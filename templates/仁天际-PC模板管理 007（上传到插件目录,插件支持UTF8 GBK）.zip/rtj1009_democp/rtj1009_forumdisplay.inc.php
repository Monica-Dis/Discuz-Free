<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . './source/plugin/rtj1009_democp/rtj1009_democp_core.php';
$addonid = 'rtj1009_democp.plugin';
if (file_exists(DISCUZ_ROOT . './source/plugin/rtj1009_democp/function.php')) {
	@(include_once DISCUZ_ROOT . './source/plugin/rtj1009_democp/function.php');
} else {
	exit('Access Denied');
}
$act = daddslashes($_GET['act']);
if (!$act) {
	$perpage = max(10, empty($_GET['perpage']) ? 10 : intval($_GET['perpage']));
	$start = ($page - 1) * $perpage;
	$count = get_forum_count();
	$forum = get_forum_list($start, $perpage);
	$mpurl = ADMINSCRIPT . '?' . $plug_url . 'rtj1009_forumdisplay';
	$multipage = multi($count, $perpage, $page, $mpurl, 0, 100);
	$bids = get_style_list();
	foreach ($bids as $row) {
		$fids[$row['bid']] = $row;
	}
	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_democp&pmod=rtj1009_forumdisplay&act=del', 'enctype');
	showtableheader(lang('plugin/rtj1009_democp', 'rtj1009_001'));
	echo '<tr class="header"><th>' . lang('plugin/rtj1009_democp', 'rtj1009_012') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_019') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_003') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_004') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_005') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_006') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_007') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_018') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_021') . '</th><th></th></tr>';
	foreach ($forum as $list) {
		$check0 = $fids[$list['fid']]['style'] == 0 ? 'checked="checked"' : '';
		$check1 = $fids[$list['fid']]['style'] == 1 ? 'checked="checked"' : '';
		$check2 = $fids[$list['fid']]['style'] == 2 ? 'checked="checked"' : '';
		$check3 = $fids[$list['fid']]['style'] == 3 ? 'checked="checked"' : '';
		$check4 = $fids[$list['fid']]['style'] == 4 ? 'checked="checked"' : '';
		$check5 = $fids[$list['fid']]['style'] == 5 ? 'checked="checked"' : '';
		$name = 'style' . $list['fid'] . '';
		echo '<tr class="hover">' . '<th class="td25"><input class="checkbox" type="checkbox" name="delete[' . $list['fid'] . ']" value="' . $list['fid'] . '"></th>' . '<th>' . $list['fid'] . '</th>' . '<th>' . $list['name'] . '</th>' . '<th><input type="radio" name="' . $name . '"  value="0"  disabled ' . $check0 . '/></th>' . '<th><input type="radio" name="' . $name . '"  value="1"  disabled ' . $check1 . '/></th>' . '<th><input type="radio" name="' . $name . '"  value="2"  disabled ' . $check2 . '/></th>' . '<th><input type="radio" name="' . $name . '"  value="3"  disabled ' . $check3 . '/></th>' . '<th><input type="radio" name="' . $name . '"  value="4"  disabled ' . $check4 . '/></th>' . '<th><input type="radio" name="' . $name . '"  value="5"  disabled ' . $check5 . '/></th>' . '<th width="100">' . '<a href="' . ADMINSCRIPT . '?' . $plug_url . 'rtj1009_forumdisplay&act=edit&id=' . $list['fid'] . '&name=' . $list['name'] . '">' . lang('plugin/rtj1009_democp', 'rtj1009_008') . '</a>&nbsp;' . '</th>' . '</tr>';
	}
	showtablefooter();/*Dism��taobao��com*/
	echo '<tr><td>
		<input type="checkbox" name="chkall" id="chkallDx4b" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')" />
		<label for="chkallDx4b">' . lang('plugin/rtj1009_democp', 'rtj1009_012') . '</label> 
		</td>  </tr>';
	echo '<script type="text/javascript">
		function check_all(obj,id){
			
			for(var i=1;i<' . $list['fid'] . ';i++){
				
				document.getElementById(id+""+i).checked = obj.checked;
			}
		}
	    </script>';
	showsubmit('submit', lang('plugin/rtj1009_democp', 'rtj1009_011'), '', '', $multipage);
	showformfooter();/*Dism-taobao_com*/
} else {
	if ($act == 'edit') {
		if (!submitcheck('submit')) {
			$fid = intval($_GET['id']);
			$name = $_GET['name'];
			$bidss = get_style_bid($fid);
			$selected0 = $bidss['style'] == 0 ? 'selected="selected"' : '';
			$selected1 = $bidss['style'] == 1 ? 'selected="selected"' : '';
			$selected2 = $bidss['style'] == 2 ? 'selected="selected"' : '';
			$selected3 = $bidss['style'] == 3 ? 'selected="selected"' : '';
			$selected4 = $bidss['style'] == 4 ? 'selected="selected"' : '';
			$selected5 = $bidss['style'] == 5 ? 'selected="selected"' : '';
			$lang = lang('plugin/rtj1009_democp');
			showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_democp&pmod=rtj1009_forumdisplay&act=edit', 'enctype');
			echo '<input type="hidden" name="id" value="' . $fid . '"/>';
			showtableheader(lang('plugin/rtj1009_democp', 'rtj1009_014') . $name);
			echo '<table class="tb" style="padding:10px 0;">
	<tbody>
		<tr>
			<td>
				' . $lang['rtj1009_0015'] . '
				<select name="style"> 
				  <option value= "0" ' . $selected0 . ' >' . $lang['rtj1009_004'] . '</option>
				  <option value ="1" ' . $selected1 . ' >' . $lang['rtj1009_005'] . '</option>
				  <option value ="2" ' . $selected2 . ' >' . $lang['rtj1009_006'] . '</option>
				  <option value ="3" ' . $selected3 . ' >' . $lang['rtj1009_007'] . '</option>
				  <option value ="4" ' . $selected4 . ' >' . $lang['rtj1009_018'] . '</option>
				  <option value ="5" ' . $selected4 . ' >' . $lang['rtj1009_021'] . '</option>
				</select>
			</td>
		</tr>
		<tr><td></td></tr>
	</tbody>
</table>';
			showsubmit('submit', lang('plugin/rtj1009_democp', 'rtj1009_013'));
			showtablefooter();/*Dism��taobao��com*/
			showformfooter();/*Dism-taobao_com*/
		} else {
			$bid = intval($_POST['id']);
			$data = array();
			$data['bid'] = intval($_POST['id']);
			$data['style'] = intval($_POST['style']);
			$condition = 'bid = ' . $bid . '';
			$cubid = get_style_bid($bid);
			if ($cubid) {
				update($data, $condition);
				cpmsg(lang('plugin/rtj1009_democp', 'gx_cg'), $plug_url . 'rtj1009_forumdisplay', 'succeed');
			} else {
				insert($data);
				cpmsg(lang('plugin/rtj1009_democp', 'cr_cg'), $plug_url . 'rtj1009_forumdisplay', 'succeed');
			}
		}
	} elseif ($act == 'del') {
		if (submitcheck('submit') && $_POST['delete']) {
			foreach ($_POST['delete'] as $delete) {
				delete(array('bid' => $delete));
			}
			cpmsg(lang('plugin/rtj1009_democp', 'rtj1009_016'), $plug_url . 'rtj1009_forumdisplay', 'succeed');
		} else {
			cpmsg(lang('plugin/rtj1009_democp', 'rtj1009_017'), $plug_url . 'rtj1009_forumdisplay', 'succeed');
		}
	}
}