<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$config = $_G['cache']['plugin']['rtj1009_democp'];
$plug_url = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_democp&pmod=';
function get_forum_count()
{
	$sult = DB::fetch_first('SELECT count(*) as count FROM ' . DB::table('forum_forum') . ' WHERE status=\'1\' and type=\'forum\'');
	return $sult['count'];
}
function get_forum_list($start, $perpage)
{
	return DB::fetch_all('SELECT * FROM ' . DB::table('forum_forum') . ' WHERE status=\'1\' and type=\'forum\' order by fid asc limit ' . $start . ',' . $perpage);
}
function get_style_bid($fid)
{
	return DB::fetch_first('SELECT * FROM ' . DB::table('rtj1009_style') . (' WHERE bid=\'' . $fid . '\' '));
}
function get_style_list()
{
	return DB::fetch_all('SELECT * FROM ' . DB::table('rtj1009_style'));
}
function insert($data)
{
	return DB::insert('rtj1009_style', $data, true);
}
function update($data, $condition)
{
	return DB::update('rtj1009_style', $data, $condition, true);
}
function delete($condition)
{
	return DB::delete('rtj1009_style', $condition);
}