<?php echo 'From: DisM.taobao.com';exit;?>

<!--{if $list['threadcount']}-->
<ul>
    <!--{eval $i = 1;}-->
	<!--{loop $list['threadlist'] $key $thread}-->
<li class="cl" {if $i == 1}style="border-top: 0;"{/if}>
    <div class="laid_glist_avt">
	     <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank"><!--{avatar($thread[authorid],middle)}--></a>
    </div>
    <div class="laid_glist_center">
        <div class="laid_glist_content">
            <div class="laid_glist_title">
                 <a href="forum.php?mod=forumdisplay&fid=$thread[fid]" class="laid_glist_fname"><em>[</em>$list['forumnames'][$thread[fid]]['name']<em>]</em></a>
                  <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" target="_blank" title="$thread[subject]">$thread[subject]</a>

				  <!--{if $thread[folder] == 'lock' || $thread['special'] == 1 || $thread['special'] == 2 || $thread['special'] == 3 || $thread['special'] == 4 || $thread['special'] == 5 || in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				  <a href="forum.php?mod=viewthread&tid=$thread[icontid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="{if $thread['displayorder'] == 1}{lang thread_type1} - {/if}
					 {if $thread['displayorder'] == 2}{lang thread_type2} - {/if}
					 {if $thread['displayorder'] == 3}{lang thread_type3} - {/if}
					 {if $thread['displayorder'] == 4}{lang thread_type4} - {/if}
					 {if $thread[folder] == 'lock'}{lang closed_thread} - {/if}
					 {if $thread['special'] == 1}{lang thread_poll} - {/if}
					 {if $thread['special'] == 2}{lang thread_trade} - {/if}
					 {if $thread['special'] == 3}{lang thread_reward} - {/if}
					 {if $thread['special'] == 4}{lang thread_activity} - {/if}
					 {if $thread['special'] == 5}{lang thread_debate} - {/if}
					 {if $thread[folder] == "new"}{lang have_newreplies} - {/if} {lang target_blank}" target="_blank">
					 <!--{if $thread[folder] == 'lock'}-->
						 <img src="{IMGDIR}/folder_lock.gif" />
					 <!--{elseif $thread['special'] == 1}-->
						 <img src="{IMGDIR}/pollsmall.gif" alt="{lang thread_poll}" />
					 <!--{elseif $thread['special'] == 2}-->
						 <img src="{IMGDIR}/tradesmall.gif" alt="{lang thread_trade}" />
					 <!--{elseif $thread['special'] == 3}-->
						 <img src="{IMGDIR}/rewardsmall.gif" alt="{lang thread_reward}" />
					 <!--{elseif $thread['special'] == 4}-->
						 <img src="{IMGDIR}/activitysmall.gif" alt="{lang thread_activity}" />
					 <!--{elseif $thread['special'] == 5}-->
						 <img src="{IMGDIR}/debatesmall.gif" alt="{lang thread_debate}" align="absmiddle" />
					 <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
						 <img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" align="absmiddle" />
					 <!--{/if}-->
				  </a>
				  <!--{/if}-->
				  <!--{if $_G['setting']['threadhidethreshold'] && $thread['hidden'] >= $_G['setting']['threadhidethreshold']}-->&nbsp;<span class="xg1">{lang hidden}</span>&nbsp;<!--{/if}--><!--{if $view == 'hot'}-->&nbsp;<span class="xi1">$thread['heats']{lang guide_attend}</span>&nbsp;<!--{/if}-->
				  <!--{if $thread[icon] >= 0}-->
					  <img src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" />
				  <!--{/if}-->
				  <!--{if $thread['rushreply']}-->
					  <img src="{IMGDIR}/rushreply_s.png" alt="{lang rushreply}" align="absmiddle" />
				  <!--{/if}-->
				  <!--{if $stemplate && $sortid}-->$stemplate[$sortid][$thread[tid]]<!--{/if}-->
					  <!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->
				  <!--{if $thread['price'] > 0}-->
					  <!--{if $thread['special'] == '3'}-->
						   - <span class="xi1">[{lang thread_reward} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span>
					  <!--{else}-->
						   - [{lang price} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
					  <!--{/if}-->
					  <!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
						   - [{lang reward_solved}]
				   <!--{/if}-->
				   <!--{if $thread['attachment'] == 2}-->
						 <img src="{STATICURL}image/filetype/image_s.gif" alt="attach_img" title="{lang attach_img}" align="absmiddle" />
						 <!--{elseif $thread['attachment'] == 1}-->
							 <img src="{STATICURL}image/filetype/common.gif" alt="attachment" title="{lang attachment}" align="absmiddle" />
						 <!--{/if}-->
						 <!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
							 <img src="{IMGDIR}/digest_$thread[digest].gif" align="absmiddle" alt="digest" title="{lang thread_digest} $thread[digest]" />
						 <!--{/if}-->
						 <!--{if $thread['displayorder'] == 0}-->
							 <!--{if $thread[recommendicon] && $filter != 'recommend'}-->
								 <img src="{IMGDIR}/recommend_$thread[recommendicon].gif" align="absmiddle" alt="recommend" title="{lang thread_recommend} $thread[recommends]" />
							 <!--{/if}-->
							 <!--{if $thread[heatlevel]}-->
								 <img src="{IMGDIR}/hot_$thread[heatlevel].gif" align="absmiddle" alt="heatlevel" title="$thread[heatlevel] {lang heats}" />
							 <!--{/if}-->
								 <!--{if $thread['rate'] > 0}-->
									 <img src="{IMGDIR}/agree.gif" align="absmiddle" alt="agree" title="{lang rate_credit_add}" />
								 <!--{elseif $thread['rate'] < 0}-->
									 <img src="{IMGDIR}/disagree.gif" align="absmiddle" alt="disagree" title="{lang posts_deducted}" />
								 <!--{/if}-->
							 <!--{/if}-->
								 <!--{if $thread['replycredit'] > 0}-->
									 - <span class="xi1">[{lang replycredit} <strong> $thread['replycredit']</strong> ]</span>
								 <!--{/if}-->
								 <!--{if $thread[multipage]}-->
									 <span class="tps">$thread[multipage]</span>
								 <!--{/if}-->
								 <!--{if $thread['weeknew']}-->
									 <a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost" class="xi1">New</a>
								 <!--{/if}-->
								 <!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									 <!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
										 <!--{eval $thread[tid]=$thread[closed];}-->
									 <!--{/if}-->
							    <!--{/if}-->
                </div>
            <div class="laid_glist_info">
			    <span>楼主：
				<!--{if $thread['authorid'] && $thread['author']}-->
					<a href="home.php?mod=space&uid=$thread[authorid]" c="1">$thread[author]</a><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->
				<!--{else}-->
					$_G[setting][anonymoustext]
				<!--{/if}-->
				</span>
				<span>$thread[dateline]</span>
				<span>最后回复：
                <!--{if $thread['lastposter']}--><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}" c="1">$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}-->
				</span>
				<span><a href="{if $thread[digest] != -2}forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost$highlight#lastpost{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}">$thread[lastpost]</a></span>
			</div>
        </div>
    </div>
    <div class="laid_glist_right laid_glist_num">
	     <span class="mr-small z">回复<em>$thread[replies]</em></span>
		 <span>浏览<em><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></em></span>
	</div>
</li>
<!--{if $view == 'my' && $viewtype=='reply' && !empty($tids[$thread[tid]])}-->
   <!--{loop $tids[$thread[tid]] $pid}-->
		<!--{eval $post = $posts[$pid];}-->
		<div class="tl_reply pbm xg1" style="margin-left: 60px;"><a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid" target="_blank"><!--{if $post[message]}-->{$post[message]}<!--{else}-->...<!--{/if}--></a></div>
   <!--{/loop}-->
<!--{/if}-->
<!--{if $view == 'my' && $viewtype=='postcomment'}-->
	  <div class="xg1" style="margin-left: 60px;padding-bottom: 15px;">$thread[comment]</div>
<!--{/if}-->
			<!--{eval $i++;}-->
		<!--{/loop}-->
	</ul>
	<!--{else}-->
	   <div class="laid_glist_emp"><p class="emp">{lang guide_nothreads}</p></div>
<!--{/if}-->