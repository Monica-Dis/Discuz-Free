<?php echo 'From: DisM.taobao.com';exit;?>
<div id="comment" class="laid_mk_main" style="margin-top: 0;padding: 10px 15px;">
     <div class="laid_tit_b"><i></i>会员评论</div>
     <div id="comment_ul" class="laid_comment_box"> 
          <!--{if !empty($pricount)}-->
              <p class="mtn mbn y">{lang hide_portal_comment}</p>
          <!--{/if}--> 
   
	      <!--{if !$data[htmlmade]}-->
		    <form id="cform" name="cform" action="$form_url" method="post" autocomplete="off">
			    <div class="laid_active_avt"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank"><!--{avatar($_G[uid],midlle)}--></a></div>
				<div class="tedt mbm" id="tedt">
					<div class="area">
                    <span class="laid_comment_arrow"><i></i></span>
						<textarea name="message" rows="3" class="pt" id="message" placeholder="{if !$_G['uid']}登录后可发表评论{else}我来说两句...{/if}" onkeydown="ctrlEnter(event, 'commentsubmit_btn');"></textarea>
					</div>
				</div>
				<!--{if $secqaacheck || $seccodecheck}-->
					<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
					<div class="mtm"><!--{subtemplate common/seccheck}--></div>
				<!--{/if}-->
				<!--{if !empty($topicid) }-->
					<input type="hidden" name="referer" value="$topicurl#comment" />
					<input type="hidden" name="topicid" value="$topicid">
				<!--{else}-->
					<input type="hidden" name="portal_referer" value="$viewurl#comment">
					<input type="hidden" name="referer" value="$viewurl#comment" />
					<input type="hidden" name="id" value="$data[id]" />
					<input type="hidden" name="idtype" value="$data[idtype]" />
					<input type="hidden" name="aid" value="$aid">
				<!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}">
				<input type="hidden" name="replysubmit" value="true">
				<input type="hidden" name="commentsubmit" value="true" />
				<p class="pt10 cl y"><button type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="true" class="pn y"><strong>{lang comment}</strong></button></p>
			</form>
		<!--{/if}-->
        <ul>
            <!--{loop $commentlist $comment}--> 
            <!--{eval $laid_i++;}-->
            <!--{eval settype($data[commentnum], 'integer');}-->
                 <!--{template portal/comment_li}--> 
                 <!--{if !empty($aimgs[$comment[cid]])}--> 
                      <script type="text/javascript" reload="1">aimgcount[{$comment[cid]}] = [<!--{echo implode(',', $aimgs[$comment[cid]]);}-->];attachimgshow($comment[cid]);</script> 
                 <!--{/if}--> 
            <!--{eval if($laid_i == 6)break;}-->
            <!--{/loop}-->
        </ul>
        <!--{if $laid_i > 5}-->
            <p class="ptm pbm cl" style=" text-align:center">
                <a href="$common_url" class="xi2">查看全部评论>></a>
            </p>
        <!--{/if}-->  
    </div>
</div>
