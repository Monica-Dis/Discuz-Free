<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$laid_today = date("Ymd",time()); 
$laid_article_num = DB::result(DB::query("SELECT count(*) FROM ".DB::table('portal_article_title')." WHERE catid = '$cat[catid]' AND FROM_UNIXTIME(dateline, '%Y%m%d') = '$laid_today'"));



?>
