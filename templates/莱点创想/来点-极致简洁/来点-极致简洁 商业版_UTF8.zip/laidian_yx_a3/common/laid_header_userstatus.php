<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['uid']}-->
<div class="laid_topbar_ritem">
    <!--{if check_diy_perm($topic)}-->
         <span class="laid_navtt">
	           <a href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" style="float: left;">设置DIY</a>
	     </span>
	     <i>|</i>
    <!--{/if}-->
    <span class="laid_navtt">
	     <a href="home.php?mod=space&do=notice" id="myprompt" class="a showmenu{if $_G[member][newprompt]} new{/if} z" onmouseover="showMenu({'ctrlid':'myprompt'});">{lang remind}<!--{if $_G[member][newprompt]}-->($_G[member][newprompt])<!--{/if}--></a>
	</span>
    <i>|</i>
    <div id="myprompt_check"></div>
    <!--{if empty($_G['cookie']['ignore_notice']) && ($_G[member][newpm] || $_G[member][newprompt_num][follower] || $_G[member][newprompt_num][follow] || $_G[member][newprompt])}--><script language="javascript">delayShow($('myprompt'), function() {showMenu({'ctrlid':'myprompt','duration':3})});</script><!--{/if}-->
</div>
<div class="laid_topbar_ruser z">
     <a href="home.php?mod=space&uid=$_G[uid]" class="laid_uname"><!--{avatar($_G[uid],small)}-->$_G[member][username]</a>
     <div class="laid_userlayer_main">
	      <ul class="cl">
		      <li class="laid_userlayer1">
			      <div class="img"><a href="home.php?mod=spacecp&ac=avatar"><!--{avatar($_G[uid],middle)}--></a></div>
				  <div class="name"><a href="home.php?mod=space&uid=$_G[uid]">{$_G[member][username]}</a></div>
				  <div class="time">用户组: <a href="home.php?mod=spacecp&ac=usergroup">$_G[group][grouptitle]</a></div>
			  </li>
		  
		      <li class="laid_userlayer2">
                  <div class="binding cl">
				       <a href="forum.php?mod=guide&amp;view=my">帖子</a>
					   <a href="home.php?mod=spacecp&ac=credit&showcredit=1">积分</a>
                       <a href="home.php?mod=space&amp;do=friend">好友</a>
					   <a href="home.php?mod=task">任务</a>
                       <a href="home.php?mod=medal">勋章</a>
					   <a href="home.php?mod=space&do=album&view=me">相册</a>
				       <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
                          <a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a>
                       <!--{/if}--> 
					   <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
			           <a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a>
		               <!--{/if}-->
                       <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
		                  <a href="admin.php" target="_blank">后台管理</a>
		               <!--{/if}-->
				  </div>
		      </li>
		  	  <li class="laid_userlayer3">
		          <a class="uc" href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{$_G[member][username]}空间">会员中心</a>
			      <a class="fav" href="home.php?mod=space&do=favorite&view=me">我的收藏</a>
		      </li>
		      <li class="laid_userlayer4">
		          <div class="laid_user_ftlink">
			           <a href="home.php?mod=spacecp">个人设置</a> | 
				       <a href="home.php?mod=spacecp&ac=profile&op=password">修改密码</a>
			      </div>
			      <div class="laid_logout"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">退出</a></div>
			  </li>
		  </ul>
    </div>
</div>
</div>

<!--{elseif !empty($_G['cookie']['loginuser'])}-->

<p>
	<strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
</p>
<!--{elseif !$_G[connectguest]}-->

<div class="laid_topbar_ruser y">
    <span class="laid_nologin_box">
        <a class="laid_login" href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" onclick="showWindow('login', this.href);return false;">登录</a>
		<span style="display: inline-block;line-height: 30px;font-size: 12px; color: #555;">|</span>
        <a class="laid_reg" href="member.php?mod={$_G[setting][regname]}" target="_blank">注册</a>
    </span>
</div>

<!--{else}-->

<div class="laid_topbar_ruser y">
     <div class="laid_topbar_ruser_avatar">
          <a class="laid_b_member_login" target="_blank" href="javascript:;">          
		      <span><img class="laid_b_avatar_pic" src="$_G['style']['styleimgdir']/laid_nologin_icon.png"></span>          
              <span class="laid_b_noLogin" style=" padding-left: 15px; font-size: 14px;overflow: hidden; text-overflow: ellipsis; white-space: nowrap; course: hand; " title="帐号" id="avatar-name">$_G[member][username]</span>
          </a>
      </div>
     
 <div class="laid_topbar_ruser_menu">
      <div class="laid_topbar_ruser_menu-panel">
           <i class="icon_hd icon-arrow-t"></i>
   
      <li>
	      <a href="member.php?mod=connect" target="_blank" title="体验本站更多功能">完善帐号信息</a>
      </div>

	<li>
		<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
    </div>

    </div>
  </div>

</div>
<!--{/if}-->