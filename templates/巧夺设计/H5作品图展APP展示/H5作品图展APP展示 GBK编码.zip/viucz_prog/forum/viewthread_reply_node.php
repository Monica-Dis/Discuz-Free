<?php echo 'Viucz';exit;?>
                             <li>
                                <div class="headImg">
									<a href="home.php?mod=space&uid=$post[authorid]"><img src="{echo avatar($post[authorid],'big',1);}"/></a>
                                </div>
                                <div class="commentWrap">
                                    <p class="name">
                                       <a href="home.php?mod=space&uid=$post[authorid]">$post[author]</a>
                                    </p>
                                    <div class="commentWords">
										<!--{subtemplate forum/viewthread_node_body}-->
                                    </div>
                                    <div class="commentInfo">
                                        <span>$post[dateline]</span>
                                    </div>
                                    <div class="y">
										<!--{if $post['invisible'] == 0}-->
										<!--{if $post['authorid'] != $_G['uid']}-->
										<span class="report">
											<a href="javascript:;" onclick="showWindow('miscreport$post[pid]', 'misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]', 'get', -1);return false;">{lang report}</a>
										</span>
										<!--{/if}-->
										<!--{/if}-->
										<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
										<span class="report">
										<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}</a><!--{/if}-->
										</span>
										<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
										<span class="report">
										<a href="forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page" onClick="showWindow('postappend', this.href, 'get', 0)">{lang postappend}</a>
										</span>
										<!--{/if}-->

										<!--{if $post['invisible'] == 0}-->
										<!--{if (!$_G['uid'] || $allowpostreply) && !$needhiddenreply}-->
										<a class="fa fa-commenting-o" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" onclick="showWindow('reply', this.href)"></a>
										<!--{/if}-->
										<!--{/if}-->
										<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
										<a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', '');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = ($('review_support_$post[pid]').innerHTML ? $('review_support_$post[pid]').innerHTML : 0) + ' {lang activity_member_unit} {lang support_reply}'" class="comment-zan "><span id="review_support_$post[pid]">$post[postreview][support]</span></a>
										<!--{/if}-->
										<!--{if !$post['first'] && $modmenu['post']}-->
										<label for="manage$post[pid]" style="color:#191616d9;padding-left:20px;">
										<input type="checkbox" id="manage$post[pid]" class="pc" {if !empty($modclick)}checked="checked" {/if}onclick="pidchecked(this);modclick(this, $post[pid])" value="$post[pid]" autocomplete="off" />
										{lang manage}
										</label>
										<!--{/if}-->
									</div>
                                </div>
                            </li>
