<?php echo 'Viucz';exit;?>
</div>
<!--{if $space[uid]}-->
<!--{eval $member_count = get_member_count($space[uid]);}-->
<!--{eval $member_profile = get_member_profile($space[uid]);}-->
<div class="head-mask">
	<div class="mask-mask"></div>
	<div class="head-mask-content">
		<div class="mask-share cl">
			<!--{if !ckfollow($space['uid'])}-->
			<a id="followmod" class="mask-follow" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]" title="��ע">+ ��ע</a>
			<!--{else}-->
			<a id="followmod" class="mask-follow" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]" title="�ѹ�ע" >&nbsp;�ѹ�ע</a>
			<!--{/if}-->
		</div>
		<div class="mask-team">
			<div class="mask-icon">
				<a href="home.php?mod=space&uid=$space[uid]" title="$space[username]" >
					<img style="border-radius:50%" src="{echo avatar($space[uid],'big',1);}" class="headimg">
				</a>
			</div>
			<div class="mask-teamname">
				{$space[username]}
			</div>
			<div class="mask-teamdetails">
				<span class="mask-areas">
					<!--{if $member_profile[residecity]}-->{$member_profile[residecity]}<!--{else}-->δ������<!--{/if}-->
					<!--{if $member_profile[occupation]}-->&nbsp;|&nbsp;{$member_profile[occupation]}<!--{/if}-->
				</span>
				<span class="mask-split">|</span>
				<span class="mask-constructor">
					<!--{if $member_profile[bio]}-->$member_profile[bio]<!--{else}-->��һ������ʲô��û�����£�<!--{/if}-->
				</span>
			</div>
		</div>
		<div class="mask-details">
			<ul>
				<li>
					<a href="home.php?mod=space&uid=$space[uid]" target="_parent">
						<span class="num">{$space[uid]}</span>
						<span class="name">UID</span>
					</a>
				</li>
				<li>
					<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space" target="_parent">
						<span class="num">$member_count[threads]</span>
						<span class="name">��Ʒ</span>
					</a>
				</li>
				<li>
					<a href="home.php?mod=follow&do=following&uid=$space[uid]" target="_parent">
						<span class="num">$member_count[following]</span>
						<span class="name">��ע</span>
					</a>
				</li>
				<li>
					<a href="home.php?mod=follow&do=follower&uid=$space[uid]" target="_parent">
						<span class="num">$member_count[follower]</span>
						<span class="name">��˿</span>
					</a>
				</li>
				<li>
					<span class="num">$member_count[extcredits2]</span>
					<span class="name">��Ǯ</span>
				</li>
			</ul>
		</div>
	</div>
</div>
<div class="conten">
	<div class="content">
		<div class="content-left caseBlock">
			<ul class="left-navigation">
				<li onclick="self.location='home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space'" class="new-news{if $do=='thread'} left-navigation-avtive{/if}">�ҵ���Ʒ</li>
				<li onclick="self.location='home.php?mod=space&uid=$space[uid]&do=profile&from=space'" class="new-news{if $do==profile} left-navigation-avtive{/if}">��������</a></li>
				<li onclick="self.location='home.php?mod=follow&do=following&uid=$space[uid]'" class="new-news{if CURMODULE == 'follow' && $do =='following'} left-navigation-avtive{/if}">�ҵĹ�ע</li>
				<li onclick="self.location='home.php?mod=follow&do=follower&uid=$space[uid]'" class="new-news{if CURMODULE == 'follow' && $do =='follower'} left-navigation-avtive{/if}">�ҵķ�˿</li>
			</ul>
			<!--{/if}-->