<?php echo 'Viucz';exit;?>
			<div class="content-right">
				<div class="right-intro">
					<ul class="right-intro-main">
						<li>
							<div class="right-type">
								<i class="iconfont">&#xe617;</i>��������
							</div>
							<div class="right-num">
								<i class="iconfont">&#xe696;</i>{$space[uid]}
							</div>
						</li>
						<li>
							<div class="right-local">
								<i class="iconfont">&#xe61b;</i><!--{if $member_profile[resideprovince]}-->{$member_profile[resideprovince]} {$member_profile[residecity]} {$member_profile[residedist]}<!--{else}-->δ֪����&nbsp;���Ի���<!--{/if}-->
							</div>
						</li>
						<!--{eval space_merge($space, 'field_home'); $space[domainurl] = space_domain($space);getuserdiydata($space);$personalnv = isset($_G['blockposition']['nv']) ? $_G['blockposition']['nv'] : '';}-->
						<li>
							<a href="{if $member_profile[site]}$member_profile[site]{else}$space[domainurl]{/if}" class="right-address" target="_blank"><i class="iconfont">&#xe615;</i><!--{if $member_profile[site]}-->$member_profile[site]<!--{else}-->$space[domainurl]<!--{/if}--></a>
						</li>
					</ul>
					<ul class="right-tag">
					</ul>
					<div class="menber-intro">
						<h3>���</h3>
						<p class="menber-inteo-main">
							<!--{if $member_profile[bio]}-->$member_profile[bio]<!--{else}-->��һ������ʲô��û����<!--{/if}-->
						</p>
					</div>
				</div>
				<div class="hotteam first-class">
					<p style="display:block;" class="noNum">
						<i class="iconfont">&#xe717;</i>�����Ŷ�
					</p>
					<nav>
						<a href="#" target="_blank">
							<img src="template/viucz_prog/nike/img/1493111647038039702.png"/>
							<span>��Ѷ��Ϸ</span>
						</a>
						<a href="#" target="_blank">
							<img src="template/viucz_prog/nike/img/1499418261165092436.jpg"/>
							<span>��Ѷ��Ƶ</span>
						</a>
						<a href="#" target="_blank">
							<img src="template/viucz_prog/nike/img/1498294697166074643.png"/>
							<span>����</span>
						</a>
					</nav>
				<div>
			</div>