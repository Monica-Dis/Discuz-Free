<?php echo 'Viucz';exit;?>
<!--{template common/header}-->
	<!--{template home/space_menu}-->
			<!--{subtemplate home/space_profile_body}-->
		</div>
		<!--{subtemplate home/space_right}-->
	</div>
</div>
<!--{template common/footer}-->