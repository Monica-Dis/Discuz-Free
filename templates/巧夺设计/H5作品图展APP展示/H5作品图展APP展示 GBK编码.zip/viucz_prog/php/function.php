<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function get_member_count($uid){
    $get_member_count = DB::fetch_first('SELECT * FROM %t WHERE uid= %d', array('common_member_count', "$uid"), 'uid');
	return $get_member_count;
}

function get_member_profile($uid){
    $get_member_profile = DB::fetch_first('SELECT * FROM %t WHERE uid= %d', array('common_member_profile', "$uid"), 'uid');
	return $get_member_profile;
}


function get_thread_cover($tid, $cover = 0, $getfilename = 0) {
	global $_G;
	if(empty($tid)) {
		return '';
	}
	$coverpath = '';
	$covername = 'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
	if($getfilename) {
		return $covername;
	}
	if($cover) {
		$coverpath = ($cover < 0 ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/'.$covername;
	}
	return $coverpath;
}

function get_ck_follow($followuid) {
	global $_G;

	if(empty($_G['uid'])) return false;

	$var = 'home_follow_'.$_G['uid'].'_'.$followuid;
	if(isset($_G[$var])) return $_G[$var];

	$_G[$var] = false;
	$follow = C::t('home_follow')->fetch_status_by_uid_followuid($_G['uid'], $followuid);
	if(isset($follow[$_G['uid']])) {
		$_G[$var] = true;
	}
	return $_G[$var];
}


function get_tid($array){
	require_once(DISCUZ_ROOT."./source/function/function_post.php");
	$tids = array();
	foreach( $array as $key => $thread){
		$table='forum_attachment_'.substr($thread['tid'], -1);
		$thread_aid = DB::fetch_first('SELECT aid FROM %t WHERE tid=%d AND isimage!=0 ORDER BY aid ASC', array("$table", "$thread[tid]"), 'tid');
		$thread_message = messagecutstr(DB::result_first('SELECT message FROM '.DB::table('forum_post').' WHERE tid ='.$thread[tid].' AND first =1'),200);
		$rw['aid'] = $thread_aid['aid'];
		$rw['message'] = $thread_message;
		$tids[$thread['tid']]=$rw;
	}
	return $tids;
}


function get_uid_thread($uid,$order,$num){
	$array = array();
	$rs = DB::query("SELECT * FROM ".DB::table("forum_thread")." WHERE authorid='$uid' AND displayorder>=0 AND attachment=2 order by $order desc limit $num");
	while ($rw = DB::fetch($rs)){
		$table ='forum_attachment_'.substr($rw['tid'], -1);
		$rw['aid'] = DB::result_first("SELECT aid FROM ".DB::table("$table")." WHERE tid ='{$rw['tid']}' AND isimage!=0 order by aid ASC");
		$array[] = $rw;
	}
	return $array;
}


function get_forum_forumfield($fid){
    $get_forum_forumfield = DB::fetch_first('SELECT * FROM %t WHERE fid= %d', array('forum_forumfield', "$fid"), 'fid');
	return $get_forum_forumfield;
}


function get_forum_gid(){
	$forum_gid = DB::fetch_all("SELECT fid,name FROM %t WHERE fup=0 AND type='group' AND status=1 ORDER BY displayorder ASC LIMIT 20", array('forum_forum'),'fid');
	return $forum_gid;
}

function get_article($aid){
	$article = DB::fetch_first('SELECT * FROM %t WHERE aid=%d', array('portal_article_count', "$aid"));
	return $article;
}


function get_viewthread($tid,$num){

	require_once(DISCUZ_ROOT."./source/function/function_post.php");
	$list['message'] = messagecutstr(DB::result_first('SELECT message FROM '.DB::table('forum_post').' WHERE tid ='.$tid.' AND first =1'),1100);
	$attachment = DB::fetch_first('SELECT * FROM %t WHERE tid=%d ORDER BY tid DESC', array('forum_attachment',$tid));
	if($attachment){
		$table = 'forum_attachment_'.substr($tid, -1);
		$list['count'] = DB::result_first("select count(*) FROM ".DB::table($table)." WHERE tid = $tid AND isimage != 0 ");
		$list['cover'] = DB::fetch_first('SELECT aid,pid,filename,filesize,attachment FROM %t WHERE tid = %d AND isimage != 0', array($table,$tid),'aid');
		$list['all'] = DB::fetch_all('SELECT aid,pid,filename,attachment,description FROM %t WHERE tid = %d AND isimage != 0 AND pid = %d', array($table, $tid,$list['cover']['pid']), 'aid');
		$list['attachment_num'] = count($list['attachment']);
		return $list;
	}
}


?>