<?php echo 'Viucz';exit;?>
<!--{template common/header}-->
</div>
<style id="diy_style" type="text/css"></style>

<!--[diy=diy5]--><div id="diy5" class="area"></div><!--[/diy]-->
<div class="cl"></div>
<!--[diy=diy6]--><div id="diy6" class="area"></div><!--[/diy]-->

<div>
<!--{template common/footer}-->