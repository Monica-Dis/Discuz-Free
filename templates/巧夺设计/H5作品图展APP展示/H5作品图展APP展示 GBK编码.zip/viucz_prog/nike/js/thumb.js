var thumb = (function() {

	var slideBox,
		thumbBox;

	function init(data) {
		slideBox = document.getElementsByClassName(data.slideBox);
		thumbBox = document.getElementsByClassName(data.thumbBox);
		for(var lens=0;lens<slideBox.length;lens++){
			(function(lens) {
				var thumbList = thumbBox[lens].getElementsByTagName('li');
				for(var i = 0; i < thumbList.length; i++) {
					(function(i) {
						thumbList[i].onmouseover = function() {
							for(var j = 0; j < thumbList.length; j++) {
								thumbList[j].className = 'thumbItem';
							}
							document.getElementsByClassName('num')[lens].innerHTML = "<i>" + parseInt(i + 1) + "</i><span> / " + thumbList.length + "</span>"
							slideBox[lens].getElementsByTagName('img')[0].src = thumbList[i].getElementsByTagName('img')[0].src;
		
							thumbList[i].className += ' active';
						}
					})(i);
				}
			})(lens);
		}
	}

	return init;

})();




var open_ = (function(){
	
	function init(){
		var openBtn = document.getElementById('openBtn');
		var word = openBtn.parentNode.getElementsByTagName('p')[0];
		var tag = document.createElement('p');
		tag.className = 'testWord';
		tag.style.width = word.clientWidth + 'px';
		tag.innerHTML = word.innerHTML;
		document.body.appendChild(tag);
		var hei = tag.clientHeight;
		var boxHei = getComputedStyle(word,false)['height'];
		tag.remove();

		openBtn.onclick = function(){
			openBtn.style.display = 'none';
//			word.style.overflow = 'visible';

			if(hei >= parseInt(boxHei)){
				word.style.height = hei + 'px';
				openBtn.parentNode.parentNode.style.height = 'auto';
			}
		}
		
		openBtn.parentNode.getElementsByTagName('p')[0].onmouseout = function(){
			openBtn.style.display = 'block';
//			word.style.overflow = 'hidden';
			word.style.height = '280px';
		}
		
	}
	
	return init;
	
})();
