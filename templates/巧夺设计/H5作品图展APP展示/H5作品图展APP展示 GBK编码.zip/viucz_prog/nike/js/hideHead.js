var tt_scroll=(function(){
	
	var posToTop,
		scrollToTop,
		bfScrollToTop,
		divBar,
		divBarContent,
		fixedBar,
		bfHeight;
	
	/*��ʼ������*/
	function init(id){
		
		getPosTop(id);
		bindScroll();
		
	}
	
	/*�󶨹�������*/
	function bindScroll(){
		
		window.onscroll=function(e){
			var e=e||window.event;
			scrollEvent(e);	
		}
		
	}
	
	/*�����¼�*/
	function scrollEvent(e){

		if(Math.abs(scrollToTop-bfScrollToTop)<=2){

			if(scrollToTop>bfScrollToTop){
				
				bfScrollToTop=scrollToTop-1;
			}
			else{
				bfScrollToTop=scrollToTop+1;
			}
			
		}
		else{
			bfScrollToTop=scrollToTop||0;
		}
		
		scrollToTop=document.documentElement.scrollTop||document.body.scrollTop;
		
		if(ifHideInTop()){
			
//			divBarContent.style.height=0+'px';
//			divBarContent.style.overflow='hidden';
	
			if(scrollDirectionCheck()){
				
				fixedBar.style.height=bfHeight+'px';
				fixedBar.style.overflow='visible';
				
			}
			if(scrollToTop>480){
				fixedBar.style.height=bfHeight+'px';
				fixedBar.style.overflow='visible';
			}
			else{
				
				fixedBar.style.height=0+'px';
				fixedBar.style.overflow='hidden';
				
			}
			
		}
		else{
			
			fixedBar.style.height=0+'px';
			fixedBar.style.overflow='hidden';
//			divBarContent.style.height=bfHeight+'px';
//			divBarContent.style.overflow='visible';
			
		}

	}
	
	/*��ײ���*/
	function ifHideInTop(){
		
		if(scrollToTop>=(posToTop+bfHeight)){
			return true;
		}
		else{
			return false;
		}

	}
	
	/*����������*/
	function scrollDirectionCheck(){

		if(scrollToTop>bfScrollToTop){
			return false;
		}
		else{
			return true;
		}
		
	}
	
	if (!window.onload){
		window.onload=function(){
		
			scrollEvent();
		
		}
	}
	else{
		var fn = window.onload;
		window.onload = function(){
			fn();
			scrollEvent();
		}
		
	}
	
	/*��¡һ��Bar*/
	function cloneBar(obj){
		
		divBar=obj;
//		divBarContent=getElement('content');
		fixedBar=divBar.cloneNode(true);
		fixedBar.className+=' mainNav_fixed';
		var winBody=document.body||document.documentElement;
		fixedBar.style.height = 0;
		fixedBar.style.overflow = 'hidden';
		
		winBody.appendChild(fixedBar);
		
	}
	
	/*��ȡ���ϱ߾�ľ���*/
	function getPosTop(id){
		
		var attrElement=getElement(id);
		posToTop=attrElement.offsetTop;
		scrollToTop=document.documentElement.scrollTop||document.body.scrollTop;
		bfScrollToTop=scrollToTop||0;
		bfHeight=parseInt(getStyle(attrElement,'height'));
		cloneBar(attrElement);
		
	}
	
	/*ͨ��ID��className��ȡ�ڵ�*/
	function getElement(id){
		
		var attrElement=document.getElementById(id);
		if(!attrElement){
			if(document.getElementsByClassName){
				attrElement=document.getElementsByClassName(id)[0];
			}
			else{
				var all=document.getElementsByTagName('*');
				for(var i=0;i<all.length;i++){
					if(all[i].className==id){
						attrElement=all[i];
						break;
					}
				}
			}
		}
		return attrElement;
		
	}
	
	/*��ȡ������ʽ*/
	function getStyle(obj,attr){
		
		if(obj.currentStyle){
			return obj.currentStyle[attr];
		}
		else{
			return getComputedStyle(obj,false)[attr];
		}
		
	}
	
	return init;
	
})();