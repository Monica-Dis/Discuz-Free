<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->
<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_sj/touch/php/portal_list.php');}-->

<!-- header start --> 
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="portal.php">{lang portal}</a>
			<em>&rsaquo;</em>
			<!--{loop $cat[ups] $value}-->
			<a href="{$portalcategory[$value['catid']]['caturl']}">{$value[catname]}</a>
			<em>&rsaquo;</em>
			<!--{/loop}-->
			<span>{$cat[catname]}</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="portal_cat">
	<!--门户频道相关分类开始-->
	<link rel="stylesheet" href="{$_G['style']['styleimgdir']}/swiper.min.css" type="text/css">
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
	<!--{if $cat[others]}-->
	<div class="portal_cat_top">
		<div class="swiper-wrapper">
			<!--{loop $cat[others] $value}-->
			<a href="{$portalcategory[$value['catid']]['caturl']}" class="swiper-slide<!--{if $_GET['catid'] == $value['catid']}--> on<!--{/if}-->">{$value[catname]}</a>
			<!--{/loop}-->
		</div>
	</div>
	<script type="text/javascript">
		if(jQuery(".portal_cat_top .on").length > 0) {
			var tab_initial = jQuery(".portal_cat_top .on").offset().left + jQuery(".portal_cat_top .on").width() + 20 >= jQuery(window).width() ? jQuery(".portal_cat_top .on").index() : 0;
		}else{
			var tab_initial = 0;
		}
		var portal_cat_top = new Swiper('.portal_cat_top', {
			initialSlide : tab_initial,
			slidesPerView : 'auto',
			freeMode : true,
		});
	</script>
	<!--{/if}-->
	<!--门户频道下级分类开始-->
	<!--{if $cat[subs]}-->
	<div class="portal_cat_sub">
		<div class="swiper-wrapper">
			<span></span>
			<!--{loop $cat[subs] $value}-->
			<a href="{$portalcategory[$value['catid']]['caturl']}" class="swiper-slide">$value[catname]</a>
			<!--{/loop}-->
		</div>
	</div>
	<script type="text/javascript">
		var tab_initial = jQuery(".portal_cat_sub .on").length > 0 ? jQuery(".portal_cat_sub .on").index() : 0;
		var portal_cat_sub = new Swiper('.portal_cat_sub', {
			initialSlide : tab_initial,
			slidesPerView : 'auto',
			freeMode : true,
		});
	</script>
	<!--{/if}-->
</div>

<!--{if $_GET['catid'] == $about_list_id}-->
	<style type="text/css">
		.about_block_bg{ margin: .1rem 0; padding: .1rem; background: #fff; text-align: center;}
		.about_block_bg h2{ display: block; margin: .1rem 0 .15rem; font-size: .24rem;}
		.about_block_bg .h2_b{ margin-top: .4rem; padding-top: .15rem; border-top: 1px solid #eee;}
		.about_block_bg img{ max-width: 100%; vertical-align: middle;}
		.about_introduce, .about_vision{ margin-bottom: .1rem; padding: .1rem; background: #fafafa;}
		div.about_introduce, div.about_vision, dl.about_contact, div.about_join{ background: linear-gradient( 45deg, #f7f7f7 0, #f7f7f7 25%, transparent 25%, transparent 50%, #f7f7f7 50%, #f7f7f7 75%, transparent 75%, transparent ); background-size: .05rem .05rem; border-radius: .1rem;}
		.about_introduce p{ margin: .05rem 0; font-size: .16rem; line-height: 1.8; color: #555;}
		.about_vision .z{ width: 100%; line-height: 2; font-size: .2rem;}
		.about_vision .y{ width: 100%;}
		.about_vision .y p{ margin: .05rem 0; font-size: .15rem; line-height: 1.8;}
		.about_vision .y p:first-child{ font-size: .17rem;}
		.about_contact{ margin-top: .1rem; padding-top: .1rem; background: #fafafa; text-align: left; text-indent: .12rem; font-size: .16rem;}
		.about_contact dt{ font-weight: 700; color: #666;}
		.about_contact dd{ color: #888; margin-bottom: .1rem; padding-bottom: .09rem; border-bottom: 1px dashed #eee;}
		.about_contact dd:last-child{ border: 0;}
		.about_join{ margin-top: .1rem; padding: .1rem; background: #fafafa;}
		.about_join .z{ margin-bottom: .1rem; width: 100%; font-size: .18rem; font-weight: 700; color: #555;}
		.about_join .y{ width: 100%; text-align: left; font-size: .16rem;}
		.about_join .y dt{ margin-top: .12rem; padding-top: .12rem; border-top: 1px dashed #eee; line-height: 2; font-weight: 700; color: #666;}
		.about_join .y dt:first-child{ margin: 0; padding: 0; border: 0;}
		.about_join .y dd{ margin: .05rem 0; color: #888;}
	</style>
	<div class="about_block_bg">
		<!--{if $about_block_sum1 || $about_block_sum2}--><h2>关于我们</h2><!--{/if}-->
		<!--{if $about_block_sum1}-->{$about_block_sum1}<!--{/if}-->
		<!--{if $about_block_sum2}-->{$about_block_sum2}<!--{/if}-->
		<!--{if $about_block_sum3 || $about_block_sum4}--><h2 class="h2_b">联系我们</h2><!--{/if}-->
		<!--{if $about_block_sum3}-->{$about_block_sum3}<!--{/if}-->
		<!--{if $about_block_sum4}-->{$about_block_sum4}<!--{/if}-->
		<!--{if $about_block_sum5 || $about_block_sum6}--><h2 class="h2_b">加入我们</h2><!--{/if}-->
		<!--{if $about_block_sum5}-->{$about_block_sum5}<!--{/if}-->
		<!--{if $about_block_sum6}-->{$about_block_sum6}<!--{/if}-->
	</div>
<!--{else}-->
	<!--{eval $portal_list_gg = byg_diy_block_sum('简约通用手机版门户列表页广告');}-->
	<!--{if $portal_list_gg}-->
	<div class="byg_gg">{$portal_list_gg}</div>
	<!--{/if}-->

	<!--门户频道文章列表开始-->
	<div class="portal_list">
		<div class="portal_list_list">
			<!--{subtemplate portal/list_list}-->
		</div>
		<div style="{if $_G['style']['fanye'] != 'on'}display: none;{/if}"><div class="pgs cl">{$list['multi']}</div></div>
		<!--{if $_G['style']['fanye'] != 'on'}-->
		<div class="load_more_button">
			<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="等待"/>数据加载中，请稍后...</a>
		</div>
		<script type="text/javascript">
			var ajax_state = true;
			var ajax_page = <!--{if $_GET[page]}-->$_GET[page]<!--{else}-->1<!--{/if}--> + 1;
			var all_page = jQuery('div.pg label span').text().replace(/[^\d]/g, '') || 0;
			var ajax_url = 'portal.php?mod=list&catid=' + '$_GET[catid]' + '&';
			var next_page_url = jQuery('div.pg .nxt').prop('href');

			function list_ajax() {
				if(ajax_state == true) {
					if(all_page >= 2 && all_page >= ajax_page) {
						ajax_state = false;
						jQuery(".load_more_button").html('<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="等待"/>数据加载中，请稍后...</a>');

						if(next_page_url.indexOf("index.php?") != -1) {
							ajax_url = next_page_url.split("?",1) + '?';
						}

						jQuery.ajax({
							url: ajax_url + 'page=' + ajax_page + '&mobile=2',
							type: 'GET',
							dataType: 'html',
							success: function(result) {
								jQuery(".portal_list_list").append(jQuery(result).find(".portal_list_list").html());
								ajax_page++;
								ajax_state = true;
							}
						});
					} else {
						jQuery(".load_more_button").html('<a href="forum.php?forumlist=1" title="论坛">已经到底了，进入论坛发现更多</a>');
						ajax_state = false;
					}
				}
			}

			if(jQuery(document).height() <= jQuery(window).height()) {
				list_ajax();
			}

			jQuery(window).scroll(function() {
				if(jQuery(document).height() <= jQuery(window).height() + jQuery(window).scrollTop() + 1000) {
					list_ajax();
				}
			});
		</script>
		<!--{/if}-->
	</div>
<!--{/if}-->

<!--{template common/footer}-->
