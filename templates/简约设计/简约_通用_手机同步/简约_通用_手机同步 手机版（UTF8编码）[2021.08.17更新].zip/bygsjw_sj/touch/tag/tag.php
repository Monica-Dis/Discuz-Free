<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin">
			<h2 class="header_z cl">
				<a href="javascript:;" class="shouye">
					<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
					<!--{if $_G[member][newpm] || $post_notice_new}-->
					<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
					<!--{/if}-->
				</a>
				<em>&rsaquo;</em>
				<span>全部标签</span>
			</h2>
			<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
		</div>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<style>
	.tag_list{ margin: .1rem 0; padding: .05rem; background: #fff;}
	.tag_list a{ float: left; margin: .05rem; padding: .04rem .08rem; line-height: .2rem; background: $_G['style']['zhuti']; display: block; border-radius: .02rem; font-size: .14rem; color: #fff;}
</style>

<div class="forumdisplay_tab">
	<a href="misc.php?mod=tag" class="on">热门标签</a>
</div>

<div class="tag_list cl">
<!--{if $tagarray}-->
	<!--{loop $tagarray $tag}-->
		<a href="misc.php?mod=tag&id=$tag[tagid]" title="$tag[tagname]">$tag[tagname]</a>
	<!--{/loop}-->
<!--{else}-->
	<p class="home_no_data">没有标签</p>
<!--{/if}-->
</div>

<!--{template common/footer}-->