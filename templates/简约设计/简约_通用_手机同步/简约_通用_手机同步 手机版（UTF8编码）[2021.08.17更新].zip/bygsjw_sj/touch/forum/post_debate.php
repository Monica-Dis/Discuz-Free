<?php echo 'From: DisM.taobao.com';exit;?>

<div class="byg_exfm cl">
	<style type="text/css">
		.byg_exfm{ margin-bottom: .05rem; padding: 0 .1rem; border-bottom: 1px solid #eaeaea; font-size: .15rem; color: #888;}
		.byg_sinf dt{ margin-top: .1rem; line-height: .3rem;}
		.byg_sinf dd textarea{ height: 1rem;}
		.byg_sadd dl{ margin: .15rem 0;}
		.byg_sadd dt{ line-height: .3rem;}
		.byg_sadd dd .px{ width: 2.8rem; border: .01rem solid #eee;}
	</style>
	<div class="byg_sinf">
		<dl>
			<dt><span class="rq">*</span><label for="affirmpoint">{lang debate_square_point}:</label></dt>
			<dd><textarea name="affirmpoint" id="affirmpoint" class="pt" tabindex="1">$debate[affirmpoint]</textarea></dd>
			<dt><span class="rq">*</span><label for="negapoint">{lang debate_opponent_point}:</label></dt>
			<dd><textarea name="negapoint" id="negapoint" class="pt" tabindex="1">$debate[negapoint]</textarea></dd>
		</dl>
	</div>
	<div class="byg_sadd">
		<dl class="cl">
			<dt class="z"><label for="endtime">{lang endtime}:</label></dt>
			<dd class="y">
				<script type="text/javascript" src="{$_G['style']['styleimgdir']}/date.js?{VERHASH}"></script>
				<input type="text" name="endtime" id="endtime" class="px" autocomplete="off" value="$debate[endtime]" tabindex="1" />
				<script type="text/javascript">
					new Rolldate({
						el: '#endtime',
						format: 'YYYY-MM-DD hh:mm',
						beginYear: 2000,
						endYear: 2100
					})
				</script>
			</dd>
		</dl>
		<dl class="cl">
			<dt class="z"><label for="umpire">可选裁判:</label></dt>
			<dd class="y">
				<input type="text" name="umpire" id="umpire" class="px" value="$debate[umpire]" tabindex="1" placeholder="输入裁判的用户名" />
			</dd>
		</dl>
	</div>
</div>
