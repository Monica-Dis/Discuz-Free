<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin">
			<div class="header_z cl">
				<a href="javascript:;" class="shouye">
					<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
					<!--{if $_G[member][newpm] || $post_notice_new}-->
					<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
					<!--{/if}-->
				</a>
				<em>&rsaquo;</em>
				<span>{lang rate_view}</span>
			</div>
			<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
		</div>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="byg_ratelog_all_t">
	<span>{lang total}：</span>
	<!--{loop $logcount $id $count}-->
	{$_G['setting']['extcredits'][$id][title]}<em><!--{if $count>0}-->+<!--{/if}-->$count{$_G['setting']['extcredits'][$id][unit]}</em>&nbsp;
	<!--{/loop}-->
</div>

<div class="byg_ratelog_all_b">
	<ul>
	<!--{loop $loglist $log}-->
		<li class="cl">
			<div class="z byg_ratelog_all_bz"><a href="home.php?mod=space&uid=$log[uid]&do=profile&mobile=2"><!--{echo avatar($log[uid],'middle');}--></a></div>
			<div class="y byg_ratelog_all_by">
				<div class="byg_ratelog_all_byt">
					<a href="home.php?mod=space&uid=$log[uid]&do=profile&mobile=2">{$log[username]}</a>
					<span class="y">{$log[dateline]}</span>
				</div>
				<p class="byg_ratelog_all_byb"><span>{$_G['setting']['extcredits'][$log[extcredits]][title]} $log[score] {$_G['setting']['extcredits'][$log[extcredits]][unit]}</span>{$log[reason]}</p>
			</div>
		</li>
	<!--{/loop}-->
	</ul>
</div>

<!--{template common/footer}-->
