<?php echo 'From: DisM.taobao.com';exit;?>

<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin">
			<div class="header_z cl">
				<a href="javascript:;" class="shouye">
					<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
					<!--{if $_G[member][newpm] || $post_notice_new}-->
					<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
					<!--{/if}-->
				</a>
				<i>$navigation</i>
				<em>&rsaquo;</em>
				<span>内容</span>
			</div>
			<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
		</div>
		<!--{template common/header_nav}-->
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--{hook/viewthread_top_mobile}-->
<!-- main postlist start -->
<div class="postlist">
	<h2>
		<!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
			[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
		<!--{/if}-->
		<!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
			[{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]
		<!--{/if}-->
		$_G[forum_thread][subject]
		<!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
		<!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
		<!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
		<!--{/if}-->
	</h2>
	<style type="text/css">
		table{ width: 100%;}
		th, td{ padding: .05rem; border: 1px solid #eee; font-size: .16rem;}
	</style>
	<!--{eval $postcount = 0;}-->
	<div class="post_list_ajax">
		<!--{subtemplate forum/viewthread_list}-->
	</div>
	<!--{subtemplate forum/forumdisplay_fastpost}-->
</div>
<!--{if $_G[forum_thread][allreplies] >= 1}-->
	<div style="{if $_G['style']['fanye'] != 'on'}display: none;{/if}">$multipage</div>
	<!--{if $_G['style']['fanye'] != 'on'}-->
	<div class="load_more_button">
		<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="等待"/>数据加载中，请稍后...</a>
	</div>
	<script type="text/javascript">
		var ajax_state = true;
		var ajax_page = <!--{if $_GET[page]}-->$_GET[page]<!--{else}-->1<!--{/if}--> + 1;
		var all_page = jQuery('div.pg label span').text().replace(/[^\d]/g, '') || 0;
		var ajax_url = 'forum.php?mod=viewthread&tid=' + '$_GET[tid]'<!--{if $_GET[extra]}--> + '&extra=' + '$_GET[extra]'<!--{/if}--><!--{if $_GET[authorid]}--> + '&authorid=' + '$_GET[authorid]'<!--{/if}--><!--{if $_GET[ordertype]}--> + '&ordertype=' + '$_GET[ordertype]'<!--{/if}-->;

		function list_ajax() {
			if(ajax_state == true) {
				if(all_page >= 2 && all_page >= ajax_page) {
					ajax_state = false;
					jQuery(".load_more_button").html('<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="等待"/>数据加载中，请稍后...</a>');
					jQuery.ajax({
						url: ajax_url + '&page=' + ajax_page + '&mobile=2',
						type: 'GET',
						dataType: 'html',
						success: function(result) {
							jQuery(".post_list_ajax").append(jQuery(result).find(".post_list_ajax").html());
							ajax_page++;
							ajax_state = true;
							if(jQuery('.popup').length > 0) {
								popup.init();
							}
						}
					});
				} else {
					jQuery(".load_more_button").html('<a href="forum.php?mod=viewthread&tid={$_GET[tid]}&page=1" title="论坛">已经到底了，点击回到本文第一页</a>');
					ajax_state = false;
				}
			}
		}

		if(jQuery(document).height() <= jQuery(window).height()) {
			list_ajax();
		}

		jQuery(window).scroll(function() {
			if(jQuery(document).height() <= jQuery(window).height() + jQuery(window).scrollTop() + 1000) {
				list_ajax();
			}
		});
	</script>
	<!--{/if}-->
<!--{/if}-->
<!-- main postlist end -->
<!--{hook/viewthread_bottom_mobile}-->

<form method="post" autocomplete="off" name="modactions" id="modactions">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="optgroup" />
	<input type="hidden" name="operation" />
	<input type="hidden" name="listextra" value="$_GET[extra]" />
	<input type="hidden" name="page" value="$page" />
</form>

<script type="text/javascript">
	jQuery(document).ready(function(){
		jQuery("#mask").click(function(){
			jQuery(".dialogbox").toggle();
		});
	});
	
	function setanswer(pid, from){
		if(confirm('您确认要把该回复选为“最佳答案”吗？')){
			document.modactions.action = 'forum.php?mod=misc&action=bestanswer&tid=' + '$_G[tid]' + '&pid=' + pid + '&from=' + from + '&bestanswersubmit=yes';
			document.modactions.submit();
		}
	}
	
	function zancai_ajax(obj) {
		var zancai_id = '#' + obj;
		if($_G[uid]){
			jQuery.ajax({
				url: jQuery(zancai_id).attr('href') + '&inajax=1',
				type: 'POST',
				dataType: 'xml',
				success: function(s) {
					popup.open(s.lastChild.firstChild.nodeValue);
					evalscript(s.lastChild.firstChild.nodeValue);
					if(s.lastChild.firstChild.nodeValue.indexOf('成功') != -1 || s.lastChild.firstChild.nodeValue.indexOf('recommentv') != -1){
						var zancai_num = jQuery(zancai_id).find('span').html();
						jQuery(zancai_id).find('span').html(Number(zancai_num) + 1);
						jQuery(zancai_id).find('span').show();
					}
				},
				error: function() {
					window.location.href = jQuery(zancai_id).attr('href');
					popup.close();
				},
			});
		}else{
			landingPrompt();
		}
	}
	
	function favorite_thread_ajax(obj) {
		var thread_id = '#' + obj;
		if($_G[uid]){
			jQuery.ajax({
				url: jQuery(thread_id).attr('href') + '&inajax=1',
				type: 'POST',
				dataType: 'xml',
				success: function(s){
					popup.open(s.lastChild.firstChild.nodeValue);
					evalscript(s.lastChild.firstChild.nodeValue);
				},
				error: function(){
					window.location.href = jQuery(thread_id).attr('href');
					popup.close();
				},
			});
		}else{
			landingPrompt();
		}
	}
</script>

<!--{template common/footer}-->
