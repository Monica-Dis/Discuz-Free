<?php echo 'From: DisM.taobao.com';exit;?>

<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_sj/touch/php/forum_forumdisplay_list.php');}-->
<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
	<!--{hook/viewthread_posttop_mobile $postcount}-->
   	<!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
		<div style="position: relative;"><img src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" alt="$_G[forum_threadstamp][text]" style="position: absolute; top: -.1rem; right: .95rem; z-index: 9; height: .65rem;"/></div>
	<!--{/if}-->
    <div class="plc cl{if !$post['first']} no_post_first{/if}" id="pid$post[pid]">
        <div class="display pi">
		    <div class="post_author">
			    <span class="avatar"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, middle, true)}--><!--{else}--><!--{avatar($post[authorid], middle, true)}--><!--{/if}-->" alt="头像"/></span>
				<ul class="authi">
					<li class="grey">
						<!--{if $_G['forum']['ismoderator']}-->
						<!-- manage start -->
						<!--{if $post[first]}-->
							<em style="float: right;"><a href="#moption_$post[pid]" class="popup blue" style="margin-left: .1rem;">{lang manage}</a></em>
							<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
								<!--{if !$_G['forum_thread']['special']}-->
								<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
								<!--{/if}-->
								<input type="button" value="{lang delete}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
								<input type="button" value="{lang close}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
								<input type="button" value="{lang admin_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
								<input type="button" value="{lang topicadmin_warn_add}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
							</div>
						<!--{else}-->
							<em style="float: right;"><a href="#moption_$post[pid]" class="popup blue" style="margin-left: .1rem;">{lang manage}</a></em>
							<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
								<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
								<!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
								<!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
								<!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
							</div>
						<!--{/if}-->
						<!-- manage end -->
						<!--{/if}-->
						<em class="post_number">
							<!--{if isset($post[isstick])}-->
								<img src ="{IMGDIR}/settop.png" alt="{lang replystick}" class="vm" />{lang from} {$post[number]}{$postnostick}
							<!--{elseif $post[number] == -1}-->
								{lang recommend_post}
							<!--{else}-->
								<!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}-->
							<!--{/if}-->
						</em>
						<b>
						<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
							<a href="home.php?mod=space&uid=$post[authorid]&do=profile&mobile=2" class="blue">$post[author]</a>
						<!--{else}-->
							<!--{if !$post['authorid']}-->
								<a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
							<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
								<!--{if $_G['forum']['ismoderator']}-->
								<a href="home.php?mod=space&uid=$post[authorid]&do=profile&mobile=2">{$_G[setting][anonymoustext]}</a>
								<!--{else}-->
								{$_G[setting][anonymoustext]}
								<!--{/if}-->
							<!--{else}-->
								$post[author] <em>{lang member_deleted}</em>
							<!--{/if}-->
						<!--{/if}-->
						</b>
					</li>
					<!--{if $post[first]}-->
					<li class="grey rela cl">
						<span class="byg_post_views">
							<img src="{$_G['style']['styleimgdir']}/chakan.png" alt="查看数"/>{$_G[forum_thread][views]}&nbsp;&nbsp;&nbsp;
							<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="回复数"/>{$_G[forum_thread][allreplies]}
						</span>
						<span class="z">{$post[dateline]}</span>
					</li>
					<!--{/if}-->
				</ul>
            </div>
			<div class="message" {if $post['first']}style="font-size: .17rem;"{/if}>
                	<!--{if $post['warned']}-->
                        <span class="grey byg_quote">{lang warn_get}</span>
                    <!--{/if}-->
                    <!--{if !$post['first'] && !empty($post[subject])}-->
                        <h2><strong>$post[subject]</strong></h2>
                    <!--{/if}-->
                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                        <div class="grey byg_quote">{lang message_banned}</div>
                    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                        <div class="grey byg_quote">{lang message_single_banned}</div>
                    <!--{elseif $needhiddenreply}-->
                        <div class="grey byg_quote">{lang message_ishidden_hiddenreplies}</div>
                    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
						<!--{template forum/viewthread_pay}-->
					<!--{else}-->

                    	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                            <div class="grey byg_quote">{lang admin_message_banned}</div>
                        <!--{elseif $post['status'] & 1}-->
                            <div class="grey byg_quote">{lang admin_message_single_banned}</div>
                        <!--{/if}-->
                        <!--{if $post['first'] && $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                            <div class="byg_fufei_jilu cl">{lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]&mobile=2" class="y">{lang pay_view}</a></div>
                        <!--{/if}-->

                        <!--{if $post['first'] && $threadsortshow}-->
							<!--{if $threadsortshow['typetemplate'] && $_G['style']['luntan_fenlei'] == "on"}-->
								{$threadsortshow[typetemplate]}
                        	<!--{elseif $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                                <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                    {lang has_expired}
                                <!--{else}-->
									<table class="byg_sort_table">
										<caption>{$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]}</caption>
										<tbody>
										<!--{loop $threadsortshow['optionlist'] $option}-->
										<!--{if $option['type'] != 'info'}-->
											<tr>
												<th>{$option[title]}:</th>
												<td>
												<!--{if $option['value']}-->
												<!--{eval preg_match("/(".str_replace("/",'\/',$_G['setting']['attachurl']).")(.*?)((.gif)|(.jpg)|(.jpeg)|(.bmp)|(.png))/",strtolower($option['value']),$sort_img);}--> 
													<!--{if count($sort_img)}-->
													<img src="$sort_img[0]" alt="{$option[title]}"/>
													<!--{else}-->
													{$option[value]} 
													<!--{/if}-->
													<span style="color:#999;font-size:.13rem;">{$option[unit]}</span>
												<!--{else}-->
													<span style="color:#999;">-</span>
												<!--{/if}-->
												</td>
											</tr>
										<!--{/if}-->
										<!--{/loop}-->
										</tbody>
									</table>
                                <!--{/if}-->
                            <!--{/if}-->
                        <!--{/if}-->
                        
                        <!--{if $post['first']}-->
                            <!--{if !$_G[forum_thread][special]}-->
                                $post[message]
                            <!--{elseif $_G[forum_thread][special] == 1}-->
                                <!--{template forum/viewthread_poll}-->
                            <!--{elseif $_G[forum_thread][special] == 2}-->
                                <!--{template forum/viewthread_trade}-->
                            <!--{elseif $_G[forum_thread][special] == 3}-->
                                <!--{template forum/viewthread_reward}-->
                            <!--{elseif $_G[forum_thread][special] == 4}-->
                                <!--{template forum/viewthread_activity}-->
                            <!--{elseif $_G[forum_thread][special] == 5}-->
                                <!--{template forum/viewthread_debate}-->
                            <!--{elseif $threadplughtml}-->
                                $threadplughtml
                                $post[message]
                            <!--{else}-->
                            	$post[message]
                            <!--{/if}-->
                        <!--{else}-->
                            $post[message]
                        <!--{/if}-->

					<!--{/if}-->
			</div>
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
				<!--{if $post['attachment']}-->
				   <div class="grey byg_quote">
				   {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
				   </div>
				<!--{elseif $post['imagelist'] || $post['attachlist']}-->
				   <!--{if $post['imagelist']}-->
					<!--{if count($post['imagelist']) == 1}-->
					<ul class="img_one">{echo showattach($post, 1)}</ul>
					<!--{else}-->
					<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
					<!--{/if}-->
					<!--{/if}-->
					<!--{if $post['attachlist']}-->
					<ul>{echo showattach($post)}</ul>
					<!--{/if}-->
				<!--{/if}-->
			<!--{/if}-->
			
			<!--{if $post['invisible'] == 0}-->
				<!--{if $post[first] && $post['authorid']}-->
				<!--【打赏评分-开始】-->
				<div class="byg_viewthread_rate cl">
						<a href="{if $_G[uid]}forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]{else}javascript:;{/if}" onclick="return landingPrompt();" class="byg_vt_rate_t {if $_G[uid]}dialog{/if}">打赏评分</a>
					<!--{if !empty($postlist[$post[pid]]['totalrate']) && $_G['forum']['ismoderator']}-->
						<a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" class="dialog byg_vt_rate_rem">{lang removerate}</a>
					<!--{/if}-->
					<!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
						<a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" class="byg_vt_ratelog_tit">{lang number_of_participants} <!--{echo count($postlist[$post[pid]][totalrate]);}-->，查看全部</a>
						<ul class="byg_vt_ratelog_ul">
						<!--{loop $post['ratelog'] $uid $ratelog}-->
							<li>
								<a href="home.php?mod=space&uid=$uid&do=profile&mobile=2"><!--{echo avatar($uid, 'middle');}--></a>
							</li>
						<!--{/loop}-->
						</ul>
					<!--{/if}-->
				</div>
				<!--【打赏评分-结束】-->
				<!--{/if}-->
			<div id="replybtn_$post[pid]" class="replybtn reply_xin cl">
				<!--{if !$post[first]}-->
				<span class="reply_xin_dateline">{$post[dateline]}</span>
				<!--{/if}-->
				
				<!--{if $post['first'] && $post[tags] && $_GET['from'] != 'preview'}-->
				<div class="byg_post_tag z cl">
					<!--{if $post[tags]}-->
						<img src="{IMGDIR}/tag.gif" alt="tag"/>
						<!--{loop $post[tags] $var}-->
							<a href="misc.php?mod=tag&id=$var[0]&type=thread" title="$var[1]" >$var[1]</a>
						<!--{/loop}-->
					<!--{/if}-->
				</div>
				<!--{/if}-->
				
				<div class="y cl">
				<!--{if $post[first]}-->
				<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
					<!--{if !empty($_G['setting']['recommendthread']['subtracttext'])}-->
					<a href="forum.php?mod=misc&action=recommend&do=subtract&tid=$_G[tid]&hash={FORMHASH}" title="{lang makebottomonce}" onclick="zancai_ajax(this.id);return false;" id="recommend_subtract"><img src="{$_G['style']['styleimgdir']}/cai.png" alt="$_G['setting']['recommendthread'][subtracttext]" /><span id="recommendv_subtract"{if !$_G['forum_thread']['recommend_sub']} style="display:none"{/if}>{$_G[forum_thread][recommend_sub]}</span></a>
					<!--{/if}-->
					<!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
					<a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" title="{lang maketoponce}" onclick="zancai_ajax(this.id);return false;" id="recommend_add"><img src="{$_G['style']['styleimgdir']}/zan.png" alt="$_G['setting']['recommendthread'][addtext]" /><span id="recommendv_add"{if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>{$_G[forum_thread][recommend_add]}</span></a>
					<!--{/if}-->
				<!--{/if}-->
				<!--{/if}-->
				
				<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
					<a href="forum.php?mod=misc&action=postreview&do=against&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" onclick="zancai_ajax(this.id);return false;" id="cai_$post[pid]"><img src="{$_G['style']['styleimgdir']}/cai.png" alt="$_G['setting']['recommendthread'][subtracttext]" /><span id="review_against_$post[pid]">$post[postreview][against]</span></a>
					<a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" onclick="zancai_ajax(this.id);return false;" id="zan_$post[pid]"><img src="{$_G['style']['styleimgdir']}/zan.png" alt="$_G['setting']['recommendthread'][addtext]" /><span id="review_support_$post[pid]">$post[postreview][support]</span></a>
				<!--{/if}-->
				
				<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
					<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><img src="{$_G['style']['styleimgdir']}/xiugai.png" alt="{lang edit}"/></a>
				<!--{/if}-->
				
				<!--{if (!$_G['uid'] || $allowpostreply) && !$needhiddenreply}-->
					<!--{if $post['first']}-->
					<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&extra=$_GET[extra]&page=$page" onclick="return landingPrompt(2);"><img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="{lang reply}"/></a>
					<!--{else}-->
					<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" onclick="return landingPrompt(2);"><img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="{lang reply}"/></a>
					<!--{/if}-->
				<!--{/if}-->
				
				<!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
					<a href="javascript:;" onclick="setanswer($post['pid'], '$_GET[from]')">{lang reward_set_bestanswer}</a>
				<!--{/if}-->
				</div>
			</div>
			<!--{/if}-->
		</div>
	</div>
	<!--{hook/viewthread_postbottom_mobile $postcount}-->
	<!--{eval $postcount++;}-->
	
	<!--{if $post[first]}-->
		<!--{eval $forum_view_gg = byg_diy_block_sum('简约通用手机版论坛内容页广告');}-->
		<!--{if $forum_view_gg}-->
		<div class="byg_gg_viewthread">
			<div class="byg_gg">{$forum_view_gg}</div>
		</div>
		<!--{/if}-->
		
		<div class="relateitem">
		<!--{if $post['relateitem']}-->
			<!--{if $_G['style']['liebiaotu'] == "on"}-->
			<style>
				.list_img1_box .relate_thread_tit{ float: left; width: 2.22rem; min-height: .52rem; margin-bottom: .02rem;}
				.list_img1_box .list_img1{ float: right; width: 1.1rem; padding: .03rem 0;}
				.list_img1_box .list_img1 a{ width: 100%; height: .7rem; border-radius: .04rem; overflow: hidden; display: block; background-position: center center; background-repeat: no-repeat; background-size: cover; -webkit-background-size: cover;}
				.list_img1_box .relate_thread_b{ float: left; width: 2.2rem;}
			</style>
			<!--{/if}-->
			<div class="relate_thread">
				<div class="relate_thread_h3">
					<h3>相关推荐</h3>
				</div>
				<ul class="relate_thread_ul cl">
				<!--{loop $post['relateitem'] $var}-->
					<!--{eval $biaoid = substr($var[tid], -1);}-->
					<!--{eval $img_number = byg_threadlist_img_num($var[tid], $var[authorid], $biaoid);}-->
					<li class="relate_thread_li cl{if $img_number == 1 || $img_number == 2} list_img1_box{/if}">
						<div class="relate_thread_tit"><a href="forum.php?mod=viewthread&tid={$var[tid]}" class="over_two">{$var[subject]}</a></div>
						<!--{if $_G['style']['liebiaotu'] == "on"}-->
							<!--{if $img_number == 1 || $img_number == 2}-->
								<!--{eval $list_img1 = byg_threadlist_img($var[tid], $var[authorid], 1, $biaoid);}-->
								<!--{loop $list_img1 $list_img1_1}-->
								<div class="list_img1 cl">
									<a href="forum.php?mod=viewthread&tid={$var[tid]}" title="{$var[subject]}" style="background-image:url({eval echo(getforumimg($list_img1_1[aid],0,220,140))});"></a>
								</div>
								<!--{/loop}-->
							<!--{elseif $img_number > 2}-->
								<div class="list_img3 cl">
								<!--{eval $list_img3 = byg_threadlist_img($var[tid], $var[authorid], 3, $biaoid);}-->
								<!--{loop $list_img3 $list_img3_1}-->
									<div class="z">
										<a href="forum.php?mod=viewthread&tid={$var[tid]}" title="{$var[subject]}" style="background-image:url({eval echo(getforumimg($list_img3_1[aid],0,220,140))});"></a>
									</div>
								<!--{/loop}-->
								</div>
							<!--{/if}-->
						<!--{/if}-->
						<div class="relate_thread_b over_one cl">
							<!--{if $var[authorid] && $var[author]}-->
							<a href="home.php?mod=space&uid={$var[authorid]}&do=profile" class="z">{$var[author]}</a>
							<!--{else}-->
							<a href="javascript:;" class="z">{$_G[setting][anonymoustext]}</a>
							<!--{/if}-->
							<span class="z"><!--{echo dgmdate($var[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
							<span class="y">阅读{$var[views]}</span>
						</div>
					</li>
				<!--{/loop}-->
				</ul>
				<div class="relate_thread_more">查看更多</div>
			</div>
			<script type="text/javascript">
				if(jQuery(".relate_thread_li").length > 3){
					jQuery(".relate_thread_li").slice(3).hide();
					jQuery(".relate_thread_more").show();
				}
				jQuery(".relate_thread_more").click(function(){
					jQuery(".relate_thread_li").css("display","block");
					jQuery(".relate_thread_more").hide();
				});
			</script>
		<!--{/if}-->
		</div>
		
		<div class="postlist_title cl" id="fullreply">
			<h3>全部回复</h3>
			<div class="y">
				<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
					<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&authorid=$_G[forum_thread][authorid]&mobile=2#fullreply" rel="nofollow">{lang viewonlyauthorid}</a>
				<!--{elseif !$_G['forum_thread']['archiveid']}-->
					<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&mobile=2#fullreply" rel="nofollow">{lang thread_show_all}</a>
				<!--{/if}-->
				<!--{if !$rushreply}-->
					<!--{if $ordertype != 1}-->
						<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1&mobile=2#fullreply">{lang post_descview}</a>
					<!--{else}-->
						<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2&mobile=2#fullreply">{lang post_ascview}</a>
					<!--{/if}-->
				<!--{/if}-->
			</div>
		</div>
		<!--{if $_G[forum_thread][allreplies] < 1}-->
		<div class="no_reply" style="padding:.1rem;">
			<img src="{$_G['style']['styleimgdir']}/no_reply.png" alt="没有回复"/>
		</div>
		<!--{/if}-->
	<!--{/if}-->
<!--{/loop}-->
