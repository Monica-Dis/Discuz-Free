<?php echo 'From: DisM.taobao.com';exit;?>

<div class="byg_exfm cl">
	<style type="text/css">
		.byg_exfm{ margin-bottom: .05rem; padding: .05rem .1rem; border-bottom: 1px solid #eaeaea;}
		.byg_exfm_t{ margin: .1rem; color: #666; font-size: .15rem;}
		.byg_exfm_t .px{ width: 1rem; border: 1px solid #eee;}
		.byg_exfm strong{ color: #ff9800;}
		.byg_exfm .byg_quote{ font-size: .13rem;}
	</style>
	<!--{if $_GET[action] == 'newthread'}-->
		<div class="byg_exfm_t">
			<label for="rewardprice">{lang reward_price}: </label>
			<input type="text" name="rewardprice" id="rewardprice" class="px pxs" size="6" onkeyup="getrealprice(this.value)" value="{$_G['group']['minrewardprice']}" tabindex="1" />
			{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
		</div>
		<p class="byg_quote xg1">
			{lang reward_tax_after} <strong id="realprice">0</strong> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
		</p>
		<p class="byg_quote xg1">
			{lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
			<!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
			, {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
		</p>
	<!--{elseif $_GET[action] == 'edit'}-->
		<!--{if $isorigauthor}-->
			<!--{if $thread['price'] > 0}-->
				<div class="byg_exfm_t">
					<label for="rewardprice">{lang reward_price}:</label>
					<input type="text" name="rewardprice" id="rewardprice" class="px pxs" onkeyup="getrealprice(this.value)" size="6" value="$rewardprice" tabindex="1" />
					{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
				</div>
				<p class="byg_quote xg1">
					{lang reward_tax_add} <strong id="realprice">0</strong> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
				</p>
				<p class="byg_quote xg1">
					{lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
					<!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
					, {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
				</p>
			<!--{else}-->
				<p class="byg_quote xg1">{lang post_reward_resolved}</p>
				<input type="hidden" name="rewardprice" value="$rewardprice" tabindex="1" />
			<!--{/if}-->
		<!--{else}-->
			<!--{if $thread['price'] > 0}-->
				<p class="byg_quote xg1">{lang reward_price}: $rewardprice {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</p>
			<!--{else}-->
				<p class="byg_quote xg1">{lang post_reward_resolved}</p>
			<!--{/if}-->
		<!--{/if}-->
	<!--{/if}-->
	<!--{if $_G['setting']['rewardexpiration'] > 0}-->
		<p class="byg_quote xg1">$_G['setting']['rewardexpiration'] {lang post_reward_message}</p>
	<!--{/if}-->
</div>

<script type="text/javascript" reload="1">
	function getrealprice(price){
		if(!price.search(/^\d+$/) ) {
			n = Math.ceil(parseInt(price) + price * $_G['setting']['creditstax']);
			if(price > 32767) {
				document.getElementById('realprice').innerHTML = '<b>{lang reward_price_overflow}</b>';
			}<!--{if $_GET[action] == 'edit'}--> else if(price < $rewardprice) {
				document.getElementById('realprice').innerHTML = '<b>{lang reward_cant_fall}</b>';
			}<!--{/if}--> else if(price < $_G['group']['minrewardprice'] || ($_G['group']['maxrewardprice'] > 0 && price > $_G['group']['maxrewardprice'])) {
				document.getElementById('realprice').innerHTML = '<b>{lang reward_price_bound}</b>';
			} else {
				document.getElementById('realprice').innerHTML = n;
			}
		}else{
			document.getElementById('realprice').innerHTML = '<b>{lang input_invalid}</b>';
		}
	}
	if(document.getElementById('rewardprice')) {
		getrealprice(document.getElementById('rewardprice').value);
	}
</script>
