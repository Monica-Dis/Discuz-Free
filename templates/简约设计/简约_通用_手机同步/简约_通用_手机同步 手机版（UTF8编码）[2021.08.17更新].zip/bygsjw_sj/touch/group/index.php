<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="group.php">{$_G[setting][navs][3][navname]}</a>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y"><img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<style type="text/css">
	.byg_group_box{ margin: .1rem 0; padding: 0 .1rem; background: #fff;}
	.byg_group_box_h2{ height: .42rem; margin-bottom: .01rem; border-bottom: .01rem solid #eee;}
	.byg_group_box_h2 h2{ display: inline-block; height: .3rem; line-height: .3rem; padding: .07rem .04rem .04rem; font-size: .15rem; font-weight: 700; border-bottom: .02rem solid $_G['style']['zhuti'];}
	.byg_group_box_h2 .y{ height: .42rem; line-height: .42rem; font-size: .14rem;}
	.byg_group_rec a{ display: block; height: .4rem; padding: .12rem .23rem .12rem 0; border-bottom: 1px dashed #eaeaea; background: #fff url({$_G['style']['styleimgdir']}/jinru.png) no-repeat right center; background-size: .16rem; overflow: hidden;}
	.byg_group_rec img{ width: .4rem; height: .4rem; border-radius: .04rem;}
	.byg_group_rec h3{ width: 2.85rem; height: .24rem; line-height: .24rem; font-size: .15rem; overflow: hidden;}
	.byg_group_rec span{ width: 2.85rem; height: .15rem; line-height: .15rem; overflow: hidden; font-size: .12rem; color: #999;}
	.byg_group_all_dl{ border-bottom: 1px dashed #eaeaea;}
	.byg_group_all_dt{ position: relative; height: .22rem; line-height: .22rem; margin: .15rem 0; padding: 0 .4rem 0 .02rem; font-size: .15rem; overflow: hidden;}
	.byg_group_all_dt .byg_group_all_gid{ font-weight: 700;}
	.byg_group_all_dt .byg_group_all_sgid{ height: .2rem; line-height: .22rem; margin-right: .06rem; padding: 0 .06rem; border: 1px solid #ddd; border-radius: .11rem; font-size: .13rem; color: #888; display: inline-block;}
	.byg_group_all_dt .byg_group_all_more{ position: absolute; top: 0; right: 0; font-size: .12rem; color: #666;}
	.byg_group_all_dd{ width: 3.65rem; padding-bottom: .04rem;}
	.byg_group_all_dd a{ float: left; width: 1.5rem; height: .34rem; line-height: .34rem; margin: 0 .1rem .12rem 0; padding: 0 .1rem; background: #fcfcfc; font-size: .14rem; color: #666; overflow: hidden; border: .01rem solid #f1f1f1; border-radius: .04rem;}
</style>

<div class="byg_group_box">
	<div class="byg_group_box_h2 cl">
		<h2>{lang recommend_group}</h2>
		<a href="group.php?mod=my" onclick="return landingPrompt();" class="y">{lang my_group}&rsaquo;</a>
	</div>
	<div class="byg_group_rec">
		<!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->
		<a href="forum.php?mod=group&fid=$val[fid]" title="$val[name]" class="cl">
			<img src="$val[icon]" alt="$val[name]" class="z" />
			<h3 class="y">$val[name]</h3>
			<span class="y">$val[description]</span>
		</a>
		<!--{/loop}-->
	</div>
</div>

<div class="byg_group_box">
	<div class="byg_group_box_h2 cl">
		<h2>{lang group_categories}</h2>
		<!--{if helper_access::check_module('group')}-->
			<!--{if empty($gid) && empty($sgid)}-->
			<a href="forum.php?mod=group&action=create" onclick="return landingPrompt();" title="{lang group_create}" class="y">{lang group_create}&rsaquo;</a>
			<!--{else}-->
			<a href="forum.php?mod=group&action=create&fupid=$fup&groupid=$sgid" onclick="return landingPrompt();" title="{lang group_create}" class="y">{lang group_create}&rsaquo;</a>
			<!--{/if}-->
		<!--{/if}-->
	</div>
	<div class="byg_group_all cl">
		<!--{loop $first $groupid $group}-->
		<dl class="byg_group_all_dl">
			<dt class="byg_group_all_dt cl">
				<a href="group.php?gid=$groupid" class="byg_group_all_gid">$group[name]</a>：<!--{loop $group['secondlist'] $fid}--><a href="group.php?sgid=$fid" class="byg_group_all_sgid">$second[$fid][name]</a><!--{/loop}--><a href="group.php?gid=$groupid" class="byg_group_all_more">{lang more}&rsaquo;</a>
			</dt>
			<dd class="byg_group_all_dd cl">
			<!--{loop $lastupdategroup[$groupid] $val}-->
				<a href="forum.php?mod=group&fid=$val[fid]">$val[name]</a>
			<!--{/loop}-->
			</dd>
		</dl>
		<!--{/loop}-->
	</div>
</div>

<!--{template common/footer}-->
