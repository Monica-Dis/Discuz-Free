<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="group.php?mod=index">{$_G[setting][navs][3][navname]}</a>
			<em>&rsaquo;</em>
			<a href="group.php?mod=my">{$_G[username]}{lang somebody_group}</a>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y"><img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<style type="text/css">
	.byg_group_box{ margin: .1rem 0; padding: 0 .1rem; background: #fff;}
	.byg_group_box_h2{ height: .42rem; margin-bottom: .01rem; border-bottom: .01rem solid #eee;}
	.byg_group_box_h2 h2{ display: inline-block; height: .3rem; line-height: .3rem; padding: .07rem .04rem .04rem; font-size: .15rem; font-weight: 700; border-bottom: .02rem solid $_G['style']['zhuti'];}
	
	.byg_group_attentiongroup .attgroup{ padding: .15rem 0 .05rem;}
	.group_attentiongroup_t{ border-bottom: 1px dashed #eaeaea;}
	.byg_group_attentiongroup li{ float: left; margin: 0 .1rem .1rem 0;}
	.byg_group_attentiongroup li label{ display: inline-block; padding: .04rem .08rem; background: #fafafa; font-size: .14rem; vertical-align: top; border-radius: .04rem; border: 1px solid #eee;}
	.group_attentiongroup_smt{ padding: .13rem 0; border-top: 1px solid #eee;}
	.group_attentiongroup_smt button{ width: 100%; height: .4rem; line-height: .4rem; border-radius: .06rem; font-size: .16rem; display: block; text-align: center;}
</style>
<div class="forumdisplay_tab">
	<div class="swiper-wrapper">
		<a href="group.php?mod=attentiongroup" class="swiper-slide on">{lang attention_group}</a>
		<a href="group.php?mod=my&view=groupthread" class="swiper-slide">{lang group_thread}</a>
		<a href="group.php?mod=my&view=mythread" class="swiper-slide">{lang my_thread}</a>
		<a href="group.php?mod=my&view=join" class="swiper-slide">{lang my_join}</a>
		<a href="group.php?mod=my&view=manager" class="swiper-slide">{lang my_manage}</a>
	</div>
</div>
<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
<script type="text/javascript">
	var forumdisplay_tab = new Swiper('.forumdisplay_tab', {
		slidesPerView : 'auto',
		freeMode : true,
	});
</script>
<div class="byg_group_box">
	<div class="byg_group_box_h2 cl">
		<h2>{lang select_focus_group}</h2>
	</div>
	<form method="post" autocomplete="off" id="attentionform" name="attentionform" action="group.php?mod=attentiongroup">
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="byg_group_attentiongroup cl">
			<div class="group_attentiongroup_t attgroup cl">
				<ul class="cl">
				<!--{loop $usergroups['groups'] $groupid $groupname}-->
					<!--{if in_array($groupid, $attentiongroup)}-->
					<li id="li$groupid"><label for="attentiongroupid_$groupid"><input type="checkbox" name="attentiongroupid[]" id="attentiongroupid_$groupid" class="pc" value="$groupid" checked="checked" onclick="attention_checkbox(this, 'attentionform', 'attentiongroupid', 5)" />$groupname</label></li>
					<!--{/if}-->
				<!--{/loop}-->
					<li id="heightline"></li>
				</ul>
			</div>
			<div class="group_attentiongroup_b attgroup cl">
				<ul class="cl">
					<!--{loop $usergroups['groups'] $groupid $groupname}-->
						<!--{if !in_array($groupid, $attentiongroup)}-->
						<li id="li$groupid"><label for="attentiongroupid_$groupid"><input type="checkbox" name="attentiongroupid[]" id="attentiongroupid_$groupid" class="pc" value="$groupid" onclick="attention_checkbox(this, 'attentionform', 'attentiongroupid', 5)" />$groupname</label></li>
						<!--{/if}-->
					<!--{/loop}-->
					<li id="lowerline"></li>
				</ul>
			</div>
		</div>
		<p class="group_attentiongroup_smt">
			<input type="hidden" name="attentionsubmit" value="true" />
			<button type="submit" class="">{lang confirms}</button>
		</p>
		<script language="javascript">
			var p = $counttype;
			function attention_checkbox(obj, formid, checkname, max_obj) {
				if(obj.checked) {
					p++;
					for (var i = 0; i < document.getElementById(formid).elements.length; i++) {
						var e = document.getElementById(formid).elements[i];
						if(p == max_obj+1) {
							if(e.name.match(checkname) && !e.checked) {
								e.disabled = true;
							}
						}
					}
				} else {
					p--;
					for (var i = 0; i < document.getElementById(formid).elements.length; i++) {
						var e = document.getElementById(formid).elements[i];
						if(e.name.match(checkname) && e.disabled) {
							e.disabled = false;
						}
					}
				}
				if(p > max_obj) {
					p--;
					obj.checked = false;
					alert('{lang max_can_select}'+max_obj+'{lang unit}.');
					return;
				}
				var oldNode = document.getElementById('li'+obj.value);
				var realvalue = obj.checked;
				if(obj.checked) {
					var line = document.getElementById('heightline');
				} else {
					var line = document.getElementById('lowerline');
				}
				oldNode.parentNode.removeChild(oldNode);
				line.parentNode.insertBefore(oldNode,line);
				obj.checked = realvalue;
			}
		</script>
	</form>
</div>

<!--{template common/footer}-->
