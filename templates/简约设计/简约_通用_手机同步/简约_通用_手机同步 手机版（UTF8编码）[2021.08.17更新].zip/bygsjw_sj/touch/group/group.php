<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="group.php">{$_G[setting][navs][3][navname]}</a>
			<!--{if $groupnav}-->
				{$groupnav}
			<!--{elseif $action == 'create'}-->
				<em>&rsaquo;</em><span>{lang group_create}</span>
			<!--{/if}-->
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y"><img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--{if $action != 'create'}-->
	<style type="text/css">
		#uhd{ position: relative; background: $_G['style']['zhuti']; overflow: hidden;}
		#uhd_bg{ position: relative; z-index: 1; width: 3.75rem; height: 1rem; overflow: hidden; margin-top: -20px;}
		.home_forum_header_js{ background: #fff !important; opacity: 0.1 !important; border-radius: 10% !important;}
		.uhd_content{ position: absolute; top: 0; left: 0; z-index: 10; width: 100%; padding: .15rem 0 .1rem;}
		.uhd_avatar{ margin: 0 0 .1rem .1rem; vertical-align: top; height: .5rem; width: .5rem; border-radius: .05rem; box-shadow: 1px 2px 2px rgba(0, 0, 0, 0.3);}
		.uhd_top_y{ width: 3.05rem;}
		.uhd_name{ line-height: .26rem; padding-right: .06rem; color: #fff; text-shadow: 1px 1px 1px #000;}
		.uhd_name a{ height: .22rem; line-height: .22rem; margin: .02rem .06rem; padding: 0 .05rem; background: rgba(0,0,0,.2); border-radius: .04rem; color: #fff; font-size: .12rem; vertical-align: top; text-shadow: none;}
		.uhd_name img{ margin: .03rem .02rem 0 0; height: .16rem; vertical-align: top;}
		.uhd_top_y_b{ margin: .05rem .1rem 0 0; font-size: .12rem; color: #fff; text-shadow: 1px 1px 1px #222;}
		.uhd_top_y_b span{ margin: 0 .08rem;}
		.uhd_description{ margin: .1rem; padding: .04rem .08rem; background: rgba(255,255,255,0.5); border-radius: .04rem; font-size: .14rem; color: #555; display: inline-block;}
	</style>
	<div id="uhd">
		<div id="uhd_bg"></div>
		<div class="uhd_content">
			<div class="uhd_top cl">
				<img src="$_G[forum][icon]" alt="$_G[forum][name]" class="uhd_avatar z" />
				<div class="uhd_top_y y">
					<div class="uhd_name cl">
						{$_G[forum][name]}
						<a href="home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}" class="dialog y"><img src="{$_G['style']['styleimgdir']}/bai_shoucang.png" alt="{lang favorite}" />{lang favorite}</a>
						<!--{if $status == 'isgroupuser'}--><a href="javascript:;" onclick="popup.open('{lang group_exit_confirm}', 'confirm','forum.php?mod=group&action=out&fid=$_G[fid]');" class="y"><img src="{$_G['style']['styleimgdir']}/bl_tuichu.png" alt="退出退组" />退出</a>
						<!--{elseif $status == 3 || $status == 5}-->
						<a href="javascript:;" class="y">待审核</a>
						<!--{elseif helper_access::check_module('group')}-->
						<a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="dialog y"><img src="{$_G['style']['styleimgdir']}/bl_zhuce.png" alt="加入群组" />加入</a>
						<!--{/if}-->
					</div>
					<p class="uhd_top_y_b">{lang posts}&nbsp;{$_G[forum][posts]}<span>/</span>{lang member}&nbsp;{$_G[forum][membernum]}<span>/</span>{lang credits}&nbsp;{$_G[forum][commoncredits]}<span>/</span>{lang group_member_rank}&nbsp;{$groupcache[ranking][data][today]}</p>
				</div>
			</div>
			<!--{if $_G[forum][description]}-->
			<div class="uhd_description">$_G[forum][description]</div>
			<!--{/if}-->
		</div>
	</div>
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/home_forum_header.js"></script>
	<script type="text/javascript">
		jQuery('#uhd').height(jQuery('.uhd_content').innerHeight());
		jQuery('#uhd_bg').height(jQuery('.uhd_content').innerHeight() + 20);
		jQuery.firefly({
			minPixel: 4,
			maxPixel: 40,
			total : 20,
			on: '#uhd_bg',
			namespace: 'home_forum_header_js'
		});
	</script>
	<!--{if $status != 2 && $status != 3}-->
	<div class="forumdisplay_tab">
		<a href="forum.php?mod=group&fid=$_G[fid]" {if $action == 'index'}class="on"{/if}>{lang home}</a>
		<a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]" {if $action == 'list'}class="on"{/if}>{lang group_discuss_area}</a>
		<a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]" {if $action == 'memberlist' || $action == 'invite'}class="on"{/if}>{lang group_member_list}</a>
		<!--{if $_G['forum']['ismoderator']}--><a href="forum.php?mod=group&action=manage&fid=$_G[fid]" {if $action == 'manage'}class="on"{/if}>{lang group_admin}</a><!--{/if}-->
	</div>
	<!--{/if}-->
<!--{/if}-->

<!--{if $action == 'index' && $status != 2 && $status != 3}-->
	<!--{subtemplate group/group_index}-->
<!--{elseif $action == 'list'}-->
	<!--{subtemplate group/group_list}-->
<!--{elseif $action == 'memberlist'}-->
	<!--{subtemplate group/group_memberlist}-->
<!--{elseif $action == 'create'}-->
	<!--{subtemplate group/group_create}-->
<!--{elseif $action == 'manage'}-->
	<!--{subtemplate group/group_manage}-->
<!--{elseif $action == 'invite'}-->
	<!--{subtemplate group/group_invite}-->
<!--{/if}-->

<!--{template common/footer}-->
