<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_sj/touch/php/forum_forumdisplay_list.php');}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="group.php?mod=index">{$_G[setting][navs][3][navname]}</a>
			<em>&rsaquo;</em>
			<a href="group.php?mod=my">{$_G[username]}{lang somebody_group}</a>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y"><img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<style type="text/css">
	.forumdisplay_tab{ margin: 0; border: 0;}
	
	.byg_group_box{ margin: .1rem 0; padding: 0 .1rem; background: #fff;}
	.byg_group_box_h2{ height: .42rem; margin-bottom: .01rem; border-bottom: .01rem solid #eee;}
	.byg_group_box_h2 h2{ display: inline-block; height: .3rem; line-height: .3rem; padding: .07rem .04rem .04rem; font-size: .15rem; font-weight: 700; border-bottom: .02rem solid $_G['style']['zhuti'];}
	.byg_group_box_h2 .y{ height: .42rem; line-height: .42rem; font-size: .13rem;}
	
	.byg_group_box .byg_threadlist{ margin: 0;}
	.byg_group_box .threadlist li{ margin: 0; border-bottom: 1px solid #f1f1f1;}
	.byg_group_box .threadlist .list_top{ padding: .1rem 0 .04rem;}
	.byg_group_box .threadlist .list_img3{ padding-left: 0; width: 3.62rem;}
	.byg_group_box .list_bottom{ margin: 0 0 .1rem;}
	.byg_group_box .list_bottom .byg_groupname{ line-height: .2rem; padding: 0 .05rem; border: .01rem solid #f1f1f1; border-radius: .02rem; background: #fcfcfc;}
	
	<!--{if $_G['style']['liebiaotu'] == "on"}-->
	.list_img1_box .list_top{ float: left; width: 2.32rem; height: .44rem; margin-bottom: .06rem; padding-right: 0; overflow: hidden;}
	.list_img1_box .list_img1{ float: right; width: 1.15rem; padding: .1rem 0;}
	.list_img1_box .list_img1 a{ width: 100%; height: .76rem; padding: 0; border-radius: .04rem; overflow: hidden; display: block; background-position: center center; background-repeat: no-repeat; background-size: cover; -webkit-background-size: cover;}
	.list_img1_box .list_bottom{ float: left; width: 2.28rem;}
	<!--{/if}-->
	
	.byg_group_box .home_no_data{ margin: 0;}
	
	.group_my_join_list a{ display: block; padding: .12rem .3rem .12rem 0; line-height: .3rem; border-bottom: 1px dashed #eaeaea; background: #fff url({$_G['style']['styleimgdir']}/jinru.png) no-repeat right center; background-size: .16rem; font-size: .15rem;}
	.group_my_join_list img{ margin: 0 .05rem 0 .03rem; height: .3rem; width: .3rem; vertical-align: top; border-radius: .04rem;}
</style>

<div class="forumdisplay_tab">
	<div class="swiper-wrapper">
		<a href="group.php?mod=attentiongroup" class="swiper-slide">{lang attention_group}</a>
		<a href="group.php?mod=my&view=groupthread" class="swiper-slide {if $_GET['view'] == 'groupthread' || !$_GET['view']}on{/if}">{lang group_thread}</a>
		<a href="group.php?mod=my&view=mythread" class="swiper-slide {if $_GET['view'] == 'mythread'}on{/if}">{lang my_thread}</a>
		<a href="group.php?mod=my&view=join" class="swiper-slide {if $_GET['view'] == 'join'}on{/if}">{lang my_join}</a>
		<a href="group.php?mod=my&view=manager" class="swiper-slide {if $_GET['view'] == 'manager'}on{/if}">{lang my_manage}</a>
	</div>
</div>
<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
<script type="text/javascript">
	if(jQuery(".forumdisplay_tab .on").length > 0) {
		var tab_initial = jQuery(".forumdisplay_tab .on").offset().left + jQuery(".forumdisplay_tab .on").width() + 20 >= jQuery(window).width() ? jQuery(".forumdisplay_tab .on").index() : 0;
	}else{
		var tab_initial = 0;
	}
	var forumdisplay_tab = new Swiper('.forumdisplay_tab', {
		initialSlide : tab_initial,
		slidesPerView : 'auto',
		freeMode : true,
	});
</script>


<!--{if $view == 'groupthread' || $view == 'mythread'}-->
	<div class="byg_thread_types">
		<ul class="swiper-wrapper">
			<li id="ttp_all" class="swiper-slide{if empty($typeid)} a{/if}"><a href="group.php?mod=my&view=$view">{lang all}</a></li>
		<!--{loop $usergroups['grouptype'] $type}-->
			<li class="swiper-slide{if $typeid == $type['fid']} a{/if}"><a href="group.php?mod=my&view=$view{if $typeid != $type['fid']}&typeid=$type[fid]{/if}">$type[name]</a></li>
		<!--{/loop}-->
		</ul>
	</div>
	<script type="text/javascript">
		if(jQuery(".byg_thread_types .a").length > 0) {
			var tab_initial = jQuery(".byg_thread_types .a").offset().left + jQuery(".byg_thread_types .a").width() + 20 >= jQuery(window).width() ? jQuery(".byg_thread_types .a").index() : 0;
		}else{
			var tab_initial = 0;
		}
		var byg_thread_types = new Swiper('.byg_thread_types', {
			initialSlide : tab_initial,
			slidesPerView : 'auto',
			freeMode : true,
		});
	</script>

	<!--{if $attentionthread}-->
		<!--{loop $attentionthread $groupid $threads}-->
		<div class="byg_group_box">
			<div class="byg_group_box_h2 cl">
				<h2>{$usergroups['groups'][$groupid]}</h2>
				<a href="forum.php?mod=group&fid=$groupid" class="y">{lang more}&rsaquo;</a>
			</div>
			<ul class="threadlist byg_threadlist">
			<!--{loop $threads $tid $thread}-->
				<!--{eval $biaoid = substr($tid, -1);}-->
				<!--{eval $thread_authorid = byg_thread_authorid($tid);}-->
				<!--{eval $img_number = byg_threadlist_img_num($tid, $thread_authorid, $biaoid);}-->
				<li class="cl{if $img_number == 1 || $img_number == 2} list_img1_box{/if}">
					<div class="list_top cl">	
						<a href="forum.php?mod=viewthread&tid=$tid" class="over_two">
						<!--{if $thread[folder] == 'lock'}-->
							<img src="{IMGDIR}/folder_lock.gif" alt="锁定" />
						<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
							<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
						<!--{else}-->
							<img src="{IMGDIR}/folder_$thread[folder].gif" alt="普通" />
						<!--{/if}-->
						{$thread[subject]}</a>
					</div>
					<!--{if $_G['style']['liebiaotu'] == "on"}-->
						<!--{if $img_number == 1 || $img_number == 2}-->
							<!--{eval $list_img1 = byg_threadlist_img($tid, $thread_authorid, 1, $biaoid);}-->
							<!--{loop $list_img1 $list_img1_1}-->
							<div class="list_img1 cl">
								<a href="forum.php?mod=viewthread&tid=$tid" style="background-image:url({eval echo(getforumimg($list_img1_1[aid],0,230,150))});"></a>
							</div>
							<!--{/loop}-->
						<!--{elseif $img_number > 2}-->
							<ul class="list_img3 cl">
							<!--{eval $list_img3 = byg_threadlist_img($tid, $thread_authorid, 3, $biaoid);}-->
							<!--{loop $list_img3 $list_img3_1}-->
								<li>
									<a href="forum.php?mod=viewthread&tid=$tid" style="background-image:url({eval echo(getforumimg($list_img3_1[aid],0,230,150))});"></a>
								</li>
							<!--{/loop}-->
							</ul>
						<!--{/if}-->
					<!--{/if}-->
					<div class="list_bottom cl">
						<em class="z">{$thread[lastpost]}&nbsp;&nbsp;</em>
						<span class="y">
							<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="回复数"/>{$thread[replies]}
						</span>
						<span class="y">
							<img src="{$_G['style']['styleimgdir']}/chakan.png" alt="查看数"/>{$thread[views]}&nbsp;&nbsp;
						</span>
					</div>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
		<!--{/loop}-->
	<!--{/if}-->
	
	<div class="byg_group_box">
		<div class="byg_group_box_h2 cl">
			<h2><!--{if $view == 'groupthread'}-->{lang last_topic_in_group}<!--{else}-->{lang my_last_topic_in_group}<!--{/if}--></h2>
		</div>
		<!--{if $groupthreadlist}-->
		<ul class="threadlist byg_threadlist">
		<!--{loop $groupthreadlist $tid $thread}-->
			<!--{eval $biaoid = substr($tid, -1);}-->
			<!--{eval $thread_authorid = byg_thread_authorid($tid);}-->
			<!--{eval $img_number = byg_threadlist_img_num($tid, $thread_authorid, $biaoid);}-->
			<li class="cl{if $img_number == 1 || $img_number == 2} list_img1_box{/if}">
				<div class="list_top cl">	
					<a href="forum.php?mod=viewthread&tid=$tid" class="over_two">
					<!--{if $thread[folder] == 'lock'}-->
						<img src="{IMGDIR}/folder_lock.gif" alt="锁定" />
					<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
						<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
					<!--{else}-->
						<img src="{IMGDIR}/folder_$thread[folder].gif" alt="普通" />
					<!--{/if}-->
					{$thread[subject]}</a>
				</div>
				<!--{if $_G['style']['liebiaotu'] == "on"}-->
					<!--{if $img_number == 1 || $img_number == 2}-->
						<!--{eval $list_img1 = byg_threadlist_img($tid, $thread_authorid, 1, $biaoid);}-->
						<!--{loop $list_img1 $list_img1_1}-->
						<div class="list_img1 cl">
							<a href="forum.php?mod=viewthread&tid=$tid" style="background-image:url({eval echo(getforumimg($list_img1_1[aid],0,230,150))});"></a>
						</div>
						<!--{/loop}-->
					<!--{elseif $img_number > 2}-->
						<ul class="list_img3 cl">
						<!--{eval $list_img3 = byg_threadlist_img($tid, $thread_authorid, 3, $biaoid);}-->
						<!--{loop $list_img3 $list_img3_1}-->
							<li>
								<a href="forum.php?mod=viewthread&tid=$tid" style="background-image:url({eval echo(getforumimg($list_img3_1[aid],0,230,150))});"></a>
							</li>
						<!--{/loop}-->
						</ul>
					<!--{/if}-->
				<!--{/if}-->
				<div class="list_bottom cl">
					<a href="forum.php?mod=group&fid=$thread[fid]" class="z byg_groupname">{$thread[groupname]}</a>
					<span class="y">
						<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="回复数"/>{$thread[replies]}
					</span>
					<span class="y">
						&nbsp;&nbsp;<img src="{$_G['style']['styleimgdir']}/chakan.png" alt="查看数"/>{$thread[views]}&nbsp;&nbsp;
					</span>
				</div>
			</li>
			<!--{/loop}-->
		</ul>
		<!--{else}-->
		<div class="home_no_data">{lang no_related_posts}</div>
		<!--{/if}-->
	</div>
	<!--{if $multipage}-->$multipage<!--{/if}-->

<!--{elseif $view == 'manager' || $view == 'join'}-->
	<!--{if $grouplist}-->
		<div class="byg_group_box">
			<div class="byg_group_box_h2 cl">
				<h2><!--{if $view == 'manager'}-->{lang my_manage_group} <!--{elseif $view == 'join'}-->{lang my_join_group} <!--{/if}--></h2>
			</div>
			<div class="group_my_join_list">
				<ul class="cl">
					<!--{loop $grouplist $groupid $group}-->
					<li>
						<a href="forum.php?mod=group&fid=$groupid" title="$group[name]"><img src="$group[icon]" alt="$group[name]" />
						<!--{if $group['flevel'] == '-1'}-->({lang group_wait_mod})<!--{/if}-->{$group[name]}</a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		<!--{if $multipage}-->$multipage<!--{/if}-->
	<!--{else}-->
		<div class="home_no_data"><!--{if $view == 'manager'}-->{lang no_group_create_now} <!--{elseif $view == 'join'}-->{lang no_group_join} <!--{/if}--></div>
	<!--{/if}-->
<!--{/if}-->

<!--{template common/footer}-->
