<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="group.php">{$_G[setting][navs][3][navname]}</a>$groupnav
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y"><img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<style type="text/css">
	.byg_group_box{ margin: .1rem 0; padding: 0 .1rem; background: #fff;}
	.byg_group_box_h2{ height: .42rem; margin-bottom: .01rem; border-bottom: .01rem solid #eee;}
	.byg_group_box_h2 h2{ display: inline-block; height: .3rem; line-height: .3rem; padding: .07rem .04rem .04rem; font-size: .15rem; font-weight: 700; border-bottom: .02rem solid $_G['style']['zhuti'];}
	.byg_group_box_h2 .y{ height: .42rem; line-height: .42rem; font-size: .14rem;}
	.byg_thread_types{ padding-bottom: .14rem; border-top: 0; border-bottom: 1px solid #eee;}
	.byg_group_box .tbmu{ padding: .1rem 0; border-bottom: 1px dashed #eaeaea; font-size: .13rem; color: #999;}
	.byg_group_box .tbmu select{ background-color: #fcfcfc; border-color: #eee; color: #888; border-radius: 2px;}
	.byg_group_rec a{ display: block; height: .4rem; padding: .12rem .23rem .12rem 0; border-bottom: 1px dashed #eaeaea; background: #fff url({$_G['style']['styleimgdir']}/jinru.png) no-repeat right center; background-size: .16rem; overflow: hidden;}
	.byg_group_rec img{ width: .4rem; height: .4rem; border-radius: .04rem;}
	.byg_group_rec h3{ width: 2.85rem; height: .24rem; line-height: .24rem; font-size: .15rem; overflow: hidden;}
	.byg_group_rec span{ width: 2.85rem; height: .15rem; line-height: .15rem; overflow: hidden; font-size: .12rem; color: #999;}
	.byg_group_box .home_no_data{ margin: 0;}
</style>

<div class="byg_group_box">
	<div class="byg_group_box_h2 cl">
		<h2>$curtype[name]</h2>
		<!--{if helper_access::check_module('group')}-->
			<!--{if empty($gid) && empty($sgid)}-->
			<a href="forum.php?mod=group&action=create" onclick="return landingPrompt();" title="{lang group_create}" class="y">{lang group_create}&rsaquo;</a>
			<!--{else}-->
			<a href="forum.php?mod=group&action=create&fupid=$fup&groupid=$sgid" onclick="return landingPrompt();" title="{lang group_create}" class="y">{lang group_create}&rsaquo;</a>
			<!--{/if}-->
		<!--{/if}-->
	</div>
	<!--{if $typelist}-->
		<div class="byg_thread_types">
			<ul class="swiper-wrapper">
			<!--{loop $typelist $fid $type}-->
				<li class="swiper-slide"><a href="group.php?sgid=$fid">{$type[name]}<!--{if $type[groupnum]}--><span class="num">($type[groupnum])</span><!--{/if}--></a></li>
			<!--{/loop}-->
			</ul>
		</div>
		<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
		<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
		<script type="text/javascript">
			if(jQuery(".byg_thread_types .a").length > 0) {
				var tab_initial = jQuery(".byg_thread_types .a").offset().left + jQuery(".byg_thread_types .a").width() + 20 >= jQuery(window).width() ? jQuery(".byg_thread_types .a").index() : 0;
			}else{
				var tab_initial = 0;
			}
			var byg_thread_types = new Swiper('.byg_thread_types', {
				initialSlide : tab_initial,
				slidesPerView : 'auto',
				freeMode : true,
			});
		</script>
	<!--{/if}-->
	<!--{if $list}-->
		<div class="tbmu cl">
			<span class="y">
			<select title="{lang orderby}" onchange="location.href=this.value">
				<option value="$url" $selectorder[default]>{lang orderby_default}</option>
				<option value="$url&orderby=thread" $selectorder[thread]>{lang stats_main_threads_count}</option>
				<option value="$url&orderby=membernum" $selectorder[membernum]>{lang group_member_count}</option>
				<option value="$url&orderby=dateline" $selectorder[dateline]>{lang group_create_time}</option>
				<option value="$url&orderby=activity" $selectorder[activity]>{lang group_activities}</option>
			</select>
			</span>
			{lang group_total_numbers}
		</div>
		<div class="byg_group_rec">
			<!--{loop $list $fid $val}-->
			<a href="forum.php?mod=group&fid=$fid" title="$val[name]" class="cl">
				<img src="$val[icon]" alt="$val[name]" class="z" />
				<h3 class="y">$val[name]</h3>
				<span class="y">成员：{$val[membernum]}&nbsp;&nbsp;&nbsp;主题：{$val[threads]}</span>
			</a>
			<!--{/loop}-->
		</div>
		<!--{if $multipage}-->$multipage<!--{/if}-->
	<!--{else}-->
		<div class="home_no_data">{lang group_category_no_groups}</div>
	<!--{/if}-->
</div>

<!--{template common/footer}-->
