<?php echo 'From: DisM.taobao.com';exit;?>

<style type="text/css">
	.byg_thread_types{ border-bottom: 1px solid #eee;}
	.byg_group_box{ margin: .1rem 0; padding: 0 .1rem; background: #fff;}
	.byg_group_box_h2{ height: .42rem; margin-bottom: .01rem; border-bottom: .01rem solid #eee;}
	.byg_group_box_h2 h2{ display: inline-block; height: .3rem; line-height: .3rem; padding: .07rem .04rem .04rem; font-size: .15rem; font-weight: 700; border-bottom: .02rem solid $_G['style']['zhuti'];}
	
	.group_manage_group{ background: #fff;}
	.group_manage_group table{ table-layout: fixed; width: 100%; overflow: hidden; font-size: .14rem;}
	.group_manage_group tr{ width: 100%; line-height: .2rem; border-bottom: 1px solid #eee;}
	.group_manage_group th{ width: .7rem; padding: .1rem; background: #fcfcfc; color: #666;}
	.group_manage_group td{ padding: .1rem; border-left: 1px solid #eee;}
	.group_manage_group .input_text{ height: .2rem; line-height: .2rem; padding: .02rem .05rem; border: 1px solid #eaeaea; border-radius: .04rem; vertical-align: top; font-size: .14rem; color: #444;}
	.group_manage_group select{ padding: .02rem; background-color: #fff; border-color: #eaeaea; color: #444; font-size: .14rem; border-radius: .04rem;}
	.group_manage_group .input_textarea{ width: 96%; padding: .02rem 2%; font-size: .14rem; border: 0; box-shadow: 0 0 0 1px #eee; color: #444; vertical-align: top;}
	.group_manage_group label{ display: block; margin: .02rem; font-size: .14rem;}
	.group_manage_group .input_text2{ width: .5rem; height: .14rem; line-height: .14rem; margin: 0 .02rem; padding: .02rem .05rem; border: 1px solid #eaeaea; border-radius: .04rem; vertical-align: top; font-size: .13rem; color: #444;}
	.group_manage_group .input_text2_p{ line-height: 1.3; margin-top: .05rem; font-size: .12rem; color: #999;}
	.group_manage_group_smt{ padding: .11rem;}
	.group_manage_group_smt button{ width: 100%; height: .4rem; line-height: .4rem; border-radius: .06rem; font-size: .16rem; display: block; text-align: center;}
	
	.group_manage_checkuser_t{ padding: .08rem .1rem; background: #fff; font-size: .14rem;}
	.group_manage_checkuser_t .pipe{ margin: 0 .08rem 0 .12rem; color: #ccc;}
	.group_manage_checkuser dl{ position: relative; padding: .11rem 0; border-top: 1px solid #eee; background: #fff;}
	.group_manage_checkuser .z img{ margin: 0 .1rem; width: .4rem; height: .4rem; vertical-align: top; border-radius: 50%;}
	.group_manage_checkuser dt{ line-height: .22rem; padding-right: 1.1rem; font-size: .15rem;}
	.group_manage_checkuser dt p{ line-height: .18rem; font-size: .12rem;}
	.group_manage_checkuser .b{ position: absolute; right: .11rem; top: .21rem; line-height: .2rem;}
	.group_manage_checkuser .b button{ padding: .01rem .06rem; vertical-align: top; font-size: .12rem;}
	
	.group_manage_manageuser_search{ margin-bottom: .1rem; padding: .12rem .1rem; background: #fff;}
	.group_manage_manageuser_search .z{ width: 2.8rem; padding: .04rem .08rem; line-height: .22rem; border: .01rem solid #eaeaea; color: #444; font-size: .14rem; border-radius: .04rem;}
	.group_manage_manageuser_search .y{ line-height: .32rem; padding: 0 .1rem; border-radius: .04rem;}
	.group_manage_manageuser_list li{ position: relative; display: block; padding: .12rem .3rem .12rem 0; line-height: .3rem; border-bottom: 1px dashed #eaeaea; background: #fff; background-size: .16rem; font-size: .15rem;}
	.group_manage_manageuser_list a img{ margin: 0 .05rem 0 .03rem; height: .3rem; width: .3rem; vertical-align: top; border-radius: 50%;}
	.group_manage_manageuser_list a span{ display: inline-block; line-height: .18rem; margin: .06rem .04rem; padding: 0 .05rem; background: $_G['style']['zhuti']; color: #fff; font-size: .12rem; border-radius: .04rem;}
	.group_manage_manageuser_list input{ position: absolute; top: .21rem; right: .08rem;}
	.group_manage_manageuser_b{ margin: .1rem 0; padding: .1rem .05rem; background: #fff; text-align: center;}
	.group_manage_manageuser_b button{ line-height: .2rem; margin: .04rem 0; padding: .02rem .06rem; font-size: .12rem; vertical-align: top; border-radius: .04rem;}
	
	.group_manage_group .threadtype_turn_on th{ width: .95rem;}
	.threadtypes_manage h2{ display: block; padding: .1rem; font-size: .15rem; font-weight: 700; border-bottom: 1px solid #eee;}
	.threadtypes_manage .threadtypes_manage_th{ width: .1rem; border-right: 1px solid #eee;}
	.threadtypes_manage tr td:first-child{ border-left: 0;}
	.threadtypes_manage .px{ height: .2rem; line-height: .2rem; padding: .02rem .05rem; border: 1px solid #eaeaea; border-radius: .04rem; vertical-align: top; font-size: .14rem; color: #444;}
	
	.group_manage_demise{ padding-top: .12rem; background: #fff;}
	.group_manage_demise .tbmu{ line-height: 1.5; margin: 0 .1rem; padding: .1rem; border: 1px dashed #eee; background: #ffe; border-radius: .02rem; font-size: .13rem; color: #666;}
	.group_manage_demise .tbmu h2{ line-height: 1.6; font-size: .14rem; font-weight: 700;}
	.group_manage_demise .byg_group_box{ margin: 0;}
	.group_manage_demise_password{ line-height: .26rem; margin: .15rem .12rem .05rem; font-size: .14rem;}
	.group_manage_demise_password input{ height: .2rem; line-height: .2rem; padding: .02rem .05rem; border: 1px solid #eaeaea; border-radius: .04rem; vertical-align: top;}
</style>

<div class="byg_thread_types">
	<ul id="thread_types" class="swiper-wrapper">
		<li id="ttp_all" class="swiper-slide{if $_GET['op'] == 'group'} a{/if}"><a href="forum.php?mod=group&action=manage&op=group&fid=$_G[fid]">{lang group_setup}</a></li>
		<!--{if !empty($groupmanagers[$_G[uid]]) || $_G['adminid'] == 1}-->
		<li class="swiper-slide{if $_GET['op'] == 'checkuser'} a{/if}"><a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]">{lang group_member_moderate}</a></li>
		<li class="swiper-slide{if $_GET['op'] == 'manageuser'} a{/if}"><a href="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]">{lang group_member_management}</a></li>
		<!--{/if}-->
		<!--{if $_G['forum']['founderuid'] == $_G['uid'] || $_G['adminid'] == 1}-->
		<li class="swiper-slide{if $_GET['op'] == 'threadtype'} a{/if}"><a href="forum.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]">{lang group_threadtype}</a></li>
		<li class="swiper-slide{if $_GET['op'] == 'demise'} a{/if}"><a href="forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]">{lang group_demise}</a></li>
		<!--{/if}-->
	</ul>
</div>
<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
<script type="text/javascript">
	if(jQuery(".byg_thread_types .a").length > 0) {
		var tab_initial = jQuery(".byg_thread_types .a").offset().left + jQuery(".byg_thread_types .a").width() + 20 >= jQuery(window).width() ? jQuery(".byg_thread_types .a").index() : 0;
	}else{
		var tab_initial = 0;
	}
	var byg_thread_types = new Swiper('.byg_thread_types', {
		initialSlide : tab_initial,
		slidesPerView : 'auto',
		freeMode : true,
	});
</script>

<!--{if $_GET['op'] == 'group'}-->
	<div class="group_manage_group">
		<form enctype="multipart/form-data" action="forum.php?mod=group&action=manage&op=group&fid=$_G[fid]" name="manage" method="post" autocomplete="off">
			<input type="hidden" value="{FORMHASH}" name="formhash" />
			<table cellspacing="0" cellpadding="0" summary="{lang group_admin_panel}">
				<tbody>
					<!--{if !empty($specialswitch['allowchangename']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
					<tr>
						<th><span class="rq">*</span>{lang group_name}:</th>
						<td><input type="text" id="name" name="name" class="input_text" size="" tabindex="1" value="$_G[forum][name]" autocomplete="off" tabindex="1" /></td>
					</tr>
					<!--{/if}-->
					<!--{if !empty($specialswitch['allowchangetype']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
					<tr>
						<th><span class="rq">*</span>{lang group_category}:</th>
						<td>
							<select name="parentid" tabindex="2" class="" onchange="ajax_groupselect(this.value);">
								$groupselect[first]
							</select>
							<em id="secondgroup"><!--{if $groupselect['second']}--><select id="fup" name="fup" class="" >$groupselect[second]</select><!--{/if}--></em>
						</td>
					</tr>
					<!--{/if}-->
					<tr>
						<th>{lang group_description}:</th>
						<td>
							<div class="tedt">
								<div class="area">
									<textarea id="descriptionmessage" name="descriptionnew" class="input_textarea" rows="5">$_G[forum][descriptionnew]</textarea>
								</div>
							</div>
						</td>
					</tr>
					<tr>
						<th>{lang group_perm_visit}:</th>
						<td>
							<label class=""><input type="radio" name="gviewpermnew" class="pr" value="1" $gviewpermselect[1] />{lang group_perm_all_user}</label>
							<label class=""><input type="radio" name="gviewpermnew" class="pr" value="0" $gviewpermselect[0] />{lang group_perm_member_only}</label>
						</td>
					</tr>
					<tr>
						<th>{lang group_join_type}:</th>
						<td>
							<label class=""><input type="radio" name="jointypenew" class="pr" value="0" $jointypeselect[0] />{lang group_join_type_free}</label>
							<label class=""><input type="radio" name="jointypenew" class="pr" value="2" $jointypeselect[2] />{lang group_join_type_moderate}</label>
							<label class=""><input type="radio" name="jointypenew" class="pr" value="1" $jointypeselect[1] />{lang group_join_type_invite}</label>
							<!--{if !empty($specialswitch['allowclosegroup'])}-->
							<label class=""><input type="radio" name="jointypenew" class="pr" value="-1" $jointypeselect[-1] />{lang close}</label>
							<p class="input_text2_p">{lang group_close_notice}</p>
							<!--{/if}-->
						</td>
					</tr>
					<!--{if $_G['setting']['allowgroupdomain'] && !empty($_G['setting']['domain']['root']['group']) && $domainlength}-->
					<tr>
						<th>{lang subdomain}:</th>
						<td>
							http://<input type="text" name="domain" class="input_text2" value="$_G[forum][domain]" />.{$_G['setting']['domain']['root']['group']}
							<p class="input_text2_p">
								{lang group_domain_message}<br/>
								<!--{if $_G[forum][domain] && $consume}-->{lang group_edit_domain_message}<!--{/if}-->
							</p>
						</td>
					</tr>
					<!--{/if}-->
					<tr>
						<th>{lang group_icon}:</th>
						<td>
							<input type="file" id="iconnew" class="" size="" name="iconnew" />
							<p class="input_text2_p" style="margin: .08rem 0;">
								{lang group_icon_resize}
								<!--{if $_G[setting][group_imgsizelimit]}-->
								<br/>{lang group_image_filesize_limit}
								<!--{/if}-->
							</p>
							<!--{if $_G['forum']['icon']}-->
								<img width="48" height="48" alt="" class="vm" src="$_G[forum][icon]?{TIMESTAMP}" />
							<!--{/if}-->
						</td>
					</tr>
				</tbody>
			</table>
			<div class="group_manage_group_smt">
				<button type="submit" name="groupmanage" value="1">{lang submit}</button>
			</div>
		</form>
		<script type="text/javascript">
			function ajax_groupselect(obj) {
				jQuery.ajax({
					url: 'forum.php?mod=ajax&action=secondgroup&fupid='+ obj + '&inajax=1',
					type: 'POST',
					dataType: 'xml',
					success: function(s) {
						jQuery('#secondgroup').html(s.lastChild.firstChild.nodeValue);
					}
				});
			}
		</script>
	</div>
<!--{elseif $_GET['op'] == 'checkuser'}-->
	<!--{if $checkusers}-->
		<p class="group_manage_checkuser_t cl">
			<span class="y">
				<a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=1">{lang pass_all}</a><span class="pipe">|</span><a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=2">{lang ignore_all}</a>
			</span>
		</p>
		<div class="group_manage_checkuser">
		<!--{loop $checkusers $uid $user}-->
			<dl class="cl">
				<dd class="z"><!--{echo avatar($user[uid], 'middle')}--></dd>
				<dt>
					<a href="home.php?mod=space&uid=$user[uid]&do=profile">$user[username]</a>
					<p class="xg1">$user['joindateline']</p>
				</dt>
				<dd class="b">
					<button type="submit" name="checkusertrue" class="" value="true" onclick="location.href='forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=1'"><em>{lang pass}</em></button> &nbsp; <button type="submit" name="checkuserfalse" class="" value="true" onclick="location.href='forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=2'"><em>{lang ignore}</em></button>
				</dd>
			</dl>
		<!--{/loop}-->
		</div>
		<!--{if $multipage}-->$multipage<!--{/if}-->
	<!--{else}-->
		<p class="home_no_data" style="margin:0;">{lang group_no_member_moderated}</p>
	<!--{/if}-->
<!--{elseif $_GET['op'] == 'manageuser'}-->
	<script type="text/javascript">
		function groupManageUser(targetlevel_val) {
			document.getElementById('targetlevel').value = targetlevel_val;
			document.getElementById('manageuser').submit();
		}
	</script>
	<div class="group_manage_manageuser_search">
		<form action="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]" method="post" class="cl">
		<input type="text" value="{if $_GET['srchuser']}$_GET[srchuser]{/if}" name="srchuser" placeholder="{lang enter_member_user}" class="z" id="groupsearch">&nbsp;
		<button class="y" type="submit"><span>{lang search}</span></button>
		</form>
	</div>
	<form action="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]&manageuser=true" name="manageuser" id="manageuser" method="post" autocomplete="off" class="">
		<input type="hidden" value="{FORMHASH}" name="formhash" />
        <input type="hidden" value="0" name="targetlevel" id="targetlevel" />
		<!--{if $adminuserlist}-->
		<div class="byg_group_box">
			<div class="byg_group_box_h2 cl">
				<h2>{lang group_admin_member}</h2>
			</div>
			<div class="group_manage_manageuser_list">
				<ul class="cl">
					<!--{loop $adminuserlist $user}-->
					<li>
						<a href="home.php?mod=space&uid=$user[uid]&do=profile"><img src="<!--{avatar($user[uid], middle, true)}-->" alt="$user[username]" />{$user[username]}<!--{if $user['level'] == 1}--><span>{lang group_moderator_title}</span><!--{elseif $user['level'] == 2}--><span>{lang group_moderator_vice_title}</span><!--{/if}--></a>
						<!--{if $_G['adminid'] == 1 || ($_G['uid'] != $user['uid'] && ($_G['uid'] == $_G['forum']['founderuid'] || $user['level'] > $groupuser['level']))}--><input type="checkbox" class="" name="muid[{$user[uid]}]" value="$user[level]" /><!--{/if}-->
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		<!--{/if}-->
		<!--{if $staruserlist || $userlist}-->
		<div class="byg_group_box">
			<div class="byg_group_box_h2 cl">
				<h2>{lang member}</h2>
			</div>
			<div class="group_manage_manageuser_list">
				<ul class="cl">
				<!--{if $staruserlist}-->
					<!--{loop $staruserlist $user}-->
					<li>
						<a href="home.php?mod=space&uid=$user[uid]&do=profile"><img src="<!--{avatar($user[uid], middle, true)}-->" alt="$user[username]" />{$user[username]}<span>{lang group_star_member_title}</span></a>
						<!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}--><input type="checkbox" class="" name="muid[{$user[uid]}]" value="$user[level]" /><!--{/if}-->
					</li>
					<!--{/loop}-->
				<!--{/if}-->
				<!--{if $userlist}-->
					<!--{loop $userlist $user}-->
					<li>
						<a href="home.php?mod=space&uid=$user[uid]&do=profile"><img src="<!--{avatar($user[uid], middle, true)}-->" alt="$user[username]" />{$user[username]}</a>
						<!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}--><input type="checkbox" class="" name="muid[{$user[uid]}]" value="$user[level]" /><!--{/if}-->
					</li>
					<!--{/loop}-->
				<!--{/if}-->
				</ul>
			</div>
		</div>
		<!--{/if}-->
		<div class="cl group_manage_manageuser_b">
			<!--{loop $mtype $key $name}-->
            	<!--{if $_G['forum']['founderuid'] == $_G['uid'] || $key > $groupuser['level'] || $_G['adminid'] == 1}-->
                <button type="button" name="manageuser" value="true" class="pn" onclick="groupManageUser('{$key}')"><span>$name</span></button>
                <!--{/if}-->
            <!--{/loop}-->
		</div>
		<!--{if $multipage}-->$multipage<!--{/if}-->
	</form>
<!--{elseif $_GET['op'] == 'threadtype'}-->
	<!--{if empty($specialswitch['allowthreadtype'])}-->
	<p class="home_no_data" style="margin:0;">{lang group_level_cannot_do}</p>
	<!--{else}-->
	<script type="text/JavaScript">
		var rowtypedata = [
			[
				[1,'<input type="checkbox" class="pc" disabled="disabled" />', ''],
				[1,'<input type="checkbox" class="pc" name="newenable[]" checked="checked" value="1" />', ''],
				[1,'<input class="px" type="text" size="2" name="newdisplayorder[]" value="0" />'],
				[1,'<input class="px" type="text" name="newname[]" />']
			],
		];
		var addrowdirect = 0;
		var typenumlimit = $typenumlimit;
		function addrow(obj, type) {
			var table = obj.parentNode.parentNode.parentNode.parentNode;
			if(typenumlimit <= obj.parentNode.parentNode.parentNode.rowIndex - 1) {
				alert('{lang group_threadtype_limit_1}'+typenumlimit+'{lang group_threadtype_limit_2}');
				return false;
			}
			if(!addrowdirect) {
				var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
			} else {
				var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
			}

			var typedata = rowtypedata[type];
			for(var i = 0; i <= typedata.length - 1; i++) {
				var cell = row.insertCell(i);
				cell.colSpan = typedata[i][0];
				var tmp = typedata[i][1];
				if(typedata[i][2]) {
					cell.className = typedata[i][2];
				}
				tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return addrow.arguments[parseInt($2) + 1];});
				cell.innerHTML = tmp;
			}
			addrowdirect = 0;
		}
	</script>
	<div id="threadtypes" class="group_manage_group">
		<form id="threadtypeform" action="forum.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]" autocomplete="off" method="post" name="threadtypeform">
			<input type="hidden" value="{FORMHASH}" name="formhash" />
			<div class="threadtype_turn_on">
				<table cellspacing="0" cellpadding="0">
					<tr>
						<th>{lang threadtype_turn_on}:</th>
						<td>
							<label class="lb"><input type="radio" name="threadtypesnew[status]" class="pr" value="1" onclick="document.getElementById('threadtypes_config').style.display = '';document.getElementById('threadtypes_manage').style.display = '';" $checkeds[status][1] />{lang yes}</label>
							<label class="lb"><input type="radio" name="threadtypesnew[status]" class="pr" value="0" onclick="document.getElementById('threadtypes_config').style.display = 'none';document.getElementById('threadtypes_manage').style.display = 'none';"  $checkeds[status][0] />{lang no}</label>
							<p class="input_text2_p">{lang threadtype_turn_on_comment}</p>
						</td>
					</tr>
					<tbody id="threadtypes_config" style="display: $display">
						<tr>
							<th>{lang threadtype_required}:</th>
							<td>
								<label class="lb"><input type="radio" name="threadtypesnew[required]" class="pr" value="1" $checkeds[required][1] />{lang yes}</label>
								<label class="lb"><input type="radio" name="threadtypesnew[required]" class="pr" value="0" $checkeds[required][0] />{lang no}</label>
								<p class="input_text2_p">{lang threadtype_required_force}</p>
							</td>
						</tr>
						<tr>
							<th>{lang threadtype_prefix}:</th>
							<td>
								<label class="lb"><input type="radio" name="threadtypesnew[prefix]" class="pr" value="0" $checkeds[prefix][0] />{lang threadtype_prefix_off}</label>
								<label class="lb"><input type="radio" name="threadtypesnew[prefix]" class="pr" value="1" $checkeds[prefix][1] />{lang threadtype_prefix_on}</label>
								<p class="input_text2_p">{lang threadtype_prefix_comment}</p>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div id="threadtypes_manage"  class="threadtypes_manage" style="display: $display">
				<h2>{lang threadtype}</h2>
				<table cellspacing="0" cellpadding="0" class="dt">
					<thead>
						<tr>
							<th class="threadtypes_manage_th">{lang delete}</th>
							<th class="threadtypes_manage_th">{lang enable}</th>
							<th class="threadtypes_manage_th">{lang displayorder}</th>
							<th>{lang threadtype_name}</th>
						</tr>
					</thead>
					<!--{if $threadtypes}-->
						<!--{loop $threadtypes $val}-->
						<tbody>
							<tr>
								<td><input type="checkbox" class="pc" name="threadtypesnew[options][delete][]" value="{$val[typeid]}" /></td>
								<td><input type="checkbox" class="pc" name="threadtypesnew[options][enable][{$val[typeid]}]" value="1" class="pc" $val[enablechecked] /></td>
								<td><input type="text" name="threadtypesnew[options][displayorder][{$val[typeid]}]" class="px" size="2" value="$val[displayorder]" /></td>
								<td><input type="text" name="threadtypesnew[options][name][{$val[typeid]}]" class="px" value="$val[name]" /></td>
							</tr>
						</tbody>
						<!--{/loop}-->
					<!--{/if}-->
					<tr>
						<td colspan="4"><img class="vm" src="{IMGDIR}/addicn.gif" /> <a href="javascript:;" onclick="addrow(this, 0)">{lang threadtype_add}</a></td>
					</tr>
				</table>
			</div>
			<div class="group_manage_group_smt">
				<button type="submit" name="groupthreadtype" value="1">{lang submit}</button>
			</div>
		</form>
	</div>
	<!--{/if}-->
<!--{elseif $_GET['op'] == 'demise'}-->
	<!--{if $groupmanagers}-->
	<div class="group_manage_demise">
		<div class="tbmu">
			{lang group_demise_comment}
			<div class="mtm">{lang group_demise_notice}</div>
		</div>
		<form action="forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]" name="groupdemise" method="post" class="exfm">
			<input type="hidden" value="{FORMHASH}" name="formhash" />
			<div class="byg_group_box">
				<div class="byg_group_box_h2 cl">
					<h2>{lang transfer_group_to}:</h2>
				</div>
				<div class="group_manage_manageuser_list">
					<ul class="cl">
						<!--{loop $groupmanagers $user}-->
						<li>
							<a href="home.php?mod=space&uid=$user[uid]&do=profile"><img src="<!--{avatar($user[uid], middle, true)}-->" alt="$user[username]" />{$user[username]}<!--{if $user['level'] == 1}--><span>{lang group_moderator_title}</span><!--{elseif $user['level'] == 2}--><span>{lang group_moderator_vice_title}</span><!--{/if}--></a>
							<!--{if $user['uid'] != $_G['uid']}--><input type="radio" name="suid" value="$user[uid]" /><!--{/if}-->
						</li>
						<!--{/loop}-->
					</ul>
				</div>
			</div>
			<div class="group_manage_demise_password">
				<span>{lang group_input_password}</span>
				<input type="password" name="grouppwd" />
			</div>
			<div class="group_manage_group_smt">
				<button type="submit" name="groupdemise" value="1">{lang submit}</button>
			</div>
		</form>
	</div>
	<!--{else}-->
	<p class="home_no_data" style="margin:0;">{lang group_no_admin_member}</p>
	<!--{/if}-->
<!--{/if}-->