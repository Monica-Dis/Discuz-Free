<?php echo 'From: DisM.taobao.com';exit;?>

<!--{eval $_G['home_tpl_titles'] = array('{lang pm}');}-->
<!--{template common/header}-->

<style>
	.pmbox li .num{ font-size: 12px;}
	.pmbox li a{ height: 42px; line-height: 21px; padding: 6px 10px 4px 55px;}
	.pmbox li a .grey{ height: 20px; line-height: 20px; overflow: hidden; font-size: 13px;}
	.byg_grouppm{ margin-top: .1rem; padding: .12rem; background: #fff;}
	.byg_grouppm_t{ margin-bottom: .06rem; padding-bottom: .12rem; border-bottom: 1px dashed #eee;}
	.byg_grouppm_t img{ width: .4rem; height: .4rem; vertical-align: top;}
	.byg_grouppm_t .y{ width: 3.05rem; line-height: .2rem; font-size: .14rem;}
	.byg_grouppm_b_t b{ font-size: .17rem; font-weight: 700;}
	.byg_grouppm_b_b a{ display: inline-block; margin-top: .1rem; padding: .02rem .08rem; background: $_G['style']['zhuti']; font-size: .12rem; color: #fff; border-radius: .02rem;}
</style>

<!--{if in_array($filter, array('privatepm')) || in_array($filter, array('announcepm')) || in_array($_GET[subop], array('view')) || in_array($_GET[subop], array('viewg'))}-->
	<!--{if in_array($filter, array('privatepm')) || in_array($filter, array('announcepm'))}-->
	
		<!-- header start -->
		<header class="header_xin">
			<div class="hdc_xin cl" id="byg_header">
				<div class="header_z cl">
					<a href="javascript:;" class="shouye">
						<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
						<!--{if $_G[member][newpm] || $post_notice_new}-->
						<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
						<!--{/if}-->
					</a>
					<em>&rsaquo;</em>
					<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" title="个人中心">个人中心</a>
					<em>&rsaquo;</em>
					<span>我的消息</span>
				</div>
				<a href="home.php?mod=spacecp&ac=pm" title="发表新消息" class="header_y">
				<img src="{$_G['style']['styleimgdir']}/faxiaoxi.png" alt="发消息"/></a>
			</div>
		</header>
		<!--{hook/global_header_mobile}-->
		<!-- header end -->
	
		<div class="forumdisplay_tab">
			<a href="home.php?mod=space&do=pm&filter=privatepm" {if $_GET['filter'] != 'announcepm'}class="on"{/if}>私人消息</a>
			<a href="home.php?mod=space&do=pm&filter=announcepm" {if $_GET['filter'] == 'announcepm'}class="on"{/if}>公共消息</a>
		</div>

		<!-- main pmlist start -->
		<div class="pmbox">
			<!--{if $grouppms}-->
			<ul>
				<!--{loop $grouppms $grouppm}-->
				<li>
				<div class="avatar_img"><img src="<!--{if $grouppm[author]}-->{IMGDIR}/annpm.png<!--{else}-->{IMGDIR}/systempm.png<!--{/if}-->" alt="头像" style="height:32px;width:32px;"/></div>
					<a href="home.php?mod=space&do=pm&subop=viewg&pmid=$grouppm[id]">
						<div class="cl">
							<!--{if !$gpmstatus[$grouppm[id]]}--><span class="num">新通知</span><!--{/if}-->
							<!--{if $grouppm[author]}-->
								<span class="name">{$grouppm[author]} {lang say}:</span>
							<!--{else}-->
								<span class="name">系统 {lang say}:</span>
							<!--{/if}-->
						</div>
						<div class="cl grey">
							<span class="time">&nbsp;&nbsp;&nbsp;<!--{date($grouppm[dateline], 'u')}--></span>
							<span>{$grouppm[message]}</span>
						</div>
					</a>
				</li>
				<!--{/loop}-->
			</ul>
			<!--{/if}-->

			<!--{if $list}-->
			<ul>
				<!--{loop $list $key $value}-->
				<li>
				<div class="avatar_img"><img src="<!--{if $value[pmtype] == 2}-->{STATICURL}image/common/grouppm.png<!--{else}--><!--{avatar($value[touid] ? $value[touid] : ($value[lastauthorid] ? $value[lastauthorid] : $value[authorid]), middle, true)}--><!--{/if}-->" alt="头像" style="height:32px;width:32px;"/></div>
					<a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}">
						<div class="cl">
							<!--{if $value[new]}--><span class="num">$value[pmnum]</span><!--{/if}-->
							<!--{if $value[touid]}-->
								<!--{if $value[msgfromid] == $_G[uid]}-->
									<span class="name">{lang me}{lang you_to} {$value[tousername]}{lang say}:</span>
								<!--{else}-->
									<span class="name">{$value[tousername]} {lang you_to}{lang me}{lang say}:</span>
								<!--{/if}-->
							<!--{elseif $value['pmtype'] == 2}-->
								<span class="name">{lang chatpm_author}:$value['firstauthor']</span>
							<!--{/if}-->
						</div>
						<div class="cl grey">
							<span class="time">&nbsp;&nbsp;&nbsp;<!--{date($value[dateline], 'u')}--></span>
							<span><!--{if $value['pmtype'] == 2}-->[{lang chatpm}]<!--{if $value[subject]}-->$value[subject]<br><!--{/if}--><!--{/if}--><!--{if $value['pmtype'] == 2 && $value['lastauthor']}--><div style="padding:0 0 0 20px;">......<br>$value['lastauthor'] : $value[message]</div><!--{else}-->$value[message]<!--{/if}--></span>
						</div>
					</a>
				</li>
				<!--{/loop}-->
			</ul>
			<!--{/if}-->

			<!--{if $_GET['filter'] == 'announcepm'}-->
				<!--{if !$grouppms}-->
					<div class="home_no_data">没有消息</div>
				<!--{/if}-->
			<!--{else}-->
				<!--{if !$grouppms && !$list}-->
					<div class="home_no_data">没有消息</div>
				<!--{/if}-->
			<!--{/if}-->
			
			<!--{if $multi}-->$multi<!--{/if}-->
		</div>
		<!-- main pmlist end -->

	<!--{elseif in_array($_GET[subop], array('view')) || in_array($_GET[subop], array('viewg'))}-->

		<!-- header start -->
		<header class="header_xin">
			<div class="hdc_xin cl" id="byg_header">
				<div class="header_z cl">
					<a href="javascript:;" class="shouye">
						<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
						<!--{if $_G[member][newpm] || $post_notice_new}-->
						<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
						<!--{/if}-->
					</a>
					<em>&rsaquo;</em>
					<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" title="个人中心">个人中心</a>
					<em>&rsaquo;</em>
					<a href="home.php?mod=space&do=pm" title="我的消息">我的消息</a>
					<em>&rsaquo;</em>
					<span>{lang viewmypm}</span>
				</div>
				<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
			</div>
		</header>
		<!--{hook/global_header_mobile}-->
		<!-- header end -->
	
		<!--{if in_array($_GET[subop], array('view'))}-->
			<!-- main viewmsg_box start -->
			<div class="wp">
				<div class="msgbox b_m">
					<!--{if !$list}-->
						<p style="text-align:center;">{lang no_corresponding_pm}</p>
					<!--{else}-->
						<!--{loop $list $key $value}-->
							<!--{subtemplate home/space_pm_node}-->
						<!--{/loop}-->
						$multi
					<!--{/if}-->
				</div>
				<form id="pmform" class="pmform" name="pmform" method="post" action="home.php?mod=spacecp&ac=pm&op=send&pmid=$pmid&daterange=$daterange&pmsubmit=yes&mobile=2" >
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<!--{if !$touid}-->
					<input type="hidden" name="plid" value="$plid" />
					<!--{else}-->
					<input type="hidden" name="touid" value="$touid" />
					<!--{/if}-->
					<div class="reply b_m"><input type="text" value="" class="px" autocomplete="off" id="replymessage" name="message"></div>
					<div class="reply b_m"><input type="button" name="pmsubmit" id="pmsubmit" class="formdialog button2" value="发送" style="margin:0;" /></div>
				</form>
			</div>
			<!-- main viewmsg_box end -->
		<!--{else}-->
			<!--{if $grouppm}-->
				<div class="byg_grouppm">
					<dl>
						<dd class="byg_grouppm_t cl">
							<!--{if $grouppm[author]}-->
								<img src="{IMGDIR}/annpm.png" alt="" />
							<!--{else}-->
								<img src="{IMGDIR}/systempm.png" alt="" />
							<!--{/if}-->
							<div class="y">
								<p><!--{if $grouppm['author']}-->{lang sendmultipmwho}<!--{else}-->{lang sendmultipmsystem}<!--{/if}--></p>
								<p class="xg1"><!--{date($grouppm[dateline], 'u')}--></p>
							</div>
						</dd>
						<dd class="byg_grouppm_b">
							<p class="byg_grouppm_b_t">$grouppm[message]</p>
							<!--{if $grouppm[author]}-->
								<p class="byg_grouppm_b_b">
									<a href="home.php?mod=space&do=pm&subop=view&touid={$grouppm[authorid]}">{lang reply} $grouppm[author]</a>
								</p>
							<!--{/if}-->
						</dd>
					</dl>
				</div>
			<!--{else}-->
				<div class="home_no_data">
					{lang no_corresponding_pm}
				</div>
			<!--{/if}-->
		<!--{/if}-->
	<!--{/if}-->
<!--{else}-->
	<div class="home_no_data">
		{lang user_mobile_pm_error}
	</div>
<!--{/if}-->

<!--{template common/footer}-->
