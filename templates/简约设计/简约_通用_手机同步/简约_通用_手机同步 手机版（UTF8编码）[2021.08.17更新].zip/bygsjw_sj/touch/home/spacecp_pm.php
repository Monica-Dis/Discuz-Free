<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!--{if $op != ''}-->
<div class="bm_c">{lang user_mobile_pm_error}</div>
<!--{else}-->

<form id="pmform_{$pmid}" name="pmform_{$pmid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=pm&op=send&touid=$touid&pmid=$pmid&mobile=2" >
	<input type="hidden" name="referer" value="{echo dreferer();}" />
	<input type="hidden" name="pmsubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" title="个人中心">个人中心</a>
			<em>&rsaquo;</em>
			<a href="home.php?mod=space&do=pm" title="我的消息">我的消息</a>
			<em>&rsaquo;</em>
			<span>{lang send_pm}</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->
<!-- main post_msg_box start -->
<div class="wp">
	<div class="post_msg_from">
		<ul>
			<!--{if !$touid}-->
			<li class="bl_line"><input type="text" value="" tabindex="1" class="px" size="30" autocomplete="off" id="username" name="username" placeholder="{lang addressee}"></li>
			<!--{/if}-->
			<li class="bl_none area">
				<textarea class="pt" tabindex="2" autocomplete="off" value="" id="sendmessage" name="message" cols="80" rows="7"  placeholder="{lang thread_content}"></textarea>
			</li>
		</ul>
		<div class="publish publish_t">
			<span><button id="pmsubmit_btn" class="btn_pn btn_pn_grey" disable="true"><span>{lang sendpm}</span></button></span>
			<input type="hidden" name="pmsubmit_btn" value="yes" />
		</div>
	</div>
</div>
<!-- main postbox start -->
</form>
<script type="text/javascript">
	(function() {
		jQuery('#sendmessage').on('keyup input', function() {
			var obj = jQuery(this);
			if(obj.val()) {
				jQuery('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
				jQuery('.btn_pn').attr('disable', 'false');
			} else {
				jQuery('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
				jQuery('.btn_pn').attr('disable', 'true');
			}
		});
		var form = jQuery('#pmform_{$pmid}');
		jQuery('#pmsubmit_btn').on('click', function() {
			var obj = jQuery(this);
			if(obj.attr('disable') == 'true') {
				return false;
			}
			jQuery.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey='+form.attr('id')+'&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				popup.open('{lang networkerror}', 'alert');
			});
			return false;
			});
	 })();
</script>
<!--{/if}-->

<!--{template common/footer}-->
