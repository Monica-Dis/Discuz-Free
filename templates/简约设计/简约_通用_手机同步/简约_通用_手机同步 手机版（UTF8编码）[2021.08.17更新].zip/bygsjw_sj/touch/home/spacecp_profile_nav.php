<?php echo 'Discuz!搴旗敤涓绩寮€鍙戣€?绠€绾﹁璁?;exit;?>

<div class="portal_font_nav">
	<div class="swiper-wrapper">
		<!--{if $operation != 'verify'}-->
		<!--{loop $profilegroup $key $value}-->
			<!--{if $value[available]}-->
			<a href="home.php?mod=spacecp&ac=profile&op=$key" class="swiper-slide {if $opactives[$key]}on{/if}">$value[title]</a>
			<!--{/if}-->
		<!--{/loop}-->
	<!--{/if}-->
	</div>
</div>