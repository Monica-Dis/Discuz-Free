<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="头像"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" title="个人中心">个人中心</a>
			<em>&rsaquo;</em>
			<span><!--{if $_GET['type'] == 'reply'}-->我的回复<!--{else}-->我的主题<!--{/if}--></span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="forumdisplay_tab">
	<a href="home.php?mod=space&do=thread&view=me&type=thread" {if $_GET['type'] != 'reply'}class="on"{/if}><h2>主题</h2></a>
	<a href="home.php?mod=space&do=thread&view=me&type=reply" {if $_GET['type'] == 'reply'}class="on"{/if}><h2>回复</h2></a>
</div>

<!-- main threadlist start -->
<div class="threadlist my_threadlist">
	<!--{if $list}-->
	<style>
		.viewtype_reply{ padding: 10px;}
		.my_threadlist.threadlist .viewtype_reply a{ padding: 0;}
		.my_threadlist.threadlist .viewtype_reply .viewtype_reply_t{ padding-bottom: .05rem;}
		.my_threadlist.threadlist .viewtype_reply .viewtype_reply_b{ margin-top: .05rem; padding: .04rem .06rem; line-height: .22rem; border: 1px dashed #eee; font-size: .15rem; background: #ffe; border-radius: .02rem; color: #666;}
	</style>
	<ul>
		<!--{loop $list $stid $thread}-->
			<li>
			<!--{if $viewtype == 'reply'}-->
			<div class="viewtype_reply">
				<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]" class="viewtype_reply_t">$thread[subject]</a>
				<!--{loop $tids[$stid] $pid}-->
					<!--{eval $post = $posts[$pid];}-->
					<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid" class="viewtype_reply_b"><!--{if $post[message]}-->{$post[message]}<!--{else}-->......<!--{/if}--></a>
				<!--{/loop}-->
			</div>
			<!--{elseif $viewtype == 'postcomment'}-->
			<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]">$thread[subject]</a>
			<!--{else}-->
			<a href="forum.php?mod=viewthread&tid=$thread[tid]" {if $thread['displayorder'] == -1}class="grey"{/if}>$thread[subject]</a>
			<!--{/if}-->
			<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				<span class="icon_top"><img src="{STATICURL}image/mobile/images/icon_top.png" alt="置顶"/></span>
			<!--{elseif $thread['attachment'] == 2}-->
				<span class="icon_tu"><img src="{STATICURL}image/mobile/images/icon_tu.png" alt="有图"/></span>
			<!--{/if}-->
			</li>
		<!--{/loop}-->
	</ul>
	<!--{else}-->
	<div class="home_no_data">{lang no_related_posts}</div>
	<!--{/if}-->
	$multi
</div>
<!-- main threadlist end -->

<!--{template common/footer}-->
