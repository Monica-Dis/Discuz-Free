<?php echo 'From: DisM.taobao.com';exit;?>

<table cellpadding="0" cellspacing="0" class="atd">
	<tr>
	<!--{eval $clicknum = 0;}-->
	<!--{loop $clicks $key $value}-->
	<!--{eval $clicknum = $clicknum + $value['clicknum'];}-->
	<!--{eval $value['height'] = $maxclicknum?intval($value['clicknum']*50/$maxclicknum):0;}-->
		<td>
			<a href="home.php?mod=spacecp&ac=click&op=add&clickid=$key&idtype=$idtype&id=$id&hash=$hash&handlekey=clickhandle" id="click_{$idtype}_{$id}_{$key}" onclick="return landingPrompt();">
				<!--{if $value[clicknum]}-->
				<div class="atdc">
					<div class="ac{$value[classid]}" style="height:<!--{echo $value[height] / 100;}-->rem;">
						<em>{$value[clicknum]}</em>
					</div>
				</div>
				<!--{/if}-->
				<img src="{STATICURL}image/click/$value[icon]" alt="$value[name]" /><br />$value[name]
			</a>
		</td>
	<!--{/loop}-->
	</tr>
</table>
<script type="text/javascript">
	function errorhandle_clickhandle(message, values) {
		if(values['id']) {
			showCreditPrompt();
			show_click(values['idtype'], values['id'], values['clickid']);
		}
	}
</script>

<!--{if $clickuserlist}-->
<h3>{lang position_friend}</h3>
<div id="trace_div">
	<ul class="cl">
	<!--{loop $clickuserlist $value}-->
		<li class="z">
			<!--{if $value[username]}-->
			<div><a href="home.php?mod=space&uid=$value[uid]&do=profile" title="$value[clickname]"><!--{avatar($value[uid], 'small')}--></a></div>
			<!--{else}-->
			<div><img src="{STATICURL}image/magic/hidden.gif" alt="$value[clickname]" /></div>
			<!--{/if}-->
		</li>
	<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->
