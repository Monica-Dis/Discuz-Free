<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//获取当前版块全部信息
function byg_post_forum_all($forumid) {
	$forum_all = DB::fetch_all("SELECT * FROM ".DB::table('forum_forum')." WHERE fup = '$forumid'");
	return $forum_all;
}

//获取版块图标
function byg_post_forum_icon($forumid) {
	$forum_icon = DB::result(DB::query("SELECT icon FROM ".DB::table('forum_forumfield')." WHERE fid = '$forumid'"));
	return $forum_icon;
}
//From: Dism_taobao_com
?>