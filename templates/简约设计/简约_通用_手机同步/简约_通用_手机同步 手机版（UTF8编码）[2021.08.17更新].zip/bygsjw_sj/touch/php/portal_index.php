<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//获取数据DIY模块的ID
function byg_data_block_id($name, $name1) {
	if (byg_diy_block_bool($name) || byg_diy_block_bool($name1)) {
		$data_block_id = DB::result(DB::query("SELECT a.bid FROM ".DB::table('common_block')." a LEFT JOIN ".DB::table('common_template_block')." b ON a.bid=b.bid WHERE (a.name = '$name' OR a.name = '$name1') AND b.targettplname = 'forum/discuz' ORDER BY a.bid DESC"));
		if(!$data_block_id) {
			$data_block_id = DB::result(DB::query("SELECT bid FROM ".DB::table('common_block')." WHERE (name = '$name' OR name = '$name1') ORDER BY bid DESC"));
		}
		return $data_block_id;
	}
}

//获取数据模块的数据
function byg_data_block_data($bid, $num) {
	$data_block_data = DB::fetch_all("SELECT * FROM ".DB::table('common_block_item')." WHERE bid = '$bid' ORDER BY displayorder ASC LIMIT $num");
	return $data_block_data;
}

//获取数据模块的标题
function byg_data_block_tit($bid) {
	$data_block_tit = DB::result(DB::query("SELECT title FROM ".DB::table('common_block')." WHERE bid = '$bid'"));
	return $data_block_tit;
}

//统计主题图片
function byg_threadlist_img_num($tid, $uid, $biaoid) {
	$img_number = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$biaoid.'')." WHERE tid = '$tid' AND uid = '$uid' AND isimage = '1'"));
	return $img_number;
}

//获取主题图片
function byg_threadlist_img($tid, $uid, $num, $biaoid) {
	$list_img = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$biaoid.'')." WHERE tid = '$tid' AND uid = '$uid' AND isimage = '1' ORDER BY dateline ASC LIMIT $num");
	return $list_img;
}

//统计文章图片
function byg_article_img_num($aid, $uid) {
	$img_number = DB::result(DB::query("SELECT count(*) FROM ".DB::table('portal_attachment')." WHERE aid = '$aid' AND isimage = '1'"));
	return $img_number;
}

//获取文章图片
function byg_article_img($aid, $uid, $num) {
	$list_img = DB::fetch_all("SELECT * FROM ".DB::table('portal_attachment')." WHERE aid = '$aid' AND isimage = '1' ORDER BY dateline ASC LIMIT $num");
	return $list_img;
}

$index_bg_p = byg_diy_block_param('简约通用手机版门户首页欢迎图片');
$bygsjw_logo = byg_diy_block_sum('简约通用手机版LOGO');
$slide_bid = byg_data_block_id('bygsjw1', '简约通用论坛首页幻灯片');
$b7_bid = byg_data_block_id('bygsjw7', '简约通用论坛首页头条');
$diy_nav1_p = byg_diy_block_param('简约通用手机版首页自定义导航1');
$diy_nav2_p = byg_diy_block_param('简约通用手机版首页自定义导航2');
$diy_nav3_p = byg_diy_block_param('简约通用手机版首页自定义导航3');
$diy_nav4_p = byg_diy_block_param('简约通用手机版首页自定义导航4');
$diy_nav5_p = byg_diy_block_param('简约通用手机版首页自定义导航5');
$diy_nav6_p = byg_diy_block_param('简约通用手机版首页自定义导航6');
$diy_nav7_p = byg_diy_block_param('简约通用手机版首页自定义导航7');
$diy_nav8_p = byg_diy_block_param('简约通用手机版首页自定义导航8');
$diy_nav9_p = byg_diy_block_param('简约通用手机版首页自定义导航9');
$diy_nav10_p = byg_diy_block_param('简约通用手机版首页自定义导航10');
$discuz_diy = byg_diy_block_sum('简约通用手机版论坛首页自定义导航');
$portal_gg1 = byg_diy_block_sum('简约通用手机版门户首页广告');
$b2_bid = byg_data_block_id('bygsjw2', '简约通用论坛首页最新');
$b3_bid = byg_data_block_id('bygsjw3', '简约通用论坛首页热门');
$b4_bid = byg_data_block_id('bygsjw4', '简约通用论坛首页精华');
$portal_gg2 = byg_diy_block_sum('简约通用手机版门户首页广告2');
$b5_bid = byg_data_block_id('bygsjw5', '简约通用论坛首页图文推荐');
$b6_bid = byg_data_block_id('bygsjw6', '简约通用论坛首页最新活动');
$load_more_bid = byg_data_block_id('开发者：简约设计', '简约通用手机版加载更多');

?>