<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$forum_list_gg = byg_diy_block_sum('简约通用手机版论坛列表页广告');

if($_G['style']['gonggao'] == 'on') {
	$forum_an = DB::fetch_all("SELECT * FROM ".DB::table('forum_announcement')." ORDER BY displayorder ASC LIMIT 1");
}
//From: Dism_taobao_com
?>