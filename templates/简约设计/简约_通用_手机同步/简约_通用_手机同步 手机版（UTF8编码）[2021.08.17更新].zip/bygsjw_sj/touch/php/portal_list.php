<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$about_portal_list_id = DB::result(DB::query("SELECT targettplname FROM ".DB::table('common_diy_data')." WHERE primaltplname = 'portal/list_bygsjw_about' ORDER BY dateline DESC"));
$about_list_id = str_replace('portal/list_','',$about_portal_list_id);

$about_block_sum1 = byg_diy_block_sum('关于我们-介绍');
$about_block_sum2 = byg_diy_block_sum('关于我们-愿景');
$about_block_sum3 = byg_diy_block_sum('联系我们-位置图片');
$about_block_sum4 = byg_diy_block_sum('联系我们-联系方式');
$about_block_sum5 = byg_diy_block_sum('加入我们-职位1');
$about_block_sum6 = byg_diy_block_sum('加入我们-职位2');

?>