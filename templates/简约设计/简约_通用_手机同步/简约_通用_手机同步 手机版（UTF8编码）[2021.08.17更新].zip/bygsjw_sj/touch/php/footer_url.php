<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//更新url
$havedomain = implode('', $_G['setting']['domain']['app']);
if($_G['setting']['rewritestatus'] || !empty($havedomain)) {
	$content = ob_get_contents();
	$content = str_replace('&mobile=2', '', $content);
	$content = output_replace($content);
	ob_end_clean();
	$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
	echo $content;
}
//From: Dism_taobao_com
?>