<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//版块列表，导读列表，帖子内容列表，标签列表，群组列表

//统计主题图片
function byg_threadlist_img_num($tid, $uid, $biaoid) {
	$img_number = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$biaoid.'')." WHERE tid = '$tid' AND uid = '$uid' AND isimage = '1'"));
	return $img_number;
}

//获取主题图片
function byg_threadlist_img($tid, $uid, $num, $biaoid) {
	$list_img = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$biaoid.'')." WHERE tid = '$tid' AND uid = '$uid' AND isimage = '1' ORDER BY dateline ASC LIMIT $num");
	return $list_img;
}

//主题是否精华
function byg_thread_digest($tid) {
	$thread_digest = DB::result(DB::query("SELECT digest FROM ".DB::table('forum_thread')." WHERE tid = '$tid'"));
	return $thread_digest;
}

//获取楼主ID
function byg_thread_authorid($tid) {
	$thread_authorid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$tid'"));
	return $thread_authorid;
}
//From: Dism_taobao_com
?>