<?php echo 'From: DisM.taobao.com';exit;?>

<div class="threadlist">
	<h2 class="thread_tit"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
</div>
<!--{if empty($articlelist)}-->
	<p style="padding:7px 10px;background:#fff;font-size:16px;">{lang search_nomatch}</p>
<!--{else}-->
	<div class="portal_search_list">
		<ul>
			<!--{loop $articlelist $article}-->
			<li>
				<h3><a href="{echo fetch_article_url($article);}">$article[title]</a></h3>
				<p class="">$article[commentnum] {lang a_comment} - $article[viewnum] {lang a_visit}</p>
				<p style="color:#999;">$article[summary]</p>
				<p>
					<span>$article[dateline]</span>
					 -
					<span><a href="home.php?mod=space&uid=$article[uid]&do=profile">$article[username]</a></span>
				</p>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
<!--{/if}-->
<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->

