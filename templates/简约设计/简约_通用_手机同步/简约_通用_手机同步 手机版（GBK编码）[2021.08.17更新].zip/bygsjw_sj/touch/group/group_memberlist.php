<?php echo 'From: DisM.taobao.com';exit;?>

<!--{if $op == 'alluser'}-->
	<style type="text/css">
		.byg_group_box{ margin: .1rem 0; padding: 0 .1rem; background: #fff;}
		.byg_group_box_h2{ height: .42rem; margin-bottom: .01rem; border-bottom: .01rem solid #eee;}
		.byg_group_box_h2 h2{ display: inline-block; height: .3rem; line-height: .3rem; padding: .07rem .04rem .04rem; font-size: .15rem; font-weight: 700; border-bottom: .02rem solid $_G['style']['zhuti'];}
		
		.group_memberlist_admin a{ display: block; padding: .12rem .3rem .12rem 0; line-height: .3rem; border-bottom: 1px dashed #eaeaea; background: #fff url({$_G['style']['styleimgdir']}/jinru.png) no-repeat right center; background-size: .16rem; font-size: .15rem;}
		.group_memberlist_admin a img{ margin: 0 .05rem 0 .03rem; height: .3rem; width: .3rem; vertical-align: top; border-radius: 50%;}
		.group_memberlist_admin a span{ display: inline-block; line-height: .18rem; margin: .06rem .04rem; padding: 0 .05rem; background: $_G['style']['zhuti']; color: #fff; font-size: .12rem; border-radius: .04rem;}
	</style>
	<!--{if $adminuserlist}-->
		<div class="byg_group_box">
			<div class="byg_group_box_h2 cl">
				<h2>{lang group_admin_member}</h2>
			</div>
			<div class="group_memberlist_admin">
				<ul class="cl">
					<!--{loop $adminuserlist $user}-->
					<li>
						<a href="home.php?mod=space&uid=$user[uid]&do=profile"><img src="<!--{avatar($user[uid], middle, true)}-->" alt="$user[username]" />{$user[username]}<!--{if $user['level'] == 1}--><span>{lang group_moderator_title}</span><!--{elseif $user['level'] == 2}--><span>{lang group_moderator_vice_title}</span><!--{/if}--></a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	<!--{/if}-->
	<!--{if $staruserlist || $alluserlist}-->
		<div class="byg_group_box">
			<div class="byg_group_box_h2 cl">
				<h2>{lang member}</h2>
			</div>
			<div class="group_memberlist_admin">
				<ul class="cl">
				<!--{if $staruserlist}-->
					<!--{loop $staruserlist $user}-->
					<li>
						<a href="home.php?mod=space&uid=$user[uid]&do=profile"><img src="<!--{avatar($user[uid], middle, true)}-->" alt="$user[username]" />{$user[username]}<span>{lang group_star_member_title}</span></a>
					</li>
					<!--{/loop}-->
				<!--{/if}-->
				<!--{if $alluserlist}-->
					<!--{loop $alluserlist $user}-->
					<li>
						<a href="home.php?mod=space&uid=$user[uid]&do=profile"><img src="<!--{avatar($user[uid], middle, true)}-->" alt="$user[username]" />{$user[username]}</a>
					</li>
					<!--{/loop}-->
				<!--{/if}-->
				</ul>
			</div>
		</div>
	<!--{/if}-->
	<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->

