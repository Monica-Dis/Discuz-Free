<?php echo 'From: DisM.taobao.com';exit;?>

<style type="text/css">
	.byg_group_create{ margin: .1rem 0; background: #fff;}
	.byg_group_create_h2{ height: .42rem; border-bottom: .01rem solid #eee;}
	.byg_group_create_h2 h2{ display: inline-block; height: .3rem; line-height: .3rem; margin-left: .06rem; padding: .07rem .04rem .04rem; font-size: .15rem; font-weight: 700;}
	
	.group_manage_group table{ table-layout: fixed; width: 100%; overflow: hidden; font-size: .14rem;}
	.group_manage_group tr{ width: 100%; line-height: .2rem; border-bottom: 1px solid #eee;}
	.group_manage_group th{ width: .7rem; padding: .1rem; background: #fcfcfc; color: #666;}
	.group_manage_group td{ padding: .1rem; border-left: 1px solid #eee;}
	.group_manage_group .input_text{ height: .2rem; line-height: .2rem; padding: .02rem .05rem; border: 1px solid #eaeaea; border-radius: .04rem; vertical-align: top; font-size: .14rem; color: #444;}
	.group_manage_group select{ padding: .02rem; background-color: #fff; border-color: #eaeaea; color: #444; font-size: .14rem; border-radius: .04rem;}
	.group_manage_group .input_textarea{ width: 96%; padding: .02rem 2%; font-size: .14rem; border: 0; box-shadow: 0 0 0 1px #eee; color: #444; vertical-align: top;}
	.group_manage_group label{ display: block; margin: .02rem; font-size: .14rem;}
	.group_manage_group_smt{ padding: .11rem;}
	.group_manage_group_smt button{ width: 100%; height: .4rem; line-height: .4rem; border-radius: .06rem; font-size: .16rem; display: block; text-align: center;}
</style>
<div class="byg_group_create" id="main_messaqge">
	<div class="byg_group_create_h2 cl">
		<h2>{lang group_create_new}
			<!--{if $_G['setting']['groupmod']}-->&nbsp;({lang group_create_mod})<!--{/if}-->
		</h2>
	</div>
	<div class="group_manage_group">
		<form method="post" autocomplete="off" name="groupform" id="groupform" class="s_clear" action="forum.php?mod=group&action=create">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="handlekey" value="creategroup" />
			<table cellspacing="0" cellpadding="0" class="" summary="{lang group_create}">
				<tbody>
					<tr>
						<th><strong class="rq">*</strong>{lang group_name}:</th>
						<td>
							<input type="text" name="name" id="name" class="input_text" size="" tabindex="1" value="" autocomplete="off" tabindex="1" />
						</td>
					</tr>
					<tr>
						<th><strong class="rq">*</strong>{lang group_category}:</th>
						<td>
							<select name="parentid" tabindex="2" class="" onchange="ajax_groupselect(this.value);">
								<option value="0">{lang choose_please}</option>
								$groupselect[first]
							</select>
							<em id="secondgroup"></em>
						</td>
					</tr>
					<tr>
						<th>{lang group_description}:</th>
						<td>
							<div class="tedt">
								<div class="area">
									<textarea id="descriptionmessage" name="descriptionnew" tabindex="3" class="input_textarea" rows="5"></textarea>
								</div>
							</div>
						</td>
					</tr>
					<tr>
						<th><strong class="rq">*</strong>{lang group_perm_visit}:</th>
						<td>
							<label class="lb"><input type="radio" name="gviewperm" class="pr" tabindex="4" value="1" checked="checked" />{lang group_perm_all_user}</label>
							<label class="lb"><input type="radio" name="gviewperm" class="pr" value="0" />{lang group_perm_member_only}</label>
						</td>
					</tr>
					<tr>
						<th><strong class="rq">*</strong>{lang group_join_type}:</th>
						<td>
							<label class="lb"><input type="radio" name="jointype" class="pr" tabindex="5" value="0" checked="checked" />{lang group_join_type_free}</label>
							<label class="lb"><input type="radio" name="jointype" class="pr" value="2" />{lang group_join_type_moderate}</label>
							<label class="lb"><input type="radio" name="jointype" class="pr" value="1" />{lang group_join_type_invite}</label>
						</td>
					</tr>
				</tbody>
			</table>
			<div class="group_manage_group_smt">
				<!--{if $_G['group']['buildgroupcredits']}--><p class="mbn rq" style="font-size: .14rem; text-align: center;">{lang group_create_buildcredits} $_G['group']['buildgroupcredits'] $_G['setting']['extcredits'][$creditstransextra]['unit']{$_G['setting']['extcredits'][$creditstransextra]['title']}</p><!--{/if}-->
				<input type="hidden" name="createsubmit" value="true"><button type="submit" tabindex="6">{lang create}</button>
			</div>
		</form>
	</div>
</div>
<script type="text/javascript">
	function ajax_groupselect(obj) {
		jQuery.ajax({
			url: 'forum.php?mod=ajax&action=secondgroup&fupid='+ obj + '&inajax=1',
			type: 'POST',
			dataType: 'xml',
			success: function(s) {
				jQuery('#secondgroup').html(s.lastChild.firstChild.nodeValue);
			}
		});
	}
	<!--{if $_GET['fupid']}-->
		jQuery.ajax({
			url: 'forum.php?mod=ajax&action=secondgroup&fupid=$_GET[fupid]<!--{if $_GET[groupid]}-->&groupid=$_GET[groupid]<!--{/if}-->&inajax=1',
			type: 'POST',
			dataType: 'xml',
			success: function(s) {
				jQuery('#secondgroup').html(s.lastChild.firstChild.nodeValue);
			}
		});
	<!--{/if}-->
</script>

