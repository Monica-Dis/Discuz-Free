<?php echo 'From: DisM.taobao.com';exit;?>

<!--{if $status != 2}-->
	<style type="text/css">
		.group_index_new{ padding: .1rem; background: #fff;}
		.group_index_new .z{ line-height: .2rem; padding: .02rem .06rem .02rem .03rem; font-size: .13rem; background: $_G['style']['zhuti']; color: #fff; border-radius: .04rem;}
		.group_index_new .z img{ height: .14rem; margin: .03rem; vertical-align: top;}
		.group_index_new .y{ line-height: .24rem; font-size: .14rem;}
		
		.threadlist.byg_threadlist{ margin: 0;}
		
		<!--{if $_G['style']['liebiaotu'] == "on"}-->
		.list_img1_box .list_top{ float: left; width: 2.32rem; height: .44rem; margin-bottom: .06rem; padding-right: 0; overflow: hidden;}
		.list_img1_box .list_img1{ float: right; width: 1.15rem; padding: .1rem .1rem .1rem 0;}
		.list_img1_box .list_img1 a{ width: 100%; height: .76rem; padding: 0; border-radius: .04rem; overflow: hidden; display: block; background-position: center center; background-repeat: no-repeat; background-size: cover; -webkit-background-size: cover;}
		.list_img1_box .list_bottom{ float: left; width: 2.28rem; margin-right: 0;}
		<!--{/if}-->
	</style>
	<!--{if helper_access::check_module('group')}-->
	<div class="group_index_new cl">
		<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="z"><img src="{$_G['style']['styleimgdir']}/fatie.png" alt="{lang send_posts}" />{lang send_posts}</a>
		<a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]" class="y">{lang view_all_threads}&rsaquo;</a>
	</div>
	<!--{/if}-->
	<!--{if $newthreadlist['dateline']['data']}-->
		<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_sj/touch/php/forum_forumdisplay_list.php');}-->
		<ul class="threadlist byg_threadlist">
		<!--{loop $newthreadlist['dateline']['data'] $thread}-->
			<!--{eval $biaoid = substr($thread[tid], -1);}-->
			<!--{eval $img_number = byg_threadlist_img_num($thread[tid], $thread[authorid], $biaoid);}-->
			<li class="cl{if $img_number == 1 || $img_number == 2} list_img1_box{/if}">
				<div class="list_top cl">
					<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="over_two">
					<!--{if $thread[folder] == 'lock'}-->
						<img src="{IMGDIR}/folder_lock.gif" alt="����" />
					<!--{elseif $thread['special'] == 1}-->
						<img src="{IMGDIR}/pollsmall.gif" alt="{lang thread_poll}" />
					<!--{elseif $thread['special'] == 2}-->
						<img src="{IMGDIR}/tradesmall.gif" alt="{lang thread_trade}" />
					<!--{elseif $thread['special'] == 3}-->
						<img src="{IMGDIR}/rewardsmall.gif" alt="{lang thread_reward}" />
					<!--{elseif $thread['special'] == 4}-->
						<img src="{IMGDIR}/activitysmall.gif" alt="{lang thread_activity}" />
					<!--{elseif $thread['special'] == 5}-->
						<img src="{IMGDIR}/debatesmall.gif" alt="{lang thread_debate}" />
					<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
					<!--{else}-->
						<img src="{IMGDIR}/folder_$thread[folder].gif" alt="��ͨ" />
					<!--{/if}-->
					{$thread[subject]}</a>
				</div>
				<!--{if $_G['style']['liebiaotu'] == "on"}-->
					<!--{if $img_number == 1 || $img_number == 2}-->
						<!--{eval $list_img1 = byg_threadlist_img($thread[tid], $thread[authorid], 1, $biaoid);}-->
						<!--{loop $list_img1 $list_img1_1}-->
						<div class="list_img1 cl">
							<a href="forum.php?mod=viewthread&tid=$thread[tid]" style="background-image:url({eval echo(getforumimg($list_img1_1[aid],0,230,150))});"></a>
						</div>
						<!--{/loop}-->
					<!--{elseif $img_number > 2}-->
						<ul class="list_img3 cl">
						<!--{eval $list_img3 = byg_threadlist_img($thread[tid], $thread[authorid], 3, $biaoid);}-->
						<!--{loop $list_img3 $list_img3_1}-->
							<li>
								<a href="forum.php?mod=viewthread&tid=$thread[tid]" style="background-image:url({eval echo(getforumimg($list_img3_1[aid],0,230,150))});"></a>
							</li>
						<!--{/loop}-->
						</ul>
					<!--{/if}-->
				<!--{/if}-->
				<div class="list_bottom cl">
					<!--{if $thread['authorid'] && $thread['author']}-->
					<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="z">{$thread[author]}</a>
					<!--{else}-->
					<a href="javascript:;" class="z">{$_G[setting][anonymoustext]}</a>
					<!--{/if}-->
					<em class="z">&nbsp;&nbsp;&nbsp;{$thread[dateline]}&nbsp;&nbsp;</em>
					<span class="y">
						<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="�ظ���"/>{$thread[allreplies]}
					</span>
					<span class="y">
						<img src="{$_G['style']['styleimgdir']}/chakan.png" alt="�鿴��"/>{$thread[views]}&nbsp;&nbsp;
					</span>
				</div>
			</li>
		<!--{/loop}-->
		</ul>
		<!--{if $_G['forum']['threads'] > 10}-->
		<div class="load_more_button">
			<a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang click_to_readmore}</a>
		</div>
		<!--{/if}-->
	<!--{else}-->
		<div class="home_no_data">{lang forum_nothreads}</div>
	<!--{/if}-->
<!--{/if}-->

