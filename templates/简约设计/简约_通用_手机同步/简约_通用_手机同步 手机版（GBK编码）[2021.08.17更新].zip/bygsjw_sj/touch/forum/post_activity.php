<?php echo 'From: DisM.taobao.com';exit;?>

<div class="byg_exfm cl">
	<style type="text/css">
		.byg_exfm{ margin-bottom: .05rem; padding: 0 .1rem; font-size: .15rem; color: #666;}
		.byg_exfm .px{ border: .01rem solid #eee;}
		.byg_sinf dl{ margin-top: .1rem; padding-bottom: .1rem; border-bottom: 1px dashed #eaeaea;}
		.byg_time_dt .byg_spmf{ line-height: .24rem; font-size: .13rem; color: #888;}
		.byg_sinf .byg_time_dd .px{ margin: .05rem 0; width: 1.65rem;}
		.byg_time_dd .bolang{ line-height: .4rem; margin-left: .05rem; color: #888;}
		.byg_sinf .byg_place_dt{ line-height: .3rem;}
		.byg_sinf .byg_place_dd{ position: relative;}
		.byg_sinf .byg_place_dd .px{ width: 2.75rem;}
		.byg_sinf .byg_place_dd textarea{ height: 1rem;}
		.byg_sinf .byg_place_dd span{ position: absolute; top: 0; right: .08rem; height: .3rem; line-height: .3rem; color: #999;}
		.byg_sinf .byg_place_dd p{ line-height: .3rem; color: #999; font-size: .13rem;}
		#activitytypelist{ position: absolute; top: .01rem; right: .01rem; height: .28rem; line-height: .28rem; padding-left: .03rem; border-color: #eee; border-radius: .04rem; color: #888; font-size: .13rem;}
		.byg_sinf .byg_gender_dd select{ width: 2.77rem; height: .3rem; line-height: .3rem; padding-left: .02rem; border-color: #eee; border-radius: .05rem; color: #888; font-size: .15rem;}
		.byg_sinf .byg_optional_data li{ float: left; padding: .05rem .1rem; font-size: .14rem; color: #888;}
		.byg_activityimg_file{ margin-top: .02rem; width: 2.75rem; height: .25rem; line-height: .25rem; overflow: hidden;}
		#activityattach_image img{ margin-top: .1rem; border-radius: .1rem; max-width: 100%; vertical-align: top;}
	</style>
	<div class="byg_sinf">
		<dl class="cl">
			<dt class="byg_time_dt cl">
				<div class="z"><span class="rq">*</span>{lang post_event_time}:</div>
				<div class="byg_spmf y">
					<label for="activitytime"><input type="checkbox" id="activitytime" name="activitytime" class="pc" onclick="if(this.checked) {document.getElementById('certainstarttime').style.display='none';document.getElementById('uncertainstarttime').style.display='';} else {document.getElementById('certainstarttime').style.display='';document.getElementById('uncertainstarttime').style.display='none';}" value="1" {if $activity['starttimeto']}checked{/if} tabindex="1" />{lang activity_starttime_endtime}</label>
				</div>
			</dt>
			<dd class="byg_time_dd cl">
				<div id="certainstarttime" {if $activity['starttimeto']}style="display: none"{/if}>
					<script type="text/javascript" src="{$_G['style']['styleimgdir']}/date.js?{VERHASH}"></script>
					<input type="text" name="starttimefrom[0]" id="starttimefrom_0" class="px" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" style="width: 100%;" />
				</div>
				<div id="uncertainstarttime" {if !$activity['starttimeto']}style="display: none"{/if} class="cl">
					<input type="text" name="starttimefrom[1]" id="starttimefrom_1" class="px z" onclick="showcalendar(event, this, true)" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" /><span class="z bolang">~</span><input onclick="showcalendar(event, this, true)" type="text" autocomplete="off" id="starttimeto" name="starttimeto" class="px y" value="{if $activity['starttimeto']}$activity[starttimeto]{/if}" tabindex="1" />
					<script type="text/javascript">
						new Rolldate({
							el: '#starttimefrom_0',
							format: 'YYYY-MM-DD hh:mm',
							beginYear: 2000,
							endYear: 2100
						});
						new Rolldate({
							el: '#starttimefrom_1',
							format: 'YYYY-MM-DD hh:mm',
							beginYear: 2000,
							endYear: 2100
						});
						new Rolldate({
							el: '#starttimeto',
							format: 'YYYY-MM-DD hh:mm',
							beginYear: 2000,
							endYear: 2100
						});
					</script>
				</div>
			</dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><span class="rq">*</span><label for="activityplace">{lang activity_space}:</label></dt>
			<dd class="byg_place_dd y">
				<input type="text" name="activityplace" id="activityplace" class="px oinf" value="$activity[place]" tabindex="1" />
			</dd>
		</dl>
		<dl class="cl">
			<!--{if $_GET[action] == 'newthread'}-->
			<dt class="byg_place_dt z"><label for="activitycity">{lang activity_city}:</label></dt>
			<dd class="byg_place_dd y"><input name="activitycity" id="activitycity" class="px" type="text" tabindex="1" /></dd>
			<!--{/if}-->
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><span class="rq">*</span><label for="activityclass">{lang activiy_sort}:</label></dt>
			<dd class="byg_place_dd y">
				<input type="text" id="activityclass" name="activityclass" class="px" value="$activity[class]" tabindex="1" />
				<!--{if $activitytypelist}-->
				<select id="activitytypelist" onchange="$('#activityclass').val($('#activitytypelist').find('option:selected').val());">
					<option value="" selected="selected">ѡ�����</option>
					<!--{loop $activitytypelist $type}-->
					<option value="{$type}">{$type}</option>
					<!--{/loop}-->
				</select>
				<!--{/if}-->
			</dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><label for="activitynumber">{lang activity_need_member}:</label></dt>
			<dd class="byg_place_dd y">
				<input type="text" name="activitynumber" id="activitynumber" class="px" value="$activity[number]" tabindex="1" />
			</dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><label for="gender">�����Ա�:</label></dt>
			<dd class="byg_gender_dd y">
				<select name="gender" id="gender">
					<option value="0" {if !$activity['gender']}selected="selected"{/if}>{lang unlimited}</option>
					<option value="1" {if $activity['gender'] == 1}selected="selected"{/if}>{lang male}</option>
					<option value="2" {if $activity['gender'] == 2}selected="selected"{/if}>{lang female}</option>
				</select>
			</dd>
		</dl>
		<!--{if $_G['setting']['activityfield']}-->
		<dl class="cl">
			<dt class="byg_place_dt">{lang optional_data}:</dt>
			<dd>
				<ul class="byg_optional_data cl">
				<!--{loop $_G['setting']['activityfield'] $key $val}-->
				<li><label for="userfield_$key"><input type="checkbox" name="userfield[]" id="userfield_$key" class="pc" value="$key"{if $activity['ufield']['userfield'] && in_array($key, $activity['ufield']['userfield'])} checked="checked"{/if} />$val</label></li>
				<!--{/loop}-->
				</ul>
			</dd>
		</dl>
		<!--{/if}-->
		<!--{if $_G['setting']['activityextnum']}-->
		<dl class="cl">
			<dt class="byg_place_dt"><label for="extfield">{lang other_data}:</label></dt>
			<dd class="byg_place_dd">
				<textarea name="extfield" id="extfield" class="pt"><!--{if $activity['ufield']['extfield']}-->$activity[ufield][extfield]<!--{/if}--></textarea>
				<p>{lang post_activity_message} $_G['setting']['activityextnum'] {lang post_option}</p>
			</dd>
		</dl>
		<!--{/if}-->
		<!--{if $_G['setting']['activitycredit']}-->
		<dl class="cl">
			<dt class="byg_place_dt z"><label for="activitycredit">{lang consumption_credit}:</label></dt>
			<dd class="byg_place_dd y">
				<input type="text" name="activitycredit" id="activitycredit" class="px" value="$activity[credit]" />
				<span class="byg_place_dd_span">{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</span>
				<p>{lang user_consumption_money}</p>
			</dd>
		</dl>
		<!--{/if}-->
		<dl class="cl">
			<dt class="byg_place_dt z"><label for="cost">{lang activity_payment}:</label></dt>
			<dd class="byg_place_dd y">
				<input type="text" name="cost" id="cost" class="px" value="$activity[cost]" tabindex="1" />
				<span>{lang payment_unit}</span>
			</dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><label for="activityexpiration">{lang post_closing}:</label></dt>
			<dd class="byg_place_dd y">
				<input type="text" name="activityexpiration" id="activityexpiration" class="px" autocomplete="off" value="$activity[expiration]" tabindex="1" />
				<script type="text/javascript">
					new Rolldate({
						el: '#activityexpiration',
						format: 'YYYY-MM-DD hh:mm',
						beginYear: 2000,
						endYear: 2100
					});
				</script>
			</dd>
		</dl>
		<!--{if $allowpostimg}-->
		<dl class="cl">
			<dt class="byg_place_dt z">{lang post_topic_image}:</dt>
			<dd class="y">
				<input type="file" name="Filedata" accept="image/jpg,image/jpeg,image/gif,image/png,image/bmp" class="byg_activityimg_file">
			</dd>
			<dd>
				<input type="hidden" name="activityaid" id="activityaid" {if $activityattach[attachment]}value="$activityattach[aid]" {/if}/>
				<input type="hidden" name="activityaid_url" id="activityaid_url" />
				<div id="activityattach_image">
				<!--{if $activityattach[attachment]}-->
					<img src="$activityattach[url]/{if $activityattach['thumb']}{eval echo getimgthumbname($activityattach['attachment']);}{else}$activityattach[attachment]{/if}" />
				<!--{/if}-->
				</div>
			</dd>
		</dl>
		<!--{/if}-->
	</div>
</div>
<script type="text/javascript" reload="1">
	$(document).on('change', '.byg_activityimg_file', function() {
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

		uploadsuccess = function(data) {
			if(data == '') {
				popup.open('{lang uploadpicfailed}', 'alert');
			}
			var dataarr = data.split('|');
			if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
				popup.close();
				$('#activityaid').val(dataarr[3]);
				$('#activityaid_url').val('/' + dataarr[5]);
				$('#activityattach_image').html('<img src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" />');
			} else {
				var sizelimit = '';
				if(dataarr[7] == 'ban') {
					sizelimit = '{lang uploadpicatttypeban}';
				} else if(dataarr[7] == 'perday') {
					sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
				} else if(dataarr[7] > 0) {
					sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
				}
				popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
			}
		};

		if(typeof FileReader != 'undefined' && this.files[0]) {//note ֧��html5�ϴ�������

			$.buildfileupload({
				uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
				files:this.files,
				uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
				uploadinputname:'Filedata',
				maxfilesize:"$swfconfig[max]",
				success:uploadsuccess,
				error:function() {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
			});

		} else {

			$.ajaxfileupload({
				url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
				data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
				dataType:'text',
				fileElementId:'filedata',
				success:uploadsuccess,
				error: function() {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
			});

		}
	});
</script>
