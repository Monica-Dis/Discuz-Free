<?php echo 'From: DisM.taobao.com';exit;?>

<!--{if $_G['forum_threadpay']}-->
<style>
	.viewthread_pay_fixed{ width: 100%; height: .5rem; background: #fff; border-top: 1px solid #ddd; position: fixed; left: 0; bottom: 0; z-index: 95;}
	.viewthread_pay_fixed a{ float: left; width: 1rem; line-height: .5rem; text-align: center; font-size: .16rem; color: #999;}
	.viewthread_pay_fixed a img{ width: .22rem; height: .22rem; margin: .14rem .01rem; vertical-align: top;}
	.viewthread_pay_fixed .post_edit{ border-right: 1px solid #ddd;}
	.viewthread_pay_fixed .pay_thread{ float: right; width: 1.72rem; background: $_G['style']['zhuti']; color: #fff; font-weight: 700;}
	.viewthread_pay_fixed .pay_thread span{ display: inline-block; margin-left: .02rem; font-weight: 400; font-size: .13rem;}
	.locked{ text-align: center; font-weight: 700;}
	.locked .byg_viewpay{ display: none;}
	.locked .right{ display: block; font-size: .14rem; color: #999;}
</style>
<div class="viewthread_pay_fixed">
	<a {if $fastpost}href="javascript:;"{else}href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" onclick="return landingPrompt(2);"{/if} title="{lang reply}" class="post_edit">
		<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="�ظ�"/>�ظ�
	</a>
	<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" title="{lang favorite}" onclick="favorite_thread_ajax(this.id);return false;" class="pay_favorite" id="favorite_thread_{$_G[tid]}">
		<img src="{$_G['style']['styleimgdir']}/hui_shoucang.png" alt="�ղ�"/>�ղ�
	</a>
	<a href="javascript:;" onclick="return landingPrompt();" class="pay_thread">��������<span>({$_G[forum_thread][price]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</span></a>
</div>
<script type="text/javascript">
	jQuery(".pay_thread").attr("href", jQuery(".locked .byg_viewpay").attr("href"));
</script>
<!--{else}-->
<div class="post_fixed cl">
	<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" title="��������" onclick="return landingPrompt();" class="post_avatar"><!--{avatar($_G[uid],middle)}--></a>
	<a {if $fastpost}href="javascript:;"{else}href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" onclick="return landingPrompt(2);"{/if} title="{lang reply}" class="post_edit">{lang send_reply_fast_tip}</a>
	<a href="javascript:;" class="post_fast_reply"><img src="{$_G['style']['styleimgdir']}/hui_huifu.png" alt="�ظ�"/><!--{if $_G['forum_thread']['allreplies']}--><span><!--{echo cutstr($_G['forum_thread']['allreplies'],3,'')}--></span><!--{/if}--></a>
	<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" title="{lang favorite}" onclick="favorite_thread_ajax(this.id);return false;" class="post_favorite" id="favorite_thread_{$_G[tid]}"><img src="{$_G['style']['styleimgdir']}/hui_shoucang.png" alt="�ղ�"/><!--{if $_G['forum_thread']['favtimes']}--><span><!--{echo cutstr($_G['forum_thread']['favtimes'],3,'')}--></span><!--{/if}--></a>
	<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="post_return"><img src="{$_G['style']['styleimgdir']}/hui_fanhui.png" alt="����"/></a>
</div>
<script type="text/javascript">
	jQuery(".post_fast_reply").click(function(){jQuery("html, body").animate({scrollTop: jQuery(".postlist_title").offset().top}, 500);});
</script>
<!--{/if}-->

<div id="post_new"></div>
<div class="cover_div"></div>
<div class="plc plc_xin cl">
	<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes&mobile=2">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="pi">
		<ul class="fastpost">
			<!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->
			<li style="margin-bottom:.1rem;">
				<select id="stand" name="stand" >
					<option value="">{lang debate_viewpoint}</option>
					<option value="0">{lang debate_neutral}</option>
					<option value="1">{lang debate_square}</option>
					<option value="2">{lang debate_opponent}</option>
				</select>
			</li>
			<!--{/if}-->
			<li style="position:relative;">
				<textarea name="message" rows="5" placeholder="&nbsp;{lang send_reply_fast_tip}" class="pt" id="fastpostmessage"></textarea>
				<a href="javascript:;" class="reply_y reply_y_t">ȡ��</a>
				<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" onclick="return landingPrompt(2);" class="reply_y reply_y_c">�߼�</a>
				<input type="button" value="{lang reply}" class="reply_y reply_y_b" name="replysubmit" id="fastpostsubmit">
			</li>
			<li id="fastpostsubmitline">
				<!--{if $secqaacheck || $seccodecheck}--><!--{subtemplate common/seccheck}--><!--{/if}-->
				<!--{hook/viewthread_fastpost_button_mobile}-->
			</li>
		</ul>
	</div>
    </form>
</div>
<script type="text/javascript">
	jQuery(".post_edit").click(function(){jQuery(".plc_xin").slideToggle(0);});
	jQuery(".post_edit").click(function(){jQuery(".cover_div").slideToggle(0);});
	jQuery(".cover_div").click(function(){jQuery(".plc_xin").slideToggle(0);});
	jQuery(".cover_div").click(function(){jQuery(".cover_div").slideToggle(0);});
	jQuery(".reply_y_t").click(function(){jQuery(".plc_xin").slideToggle(0);});
	jQuery(".reply_y_t").click(function(){jQuery(".cover_div").slideToggle(0);});
	(function() {
		var form = jQuery('#fastpostform');
		<!--{if !$allowpostreply}-->
		jQuery('#fastpostmessage').on('focus', function() {
			<!--{if !$_G[uid]}-->
				jQuery(".cover_top").slideToggle(0);
				jQuery(".landingPrompt").slideToggle(500);
			<!--{else}-->
				popup.open('{lang nopostreply}', 'alert');
			<!--{/if}-->
			this.blur();
		});
		<!--{else}-->
		jQuery('#fastpostmessage').on('focus', function() {
			var obj = jQuery(this);
			if(obj.attr('') == '') {
				obj.attr('value', '');
				obj.removeClass('');
				obj.attr('', '');
				jQuery('#fastpostsubmitline').css('', '');
			}
		})
		.on('blur', function() {
			var obj = jQuery(this);
			if(obj.attr('value') == '') {
				obj.addClass('');
				obj.attr('value', '');
				obj.attr('color', '');
			}
		});
		<!--{/if}-->

		jQuery('#fastpostsubmit').on('click', function() {
			var msgobj = jQuery('#fastpostmessage');
			if(msgobj.val() == '') {
				msgobj.attr('value', '');
			}
			jQuery.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey=fastpost&loc=1&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});

		jQuery('#replyid').on('click', function() {
			jQuery(document).scrollTop(jQuery(document).height());
			jQuery('#fastpostmessage')[0].focus();
		});

	})();

	function succeedhandle_fastpost(locationhref, message, param) {
		var pid = param['pid'];
		var tid = param['tid'];
		if(pid) {
			jQuery.ajax({
				type:'POST',
				url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid + '&mobile=2',
				dataType:'xml'
			})
			.success(function(s) {
				jQuery('#post_new').append(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = 'forum.php?mod=viewthread&tid=' + tid;
				popup.close();
			});
			jQuery(".plc_xin").slideToggle(0);
			jQuery(".cover_div").slideToggle(0);
			jQuery(".no_reply").hide();
		} else {
			if(!message) {
				message = '{lang postreplyneedmod}';
			}
			popup.open(message, 'alert');
		}
		jQuery('#fastpostmessage').attr('value', '');
		if(param['sechash']) {
			jQuery('.seccodeimg').click();
		}
	}

	function errorhandle_fastpost(message, param) {
		popup.open(message, 'alert');
	}
</script>

