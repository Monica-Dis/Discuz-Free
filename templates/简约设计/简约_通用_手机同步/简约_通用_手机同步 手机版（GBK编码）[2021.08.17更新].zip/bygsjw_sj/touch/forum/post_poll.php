<?php echo 'From: DisM.taobao.com';exit;?>

<input type="hidden" name="polls" value="yes" />
<div class="byg_exfm cl">
	<style type="text/css">
		.byg_sinf h4{ display: block; padding: .1rem; background: #f5f5f5; font-size: .14rem; color: #666;}
		.byg_sinf h4 input{ vertical-align: top; margin: .04rem .02rem;}
		.byg_pollm_c_1{ padding: 0 .1rem; border-top: 1px solid #eaeaea;}
		.byg_pollm_c_1p{ padding: .12rem 0; border-bottom: 1px dashed #eaeaea;}
		.byg_poll_del img{ vertical-align: top; width: .2rem; height: .2rem; margin: .05rem 0;}
		.byg_polloption_op{ line-height: .3rem; margin-right: .05rem; font-size: .15rem; color: #888;}
		.byg_pollm_c_1p .px.byg_poll_order{ width: .25rem; margin-right: .05rem; font-size: .13rem;}
		.byg_pollm_c_1p .px{ float: left; width: 2.15rem; border: .01rem solid #eee;}
		.byg_newpoll_icon{ float: left; position: relative; margin-left: .08rem; width: .3rem; height: .3rem;}
		.byg_newpoll, .byg_newpoll_icon img{ position: absolute; top: .02rem; left: .02rem; width: .26rem; height: .26rem; overflow: hidden;}
		.byg_newpoll{ z-index: 2; opacity: 0;}
		.byg_newpoll_icon img{ z-index: 1;}
		.pollimg_icon{ margin-left: .06rem; float: left;}
		.pollimg_icon img{ margin: .03rem .01rem; width: .22rem; height: .22rem; vertical-align: top; border: .01rem solid #ddd; border-radius: .04rem;}
		.pollimg_view{ float: left; margin-top: .1rem; padding: .1rem; background: #ffc; border-radius: .12rem;}
		.pollimg_view img{ max-width: 100%; vertical-align: top; border-radius: .1rem;}
		.byg_addpolloption a{ display: inline-block; margin: .1rem 0; font-size: .14rem; color: #06f;}
		.byg_sadd{ padding: 0 .1rem; border-bottom: 1px solid #eaeaea; font-size: .15rem; color: #888;}
		.byg_sadd .byg_mbn{ padding: .12rem .02rem; border-top: 1px solid #eee;}
		.byg_sadd .byg_mbn .px{ width: 1rem; border: .01rem solid #eee;}
		
		.byg_pollm_c_2{ padding: .02rem .1rem;}
		.byg_pollm_c_2 .pt{ margin: .1rem 0; height: 1rem;}
		.byg_pollm_c_2 p{ margin-bottom: .1rem; font-size: .13rem; color: #ff9800;}
	</style>
	<div class="byg_sinf byg_sppoll">
		<input type="hidden" name="fid" value="$_G[fid]" />
		<!--{if $_GET[action] == 'newthread'}-->
			<input type="hidden" name="tpolloption" value="1" />
			<div class="cl">
				<h4 class="cl">
					<em>{lang post_poll_options}: </em>
					{lang post_poll_comment} &nbsp;
					<span class="y"><input id="pollchecked" type="checkbox" class="" onclick="switchpollm(1)" /><label for="pollchecked">{lang post_single_frame_mode}</label></span>
				</h4>
			</div>
			<div id="pollm_c_1" class="byg_pollm_c_1">
				<span id="polloption_new"></span>
				<p id="polloption_hidden" style="display: none">
					<a href="javascript:;" class="y byg_poll_del" onclick="delpolloption(this)"><img src="{$_G['style']['styleimgdir']}/hong_shanchu.png" alt="ɾ��"/></a>
					<span class="z byg_polloption_op">ѡ��</span>
					<input type="text" name="polloption[]" class="px vm" autocomplete="off" tabindex="1" />
					<a href="javascript:;" class="byg_newpoll_icon">
						<input type="file" name="Filedata" accept="image/jpg,image/jpeg,image/gif,image/png,image/bmp" pollimg_id="bygsjw0" class="byg_newpoll">
						<img src="{$_G['style']['styleimgdir']}/hui_shangchuantu.png" alt="�ϴ�ͼƬ"/>
					</a>
					<span onclick="pollimg_view_on('bygsjw0')" id="pollUploadProgress" class="pollimg_icon" style="display: none;"></span>
					<span id="pollimg_view_box" class="pollimg_view" style="display: none;"></span>
				</p>
				<div class="byg_addpolloption"><a href="javascript:;" onclick="addpolloption()">+{lang post_poll_add}</a></div>
			</div>
			<div id="pollm_c_2" class="byg_pollm_c_2" style="display:none">
				<textarea name="polloptions" class="pt" onchange="switchpollm(0)" /></textarea>
				<p class="cl">{lang post_poll_comment_s}</p>
			</div>
		<!--{else}-->
			<div class="cl">
				<h4 class="cl">
					<em>{lang post_poll_options}: </em>
					{lang post_poll_comment} &nbsp;
				</h4>
			</div>
			<div id="pollm_c_1" class="byg_pollm_c_1">
			<!--{loop $poll['polloption'] $key $option}-->
				<!--{eval $ppid = $poll['polloptionid'][$key];}-->
				<p class="cl byg_pollm_c_1p">
					<input type="hidden" name="polloptionid[{$poll[polloptionid][$key]}]" value="$poll[polloptionid][$key]" />
					<input type="text" name="displayorder[{$poll[polloptionid][$key]}]" class="px vm byg_poll_order" autocomplete="off" tabindex="1" value="$poll[displayorder][$key]" />
					<input type="text" name="polloption[{$poll[polloptionid][$key]}]" class="px vm" autocomplete="off" tabindex="1" value="$option"{if !$_G['group']['alloweditpoll']} readonly="readonly"{/if} />
					<!--img src="$poll[imginfo][$ppid][small]" class="cur1" /-->
					<!--{if $poll[isimage]}-->
					<span onclick="pollimg_view_on('{$key}')" id="pollUploadProgress_{$key}" class="pollimg_icon" style="margin-left: .1rem;">
						<img src="{if $poll[imginfo][$ppid][small]}$poll[imginfo][$ppid][small]{else}static/image/common/nophoto.gif{/if}">
					</span>
					<span id="pollimg_view_box{$key}" class="pollimg_view" style="display: none;">
						<img src="{if $poll[imginfo][$ppid][big]}$poll[imginfo][$ppid][big]{else}static/image/common/nophoto.gif{/if}">
						<input type="hidden" name="pollimage[{$poll[polloptionid][$key]}]" value="$poll[imginfo][$ppid][aid]" />
					</span>
					<!--{/if}-->
				</p>
			<!--{/loop}-->
				<span id="polloption_new"></span>
				<p id="polloption_hidden" style="display: none">
					<a href="javascript:;" class="y byg_poll_del" onclick="delpolloption(this)"><img src="{$_G['style']['styleimgdir']}/hong_shanchu.png" alt="ɾ��"/></a>
					<input type="text" name="displayorder[]" class="px vm byg_poll_order" autocomplete="off" tabindex="1" />
					<input type="text" name="polloption[]" class="px vm" autocomplete="off" tabindex="1" />
					<a href="javascript:;" class="byg_newpoll_icon">
						<input type="file" name="Filedata" accept="image/jpg,image/jpeg,image/gif,image/png,image/bmp" pollimg_id="bygsjw0" class="byg_newpoll">
						<img src="{$_G['style']['styleimgdir']}/hui_shangchuantu.png" alt="�ϴ�ͼƬ"/>
					</a>
					<span onclick="pollimg_view_on('bygsjw0')" id="pollUploadProgress" class="pollimg_icon" style="display: none;"></span>
					<span id="pollimg_view_box" class="pollimg_view" style="display: none;"></span>
				</p>
				<div class="byg_addpolloption"><a href="javascript:;" onclick="addpolloption()">+{lang post_poll_add}</a></div>
			</div>
		<!--{/if}-->
	</div>
	<div class="byg_sadd">
		<p class="byg_mbn">
			<label for="maxchoices">{lang post_poll_allowmultiple}</label>
			<input type="text" name="maxchoices" id="maxchoices" class="px" value="{if $_GET[action] == 'edit' && $poll[maxchoices]}$poll[maxchoices]{else}1{/if}" tabindex="1" /> {lang post_option}
		</p>
		<p class="byg_mbn">
			<label for="polldatas">{lang post_poll_expiration}</label>
			<input type="text" name="expiration" id="polldatas" class="px" value="{if $_GET[action] == 'edit'}{if !$poll[expiration]}0{elseif $poll[expiration] < 0}{lang poll_close}{elseif $poll[expiration] < TIMESTAMP}{lang poll_finish}{else}{echo (round(($poll[expiration] - TIMESTAMP) / 86400))}{/if}{/if}" tabindex="1" /> {lang days}
		</p>
		<p class="byg_mbn">
			<input type="checkbox" name="visibilitypoll" id="visibilitypoll" class="pc" value="1"{if $_GET[action] == 'edit' && !$poll[visible]} checked{/if} tabindex="1" /><label for="visibilitypoll">{lang poll_after_result}</label>
		</p>
		<p class="byg_mbn">
			<input type="checkbox" name="overt" id="overt" class="pc" value="1"{if $_GET[action] == 'edit' && $poll[overt]} checked{/if} tabindex="1" /><label for="overt">{lang post_poll_overt}</label>
		</p>
	</div>
</div>

<script type="text/javascript" reload="1">
	var maxoptions = parseInt('$_G[setting][maxpolloptions]');
	<!--{if $_GET[action] == 'newthread'}-->
	var curoptions = 0;
	var curnumber = 1;
	addpolloption();
	addpolloption();
	addpolloption();
	<!--{else}-->
	var curnumber = curoptions = <!--{echo count($poll['polloption'])}-->;
	<!--{/if}-->
	
	function addpolloption() {
		if(curoptions < maxoptions) {
			var proid = 'pollUploadProgress_'+curnumber;
			var pollstr = document.getElementById('polloption_hidden').innerHTML.replace('pollUploadProgress', proid);
		 	pollstr = pollstr.replace(/bygsjw0/g, curnumber);
		 	pollstr = pollstr.replace('pollimg_view_box', 'pollimg_view_box' + curnumber);
			document.getElementById('polloption_new').outerHTML = '<p class="cl byg_pollm_c_1p">' + pollstr + '</p>' + document.getElementById('polloption_new').outerHTML;
			curoptions++;
			curnumber++;
		} else {
			popup.open('�Ѵﵽ���ͶƱ��' + maxoptions + '!', 'alert');
		}
	}
	
	function delpolloption(obj) {
		obj.parentNode.parentNode.removeChild(obj.parentNode);
		curoptions--;
	}
	
	function pollimg_view_on(a) {
		var obj = $('#pollimg_view_box' + a);
		var dis = obj.css("display");
		if(dis == "none"){ 
			obj.css("display", "block"); 
		}else{ 
			obj.css("display", "none"); 
		} 
	}
	
	function switchpollm(swt) {
		t = document.getElementById('pollchecked').checked && swt ? 2 : 1;
		var v = '', q = 0;
		for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
			var e = document.getElementById('postform').elements[i];
			if(!isUndefined(e.name)) {
				if(e.name.match('^polloption')) {
					if(t == 2 && e.tagName == 'INPUT' && e.value) {
						v += (q > 0 ? "\n" : '') + e.value;
						q++;
					} else if(t == 1 && e.tagName == 'TEXTAREA' && e.value) {
						v += e.value;
					}
				}
			}
		}
		if(t == 1) {
			var a = v.split('\n');
			var pcount = 0;
			for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
				var e = document.getElementById('postform').elements[i];
				if(!isUndefined(e.name)) {
					if(e.name.match('^polloption')) {
						pcount++;
						if(e.tagName == 'INPUT') e.value = '';
					}
				}
			}
			for(var i = 0; i < a.length - pcount + 2; i++) {
				addpolloption();
			}
			var ii = 0;
			for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
				var e = document.getElementById('postform').elements[i];
				if(!isUndefined(e.name)) {
					if(e.name.match('^polloption') && e.tagName == 'INPUT' && a[ii]) {
						e.value = a[ii++];
					}
				}
			}
		} else if(t == 2) {
			document.getElementById('postform').polloptions.value = trim(v);

		}
		document.getElementById('postform').tpolloption.value = t;
		if(swt) {
			display('pollm_c_1');
			display('pollm_c_2');
		}
	}
	
	function trim(str) {
		return str.replace(/^\s*(.*?)[\s\n]*$/g, '$1');
	}
	
	function display(id) {
		var obj = document.getElementById(id);
		if(obj.style.visibility) {
			obj.style.visibility = obj.style.visibility == 'visible' ? 'hidden' : 'visible';
		} else {
			obj.style.display = obj.style.display == '' ? 'none' : '';
		}
	}
	
	$(document).on('change', '.byg_newpoll', function() {
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
			var pollimg_id = $(this).attr('pollimg_id');

			uploadsuccess = function(data) {
				if(data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
				var byg_dataarr = eval("("+data+")");
				if(byg_dataarr.errorcode == 0 && byg_dataarr.aid) {
					popup.close();
					$('#pollimg_view_box' + pollimg_id).html('<img src="' + byg_dataarr.bigimg + '"><input type="hidden" name="pollimage[]" value="' + byg_dataarr.aid + '">');
					$('#pollUploadProgress_' + pollimg_id).html('<img src="' + byg_dataarr.smallimg + '">');
					$('#pollUploadProgress_' + pollimg_id).css('display','');
				} else {
					popup.open(STATUSMSG[byg_dataarr.errorcode], 'alert');
				}
			};

			if(typeof FileReader != 'undefined' && this.files[0]) {//note ֧��html5�ϴ�������
				
				$.buildfileupload({
					uploadurl:'misc.php?mod=swfupload&action=swfupload&operation=poll&fid=$_G[fid]',
					files:this.files,
					uploadformdata:{"uid":"$_G[uid]", "hash":"$swfconfig[hash]"},
					uploadinputname:'Filedata',
					maxfilesize:"2048",
					success:uploadsuccess,
					error:function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			} else {

				$.ajaxfileupload({
					url:'misc.php?mod=swfupload&action=swfupload&operation=poll&fid=$_G[fid]',
					data:{"uid":"$_G[uid]", "hash":"$swfconfig[hash]"},
					dataType:'text',
					fileElementId:'filedata',
					success:uploadsuccess,
					error: function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			}
	});
	
</script>

