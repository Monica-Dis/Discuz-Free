<?php echo 'From: DisM.taobao.com';exit;?>

<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
	<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_sj/touch/php/forum_forumdisplay_list.php');}-->
	<!--{loop $_G['forum_threadlist'] $key $thread}-->
		<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
			{eval continue;}
		<!--{/if}-->
		<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
			{eval $displayorder_thread = 1;}
		<!--{/if}-->
		<!--{if $thread['moved']}-->
			<!--{eval $thread[tid]=$thread[closed];}-->
		<!--{/if}-->
		<!--{eval $biaoid = substr($thread[tid], -1);}-->
		<!--{eval $img_number = byg_threadlist_img_num($thread[tid], $thread[authorid], $biaoid);}-->
		<li class="cl{if $img_number == 1 || $img_number == 2} list_img1_box{/if}">
			<!--{hook/forumdisplay_thread_mobile $key}-->
			<div class="list_top cl">
				<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="over_two">
				<!--{if $thread[folder] == 'lock'}-->
					<img src="{IMGDIR}/folder_lock.gif" alt="����" />
				<!--{elseif $thread['special'] == 1}-->
					<img src="{IMGDIR}/pollsmall.gif" alt="{lang thread_poll}" />
				<!--{elseif $thread['special'] == 2}-->
					<img src="{IMGDIR}/tradesmall.gif" alt="{lang thread_trade}" />
				<!--{elseif $thread['special'] == 3}-->
					<img src="{IMGDIR}/rewardsmall.gif" alt="{lang thread_reward}" />
				<!--{elseif $thread['special'] == 4}-->
					<img src="{IMGDIR}/activitysmall.gif" alt="{lang thread_activity}" />
				<!--{elseif $thread['special'] == 5}-->
					<img src="{IMGDIR}/debatesmall.gif" alt="{lang thread_debate}" />
				<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
				<!--{else}-->
					<img src="{IMGDIR}/folder_$thread[folder].gif" alt="��ͨ" />
				<!--{/if}-->
				<!--{if $thread['price'] > 0}-->
					<!--{if $thread['special'] == '3'}-->
					<span class="list_typename">{lang thread_reward}{$thread[price]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}</span>
					<!--{else}-->
					<span class="list_typename">{lang price}{$thread[price]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}</span>
					<!--{/if}-->
				<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
					<span class="list_typename">{lang reward_solved}</span>
				<!--{/if}-->
				<!--{if $thread[typename]}--><span class="list_typename">{$thread[typename]}</span><!--{/if}-->
				{$thread[subject]}</a>
			</div>
			<!--{if $_G['style']['liebiaotu'] == "on"}-->
				<!--{if $img_number == 1 || $img_number == 2}-->
					<!--{eval $list_img1 = byg_threadlist_img($thread[tid], $thread[authorid], 1, $biaoid);}-->
					<!--{loop $list_img1 $list_img1_1}-->
					<div class="list_img1 cl">
						<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" style="background-image:url({eval echo(getforumimg($list_img1_1[aid],0,230,150))});"></a>
					</div>
					<!--{/loop}-->
				<!--{elseif $img_number > 2}-->
					<ul class="list_img3 cl">
					<!--{eval $list_img3 = byg_threadlist_img($thread[tid], $thread[authorid], 3, $biaoid);}-->
					<!--{loop $list_img3 $list_img3_1}-->
						<li>
							<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" style="background-image:url({eval echo(getforumimg($list_img3_1[aid],0,230,150))});"></a>
						</li>
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
			<!--{/if}-->
			<div class="list_bottom cl">
				<!--{eval $list_thread_digest = byg_thread_digest($thread[tid]);}-->
				<!--{if $list_thread_digest > 0}-->
				<em class="z jinghua_icon"><img src="{IMGDIR}/digest_$thread[digest].gif" alt="����"/></em>
				<!--{elseif $_G['style']['liebiaotu'] != "on"}-->
					<!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
					<em class="z jinghua_icon"><img src="{STATICURL}image/filetype/image_s.gif" alt="ͼƬ" style="height: .16rem; margin: .03rem .02rem 0 0;"/></em>
					<!--{/if}-->
				<!--{/if}-->
				<!--{if $thread['authorid'] && $thread['author']}-->
				<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="z">{$thread[author]}</a>
				<!--{else}-->
				<a href="javascript:;" class="z">{$_G[setting][anonymoustext]}</a>
				<!--{/if}-->
				<em class="z">&nbsp;&nbsp;&nbsp;{$thread[dateline]}&nbsp;&nbsp;</em>
				<span class="y">
					<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="�ظ���"/>{$thread[allreplies]}
				</span>
				<span class="y">
					<img src="{$_G['style']['styleimgdir']}/chakan.png" alt="�鿴��"/><!--{if $thread['isgroup'] != 1}-->{$thread[views]}<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->&nbsp;&nbsp;
				</span>
			</div>
		</li>
	<!--{/loop}-->
<!--{else}-->
	<!--{loop $_G['forum_threadlist'] $key $thread}-->
	<!--{if $_G['hiddenexists'] && $thread['hidden']}-->
		<!--{eval continue;}-->
	<!--{/if}-->
	<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
		<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
			<!--{eval $thread[tid]=$thread[closed];}-->
		<!--{/if}-->
	<!--{/if}-->
	<li class="byg_threadlist_pic_li white-panel">
		<div class="byg_threadlist_pic">
			<div class="byg_pic_img">
				<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="$thread[subject]">
					<!--{if $thread['cover']}-->
						<img src="$thread[coverpath]" alt="$thread[subject]" />
					<!--{else}-->
						<img src="{$_G['style']['styleimgdir']}/nophoto.gif" alt="$thread[subject]" />
					<!--{/if}-->
				</a>
			</div>
			<h3 class="byg_pic_tit">
				<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight] title="$thread[subject]">$thread[subject]</a>
			</h3>
			<div class="byg_pic_auth cl">
				<span class="y">
					{lang like}: <!--{if $thread[recommends]}-->$thread[recommends]<!--{else}-->0<!--{/if}-->
					 &nbsp; {lang reply}: <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" title="$thread[replies] {lang reply}">$thread[replies]</a>
				</span>
				<span class="z">
				<!--{if $thread['authorid'] && $thread['author']}-->
					<a href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
				<!--{else}-->
					$_G[setting][anonymoustext]
				<!--{/if}-->
				</span>
			</div>
		</div>
	</li>
	<!--{/loop}-->
<!--{/if}-->
