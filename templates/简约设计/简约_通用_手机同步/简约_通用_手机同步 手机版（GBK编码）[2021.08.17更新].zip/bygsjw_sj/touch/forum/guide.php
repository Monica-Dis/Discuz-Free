<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin">
			<h2 class="header_z cl">
				<a href="javascript:;" class="shouye">
					<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/>
					<!--{if $_G[member][newpm] || $post_notice_new}-->
					<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
					<!--{/if}-->
				</a>
				<em>&rsaquo;</em>
				<span>����</span>
			</h2>
			<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="����"/></a>
		</div>
		<!--{template common/header_nav}-->
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--{eval $forum_guide_gg = byg_diy_block_sum('��Լͨ���ֻ�����̳����ҳ���');}-->
<!--{if $forum_guide_gg}-->
<div class="byg_gg">{$forum_guide_gg}</div>
<!--{/if}-->

<!-- main threadlist start -->
<div class="threadlist">
	<!--{if $_G['style']['liebiaotu'] == "on"}-->
	<style>
		.list_img1_box .list_top{ float: left; width: 2.32rem; height: .44rem; margin-bottom: .06rem; padding-right: 0; overflow: hidden;}
		.list_img1_box .list_img1{ float: right; width: 1.15rem; padding: .1rem .1rem .1rem 0;}
		.list_img1_box .list_img1 a{ width: 100%; height: .76rem; padding: 0; border-radius: .04rem; overflow: hidden; display: block; background-position: center center; background-repeat: no-repeat; background-size: cover; -webkit-background-size: cover;}
		.list_img1_box .list_bottom{ float: left; width: 2.28rem; margin-right: 0;}
	</style>
	<!--{/if}-->
	<!--{loop $data $key $list}-->
	<ul class="hotlist">
		<!--{if $list['threadcount']}-->
			<!--{subtemplate forum/guide_list_row}-->
		<!--{else}-->
			<li style="padding:.1rem;color:#888;text-align:center;">{lang guide_nothreads}</li>
		<!--{/if}-->
	</ul>
	<!--{if $list['threadcount']}-->
		<div style="{if $_G['style']['fanye'] != 'on'}display: none;{/if}">$multipage</div>
		<!--{if $_G['style']['fanye'] != 'on'}-->
		<div class="load_more_button">
			<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="�ȴ�"/>���ݼ����У����Ժ�...</a>
		</div>
		<script type="text/javascript">
			var ajax_state = true;
			var ajax_page = <!--{if $_GET[page]}-->$_GET[page]<!--{else}-->1<!--{/if}--> + 1;
			var all_page = jQuery('div.pg label span').text().replace(/[^\d]/g, '') || 0;
			var ajax_url = 'forum.php?mod=guide&view=' + '$_GET[view]';

			function list_ajax() {
				if(ajax_state == true) {
					if(all_page >= 2 && all_page >= ajax_page) {
						ajax_state = false;
						jQuery(".load_more_button").html('<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="�ȴ�"/>���ݼ����У����Ժ�...</a>');
						jQuery.ajax({
							url: ajax_url + '&page=' + ajax_page + '&mobile=2',
							type: 'GET',
							dataType: 'html',
							success: function(result) {
								jQuery(".hotlist").append(jQuery(result).find(".hotlist").html());
								ajax_page++;
								ajax_state = true;
							}
						});
					} else {
						jQuery(".load_more_button").html('<a href="forum.php?forumlist=1" title="��̳">�Ѿ������ˣ�������̳���ָ���</a>');
						ajax_state = false;
					}
				}
			}

			if(jQuery(document).height() <= jQuery(window).height()) {
				list_ajax();
			}

			jQuery(window).scroll(function() {
				if(jQuery(document).height() <= jQuery(window).height() + jQuery(window).scrollTop() + 1000) {
					list_ajax();
				}
			});
		</script>
		<!--{/if}-->
	<!--{/if}-->
	<!--{/loop}-->
</div>
<!-- main threadlist end -->

<!--{template common/footer}-->

