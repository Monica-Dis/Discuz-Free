<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin">
			<h2 class="header_z cl">
				<a href="javascript:;" class="shouye">
					<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/>
					<!--{if $_G[member][newpm] || $post_notice_new}-->
					<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
					<!--{/if}-->
				</a>
				<em>&rsaquo;</em>
				<span>����</span>
			</h2>
			<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="����"/></a>
		</div>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<style type="text/css">
	.an_all_li{ padding: .1rem; margin: .1rem 0; background: #fff;}
	.an_all_li_t{ width: 3.62rem;}
	.an_all_li_t .z{ width: 3.37rem; line-height: .24rem; font-size: .16rem;}
	.an_all_li_t .y{ width: .1rem; height: .1rem; margin: .04rem; padding: .03rem; background: #f1f1f1; border-radius: 50%; transition: transform 0.2s; -webkit-transition: transform 0.2s; -o-transition: transform 0.2s; -moz-transition: transform 0.2s;}
	.an_all_li_t .y.on{ -webkit-transform: rotateZ(90deg); -moz-transform: rotateZ(90deg); -o-transform: rotateZ(90deg); -ms-transform: rotateZ(90deg); transform: rotateZ(90deg);}
	.an_all_li_c{ color: #999; font-size: .14rem; margin-top: .04rem;}
	.an_all_li_b{  margin: .08rem 0 .04rem; padding: .08rem .1rem; border: 1px dashed #eee; background: #ffe; border-radius: .02rem;}
	.an_all_li_b a{ color: #06c;}
</style>
<ul class="an_all_ul">
	<!--{loop $announcelist $ann}-->
		<li class="an_all_li">
			<div id="announce{$ann[id]}" class="an_all_li_t cl">
				<h3 class="z">{$ann[subject]}</h3>
				<img src="{$_G['style']['styleimgdir']}/jinru.png" alt="����" id="announce{$ann[id]}_i" class="y{if $_GET[id] == $ann[id]} on{/if}" />
			</div>
			<div class="an_all_li_c cl">
				<span class="z">{lang author}: <a href="home.php?mod=space&username=$ann[authorenc]&do=profile">{$ann[author]}</a></span>
				<span class="y">{$ann[starttime]}</span>
			</div>
			<div id="announce{$ann[id]}_c" class="an_all_li_b cl" {if $_GET[id] != $ann[id]}style="display: none"{/if}>
				{$ann[message]}
			</div>
		</li>
	<!--{/loop}-->
</ul>
<script type="text/javascript">
	jQuery('.an_all_li_t').on('click', function() {
		var an = jQuery(this);
		var an_i = jQuery('#' + an.attr('id') + '_i');
		var an_c = jQuery('#' + an.attr('id') + '_c');
		if(an_c.css('display') == 'none') {
			an_c.css('display', 'block');
			an_i.addClass('on');
		} else {
			an_c.css('display', 'none');
			an_i.removeClass('on');
		}
	});
</script>

<!--{template common/footer}-->

