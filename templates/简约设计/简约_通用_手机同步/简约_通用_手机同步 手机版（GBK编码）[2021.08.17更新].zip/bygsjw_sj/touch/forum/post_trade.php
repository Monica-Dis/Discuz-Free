<?php echo 'From: DisM.taobao.com';exit;?>

<input type="hidden" name="trade" value="yes" />
<input type="hidden" name="item_type" value="1" />
<div class="byg_exfm cl">
	<style type="text/css">
		.byg_exfm{ margin-bottom: .05rem; padding: 0 .1rem; font-size: .15rem; color: #666;}
		.byg_exfm .px{ border: .01rem solid #eee;}
		.byg_sinf dl{ margin-top: .1rem; padding-bottom: .1rem; border-bottom: 1px dashed #eaeaea;}
		.byg_sinf .byg_place_dt{ line-height: .3rem;}
		.byg_sinf .byg_place_dd{ position: relative;}
		.byg_sinf .byg_place_dd .px{ width: 2.75rem;}
		.byg_sinf .byg_place_dd .pt{ height: 1rem;}
		.byg_sinf .byg_place_dd .ps{ width: 2.77rem; height: .3rem; line-height: .3rem; padding-left: .02rem; border-color: #eee; border-radius: .05rem; color: #888; font-size: .15rem;}
		.byg_sinf .byg_place_dd span{ position: absolute; top: 0; right: .08rem; height: .3rem; line-height: .3rem; color: #999;}
		.byg_sinf .byg_place_dd p{ line-height: .3rem; color: #999; font-size: .13rem;}
		.byg_trade_price .byg_place_dd{ margin-bottom: .1rem;}
		.byg_sinf dl.byg_trade_price{ padding: 0;}
		.byg_tradeimg_file{ margin-top: .02rem; width: 2.75rem; height: .25rem; line-height: .25rem; overflow: hidden;}
		#tradeattach_image img{ margin-top: .1rem; border-radius: .1rem; max-width: 100%; vertical-align: top;}
	</style>
	<div class="byg_sinf">
		<dl class="cl">
			<dt class="byg_place_dt z"><span class="rq">*</span><label for="item_name">{lang post_trade_name}:</label></dt>
			<dd class="byg_place_dd y"><input type="text" name="item_name" id="item_name" class="px" value="$trade[subject]" tabindex="1" /></dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><span class="rq">*</span><label for="item_number">{lang post_trade_number}:</label></dt>
			<dd class="byg_place_dd y"><input type="text" name="item_number" id="item_number" class="px" value="$trade[amount]" tabindex="1" /></dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><span class="rq">*</span><label for="item_quality">��Ʒ��ɫ:</label></dt>
			<dd class="byg_place_dd y">
				<select id="item_quality" class="ps" name="item_quality" tabindex="1">
					<option value="1" {if $trade['quality'] == 1}selected="selected"{/if}>{lang trade_new}</option>
					<option value="2" {if $trade['quality'] == 2}selected="selected"{/if}>{lang trade_old}</option>
				</select>
			</dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><label for="transport">{lang post_trade_transport}:</label></dt>
			<dd class="byg_place_dd y">
				<select name="transport" id="transport" onchange="document.getElementById('logisticssetting').style.display = (document.getElementById('transport').value == 'virtual' ? 'none' : '');" class="ps">
					<option value="virtual" {if $trade['transport'] == 3}selected="selected"{/if}>{lang post_trade_transport_virtual}</option>
					<option value="seller" {if $trade['transport'] == 1}selected="selected"{/if}>{lang post_trade_transport_seller}</option>
					<option value="buyer" {if $trade['transport'] == 2}selected="selected"{/if}>{lang post_trade_transport_buyer}</option>
					<option value="logistics" {if $trade['transport'] == 4}selected="selected"{/if}>{lang trade_type_transport_physical}</option>
					<option value="offline" {if $trade['transport'] == 0}selected="selected"{/if}>{lang post_trade_transport_offline}</option>
				</select>
			</dd>
		</dl>
		<dl class="cl byg_trade_price">
			<dt class="byg_place_dt z"><span class="rq">*</span>{lang post_trade_price}:</dt>
			<dd class="byg_place_dd y">
				<input type="text" name="item_price" id="item_price" class="px" value="$trade[price]" tabindex="1" />
				<span>{lang post_current_price}</span>
			</dd>
			<dd class="byg_place_dd y">
				<input type="text" name="item_costprice" id="item_costprice" class="px" value="$trade[costprice]" tabindex="1" />
				<span>{lang post_original_price}</span>
			</dd>
			<!--{if $_G['setting']['creditstransextra'][5] != -1}-->
			<dd class="byg_place_dd y">
				<input type="text" name="item_credit" id="item_credit" class="px" value="$trade[credit]" tabindex="1" />
				<span>{lang post_current_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})</span>
			</dd>
			<dd class="byg_place_dd y">
				<input type="text" name="item_costcredit" id="item_costcredit" class="px" value="$trade[costcredit]" tabindex="1" />
				<span>{lang post_original_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})</span>
			</dd>
			<!--{/if}-->
			<dd class="y" id="logisticssetting" style="display:{if !$trade['transport'] || $trade['transport'] == 3}none{/if}">
				<div class="byg_place_dd y">
					<input type="text" name="postage_mail" id="postage_mail" class="px" value="$trade[ordinaryfee]" tabindex="1" />
					<span>{lang post_trade_transport_mail}</span>
				</div>
				<div class="byg_place_dd y">
					<input type="text" name="postage_express" id="postage_express" class="px" value="$trade[expressfee]" tabindex="1" />
					<span>{lang post_trade_transport_express}</span>
				</div>
				<div class="byg_place_dd y">
					<input type="text" name="postage_ems" id="postage_ems" class="px" value="$trade[emsfee]" tabindex="1" />
					<span>EMS</span>
				</div>
			</dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><label for="paymethod">{lang post_trade_paymethod}:</label></dt>
			<dd class="byg_place_dd y">
				<select name="paymethod" id="paymethod" onchange="document.getElementById('tenpayseller').style.display = (document.getElementById('paymethod').value == '1' ? 'none' : '');" class="ps" tabindex="1">
					<!--{if $_G[setting][ec_tenpay_opentrans_chnid]}--><option value="0" {if $trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_online}</option><!--{/if}-->
					<option value="1" {if !$trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_offline}</option>
				</select>
			</dd>
		</dl>
		<dl class="cl" id="tenpayseller" style="{if !$trade[tenpayaccount]}display:none{/if}">
			<dt class="byg_place_dt z"><label for="tenpay_account">{lang post_trade_tenpay_seller}:</label></dt>
			<dd class="byg_place_dd y"><input type="text" name="tenpay_account" id="tenpay_account" class="px" value="$trade[tenpayaccount]" tabindex="2" style="width: 2.6rem;" /></dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><label for="item_locus">{lang post_trade_locus}:</label></dt>
			<dd class="byg_place_dd y"><input type="text" name="item_locus" id="item_locus" class="px" value="$trade[locus]" tabindex="1" /></dd>
		</dl>
		<dl class="cl">
			<dt class="byg_place_dt z"><label for="item_expiration">{lang valid_before}:</label></dt>
			<dd class="byg_place_dd y">
				<script type="text/javascript" src="{$_G['style']['styleimgdir']}/date.js?{VERHASH}"></script>
				<input type="text" name="item_expiration" id="item_expiration" class="px" autocomplete="off" value="$trade[expiration]" tabindex="1" />
				<script type="text/javascript">
					new Rolldate({
						el: '#item_expiration',
						format: 'YYYY-MM-DD',
						beginYear: 2000,
						endYear: 2100
					});
				</script>
			</dd>
		</dl>
		<!--{if $allowpostimg}-->
		<dl class="cl">
			<dt class="byg_place_dt z">{lang post_trade_picture}:</dt>
			<dd class="y">
				<input type="file" name="Filedata" accept="image/jpg,image/jpeg,image/gif,image/png,image/bmp" class="byg_tradeimg_file">
			</dd>
			<dd>
				<input type="hidden" name="tradeaid" id="tradeaid" {if $tradeattach[attachment]}value="$tradeattach[aid]" {/if}/>
				<input type="hidden" name="tradeaid_url" id="tradeaid_url" />
				<div id="tradeattach_image">
				<!--{if $tradeattach[attachment]}-->
					<img src="$tradeattach[url]/{if $tradeattach['thumb']}{eval echo getimgthumbname($tradeattach['attachment']);}{else}$tradeattach[attachment]{/if}" />
				<!--{/if}-->
				</div>
			</dd>
		</dl>
		<!--{/if}-->
	</div>
</div>

<script type="text/javascript" reload="1">
	$(document).on('change', '.byg_tradeimg_file', function() {
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

		uploadsuccess = function(data) {
			if(data == '') {
				popup.open('{lang uploadpicfailed}', 'alert');
			}
			var dataarr = data.split('|');
			if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
				popup.close();
				$('#tradeaid').val(dataarr[3]);
				$('#tradeaid_url').val('/' + dataarr[5]);
				$('#tradeattach_image').html('<img src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" />');
			} else {
				var sizelimit = '';
				if(dataarr[7] == 'ban') {
					sizelimit = '{lang uploadpicatttypeban}';
				} else if(dataarr[7] == 'perday') {
					sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
				} else if(dataarr[7] > 0) {
					sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
				}
				popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
			}
		};

		if(typeof FileReader != 'undefined' && this.files[0]) {//note ֧��html5�ϴ�������

			$.buildfileupload({
				uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
				files:this.files,
				uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
				uploadinputname:'Filedata',
				maxfilesize:"$swfconfig[max]",
				success:uploadsuccess,
				error:function() {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
			});

		} else {

			$.ajaxfileupload({
				url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
				data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
				dataType:'text',
				fileElementId:'filedata',
				success:uploadsuccess,
				error: function() {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
			});

		}
	});
</script>
