<?php echo 'From: DisM.taobao.com';exit;?>

<div class="profile_body">
	<style>
		.profile_body, .profile_body a{ font-size: .15rem; line-height: 1.8;}
		.profile_body_1, .profile_body_2, .profile_body_3, .profile_body_4, .profile_body_5, .profile_body_6, .profile_body_7{ margin: .1rem 0; padding: .1rem; background: #fff;}
		.profile_body h2{ display: block; margin-bottom: .1rem; padding-bottom: .08rem; border-bottom: 1px solid #eee; font-size: .16rem; font-weight: 700;}
		.profile_body_1ul2, .profile_body_1ul3, .profile_body_6ul1{ margin-bottom: .1rem; padding-bottom: .1rem; border-bottom: 1px dashed #eaeaea;}
		.profile_body ul em{ margin-right: .05rem; color: #999;}
		.profile_body .pipe{ margin: 0 .05rem; color: #ccc;}
		.profile_body_4 a{ display: inline-block; margin: .05rem 0; padding: 0 .06rem; border: 1px solid $_G['style']['zhuti']; border-radius: .02rem; color: $_G['style']['zhuti']; font-size: .14rem;}
		.profile_body_2p{ margin: .15rem 0 .05rem;}
		.profile_body_2p img{ margin-right: .02rem; vertical-align: middle;}
	</style>
	<script type="text/javascript">
		function zoom(){};
		function img_onmouseoverfunc(){};
		function thumbImg(){};
	</script>
	<div class="profile_body_1">
		<h2>
			{$space[username]}
			<!--{if $_G['ols'][$space[uid]]}-->
				<img src="{IMGDIR}/ol.gif" alt="����" title="{lang online}" class="vm" />&nbsp;
			<!--{/if}-->
			<span>(UID: {$space[uid]}
			<!--{eval $isfriendinfo = 'home_friend_info_'.$space['uid'].'_'.$_G[uid];}-->
			<!--{if $_G[$isfriendinfo][note]}-->
				, <span>$_G[$isfriendinfo][note]</span>
			<!--{/if}-->
			)</span>
		</h2>
		<ul class="profile_body_1ul1">
			<!--{if $_G['setting']['allowspacedomain'] && $_G['setting']['domain']['root']['home'] && checkperm('domainlength') && !empty($space['domain'])}-->
			<!--{eval $spaceurl = 'http://'.$space['domain'].'.'.$_G['setting']['domain']['root']['home'];}-->
			<li><em>{lang second_domain}��</em>$spaceurl</li>
			<!--{/if}-->
			<!--{if $_G[setting][homepagestyle]}-->
			<li><em>{lang space_visits}��</em>$space[views]</li>
			<!--{/if}-->
			<!--{if in_array($_G[adminid], array(1, 2))}-->
			<li><em>Email��</em>$space[email]</li>
			<!--{/if}-->
			<li><em>{lang email_status}��</em><!--{if $space[emailstatus] > 0}-->{lang profile_verified}<!--{else}-->{lang profile_no_verified}<!--{/if}--></li>
			<li><em>{lang video_certification}��</em><!--{if $space[videophotostatus] > 0}-->{lang profile_certified}<!--{else}-->{lang profile_no_certified}<!--{/if}--></li>
		</ul>
		<ul class="profile_body_1ul2">
			<!--{if $space[spacenote]}--><li><em>{lang spacenote}��</em>$space[spacenote]</li><!--{/if}-->
			<!--{if $space[customstatus]}--><li><em>{lang permission_basic_status}��</em>$space[customstatus]</li><!--{/if}-->
			<!--{if $space[group][maxsigsize] && $space[sightml]}--><li><em>{lang personal_signature}��</em><table><tr><td>$space[sightml]</td></tr></table></li><!--{/if}-->
		</ul>
		<ul class="profile_body_1ul3">
			<li>
				<em>{lang stat_info}��</em>
				<a href="javascript:;">{lang friends_num} $space[friends]</a>
				<!--{if helper_access::check_module('doing')}-->
					<span class="pipe">|</span>
					<a href="javascript:;">{lang doings_num} $space[doings]</a>
				<!--{/if}-->
				<!--{if helper_access::check_module('blog')}-->
					<span class="pipe">|</span>
					<a href="javascript:;">{lang blogs_num} $space[blogs]</a>
				<!--{/if}-->
				<!--{if helper_access::check_module('album')}-->
					<span class="pipe">|</span>
					<a href="javascript:;">{lang albums_num} $space[albums]</a>
				<!--{/if}-->
				<!--{if $_G['setting']['allowviewuserthread'] !== false}-->
					<span class="pipe">|</span>
					<!--{eval $space['posts'] = $space['posts'] - $space['threads'];}-->
					<a href="javascript:;">{lang replay_num} $space[posts]</a>
					<span class="pipe">|</span>
					<a href="javascript:;">{lang threads_num} $space[threads]</a>
				<!--{/if}-->
				<!--{if helper_access::check_module('share')}-->
					<span class="pipe">|</span>
					<a href="javascript:;">{lang shares_num} $space[sharings]</a>
				<!--{/if}-->
			</li>
		</ul>
		<ul class="profile_body_1ul4">
			<!--{loop $profiles $value}-->
			<li><em>$value[title]��</em>$value[value]</li>
			<!--{/loop}-->
		</ul>
	</div>

<!--{if $space['medals']}-->
	<div class="profile_body_2">
		<h2>{lang medals}</h2>
		<p class="profile_body_2p">
			<a href="javascript:;">
			<!--{loop $space['medals'] $medal}-->
				<img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" id="md_{$medal[medalid]}" />
			<!--{/loop}-->
			</a>
		</p>
	</div>
<!--{/if}-->

<!--{if $_G['setting']['verify']['enabled']}-->
	<!--{eval $showverify = true;}-->
	<!--{loop $_G['setting']['verify'] $vid $verify}-->
		<!--{if $verify['available']}-->
			<!--{if $showverify}-->
			<div class="profile_body_3">
			<h2>{lang profile_verify}</h2>
			<!--{eval $showverify = false;}-->
			<!--{/if}-->

			<!--{if $space['verify'.$vid] == 1}-->
				<a href="javascript:;"><!--{if $verify['icon']}--><img src="$verify['icon']" class="vm" alt="$verify[title]" /><!--{/if}-->{$verify[title]}</a>&nbsp;
			<!--{elseif !empty($verify['unverifyicon'])}-->
				<a href="javascript:;"><!--{if $verify['unverifyicon']}--><img src="$verify['unverifyicon']" class="vm" alt="$verify[title]" /><!--{/if}-->{$verify[title]}</a>&nbsp;
			<!--{/if}-->

		<!--{/if}-->
	<!--{/loop}-->
	<!--{if !$showverify}--></div><!--{/if}-->
<!--{/if}-->

<!--{if $count}-->
	<div class="profile_body_4">
		<h2>{lang manage_forums}</h2>
		<!--{loop $manage_forum $key $value}-->
		<a href="forum.php?mod=forumdisplay&fid=$key">{$value}</a> &nbsp;
		<!--{/loop}-->
	</div>
<!--{/if}-->
<!--{if $groupcount}-->
	<div class="profile_body_5">
		<h2>{lang joined_group}</h2>
		<!--{loop $usergrouplist $key $value}-->
		<a href="javascript:;">{$value['name']}</a> &nbsp;
		<!--{/loop}-->
	</div>
<!--{/if}-->

	<div class="profile_body_6">
		<h2>{lang active_profile}</h2>
		<ul class="profile_body_6ul1">
			<!--{if $space[adminid]}--><li><em>{lang management_team}��</em><span style="color:{$space[admingroup][color]}"><a href="javascript:;">{$space[admingroup][grouptitle]}</a></span> {$space[admingroup][icon]}</li><!--{/if}-->
			<li><em>{lang usergroup}��</em><span style="color:{$space[group][color]}"><a href="javascript:;">{$space[group][grouptitle]}</a></span>{$space[group][icon]}<!--{if !empty($space['groupexpiry'])}-->&nbsp;{lang group_useful_life}&nbsp;<!--{date($space[groupexpiry], 'Y-m-d H:i')}--><!--{/if}--></li>
			<!--{if $space[extgroupids]}--><li><em>{lang group_expiry_type_ext}��</em>$space[extgroupids]</li><!--{/if}-->
		</ul>
		<ul class="profile_body_6ul2">
			<!--{if $space[oltime]}--><li><em>{lang online_time}��</em>$space[oltime] {lang hours}</li><!--{/if}-->
			<li><em>{lang regdate}��</em>$space[regdate]</li>
			<li><em>{lang last_visit}��</em>$space[lastvisit]</li>
			<!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
			<li><em>{lang register_ip}��</em>$space[regip] - $space[regip_loc]</li>
			<li><em>{lang last_visit_ip}��</em>$space[lastip]:$space[port] - $space[lastip_loc]</li>
			<!--{/if}-->
			<!--{if $space[lastactivity]}--><li><em>{lang last_activity_time}��</em>$space[lastactivity]</li><!--{/if}-->
			<!--{if $space[lastpost]}--><li><em>{lang last_post_time}��</em>$space[lastpost]</li><!--{/if}-->
			<!--{if $space[lastsendmail]}--><li><em>{lang last_send_email}��</em>$space[lastsendmail]</li><!--{/if}-->
			<li><em>{lang time_offset}��</em>
				<!--{eval $timeoffset = array({lang timezone});}-->
				$timeoffset[$space[timeoffset]]
			</li>
		</ul>
	</div>

	<div class="profile_body_7">
		<h2>{lang stat_info}</h2>
		<ul class="profile_body_7ul">
			<li><em>{lang used_space}��</em>$space[attachsize]</li>
			<!--{if $space[buyercredit]}-->
			<li><em>{lang eccredit_sellerinfo}��</em><a href="javascript:;">$space[buyercredit] <img src="{STATICURL}image/traderank/buyer/$space[buyerrank].gif" border="0" class="vm" /></a></li>
			<!--{/if}-->
			<!--{if $space[sellercredit]}-->
			<li><em>{lang eccredit_buyerinfo}��</em><a href="javascript:;">$space[sellercredit] <img src="{STATICURL}image/traderank/seller/$space[sellerrank].gif" border="0" class="vm" /></a></li>
			<!--{/if}-->
			<li><em>{lang credits}��</em>$space[credits]</li>
			<!--{loop $_G[setting][extcredits] $key $value}-->
			<!--{if $value[title]}-->
			<li><em>$value[title]��</em>{$space["extcredits$key"]} $value[unit]</li>
			<!--{/if}-->
			<!--{/loop}-->
		</ul>
	</div>
</div>
