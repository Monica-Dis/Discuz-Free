<?php echo 'From: DisM.taobao.com';exit;?>

<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !$_GET['mycenter']}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<!--{if $_G['uid'] == $space['uid']}-->
				<em>&rsaquo;</em>
				<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" title="��������">��������</a>
				<em>&rsaquo;</em><span>�ҵ�����</span>
			<!--{else}-->
				<em>&rsaquo;</em><span>{$space[username]}&nbsp;������</span>
			<!--{/if}-->
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="����"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--{if $space[uid]}-->
<!--{template home/space_menu}-->
<!--{subtemplate home/space_profile_body}-->
<!--{/if}-->

<!--{else}-->

<script type="text/javascript">
	if(document.referrer.indexOf("mod=spacecp&ac=avatar") != -1) {
		location.reload(true);
	}
</script>

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<span>��������</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="����"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!-- userinfo start -->
<div class="userinfo">

	<style>
		#uhd{ position: relative; background: #fff;}
		#uhd_bg{ position: relative; z-index: 1; width: 3.75rem; height: 1.65rem; overflow: hidden; background: #3498db; background-color: $_G['style']['zhuti'];}
		.home_forum_header_js{ background: #fff !important; opacity: 0.1 !important; border-radius: 10% !important;}
	</style>
	<div id="uhd">
		<div id="uhd_bg"></div>
		<div class="user_avatar">
			<div class="avatar_m"><a href="home.php?mod=spacecp&ac=avatar"><img src="<!--{avatar($_G[uid], big, true)}-->" alt="ͷ��" /><span>�޸�ͷ��</span></a></div>
			<h2 class="name">{$_G[username]}</h2>
			<p class="home_user_group">�û��飺{$_G[group][grouptitle]}</p>
		</div>
	</div>
	
	<!--{eval $home_gg = byg_diy_block_sum('��Լͨ���ֻ����������ҳ���');}-->
	<!--{if $home_gg}-->
	<div class="byg_gg" style="margin:1px 0;">{$home_gg}</div>
	<!--{/if}-->
	
	<ul class="myinfo_sige_ul cl">
		<li>
			<a href="home.php?mod=space&uid={$_G[uid]}&do=profile">
				<img src="{$_G['style']['styleimgdir']}/bl_ziliao.png" alt="����"/>
				<p>�ҵ�����</p>
			</a>
		</li>
		<li>
			<a href="home.php?mod=spacecp&ac=profile">
				<img src="{$_G['style']['styleimgdir']}/bl_ziliao_xiugai.png" alt="�޸�"/>
				<p>�޸�����</p>
			</a>
		</li>
		<li>
			<a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me">
				<img src="{$_G['style']['styleimgdir']}/bl_zhuti.png" alt="����"/>
				<p>�ҵ�����</p>
			</a>
		</li>
		<li style="width: .92rem; border-right: 0;">
			<a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me&type=reply">
				<img src="{$_G['style']['styleimgdir']}/bl_xintie.png" alt="�ظ�"/>
				<p>�ҵĻظ�</p>
			</a>
		</li>
		<li style="border-bottom: 0;">
			<a href="home.php?mod=space&do=pm">
				<img src="{$_G['style']['styleimgdir']}/bl_xiaoxi.png" alt="��Ϣ"/>
				<p>�ҵ���Ϣ</p>
				<!--{if $_G[member][newpm]}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
		</li>
		<li style="border-bottom: 0;">
			<a href="home.php?mod=space&do=notice&view=mypost">
				<img src="{$_G['style']['styleimgdir']}/bl_tixing.png" alt="����"/>
				<p>��������</p>
				<!--{if $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
		</li>
		<li style="border-bottom: 0;">
			<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">
				<img src="{$_G['style']['styleimgdir']}/bl_shoucang.png" alt="�ղ�"/>
				<p>�ҵ��ղ�</p>
			</a>
		</li>
	</ul>
	
	<div class="myinfo_list cl">
		<ul>
		<!--���������Ĺ����б���ʼ��-->
			<!--{eval}-->
				$home_nav1_p = byg_diy_block_param('��Լͨ���ֻ���������ĵ���1');
				$home_nav2_p = byg_diy_block_param('��Լͨ���ֻ���������ĵ���2');
				$home_nav3_p = byg_diy_block_param('��Լͨ���ֻ���������ĵ���3');
				$home_nav4_p = byg_diy_block_param('��Լͨ���ֻ���������ĵ���4');
				$home_nav5_p = byg_diy_block_param('��Լͨ���ֻ���������ĵ���5');
				$home_nav6_p = byg_diy_block_param('��Լͨ���ֻ���������ĵ���6');
			<!--{/eval}-->
			<!--{if $home_nav1_p}-->
			<!--{eval $home_nav1 = unserialize($home_nav1_p);}-->
			<li>
				<a href="{$home_nav1['url']}"><img src="{$home_nav1['pic']}" alt="{$home_nav1['text']}"/>{$home_nav1['text']}<img src="{$_G['style']['styleimgdir']}/jinru.png" alt="����" class="myinfo_list_jinru"/></a>
			</li>
			<!--{/if}-->
			<!--{if $home_nav2_p}-->
			<!--{eval $home_nav2 = unserialize($home_nav2_p);}-->
			<li>
				<a href="{$home_nav2['url']}"><img src="{$home_nav2['pic']}" alt="{$home_nav2['text']}"/>{$home_nav2['text']}<img src="{$_G['style']['styleimgdir']}/jinru.png" alt="����" class="myinfo_list_jinru"/></a>
			</li>
			<!--{/if}-->
			<!--{if $home_nav3_p}-->
			<!--{eval $home_nav3 = unserialize($home_nav3_p);}-->
			<li>
				<a href="{$home_nav3['url']}"><img src="{$home_nav3['pic']}" alt="{$home_nav3['text']}"/>{$home_nav3['text']}<img src="{$_G['style']['styleimgdir']}/jinru.png" alt="����" class="myinfo_list_jinru"/></a>
			</li>
			<!--{/if}-->
			<!--{if $home_nav4_p}-->
			<!--{eval $home_nav4 = unserialize($home_nav4_p);}-->
			<li>
				<a href="{$home_nav4['url']}"><img src="{$home_nav4['pic']}" alt="{$home_nav4['text']}"/>{$home_nav4['text']}<img src="{$_G['style']['styleimgdir']}/jinru.png" alt="����" class="myinfo_list_jinru"/></a>
			</li>
			<!--{/if}-->
			<!--{if $home_nav5_p}-->
			<!--{eval $home_nav5 = unserialize($home_nav5_p);}-->
			<li>
				<a href="{$home_nav5['url']}"><img src="{$home_nav5['pic']}" alt="{$home_nav5['text']}"/>{$home_nav5['text']}<img src="{$_G['style']['styleimgdir']}/jinru.png" alt="����" class="myinfo_list_jinru"/></a>
			</li>
			<!--{/if}-->
			<!--{if $home_nav6_p}-->
			<!--{eval $home_nav6 = unserialize($home_nav6_p);}-->
			<li>
				<a href="{$home_nav6['url']}"><img src="{$home_nav6['pic']}" alt="{$home_nav6['text']}"/>{$home_nav6['text']}<img src="{$_G['style']['styleimgdir']}/jinru.png" alt="����" class="myinfo_list_jinru"/></a>
			</li>
			<!--{/if}-->
			
			<!--{if $_G['setting']['card']['open']}-->
			<li>
				<a href="home.php?mod=spacecp&ac=credit&op=base"><img src="{$_G['style']['styleimgdir']}/bl_jifen.png" alt="����"/>���ֳ�ֵ<img src="{$_G['style']['styleimgdir']}/jinru.png" alt="����" class="myinfo_list_jinru"/></a>
			</li>
			<!--{/if}-->
			<!--{if $space['uid'] == $_G['uid']}-->
			<li>
				<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}"><img src="{$_G['style']['styleimgdir']}/home_tuichu.png" alt="�˳�"/>�˳���½<img src="{$_G['style']['styleimgdir']}/jinru.png" alt="����" class="myinfo_list_jinru"/></a>
			</li>
			<!--{/if}-->
		<!--���������Ĺ����б�������-->
		</ul>
	</div>
	
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/home_forum_header.js"></script>
	<script type="text/javascript">
		jQuery.firefly({
		  minPixel: 4,
		  maxPixel: 40,
		  total : 20,
		  on: '#uhd_bg',
		  namespace: 'home_forum_header_js'
		});
	</script>
</div>
<!-- userinfo end -->

<!--{/if}-->
<!--{template common/footer}-->

