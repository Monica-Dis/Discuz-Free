<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" title="��������">��������</a>
			<em>&rsaquo;</em>
			<span>�ҵ��ղ�</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="����"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="forumdisplay_tab">
	<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread" {if $_GET['type'] == 'thread'}class="on"{/if}><h2>����</h2></a>
	<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=forum" {if $_GET['type'] == 'forum'}class="on"{/if}><h2>���</h2></a>
	<!--{if helper_access::check_module('group')}--><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=group" {if $_GET['type'] == 'group'}class="on"{/if}><h2>{lang favorite_group}</h2></a><!--{/if}-->
	<!--{if helper_access::check_module('portal')}--><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=article" {if $_GET['type'] == 'article'}class="on"{/if}><h2>����</h2></a><!--{/if}-->
</div>

<!-- main collectlist start -->
<style>
	.threadlist li{ padding: .12rem .1rem;}
	.threadlist li .z{ width: 3.05rem; padding: 0;}
	.threadlist li .z p{ margin-top: .02rem; line-height: .18rem; font-size: .13rem; color: #999;}
	.threadlist li .y{ float: right; width: .4rem; padding: 0; background: #aaa; color: #fff; border: 0; border-radius: .04rem; cursor: pointer; -webkit-appearance: none; font-size: .12rem; text-align: center;}
</style>
<div class="threadlist">
	<!--{if $list}-->
	<ul>
		<!--{loop $list $k $value}-->
		<li class="cl">
			<a href="{$value[url]}" class="z">
				<!--{if $_GET['type'] == 'all'}--><span>{$value[icon]}</span><!--{/if}-->
				{$value[title]}
				<p><!--{date($value[dateline], 'u')}--><!--{if $value[description]}-->&nbsp;&nbsp;&nbsp;"{$value[description]}"<!--{/if}--></p>
			</a>
			<a href="home.php?mod=spacecp&ac=favorite&op=delete&favid={$k}&type={$_GET[type]}" onclick="favorite_delete_ajax(this.id);return false;" class="y" id="a_delete_{$k}">{lang delete}</a>
		</li>
		<!--{/loop}-->
	</ul>
	<!--{else}-->
	<div class="home_no_data">{lang no_favorite_yet}</div>
	<!--{/if}-->
</div>
<script type="text/javascript">
	function favorite_delete_ajax(obj) {
		var delete_id = '#' + obj;
		jQuery.ajax({
			url: jQuery(delete_id).attr('href') + '&inajax=1',
			type: 'POST',
			dataType: 'xml',
			success: function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
				evalscript(s.lastChild.firstChild.nodeValue);
			},
			error: function() {
				window.location.href = jQuery(delete_id).attr('href');
				popup.close();
			},
		});
	}
</script>
<!-- main collectlist end -->
$multi

<!--{template common/footer}-->

