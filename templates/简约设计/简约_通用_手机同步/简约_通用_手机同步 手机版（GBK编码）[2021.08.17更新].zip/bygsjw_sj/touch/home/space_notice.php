<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" title="��������">��������</a>
			<em>&rsaquo;</em>
			<span>��������</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="����"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--{if empty($list)}-->
<div class="home_no_data">{lang no_notice}</div>
<!--{/if}-->
<!--{if $list}-->
<div class="post_notice_list">
	<ul>
		<!--{loop $list $key $value}-->
		<li class="cl">
			<div class="post_notice_list_z">
				<!--{if $value[authorid]}-->
				<a href="home.php?mod=space&uid={$value[authorid]}&do=profile"><!--{avatar($value[authorid],middle)}--></a>
				<!--{else}-->
				<img src="{$_G['style']['styleimgdir']}/middle.gif" alt="ͷ��"/>
				<!--{/if}-->
			</div>
			<div class="post_notice_list_yt" style="$value[style]">
				<!--{if $value[authorid] && $value[author]}-->
				<a href="home.php?mod=space&uid={$value[authorid]}&do=profile">{$value[author]}</a>
				<i>��<!--{date($value[dateline], 'u')}-->��</i><span>{$value[note]}</span>
				<!--{else}-->
				<i>��<!--{date($value[dateline], 'u')}-->��</i>{$value[note]}
				<!--{/if}-->
			</div>
			<!--{if $value[from_num]}-->
			<div class="post_notice_list_yb">{lang ignore_same_notice_message}</div>
			<!--{/if}-->
		</li>
		<!--{/loop}-->
	</ul>
</div>
<!--{if $multi}--><div class="pgs cl">$multi</div><!--{/if}-->
<!--{/if}-->

<!--{template common/footer}-->
