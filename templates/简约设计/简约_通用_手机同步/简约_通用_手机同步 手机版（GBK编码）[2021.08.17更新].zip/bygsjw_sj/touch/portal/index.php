<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_sj/touch/php/portal_index.php');}-->

<!--{if $index_bg_p}-->
	<!--{eval $index_bg = unserialize($index_bg_p);}-->
	<!--{if !$byg_index_bg}-->
	<style>
		.byg_index_bg{ position: fixed; top: 0; bottom: 0; left: 0; right: 0; z-index: 9998; display: block; width: 100%; height: 100%; background: #fff url({$_G['style']['styleimgdir']}/lanjiazai.gif) no-repeat center center;}
		.byg_index_bg .index_bg_img{ display: block; width: 100%; height: 100%; background-image: url($index_bg['pic']); border-radius: 0;}
		.byg_index_bg .index_bg_time{ position: fixed; right: .15rem; top: .15rem; z-index: 9999; width: .36rem; height: .36rem; padding: .08rem; background: rgba(0, 0, 0, 0.3); line-height: .19rem; font-size: .14rem; color: #fff; border-radius: 50%; text-align: center;}
	</style>
	<div class="byg_index_bg">
		<a href="{$index_bg['url']}" title="{$index_bg['text']}" class="index_bg_img img_center"></a>
		<div class="index_bg_time">����<br/><span>5</span>s</div>
	</div>
	<script type="text/javascript">
		var bg_num = 5;//��ҳ��ӭͼƬ-�޸ĵ���ʱ���������Ϸ����������5ҲҪͬʱ�޸ġ�
		var bg_time = setInterval(function(){
			if(bg_num == 0){
				index_bg_off();
			}
			bg_num--;
			jQuery('.index_bg_time span').html(bg_num);
		},1000);

		function index_bg_off() {
			jQuery('.byg_index_bg').hide();
			clearInterval(bg_time);
		}
		
		if(window.performance.navigation.type == 2){
			index_bg_off();
		}

		jQuery('.index_bg_time').on('click', function(){
			index_bg_off();
		});
	</script>
	<!--{/if}-->
<!--{/if}-->

<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin">
			<div class="header_z cl">
				<a href="javascript:;" class="shouye">
					<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/>
					<!--{if $_G[member][newpm] || $post_notice_new}-->
					<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
					<!--{/if}-->
				</a>
			</div>
			<h1>
				<a href="./" title="$_G[setting][bbname]">
					<!--{if $bygsjw_logo}-->
					{$bygsjw_logo}
					<!--{else}-->
					<img src="{$_G['style']['boardimg']}" alt="LOGO"/>
					<!--{/if}-->
				</a>
			</h1>
			<a href="search.php?mod=forum" title="վ������" class="header_y"><img src="{$_G['style']['styleimgdir']}/sousuo_bai.png" alt="����"/></a>
		</div>
		<!--{template common/header_nav}-->
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--���õ�Ƭ��-->
<!--{if $slide_bid}-->
	<!--{eval $slide = byg_data_block_data($slide_bid, 10);}-->
	<!--{if $slide}-->
		<div data-byginto class="sj_slide">
			<div class="sj_slide_bd">
				<ul class="swiper-wrapper">
					<!--{loop $slide $sl}-->
					<!--{eval $sl_fields = unserialize($sl[fields]);}-->
					<!--{eval $sl_style = unserialize($sl[showstyle]);}-->
					<li class="swiper-slide">
						<!--{if $sl[picflag] == 1}-->
						<a href="{$sl[url]}" title="{$sl[title]}" data-background="{$_G['setting']['attachurl']}{if $sl[makethumb] == 1}{$sl[thumbpath]}{else}{$sl[pic]}{/if}" class="slide_img swiper-lazy"></a>
						<!--{elseif $sl[picflag] == 2}-->
						<a href="{$sl[url]}" title="{$sl[title]}" data-background="{$_G['setting']['ftp']['attachurl']}{if $sl[makethumb] == 1}{$sl[thumbpath]}{else}{$sl[pic]}{/if}" class="slide_img swiper-lazy"></a>
						<!--{else}-->
						<a href="{$sl[url]}" title="{$sl[title]}" data-background="{$sl[pic]}" class="slide_img swiper-lazy"></a>
						<!--{/if}-->
						<a href="{$sl[url]}" title="{$sl[title]}" class="sj_sl_tit"><span style="color: <!--{if $sl_style[title_c]}-->{$sl_style[title_c]}<!--{else}-->{$sl_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($sl[title],42,'')}--></span></a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<div class="sj_slide_hd"></div>
		</div>
	<!--{else}-->
		<p style="background: #fff; text-align: center;">�õ�Ƭģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}-->
<!--{/if}-->

<!--��ͷ����-->
<!--{if $b7_bid}-->
	<!--{eval $b7 = byg_data_block_data($b7_bid, 100);}-->
	<!--{if $b7}-->
		<div data-byginto class="sj_headline_box">
			<div class="sj_headline">
				<ul class="sj_headline_ul swiper-wrapper">
					<!--{loop $b7 $b71}-->
					<!--{eval $b71_fields = unserialize($b71[fields]);}-->
					<!--{eval $b71_style = unserialize($b71[showstyle]);}-->
					<li class="sj_headline_li swiper-slide" style="background-image: url({$_G['style']['styleimgdir']}/headline.png);">
						<a href="{$b71[url]}" title="{$b71[title]}"><h3 style="color: <!--{if $b71_style[title_c]}-->{$b71_style[title_c]}<!--{else}-->{$b71_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($b71[title],38,'')}--></h3></a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	<!--{else}-->
		<p style="background: #fff; text-align: center;">ͷ��ģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}-->
<!--{/if}-->

<!--���Զ��嵼����-->
<!--{if $diy_nav1_p || $diy_nav2_p || $diy_nav3_p || $diy_nav4_p || $diy_nav5_p || $diy_nav6_p || $diy_nav7_p || $diy_nav8_p || $diy_nav9_p || $diy_nav10_p}-->
	<!--{eval}-->
		$diy_nav_num = 0;
		if($diy_nav1_p){ $diy_nav_num++;}
		if($diy_nav2_p){ $diy_nav_num++;}
		if($diy_nav3_p){ $diy_nav_num++;}
		if($diy_nav4_p){ $diy_nav_num++;}
		if($diy_nav5_p){ $diy_nav_num++;}
		if($diy_nav6_p){ $diy_nav_num++;}
		if($diy_nav7_p){ $diy_nav_num++;}
		if($diy_nav8_p){ $diy_nav_num++;}
		if($diy_nav9_p){ $diy_nav_num++;}
		if($diy_nav10_p){ $diy_nav_num++;}
	<!--{/eval}-->
	<div data-byginto class="byg_diynav">
		<style>
			.bg_xin .byg_diynav li{ width: <!--{if $diy_nav_num == 1}-->100%<!--{elseif $diy_nav_num == 2}-->50%<!--{elseif $diy_nav_num == 3 || $diy_nav_num == 6}-->33.3%<!--{elseif $diy_nav_num == 4 || $diy_nav_num == 7 || $diy_nav_num == 8}-->25%<!--{else}-->20%<!--{/if}-->;}
		</style>
		<ul>
			<!--{if $diy_nav1_p}-->
			<!--{eval $diy_nav1 = unserialize($diy_nav1_p);}-->
			<li>
				<a href="{$diy_nav1['url']}">
					<img src="{$diy_nav1['pic']}" alt="{$diy_nav1['text']}"/>
					<p>{$diy_nav1['text']}</p>
				</a>
			</li>
			<!--{/if}-->
			<!--{if $diy_nav2_p}-->
			<!--{eval $diy_nav2 = unserialize($diy_nav2_p);}-->
			<li>
				<a href="{$diy_nav2['url']}">
					<img src="{$diy_nav2['pic']}" alt="{$diy_nav2['text']}"/>
					<p>{$diy_nav2['text']}</p>
				</a>
			</li>
			<!--{/if}-->
			<!--{if $diy_nav3_p}-->
			<!--{eval $diy_nav3 = unserialize($diy_nav3_p);}-->
			<li>
				<a href="{$diy_nav3['url']}">
					<img src="{$diy_nav3['pic']}" alt="{$diy_nav3['text']}"/>
					<p>{$diy_nav3['text']}</p>
				</a>
			</li>
			<!--{/if}-->
			<!--{if $diy_nav4_p}-->
			<!--{eval $diy_nav4 = unserialize($diy_nav4_p);}-->
			<li>
				<a href="{$diy_nav4['url']}">
					<img src="{$diy_nav4['pic']}" alt="{$diy_nav4['text']}"/>
					<p>{$diy_nav4['text']}</p>
				</a>
			</li>
			<!--{/if}-->
			<!--{if $diy_nav5_p}-->
			<!--{eval $diy_nav5 = unserialize($diy_nav5_p);}-->
			<li>
				<a href="{$diy_nav5['url']}">
					<img src="{$diy_nav5['pic']}" alt="{$diy_nav5['text']}"/>
					<p>{$diy_nav5['text']}</p>
				</a>
			</li>
			<!--{/if}-->
			<!--{if $diy_nav6_p}-->
			<!--{eval $diy_nav6 = unserialize($diy_nav6_p);}-->
			<li>
				<a href="{$diy_nav6['url']}">
					<img src="{$diy_nav6['pic']}" alt="{$diy_nav6['text']}"/>
					<p>{$diy_nav6['text']}</p>
				</a>
			</li>
			<!--{/if}-->
			<!--{if $diy_nav7_p}-->
			<!--{eval $diy_nav7 = unserialize($diy_nav7_p);}-->
			<li>
				<a href="{$diy_nav7['url']}">
					<img src="{$diy_nav7['pic']}" alt="{$diy_nav7['text']}"/>
					<p>{$diy_nav7['text']}</p>
				</a>
			</li>
			<!--{/if}-->
			<!--{if $diy_nav8_p}-->
			<!--{eval $diy_nav8 = unserialize($diy_nav8_p);}-->
			<li>
				<a href="{$diy_nav8['url']}">
					<img src="{$diy_nav8['pic']}" alt="{$diy_nav8['text']}"/>
					<p>{$diy_nav8['text']}</p>
				</a>
			</li>
			<!--{/if}-->
			<!--{if $diy_nav9_p}-->
			<!--{eval $diy_nav9 = unserialize($diy_nav9_p);}-->
			<li>
				<a href="{$diy_nav9['url']}">
					<img src="{$diy_nav9['pic']}" alt="{$diy_nav9['text']}"/>
					<p>{$diy_nav9['text']}</p>
				</a>
			</li>
			<!--{/if}-->
			<!--{if $diy_nav10_p}-->
			<!--{eval $diy_nav10 = unserialize($diy_nav10_p);}-->
			<li>
				<a href="{$diy_nav10['url']}">
					<img src="{$diy_nav10['pic']}" alt="{$diy_nav10['text']}"/>
					<p>{$diy_nav10['text']}</p>
				</a>
			</li>
			<!--{/if}-->
		</ul>
	</div>
<!--{elseif $discuz_diy}-->
	<div data-byginto class="byg_diynav">
		<ul>
			{$discuz_diy}
		</ul>
	</div>
<!--{/if}-->

<!--{if $portal_gg1}-->
<div data-byginto class="byg_gg">{$portal_gg1}</div>
<!--{/if}-->

<!--�����¡����š�������-->
<!--{if $b2_bid || $b3_bid || $b4_bid}-->
<div data-byginto id="tabBox1" class="tabBox">
	<div class="tabBox_hd">
		<ul>
		<!--{if $b2_bid}-->
			<!--{eval $b2_title = byg_data_block_tit($b2_bid);}-->
			<li><a href="javascript:;"><h2><!--{if $b2_title}--><!--{eval $b2_title1 = strip_tags("$b2_title");}-->{$b2_title1}<!--{else}-->����<!--{/if}--></h2></a></li>
		<!--{/if}-->
		<!--{if $b3_bid}-->
			<!--{eval $b3_title = byg_data_block_tit($b3_bid);}-->
			<li><a href="javascript:;"><h2><!--{if $b3_title}--><!--{eval $b3_title1 = strip_tags("$b3_title");}-->{$b3_title1}<!--{else}-->����<!--{/if}--></h2></a></li>
		<!--{/if}-->
		<!--{if $b4_bid}-->
			<!--{eval $b4_title = byg_data_block_tit($b4_bid);}-->
			<li><a href="javascript:;"><h2><!--{if $b4_title}--><!--{eval $b4_title1 = strip_tags("$b4_title");}-->{$b4_title1}<!--{else}-->����<!--{/if}--></h2></a></li>
		<!--{/if}-->
		</ul>
	</div>
	<div class="tabBox_bd">
		<!--{if $b2_bid}-->
		<div class="qh_content">
			<ul>
			<!--{eval $b2 = byg_data_block_data($b2_bid, 100);}-->
			<!--{if $b2}-->
				<!--{loop $b2 $b21}-->
				<!--{eval $b21_fields = unserialize($b21[fields]);}-->
				<!--{eval $b21_style = unserialize($b21[showstyle]);}-->
				<li>
					<span class="qh_number"><span class="number number{$b21[displayorder]}">{$b21[displayorder]}</span></span>
					<h3><span><a href="{$b21[url]}" title="{$b21[title]}" style="color: <!--{if $b21_style[title_c]}-->{$b21_style[title_c]}<!--{else}-->{$b21_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($b21[title],34,'')}--></a></span></h3>
					<em>
					<!--{if $b21_fields[authorid]}-->
						<a href="home.php?mod=space&uid={$b21_fields[authorid]}&do=profile"><span><!--{echo cutstr($b21_fields[author],8,'')}--></span></a>
					<!--{elseif $b21_fields[uid]}-->
						<a href="home.php?mod=space&uid={$b21_fields[uid]}&do=profile"><span><!--{echo cutstr($b21_fields[username],8,'')}--></span></a>
					<!--{else}-->
						<a href="javascript:;"><span>{$_G[setting][anonymoustext]}</span></a>
					<!--{/if}-->
					</em>
				</li>
				<!--{/loop}-->
			<!--{else}-->
				<li style="background: #fff; text-align: center;">����ģ�飺�����ݣ��뿴�̡̳���6����</li>
			<!--{/if}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{if $b3_bid}-->
		<div class="qh_content">
			<ul>
			<!--{eval $b3 = byg_data_block_data($b3_bid, 100);}-->
			<!--{if $b3}-->
				<!--{loop $b3 $b31}-->
				<!--{eval $b31_fields = unserialize($b31[fields]);}-->
				<!--{eval $b31_style = unserialize($b31[showstyle]);}-->
				<li>
					<span class="qh_number"><span class="number number{$b31[displayorder]}">{$b31[displayorder]}</span></span>
					<h3><span><a href="{$b31[url]}" title="{$b31[title]}" style="color: <!--{if $b31_style[title_c]}-->{$b31_style[title_c]}<!--{else}-->{$b31_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($b31[title],34,'')}--></a></span></h3>
					<em>
					<!--{if $b31_fields[authorid]}-->
						<a href="home.php?mod=space&uid={$b31_fields[authorid]}&do=profile"><span><!--{echo cutstr($b31_fields[author],8,'')}--></span></a>
					<!--{elseif $b31_fields[uid]}-->
						<a href="home.php?mod=space&uid={$b31_fields[uid]}&do=profile"><span><!--{echo cutstr($b31_fields[username],8,'')}--></span></a>
					<!--{else}-->
						<a href="javascript:;"><span>{$_G[setting][anonymoustext]}</span></a>
					<!--{/if}-->
					</em>
				</li>
				<!--{/loop}-->
			<!--{else}-->
				<li style="background: #fff; text-align: center;">����ģ�飺�����ݣ��뿴�̡̳���6����</li>
			<!--{/if}-->
			</ul>
		</div>
		<!--{/if}-->
		<!--{if $b4_bid}-->
		<div class="qh_content">
			<ul>
			<!--{eval $b4 = byg_data_block_data($b4_bid, 100);}-->
			<!--{if $b4}-->
				<!--{loop $b4 $b41}-->
				<!--{eval $b41_fields = unserialize($b41[fields]);}-->
				<!--{eval $b41_style = unserialize($b41[showstyle]);}-->
				<li>
					<span class="qh_number"><span class="number number{$b41[displayorder]}">{$b41[displayorder]}</span></span>
					<h3><span><a href="{$b41[url]}" title="{$b41[title]}" style="color: <!--{if $b41_style[title_c]}-->{$b41_style[title_c]}<!--{else}-->{$b41_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($b41[title],34,'')}--></a></span></h3>
					<em>
					<!--{if $b41_fields[authorid]}-->
						<a href="home.php?mod=space&uid={$b41_fields[authorid]}&do=profile"><span><!--{echo cutstr($b41_fields[author],8,'')}--></span></a>
					<!--{elseif $b41_fields[uid]}-->
						<a href="home.php?mod=space&uid={$b41_fields[uid]}&do=profile"><span><!--{echo cutstr($b41_fields[username],8,'')}--></span></a>
					<!--{else}-->
						<a href="javascript:;"><span>{$_G[setting][anonymoustext]}</span></a>
					<!--{/if}-->
					</em>
				</li>
				<!--{/loop}-->
			<!--{else}-->
				<li style="background: #fff; text-align: center;">����ģ�飺�����ݣ��뿴�̡̳���6����</li>
			<!--{/if}-->
			</ul>
		</div>
		<!--{/if}-->
	</div>
</div>
<!--{/if}-->

<!--{if $portal_gg2}-->
<div data-byginto class="byg_gg">{$portal_gg2}</div>
<!--{/if}-->

<!--��ͼ���Ƽ���-->
<!--{if $b5_bid}-->
	<!--{eval $b5 = byg_data_block_data($b5_bid, 100);}-->
	<!--{if $b5}-->
		<div data-byginto class="tuwen">
			<div class="tw_tab">
				<!--{eval $b5_title = byg_data_block_tit($b5_bid);}-->
				<h2><!--{if $b5_title}--><!--{eval $b5_title1 = strip_tags("$b5_title");}-->{$b5_title1}<!--{else}-->ͼ���Ƽ�<!--{/if}--></h2>
			</div>
			<ul>
				<!--{loop $b5 $b51}-->
				<!--{eval $b51_fields = unserialize($b51[fields]);}-->
				<!--{eval $b51_style = unserialize($b51[showstyle]);}-->
				<li class="cl">
					<div class="z lanjiazai_bg">
						<!--{if $b51[picflag] == 1}-->
						<a href="{$b51[url]}" title="{$b51[title]}" class="tw_z lanjiazai" data-original="{$_G['setting']['attachurl']}{if $b51[makethumb] == 1}{$b51[thumbpath]}{else}{$b51[pic]}{/if}"></a>
						<!--{elseif $b51[picflag] == 2}-->
						<a href="{$b51[url]}" title="{$b51[title]}" class="tw_z lanjiazai" data-original="{$_G['setting']['ftp']['attachurl']}{if $b51[makethumb] == 1}{$b51[thumbpath]}{else}{$b51[pic]}{/if}"></a>
						<!--{else}-->
						<a href="{$b51[url]}" title="{$b51[title]}" class="tw_z lanjiazai" data-original="{$b51[pic]}"></a>
						<!--{/if}-->
					</div>
					<div class="tw_y">
						<h3><a href="{$b51[url]}" title="{$b51[title]}" style="color: <!--{if $b51_style[title_c]}-->{$b51_style[title_c]}<!--{else}-->{$b51_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($b51[title],52,'')}--></a></h3>
						<span class="tw_y_time"><!--{echo dgmdate($b51_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
						<em>
						<!--{if $b51_fields[authorid]}-->
							<a href="home.php?mod=space&uid={$b51_fields[authorid]}&do=profile"><i class="lanjiazai img_center" data-original="<!--{avatar($b51_fields[authorid], middle, true)}-->"></i>&nbsp;{$b51_fields[author]}</a>
						<!--{elseif $b51_fields[uid]}-->
							<a href="home.php?mod=space&uid={$b51_fields[uid]}&do=profile"><i class="lanjiazai img_center" data-original="<!--{avatar($b51_fields[uid], middle, true)}-->"></i>&nbsp;{$b51_fields[username]}</a>
						<!--{else}-->
							<a href="javascript:;"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/middle.gif"></i>&nbsp;{$_G[setting][anonymoustext]}</a>
						<!--{/if}-->
						</em>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	<!--{else}-->
		<p style="background: #fff; text-align: center;">ͼ���Ƽ�ģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}-->
<!--{/if}-->


<!--�����»��-->
<!--{if $b6_bid}-->
	<!--{eval $b6 = byg_data_block_data($b6_bid, 5);}-->
	<!--{if $b6}-->
		<div data-byginto id="portal_activity">
			<div class="ac_hd">
				<!--{eval $b6_title = byg_data_block_tit($b6_bid);}-->
				<h2><!--{if $b6_title}--><!--{eval $b6_title1 = strip_tags("$b6_title");}-->{$b6_title1}<!--{else}-->���»<!--{/if}--></h2>
				<span class="next y"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/ac-next.png"></i></span>
				<ul></ul>
				<span class="prev y"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/ac-prev.png"></i></span>
			</div>
			<div class="portal_activity">
				<div class="ac_bd">
					<ul>
						<!--{loop $b6 $b61}-->
						<!--{eval $b61_fields = unserialize($b61[fields]);}-->
						<!--{eval $b61_style = unserialize($b61[showstyle]);}-->
						<li>
							<div class="z lanjiazai_bg">
								<!--{if $b61[picflag] == 1}-->
								<a href="{$b61[url]}" title="{$b61[title]}" class="tw_z" style="background-image:url({$_G['setting']['attachurl']}{if $b61[makethumb] == 1}{$b61[thumbpath]}{else}{$b61[pic]}{/if});"></a>
								<!--{elseif $b61[picflag] == 2}-->
								<a href="{$b61[url]}" title="{$b61[title]}" class="tw_z" style="background-image:url({$_G['setting']['ftp']['attachurl']}{if $b61[makethumb] == 1}{$b61[thumbpath]}{else}{$b61[pic]}{/if});"></a>
								<!--{else}-->
								<a href="{$b61[url]}" title="{$b61[title]}" class="tw_z" style="background-image:url({$b61[pic]});"></a>
								<!--{/if}-->
							</div>
							<h3><a href="{$b61[url]}" title="{$b61[title]}" style="color: <!--{if $b61_style[title_c]}-->{$b61_style[title_c]}<!--{else}-->{$b61_fields[showstyle][title_c]}<!--{/if}-->;"><span>HOT</span>&nbsp;<!--{echo cutstr($b61[title],38,'')}--></a></h3>
							<div class="clear"></div>
						</li>
						<!--{/loop}-->
					</ul>
				</div>
			</div>
		</div>
	<!--{else}-->
		<p style="background: #fff; text-align: center;">���»ģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}-->
<!--{/if}-->

<!--�����ظ��ࡿ-->
<!--{if $load_more_bid}-->
<div class="load_more">
	<!--{eval $load_more = byg_data_block_data($load_more_bid, 999);}-->
	<!--{if $load_more}-->
		<ul class="load_more_hidden">
			<!--{loop $load_more $load_more1}-->
			<li data-byginto class="load_more_li cl">
				<!--{eval $lm_fields = unserialize($load_more1[fields]);}-->
				<!--{eval $lm_style = unserialize($load_more1[showstyle]);}-->
				<div class="load_more_t cl">
				<!--{if $lm_fields[authorid] || $lm_fields[authorid] == "0"}-->
					<a href="home.php?mod=space&uid={$lm_fields[authorid]}&do=profile" title="{$lm_fields[author]}" class="z lanjiazai_bg"><i class="load_more_avatar z lanjiazai img_center" data-original="<!--{avatar($lm_fields[authorid], middle, true)}-->"></i></a>
					<div class="y">
						<p class="load_more_author"><a href="home.php?mod=space&uid={$lm_fields[authorid]}&do=profile" title="{$lm_fields[author]}">{$lm_fields[author]}</a></p>
						<p class="load_more_date"><!--{echo dgmdate($lm_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></p>
					</div>
					<a href="{$lm_fields[forumurl]}" title="{$lm_fields[forumname]}" class="load_more_from">#{$lm_fields[forumname]}</a>
				<!--{else}-->
					<a href="home.php?mod=space&uid={$lm_fields[uid]}&do=profile" title="{$lm_fields[username]}" class="z lanjiazai_bg"><i class="load_more_avatar z lanjiazai img_center" data-original="<!--{avatar($lm_fields[uid], middle, true)}-->"></i></a>
					<div class="y">
						<p class="load_more_author"><a href="home.php?mod=space&uid={$lm_fields[uid]}&do=profile" title="{$lm_fields[username]}">{$lm_fields[username]}</a></p>
						<p class="load_more_date"><!--{echo dgmdate($lm_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></p>
					</div>
					<a href="{$lm_fields[caturl]}" title="{$lm_fields[catname]}" class="load_more_from">#{$lm_fields[catname]}</a>
				<!--{/if}-->
				</div>
				<div class="load_more_c cl">
					<a href="{$load_more1[url]}" title="{$load_more1[title]}"><h3 class="load_more_title" style="color: <!--{if $lm_style[title_c]}-->{$lm_style[title_c]}<!--{else}-->{$lm_fields[showstyle][title_c]}<!--{/if}-->;">{$load_more1[title]}</h3></a>
					<!--{if $lm_fields[authorid] || $lm_fields[authorid] == "0"}-->
						<!--{if $load_more1[idtype] == "tid"}-->
							<!--{eval}-->
								$biaoid = substr($load_more1[id], -1);
								$img_number = byg_threadlist_img_num($load_more1[id], $lm_fields[authorid], $biaoid);
							<!--{/eval}-->
							<!--{if $img_number == 1}-->
								<!--{eval $list_img1 = byg_threadlist_img($load_more1[id], $lm_fields[authorid], 1, $biaoid);}-->
								<!--{loop $list_img1 $list_img1_1}-->
								<div class="load_more_img1 cl">
									<a href="{$load_more1[url]}" title="{$load_more1[title]}" class="z"><img src="{$_G['style']['styleimgdir']}/lanjiazai.gif" data-original="{eval echo(getforumimg($list_img1_1[aid],0,400,0))}" class="lanjiazai" alt="{$load_more1[title]}" /></a>
								</div>
								<!--{/loop}-->
							<!--{elseif $img_number > 1}-->
								<div class="load_more_img3 cl">
								<!--{eval $list_img3 = byg_threadlist_img($load_more1[id], $lm_fields[authorid], 9, $biaoid);}-->
								<!--{loop $list_img3 $list_img3_1}-->
									<div class="z lanjiazai_bg">
										<a href="{$load_more1[url]}" title="{$load_more1[title]}" class="img_center lanjiazai" data-original="{eval echo(getforumimg($list_img3_1[aid],0,200,200))}"></a>
									</div>
								<!--{/loop}-->
								</div>
							<!--{/if}-->
						<!--{/if}-->
					<!--{else}-->
						<!--{if $load_more1[idtype] == "aid"}-->
							<!--{eval $img_number = byg_article_img_num($load_more1[id], $lm_fields[uid]);}-->
							<!--{if $img_number == 1}-->
								<!--{eval $list_img1 = byg_article_img($load_more1[id], $lm_fields[uid], 1);}-->
								<!--{loop $list_img1 $list_img1_1}-->
								<div class="load_more_img1 cl">
									<a href="{$load_more1[url]}" title="{$load_more1[title]}" class="z"><img src="{$_G['style']['styleimgdir']}/lanjiazai.gif" data-original="{if $list_img1_1[remote] == 0}{$_G['setting']['attachurl']}portal/{$list_img1_1[attachment]}{else}{$_G['setting']['ftp']['attachurl']}portal/{$list_img1_1[attachment]}{/if}" class="lanjiazai" alt="{$load_more1[title]}" /></a>
								</div>
								<!--{/loop}-->
							<!--{elseif $img_number > 1}-->
								<div class="load_more_img3 cl">
								<!--{eval $list_img3 = byg_article_img($load_more1[id], $lm_fields[uid], 9);}-->
								<!--{loop $list_img3 $list_img3_1}-->
									<div class="z lanjiazai_bg">
										<a href="{$load_more1[url]}" title="{$load_more1[title]}" class="img_center lanjiazai" data-original="{if $list_img3_1[remote] == 0}{$_G['setting']['attachurl']}portal/{$list_img3_1[attachment]}{else}{$_G['setting']['ftp']['attachurl']}portal/{$list_img3_1[attachment]}{/if}"></a>
									</div>
								<!--{/loop}-->
								</div>
							<!--{/if}-->
						<!--{/if}-->
					<!--{/if}-->
				</div>
				<div class="load_more_b cl">
					<a href="{$load_more1[url]}">
					<!--{if $lm_fields[authorid] || $lm_fields[authorid] == "0"}-->
						<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/chakan.png"></i>{$lm_fields[views]}</span>
						<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/forum_posts.png"></i>{$lm_fields[replies]}</span>
						<span class="y"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/zan.png"></i>{$lm_fields[recommends]}</span>
					<!--{else}-->
						<span class="z" style="width:1.76rem;"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/chakan.png"></i>{$lm_fields[viewnum]}</span>
						<span class="y" style="width:1.76rem;"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/forum_posts.png"></i>{$lm_fields[commentnum]}</span>
					<!--{/if}-->
					</a>
				</div>
			</li>
			<!--{/loop}-->
		</ul>
		<ul class="load_more_ul"></ul>
		<div class="load_more_button">
			<a href="javascript:;"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/loading.gif"></i>���ݼ����У����Ժ�...</a>
		</div>
		<script type="text/javascript">
			var _content = [];
			var loadding = {
				_default:5, //���ظ���ģ��-ֱ����ʾ�ĸ���
				_loading:10, //���ظ���ģ��-ÿ�μ��صĸ���
				init:function(){
					var lis = jQuery(".load_more_li");
					jQuery(".load_more_ul").html("");
					for(var n=0;n<loadding._default;n++){
						lis.eq(n).appendTo(".load_more_ul");
					}
					for(var i=loadding._default;i<lis.length;i++){
						_content.push(lis.eq(i));
					}
				}
			}
			loadding.init();
			
			function list_ajax() {
				for(var i =0;i<loadding._loading;i++) {
					var target = _content.shift();
					if(!target) {
						jQuery(".load_more_button").html('<a href="forum.php?forumlist=1" title="��̳">�Ѿ������ˣ�������̳���ָ���</a>');
						break;
					}
					jQuery(".load_more_ul").append(target);
				}
			}
			
			if(jQuery(document).height() <= jQuery(window).height()) {
				list_ajax();
			}
			
			jQuery(window).scroll(function() {
				if(jQuery(document).height() <= jQuery(window).height() + jQuery(window).scrollTop() + 1000) {
					list_ajax();
				}
			});
		</script>
	<!--{else}--> 
		<p style="background: #fff; text-align: center;">���ظ���ģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}--> 
</div>
<!--{/if}-->

<!--{template common/footer}-->

