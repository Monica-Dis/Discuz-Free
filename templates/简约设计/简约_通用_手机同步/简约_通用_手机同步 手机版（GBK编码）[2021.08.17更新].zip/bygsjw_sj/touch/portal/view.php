<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<a href="portal.php">{lang portal}</a>
			<em>&rsaquo;</em>
			<!--{loop $cat[ups] $value}-->
			<a href="{echo getportalcategoryurl($value[catid])}">$value[catname]</a>
			<em>&rsaquo;</em>
			<!--{/loop}-->
			<a href="{echo getportalcategoryurl($cat[catid])}">$cat[catname]</a>
			<em>&rsaquo;</em>
			<span>����</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="����"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="portal_cat">
	<!--�Ż�Ƶ����ط��࿪ʼ-->
	<link rel="stylesheet" href="{$_G['style']['styleimgdir']}/swiper.min.css" type="text/css">
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
	<!--{if $cat[others]}-->
	<div class="portal_cat_top">
		<div class="swiper-wrapper">
			<!--{loop $cat[others] $value}-->
			<a href="{echo getportalcategoryurl($value[catid])}" class="swiper-slide<!--{if $_GET['catid'] == $value['catid']}--> on<!--{/if}-->">{$value[catname]}</a>
			<!--{/loop}-->
		</div>
	</div>
	<script type="text/javascript">
		var tab_initial = jQuery(".portal_cat_top .on").length > 0 ? jQuery(".portal_cat_top .on").index() : 0;
		var portal_cat_top = new Swiper('.portal_cat_top', {
			initialSlide : tab_initial,
			slidesPerView : 'auto',
			freeMode : true,
		});
	</script>
	<!--{/if}-->
	<!--�Ż�Ƶ���¼����࿪ʼ-->
	<!--{if $cat[subs]}-->
	<div class="portal_cat_sub">
		<div class="swiper-wrapper">
			<span></span>
			<!--{loop $cat[subs] $value}-->
			<a href="{echo getportalcategoryurl($value[catid])}" class="swiper-slide">$value[catname]</a>
			<!--{/loop}-->
		</div>
	</div>
	<script type="text/javascript">
		var tab_initial = jQuery(".portal_cat_sub .on").length > 0 ? jQuery(".portal_cat_sub .on").index() : 0;
		var portal_cat_sub = new Swiper('.portal_cat_sub', {
			initialSlide : tab_initial,
			slidesPerView : 'auto',
			freeMode : true,
		});
	</script>
	<!--{/if}-->
</div>

<!--�Ż�����ҳ���¿�ʼ-->
<div class="portal_content_t">
	<div class="title">
		<h1>$article[title] <!--{if $article['status'] == 1}-->({lang moderate_need})<!--{elseif $article['status'] == 2}-->({lang ignored})<!--{/if}--></h1>
		<p>
			<span class="y">$article[dateline]</span>
			<a href="home.php?mod=space&uid=$article[uid]&do=profile">$article[username]</a>&nbsp;&nbsp;
			{lang view_views}&nbsp;:&nbsp;<em id="_viewnum"><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}--></em>&nbsp;&nbsp;
			{lang view_comments}&nbsp;:&nbsp;<!--{if $article[commentnum] > 0}--><a href="$common_url" title="{lang view_all_comments}"><em id="_commentnum">$article[commentnum]</em></a><!--{else}-->0<!--{/if}-->&nbsp;&nbsp;
		</p>
	</div>

	<div id="article_content">$content[content]</div>
	<!--{if $multi}--><div class="ptw pbw cl">$multi</div><!--{/if}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>

	<div id="click_div">
		<!--{template home/space_click}-->
	</div>

	<!--{if $article['preaid'] || $article['nextaid']}-->
	<div class="pren">
		<!--{if $article['prearticle']}--><em>{lang pre_article}<a href="{$article['prearticle']['url']}" title="{$article['prearticle']['title']}"><!--{echo cutstr($article['prearticle']['title'],36,'')}--></a></em><!--{/if}-->
		<!--{if $article['nextarticle']}--><em>{lang next_article}<a href="{$article['nextarticle']['url']}" title="{$article['nextarticle']['title']}"><!--{echo cutstr($article['nextarticle']['title'],36,'')}--></a></em><!--{/if}-->
	</div>
	<!--{/if}-->
</div>

<!--{eval $portal_view_gg = byg_diy_block_sum('��Լͨ���ֻ����Ż�����ҳ���');}-->
<!--{if $portal_view_gg}-->
<div class="byg_gg">{$portal_view_gg}</div>
<!--{/if}-->

<!--�Ż�����ҳ����Ķ���ʼ-->
<!--{if $article['related']}-->
<div id="related_article" class="portal_content_c">
	<div class="pcc_title">
		<h3>{lang view_related}</h3>
	</div>
	<div class="pcc_content">
		<ul class="cl" id="raid_div">
		<!--{loop $article['related'] $raid $rvalue}-->
			<input type="hidden" value="$raid" />
			<li>&bull; <a href="{$rvalue[uri]}" title="{$rvalue[title]}"><!--{echo cutstr($rvalue[title],40,'')}--></a></li>
		<!--{/loop}-->
		</ul>
	</div>
</div>
<!--{/if}-->

<!--�Ż�����ҳ�������ۿ�ʼ-->
<!--{if $article['allowcomment']==1}-->
	<!--{eval $data = &$article}-->
	<!--{subtemplate portal/portal_comment}-->
<!--{/if}-->

<!--{template common/footer}-->

