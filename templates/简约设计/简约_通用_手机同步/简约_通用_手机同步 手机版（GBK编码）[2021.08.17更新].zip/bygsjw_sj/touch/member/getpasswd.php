<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header">
		<div class="header_z cl">
			<a href="javascript:;" class="shouye">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<em>&rsaquo;</em>
			<span>{lang getpassword}</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/houtui.png" alt="����"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="byg_getpasswd">
<style>
	.byg_getpasswd{ margin: .1rem; padding: .1rem; border-radius: .1rem;}
	.byg_getpasswd .px, .byg_getpasswd_p1{ display: block; width: 3.15rem; line-height: .25rem; margin-bottom: .1rem; padding: .1rem; border: 0; font-size: .16rem; background: #fff;}
	.byg_getpasswd_p1 em{ color: #999;}
	.byg_getpasswd_p2{ margin: .1rem; font-size: .14rem; color: #888;}
	.byg_getpasswd button{ width: 100%; height: .45rem; line-height: .45rem; font-size: .18rem; font-weight: 400;}
</style>
	<form method="post" autocomplete="off" action="member.php?mod=getpasswd&uid=$uid&id=$hashid&sign=$_GET[sign]">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="c cl">
			<p class="byg_getpasswd_p1"><em>{lang username} : </em>$member[username]</p>
			<p class="byg_getpasswd_p2">
				<i class="d" id="chk_newpasswd1">{lang register_password_tips}<!--{if $_G['setting']['pwlength']}-->, {lang register_password_length_tips1} $_G['setting']['pwlength'] {lang register_password_length_tips2}<!--{/if}--></i>
			</p>
			<input type="password" id="newpasswd1" name="newpasswd1" class="px" placeholder="{lang new_password}"/>
			<input type="password" id="newpasswd2" name="newpasswd2" class="px" placeholder="{lang new_password_confirm}"/>
		</div>
		<button class="pn pnc" type="submit" name="getpwsubmit" value="true"><span>{lang submit}</span></button>
	</form>
</div>

<!--{template common/footer}-->
