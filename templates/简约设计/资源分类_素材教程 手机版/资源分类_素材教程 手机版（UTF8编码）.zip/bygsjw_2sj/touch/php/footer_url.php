<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//更新url
$havedomain = implode('', $_G['setting']['domain']['app']);
if($_G['setting']['rewritestatus'] || !empty($havedomain)) {
	$content = ob_get_contents();
	$content = str_replace('&mobile=2', '', $content);
	$content = output_replace($content);
	ob_end_clean();
	$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
	echo $content;
}
//From: Dism_taobao-com
?>
