<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//获取数据DIY模块的ID
function byg_data_block_id($name) {
	if (byg_diy_block_bool($name)) {
		$data_block_id = DB::result(DB::query("SELECT a.bid FROM ".DB::table('common_block')." a LEFT JOIN ".DB::table('common_template_block')." b ON a.bid=b.bid WHERE a.name = '$name' AND b.targettplname = 'portal/index' ORDER BY a.bid DESC"));
		if(!$data_block_id) {
			$data_block_id = DB::result(DB::query("SELECT bid FROM ".DB::table('common_block')." WHERE name = '$name' ORDER BY bid DESC"));
		}
		return $data_block_id;
	}
}

//获取数据模块的数据
function byg_data_block_data($bid, $num) {
	$data_block_data = DB::fetch_all("SELECT * FROM ".DB::table('common_block_item')." WHERE bid = '$bid' ORDER BY displayorder ASC LIMIT $num");
	return $data_block_data;
}

//获取数据模块的标题
function byg_data_block_tit($bid) {
	$data_block_tit = DB::result(DB::query("SELECT title FROM ".DB::table('common_block')." WHERE bid = '$bid'"));
	return $data_block_tit;
}

$index_bg_p = byg_diy_block_param('资源分类手机版门户首页欢迎图片');
$bygsjw_logo = byg_diy_block_sum('资源分类手机版LOGO');
$slide_bid = byg_data_block_id('资源分类门户首页幻灯片');
$four_case_tit1_param = byg_diy_block_param('资源分类手机版门户首页四格导航1标题');
$four_case_tit2_param = byg_diy_block_param('资源分类手机版门户首页四格导航2标题');
$four_case_tit3_param = byg_diy_block_param('资源分类手机版门户首页四格导航3标题');
$four_case_tit4_param = byg_diy_block_param('资源分类手机版门户首页四格导航4标题');
$good_bid = byg_data_block_id('资源分类门户首页发现好资源');
$portal_gg1 = byg_diy_block_sum('资源分类手机版门户首页广告1');
$new_bid = byg_data_block_id('资源分类门户首页最新资源');
$portal_gg2 = byg_diy_block_sum('资源分类手机版门户首页广告2');
$hot_bid = byg_data_block_id('资源分类门户首页最热资源');
$portal_gg3 = byg_diy_block_sum('资源分类手机版门户首页广告3');
$news_bid = byg_data_block_id('资源分类门户首页新闻资讯');
$portal_gg4 = byg_diy_block_sum('资源分类手机版门户首页广告4');
$load_more_bid = byg_data_block_id('资源分类手机版加载更多');

?>
