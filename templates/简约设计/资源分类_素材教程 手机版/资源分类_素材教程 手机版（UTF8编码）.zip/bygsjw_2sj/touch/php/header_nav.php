<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$font_nav1_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航1');
$font_nav2_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航2');
$font_nav3_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航3');
$font_nav4_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航4');
$font_nav5_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航5');
$font_nav6_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航6');
$font_nav7_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航7');
$font_nav8_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航8');
$font_nav9_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航9');
$font_nav10_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航10');
$font_nav11_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航11');
$font_nav12_p = byg_diy_block_param('资源分类手机版门户首页顶部文字导航12');

?>
