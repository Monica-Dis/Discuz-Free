<?php echo 'From: DisM.taobao.com';exit;?>

<a name="comment_anchor_$comment[cid]"></a>
<li id="comment_{$comment[cid]}_li">
	<div class="cl">
		<!--{if !empty($comment['uid'])}-->
		<a href="home.php?mod=space&uid=$comment[uid]&do=profile" class="z"><!--{avatar($comment[uid],middle)}--></a>
		<!--{else}-->
		<a href="#" class="z"><img src="{$_G['style']['styleimgdir']}/middle.gif" alt="头像"/></a>
		<!--{/if}-->
		<div class="y y_t">
			<!--{if !empty($comment['uid'])}-->
			<a href="home.php?mod=space&uid=$comment[uid]&do=profile" c="1">$comment[username]</a>
			<!--{else}-->
			{lang guest}
			<!--{/if}-->
		</div>
		<div class="y y_b">
			<span><!--{date($comment[dateline])}--></span>
			<span class="y">
				<!--{if !isset($_G[makehtml]) && !$data[htmlmade]}--><a href="javascript:;" onclick="portal_comment_requote($comment[cid], '$article[aid]');"><img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="回复"/></a>
				<!--{/if}-->
				<!--{if ($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']}-->
				<a href="portal.php?mod=portalcp&ac=comment&op=edit&cid=$comment[cid]" id="c_$comment[cid]_edit"><img src="{$_G['style']['styleimgdir']}/xiugai.png" alt="{lang edit}"/></a>
				<a href="portal.php?mod=portalcp&ac=comment&op=delete&cid=$comment[cid]" id="c_$comment[cid]_delete"><img src="{$_G['style']['styleimgdir']}/shanchu.png" alt="{lang delete}"/></a>
				<!--{/if}-->
			</span>
		</div>
	</div>
	<p><!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->$comment[message]<!--{else}--> {lang moderate_not_validate}<!--{/if}--></p>
</li>
