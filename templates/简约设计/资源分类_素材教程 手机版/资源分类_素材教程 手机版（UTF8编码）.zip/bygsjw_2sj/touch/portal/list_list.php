<?php echo 'From: DisM.taobao.com';exit;?>

<!--{loop $list['list'] $value}-->
	<!--{eval $highlight = article_title_style($value);}-->
	<!--{eval $article_url = fetch_article_url($value);}-->
	<dl class="list_dl cl">
		<dt class="list_dt_yt y">
			<a href="$article_url" title="$value[title]" $highlight><!--{echo cutstr($value[title],52,'')}--></a>
		</dt>
		<dd class="list_dd_z z">
			<!--{if $value[pic]}-->
			<a href="$article_url" title="$value[title]" style="background-image: url($value[pic]);"></a>
			<!--{else}-->
			<a href="$article_url" title="$value[title]" style="background-image: url({$_G['style']['styleimgdir']}/nophoto.gif);"></a>
			<!--{/if}-->
		</dd>
		<dd class="list_dd_yc y">
			<a href="$article_url"><!--{echo cutstr($value[summary],60)}--></a>
		</dd>
		<dd class="list_dd_yb y">
			<span>$value[dateline]</span>
		</dd>
	</dl>
<!--{/loop}-->

