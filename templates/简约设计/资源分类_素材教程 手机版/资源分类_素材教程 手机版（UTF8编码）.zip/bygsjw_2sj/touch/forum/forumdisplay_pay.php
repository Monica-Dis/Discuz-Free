<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin cl">
			<a href="javascript:;" class="header_z">
				<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="菜单"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<div class="header_c">
				<span class="header_font">提示信息</span>
			</div>
			<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="返回"/></a>
		</div>
		<!--{template common/header_nav}-->
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="fdy_pay_box">
	<h3>{lang youneedpay} $paycredits {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit']}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title']} {lang onlyintoforum}</h3>
	<div class="fdy_pay_form">
		<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=paysubmit">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<button class="vm" type="submit" name="loginsubmit" value="true">{lang confirmyourpay}</button>
			<button class="vm" type="button" onclick="history.go(-1)" style="margin-left: .1rem;">{lang cancel}</button>
		</form>
	</div>
</div>

<!--{template common/footer}-->

