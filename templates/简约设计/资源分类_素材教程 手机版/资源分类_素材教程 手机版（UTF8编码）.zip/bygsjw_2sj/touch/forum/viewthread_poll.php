<?php echo 'From: DisM.taobao.com';exit;?>

<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>

<div class="byg_poll">
<form id="poll" name="poll" method="post" autocomplete="off" action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes&mobile=2" >
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="byg_pinf">
		<!--{if $multiple}--><strong>{lang poll_multiple}{lang thread_poll}</strong><!--{if $maxchoices}-->: ( {lang poll_more_than} )<!--{/if}--><!--{else}--><strong>{lang poll_single}{lang thread_poll}</strong><!--{/if}--><!--{if $visiblepoll && $_G['group']['allowvote']}--> , {lang poll_after_result}<!--{/if}-->, {lang poll_voterscount}
	</div>

	<!--{if $_G[forum_thread][remaintime]}-->
	<p class="byg_ptmr">
		{lang poll_count_down}:
		<span class="xg1">
		<!--{if $_G[forum_thread][remaintime][0]}-->$_G[forum_thread][remaintime][0] {lang days}<!--{/if}-->
		<!--{if $_G[forum_thread][remaintime][1]}-->$_G[forum_thread][remaintime][1] {lang poll_hour}<!--{/if}-->
		$_G[forum_thread][remaintime][2] {lang poll_minute}
		</span>
	</p>
	<!--{elseif $expiration && $expirations < TIMESTAMP}-->
	<p class="byg_ptmr"><strong>{lang poll_end}</strong></p>
	<!--{/if}-->

	<div>
        <!--{loop $polloptions $key $option}-->
            <div class="byg_pcht_font">
            <!--{if $isimagepoll}-->
				<!--{eval $imginfo=$option['imginfo'];}-->
				<!--{if $imginfo}-->
					<img src="$imginfo[big]" alt="$imginfo[filename]" class="byg_pcht_img" />
				<!--{else}-->
					<img src="{IMGDIR}/nophoto.gif" alt="没有图片" class="byg_pcht_img" />
				<!--{/if}-->
           	<!--{/if}-->
            <!--{if $_G['group']['allowvote']}-->
                <input type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if} />
            <!--{/if}-->
            	<label for="option_$key">$key.$option[polloption]</label>
            <!--{if !$visiblepoll}-->
				<div class="pcht_font_b cl">
					<div class="pbg">
						<div class="pbr" style="width: $option[width]; background-color:#$option[color]"></div>
					</div>
					$option[percent]% <em style="color:#$option[color]">($option[votes])</em>
				</div>
            <!--{/if}-->
            </div>
        <!--{/loop}-->
        <!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
		<div class="byg_pcht_b">
            <input type="submit" name="pollsubmit" id="pollsubmit" value="{lang submit}" />
            <!--{if $overt}-->
                <span class="xg2">({lang poll_msg_overt})</span>
            <!--{/if}-->
        </div>
        <!--{elseif !$allwvoteusergroup}-->
        <div class="byg_pcht_b">
            <!--{if !$_G['uid']}-->
            <span class="xi1">{lang poll_msg_allwvote_user}</span>
            <!--{else}-->
            <span class="xi1">{lang poll_msg_allwvoteusergroup}</span>
            <!--{/if}-->
        </div>
        <!--{elseif !$allowvotepolled}-->
        <div class="byg_pcht_b">
            <span class="xi1">{lang poll_msg_allowvotepolled}</span>
        </div>
        <!--{elseif !$allowvotethread}-->
        <div class="byg_pcht_b">
            <span class="xi1">{lang poll_msg_allowvotethread}</span>
        </div>
        <!--{/if}-->
	</div>
</form>
</div>

