<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin cl">
			<a href="javascript:;" class="header_z">
				<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="菜单"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<div class="header_c">
				<span class="header_font">提示信息</span>
			</div>
			<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="返回"/></a>
		</div>
		<!--{template common/header_nav}-->
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="fdy_passwd_box">
	<h3>{lang forum_password_require}</h3>
	<div class="fdy_passwd_form">
		<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=pwverify">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="password" name="pw" class="px vm" size="25" />
			<button class="vm" type="submit" name="loginsubmit" value="true">{lang submit}</button>
		</form>
	</div>
</div>

<!--{template common/footer}-->
