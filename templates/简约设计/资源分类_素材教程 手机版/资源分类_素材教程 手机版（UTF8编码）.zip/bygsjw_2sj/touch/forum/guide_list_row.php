<?php echo 'From: DisM.taobao.com';exit;?>

<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/forum_forumdisplay_list.php');}-->

<!--{loop $list['threadlist'] $key $thread}-->
	<!--{eval $biaoid = substr($thread[tid], -1);}-->
	<!--{eval $img_number = byg_threadlist_img_num($thread[tid], $thread[authorid], $biaoid);}-->
	<li class="cl hotlist_ajax {if $img_number == 1 || $img_number == 2}list_img1_box{/if}">
		<div class="list_top cl">
			<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="over_two">
			<!--{if $thread[folder] == 'lock'}-->
				<img src="{IMGDIR}/folder_lock.gif" alt="锁定" />
			<!--{elseif $thread['special'] == 1}-->
				<img src="{IMGDIR}/pollsmall.gif" alt="{lang thread_poll}" />
			<!--{elseif $thread['special'] == 2}-->
				<img src="{IMGDIR}/tradesmall.gif" alt="{lang thread_trade}" />
			<!--{elseif $thread['special'] == 3}-->
				<img src="{IMGDIR}/rewardsmall.gif" alt="{lang thread_reward}" />
			<!--{elseif $thread['special'] == 4}-->
				<img src="{IMGDIR}/activitysmall.gif" alt="{lang thread_activity}" />
			<!--{elseif $thread['special'] == 5}-->
				<img src="{IMGDIR}/debatesmall.gif" alt="{lang thread_debate}" />
			<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
			<!--{else}-->
				<img src="{IMGDIR}/folder_$thread[folder].gif" alt="普通" />
			<!--{/if}-->
			<!--{if $thread['price'] > 0}-->
				<!--{if $thread['special'] == '3'}-->
				<span class="list_typename">{lang thread_reward}{$thread[price]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}</span>
				<!--{else}-->
				<span class="list_typename">{lang price}{$thread[price]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}</span>
				<!--{/if}-->
			<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
				<span class="list_typename">{lang reward_solved}</span>
			<!--{/if}-->
			{$thread[subject]}</a>
		</div>
	<!--{if $_G['style']['luntan_liebiaotu'] == 'on'}-->
		<!--{if $img_number == 1 || $img_number == 2}-->
			<!--{eval $list_img1 = byg_threadlist_img($thread[tid], $thread[authorid], 1, $biaoid);}-->
			<!--{loop $list_img1 $list_img1_1}-->
			<div class="list_img1 cl">
				<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" style="background-image:url({eval echo(getforumimg($list_img1_1[aid],0,230,150))});"></a>
			</div>
			<!--{/loop}-->
		<!--{elseif $img_number > 2}-->
			<ul class="list_img3 cl">
			<!--{eval $list_img3 = byg_threadlist_img($thread[tid], $thread[authorid], 3, $biaoid);}-->
			<!--{loop $list_img3 $list_img3_1}-->
				<li>
					<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" style="background-image:url({eval echo(getforumimg($list_img3_1[aid],0,230,150))});"></a>
				</li>
			<!--{/loop}-->
			</ul>
		<!--{/if}-->
	<!--{/if}-->
		<div class="list_bottom cl">
			<!--{if $thread['authorid'] && $thread['author']}-->
			<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="z">{$thread[author]}</a>
			<!--{else}-->
			<a href="javascript:;" class="z">{$_G[setting][anonymoustext]}</a>
			<!--{/if}-->
			<em class="z">&nbsp;&nbsp;&nbsp;&nbsp;{$thread[dateline]}&nbsp;&nbsp;</em>
			<span class="y">
				<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="回复数"/>{$thread[replies]}
			</span>
			<span class="y">
				<img src="{$_G['style']['styleimgdir']}/chakan.png" alt="查看数"/>{$thread[views]}&nbsp;&nbsp;
			</span>
		</div>
	</li>
<!--{/loop}-->

