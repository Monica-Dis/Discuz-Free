<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header"> 
		<a href="javascript:;" class="header_z">
			<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="菜单"/>
			<!--{if $_G[member][newpm] || $post_notice_new}-->
			<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
			<!--{/if}-->
		</a>
		<div class="header_c">
			<span class="header_font">购买记录</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="f_c byg_pay_view">
	<h3 class="flb">
		<em id="return_$_GET['handlekey']">{lang pay_view}</em>
		<span>
			<!--{if !empty($_GET['infloat'])}--><a href="javascript:;" class="flbc" onclick="hideWindow('$_GET['handlekey']')" title="{lang close}">{lang close}</a><!--{/if}-->
		</span>
	</h3>
	<div class="byg_c floatwrap">
		<table class="list" cellspacing="0" cellpadding="0">
			<thead>
				<tr>
					<td>{lang username}&nbsp;</td>
					<td>{lang time}&nbsp;</td>
					<td>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</td>
				</tr>
			</thead>
			<!--{if $loglist}-->
				<!--{loop $loglist $log}-->
					<tr>
						<td><a href="home.php?mod=space&uid=$log[uid]&do=profile">$log[username]</a>&nbsp;</td>
						<td>$log[dateline]&nbsp;</td>
						<td>{$log[$extcreditname]} {$_G[setting][extcredits][$_G[setting][creditstransextra][1]][unit]}</td>
					</tr>
				<!--{/loop}-->
			<!--{else}-->
				<tr><td colspan="3">{lang pay_nobuyers}</td></tr>
			<!--{/if}-->
		</table>
	</div>
</div>

<!--{template common/footer}-->
