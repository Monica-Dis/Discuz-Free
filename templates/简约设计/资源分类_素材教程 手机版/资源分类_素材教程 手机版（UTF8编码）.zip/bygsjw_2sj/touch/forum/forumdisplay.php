<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/forum_forumdisplay.php');}-->
<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin cl">
			<a href="javascript:;" class="header_z">
				<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="菜单"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<div class="header_c">
				<span class="header_font"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></span>
			</div>
			<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="返回"/></a>
		</div>
		<!--{template common/header_nav}-->
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--【版块信息栏-开始】-->
<div class="forumdisplay_top sidenav-brand cl">
	<div class="cl">
		<div class="forumdisplay_top_z z">
			<!--{if $_G['forum'][icon]}-->
				<img src="<!--{if preg_match("/^http(s)?:\\/\\/.+/",$_G['forum'][icon])}-->{$_G['forum'][icon]}<!--{else}-->{$_G['setting']['attachurl']}common/{$_G['forum'][icon]}<!--{/if}-->" alt="{$_G['forum'][name]}" class="z"/>
			<!--{else}-->
				<img src="{$_G['style']['styleimgdir']}/forum.png" alt="{$_G['forum'][name]}" class="z"/>
			<!--{/if}-->
			<div class="y">
				<p style="margin-top: .04rem;">{$_G['forum'][name]}</p>
				<p style="font-size: .13rem;">今日：{$_G[forum][todayposts]}&nbsp;&nbsp;/&nbsp;&nbsp;主题：{$_G[forum][threads]}</p>
			</div>
		</div>
		<div class="forumdisplay_top_y y">
			<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" onclick="favorite_forum_ajax(this.id);return false;" id="favorite_forum_{$_G[fid]}"><img src="{$_G['style']['styleimgdir']}/bai_shoucang.png" alt="收藏"/>收藏本版</a>
		</div>
		<script type="text/javascript">
			function favorite_forum_ajax(obj) {
				var forum_id = '#' + obj;
				if($_G[uid]){
					jQuery.ajax({
						url: jQuery(forum_id).attr('href') + '&inajax=1',
						type: 'POST',
						dataType: 'xml',
						success: function(s){
							popup.open(s.lastChild.firstChild.nodeValue);
							evalscript(s.lastChild.firstChild.nodeValue);
						},
						error: function(){
							window.location.href = jQuery(forum_id).attr('href');
							popup.close();
						},
					});
				}else{
					landingPrompt();
				}
			}
		</script>
	</div>
	<!--{if $moderatedby}-->
	<div class="forumdisplay_admin">{lang forum_modedby}：<span>$moderatedby</span></div>
	<!--{/if}-->
	<!--{if $_G['page'] == 1 && $_G['forum']['rules']}-->
	<div class="forumdisplay_rules">$_G['forum'][rules]</div>
	<!--{/if}-->
</div>
<!--【版块信息栏-结束】-->

<!--{if $subexists && $_G['page'] == 1}-->
<div class="sub_forum {if $_G['style']['luntan_bankuai'] == 1}byg_forum1{elseif $_G['style']['luntan_bankuai'] == 2}byg_forum2{elseif $_G['style']['luntan_bankuai'] == 3}byg_forum3{elseif $_G['style']['luntan_bankuai'] == 4}byg_forum4{else}{if $_G[forum][forumcolumns] > 3}byg_forum4{elseif $_G[forum][forumcolumns] == 3}byg_forum3{elseif $_G[forum][forumcolumns] == 2}byg_forum2{else}byg_forum1{/if}{/if}">
	<ul class="cl">
		<!--{loop $sublist $sub}-->
		<li class="cl">
		<!--{if $sub[icon]}-->
			<div class="forum_img cl">
				$sub[icon]
			</div>
		<!--{else}-->
			<a href="forum.php?mod=forumdisplay&fid={$sub['fid']}" class="forum_img cl">
				<img src="{$_G['style']['styleimgdir']}/forum.png" alt="$sub[name]" />
			</a>
		<!--{/if}-->
			<a href="forum.php?mod=forumdisplay&fid={$sub['fid']}" class="forum_name cl">
				<div class="forum_names over_one">{$sub[name]}</div>
				<div class="y">
					<span class="forum_threads over_one">
						<img src="{$_G['style']['styleimgdir']}/forum_threads.png" alt="主题数"/>{$sub[threads]}
					</span>
					<span class="forum_posts over_one">
						<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="帖子数"/>{$sub[posts]}
					</span>
				</div>
			</a>
		</li>
		<!--{/loop}-->
	</ul>
</div>
<!--{/if}-->

<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
<div style="position: relative;">
	<div class="byg_thread_types">
		<ul id="thread_types" class="swiper-wrapper">
			<li id="ttp_all" class="swiper-slide{if !$_GET['typeid'] && !$_GET['sortid']} a{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a></li>
			<!--{if $_G['forum']['threadtypes']}-->
				<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
					<!--{if $_GET['typeid'] == $id}-->
					<li class="swiper-slide a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img src="$_G[forum][threadtypes][icons][$id]" alt="{$name}" /> <!--{/if}-->{$name}<!--{if $showthreadclasscount[typeid][$id]}--><span class="num">({$showthreadclasscount[typeid][$id]})</span><!--{/if}--></a></li>
					<!--{else}-->
					<li class="swiper-slide"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img src="$_G[forum][threadtypes][icons][$id]" alt="{$name}" /> <!--{/if}-->{$name}<!--{if $showthreadclasscount[typeid][$id]}--><span class="num">({$showthreadclasscount[typeid][$id]})</span><!--{/if}--></a></li>
					<!--{/if}-->
				<!--{/loop}-->
			<!--{/if}-->
			<!--{if $_G['forum']['threadsorts']}-->
				<!--{if $_G['forum']['threadtypes']}-->
					<li class="swiper-slide"><span class="pipe">|</span></li>
				<!--{/if}-->
				<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
					<!--{if $_GET['sortid'] == $id}-->
					<li class="swiper-slide a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="num">({$showthreadclasscount[sortid][$id]})</span><!--{/if}--></a></li>
					<!--{else}-->
					<li class="swiper-slide"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="num">({$showthreadclasscount[sortid][$id]})</span><!--{/if}--></a></li>
					<!--{/if}-->
				<!--{/loop}-->
			<!--{/if}-->
		</ul>
	</div>
	<!--{if $quicksearchlist && !$_GET['archiveid']}-->
		<!--{subtemplate forum/search_sortoption}-->
	<!--{/if}-->
	<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
	<script type="text/javascript">
		if(jQuery(".byg_thread_types .a").length > 0) {
			var tab_initial = jQuery(".byg_thread_types .a").offset().left + jQuery(".byg_thread_types .a").width() + 20 >= jQuery(window).width() ? jQuery(".byg_thread_types .a").index() : 0;
		}else{
			var tab_initial = 0;
		}
		var byg_thread_types = new Swiper('.byg_thread_types', {
			initialSlide : tab_initial,
			slidesPerView : 'auto',
			freeMode : true,
		});
	</script>
</div>
<!--{/if}-->

<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->

<!--{if $forum_list_gg}-->
<div class="byg_gg">{$forum_list_gg}</div>
<!--{/if}-->

<!--{if !$subforumonly}-->
<div class="threadlist byg_threadlist">
	<!--{if empty($_G['forum']['sortmode']) || $_G['style']['luntan_fenlei'] != "on"}-->
		<!--{if $_G['style']['gonggao'] == 'on'}-->
			<!--{if $forum_an}-->
			<div class="byg_an">
				<img src="{$_G['style']['styleimgdir']}/an.gif" alt="{lang announcement}" class="byg_an_i byg_an_i1"/>
				<!--{loop $forum_an $f_a}-->
					<!--{if $f_a[type] == 0}-->
					<span class="an_li"><a href="forum.php?mod=announcement&id={$f_a[id]}" class="an_li_m">{$f_a[subject]}</a></span>
					<!--{else}-->
					<span class="an_li"><a href="{$f_a[message]}">{$f_a[subject]}</a></span>
					<!--{/if}-->
				<!--{/loop}-->
			</div>
			<!--{/if}-->
		<!--{/if}-->
		<ul class="byg_threadlist_ul">
			<!--{if $_G['forum_threadcount']}-->
				<!--{subtemplate forum/forumdisplay_list}-->
			<!--{else}-->
				<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
				<li style="padding:.1rem;color:#888;text-align:center;">{lang forum_nothreads}</li>
				<!--{else}-->
				<style type="text/css">
					ul.byg_threadlist_ul{ margin: 0; height: auto !important;}
					ul.byg_threadlist_ul li{ top: 0 !important; left: 0 !important; width: 3.55rem !important;}
				</style>
				<li style="padding:.1rem;color:#888;text-align:center;">{lang forum_nothreads}</li>
				<!--{/if}-->
			<!--{/if}-->
		</ul>
		<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
			<!--{if $_G['style']['luntan_liebiaotu'] == 'on'}-->
			<style type="text/css">
				.list_img1_box .list_top{ float: left; width: 2.32rem; height: .44rem; margin-bottom: .06rem; padding-right: 0; overflow: hidden;}
				.list_img1_box .list_img1{ float: right; width: 1.15rem; padding: .1rem .1rem .1rem 0;}
				.list_img1_box .list_img1 a{ width: 100%; height: .76rem; padding: 0; border-radius: .04rem; overflow: hidden; display: block; background-position: center center; background-repeat: no-repeat; background-size: cover; -webkit-background-size: cover;}
				.list_img1_box .list_bottom{ float: left; width: 2.28rem; margin-right: 0;}
			</style>
			<!--{/if}-->
		<!--{else}-->
			<style type="text/css">
				.byg_threadlist{ background: #fff;}
				.byg_threadlist .byg_an{ border-bottom: 1px solid #f1f1f1;}
				.byg_threadlist_ul{ position:relative; margin: .12rem 0 0 .12rem}
				.byg_threadlist_ul .byg_threadlist_pic_li{ position: absolute; left: 0; top: 0; width: 1.68rem !important; margin: 0; padding: 0 .12rem .12rem 0; font-size: .16rem; border: 0;}
				.byg_threadlist_ul .byg_threadlist_pic{ width: 1.69rem; background: #f9f9f9; box-shadow: 0 0 0 1px #eee; border-radius: .04rem;}
				.byg_threadlist_ul .byg_pic_img a{ padding: .05rem .05rem 0; font-size: .16rem;}
				.byg_threadlist_ul .byg_pic_img img{ vertical-align: middle; width: 100%;}
				.byg_threadlist_ul .byg_pic_tit a{ margin: .05rem; padding: 0; font-size: .16rem; line-height: .22rem;}
				.byg_threadlist_ul .byg_pic_auth{ padding: .05rem; border-top: 1px solid #eee; font-size: .12rem; color: #999;}
				.byg_threadlist_ul .byg_pic_auth a{ display: inline-block; padding: 0; line-height: normal; font-size: .12rem; color: #888;}
				.byg_threadlist .load_more_button{ border-top: 1px solid #f1f1f1;}
			</style>
			<script src="{$_G['style']['styleimgdir']}/forumdisplay_pic.js" type="text/javascript"></script>
			<script type="text/javascript">
				jQuery(".byg_threadlist_ul").pinterest_grid();
			</script>
		<!--{/if}-->
	<!--{else}-->
		<div class="byg_sorttemplate_box">
			<div class="byg_sorttemplate cl">
				{$sorttemplate['body']}
			</div>
		</div>
	<!--{/if}-->
	<!--{if $_G['forum_threadcount']}-->
		<div style="{if $_G['style']['fanye'] != 'on'}display: none;{/if}">$multipage</div>
		<!--{if $_G['style']['fanye'] != 'on'}-->
		<div class="load_more_button">
			<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="等待"/>数据加载中，请稍后...</a>
		</div>
		<script type="text/javascript">
			var ajax_state = true;
			var ajax_page = <!--{if $_GET[page]}-->$_GET[page]<!--{else}-->1<!--{/if}--> + 1;
			var all_page = jQuery('div.pg label span').text().replace(/[^\d]/g, '') || 0;
			var ajax_url = 'forum.php?mod=forumdisplay&fid=' + '$_GET[fid]'<!--{if $_GET[filter]}--> + '&filter=' + '$_GET[filter]'<!--{/if}--><!--{if $_GET[digest]}--> + '&digest=' + '$_GET[digest]'<!--{/if}--><!--{if $_GET[sortid]}--> + '&sortid=' + '$_GET[sortid]'<!--{/if}--><!--{if $_GET[typeid]}--> + '&typeid=' + '$_GET[typeid]'<!--{/if}--><!--{if $_GET[orderby]}--> + '&orderby=' + '$_GET[orderby]'<!--{/if}--><!--{if $_GET[specialtype]}--> + '&specialtype=' + '$_GET[specialtype]'<!--{/if}--><!--{if $_GET[dateline]}--> + '&dateline=' + '$_GET[dateline]'<!--{/if}--><!--{if $_GET[sortall]}--> + '&sortall=' + '$_GET[sortall]'<!--{/if}-->;

			function list_ajax() {
				if(ajax_state == true) {
					if(all_page >= 2 && all_page >= ajax_page) {
						ajax_state = false;
						jQuery(".load_more_button").html('<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="等待"/>数据加载中，请稍后...</a>');
						jQuery.ajax({
							url: ajax_url + '&page=' + ajax_page + '&mobile=2',
							type: 'GET',
							dataType: 'html',
							success: function(result) {
							<!--{if empty($_G['forum']['sortmode']) || $_G['style']['luntan_fenlei'] != "on"}-->
								jQuery(".byg_threadlist_ul").append(jQuery(result).find(".byg_threadlist_ul").html());
							<!--{else}-->
								jQuery(".byg_sorttemplate").append(jQuery(result).find(".byg_sorttemplate").html());
							<!--{/if}-->
								ajax_page++;
								ajax_state = true;
							}
						});
					} else {
						jQuery(".load_more_button").html('<a href="forum.php?forumlist=1" title="论坛">已经到底了，进入论坛发现更多</a>');
						ajax_state = false;
					}
				}
			}

			if(jQuery(document).height() <= jQuery(window).height()) {
				list_ajax();
			}

			jQuery(window).scroll(function() {
				if(jQuery(document).height() <= jQuery(window).height() + jQuery(window).scrollTop() + 1000) {
					list_ajax();
				}
			});
		</script>
		<!--{/if}-->
	<!--{/if}-->
</div>
<!--{/if}-->
<!-- main threadlist end -->
<!--{hook/forumdisplay_bottom_mobile}-->

<!--{template common/footer}-->

