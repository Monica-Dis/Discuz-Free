<?php echo 'From: DisM.taobao.com';exit;?>

<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{if !$_GET['gid']}-->
		<!--{eval dheader('Location:portal.php?mod=index&mobile=2');exit;}-->
	<!--{/if}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/forum_discuz.php');}-->

<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<!--{if $_GET['visitclient']}-->

<header class="header">
	<div class="nav"> <span>{lang warmtip}</span> </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}
			<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" />
		</p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}
			<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" />
		</p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		jQuery('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script> 

<!--{else}--> 

<!--{if $showvisitclient}-->
<div class="visitclienttip vm" style="display:block;"> <a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>
	<p> {lang downloadzslttoshareview} </p>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		jQuery('#visitclientid').attr('href', visitclienthref);
		jQuery('.visitclienttip').css('display', 'block');
	}
</script> 
<!--{/if}-->

<!-- header start --> 
<header class="header_xin" style="margin-bottom: .1rem;">
	<div id="byg_header">
		<div class="hdc_xin cl">
			<a href="javascript:;" class="header_z">
				<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="菜单"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
				<!--{/if}-->
			</a>
			<h2 class="header_c">
				<a href="./" title="$_G[setting][bbname]">
					<!--{if $bygsjw_logo}-->
					{$bygsjw_logo}
					<!--{else}-->
					<img src="{$_G['style']['boardimg']}" alt="LOGO"/>
					<!--{/if}-->
				</a>
			</h2>
			<a href="search.php?mod=forum" title="站内搜索" class="header_y"><img src="{$_G['style']['styleimgdir']}/tou_sousuo.png" alt="搜索"/></a>
		</div>
		<!--{template common/header_nav}-->
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--{hook/index_top_mobile}-->

<!--【论坛首页轮播广告】-->
<!--{if $forum_gg1 || $forum_gg2 || $forum_gg3}-->
<div data-byginto class="forum_gg">
	<div class="forum_gg_sl_bd">
		<ul class="swiper-wrapper">
		<!--{if $forum_gg1}-->
			<li class="swiper-slide">{$forum_gg1}</li>
		<!--{/if}-->
		<!--{if $forum_gg2}-->
			<li class="swiper-slide">{$forum_gg2}</li>
		<!--{/if}-->
		<!--{if $forum_gg3}-->
			<li class="swiper-slide">{$forum_gg3}</li>
		<!--{/if}-->
		</ul>
	</div>
</div>
<!--{/if}-->

<!--【公告】-->
<!--{if $_G['style']['gonggao'] == 'on'}-->
	<!--{if $forum_an}-->
	<div data-byginto class="byg_an">
		<img src="{$_G['style']['styleimgdir']}/an.gif" alt="{lang announcement}" class="byg_an_i byg_an_i1"/>
		<!--{loop $forum_an $f_a}-->
			<!--{if $f_a[type] == 0}-->
			<span class="an_li"><a href="forum.php?mod=announcement&id={$f_a[id]}" class="an_li_m">{$f_a[subject]}</a></span>
			<!--{else}-->
			<span class="an_li"><a href="{$f_a[message]}">{$f_a[subject]}</a></span>
			<!--{/if}-->
		<!--{/loop}-->
	</div>
	<!--{/if}-->
<!--{/if}-->

<!--【论坛统计】-->
<!--{if $_G['style']['luntan_tongji'] == 'on'}-->
<div data-byginto class="byg_tongji">
	<ul class="cl">
		<li>
			<div>
				<img src="{$_G['style']['styleimgdir']}/tongji_today.png" alt="{lang index_today}"/>
				<span>
					<p>{lang index_today}</p>
					<p>{$todayposts}</p>
				</span>
			</div>
		</li>
		<li>
			<div>
				<img src="{$_G['style']['styleimgdir']}/tongji_posts.png" alt="{lang index_posts}"/>
				<span>
					<p>{lang index_posts}</p>
					<p>{$posts}</p>
				</span>
			</div>
		</li>
		<li style="border:0;">
			<div>
				<img src="{$_G['style']['styleimgdir']}/tongji_members.png" alt="{lang index_members}"/>
				<span>
					<p>{lang index_members}</p>
					<p>{$_G['cache']['userstats']['totalmembers']}</p>
				</span>
			</div>
		</li>
	</ul>
</div>
<!--{/if}-->

<!-- main forumlist start -->
<div class="wp wm_xin" id="wp">
	<!--{loop $catlist $key $cat}-->
	<div data-byginto class="bm bmw fl">
		<div href="#sub_forum_$cat[fid]" class="subforumshow bm_xin cl">
			<img src="{$_G['style']['styleimgdir']}/<!--{if !$_G[setting][mobile][mobileforumview]}-->forum_guan<!--{else}-->forum_kai<!--{/if}-->.png" alt="开关"/>
			<h2><a href="javascript:;">$cat[name]</a></h2>
		</div>
		<div id="sub_forum_$cat[fid]" class="sub_forum {if $_G['style']['luntan_bankuai'] == 1}byg_forum1{elseif $_G['style']['luntan_bankuai'] == 2}byg_forum2{elseif $_G['style']['luntan_bankuai'] == 3}byg_forum3{elseif $_G['style']['luntan_bankuai'] == 4}byg_forum4{else}{if $cat['forumcolumns'] > 3}byg_forum4{elseif $cat['forumcolumns'] == 3}byg_forum3{elseif $cat['forumcolumns'] == 2}byg_forum2{else}byg_forum1{/if}{/if}">
			<ul class="cl">
				<!--{loop $cat[forums] $forumid}--> 
				<!--{eval $forum=$forumlist[$forumid];}-->
				<li class="cl">
				<!--{if $forum[icon]}-->
					<div class="forum_img cl">
						$forum[icon]
					</div>
				<!--{else}-->
					<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="forum_img cl">
						<img src="{$_G['style']['styleimgdir']}/forum.png" alt="$forum[name]"/>
					</a>
				<!--{/if}-->
					<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="forum_name cl">
						<div class="forum_names over_one">{$forum[name]}<!--{if $forum[todayposts] && !$forum['redirect']}--><em>($forum[todayposts])</em><!--{/if}--></div>
						<div class="y">
							<span class="forum_threads over_one">
								<img src="{$_G['style']['styleimgdir']}/forum_threads.png" alt="主题数"/><!--{echo dnumber($forum[threads])}-->
							</span>
							<span class="forum_posts over_one">
								<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="帖子数"/><!--{echo dnumber($forum[posts])}-->
							</span>
						</div>
					</a>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{/loop}--> 
</div>
<!-- main forumlist end --> 

<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			jQuery('.sub_forum').css('display', 'block');
		<!--{else}-->
			jQuery('.sub_forum').css('display', 'none');
		<!--{/if}-->
		jQuery('.subforumshow').on('click', function() {
			var obj = jQuery(this);
			var subobj = jQuery(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
				obj.find('img').attr('src', '{$_G['style']['styleimgdir']}/forum_guan.png');
			} else {
				subobj.css('display', 'none');
				obj.find('img').attr('src', '{$_G['style']['styleimgdir']}/forum_kai.png');
			}
		});
	 })();
</script>
<!--{hook/index_middle_mobile}-->

<!--{/if}-->
<!--{template common/footer}--> 

