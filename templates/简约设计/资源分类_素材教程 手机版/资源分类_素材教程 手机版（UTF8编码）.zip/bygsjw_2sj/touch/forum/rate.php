<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!--{if empty($_GET['showratetip'])}-->
<style>
	.bygsjw_rate{ width: 3.35rem; background: #fff; border-radius: .1rem;}
	.bygsjw_rate h3{ padding: .1rem 0; font-size: .18rem; text-align: center; background: $_G['style']['zhuti']; color: #fff; border-radius: .1rem .1rem 0 0; display: block;}
	.bygsjw_rate form{ padding: .15rem;}
	.bygsjw_rate table{ table-layout: fixed; width: 100%; border: 1px solid #eee; border-color: #eee;}
	.bygsjw_rate th{ padding: .08rem 0; background: #fafafa; line-height: .2rem; text-align: center;}
	.bygsjw_rate td{ padding: .08rem .05rem; font-size: .15rem; line-height: .2rem; text-align: center;}
	.bygsjw_rate .px{ border: .01rem solid #eee; padding: .02rem .04rem; font-size: .14rem;}
	.bygsjw_rate_c{ max-height: 3rem; overflow-x: hidden; overflow-y: auto;}
	.bygsjw_rate_b{ margin-top: .12rem; line-height: .25rem;}
	.bygsjw_rate_b label{ font-size: .14rem;}
	.bygsjw_rate_b button{ float: right; padding: .02rem .1rem;}
	.bygsjw_rate_b .xg1{ margin-right: .1rem; font-size: .13rem;}
</style>

	<!--{if $_GET[action] == 'rate'}-->
	<div class="bygsjw_rate">
		<h3>
			<em>打赏评分，给作者增加点动力吧</em>
		</h3>
		<form id="rateform" method="post" autocomplete="off" action="forum.php?mod=misc&action=rate&ratesubmit=yes&infloat=yes">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="tid" value="$_G[tid]" />
			<input type="hidden" name="pid" value="$_GET[pid]" />
			<input type="hidden" name="referer" value="$referer" />
			<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="rate"><!--{/if}-->
			<div class="bygsjw_rate_c">
				<table cellspacing="0" cellpadding="0" border="1">
					<tr>
						<th>&nbsp;</th>
						<th>{lang rate_raterange}</th>
						<th>{lang rate_todayleft}</th>
					</tr>
					<!--{eval $rateselfflag = 0;}-->
					<!--{loop $ratelist $id $options}-->
						<tr>
							<td>{$_G['setting']['extcredits'][$id][title]}&nbsp;<input type="text" name="score$id" id="score$id" class="px" placeholder="0" value="" style="width: .3rem;" /></td>
							<td>{$_G['group']['raterange'][$id]['min']} ~ {$_G['group']['raterange'][$id]['max']}</td>
							<!--{eval $rateselfflag = $_G['group']['raterange'][$id][isself] ? 1 : $rateselfflag;}-->
							<td>$maxratetoday[$id]</td>
						</tr>
					<!--{/loop}-->
				</table>

				<div style="margin-top: .12rem;">
					<input type="text" name="reason" id="reason" class="px" placeholder="{lang user_operation_explain}" style="width: 2.95rem; padding: .05rem .04rem;" />
				</div>
			</div>
			<div class="bygsjw_rate_b cl">
				<label for="sendreasonpm"><input type="checkbox" name="sendreasonpm" id="sendreasonpm" class="pc"{if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />{lang admin_pm}</label>
				<button name="ratesubmit" type="submit" value="true" class="formdialog y"><span>{lang confirms}</span></button>
				<!--{if $rateselfflag}-->
				<span class="xg1 y">({lang admin_rate})</span>
				<!--{/if}-->
			</div>
		</form>
	</div>

	<!--{elseif $_GET[action] == 'removerate'}-->

	<div class="bygsjw_rate">
		<h3>
			<em>{lang thread_removerate}</em>
		</h3>
		<form id="rateform" method="post" autocomplete="off" action="forum.php?mod=misc&action=removerate&ratesubmit=yes&infloat=yes">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="tid" value="$_G[tid]">
			<input type="hidden" name="pid" value="$_GET[pid]">
			<input type="hidden" name="referer" value="$referer" />
			<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="rate"><!--{/if}-->
			<div class="bygsjw_rate_c">
				<table class="list" cellspacing="0" cellpadding="0" border="1">
					<tr>
						<th>&nbsp;</th>
						<th>{lang username}</th>
						<th>{lang time}</th>
						<th>{lang credits}</th>
						<th>{lang reason}</th>
					</tr>
				<!--{loop $ratelogs $ratelog}-->
					<tr>
						<td><input type="checkbox" name="logidarray[]" value="$ratelog[uid] $ratelog[extcredits] $ratelog[dbdateline]" /></td>
						<td><a href="home.php?mod=space&uid=$ratelog[uid]">$ratelog[username]</a></td>
						<td>$ratelog[dateline]</td>
						<td>{$_G['setting']['extcredits'][$ratelog[extcredits]][title]} <span class="xw1">$ratelog[scoreview]</span> {$_G['setting']['extcredits'][$ratelog[extcredits]][unit]}</td>
						<td>$ratelog[reason]</td>
					</tr>
				<!--{/loop}-->
				</table>
			</div>
			<div class="bygsjw_rate_b cl">
				<label for="sendreasonpm"><input type="checkbox" name="sendreasonpm" id="sendreasonpm" class="pc"{if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />{lang admin_pm}</label>
				<button class="formdialog y" type="submit" value="true" name="ratesubmit"><span>{lang submit}</span></button>
				<span class="xg1 y">{lang admin_operation_explain}: <input name="reason" class="px" style="width: .6rem;" /></span>
			</div>
		</form>
	</div>
	<!--{/if}-->
<!--{/if}-->

<!--{template common/footer}-->
