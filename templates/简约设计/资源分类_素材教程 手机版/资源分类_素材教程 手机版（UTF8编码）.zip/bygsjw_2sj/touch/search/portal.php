<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header"> 
		<a href="javascript:;" class="header_z">
			<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="菜单"/>
			<!--{if $_G[member][newpm] || $post_notice_new}-->
			<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
			<!--{/if}-->
		</a>
		<div class="header_c">
			<span class="header_font">门户搜索</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->


<form class="searchform" method="post" autocomplete="off" action="search.php?mod=portal">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<!--{subtemplate search/pubsearch}-->
</form>

<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
<!--{subtemplate search/portal_list}-->
<!--{/if}-->
<!--{template common/footer}-->
