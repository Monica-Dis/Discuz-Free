<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header"> 
		<a href="javascript:;" class="header_z">
			<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="菜单"/>
			<!--{if $_G[member][newpm] || $post_notice_new}-->
			<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
			<!--{/if}-->
		</a>
		<div class="header_c">
			<span class="header_font">帖子提醒</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--{if empty($list)}-->
<div class="home_no_data">{lang no_notice}</div>
<!--{/if}-->
<!--{if $list}-->
<div class="post_notice_list">
	<ul>
		<!--{loop $list $key $value}-->
		<li class="cl">
			<div class="post_notice_list_z">
				<!--{if $value[authorid]}-->
				<a href="home.php?mod=space&uid={$value[authorid]}&do=profile"><!--{avatar($value[authorid],middle)}--></a>
				<!--{else}-->
				<img src="{$_G['style']['styleimgdir']}/middle.gif" alt="头像"/>
				<!--{/if}-->
			</div>
			<div class="post_notice_list_yt" style="$value[style]">
				<!--{if $value[authorid] && $value[author]}-->
				<a href="home.php?mod=space&uid={$value[authorid]}&do=profile">{$value[author]}</a>
				<i>（<!--{date($value[dateline], 'u')}-->）</i><span>{$value[note]}</span>
				<!--{else}-->
				<i>（<!--{date($value[dateline], 'u')}-->）</i>{$value[note]}
				<!--{/if}-->
			</div>
			<!--{if $value[from_num]}-->
			<div class="post_notice_list_yb">{lang ignore_same_notice_message}</div>
			<!--{/if}-->
		</li>
		<!--{/loop}-->
	</ul>
</div>
<!--{if $multi}--><div class="pgs cl">$multi</div><!--{/if}-->
<!--{/if}-->

<!--{template common/footer}-->
