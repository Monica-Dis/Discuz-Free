<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header"> 
		<a href="javascript:;" class="header_z">
			<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="菜单"/>
			<!--{if $_G[member][newpm] || $post_notice_new}-->
			<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
			<!--{/if}-->
		</a>
		<div class="header_c">
			<span class="header_font">我的收藏</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="forumdisplay_tab">
	<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread" {if $_GET['type'] == 'thread'}class="on"{/if}><h2>帖子</h2></a>
	<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=forum" {if $_GET['type'] == 'forum'}class="on"{/if}><h2>版块</h2></a>
	<!--{if helper_access::check_module('portal')}--><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=article" {if $_GET['type'] == 'article'}class="on"{/if}><h2>文章</h2></a><!--{/if}-->
</div>

<!-- main collectlist start -->
<style>
	.threadlist li{ padding: .12rem .1rem;}
	.threadlist li .z{ width: 3.05rem; padding: 0;}
	.threadlist li .z p{ margin-top: .02rem; line-height: .18rem; font-size: .13rem; color: #999;}
	.threadlist li .y{ float: right; width: .4rem; padding: 0; background: #aaa; color: #fff; border: 0; border-radius: .04rem; cursor: pointer; -webkit-appearance: none; font-size: .12rem; text-align: center;}
</style>
<div class="threadlist">
	<!--{if $list}-->
	<ul>
		<!--{loop $list $k $value}-->
		<li class="cl">
			<a href="{$value[url]}" class="z">
				<!--{if $_GET['type'] == 'all'}--><span>{$value[icon]}</span><!--{/if}-->
				{$value[title]}
				<p><!--{date($value[dateline], 'u')}--><!--{if $value[description]}-->&nbsp;&nbsp;&nbsp;"{$value[description]}"<!--{/if}--></p>
			</a>
			<a href="home.php?mod=spacecp&ac=favorite&op=delete&favid={$k}&type={$_GET[type]}" onclick="favorite_delete_ajax(this.id);return false;" class="y" id="a_delete_{$k}">{lang delete}</a>
		</li>
		<!--{/loop}-->
	</ul>
	<!--{else}-->
	<div class="home_no_data">{lang no_favorite_yet}</div>
	<!--{/if}-->
</div>
<script type="text/javascript">
	function favorite_delete_ajax(obj) {
		var delete_id = '#' + obj;
		jQuery.ajax({
			url: jQuery(delete_id).attr('href') + '&inajax=1',
			type: 'POST',
			dataType: 'xml',
			success: function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
				evalscript(s.lastChild.firstChild.nodeValue);
			},
			error: function() {
				window.location.href = jQuery(delete_id).attr('href');
				popup.close();
			},
		});
	}
</script>
<!-- main collectlist end -->
$multi

<!--{template common/footer}-->

