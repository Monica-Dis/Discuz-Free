<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header"> 
		<a href="javascript:;" class="header_z">
			<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="菜单"/>
			<!--{if $_G[member][newpm] || $post_notice_new}-->
			<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="提醒" class="new_pm"/>
			<!--{/if}-->
		</a>
		<div class="header_c">
			<!--{if $_GET['op'] == 'base'}-->
			<span class="header_font">我的积分</span>
			<!--{elseif $_GET['op'] == 'buy'}-->
			<span class="header_font">充值</span>
			<!--{/if}-->
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="返回上一页" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="返回"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<style>
	table{ width: 100%;}
	.creditl{ margin-bottom: .1rem; padding: .1rem; background: #fff; font-size: .16rem;}
	.creditl li{ margin: .06rem 0;}
	.creditl em{ font-weight: 700;}
	.creditl .xi2{ color: #06f;}
	.creditl .xg1{ vertical-align: top;}
	.creditl u{ text-decoration: none;}
	.byg_base_b{ background: #fff;}
	.byg_base_b caption{ padding: .08rem .1rem; border-bottom: 1px solid #eee;}
	.byg_base_b caption h2{ font-weight: 700;}
	.byg_base_b td, .byg_base_b th{ padding: .06rem .1rem; border-bottom: 1px solid #eee; border-right: 1px solid #eee; font-size: .14rem;}
	.byg_base_b th{ background: #fafafa; font-size: .15rem;}
	.byg_buy{ padding: 0 .1rem; background: #fff; font-size: .16rem;}
	.byg_buy tr{ line-height: .46rem; border-bottom: 1px dashed #eaeaea;}
	.byg_buy th{ width: 25%;}
	.byg_buy .px{ padding: .02rem .04rem; line-height: .18rem; border: 1px solid #eee; font-size: .14rem;}
	.byg_buy .sec_code{ padding: .1rem 0; border-bottom: 1px dashed #eaeaea;}
	.byg_buy .sec_code .px{ vertical-align: top;}
	.byg_buy .sec_code img{ float: left; margin-right: .1rem; height: .23rem; vertical-align: top;}
	.byg_buy button{ margin: .12rem 0; width: 100%; line-height: .36rem; font-size: .15rem;}
	.byg_buy a{ display: block; margin-bottom: .12rem; line-height: .34rem; border: 1px solid #eaeaea; background: #fafafa; font-size: .15rem; color: #06f; text-align: center; border-radius: .02rem;}
</style>

<!--{if in_array($_GET['op'], array('base', 'buy'))}-->
	<ul class="creditl cl">
	<!--{eval $creditid=0;}-->
	<!--{if $_GET['op'] == 'base' && $_G['setting']['creditstrans']}-->
		<!--{eval $creditid=$_G['setting']['creditstrans'];}-->
		<!--{if $_G['setting']['extcredits'][$creditid]}-->
		<!--{eval $credit=$_G['setting']['extcredits'][$creditid]; }-->
		<li class="xi1 cl"><em>{$credit[title]}&nbsp;: </em><!--{echo getuserprofile('extcredits'.$creditid);}--> {$credit[unit]} &nbsp; <!--{if $_G['setting']['card']['open']}--><a href="home.php?mod=spacecp&ac=credit&op=buy" class="xi2">{lang card_use}&raquo;</a><!--{/if}--></li>
		<!--{/if}-->
	<!--{/if}-->
	<!--{loop $_G['setting']['extcredits'] $id $credit}-->
		<!--{if $id!=$creditid}-->
		<li><em>{$credit[title]}&nbsp;: </em><!--{echo getuserprofile('extcredits'.$id);}--> {$credit[unit]}</li>
		<!--{/if}-->
	<!--{/loop}-->
	<!--{if  $_GET['op'] == 'base'}-->
		<li class="cl"><em>{lang credits}&nbsp;: </em>$_G['member']['credits'] <span class="xg1">( $creditsformulaexp )</span></li>
	<!--{/if}-->
	</ul>
<!--{/if}-->

<!--{if $_GET['op'] == 'base'}-->
	<div class="byg_base_b">
		<table summary="{lang memcp_credits_log_transaction}" cellspacing="0" cellpadding="0" class="">
			<caption>
				<h2 class="xs2">
					近期记录
				</h2>
			</caption>
			<tr>
				<th width="70">{lang operation}</th>
				<th width="70">{lang logs_credit}</th>
				<th>{lang detail}</th>
				<th width="70">{lang changedateline}</th>
			</tr>
		<!--{if $loglist}-->
			<!--{loop $loglist $value}-->
			<!--{eval $value = makecreditlog($value, $otherinfo);}-->
			<tr>
				<td><!--{if $value['operation']}--><a href="home.php?mod=spacecp&ac=credit&op=log&optype=$value['operation']">$value['optype']</a><!--{else}-->$value['title']<!--{/if}--></td>
				<td>$value['credit']</td>
				<td><!--{if $value['operation']}-->$value['opinfo']<!--{else}-->$value['text']<!--{/if}--></td>
				<td>$value['dateline']</td>
			</tr>
			<!--{/loop}-->
		<!--{else}-->
			<tr><td colspan="4"><p class="emp">{lang memcp_credits_log_none}</p></td></tr>
		<!--{/if}-->
		</table>
	</div>

<!--{elseif $_GET['op'] == 'buy'}-->

	<!--{if ($_G[setting][ec_ratio] && ($_G[setting][ec_account] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_tenpay_bargainor])) || $_G[setting][card][open]}-->
	<div class="byg_buy cl">
		<form id="addfundsform" name="addfundsform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=buy">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="addfundssubmit" value="true" />
			<input type="hidden" name="handlekey" value="buycredit" />
			<table cellspacing="0" cellpadding="0" class="tfm">
				<tr>
					<th>{lang mode_of_payment}&nbsp;:</th>
					<td colspan="2">
						<div class="long-logo">
							<ul>
							<!--{if $_G[setting][card][open]}-->
								<li>
									<input name="bank_type" type="radio" value="card" checked="checked" id="apitype_card" class="vm" $ecchecked /><label><span class="xs2">{lang card_credit}</span></label>
								</li>
							<!--{/if}-->
							</ul>
						</div>
					</td>
				</tr>
				<!--{if $_G[setting][card][open]}-->
					<tr id="cardbox">
						<th>{lang card}&nbsp;:</th>
						<td colspan="2">
							<input type="text" class="px" id="cardid" name="cardid" />
						</td>
					</tr>
					<!--{if $seccodecheck}-->
						</table>
						<!--{block sectpl}--><table id="card_box_sec" cellspacing="0" cellpadding="0" class="tfm mtn"><tr><th><sec></th><td colspan="2"><span id="sec<hash>" onclick="showMenu({'ctrlid':this.id,'win':'{$_GET[handlekey]}'})"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div></td></tr></table><!--{/block}-->
						<!--{subtemplate common/seccheck}-->
						<table cellspacing="0" cellpadding="0" class="tfm">
					<!--{/if}-->
				<!--{/if}-->
				<tr style="border: 0;">
					<td colspan="3">
						<button type="submit" name="addfundssubmit_btn" class="pn" id="addfundssubmit_btn" value="true"><em>{lang memcp_credits_addfunds}</em></button>
					</td>
				</tr>
			</table>
		</form>
		<!--{eval $buy_card_p = byg_diy_block_param('资源分类手机版购买充值卡密');}-->
		<!--{if $buy_card_p}-->
		<!--{eval $buy_card = unserialize($buy_card_p);}-->
		<a href="{$buy_card['url']}" target="_blank">{$buy_card['text']}</a>
		<!--{/if}-->
	</div>
	<!--{/if}-->

<!--{/if}-->

<!--{template common/footer}-->
