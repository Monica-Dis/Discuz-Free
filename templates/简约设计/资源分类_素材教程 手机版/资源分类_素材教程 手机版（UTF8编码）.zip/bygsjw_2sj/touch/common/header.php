<?php echo 'Discuz';exit;?>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<!--{if CURSCRIPT == 'portal' && CURMODULE == 'list'}--><base href="{$_G[siteurl]}" /><!--{/if}-->

<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by Discuz!</title>
<link rel="stylesheet" href="{STATICURL}image/mobile/style.css" type="text/css" media="all">

<!--{if CURSCRIPT != 'plugin'}-->
<script src="{$_G['style']['styleimgdir']}/flexible.js"></script>
<link rel="stylesheet" href="{$_G['style']['styleimgdir']}/style.css" type="text/css">
<link rel="stylesheet" href="{$_G['style']['styleimgdir']}/iconfont/iconfont.css" type="text/css">
<style type="text/css">
/* common */
	.landingPrompt a, #cform .area button, .sort_search_but button, .bg_xin #date-wrapper h3, #date-wrapper #d-confirm, .post_nav_b .post_on, .pmbox li .num{ background: $_G['style']['zhuti'];}

	.button, .button2, .btn_pn, .btn_login .pn, .btn_login .pn:hover, .btn_register .pn, .btn_register .pn:hover, .btn_exit a, .btn_exit a:hover{ background: $_G['style']['zhuti']; color: #fff; border-radius: .02rem;}

	input[type=button], input[type=submit], input[type=file], button{ background: $_G['style']['zhuti']; color: #fff; border: 0; border-radius: .02rem; cursor: pointer; -webkit-appearance: none; font-size: .14rem;}
	input, textarea, select{ outline-color: $_G['style']['zhuti']; max-width: 100%;}

	.lanjiazai_bg, .sj_portal_slide .sj_slide_bd li{ background: #fff url({$_G['style']['styleimgdir']}/lanjiazai.gif) no-repeat center center;}

	.portal_font_nav .on, .portal_cat_top .on, .discuz_font_nav .on, .forumdisplay_tab .on, .newthread_type_tab .a{ color: $_G['style']['zhuti'];}
	.portal_font_nav .on:after, .portal_cat_top .on:after, .discuz_font_nav .on:after, .forumdisplay_tab .on:after, .newthread_type_tab .a:after{ content: "."; position: absolute; top: .26rem; left: 50%; display: block; width: .16rem; height: .04rem; margin-left: -.08rem; line-height: 999em; background: $_G['style']['zhuti']; color: #fff; border-radius: .02rem;}

	.portal_cat_sub .on, .byg_thread_types .a a, .byg_sort_font .a a{ border-color: $_G['style']['zhuti']; color: $_G['style']['zhuti'];}

	.portal_content_c .pcc_title h3:after, .portal_content_b .pcb_title h3:after, .bm_xin h2:after, .postlist_title h3:after{ content: "."; position: absolute; top: .1rem; left: .01rem; display: block; width: .04rem; height: .16rem; line-height: .1rem; background: $_G['style']['zhuti']; color: $_G['style']['zhuti']; border-radius: 2px;}

/* portal */
	.sj_portal_slide .sj_slide_hd .swiper-pagination-bullet-active{ width: .1rem; background: $_G['style']['zhuti'];}

	.portal_block_tit .subtitle{ float: none !important; width: 100%; padding-top: 14px; display: block; background: url({$_G['style']['styleimgdir']}/portal_block_tit.png) no-repeat center 2px; text-align: center; font-size: .12rem; color: #999;}

/* view */
	.quote{ padding: .05rem 0 .05rem 16px; margin: .04rem 0; line-height: .2rem; border: 1px dashed #eee; border-radius: .02rem; background: #ffe url({$_G['style']['styleimgdir']}/qa.gif) no-repeat 0 .05rem; font-size: .14rem; color: #888; overflow: hidden;}
	.quote blockquote{ margin: 0; padding-right: 16px; background: url({$_G['style']['styleimgdir']}/qz.gif) no-repeat 100% 100%; display: inline; font-size: .14rem;}

/* viewthread */
	.byg_viewpay, #attachpayform .byg_o button, #payform .byg_o button, .trade_add_about a, .byg_reward_b a, #affirmbutton, #negabutton, .byg_debate_b .mtn a{ padding: .01rem .06rem; background: $_G['style']['zhuti'] !important; font-size: .14rem; color: #fff !important; border-radius: .02rem; display: inline-block;}

	a.byg_attach_name{ display: inline-block; vertical-align: middle; line-height: .28rem; padding: 0 .06rem 0 .24rem; background: $_G['style']['zhuti'] url({$_G['style']['styleimgdir']}/bai_xiazai.png) no-repeat .05rem center; background-size: .17rem; -webkit-background-size: .17rem; font-size: .16rem; color: #fff; border-radius: .04rem;}

/* post */
	#block_forum .over_one{ background: url({$_G['style']['styleimgdir']}/jinru.png) right center no-repeat; background-size: .16rem; -webkit-background-size: .16rem;}

	.plc_xin li .reply_y_b{ top: .9rem; width: .4rem; height: .25rem; line-height: .25rem; border: 0; background: $_G['style']['zhuti']; color: #fff;}

	.post_sort_img_btn .psi_btn{ position: absolute; top: 0; left: 0; z-index: 1; padding: .02rem .05rem; text-align: center; background: $_G['style']['zhuti']; color: #fff; border-radius: .04rem;}

/* footer */
	.footer_on, .footer_on i, .footer_on span{ color: $_G['style']['zhuti'] !important;}

	.sidenav-brand{ width: 100%; overflow: hidden; display: block; background-position: center center; background-image:url({$_G['style']['styleimgdir']}/home_bg.jpg); background-repeat: no-repeat; background-size: cover; -webkit-background-size: cover;}
	.byg_bl_lang1{ top: 0; background: url({$_G['style']['styleimgdir']}/bolang1.svg) repeat-x; background-size: 300px; -webkit-animation: byg_bl_lang1 3s linear infinite; animation: byg_bl_lang1 3s linear infinite;}
	.byg_bl_lang2{ top: 4px; background: url({$_G['style']['styleimgdir']}/bolang2.svg) repeat-x; background-size: 300px; -webkit-animation: byg_bl_lang2 5s linear infinite; animation: byg_bl_lang2 5s linear infinite;}

	.byg_scrolltop .scrolltop_side{ background: $_G['style']['zhuti'];}
	.byg_scrolltop .scrolltop_top{ background: $_G['style']['noticetext'];}
	.scrolltop_order_tit{ padding: .1rem 0; font-size: .18rem; text-align: center; background: $_G['style']['zhuti']; color: #fff; border-radius: .1rem .1rem 0 0;}
	.scrolltop_order_c li .on{ background: $_G['style']['zhuti']; color: #fff;}
</style>
<!--{/if}-->

<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>
<script src="{$_G['style']['styleimgdir']}/jquery.min.js?{VERHASH}"></script>
<script src="{$_G['style']['styleimgdir']}/common.js?{VERHASH}" charset="{CHARSET}"></script>

<!--{if CURSCRIPT == 'portal' && CURMODULE == 'index'}-->
<!--{eval}-->
	if(isset($_COOKIE["bygsjw"])){ 
		$byg_index_bg = true;
		setcookie("bygsjw", 1, time()+3600);
	}else{
		$byg_index_bg = false;
		setcookie("bygsjw", 1, time()+3600);
	}
<!--{/eval}-->
<!--{/if}-->
</head>

<body class="bg_xin">
<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/header.php');}-->

