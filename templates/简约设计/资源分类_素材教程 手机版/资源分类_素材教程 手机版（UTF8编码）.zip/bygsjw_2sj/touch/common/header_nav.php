<?php echo 'From: DisM.taobao.com';exit;?>

<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>

<!--【顶部文字导航开始】-->
<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/header_nav.php');}-->
<!--{if $font_nav1_p || $font_nav2_p || $font_nav3_p || $font_nav4_p || $font_nav5_p || $font_nav6_p || $font_nav7_p || $font_nav8_p || $font_nav9_p || $font_nav10_p || $font_nav11_p || $font_nav12_p}-->
<style>
	.bg_xin .header_xin{ padding-bottom: .91rem;}
	.bg_xin #byg_header{ height: .9rem; border-bottom: 1px solid #eee;}
</style>
<div class="portal_font_nav cl">
	<div class="swiper-wrapper">
		<!--{if $font_nav1_p}-->
		<!--{eval $font_nav1 = unserialize($font_nav1_p);}-->
		<a href="{$font_nav1['url']}" class="swiper-slide">{$font_nav1['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav2_p}-->
		<!--{eval $font_nav2 = unserialize($font_nav2_p);}-->
		<a href="{$font_nav2['url']}" class="swiper-slide">{$font_nav2['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav3_p}-->
		<!--{eval $font_nav3 = unserialize($font_nav3_p);}-->
		<a href="{$font_nav3['url']}" class="swiper-slide">{$font_nav3['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav4_p}-->
		<!--{eval $font_nav4 = unserialize($font_nav4_p);}-->
		<a href="{$font_nav4['url']}" class="swiper-slide">{$font_nav4['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav5_p}-->
		<!--{eval $font_nav5 = unserialize($font_nav5_p);}-->
		<a href="{$font_nav5['url']}" class="swiper-slide">{$font_nav5['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav6_p}-->
		<!--{eval $font_nav6 = unserialize($font_nav6_p);}-->
		<a href="{$font_nav6['url']}" class="swiper-slide">{$font_nav6['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav7_p}-->
		<!--{eval $font_nav7 = unserialize($font_nav7_p);}-->
		<a href="{$font_nav7['url']}" class="swiper-slide">{$font_nav7['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav8_p}-->
		<!--{eval $font_nav8 = unserialize($font_nav8_p);}-->
		<a href="{$font_nav8['url']}" class="swiper-slide">{$font_nav8['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav9_p}-->
		<!--{eval $font_nav9 = unserialize($font_nav9_p);}-->
		<a href="{$font_nav9['url']}" class="swiper-slide">{$font_nav9['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav10_p}-->
		<!--{eval $font_nav10 = unserialize($font_nav10_p);}-->
		<a href="{$font_nav10['url']}" class="swiper-slide">{$font_nav10['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav11_p}-->
		<!--{eval $font_nav11 = unserialize($font_nav11_p);}-->
		<a href="{$font_nav11['url']}" class="swiper-slide">{$font_nav11['text']}</a>
		<!--{/if}-->
		<!--{if $font_nav12_p}-->
		<!--{eval $font_nav12 = unserialize($font_nav12_p);}-->
		<a href="{$font_nav12['url']}" class="swiper-slide">{$font_nav12['text']}</a>
		<!--{/if}-->
	</div>
</div>
<script type="text/javascript">
	var font_nav_url = jQuery(".portal_font_nav .swiper-slide");
	for(var n=0;n<font_nav_url.length;n++){
		if(window.location.href.replace("{$_G[siteurl]}","").replace("&mobile=2","") == font_nav_url.eq(n).attr('href').replace("{$_G[siteurl]}","").replace("&mobile=2","")) {
			font_nav_url.eq(n).addClass("on");
			break;
		}
	}
	if(jQuery(".portal_font_nav .on").length > 0) {
		var font_nav_initial = jQuery(".portal_font_nav .on").offset().left + jQuery(".portal_font_nav .on").width() + 10 >= jQuery(window).width() ? jQuery(".portal_font_nav .on").index() : 0;
	}else{
		var font_nav_initial = 0;
	}
	var portal_font_nav = new Swiper('.portal_font_nav', {
		initialSlide : font_nav_initial,
		freeMode: true,
		slidesPerView: 'auto',
	});
</script>
<!--{/if}-->
<!--【顶部文字导航结束】-->

