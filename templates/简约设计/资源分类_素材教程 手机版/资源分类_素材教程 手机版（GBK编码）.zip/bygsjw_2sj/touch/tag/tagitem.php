<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!-- header start -->
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin cl"> 
			<a href="javascript:;" class="header_z">
				<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="�˵�"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<div class="header_c">
				<span class="header_font">��ر�ǩ</span>
			</div>
			<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="����"/></a>
		</div>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="forumdisplay_tab">
	<a href="misc.php?mod=tag" style="margin-right: 0;">ȫ����ǩ</a>
	<a href="javascript:;" class="on">{$tagname}</a>
</div>

<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/forum_forumdisplay_list.php');}-->
<!--{if $threadlist}-->
	<ul class="threadlist byg_tag_list">
		<!--{if $_G['style']['luntan_liebiaotu'] == "on"}-->
		<style>
			.list_img1_box .list_top{ float: left; width: 2.32rem; height: .44rem; margin-bottom: .06rem; padding-right: 0; overflow: hidden;}
			.list_img1_box .list_img1{ float: right; width: 1.15rem; padding: .1rem .1rem .1rem 0;}
			.list_img1_box .list_img1 a{ width: 100%; height: .76rem; padding: 0; border-radius: .04rem; overflow: hidden; display: block; background-position: center center; background-repeat: no-repeat; background-size: cover; -webkit-background-size: cover;}
			.list_img1_box .list_bottom{ float: left; width: 2.28rem; margin-right: 0;}
		</style>
		<!--{/if}-->
		<!--{loop $threadlist $thread}-->
			<!--{eval}-->
				$biaoid = substr($thread[tid], -1);
				$img_number = byg_threadlist_img_num($thread[tid], $thread[authorid], $biaoid);
			<!--{/eval}-->
			<li class="cl {if $img_number == 1 || $img_number == 2}list_img1_box{/if}">
				<div class="list_top cl">
					<a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight] class="over_two">{$thread[subject]}</a>
				</div>
			<!--{if $_G['style']['luntan_liebiaotu'] == "on"}-->
				<!--{if $img_number == 1 || $img_number == 2}-->
					<!--{eval $list_img1 = byg_threadlist_img($thread[tid], $thread[authorid], 1, $biaoid);}-->
					<!--{loop $list_img1 $list_img1_1}-->
					<div class="list_img1 cl">
						<a href="forum.php?mod=viewthread&tid=$thread[tid]" title="{$thread[subject]}" style="background-image:url({eval echo(getforumimg($list_img1_1[aid],0,230,150))});"></a>
					</div>
					<!--{/loop}-->
				<!--{elseif $img_number > 2}-->
					<ul class="list_img3 cl">
					<!--{eval $list_img3 = byg_threadlist_img($thread[tid], $thread[authorid], 3, $biaoid);}-->
					<!--{loop $list_img3 $list_img3_1}-->
						<li>
							<a href="forum.php?mod=viewthread&tid=$thread[tid]" title="{$thread[subject]}" style="background-image:url({eval echo(getforumimg($list_img3_1[aid],0,230,150))});"></a>
						</li>
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
			<!--{/if}-->
				<div class="list_bottom cl">
					<!--{if $thread['authorid'] && $thread['author']}-->
					<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="z">{$thread[author]}</a>
					<!--{else}-->
					<a href="javascript:;" class="z">{$_G[setting][anonymoustext]}</a>
					<!--{/if}-->
					<em class="z">&nbsp;&nbsp;&nbsp;&nbsp;{$thread[dateline]}&nbsp;&nbsp;</em>
					<span class="y">
						<img src="{$_G['style']['styleimgdir']}/forum_posts.png" alt="�ظ���"/>{$thread[replies]}
					</span>
					<span class="y">
						<img src="{$_G['style']['styleimgdir']}/chakan.png" alt="�鿴��"/>{$thread[views]}&nbsp;&nbsp;
					</span>
				</div>
			</li>
		<!--{/loop}-->
		<!--{if empty($showtype)}-->
			<li class="load_more_button">
				<a href="misc.php?mod=tag&id=$id&type=thread" style="padding:.05rem 0;font-size:.14rem;">�鿴����</a>
			</li>
		<!--{else}-->
			<!--{if $multipage}-->$multipage<!--{/if}-->
		<!--{/if}-->
	</ul>
<!--{else}-->
	<p class="home_no_data">{lang no_content}</p>
<!--{/if}-->

<!--{template common/footer}-->