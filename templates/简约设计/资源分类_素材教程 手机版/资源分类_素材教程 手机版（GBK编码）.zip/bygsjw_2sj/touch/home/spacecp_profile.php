<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header"> 
		<a href="javascript:;" class="header_z">
			<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="�˵�"/>
			<!--{if $_G[member][newpm] || $post_notice_new}-->
			<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
			<!--{/if}-->
		</a>
		<div class="header_c">
			<span class="header_font">�޸�����</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="����"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--{if $validate}-->
<!--{else}-->
	<!--{if $operation == 'password'}-->
	<!--{else}-->
		<style>
			#uhd{ position: relative; background: #fff;}
			#uhd_bg{ position: relative; z-index: 1; width: 3.75rem; height: 1.35rem; overflow: hidden; background: #3498db; background-color: $_G['style']['zhuti'];}
			.home_forum_header_js{ background: #fff !important; opacity: 0.1 !important; border-radius: 10% !important;}
			
			.byg_vid_show{ margin: .1rem 0 -.1rem; padding: .1rem; background: #ffe; border-radius: .02rem; font-size: .12rem; color: #f26c4f; text-align: center;}
			.byg_profilelist{ table-layout: fixed; width: 100%; margin: .1rem 0; border: 1px solid #eee; font-size: .14rem; background: #fff;}
			.byg_profilelist tr{ width: 100%; line-height: .2rem; border: 1px solid #eee;}
			.byg_profilelist th{ width: .9rem; padding: .1rem 0 .1rem .1rem; background: #fafafa; border: 1px solid #eee; }
			.byg_profilelist td{ padding: .05rem 0 .05rem .05rem;}
			.byg_profilelist_y{ width: .9rem;}
			.byg_profilelist td > input, .byg_profilelist td textarea{ width: 1.6rem; padding: .04rem; line-height: .16rem; border: .01rem solid #ddd; font-size: .14rem;}
			.byg_profilelist td select{ padding: .01rem 0 .02rem; font-size: .14rem; border: .01rem solid #ddd;}
			.byg_profilelist #tr_birthcity, .byg_profilelist #tr_residecity{ display: none;}
			.byg_profilelist td img{ max-width: 100%;}
			.byg_profilelist td .mtn{ margin: 0 !important;}
			.byg_profilelist td .xi2{ font-size: .12rem;}
			#profilesubmitbtn{ display: block; margin: .1rem; width: 3.55rem; line-height: .36rem; font-size: .16rem;}
			.tip dd a{ display: none;}
		</style>
		<div id="uhd">
			<div id="uhd_bg"></div>
			<div class="user_avatar">
				<div class="avatar_m"><a href="home.php?mod=spacecp&ac=avatar"><img src="<!--{avatar($_G[uid], big, true)}-->" alt="ͷ��" /><span>�޸�ͷ��</span></a></div>
				<h2 class="name">{$_G[username]}</h2>
			</div>
		</div>
		<!--{subtemplate home/spacecp_profile_nav}-->
		<!--{if $vid}-->
			<p class="byg_vid_show"><!--{if $showbtn}-->{lang spacecp_profile_message1}<!--{else}-->{lang spacecp_profile_message2}<!--{/if}--></p>
		<!--{/if}-->
		<iframe id="frame_profile" name="frame_profile" style="display: none"></iframe>
		<form action="{if $operation != 'plugin'}home.php?mod=spacecp&ac=profile&op=$operation{else}home.php?mod=spacecp&ac=plugin&op=profile&id=$_GET[id]{/if}" method="post" enctype="multipart/form-data" autocomplete="off"{if $operation != 'plugin'} target="frame_profile"{/if}>
			<input type="hidden" value="{FORMHASH}" name="formhash" />
			<!--{if $_GET[vid]}-->
			<input type="hidden" value="$_GET[vid]" name="vid" />
			<!--{/if}-->
			<table cellspacing="0" cellpadding="0" class="byg_profilelist" id="profilelist">
				<tr>
					<th>{lang username}</th>
					<td>$_G[member][username]</td>
					<td class="byg_profilelist_y">&nbsp;</td>
				</tr>
			<!--{loop $settings $key $value}-->
			<!--{if $value[available]}-->
				<tr id="tr_$key">
					<th id="th_$key"><!--{if $value[required]}--><span class="rq" title="{lang required}">*</span><!--{/if}-->$value[title]</th>
					<td id="td_$key">
						$htmls[$key]
					</td>
					<td class="byg_profilelist_y">
						<!--{if $vid}-->
						<input type="hidden" name="privacy[$key]" value="3" />
						<!--{else}-->
						<select name="privacy[$key]">
							<option value="0"{if $privacy[$key] == "0"} selected="selected"{/if}>{lang open_privacy}</option>
							<option value="1"{if $privacy[$key] == "1"} selected="selected"{/if}>{lang friend_privacy}</option>
							<option value="3"{if $privacy[$key] == "3"} selected="selected"{/if}>{lang secrecy}</option>
						</select>
						<!--{/if}-->
					</td>
				</tr>
			<!--{/if}-->
			<!--{/loop}-->
			<!--{if $allowcstatus && in_array('customstatus', $allowitems)}-->
				<tr>
					<th id="th_customstatus">{lang permission_basic_status}</th>
					<td id="td_customstatus">
						<input type="text" value="$space[customstatus]" name="customstatus" id="customstatus" class="" />
						<div class="" id="showerror_customstatus"></div>
					</td>
					<td>&nbsp;</td>
				</tr>
			<!--{/if}-->
			<!--{if $_G['group']['maxsigsize'] && in_array('sightml', $allowitems)}-->
				<tr>
					<th id="th_sightml">{lang personal_signature}</th>
					<td id="td_sightml">
						<div class="">
							<div class="">
								<textarea rows="3" name="sightml" id="sightmlmessage" class="">$space[sightml]</textarea>
							</div>
						</div>
					</td>
					<td>&nbsp;</td>
				</tr>
			<!--{/if}-->
			<!--{if in_array('timeoffset', $allowitems)}-->
				<tr>
					<th id="th_timeoffset">{lang time_zone}</th>
					<td id="td_timeoffset">
						<!--{eval $timeoffset = array({lang timezone});}-->
						<select name="timeoffset">
							<!--{loop $timeoffset $key $desc}-->
							<option value="$key"{if $key==$space[timeoffset]} selected="selected"{/if}>$desc</option>
							<!--{/loop}-->
						</select>
						<p class="xg1 xi2">{lang current_time} : <!--{date($_G[timestamp])}--></p>
						<p class="xg1 xi2">{lang time_zone_message}</p>
					</td>
					<td>&nbsp;</td>
				</tr>
			<!--{/if}-->

			<!--{if $operation == 'contact'}-->
				<tr>
					<th id="th_sightml">Email</th>
					<td id="td_sightml">$space[email]</td>
					<td>&nbsp;</td>
				</tr>
			<!--{/if}-->
			</table>
			<!--{if $showbtn}-->
			<div>
				<input type="hidden" name="profilesubmit" value="true" />
				<button type="submit" name="profilesubmitbtn" id="profilesubmitbtn" value="true">{lang save}</button>
			</div>
			<!--{/if}-->
		</form>
		<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
		<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
		<script type="text/javascript" src="{$_G['style']['styleimgdir']}/home_forum_header.js"></script>
		<script type="text/javascript">
			jQuery.firefly({
				minPixel: 6,
				maxPixel: 60,
				total : 15,
				on: '#uhd_bg',
				namespace: 'home_forum_header_js'
			});
			
			if(jQuery(".portal_font_nav .on").length > 0) {
				var font_nav_initial = jQuery(".portal_font_nav .on").offset().left + jQuery(".portal_font_nav .on").width() + 10 >= jQuery(window).width() ? jQuery(".portal_font_nav .on").index() : 0;
			}else{
				var font_nav_initial = 0;
			}
			var portal_font_nav = new Swiper('.portal_font_nav', {
				initialSlide : font_nav_initial,
				freeMode: true,
				slidesPerView: 'auto',
			});
			
			function bygsjw_id(id) {
				return !id ? null : document.getElementById(id);
			}
			function show_error(fieldid, extrainfo) {
				var elem = bygsjw_id('th_'+fieldid);
				if(elem) {
					elem.className = "rq";
					fieldname = elem.innerHTML;
					extrainfo = (typeof extrainfo == "string") ? extrainfo : "";
					bygsjw_id('showerror_'+fieldid).innerHTML = "{lang check_date_item} " + extrainfo;
					bygsjw_id(fieldid).focus();
				}
			}
			function show_success(message) {
				message = message == '' ? '{lang update_date_success}' : message;
				popup.open(message, 'confirm','home.php?mod=spacecp&ac=profile&op=$_GET[op]');
			}
			function clearErrorInfo() {
				var spanObj = bygsjw_id('profilelist').getElementsByTagName("div");
				for(var i in spanObj) {
					if(typeof spanObj[i].id != "undefined" && spanObj[i].id.indexOf("_")) {
						var ids = explode('_', spanObj[i].id);
						if(ids[0] == "showerror") {
							spanObj[i].innerHTML = '';
							bygsjw_id('th_'+ids[1]).className = '';
						}
					}
				}
			}
		</script>
	<!--{/if}-->
<!--{/if}-->

<!--{template common/footer}-->
