<?php echo 'From: DisM.taobao.com';exit;?>

<style>
	#uhd{ position: relative; background: #fff;}
	#uhd_bg{ position: relative; z-index: 1; width: 3.75rem; height: 1.5rem; overflow: hidden; background: #3498db; background-color: $_G['style']['zhuti'];}
	.home_forum_header_js{ background: #fff !important; opacity: 0.1 !important; border-radius: 10% !important;}
	.uhd_content{ position: absolute; top: .25rem; left: 0; z-index: 10; width: 100%; text-align: center;}
	.uhd_avatar{}
	.uhd_avatar img{ vertical-align: top; height: .8rem; width: .8rem; border-radius: 50%; box-shadow: 1px 2px 2px rgba(0, 0, 0, 0.3);}
	.uhd_name{ margin-top: .02rem; color: #fff; text-shadow: 1px 1px 1px #000;}
	.uhd_pm{ margin-top: .05rem;}
	.uhd_pm a{ display: inline-block; height: .24rem; line-height: .24rem; padding: 0 .05rem; background: rgba(0,0,0,.3); border-radius: .04rem; color: #fff; font-size: .12rem; vertical-align: top;}
	.uhd_pm img{ margin: .03rem .02rem 0; height: .18rem; vertical-align: top;}
</style>

<div id="uhd">
	<div id="uhd_bg"></div>
	<div class="uhd_content">
		<div class="uhd_avatar"><img src="<!--{avatar($space[uid], middle, true)}-->" alt="ͷ��" /></div>
		<h2 class="uhd_name">$space[username]</h2>
		<!--{if $space['uid'] != $_G['uid']}-->
		<div class="uhd_pm">
			<style>
				div#uhd_bg{ height: 1.75rem;}
			</style>
			<a href="home.php?mod=space&do=pm&subop=view&touid={$space['uid']}" onclick="return landingPrompt();"><img src="{$_G['style']['styleimgdir']}/faxiaoxi_bai.png" alt="��Ϣ" />����Ϣ</a>
		</div>
		<!--{/if}-->
	</div>
</div>

<div class="portal_font_nav">
	<div class="swiper-wrapper">
		<a href="home.php?mod=space&uid=$space[uid]&do=profile" class="swiper-slide {if $do==profile}on{/if}">{lang memcp_profile}</a>
		<!--{if $_G['uid'] == $space['uid']}-->
		<a href="home.php?mod=spacecp&ac=profile" class="swiper-slide">�޸�����</a>
		<!--{/if}-->
	</div>
</div>

<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/home_forum_header.js"></script>
<script type="text/javascript">
	jQuery.firefly({
	  minPixel: 6,
	  maxPixel: 60,
	  total : 15,
	  on: '#uhd_bg',
	  namespace: 'home_forum_header_js'
	});
	
	if(jQuery(".portal_font_nav .on").length > 0) {
		var font_nav_initial = jQuery(".portal_font_nav .on").offset().left + jQuery(".portal_font_nav .on").width() + 10 >= jQuery(window).width() ? jQuery(".portal_font_nav .on").index() : 0;
	}else{
		var font_nav_initial = 0;
	}
	var portal_font_nav = new Swiper('.portal_font_nav', {
		initialSlide : font_nav_initial,
		freeMode: true,
		slidesPerView: 'auto',
	});
</script>
