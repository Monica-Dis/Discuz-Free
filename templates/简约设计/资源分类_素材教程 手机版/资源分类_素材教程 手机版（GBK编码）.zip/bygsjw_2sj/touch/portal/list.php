<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->
<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header"> 
		<a href="javascript:;" class="header_z">
			<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="�˵�"/>
			<!--{if $_G[member][newpm] || $post_notice_new}-->
			<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
			<!--{/if}-->
		</a>
		<div class="header_c">
			<span class="header_font">{$cat[catname]}</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="����"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div class="portal_cat">
	<!--�Ż�Ƶ����ط��࿪ʼ-->
	<link rel="stylesheet" href="{$_G['style']['styleimgdir']}/swiper.min.css" type="text/css">
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
	<!--{if $cat[others]}-->
	<div class="portal_cat_top">
		<div class="swiper-wrapper">
			<!--{loop $cat[others] $value}-->
			<a href="{$portalcategory[$value['catid']]['caturl']}" class="swiper-slide<!--{if $_GET['catid'] == $value['catid']}--> on<!--{/if}-->">{$value[catname]}</a>
			<!--{/loop}-->
		</div>
	</div>
	<script type="text/javascript">
		if(jQuery(".portal_cat_top .on").length > 0) {
			var tab_initial = jQuery(".portal_cat_top .on").offset().left + jQuery(".portal_cat_top .on").width() + 20 >= jQuery(window).width() ? jQuery(".portal_cat_top .on").index() : 0;
		}else{
			var tab_initial = 0;
		}
		var portal_cat_top = new Swiper('.portal_cat_top', {
			initialSlide : tab_initial,
			slidesPerView : 'auto',
			freeMode : true,
		});
	</script>
	<!--{/if}-->
	<!--�Ż�Ƶ���¼����࿪ʼ-->
	<!--{if $cat[subs]}-->
	<div class="portal_cat_sub">
		<div class="swiper-wrapper">
			<span></span>
			<!--{loop $cat[subs] $value}-->
			<a href="{$portalcategory[$value['catid']]['caturl']}" class="swiper-slide">$value[catname]</a>
			<!--{/loop}-->
		</div>
	</div>
	<script type="text/javascript">
		var tab_initial = jQuery(".portal_cat_sub .on").length > 0 ? jQuery(".portal_cat_sub .on").index() : 0;
		var portal_cat_sub = new Swiper('.portal_cat_sub', {
			initialSlide : tab_initial,
			slidesPerView : 'auto',
			freeMode : true,
		});
	</script>
	<!--{/if}-->
</div>

<!--{eval $portal_list_gg = byg_diy_block_sum('��Դ�����ֻ����Ż��б�ҳ���');}-->
<!--{if $portal_list_gg}-->
<div class="byg_gg">{$portal_list_gg}</div>
<!--{/if}-->

<!--�Ż�Ƶ�������б���ʼ-->
<div class="portal_list">
	<div class="portal_list_list">
		<!--{subtemplate portal/list_list}-->
	</div>
	<div style="{if $_G['style']['fanye'] != 'on'}display: none;{/if}"><div class="pgs cl">{$list['multi']}</div></div>
	<!--{if $_G['style']['fanye'] != 'on'}-->
	<div class="load_more_button">
		<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="�ȴ�"/>���ݼ����У����Ժ�...</a>
	</div>
	<script type="text/javascript">
		var ajax_state = true;
		var ajax_page = <!--{if $_GET[page]}-->$_GET[page]<!--{else}-->1<!--{/if}--> + 1;
		var all_page = jQuery('div.pg label span').text().replace(/[^\d]/g, '') || 0;
		var ajax_url = 'portal.php?mod=list&catid=' + '$_GET[catid]' + '&';
		var next_page_url = jQuery('div.pg .nxt').prop('href');
		
		function list_ajax() {
			if(ajax_state == true) {
				if(all_page >= 2 && all_page >= ajax_page) {
					ajax_state = false;
					jQuery(".load_more_button").html('<a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/loading.gif" alt="�ȴ�"/>���ݼ����У����Ժ�...</a>');
					
					if(next_page_url.indexOf("index.php?") != -1) {
						ajax_url = next_page_url.split("?",1) + '?';
					}
					
					jQuery.ajax({
						url: ajax_url + 'page=' + ajax_page + '&mobile=2',
						type: 'GET',
						dataType: 'html',
						success: function(result) {
							jQuery(".portal_list_list").append(jQuery(result).find(".portal_list_list").html());
							ajax_page++;
							ajax_state = true;
						}
					});
				} else {
					jQuery(".load_more_button").html('<a href="forum.php?forumlist=1" title="��̳">�Ѿ������ˣ�������̳���ָ���</a>');
					ajax_state = false;
				}
			}
		}

		if(jQuery(document).height() <= jQuery(window).height()) {
			list_ajax();
		}

		jQuery(window).scroll(function() {
			if(jQuery(document).height() <= jQuery(window).height() + jQuery(window).scrollTop() + 1000) {
				list_ajax();
			}
		});
	</script>
	<!--{/if}-->
</div>

<!--{template common/footer}-->
