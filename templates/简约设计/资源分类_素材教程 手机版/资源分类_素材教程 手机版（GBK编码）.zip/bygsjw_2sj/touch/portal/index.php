<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/portal_index.php');}-->

<!--{if $index_bg_p}-->
	<!--{eval $index_bg = unserialize($index_bg_p);}-->
	<!--{if !$byg_index_bg}-->
	<style>
		.byg_index_bg{ position: fixed; top: 0; bottom: 0; left: 0; right: 0; z-index: 9998; display: block; width: 100%; height: 100%; background: #fff url({$_G['style']['styleimgdir']}/lanjiazai.gif) no-repeat center center;}
		.byg_index_bg .index_bg_img{ display: block; width: 100%; height: 100%; background-image: url($index_bg['pic']); border-radius: 0;}
		.byg_index_bg .index_bg_time{ position: fixed; right: .15rem; top: .15rem; z-index: 9999; width: .36rem; height: .36rem; padding: .08rem; background: rgba(0, 0, 0, 0.3); line-height: .19rem; font-size: .14rem; color: #fff; border-radius: 50%; text-align: center;}
	</style>
	<div class="byg_index_bg">
		<a href="{$index_bg['url']}" title="{$index_bg['text']}" class="index_bg_img img_center"></a>
		<div class="index_bg_time">����<br/><span>5</span>s</div>
	</div>
	<script type="text/javascript">
		var bg_num = 5;//��ҳ��ӭͼƬ-�޸ĵ���ʱ���������Ϸ����������5ҲҪͬʱ�޸ġ�
		var bg_time = setInterval(function(){
			if(bg_num == 0){
				index_bg_off();
			}
			bg_num--;
			jQuery('.index_bg_time span').html(bg_num);
		},1000);

		function index_bg_off() {
			jQuery('.byg_index_bg').hide();
			clearInterval(bg_time);
		}
		
		if(window.performance.navigation.type == 2){
			index_bg_off();
		}

		jQuery('.index_bg_time').on('click', function(){
			index_bg_off();
		});
	</script>
	<!--{/if}-->
<!--{/if}-->

<!-- header start --> 
<header class="header_xin">
	<div id="byg_header">
		<div class="hdc_xin cl">
			<a href="javascript:;" class="header_z">
				<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="�˵�"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<h2 class="header_c">
				<a href="./" title="$_G[setting][bbname]">
					<!--{if $bygsjw_logo}-->
					{$bygsjw_logo}
					<!--{else}-->
					<img src="{$_G['style']['boardimg']}" alt="LOGO"/>
					<!--{/if}-->
				</a>
			</h2>
			<a href="search.php?mod=forum" title="վ������" class="header_y"><img src="{$_G['style']['styleimgdir']}/tou_sousuo.png" alt="����"/></a>
		</div>
		<!--{template common/header_nav}-->
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<!--���Ż���ҳ�õ�Ƭ��-->
<!--{if $slide_bid}-->
	<!--{eval $slide = byg_data_block_data($slide_bid, 10);}-->
	<!--{if $slide}-->
	<div data-byginto class="sj_portal_slide">
		<div class="sj_slide_bd">
			<ul class="cl swiper-wrapper">
			<!--{loop $slide $sl}-->
				<li class="swiper-slide">
				<!--{if $sl[picflag] == 1}-->
					<a href="{$sl[url]}" title="{$sl[title]}" class="slide_img img_center swiper-lazy" data-background="{$_G['setting']['attachurl']}{if $sl[makethumb] == 1}{$sl[thumbpath]}{else}{$sl[pic]}{/if}"></a>
				<!--{elseif $sl[picflag] == 2}-->
					<a href="{$sl[url]}" title="{$sl[title]}" class="slide_img img_center swiper-lazy" data-background="{$_G['setting']['ftp']['attachurl']}{if $sl[makethumb] == 1}{$sl[thumbpath]}{else}{$sl[pic]}{/if}"></a>
				<!--{else}-->
					<a href="{$sl[url]}" title="{$sl[title]}" class="slide_img img_center swiper-lazy" data-background="{$sl[pic]}"></a>
				<!--{/if}-->
				</li>
			<!--{/loop}-->
			</ul>
		</div>
		<div class="sj_slide_hd_box"><ul class="sj_slide_hd"></ul></div>
	</div>
	<!--{else}-->
	<p style="background: #fff; text-align: center;">�õ�Ƭģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}-->
<!--{/if}-->

<!--���Ż���ҳ�ĸ񵼺���-->
<!--{if $four_case_tit1_param || $four_case_tit2_param || $four_case_tit3_param || $four_case_tit4_param}-->
<!--{eval}-->
	$four_case_sum1_param = byg_diy_block_param('��Դ�����ֻ����Ż���ҳ�ĸ񵼺�1����');
	$four_case_sum2_param = byg_diy_block_param('��Դ�����ֻ����Ż���ҳ�ĸ񵼺�2����');
	$four_case_sum3_param = byg_diy_block_param('��Դ�����ֻ����Ż���ҳ�ĸ񵼺�3����');
	$four_case_sum4_param = byg_diy_block_param('��Դ�����ֻ����Ż���ҳ�ĸ񵼺�4����');
	$f_c_tit1 = unserialize($four_case_tit1_param);
	$f_c_sum1 = unserialize($four_case_sum1_param);
	$f_c_tit2 = unserialize($four_case_tit2_param);
	$f_c_sum2 = unserialize($four_case_sum2_param);
	$f_c_tit3 = unserialize($four_case_tit3_param);
	$f_c_sum3 = unserialize($four_case_sum3_param);
	$f_c_tit4 = unserialize($four_case_tit4_param);
	$f_c_sum4 = unserialize($four_case_sum4_param);
<!--{/eval}-->
<div data-byginto class="portal_four_case">
	<ul class="cl">
		<!--{if $four_case_tit1_param}-->
		<li class="z four_case1">
			<a href="{$f_c_tit1['url']}" class="cl">
				<img src="{$f_c_tit1['pic']}" alt="{$f_c_tit1['text']}" class="z"/>
				<div class="y">
					<p class="four_case_tit over_one">{$f_c_tit1['text']}</p>
					<p class="four_case_sum over_one">{$f_c_sum1['text']}</p>
				</div>
			</a>
		</li>
		<!--{/if}-->
		<!--{if $four_case_tit2_param}-->
		<li class="z four_case2">
			<a href="{$f_c_tit2['url']}" class="cl">
				<img src="{$f_c_tit2['pic']}" alt="{$f_c_tit2['text']}" class="z"/>
				<div class="y">
					<p class="four_case_tit over_one">{$f_c_tit2['text']}</p>
					<p class="four_case_sum over_one">{$f_c_sum2['text']}</p>
				</div>
			</a>
		</li>
		<!--{/if}-->
		<!--{if $four_case_tit3_param}-->
		<li class="z four_case3">
			<a href="{$f_c_tit3['url']}" class="cl">
				<img src="{$f_c_tit3['pic']}" alt="{$f_c_tit3['text']}" class="z"/>
				<div class="y">
					<p class="four_case_tit over_one">{$f_c_tit3['text']}</p>
					<p class="four_case_sum over_one">{$f_c_sum3['text']}</p>
				</div>
			</a>
		</li>
		<!--{/if}-->
		<!--{if $four_case_tit4_param}-->
		<li class="z four_case4">
			<a href="{$f_c_tit4['url']}" class="cl">
				<img src="{$f_c_tit4['pic']}" alt="{$f_c_tit4['text']}" class="z"/>
				<div class="y">
					<p class="four_case_tit over_one">{$f_c_tit4['text']}</p>
					<p class="four_case_sum over_one">{$f_c_sum4['text']}</p>
				</div>
			</a>
		</li>
		<!--{/if}-->
	</ul>
</div>
<!--{else}-->
<style>
	.bg_xin .sj_portal_slide{ padding-bottom: .1rem;}
	.bg_xin .sj_portal_slide .sj_slide_hd_box{ bottom: .22rem;}
</style>
<!--{/if}-->

<!--���Ż���ҳ���ֺ���Դ��-->
<!--{if $good_bid}-->
	<!--{eval $good_tit = byg_data_block_tit($good_bid);}-->
	<!--{eval $good_c = byg_data_block_data($good_bid, 100);}-->
	<!--{if $good_c}-->
	<div data-byginto class="portal_good">
		<div class="portal_block_tit">
			{$good_tit}
		</div>
		<div class="portal_good_c">
			<ul class="cl">
			<!--{loop $good_c $gd_c}-->
				<!--{eval $gd_c_fields = unserialize($gd_c[fields]);}-->
				<!--{eval $gd_c_style = unserialize($gd_c[showstyle]);}-->
				<li>
					<div class="portal_block_border cl">
						<div class="lanjiazai_bg">
						<!--{if $gd_c[picflag] == 1}-->
							<a href="{$gd_c[url]}" title="{$gd_c[title]}" class="portal_good_img img_center lanjiazai" data-original="{$_G['setting']['attachurl']}{if $gd_c[makethumb] == 1}{$gd_c[thumbpath]}{else}{$gd_c[pic]}{/if}"></a>
						<!--{elseif $gd_c[picflag] == 2}-->
							<a href="{$gd_c[url]}" title="{$gd_c[title]}" class="portal_good_img img_center lanjiazai" data-original="{$_G['setting']['ftp']['attachurl']}{if $gd_c[makethumb] == 1}{$gd_c[thumbpath]}{else}{$gd_c[pic]}{/if}"></a>
						<!--{else}-->
							<a href="{$gd_c[url]}" title="{$gd_c[title]}" class="portal_good_img img_center lanjiazai" data-original="{$gd_c[pic]}"></a>
						<!--{/if}-->
						</div>
						<a href="{$gd_c[url]}" title="{$gd_c[title]}" class="portal_good_tit over_one" style="color: <!--{if $gd_c_style[title_c]}-->{$gd_c_style[title_c]}<!--{else}-->{$gd_c_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($gd_c[title],20,'')}--></a>
					</div>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{else}-->
	<p style="background: #fff; text-align: center;">���ֺ���Դģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}-->
<!--{/if}-->

<!--{if $portal_gg1}-->
<div data-byginto class="byg_gg">{$portal_gg1}</div>
<!--{/if}-->

<!--���Ż���ҳ������Դ��-->
<!--{if $new_bid}-->
	<!--{eval $new_tit = byg_data_block_tit($new_bid);}-->
	<!--{eval $new_c = byg_data_block_data($new_bid, 100);}-->
	<!--{if $new_c}-->
	<div data-byginto class="portal_new">
		<div class="portal_block_tit">
			{$new_tit}
		</div>
		<div class="portal_new_c">
			<ul class="cl">
			<!--{loop $new_c $nw_c}-->
				<!--{eval $nw_c_fields = unserialize($nw_c[fields]);}-->
				<!--{eval $nw_c_style = unserialize($nw_c[showstyle]);}-->
				<li>
					<div class="portal_block_border cl">
						<div class="lanjiazai_bg">
						<!--{if $nw_c[picflag] == 1}-->
							<a href="{$nw_c[url]}" title="{$nw_c[title]}" class="portal_new_img img_center lanjiazai" data-original="{$_G['setting']['attachurl']}{if $nw_c[makethumb] == 1}{$nw_c[thumbpath]}{else}{$nw_c[pic]}{/if}"></a>
						<!--{elseif $nw_c[picflag] == 2}-->
							<a href="{$nw_c[url]}" title="{$nw_c[title]}" class="portal_new_img img_center lanjiazai" data-original="{$_G['setting']['ftp']['attachurl']}{if $nw_c[makethumb] == 1}{$nw_c[thumbpath]}{else}{$nw_c[pic]}{/if}"></a>
						<!--{else}-->
							<a href="{$nw_c[url]}" title="{$nw_c[title]}" class="portal_new_img img_center lanjiazai" data-original="{$nw_c[pic]}"></a>
						<!--{/if}-->
						</div>
						<a href="{$nw_c[url]}" title="{$nw_c[title]}" class="portal_new_tit over_one" style="color: <!--{if $nw_c_style[title_c]}-->{$nw_c_style[title_c]}<!--{else}-->{$nw_c_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($nw_c[title],20,'')}--></a>
					<!--{if $nw_c_fields[authorid] || $nw_c_fields[authorid] == "0"}-->
						<div class="portal_new_count cl">
							<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_chakan.png" style="margin-right: 1px;"></i>{$nw_c_fields[views]}</span>
							<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_huifu.png"></i>{$nw_c_fields[replies]}</span>
							<span class="z portal_new_laizi"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_laizi.png"></i><a href="{$nw_c_fields[forumurl]}" title="{$nw_c_fields[forumname]}">{$nw_c_fields[forumname]}</a></span>
						</div>
						<div class="portal_new_id cl">
							<a href="home.php?mod=space&uid={$nw_c_fields[authorid]}&do=profile" title="{$nw_c_fields[author]}" class="portal_new_name over_one z"><i class="lanjiazai img_center" data-original="<!--{avatar($nw_c_fields[authorid], middle, true)}-->"></i>{$nw_c_fields[author]}</a>
							<span class="portal_new_date over_one y"><!--{echo dgmdate($nw_c_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
						</div>
					<!--{else}-->
						<div class="portal_new_count cl">
							<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_chakan.png" style="margin-right: 1px;"></i>{$nw_c_fields[viewnum]}</span>
							<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_huifu.png"></i>{$nw_c_fields[commentnum]}</span>
							<span class="z portal_new_laizi"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_laizi.png"></i><a href="{$nw_c_fields[caturl]}" title="{$nw_c_fields[catname]}">{$nw_c_fields[catname]}</a></span>
						</div>
						<div class="portal_new_id cl">
							<a href="home.php?mod=space&uid={$nw_c_fields[uid]}&do=profile" title="{$nw_c_fields[username]}" class="portal_new_name over_one z"><i class="lanjiazai img_center" data-original="<!--{avatar($nw_c_fields[uid], middle, true)}-->"></i>{$nw_c_fields[username]}</a>
							<span class="portal_new_date over_one y"><!--{echo dgmdate($nw_c_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
						</div>
					<!--{/if}-->
					</div>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{else}-->
	<p style="background: #fff; text-align: center;">������Դģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}-->
<!--{/if}-->

<!--{if $portal_gg2}-->
<div data-byginto class="byg_gg">{$portal_gg2}</div>
<!--{/if}-->

<!--���Ż���ҳ������Դ��-->
<!--{if $hot_bid}-->
	<!--{eval $hot_tit = byg_data_block_tit($hot_bid);}-->
	<!--{eval $hot_c = byg_data_block_data($hot_bid, 100);}-->
	<!--{if $hot_c}-->
	<div data-byginto class="portal_new">
		<div class="portal_block_tit">
			{$hot_tit}
		</div>
		<div class="portal_new_c">
			<ul class="cl">
			<!--{loop $hot_c $ht_c}-->
				<!--{eval $ht_c_fields = unserialize($ht_c[fields]);}-->
				<!--{eval $ht_c_style = unserialize($ht_c[showstyle]);}-->
				<li>
					<div class="portal_block_border cl">
						<div class="lanjiazai_bg">
						<!--{if $ht_c[picflag] == 1}-->
							<a href="{$ht_c[url]}" title="{$ht_c[title]}" class="portal_new_img img_center lanjiazai" data-original="{$_G['setting']['attachurl']}{if $ht_c[makethumb] == 1}{$ht_c[thumbpath]}{else}{$ht_c[pic]}{/if}"></a>
						<!--{elseif $ht_c[picflag] == 2}-->
							<a href="{$ht_c[url]}" title="{$ht_c[title]}" class="portal_new_img img_center lanjiazai" data-original="{$_G['setting']['ftp']['attachurl']}{if $ht_c[makethumb] == 1}{$ht_c[thumbpath]}{else}{$ht_c[pic]}{/if}"></a>
						<!--{else}-->
							<a href="{$ht_c[url]}" title="{$ht_c[title]}" class="portal_new_img img_center lanjiazai" data-original="{$ht_c[pic]}"></a>
						<!--{/if}-->
						</div>
						<a href="{$ht_c[url]}" title="{$ht_c[title]}" class="portal_new_tit over_one" style="color: <!--{if $ht_c_style[title_c]}-->{$ht_c_style[title_c]}<!--{else}-->{$ht_c_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($ht_c[title],20,'')}--></a>
					<!--{if $ht_c_fields[authorid] || $ht_c_fields[authorid] == "0"}-->
						<div class="portal_new_count cl">
							<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_chakan.png" style="margin-right: 1px;"></i>{$ht_c_fields[views]}</span>
							<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_huifu.png"></i>{$ht_c_fields[replies]}</span>
							<span class="z portal_new_laizi"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_laizi.png"></i><a href="{$ht_c_fields[forumurl]}" title="{$ht_c_fields[forumname]}">{$ht_c_fields[forumname]}</a></span>
						</div>
						<div class="portal_new_id cl">
							<a href="home.php?mod=space&uid={$ht_c_fields[authorid]}&do=profile" title="{$ht_c_fields[author]}" class="portal_new_name over_one z"><i class="lanjiazai img_center" data-original="<!--{avatar($ht_c_fields[authorid], middle, true)}-->"></i>{$ht_c_fields[author]}</a>
							<span class="portal_new_date over_one y"><!--{echo dgmdate($ht_c_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
						</div>
					<!--{else}-->
						<div class="portal_new_count cl">
							<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_chakan.png" style="margin-right: 1px;"></i>{$ht_c_fields[viewnum]}</span>
							<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_huifu.png"></i>{$ht_c_fields[commentnum]}</span>
							<span class="z portal_new_laizi"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/hui_laizi.png"></i><a href="{$ht_c_fields[caturl]}" title="{$ht_c_fields[catname]}">{$ht_c_fields[catname]}</a></span>
						</div>
						<div class="portal_new_id cl">
							<a href="home.php?mod=space&uid={$ht_c_fields[uid]}&do=profile" title="{$ht_c_fields[username]}" class="portal_new_name over_one z"><i class="lanjiazai img_center" data-original="<!--{avatar($ht_c_fields[uid], middle, true)}-->"></i>{$ht_c_fields[username]}</a>
							<span class="portal_new_date over_one y"><!--{echo dgmdate($ht_c_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
						</div>
					<!--{/if}-->
					</div>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{else}-->
	<p style="background: #fff; text-align: center;">������Դģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}-->
<!--{/if}-->

<!--{if $portal_gg3}-->
<div data-byginto class="byg_gg">{$portal_gg3}</div>
<!--{/if}-->

<!--���Ż���ҳ������Ѷ��-->
<!--{if $news_bid}-->
	<!--{eval $news_tit = byg_data_block_tit($news_bid);}-->
	<!--{eval $news_c = byg_data_block_data($news_bid, 100);}-->
	<!--{if $news_c}-->
	<div data-byginto class="portal_news">
		<div class="portal_block_tit">
			{$news_tit}
		</div>
		<div class="portal_news_c">
			<ul>
			<!--{loop $news_c $ns_c}-->
				<!--{eval $ns_c_fields = unserialize($ns_c[fields]);}-->
				<!--{eval $ns_c_style = unserialize($ns_c[showstyle]);}-->
				<li class="cl">
					<div class="lanjiazai_bg z">
					<!--{if $ns_c[picflag] == 1}-->
						<a href="{$ns_c[url]}" title="{$ns_c[title]}" class="img_center lanjiazai" data-original="{$_G['setting']['attachurl']}{if $ns_c[makethumb] == 1}{$ns_c[thumbpath]}{else}{$ns_c[pic]}{/if}"></a>
					<!--{elseif $ns_c[picflag] == 2}-->
						<a href="{$ns_c[url]}" title="{$ns_c[title]}" class="img_center lanjiazai" data-original="{$_G['setting']['ftp']['attachurl']}{if $ns_c[makethumb] == 1}{$ns_c[thumbpath]}{else}{$ns_c[pic]}{/if}"></a>
					<!--{else}-->
						<a href="{$ns_c[url]}" title="{$ns_c[title]}" class="img_center lanjiazai" data-original="{$ns_c[pic]}"></a>
					<!--{/if}-->
					</div>
					<div class="portal_news_y">
						<a href="{$ns_c[url]}" title="{$ns_c[title]}" class="portal_news_tit" style="color: <!--{if $ns_c_style[title_c]}-->{$ns_c_style[title_c]}<!--{else}-->{$ns_c_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($ns_c[title],78,'')}--></a>
						<div class="cl">
						<!--{if $ns_c_fields[forumname]}-->
							<a href="{$ns_c_fields[forumurl]}" title="{$ns_c_fields[forumname]}" class="over_one z">���ԣ�<!--{echo cutstr($ns_c_fields[forumname],16)}--></a>
						<!--{elseif $ns_c_fields[catname]}-->
							<a href="{$ns_c_fields[caturl]}" title="{$ns_c_fields[catname]}" class="over_one z">���ԣ�<!--{echo cutstr($ns_c_fields[catname],16)}--></a>
						<!--{/if}-->
							<span class="over_one y"><!--{echo dgmdate($ns_c_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
						</div>
					</div>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{else}-->
	<p style="background: #fff; text-align: center;">������Ѷģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}-->
<!--{/if}-->

<!--{if $portal_gg4}-->
<div data-byginto class="byg_gg">{$portal_gg4}</div>
<!--{/if}-->

<!--���Ż���ҳ���ظ��ࡿ-->
<!--{if $load_more_bid}-->
<div class="load_more">
	<!--{eval $load_more = byg_data_block_data($load_more_bid, 999);}-->
	<!--{if $load_more}-->
		<ul class="load_more_hidden">
		<!--{loop $load_more $load_more1}-->
			<!--{eval $lm_fields = unserialize($load_more1[fields]);}-->
			<!--{eval $lm_summary = strip_tags("$load_more1[summary]");}-->
			<!--{eval $lm_style = unserialize($load_more1[showstyle]);}-->
			<li data-byginto class="load_more_li cl">
				<div class="load_more_t cl">
				<!--{if $lm_fields[authorid] || $lm_fields[authorid] == "0"}-->
					<a href="home.php?mod=space&uid={$lm_fields[authorid]}&do=profile" title="{$lm_fields[author]}"><i class="load_more_avatar z lanjiazai img_center" data-original="<!--{avatar($lm_fields[authorid], middle, true)}-->"></i></a>
					<div class="y">
						<p class="load_more_author"><a href="home.php?mod=space&uid={$lm_fields[authorid]}&do=profile" title="{$lm_fields[author]}">{$lm_fields[author]}</a></p>
						<p class="load_more_date"><!--{echo dgmdate($lm_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></p>
					</div>
					<a href="{$lm_fields[forumurl]}" title="{$lm_fields[forumname]}" class="load_more_from">���ԣ�{$lm_fields[forumname]}</a>
				<!--{else}-->
					<a href="home.php?mod=space&uid={$lm_fields[uid]}&do=profile" title="{$lm_fields[username]}"><i class="load_more_avatar z lanjiazai img_center" data-original="<!--{avatar($lm_fields[uid], middle, true)}-->"></i></a>
					<div class="y">
						<p class="load_more_author"><a href="home.php?mod=space&uid={$lm_fields[uid]}&do=profile" title="{$lm_fields[username]}">{$lm_fields[username]}</a></p>
						<p class="load_more_date"><!--{echo dgmdate($lm_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></p>
					</div>
					<a href="{$lm_fields[caturl]}" title="{$lm_fields[catname]}" class="load_more_from">���ԣ�{$lm_fields[catname]}</a>
				<!--{/if}-->
				</div>
				<div class="load_more_c cl">
					<!--{if $load_more1[pic] == 'static/image/common/nophoto.gif'}-->
						<a href="{$load_more1[url]}" title="{$load_more1[title]}" class="z" style="width: 100%;">
							<h3 class="load_more_title over_two" style="width:100%; color:<!--{if $lm_style[title_c]}-->{$lm_style[title_c]}<!--{else}-->{$lm_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($load_more1[title],88,'')}--></h3>
							<p class="load_more_summary over_one" style="width:100%;"><!--{echo cutstr($lm_summary,58,'')}-->...</p>
						</a>
					<!--{else}-->
						<a href="{$load_more1[url]}" title="{$load_more1[title]}" class="z">
							<h3 class="load_more_title over_two" style="color:<!--{if $lm_style[title_c]}-->{$lm_style[title_c]}<!--{else}-->{$lm_fields[showstyle][title_c]}<!--{/if}-->;"><!--{echo cutstr($load_more1[title],60,'')}--></h3>
							<p class="load_more_summary over_one"><!--{echo cutstr($lm_summary,38,'')}-->...</p>
						</a>
						<div class="lanjiazai_bg y">
							<!--{if $load_more1[picflag] == 1}-->
							<a href="{$load_more1[url]}" title="{$load_more1[title]}" class="load_more_pic y lanjiazai" data-original="{$_G['setting']['attachurl']}{if $load_more1[makethumb] == 1}{$load_more1[thumbpath]}{else}{$load_more1[pic]}{/if}"></a>
							<!--{elseif $load_more1[picflag] == 2}-->
							<a href="{$load_more1[url]}" title="{$load_more1[title]}" class="load_more_pic y lanjiazai" data-original="{$_G['setting']['ftp']['attachurl']}{if $load_more1[makethumb] == 1}{$load_more1[thumbpath]}{else}{$load_more1[pic]}{/if}"></a>
							<!--{else}-->
							<a href="{$load_more1[url]}" title="{$load_more1[title]}" class="load_more_pic y lanjiazai" data-original="{$load_more1[pic]}"></a>
							<!--{/if}-->
						</div>
					<!--{/if}-->
				</div>
				<div class="load_more_b cl">
				<!--{if $lm_fields[authorid] || $lm_fields[authorid] == "0"}-->
					<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/chakan.png"></i>{$lm_fields[views]}</span>
					<span class="z"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/forum_posts.png"></i>{$lm_fields[replies]}</span>
					<span class="y"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/zan.png"></i>{$lm_fields[recommends]}</span>
				<!--{else}-->
					<span class="z" style="width:1.76rem;"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/chakan.png"></i>{$lm_fields[viewnum]}</span>
					<span class="y" style="width:1.76rem;"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/forum_posts.png"></i>{$lm_fields[commentnum]}</span>
				<!--{/if}-->
				</div>
			</li>
		<!--{/loop}-->
		</ul>
		<ul class="load_more_ul"></ul>
		<div class="load_more_button">
			<a href="javascript:;"><i class="lanjiazai img_center" data-original="{$_G['style']['styleimgdir']}/loading.gif"></i>���ݼ����У����Ժ�...</a>
		</div>
		<script type="text/javascript">
			var _content = [];
			var loadding = {
				_default:5, //ֱ����ʾ�ĸ���
				_loading:10, //ÿ�μ��صĸ���
				init:function(){
					var lis = jQuery(".load_more_li");
					jQuery(".load_more_ul").html("");
					for(var n=0;n<loadding._default;n++){
						lis.eq(n).appendTo(".load_more_ul");
					}
					for(var i=loadding._default;i<lis.length;i++){
						_content.push(lis.eq(i));
					}
				}
			}
			loadding.init();
			
			function list_ajax() {
				for(var i =0;i<loadding._loading;i++) {
					var target = _content.shift();
					if(!target) {
						jQuery(".load_more_button").html('<a href="forum.php?forumlist=1" title="��̳">�Ѿ������ˣ�������̳���ָ���</a>');
						break;
					}
					jQuery(".load_more_ul").append(target);
				}
			}
			
			if(jQuery(document).height() <= jQuery(window).height()) {
				list_ajax();
			}
			
			jQuery(window).scroll(function() {
				if(jQuery(document).height() <= jQuery(window).height() + jQuery(window).scrollTop() + 1000) {
					list_ajax();
				}
			});
		</script>
	<!--{else}--> 
		<p style="background: #fff; text-align: center;">���ظ���ģ�飺�����ݣ��뿴�̡̳���6����</p>
	<!--{/if}--> 
</div>
<!--{/if}-->

<!--{template common/footer}-->
