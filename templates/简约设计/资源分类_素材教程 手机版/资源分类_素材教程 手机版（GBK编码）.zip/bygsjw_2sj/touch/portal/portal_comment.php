<?php echo 'From: DisM.taobao.com';exit;?>

<div id="comment" class="portal_content_b">
	<div class="pcb_title cl">
		<span class="y">{$data[commentnum]}������</span>
		<h3>{lang latest_comment}</h3>
	</div>
	
	<div id="comment_ul" class="comment_ul">
		<!--{if $article[commentnum]}-->
			<ul class="comment_list">
				<!--{loop $commentlist $comment}-->
				<!--{template portal/comment_li}-->
				<!--{if !empty($aimgs[$comment[cid]])}-->
				<script type="text/javascript" reload="1">aimgcount[{$comment[cid]}] = [<!--{echo implode(',', $aimgs[$comment[cid]]);}-->];attachimgshow($comment[cid]);</script>
				<!--{/if}-->
				<!--{/loop}-->
				<script src="{$_G['style']['styleimgdir']}/comment_reply.js"></script>
			</ul>
		<!--{else}-->
			<div class="no_reply">
				<img src="{$_G['style']['styleimgdir']}/no_reply.png" alt="û�лظ�"/>
			</div>
		<!--{/if}-->
		
		<!--{if !$data[htmlmade]}-->
			<div class="post_fixed cl">
				<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" title="��������" onclick="return landingPrompt();" class="post_avatar"><img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/></a>
				<a href="javascript:;" class="post_edit" id="post_edit">{lang send_reply_fast_tip}</a>
				<a href="javascript:;" class="post_sidenav"><img src="{$_G['style']['styleimgdir']}/post_sidenav.png" alt="����"/></a>
				<a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" onclick="favorite_thread_ajax(this.id);return false;" id="a_favorite" class="post_favorite"><img src="{$_G['style']['styleimgdir']}/shoucang.png" alt="�ղ�"/></a>
				<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="post_return"><img src="{$_G['style']['styleimgdir']}/fanhui.png" alt="����"/></a>
			</div>
			<div class="cover_div"></div>
			<form id="cform" name="cform" action="$form_url" method="post" autocomplete="off">
				<div class="tedt">
					<div class="area">
						<textarea name="message" rows="5" placeholder="&nbsp;{lang send_reply_fast_tip}" onclick="return landingPrompt();" class="pt" id="message"></textarea>
						<a href="javascript:;" class="cform_off">ȡ��</a>
						<button type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="true" class="pn">�ύ</button>
					</div>
				</div>
				<!--{if $secqaacheck || $seccodecheck}-->
					<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
					<div class="mtm"><!--{subtemplate common/seccheck}--></div>
				<!--{/if}-->
				<!--{if !empty($topicid) }-->
					<input type="hidden" name="referer" value="$topicurl#comment" />
					<input type="hidden" name="topicid" value="$topicid">
				<!--{else}-->
					<input type="hidden" name="portal_referer" value="$viewurl#comment">
					<input type="hidden" name="referer" value="$viewurl#comment" />
					<input type="hidden" name="id" value="$data[id]" />
					<input type="hidden" name="idtype" value="$data[idtype]" />
					<input type="hidden" name="aid" value="$aid">
				<!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}">
				<input type="hidden" name="replysubmit" value="true">
				<input type="hidden" name="commentsubmit" value="true" />
			</form>
			<script type="text/javascript">
				jQuery("#post_edit").click(function(){jQuery("#cform").slideToggle(0);});
				jQuery("#post_edit").click(function(){jQuery(".cover_div").slideToggle(0);});
				jQuery(".cover_div").click(function(){jQuery("#cform").slideToggle(0);});
				jQuery(".cover_div").click(function(){jQuery(".cover_div").slideToggle(0);});
				jQuery(".cform_off").click(function(){jQuery("#cform").slideToggle(0);});
				jQuery(".cform_off").click(function(){jQuery(".cover_div").slideToggle(0);});
				
				function favorite_thread_ajax(obj) {
					var thread_id = '#' + obj;
					if($_G[uid]){
						jQuery.ajax({
							url: jQuery(thread_id).attr('href') + '&inajax=1',
							type: 'POST',
							dataType: 'xml',
							success: function(s){
								popup.open(s.lastChild.firstChild.nodeValue);
								evalscript(s.lastChild.firstChild.nodeValue);
							},
							error: function(){
								window.location.href = jQuery(thread_id).attr('href');
								popup.close();
							},
						});
					}else{
						landingPrompt();
					}
				}
			</script>
		<!--{/if}-->
	</div>
</div>