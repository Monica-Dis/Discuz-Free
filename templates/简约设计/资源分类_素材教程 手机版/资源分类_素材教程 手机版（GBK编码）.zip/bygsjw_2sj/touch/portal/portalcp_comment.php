<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->

<!--{if $_GET['op'] == 'requote'}-->
	[quote]{$comment[username]}: {$comment[message]}[/quote]
<!--{elseif $_GET['op'] == 'edit'}-->
	<!-- header start --> 
	<header class="header_xin">
		<div class="hdc_xin cl" id="byg_header"> 
			<a href="javascript:;" class="header_z">
				<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="�˵�"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<div class="header_c">
				<span class="header_font">�༭����</span>
			</div>
			<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="����"/></a>
		</div>
	</header>
	<!--{hook/global_header_mobile}-->
	<!-- header end -->
	<form id="editcommentform_{$cid}" name="editcommentform_{$cid}" method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=comment&op=edit&cid=$cid{if $_GET[modarticlecommentkey]}&modarticlecommentkey=$_GET[modarticlecommentkey]{/if}" class="comment_edit">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div>
			<textarea id="message_{$cid}" name="message" rows="8" class="pt">$comment[message]</textarea>
		</div>
		<p class="cl">
			<button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="z">{lang submit}</button>
			<button type="button" onclick="history.go(-1)" class="y">ȡ��</button>
		</p>
	</form>
<!--{elseif $_GET['op'] == 'delete'}-->
	<!-- header start --> 
	<header class="header_xin">
		<div class="hdc_xin cl" id="byg_header"> 
			<a href="javascript:;" class="header_z">
				<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="�˵�"/>
				<!--{if $_G[member][newpm] || $post_notice_new}-->
				<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
				<!--{/if}-->
			</a>
			<div class="header_c">
				<span class="header_font">ɾ������</span>
			</div>
			<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
			<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="����"/></a>
		</div>
	</header>
	<!--{hook/global_header_mobile}-->
	<!-- header end -->
	<form id="deletecommentform_{$cid}" name="deletecommentform_{$cid}" method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=comment&op=delete&cid=$cid" class="comment_delete">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="c">{lang comment_delete_confirm}</div>
		<p class="cl">
			<button type="submit" name="deletesubmitbtn" value="true" class="z">{lang confirms}</button>
			<button type="button" onclick="history.go(-1)" class="y">ȡ��</button>
		</p>
	</form>
<!--{/if}-->

<!--{template common/footer}-->