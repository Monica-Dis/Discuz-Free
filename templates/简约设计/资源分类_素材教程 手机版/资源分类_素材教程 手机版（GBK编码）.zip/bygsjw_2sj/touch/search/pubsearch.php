<?php echo 'From: DisM.taobao.com';exit;?>

<div class="forumdisplay_tab">
	<a href="search.php?mod=forum" {if $_GET['mod'] == 'forum'}class="on"{/if}>����</a>
	<a href="search.php?mod=portal" {if $_GET['mod'] == 'portal'}class="on"{/if}>����</a>
</div>

<!--{eval $search_gg = byg_diy_block_sum('��Դ�����ֻ�������ҳ���');}-->
<!--{if $search_gg}-->
<div class="byg_gg">{$search_gg}</div>
<!--{/if}-->

<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<div class="search">
	<table width="100%" cellspacing="0" cellpadding="0">
		<tbody>
			<tr>
				<td>
					<input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt"{if $_GET['mod'] == 'forum'} placeholder="��������"{elseif $_GET['mod'] == 'portal'} placeholder="��������"{/if} />
				</td>
				<td align="right" class="scbar_btn_td" style="width:.6rem;">
					<div><input type="hidden" name="searchsubmit" value="yes" /><input type="submit" value="{lang search}" class="button2" id="scform_submit" style="width:.5rem;" /></div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
