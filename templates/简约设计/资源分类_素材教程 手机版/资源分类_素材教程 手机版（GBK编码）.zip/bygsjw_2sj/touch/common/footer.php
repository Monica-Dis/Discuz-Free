<?php echo 'From: DisM.taobao.com';exit;?>

<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<div id="mask" style="display:none;"></div>
<!--{if $_G['style']['wei'] == 'on'}-->
	<!--{if !$nofooter}-->
	<div class="footer">
		<div>
			<!--{if !$_G[uid] && !$_G['connectguest']}-->
			<a href="forum.php">{lang mobilehome}</a> | <a href="member.php?mod=logging&action=login" title="{lang login}">{lang login}</a> | <a href="<!--{if $_G['setting']['regstatus']}-->member.php?mod={$_G[setting][regname]}<!--{else}-->javascript:;" style="color:#D7D7D7;<!--{/if}-->" title="{$_G['setting']['reglinkname']}">{lang register}</a>
			<!--{else}-->
			<a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1">{$_G['member']['username']}</a> , <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" title="{lang logout}" class="dialog">{lang logout}</a>
			<!--{/if}-->
		</div>
		<div>
			<a href="{$_G['setting']['mobile']['simpletypeurl'][0]}">{lang no_simplemobiletype}</a> |  
			<a href="javascript:;" style="color:#D7D7D7;">{lang mobile2version}</a> | 
			<a href="{$_G['setting']['mobile']['nomobileurl']}">{lang nomobiletype}</a> | 
			<span>&copy; Comsenz Inc.</span>
		</div>
	</div>
	<!--{/if}-->
<!--{/if}-->

<!--{if CURSCRIPT != 'plugin'}-->

<!--{eval $stats_code = byg_diy_block_sum('��Դ�����ֻ���ͳ�ƴ���');}-->
<!--{if $stats_code}-->
{$stats_code}
<!--{/if}-->

<!--��β����������ʼ��-->
<!--{if (CURSCRIPT == 'forum' && (CURMODULE  == 'viewthread' || CURMODULE  == 'post')) || (CURSCRIPT == 'portal' && CURMODULE == 'view')}-->
<div class="post_footer"></div>
<!--{else}-->
<div class="footer_xin">
	<ul class="footer_nav" id="footer_nav">
	<!--{eval}-->
		$footer_nav1_p = byg_diy_block_param('��Դ�����ֻ���β������1');
		$footer_nav2_p = byg_diy_block_param('��Դ�����ֻ���β������2');
		$footer_nav3_p = byg_diy_block_param('��Դ�����ֻ���β������3');
		$footer_nav4_p = byg_diy_block_param('��Դ�����ֻ���β������4');
		$footer_nav5_p = byg_diy_block_param('��Դ�����ֻ���β������5');
	<!--{/eval}-->
	
		<li>
		<!--{if $footer_nav1_p}-->
			<!--{eval $footer_nav1 = unserialize($footer_nav1_p);}-->
			<!--{if $footer_nav1['url'] == 'portal.php?mod=index'}-->
			<a href="{$footer_nav1['url']}" title="$_G[setting][bbname]" class="<!--{if CURSCRIPT == 'portal' && CURMODULE == 'index'}-->footer_on<!--{/if}-->">
			<!--{else}-->
			<a href="{$footer_nav1['url']}">
			<!--{/if}-->
			<img src="{$footer_nav1['pic']}" alt="{$footer_nav1['text']}"/><span>{$footer_nav1['text']}</span></a>
		<!--{else}-->
			<a href="portal.php?mod=index" title="$_G[setting][bbname]" class="<!--{if CURSCRIPT == 'portal' && CURMODULE == 'index'}-->footer_on<!--{/if}-->">
			<!--{if CURSCRIPT == 'portal' && CURMODULE == 'index'}-->
				<i class="iconfont icon-zhuye-on"></i>
			<!--{else}-->
				<i class="iconfont icon-zhuye-off"></i>
			<!--{/if}-->
				<span>��ҳ</span>
			</a>
		<!--{/if}-->
		</li>
	
		<li>
		<!--{if $footer_nav2_p}-->
			<!--{eval $footer_nav2 = unserialize($footer_nav2_p);}-->
			<!--{if $footer_nav2['url'] == 'forum.php?forumlist=1'}-->
			<a href="{$footer_nav2['url']}" title="$_G[setting][bbname]-��̳" class="<!--{if CURSCRIPT == 'forum' && CURMODULE == 'index'}-->footer_on<!--{/if}-->">
			<!--{else}-->
			<a href="{$footer_nav2['url']}">
			<!--{/if}-->
			<img src="{$footer_nav2['pic']}" alt="{$footer_nav2['text']}"/><span>{$footer_nav2['text']}</span></a>
		<!--{else}-->
			<a href="forum.php?forumlist=1" title="$_G[setting][bbname]-��̳" class="<!--{if CURSCRIPT == 'forum' && CURMODULE == 'index'}-->footer_on<!--{/if}-->">
			<!--{if CURSCRIPT == 'forum' && CURMODULE == 'index'}-->
				<i class="iconfont icon-luntan-on"></i>
			<!--{else}-->
				<i class="iconfont icon-luntan-off"></i>
			<!--{/if}-->
				<span>��̳</span>
			</a>
		<!--{/if}-->
		</li>
		
		<li>
			<div class="footer_fatie">
			<!--{if $footer_nav3_p}-->
				<!--{eval $footer_nav3 = unserialize($footer_nav3_p);}-->
				<!--{if $footer_nav3['url'] == 'forum.php?mod=misc&action=nav'}-->
				<a href="{$footer_nav3['url']}" title="��������" class="<!--{if (CURSCRIPT == 'forum' && CURMODULE == 'misc' && $_GET['action'] == 'nav') || (CURSCRIPT == 'forum' && CURMODULE == 'post')}-->footer_on<!--{/if}-->">
				<!--{else}-->
				<a href="{$footer_nav3['url']}">
				<!--{/if}-->
				<img src="{$footer_nav3['pic']}" alt="{$footer_nav3['text']}"/><span>{$footer_nav3['text']}</span></a>
			<!--{else}-->
				<!--{if CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay'}-->
				<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}" onclick="return landingPrompt(1);" class="<!--{if (CURSCRIPT == 'forum' && CURMODULE == 'misc' && $_GET['action'] == 'nav') || (CURSCRIPT == 'forum' && CURMODULE == 'post')}-->footer_on<!--{/if}-->">
				<!--{else}-->
				<a href="forum.php?mod=misc&action=nav" title="��������" class="<!--{if (CURSCRIPT == 'forum' && CURMODULE == 'misc' && $_GET['action'] == 'nav') || (CURSCRIPT == 'forum' && CURMODULE == 'post')}-->footer_on<!--{/if}-->">
				<!--{/if}-->
					<!--{if (CURSCRIPT == 'forum' && CURMODULE == 'misc' && $_GET['action'] == 'nav') || (CURSCRIPT == 'forum' && CURMODULE == 'post')}-->
					<i class="iconfont icon-fatie-on"></i>
					<!--{else}-->
					<i class="iconfont icon-fatie-off"></i>
					<!--{/if}-->
					<span>����</span>
				</a>
			<!--{/if}-->
			</div>
		</li>
		
		<li>
		<!--{if $footer_nav4_p}-->
			<!--{eval $footer_nav4 = unserialize($footer_nav4_p);}-->
			<!--{if $footer_nav4['url'] == 'search.php?mod=forum'}-->
			<a href="{$footer_nav4['url']}" title="վ������" class="<!--{if CURSCRIPT == 'search'}-->footer_on<!--{/if}-->">
			<!--{else}-->
			<a href="{$footer_nav4['url']}">
			<!--{/if}-->
			<img src="{$footer_nav4['pic']}" alt="{$footer_nav4['text']}"/><span>{$footer_nav4['text']}</span></a>
		<!--{else}-->
			<a href="search.php?mod=forum" title="վ������" class="<!--{if CURSCRIPT == 'search'}-->footer_on<!--{/if}-->">
			<!--{if CURSCRIPT == 'search'}-->
				<i class="iconfont icon-sousuo-on"></i>
			<!--{else}-->
				<i class="iconfont icon-sousuo-off"></i>
			<!--{/if}-->
				<span>����</span>
			</a>
		<!--{/if}-->
		</li>
		
		<li>
		<!--{if $footer_nav5_p}-->
			<!--{eval $footer_nav5 = unserialize($footer_nav5_p);}-->
			<!--{if $footer_nav5['url'] == 'home.php?mod=space&do=profile&mycenter=1'}-->
			<a href="{$footer_nav5['url']}" title="��������" onclick="return landingPrompt();" class="<!--{if CURSCRIPT == 'home'}-->footer_on<!--{/if}-->">
			<!--{else}-->
			<a href="{$footer_nav5['url']}">
			<!--{/if}-->
			<img src="{$footer_nav5['pic']}" alt="{$footer_nav5['text']}"/><span>{$footer_nav5['text']}</span></a>
		<!--{else}-->
			<a href="home.php?mod=space&do=profile&mycenter=1" title="��������" onclick="return landingPrompt();" class="<!--{if CURSCRIPT == 'home'}-->footer_on<!--{/if}-->">
			<!--{if CURSCRIPT == 'home'}-->
				<i class="iconfont icon-wode-on"></i>
			<!--{else}-->
				<i class="iconfont icon-wode-off"></i>
			<!--{/if}-->
				<span>�ҵ�</span>
			</a>
		<!--{/if}-->
		</li>
		
	</ul>
</div>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/footer.js"></script>
<!--{/if}-->
<!--��β��������������-->

<div class="byg_scrolltop">
	<!--{if CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay'}-->
	<a href="javascript:;" class="scrolltop_order"><img src="{$_G['style']['styleimgdir']}/bai_paixu.png" alt="����"/><span>����</span></a>
	<!--{/if}-->
	<!--{if CURSCRIPT == 'forum' && CURMODULE == 'guide'}-->
	<a href="javascript:;" class="scrolltop_guide"><img src="{$_G['style']['styleimgdir']}/bai_paixu.png" alt="����"/><span>����</span></a>
	<!--{/if}-->
	<a href="javascript:;" class="scrolltop_side"><i class="iconfont icon-daohang"></i><span>����</span></a>
	<a href="javascript:;" onclick="topFunction();" class="scrolltop_top"><i class="iconfont icon-top"></i><span>����</span></a>
</div>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/scrolltop.js"></script>
<!--{if CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay'}-->
<div class="scrolltop_order_pop">
	<div class="scrolltop_order_tit">�б�����</div>
	<div class="scrolltop_order_c">
		<ul>
			<li class="cl">
				<span>���ͣ�</span>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['filter']}class="on"{/if}>ȫ������</a>
				<!--{if $showpoll}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['specialtype'] == 'poll'}class="on"{/if}>ͶƱ</a><!--{/if}-->
				<!--{if $showtrade}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['specialtype'] == 'trade'}class="on"{/if}>��Ʒ</a><!--{/if}-->
				<!--{if $showreward}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['specialtype'] == 'reward'}class="on"{/if}>����</a><!--{/if}-->
				<!--{if $showactivity}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['specialtype'] == 'activity'}class="on"{/if}>�</a><!--{/if}-->
				<!--{if $showdebate}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['specialtype'] == 'debate'}class="on"{/if}>����</a><!--{/if}-->
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=hot" {if $_GET['filter'] == 'hot'}class="on"{/if}>����</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['filter'] == 'digest'}class="on"{/if}>����</a>
			</li>
			<!--{if $_GET['specialtype'] == 'reward'}-->
			<li class="cl">
				<span>���ͣ�</span>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['rewardtype'] == ''}class="on"{/if}>ȫ������</a>
				<!--{if $showpoll}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1" {if $_GET['rewardtype'] == '1'}class="on"{/if}>������</a><!--{/if}-->
				<!--{if $showtrade}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2" {if $_GET['rewardtype'] == '2'}class="on"{/if}>�ѽ��</a><!--{/if}-->
			</li>
			<!--{/if}-->
			<li class="cl">
				<span>����</span>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'lastpost'}class="on"{/if}>���»ظ�</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'dateline'}class="on"{/if}>����ʱ��</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'replies'}class="on"{/if}>�ظ���</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'views'}class="on"{/if}>�鿴��</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'heats'}class="on"{/if}>���Ŷ�</a>
			</li>
			<li class="cl">
				<span>ʱ�䣺</span>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['dateline']}class="on"{/if}>ȫ��ʱ��</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '86400'}class="on"{/if}>һ��</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '172800'}class="on"{/if}>����</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '604800'}class="on"{/if}>һ��</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '2592000'}class="on"{/if}>һ����</a>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '7948800'}class="on"{/if}>������</a>
			</li>
		</ul>
	</div>
</div>
<div class="scrolltop_order_cover"></div>
<script type="text/javascript">
	jQuery(".scrolltop_order,.scrolltop_order_cover").click(function(){jQuery(".scrolltop_order_pop,.scrolltop_order_cover").slideToggle(0);});
</script>
<!--{/if}-->
<!--{if CURSCRIPT == 'forum' && CURMODULE == 'guide'}-->
<div class="scrolltop_guide_pop">
	<div class="scrolltop_order_tit">�б�����</div>
	<div class="scrolltop_order_c">
		<ul>
			<li class="cl">
				<a href="forum.php?mod=guide" {if !$_GET['view']}class="on"{/if}>Ĭ��</a>
				<a href="forum.php?mod=guide&view=newthread" {if $_GET['view'] == 'newthread'}class="on"{/if}>���·���</a>
				<a href="forum.php?mod=guide&view=sofa" {if $_GET['view'] == 'sofa'}class="on"{/if}>��ɳ��</a>
				<a href="forum.php?mod=guide&view=new" {if $_GET['view'] == 'new'}class="on"{/if}>���»ظ�</a>
				<a href="forum.php?mod=guide&view=hot" {if $_GET['view'] == 'hot'}class="on"{/if}>��������</a>
				<a href="forum.php?mod=guide&view=digest" {if $_GET['view'] == 'digest'}class="on"{/if}>���¾���</a>
				<a href="forum.php?mod=guide&view=my" onclick="return landingPrompt();" {if $_GET['view'] == 'my'}class="on"{/if}>�ҵ�����</a>
			</li>
		</ul>
	</div>
</div>
<div class="scrolltop_guide_cover"></div>
<script type="text/javascript">
	jQuery(".scrolltop_guide,.scrolltop_guide_cover").click(function(){jQuery(".scrolltop_guide_pop,.scrolltop_guide_cover").slideToggle(0);});
</script>
<!--{/if}-->

<!--����ർ������ʼ��-->
<div class="byg_sidenav">
	<div class="sidenav-brand">
		<!--{if $_G[uid]}-->
		<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="sidenav_t cl">
			<img src="<!--{avatar($_G[uid], middle, true)}-->" alt="ͷ��"/><span>{$_G['username']}</span>
		</a>
		<div class="sidenav_c cl">
			<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}"><i class="iconfont icon-tuichu"></i>�˳���½</a>
		</div>
		<!--{else}-->
		<a href="member.php?mod=logging&action=login" onclick="return landingPrompt();" class="sidenav_t cl">
			<img src="{$_G['style']['styleimgdir']}/middle.gif" alt="ͷ��"/><span>�ο�</span>
		</a>
		<div class="sidenav_c cl">
			<a href="member.php?mod=logging&action=login"><i class="iconfont icon-denglu"></i>��½</a>
			<a href="member.php?mod={$_G[setting][regname]}"><i class="iconfont icon-zhuce"></i>ע��</a>
		</div>
		<!--{/if}-->
		<div class="byg_bl_lang">
			<div class="byg_bl_lang1"></div>
			<div class="byg_bl_lang2"></div>
		</div>
	</div>
	<ul class="sidenav-menu">
		<!--{if CURSCRIPT == 'forum' && CURMODULE == 'viewthread'}-->
		<li>
			<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&<!--{eval echo rawurldecode($_GET[extra]);}-->"><i class="iconfont icon-fanhui2"></i>����б�</a>
		</li>
		<!--{/if}-->
		<!--{eval}-->
			$side_nav1_p = byg_diy_block_param('��Դ�����ֻ����ߵ���1');
			$side_nav2_p = byg_diy_block_param('��Դ�����ֻ����ߵ���2');
			$side_nav3_p = byg_diy_block_param('��Դ�����ֻ����ߵ���3');
			$side_nav4_p = byg_diy_block_param('��Դ�����ֻ����ߵ���4');
			$side_nav5_p = byg_diy_block_param('��Դ�����ֻ����ߵ���5');
			$side_nav6_p = byg_diy_block_param('��Դ�����ֻ����ߵ���6');
			$side_nav7_p = byg_diy_block_param('��Դ�����ֻ����ߵ���7');
			$side_nav8_p = byg_diy_block_param('��Դ�����ֻ����ߵ���8');
		<!--{/eval}-->
		
		<!--{if $side_nav1_p}-->
			<!--{eval $side_nav1 = unserialize($side_nav1_p);}-->
			<!--{if $side_nav1['text']}-->
			<li><a href="{$side_nav1['url']}"><img src="{$side_nav1['pic']}" alt="{$side_nav1['text']}"/>{$side_nav1['text']}</a></li>
			<!--{/if}-->
		<!--{else}-->
			<li><a href="portal.php?mod=index"><i class="iconfont icon-zhuye-off"></i>��վ��ҳ</a></li>
		<!--{/if}-->
		
		<!--{if $side_nav2_p}-->
			<!--{eval $side_nav2 = unserialize($side_nav2_p);}-->
			<!--{if $side_nav2['text']}-->
			<li><a href="{$side_nav2['url']}"><img src="{$side_nav2['pic']}" alt="{$side_nav2['text']}"/>{$side_nav2['text']}</a></li>
			<!--{/if}-->
		<!--{else}-->
			<li><a href="forum.php?forumlist=1"><i class="iconfont icon-luntan-off"></i>��̳���</a></li>
		<!--{/if}-->
		
		<!--{if $side_nav3_p}-->
			<!--{eval $side_nav3 = unserialize($side_nav3_p);}-->
			<!--{if $side_nav3['text']}-->
			<li><a href="{$side_nav3['url']}"><img src="{$side_nav3['pic']}" alt="{$side_nav3['text']}"/>{$side_nav3['text']}</a></li>
			<!--{/if}-->
		<!--{else}-->
			<li><a href="search.php?mod=forum"><i class="iconfont icon-sousuo"></i>վ������</a></li>
		<!--{/if}-->
		
		<!--{if $side_nav4_p}-->
			<!--{eval $side_nav4 = unserialize($side_nav4_p);}-->
			<!--{if $side_nav4['text']}-->
			<li><a href="{$side_nav4['url']}"><img src="{$side_nav4['pic']}" alt="{$side_nav4['text']}"/>{$side_nav4['text']}</a></li>
			<!--{/if}-->
		<!--{else}-->
			<li><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" onclick="return landingPrompt();"><i class="iconfont icon-wode"></i>��������</a></li>
		<!--{/if}-->
		
		<!--{if $side_nav5_p}-->
			<!--{eval $side_nav5 = unserialize($side_nav5_p);}-->
			<!--{if $side_nav5['text']}-->
			<li><a href="{$side_nav5['url']}"><img src="{$side_nav5['pic']}" alt="{$side_nav5['text']}"/>{$side_nav5['text']}</a></li>
			<!--{/if}-->
		<!--{else}-->
			<li><a href="home.php?mod=space&do=pm" onclick="return landingPrompt();" style="position:relative;"><i class="iconfont icon-xiaoxi"></i><!--{if $_G[member][newpm]}--><img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/><!--{/if}-->�ҵ���Ϣ</a></li>
		<!--{/if}-->
		
		<!--{if $side_nav6_p}-->
			<!--{eval $side_nav6 = unserialize($side_nav6_p);}-->
			<!--{if $side_nav6['text']}-->
			<li><a href="{$side_nav6['url']}"><img src="{$side_nav6['pic']}" alt="{$side_nav6['text']}"/>{$side_nav6['text']}</a></li>
			<!--{/if}-->
		<!--{else}-->
			<li><a href="home.php?mod=space&do=notice&view=mypost" onclick="return landingPrompt();" style="position:relative;"><i class="iconfont icon-tixing"></i><!--{if $post_notice_new}--><img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/><!--{/if}-->��������</a></li>
		<!--{/if}-->
		
		<!--{if $side_nav7_p}-->
			<!--{eval $side_nav7 = unserialize($side_nav7_p);}-->
			<!--{if $side_nav7['text']}-->
			<li><a href="{$side_nav7['url']}"><img src="{$side_nav7['pic']}" alt="{$side_nav7['text']}"/>{$side_nav7['text']}</a></li>
			<!--{/if}-->
		<!--{else}-->
			<li><a href="forum.php?mod=misc&action=nav"><i class="iconfont icon-fatie"></i>��������</a></li>
		<!--{/if}-->
		
		<!--{if $side_nav8_p}-->
			<!--{eval $side_nav8 = unserialize($side_nav8_p);}-->
			<!--{if $side_nav8['text']}-->
			<li><a href="{$side_nav8['url']}"><img src="{$side_nav8['pic']}" alt="{$side_nav8['text']}"/>{$side_nav8['text']}</a></li>
			<!--{/if}-->
		<!--{else}-->
			<li><a href="{$_G['setting']['mobile']['nomobileurl']}"><i class="iconfont icon-diannao"></i>�����԰�</a></li>
		<!--{/if}-->
		
	</ul>
</div>
<div class="sidenav_overlay"></div>
<script type="text/javascript">
	jQuery(".header_z,.scrolltop_side,.post_sidenav").click(function(){jQuery(".byg_sidenav,.sidenav_overlay").addClass("show");});
	jQuery(".header_z,.scrolltop_side,.post_sidenav").click(function(){jQuery("html").addClass("cover_overflow");});
	jQuery(".sidenav_overlay").click(function(){jQuery(".byg_sidenav,.sidenav_overlay").removeClass("show");});
	jQuery(".sidenav_overlay").click(function(){jQuery("html").removeClass("cover_overflow");});
</script>
<!--����ർ����������-->

<div class="cover_top" style="z-index:98;"></div>
<div class="landingPrompt">
	<p>����δ��¼��������¼��</p>
	<div>
		<a href="member.php?mod=logging&action=login" class="landing_on">ȷ��</a>
		<a href="javascript:;" class="landing_off">ȡ��</a>
	</div>
</div>
<script type="text/javascript">
	function landingPrompt(data) {
		if(data == 1 && <!--{if $_G['group']['allowpost']}-->true<!--{else}-->false<!--{/if}-->) {
			return true;
		} else if(data == 2 && <!--{if $allowpostreply}-->true<!--{else}-->false<!--{/if}-->) {
			return true;
		} else {
			if($_G[uid]) {
				return true;
			} else {
				jQuery(".cover_top").slideToggle(0);
				jQuery(".landingPrompt").slideToggle(500);
				return false;
			}
		}
	}
	jQuery(".cover_top,.landing_off").click(function(){jQuery(".cover_top,.landingPrompt").slideToggle(0);});	
</script>

<script type="text/javascript" src="{$_G['style']['styleimgdir']}/header.js"></script>

<!--{if CURSCRIPT == 'portal' && CURMODULE == 'index'}-->
	<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/lanjiazai.js"></script>
	<script type="text/javascript">
		jQuery(".lanjiazai").lazyload({
			effect:"fadeIn",
			threshold: 1100,
		});
	</script>
	<!--{if $slide}-->
	<script type="text/javascript">
		var sj_slide = new Swiper('.sj_slide_bd', {
			loop : true,
			speed: 800,
			autoplay: {
			<!--{if count($slide) < 2}-->
				delay: 3600000,
			<!--{else}-->
				delay: 4000,
			<!--{/if}-->
				disableOnInteraction: false,
			},
			pagination: {
				el: '.sj_slide_hd',
				clickable :true,
				bulletElement : 'li',
			},
			lazy: {
				loadPrevNext: true,
			},
		});
	</script>
	<!--{/if}-->
	<div class="block_update">
		<script type="text/javascript">
			function runslideshow(){}
		</script>
		<!--{eval include_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/footer.php');}-->
		<!--{if $block_update_bid}-->
		<div style="display:none;">
			<script type="text/javascript" src="api.php?mod=js&bid={$block_update_bid}"></script>
		</div>
		<!--{/if}-->
		<script type="text/javascript">
			jQuery(".block_update").html("");
		</script>
	</div>
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/byg_into.js"></script>
<!--{/if}-->

<!--{if CURSCRIPT == 'forum' && CURMODULE == 'index'}-->
	<!--{if $forum_gg1 || $forum_gg2 || $forum_gg3}-->
	<!--{eval}-->
		$forum_gg_num = 0;
		if($forum_gg1){ $forum_gg_num++;}
		if($forum_gg2){ $forum_gg_num++;}
		if($forum_gg3){ $forum_gg_num++;}
	<!--{/eval}-->
	<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/swiper.min.css">
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/swiper.jquery.min.js"></script>
	<script type="text/javascript">
		var forum_gg_sl_bd = new Swiper('.forum_gg_sl_bd', {
			loop : true,
			speed: 800,
			autoplay: {
			<!--{if $forum_gg_num < 2}-->
				delay: 3600000,
			<!--{else}-->
				delay: 3000,
			<!--{/if}-->
				disableOnInteraction: false,
			},
		});
	</script>
	<!--{/if}-->
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/byg_into.js"></script>
<!--{/if}-->

<!--{if !$_G['setting']['bbclosed'] && !$_G['member']['freeze'] && !$_G['member']['groupexpiry']}-->
	<!--{if $_G[uid] && !isset($_G['cookie']['checkpm'])}-->
	<script type="text/javascript" src="home.php?mod=spacecp&ac=pm&op=checknewpm&rand=$_G[timestamp]"></script>
	<!--{/if}-->
	<!--{if $_G[uid] && helper_access::check_module('follow') && !isset($_G['cookie']['checkfollow'])}-->
	<script type="text/javascript" src="home.php?mod=spacecp&ac=follow&op=checkfeed&rand=$_G[timestamp]"></script>
	<!--{/if}-->
	<!--{if !isset($_G['cookie']['sendmail'])}-->
	<script type="text/javascript" src="home.php?mod=misc&ac=sendmail&rand=$_G[timestamp]"></script>
	<!--{/if}-->
	<!--{if $_G[uid] && $_G['member']['allowadmincp'] == 1 && !isset($_G['cookie']['checkpatch'])}-->
	<script type="text/javascript" src="misc.php?mod=patch&action=checkpatch&rand=$_G[timestamp]"></script>
	<!--{/if}-->
<!--{/if}-->

<!--{/if}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval include_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/footer_url.php');}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->
