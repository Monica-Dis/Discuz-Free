<?php echo 'From: DisM.taobao.com';exit;?>

<div class="byg_reward">
	<div class="byg_reward_t">
		{lang thread_reward}<strong>{$rewardprice}</strong>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
		{if $_G['forum_thread']['price'] > 0}<span class="xi1">({lang unresolved})</span>{elseif $_G['forum_thread']['price'] < 0}<span class="xi1">({lang resolved})</span>{/if}
	</div>
	<!--{if $_G['forum_thread']['price'] > 0 && !$_G['forum_thread']['is_archived']}-->
	<div class="byg_reward_b">
		<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" onclick="return landingPrompt();">�����ش�</a>
		<span>���Ļش𱻲��ɺ󽫻��{$rewardprice}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</span>
	</div>
	<!--{/if}-->
</div>
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>

<!--{if $post['attachment']}-->
	<div class="grey byg_quote">{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em></div>
<!--{elseif $post['imagelist'] || $post['attachlist']}-->
    <!--{if $post['imagelist']}-->
         {echo showattach($post, 1)}
    <!--{/if}-->
    <!--{if $post['attachlist']}-->
         {echo showattach($post)}
    <!--{/if}-->
<!--{/if}-->
<!--{eval $post['attachment'] = $post['imagelist'] = $post['attachlist'] = '';}-->

<!--{if $bestpost}-->
	<div class="byg_reward_good">
		<h3 class="psth">{lang reward_bestanswer}</h3>
		<div class="pstl cl">
			<div class="psta">$bestpost[avatar]</div>
			<div class="psti">
				<p class="psti_p">
					<a href="home.php?mod=space&uid=$bestpost[authorid]&do=profile&mobile=2" class="psti_p_z">$bestpost[author]</a>
					<a href="forum.php?mod=redirect&goto=findpost&ptid=$bestpost[tid]&pid=$bestpost[pid]" class="psti_p_y">{lang view_full_content}</a>
				</p>
				<div class="mtn">$bestpost[message]</div>
			</div>
		</div>
	</div>
<!--{/if}-->