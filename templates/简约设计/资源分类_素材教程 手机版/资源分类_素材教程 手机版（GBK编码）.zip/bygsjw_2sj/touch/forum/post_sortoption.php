<?php echo 'From: DisM.taobao.com';exit;?>

<script type="text/javascript">
	var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
</script>
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/threadsort.js?{VERHASH}"></script>

<input type="hidden" name="selectsortid" value="$_G['forum_selectsortid']" />
<table class="tfm">
<!--{if $_G['forum']['threadsorts']['description'][$_G['forum_selectsortid']]}-->
	<tr>
		<th class="">{lang threadtype_description}</th>
		<td colspan="2" class="byg_td1" style="padding:.1rem;">$_G[forum][threadsorts][description][$_G[forum_selectsortid]]</td>
	</tr>
<!--{/if}-->
<!--{if $_G['forum']['threadsorts']['expiration'][$_G['forum_selectsortid']]}-->
	<tr>
		<th class="">{lang threadtype_expiration}</th>
		<td colspan="2" class="byg_td1">
			<div class="ftid">
				<select name="typeexpiration" tabindex="1" id="typeexpiration">
					<option value="259200">{lang three_days}</option>
					<option value="432000">{lang five_days}</option>
					<option value="604800">{lang seven_days}</option>
					<option value="2592000">{lang one_month}</option>
					<option value="7776000">{lang three_months}</option>
					<option value="15552000">{lang half_year}</option>
					<option value="31536000">{lang one_year}</option>
				</select>
			</div>
			<!--{if $_G['forum_optiondata']['expiration']}-->{lang valid_before}: $_G[forum_optiondata][expiration]<!--{/if}-->
		</td>
	</tr>
<!--{/if}-->

<!--{loop $_G['forum_optionlist'] $optionid $option}-->
	<tr>
		<th class="">$option[title]<!--{if $option['required']}--><div style="color:#ff6600;font-size:.12rem;">*(����)</div><!--{/if}--></th>
		<td class="byg_td1">
			<div id="select_$option[identifier]">
			<!--{if in_array($option['type'], array('number', 'text', 'email', 'calendar', 'image', 'url', 'range', 'upload', 'range'))}-->
				<!--{if $option['type'] == 'calendar'}-->
				<script type="text/javascript" src="{$_G['style']['styleimgdir']}/date.js?{VERHASH}"></script>
				<input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" value="$option[value]" $option[unchangeable] class="byg_date input_text"/>
				<script type="text/javascript">
					new Rolldate({
						el: '#typeoption_$option[identifier]',
						format: 'YYYY-MM-DD',
						beginYear: 2000,
						endYear: 2100
					})
				</script>
				<!--{elseif $option['type'] == 'image'}-->
					<!--{if !($option[unchangeable] && $option['value'])}-->
						<div class="post_sort_img_btn">
                            <div id="psi_btn" class="psi_btn"><!--{if $option['value']}-->{lang update}ͼƬ<!--{else}-->{lang upload}ͼƬ<!--{/if}--></div>
                            <input type="file" id="sortfile_{$option[identifier]}" class="psi_ipt" />
                        </div>
						<input type="hidden" name="typeoption[{$option[identifier]}][aid]" value="$option[value][aid]" id="sortaid_{$option[identifier]}" />
						<input type="hidden" name="sortaid_{$option[identifier]}_url" id="sortaid_{$option[identifier]}_url" />
						<!--{if $option[value]}--><input type="hidden" name="oldsortaid[{$option[identifier]}]" value="$option[value][aid]" tabindex="1" /><!--{/if}-->
						<input type="hidden" name="typeoption[{$option[identifier]}][url]" id="sortattachurl_{$option[identifier]}" {if $option[value][url]}value="$option[value][url]"{/if} tabindex="1" />
					<!--{/if}-->
					<div id="sortattach_image_{$option[identifier]}" class="post_sort_img">
					<!--{if $option['value']['url']}-->
						<img src="$option[value][url]" alt="" />
					<!--{/if}-->
					</div>
					<script type="text/javascript">
						jQuery(document).on('change', '#sortfile_{$option[identifier]}', function() {
							popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
							
							uploadsuccess = function(data) {
								if(data == '') {
									popup.open('{lang uploadpicfailed}', 'alert');
								}
								var dataarr = data.split('|');
								if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
									popup.close();
									jQuery('#sortaid_{$option[identifier]}').val(dataarr[3]);
									jQuery('#sortaid_{$option[identifier]}_url').val(dataarr[5]);
									jQuery('#sortattachurl_{$option[identifier]}').val('{$_G[setting][attachurl]}forum/' + dataarr[5]);
									jQuery('.post_sort_img').html('<img src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'"/>');
									byg_id('psi_btn').innerHTML = '{lang update}ͼƬ';
								} else {
									var sizelimit = '';
									if(dataarr[7] == 'ban') {
										sizelimit = '{lang uploadpicatttypeban}';
									} else if(dataarr[7] == 'perday') {
										sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
									} else if(dataarr[7] > 0) {
										sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
									}
									popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
									return false;
								}
							};
							
							if(typeof FileReader != 'undefined' && this.files[0]) {//note ֧��html5�ϴ�������
								$.buildfileupload({
									uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
									files:this.files,
									uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
									uploadinputname:'Filedata',
									maxfilesize:"$swfconfig[max]",
									success:uploadsuccess,
									error:function() {
										popup.open('{lang uploadpicfailed}', 'alert');
									}
								});
							} else {
								$.ajaxfileupload({
									url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
									data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
									dataType:'text',
									fileElementId:'filedata',
									success:uploadsuccess,
									error: function() {
										popup.open('{lang uploadpicfailed}', 'alert');
									}
								});
							}
						});
					</script>
				<!--{else}-->
				<input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="input_text" tabindex="1" size="$option[inputsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]'{if $option[maxnum]}, '$option[maxnum]'{else}, '0'{/if}{if $option[minnum]}, '$option[minnum]'{else}, '0'{/if}{if $option[maxlength]}, '$option[maxlength]'{/if})" value="{if $_G['tid']}$option[value]{else}{if $member_profile[$option['profile']]}$member_profile[$option['profile']]{else}$option['defaultvalue']{/if}{/if}" $option[unchangeable] />
				<!--{/if}-->
			<!--{elseif in_array($option['type'], array('radio', 'checkbox', 'select'))}-->
				<!--{if $option[type] == 'select'}-->
					<!--{loop $option['value'] $selectedkey $selectedvalue}-->
						<!--{if $selectedkey}-->
				<script type="text/javascript">
								changeselectthreadsort('$selectedkey', $optionid, 'update');
							</script>
						<!--{else}-->
							<select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable] class="ps">
								<option value="0">{lang please_select}</option>
								<!--{loop $option['choices'] $id $value}-->
									<!--{if !$value[foptionid]}-->
									<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
									<!--{/if}-->
								<!--{/loop}-->
							</select>
						<!--{/if}-->
					<!--{/loop}-->
					<!--{if !is_array($option['value'])}-->
						<select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable] class="ps">
							<option value="0">{lang please_select}</option>
							<!--{loop $option['choices'] $id $value}-->
								<!--{if !$value[foptionid]}-->
								<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
								<!--{/if}-->
							<!--{/loop}-->
						</select>
					<!--{/if}-->
				<!--{elseif $option['type'] == 'radio'}-->
				<ul class="input_radio_box">
					<!--{loop $option['choices'] $id $value}-->
						<li><label><input type="radio" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="pr" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id] $option[unchangeable] class="pr">$value</label></li>
					<!--{/loop}-->
					</ul>
				<!--{elseif $option['type'] == 'checkbox'}-->
				<ul class="input_radio_box">
					<!--{loop $option['choices'] $id $value}-->
						<li><label><input type="checkbox" name="typeoption[{$option[identifier]}][]" id="typeoption_$option[identifier]" class="pc" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id][$id] $option[unchangeable] class="pc">$value</label></li>
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
			<!--{elseif in_array($option['type'], array('textarea'))}-->
				<div class="input_textarea_box">
					<textarea name="typeoption[{$option[identifier]}]" tabindex="1" id="typeoption_$option[identifier]" rows="$option[rowsize]" cols="$option[colsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]', 0, 0{if $option[maxlength]}, '$option[maxlength]'{/if})" $option[unchangeable] class="input_textarea">$option[value]</textarea>
				</div>
			<!--{/if}-->
			</div>
		</td>
		<td class="byg_td2">
			<div>{$option[unit]}</div>
			<!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
				<div class="">
				<!--{if $option['maxnum']}-->
					{lang maxnum} $option[maxnum]&nbsp;
				<!--{/if}-->
				<!--{if $option['minnum']}-->
					{lang minnum} $option[minnum]&nbsp;
				<!--{/if}-->
				<!--{if $option['maxlength']}-->
					{lang maxlength} $option[maxlength]&nbsp;
				<!--{/if}-->
				<!--{if $option['unchangeable']}-->
					{lang unchangeable}&nbsp;
				<!--{/if}-->
				<!--{if $option[description]}-->
					$option[description]
				<!--{/if}-->
				</div>
			<!--{/if}-->
			<span id="check{$option[identifier]}" style="color:#ff9900;font-size:.12rem;"></span>
		</td>
	</tr>
<!--{/loop}-->
</table>

<script type="text/javascript" reload="1">
	var CHECKALLSORT = false;

	function warning(obj, msg) {
		obj.style.display = '';
		obj.innerHTML = '<img src="{IMGDIR}/check_error.gif" width="16" height="16" class="vm" /> ' + msg;
		obj.className = "warning";
		if(CHECKALLSORT) {
			popup.open(msg, 'alert');
		}
	}

	function validateextra() {
		CHECKALLSORT = true;
		<!--{loop $_G['forum_optionlist'] $optionid $option}-->
			if(!checkoption('$option[identifier]', '$option[required]', '$option[type]')) {
				return false;
			}
		<!--{/loop}-->
		return true;
	}
</script>
