<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template touch/common/header}-->
<!--{eval require_once(DISCUZ_ROOT.'./template/bygsjw_2sj/touch/php/forum_post_forumselect.php');}-->

<!-- header start -->
<header class="header_xin">
	<div class="hdc_xin cl" id="byg_header"> 
		<a href="javascript:;" class="header_z">
			<img src="{$_G['style']['styleimgdir']}/tou_caidan.png" alt="�˵�"/>
			<!--{if $_G[member][newpm] || $post_notice_new}-->
			<img src="{$_G['style']['styleimgdir']}/new_pm.png" alt="����" class="new_pm"/>
			<!--{/if}-->
		</a>
		<div class="header_c">
			<span class="header_font">��ѡ���鷢��</span>
		</div>
		<a href="javascript:;" onclick="history.go(-1)" title="������һҳ" class="header_y">
		<img src="{$_G['style']['styleimgdir']}/tou_fanhui.png" alt="����"/></a>
	</div>
</header>
<!--{hook/global_header_mobile}-->
<!-- header end -->

<div style="display: none">
	<ul id="fs_group">$grouplist</ul>
	<ul id="fs_forum_common">$commonlist</ul>
	<!--{loop $forumlist $forumid $forum}-->
		<ul id="fs_forum_$forumid">$forum</ul>
		<!--{eval $fs_forum_all = byg_post_forum_all($forumid);}-->
		<!--{loop $fs_forum_all $f_f_a}-->
			<!--{eval $fs_forum_icon = byg_post_forum_icon($f_f_a[fid]);}-->
			<!--{if $fs_forum_icon}-->
				<div id="fs_forum_icon_{$f_f_a[fid]}"><!--{if preg_match("/^http(s)?:\\/\\/.+/",$fs_forum_icon)}-->{$fs_forum_icon}<!--{else}-->{$_G['setting']['attachurl']}common/{$fs_forum_icon}<!--{/if}--></div>
			<!--{/if}-->
		<!--{/loop}-->
	<!--{/loop}-->
	<!--{loop $subforumlist $forumid $forum}-->
		<ul id="fs_subforum_$forumid">$forum</ul>
		<!--{eval $fs_subforum_all = byg_post_forum_all($forumid);}-->
		<!--{loop $fs_subforum_all $f_sf_a}-->
			<!--{eval $fs_subforum_icon = byg_post_forum_icon($f_sf_a[fid]);}-->
			<!--{if $fs_subforum_icon}-->
				<div id="fs_subforum_icon_{$f_sf_a[fid]}"><!--{if preg_match("/^http(s)?:\\/\\/.+/",$fs_subforum_icon)}-->{$fs_subforum_icon}<!--{else}-->{$_G['setting']['attachurl']}common/{$fs_subforum_icon}<!--{/if}--></div>
			<!--{/if}-->
		<!--{/loop}-->
	<!--{/loop}-->
</div>

<div class="fast_post">
	<ul class="cl">
		<li id="block_group"></li>
		<li id="block_forum"></li>
	</ul>
</div>

<script type="text/javascript">
	var s_gid = '';
	var lis = document.getElementById('fs_group').getElementsByTagName('LI');
	var lastswitchobj = null;
	
	for(i = 0;i < lis.length;i++) {
		var gid = lis[i].getAttribute('fid');
		if(document.getElementById('fs_forum_' + gid)) {
			s_gid += '<p><a href="javascript:;" onclick="switchforums(this, 1, ' + gid + ')" id="post_gid_' + gid + '" class="over_one">' + lis[i].innerHTML + '</a></p>';
		}
	}
	document.getElementById('block_group').innerHTML = s_gid;
	
	for(i = 0;i < 1;i++) {
		var gid1 = lis[i].getAttribute('fid');
		switchforums(document.getElementById('post_gid_' + gid1), 1, gid1);
	}

	function switchforums(obj, block, fid) {
		var s_fid = '';
		var lis = document.getElementById('fs_forum_' + fid).getElementsByTagName('LI');
		var fs_forum_icon;
		var fs_subforum_icon;
		var lis_sub;
		var fid_sub;
		
		if(lastswitchobj != obj) {
			if(lastswitchobj) {
				lastswitchobj.parentNode.className = '';
			}
			obj.parentNode.className = 'pbls';
		}
		
		for(i = 0;i < lis.length;i++) {
			fid = lis[i].getAttribute('fid');
			fs_forum_icon = document.getElementById('fs_forum_icon_' + fid) ? document.getElementById('fs_forum_icon_' + fid).innerHTML : '{$_G['style']['styleimgdir']}/forum.png';
			
			if(fid != '') {
				s_fid += '<p><a href="forum.php?mod=post&action=newthread&fid=' + fid + '" onclick="return landingPrompt(1);"><img src="'+ fs_forum_icon +'" alt="' + lis[i].innerHTML + '"/></a><a href="forum.php?mod=post&action=newthread&fid=' + fid + '" onclick="return landingPrompt(1);" class="over_one">' + lis[i].innerHTML + '</a></p>';
				
				if(document.getElementById('fs_subforum_' + fid)) {
					lis_sub = document.getElementById('fs_subforum_' + fid).getElementsByTagName('LI');
					for(i1 = 0;i1 < lis_sub.length;i1++) {
						fid_sub = lis_sub[i1].getAttribute('fid');
						fs_subforum_icon = document.getElementById('fs_subforum_icon_' + fid_sub) ? document.getElementById('fs_subforum_icon_' + fid_sub).innerHTML : '{$_G['style']['styleimgdir']}/forum.png';
						
						s_fid += '<p class="fast_post_subforum"><a href="forum.php?mod=post&action=newthread&fid=' + fid_sub + '" onclick="return landingPrompt(1);"><img src="'+ fs_subforum_icon +'" alt="' + lis_sub[i1].innerHTML + '"/></a><a href="forum.php?mod=post&action=newthread&fid=' + fid_sub + '" onclick="return landingPrompt(1);" class="over_one">' + lis_sub[i1].innerHTML + '</a></p>';
					}
				}
			}
		}
		document.getElementById('block_forum').innerHTML = s_fid;
		lastswitchobj = obj;
	}
</script>

<!--{template touch/common/footer}-->
