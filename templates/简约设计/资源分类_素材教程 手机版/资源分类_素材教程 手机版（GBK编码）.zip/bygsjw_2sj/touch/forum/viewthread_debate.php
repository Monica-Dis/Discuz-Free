<?php echo 'From: DisM.taobao.com';exit;?>

<div class="byg_debate">
    <div class="byg_debate_t">
        <strong>{lang debate_square_point} ($debate[affirmvotes]) ({lang debater}:$debate[affirmdebaters]) </strong>
        <p class="xg2">$debate[affirmpoint]</p>
        <p><!--{if !$_G['forum_thread']['is_archived']}-->
			<a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" id="affirmbutton" >{lang debate_support}{lang debate_square_point}</a><!--{/if}--></p>
    </div>
    <div class="byg_debate_c">
        <strong>{lang debate_opponent_point} ($debate[negavotes]) ({lang debater}:$debate[negadebaters])</strong>
        <p class="xg2">$debate[negapoint]</p>
        <p><a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" id="negabutton" >{lang debate_support}{lang debate_opponent_point}</a></p>
    </div>
    <div class="byg_debate_b">
	<!--{if $debate[endtime]}-->
		<p>{lang endtime}: $debate[endtime] <!--{if $debate[umpire]}-->{lang debate_umpire}: $debate[umpire]<!--{/if}--></p>
	<!--{/if}-->

	<!--{if $debate[umpire] && $_G['username'] && $debate[umpire] == $_G['member']['username']}-->
		<p class="mtn">
		<!--{if $debate[remaintime] && !$debate[umpirepoint]}-->
		 <a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" >{lang debate_umpire_end}</a>
		<!--{elseif TIMESTAMP - $debate['dbendtime'] < 3600}-->
		 <a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" >{lang debate_umpirepoint_edit}</a>
		<!--{/if}-->
		</p>
	<!--{/if}-->
	</div>
</div>

<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>

<!--{if $debate[umpire]}-->
	<!--{if $debate['umpirepoint']}-->
	<div class="byg_debate_result">
		<div class="byg_debate_result_t">
			<!--{if $debate[winner]}-->
				<!--{if $debate[winner] == 1}-->
				<label><strong>{lang debate_square}{lang debate_winner}</strong></label>
				<!--{elseif $debate[winner] == 2}-->
				<label><strong>{lang debate_opponent}{lang debate_winner}</strong></label>
				<!--{else}-->
				<label><strong>{lang debate_draw}</strong></label>
				<!--{/if}-->
			<!--{/if}-->
			<em>{lang debate_comment_dateline}: $debate[endtime]</em>
		</div>
		<!--{if $debate[umpirepoint]}--><p><strong>{lang debate_umpirepoint}</strong>: $debate[umpirepoint]</p><!--{/if}-->
		<!--{if $debate[bestdebater]}--><p><strong>{lang debate_bestdebater}</strong>: $debate[bestdebater]</p><!--{/if}-->
	</div>
	<!--{/if}-->
<!--{/if}-->