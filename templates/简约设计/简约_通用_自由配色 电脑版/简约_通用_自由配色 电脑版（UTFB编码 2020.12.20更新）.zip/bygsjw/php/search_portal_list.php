<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//统计文章图片
function byg_article_img_num($aid, $uid) {
	$img_number = DB::result(DB::query("SELECT count(*) FROM ".DB::table('portal_attachment')." WHERE aid = '$aid' AND isimage = '1'"));
	return $img_number;
}

//获取文章图片
function byg_article_img($aid, $uid, $num) {
	$list_img = DB::fetch_all("SELECT * FROM ".DB::table('portal_attachment')." WHERE aid = '$aid' AND isimage = '1' ORDER BY dateline ASC LIMIT $num");
	return $list_img;
}
//From: Dism_taobao-com
?>
