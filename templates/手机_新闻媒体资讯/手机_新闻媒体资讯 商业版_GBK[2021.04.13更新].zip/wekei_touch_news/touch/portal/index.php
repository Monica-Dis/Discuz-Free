<?php exit; ?>

<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>

<!-- �����������õ� �õ���css��js�ļ� -->
<link href="$_G['style']['styleimgdir']/touch/css/swiper.min.css" rel="stylesheet" />
<script src="$_G['style']['styleimgdir']/touch/css/swiper.min.js?{VERHASH}"></script> 

<!--{eval include TPLDIR.'/php/vk_diy.php';}-->
<!--{eval include TPLDIR.'/php/vk_diy_index.php';}-->




<!--
�������ֵ��� - �����л���ʽ
-->

<!-- ���������̶���ʽ
<div class="swiper-container-nav" id="topNav" style=" display:block; width:100%; height: 50px; position:fixed; top:44; z-index:99; border-top:1px solid #eee; background:#fff;">
-->

<div class="swiper-container-nav" id="topNav">
  <div class="swiper-wrapper">
  		<div class="swiper-slide active"><span>�Ƽ�</span></div>
		<div class="swiper-slide"><span>�Ȱ�</span></div>
		<div class="swiper-slide"><span>�Ƽ�</span></div>
		<div class="swiper-slide"><span>��Ů</span></div>
		<div class="swiper-slide"><span>����</span></div>
		<div class="swiper-slide"><span>����</span></div>
		<div class="swiper-slide"><span>����</span></div>
	</div>
</div>





<!--
�������ֵ��� ��Ӧ��ģ��
-->
<div class="swiper-container-page" id="topNav_page">
	<div class="swiper-wrapper" >
	
	
	
		<!-- ģ��"�Ƽ�"�µ�block���� -->
		<div class="swiper-slide  swiper-slide-active">
		
		

			<div class="vk_wp" style="margin-top: 0px; overflow: hidden;">
            <!--
            [δ���Ƽ�_�ֻ�]����-����ͨ��ģ��-ͼƬ�õ�
            DIYģ�������ͼƬ����Ϊ �� 800 �� 500����Ӧ��ͬ�ߴ���Ļ��
            Ĭ��ȫ��ֱ����ʾ�� #slide_index �����ԣ����ƻõ��Ƿ�ȫ�����ڲ�Բ����ʾ����Ҫ�ڲ�Բ����ʾ������ vk_touch.css ������ #slide_index �����Լ���

            ��Ϊ Ҫ���� swiper.min.css �� swiper.min.js �ļ���Ϊ�˱����޸�·���鷳����js���ô������htm�ļ���
            -->
            <!-- Swiper -->
            <!--{if $vk_slide_index_1_id}-->

                <!--{eval $vk_slide_index_1 = vk_diy_block($vk_slide_index_1_id, 5);}-->
                <!--{if $vk_slide_index_1}-->

                    <div class="swiper-container_slide" id="slide_index">
                        <div class="swiper-wrapper">

                            <!--{loop $vk_slide_index_1 $vk_slide_index_1_this}-->
                            <!--{eval $vk_slide_index_1_this_fields = unserialize($vk_slide_index_1_this[fields]); }-->
                            <!--{eval $vk_slide_index_1_this_style = unserialize($vk_slide_index_1_this[showstyle]); }-->

                                <div class="swiper-slide">
                                    <!--{if $vk_slide_index_1_this[picflag] == 1 }-->
                                    <a href="{$vk_slide_index_1_this[url]}" target="_self" title="{$vk_slide_index_1_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_slide_index_1_this[makethumb] == 1}{$vk_slide_index_1_this[thumbpath]}{else}{$vk_slide_index_1_this[pic]}{/if}"/></a>
                                    <!--{elseif $vk_slide_index_1_this[picflag] == 2}-->
                                    <a href="{$vk_slide_index_1_this[url]}" target="_self" title="{$vk_slide_index_1_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_slide_index_1_this[makethumb] == 1}{$vk_slide_index_1_this[thumbpath]}{else}{$vk_slide_index_1_this[pic]}{/if}"/></a>
                                    <!--{else}-->
                                    <a href="{$vk_slide_index_1_this[url]}" target="_self" title="{$vk_slide_index_1_this[title]}"> <img src="{$vk_slide_index_1_this[pic]}"/></a>
                                    <!--{/if}-->

                                    <h2> <!--{echo cutstr($vk_slide_index_1_this[title], 30,'')}--> </h2>

                                </div>
                            <!--{/loop}-->
                        </div>

                        <!-- Add Pagination -->
                        <div class="swiper-pagination"></div>

                        <!-- Add Arrows -->
                        <!--
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                        -->
                    </div>
                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->


            <!-- Initialize Swiper --> 
            <script>
                var slideSwiper = new Swiper('#slide_index', {
                    pagination: '.swiper-container_slide .swiper-pagination',
                    nextButton: '.swiper-container_slide .swiper-button-next',
                    prevButton: '.swiper-container_slide .swiper-button-prev',
                    paginationClickable: true,
                    spaceBetween: 30,
                    centeredSlides: true,
                    autoplay: 2500,
                    autoplayDisableOnInteraction: false,
                    preventClicks:false,

                });
            </script>
			</div>
			
			

			<!-- ͷ�� ���ô��� -->
            <!--
        
			<div class="vk_wp" style="margin-top: 0px;">
				<div class="vk_diy_news_top">
					<div class="diy_left_icon"></div>
					<div class="diy_right_div">

                    </div>
				</div>
			</div>
			-->
	
			<!-- ����/ͷ�� ���ô��� -->
            <!--
            [δ���Ƽ�_�ֻ�]����-����ͨ��ģ��-JS���������ʾ
            ��Ӧ��DIYģ�����Ե����ڸ�ʽ��Ҫ���ա���-�ա���ʽ��ʾ����Ҫ���ա���-��-�ա�������ʱ���λ
            -->
            <!--{if $vk_li_roll_id}-->

                <!--{eval $vk_li_roll = vk_diy_block($vk_li_roll_id, 10);}-->
                <!--{if $vk_li_roll}-->


                    <div class="vk_diy_news_top vk_wp m_t_0 p_b_10 cl">
					    <div class="diy_left_icon"></div>

                        <div class="diy_right_div">


                            <div class="roll_div">

                                 <ul id="rollBox">

                                    <!--{loop $vk_li_roll $vk_li_roll_this}-->
                                    <!--{eval $vk_li_roll_this_fields = unserialize($vk_li_roll_this[fields]); }-->
                                    <!--{eval $vk_li_roll_this_style = unserialize($vk_li_roll_this[showstyle]); }-->

                                    <li>
                                        <a href="{$vk_li_roll_this[url]}" title="{$vk_li_roll_this[title]}" target="_self" style="color: <!--{if $vk_li_roll_this_style[title_c] }--> {$vk_li_roll_this_style[title_c]} <!--{else}--> {$vk_li_roll_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_roll_this[title], 40,'')}--></a>
                                        <span><!--{echo dgmdate($vk_li_roll_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                                    </li>

                                    <!--{/loop}-->
                                </ul>
                            </div>

                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
            <script type="text/javascript">
                var rollText={
                        go:null,
                        oParentUl:null,
                        oUlH:null,
                        liArr:null,
                        childNode:null,
                        timeout:null,
                        run:function(id,delay){
                                var oLiFirst=this.liArr[0];
                                var liMarTop = oLiFirst.style.marginTop;
                                var liTopNum=parseInt(liMarTop);
                                var c = Math.abs(liTopNum);
                                if(c< parseInt(this.oUlH)){
                                        c++;
                                        oLiFirst.style.marginTop ='-' + c + 'px';
                                }else if(Math.abs(liTopNum)== parseInt(this.oUlH)){
                                        clearInterval(this.go);
                                        this.oParentUl.removeChild(oLiFirst);
                                        this.oParentUl.appendChild(oLiFirst);
                                        this.liArr[this.liArr.length-1].style.marginTop='0px';
                                        this.timeout=setTimeout(function(obj,id,childtags,delay){return function(){obj.start(id,childtags,delay);};}(this,id,this.childNode,delay),delay);
                                }
                        },
                        start:function(id,childtags,delay){
                                this.childNode=childtags;
                                this.oParentUl=document.getElementById(id);
                                this.oUlH=this.oParentUl.currentStyle?this.oParentUl.currentStyle['height']:window.getComputedStyle(this.oParentUl,null)['height'];
                                this.liArr=this.oParentUl.getElementsByTagName(childtags);
                                for(var i=0;i<this.liArr.length;i++){
                                        this.liArr[i].style.cssText +=';margin-top:0;height:'+this.oUlH+';line-height:'+this.oUlH+';display:block; width:100%;';
                                }
                                this.go =setInterval(
                                         function(obj,id,delay){
                                        return function(){obj.run(id,delay)}
                                }(this,id,delay),10);
                                this.oParentUl.onmouseover=function(obj){return function(){clearTimeout(obj.timeout);clearTimeout(obj.go);};}(this);
                                this.oParentUl.onmouseout=function(obj){return function(){obj.go =setInterval(function(obj,id,delay){return function(){obj.run(id,delay)};}(obj,id,delay),10);};}(this);
                        }
                }
                rollText.start('rollBox','li',3000);
                function clone(){};
                clone.prototype= rollText;
            </script>
            
            
            
            

			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_0.jpg" />
					</a>
				</div>
			</div>








			<!-- ����ͼ�� ���� - ����⣬��ͼƬ -->
            <!--
            [δ���Ƽ�_�ֻ�]����ģ��-�������ͼ��240��140
            DIYģ�������ͼƬ����Ϊ �� 240 �� 140
            -->
            <!--{if $vk_li_title_pic_1_id}-->
                <!--{eval $vk_li_title_pic_1 = vk_diy_block($vk_li_title_pic_1_id, 10);}-->
                <!--{if $vk_li_title_pic_1}-->

                    <div class="vk_wp cl">
                        <div class="vk_li_title_pic cl">
                            <ul>

                                <!--{loop $vk_li_title_pic_1 $vk_li_title_pic_1_this}-->
                                <!--{eval $vk_li_title_pic_1_this_fields = unserialize($vk_li_title_pic_1_this[fields]); }-->
                                <!--{eval $vk_li_title_pic_1_this_style = unserialize($vk_li_title_pic_1_this[showstyle]); }-->

                                <li>
                                    <div class="vk_li_title_pic_title left">
                                        <div class="vk_li_title"> <a href="{$vk_li_title_pic_1_this[url]}" title="{$vk_li_title_pic_1_this[title]}" target="_self" style="color: <!--{if $vk_li_title_pic_1_this_style[title_c] }--> {$vk_li_title_pic_1_this_style[title_c]} <!--{else}--> {$vk_li_title_pic_1_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_title_pic_1_this[title], 50,'')}--></a> </div>
                                        <div class="vk_li_info">
                                            <!--{if $vk_li_title_pic_1_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_1_this_fields[authorid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_title_pic_1_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_1_this_fields[uid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <span><!--{echo dgmdate($vk_li_title_pic_1_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                                            <i>{$vk_li_title_pic_1_this_fields[views]} �Ķ�</i>
                                        </div>
                                    </div>

                                    <div class="vk_li_title_pic_pic right">

                                        <!--{if $vk_li_title_pic_1_this[picflag] == 1 }-->
                                        <a href="{$vk_li_title_pic_1_this[url]}" target="_self" title="{$vk_li_title_pic_1_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_title_pic_1_this[makethumb] == 1}{$vk_li_title_pic_1_this[thumbpath]}{else}{$vk_li_title_pic_1_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_title_pic_1_this[picflag] == 2}-->
                                        <a href="{$vk_li_title_pic_1_this[url]}" target="_self" title="{$vk_li_title_pic_1_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_title_pic_1_this[makethumb] == 1}{$vk_li_title_pic_1_this[thumbpath]}{else}{$vk_li_title_pic_1_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_title_pic_1_this[url]}" target="_self" title="{$vk_li_title_pic_1_this[title]}"> <img src="{$vk_li_title_pic_1_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->




			<!-- ͼ�� ���� - �±��⣬��ͼƬ - ������ʾ�������л� -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_rec"><a href="http://t.cn/Aiux1Qh0" target="_blank">�Ƽ�</a></h2>
					<ul>
						<li><a href="http://t.cn/Aiux1Qh0" target="_blank" class="more_rec"> �鿴���� </a></li>
					</ul>
				</div>
				<div class="p_l_15">
                    <!-- Swiper -->
                    <!--{if $vk_slide_index_part_1_id}-->

                        <!--{eval $vk_slide_index_part_1 = vk_diy_block($vk_slide_index_part_1_id, 5);}-->
                        <!--{if $vk_slide_index_part_1}-->

                            <div class="swiper-container-slide-part" id="slide_part">
                                <div class="swiper-wrapper">

                                    <!--{loop $vk_slide_index_part_1 $vk_slide_index_part_1_this}-->
                                    <!--{eval $vk_slide_index_part_1_this_fields = unserialize($vk_slide_index_part_1_this[fields]); }-->
                                    <!--{eval $vk_slide_index_part_1_this_style = unserialize($vk_slide_index_part_1_this[showstyle]); }-->

                                        <div class="swiper-slide">
                                            <!--{if $vk_slide_index_part_1_this[picflag] == 1 }-->
                                            <a href="{$vk_slide_index_part_1_this[url]}" target="_self" title="{$vk_slide_index_part_1_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_slide_index_part_1_this[makethumb] == 1}{$vk_slide_index_part_1_this[thumbpath]}{else}{$vk_slide_index_part_1_this[pic]}{/if}"/></a>
                                            <!--{elseif $vk_slide_index_part_1_this[picflag] == 2}-->
                                            <a href="{$vk_slide_index_part_1_this[url]}" target="_self" title="{$vk_slide_index_part_1_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_slide_index_part_1_this[makethumb] == 1}{$vk_slide_index_part_1_this[thumbpath]}{else}{$vk_slide_index_part_1_this[pic]}{/if}"/></a>
                                            <!--{else}-->
                                            <a href="{$vk_slide_index_part_1_this[url]}" target="_self" title="{$vk_slide_index_part_1_this[title]}"> <img src="{$vk_slide_index_part_1_this[pic]}"/></a>
                                            <!--{/if}-->

                                            <h2> <span> <!--{echo cutstr($vk_slide_index_part_1_this[title], 30,'')}--> </span> </h2>
                                        </div>
                                    <!--{/loop}-->
                                </div>
                            </div>
                        <!--{else}-->
                        <!--{/if}-->

                    <!--{else}-->
                    <!--{/if}-->
                    
                    
                    <!-- Initialize Swiper --> 
                    <script>
                        var slideSwiper = new Swiper('#slide_part', {
                            pagination: '#slide_part .swiper-pagination',
                            slidesPerView: 'auto',
                            spaceBetween: 15,
                            preventClicks:false,
                        });
                    </script>
				</div>
			</div>
			
			

			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_1.jpg" />
					</a>
				</div>
			</div>
			
			

			<!-- ����ͼ�� ���� - ����⣬��ͼƬ - ������� -->
            <!--
            [δ���Ƽ�_�ֻ�]����ģ��-�������ͼ��240��140-������Ϣ-�������
            DIYģ�������ͼƬ����Ϊ �� 240 �� 140
            -->
            <!--{if $vk_li_title_pic_load_id}-->
                <!--{eval $vk_li_title_pic_load = vk_diy_block($vk_li_title_pic_load_id, 100);}-->
                <!--{if $vk_li_title_pic_load}-->

                    <div class="vk_wp cl">
                        <div class="vk_li_title_pic cl">
                            <ul>

                                <!--{loop $vk_li_title_pic_load $vk_li_title_pic_load_this}-->
                                <!--{eval $vk_li_title_pic_load_this_fields = unserialize($vk_li_title_pic_load_this[fields]); }-->
                                <!--{eval $vk_li_title_pic_load_this_style = unserialize($vk_li_title_pic_load_this[showstyle]); }-->

                                <li class="vk_load_list">
                                    <div class="vk_li_title_pic_title left">
                                        <div class="vk_li_title"> <a href="{$vk_li_title_pic_load_this[url]}" title="{$vk_li_title_pic_load_this[title]}" target="_self" style="color: <!--{if $vk_li_title_pic_load_this_style[title_c] }--> {$vk_li_title_pic_load_this_style[title_c]} <!--{else}--> {$vk_li_title_pic_load_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_title_pic_load_this[title], 50,'')}--></a> </div>
                                        <div class="vk_li_info">
                                            <!--{if $vk_li_title_pic_load_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_load_this_fields[authorid]}&do=profile" target="_self"> <span>{$vk_li_title_pic_load_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_title_pic_load_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_load_this_fields[uid]}&do=profile" target="_self"> <span>{$vk_li_title_pic_load_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <span><!--{echo dgmdate($vk_li_title_pic_load_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                                            <i>{$vk_li_title_pic_load_this_fields[views]} �Ķ�</i>
                                        </div>
                                    </div>

                                    <div class="vk_li_title_pic_pic right">

                                        <!--{if $vk_li_title_pic_load_this[picflag] == 1 }-->
                                        <a href="{$vk_li_title_pic_load_this[url]}" target="_self" title="{$vk_li_title_pic_load_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_title_pic_load_this[makethumb] == 1}{$vk_li_title_pic_load_this[thumbpath]}{else}{$vk_li_title_pic_load_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_title_pic_load_this[picflag] == 2}-->
                                        <a href="{$vk_li_title_pic_load_this[url]}" target="_self" title="{$vk_li_title_pic_load_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_title_pic_load_this[makethumb] == 1}{$vk_li_title_pic_load_this[thumbpath]}{else}{$vk_li_title_pic_load_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_title_pic_load_this[url]}" target="_self" title="{$vk_li_title_pic_load_this[title]}"> <img src="{$vk_li_title_pic_load_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>
                                </li>

                                <!--{/loop}-->


                                <div class="vk_load_more">
                                    <a href="javascript:;">�鿴���� ... </a>
                                </div>

                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->

            <!-- ��Ҫ���� jquery.min.js����� head�ļ����ù����˴��ɺ��� -->
            <!--
            <script src="$_G['style']['styleimgdir']/touch/css/jquery.min.js?{VERHASH}"></script>
            -->
            <script type="text/javascript">
                jQuery(function (){
                    showItem(0, 10);
                    var itemNum = 10; 

                    jQuery('.vk_load_more').click(function(){
                        if(itemNum < 100){
                            showItem(itemNum, itemNum += 20);
                        } else {
                            location.href = 'forum.php';
                        }
                    });  	

                    function showItem(fromindex,toindex){
                        var len = jQuery('.vk_load_list').length;
                        for(var i = fromindex; i < toindex ; i++ ){
                            jQuery('.vk_load_list').eq(i).css('display','block');
                        }
                    } 

                })
            </script>
			
			

			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_2.jpg" />
					</a>
				</div>
			</div>

		</div>
		
		
		
		
		
		
		
		
		

		<!-- ģ�顰�Ȱ��µ�block���� -->
		<div class="swiper-slide">    
            
			<!-- ����ͼ�� ���� - �Ȱ� -->
            <!--
            [δ���Ƽ�_�ֻ�]����ģ��-�������ͼ��240��140
            DIYģ�������ͼƬ����Ϊ �� 240 �� 140
            -->
            <!--{if $vk_li_title_pic_1_life_01_id}-->
                <!--{eval $vk_li_title_pic_1_life_01 = vk_diy_block($vk_li_title_pic_1_life_01_id, 10);}-->
                <!--{if $vk_li_title_pic_1_life_01}-->

                    <div class="vk_wp cl">
                        <div class="vk_li_title_pic cl">
                            <ul>

                                <!--{loop $vk_li_title_pic_1_life_01 $vk_li_title_pic_1_life_01_this}-->
                                <!--{eval $vk_li_title_pic_1_life_01_this_fields = unserialize($vk_li_title_pic_1_life_01_this[fields]); }-->
                                <!--{eval $vk_li_title_pic_1_life_01_this_style = unserialize($vk_li_title_pic_1_life_01_this[showstyle]); }-->

                                <li>
                                    <div class="vk_li_title_pic_title left">
                                        <div class="vk_li_title"> <span class="color_{$vk_li_title_pic_1_life_01_this[displayorder]}">No.{$vk_li_title_pic_1_life_01_this[displayorder]}</span> <a href="{$vk_li_title_pic_1_life_01_this[url]}" title="{$vk_li_title_pic_1_life_01_this[title]}" target="_self" style="color: <!--{if $vk_li_title_pic_1_life_01_this_style[title_c] }--> {$vk_li_title_pic_1_life_01_this_style[title_c]} <!--{else}--> {$vk_li_title_pic_1_life_01_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_title_pic_1_life_01_this[title], 50,'')}--></a> </div>
                                        <div class="vk_li_info">
                                            <span><!--{echo dgmdate($vk_li_title_pic_1_life_01_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>

                                            <i>
                                                <!--{if $vk_li_title_pic_1_life_01_this_fields[authorid]}-->
                                                <a href="home.php?mod=space&uid={$vk_li_title_pic_1_life_01_this_fields[authorid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_life_01_this_fields[author]}</span></a>
                                                <!--{elseif $vk_li_title_pic_1_life_01_this_fields[uid]}-->
                                                <a href="home.php?mod=space&uid={$vk_li_title_pic_1_life_01_this_fields[uid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_life_01_this_fields[username]}</span></a>
                                                <!--{else}-->
                                                <a href="javascript:;"> <span> {$_G[setting][anonymoustext]} </span></a>
                                                <!--{/if}-->
                                            </i>
                                        </div>
                                    </div>

                                    <div class="vk_li_title_pic_pic right">

                                        <!--{if $vk_li_title_pic_1_life_01_this[picflag] == 1 }-->
                                        <a href="{$vk_li_title_pic_1_life_01_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_01_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_title_pic_1_life_01_this[makethumb] == 1}{$vk_li_title_pic_1_life_01_this[thumbpath]}{else}{$vk_li_title_pic_1_life_01_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_title_pic_1_life_01_this[picflag] == 2}-->
                                        <a href="{$vk_li_title_pic_1_life_01_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_01_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_title_pic_1_life_01_this[makethumb] == 1}{$vk_li_title_pic_1_life_01_this[thumbpath]}{else}{$vk_li_title_pic_1_life_01_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_title_pic_1_life_01_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_01_this[title]}"> <img src="{$vk_li_title_pic_1_life_01_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>


        
        
        
        
		<!-- ģ�顰�Ƽ����µ�block���� -->
		<div class="swiper-slide">
			<!-- ��/�� -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_8.jpg" />
					</a>
				</div>
			</div>
			<!-- ����ͼ�� ���� - �Ƽ� -->
            <!--
            [δ���Ƽ�_�ֻ�]����ģ��-�������ͼ��240��140
            DIYģ�������ͼƬ����Ϊ �� 240 �� 140
            -->
            <!--{if $vk_li_title_pic_1_life_02_id}-->
                <!--{eval $vk_li_title_pic_1_life_02 = vk_diy_block($vk_li_title_pic_1_life_02_id, 10);}-->
                <!--{if $vk_li_title_pic_1_life_02}-->

                    <div class="vk_wp cl">
                        <div class="vk_li_title_pic cl">
                            <ul>

                                <!--{loop $vk_li_title_pic_1_life_02 $vk_li_title_pic_1_life_02_this}-->
                                <!--{eval $vk_li_title_pic_1_life_02_this_fields = unserialize($vk_li_title_pic_1_life_02_this[fields]); }-->
                                <!--{eval $vk_li_title_pic_1_life_02_this_style = unserialize($vk_li_title_pic_1_life_02_this[showstyle]); }-->

                                <li>
                                    <div class="vk_li_title_pic_title left">
                                        <div class="vk_li_title"> <a href="{$vk_li_title_pic_1_life_02_this[url]}" title="{$vk_li_title_pic_1_life_02_this[title]}" target="_self" style="color: <!--{if $vk_li_title_pic_1_life_02_this_style[title_c] }--> {$vk_li_title_pic_1_life_02_this_style[title_c]} <!--{else}--> {$vk_li_title_pic_1_life_02_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_title_pic_1_life_02_this[title], 50,'')}--></a> </div>
                                        <div class="vk_li_info">
                                            <!--{if $vk_li_title_pic_1_life_02_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_1_life_02_this_fields[authorid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_life_02_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_title_pic_1_life_02_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_1_life_02_this_fields[uid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_life_02_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <span><!--{echo dgmdate($vk_li_title_pic_1_life_02_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                                            <i>{$vk_li_title_pic_1_life_02_this_fields[views]} �Ķ�</i>
                                        </div>
                                    </div>

                                    <div class="vk_li_title_pic_pic right">

                                        <!--{if $vk_li_title_pic_1_life_02_this[picflag] == 1 }-->
                                        <a href="{$vk_li_title_pic_1_life_02_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_02_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_title_pic_1_life_02_this[makethumb] == 1}{$vk_li_title_pic_1_life_02_this[thumbpath]}{else}{$vk_li_title_pic_1_life_02_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_title_pic_1_life_02_this[picflag] == 2}-->
                                        <a href="{$vk_li_title_pic_1_life_02_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_02_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_title_pic_1_life_02_this[makethumb] == 1}{$vk_li_title_pic_1_life_02_this[thumbpath]}{else}{$vk_li_title_pic_1_life_02_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_title_pic_1_life_02_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_02_this[title]}"> <img src="{$vk_li_title_pic_1_life_02_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>
		
        
        
        
        

		<!-- ģ�顰��Ů���µ�block���� -->
		<div class="swiper-slide">
			<div class="wp m_t_0">
			<!-- ����ͼ�� ���� - ��Ů -->
            <!--
            [δ���Ƽ�_�ֻ�]����-����ͨ��ģ��-��ͼ��360��240-�±�������-����
            DIYģ�������ͼƬ����Ϊ �� 360 �� 240
            -->
            <!--{if $vk_li_2_pic_1_life_03_id}-->
                <!--{eval $vk_li_2_pic_1_life_03 = vk_diy_block($vk_li_2_pic_1_life_03_id, 10);}-->
                <!--{if $vk_li_2_pic_1_life_03}-->

                    <div class="wp cl">
                        <div class="vk_li_2_pic_title cl">
                            <ul>

                                <!--{loop $vk_li_2_pic_1_life_03 $vk_li_2_pic_1_life_03_this}-->
                                <!--{eval $vk_li_2_pic_1_life_03_this_fields = unserialize($vk_li_2_pic_1_life_03_this[fields]); }-->
                                <!--{eval $vk_li_2_pic_1_life_03_this_style = unserialize($vk_li_2_pic_1_life_03_this[showstyle]); }-->

                                <li>
                                    <div class="vk_top_img">

                                        <!--{if $vk_li_2_pic_1_life_03_this[picflag] == 1 }-->
                                        <a href="{$vk_li_2_pic_1_life_03_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_03_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_2_pic_1_life_03_this[makethumb] == 1}{$vk_li_2_pic_1_life_03_this[thumbpath]}{else}{$vk_li_2_pic_1_life_03_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_2_pic_1_life_03_this[picflag] == 2}-->
                                        <a href="{$vk_li_2_pic_1_life_03_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_03_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_2_pic_1_life_03_this[makethumb] == 1}{$vk_li_2_pic_1_life_03_this[thumbpath]}{else}{$vk_li_2_pic_1_life_03_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_2_pic_1_life_03_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_03_this[title]}"> <img src="{$vk_li_2_pic_1_life_03_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>

                                    <div class="vk_bottom_div_avt">
                                        <div class="list_title"> <a href="{$vk_li_2_pic_1_life_03_this[url]}" title="{$vk_li_2_pic_1_life_03_this[title]}" target="_self" style="color: <!--{if $vk_li_2_pic_1_life_03_this_style[title_c] }--> {$vk_li_2_pic_1_life_03_this_style[title_c]} <!--{else}--> {$vk_li_2_pic_1_life_03_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_2_pic_1_life_03_this[title], 50,'')}--></a> 
                                        </div>
                                        <div class="list_info">
                                            <!--{if $vk_li_2_pic_1_life_03_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_03_this_fields[authorid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_03_this_fields[authorid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_03_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_2_pic_1_life_03_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_03_this_fields[uid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_03_this_fields[uid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_03_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/touch/img/vk_icon_user.png" /> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <i><!--{echo dgmdate($vk_li_2_pic_1_life_03_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></i>
                                        </div>
                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
			</div>
		</div>
		

        
        
        
        
		<!-- ģ�顰�������µ�block���� -->
		<div class="swiper-slide">
			<!-- ��/�� -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_7.jpg" />
					</a>
				</div>
			</div>
			<!-- ����ͼ�� ���� - ���� -->
            <!--
            [δ���Ƽ�_�ֻ�]����-����ͨ��ģ��-��ͼ��360��240-�±�������-����
            DIYģ�������ͼƬ����Ϊ �� 360 �� 240
            -->
            <!--{if $vk_li_2_pic_1_life_05_id}-->
                <!--{eval $vk_li_2_pic_1_life_05 = vk_diy_block($vk_li_2_pic_1_life_05_id, 10);}-->
                <!--{if $vk_li_2_pic_1_life_05}-->

                    <div class="wp cl">
                        <div class="vk_li_2_pic_title cl">
                            <ul>

                                <!--{loop $vk_li_2_pic_1_life_05 $vk_li_2_pic_1_life_05_this}-->
                                <!--{eval $vk_li_2_pic_1_life_05_this_fields = unserialize($vk_li_2_pic_1_life_05_this[fields]); }-->
                                <!--{eval $vk_li_2_pic_1_life_05_this_style = unserialize($vk_li_2_pic_1_life_05_this[showstyle]); }-->

                                <li>
                                    <div class="vk_top_img">

                                        <!--{if $vk_li_2_pic_1_life_05_this[picflag] == 1 }-->
                                        <a href="{$vk_li_2_pic_1_life_05_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_05_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_2_pic_1_life_05_this[makethumb] == 1}{$vk_li_2_pic_1_life_05_this[thumbpath]}{else}{$vk_li_2_pic_1_life_05_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_2_pic_1_life_05_this[picflag] == 2}-->
                                        <a href="{$vk_li_2_pic_1_life_05_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_05_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_2_pic_1_life_05_this[makethumb] == 1}{$vk_li_2_pic_1_life_05_this[thumbpath]}{else}{$vk_li_2_pic_1_life_05_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_2_pic_1_life_05_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_05_this[title]}"> <img src="{$vk_li_2_pic_1_life_05_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>

                                    <div class="vk_bottom_div_avt">
                                        <div class="list_title"> <a href="{$vk_li_2_pic_1_life_05_this[url]}" title="{$vk_li_2_pic_1_life_05_this[title]}" target="_self" style="color: <!--{if $vk_li_2_pic_1_life_05_this_style[title_c] }--> {$vk_li_2_pic_1_life_05_this_style[title_c]} <!--{else}--> {$vk_li_2_pic_1_life_05_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_2_pic_1_life_05_this[title], 50,'')}--></a> 
                                        </div>
                                        <div class="list_info">
                                            <!--{if $vk_li_2_pic_1_life_05_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_05_this_fields[authorid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_05_this_fields[authorid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_05_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_2_pic_1_life_05_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_05_this_fields[uid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_05_this_fields[uid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_05_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/touch/img/vk_icon_user.png" /> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <i><!--{echo dgmdate($vk_li_2_pic_1_life_05_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></i>
                                        </div>
                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>
		

        
        
        
		<!-- ģ�顰¥�̡��µ�block���� -->
		<div class="swiper-slide">
			<!-- ��/�� -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_9.jpg" />
					</a>
				</div>
			</div>
			<!-- ����ͼ�� ���� - ¥�� -->
            <!--
            [δ���Ƽ�_�ֻ�]����-����ͨ��ģ��-��ͼ��360��240-�±�������-����
            DIYģ�������ͼƬ����Ϊ �� 360 �� 240
            -->
            <!--{if $vk_li_2_pic_1_life_04_id}-->
                <!--{eval $vk_li_2_pic_1_life_04 = vk_diy_block($vk_li_2_pic_1_life_04_id, 10);}-->
                <!--{if $vk_li_2_pic_1_life_04}-->

                    <div class="wp cl">
                        <div class="vk_li_2_pic_title cl">
                            <ul>

                                <!--{loop $vk_li_2_pic_1_life_04 $vk_li_2_pic_1_life_04_this}-->
                                <!--{eval $vk_li_2_pic_1_life_04_this_fields = unserialize($vk_li_2_pic_1_life_04_this[fields]); }-->
                                <!--{eval $vk_li_2_pic_1_life_04_this_style = unserialize($vk_li_2_pic_1_life_04_this[showstyle]); }-->

                                <li>
                                    <div class="vk_top_img">

                                        <!--{if $vk_li_2_pic_1_life_04_this[picflag] == 1 }-->
                                        <a href="{$vk_li_2_pic_1_life_04_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_04_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_2_pic_1_life_04_this[makethumb] == 1}{$vk_li_2_pic_1_life_04_this[thumbpath]}{else}{$vk_li_2_pic_1_life_04_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_2_pic_1_life_04_this[picflag] == 2}-->
                                        <a href="{$vk_li_2_pic_1_life_04_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_04_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_2_pic_1_life_04_this[makethumb] == 1}{$vk_li_2_pic_1_life_04_this[thumbpath]}{else}{$vk_li_2_pic_1_life_04_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_2_pic_1_life_04_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_04_this[title]}"> <img src="{$vk_li_2_pic_1_life_04_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>

                                    <div class="vk_bottom_div_avt">
                                        <div class="list_title"> <a href="{$vk_li_2_pic_1_life_04_this[url]}" title="{$vk_li_2_pic_1_life_04_this[title]}" target="_self" style="color: <!--{if $vk_li_2_pic_1_life_04_this_style[title_c] }--> {$vk_li_2_pic_1_life_04_this_style[title_c]} <!--{else}--> {$vk_li_2_pic_1_life_04_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_2_pic_1_life_04_this[title], 50,'')}--></a> 
                                        </div>
                                        <div class="list_info">
                                            <!--{if $vk_li_2_pic_1_life_04_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_04_this_fields[authorid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_04_this_fields[authorid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_04_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_2_pic_1_life_04_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_04_this_fields[uid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_04_this_fields[uid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_04_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/touch/img/vk_icon_user.png" /> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <i><!--{echo dgmdate($vk_li_2_pic_1_life_04_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></i>
                                        </div>
                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>


        
        
        
		<!-- ģ�顰���֡��µ�block���� -->
		<div class="swiper-slide">
			<!-- ����ͼ�� ���� - ���� -->
            <!--
            [δ���Ƽ�_�ֻ�]����-����ͨ��ģ��-��ͼ��360��240-�±�������-����
            DIYģ�������ͼƬ����Ϊ �� 360 �� 240
            -->
            <!--{if $vk_li_2_pic_1_life_06_id}-->
                <!--{eval $vk_li_2_pic_1_life_06 = vk_diy_block($vk_li_2_pic_1_life_06_id, 10);}-->
                <!--{if $vk_li_2_pic_1_life_06}-->

                    <div class="wp cl">
                        <div class="vk_li_2_pic_title cl">
                            <ul>

                                <!--{loop $vk_li_2_pic_1_life_06 $vk_li_2_pic_1_life_06_this}-->
                                <!--{eval $vk_li_2_pic_1_life_06_this_fields = unserialize($vk_li_2_pic_1_life_06_this[fields]); }-->
                                <!--{eval $vk_li_2_pic_1_life_06_this_style = unserialize($vk_li_2_pic_1_life_06_this[showstyle]); }-->

                                <li>
                                    <div class="vk_top_img">

                                        <!--{if $vk_li_2_pic_1_life_06_this[picflag] == 1 }-->
                                        <a href="{$vk_li_2_pic_1_life_06_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_06_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_2_pic_1_life_06_this[makethumb] == 1}{$vk_li_2_pic_1_life_06_this[thumbpath]}{else}{$vk_li_2_pic_1_life_06_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_2_pic_1_life_06_this[picflag] == 2}-->
                                        <a href="{$vk_li_2_pic_1_life_06_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_06_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_2_pic_1_life_06_this[makethumb] == 1}{$vk_li_2_pic_1_life_06_this[thumbpath]}{else}{$vk_li_2_pic_1_life_06_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_2_pic_1_life_06_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_06_this[title]}"> <img src="{$vk_li_2_pic_1_life_06_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>

                                    <div class="vk_bottom_div_avt">
                                        <div class="list_title"> <a href="{$vk_li_2_pic_1_life_06_this[url]}" title="{$vk_li_2_pic_1_life_06_this[title]}" target="_self" style="color: <!--{if $vk_li_2_pic_1_life_06_this_style[title_c] }--> {$vk_li_2_pic_1_life_06_this_style[title_c]} <!--{else}--> {$vk_li_2_pic_1_life_06_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_2_pic_1_life_06_this[title], 50,'')}--></a> 
                                        </div>
                                        <div class="list_info">
                                            <!--{if $vk_li_2_pic_1_life_06_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_06_this_fields[authorid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_06_this_fields[authorid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_06_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_2_pic_1_life_06_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_06_this_fields[uid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_06_this_fields[uid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_06_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/touch/img/vk_icon_user.png" /> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <i><!--{echo dgmdate($vk_li_2_pic_1_life_06_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></i>
                                        </div>
                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>

		
		
		

	</div>
</div>





<script type="text/javascript">
var mySwiper = new Swiper('#topNav', {
	freeMode: true,
	freeModeMomentumRatio: 0.5,
	slidesPerView: 'auto',
	roundLengths : true,
});

swiperWidth = mySwiper.container[0].clientWidth
maxTranslate = mySwiper.maxTranslate();
maxWidth = -maxTranslate + swiperWidth / 2

$(".swiper-container").on('touchstart', function(e) {
	e.preventDefault()
})

mySwiper.on('tap', function(swiper, e) {
//    console.log(swiper.clickedIndex)
    pageSwiper.slideTo(swiper.clickedIndex, 1000, false);//��ת
//	e.preventDefault()
	slide = swiper.slides[swiper.clickedIndex]
	slideLeft = slide.offsetLeft
	slideWidth = slide.clientWidth
	slideCenter = slideLeft + slideWidth / 2
    console.log("slideLeft:"+slideLeft)
    console.log("maxWidth:"+maxWidth)
    console.log("slideCenter:"+slideCenter)
	// �����slide�����ĵ�
	mySwiper.setWrapperTransition(300)
	if (slideCenter < swiperWidth / 2) {
		mySwiper.setWrapperTranslate(0)
	} else if (slideCenter > maxWidth) {
		mySwiper.setWrapperTranslate(maxTranslate)
	} else {
		nowTlanslate = slideCenter - swiperWidth / 2
		mySwiper.setWrapperTranslate(-nowTlanslate)
	}
	$("#topNav .active").removeClass('active')
	$("#topNav .swiper-slide").eq(swiper.clickedIndex).addClass('active')

})
</script>



<script>
    var pageSwiper = new Swiper('#topNav_page', {
        paginationClickable: true,
        uniqueNavElements :false,
		roundLengths : true,
        onSlideChangeStart: function(swiper){
//            console.log(swiper.activeIndex)
//            mySwiper.slideTo(swiper.activeIndex, 1000, false);
            $("#topNav .active").removeClass('active')
            $("#topNav .swiper-slide").eq(swiper.activeIndex).addClass('active')

            slide = mySwiper.slides[swiper.activeIndex];//��ȡ��ǰ��slide�ڵ�
            slideLeft = slide.offsetLeft
            slideWidth = slide.clientWidth
            slideCenter = slideLeft + slideWidth / 2
            // �����slide�����ĵ�
            console.log("============")
            console.log("slideLeft:"+slideLeft)
            console.log("maxWidth:"+maxWidth)
            console.log("slideCenter:"+slideCenter)
            console.log("swiperWidth / 2:"+swiperWidth / 2)
            mySwiper.setWrapperTransition(300)
            if (slideCenter < swiperWidth / 2) {
                mySwiper.setWrapperTranslate(0)
            } else if (slideCenter >maxWidth) {
                mySwiper.setWrapperTranslate(maxTranslate)
                console.log("maxTranslate:"+maxTranslate)
            } else {
                nowTlanslate = slideCenter - swiperWidth / 2
                console.log(nowTlanslate)
                mySwiper.setWrapperTranslate(-nowTlanslate)
            }
        }
    });
</script>









<!-- main threadlist start -->
<!-- main threadlist end -->


<div class="pullrefresh" style="display:none;"></div>

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>

<!--{template common/footer}-->

