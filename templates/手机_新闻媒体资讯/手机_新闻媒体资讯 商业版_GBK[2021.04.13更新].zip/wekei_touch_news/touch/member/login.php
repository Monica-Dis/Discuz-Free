<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->


<!--{if !$_GET['infloat']}-->
<!-- header start -->
<div class="vk_login_reg cl">
<!-- header start -->
<div class="login-header">
	<div class="nav">
        <a href="javascript:;" onclick="history.go(-1)" class="z vk_icon_back"></a>
        <span class="name">{lang login}</span>
	</div>
</div>
<!-- header end -->
<!--{/if}-->

{eval $loginhash = 'L'.random(4);}


<!-- userinfo start -->
<div class="loginbox <!--{if $_GET[infloat]}-->login_pop<!--{/if}-->">
	<!--{if $_GET[infloat]}-->
		<h2 class="log_tit"><a href="javascript:;" onclick="popup.close();"><span class="icon_close y">&nbsp;</span></a>{lang login}</h2>
	<!--{/if}-->
		<form id="loginform" method="post" action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
		<input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
		<input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
		<input type="hidden" name="fastloginfield" value="username">
		<input type="hidden" name="cookietime" value="2592000">
		<!--{if $auth}-->
			<input type="hidden" name="auth" value="$auth" />
		<!--{/if}-->
	<div class="login_from">
		<ul>
			<li><input type="text" value="" tabindex="1" size="30" autocomplete="off" value="" name="username" placeholder="{lang inputyourname}" fwin="login" class="vk_login_name"></li>
			<li><input type="password" tabindex="2" size="30" value="" name="password" placeholder="{lang login_password}" fwin="login" class="vk_login_password"></li>
			<li class="questionli">
				<div class="login_select">
				<span class="login-btn-inner">
					<span class="login-btn-text">
						<span class="span_question">{lang security_question}</span>
					</span>
					<span class="icon-arrow">&nbsp;</span>
				</span>
				<select id="questionid_{$loginhash}" name="questionid" class="sel_list">
					<option value="0" selected="selected">{lang security_question}</option>
					<option value="1">{lang security_question_1}</option>
					<option value="2">{lang security_question_2}</option>
					<option value="3">{lang security_question_3}</option>
					<option value="4">{lang security_question_4}</option>
					<option value="5">{lang security_question_5}</option>
					<option value="6">{lang security_question_6}</option>
					<option value="7">{lang security_question_7}</option>
				</select>
				</div>
			</li>
			<li class="bl_none answerli" style="display:none;"><input type="text" name="answer" id="answer_{$loginhash}" placeholder="{lang security_a}"  class="vk_login_answer"></li>
		</ul>
		<!--{if $seccodecheck}-->
		<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
	</div>
	<div class="vk_login cl">
    	<div class="btn_login"><button tabindex="3" value="true" name="submit" type="submit" class="formdialog btn_login">{lang login}</button></div>
        <!--{if $_G['setting']['regstatus']}-->
        	<div class="reg_link cl"><a href="member.php?mod={$_G[setting][regname]}">{echo vk_lang('vk_login_quick_reg')} </a></div>
        <!--{/if}-->
    </div>
	</form>
</div>
<!-- userinfo end -->


	<div class="vk_login_others cl">
    	<div class="login_title cl">
            <div class="line_left"></div>
            <div class="line_title">{echo vk_lang('vk_login_others')}</div>
            <div class="line_right"></div>
        </div>
        <div class="login_icon cl">
		<!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
    	<a href="$_G[connect][login_url]&statfrom=login_simple" class="login_qq"></a>
		<!--{/if}-->


		<!--
		���е������˺ŵ�¼ͼ�����ӣ��ɸ��ݶ�Ӧ�Ĳ��ʵ�������޸ġ�
		�޸ķ�����������a���ӵ� href="javascript:;" �ڵ� javascript:; ��Ϊ�ò���ĵ�¼���ӣ�ͬʱȥ�� onclick="vk_login_alert()" ��δ��롣
		Ȼ���̨����css���� ���ɡ�
		-->
        <a href="plugin.php?id=wechat:login" class="login_weixin" onclick="vk_login_alert()"></a>
        <a href="javascript:;" class="login_weibo" onclick="vk_login_alert()"></a>
        <a href="javascript:;" class="login_phone" onclick="vk_login_alert()"></a>
        </div>
	</div>
	<script>function vk_login_alert() {alert("{echo vk_lang('vk_login_alert')}");}</script>

	<div class="login_hook" style="display:none"><!--{hook/logging_bottom_mobile}--></div>


<!--{if $_G['setting']['pwdsafety']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<!--{/if}-->
<!--{eval updatesession();}-->

<script type="text/javascript">
	(function() {
		$(document).on('change', '.sel_list', function() {
			var obj = $(this);
			$('.span_question').text(obj.find('option:selected').text());
			if(obj.val() == 0) {
				$('.answerli').css('display', 'none');
				$('.questionli').addClass('bl_none');
			} else {
				$('.answerli').css('display', 'block');
				$('.questionli').removeClass('bl_none');
			}
		});
	 })();
</script>

</div>

<!--{template common/footer}-->

