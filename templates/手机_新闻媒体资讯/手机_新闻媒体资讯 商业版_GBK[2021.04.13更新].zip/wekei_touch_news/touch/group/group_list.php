<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>

				<!--{loop $_G['forum_threadlist'] $key $thread}-->
				<!--{if $thread['special'] == 4}-->
					<!--{eval $vk_place = DB::result_first('SELECT place FROM '.DB::table('forum_activity').' WHERE tid ='.$thread[tid].'')}-->
					<!--{eval $vk_type = DB::result_first('SELECT class FROM '.DB::table('forum_activity').' WHERE tid ='.$thread[tid].'')}-->
					<!--{eval $vk_time_start = DB::result_first('SELECT starttimefrom FROM '.DB::table('forum_activity').' WHERE tid ='.$thread[tid].'')}-->
					<!--{eval $vk_time_end = DB::result_first('SELECT starttimeto FROM '.DB::table('forum_activity').' WHERE tid ='.$thread[tid].'')}-->
					<!--{eval $vk_time_now = time()}-->
				<!--{/if}-->

				<li id="$thread[id]">
					<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="normal">
					<p $thread[highlight] class="tit cl">
						<!--{if $thread['digest'] > 0}-->
							<span class="digest">{echo vk_lang('digest')}</span>
						<!--{/if}-->
						<!--{if $thread['special'] == 1}-->
							<span class="vk_thread_type">{lang thread_poll}</span>
						<!--{elseif $thread['special'] == 2}-->
							<span class="vk_thread_type">{lang thread_trade}</span>
						<!--{elseif $thread['special'] == 4}-->
							<!--{if $vk_time_end}-->
								<!--{if $vk_time_end < $vk_time_now}-->
								<span class="vk_thread_type" style="background:#999;">{echo vk_lang('activity_over')}</span>
								<!--{else}-->
								<span class="vk_thread_type">{echo vk_lang('activity_ongoing')}</span>
								<!--{/if}-->
							<!--{else}-->
								<!--{if $vk_time_start < $vk_time_now}-->
								<span class="vk_thread_type" style="background:#999;">{echo vk_lang('activity_over')}</span>
								<!--{else}-->
								<span class="vk_thread_type">{echo vk_lang('activity_ongoing')}</span>
								<!--{/if}-->
							<!--{/if}-->
						<!--{elseif $thread['special'] == 5}-->
							<span class="vk_thread_type">{lang thread_debate}</span>
						<!--{/if}-->
						<!--{if $thread['price'] > 0}-->
							<!--{if $thread['special'] == '3'}-->
							<span class="vk_thread_type">{lang thread_reward}</span>
							<!--{else}-->
							<span class="vk_thread_type">{lang thread_reward}</span>
							<!--{/if}-->
						<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
							<span class="vk_thread_type" style="background:#7b2;">{lang reward_solved}</span>
						<!--{/if}-->
						<!-- �������				
						$thread[typehtml]
						-->						
						{$thread[subject]}
						<!--{if $thread['price'] > 0}-->
						<span class="price">$thread[price]</span>
						<!--{/if}-->

						<!--{if $_G['forum_thread']['recommendlevel']}-->
							<span class="recommend">{lang thread_recommend} $_G['forum_thread'][recommends]</span>
						<!--{/if}-->
						<!--{if $_G['forum_thread'][heatlevel]}-->
							<span class="heats">{lang hot_thread}</span>
						<!--{/if}-->
					</p>
					<!--{eval include(DISCUZ_ROOT."./template/wekei_touch_news/touch/common/group_pic.php");}-->
					$thread['pic']
					<!--{eval include(DISCUZ_ROOT."./template/wekei_touch_news/touch/common/group_summary.php");}-->
					$thread['summary']
					<!--{if $thread['special'] == 4}-->
					<p class="activity cl">
						<!--{if $vk_place}--><span><em>{echo vk_lang('place')} : </em>$vk_place</span><!--{/if}-->
						<!--{if $vk_type}--><span><em>{echo vk_lang('type')}  : </em>$vk_type</span><!--{/if}-->
						<!--{if $vk_time_start}--><span><em>{echo vk_lang('time')}  : </em>{echo dgmdate($vk_time_start)}<!--{if $vk_time_end}--> - {echo dgmdate($vk_time_end)}<!--{/if}--></span><!--{/if}-->
					</p>
					<!--{else}-->
					<p class="auth cl">
						<!--{avatar($thread[authorid], 'middle')}-->
						<span {if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if}>$thread[author]</span>
						<span>&nbsp; &nbsp;$thread[dateline]</span>
						<em>{$thread[replies]} {echo vk_lang('reply')}</em><em>$thread[views] {echo vk_lang('view')}</em>
					</p>
					<!--{/if}-->
					</a>
				</li>
				<div class="cl"></div>
				<!--{/loop}-->

