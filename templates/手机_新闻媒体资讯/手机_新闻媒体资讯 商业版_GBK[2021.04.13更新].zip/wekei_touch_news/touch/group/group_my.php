<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{hook/my_header}-->

<style id="diy_style" type="text/css"></style>

<div id="ct" class="wp cl vk_group_my">

	<div class="mn">
	
		<div class="vk_my_all cl">
			<h2><a href="group.php?mod=index">{lang all_group}&nbsp;&rsaquo;</a></h2>
		</div>
		
	<!--{if $view == 'groupthread' || $view == 'mythread'}-->
	<!--{elseif $view == 'manager' || $view == 'join'}-->
		<!--{if $grouplist}-->
			<div class="bm bml bw0">
				<div class="vk_my_title cl">
					<h2><!--{if $view == 'manager'}-->{lang my_manage_group} <!--{elseif $view == 'join'}-->{lang my_join_group} <!--{/if}--></h2>
				</div>
				<div class="bm_c">
					<ul class="ml mls cl">
						<!--{loop $grouplist $groupid $group}-->
						<li>
							<a href="forum.php?mod=group&fid=$groupid" title="$group[name]" class="avt"><img src="$group[icon]" alt="$group[name]" /></a>
							<p><!--{if $group['flevel'] == '-1'}-->({lang group_wait_mod})<!--{/if}--><a href="forum.php?mod=group&fid=$groupid" title="$group[name]">$group[name]</a></p>
						</li>
						<!--{/loop}-->
					</ul>
				</div>
			</div>
			<!--{if $multipage}--><div class="pgs">$multipage</div><!--{/if}-->
		<!--{else}-->
			<div class="emp"><!--{if $view == 'manager'}-->{lang no_group_create_now} <!--{elseif $view == 'join'}-->{lang no_group_join} <!--{/if}--></div>
		<!--{/if}-->
	<!--{/if}-->
	<!--{hook/my_bottom}-->

	</div>

</div>


<!--{template common/footer}-->
