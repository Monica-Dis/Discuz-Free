/*
        [Discuz!] ajaxlist
*/

(function() {

        var autopbn = $('autopbn');
        var nextpageurl = autopbn.getAttribute('rel').valueOf();
        var curpage = parseInt(autopbn.getAttribute('curpage').valueOf());
        var totalpage = parseInt(autopbn.getAttribute('totalpage').valueOf());
        var picstyle = parseInt(autopbn.getAttribute('picstyle').valueOf());
        var forumdefstyle = parseInt(autopbn.getAttribute('forumdefstyle').valueOf());
        picstyle = picstyle && !forumdefstyle;
        var autopagenum = 0;
        var maxpage = (curpage + autopagenum) > totalpage ? totalpage : (curpage + autopagenum);

        var loadstatus = 0;

        autopbn.onclick = function() {
                var oldloadstatus = loadstatus;
                loadstatus = 2;
                autopbn.innerHTML = '���ڼ���, ���Ժ�...';
                getnextpagecontent();
                loadstatus = oldloadstatus;
        };

        if(autopagenum > 0) {
                window.onscroll = function () {
                        var curtop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
                        if(curtop + document.documentElement.clientHeight + 500 >= document.documentElement.scrollHeight && !loadstatus) {
                                loadstatus = 1;
                                autopbn.innerHTML = '���ڼ���, ���Ժ�...';
                                setTimeout(getnextpagecontent, 1000);
                        }
                };
        }

        function getnextpagecontent() {

                if(curpage + 1 > totalpage) {
                        window.onscroll = null;
                        autopbn.style.display = 'none';
                        return;
                }
                if(loadstatus != 2 && curpage + 1 > maxpage) {
                        autopbn.innerHTML = '��һҳ ?';
                        if(curpage + 1 > maxpage) {
                                window.onscroll = null;
                        }
                        return;
                }
                curpage++;
                var url = nextpageurl + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
                var x = new Ajax('HTML');
                x.get(url, function (s) {
                        s = s.replace(/\n|\r/g, '');
                        if(s.indexOf("id='autopbn'") == -1) {
                                $("autopbn").style.display = "none";
                                window.onscroll = null;
                        }

                        if(!picstyle) {
                                var tableobj = $('article-list');
                                var nexts = s.match(/\<li id="list_(\d+)" class="item"\>(.+?)\<\/li>/g);
                                for(i in nexts) {
                                        if(i == 'index' || i == 'lastIndex') {
                                                continue;
                                        }
                                        var insertid = nexts[i].match(/<li id="list_(\d+)" class="item"\>/);
                                        if(!$('list_' + insertid[1])) {

                                                var newbody = document.createElement('li');
                                                tableobj.appendChild(newbody);
                                                var div = document.createElement('ul');
                                                div.innerHTML = '<ul>' + nexts[i] + '</ul>';
                                                tableobj.replaceChild(div.childNodes[0].childNodes[0], tableobj.lastChild);
                                        }
                                }
                        } else {
                                var nexts = s.match(/\<li style="width:\d+px;" id="picstylethread_(\d+)"\>(.+?)\<\/li\>/g);
                                for(i in nexts) {
                                        var insertid = nexts[i].match(/id="picstylethread_(\d+)"\>/);
                                        if(!$('picstylethread_' + insertid[1])) {
                                                $('threadlist_picstyle').innerHTML += nexts[i];
                                        }
                                }
                        }
                        var pageinfo = s.match(/\<div id="fd_page_bottom"\>(.+?)\<\/div\>/);
                        nextpageurl = nextpageurl.replace(/&page=\d+/, '&page=' + (curpage + 1));

                        $('fd_page_bottom').innerHTML = pageinfo[1];
                        if(curpage + 1 > totalpage) {
                                autopbn.style.display = 'none';
                        } else {
                                autopbn.innerHTML = '��һҳ ?';
                        }
                        loadstatus = 0;
                });
        }

})();
