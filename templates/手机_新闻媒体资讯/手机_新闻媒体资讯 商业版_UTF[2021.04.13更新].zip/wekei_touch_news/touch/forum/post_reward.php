<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="vk_post_reward cl">
	<!--{if $_GET[action] == 'newthread'}-->
    <li class="vk_post_reward_li">
		<div class="vk_post_reward_li_title">{lang reward_price}</div>
		<div class="vk_post_reward_li_ct">
        	<input type="text" name="rewardprice" id="rewardprice" class="px pxs" size="6" onkeyup="getrealprice(this.value)" value="{$_G['group']['minrewardprice']}" tabindex="1" />
        <span>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}				</span>
        </div>
    </li>	
    <div class="vk_post_reward_box">
    	<div class="vk_post_reward_div">
            <p class="vk_post_reward_price">
                {lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
                <!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
                , {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
            </p>
        <!--{elseif $_GET[action] == 'edit'}-->
            <!--{if $isorigauthor}-->
                <!--{if $thread['price'] > 0}-->
                    <label for="rewardprice">{lang reward_price}:</label>
                    <input type="text" name="rewardprice" id="rewardprice" onkeyup="getrealprice(this.value)" size="6" value="$rewardprice" tabindex="1" />
                    {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
                    , {lang reward_tax_add} <strong id="realprice">0</strong> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
                    <p class="mtn xg1">
                        {lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
                        <!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
                        , {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
                    </p>
                <!--{else}-->
                    {lang post_reward_resolved}
                    <input type="hidden" name="rewardprice" value="$rewardprice" tabindex="1" />
                <!--{/if}-->
            <!--{else}-->
                <!--{if $thread['price'] > 0}-->
                    {lang reward_price}: $rewardprice {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
                <!--{else}-->
                    {lang post_reward_resolved}
                <!--{/if}-->
            <!--{/if}-->
        <!--{/if}-->
        </div>
        <!--{if $_G['setting']['rewardexpiration'] > 0}-->
            <p class="vk_post_reward_message">$_G['setting']['rewardexpiration'] {lang post_reward_message}</p>
        <!--{/if}-->
	<!--{hook/post_reward_extra}-->
    </div>
</div>

<script type="text/javascript" reload="1">
function getrealprice(price){
	if(!price.search(/^\d+$/) ) {
		n = Math.ceil(parseInt(price) + price * $_G['setting']['creditstax']);
		if(price > 32767) {
			$('realprice').innerHTML = '<b>{lang reward_price_overflow}</b>';
		}<!--{if $_GET[action] == 'edit'}-->	else if(price < $rewardprice) {
			$('realprice').innerHTML = '<b>{lang reward_cant_fall}</b>';
		}<!--{/if}--> else if(price < $_G['group']['minrewardprice'] || ($_G['group']['maxrewardprice'] > 0 && price > $_G['group']['maxrewardprice'])) {
			$('realprice').innerHTML = '<b>{lang reward_price_bound}</b>';
		} else {
			$('realprice').innerHTML = n;
		}
	}else{
		$('realprice').innerHTML = '<b>{lang input_invalid}</b>';
	}
}
if($('rewardprice')) {
	getrealprice($('rewardprice').value)
}

EXTRAFUNC['validator']['special'] = 'validateextra';
function validateextra() {
	if($('postform').rewardprice && $('postform').rewardprice.value == '') {
		showDialog('{lang post_reward_error_message}', 'alert', '', function () { $('postform').rewardprice.focus() });
		return false;
	}
	return true;
}
</script>