<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<div id="post_new" class="vk_post_new cl"></div>
<div class="vk_post_fast cl">


	<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes&mobile=2">
	
	
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	  
	<div class="vk_post_pi pi cl">
		<!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->
		<div class="vk_post_special">
		<select id="stand" name="stand" >
			<option value="">{lang debate_viewpoint}</option>
			<option value="0">{lang debate_neutral}</option>
			<option value="1">{lang debate_square}</option>
			<option value="2">{lang debate_opponent}</option>
		</select>
		</div>
		<!--{/if}-->
		

		<div class="vk_post_text cl">
        	<textarea type="text" placeholder="{lang send_reply_fast_tip}" value="{lang send_reply_fast_tip}" class="grey vk_post_text_t" color="gray" name="message" id="fastpostmessage">
			</textarea>
        </div>
		
		
		<div class="vk_post_editor" style="display: inline-block;">
			<ul id="imglist" class="vk_icon_post_img_list cl">
				<li class="vk_icon_post_img">
					<a href="javascript:;" class="vk_icon_post_img_a">
						<input type="file" name="Filedata" id="filedata" multiple="multiple" />
					</a>
				</li>
			</ul>
		</div>

        <!--{if $secqaacheck || $seccodecheck}-->
		<div style="padding-left: 10px; margin-bottom: 15px; ">
		<!--{subtemplate common/seccheck}-->
		</div>
		<!--{/if}-->
		
		
        <div class="vk_post_submit">
			<!-- 表情模块 -->
			<a href="javascript:;" class="face" title="表情"></a>
			<div id="fastpostsubmitline" class="post_fast">
				<input type="submit" value="{lang reply}" class="vk_post_submit_btn" name="replysubmit" id="fastpostsubmit">
				<!--{hook/viewthread_fastpost_button_mobile}-->
        	</div>
			<div class="vk_fastpost_bottom_down">{lang cancel}</div>
        </div>
        <div id="Smohan_FaceBox"></div>
	</div>
    </form>
</div>




<!-- 表情js代码 -->
<script src="$_G['style']['styleimgdir']/touch/img/qq/qq.js"></script>
<script>
	$(function (){
		$("a.face").smohanfacebox({
			Event : "click",	//触发事件	
			divid : "Smohan_FaceBox", //外层DIV ID
			textid : "fastpostmessage" //文本框 ID
		});
	});

	$('#Smohan_Showface').click(function(){
		$('#Zones').fadeIn(300);
		$('#Zones').html($('#Smohan_text').val());
		$('#Zones').replaceface($('#Zones').html());
	});
	
</script>



<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="$_G['style']['styleimgdir']/touch/css/buildfileupload.js?{VERHASH}"></script>
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
	var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	var form = $('#postform');
	$(document).on('change', '#filedata', function() {
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

			uploadsuccess = function(data) {
				if(data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
				var dataarr = data.split('|');
				if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
					popup.close();
					$('#imglist').append('<li><span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;"><img style="height:60px;width:60px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
				} else {
					var sizelimit = '';
					if(dataarr[7] == 'ban') {
						sizelimit = '{lang uploadpicatttypeban}';
					} else if(dataarr[7] == 'perday') {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
					} else if(dataarr[7] > 0) {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
					}
					popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
				}
			};

			if(typeof FileReader != 'undefined' && this.files[0]) {//note 支持html5上传新特性
				
				/*
				$.buildfileupload({
				});
				*/
				
				
				
				for (var i=0;i<this.files.length;i++ ) {
					var file_data = [];
					file_data.push(this.files[i]);
					$.buildfileupload({
									uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
						files:file_data,
						uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
						uploadinputname:'Filedata',
                        maxfilesize:"$swfconfig[max]",
						success:uploadsuccess,
						error:function() {
							popup.open('{lang uploadpicfailed}', 'alert');
						}
					 });
				}

			} else {

				$.ajaxfileupload({
					url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
					data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
					dataType:'text',
					fileElementId:'filedata',
					success:uploadsuccess,
					error: function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			}
	});

	<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
	geo.getcurrentposition();
	<!--{/if}-->
	
	$('#postsubmit').on('click', function() {
		var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}

		obj.attr('disable', 'true').removeClass('btn_pn_blue').addClass('btn_pn_grey');
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

		var postlocation = '';
		if(geo.errmsg === '' && geo.loc) {
			postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
		}

		$.ajax({
			type:'POST',
			url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

	$(document).on('click', '.del', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
		})
		
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

</script>



<!-- 未登录时 弹窗提醒 -->
<script type="text/javascript">
	(function() {
		var form = $('#fastpostform');
		<!--{if !$_G[uid] || $_G[uid] && !$allowpostreply}-->
		$('#fastpostmessage').on('focus', function() {
			<!--{if !$_G[uid]}-->
				popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
			<!--{else}-->
				popup.open('{lang nopostreply}', 'alert');
			<!--{/if}-->
			this.blur();
		});
		<!--{else}-->
		<!--{/if}-->

	})();


	function errorhandle_fastpost(message, param) {
		popup.open(message, 'alert');
	}
</script>

