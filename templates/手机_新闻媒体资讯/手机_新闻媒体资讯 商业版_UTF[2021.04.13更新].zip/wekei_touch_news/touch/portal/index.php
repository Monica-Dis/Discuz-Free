<?php exit; ?>

<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>

<!-- 顶部导航、幻灯 用到的css、js文件 -->
<link href="$_G['style']['styleimgdir']/touch/css/swiper.min.css" rel="stylesheet" />
<script src="$_G['style']['styleimgdir']/touch/css/swiper.min.js?{VERHASH}"></script> 

<!--{eval include TPLDIR.'/php/vk_diy.php';}-->
<!--{eval include TPLDIR.'/php/vk_diy_index.php';}-->




<!--
二级文字导航 - 左右切换样式
-->

<!-- 二级导航固定样式
<div class="swiper-container-nav" id="topNav" style=" display:block; width:100%; height: 50px; position:fixed; top:44; z-index:99; border-top:1px solid #eee; background:#fff;">
-->

<div class="swiper-container-nav" id="topNav">
  <div class="swiper-wrapper">
  		<div class="swiper-slide active"><span>推荐</span></div>
		<div class="swiper-slide"><span>热榜</span></div>
		<div class="swiper-slide"><span>科技</span></div>
		<div class="swiper-slide"><span>美女</span></div>
		<div class="swiper-slide"><span>汽车</span></div>
		<div class="swiper-slide"><span>房产</span></div>
		<div class="swiper-slide"><span>娱乐</span></div>
	</div>
</div>





<!--
二级文字导航 对应的模块
-->
<div class="swiper-container-page" id="topNav_page">
	<div class="swiper-wrapper" >
	
	
	
		<!-- 模块"推荐"下的block调用 -->
		<div class="swiper-slide  swiper-slide-active">
		
		

			<div class="vk_wp" style="margin-top: 0px; overflow: hidden;">
            <!--
            [未来科技_手机]文章-帖子通用模块-图片幻灯
            DIY模块属性里：图片设置为 宽 800 高 500，适应不同尺寸屏幕。
            默认全屏直角显示。 #slide_index 的属性，控制幻灯是否全屏或内部圆角显示。若要内部圆角显示，则在 vk_touch.css 内添加 #slide_index 的属性即可

            因为 要引用 swiper.min.css 和 swiper.min.js 文件，为了避免修改路径麻烦，故js引用代码放在htm文件内
            -->
            <!-- Swiper -->
            <!--{if $vk_slide_index_1_id}-->

                <!--{eval $vk_slide_index_1 = vk_diy_block($vk_slide_index_1_id, 5);}-->
                <!--{if $vk_slide_index_1}-->

                    <div class="swiper-container_slide" id="slide_index">
                        <div class="swiper-wrapper">

                            <!--{loop $vk_slide_index_1 $vk_slide_index_1_this}-->
                            <!--{eval $vk_slide_index_1_this_fields = unserialize($vk_slide_index_1_this[fields]); }-->
                            <!--{eval $vk_slide_index_1_this_style = unserialize($vk_slide_index_1_this[showstyle]); }-->

                                <div class="swiper-slide">
                                    <!--{if $vk_slide_index_1_this[picflag] == 1 }-->
                                    <a href="{$vk_slide_index_1_this[url]}" target="_self" title="{$vk_slide_index_1_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_slide_index_1_this[makethumb] == 1}{$vk_slide_index_1_this[thumbpath]}{else}{$vk_slide_index_1_this[pic]}{/if}"/></a>
                                    <!--{elseif $vk_slide_index_1_this[picflag] == 2}-->
                                    <a href="{$vk_slide_index_1_this[url]}" target="_self" title="{$vk_slide_index_1_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_slide_index_1_this[makethumb] == 1}{$vk_slide_index_1_this[thumbpath]}{else}{$vk_slide_index_1_this[pic]}{/if}"/></a>
                                    <!--{else}-->
                                    <a href="{$vk_slide_index_1_this[url]}" target="_self" title="{$vk_slide_index_1_this[title]}"> <img src="{$vk_slide_index_1_this[pic]}"/></a>
                                    <!--{/if}-->

                                    <h2> <!--{echo cutstr($vk_slide_index_1_this[title], 30,'')}--> </h2>

                                </div>
                            <!--{/loop}-->
                        </div>

                        <!-- Add Pagination -->
                        <div class="swiper-pagination"></div>

                        <!-- Add Arrows -->
                        <!--
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                        -->
                    </div>
                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->


            <!-- Initialize Swiper --> 
            <script>
                var slideSwiper = new Swiper('#slide_index', {
                    pagination: '.swiper-container_slide .swiper-pagination',
                    nextButton: '.swiper-container_slide .swiper-button-next',
                    prevButton: '.swiper-container_slide .swiper-button-prev',
                    paginationClickable: true,
                    spaceBetween: 30,
                    centeredSlides: true,
                    autoplay: 2500,
                    autoplayDisableOnInteraction: false,
                    preventClicks:false,

                });
            </script>
			</div>
			
			

			<!-- 头条 调用代码 -->
            <!--
        
			<div class="vk_wp" style="margin-top: 0px;">
				<div class="vk_diy_news_top">
					<div class="diy_left_icon"></div>
					<div class="diy_right_div">

                    </div>
				</div>
			</div>
			-->
	
			<!-- 公告/头条 调用代码 -->
            <!--
            [未来科技_手机]文章-帖子通用模块-JS标题滚动显示
            对应的DIY模块属性的日期格式，要按照“月-日”形式显示，不要按照“年-月-日”，否则时间错位
            -->
            <!--{if $vk_li_roll_id}-->

                <!--{eval $vk_li_roll = vk_diy_block($vk_li_roll_id, 10);}-->
                <!--{if $vk_li_roll}-->


                    <div class="vk_diy_news_top vk_wp m_t_0 p_b_10 cl">
					    <div class="diy_left_icon"></div>

                        <div class="diy_right_div">


                            <div class="roll_div">

                                 <ul id="rollBox">

                                    <!--{loop $vk_li_roll $vk_li_roll_this}-->
                                    <!--{eval $vk_li_roll_this_fields = unserialize($vk_li_roll_this[fields]); }-->
                                    <!--{eval $vk_li_roll_this_style = unserialize($vk_li_roll_this[showstyle]); }-->

                                    <li>
                                        <a href="{$vk_li_roll_this[url]}" title="{$vk_li_roll_this[title]}" target="_self" style="color: <!--{if $vk_li_roll_this_style[title_c] }--> {$vk_li_roll_this_style[title_c]} <!--{else}--> {$vk_li_roll_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_roll_this[title], 40,'')}--></a>
                                        <span><!--{echo dgmdate($vk_li_roll_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                                    </li>

                                    <!--{/loop}-->
                                </ul>
                            </div>

                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
            <script type="text/javascript">
                var rollText={
                        go:null,
                        oParentUl:null,
                        oUlH:null,
                        liArr:null,
                        childNode:null,
                        timeout:null,
                        run:function(id,delay){
                                var oLiFirst=this.liArr[0];
                                var liMarTop = oLiFirst.style.marginTop;
                                var liTopNum=parseInt(liMarTop);
                                var c = Math.abs(liTopNum);
                                if(c< parseInt(this.oUlH)){
                                        c++;
                                        oLiFirst.style.marginTop ='-' + c + 'px';
                                }else if(Math.abs(liTopNum)== parseInt(this.oUlH)){
                                        clearInterval(this.go);
                                        this.oParentUl.removeChild(oLiFirst);
                                        this.oParentUl.appendChild(oLiFirst);
                                        this.liArr[this.liArr.length-1].style.marginTop='0px';
                                        this.timeout=setTimeout(function(obj,id,childtags,delay){return function(){obj.start(id,childtags,delay);};}(this,id,this.childNode,delay),delay);
                                }
                        },
                        start:function(id,childtags,delay){
                                this.childNode=childtags;
                                this.oParentUl=document.getElementById(id);
                                this.oUlH=this.oParentUl.currentStyle?this.oParentUl.currentStyle['height']:window.getComputedStyle(this.oParentUl,null)['height'];
                                this.liArr=this.oParentUl.getElementsByTagName(childtags);
                                for(var i=0;i<this.liArr.length;i++){
                                        this.liArr[i].style.cssText +=';margin-top:0;height:'+this.oUlH+';line-height:'+this.oUlH+';display:block; width:100%;';
                                }
                                this.go =setInterval(
                                         function(obj,id,delay){
                                        return function(){obj.run(id,delay)}
                                }(this,id,delay),10);
                                this.oParentUl.onmouseover=function(obj){return function(){clearTimeout(obj.timeout);clearTimeout(obj.go);};}(this);
                                this.oParentUl.onmouseout=function(obj){return function(){obj.go =setInterval(function(obj,id,delay){return function(){obj.run(id,delay)};}(obj,id,delay),10);};}(this);
                        }
                }
                rollText.start('rollBox','li',3000);
                function clone(){};
                clone.prototype= rollText;
            </script>
            
            
            
            

			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_0.jpg" />
					</a>
				</div>
			</div>








			<!-- 文章图文 调用 - 左标题，右图片 -->
            <!--
            [未来科技_手机]帖子模块-左标题右图宽240高140
            DIY模块属性里：图片设置为 宽 240 高 140
            -->
            <!--{if $vk_li_title_pic_1_id}-->
                <!--{eval $vk_li_title_pic_1 = vk_diy_block($vk_li_title_pic_1_id, 10);}-->
                <!--{if $vk_li_title_pic_1}-->

                    <div class="vk_wp cl">
                        <div class="vk_li_title_pic cl">
                            <ul>

                                <!--{loop $vk_li_title_pic_1 $vk_li_title_pic_1_this}-->
                                <!--{eval $vk_li_title_pic_1_this_fields = unserialize($vk_li_title_pic_1_this[fields]); }-->
                                <!--{eval $vk_li_title_pic_1_this_style = unserialize($vk_li_title_pic_1_this[showstyle]); }-->

                                <li>
                                    <div class="vk_li_title_pic_title left">
                                        <div class="vk_li_title"> <a href="{$vk_li_title_pic_1_this[url]}" title="{$vk_li_title_pic_1_this[title]}" target="_self" style="color: <!--{if $vk_li_title_pic_1_this_style[title_c] }--> {$vk_li_title_pic_1_this_style[title_c]} <!--{else}--> {$vk_li_title_pic_1_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_title_pic_1_this[title], 50,'')}--></a> </div>
                                        <div class="vk_li_info">
                                            <!--{if $vk_li_title_pic_1_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_1_this_fields[authorid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_title_pic_1_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_1_this_fields[uid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <span><!--{echo dgmdate($vk_li_title_pic_1_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                                            <i>{$vk_li_title_pic_1_this_fields[views]} 阅读</i>
                                        </div>
                                    </div>

                                    <div class="vk_li_title_pic_pic right">

                                        <!--{if $vk_li_title_pic_1_this[picflag] == 1 }-->
                                        <a href="{$vk_li_title_pic_1_this[url]}" target="_self" title="{$vk_li_title_pic_1_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_title_pic_1_this[makethumb] == 1}{$vk_li_title_pic_1_this[thumbpath]}{else}{$vk_li_title_pic_1_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_title_pic_1_this[picflag] == 2}-->
                                        <a href="{$vk_li_title_pic_1_this[url]}" target="_self" title="{$vk_li_title_pic_1_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_title_pic_1_this[makethumb] == 1}{$vk_li_title_pic_1_this[thumbpath]}{else}{$vk_li_title_pic_1_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_title_pic_1_this[url]}" target="_self" title="{$vk_li_title_pic_1_this[title]}"> <img src="{$vk_li_title_pic_1_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->




			<!-- 图文 调用 - 下标题，上图片 - 部分显示，左右切换 -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_rec"><a href="http://t.cn/Aiux1Qh0" target="_blank">推荐</a></h2>
					<ul>
						<li><a href="http://t.cn/Aiux1Qh0" target="_blank" class="more_rec"> 查看更多 </a></li>
					</ul>
				</div>
				<div class="p_l_15">
                    <!-- Swiper -->
                    <!--{if $vk_slide_index_part_1_id}-->

                        <!--{eval $vk_slide_index_part_1 = vk_diy_block($vk_slide_index_part_1_id, 5);}-->
                        <!--{if $vk_slide_index_part_1}-->

                            <div class="swiper-container-slide-part" id="slide_part">
                                <div class="swiper-wrapper">

                                    <!--{loop $vk_slide_index_part_1 $vk_slide_index_part_1_this}-->
                                    <!--{eval $vk_slide_index_part_1_this_fields = unserialize($vk_slide_index_part_1_this[fields]); }-->
                                    <!--{eval $vk_slide_index_part_1_this_style = unserialize($vk_slide_index_part_1_this[showstyle]); }-->

                                        <div class="swiper-slide">
                                            <!--{if $vk_slide_index_part_1_this[picflag] == 1 }-->
                                            <a href="{$vk_slide_index_part_1_this[url]}" target="_self" title="{$vk_slide_index_part_1_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_slide_index_part_1_this[makethumb] == 1}{$vk_slide_index_part_1_this[thumbpath]}{else}{$vk_slide_index_part_1_this[pic]}{/if}"/></a>
                                            <!--{elseif $vk_slide_index_part_1_this[picflag] == 2}-->
                                            <a href="{$vk_slide_index_part_1_this[url]}" target="_self" title="{$vk_slide_index_part_1_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_slide_index_part_1_this[makethumb] == 1}{$vk_slide_index_part_1_this[thumbpath]}{else}{$vk_slide_index_part_1_this[pic]}{/if}"/></a>
                                            <!--{else}-->
                                            <a href="{$vk_slide_index_part_1_this[url]}" target="_self" title="{$vk_slide_index_part_1_this[title]}"> <img src="{$vk_slide_index_part_1_this[pic]}"/></a>
                                            <!--{/if}-->

                                            <h2> <span> <!--{echo cutstr($vk_slide_index_part_1_this[title], 30,'')}--> </span> </h2>
                                        </div>
                                    <!--{/loop}-->
                                </div>
                            </div>
                        <!--{else}-->
                        <!--{/if}-->

                    <!--{else}-->
                    <!--{/if}-->
                    
                    
                    <!-- Initialize Swiper --> 
                    <script>
                        var slideSwiper = new Swiper('#slide_part', {
                            pagination: '#slide_part .swiper-pagination',
                            slidesPerView: 'auto',
                            spaceBetween: 15,
                            preventClicks:false,
                        });
                    </script>
				</div>
			</div>
			
			

			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_1.jpg" />
					</a>
				</div>
			</div>
			
			

			<!-- 文章图文 调用 - 左标题，右图片 - 点击加载 -->
            <!--
            [未来科技_手机]帖子模块-左标题右图宽240高140-附加信息-点击加载
            DIY模块属性里：图片设置为 宽 240 高 140
            -->
            <!--{if $vk_li_title_pic_load_id}-->
                <!--{eval $vk_li_title_pic_load = vk_diy_block($vk_li_title_pic_load_id, 100);}-->
                <!--{if $vk_li_title_pic_load}-->

                    <div class="vk_wp cl">
                        <div class="vk_li_title_pic cl">
                            <ul>

                                <!--{loop $vk_li_title_pic_load $vk_li_title_pic_load_this}-->
                                <!--{eval $vk_li_title_pic_load_this_fields = unserialize($vk_li_title_pic_load_this[fields]); }-->
                                <!--{eval $vk_li_title_pic_load_this_style = unserialize($vk_li_title_pic_load_this[showstyle]); }-->

                                <li class="vk_load_list">
                                    <div class="vk_li_title_pic_title left">
                                        <div class="vk_li_title"> <a href="{$vk_li_title_pic_load_this[url]}" title="{$vk_li_title_pic_load_this[title]}" target="_self" style="color: <!--{if $vk_li_title_pic_load_this_style[title_c] }--> {$vk_li_title_pic_load_this_style[title_c]} <!--{else}--> {$vk_li_title_pic_load_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_title_pic_load_this[title], 50,'')}--></a> </div>
                                        <div class="vk_li_info">
                                            <!--{if $vk_li_title_pic_load_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_load_this_fields[authorid]}&do=profile" target="_self"> <span>{$vk_li_title_pic_load_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_title_pic_load_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_load_this_fields[uid]}&do=profile" target="_self"> <span>{$vk_li_title_pic_load_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <span><!--{echo dgmdate($vk_li_title_pic_load_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                                            <i>{$vk_li_title_pic_load_this_fields[views]} 阅读</i>
                                        </div>
                                    </div>

                                    <div class="vk_li_title_pic_pic right">

                                        <!--{if $vk_li_title_pic_load_this[picflag] == 1 }-->
                                        <a href="{$vk_li_title_pic_load_this[url]}" target="_self" title="{$vk_li_title_pic_load_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_title_pic_load_this[makethumb] == 1}{$vk_li_title_pic_load_this[thumbpath]}{else}{$vk_li_title_pic_load_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_title_pic_load_this[picflag] == 2}-->
                                        <a href="{$vk_li_title_pic_load_this[url]}" target="_self" title="{$vk_li_title_pic_load_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_title_pic_load_this[makethumb] == 1}{$vk_li_title_pic_load_this[thumbpath]}{else}{$vk_li_title_pic_load_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_title_pic_load_this[url]}" target="_self" title="{$vk_li_title_pic_load_this[title]}"> <img src="{$vk_li_title_pic_load_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>
                                </li>

                                <!--{/loop}-->


                                <div class="vk_load_more">
                                    <a href="javascript:;">查看更多 ... </a>
                                </div>

                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->

            <!-- 需要引用 jquery.min.js。如果 head文件引用过，此处可忽略 -->
            <!--
            <script src="$_G['style']['styleimgdir']/touch/css/jquery.min.js?{VERHASH}"></script>
            -->
            <script type="text/javascript">
                jQuery(function (){
                    showItem(0, 10);
                    var itemNum = 10; 

                    jQuery('.vk_load_more').click(function(){
                        if(itemNum < 100){
                            showItem(itemNum, itemNum += 20);
                        } else {
                            location.href = 'forum.php';
                        }
                    });  	

                    function showItem(fromindex,toindex){
                        var len = jQuery('.vk_load_list').length;
                        for(var i = fromindex; i < toindex ; i++ ){
                            jQuery('.vk_load_list').eq(i).css('display','block');
                        }
                    } 

                })
            </script>
			
			

			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_2.jpg" />
					</a>
				</div>
			</div>

		</div>
		
		
		
		
		
		
		
		
		

		<!-- 模块“热榜”下的block调用 -->
		<div class="swiper-slide">    
            
			<!-- 帖子图文 调用 - 热榜 -->
            <!--
            [未来科技_手机]帖子模块-左标题右图宽240高140
            DIY模块属性里：图片设置为 宽 240 高 140
            -->
            <!--{if $vk_li_title_pic_1_life_01_id}-->
                <!--{eval $vk_li_title_pic_1_life_01 = vk_diy_block($vk_li_title_pic_1_life_01_id, 10);}-->
                <!--{if $vk_li_title_pic_1_life_01}-->

                    <div class="vk_wp cl">
                        <div class="vk_li_title_pic cl">
                            <ul>

                                <!--{loop $vk_li_title_pic_1_life_01 $vk_li_title_pic_1_life_01_this}-->
                                <!--{eval $vk_li_title_pic_1_life_01_this_fields = unserialize($vk_li_title_pic_1_life_01_this[fields]); }-->
                                <!--{eval $vk_li_title_pic_1_life_01_this_style = unserialize($vk_li_title_pic_1_life_01_this[showstyle]); }-->

                                <li>
                                    <div class="vk_li_title_pic_title left">
                                        <div class="vk_li_title"> <span class="color_{$vk_li_title_pic_1_life_01_this[displayorder]}">No.{$vk_li_title_pic_1_life_01_this[displayorder]}</span> <a href="{$vk_li_title_pic_1_life_01_this[url]}" title="{$vk_li_title_pic_1_life_01_this[title]}" target="_self" style="color: <!--{if $vk_li_title_pic_1_life_01_this_style[title_c] }--> {$vk_li_title_pic_1_life_01_this_style[title_c]} <!--{else}--> {$vk_li_title_pic_1_life_01_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_title_pic_1_life_01_this[title], 50,'')}--></a> </div>
                                        <div class="vk_li_info">
                                            <span><!--{echo dgmdate($vk_li_title_pic_1_life_01_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>

                                            <i>
                                                <!--{if $vk_li_title_pic_1_life_01_this_fields[authorid]}-->
                                                <a href="home.php?mod=space&uid={$vk_li_title_pic_1_life_01_this_fields[authorid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_life_01_this_fields[author]}</span></a>
                                                <!--{elseif $vk_li_title_pic_1_life_01_this_fields[uid]}-->
                                                <a href="home.php?mod=space&uid={$vk_li_title_pic_1_life_01_this_fields[uid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_life_01_this_fields[username]}</span></a>
                                                <!--{else}-->
                                                <a href="javascript:;"> <span> {$_G[setting][anonymoustext]} </span></a>
                                                <!--{/if}-->
                                            </i>
                                        </div>
                                    </div>

                                    <div class="vk_li_title_pic_pic right">

                                        <!--{if $vk_li_title_pic_1_life_01_this[picflag] == 1 }-->
                                        <a href="{$vk_li_title_pic_1_life_01_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_01_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_title_pic_1_life_01_this[makethumb] == 1}{$vk_li_title_pic_1_life_01_this[thumbpath]}{else}{$vk_li_title_pic_1_life_01_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_title_pic_1_life_01_this[picflag] == 2}-->
                                        <a href="{$vk_li_title_pic_1_life_01_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_01_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_title_pic_1_life_01_this[makethumb] == 1}{$vk_li_title_pic_1_life_01_this[thumbpath]}{else}{$vk_li_title_pic_1_life_01_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_title_pic_1_life_01_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_01_this[title]}"> <img src="{$vk_li_title_pic_1_life_01_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>


        
        
        
        
		<!-- 模块“科技”下的block调用 -->
		<div class="swiper-slide">
			<!-- 广/告 -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_8.jpg" />
					</a>
				</div>
			</div>
			<!-- 帖子图文 调用 - 科技 -->
            <!--
            [未来科技_手机]帖子模块-左标题右图宽240高140
            DIY模块属性里：图片设置为 宽 240 高 140
            -->
            <!--{if $vk_li_title_pic_1_life_02_id}-->
                <!--{eval $vk_li_title_pic_1_life_02 = vk_diy_block($vk_li_title_pic_1_life_02_id, 10);}-->
                <!--{if $vk_li_title_pic_1_life_02}-->

                    <div class="vk_wp cl">
                        <div class="vk_li_title_pic cl">
                            <ul>

                                <!--{loop $vk_li_title_pic_1_life_02 $vk_li_title_pic_1_life_02_this}-->
                                <!--{eval $vk_li_title_pic_1_life_02_this_fields = unserialize($vk_li_title_pic_1_life_02_this[fields]); }-->
                                <!--{eval $vk_li_title_pic_1_life_02_this_style = unserialize($vk_li_title_pic_1_life_02_this[showstyle]); }-->

                                <li>
                                    <div class="vk_li_title_pic_title left">
                                        <div class="vk_li_title"> <a href="{$vk_li_title_pic_1_life_02_this[url]}" title="{$vk_li_title_pic_1_life_02_this[title]}" target="_self" style="color: <!--{if $vk_li_title_pic_1_life_02_this_style[title_c] }--> {$vk_li_title_pic_1_life_02_this_style[title_c]} <!--{else}--> {$vk_li_title_pic_1_life_02_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_title_pic_1_life_02_this[title], 50,'')}--></a> </div>
                                        <div class="vk_li_info">
                                            <!--{if $vk_li_title_pic_1_life_02_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_1_life_02_this_fields[authorid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_life_02_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_title_pic_1_life_02_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_title_pic_1_life_02_this_fields[uid]}&do=profile" target="_self"><span>{$vk_li_title_pic_1_life_02_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <span><!--{echo dgmdate($vk_li_title_pic_1_life_02_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                                            <i>{$vk_li_title_pic_1_life_02_this_fields[views]} 阅读</i>
                                        </div>
                                    </div>

                                    <div class="vk_li_title_pic_pic right">

                                        <!--{if $vk_li_title_pic_1_life_02_this[picflag] == 1 }-->
                                        <a href="{$vk_li_title_pic_1_life_02_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_02_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_title_pic_1_life_02_this[makethumb] == 1}{$vk_li_title_pic_1_life_02_this[thumbpath]}{else}{$vk_li_title_pic_1_life_02_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_title_pic_1_life_02_this[picflag] == 2}-->
                                        <a href="{$vk_li_title_pic_1_life_02_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_02_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_title_pic_1_life_02_this[makethumb] == 1}{$vk_li_title_pic_1_life_02_this[thumbpath]}{else}{$vk_li_title_pic_1_life_02_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_title_pic_1_life_02_this[url]}" target="_self" title="{$vk_li_title_pic_1_life_02_this[title]}"> <img src="{$vk_li_title_pic_1_life_02_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>
		
        
        
        
        

		<!-- 模块“美女”下的block调用 -->
		<div class="swiper-slide">
			<div class="wp m_t_0">
			<!-- 帖子图文 调用 - 美女 -->
            <!--
            [未来科技_手机]文章-帖子通用模块-上图宽360高240-下标题两行-两列
            DIY模块属性里：图片设置为 宽 360 高 240
            -->
            <!--{if $vk_li_2_pic_1_life_03_id}-->
                <!--{eval $vk_li_2_pic_1_life_03 = vk_diy_block($vk_li_2_pic_1_life_03_id, 10);}-->
                <!--{if $vk_li_2_pic_1_life_03}-->

                    <div class="wp cl">
                        <div class="vk_li_2_pic_title cl">
                            <ul>

                                <!--{loop $vk_li_2_pic_1_life_03 $vk_li_2_pic_1_life_03_this}-->
                                <!--{eval $vk_li_2_pic_1_life_03_this_fields = unserialize($vk_li_2_pic_1_life_03_this[fields]); }-->
                                <!--{eval $vk_li_2_pic_1_life_03_this_style = unserialize($vk_li_2_pic_1_life_03_this[showstyle]); }-->

                                <li>
                                    <div class="vk_top_img">

                                        <!--{if $vk_li_2_pic_1_life_03_this[picflag] == 1 }-->
                                        <a href="{$vk_li_2_pic_1_life_03_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_03_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_2_pic_1_life_03_this[makethumb] == 1}{$vk_li_2_pic_1_life_03_this[thumbpath]}{else}{$vk_li_2_pic_1_life_03_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_2_pic_1_life_03_this[picflag] == 2}-->
                                        <a href="{$vk_li_2_pic_1_life_03_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_03_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_2_pic_1_life_03_this[makethumb] == 1}{$vk_li_2_pic_1_life_03_this[thumbpath]}{else}{$vk_li_2_pic_1_life_03_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_2_pic_1_life_03_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_03_this[title]}"> <img src="{$vk_li_2_pic_1_life_03_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>

                                    <div class="vk_bottom_div_avt">
                                        <div class="list_title"> <a href="{$vk_li_2_pic_1_life_03_this[url]}" title="{$vk_li_2_pic_1_life_03_this[title]}" target="_self" style="color: <!--{if $vk_li_2_pic_1_life_03_this_style[title_c] }--> {$vk_li_2_pic_1_life_03_this_style[title_c]} <!--{else}--> {$vk_li_2_pic_1_life_03_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_2_pic_1_life_03_this[title], 50,'')}--></a> 
                                        </div>
                                        <div class="list_info">
                                            <!--{if $vk_li_2_pic_1_life_03_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_03_this_fields[authorid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_03_this_fields[authorid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_03_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_2_pic_1_life_03_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_03_this_fields[uid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_03_this_fields[uid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_03_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/touch/img/vk_icon_user.png" /> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <i><!--{echo dgmdate($vk_li_2_pic_1_life_03_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></i>
                                        </div>
                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
			</div>
		</div>
		

        
        
        
        
		<!-- 模块“汽车”下的block调用 -->
		<div class="swiper-slide">
			<!-- 广/告 -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_7.jpg" />
					</a>
				</div>
			</div>
			<!-- 帖子图文 调用 - 汽车 -->
            <!--
            [未来科技_手机]文章-帖子通用模块-上图宽360高240-下标题两行-两列
            DIY模块属性里：图片设置为 宽 360 高 240
            -->
            <!--{if $vk_li_2_pic_1_life_05_id}-->
                <!--{eval $vk_li_2_pic_1_life_05 = vk_diy_block($vk_li_2_pic_1_life_05_id, 10);}-->
                <!--{if $vk_li_2_pic_1_life_05}-->

                    <div class="wp cl">
                        <div class="vk_li_2_pic_title cl">
                            <ul>

                                <!--{loop $vk_li_2_pic_1_life_05 $vk_li_2_pic_1_life_05_this}-->
                                <!--{eval $vk_li_2_pic_1_life_05_this_fields = unserialize($vk_li_2_pic_1_life_05_this[fields]); }-->
                                <!--{eval $vk_li_2_pic_1_life_05_this_style = unserialize($vk_li_2_pic_1_life_05_this[showstyle]); }-->

                                <li>
                                    <div class="vk_top_img">

                                        <!--{if $vk_li_2_pic_1_life_05_this[picflag] == 1 }-->
                                        <a href="{$vk_li_2_pic_1_life_05_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_05_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_2_pic_1_life_05_this[makethumb] == 1}{$vk_li_2_pic_1_life_05_this[thumbpath]}{else}{$vk_li_2_pic_1_life_05_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_2_pic_1_life_05_this[picflag] == 2}-->
                                        <a href="{$vk_li_2_pic_1_life_05_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_05_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_2_pic_1_life_05_this[makethumb] == 1}{$vk_li_2_pic_1_life_05_this[thumbpath]}{else}{$vk_li_2_pic_1_life_05_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_2_pic_1_life_05_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_05_this[title]}"> <img src="{$vk_li_2_pic_1_life_05_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>

                                    <div class="vk_bottom_div_avt">
                                        <div class="list_title"> <a href="{$vk_li_2_pic_1_life_05_this[url]}" title="{$vk_li_2_pic_1_life_05_this[title]}" target="_self" style="color: <!--{if $vk_li_2_pic_1_life_05_this_style[title_c] }--> {$vk_li_2_pic_1_life_05_this_style[title_c]} <!--{else}--> {$vk_li_2_pic_1_life_05_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_2_pic_1_life_05_this[title], 50,'')}--></a> 
                                        </div>
                                        <div class="list_info">
                                            <!--{if $vk_li_2_pic_1_life_05_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_05_this_fields[authorid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_05_this_fields[authorid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_05_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_2_pic_1_life_05_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_05_this_fields[uid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_05_this_fields[uid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_05_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/touch/img/vk_icon_user.png" /> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <i><!--{echo dgmdate($vk_li_2_pic_1_life_05_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></i>
                                        </div>
                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>
		

        
        
        
		<!-- 模块“楼盘”下的block调用 -->
		<div class="swiper-slide">
			<!-- 广/告 -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_9.jpg" />
					</a>
				</div>
			</div>
			<!-- 帖子图文 调用 - 楼盘 -->
            <!--
            [未来科技_手机]文章-帖子通用模块-上图宽360高240-下标题两行-两列
            DIY模块属性里：图片设置为 宽 360 高 240
            -->
            <!--{if $vk_li_2_pic_1_life_04_id}-->
                <!--{eval $vk_li_2_pic_1_life_04 = vk_diy_block($vk_li_2_pic_1_life_04_id, 10);}-->
                <!--{if $vk_li_2_pic_1_life_04}-->

                    <div class="wp cl">
                        <div class="vk_li_2_pic_title cl">
                            <ul>

                                <!--{loop $vk_li_2_pic_1_life_04 $vk_li_2_pic_1_life_04_this}-->
                                <!--{eval $vk_li_2_pic_1_life_04_this_fields = unserialize($vk_li_2_pic_1_life_04_this[fields]); }-->
                                <!--{eval $vk_li_2_pic_1_life_04_this_style = unserialize($vk_li_2_pic_1_life_04_this[showstyle]); }-->

                                <li>
                                    <div class="vk_top_img">

                                        <!--{if $vk_li_2_pic_1_life_04_this[picflag] == 1 }-->
                                        <a href="{$vk_li_2_pic_1_life_04_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_04_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_2_pic_1_life_04_this[makethumb] == 1}{$vk_li_2_pic_1_life_04_this[thumbpath]}{else}{$vk_li_2_pic_1_life_04_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_2_pic_1_life_04_this[picflag] == 2}-->
                                        <a href="{$vk_li_2_pic_1_life_04_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_04_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_2_pic_1_life_04_this[makethumb] == 1}{$vk_li_2_pic_1_life_04_this[thumbpath]}{else}{$vk_li_2_pic_1_life_04_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_2_pic_1_life_04_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_04_this[title]}"> <img src="{$vk_li_2_pic_1_life_04_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>

                                    <div class="vk_bottom_div_avt">
                                        <div class="list_title"> <a href="{$vk_li_2_pic_1_life_04_this[url]}" title="{$vk_li_2_pic_1_life_04_this[title]}" target="_self" style="color: <!--{if $vk_li_2_pic_1_life_04_this_style[title_c] }--> {$vk_li_2_pic_1_life_04_this_style[title_c]} <!--{else}--> {$vk_li_2_pic_1_life_04_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_2_pic_1_life_04_this[title], 50,'')}--></a> 
                                        </div>
                                        <div class="list_info">
                                            <!--{if $vk_li_2_pic_1_life_04_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_04_this_fields[authorid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_04_this_fields[authorid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_04_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_2_pic_1_life_04_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_04_this_fields[uid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_04_this_fields[uid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_04_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/touch/img/vk_icon_user.png" /> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <i><!--{echo dgmdate($vk_li_2_pic_1_life_04_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></i>
                                        </div>
                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>


        
        
        
		<!-- 模块“娱乐”下的block调用 -->
		<div class="swiper-slide">
			<!-- 帖子图文 调用 - 娱乐 -->
            <!--
            [未来科技_手机]文章-帖子通用模块-上图宽360高240-下标题两行-两列
            DIY模块属性里：图片设置为 宽 360 高 240
            -->
            <!--{if $vk_li_2_pic_1_life_06_id}-->
                <!--{eval $vk_li_2_pic_1_life_06 = vk_diy_block($vk_li_2_pic_1_life_06_id, 10);}-->
                <!--{if $vk_li_2_pic_1_life_06}-->

                    <div class="wp cl">
                        <div class="vk_li_2_pic_title cl">
                            <ul>

                                <!--{loop $vk_li_2_pic_1_life_06 $vk_li_2_pic_1_life_06_this}-->
                                <!--{eval $vk_li_2_pic_1_life_06_this_fields = unserialize($vk_li_2_pic_1_life_06_this[fields]); }-->
                                <!--{eval $vk_li_2_pic_1_life_06_this_style = unserialize($vk_li_2_pic_1_life_06_this[showstyle]); }-->

                                <li>
                                    <div class="vk_top_img">

                                        <!--{if $vk_li_2_pic_1_life_06_this[picflag] == 1 }-->
                                        <a href="{$vk_li_2_pic_1_life_06_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_06_this[title]}"> <img src="{$_G['setting']['attachurl']}{if $vk_li_2_pic_1_life_06_this[makethumb] == 1}{$vk_li_2_pic_1_life_06_this[thumbpath]}{else}{$vk_li_2_pic_1_life_06_this[pic]}{/if}"/> </a>
                                        <!--{elseif $vk_li_2_pic_1_life_06_this[picflag] == 2}-->
                                        <a href="{$vk_li_2_pic_1_life_06_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_06_this[title]}"> <img src="{$_G['setting']['ftp']['attachurl']}{if $vk_li_2_pic_1_life_06_this[makethumb] == 1}{$vk_li_2_pic_1_life_06_this[thumbpath]}{else}{$vk_li_2_pic_1_life_06_this[pic]}{/if}"/> </a>
                                        <!--{else}-->
                                        <a href="{$vk_li_2_pic_1_life_06_this[url]}" target="_self" title="{$vk_li_2_pic_1_life_06_this[title]}"> <img src="{$vk_li_2_pic_1_life_06_this[pic]}"/> </a>
                                        <!--{/if}-->

                                    </div>

                                    <div class="vk_bottom_div_avt">
                                        <div class="list_title"> <a href="{$vk_li_2_pic_1_life_06_this[url]}" title="{$vk_li_2_pic_1_life_06_this[title]}" target="_self" style="color: <!--{if $vk_li_2_pic_1_life_06_this_style[title_c] }--> {$vk_li_2_pic_1_life_06_this_style[title_c]} <!--{else}--> {$vk_li_2_pic_1_life_06_this_fields[showstyle][title_c]} <!--{/if}-->" ><!--{echo cutstr($vk_li_2_pic_1_life_06_this[title], 50,'')}--></a> 
                                        </div>
                                        <div class="list_info">
                                            <!--{if $vk_li_2_pic_1_life_06_this_fields[authorid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_06_this_fields[authorid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_06_this_fields[authorid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_06_this_fields[author]}</span></a>
                                            <!--{elseif $vk_li_2_pic_1_life_06_this_fields[uid]}-->
                                            <a href="home.php?mod=space&uid={$vk_li_2_pic_1_life_06_this_fields[uid]}&do=profile" target="_self"><img src="<!--{avatar($vk_li_2_pic_1_life_06_this_fields[uid], middle, true)}-->" /> <span>{$vk_li_2_pic_1_life_06_this_fields[username]}</span></a>
                                            <!--{else}-->
                                            <a href="javascript:;"><img src="{$_G['style']['styleimgdir']}/touch/img/vk_icon_user.png" /> <span> {$_G[setting][anonymoustext]} </span></a>
                                            <!--{/if}-->
                                            <i><!--{echo dgmdate($vk_li_2_pic_1_life_06_this_fields[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></i>
                                        </div>
                                    </div>
                                </li>

                                <!--{/loop}-->
                            </ul>
                        </div>
                    </div>

                <!--{else}-->
                <!--{/if}-->

            <!--{else}-->
            <!--{/if}-->
		</div>

		
		
		

	</div>
</div>





<script type="text/javascript">
var mySwiper = new Swiper('#topNav', {
	freeMode: true,
	freeModeMomentumRatio: 0.5,
	slidesPerView: 'auto',
	roundLengths : true,
});

swiperWidth = mySwiper.container[0].clientWidth
maxTranslate = mySwiper.maxTranslate();
maxWidth = -maxTranslate + swiperWidth / 2

$(".swiper-container").on('touchstart', function(e) {
	e.preventDefault()
})

mySwiper.on('tap', function(swiper, e) {
//    console.log(swiper.clickedIndex)
    pageSwiper.slideTo(swiper.clickedIndex, 1000, false);//跳转
//	e.preventDefault()
	slide = swiper.slides[swiper.clickedIndex]
	slideLeft = slide.offsetLeft
	slideWidth = slide.clientWidth
	slideCenter = slideLeft + slideWidth / 2
    console.log("slideLeft:"+slideLeft)
    console.log("maxWidth:"+maxWidth)
    console.log("slideCenter:"+slideCenter)
	// 被点击slide的中心点
	mySwiper.setWrapperTransition(300)
	if (slideCenter < swiperWidth / 2) {
		mySwiper.setWrapperTranslate(0)
	} else if (slideCenter > maxWidth) {
		mySwiper.setWrapperTranslate(maxTranslate)
	} else {
		nowTlanslate = slideCenter - swiperWidth / 2
		mySwiper.setWrapperTranslate(-nowTlanslate)
	}
	$("#topNav .active").removeClass('active')
	$("#topNav .swiper-slide").eq(swiper.clickedIndex).addClass('active')

})
</script>



<script>
    var pageSwiper = new Swiper('#topNav_page', {
        paginationClickable: true,
        uniqueNavElements :false,
		roundLengths : true,
        onSlideChangeStart: function(swiper){
//            console.log(swiper.activeIndex)
//            mySwiper.slideTo(swiper.activeIndex, 1000, false);
            $("#topNav .active").removeClass('active')
            $("#topNav .swiper-slide").eq(swiper.activeIndex).addClass('active')

            slide = mySwiper.slides[swiper.activeIndex];//获取当前的slide节点
            slideLeft = slide.offsetLeft
            slideWidth = slide.clientWidth
            slideCenter = slideLeft + slideWidth / 2
            // 被点击slide的中心点
            console.log("============")
            console.log("slideLeft:"+slideLeft)
            console.log("maxWidth:"+maxWidth)
            console.log("slideCenter:"+slideCenter)
            console.log("swiperWidth / 2:"+swiperWidth / 2)
            mySwiper.setWrapperTransition(300)
            if (slideCenter < swiperWidth / 2) {
                mySwiper.setWrapperTranslate(0)
            } else if (slideCenter >maxWidth) {
                mySwiper.setWrapperTranslate(maxTranslate)
                console.log("maxTranslate:"+maxTranslate)
            } else {
                nowTlanslate = slideCenter - swiperWidth / 2
                console.log(nowTlanslate)
                mySwiper.setWrapperTranslate(-nowTlanslate)
            }
        }
    });
</script>









<!-- main threadlist start -->
<!-- main threadlist end -->


<div class="pullrefresh" style="display:none;"></div>

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>

<!--{template common/footer}-->
