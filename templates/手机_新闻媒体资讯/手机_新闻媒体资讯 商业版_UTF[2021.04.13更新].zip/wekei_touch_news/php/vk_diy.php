<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}




/* 首页 帖子点击加载 */
/* 下面这一行是调用的需要显示的版块ID，可以根据需要把里面的数字换为需要显示的版块ID */
$fids = '2,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70';

$postlist = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." WHERE `displayorder` = 0 AND isgroup = '0' AND `fid` in ($fids) ORDER BY `dateline` DESC limit 0 , 200");
/*
$pic_list = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$piclist.'')." WHERE `tid`= $post_list[tid] AND isimage = '1' ORDER BY `dateline` DESC limit 0 , 9");
*/




function vk_diy_on($name){
    $name_off = '0'.$name ;
    $diy_on  = DB::result(DB::query("SELECT bid FROM ".DB::table('common_block')." WHERE name = '$name' ORDER BY bid DESC"));
    $diy_off = DB::result(DB::query("SELECT bid FROM ".DB::table('common_block')." WHERE name = '$name_off' ORDER BY bid DESC"));

    if (empty($diy_on)) { $diy_on = '0'; }
    if (empty($diy_off)) { $diy_off = '0'; }
    if ($diy_on > $diy_off) { return true; } else { return false; }
    
}




function vk_diy_id($name1, $name2){
    if(vk_diy_on($name1) || vk_diy_on($name2)){
        
        $diy_id = DB::result(DB::query("SELECT a.bid FROM ".DB::table('common_block')." a LEFT JOIN ".DB::table('common_template_block')." b ON a.bid=b.bid WHERE (a.name = '$name1' OR a.name = '$name2') AND b.targettplname = 'forum/discuz' ORDER BY a.bid DESC"));
        
        if(!$diy_id){
            $diy_id = DB::result(DB::query("SELECT bid FROM ".DB::table('common_block')." WHERE (name = '$name1' OR name = '$name2') ORDER BY bid DESC"));
        }
        
        return $diy_id;
    }
}




function vk_diy_block($bid, $num){
    $diy_block = DB::fetch_all("SELECT * FROM ".DB::table('common_block_item')." WHERE bid = '$bid' ORDER BY displayorder ASC LIMIT $num");
    return $diy_block;
}




function vk_diy_param($name){
    if (vk_diy_on($name)) {
        $diy_param = DB::result(DB::query("SELECT param FROM ".DB::table('common_block')." WHERE name = '$name' ORDER BY bid DESC"));
        return $diy_param;
    }
}




function vk_diy_title($bid){
    $diy_title = DB::result(DB::query("SELECT title FROM ".DB::table('common_block')." WHERE bid = '$bid'"));
    return $diy_title;
}




function vk_diy_summary($name){
    if(vk_diy_on($name)) {
        $diy_summary = DB::result(DB::query("SELECT summary FROM ".DB::table('common_block')." WHERE name = '$name' ORDER BY bid DESC"));
        return $diy_summary;
    }
}



//di'.'sm.t'.'aoba'.'o.com
?>

