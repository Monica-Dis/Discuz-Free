<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



/* 文章-帖子通用模块 */


/***************************************************************************


变量命名说明：

列表
_li_      表示一列（默认）
_li_2_    表示两列

后缀
_1  最新发布
_2  最新回复
_3  热门推荐  

CSS属性
对应模块的属性，位于 模板文件夹/images/touch/css/vk_touch.css 内


****************************************************************************/



/******************************************


公共常用模块


*******************************************/


/* 文章-帖子通用模块-图片幻灯 */
$vk_slide_index_1_id = vk_diy_id('$vk_slide_index_1', '模块_图片幻灯');

/* 文章-帖子通用模块-图片幻灯-部分显示 */
$vk_slide_index_part_1_id = vk_diy_id('$vk_slide_index_part_1', '模块_图片幻灯_部分显示');




/* 标题滚动显示：标题 - 时间 */
$vk_li_roll_id = vk_diy_id('$vk_li_roll', '模块_标题滚动显示_时间');




/*
版块模块-图标+版块名称-上图标下标题-三列
版块模块-图标+版块名称-上图标下标题-三列-内部
共用id和标识
*/
$vk_li_3_forum_icon_id = vk_diy_id('$vk_li_3_forum_icon', '模块_版块图标名称_3列');

/* 版块模块-图标+版块名称-上图标下标题-四列 */
$vk_li_4_forum_icon_id = vk_diy_id('$vk_li_4_forum_icon', '模块_版块图标名称_4列');

/* 版块模块-图标+版块名称-上图标下标题-五列 */
$vk_li_5_forum_icon_id = vk_diy_id('$vk_li_5_forum_icon', '模块_版块图标名称_5列');




/* 标题列表：标题 - 时间 */
$vk_li_title_time_1_id = vk_diy_id('$vk_li_title_time_1', '模块_标题列表_时间_最新发布');
$vk_li_title_time_2_id = vk_diy_id('$vk_li_title_time_2', '模块_标题列表_时间_最新回复');
$vk_li_title_time_3_id = vk_diy_id('$vk_li_title_time_3', '模块_标题列表_时间_热门推荐');

/* 标题列表：标题 - 作者 */
$vk_li_title_author_1_id = vk_diy_id('$vk_li_title_1_author', '模块_标题列表_作者_最新发布');
$vk_li_title_author_2_id = vk_diy_id('$vk_li_title_2_author', '模块_标题列表_作者_最新回复');
$vk_li_title_author_3_id = vk_diy_id('$vk_li_title_3_author', '模块_标题列表_作者_热门推荐');




/* 图文列表：左图右标题 */
$vk_li_pic_title_1_id = vk_diy_id('$vk_li_pic_title_1', '模块_左图右标题_最新发布');
$vk_li_pic_title_2_id = vk_diy_id('$vk_li_pic_title_2', '模块_左图右标题_最新回复');
$vk_li_pic_title_3_id = vk_diy_id('$vk_li_pic_title_3', '模块_左图右标题_热门推荐');




/* 图文列表：左标题右图 */
$vk_li_title_pic_1_id = vk_diy_id('$vk_li_title_pic_1', '模块_左标题右图_最新发布');
$vk_li_title_pic_2_id = vk_diy_id('$vk_li_title_pic_2', '模块_左标题右图_最新回复');
$vk_li_title_pic_3_id = vk_diy_id('$vk_li_title_pic_3', '模块_左标题右图_热门推荐');

/* 图文列表：左标题右图 - 点击加载*/
$vk_li_title_pic_load_id = vk_diy_id('$vk_li_title_pic_load', '模块_左标题右图_点击加载');

/* 图文列表：左标题右图 - 附加信息 - 点击加载*/
$vk_li_title_pic_info_load_id = vk_diy_id('$vk_li_title_pic_info_load', '模块_左标题右图_附加信息_点击加载');




/* 图文列表：图片-一列 */
$vk_li_1_pic_title_1_id = vk_diy_id('$vk_li_1_pic_title_1', '模块_图片_一列_最新发布');
$vk_li_1_pic_title_2_id = vk_diy_id('$vk_li_1_pic_title_2', '模块_图片_一列_最新回复');
$vk_li_1_pic_title_3_id = vk_diy_id('$vk_li_1_pic_title_3', '模块_图片_一列_热门推荐');




/* 图文列表：图片-两列 */
$vk_li_2_pic_1_id = vk_diy_id('$vk_li_2_pic_1', '模块_图片_两列_最新发布');
$vk_li_2_pic_2_id = vk_diy_id('$vk_li_2_pic_2', '模块_图片_两列_最新回复');
$vk_li_2_pic_3_id = vk_diy_id('$vk_li_2_pic_3', '模块_图片_两列_热门推荐');

/* 图文列表：图片-两列-附加信息 */
$vk_li_2_pic_info_1_id = vk_diy_id('$vk_li_2_pic_info_1', '模块_图片_两列_附加信息_最新发布');
$vk_li_2_pic_info_2_id = vk_diy_id('$vk_li_2_pic_info_2', '模块_图片_两列_附加信息_最新回复');
$vk_li_2_pic_info_3_id = vk_diy_id('$vk_li_2_pic_info_3', '模块_图片_两列_附加信息_热门推荐');

/* 图文列表：图片-两列-附加信息-带头像 */
$vk_li_2_pic_info_avt_1_id = vk_diy_id('$vk_li_2_pic_info_avt_1', '模块_图片_两列_附加信息_带头像_最新发布');
$vk_li_2_pic_info_avt_2_id = vk_diy_id('$vk_li_2_pic_info_avt_2', '模块_图片_两列_附加信息_带头像_最新回复');
$vk_li_2_pic_info_avt_3_id = vk_diy_id('$vk_li_2_pic_info_avt_3', '模块_图片_两列_附加信息_带头像_热门推荐');

/* 图文列表：图片-两列-点击加载 */
$vk_li_2_pic_load_1_id = vk_diy_id('$vk_li_2_pic_load_1', '模块_图片_两列_点击加载_最新发布');
$vk_li_2_pic_load_2_id = vk_diy_id('$vk_li_2_pic_load_2', '模块_图片_两列_点击加载_最新回复');
$vk_li_2_pic_load_3_id = vk_diy_id('$vk_li_2_pic_load_3', '模块_图片_两列_点击加载_热门推荐');




/* 图文列表：上图下标题-两列 */
$vk_li_2_pic_title_1_id = vk_diy_id('$vk_li_2_pic_title_1', '模块_上图下标题_两列_最新发布');
$vk_li_2_pic_title_2_id = vk_diy_id('$vk_li_2_pic_title_2', '模块_上图下标题_两列_最新回复');
$vk_li_2_pic_title_3_id = vk_diy_id('$vk_li_2_pic_title_3', '模块_上图下标题_两列_热门推荐');




/* 会员模块：头像-附加信息-一列 */
$vk_li_avt_info_1_id = vk_diy_id('$vk_li_avt_info_1', '模块_会员头像_附加信息');













/******************************************


单独添加的模块


*******************************************/



/* 图文列表：图片-两列 */
$vk_li_2_pic_1_life_01_id = vk_diy_id('$vk_li_2_pic_1_life_01', '模块_图片_两列_房产楼市');
$vk_li_2_pic_1_life_02_id = vk_diy_id('$vk_li_2_pic_1_life_02', '模块_图片_两列_科技');
$vk_li_2_pic_1_life_03_id = vk_diy_id('$vk_li_2_pic_1_life_03', '模块_图片_两列_美女');
$vk_li_2_pic_1_life_04_id = vk_diy_id('$vk_li_2_pic_1_life_04', '模块_图片_两列_楼盘');
$vk_li_2_pic_1_life_05_id = vk_diy_id('$vk_li_2_pic_1_life_05', '模块_图片_两列_汽车');
$vk_li_2_pic_1_life_06_id = vk_diy_id('$vk_li_2_pic_1_life_06', '模块_图片_两列_娱乐');





/* 图文列表：左标题右图 */
$vk_li_title_pic_1_life_01_id = vk_diy_id('$vk_li_title_pic_1_life_01', '模块_左标题右图_热榜');
$vk_li_title_pic_1_life_02_id = vk_diy_id('$vk_li_title_pic_1_life_02', '模块_左标题右图_科技');

$vk_li_title_pic_1_life_03_id = vk_diy_id('$vk_li_title_pic_1_life_03', '模块_左标题右图_优惠');
$vk_li_title_pic_1_life_04_id = vk_diy_id('$vk_li_title_pic_1_life_04', '模块_左标题右图_娱乐');






?>

