<?PHP exit('请支持正版 - 标奇创意 http://addon.dismall.com/?@68363.developer');?>	
<!--{template common/header}-->

<link href="template/biaoqi_lr_2018/member/css/biaoqi_sign.css" type="text/css" rel="stylesheet">

<script type="text/javascript">
	var strongpw = new Array();
	<!--{if $_G['setting']['strongpw']}-->
		<!--{loop $_G['setting']['strongpw'] $key $val}-->
		strongpw[$key] = $val;
		<!--{/loop}-->
	<!--{/if}-->
	var pwlength = <!--{if $_G['setting']['pwlength']}-->$_G['setting']['pwlength']<!--{else}-->0<!--{/if}-->;
</script>

<script type="text/javascript" src="{$this->setting[jspath]}register.js?{VERHASH}"></script>

<div id="ct" class="biaoqi_lr_wp ptm wp cl">

	<div class="nfl" id="main_succeed" style="display: none">
		<div class="f_c altw">
			<div class="alert_right">
				<p id="succeedmessage"></p>
				<p id="succeedlocation" class="alert_btnleft"></p>
				<p class="alert_btnleft"><a id="succeedmessage_href">{lang message_forward}</a></p>
			</div>
		</div>
	</div>
	<div class="mn" id="main_message">

	<div class="wp cl" style="margin-top: 35px;">
    <div class="biaoqi_lr_logo z"> 
		     <!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}-->
	</div>  
    <div class="biaoqi_lr_mode y"><a href="javascript:void(0);" class="cur-reg"">用户注册</a></div>
</div>

<div class="biaoqi_zhuce cl">

<div class="biaoqi_zhuce_ul">

   <div id="main_hnav" class="have-no-account">我已经注册，<a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}">马上登录&gt;&gt;</a></div>
   <!--{hook/register_side_top}-->
	<p id="returnmessage4"></p>

	<!--{if $this->showregisterform}-->

	<form method="post" autocomplete="off" name="register" id="registerform" enctype="multipart/form-data" onsubmit="checksubmit();return false;" action="member.php?mod=$regname">
		<div id="layer_reg">
			<input type="hidden" name="regsubmit" value="yes" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="referer" value="$dreferer" />
			<input type="hidden" name="activationauth" value="{if $_G[gp_action] == 'activation'}$activationauth{/if}" />
				<div id="reginfo_a" style="margin-top: 0;">
					<!--{hook/register_top}-->

					<!--{if $sendurl}-->
						<div class="rfm">
							<table>
								<tr>
									<th><span class="rq">*</span><label for="{$this->setting['reginput']['email']}">{lang email}:</label></th>
									<td>
										<input type="text" id="{$this->setting['reginput']['email']}" name="$this->setting['reginput']['email']" autocomplete="off" size="25" tabindex="1" class="px" required /><br /><em id="emailmore">&nbsp;</em>
										<input type="hidden" name="handlekey" value="sendregister"/>
									</td>
								</tr>
							</table>
							<div style="height: 30px;"><div class="tipcol"><i id="tip_{$this->setting['reginput']['email']}" class="p_tip">{lang register_email_tips}</i><kbd id="chk_{$this->setting['reginput']['email']}" class="p_chk"></kbd></div></div>
							<table style="margin-bottom: 30px;">
								<tr>
									<th>&nbsp;</th>
									<td class="tipwide">
										{lang register_validate_email_tips}
									</td>
								</tr>
							</table>
							<script type="text/javascript">
								function succeedhandle_sendregister(url, msg, values) {
									showDialog(msg, 'notice');
								}
							</script>
						</div>
					<!--{else}-->

						<!--{if $invite}-->
							<!--{if $invite['uid']}-->
							<div class="rfm">
								<table>
									<tr>
										<th>{lang register_from}:</th>
										<td><a href="home.php?mod=space&uid=$invite[uid]" target="_blank">$invite[username]</a></td>
									</tr>
								</table>
							</div>
							<!--{else}-->
							<div class="rfm">
								<table>
									<tr>
										<th><label for="invitecode">{lang invite_code}:</label></th>
										<td>$_G[gp_invitecode]<input type="hidden" id="invitecode" name="invitecode" value="$_G[gp_invitecode]" /></td>
									</tr>
								</table>
							</div>
							<!--{eval $invitecode = 1;}-->
							<!--{/if}-->
						<!--{/if}-->

						<!--{if empty($invite) && $this->setting['regstatus'] == 2 && !$invitestatus}-->
						<div class="rfm">
							<table>
								<tr>
									<th><label for="invitecode">{lang invite_code}:</label></th>
									<td><input type="text" id="invitecode" name="invitecode" autocomplete="off" size="25" onblur="checkinvite()" tabindex="1" class="px" required /><!--{if $this->setting['inviteconfig']['buyinvitecode'] && $this->setting['inviteconfig']['invitecodeprice'] && ($this->setting[ec_tenpay_bargainor] || $this->setting[ec_tenpay_opentrans_chnid] || $this->setting[ec_account])}--><p><a href="misc.php?mod=buyinvitecode" target="_blank" class="xi2">{lang register_buyinvitecode}</a></p><!--{/if}--></td>
								</tr>
							</table>
							<div class="tipcol"><!--{if $this->setting['inviteconfig']['invitecodeprompt']}--><i id="tip_invitecode" class="p_tip">$this->setting[inviteconfig][invitecodeprompt]</i><!--{/if}--><kbd id="chk_invitecode" class="p_chk"></kbd></div>
						</div>
						<!--{eval $invitecode = 1;}-->
						<!--{/if}-->

						<div class="rfm">
							<table>
								<tr>
									<th><label for="{$this->setting['reginput']['username']}">{lang username}:</label></th>
									<td><input type="text" id="{$this->setting['reginput']['username']}" name="" class="px" tabindex="1" autocomplete="off" size="25" maxlength="15" required /></td>
								</tr>
							</table>
							<div class="tipcol"><i id="tip_{$this->setting['reginput']['username']}" class="p_tip">{lang register_username_tips}</i><kbd id="chk_{$this->setting['reginput']['username']}" class="p_chk"></kbd></div>
						</div>

						<div class="rfm">
							<table>
								<tr>
									<th><label for="{$this->setting['reginput']['password']}">{lang password}:</label></th>
									<td><input type="password" id="{$this->setting['reginput']['password']}" name="" size="25" tabindex="1" class="px" required /></td>
									
								</tr>
							</table>
							<div class="tipcol"><i id="tip_{$this->setting['reginput']['password']}" class="p_tip">{lang register_password_tips}</i><kbd id="chk_{$this->setting['reginput']['password']}" class="p_chk"></kbd></div>
						</div>

						<div class="rfm">
							<table>
								<tr>
									<th><label for="{$this->setting['reginput']['password2']}">{lang password_confirm}:</label></th>
									<td><input type="password" id="{$this->setting['reginput']['password2']}" name="" size="25" tabindex="1" value="" class="px" required /></td>
									
								</tr>
							</table>
							<div class="tipcol"><i id="tip_{$this->setting['reginput']['password2']}" class="p_tip">{lang register_repassword_tips}</i><kbd id="chk_{$this->setting['reginput']['password2']}" class="p_chk"></kbd></div>
						</div>

						<div class="rfm">
							<table>
								<tr>
									<th><label for="{$this->setting['reginput']['email']}">{lang email}:</label></th>
									<td><input type="text" id="{$this->setting['reginput']['email']}" name="" autocomplete="off" size="25" tabindex="1" class="px" required /><br /><em id="emailmore">&nbsp;</em></td>
									
								</tr>
							</table>
							<div class="tipcol"><i id="tip_{$this->setting['reginput']['email']}" class="p_tip">{lang register_email_tips}</i><kbd id="chk_{$this->setting['reginput']['email']}" class="p_chk"></kbd></div>
						</div>
					<!--{/if}-->

					<!--{if $_G[gp_action] == 'activation'}-->
					<div id="activation_user" class="biaoqi_zhuce_li">
						<table>
							<tr>
								<th>{lang username}:</th>
								<td><strong>$username</strong></td>
							</tr>
						</table>
					</div>
					<!--{/if}-->

					<!--{if $this->setting['regverify'] == 2}-->
					<div class="rfm">
						<table>
							<tr>
								<th><label for="regmessage">{lang register_message}:</label></th>
								<td><input id="regmessage" name="regmessage" class="px" autocomplete="off" size="25" tabindex="1" required /></td>
								
							</tr>
						</table>
						<div class="tipcol"><i id="tip_regmessage" class="p_tip">{lang register_message1}</i></div>
					</div>
					<!--{/if}-->

					<!--{if empty($invite) && $this->setting['regstatus'] == 3}-->
					<div class="rfm">
						<table>
							<tr>
								<th><label for="invitecode">{lang invite_code}:</label></th>
								<td><input type="text" name="invitecode" autocomplete="off" size="25" id="invitecode"{if $this->setting['regstatus'] == 2} onblur="checkinvite()"{/if} tabindex="1" class="px" /></td>
							</tr>
						</table>
					</div>
					<!--{eval $invitecode = 1;}-->
					<!--{/if}-->

					<!--{loop $_G['cache']['fields_register'] $field}-->
						<!--{if $htmls[$field['fieldid']]}-->
						<div class="rfm">
							<table>
								<tr>
									<th><label for="$field['fieldid']">$field[title]:</label></th>
									<td>$htmls[$field['fieldid']]</td>									
								</tr>
							</table>
						</div>
						<!--{/if}-->
					<!--{/loop}-->

					<!--{hook/register_input}-->

					<!--{if $secqaacheck || $seccodecheck}-->
						<!--{block sectpl}--><div class="biaoqi_denglu_li code"><table><tr><th><sec>: </th><td><sec><br /><sec></td></tr></table></div><!--{/block}-->
						<!--{subtemplate common/seccheck}-->
					<!--{/if}-->

				<script>
					<!--{eval $vmid = 'c'.$sechash;}-->
					var secjsTimer = setInterval(
					    function(){
						   if($('seccodeverify_$vmid')){
							    clearInterval(secjsTimer);
								$('seccodeverify_$vmid').setAttribute('placeholder','请输入验证码');
								$('checkseccodeverify_$vmid').className = 'biaoqi_code_icon';
							  }
							}
					  ,500);
				</script>

				</div>

			</div>

    <!--{if $bbrules}-->
	    <div class="protocol_wrap">
		     <label for="agreebbrule"><input type="checkbox" class="ibox" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />我已经阅读并同意</label>
			 <a href="javascript:;" onclick="showBBRule()">《{lang rulemessage}》</a>
        </div>
	<!--{/if}-->

		<div id="layer_reginfo_b">
			<div class="biaoqi_zhuce_li bw0">
				<table width="100%">
					<tr>
						<td>
							<span id="reginfo_a_btn">
								<!--{if $_G[gp_action] != 'activation'}--><em>&nbsp;</em><!--{/if}-->
									<button class="biaoqicn_pn pnc" id="registerformsubmit" type="submit" name="regsubmit" value="true" tabindex="1"><!--{if $_G[gp_action] == 'activation'}-->立即激活<!--{else}-->免费注册<!--{/if}--></button>
							</span>
						</td>
						<td><!--{if $this->setting['sitemessage'][register]}--><a href="javascript:;" id="custominfo_register" class="y"><img src="{IMGDIR}/info_small.gif" alt="{lang faq}" /></a><!--{/if}--></td>
					</tr>
				</table>
			</div>

				<!--{if !empty($_G['setting']['pluginhooks']['register_logging_method'])}-->
				<div class="rfm bw0 {if empty($_GET['infloat'])} mbw{/if}" {if empty($_GET['infloat'])}style="display: none;"{/if}>
					<hr class="l" />
					<table>
						<tr>
							<th>{lang login_method}:</th>
							<td><!--{hook/register_logging_method}--></td>
						</tr>
					</table>
				</div>
			<!--{/if}-->
			   <div>
			</div>
		</div>
	</form>
	<!--{/if}-->
	<!--{hook/register_bottom}-->
	
</div>


<div class="register-right">
    <div class="register-rod">
	    <h2>注册成功您可以：</h2>
		<p>发帖、回帖、评分和收藏。</p>
		<p>体验炫酷特权。</p>
		<p>免费参加各种精彩活动。</p>
		<img src="template/biaoqi_lr_2018/member/img/biaoqi_lr_icon.jpg"><br>
	</div>
        <p class="other-plat2"><span>不想注册？可以用以下平台账号登录</span></p>
        <div class="other-account2">
		<!--{if in_array(wechat,$_G['setting']['plugins']['available'])}-->
            <a href="plugin.php?id=wechat:login" class="wx-wrap"><i class="wx"></i><p>微信</p></a>
		<!--{/if}-->
		<!--{if !empty($_G['setting']['plugins']['spacecp'])}-->
			<a href="connect.php?mod=login&amp;op=init&amp;referer=forum.php&amp;statfrom=login" class="qq-wrap"><i class="qq"></i><p>qq</p></a>
		<!--{/if}-->
			<a href="#" class="wb-wrap"><i class="wb"></i><p>新浪微博</p></a>
        </div>
    </div>
	
	
	</div>

<div id="layer_regmessage"class="f_c blr nfl" style="display: none">
	<div class="c"><div class="alert_right">
		<div id="messageleft1"></div>
		<p class="alert_btnleft" id="messageright1"></p>
	</div>
</div>

<div id="layer_bbrule" style="display: none">
<div class="c" style="width:700px;height:350px;overflow:auto">$bbrulestxt</div>
<p class="fsb pns cl hm">
	<button class="pn pnc" onclick="$('agreebbrule').checked = true;hideMenu('fwin_dialog', 'dialog');{if $this->setting['sitemessage'][register] && ($bbrules && $bbrulesforce)}showRegprompt();{/if}"><span>{lang agree}</span></button>
	<button class="pn" onclick="location.href='$_G[siteurl]'"><span>{lang disagree}</span></button>
</p>
</div>

<script type="text/javascript">
var ignoreEmail = <!--{if $_G['setting']['forgeemail']}-->true<!--{else}-->false<!--{/if}-->;
<!--{if $bbrules && $bbrulesforce}-->
	showBBRule();
<!--{/if}-->
<!--{if $this->showregisterform}-->
	<!--{if $sendurl}-->
	addMailEvent($('{$this->setting['reginput']['email']}'));
	<!--{else}-->
	addFormEvent('registerform', <!--{if $_GET[action] != 'activation' && !($bbrules && $bbrulesforce) && !empty($invitecode)}-->1<!--{else}-->0<!--{/if}-->);
	<!--{/if}-->
	<!--{if $this->setting['sitemessage'][register]}-->
		function showRegprompt() {
			showPrompt('custominfo_register', 'mouseover', '<!--{echo trim($this->setting['sitemessage'][register][array_rand($this->setting['sitemessage'][register])])}-->', $this->setting['sitemessage'][time]);
		}
		<!--{if !($bbrules && $bbrulesforce)}-->
			showRegprompt();
		<!--{/if}-->
	<!--{/if}-->
	function showBBRule() {
		showDialog($('layer_bbrule').innerHTML, 'info', '<!--{echo addslashes($this->setting['bbname']);}--> {lang rulemessage}');
		$('fwin_dialog_close').style.display = 'none';
	}
<!--{/if}-->
</script>

	</div></div>
</div>

<!--{eval updatesession();}-->
<!--{template common/member-footer}-->
