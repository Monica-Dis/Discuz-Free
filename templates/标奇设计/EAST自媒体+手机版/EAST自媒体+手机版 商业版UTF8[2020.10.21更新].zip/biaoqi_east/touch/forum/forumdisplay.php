<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>	
<!--{template common/header}-->
<!-- header start -->

<div class="banner">
<div class="banner-l cl">
<div class="banner-img" style="height: 61px;"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" title="$_G['forum'][name]"><img alt="$_G['forum'][name]" src="<!--{if $_G['forum'][icon]}-->data/attachment/common/$_G['forum'][icon]<!--{else}-->$_G['style']['styleimgdir']/touch/img/forum.gif<!--{/if}-->"  class="imgshow" /></a></div>
<div class="banner-info">
<h3 class="title">$_G['forum']['name']</h3>
<p class="biaoqicnposts">
   <span>主题: <em>$_G[forum][threads]</em></span> / 
    <span>帖子: <em>$_G[forum][posts]</em></span>
</p>
</div>
</div>

<div class="banner-r">
   <a href="forum.php?mod=post&action=newthread&fid=$_G['fid']" title="{lang send_threads}" style="margin-bottom: 8px;">发新帖</a>
   <a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" style="background: #00AF9D;">加关注</a>
</div>

</div>

<div class="biaoqicn_thread_types" style="margin-bottom: 10px;">
     <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter={if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == ''} a{/if}">全部内容</a>
     <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'lastpost'}a{/if}">最新发表</a>   
     <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'heat'}a{/if}">热门主题</a>				
     <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'digest'}a{/if}" style="border-right: 0;">精华主题</a>	
</div>

<!--{if $subexists && $_G['page'] == 1 || ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
    <div class="biaoqicn_zbk">
        <!--{if $subexists && $_G['page'] == 1}-->
        <ul class="cl">
            <li class="tit">子版块</li>
		    <!--{loop $sublist $sub}-->
		    <li><a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a></li>
		    <!--{/loop}-->
		</ul>
        <!--{/if}-->

        <!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
        <ul class="cl">
						<li id="ttp_all" {if !$_GET['typeid'] && !$_GET['sortid']}class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" style="padding: 0;">{lang forum_viewall}</a></li>
						<!--{if $_G['forum']['threadtypes']}-->
							<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
								<!--{if $_GET['typeid'] == $id}-->
								<li class="a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name</a></li>
								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name</a></li>
								<!--{/if}-->
							<!--{/loop}-->
						<!--{/if}-->
						<!--{if $_G['forum']['threadsorts']}-->
							<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
								<!--{if $_GET['sortid'] == $id}-->
								<li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
								<!--{/if}-->
							<!--{/loop}-->
						<!--{/if}-->
         </ul>
        <!--{/if}-->
	</div>
  <!--{/if}-->

<!-- header end -->


<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->

<!--{if $_G['forum_threadcount']}-->

<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
<!--{if !$subforumonly}-->
<div class="biaoqicn_threadlist">
			<!--{if $_G['forum_threadcount']}-->
				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->

                	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->

					<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->

<article>  
<!--{hook/forumdisplay_thread_mobile $key}-->
 <div class="title-box">
     <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="artTitle" title="$thread[subject]">$thread[subject]</a>
     <span class="marks">
		 <!--{if $thread[heatlevel]}-->
			<img  class="marking" src="$_G['style'][styleimgdir]/hot.png" align="absmiddle" alt="heatlevel" title="{lang heats}: {$thread[heats]}" />
		 <!--{/if}-->	           
         <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
			<img class="marking" src="$_G['style']['styleimgdir']/pin.gif" alt="置顶帖子" title="置顶帖子" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['attachment'] == 2}-->
			<img class="marking" src="$_G['style']['styleimgdir']/image_s.png" alt="附件图片" title="附件图片" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['digest'] > 0}-->
			<img class="marking" src="$_G['style']['styleimgdir']/digest.png" alt="精华" title="精华" align="absmiddle" />
		 <!--{/if}-->
	 </span>
 </div>

 <div class="artHeader">
    <a href="{if $_G[uid] == $thread[authorid]}home.php?mod=space&uid={$thread[authorid]}&do=profile&mycenter=1{else}home.php?mod=space&uid={$thread[authorid]}&do=profile{/if}" class="artAvatar">
       <!--{avatar($thread[authorid],middle)}-->       
    </a>
    <div class="auth_msg cl">
		<a href="{if $_G[uid] == $thread[authorid]}home.php?mod=space&uid={$thread[authorid]}&do=profile&mycenter=1{else}home.php?mod=space&uid={$thread[authorid]}&do=profile{/if}}" class="user_name">$thread[author]</a>
        <p><a class="time txt">$thread[dateline]</a></p>
	    <span class="numb msg"><i class="iconfont biaoqicn-huifu"></i>{$thread[replies]}</span>
		<span class="numb view"><i class="iconfont biaoqicn-chakan"></i>{$thread[views]}</span>
	</div>
 </div>
</article>
        <!--{/loop}-->
      <!--{else}-->
	<li>{lang forum_nothreads}</li>
  <!--{/if}-->
</div>
$multipage
<!--{/if}-->


<!--{else}-->
<div class="wrapper">
	<ul class="wall">
		<!--{loop $_G['forum_threadlist'] $key $thread}-->
			<!--{if $_G['hiddenexists'] && $thread['hidden']}-->
				<!--{eval continue;}-->
			<!--{/if}-->
			<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
				<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
					<!--{eval $thread[tid]=$thread[closed];}-->
				<!--{/if}-->
			<!--{/if}-->
		<li class="article">
			<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]">
				<!--{if $thread['cover']}-->
					<img src="$thread[coverpath]" alt="$thread[subject]" />
				<!--{else}-->
					<span class="nopic"></span>
				<!--{/if}-->
			<p>$thread[subject]</p>

			   <div class="auth cl">
                   <a href="{if $_G[uid] == $thread[authorid]}home.php?mod=space&uid={$thread[authorid]}&do=profile&mycenter=1{else}home.php?mod=space&uid={$thread[authorid]}&do=profile{/if}" class="z"><i class="icon-user"></i>$thread[author]</a>
                   <em><i class="icon-xiaoxi"></i>$thread[replies]</em> 
                   <em><i class="icon-chakan"></i>$thread[views]&nbsp;&nbsp;&nbsp;</em> 
               </div>
			</a>
		</li>
		<!--{/loop}-->
	</ul>
</div>
<div style="clear:both"></div>
   $multipage
<!--{/if}-->

<!--{else}-->  <!--如果 帖子总数是 false 或 0-->
<div style=" margin-bottom: 5px;">
   <a href="forum.php?mod=post&action=newthread&fid=$_G['fid']"><img src="$_G['style']['styleimgdir']/touch/img/biaoqicn_nothread.png" /></a>
</div>
<!--{/if}--> 

<script src="$_G['style']['styleimgdir']/touch/js/jaliswall.js" type="text/javascript"></script>
<script type="text/javascript">
	jQuery(function(){
		jQuery('.wall').jaliswall({ item: '.article' });
	});
</script>
<!-- main threadlist end -->
<!--{hook/forumdisplay_bottom_mobile}-->
<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}-->