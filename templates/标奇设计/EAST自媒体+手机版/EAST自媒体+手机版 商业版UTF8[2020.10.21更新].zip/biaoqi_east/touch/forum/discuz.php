<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>	
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:portal.php?mod=index&mobile=2');exit;}-->
<!--{/if}-->
<!--{template common/header}-->

<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<!--{if $_GET['visitclient']}-->

<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->

<!--{hook/index_top_mobile}-->
<!-- main forumlist start -->
<div class="biaoqicncn_listx wp" id="biaoqicncn_list">
	<!--{loop $catlist $key $cat}-->
	<div class="biaoqicncn_fm fl">
		<div class="subforumshow bm_h cl" href="#sub_forum_$cat[fid]">
			<span class="o"><img src="$_G['style']['styleimgdir']/touch/img/collapsed_<!--{if !$_G[setting][mobile][mobileforumview]}-->yes<!--{else}-->no<!--{/if}-->.png"></span>
		<h2><a href="javascript:;">$cat[name]</a></h2>
		</div>
		<div id="sub_forum_$cat[fid]" class="sub_forum">
			<ul class="cl">
				<!--{loop $cat[forums] $forumid}-->
					<!--{eval $forum=$forumlist[$forumid];}-->

					<li class="cl">	
						<!--{if $forum[icon]}-->
						<!--{eval $forum[icon] = str_replace('left', 'center', $forum[icon]);}-->
							$forum[icon]
						<!--{else}-->
							<img src="$_G['style']['styleimgdir']/touch/img/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" align="center" />
						<!--{/if}-->

						<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="biaoqicn_ico_right">
						   <p>{$forum[name]}</p>
						</a>
                         				
					</li>

				<!--{/loop}-->
			 </ul>
		</div>
	</div>
	<!--{/loop}-->
</div>
<!-- main forumlist end -->
<!--{hook/index_middle_mobile}-->
<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			$('.sub_forum').css('display', 'block');
		<!--{else}-->
			$('.sub_forum').css('display', 'none');
		<!--{/if}-->
		$('.subforumshow').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
				obj.find('img').attr('src', '$_G['style']['styleimgdir']/touch/img/collapsed_yes.png');
			} else {
				subobj.css('display', 'none');
				obj.find('img').attr('src', '$_G['style']['styleimgdir']/touch/img/collapsed_no.png');
			}
		});
	 })();
</script>

<!--{/if}-->
<!--{template common/footer}-->
