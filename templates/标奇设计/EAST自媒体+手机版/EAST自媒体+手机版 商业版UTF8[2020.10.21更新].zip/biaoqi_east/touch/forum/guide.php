<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>	
<!--{template common/header}-->

<!-- main threadlist start -->

	<div class="biaoqicn_thread_types">
		<a href="forum.php?mod=guide&view=newthread" class="{if $view == 'newthread'}a{/if}">{lang guide_newthread}</a>		
        <a href="forum.php?mod=guide&view=new" class="{if $view == 'new'}a{/if}">{lang guide_new}</a>	
     	<a href="forum.php?mod=guide&view=hot" class="{if $view == 'hot'}a{/if}">{lang guide_hot}</a>
		<a href="forum.php?mod=guide&view=digest" class="{if $view == 'digest'}a{/if}">{lang guide_digest}</a>     
    </div>

<div style="clear:both"></div>

<div class="biaoqicn_threadlist">
<!--{if $view == 'index'}-->

<!-------------------------------------最新主题------------------------------------->  
  <!--{elseif $view == 'newthread'}-->   
    <!--{loop $data $key $list}-->
    <!--{eval //var_dump($list['threadlist']);}-->                   
                <!--{if $list['threadcount']}-->					 			
                    <!--{loop $list['threadlist'] $thread}-->
                    <!--{if $key == 'newthread'}-->
<article>  

 <div class="title-box">
     <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="artTitle" title="$thread[subject]">$thread[subject]</a>
     <span class="marks">
		 <!--{if $thread[heatlevel]}-->
			<img  class="marking" src="$_G['style'][styleimgdir]/touch/img/hot.png" align="absmiddle" alt="heatlevel" title="{lang heats}: {$thread[heats]}" />
		 <!--{/if}-->	           
         <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/pin.gif" alt="置顶帖子" title="置顶帖子" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['attachment'] == 2}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/image_s.png" alt="附件图片" title="附件图片" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['digest'] > 0}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/digest.png" alt="精华" title="精华" align="absmiddle" />
		 <!--{/if}-->
	 </span>
 </div>

 <div class="artHeader">
    <a href="home.php?mod=space&uid={authorid}" class="artAvatar">
       <img src="uc_server/avatar.php?uid=$thread[authorid]&size=middle" alt="$thread[author]">        
    </a>
    <div class="auth_msg clearfix">
		<a href="{if $_G[uid] == $thread[authorid]}home.php?mod=space&uid={$thread[authorid]}&do=profile&mycenter=1{else}home.php?mod=space&uid={$thread[authorid]}&do=profile{/if}" class="user_name" target="_blank">$thread[author]</a>
        <p><a class="time txt">$thread[dateline]</a></p>
	    <span class="numb msg"><i class="iconfont biaoqicn-huifu"></i>{$thread[replies]}</span>
		<span class="numb view"><i class="iconfont biaoqicn-chakan"></i>{$thread[views]}</span>
	</div>
 </div>
</article>

<!--{/if}-->
<!--{/loop}-->

$multipage

<!--{else}-->
<li class="wmt brtb" style=" margin: 15px 0; padding: 20px 10px; border: 0;font-size: 14px; text-align: center;">{lang guide_nothreads}</li>			 		
<!--{/if}-->                            
<!--{/loop}-->  

<!-------------------------------------最新回复------------------------------------->  
	<!--{elseif $view == 'new'}-->   
    <!--{loop $data $key $list}-->
    <!--{eval //var_dump($list['threadlist']);}-->                   
                <!--{if $list['threadcount']}-->					 			
                    <!--{loop $list['threadlist'] $thread}-->
                    <!--{if $key == 'new'}-->
<article>  

 <div class="title-box">
     <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="artTitle" title="$thread[subject]">$thread[subject]</a>
     <span class="marks">
		 <!--{if $thread[heatlevel]}-->
			<img  class="marking" src="$_G['style'][styleimgdir]/img/hot.png" align="absmiddle" alt="heatlevel" title="{lang heats}: {$thread[heats]}" />
		 <!--{/if}-->	           
         <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/pin.gif" alt="置顶帖子" title="置顶帖子" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['attachment'] == 2}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/image_s.png" alt="附件图片" title="附件图片" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['digest'] > 0}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/digest.png" alt="精华" title="精华" align="absmiddle" />
		 <!--{/if}-->
	 </span>
 </div>

 <div class="artHeader">
    <a href="home.php?mod=space&uid={authorid}" class="artAvatar">
       <img src="uc_server/avatar.php?uid=$thread[authorid]&size=middle" alt="$thread[author]">        
    </a>
    <div class="auth_msg clearfix">
		<a href="{if $_G[uid] == $thread[authorid]}home.php?mod=space&uid={$thread[authorid]}&do=profile&mycenter=1{else}home.php?mod=space&uid={$thread[authorid]}&do=profile{/if}" class="user_name" target="_blank">$thread[author]</a>
        <p><a class="time txt">$thread[dateline]</a></p>
	    <span class="numb msg"><i class="iconfont biaoqicn-huifu"></i>{$thread[replies]}</span>
		<span class="numb view"><i class="iconfont biaoqicn-chakan"></i>{$thread[views]}</span>
	</div>
 </div>
</article>

<!--{/if}-->
<!--{/loop}-->

$multipage

<!--{else}-->
<li class="wmt brtb" style=" margin: 15px 0; padding: 20px 10px; border: 0;font-size: 14px; text-align: center;">{lang guide_nothreads}</li>			 		
<!--{/if}-->                            
<!--{/loop}-->  

<!-------------------------------------最新热门------------------------------------->  

<!--{elseif $view == 'hot'}-->
    <!--{loop $data $key $list}-->                           
             <!--{if $list['threadcount']}-->					 			
                 <!--{loop $list['threadlist'] $thread}-->
                    <!--{if $key == 'hot'}-->
<article>  

 <div class="title-box">
     <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="artTitle" title="$thread[subject]">$thread[subject]</a>
     <span class="marks">
		 <!--{if $thread[heatlevel]}-->
			<img  class="marking" src="$_G['style'][styleimgdir]/img/hot.png" align="absmiddle" alt="heatlevel" title="{lang heats}: {$thread[heats]}" />
		 <!--{/if}-->	           
         <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/pin.gif" alt="置顶帖子" title="置顶帖子" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['attachment'] == 2}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/image_s.png" alt="附件图片" title="附件图片" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['digest'] > 0}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/digest.png" alt="精华" title="精华" align="absmiddle" />
		 <!--{/if}-->
	 </span>
 </div>

 <div class="artHeader">
    <a href="home.php?mod=space&uid={authorid}" class="artAvatar">
       <img src="uc_server/avatar.php?uid=$thread[authorid]&size=middle" alt="$thread[author]">        
    </a>
    <div class="auth_msg clearfix">
		<a href="{if $_G[uid] == $thread[authorid]}home.php?mod=space&uid={$thread[authorid]}&do=profile&mycenter=1{else}home.php?mod=space&uid={$thread[authorid]}&do=profile{/if}" class="user_name" target="_blank">$thread[author]</a>
        <p><a class="time txt">$thread[dateline]</a></p>
	    <span class="numb msg"><i class="iconfont biaoqicn-huifu"></i>{$thread[replies]}</span>
		<span class="numb view"><i class="iconfont biaoqicn-chakan"></i>{$thread[views]}</span>
	</div>
 </div>
</article>

<!--{/if}-->
<!--{/loop}-->

$multipage

<!--{else}-->
<li class="wmt brtb" style=" margin: 15px 0; padding: 20px 10px; border: 0;font-size: 14px; text-align: center;">{lang guide_nothreads}</li>				 		
<!--{/if}-->                            
<!--{/loop}-->  


<!-------------------------------------最新精华------------------------------------->  

<!--{elseif $view == 'digest'}-->
    <!--{loop $data $key $list}-->                    
                <!--{if $list['threadcount']}-->					 			
                    <!--{loop $list['threadlist'] $thread}-->
                    <!--{if $key == 'digest'}-->
<article>  
 <div class="title-box">
     <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="artTitle" title="$thread[subject]">$thread[subject]</a>
     <span class="marks">
		 <!--{if $thread[heatlevel]}-->
			<img  class="marking" src="$_G['style'][styleimgdir]/img/hot.png" align="absmiddle" alt="heatlevel" title="{lang heats}: {$thread[heats]}" />
		 <!--{/if}-->	           
         <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/pin.gif" alt="置顶帖子" title="置顶帖子" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['attachment'] == 2}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/image_s.png" alt="附件图片" title="附件图片" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['digest'] > 0}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/digest.png" alt="精华" title="精华" align="absmiddle" />
		 <!--{/if}-->
	 </span>
 </div>

 <div class="artHeader">
    <a href="home.php?mod=space&uid={authorid}" class="artAvatar">
       <img src="uc_server/avatar.php?uid=$thread[authorid]&size=middle" alt="$thread[author]">        
    </a>
    <div class="auth_msg clearfix">
		<a href="{if $_G[uid] == $thread[authorid]}home.php?mod=space&uid={$thread[authorid]}&do=profile&mycenter=1{else}home.php?mod=space&uid={$thread[authorid]}&do=profile{/if}" class="user_name" target="_blank">$thread[author]</a>
        <p><a class="time txt">$thread[dateline]</a></p>
	    <span class="numb msg"><i class="iconfont biaoqicn-huifu"></i>{$thread[replies]}</span>
		<span class="numb view"><i class="iconfont biaoqicn-chakan"></i>{$thread[views]}</span>
	</div>
 </div>
</article>

<!--{/if}-->
<!--{/loop}-->

$multipage

<!--{else}-->
<li class="wmt brtb" style=" margin: 15px 0; padding: 20px 10px; border: 0;font-size: 14px; text-align: center;">{lang guide_nothreads}</li>			 		
<!--{/if}-->                            
<!--{/loop}-->  

<!--{/if}-->
</div>

<!-- main threadlist end -->

<!--{template common/footer}-->
