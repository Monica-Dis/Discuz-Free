<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>	

<!--{template common/header}-->
<div class="biaoqicn_forumlist cl">

	<ul>

		<!--{loop $_G['cache']['forums'] $forum}-->

		<!--{if $forum['type'] != 'group' && $forum['status'] > 0 && !$forum['viewperm'] && !$forum['havepassword']}-->

		<li><a href="forum.php?mod=post&action=newthread&fid=$forum[fid]">$forum[name]</a></li>

		<!--{/if}-->

		<!--{/loop}-->

	</ul>

</div>

<!--{template common/footer}-->