<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->
<link rel="stylesheet" href="$_G['style']['styleimgdir']/touch/css/sign.css?{VERHASH}" type="text/css" media="all">

{eval $loginhash = 'L'.random(4);}

<header class="log_header">
  <div class="nav">
    <a href="javascript:history.go(-1);" class="menu-z"><i class="iconfont biaoqicn-fanhui" style="color: #fff;"></i></a>
    <h2 class="tit">登录</h2>
  </div>
</header>

<!-- userinfo start -->
<div class="login" style="margin: 0;">
	<div class="member-logo"></div>
	<form id="loginform" method="post" action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
		<input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
		<input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
		<input type="hidden" name="fastloginfield" value="username">
		<input type="hidden" name="cookietime" value="2592000">
		<!--{if $auth}-->
			<input type="hidden" name="auth" value="$auth" />
		<!--{/if}-->
	
		<!-- 登录区域 -->
		<div id="web_login" style="display: block;">
			<ul id="g_list">
				<li id="g_u">
					<input type="text" class="inputstyle" autocomplete="off" name="username" placeholder="{lang inputyourname}">
				</li>
				<li id="g_p">
					<input type="password" class="inputstyle" maxlength="16" autocorrect="off" name="password" placeholder="{lang login_password}">
				</li>
				<li class="bl_none questionli">
					<select id="questionid_{$loginhash}" name="questionid" class="inputstyle sel_list">
						<option value="0" selected="selected">{lang security_question}</option>
						<option value="1">{lang security_question_1}</option>
						<option value="2">{lang security_question_2}</option>
						<option value="3">{lang security_question_3}</option>
						<option value="4">{lang security_question_4}</option>
						<option value="5">{lang security_question_5}</option>
						<option value="6">{lang security_question_6}</option>
						<option value="7">{lang security_question_7}</option>
					</select>
				</li>
				<li class="bl_none answerli" style="display:none;"><input type="text" name="answer" id="answer_{$loginhash}" class="inputstyle" size="30" placeholder="{lang security_a}"></li>
				<!--{if $seccodecheck}-->
				<!--{subtemplate common/seccheck}-->
				<!--{/if}-->
			</ul>
	
			<div class="btn_login"><button id="sendlogin" tabindex="3" value="true" name="submit" type="submit">{lang login}</button></div>	
			
			<div class="biaoqicn_reg">
			    <a href="member.php?mod={$_G[setting][regname]}">还没有注册？></a>
			</div>
		</div>
	</form>

	<!-- 切换登录区域 -->

	<div class="log_connect">
		 <div class="horizontal divider"><i>使用第三方帐号登录</i></div>

			<div class="third-login">
			    <a href="$_G[connect][login_url]&statfrom=login_simple" class="qq"></a>
			    <a href="#" class="wx"></a>
			</div>

		</div>	
    </div>
<!--{hook/logging_bottom_mobile}-->
<!-- userinfo end -->

<!--{if $_G['setting']['pwdsafety']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<!--{/if}-->


<script type="text/javascript">
	(function() {
		$(document).on('change', '.sel_list', function() {
			var obj = $(this);
			$('.span_question').text(obj.find('option:selected').text());
			if(obj.val() == 0) {
				$('.answerli').css('display', 'none');
				$('.questionli').addClass('bl_none');
			} else {
				$('.answerli').css('display', 'block');
				$('.questionli').removeClass('bl_none');
			}
		});
	 })();
</script>
<!--{template common/footer}-->
