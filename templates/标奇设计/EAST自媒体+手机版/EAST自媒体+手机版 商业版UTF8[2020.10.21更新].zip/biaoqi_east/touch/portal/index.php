<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{block/1111}-->

<!--{block/2222}-->

<!--{block/3333}-->

<!--{block/4444}-->

<!--{block/5555}-->

<!--{block/6666}-->

<!--{block/7777}-->

<script type="text/javascript" src="$_G['style']['styleimgdir']/touch/js/swipe.min.js"></script>

<!--{template common/footer}-->