<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $tagname}-->

<!--{if empty($showtype) || $showtype == 'thread'}-->

<!--{if $threadlist}-->
<div class="biaoqicn_tag_list">
	<ul>
		<!--{loop $threadlist $thread}-->
           <li><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="artTitle" title="$thread[subject]">{$thread[subject]}</a></li>
		<!--{/loop}-->
    </ul>
</div>
<!--{if $multipage}--><div class="page cl">$multipage</div><!--{/if}-->

<!--{else}-->

<div class="biaoqicn_no_tag">无内容或被删除了</div>

<!--{/if}-->

<!--{/if}-->

<!--{else}-->

<div class="biaoqicn_no_tag">无内容或被删除了</div>
<!--{/if}-->

<!--{template common/footer}-->