<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $type != 'countitem'}-->

  <div class="biaoqicn_tag_search">
      <form method="post" action="misc.php?mod=tag" class="pns">
		<table width="100%" cellspacing="0" cellpadding="0">
		   <tbody>
		      <tr>
		        <td><input type="text" name="name" class="input" placeholder="{lang tag}" /></td>
                <td align="right" width="75"><button type="submit" class="button2">{lang search}</button></td>
		      </tr>
		   </tbody>
		</table>
      </form>
   </div>

<!--{if $tagarray}-->
    <div class="taglist cl"> 
        <!--{loop $tagarray $tag}--> 
		<li class="biaoqicn_tag">
            <a href="misc.php?mod=tag&id=$tag[tagid]">$tag[tagname]</a> 
		</li>
        <!--{/loop}--> 
    </div>
<!--{else}-->
  <div class="wmt brtb notb">{lang no_tag}</div>
<!--{/if}--> 

<!--{else}--> 
$num 
<!--{/if}--> 


<!--{template common/footer}-->