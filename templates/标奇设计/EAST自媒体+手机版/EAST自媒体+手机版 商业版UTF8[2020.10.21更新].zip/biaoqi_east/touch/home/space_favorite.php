<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->
<!-- header start -->

<!--{template home/space_top}-->

<div class="userinfo">
	<div class="myinfo_list cl">
		<ul>
		    <li><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}">{lang myprofile}</a></li>
			<li class="on"><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang myfavorite}</a></li>
			<li><a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me">{lang mythread}</a></li>
			<li><a href="home.php?mod=space&do=pm">{lang mypm}<!--{if $_G[member][newpm]}--><img src="{STATICURL}image/mobile/images/icon_msg.png" /><!--{/if}--></a></li>
		</ul>
	</div>

<!-- main collectlist start -->
<!--{if $_GET['type'] == 'forum'}-->
<div class="coll_list b_radius">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li><a href="$value[url]">$value[title]</a></li>
			<!--{/loop}-->
		<!--{else}-->
		<li>{lang no_favorite_yet}</li>
		<!--{/if}-->

	</ul>
</div>
<!--{else}-->
<div class="threadlist biaoqicn_user_li" style="padding: 0 10px 20px;">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li><a href="$value[url]">$value[title]</a></li>
			<!--{/loop}-->
		<!--{else}-->
		<li><a style="font-size: 14px; text-align: center;">您还没有添加任何收藏</a></li>
		<!--{/if}-->
	</ul>
</div>
<!--{/if}-->
<!-- main collectlist end -->
$multi

</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
