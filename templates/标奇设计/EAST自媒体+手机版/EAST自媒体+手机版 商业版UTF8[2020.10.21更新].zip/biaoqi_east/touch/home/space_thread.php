<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->

<!-- header start -->

<!--{template home/space_top}-->

<div class="userinfo">
	<div class="myinfo_list cl">
		<ul>
		    <li><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}">{lang myprofile}</a></li>
			<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang myfavorite}</a></li>
			<li class="on"><a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me">{lang mythread}</a></li>
			<li><a href="home.php?mod=space&do=pm">{lang mypm}<!--{if $_G[member][newpm]}--><img src="{STATICURL}image/mobile/images/icon_msg.png" /><!--{/if}--></a></li>
		</ul>
	</div>

<!-- header end -->
<!-- main threadlist start -->
<div class="threadlist biaoqicn_threadlist">
	<!--{if $list}-->
		<!--{loop $list $thread}-->

<article>  
<!--{hook/forumdisplay_thread_mobile $key}-->
 <div class="title-box">
     <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="artTitle" title="$thread[subject]">$thread[subject]</a>
     <span class="marks">
		 <!--{if $thread[heatlevel]}-->
			<img  class="marking" src="$_G['style'][styleimgdir]/img/hot.png" align="absmiddle" alt="heatlevel" title="{lang heats}: {$thread[heats]}" />
		 <!--{/if}-->	           
         <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/pin.gif" alt="置顶帖子" title="置顶帖子" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['attachment'] == 2}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/image_s.png" alt="附件图片" title="附件图片" align="absmiddle" />
		 <!--{/if}-->
         <!--{if $thread['digest'] > 0}-->
			<img class="marking" src="$_G['style']['styleimgdir']/touch/img/digest.png" alt="精华" title="精华" align="absmiddle" />
		 <!--{/if}-->
	 </span>
 </div>

 <div class="artHeader">
    <a href="home.php?mod=space&uid={authorid}" class="artAvatar">
       <img src="uc_server/avatar.php?uid=$thread[authorid]&size=middle" alt="$thread[author]">        
    </a>
    <div class="auth_msg clearfix">
		<a href="home.php?mod=space&uid={authorid}" class="user_name" target="_blank">$thread[author]</a>
        <p><a class="time txt">$thread[dateline]</a></p>
	    <span class="numb msg"><i class="iconfont biaoqicn-huifu"></i>{$thread[replies]}</span>
		<span class="numb view"><i class="iconfont biaoqicn-chakan"></i>{$thread[views]}</span>
	</div>
 </div>
</article>


		<!--{/loop}-->
	<!--{else}-->
		<li style="padding: 10px; font-size: 14px; text-align: center;">{lang no_related_posts}</li>
	<!--{/if}-->
	$multi
</div>
</div>
<!-- main threadlist end -->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
