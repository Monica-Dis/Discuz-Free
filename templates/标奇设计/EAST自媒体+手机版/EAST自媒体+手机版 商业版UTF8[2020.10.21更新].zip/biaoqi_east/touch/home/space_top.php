<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>

<div id="userHome">
    <div id="userBody">

	       <div id="usernu">
	           <div id="uheadimg">
		           <img src="<!--{avatar($_G[uid], middle, true)}-->" width="76" height="76" />
			   </div>
		       <div id="unickname"><span class="ellipsis">$_G[username]</span></div>
           </div>
<!--{eval $biaoqicnuid = $space[uid];}-->
<!--{eval $biaoqicn_count = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid=$biaoqicnuid");}-->
	
    <ul id="usercount">
	   <li><p>$biaoqicn_count['follower']</p>粉丝</li>
	   <li><p>$biaoqicn_count['following']</p>关注</li>
	   <li><p>$biaoqicn_count[views]</p>人气</li>
	</ul>

  </div>
</div>