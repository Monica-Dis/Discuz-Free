<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->

<!-- userinfo start -->

<!--{template home/space_top}-->

<div class="userinfo">
	<div class="myinfo_list cl">
		<ul>
		    <li class="on"><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}">{lang myprofile}</a></li>
			<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang myfavorite}</a></li>
			<li><a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me">{lang mythread}</a></li>
			<li><a href="home.php?mod=space&do=pm">{lang mypm}<!--{if $_G[member][newpm]}--><img src="{STATICURL}image/mobile/images/icon_msg.png" /><!--{/if}--></a></li>
		</ul>
	</div>

    <div class="biaoqicn_user_box" style="margin-top: 10px;">
		<ul>
			<li><span>$space[credits]</span>{lang credits}</li>
			<!--{loop $_G[setting][extcredits] $key $value}-->
			<!--{if $value[title]}-->
			<li><span>{$space["extcredits$key"]} $value[unit]</span>$value[title]</li>
			<!--{/if}-->
			<!--{/loop}-->
		</ul>
    </div>

<div class="biaoqicn_user_box">

<div class="pbm bbda cl">
	<ul>
		<!--{if $space[adminid]}--><li><em class="xg1">{lang management_team}&nbsp;&nbsp;</em><span style="color:{$space[admingroup][color]}"><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[adminid]" >{$space[admingroup][grouptitle]}</a></span> {$space[admingroup][icon]}</li><!--{/if}-->
		<li><em class="xg1">{lang usergroup}&nbsp;&nbsp;</em><span style="color:{$space[group][color]}"{if $upgradecredit !== false} class="xi2" onmouseover="showTip(this)" tip="{lang credits} $space[credits], {lang thread_groupupgrade} $upgradecredit {lang credits}"{/if}><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[groupid]" >{$space[group][grouptitle]}</a></span> {$space[group][icon]} <!--{if !empty($space['groupexpiry'])}-->&nbsp;{lang group_useful_life}&nbsp;<!--{date($space[groupexpiry], 'Y-m-d H:i')}--><!--{/if}--></li>
		<!--{if $space[extgroupids]}--><li><em class="xg1">{lang group_expiry_type_ext}&nbsp;&nbsp;</em>$space[extgroupids]</li><!--{/if}-->
	</ul>
	<ul id="pbbs" class="pf_l">
		<!--{if $space[oltime]}--><li>{lang online_time}<span>$space[oltime] {lang hours}</span></li><!--{/if}-->
		<li>{lang regdate}<span>$space[regdate]</span></li>
		<li>最后登录<span>$space[lastvisit]</span></li>		
	</ul>
</div>
</div>

	</div>
	<!--{if $space['uid'] == $_G['uid']}-->
	<div class="biaoqicn_btn_exit"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout_mobile}</a></div>
	<!--{/if}-->

</div>
<!-- userinfo end -->

