<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>	
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by Discuz!</title>
<link rel="stylesheet" href="{STATICURL}image/mobile/style.css" type="text/css" media="all">
<link rel="stylesheet" href="$_G['style']['styleimgdir']/touch/css/common.css?{VERHASH}" type="text/css" media="all">
<script src="$_G['style']['styleimgdir']/touch/js/jquery.min.js?{VERHASH}"></script>

<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>

<script src="{STATICURL}js/mobile/common.js?{VERHASH}" charset="{CHARSET}"></script>
<link rel="stylesheet" href="$_G['style']['styleimgdir']/touch/iconfont/iconfont.css" type="text/css">
<script src="$_G['style']['styleimgdir']/touch/js/biaoqicn.cn.js?{VERHASH}"></script>
<script src="$_G['style']['styleimgdir']/touch/js/TouchSlide.1.1.js?{VERHASH}"></script>
<script language="javascript" type="text/javascript">
     function killErrors() {
           return true;
       }
    window.onerror = killErrors;
</script>
</head>

<body>
<!--{hook/global_header_mobile}-->
  <div class="biaoqicn_top">
    <div class="header_btn">
	<!--{if CURSCRIPT == 'portal' && CURMODULE == 'index'}-->
	    <i class="iconfont biaoqicn-menu"></i>
	    <i class="iconfont biaoqicn-close"></i>
	<!--{else}-->
		 <a href="javascript:history.go(-1);"><i class="iconfont biaoqicn-fanhui"></i></a>
	<!--{/if}-->
	</div>
      
	  <!--{if CURSCRIPT == 'portal' && CURMODULE == 'index'}-->
	      <a class="logo" href="portal.php?mod=index&mobile=2"></a>
      <!--{elseif $_GET['mod'] == 'guide'}-->
		  <span>导读</span>
      <!--{elseif $_GET['mod'] == 'forumdisplay'}-->
          <span>{$_G['forum']['name']}</span>
      <!--{elseif $_GET['mod'] == 'viewthread'}-->
           <span>主题帖</span>
      <!--{elseif $_GET['mod'] == 'logging'}-->   
           <span>登录</span> 
      <!--{elseif $_GET['mod'] == 'tag'}-->   
           <span>标签</span>  
      <!--{elseif $_GET['mod'] == 'post'}-->
           <span>发表帖子</span>
      <!--{elseif $_G['basescript'] == 'search'}-->
           <span>搜索</span>
      <!--{elseif $_GET['do'] == 'pm'}-->
           <span>短消息</span>
      <!--{elseif $_GET['do'] == 'profile'}-->
           <span>个人中心</span>
	  <!--{elseif $_GET['do'] == 'favorite'}-->
           <span>收藏中心</span>
	  <!--{elseif $_GET['do'] == 'thread'}-->
           <span>帖子中心</span>
      <!--{elseif $_G['basescript'] == 'forum'}-->
           <span>版块导航</span>
      <!--{else}-->
           <span><a href="forum.php?mod=guide&view=hot">{$_G[setting][bbname]}</a></span>
      <!--{/if}-->	  

 <div class="icon_edit y">
 <!--{if $_G[uid]}-->
	  <a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="avatar">
	      <img src="<!--{avatar($_G[uid], middle, true)}-->" />
       </a>	  
  <!--{else}-->
		<a href="member.php?mod=logging&amp;action=login&amp;mobile=2" class="loginbtn" title="登录">登录</a> 
		<a href="member.php?mod=register&amp;mobile=2" class="registerbtn"title="立即注册">注册</a>
  <!--{/if}-->
  </div>

</div>

<div id="menu" class="top-menu">
   <div class="view"> 
	  <div class="biaoqicn_menu-main"> 
	     <h2><a href="portal.php?mod=index&mobile=2" class="v-link-active">网站首页</a></h2> 
		 <dl class="clearfix"> 
		    <dt>官方专区</dt> 
			<dd> <a rel="nofollow" href="#">官方动态</a> </dd>
			<dd> <a rel="nofollow" href="#">官方活动</a> </dd> 
		 </dl>
		 
		 <dl class="clearfix"> 
		    <dt>第一分区</dt> 
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
		 </dl>
		 
		 <dl class="clearfix"> 
		    <dt>第二分区</dt> 
		    <dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd> 
		 </dl>
		 
		 <dl class="clearfix"> 
		    <dt>第三分区</dt> 
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd>
			<dd> <a rel="nofollow" href="#">自定义</a> </dd> 
		 </dl> 
	</div> 
	
	    <ul class="biaoqicn_menu-sub clearfix"> 
		    <li> <a class="btn btn-cdkey" rel="nofollow" href="#"> 自定义 </a> </li> 
			<li> <a class="btn btn-service" rel="nofollow" href="#"> 自定义 </a> </li> 
			<li> <a class="btn btn-service" rel="nofollow" href="#"> 自定义 </a> </li> 
		</ul> 
	</div> 
</div>


</div>
</div>

<script type="text/javascript">
jQuery(document).ready(function(){
  jQuery(".header_btn").click(function(){
    jQuery("body").toggleClass("show-nav");
  });
});
</script>
