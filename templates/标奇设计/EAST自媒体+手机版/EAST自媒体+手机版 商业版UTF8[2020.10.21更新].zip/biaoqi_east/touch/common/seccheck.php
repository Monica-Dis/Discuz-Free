<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>	
{eval
	$sechash = 'S'.random(4);
	$sectpl = !empty($sectpl) ? explode("<sec>", $sectpl) : array('<br />',': ','<br />','');	
	$ran = random(5, 1);
}
<!--{if $secqaacheck}-->
<!--{eval
	$message = '';
	$question = make_secqaa();
	$secqaa = lang('core', 'secqaa_tips').$question;
}-->
<!--{/if}-->
<!--{if $sectpl}-->
	<!--{if $secqaacheck}-->
		<li class="quertion">
			<p>{lang secqaa}: <span class="xg2">$secqaa</span></p>
			<input name="secqaahash" type="hidden" value="$sechash" />
			<input name="secanswer" id="secqaaverify_$sechash" type="text" class="inputstyle" placeholder="请输入答案"/>
		</li>
	<!--{/if}-->
	<!--{if $seccodecheck}-->
		<li class="sec_code">
		<input name="seccodehash" type="hidden" value="$sechash" />
		<input type="text" class="inputstyle" style="width: 110px !important;margin-left: 0 !important; border-radius: 3px; background-color: #fff !important; border: 1px solid #ddd;" autocomplete="off" value="" id="seccodeverify_$sechash" name="seccodeverify" placeholder="{lang seccode}" fwin="seccode">
        <img src="misc.php?mod=seccode&update={$ran}&idhash={$sechash}&mobile=2" class="seccodeimg"/>
		</li>
	<!--{/if}-->
<!--{/if}-->
<script type="text/javascript">
	(function() {
		$('.seccodeimg').on('click', function() {
			$('#seccodeverify_$sechash').attr('value', '');
			var tmprandom = 'S' + Math.floor(Math.random() * 1000);
			$('.sechash').attr('value', tmprandom);
			$(this).attr('src', 'misc.php?mod=seccode&update={$ran}&idhash='+ tmprandom +'&mobile=2');
		});
	})();
</script>
