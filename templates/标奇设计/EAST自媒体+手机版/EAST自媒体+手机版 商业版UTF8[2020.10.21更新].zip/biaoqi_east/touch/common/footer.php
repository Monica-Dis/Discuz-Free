<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>	
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<div id="mask" style="display:none;"></div>

<!--{if !$nofooter}-->
<div class="footer">
	<div>
		<!--{if !$_G[uid] && !$_G['connectguest']}-->
		<a href="forum.php">{lang mobilehome}</a> | <a href="member.php?mod=logging&action=login" title="{lang login}">{lang login}</a> | <a href="<!--{if $_G['setting']['regstatus']}-->member.php?mod={$_G[setting][regname]}<!--{else}-->javascript:;" style="color:#D7D7D7;<!--{/if}-->" title="{$_G['setting']['reglinkname']}">{lang register}</a>
		<!--{else}-->
		<a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1">{$_G['member']['username']}</a> , <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" title="{lang logout}" class="dialog">{lang logout}</a>
		<!--{/if}-->
	</div>
    <div>
		<a href="{$_G['setting']['mobile']['simpletypeurl'][0]}">{lang no_simplemobiletype}</a> |  
		<a href="javascript:;" class="a">{lang mobile2version}</a> | 
		<a href="{$_G['setting']['mobile']['nomobileurl']}">{lang nomobiletype}</a> | 
		<!--{if $clienturl}--><a href="$clienturl">{lang clientversion}</a><!--{/if}-->
    </div>
	<p>&copy; Comsenz Inc.</p>
</div>
<!--{/if}-->
   
   <div class="biaoqicn_ftb"></div>

   <div class="biaoqicn_ft_fix">
        <ul>
            <li class="<!--{if CURSCRIPT == 'portal' && CURMODULE == 'index'}--> a{/if}"><a href="portal.php?mod=index&mobile=2"><i class="iconfont biaoqicn-shouye"></i>首页</a></li>
            <li class="{if CURSCRIPT !== 'portal' && $_GET['mod'] !== 'guide' && $_GET['mod'] !== 'space' && $_GET['mod'] !== 'forum' && $_GET['mod'] !== 'logging' && $_GET['mod'] !== 'post' && $_GET['action'] !== 'nav'} a{/if}"><a href="forum.php?forumlist=1"><i class="iconfont biaoqicn-bbs"></i>论坛</a></li>
            <li class="biaoqicn_post"><a href="<!--{if $_GET['mod'] == 'forumdisplay' || $_GET['mod'] == 'viewthread'}-->forum.php?mod=post&action=newthread&fid=$_G['fid']<!--{else}-->forum.php?mod=misc&action=nav<!--{/if}-->"><i class="iconfont biaoqicn-posts"></i></a></li>
            <li class="{if $_GET['mod'] == 'forum'} a{/if}"><a href="search.php?mod=forum"><i class="iconfont biaoqicn-search"></i>搜索</a></li>
            <li class="{if $_GET['mod'] == 'guide'} a{/if}"><a href="forum.php?mod=guide&view=newthread"><i class="iconfont biaoqicn-daodu"></i>导读</a></li>
        </ul>
   </div>

  <a href="javascript:;" title="{lang scrolltop}" class="biaoqicn_gotop scrolltop bottom"></a>


</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->
