<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<div class="biaoqicn_sousuo_threadlist">
	<h2 class="biaoqicn_sousuo_thread_tit cl"><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page" target="_blank">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	<!--{if empty($threadlist)}-->
	<ul class="biaoqicn_sousuo_txt cl"><li><a href="javascript:;">{lang search_nomatch}</a></li></ul>
	<!--{else}-->
			<ul class="biaoqicn_sousuo_txt cl">
				<!--{loop $threadlist $thread}-->
				<li>
					<a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank" $thread[highlight]>$thread[subject]</a>
				</li>
				<!--{/loop}-->
			</ul>
	<!--{/if}-->	
</div>

$multipage
