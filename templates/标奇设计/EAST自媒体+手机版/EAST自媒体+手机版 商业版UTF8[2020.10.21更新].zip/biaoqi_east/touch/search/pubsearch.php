<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<div class="search">
		<table width="100%" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td>
						<input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="请输入搜索关键词">
					</td>
				</tr>

				<tr>
					<td width="66" align="center" class="scbar_btn_td">
						<input type="hidden" name="searchsubmit" value="yes"><input type="submit" value="{lang search}" class="button2 post_msg_btn" id="scform_submit">
					</td>
				</tr>

				<tr>
<td>
<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}--> 
<!--{else}--> 
<!--{if $_G['setting']['srchhotkeywords']}-->
<div class="biaoqicn_hot_search">
<strong class="xw1" style="font-size: 16px;font-weight: 400;">热搜: </strong>
<p>
<!--{loop $_G['setting']['srchhotkeywords'] $val}--> 
<!--{if $val=trim($val)}--> 
<!--{eval $valenc=rawurlencode($val);}--> 
<!--{block srchhotkeywords[]}--> 
<!--{if !empty($searchparams[url])}--> 
<a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}">$val</a> 
<!--{else}--> 
<a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch">$val</a> 
<!--{/if}--> 
<!--{/block}--> 
<!--{/if}--> 
<!--{/loop}--> 
</p>
<!--{echo implode('', $srchhotkeywords);}--> 
</div>
<!--{/if}--> 
<!--{/if}--> 
</td>
</tr>
			</tbody>
		</table>
</div>
