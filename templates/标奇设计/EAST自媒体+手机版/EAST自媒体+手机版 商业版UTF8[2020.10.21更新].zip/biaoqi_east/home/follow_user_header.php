<?PHP exit('��֧������ - ���洴�� http://dism.taobao.com/?@68363.developer');?>
<div class="flw_hd biaoqi_flw">
	<!--{if helper_access::check_module('follow')}-->
	<div class="tns">
         <p>
		    <a href="home.php?mod=follow&uid=$uid&do=view" class="xi2 xw1">{lang follow}($space['feeds'])</a>

		    <a href="home.php?mod=follow&do=following&uid=$uid" class="xi2 xw1">{lang follow_add}($space['following'])</a>
		 
		    <a href="home.php?mod=follow&do=follower&uid=$uid" id="followernum_$uid" class="xi2 xw1">{lang follow_follower}($space['follower'])</a>
		</p>

	</div>
	<!--{/if}-->
<!--{if !$viewself}-->
	<div class="mtm o cl">
		<div id="followflag" {if !isset($flag[$_G['uid']])}style="display: none"{/if}>
			<!--{if helper_access::check_module('follow')}-->
			<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&special={if $flag[$_G['uid']]['status'] == 1}2{else}1{/if}&fuid=$uid&from=head" class="{if $flag[$_G['uid']]['status'] == 1}flw_specialunfo{else}flw_specialfo{/if}" id="specialflag_$uid" onclick="ajaxget(this.href);doane(event);" title="{if $flag[$_G['uid']]['status'] == 1}{lang follow_del_special_following}{else}{lang follow_add_special_following}{/if}"><!--{if $flag[$_G['uid']]['status'] == 1}-->ȡ���ر�����<!--{else}-->�����ر�����<!--{/if}--></a>
			<!--{/if}-->
			<!--{if $flag[$_G['uid']]['mutual']}-->
			<a>{lang follow_follower_mutual}</a>
			<!--{else}-->
			<a>{lang follow_followed}</a>
			<!--{/if}-->
			<a id="a_followmod_{$uid}" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$uid&from=head" onclick="ajaxget(this.href);doane(event);">{lang follow_del}</a>
		</div>
		<div id="unfollowflag" {if isset($flag[$_G['uid']])}style="display: none"{/if}>
			<!--{if isset($flag[$uid])}-->
			<span class="z flw_status_1">{lang follow_user_followed}</span>
			<!--{/if}-->
			<!--{if helper_access::check_module('follow')}-->
			<a id="a_followmod_{$uid}" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$uid&from=head" onclick="ajaxget(this.href);doane(event);" class="flw_btn_fo" style="margin-left: 40px;">{lang follow_add}</a>
			<!--{/if}-->
		</div>
	</div>
<!--{/if}-->
</div>