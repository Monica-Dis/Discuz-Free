(function(){
    jQuery.fn.capacityFixed = function(options) {
        var opts = jQuery.extend({},jQuery.fn.capacityFixed.deflunt,options);
        var FixedFun = function(element) {
            var top = opts.top;
            element.css({
                "top":top
            });
            jQuery(window).scroll(function() {
                var scrolls = jQuery(this).scrollTop();
                if (scrolls > top) {

                    if (window.XMLHttpRequest) {
                        element.css({
                            position: "fixed",
                            top: 0							
                        });
                    } else {
                        element.css({
                            top: scrolls
                        });
                    }
                }else {
                    element.css({
                        position: "static",
                        top: top
                    });
                }
            });
            element.find(".close-ico").click(function(event){
                element.remove();
                event.preventDefault();
            })
        };
        return jQuery(this).each(function() {
            FixedFun(jQuery(this));
        });
    };
    jQuery.fn.capacityFixed.deflunt={
		right : 0,
        top:0
	};
})();