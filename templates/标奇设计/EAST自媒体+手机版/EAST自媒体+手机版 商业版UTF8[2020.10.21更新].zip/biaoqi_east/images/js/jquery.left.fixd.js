/*!
 * jQuery plugin BiaoQi v1.0
 * BiaoQi.left.fixd
 * �������
 *
 * Copyright 2013-2020 BiaoQi
 * Released under the GPLv2 license
 * https://dism.taobao.com/?@68363.developer
 * 
 * Written by Yang Xiaojun
 */

(function (jQuery) {
    var defaults = {
            topSpacing: 0,
            bottomSpacing: 0,
            className: 'fixd_open',
            center: false,
            getWidthFrom: ''
        },
        jQuerywindow = jQuery(window),
        jQuerydocument = jQuery(document),
        biaoqifixd = [],
        windowHeight = jQuerywindow.height(),
        scroller = function () {
            var scrollTop = jQuerywindow.scrollTop(),
                documentHeight = jQuerydocument.height(),
                dwh = documentHeight - windowHeight,
                extra = (scrollTop > dwh) ? dwh - scrollTop : 0;

            for (var i = 0; i < biaoqifixd.length; i++) {
                var s = biaoqifixd[i],
                    elementTop = s.fastenWrapper.offset().top,
                    etse = elementTop - s.topSpacing - extra;

                if (scrollTop <= etse) {
                    if (s.currentTop !== null) {
                        s.fastenElement
                            .css('position', '')
                            .css('top', '');
                        s.fastenElement.parent().removeClass(s.className);
                        s.currentTop = null;
                    }
                } else {
                    var newTop = documentHeight - s.fastenElement.outerHeight() - s.topSpacing - s.bottomSpacing - scrollTop - extra;
                    if (newTop < 0) {
                        newTop = newTop + s.topSpacing;
                    } else {
                        newTop = s.topSpacing;
                    }
                    if (s.currentTop != newTop) {
                        s.fastenElement
                            .css('position', 'fixed')
                            .css('top', newTop);

                        if (typeof s.getWidthFrom !== 'undefined') {
                            s.fastenElement.css('width', jQuery(s.getWidthFrom).width());
                        }

                        s.fastenElement.parent().addClass(s.className);
                        s.currentTop = newTop;
                    }
                }
            }
        },
        resizer = function () {
            windowHeight = jQuerywindow.height();
        },
        methods = {
            init: function (options) {
                    var o = jQuery.extend(defaults, options);
                    return this.each(function () {
                        var fastenElement = jQuery(this);

                        var fastenId = fastenElement.attr('id');
                        var wrapper = jQuery('<div class="biaoqi_left_fixd"></div>')
                        fastenElement.wrapAll(wrapper);

                        if (o.center) {
                            fastenElement.parent().css({
                                width: fastenElement.outerWidth(),
                                marginLeft: "auto",
                                marginRight: "auto"
                            });
                        }

                        if (fastenElement.css("float") == "right") {
                            fastenElement.css({
                                "float": "none"
                            }).parent().css({
                                "float": "right"
                            });
                        }

                        var fastenWrapper = fastenElement.parent();
                        fastenWrapper.css('height', fastenElement.outerHeight());
                        biaoqifixd.push({
                            topSpacing: o.topSpacing,
                            bottomSpacing: o.bottomSpacing,
                            fastenElement: fastenElement,
                            currentTop: null,
                            fastenWrapper: fastenWrapper,
                            className: o.className,
                            getWidthFrom: o.getWidthFrom
                        });
                    });
                },
                update: scroller
        };

    if (window.addEventListener) {
        window.addEventListener('scroll', scroller, false);
        window.addEventListener('resize', resizer, false);
    } else if (window.attachEvent) {
        window.attachEvent('onscroll', scroller);
        window.attachEvent('onresize', resizer);
    }

    jQuery.fn.fasten = function (method) {
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            jQuery.error('Method ' + method + ' does not exist on jQuery.fasten');
        }
    };
    jQuery(function () {
        setTimeout(scroller, 0);
    });
})(jQuery);