/*!
 * jQuery plugin BiaoQi v1.0
 * BiaoQi.loadmore
 * 标奇设计
 *
 * Copyright 2013-2020 BiaoQi
 * Released under the GPLv2 license
 * https://dism.taobao.com/?@68363.developer
 * 
 * Written by Yang Xiaojun
 */
 
 jQuery(document).ready(function () {
    var biaoqicn_b_aiv = function (jQuerychildren, n) {
        var jQueryhiddenChildren = jQuerychildren.filter(":hidden");
        var cnt = jQueryhiddenChildren.length;
        for (var i = 0; i < n && i < cnt; i++) {
            jQueryhiddenChildren.eq(i).fadeIn();
        }
        return cnt - n;
    }

    jQuery(".biaoqi_news_list").each(function () {
        var pagenum = jQuery(this).attr("pagenum") || 16;
        var jQuerychildren = jQuery(this).children();
        if (jQuerychildren.length > pagenum) {
            for (var i = pagenum; i < jQuerychildren.length; i++) {
                jQuerychildren.eq(i).hide();
            }
            jQuery("<div class='biaoqi-loadmore-btn cl'><span>点击加载更多</span></div>").insertAfter(jQuery(this)).click(function () {
                if (biaoqicn_b_aiv(jQuerychildren, pagenum) <= 0) {
                    jQuery(this).html("<span>已经到底了...</span>");
                };
            });
        }
    });
});