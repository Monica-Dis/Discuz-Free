<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>	
<!--{if $_G['uid']}-->
<div class="login-wrap y">
<div class="menu-heading">         
   <span  class="avatar-pic"><a href="home.php?mod=space&uid=$_G[uid]"><!--{avatar($_G[uid],small)}--></a>
   <!--{if $_G[member][newprompt] || $_G[member][newpm]}-->
      <!--{eval settype($_G[member][newprompt], 'integer');}-->
      <!--{eval settype($_G[member][newpm], 'integer');}-->
      <!--{eval $noticenum = $_G[member][newprompt] + $_G[member][newpm];}-->
      <i>$noticenum</i>
   <!--{/if}-->
   </span>  
   <span class="member-name"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="�����ҵĿռ�">$_G[member][username]</a> </span>
   <span class="angle"></span>
</div>
     
<div class="menu-body">
   <div class="menu-body-panel login-detail-wrap">
      <i class="icon icon-arrow-t"></i>
       <div class="item">
         <a href="javascript:;" id="qmenu" onmouseover="delayShow(this, function () {showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2});showForummenu($_G[fid]);})">{lang my_nav}</a>
      </div>
	 <!--{if !empty($_G['setting']['plugins']['spacecp']) || in_array(wechat,$_G['setting']['plugins']['available'])}-->
	     <div class="item_plugins">
		      <!--{hook/global_usernav_extra1}-->
	     </div>
	  <!--{/if}--> 

      <div class="item">
	      <a id="nte_menu" href="home.php?mod=space&do=notice" class="notification">����<!--{if $_G[member][newprompt]}--><i>$_G[member][newprompt]</i><!--{/if}--></a></li>
      </div>

      <div class="item">
	      <a id="msg_menu" href="home.php?mod=space&do=pm" class="msg">��Ϣ<!--{if $_G[member][newpm]}--><i>$_G[member][newpm]</i><!--{/if}--></a> 
	  </div>

	  <!--{hook/global_usernav_extra3}-->
	
	  <!--{if check_diy_perm($topic)}-->
		 <div class="item">
            <a href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" title="{lang open_diy}">��DIY</a>
		</div>
     <!--{/if}--> 

	
	  <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
	   <div class="item">
          <a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a>
       </div>	
     <!--{/if}--> 
    

	 <!--{if $_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])}-->
		<div class="item">
		   <a href="home.php?mod=task&item=doing" id="task_ntc">{lang task_doing}</a>
		 </div>
	 <!--{/if}-->
	
     <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
		<div class="item">
			<a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a>
		</div>
	<!--{/if}-->

	 <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
		<div class="item">
			<a href="admin.php" target="_blank">{lang admincp}</a>
		</div>
	<!--{/if}-->
     
	 
	 <div class="item">
		   <a href="home.php?mod=spacecp">{lang setup}</a>
     </div>

	<div class="item">
		<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
    </div>

    </div>
  </div>

</div>

<!--{elseif !empty($_G['cookie']['loginuser'])}-->

<p>
	<strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
</p>
<!--{elseif !$_G[connectguest]}-->

<div class="login-wrap y">
     <div class="menu-heading">
          <a class="member-login" target="_blank" href="javascript:;">          
		      <span><img class="avatar-pic" width="51" height="50" src="$_G['style']['styleimgdir']/noLogin.png" id="avatar-pic"></span>          
              <span class="member-name">�ʺ�</span>
          </a>
		  
		  <span class="angle"></span>

      </div>
     
      <div class="menu-body">
           <div class="menu-body-panel login-detail-wrap">

                <i class="icon icon-arrow-t"></i>
                
				<div class="item">
				     <a href="javascript:;" id="qmenu" onmouseover="delayShow(this, function () {showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2});showForummenu($_G[fid]);})"><span class="icon icon-kuaijie"></span>{lang my_nav}</a>
                </div>
				
                <div class="item">
				     <a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" onclick="showWindow('login', this.href);return false;"><span class="icon icon-login"></span>��¼</a>
				</div>
                  
                <div class="item">
				     <a href="member.php?mod={$_G[setting][regname]}" rel="nofollow" target="_blank"><span class="icon icon-register"></span>ע��</a>
				</div>

             </div>
       </div>

</div>

<!--{else}-->

<div class="login-wrap y">
     <div class="menu-heading">
          <a class="member-login" target="_blank" href="javascript:;">          
		      <span><img class="avatar-pic" width="51" height="50" src="$_G['style']['styleimgdir']/noLogin.png" id="avatar-pic"></span>          
              <span class="member-name">$_G[member][username]</span>
          </a>
		  
		  <span class="angle"></span>

      </div>
     
 <div class="menu-body">
      <div class="menu-body-panel login-detail-wrap">
           <i class="icon icon-arrow-t"></i>
   
      <div class="item">
	      <a href="member.php?mod=connect" target="_blank" title="���鱾վ���๦��">�����ʺ���Ϣ</a>
      </div>

	<div class="item">
		<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
    </div>

    </div>
  </div>

</div>
<!--{/if}-->
