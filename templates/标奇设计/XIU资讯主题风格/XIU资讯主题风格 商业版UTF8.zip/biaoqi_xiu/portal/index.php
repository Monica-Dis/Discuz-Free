<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>	
<!--{subtemplate common/header}-->

<style id="diy_style" type="text/css"></style>

<div class="mail cl">
<div class="main-left">
    <!--[diy=biaoqicn_b_left_list]--><div id="biaoqicn_b_left_list" class="area"></div><!--[/diy]--> 			    
</div>

<div class="biaoqi_slide">
<div class="main-center cl">


   <div class="huandeng">
         <!--[diy=biaoqicn_b_diy2]--><div id="biaoqicn_b_diy2" class="area"></div><!--[/diy]-->
  </div> 
<script type="text/javascript" src="$_G['style']['styleimgdir']/js/unslider.min.js?{VERHASH}"></script>
<script type="text/javascript">
	jQuery(function(){jQuery('.forum_focus').unslider({arrows:true,dots:true});jQuery('.forum_focus .dots').eq(1).hide();jQuery('.forum_focus .dot').mouseover(function(){jQuery(this).closest('.forum_focus').find('ul').stop();jQuery(this).click();});jQuery('.forum_focus').hover(function(){jQuery(this).toggleClass('hover');});});
</script>

<div class="main-left-pic cl">
   <!--[diy=main-left-pic]--><div id="main-left-pic" class="area"></div><!--[/diy]-->
</div> 

<div class="biaoqicn_zx_box cl">
     <div class="biaoqicn_z_tab">	
          <em id="biaoqicn_z_tz_1" class="on" onmousemove="switchTab('biaoqicn_z_tz',1,4,'on');">社区热门</em>
          <em id="biaoqicn_z_tz_2" onmousemove="switchTab('biaoqicn_z_tz',2,4,'on');">最新发布</em>
		  <em id="biaoqicn_z_tz_3" onmousemove="switchTab('biaoqicn_z_tz',3,4,'on');">最新回复</em>
		  <em id="biaoqicn_z_tz_4" onmousemove="switchTab('biaoqicn_z_tz',4,4,'on');">精华内容</em>
     </div>

<div id="biaoqicn_z_tz_c_1" class="biaoqicn_b_aiv cl" style="display:block;">
    <!--[diy=biaoqicn_b_diy4]--><div id="biaoqicn_b_diy4" class="area"></div><!--[/diy]-->
</div>

<div id="biaoqicn_z_tz_c_2" class="biaoqicn_b_aiv cl" style="display:none;">
    <!--[diy=biaoqicn_b_diy4a]--><div id="biaoqicn_b_diy4a" class="area"></div><!--[/diy]-->
</div>

<div id="biaoqicn_z_tz_c_3" class="biaoqicn_b_aiv cl" style="display:none;">
    <!--[diy=biaoqicn_b_diy4b]--><div id="biaoqicn_b_diy4b" class="area"></div><!--[/diy]-->
</div>

<div id="biaoqicn_z_tz_c_4" class="biaoqicn_b_aiv cl" style="display:none;">
    <!--[diy=biaoqicn_b_diy4c]--><div id="biaoqicn_b_diy4c" class="area"></div><!--[/diy]-->
</div>
</div> 
</div>

<div class="main-right cl"> 
<div class="main-right-box cl">
    <ul><!--[diy=biaoqib_diy3]--><div id="biaoqib_diy3" class="area"></div><!--[/diy]--></ul>
</div>

<div class="main-right-box cl">
<!--[diy=biaoqicn_b_diy5]--><div id="biaoqicn_b_diy5" class="area"></div><!--[/diy]-->
</div>

<div class="main-right-box cl">
<!--[diy=biaoqicn_b_diy8]--><div id="biaoqicn_b_diy8" class="area"></div><!--[/diy]-->
</div>

<div class="main-right-box cl">
<!--[diy=biaoqicn_b_diy6]--><div id="biaoqicn_b_diy6" class="area"></div><!--[/diy]-->
</div>

<div class="main-right-box cl">
   <!--[diy=biaoqicn_b_diy7]--><div id="biaoqicn_b_diy7" class="area"></div><!--[/diy]-->
</div>

<div class="main-right-box fixedrightbox cl"> 
<!--[diy=biaoqicn_b_diy9]--><div id="biaoqicn_b_diy9" class="area"></div><!--[/diy]-->
</div>

</div> 
</div> 

</div> 

<div class="partners cl">
   <!--{eval $slides = DB::fetch_all("select * FROM " . DB::table("common_friendlink"). " LIMIT4 ");}-->
   <h3>友情链接</h3>
   <ul>
   <!--{loop $slides $slide}-->
	  <li><a href="$slide[url]" target="_blank" title="$slide[name]">$slide[name]</a></li>
   <!--{/loop}-->
   </ul>
</div>

	<script>
		var _content = []; //临时存储li循环内容
		var hotbox = {
			_default:12, //默认显示图片个数
			_loading:5,  //每次点击按钮后加载的个数
			init:function(){
				var lis = jQuery(".hotbox .hidden li");
				jQuery(".hotbox ul.list").html("");
				for(var n=0;n<hotbox._default;n++){
					lis.eq(n).appendTo(".hotbox ul.list");
				}
				jQuery(".hotbox ul.list img").each(function(){
					jQuery(this).attr('src',jQuery(this).attr('realSrc'));
				})
				for(var i=hotbox._default;i<lis.length;i++){
					_content.push(lis.eq(i));
				}
				jQuery(".hotbox .hidden").html("");
			},
			loadMore:function(){
				var mLis = jQuery(".hotbox ul.list li").length;
				for(var i =0;i<=hotbox._loading;i++){
					var target = _content.shift();
					if(!target){
						jQuery('.hotbox .more').html("<p><a href=\"#\">前往频道</a></p>"); //这里的#是加载完后要跳转的链接，修改即可，别动其他符号
						break;
					}
					jQuery(".hotbox ul.list").append(target);
					jQuery(".hotbox ul.list img").eq(mLis+i).each(function(){
						jQuery(this).attr('src',jQuery(this).attr('realSrc'));
					});
				}
			}
		}
		hotbox.init();
	</script>

<!--{subtemplate common/footer}-->

