<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>	
<!--{template common/header}-->
<style type="text/css">

	.xl2 { background: url({IMGDIR}/vline.png) repeat-y 50% 0; }
		.xl2 li { width: 49.9%; }
			.xl2 li em { padding-right: 10px; }
				.xl2 .xl2_r em { padding-right: 0; }
			.xl2 .xl2_r i { padding-left: 10px; }
#threadlist .avt img{width: 50px;height: 50px;padding: 0;border:0;}
.mn #threadlist .avt a{width: 50px;padding: 0 !important;}
#threadlist .bm_c{padding:0}
.biaoqicn_group .avt{width:55px;padding:10px 0}
.h_avatar {margin: -8px 13px 0 0;}
.h_avatar .reply_left { line-height: 25px;}

#threadlist #separatorline .avt{padding:0}
#threadlist .flt,#threadlist .flts{width:0}
#threadlist .by{width: 145px;}
#threadlist .bm_c th{padding-left:5px;padding-right:0}
#threadlist .bm_c .new{padding-left:5px;padding-right:0}
#threadlist .xst{font-size:16px; font-family: Microsoft YaHei;}

#threadlist .xst .forumname {
    height: 14px;
    line-height: 14px;
    margin-right: 5px;
    padding: 3px 6px;
    border: 1px solid #eee;
    background: #F14843 !important;
    font-size: 14px;
    color: #fff !important;
}

#threadlist th a:hover,#threadlist td.fn a:hover{text-decoration:none;color:#F14843 !important}
.biaoqicn_group th, .biaoqicn_group td {padding: 20px 0 20px 12px !important; border-bottom: 1px solid #e7e7e7 !important;}
.biaoqicn_mtn {margin-top: 10px !important;}
.biaoqicn_guide_mn {
    background: #fff;
    padding: 0 10px;
}

#threadlist .xld .m, #threadlist .xld .m a {
    width: 54px;
    height: 45px;
    overflow: hidden;
    cursor: pointer;
    margin-right: 15px;
    background: #f5f5f5;
}
.xld .m {
    float: left;
    margin: 8px 10px 10px 0;
}
#threadlist .xld .m strong {
    display: block;
    height: 25px;
    line-height: 25px;
    color: #F14843 !important;
    overflow: hidden;
}
#threadlist .xld .m span {
    display: block;
    color: #F14843 !important;
}

.biaoqicn_ttp {
    background: #fff;
    border: 0;
    border-bottom: 1px solid #eee;
}

.biaoqicn_ttp li {
    float: left;
    height: 57px;
    line-height: 60px;
    margin-right: 20px;
    color: #333;
    font-size: 14px;
    cursor: pointer;
}
.biaoqicn_ttp li a {display: block; position: relative;color: #333;font-size: 14px;height: 57px;line-height: 60px; padding: 0 5px;}
.biaoqicn_ttp li a:hover, .biaoqicn_threadtypes ul li.a a {color: #F14843;}
.biaoqicn_ttp li.a a {font-weight: 700;color: #F14843;}

.biaoqicn_ttp li span {display: block;position: absolute;bottom: -1px;left: 50%;width: 0%;bottom: -1px;height: 3px;background-color: #F14843;transition: all 0.2s ease-in-out 0s;}
.biaoqicn_ttp li.a span, .biaoqicn_ttp a:hover span {width: 100%;left: 0;}

.biaoqicn_g_m {
    padding: 15px;
}
.biaoqicn_guide_mn .tl .tf {
    padding: 3px 16px;
}
.avt img{
    -moz-border-radius: 50%;
    -webkit-border-radius: 50%;
    border-radius: 50%;
}
#threadlist .post_infolist_other, #threadlist .post_infolist_other a { color: #BCC0C4 !important;}
#threadlist .nums span { margin-left: 8px; padding-left: 20px; background: url($_G['style']['styleimgdir']/icon.png) no-repeat 0 -577px; color: #BCC0C4;}
#threadlist .nums span.reply { background-position: 0 -637px;}
</style>

<style id="diy_style" type="text/css"></style>

<div id="pt" class="bm cl">
	<div class="z">
		<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a><em>&raquo;</em><a href="forum.php">{$_G[setting][navs][2][navname]}</a>$navigation
	</div>
</div>

<div class="boardnav" style="margin: 0 0 15px">
	<div id="ct" class="wp cl{if $_G['forum']['allowside']} ct2{/if}"{if $leftside} style="margin-left:{$_G['leftsidewidth_mwidth']}px"{/if}>
		<div class="mn biaoqicn_guide_mn" style="padding-top: 1px;">
			<ul id="thread_types" class="biaoqicn_ttp bm cl">	
				<li $currentview['hot']><a href="forum.php?mod=guide&view=hot">{lang guide_hot}<span></span></a></li>
				<li $currentview['digest']><a href="forum.php?mod=guide&view=digest">{lang guide_digest}<span></span></a></li>
				<li $currentview['new']><a href="forum.php?mod=guide&view=new">{lang guide_new}<span></span></a></li>
				<li $currentview['newthread']><a href="forum.php?mod=guide&view=newthread">{lang guide_newthread}<span></span></a></li>
				<li $currentview['sofa']><a href="forum.php?mod=guide&view=sofa">{lang guide_sofa}<span></span></a></li>
				<li $currentview['my']><a id="filter_special" href="forum.php?mod=guide&view=my" onmouseover="showMenu(this.id)">{lang guide_my}<span></span></a></li>
				<li style="float: right;margin: 0;"><a href="forum.php?mod=misc&amp;action=nav&amp;special=0&amp;" onclick="showWindow('nav', this.href);return false;" title="{lang send_posts}" class="btn sendtheme"><img src="{$_G[style][styleimgdir]}/pn_post.png" alt="{lang send_posts}" style="padding-top: 8px;" /></a></li>
				<!--{hook/guide_nav_extra}-->
			</ul>
			<!--{hook/guide_top}-->
			<!--{if $view == 'index'}-->
				<!--{loop $data $key $list}-->
				<div class="bm bmw">
					<div class="bm_h">
						<a href="forum.php?mod=guide&view=$key" class="y xi2">{lang more} &raquo;</a>
						<h2>
							<!--{if $key == 'hot'}-->{lang guide_hot}<!--{elseif $key == 'digest'}-->{lang guide_digest}<!--{elseif $key == 'newthread'}-->{lang guide_newthread}<!--{elseif $key == 'new'}-->{lang guide_new}<!--{elseif $key == 'my'}-->{lang guide_my}<!--{/if}-->
						</h2>
					</div>
					 <div class="bm_c">
					 	<div class="xl xl2 cl">
					 		<!--{if $list['threadcount']}-->
					 			<!--{eval $i=0;}-->
					 			<!--{loop $list['threadlist'] $thread}-->
					 			<!--{eval $i++;$newtd=$i%2;}-->
					 			<li{if !$newtd} class="xl2_r"{/if}>
						 			<em>
							 			<!--{if $key == 'hot'}--><span class="xi1">$thread['heats']{lang guide_attend}</span><!--{/if}-->
							 			<!--{if $key == 'new'}-->$thread['lastpost']<!--{/if}-->
						 			</em>
						 			
						 			<i>&middot; <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight] target="_blank">$thread[subject]</a></i>&nbsp;<span class="xg1"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$list['forumnames'][$thread[fid]]['name']</a></span>
					 			</li>
					 			<!--{/loop}-->
					 		<!--{else}-->
					 				<p class="emp">{lang guide_nothreads}</p>
					 		<!--{/if}-->
					 	</div>
					</div>
				</div>
				<!--{/loop}-->
			<!--{else}-->
				<!--{loop $data $key $list}-->
				<div id="threadlist" class="tl"{if $_G['uid']} style="position: relative;"{/if}>
					<div class="bm_c biaoqicn_group">
						<div id="forumnew" style="display:none"></div>
							<table cellspacing="0" cellpadding="0">
							<!--{subtemplate forum/guide_list_row}-->
							</table>
					</div>
				</div>
				<!--{/loop}-->
				<div class="bm bw0 biaoqicn_g_m pgs cl">
					$multipage
				</div>
			<!--{/if}-->
			<!--{hook/guide_bottom}-->
		</div>

	</div>
</div>
<!--{if !IS_ROBOT}-->
	<div id="filter_special_menu" class="p_pop" style="display:none">
		<ul>
			<li><a href="home.php?mod=space&do=poll&view=me" target="_blank">{lang thread_poll}</a></li>
			<li><a href="home.php?mod=space&do=trade&view=me" target="_blank">{lang thread_trade}</a></li>
			<li><a href="home.php?mod=space&do=reward&view=me" target="_blank">{lang thread_reward}</a></li>
			<li><a href="home.php?mod=space&do=activity&view=me" target="_blank">{lang thread_activity}</a></li>
		</ul>
	</div>
<!--{/if}-->
<!--{template common/footer}-->
