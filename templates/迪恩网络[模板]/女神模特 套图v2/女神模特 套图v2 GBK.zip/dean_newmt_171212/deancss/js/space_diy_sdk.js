// JavaScript Document

jq(".deancloselight").toggle(
	function(){
		jq(this).addClass("deanopenlight");
		jq("body").css("background","#222");
		jq(this).children("span").text("����");
		jq(".deanfltit h3").css("color","#fff");
		jq(".deanscrollimg ul.deanscrollul li h3 a").css("color","#fff");
		jq(".deanfltit").css("border-bottom","1px solid #666");
		jq(".deannvlist ul li").css("border","1px solid #000");
	},
	function(){
		jq(this).removeClass("deanopenlight");
		jq("body").css("background","#fff");
		jq(this).children("span").text("�ص�");
		jq(".deanfltit h3").css("color","#444");
		jq(".deanscrollimg ul.deanscrollul li h3 a").css("color","#333");
		jq(".deanfltit").css("border-bottom","1px solid #e9e9e9");
		jq(".deannvlist ul li").css("border","1px solid #666");
		})
