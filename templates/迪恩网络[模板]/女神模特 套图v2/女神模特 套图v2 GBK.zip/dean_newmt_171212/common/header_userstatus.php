<?php echo '��֧�ֵ϶���������';exit;?>
<!--{if $_G['uid']}-->
<style type="text/css">
.deanmessage .pipe{ display:none;}
.vwmy.qq{ padding-left:0; background-position:12px 12px; text-indent:32px;}
.deanbangding{ margin-top:10px; padding-left:15px;}
.deanbangding img,.deanbangding1 img{ }
	.deanbangding a{ display:inline-block; margin-bottom:10px!important; color:#666!important; font-size:14px; clear:both;}
	.deanbangding1 a{ color:#666!important; font-size:14px;}
</style>
<div class="deanloginin">
    <div class="deaninfo">
    	<div class="deanhove deanxz"><a href="home.php?mod=space&uid=$_G[uid]" title="{$_G[member][username]}"><!--{avatar($_G[uid],small)}--></a></div>
        <div class="clear"></div>
        <div class="deanmessage ">
        	<b class="deanarrowss"><i></i></b>
            <div class="deanmessagetop">
            	<div class="deanhiadmint"><h3>Hi, {$_G[member][username]}<!--{if check_diy_perm($topic)}-->$diynav<!--{/if}--></h3><div class="clear"></div><div class="deanppp">��ӭ������վ��������Ů������</div></div>
                <div class="clear"></div>
                <a href="home.php?mod=space&uid=$_G[uid]" title="{lang visit_my_space}" target="_blank" class="deangouc">ȥ��������</a>
                <dl class="deanmessagedl">
                	<dd>
                    	<i></i>
                        <a href="home.php?mod=space&do=notice" id="myprompt"{if $_G[member][newprompt]} class="new"{/if} title="{lang remind}">
                    		<!--{if $_G[member][newprompt]}--><em>$_G[member][newprompt]</em><!--{else}--><em>0</em><!--{/if}-->
                        	<div class="clear"></div>
                    		{lang remind}
                            <span id="myprompt_check"></span>
							<!--{if empty($_G['cookie']['ignore_notice']) && ($_G[member][newpm] || $_G[member][newprompt_num][follower] || $_G[member][newprompt_num][follow] || $_G[member][newprompt])}--><!--{/if}-->
                        	</a>
                    </dd>
                    <dd>
                    	<i></i>
                        <a href="home.php?mod=spacecp&ac=credit&showcredit=1">
                            <em>$_G[member][credits]</em>
                            <div class="clear"></div>
                            {lang credits}
                        </a>
                    </dd>
                    <dd>
                    	<a href="home.php?mod=spacecp&ac=usergroup" >
                            <em>$_G[group][grouptitle]</em>
                            <div class="clear"></div>
                            �û���
                        </a>
                    </dd>
                    <div class="clear"></div>
                </dl>
            </div>
        	<ul class="deanmessageul">
                <li><a class="deanmesli1" href="home.php?mod=spacecp"><i class="icon-cog"></i><div class="clear"></div>{lang setup}</a></li>
                <!--{if $_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])}--><li><a href="home.php?mod=task&item=doing" id="task_ntc" class="new deanmesli2"><i></i><div class="clear"></div>{lang task_doing}</a></li><!--{/if}-->
                <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
                <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}--><li><a href="admin.php" class="deanmesli5" target="_blank" title="��������"><i class=" icon-wrench"></i><div class="clear"></div>��̨</a></li><!--{/if}-->
				<li title="�Ż�����"><a class="deanmesli3" href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }--><i class="icon-trash"></i><div class="clear"></div>�Ż�<!--{else}--><i class="icon-trash"></i><div class="clear"></div>�Ż�����<!--{/if}--></a></li>
				<!--{/if}-->
                <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}--><li><a  class="deanmesli4" href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank"><i class="icon-tint"></i><div class="clear"></div>{lang forum_manager}</a></li><!--{/if}-->
                
                <li><a class="deanmesli7"  href="home.php?mod=space&do=friend" target="_blank"><i class="icon-group"></i><div class="clear"></div>����</a></li>
                <li><a class="deanmesli8"  href="forum.php?mod=guide&view=my" target="_blank"><i class="icon-pencil"></i><div class="clear"></div>����</a></li>
                <li><a class="deanmesli9"  href="home.php?mod=space&do=favorite&view=me" target="_blank"><i class="icon-star-empty"></i><div class="clear"></div>�ղ�</a></li>
                <li><a class="deanmesli10" href="home.php?mod=medal" target="_blank"><i class="icon-bookmark-empty"></i><div class="clear"></div>ѫ��</a></li>
                <li><a class="deanmesli11" href="forum.php?mod=guide" target="_blank"><i class="icon-book"></i><div class="clear"></div>����</a></li>
                <li><a class="deanmesli12" href="home.php?mod=space&do=album" target="_blank"><i class="icon-picture"></i><div class="clear"></div>���</a></li>
                <li><a class="deanmesli6" href="member.php?mod=logging&action=logout&formhash={FORMHASH}"><i class="icon-off"></i><div class="clear"></div>�˳�</a></li>
            </ul>
            <div class="clear"></div>
            <div class="deanbangding"><!--{hook/global_usernav_extra1}--><div class="clear"></div><!--{hook/global_usernav_extra2}--><div class="clear"></div><!--{hook/global_usernav_extra3}--><div class="clear"></div><!--{hook/global_usernav_extra4}--></div>
        </div>
    </div>
    
    <div class="clear"></div>
</div>

<!--{elseif !empty($_G['cookie']['loginuser'])}-->
    <div class="deanmessage">
        <li><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></li>
        <li><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a></li>
        <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
    </div>
<!--{elseif !$_G[connectguest]}-->
	<div class="deanuserha">
        <div class="deanusemain">
            <div class="deanuseavar"><img width="26" height="26" src="$_G['style'][styleimgdir]/common/avar.png"></div>
            <div class="deanuselink">
            	<b class="deanarrowss"><i></i></b>
                <div class="deanhsdenglu">
                    <a href="member.php?mod=logging&action=login" class="deandenglua">��¼</a>
                    <a href="member.php?mod={$_G[setting][regname]}" target="_blank" class="deanzhucea">ע��</a>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
                <div class="deankjdlbtn">
                	<div class="deanqjdltit"><i></i><span>��ݵ�¼</span></div>
                	<div class="clear"></div>
                    <a class="deanqqicon" href="connect.php?mod=login&op=init&referer=index.php&statfrom=login_simple" title="qq��½" target="_blank"></a>
                    <a class="deanwechaticon" href="plugin.php?id=wechat:login" target="_blank" title="΢�ŵ�½"></a>
                    <a class="deanwenicon" href="javascript:;" onclick="showWindow('login', 'member.php?mod=logging&action=login&viewlostpw=1')" title="{lang forgotpw}"></a>
                </div>
            </div>
        </div>
		<div class="clear"></div>
    </div>
    
	
<!--{else}-->
<div id="um">
	<div class="avt y"><!--{avatar(0,small)}--></div>
	<p>
		<strong class="vwmy qq">{$_G[member][username]}</strong>
		<!--{hook/global_usernav_extra1}-->
		<span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
	</p>
	<p>
		<a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a>
		<span class="pipe">|</span>{lang usergroup}: $_G[group][grouptitle]
	</p>
</div>
<!--{/if}-->
