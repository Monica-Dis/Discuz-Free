<?php echo '��֧�ֵ϶���������';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.SuperSlide.2.1.1.js"></script>
<div class="deanwp">
	
	<div class="deannewbox">
    	<div class="deannvshenbq"><!--[diy=deannvshenbq]--><div id="deannvshenbq" class="area"></div><!--[/diy]--></div>
        <div class="deannvshenright">
        	<div class="deangirltp">
            	<div class="deannvhdp"><!--[diy=deannvhdp]--><div id="deannvhdp" class="area"></div><!--[/diy]--></div>
                <script type="text/javascript">
                	jq(".deannvhdp").slide({mainCell:".bd ul",effect:"fade",autoPlay:true});
                </script>
                <div class="deannvgglist">
                	<h3><i class="icon-volume-up"></i><span>ģ�ع���</span><div class="clear"></div></h3>
                    <div class="clear"></div>
                	<ul><!--[diy=deannvgglist]--><div id="deannvgglist" class="area"></div><!--[/diy]--></ul>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            <div class="deannvfltype">
            	<div class="deannvfltypec">
                	<div class="deannvleft">
                    	<ul>
                        	<li><!--[diy=deannvleft1]--><div id="deannvleft1" class="area"></div><!--[/diy]--></li>
                            <li><!--[diy=deannvleft2]--><div id="deannvleft2" class="area"></div><!--[/diy]--></li>
                            <div class="clear"></div>
                        </ul>
                        <div class="deannvlb"><!--[diy=deannvlb]--><div id="deannvlb" class="area"></div><!--[/diy]--></div>
                    </div>
                    <div class="deannvcenter"><!--[diy=deannvcenter]--><div id="deannvcenter" class="area"></div><!--[/diy]--></div>
                    <div class="deannvright">
                    	<ul>
                        	<li><!--[diy=deannvright1]--><div id="deannvright1" class="area"></div><!--[/diy]--></li>
                            <li style="margin-bottom:0;"><!--[diy=deannvright2]--><div id="deannvright2" class="area"></div><!--[/diy]--></li>
                        </ul>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
    <div class="clear"></div>
	<!--ģ��1չʾ-->
    <div class="deanflxm">
    	<div class="deanfltit"><i class="icon-github-alt"></i><h3>��ģѧԺ/MFstar</h3><a href="#" target="_blank">����<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
        <div class="clear"></div>
        <ul><!--[diy=deanflxm]--><div id="deanflxm" class="area"></div><!--[/diy]-->
            <div class="clear"></div>
        </ul>
    </div>
    <div class="clear"></div>
    <!--ģ��2չʾ-->
    <div class="deanscrollimg">
    	<a class="prev icon-angle-left" href="javascript:void(0)"></a>
		<a class="next icon-angle-right" href="javascript:void(0)"></a>
    	<div class="deanfltit"><i class="icon-heart-empty"></i><h3>�����Ƽ�/FeiLin</h3><a href="#" target="_blank">����<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
        <div class="clear"></div>
        <div style=" margin-top:15px;"><!--[diy=deanscrollimg]--><div id="deanscrollimg" class="area"></div><!--[/diy]--></div>
    </div>
    <script type="text/javascript">
    	jQuery(".deanscrollimg").slide({titCell:".hd ul",mainCell:".deanscrollul",autoPage:true,effect:"leftLoop",autoPlay:true,vis:5});
    </script>
    <div class="clear"></div>
    <!--ģ��3չʾ-->
    <div class="deanflxm">
    	<div class="deanfltit"><i class="icon-glass"></i><h3>���ȹ�/MyGirl</h3><a href="#" target="_blank">����<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
        <div class="clear"></div>
        <ul><!--[diy=deanflxm2]--><div id="deanflxm2" class="area"></div><!--[/diy]-->
            <div class="clear"></div>
        </ul>
    </div>
    <div class="clear"></div>
    
	<div class="deanad  fadeInUp"><!--[diy=deanad1]--><div id="deanad1" class="area"></div><!--[/diy]--></div>
    <div class="clear"></div>
    <!--ģ������-->
    <div class="deanfrank">
    	<div class="deanfrankdiv">
        	<div class="deanfrktit"><h3><i class="icon-coffee"></i>����������</h3><em></em></div>
            <div class="clear"></div>
            <ul>
            	<!--[diy=deanfrankdiv]--><div id="deanfrankdiv" class="area"></div><!--[/diy]-->
            </ul>
        </div>
        <div class="deanfrankdiv">
        	<div class="deanfrktit"><h3><i class="icon-star"></i>����������עĿ</h3><em></em></div>
            <div class="clear"></div>
            <ul>
            	<!--[diy=deanfrankdiv1]--><div id="deanfrankdiv1" class="area"></div><!--[/diy]-->
            </ul>
        </div>
        <div class="deanfrankdiv">
        	<div class="deanfrktit"><h3><i class="icon-gift"></i>���ڸ���</h3><em></em></div>
            <div class="clear"></div>
            <ul>
            	<!--[diy=deanfrankdiv2]--><div id="deanfrankdiv2" class="area"></div><!--[/diy]-->
            </ul>
        </div>
        <div class="deanfrankdiv">
        	<div class="deanfrktit"><h3><i class="icon-screenshot"></i>��������</h3><em></em></div>
            <div class="clear"></div>
            <ul>
            	<!--[diy=deanfrankdiv3]--><div id="deanfrankdiv3" class="area"></div><!--[/diy]-->
            </ul>
        </div>
    	<div class="clear"></div>
        <script type="text/javascript">
        	jq(".deanfrankdiv ul li:even").css("background","#fcfcfc");
			
        </script>
    </div>
    <div class="clear"></div>
    <div class="deanad deanad5  fadeInUp"><!--[diy=deanad]--><div id="deanad" class="area"></div><!--[/diy]--></div>
	<!--ģ��4չʾ-->
    <div class="deanflxm">
    	<div class="deanfltit"><i class="icon-camera"></i><h3>������/UGirls APP</h3><a href="#" target="_blank">����<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
        <div class="clear"></div>
        <ul><!--[diy=deanflxm3]--><div id="deanflxm3" class="area"></div><!--[/diy]-->
            <div class="clear"></div>
        </ul>
    </div>
    <div class="clear"></div>
	<!--ģ��4չʾ-->
    <div class="deanflxm">
    	<div class="deanfltit"><i class="icon-facetime-video"></i><h3>��˿/ROSI</h3><a href="#" target="_blank">����<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
        <div class="clear"></div>
        <ul><!--[diy=deanflxm5]--><div id="deanflxm5" class="area"></div><!--[/diy]-->
            <div class="clear"></div>
        </ul>
    </div>
    <div class="clear"></div>
    <!--��������-->
    <div class="deanlink  fadeInUp">
    	<div class="deanfltit"><i class="icon-link"></i><h3>��������/LINKs</h3><a href="#" target="_blank">��ϵQQ3318850993<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
            <div class="clear"></div>
            <ul><!--[diy=deanlink]--><div id="deanlink" class="area"></div><!--[/diy]--> 
                <div class="clear"></div>
            </ul>
        </div>
    </div>
    
    
</div>

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->
