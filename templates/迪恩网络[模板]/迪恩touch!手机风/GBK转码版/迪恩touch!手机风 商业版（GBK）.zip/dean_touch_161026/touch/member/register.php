<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style type="text/css">
.footer{ display:none;}
.bg{ background:url(./template/dean_touch_161026/deancss/login/bg2.jpg) 0 0 no-repeat; background-size:cover; position:relative;}
.deanloginbg{ width:100%; height:100%; background:rgba(0,0,0,0.15); position:absolute; left:0; top:0;}
.login_from{ background:none; margin:0 15px; margin-top:30px;}
.nav{ background:none;}
.login_from ul{ width:100%;}
	.login_from ul li{ margin-bottom:5px;  width:100%; padding:0;}
		.login_from ul li input{ border:1px solid #eee; text-indent:15px; height:36px; line-height:36px; border-radius:2px; -webkit-box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 3px; -moz-box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 3px; box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 3px; padding:0; width:100%!important; background:rgba(255,255,255,0.9);} 
	.login_select,.login_select select{ border:0px solid #aaa; text-indent:15px; border-radius:2px; -webkit-box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 3px; -moz-box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 3px; box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 3px; padding:0; width:100%!important; background:rgba(255,255,255,0.9); font-weight:normal!important;}

.btn_login{ margin-top:10px;}
.btn_login .pn, .btn_register .pn{ width:91%; background:#f80; font-weight:normal; font-size:18px; border-radius:2px; }
.reg_link{width:91%; background:#2B8AE8; font-weight:normal; margin:10px auto; height:45px; line-height:45px; border-radius:2px; }
	.reg_link a{ padding:0; line-height:45px; display:block; color:#fff; text-align:center;  font-size:18px; background:none; border-radius:2px; }

.sec_code{ padding:0; margin-top:10px;}
	.sec_code .px{ width:200px!important; border:1px solid #eee; -webkit-box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 3px; -moz-box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 3px; box-shadow: rgba(0, 0, 0, 0.3) 1px 1px 3px; border-radius:2px; background:rgba(255,255,255,0.8)!important; text-indent:10px; height:30px; line-height:30px; padding:0!important; margin-right:10px;}
.btn_register{ margin-top:10px;}
</style>
<div class="deanloginbg">
<!-- header start -->
<header class="header">
    <div class="nav">
        <a href="javascript:;" onclick="history.go(-1)" class="z"><img src="./template/dean_touch_161026/deancss/back.png" width="30" height="30" /></a>
		<span>{lang register}</span>
    </div>
</header>
<!-- header end -->
<!-- registerbox start -->
<div class="loginbox registerbox">
	<div class="login_from">
		<form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}&mobile=2">
		<input type="hidden" name="regsubmit" value="yes" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
		<input type="hidden" name="referer" value="$dreferer" />
		<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
		<input type="hidden" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
		<ul>
			<li><input type="text" tabindex="1" class="px p_fre" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip}" fwin="login"></li>
			<li><input type="password" tabindex="2" class="px p_fre" size="30" value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password}" fwin="login"></li>
			<li><input type="password" tabindex="3" class="px p_fre" size="30" value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2}" fwin="login"></li>
			<li class="bl_none"><input type="email" tabindex="4" class="px p_fre" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login"></li>
			<!--{if empty($invite) && ($_G['setting']['regstatus'] == 2 || $_G['setting']['regstatus'] == 3)}-->
				<li><input type="text" name="invitecode" autocomplete="off" tabindex="5" class="px p_fre" size="30" value="{lang invite_code}" placeholder="{lang invite_code}" fwin="login"></li>
			<!--{/if}-->
			<!--{if $_G['setting']['regverify'] == 2}-->
				<li><input type="text" name="regmessage" autocomplete="off" tabindex="6" class="px p_fre" size="30" value="{lang register_message}" placeholder="{lang register_message}" fwin="login"></li>
			<!--{/if}-->
		</ul>
		<!--{if $secqaacheck || $seccodecheck}-->
			<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
	</div>
	<div class="btn_register"><button tabindex="7" value="true" name="regsubmit" type="submit" class="formdialog pn pnc"><span>{lang quickregister}</span></button></div>
	</form>
</div>
<!-- registerbox end -->

<!--{eval updatesession();}-->
</div>
<!--{template common/footer}-->

