<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--[name]{lang portalcategory_viewtplname}[/name]-->

<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']), imagemaxwidth = '{$_G['setting']['imagemaxwidth']}', aimgcount = new Array();</script>
<style type="text/css">
.scrolltop{ bottom:60px!important;}
.deanmn{ padding:0 15px;}
h1.ph{ font-size:16px; font-weight:normal; color:#0F2C3C; text-align:left;}
p.xg1{ line-height:40px;}
.s{ background:#F1F5F8; padding:10px; color:#70818B; font-size:13px; line-height:25px; margin-bottom:10px;}
p.xg1 .pipe{ color:#aaa; padding:0 5px; font-size:10px;}
.deanpren{ margin-top:15px;}
	.deanpren li{ font-size:15px; margin-bottom:10px;}
#related_article{}
	#related_article .bm_h{ border-bottom:1px solid #f0f0f0; height:35px; line-height:35px; background:none;}
		#related_article .bm_h h3{ border-bottom:1px solid #089FEE; font-size:16px; color:#666; display:block; height:35px; line-height:35px; float:left;}
		#related_article ul{ margin-top:10px;}
			#related_article ul li{ margin-bottom:10px; font-size:15px;}
.d img{ max-width:350px!important; width:95%!important; }
</style>
<header class="header">
    <div class="nav">
        <a href="javascript:;" onclick="history.go(-1)" class="z"><img src="./template/dean_touch_161026/deancss/back.png" width="30" height="30" /></a>
		<span>{lang view_content}</span>
    </div>
</header>
<style id="diy_style" type="text/css"></style>

<div class="deanmn">
		<div class="bm vw">
			<div class="h hm">
				<h1 class="ph">$article[title] <!--{if $article['status'] == 1}-->({lang moderate_need})<!--{elseif $article['status'] == 2}-->({lang ignored})<!--{/if}--></h1>
				<p class="xg1">
					$article[dateline]<span class="pipe">|</span>
					{lang view_publisher}: <a href="home.php?mod=space&uid=$article[uid]">$article[username]</a><span class="pipe">|</span>
					{lang view_views}: <em id="_viewnum"><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}--></em><span class="pipe">|</span>
					{lang view_comments}: <!--{if $article[commentnum] > 0}--><a href="$common_url" title="{lang view_all_comments}"><em id="_commentnum">$article[commentnum]</em></a><!--{else}-->0<!--{/if}-->
				</p>
			</div>
			<!--{if $article[summary] && empty($cat[notshowarticlesummay])}--><div class="s"><div><strong>{lang article_description}</strong>: $article[summary]</div><!--{hook/view_article_summary}--></div><!--{/if}-->
            <div class="clear"></div>
			<div class="d">
				<table cellpadding="0" cellspacing="0" class="vwtb"><tr><td id="article_content">
					<!--{if $content[title]}-->
					<div class="vm_pagetitle xw1">$content[title]</div>
					<!--{/if}-->
					$content[content]
				</td></tr></table>
                <div class="clear"></div>
              
                <!-- JiaThis Button BEGIN -->
                <div class="jiathis_style_m"></div>
                <script type="text/javascript" src="http://v3.jiathis.com/code/jiathis_m.js" charset=gbk></script>
                <!-- JiaThis Button END -->
               
                <div class="clear"></div>
				<!--{if $multi}--><div class="ptw pbw cl">$multi</div><!--{/if}-->
				<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
				<!--{if !empty($contents)}-->
				<div id="inner_nav" class="ptn xs1">
					<h3>{lang article_inner_navigation}</h3>
					<ul class="xl xl2 cl">
						<!--{loop $contents $key $value}-->
						<!--{eval $curpage = $key+1;}-->
						<!--{eval $inner_view_url = helper_page::mpurl($viewurl, '&page=', $curpage);}-->
						<li>&bull; <a href="$inner_view_url"{if $key === $start} class="xi1"{/if}>{lang article_inner_page_pre} {$curpage} {lang article_inner_page} $value[title]</a></li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--{/if}-->


			</div>
			<!--{if !empty($aimgs[$content[pid]])}-->
				<script type="text/javascript" reload="1">aimgcount[{$content[pid]}] = [<!--{echo implode(',', $aimgs[$content[pid]]);}-->];attachimgshow($content[pid]);</script>
			<!--{/if}-->

			
			<!--{if $article['preaid'] || $article['nextaid']}-->
			<div class="deanpren pbm cl">
            	<ul>
                    <li><!--{if $article['prearticle']}-->{lang pre_article}<a href="{$article['prearticle']['url']}">{$article['prearticle']['title']}</a><!--{/if}--></li>
                    <li><!--{if $article['nextarticle']}-->{lang next_article}<a href="{$article['nextarticle']['url']}">{$article['nextarticle']['title']}</a><!--{/if}--></li>
                </ul>
			</div>
			<!--{/if}-->
		</div>

		<!--{if $article['related']}-->
		<div id="related_article" class="bm">
			<div class="bm_h cl">
				<h3>{lang view_related}</h3>
			</div>
			<div class="bm_c">
				<ul class="xl xl2 cl" id="raid_div">
				<!--{loop $article['related'] $raid $rvalue}-->
					<input type="hidden" value="$raid" />
					<li>&bull; <a href="{$rvalue[uri]}">{$rvalue[title]}</a></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
		<!--{/if}-->

		<div style="display:none;">
		<!--{if $article['allowcomment']==1}-->
			<!--{eval $data = &$article}-->
			<!--{subtemplate portal/portal_comment}-->
		<!--{/if}-->
		</div>


	</div>

<!--{if $_G['relatedlinks']}-->
	<script type="text/javascript">
		var relatedlink = [];
		<!--{loop $_G['relatedlinks'] $key $link}-->
		relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
		<!--{/loop}-->
		relatedlinks('article_content');
	</script>
<!--{/if}-->
<a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a>
<input type="hidden" id="portalview" value="1">

<!--{template common/footer}-->
