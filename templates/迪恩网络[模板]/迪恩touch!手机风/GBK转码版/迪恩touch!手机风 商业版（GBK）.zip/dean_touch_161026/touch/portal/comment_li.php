<?php echo '';exit;?>

<a name="comment_anchor_$comment[cid]"></a>
<div id="comment_{$comment[cid]}_li" class="ptm pbm bbda cl">
	<div class="mbm">
	<!--{if !empty($comment['uid'])}-->
    	<div class="deanportalavar"><a href="home.php?mod=space&uid=$comment[authorid]" c="1"><!--{avatar($comment[uid],small)}--></a></div>
	<!--{else}-->
		{lang guest}
	<!--{/if}-->
    	<div class="deanportalinfo">
        	<div class="deanauthorttt">
            	<a href="home.php?mod=space&uid=$comment[uid]" class="deanportalname" c="1">$comment[username]</a><span><!--{date($comment[dateline])}--></span>
            </div>
            <p class="deanportalinfos"><!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->$comment[message]<!--{else}--> {lang moderate_not_validate}<!--{/if}--></p>
            <div class="clear"></div>
            
            <!--{if $comment[status] == 1}--><b>({lang moderate_need})</b><!--{/if}-->
        </div>
		<div class="clear"></div>
    </div>
</div>
