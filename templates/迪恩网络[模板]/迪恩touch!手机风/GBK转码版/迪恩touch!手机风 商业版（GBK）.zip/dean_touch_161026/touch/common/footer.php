<?php echo 'From: DisM.taobao.com';exit;?>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
</div>
<!--{if !$nofooter}-->
<div class="footer" >
	<div>
		<!--{if !$_G[uid] && !$_G['connectguest']}-->
		<a href="forum.php">{lang mobilehome}</a> | <a href="member.php?mod=logging&action=login" title="{lang login}">{lang login}</a> | <a href="<!--{if $_G['setting']['regstatus']}-->member.php?mod={$_G[setting][regname]}<!--{else}-->javascript:;" style="color:#D7D7D7;<!--{/if}-->" title="{$_G['setting']['reglinkname']}">{lang register}</a>
		<!--{else}-->
		<a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1">{$_G['member']['username']}</a> , <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" title="{lang logout}" class="dialog">{lang logout}</a>
		<!--{/if}-->
</div>
    
	<p>&copy; Comsenz Inc.</p>
</div>
<!--{/if}-->
<div id="mask" style="display:none;"></div>
<div class="clear"></div>
<div class="deanh100">&nbsp;</div>
<div class="clear"></div>
<div class="deanfooter">
	<a class="deanfta1" href="portal.php?mobile=2"><span></span><div class="clear"></div><p>��ҳ</p></a>
    <a class="deanfta2" href="forum.php?forumlist=1&mobile=2"><span></span><div class="clear"></div><p>��̳</p></a>
    <a class="deanfta3" href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread"><span></span><div class="clear"></div><p>�ղ�</p></a>
    <a class="deanfta4" href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><span></span><div class="clear"></div><p>�ҵ�</p></a>
    <div class="clear"></div>
</div>

<script type="text/javascript">
	$(".deanclick").click(function(){$(".deanfudongceng").animate({left:"0"},300);})
	$(".deanfudongceng").click(function(){$(".deanfudongceng").animate({left:"-100%"},100);})
</script>
</div>
<script type="text/javascript">  
// Create a couple of global variables to use.   
var audioElm = document.getElementById("audio1"); // Audio element  
var ratedisplay = document.getElementById("rate"); // Rate display area  

// Hook the ratechange event and display the current playbackRate after each change  
audioElm.addEventListener("ratechange", function () {  
ratedisplay.innerHTML = "��ǰ�ٶ�: " + audioElm.playbackRate;  
}, false);  

//  Alternates between play and pause based on the value of the paused property  
function togglePlay() {  
if (document.getElementById("audio1")) {  

if (audioElm.paused == true) {  
playAudio(audioElm);    //  if player is paused, then play the file  
} else {  
pauseAudio(audioElm);   //  if player is playing, then pause  
}  
}  
}  

function playAudio(audioElm) {  
document.getElementById("playbutton").innerHTML = "ֹͣ"; // Set button text == Pause  
// Get file from text box and assign it to the source of the audio element   
audioElm.src = document.getElementById('audioFile').value;  
audioElm.play();  
}  

function pauseAudio(audioElm) {  
document.getElementById("playbutton").innerHTML = "����"; // Set button text == Play  
audioElm.pause();  
}  

// Increment playbackRate by 0.25   
function increaseSpeed() {  
audioElm.playbackRate += 0.25;  
}  

// Cut playback rate in half  
function decreaseSpeed() {  
if (audioElm.playbackRate <= 1) {  
var temp = audioElm.playbackRate;  
audioElm.playbackRate -= 0.1;   
} else {  
audioElm.playbackRate -= 0.25;  
}  
}  

</script> 
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->

