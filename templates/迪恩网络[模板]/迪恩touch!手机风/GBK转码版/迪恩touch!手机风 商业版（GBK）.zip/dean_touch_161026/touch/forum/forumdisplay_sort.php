<?php echo '';exit;?>
<style type="text/css">
.deankclist{ width:100%; margin:0 auto; margin-top:10px; position:relative; z-index:1;}
		.deankclist ul{ }
			.deankclist ul li{ width:45.5%; height:195px; margin-left:2.5%; border:1px solid #e6e6e6; background:#fff; margin-bottom:10px; float:left; position:relative;}
				.deankclist ul li .deankcimg{ position:relative; width:100%; height:100px; overflow:hidden; z-index:1;}
					.deankclist ul li .deankcimg a{ display:block; width:100%; height:100px; overflow:hidden;}
						.deankclist ul li .deankcimg a img{ width:100%; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; }
						.deankclist ul li .deankcimg a:hover img{transform: scale(1.1); -moz-transform: scale(1.1); -webkit-transform: scale(1.1); -o-transform: scale(1.1); -ms-transform: scale(1.1);}
					.deankclist ul li a .deankcover{ position:absolute; opacity:0; z-index:2; width:100%; height:100px; overflow:hidden; left:0; top:0; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; background:rgba(0,0,0,0.4); }	
					.deankclist ul li:hover .deankcover{ opacity:1;}
						.deankclist ul li a .deankcover i.deanplaybtn{ display:block; width:50px; height:50px; position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; background:url(./template/dean_newpx_180112/deancss/forumlist/video.png) 0 0 no-repeat; background-size:50px 50px;}
				.deankclist ul li .deankcbottom{ padding:5px 10px; border:1px solid #eaeaea; border-top:0; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; position:relative; z-index:2; background:#fff; }
				.deankclist ul li:hover .deankcbottom{ }
					.deankcnames{font-size: 16px; font-weight:normal; letter-spacing:0.5px; color: #333; line-height:23px; margin-bottom:5px; height:46px; display:block; overflow:hidden;}
						.deankcnames a{ color:#666;}
						.deankcnames a:hover{ color:#00BC9B;}
					.deankcsummary{ font-size:12px; color:#999; line-height:20px; height:0px; overflow:hidden; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; opacity:0; letter-spacing:0.5px;}	
					.deankclist ul li:hover .deankcsummary{  height:60px; margin-bottom:10px; opacity:1;}
				.deankcinfos{ padding:5px 0;}
					.deankcinfos dl{ width:100%; height:20px; overflow:hidden; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; }
					.deankclist ul li:hover .deankcinfos dl{ height:50px;}
					.deankcinfos dl dd{ float:left; height:20px; line-height:20px; margin-bottom:5px; font-size:12px; width:50%; float:left; color:#666; overflow:hidden;}
						.deankcinfos dl dd i{ padding-right:3px;}
						.deankcinfos dl dd.deanprices{ font-size:15px; color:#f60;}
</style>
<style type="text/css">

		.deankclist li#deanidlist{  width:45.5%; height:327px; margin-left:2.5%; border:1px solid #e6e6e6; background:#fff; margin-bottom:10px; float:left; position:relative;-ms-transition: transform .2s; -webkit-transition: transform .2s; -moz-transition: transform .2s; transition: transform .2s;}
		.deankclist li#deanidlist:hover{ transform: translateY(-6px);
    -webkit-transform: translateY(-6px);
    -moz-transform: translateY(-6px);
    box-shadow: 0 26px 40px -24px rgba(0,36,100,0.3);
    -webkit-box-shadow: 0 26px 40px -24px rgba(0,36,100,0.3);
    -moz-box-shadow: 0 26px 40px -24px rgba(0,36,100,0.3);
    -webkit-transition: all 0.3s ease;
    -moz-transition: all 0.3s ease;
    -o-transition: all 0.3s ease;
    transition: all 0.3s ease;}
		.deankclist li#deanidlist .c, .deankclist li#deanidlist h3{ font-size:13px; background:#fff; border-color:#e6e6e6; font-weight:normal; }
		.deankclist li#deanidlist .c{ height:205px; overflow:hidden; width:100%;}
		li#deanidlist .c img{ width:100%; height:100%;}
		.deankclist li#deanidlist .c{ padding:0; position:relative; z-index:1;}
			.deankclist li#deanidlist h3{ padding:5px 10px; height:30px; line-height:30px; display:block;white-space:nowrap; overflow:hidden; text-overflow:ellipsis; overflow:hidden;}
			.deankclist li#deanidlist .auth{ background:#fff; border-top:1px solid #f0f0f0; border-radius:0 0 3px 3px; padding:5px 10px; color:#666; position:relative;}
				.deankclist li#deanidlist .auth b.deanarrowss{ position: absolute; z-index: 11; top: -11px; left: 15px; border-width:6px;  overflow: visible; display:block; border: 5px dashed transparent; border-bottom-color: #ededed;}
					.deankclist li#deanidlist .auth b.deanarrowss i{position: absolute; width: 0; height: 0; top: -3px; left: -5px; border:5px solid transparent; border-bottom-color: #fff; display:block; }
			.deankclist li#deanidlist h3 a{ color:#333; font-size:16px;}
			.deankclist li#deanidlist h3 a:hover{ color:#00B091;}
			.deankclist li#deanidlist .auth .xg1, .waterfall .auth a{ color:#aaa!important; font-size:12px;}
			
			.deanyhz{ height:30px; margin:5px 0; line-height:30px;}
				.deanyhz img{ width:30px; height:30px; border-radius:30px; float:left;}
				.deanyhz b{ float:left; font-weight:normal; display:block;  padding-left:10px;}
			.deantnums{ height:30px; line-height:30px; font-size:12px; color:#bbb; width:100%; overflow:hidden;}
				.deantnums b{ display:block; float:left; font-weight:normal; overflow:hidden;}
				.deantnums i{ display:block; margin:0 4px; border-right:1px solid #ddd; float:left; width:1px; height:12px; margin-top:10px;}


  .deankclist li#deanidlists{  width:45.5%; height:177px; margin-left:2.5%; border:1px solid #e6e6e6; background:#fff; margin-bottom:10px; float:left; position:relative;-ms-transition: transform .2s; -webkit-transition: transform .2s; -moz-transition: transform .2s; transition: transform .2s;}
		.deankclist li#deanidlists:hover{ transform: translateY(-6px);
    -webkit-transform: translateY(-6px);
    -moz-transform: translateY(-6px);
    box-shadow: 0 26px 40px -24px rgba(0,36,100,0.3);
    -webkit-box-shadow: 0 26px 40px -24px rgba(0,36,100,0.3);
    -moz-box-shadow: 0 26px 40px -24px rgba(0,36,100,0.3);
    -webkit-transition: all 0.3s ease;
    -moz-transition: all 0.3s ease;
    -o-transition: all 0.3s ease;
    transition: all 0.3s ease;}
		.deankclist li#deanidlists .c, .deankclist li#deanidlists h3{ font-size:13px; background:#fff; border-color:#e6e6e6; font-weight:normal; }
		.deankclist li#deanidlists .c{ height:95px; overflow:hidden; width:100%;}
		li#deanidlists .c img{ width:100%; height:100%;}
		.deankclist li#deanidlists .c{ padding:0; position:relative; z-index:1;}
			.deankclist li#deanidlists h3{ padding:5px 10px; height:30px; line-height:30px; display:block;white-space:nowrap; overflow:hidden; text-overflow:ellipsis; overflow:hidden;}
			.deankclist li#deanidlists .auth{ background:#fff; border-top:1px solid #f0f0f0; border-radius:0 0 3px 3px; padding:5px 10px; color:#666; position:relative;}
				.deankclist li#deanidlists .auth b.deanarrowss{ position: absolute; z-index: 11; top: -11px; left: 15px; border-width:6px;  overflow: visible; display:block; border: 5px dashed transparent; border-bottom-color: #ededed;}
					.deankclist li#deanidlists .auth b.deanarrowss i{position: absolute; width: 0; height: 0; top: -3px; left: -5px; border:5px solid transparent; border-bottom-color: #fff; display:block; }
			.deankclist li#deanidlists h3 a{ color:#333; font-size:16px;}
			.deankclist li#deanidlists h3 a:hover{ color:#00B091;}
			.deankclist li#deanidlists .auth .xg1, .waterfall .auth a{ color:#aaa!important; font-size:12px;}
  
  
  
.deanpang .deanddimg{ width:100%; height:120px; overflow:hidden; position:relative;}
	.deanpang .deanddimg img{ width:100%;  }
	.deanpang .deanddimg a{ display:block;  width:100%; height:120px;  }
	.deanpang .deanddimg a .deancoverimg1{ width:100%; height:120px;  background:rgba(0,0,0,0.5); font-size:12px; color:#fff; font-weight:normal; position:absolute; top:0; left:0; opacity:0; -webkit-transition:all 0.3s linear;-o-transition:all 0.3s linear;-ms-transition:all 0.3s linear;-moz-transition:all 0.3s linear;transition:all 0.3s linear;}
	.deanpang .deanddimg a:hover .deancoverimg1{ opacity:1;}
	.deancvinfos{ display:block; width:90%; font-size:12px; color:#fff; height:50px; line-height:25px; overflow:hidden; margin:0 auto; padding:0 5%;}
	.deancoverimg1 b{ height:25px; line-height:25px; font-weight:normal; width:70px; text-align:center; background:#f60; color:#fff; margin:10px auto; display:block;}
	.deancoverimg1 em{ display:block; width:50%; padding-top:5px; padding-left:5%; margin:0 auto; font-size:12px; color:#fff;}
	.deanpang .deanddimg a:hover img{transform: scale(1.2); -moz-transform: scale(1.2); -webkit-transform: scale(1.2); -o-transform: scale(1.2); -ms-transform: scale(1.2);}
.deanpang h3{ padding:5px; padding-bottom:0; font-weight:500; display:block;white-space:nowrap; overflow:hidden; text-overflow:ellipsis;}
	.deanpang h3 a{ font-size:16px; color:#333;}
	.deanpang h3 a:hover{ text-decoration:underline; }
.deanpang .deannum{ font-size:12px; padding:0px 10px; padding-top:10px;}
	.deanpang .deannum span{ float:left; color:#a8a8a8;}
	.deanpang .deannum a{ font-weight:500; float:right; color:#a8a8a8;}				

				
</style>
<div class="deankclist">
	<ul>
    	$sorttemplate['body']
        <div class="clear"></div>
    </ul>
</div>

