<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}

$deanbid = substr($thread[tid], -1);
$deanpicnums = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$deanbid.'')." WHERE tid = '$thread[tid]' AND isimage = '1'"));
?>
