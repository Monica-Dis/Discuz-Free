/**
 * jQuery's jqfaceedit Plugin
 *
 * @author cdm
 * @version 0.2
 * @copyright Copyright(c) 2012.
 * @date 2012-08-09
 */
(function($) {
    var em = [
                {'id':1,'phrase':':)','url':'smile.gif'},
				{'id':2,'phrase':':(','url':'sad.gif'},
                {'id':3,'phrase':':D','url':'biggrin.gif'},
				{'id':4,'phrase':':kuqi:','url':'cry.gif'},
				{'id':5,'phrase':':@','url':'huffy.gif'},
				{'id':6,'phrase':':o','url':'shocked.gif'},
				{'id':7,'phrase':':P','url':'tongue.gif'},
				{'id':8,'phrase':':$','url':'shy.gif'},
				{'id':9,'phrase':';P','url':'titter.gif'},
				{'id':10,'phrase':':L','url':'sweat.gif'},
				{'id':11,'phrase':':Q','url':'mad.gif'},
				{'id':12,'phrase':':lol','url':'lol.gif'},
				{'id':13,'phrase':':loveliness:','url':'loveliness.gif'},
				{'id':14,'phrase':':funk:','url':'funk.gif'},
				{'id':15,'phrase':':curse:','url':'curse.gif'},
				{'id':16,'phrase':':dizzy:','url':'dizzy.gif'},
				{'id':17,'phrase':':shutup:','url':'shutup.gif'},
				{'id':18,'phrase':':sleepy:','url':'sleepy.gif'},
				{'id':19,'phrase':':hug:','url':'hug.gif'},
				{'id':20,'phrase':':victory:','url':'victory.gif'},
				{'id':21,'phrase':':time:','url':'time.gif'},
				{'id':22,'phrase':':kiss:','url':'kiss.gif'},
				{'id':23,'phrase':':handshake','url':'handshake.gif'},
				{'id':24,'phrase':':call:','url':'call.gif'},
            ];
    //textarea���ù��λ��
    function setCursorPosition(ctrl, pos) {
        if(ctrl.setSelectionRange) {
            ctrl.focus();
            ctrl.setSelectionRange(pos, pos);
        } else if(ctrl.createTextRange) {// IE Support
            var range = ctrl.createTextRange();
            range.collapse(true);
            range.moveEnd('character', pos);
            range.moveStart('character', pos);
            range.select();
        }
    }

    //��ȡ�����ı�����λ��
    function getPositionForTextArea(obj)
    {
        var Sel = document.selection.createRange();
        var Sel2 = Sel.duplicate();
        Sel2.moveToElementText(obj);
        var CaretPos = -1;
        while(Sel2.inRange(Sel)) {
            Sel2.moveStart('character');
            CaretPos++;
        }
       return CaretPos ;

    }

    $.fn.extend({
        jqfaceedit : function(options) {
            var defaults = {
                txtAreaObj : '', //TextArea����
                containerObj : '', //����򸸶���
                textareaid: 'needmessage',//textareaԪ�ص�id
                popName : '', //iframe����������,containerObjΪ������ʱʹ��
                emotions : em, //������Ϣjson��ʽ��id��������� phrase����ʹ�õ��������url�����ļ���
                top : 0, //���ƫ��
                left : 0 //���ƫ��
            };
            
            var options = $.extend(defaults, options);
            var cpos=0;//���λ�ã�֧�ִӹ�괦��������
            var textareaid = options.textareaid;
            
            return this.each(function() {
                var Obj = $(this);
                var container = options.containerObj;
                if ( document.selection ) {//ie
                    options.txtAreaObj.bind("click keyup",function(e){//�������̶���ʱ���ù��ֵ
                        e.stopPropagation();
                        cpos = getPositionForTextArea(document.getElementById(textareaid)?document.getElementById(textareaid):window.frames[options.popName].document.getElementById(textareaid));
                    });
                }
                $(Obj).bind("click", function(e) {
                    e.stopPropagation();
                    var faceHtml = '<div id="face">';
                    faceHtml += '<div id="facebox">';
                    faceHtml += '<div id="face_detail" class="facebox clearfix"><ul>';

                    for( i = 0; i < options.emotions.length; i++) {
                        faceHtml += '<li text=' + options.emotions[i].phrase + ' type=' + i + '><img title=' + options.emotions[i].phrase + ' src="template/zhikai_n5mobi/touch/style/bq/'+ options.emotions[i].url + '"  style="cursor:pointer; position:relative;"   /></li>';
                    }
                    faceHtml += '</ul></div>';
                    faceHtml += '</div><div class="arrow arrow_t"></div></div>';

                    container.find('#face').remove();
                    container.append(faceHtml);
                    
                    container.find("#face_detail ul >li").bind("click", function(e) {
                        var txt = $(this).attr("text");
                        var faceText = txt;

                        //options.txtAreaObj.val(options.txtAreaObj.val() + faceText);
                        var tclen = options.txtAreaObj.val().length;
                        
                        var tc = document.getElementById(textareaid);
                        if ( options.popName ) {
                            tc = window.frames[options.popName].document.getElementById(textareaid);
                        }
                        var pos = 0;
                        if( typeof document.selection != "undefined") {//IE
                            options.txtAreaObj.focus();
                            setCursorPosition(tc, cpos);//���ý���
                            document.selection.createRange().text = faceText;
                            //������λ��
                            pos = getPositionForTextArea(tc); 
                        } else {//���
                            //������λ��
                            pos = tc.selectionStart + faceText.length;
                            options.txtAreaObj.val(options.txtAreaObj.val().substr(0, tc.selectionStart) + faceText + options.txtAreaObj.val().substring(tc.selectionStart, tclen));
                        }
                        cpos = pos;
                        setCursorPosition(tc, pos);//���ý���
                        container.find("#face").remove();

                    });
                    //����js�¼�ð������
                    $('body').bind("click", function(e) {
                        e.stopPropagation();
                        container.find('#face').remove();
                        $(this).unbind('click');
                    });
                    if(options.popName != '') {
                        $(window.frames[options.popName].document).find('body').bind("click", function(e) {
                            e.stopPropagation();
                            container.find('#face').remove();
                        });
                    }
                    container.find('#face').bind("click", function(e) {
                        e.stopPropagation();
                    });
                    var offset = $(e.target).offset();
                    offset.top += options.top;
                    offset.left += options.left;
                    container.find("#face").css(offset).show();
                });
            });
        },
    })
})(jQuery);

