<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style type="text/css">
.search{ padding-top:40px; padding-left:20px;}
	.search .input{ height:48px; line-height:48px; border:1px solid #e6e6e6;}
	.button2{ height:50px; line-height:50px; margin:0; margin-top:2px; background:#f60; font-size:20px; font-weight:normal; border-radius:5px;}
#scbar_hot{ padding:10px 20px; white-space:nowrap;}
	#scbar_hot strong{ font-size:15px; line-height:30px; color:#666; font-weight:normal; float:left; margin-right:15px; margin-bottom:15px;}
	#scbar_hot a{ display:block; height:28px; float:left; padding:0 10px; line-height:28px; font-size:14px; border:1px solid #ddd; border-radius:15px; margin-right:15px; margin-bottom:15px;}
.threadlist .thread_tit{ padding:0px; margin:5px 20px; color:#FFB200; font-weight:normal; border-bottom:1px solid #e6e6e6;}
.threadlist li{ font-size:15px; border-bottom:1px solid #f0f0f0;}
	.threadlist li a{ padding:10px; font-size:15px;}
</style>
<!-- header start -->
<header class="header" style="display:none;">
	<div class="hdc cl">
		<!--{if $_G['setting']['domain']['app']['mobile']}-->
			{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
		<!--{else}-->
			{eval $nav = "forum.php";}
		<!--{/if}-->
		<h2><a title="$_G[setting][bbname]" href="$nav"><img src="{STATICURL}image/mobile/images/logo.png" /></a></h2>
		<ul class="user_fun">
			<li class="on"><a href="search.php?mod=forum" class="icon_search">{lang search}</a></li>
			<li><a href="forum.php?forumlist=1" class="icon_threadlist">{lang forum_list}</a></li>
			<li id="usermsg"><a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="icon_userinfo">{lang user_info}</a><!--{if $_G[member][newpm]}--><span class="icon_msg"></span><!--{/if}--></li>
			<!--{if $_G['setting']['mobile']['mobilehotthread']}-->
			<li><a href="forum.php?mod=guide&view=hot" class="icon_hotthread">{lang hot_thread}</a></li>
			<!--{/if}-->
		</ul>
	</div>
</header>
<!-- header end -->
<form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
			<input type="hidden" name="formhash" value="{FORMHASH}" />

			<!--{subtemplate search/pubsearch}-->

			<!--{eval $policymsgs = $p = '';}-->
			<!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
			<!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
			<!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
			<!--{/loop}-->
			<!--{if $policymsgs}--><p>{lang search_credit_msg}</p><!--{/if}-->
</form>

<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
	<!--{subtemplate search/thread_list}-->
<!--{/if}-->
<!--{template common/footer}-->
