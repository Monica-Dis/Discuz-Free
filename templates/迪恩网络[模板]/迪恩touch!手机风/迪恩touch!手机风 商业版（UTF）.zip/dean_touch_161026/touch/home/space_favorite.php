<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!-- header start -->
<style type="text/css">
.category .subname_list{ z-index:3;}
.category .subname_list ul{ border:0; box-shadow:0 0 0 #fff;}
.category .subname_list li{ border:1px solid #ddd; background:#fff; z-index:3;}
.threadlist li{ padding:0 15px; margin:0;}
.category .display{ width:120px; margin:0 auto;}
	.category .display h2{ font-size:16px; float:left;}
	.category .display em{ width:16px; height:16px; background:url(./template/dean_touch_161026/deancss/down.png) 0 0 no-repeat; background-size:16px 16px; display:block; float:left; margin-left:8px; margin-top:6px;}
</style>
<header class="header">
    <div class="nav">
		<a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="z"><img src="./template/dean_touch_161026/deancss/back.png" width="30" height="30" /></a>
		<!--{if $_GET['type'] == 'forum'}-->
		<span class="category">
			<span class="display name vm" href="#subname_list">
				<h2 class="tit">{lang favforum}</h2>
				<em></em>
                <div class="clear"></div>
			</span>
	        <div id="subname_list" class="subname_list" display="true">
				<ul>
				<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang favthread}</a></li>
				</ul>
	        </div>
		</span>
		<!--{else}-->
		<span class="category">
			<span class="display name vm" href="#subname_list">
				<h2 class="tit">{lang favthread}</h2>
				<em></em>
                <div class="clear"></div>
			</span>
	        <div id="subname_list" class="subname_list" display="true">
				<ul>
				<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=forum">{lang favforum}</a></li>
				</ul>
	        </div>
		</span>
		<!--{/if}-->
    </div>
</header>
<style type="text/css">
	.coll_list{ border:0;}
		.coll_list ul{}
			.coll_list ul li{ border-bottom:1px solid #e6e6e6;}
</style>
<!-- main collectlist start -->
<!--{if $_GET['type'] == 'forum'}-->
<div class="coll_list b_radius">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li><a href="$value[url]">$value[title]</a></li>
			<!--{/loop}-->
		<!--{else}-->
		<li>{lang no_favorite_yet}</li>
		<!--{/if}-->

	</ul>
</div>

<!--{else}-->
<div class="threadlist">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li><a href="$value[url]">$value[title]</a></li>
			<!--{/loop}-->
		<!--{else}-->
		<li>{lang no_favorite_yet}</li>
		<!--{/if}-->
	</ul>
</div>
<script type="text/javascript">
	$(".threadlist ul li:even").css("background","#f9f9f9");
</script>
<!--{/if}-->
<!-- main collectlist end -->
$multi
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
