<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style type="text/css">
.deanmythread{ }
	.deanmythread ul{}
		.deanmythread ul li{ padding:10px; border-bottom:1px solid #f0f0f0;}
			.deanmythread ul li span{ float:left; margin-top:3px;}
			.deanmythread ul li a{ float:left; color:#333; font-size:15px;}
			a.grey:link, a.grey:visited, a.grey:hover{color:#333; }
			.deanmythread ul li em{ float:right; display:block; text-indent:20px; height:18px; margin-top:5px; color:#96a0aa; font-size:12px; background:url(./template/dean_touch_161026/deancss/comment.png) 0 0 no-repeat; background-size:18px 18px;}
</style>
<!-- header start -->
<header class="header">
    <div class="nav">
       <a href="home.php?mod=space&uid=1&do=profile&mycenter=1" class="z"><img src="./template/dean_touch_161026/deancss/back.png" width="30" height="30"  /></a>
	   <span>{lang mythread}</span>
   </div>
</header>
<!-- header end -->
<!-- main threadlist start -->
<div class="deanmythread">
	<ul>
	<!--{if $list}-->
		<!--{loop $list $thread}-->
			<li>
                <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                    <span class="deanicon_top">置顶</span>
                <!--{elseif $thread['attachment'] == 2}-->
                    <span class="deanicon_tu">有图</span>
                <!--{/if}-->
                <!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
                <a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]">$thread[subject]</a>
                <!--{else}-->
                <a href="forum.php?mod=viewthread&tid=$thread[tid]" {if $thread['displayorder'] == -1}class="grey"{/if}>$thread[subject]</a>
                <!--{/if}-->
                <em class="num">{$thread[replies]}</em>
				<div class="clear"></div>
			</li>
		<!--{/loop}-->
	<!--{else}-->
		<li class="deannothread">{lang no_related_posts}</li>
	<!--{/if}-->
    
    
	</ul>
	$multi
</div>
<script type="text/javascript">
	$(".deanmythread ul li:even").css("background","#f9f9f9");
</script>
<!-- main threadlist end -->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
