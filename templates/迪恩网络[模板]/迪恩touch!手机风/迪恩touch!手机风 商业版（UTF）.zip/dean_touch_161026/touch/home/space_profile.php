<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !$_GET['mycenter']}-->

<!-- header start -->
<header class="header">
    <div class="nav">
		<a href="javascript:;" onclick="history.go(-1);" class="z"><img src="./template/dean_touch_161026/deancss/back.png"  width="30" height="30" /></a>
		<span><!--{if $_G['uid'] == $space['uid']}-->{lang myprofile}<!--{else}-->$space[username]{lang otherprofile}<!--{/if}--></span>
    </div>
</header>
<!-- header end -->
<!-- userinfo start -->
<div class="userinfo" >
	<div class="user_avatar">
		<div class="deanavatar_m" >
        	<span><img style="margin-top:0;" src="<!--{avatar($space[uid], middle, true)}-->" /></span>
        	<!--{if $_G['ols'][$space[uid]]}-->
				<em class="deanonline" alt="online" title="{lang online}">{lang online}</em>
			<!--{/if}-->
        </div>
		<h2 class="name">$space[username](UID: {$space[uid]})</h2>
        
	</div>
	<div class="deanuser_box">
		<ul>
			<li>{lang credits}:<span>$space[credits]</span></li>
			<!--{loop $_G[setting][extcredits] $key $value}-->
			<!--{if $value[title]}-->
			<li>$value[title]:<span>{$space["extcredits$key"]} $value[unit]</span></li>
			<!--{/if}-->
			<!--{/loop}-->
            <li>{lang friends_num}:<span> $space[friends]</span></li>
            <!--{if $_G['setting']['allowviewuserthread'] !== false}-->
                <!--{eval $space['posts'] = $space['posts'] - $space['threads'];}-->
                <li><a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=reply&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread&type=reply{/if}">{lang replay_num}:<span>$space[posts]</span></a></li>
                <li><a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=thread&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread{/if}">{lang threads_num}:<span>$space[threads]</span></a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('share')}-->
                <li>{lang shares_num}: <span>$space[sharings]</span></li>
            <!--{/if}-->
            <!--{if $_G[setting][homepagestyle]}-->
			<li>{lang space_visits}:<span>$space[views]</span></li>
			<!--{/if}-->
            <!--{if $space[oltime]}--><li>{lang online_time}:<span>$space[oltime] {lang hours}</span></li><!--{/if}-->
            <div class="clear"></div>
		</ul>
        <ul class="pf_l cl">
        	<!--{if in_array($_G[adminid], array(1, 2))}-->
			<li>Email:<span>$space[email]</span></li>
			<!--{/if}-->
			<!--{loop $profiles $value}-->
			<li>$value[title]:<span>$value[value]</span></li>
			<!--{/loop}-->
            <div class="clear"></div>
		</ul>
        <ul>
            <!--{if $space[adminid]}--><li><em class="xg1">{lang management_team}&nbsp;&nbsp;</em><span style="color:{$space[admingroup][color]}">{$space[admingroup][grouptitle]}</span> {$space[admingroup][icon]}</li><!--{/if}-->
            <li><em class="xg1">{lang usergroup}&nbsp;&nbsp;</em><span style="color:{$space[group][color]}"{if $upgradecredit !== false} class="xi2" onmouseover="showTip(this)" tip="{lang credits} $space[credits], {lang thread_groupupgrade} $upgradecredit {lang credits}"{/if}>{$space[group][grouptitle]}</span> {$space[group][icon]} <!--{if !empty($space['groupexpiry'])}-->&nbsp;{lang group_useful_life}&nbsp;<!--{date($space[groupexpiry], 'Y-m-d H:i')}--><!--{/if}--></li>
            <!--{if $space[extgroupids]}--><li><em class="xg1">{lang group_expiry_type_ext}&nbsp;&nbsp;</em>$space[extgroupids]</li><!--{/if}-->
            <li>{lang regdate}:<span>$space[regdate]</span></li>
            <div class="clear"></div>
        </ul>

	</div>
    <div class="clear"></div>
	<!--{if $space['uid'] == $_G['uid']}-->
	<div class="deanbtn_exit"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout_mobile}</a></div>
	<!--{/if}-->
</div>
<!-- userinfo end -->

<!--{else}-->

<!-- header start -->
<header class="header" style="display:none;">
	<div class="hdc cl">
		<!--{if $_G['setting']['domain']['app']['mobile']}-->
			{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
		<!--{else}-->
			{eval $nav = "forum.php";}
		<!--{/if}-->
		<h2><a title="$_G[setting][bbname]" href="$nav"><img src="{STATICURL}image/mobile/images/logo.png" /></a></h2>
		<ul class="user_fun">
			<li><a href="search.php?mod=forum" class="icon_search">{lang search}</a></li>
			<li><a href="forum.php?forumlist=1" class="icon_threadlist">{lang forum_list}</a></li>
			<li class="on" id="usermsg"><a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="icon_userinfo">{lang user_info}</a><!--{if $_G[member][newpm]}--><span class="icon_msg"></span><!--{/if}--></li>
			<!--{if $_G['setting']['mobile']['mobilehotthread']}-->
			<li><a href="forum.php?mod=guide&view=hot" class="icon_hotthread">{lang hot_thread}</a></li>
			<!--{/if}-->
		</ul>
	</div>
</header>
<!-- header end -->
<!-- userinfo start -->
<style type="text/css">
body,.bg{ background:#f2f2f2;}

		
</style>
<div class="userinfo">
	<div class="user_avatar">
    	<div class="deanavarblack">
        	<a href="home.php?mod=space&uid={$_G[uid]}">
            	<div class="deanavatar_m" style=" margin-top:30px;">
                    <span><img style="margin-top:0;" src="<!--{avatar($space[uid], middle, true)}-->" /></span>
                    <!--{if $_G['ols'][$space[uid]]}-->
                        <em class="deanonline" alt="online" title="{lang online}">{lang online}</em>
                    <!--{/if}-->
        		</div>
				<h2 class="name">$space[username](UID: {$space[uid]})</h2>
            </a>
        </div>
	</div>
	<div class="deanmylist">
		<ul>
			<li class="deanmylistli1"><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread"><i></i><span>{lang myfavorite}</span><b></b><div class="clear"></div></a></li>
			<li class="deanmylistli2"><a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me"><i></i><span>{lang mythread}</span><b></b><div class="clear"></div></a></li>
		</ul>
        <div class="clear"></div>
        <ul>
        	<li class="deanmylistli3"><a href="home.php?mod=space&do=pm"><i></i><span>{lang mypm}<!--{if $_G[member][newpm]}--><img src="{STATICURL}image/mobile/images/icon_msg.png" /><!--{/if}--></span><b></b><div class="clear"></div></a></li>
			<li class="deanmylistli4"><a href="home.php?mod=space&uid={$_G[uid]}"><i></i><span>{lang myprofile}</span><b></b><div class="clear"></div></a></li>
        </ul>
	</div>
</div>
<!-- userinfo end -->

<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
