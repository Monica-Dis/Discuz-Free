<?php echo '请支持迪恩网络正版 QQ1589787930';exit;?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by Discuz!</title>
<link rel="stylesheet" href="{STATICURL}image/mobile/style.css" type="text/css" media="all">
<script src="{STATICURL}js/mobile/jquery.min.js?{VERHASH}"></script>

<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>

<script src="{STATICURL}js/mobile/common.js?{VERHASH}" charset="{CHARSET}"></script>
<link href="./template/dean_touch_161026/deancss/common.css" type="text/css" rel="stylesheet" />
<link href="./template/dean_touch_161026/deancss/touch.css" type="text/css" rel="stylesheet" />

</head>

<body class="bg">
<div class="deanwrap">
	<div class="deanfudongceng">	
    	<div id="deanul">
    	<div class="deanheadertop">
            <div class="deanperson">
                <a class="deanpersonavar deanxz" href="home.php?mod=space&uid=$_G[uid]"><!--{avatar($_G[uid],middle)}--></a>
                <div class="deanuserinfo">
                	<a href="home.php?mod=space&uid=$_G[uid]" title="{lang visit_my_space}" class="deanusernames">{$_G[member][username]}</a>
                    <div class="clear"></div>
                	<div class="deangroups">$_G[group][grouptitle]&nbsp;&nbsp;&nbsp;{lang credits}: $_G[member][credits]</div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            
        </div>
        <div class="clear"></div>
        <div class="deannv">			
            <ul>
                <li><a href="portal.php?mobile=2">门户</a></li>
                <li><a href="forum.php?forumlist=1&mobile=2">论坛</a></li>
                <li><a href="forum.php?mod=forumdisplay&fid=2&mobile=2">美图欣赏</a></li>
                <li><a href="portal.php?mod=list&catid=1">资讯动态</a></li>
                <!--{if !$_G[uid]}--><li class="deanloginli"><a href="member.php?mod=logging&action=login" title="{lang login}" >{lang login}</a></li><!--{/if}-->
                <!--{if $_G[uid]}--><li class="deanexitli"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" title="{lang logout}" class="dialog">{lang logout}</a></li><!--{/if}-->
            </ul>
            <!--{hook/global_nav_extra}-->
        </div>
        <script type="text/javascript">
        	$(".deannv li").eq(0).addClass("deanli1");
			$(".deannv li").eq(1).addClass("deanli2");
			$(".deannv li").eq(2).addClass("deanli3");
			$(".deannv li").eq(3).addClass("deanli4");
			$(".deannv li").eq(4).addClass("deanli5");
			$(".deannv li").eq(5).addClass("deanli6");
			$(".deannv li").eq(6).addClass("deanli7");
			$(".deannv li").eq(7).addClass("deanli8");
			$(".deannv li").eq(8).addClass("deanli9");
        </script>
    </div>
    </div>    

        <div id="deantopnav">
            <div class="deanclick"></div>
            <div class="deantoptitle"><img src="./template/dean_touch_161026/deancss/logo.png" height="50" /></div>
            <div class="deansearch"><a href="search.php?mod=forum" class="icon_search"></a></div>
            <div class="clear"></div>          
        </div>
        <!--{hook/global_header_mobile}-->
        <div class="deanwp">
