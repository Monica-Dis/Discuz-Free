<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$dncounts = DB::fetch_all("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]' ");
$dnmbinfo = DB::fetch_all("SELECT * FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]' ");

$deanqm = DB::fetch_all("SELECT * FROM ".DB::table('common_member_field_forum')." WHERE uid = '$_G[uid]' ");
?>