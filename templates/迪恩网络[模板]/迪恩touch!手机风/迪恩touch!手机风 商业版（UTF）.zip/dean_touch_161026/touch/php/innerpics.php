<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$thread_id = substr($thread[tid], -1);
$dnpicfm = DB::fetch_all("SELECT * FROM ".DB::table('forum_threadimage')." WHERE tid = '$thread[tid]' ");

?>