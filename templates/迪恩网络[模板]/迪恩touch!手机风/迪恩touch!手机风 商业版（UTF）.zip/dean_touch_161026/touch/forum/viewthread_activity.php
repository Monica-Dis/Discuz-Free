<?php echo '';exit;?>
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>

<div class="mbn n5_hdztzt">
	<!--{if $activity['thumb']}--><img src="$activity['thumb']" width="{if $activity[width] > 230}230{else}$activity[width]{/if}" /><!--{else}--><img src="{IMGDIR}/nophoto.gif" width="230" height="230" /><!--{/if}-->
    <div class="n5_hdztjs">
    	<dl>
			<dt>{lang activity_type}: <strong>$activity[class]</strong></dt>
			<dt>{lang activity_starttime}:<span class="xi1">
				<!--{if $activity['starttimeto']}-->
					{lang activity_start_between}
				<!--{else}-->
					$activity[starttimefrom]
				<!--{/if}--></span>
			</dt>
			<dt>{lang activity_space}: $activity[place]</dt>
			<dt>{lang gender}:
				<!--{if $activity['gender'] == 1}-->
					{lang male}
				<!--{elseif $activity['gender'] == 2}-->
					{lang female}
				<!--{else}-->
					 {lang unlimited}
				<!--{/if}-->
			</dt>
			<!--{if $activity['cost']}-->
				<dt>{lang activity_payment}: $activity[cost] {lang payment_unit}</dt>
			<!--{/if}-->
		</dl>
		<!--{if !$_G['forum_thread']['is_archived']}-->
		<dl>
			<dt>{lang activity_already}:
				<em>$allapplynum</em> {lang activity_member_unit}
				<!--{if $post['invisible'] == 0 && ($_G['forum_thread']['authorid'] == $_G['uid'] || (in_array($_G['group']['radminid'], array(1, 2)) && $_G['group']['alloweditactivity']) || ( $_G['group']['radminid'] == 3 && $_G['forum']['ismoderator'] && $_G['group']['alloweditactivity']))}-->
					<span class="xi1">{lang activity_mod}</span>
				<!--{/if}-->
			</dt>
		</dl>
		<dl>
			<!--{if $activity['number']}-->
			<dt>{lang activity_about_member}:
				$aboutmembers {lang activity_member_unit}
			</dt>
			<!--{/if}-->
			<!--{if $activity['expiration']}-->
				<dt>{lang post_closing}: $activity[expiration]</dt>
			<!--{/if}-->
		</dl>
		<!--{/if}-->
	</div>
</div>




<!--{if $_G['uid'] && !$activityclose && (!$applied || $isverified == 2)}-->
	<div id="activityjoin" class="n5_hdztbm">
        <div class="xw1">{lang activity_join}</div>
		<div class="n5_hdztbn">
	<!--{if $_G['forum']['status'] == 3 && helper_access::check_module('group') && $isgroupuser != 'isgroupuser'}-->
        <p>{lang activity_no_member}</p>
        <p><a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="xi2">{lang activity_join_group}</a></p>
	<!--{else}-->
		<form name="activity" id="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}&mobile=2" >
			<input type="hidden" name="formhash" value="{FORMHASH}" />

			<!--{if $_G['setting']['activitycredit'] && $activity['credit'] && !$applied}--><p class="n5_hdztts">{lang activity_need_credit} $activity[credit] {$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</p><!--{/if}-->
                <!--{if $activity['cost']}-->
				   <div class="n5_hdztzf">
				   <p>{lang activity_paytype}：</p>
                   <p><label><input class="pr" type="radio" value="0" name="payment" id="payment_0" checked="checked" />{lang activity_pay_myself}</label> <label><input class="pr" type="radio" value="1" name="payment" id="payment_1" />{lang activity_would_payment} </label> <input name="payvalue" size="3" class="txt_s" /> {lang payment_unit}</p>
                   </div>
				<!--{/if}-->
                <!--{if !empty($activity['ufield']['userfield'])}-->
                    <!--{loop $activity['ufield']['userfield'] $fieldid}-->
                    <!--{if $settings[$fieldid][available]}-->
                        <strong>$settings[$fieldid][title]<span class="xi1">*</span></strong>
                        $htmls[$fieldid]
                    <!--{/if}-->
                    <!--{/loop}-->
                <!--{/if}-->
                <!--{if !empty($activity['ufield']['extfield'])}-->
                    <!--{loop $activity['ufield']['extfield'] $extname}-->
                        $extname<input type="text" name="$extname" maxlength="200" class="txt" value="{if !empty($ufielddata)}$ufielddata[extfield][$extname]{/if}" />
                    <!--{/loop}-->
                <!--{/if}-->
            <div class="n5_hdztly">{lang leaveword}<textarea name="message" maxlength="200" cols="28" rows="1" class="txt">$applyinfo[message]</textarea></div>
			<div class="o pns">
				<!--{if $_G['setting']['activitycredit'] && $activity['credit'] && checklowerlimit(array('extcredits'.$_G['setting']['activitycredit'] => '-'.$activity['credit']), $_G['uid'], 1, 0, 1) !== true}-->
					<p class="xi1">{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]} {lang not_enough}$activity['credit']</p>
				<!--{else}-->
					<input type="hidden" name="activitysubmit" value="true">
					<em class="xi1" id="return_activityapplies"></em>
					<button type="submit" class="n5_tsztan"><span>{lang submit}</span></button>
				<!--{/if}-->
			</div>
		</form>

		<script type="text/javascript">
			function succeedhandle_activityapplies(locationhref, message) {
				showDialog(message, 'notice', '', 'location.href="' + locationhref + '"');
			}
		</script>
	<!--{/if}-->
    	</div>
	</div>
<!--{elseif $_G['uid'] && !$activityclose && $applied}-->
<div id="activityjoincancel" class="n5_hdztqx">
    <div class="xw1">{lang activity_join_cancel}</div>
    <div class="n5_hdztqs">
        <form name="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <p>
            {lang leaveword}<input type="text" name="message" maxlength="200" class="px" value="" />
        </p>
        <p class="mtn">
        <button type="submit" name="activitycancel" class="n5_tsztan" value="true"><span>{lang submit}</span></button>
        </p>
        </form>
	</div>
</div>
<!--{/if}-->