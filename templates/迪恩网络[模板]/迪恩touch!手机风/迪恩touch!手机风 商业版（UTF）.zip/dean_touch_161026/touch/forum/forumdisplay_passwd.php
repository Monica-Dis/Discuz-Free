<?php echo '';exit;?>
<!--{template common/header}-->
<div class="dean_tbys cl">
    <a href="javascript:void(0);" onclick="return window.history.go(-1);" class="fhan">返回</a>
	<span class="dqym">输入密码</span>
</div>
<div class="dean_tbxj"></div>

<div id="ct" class="dean_hyysmm">
	<div class="mn">
		<div class="nfl">
			<div class="f_c">
				<h3 class="xs2 xi2 mbm">{lang forum_password_require}</h3>
				<div class="o">
					<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=pwverify">
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="password" name="pw" class="px vm" size="25" />
						&nbsp;<button class="pn pnc vm" type="submit" name="loginsubmit" value="true"><strong>{lang submit}</strong></button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="dean_dbcd">
	<a href="portal.php?mod=index" class="bottom_index">聚焦</a>
	<a href="forum.php?mod=guide&view=newthread" class="bottom_daodu">导读</a>
	<a href="forum.php?forumlist=1" class="bottom_history_on">社区</a>
	<a href="forum.php?mod=misc&action=nav" class="bottom_post">发布</a>
	<a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="bottom_member">我的<!--{if $_G[member][newprompt]}--><i>&nbsp;</i><!--{/if}--></a>
</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->