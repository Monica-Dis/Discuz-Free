<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!-- header start -->
<header class="header">
    <div class="nav">
		<div class="icon_edit y"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}"><span class="none">{lang send_threads}</span></a></div>
        <a href="forum.php?forumlist=1" class="z"><img src="./template/dean_touch_161026/deancss/back.png" width="30" height="30" /></a>
		<span class="category">
			<!--{if $subexists && $_G['page'] == 1}-->
			<span class="display name vm" href="#subname_list">
				<h2 class="tit"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></h2>
				<img src="{STATICURL}image/mobile/images/icon_arrow_down.png">
			</span>
			<div id="subname_list" class="subname_list" display="true" style="display:none;">
				<ul>
				<!--{loop $sublist $sub}-->
				<li>
					<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a>
				</li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{else}-->
			<span class="name">
				<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
			</span>
			<!--{/if}-->
		</span>
    </div>
</header>

<!-- header end -->
<div class="deanbkjs">
    <div class="deanbktopimg">
    	<!--{if $_G[forum][banner] && !$subforumonly}--><img src="$_G[forum][banner]" alt="$_G['forum'][name]" /><!--{/if}-->
        <a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" id="a_favorite" class="deanbanzhu" onclick="showWindow(this.id, this.href, 'get', 0);">{lang forum_favorite} <strong class="xi1" id="number_favorite" {if !$_G[forum][favtimes]} style="display:none;"{/if}><span id="number_favorite_num">$_G[forum][favtimes]</span></strong></a>
    </div>
    <div class="deanbkjsinfo">
        <div class="deanbkjsinfoc">
            <div class="z">
                <!--{if !$subforumonly}--><span class="xs1 xw0 i">{lang index_today}: <strong class="xi1">$_G[forum][todayposts]</strong><!--{if $_G[forum][todayposts]}--><!--{if $_G[forum][todayposts] < $_G[forum][yesterdayposts]}--><b class="ico_fall">&nbsp;</b><!--{else}--><b class="ico_increase">&nbsp;</b><!--{/if}--><!--{/if}--><span class="pipe">|</span>{lang index_threads}: <strong class="xi1">$_G[forum][threads]</strong><!--{if $_G[forum][rank]}--><span class="pipe">|</span>{lang rank}: <strong class="xi1" title="{lang previous_rank}:$_G[forum][oldrank]">$_G[forum][rank]</strong><!--{if $_G[forum][rank] <= $_G[forum][oldrank]}--><b class="ico_increase">&nbsp;</b><!--{else}--><b class="ico_fall">&nbsp;</b><!--{/if}--><!--{/if}--></span><!--{/if}-->
                <!--{if $moderatedby}--><span class="pipe">|</span>&nbsp;{lang forum_modedby}:<span>$moderatedby</span><!--{/if}-->
            </div>
            
            <div class="clear"></div>    
          </div>
      <!--{if (!empty($_G[forum][domain]) && !empty($_G['setting']['domain']['root']['forum'])) || $moderatedby || ($_G['page'] == 1 && $_G['forum']['rules'])}--><div class="deanrule"><div id="forum_rules_{$_G[fid]}" style="$collapse['forum_rules'];"><div class="ptn xg2">本版规则：$_G['forum'][rules]</div></div>
      </div>
        <!--{/if}-->
      <!--{if !empty($forumarchive)}-->
            <div id="forumarchive_menu" class="p_pop" style="display:none">
                <ul>
                    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">{lang threads_all}</a></li>
                    <!--{loop $forumarchive $id $info}-->
                    <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&archiveid=$id">{$info['displayname']} ({$info['threads']})</a></li>
                    <!--{/loop}-->
                </ul>
            </div>
        <!--{/if}-->
    </div>
</div>
<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->
<!--{if !$subforumonly}-->
<!--{eval include 'template/dean_touch_161026/touch/php/picstyle.php'}-->
<!--{if $picstyle == '1'}-->

<!--分类开始-->
<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
    <ul id="thread_types" class="ttp bm cl">
        <!--{hook/forumdisplay_threadtype_inner}-->
        <li id="ttp_all" {if !$_GET['typeid'] && !$_GET['sortid']}class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a></li>
        <!--{if $_G['forum']['threadtypes']}-->
            <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
                <!--{if $_GET['typeid'] == $id}-->
                <li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
                <!--{else}-->
                <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
                <!--{/if}-->
            <!--{/loop}-->
        <!--{/if}-->

        <!--{if $_G['forum']['threadsorts']}-->
            <!--{if $_G['forum']['threadtypes']}--><li><span class="pipe">|</span></li><!--{/if}-->
            <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
                <!--{if $_GET['sortid'] == $id}-->
                <li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
                <!--{else}-->
                <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
                <!--{/if}-->
            <!--{/loop}-->
        <!--{/if}-->
        <!--{hook/forumdisplay_filter_extra}-->
    </ul>
    <script type="text/javascript">showTypes('thread_types');</script>
<!--{/if}-->
	
    <div class="deanthreadlist">
			<ul>
			<!--{if $_G['forum_threadcount']}-->
				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
                	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<li>
                    
					<!--{hook/forumdisplay_thread_mobile $key}-->
                    <!--{eval include 'template/dean_touch_161026/touch/php/tupian.php'}-->
                    <!--{if $tupian}--><div class="deanwaterfallpic"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] ><img src="data/attachment/forum/$tupian" style="width:100%;"></a></div><!--{/if}-->
    				<div class="deanwatername">
                    	<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] >
                            <h3>$thread[subject]</h3>
                            <div class="clear"></div>
                            <div class="deanwaternum">
                                <span class="deanthrby">$thread[author]</span>
                                <em><strong>$thread[views]</strong>人看过</em>
                                <b><strong>$thread[replies]</strong>评论</b>
                                <div class="clear"></div>
                            </div>
                        </a>
                    </div>
    				
    				</li>
                <!--{/loop}-->
            <!--{else}-->
			<li class="deannothread">{lang forum_nothreads}</li>
			<!--{/if}-->
		</ul>
</div>

    
    
    
    
    
<!--{else}-->

<!--分类开始-->
<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
    <ul id="thread_types" class="ttp bm cl">
        <!--{hook/forumdisplay_threadtype_inner}-->
        <li id="ttp_all" {if !$_GET['typeid'] && !$_GET['sortid']}class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a></li>
        <!--{if $_G['forum']['threadtypes']}-->
            <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
                <!--{if $_GET['typeid'] == $id}-->
                <li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
                <!--{else}-->
                <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
                <!--{/if}-->
            <!--{/loop}-->
        <!--{/if}-->

        <!--{if $_G['forum']['threadsorts']}-->
            <!--{if $_G['forum']['threadtypes']}--><li><span class="pipe">|</span></li><!--{/if}-->
            <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
                <!--{if $_GET['sortid'] == $id}-->
                <li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
                <!--{else}-->
                <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
                <!--{/if}-->
            <!--{/loop}-->
        <!--{/if}-->
        <!--{hook/forumdisplay_filter_extra}-->
    </ul>
    <script type="text/javascript">showTypes('thread_types');</script>
<!--{/if}-->

	<div class="threadlist">
			<ul>
			<!--{if $_G['forum_threadcount']}-->
				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
                	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<li>
                    
					<!--{hook/forumdisplay_thread_mobile $key}-->
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] >
                    	
						<h3>
                            <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                            <span class="deanicon_top">置顶</span>
                            <!--{elseif $thread['digest'] > 0}-->
                            <span class="deanicon_top">精华</span>
                            <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                            <span class="deanicon_tu">有图</span>
                            <!--{/if}-->
                        	$thread[subject]
                        </h3>
                        <div class="clear"></div>
                        <div class="deanthr">
                            <div class="deanthrl">
                                <span class="deanthrby">$thread[author]</span>
                                <span class="deanthrdate">$thread[dateline]</span>
                                <div class="clear"></div>
                            </div>
                            <div class="deanthrr">
                                <span><!--{if $thread[recommends]}-->$thread[recommends]<!--{else}-->0<!--{/if}--></span>
                                <b>$thread[replies]</b>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
					</a>
					</li>
                <!--{/loop}-->
            <!--{else}-->
			<li class="deannothread" style="text-indent:5px;">{lang forum_nothreads}</li>
			<!--{/if}-->
		</ul>
</div>

<!--{/if}-->
$multipage
<!--{/if}-->
<!-- main threadlist end -->
<!--{hook/forumdisplay_bottom_mobile}-->
<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}-->
