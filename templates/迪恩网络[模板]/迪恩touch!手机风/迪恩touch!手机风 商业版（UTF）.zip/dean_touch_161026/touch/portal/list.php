<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--[name]{lang portalcategory_listtplname}[/name]-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->

<style type="text/css">

.scrolltop{ bottom:60px!important;}
.deanartsub{ white-space:nowrap;}
	.deanartsub a{ padding:0 10px; margin-bottom:10px; margin-left:15px; float:left; display:block; height:30px; line-height:30px; font-size:15px; border:1px solid #089FEE; color:#089FEE; border-radius:5px; }
.deanvdl{ margin:0 15px; margin-top:10px;}
	.deanvdl dl{}
		.deanvdl dl dd{ padding-bottom:10px; margin-bottom:10px; border-bottom:1px solid #e9e9e9;}
			.deanvimg{ width:39%; height:85px; float:left; overflow:hidden; position:relative;}
				.deanvimg img{ min-height:85px;}
				.deantypes{ height:25px; line-height:25px; padding:0 10px; border-radius:20px; background:rgba(0,0,0,0.6); color:#fff!important; font-size:12px; position:absolute; left:5px; top:5px;}
			.deanvinfo{ width:55%; float:left; margin-left:3%;}
				.deanvinfo h3{ font-size:16px; font-weight:normal; max-height:50px; line-height:25px; overflow:hidden; color:#333;}
				.deanvnums{ margin-top:10px; font-size:12px; color:#999;}
	
</style>


<header class="header">
    <div class="nav">
        <a href="javascript:;" onclick="history.go(-1)" class="z"><img src="./template/dean_touch_161026/deancss/back.png" width="30" height="30" /></a>
		<span>$cat[catname]</span>
    </div>
</header>

<div class="clear"></div>
<!--{if $cat[subs]}-->
<div class="deanartsub">
    <!--{eval $i = 1;}-->
    <!--{loop $cat[subs] $value}-->
    <!--{if $i != 1}--><!--{/if}--><a href="{$portalcategory[$value['catid']]['caturl']}" class="xi2">$value[catname]</a><!--{eval $i--;}-->
    <!--{/loop}-->
    <div class="clear"></div>
</div>
<!--{/if}-->


<div class="deanvdl">
    <!--{loop $list['list'] $value}-->
        <!--{eval $highlight = article_title_style($value);}-->
        <!--{eval $article_url = fetch_article_url($value);}-->
        <dl>
        	<!--{if $value[pic]}-->
        	<dd>
            	<a href="$article_url">
                    <div class="deanvimg"><img src="$value[pic]" alt="$value[title]" width="130" /><!--{if $value[catname] && $cat[subs]}--><em class="deantypes">$value[catname]</em><!--{/if}--></div>
                    <div class="deanvinfo">
                        <h3 $highlight>$value[title]<!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}--></h3>
                        <div class="clear"></div>
                        <div class="deanvnums"><span> $value[dateline]</span></div>
                    </div>
                    <div class="clear"></div>
                </a>
            </dd>
            <!--{/if}-->
            <!--{if !$value[pic]}-->
            <dd>
            	<a href="$article_url">
                    <div class="deanvinfo" style="width:100%; margin-left:0;">
                        <h3 $highlight>$value[title]<!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}--></h3>
                        <div class="clear"></div>
                        <div class="deanvnums"><span> $value[dateline]</span></div>
                    </div>
                    <div class="clear"></div>
                </a>
            </dd>
            <!--{/if}-->
        </dl>
    <!--{/loop}-->
</div>

<!--{if $list['multi']}--><div class="pgs cl">{$list['multi']}</div><!--{/if}-->

<a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a>

<!--{template common/footer}-->