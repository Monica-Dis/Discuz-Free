<?php echo '';exit;?>
<!--{template common/header}-->
<link href="template/dean_touch_161026/deancss/view.css" rel="stylesheet" type="text/css" />
<style type="text/css">
	.bg{ background:#fff;}
</style>
<div class="deansametop cl">
    <a href="javascript:void(0);" onclick="return window.history.go(-1);" class="deanfanhui"><b><i class="icon-angle-left"></i></b></a>
	<span class="deanbknames">评论</span>
	<a href="search.php?mod=forum" class="deansearchs"><em><i class="icon-search"></i></em></a>
</div>
<div class="dean_tbxj"></div>

<div class="dean_plny">
	<div class="mn">
		<div class="bm vw">
			<div class="deanpltit cl">
                <a href="$common_url" class="y">已有$csubject[commentnum]人评论</a>
		        <h3><a href="javascript:;" onclick="location.href=location.href.replace(/(\#.*)/, '')+'#message';$('message').focus();return false;">参与评论</a></h3>
	        </div>
			<div class="dean_plkj">
			<!--{loop $commentlist $comment}-->
				<!--{template portal/comment_li}-->
			<!--{/loop}-->
			<!--{if $pricount}-->
				<p class="mbn mtn y">{lang hide_portal_comment}</p>
			<!--{/if}-->
			<div class="pgs cl mtm mbm">$multi</div>
			<!--{if $csubject['allowcomment'] == 1}-->
				<form id="cform" name="cform" action="portal.php?mod=portalcp&ac=comment" method="post" autocomplete="off">
					<div class="tedt">
						<div class="area">
							<textarea name="message" cols="60" rows="3" class="pt" id="message"></textarea>
						</div>
					</div>
					<!--{if $secqaacheck || $seccodecheck}-->
						<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
						<div class="mtm"><!--{subtemplate common/seccheck}--></div>
					<!--{/if}-->

					<!--{if $idtype == 'topicid' }-->
						<input type="hidden" name="topicid" value="$id">
					<!--{else}-->
						<input type="hidden" name="aid" value="$id">
					<!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}">
					<p class="ptn"><button type="submit" name="commentsubmit" value="true" class="dean_plan">{lang comment}</button></p>
				</form>
			<!--{/if}-->
			</div>
		</div>
	</div>
</div>


<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->