<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<link href="./template/dean_touch_161026/deancss/js/scroll.min.css" type="text/css" rel="stylesheet" />
<link href="./template/dean_touch_161026/deancss/index.css" type="text/css" rel="stylesheet" />
<script src="./template/dean_touch_161026/deancss/js/swiper.jquery.min.js" type="text/javascript"></script>

<div class="wp">
	<div class="deansnav">
    	<ul>
        	<li class="a"><a href="portal.php">首页</a></li>
            <li><a href="forum.php?forumlist=1&mobile=2">论坛</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=2&mobile=2">美图</a></li>
            <li><a href="portal.php?mod=list&catid=1">资讯</a></li>
            <li class="deanmorela"><span></span></li>
            <div class="clear"></div>
        </ul>
    </div>
    <dl class="deansdl">
        <dd><a href="portal.php?mod=list&catid=2">摄影</a></dd>
        <dd><a href="portal.php?mod=list&catid=3">模特</a></dd>
        <dd><a href="portal.php?mod=list&catid=4">造型</a></dd>
        <dd><a href="#">设计</a></dd>
        <dd><a href="#">艺术</a></dd>
        <dd><a href="#">广告</a></dd>
        <dd><a href="#">演艺</a></dd>
        <dd><a href="#">游戏</a></dd>
        <dd><a href="#">动漫</a></dd>
        <dd><a href="#">插画</a></dd>
        <div class="clear"></div>
    </dl>
    <script type="text/javascript">$(".deanmorela").each(function(s){$(this).click(function(){$(".deansdl").toggle();$(".deanmorela").toggleClass("cur");})})</script>

	<!--幻灯片-->
	<section class="banner banner-zixun">
        <div class="swiper-container swiper-container-banner swiper-container-horizontal">
            <div class="swiper-wrapper" style="transform: translate3d(0px, 0px, 0px); transition-duration: 0ms;"><!--{block/3}--></div>
            <div class="swiper-pagination swiper-pagination-bullets"></div>
        </div>
	</section>
	<!--热门板块-->
	<div class="deanpforum">
        <ul>
        	<!--{block/4}-->
            <div class="clear"></div>
        </ul>
    </div>
    <div class="clear"></div>
    <!--热门话题-->
	<div class="deanhotht">
    	<div class="deanptit1"><img src="./template/dean_touch_161026/deancss/portal/tit2.png" height="23" /></div>
        <div class="clear"></div>
        <ul><!--{block/5}--></ul>
    </div>
    <!--美图秀-->
    <div class="clear"></div>
    <div class="deanwaterfall">
    	<div class="deantitlename"><a href="#">美图秀</a><span></span><div class="clear"></div></div>
        <div class="clear"></div>
        <ul>
        	<!--{block/6}-->
            <div class="clear"></div>
        </ul>
    </div>
    <!--tab-->
    <div class="clear"></div>
    <div class="deantab">
    	<ul class="deantabn"><li class="cur">全部</li><li>最新</li><li>最热</li><li>精华</li><li>回复</li><div class="clear"></div></ul>
        <div class="clear"></div>
        <ul class="deantabc">
        	<li style="display:block;"><dl><!--{block/7}--></dl></li>
            <li><dl><!--{block/8}--></dl></li>
            <li><dl><!--{block/9}--></dl></li>
            <li><dl><!--{block/8}--></dl></li>
            <li><dl><!--{block/7}--></dl></li>
        </ul>
    </div>
    <script type="text/javascript">
    	$(".deantabn li").each(function(s){
			$(this).hover(function(){
				$(this).addClass("cur").siblings().removeClass("cur");
				$(".deantabc li").eq(s).show().siblings().hide();
				})
			})
    </script>
    
    <div class="clear"></div>
    <div class="deanad"><a href="#"><img src="./template/dean_touch_161026/deancss/portal/ad.jpg" /><span>广告</span></a></div>
    <div class="clear"></div>
    <!--红人馆-->
    <div class="deanhren">
    	<div class="deanptit1"><img src="./template/dean_touch_161026/deancss/portal/tit1.png" height="23" /></div>
        <div class="clear"></div>
        <ul>
        	<!--{block/10}-->
            <div class="clear"></div>
        </ul>
    </div>
</div>
<script>
    var mySwiper = new Swiper('.swiper-container-banner', {
        autoplay: 5000,
        direction: 'horizontal',
        speed: 300,
        paginationType: 'bullets',
        pagination: '.swiper-pagination', // 分页器
    });
</script>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->
