<?php echo 'www.verydean.com,��л��ҵ�֧��';exit;?>
<style type="text/css">
.bbda{ border-bottom:1px solid #f0f0f0!important;}

</style>
<!--{if $_G[setting][homepagestyle]}-->
	<!--{subtemplate home/space_header}-->
	<div id="ct" class="ct2 wp cl">
		<div class="mn">
			<div class="bm">
				<div class="bm_h">
					<h1 class="mt">{lang memcp_profile}</h1>
				</div>
			<div class="bm_c">
<!--{else}-->
	<!--{template common/header}-->
	<div id="pt" class="bm cl">
		<div class="z">
			<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
			<a href="home.php?mod=space&uid=$space[uid]">{$space[username]}</a> <em>&rsaquo;</em>
			{lang memcp_profile}
		</div>
	</div>
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<!--{template home/space_menu}-->
	<div id="ct" class="ct1 wp cl">
		<div class="mn">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<div class="bm_c">
<!--{/if}-->

				<!--{subtemplate home/space_profile_body}-->
		
				<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->
				</div>
			</div>
			<!--{if $_G[setting][homepagestyle]}-->
		</div>
		<div class="sd">
			<!--{subtemplate home/space_userabout}-->
		<!--{/if}-->
	</div>
</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->
<!--{template common/footer}-->
