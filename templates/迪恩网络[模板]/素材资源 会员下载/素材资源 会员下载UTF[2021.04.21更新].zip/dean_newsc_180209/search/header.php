<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{subtemplate common/header_common}-->
<link href="$_G['style'][styleimgdir]/js/main.css" type="text/css" rel="stylesheet" />
<link href="$_G['style'][styleimgdir]/js/a.css" type="text/css" rel="stylesheet" />
<link href="$_G['style'][styleimgdir]/font-awesome.min.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery-1.8.3.min.js"></script>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.bxslider.js"></script>   
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.flexslider-min.js"></script> 
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jPages.min.js"></script>
<script src="$_G['style'][styleimgdir]/js/jquery.lazyload.js"></script>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/wow.min.js"></script>
<script type="text/javascript">
    var jq=jQuery.noConflict();
</script>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/kefu.js"></script>
<script src="$_G['style'][styleimgdir]/js/wow.min.js"></script>
<script>new WOW().init();</script>
 
<script language="javascript" type="text/javascript">
    function killErrors() {
        return true;
    }
    window.onerror = killErrors;
</script>
</head>
<style type="text/css">
#toptb{ background:#fafafa!important; border-bottom:1px solid #f0f0f0!important;}
#toptb .z a{ padding-right:15px!important;}
body#nv_search{ background:#fff!important;}
.mw,#ct{width:1180px; margin:0 auto; }
.sttl{ width:587px; margin:0px auto; margin-bottom:20px; border-bottom:1px solid #f0f0f0; font-size:14px; font-weight:normal; background:#fefefe;}
	.sttl h2{ font-weight:normal;}
		.sttl h2 i{ padding-right:5px; color:#f60;}
.slst{ width:100%;}
.deanwaterfall{ width:1180px; margin:15px auto;}
	.deanwaterfall ul{ width:1200px;}
		.deanwaterfall li{ background:#fff; width:220px; height:300px; border:1px solid #f0f0f0; border-radius:0 0 3px 3px; margin-right:18px; float:left; margin-bottom:18px;  -ms-transition: transform .2s; -webkit-transition: transform .2s; -moz-transition: transform .2s; transition: transform .2s;}
		.deanwaterfall li:hover{ transform: translateY(-6px);
	-webkit-transform: translateY(-6px);
	-moz-transform: translateY(-6px);
	box-shadow: 0 26px 40px -24px rgba(0,36,100,0.3);
	-webkit-box-shadow: 0 26px 40px -24px rgba(0,36,100,0.3);
	-moz-box-shadow: 0 26px 40px -24px rgba(0,36,100,0.3);
	-webkit-transition: all 0.3s ease;
	-moz-transition: all 0.3s ease;
	-o-transition: all 0.3s ease;
	transition: all 0.3s ease;}
	.deanfmfm{ height:170px; overflow:hidden;}
		.deanfmfm img{}
		.deanwaterfall .c, .deanwaterfall h3{ font-size:13px; background:#fff; border-color:#e6e6e6; font-weight:normal; }
		.deanwaterfall .c{ padding:0; position:relative; z-index:1;}
			.deanwaterfall h3{ padding:5px 10px; height:30px; line-height:30px; display:block;white-space:nowrap; overflow:hidden; text-overflow:ellipsis; overflow:hidden;}
			.deanwaterfall .auth{ background:#fff; border-top:1px solid #f0f0f0; border-radius:0 0 3px 3px; padding:5px 10px; color:#666; position:relative;}
				.deanwaterfall .auth b.deanarrowss{ position: absolute; z-index: 11; top: -11px; left: 15px; border-width:6px;  overflow: visible; display:block; border: 5px dashed transparent; border-bottom-color: #ededed;}
					.deanwaterfall .auth b.deanarrowss i{position: absolute; width: 0; height: 0; top: -3px; left: -5px; border:5px solid transparent; border-bottom-color: #fff; display:block; }
			.deanwaterfall h3 a{ color:#333; font-size:16px; text-decoration:none;}
			.deanwaterfall h3 a:hover{ color:#00B091;}
			.deanwaterfall .auth .xg1, .waterfall .auth a{ color:#aaa!important; font-size:12px;}
			
			.deanyhz{ height:30px; margin:5px 0; line-height:30px;}
				.deanyhz img{ width:30px; height:30px; border-radius:30px; float:left;}
				.deanyhz b{ float:left; font-weight:normal; display:block;  padding-left:10px;}
			.deantnums{ height:30px; line-height:30px; font-size:12px; color:#bbb;}
				.deantnums b{ display:inline-block; float:left; font-weight:normal;}
				.deantnums i{ display:block; margin:0 7px; border-right:1px solid #ddd; float:left; width:1px; height:12px; margin-top:10px;}
			.slst a{ text-decoration:none;}
#toptb a{ color:#999;}
</style> 
<body id="nv_search" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<div id="toptb" class="cl">
		<div class="z">
			<a href="./" id="navs" class="showmenu xi2" onMouseOver="showMenu(this.id)">{lang return_homepage}</a>
		</div>
		<div class="y">
			<!--{if $_G['uid']}-->
				<strong><a href="home.php?mod=space" target="_blank" title="{lang visit_my_space}">{$_G[member][username]}</a></strong>
				<a href="javascript:;" id="myspace" class="showmenu xi2" onMouseOver="showMenu(this.id);">{lang my_nav}</a>
				<!--{hook/global_usernav_extra1}-->
				<a href="home.php?mod=spacecp">{lang setup}</a>
				<!--{if $_G['uid'] && ($_G['group']['radminid'] == 1 || getstatus($_G['member']['allowadmincp'], 1))}--><a href="admin.php" target="_blank">{lang admincp}</a><!--{/if}-->
				<!--{hook/global_usernav_extra2}-->
				<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
			<!--{elseif !empty($_G['cookie']['loginuser'])}-->
				<strong><a id="loginuser"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
				<a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang activation}</a>
				<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
			<!--{else}-->
				<a href="member.php?mod={$_G[setting][regname]}">$_G['setting']['reglinkname']</a>
				<a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang login}</a>
			<!--{/if}-->
		</div>
	</div>
	<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
		<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
		<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
		     <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
		     <li>$module[url]</li>
		     <!--{/if}-->
		<!--{/loop}-->
		</ul>
	<!--{/if}-->
	$_G[setting][menunavs]

	<!--{if $_G['setting']['navs']}-->
		<ul class="p_pop h_pop" id="navs_menu" style="display: none">
		<!--{loop $_G['setting']['navs'] $nav}-->
			<!--{eval $nav_showmenu = strpos($nav['nav'], 'onmouseover="showMenu(');}-->
		    <!--{eval $nav_navshow = strpos($nav['nav'], 'onmouseover="navShow(')}-->
		    <!--{if $nav_hidden !== false || $nav_navshow !== false}-->
			<!--{eval $nav['nav'] = preg_replace("/onmouseover\=\"(.*?)\"/i", '',$nav['nav'])}-->
		    <!--{/if}-->
			<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li $nav[nav]></li><!--{/if}-->
		<!--{/loop}-->
		</ul>
	<!--{/if}-->

	<ul id="myspace_menu" class="p_pop" style="display:none;">
		<!--{loop $_G['setting']['mynavs'] $nav}-->
			<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->
				<li>$nav[code]</li>
			<!--{/if}-->
		<!--{/loop}-->
	</ul>