<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.SuperSlide.2.1.1.js"></script>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/hd.js"></script>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.hoverdir.js"></script>
<script type="text/javascript">
	jq(function() {
		jq('#da-thumbs > li').hoverdir( {
			hoverDelay	: 75
		} );
	
	});
</script>
<div class="deanhdp"><!--[diy=deanhdp]--><div id="deanhdp" class="area"></div><!--[/diy]-->
    <div class="deanw1180s"><div class="deannavbox">
    <div class="deannavboxname">
        <ul>
            <li class="deanli1">
            	<a href="#" target="_blank" class="deanaaa"><em>ϵͳ/��ά �� ������</em></a>
            	<div class="deanp"><a href="#" target="_blank">Linux</a><a href="#" target="_blank">���ѧϰ</a><a href="#" target="_blank">Windows</a></div>
            </li>
            <li class="deanli2">
            	<a href="#" target="_blank" class="deanaaa"><em>������� �� Web����</em></a>
            	<div class="deanp"><a href="#" target="_blank">Python</a><a href="#" target="_blank">PHP</a><a href="#" target="_blank">Java</a></div>
            </li>
            <li class="deanli3">
            	<a href="#" target="_blank" class="deanaaa"><em>�ƶ����� �� ��Ϸ����</em></a>
            	<div class="deanp"><a href="#" target="_blank">HTML5</a><a href="#" target="_blank">Unity3D</a><a href="#" target="_blank">�ƶ�����</a></div>
            </li>
            <li class="deanli4">
            	<a href="#" target="_blank" class="deanaaa"><em>������֤ �� ���缼��</em></a>
            	<div class="deanp"><a href="#" target="_blank">����</a><a href="#" target="_blank">�������</a><a href="#" target="_blank">��ñ��֤</a></div>
            </li>
            <li class="deanli5">
            	<a href="#" target="_blank" class="deanaaa"><em>ϵͳ/��ά �� ������</em></a>
            	<div class="deanp"><a href="#" target="_blank">Linux</a><a href="#" target="_blank">���ѧϰ</a><a href="#" target="_blank">Windows</a></div>
            </li>
        </ul>
    </div>
    <div class="deannavboxc">
        <ul>
            <li class="deanliwrap1">
                <div class="deanliwrap">
                    <div class="deanliwl">
                        <h3><a href="#" target="_blank">����</a></h3>
                        <div class="clear"></div>
                        <div class="deanliwdl">    
      
                            <a href="#" target="_blank">Linux</a><em>/</em>
                            <a href="#" target="_blank">Windows</a><em>/</em>
                            <a href="#" target="_blank">Unix</a><em>/</em>
                            <a href="#" target="_blank">Mac</a><em>/</em>
                            <a href="#" target="_blank">os</a><em>/</em>
                            <a href="#" target="_blank">���ѧϰ</a><em>/</em>
                            <a href="#" target="_blank">Hadoop</a><em>/</em>
                            <a href="#" target="_blank">Spark</a><em>/</em>
                            <a href="#" target="_blank">Storm</a><em>/</em>
                            <a href="#" target="_blank">Hive</a><em>/</em>
                            <a href="#" target="_blank">Yarn</a><em>/</em>
                            <a href="#" target="_blank">����</a>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                        <div class="deanstudylist">
                        	<h3><a href="#" target="_blank">���ſγ��Ƽ�</a></h3>
                        	<div class="clear"></div>
                        	<dl>
                            	<!--[diy=deanstudylist]--><div id="deanstudylist" class="area"></div><!--[/diy]-->
                            </dl>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </li>
            <li class="deanliwrap2">
                <div class="deanliwrap">
                    <div class="deanliwl"> 
                        <h3><a href="#" target="_blank">����</a></h3>
                        <div class="clear"></div>
                        <div class="deanliwdl">          
                            <a href="#" target="_blank">Python</a><em>/</em>
                            <a href="#" target="_blank">Java</a><em>/</em>
                            <a href="#" target="_blank">C/C++</a><em>/</em>
                            <a href="#" target="_blank">.Net</a><em>/</em>
                            <a href="#" target="_blank">Ruby</a><em>/</em>
                            <a href="#" target="_blank">Objective-C</a><em>/</em>
                            <a href="#" target="_blank">Go����</a><em>/</em>
                            <a href="#" target="_blank">Qt</a><em>/</em>
                            <a href="#" target="_blank">VB</a><em>/</em>
                            <a href="#" target="_blank">Delphi</a><em>/</em>
                            <a href="#" target="_blank">R����</a><em>/</em>
                            <a href="#" target="_blank">PHP</a><em>/</em>
                            <a href="#" target="_blank">JavaScript</a><em>/</em>
                            <a href="#" target="_blank">jQuery</a><em>/</em>
                            <a href="#" target="_blank">Node.js</a><em>/</em>
                            <a href="#" target="_blank">XML/XSL</a>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                        <div class="clear"></div>
                        <div class="deanstudylist">
                        	<h3><a href="#" target="_blank">���ſγ��Ƽ�</a></h3>
                        	<div class="clear"></div>
                        	<dl>
                            	<!--[diy=deanstudylist1]--><div id="deanstudylist1" class="area"></div><!--[/diy]-->
                            </dl>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </li>
            <li class="deanliwrap3">
                <div class="deanliwrap">
                    <div class="deanliwl">
                        <h3><a href="#" target="_blank">����</a></h3>
                        <div class="clear"></div>
                        <div class="deanliwdl">       
                            <a href="#" target="_blank">HTML5</a><em>/</em>
                            <a href="#" target="_blank">�ƶ�����</a><em>/</em>
                            <a href="#" target="_blank">΢�ſ���</a><em>/</em>
                            <a href="#" target="_blank">iOS</a><em>/</em>
                            <a href="#" target="_blank">Android</a><em>/</em>
                            <a href="#" target="_blank">Swift</a><em>/</em>
                            <a href="#" target="_blank">WinPhone</a><em>/</em>
                            <a href="#" target="_blank">Unity3D</a><em>/</em>
                            <a href="#" target="_blank">Cocos2d-x</a><em>/</em>
                            <a href="#" target="_blank">VR������ʵ </a><em>/</em>
                            <a href="#" target="_blank">���ο���</a><em>/</em>
                            <a href="#" target="_blank">Swift</a><em>/</em>
                            <a href="#" target="_blank">3D��Ϸ</a><em>/</em>
                            <a href="#" target="_blank">��������</a><em>/</em>
                            <a href="#" target="_blank">����</a>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                        <div class="clear"></div>
                        <div class="deanstudylist">
                        	<h3><a href="#" target="_blank">���ſγ��Ƽ�</a></h3>
                        	<div class="clear"></div>
                        	<dl>
                            	<!--[diy=deanstudylist2]--><div id="deanstudylist2" class="area"></div><!--[/diy]-->
                            </dl>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </li>
            <li class="deanliwrap4">
                <div class="deanliwrap">
                    <div class="deanliwl">
                        <h3><a href="#" target="_blank">����</a></h3>
                        <div class="clear"></div>
                        <div class="deanliwdl">      
    
                            <a href="#" target="_blank">����</a><em>/</em>
                            <a href="#" target="_blank">��ñ��֤</a><em>/</em>
                            <a href="#" target="_blank">��Ϊ��֤</a><em>/</em>
                            <a href="#" target="_blank">˼����֤</a><em>/</em>
                            <a href="#" target="_blank">΢����֤</a><em>/</em>
                            <a href="#" target="_blank">H3C��֤</a><em>/</em>
                            <a href="#" target="_blank">�ȼ�����</a><em>/</em>
                            <a href="#" target="_blank">�������</a><em>/</em>
                            <a href="#" target="_blank">·�ɽ���</a><em>/</em>  
                            <a href="#" target="_blank">��ȫ����</a><em>/</em>
                            <a href="#" target="_blank">��ȫ����</a><em>/</em>
                            <a href="#" target="_blank">��������</a>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                        <div class="clear"></div>
                        <div class="deanstudylist">
                        	<h3><a href="#" target="_blank">���ſγ��Ƽ�</a></h3>
                        	<div class="clear"></div>
                        	<dl>
                            	<!--[diy=deanstudylist3]--><div id="deanstudylist3" class="area"></div><!--[/diy]-->
                            </dl>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </li>
            <li class="deanliwrap5">
                <div class="deanliwrap">
                    <div class="deanliwl">
                        <h3><a href="#" target="_blank">����</a></h3>
                        <div class="clear"></div>
                        <div class="deanliwdl">         
   
                            <a href="#" target="_blank">MySQL</a><em>/</em>
                            <a href="#" target="_blank">Oracle</a><em>/</em>
                            <a href="#" target="_blank">SQL</a><em>/</em>
                            <a href="#" target="_blank">Server</a><em>/</em>
                            <a href="#" target="_blank">Access</a>
                            <a href="#" target="_blank">DB2</a><em>/</em>
                            <a href="#" target="_blank">NoSQL</a><em>/</em>
                            <a href="#" target="_blank">MongoDB</a><em>/</em>
                            <a href="#" target="_blank">Hbase</a><em>/</em>
                            <a href="#" target="_blank">Excel</a><em>/</em>
                            <a href="#" target="_blank">PPT</a><em>/</em>
                            <a href="#" target="_blank">Word</a><em>/</em>
                            <a href="#" target="_blank">����</a>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                        <div class="deanstudylist">
                            <h3><a href="#" target="_blank">���ſγ��Ƽ�</a></h3>
                            <div class="clear"></div>
                            <dl>
                                <!--[diy=deanstudylist49]--><div id="deanstudylist49" class="area"></div><!--[/diy]-->
                            </dl>
                        </div>
                    </div>
                    
                    <div class="clear"></div>
                </div>
            </li>
        </ul>
    </div>
    <script type="text/javascript">
        jq(".deannavboxname li").each(function(s){
            jq(this).hover(
                function(){
                    jq(this).addClass("cur");
                    jq(".deannavboxc ul li").eq(s).show();
                },
                function(){
                    jq(this).removeClass("cur");
                    jq(".deannavboxc ul li").eq(s).hide();
                    })
            })
        jq(".deannavboxc ul li").each(function(s){
            jq(this).hover(
            function(){
                jq(this).show();
                jq(".deannavboxname li").eq(s).addClass("cur");
            },
            function(){
                jq(this).hide();
                jq(".deannavboxname li").eq(s).removeClass("cur");
                })
            })
    </script>
</div>
</div>
    <script type="text/javascript">
        jq(".deannavboxname ul li:last").css("border-bottom","0");
    </script>
</div>
<div class="clear"></div>
<div class="deanwp">
   	<div class="deancaselist"><ul><!--[diy=deancaselist]--><div id="deancaselist" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
    <div class="clear"></div>
    <div class="deancaset"><ul><!--[diy=deancaset]--><div id="deancaset" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
    <!--���пγ�-->
    <div class="deansource">
    	<div class="deanptitle" style=" padding:30px 0;"><h3>��У�γ�</h3><div class="clear"></div><span></span><div class="clear"></div><p>��ѡ��У�γ̣��������ѧϰ��Ȥ��</p></div>
        <div class="deansourcec">
            <div class="clear"></div>
            <ul class="deantabname">
                <li class="cur">ǰ�˿���</li>
                <li>�ƶ�����</li>
                <li>��˿���</li>
                <li>�˹�����</li>
                <li>����Ӳ��</li>
                <li>��Ʋ�Ʒ</li>
                <div class="clear"></div>
            </ul>
            <div class="deankclist">
                <div class="deantacdiv" style="display:block;"><ul><!--[diy=deansc1]--><div id="deansc1" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
                <div class="deantacdiv"><ul><!--[diy=deansc2]--><div id="deansc2" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
                <div class="deantacdiv"><ul><!--[diy=deansc3]--><div id="deansc3" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
                <div class="deantacdiv"><ul><!--[diy=deansc4]--><div id="deansc4" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
                <div class="deantacdiv"><ul><!--[diy=deansc5]--><div id="deansc5" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
                <div class="deantacdiv"><ul><!--[diy=deansc6]--><div id="deansc6" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
            </div>
            <div class="clear"></div>
            <a href="#" target="_blank" class="deanall">�鿴���пγ�</a>
            
        </div>
    </div>
    <script type="text/javascript">
		jq(".deantabname li").each(function(e){
			jq(this).hover(function(){
				jq(this).addClass("cur").siblings().removeClass("cur");
				jq(".deankclist .deantacdiv").eq(e).show().siblings().hide();
				})
			})
	</script>
    <div class="clear"></div>
    <div class="deankecheng">
        <div class="deankcc">
            <div class="deanptitle"><h3>18����Ŀ��300��רҵ�γ�</h3><div class="clear"></div><span></span><div class="clear"></div><p>ѡ��һ�ż��ܿ�ʼѧϰ������֪ʶ���Ըı�����</p></div>
            <div class="clear"></div>
            <ul><!--[diy=deankecheng]--><div id="deankecheng" class="area"></div><!--[/diy]--><div class="clear"></div></ul>
            <div class="clear"></div>
            <a href="#" target="_blank" class="deanall">ȫ����Ŀ</a>
        </div>
    </div>
    <div class="clear"></div>

	<div class="deanadthree"><ul><!--[diy=deanadthree]--><div id="deanadthree" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
    
    <div class="clear"></div>
    
    <div class="deanartice">
    	<div class="deanarticel  fadeInLeft">
            <div class="deantabtitle">
                <span>�ȵ���Ѷ</span>
                <ul class="deantabname1">
                    <li class="cur">��ѧ</li>
                    <li>��ѧ</li>
                    <li>��ѧ</li>
                    <div class="clear"></div>
                </ul>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            <div class="deansdivbox">
                <div class="deansdiv" style="display:block;">
                    <div class="deansdivhot"><!--[diy=deansdivhot]--><div id="deansdivhot" class="area"></div><!--[/diy]--></div>
                    <div class="clear"></div>
                    <dl><!--[diy=deansdivhotdl]--><div id="deansdivhotdl" class="area"></div><!--[/diy]--><div class="clear"></div></dl>
                    <div class="clear"></div>
                    <div class="deansdivhot"><!--[diy=deansdivhot2]--><div id="deansdivhot2" class="area"></div><!--[/diy]--></div>
                    <div class="clear"></div>
                    <dl><!--[diy=deansdivhotdl2]--><div id="deansdivhotdl2" class="area"></div><!--[/diy]--><div class="clear"></div></dl>
                </div>
                <div class="deansdiv">
                    <div class="deansdivhot"><!--[diy=deansdivhot3]--><div id="deansdivhot3" class="area"></div><!--[/diy]--></div>
                    <div class="clear"></div>
                    <dl><!--[diy=deansdivhotdl3]--><div id="deansdivhotdl3" class="area"></div><!--[/diy]--><div class="clear"></div></dl>
                    <div class="clear"></div>
                    <div class="deansdivhot"><!--[diy=deansdivhot4]--><div id="deansdivhot4" class="area"></div><!--[/diy]--></div>
                    <div class="clear"></div>
                    <dl><!--[diy=deansdivhotdl4]--><div id="deansdivhotdl4" class="area"></div><!--[/diy]--><div class="clear"></div></dl>
                </div>
                <div class="deansdiv">
                    <div class="deansdivhot"><!--[diy=deansdivhot5]--><div id="deansdivhot5" class="area"></div><!--[/diy]--></div>
                    <div class="clear"></div>
                    <dl><!--[diy=deansdivhotdl5]--><div id="deansdivhotdl5" class="area"></div><!--[/diy]--><div class="clear"></div></dl>
                    <div class="clear"></div>
                    <div class="deansdivhot"><!--[diy=deansdivhot6]--><div id="deansdivhot6" class="area"></div><!--[/diy]--></div>
                    <div class="clear"></div>
                    <dl><!--[diy=deansdivhotdl6]--><div id="deansdivhotdl6" class="area"></div><!--[/diy]--><div class="clear"></div></dl>
                </div>
            </div>
        </div>
        <div class="deanarticer">
        	<div class="deantabtitle"><span>ͼ����Ѷ</span><a href="#" target="_blank">����</a><div class="clear"></div></div>
            <div class="clear"></div>
            <div class="deanartl"><ul><!--[diy=deanartl]--><div id="deanartl" class="area"></div><!--[/diy]--></ul></div>
        </div>
        <div class="clear"></div>
    </div>
    <div class="clear"></div>
    <script type="text/javascript">
		jq(".deantabname1 li").each(function(s){
			jq(this).hover(function(){
				jq(this).addClass("cur").siblings().removeClass("cur");
				jq(".deansdivbox .deansdiv").eq(s).show().siblings().hide();
				})
			})
	</script>
    
    <div class="deannewhj  fadeInUp">
    	<div class="deanptitle"><h3>���¿γ̻���</h3><div class="clear"></div><span></span><div class="clear"></div><p>��ҵר�Ҵ������ѻ����γ̣�ע�ἴ��ѧϰ</p></div>
        <div class="clear"></div>
    	<div class="clear"></div>
        <div class="deansourcenewlist"><!--[diy=deannewhj]--><div id="deannewhj" class="area"></div><!--[/diy]--></div>
    </div>
    <script type="text/javascript">
		jq(function() {
			jq(".da-thumbs > li").hoverdir();
		});
	</script>
   
    
    <div class="deanhotnew">
        <div class="deanhotnewc">
            <div class="deanptitle"><h3>��������</h3><div class="clear"></div><span></span><div class="clear"></div><p>����С�飬�ύ����ͬѧ����ע�γ̶�̬��</p></div>
            <div class="clear"></div>
            <div class="deanbox  fadeInLeft">
                <div class="deanlines"></div>
                <ul><!--[diy=deanbox]--><div id="deanbox" class="area"></div><!--[/diy]--></ul>
            </div>
            <div class="deanforumbox  fadeInRight">
                <ul><!--[diy=deanforumbox]--><div id="deanforumbox" class="area"></div><!--[/diy]--></ul>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    
    <div class="deanteacher  fadeInUp">
        <div class="deanteacherc dean1180">
            <div class="deanptitle"><h3>Ȩ���Ƽ�</h3><div class="clear"></div><span></span><div class="clear"></div><p>��ҵ����Ϊ"���������ļ�����λ�˲�������ҡ��"</p></div>
            <div class="clear"></div>
            <div class="productflow">
                <span class="prev"></span>
                <span class="next"></span>
                <div class="deanscroll"><!--[diy=deanscroll]--><div id="deanscroll" class="area"></div><!--[/diy]--></div>
                <script type="text/javascript">
                     function DY_scroll(wraper,prev,next,img,speed,or)
                     { 
                      var wraper = jq(wraper);
                      var prev = jq(prev);
                      var next = jq(next);
                      var img = jq(img).find('ul');
                      var w = img.find('li').outerWidth(true);
                      var s = speed;
                      next.click(function()
                           {
                            img.animate({'margin-left':-w},function()
                                      {
                                       img.find('li').eq(0).appendTo(img);
                                       img.css({'margin-left':0});
                                       });
                            });
                      prev.click(function()
                           {
                            img.find('li:last').prependTo(img);
                            img.css({'margin-left':-w});
                            img.animate({'margin-left':0});
                            });
                      if (or == true)
                      {
                       ad = setInterval(function() { next.click();},s*1000);
                       wraper.hover(function(){clearInterval(ad);},function(){ad = setInterval(function() { next.click();},s*1000);});
                    
                      }
                     }
                     DY_scroll('.deanscroll','.prev','.next','.deanlistimg',3,true);// trueΪ�Զ����ţ����Ӵ˲�����false��Ĭ�ϲ��Զ�
                </script>
            </div>
        </div>
    </div>
    <!--�������-->
    <div class="clear"></div>
    <div class="deanpartc">
        <div class="deanparter">
            <div class="deanptitle"><h3>��ҵ��ҵ</h3><div class="clear"></div><span></span><div class="clear"></div><p>������������ҵ�Ѵ�2000��ң�����ս�Ժ���֪����ҵ�Ѵ�200���</p></div>
            <div class="clear"></div>
            <ul><!--[diy=deanparter]--><div id="deanparter" class="area"></div><!--[/diy]--><div class="clear"></div></ul>
        </div>
    </div>
    <!--��������-->
    <div class="deanlinkst">
        <div class="deanlinkc">
        	<div class="deantjtit">
                <i class="icon-link"></i>
                <span>�ٷ�����</span>
                <em>������������ QQ:3318850993</em>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            <ul><!--[diy=deanlink]--><div id="deanlink" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
            </ul>
            <script type="text/javascript">
            	jq(".deanlinkst ul li").eq(0).addClass("deanlinkli1");
            </script>
        </div>
    </div>
 
</div>

<div class="clear"></div>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

