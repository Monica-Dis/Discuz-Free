<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<div class="sttl mbn">
		<h2><i class="icon-star"></i><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($articlelist)}-->
		<p class="emp xg2 xs2">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="deanwaterfall">
			<ul class="cl">
				<!--{loop $articlelist $article}-->
				<li>
                	<div class="c cl deanfmfm"><a href="{echo fetch_article_url($article);}" target="_blank"><img src="$article[pic]" width="220"  height="140"/></a></div>
					<h3 class="xs3"><a href="{echo fetch_article_url($article);}" target="_blank">$article[title]</a></h3>
					<div class="auth cl">
                        <b class="deanarrowss"><i></i></b>
                        <div class="deanyhz">
                            <a href="home.php?mod=space&uid=$article[uid]"><img src="uc_server/avatar.php?uid=$article[uid]&size=large" /><b><a href="home.php?mod=space&uid=$article[uid]" target="_blank">$article[username]</a></b></a>
                          <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                        <div class="deantnums">  
                            <b>$article[viewnum] {lang a_visit}</b>
                            <i></i>
                            <b>$article[commentnum] {lang a_comment}</b><i></i>
                            <b style="width:58px; height:30px; display:block; overflow:hidden;">$article[dateline]</b>
                            <div class="clear"></div>
                        </div>
                    </div>
					
					
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>
