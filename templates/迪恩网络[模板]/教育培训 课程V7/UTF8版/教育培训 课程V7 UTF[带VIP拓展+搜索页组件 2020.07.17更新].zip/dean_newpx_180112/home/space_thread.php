<?php echo 'From: DisM.taobao.com';exit;?>
{eval
	$filter = array( 'common' => '{lang have_posted}', 'save' => '{lang draft}', 'close' => '{lang closed}', 'aduit' => '{lang pending}', 'ignored' => '{lang ignored}', 'recyclebin' => '{lang recyclebin}');
	$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=thread&view=me\">{lang they_thread}</a>";
}

<!--{if $diymode}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
        <style type="text/css">
    	.deanztlist{ width:700px!important; margin:20px auto; padding-bottom:50px; }
			.deanztlist ul{ width:730px!important; }
			.bm{ border:1px solid #e6e6e6;}
				.bm_h{ border-bottom:1px solid #e6e6e6;}
   		 </style>
		<div id="ct" class="ct2 wp cl">
			<div class="mn">
				<div class="bm">
					<div class="bm_h">
						<!--{if $space[self]}--><span class="xi2 y"><a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="addnew">{lang posted}</a></span><!--{/if}-->
						<h1 class="mt">
							<!--{if $_GET[type] == 'reply'}-->
							<span class="xs1 xw0"><a href="home.php?mod=space&do=thread&view=me&type=thread&uid=$space[uid]&from=space">{lang topic}</a><span class="pipe">|</span></span>{lang reply}
							<!--{else}-->
							{lang topic}<span class="xs1 xw0"><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=reply&uid=$space[uid]&from=space">{lang reply}</a></span>
							<!--{/if}-->
						</h1>
					</div>
				<div class="bm_c">
	<!--{else}-->
		<!--{template common/header}-->
		<div id="pt" class="bm cl">
			<div class="z">
				<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
				<a href="home.php?mod=space&uid=$space[uid]">{$space[username]}</a> <em>&rsaquo;</em>
				<a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me">{lang thread}</a>
			</div>
		</div>
		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="ct1 wp cl">
			<div class="mn">
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<div class="bm bw0">
					<div class="bm_c">
	<!--{/if}-->
<!--{else}-->
	<!--{template common/header}-->
	<div id="pt" class="bm cl">
		<div class="z">
			<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
			<!--{if $_G[setting][homestyle]}--><a href="home.php">$_G[setting][navs][4][navname]</a> <em>&rsaquo;</em> <!--{/if}-->
			<a href="home.php?mod=space&do=blog">{lang thread}</a>
		</div>
	</div>
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ct" class="ct2_a wp cl">
	<!--{if $_G[setting][homestyle]}-->
    
		<div class="appl">
			<!--{subtemplate common/userabout}-->
		</div>
		<div class="mn pbw">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<ul class="tb cl">
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
	<!--{else}-->
		<div class="appl">
			<div class="tbn">
				<h2 class="mt bbda">{lang thread}</h2>
				<ul>
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
		</div>
		<div class="mn pbw">
		<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
	<!--{/if}-->
<!--{/if}-->
		<style type="text/css">
        	.tbmu{  padding:0; height:41px; position:relative;}
				.deantbmuc{ position:absolute; left:0px; bottom:1px; z-index:2;}
					.deantbmuc a{ display:inline-block; display: inline-block; line-height: 26px; height: 26px; white-space: nowrap; padding: 0 10px; color: #8f8f8f; font-size: 14px; -webkit-border-radius: 4px; border-radius: 4px; margin-right:30px;}
					.deantbmuc a.a{ color: #fff; background: #3385ff; font-weight:normal;}
        </style>
		<!--{if !$diymode && $space[self]}-->
			<!--{if $_GET['view'] == 'me'}-->
			<p class="tbmu bw0">
				<!--{if $viewtype != 'postcomment'}-->
					<span class="y">
					<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=" {if !$_GET[filter]}class="a"{/if}>{lang all}</a>
					<!--{loop $filter $key $name}--><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=$key" {if $key == $_GET[filter]}class="a"{/if}>$name</a><!--{/loop}--> &nbsp;
						<select name="forumlist" id="forumlist" class="ps vm" onchange="viewforumthread(this.value);" style="width: 120px; word-wrap: normal;">
							<option value="0">{lang follow_select_forum}</option>
							$forumlist
						</select>
					</span>
				<!--{/if}-->
				<a href="home.php?mod=space&do=thread&view=me&type=thread" $orderactives[thread]>{lang topic}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=reply" $orderactives[reply]>{lang reply}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=postcomment" $orderactives[postcomment]>{lang post_comment}</a>
				<!--{if $viewtype != 'reply' && $viewtype != 'postcomment'}-->&nbsp; <input type="text" id="searchmypost" class="px vm" size="15" /> <button class="pn vm" onclick="searchpostbyusername($('searchmypost').value, '$_G[username]');"><em>{lang search}</em></button><!--{/if}-->
			</p>
			<!--{elseif $_GET['view'] == 'all'}-->
			<p class="tbmu bw0">
				<a href="home.php?mod=space&do=thread&view=all&order=dateline" $orderactives[dateline]>{lang newest_thread}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=all&order=hot" $orderactives[hot]>{lang top_thread}</a>
			</p>
			<!--{/if}-->
		<!--{/if}-->
		
		<!--{if $diymode && !$_G[setting][homepagestyle] }-->
			<div class="tbmu">
            	<div class="deantbmuc">
                    <a style="border-right:0;" href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread" $orderactives[thread]>{lang topic}</a>
                    <a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=reply" $orderactives[reply]>{lang reply}</a>
                </div>
			</div>
		<!--{/if}-->
		
		<!--{if $userlist}-->
			<p class="tbmu bw0">
				{lang view_by_friend}
				<select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
					<option value="">{lang all_friends}</option>
					<!--{loop $userlist $value}-->
					<option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
					<!--{/loop}-->
				</select>
			</p>
		<!--{/if}-->
        <style type="text/css">
        	.deanzxtabc{ width:1180px; margin:20px auto; padding-bottom:50px; }
				.deanzxtabc ul{ width:1200px; height:auto;}
					.deanzxtabc ul li{ float:left; width:278px; border:1px solid #f0f0f0; margin-right:20px; margin-bottom:20px; border-radius:6px; background:#fff; border-radius:3px;-webkit-transition: all .2s; -o-transition: all .2s; transition: all .2s;}
					.deanzxtabc ul li:hover{ -webkit-box-shadow: 0 0 10px rgba(0,0,0,.05); box-shadow: 0 0 10px rgba(0,0,0,.05); -webkit-transform: translateY(-3px);-ms-transform: translateY(-3px); transform: translateY(-3px);}	
						.deanzxfm{ width:278px; height:178px; overflow:hidden; border-radius:6px 6px 0 0 ;}		
							.deanzxfm img{ width:278px; min-height:178px;  border-radius:6px 6px 0 0 ;}	
							.deanzxtabc ul li:hover .deanzxfm img{ opacity:0.8;}
						.deanzxtabc ul li h5{ font-size:15px; line-height:23px; height:46px; overflow:hidden; font-weight:normal; padding:15px 20px; padding-bottom:0;}
							.deanzxtabc ul li h5 a{ color: #3c3c3c; -webkit-transition: all .2s; -o-transition: all .2s; transition: all .2s;}
							.deanzxtabc ul li h5 a:hover{ color:#3385ff;}	
						.deanzxinfos{ height:25px; line-height:25px; padding:0 20px; padding-bottom:15px; margin-top:10px;}
							.deanzximg{ float:left;}
								.deanzximg img{ width:25px; height:25px; border-radius:25px; float:left; display:block; margin-right:5px;}
								.deanzximg span{ float:left; font-size:12px; color:#bdbdbd;}
								.deanzximg:hover span{ color:#3385ff;}
							.deanforumname{ float:right; font-size:12px; color:#bdbdbd;}	
							.deanforumname:hover{ color:#3385ff;}
        </style>
		<div class="tl deanztlist">
			<form method="post" autocomplete="off" name="delform" id="delform" action="home.php?mod=space&do=thread&view=all&order=dateline" onsubmit="showDialog('{lang del_select_thread_confirm}', 'confirm', '', '$(\'delform\').submit();'); return false;">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="delthread" value="true" />

					
					<div class="deanzxtabc">
                        <!--{if $list}-->
                            <ul>
                            <!--{loop $list $stid $thread}-->
                                <!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
                                	<!--{if $thread['attachment'] == 2}-->
                                	<li>
                                    <!--{eval include 'template/dean_newpx_180112/php/innerpics.php'}-->
                                    <!--{loop $dnpicfm $homepic}-->
                                      <div class="deanzxfm"><a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank"><img src="data/attachment/forum/$homepic[attachment]" /></a></div>
                                    <!--{/loop}-->
                                    <h5><a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]" target="_blank">$thread[subject]</a></h5>
                                    <div class="clear"></div>
                                    <div class="deanzxinfos">
                                    	<a href="home.php?mod=space&uid=$space[uid]" class="deanzximg"><!--{avatar($space[uid],big)}--><span>{$space[username]}</span></a>
                                        <a href="forum.php?mod=forumdisplay&fid=$thread[fid]" class="deanforumname" target="_blank">$forums[$thread[fid]]</a>
                                        <div class="clear"></div>
                                	</div> 
                                </li>
                                	<!--{/if}-->
                              <!--{else}-->
                                	<!--{if $thread[attachment] == 2}-->
                                    <li>
                                    <!--主题-->
                                        <!--{eval include 'template/dean_newpx_180112/php/innerpics.php'}-->
                                        <!--{loop $dnpicfm $homepic}-->
                                            <div class="deanzxfm"><a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank"><img src="data/attachment/forum/$homepic[attachment]" /></a></div>
                                        <!--{/loop}-->
                                        <h5><a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank" {if $thread['displayorder'] == -1}class="recy"{/if}>$thread[subject]</a></h5>
                                        <div class="deanzxinfos">
											<a href="home.php?mod=space&uid=$space[uid]" class="deanzximg"><!--{avatar($space[uid],big)}--><span>{$space[username]}</span></a>
                                			<!--{if $viewtype != 'postcomment'}-->
                                            	<a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank" class="deanforumname">$forums[$thread[fid]]</a>
                                            <!--{/if}-->
                                			<div class="clear"></div>
                                        </div>
                                    </li>
                           	    <!--{/if}-->
                            	<!--{/if}-->
                            <!--{/loop}-->
                            <div class="clear"></div>
                            </ul>
                        <!--{else}-->
                        	<p class="emp">{lang no_related_posts}</p>
                        <!--{/if}-->
                    </div>	
					
                        
        
                  <div style="display:none;"> 
                    <!--{if $thread['digest'] > 0}-->
                        <img src="{IMGDIR}/digest_$thread[digest].gif" alt="{lang digest} $thread[digest]" align="absmiddle" />
                    <!--{/if}-->
                    <!--{if $thread['attachment'] == 2}-->
                        <img src="{STATICURL}image/filetype/image_s.gif" alt="{lang photo_accessories}" align="absmiddle" />
                    <!--{elseif $thread['attachment'] == 1}-->
                        <img src="{STATICURL}image/filetype/common.gif" alt="{lang accessory}" align="absmiddle" />
                    <!--{/if}-->
                    <!--{if $thread[multipage]}--><span class="tps">$thread[multipage]</span><!--{/if}-->
                    <!--{if !$_GET['filter']}-->
                        <!--{if $thread[$statusfield] == -1}--><span class="xg1">$filter[recyclebin]</span>
                        <!--{elseif $thread[$statusfield] == -2}--><span class="xg1">$filter[aduit]</span>
                        <!--{elseif $thread[$statusfield] == -3 && $thread[displayorder] != -4}--><span class="xg1">$filter[ignored]</span>
                        <!--{elseif $thread[displayorder] == -4}--><span class="xg1">$filter[save]</span>
                        <!--{elseif $thread['closed'] == 1}--><span class="xg1">$filter[close]</span>
                        <!--{/if}-->
                    <!--{/if}-->
                </div> 
						
					
					
				

					<!--{if $_GET['view'] == 'all' && $pruneperm && !$_GET['archiveid'] && $list}-->
						<p class="mtm pns">
							<label for="chkall" onclick="checkall(this.form, 'moderate')"><input type="checkbox" name="chkall" id="chkall" class="pc vm" />{lang select_all}</label>
							<button type="submit" name="delsubmit" value="true" class="pn vm"><em>{lang del_select_thread}</em></button>
						</p>
					<!--{/if}-->
				</form>

				<!--{if $hiddennum}-->
					<p class="mtm">{lang hide_thread}</p>
				<!--{/if}-->
			</div>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->		
		
		<script type="text/javascript">
		function fuidgoto(fuid) {
			window.location.href = 'home.php?mod=space&do=thread&view=we&fuid='+fuid;
		}
		function viewforumthread(fid) {
			window.location.href = '{$forumurl}&fid='+fid;
		}
		</script>
		
		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="sd">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->

<!--{template common/footer}-->