<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<div class="sttl mbn">
		<h2><i class="icon-star"></i><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page" target="_blank">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($threadlist)}-->
		<p class="emp xs2 xg2">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="slst mtw" id="threadlist" {if $modfid} style="position: relative;"{/if}>
			<!--{if $modfid}-->
			<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$modfid&infloat=yes&nopost=yes">
			<!--{/if}-->
            
            <div class="deanwaterfall">
            	<ul class="cl">
                	<!--{loop $threadlist $thread}-->
                    <li>
                        <div class="c cl deanfmfm">
                            <!--{eval include 'template/dean_newpx_180112/php/innerpics.php'}-->
                            <!--{loop $dnpicfm $deanptp}-->
                            <a href="forum.php?mod=viewthread&tid=$thread[realtid]" target="_blank">
                                <img src="data/attachment/forum/$deanptp[attachment]" width="220" height="140">
                            </a>
                            <!--{/loop}-->
                        </div>
                        <h3><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank" $thread[highlight]>$thread[subject]</a></h3>
                        <div class="auth cl">
                            <b class="deanarrowss"><i></i></b>
                            <div class="deanyhz">
                                <a href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread[authorid],middle)}-->
                                    <b>
                                    <!--{if $thread['authorid'] && $thread['author']}-->
                                        <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">$thread[author]</a>
                                    <!--{else}-->
                                    <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
                                    <!--{/if}-->
                                    </b>
                                </a>
                              <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                            <div class="deantnums">  
                                <b>$thread[views] {lang a_visit}</b>
                                <i></i>
                                <b>$thread[replies] {lang a_comment_thread}</b><i></i>
                                <b style="width:58px; height:30px; display:block; overflow:hidden;">$thread[dateline]</b>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </li>
                    <!--{/loop}-->
                    <div class="clear"></div>
                </ul>
            </div>
			
		<!--{if $modfid}-->
			</form>
			<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
			<!--{template forum/topicadmin_modlayer}-->
		<!--{/if}-->
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>