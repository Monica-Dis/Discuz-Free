<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $focusid = getfocus_rand($_G[basescript]);}-->
<!--{if $focusid !== null}-->
	<!--{eval $focus = $_G['cache']['focus']['data'][$focusid];}-->
	<div class="focus" id="focus">
		<div class="bm">
			<div class="bm_h cl">
				<a href="javascript:;" onclick="setcookie('nofocus_$focusid', 1, $_G['cache']['focus']['cookie']*3600);$('focus').style.display='none'" class="y" title="{lang close}">{lang close}</a>
				<h2><!--{if $_G['cache']['focus']['title']}-->{$_G['cache']['focus']['title']}<!--{else}-->{lang focus_hottopics}<!--{/if}--></h2>
			</div>
			<div class="bm_c">
				<dl class="xld cl bbda">
					<dt><a href="{$focus['url']}" class="xi2" target="_blank">$focus['subject']</a></dt>
					<!--{if $focus[image]}-->
					<dd class="m"><a href="{$focus['url']}" target="_blank"><img src="{$focus['image']}" alt="$focus['subject']" /></a></dd>
					<!--{/if}-->
					<dd>$focus['summary']</dd>
				</dl>
				<p class="ptn hm"><a href="{$focus['url']}" class="xi2" target="_blank">{lang focus_show} &raquo;</a></p>
			</div>
		</div>
	</div>
<!--{/if}-->

<!--{ad/footerbanner/wp a_f hm/1}--><!--{ad/footerbanner/wp a_f hm/2}--><!--{ad/footerbanner/wp a_f hm/3}-->
<!--{ad/float/a_fl/1}--><!--{ad/float/a_fr/2}-->
<!--{ad/couplebanner/a_fl a_cb/1}--><!--{ad/couplebanner/a_fr a_cb/2}-->

<!--{hook/global_footer}-->
<div class="deanfooter">
        <div class="deanfttop">
            <div class="deanw1180">
                <div class="deanlinks">
                    <ul>
                        <li>
                            <p>底部导航</p>
                            <!--{loop $_G['setting']['footernavs'] $nav}--><!--{if $nav['available'] && ($nav['type'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1)) ||
						!$nav['type'] && ($nav['id'] == 'stat' && $_G['group']['allowstatdata'] || $nav['id'] == 'report' && $_G['uid'] || $nav['id'] == 'archiver' || $nav['id'] == 'mobile' || $nav['id'] == 'darkroom'))}-->$nav[code]<!--{/if}--><!--{/loop}-->
                        </li>
                        <li>
                            <p>积分管理</p>
                            <a href="http://t.cn/Aiux14ti" target="_blank" >我的积分</a>
                            <a href="http://t.cn/Aiux14ti" target="_blank" >兑换奖品</a>
                            <a href="http://t.cn/Aiux14ti" target="_blank" >积分介绍</a>
                            <a href="http://t.cn/Aiux14ti" target="_blank" >查看晒单</a>
                        </li>
                        <li>
                            <p>关于我们</p>
                            <a href="http://t.cn/Aiux14ti" target="_blank" >联系我们</a>
                            <a href="http://t.cn/Aiux14ti" target="_blank" >管理团队</a>
                            <a href="http://t.cn/Aiux14ti" target="_blank" >发展历程</a>
                            <a href="http://t.cn/Aiux14ti" target="_blank" >安全保障</a>
                        </li>
                    </ul>
                </div>
                <div class="deanspread">
                    <p>关注我们：微信订阅号</p>
                    <div class="deanweixin">
                        <img src="$_G['style'][styleimgdir]/footer/weixin.jpg">
                        <p>官方微信</p>
                    </div>
                    <div class="deanappft">
                        <img src="$_G['style'][styleimgdir]/footer/weixin.jpg">
                        <p>APP下载</p>
                    </div>
                </div>
                <div class="deancontact">
                    <div class="deanfttel clear">
                        <span></span>
                        <div class="deanfttext">
                            <p>全国服务热线：</p>
                            <b>4000-018-018</b>
                        </div>
                    </div>
                    <p class="c-aaa">公司地址：上海市嘉定区银翔路655号B区1068室</p>
                    <p class="c-aaa">运营中心：成都市锦江区东华正街42号广电仕百达国际大厦25楼</p>
                    <p class="c-aaa">邮编：610066  Email：3318850993#qq.com</p>
                    
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="deanofficial">
           Copyright &nbsp;&nbsp;&copy;2019-2020&nbsp;&nbsp;<a href="$_G['setting']['siteurl']" target="_blank">$_G['setting']['sitename']</a>Powered by&copy;<a href="http://t.cn/Aiux1eta" target="_blank">DisM!</a>技术支持：<a href="http://t.cn/Aiux14ti" target="_blank">DisM!应用中心</a>&nbsp;&nbsp;<!--{if $_G['setting']['statcode']}-->$_G['setting']['statcode']<!--{/if}-->&nbsp;&nbsp;<!--{if $_G['setting']['icp']}-->( <a href="http://www.miitbeian.gov.cn/" target="_blank">$_G['setting']['icp']</a> )<!--{/if}--><!--{hook/global_footerlink}-->
        </div>
</div>
<div id="ft" class="w cl" style="display:none;">
	<em>Powered by <strong><a href="http://t.cn/Aiux1eta" target="_blank">DisM!</a></strong> <em>$_G['setting']['version']</em><!--{if !empty($_G['setting']['boardlicensed'])}--> <a href="http://license.comsenz.com/?pid=1&host=$_SERVER[HTTP_HOST]" target="_blank">Licensed</a><!--{/if}--></em> &nbsp;
	<em>&copy; 2001-2017 <a href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a></em>
	<span class="pipe">|</span>
	<!--{loop $_G['setting']['footernavs'] $nav}--><!--{if $nav['available'] && ($nav['type'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1)) ||
			!$nav['type'] && ($nav['id'] == 'stat' && $_G['group']['allowstatdata'] || $nav['id'] == 'report' && $_G['uid'] || $nav['id'] == 'archiver'))}-->$nav[code]<span class="pipe">|</span><!--{/if}--><!--{/loop}-->
	<strong><a href="$_G['setting']['siteurl']" target="_blank">$_G['setting']['sitename']</a></strong>
	<!--{if $_G['setting']['icp']}-->( <a href="http://www.miibeian.gov.cn/" target="_blank">$_G['setting']['icp']</a> )<!--{/if}-->
	<!--{hook/global_footerlink}-->
	<!--{if $_G['setting']['statcode']}--><span class="pipe">| $_G['setting']['statcode']</span><!--{/if}-->
	<!--{eval updatesession();}-->
</div>
<!--{if $_G[uid] && !isset($_G['cookie']['checkpm'])}-->
<script language="javascript"  type="text/javascript" src="home.php?mod=spacecp&ac=pm&op=checknewpm&rand=$_G[timestamp]"></script>
<!--{/if}-->
<!--{eval output();}-->
</body>
</html>