<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<div class="sttl mbn">
		<h2><i class="icon-star"></i><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($articlelist)}-->
		<p class="emp xg2 xs2">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="deanpiclist">
			<ul class="cl">
				<!--{loop $articlelist $article}-->
                <li>
                    <div class="deanpiclic">
                        
                        <a href="{echo fetch_article_url($article);}" target="_blank" class="deansearchimg"><img src="$article[pic]" width="210"  /></a>

                 
                        <div class="deanpiclicr">
                            <h2><a href="{echo fetch_article_url($article);}" target="_blank"> $article[title]</a></h2>
                            <div class="clear"></div>
                            <div class="deanpicsummary">$article[summary]</div>
                            <div class="clear"></div>
                            <div class="deannewtwonum">
                                <div class="deanartavar">
                                    <a href="home.php?mod=space&uid=$article[uid]"><img src="uc_server/avatar.php?uid=$article[uid]&size=large" /></a>
                                    <span>作者:$article[username]</span>
                                    <div class="clear"></div>
                                </div>
                                <i class="deanpipe"></i>
                                <b>时间：$article[dateline]</b>
                                <i class="deanpipe"></i>
                                <span>阅读$article[viewnum] {lang a_visit}</span>
                                <i class="deanpipe"></i>
                                <em>回复：$article[commentnum] {lang a_comment}</em>
                                <div class="clear"></div>
                            </div>
                            
                            <div class="clear"></div>
                        </div>                           
                        <div class="clear"></div>
                    </div>
                </li>
				
				<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>