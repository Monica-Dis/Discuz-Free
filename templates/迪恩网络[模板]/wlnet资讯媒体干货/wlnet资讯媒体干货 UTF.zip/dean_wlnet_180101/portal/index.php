<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.SuperSlide.2.1.1.js"></script>
<div class="deanwp">
	<div class="deanpart">
    	<div class="deanpartl">
        	<div class="deanboxone">
            	<div class="deannvhdp"><!--[diy=deanhdp]--><div id="deanhdp" class="area"></div><!--[/diy]--></div>
                <script type="text/javascript">
                	jq(".deannvhdp").slide({ mainCell:".bd ul", effect:"fold", autoPlay:true, delayTime:600, triggerTime:50});  
                </script>
                
            	<div class="deanhotnews">
                	<h3><i class="icon-lightbulb"></i>头条资讯</h3>
                    <div class="clear"></div>
                    <ul><!--[diy=deanhotnews]--><div id="deanhotnews" class="area"></div><!--[/diy]--></ul>
                </div>
                <script type="text/javascript">jq(".deanhotnews ul li:last").css("border-bottom","0");</script>
                <div class="clear"></div>
            </div>
        	<div class="clear"></div>
            <!--精选导读-->
            <div class="deanjxtj">
            	<div class="deanfltit"><i></i><h3>精选导读</h3><a href="http://t.cn/Aiux14ti" target="_blank">更多<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
                <div class="clear"></div>
            	<ul><!--[diy=deanjxtj]--><div id="deanjxtj" class="area"></div><!--[/diy]--></ul>
            </div>
            <div class="clear"></div>
            <!--模块2展示-->
            <div class="deanscrollimg">
                <a class="prev icon-angle-left" href="javascript:void(0)"></a>
                <a class="next icon-angle-right" href="javascript:void(0)"></a>
                <div class="deanfltit"><i></i><h3>滚动资讯</h3><a href="http://t.cn/Aiux14ti" target="_blank">更多<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
                <div class="clear"></div>
                <div style=" margin-top:15px;"><!--[diy=deanscrollimg]--><div id="deanscrollimg" class="area"></div><!--[/diy]--></div>
            </div>
            <script type="text/javascript">
                jq(".deanscrollimg").slide({titCell:".hd ul",mainCell:".deanscrollul",autoPage:true,effect:"leftLoop",autoPlay:true,vis:3});
            </script>
            <div class="clear"></div>
            <div class="deanadleft"><!--[diy=deanadleft]--><div id="deanadleft" class="area"></div><!--[/diy]--></div>
            <div class="clear"></div>
            
            <div class="deanpiclist">
            	<div class="deanfltit"><i></i><h3>精选导读</h3><a href="http://t.cn/Aiux14ti" target="_blank">更多<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
                <div class="clear"></div>
                <!--[diy=deanarticelist]--><div id="deanarticelist" class="area"></div><!--[/diy]-->
                <div class="holder"></div> 
            </div>
            <script type="text/javascript">  
			  jq(function(){  
				jq("div.holder").jPages({  
				  containerID : "itemContainer",  
				  previous : "←",  
				  next : "→",  
				  perPage : 13,  
				  delay : 100  
				});  
			  });  
			</script> 
        </div>
        <div class="deanpartr">
            <div class="deanguanzhuwm"><!--[diy=deanguanzhuwm]--><div id="deanguanzhuwm" class="area"></div><!--[/diy]--></div>
            
            <div class="clear"></div>
           
            <div class="clear"></div>
            <div class="deanarthdp  fadeInUp deannewshadow">
            	<div class="deanvh3"><span>事件解读</span><div class="clear"></div></div>
            	<div class="clear"></div>
            	<!--[diy=deanarthdp]--><div id="deanarthdp" class="area"></div><!--[/diy]-->
            </div>
        	<script type="text/javascript" src="$_G['style'][styleimgdir]/js/slide.js"></script>
            <div class="deanhotartice">
            	<div class="deanvh3"><span>热门文章</span><div class="clear"></div></div>
            	<div class="clear"></div>
                <ul><!--[diy=deanhotartice]--><div id="deanhotartice" class="area"></div><!--[/diy]--></ul>
            </div>
            <div class="deanmbll deannewshadow">
            	<div class="deanvh3"><span>热门评论</span><div class="clear"></div></div>
            	<div class="clear"></div>
                <div class="deanmblldiv">
                    <!--[diy=deanmblldiv]--><div id="deanmblldiv" class="area"></div><!--[/diy]-->
                </div>
            </div>
            <script type="text/javascript">jq(".deanmbll").slide({titCell:".hd ul",mainCell:".deanmblldiv ul",autoPage:true,effect:"top",autoPlay:true,vis:4});</script>
            <div class="clear"></div>
            <div class="deanad"><!--[diy=deanad]--><div id="deanad" class="area"></div><!--[/diy]--></div>
            <div class="deanad"><!--[diy=deanad1]--><div id="deanad1" class="area"></div><!--[/diy]--></div>
            <div class="clear"></div>
            <div class="deanhotpics deannewshadow">
            	<div class="deanvh3"><span>热门专题</span><div class="clear"></div></div>
            	<div class="clear"></div>
                <ul><!--[diy=deanhotpics]--><div id="deanhotpics" class="area"></div><!--[/diy]-->
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="clear"></div>
            <div class="deanranklistha deanshadow">
            	<div class="deanvh3"><span>排行榜</span><ul class="deanranknameha"><li class="cur">日</li><li>周</li><li>月</li></ul><div class="clear"></div></div>
                <div class="clear"></div>
                <div class="deanrankcha"><dl><dd style="display:block;"><ul><!--[diy=deanrankcha]--><div id="deanrankcha" class="area"></div><!--[/diy]--></ul></dd><dd><ul><!--[diy=deanrankcha1]--><div id="deanrankcha1" class="area"></div><!--[/diy]--></ul></dd><dd><ul><!--[diy=deanrankcha2]--><div id="deanrankcha2" class="area"></div><!--[/diy]--></ul></dd></dl></div>
            </div>
            <script type="text/javascript">
            	jq(".deanrankcha ul li").hover(function(s){
					jq(".deanrankcha ul li").children(".deanrankinfost").hide();
					jq(this).children(".deanrankinfost").show();
					})
				jq(".deanranknameha li").each(function(a){
					jq(this).hover(function(){
						jq(this).addClass("cur").siblings().removeClass("cur");
						jq(".deanrankcha dl dd").eq(a).show().siblings().hide();
						})
					})
            </script>
            <div class="clear"></div>
			<div class="deanad4s"><!--[diy=deanad4s]--><div id="deanad4s" class="area"></div><!--[/diy]--></div>
            <div class="clear"></div>
            
            <div class="deanzlzuozhe">
            	<div class="deanvh3"><span>作者专栏</span><div class="clear"></div></div>
            	<div class="clear"></div>
                <ul><!--[diy=deanzlzuozhe]--><div id="deanzlzuozhe" class="area"></div><!--[/diy]--></ul>
            </div>
            <script type="text/javascript">
            	jq(".deanzlzuozhe ul li:last").css({"border-bottom":"0","padding":"0","margin-bottom":"0"});
            </script>
        </div>
        <div class="clear"></div>
    </div>
	
    <div class="clear"></div>
    <div class="deanads"><!--[diy=deanads1]--><div id="deanads1" class="area"></div><!--[/diy]--></div>
    <div class="clear"></div>
    <!--图文阅读-->
    <div class="deanreads">
    	<div class="deanreadname"><!--[diy=deanreadname]--><div id="deanreadname" class="area"></div><!--[/diy]--></div>
        <div class="deanreadlist"><ul><!--[diy=deanreadlist]--><div id="deanreadlist" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
        <div class="clear"></div>
    </div>
    <div class="clear"></div>
    <div class="deanlinkst">
    	<div class="deanfltit"><i></i><h3>友情链接</h3><a href="tencent://Message/?Uin=3318850993&websiteName=#=&Menu=yes" target="_blank">联系3318850993申请友情链接<b class="icon-double-angle-right"></b></a><div class="clear"></div></div>
    	<div class="clear"></div>
        <div class="deanlinkul"><!--[diy=deanlinkul]--><div id="deanlinkul" class="area"></div><!--[/diy]--></div>
    </div>
    <div class="clear"></div>
    
</div>

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->
