﻿jq(function () {
    gain = jq("#banpic .gain, .gain-bg, .gain-login");
    gaintop = gain.css("top");
    gain.css("top", -695);
    gain.animate({
        top: gaintop + 102
    }, 500);
    gain.animate({
        top: gaintop
    }, 200);
    gain.animate({
        top: '-=12px'
    }, 200);
    gain.animate({
        top: gaintop
    }, 200);
    gain.animate({
        top: '-=3px'
    }, 100);

    gain.animate({
        top: '+=1px'
    }, 100);
    gain.animate({
        top: gaintop
    }, 100);

})

jq(function () {
    //投资直通车跳转
    jq("#js_link_zdtb").on("click",function () {
        window.open('/simple/zidongtoubiao/index.aspx')
    })

    //右侧浮动菜单
    jq("#floatrig").css("bottom", "18px");
})
jq(window).scroll(function () {
    if (jq(window).scrollTop() > 200) {
        jq("#floatrig").stop().animate({ "bottom": "50%", "marginBottom": "0" }, 300)
    }
    if (jq(window).scrollTop() <= 200) {
        jq("#floatrig").stop().animate({ "bottom": "18px", "marginBottom": "-250px" }, 300)
    }

})
/*数字动态*/
jq.fn.countTo = function (options) {
    options = options || {};
    return jq(this).each(function () {
        var settings = jq.extend({}, jq.fn.countTo.defaults, {
            from: jq(this).data("from"),
            to: jq(this).data("to"),
            speed: jq(this).data("speed"),
            refreshInterval: jq(this).data("refresh-interval"),
            decimals: jq(this).data("decimals")
        }, options);
        var loops = Math.ceil(settings.speed / settings.refreshInterval),
			increment = (settings.to - settings.from) / loops;
        var self = this,
			jqself = jq(this),
			loopCount = 0,
			value = settings.from,
			data = jqself.data("countTo") || {};
        jqself.data("countTo", data);
        if (data.interval) {
            clearInterval(data.interval)
        }
        data.interval = setInterval(updateTimer, settings.refreshInterval);
        render(value);

        function updateTimer() {
            value += increment;
            loopCount++;
            render(value);
            if (typeof (settings.onUpdate) == "function") {
                settings.onUpdate.call(self, value)
            }
            if (loopCount >= loops) {
                jqself.removeData("countTo");
                clearInterval(data.interval);
                value = settings.to;
                if (typeof (settings.onComplete) == "function") {
                    settings.onComplete.call(self, value)
                }
            }
        }
        function render(value) {
            var formattedValue = settings.formatter.call(self, value, settings);
            jqself.html(formattedValue)
        }
    })
};
jq.fn.countTo.defaults = {
    from: 0,
    to: 0,
    speed: 1000,
    refreshInterval: 100,
    decimals: 0,
    formatter: formatter,
    onUpdate: null,
    onComplete: null
};

function formatter(value, settings) {
    return value.toFixed(settings.decimals)
}
jq("#count-number,#count-number2,#count-reg").data("countToOptions", {
    formatter: function (value, options) {
        return value.toFixed(options.decimals).replace(/\B(?=(?:\d{3})+(?!\d))/g, ",")
    }
});
jq(".timer, .count-reg").each(count);
jq("#date-num1, #date-num2, #date-num3, #date-num4, #date-num5").data("countToOptions", {
    formatter: function (value, options) {
        /*  var res=value.toFixed(options.decimals).replace(/\B(?=(?:\d{8})+(?!\d))/g, "<em>亿</em>");*/
        var res = value.toFixed(options.decimals).replace(/\B(?=(?:\d{4})+(?!\d))/g, ",")
        res = res.split(',')
        if (res.length == 3) {
            res = parseInt(res[0]) + '<em>亿</em>' + parseInt(res[1]) + '<em></em>'
        } else if (res.length == 2) {
            res = res[0]
        } else {
            res = res[0]
            if (res == 0) {
                res = '--'
            }
        }
        return res
    }
});
jq("#date-num6").data("countToOptions", {
    formatter: function (value, options) {
        return value.toFixed(options.decimals).replace(/\B(?=(?:\d{8})+(?!\d))/g, "")
    }
});
jq(".count-num").each(count);
function count(options) {
    var jqthis = jq(this);
    options = jq.extend({}, options || {}, jqthis.data("countToOptions") || {});
    jqthis.countTo(options)
}
/*图片动态*/
jq(".biao-c1").hover(function () {
    jq(this).animate({ left: "10" }, 1000);
})

jq("span[id^='index_pic_']").mouseenter(function () {
    var i = jq("span[id^='index_pic_']").index(jq(this))+1;
    jq("#index_pic" + i + "_" + i).show();
    jq("#index_pic"+i).hide();
}).mouseleave(function () {
    var i = jq("span[id^='index_pic_']").index(jq(this)) + 1;
    jq("#index_pic" + i + "_" + i).hide();
    jq("#index_pic" + i).show();
});
/*视频*/
function showvideo() {
    jq("#vedio_iframe").css("display", "block");
    jq("#grayfix").css({ "width": document.documentElement.scrollWidth + "px", "height": document.documentElement.scrollHeight + "px", "display": "block" });
    jq("#iframe_video").attr("src", "/video_2years.html");
    //player.pauseVideo();
}
function closevideo(a) {
    document.getElementById("grayfix").style.display = "none";
    jq("#" + a).css("display", "none");
    jq("#iframe_video").attr("src", "");
    //player.playVideo();

}
//广告上下滚动
jq(function() {
    var index = 0;
    var adtimer;
    var _wrap = jq("#bank-ad ul"); //
    var len = jq("#bank-ad ul li").length;
    //len=1;
    if (len > 1) {
        jq("#bank-ad").hover(function() {
                clearInterval(adtimer);
            },
            function() {
                adtimer = setInterval(function() {
                        var _field = _wrap.find('li:first');
                        var _h = _field.height();
                        _field.animate({
                                marginTop: -_h + 'px'
                            },
                            500,
                            function() {
                                _field.css('marginTop', 0).appendTo(_wrap);
                            })
                    },
                    3000);
            }).trigger("mouseleave");
    }
});
jq(document).ready(function (){

    jq('.phone').mouseover(function (){
        jq('.phone').css('background', '#ffce55');
        jq('#iphone_link').css('display', 'none');
        jq('#iphone_hover').css('display', 'block');
    });
    jq('.phone').mouseout(function (){
        jq('.phone').css('background', '#fdfdfe');
        jq('#iphone_link').css('display', 'block');
        jq('#iphone_hover').css('display', 'none');
    });
    jq('.watch').mouseover(function (){
        jq('.watch').css('background', '#fb6e52');
        jq('#watch_link').css('display', 'none');
        jq('#watch_hover').css('display', 'block');
    });
    jq('.watch').mouseout(function (){
        jq('.watch').css('background', '#fdfdfe');
        jq('#watch_link').css('display', 'block');
        jq('#watch_hover').css('display', 'none');
    });
    jq('.computer').mouseover(function (){
        jq('.computer').css('background', '#5d9cec');
        jq('#computer_link').css('display', 'none');
        jq('#computer_hover').css('display', 'block');
    });
    jq('.computer').mouseout(function (){
        jq('.computer').css('background', '#fdfdfe');
        jq('#computer_link').css('display', 'block');
        jq('#computer_hover').css('display', 'none');
    });
    jq('.camera').mouseover(function (){
        jq('.camera').css('background', '#a0d468');
        jq('#camera_link').css('display', 'none');
        jq('#camera_hover').css('display', 'block');
    });
    jq('.camera').mouseout(function (){
        jq('.camera').css('background', '#fdfdfe');
        jq('#camera_link').css('display', 'block');
        jq('#camera_hover').css('display', 'none');
    });
});

// Noclip 2016-4-11 分期计划动态接口
jq.getJSON('/appapi/mall.ashx?q=toppro').then(function (d) {
    util.bind("#tpl_fenqi", ".index-fqjh", d.content.list, false);
});