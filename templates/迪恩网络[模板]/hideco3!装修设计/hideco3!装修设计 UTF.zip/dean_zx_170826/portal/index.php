<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/hd.js"></script>
<div class="deanhdp">
    <div class="focus_banner" id="wowslider-container1">
        <ul>
            <li class="deanhdpli1"> <a href="http://t.cn/Aiux14ti" target="_blank"></a></li>
            <li class="deanhdpli2"> <a href="http://t.cn/Aiux14ti" target="_blank"></a></li>
            <li class="deanhdpli3"> <a href="http://t.cn/Aiux14ti" target="_blank"></a> </li>
        </ul>
        <a href="javascript:;" id="prev1" class="ws_prev"><span></span></a> <a href="javascript:;" id="next1" class="ws_next"><span></span></a>
        <div id="page" class="ws_bullets"><div><a href="javascript:;" title="">1</a><a href="javascript:;" title="">2</a><a href="javascript:;" title="">3</a></div></div>
    </div>
</div>
<div class="clear"></div>
<div class="deanwp">
	<div class="deanzxbutton">
    	<div class="deanzxbuttonc">
    		<ul><!--[diy=deanzxbutton]--><div id="deanzxbutton" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
            </ul>
        </div>
    </div>
	<div class="clear"></div>
    <div class="deanzxpic">
    	<div class="deanzxname wow fadeInUp"><span></span>装修效果图<span></span></div>
        <div class="deanzxp">搜索海量家居美图，发现新家装修灵感</div>
        <div class="clear"></div>
        <div class="deanzxtabname wow fadeInUp"><ul><li class="cur">简约</li><li>欧式</li><li>美式</li><li>中式</li><li>北欧</li><li class="deanzxlilast">地中海</li><div class="clear"></div></ul></div>
        <div class="clear"></div>
        <div class="deanzxtabc">
        	<ul>
            	<li style="display:block;"><dl><!--[diy=deanzxtabc]--><div id="deanzxtabc" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc2]--><div id="deanzxtabc2" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc3]--><div id="deanzxtabc3" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc4]--><div id="deanzxtabc4" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc5]--><div id="deanzxtabc5" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc6]--><div id="deanzxtabc6" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
            </ul>
        </div>
        <script type="text/javascript">
        	jq(".deanzxtabname ul li").each(function(s){
				jq(this).click(function(){
					jq(this).addClass("cur").siblings().removeClass("cur");
					jq(".deanzxtabc ul li").eq(s).show().siblings().hide();
					})
				})
        </script>
    </div>
    <div class="clear"></div>
    <!--装修日志-->
    <div class="deanzxnote">
    	<!--[diy=deanzxnote]--><div id="deanzxnote" class="area"></div><!--[/diy]-->
        <div class="clear"></div>
        <script type="text/javascript">
        	jq(".deannotemb ul li").each(function(s){
				jq(this).click(function(){
					jq(this).addClass("cur").siblings().removeClass("cur");
					jq(this).removeClass("deangray").siblings().addClass("deangray");
					jq(".deannoteinfo ul li").eq(s).show().siblings().hide();
					})
				})
        </script>
    </div>
    <div class="clear"></div>
    <!--服务流程-->
    <div class="deanservice">
    	<div class="deanzxname"><span></span>服务流程<span></span></div>
        <div class="clear"></div>
        <div class="deanzxlc"><ul><!--[diy=deanzxlc]--><div id="deanzxlc" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
        <script type="text/javascript">jq(".deanzxlc ul li").addClass("deanmove");</script>
    </div>
	<div class="clear"></div>
    <!--找装修-->
    <div class="deanzxgs">
    	<div class="deanzxname wow fadeInUp"><span></span>找装修<span></span></div>
        <div class="deanzxp wow fadeInUp">甄选城中优质装修公司，丰富选择实现理想家</div>
        <div class="clear"></div>
        <ul><!--[diy=deanzxgs]--><div id="deanzxgs" class="area"></div><!--[/diy]-->
        	
            <div class="clear"></div>
        </ul>
    </div>
    <script type="text/javascript">
    	jq(".deanzxgs ul li .deanzxgsimg").eq(1).addClass("deanzxgsimg2");
		jq(".deanzxgs ul li .deanzxgsimg").eq(2).addClass("deanzxgsimg3");
		jq(".deanzxgs ul li .deanzxgsimg").eq(3).addClass("deanzxgsimg4");
		jq(".deanzxgs ul li").eq(3).css("margin-right","0");
    </script>
    <!--看攻略-->
    <div class="deangonglue">
    	<div class="deanzxname"><span></span>看攻略<span></span></div>
        <div class="deanzxp">学习装修经验与交流装修问题，小白晋级达人就靠它</div>
        <div class="clear"></div>
        <ul>
        	<li class="deanglli1 wow fadeInUp">
            	<div class="deanzxtop">
                	<i></i><div class="clear"></div><span>装修攻略</span>
                </div>
                <div class="clear"></div>
                <dl class="deandllist">
                	<!--[diy=deandllist]--><div id="deandllist" class="area"></div><!--[/diy]-->
                </dl>
                <div class="clear"></div>
                <a href="http://t.cn/Aiux14ti" target="_blank" class="deanarrowmore"></a>
            </li>
            <li class="deanglli2 wow fadeInDown">
            	<div class="deanzxtop">
                	<i></i><div class="clear"></div><span>装修日记</span>
                </div>
                <div class="clear"></div>
                <dl class="deandllist">
                	<!--[diy=deandllist2]--><div id="deandllist2" class="area"></div><!--[/diy]-->	
                </dl>
                <div class="clear"></div>
                <a href="http://t.cn/Aiux14ti" target="_blank" class="deanarrowmore"></a>
            </li>
            <li class="deanglli3 wow fadeInUp">
            	<div class="deanzxtop">
                	<i></i><div class="clear"></div><span>装修问答</span>
                </div>
                <div class="clear"></div>
                <dl class="deandllist">
                	<!--[diy=deandllist3]--><div id="deandllist3" class="area"></div><!--[/diy]-->	
                </dl>
                <div class="clear"></div>
                <a href="http://t.cn/Aiux14ti" target="_blank" class="deanarrowmore"></a>
            </li>
            <li class="deanglli4 wow fadeInDown">
            	<div class="deanzxtop">
                	<i></i><div class="clear"></div><span>装修工具</span>
                </div>
                <div class="clear"></div>
                <dl class="deandllistbtn">
                	<!--[diy=deandllist4]--><div id="deandllist4" class="area"></div><!--[/diy]-->
                    <div class="clear"></div>
                </dl>
                <script type="text/javascript">
                	jq(".deandllistbtn dd").addClass("deanmove");
                </script>
            </li>
            <div class="clear"></div>
        </ul>
        <script type="text/javascript">
			jq(".deangonglue ul li").addClass("deanmove");
		</script>
    </div>
    <div class="clear"></div>
    <!--装修商城-->
    <div class="deanshopindex">
    	<div class="deanzxname wow fadeInUp"><span></span>装修商城<span></span></div>
        <div class="deanzxp wow fadeInUp">任挑任选大牌商品，全场享受工厂价折扣</div>
        <div class="clear"></div>
    	<div class="deangoodlist"><ul><!--[diy=deangoodlist]--><div id="deangoodlist" class="area"></div><!--[/diy]--><div class="clear"></div></ul></div>
        <div class="clear"></div>
        <div class="deanaddl"><dl><!--[diy=deanaddl]--><div id="deanaddl" class="area"></div><!--[/diy]--><div class="clear"></div></dl></div>
    </div>
    <div class="clear"></div>
    <!--网站新闻-->
    <div class="deannewsindex">
    	<div class="deanzxname wow fadeInUp"><span></span>企业新闻<span></span></div>
        <div class="deanzxp wow fadeInUp">一线媒体强势报道，全面了解公司动态</div>
        <div class="clear"></div>
        <div class="deannewindexc">
        	<ul><!--[diy=deannewindexc]--><div id="deannewindexc" class="area"></div><!--[/diy]--><div class="clear"></div></ul>
        </div>
    </div>
    <div class="clear"></div>
    <!--友情链接-->
    <div class="deanlinkindex">
    	<div class="deanzxname wow fadeInUp"><span></span>友情链接<span></span></div>
        <div class="deanzxp wow fadeInUp">联系QQ 3318850993 pr>5</div>
        <div class="clear"></div>
        <ul><!--[diy=deanlinkindex]--><div id="deanlinkindex" class="area"></div><!--[/diy]-->
        	<div class="clear"></div>
        </ul>
    </div>
</div>
<div class="clear"></div>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->
