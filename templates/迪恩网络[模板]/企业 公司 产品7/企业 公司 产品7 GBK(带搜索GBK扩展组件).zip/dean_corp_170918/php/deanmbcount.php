<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$dncounts = DB::fetch_all("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]' ");
$dnmbinfo = DB::fetch_all("SELECT * FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]' ");
?>