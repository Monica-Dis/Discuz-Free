<?php echo '��֧�ֵ϶���������';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/hd.js"></script>
<div class="deanhdp">
    <div class="focus_banner" id="wowslider-container1">
        <ul>
            <li class="deanhdpli1"><a href="http://www.baidu.com" target="_blank"></a></li>
            <li class="deanhdpli2"><a href="#" target="_blank"></a></li>
            <li class="deanhdpli3"><a href="#" target="_blank"></a></li>
            <li class="deanhdpli4"><a href="#" target="_blank"></a></li>
            <li class="deanhdpli5"><a href="#" target="_blank"></a></li>
        </ul>
        <a href="javascript:;" id="prev1" class="ws_prev"><span></span></a>
        <a href="javascript:;" id="next1" class="ws_next"><span></span></a>
        <div id="page" class="ws_bullets"><div><a href="javascript:;">1</a><a href="javascript:;">2</a><a href="javascript:;">3</a><a href="javascript:;">4</a><a href="javascript:;">5</a></div></div>
    </div>
</div>
<div class="clear"></div>
<div class="deanwp">
	
	<div class="deanzxpic">
    	<div class="deanzxname wow fadeInUp"><span></span>���ǵ�Ʒ<span></span></div>
        <div class="deanzxp">STAR &nbsp;&nbsp;PRODUCTS</div>
        <div class="clear"></div>
        <div class="deanzxtabname wow fadeInUp"><ul><li class="cur">�յ�</li><li>����</li><li>ϴ�»�</li><li>��������</li><li>����ҵ�</li><li class="deanzxlilast">����</li><div class="clear"></div></ul></div>
        <div class="clear"></div>
        <div class="deanzxtabc">
        	<ul>
            	<li style="display:block;"><dl><!--[diy=deanzxtabc]--><div id="deanzxtabc" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc2]--><div id="deanzxtabc2" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc3]--><div id="deanzxtabc3" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc4]--><div id="deanzxtabc4" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc5]--><div id="deanzxtabc5" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
                <li><dl><!--[diy=deanzxtabc6]--><div id="deanzxtabc6" class="area"></div><!--[/diy]--><div class="clear"></div></dl></li>
            </ul>
        </div>
        <script type="text/javascript">
        	jq(".deanzxtabname ul li").each(function(s){
				jq(this).hover(function(){
					jq(this).addClass("cur").siblings().removeClass("cur");
					jq(".deanzxtabc ul li").eq(s).show().siblings().hide();
					})
				})
        </script>
    </div>
    <div class="clear"></div>
    <!--���ǵ�����1-->
	<div class="deanboxone">
    	<div class="deanboxonel wow fadeInRight">
        	<div class="deanboxonelt"><!--[diy=deanboxonelt]--><div id="deanboxonelt" class="area"></div><!--[/diy]--><div class="clear"></div></div>
            <div class="clear"></div>
            <div class="deanboxonelb"><!--[diy=deanboxonelb]--><div id="deanboxonelb" class="area"></div><!--[/diy]--></div>
        </div>
        <div class="deanboxoner wow fadeInLeft">
        	<div class="deanourys">
            	<h3>���ǵ�����</h3>
                <div class="clear"></div>
                <ul><!--[diy=deanourys]--><div id="deanourys" class="area"></div><!--[/diy]--></ul>
            </div>
        </div>
        <div class="clear"></div>
    </div>
    
    <div class="clear"></div>
	<div class="deanmbfl">
    	<div class="deanzxname wow fadeInUp"><span></span>��Աר��<span></span></div>
        <div class="clear"></div>
        <div class="deanzxp wow fadeInUp">�����Ա����</div>
        <ul>
        	<!--[diy=deanmbfl]--><div id="deanmbfl" class="area"></div><!--[/diy]-->
            <div class="clear"></div>
        </ul>
    </div>
    <div class="clear"></div>
    <div class="deannewlist wow fadeInUp">
        <div class="deannewhd">
            <div class="deanh2"><span>��˾�</span><a href="#" target="_blank" class="deanmore">����</a><div class="clear"></div></div>
            <div class="clear"></div>
            <div class="deanboxsame deanlarge"><!--[diy=deanboxsame1]--><div id="deanboxsame1" class="area"></div><!--[/diy]--></div>
            <ul class="deanboxul"><!--[diy=deanboxul1]--><div id="deanboxul1" class="area"></div><!--[/diy]--></ul>
        </div>
        <div class="deannews">
            <div class="deanh2"><span>���Ŷ�̬</span><a href="#" target="_blank" class="deanmore">����</a><div class="clear"></div></div>
            <div class="clear"></div>
            <div class="deanboxsame deanlarge"><!--[diy=deanboxsame2]--><div id="deanboxsame2" class="area"></div><!--[/diy]--></div>
            <ul class="deanboxsameul"><!--[diy=deanboxsameul2]--><div id="deanboxsameul2" class="area"></div><!--[/diy]--></ul>
        </div>
        <div class="deannewforum">
            <div class="deanh2"><span>��������</span><a href="#" target="_blank" class="deanmore">����</a><div class="clear"></div></div>
            <div class="clear"></div>
            <div class="deanboxsame deanlarge"><!--[diy=deanboxsame3]--><div id="deanboxsame3" class="area"></div><!--[/diy]--></div>
            <ul class="deanboxul"><!--[diy=deanboxul3]--><div id="deanboxul3" class="area"></div><!--[/diy]--></ul>
        </div>
        <div class="clear"></div>
    </div>
    <div class="clear"></div>
    <div class="deanparter">
    	<div class="deanparterc">
            <div class="deanzxname"><span></span>�������<span></span></div>
            <div class="clear"></div>
            <div class="deanzxp">�������ǣ�����ѡ��ɹ���һ�룬���ʵ�Ʒ�ʣ����ĵķ���!</div>
            <div class="clear"></div>
            <ul><!--[diy=deanparter]--><div id="deanparter" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
            </ul>
        </div>
    </div>
    <div class="clear"></div>
    <!--��������-->
    <div class="deanlinkindex">
    	<div class="deanzxname wow fadeInUp"><span></span>��������<span></span></div>
        <div class="deanzxp wow fadeInUp">��ϵQQ 3318850993 pr>5</div>
        <div class="clear"></div>
        <ul><!--[diy=deanlinkindex]--><div id="deanlinkindex" class="area"></div><!--[/diy]-->
        	<div class="clear"></div>
        </ul>
    </div>
</div>
<div class="clear"></div>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->
