jq(function(){
    var bannerWidth = document.body.clientWidth>1260?1180:980;
    var bannerLength = jq('#banner li').length;
    var bennerCurrent = 1;
    var timer = null;
    jq('#banner ul').css('left',-bannerWidth).append(jq('#banner li').clone()).prepend(jq('#banner li:last-child').clone());

    function rebind(){
        jq('#banner .mask_l').click(bannerRight);
        jq('#banner .mask_r').click(bannerLeft);
    }
    function unbind(){
        jq('#banner .mask_l').unbind();
        jq('#banner .mask_r').unbind();
    }
    function bannerLeft(){
        if(bennerCurrent>=bannerLength+1) {
            bennerCurrent = 1;
            jq('#banner ul').css('left', -bennerCurrent * bannerWidth);
        }
        bennerCurrent++;
        bannerMove(-bennerCurrent*bannerWidth);
    }
    function bannerRight(){
        if(bennerCurrent<=1) {
            bennerCurrent = bannerLength + 1;
            jq('#banner ul').css('left', -bennerCurrent * bannerWidth);
        }
        bennerCurrent--;
        bannerMove(-bennerCurrent*bannerWidth);
    }
    function bannerMove(targetX,finnalX){
        clearTimeout(timer);
        unbind();
        jq('#banner ul').animate({left:targetX},function(){
            if(finnalX!=0) jq(this).css('left',finnalX);
            rebind();
            timer = setTimeout(bannerLeft,5000);
        })
    }
    rebind();
    timer = setTimeout(bannerLeft,5000);
    function resize(clientWidth){
        clearTimeout(timer);
        if(clientWidth>1260 && bannerWidth==980){
            jq('#banner ul').stop(true,true);
            bannerWidth=1180;
            jq('#banner ul').css('left', -bannerWidth);
            bennerCurrent=1;
        }else if(clientWidth<=1260 && bannerWidth==1180){
            jq('#banner ul').stop(true,true);
            bannerWidth=980;
            jq('#banner ul').css('left', -bannerWidth);
            bennerCurrent=1;
        }
        timer = setTimeout(bannerLeft,5000);
    }
});
