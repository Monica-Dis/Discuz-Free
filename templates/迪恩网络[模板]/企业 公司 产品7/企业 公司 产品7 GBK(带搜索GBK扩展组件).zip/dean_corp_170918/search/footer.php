<?php echo '��֧�ֵ϶���������';exit;?>
<!--{eval $focusid = getfocus_rand($_G[basescript]);}-->
<!--{if $focusid !== null}-->
	<!--{eval $focus = $_G['cache']['focus']['data'][$focusid];}-->
	<div class="focus" id="focus">
		<div class="bm">
			<div class="bm_h cl">
				<a href="javascript:;" onclick="setcookie('nofocus_$focusid', 1, $_G['cache']['focus']['cookie']*3600);$('focus').style.display='none'" class="y" title="{lang close}">{lang close}</a>
				<h2><!--{if $_G['cache']['focus']['title']}-->{$_G['cache']['focus']['title']}<!--{else}-->{lang focus_hottopics}<!--{/if}--></h2>
			</div>
			<div class="bm_c">
				<dl class="xld cl bbda">
					<dt><a href="{$focus['url']}" class="xi2" target="_blank">$focus['subject']</a></dt>
					<!--{if $focus[image]}-->
					<dd class="m"><a href="{$focus['url']}" target="_blank"><img src="{$focus['image']}" alt="$focus['subject']" /></a></dd>
					<!--{/if}-->
					<dd>$focus['summary']</dd>
				</dl>
				<p class="ptn hm"><a href="{$focus['url']}" class="xi2" target="_blank">{lang focus_show} &raquo;</a></p>
			</div>
		</div>
	</div>
<!--{/if}-->

<!--{ad/footerbanner/wp a_f hm/1}--><!--{ad/footerbanner/wp a_f hm/2}--><!--{ad/footerbanner/wp a_f hm/3}-->
<!--{ad/float/a_fl/1}--><!--{ad/float/a_fr/2}-->
<!--{ad/couplebanner/a_fl a_cb/1}--><!--{ad/couplebanner/a_fr a_cb/2}-->

<!--{hook/global_footer}-->
<div class="deanfooter">
        <div class="deanfttop">
            <div class="deanw1180">
                <div class="deanlinks">
                    <ul>
                        <li>
                            <p>��������</p>
                            <a href="#" target="_blank" >��˾����</a>
                            <a href="#" target="_blank" >��ҵ��̬</a>
                            <a href="#" target="_blank" >��ϵ����</a>
                            <a href="#" target="_blank" >���ʽ</a>
                            <a href="#" target="_blank" >�û�Э��</a>
                        </li>
                        <li>
                            <p>��������</p>
                            <a href="#" target="_blank" >������è</a>
                            <a href="#" target="_blank" >��������</a>
                            <a href="#" target="_blank" >����ƽ̨</a>
                            <a href="#" target="_blank" >��ƸӢ��</a>
                            <a href="#" target="_blank" >��ϵ����</a>
                        </li>
                        <li>
                            <p>��վ����</p>
                            <a href="#" target="_blank" >��ҵ��Ѷ</a>
                            <a href="#" target="_blank" >װ�޷�ˮ</a>
                            <a href="#" target="_blank" >װ��֪ʶ</a>
                        </li>
                    </ul>
                </div>
                <div class="deanspread">
                    <p>��ע����:�϶�����</p>
                    <div class="deanweixin">
                        <img src="$_G['style'][styleimgdir]/house/apptoubu.png">
                        <p>�ٷ�΢��</p>
                    </div>
                    <div class="deanappft">
                        <img src="$_G['style'][styleimgdir]/house/apptoubu.png">
                        <p>APP����</p>
                    </div>
                </div>
                <div class="deancontact">
                    <div class="deanfttel clear" style="margin-bottom:5px;">
                        <span></span>
                        <div class="deanfttext">
                            <p>ȫ���������ߣ�</p>
                            <b>4000-018-018</b>
                        </div>
                    </div>
                    <p class="c-aaa">��˾��ַ���Ϻ��мζ�������·655��B��1068��</p>
                    <p class="c-aaa">��Ӫ���ģ��ɶ��н�������������42��</p>
                    <p class="c-aaa">�ʱࣺ610066  Email��mail@yidai.com</p>
                    <p class="dean666">Copyright &nbsp;&nbsp;&copy;2015-2016&nbsp;&nbsp;<a href="$_G['setting']['siteurl']" target="_blank">$_G['setting']['sitename']</a>&nbsp;&nbsp;Powered by&copy;<a href="http://t.cn/Aiux1Qh0" target="_blank">Discuz!</a>&nbsp;&nbsp;����֧�֣�<a href="#" target="_blank">�϶�����</a>&nbsp;&nbsp;<!--{if $_G['setting']['statcode']}-->$_G['setting']['statcode']<!--{/if}-->&nbsp;&nbsp;<!--{if $_G['setting']['icp']}-->( <a href="http://www.miitbeian.gov.cn/" target="_blank">$_G['setting']['icp']</a> )<!--{/if}--><!--{hook/global_footerlink}--></p>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <div class="clear"></div>
        <div class="deanofficial">
            <div class="deanftanquan"><a href="#" target="_blank"><img src="$_G['style'][styleimgdir]/footer/1.png" /></a><a href="#" target="_blank"><img src="$_G['style'][styleimgdir]/footer/2.png" /></a><a href="#" target="_blank"><img src="$_G['style'][styleimgdir]/footer/3.jpg" /></a><a href="#" target="_blank"><img src="$_G['style'][styleimgdir]/footer/5.jpg" /></a><a href="#" target="_blank"><img src="$_G['style'][styleimgdir]/footer/6.jpg" /></a><div class="clear"></div></div>
        </div>
    </div>
<div id="ft" class="w cl" style="display:none;">
	<em>Powered by <strong><a href="http://t.cn/Aiux1Qh0" target="_blank">Discuz!</a></strong> <em>$_G['setting']['version']</em><!--{if !empty($_G['setting']['boardlicensed'])}--> <a href="http://license.comsenz.com/?pid=1&host=$_SERVER[HTTP_HOST]" target="_blank">Licensed</a><!--{/if}--></em> &nbsp;
	<em>&copy; 2001-2017 <a href="http://t.cn/Aiux1012" target="_blank">DisM.Taobao.Com.</a></em>
	<span class="pipe">|</span>
	<!--{loop $_G['setting']['footernavs'] $nav}--><!--{if $nav['available'] && ($nav['type'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1)) ||
			!$nav['type'] && ($nav['id'] == 'stat' && $_G['group']['allowstatdata'] || $nav['id'] == 'report' && $_G['uid'] || $nav['id'] == 'archiver'))}-->$nav[code]<span class="pipe">|</span><!--{/if}--><!--{/loop}-->
	<strong><a href="$_G['setting']['siteurl']" target="_blank">$_G['setting']['sitename']</a></strong>
	<!--{if $_G['setting']['icp']}-->( <a href="http://www.miibeian.gov.cn/" target="_blank">$_G['setting']['icp']</a> )<!--{/if}-->
	<!--{hook/global_footerlink}-->
	<!--{if $_G['setting']['statcode']}--><span class="pipe">| $_G['setting']['statcode']</span><!--{/if}-->
	<!--{eval updatesession();}-->
</div>
<!--{if $_G[uid] && !isset($_G['cookie']['checkpm'])}-->
<script language="javascript"  type="text/javascript" src="home.php?mod=spacecp&ac=pm&op=checknewpm&rand=$_G[timestamp]"></script>
<!--{/if}-->
<!--{eval output();}-->
</body>
</html>