<?php echo 'From: DisM.taobao.com';exit;?>

<!--{template common/header}-->
<!--{eval $ucthread = C::t('forum_thread')->fetch_all_by_authorid($_G['forum_thread']['authorid'], 0,8);}-->
<!--{eval $ucauthor = DB::fetch_first("SELECT `follower`,`threads`,`following` FROM ".DB::table('common_member_count')." WHERE uid = ".$_G['forum_thread']['authorid']);}-->
<!--{eval $ucmedals = DB::fetch_all("SELECT * FROM ".DB::table('common_member_medal')." WHERE uid = ".$_G['forum_thread']['authorid']);}-->

<script type="text/javascript">var fid = parseInt('$_G[fid]'), tid = parseInt('$_G[tid]');</script>
<!--{if $modmenu['thread'] || $modmenu['post']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->

<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';var aimgcount = new Array();</script>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.hoverdir.js"></script>
<script type="text/javascript">
	jq(function() {
		jq('#da-thumbs > li').hoverdir( {
			hoverDelay	: 75
		} );
	
	});
</script>
<style id="diy_style" type="text/css"></style>
<style type="text/css">
#wp,.wp{ width:1180px!important;}
.mn{ padding:0!important; margin:0!important;  margin-top:0!important; box-shadow:none!important;  background:#fff!important;}
</style>
<style type="text/css">
#modmenu a{ }
	#modmenu span.pipe{ padding:0 5px; color:#bbb;}
	.pob a{ padding:0!important; padding-right:15px!important; color:#666!important;}
	.po p a{ margin-right:0!important;}
</style>
	
<!--{if $modmenu['thread']}-->
	<div id="modmenu" class="xi2 pbm">
		<!--{eval $modopt=0;}-->
		<!--{if $_G['forum']['ismoderator']}-->
			<!--{if $_G['group']['allowdelpost']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(3, 'delete')">{lang modmenu_deletethread}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowbumpthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(3, 'bump')">{lang modmenu_updown}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(1, 'stick')">{lang modmenu_stickthread}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowlivethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('live')">{lang modmenu_live}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowhighlightthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(1, 'highlight')">{lang modmenu_highlight}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(1, 'digest')">{lang modmenu_digestpost}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(1, 'recommend')">{lang modmenu_recommend}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowstampthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('stamp')">{lang modmenu_stamp}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowstamplist'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('stamplist')">{lang modmenu_icon}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowclosethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(4)"><!--{if !$_G['forum_thread']['closed']}-->{lang modmenu_switch_off}<!--{else}-->{lang modmenu_switch_on}<!--{/if}--></a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(2, 'move')">{lang modmenu_move}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowedittypethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(2, 'type')">{lang modmenu_type}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if !$_G['forum_thread']['special'] && !$_G['forum_thread']['is_archived']}-->
				<!--{if $_G['group']['allowcopythread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('copy')">{lang modmenu_copy}</a><span class="pipe">|</span><!--{/if}-->
				<!--{if $_G['group']['allowmergethread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('merge')">{lang modmenu_merge}</a><span class="pipe">|</span><!--{/if}-->
				<!--{if $_G['group']['allowrefund'] && $_G['forum_thread']['price'] > 0}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('refund')">{lang modmenu_restore}</a><span class="pipe">|</span><!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowsplitthread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('split')">{lang modmenu_split}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowrepairthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('repair')">{lang modmenu_repair}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['forum_thread']['is_archived'] && $_G['adminid'] == 1}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('restore', '', 'archiveid={$_G[forum_thread][archiveid]}')">{lang modmenu_archive}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['forum_firstpid']}-->
				<!--{if $_G['group']['allowwarnpost']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('warn', '$_G[forum_firstpid]')">{lang modmenu_warn}</a><span class="pipe">|</span><!--{/if}-->
				<!--{if $_G['group']['allowbanpost']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('banpost', '$_G[forum_firstpid]')">{lang modmenu_banthread}</a><span class="pipe">|</span><!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowremovereward'] && $_G['forum_thread']['special'] == 3 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('removereward')">{lang modmenu_removereward}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['forum']['status'] == 3 && in_array($_G['adminid'], array('1','2')) && $_G['forum_thread']['closed'] < 1}--><a href="javascript:;" onclick="modthreads(5, 'recommend_group');return false;">{lang modmenu_grouprecommend}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['allowmanagetag']}--><a href="javascript:;" onclick="showWindow('mods', 'forum.php?mod=tag&op=manage&tid=$_G[tid]', 'get', 0)">{lang post_tag}</a><span class="pipe">|</span><!--{/if}-->
			<!--{if $_G['group']['alloweditusertag']}--><a href="javascript:;" onclick="showWindow('usertag', 'forum.php?mod=misc&action=usertag&tid=$_G[tid]', 'get', 0)">{lang usertag}</a><span class="pipe">|</span><!--{/if}-->
		<!--{/if}-->
		<!--{if $allowpusharticle && $allowpostarticle}--><!--{eval $modopt++}--><a href="portal.php?mod=portalcp&ac=article&from_idtype=tid&from_id=$_G['tid']">{lang modmenu_pusharticle}</a><span class="pipe">|</span><!--{/if}-->
		<!--{hook/viewthread_modoption}-->
	</div>
<!--{/if}-->
<!--{hook/viewthread_top}-->
<!--{ad/text/wp a_t}-->

<style id="diy_style" type="text/css"></style>

<!--[diy=diynavtop]--><div id="diynavtop" class="area"></div><!--[/diy]-->
<div id="pt" class="bm cl">
	<div class="z">
		<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a>$navigation <em>&rsaquo;</em> <a href="forum.php?mod=viewthread&tid=$_G[tid]">$_G[forum_thread][short_subject]</a>
	</div>
</div>

<div id="ct" class="wp cl {if $close_leftinfo} ct2{/if}">
	<div class="deanquickbtn">
    	<a class="deannewpost"onclick="showWindow('reply', 'forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]')" href="javascript:;" title="{lang reply}" ></a>
        <a id="post_reply" onclick="showWindow('newthread', 'forum.php?mod=post&amp;action=newthread&amp;fid=$_G[fid]')" href="javascript:;" title="{lang send_posts}"></a>
    </div>
    <div class="mn" <!--{if !$close_leftinfo}-->style="width:100%"<!--{/if}--> > 

        <div id="pgt" class="pgs mbm cl {if $modmenu['thread']}pbm bbs{/if}" style=" display:none;">
            <div class="pgt">$multipage</div>
            <span class="y pgb"{if $_G['setting']['visitedforums']} id="visitedforums" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id,'pos':'34'})"{/if}><a href="$upnavlink">{lang return_forumdisplay}</a></span>
            <!--{if $_G['forum']['threadsorts'] && $_G['forum']['threadsorts']['templatelist']}-->
                <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
                    <button id="newspecial" class="pn pnc" onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id'"><strong>{lang i_want}$name</strong></button>
                <!--{/loop}-->
            <!--{else}-->
                <!--{if !$_G['forum_thread']['is_archived']}--><a id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} href="javascript:;" title="{lang send_posts}"><img src="{IMGDIR}/pn_post.png" alt="{lang send_posts}" /></a><!--{/if}-->
            <!--{/if}-->
            <!--{if $allowpostreply && !$_G['forum_thread']['archiveid']}-->
                <a id="post_reply" onclick="showWindow('reply', 'forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]')" href="javascript:;" title="{lang reply}"><img src="{IMGDIR}/pn_reply.png" alt="{lang reply}" /></a>
            <!--{/if}-->
            <!--{hook/viewthread_postbutton_top}-->
        </div>
    
    <!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
        <ul class="p_pop" id="newspecial_menu" style="display: none">
            <!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang post_newthread}</a></li><!--{/if}-->
            <!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
                <!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
                    <!--{if $_G['forum']['threadsorts']['show'][$id]}-->
                        <li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&sortid=$id">$threadsorts</a></li>
                    <!--{/if}-->
                <!--{/loop}-->
            <!--{/if}-->
            <!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
            <!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
            <!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
            <!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
            <!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
            <!--{if $_G['setting']['threadplugins']}-->
                <!--{loop $_G['forum']['threadplugin'] $tpid}-->
                    <!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
                        <li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url(source/plugin/$tpid/$_G['setting']['threadplugins'][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G['setting']['threadplugins'][$tpid][name]}</a></li>
                    <!--{/if}-->
                <!--{/loop}-->
            <!--{/if}-->
        </ul>
    <!--{/if}-->
    
    <!--{if $modmenu['post']}-->
        <div id="mdly" class="fwinmask" style="display:none;z-index:350;">
            <table cellspacing="0" cellpadding="0" class="fwin">
                <tr>
                    <td class="t_l"></td>
                    <td class="t_c"></td>
                    <td class="t_r"></td>
                </tr>
                <tr>
                    <td class="m_l">&nbsp;&nbsp;</td>
                    <td class="m_c">
                        <div class="f_c">
                            <div class="c">
                                <h3>{lang admin_select}&nbsp;<strong id="mdct" class="xi1"></strong>&nbsp;{lang piece}: </h3>
                                <!--{if $_G['forum']['ismoderator']}-->
                                    <!--{if $_G['group']['allowwarnpost']}--><a href="javascript:;" onclick="modaction('warn')">{lang modmenu_warn}</a><span class="pipe">|</span><!--{/if}-->
                                    <!--{if $_G['group']['allowbanpost']}--><a href="javascript:;" onclick="modaction('banpost')">{lang modmenu_banpost}</a><span class="pipe">|</span><!--{/if}-->
                                    <!--{if $_G['group']['allowdelpost'] && !$rushreply}--><a href="javascript:;" onclick="modaction('delpost')">{lang modmenu_deletepost}</a><span class="pipe">|</span><!--{/if}-->
                                <!--{/if}-->
                                <!--{if $_G['forum']['ismoderator'] && $_G['group']['allowstickreply'] || $_G['forum_thread']['authorid'] == $_G['uid']}--><a href="javascript:;" onclick="modaction('stickreply')">{lang modmenu_stickpost}</a><span class="pipe">|</span><!--{/if}-->
                                <!--{if $_G['forum_thread']['pushedaid'] && $allowpostarticle}--><a href="javascript:;" onclick="modaction('pushplus', '', 'aid=$_G[forum_thread][pushedaid]', 'portal.php?mod=portalcp&ac=article&op=pushplus')">{lang modmenu_pushplus}</a><span class="pipe">|</span><!--{/if}-->
                            </div>
                        </div>
                    </td>
                    <td class="m_r"></td>
                </tr>
                <tr>
                    <td class="b_l"></td>
                    <td class="b_c"></td>
                    <td class="b_r"></td>
                </tr>
            </table>
        </div>
    <!--{/if}-->

    
    <!--{hook/viewthread_beginline}-->
    
    
    
    <div id="postlist" class="pl bm {if $post['first']} deanfirsthaha {else}deannofirsthaha{/if} {if !$close_leftinfo}deanfirstlz{else}deannolz{/if}">
  		<!--抢楼回帖奖励-->
  		<!--{if $_G['forum_thread']['replycredit'] > 0 || $rushreply}-->
            <div id="pl_top" class="box mb20">
                <table cellspacing="0" cellpadding="0">
                    <tr class="ad">
                        <td class="pls"></td>
                        <td class="plc"></td>
                    </tr>
                    <!--{if $_G['forum_thread']['replycredit'] > 0 }-->
                        <tr>
                            <!--{if !$close_leftinfo}-->
                            <td class="pls vm ptm">
                            <!--{else}-->
                            <td class="pls ptm pbm xi1" colspan="2">
                            <!--{/if}-->
                                <img src="{IMGDIR}/thread_prize_s.png" class="hm" alt="{lang replycredit}" />
                                    <strong>{$_G['forum_thread']['replycredit']} {$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][unit]}{$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][title]}</strong>
                            <!--{if !$close_leftinfo}-->
                            </td>
                            <td class="plc ptm pbm xi1">
                            <!--{else}-->
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <!--{/if}-->
                                {lang thread_replycredit_tips1} {lang thread_replycredit_tips2}<!--{if $_G['forum_thread']['replycredit_rule'][random] > 0}--><span class="xg1">{lang thread_replycredit_tips3}</span><!--{/if}-->
                            </td>
                        </tr>
                        <!--{if $rushreply}-->
                        <tr class="ad">
                            <td class="pls"></td>
                            <td class="plc"></td>
                        </tr>
                        <!--{/if}-->
                <!--{/if}-->
        
                <!--{if $rushreply}-->
                    <tr>
                        <!--{if !$close_leftinfo}-->
                        <td class="pls vm ptm">
                            <img src="{IMGDIR}/rushreply_s.png" class="vm" alt="{lang rushreply}" />
                            <strong>{lang rushreply}</strong>
                        </td>
                        <td class="plc ptm pbm xi1">
                        <!--{else}-->
                        <td class="plc ptm pbm xi1" colspan="2">
                            <img src="{IMGDIR}/rushreply_s.png" class="vm" alt="{lang rushreply}" />
                        <!--{/if}-->
                            <!--{if $rushresult[rewardfloor]}-->
                                <span class="y">
                                <!--{if $_G['uid'] == $_G['thread']['authorid'] || $_G['forum']['ismoderator']}--><a href="javascript:;" onclick="showWindow('membernum', 'forum.php?mod=ajax&action=get_rushreply_membernum&tid=$_G[tid]')" class="y pn xi2"><span>{lang thread_rushreply_statnum}</span></a><!--{/if}-->
                                <!--{if !$_GET['checkrush']}-->
                                        <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" class="y pn xi2"><span>{lang rushreply_view}</span></a>
                                <!--{/if}-->
                                </span>
                            <!--{/if}-->
                            <!--{if $rushresult[creditlimit] == ''}-->
                                {lang thread_rushreply}&nbsp;
                            <!--{else}-->
                                {lang thread_rushreply_limit} &nbsp;
                            <!--{/if}-->
                            <!--{if $rushresult['timer']}-->
                            <span id="rushtimer_$thread[tid]"> {lang havemore_special} <span id="rushtimer_body_$thread[tid]"></span> <script language="javascript">settimer($rushresult['timer'], 'rushtimer_body_$thread[tid]');</script>{if $rushresult['timertype'] == 'start'} {lang header_start} {else} {lang over} {/if} {lang right_special}</span>
                            <!--{/if}-->
                            <!--{if $rushresult[stopfloor]}-->
                                {lang thread_rushreply_end}$rushresult[stopfloor]&nbsp;
                            <!--{/if}-->
                            <!--{if $rushresult[rewardfloor]}-->
                                {lang thread_rushreply_floor}: $rushresult[rewardfloor]&nbsp;
                            <!--{/if}-->
                            <!--{if $rushresult[rewardfloor] && $_GET['checkrush']}-->
                                <p class="ptn">
                                    <!--{if $countrushpost}-->[<strong>$countrushpost</strong>]{lang thread_rushreply_rewardnum}<!--{else}--> {lang thread_rushreply_noreward} <!--{/if}-->&nbsp;&nbsp;
                                    <a href="forum.php?mod=viewthread&tid=$_G[tid]" class="xi2">{lang thread_rushreply_check_back}</a>
                                </p>
                            <!--{/if}-->
                        </td>
                    </tr>
                <!--{/if}-->
                </table>
            </div>
            <!--{/if}-->
  		
        <div class="deanviewtit cl">
            <!--{if $_G['setting']['close_leftinfo_userctrl']}-->
             
                <!--{if !$close_leftinfo}-->
                    <a onclick="setcookie('close_leftinfo', 1);location.reload();" title="{lang collapse_the_left}" class="btn_s_close" href="javascript:;"><img src="$_G['style'][styleimgdir]/viewthread/control_l.png" alt="{lang collapse_the_left}" class="vm" /></a>
                <!--{else}-->
                    <a onclick="setcookie('close_leftinfo', 2);location.reload();" title="{lang open_the_left}" class="btn_s_open" href="javascript:;"><img src="$_G['style'][styleimgdir]/viewthread/control_r.png" alt="{lang open_the_left}" class="vm" /></a>
                <!--{/if}-->
                
            <!--{/if}-->
            <!--{if !$close_leftinfo}-->
			<div class="deanviewuser cl z">
				<!--{if $_G['page'] > 1}-->
					<!--{if $_G[forum_thread][authorid] && $_G[forum_thread][author]}-->
						<a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" title="$_G[forum_thread][author]"><!--{avatar($_G[forum_thread][authorid],small)}--></a>
						{lang thread_author}: <a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" title="$_G[forum_thread][author]">$_G[forum_thread][author]</a>
					<!--{else}-->
						{lang thread_author}:
						<!--{if $_G['forum']['ismoderator']}-->
							<a href="home.php?mod=space&uid=$_G[forum_thread][authorid]">{lang anonymous}</a>
						<!--{else}-->
							{lang anonymous}
						<!--{/if}-->
					<!--{/if}-->
				<!--{/if}-->
			</div>
			<!--{/if}-->
            <h1 class="deanviewts z">
                <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
                    <!--{if !IS_ROBOT && ($_G['forum']['threadtypes']['listable'] || $_G['forum']['status'] == 3)}-->
                        <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$_G[forum_thread][typeid]">[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]</a>
                    <!--{else}-->
                        [{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
                    <!--{/if}-->
                <!--{/if}-->
                <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
                    <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_G[forum_thread][sortid]">[{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]</a>
                <!--{/if}-->
                <span id="thread_subject">$_G[forum_thread][subject]</span>
            </h1>
            <!--{if !$close_leftinfo}-->
            <span class="deanviewreplies y">
            	<strong>$_G[forum_thread][allreplies]</strong></br>{lang reply}
            </span>
            <span class="deanviewviews y">
            	<strong>$_G[forum_thread][views]</strong></br>{lang show}
            </span>
             <!--{if !IS_ROBOT}-->
                <div class="y">
                    <!--{if $post['invisible'] == 0}--><a href="forum.php?mod=viewthread&action=printable&tid=$_G[tid]" title="{lang thread_printable}" target="_blank"><img src="{IMGDIR}/print.png" alt="{lang thread_printable}" class="vm" /></a>
                    <!--{/if}-->
                    <a href="forum.php?mod=redirect&goto=nextoldset&tid=$_G[tid]" title="{lang last_thread}"><img src="{IMGDIR}/thread-prev.png" alt="{lang last_thread}" class="vm" /></a>
                    <a href="forum.php?mod=redirect&goto=nextnewset&tid=$_G[tid]" title="{lang next_thread}"><img src="{IMGDIR}/thread-next.png" alt="{lang next_thread}" class="vm" /></a>
                </div>
            <!--{/if}-->
            <!--{/if}-->
            <span class="xg1">
                <!--{if $_G['forum_thread'][displayorder] == -2}-->({lang moderating})
                <!--{elseif $_G['forum_thread'][displayorder] == -3}-->({lang have_ignored})
                <!--{elseif $_G['forum_thread'][displayorder] == -4}-->({lang draft})
                    <!--{if $post['first'] && $post['invisible'] == -3}-->
                        <a class="psave" href="forum.php?mod=misc&action=pubsave&tid=$_G[tid]">{lang published}</a>
                    <!--{/if}-->
                <!--{/if}-->
                <!--{if $_G['setting']['threadhidethreshold'] && $_G['forum_thread']['hidden'] >= $_G['setting']['threadhidethreshold']}-->						
                    <!--{if $_G['forum_thread']['authorid'] == $_G['uid']}--><a class="psave" id="hiderecover" title="{lang hiderecover_tips}" href="forum.php?mod=misc&action=hiderecover&tid=$_G[tid]&formhash={FORMHASH}" onclick="showWindow(this.id, this.href, 'get', 0);">{lang hidden}</a><!--{else}-->({lang hidden})<!--{/if}-->
                    &nbsp;
                <!--{/if}-->
                <!--{if $_G['forum_thread']['recommendlevel']}-->
                    &nbsp;<img src="{IMGDIR}/recommend_$_G['forum_thread']['recommendlevel'].gif" alt="" title="{lang thread_recommend} $_G['forum_thread'][recommends]" />
                <!--{/if}-->
                <!--{if $_G['forum_thread'][heatlevel]}-->
                    &nbsp;<img src="{IMGDIR}/hot_$_G['forum_thread'][heatlevel].gif" alt="" title="{lang heats}: $_G['forum_thread']['heats']" />
                <!--{/if}-->
                <!--{if $_G['forum_thread']['closed'] == 1}-->
                    &nbsp;<img src="{IMGDIR}/locked.gif" alt="{lang close}" title="{lang close}" class="vm" />
                <!--{/if}-->
                <a href="forum.php?mod=viewthread&tid=$_G[tid]$fromuid" onclick="return copyThreadUrl(this, '$_G[setting][bbname]')" {if $fromuid}title="{lang share_url_copy_comment}"{/if}>[{lang share_url_copy}]</a>
            </span>
         
            <!--{hook/viewthread_title_extra}-->
        </div>
        
        <!--{hook/viewthread_title_row}-->
    
        <table cellspacing="0" cellpadding="0" class="ad" style=" display:none;">
            <tr>
                <td class="pls">
                <!--{if !$close_leftinfo}-->
                </td>
                <td class="plc">
                <!--{/if}-->
                </td>
            </tr>
        </table>
        <!--{eval $postcount = 0;}-->
        <!--{loop $postlist $post}-->
            <!--{if $rushreply && $_GET['checkrush'] && $post['rewardfloor'] != 1}-->
                <!--{eval continue;}-->
            <!--{/if}--> 
            <div id="post_$post[pid]" class="viewbox {if $post['first']}firstfloor{else}otherfloor{/if} cl" {if $_G['blockedpids'] && $post['inblacklist']}style="display:none;"{/if}>
                <!--{subtemplate forum/viewthread_node}-->
            </div>
            <!--{eval $postcount++;}-->
        <!--{/loop}-->
        <div id="postlistreply" class="pl"><div id="post_new" class="viewthread_table" style="display: none"></div></div>
        <!--{if $_G['blockedpids']}-->
            <div id='hiddenpoststip'><a href='javascript:display_blocked_post();'>{lang other_reply_hide}</a></div>
            <div id="hiddenposts"></div>
        <!--{/if}-->
    </div>
    
    
    <form method="post" autocomplete="off" name="modactions" id="modactions">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="optgroup" />
        <input type="hidden" name="operation" />
        <input type="hidden" name="listextra" value="$_GET[extra]" />
        <input type="hidden" name="page" value="$page" />
    </form>
    
    $_G['forum_tagscript']
    
    <!--{if $multipage && $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->
    <!--{eval $nxtpage = $page + 1;}-->
        <div class="pgbtn"><a href="forum.php?mod=viewthread&tid=$_G[tid]{if $_GET[authorid]}&authorid=$_GET[authorid]{/if}&page=$nxtpage" hidefocus="true">{lang next_page_extra}</a></div>
    <!--{/if}-->
    
    <div class="pgs mtm mbm cl">
        $multipage
        <span class="pgb y"{if $_G['setting']['visitedforums']} id="visitedforumstmp" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id,'pos':'21'})"{/if}><a href="$upnavlink">{lang return_forumdisplay}</a></span>
        
    </div>
    
    <!--{hook/viewthread_middle}-->
    <!--[diy=diyfastposttop]--><div id="diyfastposttop" class="area"></div><!--[/diy]-->
    <!--{if $fastpost}-->
        <!--{subtemplate forum/viewthread_fastpost}-->
    <!--{/if}-->
    
    <!--{hook/viewthread_bottom}-->
    
    <!--{if ($_G['setting']['visitedforums']) && $_G['forum']['status'] != 3}-->
        <div id="visitedforums_menu" class="p_pop blk cl" style="display: none;">
            <table cellspacing="0" cellpadding="0">
                <tr>
                    <td id="v_forums">
                        <h3 class="mbn pbn bbda xg1">{lang viewed_forums}</h3>
                        <ul class="xl xl1">
                            $_G['setting']['visitedforums']
                        </ul>
                    </td>
                </tr>
            </table>
        </div>
    <!--{/if}-->
    <!--{if $_G['medal_list']}-->
    <!--{loop $_G['medal_list'] $medalid $medal}-->
        <div id="md_{$medalid}_menu" class="tip tip_4" style="display: none;">
            <div class="tip_horn"></div>
            <div class="tip_c">
                <h4>$medal[name]</h4>
                <p>$medal[description]</p>
            </div>
        </div>
    <!--{/loop}-->
    <!--{/if}-->
    
    <!--{if !IS_ROBOT && !empty($_G[setting][lazyload])}-->
        <script type="text/javascript">
        new lazyload();
        </script>
    <!--{/if}-->
    
    <!--{if !IS_ROBOT && $_G['setting']['threadmaxpages'] > 1}-->
        <script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=viewthread&tid=$_G[tid]<!--{if $_GET[authorid]}-->&authorid=$_GET[authorid]<!--{/if}-->', $page);}</script>
    <!--{/if}-->
    </div>
    <!--{if $close_leftinfo}-->
	<div class="sd">
		
		<div class="dean_author deanmind cl">
			<div class="r_arrow"></div>
			<div class="lzinfo_img">
				<a href="home.php?mod=space&uid={$_G[forum_thread][authorid]}" target="_blank" title="访问我的空间"><!--{avatar($_G[forum_thread][authorid],large)}--></a>
			</div>

			<div class="deanuser">
				<a class="deanlzname" href="home.php?mod=space&uid={$_G[forum_thread][authorid]}" target="_blank" title="访问我的空间" c="1">{$_G[forum_thread][author]}</a>
				<!--{loop $postlist $post}-->
					<!--{if $post['first']}-->
						<!--{loop $post['verifyicon'] $vid}-->
							<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $_G['setting']['verify'][$vid]['icon']}--><img src="$_G['setting']['verify'][$vid]['icon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /><!--{else}-->$_G['setting']['verify'][$vid]['title']<!--{/if}--></a>
						<!--{/loop}-->
						<!--{loop $post['unverifyicon'] $vid}-->
							<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><img src="$_G['setting']['verify'][$vid]['unverifyicon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /></a>
						<!--{/loop}-->
						<a href="home.php?mod=spacecp&ac=usergroup&gid=$post[groupid]" target="_blank" class="deangrtxt">{$post[authortitle]}</a>
					<!--{/if}-->
				<!--{/loop}-->
				</div>
                
                
                
                
                <div class="dean_medalbox">
                	<ul>
                        <!--{loop $ucmedals $deanmedalid}-->
                        <li><img src="static/image/common/medal$deanmedalid[medalid].gif"  /></li>
                        <!--{/loop}-->
                    </ul>
                </div>
                
				<div class="clear"></div>
                <br>
                <p class="z"><strong>$ucauthor['following']</strong><span>关注</span></p>
                <p class="m"><strong>$ucauthor['follower']</strong><span>粉丝</span></p>
                <p class="y"><strong>$ucauthor['threads']</strong><span>帖子</span></p>
                <div class="clear"></div>
            
            <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
            
			<!--{if !($_G['setting']['threadguestlite'] && !$_G['uid'])}-->
            	
                <!--{if $thread[authorid] != $_G[uid]}-->
                      <ul class="user_contact pt15 cl">
                          		
                              <li class="user_flw">
                                  <a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_{$_G[forum_thread][authorid]}&touid={$_G[forum_thread][authorid]}&pmid=0&daterange=2&tid={$_G[tid]}" onclick="showWindow('sendpm', this.href);" title="{lang viewthread_left_sendpm}">发送私信</a>
                               </li>
                               
                               <!--{if helper_access::check_module('follow')}-->
                                <li class="user_add">
								<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$post[authorid]" id="followmod_$post[authorid]" title="{lang follow}" class="xi2" onclick="showWindow('followmod', this.href, 'get', 0);">{lang follow}</a>
                                <!--{/if}-->
							</li>
                             <li class="user_pm"><a href="home.php?mod=space&uid={$_G[forum_thread][authorid]}" target="_blank">Ta的主页</a></li>
                         </ul>
                      <!--{/if}-->
			<!--{/if}-->
            <!--{/if}-->
		</div>

        <div class="clear"></div>
        <div class="deansd">
			
            <div class="clear"></div>
            <div class="deanhotpics deannewshadow">
				<div class="deanvh3"><span>热门图文</span><div class="clear"></div></div>
				<div class="clear"></div>
				<ul><!--[diy=deanhotpics]--><div id="deanhotpics" class="area"></div><!--[/diy]-->
					<div class="clear"></div>
				</ul>
			</div>
			<div class="clear"></div>
			<div class="deanhotartice deannewshadow">
				<div class="deanvh3"><span>热门帖子</span><div class="clear"></div></div>
				<div class="clear"></div>
				<ul><!--[diy=deanmblldiv]--><div id="deanmblldiv" class="area"></div><!--[/diy]--></ul>
			</div>
			<script type="text/javascript">jq(".deanmbll").slide({titCell:".hd ul",mainCell:".deanmblldiv ul",autoPage:true,effect:"top",autoPlay:true,vis:5});</script>
			
			<div class="clear"></div>
			<div class="deanad4s"><!--[diy=deanad4s]--><div id="deanad4s" class="area"></div><!--[/diy]--></div>
			<div class="deanad4s"><!--[diy=deanad4s1]--><div id="deanad4s1" class="area"></div><!--[/diy]--></div>
            <div class="deanad4s"><!--[diy=deanad4s2]--><div id="deanad4s2" class="area"></div><!--[/diy]--></div>
			<div class="clear"></div>
			<div class="deanranklistha deanshadow">
            	<div class="deanvh3"><span>排行榜</span><ul class="deanranknameha"><li class="cur">日</li><li>周</li><li>月</li></ul><div class="clear"></div></div>
                <div class="clear"></div>
                <div class="deanrankcha"><dl><dd style="display:block;"><ul><!--[diy=deanrankcha]--><div id="deanrankcha" class="area"></div><!--[/diy]--></ul></dd><dd><ul><!--[diy=deanrankcha1]--><div id="deanrankcha1" class="area"></div><!--[/diy]--></ul></dd><dd><ul><!--[diy=deanrankcha2]--><div id="deanrankcha2" class="area"></div><!--[/diy]--></ul></dd></dl></div>
            </div>
            <script type="text/javascript">
            	jq(".deanrankcha ul li").hover(function(s){
					jq(".deanrankcha ul li").children(".deanrankinfost").hide();
					jq(this).children(".deanrankinfost").show();
					})
				jq(".deanranknameha li").each(function(a){
					jq(this).hover(function(){
						jq(this).addClass("cur").siblings().removeClass("cur");
						jq(".deanrankcha dl dd").eq(a).show().siblings().hide();
						})
					})
            </script>
			<div class="deanzlzuozhe">
            	<div class="deanvh3"><span>作者专栏</span><div class="clear"></div></div>
            	<div class="clear"></div>
                <ul><!--[diy=deanzlzuozhe]--><div id="deanzlzuozhe" class="area"></div><!--[/diy]--></ul>
            </div>
            <script type="text/javascript">
            	jq(".deanzlzuozhe ul li:last").css({"border-bottom":"0","padding":"0","margin-bottom":"0"});
            </script>
		</div>
 
    </div>
     <!--{/if}-->
</div>
<div class="clear"></div>

<div class="wp mtn">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>

<!--{if $_G['relatedlinks'] || $_GET['highlight']}-->
	<script type="text/javascript">
		var relatedlink = [];
		<!--{loop $_G['relatedlinks'] $key $link}-->
		relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
		<!--{/loop}-->
		{eval $highlights = explode(' ', str_replace(array('\'', chr(125)), array('&#039;', '&#125;'), dhtmlspecialchars($_GET['highlight'])));}
		<!--{loop $highlights $word}-->
		{eval $key++;}
		relatedlink[$key] = {'sname':'$word', 'surl':''};
		<!--{/loop}-->
		relatedlinks('postmessage_$_G[forum_firstpid]');
	</script>
<!--{/if}-->

<!--{if !empty($_G['cookie']['clearUserdata']) && $_G['cookie']['clearUserdata'] == 'forum'}-->
	<script type="text/javascript">saveUserdata('forum_'+discuz_uid, '')</script>
<!--{/if}-->

<script type="text/javascript">
<!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->
function showsetcover(obj) {
	if(obj.parentNode.id == 'postmessage_$_G[forum_firstpid]') {
		var defheight = $_G['setting']['forumpicstyle']['thumbheight'];
		var defwidth = $_G['setting']['forumpicstyle']['thumbwidth'];
		var newimgid = 'showcoverimg';
		var imgsrc = obj.src ? obj.src : obj.file;
		if(!imgsrc) return;

		var tempimg=new Image();
		tempimg.src=imgsrc;
		if(tempimg.complete) {
			if(tempimg.width < defwidth || tempimg.height < defheight) return;
		} else {
			return;
		}
		if($(newimgid) && obj.id != newimgid) {
			$(newimgid).id = 'img'+Math.random();
		}
		if($(newimgid+'_menu')) {
			var menudiv = $(newimgid+'_menu');
		} else {
			var menudiv = document.createElement('div');
			menudiv.className = 'tip tip_4 aimg_tip';
			menudiv.id = newimgid+'_menu';
			menudiv.style.position = 'absolute';
			menudiv.style.display = 'none';
			obj.parentNode.appendChild(menudiv);
		}
		menudiv.innerHTML = '<div class="tip_c xs0"><a onclick="showWindow(\'setcover_'+newimgid+'\', this.href)" href="forum.php?mod=ajax&amp;action=setthreadcover&amp;tid=$_G[tid]&amp;pid=$_G[forum_firstpid]&amp;fid=$_G[fid]&imgurl='+imgsrc+'">{lang set_cover}</a></div>';
		obj.id = newimgid;
		showMenu({'ctrlid':newimgid,'pos':'12'});
	}
	return;
}
<!--{/if}-->
function succeedhandle_followmod(url, msg, values) {
	var fObj = $('followmod_'+values['fuid']);
	if(values['type'] == 'add') {
		fObj.innerHTML = '{lang nofollow}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
	} else if(values['type'] == 'del') {
		fObj.innerHTML = '{lang follow}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
	}
}
<!--{if $_G['blockedpids']}-->
var blockedPIDs = [<!--{echo implode(',', $_G['blockedpids'])}-->];
<!--{/if}-->
<!--{if $postlist && empty($_G['setting']['disfixedavatar'])}-->
fixed_avatar([<!--{echo implode(',', array_keys($postlist))}-->], {if empty($_G['setting']['disfixednv_viewthread']) }1{else}0{/if});
<!--{elseif empty($_G['setting']['disfixednv_viewthread'])}-->
fixed_top_nv();
<!--{/if}-->
</script>
<script type="text/javascript">
jQuery(function() { 
	var elm = jQuery('.deansideboxs_move'); 
	var startPos = jQuery(elm).offset().top; 
	jQuery.event.add(window, "scroll", function() { 
		var p = jQuery(window).scrollTop(); 
		jQuery(elm).css('position',((p) > startPos) ? 'fixed' : 'static'); 
		jQuery(elm).css('top',((p) > startPos) ? '65px' : ''); 
	}); 
}); 
</script>
<script type="text/javascript">
	jq(".viewinfo .plc  .pi strong a").eq(0).addClass("deanshafa");
	jq(".viewinfo .plc  .pi strong a").eq(1).addClass("deanbandeng");
	jq(".viewinfo .plc  .pi strong a").eq(2).addClass("deandiban");
</script>

<!--{template common/footer}-->



