<?php echo 'From: DisM.taobao.com';exit;?>
{eval
	$filter = array( 'common' => '{lang have_posted}', 'save' => '{lang draft}', 'close' => '{lang closed}', 'aduit' => '{lang pending}', 'ignored' => '{lang ignored}', 'recyclebin' => '{lang recyclebin}');
	$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=thread&view=me\">{lang they_thread}</a>";
}

<!--{if $diymode}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
        
        <style type="text/css">
    	.deanztlist{ width:700px!important; margin:20px auto; padding-bottom:50px; }
			.deanztlist ul{ width:730px!important; }
			.bm{ border:1px solid #e6e6e6;}
				.bm_h{ border-bottom:1px solid #e6e6e6;}
   		 </style>
		<div id="ct" class="ct2 wp cl">
			<div class="mn">
				<div class="bm">
					<div class="bm_h">
						<!--{if $space[self]}--><span class="xi2 y"><a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="addnew">{lang posted}</a></span><!--{/if}-->
						<h1 class="mt">
							<!--{if $_GET[type] == 'reply'}-->
							<span class="xs1 xw0"><a href="home.php?mod=space&do=thread&view=me&type=thread&uid=$space[uid]&from=space">{lang topic}</a><span class="pipe">|</span></span>{lang reply}
							<!--{else}-->
							{lang topic}<span class="xs1 xw0"><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=reply&uid=$space[uid]&from=space">{lang reply}</a></span>
							<!--{/if}-->
						</h1>
					</div>
				<div class="bm_c">
	<!--{else}-->
		<!--{template common/header}-->
		<div id="pt" class="bm cl">
			<div class="z">
				<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
				<a href="home.php?mod=space&uid=$space[uid]">{$space[username]}</a> <em>&rsaquo;</em>
				<a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me">{lang thread}</a>
			</div>
		</div>
		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="ct1 wp cl">
			<div class="mn">
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<div class="bm bw0">
					<div class="bm_c">
	<!--{/if}-->
<!--{else}-->
	<!--{template common/header}-->
	<div id="pt" class="bm cl">
		<div class="z">
			<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
			<!--{if $_G[setting][homestyle]}--><a href="home.php">$_G[setting][navs][4][navname]</a> <em>&rsaquo;</em> <!--{/if}-->
			<a href="home.php?mod=space&do=blog">{lang thread}</a>
		</div>
	</div>
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ct" class="ct2_a wp cl">
	<!--{if $_G[setting][homestyle]}-->
    
		<div class="appl">
			<!--{subtemplate common/userabout}-->
		</div>
		<div class="mn pbw">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<ul class="tb cl">
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
	<!--{else}-->
		<div class="appl">
			<div class="tbn">
				<h2 class="mt bbda">{lang thread}</h2>
				<ul>
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
		</div>
		<div class="mn pbw">
		<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
	<!--{/if}-->
<!--{/if}-->
		<style type="text/css">
        	.tbmu{ border-bottom:1px solid #e6e6e6; padding:0; height:41px; line-height:41px; position:relative;}
				.deantbmuc{ height:40px; position:absolute; left:10px; bottom:1px; z-index:2;}
					.deantbmuc a{ display:inline-block; float:left; height:40px; font-size:16px; color:#666; border:1px solid #e6e6e6;  margin:0; padding:0 30px; z-index:3; position:relative; background:#fafafa;}
					.deantbmuc a.a{ border-bottom:1px solid #fff; background:#fff; font-weight:normal; color:#00BC9B; border-top:1px solid #00BC9B;}
        </style>
		<!--{if !$diymode && $space[self]}-->
			<!--{if $_GET['view'] == 'me'}-->
			<p class="tbmu bw0">
				<!--{if $viewtype != 'postcomment'}-->
					<span class="y">
					<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=" {if !$_GET[filter]}class="a"{/if}>{lang all}</a>
					<!--{loop $filter $key $name}--><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=$key" {if $key == $_GET[filter]}class="a"{/if}>$name</a><!--{/loop}--> &nbsp;
						<select name="forumlist" id="forumlist" class="ps vm" onchange="viewforumthread(this.value);" style="width: 120px; word-wrap: normal;">
							<option value="0">{lang follow_select_forum}</option>
							$forumlist
						</select>
					</span>
				<!--{/if}-->
				<a href="home.php?mod=space&do=thread&view=me&type=thread" $orderactives[thread]>{lang topic}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=reply" $orderactives[reply]>{lang reply}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=postcomment" $orderactives[postcomment]>{lang post_comment}</a>
				<!--{if $viewtype != 'reply' && $viewtype != 'postcomment'}-->&nbsp; <input type="text" id="searchmypost" class="px vm" size="15" /> <button class="pn vm" onclick="searchpostbyusername($('searchmypost').value, '$_G[username]');"><em>{lang search}</em></button><!--{/if}-->
			</p>
			<!--{elseif $_GET['view'] == 'all'}-->
			<p class="tbmu bw0">
				<a href="home.php?mod=space&do=thread&view=all&order=dateline" $orderactives[dateline]>{lang newest_thread}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=all&order=hot" $orderactives[hot]>{lang top_thread}</a>
			</p>
			<!--{/if}-->
		<!--{/if}-->
		
		<!--{if $diymode && !$_G[setting][homepagestyle] }-->
			<div class="tbmu">
            	<div class="deantbmuc">
                    <a style="border-right:0;" href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread" $orderactives[thread]>{lang topic}</a>
                    <a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=reply" $orderactives[reply]>{lang reply}</a>
                </div>
			</div>
		<!--{/if}-->
		
		<!--{if $userlist}-->
			<p class="tbmu bw0">
				{lang view_by_friend}
				<select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
					<option value="">{lang all_friends}</option>
					<!--{loop $userlist $value}-->
					<option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
					<!--{/loop}-->
				</select>
			</p>
		<!--{/if}-->
        <style type="text/css">
        	.deanztlist{ width:1180px; margin:20px auto; padding-bottom:50px; }
				.deankclist ul{ width:1200px; height:auto;}
					.deankclist ul li{ width:280px; height:270px; margin-right:20px; margin-bottom:20px; float:left; position:relative;}
						.deankclist ul li .deankcimg{ position:relative; width:278px; height:190px;  border:1px solid #e6e6e6; border-bottom:0; overflow:hidden;}
							.deankclist ul li .deankcimg a{ display:block; width:278px; height:190px; overflow:hidden;}
								.deankclist ul li .deankcimg a img{ width:280px; height:190px; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; }
								.deankclist ul li .deankcimg a:hover img{transform: scale(1.1); -moz-transform: scale(1.1); -webkit-transform: scale(1.1); -o-transform: scale(1.1); -ms-transform: scale(1.1);}
							.deankclist ul li a .deankcover{ position:absolute; opacity:0; z-index:2; width:278px; height:190px; overflow:hidden; left:0; top:0; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; background:rgba(0,0,0,0.4); }	
							.deankclist ul li:hover .deankcover{ opacity:1;}
								.deankclist ul li a .deankcover i.deanplaybtn{ display:block; width:50px; height:50px; position:absolute; left:50%; top:50%; margin-left:-25px; margin-top:-25px; }
						.deankclist ul li .deankcbottom{ padding:5px 10px; border:1px solid #e6e6e6; border-top:0; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; position:relative; z-index:200; background:#fff; }
						.deankclist ul li:hover .deankcbottom{ }
							.deankcnames{font-size:15px; font-weight:bold; letter-spacing:0.5px; color: #333; line-height:20px; margin-bottom:7px; height:40px; overflow: hidden;}
								.deankcnames a{ color:#333;}
								.deankcnames a:hover{ color:#3297fc;}
							.deankcsummary{ font-size:12px; color:#999; line-height:20px; height:0px; overflow:hidden; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; opacity:0; letter-spacing:0.5px;}	
							.deankclist ul li:hover .deankcsummary{  height:60px; opacity:1; margin-bottom:10px;}
							
							.deankcsummary1{ font-size:12px; color:#999; line-height:20px; height:0px; overflow:hidden; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; opacity:0; letter-spacing:0.5px;}	
							.deankclist ul li:hover .deankcsummary1{ height:80px; opacity:1; margin-bottom:10px;}
								.deankclist ul li:hover .deankcsummary1 i{  padding-right:5px; color:#aaa; font-size:12px; padding-left:5px;}
								.deankclist ul li:hover .deankcsummary1 a{ color:#666; font-size:12px;}
							 .deankcsummary1 h3{ margin-bottom:5px; margin-top:5px; border-bottom:1px solid #f0f0f0; padding-bottom:5px; font-size:14px; color:#666;}
						.deankcinfos{ color:#777;}
							.deankcinfos .deanflha{ float:left;}
								.deankcinfos .deanflha i{ padding-right:5px; color:#aaa;}
								.deankcinfos .deanflha a{ color:#777;}
							.deankcinfos .deanfrha{ float:right;}
							.deankcinfos dl{ margin-top:3px; height:0; opacity:0; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; }
							.deankclist ul li:hover .deankcinfos dl{ opacity:1; height:20px;}
							.deankcinfos dl dd{ float:left; height:20px; line-height:20px; font-size:12px; color:#777; padding-right:15px;}
								.deankcinfos dl dd i{ padding-right:5px; color:#aaa;}
								.deankcinfos dl dd a{ color:#777;}
        </style>
		<div class="tl deanztlist">
			<form method="post" autocomplete="off" name="delform" id="delform" action="home.php?mod=space&do=thread&view=all&order=dateline" onsubmit="showDialog('{lang del_select_thread_confirm}', 'confirm', '', '$(\'delform\').submit();'); return false;">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="delthread" value="true" />

					
					<div class="deankclist">
                        <!--{if $list}-->
                            <ul>
                            <!--{loop $list $stid $thread}-->
                                <!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
                                	
                                	<li>
                                	<!--{if $thread['attachment'] == 2}-->	
                                    <!--{eval include 'template/dean_cj_190401/php/innerpics.php'}-->
                                    <!--{loop $dnpicfm $homepic}-->
                                      <div class="deankcimg"><a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank"><img src="data/attachment/forum/$homepic[attachment]"></a></div>
                                    <!--{/loop}-->
                                    <!--{else}--><div class="deankcimg"><a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank"><img src="./template/dean_cj_190401/deancss/nopic.jpg"/></a></div>
                                    <!--{/if}-->
                                    
                                    <div class="deankcbottom">
                                        <div class="deankcnames"><a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]" target="_blank">$thread[subject]</a></div>
                                        <div class="deankcinfos">
                                        	<div class="deankcmb">
                                        		<div class="deanflha"><i class="icon-tag"></i><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" class="xg1" target="_blank">$forums[$thread[fid]]</a></div>
                                                <div class="clear"></div>
                                            </div>
                                        </div>
                                        
                                     <!--{if $actives[me] && $viewtype=='reply'}-->
                                     	<div class="deankcsummary1">
                                        <h3>���ʻظ�:</h3>
                                        <dl>
                                        	<!--{loop $tids[$stid] $pid}-->
                                        	<dd>
                                            	<!--{eval $post = $posts[$pid];}-->
                                            	<i class="icon-quote-left"></i><a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid" target="_blank"><!--{if $post[message]}-->{$post[message]}<!--{else}-->���޻ظ�<!--{/if}--></a><i class="icon-quote-right"></i>
                                            </dd>
                                            <!--{/loop}-->
                                        </dl>
                                        </div>
                                    <!--{/if}-->
                                         
                                	</div> 
                                </li>
                                	
                              <!--{else}-->
                                	
                                    <li>
                                    <!--����-->
                                    	<!--{if $thread[attachment] == 2}-->
                                        <!--{eval include 'template/dean_cj_190401/php/innerpics.php'}-->
                                        <!--{loop $dnpicfm $homepic}-->
                                            <div class="deankcimg"><a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank"><img src="data/attachment/forum/$homepic[attachment]"><div class="deankcover"><i class="deanplaybtn"></i></div></a></div>
                                        <!--{/loop}-->
                                        <!--{else}--><div class="deankcimg"><a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank"><img src="./template/dean_cj_190401/deancss/nopic.jpg"/><div class="deankcover"><i class="deanplaybtn"></i></div></a></div>
                                        <!--{/if}-->
                                        
                                        <div class="deankcbottom">
                                            <div class="deankcnames"><a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank" {if $thread['displayorder'] == -1}class="recy"{/if}>$thread[subject]</a></div>
                                            <div class="deankcsummary">
                                                <!--{eval include 'template/dean_cj_190401/php/summary.php'}-->
                                                <!--{echo cutstr($deansummary_echo,200)}-->
                                            </div>
                                            <div class="deankcinfos">
                                                <div class="deankcmb">
                                                    <!--{if $viewtype != 'postcomment'}-->
                                                        <div class="deanflha"><i class="icon-tag"></i><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$forums[$thread[fid]]</a></div>
                                                        <div class="deanfrha"><!--{if $actives[me]}-->$thread[lastpost]<!--{/if}--></div>
                                                        <div class="clear"></div>              
                                                    <!--{/if}-->
                                                </div>
                                                <dl>
                                                    <!--{if $viewtype != 'postcomment'}-->  
                                                    <dd><i class="icon-comments"></i><a href="forum.php?mod=viewthread&tid=$thread[tid]" class="xi2" target="_blank">$thread[replies]</a></dd>
                                                    <dd><i class="icon-eye-open"></i>$thread[views]</dd>
                                                    <!--{/if}-->
                                                    <div class="clear"></div>
                                                </dl>
                                            </div>
                                        </div>
                                    </li>
                           	    
                            	<!--{/if}-->
                            <!--{/loop}-->
                            <div class="clear"></div>
                            </ul>
                        <!--{else}-->
                        	<p class="emp">{lang no_related_posts}</p>
                        <!--{/if}-->
                    </div>	
					
                        
        
                  <div style="display:none;"> 
                    <!--{if $thread['digest'] > 0}-->
                        <img src="{IMGDIR}/digest_$thread[digest].gif" alt="{lang digest} $thread[digest]" align="absmiddle" />
                    <!--{/if}-->
                    <!--{if $thread['attachment'] == 2}-->
                        <img src="{STATICURL}image/filetype/image_s.gif" alt="{lang photo_accessories}" align="absmiddle" />
                    <!--{elseif $thread['attachment'] == 1}-->
                        <img src="{STATICURL}image/filetype/common.gif" alt="{lang accessory}" align="absmiddle" />
                    <!--{/if}-->
                    <!--{if $thread[multipage]}--><span class="tps">$thread[multipage]</span><!--{/if}-->
                    <!--{if !$_GET['filter']}-->
                        <!--{if $thread[$statusfield] == -1}--><span class="xg1">$filter[recyclebin]</span>
                        <!--{elseif $thread[$statusfield] == -2}--><span class="xg1">$filter[aduit]</span>
                        <!--{elseif $thread[$statusfield] == -3 && $thread[displayorder] != -4}--><span class="xg1">$filter[ignored]</span>
                        <!--{elseif $thread[displayorder] == -4}--><span class="xg1">$filter[save]</span>
                        <!--{elseif $thread['closed'] == 1}--><span class="xg1">$filter[close]</span>
                        <!--{/if}-->
                    <!--{/if}-->
                </div> 
						
					
					
				

					<!--{if $_GET['view'] == 'all' && $pruneperm && !$_GET['archiveid'] && $list}-->
						<p class="mtm pns">
							<label for="chkall" onclick="checkall(this.form, 'moderate')"><input type="checkbox" name="chkall" id="chkall" class="pc vm" />{lang select_all}</label>
							<button type="submit" name="delsubmit" value="true" class="pn vm"><em>{lang del_select_thread}</em></button>
						</p>
					<!--{/if}-->
				</form>

				<!--{if $hiddennum}-->
					<p class="mtm">{lang hide_thread}</p>
				<!--{/if}-->
			</div>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->		
		
		<script type="text/javascript">
		function fuidgoto(fuid) {
			window.location.href = 'home.php?mod=space&do=thread&view=we&fuid='+fuid;
		}
		function viewforumthread(fid) {
			window.location.href = '{$forumurl}&fid='+fid;
		}
		</script>
		
		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="sd">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->

<!--{template common/footer}-->
