<?php echo 'From: DisM.taobao.com';exit;?>
<style type="text/css">
body{ background:#fff;}
#pt{ display:none;}
	.wp,#wp{ width:100%; background:#fff;}
	.tbmu{ border-bottom:1px solid #f0f0f0;}
	#ct .pnc, #ct a.pnc{ display: block; float: right; margin-right: 15px; color: #fff; background: #4593FF; font-size: 12px; height: 22px; line-height: 22px; padding: 0 10px; border-radius: 22px; transition: all 0.5s; border:0; font-weight:normal;}
	#ct .pnc strong, #ct a.pnc strong{ font-weight:normal; text-indent:0!important; padding:0;}
	#fastpostsubmit{ text-indent:0;}
	#uhd{ width:100%; height:280px; border:0; background:#4b9ff4 url(./template/dean_cj_190401/deancss/home/person.jpg) top center no-repeat; background-size:cover;  position:relative; z-index:1; }
	.deanlightblack{ width:100%; height:290px; background:rgba(0,0,0,0.15); position:absolute; z-index:2; left:0; top:0;}
		.deantbnavs{ position:absolute; bottom:0; left:0; width:100%; height:50px; line-height:50px; background:rgba(0,0,0,0.3); z-index:3; }
			.deantbnavs ul{ width:800px; margin:0 auto;}
			.deantbnavs li{ display:inline-block; float:left; width:95px; margin-right:5px; text-align:center;}
				.deantbnavs li a{ color:#fff; font-size:14px; display:block; height:50px; line-height:50px;}
				.deantbnavs li a:hover{ background:#fff; color:#333; }
				.deantbnavs li.a a{ background:#fff; color:#333; }
	#ct{ width:1180px!important; margin:0px auto; margin-top:20px;  border:0!important;}
		.bm_c{ padding:0px; }
	
	/*�û���Ϣ*/
	.deanusecenter{ text-align:center;}
		.deanuseravar{ width:100px; margin:0 auto; margin-top:50px; position:relative; z-index:1;}
			.deanuseravar a{}
			.deanuseravar a img{ width:100px; height:100px; border-radius:100px; border:5px solid #fff; }
				.deanusername{ font-size:22px; color:#fff; text-align:center; margin-top:5px; margin-bottom:5px;}
		.deanusecenter .deanbio{ height:22px; line-height:22px; background:#4b9ff4; border:2px solid #eee; color:#666; font-size:12px; padding:0 10px; border-radius:15px; display:inline-block; text-align:center;}
	.deanuseravar span{ display:block; height:20px; line-height:20px; border-radius:20px; padding:0 6px; border:3px solid #fff; background:rgba(0,0,0,0.5); color:#fff; font-size:12px; position:absolute; right:-20px; top:0;}
	.deantns{ text-align:center; line-height:20px; margin-top:10px; font-size:14px; color:#aaa;}
		.deantns span{ display:inline-block;}
		.deantns i{ display:inline-block; height:10px; border-right:1px solid #999; width:1px; margin-right:7px; margin-left:7px; margin-top:5px;}
	#uhd .flw_hd{ margin-bottom:0;}

	.deanw1180div{ width:1180px; margin:30px auto;}
		.deanuserleft{ float:left; width:160px; height:160px; position:relative; z-index:1;}
			.deanuserleft span{ display:block; height:20px; line-height:20px;  padding:0 6px; border:3px solid #fff; background:rgba(0,0,0,0.5); color:#fff; font-size:12px; position:absolute; right:-20px; top:0;}
			.deanuserleft img{ width:150px; height:150px; border:5px solid #fff;}
		.deanusercenter{ float:left; width:500px; height:160px; position:relative; z-index:1; margin-left:20px; color:#fff;}
			.deanusercenter h2{ font-size:30px; color:#fff; height:40px; line-height:40px; font-weight:normal; margin-top:30px;}
			.deanuserzu a{ color:#fff;}
			.deanbio{ height:30px; line-height:30px; font-size:12px; color:#eee;}
				.deanbio i{ padding-right:5px;}
			.deanuserxxx{ position:absolute; z-index:2; bottom:0; left:0; }
				.deanuserxxx ul{ }
					.deannewbtn ul li{ display:inline-block; margin-right:15px; height:26px; line-height:26px; color:#fff;}
						.deannewbtn ul li a{ display:inline-block; height:26px; line-height:26px; background:#4593FF;  color:#fff; padding:0 15px; }
							.deannewbtn ul li a i{ padding-right:5px;}
						.deannewbtn ul li a#followmod{ background:#009cff;}
						.deannewbtn ul li.addf a{ background:#3db868;}
						.deannewbtn ul li.pm2 a{ background:#fe5000;}
		.deanuserright{ float:right; color:#fff;}
			.deanusernums{ width:400px; text-align:center; margin-top:40px;}
				.deanusernums ul{}
					.deanusernums ul li{ float:left; font-size:12px; color:#fff; text-align:center; width:20%; position:relative; z-index:1;}
						.deanusernums ul li i{ padding-right:5px; font-size:12px;}
						.deanusernums ul li span{ color:#fff;}
						.deanusernums ul li b{ position:absolute; right:0; top:10px; height:30px; width:1px; border-right:1px solid #888;}
			.deanliuyan{ margin-top:30px; text-align:center;}
				.deanliuyan a{ display:inline-block; width:100px; height:30px; background:#f90; color:#fff; line-height:30px; border-radius:2px; font-size:16px; text-align:center;}
					.deanliuyan a i{ padding-right:5px;}
</style>
<!--{if $space[uid]}-->
<div id="uhd">
	<div class="deanlightblack">
		<div class="deanw1180div">
    	<!--{eval include 'template/dean_cj_190401/php/deanmbcount.php'}-->
        <!--{loop $dnmbinfo $dninfo}-->
    	<div class="deanuserleft"><a href="home.php?mod=space&uid=$space[uid]"><!--{avatar($space[uid],big)}--></a><span>UID:$dninfo[uid]</span></div>
        <!--{/loop}-->
        <div class="deanusercenter">
        	<h2>{$space[username]}�θ��˿ռ�</h2>
            <div class="clear"></div>
            <!--{loop $dnmbinfo $dninfo}--><!--{if $dninfo[bio]}--><p class="deanbio"><i class="icon-bar-chart"></i>���˼�飺$dninfo[bio]</p><!--{else}--><p class="deanbio"><i class="icon-bar-chart"></i>��һ������ʲô��ûд...</p><!--{/if}--><!--{/loop}-->
            <div class="deanuserxxx">
            	<!--{if CURMODULE == 'follow'}-->
                <!--{subtemplate home/follow_user_header}-->
                <!--{elseif !$space[self]}-->
                <div class="deannewbtn">
                    <ul>
                        <!--{if helper_access::check_module('follow')}-->
                        <li class="addflw">
                            <!--{if !ckfollow($space['uid'])}-->
                                <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"><i class="icon-headphones"></i>{lang follow_add}TA</a>
                            <!--{else}-->
                                <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]"><i class="icon-headphones"></i>{lang follow_del}</a>
                            <!--{/if}-->
                        </li>
                        <!--{/if}-->
                        <li class="addf">
                            <!--{if !$isfriend}-->
                            <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=addfriendhk_{$space[uid]}" id="a_friend_li_{$space[uid]}" onclick="showWindow(this.id, this.href, 'get', 0);" class="xi2"><i class="icon-plus"></i>{lang add_friend}</a>
                            <!--{else}-->
                            <a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$space[uid]&handlekey=ignorefriendhk_{$space[uid]}" id="a_ignore_{$space[uid]}" onclick="showWindow(this.id, this.href, 'get', 0);" class="xi2"><i class="icon-plus"></i>{lang ignore_friend}</a>
                            <!--{/if}-->
                        </li>
                        <li class="pm2">
                            <a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onclick="showWindow('showMsgBox', this.href, 'get', 0)" title="{lang send_pm}"><i class=" icon-envelope-alt"></i>{lang send_pm}</a>
                        </li>
                    </ul>
                    <!--{if helper_access::check_module('follow')}-->
                    <script type="text/javascript">
                    function succeedhandle_followmod(url, msg, values) {
                        var fObj = $('followmod');
                        if(values['type'] == 'add') {
                            fObj.innerHTML = '{lang follow_del}';
                            fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
                        } else if(values['type'] == 'del') {
                            fObj.innerHTML = '{lang follow_add}TA';
                            fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
                        }
                    }
                    </script>
                    <!--{/if}-->
                </div>
                <!--{/if}-->
            </div>
        </div>
        <div class="deanuserright">
        	<div class="deanusernums">
            	<ul>
            	<!--{loop $dncounts $dnval}-->
                   <li><span>$dnval[threads]</span><div class="clear"></div><i class="icon-magic"></i><em>����</em><b></b></li>
                   <li><span>$dnval[feeds]</span><div class="clear"></div><i class="icon-volume-up"></i><em>�㲥</em><b></b></li>
                   <li><span>$dnval[follower]</span><div class="clear"></div><i class="icon-group"></i><em>����</em><b></b></li>
                   <li><span>$dnval[following]</span><div class="clear"></div><i class="icon-headphones"></i><em>����</em><b></b></li>
                   <li><span>$dnval[friends]</span><div class="clear"></div><i class="icon-user"></i><em>����</em></li>
                <!--{/loop}-->
                </ul>
            </div>
            <div class="clear"></div>
            <div class="deanliuyan">
            	<!--{if helper_access::check_module('wall')}-->
                	<a href="home.php?mod=space&uid=$space[uid]&do=wall&from=space"><i class="icon-pencil"></i>����</a>
                <!--{/if}-->
            </div>
        </div>
        <div class="clear"></div>
    </div>
    </div>
    
	
	<div class="h cl">
		
		<h2 class="mt">
			
			<!--{if isset($flag[$_G['uid']])}-->
			<span class="xs1 xg1 xw0">
				<span id="followbkame_{$uid}"><!--{if $flag[$_G['uid']]['bkname']}-->$flag[$_G['uid']]['bkname']<!--{/if}--></span>
				<a href="home.php?mod=spacecp&ac=follow&op=bkname&fuid=$uid&handlekey=followbkame_$uid" id="fbkname_{$uid}" onclick="showWindow('followbkame_{$uid}', this.href, 'get', 0);"><!--{if $flag[$_G['uid']]['bkname']}-->[{lang follow_mod_bkname}]<!--{else}-->[{lang follow_add_bkname}]<!--{/if}--></a>
			</span>
			<!--{/if}-->
		</h2>
		<p style="display:none;">
			<a href="{$_G[siteurl]}?$uid" class="xg1">{$_G[siteurl]}?$uid</a>
			<!--{if checkperm('allowbanuser') || checkperm('allowedituser') || $_G[adminid] == 1}-->
				<span class="pipe">|</span>
					<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
							<!--{if checkperm('allowbanuser')}-->
							<a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" id="usermanageli" onmouseover="showMenu(this.id)" class="showmenu" target="_blank">{lang member_manage}</a>
							<!--{else}-->
							<a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" id="usermanageli" onmouseover="showMenu(this.id)" class="showmenu" target="_blank">{lang member_manage}</a>
							<!--{/if}-->
					<!--{/if}-->
					
					<!--{if $_G[adminid] == 1}-->
						<a href="forum.php?mod=modcp&action=thread&op=post&do=search&searchsubmit=1&users=$encodeusername" id="umanageli" onmouseover="showMenu(this.id)" class="showmenu">{lang content_manage}</a>
					<!--{/if}-->
				<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
				<ul id="usermanageli_menu" class="p_pop" style="width: 80px; display:none;">
					<!--{if checkperm('allowbanuser')}-->
						<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" target="_blank">{lang user_ban}</a></li>
					<!--{/if}-->
					<!--{if checkperm('allowedituser')}-->
						<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" target="_blank">{lang user_edit}</a></li>
					<!--{/if}-->
				</ul>
				<!--{/if}-->
				<!--{if $_G['adminid'] == 1}-->
					<ul id="umanageli_menu" class="p_pop" style="width: 80px; display:none;">
						<li><a href="forum.php?mod=modcp&action=thread&op=post&searchsubmit=1&do=search&users=$encodeusername" target="_blank">{lang manage_post}</a></li>
						<!--{if helper_access::check_module('doing')}-->
							<li><a href="admin.php?action=doing&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_doing}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('blog')}-->
							<li><a href="admin.php?action=blog&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_blog}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('feed')}-->
							<li><a href="admin.php?action=feed&searchsubmit=1&detail=1&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_feed}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('album')}-->
							<li><a href="admin.php?action=album&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_album}</a></li>
							<li><a href="admin.php?action=pic&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_pic}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('wall')}-->
							<li><a href="admin.php?action=comment&searchsubmit=1&detail=1&fromumanage=1&authorid=$space[uid]" target="_blank">{lang manage_comment}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('share')}-->
							<li><a href="admin.php?action=share&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_share}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('group')}-->
							<li><a href="admin.php?action=threads&operation=group&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_threads}</a></li>
							<li><a href="admin.php?action=prune&searchsubmit=1&detail=1&operation=group&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_prune}</a></li>
						<!--{/if}-->
					</ul>
				<!--{/if}-->
			<!--{/if}-->
		</p>
	</div>

	
	
	
	<!--{hook/space_menu_extra}-->
    <div class="deantbnavs">
        <ul class="deantbnavsul" >
        	<!--{if helper_access::check_module('follow')}-->
            <li{if CURMODULE == 'follow'} class="a"{/if}><a href="home.php?mod=follow&uid=$space[uid]&do=view&from=space">{lang follow}</a></li>
            <!--{/if}-->
            <li{if $do=='thread'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space">{lang topic}</a></li>
            <!--{if helper_access::check_module('blog')}-->
            <li{if $do=='blog'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space">{lang blog}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('album')}-->
            <li{if $do=='album'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space">{lang album}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('doing')}-->
            <li{if $do=='doing'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space">{lang doing}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('home')}-->
            <li{if $do=='home'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=home&view=me&from=space">{lang feed}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('share')}-->
            <li{if $do=='share'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space">{lang share}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('wall')}-->
            <li{if $do==wall} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=wall&from=space">{lang message}</a></li>
            <!--{/if}-->
            <li{if $do==profile} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=profile&from=space">{lang memcp_profile}</a></li>
            <div class="clear"></div>
        </ul>
    </div>
</div>
<!--{/if}-->
