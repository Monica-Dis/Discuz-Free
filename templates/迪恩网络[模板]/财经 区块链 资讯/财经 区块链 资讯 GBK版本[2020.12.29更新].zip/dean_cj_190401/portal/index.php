<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.SuperSlide.2.1.1.js"></script>
<script src="$_G['style'][styleimgdir]/js/page.js" type="text/javascript"></script>
<!--�Ƽ�ģ��-->
<div class="deantjweb"><!--[diy=deantjweb]--><div id="deantjweb" class="area"></div><!--[/diy]--><div class="clear"></div></div>
<div class="clear"></div>

<div class="deanpart">
	<div class="deanpartleft">
    	<div class="deanparthdp">
        	<div class="deanhdop"><!--[diy=deanhdop]--><div id="deanhdop" class="area"></div><!--[/diy]-->
				<script type="text/javascript">
                    jq(".deanhdop").slide({ mainCell:".bd ul", effect:"fold", autoPlay:true, delayTime:600, triggerTime:50});  
                </script>
            </div>
            <div class="deanparthdpr"><ul><!--[diy=deanparthdpr]--><div id="deanparthdpr" class="area"></div><!--[/diy]--></ul></div>
            <div class="clear"></div>
        </div>
    	<div class="deanadleft"><!--[diy=deanadleft]--><div id="deanadleft" class="area"></div><!--[/diy]--></div>
        <div class="clear"></div>
        
        <div class="deantabnew">
        	<div class="deantabname">
            	<ul>
                	<li class="cur">ͷ��</li>
                    <li>�Ƽ���</li>
                    <li>����</li>
                    <li>����</li>
                    <li>����</li>
                    <li>���</li>
                    <li>����</li>
                    <li>������</li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="clear"></div>
            <div class="deantabc">
            	<ul>
                	<li style="display:block;"><!--[diy=deantabc1]--><div id="deantabc1" class="area"></div><!--[/diy]--></li>
                    <li><!--[diy=deantabc2]--><div id="deantabc2" class="area"></div><!--[/diy]--></li>
                    <li><!--[diy=deantabc3]--><div id="deantabc3" class="area"></div><!--[/diy]--></li>
                    <li><!--[diy=deantabc4]--><div id="deantabc4" class="area"></div><!--[/diy]--></li>
                    <li><!--[diy=deantabc5]--><div id="deantabc5" class="area"></div><!--[/diy]--></li>
                    <li><!--[diy=deantabc6]--><div id="deantabc6" class="area"></div><!--[/diy]--></li>
                    <li><!--[diy=deantabc7]--><div id="deantabc7" class="area"></div><!--[/diy]--></li>
                    <li><!--[diy=deantabc8]--><div id="deantabc8" class="area"></div><!--[/diy]--></li>
                </ul>
            </div>
            <script type="text/javascript">
            	jQuery(".deantabname ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("cur").siblings().removeClass("cur");
						jQuery(".deantabc ul li").eq(s).show().siblings().hide();
						})
					})
            </script>
        </div>
    </div>
    <div class="deanpartright">
        <div class="deanhours7">
        	<div class="deantits"><span>7x24H ��Ѷ</span><a href="http://t.cn/Aiux1Qh0" target="_blank" class="deanarr"></a><div class="clear"></div></div>
        	<div class="clear"></div>
            <div class="deanrightline">
        		<ul><!--[diy=deanhours7]--><div id="deanhours7" class="area"></div><!--[/diy]--></ul>
            </div>
        	<div class="clear"></div>
        </div>
    	<div class="clear"></div>
		<!--�ƹ�-->
        <div class="swiper-container deanrightshan"><!--[diy=deanrightshan]--><div id="deanrightshan" class="area"></div><!--[/diy]-->
        	<div class="deantits1"><span>�ƹ�</span><div class="clear"></div></div>
            <div class="swiper-wrapper">
				<div class="swiper-slide">
                	<ul class="deantuiguang">
                    	<li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/1.jpg" /></div>
                                <div class="deangginfo">
                                    <h5>Baer Chain</h5><p>ȫ����Ϸ����������</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/2.jpg" /></div>
                                <div class="deangginfo">
                                    <h5>SoPay��SOP��</h5><p>֧�����ڿ�0������, 1�뵽��.</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/3.png" /></div>
                                <div class="deangginfo">
                                    <h5>IX������</h5><p>��BTC�Ϸ�ƽ̨����30%</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/4.png" /></div>
                                <div class="deangginfo">
                                    <h5>COOCѧ����</h5><p>�ý������м�ֵ</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/5.png" /></div>
                                <div class="deangginfo">
                                    <h5>BitAsset������</h5><p>��ƽ��רҵ����ȫ���Ѻ�</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li class="deanlasstli">
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/6.png" /></div>
                                <div class="deangginfo">
                                    <h5>BitForex�ҷ�����</h5><p>�����ڿ󣬻𱬿���</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="swiper-slide">
                	<ul class="deantuiguang">
                    	<li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/7.png" /></div>
                                <div class="deangginfo">
                                    <h5>Proton������/h5><p>��������Эͬ����</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/8.png" /></div>
                                <div class="deangginfo">
                                    <h5>SoPay��SOP��</h5><p>֧�����ڿ�0������, 1�뵽��.</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/9.png" /></div>
                                <div class="deangginfo">
                                    <h5>IX������</h5><p>��BTC�Ϸ�ƽ̨����30%</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/10.png" /></div>
                                <div class="deangginfo">
                                    <h5>COOCѧ����</h5><p>�ý������м�ֵ</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/11.jpg" /></div>
                                <div class="deangginfo">
                                    <h5>BitAsset������</h5><p>��ƽ��רҵ����ȫ���Ѻ�</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li class="deanlasstli">
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/12.jpg" /></div>
                                <div class="deangginfo">
                                    <h5>BitForex�ҷ�����</h5><p>�����ڿ󣬻𱬿���</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="swiper-slide">
                	<ul class="deantuiguang">
                    	<li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/13.jpg" /></div>
                                <div class="deangginfo">
                                    <h5>Baer Chain</h5><p>ȫ����Ϸ����������</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/14.png" /></div>
                                <div class="deangginfo">
                                    <h5>SoPay��SOP��</h5><p>֧�����ڿ�0������, 1�뵽��.</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        <li>
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <div class="deanggimg"><img src="./template/dean_cj_190401/deancss/b/15.png" /></div>
                                <div class="deangginfo">
                                    <h5>IX������</h5><p>��BTC�Ϸ�ƽ̨����30%</p>
                                </div>
                                <div class="clear"></div>
                            </a>
                        </li>
                        
                    </ul>
                </div>
			</div>

        	<!-- �����Ҫ��ҳ�� -->
        	<div class="swiper-pagination"></div>  
        	<!-- �����Ҫ������ť -->
        	<!--<div class="swiper-button-prev"></div>
        	<div class="swiper-button-next"></div>-->
        	<!-- �����Ҫ������ -->
        	<!--<div class="swiper-scrollbar"></div>-->
        </div>
        <div class="clear"></div>

        <!--����ר��-->
        <div class="deanhotzt">
        	<div class="deantits"><span>����ר��</span><a href="http://t.cn/Aiux1Qh0" target="_blank" class="deanarr"></a><div class="clear"></div></div>
        	<div class="clear"></div>
        	<ul><!--[diy=deanhotzt]--><div id="deanhotzt" class="area"></div><!--[/diy]--></ul>
        </div>
        <script type="text/javascript">
        	jQuery(".deanhotzt ul li:last").css("border-bottom","0");
			jQuery(".deanhotzt ul li:last").css("padding-bottom","0");
        </script>
        <div class="clear"></div>
        
        <!--��Ծ����-->
        <div class="deanzjia">
        	<div class="deantits"><span>��Ծ����</span><div class="clear"></div></div>
        	<div class="clear"></div>
        	<ul><!--[diy=deanzjia]--><div id="deanzjia" class="area"></div><!--[/diy]--></ul>
        </div>
        <div class="clear"></div>
        <!--������Ƶ-->
        
        <div class="deanhotsp">
        	<div class="deantits"><span>������Ƶ</span><a href="http://t.cn/Aiux1Qh0" target="_blank" class="deanarr"></a><div class="clear"></div></div>
        	<div class="clear"></div>
            <ul><!--[diy=deanhotsp]--><div id="deanhotsp" class="area"></div><!--[/diy]--></ul>
        </div>
        <div class="clear"></div>
        <style type="text/css">
        	
        </style>
        <!--���а�-->
        <div class="deanphb">
        	<div class="deanphbname">
            	<span>���а�</span>
                <ul>
                	<li class="cur">������</li>
                    <li>������</li>
                    <li>������</li>
                    <div class="clear"></div>
                </ul>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            <div class="deanphbc">
            	<div class="deanlanmu">
                	<span>����</span>
                    <b>���±���</b>
                    <em>�鿴</em>
                    <div class="clear"></div>
                </div>
            	<ul>
                	<li style="display:block;"><dl><!--[diy=deanphbc]--><div id="deanphbc" class="area"></div><!--[/diy]--></dl></li>
                    <li><dl><!--[diy=deanphbc1]--><div id="deanphbc1" class="area"></div><!--[/diy]--></dl></li>
                    <li><dl><!--[diy=deanphbc2]--><div id="deanphbc2" class="area"></div><!--[/diy]--></dl></li>
                </ul>
            </div>
            <script type="text/javascript">
            	jQuery(".deanphbname ul li").each(function(s){
					jQuery(this).hover(function(){
						jQuery(this).addClass("cur").siblings().removeClass("cur");
						jQuery(".deanphbc ul li").eq(s).show().siblings().hide();
						})
					})
            </script>
        </div>
        <div class="clear"></div>
        <!--���ű�ǩ-->
       
        <div class="deantags">
        	<div class="deantits"><span>���ű�ǩ</span><div class="clear"></div></div>
        	<div class="clear"></div>
            <div class="deantagsc"><!--[diy=deantagsc]--><div id="deantagsc" class="area"></div><!--[/diy]--><div class="clear"></div></div>
        </div>
        
    </div>
    <div class="clear"></div>
</div>

<div class="clear"></div>

<div class="deanbox">
	<div class="deanboxl">
    	<div class="deanht2"><span>����</span><a href="http://t.cn/Aiux1Qh0" target="_blank">����<i class="icon-angle-right"></i></a><div class="clear"></div></div>
        <div class="clear"></div>
        <div class="deanboxf">
        	<div class="deanboxfc">
            	<!--[diy=deanboxfc]--><div id="deanboxfc" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
                <dl>
                	<!--[diy=deanboxfcdl]--><div id="deanboxfcdl" class="area"></div><!--[/diy]-->
                </dl>
            </div>
        </div>
        <div class="deanboxf">
        	<div class="deanboxfc">
            	<!--[diy=deanboxfc1]--><div id="deanboxfc1" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
                <dl>
                	<!--[diy=deanboxfcdl1]--><div id="deanboxfcdl1" class="area"></div><!--[/diy]-->
                </dl>
            </div>
        </div>
        <div class="deanboxf" style="margin-right:0;">
        	<div class="deanboxfc">
            	<!--[diy=deanboxfc2]--><div id="deanboxfc2" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
                <dl>
                	<!--[diy=deanboxfcdl2]--><div id="deanboxfcdl2" class="area"></div><!--[/diy]-->
                </dl>
            </div>
        </div>
        <div class="deanboxf">
        	<div class="deanboxfc">
            	<!--[diy=deanboxfc3]--><div id="deanboxfc3" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
                <dl>
                	<!--[diy=deanboxfcdl3]--><div id="deanboxfcdl3" class="area"></div><!--[/diy]-->
                </dl>
            </div>
        </div>
        <div class="deanboxf">
        	<div class="deanboxfc">
            	<!--[diy=deanboxfc4]--><div id="deanboxfc4" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
                <dl>
                	<!--[diy=deanboxfcdl4]--><div id="deanboxfcdl4" class="area"></div><!--[/diy]-->
                </dl>
            </div>
        </div>
        <div class="deanboxf" style="margin-right:0;">
        	<div class="deanboxfc">
            	<!--[diy=deanboxfc5]--><div id="deanboxfc5" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
                <dl>
                	<!--[diy=deanboxfcdl5]--><div id="deanboxfcdl5" class="area"></div><!--[/diy]-->
                </dl>
            </div>
        </div>
        <div class="clear"></div>
    </div>
    <div class="deanboxr">
    	<div class="deanht2"><span>����</span><a href="http://t.cn/Aiux1Qh0" target="_blank">����<i class="icon-angle-right"></i></a><div class="clear"></div></div>
        <div class="clear"></div>
        <div class="deanboxrc">
        	<ul><!--[diy=deanboxrc]--><div id="deanboxrc" class="area"></div><!--[/diy]--></ul>
        </div>
        <script type="text/javascript">
        	jq(".deanboxrc ul li:last").css("border-bottom","0");
        </script>
    </div>
    <div class="clear"></div>
</div>

<div class="clear"></div>

<!--��������-->
<div class="deanlinkst">
    <div class="deanlinkc">
        <div class="deantjtit">
            <i class="fa fa-paper-plane-o"></i>
            <span>�ٷ�����</span>
            <em>������������ QQ:3318850993</em>
            <div class="clear"></div>
        </div>
        <div class="clear"></div>
        <ul><!--[diy=deanlink]--><div id="deanlink" class="area"></div><!--[/diy]-->
            <div class="clear"></div>
        </ul>
        <script type="text/javascript">
            jq(".deanlinkst ul li").eq(0).addClass("deanlinkli1");
        </script>
    </div>
</div>





<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

