<?php echo '请支持迪恩网络正版';exit;?>
<!--{subtemplate common/header_common}-->
<link href="$_G['style'][styleimgdir]/js/main.css" type="text/css" rel="stylesheet" />
    <link href="$_G['style'][styleimgdir]/js/a.css" type="text/css" rel="stylesheet" />
    <link href="$_G['style'][styleimgdir]/font-awesome.min.css" type="text/css" rel="stylesheet" />
    <script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery-1.8.3.min.js"></script>
    <script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.bxslider.js"></script>   
	<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.flexslider-min.js"></script> 
    <script type="text/javascript" src="$_G['style'][styleimgdir]/js/jPages.min.js"></script>
    <script src="$_G['style'][styleimgdir]/js/jquery.lazyload.js"></script>
    <script type="text/javascript" src="$_G['style'][styleimgdir]/js/wow.min.js"></script>
    <script type="text/javascript">
        var jq=jQuery.noConflict();
    </script>
    <script type="text/javascript" src="$_G['style'][styleimgdir]/js/kefu.js"></script>
    <script src="$_G['style'][styleimgdir]/js/wow.min.js"></script>
    <script>new WOW().init();</script>
     
    <script language="javascript" type="text/javascript">
        function killErrors() {
            return true;
        }
        window.onerror = killErrors;
    </script>
</head>
<style type="text/css">
#toptb{ background:#fafafa!important; border-bottom:1px solid #f0f0f0!important;}
#toptb .z a{ padding-right:15px!important;}
body#nv_search{ background:#fff!important;}
.mw,#ct{width:1180px; margin:0 auto; }
.sttl{ width:1180px; margin:0 auto; padding:10px 0; border-bottom:1px solid #f0f0f0; font-size:16px; font-weight:normal; background:#fefefe;}
	.sttl h2{ font-weight:normal;}
		.sttl h2 i{ padding-right:5px; color:#f60;}
.slst{ width:100%;}

/*左侧文章列表*/
.deanpiclist{}
	.deanpiclist ul{ margin-top:15px;}
		.deanpiclist ul li{}
			
			
.deanpiclist{ width:1180px; margin:0 auto;}
	.deanpiclist ul{}
		.deanpiclist ul li{ height:130px; background:#fff; margin-bottom:12px; padding-bottom:12px; border-bottom:1px solid #e6e6e6; }
			.deanpiclic{  }
				.deansearchimg{ width:210px; height:130px; overflow:hidden; float:left; position:relative; z-index:1;transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s; margin-right:15px;}
				.deansearchimg:hover{ transform: scale(1.1); -moz-transform: scale(1.1); -webkit-transform: scale(1.1); -o-transform: scale(1.1); -ms-transform: scale(1.1);}
					
				.deanpiclicr{ width:795px; height:130px; float:left; position:relative; }
					.deanpiclicr h2{ font-size:18px; font-weight:500; width:575px; height:25px; overflow:hidden; text-overflow: ellipsis;}
						.deanpiclicr h2 a{ color:#333; transition: all 0.3s; -moz-transition: all 0.3s; -webkit-transition: all 0.3s; -o-transition: all 0.3s;  }
						.deanpiclicr h2 a:hover{ color:#4593FF; text-decoration:none; }
					.deanpicsummary{ color: #999; font-size: 12px;  overflow: hidden; font-weight:normal; margin-bottom: 5px; height: 46px; line-height: 23px; margin-top:10px;}
					
.deantit{ margin-bottom:20px;}
	
	.deannewtwonum{ height:25px; line-height:25px; font-size:12px; position:absolute; left:0; bottom:15px; color:#aaa;}
		.deanartavar{ float:left;}
			.deanartavar img{ float:left; width:25px; height:25px; border-radius:25px;}
			.deanartavar i{ float:left;}
		.deannewtwonum a{color:#aaa; float:left;}
		.deannewtwonum span{ float:left; display:block; margin-left:10px;  }
		.deannewtwonum em{ float:left; display:block; margin-left:10px; }
		.deannewtwonum b{ float:left; display:block; font-weight:normal; height:20px; margin-left:10px;}
		.deannewtwonum i.deanpipe{ width:1px; height:12px; margin-left:10px; margin-top:7px; display:inline-block; float:left; border-right:1px solid #e6e6e6;}	
		.deannewsubnavs{ height:30px; line-height:30px; margin-bottom:20px;}
			.deannewsubnavs span{ display:inline-block; float:left; font-size:16px; font-weight:bold; color:#333; margin-right:10px;}
			.deannewsubnavs ul{ float:left;}
				.deannewsubnavs ul li{ height:30px; margin-right:10px; float:left;}
					.deannewsubnavs ul li a{ display:inline-block; padding:0 10px; color:#4593FF; font-size:12px; height:26px; line-height:26px; border:2px solid #4593FF; border-radius:20px;}
					.deannewsubnavs ul li a:hover{ background:#4593FF; color:#fff;}		
			.slst a{ text-decoration:none;}
#toptb a{ color:#999;}
</style> 
<body id="nv_search" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<div id="toptb" class="cl">
		<div class="z">
			<a href="./" id="navs" class="showmenu xi2" onMouseOver="showMenu(this.id)">{lang return_homepage}</a>
		</div>
		<div class="y">
			<!--{if $_G['uid']}-->
				<strong><a href="home.php?mod=space" target="_blank" title="{lang visit_my_space}">{$_G[member][username]}</a></strong>
				<a href="javascript:;" id="myspace" class="showmenu xi2" onMouseOver="showMenu(this.id);">{lang my_nav}</a>
				<!--{hook/global_usernav_extra1}-->
				<a href="home.php?mod=spacecp">{lang setup}</a>
				<!--{if $_G['uid'] && ($_G['group']['radminid'] == 1 || getstatus($_G['member']['allowadmincp'], 1))}--><a href="admin.php" target="_blank">{lang admincp}</a><!--{/if}-->
				<!--{hook/global_usernav_extra2}-->
				<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
			<!--{elseif !empty($_G['cookie']['loginuser'])}-->
				<strong><a id="loginuser"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
				<a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang activation}</a>
				<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
			<!--{else}-->
				<a href="member.php?mod={$_G[setting][regname]}">$_G['setting']['reglinkname']</a>
				<a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang login}</a>
			<!--{/if}-->
		</div>
	</div>
	<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
		<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
		<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
		     <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
		     <li>$module[url]</li>
		     <!--{/if}-->
		<!--{/loop}-->
		</ul>
	<!--{/if}-->
	$_G[setting][menunavs]

	<!--{if $_G['setting']['navs']}-->
		<ul class="p_pop h_pop" id="navs_menu" style="display: none">
		<!--{loop $_G['setting']['navs'] $nav}-->
			<!--{eval $nav_showmenu = strpos($nav['nav'], 'onmouseover="showMenu(');}-->
		    <!--{eval $nav_navshow = strpos($nav['nav'], 'onmouseover="navShow(')}-->
		    <!--{if $nav_hidden !== false || $nav_navshow !== false}-->
			<!--{eval $nav['nav'] = preg_replace("/onmouseover\=\"(.*?)\"/i", '',$nav['nav'])}-->
		    <!--{/if}-->
			<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li $nav[nav]></li><!--{/if}-->
		<!--{/loop}-->
		</ul>
	<!--{/if}-->

	<ul id="myspace_menu" class="p_pop" style="display:none;">
		<!--{loop $_G['setting']['mynavs'] $nav}-->
			<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->
				<li>$nav[code]</li>
			<!--{/if}-->
		<!--{/loop}-->
	</ul>