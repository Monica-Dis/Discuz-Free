<?php echo '��֧�ֵ϶���������';exit;?>
<div class="tl">
	<div class="sttl mbn">
		<h2><i class="icon-star"></i><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page" target="_blank">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($threadlist)}-->
		<p class="emp xs2 xg2">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="slst mtw" id="threadlist" {if $modfid} style="position: relative;"{/if}>
			<!--{if $modfid}-->
			<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$modfid&infloat=yes&nopost=yes">
			<!--{/if}-->
            
            <div class="deanpiclist">
            	<ul class="cl">
                	<!--{loop $threadlist $thread}-->
                    
                  <li>
                    <div class="deanpiclic">
                        <!--{eval include 'template/dean_lcpt_190101/php/innerpics.php'}-->
                        <!--{loop $dnpicfm $deanptp}-->
                        <a href="forum.php?mod=viewthread&tid=$thread[realtid]" target="_blank" class="deansearchimg"><img src="data/attachment/forum/$deanptp[attachment]" width="210"  ></a>
                        <!--{/loop}-->
                       
                  		<div class="deanpiclicr">
                            <h2 style="font-weight:normal;"><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank" $thread[highlight]>$thread[subject]</a></h2>
                            <div class="clear"></div>
                            <div class="deanpicsummary">
                                <!--{eval include 'template/dean_lcpt_190101/php/summary.php'}-->
                                <!--{echo cutstr($deansummary_echo,200)}-->
                            </div>
							<div class="clear"></div>
                            <div class="deannewtwonum">
                                <div class="deanartavar">
                                    <a href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread[authorid],middle)}--></a>
                                    <span>����:$thread[author]</span>
                                    <div class="clear"></div>
                                </div>
                                <i class="deanpipe"></i>
                                <b>ʱ�䣺$thread[dateline]</b>
                                <i class="deanpipe"></i>
                                <span>�Ķ�$thread[views]</span>
                                <i class="deanpipe"></i>
                                <em>�ظ���$thread[replies]</em>
                                <div class="clear"></div>
                            </div>
                            
                            <div class="clear"></div>
                        </div>                           
                        <div class="clear"></div>
                    </div>
                </li>
                    
                    
                    
                    <!--{/loop}-->
                  <div class="clear"></div>
                </ul>
            </div>
			
		<!--{if $modfid}-->
			</form>
			<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
			<!--{template forum/topicadmin_modlayer}-->
		<!--{/if}-->
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>