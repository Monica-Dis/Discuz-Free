<?php


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

function build_cache_mumucms_app(){ 
		global $installlang;
	    $data = array();
	    $data['app_qiyong'] = '1';
	    $data['app_guidexs'] = '1';
	    $data['app_forumdisplayxs'] = '1';
	    $data['app_viewthreadxs'] = '1';
	    $data['app_downkz'] =  '1';		    
	    $data['app_downtext'] = $installlang['app_downtext_install'];
	    $data['app_android'] = '#';	    
	    $data['app_ios'] = '#';
	    $data['app_ico'] = $installlang['app_ico_install'];
	    $data['app_name'] = $installlang['app_name_install'];
	    $data['app_sum'] = $installlang['app_sum_install'];		    		    		    
	    save_syscache('mumucms_app', $data);
	};
	updatecache('mumucms_app');

	function build_cache_mumucms_startup(){ 
		global $installlang;
	    $data = array();
	    $data['startup_qiyong'] = '1';
	    $data['startup_guoqi'] = '60';
	    $data['startup_guanbi'] = '5';
	    $data['startup_text'] = $installlang['startup_text_install'];
	    $data['startup_shengxiao'] = '0';
	    $data['startup_imgadr'] = 'template/mumucms_waptheme/img/mumucms_startup.png';
	    $data['startup_imglink'] = '#';	    
	    $data['startup_imglogo'] = 'template/mumucms_waptheme/img/mumucms_startup_logo.png';
	    $data['startup_logotext'] = 'Copyright &copy; 2019 Mumucms.Com All Rights Reserved.';
	    save_syscache('mumucms_startup', $data);
	}
	updatecache('mumucms_startup');

$finish = TRUE;

?>