<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$mumucms_donate_mingcheng = $_G['cache']['plugin']['mumucms_donate']['mumucms_donate_mingcheng'];
$mumucms_donate_zfbpic = $_G['cache']['plugin']['mumucms_donate']['mumucms_donate_zfbpic'];
$mumucms_donate_zfbname = $_G['cache']['plugin']['mumucms_donate']['mumucms_donate_zfbname'];
$mumucms_donate_zfbtext = $_G['cache']['plugin']['mumucms_donate']['mumucms_donate_zfbtext'];
$mumucms_donate_weixinpic = $_G['cache']['plugin']['mumucms_donate']['mumucms_donate_weixinpic'];
$mumucms_donate_weixinname = $_G['cache']['plugin']['mumucms_donate']['mumucms_donate_weixinname'];
$mumucms_donate_weixintext = $_G['cache']['plugin']['mumucms_donate']['mumucms_donate_weixintext'];

include template("mumucms_wapcontrol:mumucms_wapcontrol_app");

?>