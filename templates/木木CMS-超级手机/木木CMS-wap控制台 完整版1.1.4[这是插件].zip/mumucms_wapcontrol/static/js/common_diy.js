var JSLOADED = [];
var Diy = {
	isChange : false,
	tmpBoxElement: null,
	ItemObj : null,
	blocks : [],
	data : [],
	spacecss : [],
	
	/*�л�����ѡ������ı�DIYģʽ*/
	features : function (type) {
		$('#nav_'+type).addClass('curr').siblings().removeClass('curr');
		$('#content'+type).show().siblings().hide();
		this.resize();
		drop.destroy();
		$('div.frame, div.block').unbind('touchstart').css({'position':'static', 'height':'auto'});
		try {
			$('#'+this.ItemObj).draggable("destroy");
			$('.ui-draggable').draggable("destroy");
		}catch (ext) {
			console.log('Percentage:', ext);
		}
		this.ItemObj = null;
		$('body').removeClass('typeframe').removeClass('typeblock');
		$('.frame .frame-name .edit, .block .block-name .edit').remove();
		$('.frame .edit-menu').remove();
		
		if(type == 'blockclass'){
			if(!$('#content'+type).html()){
			    $('#content'+type).html('<p class="minload"><img src="source/plugin/mogu_app/static/images/load.gif"></p>');
			    this.getdiy(type);
			}
			$('body').addClass('typeblock');
			drop.init($('div.frame .column'),'block');
			$('div.column > .block').addClass('drop').removeClass('out');
			this.bindObj('block');
		}else if(type == 'frame'){
			$('body').addClass('typeframe');
			drop.init($('div.area'),type);
			$('div.area > .frame').addClass('drop').removeClass('out');
			this.bindObj('frame');
		}
	},
	
	/*��ȡ����ַ���*/
	getRandom : function (len,type) {
		len = len < 0 ? 0 : len;
		type = type && type<=3? type : 3;
		var str = '';
		for (var i = 0; i < len; i++) {
			var j = Math.ceil(Math.random()*type);
			if (j == 1) {
				str += Math.ceil(Math.random()*9);
			} else if (j == 2) {
				str += String.fromCharCode(Math.ceil(Math.random()*25+65));
			} else {
				str += String.fromCharCode(Math.ceil(Math.random()*25+97));
			}
		}
		return str;
	},
	
	/*�ر�*/
	cancel : function () {
		if (!confirm('\u4f60\u786e\u5b9a\u8981\u79bb\u5f00\uff1f')){
			return false;
		}else{
			location.href = location.href.replace(/[\?|\&]diy\=yes/g,'');
		}
	},
	
	/*����*/
	save : function (optype,rejs) {
		drop.destroy();
		$('div.frame, div.block').css({'position':'static'});
		try {
			$('#'+this.ItemObj).draggable("destroy");
		}catch (ext) {}
		$('.frame .edit').remove();
		$('.frame .edit-menu').remove();
		
		optype = typeof optype == 'undefined' ? '' : optype;
		var tplpre = document.diyform.template.value.split(':');
		document.diyform.action = document.diyform.action.replace(/[&|\?]inajax=1/, '');
		document.diyform.optype.value = optype;
		document.diyform.layoutdata.value = this.getPositionStr();
		
		if (['portal/portal_topic_content', 'portal/list', 'portal/view'].indexOf(tplpre[0]) == -1) {
			/*
			if (document.diyform.template.value.indexOf(':') > -1 && !document.selectsave) {
				var schecked = '',dchecked = '';
				if (document.diyform.savemod.value == '1') {
					dchecked = ' checked';
				} else {
					schecked = ' checked';
				}
				popup.open('<div class="tip savemod"><p class="bbw1" onclick="document.diyform.savemod.value = 0;document.diyform.submit();popup.open(\'<img src=' + IMGDIR + '/imageloading.gif>\');">\u5e94\u7528\u4e8e\u6b64\u7c7b\u5168\u90e8\u9875\u9762</p> <p onclick="document.diyform.savemod.value = 1;document.diyform.submit();popup.open(\'<img src=' + IMGDIR + '/imageloading.gif>\');">\u53ea\u5e94\u7528\u4e8e\u672c\u9875\u9762</p></div');
				return false;
			}else{
				document.diyform.savemod.value = 0;
			}
			*/
			document.diyform.savemod.value = 0;
		}
		document.diyform.submit();
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	},
	
	getPositionStr : function (){
		this.initPosition();
		var start = '<?xml version="1.0" encoding="ISO-8859-1"?><root>';
		var end ="</root>";
		var str = "";
		for (var i in this.data) {
			if (typeof this.data[i] == 'function') continue;
			str += '<item id="' + i + '">';
			for (var j in this.data[i]) {
				if (!(this.data[i][j] instanceof Frame)) continue;
				str += this._getFrameXML(this.data[i][j]);
			}
			str += '</item>';
		}
		return start + str + end;
	},
	
	initPosition : function () {
		var data = [];
		$('div.area').each(function(){
			var areaData = [];
			var area = $(this)[0].id;
			 data[area] = [];
			var frameObj = null;
			$(this).find('> div.frame').each(function(){
				frameObj = new Frame($(this)[0].id, $(this)[0].className, 0, 0, 'move-span');
				Diy._initColumn(frameObj, $(this)[0]);
				areaData.push(frameObj);
			    data[area] = areaData;
			});
		});
		this.data = data;
	},
	
	_initColumn : function (frameObj, frameEle) {
		var columns = $(frameEle).find('.column');
		$(frameEle).find('.column').each(function(i,obj){
			var columnId = $(this)[0].id;
			var column = new Column(columnId, $(this)[0].className);
			frameObj.addColumn(column);
			var elements = $(this).find('> div.block');
			var eleLen = elements.length;
			for (var j = 0; j < eleLen; j++) {
				var ele = elements[j];
				var block = new Block(ele.id, ele.className, 0, 0);
				frameObj.addBlock(columnId, block);
			}
		});
	},
	
	_getFrameXML : function (frame) {
		if (!frame instanceof Frame || frame.name.indexOf('temp') > 0) return '';
		var itemId = 'frame';
		var Cstr = "";
		var name = frame.name;
		var frameAttr = this._getAttrXML(frame);
		var columns = frame['columns'];
		for (var j in columns) {
			if (columns[j] instanceof Column) {
				var Bstr = '';
				var colChildren = columns[j].children;
				for (var k in colChildren) {
					if (k == 'attr' || typeof colChildren[k] == 'function' || colChildren[k].name.indexOf('temp') > 0) continue;
					if (colChildren[k] instanceof Block) {
						Bstr += '<item id="block`' + colChildren[k]['name'] + '">';
						Bstr += this._getAttrXML(colChildren[k]);
						Bstr += '</item>';
					} else if (colChildren[k] instanceof Frame || colChildren[k] instanceof Tab) {
						Bstr += this._getFrameXML(colChildren[k]);
					}
				}
				var columnAttr = this._getAttrXML(columns[j]);
				Cstr += '<item id="column`' + j + '">' + columnAttr + Bstr + '</item>';
			}
		}
		return '<item id="' + itemId + '`' + name + '">' + frameAttr + Cstr + '</item>';
	},
	
	_getAttrXML : function (obj) {
		var attrXml = '<item id="attr">';
		var trimAttr = ['left', 'top'];
		var xml = '';
		if (obj instanceof Frame || obj instanceof Block || obj instanceof Column) {
			for (var i in obj) {
				if (i == 'titles') {
					xml += this._getTitlesXML(obj[i]);
				}
				if (!(typeof obj[i] == 'object' || typeof obj[i] == 'function')) {
					if (trimAttr.indexOf(i) >= 0) continue;
					xml += '<item id="' + i + '"><![CDATA[' + obj[i] + ']]></item>';
				}
			}
		}else {
			xml += '';
		}
		return attrXml + xml + '</item>';
	},
	
	_getTitlesXML : function (titles) {
		var xml = '<item id="titles">';
		for (var i in titles) {
			if (typeof titles[i] == 'function') continue;
			xml += '<item id="'+i+'">';
			for (var j in titles[i]) {
				if (typeof titles[i][j] == 'function') continue;
				xml += '<item id="'+j+'"><![CDATA[' + titles[i][j] + ']]></item>';
			}
			xml += '</item>';
		}
		xml += '</item>';
		return xml;
	},
	
	/*�ı��С*/
	resize : function () {
		var height = $('#controlpanel').height();
		$('body').animate({'padding-top':height+'px'});
	},
	
	/*AJAX����*/
	getdiy : function (type) {
		if (!type) {
			return false;
		}
		var para = '&op='+type;
		var ajaxtarget = type == 'diy' ? 'diyimages' : '';
		$.ajax({
			url: 'portal.php?mod=portalcp&ac=diy'+para+'&inajax=1&ajaxtarget='+ajaxtarget,
			type: "get",
			dataType: "xml",
			success: function(s) {
				if (s.lastChild.firstChild.nodeValue) {
					$('#content'+type).html(s.lastChild.firstChild.nodeValue);
					var evaled = false;
					if(s.lastChild.firstChild.nodeValue.indexOf('ajaxerror') != -1) {
						evalscript(s.lastChild.firstChild.nodeValue);
						evaled = true;
					}
					if(!evaled && (typeof ajaxerror == 'undefined' || !ajaxerror)) {
						if(ajaxtarget) {
							ajaxupdateevents($F(ajaxtarget));
						}
					}
					if(!evaled){
						evalscript(s.lastChild.firstChild.nodeValue);
					}
				}
				Diy.resize();
			}
		});
		
	},
	
	/*��ʼ��*/
	init : function(){
		this.resize();
		$(document).on('click', "a[href]", function(e) {
			var cts = $(this).attr('onclick');
			var href = $(this).attr('href');
			if(!cts && href.indexOf("javascript") < 0){
				return false;
			}
		});
		
	},
	
	/*���ɿ��ģ��*/
	getFrameHtml : function (type) {
		var id = 'frame'+this.getRandom(6);
		var className = ['frame','move-span'].join(' ');
		className = className + ' cl frame-' + type;
		var str = '<div id="'+id+'" class="'+className+'" style="position: fixed; top:150px;width:100%;">';
		str += '<div class="frame-name">\u6846\u67b6: '+id+' ('+type+')</div>';
		var cols = type.split('-');
		var clsl='',clsc='',clsr='';
		clsl = ' frame-'+type+'-l';
		clsc = ' frame-'+type+'-c';
		clsr = ' frame-'+type+'-r';
		var len = cols.length;
		if (len == 1) {
			str += '<div id="'+id+'_left" class="column'+clsc+'"></div>';
		} else if (len == 2) {
			str += '<div id="'+id+'_left" class="column'+clsl+ '"></div>';
			str += '<div id="'+id+'_center" class="column'+clsr+ '"></div>';
		} else if (len == 3) {
			str += '<div id="'+id+'_left" class="column'+clsl+'"></div>';
			str += '<div id="'+id+'_center" class="column'+clsc+'"></div>';
			str += '<div id="'+id+'_right" class="column'+clsr+'"></div>';
		}
		str += '</div>';
		return str;
	},
	
	getBlockHtml : function (type) {
		var id = 'block'+this.getRandom(6);
		var str = '<div id="'+id+'" class="block move-span new" data-type="'+type+'" style="position: fixed; top:150px;width:100%;"><div class="block-name">\u6a21\u5757: '+id+' (\u65b0\u6dfb\u52a0)</div></div>';
		return str;
	},
	
	/*����tmpbox���*/
	getTmpBoxElement : function () {
		  if  (!this.tmpBoxElement) {
			  this.tmpBoxElement = document.createElement("div");
			  this.tmpBoxElement.id = 'tmpbox';
			  this.tmpBoxElement.className = "tmpbox" ;
		  }
		  return this.tmpBoxElement;
	  },
	
	/*����ģ��*/
	createBlock : function (e,contentType) {
		if($('.area > .frame .column').length < 1){
			alert("\u63d0\u793a\uff1a\u672a\u627e\u5230\u6846\u67b6\uff0c\u8bf7\u5148\u6dfb\u52a0\u6846\u67b6");
			this.features('frame');
			return false;
		}
		html =  this.getBlockHtml(contentType);
		$('body').append(html);
		this.bindObj('block');
		this.SelectObj('block', $(html));
	},
	
	/*���ӿ��*/
	createFrame : function (e,contentType) {
		this.checkDiyItem($('div.area'));
		var html = '';
		html =  this.getFrameHtml(contentType);
		$('body').append(html);
		//if (!this.getTmpBoxElement()) return false;
		this.bindObj('frame');
		this.SelectObj('frame', $(html));
	},
	
	checkDiyItem : function (obj) {
		if(obj.length < 1){
			alert("\u6b64\u9875\u9762\u6ca1\u6709\u5b9a\u4e49\u0044\u0049\u0059\u6807\u8bb0");
			return false;
		}
	},
	
	/*��Ԫ���¼�*/
	bindObj : function(type){
		$('div.'+type).on('touchstart', function(e) {
			e = mygetnativeevent(e);
			height = $(this).height();
			$(this).css({'top':e.touches[0].clientY - (height/2)+'px'});
			Diy.SelectObj(type,$(this));
		}).css({'position':'fixed'});
	},
	
	/*ѡ��Ԫ��*/
	SelectObj : function(type, obj){
		id = $(obj)[0].id;
		if(id == this.ItemObj){
			return false;
		}
		try {
			$('#'+this.ItemObj+' > .edit-menu').remove();
			$('#'+this.ItemObj+' .edit').remove();
			$('.ui-draggable').draggable("destroy");
		}catch (ext) {}
		
		if(!$('#'+id+' > .'+type+'-name')[0]){
			$('#'+id).prepend('<div class="'+type+'-name">'+id+'</div>');
		}
		if($('#'+id).is('.drop')){
		    $('#'+id+' > .'+type+'-name').prepend('<a class="edit" onclick="Diy.MenuObj(\''+id+'\',\''+type+'\')"><i data-id="&#xe037;"></i></a>');
		}
		$('#'+id).draggable({
			connectToSortable: ".ui-sortable",
			scroll: false,
			opacity: 0.65,
			zIndex: 1000,
			drag: function( event, ui ) {
				$(this).css({'width':+$(this).parent().width()+'px'});
			}
		});
		this.ItemObj = id;
	},
	
	/*ģ���л�*/
	switchBlockclass : function (obj,type) {
		$(obj).addClass('a').siblings().removeClass('a');
		$('#contentblockclass_'+type).show().siblings().hide();
		Diy.resize();
	},
	
	/*��ȡģ������*/
	getBlockData : function (bid, blockname) {
		var eleid = bid;
		if (bid.indexOf('portal_block_') != -1) {
			eleid = 0;
		}else {
			bid = 0;
		}
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
		$.ajax({
			type : 'GET',
			url : 'portal.php?mod=portalcp&ac=block&op=block&classname='+blockname+'&bid='+bid+'&eleid='+eleid+'&tpl='+document.diyform.template.value+'&inajax=1',
			dataType : 'xml'
		}).success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		});
		
		return true;
	},
	
	/*ajax����*/
	AjaxGet : function (obj) {
		var obj = $(obj);
		event.preventDefault();
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
		$.ajax({
			type : 'GET',
			url : SITEURL+obj.attr('href') + '&inajax=1',
			dataType : 'xml'
		}).success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		});
		return false;
	},
	
	showTip : function (obj) {
		alert($(obj).data('tip'));
	},
	
	MenuObj : function (id, type) {
		var lihtml = '<li class="mitem" onclick="Diy.EditObj(\''+id+'\', \'delete\')">\u5220\u9664</li>';
		if(type == 'block'){
			lihtml += '<li class="mitem" onclick="Diy.EditObj(\''+id+'\', \'edit\')">\u5c5e\u6027</li>';
			lihtml += '<li class="mitem" onclick="Diy.EditObj(\''+id+'\', \'data\')">\u6570\u636e</li>';
		    lihtml += '<li class="mitem" onclick="Diy.EditObj(\''+id+'\', \'update\')">\u66f4\u65b0</li>';
		}
		
		if(!$('#'+id+' > #edit_menu')[0]){
			$('#'+id).append('<div id="edit_menu" class="edit-menu"></div>');
		}
		$('#'+id+' > #edit_menu').html('<ul>'+lihtml+'</ul>');
	},
	
	blockForceUpdate : function (id, all){
		var bid = id.replace('portal_block_','');
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
		$.ajax({
			type : 'GET',
			url : 'portal.php?mod=portalcp&ac=block&op=getblock&forceupdate=1&inajax=1&bid='+bid+'&tpl='+document.diyform.template.value,
			dataType : 'xml'
		}).success(function(s) {
			html = s.lastChild.firstChild.nodeValue;
			if(html.indexOf('errorhandle_') != -1) {
				popup.open('\u62b1\u6b49\uff0c\u60a8\u6ca1\u6709\u6743\u9650\u6dfb\u52a0\u6216\u7f16\u8f91\u6a21\u5757', 'alert');
				return false;
			} else {
				$('#'+id).prop("outerHTML", html);
				$('#'+id).addClass('drop').removeClass('out');
				if(html.indexOf('runslideshow();') > 0) {
					runslideshow();
				}
				evalscript(html);
				if (all) {
					Diy.getBlocks();
					return false;
				}
				Diy.bindObj('block');
				Diy.ItemObj = null;
				Diy.SelectObj('block', $('#'+id));
				Common.tips('\u66f4\u65b0\u5b8c\u6210');
			}
		});
	},
	
	blockForceUpdateBatch : function (){
		$('div.column > div.block').each(function(){
			Diy.blocks.push($(this)[0].id)
		});
		this.getBlocks();
	},
	
	getBlocks : function () {
		if (this.blocks.length == 0) {
			Common.tips('\u66f4\u65b0\u5b8c\u6210');
			return false;
		}
		this.blockForceUpdate(this.blocks.pop(), true);
	},
	
	EditObj : function (id, type) {
		var bid = id.replace('portal_block_','');
		$('#'+id+' > .edit-menu').remove();
		if(type == 'delete'){
			if(confirm('\u786e\u5b9a\u8981\u5220\u9664\uff1f')){
				$('#'+id).remove();
			}
		}else if(type == 'edit' || type == 'data'){
			if (id.indexOf('portal_block_') < 0) {
				 this.getBlockData(id, $('#'+id).data('type'));
				 return false;
			}
			var op = type == 'edit' ? 'block' : 'data';
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
			$.ajax({
				type : 'GET',
				url : 'portal.php?mod=portalcp&ac=block&op='+op+'&bid='+bid+'&inajax=1&tpl='+document.diyform.template.value,
				dataType : 'xml'
			}).success(function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
				evalscript(s.lastChild.firstChild.nodeValue);
			});
		}else if(type == 'update'){
			if (id.indexOf('portal_block_') < 0) {
				this.getBlockData(id, $('#'+id).data('type'));
				return false;
			}
			this.blockForceUpdate(id);
		}
	},
	
	clearAll : function () {
		if (!confirm('\u4f60\u786e\u5b9a\u8981\u6e05\u7a7a\u6240\u6709\u6a21\u5757\uff1f')){
			return false;
		}else{
			$('div.area').empty();
		}
	},
	
	openFrameImport : function (type) {
		this.checkDiyItem($('div.area'));
		var type = type || 1;
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
		$.ajax({
			type : 'GET',
			url : 'plugin.php?id=mogu_app:diy&op=import&tpl='+document.diyform.template.value+'&tpldirectory='+document.diyform.tpldirectory.value+'&diysign='+document.diyform.diysign.value+'&type='+type+'&inajax=1',
			dataType : 'xml'
		}).success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		});
	},
	
	event: function(event){
		var e = event || window.event;
		e.aim = e.target || e.srcElement;
		if (!e.preventDefault) {
			e.preventDefault = function(){
				e.returnValue = false;
			};
		}
		if (!e.stopPropagation) {
			e.stopPropagation = function(){
				e.cancelBubble = true;
			};
		}
		if (typeof e.layerX == "undefined") {
			e.layerX = e.offsetX;
		}
		if (typeof e.layerY == "undefined") {
			e.layerY = e.offsetY;
		}
		if (typeof e.which == "undefined") {
			e.which = e.button;
		}
		return e;
	},
	
	frameExport : function (e) {
		var flag = true;
		if (!confirm('\u5982\u679c\u4f60\u5df2\u7ecf\u8fdb\u884c\u8fc7\u4fee\u6539\uff0c\u8bf7\u5148\u4fdd\u5b58\u540e\u518d\u5bfc\u51fa\uff0c\u5426\u5219\u5c06\u53ea\u4f1a\u5bfc\u51fa\u4fee\u6539\u524d\u7684\u6570\u636e\uff01')) {
			return false;
		}
		if (flag) {
			flag = false;
			if (!$('#frameexport')[0]){
				var dom  = document.createElement('div');
				dom.innerHTML = '<form name="frameexport" id="frameexport" method="post" action="portal.php?mod=portalcp&ac=diy&op=export"><input type="hidden" name="frame" value="" />\n\
					<input type="hidden" name="tpl" value="'+document.diyform.template.value+'" />\n\
					<input type="hidden" name="tpldirectory" value="'+document.diyform.tpldirectory.value+'" />\n\
					<input type="hidden" name="diysign" value="'+document.diyform.diysign.value+'" />\n\
					<input type="hidden" name="formhash" value="'+document.diyform.formhash.value+'" /><input type="hidden" name="exportsubmit" value="true"/></form>';
				$('#DiyBar').append(dom.childNodes[0]);
			}
			//document.forms.frameexport.frame.value = frame;
			document.frameexport.submit();
		}
	},
	
	recover : function () {
		if (confirm('\u60a8\u786e\u5b9a\u8981\u6062\u590d\u5230\u4e0a\u4e00\u7248\u672c\u4fdd\u5b58\u7684\u7ed3\u679c\u5417?')) {
			document.diyform.recover.value = '1';
			document.diyform.gobackurl.value = location.href.replace(/(\?diy=yes)|(\&diy=yes)/,'').replace(/[\?|\&]preview=yes/,'');
			document.diyform.submit();
		}
	},
	
	initDiyStyle : function (css) {
		var allCssText = css || $('#diy_style').html();
		allCssText = allCssText ? allCssText.replace(/\n|\r|\t|  /g,'') : '';
		var random = Math.random(), rules = '';
		var reg = new RegExp('(.*?) ?\{(.*?)\}','g');
		while((rules = reg.exec(allCssText))) {
			var selector = this.checkSelector(rules[1]);
			var cssText = rules[2];
			var cssarr = cssText.split(';');
			var l = cssarr.length;
			for (var k = 0; k < l; k++) {
				var attribute = trim(cssarr[k].substr(0, cssarr[k].indexOf(':')).toLowerCase());
				var value = cssarr[k].substr(cssarr[k].indexOf(':')+1).toLowerCase();
				if (!attribute || !value) continue;
				if (!this.spacecss[selector]) this.spacecss[selector] = [];
				this.spacecss[selector][attribute] = value;
				if (css) this.setStyle(selector, attribute, value, random);
			}
		}
	},
	
	checkSelector : function (selector) {
		var s  = selector.toLowerCase();
		if (s.toLowerCase().indexOf('body') > -1) {
			var body = 'body';
			selector = selector.replace(/body/i,body);
		}
		if (s.indexOf(' a') > -1) {
			selector = selector.replace(/ [aA]/,' a');
		}
		return selector;
	},
	
	setStyle : function (ele,cssText) {
		if (ele) {
			var s = ele.getAttribute('style') || '';
			return typeof s == 'object' ? s.cssText = cssText : ele.setAttribute('style',cssText);
		}
		return false;
	}
	
}


var drop ={
	init : function(obj, type){
		$(obj).droppable({
			tolerance: 'pointer',
			activeClass: "ui-state-default",
			hoverClass: "ui-state-hover",
			accept: ":not(.ui-sortable-helper)",
			activate: function( event, ui ) {
				$(ui.draggable).removeClass('drop').addClass('out');
				$(ui.draggable).find('> .'+type+'-name .edit').remove();
				$(ui.draggable).find('> .edit-menu').remove();
			},
			drop: function( event, ui ) {
				var thi = ui.draggable;
				$(thi).html(thi.html()).appendTo(this);
				$(thi).addClass('drop').removeClass('out');
				if(!$(thi).find('> .'+type+'-name .edit')[0]){
				    $(thi).find('> .'+type+'-name').prepend('<a class="edit" onclick="Diy.MenuObj(\''+thi[0].id+'\',\''+type+'\')"><i data-id="&#xe037;"></i></a>');
				}
				if($(thi).is('.new')){
					$(thi).removeClass('new');
				    Diy.getBlockData(thi[0].id, $(thi).data('type'));
				}
			}
		}).sortable({
			delay: 150,
			items: "div."+type,
			update: function( event, ui ) {
				var thi = ui.item;
				$(thi).addClass('drop').removeClass('out');
				if(!$(thi).find('> .'+type+'-name .edit')[0]){
				    $(thi).find('> .'+type+'-name').prepend('<a class="edit" onclick="Diy.MenuObj(\''+thi[0].id+'\',\''+type+'\')"><i data-id="&#xe037;"></i></a>');
				}
			}
		}).disableSelection();
	},
	
	destroy : function(obj){
		try {
			if(obj){
				$(obj).droppable("destroy").sortable("destroy");
			}else{
				$('.ui-droppable').droppable("destroy");
				$('.ui-sortable').sortable("destroy");
			}
		}catch (ext) {
			console.log('Percentage:', ext);
		}
	}
	
}
	
$(function(){
    Diy.init();
	
	Frame = function(name, className, top, left, moveable){
		this.name = name;
		this.top = top;
		this.left = left;
		this.moveable = moveable ? true : false;
		this.columns = [];
		this.className = className;
		this.titles = [];
		if (typeof Frame._init == 'undefined') {
			Frame.prototype.addColumn = function (column) {
				if (column instanceof Column) {
					this.columns[column.name] = column;
				}
			};
			Frame.prototype.addFrame = function(columnId, frame) {
				if (frame instanceof Frame || frame instanceof Tab){
					this.columns[columnId].children.push(frame);
				}
			};
			Frame.prototype.addBlock = function(columnId, block) {
				if (block instanceof Block){
					this.columns[columnId].children.push(block);
				}
			};
		}
		Frame._init = true;
	};
	
	Column = function (name, className) {
		this.name = name;
		this.className = className;
		this.children = [];
	};
	
	Block = function(name, className, top, left) {
		this.name = name;
		this.top = top;
		this.left = left;
		this.className = className;
		this.titles = [];
	};
	
});