<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}

class mobileplugin_mumucms_wapcontrol { 

       function global_header_mobile() {
            global $_G;
			$mumucms_wapcontrol = array();
			$mumucms_wapcontrol = $_G['cache']['plugin']['mumucms_wapcontrol'];//����������ֵ
			loadcache('mumucms_startup');
			loadcache('mumucms_app');
      }
      
		function mumucms_wapcontrol_generate($value) {
				global $_G;
				$_init_style = false;
				if($_init_style === false) {
					C::app()->_init_style();
					$_init_style = true;
				}
				$file = 'touch/'.$value['dir'].'/'.$value['template'];
				!empty($value['id']) && $file = $file.'_'.$value['id'];
				$tplfile = 'data/diy/./template/mumucms_waptheme/'.$file.'.htm';
				
				if(is_file(DISCUZ_ROOT.$tplfile)){
					$templateid = 'diy';
					$cachefile = './data/template/'.(defined('STYLEID') ? STYLEID.'_' : '_').$templateid.'_'.str_replace('/', '_', $file).'.tpl.php';
					$tpldir = 'data/diy/./template/mumucms_waptheme';
					mobileplugin_mumucms_wapcontrol::mumucms_wapcontrol_checktplrefresh($tplfile, $tplfile, @filemtime(DISCUZ_ROOT.$cachefile), $templateid, $cachefile, $tpldir, $file);
				}
		}

		function mumucms_wapcontrol_checktplrefresh($maintpl, $subtpl, $timecompare, $templateid, $cachefile, $tpldir, $file) {
			$tplrefresh = $timestamp = $targettplname = NULL;
			if($tplrefresh === null) {
				$tplrefresh = getglobal('config/output/tplrefresh');
				$timestamp = getglobal('timestamp');
			}
			if(empty($timecompare) || $tplrefresh == 1 || ($tplrefresh > 1 && !($timestamp % $tplrefresh))) {
				if(empty($timecompare) || @filemtime(DISCUZ_ROOT.$subtpl) > $timecompare) {
					require_once DISCUZ_ROOT.'/source/class/class_template.php';
					$template = new template();
					$template->parse_template($maintpl, $templateid, $tpldir, $file, $cachefile);
					if($targettplname === null) {
						$targettplname = $file;
						if(!empty($targettplname)) {
							include_once libfile('function/block');
							$targettplname = strtr($targettplname, ':', '_');
							update_template_block($targettplname, './template/mumucms_waptheme', $template->blocks);
						}
						$targettplname = true;
					}
					return TRUE;
				}
			}
			return FALSE;
		}

}


class mobileplugin_mumucms_wapcontrol_forum extends mobileplugin_mumucms_wapcontrol {
	//��̳��ҳ֧��DIY
	function index_forum_discuz(){
		$para = array('template' => 'discuz','dir'=>'forum');
        mobileplugin_mumucms_wapcontrol::mumucms_wapcontrol_generate($para);	
	}

}

class mobileplugin_mumucms_wapcontrol_portal extends mobileplugin_mumucms_wapcontrol {
		//�Ż���ҳ֧��DIY
		function index_portal_index(){
		$para = array('template' => 'index','dir'=>'portal');
        mobileplugin_mumucms_wapcontrol::mumucms_wapcontrol_generate($para);	
	}
		//�Ż�Ƶ��֧��DIY
		function index_portal_list(){
		$para = array('template' => 'list','dir'=>'portal');
        mobileplugin_mumucms_wapcontrol::mumucms_wapcontrol_generate($para);	
	}

}
//From: Dism_taobao-com
?>