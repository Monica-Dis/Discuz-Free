<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}




	echo <<<EOF
		<ul class="tab1">
			<li class="current"><a href="admin.php?action=plugins&operation=config&do=$pluginid&identifier=mumucms_wapcontrol&pmod=mumucms_wapcontrol_other&gnmod=other"><span>{$langs['mumucms_startup']}</span></a></li>	
			<li><a href="admin.php?action=plugins&operation=config&do=$pluginid&identifier=mumucms_wapcontrol&pmod=mumucms_wapcontrol_other&gnmod=app"><span>{$langs['mumucms_app']}</span></a></li>
		</ul>
EOF;

	if(!submitcheck('submit')){
		require_once libfile('function/cache');
		loadcache('mumucms_startup');
		$cache =$_G['cache']['mumucms_startup'];
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=mumucms_wapcontrol&pmod=mumucms_wapcontrol_other&gnmod=other');
		showtableheader(lang('plugin/mumucms_wapcontrol', 'setting'));
		showsetting($langs['startup_qiyong'],'startup_qiyong',$cache['startup_qiyong'],'radio');
		showsetting($langs['startup_guoqi'],'startup_guoqi',$cache['startup_guoqi'],'text');
		showsetting($langs['startup_guanbi'],'startup_guanbi',$cache['startup_guanbi'],'text');
		showsetting($langs['startup_text'],'startup_text',$cache['startup_text'],'text');
		showsetting($langs['startup_shengxiao'],'startup_shengxiao',$cache['startup_shengxiao'],'radio');
		showsetting($langs['startup_imgadr'],'startup_imgadr',$cache['startup_imgadr'],'text');
		showsetting($langs['startup_imglink'],'startup_imglink',$cache['startup_imglink'],'text');
		showsetting($langs['startup_imglogo'],'startup_imglogo',$cache['startup_imglogo'],'text');
		showsetting($langs['startup_logotext'],'startup_logotext',$cache['startup_logotext'],'text');		
		showsubmit('submit');	
		showtablefooter();
		showformfooter();
	}else{
		function build_cache_mumucms_startup(){ 
		    $data = array();
		    $data['startup_qiyong'] = $_GET['startup_qiyong'];
		    $data['startup_guoqi'] = $_GET['startup_guoqi'];
		    $data['startup_guanbi'] = $_GET['startup_guanbi'];
		    $data['startup_text'] = $_GET['startup_text'];
		    $data['startup_shengxiao'] = $_GET['startup_shengxiao'];
		    $data['startup_imgadr'] = $_GET['startup_imgadr'];
		    $data['startup_imglink'] = $_GET['startup_imglink'];	    
		    $data['startup_imglogo'] = $_GET['startup_imglogo'];
		    $data['startup_logotext'] = $_GET['startup_logotext'];
		    save_syscache('mumucms_startup', $data);
		}
		updatecache('mumucms_startup');

		cpmsg('tasks_installed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=mumucms_wapcontrol&pmod=mumucms_wapcontrol_other&gnmod=other', 'succeed');
	}



?>