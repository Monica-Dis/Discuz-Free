<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

echo <<<EOF
		<ul class="tab1">
			<li><a href="admin.php?action=plugins&operation=config&do=$pluginid&identifier=mumucms_wapcontrol&pmod=mumucms_wapcontrol_other&gnmod=other"><span>{$langs['mumucms_startup']}</span></a></li>	
			<li class="current"><a href="admin.php?action=plugins&operation=config&do=$pluginid&identifier=mumucms_wapcontrol&pmod=mumucms_wapcontrol_other&gnmod=app"><span>{$langs['mumucms_app']}</span></a></li>
		</ul>
EOF;

	if(!submitcheck('submit')){
		require_once libfile('function/cache');
		loadcache('mumucms_app');
		$cache =$_G['cache']['mumucms_app'];
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=mumucms_wapcontrol&pmod=mumucms_wapcontrol_other&gnmod=app');
		showtableheader(lang('plugin/mumucms_wapcontrol', 'setting'));
		showsetting($langs['app_qiyong'],'app_qiyong',$cache['app_qiyong'],'radio','','0',$langs['mumucms_gaoji_sortid_jieshao']);
		showsetting($langs['app_guidexs'],'app_guidexs',$cache['app_guidexs'],'radio');
		showsetting($langs['app_forumdisplayxs'],'app_forumdisplayxs',$cache['app_forumdisplayxs'],'radio');
		showsetting($langs['app_viewthreadxs'],'app_viewthreadxs',$cache['app_viewthreadxs'],'radio');
		showsetting($langs['app_downkz'],'app_downkz',$cache['app_downkz'],'radio');		
		showsetting($langs['app_downtext'],'app_downtext',$cache['app_downtext'],'text');
		showsetting($langs['app_android'],'app_android',$cache['app_android'],'text');
		showsetting($langs['app_ios'],'app_ios',$cache['app_ios'],'text');
		showtableheader(lang('plugin/mumucms_wapcontrol', $langs['app_duli']));
		showsetting($langs['app_ico'],'app_ico',$cache['app_ico'],'text');
		showsetting($langs['app_name'],'app_name',$cache['app_name'],'text');	
		showsetting($langs['app_sum'],'app_sum',$cache['app_sum'],'text');					
		showsubmit('submit');	
		showtablefooter();
		showformfooter();
	}else{
		function build_cache_mumucms_app(){ 
		    $data = array();
		    $data['app_qiyong'] = $_GET['app_qiyong'];
		    $data['app_guidexs'] = $_GET['app_guidexs'];
		    $data['app_forumdisplayxs'] = $_GET['app_forumdisplayxs'];
		    $data['app_viewthreadxs'] = $_GET['app_viewthreadxs'];
		    $data['app_downkz'] = $_GET['app_downkz'];		    
		    $data['app_downtext'] = $_GET['app_downtext'];
		    $data['app_android'] = $_GET['app_android'];	    
		    $data['app_ios'] = $_GET['app_ios'];
		    $data['app_ico'] = $_GET['app_ico'];
		    $data['app_name'] = $_GET['app_name'];
		    $data['app_sum'] = $_GET['app_sum'];		    		    		    
		    save_syscache('mumucms_app', $data);
		}
		updatecache('mumucms_app');

		cpmsg('tasks_installed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=mumucms_wapcontrol&pmod=mumucms_wapcontrol_other&gnmod=app', 'succeed');
	}


?>