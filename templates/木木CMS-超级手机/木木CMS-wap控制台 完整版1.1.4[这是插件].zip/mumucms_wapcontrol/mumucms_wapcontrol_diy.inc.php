<?php

/**
 *  FOR Discuz! X 
 *	ainuo design 
 *  
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/portalcp');
$op = in_array($_GET['op'], array('style', 'diy', 'image', 'export', 'import', 'blockclass')) ? $_GET['op'] : '';



if ($op == 'import') {

	$tpl = $_POST['tpl'] ? $_POST['tpl'] : $_GET['tpl'];
	tpl_checkperm($tpl);
	if (submitcheck('importsubmit')) {
		$isinner = false;
		$filename = '';
		if($_POST['importfilename']) {
			$filename = DISCUZ_ROOT.'./template/mumucms_waptheme/touch/portal/diyxml/'.$_POST['importfilename'].'.xml';
			$isinner = true;
		} else {
			$upload = new discuz_upload();
			$upload->init($_FILES['importfile'], 'temp');
			$attach = $upload->attach;
			if(!$upload->error()) {
				$upload->save();
			}
			if($upload->error()) {
				showmessage($upload->error(),'',array('status'=>$upload->error()));
			} else {
				$filename = $attach['target'];
			}
		}
		if($filename) {
			$arr = import_diy($filename);
			if(!$isinner) {
				@unlink($filename);
			}
			if (!empty($arr)) {
				$search = array('/\<script/i', '/\<\/script\>/i', "/\r/", "/\n/", '/(\[script [^>]*?)(src=)(.*?\[\/script\])/');
				$replace = array('[script', '[/script]', '', '', '$1[src=]$3');
				$arr['css'] = str_replace(array("\r","\n"),array(''),$arr['css']);

				$jsarr = array('status'=>1,'css'=>$arr['css'],'bids'=>implode(',',$arr['mapping']));

				foreach ($arr['html'] as $key => $value) {
					$value = preg_replace($search,$replace,$value);
					$jsarr['html'][$key] = $value;
				}

				showmessage('do_success','portal.php',$jsarr);
			} else {
				showmessage('do_success','portal.php',array('status'=>0));
			}
		}
	}
	$xmlarr = array();
	$template = str_replace('/','-',$tpl);
	if ($_GET['type'] == 1) {
		$xmlfilepath = DISCUZ_ROOT.'./template/mumucms_waptheme/touch/portal/diyxml/';
		if(($dh = @opendir($xmlfilepath))) {
			while(($file = @readdir($dh)) !== false) {
				if(strpos($file,$template) !== false && fileext($file) == 'xml' && strstr(strtolower($file),CHARSET)) {
					$xmlarr[substr($file, 0, -4)] = getdiyxmlname($file, $xmlfilepath);
					
				}
			}
			closedir($dh);
		}
		arsort($xmlarr);
	}
} else {
	showmessage('undefined_action');
}

include_once template("portal/portalcp_diy");

function topic_upload_error($attach, $msg='') {
	echo '<script>';
	echo 'parent.document.getElementById(\'uploadmsg\').innerHTML = \''.$attach['name'].' '.lang('home/template', 'upload_error').$msg.'\';';
	echo '</script>';
	exit();
}

function topic_upload_show($topicid) {

	echo '<script>';
	echo 'parent.ajaxget("portal.php?mod=portalcp&ac=diy&op=image&topicid='.$topicid.'&", "diyimages");';
	echo 'parent.document.uploadpic.attach.value = \'\';';
	echo 'Util.toggleEle(\'upload\')';
	echo '</script>';
	exit();
}

function tpl_checkperm($tpl) {
	global $_G;
	list($file,$id) = explode(':', $tpl);

		if(!$_G['group']['allowdiy']) {
			showmessage('diy_nopermission');
		
	}
}

function category_checkperm($category) {
	global $_G;
	if(empty($category)) {
		showmessage('topic_not_exist');
	}

	if($_G['group']['allowdiy']) return true;

	if(!$_G['group']['allowdiy'] && (!$_G['group']['allowaddtopic'] || $_G['uid'] != $topic['uid'])) {
		showmessage('topic_edit_nopermission');
	}

}

function topic_checkperm($topic) {
	global $_G;
	if(empty($topic)) {
		showmessage('topic_not_exist');
	}
	if(!$_G['group']['allowmanagetopic'] && (!$_G['group']['allowaddtopic'] || $_G['uid'] != $topic['uid'])) {
		showmessage('topic_edit_nopermission');
	}
}

function gettopictplname($topicid) {
	$topicid = max(0,intval($topicid));
	$topic = C::t('portal_topic')->fetch($topicid);
	return !empty($topic) && !empty($topic['primaltplname']) ? $topic['primaltplname'] : getglobal('cache/style_default/tpldir').':portal/portal_topic_content';
}

function getportalcategorytplname($catid) {
	global $_G;
	$catid = max(0,intval($catid));
	$category = $_G['cache']['portalcategory'][$catid];
	return !empty($category) && !empty($category['primaltplname']) ? $category['primaltplname'] : getglobal('cache/style_default/tpldir').':portal/list';
}

function getportalarticletplname($catid, $primaltplname = ''){
	if(($catid = intval($catid))) {
		if(($category = C::t('portal_category')->fetch($catid))) {
			$primaltplname = $category['articleprimaltplname'];
		}
		if(empty($primaltplname)) {
			$primaltplname = getglobal('cache/style_default/tpldir').':portal/view';
			C::t('portal_category')->update($catid, array('articleprimaltplname' => $primaltplname));
		}
	}
	return $primaltplname;
}

function getdiyxmlname($filename, $path) {
	$content = @file_get_contents($path.$filename);
	$name = $filename;
	if($content) {
		preg_match("/\<\!\-\-\[name\](.+?)\[\/name\]\-\-\>/i", trim($content), $mathes);
		if(!empty($mathes[1])) {
			preg_match("/^\{lang (.+?)\}$/", $mathes[1], $langs);
			if(!empty($langs[1])) {
				$name = lang('portalcp', $langs[1]);
			} else {
				$name = dhtmlspecialchars($mathes[1]);
			}
		}
	}
	return $name;
}
?>