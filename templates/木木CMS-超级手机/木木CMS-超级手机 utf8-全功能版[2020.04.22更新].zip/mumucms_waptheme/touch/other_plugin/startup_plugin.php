<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if !$_G['uid'] and $_G['cache']['mumucms_startup']['startup_shengxiao'] == 1}-->
	<!--{if empty($_G['cookie']['mumucms_startup_pop_time'])}-->
	<style type="text/css">
	.mumucms_startup{position:fixed;width:100%;height:100%;background:#FFF;z-index:9999;}	
	.mumucms_startup .mumucms_starimgd a {display: block;width: 100%;height: 100%;overflow: hidden;}
	.mumucms_startup .mumucms_starimg img{width:100%;height:auto;object-fit: cover;}
	.mumucms_startup .mumucms_time{position:absolute;right:15px;top:15px;padding:5px 10px;background:rgba(0, 0, 0, 0.4);color:rgba(255, 255, 255, 0.9);font-size:14px;border-radius:3px;}
	.mumucms_startup .mumucms_logo{position:absolute;height:15%;width:100%;text-align:center;overflow:hidden;left:0;bottom:0;
    background:#FFF;}
	.mumucms_startup .mumucms_logo img{margin-top:5%;height:50%;}
	.mumucms_startup .mumucms_logo p{font-size:12px;color:#999;}
	</style>
	<div class="mumucms_startup">
		<div class="mumucms_starimg">
			<a href="{$_G['cache']['mumucms_startup']['startup_imglink']}"><img src="{$_G['cache']['mumucms_startup']['startup_imgadr']}"></a>
		</div>
		
		<div class="mumucms_time"><span id="dd">{$_G['cache']['mumucms_startup']['startup_guanbi']}</span>{$_G['cache']['mumucms_startup']['startup_text']}</div>
		<div class="mumucms_logo">
			<img src="{$_G['cache']['mumucms_startup']['startup_imglogo']}">
			<p>{$_G['cache']['mumucms_startup']['startup_logotext']}</p>
		</div>
	</div>
	<script type="text/javascript">
		function run(){
	 	var s = document.getElementById("dd");
			if(s.innerHTML == 0){
				$(".mumucms_startup").hide();
		  		setcookie('mumucms_startup_pop_time', '1', {$_G['cache']['mumucms_startup']['startup_guoqi']});//设置过期时间

			}
			if(s.innerHTML == -1){
				return false;	
			}	
	 		s.innerHTML = s.innerHTML * 1 - 1;
		}
		window.setInterval("run();", 1000);

		$(".mumucms_time").click(function(){
			setcookie('mumucms_startup_pop_time', '1', {$_G['cache']['mumucms_startup']['startup_guoqi']});//设置过期时间
	  		$(".mumucms_startup").hide();
		});
	</script>
	<!--{/if}-->
<!--{elseif $_G['cache']['mumucms_startup']['startup_shengxiao'] == 0}-->
	<!--{if empty($_G['cookie']['mumucms_startup_pop_time'])}-->
	<style type="text/css">
	.mumucms_startup{position:fixed;width:100%;height:100%;background:#FFF;z-index:9999;}	
	.mumucms_startup .mumucms_starimgd a {display: block;width: 100%;height: 100%;overflow: hidden;}
	.mumucms_startup .mumucms_starimg img{width:100%;height:auto;object-fit: cover;}
	.mumucms_startup .mumucms_time{position:absolute;right:15px;top:15px;padding:5px 10px;background:rgba(0, 0, 0, 0.4);color:rgba(255, 255, 255, 0.9);font-size:14px;border-radius:3px;}
	.mumucms_startup .mumucms_logo{position:absolute;height:15%;width:100%;text-align:center;overflow:hidden;left:0;bottom:0;
    background:#FFF;}
	.mumucms_startup .mumucms_logo img{margin-top:5%;height:50%;}
	.mumucms_startup .mumucms_logo p{font-size:12px;color:#999;}
	</style>
	<div class="mumucms_startup">
		<div class="mumucms_starimg">
			<a href="{$_G['cache']['mumucms_startup']['startup_imglink']}"><img src="{$_G['cache']['mumucms_startup']['startup_imgadr']}"></a>
		</div>
		
		<div class="mumucms_time"><span id="dd">{$_G['cache']['mumucms_startup']['startup_guanbi']}</span>{$_G['cache']['mumucms_startup']['startup_text']}</div>
		<div class="mumucms_logo">
			<img src="{$_G['cache']['mumucms_startup']['startup_imglogo']}">
			<p>{$_G['cache']['mumucms_startup']['startup_logotext']}</p>
		</div>
	</div>
	<script type="text/javascript">
		function run(){
	 	var s = document.getElementById("dd");
			if(s.innerHTML == 0){
				$(".mumucms_startup").hide();
		  		setcookie('mumucms_startup_pop_time', '1', {$_G['cache']['mumucms_startup']['startup_guoqi']});//设置过期时间

			}
			if(s.innerHTML == -1){
				return false;	
			}	
	 		s.innerHTML = s.innerHTML * 1 - 1;
		}
		window.setInterval("run();", 1000);

		$(".mumucms_time").click(function(){
			setcookie('mumucms_startup_pop_time', '1', {$_G['cache']['mumucms_startup']['startup_guoqi']});//设置过期时间
	  		$(".mumucms_startup").hide();
		});
	</script>
	<!--{/if}-->		
<!--{/if}-->
