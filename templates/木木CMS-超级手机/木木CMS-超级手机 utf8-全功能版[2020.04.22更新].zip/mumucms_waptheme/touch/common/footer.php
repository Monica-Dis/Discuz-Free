<?php echo 'From: DisM.taobao.com';exit;?>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<!--{if $_GET['diy'] == 'yes'}-->
    <!--{template common/header_diy}-->
 <!--{/if}-->

<!--{if !$mumucms_scrollmenu}-->
<div class="mumucms_scrollmenu">
<!--{if check_diy_perm($topic)}-->	
<li><a href="javascript:;" onclick="openDiy()" class="ascrolldiy"  style="background:#FF9800;">DIY</a></li>
 <!--{/if}-->
<li><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></li>
<li><a href="javascript:;" onclick="location.reload();"><i class="iconfont icon-shuaxin"></i></a></li>
<li><a class="gotop" href="javascript:;"><i class="iconfont icon-jiantoutop"></i></a></li>
</div>
<script type="text/javascript">  
    var t = 0, 
        b = 0;
    $(window).scroll(function(){
        t = $(this).scrollTop();
        if(b < t){
            $('.mumucms_scrollmenu').addClass('mumucms_scrollhide'); 
        }else{
            $('.mumucms_scrollmenu').removeClass('mumucms_scrollhide');  
        }
        setTimeout(function(){
            b = t
        }, 0);

    });
    $(function () {    
        $(".gotop").click(function(){
        $('html,body').animate({'scrollTop':0},500);
        });     
    });    
</script>
<!--{/if}-->

<div class="mumucms_slide_menu">
    <div class="mumucms_user">
        <div class="mumucms_userinfo">
            <!--{if $_G['uid']}-->
            <a href="home.php?mod=space&uid=$_G[uid]&do=profile">
                <div class="mumucms_avatar mumucms_fl"><!--{avatar($space[uid],middle)}--></div>
                <h3 class="mumucms_name">$_G[username]</h3>
            </a>
            <!--{else}-->
            <a href="member.php?mod=logging&action=login">
                <div class="mumucms_avatar mumucms_fl"><!--{avatar($space[uid],middle)}--></div>
                <h3 class="mumucms_name">
                <script language="javascript">                  
                        var myDate = new Date();
                        var i = myDate.getHours();
                        if(i < 12)
                        document.write("早上好!");
                        else if(i >=12 && i < 14)
                        document.write("中午好!");
                        else if(i >= 14 && i < 18)
                        document.write("下午好!");
                        else if(i >= 18)
                        document.write("晚上好!");                 
                </script>&nbsp;请登录</h3>
            </a>
            <!--{/if}-->
        </div>
        <div class="mumucms_menber">
            <iframe scrolling="no" src="https://tianqiapi.com/api.php?style=tv&skin=cake&color=FFF" frameborder="0" width="160" height="25"  allowtransparency="true"></iframe>
            <!--{if $_G[uid]}-->
            <a class="mumucms_register" href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1"><i class="iconfont icon-shezhi"></i>设置中心</a>
            <!--{else}-->
            <a class="mumucms_register" href="member.php?mod={$_G[setting][regname]}"><i class="iconfont icon-caidan"></i>立即注册</a>
            <!--{/if}-->

        </div>
    </div>

<div class="mumucms_style">
    <li id="t0" onclick="mumucms_style('t0');"{if $_G['cookie']['mumucms_style'] == t0 || empty($_G['cookie']['mumucms_style'])}class="hover"{/if}><span><i class="iconfont icon-duihao"></i></span></li>
    <li id="t1" onclick="mumucms_style('t1');"{if $_G['cookie']['mumucms_style'] == t1}class="hover"{/if}><span style="background:#d43232;"><i class="iconfont icon-duihao"></i></span></li>
    <li id="t2" onclick="mumucms_style('t2');"{if $_G['cookie']['mumucms_style'] == t2}class="hover"{/if}><span style="background:#73b31c;"><i class="iconfont icon-duihao"></i></span></li>
    <li id="t3" onclick="mumucms_style('t3');"{if $_G['cookie']['mumucms_style'] == t3}class="hover"{/if}><span style="background:#f78015;"><i class="iconfont icon-duihao"></i></span></li>
    <li id="t4" onclick="mumucms_style('t4');"{if $_G['cookie']['mumucms_style'] == t4}class="hover"{/if}><span style="background:#f65b7a;"><i class="iconfont icon-duihao"></i></span></li>
    <li id="t5" onclick="mumucms_style('t5');"{if $_G['cookie']['mumucms_style'] == t5}class="hover"{/if}><span style="background:#323436;"><i class="iconfont icon-duihao"></i></span></li>
    <li id="t6" onclick="mumucms_style('t6');"{if $_G['cookie']['mumucms_style'] == t6}class="hover"{/if}><span style="background:#0AA76F;"><i class="iconfont icon-duihao"></i></span></li>
    <li id="t7" onclick="mumucms_style('t7');"{if $_G['cookie']['mumucms_style'] == t7}class="hover"{/if}><span style="background:#9c27b0;"><i class="iconfont icon-duihao"></i></span></li>
    <li id="t8" onclick="mumucms_style('t8');"{if $_G['cookie']['mumucms_style'] == t8}class="hover"{/if}><span style="background:#00bcd4;"><i class="iconfont icon-duihao"></i></span></li>    
</div>
    <div class="mumucms_menulist">
    <ul>
        <li><a href="{$_G['siteurl']}"><i class="iconfont icon-shouye" style="color:#00C5C7;"></i>首页</a></li>
        <li><a href="forum.php?forumlist=1"><i class="iconfont icon-xiaoxi" style="color:#FFA800"></i>社区</a></li>
        <li><a href="forum.php?mod=guide&view=newthread"><i class="iconfont icon-faxian" style="color:#9DCA08;"></i>导读</a></li>
        <li><a href="news"><i class="iconfont icon-xinwen" style="color:#FA7D5F;"></i>微资讯</a></li>        
        <li><a href="http://t.cn/AiuxBMCp"><i class="iconfont icon-fangchan01" style="color:#DA99DB;"></i>房产</a></li>        
        <li><a href="http://t.cn/AiuxBMCp"><i class="iconfont icon-tupian" style="color:#F37D7D;"></i>图说事</a></li>
        <li><a href="http://t.cn/AiuxBMCp"><i class="iconfont icon-fenlei" style="color:#9DCA08;"></i>分类信息</a></li>        
        <li><a href="http://t.cn/AiuxBMCp"><i class="iconfont icon-renyuan" style="color:#00C5C7;"></i>人才招聘</a></li>
        <li><a href="http://t.cn/AiuxBMCp"><i class="iconfont icon-huodong" style="color:#FFA800;"></i>活动中心</a></li>
        <li><a href="home.php?mod=space&uid=$_G[uid]&do=thread&view=me"><i class="iconfont icon-fabu" style="color:#DA99DB;"></i>我的帖子</a></li>   
        <!--{eval $agent = $_SERVER['HTTP_USER_AGENT']}--> 
        <!--{if strpos($agent,"Html5Plus") === false }-->
        <li><a href="plugin.php?id=mumucms_wapcontrol:mumucms_wapcontrol_app"><i class="iconfont icon-app" style="color:#FA7D5F;"></i>APP下载</a></li>
        <!--{/if}-->    
    </ul>
    </div>
</div>
  

<div id="mask" style="display:none;"></div>
</div>
<!--{if !$nofooter}-->
<div class="mumucms_footer_zw"></div>
<div id="mumucms_footer">
    <a href="{$_G['siteurl']}" id="nav-home">
        <div class="mumucms_footer_icons"><i class="iconfont icon-shouye"></i></div>
        <div class="mumucms_footer_text">首页</div>
    </a>
    <a href="forum.php?forumlist=1" id="nav-news">
        <div class="mumucms_footer_icons"><i class="iconfont icon-xiaoxi"></i></div>
        <div class="mumucms_footer_text">社区</div>
    </a>
    <li class="mumucms_fl">
    <a href="forum.php?mod=misc&action=nav">
       <span class="bg_top"></span>
       <span class="bg_top bg_bottom"><i class="iconfont icon-fabu"></i></span>
    </a>
    </li>
    <a href="search.php?mod=forum" id="nav-forum">
        <div class="mumucms_footer_icons"><i class="iconfont icon-faxian"></i></div>
        <div class="mumucms_footer_text">发现</div>
    </a>
    <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" id="nav-my">
        <div class="mumucms_footer_icons"><i class="iconfont icon-renyuan"></i></div>
        <div class="mumucms_footer_text">我的</div>
    </a>
</div>
<!--{/if}-->




</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
    <!--{eval output();}-->
<!--{else}-->
    <!--{eval output_preview();}-->
<!--{/if}-->

