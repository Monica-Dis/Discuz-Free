<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block diynav}-->
	<a id="diy-tg" href="javascript:openDiy();" title="{lang open_diy}" class="xi1 xw1" onmouseover="showMenu(this.id)"><img src="{STATICURL}image/diy/panel-toggle.png" alt="DIY" /></a>
	<div id="diy-tg_menu" style="display: none;">
		<ul>
			<li><a href="javascript:saveUserdata('diy_advance_mode', '');openDiy();" class="xi2">{lang header_diy_mode_simple}</a></li>
			<li><a href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" class="xi2">{lang header_diy_mode_adv}</a></li>
		</ul>
	</div>
<!--{/block}-->
