<?php echo 'From: DisM.taobao.com';exit;?>、
<!--{echo output_ajax()}-->]]></root><!--{eval exit;}-->
