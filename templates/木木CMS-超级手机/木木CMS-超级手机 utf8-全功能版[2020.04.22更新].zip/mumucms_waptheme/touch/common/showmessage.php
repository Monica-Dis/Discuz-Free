<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $param['login']}-->
	<!--{if $_G['inajax']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login&inajax=1&infloat=1');exit;}-->
	<!--{else}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
	<!--{/if}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if $_G['inajax']}-->
<div class="mumucms_tip">
	<dt id="messagetext">
		<p>$show_message</p>
	</dt>
		<!--{if $_G['forcemobilemessage']}-->
			<dd>
        	<p >
            	<a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
                <a href="javascript:history.back();">{lang goback}</a>
            </p>
            </dd>
        <!--{/if}-->
		<!--{if $url_forward && !$_GET['loc']}-->
			<!--<p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>-->
			<script type="text/javascript">
			    var text = '$url_forward';
				setTimeout(function() {
					if(text.indexOf("ac=block") > 0 ){
						popup.close();
					}else{
						<!--{if $values['html']}-->
						popup.close();
						<!--{else}-->
						window.location.href = '$url_forward';
						<!--{/if}-->
					}
				}, '1500');
			</script>
		<!--{elseif $allowreturn}-->
			<dd><p><input type="button" class="button" onclick="popup.close();" value="{lang close}"></p></dd>
		<!--{/if}-->
</div>
<!--{else}-->

<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>$navtitle</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<!-- header end -->
<!-- main jump start -->
<div class="mumucms_wrap mumucms_jump">
<div class="jump_c">
	<p>$show_message</p>
    <!--{if $_G['forcemobilemessage']}-->
		<p>
            <a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
            <a href="javascript:history.back();">{lang goback}</a>
        </p>
    <!--{/if}-->
	<!--{if $url_forward}-->
		<p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>
	<!--{elseif $allowreturn}-->
		<p><a class="grey" href="javascript:history.back();">{lang message_go_back}</a></p>
	<!--{/if}-->
</div>
</div>
<!-- main jump end -->
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<!--{/if}-->
<!--{template common/footer}-->

