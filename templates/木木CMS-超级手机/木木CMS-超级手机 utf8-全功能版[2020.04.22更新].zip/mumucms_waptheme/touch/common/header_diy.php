<?php echo 'From: DisM.taobao.com';exit;?>
<div id="mumucms_diy">
<div class="mumucms_diy">
	<div id="controlheader" class="diy_header">
		<div class="diy_btn">
			<span id="navsave"><a href="javascript:;" onclick="javascript:spaceDiy.save();return false;">{lang save}</a></span>
			<span id="navcancel" class="diy_close"><a href="javascript:;" id="diycancel" onclick="spaceDiy.cancel();return false;">{lang close}</a></span>
		</div>
		<ul id="controlnav">
			<li id="navstart" class="current"><a href="javascript:" onclick="spaceDiy.getdiy('start');this.blur();return false;">{lang header_start}</a></li>
			<li id="navframe"><a href="javascript:;" onclick="spaceDiy.getdiy('frame');this.blur();return false;">{lang header_frame}</a></li>
			<li id="navblockclass"><a href="javascript:;" onclick="spaceDiy.getdiy('blockclass');this.blur();return false;" id="hd_mod">{lang header_module}</a></li>
			<!--{if !empty($topic)}-->
			<li id="navstyle"><a href="javascript:;" onclick="spaceDiy.getdiy('style');this.blur();return false;">{lang style}</a></li>
			<li id="navdiy"><a href="javascript:;" onclick="spaceDiy.getdiy('diy', 'topicid', '$topic[topicid]');this.blur();return false;">{lang header_diy}</a></li>
			<!--{/if}-->
		</ul>
	</div>
	<div id="controlcontent"  class="diy_content">
		<ul id="contentstart" class="diy_start">
	        <li><a href="javascript:;" onclick="spaceDiy.recover();return false;" title="{lang header_restore_backup_desc}">{lang header_restore_backup}</a></li>
	        <li><a href="javascript:;" onclick="drag.frameExport();return false;" title="{lang header_export_desc}">{lang header_export}</a></li>
	        <li><a href="javascript:;" onclick="drag.openFrameImport(1);return false;" title="{lang header_import_desc}">{lang header_import}</a></li>
	        <li><a href="javascript:;" onclick="Diy.blockForceUpdateBatch();return false;" title="{lang header_update_desc}">{lang header_update}</a></li>
	        <li><a href="javascript:;" onclick="drag.clearAll();return false;" title="{lang header_clearall_desc}">{lang header_clearall}</a></li>
		</ul>
		<ul id="contentframe" class="diy_frame">
			<li><a href="javascript:;" id="frame_1" onmousedown="drag.createObj(event,'frame','1');" onfocus="this.blur();" data="$widthstr"><img src="{STATICURL}image/diy/layout-1.png" /></a></li>
			<li><a href="javascript:;" id="frame_1_1" onmousedown="drag.createObj(event,'frame','1-1');" onfocus="this.blur();"><img src="{STATICURL}image/diy/layout-1-1.png" /></a></li>
			<li><a href="javascript:;" id="frame_1_2" onmousedown="drag.createObj(event,'frame','1-2');" onfocus="this.blur();"><img src="{STATICURL}image/diy/layout-1-2.png" /></a></li>
			<li><a href="javascript:;" id="frame_2_1" onmousedown="drag.createObj(event,'frame','2-1');" onfocus="this.blur();"><img src="{STATICURL}image/diy/layout-2-1.png" /></a></li>
			<li><a href="javascript:;" id="frame_1_3" onmousedown="drag.createObj(event,'frame','1-3');" onfocus="this.blur();"><img src="{STATICURL}image/diy/layout-1-3.png" /></a></li>
			<li><a href="javascript:;" id="frame_3_1" onmousedown="drag.createObj(event,'frame','3-1');" onfocus="this.blur();"><img src="{STATICURL}image/diy/layout-3-1.png" /></a></li>
			<li><a href="javascript:;" id="frame_1_1_1" onmousedown="drag.createObj(event,'frame','1-1-1');" onfocus="this.blur();" data="$widthstr"><img src="{STATICURL}image/diy/layout-1-1-1.png" /></a></li>
			<li><a href="javascript:;" id="frame_tab" onmousedown="drag.createObj(event,'tab');" onfocus="this.blur();" data="$widthstr"><img src="{STATICURL}image/diy/layout-tab.png" /></a></li>
		</ul>
		<div id="contentblockclass" class="diy_blockclass"></div>
	</div>

</div>

  <!--{eval ($_GET['mod'] == 'topic' && $_GET['topicid']) && $_G['style']['tplfile'] = 'portal/portal_topic_content:'.$_GET['topicid'];$_G['style']['tplsavemod']=1;}-->
  
  <!--{eval $_GET['mod'] == 'guide' && $_G['style']['tplfile'] = 'forum/guide';$_G['style']['tplsavemod']=1;}-->

  <!--{eval ($_GET['mod'] == 'list' && $_GET['catid']) && $_G['style']['tplfile'] = 'portal/list:'.$_GET['catid'];$_G['style']['tplsavemod']=1;}-->

  <!--{eval $_G['sign'] = dsign($_G['style']['directory'].'/touch'.$_G['style']['tplfile']);}-->
  <form method="post" autocomplete="off" name="diyform" id="diyform" action="$_G[siteurl]portal.php?mod=portalcp&ac=diy">
    <input type="hidden" name="template" value="$_G['style']['tplfile']" />
    <input type="hidden" name="tpldirectory" value="$_G['style']['directory']/touch" />
    <input type="hidden" name="diysign" value="$_G['sign']" />
    <input type="hidden" name="prefile" id="prefile" value="$_G['style']['prefile']" />
    <input type="hidden" name="savemod" value="$_G['style']['tplsavemod']" />
    <input type="hidden" name="spacecss" value="" />
    <input type="hidden" name="style" value="" />
    <input type="hidden" name="rejs" value="" />
    <input type="hidden" name="handlekey" value="" />
    <input type="hidden" name="layoutdata" value="" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="gobackurl" id="gobackurl" value=""/>
    <input type="hidden" name="recover" value=""/>
    <input type="hidden" name="optype" value=""/>
    <input type="hidden" name="diysubmit" value="true"/>
  </form>

</div>



<script src="{$_G['style'][tpldir]}/img/js/common_diy.js?{VERHASH}" charset="{CHARSET}"></script> 
<script src="{$_G['style'][tpldir]}/img/js/portal_diy.js?{VERHASH}" charset="{CHARSET}"></script> 
<script>

spaceDiy.init();
var SlideDistance = [];
var JSLOADED = [];

function checkblockname(form) {
	if(!(form.name.value) > '') {
		alert('name');
		return false;
	}
	if(form.summary && form.summary.value) {
		var tag = blockCheckTag(form.summary.value, true);
		if(tag) {
			showBlockSummary();
			form.summary.focus();
			alert('\u6807\u7b7e\u4e0d\u5339\u914d');
			return false;
		}
	}

	return true;
}
function block_delete_item(bid, itemid, itemtype, itemfrom, from) {
	var msg = '\u60a8\u786e\u5b9a\u8981\u5220\u9664\u8be5\u6570\u636e\u5417\uff1f';
	if(confirm(msg)) {
		var url = 'portal.php?mod=portalcp&ac=block&op=remove&bid='+bid+'&itemid='+itemid;
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
		$.ajax({
			type : 'GET',
			url : url + '&inajax=1',
			dataType : 'xml'
		}).success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			//evalscript(s.lastChild.firstChild.nodeValue);
		});
		return false;
	}

}


function tabnav(obj) {
	var obj = $(obj);
	event.preventDefault();
	popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	$.ajax({
		type : 'GET',
		url : SITEURL+obj.attr('href') + '&inajax=1',
		dataType : 'xml'
	}).success(function(s) {
		popup.open(s.lastChild.firstChild.nodeValue);
		evalscript(s.lastChild.firstChild.nodeValue);
	});
	return false;
}

$(document).on('click', '.frameimportbutton', function() {
	var obj = $(this);
	var formobj = $(this.form);
	popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	$.ajax({
		type:'POST',
		url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
		data:formobj.serialize(),
		dataType:'xml'
	})
	.success(function(s) {
		popup.open(s.lastChild.firstChild.nodeValue);
		//evalscript(s.lastChild.firstChild.nodeValue);
	})
	.error(function() {
		popup.close();
	});
	return false;
});
function showWindow(id, href){
	var obj = window.event.srcElement || window.event.target;
	$(document).on('click', '#'+obj.id, function() {
		return false;
	});
	popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	$.ajax({
		type : 'GET',
		url : href + '&inajax=1',
		dataType : 'xml'
	})
	.success(function(s) {
		popup.open(s.lastChild.firstChild.nodeValue);
		evalscript(s.lastChild.firstChild.nodeValue);
	});
	return false;
}

$(document).on('click', '.diyformdialog', function() {
	popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	var obj = $(this);
	var formobj = $(this.form);
	$.ajax({
		type:'POST',
		url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
		data:formobj.serialize(),
		dataType:'xml'
	})
	.success(function(s) {
		popup.open(s.lastChild.firstChild.nodeValue);
		//evalscript(s.lastChild.firstChild.nodeValue);
		
	})
	return false;
});
function strLenCalc(obj, checklen, maxlen) {
	var v = obj.value, charlen = 0, maxlen = !maxlen ? 200 : maxlen, curlen = maxlen, len = v.length;
	if(maxlen < len) {
		obj.value = mb_cutstr(v, maxlen, 0);
		$('#'+checklen).html(maxlen);
	} else {
		$('#'+checklen).html(len);
	}
}

function mb_cutstr(str, maxlen, dot) {
	var len = 0;
	var ret = '';
	var dot = !dot ? '...' : dot;
	maxlen = maxlen - dot.length;
	for(var i = 0; i < str.length; i++) {
		len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? (charset == 'utf-8' ? 3 : 2) : 1;
		if(len > maxlen) {
			ret += dot;
			break;
		}
		ret += str.substr(i, 1);
	}
	return ret;
}

</script>
