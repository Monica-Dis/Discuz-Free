<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{if $op != ''}-->
<div class="bm_c">{lang user_mobile_pm_error}</div>
<!--{else}-->


<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>{lang send_pm}</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>	
<!-- header end -->
<!-- main start -->
<div class="mumucms_wrap mumucms_mypmlist">
	<div class="mumucms_psot_forum">
	<form id="pmform_{$pmid}" name="pmform_{$pmid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=pm&op=send&touid=$touid&pmid=$pmid&mobile=2" >
		<input type="hidden" name="referer" value="{echo dreferer();}" />
		<input type="hidden" name="pmsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if !$touid}-->
		<div class="mumucms_zyjg">
		<div class="tit">{lang addressee}</div>
		<div class="sum">
			<input type="text" value="" tabindex="1" class="px" size="30" autocomplete="off" id="username" name="username">
			<a href="home.php?mod=space&do=friend&mobile=2"><i class="iconfont icon-renyuan"></i></a>
		</div>
		</div>
		<!--{/if}-->
		<div class="mumucms_tljg">
		<div class="tit">{lang thread_content}</div>
		<div class="sum"><textarea class="pt" tabindex="2" autocomplete="off" value="" id="sendmessage" name="message" cols="80" rows="7"  placeholder="{lang thread_content}"></textarea></div>
		</div>	
		<div class="mumucms_pobut">
		<button id="pmsubmit_btn" disable="true" class="mumucms_fbbut mumucms_button mumucms_button_large mumucms_fbbut_grey"><span>{lang sendpm}</span></button></span>
		<input type="hidden" name="pmsubmit_btn" value="yes" />
		</div>			
	</form>
	</div>
</div>	
<!-- main start -->
<script type="text/javascript">
	(function() {
		$('#sendmessage').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				$('#pmsubmit_btn').addClass('mumucms_primary');
				$('#pmsubmit_btn').attr('disable', 'false');
			} else {
				$('#pmsubmit_btn').removeClass('mumucms_primary');
				$('#pmsubmit_btn').attr('disable', 'true');
			}
		});
		var form = $('#pmform_{$pmid}');
		$('#pmsubmit_btn').on('click', function() {
			var obj = $(this);
			if(obj.attr('disable') == 'true') {
				return false;
			}
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey='+form.attr('id')+'&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				popup.open('{lang networkerror}', 'alert');
			});
			return false;
			});
	 })();
</script>
<!--{/if}-->
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<!--{eval $mumucms_scrollmenu = true;}-->
<!--{template common/footer}-->

