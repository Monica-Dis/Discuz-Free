<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{if $_GET['op'] == 'delete'}-->
<!--{if $_G[inajax]}-->
	<form id="favoriteform_{$favid}" name="favoriteform_{$favid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favid&type=$_GET[type]" {if $_G[inajax] && $_GET[type]!='view'} onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="mumucms_tip">
			<dt>{lang delete_favorite_message}</dt>
			<dd><a href="javascript:;" onclick="popup.close();">取消</a>
				<input class="button2" type="submit" name="deletesubmitbtn" value="{lang determine}"></dd>
		</div>
	</form>
<!--{/if}-->	
<!--{/if}-->

<!--{template common/footer}-->
