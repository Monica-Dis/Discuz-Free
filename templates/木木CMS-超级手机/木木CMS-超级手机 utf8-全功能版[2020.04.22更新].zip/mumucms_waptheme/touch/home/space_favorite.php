<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>{lang myfavorite}</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<div class="mumucms_wrap mumucms_favorite">

<div class="mumucms_type">
	<div class="cl">
	<div class="types{if $_GET['type'] == 'all'} active{/if}"><a href="home.php?mod=space&do=favorite&type=all">{lang favorite_all}</a></div>	
	<div class="types{if $_GET['type'] == 'thread'} active{/if}"><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang favthread}</a></div>	
	<div class="types{if $_GET['type'] == 'forum'} active{/if}"><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=forum">{lang favforum}</a></div>
	<!--{if helper_access::check_module('group')}-->
	<div class="types{if $_GET['type'] == 'group'} active{/if}"><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=group">收藏{lang favorite_group}</a></div>
	<!--{/if}-->
	<!--{if helper_access::check_module('blog')}-->
	<div class="types{if $_GET['type'] == 'blog'} active{/if}"><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=blog">收藏{lang favorite_blog}</a></div>
	<!--{/if}-->
	<!--{if helper_access::check_module('album')}-->
	<div class="types{if $_GET['type'] == 'album'} active{/if}"><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=album">收藏{lang favorite_album}</a></div>
	<!--{/if}-->
	<!--{if helper_access::check_module('portal')}-->
	<div class="types{if $_GET['type'] == 'article'} active{/if}"><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=article">收藏{lang favorite_article}</a></div>
	<!--{/if}-->
	<!--{hook/space_favorite_nav_extra}-->
	</div>
</div>

<!-- main collectlist start -->
<!--{if $_GET['type'] == 'forum'}-->
<div class="mumucms_flist">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li><a class="tit" href="$value[url]"><div class="text">$value[title]</div></a>
			<a class="delete dialog" href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k"><i class="iconfont icon-error"></i></a>	
			</li>
			<!--{/loop}-->
		<!--{else}-->
		<li><a href="javascript:;"><div class="text">{lang no_favorite_yet}</div></a></li>
		<!--{/if}-->
	</ul>
</div>
<!--{else}-->
<div class="mumucms_flist">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li><a class="tit" href="$value[url]"><div class="text">$value[title]</div></a>
			<a class="delete dialog" href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k"><i class="iconfont icon-error"></i></a>
			</li>
			<!--{/loop}-->
		<!--{else}-->
		<li><a href="javascript:;"><div class="text">{lang no_favorite_yet}</div></a></li>
		<!--{/if}-->
	</ul>		
</div>
<!--{/if}-->
<!-- main collectlist end -->
$multi
</div>
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript">
mumucms('.mumucms_type').scrollX(4, '.types');
</script>
<script type="text/javascript">
var info_head_top = jQuery(".mumucms_type").offset().top;
jQuery(document).scroll(function(){
    var scrtop = jQuery(this).scrollTop()
    if(scrtop>info_head_top){
        jQuery(".mumucms_type").removeClass("mumucms_not_xuanfu").addClass("mumucms_xuanfu");
        jQuery("#back").show();
    }
    else{
        jQuery(".mumucms_type").removeClass("mumucms_xuanfu").addClass("mumucms_not_xuanfu");
        jQuery("#back").hide();
    }
});
</script>
<!--{eval $mumucms_scrollmenu = true;}-->
<!--{template common/footer}-->

