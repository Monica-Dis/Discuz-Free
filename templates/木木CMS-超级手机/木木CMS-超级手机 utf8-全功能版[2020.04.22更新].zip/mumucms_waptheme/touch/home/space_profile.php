<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !$_GET['mycenter']}-->

<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1><!--{if $_G['uid'] == $space['uid']}-->{lang myprofile}<!--{else}-->$space[username]{lang otherprofile}<!--{/if}--></h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<!-- header end -->
<!-- userinfo start -->
<div class="mumucms_wrap mumucms_myprofile">
<div class="mumucms_userinfo">
	<div class="user_avatar">
		<div class="mumumcs_ico_bgimg">
		   <img src="{avatar($space['uid'], big, true)}">
		</div>
		<div class="mumucms_ico_bgcolor"></div>
		<div class="avatar_m">
			<img src="{avatar($space['uid'], middle, true)}" />
			<div class="name">
				<h2>$space[username]
				<!--{if $space[gender] == 1}-->
				<i class="iconfont icon-nan"></i>
				<!--{elseif $space[gender] == 2}-->
				<i class="iconfont icon-nv girl"></i>
				<!--{/if}-->
				</h2>
			</div>
			<div class="mumucms_bq">
				{if !empty($space[resideprovince])}<span><i class="iconfont icon-ditu"></i>{$space[resideprovince]}</span>{/if}{if !empty($space[occupation])}<span>{$space[occupation]}</span>{/if}
			</div>
			<p class="bio">
				<!--{if !empty($space[bio])}-->
				$space[bio]
				<!--{else}-->
				这家伙很懒什么也没留下！
				<!--{/if}-->
			</p>
		</div>
		<div class="mumucms_bl_box">
			<i class="mumucms_bl bl_top"></i>
			<i class="mumucms_bl bl_down"></i>
		</div>
	</div>	
	<div class="mumucms_userbox">
		<ul>
			<li><span>{lang credits}</span><div class="mumucms_frinfo">$space[credits]</div></li>
			<!--{loop $_G[setting][extcredits] $key $value}-->
			<!--{if $value[title]}-->
			<li><span>$value[title]</span><div class="mumucms_frinfo">{$space["extcredits$key"]} $value[unit]</div></li>
			<!--{/if}-->
			<!--{/loop}-->
		</ul>
	</div>
	<!--{if $space['uid'] == $_G['uid']}-->
	<div class="mumucms_btn_exit"><a class="mumucms_button mumucms_button_large mumucms_primary" href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout_mobile}</a></div>
	<!--{/if}-->
</div>
</div>
<!-- userinfo end -->

<!--{else}-->

<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>$_G[setting][bbname]</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<div class="mumucms_wrap mumucms_home">

<!-- userinfo start -->
<div class="mumucms_userinfo">
	<div class="user_avatar">
		<a href="home.php?mod=spacecp&ac=profile&op=base">
		<div class="avatar_m">
			<img src="{avatar($space['uid'], middle, true)}" />
		</div>
		<div class="user_name">
			<h2 class="name">$space[username]</h2>
			<p class="bio">
				<!--{if !empty($space[bio])}-->
				$space[bio]
				<!--{else}-->
				设置个性签名，会有更多的人关注您哦
				<!--{/if}-->
			</p>
			<i class="iconfont icon-yjiantou"></i>
		<!--{if $space[profileprogress] != 100}-->
			<div class="mumucms_prog">
				<div class="mumucms_pbg"><div class="mumucms_pbr mumucms_bgcolor" style="width: {if $space[profileprogress] < 2}2{else}$space[profileprogress]{/if}%;">$space[profileprogress]%&nbsp;</div></div>
			</div>
		<!--{/if}-->			
		</div>
		</a>
	</div>
	<div class="mumucms_zxlist">
		 <ul>
		 	
		 		 <li>
	                <a href="home.php?mod=space&do=friend">
	                    <div class="zxlist_icons">
	                       <i class="iconfont icon-renyuan" style="color:#FFA800;"></i>
	                    </div>
	                    <div class="zxlist_text favorite">我的好友<i class="iconfont icon-yjiantou"></i></div>
	                </a>
	            </li>
	            <li>
	                <a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=all">
	                    <div class="zxlist_icons">
	                       <i class="iconfont icon-aixin" style="color:#F37D7D;"></i>
	                    </div>
	                    <div class="zxlist_text favorite">{lang myfavorite}<i class="iconfont icon-yjiantou"></i></div>
	                </a>
	            </li>
	            <li>
	                <a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me">
	                    <div class="zxlist_icons">
	                      <i class="iconfont icon-tiezi" style="color:#00C5C7;"></i>
	                    </div>
	                    <div class="zxlist_text">{lang mythread}<i class="iconfont icon-yjiantou"></i></div>
	                </a>
	            </li>
	            <li>
	                <a href="home.php?mod=space&do=pm">
	                    <div class="zxlist_icons">
	                        <i class="iconfont icon-xiaoxi" style="color:#9DCA08;"></i>
	                    </div>
	                    <div class="zxlist_text">{lang mypm}<i class="iconfont icon-yjiantou"></i></div>
	                </a>
	            </li>
	            <li>
	                <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mobile=2">
	                    <div class="zxlist_icons">
	                        <i class="iconfont icon-ziliao" style="color:#FF9900;"></i>
	                    </div>
	                    <div class="zxlist_text">{lang myprofile}<i class="iconfont icon-yjiantou"></i></div>
	                </a>
	            </li>  
	            <li>
	                <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="dialog">
	                    <div class="zxlist_icons">
	                        <i class="iconfont icon-tuichu" style="color:#00C5C7;"></i>
	                    </div>
	                    <div class="zxlist_text">退出登录<i class="iconfont icon-yjiantou"></i></div>
	                </a>
	            </li>                                   
		 </ul>	
	</div>
</div>	
<!-- userinfo end -->
</div>
<!--{/if}-->
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<!--{template common/footer}-->

