<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{if $op=='blockclass'}-->
	<div class="tbmu" id="contentblockclass_nav">
		<!--{eval $isfirst=1;}-->
		<!--{loop $_G['cache']['blockclass'] $key $value}-->
		<!--{if $isfirst}-->
		<!--{eval $isfirst=0;}-->
		<a href="javascript:;" id="bcnav_$key" class="a" onclick="spaceDiy.switchBlockclass('$key');return false;">$value[name]</a>
		<!--{else}-->
		<a href="javascript:;" id="bcnav_$key" onclick="spaceDiy.switchBlockclass('$key');return false;">$value[name]</a>
		<!--{/if}-->
		<!--{/loop}-->
	</div>
	<!--{eval $isfirst=1;}-->
	<!--{loop $_G['cache']['blockclass'] $key $value}-->
	<!--{if $isfirst}-->
	<!--{eval $isfirst=0;}-->
	<ul class="blocks_content" id="contentblockclass_$key">
	<!--{else}-->
	<ul class="blocks_content" id="contentblockclass_$key" style="display:none;">
	<!--{/if}-->
			<!--{loop $value[subs] $skey $svalue}-->
				<li class="module-$skey"><label onmousedown="drag.createObj (event,'block','$skey');" onmouseover="className='hover';" onmouseout="this.className='';">$svalue[name]</label></li>
			<!--{/loop}-->
	</ul>
	<!--{/loop}-->
<!--{elseif $op == 'style'}-->
<ul class="content" style="overflow-y: auto; height: 90px;">
<!--{loop $themes $value}-->
  <li><a href="javascript:;" onclick="spaceDiy.changeStyle('$value[dir]');return false;"><img src="{STATICURL}$value['dir']/preview.jpg" />$value['name']</a></li>
<!--{/loop}-->
</ul>
<!--{elseif $_GET['op'] == 'image'}-->
	<div id="diyimg_prev" class="z">$multi</div>
	<ul id="imagebody">
		<!--{loop $list $key $value}-->
		<li class="thumb"><a href="javascript:;" onclick="return false;"><img src="$value[pic]" alt="" onclick="spaceDiy.setBgImage(this);"/></a></li>
		<!--{/loop}-->
	</ul>
	<div id="diyimg_next" class="z">$multi</div>
<!--{elseif $_GET['op'] == 'diy'}-->
<dl class='diy'>
	<dt class="cl pns">
		<div class="y">
			<button type="button" id="uploadmsg_button" onclick="Util.toggleEle('upload');" class="pn pnc z{if empty($list)} hide{/if}"><span>{lang diy_upload_image}</span></button>
			<div id="upload" class="z{if $list} hide{/if}"><iframe id="uploadframe" name="uploadframe" width="0" height="0" marginwidth="0" frameborder="0" src="about:blank"></iframe>
				<form method="post" autocomplete="off" name="uploadpic" id="uploadpic" action="portal.php?mod=portalcp&ac=diy" enctype="multipart/form-data" target="uploadframe" onsubmit="return spaceDiy.uploadSubmit();">
					<input type="file" class="t_input" name="attach" size="15">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="topicid" value="$_GET[topicid]" />
					<button type="submit" name="uploadsubmit" id="btnupload" class="pn" value="true"><span>{lang diy_update_start}</span></button>
				</form>
			</div>
			<span id="uploadmsg" class="z"></span>
		</div>
		{lang diy_editing}:
		<a id="diy_tag_body" href="javascript:;" onclick="spaceDiy.setCurrentDiy('body');return false;">{lang background}</a>
		<span class="pipe">|</span><a id="diy_tag_blocktitle" href="javascript:;" onclick="spaceDiy.setCurrentDiy('blocktitle');return false;">{lang title_bar}</a></span>
		<span class="pipe">|</span><a id="diy_tag_ct" href="javascript:;" onclick="spaceDiy.setCurrentDiy('ct');return false;">{lang content_area}</a>

	  	<a style="margin-left: 40px;" id="bg_button" href="javascript:;" onclick="spaceDiy.hideBg();return false;">{lang background_image_cancel}</a>
		<span class="pipe">|</span><a id="recover_button" href="javascript:;" onclick="spaceDiy.recoverStyle();return false;">{lang restore_skin}</a>
	</dt>
	<dd>
		<div class="photo_list cl">
			<div id="currentimgdiv" class="z" style="width:446px;">
				<center><ul><li class="thumb" style="border:1px solid #ccc; padding:2px;"><img id="currentimg" alt="" src=""/></li></ul>
				<div class="z cur1" onclick="spaceDiy.changeBgImgDiv();">{lang diy_change}</div></center>
			</div>
			<div id="diyimages" class="z" style="width: 446px; display: none">
				<div id="diyimg_prev" class="z">$multi</div>
				<ul id="imagebody">
					<!--{loop $list $key $value}-->
					<li class="thumb"><a href="javascript:;" onclick="return false;"><img src="$value[pic]" alt="" onclick="spaceDiy.setBgImage(this);"/></a></li>
					<!--{/loop}-->
				</ul>
				<div id="diyimg_next" class="z">$multi</div>
			</div>
			<div class="z" style="padding-left: 7px; width: 160px; border: solid #CCC; border-width: 0 1px;">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td><label for="repeat_mode">{lang image_repeat_mode}:</label></td>
						<td>
							<select id="repeat_mode" name="repeat_mode" class="ps" onclick="spaceDiy.setBgRepeat(this.value);">
								<option value="0" selected="selected">{lang image_repeat}</option>
								<option value="1">{lang image_repeat_direct}</option>
								<option value="2">{lang image_repeat_horizontal}</option>
								<option value="3">{lang image_repeat_vertical}</option>
							</select>
						</td>
					</tr>
					<tr>
						<td>{lang image_position}:</td>
						<td>
							<table cellpadding="0" cellspacing="0" id="positiontable">
								<tr>
									<td id="bgimgposition0" onclick="spaceDiy.setBgPosition(this.id)">&nbsp;</td>
									<td id="bgimgposition1" onclick="spaceDiy.setBgPosition(this.id)">&nbsp;</td>
									<td id="bgimgposition2" onclick="spaceDiy.setBgPosition(this.id)">&nbsp;</td>
								</tr>
								<tr>
									<td id="bgimgposition3" onclick="spaceDiy.setBgPosition(this.id)">&nbsp;</td>
									<td id="bgimgposition4" onclick="spaceDiy.setBgPosition(this.id)">&nbsp;</td>
									<td id="bgimgposition5" onclick="spaceDiy.setBgPosition(this.id)">&nbsp;</td>
								</tr>
								<tr>
									<td id="bgimgposition6" onclick="spaceDiy.setBgPosition(this.id)">&nbsp;</td>
									<td id="bgimgposition7" onclick="spaceDiy.setBgPosition(this.id)">&nbsp;</td>
									<td id="bgimgposition8" onclick="spaceDiy.setBgPosition(this.id)">&nbsp;</td>
								</tr>
							</table>
						</td>
					</tr>
				</table>
			</div>
			<div class="z diywin" style="padding-left: 7px; width: 160px;">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td>{lang background_attach_mode}:</td>
						<td>
							<label for="rabga0"><input type="radio" id="rabga0" name="attachment_mode" onclick="spaceDiy.setBgAttachment(0);" class="pr" />{lang background_attach_scroll}</label>
							<label for="rabga1"><input type="radio" id="rabga1" name="attachment_mode" onclick="spaceDiy.setBgAttachment(1);" class="pr" />{lang background_attach_fixed}</label>
						</td>
					</tr>
					<tr>
						<td>{lang background_color}:</td>
						<td><input type="text" id="colorValue" value="" size="6" onchange="spaceDiy.setBgColor(this.value);" class="px vm" style="font-size: 12px; padding: 2px;" />
						<input id="cbpb" onclick="createPalette('bpb', 'colorValue', 'spaceDiy.setBgColor');" type="button" class="pn colorwd" value="" />
						</td>
					</tr>
				</table>
			</div>
			<div class="z diywin" style="padding-left: 7px; width: 160px;">
				<table cellpadding="0" cellspacing="0">
					<tr>
						<td>{lang text_color}:</td>
						<td><input type="text" id="textColorValue" value="" size="6" onchange="spaceDiy.setTextColor(this.value);" class="px vm" style="font-size: 12px; padding: 2px;" />
						<input id="ctpb" onclick="createPalette('tpb', 'textColorValue', 'spaceDiy.setTextColor');" type="button" class="pn colorwd" value="" />
						</td>
					</tr>
					<tr>
						<td>{lang link_color}:</td>
						<td><input type="text" id="linkColorValue" value="" size="6" onchange="spaceDiy.setLinkColor(this.value);" class="px vm" style="font-size: 12px; padding: 2px;" />
						<input id="clpb" onclick="createPalette('lpb', 'linkColorValue', 'spaceDiy.setLinkColor');" type="button" class="colorwd" value="" style="background: #fff;" />
						</td>
					</tr>
				</table>
			</div>
  </dd>
</dl>
<!--{elseif $op == 'import'}-->
<div class="mumucms_diy_block">
	<div class="diy_header">
		<ul class="tb cl">
			<li{if empty($_GET['type'])} class="current"{/if} id="li_import_upload"><a  href="plugin.php?id=mumucms_wapcontrol:mumucms_wapcontrol_diy&op=import&type=0&tpl=$_GET['tpl']" class="dialog">{lang diy_uploadfile}</a></li>
			<li{if $_GET['type'] == 1} class="current"{/if} id="li_import_system"><a href="plugin.php?id=mumucms_wapcontrol:mumucms_wapcontrol_diy&op=import&type=1&tpl=$_GET['tpl']" class="dialog">{lang diy_systemfile}</a></li>
		</ul>
	</div>
  <form name="frameimport" id="frameimport" method="post" action="plugin.php?id=mumucms_wapcontrol:mumucms_wapcontrol_diy&op=import">
	<div class="diy_win">	
		<div class="diy_import">
		<!--{if $_GET['type'] == 1}-->
			<!--{if $xmlarr}-->
			<select id="importfilename" name="importfilename" class="">
				<option value="">{lang import_select_file}:</option>
				<!--{loop $xmlarr $key $value}-->
				<option value="$key">$value</option>
				<!--{/loop}-->
			</select>
			<!--{else}-->
			<center>{lang import_system_file_no_exists}</center>
			<!--{/if}-->
		<!--{else}-->
		 <div id="importfile" class="importfile">&nbsp;</div>
		<!--{/if}-->
		</div>
		<div class="diy_button">
	      <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
	      <input type="hidden" name="importsubmit" value="true" />
	      <input type="hidden" name="tpl" value="$_GET['tpl']" />
	      <input type="hidden" name="formhash" value="{FORMHASH}" />
	      <button type="submit" class="pn pnc <!--{if $_GET['type'] == 1}-->frameimportbutton<!--{/if}-->" id="frameimportbutton"><strong>{lang import}</strong></button>
	      <button type="button" class="pn pnx" onclick="popup.close();"><strong>{lang cancel}</strong></button>
		</div>
	</div>	
</form>

<!--{if $_GET['type'] != 1}--> 

<script type="text/javascript" src="source/plugin/mumucms_wapcontrol/static/js/webuploader.min.js"></script>

<!--{/if}--> 

<script>
/*{echo rand();}*/
<!--{if $_GET['type'] == 1}-->
$(document).on('click', '#frameimportbutton', function() {
	var obj = $(this);
	var formobj = $(this.form);
	popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	$.ajax({
		type:'POST',
		url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
		data:formobj.serialize(),
		dataType:'xml'
	})
	.success(function(s) {
		//popup.open(s.lastChild.firstChild.nodeValue);
		evalscript(s.lastChild.firstChild.nodeValue);
	})
	.error(function() {
		alert('\u5bfc\u5165\u5931\u8d25');
	});
	return false;
});
<!--{else}-->
var uploader = WebUploader.create({
	swf: '{$_G[siteurl]}source/plugin/mumucms_wapcontrol/static/images/Uploader.swf',
	server: 'plugin.php?id=mumucms_wapcontrol:mumucms_wapcontrol_diy&op=import&inajax=1',
	formData: {handlekey:"$_GET[handlekey]",importsubmit:"true",tpl:"$_GET['tpl']",formhash:"{FORMHASH}"},
	fileVal: 'importfile',
	pick: '.importfile'
});
uploader.on('uploadBeforeSend', function( block, data, headers) {
	data.id = 'mumucms_wapcontrol:mumucms_wapcontrol_diy';
});
uploader.on('uploadSuccess', function(file, s) {
    if(document.all){ 
        var xmlDom = new ActiveXObject("Microsoft.XMLDOM"); 
        xmlDom.loadXML(s._raw);
        var c = xmlDom;
    }else{
         var c = new DOMParser().parseFromString(s._raw, "text/xml");
    }
	//popup.open(c.lastChild.firstChild.nodeValue);
	evalscript(c.lastChild.firstChild.nodeValue);
});
$(document).on('click', '#frameimportbutton', function() {
	uploader.upload();
	popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	return false;
});
<!--{/if}-->
var Running = false;
function succeedhandle_$_GET['handlekey'](url, message, values) {
	if(!Running){
		if (values['status'] == '1') {
			Running = true;
			if (values['css']) Diy.initDiyStyle(values['css']);
			var areaArr = values['html'];
			var dom = document.createElement("div");
			for (var i in areaArr) {
				var html = areaArr[i].replace(/\[script/g, '<script').replace(/\[\/script\]/g, '<\/script>');
				var area = document.getElementById(i);
				dom.innerHTML = html;
				var arr = [];
				for (var i=0, l=dom.childNodes.length; i < l; i++) {
					arr.push(dom.childNodes[i]);
				}
				var one = '';
				while(one = arr.pop()) {
					$(area).prepend(one);
				}
			}
			
			Diy.blockForceUpdateBatch();
			popup.close();
		}else{
			alert('\u5bfc\u5165\u5931\u8d25');
		}	
	}
}
</script> 
<!--{/if}-->
<!--{template common/footer}-->
