<?php echo 'From: DisM.taobao.com';exit;?>
<div id="comment" class="mumucms_comment">
	<div class="mumucms_box cl">
		<span class="mumucms_fr"><a href="$common_url">$data[commentnum]条评论</a></span>
		<h2>{lang latest_comment}</h2>
	</div>
	<div id="comment_ul" class="bm_c">
		<!--{if $data[commentnum]}-->
			<!--{loop $commentlist $comment}-->
			<!--{template portal/comment_li}-->
			<!--{if !empty($aimgs[$comment[cid]])}-->
				<script type="text/javascript" reload="1">aimgcount[{$comment[cid]}] = [<!--{echo implode(',', $aimgs[$comment[cid]]);}-->];attachimgshow($comment[cid]);</script>
			<!--{/if}-->
			<!--{/loop}-->
			<!--{if !empty($pricount)}-->
				<p class="mtn mbn y">{lang hide_portal_comment}</p>
			<!--{/if}-->
		<!--{else}-->
		<div class="mumucms_zanwu">
			<i class="iconfont icon-zanwu"></i>
			<p>暂无评论,快来抢沙发</p>
		</div>
		<!--{/if}-->
		<div class="mumucms_bpop_main">
			<div class="mumucms_viewfoot_zw"></div>
			<div class="mumucms_viewfoot">
			<ul class="cl">
				<li><a href="javascript:;" class="mumucms_open_shaer_bpop"><i class="iconfont icon-ziyuan"></i></a></li>		
				<li><a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" class="favbtn"><i class="iconfont icon-shoucang"></i></a></li>
				<li><a href="javascript:;" class="mumucms_open_bpop"><i class="iconfont icon-pinglun"></i><em class="zannum" {if !$data[commentnum]} style="display:none"{/if}>$data[commentnum]</em></a></li>
				<li class="post"><a href="javascript:;" class="mumucms_open_bpop"><span>{lang send_reply_fast_tip}...</span></a></li>
			</ul>
			</div>
			<div class="mumucms_shaer_bpop mumucms_shaer_bpop_hover">
				<div class="mumucms_share">
					<div class="social-share" data-initialized="false" data-mode="prepend" data-url="{$_G['siteurl']}portal.php?mod=view&aid=$article[aid]"  data-title="$article[title]">
						<a href="#" class="share-qq"><i class="iconfont icon-qq1"></i><p>QQ好友</p></a>
			            <a href="#" class="share-qzone"><i class="iconfont icon-kongjian"></i><p>QQ空间</p></a>
			            <a href="#" class="share-weibo"><i class="iconfont icon-weibo1"></i><p>新浪微博</p></a>
			            <a href="#" class="share-douban"><i class="iconfont icon-douban"></i><p>豆瓣</p></a>
		            	<a href="#" class="share-linkedin"><i class="iconfont icon-linkedin"></i><p>linkedin</p></a>
			            <a href="#" class="share-facebook"><i class="iconfont icon-facebook"></i><p>facebook</p></a>
			            <a href="#" class="share-twitter"><i class="iconfont icon-twitter"></i><p>twitter</p></a>
			            <a class="mumucms_copylink" id="mumucms_copylink"><i class="iconfont icon-fuzhilianjie"></i><p>复制链接</p></a>
			        </div>
			    </div> 
				<div class="mumucms_share_qx mumucms_close_shaer_bpop">取消</div>
			</div>
			<div class="mumucms_shaer_bpop_mask"></div>
			<div class="mumucms_bpop mumucms_bpop_hover">
				<header class="mumucms_wapheader">
				    <div class="mumucms_icon"></div>
				    <h1>{lang post_comment}</h1>
				    <div class="mumucms_icon mumucms_close_bpop"><i class="iconfont icon-error"></i></div>
				</header>
			<div class="mumucms_contents">
				<div class="mumucms_fastpost">
				<!--{if !$data[htmlmade]}-->
				<form id="cform" name="cform" action="$form_url" method="post" autocomplete="off">
				<div class="mumucms_post_pi">
					<div class="post_sum">
						<textarea name="message" placeholder="{lang send_reply_fast_tip}" rows="3" class="mumucms_grey grey" color="gray" id="message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');"></textarea>
					</div>
					<div id="fastpostsubmitline" style="display:none;">
										<!--{if $secqaacheck || $seccodecheck}-->
							<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
							<div class="mtm"><!--{subtemplate common/seccheck}--></div>
						<!--{/if}-->
					</div>
					<!--{if !empty($topicid) }-->
						<input type="hidden" name="referer" value="$topicurl#comment" />
						<input type="hidden" name="topicid" value="$topicid">
					<!--{else}-->
						<input type="hidden" name="portal_referer" value="$viewurl#comment">
						<input type="hidden" name="referer" value="$viewurl#comment" />
						<input type="hidden" name="id" value="$data[id]" />
						<input type="hidden" name="idtype" value="$data[idtype]" />
						<input type="hidden" name="aid" value="$aid">
					<!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}">
					<input type="hidden" name="replysubmit" value="true">
					<input type="hidden" name="commentsubmit" value="true" />			
					<div class="post_bt">
						<a href="javascript:void(0)" class="mumucms_face"><i class="iconfont icon-biaoqing"></i></a>
						<a href="$common_url"><i class="iconfont icon-tupian"></i></a>
						<div id="fastpostsubmitline" class="post_but">
							<input type="submit" value="{lang comment}" class="button" name="commentsubmit_btn" id="commentsubmit_btn">
						</div>
					</div>
				</div>
			    </form>
			    <!--{/if}-->
				<div id="mumucms_face"></div>
				<script src="{$_G['style'][tpldir]}/img/face/mumucms.face.js" charset="{CHARSET}"></script>
				<script type="text/javascript">
					$(function (){
						$("a.mumucms_face").mumucmsfacebox({
							Event : "click",	//触发事件	
							divid : "mumucms_face", //外层DIV ID
							textid : "message" //文本框 ID
						});
					});
				</script>
				</div>
			</div>
			</div>	
			<div class="mumucms_bpop_mask"></div>
		</div>		
	</div>
</div>
<script type="text/javascript">
	(function() {
		$('#message').on('focus', function() {
				$('#fastpostsubmitline').css('display', 'block');
		})
	})();
</script>

