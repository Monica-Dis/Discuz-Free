<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>{lang comment_view}</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>

<div class="mumucms_wrap mumucms_view mumucms_news_view">

	<div class="mumucms_vw">
		<div class="mumucms_tit mumucms_boeder_bottom">
		<h1 class="ph"><a href="$url">$csubject[title]</a></h1>
		</div>
		<!--{if $csubject[commentnum]}-->
			<!--{loop $commentlist $comment}-->
				<!--{template portal/comment_li}-->
			<!--{/loop}-->
			<!--{if $pricount}-->
				<p class="mbn mtn y">{lang hide_portal_comment}</p>
			<!--{/if}-->
			<div class="pgs cl mtm mbm">$multi</div>
		<!--{else}-->
		<div class="mumucms_zanwu">
			<i class="iconfont icon-zanwu"></i>
			<p>暂无评论,快来抢沙发</p>
		</div>
		<!--{/if}-->
	</div>			
		<!--{if $csubject['allowcomment'] == 1}-->
		<div class="mumucms_bpop_main">
			<div class="mumucms_viewfoot_zw"></div>
			<div class="mumucms_viewfoot">
			<ul class="cl">
				<li><a href="home.php?mod=spacecp&ac=favorite&type=article&id=$csubject[aid]&handlekey=favoritearticlehk_{$csubject[aid]}" class="favbtn"><i class="iconfont icon-shoucang"></i></a></li>		
				<li><a href="javascript:;" class="mumucms_open_bpop"><i class="iconfont icon-pinglun"></i><em class="zannum" {if !$csubject[commentnum]} style="display:none"{/if}>$csubject[commentnum]</em></a></li>
				<li class="post"><a href="javascript:;" class="mumucms_open_bpop"><span>{lang send_reply_fast_tip}...</span></a></li>
			</ul>
			</div>
			<div class="mumucms_bpop mumucms_bpop_hover">
				<header class="mumucms_wapheader">
				    <div class="mumucms_icon"></div>
				    <h1>{lang post_comment}</h1>
				    <div class="mumucms_icon mumucms_close_bpop"><i class="iconfont icon-error"></i></div>
				</header>
			<div class="mumucms_contents">
				<div class="mumucms_fastpost">
				<form id="cform" name="cform" action="portal.php?mod=portalcp&ac=comment" method="post" autocomplete="off">
				<div class="mumucms_post_pi">
					<div class="post_sum">
						<textarea name="message" placeholder="{lang send_reply_fast_tip}" rows="3" class="mumucms_grey grey" color="gray" id="message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');"></textarea>
					</div>
					<div id="fastpostsubmitline" style="display:none;">
						<!--{if $secqaacheck || $seccodecheck}-->
							<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
							<div class="mtm"><!--{subtemplate common/seccheck}--></div>
						<!--{/if}-->
					</div>
					<!--{if $idtype == 'topicid' }-->
						<input type="hidden" name="topicid" value="$id">
					<!--{else}-->
						<input type="hidden" name="aid" value="$id">
					<!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}">			
					<div class="post_bt">
						<a href="javascript:void(0)" class="mumucms_face"><i class="iconfont icon-biaoqing"></i></a>
						<div id="fastpostsubmitline" class="post_but">
							<input type="submit" value="{lang comment}" class="button" name="commentsubmit" id="commentsubmit_btn">
						</div>
					</div>
				</div>
			    </form>
			    <div id="mumucms_face"></div>
			    <script src="{$_G['style'][tpldir]}/img/face/mumucms.face.js" charset="{CHARSET}"></script>
				<script type="text/javascript">
					$(function (){
						$("a.mumucms_face").mumucmsfacebox({
							Event : "click",	//触发事件	
							divid : "mumucms_face", //外层DIV ID
							textid : "message" //文本框 ID
						});
					});
				</script>
				</div>
			</div>
			</div>	
			<div class="mumucms_bpop_mask"></div>
		</div>
		<!--{/if}-->
</div>
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>
<script type="text/javascript">
	(function() {
		$('#message').on('focus', function() {
				$('#fastpostsubmitline').css('display', 'block');
		})
	})();
</script>
<script type="text/javascript">
	jQuery('.mumucms_open_bpop').click(function(){
	    jQuery('.mumucms_bpop').removeClass('mumucms_bpop_hover');
		jQuery('.mumucms_bpop_mask').addClass('mumucms_bpop_block');
	});
	jQuery('.mumucms_close_bpop').click(function(){
	   jQuery('.mumucms_bpop').addClass('mumucms_bpop_hover');
	   jQuery('.mumucms_bpop_mask').removeClass('mumucms_bpop_block');	   
	});
	jQuery('.mumucms_bpop_mask').click(function(){
	   jQuery('.mumucms_bpop').addClass('mumucms_bpop_hover');
	   jQuery('.mumucms_bpop_mask').removeClass('mumucms_bpop_block');
	});
</script>

<script type="text/javascript">
    $('.reference').click(function () {
        var message = $.trim($(this).parents('.mumucms_plc').find('.message').html());
        var message = message.replace(/\<div class="quote"\>([\s\S]*?)\<\/div\>/g, '');
        var message = message.replace(/\<img src="static\/image\/smiley\/comcom\/([\s\S]*?).gif" class="vm" zsrc="static\/image\/smiley\/comcom\/([\s\S]*?).gif" style="display: inline; visibility: visible;">/g, '[em:$1:]');
		var author = $.trim($(this).parents('h3').find('.username').html());
        var dateline = $.trim($(this).parents('.mumucms_plc').find('.time span').html());
        $('.mumucms_grey').val('[quote]' + '引用' + ': ' + author + ' 发表于 ' + dateline + '\n' + message + '[/quote]\n');
    });
</script>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
