<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>$navtitle</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<div class="mumucms_wrap mumucms_view mumucms_news_view">

		<div class="mumucms_vw">
			<div class="mumucms_tit">
				<h1 class="ph">$article[title] <!--{if $article['status'] == 1}-->({lang moderate_need})<!--{elseif $article['status'] == 2}-->({lang ignored})<!--{/if}--></h1>
				<p class="xg">
					<span class="pipe">$article[dateline]</span>
					<span class="pipe"><a href="portal.php?mod=list&catid=$cat['catid']">$cat[catname]</a></span>
					<span class="pipe">{lang view_views}: <em id="_viewnum"><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}--></em></span>
					<span class="pipe">{lang view_comments}: <!--{if $article[commentnum] > 0}--><a href="$common_url" title="{lang view_all_comments}"><em id="_commentnum">$article[commentnum]</em></a><!--{else}-->0<!--{/if}--></span>
					<!--{if $article[author]}--><span class="pipe">{lang view_author_original}: $article[author]</span><!--{/if}-->
					<!--{if $article[from]}--><span class="pipe">{lang from}: <!--{if $article[fromurl]}--><a href="$article[fromurl]" target="_blank">$article[from]</a><!--{else}-->$article[from]<!--{/if}--></span><!--{/if}-->

					<!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
						<span class="pipe"><a href="portal.php?mod=portalcp&ac=article&op=edit&catid=$article[catid]&aid=$article[aid]">{lang edit}</a></span>
						<!--{if $article[status]>0 && ($_G['group']['allowmanagearticle'] || $categoryperm[$value['catid']]['allowmanage'])}-->
							<span class="pipe"><a href="portal.php?mod=portalcp&ac=article&op=verify&aid=$article[aid]" id="article_verify_$article[aid]" class="dialog">{lang moderate}</a></span>
						<!--{else}-->
							<span class="pipe"><a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$article[aid]" id="article_delete_$article[aid]" class="dialog">{lang delete}</a></span>
						<!--{/if}-->
					<!--{/if}-->
					<!--{hook/view_article_subtitle}-->
				</p>
			</div>
			<!--{if $article[summary] && empty($cat[notshowarticlesummay])}--><div class="mumucms_zy"><div class="mumucms_zysum"><strong>{lang article_description}</strong>$article[summary]</div><!--{hook/view_article_summary}--></div><!--{/if}-->
			<div class="mumucms_cont">				
				<table cellpadding="0" cellspacing="0" class="mumucms_vwtb"><tr><td id="article_content">
					<!--{ad/article/a_af/1}-->
					<!--{if $content[title]}-->
					<div class="vm_pagetitle xw1">$content[title]</div>
					<!--{/if}-->
				<!--{eval echo nl2br(str_replace(chr(32),' ',$content[content]));}-->	

				</td></tr></table>
				<!--{hook/view_article_content}-->
				<!--{if $multi}--><div class="ptw pbw cl">$multi</div><!--{/if}-->                            
				<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
				<div id="click_div" class="mumucms_click">
					<!--{template home/space_click}-->
				</div>
				<!--{hook/view__mumucms_donate}-->
				<!--{if !empty($contents)}-->
				<div id="inner_nav" class="ptn xs1">
					<h3>{lang article_inner_navigation}</h3>
					<ul class="xl xl2 cl">
						<!--{loop $contents $key $value}-->
						<!--{eval $curpage = $key+1;}-->
						<!--{eval $inner_view_url = helper_page::mpurl($viewurl, '&page=', $curpage);}-->
						<li>&bull; <a href="$inner_view_url"{if $key === $start} class="xi1"{/if}>{lang article_inner_page_pre} {$curpage} {lang article_inner_page} $value[title]</a></li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--{/if}-->
			</div>
			<!--{if !empty($aimgs[$content[pid]])}-->
				<script type="text/javascript" reload="1">aimgcount[{$content[pid]}] = [<!--{echo implode(',', $aimgs[$content[pid]]);}-->];attachimgshow($content[pid]);</script>
			<!--{/if}-->

			<!--{if !empty($_G['setting']['pluginhooks']['view_share_method'])}-->
				<div class="tshare cl">
					<strong>{lang viewthread_share_to}:</strong>
					<!--{hook/view_share_method}-->
				</div>
			<!--{/if}-->
			<!--{if $article['preaid'] || $article['nextaid']}-->
			<div class="mumucms_pren">
				<!--{if $article['prearticle']}--><a href="{$article['prearticle']['url']}">{lang pre_article}{$article['prearticle']['title']}</a><!--{/if}-->
				<!--{if $article['nextarticle']}--><a href="{$article['nextarticle']['url']}">{lang next_article}{$article['nextarticle']['title']}</a><!--{/if}-->
			</div>
			<!--{/if}-->
		</div>

		<!--{if $article['related']}-->
		<div id="related_article" class="mumucms_bm">
			<div class="mumucms_bm_h cl">
				<h3>{lang view_related}</h3>
			</div>
			<div class="bm_c">
				<ul class="xl xl2 cl" id="raid_div">
				<!--{loop $article['related'] $raid $rvalue}-->
					<input type="hidden" value="$raid" />
					<li>&bull; <a href="{$rvalue[uri]}">{$rvalue[title]}</a></li>
				<!--{/loop}-->
				</ul>
			</div>
		</div>
		<!--{/if}-->


		<!--{if $article['allowcomment']==1}-->
			<!--{eval $data = &$article}-->
			<!--{subtemplate portal/portal_comment}-->
		<!--{/if}-->

</div>


<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

</script>

<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript">
	jQuery('.mumucms_open_bpop').click(function(){
	    jQuery('.mumucms_bpop').removeClass('mumucms_bpop_hover');
		jQuery('.mumucms_bpop_mask').addClass('mumucms_bpop_block');
	});
	jQuery('.mumucms_close_bpop').click(function(){
	   jQuery('.mumucms_bpop').addClass('mumucms_bpop_hover');
	   jQuery('.mumucms_bpop_mask').removeClass('mumucms_bpop_block');	   
	});
	jQuery('.mumucms_bpop_mask').click(function(){
	   jQuery('.mumucms_bpop').addClass('mumucms_bpop_hover');
	   jQuery('.mumucms_bpop_mask').removeClass('mumucms_bpop_block');
	});
</script>
<!--{eval $agent = $_SERVER['HTTP_USER_AGENT'];}--> 
<!--{if strpos($agent,"Html5Plus") === false }-->
	<script type="text/javascript">
	
			jQuery('.mumucms_open_shaer_bpop').click(function(){
				jQuery('.mumucms_shaer_bpop').removeClass('mumucms_shaer_bpop_hover');
				jQuery('.mumucms_shaer_bpop_mask').addClass('mumucms_shaer_bpop_block');
			});				
			jQuery('.mumucms_close_shaer_bpop').click(function(){
			   jQuery('.mumucms_shaer_bpop').addClass('mumucms_shaer_bpop_hover');
			   jQuery('.mumucms_shaer_bpop_mask').removeClass('mumucms_shaer_bpop_block');	   
			});
			jQuery('.mumucms_shaer_bpop_mask').click(function(){
			   jQuery('.mumucms_shaer_bpop').addClass('mumucms_shaer_bpop_hover');
			   jQuery('.mumucms_shaer_bpop_mask').removeClass('mumucms_shaer_bpop_block');
			});
	</script>		
<!--{else}-->
	<script type="text/javascript" src="{$_G['style'][tpldir]}/img/js/plusShare.js"></script>
	<script type="text/javascript">	
			jQuery('.mumucms_open_shaer_bpop').click(function(){				
				if(navigator.userAgent.indexOf("Html5Plus") > -1) {  
					//5+ 原生分享  
					window.plusShare({  
						title: "$_G[forum_thread][subject]",//应用名字  
						content: "$_G[forum_thread][subject]",  
						href: location.href,//分享出去后，点击跳转地址  
						thumbs: ["http://wap.mumucms.com/data/attachment/forum/201812/19/132455gvs768m8tvytku0s.jpeg"] //分享缩略图  
					}, function(result) {  
						//分享回调  
					});  
				}
			});
	</script>
<!--{/if}-->
<script src="{$_G['style'][tpldir]}/share/js/social-share.min.js"></script>
<script src="{$_G['style'][tpldir]}/share/js/jquery.copy.js"></script>
<script type="text/javascript">
    $(function(){
        $.copy({
            copyUrl:"", //自定义复制链接地址
            copyId:"#mumucms_copylink"//复制按钮id
        });        	
    });
    mumucms('.mumucms_copylink').click(function(){mumucms.toast('复制成功');});
</script>

<script type="text/javascript">
    $('.reference').click(function () {
        var message = $.trim($(this).parents('.mumucms_plc').find('.message').html());
        var message = message.replace(/\<div class="quote"\>([\s\S]*?)\<\/div\>/g, '');
        var message = message.replace(/\<img src="static\/image\/smiley\/comcom\/([\s\S]*?).gif" class="vm" zsrc="static\/image\/smiley\/comcom\/([\s\S]*?).gif" style="display: inline; visibility: visible;">/g, '[em:$1:]');
		var author = $.trim($(this).parents('h3').find('.username').html());
        var dateline = $.trim($(this).parents('.mumucms_plc').find('.time span').html());
        $('.mumucms_grey').val('[quote]' + '引用' + ': ' + author + ' 发表于 ' + dateline + '\n' + message + '[/quote]\n');
    });
</script>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
