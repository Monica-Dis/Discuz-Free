<?php echo 'From: DisM.taobao.com';exit;?>
<div class="mumucms_threadlist_buluo">
	<h2 class="thread_tit"><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page" target="_blank">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	<!--{if empty($threadlist)}-->
	<ul><li><a href="javascript:;">{lang search_nomatch}</a></li></ul>
	<!--{else}-->
			<ul class="cl">
				<!--{loop $threadlist $thread}-->			
						<!--{eval $tbid = DB::result(DB::query("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE `tid`= '$thread[tid]'"));}-->
						<!--{if $tbid}-->
						<!--{eval $picount = DB::fetch_all("SELECT aid FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1;");}-->
						<!--{eval $picnum = count($picount);}-->
						<!--{if $picnum < 3}-->
						<!--{eval $litpicnum = '1';}-->
						<!--{elseif $picnum > 2 && $picnum < 6}-->
						<!--{eval $litpicnum = '3';}-->
						<!--{elseif $picnum > 5}-->
						<!--{eval $litpicnum = '6';}-->
						<!--{/if}-->
						<!--{eval $covers = DB::fetch_all("SELECT attachment,aid,description FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1 LIMIT 0,$litpicnum;");}-->
						<!--{/if}-->
							<li  id="$thread[id]">
							<!--{hook/forumdisplay_thread_mobile $key}-->
							<a href="forum.php?mod=viewthread&tid=$thread[tid]">
							<div class="mumucms_listtit">
								<div class="mumucms_avatar">
									<!--{if $thread['authorid'] && $thread['author']}-->
										<!--{avatar($thread[authorid],small)}-->
									<!--{else}-->
										<img src="$_G['style']['styleimgdir']/hidden.gif" title="$_G[setting][anonymoustext]" alt="$_G[setting][anonymoustext]" />
									<!--{/if}-->
								</div>
								<h3>
								<div class="mumucms_num">
								<span class="mumucms_views"><i class="iconfont icon-chakan2"></i><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
								<span class="mumucms_replies"><i class="iconfont icon-huifu"></i>$thread[replies]</span>
								</div>
										<!--{if $thread['authorid'] && $thread['author']}-->
											$thread[author]
												
												<!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->
											<!--{else}-->
												$_G[setting][anonymoustext]
											<!--{/if}-->
								</h3>
								<p>发表于&nbsp;$thread[dateline]</p>
							</div>
							<div class="mumucms_listsubject"><h2 $thread[highlight]>$thread[subject]</h2></div>
							<div class="mumucms_listsum">
								<!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
								<!--{echo messagecutstr(DB::result_first('SELECT `message` FROM '.DB::table('forum_post').' WHERE `tid` ='.$thread[tid].' AND `first` =1'),80);}-->
							</div>
							<div class="mumucms_listpic">
							<!--{if $tbid}-->
							<!--{loop $covers $thecover}-->
							<!--{if $litpicnum == 1}-->
							<!--{eval $piclist = getforumimg($thecover[aid], 0, 200, 140); }-->
							<img src="$piclist"/>
							<!--{else}-->
							<!--{eval $piclist = getforumimg($thecover[aid], 0, 200, 140); }-->
							<img src="$piclist"/>
							<!--{/if}-->
							<!--{/loop}-->
							<!--{/if}-->
							</div>
							</a>
							</li>
							
				<!--{/loop}-->
			</ul>
	<!--{/if}-->
	$multipage
</div>

