<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<div class="search">
		<table width="100%" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td>
						<input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="{lang searchthread}">
					</td>
					<td width="66" align="center" class="scbar_btn_td">
						<div><input type="hidden" name="searchsubmit" value="yes"><input type="submit" value="{lang search}" class="button2 mumucms_bgcolor" id="scform_submit"></div>
					</td>
				</tr>
			</tbody>
		</table>
</div>

<!--{if empty($searchid)}-->
<!--{if $_G['setting']['srchhotkeywords']}-->
<div class="mumucms_hot_sreach">
		<div class="mumucms_hot_sreach_title">热门搜索</div>
		<div class="mumucms_hot_sreach_keys">
		<!--{loop $_G['setting']['srchhotkeywords'] $val}-->
			<!--{if $val=trim($val)}-->
				<!--{eval $valenc=rawurlencode($val);}-->
				<!--{block srchhotkeywords[]}-->
					<!--{if !empty($searchparams[url])}-->
						<a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}" target="_blank" sc="1">$val</a>
					<!--{else}-->
						<a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch" target="_blank" sc="1">$val</a>
					<!--{/if}-->
				<!--{/block}-->
			<!--{/if}-->
		<!--{/loop}-->
		<!--{echo implode('', $srchhotkeywords);}-->
		</div>
</div>	
<!--{/if}-->
<!--{/if}-->
