<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>$navtitle</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>

<div class="mumucms_wrap mumucms_search">
	<!--{if $type != 'countitem'}-->
	<form method="post" action="misc.php?mod=tag" class="searchform">
	<div class="search">
		<table width="100%" cellspacing="0" cellpadding="0">
			<tbody>
				<tr>
					<td>
						<input type="text" name="name" class="input" size="30" placeholder="搜索标签"/>
						
					</td>
					<td width="66" align="center" class="scbar_btn_td">
						<input type="submit" value="{lang search}" class="button2 mumucms_bgcolor">
					</td>
				</tr>
			</tbody>
		</table>
	</div>
	</form>
	<div class="mumucms_hot_sreach">
		<div class="mumucms_hot_sreach_title">{lang tag}</div>
		<div class="mumucms_hot_sreach_keys">
			<!--{if $tagarray}-->
				<!--{loop $tagarray $tag}-->
					<a href="misc.php?mod=tag&id=$tag[tagid]" title="$tag[tagname]" class="xi2">$tag[tagname]</a>
				<!--{/loop}-->
			<!--{else}-->
				<p class="emp">{lang no_tag}</p>
			<!--{/if}-->
		</div>
	</div>	
	<!--{else}-->
	$num
	<!--{/if}-->
</div>
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<!--{template common/footer}-->
