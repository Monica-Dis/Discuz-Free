<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>$navtitle</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<div class="mumucms_wrap mumucms_mythread">
<!--{if $tagname}-->
<div class="mumucms_tlist">
	<!--{if empty($showtype) || $showtype == 'thread'}-->
	<div class="mumucms_diy_title mumucms_frame_titlee">
		<span class="titletext">{lang related_thread}</span>
		<!--{if empty($showtype)}-->
			<a class="mumucms_fr mumucms_font14" href="misc.php?mod=tag&id=$id&type=thread">{lang more}</a>
		<!--{/if}-->
	</div>	
	<ul>
		<!--{if $threadlist}-->
			<!--{loop $threadlist $thread}-->
				<li>
				<a href="forum.php?mod=viewthread&tid=$thread[tid]">$thread[subject]
					<p>
						<span class="mumucms_views mumucms_fl">$thread[dateline]</span>
						<span class="mumucms_replies mumucms_fr"><i class="iconfont icon-huifu mumucms_fl"></i>{$thread[replies]}</span>					
						<span class="mumucms_views mumucms_fr"><i class="iconfont icon-chakan2 mumucms_fl"></i>{$thread[views]}</span>
					</p>
				</a>
				</li>
			<!--{/loop}-->
		<!--{else}-->
				<li>{lang no_content}</li>
		<!--{/if}-->
	</ul>
		<!--{if !empty($showtype)}-->
			<!--{if $multipage}-->$multi<!--{/if}-->
		<!--{/if}-->
	<!--{/if}-->
</div>	
<div class="mumucms_tlist mumucms_mt10">
	<!--{if helper_access::check_module('blog') && (empty($showtype) || $showtype == 'blog')}-->
	<div class="mumucms_diy_title mumucms_frame_titlee">
		<span class="titletext">{lang related_blog}</span>
		<!--{if empty($showtype)}-->
			<a class="mumucms_fr mumucms_font14" href="misc.php?mod=tag&id=$id&type=blog">{lang more}</a>
		<!--{/if}-->
	</div>
	<ul>
		<!--{if $bloglist}-->
			<!--{loop $bloglist $blog}-->
				<li>
				<a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]">$blog['subject']
					<p>
						<span class="mumucms_views mumucms_fl">$blog[dateline]</span>
						<span class="mumucms_replies mumucms_fr"><i class="iconfont icon-huifu mumucms_fl"></i>{$blog[replies]}</span>					
						<span class="mumucms_views mumucms_fr"><i class="iconfont icon-chakan2 mumucms_fl"></i>{$blog[views]}</span>
					</p>
				</a>
				</li>
			<!--{/loop}-->
		<!--{else}-->
				<li>{lang no_content}</li>
		<!--{/if}-->
	</ul>	
		<!--{if !empty($showtype)}-->
			<!--{if $multipage}-->$multi<!--{/if}-->
		<!--{/if}-->
	<!--{/if}-->
</div>

<!--{else}-->
	<div id="ct" class="wp cl">
		<h1 class="mt"><img class="vm" src="{IMGDIR}/tag.gif" alt="tag" /> {lang tag}: $searchtagname</h1>
		<div class="bm">
			<div class="bm_c">
				<form method="post" action="misc.php?mod=tag" class="pns">
					<input type="text" name="name" class="px vm" size="30" />&nbsp;
					<button type="submit" class="pn vm"><em>{lang search}</em></button>
				</form>
				<div class="taglist mtm mbm"><p class="emp">{lang empty_tags}</p></div>
			</div>
		</div>
	</div>
<!--{/if}-->
</div>
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<!--{template common/footer}-->
