<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1><a href="javascript:;" class="mumucms_open_bpop"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--><i class="iconfont icon-jiantou"></i></a></h1>
    <div class="mumucms_sousuo"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}"><i class="iconfont icon-fabu"></i></a></div>
</header>
<!-- header end -->

<div class="mumucms_wrap mumucms_forumdisplay">

		<div class="mumucms_forum_ico cl">
			<div class="mumumcs_ico_bgimg">
					<!--{if $_G['forum'][icon]}-->
						<!--{if preg_match("/^http(s)?:\\/\\/.+/", $_G['forum'][icon])}-->
						   <img border="0" alt="$_G['forum'][name]" src="$_G['forum'][icon]">
						<!--{else}-->
						   <img border="0" alt="$_G['forum'][name]" src="data/attachment/common/$_G['forum'][icon]">
						<!--{/if}-->
					<!--{else}-->
					<img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$_G['forum'][name]" />
					<!--{/if}-->
			</div>
			<div class="mumucms_ico_bgcolor"></div>
			<div class="mumucms_ico_img">
				<div class="mumucms_wapimg_ico">
					<!--{if $_G['forum'][icon]}-->
						<!--{if preg_match("/^http(s)?:\\/\\/.+/", $_G['forum'][icon])}-->
							<img border="0" alt="$_G['forum'][name]" src="$_G['forum'][icon]">
						<!--{else}-->
							<img border="0" alt="$_G['forum'][name]" src="data/attachment/common/$_G['forum'][icon]">
						<!--{/if}-->
					<!--{else}-->
					<img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$_G['forum'][name]" />
					<!--{/if}-->
				</div>
				<ul class="mumucms_forum_waptit">
				<h1><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">$_G['forum'][name]</a></h1>
				<p>	<span>{lang index_today}：$_G[forum][todayposts]</span>
				<span>{lang index_threads}：$_G[forum][threads]</span>
				<span>{lang rank}：$_G[forum][rank]</span>
				</p>
				</ul>
			</div>
			<div class="mumucms_newspecial">
			<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" class="favorite dialog">+关注</a>
			</div>
		</div>

			<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
			<div class="mumucms_type">
				<div class="cl">
					<!--{if $_G['forum']['threadtypes']}-->
						<div class="types{if !$_GET['typeid'] && !$_GET['sortid']} active{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}主题</a></div>	
						<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
							<!--{if $_GET['typeid'] == $id}-->
							<div class="types active"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></div>
							<!--{else}-->
							<div class="types{if $_GET['type'] == 'all'} active{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></div>
							<!--{/if}-->
						<!--{/loop}-->
					<!--{/if}-->
					<!--{if $_G['forum']['threadsorts']}-->
						<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
							<!--{if $_GET['sortid'] == $id}-->
							<div class="types active"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></div>
							<!--{else}-->
							<div class="types{if !$_GET['typeid'] && $_GET['sortid']} active{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></div>
							<!--{/if}-->
						<!--{/loop}-->
					<!--{/if}-->
				</div>
			</div>
			<!--{else}-->
			<div class="mumucms_type">
				<div class="cl">
					<div class="types{if !$_GET['typeid'] && !$_GET['sortid']} active{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}主题</a></div>	
				</div>
			</div>			
			<!--{/if}-->

<!--{hook/forumdisplay_top_mobile}-->
$curpage
<!--{if empty($_G['forum']['sortmode'])}-->
	<!--{template forum/forumdisplay_list}-->
<!--{else}-->
	<!--{template forum/forumdisplay_sort}-->
<!--{/if}-->
<!--{hook/forumdisplay_bottom_mobile}-->
<div class="mumucms_bpop mumucms_bpop_hover">
	<header class="mumucms_wapheader">
	    <div class="mumucms_icon"></div>
	    <h1>高级筛选</h1>
	    <div class="mumucms_icon mumucms_close_bpop"><i class="iconfont icon-error"></i></div>
	</header>
	<div class="mumucms_contents">
		<div class="mumucms_paixu">
		  <ul class="cl">
			<li><span>筛选：</span></li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if ($_GET['filter'] == 'digest' && in_array($_GET['specialtype'], array('poll', 'trade', 'reward', 'activity', 'debate'))) || !in_array($_GET['filter'], array('lastpost', 'heat', 'hot', 'digest'))}class="active"{/if}>{lang all}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['filter'] == 'lastpost'}class="active"{/if}>{lang latest}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['filter'] == 'heat'}class="active"{/if}>{lang order_heats}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['filter'] == 'digest'}class="active"{/if}>{lang digest_posts}</a>
				</li>
			</ul>
			<ul class="cl">
				<li><span>{lang orderby}：</span></li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'dateline'}class="active"{/if}>{lang list_post_time}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'replies'}class="active"{/if}>{lang replies}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'views'}class="active"{/if}>{lang views}</a>
				</li>
			</ul>
			<ul class="cl">
				<li><span>{lang time}：</span></li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['dateline']}class="active"{/if}>{lang all}{lang search_any_date}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '86400'}class="active"{/if}>{lang last_1_days}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '172800'}class="active"{/if}>{lang last_2_days}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '604800'}class="active"{/if}>{lang list_one_week}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '2592000'}class="active"{/if}>{lang list_one_month}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '7948800'}class="active"{/if}>{lang list_three_month}</a>
				</li>
			</ul>
		</div>
		<!--{if $subexists && $_G['page'] == 1}-->
		<div class="mumucms_tit">子版块</div>
			<div  class="mumucms_sub">
				<ul>
				<!--{loop $sublist $sub}-->
				<li>
					<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a>
				</li>
				<!--{/loop}-->
				</ul>
			</div>
		<!--{/if}-->
	    </div>
    </div>
</div>

</div>
<div class="pullrefresh" style="display:none;"></div>

<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript">
	mumucms('.mumucms_close_bpop').click(function(){
	    mumucms('.mumucms_bpop').addClass('mumucms_bpop_hover');
	});
	mumucms('.mumucms_open_bpop').click(function(){
	    mumucms('.mumucms_bpop').removeClass('mumucms_bpop_hover');
	});
</script>


<script type="text/javascript">
mumucms('.mumucms_type').scrollX(4, '.types');
</script>
<script type="text/javascript">
var info_head_top = jQuery(".mumucms_type").offset().top;
jQuery(document).scroll(function(){
    var scrtop = jQuery(this).scrollTop()
    if(scrtop>info_head_top){
        jQuery(".mumucms_type").removeClass("mumucms_not_xuanfu").addClass("mumucms_xuanfu");
        jQuery("#back").show();
    }
    else{
        jQuery(".mumucms_type").removeClass("mumucms_xuanfu").addClass("mumucms_not_xuanfu");
        jQuery("#back").hide();
    }
});
</script>


<!--{template common/footer}-->

