<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['cache']['mumucms_app']['app_qiyong'] == 1}-->
	<!--{if $_G['cache']['mumucms_app']['app_forumdisplayxs'] == 1}-->
		<!--{template other_plugin/app_plugin}-->
	<!--{/if}-->	
<!--{/if}-->
<!--{if !$subforumonly}-->
<div class="mumucms_threadlist mumucms_threadlist_buluo">
			<ul class="cl">
			<!--{if $_G['forum_threadcount']}-->
				<!--{loop $_G['forum_threadlist'] $key $thread}-->				
				<!--{if $thread[special] == 4}-->
					<!--{eval $activity = DB::fetch_first("SELECT * FROM ".DB::table('forum_activity')." WHERE tid= '$thread[tid]'");}-->
					<!--{eval $activityimg = getforumimg($activity[aid], 0, 420, 9999); }-->
					<!--{eval $time =time();}-->
					<li class="mumucms_activity_list cl">
					<div class="mumucms_tit">
						<h2 class="bt"><a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank">$thread[subject]</a></h2>
						<div class="xj"><span class="leixing">$activity[class]</span><span class="time">活动时间:<!--{eval echo dgmdate($activity[starttimefrom])}--></span></div>
					</div>	
					<div class="mumucms_img">
						<a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank"><img class="b-lazy b-loaded" src="{$activityimg}"></a>
						<span class="mumucms_ybm">$activity[applynumber]人已报名</span>
					</div>
					<div class="mumucms_price">
						<span class="feiyong">费用：<i>$activity[cost]元/人</i></span>
						<!--{if $time < $activity[starttimefrom]}-->
						<a href="forum.php?mod=viewthread&tid=$activity[tid]" target="_blank" class="wapbtn">我要报名</a>
						<!--{else}-->
							<!--{if $time < $activity[starttimeto]}-->
							<a href="forum.php?mod=viewthread&tid=$activity[tid]" target="_blank" class="wapbtn">活动详情</a>	
							<!--{else}-->
							<a href="forum.php?mod=viewthread&tid=$activity[tid]" target="_blank" class="wapbtn">活动回顾</a>	
							<!--{/if}-->
						<!--{/if}-->						
					</div>
					</li>
				<!--{else}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
                	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
						<li class="list" id="$thread[id]">
						<!--{hook/forumdisplay_thread_mobile $key}-->
						<div class="mumucms_listtit">
							<div class="mumucms_avatar">
								<a href="home.php?mod=space&uid=$thread[authorid]">
								<!--{if $thread['authorid'] && $thread['author']}-->
									<!--{avatar($thread[authorid],small)}-->
								<!--{else}-->
									<img src="$_G['style']['styleimgdir']/hidden.gif" title="$_G[setting][anonymoustext]" alt="$_G[setting][anonymoustext]" />
								<!--{/if}-->
								</a>
							</div>
							<h3>
								<div class="mumucms_num">
								<span class="mumucms_views"><a href="forum.php?mod=viewthread&tid=$thread[tid]"><i class="iconfont icon-chakan2"></i><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></a></span>
								<span class="mumucms_replies"><a href="forum.php?mod=viewthread&tid=$thread[tid]"><i class="iconfont icon-huifu"></i>$thread[replies]</a></span>
								</div>
								<a href="home.php?mod=space&uid=$thread[authorid]">
									<!--{if $thread['authorid'] && $thread['author']}-->
										$thread[author]
											<!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->
									<!--{else}-->
										$_G[setting][anonymoustext]
									<!--{/if}-->
								</a>
							</h3>
							<p>发表于&nbsp;$thread[dateline]</p>
						</div>
						<div class="mumucms_listsubject"><h2 $thread[highlight]><a href="forum.php?mod=viewthread&tid=$thread[tid]">$thread[subject]</a></h2></div>
						<div class="mumucms_listsum">
							<a href="forum.php?mod=viewthread&tid=$thread[tid]">
							<!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
							<!--{echo messagecutstr(DB::result_first('SELECT `message` FROM '.DB::table('forum_post').' WHERE `tid` ='.$thread[tid].' AND `first` =1'),80);}-->
							</a>
						</div>
						<!--{if $thread['attachment'] == 2}-->
							<!--{eval $tbid = DB::result(DB::query("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE `tid`= '$thread[tid]'"));}-->
							<!--{if !is_null($tbid)}-->
							<!--{eval $picount = DB::fetch_all("SELECT aid FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1;");}-->
							<!--{eval $picnum = count($picount);}-->
							<!--{if $picnum < 3}-->
							<!--{eval $litpicnum = '1';}-->
							<!--{elseif $picnum > 2 && $picnum < 6}-->
							<!--{eval $litpicnum = '3';}-->
							<!--{elseif $picnum > 5}-->
							<!--{eval $litpicnum = '6';}-->
							<!--{/if}-->
							<!--{eval $covers = DB::fetch_all("SELECT attachment,aid,description FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1 LIMIT 0,$litpicnum;");}-->
							<!--{/if}-->						
							<div class="mumucms_listpic">
							<!--{if !is_null($tbid)}-->
							<!--{loop $covers $thecover}-->
							<!--{if $litpicnum == 1}-->
							<!--{eval $piclist = getforumimg($thecover[aid], 0, 420, 9999); }-->
							<a href="forum.php?mod=viewthread&tid=$thread[tid]"><img class="img" src="$piclist"/></a>
							<!--{else}-->
							<!--{eval $piclist = getforumimg($thecover[aid], 0, 200, 140); }-->
							<a href="forum.php?mod=viewthread&tid=$thread[tid]"><img class="imgs" src="$piclist"/></a>
							<!--{/if}-->
							<!--{/loop}-->
							<!--{/if}-->
							</div>
						<!--{/if}-->
						</li>
				<!--{/if}-->			
                <!--{/loop}-->
            <!--{else}-->
			<li>{lang forum_nothreads}</li>
			<!--{/if}-->
		</ul>
</div>
$multipage
<!--{if $_SERVER["HTTP_X_REQUESTED_WITH"]=="XMLHttpRequest"}-->
	<!--{eval $pages = $_REQUEST['page'];}-->
	<!--{eval $pages++;}-->
	<!--{if $pages > 20}-->
		<!--{eval return;}-->
	 <!--{/if}-->	
<!--{else}-->
	<!--{eval $pages = 2;}-->
 <!--{/if}-->
<div class="mumucms_page"><a class="next_page" href="forum.php?mod=forumdisplay&fid=$_G[fid]&page=$pages">下一页</a></div>
<style type="text/css">
.mumucms_trigger{background:#FFF;}	
</style>
<script src="{$_G['style'][tpldir]}/img/js/jquery-ias.min.js?{VERHASH}" charset="{CHARSET}"></script>
<script type="text/javascript">
	var ias = jQuery.ias({
	  container:  '.mumucms_threadlist',
	  item:       '.list',
	  pagination: '.mumucms_page',
	  next:       'a.next_page',
	});
	ias.extension(new IASTriggerExtension({
	    text: '点击查看更多',
	    offset: 10, 
	}));
	ias.extension(new IASSpinnerExtension());
	ias.extension(new IASNoneLeftExtension({
	    text: '已经是全部内容了', 
	}));	
</script>

<!--{/if}-->

