<?php echo 'From: DisM.taobao.com';exit;?>

<!--{if $_G['cache']['mumucms_app']['app_qiyong'] == 1}-->
	<!--{if $_G['cache']['mumucms_app']['app_forumdisplayxs'] == 1}-->
		<!--{template other_plugin/app_plugin}-->
	<!--{/if}-->	
<!--{/if}-->

<!--{if $quicksearchlist && !$_GET['archiveid']}-->
	<!--{subtemplate forum/search_sortoption}-->
<!--{/if}-->
<!--{eval $mumucms_wapcontrol_zxlp_sortid = $_G['cache']['plugin']['mumucms_wapcontrol']['mumucms_wapcontrol_gaoji_sortid'];}-->
<!--{if $_GET['sortid'] == $mumucms_wapcontrol_zxlp_sortid}-->
	<!--{if $_GET['sortid'] == $_G['cache']['plugin']['mumucms_wapcontrol']['mumucms_wapcontrol_zxlp_sortid']}-->
		<!--{eval $mumucms_tese = (explode("&nbsp;",$_G['optionvaluelist'][$sortid][$thread['tid']][mumucms_zxlp_lpts][value]));}-->
		<div class="mumucms_threadlist_sort">
			<ul class="cl">
				<!--{eval $mumucms_info = DB::fetch_all("SELECT * FROM ".DB::table('forum_typeoptionvar')." WHERE fid='$_G[fid]'");}-->
			<!--{loop $_G['forum_threadlist'] $key $thread}-->
			<li id="$thread[id]">
				<a href="forum.php?mod=viewthread&tid=$thread[tid]">
				<div class="mumucms_img">
						<img src="{$_G['optionvaluelist'][$sortid][$thread['tid']][mumucms_zxlp_xgt][value]}">
						<span class="xszt">{$_G['optionvaluelist'][$sortid][$thread['tid']][mumucms_zxlp_xszt][value]}</span>
				</div>
				<div class="mumucms_txt">
					<h2 class="tit">{$_G['optionvaluelist'][$sortid][$thread['tid']][mumucms_zxlp_lpmc][value]}</h2>
					<p class="dizhi"><i class="iconfont icon-ditu"></i>{$_G['optionvaluelist'][$sortid][$thread['tid']][mumucms_zxlp_lpdz][value]}</p>
					<div class="tese"><i>$mumucms_tese[0]</i><i>$mumucms_tese[1]</i><i>$mumucms_tese[2]</i></div>
					<div class="price">{$_G['optionvaluelist'][$sortid][$thread['tid']][mumucms_zxlp_ckjj][value]}<em>{$_G['optionvaluelist'][$sortid][$thread['tid']][mumucms_zxlp_ckjj][unit]}</em></div>
				</div>
				</a>
			</li>
			<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
<!--{else}-->
	<div id="threadlist" class="mumucms_threadlist"{if $_G['uid']} style="position: relative;"{/if}>		
		$sorttemplate['header']
		<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">		
			$sorttemplate['body']
		</form>
		$sorttemplate['footer']
	</div>
<!--{/if}-->

