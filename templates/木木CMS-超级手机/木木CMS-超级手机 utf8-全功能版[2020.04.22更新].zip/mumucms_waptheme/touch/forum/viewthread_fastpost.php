<?php echo 'From: DisM.taobao.com';exit;?>
<div class="mumucms_fastpost">
	<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes&mobile=2">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="mumucms_post_pi">
		<div class="post_sum">
			<textarea class="mumucms_grey grey" placeholder="{lang send_reply_fast_tip}" name="message" id="fastpostmessage" color="gray"></textarea>
		</div>
		<div id="fastpostsubmitline" style="display:none;">
			<!--{if $secqaacheck || $seccodecheck}--><!--{subtemplate common/seccheck}--><!--{/if}-->
			<!--{hook/viewthread_fastpost_button_mobile}-->
		</div>
		<div class="post_bt">
			<a href="javascript:void(0)" class="mumucms_face"><i class="iconfont icon-biaoqing"></i></a>
			<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page"><i class="iconfont icon-tupian"></i></a>
			<div id="fastpostsubmitline" class="post_but">
				<input type="button" value="{lang reply}" class="formdialog button" name="replysubmit" id="fastpostsubmit">
			</div>
		</div>
	</div>
    </form>
	<script src="{$_G['style'][tpldir]}/img/face/mumucms.face.js" charset="{CHARSET}"></script>
	<div id="mumucms_face"></div>
	<script type="text/javascript">
	$(function (){
		$("a.mumucms_face").mumucmsfacebox({
			Event : "click",	//触发事件	
			divid : "mumucms_face", //外层DIV ID
			textid : "fastpostmessage" //文本框 ID
		});
	});
	</script>
</div>
<script type="text/javascript">
	(function() {
		var form = $('#fastpostform');
		<!--{if !$_G[uid] || $_G[uid] && !$allowpostreply}-->
		$('#fastpostmessage').on('focus', function() {
			<!--{if !$_G[uid]}-->
				popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
			<!--{else}-->
				popup.open('{lang nopostreply}', 'alert');
			<!--{/if}-->
			this.blur();
		});
		<!--{else}-->
		$('#fastpostmessage').on('focus', function() {
			var obj = $(this);
			if(obj.attr('color') == 'gray') {
				obj.attr('value', '');
				obj.removeClass('grey');
				obj.attr('color', 'black');
				$('#fastpostsubmitline').css('display', 'block');
			}
		})
		.on('blur', function() {
			var obj = $(this);
			if(obj.attr('value') == '') {
				obj.addClass('grey');
				obj.attr('value', '{lang send_reply_fast_tip}');
				obj.attr('color', 'gray');
			}
		});
		<!--{/if}-->
		$('#fastpostsubmit').on('click', function() {
			var msgobj = $('#fastpostmessage');
			if(msgobj.val() == '{lang send_reply_fast_tip}') {
				msgobj.attr('value', '');
			}
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey=fastpost&loc=1&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});

		$('#replyid').on('click', function() {
			$(document).scrollTop($(document).height());
			$('#fastpostmessage')[0].focus();
		});

	})();

	function succeedhandle_fastpost(locationhref, message, param) {
		var pid = param['pid'];
		var tid = param['tid'];
		if(pid) {
			$.ajax({
				type:'POST',
				url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid + '&mobile=2',
				dataType:'xml'
			})
			.success(function(s) {
				$('#post_new').append(s.lastChild.firstChild.nodeValue);
				mumucms.toast('发表成功');
				$('.mumucms_bpop').addClass('mumucms_bpop_hover');
				$('.mumucms_bpop_mask').removeClass('mumucms_bpop_block');
			})
			.error(function() {
				window.location.href = 'forum.php?mod=viewthread&tid=' + tid;
				popup.close();
			});
		} else {
			if(!message) {
				message = '{lang postreplyneedmod}';
			}
			popup.open(message, 'alert');
		}
		$('#fastpostmessage').attr('value', '');
		if(param['sechash']) {
			$('.seccodeimg').click();
		}
	}

	function errorhandle_fastpost(message, param) {
		popup.open(message, 'alert');
	}
</script>

