<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<header class="mumucms_wapheader">
    <div class="mumucms_menu"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-youcecaidan"></i><!--{avatar($space[uid],middle)}--></a></div>
    <h1>$navtitle</h1>
    <div class="mumucms_sousuo"><a href="search.php?mod=forum&amp;mobile=2"><i class="iconfont icon-sousuo"></i></a></div>
</header>
<div class="mumucms_wrap mumucms_forum">
	<div class="mumucms_sub">
        <div class="tab_hd">
			<li class="active"><a href="javascript:void(0)">全部版块</a></li>	
			<li><a href="javascript:void(0)">发布文章</a></li>	
			<!--{eval $mumucms_forum_forum = DB::fetch_all("SELECT a.*,b.icon FROM ".DB::table("forum_forum")." a LEFT JOIN ".DB::table("forum_forumfield")." b on b.fid=a.fid WHERE a.fid=b.fid");}-->	
			
			<!--{loop $mumucms_forum_forum $cat}-->
				<!--{if $cat[fup] == 0 & $cat[status] == 1}-->
				<li><a href="javascript:void(0)">$cat[name] $cat[icon]</a></li>				
				<!--{/if}-->								
			<!--{/loop}-->
        </div>
        <div class="tab_bd">
			<div class="forumlist" style="display:block;">
			
			<!--{loop $mumucms_forum_forum $forum}-->
			<!--{if $forum[type] == forum & $forum[status] == 1}-->
					<li class="list cl">		
						<div class="icon">
								<!--{if $forum[icon]}-->
									<a href="forum.php?mod=post&action=newthread&fid=$forum[fid]&mobile=2" target="_blank"><img src="data/attachment/common/$forum[icon]" alt="$forum[name]" /></a>								
								<!--{else}-->
									<a href="forum.php?mod=post&action=newthread&fid=$forum[fid]&mobile=2"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
								<!--{/if}-->
						</div>
						<div class="name">
							<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
							<span>{$forum[name]}</span>
							<!--{if empty($forum[redirect])}--><dd><em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em><em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em></dd><!--{/if}-->
							</a>
							<a href="forum.php?mod=post&action=newthread&fid=$forum[fid]&mobile=2" class="favorite">+发帖</a>
						</div>
					</li>	
			<!--{/if}-->
			<!--{/loop}-->
			</div>

			<div class="forumlist" style="display:none;">
			<!--{eval $mumucms_portal_category = DB::fetch_all("SELECT * FROM ".DB::table('portal_category')." WHERE `disallowpublish`='0'");}-->
			<!--{loop $mumucms_portal_category $category}-->
					<li class="list cl">		
						<div class="icon">
									<a href="forum.php?mod=post&action=newthread&fid=$forum[fid]&mobile=2"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
						</div>
						<div class="name">
							<a href="portal.php?mod=list&catid={$category[catid]}">
							<span>{$category[catname]}</span>
							<dd><em>文章: <!--{echo dnumber($category[articles])}--></em>
							</a>
							<a href="portal.php?mod=portalcp&ac=article&catid=$category[catid]&mobile=2" class="favorite">+发表</a>
						</div>
					</li>	
			<!--{/loop}-->
			</div>

<!--{loop $mumucms_forum_forum $cat}-->
<!--{if $cat[fup] == 0 & $cat[status] == 1}-->
				<div class="forumlist" style="display:none;">
			<!--{loop $mumucms_forum_forum $forum}-->
			<!--{if $forum[fup] == $cat[fid] & $forum[status] == 1}-->
					<li class="list cl">		
						<div class="icon">
								<!--{if $forum[icon]}-->
									<a href="forum.php?mod=post&action=newthread&fid=$forum[fid]&mobile=2" target="_blank"><img src="data/attachment/common/$forum[icon]" alt="$forum[name]" /></a>								
								<!--{else}-->
									<a href="forum.php?mod=post&action=newthread&fid=$forum[fid]&mobile=2"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
								<!--{/if}-->
						</div>
						<div class="name">
							<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
							<span>{$forum[name]}</span>
							<!--{if empty($forum[redirect])}--><dd><em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em><em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em></dd><!--{/if}-->
							</a>
							<a href="forum.php?mod=post&action=newthread&fid=$forum[fid]&mobile=2" class="favorite">+发帖</a>
						</div>
					</li>	
			<!--{/if}-->
			<!--{/loop}-->
			</div>		
<!--{/if}-->			
	<!--{/loop}-->

        </div>
	</div>
</div>
<script type="text/javascript">
        jQuery(function(){
                function tabs(tabTit,on,tabCon){
                        jQuery(tabTit).children().hover(function(){
                                jQuery(this).addClass(on).siblings().removeClass(on);
                                var index = jQuery(tabTit).children().index(this);
                                jQuery(tabCon).children().eq(index).show().siblings().hide();
                        });
                };
        tabs(".tab_hd","active",".tab_bd");
        });
</script>

<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>

<!--{template common/footer}-->
