<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $mumucms_wapcontrol_gaoji_sortid = (explode(",",$_G['cache']['plugin']['mumucms_wapcontrol']['mumucms_wapcontrol_gaoji_sortid']));}-->
<!--{if (in_array($_G[forum_thread][sortid],$mumucms_wapcontrol_gaoji_sortid))}-->
	<!--{if $_G[forum_thread][sortid] == $_G['cache']['plugin']['mumucms_wapcontrol']['mumucms_wapcontrol_zxlp_sortid']}-->
		<!--{template sort/viewthread_sort_zxlp}-->
	<!--{/if}-->
<!--{else}-->
<div class="message">
	$threadsortshow[typetemplate]
</div>	
<!--{/if}-->
