<?php echo 'From: DisM.taobao.com';exit;?>
 <div class="mumucms_news_list">

				<!--{if $list['threadcount']}-->
					<!--{loop $list['threadlist'] $key $thread}-->
				<!--{if $thread['attachment'] == 2}-->
					<!--{eval $tbid = DB::result(DB::query("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE `tid`= '$thread[tid]'"));}-->
					<!--{if !is_null($tbid)}-->
					<!--{eval $picount = DB::fetch_all("SELECT aid FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1;");}-->
					<!--{eval $picnum = count($picount);}-->
					<!--{if $picnum < 3}-->
					<!--{eval $litpicnum = '1';}-->
					<!--{elseif $picnum > 2 && $picnum < 6}-->
					<!--{eval $litpicnum = '3';}-->
					<!--{elseif $picnum > 5}-->
					<!--{eval $litpicnum = '6';}-->
					<!--{/if}-->
					<!--{eval $covers = DB::fetch_all("SELECT attachment,aid,description FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1 LIMIT 0,$litpicnum;");}-->
					<!--{/if}-->
					<!--{eval $picnum = count($picount);}-->
   
        	<!--{if $picnum < 3}-->
			<li class="guide">
                <a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
                    <div class="mumucms_news_list_l">
                        $thread[subject]<br />
                        <span>$thread[author] | $thread[dateline]</span>
                    </div>
                    <div class="mumucms_news_list_r">
							<!--{if $litpicnum == 1}-->
							<!--{loop $covers $thecover}-->
							<!--{eval $piclist = getforumimg($thecover[aid], 0, 200, 140); }-->
							<img src="$piclist"/>
							<!--{/loop}-->
							<!--{/if}-->
                    </div>
                </a>
            </li>
            <!--{elseif $picnum > 2 && $picnum < 6}-->
            <li class="guide">
                <a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
                    <div class="mumucms_news_list_titile">
                        $thread[subject]
                    </div>
                    <div class="mumucms_news_list_imgs">
							<!--{if $litpicnum == 3}-->
							<!--{loop $covers $thecover}-->
							<!--{eval $piclist = getforumimg($thecover[aid], 0, 200, 140); }-->
							<img src="$piclist"/>
							<!--{/loop}-->
							<!--{/if}-->
                    </div>
                    <div class="mumucms_news_list_info">$thread[author] | $thread[dateline]</div>
                </a>
            </li>
			<!--{/if}-->


	    <!--{else}--> 
			 <li class="guide">
                 <a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
                    <div class="mumucms_news_list_titile">
                        $thread[subject]
                    </div>
                    <div class="mumucms_news_list_info">$thread[author] | $thread[dateline]</div>
                </a>
            </li>
    
        <!--{/if}-->


						<!--{/loop}-->
				<!--{else}-->
					<p>{lang guide_nothreads}</p>
				<!--{/if}-->
</div>
