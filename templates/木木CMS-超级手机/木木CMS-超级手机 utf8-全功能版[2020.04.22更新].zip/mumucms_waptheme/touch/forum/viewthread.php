<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->
<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="<!--{if $_GET[fromguid] == 'hot'}-->forum.php?mod=guide&view=newthread&page=$_GET[page]<!--{else}-->forum.php?mod=forumdisplay&fid=$_G[fid]&<!--{eval echo rawurldecode($_GET[extra]);}--><!--{/if}-->"><i class="iconfont icon-fanhui"></i></a></div>
    <h1><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></h1>
    <div class="mumucms_sousuo"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}"><i class="iconfont icon-fabu"></i></a></div>
</header>
<!-- header end -->

<div class="mumucms_wrap mumucms_view">
<!--{hook/viewthread_top_mobile}-->
<!-- main postlist start -->
<div class="mumucms_postlist">
	<!--{eval $mumucms_wapcontrol_gaoji_sortid = (explode(",",$_G['cache']['plugin']['mumucms_wapcontrol']['mumucms_wapcontrol_gaoji_sortid']));}-->
		<!--{if (!in_array($_G[forum_thread][sortid],$mumucms_wapcontrol_gaoji_sortid))}-->
			<div class="mumucms_tit">
				<h2>
		        	<!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
						[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
		            <!--{/if}-->
		            <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
		                [{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]
					<!--{/if}-->
					$_G[forum_thread][subject]
		            <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
		            <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
		            <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
		            <!--{/if}-->
				</h2>
			</div>	
		<!--{/if}-->

	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
	<!--{hook/viewthread_posttop_mobile $postcount}-->
    <div class="mumucms_plc cl" id="pid$post[pid]">
    	<!--{if (in_array($_G[forum_thread][sortid],$mumucms_wapcontrol_gaoji_sortid))}-->
	    	<!--{if !$post[first]}-->
		   	<div class="mumucms_avatar cl">
				<div class="authi"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->""></div>
				<h3>
					<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
							<a href="home.php?mod=space&uid=$post[authorid]" class="mumucms_a_color">$post[author]</a></b>

						<!--{else}-->
							<!--{if !$post['authorid']}-->
							<a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
							<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
							<!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
							<!--{else}-->
							$post[author] <em>{lang member_deleted}</em>
							<!--{/if}-->
						<!--{/if}-->

						<em class="mumucms_bgcolor">
							<!--{if isset($post[isstick])}-->
								<img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> {lang from} {$post[number]}{$postnostick}
							<!--{elseif $post[number] == -1}-->
								{lang recommend_post}
							<!--{else}-->
								<!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}#<!--{/if}-->
							<!--{/if}-->
						</em>
				</h3>
				<div class="time cl">
					<span class="mumucms_span mumucms_dataline mumucms_fl">$post[dateline]</span>
					<!--{if $_G['forum']['ismoderator']}-->
						<!-- manage start -->
						<!--{if $post[first]}-->
							<span class="mumucms_span mumucms_fl"><a pid="#moption_$post[pid]" class="popup blue">{lang manage}</a></span>
							<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
								<div class="mumucms_tip">
								<!--{if !$_G['forum_thread']['special']}-->
								<dd style="border-top:none;"><input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></dd>
								<!--{/if}-->
								<dd><input type="button" value="{lang delete}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}"></dd>
								<dd><input type="button" value="{lang close}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4"></dd>
								<dd><input type="button" value="{lang admin_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></dd>
								<dd><input type="button" value="{lang topicadmin_warn_add}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></dd>
								<dd><input type="button" class="button" onclick="popup.close();" value="取消"></dd>
								</div>
							</div>
						<!--{else}-->
							<span class="mumucms_span mumucms_fl"><a pid="#moption_$post[pid]" class="popup blue">{lang manage}</a></span>
							<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
								<div class="mumucms_tip">
								<dd style="border-top:none;"><input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></dd>
								<!--{if $_G['group']['allowdelpost']}--><dd><input type="button" value="{lang modmenu_deletepost}" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></dd><!--{/if}-->
								<!--{if $_G['group']['allowbanpost']}--><dd><input type="button" value="{lang modmenu_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></dd><!--{/if}-->
								<!--{if $_G['group']['allowwarnpost']}--><dd><input type="button" value="{lang modmenu_warn}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></dd><!--{/if}-->
								<dd><input type="button" class="button" onclick="popup.close();" value="取消"></dd>
								</div>
							</div>
						<!--{/if}-->
						<!-- manage end -->
						<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid']}-->
							<span class="mumucms_span mumucms_fl"><a type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a></span>
						<!--{/if}-->
					<!--{if $post[first]}-->
					<span class="mumucms_span mumucms_fl"><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn blue" <!--{if $_G[forum][ismoderator]}-->style="margin-right:10px;"<!--{/if}-->>{lang favorite}</a></span>
					<span class="mumucms_span mumucms_replies mumucms_fr"><i class="iconfont icon-huifu mumucms_fl"></i>$thread[replies]</span>				
					<span class="mumucms_span mumucms_views mumucms_fr"><i class="iconfont icon-chakan2 mumucms_fl"></i>
					<!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
					<!--{/if}-->
				</div>
			</div>
			<!--{else}-->
			<!--{/if}-->
		<!--{else}-->	
		   	<div class="mumucms_avatar cl">
				<div class="authi"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->""></div>
				<h3>
					<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
							<a href="home.php?mod=space&uid=$post[authorid]" class="blue">$post[author]</a></b>

						<!--{else}-->
							<!--{if !$post['authorid']}-->
							<a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
							<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
							<!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
							<!--{else}-->
							$post[author] <em>{lang member_deleted}</em>
							<!--{/if}-->
						<!--{/if}-->

						<em>
							<!--{if isset($post[isstick])}-->
								<img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> {lang from} {$post[number]}{$postnostick}
							<!--{elseif $post[number] == -1}-->
								{lang recommend_post}
							<!--{else}-->
								<!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}#<!--{/if}-->
							<!--{/if}-->
						</em>
				</h3>
				<div class="time cl">
					<span class="mumucms_span mumucms_dataline mumucms_fl">$post[dateline]</span>
					<!--{if $_G['forum']['ismoderator']}-->
						<!-- manage start -->
						<!--{if $post[first]}-->
							<span class="mumucms_span mumucms_fl"><a pid="#moption_$post[pid]" class="popup blue">{lang manage}</a></span>
							<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
								<div class="mumucms_tip">
								<!--{if !$_G['forum_thread']['special']}-->
								<dd style="border-top:none;"><input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></dd>
								<!--{/if}-->
								<dd><input type="button" value="{lang delete}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}"></dd>
								<dd><input type="button" value="{lang close}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4"></dd>
								<dd><input type="button" value="{lang admin_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></dd>
								<dd><input type="button" value="{lang topicadmin_warn_add}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></dd>
								<dd><input type="button" class="button" onclick="popup.close();" value="取消"></dd>
								</div>
							</div>
						<!--{else}-->
							<span class="mumucms_span mumucms_fl"><a pid="#moption_$post[pid]" class="popup blue">{lang manage}</a></span>
							<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
								<div class="mumucms_tip">
								<dd style="border-top:none;"><input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></dd>
								<!--{if $_G['group']['allowdelpost']}--><dd><input type="button" value="{lang modmenu_deletepost}" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></dd><!--{/if}-->
								<!--{if $_G['group']['allowbanpost']}--><dd><input type="button" value="{lang modmenu_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></dd><!--{/if}-->
								<!--{if $_G['group']['allowwarnpost']}--><dd><input type="button" value="{lang modmenu_warn}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></dd><!--{/if}-->
								<dd><input type="button" class="button" onclick="popup.close();" value="取消"></dd>
								</div>
							</div>
						<!--{/if}-->
						<!-- manage end -->
						<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid']}-->
							<span class="mumucms_span mumucms_fl"><a type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a></span>
						<!--{/if}-->
					<!--{if $post[first]}-->
					<span class="mumucms_span mumucms_fl"><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn blue" <!--{if $_G[forum][ismoderator]}-->style="margin-right:10px;"<!--{/if}-->>{lang favorite}</a></span>
					<span class="mumucms_span mumucms_replies mumucms_fr"><i class="iconfont icon-huifu mumucms_fl"></i>$thread[replies]</span>				
					<span class="mumucms_span mumucms_views mumucms_fr"><i class="iconfont icon-chakan2 mumucms_fl"></i>
					<!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
					<!--{/if}-->
				</div>
			</div>		
		<!--{/if}-->
       <div class="mumucms_pi" href="#replybtn_$post[pid]">
                	<!--{if $post['warned']}-->
                        <span class="grey quote">{lang warn_get}</span>
                    <!--{/if}-->
                    <!--{if !$post['first'] && !empty($post[subject])}-->
                        <h2><strong>$post[subject]</strong></h2>
                    <!--{/if}-->
                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                        <div class="grey quote">{lang message_banned}</div>
                    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                        <div class="grey quote">{lang message_single_banned}</div>
                    <!--{elseif $needhiddenreply}-->
                        <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
                    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
						<!--{template forum/viewthread_pay}-->
					<!--{else}-->

                    	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                            <div class="grey quote">{lang admin_message_banned}</div>
                        <!--{elseif $post['status'] & 1}-->
                            <div class="grey quote">{lang admin_message_single_banned}</div>
                        <!--{/if}-->
                        <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                            {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
                        <!--{/if}-->
                        <!--{if $post['first'] && $threadsortshow}-->
                        	<!--{if $threadsortshow['typetemplate']}-->
                        	  <!--{template forum/viewthread_sort}-->
							<!--{elseif $threadsortshow['optionlist']}-->
								<div class="message">
                                <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                    {lang has_expired}
                                <!--{else}-->
                                    <div class="box_ex2 viewsort">
                                        <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                                    <!--{loop $threadsortshow['optionlist'] $option}-->
                                        <!--{if $option['type'] != 'info'}-->
                                            $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                                        <!--{/if}-->
                                    <!--{/loop}-->
                                    </div>
                                <!--{/if}-->
                                </div>
                            <!--{/if}-->
                        <!--{/if}-->
                    <div class="message">   	
                        <!--{if $post['first']}-->
                            <!--{if !$_G[forum_thread][special]}-->
                                $post[message]
                            <!--{elseif $_G[forum_thread][special] == 1}-->
                                <!--{template forum/viewthread_poll}-->
                            <!--{elseif $_G[forum_thread][special] == 2}-->
                                <!--{template forum/viewthread_trade}-->
                            <!--{elseif $_G[forum_thread][special] == 3}-->
                                <!--{template forum/viewthread_reward}-->
                            <!--{elseif $_G[forum_thread][special] == 4}-->
                                <!--{template forum/viewthread_activity}-->
                            <!--{elseif $_G[forum_thread][special] == 5}-->
                                <!--{template forum/viewthread_debate}-->
                            <!--{elseif $threadplughtml}-->
                                $threadplughtml
                                $post[message]
                            <!--{else}-->
                            	$post[message]
                            <!--{/if}-->
                        <!--{else}-->
                            $post[message]
                        <!--{/if}-->
                    </div>    
					<!--{/if}-->
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
			<!--{if $post['attachment']}-->
               <div class="grey quote">
               {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
               </div>
            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
            <div class="message">  
               <!--{if $post['imagelist']}-->
				<!--{if count($post['imagelist']) == 1}-->
				<ul class="img_one">{echo showattach($post, 1)}</ul>
				<!--{else}-->
				<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
				<!--{/if}-->
				<!--{/if}-->
                <!--{if $post['attachlist']}-->
				<ul>{echo showattach($post)}</ul>
				<!--{/if}-->
			</div>	
			<!--{/if}-->
			<!--{/if}-->
			<!--{if $_G[uid] && $allowpostreply && !$post[first]}-->
			<div id="replybtn_$post[pid]" class="replybtn" display="true" style="display:none;position:absolute;right:0px;top:5px;">
				<input type="button" class="redirect button" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" value="{lang reply}">
			</div>
			<!--{/if}-->

			<!--{if $post['first'] && ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
				<div class="mumucms_tagbtn">
					<a class="btn_i" href="misc.php?mod=tag&mobile=2"><i class="iconfont icon-biaoqian"></i></a>
					<!--{if $post[tags]}-->
						<!--{eval $tagi = 0;}-->
						<!--{loop $post[tags] $var}-->
							<a class="btn_a" title="$var[1]" href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
							<!--{eval $tagi++;}-->
						<!--{/loop}-->
					<!--{/if}-->
					<!--{if $relatedkeywords}--><span>$relatedkeywords</span><!--{/if}-->
				</div>
			<!--{/if}-->	
			<!--{if $post[first]}-->
			<style type="text/css">
				.mumucms_poster{padding:10px;overflow:hidden;border-top:1px solid #F5F5F5;}
				.mumucms_poster .mumucms_hbbtn a{height:30px;line-height:30px;color:#FFF;display:block;border-radius:3px;padding:0 10px;font-size:14px;}
				.mumucms_poster .mumucms_hbbtn a i{margin-right:5px;float:left;}
			</style>
			<div class="mumucms_poster">
				<div class="mumucms_fl mumucms_hbbtn">
					<a class="mumucms_btnbg_1 mumucms_kfz" href="javascript:;"><i class="iconfont icon-qrcode-1-copy"></i>生成海报</a>
				</div>
			</div>

			<!--{/if}-->
	        <!--{if $_G['cache']['mumucms_app']['app_qiyong'] == 1}-->
		    	<!--{if $_G['cache']['mumucms_app']['app_viewthreadxs'] == 1}-->
	                <!--{if $post[first]}-->
	                	<!--{template other_plugin/app_plugin}--> 	
					<!--{/if}-->
		    	<!--{/if}-->	
		    <!--{/if}-->

       </div>
       <div class="mumucms_cz">
       		<!--{if $_G[uid] && $allowpostreply && !$post[first]}-->
				<a class="redirect button" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" value="{lang reply}">{lang reply}</a>
			<!--{/if}-->
       </div>
   </div>
   <!--{hook/viewthread_postbottom_mobile $postcount}-->
   <!--{eval $postcount++;}-->
   <!--{/loop}-->
	<div id="post_new"></div>
</div>
<!-- main postlist end -->

$multipage

<!--{hook/viewthread_bottom_mobile}-->
<div class="mumucms_bpop_main">
	<div class="mumucms_viewfoot_zw"></div>
	<div class="mumucms_viewfoot">
		<ul class="cl">
			<li><a href="javascript:;" class="mumucms_open_shaer_bpop"><i class="iconfont icon-ziyuan"></i></a></li>
			<li><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn"><i class="iconfont icon-shoucang"></i></a></li>
			<li><a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" class="favbtn"><i class="iconfont icon-zan"></i><em class="zannum" {if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>$_G[forum_thread][recommend_add]</em></a></li>
			<li class="post"><a href="javascript:;" class="mumucms_open_bpop"><span>{lang send_reply_fast_tip}...</span></a></li>
		</ul>
	</div>
	<div class="mumucms_shaer_bpop mumucms_shaer_bpop_hover">
		<div class="mumucms_share">
			<div class="social-share" data-initialized="false" data-mode="prepend" data-url="{$_G['siteurl']}portal.php?mod=view&aid=$article[aid]"  data-title="$article[title]">
				<a href="#" class="share-qq"><i class="iconfont icon-qq1"></i><p>QQ好友</p></a>
	            <a href="#" class="share-qzone"><i class="iconfont icon-kongjian"></i><p>QQ空间</p></a>
	            <a href="#" class="share-weibo"><i class="iconfont icon-weibo1"></i><p>新浪微博</p></a>
	            <a href="#" class="share-douban"><i class="iconfont icon-douban"></i><p>豆瓣</p></a>
	        	<a href="#" class="share-linkedin"><i class="iconfont icon-linkedin"></i><p>linkedin</p></a>
	            <a href="#" class="share-facebook"><i class="iconfont icon-facebook"></i><p>facebook</p></a>
	            <a href="#" class="share-twitter"><i class="iconfont icon-twitter"></i><p>twitter</p></a>
	            <a class="mumucms_copylink" id="mumucms_copylink"><i class="iconfont icon-fuzhilianjie"></i><p>复制链接</p></a>
	        </div>
	    </div> 
		<div class="mumucms_share_qx mumucms_close_shaer_bpop">取消</div>
	</div>
	<div class="mumucms_shaer_bpop_mask"></div>
	<div class="mumucms_bpop mumucms_bpop_hover">
		<header class="mumucms_wapheader">
		    <div class="mumucms_icon"></div>
		    <h1>回复</h1>
		    <div class="mumucms_icon mumucms_close_bpop"><i class="iconfont icon-error"></i></div>
		</header>
		<div class="mumucms_contents">
			<!--{subtemplate forum/viewthread_fastpost}-->
		</div>
	</div>
	<div class="mumucms_bpop_mask"></div>
</div>
<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript">
	jQuery('.mumucms_open_bpop').click(function(){
	    jQuery('.mumucms_bpop').removeClass('mumucms_bpop_hover');
		jQuery('.mumucms_bpop_mask').addClass('mumucms_bpop_block');
	});
	jQuery('.mumucms_close_bpop').click(function(){
	   jQuery('.mumucms_bpop').addClass('mumucms_bpop_hover');
	   jQuery('.mumucms_bpop_mask').removeClass('mumucms_bpop_block');	   
	});
	jQuery('.mumucms_bpop_mask').click(function(){
	   jQuery('.mumucms_bpop').addClass('mumucms_bpop_hover');
	   jQuery('.mumucms_bpop_mask').removeClass('mumucms_bpop_block');
	});
</script>
<!--{eval $agent = $_SERVER['HTTP_USER_AGENT'];}--> 
<!--{if strpos($agent,"Html5Plus") === false }-->
	<script type="text/javascript">
	
			jQuery('.mumucms_open_shaer_bpop').click(function(){
				jQuery('.mumucms_shaer_bpop').removeClass('mumucms_shaer_bpop_hover');
				jQuery('.mumucms_shaer_bpop_mask').addClass('mumucms_shaer_bpop_block');
			});				
			jQuery('.mumucms_close_shaer_bpop').click(function(){
			   jQuery('.mumucms_shaer_bpop').addClass('mumucms_shaer_bpop_hover');
			   jQuery('.mumucms_shaer_bpop_mask').removeClass('mumucms_shaer_bpop_block');	   
			});
			jQuery('.mumucms_shaer_bpop_mask').click(function(){
			   jQuery('.mumucms_shaer_bpop').addClass('mumucms_shaer_bpop_hover');
			   jQuery('.mumucms_shaer_bpop_mask').removeClass('mumucms_shaer_bpop_block');
			});
	</script>		
<!--{else}-->
	<script type="text/javascript" src="{$_G['style'][tpldir]}/img/js/plusShare.js"></script>
	<script type="text/javascript">	
			jQuery('.mumucms_open_shaer_bpop').click(function(){				
				if(navigator.userAgent.indexOf("Html5Plus") > -1) {  
					//5+ 原生分享  
					window.plusShare({  
						title: "$_G[forum_thread][subject]",//应用名字  
						content: "$_G[forum_thread][subject]",  
						href: location.href,//分享出去后，点击跳转地址  
						thumbs: ["http://wap.mumucms.com/data/attachment/forum/201812/19/132455gvs768m8tvytku0s.jpeg"] //分享缩略图  
					}, function(result) {  
						//分享回调  
					});  
				}
			});
	</script>
<!--{/if}-->
<script type="text/javascript">
mumucms.lazyLoad();
</script>
<script type="text/javascript">
$('.mumucms_plc .mumucms_pi img').each(function () {
		AutoResizeImage(this);
	});
	function AutoResizeImage(objImg) {
		var img = new Image();
		img.src = objImg.src;
		img.onload = function(){
			if(this.width >= 200){
				$(objImg).css('margin-top','10px');				
				$(objImg).css('width','100%');
				$(objImg).css('height','auto');
			}
		}
	}
</script>
<script src="{$_G['style'][tpldir]}/share/js/social-share.min.js"></script>
<script src="{$_G['style'][tpldir]}/share/js/jquery.copy.js"></script>
<script type="text/javascript">
    $(function(){
        $.copy({
            copyUrl:"", //自定义复制链接地址
            copyId:"#mumucms_copylink"//复制按钮id
        });        	
    });
    mumucms('.mumucms_copylink').click(function(){mumucms.toast('复制成功');});
</script>
<script type="text/javascript">
	mumucms('.mumucms_kfz').click(function(){mumucms.toast('功能开发中,下版本将与您见面');});
</script>
</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

