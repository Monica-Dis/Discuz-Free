<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<script type="text/javascript">
	var allowpostattach = parseInt('{$_G['group']['allowpostattach']}');
	var allowpostimg = parseInt('$allowpostimg');
	var pid = parseInt('$pid');
	var tid = parseInt('$_G[tid]');
	var extensions = '{$_G['group']['attachextensions']}';
	var imgexts = '$imgexts';
	var postminchars = parseInt('$_G['setting']['minpostsize']');
	var postmaxchars = parseInt('$_G['setting']['maxpostsize']');
	var disablepostctrl = parseInt('{$_G['group']['disablepostctrl']}');
	var seccodecheck = parseInt('<!--{if $seccodecheck}-->1<!--{else}-->0<!--{/if}-->');
	var secqaacheck = parseInt('<!--{if $secqaacheck}-->1<!--{else}-->0<!--{/if}-->');
	var typerequired = parseInt('{$_G[forum][threadtypes][required]}');
	var sortrequired = parseInt('{$_G[forum][threadsorts][required]}');
	var special = parseInt('$special');
	var isfirstpost = <!--{if $isfirstpost}-->1<!--{else}-->0<!--{/if}-->;
	var allowposttrade = parseInt('{$_G['group']['allowposttrade']}');
	var allowpostreward = parseInt('{$_G['group']['allowpostreward']}');
	var allowpostactivity = parseInt('{$_G['group']['allowpostactivity']}');
	var sortid = parseInt('$sortid');
	var special = parseInt('$special');
	var fid = $_G['fid'];
	var postaction = '{$_GET['action']}';
	var ispicstyleforum = <!--{if $_G['forum']['picstyle']}-->1<!--{else}-->0<!--{/if}-->;
</script>



	<script type="text/javascript">
		var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
	</script>
	<script type="text/javascript" src="{$_G['style'][tpldir]}/img/js/threadsort.js?{VERHASH}"></script>



<!--{eval $adveditor = $isfirstpost && $special || $special == 2 && ($_GET['action'] == 'newthread' || $_GET['action'] == 'reply' && !empty($_GET['addtrade']) || $_GET['action'] == 'edit' && $thread['special'] == 2);}-->
<!--{eval $advmore = !$showthreadsorts && !$special || $_GET['action'] == 'reply' && empty($_GET['addtrade']) || $_GET['action'] == 'edit' && !$isfirstpost && ($thread['special'] == 2 && !$special || $thread['special'] != 2);}-->
<style type="text/css">.mumucms_bg{background:#FFF;}</style>
<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="<!--{if $_GET[action] == 'newthread'}-->forum.php?mod=forumdisplay&fid=$_G[fid]&page=$_GET[page]<!--{else}-->forum.php?mod=redirect&goto=findpost&ptid=$_G[tid]&pid=$pid<!--{/if}-->"><i class="iconfont icon-fanhui"></i></a></div>
    <h1><!--{if $_GET[action] == 'edit'}-->{lang edit}<!--{else}-->{lang send_threads}<!--{/if}--></h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<!-- header end -->

<div class="mumucms_wrap mumucms_post">
<form method="post" autocomplete="off" id="postform"
	{if $_GET[action] == 'newthread'}action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes"
	{elseif $_GET[action] == 'reply'}action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes"
	{elseif $_GET[action] == 'edit'}action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes" $enctype
	{/if}
	onsubmit="return validate(this)">
	<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
	<input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}" />
	<!--{if $_GET['action'] == 'edit'}-->
		<input type="hidden" name="delattachop" id="delattachop" value="0" />
	<!--{/if}-->
	<!--{if !empty($_GET['modthreadkey'])}--><input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" /><!--{/if}-->
	<input type="hidden" name="wysiwyg" id="{$editorid}_mode" value="$editormode" />
	<!--{if $_GET[action] == 'reply'}-->
		<input type="hidden" name="noticeauthor" value="$noticeauthor" />
		<input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
		<input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
		<!--{if $reppid}-->
			<input type="hidden" name="reppid" value="$reppid" />
		<!--{/if}-->
		<!--{if $_GET[reppost]}-->
			<input type="hidden" name="reppost" value="$_GET[reppost]" />
		<!--{elseif $_GET[repquote]}-->
			<input type="hidden" name="reppost" value="$_GET[repquote]" />
		<!--{/if}-->
	<!--{/if}-->
	<!--{if $_GET[action] == 'edit'}-->
		<input type="hidden" name="fid" id="fid" value="$_G[fid]" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<input type="hidden" name="pid" value="$pid" />
		<input type="hidden" name="page" value="$_GET[page]" />
	<!--{/if}-->
	<!--{if $special}-->
		<input type="hidden" name="special" value="$special" />
	<!--{/if}-->
	<!--{if $specialextra}-->
		<input type="hidden" name="specialextra" value="$specialextra" />
	<!--{/if}-->
	<div class="mumucms_post_from">

    <!--{if $_GET[action] == 'newthread'}-->
   	    <div class="mumucms_huamenu"> 
    			<div class="mumucms_type">
				<div class="cl">
                    <!--{if !$_G['forum']['threadsorts']['required'] && !$_G['forum']['allowspecialonly']}-->
                    <div class="types{if $_GET[special] == ''} active{/if}"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang post_newthread}</a></div><!--{/if}-->
                    <!--{loop $_G['forum']['threadsorts'][types] $tsortid $name}-->
                         <div class="types{if $sortid == $tsortid} active{/if}"><a href="forum.php?mod=post&action=newthread&sortid=$tsortid&fid=$_G[fid]"><!--{echo strip_tags($name);}--></a></div>
                    <!--{/loop}-->
                    
                    <!--{if $_G['group']['allowpostpoll']}--> <div class="types{if $_GET[special] == 1} active{/if}"><a href="forum.php?mod=post&action=newthread&special=1&fid=$_G[fid]">{lang post_newthreadpoll}</a></div   ><!--{/if}-->
                    <!--{if $_G['group']['allowposttrade']}--><div class="types{if $_GET[special] == 2} active{/if}"><a href="forum.php?mod=post&action=newthread&special=2&fid=$_G[fid]">{lang post_newthreadtrade}</a></div><!--{/if}-->
                    <!--{if $_G['group']['allowpostreward']}--><div class="types{if $_GET[special] == 3} active{/if}"><a href="forum.php?mod=post&action=newthread&special=3&fid=$_G[fid]">{lang post_newthreadreward}</a></div><!--{/if}-->
                    <!--{if $_G['group']['allowpostactivity']}--><div class="types{if $_GET[special] == 4} active{/if}"><a href="forum.php?mod=post&action=newthread&special=4&fid=$_G[fid]">{lang post_newthreadactivity}</a></div><!--{/if}-->
                    <!--{if $_G['group']['allowpostdebate']}--><div class="types{if $_GET[special] == 5} active{/if}"><a href="forum.php?mod=post&action=newthread&special=5&fid=$_G[fid]">{lang post_newthreaddebate}</a></div><!--{/if}-->
                    <!--{if $_G['setting']['threadplugins']}-->
                        <!--{loop $_G['forum']['threadplugin'] $tpid}-->
                            <!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
                                <div class="types{if $specialextra == $tpid} active{/if}"><a href="forum.php?mod=post&action=newthread&specialextra=$tpid&fid=$_G[fid]">{$_G[setting][threadplugins][$tpid][name]}</a></div>
                            <!--{/if}-->
                        <!--{/loop}-->
                    <!--{/if}-->
				</div>
			</div>
	    </div>		
	<!--{/if}-->

		<!--{if $isfirstpost && !empty($_G['forum'][threadtypes][types])}-->
		<div class="mumucms_ztfl">
			<div class="mumucms_bl_line">
				<select id="typeid" name="typeid" class="sort_sel">
					<option value="0" selected="selected">{lang select_thread_catgory}</option>
					<!--{loop $_G['forum'][threadtypes][types] $typeid $name}-->
					<!--{if empty($_G['forum']['threadtypes']['moderators'][$typeid]) || $_G['forum']['ismoderator']}-->
					<option value="$typeid"{if $thread['typeid'] == $typeid || $_GET['typeid'] == $typeid} selected="selected"{/if}><!--{echo strip_tags($name);}--></option>
					<!--{/if}-->
					<!--{/loop}-->
				</select>
			</div>
		</div>
		<!--{/if}-->
		<div class="mumucms_subject">
			<!--{if $_GET['action'] != 'reply'}-->
			<input type="text" tabindex="1" class="mumucms_px" id="needsubject" size="30" autocomplete="off" value="$postinfo[subject]" name="subject" placeholder="请输入{lang thread_subject}（必填）" fwin="login">
			<!--{else}-->
				RE: $thread['subject']
			<!--{/if}-->
		</div>

		<!--{template forum/post_editor_extra}-->
    
		<!--{if $_GET[action] == 'edit' && $isorigauthor && ($isfirstpost && $thread['replies'] < 1 || !$isfirstpost) && !$rushreply && $_G['setting']['editperdel']}-->

		<div class="mumucms_bl_line">
			<input type="checkbox" name="delete" id="delete" class="pc" value="1" title="{lang post_delpost}{if $thread[special] == 3}{lang reward_price_back}{/if}"> {lang delete_check}
		</div>
		<!--{/if}-->
		<div class="mumucms_bl_none">
		<div class="zhusum">内容</div>
		<div class="mumucms_area">
		<textarea class="pt" id="needmessage" tabindex="3" autocomplete="off" id="{$editorid}_textarea" name="$editor[textarea]" placeholder="说点什么吧！" fwin="reply">$postinfo[message]</textarea>
		</div>
		</div>
		<div id="mumucms_tab_top" class="mumucms_post_gn">
			<a href="javascript:void(0)" id="face_tab_a" onclick="showExtra('face_tab')" class="mumucms_face tabtop"><i class="iconfont icon-biaoqing"></i></a>
			<a href="javascript:void(0)" id="tupian_tab_a" onclick="showExtra('tupian_tab')" class="mumucms_sc tabtop"><i class="iconfont icon-tupian"></i></a>
			<a href="javascript:void(0)" id="tag_tab_a" onclick="showExtra('tag_tab')" class="mumucms_tag tabtop"><i class="iconfont icon-biaoqian"></i></a>		
		</div>
		<div id="mumucms_tab_con">
			<div id="face_tab_b" class="tabcon" style="display:none;">
				<script src="{$_G['style'][tpldir]}/img/face/mumucms.face.js" charset="{CHARSET}"></script>
				<div id="mumucms_face"></div>
				<script type="text/javascript">
					$(function (){
						$("a.mumucms_face").mumucmsfacebox({
							Event : "click",	//触发事件	
							divid : "mumucms_face", //外层DIV ID
							textid : "needmessage" //文本框 ID
						});
					});
				</script>
			</div>		

			<!--{if $_GET[action]=='edit'}-->
            <!--{eval $table='forum_attachment_'.substr($postinfo['tid'], -1);}-->
            <!--{eval $query = DB::query("SELECT * FROM ".DB::table($table)." WHERE pid='$postinfo[pid]' AND isimage!=0 ORDER BY `dateline` ASC"); while($value = DB::fetch($query))$mumucms_imsges[]=$value;}-->
            <!--{/if}-->
            <div id="tupian_tab_b" class="tabcon" {if !$mumucms_imsges}style="display:none"{/if}>
				<ul id="mumucms_imglist" class="mumucms_imglist cl">
					<li class="scimg"><i class="iconfont icon-jiahao1"></i><input type="file" name="Filedata" id="filedata"></li>
						<!--{if $mumucms_imsges}-->
		                  <!--{loop $mumucms_imsges $imsges}-->
		                  <!--{eval $aid=$imsges['aid'];}-->
		                  <li>
		                   <span aid="$aid" id="$aid" class="del"><a href="javascript:;"><i class="iconfont icon-error"></i></a></a></span>
		                   <span class="p_img"><a href="javascript:;"><img style="height:60px;width:60px;" id="aimg_{$aid}" src="data/attachment/forum/{$imsges[attachment]}" /></a></span>
		                   <input type="hidden" name="attachnew[$aid][description]" />
		                  </li>
		                  <!--{/loop}-->
		                <!--{/if}-->
				</ul>
			</div>	
			<!--{if $_G['group']['allowposttag']}-->
				<div id="tag_tab_b" class="tabcon mumucms_tag_tab_b" style="display:none;">
					<div class="mumucms_subject mumucms_tagipt">
					<input type="text" class="mumucms_px" size="60" id="tags" name="tags" value="$postinfo[tag]" onblur="extraCheck(4)" placeholder="请输入{lang post_tag}">
						<!--<a href="forum.php?mod=tag" class="choosetag mumucms_bgcolor dialog">{lang choosetag}</a>-->
					</div>
					<div class="mumcums_sm">
						<p class="xg1">{lang posttag_comment}</p>
						<!--{eval $recent_use_tag = recent_use_tag();}-->
						<!--{if $recent_use_tag}-->
						<p class="mtn">{lang recent_use_tag}&nbsp;
							<!--{eval $tagi = 0;}-->
							<!--{loop $recent_use_tag $var}-->
							<!--{if $tagi}-->, <!--{/if}--><a href="javascript:;" class="mumucms_a_color">$var</a>
								<!--{eval $tagi++;}-->
							<!--{/loop}-->
						</p>
						<!--{/if}-->

					</div>
				</div>
			<!--{/if}-->
		</div>	
		<div class="mumucms_pobut">
		<button id="postsubmit" class="mumucms_fbbut mumucms_button mumucms_button_large <!--{if $_GET[action] == 'edit'}-->mumucms_primary" disable="false"<!--{else}-->mumucms_fbbut_grey" disable="true"<!--{/if}-->><span><!--{if $_GET[action] == 'newthread'}-->{lang send_thread}<!--{elseif $_GET[action] == 'reply'}-->{lang join_thread}<!--{elseif $_GET[action] == 'edit'}-->{lang edit_save}<!--{/if}--></span></button>
		</div>
		<!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
		<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
		<!--{hook/post_bottom_mobile}-->
	</div>
<!-- main postbox start -->
</form>
</div>

<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript">
mumucms('.mumucms_type').scrollX(4, '.types');
</script>

<script type="text/javascript">
	(function() {
		var needsubject = needmessage = false;

		<!--{if $_GET[action] == 'reply'}-->
			needsubject = true;
		<!--{elseif $_GET[action] == 'edit'}-->
			needsubject = needmessage = true;
		<!--{/if}-->

		<!--{if $_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost)}-->
		$('#needsubject').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				needsubject = true;
				if(needmessage == true) {
					$('.mumucms_fbbut').removeClass('mumucms_fbbut_grey').addClass('mumucms_primary');
					$('.mumucms_fbbut').attr('disable', 'false');
				}
			} else {
				needsubject = false;
				$('.mumucms_fbbut').removeClass('mumucms_primary').addClass('mumucms_fbbut_grey');
				$('.mumucms_fbbut').attr('disable', 'true');
			}
		});
		<!--{/if}-->
		$('#needmessage').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				needmessage = true;
				if(needsubject == true) {
					$('.mumucms_fbbut').removeClass('mumucms_fbbut_grey').addClass('mumucms_primary');
					$('.mumucms_fbbut').attr('disable', 'false');
				}
			} else {
				needmessage = false;
				$('.mumucms_fbbut').removeClass('mumucms_primary').addClass('mumucms_fbbut_grey');
				$('.mumucms_fbbut').attr('disable', 'true');
			}
		});

		$('#needmessage').on('scroll', function() {
			var obj = $(this);
			if(obj.scrollTop() > 0) {
				obj.attr('rows', parseInt(obj.attr('rows'))+2);
			}
		}).scrollTop($(document).height());
	 })();
</script>
<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="{STATICURL}js/mobile/buildfileupload.js?{VERHASH}"></script>
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
	var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	var form = $('#postform');
	$(document).on('change', '#filedata', function() {
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

			uploadsuccess = function(data) {
				if(data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
				var dataarr = data.split('|');
				if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
					popup.close();
					$('#mumucms_imglist').append('<li><span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><i class="iconfont icon-error"></i></a></span><span class="insert"><a href="javascript:;" onclick="addipic(\'[attachimg]'+dataarr[3]+'[/attachimg]\')">点击插入</a></span><span class="p_img"><a href="javascript:;" ><img style="height:60px;width:60px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
				} else {
					var sizelimit = '';
					if(dataarr[7] == 'ban') {
						sizelimit = '{lang uploadpicatttypeban}';
					} else if(dataarr[7] == 'perday') {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
					} else if(dataarr[7] > 0) {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
					}
					popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
				}
			};

			if(typeof FileReader != 'undefined' && this.files[0]) {//note 支持html5上传新特性
				
				$.buildfileupload({
					uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
					files:this.files,
					uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
					uploadinputname:'Filedata',
					maxfilesize:"$swfconfig[max]",
					success:uploadsuccess,
					error:function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			} else {

				$.ajaxfileupload({
					url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
					data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
					dataType:'text',
					fileElementId:'filedata',
					success:uploadsuccess,
					error: function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			}
	});

	<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
	geo.getcurrentposition();
	<!--{/if}-->
	$('#postsubmit').on('click', function() {
		var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}

		obj.attr('disable', 'true').removeClass('mumucms_primary').addClass('mumucms_fbbut_grey');
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

		var postlocation = '';
		if(geo.errmsg === '' && geo.loc) {
			postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
		}

		$.ajax({
			type:'POST',
			url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

	$(document).on('click', '.del', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid') + (obj.attr('up') == 1 ? '&tid={$postinfo[tid]}&pid={$postinfo[pid]}' : '&tid={$postinfo[tid]}&pid={$postinfo[pid]}'),
		})
		.success(function(s) {
			obj.parent().remove();
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

</script>

<script>

function addipic(aid) {
seditor_insertunit('need', aid);
}
function seditor_insertunit(key, text, textend, moveend, selappend) {
if(document.getElementById(key + 'message')) {
document.getElementById(key + 'message').focus();
}
textend = isUndefined(textend) ? '' : textend;
moveend = isUndefined(textend) ? 0 : moveend;
selappend = isUndefined(selappend) ? 1 : selappend;
startlen = strlen(text);
endlen = strlen(textend);
if(!isUndefined(document.getElementById(key + 'message').selectionStart)) {
if(selappend) {
var opn = document.getElementById(key + 'message').selectionStart + 0;
if(textend != '') {
text = text + document.getElementById(key + 'message').value.substring(document.getElementById(key + 'message').selectionStart, document.getElementById(key + 'message').selectionEnd) + textend;
}
document.getElementById(key + 'message').value = document.getElementById(key + 'message').value.substr(0, document.getElementById(key + 'message').selectionStart) + text + document.getElementById(key + 'message').value.substr(document.getElementById(key + 'message').selectionEnd);
if(!moveend) {
document.getElementById(key + 'message').selectionStart = opn + strlen(text) - endlen;
document.getElementById(key + 'message').selectionEnd = opn + strlen(text) - endlen;
}
} else {
text = text + textend;
document.getElementById(key + 'message').value = document.getElementById(key + 'message').value.substr(0, document.getElementById(key + 'message').selectionStart) + text + document.getElementById(key + 'message').value.substr(document.getElementById(key + 'message').selectionEnd);
}
} else if(document.selection && document.selection.createRange) {
var sel = document.selection.createRange();
if(!sel.text.length && document.getElementById(key + 'message').sel) {
sel = document.getElementById(key + 'message').sel;
document.getElementById(key + 'message').sel = null;
}
if(selappend) {
if(textend != '') {
text = text + sel.text + textend;
}
sel.text = text.replace(/\r?\n/g, '\r\n');
if(!moveend) {
sel.moveStart('character', -endlen);
sel.moveEnd('character', -endlen);
}
sel.select();
} else {
sel.text = text + textend;
}
} else {
document.getElementById(key + 'message').value += text;
}
//hideMenu(2);
}
function strlen(str) {
return (str.indexOf('\n') != -1) ? str.replace(/\r?\n/g, '_').length : str.length;
}
</script>


<!--{eval $mumucms_scrollmenu = true;}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
