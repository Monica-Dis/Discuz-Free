<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<header class="mumucms_wapheader">
    <div class="mumucms_menu"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-youcecaidan"></i><!--{avatar($space[uid],middle)}--></a></div>
    <h1>$_G[setting][bbname]</h1>
    <div class="mumucms_sousuo"><a href="search.php?mod=forum&mobile=2"><i class="iconfont icon-sousuo"></i></a></div>
</header>
<div class="mumucms_wrap mumucms_guide">

<style id="diy_style" type="text/css"></style>
<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->


<!-- main threadlist start --> 
<div class="mumucms_forum">
    <div class="mumucms_swipe" id="swipe">
        <div class="mumucms_swipe_items">
            <div class="mumucms_swipe_item">
			<!--{eval $mumucms_forum = DB::fetch_all("SELECT * FROM ".DB::table('forum_forum')." as a LEFT JOIN ".DB::table('forum_forumfield')." as b on b.fid=a.fid WHERE a.`type`='forum' and a.`status`='1' ORDER BY a.`posts` DESC LIMIT 0,14");}-->
			<!--{eval $i=0;}--> 
			<!--{loop $mumucms_forum $forum}-->
			<!--{if $i == 7}-->
			        <li><a href="forum.php?forumlist=1"><img src="{$_G['style'][tpldir]}/img/mumucms_forum.gif"><span>全部版块</span></a></li>
			</div>
			<div class="mumucms_swipe_item">
			<!--{/if}-->
				<!--{if $forum[icon]}-->
					<!--{if preg_match("/^http(s)?:\\/\\/.+/",$forum[icon])}-->
					   <li><a href="forum.php?mod=forumdisplay&fid={$forum[fid]}"><img src="$forum[icon]"><span>$forum[name]</span></a></li>
					<!--{else}-->
					    <li><a href="forum.php?mod=forumdisplay&fid={$forum[fid]}"><img src="data/attachment/common/$forum[icon]"><span>$forum[name]</span></a></li>
					<!--{/if}-->
				<!--{else}-->
					<li><a href="forum.php?mod=forumdisplay&fid={$forum[fid]}"><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif"><span>$forum[name]</span></a></li>
				<!--{/if}-->
				  <!--{eval $i++;}-->
			<!--{/loop}-->
			 		<li><a href="forum.php?forumlist=1"><img src="{$_G['style'][tpldir]}/img/mumucms_forum.gif"><span>全部版块</span></a></li>
			</div>
        </div>
    </div>
    <!--{if $_G['cache']['mumucms_app']['app_qiyong'] == 1}-->
    	<!--{if $_G['cache']['mumucms_app']['app_guidexs'] == 1}-->
    		<!--{template other_plugin/app_plugin}-->
    	<!--{/if}-->	
    <!--{/if}-->
</div>

<div id="thread_types">
	<div class="cl">
	<div class="types{if $view == 'newthread'} active{/if}"><a href="forum.php?mod=guide&view=newthread">{lang guide_newthread}</a></div>	
	<div class="types{if $view == 'new'} active{/if}"><a href="forum.php?mod=guide&view=new">{lang guide_new}</a></div>
	<div class="types{if $view == 'hot'} active{/if}"><a href="forum.php?mod=guide&view=hot">{lang guide_hot}</a></div>
	<div class="types{if $view == 'digest'} active{/if}"><a href="forum.php?mod=guide&view=digest">{lang guide_digest}</a></div>
	</div>
</div>

<div class="threadlist">

	<!--{loop $data $key $list}-->
		<!--{subtemplate forum/guide_list_row}-->
	<!--{/loop}-->
<!-- main threadlist end -->

$multipage


<!--{if $_SERVER["HTTP_X_REQUESTED_WITH"]=="XMLHttpRequest"}-->
	<!--{eval $pages = $_REQUEST['page'];}-->
	<!--{eval $pages++;}-->
		<!--{if $pages > 20}-->
			<!--{eval return;}-->
	 	<!--{/if}-->
<!--{else}-->
	<!--{eval $pages = 2;}-->
 <!--{/if}-->
<div class="mumucms_page"><a class="next_page" href="forum.php?mod=guide&view={$_GET['view']}&page=$pages&mobile=2">下一页</a></div>
<script src="{$_G['style'][tpldir]}/img/js/jquery-ias.min.js?{VERHASH}" charset="{CHARSET}"></script>
<script type="text/javascript">
	var ias = jQuery.ias({
	  container:  '.mumucms_news_list',
	  item:       '.guide',
	  pagination: '.mumucms_page',
	  next:       'a.next_page'
	});
	ias.extension(new IASTriggerExtension({
	    text: '点击查看更多',
	    offset: 10, 
	}));
	ias.extension(new IASSpinnerExtension());
	ias.extension(new IASNoneLeftExtension({
	    text: '已经是全部内容了', 
	}));	
</script>


<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script src="{$_G['style'][tpldir]}/common/js/common_swipe.js" type="text/javascript"></script>
<script type="text/javascript">
mumucms('#thread_types').scrollX(4, '.types');
</script>
<script type="text/javascript">
var info_head_top = jQuery("#thread_types").offset().top;
jQuery(document).scroll(function(){
    var scrtop = jQuery(this).scrollTop()
    if(scrtop>info_head_top){
        jQuery("#thread_types").removeClass("not_xuanfu").addClass("xuanfu");
        jQuery("#back").show();
    }
    else{
        jQuery("#thread_types").removeClass("xuanfu").addClass("not_xuanfu");
        jQuery("#back").hide();
    }
});
</script>
<script type="text/javascript">
	var swipe = new mumucmsSwpie('#swipe');
	swipe.autoPlay = false;
	swipe.run();
</script>
</div>
<!--{template common/footer}-->

