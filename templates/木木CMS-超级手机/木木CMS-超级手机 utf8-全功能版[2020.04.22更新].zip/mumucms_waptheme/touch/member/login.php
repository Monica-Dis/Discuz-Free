<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<!--{if !$_GET['infloat']}-->

<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>$navtitle</h1>
    <div class="mumucms_sousuo"><a href="{$_G['siteurl']}"><i class="iconfont icon-zhuye"></i></a></div>
</header>

<!-- header end -->

<!--{/if}-->
{eval $loginhash = 'L'.random(4);}

<!-- userinfo start -->

<div class="<!--{if !$_GET['infloat']}-->mumucms_wrap <!--{/if}-->mumucms_member"  <!--{if $_GET[infloat]}-->
	style="background:#FFF;"<!--{/if}-->>

<div class="mumucms_loginbox">
	<!--{if $_GET[infloat]}-->
		<h2 class="log_tit"><a href="javascript:;" onclick="popup.close();"><span class="icon_close y">&nbsp;</span></a>{lang login}</h2>
	<!--{/if}-->
		<form id="loginform" method="post" action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
		<input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
		<input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
		<input type="hidden" name="fastloginfield" value="username">
		<input type="hidden" name="cookietime" value="2592000">
		<!--{if $auth}-->
			<input type="hidden" name="auth" value="$auth" />
		<!--{/if}-->
	<div class="mumucms_login_from">
		<ul>
			<li><input type="text" value="" tabindex="1" class="mumucms_px" size="30" autocomplete="off" value="" name="username" placeholder="{lang inputyourname}" fwin="login"></li>
			<li><input type="password" tabindex="2" class="mumucms_px" size="30" value="" name="password" placeholder="{lang login_password}" fwin="login"></li>
			<li class="questionli">
				<div class="login_select">
				<span class="login-btn-inner">
					<span class="login-btn-text">
						<span class="span_question">{lang security_question}</span>
					</span>
					<span class="icon-arrow">&nbsp;</span>
				</span>
				<select id="questionid_{$loginhash}" name="questionid" class="sel_list">
					<option value="0" selected="selected">{lang security_question}</option>
					<option value="1">{lang security_question_1}</option>
					<option value="2">{lang security_question_2}</option>
					<option value="3">{lang security_question_3}</option>
					<option value="4">{lang security_question_4}</option>
					<option value="5">{lang security_question_5}</option>
					<option value="6">{lang security_question_6}</option>
					<option value="7">{lang security_question_7}</option>
				</select>
				</div>
			</li>
			<li class="bl_none answerli" style="display:none;"><input type="text" name="answer" id="answer_{$loginhash}" class="mumucms_px" size="30" placeholder="{lang security_a}"></li>
		</ul>
		<!--{if $seccodecheck}-->
		<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
	</div>
	<div class="mumucms_btn_login"><button tabindex="3" value="true" name="submit" type="submit" class="mumucms_button mumucms_button_large mumucms_primary formdialog"><span>{lang login}</span></button></div>
	</form>
	<!--{if $_G['setting']['regstatus']}-->
	<div class="reg_link">
		<a href="member.php?mod={$_G[setting][regname]}" class="mumucms_fl">注册新账号</a>
		<a href="javascript:;" class="mumucms_fr mumucms_open_bpop" title="找回密码">找回密码</a>
	</div>
	<!--{/if}-->
	<!--{hook/logging_bottom_mobile}-->
	<!--{if !$_GET['infloat']}-->
	<div class="mumucms_kuaijie">
		<p class="reg_ts"><span>使用第三方快捷登录</span></p>
		<div class="reg_tb">
			<a href="#"><img src="{$_G['style'][tpldir]}/img/mumucms_weixin.png"></a>
			<a href="#"><img src="{$_G['style'][tpldir]}/img/mumucms_shouji.png"></a>
			<a href="$_G[connect][login_url]&statfrom=login_simple"><img src="{$_G['style'][tpldir]}/img/mumucms_qq.png"></a>
		</div>
	</div>
	<!--{/if}-->
</div>
<!-- userinfo end -->

<!--{if !$_GET['infloat']}-->
<div class="mumucms_bpop mumucms_bpop_hover">
	<header class="mumucms_wapheader">
	    <div class="mumucms_close_bpop"><i class="iconfont icon-fanhui"></i></div>
	    <h1>找回密码</h1>
	    <div class="mumucms_sousuo"><a href="{$_G['siteurl']}"><i class="iconfont icon-zhuye"></i></a></div>
	</header>
	<div class="mumucms_content">
	    <div class="mumucms_loginbox">
			<form method="post" autocomplete="off" id="lostpwform_$loginhash" class="cl" onsubmit="ajaxpost('lostpwform_$loginhash', 'returnmessage3_$loginhash', 'returnmessage3_$loginhash', 'onerror');return false;" action="member.php?mod=lostpasswd&lostpwsubmit=yes&infloat=yes">
				<div class="mumucms_login_from">
					<ul>
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="handlekey" value="lostpwform" />

					<li><input type="text" name="email" id="lostpw_email" size="30" value=""  tabindex="1" class="mumucms_px" placeholder="(*)请输入您的{lang email}" fwin="login"></li>
					<li><input type="text" name="username" id="lostpw_username" size="30" value=""  tabindex="1" class="mumucms_px" placeholder="请输入您的{lang username} "/></li>
					</ul>
				</div>
				<div class="mumucms_btn_login"><button tabindex="3" value="true" name="submit" type="submit" class="mumucms_button mumucms_button_large mumucms_primary"><span>{lang submit}</span></button></div>
			</form>
	    </div>
    </div>
</div>
<!--{/if}-->

<!--{if $_G['setting']['pwdsafety']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<!--{/if}-->
<!--{eval updatesession();}-->

<script type="text/javascript">
	(function() {
		$(document).on('change', '.sel_list', function() {
			var obj = $(this);
			$('.span_question').text(obj.find('option:selected').text());
			if(obj.val() == 0) {
				$('.answerli').css('display', 'none');
				$('.questionli').addClass('bl_none');
			} else {
				$('.answerli').css('display', 'block');
				$('.questionli').removeClass('bl_none');
			}
		});
	 })();
</script>


</div>
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript">
	mumucms('.mumucms_close_bpop').click(function(){
	    mumucms('.mumucms_bpop').addClass('mumucms_bpop_hover');
	});
	mumucms('.mumucms_open_bpop').click(function(){
	    mumucms('.mumucms_bpop').removeClass('mumucms_bpop_hover');
	});
</script>


<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

