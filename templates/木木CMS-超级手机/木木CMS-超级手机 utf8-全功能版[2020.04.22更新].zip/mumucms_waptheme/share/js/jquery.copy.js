;(function($){
    var defaults = {
        copyUrl:"",//自定义复制链接地址
        tipTime:2000,//分享提示消失时间
        copyId:""//复制按钮id
    };
    $.extend({
        copy:function(option){
            var options = $.extend({},defaults,option);
            var URL = options.copyUrl == "" ? window.location.href.split('#')[0] : options.copyUrl;
            var cId = options.copyId == "" ? '#copy' : options.copyId;
            var u = navigator.userAgent; 
            var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android终端 
            var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端 
            var aEle = document.querySelectorAll(cId);
            if(isAndroid || (!isAndroid && !isiOS)){
                $(aEle).each(function(){
                    var index = $(this).attr("id").split("y")[1];
                    $('body').append('<textarea id="selector'+index+'" style="position:absolute;top:-9999px;left:-9999px;" readonly>'+URL+'</textarea>');
                    $(this)[0].onclick=function(event){
                        $("#selector"+index).select();
                        document.execCommand("copy",false,null);
                        $("body").append(tipsHtml);
                        setTimeout(function(){
                            $("#share-tips").remove();
                        },options.tipTime);
                    };
                });        
            }
            if(isiOS){
                $(aEle).each(function(){
                    var index = $(this).attr("id").split("y")[1];
                    $('body').append('<a id="selector'+index+'" style="position:absolute;top:-9999px;left:-9999px;">'+URL+'</a>');
                    this.addEventListener('click',function(){
                        var copyDOM = document.querySelectorAll('#selector'+index);
                        var range = document.createRange();  
                        range.selectNode(copyDOM[0]);
                        window.getSelection().removeAllRanges();
                        window.getSelection().addRange(range);
                        document.execCommand('copy');
                        $("body").append(tipsHtml);
                        setTimeout(function(){
                            $("#share-tips").remove();
                        },options.tipTime);   
                    },false);
                    
                });
                
            }
        }
    });
})(jQuery);
