/*
mumucms 下拉刷新、上拉加载更多组件
作者 : 深海  5213606@qq.com
官网 : http://www.hcoder.net/mumucms
*/
mumucms.refreshY = 0, mumucms.refreshIng = false, mumucms.refreshTitle, mumucms.refreshIcon1, mumucms.refreshNumber = 0, mumucms.loadMoreText = '';
mumucms.refresh = function(selector, func, icons1, icons2, loading){
	if(!icons1){icons1 = '<span class="mumucms_icons mumucms_icons_down"></span>继续下拉刷新';}
	mumucms.refreshIcon1 = icons1;
	if(!icons2){icons2 = '<span class="mumucms_icons mumucms_icons_up"></span>释放立即刷新';}
	if(!loading){loading = '<div class="mumucms_loading_wrap"><div class="mumucms_loading" style="margin:18px 5px 0px 0px;"></div><div class="mumucms_loading_text">加载中</div></div>';}
	var dom = mumucms(selector); mumucms.refreshTitle = dom.find('.mumucms_refresh_icon');
	mumucms.refreshTitle.html(icons1);
	var mumucmsRefreshStartY = 0, winInfo;
	dom.dom[0].addEventListener('touchstart',function(e){
		mumucms.refreshY = 0;
		winInfo = mumucms.winInfo();
		mumucmsRefreshStartY = e.touches[0].clientY;
	}, false);
	dom.dom[0].addEventListener('touchmove',function(e){
		if(winInfo.scrollTop > 1){return false;}
		mumucms.refreshY = e.changedTouches[0].clientY - mumucmsRefreshStartY;
		mumucms.refreshY  = mumucms.refreshY / 4;
		if(mumucms.refreshY < 1 || mumucms.refreshY >= 60){return;}
		if(mumucms.refreshY >= 50){mumucms.refreshTitle.html(icons2);}
		mumucms.refreshTitle.css({'marginTop' : (mumucms.refreshY - 60) + 'px'});
	}, false);
	dom.dom[0].addEventListener('touchend',function(e){
		if(mumucms.refreshIng){return false;}
		if(winInfo.scrollTop > 1){return false;}
		if(mumucms.refreshY >= 50){
			mumucms.refreshIng = true;
			mumucms.refreshTitle.html(loading);
			mumucms.refreshNumber++;
			func();
		}else{
			mumucms.refreshIng = false;
			mumucms.refreshTitle.css({'marginTop' :'-60px'});
		}
	}, false);
	mumucms.refreshIng = true;
	func();
}
mumucms.endRefresh = function(){
	mumucms.refreshIng = false;
	mumucms.refreshTitle.css({'marginTop' : '-60px'});
	mumucms.refreshTitle.html(mumucms.refreshIcon1);
}
/* 上拉加载更多 */
mumucms.loadMoreEnd = false;
mumucms.loadMore = function(func, title, loading){
	if(!title){title = '<span class="mumucms_icons mumucms_icons_up"></span>上拉加载更多';}
	if(!loading){loading = '<div class="mumucms_loading_wrap"><div class="mumucms_loading" style="margin:8px 5px 0px 0px;"></div><div class="mumucms_loading_text">加载中</div></div>';}
	mumucms.loadMoreText = title;
	var dom = mumucms('#mumucms_load_more'), winInfo = mumucms.winInfo();
	if(dom.length < 1){
		dom = document.createElement('div');
		dom.setAttribute('id', 'mumucms_load_more');
		dom.innerHTML = title;
		document.body.appendChild(dom);
		dom = mumucms('#mumucms_load_more');
	}
	var loadMoreTimer = null;
	mumucms.onScroll(function(e){
		if(mumucms.refreshIng || mumucms.loadMoreEnd){return false;}
		if(loadMoreTimer != null){clearTimeout(loadMoreTimer);}
		loadMoreTimer = setTimeout(function(){
			var sets = dom.offset();
			if(sets.top < e + winInfo.height){
				mumucms.refreshIng = true;
				dom.html(loading);
				func();
			}
		},200);
	});
}
mumucms.endLoadMore = function(isEnd, endMsg){
	if(!endMsg){endMsg = '已经加载全部';}
	var dom = mumucms('#mumucms_load_more');
	if(isEnd){dom.html(endMsg); mumucms.loadMoreEnd = true;}
	mumucms.refreshIng = false;
}
mumucms.resetLoadMore = function(){
	mumucms.loadMoreEnd = false;
	mumucms('#mumucms_load_more').html(mumucms.loadMoreText);
}
