<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}


$fids= implode(",",$ajaxfid);//调用的版块，多个用英文逗号分开

$order= 'dateline';//排序方式

$messagelength='500';//内容字数

$allnum=100;//控制总的显示条数，如果需要客气就取消这个注释，将下面的$allnum的语句注释掉

$num=10;//每页显示条数
$begin=($_G['page']-1)*$num;
$manylist=array();
require_once libfile('function/post');
$rs=DB::query("SELECT t.*,a.gender,p.message,p.pid,f.name FROM ".DB::table("forum_thread")." t LEFT JOIN ".DB::table("forum_post")." p on p.tid=t.tid LEFT JOIN ".DB::table("common_member_profile")." a on a.uid=p.authorid LEFT JOIN ".DB::table("forum_forum")." f on f.fid=t.fid WHERE t.`fid` in ($fids) and t.displayorder>=0 and p.first=1 group by t.tid ORDER BY t.`$order` DESC LIMIT $begin , $num");
while ($rw=DB::fetch($rs)) {
        $rw['message']=messagecutstr($rw['message'],$messagelength,'');
        $rw['message']=dhtmlspecialchars($rw['message']);
        $manylist[]=$rw;
}
//$allnum=DB::result_first("select count(*) from ".DB::table("forum_thread")." where fid in ($fids)");
$page = 10;//显示几个分页
$pagenav=multi($allnum,$num,$_G['page'],"portal.php?mod=index&mobile=2",$page);

?>
