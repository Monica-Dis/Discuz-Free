/*
 @ 文本框插入表情插件
 @ 作者：水墨寒 mumucms.net
 @ 日期：2013年1月28日
*/
$(function() {
	$.fn.mumucmsfacebox = function(options) {
		var defaults = {
		Event : "click", //响应事件		
		divid : "mumucms_face", //表单ID（textarea外层ID）
		textid : "TextArea" //文本框ID
		};
		var options = $.extend(defaults,options);
		var $btn = $(this);//取得触发事件的ID
		
		//创建表情框
		var faceimg = '';
	    for(i=30;i<62;i++){  //通过循环创建60个表情，可扩展
		 faceimg+='<li><a href="javascript:void(0)"><img src="static/image/smiley/mumucms_biaoqing/'+(i+1)+'.gif" face="[em:'+(i+1)+':]"/></a></li>';
		 };
		$("#"+options.divid).prepend("<div id='mumucms_facebox'><div class='face_content'><ul>"+faceimg+"</ul></div></div>");
		//创建表情框结束
		
		var $facepic = $("#mumucms_facebox li img");
		//BTN触发事件，显示或隐藏表情层

		//插入表情
		$facepic.die().click(function(){
		     $('#mumucms_facebox').hide();
			 $("#"+options.textid).die().insertContent($(this).attr("face"));
			});	
  };  

  // 【漫画】 光标定位插件
	$.fn.extend({  
		insertContent : function(myValue, t) {  
			var $t = $(this)[0];  
			if (document.selection) {  
				this.focus();  
				var sel = document.selection.createRange();  
				sel.text = myValue;  
				this.focus();  
				sel.moveStart('character', -l);  
				var wee = sel.text.length;  
				if (arguments.length == 2) {  
				var l = $t.value.length;  
				sel.moveEnd("character", wee + t);  
				t <= 0 ? sel.moveStart("character", wee - 2 * t	- myValue.length) : sel.moveStart("character", wee - t - myValue.length);  
				sel.select();  
				}  
			} else if ($t.selectionStart || $t.selectionStart == '0') {  
				var startPos = $t.selectionStart;  
				var endPos = $t.selectionEnd;  
				var scrollTop = $t.scrollTop;  
				$t.value = $t.value.substring(0, startPos) + myValue + $t.value.substring(endPos,$t.value.length);  
				this.focus();  
				$t.selectionStart = startPos + myValue.length;  
				$t.selectionEnd = startPos + myValue.length;  
				$t.scrollTop = scrollTop;  
				if (arguments.length == 2) { 
					$t.setSelectionRange(startPos - t,$t.selectionEnd + t);  
					this.focus(); 
				}  
			} else {                              
				this.value += myValue;                              
				this.focus();  
			}  
		}  
	});	  
  

});

