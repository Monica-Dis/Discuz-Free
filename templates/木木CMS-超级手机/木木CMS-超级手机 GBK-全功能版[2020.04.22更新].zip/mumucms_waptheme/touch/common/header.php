<?php echo 'From: DisM.taobao.com';exit;?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gb2312">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by DisM.Taobao.Com!</title>
<base href="{$_G['siteurl']}" />
<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>
<script src="{$_G['style'][tpldir]}/img/js/jquery.min.js?{VERHASH}" charset="{CHARSET}"></script>
<script src="{$_G['style'][tpldir]}/img/js/common.js?{VERHASH}" charset="{CHARSET}"></script>
<script src="{$_G['style'][tpldir]}/img/js/TouchSlide.1.1.js?{VERHASH}"  charset="{CHARSET}"></script>
<link href="{$_G['style'][tpldir]}/common/css/common.css?{VERHASH}" rel="stylesheet" />
<link href="{$_G['style'][tpldir]}/img/common.css?{VERHASH}" rel="stylesheet" />
<link href="{$_G['style'][tpldir]}/img/font/iconfont.css" rel="stylesheet" />	
<link href="{$_G['style'][tpldir]}/img/swiper.min.css?{VERHASH}" rel="stylesheet" /> 
<!--{if $_GET['diy'] == 'yes'}-->
	<link href="{$_G['style'][tpldir]}/img/common_diy.css?{VERHASH}" rel="stylesheet" />
 <!--{/if}-->
<!--{eval $mumucms_wapcontrol_defaultcolor = $_G['cache']['plugin']['mumucms_wapcontrol']['mumucms_wapcontrol_defaultcolor'];}-->
<!--{if empty($_G['cookie']['mumucms_style'])}-->
<link href="{$_G['style'][tpldir]}/touch/style/t{$mumucms_wapcontrol_defaultcolor}/style.css?{VERHASH}" rel="stylesheet" id="mumucms_style_file" />
<!--{else}-->
<link href="{$_G['style'][tpldir]}/touch/style/$_G['cookie']['mumucms_style']/style.css?{VERHASH}" rel="stylesheet" id="mumucms_style_file" />
<!--{/if}-->
</head>

<body class="mumucms_bg">
<!--{hook/global_header_mobile}-->
<div class="mumucms_zdcode">$_G['cache']['plugin']['mumucms_wapcontrol']['mumucms_wapcontrol_zdcode']</div>
<!--{if $_G['cache']['mumucms_startup']['startup_qiyong'] == 1}-->
	<!--{template other_plugin/startup_plugin}-->
<!--{/if}-->

