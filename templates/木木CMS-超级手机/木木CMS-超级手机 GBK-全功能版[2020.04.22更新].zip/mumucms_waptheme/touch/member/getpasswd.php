<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<header class="mumucms_wapheader">
    <div class="mumucms_menu"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-youcecaidan"></i><!--{avatar($space[uid],middle)}--></a></div>
    <h1>$_G[setting][bbname]</h1>
    <div class="mumucms_sousuo"><a href="search.php?mod=forum&amp;mobile=2"><i class="iconfont icon-sousuo"></i></a></div>
</header>
<div class="mumucms_wrap mumucms_member">
	<div class="mumucms_loginbox">
		<form method="post" autocomplete="off" action="member.php?mod=getpasswd&uid=$uid&id=$hashid&sign=$_GET[sign]">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<div class="mumucms_login_from">	
				<ul>
				<li>{lang username}:$member[username]</li>
				<li><input type="password" tabindex="2" class="mumucms_px" size="30" value="" id="newpasswd1" name="newpasswd1" placeholder="������{lang new_password}" fwin="login"></li>
				<li>{lang register_password_tips}<!--{if $_G['setting']['pwlength']}-->, {lang register_password_length_tips1} $_G['setting']['pwlength'] {lang register_password_length_tips2}<!--{/if}--></li>
				<li><input type="password" tabindex="2" class="mumucms_px" size="30" value="" id="newpasswd2" name="newpasswd2" placeholder="{lang new_password_confirm}" fwin="login"></li>
				<li>��ȷ�����룬���������뱣��һ��</li>
				</ul>
			</div>	
			<div class="mumucms_btn_login"><button tabindex="3" value="true" name="getpwsubmit" type="submit" class="mumucms_button mumucms_button_large mumucms_primary"><span>{lang submit}</span></button></div>				
		</form>
			<script type="text/javascript" src="{$_G[setting][jspath]}register.js?{VERHASH}"></script>
			<script type="text/javascript">
				var strongpw = new Array();
				<!--{if $_G['setting']['strongpw']}-->
					<!--{loop $_G['setting']['strongpw'] $key $val}-->
					strongpw[$key] = $val;
					<!--{/loop}-->
				<!--{/if}-->
				var pwlength = <!--{if $_G['setting']['pwlength']}-->$_G['setting']['pwlength']<!--{else}-->0<!--{/if}-->;
				checkPwdComplexity($('newpasswd1'), $('newpasswd2'));
			</script>		
		<!--{if $_G['setting']['regstatus']}-->
		<div class="reg_link">
		<a href="member.php?mod={$_G[setting][regname]}" class="mumucms_fl">ע�����˺�</a>
		<a href="member.php?mod=logging&action=login" class="mumucms_fr" title="�����˺ţ����ϵ�¼">�����˺ţ����ϵ�¼</a>
		</div>
		<!--{/if}-->	
	</div>
</div>
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>

<!--{template common/footer}-->
