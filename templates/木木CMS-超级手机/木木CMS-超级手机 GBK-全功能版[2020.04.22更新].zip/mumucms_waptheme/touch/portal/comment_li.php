<?php echo 'From: DisM.taobao.com';exit;?>
<a name="comment_anchor_$comment[cid]"></a>

<div class="mumucms_plc" id="comment_{$comment[cid]}_li">
   	<div class="mumucms_avatar cl">
   		<!--{if !empty($comment['uid'])}-->
		<div class="authi"><!--{avatar($comment[uid],middle)}--></div>
		<h3>
			<a href="home.php?mod=space&uid=$comment[uid]" class="username">$comment[username]</a>
			<!--{if !isset($_G[makehtml])}--><em><a href="javascript:;" class="reference mumucms_open_bpop" onclick="portal_comment_requote($comment[cid], '$article[aid]');">{lang quote}</a></em><!--{/if}-->
			<!--{if ($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']}-->
			<em><a href="portal.php?mod=portalcp&ac=comment&op=edit&cid=$comment[cid]" id="c_$comment[cid]_edit"  class="dialog">{lang edit}</a></em>
			<em><a href="portal.php?mod=portalcp&ac=comment&op=delete&cid=$comment[cid]" id="c_$comment[cid]_delete" class="dialog">{lang delete}</a></em>
			<!--{/if}-->
		</h3>
		<!--{else}-->
			{lang guest}
		<!--{/if}-->
		<div class="time"><span><!--{date($comment[dateline])}--></span></div>
	</div>
       <div class="mumucms_pi" href="#replybtn_120">
			<div class="message">
			<!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->$comment[message]<!--{else}--> {lang moderate_not_validate}<!--{/if}-->
			</div>
       </div>
</div>
