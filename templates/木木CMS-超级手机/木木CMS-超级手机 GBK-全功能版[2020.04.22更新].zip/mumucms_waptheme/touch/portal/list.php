<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--[name][ľľCMS]����Ƶ��-ͼ���б�ģ��[/name]-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>$navtitle</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<!--{if $catid == 11}-->
<!--{hook/global_job_mobile}-->
<div class="mumucms_wrap mumucms_search">
<style id="diy_style" type="text/css"></style>
<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>
<!--{else}-->

<div class="mumucms_wrap mumucms_search">

	<!--{if $cat[subs]}-->
		<div class="mumucms_huamenu">
			<div class="mumucms_type">
				<div class="cl">
				<!--{loop $cat[subs] $value}-->
				<div class="types{if $catid == $value['catid']} active{/if}"><a href="{$portalcategory[$value['catid']]['caturl']}">$value[catname]</a></div>	
				<!--{/loop}-->
				</div>
			</div>
		</div>
		<!--{elseif $cat[others]}-->
		<div class="mumucms_huamenu">
			<div class="mumucms_type">
				<div class="cl">
					<!--{loop $cat[others] $value}-->
					<div class="types{if $catid == $value['catid']} active{/if}"><a href="{$portalcategory[$value['catid']]['caturl']}">$value[catname]</a></div>	
					<!--{/loop}-->
				</div>
			</div>
		</div>
	<!--{/if}-->
</div>	
<!--{/if}-->

<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->

<div id="ct" class="ct2 wp cl mumucms_news_imagetext">
	<div class="mumucms_mn">
		<div class="mumucms_bm">

			<div class="mumucms_bm_c">
			<!--{loop $list['list'] $value}-->
				<!--{eval $highlight = article_title_style($value);}-->
				<!--{eval $article_url = fetch_article_url($value);}-->
				<dl class="mumucms_news_list cl">
					<!--{if $value[pic]}--><dt class="mumucms_fl img cl"><a href="$article_url"><img src="$value[pic]" alt="$value[title]" class="tn" /></a>
					</dt><!--{/if}-->
					<dd class="text cl">
					<h1 class="tit"><a href="$article_url" class="tit" $highlight>$value[title]</a> <!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}--></h1>					
					<p class="date">
						<span class="time"> $value[dateline]</span>
						<!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $value['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $value['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
						<span class="xg1">
							<span class="pipe">|</span>
							<label><a href="portal.php?mod=portalcp&ac=article&op=edit&catid=$value[catid]&aid=$value[aid]">{lang edit}</a></label>
							<span class="pipe">|</span>
							<label><a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$value[aid]" id="article_delete_$value[aid]" class="favorite dialog">{lang delete}</a></label>
						</span>
						<!--{/if}-->
					</p>	
					</dd>
				</dl>
			<!--{/loop}-->
			</div>
		</div>
		<!--{if $list['multi']}--><div class="mumucms_news_pgs cl">{$list['multi']}</div><!--{/if}-->
	</div>

</div>

</div>
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript">
mumucms('.mumucms_type').scrollX(4, '.types');
</script>
<script type="text/javascript">
var info_head_top = jQuery(".mumucms_type").offset().top;
jQuery(document).scroll(function(){
    var scrtop = jQuery(this).scrollTop()
    if(scrtop>info_head_top){
        jQuery(".mumucms_type").removeClass("mumucms_not_xuanfu").addClass("mumucms_xuanfu");
        jQuery("#back").show();
    }
    else{
        jQuery(".mumucms_type").removeClass("mumucms_xuanfu").addClass("mumucms_not_xuanfu");
        jQuery("#back").hide();
    }
});
</script>

<!--{template common/footer}-->
