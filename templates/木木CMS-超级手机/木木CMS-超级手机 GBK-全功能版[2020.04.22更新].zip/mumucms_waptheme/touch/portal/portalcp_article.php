<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<!--{if $op == 'delete'}-->
<div class="mumucms_tip">
	<div class="mumucms_tishi">{lang article_delete}</div>
	<form method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=article&op=delete&aid=$_GET[aid]">
		<dt>
			<!--{if $_G['group']['allowpostarticlemod'] && $article['status'] == 1}-->
			{lang article_delete_sure}
			<input type="hidden" name="optype" value="0" class="pc" />
			<!--{else}-->
			<p><label class="lb"><input type="radio" name="optype" value="0" class="pc" />{lang article_delete_direct}</label></p>
			<p><label class="lb"><input type="radio" name="optype" value="1" class="pc" checked="checked" />{lang article_delete_recyclebin}</label></p>
			<!--{/if}-->
		</dt>
		<dd>
			<a href="javascript:;" onclick="popup.close();">ȡ��</a>
			<input class="button2" type="submit" name="btnsubmit" value="{lang confirms}">
		</dd>
		<input type="hidden" name="aid" value="$_GET[aid]" />
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" id="attach_ids" name="attach_ids" value="0">
	</form>
</div>
<!--{elseif $op == 'verify'}-->
<h3 class="flb">
	<em id="return_$_GET[handlekey]">{lang moderate_article}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>

<form method="post" autocomplete="off" id="aritcle_verify_$aid" action="portal.php?mod=portalcp&ac=article&op=verify&aid=$aid">
	<div class="c">
		<label for="status_0" class="lb"><input type="radio" class="pr" name="status" value="0" id="status_0"{if $article[status]=='1'} checked="checked"{/if} />{lang passed}</label>
		<label for="status_x" class="lb"><input type="radio" class="pr" name="status" value="-1" id="status_x" />{lang delete}</label>
		<label for="status_2" class="lb"><input type="radio" class="pr" name="status" value="2" id="status_2"{if $article[status]=='2'} checked="checked"{/if} />{lang ignore}</label>
	</div>
	<p class="o pns">
		<button type="submit" name="btnsubmit" value="true" class="pn pnc"><strong>{lang confirms}</strong></button>
	</p>
	<input type="hidden" name="aid" value="$aid" />
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="handlekey" value="$_GET['handlekey']" />
	<input type="hidden" name="verifysubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
</form>
<!--{elseif $op == 'related'}-->

	<!--{if $ra}-->
	<li id="raid_li_$ra[aid]"><input type="hidden" name="raids[]" value="$ra[aid]" size="5">[ $ra[aid] ] <a href="{echo fetch_article_url($ra);}" target="_blank">$ra[title]</a> <a href="javascript:;" onclick="raid_delete($ra[aid]);">{lang delete}</a></li>
	<!--{/if}-->

<!--{elseif $op == 'pushplus'}-->
<h3 class="flb">
	<em>{lang article_pushplus}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>
<form method="post" target="_blank" action="portal.php?mod=portalcp&ac=article&tid=$tid&aid=$aid">
	<div class="c">
		<b>$pushcount</b> {lang portalcp_article_message1}<a href="$article_url" target="_blank" class="xi2">({lang view_article})</a>
		<!--{if $pushedcount}--><br />{lang portalcp_article_message2}<!--{/if}-->
		<div id="pushplus_list">
		<!--{loop $pids $pid}-->
		<input type="hidden" name="pushpluspids[]" value="$pid" />
		<!--{/loop}-->
		</div>
	</div>
	<p class="o pns">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="pushplussubmit" value="1" />

		<input type="hidden" name="toedit" value="1" />
		<button type="submit" class="pn pnc vm"><span>{lang submit}</span></button>
	</p>
</form>
<!--{elseif $op == 'add_success'}-->
	<!-- header start -->
	<header class="mumucms_wapheader">
	    <div class="mumucms_menu"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-youcecaidan"></i><!--{avatar($space[uid],middle)}--></a></div>
	    <h1>$_G[setting][bbname]</h1>
	    <div class="mumucms_sousuo"><a href="search.php?mod=forum&amp;mobile=2"><i class="iconfont icon-sousuo"></i></a></div>
	</header>
	<!-- header end -->
	<div class="mumucms_wrap mumucms_jump">
		<div class="jump_c">
			<p class="cg mtb jxcz">{lang article_send_succeed}</p>
			<p class="jxcz mtb"><a href="{$article_add_url}&op=edit&aid=$aid">{lang article_edit}</a></p>
			<p class="jxcz mtb"><a href="$article_add_url">{lang article_send_continue}</a></p>
			<p class="jxcz mtb"><a href="portal.php?mod=view&aid=$aid">{lang view_article}</a></p>
		</div>
	</div>
	<script src="{STATICURL}js/makehtml.js" type="text/javascript"></script>
	<script type="text/javascript">
	<!--{if !empty($_G['cookie']['clearUserdata']) && $_G['cookie']['clearUserdata'] == 'home'}-->
		saveUserdata('home', '')
	<!--{/if}-->
	make_html('portal.php?mod=view&aid={$aid}', $('makehtml_'));
	</script>
<!--{else}-->
		<style type="text/css">.mumucms_bg{background:#FFF;}</style>
		<!-- header start -->
		<header class="mumucms_wapheader">
		    <div class="mumucms_menu"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-youcecaidan"></i><!--{avatar($space[uid],middle)}--></a></div>
		    <h1>$_G[setting][bbname]</h1>
		    <div class="mumucms_sousuo"><a href="search.php?mod=forum&amp;mobile=2"><i class="iconfont icon-sousuo"></i></a></div>
		</header>
		<!-- header end -->

		<div class="mumucms_wrap mumucms_post">
			<div class="mumucms_post_from">
		   	    <div class="mumucms_huamenu"> 
		    			<div class="mumucms_type">
						<div class="cl">
							<!--{if !empty($aid)}-->
		                    <div class="types active">{lang article_edit}</div>
		                    <!--{else}-->
		 					<div class="types active">{lang article_publish}</div>
		                    <!--{/if}-->
						</div>
					</div>
			    </div>
		<script type="text/javascript" src="{$_G[setting][jspath]}calendar.js?{VERHASH}"></script>
		<form method="post" autocomplete="off" id="articleform" action="portal.php?mod=portalcp&ac=article{if $_GET[modarticlekey]}&modarticlekey=$_GET[modarticlekey]{/if}" enctype="multipart/form-data">

			<div id="htmlname_" class="dopt mtn cl"{if !$htmlstatus} style="display: none"{/if}>
				<span class="z mtn" style="width: 80px;">HTML{lang filename}:</span>
				<input type="text" name="htmlname" id="htmlname" class="px" value="$article[htmlname]" size="80" onblur="check_htmlname_exists(this)"/>.{$_G['setting']['makehtml']['extendname']}
				<strong id="checkhtmlnamemsg"></strong>
				<input type="hidden" name="oldhtmlname" id="oldhtmlname" value="$article[htmlname]" />
			</div>
			<div id="pagetitle_" class="dopt mtn cl"{if $article[contents] < 2} style="display: none"{/if}>
				<span class="z mtn" style="width: 80px;">{lang page_title}:&nbsp;</span>
				<input type="text" name="pagetitle" id="pagetitle" class="px" value="$article_content[title]" size="80" />
			</div>


			<div class="mumucms_bl_none">
			<div class="zhusum">���±���</div>		
			<div class="mumucms_subject">
				<!--{if $_GET['action'] != 'reply'}-->
				<input type="text" tabindex="1" class="mumucms_px" id="title" size="30" autocomplete="off" value="$article[title]" name="title" placeholder="���������±��⣨���" fwin="login">
				<!--{else}-->
					RE: $thread['subject']
					<!--{if $quotemessage}-->$quotemessage<!--{/if}-->
				<!--{/if}-->
			</div>				
			<!--{if $_G['cache']['portalcategory'] && $categoryselect}-->
				<div class="zhusum">{lang article_category}</div>	
				<div class="mumucms_subject mumucms_select">$categoryselect
				<script type="text/javascript">simulateSelect('catid', 158);</script></div>
			<!--{/if}-->				
			<div class="zhusum">{lang article_author}</div>	
				<div class="mumucms_subject">
					<input type="text" name="author" class="mumucms_px" value="$article[author]" size="30" placeholder="������{lang article_author}" />
				</div>			
			<div class="zhusum">{lang article_dateline}</div>	
				<div class="mumucms_subject">
					<input type="text" name="dateline" class="mumucms_px" value="{if !empty($article[dateline])}$article[dateline]{else}{eval echo date("Y-m-d H:i:s");}{/if} " size="30" onclick="showcalendar(event, this, true)" placeholder="������{lang article_dateline}" />
				</div>
			<div class="zhusum">����</div>
			<div class="mumucms_area">
				<textarea class="pt" id="needmessage" tabindex="3" autocomplete="off" id="uchome-ttHtmlEditor" name="content" placeholder="˵��ʲô�ɣ�" fwin="reply">$article_content[content]</textarea>
			</div>
			<script type="text/javascript" language="javascript" src="{STATICURL}image/editor/editor_function.js?{VERHASH}"></script>
			<!--{subtemplate portal/editor_image_menu}-->
			<!--{if $category[$catid][allowcomment]}-->
			<div class="zhusum">{lang article_comment_setup}</div>
			<div class="mumucms_area"><label for="ck_allowcomment" class="mumucms_label"><input type="checkbox" name="forbidcomment" id="ck_allowcomment" value="1"{if isset($article['allowcomment']) && empty($article['allowcomment'])}checked="checked"{/if} />{lang article_forbidcomment_description}</label></div>
			<!--{/if}-->						
			</div>

			<div class="mumucms_pobut">
				<button id="issuance" class="formdialog mumucms_fbbut mumucms_button mumucms_button_large mumucms_fbbut_grey mumucms_primary" name="articlebutton" disable="false"><span>����</span></button>

				<label id="innernavele"{if $article[contents] < 2} style="display: none"{/if} for="ck_showinnernav"><input type="checkbox" name="showinnernav" id="ck_showinnernav" class="pc" value="1"{if !empty($article['showinnernav'])}checked="checked"{/if} />{lang article_show_inner_navigation}</label>
			</div>

			<input type="hidden" id="aid" name="aid" value="$article[aid]" />
			<input type="hidden" name="cid" value="$article_content[cid]" />
			<input type="hidden" id="attach_ids" name="attach_ids" value="0" />
			<input type="hidden" name="articlesubmit" value="true" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="conver" id="conver" value="" />
		</form>
			</div>
		</div>
<iframe id="uploadframe" name="uploadframe" width="0" height="0" marginwidth="0" frameborder="0" src="about:blank"></iframe>
<script type="text/javascript">
function from_get() {
	var el = $('catid');
	var catid = el ? el.value : 0;
	window.location.href='portal.php?mod=portalcp&ac=article&from_idtype='+$('from_idtype').value+'&catid='+catid+'&from_id='+$('from_id').value+'&getauthorall='+($('getauthorall').checked ? '1' : '');
	return true;
}
function validate(obj) {
	var title = $('title');
	if(title) {
		var slen = strlen(title.value);
		if (slen < 1 || slen > 80) {
			alert("{lang article_validate_title}");
			title.focus();
			return false;
		}
	}
	if(!check_catid()) {
		return false;
	}
	edit_save();
	window.onbeforeunload = null;
	obj.form.submit();
	return false;
}
function check_catid(){
	var catObj = $("catid");
	if(catObj) {
		if (catObj.value < 1) {
			alert("{lang article_validate_category}");
			catObj.focus();
			return false;
		}
	}
	return true;
}
function raid_add() {
	var raid = $('raid').value;
	if($('raid_li_'+raid)) {
		alert('{lang article_validate_has_added}');
		return false;
	}
	var url = 'portal.php?mod=portalcp&ac=article&op=related&inajax=1&aid={$article[aid]}&raid='+raid;
	var x = new Ajax();
	x.get(url, function(s){
		s = trim(s);
		if(s) {
			$('raid_div').innerHTML += s;
		} else {
			alert('{lang article_validate_noexist}');
			return false;
		}
	});
}
function raid_delete(aid) {
	var node = $('raid_li_'+aid);
	var p;
	if(p = node.parentNode) {
		p.removeChild(node);
	}
}
function switchhl(obj, v) {
	if(parseInt($('highlight_style_' + v).value)) {
		$('highlight_style_' + v).value = 0;
		obj.className = obj.className.replace(/ cnt/, '');
	} else {
		$('highlight_style_' + v).value = 1;
		obj.className += ' cnt';
	}
}
function change_title_color(hlid) {
	var showid = hlid;
	if(!$(showid + '_menu')) {
		var str = '';
		var coloroptions = {'0' : '#000', '1' : '#EE1B2E', '2' : '#EE5023', '3' : '#996600', '4' : '#3C9D40', '5' : '#2897C5', '6' : '#2B65B7', '7' : '#8F2A90', '8' : '#EC1282'};
		var menu = document.createElement('div');
		menu.id = showid + '_menu';
		menu.className = 'cmen';
		menu.style.display = 'none';
		for(var i in coloroptions) {
			str += '<a href="javascript:;" onclick="$(\'highlight_style_0\').value=\'' + coloroptions[i] + '\';$(\'' + showid + '\').style.backgroundColor=\'' + coloroptions[i] + '\';hideMenu(\'' + menu.id + '\')" style="background:' + coloroptions[i] + ';color:' + coloroptions[i] + ';">' + coloroptions[i] + '</a>';
		}
		menu.innerHTML = str;
		$('append_parent').appendChild(menu);
	}
	showMenu({'ctrlid':hlid + '_ctrl','evt':'click','showid':showid});
}
if($('title')) {
	$('title').focus();
}
function setConver(attach) {
	$('conver').value = attach;
}

function deleteAttach(attachid, url) {
	ajaxget(url);
	$('attach_list_' + attachid).style.display = 'none';
	if($('setconver' + attachid).checked) {
		$('conver').value = '';
	}
}
<!--{if !empty($article['conver'])}-->
setConver('$article[conver]');
<!--{/if}-->
function check_htmlname_exists(obj) {
	name = obj.value;
	var msg = $('checkhtmlnamemsg');
	if(name && $('oldhtmlname').value != name) {
		var catid = $('catid').value;
		var aid = $('aid').value;
		var x = new Ajax();
		x.getJSON('portal.php?mod=portalcp&ac=article&op=checkhtmlname&htmlname='+name+'&catid='+catid+'&aid='+aid, function(s){
			if(s['message'] == 'html_existed') {
				obj.focus();
				msg.style.color = 'red';
				msg.style.paddingLeft = '10px';
				msg.innerHTML = '{lang article_html_existed}';
				$('issuance').disabled = 'disabled';
			} else {
				msg.innerHTML = '';
				$('issuance').disabled = '';
			}
		});
	} else {
		msg.innerHTML = '';
		$('issuance').disabled = '';
	}
}
</script>

</div>
<!--{/if}-->
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<!--{template common/footer}-->

