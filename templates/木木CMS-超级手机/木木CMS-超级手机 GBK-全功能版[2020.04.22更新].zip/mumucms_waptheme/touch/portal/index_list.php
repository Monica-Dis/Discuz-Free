


<!--{eval require_once("template/mumucms_waptheme/source/mumucms_index_list.php");}-->
<div class="mumucms_threadlist">
<!--{eval $list_count=0;}-->
<!--{loop $manylist $thread}-->
<!--{eval $list_count+=1;}-->
<li class="list" id="thread_$thread[tid]">
	<div class="mumucms_listtit">
		<div class="mumucms_avatar">
			<!--{avatar($thread[authorid],small)}-->
		</div>
		<h3>
		<a href="forum.php?mod=viewthread&tid=$thread[tid]">$thread[author]</a>
		<!--{if $thread[gender] == 1}-->
		<i class="iconfont icon-nan gender"></i>
		<!--{elseif $thread[gender] == 2}-->
		<i class="iconfont icon-nv gender girl"></i>
		<!--{/if}-->
		</h3>
		<p>{echo date('Y-m-d', $thread['dateline']);}&nbsp;����&nbsp;$thread[name]</p>
		<div class="guanzhu">
			<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$thread[fid]&handlekey=favoriteforum&formhash={FORMHASH}" class="favorite dialog mumucms_a_color">+��ע</a>
		</div>
	</div>
	<div class="mumucms_listsubject">
		<h2><a href="forum.php?mod=viewthread&tid=$thread[tid]">$thread[subject]</a></h2>
	</div>
	<div class="mumucms_listsum">
		<a href="forum.php?mod=viewthread&tid=$thread[tid]"><!--{echo cutstr($thread['message'],100)}-->...</a>
	</div>
	<div class="mumucms_listpic">
	<!--{if $thread['attachment'] == 2}-->
	<!--{eval $tbid = DB::result(DB::query("SELECT tableid FROM ".DB::table('forum_attachment')." WHERE `tid`= '$thread[tid]'"));}-->
	<!--{if !is_null($tbid)}-->
	<!--{eval $picount = DB::fetch_all("SELECT aid FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1;");}-->
	<!--{eval $picnum = count($picount);}-->
	<!--{if $picnum < 3}-->
	<!--{eval $litpicnum = '1';}-->
	<!--{elseif $picnum > 2 && $picnum < 6}-->
	<!--{eval $litpicnum = '3';}-->
	<!--{elseif $picnum > 5}-->
	<!--{eval $litpicnum = '6';}-->
	<!--{/if}-->
	<!--{eval $covers = DB::fetch_all("SELECT attachment,aid,description FROM ".DB::table('forum_attachment_'.$tbid.'')." WHERE `tid`= '$thread[tid]' AND `isimage`=1 LIMIT 0,$litpicnum;");}-->
	<!--{/if}-->
	<!--{eval $picnum = count($picount);}-->
		<!--{if $picnum < 3}-->
		<div class="threadlist_imglist">
			<!--{if $litpicnum == 1}-->
			<!--{loop $covers $thecover}-->
				<!--{eval $piclist = getforumimg($thecover[aid], 0, 420, 9999); }-->
				<a href="forum.php?mod=viewthread&tid=$thread[tid]"><img class="img" src="$piclist"/></a>
			<!--{/loop}-->
			<!--{/if}-->
			</div>
		<!--{elseif $picnum > 2 && $picnum < 6}-->
			<div class="threadlist_imglist">
			<!--{if $litpicnum == 3}-->
			<!--{loop $covers $thecover}-->
			<!--{eval $piclist = getforumimg($thecover[aid], 0, 200, 150); }-->
			<a href="forum.php?mod=viewthread&tid=$thread[tid]"><img class="imgs" src="$piclist"/></a>
			<!--{/loop}-->
			<!--{/if}-->
			</div>
		<!--{/if}-->
	<!--{/if}-->
	</div>
	<div class="mumucms_num">
	<a href="forum.php?mod=viewthread&tid=$thread[tid]">
		<span class="views"><i class="iconfont icon-chakan2"></i>$thread[views]�Ķ�</span>
		<span class="replies"><i class="iconfont icon-huifu"></i>$thread[replies]����</span>
		<span class="zan"><i class="iconfont icon-zan"></i>$thread[recommend_add]��</span>	
	</a>
	</div>
</li>
<!--{/loop}-->
$pagenav
<!--{if $_SERVER["HTTP_X_REQUESTED_WITH"]=="XMLHttpRequest"}-->
	<!--{eval $pages = $_REQUEST['page'];}-->
	<!--{eval $pages++;}-->
		<!--{if $pages > 20}-->
			<!--{eval return;}-->
	 	<!--{/if}-->
<!--{else}-->
	<!--{eval $pages = 2;}-->
<!--{/if}-->

<div class="mumucms_page"><a class="next_page" href="portal.php?mod=index&mobile=2&page=$pages">��һҳ</a></div>

</div>

<script src="{$_G['style'][tpldir]}/img/js/jquery-ias.min.js?{VERHASH}" charset="{CHARSET}"></script>
<script type="text/javascript">
	var ias = jQuery.ias({
	  container:  '.mumucms_threadlist',
	  item:       '.list',
	  pagination: '.mumucms_page',
	  next:       'a.next_page',
	});
	ias.extension(new IASTriggerExtension({
	    text: '����鿴����',
	    offset: 10, 
	}));
	ias.extension(new IASSpinnerExtension());
	ias.extension(new IASNoneLeftExtension({
	    text: '�Ѿ���ȫ��������', 
	}));	
</script>
