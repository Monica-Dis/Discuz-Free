<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<!--{if $_GET['op'] == 'requote'}-->
	[quote]{$comment[username]}: {$comment[message]}[/quote]

<!--{elseif $_GET['op'] == 'edit'}-->
<div class="mumucms_tip">
	<div class="mumucms_tishi">{lang comment_edit_content}</div>
	<form id="editcommentform_{$cid}" name="editcommentform_{$cid}" method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=comment&op=edit&cid=$cid{if $_GET[modarticlecommentkey]}&modarticlecommentkey=$_GET[modarticlecommentkey]{/if}">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="mumucms_edit">
			<textarea id="message_{$cid}" name="message" cols="70" onkeydown="ctrlEnter(event, 'editsubmit_btn');" rows="8" class="pt">$comment[message]</textarea>
		</div>
		<dd>
			<a href="javascript:;" onclick="popup.close();">ȡ��</a>
			<input class="button2" type="submit" name="editsubmit_btn" value="{lang submit}">
		</dd>
	</form>
</div>
<!--{elseif $_GET['op'] == 'delete'}-->
<div class="mumucms_tip">
	<form id="deletecommentform_{$cid}" name="deletecommentform_{$cid}" method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=comment&op=delete&cid=$cid">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<dt><p>{lang comment_delete_confirm}</p></dt>
		<dd>
			<a href="javascript:;" onclick="popup.close();">ȡ��</a>
			<input class="button2" type="submit" name="deletesubmitbtn" value="{lang confirms}">
		</dd>
	</form>
</div>
<!--{/if}-->

<!--{template common/footer}-->
