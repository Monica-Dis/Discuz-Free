<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_menu"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-youcecaidan"></i><!--{avatar($space[uid],middle)}--></a></div>
    <h1>$_G[setting][bbname]</h1>
    <div class="mumucms_sousuo"><a href="search.php?mod=forum&mobile=2"><i class="iconfont icon-sousuo"></i></a></div>
</header>
<!-- header end -->

<div class="mumucms_wrap mumucms_index">
<style id="diy_style" type="text/css"></style>
<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
<!--{eval $ajaxfid =array_filter((unserialize($_G['cache']['plugin']['mumucms_wapcontrol']['mumucms_wapcontrol_index_ajax'])));}-->
<!--{eval $fids= implode(",",$ajaxfid);}-->
<!--{if !empty($fids)}-->
<!--{template portal/index_list}-->
<!--{/if}-->
</div>

<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript" src="{$_G['style'][tpldir]}/img/js/swiper.min.js"></script>
<script type="text/javascript">
window.onload = function() {
    var navSwiper = new Swiper('.mumucms_subnav', {
        freeMode: true,
        slidesPerView: 'auto',
        freeModeSticky: true,
    });
    var navSwiper = new Swiper('.mumucms_activity', {
        freeMode: true,
        slidesPerView: 'auto',
        freeModeSticky: true,
    });
}
</script>
<script>
	var swiper = new Swiper('.mumucms_lbt', {
		loop : true,
	  	pagination: {
	   		el: '#swiper-pagination-lbt',
	  },
	});
</script>
<script>
	var swiper = new Swiper('#mumucms_kjdh', {
		autoplay:true,
		loop : true,
	  	pagination: {
	   		el: '#swiper-pagination-kjdh',
	  },
	});
</script>

<script type="text/javascript">
	mumucms.scrollNews(scrollnew1);
</script>
<!--{template common/footer}-->



