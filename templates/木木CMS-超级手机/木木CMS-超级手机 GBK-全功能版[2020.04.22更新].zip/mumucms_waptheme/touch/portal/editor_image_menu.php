<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $op=='edit'}-->

<!--{eval $query = DB::fetch_all("SELECT * FROM ".DB::table('portal_attachment')." WHERE `aid`='$_GET[aid]'");}-->

<!--{/if}-->
<ul id="mumucms_imglist" class="mumucms_imglist cl">
<li class="scimg"><i class="iconfont icon-jiahao1"></i><input type="file" name="Filedata" id="filedata"></li>

	<!--{if $query}-->
      <!--{loop $query $imsges}-->
      <!--{eval $aid=$imsges['aid'];}-->
      <li>
       <span attachid="$imsges[attachid]" id="$imsges[attachid]" class="del"><a href="javascript:;"><i class="iconfont icon-error"></i></a></a></span>
       <span class="p_img"><a href="javascript:;"><img style="height:60px;width:60px;" id="aimg_{$aid}" src="data/attachment/portal/{$imsges[attachment]}" /></a></span>
       <input type="hidden" name="attachnew[$aid][description]" />
      </li>
      <!--{/loop}-->
    <!--{/if}-->
</ul>
<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="{STATICURL}js/mobile/buildfileupload.js?{VERHASH}"></script>
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
	var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	var form = $('#postform');
	var covers=new Object();
	$(document).on('change', '#filedata', function() {
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

			uploadsuccess = function(data) {
				if(data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
				var dataarr = eval('('+data+')');
				if(dataarr.aid>0){
					covers[dataarr.aid]=dataarr.cover;
					var attach_ids=$("#attach_ids").val();
					attach_ids=attach_ids.split(",");
					attach_ids.push(dataarr.aid);
					$("#attach_ids").val(attach_ids.join(","));
					popup.close();
					$('#mumucms_imglist').append('<li><span aid="'+dataarr.attachid+'" class="del"><a href="javascript:;"><i class="iconfont icon-error"></i></a></span><span class="insert"><a href="javascript:;" onclick="addipic(\''+dataarr.bigimg+'\')">�������</a></span><span class="p_img"><a href="javascript:;" ><img style="height:60px;width:60px;" id="aimg_'+dataarr.aid+'" src="'+dataarr.smallimg+'" /></a></span></li>');
					$('#conver').val(covers[Object.keys(covers)[0]]);
				} else {
					var sizelimit = '';
					if(dataarr.errorcode==1){
						//û���ҵ�ָ�������£��༭ʱ����
					}else if(dataarr.errorcode==2){
						//���²������༭���༭ʱ����
					}else if(dataarr.errorcode==3){
						//��Ȩ�޷�������
					}else if(dataarr.errorcode==4){
						//�������ڲ�����δ�ϴ��ļ�
					}else if(dataarr.errorcode==5){
						//FTPԶ�̱��渽��ʱ���󣨲�������
					}
					/*
					�������²��ܵ���̳�ϴ�����ÿ�մ�С��ÿ������������
							== 'ban') {
						sizelimit = '{lang uploadpicatttypeban}';
					} else if(dataarr[7] == 'perday') {
						sizelimit = '{lang donotcross}{$swfconfig[max]}K)';
					} else if(dataarr[7] > 0) {
						sizelimit = '{lang donotcross}{$swfconfig[max]}K)';
					}
					
					popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
					*/
					popup.open('error_contents', 'alert');
				}
			};

			if(typeof FileReader != 'undefined' && this.files[0]) {//note ֧��html5�ϴ�������
				
				$.buildfileupload({
					uploadurl:'misc.php?mod=swfupload&action=swfupload&operation=portal',
					files:this.files,
					uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->",aid:"<!--{eval echo ($_GET['aid']?$_GET['aid']:0)}-->",catid:"<!--{eval echo $_GET['catid']}-->",Upload:"Submit Query"},
					uploadinputname:'Filedata',
					maxfilesize:"$swfconfig[max]",
					success:uploadsuccess,
					error:function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			} else {

				$.ajaxfileupload({
					url:'misc.php?mod=swfupload&action=swfupload&operation=portal',
					data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->",aid:"<!--{eval echo ($_GET['aid']?$_GET['aid']:0)}-->",catid:"<!--{eval echo $_GET['catid']}-->",Upload:"Submit Query"},
					dataType:'text',
					fileElementId:'filedata',
					success:uploadsuccess,
					error: function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			}
	});

	<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
	geo.getcurrentposition();
	<!--{/if}-->
	$('#postsubmit').on('click', function() {
		var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}

		obj.attr('disable', 'true').removeClass('mumucms_primary').addClass('mumucms_fbbut_grey');
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

		var postlocation = '';
		if(geo.errmsg === '' && geo.loc) {
			postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
		}

		$.ajax({
			type:'POST',
			url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

	$(document).on('click', '.del', function() {
		var obj = $(this);
		
		$('#conver').val(covers[Object.keys(covers)[0]]);
		//deleteAttach('13', 'portal.php?mod=attachment&id=13&op=delete');
		$.ajax({
			type:'GET',
			url:'portal.php?mod=attachment&id=' + obj.attr('attachid') + '&op=delete',
		})
		.success(function(s) {
			obj.parent().remove();
			delete covers[obj.attr('aid')];
			var attach_ids=$("#attach_ids").val();
			attach_ids=attach_ids.split(",");
			for(var i=0;i<attach_ids.length;i++){
				if(attach_ids[i]==obj.attr('aid')){
					attach_ids.splice(i,1);
					break;
				}
			}
			$("#attach_ids").val(attach_ids.join(","));
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

</script>
<script>

function addipic(aid) {
seditor_insertunit('need', '<img src="'+aid+'">');
}
function seditor_insertunit(key, text, textend, moveend, selappend) {
if(document.getElementById(key + 'message')) {
document.getElementById(key + 'message').focus();
}
textend = isUndefined(textend) ? '' : textend;
moveend = isUndefined(textend) ? 0 : moveend;
selappend = isUndefined(selappend) ? 1 : selappend;
startlen = strlen(text);
endlen = strlen(textend);
if(!isUndefined(document.getElementById(key + 'message').selectionStart)) {
if(selappend) {
var opn = document.getElementById(key + 'message').selectionStart + 0;
if(textend != '') {
text = text + document.getElementById(key + 'message').value.substring(document.getElementById(key + 'message').selectionStart, document.getElementById(key + 'message').selectionEnd) + textend;
}
document.getElementById(key + 'message').value = document.getElementById(key + 'message').value.substr(0, document.getElementById(key + 'message').selectionStart) + text + document.getElementById(key + 'message').value.substr(document.getElementById(key + 'message').selectionEnd);
if(!moveend) {
document.getElementById(key + 'message').selectionStart = opn + strlen(text) - endlen;
document.getElementById(key + 'message').selectionEnd = opn + strlen(text) - endlen;
}
} else {
text = text + textend;
document.getElementById(key + 'message').value = document.getElementById(key + 'message').value.substr(0, document.getElementById(key + 'message').selectionStart) + text + document.getElementById(key + 'message').value.substr(document.getElementById(key + 'message').selectionEnd);
}
} else if(document.selection && document.selection.createRange) {
var sel = document.selection.createRange();
if(!sel.text.length && document.getElementById(key + 'message').sel) {
sel = document.getElementById(key + 'message').sel;
document.getElementById(key + 'message').sel = null;
}
if(selappend) {
if(textend != '') {
text = text + sel.text + textend;
}
sel.text = text.replace(/\r?\n/g, '\r\n');
if(!moveend) {
sel.moveStart('character', -endlen);
sel.moveEnd('character', -endlen);
}
sel.select();
} else {
sel.text = text + textend;
}
} else {
document.getElementById(key + 'message').value += text;
}
//hideMenu(2);
}
function strlen(str) {
return (str.indexOf('\n') != -1) ? str.replace(/\r?\n/g, '_').length : str.length;
}
</script>
