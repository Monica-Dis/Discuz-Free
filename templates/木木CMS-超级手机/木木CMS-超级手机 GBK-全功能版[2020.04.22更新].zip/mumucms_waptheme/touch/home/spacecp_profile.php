<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>{lang memcp_profile}</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<div class="mumucms_wrap mumucms_profile">	
	<!--{if $validate}-->
		<p class="tbmu mbm">{lang validator_comment}</p>
		<form action="member.php?mod=regverify" method="post" autocomplete="off">
		<input type="hidden" value="{FORMHASH}" name="formhash" />
		<table summary="{lang memcp_profile}" cellspacing="0" cellpadding="0" class="tfm">
		<tr>
			<th>{lang validator_remark}</th>
			<td>$validate[remark]</td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<th>{lang validator_message}</th>
			<td><input type="text" class="px" name="regmessagenew" value="" /></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<th>&nbsp;</th>
			<td colspan="2">
				<button type="submit" name="verifysubmit" value="true" class="pn pnc" /><strong>{lang validator_submit}</strong></button>
			</td>
		</tr>
		</table>
		</div></div>
	<!--{else}-->
		<!--{if $operation == 'password'}-->
			<script type="text/javascript" src="{$_G[setting][jspath]}register.js?{VERHASH}"></script>
			<div class="mumucms_psot_forum">
				<div class="mumucms_zyjg" style="color:#FF9900;margin-bottom:10px;">
					<!--{if !$_G['member']['freeze']}-->
						<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->{lang old_password_comment}<!--{elseif $wechatuser}-->{lang wechat_config_newpassword_comment}<!--{else}-->{lang connect_config_newpassword_comment}<!--{/if}-->
					<!--{elseif $_G['member']['freeze'] == 1}-->
						<strong class="xi1">{lang freeze_pw_tips}</strong>
					<!--{elseif $_G['member']['freeze'] == 2}-->
						<strong class="xi1">{lang freeze_email_tips}</strong>
					<!--{/if}-->
				</div>
				<form action="home.php?mod=spacecp&ac=profile" method="post" autocomplete="off">
					<input type="hidden" value="{FORMHASH}" name="formhash" />
					<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->
					<div class="mumucms_zyjg">
						<div class="tit">{lang old_password}</div>
						<div class="sum"><input type="password" name="oldpassword" id="oldpassword" class="px" /></div>
					</div>
					<!--{/if}-->
					<div class="mumucms_zyjg">
						<div class="tit">{lang new_password}</div>
						<div class="sum"><input type="password" name="newpassword" id="newpassword" class="px" /></div>
					</div>
					<div class="mumucms_zyjg">
						<div class="tit">{lang new_password_confirm}</div>
						<div class="sum"><input type="password" name="newpassword2" id="newpassword2"class="px" /></div>
					</div>		
					<div class="mumucms_zyjg">
						<div class="tit">{lang email}</div>
						<div class="sum"><input type="text" name="emailnew" id="emailnew" value="$space[email]" class="px" />
						<!--{if empty($space['newemail'])}-->
							<i class="iconfont icon-youxiangyanzheng" style="color:#73b31c;"></i>
						<!--{/if}-->
						</div>
					</div>	
					<!--{if !empty($space['newemail'])}-->
					<div class="mumucms_zyjg">
						<div class="mumucms_newemail">������$space[newemail]�ȴ���֤��<a href="home.php?mod=spacecp&ac=profile&op=password&resend=1&mobile=2" class="dialog mumucms_fr">���½���</a>
						</div>
					</div>
					<!--{elseif $space[emailstatus] == 0}-->
					<div class="mumucms_zyjg">
						<div class="mumucms_newemail">������$space[newemail]�ȴ���֤��<a href="home.php?mod=spacecp&ac=profile&op=password&resend=1&mobile=2" class="dialog mumucms_fr">���½���</a>
						</div>
					</div>			
					<!--{/if}-->

					<!--{if $_G['setting']['regverify'] == 1 && (($_G['group']['grouptype'] == 'member' && $_G['adminid'] == 0) || $_G['groupid'] == 8) || $_G['member']['freeze']}--><div class="mumucms_zyjg">{lang memcp_profile_email_comment}</div><!--{/if}-->

					<!--{if $_G['member']['freeze'] == 2}-->
					<div class="mumucms_zyjg">
						<div class="tit">{lang freeze_reason}</div>
						<div class="sum"><textarea rows="3" cols="80" name="freezereson" class="pt">$space[freezereson]</textarea></div>
					</div>						
					<!--{/if}-->
					<div class="mumucms_zyjg">
						<div class="tit">{lang security_question}</div>
						<div class="sum">
							<select name="questionidnew" id="questionidnew" class="ps">
								<option value="" selected>{lang memcp_profile_security_keep}</option>
								<option value="0">{lang security_question_0}</option>
								<option value="1">{lang security_question_1}</option>
								<option value="2">{lang security_question_2}</option>
								<option value="3">{lang security_question_3}</option>
								<option value="4">{lang security_question_4}</option>
								<option value="5">{lang security_question_5}</option>
								<option value="6">{lang security_question_6}</option>
								<option value="7">{lang security_question_7}</option>
							</select>
							<i class="iconfont icon-yjiantou"></i>
						</div>
					</div>	

					<div class="mumucms_zyjg">
						<div class="tit">{lang security_answer}</div>
						<div class="sum"><input type="text" name="answernew" id="answernew" class="px" /></div>
					</div>
					<div class="mumucms_zyjg">
						<!--{if $secqaacheck || $seccodecheck}-->
							<!--{eval $sectpl = '<table cellspacing="0" cellpadding="0" class="tfm"><tr><th><sec></th><td><sec><p class="d"><sec></p></td></tr></table>';}-->
							<!--{subtemplate common/seccheck}-->
						<!--{/if}-->
					</div>	
					<div class="mumucms_pobut">
						<button type="submit" name="pwdsubmit" value="true" class="formdialog mumucms_fbbut mumucms_button mumucms_button_large mumucms_fbbut_grey mumucms_primary" /><strong>{lang save}</strong></button>
					</div>						
					<input type="hidden" name="passwordsubmit" value="true" />
				</form>
			</div>
			<script type="text/javascript">
				var strongpw = new Array();
				<!--{if $_G['setting']['strongpw']}-->
					<!--{loop $_G['setting']['strongpw'] $key $val}-->
					strongpw[$key] = $val;
					<!--{/loop}-->
				<!--{/if}-->
				var pwlength = <!--{if $_G['setting']['pwlength']}-->$_G['setting']['pwlength']<!--{else}-->0<!--{/if}-->;
				checkPwdComplexity($('newpassword'), $('newpassword2'), true);

							if(seccodecheck) {
				chkv = $('checkseccodeverify_' + theform.seccodehash.value).innerHTML;
				if(chkv.indexOf('loading') !== -1) {
					setTimeout(function () { validate(theform); }, 100);
					chk = 0;
				} else if(chkv.indexOf('check_right') === -1) {
					showError('��֤�������������д');
					chk = 0;
				}
			}
			
			</script>
		<!--{else}-->
			<div class="mumucms_type">
				<div class="cl">
					<!--{loop $profilegroup $key $value}-->
						<!--{if $value[available]}-->
						<div class="types{if $_GET['op'] == $key} active{/if}"><a href="home.php?mod=spacecp&ac=profile&op=$key">$value[title]</a></div>
						<!--{/if}-->
					<!--{/loop}-->
				</div>
			</div>			
				<!--{if $vid}-->
				<p class="tbms mtm {if !$showbtn}tbms_r{/if}"><!--{if $showbtn}-->{lang spacecp_profile_message1}<!--{else}-->{lang spacecp_profile_message2}<!--{/if}--></p>
				<!--{/if}-->
			<iframe id="frame_profile" name="frame_profile" style="display: none"></iframe>
			<div class="mumucms_psot_forum">
				<form action="{if $operation != 'plugin'}home.php?mod=spacecp&ac=profile&op=$operation{else}home.php?mod=spacecp&ac=plugin&op=profile&id=$_GET[id]{/if}" method="post" enctype="multipart/form-data" autocomplete="off"{if $operation != 'plugin'} target="frame_profile"{/if} onsubmit="clearErrorInfo();">
					<input type="hidden" value="{FORMHASH}" name="formhash" />
					<!--{if $_GET[vid]}-->
					<input type="hidden" value="$_GET[vid]" name="vid" />
					<!--{/if}-->
					<div class="mumucms_zyjg">
						<div class="tit">{lang username}</div>
						<div class="sum">$_G[member][username]</div>
					</div>
					<!--{loop $settings $key $value}-->
					<!--{if $value[available]}-->
						<div id="tr_$key" class="mumucms_zyjg">
							<div class="tit"><!--{if $value[required]}--><span class="rq" title="{lang required}">*</span><!--{/if}-->$value[title]</div>
							<div class="sum">$htmls[$key]<i class="iconfont icon-yjiantou"></i></div>
						</div>
					<!--{/if}-->
					<!--{/loop}-->

					<!--{if $allowcstatus && in_array('customstatus', $allowitems)}-->
						<div id="th_customstatus" class="mumucms_zyjg">
							<div class="tit">{lang permission_basic_status}</div>
							<div class="sum"><input type="text" value="$space[customstatus]" name="customstatus" id="customstatus" class="ps" /><i class="iconfont icon-yjiantou"></i></div>
						</div>
					<!--{/if}-->
					<!--{if $_G['group']['maxsigsize'] && in_array('sightml', $allowitems)}-->
						<div id="th_sightml" class="mumucms_zyjg">
							<div class="tit">{lang personal_signature}</div>
							<div class="sum"><textarea rows="3" cols="80" name="sightml" id="sightmlmessage" class="pt" onkeydown="ctrlEnter(event, 'profilesubmitbtn');">$space[sightml]</textarea></div>
						</div>
					<!--{/if}-->


					<!--{if $operation == 'contact'}-->
					<div class="mumucms_zyjg">
						<div class="tit">Email</div>
						<a href="home.php?mod=spacecp&ac=profile&op=password&from=contact#contact">
						<div class="sum">$space[email]<i class="iconfont icon-yjiantou"></i></div>
						</a>
					</div>
					<!--{/if}-->

					<!--{if $operation == 'plugin'}-->
						<!--{eval include(template($_GET['id']));}-->
					<!--{/if}-->

					<!--{if $showbtn}-->
					<div class="mumucms_pobut">
						<input type="hidden" name="profilesubmit" value="true" />
						<button type="submit" name="profilesubmitbtn" id="profilesubmitbtn" value="true" class="mumucms_fbbut mumucms_button mumucms_button_large mumucms_fbbut_grey mumucms_primary" /><strong>{lang save}</strong></button>
					</div>
					<!--{/if}-->
				</form>
			</div>
			<script type="text/javascript">
				function show_error(fieldid, extrainfo) {
					var elem = $('th_'+fieldid);
					if(elem) {
						elem.className = "rq";
						fieldname = elem.innerHTML;
						extrainfo = (typeof extrainfo == "string") ? extrainfo : "";
						$('showerror_'+fieldid).innerHTML = "{lang check_date_item} " + extrainfo;
						$(fieldid).focus();
					}
				}
				function show_success(message) {
					message = message == '' ? '{lang update_date_success}' : message;
					popup.open('<div class="mumucms_tip"><dd>'+ message +'</dd></div>');
					setTimeout(function() {
						popup.close();
						location.reload();
					}, '1500');
				}
				function clearErrorInfo() {
					var spanObj = $('profilelist').getElementsByTagName("div");
					for(var i in spanObj) {
						if(typeof spanObj[i].id != "undefined" && spanObj[i].id.indexOf("_")) {
							var ids = explode('_', spanObj[i].id);
							if(ids[0] == "showerror") {
								spanObj[i].innerHTML = '';
								$('th_'+ids[1]).className = '';
							}
						}
					}
				}
			</script>

		<!--{/if}-->
		</div>
	</div>
	<!--{/if}-->
</div>

<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<script type="text/javascript">
mumucms('.mumucms_type').scrollX(4, '.types');
</script>
<!--{eval $mumucms_scrollmenu = true;}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

