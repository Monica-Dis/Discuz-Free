<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $_G['home_tpl_titles'] = array('{lang pm}');}-->
<!--{template common/header}-->
<!--{if in_array($filter, array('privatepm')) || in_array($_GET[subop], array('view'))}-->

	<!--{if in_array($filter, array('privatepm'))}-->

	<!-- header start -->
	<header class="mumucms_wapheader">
	    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
	    <h1>�ҵ�{lang pm_center}</h1>
	    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
	</header>	
	<!-- header end -->
	<!-- main pmlist start -->
	<div class="mumucms_wrap mumucms_mypmlist">	
		<div class="mumucms_pmbox">
			<ul>
			<form id="deletepmform" action="home.php?mod=spacecp&ac=pm&op=delete&folder=$folder" method="post" autocomplete="off" name="deletepmform">	
				<!--{loop $list $key $value}-->
				<li id="list_$value[touid]">
				<a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}">
				<div class="avatar">
					<div class="img">
						<img src="<!--{if $value[pmtype] == 2}-->{STATICURL}image/common/grouppm.png<!--{else}--><!--{avatar($value[touid] ? $value[touid] : ($value[lastauthorid] ? $value[lastauthorid] : $value[authorid]), middle, true)}--><!--{/if}-->" />
					</div>
					<div class="name">
						<h2>
							<!--{if $value['pmtype'] == 1}-->
								<input type="checkbox" name="deletepm_deluid[]" id="a_delete_$value[plid]" class="pc" value="$value[touid]" />
							<!--{elseif $value['pmtype'] == 2}-->
								<!--{if $value['authorid'] == $_G['uid']}-->
								<input type="checkbox" name="deletepm_delplid[]" id="a_delete_$value[plid]" class="pc" value="$value[plid]" />
								<!--{else}-->
								<input type="checkbox" name="deletepm_quitplid[]" id="a_delete_$value[plid]" class="pc" value="$value[plid]" />
								<!--{/if}-->
							<!--{/if}-->
							<!--{if $value[touid]}-->
								<!--{if $value[msgfromid] == $_G[uid]}-->
									{lang me}{lang you_to} {$value[tousername]}{lang say}:
								<!--{else}-->
									{$value[tousername]} {lang you_to}{lang me}{lang say}:
								<!--{/if}-->
							<!--{elseif $value['pmtype'] == 2}-->
								{lang chatpm_author}:$value['firstauthor']
							<!--{/if}-->
						</h2>	
						<p class="time">
							<!--{date($value[dateline], 'u')}-->
							<span class="mumucms_a_color mumucms_fr">��$value[pmnum]��</span>
						</p>					
					</div>
				</div>
				<div class="message">
					<!--{if $value['pmtype'] == 2}-->[{lang chatpm}]<!--{if $value[subject]}-->$value[subject]<br><!--{/if}--><!--{/if}--><!--{if $value['pmtype'] == 2 && $value['lastauthor']}--><div style="padding:0 0 0 20px;">......<br>$value['lastauthor'] : $value[message]</div><!--{else}-->$value[message]<!--{/if}-->
				</div>
				</a>
				</li>
				<!--{/loop}-->
				<input type="hidden" name='deletesubmit' value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="mumucms_home_foot">
					<input type="button" value="ȫѡ" class="mumucms_bgcolor w50 w33" onclick="setChecked(true)">
					<input type="button" value="ȡ��" class="two w50 w33" onclick="setChecked(false)">
					<button type="submit" name="deletepmsubmit_btn" value="true" class="formdialog three w50 w33"><strong>{lang delete}</strong></button>

				</div>	
				<script type="text/javascript">
					function setChecked(option){
					    var cks = document.getElementsByName("deletepm_deluid[]");
					    for(i=0;i<cks.length;i++){
					        cks[i].checked = option;
					    }
					}
				</script>				
			</form>				
			</ul>
		</div>
		<div class="mumucms_scrollmenu">
		<li><a href="home.php?mod=spacecp&ac=pm"  style="background:#FF9800;"><i class="iconfont icon-fabu"></i></a></li>
		</div>	
	</div>	
	<!--{eval $mumucms_scrollmenu = true;}-->
	<!--{eval $nofooter = true;}-->
	<!-- main pmlist end -->

	<!--{elseif in_array($_GET[subop], array('view'))}-->
	<style type="text/css">.mumucms_bg{background:#FFF;}</style>
	<!-- header start -->
	<header class="mumucms_wapheader">
	    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
	    <!--{eval $profile = DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE uid='$_GET[touid]'");;}-->
	    <h1>��$profile[username]������</h1>
	    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
	</header>	
	<!-- header end -->
	<!-- main viewmsg_box start -->
	<div class="mumucms_wrap mumucms_view mumucms_mypmview">	
		<div class="mumucms_msgbox">
			<!--{if !$list}-->
				<div class="no_tishi">{lang no_corresponding_pm}</div>
			<!--{else}-->
				<!--{loop $list $key $value}-->
					<!--{subtemplate home/space_pm_node}-->
				<!--{/loop}-->
				$multi
			<!--{/if}-->
		</div>
		<div class="mumucms_bpop_main">
			<div class="mumucms_viewfoot_zw"></div>
			<div class="mumucms_viewfoot">
				<ul class="cl">
					<!--<li><a href="javascript:;" class="mumucms_open_shaer_bpop"><i class="iconfont icon-ziyuan"></i></a></li>
					<li><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn"><i class="iconfont icon-shoucang"></i></a></li>
					<li><a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" class="favbtn"><i class="iconfont icon-zan"></i><em class="zannum" {if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>$_G[forum_thread][recommend_add]</em></a></li>-->
					<li class="post"><a href="javascript:;" class="mumucms_open_bpop"><span>{lang send_reply_fast_tip}...</span></a></li>
				</ul>
			</div>
			<div class="mumucms_shaer_bpop mumucms_shaer_bpop_hover">
				<div class="mumucms_share">
					<div class="social-share" data-initialized="false" data-mode="prepend" data-url="{$_G['siteurl']}portal.php?mod=view&aid=$article[aid]"  data-title="$article[title]">
						<a href="#" class="share-qq"><i class="iconfont icon-qq1"></i><p>QQ����</p></a>
			            <a href="#" class="share-qzone"><i class="iconfont icon-kongjian"></i><p>QQ�ռ�</p></a>
			            <a href="#" class="share-weibo"><i class="iconfont icon-weibo1"></i><p>����΢��</p></a>
			            <a href="#" class="share-douban"><i class="iconfont icon-douban"></i><p>����</p></a>
			        	<a href="#" class="share-linkedin"><i class="iconfont icon-linkedin"></i><p>linkedin</p></a>
			            <a href="#" class="share-facebook"><i class="iconfont icon-facebook"></i><p>facebook</p></a>
			            <a href="#" class="share-twitter"><i class="iconfont icon-twitter"></i><p>twitter</p></a>
			            <a class="mumucms_copylink" id="mumucms_copylink"><i class="iconfont icon-fuzhilianjie"></i><p>��������</p></a>
			        </div>
			    </div> 
				<div class="mumucms_share_qx mumucms_close_shaer_bpop">ȡ��</div>
			</div>
			<div class="mumucms_shaer_bpop_mask"></div>
			<div class="mumucms_bpop mumucms_bpop_hover">
				<header class="mumucms_wapheader">
				    <div class="mumucms_icon"></div>
				    <h1>�ظ�</h1>
				    <div class="mumucms_icon mumucms_close_bpop"><i class="iconfont icon-error"></i></div>
				</header>
				<div class="mumucms_contents">
					<div class="mumucms_fastpost">
						<form id="pmform" class="pmform" name="pmform" method="post" action="home.php?mod=spacecp&ac=pm&op=send&pmid=$pmid&daterange=$daterange&pmsubmit=yes&mobile=2" >
							<input type="hidden" name="formhash" value="{FORMHASH}" />
							<!--{if !$touid}-->
							<input type="hidden" name="plid" value="$plid" />
							<!--{else}-->
							<input type="hidden" name="touid" value="$touid" />
							<!--{/if}-->
							<div class="mumucms_post_pi">
							<div class="post_sum">
								<textarea class="mumucms_grey grey" placeholder="{lang send_reply_fast_tip}" name="message" id="replymessage" color="gray"></textarea>
							</div>
							<div class="post_bt">
								<a href="javascript:void(0)" class="mumucms_face"><i class="iconfont icon-biaoqing"></i></a>
								<!--<a href="#"><i class="iconfont icon-tupian"></i></a>-->
								<div class="post_but">
									<input type="button" name="pmsubmit" id="pmsubmit" class="formdialog button" value="{lang reply}" />
								</div>
							</div>
							</div>
				        </form>
						<script src="{$_G['style'][tpldir]}/img/face/mumucms.face.js" charset="{CHARSET}"></script>
						<div id="mumucms_face"></div>
						<script type="text/javascript">
						$(function (){
							$("a.mumucms_face").mumucmsfacebox({
								Event : "click",	//�����¼�	
								divid : "mumucms_face", //���DIV ID
								textid : "replymessage" //�ı��� ID
							});
						});
						</script>		        
			        </div>
				</div>
			</div>
			<div class="mumucms_bpop_mask"></div>
		</div>
		<script type="text/javascript">
			$('.favbtn').on('click', function() {
				var obj = $(this);
				$.ajax({
					type:'POST',
					url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
					data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
					dataType:'xml',
				})
				.success(function(s) {
					popup.open(s.lastChild.firstChild.nodeValue);
					evalscript(s.lastChild.firstChild.nodeValue);
				})
				.error(function() {
					window.location.href = obj.attr('href');
					popup.close();
				});
				return false;
			});
		</script>		
		<script type="text/javascript">
			jQuery('.mumucms_open_bpop').click(function(){
			    jQuery('.mumucms_bpop').removeClass('mumucms_bpop_hover');
				jQuery('.mumucms_bpop_mask').addClass('mumucms_bpop_block');
			});
			jQuery('.mumucms_close_bpop').click(function(){
			   jQuery('.mumucms_bpop').addClass('mumucms_bpop_hover');
			   jQuery('.mumucms_bpop_mask').removeClass('mumucms_bpop_block');	   
			});
			jQuery('.mumucms_bpop_mask').click(function(){
			   jQuery('.mumucms_bpop').addClass('mumucms_bpop_hover');
			   jQuery('.mumucms_bpop_mask').removeClass('mumucms_bpop_block');
			});
		</script>		
	
	</div>	
	<!--{eval $mumucms_scrollmenu = true;}-->
	<!--{eval $nofooter = true;}-->
	<!-- main viewmsg_box end -->

	<!--{/if}-->

<!--{else}-->
	<div class="bm_c">
		{lang user_mobile_pm_error}
	</div>
<!--{/if}-->
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<!--{template common/footer}-->

