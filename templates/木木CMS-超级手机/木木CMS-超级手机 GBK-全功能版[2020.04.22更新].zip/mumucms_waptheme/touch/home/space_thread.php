<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<!-- header start -->
<header class="mumucms_wapheader">
    <div class="mumucms_sousuo"><a href="javascript:history.back();"><i class="iconfont icon-fanhui"></i></a></div>
    <h1>{lang mythread}</h1>
    <div class="mumucms_sousuo"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-caidan"></i></a></div>
</header>
<!-- header end -->
<!-- main threadlist start -->
<div class="mumucms_wrap mumucms_mythread">
<div class="mumucms_tlist">
	<ul>
	<!--{if $list}-->
		<!--{loop $list $thread}-->
			<li>
			<!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
			<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]" target="_blank">$thread[subject]
				<p>
					<span class="mumucms_views"><i class="iconfont icon-chakan2"></i>73</span>
					<span class="mumucms_replies"><i class="iconfont icon-huifu"></i>{$thread[replies]}</span>
				</p>
			</a>
			<!--{else}-->
			<a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank" {if $thread['displayorder'] == -1}class="grey"{/if}>$thread[subject]
				<p>
					<span class="mumucms_views mumucms_fl">$thread[dateline]</span>
					<span class="mumucms_replies mumucms_fr"><i class="iconfont icon-huifu mumucms_fl"></i>{$thread[replies]}</span>					
					<span class="mumucms_views mumucms_fr"><i class="iconfont icon-chakan2 mumucms_fl"></i>{$thread[views]}</span>
				</p>
			</a>
			<!--{/if}-->
			</li>
		<!--{/loop}-->
	<!--{else}-->
		<li>{lang no_related_posts}</li>
	<!--{/if}-->
	</ul>
	$multi
</div>
</div>
<!-- main threadlist end -->
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>
<!--{template common/footer}-->

