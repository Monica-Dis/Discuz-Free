<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $value[msgfromid] != $_G['uid']}-->
<div class="friend_msg list_msg cl">
	<div class="avat mumucms_fl"><img src="<!--{avatar($value[msgfromid], middle, true)}-->" /></div>
	<div class="dialog_green z">
		<div class="dialog_c">
			<div class="dialog_t">$value[message]</div>
			<i class="jt"></i>
		</div>
		<div class="dialog_b"></div>
		<div class="date">
			<span class="mumucms_fl"><!--{date($value[dateline], 'u')}--></span>
			<!--{if $value['pmtype'] == 1}-->
			<a href="home.php?mod=spacecp&ac=pm&op=delete&deletepm_pmid[]=$value[pmid]&touid=$touid&deletesubmit=1&handlekey=pmdeletehk_{$value[pmid]}&formhash={FORMHASH}" class="fdialog mumucms_fr" title="{lang delete}"><i class="iconfont icon-error"></i></a>
			<!--{/if}-->			
		</div>
	</div>
</div>
<!--{else}-->
<div class="self_msg list_msg cl">
	<div class="avat mumucms_fr"><img src="<!--{avatar($value[msgfromid], middle, true)}-->" /></div>
	<div class="dialog_white y">			
		<div class="dialog_c mumucms_bgcolor">
			<div class="dialog_t">$value[message]</div>
			<i class="jt mumucms_border_color"></i>
		</div>
		<div class="dialog_b"></div>
		<div class="date">
			<span class="mumucms_fr"><!--{date($value[dateline], 'u')}--></span>
			<!--{if $value['pmtype'] == 1}-->
			<a href="home.php?mod=spacecp&ac=pm&op=delete&deletepm_pmid[]=$value[pmid]&touid=$touid&deletesubmit=1&handlekey=pmdeletehk_{$value[pmid]}&formhash={FORMHASH}" class="dialog mumucms_fl" title="{lang delete}"><i class="iconfont icon-error"></i></a>
			<!--{/if}-->
		</div>
	</div>
</div>
<!--{/if}-->

