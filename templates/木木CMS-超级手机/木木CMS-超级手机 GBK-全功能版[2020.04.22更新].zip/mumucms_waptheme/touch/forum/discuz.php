<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $mumucms_wapcontrol_index = $_G['cache']['plugin']['mumucms_wapcontrol']['mumucms_wapcontrol_index'];}-->
<!--{if $mumucms_wapcontrol_index == 1}-->
	<!--{if $_GET['forumlist'] != 1}-->
		<!--{eval dheader('Location:portal.php?mod=index');}-->
	<!--{/if}-->
<!--{elseif $mumucms_wapcontrol_index == 0}-->
	<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
		<!--{eval dheader('Location:forum.php?mod=guide&view=newthread');exit;}-->
	<!--{/if}-->
<!--{/if}-->

<!--{template common/header}-->

<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<!--{if $_GET['visitclient']}-->
<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->

<!-- header start -->
<!--{if $showvisitclient}-->

<div class="visitclienttip vm" style="display:block;">
	<a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>	
	<p>
		{lang downloadzslttoshareview}
	</p>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
		$('.visitclienttip').css('display', 'block');
	}
</script>

<!--{/if}-->
<!--{hook/index_top_mobile}-->
<!-- main forumlist start -->
<div class="wp" id="wp">
<header class="mumucms_wapheader">
    <div class="mumucms_menu"><a href="javascript:;" onclick="mumucms.showSlideMenu();"><i class="iconfont icon-youcecaidan"></i><!--{avatar($space[uid],middle)}--></a></div>
    <h1>$_G[setting][bbname]</h1>
    <div class="mumucms_sousuo"><a href="search.php?mod=forum&amp;mobile=2"><i class="iconfont icon-sousuo"></i></a></div>
</header>
<div class="mumucms_wrap mumucms_forum">
	<div class="mumucms_sub">
        <div class="tab_hd">
        	<!--{if $_G['uid']}-->
        	<li class="active"><a href="javascript:void(0)">�ҵĹ�ע</a></li>
        	<!--{/if}-->
			<li{if !$_G['uid']} class="active"{/if}><a href="javascript:void(0)">ȫ�����</a></li>
           	<!--{loop $catlist $key $cat}-->
                <li><a href="javascript:void(0)">$cat[name]</a></li>
           	<!--{/loop}-->
        </div>
        <div class="tab_bd">	
        	<!--{if $_G['uid']}-->
        	<div class="forumlist" style="display: block;">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
        		<!--{if empty($gid) && !empty($forum_favlist)}-->
	        		<!--{eval $mumucms_favorite = DB::fetch_all("SELECT * FROM ".DB::table('home_favorite'));}-->
	        		<!--{loop $mumucms_favorite $favorite1}-->    		
						<!--{eval $favorderid = 0;}-->
							<!--{loop $forum_favlist $key $favorite}-->
							<!--{eval $forum=$favforumlist[$favorite[id]];}-->
							<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
							<!--{if $favorite1[id] == $forum[fid]}-->
							<li class="list cl">		
									<div class="icon">
										<!--{if $forum[icon]}-->
											$forum[icon]
										<!--{else}-->
										<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
											<img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" />
										</a>
										<!--{/if}-->
									</div>
									<div class="name">
										<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
										<span class="tit">{$forum[name]}</span>
										<!--{if empty($forum[redirect])}--><dd><em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em><em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em></dd><!--{/if}-->
										</a>
										<a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favorite1[favid]" class="favorite favorite_del dialog">ȡ��</a>
									</div>
							</li>
							<!--{/if}-->
							<!--{/loop}-->	
					<!--{/loop}-->
				<!--{else}-->
					<div class="mumucms_zanwu">
						<i class="iconfont icon-zanwu"></i>
						<p>���޹�ע,�Ͻ�ȥ��ע�ɣ�</p>
					</div>
				<!--{/if}-->
			 </div>
			 <!--{/if}-->
			<div class="forumlist" {if !$_G['uid']}style="display:block;"{else}style="display:none;"{/if}>
				<!--{loop $catlist $key $cat}-->
				<!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->
				<li class="list cl">		
						<div class="icon">
							<!--{if $forum[icon]}-->
								$forum[icon]
							<!--{else}-->
							<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
								<img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" />
							</a>
							<!--{/if}-->
						</div>
						<div class="name">
							<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
							<span class="tit">{$forum[name]}</span>
							<!--{if empty($forum[redirect])}--><dd><em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em><em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em></dd><!--{/if}-->
							</a>
							<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$forum[fid]&handlekey=favoriteforum&formhash={FORMHASH}" class="favorite dialog">+��ע</a>
						</div>
				</li>
				<!--{/loop}-->
				<!--{/loop}-->
			 </div>
        	<!--{loop $catlist $key $cat}-->
            <div class="forumlist" style="display:none;">
	                <!--{loop $cat[forums] $forumid}-->
					<!--{eval $forum=$forumlist[$forumid];}-->
					<li class="list cl">		
							<div class="icon">
								<!--{if $forum[icon]}-->
									$forum[icon]
								<!--{else}-->
								<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
									<img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" />
								</a>
								<!--{/if}-->
							</div>
							<div class="name">
								<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
								<span class="tit">{$forum[name]}</span>
								<!--{if empty($forum[redirect])}--><dd><em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em><em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em></dd><!--{/if}-->
								</a>
								<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$forum[fid]&handlekey=favoriteforum&formhash={FORMHASH}" class="favorite dialog">+��ע</a>
							</div>
					</li>
					<!--{/loop}-->
            </div>             
            <!--{/loop}-->
        </div>
	</div>
</div>
<script type="text/javascript">
        jQuery(function(){
                function tabs(tabTit,on,tabCon){
                        jQuery(tabTit).children().hover(function(){
                                jQuery(this).addClass(on).siblings().removeClass(on);
                                var index = jQuery(tabTit).children().index(this);
                                jQuery(tabCon).children().eq(index).show().siblings().hide();
                        });
                };
        tabs(".tab_hd","active",".tab_bd");
        });
</script>
<!--{if !$_G['uid']}-->
<script type="text/javascript">
$('.dialog').on('click', function() {
popup.open('����δ��¼��������¼?', 'confirm', 'member.php?mod=logging&action=login');
return false;
});
</script>
<!--{/if}-->
</div>
<!-- main forumlist end -->
<!--{hook/index_middle_mobile}-->
<!--{/if}-->
<script type="text/javascript" src="{$_G['style'][tpldir]}/common/js/common.js"></script>

<!--{template common/footer}-->

