<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $agent = $_SERVER['HTTP_USER_AGENT']}--> 
<!--{if strpos($agent,"Html5Plus") === false }-->
<style type="text/css">
.mumucms_appdown{background:#FFF;text-align:center;padding:10px;}
.mumucms_appdown a{background-image: linear-gradient(to right,#FF5722,#FF9800);width:100%;height:46px;line-height:46px;display:inline-block;font-size:16px;color:#FFF;border-radius:5px;}	
.mumucms_appdown a i{font-size:22px;margin-right:10px;}
</style>
<div class="mumucms_appdown html5plus">
	<!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone') || strpos($_SERVER['HTTP_USER_AGENT'], 'iPad')}-->
		<!--{if $_G['cache']['mumucms_app']['app_downkz'] == 1}-->
			<a href="{$_G['cache']['mumucms_app']['app_ios']}">{$_G['cache']['mumucms_app']['app_downtext']}</a>
		<!--{else}-->
			<a href="plugin.php?id=mumucms_wapcontrol:mumucms_wapcontrol_app">{$_G['cache']['mumucms_app']['app_downtext']}</a>	
		<!--{/if}-->	
	<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'Android')}-->
		<!--{if $_G['cache']['mumucms_app']['app_downkz'] == 1}-->
			<a href="{$_G['cache']['mumucms_app']['app_android']}">{$_G['cache']['mumucms_app']['app_downtext']}</a>
		<!--{else}-->
			<a href="plugin.php?id=mumucms_wapcontrol:mumucms_wapcontrol_app">{$_G['cache']['mumucms_app']['app_downtext']}</a>	
		<!--{/if}-->			
	<!--{else}-->
	<a href="javascript:;">APP��ʱ֧�ְ�׿��ƻ��ϵͳ</a>
	<!--{/if}-->
</div>
<!--{/if}-->




