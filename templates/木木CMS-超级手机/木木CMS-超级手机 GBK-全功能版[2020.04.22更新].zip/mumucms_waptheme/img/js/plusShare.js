(function() {
	var plusReady = function(callback) {
		if(window.plus) {
			callback();
		} else {
			document.addEventListener('plusready', callback);
		}
	}
	var shareServices = {};
	var init = function() {
		plus.share.getServices(function(services) {
			for(var i = 0, len = services.length; i < len; i++) {
				shareServices[services[i].id] = services[i];
			}
		});
	};
	var isWechatInstalled = function() {
		return plus.runtime.isApplicationExist && plus.runtime.isApplicationExist({
			pname: 'com.tencent.mm',
			action: 'weixin://'
		});
	};

	function share(id, msg, callback) {
		var service = shareServices[id];
		if(!service) {
			callback && callback(false);
			return;
		}
		var _share = function() {
			service.send(msg, function() {
				plus.nativeUI.toast("������\"" + service.description + "\"�ɹ���");
				callback && callback(true);
			}, function(e) {
				plus.nativeUI.toast("������\"" + service.description + "\"ʧ�ܣ�");
				callback && callback(false);
			})
		};
		if(service.authenticated) {
			_share(service, msg, callback);
		} else {
			service.authorize(function() {
				_share(service, msg, callback);
			}, function(e) {
				console.log("��֤��Ȩʧ��");
				callback && callback(false);
			})
		}
	};

	function openSystem(msg, callback) {
		if(plus.share.sendWithSystem) {
			plus.share.sendWithSystem(msg, function() {
				//TODO ϵͳ�����ݲ�֧�ֻص�
				//callback && callback(true);
			}, function() {
				//TODO ϵͳ�����ݲ�֧�ֻص�
				//callback && callback(false);
			});
		} else {
			callback && callback(false);
		}
	}
	var open = function(msg, callback) {
		/**
		 *�������ֱ�Ӵ�ϵͳ����
		 * 1��δ����΢�ŷ���ͨ��
		 * 2���û��ֻ�δ��װ��в��
		 * 3��360�������
		 */

		if(shareServices.weixin && isWechatInstalled() && !/360\sAphone/.test(navigator.userAgent)) {
			plus.nativeUI.actionSheet({
				title: '������',
				cancel: "ȡ��",
				buttons: [{
					title: "΢����Ϣ"
				}, {
					title: "΢������Ȧ"
				}, {
					title: "�������"
				}]
			}, function(e) {
				var index = e.index;
				switch(index) {
					case 1: //������΢�ź���
						msg.extra = {
							scene: 'WXSceneSession'
						};
						share('weixin', msg, callback);
						break;
					case 2: //������΢������Ȧ
						msg.title = msg.content;
						msg.extra = {
							scene: 'WXSceneTimeline'
						};
						share('weixin', msg, callback);
						break;
					case 3: //�������
						var url = msg.href ? ('( ' + msg.href + ' )') : '';
						msg.title = msg.title + url;
						msg.content = msg.content + url;
						openSystem(msg, callback);
						break;
				}
			})
		} else {
			//ϵͳ����
			var url = msg.href ? ('( ' + msg.href + ' )') : '';
			msg.title = msg.title + url;
			msg.content = msg.content + url;
			openSystem(msg, callback);
		}
	};
	plusReady(init);
	window.plusShare = open;
})();
