;(function($){
    var defaults = {
        copyUrl:"",//�Զ��帴�����ӵ�ַ
        tipTime:2000,//������ʾ��ʧʱ��
        copyId:""//���ư�ťid
    };
    $.extend({
        copy:function(option){
            var options = $.extend({},defaults,option);
            var URL = options.copyUrl == "" ? window.location.href.split('#')[0] : options.copyUrl;
            var cId = options.copyId == "" ? '#copy' : options.copyId;
            var u = navigator.userAgent; 
            var isAndroid = u.indexOf('Android') > -1 || u.indexOf('Adr') > -1; //android�ն� 
            var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios�ն� 
            var aEle = document.querySelectorAll(cId);
            if(isAndroid || (!isAndroid && !isiOS)){
                $(aEle).each(function(){
                    var index = $(this).attr("id").split("y")[1];
                    $('body').append('<textarea id="selector'+index+'" style="position:absolute;top:-9999px;left:-9999px;" readonly>'+URL+'</textarea>');
                    $(this)[0].onclick=function(event){
                        $("#selector"+index).select();
                        document.execCommand("copy",false,null);
                        $("body").append(tipsHtml);
                        setTimeout(function(){
                            $("#share-tips").remove();
                        },options.tipTime);
                    };
                });        
            }
            if(isiOS){
                $(aEle).each(function(){
                    var index = $(this).attr("id").split("y")[1];
                    $('body').append('<a id="selector'+index+'" style="position:absolute;top:-9999px;left:-9999px;">'+URL+'</a>');
                    this.addEventListener('click',function(){
                        var copyDOM = document.querySelectorAll('#selector'+index);
                        var range = document.createRange();  
                        range.selectNode(copyDOM[0]);
                        window.getSelection().removeAllRanges();
                        window.getSelection().addRange(range);
                        document.execCommand('copy');
                        $("body").append(tipsHtml);
                        setTimeout(function(){
                            $("#share-tips").remove();
                        },options.tipTime);   
                    },false);
                    
                });
                
            }
        }
    });
})(jQuery);
