<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


/* 帖子列表页 每个帖子的缩略图 */
$table = 'forum_attachment_'.substr($thread['tid'], -1);
$pic_queue = DB::fetch_all("SELECT aid,tid FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!=0 ORDER BY `dateline` ASC"); 
$pic_num = count($pic_queue);
//$pic_list = getforumimg($pic[aid],0,145,90);

?>