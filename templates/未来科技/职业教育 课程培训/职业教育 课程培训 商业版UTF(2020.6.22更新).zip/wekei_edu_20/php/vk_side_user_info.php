<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


/* 帖子内容页 右侧头像模块信息 */
$theuid = $_G[forum_thread][authorid];
$author_info_1 = DB::fetch_first("SELECT `follower`,`threads`,`following` FROM ".DB::table('common_member_count')." WHERE uid=$theuid");
$author_info_2 = DB::fetch_first("SELECT `resideprovince`,`occupation` FROM ".DB::table('common_member_profile')." WHERE uid=$theuid");
$thegroupid = DB::result_first("SELECT `groupid` FROM ".DB::table('common_member')." WHERE uid=$theuid");

?>