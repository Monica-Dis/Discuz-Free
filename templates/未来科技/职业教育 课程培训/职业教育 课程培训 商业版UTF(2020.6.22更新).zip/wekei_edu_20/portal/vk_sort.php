<?php exit;?>
<!-- 分类 -->

<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.hoverdir.js"></script>
<script type="text/javascript">
	jq(function() {
		jq('#da-thumbs > li').hoverdir( {
			hoverDelay	: 75
		} );
	
	});
</script>
<script type="text/javascript"> var jq=jQuery.noConflict(); </script>


<!--    
<div class="vk_sort_slide">
</div>
-->    

<!--[diy=vk_sort_wp]--><div id="vk_sort_wp" class="area"></div><!--[/diy]-->

<div class="vk_sort_div">

    <div class="vk_sort_content">

        <div class="vk_sort">
            <ul>
                <li class="vk_sort_li_1 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">IT · 互联网</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">前端开发</a><a href="http://t.cn/Aiux1eta" target="_blank">Java</a><a href="http://t.cn/Aiux1eta" target="_blank">产品策划</a></div>
                </li>
                <li class="vk_sort_li_2 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">设计 · 创作</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">平面设计</a><a href="http://t.cn/Aiux1eta" target="_blank">UI设计</a><a href="http://t.cn/Aiux1eta" target="_blank">室内设计</a></div>
                </li>
                <li class="vk_sort_li_3 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">电商 · 营销</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">电商平台</a><a href="http://t.cn/Aiux1eta" target="_blank">跨境电商</a><a href="http://t.cn/Aiux1eta" target="_blank">社交电商</a></div>
                </li>
                <li class="vk_sort_li_4 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">职业 · 考证 · Office</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">公务员</a><a href="http://t.cn/Aiux1eta" target="_blank">教师考试</a><a href="http://t.cn/Aiux1eta" target="_blank">网络认证</a></div>
                </li>
                <li class="vk_sort_li_5 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">升学 · 考研 · 语言 · 留学</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">考研</a><a href="http://t.cn/Aiux1eta" target="_blank">大学</a><a href="http://t.cn/Aiux1eta" target="_blank">高中</a><a href="http://t.cn/Aiux1eta" target="_blank">初中</a></div>
                </li>
            </ul>
        </div>

        <div class="vk_sort_sub">
            <ul>
                <li class="vk_sort_sub_li_1 ">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">互联网产品</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">产品策划</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">产品运营</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">游戏策划</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">游戏运营</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">媒体营销</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">网络营销</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">建站</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">SEO</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">编程语言</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">C</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">C++</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">JAVA</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">PHP</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">C#/NET</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Object-C</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">SQL</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Python</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Html</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Html5</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">CSS</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Javascript</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Ruby</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Perl</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Lua</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Flash</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Swift</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">VB.NET</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">前端/移动/游戏开发</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">基础就业课</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">实战进阶课</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">技术专题课</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Android开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">iOS开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">微信开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">APP开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Unity3D游戏开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Cocos2d-x游戏开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Html5游戏</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">VR/AR</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">OpenGL开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">egret游戏开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">游戏服务器开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">软件开发</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">敏捷开发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">软件测试</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">软件研发</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">硬件开发</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">嵌入式设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">IC设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">单片机</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">云计算/大数据</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">云计算</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">大数据</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">人工智能</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">物联网</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">区块链</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">网络/运维</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">Linux运维</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Python自动化运维</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">DevOps</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">信息安全</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">认证考试</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">思科认证</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">红帽认证</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">微软认证</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">软考</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="vk_sort_sub_li_2">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div"> 
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">平面设计</a></h3>
                            <div class="vk_sort_sub_li_a">          
                                <a href="http://t.cn/Aiux1eta" target="_blank">电商美工</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">综合平面设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">摄影后期</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div"> 
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">设计软件</a></h3>
                            <div class="vk_sort_sub_li_a">          
                                <a href="http://t.cn/Aiux1eta" target="_blank">Photoshop</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Dreamweaver</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Illustrator</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">CAD</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">CDR</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">3DMAX</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">InDesign</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Axure</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Fireworks</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">UG</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">SolidWorks</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Sketchup</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Flash</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Rhino3D</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">AE</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">MAYA</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">VRay</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Premiere</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Pro/E</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">环境艺术设计</a></h3>
                            <div class="vk_sort_sub_li_a">       
                                <a href="http://t.cn/Aiux1eta" target="_blank">室内设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">建筑设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">景观设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">绘画创作</a></h3>
                            <div class="vk_sort_sub_li_a">       
                                <a href="http://t.cn/Aiux1eta" target="_blank">插画/漫画</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">国画/油画</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">水彩水粉画</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">素描</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">手绘</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">工业产品设计</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">产品设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">模具设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">机械设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">包装设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">UI设计</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">交互设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">游戏UI设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Web UI设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">App UI设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">游戏动画设计</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">游戏角色设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">场景概念设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">游戏模型设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">特效设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">动画设计</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">游戏美宣</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">影视后期设计</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">包装/剪辑</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">特效/后期</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">服装设计</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">服装设计打版</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="vk_sort_sub_li_3">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">电商平台</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">淘宝营销</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">京东营销</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">拼多多营销</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">跨境电商</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">亚马逊</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">速卖通</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">阿里国际站</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">独立站</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">社交电商</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">抖音电商</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">微信电商</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">社群营销</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="vk_sort_sub_li_4">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">Office</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">PPT</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Word</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Excel</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">求职简历</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">面试指导</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">职场礼仪</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">公考求职</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">公务员</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">事业单位</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">教师考试</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">金融银行</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">企业招聘</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他招考</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">法学院</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">法律硕士</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">法律职业资格</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">法律实务</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">警法考试</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">趣味学法</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">财会金融</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">会计职称</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">注册会计师</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">国际证书</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">金融类从业</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">会计实务操作</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他财经类考试</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">医疗卫生</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">执业药师</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">执业医师</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">执业护士</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">中医技能</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">卫生资格</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">妇幼课堂</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">医学升学</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他医疗培训</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">建筑工程</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">一级建造师</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">二级建造师</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">消防工程师</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">工程造价/实操</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">工程施工/技能</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">注册工程师</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他建工类培训</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">职业技能</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">人力资源</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">办公软件</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">计算机等级考试</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">技工技能</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">心理咨询</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">企业培训</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">创业教育</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="vk_sort_sub_li_5">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">实用英语</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">英语口语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">学术英语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">新概念英语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">青少年英语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">词汇</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">语法</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">职场英语</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">出国留学</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">托福</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">雅思</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">研究生留学</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">留学指导</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">K12留学</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">英语四六级</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">四级</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">六级</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">专业英语</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">日语</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">日语零基础</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">日语初级</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">日语中高级</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">兴趣日语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">日语考试</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">日本留学</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">小语种</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">韩语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">法语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">俄语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">德语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">西班牙语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">方言</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>

                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">考研</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">规划指导</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">考研英语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">考研政治</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">考研数学</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">专业课</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">大学</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">自考</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">专升本</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">高中</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">高考备战</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">高二</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">高一</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">初中</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">中考备战</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">初二</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">初一</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">小学</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">语文</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">数学</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">英语</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">其他</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">小升初备战</a>
                            </div>
                        </div>

                    </div>
                </li>
            </ul>
        </div>
            <script type="text/javascript">
                jq(".vk_sort li").each(function(s){
                    jq(this).hover(
                        function(){
                            jq(this).addClass("on");
                            jq(".vk_sort_sub ul li").eq(s).show();
                        },
                        function(){
                            jq(this).removeClass("on");
                            jq(".vk_sort_sub ul li").eq(s).hide();
                            })
                    })
                jq(".vk_sort_sub ul li").each(function(s){
                    jq(this).hover(
                    function(){
                        jq(this).show();
                        jq(".vk_sort li").eq(s).addClass("on");
                    },
                    function(){
                        jq(this).hide();
                        jq(".vk_sort li").eq(s).removeClass("on");
                        })
                    })
            </script>
        
        
    </div>
</div>


