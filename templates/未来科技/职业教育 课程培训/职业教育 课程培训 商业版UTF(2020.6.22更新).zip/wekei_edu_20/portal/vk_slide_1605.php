<?php exit; ?>
<!--
Slide Module
原Num: vk_slide_1605
Num: vk_slide_sim

模板文件夹： ./template/当前模板目录/vk_slide/vk_slide_1605.php
图片/CSS/JS 文件夹：./template/当前模板目录/图片目录(一般为images)/vk_slide_1605/


未来科技
www.wekei.cn
Author: Veiki

Created Time: 20160501
Change Time: 20160501
Change Time: 20190801

更改日志：由高度580px 改为了 400px

-->



<!--上部1920 x 400px 自适应 幻灯 start-->
<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/vk_slide_1605/vk_slide.css">
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/vk_slide_1605/jquery.js"></script> 
<script type="text/javascript" src="{$_G['style']['styleimgdir']}/vk_slide_1605/vk_slide.js"></script> 
<!--[if lte IE 6]>
<script type="text/javascript" src="js/vk_slide_png.js"></script>
<script type="text/javascript">
    var __IE6=true;
    DD_belatedPNG.fix('.logo img,.prev img,.next img,img');
</script>
<![endif]-->


 
<div id="vk_slide">

<div class="slide-main" id="touchMain">
	<a class="prev" href="javascript:;" stat="prev1001"><img src="{$_G['style']['styleimgdir']}/vk_slide_1605/l-btn.png" /></a>
	<div class="slide-box" id="slideContent">
		<div class="slide" id="bgstylea">
			<a stat="sslink-1" href="http://t.cn/Aiux1eta" target="_blank">
<!--
				<div class="obj-a"><img src="{$_G['style']['styleimgdir']}/vk_slide_1605/vk_slide_pic_1.png" /></div>
				<div class="obj-b"><img src="{$_G['style']['styleimgdir']}/vk_slide_1605/vk_slide_pic_2.png" /></div>
-->
			</a>
		</div>
		<div class="slide" id="bgstyleb">
			<a stat="sslink-2" href="http://t.cn/Aiux1eta" target="_blank">
<!--            
				<div class="obj-c"><img src="{$_G['style']['styleimgdir']}/vk_slide_1605/vk_slide_pic_3.png" /></div>
				<div class="obj-d"><img src="{$_G['style']['styleimgdir']}/vk_slide_1605/vk_slide_pic_4.png" /></div>
-->                
			</a>
		</div>
		<div class="slide" id="bgstylec">
			<a stat="sslink-3" href="http://t.cn/Aiux1eta" target="_blank">
<!--            
				<div class="obj-e"><img src="{$_G['style']['styleimgdir']}/vk_slide_1605/vk_slide_pic_5.png" /></div>
				<div class="obj-f"><img src="{$_G['style']['styleimgdir']}/vk_slide_1605/vk_slide_pic_6.png" /><p> </p></div>
-->                
			</a>
		</div>
        
<!--
-->
	</div>
	<a class="next" href="javascript:;" stat="next1002"><img src="{$_G['style']['styleimgdir']}/vk_slide_1605/r-btn.png" /></a>
	<div class="item">
		<a class="cur" stat="item1001" href="javascript:;"></a>
        <a href="javascript:;" stat="item1002"></a>
        <a href="javascript:;" stat="item1003"></a>
<!--
-->
	</div>
</div>


</div>

<script type="text/javascript"> jQuery.noConflict(); </script>


<!--上部1920 x 400px 幻灯 end-->

