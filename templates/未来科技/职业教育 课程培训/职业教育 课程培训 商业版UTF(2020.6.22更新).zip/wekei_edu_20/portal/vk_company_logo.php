<?php exit;?>
<!-- 各个公司的Logo -->




<div class="wp vk_company_logo">

    <div class="module-body">
        <div class="home-slide-wrap" style="margin-left: 0px;">
            <ul class="webtest-list clearfix">
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_7">阿里巴巴</div>
                        <div class="webtest-title">阿里巴巴</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_2">腾讯</div>
                        <div class="webtest-title">腾讯</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_1">百度</div>
                        <div class="webtest-title">百度</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_9">google</div>
                        <div class="webtest-title">google</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_8">小米</div>
                        <div class="webtest-title">小米</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_4">微软</div>
                        <div class="webtest-title">微软</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_28">人人网</div>
                        <div class="webtest-title">人人网</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_40">迅雷</div>
                        <div class="webtest-title">迅雷</div>
                    </a>
                </li>

                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_6">美团点评</div>
                        <div class="webtest-title">美团点评</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_15">网易</div>
                        <div class="webtest-title">网易</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_3">360公司</div>
                        <div class="webtest-title">360公司</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_37">京东</div>
                        <div class="webtest-title">京东</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_32">大众点评</div>
                        <div class="webtest-title">大众点评</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_21">搜狐</div>
                        <div class="webtest-title">搜狐</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_29">去哪儿</div>
                        <div class="webtest-title">去哪儿</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_25">爱奇艺</div>
                        <div class="webtest-title">爱奇艺</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_26">优酷</div>
                        <div class="webtest-title">优酷</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_31">天猫</div>
                        <div class="webtest-title">天猫</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_35">新浪</div>
                        <div class="webtest-title">新浪</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_39">支付宝</div>
                        <div class="webtest-title">支付宝</div>
                    </a>
                </li>

            </ul>
        </div>
    </div>

</div>