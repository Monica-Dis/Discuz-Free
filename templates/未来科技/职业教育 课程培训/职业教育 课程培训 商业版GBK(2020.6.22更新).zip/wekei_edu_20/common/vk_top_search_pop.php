<?php exit; ?>

<div id="vk_top_search_menu">

	<div class="vk_top_search_form cl">
		<!--{if $_G['setting']['search']}-->
			<form id="scform" method="post" autocomplete="off" action="$_G[siteurl]search.php?searchsubmit=yes" target="_blank">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="mod" value="forum" />
				<input type="text" name="srchtxt" id="srchtxt" class="z" autocomplete="off" onblur="if (value ==''){value='{lang enter_content}'}" onfocus="if (value =='{lang enter_content}'){value =''}" value="{lang enter_content}" />
				<button id="search_submit" name="searchsubmit" type="submit" value="true">{lang search}</button>
			</form>
		<!--{/if}-->				
	</div>

	<div id="scbar_hot" class="cl">
		<!--{if $_G['setting']['srchhotkeywords']}-->
			<strong class="z">{lang hot_search}: </strong>
			<!--{loop $_G['setting']['srchhotkeywords'] $val}-->
				<!--{if $val=trim($val)}-->
					<!--{eval $valenc=rawurlencode($val);}-->
					<!--{block srchhotkeywords[]}-->
						<!--{if !empty($searchparams[url])}-->
							<a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}" target="_blank" sc="1">$val</a>
						<!--{else}-->
							<a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch" target="_blank" sc="1">$val</a>
						<!--{/if}-->
					<!--{/block}-->
				<!--{/if}-->
			<!--{/loop}-->
			<!--{echo implode('', $srchhotkeywords);}-->
		<!--{/if}-->
	</div>

</div>



<script type="text/javascript">
	initSearchmenu('scbar', '$searchparams[url]');
</script> 





