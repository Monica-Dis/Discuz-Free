<?php exit;?>
<!-- ���� -->

<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.hoverdir.js"></script>
<script type="text/javascript">
	jq(function() {
		jq('#da-thumbs > li').hoverdir( {
			hoverDelay	: 75
		} );
	
	});
</script>
<script type="text/javascript"> var jq=jQuery.noConflict(); </script>


<!--    
<div class="vk_sort_slide">
</div>
-->    

<!--[diy=vk_sort_wp]--><div id="vk_sort_wp" class="area"></div><!--[/diy]-->

<div class="vk_sort_div">

    <div class="vk_sort_content">

        <div class="vk_sort">
            <ul>
                <li class="vk_sort_li_1 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">IT �� ������</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">ǰ�˿���</a><a href="http://t.cn/Aiux1eta" target="_blank">Java</a><a href="http://t.cn/Aiux1eta" target="_blank">��Ʒ�߻�</a></div>
                </li>
                <li class="vk_sort_li_2 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">��� �� ����</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">ƽ�����</a><a href="http://t.cn/Aiux1eta" target="_blank">UI���</a><a href="http://t.cn/Aiux1eta" target="_blank">�������</a></div>
                </li>
                <li class="vk_sort_li_3 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">���� �� Ӫ��</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">����ƽ̨</a><a href="http://t.cn/Aiux1eta" target="_blank">�羳����</a><a href="http://t.cn/Aiux1eta" target="_blank">�罻����</a></div>
                </li>
                <li class="vk_sort_li_4 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">ְҵ �� ��֤ �� Office</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">����Ա</a><a href="http://t.cn/Aiux1eta" target="_blank">��ʦ����</a><a href="http://t.cn/Aiux1eta" target="_blank">������֤</a></div>
                </li>
                <li class="vk_sort_li_5 hvr-wobble-horizontal">
                    <a href="#" target="_blank" class="li_name">��ѧ �� ���� �� ���� �� ��ѧ</a>
                    <div class="vk_sort_li_little"><a href="http://t.cn/Aiux1eta" target="_blank">����</a><a href="http://t.cn/Aiux1eta" target="_blank">��ѧ</a><a href="http://t.cn/Aiux1eta" target="_blank">����</a><a href="http://t.cn/Aiux1eta" target="_blank">����</a></div>
                </li>
            </ul>
        </div>

        <div class="vk_sort_sub">
            <ul>
                <li class="vk_sort_sub_li_1 ">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">��������Ʒ</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ʒ�߻�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ʒ��Ӫ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ϸ�߻�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ϸ��Ӫ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ý��Ӫ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����Ӫ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��վ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">SEO</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">�������</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">C</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">C++</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">JAVA</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">PHP</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">C#/NET</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Object-C</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">SQL</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Python</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Html</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Html5</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">CSS</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Javascript</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Ruby</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Perl</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Lua</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Flash</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Swift</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">VB.NET</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">ǰ��/�ƶ�/��Ϸ����</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">������ҵ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ʵս���׿�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����ר���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Android����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">iOS����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">΢�ſ���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">APP����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Unity3D��Ϸ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Cocos2d-x��Ϸ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Html5��Ϸ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">VR/AR</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">OpenGL����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">egret��Ϸ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ϸ����������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">��������</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">���ݿ���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�����з�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">Ӳ������</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">Ƕ��ʽ���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">IC���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ƭ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">�Ƽ���/������</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">�Ƽ���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�˹�����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">����/��ά</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">Linux��ά</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Python�Զ�����ά</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">DevOps</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ϣ��ȫ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">��֤����</a></h3>
                            <div class="vk_sort_sub_li_a">    
                                <a href="http://t.cn/Aiux1eta" target="_blank">˼����֤</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ñ��֤</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">΢����֤</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="vk_sort_sub_li_2">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div"> 
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">ƽ�����</a></h3>
                            <div class="vk_sort_sub_li_a">          
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�ۺ�ƽ�����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ӱ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div"> 
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">�������</a></h3>
                            <div class="vk_sort_sub_li_a">          
                                <a href="http://t.cn/Aiux1eta" target="_blank">Photoshop</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Dreamweaver</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Illustrator</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">CAD</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">CDR</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">3DMAX</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">InDesign</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Axure</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Fireworks</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">UG</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">SolidWorks</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Sketchup</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Flash</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Rhino3D</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">AE</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">MAYA</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">VRay</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Premiere</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Pro/E</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">�����������</a></h3>
                            <div class="vk_sort_sub_li_a">       
                                <a href="http://t.cn/Aiux1eta" target="_blank">�������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">�滭����</a></h3>
                            <div class="vk_sort_sub_li_a">       
                                <a href="http://t.cn/Aiux1eta" target="_blank">�廭/����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����/�ͻ�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ˮ��ˮ�ۻ�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�ֻ�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">��ҵ��Ʒ���</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ʒ���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ģ�����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��е���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��װ���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">UI���</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">�������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ϷUI���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Web UI���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">App UI���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">��Ϸ�������</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ϸ��ɫ���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�����������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ϸģ�����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ч���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ϸ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">Ӱ�Ӻ������</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">��װ/����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ч/����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">��װ���</a></h3>
                            <div class="vk_sort_sub_li_a">      
                                <a href="http://t.cn/Aiux1eta" target="_blank">��װ��ƴ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="vk_sort_sub_li_3">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">����ƽ̨</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">�Ա�Ӫ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����Ӫ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ƴ���Ӫ��</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">�羳����</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">����ѷ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����ͨ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�������վ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����վ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">�罻����</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">΢�ŵ���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ȺӪ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="vk_sort_sub_li_4">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">Office</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">PPT</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Word</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Excel</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ְ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����ָ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ְ������</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">������ְ</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">����Ա</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ҵ��λ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ʦ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ҵ��Ƹ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�����п�</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">��ѧԺ</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">����˶ʿ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����ְҵ�ʸ�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����ʵ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Ȥζѧ��</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">�ƻ����</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">���ְ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ע����ʦ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����֤��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�������ҵ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">���ʵ�����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�����ƾ��࿼��</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">ҽ������</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">ִҵҩʦ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ִҵҽʦ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ִҵ��ʿ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ҽ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�����ʸ�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">���׿���</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ҽѧ��ѧ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����ҽ����ѵ</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">��������</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">һ������ʦ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������ʦ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������ʦ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�������/ʵ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����ʩ��/����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ע�Ṥ��ʦ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">������������ѵ</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">ְҵ����</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">������Դ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�칫����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">������ȼ�����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">������ѯ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ҵ��ѵ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ҵ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                    </div>
                </li>
                <li class="vk_sort_sub_li_5">
                    <div class="vk_sort_sub_li">
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">ʵ��Ӣ��</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">Ӣ�����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ѧ��Ӣ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�¸���Ӣ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">������Ӣ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�ʻ�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�﷨</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ְ��Ӣ��</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">������ѧ</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">�и�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��˼</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�о�����ѧ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ѧָ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">K12��ѧ</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">Ӣ��������</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">�ļ�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">רҵӢ��</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">����</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">���������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�����и߼�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��Ȥ����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">���￼��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�ձ���ѧ</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">С����</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>

                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">����</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">�滮ָ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����Ӣ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��������</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">������ѧ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">רҵ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">��ѧ</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">�Կ�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">ר����</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">����</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">�߿���ս</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">�߶�</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��һ</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">����</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">�п���ս</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��һ</a>
                            </div>
                        </div>
                        <div class="vk_sort_sub_li_div">
                            <h3><a href="http://t.cn/Aiux1eta" target="_blank">Сѧ</a></h3>
                            <div class="vk_sort_sub_li_a">         
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">��ѧ</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">Ӣ��</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">����</a>
                                <a href="http://t.cn/Aiux1eta" target="_blank">С������ս</a>
                            </div>
                        </div>

                    </div>
                </li>
            </ul>
        </div>
            <script type="text/javascript">
                jq(".vk_sort li").each(function(s){
                    jq(this).hover(
                        function(){
                            jq(this).addClass("on");
                            jq(".vk_sort_sub ul li").eq(s).show();
                        },
                        function(){
                            jq(this).removeClass("on");
                            jq(".vk_sort_sub ul li").eq(s).hide();
                            })
                    })
                jq(".vk_sort_sub ul li").each(function(s){
                    jq(this).hover(
                    function(){
                        jq(this).show();
                        jq(".vk_sort li").eq(s).addClass("on");
                    },
                    function(){
                        jq(this).hide();
                        jq(".vk_sort li").eq(s).removeClass("on");
                        })
                    })
            </script>
        
        
    </div>
</div>



