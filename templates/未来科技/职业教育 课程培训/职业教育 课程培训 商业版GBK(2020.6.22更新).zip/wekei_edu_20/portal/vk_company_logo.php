<?php exit;?>
<!-- ������˾��Logo -->




<div class="wp vk_company_logo">

    <div class="module-body">
        <div class="home-slide-wrap" style="margin-left: 0px;">
            <ul class="webtest-list clearfix">
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_7">����Ͱ�</div>
                        <div class="webtest-title">����Ͱ�</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_2">��Ѷ</div>
                        <div class="webtest-title">��Ѷ</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_1">�ٶ�</div>
                        <div class="webtest-title">�ٶ�</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_9">google</div>
                        <div class="webtest-title">google</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_8">С��</div>
                        <div class="webtest-title">С��</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_4">΢��</div>
                        <div class="webtest-title">΢��</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_28">������</div>
                        <div class="webtest-title">������</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_40">Ѹ��</div>
                        <div class="webtest-title">Ѹ��</div>
                    </a>
                </li>

                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_6">���ŵ���</div>
                        <div class="webtest-title">���ŵ���</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_15">����</div>
                        <div class="webtest-title">����</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_3">360��˾</div>
                        <div class="webtest-title">360��˾</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_37">����</div>
                        <div class="webtest-title">����</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_32">���ڵ���</div>
                        <div class="webtest-title">���ڵ���</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_21">�Ѻ�</div>
                        <div class="webtest-title">�Ѻ�</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_29">ȥ�Ķ�</div>
                        <div class="webtest-title">ȥ�Ķ�</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_25">������</div>
                        <div class="webtest-title">������</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_26">�ſ�</div>
                        <div class="webtest-title">�ſ�</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_31">��è</div>
                        <div class="webtest-title">��è</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_35">����</div>
                        <div class="webtest-title">����</div>
                    </a>
                </li>
                <li>
                    <a href="#" class="webtest-item">
                        <div class="weblogo logo_39">֧����</div>
                        <div class="webtest-title">֧����</div>
                    </a>
                </li>

            </ul>
        </div>
    </div>

</div>
