<?php exit;?>

<!--{template common/header}-->
</div>



<style id="diy_style" type="text/css"></style>






<!-- ���� -->


<div class="vk_sort_wp">

    <!-- �õ�ģ�� -->
<!-- slide start -->
<!--{subtemplate portal/vk_slide_1605}-->
<!-- slide end -->

<!--{subtemplate portal/vk_sort}-->


</div>

<script type="text/javascript">
    var jq=jQuery.noConflict();
</script>





  
<div class="wp col_4 m_b_20 wow animated bounce">
    <div class="col_4_1-1-1-1 hvr-wobble-horizontal" > <a href="#" target="_blank" class="vk_about_1" >  </a>
    </div>
    
    <div class="col_4_1-1-1-1 hvr-wobble-horizontal" > <a href="#" target="_blank" class="vk_about_2"  > </a>
    </div>
    
    <div class="col_4_1-1-1-1 hvr-wobble-horizontal" ><a href="#" target="_blank" class="vk_about_3"  >  </a>
    </div>
    
    <div class="col_4_1-1-1-1 hvr-wobble-horizontal right m_r_0" ><a href="#" target="_blank" class="vk_about_4"  >  </a>
    </div>
</div>









<!--  ���λ   -->
<div class="wp vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_001]--> <div id="diy_vk_ad_001" class="area"></div><!--[/diy]--> 
</div>




<div class="wp col_2-1 m_b_20 wow animated fadeInUp">
    <div class="vk_title_wide">
        <h2><a href="http://t.cn/Aiux1eta" target="_blank">�����Ƽ�</a></h2>
        <ul>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ƽ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > UI��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��·Ӫ�� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��Ϸ���� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > App��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > Office </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ǰ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ������֤ </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��ҵָ�� </a></li>
        </ul>
    </div>
    <!--�õ�Ƭģ��--> 
    <div class="col_2-1_l vk_diy">
      <!--[diy=diy_vk_slide_500]-->  <div id="diy_vk_slide_500" class="area"> </div>  <!--[/diy]-->
    </div>

    <!-- �ϲ��Ҳ�ģ�� start-->
    <div class="col_2-1_r  col_vk_title vk_wechat_wp ">
    	<div id="vk_wechat" class="vk_wechat"></div>
    	<div id="vk_phone_icon" class="vk_phone_icon"></div>
    	<div class="vk_side_icon_4 "  >
        	<a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="vk_side_icon_4_1 left hvr-wobble-vertical" > Ͷ�� </a>
        	<a href="#" class="vk_side_icon_4_2 left hvr-wobble-vertical" 
            onmouseover="document.getElementById('vk_phone_icon').style.display='block';"
            onmouseout="document.getElementById('vk_phone_icon').style.display='none'"
            > �ֻ��� </a>
        	<a href="#" class="vk_side_icon_4_3 left hvr-wobble-vertical" > ����΢�� </a>
        	<a href="#" class="vk_side_icon_4_4 right m_r_0 hvr-wobble-vertical"  
            onmouseover="document.getElementById('vk_wechat').style.display='block';"
            onmouseout="document.getElementById('vk_wechat').style.display='none'"
             > ����ƽ̨ </a>
        </div>
		
    	<div class="vk_index_top_post_hot hvr-wobble-bottom"> <a class="" href="#" > ���ѧϰ Hot</a> </div>
    	<div class="vk_index_top_post">
        	<a href="#" class="left hvr-wobble-top" > Office���� </a>
        	<a href="#" class="right hvr-wobble-top" > ǰ�˿��� </a>
        	<a href="#" class="left hvr-wobble-top" > Android ���� </a>
        	<a href="#" class="right hvr-wobble-top" > iOS���� </a>
        	<a href="#" class="left hvr-wobble-top" > ��Ϸ���� </a>
        	<a href="#" class="right hvr-wobble-top" > ƽ����� </a>
        	<a href="#" class="left hvr-wobble-top" > ��Ʒ��Ӫ </a>
        	<a href="#" class="right hvr-wobble-top" > ����Ӫ�� </a>
        </div>
    </div>
    <!-- �ϲ��Ҳ�ģ�� end -->

</div>

  
  


<!--  ���λ   -->
<div class="wp vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_002]--> <div id="diy_vk_ad_002" class="area"></div><!--[/diy]--> 
</div>



<div class="wp vk_diy_wide clear">
  	<!--[diy=diy_vk_slide_600]--> <div id="diy_vk_slide_600" class="area"></div><!--[/diy]--> 
</div>








<!-- �̲� -->
<div class="wp vk_diy_bg_none m_b_20 wow animated fadeInUp">
    <div class="vk_title_wide">
        <h2><a href="http://t.cn/Aiux1eta" target="_blank"><span>0Ԫ</span> �� �������</a></h2>
        <ul>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ƽ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > UI��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��·Ӫ�� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��Ϸ���� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > App��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > Office </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ǰ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ������֤ </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��ҵָ�� </a></li>
        </ul>
    </div>
    <!--[diy=diy_vk_class_00]--> <div id="diy_vk_class_00" class="area"></div><!--[/diy]--> 
</div>



  

<!--  ���λ   -->
<div class="wp vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_003]--> <div id="diy_vk_ad_003" class="area"></div><!--[/diy]--> 
</div>






<div class="vk_bg m_b_40 wow animated fadeInUp">
<div class="wp vk_diy_bg_none ">
    <div class="vk_title_wide">
        <h2><a href="http://t.cn/Aiux1eta" target="_blank"><span>����</span> �� ������</a></h2>
        <ul>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ƽ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > UI��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��·Ӫ�� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��Ϸ���� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > App��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > Office </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ǰ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ������֤ </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��ҵָ�� </a></li>
        </ul>
    </div>
    <div>
        <div class="col_3_l vk_bg_white">
            <!--[diy=diy_vk_class_011]--> <div id="diy_vk_class_011" class="area"></div><!--[/diy]--> 
            <!--[diy=diy_vk_class_0111]--> <div id="diy_vk_class_0111" class="area"></div><!--[/diy]--> 
        </div>
        <div class="col_3_m">
            <!--[diy=diy_vk_class_012]--> <div id="diy_vk_class_012" class="area"></div><!--[/diy]--> 
        </div>
        <div class="col_3_r">
            <!--[diy=diy_vk_class_013]--> <div id="diy_vk_class_013" class="area"></div><!--[/diy]--> 
        </div>
    </div>
</div>
</div>







<!--  ���λ   -->
<div class="wp vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_004]--> <div id="diy_vk_ad_004" class="area"></div><!--[/diy]--> 
</div>



  
  
  

<!--  �����²� ȫ��������ռλ   -->
<div class="wp  vk_diy wow animated fadeInUp">
    <!--[diy=diy_vk_ad_005]--> <div id="diy_vk_ad_005" class="area"></div><!--[/diy]--> 
</div>




<!-- �̲� -->
<div class="wp vk_diy_bg_none m_b_20 wow animated fadeInUp">
    <div class="vk_title_wide">
        <h2><a href="http://t.cn/Aiux1eta" target="_blank">������</a></h2>
        <ul>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ƽ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > UI��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��·Ӫ�� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��Ϸ���� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > App��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > Office </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ǰ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ������֤ </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��ҵָ�� </a></li>
        </ul>
    </div>
    <!--[diy=diy_class_1]--> <div id="diy_class_1" class="area"></div><!--[/diy]--> 
</div>






<!--  ���λ   -->
<div class="wp  vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_006]--> <div id="diy_vk_ad_006" class="area"></div><!--[/diy]--> 
</div>







<div class="wp vk_diy_bg_none m_b_20 wow animated fadeInUp">
    <div class="vk_title_wide">
        <h2><a href="http://t.cn/Aiux1eta" target="_blank">��ѿ�</a></h2>
        <ul>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ƽ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > UI��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��·Ӫ�� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��Ϸ���� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > App��� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > Office </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ǰ����� </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ������֤ </a></li>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > ��ҵָ�� </a></li>
        </ul>
    </div>
    <!--[diy=diy_class_2]--> <div id="diy_class_2" class="area"></div><!--[/diy]--> 
</div>







<!--  ���λ   -->
<div class="wp  vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_007]--> <div id="diy_vk_ad_007" class="area"></div><!--[/diy]--> 
</div>






<div class="vk_bg vk_bg_white p_b_20 m_b_20 wow animated fadeInUp">
<div class="wp col_1-1">
    <div class="vk_title_wide  m_t_20">
        <h2><a href="http://t.cn/Aiux1eta" target="_blank">������̬</a></h2>
        <ul>
            <li><a href="#" target="_blank" class="hvr-bounce-to-right" > �������� </a></li>
        </ul>
    </div>

    <div class="vk_col_ct">
        <div class="col_1-1_l">
            <div class="vk_title_wide_sub title_color_blue">
                <h2><a href="http://t.cn/Aiux1eta" target="_blank">������</a></h2>
                <!--
                <ul>
                    <li><a href="http://t.cn/Aiux1eta" target="_blank"> ���� + </a></li>
                </ul>
                -->
            </div>

            <div class="p_r_20 m_r_20 b_r_dashed">
                <!--[diy=diy_vk_diy_1-1_left]--> <div id="diy_vk_diy_1-1_left" class="area"></div><!--[/diy]--> 
            </div>


        </div>

        <div class="col_1-1_r">
            <div class="vk_title_wide_sub title_color_blue">
                <h2><a href="http://t.cn/Aiux1eta" target="_blank">�ȵ��Ƽ�</a></h2>
                <!--
                <ul>
                    <li><a href="http://t.cn/Aiux1eta" target="_blank"> ���� + </a></li>
                </ul>
                -->
            </div>

            <div class=" ">
                <!--[diy=diy_vk_diy_1-1_right]--> <div id="diy_vk_diy_1-1_right" class="area"></div><!--[/diy]--> 
            </div>
        </div>
    </div>
</div>
</div>





<!--  ���λ   -->
<div class="wp  vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_008]--> <div id="diy_vk_ad_008" class="area"></div><!--[/diy]--> 
</div>





<div class="vk_bg m_b_20 wow fadeInUp">
    <div class="wp " >
		<div class="vk_title_center m_t_20"  >
			<h2>ʦ������<i></i></h2>
		</div>
		<div class="vk_title_center_sub"  >
			<h2>100��λ��ʦ���ߣ��㼯ȫ������ʦ����Դ���ṩ��õĽ�������<i></i></h2>
		</div>
	</div>

    <div class="wp vk_diy_bg_none  m_t_20">
        <!--[diy=diy_vk_diy_teacher]--> <div id="diy_vk_diy_teacher" class="area"></div><!--[/diy]--> 
    </div>

</div>






<!--  ���λ   -->
<div class="wp  vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_009]--> <div id="diy_vk_ad_009" class="area"></div><!--[/diy]--> 
</div>






<div class="vk_bg m_b_20 wow animated fadeInUp">
    <div class="wp " >
		<div class="vk_title_center m_t_20"  >
			<h2>��ҵ����<i></i></h2>
		</div>
		<div class="vk_title_center_sub "  >
			<h2>1000��Һ�����ҵ�����ǻ�������ͨ�š����ڡ�ʵҵ�ȶ���ְҵ<i></i></h2>
		</div>
	</div>

    <!--{subtemplate portal/vk_company_logo}-->

</div>





<!--  ���λ   -->
<div class="wp  vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_010]--> <div id="diy_vk_ad_010" class="area"></div><!--[/diy]--> 
</div>




<div class="wp m_b_20 wow animated fadeInUp">
    <div class="wp vk_touch_support " >
        <h2>֧�ֵ��ԡ��ֻ���PAD��ƽ̨ѧϰ</h2>
        <ul class="zg_dptu">
            <li class="l1">
                <h6>֧�� Android��iOS �����豸</h6>
                <p>������Ƶ����ͬ�����ƶ��ˣ�֧��ƻ���Ͱ�׿�����豸</p>
            </li>
            <li class="l2">
                <h6>APP֧�����ߣ���ʱѧ</h6>
                <p>������Ƶ����ͬ�����ƶ��ˣ�֧��ƻ���Ͱ�׿�����豸</p>
            </li>
            <li class="l3">
                <h6>ֱ����¼������ѧϰ��ʽ</h6>
                <p>����ֱ�������γ̣�Ҳ��¼����Ƶ�����䲻ͬ����</p>
            </li>
        </ul>
    </div>

</div>










<div class="wp m_b_20 wow animated fadeInUp">
    <div class="wp col_3 vk_diy_bg_none" >
        <div class="col_3_l">
            <h2>�ɻ�����</h2>
            <!--[diy=diy_vk_col_3_l]--> <div id="diy_vk_col_3_l" class="area"></div><!--[/diy]--> 
        </div>
        <div class="col_3_m">
            <h2>֪ʶ����</h2>
            <!--[diy=diy_vk_col_3_m]--> <div id="diy_vk_col_3_m" class="area"></div><!--[/diy]--> 
        </div>
        <div class="col_3_r">
            <h2>��ʦָ��</h2>
            <!--[diy=diy_vk_col_3_r]--> <div id="diy_vk_col_3_r" class="area"></div><!--[/diy]--> 
        </div>
        
    </div>

</div>





<!--  ���λ   -->
<div class="wp  vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_011]--> <div id="diy_vk_ad_011" class="area"></div><!--[/diy]--> 
</div>



<div class="vk_bg m_b_20 wow animated fadeInUp">
    <div class="wp " >
		<div class="vk_title_center m_t_20"  >
			<h2>��������<i></i></h2>
		</div>
		<div class="vk_title_center_sub "  >
			<h2>��ӭ���������������ӣ���������ѯ���߿ͷ�<i></i></h2>
		</div>
	</div>

    <div class="wp vk_diy_bg_none  m_t_20">
        <!--[diy=diy_vk_diy_url]--> <div id="diy_vk_diy_url" class="area"></div><!--[/diy]--> 
    </div>

</div>






<!--  ���λ   -->
<div class="wp vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_012]--> <div id="diy_vk_ad_012" class="area"></div><!--[/diy]--> 
</div>






<!--  ��ҳ ȫ��������ռλ 5  -->
<div class="wp vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_5]--> <div id="diy_vk_ad_5" class="area"></div><!--[/diy]--> 
</div>



<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>



<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

