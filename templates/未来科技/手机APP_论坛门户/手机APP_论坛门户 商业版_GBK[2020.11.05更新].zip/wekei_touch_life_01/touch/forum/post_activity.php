<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="vk_post_activity cl">
	<div class="vk_post_activity_ct_1">
		<ul>
        	<li class=" vk_post_li_ct_1">
                <div class="vk_post_li_ct_title">{echo vk_lang('time_range_tip')}
                    <div class="y">
                    	<label for="activitytime"><input type="checkbox" id="activitytime" name="activitytime" class="pc" onclick="if(this.checked) {$('#certainstarttime').hide();$('#uncertainstarttime').show();} else {$('#certainstarttime').show();$('#uncertainstarttime').hide();}" value="1" {if $activity['starttimeto']}checked{/if} tabindex="1" />{lang activity_starttime_endtime}</label>
                    </div>
                </div>
                <div class="vk_post_time_scope">
                    <div id="certainstarttime" class="vk_post_time" {if $activity['starttimeto']}style="display: none"{/if}>
                    	<div class="vk_post_time_r_1 p_t_b_10">
                            <div class="vk_post_time_name">{lang post_event_time} :<span class="rq"> *</span></div>
                            <div class="vk_post_time_forum">
                                <input type="text" name="starttimefrom[0]" id="starttimefrom_0" placeholder="{echo vk_lang('time_form')} : 2020-05-20 10:00" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" />
                            </div>
                        </div>
                    </div>
                    
                    <div id="uncertainstarttime" class="vk_post_time" {if !$activity['starttimeto']}style="display: none"{/if}>
                    	<div class="vk_post_time_r_1  p_t_b_10">
                            <div class="vk_post_time_name">{echo vk_lang('start_time')}<span class="rq"> *</span></div>
                            <div class="vk_post_time_forum">
                                <input type="text" name="starttimefrom[1]" id="starttimefrom_1"  placeholder="{echo vk_lang('time_form')} : 2020-05-20 10:00" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" />
                            </div>
                        </div>
                    	<div class="vk_post_time_r_2  p_t_b_10">
                            <div class="vk_post_time_name">{echo vk_lang('end_time')}<span class="rq"> *</span></div>
                            <div class="vk_post_time_forum">
                                <input type="text" autocomplete="off" id="starttimeto" name="starttimeto"  placeholder="{echo vk_lang('time_form')} : 2020-05-20 10:00" value="{if $activity['starttimeto']}$activity[starttimeto]{/if}" tabindex="1" />
                            </div>
                        </div>
                    </div>
                   
                </div>
            </li>
            
            <li class="vk_post_act_r">
                <div class="vk_post_li_ct_title">{lang activity_space}<span class="rq"> *</span></div>
                <div class="vk_post_li_ct_ct">
                    <input type="text" name="activityplace" id="activityplace" class="px oinf" value="$activity[place]" tabindex="1" />
                </div>
            </li>
            
            <!--{if $_GET[action] == 'newthread'}-->
            <li class="vk_post_act_r">
                <div class="vk_post_li_ct_title">{lang activity_city}</div>
                <div class="vk_post_li_ct_ct">
                   <input name="activitycity" id="activitycity" class="px" type="text" tabindex="1" />
                </div>
            </li>
            <!--{/if}-->
            
            
            <li class="vk_post_act_r">
                <div class="vk_post_li_ct_title">{lang activiy_sort}<span class="rq"> *</span></div>
                <div class="vk_post_li_ct_ct">
                <!--{if $activitytypelist}-->
					<select id="activityclass" name="activityclass" value="$activity[class]" >
					<!--{loop $activitytypelist $type}-->
						<option value="$type">$type</option>
					<!--{/loop}-->
					</select>
				<!--{/if}-->
                </div>
            </li>
            
            
            <li class="vk_post_act_r">
                <div class="vk_post_li_ct_title">{lang activity_need_member}<span class="rq"> *</span></div>
                <div class="vk_post_li_ct_ct">
					<input type="text" name="activitynumber" id="activitynumber" class="px z" value="$activity[number]" tabindex="1" />
                </div>
            </li>
            
            <li class="vk_post_act_r">
                <div class="vk_post_li_ct_title">{echo vk_lang('sex')}<span class="rq"> *</span></div>
                <div class="vk_post_li_ct_ct">
					<select name="gender" id="gender" width="38" class="ps">
						<option value="0" {if !$activity['gender']}selected="selected"{/if}>{lang unlimited}</option>
						<option value="1" {if $activity['gender'] == 1}selected="selected"{/if}>{lang male}</option>
						<option value="2" {if $activity['gender'] == 2}selected="selected"{/if}>{lang female}</option>
					</select>
                </div>
            </li>
            
			<!--{if $_G['setting']['activityfield']}-->
            <li class=" vk_post_li_ct_1">
                <div class="vk_post_li_ct_title">{lang optional_data}<span class="rq"> *</span></div>
                <div class="vk_post_li_ct_ct">
                    <ul class="vk_post_optional_ct cl">
                    <!--{loop $_G['setting']['activityfield'] $key $val}-->
                    	<li>
                        	<label for="userfield_$key"><input type="checkbox" name="userfield[]" id="userfield_$key" class="pc" value="$key"{if $activity['ufield']['userfield'] && in_array($key, $activity['ufield']['userfield'])} checked="checked"{/if} />$val</label>
                        </li>
                    <!--{/loop}-->
                    </ul>
                </div>
            </li>
            <!--{/if}-->

		</ul>
	</div>
	<div class="vk_post_activity_ct_2">
		<ul>
			<!--{if $_G['setting']['activitycredit']}-->
            <li class="vk_post_act_r">
                <div class="vk_post_li_ct_title">{lang consumption_credit}</div>
                <div class="vk_post_li_ct_ct">
					<input type="text" name="activitycredit" id="activitycredit" class="px" value="$activity[credit]" />{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}
                </div>
            </li>
            <!--{/if}-->
            
            <li class="vk_post_act_r">
                <div class="vk_post_li_ct_title">{lang activity_payment}</div>
                <div class="vk_post_li_ct_ct">
					<input type="text" name="cost" id="cost" class="px" onkeyup="checkvalue(this.value, 'costmessage')" value="$activity[cost]" tabindex="1" />{lang payment_unit}
                </div>
            </li>
            
            
            <li class="vk_post_act_r">
                <div class="vk_post_li_ct_title">{lang post_closing}</div>
                <div class="vk_post_li_ct_ct">
					<input type="text" name="activityexpiration" id="activityexpiration" class="px" placeholder="{echo vk_lang('time_form')} : 2020-05-20 10:00" autocomplete="off" value="$activity[expiration]" tabindex="1" />
                </div>
            </li>
            
			<!--{if $allowpostimg}-->
            <li class=" vk_post_topic_img_li">
                <div class="vk_post_li_ct_title">{lang post_topic_image}</div>
                <div class="vk_post_li_ct_ct">
                      <div id="activityaid" class="vk_post_topic_img_title cl">
                          <a href="javascript:;" class="vk_post_topic_img_title_a">
                              <input type="file" name="activityaid_upload" id="activityaid_upload"/>
                              <em>{lang upload}</em>
                          </a>
                      </div>
                      <input type="hidden" name="activityaid" id="activityaid" {if $activityattach[attachment]}value="$activityattach[aid]" {/if}/>
					  <input type="hidden" name="activityaid_url" id="activityaid_url" />
                      <div id="activityattach_image" class="vk_post_topic_img_ct">
                      </div>
					  <script type="text/javascript">
                          $(document).on('change', '#activityaid_upload', function() {
                                  popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
                      
                                  uploadsuccess = function(data) {
                                      if(data == '') {
                                          popup.open('{lang uploadpicfailed}', 'alert');
                                      }
                                      var dataarr = data.split('|');
                                      if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                                          popup.close();
                                              $('#activityaid').val(dataarr[3]);
                                              $('#activityaid_url').val(dataarr[5]);
                                              $('.vk_post_topic_img_ct').html('<a href="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" target="_blank"><img src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a>');
                                      } else {
                                          var sizelimit = '';
                                          if(dataarr[7] == 'ban') {
                                              sizelimit = '{lang uploadpicatttypeban}';
                                          } else if(dataarr[7] == 'perday') {
                                              sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                                          } else if(dataarr[7] > 0) {
                                              sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                                          }
                                          popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
                                      }
                                  };
                      
                                  if(typeof FileReader != 'undefined' && this.files[0]) {
                                      
                                      $.buildfileupload({
                                          uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
                                          files:this.files,
                                          uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                                          uploadinputname:'Filedata',
                                          maxfilesize:"$swfconfig[max]",
                                          success:uploadsuccess,
                                          error:function() {
                                              popup.open('{lang uploadpicfailed}', 'alert');
                                          return false;
                                          }
                                      });
                      
                                  } else {
                      
                                      $.ajaxfileupload({
                                          url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
                                          data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                                          dataType:'text',
                                          fileElementId:'filedata',
                                          success:uploadsuccess,
                                          error: function() {
                                              popup.open('{lang uploadpicfailed}', 'alert');
                                          }
                                      });
                      
                                  }
                          });
                      </script>
                </div>
            </li>
            <!--{/if}-->
			<!--{hook/post_activity_extra}-->
            <li class="vk_post_li_ct_1"><div class="vk_post_content">{lang thread_content}</div></li>
		</ul>
	</div>
</div>
<script type="text/javascript" reload="1">
simulateSelect('gender');
function activityaid_upload(aid, url) {
	$('activityaid_url').value = url;
	updateactivityattach(aid, url, '{$_G['setting']['attachurl']}forum');
}
</script>
