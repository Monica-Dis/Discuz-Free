<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="vk_post_activity cl">
	<div class="vk_post_activity_ct_1">
		<ul>
        	<li class=" vk_post_li_ct_1">
            	<div class="vk_post_li_ct_title">{lang debate_square_point}<span class="rq"> *</span></div>
                <div class="vk_post_li_ct_ct">
                	<textarea name="affirmpoint" id="affirmpoint" class="pt" tabindex="1">$debate[affirmpoint]</textarea>
                </div>
            </li>
        	<li class=" vk_post_li_ct_1">
            	<div class="vk_post_li_ct_title">{lang debate_opponent_point}<span class="rq"> *</span></div>
                <div class="vk_post_li_ct_ct">
                	<textarea name="negapoint" id="negapoint" class="pt" tabindex="1">$debate[negapoint]</textarea>
                </div>
            </li>
		</ul>
	</div>
	<div class="vk_post_activity_ct_2">
		<ul>
        	<li class="vk_post_act_r">
            	<div class="vk_post_li_ct_title">{lang endtime}</div>
                <div class="vk_post_li_ct_ct">
                	<input type="text" name="endtime" id="endtime" class="px" placeholder="{echo vk_lang('time_form')} : 2020-05-20 10:00" autocomplete="off" value="$debate[endtime]" tabindex="1" />
                </div>
            </li>
            
        	<li class="vk_post_act_r">
            	<div class="vk_post_li_ct_title">{lang debate_umpire}</div>
                <div class="vk_post_li_ct_ct">
                	<input type="text" name="umpire" id="umpire" class="px" placeholder="{echo vk_lang('debate_name_tip')}" value="$debate[umpire]" tabindex="1" />
                </div>
            </li>
            <li class="vk_post_li_ct_1"><div class="vk_post_content">{lang thread_content}</div></li>
			<!--{hook/post_debate_extra}-->
		</ul>
	</div>
</div>

<script type="text/javascript" reload="1">
function checkuserexists(username, objname) {
	if(!username) {
		$(objname).innerHTML = '';
		return;
	}
	var x = new Ajax();
	username = BROWSER.ie && document.charset == 'utf-8' ? encodeURIComponent(username) : username;
	x.get('forum.php?mod=ajax&inajax=1&action=checkuserexists&username=' + username, function(s){
		var obj = $(objname);
		obj.innerHTML = s;
	});
}

EXTRAFUNC['validator']['special'] = 'validateextra';
function validateextra() {
	if($('postform').affirmpoint.value == '') {
		showDialog('{lang post_debate_message_1}', 'alert', '', function () { $('postform').affirmpoint.focus() });
		return false;
	}
	if($('postform').negapoint.value == '') {
		showDialog('{lang post_debate_message_2}', 'alert', '', function () { $('postform').negapoint.focus() });
		return false;
	}
	return true;
}
</script>
