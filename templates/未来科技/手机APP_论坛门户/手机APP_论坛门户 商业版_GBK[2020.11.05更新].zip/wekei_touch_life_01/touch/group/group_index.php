<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $status != 2}-->
	

	<div class="vk_group_threadlist_div cl">

		<div class="vk_group_threadlist cl">
		<!--{if $newthreadlist['dateline']['data']}-->
        	<ul id="vk_group_list_ul">
            	<!--{loop $newthreadlist['dateline']['data'] $thread}-->
					<!--{eval $vk_place = DB::result_first('SELECT place FROM '.DB::table('forum_activity').' WHERE tid ='.$thread[tid].'')}-->
					<!--{eval $vk_type = DB::result_first('SELECT class FROM '.DB::table('forum_activity').' WHERE tid ='.$thread[tid].'')}-->
					<!--{eval $vk_time_start = DB::result_first('SELECT starttimefrom FROM '.DB::table('forum_activity').' WHERE tid ='.$thread[tid].'')}-->
					<!--{eval $vk_time_end = DB::result_first('SELECT starttimeto FROM '.DB::table('forum_activity').' WHERE tid ='.$thread[tid].'')}-->
					<!--{eval $vk_time_now = time()}-->
            	<li id="$thread[id]">
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="normal">
                    <p $thread[highlight] class="tit cl">
                        <!--{if $thread['digest'] > 0}-->
							<span class="digest">{echo vk_lang('digest')}</span>
                        <!--{/if}-->
                        <!--{if $thread['special'] == 1}-->
                            <span class="vk_thread_type">{lang thread_poll}</span>
                        <!--{elseif $thread['special'] == 2}-->
                            <span class="vk_thread_type">{lang thread_trade}</span>
                        <!--{elseif $thread['special'] == 4}-->
                            <!--{if $vk_time_end}-->
                                <!--{if $vk_time_end < $vk_time_now}-->
								<span class="vk_thread_type" style="background:#999;">{echo vk_lang('activity_over')}</span>
								<!--{else}-->
								<span class="vk_thread_type">{echo vk_lang('activity_ongoing')}</span>
                                <!--{/if}-->
                            <!--{else}-->
                                <!--{if $vk_time_start < $vk_time_now}-->
								<span class="vk_thread_type" style="background:#999;">{echo vk_lang('activity_over')}</span>
								<!--{else}-->
								<span class="vk_thread_type">{echo vk_lang('activity_ongoing')}</span>
                                <!--{/if}-->
                            <!--{/if}-->
                        <!--{elseif $thread['special'] == 5}-->
                            <span class="vk_thread_type">{lang thread_debate}</span>
                        <!--{/if}-->
                        <!--{if $thread['price'] > 0}-->
                            <!--{if $thread['special'] == '3'}-->
							<span class="vk_thread_type">{lang thread_reward}</span>
							<!--{else}-->
							<span class="vk_thread_type">{lang thread_reward}</span>
                            <!--{/if}-->
						<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
							<span class="vk_thread_type" style="background:#7b2;">{lang reward_solved}</span>
						<!--{/if}-->
						{$thread[subject]}
                        <!--{if $thread['price'] > 0}-->
                        <span class="price">$thread[price]</span>
                        <!--{/if}-->
                        
                        <!--{if $_G['forum_thread']['recommendlevel']}-->
                            <span class="recommend">{lang thread_recommend} $_G['forum_thread'][recommends]</span>
                        <!--{/if}-->
                        <!--{if $_G['forum_thread'][heatlevel]}-->
                            <span class="heats">{lang hot_thread}</span>
                        <!--{/if}-->
                    </p>
                   			<!--{eval include(DISCUZ_ROOT."./template/wekei_touch_life_01/touch/common/group_pic.php");}-->
                            $thread['pic']
                            <!--{eval include(DISCUZ_ROOT."./template/wekei_touch_life_01/touch/common/group_summary.php");}-->
                            $thread['summary']
                    <!--{if $thread['special'] == 4}-->
					<p class="activity cl">
						<!--{if $vk_place}--><span><em>{echo vk_lang('place')} : </em>$vk_place</span><!--{/if}-->
						<!--{if $vk_type}--><span><em>{echo vk_lang('type')}  : </em>$vk_type</span><!--{/if}-->
						<!--{if $vk_time_start}--><span><em>{echo vk_lang('time')}  : </em>{echo dgmdate($vk_time_start)}<!--{if $vk_time_end}--> - {echo dgmdate($vk_time_end)}<!--{/if}--></span><!--{/if}-->
					</p>
					<!--{else}-->
					<p class="auth cl">
						<!--{avatar($thread[authorid], 'middle')}-->
						<span {if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if}>$thread[author]</span>
						<span>&nbsp;/&nbsp;$thread[dateline]</span>
						<em>{$thread[replies]} {echo vk_lang('reply')}</em><em>$thread[views] {echo vk_lang('view')}</em>
					</p>
                    <!--{/if}-->
                    </a>
                </li>
                <!--{/loop}-->
            </ul>

            <!--{if $_G['forum']['threads'] > 10}-->
                <div class="more cl"><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]#groupnav">{lang click_to_readmore}</a></div>	
            <!--{/if}-->

		<!--{else}-->
       		<div class="emp cl"><p>{lang forum_nothreads}</p></div>
		<!--{/if}-->
		</div>
	</div>
	
	<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
		<ul class="p_pop" id="newspecial_menu" style="display: none">
			<!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" onclick="showWindow('newthread', this.href);doane(event)">{lang post_newthread}</a></li><!--{/if}-->
			<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
			<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
			<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
			<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
			<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
			<!--{if $_G['setting']['threadplugins']}-->
				<!--{loop $_G['forum']['threadplugin'] $tpid}-->
					<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
						<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url($_G[setting][threadplugins][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>
					<!--{/if}-->
				<!--{/loop}-->
			<!--{/if}-->
			<!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
				<!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
					<!--{if $_G['forum']['threadsorts']['show'][$id]}-->
						<li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id">$threadsorts</a></li>
					<!--{/if}-->
				<!--{/loop}-->
			<!--{/if}-->
		</ul>
	<!--{/if}-->
<!--{/if}-->

