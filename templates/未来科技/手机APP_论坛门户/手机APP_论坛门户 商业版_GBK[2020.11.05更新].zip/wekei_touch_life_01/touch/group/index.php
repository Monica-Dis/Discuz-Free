<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->



<!-- header start -->
    <div class="header_group">
        <div class="nav_group">
	        <a href="javascript:;" id="icon_nav_one" class="z icon_nav_one"></a>
			<span class="name">{echo vk_lang('group')}</span>
            <a href="forum.php?mod=group&action=create" class="y vk_icon_add"></a>
        </div>
    </div>
<!-- header end -->
<style type="text/css">
	#header { display: none; }
	/*
	.header_sub { position: relative; float: left; display: block; width: 100%; height: 44px; margin-top: 0px; z-index: 99;}
	*/
	#page { padding-top: 0px; }
</style>



<!-- main forumlist start -->
<div class="page">

	<div class="forum_left_nav">
		<ul id="forum_left_nav">
			<li class="item"><a href="#tab0" class="tab-link active">{echo vk_lang('rec_for_you')}</a></li>
			<li class="item"><a href="#tab1" class="tab-link">{echo vk_lang('group_my_manage')}</a></li>
			<li class="item"><a href="#tab2" class="tab-link">{echo vk_lang('group_my_join')}</a></li>
			<!--{loop $first $groupid $group}-->
			<li class="item"><a href="#tab{$groupid}" class="tab-link">$group[name]</a></li>
			<!--{/loop}-->
   		</ul>
	</div>



	<div class="forum_right_content">
		<div class="tabs">
			<div class="sub_forum tab active" id="tab0">
				<!--{if dunserialize($_G['setting']['group_recommend'])}-->
					<ul>
					<!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->         
						<li>
							<div class="sub_icon sub_icon_group">
							<!--{if $val[icon]}-->
								<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]"><img src="$val[icon]"  alt="$val[name]"/></a>
							<!--{else}-->
								<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]"><img src="static/image/common/groupicon.gif" /></a>
							<!--{/if}-->
							</div>
							<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="sub_forum_name">
								<i class="iconfont icon-right"></i>
								<div class="sub_forum_name_div">
									<h2>{$val[name]}</h2>
									<p class="sub_forum_info">$val[description]</p>
								</div>
							</a>
						</li>
						<!--{/loop}-->
						</ul>
				<!--{else}-->
					<div class="my_fav_tip">{echo vk_lang('group_my_rec_none')}</div>
				<!--{/if}-->

			</div>
			
			<!-- ������ʾ���ҹ����ġ�Ⱥ�� -->
			<!--{eval require_once('template/wekei_touch_life_01/touch/common/group_my.php');}-->
					
		
			<div class="sub_forum tab" id="tab1">
				<!--{if $grouplistmanage}-->
					<ul>
					<!--{loop $grouplistmanage $groupid $group}-->
					<!--{eval $groupdesc = DB::result_first('SELECT description FROM '.DB::table('forum_forumfield').' WHERE fid ='.$groupid.'')}-->
							<li>
								<div class="sub_icon sub_icon_group">
								<a href="forum.php?mod=forumdisplay&action=list&fid=$groupid"><img src="$group[icon]" alt="$group[name]" /></a>
								</div>
								<a href="forum.php?mod=forumdisplay&action=list&fid=$groupid" class="sub_forum_name">
									<i class="iconfont icon-right"></i>
									<div class="sub_forum_name_div">
										<h2>{$group[name]}</h2>
										<p class="sub_forum_info">$groupdesc</p>
									</div>
								</a>
							</li>
					<!--{/loop}-->
					</ul>
				<!--{else}-->
					{if $_G[uid]}
						<div class="my_fav_tip">
							<a href="forum.php?mod=group&action=create">{lang group_create}</a>
							<p style="margin-top:20px;">{echo vk_lang('group_my_manage_none')}</p>
						</div>
					{else}
						<div class="my_fav_tip">
							<a href="member.php?mod=logging&action=login" title="{lang login}">{lang login}</a> 
							<a href="member.php?mod={$_G[setting][regname]}" title="{$_G['setting']['reglinkname']}">{lang register}</a>
							<p>{echo vk_lang('my_fav_tip_show_manage')}</p>
						</div>
					{/if}
				<!--{/if}-->

			</div>
			<div class="sub_forum tab" id="tab2">
				<!--{if $grouplist_join}-->
					<ul>
					<!--{loop $grouplist_join $groupid $group}-->
					<!--{eval $groupdesc = DB::result_first('SELECT description FROM '.DB::table('forum_forumfield').' WHERE fid ='.$groupid.'')}-->
							<li>
								<div class="sub_icon sub_icon_group">
								<a href="forum.php?mod=forumdisplay&action=list&fid=$groupid"><img src="$group[icon]" alt="$group[name]" /></a>
								</div>
								<a href="forum.php?mod=forumdisplay&action=list&fid=$groupid" class="sub_forum_name">
									<i class="iconfont icon-right"></i>
									<div class="sub_forum_name_div">
										<h2>{$group[name]}</h2>
										<p class="sub_forum_info">$groupdesc</p>
									</div>
								</a>
							</li>
					<!--{/loop}-->
					</ul>
				<!--{else}-->
					{if $_G[uid]}
						<div class="my_fav_tip">{echo vk_lang('group_my_join_none')}</div>
					{else}
						<div class="my_fav_tip">
							<a href="member.php?mod=logging&action=login" title="{lang login}">{lang login}</a> 
							<a href="member.php?mod={$_G[setting][regname]}" title="{$_G['setting']['reglinkname']}">{lang register}</a>
							<p>{echo vk_lang('my_fav_tip_show_join')}</p>
						</div>
					{/if}
				<!--{/if}-->

			</div>
		<!--{loop $first $groupid $group}-->
			<div class="sub_forum tab" id="tab{$groupid}">
				<ul class="cl">
				<!--{loop $lastupdategroup[$groupid] $val}-->
				<!--{eval $vk_group_icon = DB::result_first('SELECT icon FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid].'')}-->
				<!--{eval $vk_group_desc = DB::result_first('SELECT description FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid].'')}-->
					<li>
						<div class="sub_icon sub_icon_group">
						<!--{if $vk_group_icon}-->
							<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]"><img src="data/attachment/group/$vk_group_icon" /></a>
						<!--{else}-->
							<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]"><img src="static/image/common/groupicon.gif" /></a>
						<!--{/if}-->
						</div>
						<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="sub_forum_name">
							<i class="iconfont icon-right"></i>
							<div class="sub_forum_name_div">
								<h2>{$val[name]}</h2>
								<p class="sub_forum_info">$vk_group_desc</p>
							</div>
						</a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>

		<!--{/loop}-->

		</div>
	</div>

</div>
<!-- main forumlist end -->




<!--{template common/footer}-->
