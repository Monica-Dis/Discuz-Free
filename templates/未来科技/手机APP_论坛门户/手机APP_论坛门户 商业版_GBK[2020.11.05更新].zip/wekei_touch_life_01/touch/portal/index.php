<?php exit; ?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>


<!-- �����������õ� �õ���css��js�ļ� -->
<link href="$_G['style']['styleimgdir']/touch/css/swiper.min.css" rel="stylesheet" />
<script src="$_G['style']['styleimgdir']/touch/css/swiper.min.js?{VERHASH}"></script> 




<!--
�������ֵ��� - �����л���ʽ
-->

<!-- ���������̶���ʽ
<div class="swiper-container-nav" id="topNav" style=" display:block; width:100%; height: 50px; position:fixed; top:44; z-index:99; border-top:1px solid #eee; background:#fff;">
-->

<div class="swiper-container-nav" id="topNav">
  <div class="swiper-wrapper">
  		<div class="swiper-slide active"><span>�Ƽ�</span></div>
		<div class="swiper-slide"><span>�Ȱ�</span></div>
		<div class="swiper-slide"><span>��Ů</span></div>
		<div class="swiper-slide"><span>����</span></div>
		<div class="swiper-slide"><span>����</span></div>
		<div class="swiper-slide"><span>����</span></div>
	</div>
</div>





<!--
�������ֵ��� ��Ӧ��ģ��
-->
<div class="swiper-container-page" id="topNav_page">
	<div class="swiper-wrapper" >
	
	
	
		<!-- ģ��"�Ƽ�"�µ�block���� -->
		<div class="swiper-slide  swiper-slide-active">
		

			<!-- �õ� ���ô��� -->
			<div class="vk_wp" style="margin-top: 0px; overflow: hidden;">
				<!--{block/100000}-->
			</div>
			

			<!-- ����/ͷ�� ���ô��� -->
			<div class="vk_wp" style="margin-top: 0px;">
				<div class="vk_diy_news_top">
					<div class="diy_left_icon"></div>
					<div class="diy_right_div">
					<!--{block/100000}-->
					</div>
				</div>
			</div>
			
			

			<!-- ������ -->
			<div class="vk_wp">
				<!--{block/100000}-->
			</div>
			
			

			<!-- ͼ�� ���� - �±��⣬��ͼƬ - ������ʾ�������л� -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_rec"><a href="#" target="_blank">��ͼ�Ƽ�</a></h2>
					<ul>
						<li><a href="#" target="_blank" class="more_rec"> �鿴���� </a></li>
					</ul>
				</div>
				<div class="p_l_15">
				<!--{block/100000}-->
				</div>
			</div>
			

			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_0.jpg" />
					</a>
				</div>
			</div>
			

			<!-- ����ͼ�� ���� -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_hot"><a href="#" target="_blank">����</a></h2>
					<ul>
						<li><a href="#" target="_blank" > ��Ů </a></li>
						<li><a href="#" target="_blank" > �Ƽ� </a></li>
						<li><a href="#" target="_blank" > ���� </a></li>
						<li><a href="#" target="_blank" > ���� > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			

			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_1.jpg" />
					</a>
				</div>
			</div>



			<!-- ����ͼ�� ���� -->
			<div class="wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_car"><a href="#" target="_blank">����</a></h2>
					<ul>
						<li><a href="#" target="_blank" > ���� > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			
			

			<!-- ��/�� -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_2.jpg" />
					</a>
				</div>
			</div>



			<!-- ����ͼ�� ���� -->
			<div class="wp">
				<div class="vk_diy_title m_b_0">
					<h2 class="vk_title_house"><a href="#" target="_blank">����¥��</a></h2>
					<ul>
						<li><a href="#" target="_blank" > ���� > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			

			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_4.jpg" />
					</a>
				</div>
			</div>



			<!-- ����ͼ�� ���� -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_baby"><a href="#" target="_blank">ĸӤ����</a></h2>
					<ul>
						<li><a href="#" target="_blank" > ���� > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			
			

			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_5.jpg" />
					</a>
				</div>
			</div>



			<!-- ����ͼ�� ���� -->
			<div class="wp">
				<div class="vk_diy_title m_b_0">
					<h2 class="vk_title_edu"><a href="#" target="_blank">������ѵ</a></h2>
					<ul>
						<li><a href="#" target="_blank" > ���� > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			
			
			
			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_6.jpg" />
					</a>
				</div>
			</div>
			
			

			<!-- ��ҳ ���ӵ������ ��ʼ  -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_forum"><a href="#" target="_blank">���¶�̬</a></h2>
					<ul>
						<li><a href="#" target="_blank" > ���� </a></li>
						<li><a href="#" target="_blank" > ���� </a></li>
						<li><a href="#" target="_blank" > �Ƽ� </a></li>
					</ul>
				</div>

				<!-- ������һ���ǵ��õ���Ҫ��ʾ�İ��ID�����Ը�����Ҫ����������ֻ�Ϊ��Ҫ��ʾ�İ��ID���� -->
				<!--{eval $fids = '2,37,38,39,40,41,42'}--> 

				<!--{eval $postlist = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." WHERE `displayorder` = 0 AND isgroup = '0' AND `fid` in ($fids) ORDER BY `dateline` DESC limit 0 , 100");}-->

				<div class="vk_threadlist" style=" margin-top: -10px; border-top: none;">
					<!--{loop $postlist $post_list}-->
					<!--{eval $piclist = substr($post_list[tid], -1); $pic_list = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$piclist.'')." WHERE `tid`= $post_list[tid] AND isimage = '1' ORDER BY `dateline` DESC limit 0 , 9");}-->
					<!--{eval $picnum = count($pic_list);}-->

					<article class="vk_load_list"> 

						<div class="vk_title_div">
							 <a href="forum.php?mod=viewthread&tid=$post_list[tid]" class="vk_thread_title" title="$post_list[subject]">$post_list[subject]</a>
						</div>

						<div class="vk_thread_pic cl"> 
							 <!--{loop $pic_list $key $vk_thread_pic}-->
							 <!--{eval $piclist = getforumimg($vk_thread_pic[aid], 0, 240, 160); }-->			
								<div class="item_pic"><a href="forum.php?mod=viewthread&tid=$post_list[tid]"><p class="col_3_$key"><span class="col_3_img"><img src="$piclist"></span></p></a></div>
							 <!--{/loop}-->					
						</div>

						<div class="vk_author_info cl">
							  <a href="home.php?mod=space&uid=$post_list[authorid]" class="vk_author" target="_blank"><img src="uc_server/avatar.php?uid=$post_list[authorid]&amp;size=middle" alt="$post_list[author]" class="vk_avt">$post_list[author]</a>
							  <a class="vk_time"><!--{echo dgmdate($post_list[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></a>       
							  <span class="vk_reply">{$post_list[replies]}</span>
							  <span class="vk_view">{$post_list[views]}</span>
						</div>

					</article>

					<!--{/loop}-->

					<div class="vk_load_more">
						<a href="javascript:;">�鿴���� ... </a>
					</div>
				</div>
				<!-- ��Ҫ���� jquery.min.js����� head�ļ����ù����˴��ɺ��� -->
				<script type="text/javascript">
					jQuery(function (){
						showItem(0, 10);
						var itemNum = 10; 

						jQuery('.vk_load_more').click(function(){
							if(itemNum < 100){
								showItem(itemNum, itemNum += 20);
							} else {
								location.href = 'portal.php?mod=list&catid=1';
							}
						});  	

						function showItem(fromindex,toindex){
							var len = jQuery('.vk_load_list').length;
							for(var i = fromindex; i < toindex ; i++ ){
								jQuery('.vk_load_list').eq(i).css('display','block');
							}
						} 

					})
				</script>

			</div>
			<!-- ��ҳ ���ӵ������ ����  -->

			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_7.jpg" />
					</a>
				</div>
			</div>

		</div>








		<!-- ģ�顰�Ȱ��µ�block���� -->
		<div class="swiper-slide">
			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_7.jpg" />
					</a>
				</div>
			</div>
			<div class="vk_wp m_t_0">
				<!--{block/100000}-->
			</div>
		</div>




		<!-- ģ�顰��Ů���µ�block���� -->
		<div class="swiper-slide">
			<div class="wp m_t_0">
				<!--{block/100000}-->
			</div>
		</div>
		
		
		

		<!-- ģ�顰�������µ�block���� -->
		<div class="swiper-slide">
			<!-- ��/�� -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_2.jpg" />
					</a>
				</div>
			</div>
			<div class="wp">
				<!--{block/100000}-->
			</div>
		</div>
		
		
		

		<!-- ģ�顰�������µ�block���� -->
		<div class="swiper-slide">
			<!-- ��/�� -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>��/��</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_7.jpg" />
					</a>
				</div>
			</div>
			<div class="wp">
				<!--{block/100000}-->
			</div>
		</div>
		
		
		

		<!-- ģ�顰���֡��µ�block���� -->
		<div class="swiper-slide">
			<div class="wp m_t_0">
				<!--{block/100000}-->
			</div>
		</div>
		
		

	</div>
</div>





<script type="text/javascript">
var mySwiper = new Swiper('#topNav', {
	freeMode: true,
	freeModeMomentumRatio: 0.5,
	slidesPerView: 'auto',
	roundLengths : true,
});

swiperWidth = mySwiper.container[0].clientWidth
maxTranslate = mySwiper.maxTranslate();
maxWidth = -maxTranslate + swiperWidth / 2

$(".swiper-container").on('touchstart', function(e) {
	e.preventDefault()
})

mySwiper.on('tap', function(swiper, e) {
//    console.log(swiper.clickedIndex)
    pageSwiper.slideTo(swiper.clickedIndex, 1000, false);//��ת
//	e.preventDefault()
	slide = swiper.slides[swiper.clickedIndex]
	slideLeft = slide.offsetLeft
	slideWidth = slide.clientWidth
	slideCenter = slideLeft + slideWidth / 2
    console.log("slideLeft:"+slideLeft)
    console.log("maxWidth:"+maxWidth)
    console.log("slideCenter:"+slideCenter)
	// �����slide�����ĵ�
	mySwiper.setWrapperTransition(300)
	if (slideCenter < swiperWidth / 2) {
		mySwiper.setWrapperTranslate(0)
	} else if (slideCenter > maxWidth) {
		mySwiper.setWrapperTranslate(maxTranslate)
	} else {
		nowTlanslate = slideCenter - swiperWidth / 2
		mySwiper.setWrapperTranslate(-nowTlanslate)
	}
	$("#topNav .active").removeClass('active')
	$("#topNav .swiper-slide").eq(swiper.clickedIndex).addClass('active')

})
</script>



<script>
    var pageSwiper = new Swiper('#topNav_page', {
        paginationClickable: true,
        uniqueNavElements :false,
		roundLengths : true,
        onSlideChangeStart: function(swiper){
//            console.log(swiper.activeIndex)
//            mySwiper.slideTo(swiper.activeIndex, 1000, false);
            $("#topNav .active").removeClass('active')
            $("#topNav .swiper-slide").eq(swiper.activeIndex).addClass('active')

            slide = mySwiper.slides[swiper.activeIndex];//��ȡ��ǰ��slide�ڵ�
            slideLeft = slide.offsetLeft
            slideWidth = slide.clientWidth
            slideCenter = slideLeft + slideWidth / 2
            // �����slide�����ĵ�
            console.log("============")
            console.log("slideLeft:"+slideLeft)
            console.log("maxWidth:"+maxWidth)
            console.log("slideCenter:"+slideCenter)
            console.log("swiperWidth / 2:"+swiperWidth / 2)
            mySwiper.setWrapperTransition(300)
            if (slideCenter < swiperWidth / 2) {
                mySwiper.setWrapperTranslate(0)
            } else if (slideCenter >maxWidth) {
                mySwiper.setWrapperTranslate(maxTranslate)
                console.log("maxTranslate:"+maxTranslate)
            } else {
                nowTlanslate = slideCenter - swiperWidth / 2
                console.log(nowTlanslate)
                mySwiper.setWrapperTranslate(-nowTlanslate)
            }
        }
    });
</script>









<div class="pullrefresh" style="display:none;"></div>

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>

<!--{template common/footer}-->

