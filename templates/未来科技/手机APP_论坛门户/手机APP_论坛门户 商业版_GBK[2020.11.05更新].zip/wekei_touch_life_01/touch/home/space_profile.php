<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->


<!--{if !$_GET['mycenter']}-->

<!-- header start -->
<header class="header">
    <div class="nav">
		<a href="javascript:;" onclick="history.go(-1);" class="z vk_icon_back"></a>
		<span><!--{if $_G['uid'] == $space['uid']}-->{lang myprofile}<!--{else}-->$space[username]{lang otherprofile}<!--{/if}--></span>
    </div>
</header>
<!-- header end -->




<!-- userinfo start -->
<div class="userinfo">
	<div class="vk_user_avatar">
		<div class="avatar_m cl"><span><img src="{avatar($space[uid], middle, true)}" /></span></div>
		<div class="name_sign">
			<h2 class="name">$space[username]</h2>
			<p class="vk_user_sign"><!--{if $space[group][maxsigsize] && $space[sightml]}-->$space[sightml]<!--{/if}--></p>
		</div>
	</div>
	
	
			
	<div class="wp user_info_num">
		<ul>
			<li class="user_info_num_1"><a href=""><span>$space['threads']</span> <p>{lang thread}</p></a></li>
			<li class="user_info_num_1"><a href=""><span>$space[posts]</span> <p>{lang reply}</p></a></li>
			<li class="user_info_num_1"><a href="home.php?mod=follow&do=following&uid=$uid"><span>$space['following']</span> <p>{echo vk_lang('follow')}</p></a></li>
			<li class="user_info_num_1"><a href="home.php?mod=follow&do=follower&uid=$uid"><span>$space['follower']</span> <p>{echo vk_lang('fan')}</p></a></li>
			<li class="user_info_num_1"><a href=""><span>$space[credits]</span> <p>{lang credits}</p></a></li>
		</ul>
	</div>
	
		
</div>
<!-- userinfo end -->




<!--{else}-->


<!-- userinfo start -->
<div class="userinfo">
	<div class="vk_user_avatar">
		<div class="avatar_m cl"><span><img src="<!--{avatar($_G[uid], big, true)}-->" /></span></div>
		<div class="name_sign">
			<h2 class="name">$_G[username]</h2>
			<p class="vk_user_sign"><!--{if $space[group][maxsigsize] && $space[sightml]}-->$space[sightml]<!--{/if}--></p>
		</div>
	</div>
	
	
			
	<div class="wp user_info_num">
		<ul>
			<li class="user_info_num_1"><a href=""><span>$space['threads']</span> <p>{lang thread}</p></a></li>
			<li class="user_info_num_1"><a href=""><span>$space[posts]</span> <p>{lang reply}</p></a></li>
			<li class="user_info_num_1"><a href="home.php?mod=follow&do=following&uid=$uid"><span>$space['following']</span> <p>{echo vk_lang('follow')}</p></a></li>
			<li class="user_info_num_1"><a href="home.php?mod=follow&do=follower&uid=$uid"><span>$space['follower']</span> <p>{echo vk_lang('fan')}</p></a></li>
			<li class="user_info_num_1"><a href=""><span>$space[credits]</span> <p>{lang credits}</p></a></li>
		</ul>
	</div>
	
		
	<div class="user_info_list cl">
		<ul>
			<li><a class="user_info_fav" href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang myfavorite}</a></li>
			<li><a class="user_info_thread" href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me">{lang mythread}</a></li>
			<li class="tit_msg"><a class="user_info_msg" href="home.php?mod=space&do=pm">{lang mypm}<!--{if $_G[member][newpm]}--><img src="{STATICURL}image/mobile/images/icon_msg.png" /><!--{/if}--></a></li>
			<li><a class="user_info_profile" href="home.php?mod=space&uid={$_G[uid]}">{lang myprofile}</a></li>
			
		</ul>
	</div>
</div>
<!-- userinfo end -->

<!--{/if}-->











<div class="space_profile_box">
<div  class="space_profile">
	<h2 >{lang stat_info}</h2>
	<ul >
		 
		<!--{if $space[buyercredit]}-->
		<li><em>{lang eccredit_sellerinfo}</em><a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit#sellcredit" target="_blank">$space[buyercredit] <img src="{STATICURL}image/traderank/buyer/$space[buyerrank].gif" border="0" class="vm" /></a></li>
		<!--{/if}-->
		<!--{if $space[sellercredit]}-->
		<li><em>{lang eccredit_buyerinfo}</em><a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit#buyercredit" target="_blank">$space[sellercredit] <img src="{STATICURL}image/traderank/seller/$space[sellerrank].gif" border="0" class="vm" /></a></li>
		<!--{/if}-->
		<li><em>{lang credits}</em>$space[credits]</li>
		<!--{loop $_G[setting][extcredits] $key $value}-->
		<!--{if $value[title]}-->
		<li><em>$value[title]</em>{$space["extcredits$key"]} $value[unit]</li>
		<!--{/if}-->
		<!--{/loop}-->
	</ul>
</div>

<div class="space_profile" >
	 
 		<h2>{echo vk_lang('profile')}</h2>
		<!--{if CURMODULE == 'space'}-->
			<!--{hook/space_profile_baseinfo_top}-->
		<!--{elseif CURMODULE == 'follow'}-->
			<!--{hook/follow_profile_baseinfo_top}-->
		<!--{/if}-->
		<ul class="pf_l cl pbm mbm">
			<!--{if $_G['setting']['allowspacedomain'] && $_G['setting']['domain']['root']['home'] && checkperm('domainlength') && !empty($space['domain'])}-->
			<!--{eval $spaceurl = $_G['scheme'].'://'.$space['domain'].'.'.$_G['setting']['domain']['root']['home'];}-->
			<li><em>{lang second_domain}</em><a href="$spaceurl" onclick="setCopy('$spaceurl', '{lang copy_space_address}');return false;">$spaceurl</a></li>
			<!--{/if}-->
			<!--{if $_G[setting][homepagestyle]}-->
			<li><em>{lang space_visits}</em><strong class="xi1">$space[views]</strong></li>
			<!--{/if}-->
			<!--{if in_array($_G[adminid], array(1, 2))}-->
			<li><em>Email</em>$space[email]</li>
			<!--{/if}-->
			<li><em>{lang email_status}</em><!--{if $space[emailstatus] > 0}-->{lang profile_verified}<!--{else}-->{lang profile_no_verified}<!--{/if}--></li>
			<li><em>{lang video_certification}</em><!--{if $space[videophotostatus] > 0}-->{lang profile_certified} <!--{if $showvideophoto}-->&nbsp;&nbsp;(<a href="home.php?mod=space&uid=$space[uid]&do=videophoto" id="viewphoto" onclick="showWindow(this.id, this.href, 'get', 0)">{lang view_certification_photos}</a>)<!--{/if}--><!--{else}-->{lang profile_no_certified}<!--{/if}--></li>
	 
 
		
		
		<!--{if CURMODULE == 'space'}-->
			<!--{hook/space_profile_baseinfo_middle}-->
		<!--{elseif CURMODULE == 'follow'}-->
			<!--{hook/follow_profile_baseinfo_middle}-->
		<!--{/if}-->
	
			<!--{loop $profiles $value}-->
			<li><em>$value[title]</em>$value[value]</li>
			<!--{/loop}-->
		</ul>
</div> 
<!--{if CURMODULE == 'space'}-->
	<!--{hook/space_profile_baseinfo_bottom}-->
<!--{elseif CURMODULE == 'follow'}-->
	<!--{hook/follow_profile_baseinfo_bottom}-->
<!--{/if}-->

 
 
<div class="space_profile">
	<h2 class="mbn">{lang active_profile}</h2>
	<ul>
		<!--{if $space[adminid]}--><li><em class="xg1">{lang management_team}&nbsp;&nbsp;</em><span style="color:{$space[admingroup][color]}">{$space[admingroup][grouptitle]}</span> {$space[admingroup][icon]}</li><!--{/if}-->
		<li><em class="xg1">{lang usergroup}&nbsp;&nbsp;</em><span style="color:{$space[group][color]}"{if $upgradecredit !== false} class="xi2" onmouseover="showTip(this)" tip="{lang credits} $space[credits], {lang thread_groupupgrade} $upgradecredit {lang credits}"{/if}>{$space[group][grouptitle]}</span> {$space[group][icon]} <!--{if !empty($space['groupexpiry'])}-->&nbsp;{lang group_useful_life}&nbsp;<!--{date($space[groupexpiry], 'Y-m-d H:i')}--><!--{/if}--></li>
		<!--{if $space[extgroupids]}--><li><em class="xg1">{lang group_expiry_type_ext}&nbsp;&nbsp;</em>$space[extgroupids]</li><!--{/if}-->
	 
		<!--{if $space[oltime]}--><li><em>{lang online_time}</em>$space[oltime] {lang hours}</li><!--{/if}-->
		<li><em>{lang regdate}</em>$space[regdate]</li>
		<li><em>{lang last_visit}</em>$space[lastvisit]</li>
		<!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
		<li><em>{lang register_ip}</em>$space[regip] - $space[regip_loc]</li>
		<li><em>{lang last_visit_ip}</em>$space[lastip]:$space[port] - $space[lastip_loc]</li>
		<!--{/if}-->
		<!--{if $space[lastactivity]}--><li><em>{lang last_activity_time}</em>$space[lastactivity]</li><!--{/if}-->
		<!--{if $space[lastpost]}--><li><em>{lang last_post_time}</em>$space[lastpost]</li><!--{/if}-->
		<!--{if $space[lastsendmail]}--><li><em>{lang last_send_email}</em>$space[lastsendmail]</li><!--{/if}-->
		<li><em>{lang time_offset}</em>
			<!--{eval $timeoffset = array({lang timezone});}-->
			$timeoffset[$space[timeoffset]]
		</li>
	</ul>
</div>


<!--{if CURMODULE == 'space'}-->
	<!--{hook/space_profile_extrainfo}-->
<!--{elseif CURMODULE == 'follow'}-->
	<!--{hook/follow_profile_extrainfo}-->
<!--{/if}-->
 
<!--{if $space['uid'] == $_G['uid']}-->
	<div class="btn_exit"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}"  class="dialog">{lang logout_mobile}</a></div>
<!--{/if}-->
</div>





<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

