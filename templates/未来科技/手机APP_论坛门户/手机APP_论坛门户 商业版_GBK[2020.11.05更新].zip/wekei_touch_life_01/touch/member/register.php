<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="vk_login_reg cl">
<!-- header start -->
<div class="login-header">
	<div class="nav">
        <a href="javascript:;" onclick="history.go(-1)" class="z vk_icon_back"></a>
        <span class="name">{lang register}</span>
	</div>
</div>

<!-- registerbox start -->
<div class="loginbox registerbox">
	<div class="login_from">
		<form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}&mobile=2">
		<input type="hidden" name="regsubmit" value="yes" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
		<input type="hidden" name="referer" value="$dreferer" />
		<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
		<input type="hidden" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
		<!--{if $_G['setting']['sendregisterurl']}-->
			<input type="hidden" name="hash" value="$_GET[hash]" />
		<!--{/if}-->
		<ul>
		
		
			<!--{if $sendurl}-->
				<li class="bl_none"><input type="email" tabindex="1" class="px p_fre" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login"></li>
			<!--{else}-->
				<!--{if empty($invite) && $_G['setting']['regstatus'] == 2 && !$invitestatus}-->
					<li><input type="text" tabindex="1" class="px p_fre" size="30" autocomplete="off" value="{lang invite_code}" name="invitecode" placeholder="{lang invite_code}" fwin="login"></li>
				<!--{/if}-->



				<li><input type="text" tabindex="2" autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip}" fwin="login" class="vk_login_name"></li>


				<li><input type="password" tabindex="3" value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password}" fwin="login" class="vk_login_password"></li>
				<li><input type="password" tabindex="4" value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2}" fwin="login" class="vk_login_password"></li>
				<li><input type="email" tabindex="5" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login" class="vk_login_email"></li>


				<!--{if $_G['setting']['regverify'] == 2}-->
					<li><input type="text" name="regmessage" autocomplete="off" tabindex="6" value="{lang register_message}" placeholder="{lang register_message}" fwin="login"></li>
				<!--{/if}-->



				<!--{if empty($invite) && $_G['setting']['regstatus'] == 3}-->
					<li><input type="text" tabindex="7" class="px p_fre" size="30" autocomplete="off" value="{lang invite_code}" name="invitecode" placeholder="{lang invite_code}" fwin="login"></li>
				<!--{/if}-->

				<!-- �����ֶ� -->
				<!--{loop $_G['cache']['fields_register'] $field}-->
					<!--{if $htmls[$field['fieldid']]}-->
						<li class="vk_input_others"><strong>$field[title]</strong> $htmls[$field['fieldid']]</li>	
					<!--{/if}-->
				<!--{/loop}-->
			<!--{/if}-->
	
			
		</ul>
        <!--{hook/register_input}-->
		<!--{if $secqaacheck || $seccodecheck}-->
			<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
	
		<div class="vk_login">
			<div class="btn_login"><button tabindex="7" value="true" name="regsubmit" type="submit" class="formdialog btn_login" type="submit">{lang register}</button></div>
			<div class="reg_link cl"><a href="member.php?mod=logging&action=login">{echo vk_lang('vk_login_quick_login')}</a></div>
		</div>
		</form>
	</div>
</div>

	<div class="vk_login_others cl">
    	<div class="login_title cl">
            <div class="line_left"></div>
            <div class="line_title">{echo vk_lang('vk_login_others')}</div>
            <div class="line_right"></div>
        </div>
        <div class="login_icon cl">
		<!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
    	<a href="$_G[connect][login_url]&statfrom=login_simple" class="login_qq"></a>
		<!--{/if}-->
		
		<!--
		���е������˺ŵ�¼ͼ�����ӣ��ɸ��ݶ�Ӧ�Ĳ��ʵ�������޸ġ�
		�޸ķ�����������a���ӵ� href="javascript:;" �ڵ� javascript:; ��Ϊ�ò���ĵ�¼���ӣ�ͬʱȥ�� onclick="vk_login_alert()" ��δ��롣
		Ȼ���̨����css���� ���ɡ�
		-->
        <a href="plugin.php?id=wechat:login" class="login_weixin" onclick="vk_login_alert()"></a>
        <a href="javascript:;" class="login_weibo" onclick="vk_login_alert()"></a>
        <a href="javascript:;" class="login_phone" onclick="vk_login_alert()"></a>
        </div>
	</div>
	<script>function vk_login_alert() {alert("{echo vk_lang('vk_login_alert')}");}</script>

<!-- registerbox end -->

<!--{eval updatesession();}-->
<!--{template common/footer}-->

