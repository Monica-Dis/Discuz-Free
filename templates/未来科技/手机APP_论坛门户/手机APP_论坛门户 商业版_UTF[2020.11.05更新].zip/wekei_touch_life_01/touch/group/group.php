<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->


<style type="text/css">
	#header { display: none; }
	#page { padding-top: 0px; }
</style>



<!--{if $_G['inajax'] == 1}-->
<!--{template group/group_list}-->
<!--{else}-->


	<!-- 群组页面 头部 - 首页 -->
	<!--{if $action != 'create'}-->
	<!--{else}-->
		<div class="nav">
			<a href="javascript:;" onclick="history.go(-1)"class="z vk_icon_back"></i></a>
			<span class="name">
				{lang group_create_new}
			</span>
		</div>
	<!--{/if}-->


	<div class="vk_group">
		<div class="cl">
			<!--{if $action != 'create'}-->
                <div class="vk_group_thread_header" {if $_G['forum']['banner']} style="background:url($_G[forum][banner]) no-repeat; background-size:cover;"{else}style="background:#0ad"{/if}>
                    <div class="vk_group_bg_cover"></div>
					
	
					<!-- 群组页面 头部 - 每个群组的内部页-->
					<div class="nav">
						<a href="javascript:;" onclick="history.go(-1)"class="z vk_icon_back"></i></a>
						<!--{if $_G['uid']}-->
							<!--{eval $favid = DB::result_first('SELECT count(*) FROM '.DB::table('home_favorite').' WHERE id='.$_G[forum][fid].' and uid='.$_G[uid].'');}-->
						<!--{else}-->
							<!--{eval $favid = 0;}-->
						<!--{/if}-->
						<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="y vk_nologin vk_icon_edit"></i></a>
						<a href="home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}" class="y fav">{if $favid}<i class="vk_icon_fav_on"></i>{else}<i class="vk_icon_fav"></i>{/if}</a>
					</div>

					
					
					<div {if $_G['forum']['banner']}class="group_icon new"{else}class="group_icon"{/if}>
						<img src="$_G[forum][icon]" alt="$_G[forum][name]" width="48" height="48" />
					</div>
					<h2>$_G[forum][name]</h2>
					<div class="cl">
					<p>
						{lang group_moderator_title}: <!--{eval $i = 1;}--><!--{loop $groupmanagers $manage}--><!--{if $i <= 0}-->, <!--{/if}--><!--{eval $i--;}-->$manage[username] <!--{/loop}-->
					</p>
					<!--{if helper_access::check_module('group') && $status != 'isgroupuser'}-->
						<a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="vk_nologin join dialog">{lang group_join_group}</a>
					<!--{/if}-->
					<!--{if $status == 'isgroupuser'}-->
						<a href="forum.php?mod=group&action=out&fid=$_G[fid]" class="join_on dialog">{lang group_exit}</a>
					<!--{/if}-->
					</div>
					<div class="vk_water_wide"></div>
					
                 </div>
				
				<!--{if $status != 2 && $status != 3}-->
			  	<div {if $_G['forum']['ismoderator']}class="tb"{else}class="tb tb_mod"{/if}>
					<ul id="groupnav">
						<li {if ($action != 'memberlist') && ($action != 'invite') && ($action != 'manage')}class="a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]" title="">{lang group_discuss_area}</a></li>
						<li {if $action == 'memberlist' || $action == 'invite'}class="a"{/if}><a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]" title="">{lang group_member_list}</a></li>
						<!--{if $_G['forum']['ismoderator']}--><li {if $action == 'manage'}class="a"{/if}><a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang group_admin}</a></li><!--{/if}-->
						<!--{if CURMODULE == 'group'}--><!--{hook/group_nav_extra}--><!--{else}--><!--{hook/forumdisplay_nav_extra}--><!--{/if}-->
					</ul>
				</div>
				<!--{/if}-->
			<!--{/if}-->





			<!--{if $action == 'index' && $status != 2 && $status != 3}-->
				<!--{template group/group_index}-->
			<!--{elseif $action == 'list'}-->
			
            <div style="position: relative;">
    			<div class="vk_group_threadlist cl">
                    		<!--{if $_G['forum_threadcount']}-->
								<!--{template group/group_list}-->
							<!--{else}-->
                        		<div class="emp cl"><p>{lang forum_nothreads}</p></div>
                    		<!--{/if}-->
    			</div>
			</div>
	
            <!--{if $_G[forum][threads] && ($_G[forum][threads] > $_G[tpp])}-->
			
				<!--{if helper_access::check_module('group')}-->
				<div class="bm bw0 pgs cl">
					$multipage
				<!--
					<span {if $_G[setting][visitedforums]}id="visitedforums" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id})"{/if} class="pgb y"><a href="forum.php?mod=group&fid=$_G[fid]">{lang return_index}</a></span>
				-->
				</div>
				
				
				<!--{/if}-->
		
            <!--{/if}-->






			<!--{elseif $action == 'memberlist'}-->
				<!--{template group/group_memberlist}-->
			<!--{elseif $action == 'create'}-->
				<!--{template group/group_create}-->
			<!--{elseif $action == 'invite'}-->
				<!--{template group/group_invite}-->
			<!--{elseif $action == 'manage'}-->
				<!--{template group/group_manage}-->
			<!--{/if}-->
			
			
		</div>
		
	</div>
    

<!--{/if}-->
<!--{template common/footer}-->