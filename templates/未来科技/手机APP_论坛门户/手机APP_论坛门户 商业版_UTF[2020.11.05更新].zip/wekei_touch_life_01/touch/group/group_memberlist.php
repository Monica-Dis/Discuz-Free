<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $op == 'alluser'}-->
	<!--{if $adminuserlist}-->
		<div class="vk_group_member">
			<h2>{lang group_admin_member}</h2>
			<div class="cl">
				<ul>
					<!--{loop $adminuserlist $user}-->
					<li>
						<a href="home.php?mod=space&uid=$user[uid]" title="">
							<!--{echo avatar($user[uid], 'middle')}-->
						</a>
						<p><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a><!--<span>{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}</span>--></p>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	<!--{/if}-->
	<!--{if $staruserlist || $alluserlist}-->
		<div class="vk_group_member">
			<h2>{lang member}</h2>
			<div class="cl">
				<!--{if $alluserlist}-->
					<ul>
						<!--{if $staruserlist}-->
						<!--{loop $staruserlist $user}-->
						<li>
							<a href="home.php?mod=space&uid=$user[uid]" title="" class="avt" >
							<!--{echo avatar($user[uid], 'middle')}--></a>
							<p><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a><!--<span>{lang group_star_member_title}{if $user['online']} {lang login_normal_mode}{/if}</span>--></p>
						</li>
						<!--{/loop}-->
						<!--{/if}-->

						<!--{loop $alluserlist $user}-->
						<li>
							<a href="home.php?mod=space&uid=$user[uid]" title="" class="avt">
							<!--{echo avatar($user[uid], 'middle')}--></a>
							<p><a href="home.php?mod=space&uid=$user[uid]">$user[username]</a><!--<span>{lang group_star_member_title}{if $user['online']} {lang login_normal_mode}{/if}</span>--></p>
						</li>
						<!--{/loop}-->
					</ul>
				<!--{/if}-->
			</div>
		</div>
	<!--{/if}-->
	<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->