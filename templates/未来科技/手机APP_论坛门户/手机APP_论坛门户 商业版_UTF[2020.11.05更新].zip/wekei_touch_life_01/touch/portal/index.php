<?php exit; ?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>


<!-- 顶部导航、幻灯 用到的css、js文件 -->
<link href="$_G['style']['styleimgdir']/touch/css/swiper.min.css" rel="stylesheet" />
<script src="$_G['style']['styleimgdir']/touch/css/swiper.min.js?{VERHASH}"></script> 




<!--
二级文字导航 - 左右切换样式
-->

<!-- 二级导航固定样式
<div class="swiper-container-nav" id="topNav" style=" display:block; width:100%; height: 50px; position:fixed; top:44; z-index:99; border-top:1px solid #eee; background:#fff;">
-->

<div class="swiper-container-nav" id="topNav">
  <div class="swiper-wrapper">
  		<div class="swiper-slide active"><span>推荐</span></div>
		<div class="swiper-slide"><span>热榜</span></div>
		<div class="swiper-slide"><span>美女</span></div>
		<div class="swiper-slide"><span>房产</span></div>
		<div class="swiper-slide"><span>汽车</span></div>
		<div class="swiper-slide"><span>娱乐</span></div>
	</div>
</div>





<!--
二级文字导航 对应的模块
-->
<div class="swiper-container-page" id="topNav_page">
	<div class="swiper-wrapper" >
	
	
	
		<!-- 模块"推荐"下的block调用 -->
		<div class="swiper-slide  swiper-slide-active">
		

			<!-- 幻灯 调用代码 -->
			<div class="vk_wp" style="margin-top: 0px; overflow: hidden;">
				<!--{block/100000}-->
			</div>
			

			<!-- 公告/头条 调用代码 -->
			<div class="vk_wp" style="margin-top: 0px;">
				<div class="vk_diy_news_top">
					<div class="diy_left_icon"></div>
					<div class="diy_right_div">
					<!--{block/100000}-->
					</div>
				</div>
			</div>
			
			

			<!-- 版块调用 -->
			<div class="vk_wp">
				<!--{block/100000}-->
			</div>
			
			

			<!-- 图文 调用 - 下标题，上图片 - 部分显示，左右切换 -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_rec"><a href="#" target="_blank">美图推荐</a></h2>
					<ul>
						<li><a href="#" target="_blank" class="more_rec"> 查看更多 </a></li>
					</ul>
				</div>
				<div class="p_l_15">
				<!--{block/100000}-->
				</div>
			</div>
			

			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_0.jpg" />
					</a>
				</div>
			</div>
			

			<!-- 帖子图文 调用 -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_hot"><a href="#" target="_blank">热帖</a></h2>
					<ul>
						<li><a href="#" target="_blank" > 美女 </a></li>
						<li><a href="#" target="_blank" > 科技 </a></li>
						<li><a href="#" target="_blank" > 娱乐 </a></li>
						<li><a href="#" target="_blank" > 更多 > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			

			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_1.jpg" />
					</a>
				</div>
			</div>



			<!-- 帖子图文 调用 -->
			<div class="wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_car"><a href="#" target="_blank">汽车</a></h2>
					<ul>
						<li><a href="#" target="_blank" > 更多 > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			
			

			<!-- 广/告 -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_2.jpg" />
					</a>
				</div>
			</div>



			<!-- 帖子图文 调用 -->
			<div class="wp">
				<div class="vk_diy_title m_b_0">
					<h2 class="vk_title_house"><a href="#" target="_blank">房产楼市</a></h2>
					<ul>
						<li><a href="#" target="_blank" > 更多 > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			

			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_4.jpg" />
					</a>
				</div>
			</div>



			<!-- 帖子图文 调用 -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_baby"><a href="#" target="_blank">母婴亲子</a></h2>
					<ul>
						<li><a href="#" target="_blank" > 更多 > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			
			

			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_5.jpg" />
					</a>
				</div>
			</div>



			<!-- 帖子图文 调用 -->
			<div class="wp">
				<div class="vk_diy_title m_b_0">
					<h2 class="vk_title_edu"><a href="#" target="_blank">教育培训</a></h2>
					<ul>
						<li><a href="#" target="_blank" > 更多 > </a></li>
					</ul>
				</div>
				<!--{block/100000}-->
			</div>
			
			
			
			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_6.jpg" />
					</a>
				</div>
			</div>
			
			

			<!-- 首页 帖子点击加载 开始  -->
			<div class="vk_wp">
				<div class="vk_diy_title">
					<h2 class="vk_title_forum"><a href="#" target="_blank">最新动态</a></h2>
					<ul>
						<li><a href="#" target="_blank" > 最新 </a></li>
						<li><a href="#" target="_blank" > 热门 </a></li>
						<li><a href="#" target="_blank" > 推荐 </a></li>
					</ul>
				</div>

				<!-- 下面这一行是调用的需要显示的版块ID，可以根据需要把里面的数字换为需要显示的版块ID即可 -->
				<!--{eval $fids = '2,37,38,39,40,41,42'}--> 

				<!--{eval $postlist = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." WHERE `displayorder` = 0 AND isgroup = '0' AND `fid` in ($fids) ORDER BY `dateline` DESC limit 0 , 100");}-->

				<div class="vk_threadlist" style=" margin-top: -10px; border-top: none;">
					<!--{loop $postlist $post_list}-->
					<!--{eval $piclist = substr($post_list[tid], -1); $pic_list = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$piclist.'')." WHERE `tid`= $post_list[tid] AND isimage = '1' ORDER BY `dateline` DESC limit 0 , 9");}-->
					<!--{eval $picnum = count($pic_list);}-->

					<article class="vk_load_list"> 

						<div class="vk_title_div">
							 <a href="forum.php?mod=viewthread&tid=$post_list[tid]" class="vk_thread_title" title="$post_list[subject]">$post_list[subject]</a>
						</div>

						<div class="vk_thread_pic cl"> 
							 <!--{loop $pic_list $key $vk_thread_pic}-->
							 <!--{eval $piclist = getforumimg($vk_thread_pic[aid], 0, 240, 160); }-->			
								<div class="item_pic"><a href="forum.php?mod=viewthread&tid=$post_list[tid]"><p class="col_3_$key"><span class="col_3_img"><img src="$piclist"></span></p></a></div>
							 <!--{/loop}-->					
						</div>

						<div class="vk_author_info cl">
							  <a href="home.php?mod=space&uid=$post_list[authorid]" class="vk_author" target="_blank"><img src="uc_server/avatar.php?uid=$post_list[authorid]&amp;size=middle" alt="$post_list[author]" class="vk_avt">$post_list[author]</a>
							  <a class="vk_time"><!--{echo dgmdate($post_list[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></a>       
							  <span class="vk_reply">{$post_list[replies]}</span>
							  <span class="vk_view">{$post_list[views]}</span>
						</div>

					</article>

					<!--{/loop}-->

					<div class="vk_load_more">
						<a href="javascript:;">查看更多 ... </a>
					</div>
				</div>
				<!-- 需要引用 jquery.min.js。如果 head文件引用过，此处可忽略 -->
				<script type="text/javascript">
					jQuery(function (){
						showItem(0, 10);
						var itemNum = 10; 

						jQuery('.vk_load_more').click(function(){
							if(itemNum < 100){
								showItem(itemNum, itemNum += 20);
							} else {
								location.href = 'portal.php?mod=list&catid=1';
							}
						});  	

						function showItem(fromindex,toindex){
							var len = jQuery('.vk_load_list').length;
							for(var i = fromindex; i < toindex ; i++ ){
								jQuery('.vk_load_list').eq(i).css('display','block');
							}
						} 

					})
				</script>

			</div>
			<!-- 首页 帖子点击加载 结束  -->

			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_7.jpg" />
					</a>
				</div>
			</div>

		</div>








		<!-- 模块“热榜”下的block调用 -->
		<div class="swiper-slide">
			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_7.jpg" />
					</a>
				</div>
			</div>
			<div class="vk_wp m_t_0">
				<!--{block/100000}-->
			</div>
		</div>




		<!-- 模块“美女”下的block调用 -->
		<div class="swiper-slide">
			<div class="wp m_t_0">
				<!--{block/100000}-->
			</div>
		</div>
		
		
		

		<!-- 模块“房产”下的block调用 -->
		<div class="swiper-slide">
			<!-- 广/告 -->
			<div class="vk_wp m_t_0">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_2.jpg" />
					</a>
				</div>
			</div>
			<div class="wp">
				<!--{block/100000}-->
			</div>
		</div>
		
		
		

		<!-- 模块“汽车”下的block调用 -->
		<div class="swiper-slide">
			<!-- 广/告 -->
			<div class="vk_wp">
				<div class="vk_index_a_d cl">
					<a href="portal.php?mod=index">
						<span>推/广</span>
						<img src="$_G['style']['styleimgdir']/touch/img/a_d/vk_index_a_d_7.jpg" />
					</a>
				</div>
			</div>
			<div class="wp">
				<!--{block/100000}-->
			</div>
		</div>
		
		
		

		<!-- 模块“娱乐”下的block调用 -->
		<div class="swiper-slide">
			<div class="wp m_t_0">
				<!--{block/100000}-->
			</div>
		</div>
		
		

	</div>
</div>





<script type="text/javascript">
var mySwiper = new Swiper('#topNav', {
	freeMode: true,
	freeModeMomentumRatio: 0.5,
	slidesPerView: 'auto',
	roundLengths : true,
});

swiperWidth = mySwiper.container[0].clientWidth
maxTranslate = mySwiper.maxTranslate();
maxWidth = -maxTranslate + swiperWidth / 2

$(".swiper-container").on('touchstart', function(e) {
	e.preventDefault()
})

mySwiper.on('tap', function(swiper, e) {
//    console.log(swiper.clickedIndex)
    pageSwiper.slideTo(swiper.clickedIndex, 1000, false);//跳转
//	e.preventDefault()
	slide = swiper.slides[swiper.clickedIndex]
	slideLeft = slide.offsetLeft
	slideWidth = slide.clientWidth
	slideCenter = slideLeft + slideWidth / 2
    console.log("slideLeft:"+slideLeft)
    console.log("maxWidth:"+maxWidth)
    console.log("slideCenter:"+slideCenter)
	// 被点击slide的中心点
	mySwiper.setWrapperTransition(300)
	if (slideCenter < swiperWidth / 2) {
		mySwiper.setWrapperTranslate(0)
	} else if (slideCenter > maxWidth) {
		mySwiper.setWrapperTranslate(maxTranslate)
	} else {
		nowTlanslate = slideCenter - swiperWidth / 2
		mySwiper.setWrapperTranslate(-nowTlanslate)
	}
	$("#topNav .active").removeClass('active')
	$("#topNav .swiper-slide").eq(swiper.clickedIndex).addClass('active')

})
</script>



<script>
    var pageSwiper = new Swiper('#topNav_page', {
        paginationClickable: true,
        uniqueNavElements :false,
		roundLengths : true,
        onSlideChangeStart: function(swiper){
//            console.log(swiper.activeIndex)
//            mySwiper.slideTo(swiper.activeIndex, 1000, false);
            $("#topNav .active").removeClass('active')
            $("#topNav .swiper-slide").eq(swiper.activeIndex).addClass('active')

            slide = mySwiper.slides[swiper.activeIndex];//获取当前的slide节点
            slideLeft = slide.offsetLeft
            slideWidth = slide.clientWidth
            slideCenter = slideLeft + slideWidth / 2
            // 被点击slide的中心点
            console.log("============")
            console.log("slideLeft:"+slideLeft)
            console.log("maxWidth:"+maxWidth)
            console.log("slideCenter:"+slideCenter)
            console.log("swiperWidth / 2:"+swiperWidth / 2)
            mySwiper.setWrapperTransition(300)
            if (slideCenter < swiperWidth / 2) {
                mySwiper.setWrapperTranslate(0)
            } else if (slideCenter >maxWidth) {
                mySwiper.setWrapperTranslate(maxTranslate)
                console.log("maxTranslate:"+maxTranslate)
            } else {
                nowTlanslate = slideCenter - swiperWidth / 2
                console.log(nowTlanslate)
                mySwiper.setWrapperTranslate(-nowTlanslate)
            }
        }
    });
</script>









<div class="pullrefresh" style="display:none;"></div>

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>

<!--{template common/footer}-->
