<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{subtemplate common/header_common}-->
	<meta name="application-name" content="$_G['setting']['bbname']" />
	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? $_G['scheme'].'://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? $_G['scheme'].'//'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? $_G['scheme'].'://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? $_G['scheme'].'://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
	<!--{/if}-->
	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
	<!--{if widthauto()}-->
		<link rel="stylesheet" id="css_widthauto" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_widthauto.css?{VERHASH}' />
		<script type="text/javascript">HTMLNODE.className += ' widthauto'</script>
	<!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'home'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'portal'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<link rel="stylesheet" type="text/css" id="diy_common" href="{$_G['setting']['csspath']}{STYLEID}_css_diy.css?{VERHASH}" />
	<!--{/if}-->
	
		<meta http-equiv="X-UA-Compatible" content="IE=8" >
		<meta http-equiv="X-UA-Compatible" content="IE=9" >
		<meta http-equiv="X-UA-Compatible" content="IE=edge" >
		<script>if (top.location != self.location) top.location=self.location;</script>
		<script>window.onerror=function(){return true;}</script>
		
		
		<!-- ҳ�涯̬�����õ��Ĵ��� -->
		<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/css/animate.min.css" />
		<script type="text/javascript" src="{$_G['style']['styleimgdir']}/js/wow.min.js"></script>
        <script>new WOW().init();</script>
 		
		<!-- ����¼�Ч������ -->
		<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/css/hover-min.css" />



</head>



<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if}" onkeydown="if(event.keyCode==27) return false;">

	<div id="append_parent"></div>
	<div id="ajaxwaitid"></div>
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}--> 
	<!--{template common/header_diy}--> 
	<!--{/if}--> 
	<!--{if check_diy_perm($topic)}--> 
	<!--{template common/header_diynav}--> 
	<!--{/if}--> 
	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}--> 
	$diynav 
	<!--{/if}--> 
	<!--{if empty($topic) || $topic['useheader']}--> 
	<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
	<div class="xi1 bm bm_c"> {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a> </div>
	<!--{/if}--> 
	<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
	<div id="shortcut"> <span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span> {lang shortcut_notice} <a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a> </div>
	<script type="text/javascript">setTimeout(setShortcut, 2000);</script> 
	<!--{/if}-->



<div class="top_head wp">
	<!--{hook/global_cpnav_top}-->
	<div class="wp vk_top_other ">
	<!--{hook/global_cpnav_extra1}-->
	<!--{hook/global_cpnav_extra2}-->
	</div>

	<!--{ad/headerbanner/wp a_h}-->


	<div id="hd">
		<div class="hdc cl"> 

			<!--{eval $mnid = getcurrentnav();}-->
			<div class="vk_logo">
			<!--{if !isset($_G['setting']['navlogos'][$mnid])}-->
			<a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]
			<!--{/if}-->
			</div>

			<div id="nv">
				<ul>
					<!--{loop $_G['setting']['navs'] $nav}--> 
					<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->
					<li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li>
					<!--{/if}--> 
					<!--{/loop}-->
				</ul>
				<!--{hook/global_nav_extra}--> 
			</div>
			
			<!-- �Ҳ�ģ�� -->
			<div class="vk_avt_nav">


				<div > 
				
					<!-- ����ģ�� �����ͣ���Ӧ������ģ���ļ��� vk_top_search_pop.php -->
					<div class="vk_top_search_pop"><a href="search.php?mod=forum" title="{lang search}"></a>
						<div class="vk_top_search_pop_div">
							<!--{subtemplate common/vk_top_search_pop}--> 
						 </div>
					</div>


					<!-- ͷ�� �Լ������˵� -->
					<!--{if $_G['uid']}-->
					<div class="left">
						<a class="top_avt" href="home.php?mod=space&uid=$_G[uid]" id="qmenu" onMouseOver="showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2}); showForummenu($_G[fid]);"><!--{avatar($_G[uid],small)}--></a> <a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}"> </a>
					</div>

					<div class="vk_top_other_indent">
						<!--{hook/global_myitem_extra}-->
					</div>



				  <!-- δ��¼״̬ -->
				  <!--{else}--> 
				  
					<div class="left">
						<a class="top_avt top_avt_default" href="javascript:;" id="qmenu" onMouseOver="showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2}); showForummenu($_G[fid]);"><img src="<!--{avatar($_G[uid], big, true)}-->" /> </a> 
					</div>
				  
				  <!--{/if}--> 


				</div>

				<!--{if !IS_ROBOT}--> 
				<!-- ��ݵ��� �����˵� -->
				<!--{subtemplate common/header_qmenu}--> 
				<!--{/if}--> 


			</div>




			<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
			<ul class="p_pop h_pop" id="plugin_menu" style="display:none;">
				<!--{loop $_G['setting']['plugins']['jsmenu'] $module}--> 
				<!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
				<li>$module[url]</li>
				<!--{/if}--> 
				<!--{/loop}-->
			</ul>
			<!--{/if}--> 
			$_G[setting][menunavs]


		</div>

	</div>




	<!--{hook/global_header}--> 
	<!--{/if}-->
</div>










<div id="wp" class="wp">





	<!--{if $_G['setting']['subnavs']}-->
	<div id="mu" class="cl"> 
		<!--{loop $_G[setting][subnavs] $navid $subnav}--> 
		<!--{if $_G['setting']['navsubhover'] || $mnid == $navid}-->
		<ul class="cl {if $mnid == $navid}current{/if}" id="snav_$navid" style="display:{if $mnid != $navid}none{/if}">
		$subnav
		</ul>
		<!--{/if}--> 
		<!--{/loop}--> 
	</div>
	<!--{/if}--> 
	<!--{ad/subnavbanner/a_mu}--> 


