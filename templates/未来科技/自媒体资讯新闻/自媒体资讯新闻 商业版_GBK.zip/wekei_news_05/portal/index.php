<?php exit;?>

<!--{template common/header}-->

<style id="diy_style" type="text/css"></style>



<!--  �ϲ����ͼƬռλ   -->
<div class="wp ">
  		<!--[diy=diy_vk_ad_top]--> <div id="diy_vk_ad_top" class="area"></div><!--[/diy]--> 
</div>


<div class="wp vk_diy col_2-1 m_t_15 ">
      
    <!--�õ�Ƭģ��--> 
	<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/js/swiper.min.css" />
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/js/swiper.min.js"></script>
    <div class="col_2-1_l m_b_0 ">
      <div class="vk_portal_slide_top vk_float"  style="height:350px; width:875px; float:left; clear:both;"> 
      <!--[diy=diy_vk_portal_slide_top]-->  <div id="diy_vk_portal_slide_top" class="area"> </div>  <!--[/diy]-->
      </div>
    </div>
    <!--�õ�Ƭģ��--> 

    <!-- �ϲ��Ҳ�ģ�� start-->
    <div class="col_2-1_r  col_vk_title vk_wechat_wp m_b_0" >
    	<div id="vk_wechat" class="vk_wechat"></div>
    	<div id="vk_phone_icon" class="vk_phone_icon"></div>
    	<div class="vk_side_icon_4 "  >
        	<a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="vk_side_icon_4_1 left animated swing hvr-wobble-horizontal" > Ͷ�� </a>
        	<a href="#" class="vk_side_icon_4_2 left animated swing hvr-wobble-horizontal" 
            onmouseover="document.getElementById('vk_phone_icon').style.display='block';"
            onmouseout="document.getElementById('vk_phone_icon').style.display='none'"
            > �ֻ��� </a>
        	<a href="#" class="vk_side_icon_4_3 left animated swing hvr-wobble-horizontal" > ����΢�� </a>
        	<a href="#" class="vk_side_icon_4_4 right m_r_0 animated swing hvr-wobble-horizontal"  
            onmouseover="document.getElementById('vk_wechat').style.display='block';"
            onmouseout="document.getElementById('vk_wechat').style.display='none'"
             > ����ƽ̨ </a>
        </div>
		
    	<div class="vk_index_top_post_hot hvr-wobble-bottom"> <a class="" href="#" > ר������ </a> </div>
    	<div class="vk_index_top_post cl">
        	<a href="#" class="left hvr-wobble-top" > Office���� </a>
        	<a href="#" class="right hvr-wobble-top" > ǰ�˿��� </a>
        	<a href="#" class="left hvr-wobble-top" > Android ���� </a>
        	<a href="#" class="right hvr-wobble-top" > iOS���� </a>
        	<a href="#" class="left hvr-wobble-top" > ��Ϸ���� </a>
        	<a href="#" class="right hvr-wobble-top" > ƽ����� </a>
        	<a href="#" class="left hvr-wobble-top" > ��Ʒ��Ӫ </a>
        	<a href="#" class="right hvr-wobble-top" > ����Ӫ�� </a>
        </div>
		
    </div>
    <!-- �ϲ��Ҳ�ģ�� end -->

</div>




<!--  ��ҳ ȫ��������ռλ  -->
<div class="wp  vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_1]--> <div id="diy_vk_ad_1" class="area"></div><!--[/diy]--> 
</div>





<div class="wp vk_diy col_2-1_page">
      
	<!-- ���ģ�� -->
    <div class="vk_col col_2-1_l_page wow animated fadeInUp">

		<!-- tab ģ�� -->
		<div class="wp m_b_20 vk_tab_index_left bg_none">
			<!--[diy=diy_vk_tab]--> <div id="diy_vk_tab" class="area"></div><!--[/diy]--> 
		</div>

			<!-- DIY��ҳģ�� -->
			<!-- 
			��ʾ�ܸ�����DIYģ�������ﶨ��
			perPage:10  ÿҳ��ʾ����������DIYģ��ʱ�����õ����»����Ӹ���һ��Ҫ������������Ż��ҳ
			scrollTop:540 ����ڶ�ҳʱ,�Զ����붥���ĸ߶Ȳ���
			-->
			<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jPages.js"></script>
			<script type="text/javascript">
				jQuery(function() {jQuery("div.holder").jPages({containerID: "hiddenresult",perPage:10,previous: "��һҳ",next: "��һҳ"});});
				jQuery(function(){ jQuery("div.holder").click(function(){ jQuery('html,body').animate({scrollTop:540},0); return false; });});
			</script> 
		
    </div>
	
	
	
    <!-- �Ҳ�ģ�� -->
	<div class="col_2-1_r_page  wow animated fadeInUp">
		

		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> һ�ܾ�ѡ </a>  
			</h2>

			<div class=" ">
				<!--[diy=diy_vk_guide_1_r]--> <div id="diy_vk_guide_1_r" class="area"></div><!--[/diy]--> 
				<!--[diy=diy_vk_guide_1_r_ad]--> <div id="diy_vk_guide_1_r_ad" class="area"></div><!--[/diy]--> 
			</div>
		</div>
		
		
		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> ����ר�� </a>  
			</h2>

			<div class=" ">
			<!--[diy=diy_vk_guide_1_r_2]--> <div id="diy_vk_guide_1_r_2" class="area"></div><!--[/diy]--> 
			</div> 
		</div>
		
		
		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> ʵʱ��Ѷ </a>  
			</h2>

			<div class=" ">
			<!--[diy=diy_vk_guide_2_1_0]--> <div id="diy_vk_guide_2_1_0" class="area"></div><!--[/diy]--> 
			</div>
		</div>
		
		
		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> ������� </a>  
			</h2>

			<div class=" ">
			<!--[diy=diy_vk_guide_2_1_1]--> <div id="diy_vk_guide_2_1_1" class="area"></div><!--[/diy]--> 
			</div>
		</div>
		
		
		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> �����Ƽ� </a>  
			</h2>

			<div class=" ">
				<!--[diy=diy_vk_news_1_r]--> <div id="diy_vk_news_1_r" class="area"></div><!--[/diy]--> 
			</div> 
		</div>
		
		
    </div>
	
</div>
  
  

<!--  ��ҳ ȫ��������ռλ 5  -->
<div class="wp vk_diy">
  		<!--[diy=diy_vk_ad_5]--> <div id="diy_vk_ad_5" class="area"></div><!--[/diy]--> 
</div>



<div class="wp  m_b_15">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>





<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

