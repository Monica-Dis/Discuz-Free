<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<div id="qmenu_menu" class="p_pop {if !$_G['uid']}blk{/if}" style="display: none;">


	<!-- 未登录、QQ账号登录但未绑定账号 状态 -->
	<!--{if $_G['uid']}-->
	<!--{elseif !empty($_G['cookie']['loginuser'])}--> 
    <div class="vk_top_in_qmenu cl m_b_20">
		<strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong> <span class="pipe">|</span><a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang activation}</a> <span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a> 
		<!--{elseif !$_G[connectguest]}--> 
		<div style="display:inline;  position:relative; width:250px; display: none;">
		<!--{hook/global_login_extra}--> 
		</div>

		<div class="vk_top_login cl">
		<ul>
		<li class="vk_top_reg"><a href="member.php?mod={$_G[setting][regname]}"  title="注册" >注册</a> </li>
		<li class="vk_top_log"><a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" onClick="showWindow('login', this.href);return false;"  title="{lang login}" > {lang login} </a>
		</li>
		</ul>

		<ul class="vk_top_login_ul">
			<li class="vk_top_login_qq"><a href="connect.php?mod=login&amp;op=init&amp;referer=index.php&amp;statfrom=login_simple" target="_blank">QQ登录</a></li>
			<li class="vk_top_login_wechat"><a href="plugin.php?id=wechat:login" target="_blank">微信登录</a></li>

			<li><a class="top_find_psw" href="javascript:;" onClick="showWindow('login', 'member.php?mod=logging&action=login&viewlostpw=1')"> {lang forgotpw} </a></li>
		</ul>

		</div>
		<!--{else}--> 

		<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="vk_inline">{lang logout}</a> <strong class="vwmy qq">{$_G[member][username]}</strong> {lang usergroup}: $_G[group][grouptitle] 
	</div>
	<!--{/if}--> 
	
	


	
	
	
	<!--{if $_G['uid']}-->
	<!-- 设置、管理 模块 -->
    <div class="vk_top_in_qmenu cl m_b_10">
		
		<!--  门户管理、管理中心 下拉菜单 位置，现在移出下拉菜单，单独显示 -->
		<div class="list_manage">
			<dt class="vk_title">
				<!-- 宽窄屏切换 图标 -->
				<!--{if empty($_G['disabledwidthauto']) && $_G['setting']['switchwidthauto']}--> 
				<a href="javascript:;" id="switchwidth" onClick="widthauto(this)" title="{if widthauto()}{lang switch_narrow}{else}{lang switch_wide}{/if}" class="switchwidth"><!--{if widthauto()}-->{lang switch_narrow}<!--{else}-->{lang switch_wide}<!--{/if}--></a>
				<!--{/if}--> 
			</dt>
				<dd class="cl">
				<ul>
				<!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
				<li><a class="vk_top_manage_portal" href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
				<!--{/if}--> 
				<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
				<li><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>
				<!--{/if}--> 
				<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
				<li><a href="admin.php" target="_blank">{lang admincp}</a></li>
				<!--{/if}--> 
				<li class="diy"><!--{if check_diy_perm($topic)}-->$diynav<!--{/if}--></li>
				
				<!--{hook/global_usernav_extra4}-->
				</ul>
			</dd>
		</div>
			  
	</div>
	<!--{/if}-->
	
	
	<!--{if $_G['uid']}-->
	<!-- 我的 消息、积分、收藏、好友等 -->
    <div class="vk_top_in_qmenu cl">
		<div class="list">
			<dl style="border-bottom: none;">
				<dt class="vk_title">我的</dt>
				<dd class="cl">
				<ul>
				<li><a href="forum.php?mod=guide&view=my">{lang mypost}</a></li>
				<li><a href="home.php?mod=space&do=favorite&view=me">{lang favorite}</a></li>
				<li><a href="home.php?mod=space&do=friend">{lang friends}</a></li>
				<li><a href="home.php?mod=spacecp&ac=credit&showcredit=1" >{lang credits}: $_G[member][credits]</a></li>
				<!--{if $_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])}-->
				<li><a href="home.php?mod=task&item=doing" id="task_ntc" class="new">{lang task_doing}</a></li>
				<!--{/if}--> 
				<li><!--{hook/global_usernav_extra1}--></li>
				<li><!--{hook/global_usernav_extra2}--></li>
				<li><!--{hook/global_usernav_extra3}--></li>
				</dd>
				
				<dd class="cl">
				<ul>
				<li><a href="home.php?mod=spacecp">{lang setup}</a></li>
				<li><a href="home.php?mod=spacecp&ac=usergroup" > $_G[group][grouptitle]</a></li>
				<li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
				<!--{hook/global_myitem_extra}-->
				</ul>
				</dd>
				
			</dl>
		</div>
	</div>
	<!--{/if}-->
	
	
	<!--{if $_G['uid']}-->
	<!-- 消息、提醒 模块 -->
    <div class="vk_top_in_qmenu cl">
		<div class="list">
			<dl style="border-bottom: none;">
				<dt class="vk_title">消息</dt>
				<dd class="cl">
				<ul>
				<li><a href="home.php?mod=space&do=notice" id="myprompt"{if $_G[member][newprompt]} class="new"{/if} onMouseOver="showMenu({'ctrlid':'myprompt'});">{lang remind}<!--{if $_G[member][newprompt]}-->($_G[member][newprompt])<!--{/if}--></a>
				<span id="myprompt_check"></span>
				<!--{if empty($_G['cookie']['ignore_notice']) && ($_G[member][newpm] || $_G[member][newprompt_num][follower] || $_G[member][newprompt_num][follow] || $_G[member][newprompt])}--><script language="javascript">delayShow($('myprompt'), function() {showMenu({'ctrlid':'myprompt','duration':3})});</script><!--{/if}-->
				</li>
				
				<li><a href="home.php?mod=space&do=pm" id="pm_ntc" style="background-repeat: no-repeat; background-position: 0 50%;"><em class="prompt_news{if empty($_G[member][newpm])}_0{/if}"></em>{lang pm_center}</a></li>
				<li><a href="home.php?mod=follow&do=follower"><em class="prompt_follower{if empty($_G[member][newprompt_num][follower])}_0{/if}"></em><!--{lang notice_interactive_follower}-->{if $_G[member][newprompt_num][follower]}($_G[member][newprompt_num][follower]){/if}</a></li>


				<!--{if $_G[member][newprompt] && $_G[member][newprompt_num][follow]}-->
				<li><a href="home.php?mod=follow"><em class="prompt_concern"></em><!--{lang notice_interactive_follow}-->($_G[member][newprompt_num][follow])</a></li>
				<!--{/if}--> 
				<!--{if $_G[member][newprompt]}--> 
				<!--{loop $_G['member']['category_num'] $key $val}-->
				<li><a href="home.php?mod=space&do=notice&view=$key"><em class="notice_$key"></em><!--{echo lang('template', 'notice_'.$key)}-->(<span class="rq">$val</span>)</a></li>
				<!--{/loop}--> 
				<!--{/if}--> 
				<!--{if empty($_G['cookie']['ignore_notice'])}-->
				<li class="ignore_noticeli"><a href="javascript:;" onClick="setcookie('ignore_notice', 1);hideMenu('myprompt_menu')" title="{lang temporarily_to_remind}"><em class="ignore_notice"></em></a></li>
				<!--{/if}-->
				
				
				</ul>
				</dd>
			</dl>
		</div>
	</div>
	<!--{/if}-->
	
	
	
  <!-- 自定义链接 -->
    <div class="vk_top_in_qmenu cl  <!--{if empty($_G['style']['extstyle'])}--> m_b_20<!--{/if}--> ">
		<div class="list">
			<dl>
				<dt class="vk_title">链接</dt>
				<dd class="cl">
				<ul>
				<li>
			  <!--{loop $_G['setting']['topnavs'][0] $nav}--> 
			  <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}--> 
			  <!--{/loop}--> 
			  <!--{hook/global_cpnav_extra1}--> 
			  <!--{hook/global_cpnav_extra2}--> 
			  <!--{loop $_G['setting']['topnavs'][1] $nav}--> 
			  <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}--> 
			  <!--{/loop}--> 
			  </li>
				</ul>
				</dd>
			</dl>
		</div>
		
	</div>
	
	
	<!--{if !empty($_G['style']['extstyle'])}-->
	<!-- 网站配色风格切换 图标 -->
	<div class="vk_top_in_qmenu cl m_b_20">
		<div class="list">
			<dl style="border-top: none;">
				<dt class="vk_title">
				  <li><a id="sslct" href="javascript:;" onMouseOver=" showMenu({'ctrlid':'sslct','pos':'34!'});">风格</a></li>
				</dt>
				<dd class="cl">
				<ul>

				  <!--{if !$_G[style][defaultextstyle]}-->
				  <li><span class="sslct_btn" onClick="extstyle('')" title="{lang default}"><i></i> {lang default}</span></li>
				  <!--{/if}--> 
				  <!--{loop $_G['style']['extstyle'] $extstyle}--> 
				  <li><span class="sslct_btn" onClick="extstyle('$extstyle[0]')" title="$extstyle[1]"><i style='background:$extstyle[2]'></i> $extstyle[1] </span> </li>
				  <!--{/loop}--> 

				</ul>
				</dd>
			</dl>
		</div>

	</div>
	<!--{/if}--> 
	
	
	
	
	
	
		
	<div class="wp cl "><!--{hook/global_qmenu_top}--></div>
    <div class="vk_top_in_qmenu_nav cl">
	<!--{if $_G['uid']}-->
	<!-- "道具"“分享”“淘贴”等小图标导航模块 -->
		<ul class="cl nav">
			<!--{loop $_G['setting']['mynavs'] $nav}-->
				<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->
					<li>$nav[code]</li>
				<!--{/if}-->
			<!--{/loop}-->
		</ul>
	<!--{elseif $_G[connectguest]}-->
	<!-- QQ账号登录但未绑定账号 状态 -->
		<div class="ptm pbw hm">
			{lang connect_fill_profile_to_visit}
		</div>
	<!--{else}-->
	<!-- 原 登录、注册 提示模块 -->
	<!--{/if}-->


	<!-- 版块模块 -->
	<!--{if $_G['setting']['showfjump']}-->
	<!-- 若要想显示，去掉这个注释即可
	<div id="fjump_menu" class="btda"></div>
	-->	
	<!--{/if}-->
	<!--{hook/global_qmenu_bottom}-->
    </div>
	
	
</div>





