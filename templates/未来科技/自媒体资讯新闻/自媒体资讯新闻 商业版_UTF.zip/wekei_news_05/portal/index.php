<?php exit;?>

<!--{template common/header}-->

<style id="diy_style" type="text/css"></style>



<!--  上部广告图片占位   -->
<div class="wp ">
  		<!--[diy=diy_vk_ad_top]--> <div id="diy_vk_ad_top" class="area"></div><!--[/diy]--> 
</div>


<div class="wp vk_diy col_2-1 m_t_15 ">
      
    <!--幻灯片模块--> 
	<link rel="stylesheet" type="text/css" href="{$_G['style']['styleimgdir']}/js/swiper.min.css" />
	<script type="text/javascript" src="{$_G['style']['styleimgdir']}/js/swiper.min.js"></script>
    <div class="col_2-1_l m_b_0 ">
      <div class="vk_portal_slide_top vk_float"  style="height:350px; width:875px; float:left; clear:both;"> 
      <!--[diy=diy_vk_portal_slide_top]-->  <div id="diy_vk_portal_slide_top" class="area"> </div>  <!--[/diy]-->
      </div>
    </div>
    <!--幻灯片模块--> 

    <!-- 上部右侧模块 start-->
    <div class="col_2-1_r  col_vk_title vk_wechat_wp m_b_0" >
    	<div id="vk_wechat" class="vk_wechat"></div>
    	<div id="vk_phone_icon" class="vk_phone_icon"></div>
    	<div class="vk_side_icon_4 "  >
        	<a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="vk_side_icon_4_1 left animated swing hvr-wobble-horizontal" > 投稿 </a>
        	<a href="#" class="vk_side_icon_4_2 left animated swing hvr-wobble-horizontal" 
            onmouseover="document.getElementById('vk_phone_icon').style.display='block';"
            onmouseout="document.getElementById('vk_phone_icon').style.display='none'"
            > 手机版 </a>
        	<a href="#" class="vk_side_icon_4_3 left animated swing hvr-wobble-horizontal" > 新浪微博 </a>
        	<a href="#" class="vk_side_icon_4_4 right m_r_0 animated swing hvr-wobble-horizontal"  
            onmouseover="document.getElementById('vk_wechat').style.display='block';"
            onmouseout="document.getElementById('vk_wechat').style.display='none'"
             > 公众平台 </a>
        </div>
		
    	<div class="vk_index_top_post_hot hvr-wobble-bottom"> <a class="" href="#" > 专栏分类 </a> </div>
    	<div class="vk_index_top_post cl">
        	<a href="#" class="left hvr-wobble-top" > Office进阶 </a>
        	<a href="#" class="right hvr-wobble-top" > 前端开发 </a>
        	<a href="#" class="left hvr-wobble-top" > Android 开发 </a>
        	<a href="#" class="right hvr-wobble-top" > iOS开发 </a>
        	<a href="#" class="left hvr-wobble-top" > 游戏开发 </a>
        	<a href="#" class="right hvr-wobble-top" > 平面设计 </a>
        	<a href="#" class="left hvr-wobble-top" > 产品运营 </a>
        	<a href="#" class="right hvr-wobble-top" > 网络营销 </a>
        </div>
		
    </div>
    <!-- 上部右侧模块 end -->

</div>




<!--  首页 全屏横幅广告占位  -->
<div class="wp  vk_diy wow animated fadeInUp">
  		<!--[diy=diy_vk_ad_1]--> <div id="diy_vk_ad_1" class="area"></div><!--[/diy]--> 
</div>





<div class="wp vk_diy col_2-1_page">
      
	<!-- 左侧模块 -->
    <div class="vk_col col_2-1_l_page wow animated fadeInUp">

		<!-- tab 模块 -->
		<div class="wp m_b_20 vk_tab_index_left bg_none">
			<!--[diy=diy_vk_tab]--> <div id="diy_vk_tab" class="area"></div><!--[/diy]--> 
		</div>

			<!-- DIY分页模块 -->
			<!-- 
			显示总个数在DIY模块属性里定义
			perPage:10  每页显示个数。添加DIY模块时，调用的文章或帖子个数一定要大于这个数，才会分页
			scrollTop:540 点击第二页时,自动距离顶部的高度参数
			-->
			<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jPages.js"></script>
			<script type="text/javascript">
				jQuery(function() {jQuery("div.holder").jPages({containerID: "hiddenresult",perPage:10,previous: "上一页",next: "下一页"});});
				jQuery(function(){ jQuery("div.holder").click(function(){ jQuery('html,body').animate({scrollTop:540},0); return false; });});
			</script> 
		
    </div>
	
	
	
    <!-- 右侧模块 -->
	<div class="col_2-1_r_page  wow animated fadeInUp">
		

		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> 一周精选 </a>  
			</h2>

			<div class=" ">
				<!--[diy=diy_vk_guide_1_r]--> <div id="diy_vk_guide_1_r" class="area"></div><!--[/diy]--> 
				<!--[diy=diy_vk_guide_1_r_ad]--> <div id="diy_vk_guide_1_r_ad" class="area"></div><!--[/diy]--> 
			</div>
		</div>
		
		
		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> 作者专栏 </a>  
			</h2>

			<div class=" ">
			<!--[diy=diy_vk_guide_1_r_2]--> <div id="diy_vk_guide_1_r_2" class="area"></div><!--[/diy]--> 
			</div> 
		</div>
		
		
		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> 实时快讯 </a>  
			</h2>

			<div class=" ">
			<!--[diy=diy_vk_guide_2_1_0]--> <div id="diy_vk_guide_2_1_0" class="area"></div><!--[/diy]--> 
			</div>
		</div>
		
		
		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> 点击排行 </a>  
			</h2>

			<div class=" ">
			<!--[diy=diy_vk_guide_2_1_1]--> <div id="diy_vk_guide_2_1_1" class="area"></div><!--[/diy]--> 
			</div>
		</div>
		
		
		<div class="m_b_15 cl vk_col">		
			<h2>
				<a href="#" target="_blank"> 热门推荐 </a>  
			</h2>

			<div class=" ">
				<!--[diy=diy_vk_news_1_r]--> <div id="diy_vk_news_1_r" class="area"></div><!--[/diy]--> 
			</div> 
		</div>
		
		
    </div>
	
</div>
  
  

<!--  首页 全屏横幅广告占位 5  -->
<div class="wp vk_diy">
  		<!--[diy=diy_vk_ad_5]--> <div id="diy_vk_ad_5" class="area"></div><!--[/diy]--> 
</div>



<div class="wp  m_b_15">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>





<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->
