<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<a href="#" target="_blank" class="vk_post_2" title="&#31614;&#21040;">
	<script type="text/javascript">
	  var vk_date=new Date();
	  var vk_day=vk_date.getDay();
	  var weekday=["&#26143;&#26399;&#26085;","&#26143;&#26399;&#19968;","&#26143;&#26399;&#20108;","&#26143;&#26399;&#19977;","&#26143;&#26399;&#22235;","&#26143;&#26399;&#20116;","&#26143;&#26399;&#20845;"];
	  document.write(weekday[vk_day] +'<br>'+(vk_date.getMonth()+1)+'&#26376;'+vk_date.getDate()+'&#26085;' );
	</script>
</a>




<!--

说明：

修改签到指向链接，只需修改第二行代码中 <a href="#"  的这个 # 号，改为签到插件调用的链接即可。其他的代码不要修改。

例如，签到插件链接为

plugin.php?id=wekei

则上面的 a 链接修改后的样子为

<a href="plugin.php?id=wekei"

然后覆盖，后台更新缓存即可。


-->
