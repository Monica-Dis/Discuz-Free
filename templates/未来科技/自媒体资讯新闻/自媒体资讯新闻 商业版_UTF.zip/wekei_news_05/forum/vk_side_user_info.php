<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<div class="vk_viewthread_side">
    <div class="vk_viewthread_side_avatar  animated bounce hvr-wobble-horizontal"><a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" target="_blank"><!--{avatar($_G[forum_thread][authorid],middle)}--></a></div>
    <div class="vk_viewthread_side_name"><a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" title="$_G[forum_thread][author]">$_G[forum_thread][author]</a></div>
    <div class="vk_viewthread_side_name_2"><a href="home.php?mod=spacecp&ac=usergroup&gid=$post[groupid]" target="_blank" class="vk_txt">{$post[authortitle]}</a></div>


	<!-- 关注 粉丝 主题 -->
	<div class="vk_tns_num">
	<!--{eval include TPLDIR.'/php/vk_side_user_info.php';}-->
      <table cellspacing="0" cellpadding="0">
          <tbody>
              <tr>
                  <th><p>$author_info_1['following']</p>
                      &#20851;&#27880;
                  </th>
                  <th><p>$author_info_1['follower']</p>
                      &#31881;&#19997;
                  </th>
                  <td><p>$author_info_1['threads']</p>
                      &#20027;&#39064;
                  </td>
              </tr>
          </tbody>
      </table>
	</div>

	<!--关注 发信息-->
    <div class="clear vk_side_follow"> 
        <!--{if $_G[forum_thread][authorid] != $_G[uid]}-->
            <ul class="cl">
                <!--{if helper_access::check_module('follow')}-->
                <li class="vk_addflw">
                    <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$_G[forum_thread][authorid]" id="followmod_$post[authorid]" title="{lang follow}" class="xi2" onclick="showWindow('followmod', this.href, 'get', 0);"> &#20851;&#27880; </a>
                </li>
                <li class="vk_pm"><a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$_G[forum_thread][authorid]&touid=$_G[forum_thread][authorid]&pmid=0&daterange=2&pid=$post[pid]&tid=$post[tid]" onclick="showWindow('sendpm', this.href);" title="{lang viewthread_left_sendpm}" class="xi2"> &#21457;&#20449;&#24687; </a></li>
                <!--{/if}-->
            </ul>
        <!--{/if}-->
    </div>
</div>
