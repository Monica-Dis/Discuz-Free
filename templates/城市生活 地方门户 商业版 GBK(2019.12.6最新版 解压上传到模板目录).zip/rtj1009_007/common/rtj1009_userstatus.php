<?PHP exit('Access Denied');?>
<!--{if $_G['uid']}-->
	<div class="rtj_yonghutouxiang"><a href="home.php?mod=space&uid=$_G[uid]"><!--{avatar($_G[uid],small)}--></a></div>
		<strong class="yonghuming"{if $_G['setting']['connect']['allow'] && $_G[member][conisbind]} class="qq"{/if}><a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">{$_G[member][username]}</a></strong>

        <!--{hook/global_usernav_extra1}-->
        	<a id="rtj_xiaoxi" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});"{if $_G[member][newpm] || $_G[member][newprompt]} class="ynew"{/if}>�ҵ�</a>
            <a id="rtj_shezhi" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});">����</a>
            <a id="rtj_sousuo" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});">����</a>
            
        <!--{hook/global_usernav_extra4}-->
		<!--{hook/global_usernav_extra2}-->
		<!--{hook/global_usernav_extra3}-->
</div>
<!--{elseif !empty($_G['cookie']['loginuser'])}-->
	<strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
<!--{elseif !$_G[connectguest]}-->
	<a id="rtj_ydenglu" href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}">��¼</a>
	<a id="rtj_yzhucen" href="member.php?mod={$_G[setting][regname]}">ע��</a>
<!--{else}-->
<div id="um">
	<div class="avt y"><!--{avatar(0,small)}--></div>
		<strong class="vwmy qq">{$_G[member][username]}</strong>
		<!--{hook/global_usernav_extra1}-->
		<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
		<a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a>
		{lang usergroup}: $_G[group][grouptitle]
<!--{/if}-->