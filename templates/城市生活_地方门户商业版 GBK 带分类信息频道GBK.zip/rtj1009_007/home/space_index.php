<?PHP exit('Access Denied');?>
<!--{template home/space_header}-->
<div id="ren_ct" class="rtj1009_lai_ct cl">
    <div class="bm ren_ly_bm cl">
        <div class="ren_bm_c ren_ly_c cl">
			<div id="frame1_left" style="width:280px" class="z column">
				<!--{if empty($leftlist)}-->
				<div id="left_temp" class="move-span temp"></div>
				<!--{/if}-->
				<!--{loop $leftlist $key $value}-->
				<!--{if !empty($key)}-->
					<div id="$key" class="block move-span">
						$value
					</div>
				<!--{/if}-->
				<!--{/loop}-->
			</div>

			<div id="frame1_center" style="width:558px" class="z column">
				<!--{if empty($centerlist)}-->
				<div id="center_temp" class="move-span temp"></div>
				<!--{/if}-->
				<!--{loop $centerlist $key $value}-->
					<!--{if !empty($key)}-->
						<div id="$key" class="block move-span">
							$value
						</div>
					<!--{/if}-->
				<!--{/loop}-->
			</div>

			<!--{if (strlen($userdiy['currentlayout']) > 3) }-->
			<div id="frame1_right" style="width:280px" class="z column">
				<!--{if empty($rightlist)}-->
				<div id="right_temp" class="move-span temp"></div>
				<!--{/if}-->
				<!--{loop $rightlist $key $value}-->
				<!--{if !empty($key)}-->
					<div id="$key" class="block move-span">
						$value
					</div>
				<!--{/if}-->
				<!--{/loop}-->
			</div>
			<!--{/if}-->
		</div>
	</div>
</div>
<script type="text/javascript">
function succeedhandle_followmod(url, msg, values) {
	var fObj = $('followmod');
	if(values['type'] == 'add') {
		fObj.innerHTML = 'ȡ����ע';
		fObj.className = 'flw_btn_unfo';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
	} else if(values['type'] == 'del') {
		fObj.innerHTML = '��ע';
		fObj.className = 'flw_btn_fo';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
	}
}
</script>
<!--{template common/footer}-->
