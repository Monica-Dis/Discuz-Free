<?PHP exit('Access Denied');?>
{eval
	$filter = array( 'common' => '{lang have_posted}', 'save' => '{lang draft}', 'close' => '{lang closed}', 'aduit' => '{lang pending}', 'ignored' => '{lang ignored}', 'recyclebin' => '{lang recyclebin}');
	$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=thread&view=me\">{lang they_thread}</a>";
}

<!--{if $diymode}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
		<div id="ren_ct" class="rtj1009_lai_ct cl">
            <div class="ren_lai_mn z">
                <div class="bm ren_ly_bm">
                	<div class="ren_bm_c ren_ly_c">
                        <p class="tbmu cl">
                        <!--{if $space[self]}--><a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="y pn pnc"><strong>{lang posted}</strong></a><!--{/if}-->
                            <a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread" $orderactives[thread]>{lang topic}</a>
                            <span class="pipe">|</span>
                            <a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=reply" $orderactives[reply]>{lang reply}</a>
                        </p>
				
	<!--{else}-->
		<!--{template common/header}-->
		
		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="rtj1009_ct cl">
			<div class="ren_g_mn">
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<div class="ren_ly_bm">
					<div class="ren_ly_c">
	<!--{/if}-->
<!--{else}-->
	<!--{template common/header}-->
	
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ct" class="ct2_a wp cl">
	<!--{if $_G[setting][homestyle]}-->
		<div class="rtj1009_zcd">
			<!--{subtemplate common/userabout}-->
		</div>
		<div class="mn pbw">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<ul class="tb cl">
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
	<!--{else}-->
		<div class="rtj1009_zcd">
			<div class="tbn">
				<h2 class="mt bbda">{lang thread}</h2>
				<ul>
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
		</div>
		<div class="mn pbw">
		<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
	<!--{/if}-->
<!--{/if}-->
		
		<!--{if !$diymode && $space[self]}-->
			<!--{if $_GET['view'] == 'me'}-->
			<p class="tbmu bw0">
				<!--{if $viewtype != 'postcomment'}-->
					<span class="y">
					<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=" {if !$_GET[filter]}class="a"{/if}>{lang all}</a>
					<!--{loop $filter $key $name}--><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=$key" {if $key == $_GET[filter]}class="a"{/if}>$name</a><!--{/loop}--> &nbsp;
						<select name="forumlist" id="forumlist" class="ps vm" onchange="viewforumthread(this.value);" style="width: 120px; word-wrap: normal;">
							<option value="0">{lang follow_select_forum}</option>
							$forumlist
						</select>
					</span>
				<!--{/if}-->
				<a href="home.php?mod=space&do=thread&view=me&type=thread" $orderactives[thread]>{lang topic}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=reply" $orderactives[reply]>{lang reply}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=postcomment" $orderactives[postcomment]>{lang post_comment}</a>
				<!--{if $viewtype != 'reply' && $viewtype != 'postcomment'}-->&nbsp; <input type="text" id="searchmypost" class="px vm" size="15" /> <button class="pn vm" onclick="searchpostbyusername($('searchmypost').value, '$_G[username]');"><em>{lang search}</em></button><!--{/if}-->
			</p>
			<!--{elseif $_GET['view'] == 'all'}-->
			<p class="tbmu bw0">
				<a href="home.php?mod=space&do=thread&view=all&order=dateline" $orderactives[dateline]>{lang newest_thread}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=all&order=hot" $orderactives[hot]>{lang top_thread}</a>
			</p>
			<!--{/if}-->
		<!--{/if}-->
		
		<!--{if $diymode && !$_G[setting][homepagestyle] }-->
			<p class="tbmu">
				<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread" $orderactives[thread]>ȫ������</a>
				<span class="pipe">|</span>
				<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=reply" $orderactives[reply]>ȫ���ظ�</a>
			</p>
		<!--{/if}-->
		
		<!--{if $userlist}-->
			<p class="tbmu bw0">
				{lang view_by_friend}
				<select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
					<option value="">{lang all_friends}</option>
					<!--{loop $userlist $value}-->
					<option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
					<!--{/loop}-->
				</select>
			</p>
		<!--{/if}-->
		<div class="tl">
			<form method="post" autocomplete="off" name="delform" id="delform" action="home.php?mod=space&do=thread&view=all&order=dateline" onsubmit="showDialog('{lang del_select_thread_confirm}', 'confirm', '', '$(\'delform\').submit();'); return false;">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="delthread" value="true" />

					<table cellspacing="0" cellpadding="0">
					<!--{if $list}-->
						<!--{loop $list $stid $thread}-->
						<tr{if $actives[me] && $viewtype=='reply' || $viewtype=='postcomment'} class="bw0_all"{/if}>
							<td class="icn">
                                <div class="ren_tielist_zztx">
                                    <a href="home.php?mod=space&uid=$thread[authorid]" class="ren_zz_tx" target="_blank"><!--{avatar($thread[authorid],small)}--></a>
                                </div>
                            </td>
							<!--{if $_GET['view'] == 'all' && $pruneperm && !$_GET['archiveid']}-->
								<td class="o">
									<!--{if $thread['digest'] == 0}-->
										<!--{if $thread['displayorder'] == 0}-->
											<input type="checkbox" name="moderate[]" value="$thread[tid]" class="pc" />
										<!--{else}-->
											<input type="checkbox" class="pc" disabled="disabled" />
										<!--{/if}-->
									<!--{else}-->
										<input type="checkbox" class="pc" disabled="disabled" />
									<!--{/if}-->
								</td>
							<!--{/if}-->
							<th class="ren_tzlb_twlb">
								<!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
									<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]" class="ren-space-xst" target="_blank">$thread[subject]</a>
								<!--{else}-->
									<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="s xst" target="_blank" {if $thread['displayorder'] == -1}class="recy"{/if}>$thread[subject]</a>
								<!--{/if}-->
								
								<!--{if $thread[multipage]}--><span class="tps">$thread[multipage]</span><!--{/if}-->
								<!--{if !$_GET['filter']}-->
									<!--{if $thread[$statusfield] == -1}--><span class="xg1">$filter[recyclebin]</span>
									<!--{elseif $thread[$statusfield] == -2}--><span class="xg1">$filter[aduit]</span>
									<!--{elseif $thread[$statusfield] == -3 && $thread[displayorder] != -4}--><span class="xg1">$filter[ignored]</span>
									<!--{elseif $thread[displayorder] == -4}--><span class="xg1">$filter[save]</span>
									<!--{elseif $thread['closed'] == 1}--><span class="xg1">$filter[close]</span>
									<!--{/if}-->
								<!--{/if}-->
                                <!--{eval  $threadlistimg =  DB::fetch_all('SELECT * FROM '.DB::table('forum_attachment').' WHERE tid = '. $thread['tid'].' LIMIT  0 ,'. 5);}-->
                                <!--{if $threadlistimg && $thread['attachment'] == 2}-->
                                <div class="ren_threadimg">
                                      <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} target="_blank">
                                          <!--{loop $threadlistimg $values}-->
                                          <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 180, 120); }-->
                                              <span><img src="$renlistimgkey" class="ren_thread_img" alt="$thread[subject]"/></span>
                                          <!--{/loop}-->
                                      </a>
                                </div>
                                <!--{/if}-->
                                <div class="ren_tie_x cl">
                                    <div class="z ren_tie_xz">
                                        <div class="z ren_tie_zhhf">
                                            <div class="z ren_tie_huifu">
                                                <span>��󷢱���</span>
                                                <!--{if $thread['lastposter']}--><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}" c="1">$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}-->
                                                <span>$thread[lastpost]</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="y ren_tie_xy cl">
                                        <div class="ren_tie_hfck cl">
                                            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" title="$thread[replies] {lang reply}"><em class="ren_zz_hf y">$thread[replies]</em></a>
                                            <div class="ren_zz_ck y">
                                                <!--{if $thread[views]}-->$thread[views]<!--{else}-->0<!--{/if}-->
                                            </div>
                                        </div>
                                    </div>
                                </div>
							</th>
						</tr>
						<!--{if $actives[me] && $viewtype=='reply'}-->
							<!--{loop $tids[$stid] $pid}-->
							<!--{eval $post = $posts[$pid];}-->
							<tr>
								<td colspan="5" class="xg1">&nbsp;<img src="{IMGDIR}/icon_quote_m_s.gif" style="vertical-align:middle;" /> <a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid" target="_blank"><!--{if $post[message]}-->{$post[message]}<!--{else}-->......<!--{/if}--></a> <img src="{IMGDIR}/icon_quote_m_e.gif" style="vertical-align:middle;" /></td>
							</tr>
							<!--{/loop}-->
						<!--{/if}-->
						<!--{if $actives[me] && $viewtype=='postcomment'}-->
						<tr>
							<td class="icn">&nbsp;</td>
							<td colspan="2" class="xg1">$thread[comment]</td>
						</tr>
						<!--{/if}-->
						<!--{/loop}-->
					<!--{else}-->
						<tr>
							<td colspan="{if $viewtype != 'postcomment'}{if ($_GET['view'] == 'all' && $pruneperm && !$_GET['archiveid'])}6{else}5{/if}{else}3{/if}"><p class="emp">{lang no_related_posts}</p></td>
						</tr>
					<!--{/if}-->
					</table>

					<!--{if $_GET['view'] == 'all' && $pruneperm && !$_GET['archiveid'] && $list}-->
						<p class="mtm pns">
							<label for="chkall" onclick="checkall(this.form, 'moderate')"><input type="checkbox" name="chkall" id="chkall" class="pc vm" />{lang select_all}</label>
							<button type="submit" name="delsubmit" value="true" class="pn vm"><em>{lang del_select_thread}</em></button>
						</p>
					<!--{/if}-->
				</form>

				<!--{if $hiddennum}-->
					<p class="mtm">{lang hide_thread}</p>
				<!--{/if}-->
			</div>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->		
		
		<script type="text/javascript">
		function fuidgoto(fuid) {
			window.location.href = 'home.php?mod=space&do=thread&view=we&fuid='+fuid;
		}
		function viewforumthread(fid) {
			window.location.href = '{$forumurl}&fid='+fid;
		}
		</script>
		
		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="rtj1009_home_sd y">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->

<!--{template common/footer}-->