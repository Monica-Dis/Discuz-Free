<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<!--{eval $loginhash = 'L'.random(4);}-->
<!--{if empty($_GET['infloat'])}-->
<div class="rtj1009_denglu">
<div id="ct" class="wp w cl">
	<div class="nfl" id="main_succeed" style="display: none">
		<div class="f_c altw">
			<div class="alert_right">
				<p id="succeedmessage"></p>
				<p id="succeedlocation" class="alert_btnleft"></p>
				<p class="alert_btnleft"><a id="succeedmessage_href">{lang message_forward}</a></p>
			</div>
		</div>
	</div>
	<div class="ren_mn y" id="main_message">
		<div class="ren_denglu">
			<div class="ren_bm_h">
            	<!--{hook/logging_side_top}-->
				<!--{if !$secchecklogin2}-->
					<span>{lang login}</span>
				<!--{else}-->
					<span>{lang login_seccheck2}</span>
				<!--{/if}-->
			</div>
        </div>
<!--{/if}-->

<div id="main_messaqge_$loginhash"{if $auth} style="width: auto"{/if}>
	<div id="layer_login_$loginhash">
		<div class="ren_flb">
            <span id="returnmessage_$loginhash">
                <!--{if !empty($_GET['infloat'])}--><!--{if !empty($_GET['guestmessage'])}-->{lang login_guestmessage}<!--{elseif $auth}-->{lang profile_renew}<!--{else}-->{lang login_member}<!--{/if}--><!--{/if}-->
            </span>
            <span class="y"><!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}--><a href="javascript:;" class="flbc" onclick="hideWindow('$_GET[handlekey]', 0, 1);" title="{lang close}">{lang close}</a><!--{/if}--></span>
        </div>
		<!--{hook/logging_top}-->
		<form method="post" autocomplete="off" name="login" id="loginform_$loginhash" class="cl" onsubmit="{if $this->setting['pwdsafety']}pwmd5('password3_$loginhash');{/if}pwdclear = 1;ajaxpost('loginform_$loginhash', 'returnmessage_$loginhash', 'returnmessage_$loginhash', 'onerror');return false;" action="member.php?mod=logging&action=login&loginsubmit=yes{if !empty($_GET['handlekey'])}&handlekey=$_GET[handlekey]{/if}{if isset($_GET['frommessage'])}&frommessage{/if}&loginhash=$loginhash">
			<div class="c ren_login_c cl">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="referer" value="{echo dreferer()}" />
				<!--{if $auth}-->
					<input type="hidden" name="auth" value="$auth" />
				<!--{/if}-->
				
				<!--{if $invite}-->
				<div class="ren_rfm">
                    <div>
                        <span>{lang register_from}</span>
                        <span><a href="home.php?mod=space&uid=$invite[uid]" target="_blank">$invite[username]</a></span>
                    </div>
				</div>
				<!--{/if}-->

				<!--{if !$auth}-->
                <div class="ren_rfm">
                    <!--{if $this->setting['autoidselect']}--><label class="ren_label_icon" for="username_$loginhash"></label><!--{else}-->
                        <span class="login_slct">
                            <select name="loginfield" style="float: left;" width="45" id="loginfield_$loginhash">
                                <option value="username">{lang username}</option>
                                <!--{if getglobal('setting/uidlogin')}-->
                                <option value="uid">{lang uid}</option>
                                <!--{/if}-->
                                <option value="email">{lang email}</option>
                            </select>
                        </span>
                    <!--{/if}-->
				</div>
				<div class="ren_rfm">
                    
                    <input type="text" name="username" id="username_$loginhash" autocomplete="off" size="30" class="ren_px input_text zhanghaoicon xg1" tabindex="1" value="$username" onblur="if (value ==''){value='�˺�'}" onfocus="if (value =='�˺�'){value =''}" value="�˺�" />
				</div>
				<div class="ren_rfm">
                    <label class="ren_label_icon" for="password3_$loginhash"></label>
                    <input type="password" id="password3_$loginhash" name="password" onfocus="clearpwd()" size="30" class="ren_px input_text mimaicon" tabindex="1" />
				</div>
				<!--{/if}-->

				<!--{if empty($_GET['auth']) || $questionexist}-->
				<div class="ren_rfm">
                    <select id="loginquestionid_$loginhash" class="ren_label_tiwen" name="questionid"{if !$questionexist} onchange="if($('loginquestionid_$loginhash').value > 0) {$('loginanswer_row_$loginhash').style.display='';} else {$('loginanswer_row_$loginhash').style.display='none';}"<!--{/if}-->>
                        <option value="0"><!--{if $questionexist}-->{lang security_question_0}<!--{else}-->{lang security_question}<!--{/if}--></option>
                        <option value="1">{lang security_question_1}</option>
                        <option value="2">{lang security_question_2}</option>
                        <option value="3">{lang security_question_3}</option>
                        <option value="4">{lang security_question_4}</option>
                        <option value="5">{lang security_question_5}</option>
                        <option value="6">{lang security_question_6}</option>
                        <option value="7">{lang security_question_7}</option>
                    </select>
				</div>
				<div class="ren_rfm" id="loginanswer_row_$loginhash" {if !$questionexist} style="display:none"{/if}>
                    <label class="ren_label_daan"></label>
                    <input type="text" name="answer" id="loginanswer_$loginhash" autocomplete="off" size="30" class="ren_px input_text_tiwen xg1" tabindex="1" value="$answer" onblur="if (value ==''){value='��'}" onfocus="if (value =='��'){value =''}" value="��" />
				</div>
				<!--{/if}-->

				<!--{if $seccodecheck}-->
					<!--{block sectpl}--><div class="ren_yzm"><table><tr><th><sec>��</th><td><sec><br /><sec></td></tr></table></div><!--{/block}-->
					<!--{subtemplate common/seccheck}-->
				<!--{/if}-->

				<!--{hook/logging_input}-->

				<div class="ren_rfm {if !empty($_GET['infloat'])} bw0{/if} cl">
                    <label for="cookietime_$loginhash" style="float: left;"><input type="checkbox" class="pc" name="cookietime" id="cookietime_$loginhash" tabindex="1" value="2592000" $cookietimecheck />{lang login_permanent}</label>
                    <span class="ren_mbzh y"><a href="javascript:;" onclick="display('layer_login_$loginhash');display('layer_lostpw_$loginhash');" title="{lang getpassword}">��������</a>
                    </span>
				</div>

				<div class="ren_rfm mbw bw0 cl">
                    <button class="ren_pn z" type="submit" name="loginsubmit" value="true" tabindex="1"><strong>{lang login}</strong></button>
                    <!--{if $this->setting['sitemessage'][login] && empty($_GET['infloat'])}--><a href="javascript:;" id="custominfo_login_$loginhash" class="y">&nbsp;<img src="{IMGDIR}/info_small.gif" alt="{lang faq}" class="vm" /></a><!--{/if}-->
                    <a href="member.php?mod={$_G[setting][regname]}" class="ren_ljzc y"><span>ע��</span></a>
				</div>

				<!--{if !empty($_G['setting']['pluginhooks']['logging_method'])}-->
                <div class="ren_qtzhdl cl">
                    <div class="ren_qtzh cl"><span>ʹ�������˺ŵ�¼</span></div>
                    <div class="ren_qqlogin cl"><!--{hook/logging_method}--></div>
                </div>
				<!--{/if}-->
			</div>
		</form>
	</div>
	<!--{if $_G['setting']['pwdsafety']}-->
		<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
	<!--{/if}-->
	<div id="layer_lostpw_$loginhash" style="display: none;">
		<h3 class="ren_zhmm_flb flb">
			<em id="returnmessage3_$loginhash">{lang getpassword}</em>
			<span><!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}--><a href="javascript:;" class="flbc" onclick="hideWindow('login')" title="{lang close}">{lang close}</a><!--{/if}--></span>
		</h3>
		<form method="post" autocomplete="off" id="lostpwform_$loginhash" class="cl" onsubmit="ajaxpost('lostpwform_$loginhash', 'returnmessage3_$loginhash', 'returnmessage3_$loginhash', 'onerror');return false;" action="member.php?mod=lostpasswd&lostpwsubmit=yes&infloat=yes">
			<div class="c ren_login_c cl">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="handlekey" value="lostpwform" />
				<div class="ren_rfm rfm">
					<table>
						<tr>
							<th><span class="rq">*</span><label for="lostpw_email">{lang email}��</label></th>
							<td><input type="text" name="email" id="lostpw_email" size="30" value=""  tabindex="1" class="ren_px input_text_zhmm" /></td>
						</tr>
					</table>
				</div>
				<div class="ren_rfm rfm">
					<table>
						<tr>
							<th><label for="lostpw_username">{lang username}��</label></th>
							<td><input type="text" name="username" id="lostpw_username" size="30" value=""  tabindex="1" class="ren_px input_text_zhmm" /></td>
						</tr>
					</table>
				</div>

				<div class="ren_rfm rfm mbw bw0">
					<table>
						<tr>
							<th></th>
							<td><button class="ren_pn" type="submit" name="lostpwsubmit" value="true" tabindex="100"><span>{lang submit}</span></button></td>
						</tr>
					</table>
				</div>
			</div>
		</form>
	</div>
</div>

<div id="layer_message_$loginhash"{if empty($_GET['infloat'])} class="f_c blr nfl"{/if} style="display: none;">
	<h3 class="ren_flb" id="layer_header_$loginhash">
		<!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}-->
		<span>{lang login_member}</span>
		<span><a href="javascript:;" class="flbc" onclick="hideWindow('login')" title="{lang close}">{lang close}</a></span>
		<!--{/if}-->
	</h3>
	<div class="c"><div class="alert_right">
		<div id="messageleft_$loginhash"></div>
		<p class="alert_btnleft" id="messageright_$loginhash"></p>
	</div>
</div>

<script type="text/javascript" reload="1">
<!--{if !isset($_GET['viewlostpw'])}-->
	var pwdclear = 0;
	function initinput_login() {
		document.body.focus();
		<!--{if !$auth}-->
			if($('loginform_$loginhash')) {
				$('loginform_$loginhash').username.focus();
			}
			<!--{if !$this->setting['autoidselect']}-->
				simulateSelect('loginfield_$loginhash');
			<!--{/if}-->
		<!--{elseif $seccodecheck && !(empty($_GET['auth']) || $questionexist)}-->
			if($('loginform_$loginhash')) {
				safescript('seccodefocus', function() {$('loginform_$loginhash').seccodeverify.focus()}, 500, 10);
			}			
		<!--{/if}-->
	}
	initinput_login();
	<!--{if $this->setting['sitemessage']['login']}-->
	showPrompt('custominfo_login_$loginhash', 'mouseover', '<!--{echo trim($this->setting['sitemessage'][login][array_rand($this->setting['sitemessage'][login])])}-->', $this->setting['sitemessage'][time]);
	<!--{/if}-->

	function clearpwd() {
		if(pwdclear) {
			$('password3_$loginhash').value = '';
		}
		pwdclear = 0;
	}
<!--{else}-->
	display('layer_login_$loginhash');
	display('layer_lostpw_$loginhash');
	$('lostpw_email').focus();
<!--{/if}-->
</script>

<!--{eval updatesession();}-->
<!--{if empty($_GET['infloat'])}-->
	</div></div></div></div>
</div></div>
<!--{/if}-->
<!--{template common/footer}-->