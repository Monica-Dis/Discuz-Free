<?PHP exit('��֧������ - վק��� https://dism.taobao.com/?@57900.developer');?>	
<!--{subtemplate common/header}-->

<style id="diy_style" type="text/css"></style>

<div class="wp ct2 zz_scroll_fixd data-sticky-container cl">
      <div class="zz_pbox cl">
           <div class="zz_pmn cl">
                <div class="zz_swiper cl">
                     <div class="zz_middle_founs cl">
			              <!--[diy=zhanzhuai_diy001]--><div id="zhanzhuai_diy001" class="area"></div><!--[/diy]-->
		             </div>
                </div>
                <div class="zz_load_thread zz_frame_c cl">
                     <div class="hd cl">
	                      <div class="zz_sidebox cl">
                               <ul>
                                   <li><a href="javascript:;" title="��Ѷ�Ƽ�">��Ѷ<em></em></a></li>
                                   <li><a href="javascript:;" title="����������">����<em></em></a></li>
			                       <li><a href="javascript:;" title="����������">����<em></em></a></li>
			                       <li><a href="javascript:;" title="����������">����<em></em></a></li>
							       <li style="float: right;"><a href="forum.php" style="margin-right: 0;" title="����">&bull;&bull;&bull;</a></li>
		                       </ul>
		                   </div>
	                  </div>
                      <div class="bd">
                           <div class="zz_pnews_list cl">
	                            <!--[diy=zhanzhuai_b_diy4]--><div id="zhanzhuai_b_diy4" class="area"></div><!--[/diy]-->
                           </div> 
					       <div class="zz_pnews_list zz_frame_c cl">
	                            <!--[diy=zhanzhuai_b_diy4a]--><div id="zhanzhuai_b_diy4a" class="area"></div><!--[/diy]-->
                           </div>
					       <div class="zz_pnews_list zz_frame_c cl">
	                            <!--[diy=zhanzhuai_b_diy4b]--><div id="zhanzhuai_b_diy4b" class="area"></div><!--[/diy]-->
                           </div>
					       <div class="zz_pnews_list zz_frame_c cl">
	                            <!--[diy=zhanzhuai_b_diy4c]--><div id="zhanzhuai_b_diy4c" class="area"></div><!--[/diy]-->
                           </div>
                      </div>
                 </div>
                 <script type="text/javascript">		
                      jQuery(".zz_load_thread").slide({ titCell:".hd li", mainCell:".bd",trigger:"click",autoPlay:false,effect:"fade" });
                 </script>
           </div> 
           <div class="zz_psd cl">

		        <!--{if $_G['uid']}-->

	<div class="zz_login_box zz_frame_c cl" style="padding: 22px 20px 5px;"> 
	     <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="zz_login_out">�˳���¼</a>
	     <div class="zz_login_avatar cl"> 
		      <a href="home.php?mod=space&uid=$_G[uid]" title="{$_G[member][username]}">
			     <!--{avatar($_G[uid],middle)}-->
			  </a> 
		 </div> 
	   
	    <div class="zz_login_uname">
		     <a href="home.php?mod=space&uid=$_G[uid]" title="{$_G[member][username]}">{$_G[member][username]}</a>
		</div>

		<div class="zz_login_num cc">  
		    <ul>
			    <li><span>����</span><p>{eval echo getuserprofile('threads');}</p></li>  
			    <li><span>����</span><p>{eval echo getuserprofile('posts');}</p></li>  
			    <li style="border:none;"><span>����</span><p>$_G[member][credits]</p></li> 
			<ul>
		</div>

		<div class="zz_mycollection">
		     <a href="forum.php?mod=guide&amp;view=my" class="zz_my_c1">
		              <i class="iconfont icon-activity left_icon"></i>�ҵ�����<i class="iconfont icon-enter right_icon"></i>
				   </a>
		           <div class="hr_line"></div> 
		           <a href="home.php?mod=space&amp;do=favorite&amp;view=me" class="zz_my_c2">
				      <i class="iconfont icon-collection left_icon"></i>�ҵ��ղ�<i class="iconfont icon-enter 
		  right_icon"></i>
		           </a>
                   <div class="hr_line"></div>
		           <a href="home.php?mod=medal&amp;action=log" class="zz_my_c3"><i class="iconfont icon-select left_icon"></i>�ҵ�ѫ��<i class="iconfont icon-enter 
		  right_icon"></i>
		           </a>
		</div>
		    
  </div>

<!--{else}-->

<!--{if CURMODULE != 'logging'}-->
    <script type="text/javascript" src="{$_G[setting][jspath]}logging.js?{VERHASH}"></script>
    <form method="post" autocomplete="off" id="lsform" action="member.php?mod=logging&action=login&loginsubmit=yes&infloat=yes&lssubmit=yes" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('ls_password');{/if}return lsSubmit();">
        <div class="zz_login_box zz_frame_c cl">
                  <span id="return_ls" style="display:none"></span>
                  <div class="zz_login_innerwrap cl">
                       <div class="zz_login_list">
					        <div class="zz_input_wrap">
							     <input type="text" name="username" id="ls_username" value="" placeholder="UID/�û���/Email" onfocus="this.placeholder=''" onblur="this.placeholder='UID/�û���/Email'" tabindex="901" class="zz_login_input">
							</div>
					   </div>
                       <div class="zz_login_list password">
					        <div class="zz_input_wrap">
							     <input type="password" name="password" id="ls_password" autocomplete="off" value="" placeholder="����������" onfocus="this.placeholder=''" onblur="this.placeholder='����������'" tabindex="902" class="zz_login_input">
						    </div>
					   </div>
                       <div class="zz_login_list"> 
					        <label for="ls_cookietime"><input type="checkbox" tabindex="903" value="2592000" class="pc" id="ls_cookietime" name="cookietime">��ס��</label>
							<a href="javascript:;" onclick="showWindow('login', 'member.php?mod=logging&action=login&viewlostpw=1')" class="y">��������</a>
					   </div>
                       <div class="zz_login_list login_btn">
					        <button type="submit" tabindex="904"><span>��¼</span></button>
					   </div>

					   <div class="zz_login_list register">
						    <span class="S_txt2">��û��΢����</span><a href="member.php?mod={$_G[setting][regname]}" target="_blank">����ע��!</a></span>
					   </div>

                       <div class="zz_login_list other_login cl">
					      <span class="z">������ʽ��¼��</span> 
					      <div class="other_login_list z">
						      <a href="connect.php?mod=login&op=init&referer=index.php&statfrom=login_simple" class="icon_qq" title="qq��¼">qq</a>
							  <a href="plugin.php?id=wechat:login" class="icon_wx" title="΢�ŵ�¼">΢��</a> 
							  <a href="#" class="icon_wb" title="΢����¼">΢��</a> 
						  </div> 
                       </div>   
                  </div>
			      <input type="hidden" name="quickforward" value="yes">
                  <input type="hidden" name="handlekey" value="ls">
              </div>
          </form>
	      <!--{if $_G['setting']['pwdsafety']}-->
		       <script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
	      <!--{/if}-->
     <!--{/if}-->
<!--{/if}-->
                
                <!--{if $_G['cache']['plugin']['k_misign']}-->
				<div class="zz_frame_c cl">
		             <div class="zz_q_btn cl">
					      <!--{hook/index_side_k_misign}-->
                     </div>
	            </div>
				<!--{/if}-->

				<div class="zz_frame_c cl">
                     <!--[diy=zhanzhuai_b_diy6]--><div id="zhanzhuai_b_diy6" class="area"></div><!--[/diy]-->
                </div>

                <div class="zz_ptop_banner cl">
                     <!--[diy=zhanzhuai_b_diy5]--><div id="zhanzhuai_b_diy5" class="area"></div><!--[/diy]-->
                </div>
                <div class="zz_frame_c cl">
                     <!--[diy=zhanzhuai_b_diy7]--><div id="zhanzhuai_b_diy7" class="area"></div><!--[/diy]-->
                </div>
                
                <div class="zz_frame_c cl">
                     <!--[diy=zhanzhuai_b_diy8]--><div id="zhanzhuai_b_diy8" class="area"></div><!--[/diy]-->
                </div>
           </div> 
      </div> 
</div>

<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
<!--{else}-->
<script type="text/javascript" src="$_G['style']['styleimgdir']/js/jquery.zz_scroll.min.js"></script>
<script type="text/javascript">
  jQuery(document).ready(function() {
    jQuery('.zz_psd').zzscrollfixd({
      // Settings
      additionalMarginTop: 80
    });
  });
</script>
<!--{/if}-->

<script type="text/javascript">			
    jQuery(document).ready(function() {
        var zz_thread_lists = function(jQuerychildren, n) {
        var jQueryhiddenChildren = jQuerychildren.filter(":hidden");
        var cnt = jQueryhiddenChildren.length;
        for (var i = 0; i < n && i < cnt; i++) {
            jQueryhiddenChildren.eq(i).fadeIn();
        }
        return cnt - n;
    }
    jQuery(".zz_threads_list").each(function() {
		var defaultNum = 12; //Ĭ���״���ʾ����
		    showNum = jQuery(this).attr("showNum") || 5; //ÿ�ε��������ʾ����

        var jQuerychildren = jQuery(this).children();
        if (jQuerychildren.length > showNum) {
            for (var i = defaultNum; i < jQuerychildren.length; i++) {
                 jQuerychildren.eq(i).hide();
            }
           jQuery("<div class='zz-loading-more cl'>���ظ���</div>").insertAfter(jQuery(this)).click(function () {
                if (zz_thread_lists(jQuerychildren, showNum) <= 0) {
                    jQuery(this).html("- û�и������� -");
                  };
              });
            }
        });
   });
</script> 

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{subtemplate common/footer}-->

