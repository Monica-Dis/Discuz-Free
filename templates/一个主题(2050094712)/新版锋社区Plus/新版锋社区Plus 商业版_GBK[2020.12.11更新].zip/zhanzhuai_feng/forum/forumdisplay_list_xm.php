<?PHP exit('��֧������ - վק��� https://dism.taobao.com/?@57900.developer');?>	
     <!--{if $quicksearchlist && !$_GET['archiveid']}-->
	      <!--{subtemplate forum/search_sortoption}-->
     <!--{/if}-->
<div id="threadlist" class="zz_frame_c tl" {if $_G['uid']} style="position: relative;"{/if}>
       <div class="zz_aw_threadlist cl">
            <div class="zz_tf_main cl">
	             <div class="zz_tf_left z">
				      <ul>
						  <li{if $_GET['specialtype']} class="on"{/if}><a id="filter_special" href="javascript:;" onclick="showMenu(this.id)" class="zz_showmenu" initialized="true"><!--{if $_GET['specialtype'] == 'poll'}-->{lang thread_poll}<!--{elseif $_GET['specialtype'] == 'trade'}-->{lang thread_trade}<!--{elseif $_GET['specialtype'] == 'reward'}-->{lang thread_reward}<!--{elseif $_GET['specialtype'] == 'activity'}-->{lang thread_activity}<!--{elseif $_GET['specialtype'] == 'debate'}-->{lang thread_debate}<!--{else}-->{lang threads_all}<!--{/if}--></a></li>

                          <li{if $_GET['orderby'] == 'replies'} class="on"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">���»ظ�</a></li>
                          <li{if $_GET['orderby'] == 'dateline'} class="on"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">���·���</a></li>
						  <li{if $_GET['filter'] == 'heat'} class="on"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����</a></li>
						  <li{if $_GET['filter'] == 'digest'} class="on"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����</a></li>
					  </ul>
                 </div>
				  <div class="zhanzhuai_shuaix y">
	                  <a id="atarget" {if $_G['cookie']['atarget'] > 0}onclick="setatarget(-1)" class="atarget_1"{else}onclick="setatarget(1)"{/if} title="{lang new_window_thread}" style="margin-right: 0;"><small></small>{lang new_window}</a>
	                  <!--{if empty($_G['forum']['picstyle'])}-->			
	                  <!--{else}-->
                          <span class="pipe">|</span><a {if empty($_G['cookie']['forumdefstyle'])} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="chked2"{else} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="unchk2"{/if} title="{lang view_thread_imagemode}{lang view_thread}"><small></small>ͼƬģʽ</a>
	                  <!--{/if}-->
					  <!--{hook/forumdisplay_filter_extra}-->
                 </div>
            </div>

	    
		<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
			<script type="text/javascript">var lasttime = $_G['timestamp'];var listcolspan= '{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}6{else}5{/if}';</script>
		<!--{/if}-->
		<div id="forumnew" style="display:none"></div>
		<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="listextra" value="$extra" />

			   <!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
					<div class="zz_fgonggao cl">
                         <div class="tlarea cl">
							  <span class="zhanzhuai_ficn"><i class="iconfont icon-notification"></i>{lang announcement}:</span>
							  <span class="zz_fgonggao_text"><!--{if empty($announcement['type'])}--><a href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]" target="_blank"><em>$announcement[subject]</em>@ $announcement[starttime]</a><!--{else}--><a href="$announcement[message]" target="_blank"><em>$announcement[subject]</em>@ $announcement[starttime]</a><!--{/if}--></span>
                         </div>
				    </div>
				<!--{/if}-->
				<!--{if $_G['forum_threadcount']}-->
					<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
					<div class="zz_forumlist_dz">
					<ul>
						<!--{eval $t==0;}-->
						<!--{loop $_G['forum_threadlist'] $key $thread}-->	
							<!--{if $separatepos <= $key + 1}-->
								<!--{ad/threadlist}-->
							<!--{/if}-->
							<li class="zz_aw_item {if !$_GET['archiveid'] && $_G['forum']['ismoderator']}zz_aw_manager {/if}{if $t==0}zz_li0 {/if}cl" id="$thread[id]"{if $_G['hiddenexists'] && $thread['hidden']} style='display:none'{/if}>
							    <div class="zz_aw_box cl">
								 <!--{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}-->
                                        <div class="zz_aw_operate">
                                            <!--{if $thread['fid'] == $_G[fid]}-->
											<!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
												<input onclick="tmodclick(this)" type="checkbox" name="moderate[]" value="$thread[tid]" />
											<!--{else}-->
												<input type="checkbox" disabled="disabled" />
											<!--{/if}-->
										<!--{else}-->
											<input type="checkbox" disabled="disabled" />
										<!--{/if}-->
                                        </div>
                                      <!--{/if}-->

								 <div class="zz_aw_user_avt z">
									  <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank"><!--{avatar($thread[authorid],middle)}--></a>
								 </div>

                                 <div class="zz_aw_content">
								      <div class="zz_aw_title cl">
                                            <a href="javascript:;" id="content_$thread[tid]" class="showcontent y" title="{lang content_actions}" onclick="CONTENT_TID='$thread[tid]';CONTENT_ID='$thread[id]';showMenu({'ctrlid':this.id,'menuid':'content_menu'})"></a>
                                            <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                                                <a href="javascript:;" onclick="hideStickThread('$thread[tid]')" class="showhide y" title="{lang hidedisplayorder}">{lang hidedisplayorder}</a></em>
                                            <!--{/if}-->
                                            <!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
                                                    <!--{eval $thread[tid]=$thread[closed];}-->
                                            <!--{/if}-->
                                            <!--{if !$_G['setting']['forumdisplaythreadpreview'] && !($thread['readperm'] && $thread['readperm'] > $_G['group']['readaccess'] && !$_G['forum']['ismoderator'] && $thread['authorid'] != $_G['uid'])}-->
                                                <!--{if !(!empty($_G['setting']['antitheft']['allow']) && empty($_G['setting']['antitheft']['disable']['thread']) && empty($_G['forum']['noantitheft']))}-->
                                                    <a class="tdpre y" href="javascript:;" onclick="previewThread('{echo $thread['moved'] ? $thread[closed] : $thread[tid]}', '$thread[id]');">{lang preview}</a>
                                                <!--{/if}-->
                                            <!--{/if}-->

                                            <!--{hook/forumdisplay_thread $key}-->
                                            
                                            <!--{if $thread['moved']}-->
                                                {lang thread_moved}:<!--{eval $thread[tid]=$thread[closed];}-->
                                            <!--{/if}-->
    
											<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} class="s">$thread[subject]</a>
											    <!--{if $thread['attachment'] == 2}-->
                                                    <img src="$_G['style']['styleimgdir']/zz_image.png" alt="attach_img" title="{lang attach_img}" align="absmiddle" />
                                                <!--{elseif $thread['attachment'] == 1}-->
                                                    <img src="$_G['style']['styleimgdir']/zz_common.png" alt="attachment" title="{lang attachment}" align="absmiddle" />
                                                <!--{/if}-->
												<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
											        <img src="$_G['style']['styleimgdir']/zz_pin.png" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" align="absmiddle" />
										        <!--{/if}-->
                                            <!--{if $_G['setting']['threadhidethreshold'] && $thread['hidden'] >= $_G['setting']['threadhidethreshold']}--><span class="xg1">{lang hidden}</span>&nbsp;<!--{/if}-->
                                            <!--{if $thread[icon] >= 0}-->
                                                <img src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" />
                                            <!--{/if}-->
                                            <!--{if $thread['rushreply']}-->
                                                <img src="{IMGDIR}/rushreply_s.png" alt="{lang rushreply}" align="absmiddle" />
                                                <!--{if $rushinfo[$thread[tid]]}-->
                                                <span id="rushtimer_$thread[tid]"> {lang havemore_special} <span id="rushtimer_body_$thread[tid]"></span> <script language="javascript">settimer($rushinfo[$thread[tid]]['timer'], 'rushtimer_body_$thread[tid]');</script>{if $rushinfo[$thread[tid]]['timertype'] == 'start'} {lang header_start} {else} {lang over} {/if} {lang right_special}</span>
                                                <!--{/if}-->
                                            <!--{/if}-->
                                            <!--{if $stemplate && $sortid}-->$stemplate[$sortid][$thread[tid]]<!--{/if}-->
                                            <!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->
                                            <!--{if $thread['price'] > 0}-->
                                                <!--{if $thread['special'] == '3'}-->
                                                - <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1" title="{lang show_rewarding_only}"><span class="xi1">[{lang thread_reward} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span></a>
                                                <!--{else}-->
                                                - [{lang price} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
                                                <!--{/if}-->
                                            <!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
                                                - <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2" title="{lang show_rewarded_only}">[{lang reward_solved}]</a>
                                            <!--{/if}-->
                                            <!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
                                                <img src="$_G['style']['styleimgdir']/zz_digest.png" align="absmiddle" alt="digest" title="{lang thread_digest} $thread[digest]" />
                                            <!--{/if}-->
                                            <!--{if $thread['displayorder'] == 0}-->
                                                <!--{if $thread[recommendicon] && $filter != 'recommend'}-->
                                                    <img src="{IMGDIR}/recommend_$thread[recommendicon].gif" align="absmiddle" alt="recommend" title="{lang thread_recommend} $thread[recommends]" />
                                                <!--{/if}-->
                                                <!--{if $thread[heatlevel]}-->
                                                    <img src="$_G['style']['styleimgdir']/zz_hot.png" align="absmiddle" alt="heatlevel" title="{lang heats}: {$thread[heats]}" />
                                                <!--{/if}-->
                                                <!--{if $thread['rate'] > 0}-->
                                                    <img src="{IMGDIR}/agree.gif" align="absmiddle" alt="agree" title="{lang rate_credit_add}" />
                                                <!--{elseif $thread['rate'] < 0}-->
                                                    <img src="{IMGDIR}/disagree.gif" align="absmiddle" alt="disagree" title="{lang posts_deducted}" />
                                                <!--{/if}-->
                                            <!--{/if}-->
                                            <!--{if $thread['replycredit'] > 0}-->
                                                - <span class="xi1">[{lang replycredit} <strong> $thread['replycredit']</strong> ]</span>
                                            <!--{/if}-->
                                            <!--{hook/forumdisplay_thread_subject $key}-->
                                            <!--{if $thread[multipage]}-->
                                                <span class="tps">$thread[multipage]</span>
                                            <!--{/if}-->
                                            <!--{if $thread['weeknew']}-->
                                                <a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost" class="xi1">New</a>
                                            <!--{/if}-->
                                            <!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
                                                <!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
                                                    <!--{eval $thread[tid]=$thread[closed];}-->
                                                <!--{/if}-->
                                                <!--{if $groupnames[$thread[tid]]}-->
                                                    <span class="fromg xg1"> [{lang from}: <a href="forum.php?mod=group&fid={$groupnames[$thread[tid]][fid]}" target="_blank" class="xg1">{$groupnames[$thread[tid]][name]}</a>]</span>
                                                <!--{/if}-->
                                            <!--{/if}-->
                                        </div>

										<div class="zz_aw_meta cl">
                                             <div class="zz_aw_meta_text z cl">	
                                                  <div class="zz_aw_meta_author-basic" style="margin-right: 11px;">
												       <!--{if $thread['authorid'] && $thread['author']}-->
                                                           <span><a href="home.php?mod=space&uid=$thread[authorid]" c="1"{if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if}>$thread[author]</a></span>
														   <!--{if !empty($verify[$thread['authorid']])}--> <span style=" margin: 0 5px;">$verify[$thread[authorid]]</span><!--{/if}-->
														<!--{else}-->
														   <a href="javascript:;"><span>$_G[setting][anonymoustext]</span></a>
														<!--{/if}-->
                                                  </div>
												  
												  <span class="z" style=" -webkit-transform: scale(0.80);transform: scale(0.80);">|</span>

												  <!--{hook/forumdisplay_author $key}-->
												  <!--{if $thread[replies] >0}-->
												       <div class="zz_aw_meta_last_c z" style="margin-left: 11px;">
											                <!--{if $thread['lastposter']}--><span>@</span> <span><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}" c="1">$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]</span><!--{/if}-->
										                    <span>���ظ�</span>
                                                            <span><a href="{if $thread[digest] != -2 && !$thread[ordertype]}forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost$highlight#lastpost{else}forum.php?mod=viewthread&tid=$thread[tid]{if !$thread[ordertype]}&page={echo max(1, $thread[pages]);}{/if}{/if}">$thread[lastpost]</a></span>
												        </div>
												   <!--{else}-->
												        <div class="zz_aw_meta_last_c z" style="margin-left: 11px;">
														     <span>������</span>
															 <span{if $thread['istoday']} class="xi1"{/if}>$thread[dateline]</span>
                                                        </div>
												   <!--{/if}-->
 
												  <div class="zz_aw_meta_form z" style="margin-left: 10px;">
                                                       $thread[typehtml] $thread[sorthtml]
                                                  </div>

												  <!--{if CURMODULE == 'guide'}-->
										            <div>
													   <a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$forumnames[$thread[fid]]['name']</a>
                                                    </div>
									              <!--{/if}-->
                                             </div>
                       
											 <div class="y">
											      <span class="zz_aw_meta_viem"><img src="$_G['style']['styleimgdir']/zzv_icon.png" /><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
                                                  <span class="zz_aw_meta_reply"><img src="$_G['style']['styleimgdir']/zzr_icon.png" />{$thread[replies]}</span>
											 </div>
                                          </div>
                                      </div>
								  </div>
							 </li>
						<!--{eval $t++;}-->
						<!--{/loop}-->
						</ul>
						
						<!--{if $_G['hiddenexists']}-->							
							<div id="hiddenthread"{if $thread['hidden']} class="last"{/if}><a href="javascript:;" onclick="display_blocked_thread()">{lang other_reply_hide}</a></div>
						<!--{/if}-->
				   </div>
				<!--{else}-->
					
	                <div class="zhanzhuai-waterfall">
	                 <ul id="waterfall" class="waterfall cl">
						 <!--{loop $_G['forum_threadlist'] $key $thread}-->
						     <!--{if $zz_fpic ==2}-->
						         <!--{eval include TPLDIR.'/php/thread_preview.php';}-->
						     <!--{/if}-->
						     <!--{if $_G['hiddenexists'] && $thread['hidden']}-->
							     <!--{eval continue;}-->
						     <!--{/if}-->
						     <!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
							     <!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
								     <!--{eval $thread[tid]=$thread[closed];}-->
							     <!--{/if}-->
						     <!--{/if}-->
						     <!--{eval $waterfallwidth = $_G[setting][forumpicstyle][thumbwidth] + 0; }-->
		                     <li style="width:{$waterfallwidth}px">
			                     <!--{if $thread['cover']}--><div class="mbpho"><!--{/if}-->
			                     <!--{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}-->
				                     <div style=" position: absolute;top: 3px;right: 3px;border-width: 0 0 1px 1px;border-style: solid;border-color: #e0e0e0;background: #FFF;border-radius: 50%;z-index: 199;">
				                         <!--{if $thread['fid'] == $_G[fid]}-->
					                         <!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
						                          <input onclick="tmodclick(this)" type="checkbox" name="moderate[]" value="$thread[tid]" />
					                         <!--{else}-->
						                          <input type="checkbox" disabled="disabled" />
					                         <!--{/if}-->
				                         <!--{else}-->
					                          <input type="checkbox" disabled="disabled" />
				                         <!--{/if}-->
				                      </div>
			                     <!--{/if}-->
                                 <!--{if $thread['cover']}-->
			                          <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" class="bor-img">
					                      <img src="$thread[coverpath]" alt="$thread[subject]" width="{$_G[setting][forumpicstyle][thumbwidth]}" />
					                      <u></u>
										  <span class="collbtn">
										     <i>�Ķ�  <!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></i><i>���� $thread[allreplies]</i>
										  </span>
                                      </a>
		                         </div>
		                         <!--{/if}-->
                                 <div class="wooscr" {if !$thread['cover']}style="border: 1px solid #e0e0e0;"{/if}>
		                              <div class="zhazhuai-tit bgwhite" {if !$thread['cover']}style="padding: 10px 33px 10px 15px;"{/if}>
		                                   <!--{hook/forumdisplay_thread $key}-->
                                           <div class="zz_dtit cl">
			                                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]">$thread[subject]</a>
			                               </div>
                                           <div class="zhazhuai-tit-bottom cl">
                                                <span class="zz_f_dz"><sup></sup><!--{if $thread[recommend_add]}-->$thread[recommend_add]<!--{else}-->0<!--{/if}--></span>
					                            <span class="view"><sup></sup><!--{if $thread[favtimes]}-->$thread[favtimes]<!--{else}-->0<!--{/if}--></span>
                                           </div>
			                               <!--{hook/forumdisplay_author $key}-->
                                      </div>
                                      <div class="zf-bottom cl">
                                           <span class="user-sta-pic"><a href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread[authorid],middle)}--></a></span>
                                           <div class="user-sta">
						                        <span class="name">
												      <!--{if $thread['authorid'] && $thread['author']}-->
													      <a href="home.php?mod=space&uid=$thread[authorid]">$thread[author]</a>
													  <!--{else}-->
										                  $_G[setting][anonymoustext]
									                  <!--{/if}-->
									            </span>
							                    <span class="time">������&nbsp;
												      <!--{if !empty($thread[typehtml])}-->
			                                              $thread[typehtml]
				                                      <!--{elseif !empty($thread[sorthtml])}-->
				                                          $thread[sorthtml]
				                                      <!--{else}-->
				                                          $_G['forum'][name]
				                                      <!--{/if}-->
												</span>
						                    </div>
                                        </div>
				                   </div>
                               </li>
							<!--{/loop}-->
						</ul>
                        </div>

						<div id="tmppic" style="display: none;"></div>
						<script type="text/javascript" src="$_G['style']['styleimgdir']/js/redef.js?{VERHASH}"></script>
						<script type="text/javascript" reload="1">
						var wf = {};

						_attachEvent(window, "load", function () {
							if($("waterfall")) {
								wf = waterfall();
							}

							<!--{if $page < $_G['page_next'] && !$subforumonly}-->
								var page = $page + 1,
									maxpage = Math.min($page + 10,$maxpage + 1),
									stopload = 0,
									scrolltimer = null,
									tmpelems = [],
									tmpimgs = [],
									markloaded = [],
									imgsloaded = 0,
									loadready = 0,
									showready = 1,
									nxtpgurl = 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&page=',
									wfloading = "<img src=\"{IMGDIR}/loading.gif\" alt=\"\" width=\"16\" height=\"16\" class=\"vm\" /> {lang onloading}...",
									pgbtn = $("pgbtn").getElementsByTagName("a")[0];

								function loadmore() {
									var url = nxtpgurl + page + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
									var x = new Ajax("HTML");
									x.get(url, function (s) {
										s = s.replace(/\n|\r/g, "");
										if(s.indexOf("id=\"pgbtn\"") == -1) {
											$("pgbtn").style.display = "none";
											stopload++;
											window.onscroll = null;
										}

										s = s.substring(s.indexOf("<ul id=\"waterfall\""), s.indexOf("<div id=\"tmppic\""));
										s = s.replace("id=\"waterfall\"", "");
										$("tmppic").innerHTML = s;
										loadready = 1;
									});
								}

								window.onscroll = function () {
									if(scrolltimer == null) {
										scrolltimer = setTimeout(function () {
											try {
												if(page < maxpage && stopload < 2 && showready && ((document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.clientHeight + 500) >= document.documentElement.scrollHeight) {
													pgbtn.innerHTML = wfloading;
													loadready = 0;
													showready = 0;
													loadmore();
													tmpelems = $("tmppic").getElementsByTagName("li");
													var waitingtimer = setInterval(function () {
														stopload >= 2 && clearInterval(waitingtimer);
														if(loadready && stopload < 2) {
															if(!tmpelems.length) {
																page++;
																pgbtn.href = nxtpgurl + Math.min(page, $maxpage);
																pgbtn.innerHTML = "{lang next_page_extra}";
																showready = 1;
																clearInterval(waitingtimer);
															}
															for(var i = 0, j = tmpelems.length; i < j; i++) {
																if(tmpelems[i]) {
																	tmpimgs = tmpelems[i].getElementsByTagName("img");
																	imgsloaded = 0;
																	for(var m = 0, n = tmpimgs.length; m < n; m++) {
																		tmpimgs[m].onerror = function () {
																			this.style.display = "none";
																		};
																		markloaded[m] = tmpimgs[m].complete ? 1 : 0;
																		imgsloaded += markloaded[m];
																	}
																	if(imgsloaded == tmpimgs.length) {
																		$("waterfall").appendChild(tmpelems[i]);
																		wf = waterfall({
																			"index": wf.index,
																			"totalwidth": wf.totalwidth,
																			"totalheight": wf.totalheight,
																			"columnsheight": wf.columnsheight
																		});
																	}
																}
															}
														}
													}, 40);
												}
											} catch(e) {}
											scrolltimer = null;
										}, 320);
									}
								};
							<!--{/if}-->

						});

						</script>
					<!--{/if}-->
				<!--{else}-->
					<div class="zz_emp_box cl">
					     <div class="zz_emp_icon cl"><img src="$_G['style']['styleimgdir']/zz_nodata.png" /></div>
						 <div class="zz_emp_text cl">{lang forum_nothreads}</div>
					</div>
					<!-- end of table "forum_G[fid]" branch 3/3 -->
				<!--{/if}-->
			<!--{if $_G['forum']['ismoderator'] && $_G['forum_threadcount']}-->
				<!--{template forum/topicadmin_modlayer}-->
			<!--{/if}-->
			</div>
		</form>
	<!--{hook/forumdisplay_threadlist_bottom}-->
</div>

<!--{if $multipage && $filter != 'hot'}-->
	<!--{if !($_G[forum][picstyle] && !$_G[cookie][forumdefstyle])}-->
		<a class="bm_h" href="javascript:;" rel="$multipage_more" curpage="$page" id="autopbn" totalpage="$maxpage" picstyle="$_G[forum][picstyle]" forumdefstyle="$_G[cookie][forumdefstyle]">������ظ���</a>
		<script type="text/javascript" src="{$_G[setting][jspath]}autoloadpage.js?{VERHASH}"></script>
	<!--{else}-->
		<div id="pgbtn" class="pgbtn"><a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}&page=$nextpage" hidefocus="true">{lang next_page_extra}</a></div>
	<!--{/if}-->
<!--{/if}-->

<!--{if !($_G[forum][picstyle] && !$_G[cookie][forumdefstyle])}-->
    <div class="bm bw0 pgs cl mt10">
		 <span id="fd_page_bottom">$multipage</span>
		 <!--{hook/forumdisplay_postbutton_bottom}-->
    </div>
<!--{/if}-->

<!--{if !IS_ROBOT}-->
	<div id="filter_special_menu" class="p_pop" style="display:none" change="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter='+$('filter_special').value">
		<ul>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all}{lang forum_threads}</a></li>
			<!--{if $showpoll}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_poll}</a></li><!--{/if}-->
			<!--{if $showtrade}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_trade}</a></li><!--{/if}-->
			<!--{if $showreward}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_reward}</a></li><!--{/if}-->
			<!--{if $showactivity}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_activity}</a></li><!--{/if}-->
			<!--{if $showdebate}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_debate}</a></li><!--{/if}-->
		</ul>
	</div>
	<div id="filter_reward_menu" class="p_pop" style="display:none" change="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype='+$('filter_reward').value">
		<ul>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all_reward}</a></li>
			<!--{if $showpoll}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1">{lang rewarding}</a></li><!--{/if}-->
			<!--{if $showtrade}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2">{lang reward_solved}</a></li><!--{/if}-->
		</ul>
	</div>
	<div id="filter_dateline_menu" class="p_pop" style="display:none">
		<ul class="pop_moremenu">
			<li>
			<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all}{lang search_any_date}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang last_1_days}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang last_2_days}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_one_week}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_one_month}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_three_month}</a>
			</li>
		</ul>
	</div>
	<!--{if !$_G['setting']['closeforumorderby']}-->
	<div id="filter_orderby_menu" class="p_pop" style="display:none">
		<ul>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_default_sort}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang views}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1">{lang digest_posts}</a></li>
		</ul>
	</div>
	<!--{/if}-->
	<div id="filter_time_menu" class="p_pop" style="display:none">
		<ul>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['dateline']}class="xw1"{/if}>{lang all}{lang search_any_date}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '86400'}class="xw1"{/if}>{lang last_1_days}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '172800'}class="xw1"{/if}>{lang last_2_days}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '604800'}class="xw1"{/if}>{lang list_one_week}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '2592000'}class="xw1"{/if}>{lang list_one_month}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '7948800'}class="xw1"{/if}>{lang list_three_month}</a></li>
		</ul>
	</div>
<!--{/if}-->
