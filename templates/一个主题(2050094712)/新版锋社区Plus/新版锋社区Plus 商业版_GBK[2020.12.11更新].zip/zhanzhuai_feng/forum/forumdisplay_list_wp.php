<?PHP exit('��֧������ - վק��� https://dism.taobao.com/?@57900.developer');?>	
     <!--{if $quicksearchlist && !$_GET['archiveid']}-->
	      <!--{subtemplate forum/search_sortoption}-->
     <!--{/if}-->
<div id="threadlist" class="zz_frame_c tl" {if $_G['uid']} style="position: relative;"{/if}>
       <div class="zz_aw_threadlist cl">
            <div class="zz_tf_main cl">
	             <div class="zz_tf_left z">
				      <ul>
						  <li{if $_GET['specialtype']} class="on"{/if}><a id="filter_special" href="javascript:;" onclick="showMenu(this.id)" class="zz_showmenu" initialized="true"><!--{if $_GET['specialtype'] == 'poll'}-->{lang thread_poll}<!--{elseif $_GET['specialtype'] == 'trade'}-->{lang thread_trade}<!--{elseif $_GET['specialtype'] == 'reward'}-->{lang thread_reward}<!--{elseif $_GET['specialtype'] == 'activity'}-->{lang thread_activity}<!--{elseif $_GET['specialtype'] == 'debate'}-->{lang thread_debate}<!--{else}-->{lang threads_all}<!--{/if}--></a></li>

                          <li{if $_GET['orderby'] == 'replies'} class="on"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">���»ظ�</a></li>
                          <li{if $_GET['orderby'] == 'dateline'} class="on"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">���·���</a></li>
						  <li{if $_GET['filter'] == 'heat'} class="on"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����</a></li>
						  <li{if $_GET['filter'] == 'digest'} class="on"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����</a></li>
					  </ul>
                 </div>
				  <div class="zhanzhuai_shuaix y">
	                  <a id="atarget" {if $_G['cookie']['atarget'] > 0}onclick="setatarget(-1)" class="atarget_1"{else}onclick="setatarget(1)"{/if} title="{lang new_window_thread}" style="margin-right: 0;"><small></small>{lang new_window}</a>
	                  <!--{if empty($_G['forum']['picstyle'])}-->			
	                  <!--{else}-->
                          <span class="pipe">|</span><a {if empty($_G['cookie']['forumdefstyle'])} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="chked2"{else} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="unchk2"{/if} title="{lang view_thread_imagemode}{lang view_thread}"><small></small>ͼƬģʽ</a>
	                  <!--{/if}-->
					  <!--{hook/forumdisplay_filter_extra}-->
                 </div>
            </div>

	    
		<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
			<script type="text/javascript">var lasttime = $_G['timestamp'];var listcolspan= '{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}6{else}5{/if}';</script>
		<!--{/if}-->
		<div id="forumnew" style="display:none"></div>
		<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="listextra" value="$extra" />

			   <!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
					<div class="zz_fgonggao cl">
                         <div class="tlarea cl">
							  <span class="zhanzhuai_ficn"><i class="iconfont icon-notification"></i>{lang announcement}:</span>
							  <span class="zz_fgonggao_text"><!--{if empty($announcement['type'])}--><a href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]" target="_blank"><em>$announcement[subject]</em>@ $announcement[starttime]</a><!--{else}--><a href="$announcement[message]" target="_blank"><em>$announcement[subject]</em>@ $announcement[starttime]</a><!--{/if}--></span>
                         </div>
				    </div>
				<!--{/if}-->
				<!--{if $_G['forum_threadcount']}-->
					<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
					<div class="zz_pnews_list cl">
					    <ul class="zz_threads_list">
						<!--{eval $t=1;}-->
						<!--{loop $_G['forum_threadlist'] $key $thread}-->
						    <!--{eval require_once libfile('function/post');$zzpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);$zzpost['message'] = trim(messagecutstr($zzpost['message'], 160));}--> 
                            <!--{eval  $zzthreadtable =  DB::fetch_all('SELECT * FROM '.DB::table('forum_attachment').' WHERE tid = '. $thread['tid'].' LIMIT  0 ,'. 1);}-->
							<!--{if $separatepos <= $key + 1}-->
								<!--{ad/threadlist}-->
							<!--{/if}-->
							<li class="zz_list_item {if !$_GET['archiveid'] && $_G['forum']['ismoderator']}zz_aw_manager {/if}{if $t==1}zz_item1 {/if}cl" id="$thread[id]"{if $_G['hiddenexists'] && $thread['hidden']} style='display:none'{/if}>
							    <div class="zz_item_pic">
		                             <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]">
		                                <!--{if $thread['attachment'] == 2}-->
										    <!--{loop $zzthreadtable $pic}-->  
                                                <!--{eval $zzthreadpic = getforumimg($pic[aid], 0, 200, 135); }--> 
                                                <img src="$zzthreadpic" alt="$thread[subject]" /></a> 
                                            <!--{/loop}--> 
									    <!--{else}-->
										    <img src="$_G['style']['styleimgdir']/zz_wp_dpic.png" alt="$thread[subject]" />
                                        <!--{/if}-->
                                     </a>
	                            </div>

							   <div class="zz_item_content">
							        <div class="zz_item_title">
									      <!--{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}-->
                                              <div class="zz_aw_operate z" style="position: relative;top: 4px;margin-right: 5px;">
                                                   <!--{if $thread['fid'] == $_G[fid]}-->
											           <!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
												            <input onclick="tmodclick(this)" type="checkbox" name="moderate[]" value="$thread[tid]" />
											           <!--{else}-->
												            <input type="checkbox" disabled="disabled" />
											           <!--{/if}-->
										           <!--{else}-->
											           <input type="checkbox" disabled="disabled" />
										           <!--{/if}-->
                                               </div>
                                            <!--{/if}-->

                                            <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                                                <a href="javascript:;" onclick="hideStickThread('$thread[tid]')" class="showhide y" title="{lang hidedisplayorder}">{lang hidedisplayorder}</a></em>
                                            <!--{/if}-->
                                            <!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
                                                    <!--{eval $thread[tid]=$thread[closed];}-->
                                            <!--{/if}-->

                                            <!--{hook/forumdisplay_thread $key}-->
                                            
                                            <!--{if $thread['moved']}-->
                                                {lang thread_moved}:<!--{eval $thread[tid]=$thread[closed];}-->
                                            <!--{/if}-->
    
											<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} class="s">$thread[subject]</a>
                                        </div>

										<p class="zz_item_desc">$zzpost['message']</p>

										<div class="zz_item_info">          
	                                         <span class="zz_item_info_a"><a href="home.php?mod=space&uid=$thread[authorid]" target="_blank"><!--{avatar($thread[authorid],middle)}-->$thread[author]</a></span>
                                             <span class="zz_item_info_d" style="padding: 0 10px !important;">$thread[dateline]</span> 
                                             <span class="zz_item_info_r">{$thread[replies]}</span>
											 <span class="zz_item_info_v"><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span> 
                                         </div>								
                                    </div>
							 </li>
						<!--{eval $t++;}-->
						<!--{/loop}-->
						</ul>
						
						<!--{if $_G['hiddenexists']}-->							
							<div id="hiddenthread"{if $thread['hidden']} class="last"{/if}><a href="javascript:;" onclick="display_blocked_thread()">{lang other_reply_hide}</a></div>
						<!--{/if}-->
				   </div>
				<!--{else}-->
					
	                <div class="zhanzhuai-waterfall">
	                 <ul id="waterfall" class="waterfall cl">
						 <!--{loop $_G['forum_threadlist'] $key $thread}-->
						     <!--{if $zz_fpic ==2}-->
						         <!--{eval include TPLDIR.'/php/thread_preview.php';}-->
						     <!--{/if}-->
						     <!--{if $_G['hiddenexists'] && $thread['hidden']}-->
							     <!--{eval continue;}-->
						     <!--{/if}-->
						     <!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
							     <!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
								     <!--{eval $thread[tid]=$thread[closed];}-->
							     <!--{/if}-->
						     <!--{/if}-->
						     <!--{eval $waterfallwidth = $_G[setting][forumpicstyle][thumbwidth] + 0; }-->
		                     <li style="width:{$waterfallwidth}px">
			                     <!--{if $thread['cover']}--><div class="mbpho"><!--{/if}-->
			                     <!--{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}-->
				                     <div style=" position: absolute;top: 3px;right: 3px;border-width: 0 0 1px 1px;border-style: solid;border-color: #e0e0e0;background: #FFF;border-radius: 50%;z-index: 199;">
				                         <!--{if $thread['fid'] == $_G[fid]}-->
					                         <!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
						                          <input onclick="tmodclick(this)" type="checkbox" name="moderate[]" value="$thread[tid]" />
					                         <!--{else}-->
						                          <input type="checkbox" disabled="disabled" />
					                         <!--{/if}-->
				                         <!--{else}-->
					                          <input type="checkbox" disabled="disabled" />
				                         <!--{/if}-->
				                      </div>
			                     <!--{/if}-->
                                 <!--{if $thread['cover']}-->
			                          <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" {if $thread['isgroup'] == 1 || $thread['forumstick'] || CURMODULE == 'guide'} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" class="bor-img">
					                      <img src="$thread[coverpath]" alt="$thread[subject]" width="{$_G[setting][forumpicstyle][thumbwidth]}" />
					                      <u></u>
										  <span class="collbtn">
										     <i>�Ķ�  <!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></i><i>���� $thread[allreplies]</i>
										  </span>
                                      </a>
		                         </div>
		                         <!--{/if}-->
                                 <div class="wooscr" {if !$thread['cover']}style="border: 1px solid #e0e0e0;"{/if}>
		                              <div class="zhazhuai-tit bgwhite" {if !$thread['cover']}style="padding: 10px 33px 10px 15px;"{/if}>
		                                   <!--{hook/forumdisplay_thread $key}-->
                                           <div class="zz_dtit cl">
			                                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]">$thread[subject]</a>
			                               </div>
                                           <div class="zhazhuai-tit-bottom cl">
                                                <span class="zz_f_dz"><sup></sup><!--{if $thread[recommend_add]}-->$thread[recommend_add]<!--{else}-->0<!--{/if}--></span>
					                            <span class="view"><sup></sup><!--{if $thread[favtimes]}-->$thread[favtimes]<!--{else}-->0<!--{/if}--></span>
                                           </div>
			                               <!--{hook/forumdisplay_author $key}-->
                                      </div>
                                      <div class="zf-bottom cl">
                                           <span class="user-sta-pic"><a href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread[authorid],middle)}--></a></span>
                                           <div class="user-sta">
						                        <span class="name">
												      <!--{if $thread['authorid'] && $thread['author']}-->
													      <a href="home.php?mod=space&uid=$thread[authorid]">$thread[author]</a>
													  <!--{else}-->
										                  $_G[setting][anonymoustext]
									                  <!--{/if}-->
									            </span>
							                    <span class="time">������&nbsp;
												      <!--{if !empty($thread[typehtml])}-->
			                                              $thread[typehtml]
				                                      <!--{elseif !empty($thread[sorthtml])}-->
				                                          $thread[sorthtml]
				                                      <!--{else}-->
				                                          $_G['forum'][name]
				                                      <!--{/if}-->
												</span>
						                    </div>
                                        </div>
				                   </div>
                               </li>
							<!--{/loop}-->
						</ul>
                        </div>

						<div id="tmppic" style="display: none;"></div>
						<script type="text/javascript" src="$_G['style']['styleimgdir']/js/redef.js?{VERHASH}"></script>
						<script type="text/javascript" reload="1">
						var wf = {};

						_attachEvent(window, "load", function () {
							if($("waterfall")) {
								wf = waterfall();
							}

							<!--{if $page < $_G['page_next'] && !$subforumonly}-->
								var page = $page + 1,
									maxpage = Math.min($page + 10,$maxpage + 1),
									stopload = 0,
									scrolltimer = null,
									tmpelems = [],
									tmpimgs = [],
									markloaded = [],
									imgsloaded = 0,
									loadready = 0,
									showready = 1,
									nxtpgurl = 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&page=',
									wfloading = "<img src=\"{IMGDIR}/loading.gif\" alt=\"\" width=\"16\" height=\"16\" class=\"vm\" /> {lang onloading}...",
									pgbtn = $("pgbtn").getElementsByTagName("a")[0];

								function loadmore() {
									var url = nxtpgurl + page + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
									var x = new Ajax("HTML");
									x.get(url, function (s) {
										s = s.replace(/\n|\r/g, "");
										if(s.indexOf("id=\"pgbtn\"") == -1) {
											$("pgbtn").style.display = "none";
											stopload++;
											window.onscroll = null;
										}

										s = s.substring(s.indexOf("<ul id=\"waterfall\""), s.indexOf("<div id=\"tmppic\""));
										s = s.replace("id=\"waterfall\"", "");
										$("tmppic").innerHTML = s;
										loadready = 1;
									});
								}

								window.onscroll = function () {
									if(scrolltimer == null) {
										scrolltimer = setTimeout(function () {
											try {
												if(page < maxpage && stopload < 2 && showready && ((document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.clientHeight + 500) >= document.documentElement.scrollHeight) {
													pgbtn.innerHTML = wfloading;
													loadready = 0;
													showready = 0;
													loadmore();
													tmpelems = $("tmppic").getElementsByTagName("li");
													var waitingtimer = setInterval(function () {
														stopload >= 2 && clearInterval(waitingtimer);
														if(loadready && stopload < 2) {
															if(!tmpelems.length) {
																page++;
																pgbtn.href = nxtpgurl + Math.min(page, $maxpage);
																pgbtn.innerHTML = "{lang next_page_extra}";
																showready = 1;
																clearInterval(waitingtimer);
															}
															for(var i = 0, j = tmpelems.length; i < j; i++) {
																if(tmpelems[i]) {
																	tmpimgs = tmpelems[i].getElementsByTagName("img");
																	imgsloaded = 0;
																	for(var m = 0, n = tmpimgs.length; m < n; m++) {
																		tmpimgs[m].onerror = function () {
																			this.style.display = "none";
																		};
																		markloaded[m] = tmpimgs[m].complete ? 1 : 0;
																		imgsloaded += markloaded[m];
																	}
																	if(imgsloaded == tmpimgs.length) {
																		$("waterfall").appendChild(tmpelems[i]);
																		wf = waterfall({
																			"index": wf.index,
																			"totalwidth": wf.totalwidth,
																			"totalheight": wf.totalheight,
																			"columnsheight": wf.columnsheight
																		});
																	}
																}
															}
														}
													}, 40);
												}
											} catch(e) {}
											scrolltimer = null;
										}, 320);
									}
								};
							<!--{/if}-->

						});

						</script>
					<!--{/if}-->
				<!--{else}-->
					<div class="zz_emp_box cl">
					     <div class="zz_emp_icon cl"><img src="$_G['style']['styleimgdir']/zz_nodata.png" /></div>
						 <div class="zz_emp_text cl">{lang forum_nothreads}</div>
					</div>
					<!-- end of table "forum_G[fid]" branch 3/3 -->
				<!--{/if}-->
			<!--{if $_G['forum']['ismoderator'] && $_G['forum_threadcount']}-->
				<!--{template forum/topicadmin_modlayer}-->
			<!--{/if}-->
			</div>
		</form>
	<!--{hook/forumdisplay_threadlist_bottom}-->
</div>

<!--{if $multipage && $filter != 'hot'}-->
	<!--{if !($_G[forum][picstyle] && !$_G[cookie][forumdefstyle])}-->
		<a class="bm_h" href="javascript:;" rel="$multipage_more" curpage="$page" id="autopbn" totalpage="$maxpage" picstyle="$_G[forum][picstyle]" forumdefstyle="$_G[cookie][forumdefstyle]">������ظ���</a>
		<script type="text/javascript" src="{$_G[setting][jspath]}autoloadpage.js?{VERHASH}"></script>
	<!--{else}-->
		<div id="pgbtn" class="pgbtn"><a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}&page=$nextpage" hidefocus="true">{lang next_page_extra}</a></div>
	<!--{/if}-->
<!--{/if}-->

<!--{if !($_G[forum][picstyle] && !$_G[cookie][forumdefstyle])}-->
    <div class="bm bw0 pgs cl mt10">
		 <span id="fd_page_bottom">$multipage</span>
		 <!--{hook/forumdisplay_postbutton_bottom}-->
    </div>
<!--{/if}-->

<!--{if !IS_ROBOT}-->
	<div id="filter_special_menu" class="p_pop" style="display:none" change="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter='+$('filter_special').value">
		<ul>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all}{lang forum_threads}</a></li>
			<!--{if $showpoll}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_poll}</a></li><!--{/if}-->
			<!--{if $showtrade}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_trade}</a></li><!--{/if}-->
			<!--{if $showreward}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_reward}</a></li><!--{/if}-->
			<!--{if $showactivity}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_activity}</a></li><!--{/if}-->
			<!--{if $showdebate}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_debate}</a></li><!--{/if}-->
		</ul>
	</div>
	<div id="filter_reward_menu" class="p_pop" style="display:none" change="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype='+$('filter_reward').value">
		<ul>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all_reward}</a></li>
			<!--{if $showpoll}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1">{lang rewarding}</a></li><!--{/if}-->
			<!--{if $showtrade}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2">{lang reward_solved}</a></li><!--{/if}-->
		</ul>
	</div>
	<div id="filter_dateline_menu" class="p_pop" style="display:none">
		<ul class="pop_moremenu">
			<li>
			<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all}{lang search_any_date}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang last_1_days}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang last_2_days}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_one_week}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_one_month}</a></li>
				<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_three_month}</a>
			</li>
		</ul>
	</div>
	<!--{if !$_G['setting']['closeforumorderby']}-->
	<div id="filter_orderby_menu" class="p_pop" style="display:none">
		<ul>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_default_sort}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang views}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">����</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1">{lang digest_posts}</a></li>
		</ul>
	</div>
	<!--{/if}-->
	<div id="filter_time_menu" class="p_pop" style="display:none">
		<ul>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['dateline']}class="xw1"{/if}>{lang all}{lang search_any_date}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '86400'}class="xw1"{/if}>{lang last_1_days}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '172800'}class="xw1"{/if}>{lang last_2_days}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '604800'}class="xw1"{/if}>{lang list_one_week}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '2592000'}class="xw1"{/if}>{lang list_one_month}</a></li>
			<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '7948800'}class="xw1"{/if}>{lang list_three_month}</a></li>
		</ul>
	</div>
<!--{/if}-->
