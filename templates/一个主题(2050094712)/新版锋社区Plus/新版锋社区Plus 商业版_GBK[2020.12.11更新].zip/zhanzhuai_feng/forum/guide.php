<?PHP exit('��֧������ - վק��� https://dism.taobao.com/?@57900.developer');?>	
<!--{template common/header}-->
<style type="text/css">
.xl2{background: url({IMGDIR}/vline.png) repeat-y 50% 0;}.xl2 li{width: 49.9%;}.xl2 li em{padding-right: 10px;}.xl2 .xl2_r em{padding-right: 0;}.xl2 .xl2_r i{padding-left: 10px;}
#threadlist .avt img{width: 45px; height: 45px; border: 0; -moz-border-radius: 50%; -webkit-border-radius: 50%; border-radius: 50%;}
.mn #threadlist .avt a{width: 45px;padding:2px !important;}
#threadlist .bm_c{padding:0}
.zhanzhuai_group .avt{width:55px;padding:10px 0}
.h_avatar{margin: -8px 13px 0 0;}
.h_avatar .reply_left{line-height: 25px;}
#threadlist #separatorline .avt{padding:0}
#threadlist .flt,#threadlist .flts{width:0}
#threadlist .by{width: 145px;}
#threadlist .bm_c th{padding-left:5px;padding-right:0}
#threadlist .bm_c .new{padding-left:5px;padding-right:0}
#threadlist .xst{font-size:16px}
#threadlist th a:hover,#threadlist td.fn a:hover{text-decoration:none;color:#ed4040 !important}
.zhanzhuai_group th, .zhanzhuai_group td{padding: 15px 0 15px 12px !important; border-bottom: 1px solid #f4f4f4 !important; background-color: #fff !important;}
.zhanzhuai_mtn{margin-top: 5px !important;}
#threadlist .xld .m, #threadlist .xld .m a{width: 54px; height: 45px; overflow: hidden; cursor: pointer; margin-right: 15px; background: #f5f5f5; border-radius: 5px;}
.xld .m{float: left; margin: 8px 10px 10px 0;}
#threadlist .xld .m strong{display: block; height: 25px; line-height: 25px; color: #ed4040 !important; overflow: hidden;}
#threadlist .xld .m span{display: block; color: #ed4040 !important;}
.zhanzhuai_ttp{height: 45px; line-height: 45px; padding: 0 15px; border: 0; border-bottom: 1px solid #f4f4f4;}
.zhanzhuai_ttp li{float: left; height: 45px; line-height: 45px; color: #333; font-size: 14px; text-align: center; margin-right: 30px; position: relative; -webkit-transition: All .3s ease; -moz-transition: All .3s ease; -o-transition: All .3s ease; cursor: pointer;}
.zhanzhuai_ttp li.a{background: #fff; z-index: 5; color: #ed4040;}
.zhanzhuai_ttp li a{display: block; position: relative; height: 45px; line-height: 45px; color: #656565; font-size: 14px; padding: 0 5px; border-bottom: 2px solid transparent;}
.zhanzhuai_ttp li a:hover{border-bottom: 2px solid #ed4040;color: #ed4040;}
.zhanzhuai_ttp li:hover{background: #fff; color: #ed4040;}
.zhanzhuai_ttp li:hover a{color: #ed4040;}
.zhanzhuai_ttp li.a a{font-weight: 400; color: #ed4040;border-bottom: 2px solid #ed4040;}
.zhanzhuai_ttp li span{display: block;position: absolute;bottom: -1px;left: 50%;width: 0%;bottom: -1px;height: 4px;background-color: #ed4040;transition: all 0.2s ease-in-out 0s;}
.zhanzhuai_ttp li.a span, .zhanzhuai_ttp a:hover span{width: 100%;left: 0;}
.zhanzhuai_g_m{margin: 15px 0; padding: 0;}
.zhanzhuai_guide_mn .tl .tf{padding: 3px 16px;}
.zhanzhuai_t1{border-radius: 0; margin-top: -1px;}
</style>

<style id="diy_style" type="text/css"></style>

<div class="boardnav">

   <div id="ct" class="wp cl{if $_G['forum']['allowside']} ct2{/if}"{if $leftside} style="margin-left:{$_G['leftsidewidth_mwidth']}px"{/if}>

	   <div class="mn zhanzhuai_guide_mn zz_frame_c z cl">
			<ul id="thread_types" class="zhanzhuai_ttp bm cl">	
				<li $currentview['hot']><a href="forum.php?mod=guide&view=hot">{lang guide_hot}</a></li>
				<li $currentview['digest']><a href="forum.php?mod=guide&view=digest">{lang guide_digest}</a></li>
				<li $currentview['new']><a href="forum.php?mod=guide&view=new">{lang guide_new}</a></li>
				<li $currentview['newthread']><a href="forum.php?mod=guide&view=newthread">{lang guide_newthread}</a></li>
				<li $currentview['sofa']><a href="forum.php?mod=guide&view=sofa">{lang guide_sofa}</a></li>
				<li $currentview['my']><a id="filter_special" href="forum.php?mod=guide&view=my" onmouseover="showMenu(this.id)">{lang guide_my}</a></li>
				<!--{hook/guide_nav_extra}-->
			</ul>
			<!--{hook/guide_top}-->
			<!--{if $view == 'index'}-->
				<!--{loop $data $key $list}-->
				<div class="bm bmw">
					<div class="bm_h">
						<a href="forum.php?mod=guide&view=$key" class="y xi2">{lang more} &raquo;</a>
						<h2>
							<!--{if $key == 'hot'}-->{lang guide_hot}<!--{elseif $key == 'digest'}-->{lang guide_digest}<!--{elseif $key == 'newthread'}-->{lang guide_newthread}<!--{elseif $key == 'new'}-->{lang guide_new}<!--{elseif $key == 'my'}-->{lang guide_my}<!--{/if}-->
						</h2>
					</div>
					 <div class="bm_c">
					 	<div class="xl xl2 cl">
					 		<!--{if $list['threadcount']}-->
					 			<!--{eval $i=0;}-->
					 			<!--{loop $list['threadlist'] $thread}-->
					 			<!--{eval $i++;$newtd=$i%2;}-->
					 			<li{if !$newtd} class="xl2_r"{/if}>
						 			<em>
							 			<!--{if $key == 'hot'}--><span class="xi1">$thread['heats']{lang guide_attend}</span><!--{/if}-->
							 			<!--{if $key == 'new'}-->$thread['lastpost']<!--{/if}-->
						 			</em>
						 			
						 			<i>&middot; <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight] target="_blank">$thread[subject]</a></i>&nbsp;<span class="xg1"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$list['forumnames'][$thread[fid]]['name']</a></span>
					 			</li>
					 			<!--{/loop}-->
					 		<!--{else}-->
					 				<p class="emp">{lang guide_nothreads}</p>
					 		<!--{/if}-->
					 	</div>
					</div>
				</div>
				<!--{/loop}-->
			<!--{else}-->
				<!--{loop $data $key $list}-->
				<div id="threadlist" class="zhanzhuai_t1 tl"{if $_G['uid']} style="position: relative;"{/if}>
					<div class="bm_c zhanzhuai_group">
						<div id="forumnew" style="display:none"></div>
							<table cellspacing="0" cellpadding="0">
							<!--{subtemplate forum/guide_list_row}-->
							</table>
					</div>
				
				<!--{/loop}-->
				<div class="bm bw0 zhanzhuai_g_m pgs cl">
					$multipage
				</div>
				</div>
			<!--{/if}-->
			<!--{hook/guide_bottom}-->
		</div>

	</div>
</div>
<!--{if !IS_ROBOT}-->
	<div id="filter_special_menu" class="p_pop" style="display:none">
		<ul>
			<li><a href="home.php?mod=space&do=poll&view=me" target="_blank">{lang thread_poll}</a></li>
			<li><a href="home.php?mod=space&do=trade&view=me" target="_blank">{lang thread_trade}</a></li>
			<li><a href="home.php?mod=space&do=reward&view=me" target="_blank">{lang thread_reward}</a></li>
			<li><a href="home.php?mod=space&do=activity&view=me" target="_blank">{lang thread_activity}</a></li>
		</ul>
	</div>
<!--{/if}-->
<!--{template common/footer}-->
