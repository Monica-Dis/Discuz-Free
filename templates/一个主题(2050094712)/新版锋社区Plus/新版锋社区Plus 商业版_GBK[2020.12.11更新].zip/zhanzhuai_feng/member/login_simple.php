<?PHP exit('��֧������ - վק��� https://dism.taobao.com/?@57900.developer');?>	
<!--{if CURMODULE != 'logging'}-->
<div class="zhanzhuai_denglu cl">
	<a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" onclick="showWindow('login', this.href);return false;" class="zz_signin">��¼</a>
	<span class="break"></span>
	<a href="member.php?mod={$_G[setting][regname]}"  class="zz_signin">ע��</a>
</div>
<!--{if $_G['setting']['pwdsafety']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<!--{/if}-->

<div style="display: none;"><!--{hook/global_login_extra}--></div>
<!--{/if}-->
