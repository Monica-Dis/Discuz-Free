<?PHP exit('��֧������ - վק��� https://dism.taobao.com/?@57900.developer');?>
{eval
	$filter = array( 'common' => '{lang have_posted}', 'save' => '{lang draft}', 'close' => '{lang closed}', 'aduit' => '{lang pending}', 'ignored' => '{lang ignored}', 'recyclebin' => '{lang recyclebin}');
	$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=thread&view=me\">{lang they_thread}</a>";
}

<!--{if $diymode}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
		<div id="ct" class="ct2 wp cl">
			<div class="mn">
				<div class="bm">
					<div class="bm_h">
						<!--{if $space[self]}--><span class="xi2 y"><a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="addnew">{lang posted}</a></span><!--{/if}-->
						<h1 class="mt">
							<!--{if $_GET[type] == 'reply'}-->
							<span class="xs1 xw0"><a href="home.php?mod=space&do=thread&view=me&type=thread&uid=$space[uid]&from=space">{lang topic}</a><span class="pipe">|</span></span>{lang reply}
							<!--{else}-->
							{lang topic}<span class="xs1 xw0"><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=reply&uid=$space[uid]&from=space">{lang reply}</a></span>
							<!--{/if}-->
						</h1>
					</div>
				<div class="bm_c">
	<!--{else}-->
		<!--{template common/header}-->

		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="ct2 wp cl">
			<div class="zz_space_sd zz_frame_c zz_br4 cl">
			     <!--{subtemplate home/space_nav}-->
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
	<!--{/if}-->
<!--{else}-->
	<!--{template common/header}-->
	<div id="pt" class="bm cl">
		<div class="z">
			<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
			<!--{if $_G[setting][homestyle]}--><a href="home.php">$_G[setting][navs][4][navname]</a> <em>&rsaquo;</em> <!--{/if}-->
			<a href="home.php?mod=space&do=blog">{lang thread}</a>
		</div>
	</div>
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ct" class="ct2_a wp cl">
	<!--{if $_G[setting][homestyle]}-->
		<div class="appl">
			<!--{subtemplate common/userabout}-->
		</div>
		<div class="mn pbw">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<ul class="tb cl">
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
	<!--{else}-->
		<div class="appl">
			<div class="tbn">
				<h2 class="mt bbda">{lang thread}</h2>
				<ul>
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
		</div>
		<div class="mn pbw">
		<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
	<!--{/if}-->
<!--{/if}-->
		
		<!--{if !$diymode && $space[self]}-->
			<!--{if $_GET['view'] == 'me'}-->
			<p class="tbmu bw0">
				<!--{if $viewtype != 'postcomment'}-->
					<span class="y">
					<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=" {if !$_GET[filter]}class="a"{/if}>{lang all}</a>
					<!--{loop $filter $key $name}--><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=$key" {if $key == $_GET[filter]}class="a"{/if}>$name</a><!--{/loop}--> &nbsp;
						<select name="forumlist" id="forumlist" class="ps vm" onchange="viewforumthread(this.value);" style="width: 120px; word-wrap: normal;">
							<option value="0">{lang follow_select_forum}</option>
							$forumlist
						</select>
					</span>
				<!--{/if}-->
				<a href="home.php?mod=space&do=thread&view=me&type=thread" $orderactives[thread]>{lang topic}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=reply" $orderactives[reply]>{lang reply}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=postcomment" $orderactives[postcomment]>{lang post_comment}</a>
				<!--{if $viewtype != 'reply' && $viewtype != 'postcomment'}-->&nbsp; <input type="text" id="searchmypost" class="px vm" size="15" /> <button class="pn vm" onclick="searchpostbyusername($('searchmypost').value, '$_G[username]');"><em>{lang search}</em></button><!--{/if}-->
			</p>
			<!--{elseif $_GET['view'] == 'all'}-->
			<p class="tbmu bw0">
				<a href="home.php?mod=space&do=thread&view=all&order=dateline" $orderactives[dateline]>{lang newest_thread}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=all&order=hot" $orderactives[hot]>{lang top_thread}</a>
			</p>
			<!--{/if}-->
		<!--{/if}-->
		
		<!--{if $diymode && !$_G[setting][homepagestyle] }-->
			<p class="tbmu">
				<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread" $orderactives[thread]>{lang topic}</a>
				<span class="pipe">|</span>
				<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=reply" $orderactives[reply]>{lang reply}</a>
			</p>
		<!--{/if}-->
		
		<!--{if $userlist}-->
			<p class="tbmu bw0">
				{lang view_by_friend}
				<select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
					<option value="">{lang all_friends}</option>
					<!--{loop $userlist $value}-->
					<option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
					<!--{/loop}-->
				</select>
			</p>
		<!--{/if}-->
		<div class="zhanzhuai_th_tl tl" style="padding: 0;">
			<form method="post" autocomplete="off" name="delform" id="delform" action="home.php?mod=space&do=thread&view=all&order=dateline" onsubmit="showDialog('{lang del_select_thread_confirm}', 'confirm', '', '$(\'delform\').submit();'); return false;">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="delthread" value="true" />

<div class="home-post-list">

<!--{if $list}-->

<ul>
<!--{loop $list $stid $thread}-->
   <!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
   <!--{eval $from_forum = C::t('forum_forum')->fetch_info_by_fid($thread['fid']);}--> 
   <!--{eval $thread['name'] = $from_forum['name'];}--> 
   <!--{eval $messages = DB::result(DB::query("SELECT message FROM ".DB::table('forum_post')." WHERE `tid`= '$thread[tid]' AND first = 1"));}-->
   <!--{eval $message = messagecutstr($messages,140);}-->

   <li class="zz_aw_item{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}zz_aw_manager{/if} cl" id="$thread[id]"{if $_G['hiddenexists'] && $thread['hidden']} style='display:none'{/if}>
		       <div class="zz_aw_user_avt z">
					<a href="home.php?mod=space&uid=$thread[authorid]" target="_blank"><!--{avatar($thread[authorid],middle)}--></a>
			   </div>
               <div class="zz_aw_content">
					<div class="zz_aw_title cl">
                         <!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
                               <!--{eval $thread[tid]=$thread[closed];}-->
                         <!--{/if}-->
                                            
                         <!--{if $thread['moved']}-->
                                {lang thread_moved}:<!--{eval $thread[tid]=$thread[closed];}-->
                         <!--{/if}-->
                         <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} class="s">$thread[subject]</a>
						 <a href="forum.php?mod=viewthread&tid=$thread[tid]&highlight=$index[keywords]" title="{lang open_new_window}" target="_blank">
								<!--{if $thread[folder] == 'lock'}-->
									<img src="{IMGDIR}/folder_lock.gif" align="absmiddle" />
								<!--{elseif $thread['special'] == 1}-->
									<img src="{IMGDIR}/pollsmall.gif" alt="{lang poll}" align="absmiddle" />
								<!--{elseif $thread['special'] == 2}-->
									<img src="{IMGDIR}/tradesmall.gif" alt="{lang trade}" align="absmiddle" />
								<!--{elseif $thread['special'] == 3}-->
									<img src="{IMGDIR}/rewardsmall.gif" alt="{lang reward}" align="absmiddle" />
								<!--{elseif $thread['special'] == 4}-->
									<img src="{IMGDIR}/activitysmall.gif" alt="{lang activity}" align="absmiddle" />
								<!--{elseif $thread['special'] == 5}-->
									<img src="{IMGDIR}/debatesmall.gif" alt="{lang debate}" align="absmiddle" />
								<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
									<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" align="absmiddle" />
								<!--{else}-->
								<!--{/if}-->
							</a>
							    <!--{if $thread['digest'] > 0}-->
									<img src="{IMGDIR}/digest_$thread[digest].gif" alt="{lang digest} $thread[digest]" align="absmiddle" />
								<!--{/if}-->
								<!--{if $thread['attachment'] == 2}-->
									<img src="{STATICURL}image/filetype/image_s.gif" alt="{lang photo_accessories}" align="absmiddle" />
								<!--{elseif $thread['attachment'] == 1}-->
									<img src="{STATICURL}image/filetype/common.gif" alt="{lang accessory}" align="absmiddle" />
								<!--{/if}-->
								<!--{if $thread[multipage]}--><span class="tps">$thread[multipage]</span><!--{/if}-->
								<!--{if !$_GET['filter']}-->
									<!--{if $thread[$statusfield] == -1}--><span class="xg1">$filter[recyclebin]</span>
									<!--{elseif $thread[$statusfield] == -2}--><span class="xg1">$filter[aduit]</span>
									<!--{elseif $thread[$statusfield] == -3 && $thread[displayorder] != -4}--><span class="xg1">$filter[ignored]</span>
									<!--{elseif $thread[displayorder] == -4}--><span class="xg1">$filter[save]</span>
									<!--{elseif $thread['closed'] == 1}--><span class="xg1">$filter[close]</span>
									<!--{/if}-->
								<!--{/if}-->

                       </div>

										<div class="post-actions cl" style="margin-top: 1px;">
                                             <div class="post-author z cl">	
                                                  <div class="post-author-basic">
												       <!--{if $thread['authorid'] && $thread['author']}-->
                                                           <a href="home.php?mod=space&uid=$thread[authorid]" c="1"{if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if}>
                                                              <span class="author-name">$thread[author]</span>
                                                           </a>
														   <!--{if !empty($verify[$thread['authorid']])}--> <span style=" margin: 0 5px;">$verify[$thread[authorid]]</span><!--{/if}-->
														<!--{else}-->
														   <a href="javascript:;">
                                                              <span class="author-name">$_G[setting][anonymoustext]</span>
                                                           </a>
														<!--{/if}-->
                                                  </div>
                                                  <div class="post_dateline z">$thread[dateline]</div>	

												  <!--{hook/forumdisplay_author $key}-->
												  <!--{if $thread[replies] >0}-->
												  <div class="post-last_c z" style="margin-left: 15px;">
											           <span><!--{if $thread['lastposter']}--><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}" c="1">$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></span>
										               <span>���ظ�</span>
                                                       <span><a href="{if $thread[digest] != -2 && !$thread[ordertype]}forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost$highlight#lastpost{else}forum.php?mod=viewthread&tid=$thread[tid]{if !$thread[ordertype]}&page={echo max(1, $thread[pages]);}{/if}{/if}">$thread[lastpost]</a></span>
												  </div>
												  <!--{/if}-->
 
												  <div class="post-form z">
                                                       $thread[typehtml] $thread[sorthtml]
                                                  </div>

												  <!--{if CURMODULE == 'guide'}-->
										            <div>
													   <a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$forumnames[$thread[fid]]['name']</a>
                                                    </div>
									              <!--{/if}-->
                                             </div>
                       
											 <div class="y">
											      <span class="post-viem" style=" margin: 0 12px 0 15px;"><i class="zhanzhuai-icons"></i><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
                                                  <span class="post-reply"><i class="zhanzhuai-icons"></i>{$thread[replies]}</span>
											 </div>

                                         </div>
                                   </div>
							 </li>
<!--{/loop}-->
<ul>
<!--{else}-->
                  <div class="zhanzhuai_home_nodata cl">
                       <span></span>
                       <p>TA��û�з������κδ���</p>
                  </div>
					
					<!--{/if}-->
					</div>

					<!--{if $_GET['view'] == 'all' && $pruneperm && !$_GET['archiveid'] && $list}-->
						<p class="mtm pns">
							<label for="chkall" onclick="checkall(this.form, 'moderate')"><input type="checkbox" name="chkall" id="chkall" class="pc vm" />{lang select_all}</label>
							<button type="submit" name="delsubmit" value="true" class="pn vm"><em>{lang del_select_thread}</em></button>
						</p>
					<!--{/if}-->
				</form>

				<!--{if $hiddennum}-->
					<p class="mtm">{lang hide_thread}</p>
				<!--{/if}-->
			</div>
			<!--{if $multi}--><div class="pgs cl mtm mbm">$multi</div><!--{/if}-->		
		
		<script type="text/javascript">
		function fuidgoto(fuid) {
			window.location.href = 'home.php?mod=space&do=thread&view=we&fuid='+fuid;
		}
		function viewforumthread(fid) {
			window.location.href = '{$forumurl}&fid='+fid;
		}
		</script>
		
		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
          
		<!--{if !$_G[setting][homepagestyle]}-->
            </div>
			<div class="zz_space_mn cl">
				<!--{subtemplate home/space_userabout_z}-->
            </div>
        <!--{/if}-->

			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			</div>
			</div>
			<div class="sd">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->

<!--{template common/footer}-->
