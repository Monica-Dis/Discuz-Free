<?PHP exit('��֧������ - վק��� https://dism.taobao.com/?@57900.developer');?>

<link rel="stylesheet" type="text/css" href='template/zhanzhuai_feng/home/css/zz_space.css' />

<!--{if $space[uid]}-->
</div>
<div id="uhd">
    <div id="header">
        <div class="zz_space_top">
		    <div class="p-profile cl" style="background-image:url(template/zhanzhuai_feng/home/img/zz_user_header.jpg);"></div>
		    <div class="zhanzhuai_shadow"></div>
			<!--{if checkperm('allowbanuser') || checkperm('allowedituser') || $_G[adminid] == 1}-->
			 <div class="pf_guanli" style="position: relative;">
					<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
							<!--{if checkperm('allowbanuser')}-->
							<a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" id="usermanageli" onmouseover="showMenu(this.id)" class="showmenu" target="_blank" style="position: relative;display: inline-block;margin: 10px 0 0 20px;color: #fff;cursor: pointer;">{lang member_manage}</a>
							<!--{else}-->
							<a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" id="usermanageli" onmouseover="showMenu(this.id)" class="showmenu" target="_blank" style="position: relative;display: inline-block;margin: 10px 0 0 20px;color: #fff;cursor: pointer;">{lang member_manage}</a>
							<!--{/if}-->
					<!--{/if}-->
					
					<!--{if $_G[adminid] == 1}-->
						<a href="forum.php?mod=modcp&action=thread&op=post&do=search&searchsubmit=1&users=$encodeusername" id="umanageli" onmouseover="showMenu(this.id)" class="showmenu" style="position: relative;display: inline-block;margin: 6px 0 0 0;color: #fff;cursor: pointer;">{lang content_manage}</a>
					<!--{/if}-->
		
			<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
				<ul id="usermanageli_menu" class="zhanzhuai_home_manage p_pop" style="width: 80px; display:none;">
					<!--{if checkperm('allowbanuser')}-->
						<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" target="_blank">{lang user_ban}</a></li>
					<!--{/if}-->
					<!--{if checkperm('allowedituser')}-->
						<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" target="_blank">{lang user_edit}</a></li>
					<!--{/if}-->
				</ul>
				<!--{/if}-->
				<!--{if $_G['adminid'] == 1}-->
					<ul id="umanageli_menu" class="zhanzhuai_home_manage p_pop" style="width: 80px; display:none;">
						<li><a href="forum.php?mod=modcp&action=thread&op=post&searchsubmit=1&do=search&users=$encodeusername" target="_blank">{lang manage_post}</a></li>
						<!--{if helper_access::check_module('doing')}-->
							<li><a href="admin.php?action=doing&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_doing}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('blog')}-->
							<li><a href="admin.php?action=blog&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_blog}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('feed')}-->
							<li><a href="admin.php?action=feed&searchsubmit=1&detail=1&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_feed}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('album')}-->
							<li><a href="admin.php?action=album&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_album}</a></li>
							<li><a href="admin.php?action=pic&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_pic}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('wall')}-->
							<li><a href="admin.php?action=comment&searchsubmit=1&detail=1&fromumanage=1&authorid=$space[uid]" target="_blank">{lang manage_comment}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('share')}-->
							<li><a href="admin.php?action=share&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_share}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('group')}-->
							<li><a href="admin.php?action=threads&operation=group&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_threads}</a></li>
							<li><a href="admin.php?action=prune&searchsubmit=1&detail=1&operation=group&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_prune}</a></li>
						<!--{/if}-->
					</ul>
				<!--{/if}-->
				</div>
			<!--{/if}-->

 <div class="zz_top_photo cl">
     <a href="home.php?mod=space&uid=$space[uid]"><!--{avatar($space[uid],big)}--></a>
 </div>
 <div class="zz_top_username cl">
		<div class="zz_username">{$space[username]}</div>
		<!--{if isset($flag[$_G['uid']])}-->
		   <p>
			   <span id="followbkame_{$uid}"><!--{if $flag[$_G['uid']]['bkname']}-->$flag[$_G['uid']]['bkname']<!--{/if}--></span>
			   <a href="home.php?mod=spacecp&ac=follow&op=bkname&fuid=$uid&handlekey=followbkame_$uid" id="fbkname_{$uid}" onclick="showWindow('followbkame_{$uid}', this.href, 'get', 0);"><!--{if $flag[$_G['uid']]['bkname']}-->[{lang follow_mod_bkname}]<!--{else}-->[{lang follow_add_bkname}]<!--{/if}--></a>
		   </p>
		<!--{/if}-->
 </div>

 <!--{eval $profile = DB::fetch_first("SELECT * FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'");}-->
 <div class="zz_top_bio">
      <!--{if $profile[bio]}-->$profile[bio]<!--{else}-->δ��д���ҽ���<!--{/if}-->                     
 </div>

	<!--{if CURMODULE == 'follow'}-->
		<!--{subtemplate home/follow_user_header}-->
	<!--{elseif !$space[self]}-->
	<div class="zz_top_btn cl">
		<ul>
			<!--{if helper_access::check_module('follow')}-->	
				<!--{if !ckfollow($space['uid'])}-->
					<li><a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]">{lang follow_add}TA</a></li>
				<!--{else}-->
					<li><a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]">{lang follow_del}</a></li>
				<!--{/if}-->
			<!--{/if}-->
	
		        <li style="margin-right: 0;"><a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onclick="showWindow('showMsgBox', this.href, 'get', 0)" title="{lang send_pm}" class="zz_btn_send">{lang send_pm}</a></li>		
		</ul>
   </div>
		<!--{if helper_access::check_module('follow')}-->
		<script type="text/javascript">
		function succeedhandle_followmod(url, msg, values) {
			var fObj = $('followmod');
			if(values['type'] == 'add') {
				fObj.innerHTML = '{lang follow_del}';
				fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
			} else if(values['type'] == 'del') {
				fObj.innerHTML = '{lang follow_add}TA';
				fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
			}
		}
		</script>
		<!--{/if}-->
	<!--{/if}-->   
</div>
	<!--{hook/space_menu_extra}-->
</div>
</div>
</div>
</div>
<!--{/if}-->

<script type="text/javascript">
   setTimeout(function(){	   
	      jQuery(".p-profile").toggleClass("banner_transition");
      },15
   );
</script>
