<?PHP exit('��֧������ - վק��� https://dism.taobao.com/?@57900.developer');?>	
<!--{subtemplate common/header_common}-->
    <meta http-equiv="X-UA-Compatible" content="IE=8" />
    <meta http-equiv="X-UA-Compatible" content="IE=9" />
	<meta http-equiv="X-UA-Compatible" content="IE=10" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="renderer" content="webkit">
	<meta name="application-name" content="$_G['setting']['bbname']" />
	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
	<!--{/if}-->
	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'portal'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
	    <link rel="stylesheet" type="text/css" id="diy_common" href="data/cache/style_{STYLEID}_css_diy.css?{VERHASH}" />
	<!--{/if}-->
	<!--{eval include TPLDIR.'/php/forum_data.php';}-->
	<!--{eval $default_forum = 'Ĭ��';}--> 
	<link rel="stylesheet" type="text/css" href="$_G['style']['styleimgdir']/zz_font/iconfont.css?{VERHASH}" />
	<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery-zz1.8.3.min.js?{VERHASH}"></script>
	<script type="text/javascript">jQuery.noConflict();</script>
	<script src="$_G['style']['styleimgdir']/js/jquery.superslide.2.1.1.js?{VERHASH}" type="text/javascript"></script>
	<script language="javascript" type="text/javascript">
       function killErrors() {
            return true;
          }
       window.onerror = killErrors;
    </script>
</head>

<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if}" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>

	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<!--{template common/header_diy}-->
	<!--{/if}-->
	<!--{if check_diy_perm($topic)}-->
		<!--{template common/header_diynav}-->
	<!--{/if}-->
	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
		$diynav
	<!--{/if}-->
	<!--{if empty($topic) || $topic['useheader']}-->
		<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
			<div class="xi1 bm bm_c">
			    {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a>
			</div>
		<!--{/if}-->
		<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
			<div id="shortcut">
				<span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span>
				{lang shortcut_notice}
				<a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a>

			</div>
			<script type="text/javascript">setTimeout(setShortcut, 2000);</script>
		<!--{/if}-->		
	<!--{/if}-->

<div class="zz_search_wrap cl">
<div class="zz_search_main cl">
     <div class="zz_search_body">
	      <div class="zz_search_content cl">  
               <!--{subtemplate common/pubsearchform}-->
          </div>
		  <div class="zz_serach_cbtn"><img src="$_G['style']['styleimgdir']/sclose_btn.png" /></div>
	 </div>
</div>
<div class="zz_serach_mask cl"></div>
</div>

<div class="wp cl">
   <!--{hook/global_cpnav_top}-->
   <!--{hook/global_cpnav_extra1}-->
   <!--{hook/global_cpnav_extra2}-->
</div>

<div class="zz-top-header">
<div class="zhanzhuai_nv_item">
	<div class="wp cl">
	     <div class="zz_hd_top cl">
	          <h1 class="zz_logo"> 
			      <!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}-->
		      </h1>

			  <div class="zz_hd_nav cl">
	               <!--{eval $mnid = getcurrentnav();}-->	
	               <ul>
				        <!--{loop $_G['setting']['navs'] $nav}-->					     
				            <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->
							     <li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]>
								     <!--{if $subs}--> 
										     <i class="iconfont icon-unfold1"></i>
										 <!--{/if}--> 
								 </li>
							<!--{/if}-->
				        <!--{/loop}-->
			       </ul>
               
			       <!--{hook/global_nav_extra}-->
		      </div>

              <div class="zhanzhuai-right-menu y">

     <div class="zhanzhuai-in-other-icon z">
        <ul class="zhanzhuai-right-menuicon">
			<li class="fg-more zz_serch_openbtn">
			    <a href="javascript:;">
					<i class="iconfont icon-search" style="font-size: 19px;"></i>
				</a>
		   </li>
           <!--{if CURMODULE != 'logging'}--> 
		       <li class="fg-more">
			       <a href="forum.php?mod=misc&amp;action=nav" onclick="showWindow('nav', this.href, 'get', 0)">
				      <i class="iconfont icon-edit"></i>
				   </a>
			   </li>
		   <!--{/if}-->
		   <!--{if $_G['uid']}-->
		       <li id="myprompt" onmouseover="showMenu({'ctrlid':'myprompt','pos':'34!','ctrlclass':'a','duration':2});"><a href="home.php?mod=space&do=pm"><i class="iconfont icon-creative"></i><!--{if $_G[member][newprompt] || $_G[member][newpm]}--><em class="notice-i"></em><!--{/if}--></a></li>
               <!--{if empty($_G['cookie']['ignore_notice']) && ($_G[member][newpm] || $_G[member][newprompt_num][follower] || $_G[member][newprompt_num][follow] || $_G[member][newprompt])}--><script language="javascript">delayShow($('myprompt'), function() {showMenu({'ctrlid':'myprompt','duration':3})});</script><!--{/if}-->
		   <!--{/if}-->
        </ul>

		<!--{if !IS_ROBOT}-->
			<!--{if $_G['uid']}-->
			<ul id="myprompt_menu" class="zhanzhuai_myprompt p_pop" style="display: none;">
				<li><a href="home.php?mod=space&do=pm" id="pm_ntc" style="background-repeat: no-repeat; background-position: 0 50%;"><em class="prompt_news{if empty($_G[member][newpm])}_0{/if}"></em>{lang pm_center}</a></li>
				<li><a href="home.php?mod=follow&do=follower"><em class="prompt_follower{if empty($_G[member][newprompt_num][follower])}_0{/if}"></em><!--{lang notice_interactive_follower}-->{if $_G[member][newprompt_num][follower]}($_G[member][newprompt_num][follower]){/if}</a></li>
				<!--{if $_G[member][newprompt] && $_G[member][newprompt_num][follow]}-->
					<li><a href="home.php?mod=follow"><em class="prompt_concern"></em><!--{lang notice_interactive_follow}-->($_G[member][newprompt_num][follow])</a></li>
				<!--{/if}-->
				<!--{if $_G[member][newprompt]}-->
					<!--{loop $_G['member']['category_num'] $key $val}-->
						<li><a href="home.php?mod=space&do=notice&view=$key"><em class="notice_$key"></em><!--{echo lang('template', 'notice_'.$key)}-->(<span class="rq">$val</span>)</a></li>
					<!--{/loop}-->
				<!--{/if}-->
				<!--{if empty($_G['cookie']['ignore_notice'])}-->
					<li class="ignore_noticeli"><a href="javascript:;" onclick="setcookie('ignore_notice', 1);hideMenu('myprompt_menu')" title="�ر�����"><em class="ignore_notice">�ر�����</em></a></li>
				<!--{/if}-->
			</ul>
			<!--{/if}-->
			<!--{if $_G['uid']}-->
				<ul id="myitem_menu" class="p_pop" style="display: none;">
					<li><a href="forum.php?mod=guide&view=my">{lang mypost}</a></li>
					<li><a href="home.php?mod=space&do=favorite&view=me">{lang favorite}</a></li>
					<li><a href="home.php?mod=space&do=friend">{lang friends}</a></li>
					<!--{hook/global_myitem_extra}-->
				</ul>
			<!--{/if}-->
			<!--{subtemplate common/header_qmenu}-->
		<!--{/if}-->
     </div>

<div class="zhanzhuai-top-user y">
<!--{if $_G['uid']}-->
<div id="zz_signin_user" onmouseover="showMenu({'ctrlid':'zz_signin_user','pos':'34!','ctrlclass':'a','duration':2});">
	<span><a href="home.php?mod=space&uid=$_G[uid]" target="_blank"><!--{avatar($_G[uid],small)}--></a></span>
</div>

<!--{elseif !empty($_G['cookie']['loginuser'])}-->
<div id="userInfoBar" class="cl">
	<div><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></dt>
	<div><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a></dt>
	<div><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></dt>
</div>
<!--{elseif !$_G[connectguest]}-->
	<!--{template member/login_simple}-->
<!--{else}-->

    <div id="zz_signin_user2" onmouseover="showMenu({'ctrlid':'zz_signin_user2','pos':'34!','ctrlclass':'a','duration':2});">
	   <span><a href="javascript:;"><!--{avatar($_G[uid],small)}--></a></span>
    </div>

<!--{/if}-->

    
<div id="zz_signin_user_menu" class="zz_signin_menu cl" style="display: none;">
     <div id="hd_uname">
	     <div class="zhanzhuai-hd-uesr cl">
		      <div class="zhanzhuai-tx-q">
                   <a href="home.php?mod=spacecp&ac=avatar" target="_blank" class="bigtximg-q"><!--{avatar($_G[uid],small)}--></a>
              </div>
              <div class="zhanzhuai-xx-q">
                   <p class="p01-q"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank">{$_G[member][username]}</a></p>
                   <p class="p02-q">$_G[group][grouptitle]<!--{if $_G[member]['freeze']}-->({lang freeze})<!--{/if}--></p>
              </div>
        </div>
		<div class="zhanzhuai-hd-plugin cl">
		     <!--{hook/global_usernav_extra1}-->
		     <!--{hook/global_usernav_extra2}-->
		     <!--{hook/global_usernav_extra3}-->
		     <!--{hook/global_usernav_extra4}-->
        </div>
	 </div>

<div class="zhanzhuai_bdimg">
    <a href="javascript:;"><font>{eval echo getuserprofile('threads');}</font><br>����</a>
    <a href="javascript:;"><font>{eval echo getuserprofile('posts');}</font><br>����</a>
    <a href="javascript:;"><font> {eval echo getuserprofile('extcredits2');}</font><br>{$_G[setting][extcredits][2][title]}</a>
</div>

<div class="zhanzhuai_dimg">
    <ul>
      <li><a href="forum.php?mod=guide&view=my">�ҵ�����</a></li>
	  <li><a href="home.php?mod=space&do=favorite&view=me">�ҵ��ղ�</a></li>
	  <li><a href="home.php?mod=space&do=friend">�ҵĺ���</a></li>
	  <li><a href="home.php?mod=medal">�ҵ�ѫ��</a></li>
	  <!--{if check_diy_perm($topic)}--><li><a href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" style="color: #1985ff;">�༭DIY</a></li><!--{/if}-->
	  <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
	     <li><a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>	
      <!--{/if}--> 
	  <!--{if $_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])}-->
		 <li><a href="home.php?mod=task&item=doing" id="task_ntc">{lang task_doing}</a></li>
	  <!--{/if}-->
      <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
         <li><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">��̳����</a></li>
      <!--{/if}-->
      <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
         <li><a href="admin.php" target="_blank">��̨����</a></li>
      <!--{/if}-->
	   
    </ul>
</div>

<div class="zhanzhuai-loginbtn-q">
<a href="home.php?mod=spacecp" target="_blank" class="sz-q">����</a>
<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="tc-q">�˳�</a>
</div>  

</div>

</div>

 </div>
</div>

       <div class="zhanzhuai_mn_menu">
		    <!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
					<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
					<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
						 <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
						 <li>$module[url]</li>
						 <!--{/if}-->
					<!--{/loop}-->
					</ul>
				<!--{/if}-->			
				$_G[setting][menunavs]
         </div>

     </div>
 </div>
 </div>

<!--{ad/subnavbanner/a_mu}-->

<!--{hook/global_header}-->

<!--{if $_G['basescript'] == 'portal' && CURMODULE == 'index'}-->
<!--{else}-->
   <div class="zhanzhuai-topad-box cl"><!--{ad/headerbanner/wp}--></div>
<!--{/if}-->

<script type="text/javascript">
	jQuery(window).scroll(function () {
	    var topScr = jQuery(window).scrollTop();
	    if (topScr > 0) {
	        jQuery(".zhanzhuai_nv_item").addClass("zz-top-fixed");
	    } else {
	        jQuery(".zhanzhuai_nv_item").removeClass("zz-top-fixed");
	    }
	});

jQuery(document).ready(function(jQuery) {
	jQuery('.zz_serch_openbtn').click(function(){
		jQuery("body").addClass("modal-open");
	})
	jQuery('.zz_serach_mask, .zz_serach_cbtn').click(function(){
		jQuery("body").removeClass("modal-open");
	})

})
</script>

<div id="wp" class="wp">
