<?PHP exit('请支持正版 - 站拽设计 https://dism.taobao.com/?@57900.developer');?>	
<!--{if $leftside['favorites']}-->
	<div class="zz_frame_c cl" style="margin-bottom: 0;">
	     <div class="zz_fun_title cl" style="padding: 0 15px 0 20px;"><span class="line"></span><a href="home.php?mod=space&do=favorite&type=forum">{lang favorite_forums}</a></div>
	     <dl id="lf_fav" class="bdl_fav mbm">
		     <!--{loop $leftside['favorites'] $favfid $fdata}-->
			     <dd>
				     <!--{if !empty($_G['cache']['forums'][$favfid]['domain']) && !empty($_G['setting']['domain']['root']['forum'])}-->
					     <a href="http://{$_G['cache']['forums'][$favfid]['domain']}.{$_G['setting']['domain']['root']['forum']}" title="$fdata[0]">$fdata[0]</a>
				     <!--{else}-->
					     <a href="forum.php?mod=forumdisplay&fid=$favfid">$fdata[0]</a>
				     <!--{/if}-->			
			     </dd>
		     <!--{/loop}-->
	    </dl>
	</div>
<!--{/if}-->

<div class="zz_frame_c cl" style="margin-bottom: 0;">
<!--{loop $leftside['forums'] $upfid $gdata}-->	
	<dl class="{if $fgroupid == $upfid || $_G['setting']['leftsideopen']}a{/if}" id="lf_$upfid">
		<dt class="zz_fun_title cl" onclick="leftside('lf_$upfid')" hidefocus="true" title="$gdata['name']"><span class="line"></span><a href="javascript:;">$gdata['name']</a></dt>
	    <!--{loop $gdata['sub'] $subfid $name}-->
		    <dd{if $_G['fid'] == $subfid || $_G['forum']['fup'] == $subfid} class="bdl_a"{/if}>
			   <!--{if !empty($_G['cache']['forums'][$subfid]['domain']) && !empty($_G['setting']['domain']['root']['forum'])}-->
				   <a href="http://{$_G['cache']['forums'][$subfid]['domain']}.{$_G['setting']['domain']['root']['forum']}" title="$name">$name</a>
			   <!--{else}-->
				   <a href="forum.php?mod=forumdisplay&fid=$subfid" title="$name">$name</a>
			   <!--{/if}-->
		    </dd>
	    <!--{/loop}-->
	</dl>	
<!--{/loop}-->
</div>