<?PHP exit('请支持正版 - 站拽设计 https://dism.taobao.com/?@57900.developer');?>	

<div class="zz_forum_zt cl">

	 <div class="zz_hm_top zz_frame_c">
	     <h1>专栏精读</h1>
	     <h2>随心写作，自由表达</h2>
	     <a href="forum.php?mod=misc&amp;action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="zz_write_btn">开始写文章</a>
     </div>

     <div class="zz_hm_forumbanner zz_frame_c cl">
		  <!--{if empty($gid)}-->
			<p class="z">{lang index_today}<em>$todayposts</em><span class="pipe">|</span>{lang index_yesterday}<em>$postdata[0]</em><span class="pipe">|</span>{lang index_posts}<em>$posts</em><span class="pipe">|</span>{lang index_members}<em>$_G['cache']['userstats']['totalmembers']</em><!--{if $_G['cache']['userstats']['newsetuser']}--><span class="pipe">|</span>{lang welcome_new_members}<em><a href="home.php?mod=space&username={echo rawurlencode($_G['cache']['userstats']['newsetuser'])}" target="_blank" class="xi2">$_G['cache']['userstats']['newsetuser']</a></em><!--{/if}--></p>
			<div class="y">
				<!--{hook/index_nav_extra}-->
				<!--{if $_G['uid']}--><a href="forum.php?mod=guide&view=my" title="{lang my_posts}" class="xi2">{lang my_posts}</a><!--{/if}--><!--{if !empty($_G['setting']['search']['forum']['status'])}--><!--{if $_G['uid']}--><span class="pipe">|</span><!--{/if}--><a href="forum.php?mod=guide&view=new" title="{lang show_newthreads}" class="xi2">{lang show_newthreads}</a><!--{/if}-->
			</div>
	     <!--{/if}-->
	 </div>

<div class="zz_forum_zt_list">
 <ul class="cl"> 
<!--{loop $catlist $key $cat}-->	
    
   <!--{loop $cat[forums] $forumid}-->
   <!--{eval $forum=$forumlist[$forumid];}-->
   <!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
	<li>
		<div class="zhanzhuai-block-icon">
             <!--{if $forum[icon]}-->
				$forum[icon]
			 <!--{else}-->
				<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}>
				    <img src="$_G['style']['styleimgdir']/forum{if $forum[folder]}_new{/if}.png" alt="$forum[name]" />
				</a>
			 <!--{/if}-->       
		</div>
		<div class="zhanzhuai-block-content">
			<p class="zhanzhuai-block-name">
			   <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if} class="active">$forum[name]</a>
			</p>
			<p class="zhanzhuai-block-description">
			   <!--{if $forum[description]}-->
			       <!--{echo cutstr($forum[description], 60)}-->
			   <!--{else}-->
			       管理大大暂无留下该专题描述
			   <!--{/if}-->
			</p>
		</div>
		<div class="zhanzhuai-block-count">
			   <!--{if empty($forum[redirect])}-->
			       <span>今日 <!--{if $forum[todayposts] && !$forum['redirect']}-->$forum[todayposts]<!--{else}-->0<!--{/if}--><em style="margin: 0 5px;">&middot;</em>主题 <!--{echo dnumber($forum[posts])}--></span>
			   <!--{/if}-->
		</div>
		
	    </li>
	<!--{/loop}-->
	
<!--{/loop}-->
</ul>
</div>
</div>

<!--{if empty($gid) && $_G['setting']['whosonlinestatus']}-->
			<div id="online" class="zhanzhuai2_fl zz_frame_c oll">
				<div class="zhanzhuai_ftit cl">
				<!--{if $detailstatus}-->
					<span class="o"><a href="forum.php?showoldetails=no#online" title="{lang spread}"><img src="$_G['style']['styleimgdir']/collapsed_no.gif" alt="{lang spread}" /></a></span>
					<span class="line"></span>
					<h2 style=" font-weight: 400;color: #aaaeb3;">
						<a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a>
						<span class="xs1">- $onlinenum{lang onlines}
						- <strong style="color: #919191;">$membercount</strong> {lang index_members}(<strong style="color: #919191;">$invisiblecount</strong> {lang index_invisibles}),
						<strong style="color: #919191;">$guestcount</strong> {lang index_guests}
						- {lang index_mostonlines} <strong style="color: #919191;">$onlineinfo[0]</strong> {lang on} <strong style="color: #919191;">$onlineinfo[1]</strong>.</span>
					</h2>
				<!--{else}-->
					<!--{if empty($_G['setting']['sessionclose'])}-->
						<span class="o"><a href="forum.php?showoldetails=yes#online" title="{lang spread}"><img src="$_G['style']['styleimgdir']/collapsed_yes.gif" alt="{lang spread}" /></a></span>
					<!--{/if}-->
					<h2>
						<strong>
							<!--{if !empty($_G['setting']['whosonlinestatus'])}-->
								{lang onlinemember}
							<!--{else}-->
								<a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a>
							<!--{/if}-->
						</strong>
						<span class="xs1">- {lang total} <strong>$onlinenum</strong> {lang onlines}
						<!--{if $membercount}-->- <strong>$membercount</strong> {lang index_members},<strong>$guestcount</strong> {lang index_guests}<!--{/if}-->
						- {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>
					</h2>
				<!--{/if}-->
				</div>
			<!--{if $_G['setting']['whosonlinestatus'] && $detailstatus}-->
				<dl id="onlinelist" class="zhanzhuai_f_item cl">
					<dt class="ptm pbm bbda">$_G[cache][onlinelist][legend]</dt>
					<!--{if $detailstatus}-->
						<dd class="ptm">
						<ul class="cl">
						<!--{if $whosonline}-->
							<!--{loop $whosonline $key $online}-->
								<li title="{lang time}: $online[lastactivity]">
								<img src="{STATICURL}image/common/$online[icon]" alt="icon" />
								<!--{if $online['uid']}-->
									<a href="home.php?mod=space&uid=$online[uid]">$online[username]</a>
								<!--{else}-->
									$online[username]
								<!--{/if}-->
								</li>
							<!--{/loop}-->
						<!--{else}-->
							<li style="width: auto">{lang online_only_guests}</li>
						<!--{/if}-->
						</ul>
					</dd>
					<!--{/if}-->
				</dl>
			<!--{/if}-->
			</div>
		<!--{/if}-->

		<!--{if empty($gid) && ($_G['cache']['forumlinks'][0] || $_G['cache']['forumlinks'][1] || $_G['cache']['forumlinks'][2])}-->
		<div class="zhanzhuai2_fl zz_frame_c lk">
			<div id="category_lk" class="cl" style="padding: 15px;">
				<!--{if $_G['cache']['forumlinks'][0]}-->
					<ul class="m mbn cl">$_G['cache']['forumlinks'][0]</ul>
				<!--{/if}-->
				<!--{if $_G['cache']['forumlinks'][1]}-->
					<div class="mbn cl">
						$_G['cache']['forumlinks'][1]
					</div>
				<!--{/if}-->
				<!--{if $_G['cache']['forumlinks'][2]}-->
					<ul class="x cl">
						$_G['cache']['forumlinks'][2]
					</ul>
				<!--{/if}-->
			</div>
		</div>
	<!--{/if}-->
</div>
