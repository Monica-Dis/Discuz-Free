<?PHP exit('请支持正版 - 站拽设计 https://dism.taobao.com/?@57900.developer');?>

<!--{eval $encodeusername = rawurlencode($space[username]);}-->

<!--menu-->
    <!--{eval $zhanzhuai_count = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = $space[uid]");}-->
	<div class="zz_home_count zz_frame_c zz_br4 cl">
        <div class="myfrendcont z">
             <a href="home.php?mod=follow&do=following&uid=$uid" style="border-left: 0;">关注<em>$zhanzhuai_count['following']</em></a>
             <a href="home.php?mod=follow&do=follower&uid=$uid">粉丝<em>$zhanzhuai_count['follower']</em></a>
             <a href="home.php?mod=space&uid=$uid&do=thread&view=me&from=space">帖子<em>$zhanzhuai_count['posts']</em></a>
        </div>
    </div>

              <!--{eval $home_gzs = DB::fetch_all("select * from ".DB::table('home_follow')." where uid = $uid order by followuid desc limit 0,10 "); $home_fans = DB::fetch_all("select * from ".DB::table('home_follow')." where followuid = $uid order by uid desc limit 0,10 ");}-->
				<!--{if $home_gzs}-->
				<!--{if $_GET[do]!='following' && $_GET[do]!='follower'}-->
                  <div class="zhanzhuai-gz-box zz_frame_c zz_br4 cl">
                       <div class="zz_sidebox_tit cl">他的关注</div>
					   <!--{loop $home_gzs $value_gzs}-->
                       <div class="zz_sidelist">
                            <a href="home.php?mod=space&uid=$value_gzs[followuid]" title="$value_gzs[fusername]" target="_blank">
							    <img src="{echo avatar($value_gzs[followuid],'middle',1);}" />
							</a>
                            <a href="home.php?mod=space&uid=$value_gzs[followuid]" title="$value_gzs[fusername]" class="name" target="_blank">$value_gzs[fusername]</a>
                            <!--{eval $follow = 0;}-->
						    <!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $value_gzs[followuid]);}-->
						    <!--{if !$follow}-->
							    <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$value_gzs[followuid]" class="zz_butbase">{lang follow_add}TA</a>
						    <!--{else}-->
							    <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$value_gzs[followuid]" class="zz_butbase">{lang follow_del}</a>
						    <!--{/if}-->
                       </div>
					   <!--{/loop}-->
                  </div>
				<!--{/if}-->
				<!--{else}-->
				   <div class="zhanzhuai-gz-box zz_frame_c zz_br4 cl">
                        <div class="zz_sidebox_tit cl">他的关注</div>					  
                        <div class="no-zz_sidelist">
                           暂无数据
                        </div>
				   </div>
				<!--{/if}-->
                <!--{eval $home_fans = DB::fetch_all("select * from ".DB::table('home_follow')." where followuid = $uid order by uid desc limit 0,10 ");}-->

				<!--{if $home_fans}-->
				<!--{if $_GET[do]!='following' && $_GET[do]!='follower'}-->
                  <div class="zhanzhuai-gz-box zz_frame_c zz_br4 cl">
                       <div class="zz_sidebox_tit cl">他的粉丝</div>
					   <!--{loop $home_fans $value_fans}-->
                       <div class="zz_sidelist">
                            <a href="home.php?mod=space&uid=$value_fans[uid]" title="$value_fans[username]" target="_blank">
							    <img src="{echo avatar($value_fans[uid],'middle',1);}" />
							</a>
                            <a href="home.php?mod=space&uid=$value_fans[uid]" title="$value_fans[username]" class="name" target="_blank">$value_fans[username]</a>
                            <!--{eval $follow = 0;}-->
						    <!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $value_fans[uid]);}-->
						    <!--{if !$follow}-->
							    <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$value_fans[uid]" class="zz_butbase">{lang follow_add}TA</a>
						    <!--{else}-->
							    <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$value_fans[uid]" class="zz_butbase">{lang follow_del}</a>
						    <!--{/if}-->
                       </div>
					   <!--{/loop}-->
                  </div>
				<!--{/if}-->
				<!--{else}-->
				   <div class="zhanzhuai-gz-box zz_frame_c zz_br4 cl">
						<div class="zz_sidebox_tit cl">他的粉丝</div>
                        <div class="no-zz_sidelist">
                           暂无数据
                        </div>
				   </div>
				<!--{/if}-->
				

 <!--menu end-->

<script type="text/javascript">
function succeedhandle_followmod(url, msg, values) {
	var fObj = $('followmod');
	if(values['type'] == 'add') {
		fObj.innerHTML = '{lang follow_del}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
	} else if(values['type'] == 'del') {
		fObj.innerHTML = '{lang follow_add}TA';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
	}
}
</script>