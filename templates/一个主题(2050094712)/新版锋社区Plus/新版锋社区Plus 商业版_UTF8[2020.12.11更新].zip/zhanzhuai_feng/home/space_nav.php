<?php echo '请支持正版 - 一个主题 https://dism.taobao.com/?@57900.developer';exit;?>
<!--menu-->
<div class="zhanzhuai-s-menu cl">
     <ul>
		<li{if $do=='thread'} class="a"{/if}><a {if $_G['uid']}href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space"{else}href="member.php?mod=logging&action=login"{/if}>{lang topic}<span></span></a></li>
		<!--{if helper_access::check_module('blog')}-->
		<li{if $do=='blog'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space">{lang blog}<span></span></a></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('album')}-->
		<li{if $do=='album'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space">{lang album}<span></span></a></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('doing')}-->
		<li{if $do=='doing'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space">{lang doing}<span></span></a></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('home')}-->
		<li{if $do=='home'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=home&view=me&from=space">{lang feed}<span></span></a></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('share')}-->
		<li{if $do=='share'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space">{lang share}<span></span></a></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('follow')}-->
		<li{if CURMODULE == 'follow'} class="a"{/if}><a {if $_G['uid']}href="home.php?mod=follow&uid=$space[uid]&do=view&from=space"{else}href="member.php?mod=logging&action=login"{/if}>{lang follow}<span></span></a></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('wall')}-->
		<li{if $do==wall} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=wall&from=space">留言<span></span></a></li>
		<!--{/if}-->
		<li{if $do==profile} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=profile&from=space">详情<span></span></a></li>          
     </ul>
</div>
<!--menu end-->