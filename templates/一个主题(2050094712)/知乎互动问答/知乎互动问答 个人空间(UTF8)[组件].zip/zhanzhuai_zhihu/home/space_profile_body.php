<?php echo 'From: DisM.taobao.com';exit;?>
<div class="{if $_G[setting][homepagestyle]}{else}zhanzhuai_details{/if} u_profile">

	<div class="details-list-box cl">
	    <div class="details-title"><h2>基本信息</h2></div>
		<ul class="pf_l cl">
		    <li><em>用户名</em>{$space[username]}<!--{if $_G['ols'][$space[uid]]}-->
				<img src="{IMGDIR}/ol.gif" alt="online" title="{lang online}" class="vm" />&nbsp;
			<!--{/if}--></li>
		    <li><em>UID</em>{$space[uid]}
			<!--{eval $isfriendinfo = 'home_friend_info_'.$space['uid'].'_'.$_G[uid];}-->
			<!--{if $_G[$isfriendinfo][note]}-->
				, <span class="xg1">$_G[$isfriendinfo][note]</span>
			<!--{/if}--></li>
		</ul>
		
		<!--{if CURMODULE == 'space'}-->
			<!--{hook/space_profile_baseinfo_top}-->
		<!--{elseif CURMODULE == 'follow'}-->
			<!--{hook/follow_profile_baseinfo_top}-->
		<!--{/if}-->
	
		<ul class="pf_l cl">
			<!--{if $_G['setting']['allowspacedomain'] && $_G['setting']['domain']['root']['home'] && checkperm('domainlength') && !empty($space['domain'])}-->
			<!--{eval $spaceurl = 'http://'.$space['domain'].'.'.$_G['setting']['domain']['root']['home'];}-->
			<li><em>{lang second_domain}</em><a href="$spaceurl" onclick="setCopy('$spaceurl', '{lang copy_space_address}');return false;">$spaceurl</a></li>
			<!--{/if}-->
			<!--{if $_G[setting][homepagestyle]}-->
			<li><em>{lang space_visits}</em><strong class="xi1">$space[views]</strong></li>
			<!--{/if}-->
			<!--{if in_array($_G[adminid], array(1, 2))}-->
			<li><em>Email</em>$space[email]</li>
			<!--{/if}-->
			<li><em>{lang email_status}</em><!--{if $space[emailstatus] > 0}-->{lang profile_verified}<!--{else}-->{lang profile_no_verified}<!--{/if}--></li>
			<li><em>{lang video_certification}</em><!--{if $space[videophotostatus] > 0}-->{lang profile_certified} <!--{if $showvideophoto}-->&nbsp;&nbsp;(<a href="home.php?mod=space&uid=$space[uid]&do=videophoto" id="viewphoto" onclick="showWindow(this.id, this.href, 'get', 0)">{lang view_certification_photos}</a>)<!--{/if}--><!--{else}-->{lang profile_no_certified}<!--{/if}--></li>
		</ul>

		<ul class="pf_l cl">
		   <!--{if $space[adminid]}--><li><em>{lang management_team}</em><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[adminid]" target="_blank">{$space[admingroup][grouptitle]}</a></li><!--{/if}-->
		    <li><em>{lang usergroup}&nbsp;&nbsp;</em><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[groupid]" target="_blank">{$space[group][grouptitle]}</a></li>
		   <!--{if $space[extgroupids]}--><li><em>{lang group_expiry_type_ext}&nbsp;&nbsp;</em>$space[extgroupids]</li><!--{/if}-->
	    </ul>

		<ul class="pf_l cl">
			<!--{loop $profiles $value}-->
			<li><em>$value[title]</em>$value[value]</li>
			<!--{/loop}-->
		</ul>

		<ul class="pf_l cl">
			<!--{if $space[spacenote]}--><li><em class="xg1">{lang spacenote}&nbsp;&nbsp;</em>$space[spacenote]</li><!--{/if}-->
			<!--{if $space[customstatus]}--><li class="xg1"><em>{lang permission_basic_status}&nbsp;&nbsp;</em>$space[customstatus]</li><!--{/if}-->
			<!--{if $space[group][maxsigsize] && $space[sightml]}--><li><em class="xg1">{lang personal_signature}&nbsp;&nbsp;</em><table><tr><td>$space[sightml]</td></tr></table></li><!--{/if}-->
		</ul>
		<!--{if CURMODULE == 'space'}-->
			<!--{hook/space_profile_baseinfo_middle}-->
		<!--{elseif CURMODULE == 'follow'}-->
			<!--{hook/follow_profile_baseinfo_middle}-->
		<!--{/if}-->
		
	</div>

<!--{if $space['medals']}-->
	<div class="details-list-box cl">
		 <div class="details-title"><h2>{lang medals}</h2></div>
		<p class="md_ctrl">
			<a href="home.php?mod=medal">
			<!--{loop $space['medals'] $medal}-->
				<img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" id="md_{$medal[medalid]}" onmouseover="showMenu({'ctrlid':this.id, 'menuid':'md_{$medal[medalid]}_menu', 'pos':'12!'});" />
			<!--{/loop}-->
			</a>
		</p>
	</div>
	<!--{loop $space['medals'] $medal}-->
		<div id="md_{$medal[medalid]}_menu" class="tip tip_4" style="display: none;">
			<div class="tip_horn"></div>
			<div class="tip_c">
				<h4>$medal[name]</h4>
				<p>$medal[description]</p>
			</div>
		</div>
	<!--{/loop}-->
<!--{/if}-->
<!--{if $_G['setting']['verify']['enabled']}-->
	<!--{eval $showverify = true;}-->
	<!--{loop $_G['setting']['verify'] $vid $verify}-->
		<!--{if $verify['available']}-->
			<!--{if $showverify}-->
			<div class="details-list-box cl">
			 <div class="details-title"><h2>{lang profile_verify}</h2></div>
			<!--{eval $showverify = false;}-->
			<!--{/if}-->
         
		 <div class="pf_l cl">
			<!--{if $space['verify'.$vid] == 1}-->
				<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $verify['icon']}--><img src="$verify['icon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{else}-->$verify[title]<!--{/if}--></a>&nbsp;
			<!--{elseif !empty($verify['unverifyicon'])}-->
				<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $verify['unverifyicon']}--><img src="$verify['unverifyicon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{/if}--></a>&nbsp;
			<!--{/if}-->
	     </div>

		<!--{/if}-->
	<!--{/loop}-->
	<!--{if !$showverify}--></div><!--{/if}-->
<!--{/if}-->
<!--{if $count}-->
	<div class="details-list-box cl">
		 <div class="details-title"><h2>{lang manage_forums}</h2></div>
		 <div class="pf_l cl">
		<!--{loop $manage_forum $key $value}-->
		<a href="forum.php?mod=forumdisplay&fid=$key" target="_blank">$value</a> &nbsp;
		<!--{/loop}-->
		</div>
	</div>
<!--{/if}-->
<!--{if $groupcount}-->
	<div class="details-list-box cl">
		 <div class="details-title"><h2>{lang joined_group}</h2></div>
		 <div class="pf_l cl">
		<!--{loop $usergrouplist $key $value}-->
		<a href="forum.php?mod=group&fid={$value['fid']}" target="_blank">$value['name']</a> &nbsp;
		<!--{/loop}-->
		</div>
	</div>
<!--{/if}-->
<div class="details-list-box cl">
	 <div class="details-title"><h2>{lang active_profile}</h2></div>
	<ul id="pbbs" class="pf_l">
		<!--{if $space[oltime]}--><li><em>{lang online_time}</em>$space[oltime] {lang hours}</li><!--{/if}-->
		<li><em>{lang regdate}</em>$space[regdate]</li>
		<li><em>{lang last_visit}</em>$space[lastvisit]</li>
		<!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
		<li><em>{lang register_ip}</em>$space[regip] - $space[regip_loc]</li>
		<li><em>{lang last_visit_ip}</em>$space[lastip]:$space[port] - $space[lastip_loc]</li>
		<!--{/if}-->
		<!--{if $space[lastactivity]}--><li><em>{lang last_activity_time}</em>$space[lastactivity]</li><!--{/if}-->
		<!--{if $space[lastpost]}--><li><em>{lang last_post_time}</em>$space[lastpost]</li><!--{/if}-->
		<!--{if $space[lastsendmail]}--><li><em>{lang last_send_email}</em>$space[lastsendmail]</li><!--{/if}-->
		<li><em>{lang time_offset}</em>
			<!--{eval $timeoffset = array({lang timezone});}-->
			$timeoffset[$space[timeoffset]]
		</li>
	</ul>
</div>

<!--{if $clist}-->
<div class="cl">
	 <div class="details-title"><h2>{lang crime_record}</h2></div>
	<table id="pcr" class="dt">
		<tr>
			<th width="15%">{lang crime_action}</th>
			<th width="15%">{lang crime_dateline}</th>
			<th>{lang crime_reason}</th>
			<th width="15%">{lang crime_operator}</th>
		</tr>
		<!--{loop $clist $crime}-->
		<tr>
			<td>
				<!--{if $crime[action] == 'crime_delpost'}-->
					{lang crime_delpost}
				<!--{elseif $crime[action] == 'crime_warnpost'}-->
					{lang crime_warnpost}
				<!--{elseif $crime[action] == 'crime_banpost'}-->
					{lang crime_banpost}
				<!--{elseif $crime[action] == 'crime_banspeak'}-->
					{lang crime_banspeak}
				<!--{elseif $crime[action] == 'crime_banvisit'}-->
					{lang crime_banvisit}
				<!--{elseif $crime[action] == 'crime_banstatus'}-->
					{lang crime_banstatus}
				<!--{elseif $crime[action] == 'crime_avatar'}-->
					{lang crime_avatar}
				<!--{elseif $crime[action] == 'crime_sightml'}-->
					{lang crime_sightml}
				<!--{elseif $crime[action] == 'crime_customstatus'}-->
					{lang crime_customstatus}
				<!--{/if}-->
			</td>
			<td><!--{date($crime[dateline])}--></td>
			<td>$crime[reason]</td>
			<td><a href="home.php?mod=space&uid=$crime[operatorid]" target="_blank">$crime[operator]</a></td>
		</tr>
		<!--{/loop}-->
	</table>
</div>
<!--{/if}-->
<!--{if CURMODULE == 'space'}-->
	<!--{hook/space_profile_extrainfo}-->
<!--{elseif CURMODULE == 'follow'}-->
	<!--{hook/follow_profile_extrainfo}-->
<!--{/if}-->

<!--{if CURMODULE == 'space'}-->
	<!--{hook/space_profile_baseinfo_bottom}-->
<!--{elseif CURMODULE == 'follow'}-->
	<!--{hook/follow_profile_baseinfo_bottom}-->
<!--{/if}-->

</div>