<?php echo 'From: DisM.taobao.com';exit;?>

<style type="text/css">
.post-tit a {
    font-size: 18px;
    color: #333;
    font-weight: 600;
}
</style>
{eval
	$filter = array( 'common' => '{lang have_posted}', 'save' => '{lang draft}', 'close' => '{lang closed}', 'aduit' => '{lang pending}', 'ignored' => '{lang ignored}', 'recyclebin' => '{lang recyclebin}');
	$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=thread&view=me\">{lang they_thread}</a>";
}

<!--{if $diymode}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
		<div id="ct" class="ct2 wp cl">
			<div class="mn">
				<div class="bm">
					<div class="bm_h">
						<!--{if $space[self]}--><span class="xi2 y"><a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="addnew">{lang posted}</a></span><!--{/if}-->
						<h1 class="mt">
							<!--{if $_GET[type] == 'reply'}-->
							<span class="xs1 xw0"><a href="home.php?mod=space&do=thread&view=me&type=thread&uid=$space[uid]&from=space">{lang topic}</a><span class="pipe">|</span></span>{lang reply}
							<!--{else}-->
							{lang topic}<span class="xs1 xw0"><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=reply&uid=$space[uid]&from=space">{lang reply}</a></span>
							<!--{/if}-->
						</h1>
					</div>
				<div class="bm_c">
	<!--{else}-->
		<!--{template common/header}-->

		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="ct2 wp cl">
			<div class="c-sideLeft cl">

			    <div class="box cl">  
			         <!--{template home/space_menu_z}-->
				     <!--{if $diymode && !$_G[setting][homepagestyle] }-->
			             <p class="tbmu" style="padding: 16px 21px 14px; border-bottom: none;">
				             <a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread" $orderactives[thread]>{lang topic}</a>
				             <span class="pipe">|</span>
				             <a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=reply" $orderactives[reply]>{lang reply}</a>
			             </p>
		             <!--{/if}-->
				</div>
	<!--{/if}-->
<!--{else}-->
	<!--{template common/header}-->
	<div id="pt" class="bm cl">
		<div class="z">
			<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
			<!--{if $_G[setting][homestyle]}--><a href="home.php">$_G[setting][navs][4][navname]</a> <em>&rsaquo;</em> <!--{/if}-->
			<a href="home.php?mod=space&do=blog">{lang thread}</a>
		</div>
	</div>
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ct" class="ct2_a wp cl">
	<!--{if $_G[setting][homestyle]}-->
		<div class="appl">
			<!--{subtemplate common/userabout}-->
		</div>
		<div class="mn pbw">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<ul class="tb cl">
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
	<!--{else}-->
		<div class="appl">
			<div class="tbn">
				<h2 class="mt bbda">{lang thread}</h2>
				<ul>
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
		</div>
		<div class="mn pbw">
		<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
	<!--{/if}-->
<!--{/if}-->
		
		<!--{if !$diymode && $space[self]}-->
			<!--{if $_GET['view'] == 'me'}-->
			<p class="tbmu bw0">
				<!--{if $viewtype != 'postcomment'}-->
					<span class="y">
					<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=" {if !$_GET[filter]}class="a"{/if}>{lang all}</a>
					<!--{loop $filter $key $name}--><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=$key" {if $key == $_GET[filter]}class="a"{/if}>$name</a><!--{/loop}--> &nbsp;
						<select name="forumlist" id="forumlist" class="ps vm" onchange="viewforumthread(this.value);" style="width: 120px; word-wrap: normal;">
							<option value="0">{lang follow_select_forum}</option>
							$forumlist
						</select>
					</span>
				<!--{/if}-->
				<a href="home.php?mod=space&do=thread&view=me&type=thread" $orderactives[thread]>{lang topic}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=reply" $orderactives[reply]>{lang reply}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=postcomment" $orderactives[postcomment]>{lang post_comment}</a>
				<!--{if $viewtype != 'reply' && $viewtype != 'postcomment'}-->&nbsp; <input type="text" id="searchmypost" class="px vm" size="15" /> <button class="pn vm" onclick="searchpostbyusername($('searchmypost').value, '$_G[username]');"><em>{lang search}</em></button><!--{/if}-->
			</p>
			<!--{elseif $_GET['view'] == 'all'}-->
			<p class="tbmu bw0">
				<a href="home.php?mod=space&do=thread&view=all&order=dateline" $orderactives[dateline]>{lang newest_thread}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=all&order=hot" $orderactives[hot]>{lang top_thread}</a>
			</p>
			<!--{/if}-->
		<!--{/if}-->

		<!--{if $userlist}-->
			<p class="tbmu bw0">
				{lang view_by_friend}
				<select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
					<option value="">{lang all_friends}</option>
					<!--{loop $userlist $value}-->
					<option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
					<!--{/loop}-->
				</select>
			</p>
		<!--{/if}-->
		<div class="zhanzhuai-postlist-box">
			<form method="post" autocomplete="off" name="delform" id="delform" action="home.php?mod=space&do=thread&view=all&order=dateline" onsubmit="showDialog('{lang del_select_thread_confirm}', 'confirm', '', '$(\'delform\').submit();'); return false;">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="delthread" value="true" />

<div class="home-post-list">

<!--{if $list}-->

<ul>
<!--{loop $list $stid $thread}-->
   <!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
   <!--{eval $from_forum = C::t('forum_forum')->fetch_info_by_fid($thread['fid']);}--> 
   <!--{eval $thread['name'] = $from_forum['name'];}--> 
   <!--{eval $messages = DB::result(DB::query("SELECT message FROM ".DB::table('forum_post')." WHERE `tid`= '$thread[tid]' AND first = 1"));}-->
   <!--{eval $message = messagecutstr($messages,200);}-->

<li id="$thread[id]" class="zhanzhuai-post-list box"{if $_G['hiddenexists'] && $thread['hidden']} style='display:none'{/if}>	 
      <div class="post-tit cl">
		     <!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
                <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="s" target="_blank">$thread[subject]</a>
             <!--{else}-->
				<a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank" {if $thread['displayorder'] == -1}class="recy"{/if}>$thread[subject]</a>
			 <!--{/if}-->
	  </div>
      <div class="post-author cl">	
          <div class="post-author-basic">
		      <a href="home.php?mod=space&uid=$thread[authorid]" c="1" class="zz_author_pt">
			     <!--{avatar($thread[authorid],middle)}-->
				 <span class="author-name"><!--{if $thread['authorid'] && $thread['author']}-->$thread[author]<!--{else}-->$_G[setting][anonymoustext]<!--{/if}-->
				 </span>
			  </a>
		  </div>		       

		  <div class="icons y">
		      <a href="forum.php?mod=viewthread&tid=$thread[tid]&highlight=$index[keywords]" title="{lang open_new_window}" target="_blank">
					<!--{if $thread[folder] == 'lock'}-->
						<span>����</span>
					<!--{elseif $thread['special'] == 1}-->
						<span>ͶƱ</span>
					<!--{elseif $thread['special'] == 2}-->
						<span>{lang thread_trade}</span>
					<!--{elseif $thread['special'] == 3}-->
						<span>����</span>
					<!--{elseif $thread['special'] == 4}-->
						<span>�</span>
					<!--{elseif $thread['special'] == 5}-->
						<span>����</span>
					<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					    <span class="stick_$thread[displayorder]">��$thread[displayorder]</span>
					<!--{else}-->
						<span>�´�</span>
					<!--{/if}-->
				</a>

				<!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
				      <span class="digest_$thread[digest]" title="����$thread[digest]">��$thread[digest]</span>
                <!--{/if}-->

				<!--{if $thread['attachment'] == 2}-->
                    <span class="image_s" title="��ͼ">ͼƬ</span>
                <!--{elseif $thread['attachment'] == 1}-->
                    <span class="image_s" title="�и���">����</span>
                <!--{/if}-->
                <!--{if $thread[recommendicon] && $filter != 'recommend'}-->
                    <span class="recommend">�Ƽ�</span>
                <!--{/if}-->
                <!--{if $thread[heatlevel]}-->
                    <span class="hot">��</span>
                <!--{/if}-->
              </div>
      </div>
  
      <div class="post-content cl">
	      <!--{eval $zhanzhuai_img = substr($thread[tid], -1); $zhanzhuai_img_jh = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$zhanzhuai_img.'')." WHERE `tid`= $thread[tid] AND isimage = '1' ORDER BY `dateline` DESC limit 0 , 1");}-->
		  <!--{if $zhanzhuai_img_jh}-->
          <div class="post-img">
               <!--{loop $zhanzhuai_img_jh $zhanzhuai_imgs}-->
               <!--{eval $piclists = getforumimg($zhanzhuai_imgs[aid], 0, 160, 105);}-->
                   <a href="forum.php?mod=viewthread&tid=$thread[tid]"><img src="$piclists"></a>
               <!--{/loop}-->
          </div>
		  <!--{/if}-->
          <div class="post-profile cl">$message<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="check-all" target="_blank">�鿴ȫ��<i></i></a></div>
      </div>

	  <div class="post-actions cl">
            <span class="post-recommend" title="$thread[recommend_add]�˵���">
			  <i class="zhanzhuai-icons"></i>$thread[recommend_add]
			</span>

			<span class="post-viem">
			   <i class="zhanzhuai-icons"></i><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></a>
			</span>

			<span class="post-reply">
			   <i class="zhanzhuai-icons"></i>{$thread[replies]}
			</span>

			<span class="post-fav">
			   <i class="zhanzhuai-icons"></i>{$thread[favtimes]}
			</span>

			<span class="post-time"><i class="zhanzhuai-icons"></i>{$thread[dateline]}</span>
            
			<span class="post-from y">
		      <a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$thread['name']</a>
              <!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
				  <!--{eval $thread[tid]=$thread[closed];}-->
			  <!--{/if}-->
				   $thread[typehtml] $thread[sorthtml]
			  <!--{if $thread['moved']}-->
					{lang thread_moved}:<!--{eval $thread[tid]=$thread[closed];}-->
			  <!--{/if}-->
			</span>
       </div>
   </li>
<!--{/loop}-->
<ul>
<!--{else}-->
                  <div class="zhanzhuai_home_nodata cl">
                       <span></span>
                       <p>TA��û�з������κδ���</p>
                  </div>
					
					<!--{/if}-->
					</div>

					<!--{if $_GET['view'] == 'all' && $pruneperm && !$_GET['archiveid'] && $list}-->
						<p class="mtm pns">
							<label for="chkall" onclick="checkall(this.form, 'moderate')"><input type="checkbox" name="chkall" id="chkall" class="pc vm" />{lang select_all}</label>
							<button type="submit" name="delsubmit" value="true" class="pn vm"><em>{lang del_select_thread}</em></button>
						</p>
					<!--{/if}-->
				</form>

				<!--{if $hiddennum}-->
					<p class="mtm">{lang hide_thread}</p>
				<!--{/if}-->
			</div>
			<!--{if $multi}--><div class="pgs cl mtm mbm">$multi</div><!--{/if}-->		
		
		<script type="text/javascript">
		function fuidgoto(fuid) {
			window.location.href = 'home.php?mod=space&do=thread&view=we&fuid='+fuid;
		}
		function viewforumthread(fid) {
			window.location.href = '{$forumurl}&fid='+fid;
		}
		</script>
		
		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
          
		<!--{if !$_G[setting][homepagestyle]}-->
            </div>
			<div class="c-sideRight cl">
				<!--{subtemplate home/space_userabout_z}-->
            </div>
        <!--{/if}-->

			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			</div>
			</div>
			<div class="sd">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->

<!--{template common/footer}-->
