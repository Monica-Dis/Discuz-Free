<?php echo 'From: DisM.taobao.com';exit;?>
<div class="pf_btn pf_follow_btn cl">

<!--{if !$viewself}-->
		<ul id="followflag" {if !isset($flag[$_G['uid']])}style="display: none"{/if}>
		        <li><a id="a_followmod_{$uid}" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$uid&from=head" onclick="ajaxget(this.href);doane(event);">{lang follow_del}</a></li>
			<!--{if helper_access::check_module('follow')}-->
			    <li style="margin-right: 0;"><a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&special={if $flag[$_G['uid']]['status'] == 1}2{else}1{/if}&fuid=$uid&from=head" class="btn_send" id="specialflag_$uid" onclick="ajaxget(this.href);doane(event);" title="{if $flag[$_G['uid']]['status'] == 1}{lang follow_del_special_following}{else}{lang follow_add_special_following}{/if}"><!--{if $flag[$_G['uid']]['status'] == 1}-->{langfollow_del_special_following}<!--{else}-->{lang follow_add_special_following}<!--{/if}--></a></li>
			<!--{/if}-->  
		</ul>
		<ul id="unfollowflag" {if isset($flag[$_G['uid']])}style="display: none"{/if}>
			<!--{if helper_access::check_module('follow')}-->
			<!--{if $_G['uid']}-->
			    <li><a id="a_followmod_{$uid}" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$uid&from=head" onclick="ajaxget(this.href);doane(event);" style="margin-right: 0;">{lang follow_add}</a></li>
			<!--{else}-->
			    <li><a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" onclick="showWindow('login', this.href);return false;" style="margin-right: 0;">{lang follow_add}</a></li>
			<!--{/if}-->
			<!--{/if}-->
		</ul>
<!--{/if}-->
</div>
