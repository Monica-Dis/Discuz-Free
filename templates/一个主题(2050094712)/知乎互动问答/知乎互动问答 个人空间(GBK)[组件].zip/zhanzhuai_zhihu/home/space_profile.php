<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G[setting][homepagestyle]}-->
	<!--{subtemplate home/space_header}-->
	<div id="ct" class="ct2 wp cl">
		<div class="mn">
			<div class="bm">
				<div class="bm_h">
					<h1 class="mt">{lang memcp_profile}</h1>
				</div>
			<div class="bm_c">
<!--{else}-->
	<!--{template common/header}-->
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<!--{template home/space_menu}-->
	<div id="ct" class="ct2 wp cl">
			<div class="c-sideLeft box cl">
			    <!--{template home/space_menu_z}-->

          <!--{/if}-->

				<!--{subtemplate home/space_profile_body}-->
		
				<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if !$_G[setting][homepagestyle]}-->

			</div>
			<div class="c-sideRight cl">
				<!--{subtemplate home/space_userabout_z}-->
            </div>
        <!--{/if}-->

			<!--{if $_G[setting][homepagestyle]}-->
			        </div>
               </div>
			</div>
			<div class="sd">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
	</div>
</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->
<!--{template common/footer}-->
