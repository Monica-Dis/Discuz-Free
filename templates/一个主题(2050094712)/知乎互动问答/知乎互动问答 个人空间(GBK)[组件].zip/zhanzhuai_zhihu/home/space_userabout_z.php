<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $encodeusername = rawurlencode($space[username]);}-->

    <!--{eval $zhanzhuai_count = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = $space[uid]");}-->
    <!--{eval $zhanzhuai_jifen = DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE uid = $space[uid]");}-->

	<div class="zhanzhuai_follow_count box">
         <ul class="cl">
             <li>
			     <a href="home.php?mod=follow&do=following&uid=$uid">
                     <p class="inst">��ע</p>
                     <p class="number">$zhanzhuai_count['following']</p>
				 </a>
             </li>
             <li style=" border-right: none;">
			     <a href="home.php?mod=follow&do=follower&uid=$uid">
                     <p class="inst">��˿</p>
                     <p class="number">$zhanzhuai_count['follower']</p>
				 </a>
             </li>
          </ul>
    </div>

	<div class="zhanzhuai_m_count box">
        <ul class="cl">
             <li><span class="m_posts z">���뻰��</span><em class="y">$zhanzhuai_count['posts']</em></li>
             <li><span class="m_threads z">��������</span><em class="y">$zhanzhuai_count['threads']</em></li>
             <li><span class="m_jf z"><i class="icon icon-score"></i>����</span><em class="y">$zhanzhuai_jifen['credits']</em></li>
			 <li><span class="m_jb z"><i class="icon icon-coin-yen"></i>���</span><em class="y">$zhanzhuai_count['extcredits2']</em></li>
             <li><span class="m_ww z"><i class="icon icon-prestige"></i>����</span><em class="y">$zhanzhuai_count['extcredits1']</em></li>
        </ul>
	</div>

<!--{eval $home_gzs = DB::fetch_all("select * from ".DB::table('home_follow')." where uid = $uid order by followuid desc limit 0,10 "); $home_fans = DB::fetch_all("select * from ".DB::table('home_follow')." where followuid = $uid order by uid desc limit 0,3 ");}-->
	<!--{if $home_gzs}-->
		<!--{if $_GET[do]!='following' && $_GET[do]!='follower'}-->
            <div class="zhanzhuai-gz zhanzhuai_expert box cl">
		         <div class="zhanzhuai_diytit cl">
                      <h2>���Ĺ�ע</h2>
                 </div>	
				 <ul>
				 <!--{loop $home_gzs $key $value_gzs}-->
				 <!--{eval $z_num = $key+1;}-->
				 <!--{eval $zhanzhuai_gz_count = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = $value_gzs[followuid]");}-->
				     <li class="zhanzhuai_$z_num">
                         <div class="zhanzhuai_e-info cl">
                              <div class="zhanzhuai_figure">
         	                       <a href="home.php?mod=space&uid=$value_gzs[followuid]" title="$value_gzs[fusername]" target="_blank">
			                           <img src="{echo avatar($value_gzs[followuid],'middle',1);}" width="60" height="90">
			                       </a>
		                      </div>
                              <div class="zhanzhuai_other">
                                   <p class="zhanzhuai_name"><a href="home.php?mod=space&uid=$value_gzs[followuid]" title="$value_gzs[fusername]" target="_blank">$value_gzs[fusername]</a></p>
                                   <p class="zhanzhuai_inst">�������� : $zhanzhuai_gz_count['posts']</p>
                                   <p class="zhanzhuai_inst">���뻰�� : $zhanzhuai_gz_count['threads']</p>
                              </div>
                              <span class="sideList y">
                                  <!--{eval $follow = 0;}-->
					              <!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $value_gzs[followuid]);}-->
					              <!--{if !$follow}-->
						              <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$value_gzs[followuid]" class="butbase">{lang follow_add}TA</a>
					              <!--{else}-->
						              <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$value_gzs[followuid]" class="butbase">{lang follow_del}</a>
					              <!--{/if}-->
                             </span>
				        </div>
                     </li> 
				  <!--{/loop}-->
				  </ul>
              </div>
		  <!--{/if}-->
	 <!--{else}-->
	 <div class="zhanzhuai-gz-box box cl">
		  <div class="zhanzhuai_diytit cl">
               <h2>���Ĺ�ע</h2>
          </div>				  
          <div class="no-sideList">��������</div>
	 </div>
	 <!--{/if}-->

<!--{eval $home_fans = DB::fetch_all("select * from ".DB::table('home_follow')." where followuid = $uid order by uid desc limit 0,3 ");}-->
     <!--{if $home_fans}-->
		 <!--{if $_GET[do]!='following' && $_GET[do]!='follower'}-->
             <div class="zhanzhuai-gz zhanzhuai_expert box cl">
				  <div class="zhanzhuai_diytit cl">
                       <h2>���ķ�˿</h2>
                  </div>
				  <ul>
				  <!--{loop $home_fans $key $value_fans}-->
				  <!--{eval $z_num2 = $key+1;}-->
				  <!--{eval $zhanzhuai_gz_count2 = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = $value_fans[followuid]");}-->
				     <li class="zhanzhuai_$z_num2">
                         <div class="zhanzhuai_e-info cl">
                              <div class="zhanzhuai_figure">
         	                        <a href="home.php?mod=space&uid=$value_fans[uid]" title="$value_fans[fusername]" target="_blank">
			                           <img src="{echo avatar($value_fans[uid],'middle',1);}" width="60" height="90">
			                       </a>
		                      </div>
                              <div class="zhanzhuai_other">
                                   <p class="zhanzhuai_name"><a href="home.php?mod=space&uid=$value_fans[uid]" title="$value_fans[fusername]" target="_blank">$value_fans[username]</a></p>
                                   <p class="zhanzhuai_inst">�������� : $zhanzhuai_gz_count2['posts']</p>
                                   <p class="zhanzhuai_inst">���뻰�� : $zhanzhuai_gz_count2['threads']</p>
                              </div>
                              <span class="sideList y">
                                  <!--{eval $follow = 0;}-->
					              <!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $value_fans[uid]);}-->
					              <!--{if !$follow}-->
							          <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$value_fans[uid]" class="butbase">{lang follow_add}TA</a>
					              <!--{else}-->
							          <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$value_fans[uid]" class="butbase">{lang follow_del}</a>
					              <!--{/if}-->
                             </span>
				        </div>
                     </li>
			       <!--{/loop}-->
				   </ul>
             </div>
		     <!--{/if}-->
		<!--{else}-->
		<div class="zhanzhuai-gz-box box cl">
			 <div class="zhanzhuai_diytit cl">
                  <h2>���ķ�˿</h2>
             </div>				  
             <div class="no-sideList">��������</div>
		</div>
	<!--{/if}-->
 <!--menu end-->

<script type="text/javascript">
function succeedhandle_followmod(url, msg, values) {
	var fObj = $('followmod');
	if(values['type'] == 'add') {
		fObj.innerHTML = '{lang follow_del}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
	} else if(values['type'] == 'del') {
		fObj.innerHTML = '{lang follow_add}TA';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
	}
}
</script>
