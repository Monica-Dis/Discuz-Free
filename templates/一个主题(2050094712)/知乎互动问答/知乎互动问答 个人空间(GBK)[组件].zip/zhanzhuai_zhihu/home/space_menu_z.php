<?php echo 'From: DisM.taobao.com';exit;?>
<!--menu-->
<div class="zhanzhuai-s-menu cl">
     <ul>
		<li{if $do=='thread'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space"><i class="thread-icon"></i>����</a><span></span></li>
		<!--{if helper_access::check_module('blog')}-->
		<li{if $do=='blog'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space"><i class="blog-icon"></i>{lang blog}</a><span></span></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('album')}-->
		<li{if $do=='album'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space"><i class="album-icon"></i>{lang album}</a><span></span></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('doing')}-->
		<li{if $do=='doing'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space"><i class="doing-icon"></i>{lang doing}</a><span></span></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('home')}-->
		<li{if $do=='home'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=home&view=me&from=space"><i class="home-icon"></i>{lang feed}</a><span></span></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('share')}-->
		<li{if $do=='share'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space"><i class="share-icon"></i>{lang share}</a><span></span></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('follow')}-->
		<li{if CURMODULE == 'follow'} class="a"{/if}><a href="home.php?mod=follow&uid=$space[uid]&do=view&from=space"><i class="follow-icon"></i>{lang follow}</a><span></span></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('wall')}-->
		<li{if $do=='wall'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=wall&from=space"><i class="wall-icon"></i>����</a><span></span></li>
		<!--{/if}-->
		<li{if $do=='profile'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=profile&from=space"><i class="profile-icon"></i>����</a><span></span></li>          
     </ul>
</div>
<!--menu end-->
