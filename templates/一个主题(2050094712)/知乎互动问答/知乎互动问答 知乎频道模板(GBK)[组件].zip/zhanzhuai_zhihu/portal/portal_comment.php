<?php echo 'From: DISM��TAOBAO��COM';exit;?>
<div id="comment">
	 <div id="comment_ul" class="zz_comment_list cl">
	     <!--{if !empty($pricount)}-->
			<p class="mtn mbn y">{lang hide_portal_comment}</p>
		<!--{/if}-->
        <ul>
		<!--{loop $commentlist $comment}-->
		    <!--{template portal/comment_li}-->
		    <!--{if !empty($aimgs[$comment[cid]])}-->
			     <script type="text/javascript" reload="1">aimgcount[{$comment[cid]}] = [<!--{echo implode(',', $aimgs[$comment[cid]]);}-->];attachimgshow($comment[cid]);</script>
		    <!--{/if}-->
		<!--{/loop}-->
	    </ul>
	</div>

	<div class="zz_all_comments box cl">
	    <!--{if $data[commentnum]}-->
		   <a href="$common_url" class="xi2">{lang view_all_comments}</a>
		<!--{else}-->
		   <p>�����������</p>
		<!--{/if}-->
	</div>
</div>

<!--{if !$data[htmlmade]}-->
<form id="cform" name="cform" action="$form_url" method="post" autocomplete="off">

	<div class="tedt zz_news_tedt box" style=" width: 100%; border: none;">
	     <h2>����<span>�����������Է��ԣ�ȫվ�ɼ�������������</h2>
		 <div class="zz_news_textarea">
			<textarea name="message" rows="3" id="message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');"></textarea>
		 </div>
	</div>
    <!--{if !empty($topicid) }-->
		<input type="hidden" name="referer" value="$topicurl#comment" />
		<input type="hidden" name="topicid" value="$topicid">
	<!--{else}-->
		<input type="hidden" name="portal_referer" value="$viewurl#comment">
		<input type="hidden" name="referer" value="$viewurl#comment" />
		<input type="hidden" name="id" value="$data[id]" />
		<input type="hidden" name="idtype" value="$data[idtype]" />
		<input type="hidden" name="aid" value="$aid">
	<!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}">
		<input type="hidden" name="replysubmit" value="true">
		<input type="hidden" name="commentsubmit" value="true" />

    <div class="zz_news_tedt_btn cl">
	    <!--{if $secqaacheck || $seccodecheck}-->
		    <!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
		    <span class="mtm z"><!--{subtemplate common/seccheck}--></span>
	    <!--{/if}-->
            <p class="y">
			    <button type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="true">��������</button>
		    </p>
	 </div>
</form>		
<!--{/if}-->
