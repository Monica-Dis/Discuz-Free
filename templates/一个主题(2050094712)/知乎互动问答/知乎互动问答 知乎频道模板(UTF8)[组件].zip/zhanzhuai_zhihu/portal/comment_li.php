<?php echo 'From: DISM·TAOBAO·COM';exit;?>

<li class="box cl">
   <a name="comment_anchor_$comment[cid]"></a>
   <div id="comment_{$comment[cid]}_li" class="zz_comment_pi cl">
        <div class="zhanzhuai_cleft_avatar">
		    <a href="home.php?mod=space&uid=$comment[uid]"><!--{avatar($comment[uid],middle)}--></a>
		</div>
		<!--{if !empty($comment['uid'])}-->
		   <a href="home.php?mod=space&uid=$comment[uid]">$comment[username]</a>
	    <!--{else}-->
		   {lang guest}
	    <!--{/if}-->
		&nbsp;发布于&nbsp;&nbsp;<!--{date($comment[dateline])}-->&nbsp;&nbsp;
        <!--{if $comment[status] == 1}--><b>({lang moderate_need})</b><!--{/if}-->
	</div>

	<div class="zz_comment_message"><!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->$comment[message]<!--{else}--> {lang moderate_not_validate}<!--{/if}--></div>

	<div class="zz_comment_pob cl">
			<!--{if !isset($_G[makehtml])}--><em><a href="javascript:;" onclick="portal_comment_requote($comment[cid], '$article[aid]');" class="fastre">{lang quote}</a></em><!--{/if}-->
			<!--{if ($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']}-->
			<p>
			   <a href="portal.php?mod=portalcp&ac=comment&op=edit&cid=$comment[cid]" id="c_$comment[cid]_edit" onclick="showWindow(this.id, this.href, 'get', 0);">{lang edit}</a>
			   <a href="portal.php?mod=portalcp&ac=comment&op=delete&cid=$comment[cid]" id="c_$comment[cid]_delete" onclick="showWindow(this.id, this.href, 'get', 0);">{lang delete}</a>
			</p>
			<!--{/if}-->
	</div>
</li>