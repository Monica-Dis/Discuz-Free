<?php echo 'From: DISM·TAOBAO·COM';exit;?>	

<div class="zz_sousuo_c">
	<div class="zhanzhuai_sttl">
		<h2><!--{if $keyword && empty($searchstring[2])}-->{lang search_group_result_keyword}  <!--{if empty($viewgroup) && !empty($grouplist)}--><a href="search.php?mod=group&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes&viewgroup=1" target="_blank">{lang search_group_viewgroup}</a><!--{/if}--><!--{elseif $viewgroup}-->{lang search_group_result}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->

<!--{if $viewgroup}-->
	<!--{if empty($grouplist)}-->
		<div class="zhanzhuai_sc_nothread"><span></span><p>对不起，没有找到匹配结果</p></div>
	<!--{else}-->
		<div class="zz_sousuo_g cl">
			<!--{loop $grouplist $key $group}-->
			<!--{eval $zz_gnum = $key +1;}-->
				<dl class="xld xld_a z zz_gnum$zz_gnum">
					<dd class="m"><a href="forum.php?mod=group&fid=$group[fid]" target="_blank"><img src="$group[icon]" alt="" /></a></dd>
					<dt><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><!--{if $group['gviewperm'] == 1}-->({lang public})<!--{/if}--></dt>
					<dd>{lang member}: $group[membernum], {lang threads}: $group[threads]</dd>
					<dd>{lang credits}: $group[commoncredits], {lang creating_time}: $group[dateline]</dd>
				</dl>
			<!--{/loop}-->
		</div>
		<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
	<!--{/if}-->
<!--{else}-->
	<!--{if !empty($grouplist) && $page < 2}-->
		<div class="zz_sousuo_g cl">
			<!--{loop $grouplist $key $group}-->
			<!--{eval $zz_gnum = $key +1;}-->
				<dl class="xld xld_a z zz_gnum$zz_gnum">
					<dd class="m"><a href="forum.php?mod=group&fid=$group[fid]" target="_blank"><img src="$group[icon]" alt="" /></a></dd>
					<dt><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><!--{if $group['gviewperm'] == 1}-->({lang public})<!--{/if}--></dt>
					<dd>{lang member}: $group[membernum], {lang threads}: $group[threads]</dd>
					<dd>{lang credits}: $group[commoncredits], {lang creating_time}: $group[dateline]</dd>
				</dl>
			<!--{/loop}-->
		</div>
	<!--{/if}-->

<div class="zhanzhuai_slst cl" {if $modfid} style="position: relative;"{/if}>
	<!--{if !empty($threadlist)}-->
			<ul>
			<!--{loop $threadlist $thread}-->
			<!--{eval $messages = DB::result(DB::query("SELECT message FROM ".DB::table('forum_post')." WHERE `tid`= '$thread[tid]' AND first = 1"));}-->
			<!--{eval $message = messagecutstr($messages,170);}-->
				<li class="pbw cl" id="$thread[tid]">
				    <div class="zz_sousuo_tit cl">
					    <h3><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank" $thread[highlight]>$thread[subject]</a></h3>
						<span class="y"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank" class="zz_forumname">#$thread[forumname]#</a></span>
					</div>
					<!--{eval $zz_sc_pic = substr($thread[tid], -1); $zz_threadpic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$zz_sc_pic.'')." WHERE `tid`= $thread[tid] AND isimage = '1' ORDER BY `dateline` DESC");}-->
                    <!--{eval $picn = count($zz_threadpic);}-->

                    <!--{if ($picn > 2)}-->
                        <!--{eval $picn2 = '3';}-->
                    <!--{elseif $picn < 3 && $picn}-->
                        <!--{eval $picn2 = '1';}-->
                    <!--{/if}-->

                    <!--{if $picn > 0}-->
	                    <!--{eval $sc_pic = substr($thread[tid], -1); $threadpic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$sc_pic.'')." WHERE `tid`= $thread[tid] AND isimage = '1' ORDER BY `dateline` DESC limit 0 , $picn2");}-->
                   <!--{/if}-->
                    
					<div class="zz_sousuo_nr" {if $picn < 3 && $picn}style="position: relative;height: 125px;"{/if}>
					   <!--{if $picn < 3 && $picn}-->
                           <div class="zz_sousuo_p1 cl"> 					      
                             <!--{loop $threadpic $zhanzhuaipic}-->
                             <!--{eval $piclist = getforumimg($zhanzhuaipic[aid], 0, 212, 125); }-->
                                   <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="img-wrap"><img src="$piclist"></a>
                             <!--{/loop}-->					
                           </div>
                       <!--{/if}-->
                       <div class="zz_sousuo_message" {if $picn < 3 && $picn}style=" float: left;width: 436px;"{/if}>$message</div>
	
                       <!--{if $picn > 2}-->
                           <div class="zz_sousuo_pn cl">  
						        <a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank">
                                    <!--{loop $threadpic $zhanzhuaipic}-->
                                    <!--{eval $piclist = getforumimg($zhanzhuaipic[aid], 0, 212, 125); }-->
                                        <img src="$piclist">
                                    <!--{/loop}-->
						        </a>
					       </div>
                       <!--{/if}-->

                       <div class="sc_footer cl" {if $picn < 3 && $picn}style="position: absolute;left: 224px;bottom: 5px;width: 436px;"{/if}> 
                           <a href="home.php?mod=space&uid=$thread[authorid]" class="username z" target="_blank">
                              <!--{avatar($thread[authorid],middle)}-->
                              <span>$thread[author]</span>
                           </a>
                           <p class="timer z">发布于：$thread[dateline]</p>
                           <p class="y">
                              <span class="post-viem"><i class="zhanzhuai-icons"></i>$thread[views]</span>
			                  <span class="post-reply"><i class="zhanzhuai-icons"></i>{$thread[replies]}</span>
                            </p>
                       </div>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
			
	<!--{else}-->
        <!--{if empty($grouplist)}--><div class="zhanzhuai_sc_nothread"><span></span><p>对不起，没有找到匹配结果</p></div><!--{/if}-->
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
<!--{/if}-->
</div>
</div>