<?php echo 'From: DISM·TAOBAO·COM';exit;?>	
<div class="zz_sousuo_c">
	<div class="zhanzhuai_sttl">
		<h2><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page" target="_blank">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	
<!--{ad/search/y mtw}-->

<div class="zhanzhuai_slst cl" {if $modfid} style="position: relative;"{/if}>

	<!--{if empty($threadlist)}-->
		<div class="zhanzhuai_sc_nothread"><span></span><p>对不起，没有找到匹配结果</p></div>
		</div>
	<!--{else}-->
		
			<!--{if $modfid}-->
			<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$modfid&infloat=yes&nopost=yes">
			<!--{/if}-->
			<ul>
		
			<!--{loop $threadlist $thread}-->
			<!--{eval $messages = DB::result(DB::query("SELECT message FROM ".DB::table('forum_post')." WHERE `tid`= '$thread[tid]' AND first = 1"));}-->
			<!--{eval $message = messagecutstr($messages,170);}-->
				<li class="pbw cl" id="$thread[tid]">
				    <div class="zz_sousuo_tit cl">
					    <h3><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank" $thread[highlight]>$thread[subject]</a></h3>
						<span class="y"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank" class="zz_forumname">#$thread[forumname]#</a></span>
					</div>
					<!--{eval $zz_sc_pic = substr($thread[tid], -1); $zz_threadpic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$zz_sc_pic.'')." WHERE `tid`= $thread[tid] AND isimage = '1' ORDER BY `dateline` DESC");}-->
                    <!--{eval $picn = count($zz_threadpic);}-->

                    <!--{if ($picn > 2)}-->
                        <!--{eval $picn2 = '3';}-->
                    <!--{elseif $picn < 3 && $picn}-->
                        <!--{eval $picn2 = '1';}-->
                    <!--{/if}-->

                    <!--{if $picn > 0}-->
	                    <!--{eval $sc_pic = substr($thread[tid], -1); $threadpic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$sc_pic.'')." WHERE `tid`= $thread[tid] AND isimage = '1' ORDER BY `dateline` DESC limit 0 , $picn2");}-->
                   <!--{/if}-->
                    
					<div class="zz_sousuo_nr" {if $picn < 3 && $picn}style="position: relative;height: 125px;"{/if}>
					   <!--{if $picn < 3 && $picn}-->
                           <div class="zz_sousuo_p1 cl"> 					      
                             <!--{loop $threadpic $zhanzhuaipic}-->
                             <!--{eval $piclist = getforumimg($zhanzhuaipic[aid], 0, 212, 125); }-->
                                   <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="img-wrap"><img src="$piclist"></a>
                             <!--{/loop}-->					
                           </div>
                       <!--{/if}-->
                       <div class="zz_sousuo_message" {if $picn < 3 && $picn}style=" float: left;width: 436px;"{/if}>$message</div>
	
                       <!--{if $picn > 2}-->
                           <div class="zz_sousuo_pn cl">  
						        <a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank">
                                    <!--{loop $threadpic $zhanzhuaipic}-->
                                    <!--{eval $piclist = getforumimg($zhanzhuaipic[aid], 0, 212, 125); }-->
                                        <img src="$piclist">
                                    <!--{/loop}-->
						        </a>
					       </div>
                       <!--{/if}-->

                       <div class="sc_footer cl" {if $picn < 3 && $picn}style="position: absolute;left: 224px;bottom: 5px;width: 436px;"{/if}> 
                           <a href="home.php?mod=space&uid=$thread[authorid]" class="username z" target="_blank">
                              <!--{avatar($thread[authorid],middle)}-->
                              <span>$thread[author]</span>
                           </a>
                           <p class="timer z">发布于：$thread[dateline]</p>
                           <p class="y">
                              <span class="post-viem"><i class="zhanzhuai-icons"></i>$thread[views]</span>
			                  <span class="post-reply"><i class="zhanzhuai-icons"></i>{$thread[replies]}</span>
                            </p>
                       </div>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		<!--{if $modfid}-->
			</form>
			<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
			<!--{template forum/topicadmin_modlayer}-->
		<!--{/if}-->


		<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
		</div>

<!--{/if}-->
</div>