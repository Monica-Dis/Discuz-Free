<?php echo 'From: DISM·TAOBAO·COM';exit;?>	
<div class="zz_sousuo_c">
	<div class="zhanzhuai_sttl">
		<h2><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->

	<!--{if empty($bloglist)}-->
		<div class="zhanzhuai_sc_nothread"><span></span><p>对不起，没有找到匹配结果</p></div>
	<!--{else}-->
		<div class="zhanzhuai_slst cl" {if $modfid} style="position: relative;"{/if}>
			<ul>
				<!--{loop $bloglist $blog}-->


				<li class="cl">
				    <div class="zz_sousuo_tit cl" style="margin-bottom: 0;">
					    <h3 style=" width: 665px;"><a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"{if $blog[magiccolor]} class="magiccolor$blog[magiccolor]"{/if} target="_blank">$blog[subject]</a></h3>
					</div>
                    
					<div class="zz_sousuo_nr" >
                       <div class="sc_footer cl"> 
                          <a href="home.php?mod=space&uid=$blog[uid]" class="username z" target="_blank">
                              <!--{avatar($blog[uid],middle)}-->
                              <span>$blog[username]</span>
                           </a>
                           <p class="timer z">发布于：$blog[dateline]</p>
                           <p class="y">
                              <span class="post-viem"><i class="zhanzhuai-icons"></i>$blog[viewnum]</span>
			                  <span class="post-reply"><i class="zhanzhuai-icons"></i>$blog[replynum]</span>
                            </p>
                       </div>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>