<?php echo 'From: DISM·TAOBAO·COM';exit;?>	
<div class="zz_sousuo_c">
	<div class="zhanzhuai_sttl">
		<h2><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->

	<!--{if empty($collectionlist)}-->
		<div class="zhanzhuai_sc_nothread"><span></span><p>对不起，没有找到匹配结果</p></div>
	<!--{else}-->
		<div class="zhanzhuai_slst cl" {if $modfid} style="position: relative;"{/if}>
		    <div class="zz_sousuo_g cl" style="background: #fff;">
			<!--{loop $collectionlist $key $value}-->
			<dl class="xld xld_a z zz_gnum$key">
				<dt style="font-size: 16px;
    color: #000042;"><a href="forum.php?mod=collection&action=view&ctid=$value[ctid]" target="_blank">$value[name]</a></dt>
				<dd style="color: #999;">{lang threads}: $value[threadnum], {lang comment}: $value[commentnum], {lang subscribe}: $value[follownum], {lang lastupdate}: $value[lastupdate]</dd>
				<dd>$value[desc]&nbsp;</dd>
			</dl>
			<!--{/loop}-->
		</div>
		</div>
		<!--{if !empty($multipage)}--><br /><div class="pgs cl mbm">$multipage</div><!--{/if}-->
	<!--{/if}-->

</div>