<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$fids = '0,9999,99999'; //不想显示内容到首页的版块，多个版块请用半角逗号分开
$perpage = 12; //每页显示数量

$page = empty($_GET['page'])?1:intval($_GET['page']);
$start = ($page-1)*$perpage;

$count = DB::result(DB::query("SELECT COUNT(*) FROM ".DB::table('forum_thread')." WHERE fid NOT in ($fids) AND displayorder > -1 AND special=0 AND isgroup = 0"));
$thread_list = array();
if ($count) {
     $threadlist = DB::query("SELECT * FROM ".DB::table('forum_thread')." WHERE fid not in ($fids) AND displayorder > -1 AND special=0 AND isgroup = 0 ORDER BY dateline DESC LIMIT $start,$perpage");
      while ($get = DB::fetch($threadlist)) {
		$thread_list[]=$get;
    }
}

$zhanzhuai_multi = multi($count, $perpage, $page, "search.php?mod=forum");

?>
