<?php echo 'From: DISM��TAOBAO��COM';exit;?>	
<div class="zz_sousuo_c">
	<div class="zhanzhuai_sttl">
		<h2><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->

<div class="zhanzhuai_slst cl" {if $modfid} style="position: relative;"{/if}>
	<!--{if empty($articlelist)}-->
		<div class="zhanzhuai_sc_nothread"><span></span><p>�Բ���û���ҵ�ƥ����</p></div>
		</div>
	<!--{else}-->
			<ul>
				<!--{loop $articlelist $article}-->
				<li class="pbw cl">
				    <div class="zz_sousuo_tit cl">
					    <h3><a href="{echo fetch_article_url($article);}" target="_blank">$article[title]</a></h3>
					</div>

					<!--{eval $zz_threadpic = DB::fetch_all("SELECT attachment FROM ".DB::table('portal_attachment')." WHERE `aid`= '$article[aid]' AND isimage = '1' ORDER BY `dateline` DESC");}-->

                    <!--{eval $picn = count($zz_threadpic);}-->
                    <!--{if ($picn > 2)}-->
                        <!--{eval $picn2 = '3';}-->
                    <!--{elseif $picn < 3 && $picn}-->
                        <!--{eval $picn2 = '1';}-->
                    <!--{/if}-->

                    <!--{if $picn > 0}-->
						<!--{eval $threadpic = DB::fetch_all("SELECT attachment FROM ".DB::table('portal_attachment')." WHERE `aid`= '$article[aid]' AND isimage = '1' ORDER BY `dateline` DESC limit 0 , $picn2");}-->
                   <!--{/if}-->
                    
					<div class="zz_sousuo_nr" {if $picn < 3 && $picn}style="position: relative;height: 125px;"{/if}>
					   <!--{if $picn < 3 && $picn}-->
                           <div class="zz_sousuo_p1 cl"> 					      
                             <!--{loop $threadpic $zhanzhuaipic}-->
                                   <a href="$article_url" class="img-wrap"><img src="data/attachment/portal/$zhanzhuaipic[attachment]" /></a>
                             <!--{/loop}-->					
                           </div>
                       <!--{/if}-->
                       <div class="zz_sousuo_message" {if $picn < 3 && $picn}style=" float: left;width: 436px; max-height: 69px;overflow: hidden;"{/if}>$article[summary]</div>

	
                       <!--{if $picn > 2}-->
                           <div class="zz_sousuo_pn cl">  
						         <a href="$article_url" target="_blank">
                                    <!--{loop $threadpic $zhanzhuaipic}-->
                                    <img src="data/attachment/portal/$zhanzhuaipic[attachment]" />
                                    <!--{/loop}-->
						        </a>
					       </div>
                       <!--{/if}-->

                       <div class="sc_footer cl" {if $picn < 3 && $picn}style="position: absolute;left: 224px;bottom: 5px;width: 436px;"{/if}> 
                           <a href="home.php?mod=space&uid=$article[uid]" class="username z" target="_blank">
                              <!--{avatar($article[uid],middle)}-->
                              <span>$article[username]</span>
                           </a>
                           <p class="timer z">�����ڣ�$article[dateline]</p>
                           <p class="y">
                              <span class="post-viem"><i class="zhanzhuai-icons"></i>$article[viewnum]</span>
			                  <span class="post-reply"><i class="zhanzhuai-icons"></i>$article[commentnum]</span>
                            </p>
                       </div>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>
