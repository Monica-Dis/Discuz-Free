<?php echo 'From: DISM��TAOBAO��COM';exit;?>	
<link type="text/css" rel="styleSheet"  href="template/zhanzhuai_zhihu/search/search_css/ss_style.css" />

<!--{eval $keywordenc = $keyword ? rawurlencode($keyword) : '';}-->
<!--{if $searchid || ($_GET['adv'] && CURMODULE == 'forum')}-->
	<div class="zz_sousuo_top box cl">
				<div id="scform_form" class="zz_sousuo_form cl">
					 <input type="text" id="scform_srchtxt" name="srchtxt" size="45" maxlength="40" value="$keyword" tabindex="1" x-webkit-speech speech />
					 <script type="text/javascript">initSearchmenu('scform_srchtxt');$('scform_srchtxt').focus();</script>
					 <input type="hidden" name="searchsubmit" value="yes" />
					 <!--{if CURMODULE == 'forum'}-->
						<span class="y" style="position: absolute;top: 25px;right: 147px;">
							<a href="javascript:;" id="quick_sch" class="showmenu" onmouseover="delayShow(this);">{lang quick}</a>
							<!--{if CURMODULE == 'forum'}-->
								<a href="search.php?mod=forum&adv=yes{if $keyword}&srchtxt=$keywordenc{/if}">{lang search_adv}</a>
							<!--{/if}-->
						</span>
					<!--{/if}-->
					 <button type="submit" id="scform_submit" class="schbtn">{lang search}</button>
                </div>

		 		<div class="zz_sousuo_tab cl">
					<!--{if $_G['setting']['portalstatus'] && $_G['setting']['search']['portal']['status'] && ($_G['group']['allowsearch'] & 1 || $_G['adminid'] == 1)}--><!--{block slist[portal]}--><a href="search.php?mod=portal{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'portal'} class="a"{/if}>{lang portal}</a><!--{/block}--><!--{/if}-->
					<!--{if $_G['setting']['search']['forum']['status'] && ($_G['group']['allowsearch'] & 2 || $_G['adminid'] == 1)}--><!--{block slist[forum]}--><a href="search.php?mod=forum{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'forum'} class="a"{/if}>{lang thread}</a><!--{/block}--><!--{/if}-->
					<!--{if helper_access::check_module('blog') && $_G['setting']['search']['blog']['status'] && ($_G['group']['allowsearch'] & 4 || $_G['adminid'] == 1)}--><!--{block slist[blog]}--><a href="search.php?mod=blog{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'blog'} class="a"{/if}>{lang blog}</a><!--{/block}--><!--{/if}-->
					<!--{if helper_access::check_module('album') && $_G['setting']['search']['album']['status'] && ($_G['group']['allowsearch'] & 8 || $_G['adminid'] == 1)}--><!--{block slist[album]}--><a href="search.php?mod=album{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'album'} class="a"{/if}>{lang album}</a><!--{/block}--><!--{/if}-->
					<!--{if $_G['setting']['groupstatus'] && $_G['setting']['search']['group']['status'] && ($_G['group']['allowsearch'] & 16 || $_G['adminid'] == 1)}--><!--{block slist[group]}--><a href="search.php?mod=group{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'group'} class="a"{/if}>$_G['setting']['navs'][3]['navname']</a><!--{/block}--><!--{/if}-->
					<!--{if helper_access::check_module('collection') && $_G['setting']['search']['collection']['status'] && ($_G['group']['allowsearch'] & 64 || $_G['adminid'] == 1)}--><!--{block slist[collection]}--><a href="search.php?mod=collection{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'collection'} class="a"{/if}>{lang collection}</a><!--{/block}--><!--{/if}-->
					<!--{block slist[user]}--><a href="search.php?mod=user{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'user'} class="a"{/if}>{lang users}</a><!--{/block}-->
					<!--{echo implode("", $slist);}-->
				</div>
	</div>
<!--{else}-->
	<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
	<!--{if $srchtype != 'threadsort'}-->
	<div class="zz_sousuo_top box cl">
				<div id="scform_form" class="zz_sousuo_form cl">
					 <input type="text" id="scform_srchtxt" name="srchtxt" size="45" maxlength="40" value="$keyword" tabindex="1" x-webkit-speech speech />
					 <script type="text/javascript">initSearchmenu('scform_srchtxt');$('scform_srchtxt').focus();</script>
					 <input type="hidden" name="searchsubmit" value="yes" />
					 <!--{if CURMODULE == 'forum'}-->
						<span class="y" style="position: absolute;top: 25px;right: 147px;">
							<a href="javascript:;" id="quick_sch" class="showmenu" onmouseover="delayShow(this);">{lang quick}</a>
							<!--{if CURMODULE == 'forum'}-->
								<a href="search.php?mod=forum&adv=yes{if $keyword}&srchtxt=$keywordenc{/if}">{lang search_adv}</a>
							<!--{/if}-->
						</span>
					<!--{/if}-->
					 <button type="submit" id="scform_submit" class="schbtn">{lang search}</button>
                </div>

		 		<div class="zz_sousuo_tab cl">
					<!--{if $_G['setting']['portalstatus'] && $_G['setting']['search']['portal']['status'] && ($_G['group']['allowsearch'] & 1 || $_G['adminid'] == 1)}--><!--{block slist[portal]}--><a href="search.php?mod=portal{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'portal'} class="a"{/if}>{lang portal}</a><!--{/block}--><!--{/if}-->
					<!--{if $_G['setting']['search']['forum']['status'] && ($_G['group']['allowsearch'] & 2 || $_G['adminid'] == 1)}--><!--{block slist[forum]}--><a href="search.php?mod=forum{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'forum'} class="a"{/if}>{lang thread}</a><!--{/block}--><!--{/if}-->
					<!--{if helper_access::check_module('blog') && $_G['setting']['search']['blog']['status'] && ($_G['group']['allowsearch'] & 4 || $_G['adminid'] == 1)}--><!--{block slist[blog]}--><a href="search.php?mod=blog{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'blog'} class="a"{/if}>{lang blog}</a><!--{/block}--><!--{/if}-->
					<!--{if helper_access::check_module('album') && $_G['setting']['search']['album']['status'] && ($_G['group']['allowsearch'] & 8 || $_G['adminid'] == 1)}--><!--{block slist[album]}--><a href="search.php?mod=album{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'album'} class="a"{/if}>{lang album}</a><!--{/block}--><!--{/if}-->
					<!--{if $_G['setting']['groupstatus'] && $_G['setting']['search']['group']['status'] && ($_G['group']['allowsearch'] & 16 || $_G['adminid'] == 1)}--><!--{block slist[group]}--><a href="search.php?mod=group{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'group'} class="a"{/if}>$_G['setting']['navs'][3]['navname']</a><!--{/block}--><!--{/if}-->
					<!--{if helper_access::check_module('collection') && $_G['setting']['search']['collection']['status'] && ($_G['group']['allowsearch'] & 64 || $_G['adminid'] == 1)}--><!--{block slist[collection]}--><a href="search.php?mod=collection{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'collection'} class="a"{/if}>{lang collection}</a><!--{/block}--><!--{/if}-->
					<!--{block slist[user]}--><a href="search.php?mod=user{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'user'} class="a"{/if}>{lang users}</a><!--{/block}-->
					<!--{echo implode("", $slist);}-->
				</div>
	</div>
	<!--{/if}-->




<!--{eval include TPLDIR.'/search/portal_data.php';}-->

<div class="zhanzhuai-postlist-box cl">
<ul>
<!--{loop $thread_list $post_list}-->
<!--{eval include TPLDIR.'/php/portal_list.php';}-->
<li id="normalthread_$post_list[tid]" class="zhanzhuai-post-list box thread-list">

	<div class="post-tit cl">
         <a href="forum.php?mod=viewthread&tid=$post_list[tid]" target="_blank">$post_list[subject]</a>
    </div>
 
    <div class="post-author cl">	
        <div class="post-author-basic">
            <a href="home.php?mod=space&uid=$post_list[authorid]" class="zz_author_pt" target="_blank">
				<img src="{echo avatar($post_list[authorid],'middle',1);}">
				<span class="author-name">$post_list[author]</span>
            </a>
        </div>		       
        <div class="pos-author-yhz"><!--{if $yhztu}--><img src="data/attachment/common/$yhztu"><!--{/if}--><font color="$yanse">$yhz</font></div>	
        <div class="icons y">
		     <!--{if $post_list[folder] == 'lock'}-->
				 <span>����</span>
			 <!--{elseif $post_list['special'] == 1}-->
				 <span>ͶƱ</span>
			 <!--{elseif $post_list['special'] == 2}-->
				 <span>{lang thread_trade}</span>
			 <!--{elseif $post_list['special'] == 3}-->
				 <span>����</span>
			 <!--{elseif $post_list['special'] == 4}-->
				 <span>�</span>
			 <!--{elseif $post_list['special'] == 5}-->
				 <span>����</span>
			 <!--{elseif in_array($post_list['displayorder'], array(1, 2, 3, 4))}-->
				 <span class="stick_$post_list[displayorder]">�ö�</span>
			 <!--{/if}-->
			 <!--{if $post_list['digest'] > 0 && $filter != 'digest'}-->
				 <span class="digest_$post_list[digest]" title="����$post_list[displayorder]">��</span>
             <!--{/if}-->
		     <!--{if $post_list['attachment'] == 2}-->
                 <span class="image_s" title="��ͼ">ͼƬ</span>
             <!--{elseif $post_list['attachment'] == 1}-->
                 <span class="image_s" title="�и���">����</span>
             <!--{/if}-->
			 <!--{if $post_list[heatlevel]}-->
                 <span class="hot">��</span>
             <!--{/if}-->


        </div>
    </div>

    <div class="post-content cl">
	     <!--{if $num >0}-->
         <div class="post-img">
              <a href="forum.php?mod=viewthread&tid=$post_list[tid]" target="_blank">
             	<!--{loop $threadpic $zhanzhuaibzz_pic}-->
			        <!--{eval $tupian = getforumimg($zhanzhuaibzz_pic[aid], 0, 160, 105); }-->   		          
			        <img src="$tupian" alt="$post_list[subject]" />
                <!--{/loop}-->
			  </a>
         </div>
		 <!--{/if}-->

         <div class="post-profile cl">
              <a href="forum.php?mod=viewthread&tid=$post_list[tid]" class="check-text" target="_blank">
			      <!--{echo messagecutstr(DB::result_first('SELECT `message` FROM '.DB::table('forum_post').' WHERE `tid` ='.$post_list[tid].' AND `first` =1'),200);}-->   
			  </a>
			  <a href="forum.php?mod=viewthread&tid=$post_list[tid]" class="check-all" target="_blank">�鿴ȫ��<i></i></a>
		 </div>
    </div>

    <div class="post-actions cl">
        <span class="post-recommend" title="0�˵���"><i class="zhanzhuai-icons"></i>$post_list[recommend_add]</span>
        <span class="post-viem"><i class="zhanzhuai-icons"></i>$post_list[views]</span>
        <span class="post-reply"><i class="zhanzhuai-icons"></i>$post_list[replies]</span>
        <span class="post-fav"><i class="zhanzhuai-icons"></i>$post_list[favtimes]</span>
		<span class="post-time"><i class="zhanzhuai-icons"></i><!--{echo dgmdate($post_list['dateline'], 'u', '9999', getglobal('setting/dateformat'))}--></span>
        <span class="post-from y">
		   <!--{loop $forum_name $forumname}-->
			 <a href="forum.php?mod=forumdisplay&fid=$forumname[fid]" target="_blank">$forumname[name]</a>
		   <!--{/loop}-->
        </span>
    </div>
</li>


<!--{/loop}-->
</ul>
</div>

<div class="zhanzhuai_fy cl">$zhanzhuai_multi</div>

<!--{/if}-->
<!--{if CURMODULE == 'forum'}-->
	<ul id="quick_sch_menu" class="p_pop" style="display: none;">
		<li><a href="search.php?mod=forum&srchfrom=3600&searchsubmit=yes">{lang search_quick_hour_1}</a></li>
		<li><a href="search.php?mod=forum&srchfrom=14400&searchsubmit=yes">{lang search_quick_hour_4}</a></li>
		<li><a href="search.php?mod=forum&srchfrom=28800&searchsubmit=yes">{lang search_quick_hour_8}</a></li>
		<li><a href="search.php?mod=forum&srchfrom=86400&searchsubmit=yes">{lang search_quick_hour_24}</a></li>
		<li><a href="search.php?mod=forum&srchfrom=604800&searchsubmit=yes">{lang search_quick_day_7}</a></li>
		<li><a href="search.php?mod=forum&srchfrom=2592000&searchsubmit=yes">{lang search_quick_day_30}</a></li>
		<li><a href="search.php?mod=forum&srchfrom=15552000&searchsubmit=yes">{lang search_quick_day_180}</a></li>
		<li><a href="search.php?mod=forum&srchfrom=31536000&searchsubmit=yes">{lang search_quick_day_365}</a></li>
	</ul>
<!--{/if}-->


