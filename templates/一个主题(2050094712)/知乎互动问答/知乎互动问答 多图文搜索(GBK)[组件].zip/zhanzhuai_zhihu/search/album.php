<?php echo 'From: DISM��TAOBAO��COM';exit;?>	
<!--{subtemplate common/header}-->
<div class="zhanzhuai_sc cl">
	<div class="zz_sousuo_l">
	<form class="searchform" method="post" autocomplete="off" action="search.php?mod=album" onsubmit="if($('scform_srchtxt')) searchFocus($('scform_srchtxt'));">
		<input type="hidden" name="formhash" value="{FORMHASH}" />

		<!--{subtemplate search/pubsearch}-->
		<!--{hook/album_top}-->

	</form>

	<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
		<!--{subtemplate search/album_list}-->
	<!--{/if}-->
</div>

<!--{subtemplate search/zz_sousuo_r}-->

<!--{hook/album_bottom}-->

</div>
<!--{subtemplate search/footer}-->
