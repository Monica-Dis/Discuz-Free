<?php echo 'From: DISM��TAOBAO��COM';exit;?>	
<div class="zz_sousuo_r cl">
		   <!--{if $guidethread_list > 0}-->
		   <div class="zhanzhuai-hot-img-list box" style="margin-bottom: 0">
				<div class="zhanzhuai_diytit cl"><h2>�����Ƽ�</h2></div>
				<ul class="cl">
				    <!--{loop $guidethread_list $key $guidepost_list}-->
					<!--{eval $listnum = $key + 1;}-->
                    <!--{eval $zhanzhuaibzz_pic = substr($guidepost_list[tid], -1); $guidethreadpic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$zhanzhuaibzz_pic.'')." WHERE `tid`= $guidepost_list[tid] AND isimage = '1' ORDER BY `dateline` DESC limit 0 , 1");}-->
                    <li class="zhanzhuai_$listnum">
                        <a href="forum.php?mod=viewthread&tid=$guidepost_list[tid]" target="_blank">
	                         <div class="guidenews-img"> 
	                              <!--{loop $guidethreadpic $zhanzhuaibzz_pic}-->
			                           <!--{eval $tupian = getforumimg($zhanzhuaibzz_pic[aid], 0, 60, 60); }-->   		          
			                           <img src="$tupian" alt="$guidepost_list[subject]" />
                                  <!--{/loop}-->
	                         </div>
	                         <div class="guidenews-content"><!--{echo cutstr($guidepost_list[subject], 40)}--></div>
                        </a>
                    </li>
                    <!--{/loop}-->
			   </ul>
          </div> 
		  <!--{/if}-->

		  <!--{if $hot_thread_list > 0}-->
		  <div class="zhanzhuai_hotnews zhanzhuai-rfixed box cl" style="margin-top: 20px;">
				<div class="zhanzhuai_diytit cl"><h2>���»ش�</h2></div>
				<ul class="zhanzhuai-r-list">
				    <!--{loop $hot_thread_list $hot_post_list}-->
                       <li>
                           <i></i>
                           <a href="forum.php?mod=viewthread&tid=$hot_post_list[tid]" target="_blank">
	                           <!--{echo cutstr($hot_post_list[subject], 40)}-->
	                       </a>
                           <p></p>
                       </li>
                    <!--{/loop}-->
			   </ul>
          </div> 
		  <!--{/if}-->
	 </div>

