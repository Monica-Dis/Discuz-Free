<?php
/**
 * 
 * DisM!出品 必属精品
 * DisM!应用中心所有 https://dism.Taobao.Com
 * 专业Discuz!应用插件、模板正版采购提供代下载服务、技术支持等全方位服务...
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$fids='2,36,37,38,39,40,41,42,43,44';//调用的版块，多个用半角逗号分开
$order= 'dateline';
$num=10;

$begin=($_G['page']-1)*$num;
$manylist=array();
require_once libfile('function/post');
$rs=DB::query("SELECT t.*,p.message,p.pid,f.name FROM ".DB::table("forum_thread")." t LEFT JOIN ".DB::table("forum_post")." p on p.tid=t.tid LEFT JOIN ".DB::table("forum_forum")." f on f.fid=t.fid WHERE t.`fid` in ($fids) and t.displayorder>=0 and p.first=1 and t.attachment>0 group by t.tid ORDER BY t.`$order` DESC LIMIT $begin , $num");

while ($rw=DB::fetch($rs)) {
$manylist[]=$rw;
$table='forum_attachment_'.substr($rw['tid'], -1);
$query = DB::fetch_first("SELECT aid,tid FROM ".DB::table($table)." WHERE tid='$rw[tid]' AND isimage!=0 ORDER BY `dateline` ASC");
$pic=(getforumimg($query[aid],0,190,130));
$rw['dateline']=date('Y-m-d', $rw['dateline']);
$html = <<< EOT
<div class="forumwrap"><a href="forum.php?mod=viewthread&tid={$rw['tid']}"><div class="forum-img"><img src="{$pic}" alt=""></div><div class="forum-title"><h3>{$rw['subject']}</h3></div><div class="forum-info">{$rw['author']}<span class="rounddot"></span>{$rw['dateline']}<span class="rounddot"></span>{$rw['replies']}回复</div></a></div>
EOT;
$contentss .= $html;
}

$num=count($manylist);

$allnum=DB::result_first("select count(*) from ".DB::table("forum_thread")." where fid in ($fids)");

$totalnum = $allnum;
if($num==0){
$remain = 0;
}else{
$remain = $totalnum-$num*$_G['page'];
}

if($num==0){
$content ='';
}else{
$content = <<< EOT
<div class="mbox hot_list" style="margin-top:1px;">$contentss</div>
EOT;
}

//$content = iconv("GBk","UTF-8//IGNORE",$content);
$array = array();
$array['num'] = $num;
$array['totalnum'] = $totalnum;
$array['remain'] = $remain;
$array['content'] = $content;
$array['scode'] = 1;


?>