<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{eval require_once("template/iscwo_touch/iscwo/php/forum_index.php");}-->
<!--{if $_GET['view'] == 'ajaxmobile'}-->
	<!--{eval echo json_encode($array) ;}-->
<!--{else}-->
<!--{template common/header}-->


<div class="mtop">
	<div class="head">
		<div class="top-forum"><a href="home.php?mod=space&do=notice" class="my-notice"></a></div>
		<div class="top-my"><a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="my-i"></a></div>
		<div class="logo"><h1><a href="index.php" >$_G['setting']['bbname']</a></h1></div>
	</div>
</div>

<div class="mwrap">
	<div class="mbox mb15">
		<div class="sliders imgslider_box" id="mySwipe">
			<div class="swipe-wrap">
				<div class="slider-img" data-log="#"><a target="_blank"><img src="template/iscwo_touch/iscwo/ad/1.jpg"></a></div>
				<div class="slider-img" data-log="#"><a target="_blank"><img src="template/iscwo_touch/iscwo/ad/2.jpg"></a></div>
				<div class="slider-img" data-log="#"><a target="_blank"><img src="template/iscwo_touch/iscwo/ad/3.jpg"></a></div>
			</div>
			<ul id="position"></ul>
		</div>

		<div class="index_navlist">
			<ul>
				<li><a href="forum.php?forumlist=1"><div class="iconimg"><i class="forum_icon"></i></div><p>版块</p></a></li>
				<li><a href="#"><div class="iconimg"><i class="sign_icon"></i></div><p>签到</p></a></li>
				<li><a href="#" target="_blank"><div class="iconimg"><i class="try_icon"></i></div><p>商城</p></a></li>
				<li><a href="search.php?mod=forum"><div class="iconimg"><i class="search_icon"></i></div><p>搜索</p></a></li>
			</ul>
		</div>
	</div>

	<div class="mbox">	
		<div class="hotforum-two">
			<ul>
				<li><a href="#" target="_blank"><p class="mes-b">联想ZUK Z2 Pro</p><p class="mes-s">4月21日见</p></a></li>
				<li><a href="#" target="_blank"><p class="mes-b">有奖话题</p><p class="mes-s">Z2海报上的10点代表啥？</p></a></li>
			</ul>
		</div>	
	</div>

	<div class="comtitle">新帖推荐</div>

	<div class="mbox hot_list">
		$contentss
	</div>

	<div class="loadbox mbox">
		<a href="javascript:loadajaxcontent()" class="loadmore">加载更多</a>
		<script>var loadding = false,loadnum = 0,loadoffset = 2;</script>
	</div>
</div>

<script src="template/iscwo_touch/iscwo/js/swipe.js" type="text/javascript"></script>

<script>

var $=jQuery;

$(document).ready(function(){
	swipemove();
	$('#mySwipe a').each(function(index){
		$(this).click(function(){ 
			$(this).parents('.swipe-wrap').find('a').removeAttr('href');
			$(this).attr('href',$(this).parent('div').attr('data-log'));
		});
	});
});	

function addmoveon(){
	var swipenum=$('#mySwipe').find('img').length;
	var pos=$('#position');
	var strli='<li><span></span></li>';
	var addstrli='';
	if(swipenum>0){
		for(i=0;i<swipenum;i++){
		addstrli+=strli;}
		if(pos.length>0){ 
			pos.empty().append(addstrli);
		}
	}
}

function swipemove(){
	addmoveon();
	var bullets = document.getElementById('position').getElementsByTagName('li');
	bullets[0].className='on';
	var elem = document.getElementById('mySwipe');
	window.mySwipe = Swipe(elem, {
		startSlide:0,
		auto:3500,                //设置自动切换时间，单位为毫秒
		continuous: true,          //无限循环图片的切换效果
		disableScroll: true,       //阻止由于触摸而滚动屏幕 
		stopPropagation: true,     // 停止事件传播       
		callback: function(pos) {
			var i = bullets.length;
			while (i--) {
			bullets[i].className = ' ';
			}
			if (bullets.length<=2){
				if(pos>=2) { bullets[pos-2].className='on';}else{ bullets[pos].className = 'on';}
			}else{
				bullets[pos].className = 'on';
			}
		}
	});
}

function loadajaxcontent(){
	loadding = true;	
	$(".loadbox a").html('正在加载中.');
	$.getJSON('forum.php?mod=guide&view=ajaxmobile&page='+loadoffset, function(response){
		clearTimeout(loaddingtimer);
		if(response.scode == '1'){		
			loadoffset = loadoffset+1;
			loadding = false;					
			$(".hot_list").last().after(response.content);
			if (response.remain<=0) {							
				$(".loadbox a").html('已经没有文章了');
			}else{						
				$(".loadbox a").html('加载更多文章...');
			}
		}
	});
}

var loaddingtimer;

function loaddingtext(){
	loaddingtimer = setTimeout(function(){
		$(".loadbox a").html($(".loadbox a").html()+'.');
		loaddingtext();
	},500);
}

</script>

<!--{template common/footer}-->
<!--{/if}-->