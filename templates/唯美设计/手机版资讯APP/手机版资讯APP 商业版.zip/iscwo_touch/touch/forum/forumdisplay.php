<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->

<!-- header start -->
<div class="top">
	<div class="head">
		<div class="top-forum"><a href="forum.php?forumlist=1" class="goback-i"></a></div>
		<div class="top-my"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}" class="post-i"></a></div>
		<div class="logo"><h1><a ><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></a></h1></div>
	</div>
	<!--{if $subexists}-->
		<div class="subnav_slider">
			<div class="swipe-wrap" id="subnav_slider">
				<ul class="subhead ">
					<li class="on"><a href="forum.php?mod=forumdisplay&fid={$_G['fid']}">全部<span></span></a></li>
					<!--{loop $sublist $sub}-->
						<li><a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}<span> </span></a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	<!--{/if}-->
	
</div>
<!-- header end -->

<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->
<!--{if !$subforumonly}-->
	<!--{if $_G['forum_threadcount']}-->
		<div class="notelist">
			<ul class=" mbox">
			<!--{if $_G['forum_threadcount']}-->
				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
                	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<li>
						<!--{hook/forumdisplay_thread_mobile $key}-->
						<div class="notelist-avatar"><!--{avatar($thread[authorid],middle)}--></div>
						<div class="notelist-r">
							<a href="forum.php?mod=viewthread&fid=$thread[fid]&tid=$thread[tid]&extra=$extra" $thread[highlight] class="notelist-title">
							   {$thread[subject]}

								<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
									<i class="zhiding-i"> </i> 
								<!--{elseif $thread['digest'] > 0}-->
									<i class="jing-i"> </i> 
								<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
									<i class="pic-i"> </i> 
								<!--{/if}-->
							</a>
							<p class="smallmes">$thread[author]<span class="rounddot"></span> {$thread[dateline]}<span class="rounddot"></span>{$thread[replies]}回复</p>
						</div>
					</li>
                <!--{/loop}-->
            <!--{/if}-->
           </ul>
		</div>
	<!--{else}-->
		<div class="nolist">{lang forum_nothreads}</div>
	<!--{/if}-->
	<div class="topborder">$multipage</div>
	
<!--{/if}-->
<!-- main threadlist end -->

<!--{hook/forumdisplay_bottom_mobile}-->
<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}-->
