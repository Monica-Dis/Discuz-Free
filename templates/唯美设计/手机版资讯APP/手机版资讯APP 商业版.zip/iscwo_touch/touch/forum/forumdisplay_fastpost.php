<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>

<div class="fastreplay">
	<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes&mobile=2">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $secqaacheck || $seccodecheck}--><style>.sec_code {padding: 0 0 6px 0;}.mwrap .sec_code {padding: 10px;}.slider-box {margin: 0 auto 60px;}.fastreplay .fastreplaybtn {background: #f2f2f2;}</style><!--{subtemplate common/seccheck}--><!--{/if}-->
		<div class="fastreplaybtn" id="fastpostsubmitline">
		<input type="button" value="回帖" name="replysubmit" id="fastpostsubmit">
		<!--{hook/viewthread_fastpost_button_mobile}-->
		</div>
		<textarea name="message" id="fastpostmessage" cols="30" placeholder="回复帖子..." value="{lang send_reply_fast_tip}"></textarea>
    </form>
</div>
<script type="text/javascript">
	(function() {
		var form = $('#fastpostform');
		<!--{if !$_G[uid] || $_G[uid] && !$allowpostreply}-->
		$('#fastpostmessage').on('focus', function() {
			<!--{if !$_G[uid]}-->
				popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
			<!--{else}-->
				popup.open('{lang nopostreply}', 'alert');
			<!--{/if}-->
			this.blur();
		});
		<!--{else}-->
		$('#fastpostmessage').on('focus', function() {
			var obj = $(this);
			if(obj.attr('color') == 'gray') {
				obj.attr('value', '');
				obj.removeClass('grey');
				obj.attr('color', 'black');
				$('#fastpostsubmitline').css('display', 'block');
			}
		})
		.on('blur', function() {
			var obj = $(this);
			if(obj.attr('value') == '') {
				obj.addClass('grey');
				obj.attr('value', '{lang send_reply_fast_tip}');
				obj.attr('color', 'gray');
			}
		});
		<!--{/if}-->
		$('#fastpostsubmit').on('click', function() {
			$('input#fastpostsubmit').attr('disabled','disabled');
			var msgobj = $('#fastpostmessage');
			var zw=/[\ud83d]|[\ud83c]|[\u274c]|[\u3635]/g;//表情字符unicode
			var bb=msgobj.val();
			/*
	        if(zw.test(bb)){
	        	bb=bb.replace(zw,'1'); 
	        	msgobj.attr('value', bb);
	        	alert(bb + '<br1/>'+zw.test(bb)+ '<br1/>'+bb.match(zw));
	        }else{
	        	alert(bb + '<br2/>'+zw.test(bb)+ '<br2/>'+bb.match(zw));
	        }*/
       		if(msgobj.val() == '{lang send_reply_fast_tip}') {
				msgobj.attr('value', '');
			}
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey=fastpost&loc=1&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				evalscript(s.lastChild.firstChild.nodeValue);
				$('input#fastpostsubmit').removeAttr('disabled');
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
				$('input#fastpostsubmit').removeAttr('disabled');
			});
			return false;
		});

		$('#replyid').on('click', function() {
			$(document).scrollTop($(document).height());
			$('#fastpostmessage')[0].focus();
		});

	})();

	function succeedhandle_fastpost(locationhref, message, param) {
		var pid = param['pid'];
		var tid = param['tid'];
		if(pid) {
			$.ajax({
				type:'POST',
				url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid + '&mobile=2',
				dataType:'xml'
			})
			.success(function(s) {
				$('#post_new').append(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = 'forum.php?mod=viewthread&tid=' + tid;
				popup.close();
			});
		} else {
			if(!message) {
				message = '{lang postreplyneedmod}';
			}
			popup.open(message, 'alert');
		}
		$('#fastpostmessage').attr('value', '');
		if(param['sechash']) {
			$('.seccodeimg').click();
		}
	}

	function errorhandle_fastpost(message, param) {
		popup.open(message, 'alert');
	}
</script>
