<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{eval $_G[forum_thread][special] = 0;}-->
<!-- main postlist start -->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
   <div class="viewfloor">
       <div class="view-avatar">
            <a href="home.php?mod=space&uid=$post[authorid]"><!--{avatar($post[authorid],middle)}--></a>
        </div>
       <div class="viewfloor-r">
            <div class="authorname">
                <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                    <a href="home.php?mod=space&uid=$post[authorid]" class="">$post[author]</a>
                <!--{else}-->
                    <!--{if !$post['authorid']}-->
                    <a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
                    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                    <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
                    <!--{else}-->
                    $post[author] <em>{lang member_deleted}</em>
                    <!--{/if}-->
                <!--{/if}-->
                <!--{if $_G['forum_thread']['authorid'] == $post['authorid']}-->
                    <span class="floorhost">
                        <!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}--><a href="forum.php?mod=viewthread&fid=$_G[fid]&tid=$post[tid]&page=$page&authorid=$post[authorid]" rel="nofollow"  class="floorman" title="点击即可“只看楼主”哟~">楼主</a><!--{elseif !$_G['forum_thread']['archiveid']}--><a href="forum.php?mod=viewthread&fid=$_G[fid]&tid=$post[tid]&page=$page" rel="nofollow" class="floorman" title="显示全部帖子">楼主</a><!--{/if}-->
                    </span>
                <!--{/if}-->
            </div>
            <div class="viewinfo">
                <!--{if $post['warned']}-->
                    <span class="grey quote">{lang warn_get}</span>
                <!--{/if}-->
                <!--{if !$post['first'] && !empty($post[subject])}-->
                    <h2><strong>$post[subject]</strong></h2>
                <!--{/if}-->
                <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                    <div class="quote">{lang message_banned}</div>
                <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                    <div class="quote">{lang message_single_banned}</div>
                <!--{elseif $needhiddenreply}-->
                    <div class="quote">{lang message_ishidden_hiddenreplies}</div>
                <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
                    <!--{template forum/viewthread_pay}-->
                <!--{else}-->

                    <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                        <div class="quote">{lang admin_message_banned}</div>
                    <!--{elseif $post['status'] & 1}-->
                        <div class="quote">{lang admin_message_single_banned}</div>
                    <!--{/if}-->
                    <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                        {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
                    <!--{/if}-->
                    $post[message]

                <!--{/if}-->
            </div>
            <p class="smallmes">
                <!--{if isset($post[isstick])}-->
                    <small class="icon_settop"></small> {lang from} {$post[number]}{$postnostick}
                <!--{elseif $post[number] == -1}-->
                    {lang recommend_post}
                <!--{else}-->
                    <!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}-->
                <!--{/if}--><span class="rounddot"></span>$post[dateline]
            </p>
            <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" class="viewbutton view-replaybtn">回帖</a>
        </div>
   </div>
<!-- main postlist end -->
