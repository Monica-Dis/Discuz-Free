<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->
<!-- header start -->
<div class="top">
	<div class="head">
		<div class="top-forum"><a href="<!--{if $_GET[fromguid] == 'hot'}-->forum.php?mod=guide&view=hot&page=$_GET[page]<!--{else}-->forum.php?mod=forumdisplay&fid=$_G[fid]<!--{if $_GET[extra]}-->&<!--{eval echo rawurldecode($_GET[extra]);}--><!--{/if}--><!--{/if}-->" class="goback-i"></a></div>
		<div class="top-my"><a href="javascript:;"  id="replyid" class="replay-i"></a></div>
		<div class="logo"><h1><a ><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></a></h1></div>
	</div>
</div>
<!-- header end -->

<!--{hook/viewthread_top_mobile}-->
<!-- main postlist start -->
<div class="mwrap slider-box">
	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
	<!--{hook/viewthread_posttop_mobile $postcount}-->

	<!--{if $post['first']}-->
		<!--{if ($post['first']&& $page<2) || (!$post['first'])}-->	
		<div class="viewfloor firstfloor" id="pid$post[pid]">
			<div class="viewhead">
				<h3>
					<!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
						[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
		            <!--{/if}-->
		            <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
		                [{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]
					<!--{/if}-->
					$_G[forum_thread][subject]
		            <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
		            <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
		            <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
		            <!--{/if}-->
				</h3>
				<p class="smallmes">
					<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
						<a href="home.php?mod=space&uid=$post[authorid]" class="authorname">$post[author]</a>
					<!--{else}-->
						<!--{if !$post['authorid']}-->
						<a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
						<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
						<!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
						<!--{else}-->
						$post[author] <em>{lang member_deleted}</em>
						<!--{/if}-->
					<!--{/if}--><span class="rounddot"></span>$post[dateline]</p>
			</div>
			<div class="viewinfo">
				<!--{if $post['warned']}-->
                    <span class="grey quote">{lang warn_get}</span>
                <!--{/if}-->
                
                <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                    <div class="grey quote">{lang message_banned}</div>
                <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                    <div class="grey quote">{lang message_single_banned}</div>
                <!--{elseif $needhiddenreply}-->
                    <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
                <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
					<!--{template forum/viewthread_pay}-->
				<!--{else}-->

                	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                        <div class="grey quote">{lang admin_message_banned}</div>
                    <!--{elseif $post['status'] & 1}-->
                        <div class="grey quote">{lang admin_message_single_banned}</div>
                    <!--{/if}-->
                    <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                        {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
                    <!--{/if}-->

                    <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                    	<!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                            <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                {lang has_expired}
                            <!--{else}-->
                                <div class="box_ex2 viewsort">
                                    <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                                <!--{loop $threadsortshow['optionlist'] $option}-->
                                    <!--{if $option['type'] != 'info'}-->
                                        $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                                    <!--{/if}-->
                                <!--{/loop}-->
                                </div>
                            <!--{/if}-->
                        <!--{/if}-->
                    <!--{/if}-->
                    
                    <!--{if !$_G[forum_thread][special]}-->
                        $post[message]
                    <!--{elseif $_G[forum_thread][special] == 1}-->
                        <!--{template forum/viewthread_poll}-->
                    <!--{elseif $_G[forum_thread][special] == 2}-->
                        <!--{template forum/viewthread_trade}-->
                    <!--{elseif $_G[forum_thread][special] == 3}-->
                        <!--{template forum/viewthread_reward}-->
                    <!--{elseif $_G[forum_thread][special] == 4}-->
                        <!--{template forum/viewthread_activity}-->
                    <!--{elseif $_G[forum_thread][special] == 5}-->
                        <!--{template forum/viewthread_debate}-->
                    <!--{elseif $threadplughtml}-->
                        $threadplughtml
                        $post[message]
                    <!--{else}-->
                    	$post[message]
                    <!--{/if}-->
                   
				<!--{/if}-->
				<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
				<!--{if $post['attachment']}-->
	               <div class="grey quote">
	               {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
	               </div>
	            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
	               <!--{if $post['imagelist']}-->
					<!--{if count($post['imagelist']) == 1}-->
					<ul class="img_one">{echo showattach($post, 1)}</ul>
					<!--{else}-->
					<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
					<!--{/if}-->
					<!--{/if}-->
	                <!--{if $post['attachlist']}-->
					<ul>{echo showattach($post)}</ul>
					<!--{/if}-->
				<!--{/if}-->
				<!--{/if}-->
			</div>
			<div class="view-btngroup"><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn collect-pan"><em class="collect-i"></em></a></div>
			<!--收藏后的em的类collect-n-i-->
			<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" class="viewbutton view-replaybtn">回帖</a>
		</div>
		<!--{if $thread[replies]}-->
			<div class="betweenline">
				<div><span>{$thread[replies]}条回帖</span></div>
			</div>
		<!--{/if}-->
		<!--{else}-->
		<!--{/if}-->


	<!--{else}-->
	   <div class="viewfloor" id="pid$post[pid]">
		   <div class="view-avatar">
		   		<a href="home.php?mod=space&uid=$post[authorid]"><!--{avatar($post[authorid],middle)}--></a>
			</div>
			<div class="viewfloor-r">
				<div class="authorname">
					<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
						<a href="home.php?mod=space&uid=$post[authorid]" class="">$post[author]</a>
					<!--{else}-->
						<!--{if !$post['authorid']}-->
						<a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
						<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
						<!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
						<!--{else}-->
						$post[author] <em>{lang member_deleted}</em>
						<!--{/if}-->
					<!--{/if}-->
					<!--{if $_G['forum_thread']['authorid'] == $post['authorid']}-->
						<span class="floorhost">
							<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}--><a href="forum.php?mod=viewthread&fid=$_G[fid]&tid=$post[tid]&page=$page&authorid=$post[authorid]" rel="nofollow"  class="floorman" title="点击即可“只看楼主”哟~">楼主</a><!--{elseif !$_G['forum_thread']['archiveid']}--><a href="forum.php?mod=viewthread&fid=$_G[fid]&tid=$post[tid]&page=$page" rel="nofollow" class="floorman" title="显示全部帖子">楼主</a><!--{/if}-->
						</span>
					<!--{/if}-->
				</div>
				<div class="viewinfo">
					<!--{if $post['warned']}-->
                        <span class="grey quote">{lang warn_get}</span>
                    <!--{/if}-->
                    <!--{if !$post['first'] && !empty($post[subject])}-->
                        <h2><strong>$post[subject]</strong></h2>
                    <!--{/if}-->
                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                        <div class="quote">{lang message_banned}</div>
                    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                        <div class="quote">{lang message_single_banned}</div>
                    <!--{elseif $needhiddenreply}-->
                        <div class="quote">{lang message_ishidden_hiddenreplies}</div>
                    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
						<!--{template forum/viewthread_pay}-->
					<!--{else}-->

                    	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                            <div class="quote">{lang admin_message_banned}</div>
                        <!--{elseif $post['status'] & 1}-->
                            <div class="quote">{lang admin_message_single_banned}</div>
                        <!--{/if}-->
                        <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                            {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
                        <!--{/if}-->
                        $post[message]

					<!--{/if}-->
				</div>
				<p class="smallmes">
					<!--{if isset($post[isstick])}-->
						<small class="icon_settop"></small> {lang from} {$post[number]}{$postnostick}
					<!--{elseif $post[number] == -1}-->
						{lang recommend_post}
					<!--{else}-->
						<!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}-->
					<!--{/if}--><span class="rounddot"></span>$post[dateline]
					<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" class="viewbutton view-replaybtn">回帖</a>
				</p>
			</div>
	   </div>

   <!--{/if}-->
	   <!--{hook/viewthread_postbottom_mobile $postcount}-->
	   <!--{eval $postcount++;}-->
	   <!--{/loop}-->
	   <div id="post_new"></div>
</div>
<!--{subtemplate forum/forumdisplay_fastpost}-->
<!-- main postlist end -->
<div class="topborder">$multipage</div>
<div class="smallh"></div>
<!--{hook/viewthread_bottom_mobile}-->
<script type="text/javascript">
	var $=jQuery;
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
	function delclose(){
		$('.js_del a').bind('click',function(){
	      $(this).parents('.dialogbox').empty();
	    });
	}
	var objvedio=$(".js_wapplayer")[0];

</script>

<a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a>
<div id="mask" style="display:none;"></div>
</body>
</html>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
