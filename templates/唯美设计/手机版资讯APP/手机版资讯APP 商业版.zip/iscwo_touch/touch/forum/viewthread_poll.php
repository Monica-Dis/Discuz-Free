<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>

<div class="bt pd2">
<form id="poll" name="poll" method="post" autocomplete="off" action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes&mobile=2" >
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="pollhead">
		<!--{if $multiple}--><strong class="redcolor">{lang poll_multiple}{lang thread_poll}</strong><!--{if $maxchoices}-->: ( {lang poll_more_than} )<!--{/if}--><!--{else}--><strong>{lang poll_single}{lang thread_poll}</strong><!--{/if}--><!--{if $visiblepoll && $_G['group']['allowvote']}--> , {lang poll_after_result}<!--{/if}-->, {lang poll_voterscount}
	</div>

	<div>
        <table width="100%" class="polltblist">
            <thead>
                <tr>
                    <th colspan="3">
                        <!--{if $_G[forum_thread][remaintime]}-->
                        <p>
                            {lang poll_count_down}:
                            <span class="xg1">
                            <!--{if $_G[forum_thread][remaintime][0]}-->$_G[forum_thread][remaintime][0] {lang days}<!--{/if}-->
                            <!--{if $_G[forum_thread][remaintime][1]}-->$_G[forum_thread][remaintime][1] {lang poll_hour}<!--{/if}-->
                            $_G[forum_thread][remaintime][2] {lang poll_minute}
                            </span>
                        </p>
                        <!--{elseif $expiration && $expirations < TIMESTAMP}-->
                        <p><strong>{lang poll_end}</strong></p>
                        <!--{/if}-->
                    </th>
                </tr>
            </thead>
            <!--{loop $polloptions $key $option}-->
                <tr><td width="5%">
                <!--{if $_G['group']['allowvote']}-->
                    <input type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if}  />
                <!--{/if}--></td>
                <td width="70%">
                    <label for="option_$key">$key.$option[polloption]</label></td>
                <td width="25%">
                <!--{if !$visiblepoll}-->
                    $option[percent]% <em style="color:#$option[color]">($option[votes])</em>
                <!--{/if}--></td>
                </tr>
            <!--{/loop}-->
            <tr>
                <td colspan="3" class="tc">
                    <!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
                        <input type="submit" name="pollsubmit " class="redbtn" id="pollsubmit" value="{lang submit}" />
                        <!--{if $overt}-->
                            <span class="xg2">({lang poll_msg_overt})</span>
                        <!--{/if}-->
                    <!--{elseif !$allwvoteusergroup}-->
                        <!--{if !$_G['uid']}-->
                        <span class="xi1">{lang poll_msg_allwvote_user}</span>
                        <!--{else}-->
                        <span class="xi1">{lang poll_msg_allwvoteusergroup}</span>
                        <!--{/if}-->
                    <!--{elseif !$allowvotepolled}-->
                        <span class="xi1">{lang poll_msg_allowvotepolled}</span>
                    <!--{elseif !$allowvotethread}-->
                        <span class="xi1">{lang poll_msg_allowvotethread}</span>
                    <!--{/if}-->
                </td>
            </tr>
        </table>
	</div>
</form>
</div>
