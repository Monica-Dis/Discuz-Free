<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:forum.php?mod=guide&view=hot');exit;}-->
<!--{/if}-->
<!--{template common/header}-->

<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<!--{if $_GET['visitclient']}-->

<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->

<!-- header start -->
<!--{if $showvisitclient}-->

<div class="visitclienttip vm" style="display:block;">
	<a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>	
	<p>
		{lang downloadzslttoshareview}
	</p>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
		$('.visitclienttip').css('display', 'block');
	}
</script>

<!--{/if}-->

<div class="top">
	<div class="head">
		<div class="top-forum"><a href="./" class="goback-i"></a></div>
		<div class="logo"><h1><a title="$_G[setting][bbname]" href="forum.php?forumlist=1">论坛</a></h1></div>
	</div>
</div>
<!-- header end -->
<style>.mwrap {margin-top: 10px;} .plate-special{margin-top: -10px;}</style>
<!--{hook/index_top_mobile}-->
<!-- main forumlist start -->
<div class="mwrap" id="wp">
	<!--{eval $i=0;}-->
	<!--{loop $catlist $key $cat}-->

	<!--{if $cat[forumcolumns]==3}-->
	<div class="plate-special mbox">
		<!--{loop $cat[forums] $forumid}-->
		<!--{eval $forum=$forumlist[$forumid]; }--><!--{eval $i++;}-->
		<!--{eval $str=$forum[icon]; preg_match('/<img.+src=\"?(.+\.(jpg|gif|bmp|bnp|png))\"?.+>/i',$str,$icon);var_dump(); }-->
		<div class="border-r">
			<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
				<!--{if $forum[icon]}-->
				<div class="plate-img" style="background:url($icon[1])  no-repeat 50% center; background-size: 35%;"></div>
				<!--{else}-->
				<div class="plate-img" style="background:url(template/iscwo_touch/iscwo/images/forum.gif)  no-repeat 50% center; background-size: 35%;"></div>
				<!--{/if}-->
				<p>{$forum[name]}</p>
				<!--{if $forum[todayposts] > 0}--><span>$forum[todayposts]</span><!--{else}--><span>0</span><!--{/if}-->
			</a>
		</div>
		<!--{/loop}-->
	</div>
	<!--{/if}-->
	<!--{/loop}-->

	<!--{eval $i=0;}-->
	<!--{loop $catlist $key $cat}-->
		<!--{if $cat[forumcolumns]==3}-->
		<!--{else}-->
			<div class="comtitle">$cat[name]</div>
			<div class="platelist mbox">
				<ul>
					<!--{loop $cat[forums] $forumid}-->
						<!--{eval $forum=$forumlist[$forumid];}--><!--{eval $i++;}-->
						<li><a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><!--{if $forum[todayposts] > 0}--><span>$forum[todayposts]</span><!--{/if}-->{$forum[name]}</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		<!--{/if}-->
	<!--{/loop}-->
	
	
</div>
<!-- main forumlist end -->
<!--{hook/index_middle_mobile}-->
<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			$('.sub_forum').css('display', 'block');
		<!--{else}-->
			$('.sub_forum').css('display', 'none');
		<!--{/if}-->
		$('.subforumshow').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
				obj.find('img').attr('src', '{STATICURL}image/mobile/images/collapsed_yes.png');
			} else {
				subobj.css('display', 'none');
				obj.find('img').attr('src', '{STATICURL}image/mobile/images/collapsed_no.png');
			}
		});
	 })();
</script>

<!--{/if}-->
<!--{template common/footer}-->
