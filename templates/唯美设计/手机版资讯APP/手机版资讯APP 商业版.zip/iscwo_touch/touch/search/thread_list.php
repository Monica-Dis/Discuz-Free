<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<div class="notelist noavatarlist">
	<h2 class="thread_tit" ><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page" target="_blank">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	<!--{if empty($threadlist)}-->
	 <div class="jump_c nolist mbox"><p>{lang search_nomatch}</p></div>
	<!--{else}-->
			<ul class="slider-box">
				<!--{loop $threadlist $thread}-->
				<li>
					<div class="notelist-r">
						<a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" class="notelist-title" $thread[highlight]>$thread[subject]</a>
						<p class="smallmes">$thread['lastpost']<span class="rounddot"></span>$thread[author]<span class="rounddot"></span>$thread['forumname']</p>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
	<!--{/if}-->
	$multipage
</div>
