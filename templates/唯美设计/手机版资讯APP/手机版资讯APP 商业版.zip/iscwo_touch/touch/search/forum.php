<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->
<!-- header start -->
<div class="top">
	<div class="head">
		<div class="top-forum"><a href="index.php" class="goback-i"></a></div>
		<div class="logo "><h1><a href="">搜索</a></h1></div>
	</div>
</div>

<div class="wrap">
	<form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
		<input type="hidden" name="formhash" value="{FORMHASH}" />

		<!--{subtemplate search/pubsearch}-->

		<!--{eval $policymsgs = $p = '';}-->
		<!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
		<!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
		<!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
		<!--{/loop}-->
		<!--{if $policymsgs}--><p>{lang search_credit_msg}</p><!--{/if}-->
	</form>
</div>
<!-- header end -->


<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
	<!--{subtemplate search/thread_list}-->
<!--{/if}-->
<!--{template common/footer}-->
