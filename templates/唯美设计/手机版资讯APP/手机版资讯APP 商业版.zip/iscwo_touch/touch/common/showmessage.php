<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{if $param['login']}-->
	<!--{if $_G['inajax']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login&referer='.urlencode($_G['requesturl']).'&inajax=1&infloat=1');exit;}-->
	<!--{else}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login&referer='.urlencode($_G['requesturl']));exit;}-->
	<!--{/if}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if $_G['inajax']}-->
<div class="tip" style="">
	<div id="messagetext" class="dialogmsg">
		<p>$show_message </p>
        <!--{if $_G['forcemobilemessage']}-->
        	<p class="">
            	<a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
                <a href="javascript:history.back();">{lang goback}</a><!---->
            </p>
        <!--{/if}-->
		<!--{if $url_forward && !$_GET['loc']}-->
			<p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p><!---->
			<script type="text/javascript">
				setTimeout(function() {
					window.location.href = '$url_forward';
				}, '3000');
			</script>
		<!--{elseif $allowreturn}-->
			<p class="tipbtn-group"><input type="button" class="button2" onclick="popup.close();" value="{lang close}"></p>
		<!--{/if}-->
	</div>
</div>
<!--{else}-->

<!-- header start -->
<div class="top">
	<div class="head">
		<div class="top-forum"><a href="forum.php" class="forum-i"></a></div>
		<div class="top-my"><a href="home.php?mod=space&uid={$_G['uid']}&do=profile&mycenter=1" class="my-i"></a></div>
		<div class="logo"><h1><a href="index.php" >ZUK社区</a></h1></div>
	</div>
</div>
<!-- header end -->
<!-- main jump start -->
<div class="mwrap">
<div class="jump_c nolist mbox">
	<p>$show_message</p>
    <!--{if $_G['forcemobilemessage']}-->
		<p>
            <a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
            <a href="javascript:history.back();">{lang goback}</a>
        </p>
   <!--{else}-->
	    <!--{if $url_forward}-->
			<p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>
		<!--{elseif $allowreturn}-->
			<p><a class="grey" href="javascript:history.back();">{lang message_go_back}</a></p>
		<!--{/if}--> 
    <!--{/if}-->
	
</div></div>
<!-- main jump end -->

<!--{/if}-->
</body>
</html>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
