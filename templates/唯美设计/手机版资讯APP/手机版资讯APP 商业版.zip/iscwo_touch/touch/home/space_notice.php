<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->
<body>
	<div class="top">
		<div class="head">
			<div class="top-forum"><a href="javascript:history.back();" class="goback-i"></a></div>
			<div class="logo "><h1><a >消息提醒</a></h1></div>
		</div>
	</div>
	<div class="notelist">
		<ul class="mbox">
			<!--{loop $list $key $invite}-->
				
				<li {if $invite[new]} class="graybg"{/if}>
					<a href="home.php?mod=space&uid=$invite[authorid]" class="notelist-avatar"><!--{avatar($invite[authorid],middle)}--></a>
					<div class="notelist-r">
						$invite[note]
						<p class="smallmes">{date($invite[dateline], 'Y-m-d H:i')}</p>
					</div>
					
				</li>
			<!--{/loop}-->			
		</ul>
	<!--{if $multi}-->
		$multi
	<!--{/if}-->	
	</div>
	
<!--{template common/footer}-->