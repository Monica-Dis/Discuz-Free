<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->
<!-- header start -->
<div class="top">
	<div class="head">
		<div class="top-forum"><a href="javascript:history.back();" class="goback-i"></a></div>
		<div class="logo"><h1><a><!--{if $space['uid'] == $_G['uid']}-->
			我<!--{else}-->
			他<!--{/if}-->的收藏</a></h1></div>
	</div>
</div>

<!-- main collectlist start -->
<!--{if $_GET['type'] == 'forum'}-->
<div class="coll_list b_radius">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li><a href="$value[url]">$value[title]</a></li>
			<!--{/loop}-->
		<!--{else}-->
		<li>{lang no_favorite_yet}</li>
		<!--{/if}-->

	</ul>
</div>
<!--{else}-->
<div class="notelist noavatarlist">
	<!--{if $list}-->
	<ul class="slider-box">
		<!--{loop $list $k $value}-->
		<li>
			<div class="notelist-r">
				<a href="$value[url]" class="notelist-title">$value[title]
					<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
						<i class="zhiding-i"> </i> 
					<!--{elseif $thread['digest'] > 0}-->
						<i class="jing-i"> </i> 
					<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
						<i class="pic-i"> </i> 
					<!--{/if}-->
				</a>
				<p class="smallmes">收藏于{echo date('Y-m-d H:i',$value[dateline])}</p>
			</div>
		</li>
		<!--{/loop}-->
	</ul>
	$multipage
	<!--{else}-->
		<div class="nolist">{lang no_favorite_yet}</div>
	<!--{/if}-->
</div>
<!--{/if}-->
<!-- main collectlist end -->

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
