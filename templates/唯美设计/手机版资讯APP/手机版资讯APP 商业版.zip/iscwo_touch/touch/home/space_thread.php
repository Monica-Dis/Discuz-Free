<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->

<!-- header start -->
<div class="top">
	<div class="head">
		<div class="top-forum"><a href="javascript:history.back();" class="goback-i"></a></div><!--home.php?mod=space&uid={$space['uid']}-->
		<div class="logo"><h1><a><!--{if $space['uid'] == $_G['uid']}-->
			我<!--{else}-->
			他<!--{/if}-->的主题</a></h1></div>
	</div>
</div>
<!-- header end -->
<!-- main threadlist start -->
<!--{if $list}-->
<div class="notelist noavatarlist">
	<ul class="slider-box">
		<!--{loop $list $thread}-->
		<li>
			<div class="notelist-r">
				<!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
				<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]" >$thread[subject]</a>
				<!--{else}-->
				<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="notelist-title {if $thread['displayorder'] == -1}recy{/if}" >$thread[subject]
					<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
						<i class="zhiding-i"> </i> 
					<!--{elseif $thread['digest'] > 0}-->
						<i class="jing-i"> </i> 
					<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
						<i class="pic-i"> </i> 
					<!--{/if}-->
				</a>
				<!--{/if}-->
				<p class="smallmes">$thread['forumname']<span class="rounddot"></span>$thread['lastpost']</p>
			</div>
		</li>
		<!--{/loop}-->
	</ul>
	$multipage
</div>
<!--{else}-->
	<div class="nolist">{lang no_related_posts}</div>
<!--{/if}-->

<!-- main threadlist end -->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
