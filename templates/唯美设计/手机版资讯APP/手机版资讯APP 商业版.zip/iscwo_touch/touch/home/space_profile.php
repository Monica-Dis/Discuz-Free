<?php echo '唯美设计QQ:474902417商业模板保护！请到官网上购买正版模板 http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->



<!-- header start -->
<div class="top">
	<div class="head">
		<!--{if $_G['setting']['domain']['app']['mobile']}-->
			{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
		<!--{else}-->
			{eval $nav = "forum.php";}
		<!--{/if}-->
		<div class="top-forum"><a href="javascript:history.back();" class="goback-i"></a></div>
		<div class="logo"><h1><a title="$_G[setting][bbname]" href="forum.php?forumlist=1"><!--{if $_G['uid'] == $space['uid']}-->{lang myprofile}<!--{else}-->$space[username]{lang otherprofile}<!--{/if}--></a></h1></div>
	</div>
</div>

<!-- header end -->

	<!-- userinfo start -->
	<div class="mwrap">
		<div class="plate-my mbox">
			<div class="avatar"><a href="home.php?mod=space&uid={$space['uid']}"><!--{avatar($space[uid],middle)}--></a></div>
			<div class="userinfo-r">
				<p class="name"><a href="home.php?mod=space&uid={$space['uid']}">
				<!--{if !$_GET['mycenter']}-->
				$space[username]
				<!--{else}-->
				$_G[username]
				<!--{/if}--> <span class="userinfo-s">$space[group][grouptitle]</span>
				</a></p>
				<div class="smallmes">经验：$space[credits] <span class="rounddot"></span>金币：$space[extcredits5]</div>
			</div>
		</div>
		<div class="platelist mbox">
			<ul>
				<li><a href="home.php?mod=space&uid={$space[uid]}&do=thread"><em class="mylist-i"></em><span>$space[threads]</span><!--{if $space['uid'] == $_G['uid']}-->
				我<!--{else}-->
				他<!--{/if}-->的主题</a></li>
				<!--{if $space['uid'] == $_G['uid']}--><li><a href="home.php?mod=space&uid={$space[uid]}&do=favorite&type=thread"><em class="myfav-i"></em><span><!--{echo C::t('home_favorite')->count_by_uid_idtype($space[uid], 'tid');}--></span>我的收藏</a>
				</li><!--{/if}-->
			</ul>
		</div>
		<!--{if $space['uid'] == $_G['uid']}-->
		<div class="platelist mbox">
			<ul>
				<li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}"><em class="logout-i"></em>退出社区</a></li>
			</ul>
		</div>
		<!--{/if}-->
	</div>
	<!-- userinfo end -->

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
