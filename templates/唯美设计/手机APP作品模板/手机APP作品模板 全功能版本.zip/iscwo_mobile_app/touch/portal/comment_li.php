<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>

					<div class="cmitem" data-id="29016">
						<a class="himage" href="home.php?mod=space&uid=$value[uid]"><img src="uc_server/avatar.php?uid=$value[uid]&size=big" width="30" height="30"/></a>
						<div class="cmitembody">
							<p class="cm-s4">
								<a href="home.php?mod=space&uid=$value[uid]">$value[username]</a><span><!--{date($value[dateline], 'u')}--></span><span class="reply btn fr"></span>
							</p>
							<p class="cm-s6">
								<!--{if $_G[adminid] == 1 || $value[uid] == $_G[uid] || $value[status] != 1}-->$value[message]<!--{else}--> {lang moderate_not_validate}<!--{/if}-->
							</p>
							<p>
							  <!--{if ($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']}-->
							  <a href="portal.php?mod=portalcp&ac=comment&op=edit&cid=$value[cid]" >{lang edit}</a>
							  <a href="portal.php?mod=portalcp&ac=comment&op=delete&cid=$value[cid]">{lang delete}</a>
							  <!--{/if}-->
							</p>
						</div>
					</div>



