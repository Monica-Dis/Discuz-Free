<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->

	<!--{eval $member_count = DB::fetch_first('SELECT * FROM %t WHERE uid= %d LIMIT %d', array('common_member_count', "$article[uid]", '1'), 'uid'); $member_profile = DB::fetch_first('SELECT * FROM %t WHERE uid= %d LIMIT %d', array('common_member_profile', "$article[uid]", '1'), 'uid'); $articlepic = DB::fetch_first('SELECT * FROM %t WHERE aid= %d LIMIT %d', array('portal_article_title', "$article[aid]", '1'), 'aid'); }-->


	<div class="postView iPage">
		<div class="header">
			<div class="hbody">
				<a class="fl btn" href="{$_G[siteurl]}portal.php?mod=list&catid=$article[catid]"><span class="sprite60 yy-back"></span></a>

				<!--{if !ckfollow($article[uid])}-->
				<span class="followbtn fr btn"><a title="����TA" href="{$_G[siteurl]}home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$article[uid]"  class="favbtn"><span class="sprite60 yy-stranger"></span></a></span>					
				<!--{else}-->
				<span class="followbtn fr btn"><a title="ȡ������" href="{$_G[siteurl]}home.php?mod=spacecp&ac=follow&op=del&fuid=$article[uid]"  class="favbtn"><span class="sprite60 yy-follow"></span></a></span>					
				<!--{/if}-->


				<div id="userinfo" class="carea">
					<span class="line fl"></span>
					<a href="{$_G[siteurl]}home.php?mod=space&uid=$article[uid]"><img height="30" width="30" src="uc_server/avatar.php?uid=$article[uid]&size=big"/></a>
					<a href="{$_G[siteurl]}home.php?mod=space&uid=$article[uid]">
					<div class="label">
						<span class="ellipsis">$article[username]</span>
					</div>
					</a>
				</div>
			</div>
		</div>
		<div class="scrollView" data-pt="105">
			<!--{if $article[pic]!="data/attachment/"}-->
			<div id="imgContent">
				<img src="{eval echo(getportalimg($article[aid],0,680,0))}"/>
			</div>
			<!--{/if}-->

			<div id="postcontent">
				<div id="posttitle">
					$article[title]
				</div>
				<div class="postbody">
					$content[content]
				</div>
			</div>
			<div id="poststats">
				<span class="sprite32 yy-view"></span>
				<span class="nums">$article[viewnum]</span>
				<span class="sprite32 yy-comment"></span>
				<span class="nums">$article[commentnum]</span>
			</div>
			<div id="postpl">
				<a href="{$_G[siteurl]}home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" class="favbtn" ><div id="praisebtn" class="btn"></div></a>
			</div>
			<!--{eval $query = DB::fetch_all("SELECT * FROM %t WHERE pic<>'' AND catid=%d AND aid!=%d ORDER BY aid DESC LIMIT %d", array('portal_article_title', "$cat[catid]", "$article[aid]", '6'), 'aid'); }-->
			<!--{if $query}-->
			<div id="postxgslide">
				<ul style="width:635px;">
					<!--{loop $query $rvalue}-->
					<li><a href="{$_G[siteurl]}portal.php?mod=view&aid=$rvalue[aid]"><img width="100" height="64" src ="{eval echo(getportalimg($rvalue[aid],0,280,180))}"></a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<div id="comment">
				<p id="cnums">
					$language[26]: <span>$article[commentnum]</span>$language[27]
				</p>
				<div id="cmbody">
					<!--{loop $commentlist $value}-->
					<!--{template portal/comment_li}-->
					<!--{/loop}-->
				</div>
			</div>
		</div>

		<div id="postcomment">
			<form id="cform" name="cform" action="$form_url" method="post" autocomplete="off">
					<!--{if checkperm('seccode') && ($secqaacheck || $seccodecheck)}-->
						<style>.postView .scrollView {height: calc(100% - 155px);height: -webkit-calc(100% - 155px);}.sec_code {padding: 10px 0;}</style>
						<!--{subtemplate common/seccheck}-->
					<!--{/if}-->
				<input type="submit" name="commentsubmit_btn" id="commentsubmit_btn" class="btn fr" value="����"/>
				<!--{if !empty($topicid) }-->
				<input type="hidden" name="referer" value="$topicurl#comment" />
				<input type="hidden" name="topicid" value="$topicid">
				<!--{else}-->
				<input type="hidden" name="portal_referer" value="$viewurl#comment">
				<input type="hidden" name="referer" value="$viewurl#comment" />
				<input type="hidden" name="id" value="$data[id]" />
				<input type="hidden" name="idtype" value="$data[idtype]" />
				<input type="hidden" name="aid" value="$aid">
				<!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}">
				<input type="hidden" name="replysubmit" value="true">
				<input type="hidden" name="commentsubmit" value="true" />
				<div id="textbg">					
					<img width="30" height="30" src="uc_server/avatar.php?uid=$_G[uid]&size=big"/>
					<div>
						<input type="text" autocomplete="off" id="message" name="message" value=""/>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div id="bgmask" class="iPage hide"></div>

<!--{template common/footer}-->