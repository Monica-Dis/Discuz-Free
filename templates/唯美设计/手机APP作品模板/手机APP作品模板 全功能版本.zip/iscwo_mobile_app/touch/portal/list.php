<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->
<!--{eval $list = array();}-->
<!--{eval $cat['caturl']='portal.php?mod=list&catid='.$cat['catid'].'&mobile=2'; }-->
<!--{eval $dateline = $_GET['dateline'] = isset($_GET['dateline']) ? intval($_GET['dateline']) : 0; }-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{if  $dateline}-->
<!--{eval $time= time()-$dateline; $wheresql .= "AND dateline >= $time" ;}-->
<!--{/if}-->
<!--{eval  $list = category_get_list($cat, $wheresql, $page);}-->


	<div id="listPage" class="tableView iPage">
		<div class="listView iPage">
			<div class="header">
				<div class="hbody">
					<div class="openlc fl btn">
						<div class="lcbody">
							<div class="lcitem top">
								<div class="rect top">
								</div>
							</div>
							<div class="lcitem bottom">
								<div class="rect bottom">
								</div>
							</div>
						</div>
					</div>
					<a id="loginpanel" href="{$_G[siteurl]}search.php?mod=forum" class="fr btn" ><span class="sprite60 yy-ss"></span></a>
					<a id="logo" title="$_G[setting][bbname]" href="$nav"><img src="{VIME_DIR}/images/logo.png" width="94" height="30" /></a>
				</div>
				<ul id="soOptions" class="subNav">
					<li class="btn" data-name="fid" data-value="" style="width:50%;"><span class="label" data-label="$cat[catname]">$cat[catname]</span><span class="sprite32 yy-down"></span></li>
					<li class="btn" data-name="owner" data-value="" style="width:50%;"><span class="label" data-label="$language[22]">$language[22]</span><span class="sprite32 yy-down"></span></li>
				</ul>
			</div>

			<div class="scrollView scrollLoad">
				<div class="content">
					<!--{if $list['count']}-->
					<div id="user-works">
					<!--{loop $list['list'] $value}-->
					<div class="citem listCell btn" onclick="location.href='{$_G[siteurl]}portal.php?mod=view&aid=$value[aid]'">
						<!--{if $value[pic]}-->
						<img src="{eval echo(getportalimg($value[aid],0,280,180))}" width="140" height="90"/>
						<!--{else}-->
						<img src="{VIME_DIR}/images/nophoto.png" width="140" height="90"/>
						<!--{/if}-->
						<div class="citemdesc">
							<div class="citemtd">
								<p><span class="ellipsis title">$value[title]</span></p>
								<p>$language[5]:  $value[username]</p>
							</div>
							<div class="citemtag">
								<span class="sprite32 yy-view"></span>
								<span class="nums">$value[viewnum]</span>
								<span class="fr"></span>
							</div>
						</div>
					</div>
					<!--{/loop}-->
					</div>
					<!--{else}-->
					<div id="nomoreresults" class="loading">
						<span><p class="nolist">$language[9]</p></span>
					</div>
					<!--{/if}-->

					<!--{if $list['multi']}-->
					<!--{eval $nextpage = $page + 1; }-->
					<div id="ajaxshow"></div> 
					<div id="a_pg"> 
						<div id="loading-box" style="display: none;">
							<div class="loading">
								<img src="{VIME_DIR}/images/loading2.gif" width="16" height="16"/>
								<span>$language[3]</span>
							</div>
						</div>
						<div id="indexPaging"  class="loading">
							<span><a href="{$_G[siteurl]}portal.php?mod=list&catid=$cat[catid]&dateline=$dateline&page=$nextpage" onclick="return ajaxpage(this.href);">$language[1]</a></span>
						</div>
					</div>
					<div id="nomoreresults" class="loading" style="display:none;">
						<span>$language[2]</span>
					</div>
					<script src="{VIME_DIR}/script/ajaxpage.js?{VERHASH}" type="text/javascript"></script>        
					<script type="text/javascript">
						var pages=$_G['page'];
						var allpage={echo $thispage = ceil($cat['articles'] / $cat['perpage']);};
						function ajaxpage(url){
							jq("loading-box").style.display='block';
							jq("indexPaging").style.display='none';
							var x = new Ajax("HTML");
							pages++;
							url=url+'&page='+pages;
							x.get(url, function (s) {
								s = s.replace(/\\n|\\r/g, "");//alert(s);
								s = s.substring(s.indexOf("<div id=\"user-works\""), s.indexOf("<div id=\"ajaxshow\"></div>"));//alert(s);
								jq('ajaxshow').innerHTML+=s;
								jq("loading-box").style.display='none';
							if(pages==allpage){							
								jq("a_pg").style.display='none';
								jq("nomoreresults").style.display='block';
							}else{
								jq("indexPaging").style.display='block';
							}
							});
							return false;
						}
					</script>
					<!--{/if}-->

				</div>
			</div>

		</div>

		<div class="postView iPage"></div>

	</div>

	<div class="soPage iPage modal" data-soname="fid">
		<div class="pTitle">
			<span class="pClose btn fr"><span class="sprite32 yy-close"></span></span>
			<div class="label">
				<span class="ellipsis">$cat[catname]</span>
			</div>
		</div>
		<div class="scrollView" data-pt="50">
			<ul>
				<!--{eval $query = DB::fetch_all('SELECT * FROM %t WHERE upid=%d LIMIT %d', array('portal_category', '0', '100'), 'catid'); }-->
				<!--{loop $query $value}-->
				<!--{eval $vcatid =$value['catid']; $queryz = DB::fetch_all('SELECT * FROM %t WHERE upid ='.$vcatid.' LIMIT %d', array('portal_category', '100'), 'id');}-->
				<li class="f  {if $cat['catid'] == $value[catid]} active{/if}" onclick="location.href='{$_G[siteurl]}portal.php?mod=list&catid=$value['catid']'">$value[catname]<span class="hide fr sprite32 yy-check"></span></li>
				<!--{loop $queryz $value}-->
				<li class="sub {if $cat['catid'] == $value[catid]} active{/if}" onclick="location.href='{$_G[siteurl]}portal.php?mod=list&catid=$value['catid']'">&nbsp;&nbsp;&nbsp;|---&nbsp;$value[catname]<span class="hide fr sprite32 yy-check"></span></li>
				<!--{/loop}-->
				<!--{/loop}-->
			</ul>
		</div>
	</div>


	<div class="soPage iPage modal" data-soname="owner">
		<div class="pTitle">
			<span class="pClose btn fr"><span class="sprite32 yy-close"></span></span>
			<div class="label">
				<span class="ellipsis">$language[22]</span>
			</div>
		</div>
		<ul>
			<li onclick="location.href='portal.php?mod=list&catid=$cat['catid']&dateline=86400'">$language[31]<span class="hide fr sprite32 yy-check"></span></li>
			<li onclick="location.href='portal.php?mod=list&catid=$cat['catid']&dateline=604800'">$language[32]<span class="hide fr sprite32 yy-check"></span></li>
			<li onclick="location.href='portal.php?mod=list&catid=$cat['catid']&dateline=1209600'">$language[33]<span class="hide fr sprite32 yy-check"></span></li>
		</ul>
	</div>



<!--{template common/footer}-->