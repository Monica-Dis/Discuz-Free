<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->
<!--{eval require_once("template/iscwo_mobile_app/php/portal_index.php");}-->

	<div id="listPage" class="tableView iPage">
		<div class="listView iPage">
			<div class="header">
				<div class="hbody">
					<div class="openlc fl btn">
						<div class="lcbody">
							<div class="lcitem top">
								<div class="rect top">
								</div>
							</div>
							<div class="lcitem bottom">
								<div class="rect bottom">
								</div>
							</div>
						</div>
					</div><ul id="soOptions"><li data-name="fid" data-value=""></li></ul>
					<a id="loginpanel" href="search.php?mod=forum" class="fr btn" ><span class="sprite60 yy-ss"></span></a>
					<a id="logo" title="$_G[setting][bbname]" href="$nav"><img src="{VIME_DIR}/images/logo.png" width="94" height="30" /></a>
				</div>
				<ul id="soOptions" class="subNav">
					<li class="btn" data-name="fid" data-value=""><span class="label" data-label="$language[30]">$language[30]</span><span class="sprite32 yy-down"></span></li>
				</ul>
			</div>

			<div class="scrollView scrollLoad">

			  <!--slide-->
			  <div class="device">
				<div class="swiper-container">
				  <div class="swiper-wrapper">
					<div class="swiper-slide"><a href="#"><img src="{VIME_DIR}/ad/1.jpg" style="width: 100%; min-height: 160px;"></a></div>
					<div class="swiper-slide"><a href="#"><img src="{VIME_DIR}/ad/2.jpg" style="width: 100%; min-height: 160px;"></a></div>
					<div class="swiper-slide"><a href="#"><img src="{VIME_DIR}/ad/3.jpg" style="width: 100%; min-height: 160px;"></a></div>
				  </div>
				</div>
				<div class="pagination"></div>
			  </div>
			  <script src="{VIME_DIR}/script/jquery-1.8.3.min.js"></script>
			  <script src="{VIME_DIR}/dist/idangerous.swiper.min.js"></script>
			  <script>
			  var mySwiper = new Swiper('.swiper-container',{
				pagination: '.pagination',
				loop:true,
				grabCursor: true,
				paginationClickable: true
			  })
			  </script>
			  <!--slide-->

				<div class="content">
					<div id="user-works">
					<!--{loop $list['list'] $value}-->
					<!--{eval $portal_category = DB::fetch_first('SELECT * FROM %t WHERE catid=%d LIMIT %d', array('portal_category', "$value[catid]", '1'), 'catid'); }-->
					<div class="citem listCell btn" onclick="location.href='portal.php?mod=view&aid=$value[aid]'">
						<!--{if $value[pic]}-->
						<img src="{eval echo(getportalimg($value[aid],0,280,180))}" width="140" height="90"/>
						<!--{else}-->
						<img src="{VIME_DIR}/images/nophoto.png" width="140" height="90"/>
						<!--{/if}-->

						<div class="citemdesc">
							<div class="citemtd">
								<p><span class="ellipsis title">$value[title]</span></p>
								<p>$language[5]:  $value[username]</p>
							</div>
							<div class="citemtag">
								<span class="sprite32 yy-view"></span>
								<span class="nums">$value[viewnum]</span>
								<span class="fr">
									<!--{if $portal_category[upid] <= 0}-->
									<a onclick="location.href='portal.php?mod=list&catid=$portal_category[catid]'" style="color: #555;">$portal_category[catname]</a>
									<!--{else}-->
									<!--{eval $portal_category_up = DB::fetch_first('SELECT * FROM %t WHERE catid=%d LIMIT %d', array('portal_category', "$portal_category[upid]", '1'), 'catid');}-->
									<a onclick="location.href='portal.php?mod=list&catid=$portal_category_up[catid]'" style="color: #555;">$portal_category_up[catname]</a> - <a onclick="location.href='portal.php?mod=list&catid=$portal_category[catid]'" style="color: #555;">$portal_category[catname]</a>
									<!--{/if}-->
								</span>
							</div>
						</div>
					</div>
					<!--{/loop}-->
					</div>
					<!--{if $list['count'] > $perpage }-->
					<!--{eval $page = $list['page']; $nextpage = $page + 1; }-->
					<div id="ajaxshow"></div> 
					<div id="a_pg"> 
						<div id="loading-box" style="display: none;">
							<div class="loading">
								<img src="{VIME_DIR}/images/loading2.gif" width="16" height="16"/>
								<span>$language[3]</span>
							</div>
						</div>
						<div id="indexPaging"  class="loading">
							<span><a href="portal.php" onclick="return ajaxpage(this.href);">$language[1]</a></span>
						</div>
					</div>
					<div id="nomoreresults" class="loading" style="display:none;">
						<span>$language[2]</span>
					</div>
					<script src="{VIME_DIR}/script/ajaxpage.js?{VERHASH}" type="text/javascript"></script>        
					<script type="text/javascript">
						var pages=$_G['page'];
						var allpage={echo $thispage = ceil($list['count'] / $list['perpage']);};
						function ajaxpage(url){
							jq("loading-box").style.display='block';
							jq("indexPaging").style.display='none';
							var x = new Ajax("HTML");
							pages++;
							url=url+'&page='+pages;
							x.get(url, function (s) {
								s = s.replace(/\\n|\\r/g, "");//alert(s);
								s = s.substring(s.indexOf("<div id=\"user-works\""), s.indexOf("<div id=\"ajaxshow\"></div>"));//alert(s);
								jq('ajaxshow').innerHTML+=s;
								jq("loading-box").style.display='none';
							if(pages==allpage){							
								jq("a_pg").style.display='none';
								jq("nomoreresults").style.display='block';
							}else{
								jq("indexPaging").style.display='block';
							}
							});
							return false;
						}
					</script>
					<!--{/if}-->

				</div>
			</div>

		</div>

		<div class="postView iPage"></div>

	</div>

	<div class="soPage iPage modal" data-soname="fid">
		<div class="pTitle">
			<span class="pClose btn fr"><span class="sprite32 yy-close"></span></span>
			<div class="label">
				<span class="ellipsis">$language[34]</span>
			</div>
		</div>
		<div class="scrollView" data-pt="50">
			<ul>
				<!--{eval $query = DB::fetch_all('SELECT * FROM %t WHERE upid=%d LIMIT %d', array('portal_category', '0', '100'), 'catid'); }-->
				<!--{loop $query $value}-->
				<!--{eval $vcatid =$value['catid']; $queryz = DB::fetch_all('SELECT * FROM %t WHERE upid ='.$vcatid.' LIMIT %d', array('portal_category', '100'), 'id');}-->
				<li class="f" onclick="location.href='portal.php?mod=list&catid=$value['catid']'">$value[catname]<span class="hide fr sprite32 yy-check"></span></li>
				<!--{loop $queryz $value}-->
				<li class="sub" onclick="location.href='portal.php?mod=list&catid=$value['catid']'">&nbsp;&nbsp;&nbsp;|---&nbsp;$value[catname]<span class="hide fr sprite32 yy-check"></span></li>
				<!--{/loop}-->
				<!--{/loop}-->

			</ul>
		</div>
	</div>



	<div class="pullrefresh" style="display:none;"></div>

<!--{template common/footer}-->