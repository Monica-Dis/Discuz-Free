<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->
<!-- header start -->
	<div id="listPage" class="tableView iPage">
		<div class="listView h iPage">
			<div class="all header">
				<div class="hbody">
					<a class="fl btn" href="forum.php?forumlist=1"><span class="sprite60 yy-back"></span></a>
					<!-- <span class="followbtn fr btn"><a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" id="a_favorite" class="fa_fav" onclick="showWindow(this.id, this.href, 'get', 0);"><span class="yy-stranger">�ղ�</span></a></span>-->
					<span class="followbtn fr btn"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}"><span class="yy-stranger">{lang send_threads}</span></a></span>
					<div id="userinfo" class="carea">
						<span class="line fl"></span>
						<a href="forum.php?mod=forumdisplay&fid=$_G[fid]">
						<div class="label">
							<span class="ellipsis">$_G['forum'][name]</span>
						</div>
						</a>
					</div>
				</div>
				<ul id="soOptions" class="subNav">
					<li class="btn" data-name="fid" data-value=""><span class="label" data-label="$language[11]">$language[11]</span><span class="sprite32 yy-down"></span></li>
					<li class="btn" data-name="sort" data-value="rec"><span class="label" data-label="$language[21]">$language[21]</span><span class="sprite32 yy-down"></span></li>
					<li class="btn" data-name="owner" data-value=""><span class="label" data-label="$language[22]">$language[22]</span><span class="sprite32 yy-down"></span></li>
				</ul>
			</div>
			<div class="scrollView scrollLoad">
				<div class="content">
				<!--{hook/forumdisplay_top_mobile}-->
				<!--{if empty($_G['forum']['picstyle'])}-->

				<!-- main threadlist start -->
				<!--{if !$subforumonly}-->
				<!--{if $_G['forum_threadcount']}-->

				<div class="threadlist">
					<ul>
						<!--{loop $_G['forum_threadlist'] $key $thread}-->
							<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
								{eval continue;}
							<!--{/if}-->
							<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
								{eval $displayorder_thread = 1;}
							<!--{/if}-->
							<!--{if $thread['moved']}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
							<!--{/if}-->
							<li>
							<!--{hook/forumdisplay_thread_mobile $key}-->
							<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] >
							<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
								<span class="c1">$language[23]</span>
							<!--{elseif $thread['digest'] > 0}-->
								<span class="c2">$language[24]</span>
							<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
								<span class="c3">$language[25]</span>
							<!--{/if}-->
							{$thread[subject]}
							<span class="by">$thread[author]</span>
							</a>
							<span class="num">{$thread[replies]}</span>

							</li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--{else}-->
				<div id="nomoreresults" class="loading">
				<span><p class="nolist">{lang forum_nothreads}</p></span>
				</div>
				<!--{/if}-->
				<!--{/if}-->
				<!-- main threadlist end -->
				<!--{else}-->
				<!--{if !$subforumonly}-->
				<!--{if $_G['forum_threadcount']}-->
					<div id="user-works">
					<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
					<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
						{eval $displayorder_thread = 1;}
					<!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<!--{eval var_dump();}-->
					<div class="citem listCell btn" onclick="location.href='forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra'" $thread[highlight]>

					<!--{if $thread['attachment'] == 2}-->
					<!--{eval $table='forum_attachment_'.substr($thread['tid'], -1);}-->
					<!--{eval $pic = DB::fetch_first("SELECT aid,tid FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!=0 ORDER BY `dateline` ASC"); }-->
						<img src="{eval echo(getforumimg($pic[aid],0,280,180))}" width="140" height="90" /></a>
					<!--{else}-->
						<img src="{VIME_DIR}/images/nophoto.png" width="140" height="90"/>
					<!--{/if}-->

						<div class="citemdesc" >
							<div class="citemtd">
								<p><span class="ellipsis title">{$thread[subject]}</span></p>
								<p>$language[5]:  $thread[author]</p>
							</div>
							<div class="citemtag">
								<span class="sprite32 yy-view"></span>
								<span class="nums">$thread[views]</span>
								<span class="fr">
									<!--{if $portal_category[upid] <= 0}-->
									<a onclick="location.href='portal.php?mod=list&catid=$portal_category[catid]'" style="color: #555;">$portal_category[catname]</a>
									<!--{else}-->
									<!--{eval $portal_category_up = DB::fetch_first('SELECT * FROM %t WHERE catid=%d LIMIT %d', array('portal_category', "$portal_category[upid]", '1'), 'catid');}-->
									<a onclick="location.href='portal.php?mod=list&catid=$portal_category_up[catid]'" style="color: #555;">$portal_category_up[catname]</a> - <a onclick="location.href='portal.php?mod=list&catid=$portal_category[catid]'" style="color: #555;">$portal_category[catname]</a>
									<!--{/if}-->
								</span>
							</div>
						</div>
					</div>
					<!--{/loop}-->
					</div>
					<!--{else}-->
					<div id="nomoreresults" class="loading">
					<span><p class="nolist">{lang forum_nothreads}</p></span>
					</div>
					<!--{/if}-->
				<!--{/if}-->

				<!--{/if}-->

				<!--{if $_G['forum_threadcount'] > $_G['tpp']}-->
				<div id="ajaxshow"></div> 
				<div id="a_pg"> 
					<div id="loading-box" style="display: none;">
						<div class="loading">
							<img src="{VIME_DIR}/images/loading2.gif" width="16" height="16"/>
							<span>$language[3]</span>
						</div>
					</div>
					<div id="indexPaging"  class="loading">
						<span><a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}" onclick="return ajaxpage(this.href);">$language[1]</a></span>
					</div>
				</div>
				<div id="nomoreresults" class="loading" style="display:none;">
					<span>$language[2]</span>
				</div>
				<script src="{VIME_DIR}/script/ajaxpage.js?{VERHASH}" type="text/javascript"></script>        
				<script type="text/javascript">
					var pages=$_G['page'];
					var allpage={echo $thispage = ceil($_G['forum_threadcount'] / $_G['tpp']);};
					function ajaxpage(url){
						jq("loading-box").style.display='block';
						jq("indexPaging").style.display='none';
						var x = new Ajax("HTML");
						pages++;
						url=url+'&page='+pages;
						x.get(url, function (s) {
							s = s.replace(/\\n|\\r/g, "");//alert(s);
							s = s.substring(s.indexOf("<div id=\"user-works\""), s.indexOf("<div id=\"ajaxshow\"></div>"));//alert(s);
							jq('ajaxshow').innerHTML+=s;
							jq("loading-box").style.display='none';
						if(pages==allpage){							
							jq("a_pg").style.display='none';
							jq("nomoreresults").style.display='block';
						}else{
							jq("indexPaging").style.display='block';
						}
						});
						return false;
					}
				</script>
				<!--{/if}--> 

				<!--{hook/forumdisplay_bottom_mobile}-->
				</div>
			</div>

		</div>
		<div class="postView iPage"></div>
	</div>

	<div class="soPage iPage modal" data-soname="fid">
		<div class="pTitle">
			<span class="pClose btn fr"><span class="sprite32 yy-close"></span></span>
			<div class="label">
				<span class="ellipsis">$language[12]</span>
			</div>
		</div>
		<div class="scrollView" data-pt="50">
			<ul>
				
				<!--{eval $leftside = forumleftside();}-->
				<!--{loop $leftside['forums'] $upfid $gdata}-->
				<li class="f">$gdata['name']</li>
				<!--{loop $gdata['sub'] $subfid $name}-->
					<!--{if !empty($_G['cache']['forums'][$subfid]['domain']) && !empty($_G['setting']['domain']['root']['forum'])}-->
					<li class="sub {if $_G['fid'] == $subfid || $_G['forum']['fup'] == $subfid} active{/if}" onclick="location.href='http://{$_G['cache']['forums'][$subfid]['domain']}.{$_G['setting']['domain']['root']['forum']}'">&nbsp;&nbsp;&nbsp;|---&nbsp;$name<span class="hide fr sprite32 yy-check"></span></li>
					<!--{else}-->
					
					<li class="sub {if $_G['fid'] == $subfid || $_G['forum']['fup'] == $subfid} active{/if}" onclick="location.href='forum.php?mod=forumdisplay&fid=$subfid'">&nbsp;&nbsp;&nbsp;|---&nbsp;$name<span class="hide fr sprite32 yy-check"></span></li>
					<!--{/if}-->
				<!--{/loop}-->
				<!--{/loop}-->
			</ul>
		</div>
	</div>

	<div class="soPage iPage modal" data-soname="sort">
		<div class="pTitle">
			<span class="pClose btn fr"><span class="sprite32 yy-close"></span></span>
			<div class="label">
				<span class="ellipsis">$language[21]</span>
			</div>
		</div>
		<ul>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang list_post_time}<span class="hide sprite32 yy-check fr"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang replies}<span class="hide sprite32 yy-check fr"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang views}<span class="hide sprite32 yy-check fr"></span></li>

			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang latest}<span class="hide sprite32 yy-check fr"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang order_heats}<span class="hide sprite32 yy-check fr"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter=hot'">{lang hot_thread}<span class="hide sprite32 yy-check fr"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang digest_posts}<span class="hide sprite32 yy-check fr"></span></li>
		</ul>
	</div>

	<div class="soPage iPage modal" data-soname="owner">
		<div class="pTitle">
			<span class="pClose btn fr"><span class="sprite32 yy-close"></span></span>
			<div class="label">
				<span class="ellipsis">$language[22]</span>
			</div>
		</div>
		<ul>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang all}{lang search_any_date}<span class="hide fr sprite32 yy-check"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang last_1_days}<span class="hide fr sprite32 yy-check"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang last_2_days}<span class="hide fr sprite32 yy-check"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang list_one_week}<span class="hide fr sprite32 yy-check"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang list_one_month}<span class="hide fr sprite32 yy-check"></span></li>
			<li onclick="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}'">{lang list_three_month}<span class="hide fr sprite32 yy-check"></span></li>
		</ul>
	</div>

	<div class="pullrefresh" style="display:none;"></div>


<!--{template common/footer}-->
