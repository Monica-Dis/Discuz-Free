<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->

		<div class="postView iPage">

			<div class="header">
				<div class="hbody">
					<a class="fl btn" href="<!--{if $_GET[fromguid] == 'hot'}-->forum.php?mod=guide&view=hot&page=$_GET[page]<!--{else}-->forum.php?mod=forumdisplay&fid=$_G[fid]&<!--{eval echo rawurldecode($_GET[extra]);}--><!--{/if}-->"><span class="sprite60 yy-back"></span></a>

					<span class="followbtn fr btn"><a title="����TA" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$_G[forum_thread][authorid]"  class="favbtn"><span class="sprite60 yy-stranger"></span></a></span>					

					<div id="userinfo" class="carea">
						<span class="line fl"></span>
						<a href="home.php?mod=space&uid=$_G[forum_thread][authorid]"><img height="30" width="30" src="uc_server/avatar.php?uid=$_G[forum_thread][authorid]&size=big"/></a>
						<a href="home.php?mod=space&uid=$_G[forum_thread][authorid]">
						<div class="label">
							<span class="ellipsis">$_G[forum_thread][author]</span>
						</div>
						</a>
					</div>
				</div>
			</div>

			<div class="scrollView" data-pt="105">
				<!--{hook/viewthread_top_mobile}-->
				<!-- main postlist start -->
				<div class="postlist">
					<!--{eval $postcount = 0;}-->
					<!--{loop $postlist $post}-->
					<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
					<!--{hook/viewthread_posttop_mobile $postcount}-->
					<!--{if $post[first]}-->
						<!--{subtemplate forum/viewthread_1}-->
					<!--{else}-->
						<!--{subtemplate forum/viewthread_2}-->
					<!--{/if}-->
				   <!--{hook/viewthread_postbottom_mobile $postcount}-->
				   <!--{eval $postcount++;}-->
				   <!--{/loop}-->
				</div>
				<!-- main postlist end -->
				$multipage
				<!--{hook/viewthread_bottom_mobile}-->

			</div>
			<div id="postcomment" class="np">
				<!--{subtemplate forum/forumdisplay_fastpost}-->
			</div>

		</div>


		<div id="bgmask" class="iPage hide"></div>

<!--{template common/footer}-->
