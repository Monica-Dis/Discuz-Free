<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:forum.php?mod=guide&view=hot');exit;}-->
<!--{/if}-->

<!--{template common/header}-->
	<div id="listPage" class="tableView iPage">
		<div class="listView iPage">
			<!--{template common/header_top}-->
			<div class="scrollView scrollLoad">

				<!--{hook/index_top_mobile}-->
				<!-- main forumlist start -->
				<div class="wp wm" id="wp">
					<!--{loop $catlist $key $cat}-->
					<div class="bm bmw fl">
						<div class="subforumshow bm_h cl" href="#sub_forum_$cat[fid]">
							<span class="o"><img src="{VIME_DIR}/mobile/images/collapsed_<!--{if !$_G[setting][mobile][mobileforumview]}-->yes<!--{else}-->no<!--{/if}-->.png"></span>
						<h2><a href="javascript:;">$cat[name]</a></h2>
						</div>
						<div id="sub_forum_$cat[fid]" class="sub_forum bm_c">
							<ul>
								<!--{loop $cat[forums] $forumid}-->
								<!--{eval $forum=$forumlist[$forumid];}-->
								<li><!--{if $forum[icon]}-->
									$forum[icon]
								<!--{else}-->
									<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
								<!--{/if}--><a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><!--{if $forum[todayposts] > 0}--><span class="num">$forum[todayposts]</span><!--{/if}-->{$forum[name]}</a></li>
								<!--{/loop}-->
							</ul>
						</div>
					</div>
					<!--{/loop}-->
				</div>
				<!-- main forumlist end -->
				<!--{hook/index_middle_mobile}-->
			</div>
		</div>
		<div class="postView iPage"></div>
	</div>

	<script type="text/javascript">
		(function() {
			<!--{if !$_G[setting][mobile][mobileforumview]}-->
				$('.sub_forum').css('display', 'block');
			<!--{else}-->
				$('.sub_forum').css('display', 'none');
			<!--{/if}-->
			$('.subforumshow').on('click', function() {
				var obj = $(this);
				var subobj = $(obj.attr('href'));
				if(subobj.css('display') == 'none') {
					subobj.css('display', 'block');
					obj.find('img').attr('src', '{VIME_DIR}/mobile/images/collapsed_yes.png');
				} else {
					subobj.css('display', 'none');
					obj.find('img').attr('src', '{VIME_DIR}/mobile/images/collapsed_no.png');
				}
			});
		 })();
	</script>

<!--{template common/footer}-->
