<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" class="hbc">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by Discuz!</title>
<!--{eval define('VIME_DIR', 'template/iscwo_mobile_app/style');}-->
<!--{eval require_once("template/iscwo_mobile_app/php/setup.php");}-->
<!--{if $gbk_utf8=='gbk'}--><!--{eval require_once("template/iscwo_mobile_app/php/language_gbk.php");}--><!--{/if}-->
<!--{if $gbk_utf8=='utf8'}--><!--{eval require_once("template/iscwo_mobile_app/php/language_utf8.php");}--><!--{/if}-->
<link rel="stylesheet" href="{VIME_DIR}/mobile/style.css?{VERHASH}" type="text/css" media="all">
<link rel="stylesheet" href="{VIME_DIR}/css/style.css?{VERHASH}" type="text/css"  />
<link rel="stylesheet" href="{VIME_DIR}/dist/idangerous.swiper.css?{VERHASH}" type="text/css" >
<link rel="stylesheet" href="{VIME_DIR}/font/icon.css?{VERHASH}" type="text/css" >
<script src="{VIME_DIR}/script/jquery-1.8.3.min.js?{VERHASH}"></script>
<script src="{VIME_DIR}/script/lib.min.js?{VERHASH}"></script>
<script src="{VIME_DIR}/script/org_wx.js?{VERHASH}" data-main="listMain"></script>
<script type="text/javascript">YY.config.url="$_G[siteurl]";YY.config.service={"TOKEN":{}}</script>

<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>

<script src="{VIME_DIR}/script/common.js?{VERHASH}" charset="{CHARSET}"></script>
</head>

<body ondragstart="window.event.returnValue=false" oncontextmenu="window.event.returnValue=false" onselectstart="event.returnValue=false">
<!--{hook/global_header_mobile}-->

<!--{if $_G['setting']['domain']['app']['mobile']}-->
	{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
<!--{else}-->
	{eval $nav = "forum.php";}
<!--{/if}-->

<div id="leftcontrol" class="hide">
	<div class="mdl-card">
		<!--{if $_G['uid']}-->
		<div class="mdl-card__title user">
		  <ul><li data-href="home.php?mod=space&uid=$_G[uid]"><img src="uc_server/avatar.php?uid=$_G[uid]&size=big" alt=""></li></ul>
		  <span class="user-name cl" >
		  <ul>
		  <li data-href="home.php?mod=space&uid=$_G[uid]">{$_G[member][username]}</li>
		</ul>
		</span>
		  <ul class="user-mail cl">
			  <li data-href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me" ><i class="material-icons">star</i>$language[13]</li>
			  <li data-href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me" ><i class="material-icons">message</i>$language[14]</li>
			  <li data-href="home.php?mod=space&do=pm"><i class="material-icons">mode_comment</i>$language[37]<!--{if $_G[member][newpm]}--><!--{/if}--></li>
		  </ul>
		</div>
		<!--{else}-->
		<div class="mdl-card__title user">
		  <ul><li data-href="member.php?mod=logging&action=login"><img src="uc_server/avatar.php?uid=$_G[uid]&size=big" alt=""></li></ul>
		  <span class="user-name" ><ul><li data-href="member.php?mod={$_G[setting][regname]}" class="v1"><i class="material-icons">person_add</i>$language[15]</li><li data-href="member.php?mod=logging&action=login" class="v2"><i class="material-icons">lock_outline</i>$language[16]</li></ul></span>
		</div>
		<!--{/if}-->
	</div>
	<ul class="two">
		<li class="a"><i class="material-icons">apps</i>$_G['setting']['bbname']</li>
		<li {if $_GET[mod]=='guide'}class="ac"{/if}data-href="forum.php?mod=guide&view=hot"><i class="material-icons">home</i>$language[38]</li>
		<li {if $_GET[mod]=='list'}class="ac"{/if} data-href="$setup[1]"><i class="material-icons">photo_library</i>$language[17]</li>
		<li {if $_GET[forumlist]==1}class="ac"{/if} data-href="forum.php?forumlist=1"><i class="material-icons">forum</i>$language[19]</li>
		<li {if $_GET[mod]=='forumdisplay'}class="ac"{/if}data-href="$setup[2]"><i class="material-icons">photo_library</i>$language[20]</li>
		<!--{if $_G['uid']}-->
		<li data-href="member.php?mod=logging&action=logout&formhash={FORMHASH}"><i class="material-icons">power_settings_new</i>{lang logout}</li>
		<!--{else}-->
		<!--{/if}-->
	</ul>
</div>

<div id="container" class="iPage">