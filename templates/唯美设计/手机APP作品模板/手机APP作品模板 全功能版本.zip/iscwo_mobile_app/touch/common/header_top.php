<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
			<div class="header">
				<div class="hbody">
					<div class="openlc fl btn">
						<div class="lcbody">
							<div class="lcitem top">
								<div class="rect top">
								</div>
							</div>
							<div class="lcitem bottom">
								<div class="rect bottom">
								</div>
							</div>
						</div>
					</div>
					<a id="loginpanel" href="search.php?mod=forum" class="fr btn" ><span class="sprite60 yy-ss"></span></a>
					<a id="logo" title="$_G[setting][bbname]" href="$nav"><img src="{VIME_DIR}/images/logo.png" width="94" height="30" /></a>
				</div>
			</div>