<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->
	<div class="postView iPage">

		<!-- header start -->
		<div class="all header">
			<div class="hbody">
				<a class="fl btn" href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><span class="sprite60 yy-back"></span></a>
				<div id="userinfo" class="carea">
					<span class="line fl"></span>
					<!--{if $_GET['type'] == 'article'}-->
					<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">
					<div class="label">
						<span class="ellipsis">$language[28]</span>
					</div>
					</a>
					<!--{else}-->
					<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=article">
					<div class="label">
						<span class="ellipsis">$language[29]</span>
					</div>
					</a>
					<!--{/if}-->
				</div>
			</div>
		</div>
		<!-- header end -->



		<!-- main collectlist start -->
		<!--{if $_GET['type'] == 'forum'}-->
		<div class="coll_list b_radius">
			<ul>
				<!--{if $list}-->
					<!--{loop $list $k $value}-->
					<li><a href="$value[url]">$value[title]</a></li>
					<!--{/loop}-->
				<!--{else}-->
				<li>{lang no_favorite_yet}</li>
				<!--{/if}-->

			</ul>
		</div>
		<!--{else}-->
		<div class="threadlist">
			<ul>
				<!--{if $list}-->
					<!--{loop $list $k $value}-->
					<li><a href="$value[url]">$value[title]</a></li>
					<!--{/loop}-->
				<!--{else}-->
				<li>{lang no_favorite_yet}</li>
				<!--{/if}-->
			</ul>
		</div>
		<!--{/if}-->
		<!-- main collectlist end -->
		$multi

	</div>
	<div id="bgmask" class="iPage hide"></div>

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
