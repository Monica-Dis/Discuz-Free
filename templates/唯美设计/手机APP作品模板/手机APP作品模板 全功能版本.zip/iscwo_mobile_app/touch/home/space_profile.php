<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>


<!--{eval $member_count = DB::fetch_first('SELECT * FROM %t WHERE uid= %d LIMIT %d', array('common_member_count', "$space[uid]", '1'), 'uid'); $member_profile = DB::fetch_first('SELECT * FROM %t WHERE uid= %d LIMIT %d', array('common_member_profile', "$space[uid]", '1'), 'uid');}-->

<!--{eval $wheresql .= 'at.uid = '.$space[uid].''; $count = C::t('portal_article_title')->fetch_all_by_sql($wheresql, '', 0, 0, 1, 'at');}-->

<!--{template common/header}-->
	<!--{if !$_GET['mycenter']}-->
	<!--{eval dheader('Location:home.php?mod=space&uid='.$space[uid].'&do=thread');exit;}-->
	<div id="userPage" class="tableView iPage">
		<div class="listView iPage">
			<div class="header">
				<div class="hbody">
					<div class="openlc fl btn">
						<div class="lcbody">
							<div class="lcitem top">
								<div class="rect top">
								</div>
							</div>
							<div class="lcitem bottom">
								<div class="rect bottom">
								</div>
							</div>
						</div>
					</div>
					<!--{if !ckfollow($space['uid'])}-->
					<span class="followbtn fr btn"><a id="followmod" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"  class="favbtn"><span class="sprite60 yy-stranger"></span></a></span>					
					<!--{else}-->
					<span class="followbtn fr btn"><a id="followmod" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]"  class="favbtn"><span class="sprite60 yy-follow"></span></a></span>					
					<!--{/if}-->
					<a id="logo" title="$_G[setting][bbname]" href="$nav"><img src="{VIME_DIR}/images/logo.png" width="94" height="30" /></a>
				</div>
			</div>
			<div class="scrollView scrollLoad" data-pt="50" >
				<div id="userHome">
					<div id="userBody">
						<div id="usernu">
							<div id="uheadimg">
								<a href="home.php?mod=space&uid=$space[uid]"><img id="uhi_1" src="<!--{avatar($space[uid], big, true)}-->" width="76" height="76"/></a>
								<img id="uhi_2" width="14" height="14" src="{VIME_DIR}/images/mo.png"/>
							</div>
							<div id="unickname">
								<span class="ellipsis">$space[username]</span>
								<img src="{VIME_DIR}/images/urec.png" width="16px" height="16px"/>
							</div>
						</div>
						<ul id="usercount">
							<li><p>$member_count[following]</p>$language[8]</li>
							<li><p>$member_count[follower]</p>$language[7]</li>
							<li><p>$count</p>$language[6]</li>
						</ul>
					</div>
				</div>
				<!-- userinfo start -->
				<div class="userinfo">
					<div class="user_box">
						<ul>
							<li><span>$space[credits]</span>{lang credits}</li>
							<!--{loop $_G[setting][extcredits] $key $value}-->
							<!--{if $value[title]}-->
							<li><span>{$space["extcredits$key"]} $value[unit]</span>$value[title]</li>
							<!--{/if}-->
							<!--{/loop}-->
						</ul>
					</div>
					<!--{if $space['uid'] == $_G['uid']}-->
					<div class="btn_exit"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout_mobile}</a></div>
					<!--{/if}-->
				</div>
				<!-- userinfo end -->
			</div>
		</div>
	</div>
	<div id="bgmask" class="iPage hide"></div>
	<!--{else}-->
	<div id="userPage" class="tableView iPage">
		<div class="listView iPage">
			<div class="header">
				<div class="hbody">
					<div class="openlc fl btn">
						<div class="lcbody">
							<div class="lcitem top">
								<div class="rect top">
								</div>
							</div>
							<div class="lcitem bottom">
								<div class="rect bottom">
								</div>
							</div>
						</div>
					</div>
					<!--{if !ckfollow($space['uid'])}-->
					<span class="followbtn fr btn"><a id="followmod" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"  class="favbtn"><span class="sprite60 yy-stranger"></span></a></span>					
					<!--{else}-->
					<span class="followbtn fr btn"><a id="followmod" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]"  class="favbtn"><span class="sprite60 yy-follow"></span></a></span>					
					<!--{/if}-->
					<a id="logo" title="$_G[setting][bbname]" href="$nav"><img src="{VIME_DIR}/images/logo.png" width="94" height="30" /></a>
				</div>
			</div>
			<div class="scrollView scrollLoad" data-pt="50" >
				<div id="userHome">
					<div id="userBody">
						<div id="usernu">
							<div id="uheadimg">
								<a href="home.php?mod=space&uid=$space[uid]"><img id="uhi_1" src="<!--{avatar($space[uid], big, true)}-->" width="76" height="76"/></a>
								<img id="uhi_2" width="14" height="14" src="{VIME_DIR}/images/mo.png"/>
							</div>
							<div id="unickname">
								<span class="ellipsis">$space[username]</span>
								<img src="{VIME_DIR}/images/urec.png" width="16px" height="16px"/>
							</div>
						</div>
						<ul id="usercount">
							<li><p>$member_count[following]</p>$language[8]</li>
							<li><p>$member_count[follower]</p>$language[7]</li>
							<li><p>$count</p>$language[6]</li>
						</ul>
					</div>
				</div>
				<!-- userinfo start -->
				<div class="userinfo" style="display: none;">
					<div class="myinfo_list cl">
						<ul>
							<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang myfavorite}</a></li>
							<li><a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me">{lang mythread}</a></li>
							<li class="tit_msg"><a href="home.php?mod=space&do=pm">{lang mypm}<!--{if $_G[member][newpm]}--><img src="{STATICURL}image/mobile/images/icon_msg.png" /><!--{/if}--></a></li>
							<li><a href="home.php?mod=space&uid={$_G[uid]}">{lang myprofile}</a></li>
						</ul>
					</div>
				</div>
				<!-- userinfo end -->
				<!-- userinfo start -->
				<div class="userinfo">
					<div class="user_box">
						<ul>
							<li><span>$space[credits]</span>{lang credits}</li>
							<!--{loop $_G[setting][extcredits] $key $value}-->
							<!--{if $value[title]}-->
							<li><span>{$space["extcredits$key"]} $value[unit]</span>$value[title]</li>
							<!--{/if}-->
							<!--{/loop}-->
						</ul>
					</div>
					<!--{if $space['uid'] == $_G['uid']}-->
					<div class="btn_exit"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout_mobile}</a></div>
					<!--{/if}-->
				</div>
				<!-- userinfo end -->
			</div>
		</div>
	</div>
	<div id="bgmask" class="iPage hide"></div>
	<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
