<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{template common/header}-->


	<div id="listPage" class="tableView iPage">
		<div class="listView iPage">
			<!--{template common/header_top}-->
			<div class="scrollView scrollLoad">
				<ul class="subNav">
					<li class="btn" style="width: 50%;background: #FFFFFF" onclick="location.href='search.php?mod=forum'">$language[19]</li>
					<li class="btn" style="width: 50%;background: #EEEDED" onclick="location.href='search.php?mod=portal'">$language[17]</li>
				</ul>
				<form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<!--{subtemplate search/pubsearch}-->
					<!--{eval $policymsgs = $p = '';}-->
					<!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
					<!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
					<!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
					<!--{/loop}-->
					<!--{if $policymsgs}--><p>{lang search_credit_msg}</p><!--{/if}-->
				</form>
				<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
					<!--{subtemplate search/thread_list}-->
				<!--{/if}-->
			</div>
		</div>
		<div class="postView iPage"></div>
	</div>


<!--{template common/footer}-->
