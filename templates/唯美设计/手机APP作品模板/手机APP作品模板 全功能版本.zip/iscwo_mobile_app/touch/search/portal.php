<?php echo 'Ψ�����QQ:474902417��ҵģ�屣�����뵽�����Ϲ�������ģ�� http://DisM.taobao.com/?@1439.developer';exit;?>
<!--{subtemplate common/header}-->


	<div id="listPage" class="tableView iPage">
		<div class="listView iPage">
			<!--{template common/header_top}-->
			<div class="scrollView scrollLoad">

				<ul class="subNav">
					<li class="btn" style="width: 50%;background: #EEEDED" onclick="location.href='search.php?mod=forum'">$language[19]</li>
					<li class="btn" style="width: 50%;background: #FFFFFF" onclick="location.href='search.php?mod=portal'">$language[17]</li>
				</ul>

  
				  <form id="mod_portal" class="searchform" method="post" action="search.php">
					<input type="hidden" id="mod_portal" name="mod" value="portal" checked="checked" />
					<input type="hidden" value="yes" name="searchsubmit">
					<div class="search">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tbody>
							<tr>
								<td>						
									<input value="$keyword" type="text" name="srchtxt" class="input" autocomplete="off" value="" placeholder="$language[35]">
								</td>
								<td width="66" align="center" class="scbar_btn_td">
									<div><input type="submit" class="button2" name="btnG" value="{lang search}"></div>
								</td>
							</tr>
						</tbody>
					</table>
					</div>
					</form>
					<!--{if $keyword}-->  
					<div class="threadlist">
						  <h2 class="thread_tit">{lang search_result_keyword}</em> </h2>
						  <!--{/if}-->
						  <!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
						  <ul class="ul">
							<!--{if empty($articlelist)}-->
								<li><a href="javascript:;">{lang search_nomatch}</a></li>
							<!--{else}--> 
							<!--{loop $articlelist $article}-->
								<li><a href="portal.php?mod=view&aid=$article[aid]">$article[title]</a></li>
							<!--{/loop}-->
							<!--{/if}-->
						  </ul>
					</div>
					<!--{/if}-->

				<!--{if $multipage}--><div>$multipage</div><!--{/if}-->

			</div>
		</div>
		<div class="postView iPage"></div>
	</div>

<!--{subtemplate common/footer}-->