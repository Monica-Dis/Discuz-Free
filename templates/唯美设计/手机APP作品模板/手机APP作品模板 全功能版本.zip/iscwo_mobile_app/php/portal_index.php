<?php


$list = array();
$list = category_get_list($catid, $_G['page'], $perpage, $orderby, $filename);

function category_get_list($catid, $page = 1, $perpage = 0, $orderby = 'dateline', $filename = 'portal.php') {
	global $_G;
	$perpage = intval($perpage);
	$page = intval($page);
	$perpage = empty($perpage) ? 15 : $perpage;
	$maxpages = 1000;
	$page = empty($page) ? 1 : min($page, $maxpages);
	$start = ($page-1)*$perpage;
	if($start<0) $start = 0;
	$list = array();
	$pricount = 0;
	$multi = '';
	$wheresql .= " at.status='0'";

	$count = C::t('portal_article_title')->fetch_all_by_sql($wheresql, '', 0, 0, 1, 'at');
	
	if($count) {
		$query = C::t('portal_article_title')->fetch_all_by_sql($wheresql, 'ORDER BY at.'.$orderby.' DESC', $start, $perpage, 0, 'at');
		var_dump();
		foreach($query as $value) {
			$value['catname'] = $_G['cache']['portalcategory'][$value['catid']]['catname'];

			$value['dateline'] = dgmdate($value['dateline']);
			$viewcommentnum = C::t('portal_article_count')->fetch($value['aid']);
			$value['viewnum'] = intval($viewcommentnum['viewnum'])-1;
			$value['commentnum'] = intval($viewcommentnum['commentnum']);
			$list[] = $value;
		}
		$multi = multi($count, $perpage, $page, $filename, $maxpages);
	}
	return $return = array('list'=>$list,'count'=>$count,'multi'=>$multi,'page'=>$page,'perpage'=>$perpage);
}
//From: Dism_taobao_com
?>