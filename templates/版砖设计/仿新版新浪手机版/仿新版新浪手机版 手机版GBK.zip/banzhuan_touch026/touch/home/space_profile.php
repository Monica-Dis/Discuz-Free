<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->

<!--{template common/header}-->

<!--{if !$_GET['mycenter']}-->

			<div class="userinfo bz-bg-f5f5f5">
				
				<!--{template home/space_profile_top}-->
				
				<!--{if $space['medals']}-->
				<div style="border-top: 1px solid #EFEFEF; border-bottom: 1px solid #EFEFEF;">
					<div class="bz-p10 bz-bg-fff bzbb1" style="font-size: 16px;"><h3>{lang medals}</h3></div>
						<p class="bz-p10 bz-bg-fff">
							<a>
							<!--{loop $space['medals'] $medal}-->
								<img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" id="md_{$medal[medalid]}" />
							<!--{/loop}-->
							</a>
						</p>
				</div>
				<div class="banzhuan-h10 bz-bg-f5f5f5"></div>
				<!--{/if}-->
		        
		        <div class="user_box">
					<div>
						<ul>
							    <!--{if $space[customstatus]}-->
								<li><a>{lang permission_basic_status}<span>$space[customstatus]</span></a></li>
								<!--{/if}-->
								<!--{if $space[group][maxsigsize] && $space[sightml]}-->
								<li><a>{lang personal_signature}<span>$space[sightml]</span></a></li>
								<!--{/if}-->	
							<!--{loop $_G[setting][extcredits] $key $value}-->
								<!--{if $value[title]}-->
								<li><a>$value[title]<span>{$space["extcredits$key"]} $value[unit]</span></a></li>
								<!--{/if}-->
							<!--{/loop}-->
							    <li style="margin-bottom: 10px;"><a>{lang credits}<span>$space[credits]</span></a></li>
							    <!--{if $space[oltime]}-->
							    <li class="bzbt1"><a>{lang online_time}<span>$space[oltime] {lang hours}</span></a></li>
						        <!--{/if}-->
								<!--{if $space[lastsendmail]}-->
								<li><a>{lang last_send_email}<span>$space[lastsendmail]</span></a></li>
								<!--{/if}-->
								<!--{if $_G['setting']['allowspacedomain'] && $_G['setting']['domain']['root']['home'] && checkperm('domainlength') && !empty($space['domain'])}-->
						        <!--{eval $spaceurl = 'http://'.$space['domain'].'.'.$_G['setting']['domain']['root']['home'];}-->
								<li><a href="$spaceurl" onclick="setCopy('$spaceurl', '{lang copy_space_address}');return false;">{lang second_domain}<span>$spaceurl</span></a></li>
						        <!--{/if}-->
								<!--{if in_array($_G[adminid], array(1, 2))}-->
								<li><a>Email<span>$space[email]</span></a></li>
								<!--{/if}-->
								<li><a>{lang email_status}<span><!--{if $space[emailstatus] > 0}-->{lang profile_verified}<!--{else}-->{lang profile_no_verified}<!--{/if}--></span></a></li>
								<li><a>{lang video_certification}<span><!--{if $space[videophotostatus] > 0}-->{lang profile_certified} <!--{if $showvideophoto}-->(<a href="home.php?mod=space&uid=$space[uid]&do=videophoto" id="viewphoto" onclick="showWindow(this.id, this.href, 'get', 0)">{lang view_certification_photos}</a>)<!--{/if}--><!--{else}-->{lang profile_no_certified}<!--{/if}--></span></a></li>
								<!--{loop $profiles $value}-->
								<li><a>$value[title]<span>$value[value]</span></a></li>
								<!--{/loop}-->	
						</ul>
					</div>
					<!--{if $count}-->
					<div class="banzhuan-h10"></div>
					<div style="border-top: 1px solid #EFEFEF; border-bottom: 1px solid #EFEFEF;">
						<div class="bz-p10 bz-bg-fff bzbb1" style="font-size: 16px;"><h3>{lang manage_forums}</h3></div>
						<ul class="bzscount bz-p10 bz-bg-fff">
							<!--{loop $manage_forum $key $value}-->
							<li><a href="forum.php?mod=forumdisplay&fid=$key">$value</a></li>
							<!--{/loop}-->
						</ul>
					</div>
					<!--{/if}-->
				</div>
				
			</div>
			
			<!--{if $space['uid'] == $_G['uid']}-->
			<!--{else}-->
			
				<div class="banzhuan-bottom"></div>
				<div id="nmfootbar">
				    <div class="fbc">
				        <ul>
				        	    <!--{if helper_access::check_module('follow') && $space[uid] != $_G[uid]}-->
								<li>
									<!--{eval $follow = 0;}-->
									<!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $space['uid']);}-->
									<!--{if !$follow}-->
										<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]" class="iconfont icon-guanzhu dialog"><span>&nbsp;{lang follow_add}TA</span></a>
									<!--{else}-->
										<a href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]" class="iconfont icon-quxiaoguanzhu dialog"><span>&nbsp;{lang follow_del}</span></a>
									<!--{/if}-->
								</li>
							<!--{/if}-->
				            
				            <li><a href="home.php?mod=space&do=pm&subop=view&touid=$space[uid]&mobile=2" class="iconfont icon-message"><span>&nbsp;{lang send_pm}</span></a></li>
				            
				        </ul>
				    </div>
				</div>
			
			<!--{/if}-->
			
			<div id="mask" style="display:none;"></div>
			</body>
			</html>
	
<!--{else}-->

			<div class="userinfo bz-bg-f5f5f5">
				<a href="home.php?mod=space&uid={$_G[uid]}&do=profile">
					<div class="user_avatar_my">
						<div class="avatar_m z">
							<span><img src="<!--{avatar($_G[uid], big, true)}-->" /></span>
						</div>
						<div class="avatar_n z">
							<h2 class="name">$_G[username]</h2>
						    <p>Lv.{$_G['cache']['usergroups'][$space[groupid]][stars]} {$_G['cache']['usergroups'][$space[groupid]][grouptitle]}<!--{if getuserprofile('gender') == 0}--><!--{elseif getuserprofile('gender') == 1}-->&nbsp;&#30007;<!--{elseif getuserprofile('gender') == 2}-->&nbsp;&#22899;<!--{/if}-->&nbsp;{lang credits}:$_G['member'][credits]</p>
						</div>
						<div class="avatar_y y"><span class="y iconfont icon-gengduo"></span></div>
					</div>
				</a>
				<div class="myinfo_list cl banzhuan-clear">
					<ul>
						<li class="bzbt1 bz-mt10"><a href="home.php?mod=space&do=pm&mobile=2" class="iconfont icon-youjian2 bzbb1">&nbsp;&nbsp;&#31449;&#20869;&#20449;<!--{if $_G[member][newpm]}--><em class="iconfont icon-dian1"></em><!--{/if}--><span class="y iconfont icon-gengduo"></span></a></li>
						<li class="bzbb1"><a href="home.php?mod=space&do=notice&mobile=2" class="iconfont icon-tixing1">&nbsp;&nbsp;{lang mail_system_insys}<!--{if $_G[member][newprompt]}--><em class="iconfont icon-dian1"></em><!--{/if}--><span class="y iconfont icon-gengduo"></span></a></li>
						<li class="bzbt1 bz-mt10"><a href="home.php?mod=space&do=favorite&type=all&mobile=2" class="iconfont icon-shoucang bzbb1">&nbsp;&nbsp;{lang myfavorite}<span class="y iconfont icon-gengduo"></span></a></li>	
						<li><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=thread" class="iconfont icon-ziliao21 bzbb1">&nbsp;&nbsp;{lang myitem}{lang topic}<span class="y iconfont icon-gengduo"></span></a></li>
						<li class="bzbb1"><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=reply" class="iconfont icon-xiaoxi">&nbsp;&nbsp;{lang myitem}{lang reply}<span class="y iconfont icon-gengduo"></span></a></li>
						<li class="bzbt1 bz-mt10"><a href="forum.php?mod=announcement&mobile=2" class="iconfont icon-tixing bzbb1">&nbsp;&nbsp;&#20844;&#21578;<span class="y iconfont icon-gengduo"></span></a></li>	
						<li><a href="misc.php?mod=tag&mobile=2" class="iconfont icon-tag bzbb1">&nbsp;&nbsp;&#26631;&#31614;<span class="y iconfont icon-gengduo"></span></a></li>
						<li class="bzbb1"><a href="misc.php?mod=faq&mobile=2" class="iconfont icon-bangzhu">&nbsp;&nbsp;{lang faq}<span class="y iconfont icon-gengduo"></span></a></li>
						<li class="bzbt1 bzbb1 bz-mt10"><a href="home.php?mod=spacecp" class="iconfont icon-set1">&nbsp;&nbsp;&#20010;&#20154;{lang setup}<span class="y iconfont icon-gengduo"></span></a></li>					    
					    <li class="bzbt1 bzbb1 bz-mt10"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="iconfont icon-tuichu2">&nbsp;&nbsp;{lang logout_mobile}<span class="y iconfont icon-gengduo"></span></a></li>					
					</ul>
				</div>
			</div>
			
			<div class="banzhuan-h10"></div>
			<!--{eval $nofooter = true;}-->
            <!--{template common/footer}-->
			
<!--{/if}-->


