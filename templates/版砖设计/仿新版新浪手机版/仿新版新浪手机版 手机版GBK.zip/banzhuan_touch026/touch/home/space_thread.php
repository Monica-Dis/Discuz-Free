<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->

<!--{if !$diymode}-->
		
		<div class="bz-header">
			<div class="bz-header-left">
				<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
			</div>
			<h2><!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->{lang myitem}{lang reply}<!--{else}-->{lang mythread}<!--{/if}--></h2>
			<div class="bz-header-right">
				<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
			</div>
		</div>
		
		<div class="stthreadlist">
			<ul class="bz-bg-fff bzbt1">
			<!--{if $list}-->
			
				<!--{loop $list $thread}-->
					<li>
						
						<!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
						<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]">
							$thread[subject]
							<div>
									    <span class="by">{lang show}:{$thread[views]}</span>
									    <span class="by">{lang reply}:{$thread[replies]}</span>
									<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
										<em class="iconfont icon-top01 y color-red" style="font-size: 12px;"></em>
									<!--{elseif $thread['digest'] > 0}-->
										<em class="iconfont icon-jing y color-red" style="font-size: 12px;"></em>
									<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
										<em class="iconfont icon-tupian y color-red"></em>
									<!--{/if}-->					
							</div>
						</a>
						<!--{else}-->
						<a href="forum.php?mod=viewthread&tid=$thread[tid]">
							$thread[subject]
							<div>
									    <span class="by">{lang show}:{$thread[views]}</span>
									    <span class="by">{lang reply}:{$thread[replies]}</span>
									<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
										<em class="iconfont icon-top01 y color-red" style="font-size: 12px;"></em>
									<!--{elseif $thread['digest'] > 0}-->
										<em class="iconfont icon-jing y color-red" style="font-size: 12px;"></em>
									<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
										<em class="iconfont icon-tupian y color-red"></em>
									<!--{/if}-->	
							</div>
						</a>
						<!--{/if}-->
					
					</li>
				<!--{/loop}-->
				
			<!--{else}-->
			
			    <li class="guide-no">
				    <p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang no_related_posts}</p>
				</li>
				
			<!--{/if}-->
			</ul>
			<!--{if $multi}-->
			   <div class="pgs cl">$multi</div>
			<!--{/if}--> 
		</div>
		
<!--{else}-->

	    <!--{template home/space_profile_top}-->
		<div class="stthreadlist">
			<ul class="bz-bg-fff bzbt1">
				<!--{if $list}-->
				
					<!--{loop $list $thread}-->
						<li>
							<!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
								<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]">
									$thread[subject]
									<div>
											    <span class="by">{lang show}:{$thread[views]}</span>
											    <span class="by">{lang reply}:{$thread[replies]}</span>
											<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
												<em class="iconfont icon-top01 y color-red" style="font-size: 12px;"></em>
											<!--{elseif $thread['digest'] > 0}-->
												<em class="iconfont icon-jing y color-red" style="font-size: 12px;"></em>
											<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
												<em class="iconfont icon-tupian y color-red"></em>
											<!--{/if}-->					
									</div>
								</a>
							<!--{else}-->
								<a href="forum.php?mod=viewthread&tid=$thread[tid]">
									$thread[subject]
									<div>
											    <span class="by">{lang show}:{$thread[views]}</span>
											    <span class="by">{lang reply}:{$thread[replies]}</span>
											<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
												<em class="iconfont icon-top01 y color-red" style="font-size: 12px;"></em>
											<!--{elseif $thread['digest'] > 0}-->
												<em class="iconfont icon-jing y color-red" style="font-size: 12px;"></em>
											<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
												<em class="iconfont icon-tupian y color-red"></em>
											<!--{/if}-->	
									</div>
								</a>
							<!--{/if}-->
						</li>
					<!--{/loop}-->
					
				<!--{else}-->
				
				    <div class="guide-no bzbb1">
					    <p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
						<p class="color-b">{lang no_related_posts}</p>
					</div>
					
				<!--{/if}-->
			</ul>
			
			<!--{if $multi}-->
			   <div class="pgs cl">$multi</div>
			<!--{/if}--> 
			
		</div>		
		
<!--{/if}--> 


<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<div class="banzhuan-bottom"></div>
</body>
</html>
