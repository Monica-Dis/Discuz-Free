<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{eval $_G['home_tpl_titles'] = array('{lang remind}');}-->
<!--{template common/header}-->

<div class="bz-header">
	<div class="bz-header-left">
		<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="iconfont icon-fanhui"></a>
	</div>
	<h2>{lang mail_system_insys}</h2>
	<div class="bz-header-right">
		<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
	</div>
</div>

<div class="bz-nt-bg">
	<div class="bz-nt-appl">
		<div class="tbn">
			<ul>	
				<!--{loop $_G['notice_structure'] $key $type}-->
				<li $opactives[$key]><em class="notice_$key"></em><a href="home.php?mod=space&do=notice&view=$key"><!--{eval echo lang('template', 'notice_'.$key)}--><!--{if $_G['member']['category_num'][$key]}-->($_G['member']['category_num'][$key])<!--{/if}--></a></li>
				<!--{/loop}-->
			</ul>
	    </div>
	</div>
	<div id="ct" class="cl">
		<div class="mn">
			<div>
				<div class="bz-ntsub-appl">
					<ul class="tb cl">
						<!--{if $_G['notice_structure'][$view] && ($view == 'mypost' || $view == 'interactive')}-->
							<!--{loop $_G['notice_structure'][$view] $subtype}-->
								<li$readtag[$subtype]><a href="home.php?mod=space&do=notice&view=$view&type=$subtype"><!--{eval echo lang('template', 'notice_'.$view.'_'.$subtype)}--><!--{if $_G['member']['newprompt_num'][$subtype]}-->($_G['member']['newprompt_num'][$subtype])<!--{/if}--></a></li>
							<!--{/loop}-->
						<!--{else}-->
							<li class="a"><a href="home.php?mod=space&do=notice&view=$view"><!--{eval echo lang('template', 'notice_'.$view)}--></a></li>
						<!--{/if}-->
					</ul>
				</div>
	
			<!--{if $view=='userapp'}-->
	
				<script type="text/javascript">
					function manyou_add_userapp(hash, url) {
						if(isUndefined(url)) {
							$(hash).innerHTML = "<tr><td colspan=\"2\">{lang successfully_ignored_information}</td></tr>";
						} else {
							$(hash).innerHTML = "<tr><td colspan=\"2\">{lang is_guide_you_in}</td></tr>";
						}
						var x = new Ajax();
						x.get('home.php?mod=misc&ac=ajax&op=deluserapp&hash='+hash, function(s){
							if(!isUndefined(url)) {
								location.href = url;
							}
						});
					}
				</script>
		
			<!--{else}-->
			
				<!--{if empty($list)}-->
				<div class="hm banzhuan-clear">
					<!--{if $new == 1}-->
						{lang no_new_notice}<a href="home.php?mod=space&do=notice&isread=1">{lang view_old_notice}</a>
					<!--{else}-->
						<div class="guide-no bzbt1 bzbb1">
							<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
							<p class="color-b">{lang no_notice}</p>
						</div>
					<!--{/if}-->
				</div>
				<!--{/if}-->
	
				<script type="text/javascript">
	
					function deleteQueryNotice(uid, type) {
						var dlObj = $(type + '_' + uid);
						if(dlObj != null) {
							var id = dlObj.getAttribute('notice');
							var x = new Ajax();
							x.get('home.php?mod=misc&ac=ajax&op=delnotice&inajax=1&id='+id, function(s){
								dlObj.parentNode.removeChild(dlObj);
							});
						}
					}
	
					function errorhandle_pokeignore(msg, values) {
						deleteQueryNotice(values['uid'], 'pokeQuery');
					}
				</script>
	
				<!--{if $list}-->
					<div class="bz-p10 banzhuan-clear bz-bg-fff bz-nt-list bzbt1 bzbb1">
						<ul>
							<!--{loop $list $key $value}-->
								
								<li class="cl {if $key==1}{/if}" $value[rowid] notice="$value[id]">
									<div class="z avt">
										<!--{if $value[authorid]}-->
										<a href="home.php?mod=space&uid=$value[authorid]"><!--{avatar($value[authorid],middle)}--></a>
										<!--{else}-->
										<img src="{IMGDIR}/systempm.png" alt="systempm" />
										<!--{/if}-->
									</div>
									<div class="z ntbody">
										<div style="margin-left: 10px;">
											<p class="color-c"><!--{date($value[dateline], 'u')}--><a href="home.php?mod=spacecp&ac=common&op=ignore&authorid=$value[authorid]&type=$value[type]&handlekey=addfriendhk_{$value[authorid]}" class="y iconfont icon-guanbi color-b dialog" style="font-size: 12px;"></a></p>
											<p class="a bz-mtb10">$value[note]</p>
											<!--{if $value[from_num]}-->
											<p class="color-b">{lang ignore_same_notice_message}</p>
											<!--{/if}-->
										</div>
									</div>
								</li>
								
							<!--{/loop}-->
						</ul>
					</div>
	
					<!--{if $view!='userapp' && $space[notifications]}-->
					<div><a href="home.php?mod=space&do=notice&ignore=all">{lang ignore_same_notice_message} <em>&rsaquo;</em></a></div>
					<!--{/if}-->
	
					<!--{if $multi}--><div class="pgs cl">$multi</div><!--{/if}-->
				<!--{/if}-->
	
			<!--{/if}-->
			
			</div>
		</div>
	</div>
</div>


<div id="mask" style="display:none;"></div>
<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<div class="banzhuan-bottom"></div>
</body>
</html>