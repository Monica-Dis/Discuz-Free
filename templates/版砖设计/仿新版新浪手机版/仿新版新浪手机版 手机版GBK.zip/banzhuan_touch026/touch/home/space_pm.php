<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{eval $_G['home_tpl_titles'] = array('{lang pm}');$msguser = $tousername;}-->
<!--{template common/header}-->

<!--{if in_array($filter, array('privatepm')) || in_array($_GET[subop], array('view')) || in_array($filter, array('announcepm'))}-->

	<!--{if in_array($filter, array('privatepm'))}-->
		<div class="bz-header">
			<div class="bz-header-left"><a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="iconfont icon-fanhui"></a></div>
			<h2>{lang mypm}</h2>
			<div class="bz-header-right">
				<a href="home.php?mod=spacecp&ac=pm"><em>{lang send_pm}</em></a>
			</div>
		</div>
		
		<div class="main banzhuan-clear">
			  <div class="bz-pm-appl">
					<ul class="cl">
						<li$actives[privatepm] $actives[newpm]><a href="home.php?mod=space&do=pm&filter=privatepm">{lang private_pm}</a></li>
						<li$actives[announcepm]><a href="home.php?mod=space&do=pm&filter=announcepm">{lang announce_pm}</a></li>
					</ul>
			  </div>
			  	
			  <!--{if $list}-->
			  <div class="pmbox bz-bg-fff">
				<ul class="bzbt1">
					<!--{loop $list $key $value}-->
					<li>
						<div class="avatar_img">
							<img style="height:30px;width:30px;" src="<!--{if $value[pmtype] == 2}-->{STATICURL}image/common/grouppm.png<!--{else}--><!--{avatar($value[touid] ? $value[touid] : ($value[lastauthorid] ? $value[lastauthorid] : $value[authorid]), middle, true)}--><!--{/if}-->" />
							<!--{if $value[new]}--><span class="num">$value[pmnum]</span><!--{/if}-->
						</div>
						<a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}">
							<div class="cl">
								<!--{if $value[touid]}-->
									<!--{if $value[msgfromid] == $_G[uid]}-->
										<span class="name">{$value[tousername]}</span>
									<!--{else}-->
										<span class="name">{$value[tousername]}</span>
									<!--{/if}-->
								<!--{elseif $value['pmtype'] == 2}-->
									<span class="name"><!--{if $value[subject]}-->$value[subject]<!--{/if}--></span>
								<!--{/if}-->
								<span class="grey y" style="font-size: 12px;"><!--{date($value[dateline], 'u')}--></span>
							</div>
							<div class="cl color-c">
								<span>
								<!--{if $value['pmtype'] == 2}-->
									&#32676;&#20027; : $value['firstauthor']<br>
								<!--{/if}-->
								<!--{if $value['pmtype'] == 2 && $value['lastauthor']}-->
									<div>......<br>$value['lastauthor'] : $value[message]</div>
								<!--{else}-->
									$value[message]
								<!--{/if}-->
								</span>
							</div>
						</a>
					</li>
					<!--{/loop}-->
				</ul>
			  </div>
			  <!--{else}-->
			  <div class="bz-p10 banzhuan-clear bz-bg-fff bz-mtb10 bzbt1 bzbb1">
				    <div class="guide-no">
						<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
						<p class="color-b">{lang no_corresponding_pm}</p>
				    </div>
			  </div>
			  <!--{/if}--> 
			  
		</div>
	
	<!--{elseif in_array($_GET[subop], array('view'))}--> 
		
		<!--{eval $nofooter = true;}-->
		<div class="bz-header">
			<div class="bz-header-left">
				<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
		    </div>
			<h2>{lang taking_with_user}</h2>
			<div class="bz-header-right">
				<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
			</div>
		</div>
		<div class="banzhuan-h10"></div>
		<div class="wp bz-bg-fff bz-p10 bzbt1 bzbb1">
				<div class="msgbox">
					<!--{if !$list}-->
						<div class="guide-no">
							<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
							<p class="color-b">{lang no_corresponding_pm}</p>
						</div>
					<!--{else}-->
						<!--{loop $list $key $value}-->
							<!--{subtemplate home/space_pm_node}-->
						<!--{/loop}-->
						<div class="banzhuan-clear">$multi</div>
					<!--{/if}-->
				</div>
		</div>
		
		<form id="pmform" class="pmform" name="pmform" method="post" action="home.php?mod=spacecp&ac=pm&op=send&pmid=$pmid&daterange=$daterange&pmsubmit=yes&mobile=2" >
		    <input type="hidden" name="formhash" value="{FORMHASH}" />
		    <!--{if !$touid}-->
		    <input type="hidden" name="plid" value="$plid" />
		    <!--{else}-->
		    <input type="hidden" name="touid" value="$touid" />
		    <!--{/if}-->
		    
		    <div class="bz-pm-fm">
		    	    <div id="phizbox" class="window" style="display:none;"></div>
				<div class="bz-pm-fm-return">
					<ul>	
						<li><a href="javascript:history.back();" class="iconfont icon-fanhui"></a></li>
						<!--<li><a href="javascript:;" onclick="Common.smilies('phizbox','replymessage');Common.Switch(this,'phizbox');"><i class="iconfont icon-biaoqing color-c"></i></a></li>-->
					</ul>
				</div>
				<div class="bz-pm-fm-reply">
					<input type="text" value="" class="pm" autocomplete="off" id="replymessage" name="message">
				</div>
				<div class="bz-pm-fm-button">
					<input type="button" name="pmsubmit" id="pmsubmit" class="formdialog pbutton y" value="{lang reply}" />
				</div>
		    </div>
		    
		</form>
		<script type="text/javascript" src="data/cache/common_smilies_var.js" charset="{CHARSET}"></script> 
		<script>
			function succeedhandle_pmform(locationhref, message, param) {
				$('#phizbox').html('');
				popup.close();
				if($('#replymessage').val()){
					$('#pmlist').append('<div class="self_msg item"><div class="avat y"><img src="<!--{avatar($_G[uid], small, true)}-->" /></div><div class="dialog_white y"><div class="dialog_c"><div class="dialog_t">'+$('#replymessage').val()+'</div></div><div class="time">&#21018;&#21018;</div></div></div>');
					$('#replymessage').val('');
					pmbottom();
				}
			}
			function getpmlist() {
				$.ajax({
					type:'GET',
					url:'home.php?mod=spacecp&ac=pm&op=showmsg&msgonly=1&touid=$touid&pmid=$pmid&inajax=1&daterange=$daterange',
					dataType:'xml'
				}).success(function(s) {
			        if($.trim(s.lastChild.firstChild.nodeValue)){
						$('#pmlist').html(s.lastChild.firstChild.nodeValue);
			            pmbottom();
					}
				});
			}
			function pmbottom() {
			    $('body').scrollTop($('#pmlist').height());
			}
			pmbottom();
			getpmlist();
			window.setInterval('getpmlist();', 2000);
		</script> 
	
	<!--{elseif in_array($filter, array('announcepm'))}-->
	
		<div class="bz-header">
			<div class="bz-header-left">
				<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="iconfont icon-fanhui"></a>
		    </div>
			<h2>{lang mypm}</h2>
			<div class="bz-header-right">
				<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
			</div>
		</div>
		
			<div class="bz-pm-appl banzhuan-clear">
				<ul class="cl">
					<li$actives[privatepm] $actives[newpm]><a href="home.php?mod=space&do=pm&filter=privatepm">{lang private_pm}</a></li>
					<li$actives[announcepm]><a href="home.php?mod=space&do=pm&filter=announcepm">{lang announce_pm}</a></li>
				</ul>
			</div>
		    <div class="bz-p10 banzhuan-clear bz-bg-fff bz-mtb10 bz-nt-list bzbt1 bzbb1">
				<!--{if $count || $grouppms}-->
						<div class="cl">
							<!--{if $grouppms}-->
								<!--{loop $grouppms $grouppm}-->
									<li id="gpmlist_$grouppm[id]" class="bbda cur1 cl{if !$gpmstatus[$grouppm[id]]} newpm{/if}">
										<div class="z avt">
											<a href="home.php?mod=space&do=pm&subop=viewg&pmid=$grouppm[id]">
											<!--{if $grouppm[author]}-->
												<img src="{IMGDIR}/annpm.png" alt="" />
											<!--{else}-->
												<img src="{IMGDIR}/systempm.png" alt="" />
											<!--{/if}-->
											</a>
										</div>
										<div class="z ntbody">
											<div style="margin-left: 10px;">
												<p class="color-c"><!--{date($grouppm[dateline], 'u')}--><!--{if $grouppm[author]}--><a href="home.php?mod=space&uid=$grouppm[authorid]">&nbsp;&nbsp;$grouppm[author]</a> {lang say} :<!--{/if}--></p>
												<p id="p_gpmid_$grouppm[id]" class="a bz-mtb10">$grouppm[message]<a href="home.php?mod=space&do=pm&subop=viewg&pmid=$grouppm[id]" id="gpmlist_$grouppm[id]_a" class="color-b" style="font-size: 12px;">{lang show}</a></p>
											</div>
										</div>
									</li>
								<!--{/loop}-->
							<!--{/if}-->
						</div>
			    <!--{else}-->
					<div class="guide-no">
						<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
						<p class="color-b">{lang no_corresponding_pm}</p>
					</div>
			    <!--{/if}-->
			</div>
	
	<!--{/if}--> 

<!--{else}-->

    <div class="bz-header">
		<div class="bz-header-left">
			<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
		</div>
	    <h2>{lang announce_pm}</h2>
		<div class="bz-header-right">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
		</div>
	</div>
    <!--{if $_GET['subop'] == 'viewg'}-->
		<!--{if $grouppm}-->
			<div id="pm_ul" class="bz-bg-fff bz-p10 bz-mtb10">
				<div class="ntbody">
					<p class="bz-mtb10">$grouppm[message]</p>
				</div>
				<div class="avt bz-mtb10">
					<p class="color-b bz-mtb10" style="font-size: 12px;line-height: 20px;">
						<!--{if $grouppm[author]}-->
							<img src="{IMGDIR}/annpm.png" alt="" />
						<!--{else}-->
							<img src="{IMGDIR}/systempm.png" alt="" />
						<!--{/if}-->
						{lang sendmultipmsystem}&nbsp;&nbsp;<span><!--{date($grouppm[dateline], 'u')}--></span>
						<!--<a href="home.php?mod=spacecp&ac=pm&op=delete&deletepm_gpmid[]=$grouppm[id]&pmid=$grouppm[id]&handlekey=gpmdeletehk_{$grouppm[id]}" id="a_gpmdelete_$grouppm[id]" class="y iconfont icon-guanbi color-b" style="font-size: 12px;"></a>-->
					</p>
				</div>
			</div>
		<!--{else}-->
			<div class="guide-no">
				<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
				<p class="color-b">{lang no_corresponding_pm}</p>
			</div>
		<!--{/if}-->
     <!--{/if}-->

<!--{/if}-->


<!--{hook/global_footer_mobile}-->
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
</body>
</html>

