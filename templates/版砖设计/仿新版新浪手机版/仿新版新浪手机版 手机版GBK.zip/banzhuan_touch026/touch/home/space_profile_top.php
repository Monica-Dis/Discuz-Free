<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<div class="user_avatar_bg">
	<div class="user_avatar_h bzmh">
		<div class="user_avatar_h_l">
			<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
		</div>
		<h2></h2>
		<div class="user_avatar_h_r">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
		</div>
	</div>
	<div class="banzhuan-top"></div>
	<div class="user_avatar hm">
		<div class="avatar_m">
			<span>
				<!--<a href="home.php?mod=spacecp&ac=avatar">-->
					<img src="<!--{avatar($space[uid], big, true)}-->" />
				<!--	</a>-->
			</span>
		</div>
		<div class="avatar_n">
			<p>$space[username]&nbsp;&nbsp;Lv.{$_G['cache']['usergroups'][$space[groupid]][stars]} {$_G['cache']['usergroups'][$space[groupid]][grouptitle]}<!--{if $space['uid'] == $_G['uid']}--><!--{if getuserprofile('gender') == 0}--><!--{elseif getuserprofile('gender') == 1}-->&nbsp;&#30007;<!--{elseif getuserprofile('gender') == 2}-->&nbsp;&#22899;<!--{/if}--><!--{/if}--></p>
		</div>
	</div>
</div>
<div class="bz-sp-memu">
	<ul class="cl">
		<li class="{if $do==profile}a{/if}"><a href="home.php?mod=space&uid={$space[uid]}&do=profile">&#20010;&#20154;&#36164;&#26009;</a></li>
		<li class="{if $do=='thread'}a{/if}"><a href="home.php?mod=space&uid={$space[uid]}&do=thread&view=me&from=space">&#20010;&#20154;&#20027;&#39064;</a></li>
	</ul>
</div>