<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->

<!--{if $operation == 'password'}-->
	
	<div class="bz-header">
		<div class="bz-header-left">
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1&mobile=2" class="iconfont icon-fanhui"><em>{lang return}</em></a>
		</div>
		<h2>{lang update_profile}</h2>
		<div class="bz-header-right">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
		</div>
	</div>
	
	<div class="main bz-cp-p">
		  <div class="postbar">
			  <form action="home.php?mod=spacecp&ac=profile" method="post" autocomplete="off" id="pwform" accept-charset="UTF-8">
				    <input type="hidden" value="{FORMHASH}" name="formhash" />
				    
				    <ul class="bz-cp-list bzbt1">
				    
					    <li class="flexbox bz-bg-fff bzbb1">
							<!--{if !$_G['member']['freeze']}-->
					            <!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->
					            		{lang old_password_comment}
					            <!--{elseif $wechatuser}-->
					            		{lang wechat_config_newpassword_comment}
					            <!--{else}-->
					            		{lang connect_config_newpassword_comment}
					            <!--{/if}-->
					        <!--{elseif $_G['member']['freeze'] == 1}-->
					            <strong class="xi1">{lang freeze_pw_tips}</strong>
					        <!--{elseif $_G['member']['freeze'] == 2}-->
					            <strong class="xi1">{lang freeze_email_tips}</strong>
					        <!--{/if}-->
						</li>
					    
					    <!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->
					    	<li class="flexbox bz-bg-fff bzbb1">
						    	<span class="name">{lang old_password}<bb class="rq">*</bb></span> 
						    	<span class="flex">
						    		<input type="password" name="oldpassword" id="oldpassword" class="px" />
						    	</span>
						</li>
					    <!--{/if}-->
					    
					    	<li class="flexbox bz-bg-fff bzbb1" id="th_newpassword">
						    	<span class="name">{lang new_password}</span> 
						    	<span class="flex html">
						    		<input type="password" name="newpassword" id="newpassword" class="px" placeholder="{lang memcp_profile_passwd_comment}"/>
						    	</span>
					    </li>
					    
					    	<li class="flexbox bz-bg-fff bzbb1" id="th_newpassword2">
						    	<span class="name">{lang registerpassword2}</span> 
						    	<span class="flex html">
						    		<input type="password" name="newpassword2" id="newpassword2"class="px" placeholder="{lang memcp_profile_passwd_comment}"/>
						    	</span>
					    </li>
					    
					    <li class="flexbox bz-bg-fff bzbb1">
						<!--{if $_G['setting']['regverify'] == 1 && (($_G['group']['grouptype'] == 'member' && $_G['adminid'] == 0) || $_G['groupid'] == 8) || $_G['member']['freeze']}--><p class="d">{lang memcp_profile_email_comment}</p><!--{/if}-->				
					    </li>
					    
					    <li class="flexbox bz-bg-fff bzbb1">
						    	<span class="name">{lang email}</span>
						    	<span class="flex html">
						    		<input type="text" name="emailnew" id="emailnew" value="$space[email]" class="px" />
						    	</span>
					    </li>
					    
					    <li class="flexbox bz-bg-fff bzbb1">
						<!--{if empty($space['newemail'])}-->{lang email_been_active}<!--{else}-->$acitvemessage<!--{/if}-->					
					    </li>
					    
					    <!--{if $_G['member']['freeze'] == 2}-->
					    <li class="flexbox bz-bg-fff bzbb1">
					    		<span class="name">{lang freeze_reason}</span>
						    	<span class="flex html">
						    		<textarea rows="3" cols="80" name="freezereson" class="pt">$space[freezereson]</textarea>
						    	</span>
					    </li>
					    <!--{/if}-->
					    
					    <li class="flexbox bz-bg-fff bzbb1">
					    		<span class="name">{lang security_question}</span> 
						    	<span class="flex html select">
						    		<select name="questionidnew" id="questionidnew">
									<option value="" selected>{lang memcp_profile_security_keep}</option>
									<option value="0">{lang security_question_0}</option>
									<option value="1">{lang security_question_1}</option>
									<option value="2">{lang security_question_2}</option>
									<option value="3">{lang security_question_3}</option>
									<option value="4">{lang security_question_4}</option>
									<option value="5">{lang security_question_5}</option>
									<option value="6">{lang security_question_6}</option>
									<option value="7">{lang security_question_7}</option>
								</select>
						    	</span>
					    </li>
					                            
					    <li class="flexbox bz-bg-fff bzbb1">
						    	<span class="name">{lang security_answer}</span> 
						    	<span class="flex html">
						    		<input type="text" name="answernew" id="answernew" class="px" placeholder="{lang memcp_profile_security_answer_comment}"/>
						    	</span>
					    </li>
					    
					    <!--{if $secqaacheck || $seccodecheck}-->
					    <div id="sec_code" class="codebar">
						      <div class="tip">
							        <h3 class="title bzbb1">&#35831;&#22635;&#20889;&#39564;&#35777;&#30721;</h3>
							        <!--{subtemplate common/seccheck}-->
							        <div class="o pns">
								          <button type="submit" name="passwordsubmit" class="pnc">{lang submit}</button>
								          <a class="pnc close" href="javascript:;" onclick="popup.close();">{lang cancel}</a>
							        </div>
						      </div>
					    </div>
					    <!--{/if}-->
				    
				    </ul>
				   
				    <div class="bz-mtb10 bz-p10">
						<input type="hidden" name="passwordsubmit" value="true" />
						<button type="button" name="pwdsubmit" value="true" class="post_btn_pn" onclick="Common.sec_code($('#pwform'),'sec_code')" /><strong>{lang save}</strong></button>
					</div>
			    
			  </form>
		  </div>
	</div>

<!--{else}-->

	<div class="bz-header">
		<div class="bz-header-left">
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1&mobile=2" class="iconfont icon-fanhui"><em>{lang return}</em></a>
		</div>
		<h2>{lang update_profile}</h2>
		<div class="bz-header-right">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
		</div>
	</div>
	<div class="bz-cp-pnav banzhuan-clear">
		<ul class="cl">
			<!--{loop $profilegroup $key $value}--> 
				<!--{if $value[available]}--> 
				<li $opactives[$key]><a href="home.php?mod=spacecp&ac=profile&op=$key">$value[title]</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		</ul>
	</div>
	
	<div class="main bz-cp-p">
		  <!--{if $vid}-->
		  <p class="bz-p10 bz-mtb10 {if !$showbtn}tbms_r{/if}"><!--{if $showbtn}-->{lang spacecp_profile_message1}<!--{else}-->{lang spacecp_profile_message2}<!--{/if}--></p>
		  <!--{/if}-->
		  <div class="banzhuan-clear"></div>
		  <div class="postbar">
			    <iframe id="frame_profile" name="frame_profile" style="display: none"></iframe>
			    <form action="{if $operation != 'plugin'}home.php?mod=spacecp&ac=profile&op=$operation{else}home.php?mod=spacecp&ac=plugin&op=profile&id=$_GET[id]{/if}" method="post" enctype="multipart/form-data" autocomplete="off"{if $operation != 'plugin'} target="frame_profile"{/if} accept-charset="UTF-8">
				      <input type="hidden" value="{FORMHASH}" name="formhash" />
				      <!--{if $_GET[vid]}-->
				      <input type="hidden" value="$_GET[vid]" name="vid" />
				      <!--{/if}-->
				      
				      <ul class="bz-cp-list bzbt1">
				      
					      <!--{loop $settings $key $value}--> 
						      <!--{if $value[available]}-->
							      
							      <!--{if $value[formtype] == 'textarea'}-->
								      <li class="flexbox bzbb1" id="th_$key">
											<span class="name">$value[title]<!--{if $value[required]}--><bb class="rq">*</bb><!--{/if}--></span>
									  </li>
								      <li class="flexbox bz-bg-fff bzbb1">
									        <span class="flex $value[formtype]">$htmls[$key]</span> 
									      	<span class="control">
									        		<input type="hidden" name="privacy[$key]" value="{if $vid}3{else}$privacy[$key]{/if}" />
									        </span>
								      </li>
							      
							      <!--{else}-->
							      
								      <li class="flexbox bz-bg-fff bzbb1" id="th_$key">
									      	<span class="name">$value[title]<!--{if $value[required]}--><bb class="rq">*</bb><!--{/if}--></span>
									        <span class="flex $value[formtype]">$htmls[$key]</span> 
									      	<span class="control">
									        		<input type="hidden" name="privacy[$key]" value="{if $vid}3{else}$privacy[$key]{/if}" />
									        </span>
								      </li>
								      
							      <!--{/if}-->
							      
						      <!--{/if}--> 
					      <!--{/loop}-->
				      
					      <!--{if $allowcstatus && in_array('customstatus', $allowitems)}-->
					      <li class="flexbox bzbb1" id="th_customstatus">
								<span class="name">{lang permission_basic_status}</span>
						  </li>
					      <li class="flexbox bz-bg-fff bzbb1">
								<span class="flex">
						      		<input type="text" value="$space[customstatus]" name="customstatus" id="customstatus" class="px" />
						      	</span>
						  </li>
					      <!--{/if}-->
				      
					      <!--{if $_G['group']['maxsigsize'] && in_array('sightml', $allowitems)}-->
					      <li class="flexbox bzbb1">
								<span class="name">{lang personal_signature}</span>
						  </li>
						  <li class="flexbox bz-bg-fff bzbb1" id="th_customstatus">
								<span class="flex">
					      			<textarea name="sightml" id="sightmlmessage" class="pt">$space[sightml]</textarea>
					      		</span>
						  </li>
					      <!--{/if}-->
				      
					      <!--{if in_array('timeoffset', $allowitems)}-->
					      
					      <!--{/if}-->
					      
					      <!--{if $operation == 'contact'}-->
					      
					      <!--{/if}-->
					      
					      <!--{if $operation == 'plugin'}-->
					          <!--{eval include(template($_GET['id']));}-->
					      <!--{/if}-->
					      
					 </ul>
					 
					 <!--{if $showbtn}-->
					 <div class="bz-mtb10 bz-p10">
						    <input type="hidden" name="profilesubmit" value="true" />
						    <button type="submit" name="profilesubmitbtn" id="profilesubmitbtn" value="true" class="post_btn_pn" />{lang save}</button>
					 </div>
					 <!--{/if}-->
				      
			    </form>
		  </div>
	</div>
	
<!--{/if}-->

<script type="text/javascript">
	function show_error(fieldid, extrainfo) {
		var elem = $('#th_'+fieldid);
		if(elem) {
			fieldname = elem.find('.name').text();
			Common.tips("{lang check_date_item}: " + fieldname);
			$('#'+fieldid).focus();
		}
	}
	function show_success(message) {
		message = message == '' ? '{lang update_date_success}' : message;
		Common.tips(message);
	}	
</script>


<!--{hook/global_footer_mobile}-->
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
</body>
</html>

