<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<li class="btw1 threadlist commentitem" id="cid$value[cid]"> 
  <div class="itemhead Elegant"> <a class="avatar" href="home.php?mod=space&uid=$value[authorid]&do=profile">{avatar($value[authorid],small)} </a>
    <div>
      <h3 class="user" style="padding-top: 0px;"> <a href="home.php?mod=space&uid=$value[authorid]" id="author_$value[cid]">{$value[author]}</a>
      <!--{if $value[authorid]!=$_G[uid] && ($value['idtype'] != 'uid' || $space[self]) && $value[author]}-->
      <a href="home.php?mod=spacecp&ac=comment&op=reply&cid=$value[cid]&feedid=$feedid&handlekey=replycommenthk_{$value[cid]}" class="dialog y"><i data-id="&#x76;"></i></a>
      <!--{/if}-->
      </h3>
      <p class="time"><!--{date($value[dateline])}--></p>
    </div>
    <div class="message"><!--{if $value[status] == 0 || $value[authorid] == $_G[uid] || $_G[adminid] == 1}-->$value[message]<!--{else}--> {lang moderate_not_validate} <!--{/if}--></div>
  </div>
</li>
