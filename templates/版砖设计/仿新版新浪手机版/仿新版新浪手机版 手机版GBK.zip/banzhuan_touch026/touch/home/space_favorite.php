<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->

<!--{if empty($diymode)}-->
	
	<div class="bz-header">
		<div class="bz-header-left">
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="iconfont icon-fanhui"></a>
		</div>
		<h2>{lang myfavorite}</h2>
		<div class="bz-header-right">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
		</div>
	</div>
	<div class="bz-fav-appl">
			<ul class="cl">
				<li$actives[all]><a href="home.php?mod=space&do=favorite&type=all">{lang all}</a></li>
				<li$actives[thread]><a href="home.php?mod=space&do=favorite&type=thread">{lang favorite_thread}</a></li>
				<li$actives[forum]><a href="home.php?mod=space&do=favorite&type=forum">{lang favorite_forum}</a></li>
				<li$actives[article]><a href="home.php?mod=space&do=favorite&type=article">{lang favorite_article}</a></li>
				<!--{if helper_access::check_module('group')}--><!--{/if}-->
				<!--{if helper_access::check_module('blog')}--><!--{/if}-->
				<!--{if helper_access::check_module('album')}--><!--{/if}-->
				<!--{hook/space_favorite_nav_extra}-->
			</ul>
	</div>
					
<!--{else}-->
			
	111
							
<!--{/if}-->

	<!--{if $list}-->
			<div class="cl bz-bg-fff">
				<form method="post" autocomplete="off" name="delform" id="delform" action="home.php?mod=spacecp&ac=favorite&op=delete&type=$_GET[type]&checkall=1" onsubmit="showDialog('{lang del_select_favorite_confirm}', 'confirm', '', '$(\'delform\').submit();'); return false;">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="delfavorite" value="true" />
					<ul id="favorite_ul" class="bzbt1 banzhuan-clear">
						<!--{loop $list $k $value}-->
						<li id="fav_$k" class="bbda bz-p10 bzbb1">
							<a class="y dialog" href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k" style="color: #D7D7D7;"><em class="iconfont icon-guanbi"></em></a>
							<!--{if $_GET['type'] == 'all'}--><!--{/if}-->
							<a href="$value[url]">$value[title]</a>
						</li>
						<!--{/loop}-->
					</ul>
				</form>
			</div>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
	<!--{else}-->
			<div class="guide-no bzbt1 bzbb1">
				<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
				<p class="color-b">{lang no_favorite_yet}</p>
			</div>
	<!--{/if}-->
     


<script type="text/javascript">
	function favorite_delete(favid) {
		var el = $('fav_' + favid);
		if(el) {
			el.style.display = "none";
		}
	}
	<!--{if $_GET[type] == "thread"}-->
	function collection_favorite() {
		var form = $('delform');
		var prefix = '^favorite';
		var tids = '';
		for(var i = 0; i < form.elements.length; i++) {
			var e = form.elements[i];		
			if(e.name.match(prefix) && e.checked) {
				tids += 'tids[]=' + e.getAttribute('vid') + '&';
			}
		}
		if(tids) {
			showWindow(null, 'forum.php?mod=collection&action=edit&op=addthread&' + tids);
		}
	}
	function update_collection() {}
	<!--{/if}-->
</script>

<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
</body>
</html>