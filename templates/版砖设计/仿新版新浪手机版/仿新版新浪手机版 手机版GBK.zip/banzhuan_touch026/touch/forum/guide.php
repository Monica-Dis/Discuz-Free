<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="boardnav">
	<div id="ct" class="wp cl{if $_G['forum']['allowside']} ct2{/if}"{if $leftside} style="margin-left:{$_G['leftsidewidth_mwidth']}px"{/if}>
		<div class="mn">
			<div class="bz-appl4">
				<ul id="thread_types" class="cl">
					<li $currentview['newthread']><a href="forum.php?mod=guide&view=newthread">{lang guide_newthread}</a></li>
					<li $currentview['hot']><a href="forum.php?mod=guide&view=hot">{lang guide_hot}</a></li>
					<li $currentview['digest']><a href="forum.php?mod=guide&view=digest">{lang guide_digest}</a></li>
					<li $currentview['new']><a href="forum.php?mod=guide&view=new">{lang guide_new}</a></li>
	                <!--{hook/guide_nav_extra}-->
				</ul>
			</div>
			<!--{hook/guide_top}-->
			<!--{if $view == 'index'}-->
			
				<!--{loop $data $key $list}-->
				<div class="bm bmw">
					<div class="bm_h">
						<a href="forum.php?mod=guide&view=$key" class="y xi2">{lang more} &raquo;</a>
						<h2>
							<!--{if $key == 'hot'}-->{lang guide_hot}<!--{elseif $key == 'digest'}-->{lang guide_digest}<!--{elseif $key == 'newthread'}-->{lang guide_newthread}<!--{elseif $key == 'new'}-->{lang guide_new}<!--{elseif $key == 'my'}-->{lang guide_my}<!--{/if}-->
						</h2>
					</div>
					 <div class="bm_c">
					 	<div class="xl xl2 cl">
					 		<!--{if $list['threadcount']}-->
					 			<!--{eval $i=0;}-->
					 			<!--{loop $list['threadlist'] $thread}-->
					 			<!--{eval $i++;$newtd=$i%2;}-->
					 			<li{if !$newtd} class="xl2_r"{/if}>
						 			<em>
							 			<!--{if $key == 'hot'}--><span class="xi1">$thread['heats']{lang guide_attend}</span><!--{/if}-->
							 			<!--{if $key == 'new'}-->$thread['lastpost']<!--{/if}-->
						 			</em>
						 			
						 			<i>&middot; <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight] target="_blank">$thread[subject]</a></i>&nbsp;<span class="xg1"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$list['forumnames'][$thread[fid]]['name']</a></span>
					 			</li>
					 			<!--{/loop}-->
					 		<!--{else}-->
									<div class="guide-no">
										<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
										<p class="color-b">{lang guide_nothreads}</p>
									</div>
					 		<!--{/if}-->
					 	</div>
					</div>
				</div>
				<!--{/loop}-->
				
			<!--{else}-->
			
				<!--{loop $data $key $list}-->
				<div id="threadlist" class="bz-p10 bz-bg-fff bzbt1 bzbb1">
					<div class="guide-tiezi">
						    <div id="forumnew" style="display:none"></div>
							<table cellspacing="0" cellpadding="0">
							    <!--{subtemplate forum/guide_list_row}-->
							</table>
					</div>
				</div>
				<!--{/loop}-->
				$multipage
			<!--{/if}-->
			
			<!--{hook/guide_bottom}-->
		</div>
	</div>
</div>
<!--{template common/footer}-->