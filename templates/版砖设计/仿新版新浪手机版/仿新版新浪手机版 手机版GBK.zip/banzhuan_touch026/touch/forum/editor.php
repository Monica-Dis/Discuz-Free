<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<style>
	.editor_menu { height: 40px; }
	.editor_menu a { float: left; position: relative; margin-top: 5px; margin-right: 8px; margin-bottom: 10px; margin-left: 8px; color: #888; }
	.editor_menu a:hover { color: #888; }
	.editor_menu i:before { font-size: 24px; line-height: 24px; }
	.editor_menu a.a:before { content: " "; position: absolute; text-align: center; left: 50%; top: 22px; margin-left: -7px; height: 0; width: 0; border: transparent 7px solid; border-width: 7px 7px; border-bottom-color: #dedede; }
	.editor_menu a.a:after { content: " "; position: absolute; text-align: center; left: 50%; top: 24px; margin-left: -6px; height: 0; width: 0; border: transparent 6px solid; border-width: 6px 6px; border-bottom-color: #FFF; }
	.editor_menu a.a { color: #333; font-weight: 700; }
	#box_smiley .smilie a { width: 12.5%; text-align: center; display: inline-block; }
	#box_smiley .smilie a span { padding: 5px; display: block; }
	#box_smiley .smilie a span img { max-width: 100%; }
	.smilies_nav { text-align: center; border-top: 1px solid #EBEBEB; height: 30px; padding-top: 10px; }
	.smilies_nav a { position: relative; display: inline-block; padding-right: 8px; padding-left: 8px; }
	.smilies_nav img { width: 20px; }
	.smilies_nav a.curr:before { content: " "; position: absolute; text-align: center; left: 50%; top: -11px; margin-left: -7px; height: 0; width: 0; border: transparent 7px solid; border-width: 7px 7px; border-top-color: #dedede; }
	.smilies_nav a.curr:after { content: " "; position: absolute; text-align: center; left: 50%; top: -11px; margin-left: -6px; height: 0; width: 0; border: transparent 6px solid; border-width: 6px 6px; border-top-color: #FFF; }
	.box_txt .txt { background-color: #E5E5E5; margin-right: 10px; height: 30px !important; text-indent: 5px; }
	.uptypenav { overflow: hidden; }
	.uptypenav a { border-radius: 2px; background-color: #E6E6E6; display: inline-block; padding-right: 3px; padding-left: 3px; margin-right: 2px; line-height:22px;}
	#upfile { position: relative; overflow: hidden; display: block; }
	#upfile .webuploader-pick {  width: 100%; }
	#upfile.webuploader-container div { width: 100% !important; position: relative !important; height: auto !important; }
	#upfile .webuploader-element-invisible { display: block;  }
	.webuploader-container .Progress { background-color: #CCC; height: 3px; }
	.webuploader-container .Progress b { height: 3px; width: 0px; display: block; }
	#container_html { outline:none; }
</style>

<div class="html_editor bz-bg-fff">
		  <div class="editor_menu bzbb1">
		    <!--{if in_array('smilies',$seditor[1]) || in_array('smilie',$seditor[1])}--><a data-id="smiley"><i class="bigs iconfont icon-biaoqing"></i></a><!--{/if}-->
		    <!--{if in_array('img',$seditor[1])}--><a data-id="image"><i class="bigs iconfont icon-camera"></i></a><!--{/if}-->
		    <!--{if in_array('video',$seditor[1])}--><!--<a data-id="video"><i class="bigs iconfont icon-video"></i></a>--><!--{/if}-->
		    <!--{if in_array('annex',$seditor[1])}--><!--<a data-id="annex"><i class="bigs iconfont icon-shezhi2"></i></a>--><!--{/if}-->
		    <!--{if in_array('link',$seditor[1])}--><!--<a data-id="link"><i class="bigs iconfont icon-shezhi2"></i></a>--><!--{/if}-->
		  </div>
		  <div class="banzhuan-clear">
			    <div id="box_smiley" class="bzbb1 bz-p10" style="display:none;"></div>
			    <div id="box_image" class="bzbb1 bz-p10 ebox imagebox" style="display:none;">
				      <ul id="imglist" class="bz-bg-fff">
					        <!--{if !empty($imgattachs['used'])}--><!--{eval $imagelist = $imgattachs['used'];}-->
					        <!--{if $imagelist}-->
					        <!--{loop $imagelist $image}-->
					        <li><span aid="$image[aid]" class="del"><a href="javascript:;"><img src="static/image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="height:44px;width:50px;" src="{echo getforumimg($image[aid], 1, 300, 300, 'fixnone')}"></span><input type="hidden" name="attachnew[{$image[aid]}][description]"></li>
					        <!--{/loop}-->
					        <!--{/if}-->
					        <!--{/if}-->
					        <li id="filedata"><a><i class="bigs iconfont icon-jiahao1"></i></a></li>
				      </ul>
			    </div>
			    <div id="box_video" class="bzbb1 bz-p10 box_txt" style="display:none;">
				      <div class="uptypenav typelist">
				        		<a class="b" onclick="Common.TabSwitch(this,'videolink');">&#36828;&#31243;&#22320;&#22336;</a>
				        		<!--<a onclick="Common.TabSwitch(this,'videoup');">&#26412;&#22320;&#19978;&#20256;</a>-->
				      </div>
				      <div class="bz-mtb10">
					        <dl class="flexbox" id="videolink">
					        		<input class="txt" id="videourl" type="text" style="float:left;" placeholder="&#25903;&#25345;&#25991;&#20214;&#31867;&#22411;: mp3,mp4,ogg"/><input class="button" type="button" value="{lang confirms}" onclick="addvideourl();" />
					        </dl>
					        <dl id="videoup" style="display:none;">
					          	<div id="upfile"></div>
					        </dl>
				      </div>
			    </div>
			    <div id="box_annex" class="bzbb1 bz-p10" style="display:none;"></div>
			    <div id="box_link" class="bzbb1 bz-p10 box_txt" style="display:none;">
		    </div>
	  </div>
</div>

<!--{if in_array('smilies',$seditor[1])}--> 
<script type="text/javascript" src="data/cache/common_smilies_var.js" charset="{CHARSET}"></script> 
<!--{/if}--> 

<script type="text/javascript">
	$('.editor_menu > a').on('click',function(){
		$(this).addClass("a").siblings().removeClass("a");
		var name = $(this).attr('data-id');

		if(name == 'smiley'){
		<!--{if in_array('smilie',$seditor[1])}-->
			var mhtml = '<div class="smilie bz-bg-fff">';
			for(i=1; i<31; i++) {
				mhtml += '<a data-id="[em:'+i+':]" onclick="Common.setsmilie(this,\'{$seditor[0]}\');"><img src="' + STATICURL + 'image/smiley/comcom/'+i+'.gif" /></a>';
			}
			mhtml += '</div>';
			$('#box_smiley').html(mhtml);
		<!--{elseif in_array('smilies',$seditor[1])}-->
		    Common.smilies('box_smiley','{$seditor[0]}');
		<!--{/if}-->
		}
		$('#box_'+name).slideDown().siblings().slideUp();
	});

	<!--{if in_array('img',$seditor[1])}-->
	var uploader = WebUploader.create({
		server: 'misc.php?mod=swfupload&operation=upload&action=swfupload&fid=$_G[fid]&inajax=yes&infloat=yes&simple=2',
		formData:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->",type:'image'},
		fileVal: 'Filedata',
		pick: '#filedata',
		auto: true,
		accept: {
			title: 'Image File',
			extensions: 'gif,jpg,jpeg,bmp,png',
			mimeTypes:'image/*,text/plain,application/msword,application/octet-stream,application/vnd.ms-excel,application/x-shockwave-flash'
		}
	});
	uploader.on('fileQueued', function(file) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		$(bar).prepend('<li id="file_'+file.id+'"><img src="template/banzhuan_touch026/touch/banzhuan/images/loading.gif" style="height:44px;width:50px;"><i class="Progress">&#21387;&#32553;&#20013;</i></li>');
	});
	
	uploader.on('uploadProgress', function( file, percentage ) {
		$('#file_'+file.id+' i').html(Math.round(percentage * 100) + '%');
	});
	
	uploader.on('uploadBeforeSend', function( block, data, headers) {
		data.type = 'image';
	}); 
	
	uploader.on('uploadSuccess', function(file, data) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		if(data._raw) {
			var dataarr = data._raw.split('|');
			if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
				$('#file_'+file.id).html('<span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="'+STATICURL+'image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="width:50px;height:44px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" />');
			}
		}
	});
	<!--{/if}-->
	
	
	
	
	$(document).on('click', '.del', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&tid=$_GET[tid]&pid=$_GET[pid]&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});
	
	
	
	
	
	<!--{if in_array('video',$seditor[1])}-->
	var uphtml,upbar;
	var uploader_file = WebUploader.create({
		server: 'misc.php?mod=swfupload&action=swfupload&operation=upload&fid=$_GET[fid]',
		formData: {uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
		fileVal: 'Filedata',
		pick: '#upfile',
		auto: true,
		accept: {
			title: 'All Files',
			extensions: 'mp3,mp4,ogg,avi',
			mimeTypes:'video/*,text/plain,application/msword,application/octet-stream,application/vnd.ms-excel,application/x-shockwave-flash'
		}
	});
	uploader_file.on('fileQueued', function(file) {
		upbar = $('#rt_'+file.source.ruid).parent();
	    uphtml = upbar.html();
		upbar.html('<div><p class="name line">'+file.name+'</p><dl class="Progress"><b class="icon"></b></dl><p style="overflow: hidden;"><span class="z FileSize">0</span><span class="y ProgressText">0%</span></p></div>');
	});
	uploader_file.on('uploadProgress', function( file, percentage ) {
		upbar.find('.Progress b').css({width:Math.round(percentage * 100) + '%'});
	    upbar.find('.ProgressText').html(Math.round(percentage * 100) + '%');
		upbar.find('.FileSize').html(((file.size/1024)/1024).toFixed(2)+' MB');
	});
	uploader_file.on('uploadSuccess', function(file, data) {
		//console.log('Percentage:', data);
		aid = parseInt(data);
		if(aid>0){
			$('#{$seditor[0]}').val($('#{$seditor[0]}').val()+'[media=x]attach://'+aid+'.'+file.ext+'[/media]');
			$("#$seditor[0]").scrollTop($("#$seditor[0]")[0].scrollHeight);
		}else{
			alert('\u4e0a\u4f20\u5931\u8d25: '+data);
		}
		upbar.html(uphtml);
		uploader_file.addButton({id:'#upfile'});
	});
	uploader_file.on('uploadError', function( file ) {
		alert('\u8bf7\u5c06\u5fae\u4fe1\u66f4\u65b0\u5230\u6700\u65b0\u7248\u672c\uff0c\u6216\u8005\u4f7f\u7528\u624b\u673a\u81ea\u5e26\u6d4f\u89c8\u5668\u4e0a\u4f20');
	    console.log('Percentage:', file);
	});
	function addvideourl(){
		var msg = $('#videourl').val();
		if(msg){
		    $('#{$seditor[0]}').val($('#{$seditor[0]}').val()+'[media=x]'+msg+'[/media]');
		    $("#$seditor[0]").scrollTop($("#$seditor[0]")[0].scrollHeight);
			$('#videourl').val('');
		}
	}
	<!--{/if}-->
	
	
	
</script>