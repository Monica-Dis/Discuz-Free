<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<!--{eval $adveditor = $isfirstpost && $special && ($_GET['action'] == 'newthread' || $_GET['action'] == 'reply' && !empty($_GET['addtrade']) || $_GET['action'] == 'edit' );}-->

<!--{if !$_GET['inajax']}-->
<script type="text/javascript" src="template/banzhuan_touch026/touch/banzhuan/webuploader.min.js" charset="{CHARSET}"></script>
<!--{/if}-->

<form method="post" id="postform" 
	{if $_GET[action] == 'newthread'}action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes&mobile=2"
	{elseif $_GET[action] == 'reply'}action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes&mobile=2"
	{elseif $_GET[action] == 'edit'}action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes&mobile=2" $enctype
	{/if}>

	<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
	<input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}" />
	<!--{if !empty($_GET['modthreadkey'])}-->
	<input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" />
	<!--{/if}--> 
	<!--{if $_GET[action] == 'reply'}-->
	<input type="hidden" name="noticeauthor" value="$noticeauthor" />
	<input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
	<input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
	<!--{if $reppid}-->
	<input type="hidden" name="reppid" value="$reppid" />
	<!--{/if}--> 
	<!--{if $_GET[reppost]}-->
	<input type="hidden" name="reppost" value="$_GET[reppost]" />
	<!--{elseif $_GET[repquote]}-->
	<input type="hidden" name="reppost" value="$_GET[repquote]" />
	<!--{/if}--> 
	<!--{/if}--> 
	<!--{if $_GET[action] == 'edit'}-->
	<input type="hidden" name="fid" id="fid" value="$_G[fid]" />
	<input type="hidden" name="tid" value="$_G[tid]" />
	<input type="hidden" name="pid" value="$pid" />
	<input type="hidden" name="page" value="$_GET[page]" />
	<!--{/if}--> 
	
	<!--{if $special}-->
	<input type="hidden" name="special" value="$special" />
	<!--{/if}--> 
	<!--{if $specialextra}-->
	<input type="hidden" name="specialextra" value="$specialextra" />
	<!--{/if}-->
	<input type="hidden" name="{if $_GET[action] == 'newthread'}topicsubmit{elseif $_GET[action] == 'reply'}replysubmit{elseif $_GET[action] == 'edit'}editsubmit{/if}" value="yes">

	<div id="posteditor" class="main postbar post">
		
		
	<!--{if $_GET[action] == 'reply'}--> 
	
	     <div class="bz-header">
			  <div class="bz-header-left">
				  <a href="javascript:history.back();" class="iconfont icon-fanhui"><em>{lang return}</em></a>
			  </div>
			  <h2><!--{if !$_GET['inajax']}-->{lang reply}: $thread['subject']<!--{else}-->{if $quotemessage}$quotemessage{else}RE: $thread['subject']{/if}<!--{/if}--></h2>
			  <div class="bz-header-right">
				  <a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
			  </div>
		  </div>
		  <div class="banzhuan-clear"></div>
		  <div class="bz-reply-editor">
			  <h3 class="bz-p10 flexbox bz-bg-fff">
				  	<span class="flex line">{if $quotemessage}$quotemessage{else}RE: $thread['subject']{/if}</span>
				  	<!--{if $_GET['inajax']}-->
				  	<a class="y" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$reppid"><i class="iconfont icon-icon09"></i></a>
				  	<!--{/if}-->
			  </h3>
			  <!--{if !$isfirstpost && $thread[special] == 5 && empty($firststand)}-->
			  <div class="pbt bz-bg-fff bzbt1 postbar p10">
				    <div class="ftid sslt html select bzpostlist">
					      <select id="stand" name="stand">
					          <option value="">{lang debate_viewpoint}</option>
					          <option value="0">{lang debate_neutral}</option>
					          <option value="1"{if $stand == 1} selected{/if}>{lang debate_square}</option>
					          <option value="2"{if $stand == 2} selected{/if}>{lang debate_opponent}</option>
					      </select>
				    </div>
			  </div>
			  <!--{/if}-->
		  
			  <div class="bzbt1">
				    <ul class="bzpostlist">
					      <li class="bz-bg-fff bz-p10">
					          <textarea class="pt" id="needmessage" id="{$editorid}_textarea" name="$editor[textarea]"  placeholder="({lang thread_content})" style="height:70px;width:100%;border:0">$postinfo[message]</textarea>
					      </li>
					      <!--{eval $seditor = array('needmessage', array('video', 'img', 'smilies'));}-->
				          <!--{template forum/editor}-->
				    </ul>
				    <!--{template forum/post_editor_attribute}-->
				    
				    <!--{if !$_GET['inajax']}-->
				    <!--{else}-->
					    <!--{eval $nofooter = true;}-->
					    <div class="o pns">
						      <input type="submit" value="{lang reply}" class="pnc">
						      <a class="pnc close" href="javascript:;" onclick="popup.close();">{lang cancel}</a>
					    </div>
				    <!--{/if}-->
			  </div>
		  
		  </div>
	  
	  
	<!--{else}-->
	
		
		  <div class="bz-header">
			  <div class="bz-header-left">
				  <a href="javascript:history.back();" class="iconfont icon-fanhui"><em>{lang return}</em></a>
			  </div>
			  <h2><!--{if $_GET[action] == 'edit'}-->{lang edit}<!--{else}-->{lang send_threads}<!--{/if}--></h2>
			  <div class="bz-header-right">
				  <a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
			  </div>
		  </div>
		  <div class="banzhuan-clear"></div>
		  <div class="bz-post-menu">
			  <ul class="cl">
					<!--{if $savecount}-->
						<li class="y">
							<a id="draftlist" href="javascript:;" class="xi2" onmouseover="showMenu({'ctrlid':'draftlist','ctrlclass':'a','duration':2,'pos':'34'})">{lang draftbox}(<strong>$savecount</strong>)</a>
						</li>
					<!--{/if}-->
					<!--{if !$_G['forum']['threadsorts']['required'] && !$_G['forum']['allowspecialonly']}-->
						<li{if !$_GET['special'] && !$_GET['sortid']} class="a"{/if}>
							<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang post_newthread}</a>
					    </li>
					<!--{/if}-->
					<!--{loop $_G['forum']['threadsorts'][types] $tsortid $name}-->
						<li{if $sortid == $tsortid} class="a"{/if}>
							<a href="forum.php?mod=post&action=newthread&sortid=$tsortid&fid=$_G[fid]"><!--{echo strip_tags($name);}--></a>
						</li>
					<!--{/loop}-->
					<!--{if $_G['group']['allowpostpoll']}--><li$postspecialcheck[1]><a href="forum.php?mod=post&action=newthread&special=1&fid=$_G[fid]">{lang post_newthreadpoll}</a></li><!--{/if}-->
					<!--{if $_G['group']['allowpostreward']}--><li$postspecialcheck[3]><a href="forum.php?mod=post&action=newthread&special=3&fid=$_G[fid]">{lang post_newthreadreward}</a></li><!--{/if}-->
					<!--{if $_G['group']['allowpostdebate']}--><li$postspecialcheck[5]><a href="forum.php?mod=post&action=newthread&special=5&fid=$_G[fid]">{lang post_newthreaddebate}</a></li><!--{/if}-->
					<!--{if $_G['group']['allowpostactivity']}--><li$postspecialcheck[4]><a href="forum.php?mod=post&action=newthread&special=4&fid=$_G[fid]">{lang post_newthreadactivity}</a></li><!--{/if}-->
					<!--{if $_G['group']['allowposttrade']}--><li$postspecialcheck[2]><a href="forum.php?mod=post&action=newthread&special=2&fid=$_G[fid]">{lang post_newthreadtrade}</a></li><!--{/if}-->
					<!--{if $_G['setting']['threadplugins']}-->
						<!--{loop $_G['forum']['threadplugin'] $tpid}-->
							<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
								<li{if $specialextra==$tpid} class="a"{/if}><a href="forum.php?mod=post&action=newthread&specialextra=$tpid&fid=$_G[fid]">{$_G[setting][threadplugins][$tpid][name]}</a></li>
							<!--{/if}-->
						<!--{/loop}-->
					<!--{/if}-->
			  </ul>
		  </div>
		  <div class="banzhuan-h10 banzhuan-clear"></div>
		  
		  <div class="bzbt1">
			    <ul class="bzpostlist">
				      <li class="flexbox bz-bg-fff"> 
					        <span class="name">{lang title}</span>
					        <span class="html flex">
					        		<input type="text" class="px" id="needsubject" autocomplete="off" value="$postinfo[subject]" name="subject" placeholder="(&#24517;&#22635;)">
					        </span> 
				      </li>
				      
				      <!--{if $isfirstpost && !empty($_G['forum'][threadtypes][types])}-->
				      <li class="flexbox bz-bg-fff bzbt1">
					      	<span class="name">{lang types}</span>
					      	<span class="html flex iocn">
					        <select id="typeid" name="typeid" class="sort_sel">
						          <option value="0" selected="selected">{lang select_thread_catgory}</option>
						          <!--{loop $_G['forum'][threadtypes][types] $typeid $name}--> 
							          <!--{if empty($_G['forum']['threadtypes']['moderators'][$typeid]) || $_G['forum']['ismoderator']}-->
							          <option value="$typeid"{if $thread['typeid'] == $typeid || $_GET['typeid'] == $typeid} selected="selected"{/if}>
							          <!--{echo strip_tags($name);}-->
							          </option>
							          <!--{/if}--> 
						          <!--{/loop}-->
					        </select>
				        </span>
				      </li>
				      <!--{/if}-->
			      
				      <!--{if $showthreadsorts}-->
				        		<!--{template forum/post_sortoption}-->
				      <!--{elseif $adveditor}-->
					        <!--{if $special == 1}-->
					          		<!--{template forum/post_poll}-->
					        <!--{elseif $special == 2 && ($_GET[action] != 'edit' || ($_GET[action] == 'edit' && ($thread['authorid'] == $_G['uid'] && $_G['group']['allowposttrade'] || $_G['group']['allowedittrade'])))}-->
					        			<!--{template forum/post_trade}-->
					        <!--{elseif $special == 3}-->
					          		<!--{template forum/post_reward}-->
					        <!--{elseif $special == 4}-->
					         		 <!--{template forum/post_activity}-->
					        <!--{elseif $special == 5}-->
					         		 <!--{template forum/post_debate}-->
					        <!--{elseif $specialextra}-->
					          		<div class="specialpost s_clear">$threadplughtml</div>
				            <!--{/if}-->
				      <!--{/if}-->
				      
				      <li class="flexbox bzbt1"><span class="name">{lang thread_content}</span></li>
				      <li class="bzbt1 bz-bg-fff" style="padding-bottom: 0;">
				        		<textarea class="pt" id="needmessage" id="{$editorid}_textarea" name="$editor[textarea]" placeholder="(&#24517;&#22635;)" style="height: 100px; width: 100%; border: 0;">$postinfo[message]</textarea>
				      </li>
				      <!--{eval $seditor = array('needmessage', array('video', 'img', 'smilies'));}-->
				      <!--{template forum/editor}-->
			    </ul>
			    <!--{template forum/post_editor_attribute}-->
		  </div>
		  <!--{hook/post_bottom_mobile}--> 
		  
	<!--{/if}-->
	
	      <!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
	      <div class="bz-p10 bz-bg-fff bzbt1 bzbb1 bz-mt10 banzhuan-clear">
		      <!--{subtemplate common/seccheck}-->
		  </div>
		  <!--{/if}-->
	
		  <!--{if !$_GET['inajax']}-->
		  <div class="bz-mtb10 bz-p10">
		    		<button id="postsubmit" class="post_btn_pn">
		    			<span><!--{if $_GET[action] == 'newthread'}-->{lang send_thread}<!--{elseif $_GET[action] == 'reply'}-->{lang join_thread}<!--{elseif $_GET[action] == 'edit'}-->{lang edit_save}<!--{/if}--></span>
		    		</button>
		  </div>
		  <!--{/if}-->
	  
	  
	</div>


</form>


<!--{if $_GET['inajax']}-->

	<script>
		/*{echo rand();}*/
		var uploader = WebUploader.create({
			server: 'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
			formData: {uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
			fileVal: 'Filedata',
			pick: '#filedata2',
			auto: true,
			accept: {
				title: 'Files',
				extensions: 'gif,jpg,jpeg,bmp,png',
				mimeTypes:'image/*,text/plain,application/msword,application/octet-stream,application/vnd.ms-excel,application/x-shockwave-flash'
			}
		});
		
		uploader.on('fileQueued', function(file) {
			var bar = $('#rt_'+file.source.ruid).parent().parent();
		    $(bar).prepend('<li id="file_'+file.id+'"><img src="template/banzhuan_touch026/touch/banzhuan/images/loading.gif" style="height:44px;width:50px;"><i class="Progress">&#21387;&#32553;&#20013;</i></li>');
		});
		
		uploader.on('uploadProgress', function( file, percentage ) {
			$('#file_'+file.id+' i').html(Math.round(percentage * 100) + '%');
		});
		
		uploader.on('uploadSuccess', function(file, data) {
			var bar = $('#rt_'+file.source.ruid).parent().parent();
		    if(data._raw) {
				var dataarr = data._raw.split('|');
				if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
					$('#file_'+file.id).html('<span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="'+STATICURL+'image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="width:50px;height:44px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" />');
				}
			}
		});
		
		uploader.on('uploadError', function( file ) {
		    Common.tips('\u4e0a\u4f20\u5931\u8d25');
		});
	</script>

<!--{/if}-->



<script type="text/javascript">
/*{echo rand();}*/
    var JSLOADED  = [];
	var hide = 0;
	var form = $('#postform');
	
	<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
	geo.getcurrentposition();
	<!--{/if}-->
	
	$('#postform').on('submit', function() {
		
		//validate();
		
		var text = '';
		var hidetext = $('#hide_text').val();
		if(hidetext && !hide){
			var hidetype = $('#hide_type').val();
			var hideday = $('#hide_day').val();
			if(hidetype == 1){
				if(hideday){
					text = '[hide=d'+hideday+']'+hidetext+'[/hide]';
				}else{
					text = '[hide]'+hidetext+'[/hide]';
				}
			}else{
				var hidecredits = $('#hide_credits').val();
				if(hideday){
					text = '[hide=d'+hideday+','+hidecredits+']'+hidetext+'[/hide]';
				}else{
					text = '[hide='+hidecredits+']'+hidetext+'[/hide]';
				}
			}
			var needmessage = $('#needmessage').val();
			$('#needmessage').val(needmessage+'\n'+text);
			hide = 1;
		}
		
	    <!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
			<!--{if $_GET['inajax']}-->
		    Common.close('posteditor');
			<!--{/if}-->
        <!--{/if}-->
		
		var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}

		obj.attr('disable', 'true').removeClass('btn_pn_blue').addClass('btn_pn_grey');
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

		var postlocation = '';
		if(geo.errmsg === '' && geo.loc) {
			postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
		}

		$.ajax({
			type:'POST',
			url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
		.success(function(s) {
			$('.sec_code').find('input[name="seccodeverify"]').attr('value', '');
			popup.open(s.lastChild.firstChild.nodeValue);
			obj.attr('disable', 'false').removeClass('btn_pn_grey').addClass('btn_pn_blue');
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
			obj.attr('disable', 'false').removeClass('btn_pn_grey').addClass('btn_pn_blue');
		});
		return false;
		
	});
	
    function succeedhandle_postform(locationhref, message, param) {
		$('.sec_code').find('input[name="seccodeverify"]').attr('value', '');
		var pid = param['pid'];
		var tid = param['tid'];
		if(pid) {
			$.ajax({
				type:'POST',
				url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid + '&mobile=2',
				dataType:'xml'
			})
			.success(function(s) {
				$('#threadlist').append(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = 'forum.php?mod=viewthread&tid=' + tid;
				popup.close();
			});
		} else {
			if(!message) {
				message = '{lang postreplyneedmod}';
			}
			popup.open(message, 'alert');
		}
		$('#fastpostmessage').attr('value', '');
		if(param['sechash']) {
			$('.seccodeimg').click();
		}
	}

	function errorhandle_postform(message, param) {
		$('.sec_code').find('input[name="seccodeverify"]').attr('value', '');
		popup.open(message, 'alert');
	}
	
</script>


<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<div id="mask" style="display:none;"></div>
<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<div class="banzhuan-bottom"></div>
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->
