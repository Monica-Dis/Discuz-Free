<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<div class="exfm">
	
<!--{if $_GET[action] == 'newthread'}-->

	  <div class="banzhuan-h10 bzbt1"></div>
	  <li class="flexbox bzbt1 align_center bz-bg-fff">
		  	<span class="name">{lang reward_price}</span>
		  	<span class="html flex">
		  		<dl class="flexbox">
		  			<input type="text" name="rewardprice" id="rewardprice" class="px pxs flex" size="6" style="text-indent: 0px;text-align: center;" onkeyup="getrealprice(this.value)" value="{$_G['group']['minrewardprice']}" />
		  			<dd>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}, {lang reward_tax_after} <i id="realprice">0</i> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</dd>
		  		</dl>
		  	</span>
	  </li>
	  <li class="flexbox bzbt1 align_center">
	    		{lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->, {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
	  </li>
	  
<!--{elseif $_GET[action] == 'edit'}-->

	  <!--{if $isorigauthor}-->
		    <!--{if $thread['price'] > 0}-->
			      <div class="banzhuan-h10 bzbt1"></div>
			      <li class="flexbox bzbt1 align_center bz-bg-fff">
			      	<span class="name">{lang reward_price}</span>
			      	<span class="html flex">
			      		<dl class="flexbox">
			      			<input type="text" name="rewardprice" id="rewardprice" class="px pxs flex" size="6" style="text-indent: 0px;text-align: center;" onkeyup="getrealprice(this.value)" value="$rewardprice" /><dd>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
							, {lang reward_tax_add} <i id="realprice">0</i> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</dd>
			      		</dl>
			      	</span>
			      </li>
			      <li class="flexbox bzbt1 align_center">
			    			{lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->, {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
			      </li>
		    <!--{else}-->
		          <li class="flexbox bzbt1 align_center">{lang post_reward_resolved}<input type="hidden" name="rewardprice" value="$rewardprice" tabindex="1" /></li>
		    <!--{/if}-->
	  <!--{else}-->   
		    <li class="flexbox bzbt1 align_center">     
			    <!--{if $thread['price'] > 0}-->
			        {lang reward_price}: $rewardprice {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
			    <!--{else}-->
			        {lang post_reward_resolved}
			    <!--{/if}-->
		    </li>
	  <!--{/if}-->
	  
<!--{/if}-->


<!--{if $_G['setting']['rewardexpiration'] > 0}-->
	  <li class="flexbox align_center" style="padding-top:0px;">$_G['setting']['rewardexpiration'] {lang post_reward_message}</li>
	  <div class="banzhuan-h10 bzbt1 bz-bg-fff"></div>
<!--{/if}-->

</div>


<script type="text/javascript" reload="1">
	function getrealprice(price){
		if(!price.search(/^\d+$/) ) {
			n = Math.ceil(parseInt(price) + price * $_G['setting']['creditstax']);
			if(price > 32767) {
				document.getElementById('realprice').innerHTML = '<b>{lang reward_price_overflow}</b>';
			}<!--{if $_GET[action] == 'edit'}-->	else if(price < $rewardprice) {
				document.getElementById('realprice').innerHTML = '<b>{lang reward_cant_fall}</b>';
			}<!--{/if}--> else if(price < $_G['group']['minrewardprice'] || ($_G['group']['maxrewardprice'] > 0 && price > $_G['group']['maxrewardprice'])) {
				document.getElementById('realprice').innerHTML = '<b>{lang reward_price_bound}</b>';
			} else {
				document.getElementById('realprice').innerHTML = n;
			}
		}else{
			document.getElementById('realprice').innerHTML = '<b>{lang input_invalid}</b>';
		}
	}
	if(document.getElementById('rewardprice')) {
		getrealprice($('rewardprice').value)
	}
	EXTRAFUNC['validator']['special'] = 'validateextra';
	function validateextra() {
		if(document.getElementById('postform').rewardprice && document.getElementById('postform').rewardprice.value == '') {
			popup.open('{lang post_reward_error_message}', 'alert');
			return false;
		}
		return true;
	}
</script>