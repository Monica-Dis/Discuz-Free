<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{if $isfirstpost && $sortid}-->
<script type="text/javascript">
	var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
</script> 
<script type="text/javascript" src="template/banzhuan_touch026/touch/banzhuan/threadsort.js?{VERHASH}"></script>
<!--{/if}-->
<div class="exfm">
  <input type="hidden" name="selectsortid" size="45" value="$_G['forum_selectsortid']" />
  <input type="hidden" name="sortid" value="$sortid" />
  <!--{if $_G['forum_typetemplate']}--> 
  $_G[forum_typetemplate] 
  <!--{else}--> 
  <!--{loop $_G['forum_optionlist'] $optionid $option}--> 
  <!--{eval $desc='';}--> 
  <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}--> 
  <!--{block desc}--> 
  <!--{if $option['maxnum']}--> 
  {lang maxnum} $option[maxnum] 
  <!--{/if}--> 
  <!--{if $option['minnum']}--> 
  {lang minnum} $option[minnum] 
  <!--{/if}--> 
  <!--{if $option['maxlength']}--> 
  {lang maxlength} $option[maxlength] 
  <!--{/if}--> 
  <!--{if $option['unchangeable']}--> 
  {lang unchangeable} 
  <!--{/if}--> 
  <!--{if $option[description]}--> 
  $option[description] 
  <!--{/if}--> 
  <!--{/block}--> 
  <!--{/if}--> 
  <!--{if in_array($option[type],array('radio', 'checkbox'))}-->
  <li class="flexbox bzbt1"><span class="name"><!--{if $option['required']}--><em class="rq">*</em><!--{/if}-->$option[title]</span></li>
  <li class="bzbt1 bz-bg-fff sm" id="bar_{$option[identifier]}"> 
    <!--{if $option['type'] == 'radio'}--> 
    <!--{loop $option['choices'] $id $value}-->
    <label>
      <input type="radio" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="pr" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id] $option[unchangeable] class="pr">
      $value</label>
    <!--{/loop}--> 
    <!--{elseif $option['type'] == 'checkbox'}--> 
    <!--{loop $option['choices'] $id $value}-->
    <label>
      <input type="checkbox" name="typeoption[{$option[identifier]}][]" id="typeoption_$option[identifier]" class="pc" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id][$id] $option[unchangeable] class="pc">
      $value</label>
    <!--{/loop}--> 
    <!--{/if}--> 
  </li>
  <!--{elseif in_array($option['type'], array('textarea'))}-->
  <li class="flexbox bzbt1"><span class="name"><!--{if $option['required']}--><em class="rq">*</em><!--{/if}-->$option[title]</span></li>
  <li class="bzbt1 bz-bg-fff" id="bar_{$option[identifier]}">
    <textarea name="typeoption[{$option[identifier]}]" tabindex="1" id="typeoption_$option[identifier]" rows="$option[rowsize]" cols="$option[colsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]', 0, 0{if $option[maxlength]}, '$option[maxlength]'{/if})" $option[unchangeable] class="pt" placeholder="{echo trim($desc)}" style="height:70px;width:100%;border:0">$option[value]</textarea>
  </li>
  <!--{else}-->
  <li class="flexbox bz-bg-fff bzbt1 align_center" id="bar_{$option[identifier]}"><span class="name"><!--{if $option['required']}--><em class="rq">*</em><!--{/if}-->$option[title]</span><span class="html flex $option[type]"> 
    <!--{if $option['type'] == 'calendar'}-->
    <input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" tabindex="1" size="$option[inputsize]" value="$option[value]" onclick="Common.showcalendar(this);" $option[unchangeable] class="px"/>
    <!--{elseif $option['type'] == 'select'}-->
    <div id="select_$option[identifier]" class="selectbar"> 
      <!--{loop $option['value'] $selectedkey $selectedvalue}--> 
      <!--{if $selectedkey}--> 
      <script type="text/javascript">
              changeselectthreadsort('$selectedkey', $optionid, 'update');
          </script> 
      <!--{else}-->
      <select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable] class="ps">
        <option value="0">{lang please_select}</option>
        <!--{loop $option['choices'] $id $value}--> 
        <!--{if !$value[foptionid]}-->
        <option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
        <!--{/if}--> 
        <!--{/loop}-->
      </select>
      <!--{/if}--> 
      <!--{/loop}--> 
      <!--{if !is_array($option['value'])}-->
      <select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable] class="ps">
        <option value="0">{lang please_select}</option>
        <!--{loop $option['choices'] $id $value}--> 
        <!--{if !$value[foptionid]}-->
        <option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
        <!--{/if}--> 
        <!--{/loop}-->
      </select>
      <!--{/if}--> 
    </div>
    <!--{elseif $option['type'] == 'image'}--> 
    <!--{if !($option[unchangeable] && $option['value'])}-->
    <input type="hidden" name="typeoption[{$option[identifier]}][aid]" value="$option[value][aid]" id="sortaid_{$option[identifier]}" />
    <input type="hidden" name="sortaid_{$option[identifier]}_url" id="sortaid_{$option[identifier]}_url" />
    <!--{if $option[value]}-->
    <input type="hidden" name="oldsortaid[{$option[identifier]}]" value="$option[value][aid]" tabindex="1" />
    <!--{/if}-->
    <input type="hidden" name="typeoption[{$option[identifier]}][url]" id="sortattachurl_{$option[identifier]}" {if $option[value][url]}value="$option[value][url]"{/if} tabindex="1" />
    <!--{/if}-->
    <div class="ptn imagebox si">
      <ul id="sortattach_image_{$option[identifier]}" data-id="$option[identifier]">
        <!--{if $option['value']['url']}-->
        <li><span aid="$option[value][aid]" name="{$option[identifier]}" class="del2"><a href="javascript:;"><img src="static/image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="height:44px;width:50px;" src="$option[value][url]"></span></li>
        <!--{else}-->
        <li id="upfiledata"><i class="big y iconfont icon-camera" style="height:25px;"></i></li>
        <!--{/if}-->
      </ul>
    </div>
    <!--{else}-->
    <input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="px" tabindex="1" size="$option[inputsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]'{if $option[maxnum]}, '$option[maxnum]'{else}, '0'{/if}{if $option[minnum]}, '$option[minnum]'{else}, '0'{/if}{if $option[maxlength]}, '$option[maxlength]'{/if})" value="{if $_G['tid']}$option[value]{else}{if $member_profile[$option['profile']]}$member_profile[$option['profile']]{else}$option['defaultvalue']{/if}{/if}" $option[unchangeable] placeholder="{echo trim($desc)}"/>
    <!--{/if}--> 
    </span></li>
  <!--{/if}--> 
  <!--{/loop}--> 
  
  <!--{if $_G['forum']['threadsorts']['expiration'][$_G['forum_selectsortid']]}-->
  <li class="flexbox bz-bg-fff bzbt1"><span class="name">{lang threadtype_expiration}</span><span class="html flex iocn">
    <select name="typeexpiration" tabindex="1" id="typeexpiration">
      <option value="259200">{lang three_days}</option>
      <option value="432000">{lang five_days}</option>
      <option value="604800">{lang seven_days}</option>
      <option value="2592000">{lang one_month}</option>
      <option value="7776000">{lang three_months}</option>
      <option value="15552000">{lang half_year}</option>
      <option value="31536000">{lang one_year}</option>
    </select>
    </span> </li>
  <!--{/if}--> 
  
  <!--{/if}--> 
</div>

<script type="text/javascript">
	function warning(id, msg, type) {
		if(type != 'right') {
			$('#bar_'+id).addClass('err');
			Common.tips(msg);
		}else{
			$('#bar_'+id).removeClass("err");
		}
	}
	var uphtml,inputid,box = '';
	var bar = [];
	var uploader_act = WebUploader.create({
		server: 'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
		formData: {uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
		fileVal: 'Filedata',
		pick: '#upfiledata',
		auto: true,
		accept: {
			title: 'Image File',
			extensions: 'gif,jpg,jpeg,bmp,png',
			mimeTypes:'image/*,text/plain,application/msword,application/octet-stream,application/vnd.ms-excel,application/x-shockwave-flash'
		}
	});
	
	uploader_act.on('fileQueued', function(file) {
		bar = $('#rt_'+file.source.ruid).parent().parent();
		$(bar).html('<li id="file_'+file.id+'"><img src="template/banzhuan_touch026/touch/banzhuan/images/loading.gif" style="height:44px;width:50px;"><i class="Progress"></i></li>');
	});
    
	uploader_act.on('uploadSuccess', function(file, data) {
		//bar = $('#rt_'+file.source.ruid).parent().parent();
		inputid = bar.attr('data-id');
		if(data._raw) {
			var dataarr = data._raw.split('|');
			if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
				$('#file_'+file.id).html('<span aid="'+dataarr[3]+'" class="del2"><a href="javascript:;"><img src="'+STATICURL+'image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="width:50px;height:44px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" />');
				$('#sortaid_'+inputid).val(dataarr[3]);
				$('#sortaid_'+inputid+'_url').val(dataarr[5]);
				$('#sortattachurl_'+inputid).val('{$_G[setting][attachurl]}forum/'+dataarr[5]);
			}
		}
	});


	$(document).on('click', '.del2', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
			if(!uphtml){
				uphtml = '<li id="upfiledata"><i class="big y" data-id="&#xe005;" style="height:25px;"></i></li>';
			}
			if(!box){
			    box = '#sortattach_image_'+obj.attr('name');
			}
			$(box).html(uphtml);
			uploader_act.addButton({id:'#upfiledata'});
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});
</script> 
