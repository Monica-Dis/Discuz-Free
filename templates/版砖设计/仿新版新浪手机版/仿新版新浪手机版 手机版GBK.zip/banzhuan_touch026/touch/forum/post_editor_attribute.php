<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<ul class="post_extra banzhuan-clear bz-bg-fff">
	  <li class="bz-ptb10">
		    <a onclick="Common.SwitchTab(this,'extra_additional');"><i class="invert iconfont icon-icon09"></i></a> 
		    <!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
		   		<a onclick="Common.SwitchTab(this,'extra_readperm');"><i class="invert iconfont icon-suo2"></i></a>
			    <!--{if $_G['group']['allowreplycredit'] && !in_array($special, array(2, 3))}--> 
				    <!--{if $_GET[action] == 'newthread'}--> 
				    		<!--{eval $extcreditstype = $_G['setting']['creditstransextra'][10];}--> 
				    <!--{else}-->
				    		<!--{eval $extcreditstype = $replycredit_rule['extcreditstype'] ? $replycredit_rule['extcreditstype'] : $_G['setting']['creditstransextra'][10];}--> 
				    <!--{/if}-->
			    		<!--{eval $userextcredit = getuserprofile('extcredits'.$extcreditstype);}--> 
				    <!--{if ($_GET[action] == 'newthread' && $userextcredit > 0) || ($_GET[action] == 'edit' && $isorigauthor && isfirstpost)}--> 
				   		 <a onclick="Common.SwitchTab(this,'extra_replycredit');"><i class="invert iconfont icon-jiangli"></i></a> 
				    <!--{/if}--> 
			    <!--{/if}--> 
			    <!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}--> 
			    		<a onclick="Common.SwitchTab(this,'extra_rushreplyset');"><i class="invert iconfont icon-qiang"></i></a> 
			    <!--{/if}--> 
			    <!--{if $_G['group']['maxprice'] && !$special}--> 
			    		<a onclick="Common.SwitchTab(this,'extra_price');"><i class="invert iconfont icon-jiage"></i></a> 
			    <!--{/if}--> 
			    <!--{if $_G['group']['allowposttag']}--> 
			    		<a onclick="Common.SwitchTab(this,'extra_tag');"><i class="invert iconfont icon-6zhuanhuan01"></i></a> 
			    <!--{/if}--> 
			    <!--{if $_G['group']['allowsetpublishdate'] && ($_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost && $thread['displayorder'] == -4))}--> 
			    		<a onclick="Common.SwitchTab(this,'extra_pubdate');"><i class="invert iconfont icon-shezhi2"></i></a> 
			    <!--{/if}--> 
		    <!--{/if}--> 
		    <!--{hook/viewthread_fastpost_button_mobile}--> 
	  </li>
</ul>

<div class="bzbb1 banzhuan-clear">
	  <ul>
		    <div class="sbox bzpostlist">
			      <div id="extra_additional" class="ebox">
			        <li class="flexbox bzbt1"><span class="name">{lang basic_attr}</span></li>
			        <li class="bzbt1 bz-bg-fff sml">
				          <!--{if $_GET[action] != 'edit'}--> 
					          <!--{if $_G['group']['allowanonymous']}-->
					          <label for="isanonymous">
						            <input type="checkbox" name="isanonymous" id="isanonymous" class="pc" value="1" />
						            {lang post_anonymous}
					          </label>
					          <!--{/if}-->
				          <!--{else}--> 
					          <!--{if $_G['group']['allowanonymous'] || (!$_G['group']['allowanonymous'] && $orig['anonymous'])}-->
					          <label for="isanonymous">
						            <input type="checkbox" name="isanonymous" id="isanonymous" class="pc" value="1" {if $orig['anonymous']}checked="checked"{/if} />
						            {lang post_anonymous}
					          </label>
					          <!--{/if}-->
				          <!--{/if}--> 
				          
				          <!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
				          <label for="hiddenreplies">
					            <input type="checkbox" name="hiddenreplies" id="hiddenreplies" class="pc"{if $thread['hiddenreplies']} checked="checked"{/if} value="1">
					            {lang hiddenreplies}
				          </label>
				          <!--{/if}--> 
				          <!--{if $_G['uid'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost) && $special != 3}-->
				          <label for="ordertype">
					            <input type="checkbox" name="ordertype" id="ordertype" class="pc" value="1" $ordertypecheck />
					            {lang post_descviewdefault}
				          </label>
				          <!--{/if}--> 
				          <!--{if ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
				          <label for="allownoticeauthor">
					            <input type="checkbox" name="allownoticeauthor" id="allownoticeauthor" class="pc" value="1"{if $allownoticeauthor} checked="checked"{/if} />
					            {lang post_noticeauthor}
				          </label>
				          <!--{/if}--> 
				          <!--{if $_GET[action] != 'edit' && helper_access::check_module('feed') && $_G['forum']['allowfeed']}-->
				          <label for="addfeed">
					            <input type="checkbox" name="addfeed" id="addfeed" class="pc" value="1" $addfeedcheck>
					            {lang addfeed}
				          </label>
				          <!--{/if}-->
				          <label for="usesig">
					            <input type="checkbox" name="usesig" id="usesig" class="pc" value="1" {if !$_G['group']['maxsigsize']}disabled {else}$usesigcheck {/if}/>
					            {lang post_show_sig}
				          </label>
			        </li>
			        <li class="flexbox bzbt1"><span class="name">{lang text_feature}</span></li>
			        <li class="bzbt1 bz-bg-fff sml"> 
				          <!--{if ($_G['forum']['allowhtml'] || ($_GET[action] == 'edit' && ($orig['htmlon'] & 1))) && $_G['group']['allowhtml']}-->
					          <label for="htmlon">
						            <input type="checkbox" name="htmlon" id="htmlon" class="pc" value="1" $htmloncheck />
						            {lang post_html}
					          </label>
				          <!--{else}-->
					          <label for="htmlon" class="tdlt">
					            <input type="checkbox" name="htmlon" id="htmlon" class="pc" value="0" $htmloncheck disabled="disabled" />
					            {lang post_html}
					          </label>
				          <!--{/if}-->
				          <label for="allowimgcode" class="tdlt">
					            <input type="checkbox" id="allowimgcode" class="pc" disabled="disabled"{if $_G['forum']['allowimgcode']} checked="checked"{/if} />
					            {lang post_imgcode}
				          </label>
				          <!--{if $_G['forum']['allowimgcode']}-->
				          <label for="allowimgurl">
					            <input type="checkbox" id="allowimgurl" class="pc" checked="checked" />
					            {lang post_imgurl}
				          </label>
				          <!--{/if}-->
				          <label for="parseurloff">
					            <input type="checkbox" name="parseurloff" id="parseurloff" class="pc" value="1" $urloffcheck />
					            {lang disable}{lang post_parseurl}
				          </label>
				          <label for="smileyoff">
					            <input type="checkbox" name="smileyoff" id="smileyoff" class="pc" value="1" $smileyoffcheck />
					            {lang disable}{lang smilies}
				          </label>
				          <label for="bbcodeoff">
					            <input type="checkbox" name="bbcodeoff" id="bbcodeoff" class="pc" value="1" $codeoffcheck />
					            {lang disable}{lang discuzcode}
				          </label>
				          <!--{if $_G['group']['allowimgcontent']}-->
					          <label for="imgcontent">
						            <input type="checkbox" name="imgcontent" id="imgcontent" class="pc" value="1" $imgcontentcheck onClick="switchEditor(this.checked?0:1);$('e_switchercheck').checked=this.checked;" />
						            {lang content_to_pic}
					          </label>
				          <!--{else}-->
					          <label for="imgcontent" class="tdlt">
					            <input type="checkbox" name="imgcontent" id="imgcontent" class="pc" value="0" $imgcontentcheck disabled="disabled"/>
					            {lang content_to_pic}
					          </label>
				          <!--{/if}--> 
			        </li>
			        <!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts'])}--> 
				        <!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts']) && ($_G['group']['allowstickthread'] || $_G['group']['allowdigestthread'])}-->
				        <li class="flexbox bzbt1"><span class="name">{lang manage_operation}</span></li>
				        <li class="bzbt1 bz-bg-fff sml"> 
					          <!--{if $_G['group']['allowstickthread']}-->
					          <label for="sticktopic">
						            <input type="checkbox" name="sticktopic" id="sticktopic" class="pc" value="1" $stickcheck />
						            {lang post_stick_thread}
					          </label>
					          <!--{/if}-->
					          <!--{if $_G['group']['allowdigestthread']}-->
					          <label for="addtodigest">
						            <input type="checkbox" name="addtodigest" id="addtodigest" class="pc" value="1" $digestcheck />
						            {lang post_digest_thread}
					          </label>
					          <!--{/if}--> 
				        </li>
				        <!--{/if}-->
			        <!--{elseif $_GET[action] == 'edit' && $_G['forum_auditstatuson']}-->
				        <li class="flexbox bzbt1"><span class="name">{lang manage_operation}</span></li>
				        <li class="bzbt1 bz-bg-fff sml">
					          <label for="audit">
						            <input type="checkbox" name="audit" id="audit" class="pc" value="1">
						            {lang auditstatuson}
					          </label>
				        </li>
			        <!--{/if}--> 
			        <!--{if $_GET[action] == 'edit' && $isorigauthor && ($isfirstpost && $thread['replies'] < 1 || !$isfirstpost) && !$rushreply && $_G['setting']['editperdel']}-->
			        <li class="flexbox bzbt1"><span class="name">{lang post_delpost}</span></li>
			        <li class="bzbt1 bz-bg-fff sml">
				          <button type="button" class="button" onClick="deleteThread();"><span>{lang post_delpost}</span></button>
				          <input type="hidden" name="delete" id="delete" value="0" />
				          {lang del_thread_warning}<!--{if $thread[special] == 3}-->, {lang reward_price_back}<!--{/if}--> 
			        </li>
			        <!--{/if}--> 
			      </div>
		     
			      <div id="extra_readperm" class="ebox">
				        <!--{if $_G['group']['allowsetreadperm']}--> 
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name">{lang readperm}</span>
					        	<span class="html flex iocn">
						          <select name="readperm" id="readperm" class="ps">
							            <option value="">{lang unlimited}</option>
							            <!--{loop $_G['cache']['groupreadaccess'] $val}-->
							            <option value="$val[readaccess]" title="{lang readperm}: $val[readaccess]"{if $thread['readperm'] == $val[readaccess]} selected="selected"{/if}>$val[grouptitle]</option>
							            <!--{/loop}-->
							            <option value="255"{if $thread['readperm'] == 255} selected="selected"{/if}>{lang highest_right}</option>
						          </select>
					        </span>
				        </li>
			            <!--{/if}--> 
			            <div style="display:none;">
			            <li class="flexbox bzbt1"><span class="name">&#38544;&#34255;&#20869;&#23481;</span></li>
			            <li class="flexbox bzbt1 bz-bg-fff">
				            <span class="html flex">
				           		 <textarea id="hide_text" style="width: 100%; height:70px;" class="txtarea"></textarea>
				            </span>
			            </li>
			            <li class="flexbox bzbt1 bz-bg-fff">
				          	  <span class="name">&#27983;&#35272;&#26465;&#20214;</span>
				          	  <span class="html flex iocn">
						          <select name="hide_type" id="hide_type" class="ps" onchange="document.getElementById('hide_credits_bar').style.display = this.value == 1 ? 'none' : ''">
							            <option value="1">&#22238;&#22797;&#21518;&#27983;&#35272;</option>
							            <option value="2">&#31215;&#20998;&#39640;&#20110;</option>
						          </select>
				              </span>
			            </li>
			            <li class="flexbox bzbt1 bz-bg-fff" id="hide_credits_bar" style="display:none;">
				          	<span class="name">&#31215;&#20998;&#39640;&#20110;</span>
				          	<span class="html flex">
				            		<input type="text" id="hide_credits">
				            </span>
			            </li>
			            <li class="flexbox bzbt1 bz-bg-fff">
					          <span class="name">&#38544;&#34255;&#20869;&#23481;&#26377;&#25928;&#22825;&#25968;</span>
					          <span class="html flex">
					          		<input type="text" id="hide_day">
					          </span>
			            </li>
			            </div>
			      </div>
		      
			      <!--{if !empty($userextcredit)}-->
			      <div id="extra_replycredit" class="ebox">
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name">{lang replycredit_once}</span>
					        	<span class="html flex flexbox">
						          <input type="text" name="replycredit_extcredits" id="replycredit_extcredits" class="px flex" value="{if $replycredit_rule['extcredits'] && $thread['replycredit'] > 0}{$replycredit_rule['extcredits']}{else}0{/if}" onKeyUp="javascript:getreplycredit();" onBlur="extraCheck(0)" placeholder="{lang replycredit_empty}"/>
						          <dd>{$_G['setting']['extcredits'][$extcreditstype][unit]}{$_G['setting']['extcredits'][$extcreditstype][title]}</dd>
					        </span>
				        </li>
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name">{lang replycredit_reward}</span>
					        	<span class="html flex flexbox">
						          <input type="text" name="replycredit_times" id="replycredit_times" class="px pxs vm" value="{if $replycredit_rule['lasttimes']}{$replycredit_rule['lasttimes']}{else}1{/if}" onkeyup="javascript:getreplycredit();"  onblur="extraCheck(0)" />
						          <dd>{lang replycredit_time}</dd>
					        </span>
				        </li>
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name">{lang replycredit_member}</span>
					        	<span class="html flex iocn">
						          <select id="replycredit_membertimes" name="replycredit_membertimes" class="ps vm">
							            <!--{eval for($i=1;$i<11;$i++) {;}-->
							            <option value="$i"{if $replycredit_rule['membertimes'] == $i} selected="selected"{/if}>$i {lang replycredit_time}</option>
							            <!--{eval };}-->
						          </select>
					        </span>
				        </li>
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name">{lang replycredit_rate}</span>
					        	<span class="html flex iocn">
						          <select id="replycredit_random" name="replycredit_random" class="ps vm">
							            <!--{eval for($i=100;$i>9;$i=$i-10) {;}-->
							            <option value="$i"{if $replycredit_rule['random'] == $i} selected="selected"{/if}>$i %</option>
							            <!--{eval };}-->
						          </select>
					        </span>
				        </li>
			      </div>
			      <!--{/if}-->
		      
			      <!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
			      <div id="extra_rushreplyset" class="ebox">
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name">{lang rushreply_change}</span>
					        	<span class="html flex">
					        		<label for="rushreply">
					        			<input type="checkbox" name="rushreply" id="rushreply" class="pc vm y" value="1" {if $_GET[action] == 'edit' && getstatus($thread['status'], 3)}disabled="disabled" checked="checked"{/if} onClick="extraCheck(3)" />
					        		</label>
					        	</span>
				        </li>
				        <li class="flexbox bzbt1"><span class="name">{lang rushreply_time}</span></li>
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="html flex flexbox">
					        		<input type="text" name="rushreplyfrom" id="rushreplyfrom" class="px flex" onclick="this.blur();Common.showcalendar(this);" autocomplete="off" value="$postinfo[rush][starttimefrom]" onKeyUp="document.getElementById('rushreply').checked = true;" />
					             ~ 
					            <input type="text" onclick="this.blur();Common.showcalendar(this);" autocomplete="off" id="rushreplyto" name="rushreplyto" class="px flex" value="$postinfo[rush][starttimeto]" onKeyUp="document.getElementById('rushreply').checked = true;" />
					        	</span>
				        </li>
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name">{lang rushreply_rewardfloor}</span>
					        	<span class="html flex">
					        		<input type="text" name="rewardfloor" id="rewardfloor" class="px oinf" value="$postinfo[rush][rewardfloor]" onKeyUp="$('rushreply').checked = true;" placeholder="{lang rushreply_rewardfloor_comment}"/>
					        	</span>
				        </li>
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name">{lang stopfloor}:</span>
					        	<span class="html flex">
					        		<input type="text" name="replylimit" id="replylimit" class="px" autocomplete="off" value="$postinfo[rush][replylimit]" onKeyUp="$('rushreply').checked = true;" placeholder="{lang replylimit}"/>
					        </span>
				        </li>
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name">{lang rushreply_end}</span>
					        	<span class="html flex">
					        		<input type="text" name="stopfloor" id="stopfloor" class="px" autocomplete="off" value="$postinfo[rush][stopfloor]" onKeyUp="$('rushreply').checked = true;" />
					        </span>
				        </li>
				        <li class="flexbox bzbt1 bz-bg-fff">
					        	<span class="name"><!--{if $_G['setting']['creditstransextra'][11]}-->{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]}<!--{else}-->{lang credits}<!--{/if}-->{lang min_limit}:</span>
					        	<span class="html flex">
					        		<input type="text" name="creditlimit" id="creditlimit" class="px" autocomplete="off" value="$postinfo[rush][creditlimit]" onKeyUp="$('rushreply').checked = true;" placeholder="<!--{if $_G['setting']['creditstransextra'][11]}-->({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]})<!--{else}-->{lang total_credits}<!--{/if}-->{lang post_rushreply_credit}"/>
					        </span>
				        </li>
			      </div>
			      <!--{/if}-->
		      
			      <!--{if $_G['group']['maxprice'] && !$special}-->
			      <div id="extra_price" class="ebox">
				        <li class="flexbox bz-bg-fff bzbt1"> 
					        <span class="name">{lang price}</span><span class="html flex flexbox">
					        		<input type="text" id="price" name="price" class="px flex" value="$thread[pricedisplay]" onblur="extraCheck(2)" placeholder="({lang post_price_comment})"/><dd>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</dd>
					        </span> 
				        </li>
			      </div>
			      <!--{/if}-->
			      
			      <!--{if $_G['group']['allowposttag']}-->
			      <div id="extra_tag" class="ebox">
				        <li class="flexbox bz-bg-fff bzbt1"> 
					          <span class="name">{lang post_tag}</span>
					          <span class="html flex flexbox">
						          	<input type="text" class="px flex" size="60" id="tags" name="tags" value="$postinfo[tag]" onblur="extraCheck(4)"  placeholder="{lang posttag_comment}"/>
						          	<!--<a href="javascript:;" id="clickbutton[]" class="linkbt" onclick="relatekw('-1','-1');">{lang auto_keyword}</a>-->
					          </span>
				        </li>
			      </div>
			      <!--{/if}-->
			      
			      <div id="extra_pubdate" class="ebox"></div>
		    </div>
	  </ul>
</div>

<script>
	function relatekw() {
		var subject = document.getElementById('needsubject').value;
		var message = document.getElementById('needmessage').value;
		message = message.replace(/&/ig, '', message).substr(0, 500);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=relatekw&subjectenc=' + subject + '&messageenc=' + message,
			dataType:'xml'
		}).success(function(s) {
			if(s.lastChild.firstChild.nodeValue){
				document.getElementById('tags').value = s.lastChild.firstChild.nodeValue;
			}
		});
	}
	function deleteThread() {
		if(confirm('\u786e\u5b9a\u8981\u5220\u9664\u8be5\u5e16\u5b50\u5417\uff1f') != 0){
			$('#delete').val('1');
			$('#postform').submit();
		}
	}
</script>