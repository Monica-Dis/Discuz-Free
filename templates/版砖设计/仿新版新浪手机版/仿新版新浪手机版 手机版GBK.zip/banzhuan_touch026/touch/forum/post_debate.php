<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<div class="exfm">
	  <li class="flexbox bzbt1 align_center"><span class="name">{lang debate_square_point}</span></li>
	  <li class="flexbox bzbt1 bz-bg-fff"><textarea name="affirmpoint" id="affirmpoint" class="pt" style="height:100px;width:100%;border:0">$debate[affirmpoint]</textarea></li>
	  <li class="flexbox bzbt1 align_center"><span class="name">{lang debate_opponent_point}</span></li>
	  <li class="flexbox bzbt1 bz-bg-fff"><textarea name="negapoint" id="negapoint" class="pt" style="height:100px;width:100%;border:0">$debate[negapoint]</textarea></li>
	  <div class="banzhuan-h10 bzbt1"></div>
	  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang endtime}</span><span class="html flex"><input type="text" name="endtime" id="endtime" class="px" onclick="this.blur();Common.showcalendar(this);" autocomplete="off" value="$debate[endtime]" tabindex="1" /></span></li>
	  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang debate_umpire}</span><span class="html flex"><input type="text" name="umpire" id="umpire" class="px" value="$debate[umpire]" tabindex="1" /></span></li>
</div>

<script type="text/javascript" reload="1">
	EXTRAFUNC = [];
	EXTRAFUNC['validator'] = [];
	EXTRAFUNC['validator']['special'] = 'validateextra';
	function validateextra() {
		if(document.getElementById('postform').affirmpoint.value == '') {
			popup.open('{lang post_debate_message_1}', 'alert');
			return false;
		}
		if(document.getElementById('postform').negapoint.value == '') {
			popup.open('{lang post_debate_message_2}', 'alert');
			return false;
		}
		return true;
	}
</script>