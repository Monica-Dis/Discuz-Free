<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-header">
	<div class="bz-header-left">
		<a href="javascript:history.back();" class="iconfont icon-fanhui"><em>{lang return}</em></a>
	</div>
	<h2>{lang send_posts}</h2>
	<div class="bz-header-right">
		<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
	</div>
</div>
<div class="bz-pfs bzbb1">
	<div style="display: none">
		<ul id="fs_group">$grouplist</ul>
		<ul id="fs_forum_common">$commonlist</ul>
		<!--{loop $forumlist $forumid $forum}-->
			<ul id="fs_forum_$forumid">$forum</ul>
		<!--{/loop}-->
		<!--{loop $subforumlist $forumid $forum}-->
			<ul id="fs_subforum_$forumid">$forum</ul>
		<!--{/loop}-->
	</div>
	<div class="c forumlistpbl_box">
		<div class="bz-p10">
			<span class="pbnv color-b">$_G['setting']['sitename']<span id="pbnv"></span> <a id="enterbtn" class="xg1 color-b" href="javascript:;" onclick="locationforums(currentblock, currentfid)">[{lang nav_forum}]</a></span>
		</div>
		<ul class="forumlistpbl cl">
			<li id="block_group"></li>
			<li id="block_forum"></li>
			<li id="block_subforum"></li>
		</ul>
	    	<p class="cl z pbut">
			<!--{if $_G['group']['allowpost'] || !$_G['uid']}-->
				<!--{if $special === null}-->
					<button id="postbtn" class="pnc z" onclick="hideWindow('nav');window.location.href='forum.php?mod=post&action=newthread&fid=' + selectfid + '&mobile=2'" disabled="disabled">{lang send_posts}</button>
				<!--{else}-->
					<button id="postbtn" class="pnc z" onclick="hideWindow('nav');window.location.href='forum.php?mod=post&action=newthread&fid=' + selectfid + '&special=$special&mobile=2'" disabled="disabled">$actiontitle</button>
				<!--{/if}-->
			<!--{/if}-->
	
		</p>
	</div>
	
	<script type="text/javascript" reload="1">
	var s = '<!--{if $commonfids}--><p><a id="commonforum" href="javascript:;" onclick="switchforums(this, 1, \'common\')" class="pbsb lightlink">{lang nav_forum_frequently}</a></p><!--{/if}-->';
	var lis = $('fs_group').getElementsByTagName('LI');
	for(i = 0;i < lis.length;i++) {
		var gid = lis[i].getAttribute('fid');
		if($('fs_forum_' + gid)) {
			s += '<p><a href="javascript:;" ondblclick="locationforums(1, ' + gid + ')" onclick="switchforums(this, 1, ' + gid + ')" class="pbsb">' + lis[i].innerHTML + '</a></p>';
		}
	
	}
	$('block_group').innerHTML = s;
	var lastswitchobj = null;
	var selectfid = 0;
	var switchforum = switchsubforum = '';
	
	switchforums($('commonforum'), 1, 'common');
	
	function switchforums(obj, block, fid) {
		if(lastswitchobj != obj) {
			if(lastswitchobj) {
				lastswitchobj.parentNode.className = '';
			}
			obj.parentNode.className = 'pbls';
		}
		var s = '';
		if(fid != 'common') {
			$('enterbtn').className = 'xi2 color-b';
			currentblock = block;
			currentfid = fid;
		} else {
			$('enterbtn').className = 'xg1 color-b';
		}
		if(block == 1) {
			var lis = $('fs_forum_' + fid).getElementsByTagName('LI');
			for(i = 0;i < lis.length;i++) {
				fid = lis[i].getAttribute('fid');
				if(fid != '') {
					s += '<p><a href="javascript:;" ondblclick="locationforums(2, ' + fid + '\)" onclick="switchforums(this, 2, ' + fid + ')"' + ($('fs_subforum_' + fid) ?  ' class="pbsb"' : '') + '>' + lis[i].innerHTML + '</a></p>';
				}
			}
			$('block_forum').innerHTML = s;
			$('block_subforum').innerHTML = '';
			switchforum = switchsubforum = '';
			selectfid = 0;
			$('postbtn').setAttribute("disabled", "disabled");
			$('postbtn').className = 'pn xg1 y';
		} else if(block == 2) {
			selectfid = fid;
			if($('fs_subforum_' + fid)) {
				var lis = $('fs_subforum_' + fid).getElementsByTagName('LI');
				for(i = 0;i < lis.length;i++) {
					fid = lis[i].getAttribute('fid');
					s += '<p><a href="javascript:;" ondblclick="locationforums(3, ' + fid + ')" onclick="switchforums(this, 3, ' + fid + ')">' + lis[i].innerHTML + '</a></p>';
				}
				$('block_subforum').innerHTML = s;
			} else {
				$('block_subforum').innerHTML = '';
			}
			switchforum = obj.innerHTML;
			switchsubforum = '';
			$('postbtn').removeAttribute("disabled");
			$('postbtn').className = 'pnc y';
		} else {
			selectfid = fid;
			switchsubforum = obj.innerHTML;
			$('postbtn').removeAttribute("disabled");
			$('postbtn').className = 'pnc y';
		}
		lastswitchobj = obj;
		$('pbnv').innerHTML = switchforum ? '&nbsp;&gt;&nbsp;' + switchforum + (switchsubforum ? '&nbsp;&gt;&nbsp;' + switchsubforum : '') : '';
	}
	
	function locationforums(block, fid) {
		location.href = block == 1 ? 'forum.php?gid=' + fid : 'forum.php?mod=forumdisplay&fid=' + fid;
	}
	
	</script>
</div>

<!--{hook/global_footer_mobile}-->
<div id="mask" style="display:none;"></div>
<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<div class="banzhuan-bottom"></div>
</body>
</html>

