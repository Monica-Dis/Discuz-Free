<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-header">
	<div class="bz-header-left"><a href="javascript:history.back();" class="iconfont icon-fanhui"></a><a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a></div>
	<h2><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></h2>
	<div class="bz-header-right bzdown">
		<a class="iconfont icon-info"></a>
	</div>
</div>
<div class="bz-b-nava-ziban">
	<div class="bgDiv"></div>
	<div class="downNav">
		<div class="downNav-cancel">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home">&nbsp;{lang return}{lang homepage}</a>
			<!--{eval}-->
			    if($_G['uid']){$favfids = C::t('home_favorite')->fetch_all_by_uid_idtype($_G['uid'], 'fid');foreach($favfids as $val){if($val['id'] == $_G[fid]){$isFav = $val['favid'];}}}
			<!--{/eval}-->
			<!--{if $isFav}-->
				<a href="home.php?mod=space&do=favorite&type=forum" class="forum-del iconfont icon-shoucang2 color-b">&nbsp;&#24050;&#25910;&#34255;</a>
			<!--{else}-->
				<a id="a_favorite" href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" class="forum-fav iconfont icon-shoucang2 color-red">&nbsp;&#25910;&#34255;&#26412;&#29256;</a>
			<!--{/if}-->
		</div>
		<div style="height: 5px; background: #F6F6F6; width: 100%;"></div>
		<div class="downNav-list">
			<!--{if $sublist > 0}-->
	 			<!--{loop $sublist $sub}-->
					<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a>
				<!--{/loop}-->
			<!--{else}-->
			    	<div class="bznodata">
					<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang forum_subforums}</p>
				</div>
			<!--{/if}-->
		</div>
	</div>
</div>
<!--{if CURMODULE != 'guide'}-->
<div class="bz-fd-appl banzhuan-clear">
	<ul class="cl">
		<li class="{if $_GET['filter'] !== 'lastpost' && $_GET['filter'] !== 'heat' && $_GET['filter'] !== 'digest' }a{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">{lang all}</a></li>
		<li class="{if $_GET['filter'] == 'lastpost'}a{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang latest}</a></li>
		<li class="{if $_GET['filter'] == 'heat'}a{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang order_heats}</a></li>
		<li class="{if $_GET['filter'] == 'digest'}a{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang digest_posts}</a></li>
		<!--{hook/forumdisplay_filter_extra}-->
	</ul>
</div>
<!--{else}-->
<!--{/if}-->

<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
<div class="bz-thread-types banzhuan-clear">
	<ul id="thread_types" class="cl">
		<!--{hook/forumdisplay_threadtype_inner}-->
		<li id="ttp_all" {if !$_GET[ 'typeid'] && !$_GET[ 'sortid']}class="xw1 a" {/if}>
			<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a>
		</li>
					
		<!--{if $_G['forum']['threadtypes']}-->
			<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
			<!--{if $_GET['typeid'] == $id}-->
			<li class="xw1 a">
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">
					<!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}-->
					<img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" />
					<!--{/if}-->
					$name
					<!--{if $showthreadclasscount[typeid][$id]}-->
					    <span class="1 num">($showthreadclasscount[typeid][$id])</span>
					<!--{/if}-->
				</a>
			</li>
			<!--{else}-->
			<li>
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">
					<!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}-->
					<img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" />
					<!--{/if}-->
					$name
					<!--{if $showthreadclasscount[typeid][$id]}-->
					<span class="2 num">($showthreadclasscount[typeid][$id])</span>
					<!--{/if}-->
				</a>
			</li>
			<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	
		<!--{if $_G['forum']['threadsorts']}-->
			<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
				<!--{if $_GET['sortid'] == $id}-->
				<li class="xw1 a">
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name
						<!--{if $showthreadclasscount[sortid][$id]}-->
						<span class="3 num">($showthreadclasscount[sortid][$id])</span>
						<!--{/if}-->
					</a>
				</li>
				<!--{else}-->
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name
						<!--{if $showthreadclasscount[sortid][$id]}-->
						<span class="4 num">($showthreadclasscount[sortid][$id])</span>
						<!--{/if}-->
					</a>
				</li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
		
		<!--{hook/forumdisplay_filter_extra}-->
	</ul>
</div>
<!--{/if}-->

<div class="main bz-fd banzhuan-clear">
	
	<div class="threadlist bz-ptb10"> 
	    <!--{hook/forumdisplay_top_mobile}--> 
	    
	    <!--{if $quicksearchlist && !$_GET['archiveid']}-->
			<!--{subtemplate forum/search_sortoption}-->
			<div class="banzhuan-clear"></div>
		<!--{/if}-->
	    
	    <!--{if !$subforumonly}--> 
	    
		    <!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
			    <ul class="bzbt1">
				      <li class="bz-plr10 bz-bg-fff line">
				      	    <a href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]"><span class="iconfont icon-tongzhigonggao color-red"></span> $announcement[subject]</a>
				      </li>
			    </ul>
		    <!--{/if}-->
		    
		    <div>
			      <ul id="threadlist">
			        <!--{if $_G['forum_threadcount']}-->
			        
				        <!--{loop $_G['forum_threadlist'] $key $thread}--> 
				        
					        <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}--> 
					        {eval $displayorder_thread = 1;} 
					        <!--{/if}--> 
					        <!--{if $thread['moved']}--> 
					        <!--{eval $thread[tid] = $thread[closed];}--> 
					        <!--{/if}--> 
					        
					        <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					        
					        <li class="bz-plr10 bz-bg-fff line"> 
					           <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight]><span class="iconfont icon-ding color-red"></span> {$thread[subject]}</a>
					        </li>
					        
					        <!--{else}-->
					        
					        <li id="thread_{$thread['tid']}"> 
					            <!--{hook/forumdisplay_thread_mobile $key}-->
                                <div class="bz-mt10 bz-fd-card">
                                    <header class="bzfdtlh">
							            <div class="bzfdtlh-left">
									        <!--{if !$thread[author]}-->
							              	<a class="avatar">{avatar($thread[0],middle)}</a>
							              	<!--{else}-->
							              	<a class="avatar" href="home.php?mod=space&uid=$thread[authorid]&do=profile">{avatar($thread[authorid],middle)}</a>
							              	<!--{/if}-->
									    </div>
									    	<div class="bzfdtlh-middle">
										    <div class="name">
										    	    <!--{if !$thread[author]}-->
									            <a class="user">{lang anonymous}{lang guest}</a>
								              	<!--{else}-->
									            <a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="user">$thread[author]</a>
								              	<!--{/if}-->
										    </div>
										    <div class="time-from"><span class="color-c">{echo dgmdate($thread[dbdateline],'u');}</span></div>
									    </div>
									    <div class="bzfdtlh-right">
									       	<!--{if $thread['typeid'] && $_G['forum']['threadtypes']['types'][$thread['typeid']]}-->
							                <a href="forum.php?mod=forumdisplay&fid=$thread['fid']&filter=typeid&typeid=$thread['typeid']" class="color-c">#{$_G['forum']['threadtypes']['types'][$thread['typeid']]}</a>
							                <!--{else}-->
							                <a class="color-c">#<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></a>
							                <!--{/if}--> 
									    </div>
                                    </header>
                                    <section class="bzfdtld">
                                        <a href="forum.php?mod=viewthread&tid=$thread[tid]">
		                                    <h2>$thread[subject]</h2>
		                                    <p><!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}--><!--{echo messagecutstr(DB::result_first('SELECT `message` FROM '.DB::table('forum_post').' WHERE `tid` ='.$thread[tid].' AND `first` =1'),100);}--></p>
                                   	   </a>
                                    </section>
                                    <div class="banzhuan-clear"></div>
                                    <footer class="bzfdtlf">
	                                    <ul>
									        <li><a href="forum.php?mod=viewthread&tid=$thread[tid]"><i class="iconfont icon-attention color-c"></i><em class="color-c">$thread[views]</em></a></li>
									        <li class="ping"><a href="forum.php?mod=viewthread&tid=$thread[tid]"><i class="iconfont icon-comment color-c"></i><em class="color-c">$thread[replies]</em></a></li>
									        <li><a href="forum.php?mod=viewthread&tid=$thread[tid]"><i class="iconfont icon-appreciatelight color-c"></i><em class="color-c">$thread[recommend_add]</em></a></li>
									    </ul>
                                    </footer>
                                 </div>
					        </li>
					        
					        <!--{/if}-->
				        
				        <!--{/loop}-->
			        
			        <!--{else}-->

			        <li class="bz-p10" style="text-align: center;">
						<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
						<p class="color-b">{lang forum_nothreads}</p>
					</li>
			        
			        <!--{/if}-->
			      </ul>
		    </div>
		    
	    <!--{/if}--> 
	    
	    <!--{hook/forumdisplay_bottom_mobile}--> 
	</div>

</div>

<script>
	<!--{eval $pageurl = 'forum.php?mod=forumdisplay&fid='.$_G[fid].($multiadd ? '&'.implode('&', $multiadd) : '').$multipage_archive;}-->
	<!--{if ceil($_G[forum_threadcount]/$_G[tpp])}-->
	$(window).scroll(function(){
		if ($(window).scrollTop() >= ($('.main').height() - $(window).height())) {
			Common.LoadMore(Common.id('loadmore'),'threadlist','li','$pageurl','{echo ceil($_G[forum_threadcount]/$_G[tpp]);}');
		}
	});
	<!--{/if}-->
</script>
<script type="text/javascript">
	$('.forum-fav').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=forum-fav&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>

<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
<div id="loadmore"></div>
<div id="mask" style="display:none;"></div>
<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<a href="forum.php?mod=post&action=newthread&fid=$_G['fid']" class="bz-return"><i class="iconfont icon-post"></i></a>
<div class="banzhuan-bottom"></div>
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->
