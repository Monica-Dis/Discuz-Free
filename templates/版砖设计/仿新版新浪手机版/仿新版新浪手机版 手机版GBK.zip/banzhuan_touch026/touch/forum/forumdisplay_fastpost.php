<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes&mobile=2">
	  <dl id="editor" class="bz-reply-editor bz-bg-fff" style="display:none;">
		    <h3 class="bz-p10 bz-bg-f5f5f5 bzbb1"><span>{lang reply}: $thread['subject']</span></h3>
		    <input type="hidden" name="formhash" value="{FORMHASH}" />
		    <input type="hidden" name="replysubmit" value="true">
		    
		    <!--{if $allowfastpost}-->
			    <div>
				      <ul class="postlist">
					        <li class="bz-bg-fff bzbb1 bz-p10">
					          	<textarea name="message" id="fastpostmessage" placeholder="{lang send_reply_fast_tip}" style="height:60px;width:100%;border:0;"></textarea>
					        </li>
				      </ul>
				      <div class="ebox imagebox" style="display:none;">
					        <ul id="imglist" class="bz-bg-fff Elegant bz-p10">
					          	<li id="filedata"><a><i class="bigs iconfont icon-jiahao1"></i></a></li>
					        </ul>
				      </div>
				      <!--{if $secqaacheck || $seccodecheck}-->
						    <div class="bz-p10 banzhuan-clear">
						        <!--{subtemplate common/seccheck}-->
						    </div>
					  <!--{/if}-->
				      <ul class="postlist">
					        <li class="bz-p10">
						        	<a onclick="Common.smilies('phizbox','fastpostmessage');Common.Switch(this,'phizbox');" class="phiz"><i class="iconfont icon-biaoqing color-c"></i></a>
						        	<!--{hook/viewthread_fastpost_button_mobile}-->
								<input type="submit" value="{lang reply}" class="pbutton y" name="replysubmit" id="fastpostsubmit" onclick='window.location.reload()'>
								<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" class="color-b y bz-mr10" style="font-size: 12px; line-height: 35px;">{lang post_advancemode}</a>
					        </li>
				      </ul>
			    </div>
			    <div class="sbox"><div id="phizbox" class="ebox"></div></div>
		    <!--{else}-->
			    <div class="bzbt1 bz-bg-fff hm" style="line-height:100px;">
				    <!--{if !$_G['uid']}-->
					      <!--{if !$_G['connectguest']}-->
					          {lang login_to_reply} <a href="member.php?mod=logging&action=login" class="color-blue">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}" class="color-blue">$_G['setting']['reglinkname']</a>
					      <!--{else}-->
					          {lang connect_fill_profile_to_post}
					      <!--{/if}-->
				    <!--{else}-->
				          {lang no_permission_to_post}
				          <a href="javascript:;" onclick="Common.id('fastpostform').submit()" class="xi2">
				          	{lang click_to_show_reason}
				          </a>
				    <!--{/if}-->
			    </div>
		    <!--{/if}-->
		    
	  </dl>
</form>

<script type="text/javascript" src="template/banzhuan_touch026/touch/banzhuan/webuploader.min.js" charset="{CHARSET}"></script>
<script type="text/javascript" src="data/cache/common_smilies_var.js" charset="{CHARSET}"></script> 
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
	var form = $('#fastpostform');
    var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	
    var uploader = WebUploader.create({
		server: 'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
		formData: {uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
		fileVal: 'Filedata',
		pick: '#filedata',
		auto: true,
		accept: {
			title: 'Files',
			extensions: 'gif,jpg,jpeg,bmp,png',
			mimeTypes:'image/*,text/plain,application/msword,application/octet-stream,application/vnd.ms-excel,application/x-shockwave-flash'
		}
	});
    
	uploader.on('fileQueued', function(file) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		$(bar).prepend('<li id="file_'+file.id+'"><img src="template/mogu_m1/images/loading_d.gif" style="height:44px;width:44px;"><i class="Progress">&#21387;&#32553;&#20013;</i></li>');
	});
	
	uploader.on('uploadProgress', function( file, percentage ) {
		$('#file_'+file.id+' i').html(Math.round(percentage * 100) + '%');
	});
	
	uploader.on('uploadSuccess', function(file, data) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		if(data._raw) {
			var dataarr = data._raw.split('|');
			if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
				$('#file_'+file.id).html('<span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="'+STATICURL+'image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="width:50px;height:44px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" />');
			} else {
				var sizelimit = '';
				if(dataarr[7] == 'ban') {
					sizelimit = '\u9644\u4ef6\u7c7b\u578b\u88ab\u7981\u6b62';
				} else if(dataarr[7] == 'perday') {
					sizelimit = '\u6587\u4ef6\u4e0d\u80fd\u8d85\u8fc7'+Math.ceil(dataarr[8]/1024)+'K)';
				} else if(dataarr[7] > 0) {
					sizelimit = '\u6587\u4ef6\u4e0d\u80fd\u8d85\u8fc7'+Math.ceil(dataarr[7]/1024)+'K)';
				}
				popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
			}
		}
	});
	
	uploader.on('uploadError', function( file ) {
		Common.tips('\u4e0a\u4f20\u5931\u8d25');
	});

	<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
	geo.getcurrentposition();
	<!--{/if}-->
	$('#fastpostform').on('submit', function() {
		<!--{if $secqaacheck || $seccodecheck}-->
	    Common.close('editor');
	    if(!Common.sec_code(this,'sec_code3')){
			return false;
		}
        <!--{/if}-->
		var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}

		obj.attr('disable', 'true').removeClass('btn_pn_blue').addClass('btn_pn_grey');
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

		var postlocation = '';
		if(geo.errmsg === '' && geo.loc) {
			postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
		}

		$.ajax({
			type:'POST',
			url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
		.success(function(s) {
			$('.sec_code').find('input[name="seccodeverify"]').attr('value', '');
			popup.open(s.lastChild.firstChild.nodeValue);
			obj.attr('disable', 'false').removeClass('btn_pn_grey').addClass('btn_pn_blue');
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
			obj.attr('disable', 'false').removeClass('btn_pn_grey').addClass('btn_pn_blue');
		});
		return false;
	});

	$(document).on('click', '.del', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});
    
	function succeedhandle_fastpostform(locationhref, message, param) {
		$('.sec_code').find('input[name="seccodeverify"]').attr('value', '');
		var pid = param['pid'];
		var tid = param['tid'];
		if(pid) {
			$.ajax({
				type:'POST',
				url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid + '&mobile=2',
				dataType:'xml'
			}).success(function(s) {
				$('#threadlist').append(s.lastChild.firstChild.nodeValue);
			}).error(function() {
				window.location.href = 'forum.php?mod=viewthread&tid=' + tid;
				popup.close();
			});
		} else {
			if(!message) {
				message = '{lang postreplyneedmod}';
			}
			popup.open(message, 'alert');
		}
		$('#fastpostmessage').attr('value', '');
		if(param['sechash']) {
			$('.seccodeimg').click();
		}
	}
	
	function errorhandle_fastpostform(message, param) {
		$('.sec_code').find('input[name="seccodeverify"]').attr('value', '');
		popup.open(message, 'alert');
	}
</script>
