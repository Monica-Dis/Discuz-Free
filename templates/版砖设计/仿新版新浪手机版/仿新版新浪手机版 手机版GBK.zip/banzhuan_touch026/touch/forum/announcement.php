<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-mobile">
	<div class="bz-mobile-left btn-open-close"><a class="iconfont icon-daohang"></a></div>
	<h2>{lang announcement}</h2>
	<div class="bz-mobile-right">
		<a href="<!--{if $_GET['mod'] == 'forumdisplay' || $_GET['mod'] == 'viewthread'}-->forum.php?mod=post&action=newthread&fid=$_G['fid']<!--{else}-->forum.php?mod=misc&action=nav<!--{/if}-->" class="iconfont icon-post"></a>
	</div>
</div>
<div id="ct" class="cl bz-anno">
	<div class="mn">
		<div class="bz-anno-appl">
			<div class="tbn">
				<ul id="annonav">
					<li class="{if empty($_GET[m])} a{/if}"><a href="forum.php?mod=announcement">{lang all}</a></li>
				    <!--{loop $months $month}-->
					<li class="{if $_GET[m] == $month[0].$month[1]} a{/if}"><a href="forum.php?mod=announcement&m=$month[0].$month[1]">$month[0] {lang year} $month[1] {lang month}</a></li>
				    <!--{/loop}-->
				</ul>
			</div>
		</div>		
		<div class="bz-p10 bz-bg-fff bzbt1">
			<div id="annofilter"></div>
		    <!--{loop $announcelist $ann}-->
			<div class="bzbb1 bz-anno-li">
				<div>
					<div id="announce$ann[id]_c" class="umh">
						<h3>$ann[subject]</h3>
					</div>
					<div id="announce$ann[id]" class="um color-c">
						$ann[message]
					</div>
				</div>
				<div class="bz-mtb10">
					<p class="color-c">$ann[starttime]&nbsp;{lang author}:$ann[author]</p>
				</div>
			</div>
			<!--{/loop}-->
		</div>
	</div>	
</div>

<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<!--{hook/global_footer_mobile}-->
<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
<!--{template common/footer_nav}-->
</body>
</html>

	
