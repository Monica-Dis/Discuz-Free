<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-header">
	<div class="bz-header-left"><a href="javascript:history.back();" class="iconfont icon-fanhui"></a><a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a></div>
	<h2><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></h2>
	<div class="bz-header-right bzdown">
		<a class="iconfont icon-info"></a>
	</div>
</div>
<div class="bz-b-nava-ziban">
	<div class="bgDiv"></div>
	<div class="downNav">
		<div class="downNav-cancel">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home">&nbsp;{lang return}{lang homepage}</a>
			<!--{eval}-->
			    if($_G['uid']){$favfids = C::t('home_favorite')->fetch_all_by_uid_idtype($_G['uid'], 'fid');foreach($favfids as $val){if($val['id'] == $_G[fid]){$isFav = $val['favid'];}}}
			<!--{/eval}-->
			<!--{if $isFav}-->
				<a href="home.php?mod=space&do=favorite&type=forum" class="forum-del iconfont icon-shoucang2 color-b">&nbsp;&#24050;&#25910;&#34255;</a>
			<!--{else}-->
				<a id="a_favorite" href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" class="forum-fav iconfont icon-shoucang2 color-red">&nbsp;&#25910;&#34255;&#26412;&#29256;</a>
			<!--{/if}-->
			<!--{if empty($_G['forum']['picstyle'])}-->
			<!--{else}-->
			<a{if empty($_G[ 'cookie'][ 'forumdefstyle'])} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="chked iconfont icon-kaiguan-kai color-red" {else} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="unchk iconfont icon-kaiguan-guan color-b" {/if} style="font-size: 12px;">&nbsp;{lang view_thread_imagemode}</a>
			<!--{/if}-->	
		</div>
		<div style="height: 5px; background: #F6F6F6; width: 100%;"></div>
		<div class="downNav-list">
			<!--{if $sublist > 0}-->
	 			<!--{loop $sublist $sub}-->
					<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a>
				<!--{/loop}-->
			<!--{else}-->
			    	<div class="bznodata">
					<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang forum_subforums}</p>
				</div>
			<!--{/if}-->
		</div>
	</div>
</div>

<div id="ct">
	<div class="bz-p10" style="margin: 50px;">
		<div style="text-align: center;">
			<em class="iconfont icon-jianglishuoming" style="font-size: 50px !important; color: #F85857;"></em>
		</div>
		<div class="bz-fd-jinbi cl">
			<div>
				<h3>{lang youneedpay} $paycredits {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit']}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title']} {lang onlyintoforum}</h3>
				<div class="o">
					<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=paysubmit">
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<button class="pn vm" type="submit" name="loginsubmit" value="true"><strong>{lang confirmyourpay}</strong></button>
						&nbsp;
						<button class="pnc vm" type="button" onclick="history.go(-1)"><strong>{lang cancel}</strong></button>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>

<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>