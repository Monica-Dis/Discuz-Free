<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<input type="hidden" name="polls" value="yes" />
<input type="hidden" name="fid" value="$_G[fid]" />

<div class="exfm">
	
	<!--{if $_GET[action] == 'newthread'}-->
	
		  <input type="hidden" name="tpolloption" value="1" />
		  <li class="flexbox bzbt1 align_center">
			  	<span class="name">{lang post_poll_comment}</span>
			  	<span class="flex" style="text-align:right;">
			  		<label for="pollchecked">
			  			<input id="pollchecked" type="checkbox" class="pc" onclick="switchpollm(1)" />
			  			{lang post_single_frame_mode}
			  		</label>
			  	</span>
		  </li>
		  <div id="pollm_c_1" class="mbm">
			    <span id="polloption_new"></span>
			    <div id="polloption_hidden" style="display: none">
				      <span class="name">
					      	{lang post_poll_options}
					      	<a class="up bzpollpic" id="pollUploadProgress">
					      		<i class="iconfont icon-camera"></i>
					      	</a>
				      </span>
				      <span class="html flex"><input type="text" name="polloption[]" style="text-indent: 0px;"/></span> 
				      <span>
				        		<a href="javascript:;" class="d color-b" onclick="delpolloption(this)"><i class="iconfont icon-guanbi"></i></a>
				      </span>
			    </div>
		    		<li class="flexbox bz-bg-fff bzbt1 Piece">
		    			<a href="javascript:;" onclick="addpolloption()" style="display:block; width:100%;color: #999;">+{lang post_poll_add}</a>
		    		</li>
		  </div>
		  <div style="display:none" id="pollm_c_2">
			  <li class="flexbox bz-bg-fff bzbt1" >
				  <span class="flex">
				 	 <textarea name="polloptions" class="pt" style="height:100px;width:100%;border:0" onchange="switchpollm(0)" /></textarea>
				  </span>
			  </li>
		  	  <li class="flexbox bzbt1 bz-bg-fff"><span class="name">{lang post_poll_comment_s}</span></li>
		  </div>
	            
	<!--{else}-->
	
		  <li class="flexbox bzbt1 align_center"><span class="name">{lang post_poll_comment}</span></li>
		  <!--{loop $poll['polloption'] $key $option}-->
		  <!--{eval $ppid = $poll['polloptionid'][$key];}-->
		  <input type="hidden" name="polloptionid[{$poll[polloptionid][$key]}]" value="$poll[polloptionid][$key]" />
		  <li class="flexbox bz-bg-fff bzbt1">
			    <span class="name">{lang post_poll_options}
				      <a class="up" style="" id="pollUploadProgress_{$key}">
						    <!--{if $poll[imginfo][$ppid][small]}-->
						      <i data-id=""><img src="$poll[imginfo][$ppid][small]" /></i>
						    <!--{else}-->
						      <i class="iconfont icon-camera"></i>
						    <!--{/if}-->
				      </a>
			    </span>
			    <span class="html flex">
			    		<input type="text" value="$option" name="polloption[$poll[polloptionid][$key]}]" style="text-indent: 0px;">
			    </span> 
			    <span>
			        <a href="javascript:;" class="d color-b" onclick="delpolloption(this)"><i class="iconfont icon-guanbi"></i></a>
			    </span>
		  </li>
		  <!--{/loop}-->
		  <span id="polloption_new"></span>
		  <div id="polloption_hidden" style="display: none">
			    <span class="name">
				    	{lang post_poll_options}
				    	<a class="up bzpollpic" id="pollUploadProgress"><i class="iconfont icon-camera"></i>
				        <input type="file" name="Filedata" class="pollfiledata" id="newpoll" style="width:25px; height:25px;">
				    </a>
			    </span>
			    <span class="html flex"><input type="text" name="polloption[]" class="px" style="text-indent: 0px;"/></span> 
			    <span>
			      	<a href="javascript:;" class="d color-b" onclick="delpolloption(this)"><i class="iconfont icon-guanbi"></i></a>
			    </span>
		  </div>
	  	  <li class="flexbox bz-bg-fff bzbt1 Piece">
	  	  		<a href="javascript:;" onclick="addpolloption()" style="display:block; width:100%;">+{lang post_poll_add}</a>
	  	  </li>
	  	  
	<!--{/if}-->
	
	  	  <div class="banzhuan-h10 bzbt1"></div>
		  <li class="flexbox bzbt1 bz-bg-fff"><span class="name">{lang post_poll_allowmultiple}</span><span class="html flex"><dl class="flexbox"><input type="text" name="maxchoices" id="maxchoices" class="px pxs" value="{if $_GET[action] == 'edit' && $poll[maxchoices]}$poll[maxchoices]{else}1{/if}"/> {lang post_option}</dl></span></li>
		  <li class="flexbox bzbt1 bz-bg-fff"><span class="name">{lang post_poll_expiration}</span><span class="html flex"><dl class="flexbox"><input type="text" name="expiration" id="polldatas" class="px pxs" value="{if $_GET[action] == 'edit'}{if !$poll[expiration]}0{elseif $poll[expiration] < 0}{lang poll_close}{elseif $poll[expiration] < TIMESTAMP}{lang poll_finish}{else}{echo (round(($poll[expiration] - TIMESTAMP) / 86400))}{/if}{/if}" tabindex="1" /> {lang days}</dl></span></li>
		  <li class="flexbox bzbt1 bz-bg-fff"><span class="name">{lang poll_after_result}</span><span class="html flex"><input type="checkbox" name="visibilitypoll" id="visibilitypoll" class="pc y" value="1"{if $_GET[action] == 'edit' && !$poll[visible]} checked{/if} /></span></li>
		  <li class="flexbox bzbt1 bz-bg-fff"><span class="name">{lang post_poll_overt}</span><span class="html flex"><input type="checkbox" name="overt" id="overt" class="pc y" value="1"{if $_GET[action] == 'edit' && $poll[overt]} checked{/if} tabindex="1" /></span></li>

</div>

<script>
	var maxoptions = parseInt('$_G[setting][maxpolloptions]');
	var uploader_poll = WebUploader.create({
		server: 'misc.php?mod=swfupload&action=swfupload&operation=poll&fid=$_G[fid]',
		formData: {uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
		fileVal: 'Filedata',
		auto: true,
		accept: {
			title: 'Files',
			extensions: 'gif,jpg,jpeg,bmp,png',
			mimeTypes:'image/*,text/plain,application/msword,application/octet-stream,application/vnd.ms-excel,application/x-shockwave-flash'
		}
	}); 
	
	uploader_poll.on('fileQueued', function(file) {
		var bar = $('#rt_'+file.source.ruid).parent();
		$(bar).find('i').attr('data-id','');
		$(bar).find('i').html('<img src="template/banzhuan_touch026/touch/banzhuan/images/loading.gif" style="height:20px;width:20px;"><i class="Progress"></i>');
	});
	
	uploader_poll.on('uploadSuccess', function(file, s) {
		var bar = $('#rt_'+file.source.ruid).parent();
		if(s.aid) {
			$(bar).find('i').html('<img src="'+s.smallimg+'" style="height:20px;width:20px;"><input type="hidden" name="pollimage[]" value="'+s.aid+'">');
		}
	});
	
	
	<!--{if $_GET[action] == 'newthread'}-->
		var curoptions = 0;
		var curnumber = 1;
		addpolloption();
		addpolloption();
		addpolloption();
	<!--{else}-->
	var curnumber = curoptions = <!--{echo count($poll['polloption'])}-->;
		for(var i=0; i < curnumber; i++) {
			uploader_poll.addButton({id:'#pollUploadProgress_'+i});
		}
	<!--{/if}-->
	
	function addpolloption() {
		if(curoptions < maxoptions) {
			var imgid = 'newpoll_'+curnumber;
			var proid = 'pollUploadProgress_'+curnumber;
			var pollstr = $('#polloption_hidden').html().replace('newpoll', imgid);
			pollstr = pollstr.replace('pollUploadProgress', proid);
			$('#polloption_new').append('<li class="flexbox bz-bg-fff bzbt1">' + pollstr + '</li>');
			curoptions++;
			curnumber++;
			uploader_poll.addButton({id:'#'+proid});  
		} else {
			popup.open('<span>\u5df2\u8fbe\u5230\u6700\u5927\u6295\u7968\u6570'+maxoptions+'</span>');
		}
	}
	
	
	function switchpollm(swt) {
		t = document.getElementById('pollchecked').checked && swt ? 2 : 1;
		var v = '';
		for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
			var e = document.getElementById('postform').elements[i];
			if(!isUndefined(e.name)) {
				if(e.name.match('^polloption')) {
					if(t == 2 && e.tagName == 'INPUT') {
						v += e.value + '\n';
					} else if(t == 1 && e.tagName == 'TEXTAREA') {
						v += e.value;
					}
				}
			}
		}
		if(t == 1) {
			var a = v.split('\n');
			var pcount = 0;
			for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
				var e = document.getElementById('postform').elements[i];
				if(!isUndefined(e.name)) {
					if(e.name.match('^polloption')) {
						pcount++;
						if(e.tagName == 'INPUT') e.value = '';
					}
				}
			}
			for(var i = 0; i < a.length - pcount + 2; i++) {
				addpolloption();
			}
			var ii = 0;
			for(var i = 0; i < document.getElementById('postform').elements.length; i++) {
				var e = document.getElementById('postform').elements[i];
				if(!isUndefined(e.name)) {
					if(e.name.match('^polloption') && e.tagName == 'INPUT' && a[ii]) {
						e.value = a[ii++];
					}
				}
			}
		} else if(t == 2) {
			document.getElementById('postform').polloptions.value = trim(v);
	
		}
		document.getElementById('postform').tpolloption.value = t;
		if(swt) {
			display('pollm_c_1');
			display('pollm_c_2');
		}
	}
	function trim(str) {
		return (str + '').replace(/(\s+)$/g, '').replace(/^\s+/g, '');
	}
	function display(id) {
		var obj = document.getElementById(id);
		if(obj.style.visibility) {
			obj.style.visibility = obj.style.visibility == 'visible' ? 'hidden' : 'visible';
		} else {
			obj.style.display = obj.style.display == '' ? 'none' : '';
		}
	}
	function delpolloption(obj) {
		obj.parentNode.parentNode.parentNode.removeChild(obj.parentNode.parentNode);
		curoptions--;
	}
</script>