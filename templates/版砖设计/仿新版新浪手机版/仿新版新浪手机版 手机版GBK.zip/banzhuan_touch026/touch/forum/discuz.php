<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:portal.php?mod=index&mobile=2');exit;}-->
<!--{/if}-->
<!--{template common/header}-->

<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<!--{if $_GET['visitclient']}-->

<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->

<!--{if $showvisitclient}-->

<div class="visitclienttip vm" style="display:block;">
	<a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>	
	<p>{lang downloadzslttoshareview}</p>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
		$('.visitclienttip').css('display', 'block');
	}
</script>

<!--{/if}-->

<!--{hook/index_top_mobile}-->
<!--{if empty($gid)}-->
<div id="chart" class="cl bz-bg-fff bz-p10">
	<ul>
		<li>
			<span>{lang index_today}</span>
			<em>$todayposts</em>
		</li>
		<li>
			<span>{lang index_posts}</span>
			<em>$posts</em>
		</li>
		<li>
			<span>{lang index_members}</span>
			<em>$_G['cache']['userstats']['totalmembers']</em>
		</li>
	</ul>
</div>
<!--{/if}-->
<!--{if empty($gid) && $announcements}-->
<div class="bz-p10 bz-bg-fff bzbb1">
	<div class="announcement">
	    <div class="z"><i class="iconfont icon-tongzhigonggao color-red"></i></div>
	    <ul id="ancl">$announcements</ul>
	</div>
</div>
<script>
  setInterval(function(){
	  $('#ancl li:last').css({'height':'0px','opacity': '0'}).insertBefore('#ancl li:first').animate({'height':'44px','opacity': '1'}, 'slow', function(){
          $(this).removeAttr('style');
      });
  },3000);
</script>
<!--{/if}-->

<div class="bz-mt10" id="wp">
	<!--{loop $catlist $key $cat}-->
	<div class="bz-mb10 banzhuan-clear">
		<div class="bz-sub-show bzbb1 cl <!--{if !$_G[setting][mobile][mobileforumview]}--><!--{else}-->bz-sub-close<!--{/if}-->" href="#sub_forum_$cat[fid]">
	    		<h2><code></code><a href="javascript:;">$cat[name]</a></h2>
	    </div>
		<div id="sub_forum_$cat[fid]" class="sub_forum">
			<ul>
				<!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->
				<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
				<li>
					<div class="gengduo"><i class="iconfont icon-gengduo"></i></div>
					<div class="name-pic">
	                    <!--{if $forum[icon]}-->
	                        {$forum[icon]}
	                    <!--{else}-->
	                        <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
	                            <span class="nopic" style="width:100%; height:100%;"></span>
	                        </a>
	                    <!--{/if}-->
				    </div>
                    	<div class="name-tit">
                    		<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                    			<span>{$forum[name]}</span>
                    			<!--{if $forum[todayposts] > 0}-->
                    	        	<p style="color: #F74C31;">{lang index_today}: $forum[todayposts] / {lang forum_threads} <!--{echo dnumber($forum[threads])}--> / {lang posts} <!--{echo dnumber($forum[posts])}--></p>
                    	        <!--{else}-->
                    	        	<p>{lang forum_threads} <!--{echo dnumber($forum[threads])}--> / {lang posts} <!--{echo dnumber($forum[posts])}--></p>
                    	        	<!--{/if}-->
                    	    </a>
                    	</div>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{/loop}-->
</div>
<!--{if empty($gid) && ($_G['cache']['forumlinks'][0] || $_G['cache']['forumlinks'][1] || $_G['cache']['forumlinks'][2])}-->
<div class="banzhuan-clear">
	<div class="bz-sub-show cl">
    		<h2><a href="javascript:;">&#21451;&#24773;&#38142;&#25509;</a></h2>
    </div>
	<div id="category_lk">
		<!--{if $_G['cache']['forumlinks'][0]}-->
		<ul class="m cl 0">$_G['cache']['forumlinks'][0]</ul>
		<!--{/if}-->
		<!--{if $_G['cache']['forumlinks'][1]}-->
		<div class="n cl 1">
			$_G['cache']['forumlinks'][1]
		</div>
		<!--{/if}-->
		<!--{if $_G['cache']['forumlinks'][2]}-->
		<ul class="x cl 2">
			$_G['cache']['forumlinks'][2]
		</ul>
		<!--{/if}-->
	</div>
</div>
<!--{/if}-->
<!--{hook/index_middle_mobile}-->
<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			$('.sub_forum').css('display', 'block');
		<!--{else}-->
			$('.sub_forum').css('display', 'none');
		<!--{/if}-->
		$('.bz-sub-show').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
			subobj.css('display', 'block');
			obj.removeClass('bz-sub-close');
			} else {
			subobj.css('display', 'none');
			obj.addClass('bz-sub-close');
			}
		});
	 })();
</script>
<!--{/if}-->
<div class="banzhuan-clear"></div>
<!--{template common/footer}-->

