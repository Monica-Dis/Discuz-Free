<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{eval $nofooter = 1; $post = $thread2 = reset($postlist); $pid = $post[pid]; $postcount = 0;}-->
<!--{template common/header}-->
<div class="bz-thread-share"><div class="bgDiv"></div><div class="upNav"></div></div>
<div class="bz-header">
	<div class="bz-header-left"><a href="javascript:history.back();" class="iconfont icon-fanhui"><em>$_G['setting']['sitename']</em></a></div>
	<h2></h2>
	<div class="bz-header-right"><a class="iconfont icon-more bzdown"></a></div>
</div>
<!--{hook/viewthread_top_mobile}-->
<div class="banzhuan-clear"></div>
<div class="postlist bz-bg-fff banzhuan-view-bg overflow">
	<h2>
		<!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
                [{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]
	    <!--{/if}-->
			$_G[forum_thread][subject]
        <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
        <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
        <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
        <!--{/if}-->
	</h2>
	<div class="banzhuan-view-bg-em">
        <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
		    <em class="y color-c">#{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}</em>
        <!--{/if}-->
        	<em class="z color-c">{lang show} $_G[forum_thread][views]&nbsp;&nbsp;&nbsp;</em>
        <em class="z color-c">{lang reply} $_G[forum_thread][allreplies]</em>
    </div>	
	<div class="banzhuan-clear"></div>
	<ul class="bz-bg-fff">
		
	<!--{loop $postlist $post}-->
	
		<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
		<!--{hook/viewthread_posttop_mobile $postcount}-->
		
			<div class="banzhuan-clear">
				<!--{if $_G['forum']['ismoderator']}-->
					<!--{if $post[first]}-->
				    <ul class="menu" data-menu data-menu-toggle="#menu-toggle2">
				    	      <!--{if !$_G['forum_thread']['special']}-->
						  <li><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><i class="iconfont icon-post"></i>&nbsp;{lang edit}</a></li>
						  <!--{/if}-->
						  <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}"><i class="iconfont icon-delete"></i>&nbsp;{lang delete}</a></li>
						  <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4"><i class="iconfont icon-quxiaoguanzhu"></i>&nbsp;{lang close}</a></li>
						  <li><a class="dialog" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"><i class="iconfont icon-attention"></i>&nbsp;{lang admin_banpost}</a></li>
						  <li><a class="dialog" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"><i class="iconfont icon-jubao"></i>&nbsp;{lang topicadmin_warn_add}</a></li>
				    </ul>
				    <!--{else}-->
				    <ul class="menu" data-menu data-menu-toggle="#menu-toggle1">
					      <li><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><i class="iconfont icon-post"></i>&nbsp;{lang edit}</a></li>
					      <!--{if $_G['group']['allowdelpost']}-->
					      <li><a class="dialog" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><i class="iconfont icon-delete"></i>&nbsp;{lang modmenu_deletepost}</a></li>
					      <!--{/if}-->
					      <!--{if $_G['group']['allowbanpost']}-->
					      <li><a class="dialog" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><i class="iconfont icon-attention"></i>&nbsp;{lang modmenu_banpost}</a></li>
					      <!--{/if}-->
					      <!--{if $_G['group']['allowwarnpost']}-->
					      <li><a class="dialog" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><i class="iconfont icon-jubao"></i>&nbsp;{lang modmenu_warn}</a></li>
					      <!--{/if}-->
				    </ul>
				    <!--{/if}-->
			    <!--{/if}-->
			</div>
		
		<!--{if $post[first]}-->
		
		    <div class="plc cl banzhuan-clear bz-bg-fff" id="pid$post[pid]">
		       <div class="display pi" href="#replybtn_$post[pid]">
		       	
		           <div class="cl" style="position: relative;">
			           <span class="avatar"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, middle, true)}--><!--{else}--><!--{avatar($post[authorid], middle, true)}--><!--{/if}-->" /></span>
					   <ul class="authi">
						   <li class="grey">
								<div class="y">
									<div>
									    <!--{if $_G['forum']['ismoderator']}-->
										<a href="javascript:;" id="menu-toggle2" class="bz-vt-manage color-b"><i class="iconfont icon-icon09"></i>{lang manage}</a>
									    <!--{/if}-->
										<a>&#27004;&#20027;</a>
									</div>
									<div class="cl">
										
										<!--{hook/viewthread_postfooter $postcount}-->
						
										<!--{if $_G['setting']['magicstatus']}-->
											<ul id="mgc_post_$post[pid]_menu" class="p_pop mgcmn" style="display: none;">
											<!--{if $post['first']}-->
												<!--{if !empty($_G['setting']['magics']['bump'])}-->
													<li><a href="home.php?mod=magic&mid=bump&idtype=tid&id=$_G[tid]" id="a_bump" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/bump.small.gif" />$_G['setting']['magics']['bump']</a></li>
												<!--{/if}-->
												<!--{if !empty($_G['setting']['magics']['stick'])}-->
													<li><a href="home.php?mod=magic&mid=stick&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/stick.small.gif" />$_G['setting']['magics']['stick']</a></li>
												<!--{/if}-->
												<!--{if !empty($_G['setting']['magics']['close'])}-->
													<li><a href="home.php?mod=magic&mid=close&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/close.small.gif" />$_G['setting']['magics']['close']</a></li>
												<!--{/if}-->
												<!--{if !empty($_G['setting']['magics']['open'])}-->
													<li><a href="home.php?mod=magic&mid=open&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/open.small.gif" />$_G['setting']['magics']['open']</a></li>
												<!--{/if}-->
												<!--{if !empty($_G['setting']['magics']['highlight'])}-->
													<li><a href="home.php?mod=magic&mid=highlight&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/highlight.small.gif" />$_G['setting']['magics']['highlight']</a></li>
												<!--{/if}-->
												<!--{if !empty($_G['setting']['magics']['sofa'])}-->
													<li><a href="home.php?mod=magic&mid=sofa&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/sofa.small.gif" />$_G['setting']['magics']['sofa']</a></li>
												<!--{/if}-->
												<!--{if !empty($_G['setting']['magics']['jack'])}-->
													<li><a href="home.php?mod=magic&mid=jack&idtype=tid&id=$_G[tid]" id="a_jack" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/jack.small.gif" />$_G['setting']['magics']['jack']</a></li>
												<!--{/if}-->
												<!--{hook/viewthread_magic_thread}-->
											<!--{/if}-->
											<!--{if !empty($_G['setting']['magics']['repent']) && $post['authorid'] == $_G['uid'] && !$rushreply}-->
												<li><a href="home.php?mod=magic&mid=repent&idtype=pid&id=$post[pid]:$_G[tid]" id="a_repent_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/repent.small.gif" />$_G['setting']['magics']['repent']</a></li>
											<!--{/if}-->
											<!--{if !empty($_G['setting']['magics']['anonymouspost']) && $post['authorid'] == $_G['uid']}-->
												<li><a href="home.php?mod=magic&mid=anonymouspost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_anonymouspost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/anonymouspost.small.gif" />$_G['setting']['magics']['anonymouspost']</a><li>
											<!--{/if}-->
											<!--{if !empty($_G['setting']['magics']['namepost'])}-->
												<li><a href="home.php?mod=magic&mid=namepost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_namepost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/namepost.small.gif" />$_G['setting']['magics']['namepost']</a><li>
											<!--{/if}-->
											<!--{hook/viewthread_magic_post $postcount}-->
											</ul>
										<!--{/if}-->
									</div>
								</div>
								<b class="bz-small">
									<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
										<a href="home.php?mod=space&uid=$post[authorid]&do=profile&mobile=2">$post[author]<em>$post[authortitle]</em>
											 <!--{if $post[gender] == 0}-->
					                         <!--{elseif $post[gender] == 1}-->
					                  	     <i class="iconfont icon-shouyezhuyetubiao06 color-nan"></i>
					                        	 <!--{elseif $post[gender] == 2}-->
					                  	     <i class="iconfont icon-iconfontshouyezhuyetubiao07 color-nv"></i>
					                         <!--{/if}--> 
				                         </a>	
									<!--{else}-->
										<!--{if !$post['authorid']}-->
										<a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
										<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
											<!--{if $_G['forum']['ismoderator']}-->
											<a href="javascript:;">{lang anonymous}</a>
											<!--{else}-->
											{lang anonymous}
											<!--{/if}-->
										<!--{else}-->
										$post[author] <em>{lang member_deleted}</em>
										<!--{/if}-->
									<!--{/if}-->
								</b>
						   </li>
						   <li class="grey rela">
								<!--{if $_G['forum']['ismoderator']}-->
								<!--{if $post[first]}-->
									<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
										<!--{if !$_G['forum_thread']['special']}-->
										<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
										<!--{/if}-->
										<input type="button" value="{lang delete}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
										<input type="button" value="{lang close}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
										<input type="button" value="{lang admin_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
										<input type="button" value="{lang topicadmin_warn_add}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
									</div>
								<!--{else}-->
									<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
										<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
										<!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
										<!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
										<!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
									</div>
								<!--{/if}-->
								<!--{/if}-->
								$post[dateline]
							</li>
		                </ul>
		           </div>
		           
		           <div class="message">
						<p>
		                	   <!--{if $post['warned']}-->
		                        <span class="color-c quote">{lang warn_get}</span>
		                    <!--{/if}-->
		                    
		                    <!--{if !$post['first'] && !empty($post[subject])}-->
		                        <h2><strong>$post[subject]</strong></h2>
		                    <!--{/if}-->
		                     
		                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
		                        <div class="color-c quote">{lang message_banned}</div>
		                    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
		                        <div class="color-c quote">{lang message_single_banned}</div>
		                    <!--{elseif $needhiddenreply}-->
		                        <div class="color-c quote">{lang message_ishidden_hiddenreplies}</div>
		                    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
								<!--{template forum/viewthread_pay}-->
							<!--{else}-->
							
		                    	   <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
		                            <div class="color-c quote">{lang admin_message_banned}</div>
		                        <!--{elseif $post['status'] & 1}-->
		                            <div class="color-c quote">{lang admin_message_single_banned}</div>
		                        <!--{/if}-->
		                        
		                        <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
		                        <!--{/if}-->
		
		                        <!--{if $post['first'] && $threadsort && $threadsortshow}-->
		                        	   <!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
		                                <!--{if $threadsortshow['optionlist'] == 'expire'}-->
		                                    {lang has_expired}
		                                <!--{else}-->
		                                    <div class="box_ex2 viewsort">
									            <div class="bz-at-form bz-mtb10">
									            	<h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
													<table cellpadding="0" cellspacing="1" border="0">
											            <!--{loop $threadsortshow['optionlist'] $option}--> 
											            <!--{if $option['type'] != 'info'}-->
														<tr>
															<th>$option[title]:</th>
															<td>
																<!--{if $option['value']}-->
																<!--{eval preg_match("/(".str_replace("/",'\/',$_G['setting']['attachurl']).")(.*?)((.gif)|(.jpg)|(.jpeg)|(.bmp)|(.png))/",strtolower($option['value']),$dzlab_match);}-->
																	<!--{if count($dzlab_match)}-->
																	<img src='$dzlab_match[0]' />
																	<!--{else}-->
																	$option[value] 
																	<!--{/if}-->
																    $option[unit]
																<!--{else}-->
																No data
																<!--{/if}-->
															</td>
														</tr>
											            <!--{/if}-->
											            <!--{/loop}-->
									              	</table>
											    </div>
		                                    </div>
		                                <!--{/if}-->
		                            <!--{/if}-->
		                        <!--{/if}-->
		                         
		                        <!--{if $post['first']}-->
		                        
		                            <!--{if !$_G[forum_thread][special]}-->
		                                $post[message]
		                            <!--{elseif $_G[forum_thread][special] == 1}-->
		                                <!--{template forum/viewthread_poll}-->
		                            <!--{elseif $_G[forum_thread][special] == 2}-->
		                                <!--{template forum/viewthread_trade}-->
		                            <!--{elseif $_G[forum_thread][special] == 3}-->
		                                <!--{template forum/viewthread_reward}-->
		                            <!--{elseif $_G[forum_thread][special] == 4}-->
		                                <!--{template forum/viewthread_activity}-->
		                            <!--{elseif $_G[forum_thread][special] == 5}-->
		                                <!--{template forum/viewthread_debate}-->
		                            <!--{elseif $threadplughtml}-->
		                                $post[message]
		                            <!--{else}-->
		                            	$post[message]
		                            <!--{/if}-->
		                            
		                        <!--{else}-->
		                            $post[message]
		                        <!--{/if}-->
		
		
		
							<!--{/if}-->
		
							</p>
					</div>
		
		           <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
					
					   <!--{if $post['attachment']}-->
						
			               <div class="color-c quote">
			                   {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
			               </div>
			              
			            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
			           
			                <!--{if $post['imagelist']}-->
							<!--{if count($post['imagelist']) == 1}-->
							<ul class="img_one">{echo showattach($post, 1)}</ul>
							<!--{else}-->
							<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
							<!--{/if}-->
							<!--{/if}-->
			                <!--{if $post['attachlist']}-->
							<ul>{echo showattach($post)}</ul>
							<!--{/if}-->
							
						<!--{/if}-->
					
					<!--{/if}-->
		
				    <!--{if $post['first'] && ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
					    <div class="bz-vt-tag">
					    	    <i class="iconfont icon-tag"></i>
						    <!--{if $post[tags]}-->
								<!--{eval $tagi = 0;}-->
								<!--{loop $post[tags] $var}-->
									<!--{if $tagi}-->, <!--{/if}--><a title="$var[1]" href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
									<!--{eval $tagi++;}-->
								<!--{/loop}-->
							<!--{/if}-->
							<!--{if $relatedkeywords}--><span>$relatedkeywords</span><!--{/if}-->
						</div>
					<!--{/if}-->
		
		          </div>
		    </div>

            <!--{if !IS_ROBOT && $post['first'] && !$_G['forum_thread']['archiveid']}-->
					<!--{if $post['invisible'] == 0}-->
						<div id="p_btn" class="bzbt1 banzhuan-clear">
							<!--{hook/viewthread_useraction}-->
							<!--{if $post['authorid'] != $_G['uid'] }-->
								<a href="misc.php?mod=report&rtype=post&rid=$pid&tid=$_G[tid]&fid=$_G[fid]" class="dialog color-b"><span><i class="iconfont icon-jubao"></i>{lang report}</span></a>
							<!--{/if}-->
						</div>
					    <div class="bz-t-ad">
		                    <!--{ad/interthread/a_p hm/$postcount}-->
		                </div>
		                <div class="banzhuan-h10 bz-bg-f5f5f5"></div>
		                <div class="bz-p10 bz-vt-ln bzbt1 bzbb1 bz-bg-fff">
					    	   <ul>
					    	    	   <li><a href="forum.php?mod=redirect&goto=nextoldset&tid=$_G[tid]"><i class="iconfont icon-fanhui1"></i>{lang last_thread}</a></li>
					    	    	   <li><a href="forum.php?mod=redirect&goto=nextnewset&tid=$_G[tid]">{lang next_thread}<i class="iconfont icon-gengduo"></i></a></li>
					    	   </ul>
				        </div>
			                <!--{if $post['relateitem']}-->
			                <div class="banzhuan-h10 bz-bg-f5f5f5"></div>
							<div class="bz-p10 bzvtre bzbt1 bzbb1">
								<h3>&nbsp;&nbsp;{lang related_thread}</h3>
								<ul class="cl">
									<!--{loop $post['relateitem'] $var}-->
									<li><a href="forum.php?mod=viewthread&tid=$var[tid]">$var[subject]</a></li>
									<!--{/loop}-->
								</ul>
							</div>
			                <!--{/if}-->
					<!--{/if}-->
			<!--{/if}-->
		    <!--{hook/viewthread_postbottom_mobile $postcount}-->
		    <div class="banzhuan-h10 bz-bg-f5f5f5"></div>
		    <div class="replaytitle bz-bg-fff bzbt1 bz-ptb10">
			    <div class="rtit bz-plr10">
		        	        <a class="color-34" style="font-size: 16px; float: left; font-weight: 100;">{lang all}{lang reply}</a>
		            <!--{if $ordertype != 1}-->
		                <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1" class="iconfont icon-daoxu" style="margin-left: 20px;"> {lang post_descview}</a>
		            <!--{else}-->
		                <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2" class="iconfont icon-shunxu" style="margin-left: 20px;"> {lang post_ascview}</a>
		            <!--{/if}-->
		            <!--{if $post[first] && $post['authorid'] && $post['username'] && !$post['anonymous']}-->
				    <!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
		                <a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&authorid=$_G[forum_thread][authorid]" rel="nofollow" class="iconfont icon-attention"> {lang viewonlyauthorid}</a>
		            <!--{elseif !$_G['forum_thread']['archiveid']}-->
		                <a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page" rel="nofollow" class="iconfont icon-attention"> {lang thread_show_all}</a>
		            <!--{/if}-->
		            <!--{/if}-->
			    </div>
		    </div> 
			    
	    <!--{else}-->
	           
		        <li class="bzbb1 banzhuan-clear replcli bz-bg-fff" id="pid$post[pid]" href="#replybtn_$post[pid]">
					<!--{if !$post['authorid'] || $post['anonymous']}-->
					<a class="avatar"><img src="<!--{avatar(0, middle, true)}-->" /></a>
					<!--{else}-->
					<a href="home.php?mod=space&uid=$post[authorid]&do=profile&mobile=2" class="avatar"><img src="<!--{avatar($post[authorid], middle, true)}-->" /></a>
					<!--{/if}-->
					<h3>
						<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
							<a href="home.php?mod=space&uid=$post[authorid]&do=profile&mobile=2">$post[author]</a>
								<b class="bz-small"><a><em>$post[authortitle]</em></a></b>
								<!--{if $post[gender] == 0}-->
						        <!--{elseif $post[gender] == 1}-->
						            <i class="iconfont icon-shouyezhuyetubiao06 color-nan"></i>
						        <!--{elseif $post[gender] == 2}-->
						            <i class="iconfont icon-iconfontshouyezhuyetubiao07 color-nv"></i>
						        <!--{/if}-->
						<!--{else}-->
							<!--{if !$post['authorid']}-->
								<a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
							<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
								<!--{if $_G['forum']['ismoderator']}-->
									<a href="javascript:;">{lang anonymous}</a>
								<!--{else}-->
									{lang anonymous}
								<!--{/if}-->
							<!--{else}-->
									$post[author] <em>{lang member_deleted}</em>
							<!--{/if}-->
						<!--{/if}-->
						<span class="y color-b">$post[dateline]</span>
					</h3>
					<div class="message">
						<p>
			                	   <!--{if $post['warned']}-->
			                        <span class="color-c quote">{lang warn_get}</span>
			                    <!--{/if}-->
			                    
			                    <!--{if !$post['first'] && !empty($post[subject])}-->
			                        <h2><strong>$post[subject]</strong></h2>
			                    <!--{/if}-->
			                     
			                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
			                        <div class="color-c quote">{lang message_banned}</div>
			                    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
			                        <div class="color-c quote">{lang message_single_banned}</div>
			                    <!--{elseif $needhiddenreply}-->
			                        <div class="color-c quote">{lang message_ishidden_hiddenreplies}</div>
			                    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
									<!--{template forum/viewthread_pay}-->
								<!--{else}-->
								
				                    	   <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
				                            <div class="color-c quote">{lang admin_message_banned}</div>
				                        <!--{elseif $post['status'] & 1}-->
				                            <div class="color-c quote">{lang admin_message_single_banned}</div>
				                        <!--{/if}-->
				                        
				                        $post[message]
			
								<!--{/if}-->
			
						</p>
						<p>
						    <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
							   <!--{if $post['attachment']}-->
					               <div class="color-c quote">
					                   {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
					               </div>
					            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
					                <!--{if $post['imagelist']}-->
										<!--{if count($post['imagelist']) == 1}-->
										<ul class="img_one">{echo showattach($post, 1)}</ul>
										<!--{else}-->
										<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
										<!--{/if}-->
									<!--{/if}-->
					                <!--{if $post['attachlist']}-->
									<ul>{echo showattach($post)}</ul>
									<!--{/if}-->
								<!--{/if}-->
							<!--{/if}-->
						</p>
					</div>
					<div class="cl bz-replc-list-a">
						<a class="color-b" style="float: left;margin-left: 0;">
							<span>
							<!--{if isset($post[isstick])}-->
								<img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> {lang from} {$post[number]}{$postnostick}
							<!--{elseif $post[number] == -1}-->
								{lang recommend_post}
							<!--{else}-->
								<!--{if !empty($postno[$post[number]])}-->
								    $postno[$post[number]]
								<!--{else}-->
								    {$post[number]}&nbsp;&#27004;
								<!--{/if}-->
							<!--{/if}-->
							</span>
						</a>
						<!--{if $_G['forum']['ismoderator']}-->
						<!--{if !$post[first]}-->
						<!--<a href="javascript:;" id="menu-toggle1" class="color-b" style="float: left;"><span><i class="iconfont icon-icon09"></i>{lang manage}</span></a>-->
						<!--{/if}-->	
						<!--{/if}-->	
						<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
						<a class="replyadd color-c" href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" onmouseover="this.title = ($('review_support_$post[pid]').innerHTML ? $('review_support_$post[pid]').innerHTML : 0) + ' {lang activity_member_unit} {lang support_reply}'">
							<span id="review_support_$post[pid]">$post[postreview][support]</span>
							<span><i class="iconfont icon-appreciatelight"></i></span>
						</a>
						<!--{/if}-->	
						<!--{if $post['invisible'] == 0}-->
							<!--{if (!$_G['uid'] || $allowpostreply) && !$needhiddenreply}-->
								<!--{if !$post['first']}-->
									<a class="fastre color-c" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page"><span><i class="iconfont icon-comment"></i></span></a>
								<!--{/if}-->
							<!--{/if}-->	
							<!--{if !$post[first]}-->
								<!--{if $post['authorid'] != $_G['uid'] }-->
									<a href="misc.php?mod=report&rtype=post&rid=$pid&tid=$_G[tid]&fid=$_G[fid]" class="dialog color-c"><span><i class="iconfont icon-jubao"></i></span></a>
								<!--{/if}-->
							<!--{/if}-->				
						<!--{/if}-->
						
						<!--{if $_G['forum']['ismoderator']}-->
							<!--{if $post[first]}-->
								<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
									<!--{if !$_G['forum_thread']['special']}-->
										<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
									<!--{/if}-->
										<input type="button" value="{lang delete}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
										<input type="button" value="{lang close}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
										<input type="button" value="{lang admin_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
										<input type="button" value="{lang topicadmin_warn_add}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
								</div>
							<!--{else}-->
								<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
									<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
									<!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
									<!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
									<!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
								</div>
							<!--{/if}-->
						<!--{/if}-->
												
						<!--{hook/viewthread_postfooter $postcount}-->
						
					</div>
				</li>
				
                 <!--{hook/viewthread_postbottom_mobile $postcount}-->
	    
	    <!--{/if}-->
	    
        <!--{eval $postcount++;}-->
    <!--{/loop}-->
    
    <!--{if count($postlist)<2}-->
        	<div class="guide-no">
			<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
			<p class="color-b">&#26242;&#26080;&#35780;&#35770;,&#24555;&#26469;&#25250;&#27801;&#21457;</p>
		</div>
    <!--{/if}-->
    </ul>
    
    $multipage
    
	<div class="bz-b-nava">
		<div class="bgDiv"></div>
		<div class="downNav">
			<div id="downNav-list">
				<a class="iconfont icon-zihao"></a>
				<a href="#" id="bzsmall">A</a>
				<a href="#" id="bzmedium" class="selected">A</a>
				<a href="#" id="bzlarge">A</a>
			</div>
			<div class="downNav-list">
				<a class="iconfont icon-fenxiang1" style="font-size: 40px;"></a>
				<a class="iconfont icon-weixin2 bzup"></a>
				<a id="ckepop" class="jiathis_button_cqq iconfont icon-qq1"></a>
				<a id="ckepop" class="jiathis_button_tsina iconfont icon-weibo"></a>
				<a id="ckepop" class="jiathis_button_qzone iconfont icon-kongjian2"></a>
			</div>
			<div class="list">
				<a href="<!--{if $_GET[fromguid] == 'hot'}-->forum.php?mod=guide&view=hot&page=$_GET[page]<!--{else}-->forum.php?mod=forumdisplay&fid=$_G[fid]&<!--{eval echo rawurldecode($_GET[extra]);}--><!--{/if}-->">{lang return_list}</a>
				<a href="portal.php?mod=index&mobile=2">{lang return}{lang homepage}</a>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="http://v3.jiathis.com/code/jia.js" charset="utf-8"></script>

    <!--{template forum/forumdisplay_fastpost}-->
</div>

	<div class="bz-com-fm">
		  <div class="bz-com-fm-return">
		  	    <ul>	<li><a href="javascript:history.back();" class="iconfont icon-fanhui"></a></li></ul>
		  </div>
		  <div class="bz-com-fm-reply">
		  	    <ul>
		    	    	    	<li>
					    <a class="fastre color-b" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page"><em class="iconfont icon-xie"></em>&#25105;&#26469;&#35828;&#20004;&#21477;...</a>
		    	    	    	</li>
	    	    	    </ul>
		  </div>
	    	  <div class="bz-com-fm-share">
	    	    	    <ul>
	    	    	      	<li>
	    	    	    	    <!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
	    	    	    	        <a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" class="recbtn iconfont icon-zan3"><em id="recommendv_add"{if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>&nbsp;{$_G['forum_thread']['recommend_add']}</em></a>
					<!--{/if}-->
	    	    	    	    </li>
	    	    	    	    <li>
	    	    	    	    		<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn iconfont icon-shoucang4"><em id="favoritenumber"{if !$_G['forum_thread']['favtimes']} style="display:none"{/if}>&nbsp;{$_G['forum_thread']['favtimes']}</em></a>
	    	    	    	    </li>
	    	    	    </ul>
	    	  </div>
	</div>

    <!--{hook/viewthread_bottom_mobile}-->

<div class="banzhuan-bottom"></div>
<script>$('[data-menu]').menu();</script>
<script type="text/javascript">
	(function() {
		var form = $('#fastpostform');
		<!--{if !$_G[uid] || $_G[uid] && !$allowpostreply}-->
		$('#fastpostmessage').on('focus', function() {
			<!--{if !$_G[uid]}-->
				popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
			<!--{else}-->
				popup.open('{lang nopostreply}', 'alert');
			<!--{/if}-->
			this.blur();
		});
		<!--{else}-->
		$('#fastpostmessage').on('focus', function() {
			var obj = $(this);
			if(obj.attr('color') == 'gray') {
				obj.attr('value', '');
				obj.removeClass('grey');
				obj.attr('color', 'black');
				$('#fastpostsubmitline').css('display', 'block');
			}
		})
		.on('blur', function() {
			var obj = $(this);
			if(obj.attr('value') == '') {
				obj.addClass('grey');
				obj.attr('value', '{lang send_reply_fast_tip}');
				obj.attr('color', 'gray');
			}
		});
		<!--{/if}-->
		$('#fastpostsubmit').on('click', function() {
			var msgobj = $('#fastpostmessage');
			if(msgobj.val() == '{lang send_reply_fast_tip}') {
				msgobj.attr('value', '');
			}
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey=fastpost&loc=1&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});

		$('#replyid').on('click', function() {
			$(document).scrollTop($(document).height());
			$('#fastpostmessage')[0].focus();
		});

	})();

	function succeedhandle_fastpost(locationhref, message, param) {
		var pid = param['pid'];
		var tid = param['tid'];
		if(pid) {
			$.ajax({
				type:'POST',
				url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid + '&mobile=2',
				dataType:'xml'
			})
			.success(function(s) {
				$('#post_new').append(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = 'forum.php?mod=viewthread&tid=' + tid;
				popup.close();
			});
		} else {
			if(!message) {
				message = '{lang postreplyneedmod}';
			}
			popup.open(message, 'alert');
		}
		$('#fastpostmessage').attr('value', '');
		if(param['sechash']) {
			$('.seccodeimg').click();
		}
	}

	function errorhandle_fastpost(message, param) {
		popup.open(message, 'alert');
	}
	
	function openVideo(a,b) {   
        $(a).html('<img src="static/image/mobile/images/icon_load.gif" />');   
        var w = $(a).width();   
        var h = w * 0.85;   
        if(/youku/.test(b)){ // 
                b = b.match(/id_(.*?)\.html|sid\/(.*?)\/v/);   
                b = 'http://player.youku.com/embed/' + (b[1] ? b[1] : b[2]);   
        }else if(/bilibili|acg\.tv/.test(b)){ //B  
                b = b.match(/o\/av(.*?)\/|aid=(.*?)&/);   
                b = 'http://www.bilibili.com/video/av' + (b[1] ? b[1] : b[2]);   
        }else{   
                $(a).html('' + b);   
                return;   
        }   
        $(a).append('<iframe width=0 height=0 src="' + b + '" scrolling=no frameborder=0 allowfullscreen></iframe>');   
        $(a).children('iframe').load(function(){   
                $(a).children('img').remove();   
                $(a).children('iframe').css({'width':w,'height':h});   
        })   
} 
	
</script>
<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

	$('.recbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=recbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
	
	$('.replyadd').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=replyadd&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>
<script type="text/javascript">
	$(document).ready(function(){
  
	    $("#bzsmall").click(function(event){
		    event.preventDefault();
		    $("p").animate({"font-size":"14px"});
		  });
		  
		  $("#bzmedium").click(function(event){
		    event.preventDefault();
		    $("p").animate({"font-size":"16px"});
		  });
		  
		  $("#bzlarge").click(function(event){
		    event.preventDefault();
		    $("p").animate({"font-size":"20px"});
		  });
		  
		  $( "a" ).click(function() {
		   $("a").removeClass("selected");
		  $(this).addClass("selected");
		  
		 });
	
	});
</script> 

<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->