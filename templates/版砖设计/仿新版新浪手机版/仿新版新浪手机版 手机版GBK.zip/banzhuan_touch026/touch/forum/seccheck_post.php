<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu({if !empty($_G[gp_infloat])}{'ctrlid':this.id,'win':'{$_GET[handlekey]}'}{else}this.id{/if})"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
<div class="mtm"><!--{subtemplate common/seccheck}--></div>