<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<input type="hidden" name="trade" value="yes" />
<input type="hidden" name="item_type" value="1" />
<div class="exfm">
	  <li class="flexbox bzbt1 align_center color-c">{lang post_message1}</li>
	  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang post_trade_name}<em class="rq">*</em></span><span class="flex html" style="text-align:right;"><input type="text" name="item_name" id="item_name" class="px oinf" value="$trade[subject]" tabindex="1" /></span></li>
	  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang post_trade_number}<em class="rq">*</em></span><span class="flex html" style="text-align:right;"><input type="text" name="item_number" id="item_number" class="px" value="$trade[amount]" tabindex="1" /></span></li>
	  <li class="flexbox bzbt1 align_center bz-bg-fff">
	  	    <span class="name">{lang trade_type_viewthread}</span>
		    <span class="flex html iocn">
			    <select id="item_quality" class="ps" width="108" name="item_quality" tabindex="1">
			        <option value="1" {if $trade['quality'] == 1}selected="selected"{/if}>{lang trade_new}</option>
			        <option value="2" {if $trade['quality'] == 2}selected="selected"{/if}>{lang trade_old}</option>
			    </select>
		    </span>
	  </li>
	  <li class="flexbox bzbt1 align_center bz-bg-fff">
	  	    <span class="name">{lang post_trade_paymethod}</span>
		    <span class="flex html iocn">
			    <select name="paymethod" id="paymethod" onchange="document.getElementById('tenpayseller').style.display = this.value == 1 ? 'none' : ''" class="ps">
			        <!--{if $_G[setting][ec_tenpay_opentrans_chnid]}--><option value="0" {if $trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_online}</option><!--{/if}-->
			        <option value="1" {if !$trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_offline}</option>
			    </select>
		    </span>
	  </li>
	  <li class="flexbox bzbt1 align_center bz-bg-fff" id="tenpayseller" style="{if !$trade[tenpayaccount]}display:none{/if}">
		  	<span class="name">{lang post_trade_tenpay_seller}</span>
		  	<span class="flex html" style="text-align:right;">
		  		<input type="text" name="tenpay_account" id="tenpay_account" class="px" value="$trade[tenpayaccount]" tabindex="2">
		    </span>
	  </li>
	  <li class="flexbox bzbt1 align_center bz-bg-fff">
		  	<span class="name">{lang post_trade_transport}</span>
		    <span class="flex html iocn">
			    <select name="transport" id="transport" onchange="document.getElementById('logisticssetting').style.display = this.value == 'virtual' ? 'none' : ''" class="ps">
			      <option value="virtual" {if $trade['transport'] == 3}selected="selected"{/if}>{lang post_trade_transport_virtual}</option>
			      <option value="seller" {if $trade['transport'] == 1}selected="selected"{/if}>{lang post_trade_transport_seller}</option>
			      <option value="buyer" {if $trade['transport'] == 2}selected="selected"{/if}>{lang post_trade_transport_buyer}</option>
			      <option value="logistics" {if $trade['transport'] == 4}selected="selected"{/if}>{lang trade_type_transport_physical}</option>
			      <option value="offline" {if $trade['transport'] == 0}selected="selected"{/if}>{lang post_trade_transport_offline}</option>
			    </select>
		    </span>
	  </li>
	  <div id="logisticssetting" style="display:{if !$trade['transport'] || $trade['transport'] == 3}none{/if}">
		    <li class="flexbox bzbt1 price align_center"><span class="name">&#29289;&#27969;&#36153;&#29992;</span></li>
		    <li class="flexbox bzbt1 bz-bg-fff price align_center">
			      <span class="flex html flexbox">
				        <em class="center">
				            <input type="text" name="postage_mail" id="postage_mail" class="px center" value="$trade[ordinaryfee]"/>
				            <label for="postage_mail">{lang post_trade_transport_mail}</label>
				        </em>
				        <em class="center">
				            <input type="text" name="postage_express" id="postage_express" class="px center" value="$trade[expressfee]"/>
				            <label for="postage_express">{lang post_trade_transport_express}</label>
				        </em>
				        <em class="center">
				            <input type="text" name="postage_ems" id="postage_ems" class="px center" value="$trade[emsfee]"/>
				            <label for="postage_ems">EMS</label>
				        </em>
			      </span>
		    </li>
	  </div>
	  <li class="flexbox bzbt1 align_center"><span class="name">{lang post_trade_price}</span></li>
	  <li class="flexbox bzbt1 bz-bg-fff price align_center">
		    <span class="flex html flexbox">
			      <em class="center">
			          <input type="text" name="item_price" id="item_price" class="px center" value="$trade[price]" tabindex="1" />
					  <label for="item_price">{lang post_current_price}</label>
			      </em>
			      <em class="center">
			          <input type="text" name="item_costprice" id="item_costprice" class="px center" value="$trade[costprice]" tabindex="1" />
					  <label for="item_costprice">{lang post_original_price}</label>
			      </em>
		    </span>
	  </li>
	  <!--{if $_G['setting']['creditstransextra'][5] != -1}-->
	  <li class="flexbox bzbt1 align_center"><span class="name">{lang consumption_credit}</span></li>
	  <li class="flexbox bzbt1 bz-bg-fff price align_center">
		    <span class="flex html flexbox">
			      <em>
				      <input type="text" name="item_credit" id="item_credit" class="px center" value="$trade[credit]" tabindex="1" />
					  <label for="item_credit">{lang post_current_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})</label>
				  </em>
				  <em>
				      <input type="text" name="item_costcredit" id="item_costcredit" class="px center" value="$trade[costcredit]" tabindex="1" />
					  <label for="item_costcredit">{lang post_original_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})</label>
				  </em>
		    </span>
	  </li>
	  <!--{/if}-->
	  <div class="banzhuan-h10 bzbt1"></div>
	  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang valid_before}</span><span class="flex html" style="text-align:right;"><input type="text" name="item_expiration" id="item_expiration" class="px" onclick="this.blur();Common.showcalendar(this);" autocomplete="off" value="$trade[expiration]" tabindex="1" /></span></li>
	  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang post_trade_locus}</span><span class="flex html" style="text-align:right;"><input type="text" name="item_locus" id="item_locus" class="px" value="$trade[locus]" tabindex="1" /></span></li>
	  <!--{if $allowpostimg}-->
	  <li class="flexbox bz-bg-fff bzbt1 align_center">
		  	<span class="name">{lang post_trade_picture}</span>
		  	<span class="html flex image"> 
			    <input type="hidden" name="tradeaid" id="tradeaid" {if $tradeattach[attachment]}value="$tradeattach[aid]" {/if}/>
				<input type="hidden" name="tradeaid_url" id="tradeaid_url" />
			    <div class="ptn imagebox si">
				      <ul id="tradeattach_image">
					      <!--{if $tradeattach[attachment]}-->        
					        <li><span aid="$tradeattach[aid]" name="tradeattach_image" class="del2"><a href="javascript:;"><img src="static/image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="height:50px;width:50px;" src="$tradeattach[url]/{if $tradeattach['thumb']}{eval echo getimgthumbname($tradeattach['attachment']);}{else}$tradeattach[attachment]{/if}"></span></li>
					      <!--{else}-->
					        <li id="upfiledata"><i class="big y iconfont icon-camera" style="height:25px;color:#888;"></i></li>
					      <!--{/if}--> 
				      </ul>
			    </div>
		    </span>
	  </li>
	  <!--{/if}-->
</div>

<script type="text/javascript" reload="1">
	var uphtml,box = '';
	var uploader_act = WebUploader.create({
		server: 'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
		formData: {uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
		fileVal: 'Filedata',
		pick: '#upfiledata',
		auto: true,
		accept: {
			title: 'Files',
			extensions: 'gif,jpg,jpeg,bmp,png',
			mimeTypes:'image/*,text/plain,application/msword,application/octet-stream,application/vnd.ms-excel,application/x-shockwave-flash'
		}
	});
	uploader_act.on('fileQueued', function(file) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		$(bar).html('<li id="file_'+file.id+'"><img src="template/banzhuan_touch026/touch/banzhuan/images/loading.gif" style="height:50px;width:50px;"><i class="Progress"></i></li>');
	});
	uploader_act.on('uploadSuccess', function(file, data) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		if(data._raw) {
			var dataarr = data._raw.split('|');
			if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
				$('#file_'+file.id).html('<span aid="'+dataarr[3]+'" class="del2"><a href="javascript:;"><img src="'+STATICURL+'image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="width:50px;height:44px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" />');
				$('#tradeaid').val(dataarr[3]);
				$('#tradeaid_url').val('{$_G[setting][attachurl]}forum/'+dataarr[5]);
			}
		}
	});
	$(document).on('click', '.del2', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
			uphtml = '<li id="upfiledata"><i class="big y iconfont icon-camera" style="height:25px;color:#888;"></i></li>';
			$('#tradeattach_image').html(uphtml);
			uploader_act.addButton({id:'#upfiledata'});
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});
</script>