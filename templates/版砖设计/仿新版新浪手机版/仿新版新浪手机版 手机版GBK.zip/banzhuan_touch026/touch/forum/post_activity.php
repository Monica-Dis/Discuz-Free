<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<div class="exfm">
  <li class="flexbox bzbt1 align_center"><span class="name">{lang activity_starttime_endtime}</span><span class="flex" style="text-align:right;"><label for="activitytime"><input type="checkbox" id="activitytime" name="activitytime" class="pc" onclick="if(this.checked) {$('#certainstarttime').hide();$('#uncertainstarttime').show();} else {$('#certainstarttime').show();$('#uncertainstarttime').hide();}" value="1" {if $activity['starttimeto']}checked{/if} tabindex="1" /></label></span></li>
  
  <li class="flexbox bzbt1 align_center bz-bg-fff" id="certainstarttime" {if $activity['starttimeto']}style="display: none"{/if}><span class="name">{lang post_event_time}<em class="rq">*</em></span><span class="flex html" style="text-align:right;"><input type="text" name="starttimefrom[0]" id="starttimefrom_0" class="px" onclick="this.blur();Common.showcalendar(this);" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" /></span></li>
  <div id="uncertainstarttime" {if !$activity['starttimeto']}style="display: none"{/if}>
    <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang activity_starttime}<em class="rq">*</em></span><span class="flex html" style="text-align:right;"><input type="text" name="starttimefrom[1]" id="starttimefrom_1" class="px" onclick="this.blur();Common.showcalendar(this);" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" /></span></li>
    
    <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang endtime}<em class="rq">*</em></span><span class="flex html" style="text-align:right;"><input onclick="this.blur();Common.showcalendar(this);" type="text" autocomplete="off" id="starttimeto" name="starttimeto" class="px" value="{if $activity['starttimeto']}$activity[starttimeto]{/if}" tabindex="1" /></span></li>
  </div>
  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang activity_space}</span><span class="flex html" style="text-align:right;"><input type="text" name="activityplace" id="activityplace" class="px" value="$activity[place]" tabindex="1" /></span></li>
  <!--{if $_GET[action] == 'newthread'}-->
  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang activity_city}</span><span class="flex html" style="text-align:right;"><input name="activitycity" id="activitycity" class="px" type="text" tabindex="1" /></span></li>
  <!--{/if}-->
  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang activiy_sort}</span><span class="flex html" style="text-align:right;"><input type="text" id="activityclass" name="activityclass" class="px" value="$activity[class]" tabindex="1" /></span>
  <!--{if $activitytypelist}-->
    <span class="html iocn">
    <select class="bigTriangle" onchange="$('#activityclass').val($(this).find('option:selected').val());">
      <!--{loop $activitytypelist $type}-->
      <option value="$type">$type</option>
      <!--{/loop}-->
    </select>
    </span>
  <!--{/if}-->
  </li>
  <li class="flexbox bzbt1 align_center bz-bg-fff" id="activitynumbermessage"><span class="name">{lang activity_need_member}</span><span class="flex html" style="text-align:right;"><input type="text" name="activitynumber" id="activitynumber" class="px" onkeyup="checkvalue(this.value, 'activitynumbermessage')" value="$activity[number]" tabindex="1" /></span></li>
  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang gender}</span><span class="flex html iocn" style="text-align:right;"><select name="gender" id="gender" width="38" class="ps">
      <option value="0" {if !$activity['gender']}selected="selected"{/if}>{lang unlimited}</option>
      <option value="1" {if $activity['gender'] == 1}selected="selected"{/if}>{lang male}</option>
      <option value="2" {if $activity['gender'] == 2}selected="selected"{/if}>{lang female}</option>
  </select></span></li>
  <!--{if $_G['setting']['activityfield']}-->
  <li class="flexbox bzbt1 align_center">{lang optional_data}</li>
  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="flex html sm">
  <!--{loop $_G['setting']['activityfield'] $key $val}-->
    <label for="userfield_$key"><input type="checkbox" name="userfield[]" id="userfield_$key" class="pc" value="$key"{if $activity['ufield']['userfield'] && in_array($key, $activity['ufield']['userfield'])} checked="checked"{/if} />$val</label>
  <!--{/loop}-->
  </span></li>
  <!--{/if}-->
  <!--{if $_G['setting']['activityextnum']}-->
  <li class="flexbox bzbt1 align_center">{lang other_data}</li>
  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="flex">
  <textarea name="extfield" id="extfield" class="pt" style="height:65px;width:100%;border:0"><!--{if $activity['ufield']['extfield']}-->$activity[ufield][extfield]<!--{/if}--></textarea>
  </span></li>
  <!--{/if}-->
  <li class="flexbox bzbt1 align_center bz-bg-fff"><span class="name">{lang consumption_credit}</span><span class="flex html"><input type="text" name="activitycredit" id="activitycredit" class="px" value="$activity[credit]" /></span>{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</li>
  <li class="flexbox bzbt1 align_center bz-bg-fff" id="costmessage"><span class="name">{lang activity_payment}</span><span class="flex html"><input type="text" name="cost" id="cost" class="px" onkeyup="checkvalue(this.value, 'costmessage')" value="$activity[cost]" tabindex="1" /></span>{lang payment_unit}</li>
  
  <li class="flexbox bzbt1 align_center bz-bg-fff" id="certainstarttime" {if $activity['starttimeto']}style="display: none"{/if}><span class="name">{lang post_closing}</span><span class="flex html" style="text-align:right;"><input type="text" name="activityexpiration" id="activityexpiration" class="px" onclick="this.blur();Common.showcalendar(this);" autocomplete="off" value="$activity[expiration]" tabindex="1" /></span></li>
  <!--{if $allowpostimg}-->
  <li class="flexbox bz-bg-fff bzbt1 align_center">
	  	<span class="name">{lang post_topic_image}</span>
	  	<span class="html flex image"> 
		    <input type="hidden" name="activityaid" id="activityaid" {if $activityattach[attachment]}value="$activityattach[aid]" {/if}/>
			<input type="hidden" name="activityaid_url" id="activityaid_url" />
		    <div class="ptn imagebox si"> 
			      <ul id="activityattach_image">
				      <!--{if $activityattach[attachment]}-->
				        <li><span aid="$activityattach[aid]" name="activityattach_image" class="del2"><a href="javascript:;"><img src="static/image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="height:44px;width:50px;" src="$activityattach[url]/{if $activityattach['thumb']}{eval echo getimgthumbname($activityattach['attachment']);}{else}$activityattach[attachment]{/if}"></span></li>
				      <!--{else}-->
				        <li id="upfiledata"><i class="big y iconfont icon-camera" style="height:25px;"></i></li>
				      <!--{/if}--> 
			      </ul>
		    </div>
	    </span>
  </li>
  <!--{/if}-->
  
</div>


<script type="text/javascript">
	function checkvalue(value, message){
		if(value.search(/^\d+$/)) {
			$('#'+message).addClass('err');
		}else{
			$('#'+message).removeClass("err");
		}
	}
	
	var uploader_act = WebUploader.create({
		server: 'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
		formData: {uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
		fileVal: 'Filedata',
		pick: '#upfiledata',
		auto: true,
		accept: {
			title: 'Files',
			extensions: 'gif,jpg,jpeg,bmp,png',
			mimeTypes:'image/*,text/plain,application/msword,application/octet-stream,application/vnd.ms-excel,application/x-shockwave-flash'
		}
	}); 
	
	uploader_act.on('fileQueued', function(file) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		$(bar).html('<li id="file_'+file.id+'"><img src="template/banzhuan_touch026/touch/banzhuan/images/loading.gif" style="height:20px;width:20px;"><i class="Progress"></i></li>');
	});
	
	uploader_act.on('uploadSuccess', function(file, data) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		if(data._raw) {
			var dataarr = data._raw.split('|');
			if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
				$('#file_'+file.id).html('<span aid="'+dataarr[3]+'" class="del2"><a href="javascript:;"><img src="'+STATICURL+'image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="height:44px;width:50px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" />');
				$('#activityaid').val(dataarr[3]);
				$('#activityaid_url').val('{$_G[setting][attachurl]}forum/'+dataarr[5]);
			}
		}
	});
	$(document).on('click', '.del2', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
			uphtml = '<li id="upfiledata"><i class="big y iconfont icon-camera" style="height:25px;"></i></li>';
			$('#activityattach_image').html(uphtml);
			uploader_act.addButton({id:'#upfiledata'});
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});
</script>