var SlideDistance = {};
var smiliea;
var Common = {
	apage : 1,
	langis : 0,
	loading : false,
	extendid : '',
	
	id : function(id){
        return !id ? null : document.getElementById(id);
    },

	Switch : function(obj,fid){
	    $(obj).toggleClass("a").siblings().removeClass("a");
        $("#"+fid).slideToggle();
	},

	TabSwitch : function(obj,fid){
	    $(obj).addClass("a").siblings().removeClass("a");
		$("#"+fid).slideDown().siblings().slideUp();
	},

	LoadMore : function(obj, container, item, url, total){
	    if(Common.loading == false){
			Common.loading = true;
			var lang = new Array('\u6ca1\u6709\u6570\u636E\u4e86','\u4EB2, \u5DF2\u7ECF\u5230\u5E95\u4E86','\u6ca1\u6709\u6570\u636E\u4e86','\u4EB2, \u5DF2\u7ECF\u5230\u5E95\u4E86');
			var text = obj.innerHTML;
			obj.innerHTML = '<img src="./template/banzhuan_touch026/touch/banzhuan/images/loading.gif"/>';
			this.apage++;
			if(total && this.apage>total){
				Common.langis = Common.langis > 3 ? 1 : Common.langis;
				obj.innerHTML = lang[Common.langis];
				Common.langis++;
				setTimeout(function(){
					obj.innerHTML = text;
					Common.loading = false;
				},2000);
				return false;
			}
			url = url+'&page='+this.apage;
			jQuery.get(url, function(data) {
				var html = jQuery(data).find("#"+container).html();
				var result = jQuery(html).filter(item);
				if(result.length < 1){
					Common.langis = Common.langis>3 ? 1 : Common.langis;
					obj.innerHTML = lang[Common.langis];
					Common.langis++;
					setTimeout(function(){
						obj.innerHTML = text;
						Common.loading = false;
					},2000);
					return false;
				}
				try {
					containers = jQuery('#'+container);
					containers.imagesLoaded( function(){
						for (var i = 0; i < result.length; i++) {
							curitem = jQuery(result[i]);
							containers.append(curitem);
							containers.masonry('appended', curitem, true);
							curitem.animate({
								opacity: 1
							});
						}
					});
				} catch (ext) {
					document.getElementById(container).innerHTML += html;
				}
				obj.innerHTML = text;	
				Common.loading = false;
			});
			return false;
		}
	},

	tips : function(msg){
		msg = '<div class="tip bz-p10" style="text-align: center;font-size:14px;">'+msg+'</div';
		popup.open(msg);
		setTimeout(function() {
			popup.close();
		}, '1000');
	},

    popup : function(id,mask){
		if(!id){
			id = Common.extendid;
		}else{
		    Common.extendid = id;
		}
		$('#'+id).slideDown();
		if(mask){
			$('#mask').addClass('mask');
			setTimeout(function(){
				$('#mask').addClass('mask_on');	
			},10);
		}
	},

    close : function(id){
		if(!id){
			id = Common.extendid;
		}
		if(id){
		    $('#'+id).slideUp();
		}
		$('#mask').removeClass('mask'),$('#mask').removeClass('mask_on');
	},
	
	SwitchTab : function(obj,fid){
	    $(obj).addClass("a").siblings().removeClass("a");
        $("#"+fid).slideDown().siblings().slideUp();
	},

	SwitchTab : function(obj,fid){
	    $(obj).addClass("a").siblings().removeClass("a");
        $("#"+fid).slideDown().siblings().slideUp();
	},

	showcalendar : function (obj) {
		obj.blur();
		var myDate = new Date();
		if(obj.value != ''){
			myDate = new Date(obj.value.replace(/-/g, "/"));
		}
		var year = myDate.getFullYear();
		var year_option = month_option = day_option = hour_option = minute_option = '';
		for(i=-3;i<85;i++){
			selected = year == year-i ? 'selected="selected"' : '';
			year_option += '<option value="'+parseInt(year-i)+'" '+selected+'>'+parseInt(year-i)+'\u5e74</option>';
		}
		var month = myDate.getMonth();
		for(i=1;i<=12;i++){
			selected = month+1 == i ? 'selected="selected"' : '';
			is =  (Array(2).join(0) + i).slice(-2);
			month_option += '<option value="'+is+'" '+selected+'>'+is+'\u6708</option>';
		}
		var ds = new Date(year, month+1, 0);
		var day = myDate.getDate();
		var days = ds.getDate();
		for(i=1;i<=days;i++){
			selected = day == i ? 'selected="selected"' : '';
			is =  (Array(2).join(0) + i).slice(-2);
			day_option += '<option value="'+is+'" '+selected+'>'+is+'\u65e5</option>';
		}
		var selecthtml = '<select nemu="year" id="baryear">'+year_option+'</select> - <select nemu="month" id="barmonth">'+month_option+'</select> - <select nemu="day" id="barday">'+day_option+'</select>';
		var hour = myDate.getHours();
		for(i=0;i<=23;i++){
			selected = hour == i ? 'selected="selected"' : '';
			is =  (Array(2).join(0) + i).slice(-2);
			hour_option += '<option value="'+is+'" '+selected+'>'+is+'\u70b9</option>';
		}
		var minute = myDate.getMinutes();
		for(i=0;i<=59;i++){
			selected = minute == i ? 'selected="selected"' : '';
			is =  (Array(2).join(0) + i).slice(-2);
			minute_option += '<option value="'+is+'" '+selected+'>'+is+'\u5206</option>';
		}
		var selecthtml2 = '<select nemu="hour" id="barhour">'+hour_option+'</select> - <select nemu="minute" id="barminute">'+minute_option+'</select>';
		var timehtml = '<div class="tip docommbox bz-bg-fff">'+
			'<h3 class="title">\u65e5\u671f\u65f6\u95f4\u8bbe\u7f6e</h3>'+
			'<div class="calendar" style="padding:15px 0 15px 0;text-align: center;line-height: 40px;"><p>'+selecthtml+'</p><p>'+selecthtml2+'</p></div>'+
			'<div class="o pns"><button type="button" class="pnc" onclick="Common.confirmcalendar(\''+$(obj).attr('id')+'\')">\u786e\u5b9a</button>'+
			'<a class="pnc" href="javascript:;" onclick="popup.close();">\u53d6\u6d88</a></div></div>';
		popup.open(timehtml);
		popup.open(timehtml);
	},

	confirmcalendar : function(id){
		var yeardata = $("#baryear").find('option:selected').val()+'-'+$("#barmonth").find('option:selected').val()+'-'+$("#barday").find('option:selected').val()+' '+$("#barhour").find('option:selected').val()+':'+$("#barminute").find('option:selected').val();
		$('#'+id).val(yeardata);
		popup.close();
	},
	
	smilies : function(id,s,b){
		if(typeof smilies_type == 'object') {
			var navitem = '';
			var smilieitem = '';
			if(!smiliea){
				for(c in smilies_array) {
					smiliea = c; break;
				}
			}
			smiliea = !b ? smiliea : b;
			for(i in smilies_type) {
				key = i.substring(1);
				navitem += '<a '+(smiliea==key?'class="a"':'')+' onclick="Common.smilies(\''+id+'\',\''+s+'\',\''+key+'\');"><img src="static/image/smiley/'+smilies_type[i][1]+'/'+smilies_array[key][1][0][2]+'"></a>';
			}
			var smilies_nav = '<div class="smilies_nav">'+navitem+'</div>';
			
			for(key in smilies_array[smiliea][1]) {
				smilieitem += '<a data-id="'+smilies_array[smiliea][1][key][1]+'" onclick="Common.setsmilie(this,\''+s+'\');"><span><img src="static/image/smiley/'+smilies_type['_'+smiliea][1]+'/'+smilies_array[smiliea][1][key][2]+'"></span></a>';
			}
			var smiliehtml = '<div class="smilie bz-bg-fff">'+smilieitem+'</div>';
			
			document.getElementById(id).innerHTML = smiliehtml+smilies_nav;
		}
	},
	
	setsmilie : function(obj,s,gb){
		var msgbox = Common.id(s);
		var str = $(obj).attr('data-id');
		if(gb){
			htmlbox = Common.id(gb).contentWindow.document.body;
			str = '<img src="' + STATICURL + str + '" />';
			try {
				rng = Common.id(gb).contentWindow.getSelection().getRangeAt(0);
				frg = rng.createContextualFragment(str);
				rng.insertNode(frg);
				msgbox.value = htmlbox.innerHTML;
				//console.log('Percentage:', htmlbox);
			} catch (ext) {
				msgbox.value += str;
				htmlbox.innerHTML = msgbox.value;
				$(htmlbox).scrollTop($(htmlbox)[0].scrollHeight);
			}
		}else{
            msgbox.value += str;
			$("#"+s).scrollTop($("#"+s)[0].scrollHeight);
		}
	},
	
}


var Load = 0;
var showcalendar = function(){
	Common.showcalendar();
}


$(document).ready(function() {

    var timer = setInterval(function(){Loading()},1000);
    function Loading(){
		if(Load){
			Load = 0;
		    popup.close();
		    clearInterval(timer);
		}
	}
	$(document).on('click', "a[href]:not(.dialog)", function() {
		var Cts = jQuery(this).attr('onclick');
		if(!Cts){
			//Common.audio(0.05,1);
			var href = jQuery(this).attr('href');
			if(href != 'javascript:;'){
				popup.open('');
				$('#mask').css({opacity:0});
				var img = new Image();
				img.src = 'template/banzhuan_touch026/touch/banzhuan/images/loading.gif';
				img.onload = function(){
					Load = 1;
					timer = setInterval(function(){Loading()},1000);
					window.location = href;
				}
				return false;
			}
		}
	});

	$('#mask').on('tap', function() {
		Common.close();
	});	
	
});

function showdistrict(container, elems, totallevel, changelevel, containertype, showdefault) {
	var getdid = function(elem) {
		var op = elem.options[elem.selectedIndex];
		return op['did'] || op.getAttribute('did') || '0';
	};
	showdefault = showdefault==0 ? showdefault : 1;
	var pid = changelevel >= 1 && elems[0] && document.getElementById(elems[0]) ? getdid(document.getElementById(elems[0])) : 0;
	var cid = changelevel >= 2 && elems[1] && document.getElementById(elems[1]) ? getdid(document.getElementById(elems[1])) : 0;
	var did = changelevel >= 3 && elems[2] && document.getElementById(elems[2]) ? getdid(document.getElementById(elems[2])) : 0;
	var coid = changelevel >= 4 && elems[3] && document.getElementById(elems[3]) ? getdid(document.getElementById(elems[3])) : 0;
	var url = "home.php?mod=misc&ac=ajax&op=district&container="+container+"&containertype="+containertype
		+"&province="+elems[0]+"&city="+elems[1]+"&district="+elems[2]+"&community="+elems[3]
		+"&pid="+pid + "&cid="+cid+"&did="+did+"&coid="+coid+'&level='+totallevel+'&handlekey='+container+'&inajax=1'+(!changelevel ? '&showdefault='+showdefault : '');
	$.get(url,function(s){
		document.getElementById(container).innerHTML = s.lastChild.firstChild.nodeValue;
	});
}

function strLenCalc(obj, checklen, maxlen) {
	var v = obj.value, charlen = 0, maxlen = !maxlen ? 200 : maxlen, curlen = maxlen, len = v.length;
	if(maxlen < len) {
		obj.value = mb_cutstr(v, maxlen, 0);
		$('#'+checklen).html(maxlen);
	} else {
		$('#'+checklen).html(len);
	}
}
