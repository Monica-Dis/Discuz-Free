<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<style>
	.editor_menu { height: 40px; }
	.editor_menu a { float: left; position: relative; margin-top: 5px; margin-right: 8px; margin-bottom: 8px; margin-left: 8px; color: #888; }
	.editor_menu a:hover { color: #888; }
	.editor_menu i:before { font-size: 24px; line-height: 24px; }
	.editor_menu a.a:before { content: " "; position: absolute; text-align: center; left: 50%; top: 22px; margin-left: -7px; height: 0; width: 0; border: transparent 7px solid; border-width: 7px 7px; border-bottom-color: #dedede; }
	.editor_menu a.a:after { content: " "; position: absolute; text-align: center; left: 50%; top: 24px; margin-left: -6px; height: 0; width: 0; border: transparent 6px solid; border-width: 6px 6px; border-bottom-color: #FFF; }
    .editor_menu a.a { color: #333; font-weight: 700; }
	#box_smiley .smilie a { width: 12.5%; text-align: center; display: inline-block; }
	#box_smiley .smilie a span { padding: 5px; display: block; }
	#box_smiley .smilie a span img { max-width: 100%; }
	.smilies_nav { text-align: center; border-top: 1px solid #EBEBEB; height: 30px; padding-top: 10px; }
	.smilies_nav a { position: relative; display: inline-block; padding-right: 8px; padding-left: 8px; }
	.smilies_nav img { width: 20px; }
	.smilies_nav a.a:before { content: " "; position: absolute; text-align: center; left: 50%; top: -11px; margin-left: -7px; height: 0; width: 0; border: transparent 7px solid; border-width: 7px 7px; border-top-color: #dedede; }
	.smilies_nav a.a:after { content: " "; position: absolute; text-align: center; left: 50%; top: -11px; margin-left: -6px; height: 0; width: 0; border: transparent 6px solid; border-width: 6px 6px; border-top-color: #FFF; }
	.box_txt .txt { background-color: #E5E5E5; margin-right: 10px; height: 30px !important; text-indent: 5px; }
	.uptypenav { overflow: hidden; }
	.uptypenav a { border-radius: 2px; background-color: #E6E6E6; display: inline-block; padding-right: 3px; padding-left: 3px; margin-right: 2px; line-height:22px;}
	#upfile { position: relative; overflow: hidden; display: block; }
	#upfile .webuploader-pick { width:100%; }
	#upfile.webuploader-container div { width: 100% !important; position: relative !important; height:auto !important; }
	#upfile .webuploader-element-invisible { display: block;  }
	.webuploader-container .Progress { background-color: #CCC; height: 3px; }
	.webuploader-container .Progress b { height: 3px; width: 0px; display: block; }
</style>

<div class="html_editor bz-bg-fff">
	    <div class="editor_menu bzbb1">
		    <!--{if in_array('smilies',$seditor[1]) || in_array('smilie',$seditor[1])}--><a data-id="smiley"><i class="bigs iconfont icon-biaoqing"></i></a><!--{/if}-->
		    <!--{if in_array('img',$seditor[1])}--><a data-id="image"><i class="bigs iconfont icon-camera"></i></a><!--{/if}-->
		    <!--{if in_array('video',$seditor[1])}--><!--<a data-id="video"><i class="bigs" class="bigs iconfont icon-video"></i></a>--><!--{/if}-->
		    <!--{if in_array('annex',$seditor[1])}--><!--<a data-id="annex"><i class="bigs iconfont icon-shezhi2"></i></a>--><!--{/if}-->
		    <!--{if in_array('link',$seditor[1])}--><!--<a data-id="link"><i class="bigs iconfont icon-shezhi2"></i></a>--><!--{/if}-->
	    </div>
	    <div class="banzhuan-clear">
		    <div id="box_smiley" class="bzbb1 bz-p10" style="display:none;"></div>
		    <div id="box_image" class="bzbb1 bz-p10 ebox imagebox" style="display:none;">
			      <ul id="imglist" class="bz-bg-fff">
				        <!--{if !empty($imgattachs['used'])}--><!--{eval $imagelist = $imgattachs['used'];}-->
				        <!--{if $imagelist}-->
				        <!--{loop $imagelist $image}-->
				        <li><span aid="$image[aid]" class="del"><a href="javascript:;"><img src="static/image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="height:44px;width:50px;" src="{echo getforumimg($image[aid], 1, 300, 300, 'fixnone')}"></span><input type="hidden" name="attachnew[{$image[aid]}][description]"></li>
				        <!--{/loop}-->
				        <!--{/if}-->
				        <!--{/if}-->
				        <!--{if $attachs}--> 
				        <!--{loop $attachs $image}-->
				        <li><span aid="$image[attachid]" class="del"><a href="javascript:;"><img src="static/image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="height:50px;width:50px;" src="{$_G[setting][attachurl]}portal/{$image['attachment']}"></span>
				          <input type="hidden" name="attachnew[{$image[aid]}][description]">
				        </li>
				        <!--{/loop}--> 
				        <!--{/if}--> 
				        <li id="filedata"><a><i class="bigs iconfont icon-jiahao1"></i></a></li>
			      </ul>
		    </div>
		    <div id="box_video" class="bzbb1 bz-p10 box_txt" style="display:none;">
				      <div class="uptypenav typelist">
					        <a class="a" onclick="Common.TabSwitch(this,'videolink');">&#36828;&#31243;&#22320;&#22336;</a>
					        <a onclick="Common.TabSwitch(this,'videoup');">&#26412;&#22320;&#19978;&#20256;</a>
				      </div>
			          <dl class="flexbox" id="videolink">
			        		    <input class="txt" name="" type="text" style="float:left;" placeholder="&#25903;&#25345;&#25991;&#20214;&#31867;&#22411;: mp3,mp4,ogg"/><input class="button" type="button" value="{lang confirms}" />
			          </dl>
			          <dl id="videoup" style="display:none;">
			          	    <div id="upfile"></div>
			          </dl>
		     </div>
		     <div id="box_annex" class="bzbb1 bz-p10" style="display:none;"></div>
		     <div id="box_link" class="bzbb1 bz-p10 box_txt" style="display:none;"></div>
        </div>
</div>

<!--{if in_array('smilies',$seditor[1])}--> 
<script type="text/javascript" src="data/cache/common_smilies_var.js" charset="{CHARSET}"></script> 
<!--{/if}-->

<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
	var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	
	var container_msg = $('#{$seditor[0]}');
	container_msg.hide();
	container_msg.after('<iframe frameborder="0" tabindex="2" id="e_iframe" class="pt" style="width: 100%;height: '+container_msg.height()+'px;"></iframe>');
	
	editbox = Common.id('e_iframe');
	var container_html = editbox.contentWindow.document.body;
	container_html.contentEditable = true;
	container_html.spellcheck = true;
	container_html.id = 'container_html';
	$(container_html).css({'overflow-x':'auto', 'margin':'0px', 'padding':'0px'});
	$(container_html).html(container_msg.val()); 
	
	function validate(obj){
		container_msg.val($(container_html).html());
	}
	
	$('.editor_menu > a').on('click',function(){
		$(this).addClass("a").siblings().removeClass("a");
		var name = $(this).attr('data-id');
		
		if(name == 'smiley'){
		<!--{if in_array('smilie',$seditor[1])}-->
			var mhtml = '<div class="smilie bz-bg-fff">';
			for(i=1; i<31; i++) {
				mhtml += '<a data-id="image/smiley/comcom/'+i+'.gif" onclick="Common.setsmilie(this,\'{$seditor[0]}\',\'e_iframe\');"><img src="' + STATICURL + 'image/smiley/comcom/'+i+'.gif" /></a>';
			}
			mhtml += '</div>';
			$('#box_smiley').html(mhtml);
		<!--{elseif in_array('smilies',$seditor[1])}-->
		    Common.smilies('box_smiley','{$seditor[0]}');
		<!--{/if}-->
		}
		$('#box_'+name).slideDown().siblings().slideUp();
	});
	
	<!--{if in_array('img',$seditor[1])}-->
	var uploader = WebUploader.create({
		<!--{if $seditor[2] == 'album'}-->
		server: 'misc.php?mod=swfupload&action=swfupload&operation={$seditor[2]}&inajax=yes&infloat=yes&simple=2',
		formData:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
		<!--{elseif $seditor[2] == 'portal'}-->
		server: 'misc.php?mod=swfupload&action=swfupload&operation=portal',
		formData:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->","aid":'$_GET['aid']',"catid":'$catid'},
		<!--{/if}-->
		fileVal: 'Filedata',
		pick: '#filedata',
		auto: true,
		accept: {
			title: 'Image File',
			extensions: 'gif,jpg,jpeg,bmp,png',
			mimeTypes:'image/*,text/plain,application/msword,application/octet-stream,application/vnd.ms-excel,application/x-shockwave-flash'
		}
	});
	uploader.on('fileQueued', function(file) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		$(bar).prepend('<li id="file_'+file.id+'"><img src="template/banzhuan_touch026/touch/banzhuan/images/loading.gif" style="height:44px;width:50px;"><i class="Progress">&#21387;&#32553;&#20013;</i></li>');
	});
	
	uploader.on('uploadProgress', function( file, percentage ) {
		$('#file_'+file.id+' i').html(Math.round(percentage * 100) + '%');
	});
	
	uploader.on('uploadSuccess', function(file, data) {
		var bar = $('#rt_'+file.source.ruid).parent().parent();
		<!--{if $seditor[2] == 'album'}-->
		if(data.picid) {
			$('#file_'+file.id).html('<span aid="'+data.picid+'" class="del"><a href="javascript:;"><img src="'+STATICURL+'image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="height:50px;width:50px;" id="aimg_'+data.picid+'" src="'+data.url+'" /></span><input type="hidden" name="picids['+data.picid+']" />');
			//$('#{$seditor[0]}').val($('#{$seditor[0]}').val()+'<img src="'+data.bigimg+'" />');
		}
		<!--{elseif $seditor[2] == 'portal'}-->
		if(data.aid) {
			$('#file_'+file.id).html('<span aid="'+data.aid+'" class="del"><a href="javascript:;"><img src="'+STATICURL+'image/mobile/images/icon_del.png"></a></span><span class="p_img"><img style="height:50px;width:50px;" id="aimg_'+data.aid+'" src="'+data.smallimg+'" /></span>');
			document.getElementById('conver').value = data.cover;
			document.getElementById('attach_ids').value += ','+data.aid;
			container_msg.val(container_msg.val()+'<img src="'+data.bigimg+'" />');
			$(container_html).html(container_msg.val());
		}else{
			popup.open(data, 'alert');
		}
		<!--{/if}-->
	});
	<!--{/if}-->
	
	$(document).on('click', '.del', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

</script>