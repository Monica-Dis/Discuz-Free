<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<div class="footerwp">
	<div class="sub-footer bzbt1" style="display: none;">
	    <ul class="cl">
	    		<li><a href="portal.php?mod=index&mobile=2"><span style="background: #444;"><i class="iconfont icon-home"></i></span>{lang homepage}</a></li>
			<li><a href="<!--{if $_GET['mod'] == 'forumdisplay' || $_GET['mod'] == 'viewthread'}-->forum.php?mod=post&action=newthread&fid=$_G['fid']<!--{else}-->forum.php?mod=misc&action=nav<!--{/if}-->"><span style="background: #444;"><i class="iconfont icon-post"></i></span>{lang send_threads}</a></li>
			<li><a href="search.php?mod=forum&mobile=2"><span style="background: #444;"><i class="iconfont icon-search4"></i></span>{lang search}</a></li>
			<!--{if helper_access::check_module('portal')}--><li><a href="portal.php?mod=list&catid=1&mobile=2"><span style="background: #444;"><i class="iconfont icon-ziliao21"></i></span>&#36164;&#35759;</a></li><!--{/if}-->
			<li><a href="forum.php?mod=announcement&mobile=2"><span style="background: #444;"><i class="iconfont icon-tixing"></i></span>&#20844;&#21578;</a></li>
			<!--{if helper_access::check_module('ranklist')}--><li><a href="misc.php?mod=ranklist&type=activity&view=heats&orderby=all&mobile=2"><span style="background: #444;"><i class="iconfont icon-huodong1"></i></span>{lang activity}</a></li><!--{/if}-->
			<!--{if helper_access::check_module('ranklist')}--><li><a href="misc.php?mod=ranklist&type=picture&view=heats&orderby=all&mobile=2"><span style="background: #444;"><i class="iconfont icon-camera"></i></span>&#22270;&#29255;</a></li><!--{/if}-->
			<li><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}"><span style="background: #444;"><i class="iconfont icon-people1"></i></span>{lang myitem}<!--{if $_G[member][newpm] || $_G[member][newprompt]}--><em class="iconfont icon-dian1"></em><!--{/if}--></a></li>
		</ul>
	</div>
</div>
<div class="btn-fullbg" style="display: none;"></div>
<script>
	var flag3 = 1;
	$(".btn-open-close,.btn-fullbg").click(function() {
	    if (flag3 == 1) {
	        $(".sub-footer,.btn-fullbg").show();
	        $(".icon-add1").addClass('color-red');
	        flag3 = 0;
	    } else {
	        $(".btn-fullbg,.sub-footer").hide();
	        $(".icon-add1").removeClass('color-red');
	        flag3 = 1;
	    }
	})
</script>
