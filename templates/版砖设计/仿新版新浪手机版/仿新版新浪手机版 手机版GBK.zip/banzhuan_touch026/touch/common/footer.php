<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<!--{if !$nofooter}-->
<div class="footer banzhuan-clear">
    <p>&copy; $_G['setting']['sitename']</p>
</div>
<!--{/if}-->
<div class="banzhuan-bottom"></div>
<div class="footerwp">
	<div class="sub-footer bzbt1" style="display: none;">
	    <ul class="cl">
			<li><a href="forum.php?mod=misc&action=nav"><span style="background: #444;"><i class="iconfont icon-post"></i></span>{lang send_threads}</a></li>
			<li><a href="search.php?mod=forum&mobile=2"><span style="background: #444;"><i class="iconfont icon-search4"></i></span>{lang search}</a></li>
			<!--{if helper_access::check_module('portal')}--><li><a href="portal.php?mod=list&catid=1&mobile=2"><span style="background: #444;"><i class="iconfont icon-ziliao21"></i></span>&#36164;&#35759;</a></li><!--{/if}-->
			<li><a href="forum.php?mod=announcement&mobile=2"><span style="background: #444;"><i class="iconfont icon-tixing"></i></span>&#20844;&#21578;</a></li>
			<!--{if helper_access::check_module('ranklist')}--><li><a href="misc.php?mod=ranklist&type=activity&view=heats&orderby=all&mobile=2"><span style="background: #444;"><i class="iconfont icon-huodong1"></i></span>{lang activity}</a></li><!--{/if}-->
			<!--{if helper_access::check_module('ranklist')}--><li><a href="misc.php?mod=ranklist&type=picture&view=heats&orderby=all&mobile=2"><span style="background: #444;"><i class="iconfont icon-camera"></i></span>&#22270;&#29255;</a></li><!--{/if}-->
			<li><a href="misc.php?mod=tag&mobile=2"><span style="background: #444;"><i class="iconfont icon-tag"></i></span>&#26631;&#31614;</a></li>
			<li><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}"><span style="background: #444;"><i class="iconfont icon-people1"></i></span>{lang myitem}<!--{if $_G[member][newpm] || $_G[member][newprompt]}--><em class="iconfont icon-dian1"></em><!--{/if}--></a></li>
		</ul>
	</div>
	<div id="footbar">
	    <div class="fbc">
	        <ul>
	            <li {if $_GET['mod'] == 'index'}class="a"{/if}><a href="portal.php?mod=index&mobile=2" class="iconfont {if $_GET['mod'] == 'index'}icon-homefill{else}icon-home{/if}">{lang homepage}</a></li>
	            <li {if $_GET['mod'] == 'guide'}class="a"{/if}><a href="forum.php?mod=guide&view=newthread&mobile=2" class="iconfont {if $_GET['mod'] == 'guide'}icon-hotfill{else}icon-hot{/if}">{$_G[setting][navs][10][navname]}</a></li>            
	            <li {if $_GET['mod'] !== 'guide' && $_GET['order'] !== 'dateline' && $_GET['mod'] !== 'index' && $_GET['order'] !== 'replies' && $_GET['order'] !== 'views' && $_GET['order'] !== 'digest' && $_GET['mod'] !== 'space' && $_GET['mod'] !== 'forum' && $_GET['mod'] !== 'spacecp' && $_GET['mod'] !== 'logging' && $_GET['mod'] !== 'register' && $_GET['mod'] !== 'post' && $_GET['action'] !== 'nav'}class="a"{/if}><a href="forum.php?forumlist=1" class="iconfont {if $_GET['mod'] !== 'guide' && $_GET['order'] !== 'dateline' && $_GET['mod'] !== 'index' && $_GET['order'] !== 'replies' && $_GET['order'] !== 'views' && $_GET['order'] !== 'digest' && $_GET['mod'] !== 'space' && $_GET['mod'] !== 'forum' && $_GET['mod'] !== 'spacecp' && $_GET['mod'] !== 'logging' && $_GET['mod'] !== 'register' && $_GET['mod'] !== 'post' && $_GET['action'] !== 'nav'}icon-manage_fill{else}icon-manage{/if}">{$_G[setting][navs][2][navname]}</a></li>
	            <li class="btn-open-close"><a class="iconfont icon-add1">{lang more}</a></li>
	        </ul>
	    </div>
	</div>
</div>
<div class="btn-fullbg" style="display: none;"></div>
<script>
	var flag3 = 1;
	$(".btn-open-close,.btn-fullbg").click(function() {
	    if (flag3 == 1) {
	        $(".sub-footer,.btn-fullbg").show();
	        $(".icon-add1").addClass('color-red');
	        flag3 = 0;
	    } else {
	        $(".btn-fullbg,.sub-footer").hide();
	        $(".icon-add1").removeClass('color-red');
	        flag3 = 1;
	    }
	})
</script>
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->
