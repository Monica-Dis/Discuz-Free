<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-mobile">
	<div class="bz-mobile-left btn-open-close"><a class="iconfont icon-daohang"></a></div>
	<h2>{lang faq}</h2>
	<div class="bz-mobile-right">
		<a href="<!--{if $_GET['mod'] == 'forumdisplay' || $_GET['mod'] == 'viewthread'}-->forum.php?mod=post&action=newthread&fid=$_G['fid']<!--{else}-->forum.php?mod=misc&action=nav<!--{/if}-->" class="iconfont icon-post"></a>
	</div>
</div>
<div id="ct" class="cl bz-faq">
	<div class="mn">
		<div class="bz-p10 bz-bg-fff bzbb1">
			<form method="post" autocomplete="off" action="misc.php?mod=faq&action=search" style="width: 100%;text-align: center;">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="searchtype" value="all" />
				<input type="text" name="keyword" value="$keyword" placeholder="{lang enter_content}" class="px vm color-c z bz-bg-f5f5f5" style="width: 78%;-webkit-appearance: none;" />
				<button type="submit" name="searchsubmit" class="button2 vm y" value="yes"><em>{lang search}</em></button>
			</form>
		</div>
		<div class="bz-faq-appl">
			<div class="tbn">
				<ul>
					<li {if empty($_GET[action])} class="a"{/if}><a href="misc.php?mod=faq">{lang all}</a></li>
					<!--{loop $faqparent $fpid $parent}-->
					<li {if $_GET[id] == $fpid}class="a"{/if}><a href="misc.php?mod=faq&action=faq&id=$fpid">$parent[title]</a></li>
					<!--{/loop}-->
					<!--{if !empty($_G['setting']['plugins']['faq'])}-->
						<!--{loop $_G['setting']['plugins']['faq'] $id $module}-->
							<li {if $_GET[id] == $id}class="a"{/if}><a href="misc.php?mod=faq&action=plugin&id=$id">$module[name]</a></li>
						<!--{/loop}-->
					<!--{/if}-->
				</ul>
			</div>
		</div>
		<div class="banzhuan-clear bz-p10 bz-bg-fff bzbt1">
			<!--{if empty($_GET[action])}-->
				<div class="lum">
					<!--{if $fpid}-->
						<!--{loop $faqparent $fpid $parent}-->
							<h2 class="blocktitle"><a href="misc.php?mod=faq&action=faq&id=$fpid">$parent[title]</a></h2>
							<ul name="$parent[title]">
								<!--{loop $faqsub[$parent[id]] $sub}-->
									<li><a href="misc.php?mod=faq&action=faq&id=$sub[fpid]&messageid=$sub[id]">$sub[title]</a></li>
								<!--{/loop}-->
							</ul>
						<!--{/loop}-->
					<!--{else}-->
					    <div class="guide-no">
							<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
							<p class="color-b">No {lang faq}</p>
						</div>
					<!--{/if}-->
				</div>
			<!--{elseif $_GET[action] == 'faq'}-->
				<!--{loop $faqlist $faq}-->
					<div id="messageid$faq[id]_c">
						<h3><a>$faq[title]</a></h3>
					</div>
					<div class="um" id="messageid$faq[id]">$faq[message]</div>
				<!--{/loop}-->
			<!--{elseif $_GET[action] == 'search'}-->
				<h1 class="mt mbm"><a>{lang keyword_faq}</a></h1>
				<!--{if $faqlist}-->
					<!--{loop $faqlist $faq}-->
						<div class="umh schfaq"><h3><a>$faq[title]</a></h3></div>
						<div class="um">$faq[message]</div>
					<!--{/loop}-->
				<!--{else}-->
					<div class="guide-no">
						<p class="iconfont icon-quxiaoguanzhu color-b" style="font-size: 50px;"></p>
						<p class="color-b">{lang faq_search_nomatch}</p>
					</div>
				<!--{/if}-->
			<!--{elseif $_GET[action] == 'plugin' && !empty($_GET['id'])}-->
				<!--{eval include(template($_GET['id']));}-->
			<!--{/if}-->
		</div>
		
	</div>
</div>

<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
<!--{template common/footer_nav}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->

