<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<base href="{$_G['siteurl']}" />
<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}-->$_G['setting']['bbname'] - <!--{/if}-->Powered by Zzb7.Net!</title>
<link rel="icon" href="template/banzhuan_touch026/touch/banzhuan/images/banzhuan.ico">
<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>
<!--{if $_GET['mod'] !== 'misc'}-->
<script src="template/banzhuan_touch026/touch/banzhuan/jquery.min.js"></script>
<script type="text/javascript">var JQT = jQuery.noConflict();</script>
<script src="template/banzhuan_touch026/touch/banzhuan/jquery-1.8.3.min.js?{VERHASH}"></script>
<script src="{STATICURL}js/mobile/common.js?{VERHASH}" charset="{CHARSET}"></script>
<script>window.jQuery || document.write('<script src="js/jquery-2.1.1.min.js"><\/script>')</script>
<script src="template/banzhuan_touch026/touch/banzhuan/bznav.js"></script>
<script src="template/banzhuan_touch026/touch/banzhuan/swiper.min.js"></script>
<script src="template/banzhuan_touch026/touch/banzhuan/bzcom.js"></script>
<script src="template/banzhuan_touch026/touch/banzhuan/webuploader.min.js"></script>
<!--{else}-->
<script src="static/js/common.js?g9O" type="text/javascript"></script>
<!--{/if}-->
<link rel="stylesheet" href="template/banzhuan_touch026/touch/banzhuan/font/iconfont.css" type="text/css">
<link rel="stylesheet" href="template/banzhuan_touch026/touch/banzhuan/bzstyle.css" type="text/css" media="all"></head>
<body class="bg">
<!--{hook/global_header_mobile}-->