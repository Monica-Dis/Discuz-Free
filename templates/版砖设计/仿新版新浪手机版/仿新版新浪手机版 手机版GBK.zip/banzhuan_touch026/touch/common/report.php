<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->

<h3 class="title">{lang report}</h3>
<div class="tip">
	<form method="post" autocomplete="off" id="form_$_GET[handlekey]" name="form_$_GET[handlekey]" action="misc.php?mod=report">
		<div class="reason_slct bz-p10" id="return_$_GET[handlekey]">
			<p class="mtn mbn" id="report_reasons"></p>
			<div id="report_other" class="bzbb1" style="display:none; margin-top:10px; margin-left:-15px; margin-right:-15px;">
				<textarea id="report_message" name="message" class="reasonarea pt" rows="4" placeholder="{lang report_reason_other}"></textarea>		
			</div>
		</div>
		<p class="o pns">
			<span id="report_msg" style="display:none"><span class="z">{lang input_message1} <strong id="checklen">200</strong> {lang input_message2}</span></span>
			<button id="report_submit" type="submit" value="true" class="formdialog pnc"><strong>{lang confirms}</strong></button>
	        <a class="pnc close" href="javascript:;" onclick="popup.close();">{lang cancel}</a>
		</p>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="reportsubmit" value="true" />
		<input type="hidden" name="rtype" value="$_GET[rtype]" />
		<input type="hidden" name="rid" value="$_GET[rid]" />
		<!--{if $_GET['fid']}-->
		<input type="hidden" name="fid" value="$_GET[fid]" />
		<!--{/if}-->
		<!--{if $_GET['uid']}-->
		<input type="hidden" name="uid" value="$_GET[uid]" />
		<!--{/if}-->
		<input type="hidden" name="url" value="$_GET[url]" />
		<input type="hidden" name="inajax" value="$_G[inajax]" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
	</form>
</div>

<script type="text/javascript" reload="1">
	var reasons = {lang report_reason_message};
	var reasonstring = '';
	for (i=0; i<reasons.length; i++) {
		reasonstring += '<label><input type="radio" name="report_select" class="pr" onclick="Common.id(\'report_other\').style.display=\'' + (i < reasons.length -1 ? 'none' : '') + '\';" value="' + reasons[i] + '"> ' + reasons[i] + '</label>';
	}
	Common.id('report_reasons').innerHTML = reasonstring;
</script>
<!--{template common/footer}-->