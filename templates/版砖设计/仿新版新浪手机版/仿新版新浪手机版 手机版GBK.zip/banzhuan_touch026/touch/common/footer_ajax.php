<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{echo output_ajax()}-->]]></root><!--{eval exit;}-->