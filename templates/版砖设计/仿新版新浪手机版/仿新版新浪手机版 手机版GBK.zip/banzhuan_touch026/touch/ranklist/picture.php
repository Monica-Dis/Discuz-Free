<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-mobile">
	<div class="bz-mobile-left btn-open-close"><a class="iconfont icon-daohang"></a></div>
	<h2>&#22270;&#29255;</h2>
	<div class="bz-mobile-right">
		<a href="<!--{if $_GET['mod'] == 'forumdisplay' || $_GET['mod'] == 'viewthread'}-->forum.php?mod=post&action=newthread&fid=$_G['fid']<!--{else}-->forum.php?mod=misc&action=nav<!--{/if}-->" class="iconfont icon-post"></a>
	</div>
</div>
<div class="bz-appl4">
	<ul id="before" class="cl">
		<li {if $orderby=='all' }class="a" {/if}>
			<a href="misc.php?mod=ranklist&type=picture&view=$_GET[view]&orderby=all" id="all" />{lang all}</a>
		</li>
		<li {if $orderby=='thismonth' }class="a" {/if}>
			<a href="misc.php?mod=ranklist&type=picture&view=$_GET[view]&orderby=thismonth" id="2592000" />{lang ranklist_month}</a>
		</li>
		<li {if $orderby=='thisweek' }class="a" {/if}>
			<a href="misc.php?mod=ranklist&type=picture&view=$_GET[view]&orderby=thisweek" id="604800" />{lang ranklist_week}</a>
		</li>
		<li {if $orderby=='today' }class="a" {/if}>
			<a href="misc.php?mod=ranklist&type=picture&view=$_GET[view]&orderby=today" id="86400" />{lang ranklist_today}</a>
		</li>
	</ul>
</div>
<div class="cl">
	<!--{if $picturelist}-->
	<ul class="bz-picrank cl bz-m10">
		<!--{loop $picturelist $picture}-->
		<li>
			<div class="bz-picrank-pic">
				<a><img src="{$picture['url']}" /></a>
			</div>
			<!--{if $_GET[view] == 'hot'}-->
			<div>
				<!--{if $picture['rank'] <= 3}-->
				<img src="{IMGDIR}/rank_$picture['rank'].gif" alt="$picture['rank']" class="z" style="margin-top: 2px; margin-right: 2px;" />
				<!--{/if}-->
				<span class="z">{lang views} $picture[hot]</span>
				<em class="y">$picture[username]</em>
			</div>
			<!--{elseif $_GET[view] == 'sharetimes'}-->
			<!--{else}-->
			<!--{/if}-->

		</li>
		<!--{/loop}-->
	</ul>
	<!--{else}-->
	<div class="guide-no bzbt1 bzbb1">
		<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
		<p class="color-b">{lang none_data}</p>
	</div>
	<!--{/if}-->
</div>

<!--{hook/global_footer_mobile}-->
<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
<!--{template common/footer_nav}-->
</body>
</html>