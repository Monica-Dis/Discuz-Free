<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-mobile">
	<div class="bz-mobile-left btn-open-close"><a class="iconfont icon-daohang"></a></div>
	<h2>{lang activity}</h2>
	<div class="bz-mobile-right">
		<a href="<!--{if $_GET['mod'] == 'forumdisplay' || $_GET['mod'] == 'viewthread'}-->forum.php?mod=post&action=newthread&fid=$_G['fid']<!--{else}-->forum.php?mod=misc&action=nav<!--{/if}-->" class="iconfont icon-post"></a>
	</div>
</div>

<div class="cl">
	<div class="bz-actrank">
			<div class="bz-appl4">
				<ul id="before" class="cl">
					<li {if $orderby == 'all'}class="a"{/if}><a href="misc.php?mod=ranklist&type=activity&view=$_GET[view]&orderby=all" id="all" />{lang all}</a></li>
					<li {if $orderby == 'thismonth'}class="a"{/if}><a href="misc.php?mod=ranklist&type=activity&view=$_GET[view]&orderby=thismonth" id="2592000" />{lang ranklist_month}</a></li>
					<li {if $orderby == 'thisweek'}class="a"{/if}><a href="misc.php?mod=ranklist&type=activity&view=$_GET[view]&orderby=thisweek" id="604800" />{lang ranklist_week}</a></li>
					<li {if $orderby == 'today'}class="a"{/if}><a href="misc.php?mod=ranklist&type=activity&view=$_GET[view]&orderby=today" id="86400" />{lang ranklist_today}</a></li>	
				</ul>
			</div>
			
			<!--{if $activitylist}-->
				<ul>
					<!--{loop $activitylist $activity}-->
					<li class="bz-actrank bz-bg-fff bz-mb10 bzbt1 bzbb1">
						<div class="bz-actrank-box">
							<a href="forum.php?mod=viewthread&tid=$activity['tid']">
								<h2 class="color-a">$activity['subject']</h2>
								<div class="listimgbig">
									<ul class="listimg">
										<li>
											<!--{if $activity['aid']}-->
											<img src="$activity['attachurl']" />
											<!--{else}-->
											<img src="./template/banzhuan_pengyouquan/touch/banzhuan/images/nopic.png" />
											<!--{/if}-->
										</li>
									</ul>
								</div>
								<div class="list-body color-c">$activity['class']{lang ranklist_activity_start} $activity['starttimefrom']<!--{if $activity['starttimeto']}--> - $activity['starttimeto']<!--{/if}--><!--{if $activity['has_expiration']}-->{lang ranklist_activity_end}<!--{/if}--></div>
							</a>
						</div>
						<div class="bz-actrank-bottom">
						    <span class="bottom-views">
								<em class="color-b">{lang have} $activity['applynumber'] {lang join}</em>
					        </span>
					        <em class="y"><a href="forum.php?mod=viewthread&tid=$activity['tid']">&#25105;&#35201;&#25253;&#21517;</a></em>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
				<div class="cl">$multi</div>
			<!--{else}-->
				<div class="guide-no bzbt1 bzbb1">
					<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang none_data}</p>
				</div>
			<!--{/if}-->
		</div>

</div>

<!--{hook/global_footer_mobile}-->
<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
<!--{template common/footer_nav}-->
</body>
</html>

