<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<div class="sethreadlist">
	<h2 class="sethread_tit"><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	<!--{if empty($threadlist)}-->
	<ul class="bzbt1 bz-bg-fff"><li><a href="javascript:;">{lang search_nomatch}</a></li></ul>
	<!--{else}-->
			<ul class="bzbt1 bz-bg-fff">
				<!--{loop $threadlist $thread}-->
				<li>
					<a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" $thread[highlight]>$thread[subject]</a>
				</li>
				<!--{/loop}-->
			</ul>
	<!--{/if}-->
	$multipage
</div>
