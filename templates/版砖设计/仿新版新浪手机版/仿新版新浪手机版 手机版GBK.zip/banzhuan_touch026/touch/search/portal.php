<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-mobile">
	<div class="bz-mobile-left btn-open-close"><a class="iconfont icon-daohang"></a></div>
	<h2>
		<!--{if $_G['setting']['portalstatus'] && $_G['setting']['search']['portal']['status'] && ($_G['group']['allowsearch'] & 1 || $_G['adminid'] == 1)}-->
		<ul>
			<li><a href="search.php?mod=forum&mobile=2">{lang thread}</a></li>
			<li class="a"><a href="search.php?mod=portal&mobile=2">{lang portal}</a></li>
		</ul>
		<!--{else}-->
		{lang thread}
		<!--{/if}-->
	</h2>
	<div class="bz-mobile-right">
		<a href="<!--{if $_GET['mod'] == 'forumdisplay' || $_GET['mod'] == 'viewthread'}-->forum.php?mod=post&action=newthread&fid=$_G['fid']<!--{else}-->forum.php?mod=misc&action=nav<!--{/if}-->" class="iconfont icon-post"></a>
	</div>
</div>
<div>
	<form class="searchform" method="post" autocomplete="off" action="search.php?mod=portal" accept-charset="UTF-8">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{subtemplate search/pubsearch}-->
		<!--{hook/portal_top}-->
	</form>
	<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
		<!--{subtemplate search/portal_list}-->
	<!--{/if}-->
</div>

<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
<!--{template common/footer_nav}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->

