<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<div class="sethreadlist">
	<h2 class="sethread_tit"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	<!--{if empty($articlelist)}-->
	<ul class="bzbt1 bz-bg-fff"><li><a href="javascript:;">{lang search_nomatch}</a></li></ul>
	<!--{else}-->
			<ul class="bzbt1 bz-bg-fff">
				<!--{loop $articlelist $article}-->
				<li>
					<a href="{echo fetch_article_url($article);}">$article[title]</a>
				</li>
				<!--{/loop}-->
			</ul>
	<!--{/if}-->
	$multipage
</div>