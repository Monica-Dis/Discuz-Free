<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<div class="bzsearch bzbb1">
	<table width="100%" cellspacing="0" cellpadding="0">
		<tbody>
			<tr>
				<td>
					<input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="{lang enter_content}">
				</td>
				<td width="66" align="right">
					<div><input type="hidden" name="searchsubmit" value="yes"><input type="submit" value="{lang search}" class="button2" id="scform_submit"></div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
