<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-header">
	<div class="bz-header-left">
		<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
	</div>
	<h2>{lang comment}($csubject[commentnum])</h2>
	<div class="bz-header-right">
		<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
	</div>
</div>
<div id="ct" class="wp cl">
	<div>
		<div>
			<div class="bz-pv-title bz-p10 bz-bg-fff">
				<h2><a href="$url">$csubject[title]</a></h2>
			</div>
            <div>
				<ul class="bz-comment-list bzbt1 bz-bg-fff">
					<!--{loop $commentlist $comment}-->
						<!--{template portal/comment_li}-->
					<!--{/loop}-->
				</ul>
				<!--{if $pricount}-->
				<p class="mbn mtn">{lang hide_portal_comment}</p>
				<!--{/if}-->
				<div class="pgs cl bz-mtb10">$multi</div>
			</div>
		</div>
	</div>
</div>
<div class="banzhuan-bottom"></div>

<!--{hook/global_footer_mobile}-->

<div id="mask" style="display:none;"></div>
<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<div class="banzhuan-bottom"></div>
</body>
</html>
