<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-thread-share">
	<div class="bgDiv"></div>
	<div class="upNav"></div>
</div>
<div class="bz-header">
	<div class="bz-header-left">
		<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
	</div>
	<h2>&#35814;&#24773;</h2>
	<div class="bz-header-right">
		<a class="iconfont icon-fenxiang3 bzup"></a>
		<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
	</div>
</div>
<div class="bz-pv">
	<div class="bz-pv-title bz-plr10 bz-bg-fff">
		<h2 class="bz-ptb10">$article[title] <!--{if $article['status'] == 1}-->({lang moderate_need})<!--{elseif $article['status'] == 2}-->({lang ignored})<!--{/if}--></h2>
		<p class="color-b bz-pb10">
			$article[dateline]
			<span class="pipe">|</span>
			 {lang view_views}: 
			 <em id="_viewnum"><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}--></em>
			 <span class="pipe">|</span> {lang view_comments}:
			<!--{if $article[commentnum] > 0}-->
			<a href="$common_url" title="{lang view_all_comments}"><em id="_commentnum">$article[commentnum]</em></a>
			<!--{else}-->0
			<!--{/if}-->
			<!--{if $article[author]}-->
			<span class="pipe">|</span>{lang view_author_original}: $article[author]
			<!--{/if}-->
			
			<!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
			<!--{if $article[status]>0 && ($_G['group']['allowmanagearticle'] || $categoryperm[$value['catid']]['allowmanage'])}-->
			<span class="pipe">|</span>
			<a href="portal.php?mod=portalcp&ac=article&op=verify&aid=$article[aid]" id="article_verify_$article[aid]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang moderate}</a>
			<!--{else}-->
			<!--{/if}-->
			<!--{/if}-->
			<!--{hook/view_article_subtitle}-->
		</p>
	</div>
	<div class="bz-pv-sum bz-plr10 bz-bg-fff">
		<!--{if $article[summary] && empty($cat[notshowarticlesummay])}-->
		<div class="s">
			<div><strong>{lang article_description}</strong> $article[summary]</div>
			<!--{hook/view_article_summary}-->
		</div>
		<div class="banzhuan-h10"></div>
		<!--{/if}-->
	</div>
	<div class="bz-pv-main bz-p10 bz-bg-fff bzbb1">
		
		<div class="d">
			<table cellpadding="0" cellspacing="0" class="vwtb">
				<tr>
					<td id="article_content">
						<!--{if $content[title]}-->
						<div class="vm_pagetitle xw1">$content[title]</div>
						<!--{/if}-->
						$content[content]
					</td>
				</tr>
			</table>
			<!--{hook/view_article_content}-->
			<!--{if $multi}-->
			<div class="ptw pbw cl">$multi</div>
			<!--{/if}-->
			<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>

			<!--{if !empty($contents)}-->
			<div id="inner_nav" class="ptn xs1">
				<h3>{lang article_inner_navigation}</h3>
				<ul class="xl xl2 cl">
					<!--{loop $contents $key $value}-->
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
		</div>
		<!--{if $article[from]}-->
		<div class="bz-pv-main-from color-b">
			    {lang from}:
			<!--{if $article[fromurl]}-->
			    <a href="$article[fromurl]">$article[from]</a>
			<!--{else}-->
			    $article[from]
			<!--{/if}-->
		</div>
		<!--{/if}-->
		
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
		<div id="click_div">
			<!--{template home/space_click}-->
		</div>
	</div>
	<div class="cl bz-pv-main-a bz-p10 bz-bg-fff bzbb1">
		    <a class="dialog color-c y" href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}"><span><i class="iconfont icon-shoucang4"></i>{lang favorite}</span></a>
		    <!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
			    <!--{if $article[status]>0 && ($_G['group']['allowmanagearticle'] || $categoryperm[$value['catid']]['allowmanage'])}-->
					<a class="dialog color-c z" href="portal.php?mod=portalcp&ac=article&op=verify&aid=$article[aid]"><span><i class="iconfont icon-guanbi"></i>{lang moderate}</a>
			    <!--{else}-->
					<a class="dialog color-c z" href="portal.php?mod=portalcp&ac=article&op=delete&aid=$article[aid]"><span><i class="iconfont icon-guanbi"></i>{lang delete}</span></a>
				<!--{/if}-->
			<!--{/if}-->
	</div>
	<div class="bz-pv-next bz-p10 bz-bg-fff bz-mtb10 bzbt1 bzbb1">
		<!--{if $article['preaid'] || $article['nextaid']}-->
		<div class="pren cl">
			<!--{if $article['prearticle']}--><em>{lang pre_article}<a href="{$article['prearticle']['url']}">{$article['prearticle']['title']}</a></em>
			<!--{/if}-->
			<!--{if $article['nextarticle']}--><em>{lang next_article}<a href="{$article['nextarticle']['url']}">{$article['nextarticle']['title']}</a></em>
			<!--{/if}-->
		</div>
		<!--{/if}-->
	</div>
    <div class="bz-t-ad">
		 <!--{ad/article/hm/1}-->
		 <!--{ad/article/hm/2}-->
	     <!--{ad/article/hm/3}-->
	</div>
	<!--{if $article['related']}-->
	<div class="bz-pv-about bz-p10 bz-mtb10 bz-bg-fff bzbt1 bzbb1">
		<div id="related_article" class="bm">
			<div class="cl">
				<h3>&nbsp;&nbsp;{lang view_related}</h3>
			</div>
			<div>
				<ul class="xl xl2 cl" id="raid_div">
					<!--{loop $article['related'] $raid $rvalue}-->
					<input type="hidden" value="$raid" />
					<li><a href="{$rvalue[uri]}">{$rvalue[title]}</a></li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<!--{/if}-->
	
	<!--{if $article['allowcomment']==1}-->
		<!--{eval $data = &$article}-->
		
		<div class="cl bz-p10 bz-bg-fff bz-mt10 bzbt1"><h3 style="color: #999; font-size: 16px;">&#35780;&#35770;&#21015;&#34920;</h3></div>
		
		<!--{if $commentlist}-->
		
			<ul class="bz-comment-list bzbt1 bz-bg-fff">
					<!--{loop $commentlist $comment}-->
						<!--{template portal/comment_li}-->
					<!--{/loop}-->
			</ul>
			<!--{if !empty($pricount)}-->
			<p class="bz-m10 bz-p10 hm">{lang hide_portal_comment}</p>
			<!--{/if}-->
			<!--{if $data[commentnum]}-->
			<p class="bz-p10 bz-m10 hm">
				<a href="$common_url" class="bz-com-all bz-bg-fff">{lang view_all_comments}(<em id="_commentnum">$data[commentnum]</em>)</a>
			</p>	
			<!--{/if}-->
		
		<!--{else}-->
		
			<div class="guide-no bzbt1 bzbb1">
				<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
				<p class="color-b">&#36824;&#27809;&#26377;&#35780;&#35770;</p>
			</div>
		
		<!--{/if}-->
		
	<!--{/if}-->

</div>

<div>
	<form id="cform" name="cform" action="$form_url" method="post" autocomplete="off" accept-charset="UTF-8">
		  <dl id="editor" class="bz-reply-editor bz-bg-fff bzbt1">
			    <!--{if !empty($topicid) }-->
			    <input type="hidden" name="referer" value="$topicurl#comment" />
			    <input type="hidden" name="topicid" value="$topicid">
			    <!--{else}-->
			    <input type="hidden" name="portal_referer" value="$viewurl#comment">
			    <input type="hidden" name="referer" value="$viewurl#comment" />
			    <input type="hidden" name="id" value="$data[id]" />
			    <input type="hidden" name="idtype" value="$data[idtype]" />
			    <input type="hidden" name="aid" value="$aid">
			    <!--{/if}-->
			    <input type="hidden" name="formhash" value="{FORMHASH}">
			    <input type="hidden" name="replysubmit" value="true">
			    <input type="hidden" name="commentsubmit" value="true" />
			    
			    <h3 class="bz-p10 bzbb1 bz-bg-f5f5f5"><span>&#35780;&#35770;</span></h3>
			    <div class="postlist">
				      <div class="messagebox bz-p10 bz-bg-fff bzbb1">
				          <textarea id="comment_message"  name="message" style="height:100px;" placeholder="{lang send_reply_fast_tip}"></textarea>
				      </div>
				      <!--{if $secqaacheck || $seccodecheck}-->
						  <div class="bz-p10">
							     <!--{subtemplate common/seccheck}-->
					      </div>
					  <!--{/if}-->
				      <li class="bz-p10"> 
				      	  <a onclick="showFace('phizbox');Common.Switch(this,'phizbox');" class="phiz"><i class="iconfont icon-biaoqing color-c"></i></a>
				          <input type="submit" value="{lang comment}" class="pbutton y" name="commentsubmit_btn" id="fastpostsubmit">
				      </li>
			    </div>
			    <div class="sbox"><div id="phizbox" class="ebox"></div></div>
		  </dl>
	</form>
</div>

<script>
	function portal_comment_requote(cid, aid) {
	    $.ajax({
	    type:'GET',
	    url: 'portal.php?mod=portalcp&ac=comment&op=requote&cid='+cid+'&aid='+aid+'&inajax=1',
	    dataType:'xml'
	    }).success(function(s) {
	        if(s.lastChild.firstChild.nodeValue) {
				$('#comment_message').val(s.lastChild.firstChild.nodeValue);
				Common.popup('editor',1);
	        }
	    });
	}
	function showFace(showid, target, dropstr) {
		if($('#'+showid).html() == ''){
			var mhtml = '<div class="smilie bz-bg-fff">';
			var faceDiv = document.createElement("div");
			faceDiv.className = 'hd';
			for(i=1; i<31; i++) {
				mhtml += '<a data-id="[em:'+i+':]" onclick="Common.setsmilie(this,\'comment_message\');"><span><img src="' + STATICURL + 'image/smiley/comcom/'+i+'.gif" /></span></a>';
			}
			mhtml += '</div>';
			faceDiv.innerHTML = mhtml;
			$('#'+showid).append(faceDiv);
		}
	}
</script>

<div class="bz-com-fm">
	  <div class="bz-com-fm-return">
	  	    <ul>	<li><a href="javascript:history.back();" class="iconfont icon-fanhui"></a></li></ul>
	  </div>
	  <div class="bz-com-fm-reply">
	  	    <ul>
	    	    	    	<li>
                    <a class="color-b" href="javascript:;" <!--{if $article['allowcomment']==1}-->onclick="$('#comment_message').val('');Common.popup('editor',1);"<!--{else}-->onclick="popup.open('&#27492;&#25991;&#31456;&#31105;&#27490;&#35780;&#35770;', 'alert');"<!--{/if}-->><em class="iconfont icon-xie"></em>&#25105;&#26469;&#35828;&#20004;&#21477;...</a>
	    	    	    	</li>
    	    	    </ul>
	  </div>
    	  <div class="bz-com-fm-share">
    	    	    <ul>
    	    	    	    <li>
    	    	    	    		<a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" class="favorite dialog iconfont icon-shoucang4"></a>
    	    	    	    </li>
    	    	    	    <li>
    	    	    	        <a href="$common_url" class="iconfont icon-momentmessage"><!--{if $data[commentnum]}--><em id="_commentnum">$data[commentnum]</em><!--{/if}--></a>
    	    	    	    </li>
    	    	    </ul>
    	  </div>
</div>

<div class="banzhuan-bottom"></div>
<!--{hook/global_footer_mobile}-->
<div id="mask" style="display:none;"></div>
</body>
</html>