<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<li class="bzbb1 banzhuan-clear" id="comment_{$comment[cid]}_li">
	<!--{if $comment[uid]}-->
	<a href="home.php?mod=space&uid=$comment[authorid]&do=profile" class="avatar">{avatar($comment[uid],middle)}</a>
	<!--{else}-->
	<a class="avatar"><img src="{STATICURL}image/magic/hidden.gif" alt="hidden" /></a>
	<!--{/if}-->
	<h2>
		<span class="y color-b"><!--{date($comment[dateline])}--></span>
		<!--{if !empty($comment['uid'])}-->
		<a href="home.php?mod=space&uid=$comment[authorid]&do=profile" class="color-c">$comment[username]</a>
		<!--{else}-->
		{lang guest}
		<!--{/if}-->
	</h2>
	<div class="message"><!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->$comment[message]<!--{else}-->{lang moderate_not_validate}<!--{/if}--></div>
	<div class="y cl bz-comment-list-a">
		<!--{if ($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']}-->
		<a class="color-c" href="portal.php?mod=portalcp&ac=comment&op=delete&cid=$comment[cid]"><span><i class="iconfont icon-guanbi"></i>{lang delete}</span></a>
		<!--{/if}-->
		<!--{if ($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']}-->
		<!--<a class="color-c" href="portal.php?mod=portalcp&ac=comment&op=edit&cid=$comment[cid]"><span><i class="iconfont icon-xie"></i>{lang edit}</span></a>-->
		<!--{/if}-->
		<!--{if !isset($_G[makehtml])}-->
		<!--<a class="dialog color-c" href="javascript:;"><span><i class="iconfont icon-comment"></i>{lang quote}</span></a>-->
		<!--{/if}-->		  
	</div>
</li>
