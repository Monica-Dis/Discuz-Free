    <?php

    if(!defined('IN_DISCUZ')) {
            exit('Access Denied');
    }

    $fids='2,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95,96,97,98,99,100';

    if($_GET['order']=='dateline' || $_GET['order']=='views' || $_GET['order']=='replies' || $_GET['order']=='digest'){
            $order= $_GET['order'];
    }else{
            $order= 'dateline';
    }

    $messagelength='500';

    $num=10;
    $begin=($_G['page']-1)*$num;
    $manylist=array();
    require_once libfile('function/post');
    $rs=DB::query("
    SELECT t.*,p.message,p.pid,f.name
    FROM ".DB::table("forum_thread")." t
    LEFT JOIN ".DB::table("forum_post")." p on p.tid=t.tid
    LEFT JOIN ".DB::table("forum_forum")." f on f.fid=t.fid
    WHERE t.`fid` in ($fids) and t.displayorder>=0 and p.first=1
    group by t.tid
    ORDER BY t.`$order` DESC
    LIMIT $begin , $num");
    while ($rw=DB::fetch($rs)) {
            $rw['message']=messagecutstr($rw['message'],$messagelength,'');
            $rw['message']=dhtmlspecialchars($rw['message']);
            $manylist[]=$rw;
    }
    $allnum=DB::result_first("select count(*) from ".DB::table("forum_thread")." where fid in ($fids)");
    $pagenav=multi($allnum,$num,$_G['page'],"portal.php?order=$order#threadsbody");

    $uid = $_G[uid];
    $magic = mysqli_query("select * from ".DB::table('common_magiclog')." where uid=$uid");
    $magicnums = mysqli_num_rows($magic);
    $medal = mysqli_query("select * from ".DB::table('common_member_medal')." where uid=$uid");
    $medalnums = mysqli_num_rows($medal);
    $task = mysqli_query("select * from ".DB::table('common_task')." where available=2");
    $tasknums = mysqli_num_rows($task);

    ?>
