<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<base href="{$_G['siteurl']}" />
<title>$_G['setting']['sitename']</title>
<link rel="icon" href="template/banzhuan_touch026/touch/banzhuan/images/banzhuan.ico">
<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>
<!--{if $_GET['mod'] !== 'misc'}-->
<script src="template/banzhuan_touch026/touch/banzhuan/jquery.min.js"></script>
<script type="text/javascript">var JQT = jQuery.noConflict();</script>
<script src="template/banzhuan_touch026/touch/banzhuan/jquery-1.8.3.min.js?{VERHASH}"></script>
<script src="{STATICURL}js/mobile/common.js?{VERHASH}" charset="{CHARSET}"></script>
<script>window.jQuery || document.write('<script src="js/jquery-2.1.1.min.js"><\/script>')</script>
<script src="template/banzhuan_touch026/touch/banzhuan/bznav.js"></script>
<script src="template/banzhuan_touch026/touch/banzhuan/swiper.min.js"></script>
<script src="template/banzhuan_touch026/touch/banzhuan/bzcom.js"></script>
<script src="template/banzhuan_touch026/touch/banzhuan/webuploader.min.js"></script>
<!--{else}-->
<script src="static/js/common.js?g9O" type="text/javascript"></script>
<!--{/if}-->
<link rel="stylesheet" href="template/banzhuan_touch026/touch/banzhuan/font/iconfont.css" type="text/css">
<link rel="stylesheet" href="template/banzhuan_touch026/touch/banzhuan/bzstyle.css" type="text/css" media="all"></head>
<body class="bg">
<!--{hook/global_header_mobile}-->
<!--{eval require_once("template/banzhuan_touch026/touch/portal/list_data.php");}-->
<!--{template portal/index_diy}-->
<div class="bz-mtb10 bz-bg-fff bzbt1">
	<div>
		<p class="bz-p10 color-c"><em class="bz-line bz-line1-1"></em><em class="bz-line bz-line1-2"></em><em class="bz-line bz-line1-3"></em>&nbsp;&nbsp;&#26368;&#26032;&#24555;&#35759;</p>
		<div>
			<!--{eval $list_count=0;}-->
			<div id="banzhuan">
			<!--{loop $manylist $thread}-->
			<!--{eval $list_count+=1;}-->
			<!--{if $thread['attachment'] == 2}-->
				<!--{eval $table='forum_attachment_'.substr($thread['tid'], -1);}-->
				<!--{eval $query = DB::fetch_all("SELECT aid,tid,description,filename FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!=0 ORDER BY `dateline` DESC LIMIT 0,3"); }-->
				<!--{eval $picnum = count($query);}-->
				<!--{if $picnum < 4}-->
				<!--{eval $litpicnum = '1';}-->
				<!--{/if}-->
				<!--{eval $query2 = DB::fetch_all("SELECT aid,tid,description,filename FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!=0 ORDER BY `dateline` DESC LIMIT 0,$litpicnum"); }-->
				<!--{eval $thread['pics']=count($query2);}-->
				<!--{if $litpicnum == 1}-->
					<div class="bz-card-one">
						<div class="bz-card-title">
							<div class="bz-card-title-a">
							    <a href="forum.php?mod=viewthread&tid=$thread[tid]" onclick="atarget(this)">
							    <!--{if $thread['digest'] > 0}-->
								<i class="iconfont icon-jing color-red"></i>
								<!--{/if}-->
								$thread[subject]
							    </a>
							</div>
							<div class="bz-card-info banzhuan-clear">
								<div class="bz-card-info-name">
									<!--{if $thread[replies] > 0}-->
									<em class="color-c iconfont icon-comment">$thread[replies]&nbsp;&nbsp;</em>
									<!--{/if}-->
									<!--{if !$thread[author]}-->
									<a class="color-c">{lang anonymous}{lang guest}</a>
								    <!--{else}-->
									<a href="home.php?mod=space&uid=$thread[authorid]&do=profile&mobile=2" class="color-c">$thread[author]</a>
								    <!--{/if}-->
								</div>
							</div>
						</div>
						<!--{if $thread['pics'] > 0}-->
						<div class="bz-card-title-pic">
							<!--{loop $query2 $pic}-->
							<a href="forum.php?mod=viewthread&tid=$thread[tid]#aimg_$pic[aid]"><img src="{eval echo(getforumimg($pic[aid],0,200,140))}" /></a>
							<!--{/loop}-->
						</div>
						<!--{/if}-->
					</div>
				<!--{/if}-->
			<!--{else}-->
				<div class="bz-cz-card">
					<div class="thread-item-main">
						<h3>
							<a href="forum.php?mod=viewthread&tid=$thread[tid]">
								<!--{if $thread['digest'] > 0}-->
								<i class="iconfont icon-jing color-red"></i>
								<!--{/if}-->
								$thread[subject]
							</a>
						</h3>
						<div class="thread-item-info clearfix">
							<!--{if $thread[replies] > 0}-->
							<span class="thread-item-comment color-c iconfont icon-comment">$thread[replies]&nbsp;&nbsp;</span>
							<!--{/if}-->
							<span class="thread-item-view">
							    <!--{if !$thread[author]}-->
								<a class="color-c">{lang anonymous}{lang guest}</a>
							    <!--{else}-->
								<a href="home.php?mod=space&uid=$thread[authorid]&do=profile&mobile=2" class="color-c">$thread[author]</a>
							    <!--{/if}-->
							</span>
							<span class="thread-item-time color-c y">{echo date('Y-m-d', $thread['dateline']);}</span>
						</div>
					</div>
				</div>
			<!--{/if}-->
			<!--{/loop}-->
			</div>
			<!--{if !$_GET['order']}-->
			<div id="loading">
				<p class="color-b bz-p10">&#19978;&#25289;&#21152;&#36733;{lang more}...</p>
			</div>
			<!--{/if}-->
		</div>
		
		<script type="text/javascript">
		    jQuery(function(){
		        var downrange = 10;
		        var num = $_G['page']+1; 
		        var maxnum = num+100;
		        var main = jQuery("#banzhuan");
		        var loaddiv = jQuery("#loading");
		        var totalheight = 0;
		        function ifLoad(){
		            var scrolltotop=parseFloat(jQuery(window).scrollTop());
		            var winheight = parseFloat(jQuery(window).height());
		            var conheight = parseFloat(jQuery(document).height())-downrange;
		            totalheight = scrolltotop + winheight;
		
		            if(totalheight >= conheight && num!=maxnum){
		                ajaxLoad(num);
		                num++;
		            }
		        }
		
		        //ajax-fun
		        function ajaxLoad(page){
		            jQuery.ajax({
		                url:"bztouch026.php",
		                type:"post",
		                data:{page:page,maxnum:maxnum},
		                success:function(result){
		                        main.append(result);
		                }
		            })
		        }
		
		        loaddiv.ajaxStart(function(){
		             jQuery(this).show();
		            }).ajaxStop(function(){
		                jQuery(this).hide();
		            })
		        //scroll-fun
		        jQuery(window).scroll(ifLoad);
		
		    })
		</script>
				
	</div>
	<!--{if $_GET['order']}-->
	    $pagenav
	<!--{/if}-->
</div>
</div>
<script>
    var swiper = new Swiper('.swiper-container', {
        pagination: '.swiper-pagination',
        nextButton: '.swiper-button-next',
        prevButton: '.swiper-button-prev',
        paginationClickable: true,
        spaceBetween: 30,
        centeredSlides: true,
        autoplay: 3500,
        autoplayDisableOnInteraction: false
    });
</script>
<!--{template common/footer}-->