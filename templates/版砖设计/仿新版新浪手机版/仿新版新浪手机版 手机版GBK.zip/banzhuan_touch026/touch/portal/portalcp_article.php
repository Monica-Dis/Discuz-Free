<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->

<!--{if $op == 'delete'}-->

    <div class="bz-header">
		<div class="bz-header-left">
			<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
		</div>
		<h2>{lang delete}</h2>
		<div class="bz-header-right">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
		</div>
	</div>
	<div class="banzhuan-top"></div>
	<div class="bz-p10 bz-bg-fff bzbb1 hm">
		<form method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=article&op=delete&aid=$_GET[aid]">
			  <div class="tip">
			    <div class="bz-p10">
				      <!--{if $_G['group']['allowpostarticlemod'] && $article['status'] == 1}--> 
					      {lang article_delete_sure}
					      <input type="hidden" name="optype" value="0" class="pc" />
				      <!--{else}-->
					      <label class="lb">
					        <input type="radio" name="optype" value="0" class="pc" />
					        {lang article_delete_direct}
					      </label>
					      <label class="lb">
					        <input type="radio" name="optype" value="1" class="pc" checked="checked" />
					        {lang article_delete_recyclebin}
					      </label>
				      <!--{/if}--> 
			    </div>
			    <p class="o pns bz-mtb10">
				      <button type="submit" name="btnsubmit" value="true" class="pbutton"><strong>{lang confirms}</strong></button>
			    </p>
			    <input type="hidden" name="aid" value="$_GET[aid]" />
			    <input type="hidden" name="referer" value="{echo dreferer()}" />
			    <input type="hidden" name="deletesubmit" value="true" />
			    <input type="hidden" name="formhash" value="{FORMHASH}" />
			  </div>
		</form>
	</div>

<!--{elseif $op == 'verify'}-->

	<h3 class="flb"> 
		<em id="return_$_GET[handlekey]">{lang moderate_article}</em> 
	    <!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}--> 
	</h3>
	<form method="post" autocomplete="off" id="aritcle_verify_$aid" action="portal.php?mod=portalcp&ac=article&op=verify&aid=$aid">
		  <div class="c">
		    <label for="status_0" class="lb">
		      <input type="radio" class="pr" name="status" value="0" id="status_0"{if $article[status]=='1'} checked="checked"{/if} />
		      {lang passed}</label>
		    <label for="status_x" class="lb">
		      <input type="radio" class="pr" name="status" value="-1" id="status_x" />
		      {lang delete}</label>
		    <label for="status_2" class="lb">
		      <input type="radio" class="pr" name="status" value="2" id="status_2"{if $article[status]=='2'} checked="checked"{/if} />
		      {lang ignore}</label>
		  </div>
		  <p class="o pns">
		        <button type="submit" name="btnsubmit" value="true" class="pnc"><strong>{lang confirms}</strong></button>
		  </p>
		  <input type="hidden" name="aid" value="$aid" />
		  <input type="hidden" name="referer" value="{echo dreferer()}" />
		  <input type="hidden" name="handlekey" value="$_GET['handlekey']" />
		  <input type="hidden" name="verifysubmit" value="true" />
		  <input type="hidden" name="formhash" value="{FORMHASH}" />
	</form>

<!--{elseif $op == 'related'}--> 

	<!--{if $ra}-->
	<li id="raid_li_$ra[aid]">
	  <input type="hidden" name="raids[]" value="$ra[aid]" size="5">
	  [ $ra[aid] ] <a href="{echo fetch_article_url($ra);}" target="_blank">$ra[title]</a> 
	  <a href="javascript:;" onclick="raid_delete($ra[aid]);">{lang delete}</a>
	</li>
	<!--{/if}--> 

<!--{elseif $op == 'pushplus'}-->

	<h3 class="flb"> 
		<em>{lang article_pushplus}</em> 
	    <!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}--> 
	</h3>
	<form method="post" target="_blank" action="portal.php?mod=portalcp&ac=article&tid=$tid&aid=$aid">
		  <div class="c"> <b>$pushcount</b> {lang portalcp_article_message1}<a href="$article_url" target="_blank" class="xi2">({lang view_article})</a> 
		    <!--{if $pushedcount}--><br />
		    {lang portalcp_article_message2}<!--{/if}-->
		    <div id="pushplus_list"> 
		      <!--{loop $pids $pid}-->
		      <input type="hidden" name="pushpluspids[]" value="$pid" />
		      <!--{/loop}--> 
		    </div>
		  </div>
		  <p class="o pns">
		    <input type="hidden" name="formhash" value="{FORMHASH}" />
		    <input type="hidden" name="pushplussubmit" value="1" />
		    <input type="hidden" name="toedit" value="1" />
		    <button type="submit" class="pnc vm"><span>{lang submit}</span></button>
		  </p>
	</form>

<!--{elseif $op == 'add_success'}-->

    <div class="bz-header">
		<div class="bz-header-left">
			<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
		</div>
		<h2>{lang article_send_succeed}</h2>
		<div class="bz-header-right">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
		</div>
	</div>
	<div class="banzhuan-top"></div>

	<div class="nfl">
		  <div class="f_c altw">
		  	
			    <div class="alert_right bz-p10 bz-bg-fff hm bzbb1">
				      <p class="color-b">{lang article_send_succeed}</p>
				      <p class="alert_btnleft bz-ptb10"> 
					      	<a href="{$article_add_url}&op=edit&aid=$aid">{lang article_edit}</a> 
					      	<span class="pipe">|</span> 
					      	<a href="$article_add_url">{lang article_send_continue}</a> 
					      	<span class="pipe">|</span> 
					      	<a href="portal.php?mod=view&aid=$aid" target="_blank">{lang view_article}</a> 
					        <!--{if $htmlstatus}--> 
					        <span class="pipe">|</span> <span id='makehtml_' mktitle="{lang article}"></span> 
					        <!--{/if}--> 
				      </p>
			    </div>
			    
			    
		  </div>
	</div>
	<script src="{STATICURL}js/makehtml.js" type="text/javascript"></script> 
	<script type="text/javascript">
		<!--{if !empty($_G['cookie']['clearUserdata']) && $_G['cookie']['clearUserdata'] == 'home'}-->
			saveUserdata('home', '')
		<!--{/if}-->
		make_html('portal.php?mod=view&aid={$aid}', $('makehtml_'));
	</script> 

<!--{else}-->
	
	<div class="bz-header">
		<div class="bz-header-left">
			<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
		</div>
		<h2><!--{if !empty($aid)}-->{lang article_edit}<!--{else}-->{lang article_publish}<!--{/if}--></h2>
		<div class="bz-header-right">
			<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
		</div>
	</div>
	<div class="banzhuan-top"></div>
	
	<script type="text/javascript" src="template/banzhuan_touch026/touch/banzhuan/webuploader.min.js" charset="{CHARSET}"></script>
	<div class="bz-pcp-ar main">
		  <form method="post" autocomplete="off" id="articleform" action="portal.php?mod=portalcp&ac=article{if $_GET[modarticlekey]}&modarticlekey=$_GET[modarticlekey]{/if}" onsubmit="return validate(this);"accept-charset="UTF-8">
			    <div class="banzhuan-h10"></div>
			    <ul class="bzpostlist">
				      <li class="flexbox bz-bg-fff bzbt1"> 
					      	<span class="name">{lang article_title}</span> 
					      	<span class="html flex">
						        <input type="text" name="title" id="title" class="px" value="$article[title]" />
						        <input type="hidden" id="highlight_style_0" name="highlight_style[0]" value="$stylecheck[0]" />
						        <input type="hidden" id="highlight_style_1" name="highlight_style[1]" value="$stylecheck[1]" />
						        <input type="hidden" id="highlight_style_2" name="highlight_style[2]" value="$stylecheck[2]" />
						        <input type="hidden" id="highlight_style_3" name="highlight_style[3]" value="$stylecheck[3]" />
					        </span>
				      </li>
				      <li id="pagetitle_" class="flexbox bz-bg-fff bzbt1"{if $article[contents] < 2} style="display: none"{/if}> 
					      	<span class="name">{lang page_title}</span> 
					      	<span class="html flex">
					            <input type="text" name="pagetitle" id="pagetitle" class="px" value="$article_content[title]"/>
					        </span>
				      </li>
				      <div class="exfm">
					        <!--{if $_G['cache']['portalcategory'] && $categoryselect}-->
					        <li class="flexbox bz-bg-fff bzbt1"> 
						        	<span class="name">{lang article_category}</span> 
						        	<span class="html flex">$categoryselect</span>
					        </li>
					        <!--{/if}-->
					        <li class="flexbox bzbt1 align_center bz-bg-fff">
						        	<span class="name">{lang article_source}</span> 
						        	<span class="flex html" style="text-align:right;">
						        		<input type="text" id="from" name="from" class="px p_fre" value="$article[from]" {if $from_cookie}size="10"{else}size="30"{/if} />
						        </span>
						        <!--{if $from_cookie}--> 
							          <span class="html iocn">
								          <select name="from_cookie" id="from_cookie" onchange="$('#from').val($(this).find('option:selected').val());">
									            <option value="" selected>{lang choose_please}</option>
									            <!--{loop $from_cookie $var}-->
									            <option value="$var">$var</option>
									            <!--{/loop}-->
								          </select>
							          </span>
						        <!--{/if}-->
					        </li>
					        <li class="flexbox bz-bg-fff bzbt1"> 
						        	<span class="name">{lang article_source_url}</span> 
						        	<span class="html flex">
						        		<input type="text" name="fromurl" class="px p_fre" value="$article[fromurl]" size="30" />
						        </span>
					        </li>
					        <li class="flexbox bz-bg-fff bzbt1"> 
						        	<span class="name">{lang article_dateline}</span> 
						        	<span class="html flex">
						        		<input type="text" name="dateline" id="dateline" class="px p_fre" value="$article[dateline]" onclick="this.blur();Common.showcalendar(this);" />
						        </span>
					        </li>
					        <li class="flexbox bz-bg-fff bzbt1"> 
						        	<span class="name">{lang article_author}</span> 
						        	<span class="html flex">
						        		<input type="text" name="author" class="px p_fre" value="$article[author]" size="30" />
						        </span>
					        </li>
					        <!--{if $category[$catid][allowcomment]}-->
					        <li class="flexbox bz-bg-fff bzbt1"> 
						        	<span class="name">{lang article_comment_setup}</span> 
						        	<span class="html flex">
							          <label for="ck_allowcomment" style="display:block;text-align:right;">
								            <input type="checkbox" name="forbidcomment" id="ck_allowcomment" class="pc" value="1"{if isset($article['allowcomment']) && empty($article['allowcomment'])}checked="checked"{/if} />
								            {lang article_forbidcomment_description}
							          </label>
						        </span>
					        </li>
					        <!--{/if}-->
				      </div>
				      <li class="flexbox bzbt1"><span class="name">&#25991;&#31456;&#20869;&#23481;</span></li>
				      <li class="flexbox bz-bg-fff bzbt1">
					      	<span class="flex">
					        		<textarea class="userData" name="content" id="uchome-ttHtmlEditor" style="height:100px;">$article_content[content]</textarea>
					        </span>
				      </li>
				      <!--{eval $seditor = array('uchome-ttHtmlEditor', array('img', 'smilie'),'portal');}-->
				      <!--{template common/editor}-->
			    </ul>
			
			    <ul class="bzpostlist">
				      <li class="flexbox"><span class="name">{lang article_description}</span></li>
				      <li class="flexbox bz-bg-fff bzbt1">
					      	<span class="flex">
					        		<textarea name="summary" cols="80" class="pt" style="height: 50px;">$article[summary]</textarea>
					        </span>
				      </li>
				      <li class="flexbox bzbt1"><span class="name">{lang article_tag}</span></li>
				      <li class="bz-bg-fff bzbt1 bzbb1 sm"> 
					        <!--{loop $article_tags $key $tag}-->
					        <label for="article_tag_$key" class="lb">
						          <input type="checkbox" name="tag[$key]" id="article_tag_$key" class="pc"{if $article_tags[$key]} checked="checked"{/if} />
						          $tag_names[$key]
					        </label>
					        <!--{/loop}--> 
				      </li>
			    </ul>
			    <!--{if $secqaacheck || $seccodecheck}-->
			        <div class="bz-mt10 bz-p10 bz-bg-fff bzbt1 bzbb1">
					        <!--{subtemplate common/seccheck}-->
					</div>
			    <!--{/if}-->
			    
			    <div class="bz-p10 bz-mtb10">
			      	<button id="issuance" class="post_btn_pn" name="articlebutton"><strong>{lang submit}</strong></button>
			    </div>
			    
			    <input type="hidden" name="conver" id="conver" value="$article['conver']"/>
			    <input type="hidden" id="aid" name="aid" value="$article[aid]" />
			    <input type="hidden" name="cid" value="$article_content[cid]" />
			    <input type="hidden" id="attach_ids" name="attach_ids" value="0" />
			    <input type="hidden" name="articlesubmit" value="true" />
			    <input type="hidden" name="formhash" value="{FORMHASH}" />
			    
		  </form>
	</div>
	
	<script type="text/javascript">
		$('#articleform').on('submit', function() {
			if(!Common.sec_code(this,'sec_code2')){
				return false;
			}
		});
		$(document).on('click', '.del', function() {
			var obj = $(this);
			$.ajax({
				type:'GET',
				url:'portal.php?mod=attachment&aid=&op=delete&id=' + obj.attr('aid'),
			})
			.success(function(s) {
				obj.parent().remove();
			})
			.error(function() {
				popup.open('{lang networkerror}', 'alert');
			});
			return false;
		});
	</script> 

<!--{/if}--> 

<!--{hook/global_footer_mobile}-->
<div id="mask" style="display:none;"></div>
<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<div class="banzhuan-bottom"></div>
</body>
</html>


