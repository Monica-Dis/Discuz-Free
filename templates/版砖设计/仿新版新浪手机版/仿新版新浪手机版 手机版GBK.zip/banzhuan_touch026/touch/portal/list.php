<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-mobile">
	<div class="bz-mobile-left btn-open-close"><a class="iconfont icon-daohang"></a></div>
	<h2>&#36164;&#35759;-$cat[catname]</h2>
	<div class="bz-mobile-right">
		<a href="search.php?mod=forum&mobile=2" class="iconfont icon-search4"></a>
	</div>
</div>

<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->
<div id="ct" class="cl">
	<div class="bzpph">
		<div class="leveltab bz-bg-fff topnav" style="margin-top:0px;">
		    <p>
			    <!--{loop $cat[others] $value}-->
			    <a href="{$portalcategory[$value['catid']]['caturl']}" {if $cat['catid'] == $value['catid']}class="a"{/if}>$value[catname]</a> 
			    <!--{/loop}--> 
		    </p>
        </div>
	</div>
	<div class="mn">
		<div class="bm">
			<div class="bz-mtb10">
				<h3 class="bz-bg-fff bz-p10 bzbt1 bzbb1" style="font-size: 16px;">&#25991;&#31456;&#21015;&#34920;</h3>
				
				<!--{if $list['list']}-->
					<div class="xld">
					<!--{loop $list['list'] $value}-->
						<!--{eval $highlight = article_title_style($value);}-->
						<!--{eval $article_url = fetch_article_url($value);}-->
						<dl class="bbda cl bzc">
							<dd class="cl">
								<!--{if $value[pic]}-->
								<div class="bzc1">
									<div class="bzc1-two"><a href="$article_url"><img src="$value[pic]" /></a></div>
									<div class="bzc1-one">
										<h1><a href="$article_url" $highlight>$value[title]</a><!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}--></h1>
										<p><span>$value[dateline]&nbsp;</span><em class="iconfont icon-comment">&nbsp;$value[commentnum]</em><em class="iconfont icon-attention">&nbsp;$value[viewnum]</em></p>
									</div>
								</div>
								<!--{else}-->
								<div class="bzc0">
									<div class="bzc0-one">
										<h1><a href="$article_url" $highlight>$value[title]</a><!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}--></h1>
										<p><span>$value[dateline]&nbsp;</span><em class="iconfont icon-comment">&nbsp;$value[commentnum]</em><em class="iconfont icon-attention">&nbsp;$value[viewnum]</em></p>
									</div>
								</div>
								<!--{/if}-->
							</dd>
						</dl>
					<!--{/loop}-->
					</div>
				<!--{else}-->
				    <div class="guide-no bzbb1">
						<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
						<p class="color-b">&#36824;&#27809;&#26377;&#20219;&#20309;&#25991;&#31456;</p>
					</div>
				<!--{/if}-->	
		
			</div>
		</div>
		<!--{if $list['multi']}-->
		<div class="pgs cl">{$list['multi']}</div>
		<!--{/if}-->
		<div class="bz-t-ad">
			<!--{ad/articlelist/hm/1}-->
			<!--{ad/articlelist/hm/2}-->
			<!--{ad/articlelist/hm/3}-->
			<!--{ad/articlelist/hm/4}-->
		</div>
	</div>
</div>


<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<div class="banzhuan-bottom"></div>
<!--{template common/footer_nav}-->

