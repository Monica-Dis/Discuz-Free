<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{eval require_once("template/banzhuan_touch026/touch/portal/list_data.php");}-->
<!--{eval $list_count=0;}-->
<!--{loop $manylist $thread}-->
<!--{eval $list_count+=1;}-->
<!--{if $thread['attachment'] == 2}-->
	<!--{eval $table='forum_attachment_'.substr($thread['tid'], -1);}-->
	<!--{eval $query = DB::fetch_all("SELECT aid,tid,description,filename FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!=0 ORDER BY `dateline` DESC LIMIT 0,3"); }-->
	<!--{eval $picnum = count($query);}-->
	<!--{if $picnum < 4}-->
	<!--{eval $litpicnum = '1';}-->
	<!--{/if}-->
	<!--{eval $query2 = DB::fetch_all("SELECT aid,tid,description,filename FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!=0 ORDER BY `dateline` DESC LIMIT 0,$litpicnum"); }-->
	<!--{eval $thread['pics']=count($query2);}-->
	<!--{if $litpicnum == 1}-->
		<div class="bz-card-one">
			<div class="bz-card-title">
				<div class="bz-card-title-a">
				    <a href="forum.php?mod=viewthread&tid=$thread[tid]" onclick="atarget(this)">
				    <!--{if $thread['digest'] > 0}-->
					<i class="iconfont icon-jing color-red"></i>
					<!--{/if}-->
					$thread[subject]
				    </a>
				</div>
				<div class="bz-card-info banzhuan-clear">
					<div class="bz-card-info-name">
						<!--{if $thread[replies] > 0}-->
						<em class="color-c iconfont icon-comment">$thread[replies]&nbsp;&nbsp;</em>
						<!--{/if}-->
						<!--{if !$thread[author]}-->
						<a class="color-c">{lang anonymous}{lang guest}</a>
					    <!--{else}-->
						<a href="home.php?mod=space&uid=$thread[authorid]&do=profile&mobile=2" class="color-c">$thread[author]</a>
					    <!--{/if}-->
					</div>
				</div>
			</div>
			<!--{if $thread['pics'] > 0}-->
			<div class="bz-card-title-pic">
				<!--{loop $query2 $pic}-->
				<a href="forum.php?mod=viewthread&tid=$thread[tid]#aimg_$pic[aid]"><img src="{eval echo(getforumimg($pic[aid],0,200,140))}" /></a>
				<!--{/loop}-->
			</div>
			<!--{/if}-->
		</div>
	<!--{/if}-->
<!--{else}-->
	<div class="bz-cz-card">
		<div class="thread-item-main">
			<h3>
				<a href="forum.php?mod=viewthread&tid=$thread[tid]">
					<!--{if $thread['digest'] > 0}-->
					<i class="iconfont icon-jing color-red"></i>
					<!--{/if}-->
					$thread[subject]
				</a>
			</h3>
			<div class="thread-item-info clearfix">
				<!--{if $thread[replies] > 0}-->
				<span class="thread-item-comment color-c iconfont icon-comment">$thread[replies]&nbsp;&nbsp;</span>
				<!--{/if}-->
				<span class="thread-item-view">
				    <!--{if !$thread[author]}-->
					<a class="color-c">{lang anonymous}{lang guest}</a>
				    <!--{else}-->
					<a href="home.php?mod=space&uid=$thread[authorid]&do=profile&mobile=2" class="color-c">$thread[author]</a>
				    <!--{/if}-->
				</span>
				<span class="thread-item-time color-c y">{echo date('Y-m-d', $thread['dateline']);}</span>
			</div>
		</div>
	</div>
<!--{/if}-->
<!--{/loop}-->