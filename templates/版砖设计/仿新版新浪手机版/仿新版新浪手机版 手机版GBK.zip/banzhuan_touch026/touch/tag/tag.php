<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-mobile">
	<div class="bz-mobile-left btn-open-close"><a class="iconfont icon-daohang"></a></div>
	<h2>{lang tag}</h2>
	<div class="bz-mobile-right"><a href="forum.php?mod=misc&action=nav" class="iconfont icon-post"></a></div>
</div>
<!--{if $type != 'countitem'}-->
	<div id="ct" class="wp cl">
		<div class="bz-p10 bz-bg-fff bzbb1">
			<div class="bz-mtb10">
				<form method="post" action="misc.php?mod=tag" accept-charset="UTF-8" class="hm">
					<input type="text" name="name" placeholder="{lang enter_content}" class="px vm z bz-bg-f5f5f5" style="width: 78%;-webkit-appearance: none;" />
					<button type="submit" class="vm button2 y"><em>{lang search}</em></button>
				</form>
			</div>
			<div class="taglist bz-mtb10">
			<!--{if $tagarray}-->
				<!--{loop $tagarray $tag}-->
					<a href="misc.php?mod=tag&id=$tag[tagid]" title="$tag[tagname]" class="xi2">$tag[tagname]</a>
				<!--{/loop}-->
			<!--{else}-->
				<div class="guide-no">
					<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang no_tag}</p>
				</div>
			<!--{/if}-->
			</div>
		</div>
	</div>
<!--{else}-->
	$num
<!--{/if}-->

<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
<!--{template common/footer_nav}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->

	