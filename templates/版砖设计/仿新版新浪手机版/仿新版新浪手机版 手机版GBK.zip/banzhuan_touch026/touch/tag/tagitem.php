<?php echo 'Made by banzhuan,QQ:1074259861';exit;?>
<!--{template common/header}-->
<div class="bz-header">
	<div class="bz-header-left">
		<a href="javascript:history.back();" class="iconfont icon-fanhui"><em>{lang return}</em></a>
	</div>
	<h2><!--{if $tagname}-->{lang tag}: $tagname<!--{else}-->{lang tag}: $searchtagname<!--{/if}--></h2>
	<div class="bz-header-right">
		<a href="portal.php?mod=index&mobile=2" class="iconfont icon-home"></a>
	</div>
</div>
<div class="banzhuan-clear"></div>
<!--{if $tagname}-->
	
	<div id="ct" class="wp cl">
		<!--{if empty($showtype) || $showtype == 'thread'}-->
			<div class="bz-p10 bztagt bzbb1">
				<div class="bz-mtb10"><h2>{lang related_thread}</h2></div>
				<div>
					<!--{if $threadlist}-->
						<ul>
							<!--{loop $threadlist $thread}-->
							<li>
								<a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight]>$thread['subject']</a>
								<p class="color-c" style="line-height: 24px;">
									<!--{if $thread[folder] == 'lock'}-->
									<span class="iconfont icon-suo1 color-red"></span>
									<!--{elseif $thread['special'] == 1}-->
									<span class="iconfont icon-c_icon1 color-red"></span>
									<!--{elseif $thread['special'] == 2}-->
									<span class="iconfont icon-gouwu color-red"></span>
									<!--{elseif $thread['special'] == 3}-->
									<span class="iconfont icon-jianglishuoming color-red"></span>
									<!--{elseif $thread['special'] == 4}-->
									<span class="iconfont icon-huodong color-red"></span>
									<!--{elseif $thread['special'] == 5}-->
									<span class="iconfont icon-chajiepifb794b color-red"></span>
									<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
									<span class="iconfont icon-top01 color-red"></span>
									<!--{else}-->
									<!--{/if}-->
					
									<!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
									<span class="iconfont icon-jing color-red"></span>
									<!--{/if}-->
									<!--{if $thread['displayorder'] == 0}-->
									<!--{if $thread[recommendicon] && $filter != 'recommend'}-->
									<!--{/if}-->
					
									<!--{if $thread[heatlevel]}-->
									<span class="iconfont icon-hotfill color-red"></span>
									<!--{/if}-->
					
									<!--{if $thread['rate'] > 0}-->
									<!--{elseif $thread['rate'] < 0}-->
									<!--{/if}-->
									<!--{/if}-->
					
									<!--{if $thread['replycredit'] > 0}-->
									<!--{/if}-->
									<!--{if $thread[multipage]}-->
									<!--{/if}-->
					
									<!--{if $_G['setting']['threadhidethreshold'] && $thread['hidden'] >= $_G['setting']['threadhidethreshold']}-->
									<!--{/if}-->
					
									<!--{if $thread[icon] >= 0}-->
									<!--{/if}-->
					
									<!--{if $thread['rushreply']}-->
									<!--{/if}-->
					
									<!--{if $stemplate && $sortid}-->
									<!--{/if}-->
									<!--{if $thread['readperm']}-->
									<!--{/if}-->
									
									<!--{if $thread['price'] > 0}-->
									<!--{if $thread['special'] == '3'}-->
									<!--{else}-->
									<!--{/if}-->
									<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
									<!--{/if}-->
									
									<span style="font-size: 12px;">
										<!--{if $thread['authorid'] && $thread['author']}-->
										$thread[author]&nbsp;&nbsp;<!--{if !empty($verify[$thread['authorid']])}-->$verify[$thread[authorid]]&nbsp;&nbsp;<!--{/if}-->
										<!--{else}-->
										$_G[setting][anonymoustext]&nbsp;&nbsp;
										<!--{/if}-->
									</span>
									<span class="iconfont icon-attention color-b" style="font-size: 12px;"><em class="color-c">&nbsp;$thread[views]&nbsp;&nbsp;</em></span>
									<span class="iconfont icon-comment color-b" style="font-size: 12px;"><em class="color-c">&nbsp;$thread[replies]</em></span>
					
									<!--{if $view == 'hot'}-->
									<span class="color-b y" style="margin-left: 10px;">$thread['heats']{lang guide_attend}</span>
									<!--{/if}-->
									<!--{if $thread['attachment'] == 2}-->
									<span class="iconfont icon-tupian color-b y"></span>
									<!--{/if}-->	
					
				                  </p>
							</li>
							<!--{/loop}-->
						</ul>
						<!--{if empty($showtype)}-->
							<div class="hm bz-mtb10">
								<a class="color-c" href="misc.php?mod=tag&id=$id&type=thread">{lang more}...</a>
							</div>
						<!--{else}-->
							<!--{if $multipage}--><div class="pgs mtm cl">$multipage</div><!--{/if}-->
						<!--{/if}-->
					<!--{else}-->
						<div class="guide-no">
							<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
							<p class="color-b">{lang no_content}</p>
						</div>
					<!--{/if}-->
				</div>
			</div>
		<!--{/if}-->
		
	</div>

<!--{else}-->
	
	<div id="ct" class="wp cl">
		<div class="bz-p10 bz-bg-fff bzbb1">
			<div class="bz-mtb10">
				<form method="post" action="misc.php?mod=tag" accept-charset="UTF-8" class="pns hm">
					<input type="text" name="name" placeholder="{lang enter_content}" class="px vm z bz-bg-f5f5f5" style="width: 78%;-webkit-appearance: none;" />
					<button type="submit" class="vm button2 y"><em>{lang search}</em></button>
				</form>
			</div>
			<div class="taglist bz-mtb10">
				<div class="guide-no">
					<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">&#27809;&#26377;&#27492;{lang tag}</p>
				</div>
			</div>
		</div>
	</div>
	
<!--{/if}-->

<a href="javascript:history.back();" class="bz-rel"><i class="iconfont icon-fanhui"></i></a>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<div class="banzhuan-bottom"></div>
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->


