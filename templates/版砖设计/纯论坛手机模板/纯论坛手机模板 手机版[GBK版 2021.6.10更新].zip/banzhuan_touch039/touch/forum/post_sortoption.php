<?php echo 'From: DisM.taobao.com';exit;?>
<div class="bz-post-sortoption">
	<input type="hidden" name="selectsortid" size="45" value="$_G['forum_selectsortid']" />

	<!--{if $_G['forum_typetemplate']}-->

		<!--{if $_G['forum']['threadsorts']['description'][$_G['forum_selectsortid']] || $_G['forum']['threadsorts']['expiration'][$_G['forum_selectsortid']]}-->
			<div class="sinf bw0">
				<dl>
					<!--{if $_G['forum']['threadsorts']['description'][$_G['forum_selectsortid']]}-->
						<dt>{lang threadtype_description}</dt>
						<dd>$_G[forum][threadsorts][description][$_G[forum_selectsortid]]</dd>
					<!--{/if}-->
					<!--{if $_G['forum']['threadsorts']['expiration'][$_G['forum_selectsortid']]}-->
						<dt><span class="rq">*</span>{lang threadtype_expiration}</dt>
						<dd>
							<div class="ftid">
								<select name="typeexpiration" tabindex="1" id="typeexpiration">
									<option value="259200">{lang three_days}</option>
									<option value="432000">{lang five_days}</option>
									<option value="604800">{lang seven_days}</option>
									<option value="2592000">{lang one_month}</option>
									<option value="7776000">{lang three_months}</option>
									<option value="15552000">{lang half_year}</option>
									<option value="31536000">{lang one_year}</option>
								</select>
							</div>
							<!--{if $_G['forum_optiondata']['expiration']}--><span class="fb">{lang valid_before}: $_G[forum_optiondata][expiration]</span><!--{/if}-->
						</dd>
					<!--{/if}-->
				</dl>
			</div>
		<!--{/if}-->
		$_G[forum_typetemplate]
	
	<!--{else}-->

		<!--{if $_G['forum']['threadsorts']['description'][$_G['forum_selectsortid']]}-->
		<p class="grey bzbb1" style="font-style: italic;font-size: 12px;padding-bottom: 10px;margin-bottom: 10px;">{lang threadtype_description} : $_G[forum][threadsorts][description][$_G[forum_selectsortid]]</p>
		<!--{/if}-->
		<!--{if $_G['forum']['threadsorts']['expiration'][$_G['forum_selectsortid']]}-->
		<p class="bz-post-sortoption-p">
	        <label>{lang threadtype_expiration}<!--{if $_G['forum_optiondata']['expiration']}--><em class="grey" style="font-style: italic;font-size: 12px;"> {lang valid_before} : $_G[forum_optiondata][expiration]</em><!--{/if}--></label>
			<select name="typeexpiration" tabindex="1" id="typeexpiration" class="sort_sel">
				<option value="259200">{lang three_days}</option>
				<option value="432000">{lang five_days}</option>
				<option value="604800">{lang seven_days}</option>
				<option value="2592000">{lang one_month}</option>
				<option value="7776000">{lang three_months}</option>
				<option value="15552000">{lang half_year}</option>
				<option value="31536000">{lang one_year}</option>
			</select>
		</p>	
		<!--{/if}-->
		<!--{loop $_G['forum_optionlist'] $optionid $option}-->
		<div id="select_$option[identifier]">
			<!--{if in_array($option['type'], array('number', 'text', 'email', 'calendar', 'image', 'url', 'range', 'upload', 'range'))}-->
				<!--{if $option['type'] == 'calendar'}-->
				<p class="bz-post-sortoption-p">
					<label>
			        		$option[title]
			        		<!--{if $option['required']}--><span class="rq"> * </span><!--{/if}-->
			        		<em class="grey" style="font-style: italic;font-size: 12px;">
			        			{lang threadsort_calendar}&nbsp;
					        <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
								<!--{if $option['maxnum']}-->
									{lang maxnum} $option[maxnum]&nbsp;
								<!--{/if}-->
								<!--{if $option['minnum']}-->
									{lang minnum} $option[minnum]&nbsp;
								<!--{/if}-->
								<!--{if $option['maxlength']}-->
									{lang maxlength} $option[maxlength]&nbsp;
								<!--{/if}-->
								<!--{if $option['unchangeable']}-->
									{lang unchangeable}&nbsp;
								<!--{/if}-->
								<!--{if $option[description]}-->
									$option[description]
								<!--{/if}-->
							<!--{/if}-->
						</em>
					</label>
					<input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" tabindex="1" size="$option[inputsize]" value="$option[value]" $option[unchangeable] class="txt_s"/>
				</p>	
				<!--{elseif $option['type'] == 'image'}-->
				<p class="bz-post-sortoption-p">
					<label>
			        		$option[title]<!--{if $option['required']}--><span class="rq"> * </span><!--{/if}-->
				        <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
							<em class="grey" style="font-style: italic;font-size: 12px;">
							<!--{if $option['maxnum']}-->
								{lang maxnum} $option[maxnum]&nbsp;
							<!--{/if}-->
							<!--{if $option['minnum']}-->
								{lang minnum} $option[minnum]&nbsp;
							<!--{/if}-->
							<!--{if $option['maxlength']}-->
								{lang maxlength} $option[maxlength]&nbsp;
							<!--{/if}-->
							<!--{if $option['unchangeable']}-->
								{lang unchangeable}&nbsp;
							<!--{/if}-->
							<!--{if $option[description]}-->
								$option[description]
							<!--{/if}-->
							</em>
						<!--{/if}-->
					</label>
					<div class="grey" style="font-style: italic;font-size: 12px;">&#26242;&#19981;&#25903;&#25345;&#27492;&#21151;&#33021;, &#21487;&#20351;&#29992;&#24213;&#37096;&#20256;&#22270;&#25353;&#38062;&#25110;{lang nomobiletype}&#20256;&#22270;&#25353;&#38062;</div>
				</p>	
				<!--{else}-->
				<p class="bz-post-sortoption-p">
					<label>
			        		$option[title]<!--{if $option['required']}--><span class="rq"> * </span><!--{/if}-->
				        <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
							<em class="grey" style="font-style: italic;font-size: 12px;">
							<!--{if $option['maxnum']}-->
								{lang maxnum} $option[maxnum]&nbsp;
							<!--{/if}-->
							<!--{if $option['minnum']}-->
								{lang minnum} $option[minnum]&nbsp;
							<!--{/if}-->
							<!--{if $option['maxlength']}-->
								{lang maxlength} $option[maxlength]&nbsp;
							<!--{/if}-->
							<!--{if $option['unchangeable']}-->
								{lang unchangeable}&nbsp;
							<!--{/if}-->
							<!--{if $option[description]}-->
								$option[description]
							<!--{/if}-->
							</em>
						<!--{/if}-->
					</label>
					<input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="txt_s" tabindex="1" size="$option[inputsize]" value="{if $_G['tid']}$option[value]{else}{if $member_profile[$option['profile']]}$member_profile[$option['profile']]{else}$option['defaultvalue']{/if}{/if}" $option[unchangeable] />
				</p>	
				<!--{/if}-->
			<!--{elseif in_array($option['type'], array('radio', 'checkbox', 'select'))}-->
				<!--{if $option[type] == 'select'}-->
					<!--{loop $option['value'] $selectedkey $selectedvalue}-->
						<!--{if $selectedkey}-->
						<!--{else}-->
						<p class="bz-post-sortoption-p">
					        <label>
					        		$option[title]<!--{if $option['required']}--><span class="rq"> * </span><!--{/if}-->
						        <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
									<em class="grey" style="font-style: italic;font-size: 12px;">
									<!--{if $option['maxnum']}-->
										{lang maxnum} $option[maxnum]&nbsp;
									<!--{/if}-->
									<!--{if $option['minnum']}-->
										{lang minnum} $option[minnum]&nbsp;
									<!--{/if}-->
									<!--{if $option['maxlength']}-->
										{lang maxlength} $option[maxlength]&nbsp;
									<!--{/if}-->
									<!--{if $option['unchangeable']}-->
										{lang unchangeable}&nbsp;
									<!--{/if}-->
									<!--{if $option[description]}-->
										$option[description]
									<!--{/if}-->
									</em>
								<!--{/if}-->
							</label>
							<select tabindex="1" $option[unchangeable] class="sort_sel">
								<option value="0">{lang please_select}</option>
								<!--{loop $option['choices'] $id $value}-->
									<!--{if !$value[foptionid]}-->
									<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
									<!--{/if}-->
								<!--{/loop}-->
							</select>
						</p>	
						<!--{/if}-->
					<!--{/loop}-->
					<!--{if !is_array($option['value'])}-->
					<p class="bz-post-sortoption-p">
				        <label>
				        		$option[title]<!--{if $option['required']}--><span class="rq"> * </span><!--{/if}-->
					        <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
								<em class="grey" style="font-style: italic;font-size: 12px;">
								<!--{if $option['maxnum']}-->
									{lang maxnum} $option[maxnum]&nbsp;
								<!--{/if}-->
								<!--{if $option['minnum']}-->
									{lang minnum} $option[minnum]&nbsp;
								<!--{/if}-->
								<!--{if $option['maxlength']}-->
									{lang maxlength} $option[maxlength]&nbsp;
								<!--{/if}-->
								<!--{if $option['unchangeable']}-->
									{lang unchangeable}&nbsp;
								<!--{/if}-->
								<!--{if $option[description]}-->
									$option[description]
								<!--{/if}-->
								</em>
							<!--{/if}-->
						</label>
						<select tabindex="1" $option[unchangeable] class="sort_sel">
							<option value="0">{lang please_select}</option>
							<!--{loop $option['choices'] $id $value}-->
								<!--{if !$value[foptionid]}-->
								<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
								<!--{/if}-->
							<!--{/loop}-->
						</select>
					</p>	
					<!--{/if}-->
				<!--{elseif $option['type'] == 'radio'}-->
				<div style="padding: 30px 0 20px 0;">
			        <label style="font-size: 16px;">
			        		$option[title]<!--{if $option['required']}--><span class="rq"> * </span><!--{/if}-->
				        <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
							<em class="grey" style="font-style: italic;font-size: 12px;">
							<!--{if $option['maxnum']}-->
								{lang maxnum} $option[maxnum]&nbsp;
							<!--{/if}-->
							<!--{if $option['minnum']}-->
								{lang minnum} $option[minnum]&nbsp;
							<!--{/if}-->
							<!--{if $option['maxlength']}-->
								{lang maxlength} $option[maxlength]&nbsp;
							<!--{/if}-->
							<!--{if $option['unchangeable']}-->
								{lang unchangeable}&nbsp;
							<!--{/if}-->
							<!--{if $option[description]}-->
								$option[description]
							<!--{/if}-->
							</em>
						<!--{/if}-->
					</label>
			        <ul class="cl bz-post-sortoption-ul">
						<!--{loop $option['choices'] $id $value}-->
						<li style="margin-right: 10px;float: left;">
							<label>
								<input type="radio" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="bzpsul-input" tabindex="1" value="$id" $option['value'][$id] $option[unchangeable]>
								$value
							</label>
						</li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--{elseif $option['type'] == 'checkbox'}-->
				<div style="padding: 30px 0 20px 0;">
			        <label style="font-size: 16px;">
			        		$option[title]<!--{if $option['required']}--><span class="rq"> * </span><!--{/if}-->
				        <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
							<em class="grey" style="font-style: italic;font-size: 12px;">
							<!--{if $option['maxnum']}-->
								{lang maxnum} $option[maxnum]&nbsp;
							<!--{/if}-->
							<!--{if $option['minnum']}-->
								{lang minnum} $option[minnum]&nbsp;
							<!--{/if}-->
							<!--{if $option['maxlength']}-->
								{lang maxlength} $option[maxlength]&nbsp;
							<!--{/if}-->
							<!--{if $option['unchangeable']}-->
								{lang unchangeable}&nbsp;
							<!--{/if}-->
							<!--{if $option[description]}-->
								$option[description]
							<!--{/if}-->
							</em>
						<!--{/if}-->
					</label>
			        <ul class="cl bz-post-sortoption-ul">
						<!--{loop $option['choices'] $id $value}-->
						<li style="margin-right: 10px;float: left;">
							<label>
								<input type="checkbox" name="typeoption[{$option[identifier]}][]" id="typeoption_$option[identifier]" class="bzpsul-input" tabindex="1" value="$id" $option['value'][$id][$id] $option[unchangeable]>
								$value
							</label>
						</li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--{/if}-->
			<!--{elseif in_array($option['type'], array('textarea'))}-->
			<p class="bz-post-sortoption-p">
		        <label>
		        		$option[title]<!--{if $option['required']}--><span class="rq"> * </span><!--{/if}-->
			        <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->
						<em class="grey" style="font-style: italic;font-size: 12px;">
						<!--{if $option['maxnum']}-->
							{lang maxnum} $option[maxnum]&nbsp;
						<!--{/if}-->
						<!--{if $option['minnum']}-->
							{lang minnum} $option[minnum]&nbsp;
						<!--{/if}-->
						<!--{if $option['maxlength']}-->
							{lang maxlength} $option[maxlength]&nbsp;
						<!--{/if}-->
						<!--{if $option['unchangeable']}-->
							{lang unchangeable}&nbsp;
						<!--{/if}-->
						<!--{if $option[description]}-->
							$option[description]
						<!--{/if}-->
						</em>
					<!--{/if}-->
				</label>
		        <textarea name="typeoption[{$option[identifier]}]" tabindex="1" id="typeoption_$option[identifier]" rows="$option[rowsize]" cols="$option[colsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]', 0, 0{if $option[maxlength]}, '$option[maxlength]'{/if})" $option[unchangeable] class="txt_s">$option[value]</textarea>
			</p>	
			<!--{/if}-->
			
			$option[unit]
		</div>
		<!--{/loop}-->
	<!--{/if}-->

</div>

