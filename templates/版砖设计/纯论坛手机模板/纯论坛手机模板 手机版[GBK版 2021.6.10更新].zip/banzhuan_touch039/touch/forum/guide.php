<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->