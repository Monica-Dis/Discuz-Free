<?php echo 'From: DisM.taobao.com';exit;?>
<div class="bz_reward bz_sp_mtw bz_sp_mbw bz_sp_bg bz_sp_p15 cl">
	<div class="hm" style="color: #F85857;"><em class="iconfont icon-jianglishuoming" style="font-size: 70px;"></em></div>
	<div class="hm bz_sp_mbw" style="color: #F85857;"><strong>$rewardprice&nbsp;</strong>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</div>
	<div class="hm bz_sp_mtw bz_sp_mbw">{lang thread_reward}{if $_G['forum_thread']['price'] > 0}<span class="bz_sp_grey bz_sp_fz12">&nbsp;/&nbsp;{lang unresolved}</span>{elseif $_G['forum_thread']['price'] < 0}<span class="bz_sp_grey bz_sp_fz12">&nbsp;/&nbsp;{lang resolved}</span>{/if}</div>
</div>
<!--{if !$_G['uid'] && $_G['forum_thread']['price'] > 0 && !$_G['forum_thread']['is_archived']}-->
<div class="bz_sp_mtw bz_sp_mbw bz_sp_bbutton"><a href="member.php?mod=logging&action=login" class="touch" style="color: #FFF !important;">{lang reward_answer}</a></div>
<!--{/if}-->
<div class="bz_sp_clear"></div>

<!--{if $bestpost}-->
<div class="bz_reward bz_sp_bg bz_sp_p15 cl">
	<div class="hm bz_sp_mtw bz_sp_mbw">{lang reward_bestanswer}</div>
	<div class="pstl bz_sp_mbw">
		<div class="psti cl">
			<div class="z" style="width: 15%;">$bestpost[avatar]</div>
			<div class="z" style="width: 85%;">
				<a href="home.php?mod=space&uid=$bestpost[authorid]&do=profile&mobile=2">$bestpost[author]</a>
				<p class="bz_sp_grey">$bestpost[message]</p>
			</div>
		</div>
	</div>
</div>
<div class="bz_sp_clear"></div>
<!--{/if}-->

<div id="postmessage_$post[pid]" class="postmessage bz_sp_mtw bz_sp_mbw cl bz-table-snone">$post[message]</div>

<!--{if $post['attachment']}-->
	<div class="warning">{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em></div>
<!--{elseif $post['imagelist'] || $post['attachlist']}-->
    <!--{if $post['imagelist']}-->
         {echo showattach($post, 1)}
    <!--{/if}-->
    <!--{if $post['attachlist']}-->
         {echo showattach($post)}
    <!--{/if}-->
<!--{/if}-->
<!--{eval $post['attachment'] = $post['imagelist'] = $post['attachlist'] = '';}-->





