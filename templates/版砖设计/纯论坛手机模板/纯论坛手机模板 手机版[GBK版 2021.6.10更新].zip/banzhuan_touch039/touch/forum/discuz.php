<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:forum.php?forumlist=1&mobile=2');exit;}-->
<!--{/if}-->

<!--{template common/header}-->

<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<!--{if $_GET['visitclient']}-->

<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->
	
	<!--{if $showvisitclient}-->
	<div class="visitclienttip vm" style="display:block;">
		<a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>	
		<p>
			{lang downloadzslttoshareview}
		</p>
	</div>
	<script type="text/javascript">
		var visitclienthref = getvisitclienthref();
		if(visitclienthref) {
			$('#visitclientid').attr('href', visitclienthref);
			$('.visitclienttip').css('display', 'block');
		}
	</script>
	<!--{/if}-->
	
	<!--{hook/index_top_mobile}-->
	<div class="bz-in-bg">
		<div class="bz-in-bgcover"></div>
		<div class="bz-in-bg-logo"><a><img src="{$_G['style']['styleimgdir']}/banzhuan/images/logo.png"/></a></div>
		<!--{if $_G['style']['extstyle'] }-->
		<div class="bz-in-sehot">
			<ul>
				<li class="z cc" style="width: 10%;text-align: center;">
					<img src="{$_G['style']['styleimgdir']}/banzhuan/images/switch_style.png"/>
				</li>
				<li class="y a" style="width: 90%;"><a href="search.php?mod=forum&mobile=2"><em class="iconfont icon-search4"></em>{lang search}</a></li>
			</ul>
		</div>
		<!--{else}-->
		<div class="bz-in-sehot"><ul><li class="a z"><a href="search.php?mod=forum&mobile=2"><em class="iconfont icon-search4"></em>{lang search}</a></li></ul></div>
		<!--{/if}-->
	</div>
	
	<!--{if empty($gid) && $announcements}-->
		<div class="bz-p10">
			<div class="announcement">
			    <div class="z"><i class="iconfont icon-tongzhigonggao color-red"></i></div>
			    <ul id="ancl">$announcements</ul>
			</div>
		</div>
		<script>
		  setInterval(function(){
			  $('#ancl li:last').css({'height':'0px','opacity': '0'}).insertBefore('#ancl li:first').animate({'height':'44px','opacity': '1'}, 'slow', function(){
		          $(this).removeAttr('style');
		      });
		  },3000);
		</script>
	<!--{/if}-->
	
	<!--{if $_G['style']['extstyle']}-->
	<div class="bz-p10" id="stylelist" style="display: none;">
		<p class="hm mbm grey">{lang changestyle}</p>
	<!--{loop $_G['style']['extstyle'] $i $item}-->
	<b class="{if $item[0] == $_G[style][defaultextstyle]}cover{/if}" data-id="$item[0]"><i class="iconfont icon-newgou-copy" style="background-color:{$item[2]};"></i></b>
	<!--{/loop}-->
	</div>
	<!--{/if}-->
	
	<div class="bz-mt10" id="wp">
		<!--{loop $catlist $key $cat}-->
		<div class="bz-mb10 banzhuan-clear">
			<div class="bz-sub-show bzbb1 cl <!--{if !$_G[setting][mobile][mobileforumview]}--><!--{else}-->bz-sub-close<!--{/if}-->" href="#sub_forum_$cat[fid]">
		    		<h2><code></code><a href="javascript:;">$cat[name]</a></h2>
		    </div>
			<div id="sub_forum_$cat[fid]" class="sub_forum">
				<ul>
					<!--{loop $cat[forums] $forumid}-->
					<!--{eval $forum=$forumlist[$forumid];}-->
					<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
					<li>
						<div class="gengduo"><a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><i class="iconfont icon-gengduo"></i></a></div>
						<div class="name-pic">
		                    <!--{if $forum[icon]}-->
		                        {$forum[icon]}
		                    <!--{else}-->
		                        <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
									<img src="{$_G['style']['styleimgdir']}/banzhuan/images/forum.jpg" align="left" />
		                        </a>
		                    <!--{/if}-->
					    </div>
	                    	<div class="name-tit">
	                    		<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
	                    			<span class="fname">{$forum[name]}</span>
	                    			<!--{if $forum[todayposts] > 0}-->
	                    	        	<p>{lang forum_threads} <!--{echo dnumber($forum[threads])}--> / {lang posts} <!--{echo dnumber($forum[posts])}--> / <em style="color: #F74C31;">{lang index_today}: $forum[todayposts]</em></p>
	                    	        <!--{else}-->
	                    	        	<p>{lang forum_threads} <!--{echo dnumber($forum[threads])}--> / {lang posts} <!--{echo dnumber($forum[posts])}--></p>
	                    	        	<!--{/if}-->
	                    	    </a>
	                    	</div>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		<!--{/loop}-->
	</div>
	<!--{if empty($gid) && ($_G['cache']['forumlinks'][0] || $_G['cache']['forumlinks'][1] || $_G['cache']['forumlinks'][2])}-->
	<div class="banzhuan-clear">
		<div class="bz-h10 cl"></div>
		<div id="category_lk">
			<!--{if $_G['cache']['forumlinks'][0]}-->
			<ul class="m cl 0">$_G['cache']['forumlinks'][0]</ul>
			<!--{/if}-->
			<!--{if $_G['cache']['forumlinks'][1]}-->
			<div class="n cl 1">
				$_G['cache']['forumlinks'][1]
			</div>
			<!--{/if}-->
			<!--{if $_G['cache']['forumlinks'][2]}-->
			<ul class="x cl 2">
				$_G['cache']['forumlinks'][2]
			</ul>
			<!--{/if}-->
		</div>
	</div>
	<!--{/if}-->
	<!--{hook/index_middle_mobile}-->
	<script type="text/javascript">
		(function() {
			<!--{if !$_G[setting][mobile][mobileforumview]}-->
				$('.sub_forum').css('display', 'block');
			<!--{else}-->
				$('.sub_forum').css('display', 'none');
			<!--{/if}-->
			$('.bz-sub-show').on('click', function() {
				var obj = $(this);
				var subobj = $(obj.attr('href'));
				if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
				obj.removeClass('bz-sub-close');
				} else {
				subobj.css('display', 'none');
				obj.addClass('bz-sub-close');
				}
			});
		 })();
	</script>

<!--{/if}-->
<script type="text/javascript">
	var flag3 = 1;
	$(document).ready(function(){
	  $(".cc").click(function(){
	  	$("#stylelist").toggle(500);
	  });
	  $(".cc").click(function() {
	    if (flag3 == 1) {
	        $(".icon-nav").addClass('color-b');
	        flag3 = 0;
	    } else {
	        $(".icon-nav").removeClass('color-b');
	        flag3 = 1;
	    }
	  })
	});
</script>
<div class="banzhuan-clear"></div>
<!--{template common/footer}-->