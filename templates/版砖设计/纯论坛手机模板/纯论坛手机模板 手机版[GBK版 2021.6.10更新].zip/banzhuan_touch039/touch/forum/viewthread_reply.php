<?php echo 'From: DisM.taobao.com';exit;?>
<div class="bz_plc_reply cl banzhuan-clear bz-bg-fff" id="pid$post[pid]">
	<div class="cl" style="position: relative;">
		<span class="avatar"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, middle, true)}--><!--{else}--><!--{avatar($post[authorid], middle, true)}--><!--{/if}-->" style="width:32px;height:32px;" /></span>
		<ul class="authi">
			<li class="name">
			    <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
				    <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
				    <!--{if $_self}-->
					<a href="home.php?mod=space&uid=$post[authorid]&do=profile&mobile=2" class="blue" style="font-weight: 700;">$post[author]({lang thread_author})</a>
					<!--{else}-->
					<a href="home.php?mod=space&uid=$post[authorid]&do=profile&mobile=2" class="blue">$post[author]</a>
					<!--{/if}-->
				<!--{else}-->
					<!--{if !$post['authorid']}-->
					<a class="blue">{lang guest}<em> $post[useip]{if $post[port]}:$post[port]{/if}</em></a>
					<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
						<!--{if $_G['forum']['ismoderator']}--><a class="blue">{lang anonymous}</a><!--{else}--><a class="blue">{lang anonymous}</a><!--{/if}-->
					<!--{else}-->
					$post[author] <em>{lang member_deleted}</em>
					<!--{/if}-->
				<!--{/if}-->
				<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
				<i>$post[authortitle]</i>
	            <!--{if $post[gender] == 1}-->
	      	    <i class="iconfont icon-shouyezhuyetubiao06 bg-nan"></i>
	            <!--{/if}-->
	            <!--{if $post[gender] == 2}-->
	      	    <i class="iconfont icon-iconfontshouyezhuyetubiao07 bg-nv"></i>
	            <!--{/if}-->
				<!--{/if}-->
				<!--{if !$post[first] && $_G['forum_thread']['special'] == 5}-->
					<!--{if $post[stand] == 1}--><a class="grey" title="{lang debate_view_square}"> / {lang debate_square}</a>
						<!--{elseif $post[stand] == 2}--><a class="grey" title="{lang debate_view_opponent}"> / {lang debate_opponent}</a>
						<!--{else}--><a class="grey" title="{lang debate_view_neutral}"> / {lang debate_neutral}</a>
					<!--{/if}-->
				<!--{/if}-->
				<!--{hook/viewthread_postfooter $postcount}-->
				<!--{if $_G['setting']['magicstatus']}-->
					<ul id="mgc_post_$post[pid]_menu" class="p_pop mgcmn" style="display: none;">
					<!--{if $post['first']}-->
						<!--{if !empty($_G['setting']['magics']['bump'])}-->
							<li><a href="home.php?mod=magic&mid=bump&idtype=tid&id=$_G[tid]" id="a_bump" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/bump.small.gif" />$_G['setting']['magics']['bump']</a></li>
						<!--{/if}-->
						<!--{if !empty($_G['setting']['magics']['stick'])}-->
							<li><a href="home.php?mod=magic&mid=stick&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/stick.small.gif" />$_G['setting']['magics']['stick']</a></li>
						<!--{/if}-->
						<!--{if !empty($_G['setting']['magics']['close'])}-->
							<li><a href="home.php?mod=magic&mid=close&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/close.small.gif" />$_G['setting']['magics']['close']</a></li>
						<!--{/if}-->
						<!--{if !empty($_G['setting']['magics']['open'])}-->
							<li><a href="home.php?mod=magic&mid=open&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/open.small.gif" />$_G['setting']['magics']['open']</a></li>
						<!--{/if}-->
						<!--{if !empty($_G['setting']['magics']['highlight'])}-->
							<li><a href="home.php?mod=magic&mid=highlight&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/highlight.small.gif" />$_G['setting']['magics']['highlight']</a></li>
						<!--{/if}-->
						<!--{if !empty($_G['setting']['magics']['sofa'])}-->
							<li><a href="home.php?mod=magic&mid=sofa&idtype=tid&id=$_G[tid]" id="a_stick" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/sofa.small.gif" />$_G['setting']['magics']['sofa']</a></li>
						<!--{/if}-->
						<!--{if !empty($_G['setting']['magics']['jack'])}-->
							<li><a href="home.php?mod=magic&mid=jack&idtype=tid&id=$_G[tid]" id="a_jack" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/jack.small.gif" />$_G['setting']['magics']['jack']</a></li>
						<!--{/if}-->
						<!--{hook/viewthread_magic_thread}-->
					<!--{/if}-->
					<!--{if !empty($_G['setting']['magics']['repent']) && $post['authorid'] == $_G['uid'] && !$rushreply}-->
						<li><a href="home.php?mod=magic&mid=repent&idtype=pid&id=$post[pid]:$_G[tid]" id="a_repent_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/repent.small.gif" />$_G['setting']['magics']['repent']</a></li>
					<!--{/if}-->
					<!--{if !empty($_G['setting']['magics']['anonymouspost']) && $post['authorid'] == $_G['uid']}-->
						<li><a href="home.php?mod=magic&mid=anonymouspost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_anonymouspost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/anonymouspost.small.gif" />$_G['setting']['magics']['anonymouspost']</a><li>
					<!--{/if}-->
					<!--{if !empty($_G['setting']['magics']['namepost'])}-->
						<li><a href="home.php?mod=magic&mid=namepost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_namepost_$post[pid]" onclick="showWindow(this.id, this.href)"><img src="{STATICURL}image/magic/namepost.small.gif" />$_G['setting']['magics']['namepost']</a><li>
					<!--{/if}-->
					<!--{hook/viewthread_magic_post $postcount}-->
					</ul>
				<!--{/if}-->
				
				<em class="y color-c fz12">
				<!--{if isset($post[isstick])}-->
					<img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="ding" />
				<!--{elseif $post[number] == -1}-->
				<!--{else}-->
					<!--{if !empty($postno[$post[number]])}-->
					    $postno[$post[number]] {$post[number]}{$postnostick}
					<!--{else}-->
					    {$post[number]}{$postnostick}
					<!--{/if}-->
				<!--{/if}-->
				</em>
				
			</li>
    	</ul>
   	</div>
    <div class="message">
   	 	<!--{if $post['warned']}-->
            <span class="color-c quote">{lang warn_get}</span>
        <!--{/if}-->
        <!--{if !$post['first'] && !empty($post[subject])}-->
            <h2><strong>$post[subject]</strong></h2>
        <!--{/if}-->
         
        <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
            <div class="color-c quote">{lang message_banned}</div>
        <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
            <div class="color-c quote">{lang message_single_banned}</div>
        <!--{elseif $needhiddenreply}-->
            <div class="color-c quote">{lang message_ishidden_hiddenreplies}</div>
        <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
			<!--{template forum/viewthread_pay}-->
		<!--{else}-->
		
        	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                <div class="color-c quote">{lang admin_message_banned}</div>
            <!--{elseif $post['status'] & 1}-->
                <div class="color-c quote">{lang admin_message_single_banned}</div>
            <!--{/if}-->
            <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
            <!--{/if}-->

            <!--{if $post['first'] && $threadsort && $threadsortshow}-->
            	   <!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                    <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                        {lang has_expired}
                    <!--{else}-->
                        <div class="box_ex2 viewsort">
				            <div class="bz-at-form bz-mtb10">
				            	<h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
								<table cellpadding="0" cellspacing="1" border="0">
						            <!--{loop $threadsortshow['optionlist'] $option}--> 
						            <!--{if $option['type'] != 'info'}-->
									<tr>
										<th>$option[title]:</th>
										<td>
											<!--{if $option['value']}-->
											<!--{eval preg_match("/(".str_replace("/",'\/',$_G['setting']['attachurl']).")(.*?)((.gif)|(.jpg)|(.jpeg)|(.bmp)|(.png))/",strtolower($option['value']),$dzlab_match);}-->
												<!--{if count($dzlab_match)}-->
												<img src='$dzlab_match[0]' />
												<!--{else}-->
												$option[value]
												<!--{/if}-->
											    $option[unit]
											<!--{else}-->
											--
											<!--{/if}-->
										</td>
									</tr>
						            <!--{/if}-->
						            <!--{/loop}-->
				              	</table>
						    </div>
                        </div>
                    <!--{/if}-->
                <!--{/if}-->
            <!--{/if}-->

            <div class="bz-table-snone">$post[message]</div>

		<!--{/if}-->
			
        <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
			<!--{if $post['attachment']}-->
               <div class="color-c quote">
               {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
               </div>
            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
               	<!--{if $post['imagelist']}-->
				<!--{if count($post['imagelist']) == 1}-->
				<ul class="img_one">{echo showattach($post, 1)}</ul>
				<!--{else}-->
				<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
				<!--{/if}-->
				<!--{/if}-->
                <!--{if $post['attachlist']}-->
				<ul>{echo showattach($post)}</ul>
				<!--{/if}-->
			<!--{/if}-->
		<!--{/if}-->
		
	</div>
	<div class="times">
		<span class="fz12 color-c">$post[dateline]&nbsp;&nbsp;</span>

		<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid']))}-->
		<!--{if $_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first']}-->
		<!--{if $_G['forum']['ismoderator']}-->
		<!--{else}-->
		<a class="color-red fz12" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a>
		<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->
		
		<!--{if $_G['forum']['ismoderator']}-->
		<a href="#moption_$post[pid]" class="popup color-red fz12">{lang manage}</a>
		<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
			<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
			<!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
			<!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
			<!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
		</div>
		<!--{/if}-->
		<a class="color-c y" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page">&nbsp;&nbsp;&nbsp;&nbsp;<i class="iconfont icon-message color-c fz12"></i></a>
		
		<!--{if isset($post[isstick])}-->
			<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
			<a class="replyadd color-c y" href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" onmouseover="this.title = ($('review_support_$post[pid]').innerHTML ? $('review_support_$post[pid]').innerHTML : 0) + ' {lang activity_member_unit} {lang support_reply}'"><i id="review_support_$post[pid]" class="fz12 color-c">$post[postreview][support]</i><i class="iconfont icon-zan fz12 color-c"></i></a>
			<!--{/if}-->
		<!--{elseif $post[number] == -1}-->
			<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
			<a class="replyadd color-c y" href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" onmouseover="this.title = ($('review_support_$post[pid]').innerHTML ? $('review_support_$post[pid]').innerHTML : 0) + ' {lang activity_member_unit} {lang support_reply}'"><i id="review_support_$post[pid]" class="fz12 color-c">$post[postreview][support]</i><i class="iconfont icon-zan fz12 color-c"></i></a>
			<!--{/if}-->
		<!--{else}-->
			<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
			<a class="replyadd color-c y" href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" onmouseover="this.title = ($('review_support_$post[pid]').innerHTML ? $('review_support_$post[pid]').innerHTML : 0) + ' {lang activity_member_unit} {lang support_reply}'"><i id="review_support_$post[pid]" class="fz12 color-c">$post[postreview][support]</i><i class="iconfont icon-appreciatelight fz12 color-c"></i></a>
			<!--{/if}-->
		<!--{/if}-->
		
	</div>
	<!--{ad/interthread/bz_vt_reply_ad bzbb1 hm/$postcount}-->
</div>



