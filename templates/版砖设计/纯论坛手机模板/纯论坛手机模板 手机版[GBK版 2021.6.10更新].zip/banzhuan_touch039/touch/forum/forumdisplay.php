<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{hook/forumdisplay_top_mobile}-->
<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || $_G['forum']['threadsorts'] }-->
<div class="bz-h10"></div>
<!--{/if}-->
<!--{if !$subforumonly}-->
	<!--{if $sublist > 0}-->
	<div class="bz-sub-nav bz-plrb10">
		<a style="background: #F2F2F2;">{lang forum_subforums}&nbsp;&nbsp;:</a>
		<!--{loop $sublist $sub}-->
		<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}<!--{if empty($sub[redirect])}--><!--{if $sub[threads] > 0}--><i class="grey" style="-webkit-transform: scale(0.8,0.8); display: inline-block;">&nbsp;&nbsp;<!--{echo dnumber($sub[threads])}--></i><!--{/if}--><!--{/if}--></a>
		<!--{/loop}-->
	</div>
	<div class="banzhuan-clear"></div>
	<!--{/if}-->
<!--{else}-->
	<!--{subtemplate forum/forumdisplay_subforumonly}-->
<!--{/if}-->
<!--{subtemplate forum/forumdisplay_threadtypes}-->
<!--{if !$subforumonly}-->
<div class="bm_h cl bz-bg-fff bzbt1">
	<span class="z">{lang forum_thread}</span>
	<!--{if empty($_G['forum']['picstyle'])}-->
	<!--{else}-->
	<!--{if empty($_G[ 'cookie'][ 'forumdefstyle'])}-->
	<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="chked z grey"><i class="iconfont icon-camera fz12"></i></a>
	<!--{else}-->
	<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="unchk z grey"><i class="iconfont icon-camerafill fz12"></i></a>
	<!--{/if}-->
	<!--{/if}-->
	<!--{if CURMODULE != 'guide'}-->
    <div class="type y">
	    <a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="{if $_GET['filter'] !== 'lastpost' && $_GET['filter'] !== 'heat' && $_GET['filter'] !== 'digest' } a{/if}">{lang all}</a>
		<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'lastpost'} a{/if}">{lang latest}</a>
		<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'heat'} a{/if}">{lang order_heats}</a>
		<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'digest'} a{/if}">{lang digest_posts}</a>
    </div>
	<!--{/if}-->
</div>
<div class="bz-fd banzhuan-clear">
    <!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
    <ul>
	    <li class="bz-plr10 bz-bg-fff line bzbb1">
	    	<a href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]"><span class="iconfont icon-tongzhigonggao color-red"></span> <em>$announcement[subject]</em></a>
	    </li>
    </ul>
    <!--{/if}-->
    <div class="cl">
	      <ul id="threadlist">
	        <!--{if $_G['forum_threadcount']}-->
	        
		        <!--{loop $_G['forum_threadlist'] $key $thread}--> 
		        
			        <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}--> 
			        {eval $displayorder_thread = 1;} 
			        <!--{/if}--> 
			        <!--{if $thread['moved']}--> 
			        	<!--{eval $thread[tid] = $thread[closed];}--> 
			        <!--{/if}--> 
			        
			        <!--{if !empty($_G['forum']['picstyle']) && !$_G['cookie']['forumdefstyle']}-->
			        
			        <li class="picstyle bz-bg-fff">
						<div class="c cl">
							<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="$thread[subject]" class="z">
								<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4)) && $thread['digest'] > 0}-->
								<i>{lang thread_sticky} / {lang thread_digest}</i>
								<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
								<i>{lang thread_sticky}</i>
								<!--{elseif $thread['digest'] > 0}-->
								<i>{lang thread_digest}</i>
								<!--{else}-->
								<!--{/if}-->
								<!--{if $thread['cover']}-->
								<img src="$thread[coverpath]" alt="$thread[subject]"/>
								<!--{else}-->
								<span class="nopic" style="width: 100%; height: 120px;"></span>
								<!--{/if}-->
							</a>
						</div>
					</li>
			        
			        <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
			        
			        <li class="bz-plr10 bz-bg-fff line bzbb1"> 
			           <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"><span class="iconfont icon-ding color-red"></span> <em $thread[highlight]>{$thread[subject]}</em></a>
			        </li>
			        
			        <!--{else}-->
			        
			        <li id="thread_{$thread['tid']}"> 
			            <!--{hook/forumdisplay_thread_mobile $key}-->
                        <div class="bz-fd-card">
                            <header class="bzfdtlh">
					            <div class="bzfdtlh-left">
							        <!--{if !$thread[author]}-->
					              	<a class="avatar">{avatar($thread[0],middle)}</a>
					              	<!--{else}-->
					              	<a class="avatar" href="home.php?mod=space&uid=$thread[authorid]&do=profile">{avatar($thread[authorid],middle)}</a>
					              	<!--{/if}-->
							    </div>
							    	<div class="bzfdtlh-middle">
								    <div class="name">
										<!--{if !$thread[author]}-->
										<a class="blue">{lang anonymous}</a>
										<!--{else}-->
										<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="blue">$thread[author]</a>
											<!--{if !empty($verify[$thread['authorid']])}-->
												$verify[$thread[authorid]]
											<!--{/if}-->
										<!--{/if}-->
										<!--{eval $thread[agroupid] = DB::result_first('SELECT groupid FROM '.DB::table('common_member').' WHERE uid='.$thread[authorid].'')}-->
										<!--{if $thread[agroupid]}-->
											<!--{eval $thread[astars] = DB::result_first('SELECT stars FROM '.DB::table('common_usergroup').' WHERE groupid='.$thread[agroupid].'')}-->
										<!--{else}-->
											<!--{eval $thread[astars] = 0}-->
										<!--{/if}-->
										<!--{if !$thread[author]}-->
										<!--{else}-->
											<!--{if $thread[astars]}--><span class="name-lv"> Lv.$thread['astars']</span><!--{/if}-->
										<!--{/if}-->
								    </div>
								    <div class="data">
								   		<span class="color-c fz12">$thread[dateline] </span>
										<!--{if $thread['special'] == 1}-->
										<span class="name-a name-b">{lang thread_poll}</span>
										<!--{elseif $thread['special'] == 2}-->
										<span class="name-a name-b">{lang thread_trade}</span>
										<!--{elseif $thread['special'] == 3}-->
										<span class="name-a name-b">{lang thread_reward}</span>
										<!--{elseif $thread['special'] == 4}-->
										<span class="name-a name-b">{lang thread_activity}</span>
										<!--{elseif $thread['special'] == 5}-->
										<span class="name-a name-b">{lang thread_debate}</span>
										<!--{/if}-->
										<!--{if $thread['digest'] > 0 }-->
										<span class="name-a">{lang thread_digest}$thread[digest]</span>
										<!--{/if}-->
										<span class="y color-c"><i class="iconfont icon-attention fz12"></i><em>$thread[views]</em></span>
										<!--{if $thread[replies] > 0}--><span class="y color-c"><i class="iconfont icon-message fz12"></i><em>{$thread[replies]}</em><i class="color-b fz12 i"> / </i></span><!--{/if}-->
										<!--{if $thread[recommendicon] && $filter != 'recommend'}--><span class="y color-c"><i class="iconfont icon-appreciatelight fz12"></i><em>$thread[recommends]</em><i class="color-b fz12 i"> / </i></span><!--{/if}-->
										<!--{if $thread[heatlevel]}--><span class="y color-c"><!--{if $_GET['orderby'] == 'heats' }--><i class="iconfont icon-hotfill fz12 color-red"></i><!--{else}--><i class="iconfont icon-hot fz12"></i><!--{/if}--><em>{$thread[heats]}</em><i class="color-b fz12 i"> / </i></span><!--{/if}-->
								    </div>
							    </div>
                            </header>
                            <!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
				            <!--{eval $bzsum = messagecutstr(DB::result_first('SELECT `message` FROM '.DB::table('forum_post').' WHERE `tid` ='.$thread[tid].' AND `first` =1'),90);}-->
                            <section class="bzfdtld"<!--{if $bzsum}--><!--{else}--> style="padding-bottom: 20px;"<!--{/if}-->>
                                <a href="forum.php?mod=viewthread&tid=$thread[tid]">
                                    <h2><span $thread[highlight]>$thread[subject]</span></h2>
				                    <!--{if $bzsum}--><p class="cl">$bzsum</p><!--{/if}-->
                           	   </a>
                            </section>
                         </div>
			        </li>
			        
			        <!--{/if}-->
		        
		        <!--{/loop}-->
	        
	        <!--{else}-->

	        <li class="bz-p10 bz-bg-fff bzbb1" style="text-align: center;">
				<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
				<p class="color-b">{lang forum_nothreads}</p>
			</li>
	        
	        <!--{/if}-->
	      </ul>
    </div>
	$multipage
</div>
<!--{/if}-->
<!--{hook/forumdisplay_bottom_mobile}-->
<script type="text/javascript">
	$('.forum-fav').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=forum-fav&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>

<!--{if !$subforumonly}-->
<!--{if $_G[uid] || $_G['group']['allowpost']}-->
<a href="forum.php?mod=post&action=newthread&fid=$_G['fid']" class="bz-post-fd"><i class="iconfont icon-post"></i></a>
<!--{else}-->
<a href="javascript:popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');" class="bz-post-fd"><i class="iconfont icon-post"></i></a>
<!--{/if}-->
<!--{/if}-->
<!--{eval}-->
if($_G['uid']){$favfids = C::t('home_favorite')->fetch_all_by_uid_idtype($_G['uid'], 'fid');foreach($favfids as $val){if($val['id'] == $_G[fid]){$isFav = $val['favid'];}}}
<!--{/eval}-->
<!--{if $isFav}-->
<a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}&formhash={FORMHASH}" class="bz-fav-fd forum-fav"><i class="iconfont icon-collection_fill"></i></a>
<!--{else}-->
<a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}&formhash={FORMHASH}" class="bz-fav-fd forum-fav"><i class="iconfont icon-collection"></i></a>
<!--{/if}-->
<a href="forum.php" class="bz-return-fd"><i class="iconfont icon-fanhui1"></i></a>
<script type="text/javascript">
	$('.forum-fav').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=forum-fav&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>

<div class="banzhuan-bottom"></div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
