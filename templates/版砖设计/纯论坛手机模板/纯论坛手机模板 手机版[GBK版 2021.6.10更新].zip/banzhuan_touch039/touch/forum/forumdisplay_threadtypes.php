<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if !$_G[setting][mobile][mobilesimpletype]}-->
<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || $_G['forum']['threadsorts']}-->
<div class="bz-sub-nav bz-plrb10">
	<a style="background: #F4F4F4;">{lang modmenu_type}&nbsp;&nbsp;:</a>
	<!--{if $_G['forum']['threadtypes']}-->
	<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['typeid'] && !$_GET['sortid']}class="a"{/if}>{lang forum_viewall}</a>
	<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
   	<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]" {if $_GET['filter'] == 'typeid' && $_GET['typeid'] == $id}class="a"{/if}>$name</a>
		<!--{/loop}-->
		<!--{/if}-->
		<!--{if $_G['forum']['threadtypes'] && $_G['forum']['threadsorts']}-->
		<a style="background: #F4F4F4; box-shadow: 0 0 0 rgba(0,0,0,0.1); padding: 0; color: rgba(0,0,0,0.1);"> | </a>
		<!--{/if}-->
		<!--{if $_G['forum']['threadsorts']}-->
	<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
    <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]" <!--{if $_GET[sortid] == $id}-->class="a"<!--{/if}-->>$name</a>
    <!--{/loop}-->
    <!--{/if}-->
</div>
<div class="banzhuan-clear"></div>
<!--{/if}-->
<!--{/if}-->
