<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $thread['freemessage']}-->
	<div id="postmessage_$pid" class="t_f">$thread[freemessage]</div>
<!--{/if}-->
<!--{if empty($_GET['archiver'])}-->
	<div class="cl locked bg b_p15 mtw mbw">
		<div class="b_p15">
		<p class="hm mtw"><!--{if $_G[forum_thread][price] > 0}-->{lang pay_comment}<!--{/if}--><!--{if $thread[endtime]}-->{lang pay_free_time}<!--{/if}--></p>
		<div class="mtw mbw btn-big">
			<a href="forum.php?mod=misc&action=pay&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET['from'])}&from=$_GET['from']{/if}" class="dialog touch" title="{lang pay}" style="color: #FFF;">{lang pay}</a>
		</div>
		<!--{if $thread[payers]}--><p class="hm mbw grey fz12">{lang have} $thread[payers] {lang people_buy}</p><!--{/if}-->
		</div>
	</div>
<!--{else}-->
	<!--{if $thread[payers]}-->{lang have} $thread[payers] {lang people_buy}&nbsp; <!--{/if}-->
	<!--{if $_G[forum_thread][price] > 0}-->{lang pay_comment}<!--{/if}-->
	<!--{if $thread[endtime]}--><br />{lang pay_free_time}<!--{/if}-->
<!--{/if}-->
