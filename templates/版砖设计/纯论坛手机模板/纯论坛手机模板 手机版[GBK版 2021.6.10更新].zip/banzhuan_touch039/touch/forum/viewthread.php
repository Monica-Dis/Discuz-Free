<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{hook/viewthread_top_mobile}-->
<div class="postlist">
	<div class="bz-bg-fff">
		<h2>$_G[forum_thread][subject]
	        <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
	        <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
	        <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
	        <!--{/if}-->
		</h2>
		<div class="bzvt-type">
	        <em class="z color-c"><i class="iconfont icon-attention fz12"></i> $_G[forum_thread][views]&nbsp;&nbsp;&nbsp;</em>
	        <em class="z color-c"><i class="iconfont icon-message fz12"></i> $_G[forum_thread][allreplies]</em>
	        <em class="y"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="blue">{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}</a></em>
	        <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
	        <em class="y">[{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]&nbsp;&nbsp;</em>
		    <!--{/if}-->
	        <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}--><em class="y"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$_G[forum_thread][typeid]" class="blue">#{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}&nbsp;&nbsp;</a></em><!--{/if}-->
	    </div>	
		<div class="banzhuan-clear"></div>
	</div>
	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
	<!--{hook/viewthread_posttop_mobile $postcount}-->
	<!--{if $post[first]}-->
		<!--{subtemplate forum/viewthread_first}-->
	<!--{else}-->
		<!--{subtemplate forum/viewthread_reply}-->
	<!--{/if}-->
   	<!--{hook/viewthread_postbottom_mobile $postcount}-->
   	<!--{eval $postcount++;}-->
   	<!--{/loop}-->
</div>
$multipage
<div class="bzvf">
	<div class="bzvfs">
		<ul>
			<li>
				<a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" class="recbtn iconfont icon-zan2"><span></span><em id="recommendv_add"{if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>{$_G['forum_thread']['recommend_add']}</em></a>
			</li>
			<li>
				<!--{if $_G[uid] || $allowpostreply}-->
				<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" class="iconfont icon-message"><span></span><em {if !$_G[forum_thread][allreplies]} style="display:none"{/if}>$_G[forum_thread][allreplies]</em></a>
				<!--{else}-->
				<a href="javascript:popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');" class="iconfont icon-message"><span></span><em {if !$_G[forum_thread][allreplies]} style="display:none"{/if}>$_G[forum_thread][allreplies]</em></a>
				<!--{/if}-->
			</li>
			<li>
				<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn iconfont icon-shoucang5"><span></span><em id="favoritenumber"{if !$_G['forum_thread']['favtimes']} style="display:none"{/if}>{$_G['forum_thread']['favtimes']}</em></a>
			</li>
		</ul>
	</div>
</div>
<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

	$('.recbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=recbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
	
	$('.replyadd').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=replyadd&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});	
</script>

<!--{hook/viewthread_bottom_mobile}-->
<a href="<!--{if $_GET[fromguid] == 'hot'}-->forum.php?mod=guide&view=hot&page=$_GET[page]<!--{else}-->forum.php?mod=forumdisplay&fid=$_G[fid]&<!--{eval echo rawurldecode($_GET[extra]);}--><!--{/if}-->" class="bz-return-vt"><i class="iconfont icon-fanhui1"></i></a>
<a href="forum.php" class="bz-home-vt"><i class="iconfont icon-home"></i></a>
<div class="banzhuan-bottom"></div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->


