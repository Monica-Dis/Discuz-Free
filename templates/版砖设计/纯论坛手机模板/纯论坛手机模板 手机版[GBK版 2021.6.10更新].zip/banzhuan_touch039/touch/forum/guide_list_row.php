<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $list['threadcount']}-->
	<!--{loop $list['threadlist'] $key $thread}-->
		<tbody id="$thread[id]">
			<tr>
				<th class="$thread[folder]">
					<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
					<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					$thread[typehtml] $thread[sorthtml]
					<!--{if $thread['moved']}-->
					{lang thread_moved}:
					<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="xst">
						<!--{if $thread['attachment'] == 2}-->
						<div class="common-pic">
							   <!--{eval $threada= C::t('forum_attachment')->fetch_all_by_id('tid', $thread['tid'], 'aid');}-->
							   <!--{eval $threadaid = reset($threada);}-->
							   <!--{eval $threadpic = C::t('forum_attachment_n')->fetch_by_aid_uid($threadaid['tableid'], $threadaid['aid'], $thread['authorid']);}-->
							   <!--{eval $thread['pic'] = $threadpic['attachment'];}-->
				               <img src ="data/attachment/forum/$thread['pic']"/>
						</div>
						<!--{else}-->
						<div class="common-pic">
				               <img src="./template/banzhuan_touch039/touch/banzhuan/images/nopic1.png">
						</div>
						<!--{/if}-->
						$thread[subject]
					</a>
					<p class="color-c" style="line-height: 24px;">
						<!--{if $thread[folder] == 'lock'}-->
						<span class="iconfont icon-suo1 color-red"></span>
						<!--{elseif $thread['special'] == 1}-->
						<span class="iconfont icon-c_icon1 color-red"></span>
						<!--{elseif $thread['special'] == 2}-->
						<span class="iconfont icon-gouwu color-red"></span>
						<!--{elseif $thread['special'] == 3}-->
						<span class="iconfont icon-jianglishuoming color-red"></span>
						<!--{elseif $thread['special'] == 4}-->
						<span class="iconfont icon-huodong color-red"></span>
						<!--{elseif $thread['special'] == 5}-->
						<span class="iconfont icon-chajiepifb794b color-red"></span>
						<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
						<span class="iconfont icon-top01 color-red"></span>
						<!--{else}-->
						<!--{/if}-->
		
						<!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
						<span class="iconfont icon-jing color-red"></span>
						<!--{/if}-->
						<!--{if $thread['displayorder'] == 0}-->
						<!--{if $thread[recommendicon] && $filter != 'recommend'}-->
						<!--{/if}-->
		
						<!--{if $thread[heatlevel]}-->
						<span class="iconfont icon-hotfill color-red"></span>
						<!--{/if}-->
		
						<!--{if $thread['rate'] > 0}-->
						<!--{elseif $thread['rate'] < 0}-->
						<!--{/if}-->
						<!--{/if}-->
		
						<!--{if $thread['replycredit'] > 0}-->
						<!--{/if}-->
						<!--{if $thread[multipage]}-->
						<!--{/if}-->
		
						<!--{if $_G['setting']['threadhidethreshold'] && $thread['hidden'] >= $_G['setting']['threadhidethreshold']}-->
						<!--{/if}-->
		
						<!--{if $thread[icon] >= 0}-->
						<!--{/if}-->
		
						<!--{if $thread['rushreply']}-->
						<!--{/if}-->
		
						<!--{if $stemplate && $sortid}-->
						<!--{/if}-->
						<!--{if $thread['readperm']}-->
						<!--{/if}-->
						
						<!--{if $thread['price'] > 0}-->
						<!--{if $thread['special'] == '3'}-->
						<!--{else}-->
						<!--{/if}-->
						<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
						<!--{/if}-->
						
						<span style="font-size: 12px;">
							<!--{if $thread['authorid'] && $thread['author']}-->
							$thread[author]&nbsp;&nbsp;<!--{if !empty($verify[$thread['authorid']])}-->$verify[$thread[authorid]]&nbsp;&nbsp;<!--{/if}-->
							<!--{else}-->
							$_G[setting][anonymoustext]&nbsp;&nbsp;
							<!--{/if}-->
						</span>
						<span class="iconfont icon-attention color-b" style="font-size: 12px;"><em class="color-c">&nbsp;$thread[views]&nbsp;&nbsp;</em></span>
						<span class="iconfont icon-comment color-b" style="font-size: 12px;"><em class="color-c">&nbsp;$thread[replies]</em></span>
		
						<!--{if $view == 'hot'}-->
						<span class="color-b y" style="margin-left: 10px;font-size: 12px;">$thread['heats']{lang guide_attend}</span>
						<!--{/if}-->
						<!--{if $thread['attachment'] == 2}-->
						<!--{/if}-->	
						
					</p>
					
					<!--{if $thread['weeknew']}-->
					<a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost" class="xi1">New</a>
					<!--{/if}-->
		
					<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
					<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
					<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<!--{/if}-->
		
				</th>
			</tr>
		</tbody>
		<!--{if $view == 'my' && $viewtype=='reply' && !empty($tids[$thread[tid]])}-->
		<tbody class="bw0_all">
			<tr>
				<td class="icn">&nbsp;</td>
				<td colspan="5">
					<!--{loop $tids[$thread[tid]] $pid}-->
					<!--{eval $post = $posts[$pid];}-->
					<div class="tl_reply pbm xg1">
						<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid">
							<!--{if $post[message]}-->{$post[message]}
							<!--{else}-->...
							<!--{/if}-->
						</a>
					</div>
					<!--{/loop}-->
				</td>
			</tr>
		</tbody>
		<tr>
			<td colspan="6"></td>
		</tr>
		<!--{/if}-->
		<!--{if $view == 'my' && $viewtype=='postcomment'}-->
		<tr>
			<td class="icn">&nbsp;</td>
			<td colspan="5" class="xg1">$thread[comment]</td>
		</tr>
		<!--{/if}-->
	<!--{/loop}-->
<!--{else}-->
	<tbody class="bw0_all">
		<tr>
			<th colspan="5">
				<div class="guide-no">
					<p class="iconfont icon-quxiaoguanzhu color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang guide_nothreads}</p>
				</div>
			</th>
		</tr>
	</tbody>
<!--{/if}-->