<?php echo 'From: DisM.taobao.com';exit;?>
<div class="bz-h10"></div>
<!--{if $sublist > 0}-->
<div class="banzhuan-clear"></div>
<div class="bz-mb10">
	<div class="bz-sub-show bzbb1 cl">
    	<h2><a>$_G['forum'][name]</a></h2>
    </div>
	<div class="sub_forum">
		<ul>
			<!--{loop $sublist $sub}-->
			<li>
				<div class="gengduo"><a href="forum.php?mod=forumdisplay&fid={$sub[fid]}"><i class="iconfont icon-gengduo"></i></a></div>
				<div class="name-pic">
                    <!--{if $sub[icon]}-->
                    {$sub[icon]}
                    <!--{else}-->
                    <a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
						<img src="template/banzhuan_touch039/touch/banzhuan/images/forum.jpg" align="left" />
                    </a>
                    <!--{/if}-->
			    </div>
                	<div class="name-tit">
                		<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
                			<span>{$sub['name']}</span>
                			<!--{if $sub[todayposts] > 0}-->
                	        	<p>{lang forum_threads} <!--{echo dnumber($sub[threads])}--> / {lang posts} <!--{echo dnumber($sub[posts])}--> / <em style="color: #F74C31;">{lang index_today}: $sub[todayposts]</em></p>
                	        <!--{else}-->
                	        	<p>{lang forum_threads} <!--{echo dnumber($sub[threads])}--> / {lang posts} <!--{echo dnumber($sub[posts])}--></p>
                	        	<!--{/if}-->
                	    </a>
                	</div>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
</div>
<div class="banzhuan-clear"></div>
<!--{else}-->
<div class="bz-mb10">
	<div class="bz-sub-show bzbb1 cl">
    	<h2><a>$_G['forum'][name]</a></h2>
    </div>
	<div class="cl">
	      <ul id="threadlist">
	        <li class="bz-p10 bz-bg-fff bzbb1" style="text-align: center;">
				<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
				<p class="color-b">{lang none}{lang forum_subforums}</p>
			</li>
		</ul>
	</div>
</div>
<!--{/if}-->



