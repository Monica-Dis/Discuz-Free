<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->

<!--{if !$_GET['mycenter']}-->

	<div class="userinfo bg">
					
		<!--{template home/space_profile_top}-->

		<!--{if $space['medals']}-->
		<div style="border-top: 1px solid #EFEFEF; border-bottom: 1px solid #EFEFEF;">
			<div class="bz-p10 bz-bg-fff bzbb1" style="font-size: 16px;"><h3>{lang medals}</h3></div>
			<p class="bz-p10 bz-bg-fff">
				<a>
				<!--{loop $space['medals'] $medal}-->
				<img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" id="md_{$medal[medalid]}" />
				<!--{/loop}-->
				</a>
			</p>
		</div>
		<div class="banzhuan-h10"></div>
		<!--{/if}-->

	    		<div class="bz_per_info bz-bg-fff bzbt1 bzbb1">
				<ul>
					<li><em>UID</em><span class="grey">$space[uid]</span></li>
				    <!--{if $space[customstatus]}-->
					<li><em>{lang permission_basic_status}</em><span class="grey">$space[customstatus]</span></li>
					<!--{/if}-->
					<!--{if $space[group][maxsigsize] && $space[sightml]}-->
					<li><em>{lang personal_signature}</em><span class="grey">$space[sightml]</span></li>
					<!--{/if}-->	
				<!--{loop $_G[setting][extcredits] $key $value}-->
					<!--{if $value[title]}-->
					<li><em>$value[title]</em><span class="grey">{$space["extcredits$key"]} $value[unit]</span></li>
					<!--{/if}-->
				<!--{/loop}-->
				    <li><em>{lang credits}</em><span class="grey">$space[credits]</span></li>
					<!--{if $space[adminid]}-->
					<li><em>{lang management_team}</em><span class="grey">{$space[admingroup][grouptitle]}</span></li>
					<!--{/if}-->
					<li><em>{lang usergroup}</em><span class="grey">{$space[group][grouptitle]}</span></li>
					<!--{if $space[extgroupids]}-->
					<li><em>{lang group_expiry_type_ext}</em><span class="grey">$space[extgroupids]</span></li>
					<!--{/if}-->
					<li><em>{lang regdate}</em><span class="grey">$space[regdate]</span></li>
					<!--{if $space[lastsendmail]}-->
					<li><em>{lang last_send_email}</em><span class="grey">$space[lastsendmail]</span></li>
					<!--{/if}-->
					<!--{if in_array($_G[adminid], array(1, 2))}-->
					<li><em>Email</em><span class="grey">$space[email]</span></li>
					<!--{/if}-->
					<!--{if $space[customstatus]}-->
					<li><em>{lang permission_basic_status}</em><span class="grey">$space[customstatus]</span></li>
					<!--{/if}-->
					<!--{if $_G['setting']['allowviewuserthread'] !== false}-->
					<!--{eval $space['posts'] = $space['posts'] - $space['threads'];}-->
					<li><em>{lang threads_num}</em><span class="grey"><a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=thread&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread{/if}" class="blue">$space[threads]</a></span></li>
					<li><em>{lang replay_num}</em><span class="grey"><a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=reply&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread&type=reply{/if}" class="blue">$space[posts]</a></span></li>
					<!--{/if}-->
					<!--{if $profiles}-->
					<!--{loop $profiles $value}-->
					<li><em>$value[title]</em><span class="grey">$value[value]</span></li>
					<!--{/loop}-->
					<!--{/if}-->
				</ul>
			</div>
			
			<!--{if $count}-->
			<div class="banzhuan-h10"></div>
			<div style="border-top: 1px solid #EFEFEF; border-bottom: 1px solid #EFEFEF;">
				<div class="bz-p10 bz-bg-fff bzbb1" style="font-size: 16px;"><h3>{lang manage_forums}</h3></div>
				<ul class="bzscount bz-p10 bz-bg-fff">
					<!--{loop $manage_forum $key $value}-->
					<li><a href="forum.php?mod=forumdisplay&fid=$key">$value</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
		</div>
		
	</div>

	<!--{if $space[self]}-->
	<!--{else}-->
		<div class="banzhuan-bottom"></div>
		<div id="nmfootbar">
		    <div class="fbc">
		        <ul>
		            <li><a href="home.php?mod=space&do=pm&subop=view&touid=$space[uid]&mobile=2" class="iconfont icon-message"><span>&nbsp;{lang send_pm}</span></a></li>
		        </ul>
		    </div>
		</div>
	<!--{/if}-->

	<!--{eval $nofooter = true;}-->
	<!--{template common/footer}-->

<!--{else}-->

	<div class="userinfo">
		<a href="home.php?mod=space&uid={$_G[uid]}&do=profile">
			<div class="user_avatar_my bzbb1">
				<div class="avatar_m z"><img src="<!--{avatar($_G[uid], big, true)}-->" /></div>
				<div class="avatar_n z">
					<h2 class="name">$_G[username]</h2>
				    <p>Lv.{$_G['cache']['usergroups'][$space[groupid]][stars]}&nbsp;&nbsp;{$_G['cache']['usergroups'][$space[groupid]][grouptitle]}&nbsp;&nbsp;<!--{if getuserprofile('gender') == 0}--><!--{elseif getuserprofile('gender') == 1}--><i class="iconfont icon-nan rnan fz12"></i><!--{elseif getuserprofile('gender') == 2}--><i class="iconfont icon-nv rnv fz12"></i><!--{/if}--></p>
				</div>
				<div class="avatar_y y"><span class="y iconfont icon-gengduo"></span></div>
			</div>
		</a>
		<div class="myinfo_list cl banzhuan-clear mtm">
			<ul>
				<!--<li class="bzbt1 bzbb1 mbm"><a href="#" class="iconfont icon-set1">&nbsp;&nbsp;{lang memcp_avatar}<span class="y iconfont icon-gengduo"></span></a></li>-->
				<li class="bzbt1"><a href="home.php?mod=space&do=pm" class="iconfont icon-youjian2 bzbb1">&nbsp;&nbsp;{lang mypm}<span class="y iconfont icon-gengduo"></span><!--{if $_G[member][newpm]}--><em class="y iconfont icon-dian1"></em><!--{/if}--></a></li>
				<li><a href="home.php?mod=space&do=notice&mobile=2" class="iconfont icon-tixing1 bzbb1">&nbsp;&nbsp;{lang mail_system_insys}<span class="y iconfont icon-gengduo"></span><!--{if $_G[member][newprompt]}--><em class="y iconfont icon-dian1"></em><!--{/if}--></a></li>
				<li><a href="home.php?mod=spacecp&ac=credit" class="iconfont icon-qianbao bzbb1">&nbsp;&nbsp;{lang my_credits}<span class="y iconfont icon-gengduo"></span><em class="y fz12 grey">$space[credits]&nbsp;{lang credits}&nbsp;&nbsp;</em></a></li>
				<li><a href="home.php?mod=space&do=favorite&type=all&mobile=2" class="iconfont icon-shoucang5 bzbb1">&nbsp;&nbsp;{lang myfavorite}<span class="y iconfont icon-gengduo"></span></a></li>
				<li class="bzbb1"><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=thread" class="iconfont icon-ziliao21">&nbsp;&nbsp;{lang myitem}{lang post}<span class="y iconfont icon-gengduo"></span></a></li>
				<li class="bzbt1" style="margin-top: 10px;"><a href="forum.php?mod=announcement" class="iconfont icon-cloud-remind bzbb1">&nbsp;&nbsp;&#20844;&#21578;<span class="y iconfont icon-gengduo"></span></a></li>
				<li class="bzbb1"><a href="misc.php?mod=faq" class="iconfont icon-help">&nbsp;&nbsp;{lang faq}<span class="y iconfont icon-gengduo"></span></a></li>
			</ul>
		</div>
	</div>
	<div class="btn_exit bzbt1 bzbb1"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout_mobile}</a></div>
	<!--{template common/footer}-->

<!--{/if}-->


