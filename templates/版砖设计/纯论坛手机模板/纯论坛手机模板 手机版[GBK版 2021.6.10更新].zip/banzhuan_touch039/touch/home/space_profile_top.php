<?php echo 'From: DisM.taobao.com';exit;?>
<div class="user_avatar_bg" style="background-image: url(<!--{avatar($space[uid], big, true)}-->);background-size: cover;">
	<div class="user_avatar_h">
		<div class="user_avatar_h_l"><a href="javascript:history.back();" class="iconfont icon-fanhui"></a></div>
		<h2></h2>
		<div class="user_avatar_h_r"><a href="forum.php" class="iconfont icon-home"></a></div>
	</div>
	<div class="user_avatar hm">
		<div class="avatar_m"><img src="<!--{avatar($space[uid], big, true)}-->" /></div>
		<div class="avatar_n mtm">
			<p class="fz16 name">$space[username]</p>
			<p class="fz14">Lv.{$_G['cache']['usergroups'][$space[groupid]][stars]}&nbsp;&nbsp;{$_G['cache']['usergroups'][$space[groupid]][grouptitle]}<!--{if $space['uid'] == $_G['uid']}--><!--{if getuserprofile('gender') == 0}--><!--{elseif getuserprofile('gender') == 1}-->&nbsp;&nbsp;<i class="iconfont icon-nan rnan fz12"></i><!--{elseif getuserprofile('gender') == 2}-->&nbsp;&nbsp;<i class="iconfont icon-nv rnv fz12"></i><!--{/if}--><!--{/if}--></p>
		</div>
	</div>
</div>
<div class="user_avatar_cover"></div>
<!--{if $space[self]}-->
<div class="bz-sp-memu bz-bg-fff bzbb1">
	<ul class="flex_box">
		<li class="flex {if $do==profile}a{/if}">
			<!--{if $_GET['mod'] == 'space' && $_GET['do'] == 'profile'}--><em class="bg_039"></em><!--{/if}-->
			<a href="home.php?mod=space&uid={$space[uid]}&do=profile" <!--{if $_GET['mod'] == 'space' && $_GET['do'] == 'profile'}-->class="rtt"<!--{/if}-->>{lang myprofile}</a>
		</li>
		<li class="flex {if $do=='thread'}a{/if}">
			<!--{if $_GET['mod'] == 'space' && $_GET['do'] == 'thread'}--><em class="bg_039"></em><!--{/if}-->
			<a href="home.php?mod=space&uid={$space[uid]}&do=thread&view=me&from=space" <!--{if $_GET['mod'] == 'space' && $_GET['do'] == 'thread'}-->class="rtt"<!--{/if}-->>{lang myitem}{lang post}</a>
		</li>
	</ul>
</div>
<!--{else}-->
<div class="bz-sp-memu bz-bg-fff bzbb1">
	<ul class="flex_box">
		<li class="flex {if $do==profile}a{/if}">
			<!--{if $_GET['mod'] == 'space' && $_GET['do'] == 'profile'}--><em class="bg_039"></em><!--{/if}-->
			<a href="home.php?mod=space&uid={$space[uid]}&do=profile" <!--{if $_GET['mod'] == 'space' && $_GET['do'] == 'profile'}-->class="rtt"<!--{/if}-->>Ta{lang otherprofile}</a>
		</li>
		<li class="flex {if $do=='thread'}a{/if}">
			<!--{if $_GET['mod'] == 'space' && $_GET['do'] == 'thread'}--><em class="bg_039"></em><!--{/if}-->
			<a href="home.php?mod=space&uid={$space[uid]}&do=thread&view=me&from=space" <!--{if $_GET['mod'] == 'space' && $_GET['do'] == 'thread'}-->class="rtt"<!--{/if}-->>Ta{lang post}</a>
		</li>
	</ul>
</div>
<!--{/if}-->
