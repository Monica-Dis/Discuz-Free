<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="loginbox registerbox">
	<div class="login_from">
	<form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}&mobile=2">
		<input type="hidden" name="regsubmit" value="yes" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
		<input type="hidden" name="referer" value="$dreferer" />
		<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
		<input type="hidden" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
		<!--{if $_G['setting']['sendregisterurl']}-->
		<input type="hidden" name="hash" value="$_GET[hash]" />
		<!--{/if}-->
		<ul>
			<!--{if $sendurl}-->
			<li><input type="email" tabindex="1" class="px w100" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login"></li>
			<!--{else}-->
				<li><input type="text" tabindex="1" class="px w100" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip}" fwin="login"></li>
				<li><input type="password" tabindex="2" class="px w100" size="30" value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password}" fwin="login"></li>
				<li><input type="password" tabindex="3" class="px w100" size="30" value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2}" fwin="login"></li>
				<li><input type="email" tabindex="4" class="px w100" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login"></li>
				<!--{if empty($invite) && ($_G['setting']['regstatus'] == 2 || $_G['setting']['regstatus'] == 3)}-->
					<li><input type="text" name="invitecode" autocomplete="off" tabindex="5" class="px w100" size="30" placeholder="{lang invite_code}" fwin="login"></li>
				<!--{/if}-->
				<!--{if $_G['setting']['regverify'] == 2}-->
					<li><input type="text" name="regmessage" autocomplete="off" tabindex="6" class="px w100" size="30" placeholder="{lang register_message}" fwin="login"></li>
				<!--{/if}-->
				<!--{loop $_G['cache']['fields_register'] $field}-->
					<!--{if $htmls[$field['fieldid']]}-->
					<li class="diy"><span>$field[title]<!--{if $field['required']}--> *<!--{/if}--></span>$htmls[$field['fieldid']]</li>
					<!--{/if}-->
				<!--{/loop}-->
			<!--{/if}-->
		</ul>
		<!--{if $secqaacheck || $seccodecheck}-->
			<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
	</div>
	<div class="btn_register">
		<button tabindex="7" value="true" name="regsubmit" type="submit" class="formdialog pn pnc"><span>{lang quickregister}</span></button>
		<div class="bz-ptb10 hm">
	    	    <a class="color-c" href="member.php?mod=logging&action=login&mobile=2">{lang login}</a>
	    </div>
	</div>
	</form>
</div>
<a href="javascript:;" onclick="history.go(-1)" class="bz-return-login"><i class="iconfont icon-fanhui1"></i></a>
<a href="forum.php" class="bz-home-login"><i class="iconfont icon-home"></i></a>
<!--{eval updatesession();}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

