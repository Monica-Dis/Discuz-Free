<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="b_p15 cl bz-bg-fff" style="height: 100%;">
	<div class="cl mtw">
		<div class="hm">
			<em class="iconfont icon-suo rtt fz90"></em>
		</div>
		<div class="bz-fd-passwd cl">
			<div class="cl">
				<div class="hm mtw">
					<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=pwverify">
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="password" name="pw" class="bz_passwd_px" placeholder="{lang m_login_pw_ph}" />
						<div class="btn-big mtw">
							<button class="touch" type="submit" name="loginsubmit" value="true">{lang submit}</button>
						</div>
						<div class="btn-big-bor mtm">
							<button class="touch" type="button" onclick="history.go(-1)">{lang cancel}</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}&formhash={FORMHASH}" class="bz-fav-fd forum-fav"><i class="iconfont icon-collection"></i></a>
<a href="forum.php" class="bz-return-fd"><i class="iconfont icon-fanhui1"></i></a>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

	

