<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="b_p15 cl bz-bg-fff" style="height: 100%;">
	<div class="cl mtw">
		<div class="hm"><em class="iconfont icon-jianglishuoming rtt fz90"></em></div>
		<div class="bz-fd-jinbi cl">
			<div class="cl">
				<div class="mbm"><strong class="rq fz50">$paycredits</strong> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit']}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title']}</div>
				<div class="mtw">
					<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=paysubmit">
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<div class="btn-big">
							<button class="touch" type="submit" name="loginsubmit" value="true">{lang confirmyourpay}</button>
						</div>
						<div class="btn-big-bor mtm">
							<button class="touch" type="button" onclick="history.go(-1)">{lang cancel}</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</div>
<a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}&formhash={FORMHASH}" class="bz-fav-fd forum-fav"><i class="iconfont icon-collection"></i></a>
<a href="forum.php" class="bz-return-fd"><i class="iconfont icon-fanhui1"></i></a>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

	

