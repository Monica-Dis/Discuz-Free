<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="bz-header">
	<div class="bz-header-left"><a href="javascript:history.back();" class="iconfont icon-fanhui"></a></div>
	<h2>{lang announcement}</h2>
	<div class="bz-header-right"><a href="forum.php" class="iconfont icon-home"></a></div>
</div>
<div class="cl">
	<div class="bz-anno-appl bzbb1">
		<ul>
			<li class="{if empty($_GET[m])} a{/if}"><a href="forum.php?mod=announcement">{lang all}</a></li>
		    <!--{loop $months $month}-->
			<li class="{if $_GET[m] == $month[0].$month[1]} a{/if}"><a href="forum.php?mod=announcement&m=$month[0].$month[1]">$month[0] {lang year} $month[1] {lang month}</a></li>
		    <!--{/loop}-->
		</ul>
	</div>
	<div class="banzhuan-clear"></div>
	<div id="annofilter"></div>
	<!--{loop $announcelist $ann}-->
	<div class="bz-anno-li bz-bg-fff bzbb1">
		<h1 id="announce$ann[id]_c" class="bz-anno-li-title">$ann[subject]</h1>
		<p style="padding-bottom: 15px;"><em class="grey">{lang author} : $ann[author]</em><em class="y grey">$ann[starttime]</em></p>
		<div id="announce$ann[id]" class="bz-anno-li-detail">
			$ann[message]
		</div>
	</div>
	<!--{/loop}-->
</div>

<div class="banzhuan-bottom"></div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->


