<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $_G[forum_thread][special] = 0;}-->

<!-- main postlist start -->

	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
	<div class="plc cl">
		<div class="pi">
			<div class="cl" style="position: relative;">
				<span class="avatar"><img src="<!--{avatar($post[authorid], middle, true)}-->" style="width:32px;height:32px;" /></span>
				<ul class="authi">
					
					
					
					<li>
						<div class="bz-small">
						    <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
							<a href="home.php?mod=space&uid=$post[authorid]&do=profile&mobile=2">
								$post[author]
		                        <!--{if $post[gender] == 1}-->
		                  	    <i class="iconfont icon-shouyezhuyetubiao06 color-nan"></i>
		                        <!--{/if}-->
		                        	<!--{if $post[gender] == 2}-->
		                  	    <i class="iconfont icon-iconfontshouyezhuyetubiao07 color-nv"></i>
		                        <!--{/if}-->
		                        <em>$post[authortitle]</em>
	                        </a>
							<!--{else}-->
								<!--{if !$post['authorid']}-->
								<a href="javascript:;">{lang guest}<em> $post[useip]{if $post[port]}:$post[port]{/if}</em></a>
								<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
									<!--{if $_G['forum']['ismoderator']}--><a>{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
								<!--{else}-->
								$post[author] <em>{lang member_deleted}</em>
								<!--{/if}-->
							<!--{/if}-->
							
							<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
							<a class="replyadd color-b y" href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" onmouseover="this.title = ($('review_support_$post[pid]').innerHTML ? $('review_support_$post[pid]').innerHTML : 0) + ' {lang activity_member_unit} {lang support_reply}'"><span id="review_support_$post[pid]">$post[postreview][support]</span><span class="iconfont icon-appreciatelight"></span></a>&nbsp;&nbsp;
							<!--{/if}-->
							
						</div>
					</li>
					
					
					
					<li class="color-c rela" style="font-size: 12px;">
						<em class="z">
							<!--{if isset($post[isstick])}-->
								<img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> {lang from} {$post[number]}{$postnostick}
							<!--{elseif $post[number] == -1}-->
								{lang recommend_post}
							<!--{else}-->
								<!--{if !empty($postno[$post[number]])}-->
								    $postno[$post[number]]
								<!--{else}-->
								    {$post[number]}&#27004;
								<!--{/if}-->
							<!--{/if}-->
						</em>
						&nbsp;$post[dateline]&nbsp;&nbsp;
					</li>
				</ul>
				<div class="message">
				    	<!--{if $post['warned']}-->
				            <span class="color-c quote">{lang warn_get}</span>
				        <!--{/if}-->
				        <!--{if !$post['first'] && !empty($post[subject])}-->
				            <h2><strong>$post[subject]</strong></h2>
				        <!--{/if}-->
				        <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
				            <div class="color-c quote">{lang message_banned}</div>
				        <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
				            <div class="color-c quote">{lang message_single_banned}</div>
				        <!--{elseif $needhiddenreply}-->
				            <div class="color-c quote">{lang message_ishidden_hiddenreplies}</div>
				        <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
							<!--{template forum/viewthread_pay}-->
						<!--{else}-->
				
				        	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
				                <div class="color-c quote">{lang admin_message_banned}</div>
				            <!--{elseif $post['status'] & 1}-->
				                <div class="color-c quote">{lang admin_message_single_banned}</div>
				            <!--{/if}-->
				            <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
				                {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
				            <!--{/if}-->
				
				            <!--{if $post['first'] && $threadsort && $threadsortshow}-->
				            	<!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
				                    <!--{if $threadsortshow['optionlist'] == 'expire'}-->
				                        {lang has_expired}
				                    <!--{else}-->
				                        <div class="box_ex2 viewsort">
				                            <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
				                        <!--{loop $threadsortshow['optionlist'] $option}-->
				                            <!--{if $option['type'] != 'info'}-->
				                                $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="xg1">--</span><!--{/if}--><br />
				                            <!--{/if}-->
				                        <!--{/loop}-->
				                        </div>
				                    <!--{/if}-->
				                <!--{/if}-->
				            <!--{/if}-->
				            <!--{if $post['first']}-->
				                <!--{if !$_G[forum_thread][special]}-->
				                    $post[message]
				                <!--{elseif $_G[forum_thread][special] == 1}-->
				                    <!--{template forum/viewthread_poll}-->
				                <!--{elseif $_G[forum_thread][special] == 2}-->
				                    <!--{template forum/viewthread_trade}-->
				                <!--{elseif $_G[forum_thread][special] == 3}-->
				                    <!--{template forum/viewthread_reward}-->
				                <!--{elseif $_G[forum_thread][special] == 4}-->
				                    <!--{template forum/viewthread_activity}-->
				                <!--{elseif $_G[forum_thread][special] == 5}-->
				                    <!--{template forum/viewthread_debate}-->
				                <!--{elseif $threadplughtml}-->
				                    $threadplughtml
				                    $post[message]
				                <!--{else}-->
				                	$post[message]
				                <!--{/if}-->
				            <!--{else}-->
				                $post[message]
				            <!--{/if}-->
				            
						<!--{/if}-->
				</div>
			</div>
				
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
			<!--{if $post['attachment']}-->
			   <div class="color-c quote">
			   {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
			   </div>
			<!--{elseif $post['imagelist'] || $post['attachlist']}-->
			   <!--{if $post['imagelist']}-->
				<!--{if count($post['imagelist']) == 1}-->
				<ul class="img_one">{echo showattach($post, 1)}</ul>
				<!--{else}-->
				<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
				<!--{/if}-->
				<!--{/if}-->
			    <!--{if $post['attachlist']}-->
				<ul>{echo showattach($post)}</ul>
				<!--{/if}-->
			<!--{/if}-->
			<!--{/if}-->
       </div>
	</div>
	
<!-- main postlist end -->

