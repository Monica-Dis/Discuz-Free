<?php echo 'From: DisM.taobao.com';exit;?>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<!--{if !$nofooter}-->
<div class="footer banzhuan-clear">
	<p><a href="{$_G['setting']['mobile']['nomobileurl']}" style="color: #D7D7D7;">{lang nomobiletype}</a></p>
	<p><!--{if $_G['setting']['icp'] || $_G['setting']['mps']}--><!--{if $_G['setting']['icp']}--><a href="http://www.beian.miit.gov.cn/" style="color: #D7D7D7;" target="_blank">$_G['setting']['icp']</a><!--{/if}--><!--{if $_G['setting']['mps']}--><!--{if $_G['setting']['icp']}--> | <!--{/if}--><a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=$_G['setting']['mpsid']" style="color: #D7D7D7;" target="_blank"><img width="10" height="10" src="{IMGDIR}/ico_mps.png" />$_G['setting']['mps']</a><!--{/if}--><!--{/if}--></p>
</div>
<div class="banzhuan-bottom"></div>
<div id="footbar">
<div class="fbc">
<ul>
<li {if $_GET['mod'] !== 'index' && $_GET['mod'] !== 'list' && $_GET['mod'] !== 'ranklist' && $_GET['mod'] !== 'space' && $_GET['mod'] !== 'faq' && $_GET['mod'] !== 'announcement' && $_GET['mod'] !== 'forum' && $_GET['mod'] !== 'spacecp' && $_GET['mod'] !== 'logging' && $_GET['mod'] !== 'register' && $_GET['mod'] !== 'post' && $_GET['action'] !== 'nav' && $_GET['order'] !== 'dateline' && $_GET['order'] !== 'replies' && $_GET['order'] !== 'views'}class="a"{/if}><a href="forum.php?forumlist=1&mobile=2" class="iconfont {if $_GET['mod'] !== 'index' && $_GET['mod'] !== 'list' && $_GET['mod'] !== 'ranklist' && $_GET['mod'] !== 'space' && $_GET['mod'] !== 'faq' && $_GET['mod'] !== 'announcement' && $_GET['mod'] !== 'forum' && $_GET['mod'] !== 'spacecp' && $_GET['mod'] !== 'logging' && $_GET['mod'] !== 'register' && $_GET['mod'] !== 'post' && $_GET['action'] !== 'nav' && $_GET['order'] !== 'dateline' && $_GET['order'] !== 'replies' && $_GET['order'] !== 'views'}icon-homefill{else}icon-home{/if}"><span>$_G['setting']['sitename']</span></a></li>
<li {if $_GET['do'] == 'profile' || $_GET['do'] == 'favorite' || $_GET['do'] == 'thread' || $_GET['do'] == 'friend' || $_GET['ac'] == 'search' || $_GET['ac'] == 'friend' ||$_GET['mod'] == 'faq'}class="a"{/if}><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}" class="iconfont {if $_GET['do'] == 'profile' || $_GET['do'] == 'favorite' || $_GET['do'] == 'thread' || $_GET['do'] == 'friend' || $_GET['ac'] == 'search' || $_GET['ac'] == 'friend' ||$_GET['mod'] == 'faq'}icon-peoplefill{else}icon-people{/if}"><span>{if $_G[uid]}{lang myitem}{else}{lang login}{/if}</span></a></li>
</ul>
</div>
</div>
<!--{/if}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->

