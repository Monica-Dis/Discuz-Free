<?php echo 'From: DisM.taobao.com';exit;?>
{eval
	$sechash = 'S'.random(4);
	$sectpl = !empty($sectpl) ? explode("<sec>", $sectpl) : array('<br />',': ','<br />','');	
	$ran = random(5, 1);
}
<!--{if $secqaacheck}-->
<!--{eval
	$message = '';
	$question = make_secqaa();
	$secqaa = lang('core', 'secqaa_tips').$question;
}-->
<!--{/if}-->
<!--{if $sectpl}-->
	<!--{if $secqaacheck}-->
		<div class="bzsecqaacheck">
			<div class="secqaa-bg">
	       		<div class="secqaa"><span class="iconfont icon-help2"></span>$secqaa</div>
	        </div>
		    <input name="secqaahash" type="hidden" value="$sechash" />
	        <div class="secqaa-input"><input name="secanswer" id="secqaaverify_$sechash" type="text" placeholder="&#31572;&#26696;" /></div>
        </div>
	<!--{/if}-->
	<!--{if $seccodecheck}-->
		<div class="sec_code vm">
			<input name="seccodehash" type="hidden" value="$sechash" />
			<input type="text" class="vm vm-input" autocomplete="off" value="" id="seccodeverify_$sechash" name="seccodeverify" placeholder="{lang seccode}" fwin="seccode">
	        <img src="misc.php?mod=seccode&update={$ran}&idhash={$sechash}&mobile=2" class="seccodeimg" />
		</div>
	<!--{/if}-->
<!--{/if}-->


<script type="text/javascript">
	(function() {
		$('.seccodeimg').on('click', function() {
			$('#seccodeverify_$sechash').attr('value', '');
			var tmprandom = 'S' + Math.floor(Math.random() * 1000);
			$('.sechash').attr('value', tmprandom);
			$(this).attr('src', 'misc.php?mod=seccode&update={$ran}&idhash='+ tmprandom +'&mobile=2');
		});
	})();
</script>

