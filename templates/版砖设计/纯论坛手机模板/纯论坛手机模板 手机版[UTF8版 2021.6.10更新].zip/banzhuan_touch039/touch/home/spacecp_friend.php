<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<div class="bz-header">
	<div class="bz-header-left">
		<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
	</div>
	<h2><!--{if $op == 'find'}-->{lang people_might_know}<!--{elseif $op == 'request'}-->{lang friend_request}<!--{elseif $op == 'group'}-->{lang set_friend_group}<!--{else}-->{lang friends}<!--{/if}--></h2>
	<div class="bz-header-right">
		<a href="search.php?mod=forum&mobile=2" class="iconfont icon-search4"></a>
	</div>
</div>
<div class="banzhuan-top"></div>

<!--{if !$_G[inajax]}-->

<div id="ct" class="ct2_a wp cl">
	<div class="mn">
		<div class="bz-mtb10">
			<div class="bz-fe-appl">
			    <div class="tbn">
					<ul>
						<li$actives[me]><a href="home.php?mod=space&do=friend">{lang friend_list}</a></li>
						<li$actives[search]><a href="home.php?mod=spacecp&ac=search">{lang search_friend}</a></li>
						<li$actives[find]><a href="home.php?mod=spacecp&ac=friend&op=find">{lang people_might_know}</a></li>
						<!--{if $_G['setting']['regstatus'] > 1}-->
							<!--<li$actives[invite]><a href="home.php?mod=spacecp&ac=invite">{lang invite_friend}</a></li>-->
						<!--{/if}-->
						<li$actives[request]><a href="home.php?mod=spacecp&ac=friend&op=request">{lang friend_request}</a></li>	
						<li$actives[group]><a href="home.php?mod=spacecp&ac=friend&op=group">{lang set_friend_group}</a></li>
					</ul>
				</div>
			</div>
			
<!--{/if}-->

		<!--{if $op =='ignore'}-->
		
			<div class="bz-p10 cl">
				<div class="tip">
					<h3 class="flb bz-mtb10">
						<em id="return_$_GET[handlekey]">{lang lgnore_friend}</em>
						<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
					</h3>
					<form method="post" autocomplete="off" id="friendform_{$uid}" name="friendform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=ignore&uid=$uid&confirm=1" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
						<input type="hidden" name="referer" value="{echo dreferer()}">
						<input type="hidden" name="friendsubmit" value="true" />
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="hidden" name="from" value="$_GET[from]" />
						<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
						<div class="c bz-p10">{lang determine_lgnore_friend}</div>
						<p class="o pns">
							<button type="submit" name="friendsubmit_btn" class="pnc button2" value="true"><strong>{lang determine}</strong></button>
						</p>
					</form>
					<script type="text/javascript">
						function succeedhandle_{$_GET[handlekey]}(url, msg, values) {
							if(values['from'] == 'notice') {
								deleteQueryNotice(values['uid'], 'pendingFriend');
							} else if(typeof friend_delete == 'function') {
								friend_delete(values['uid']);
							}
						}
					</script>
				</div>
			</div>
		
		<!--{elseif $op == 'find'}-->
			
	        <div class="bz-p10 cl">
				<!--{if !empty($recommenduser) || $nearlist || $friendlist || $onlinelist}-->
	
					<!--{if !empty($recommenduser)}-->
					<h2 class="mtw">{lang recommend_user}</h2>
					<ul class="buddy cl">
						<!--{loop $recommenduser $key $value}-->
						<li>
							<div class="avt"><a href="home.php?mod=space&uid=$value[uid]" title="$value[username]" target="_blank" c="1"><!--{avatar($value[uid],small)}--></a></div>
							<h4><a href="home.php?mod=space&uid=$value[uid]" title="$value[username]">$value[username]</a></h4>
							<p title="$value[reason]" class="maxh">$value[reason]</p>
							<p><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]" id="a_near_friend_$key" onclick="showWindow(this.id, this.href, 'get', 0);" class="addbuddy">{lang add_friend}</a></p>
						</li>
						<!--{/loop}-->
					</ul>
					<!--{/if}-->
	
					<!--{if $nearlist}-->
					<h2 class="mtw">{lang surprise_they_near}</h2>
					<ul class="buddy cl">
						<!--{loop $nearlist $key $value}-->
						<li>
							<div class="avt"><a href="home.php?mod=space&uid=$value[uid]" title="$value[username]" target="_blank" c="1"><!--{avatar($value[uid],small)}--></a></div>
							<h4><a href="home.php?mod=space&uid=$value[uid]" title="$value[username]">$value[username]</a></h4>
							<p><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]" id="a_near_friend_$key" onclick="showWindow(this.id, this.href, 'get', 0);" class="addbuddy">{lang add_friend}</a></p>
						</li>
						<!--{/loop}-->
					</ul>
					<!--{/if}-->
	
					<!--{if $friendlist}-->
					<h2 class="mtw">{lang friend_friend_might_know}</h2>
					<ul class="buddy cl">
						<!--{loop $friendlist $key $value}-->
						<li>
							<div class="avt"><a href="home.php?mod=space&uid=$value[uid]" title="$value[username]" target="_blank" c="1"><!--{avatar($value[uid],small)}--></a></div>
							<h4><a href="home.php?mod=space&uid=$value[uid]" title="$value[username]">$value[username]</a></h4>
							<p><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=friendhk_{$value[uid]}" id="a_friend_friend_$key" onclick="showWindow(this.id, this.href, 'get', 0);" class="addbuddy">{lang add_friend}</a></p>
						</li>
						<!--{/loop}-->
					</ul>
					<!--{/if}-->
	
					<!--{if $onlinelist}-->
					<h2 class="mtw">{lang they_online_add_friend}</h2>
					<ul class="buddy cl">
						<!--{loop $onlinelist $key $value}-->
						<li>
							<div class="avt"><a href="home.php?mod=space&uid=$value[uid]" title="$value[username]" target="_blank" c="1"><!--{avatar($value[uid],small)}--></a></div>
							<h4><a href="home.php?mod=space&uid=$value[uid]" title="$value[username]">$value[username]</a></h4>
							<p><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=onlinehk_{$value[uid]}" id="a_online_friend_$key" onclick="showWindow(this.id, this.href, 'get', 0);" class="addbuddy">{lang add_friend}</a></p>
						</li>
						<!--{/loop}-->
					</ul>
					<!--{/if}-->
					
				<!--{else}-->
					<div class="guide-no">
						<p class="iconfont icon-quxiaoguanzhu color-b" style="font-size: 50px;"></p>
						<p class="color-b">{lang find_know_nofound}</p>
					</div>
				<!--{/if}-->
			</div>

		<!--{elseif $op == 'search'}-->
		
	        <div class="bz-p10 cl">
				<h3 class="tbmu">{lang search_member_result}:</h3>
				<!--{template home/space_list}-->
	        </div>	
	        
		<!--{elseif $op=='changenum'}-->
		
			<div class="bz-p10 cl">
				<h3 class="flb">
					<em id="return_$_GET[handlekey]">{lang friend_hot}</em>
					<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
				</h3>
				<form method="post" autocomplete="off" id="changenumform_{$uid}" name="changenumform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=changenum&uid=$uid">
					<input type="hidden" name="referer" value="{echo dreferer()}">
					<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="c">
						<p>{lang adjust_friend_hot}</p>
						<p>{lang new_hot}:<input type="text" name="num" value="$friend[num]" size="5" class="px" /> ({lang num_0_999})</p>
					</div>
					<p class="o pns">
						<button type="submit" name="changenumsubmit" class="pn pnc" value="true"><strong>{lang determine}</strong></button>
					</p>
				</form>
				<script type="text/javascript" reload="1">
					function succeedhandle_$_GET[handlekey](url, msg, values) {
						friend_delete(values['uid']);
						$('spannum_'+values['fid']).innerHTML = values['num'];
						hideWindow('$_GET[handlekey]');
					}
				</script>
			</div>	
		
		<!--{elseif $op=='changegroup'}-->
		
			<div class="bz-p10 cl">
				<h3 class="flb">
					<em id="return_$_GET[handlekey]">{lang set_friend_group}</em>
					<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
				</h3>
				<form method="post" autocomplete="off" id="changegroupform_{$uid}" name="changegroupform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=changegroup&uid=$uid" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
					<input type="hidden" name="referer" value="{echo dreferer()}">
					<input type="hidden" name="changegroupsubmit" value="true" />
					<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="c">
						<p>{lang set_friend_group}</p>
						<table><tr>
						<!--{eval $i=0;}-->
						<!--{loop $groups $key $value}-->
						<td style="padding:8px 8px 0 0;"><label><input type="radio" name="group" value="$key"$groupselect[$key] />$value</label></td>
						<!--{if $i%2==1}--></tr><tr><!--{/if}-->
						<!--{eval $i++;}-->
						<!--{/loop}-->
						</tr></table>
					</div>
					<p class="o pns">
						<button type="submit" name="changegroupsubmit_btn" class="pn pnc" value="true"><strong>{lang determine}</strong></button>
					</p>
				</form>
				<script type="text/javascript">
					function succeedhandle_$_GET[handlekey](url, msg, values) {
						friend_changegroup(values['gid']);
					}
				</script>
	        </div>
	        
		<!--{elseif $op=='editnote'}-->
		
	        <div class="bz-p10 cl">
				<h3 class="flb">
					<em id="return_$_GET[handlekey]">{lang friend_note}</em>
					<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
				</h3>
				<form method="post" autocomplete="off" id="editnoteform_{$uid}" name="editnoteform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=editnote&uid=$uid" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
					<input type="hidden" name="referer" value="{echo dreferer()}">
					<input type="hidden" name="editnotesubmit" value="true" />
					<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="c">
						<p>{lang friend_note_message}</p>
						<input type="text" name="note" class="px mtn" value="$friend[note]" size="50" />
					</div>
					<p class="o pns">
						<button type="submit" name="editnotesubmit_btn" class="pn pnc" value="true"><strong>{lang determine}</strong></button>
					</p>
				</form>
				<script type="text/javascript">
					function succeedhandle_$_GET[handlekey](url, msg, values) {
						var uid=values['uid'];
						var elem = $('friend_note_'+uid);
						if(elem) {
							elem.innerHTML = values['note'];
						}
					}
				</script>
	        </div>
	        
		<!--{elseif $op=='group'}-->
		
		    <div class="bz-fesub-appl">
				<ul class="tb cl">
					<li{if !isset($_GET[group])} class="a"{/if}><a href="home.php?mod=spacecp&ac=friend&op=group">{lang all_friends}</a></li>
					<!--{loop $groups $key $value}-->
				    <li{if isset($_GET[group]) && $_GET[group]==$key} class="a"{/if}><a href="home.php?mod=spacecp&ac=friend&op=group&group=$key">$value</a></li>
				    <!--{/loop}-->
				</ul>
			</div>
            <div class="cl banzhuan-clear">
				<p class="tbmu bz-p10">{lang friend_group_hot_message}</p>
				<!--{if $list}-->
				<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=friend&op=group&ref">
					<div id="friend_ul" class="bz-p10 banzhuan-clear bz-bg-fff bz-fe-list">
						<ul class="buddy cl">
						<!--{loop $list $key $value}-->
							<li class="cl">
								<div class="z avt"><a href="home.php?mod=space&uid=$value[uid]"><!--{avatar($value[uid],middle)}--></a></div>
								<div class="z ntbody">
									<div style="margin-left: 10px;">
										<p><a href="home.php?mod=space&uid=$value[uid]">$value[username]</a><span class="y">{lang hot}:$value[num]</span></p>
										<p class="a"><a>$value[group]</a></p>
									</div>
								</div>
							</li>
						<!--{/loop}-->
						</ul>
					</div>
					<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="groupsubmin" value="true" />
				</form>
				<!--{else}-->
				<div class="guide-no">
				    <p class="iconfont icon-quxiaoguanzhu color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang no_friend_list}</p>
				</div>
				<!--{/if}-->
			</div>

		<!--{elseif $op=='groupname'}-->
		
			<div class="bz-p10 cl">
				<h3 class="flb">
					<em id="return_$_GET[handlekey]">{lang friends_group}</em>
					<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
				</h3>
				<div id="__groupnameform_{$group}">
					<form method="post" autocomplete="off" id="groupnameform_{$group}" name="groupnameform_{$group}" action="home.php?mod=spacecp&ac=friend&op=groupname&group=$group" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
						<input type="hidden" name="referer" value="{echo dreferer()}">
						<input type="hidden" name="groupnamesubmit" value="true" />
						<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<div class="c">
							<p>{lang set_friend_group_name}</p>
							<p class="mtm">{lang new_name}:<input type="text" name="groupname" value="$groups[$group]" size="15" class="px" /></p>
						</div>
						<p class="o pns">
							<button type="submit" name="groupnamesubmit_btn" value="true" class="pn pnc"><strong>{lang determine}</strong></button>
						</p>
					</form>
					<script type="text/javascript">
						function succeedhandle_$_GET[handlekey](url, msg, values) {
							friend_changegroupname(values['gid']);
						}
					</script>
				</div>
	        </div>
	        
		<!--{elseif $op=='groupignore'}-->
		
			<div class="bz-p10 cl">
				<h3 class="flb">
					<em id="return_$_GET[handlekey]">{lang set_member_feed}</em>
					<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
				</h3>
				<div id="$group">
					<form method="post" autocomplete="off" id="groupignoreform" name="groupignoreform" action="home.php?mod=spacecp&ac=friend&op=groupignore&group=$group" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
						<input type="hidden" name="referer" value="{echo dreferer()}">
						<input type="hidden" name="groupignoresubmit" value="true" />
						<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<div class="c">
							<!--{if !isset($space['privacy']['filter_gid'][$group])}-->
							<p>{lang not_show_feed_homepage}</p>
							<!--{else}-->
							<p>{lang show_feed_homepage}</p>
							<!--{/if}-->
						</div>
						<p class="o pns">
							<button type="submit" name="groupignoresubmit_btn" class="pn pnc" value="true"><strong>{lang determine}</strong></button>
						</p>
					</form>
				</div>
			</div>	
			
		<!--{elseif $op=='request'}-->
		
            <div class="cl bz-mtb10 banzhuan-clear">
				<div class="tbmu bz-p10">
					<!--{if $list}-->
					<!--{/if}-->
					<span id="add_friend_div">{lang select_friend_application_do}</span>
					<!--{if $maxfriendnum}-->
					({lang max_friend_num})
					<p>
						<!--{if $_G[magic][friendnum]}-->
						<img src="{STATICURL}image/magic/friendnum.small.gif" alt="friendnum" class="vm" />
						<a id="a_magic_friendnum" href="home.php?mod=magic&mid=friendnum" onclick="showWindow(this.id, this.href, 'get', '0')">{lang expansion_friend}</a>
						({lang expansion_friend_message})
						<!--{/if}-->
					</p>
					<!--{/if}-->
				</div>
				<!--{if $list}-->
				<ul id="friend_ul" class="bz-p10 bz-bg-fff friend_ul_request">
					<!--{loop $list $key $value}-->
					<li id="friend_tbody_$value[fuid]">
						<table cellpadding="0" cellspacing="0" class="tfm">
							<tr>
								<td width="140">
									<div class="avt avtm"><a href="home.php?mod=space&uid=$value[fuid]" c="1"><!--{avatar($value[fuid],middle)}--></a></div>
								</td>
								<td>
									<h4>
										<a href="home.php?mod=space&uid=$value[fuid]">$value[fusername]</a>
										<!--{if $ols[$value[fuid]]}--><img src="{IMGDIR}/ol.gif" alt="online" title="{lang online}" class="vm" /> <!--{/if}-->
										<!--{if $value['videostatus']}-->
										<img src="{IMGDIR}/videophoto.gif" alt="videophoto" class="vm" /> <span class="xg1">{lang certified_by_video}</span>
										<!--{/if}-->
									</h4>
									<div id="friend_$value[fuid]">
										<!--{if $value[note]}--><div class="quote"><blockquote id="quote">$value[note]</blockquote></div><!--{/if}-->
										<p class="color-c"><!--{date($value[dateline], 'n-j H:i')}--></p>
										<p><a href="home.php?mod=spacecp&ac=friend&op=getcfriend&fuid=$value[fuid]&handlekey=cfrfriendhk_{$value[uid]}" id="a_cfriend_$key" class="color-c">{lang your_common_friends}</a></p>
										<p class="mtm cl pns">
											<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[fuid]&handlekey=afrfriendhk_{$value[uid]}" id="afr_$value[fuid]" class="pn z"><em class="z">{lang confirm_applications}</em></a>
											<a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$value[fuid]&confirm=1&handlekey=afifriendhk_{$value[uid]}" id="afi_$value[fuid]" class="z ptn color-c">{lang ignore}</a>
										</p>
									</div>
								</td>
							</tr>
							<tbody id="cf_$value[fuid]"></tbody>
						</table>
					</li>
					<!--{/loop}-->
				</ul>
				<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
				<!--{else}-->
				<div class="guide-no">
				    <p class="iconfont icon-quxiaoguanzhu color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang no_new_friend_application}</p>
				</div>
				<!--{/if}-->
            </div>
            
		<!--{elseif $op=='getcfriend'}-->
		
	        <div class="bz-mtb10 cl banzhuan-clear">
				<h3 class="flb bz-p10">
					<em id="return_$_GET[handlekey]">{lang common_friends}</em>
					<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc">{lang close}</a></span><!--{/if}-->
				</h3>
				<div class="c">
					<!--{if $list}-->
					<div class="bz-p10 bz-bg-fff">
						<!--{if count($list)>14}-->
						<p class="bz-ptb10">{lang max_view_15_friends}</p>
						<!--{else}-->
						<p class="bz-ptb10">{lang you_have_common_friends}</p>
						<!--{/if}-->
						<ul class="cl bzcfmls bzcfml">
							<!--{loop $list $key $value}-->
							<li>
								<div class="avt"><a href="home.php?mod=space&uid=$value[uid]"><!--{avatar($value[uid],middle)}--></a></div>
								<p><a href="home.php?mod=space&uid=$value[uid]">$value[username]</a></p>
							</li>
							<!--{/loop}-->
						</ul>
					</div>
					<!--{else}-->
					<div class="guide-no">
						<p class="iconfont icon-quxiaoguanzhu color-b" style="font-size: 50px;"></p>
						<p class="color-b">{lang you_have_no_common_friends}</p>
					</div>
					<!--{/if}-->
				</div>
	        </div>
	        
		<!--{elseif $op=='add'}-->
		
			<div class="bz-p10 cl bz-bg-fff">
				<h3 class="flb" style="margin-bottom: 10px;">
					<em id="return_$_GET[handlekey]">{lang add_friend}</em>
					<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
				</h3>
				<form method="post" autocomplete="off" id="addform_{$tospace[uid]}" name="addform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
					<input type="hidden" name="referer" value="{echo dreferer()}" />
					<input type="hidden" name="addsubmit" value="true" />
					<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="c">
						<table>
							<tr>
								<th valign="top" width="60" class="avt"><a href="home.php?mod=space&uid=$tospace[uid]"><!--{avatar($tospace[uid],small)}--></th>
								<td valign="top">{lang add} <strong>{$tospace[username]}</strong> {lang add_friend_note}:<br />
									<input type="text" name="note" value="" size="35" class="px"  onkeydown="ctrlEnter(event, 'addsubmit_btn', 1);" />
									<p class="mtn xg1">({lang view_note_message})</p>
									<p class="mtm">
										{lang friend_group}: <select name="gid" class="ps">
										<!--{loop $groups $key $value}-->
										<option value="$key" {if empty($space['privacy']['groupname']) && $key==1} selected="selected"{/if}>$value</option>
										<!--{/loop}-->
										</select>
									</p>
								</td>
							</tr>
						</table>
					</div>
					<p class="o pns">
						<button type="submit" name="addsubmit_btn" id="addsubmit_btn" value="true" class="button2 pnc"><strong>{lang determine}</strong></button>
					</p>
				</form>
			</div>	
			
		<!--{elseif $op=='add2'}-->
		
	        <div class="bz-p10 cl bz-bg-fff">
				<h3 class="flb" style="margin-bottom: 10px;">
					<em id="return_$_GET[handlekey]">{lang approval_the_request}</em>
					<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
				</h3>
				<form method="post" autocomplete="off" id="addratifyform_{$tospace[uid]}" name="addratifyform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
					<input type="hidden" name="referer" value="{echo dreferer()}" />
					<input type="hidden" name="add2submit" value="true" />
					<input type="hidden" name="from" value="$_GET[from]" />
					<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="c">
						<table cellspacing="0" cellpadding="0">
							<tr>
								<th valign="top" width="60" class="avt"><a href="home.php?mod=space&uid=$tospace[uid]"><!--{avatar($tospace[uid],small)}--></th>
								<td valign="top">
									<p>{lang approval_the_request_group}:</p>
									<table>
										<tr>
										<!--{eval $i=0;}-->
										<!--{loop $groups $key $value}-->
										<td style="padding:8px 8px 0 0;"><label for="group_$key"><input type="radio" name="gid" id="group_$key" value="$key"$groupselect[$key] />$value</label></td>
										<!--{if $i%2==1}--></tr><tr><!--{/if}-->
										<!--{eval $i++;}-->
										<!--{/loop}-->
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</div>
					<p class="o pns">
						<button type="submit" name="add2submit_btn" value="true" class="button2 pnc"><strong>{lang approval}</strong></button>
					</p>
				</form>
				<script type="text/javascript">
					function succeedhandle_$_GET[handlekey](url, msg, values) {
						if(values['from'] == 'notice') {
							deleteQueryNotice(values['uid'], 'pendingFriend');
						} else {
							myfriend_post(values['uid']);
						}
					}
				</script>
	        </div>	
	        
		<!--{elseif $op=='getinviteuser'}-->
		
			$jsstr
			
		<!--{/if}-->

<!--{if !$_G[inajax]}-->
		</div>
	</div>
	
</div>
<!--{/if}-->



<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

