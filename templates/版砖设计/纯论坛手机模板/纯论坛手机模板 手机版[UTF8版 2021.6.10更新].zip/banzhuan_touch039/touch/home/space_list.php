<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $list}-->
	<ul class="buddy cl bz-fe-list bzbt1">
		<!--{loop $list $key $value}-->
		<li class="bbda cl">	
			<div class="z avt">
				<a href="home.php?mod=space&uid=$value[uid]&do=profile" c="1"><!--{avatar($value[uid],middle)}--></a>
			</div>
			<div class="z ntbody">
				<div style="margin-left: 10px;">
					<p>
						<!--
						<span class="y">
							<!--{if isset($value['follow']) && $key != $_G['uid']}--><a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&hash={FORMHASH}&fuid=$value[uid]" id="a_followmod_$key" onclick="showWindow('followmod', this.href, 'get', 0)"><!--{if $value['follow']}--><span>{lang follow_del}</span><!--{else}--><span class="color-red" style="font-weight: 700;">{lang follow_add}TA</span><!--{/if}--></a><!--{/if}-->
						</span>
						-->
						<a href="home.php?mod=space&uid=$value[uid]&do=profile" title="$value[username]" {eval g_color($value[groupid]);}>$value[username]</a>
					</p>
					<p class="a">
						<a>
						{$_G['cache']['usergroups'][$value['groupid']]['grouptitle']} <!--{eval g_icon($value[groupid]);}-->
						<!--{if $value['credits']}-->&nbsp;{lang credit_num}: $value[credits]<!--{/if}-->
						</a>
					</p>
				</div>
			</div>
		</li>
		<!--{/loop}-->
	</ul>
	<!--{if $multi}--><div class="mtm pgs cl">$multi</div><!--{/if}-->
	<script type="text/javascript">
		function succeedhandle_followmod(url, msg, values) {
			var fObj = $('a_followmod_'+values['fuid']);
			if(values['type'] == 'add') {
				fObj.innerHTML = '{lang follow_del}';
				fObj.className = 'flw_btn_unfo';
				fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
			} else if(values['type'] == 'del') {
				fObj.innerHTML = '{lang follow_add}TA';
				fObj.className = 'flw_btn_fo';
				fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
			}
		}
	</script>
<!--{else}-->
	<div class="guide-no">
		<p class="iconfont icon-quxiaoguanzhu color-b" style="font-size: 50px;"></p>
		<p class="color-b">{lang no_members_of}</p>
	</div>
<!--{/if}-->
