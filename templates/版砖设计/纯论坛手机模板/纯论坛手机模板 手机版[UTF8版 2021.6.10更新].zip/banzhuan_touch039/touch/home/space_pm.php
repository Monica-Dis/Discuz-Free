<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $_G['home_tpl_titles'] = array('{lang pm}');}-->
<!--{template common/header}-->
    <div class="bz-header">
		<div class="bz-header-left">
			<!--{if in_array($filter, array('privatepm'))}-->
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="iconfont icon-fanhui"></a>
			<!--{elseif in_array($_GET[subop], array('view'))}-->
			<a href="home.php?mod=space&do=pm" class="iconfont icon-fanhui"></a>
			<!--{elseif in_array($_GET[subop], array('viewg'))}-->
			<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
			<!--{elseif in_array($filter, array('announcepm'))}-->
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="iconfont icon-fanhui"></a>
			<!--{/if}-->
	    </div>
		<h2><!--{if in_array($filter, array('privatepm'))}-->{lang mypm}<!--{elseif in_array($_GET[subop], array('view'))}--><!--{if $tousername}-->{$tousername}<!--{else}--><!--{if $value[subject]}-->$value[subject] <!--{else}-->{lang chat_type} <!--{/if}--><em class="fz12">$value[members]</em><em class="fz12">&#20154;</em><!--{/if}--><!--{elseif in_array($_GET[subop], array('viewg'))}-->{lang announce_pm}<!--{elseif in_array($filter, array('announcepm'))}-->{lang announce_pm}<!--{/if}--></h2>
		<div class="bz-header-right">
			<!--{if in_array($filter, array('privatepm'))}-->
			<a href="home.php?mod=spacecp&ac=pm"><em>{lang send_pm}</em></a>
			<!--{elseif in_array($_GET[subop], array('view'))}-->
			<a href="forum.php" class="iconfont icon-home"></a>
			<!--{elseif in_array($_GET[subop], array('viewg'))}-->
			<a href="forum.php" class="iconfont icon-home"></a>
			<!--{elseif in_array($filter, array('announcepm'))}-->
			<a href="forum.php" class="iconfont icon-home"></a>
			<!--{/if}-->
		</div>
	</div>

<!--{if in_array($filter, array('privatepm')) || in_array($_GET[subop], array('view')) || in_array($filter, array('announcepm'))}-->


	<!--{if in_array($filter, array('privatepm'))}-->
		<div class="bz-bg-fff bz-pm-appl">
			<ul class="cl">
				<li$actives[privatepm] $actives[newpm]><a href="home.php?mod=space&do=pm&filter=privatepm">{lang private_pm}</a></li>
				<li$actives[announcepm]><a href="home.php?mod=space&do=pm&filter=announcepm">{lang announce_pm}</a></li>
			</ul>
		</div>
		<!--{if $list}-->
			<div class="pmbox bz-bg-fff">
				<ul class="bzbt1">
					<!--{loop $list $key $value}-->
					<li>
						<div class="avatar_img">
							<img style="height:30px;width:30px;" src="<!--{if $value[pmtype] == 2}-->{STATICURL}image/common/grouppm.png<!--{else}--><!--{avatar($value[touid] ? $value[touid] : ($value[lastauthorid] ? $value[lastauthorid] : $value[authorid]), middle, true)}--><!--{/if}-->" />
							<!--{if $value[new]}--><span class="num">$value[pmnum]</span><!--{/if}-->
						</div>
						<a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}">
							<div class="cl">
								<!--{if $value[touid]}-->
									<!--{if $value[msgfromid] == $_G[uid]}-->
										<span class="name">{$value[tousername]}</span>
									<!--{else}-->
										<span class="name">{$value[tousername]}</span>
									<!--{/if}-->
								<!--{elseif $value['pmtype'] == 2}-->
									<span class="name"><!--{if $value[subject]}-->$value[subject]<!--{/if}--></span>
								<!--{/if}-->
								<span class="grey y" style="font-size: 12px;"><!--{date($value[dateline], 'u')}--></span>
							</div>
							<div class="cl color-c">
								<span>
								<!--{if $value['pmtype'] == 2}-->
									&#32676;&#20027; : $value['firstauthor']<br>
								<!--{/if}-->
								<!--{if $value['pmtype'] == 2 && $value['lastauthor']}-->
									<div>......<br>$value['lastauthor'] : $value[message]</div>
								<!--{else}-->
									$value[message]
								<!--{/if}-->
								</span>
							</div>
						</a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
	    <!--{else}-->
	        <div class="bz-mtb10 bz-p10 bz-bg-fff">
				<div class="guide-no">
					<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang no_corresponding_pm}</p>
				</div>
			</div>
		<!--{/if}-->
	<!--{elseif in_array($_GET[subop], array('view'))}-->
		<div class="banzhuan-clear"></div>
		<div class="cl">
			<div class="msgbox bz-bg-fff bz-p10 bzbb1">
				<!--{if !$list}-->
					{lang no_corresponding_pm}
				<!--{else}-->
					<!--{loop $list $key $value}-->
						<!--{subtemplate home/space_pm_node}-->
					<!--{/loop}-->
					$multi
				<!--{/if}-->
			</div>
			<form id="pmform" class="pmform" name="pmform" method="post" action="home.php?mod=spacecp&ac=pm&op=send&pmid=$pmid&daterange=$daterange&pmsubmit=yes&mobile=2" >
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<!--{if !$touid}-->
				<input type="hidden" name="plid" value="$plid" />
				<!--{else}-->
				<input type="hidden" name="touid" value="$touid" />
				<!--{/if}-->
				<div class="b_p15 bzbt1 bz-bg-fff">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tbody>
							<tr>
								<td>
									<input type="text" value="" class="bz-input" autocomplete="off" id="replymessage" name="message">
								</td>
								<td width="60" align="right">
									<div>
										<input type="button" name="pmsubmit" id="pmsubmit" class="formdialog button2" value="{lang reply}" />
									</div>
								</td>
							</tr>
						</tbody>
					</table>
				</div>
           </form>
		</div>

    <!--{elseif in_array($filter, array('announcepm'))}-->
		<div class="bz-bg-fff bz-pm-appl">
			<ul class="cl">
				<li$actives[privatepm] $actives[newpm]><a href="home.php?mod=space&do=pm&filter=privatepm">{lang private_pm}</a></li>
				<li$actives[announcepm]><a href="home.php?mod=space&do=pm&filter=announcepm">{lang announce_pm}</a></li>
			</ul>
		</div>
	    <div class="bz-p10 banzhuan-clear bz-bg-fff bz-mtb10 bz-nt-list">
			<!--{if $count || $grouppms}-->
			<div class="cl">
				<!--{if $grouppms}-->
					<!--{loop $grouppms $grouppm}-->
						<li id="gpmlist_$grouppm[id]" class="bbda cur1 cl{if !$gpmstatus[$grouppm[id]]} newpm{/if}">
							<div class="z avt">
								<a href="home.php?mod=space&do=pm&subop=viewg&pmid=$grouppm[id]">
								<!--{if $grouppm[author]}-->
									<img src="{IMGDIR}/annpm.png" alt="" />
								<!--{else}-->
									<img src="{IMGDIR}/systempm.png" alt="" />
								<!--{/if}-->
								</a>
							</div>
							<div class="z ntbody">
								<div style="margin-left: 10px;">
									<p class="color-c"><!--{date($grouppm[dateline], 'u')}--><!--{if $grouppm[author]}--><a href="home.php?mod=space&uid=$grouppm[authorid]">&nbsp;&nbsp;$grouppm[author]</a> {lang say} :<!--{/if}--></p>
									<p id="p_gpmid_$grouppm[id]" class="a bz-mtb10">$grouppm[message]<a href="home.php?mod=space&do=pm&subop=viewg&pmid=$grouppm[id]" id="gpmlist_$grouppm[id]_a" class="color-b" style="font-size: 12px;">{lang show}</a></p>
								</div>
							</div>
						</li>
					<!--{/loop}-->
				<!--{/if}-->
			</div>
		    <!--{else}-->
			<div class="guide-no">
				<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
				<p class="color-b">{lang no_corresponding_pm}</p>
			</div>
		    <!--{/if}-->
		</div>

	<!--{/if}-->


<!--{else}-->

    <!--{if $_GET['subop'] == 'viewg'}-->
		<!--{if $grouppm}-->
			<div id="pm_ul" class="bz-bg-fff bz-p10 bz-mtb10">
				<div class="ntbody">
					<p class="bz-mtb10">$grouppm[message]</p>
				</div>
				<div class="avt bz-mtb10">
					<p class="color-b bz-mtb10" style="font-size: 12px;line-height: 20px;">
						<!--{if $grouppm[author]}-->
							<img src="{IMGDIR}/annpm.png" alt="" />
						<!--{else}-->
							<img src="{IMGDIR}/systempm.png" alt="" />
						<!--{/if}-->
						{lang sendmultipmsystem}&nbsp;&nbsp;<span><!--{date($grouppm[dateline], 'u')}--></span>
						<!--<a href="home.php?mod=spacecp&ac=pm&op=delete&deletepm_gpmid[]=$grouppm[id]&pmid=$grouppm[id]&handlekey=gpmdeletehk_{$grouppm[id]}" id="a_gpmdelete_$grouppm[id]" class="y iconfont icon-guanbi color-b" style="font-size: 12px;"></a>-->
					</p>
				</div>
			</div>
		<!--{else}-->
			<div class="guide-no">
				<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
				<p class="color-b">{lang no_corresponding_pm}</p>
	        </div>
		<!--{/if}-->
    <!--{/if}-->

<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->



