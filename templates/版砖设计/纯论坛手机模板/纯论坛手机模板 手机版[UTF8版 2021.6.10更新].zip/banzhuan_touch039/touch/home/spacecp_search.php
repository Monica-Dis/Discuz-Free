<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="bz-header">
	<div class="bz-header-left"><a href="javascript:history.back();" class="iconfont icon-fanhui"></a></div>
	<h2>
		<ul>
			<li><a href="search.php?mod=forum&mobile=2">{lang thread}</a></li>
			<li class="a"><a href="home.php?mod=spacecp&ac=search&mobile=2">{lang users}</a></li>
		</ul>
	</h2>
	<div class="bz-header-right"><a href="forum.php" class="iconfont icon-home"></a></div>
</div>
<div class="cl">
	<div class="mn">

		<!--{if !empty($_GET['searchsubmit'])}-->

			<!--{if empty($list)}-->
				<div class="guide-no">
					<p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang no_search_friend}<a href="home.php?mod=spacecp&ac=search">{lang change_search}</a></p>
				</div>
			<!--{else}-->
				<div class="bz_search">
					<ul>
						<li>
							<a>
							<em class="iconfont icon-search"></em>
							<form action="home.php" method="post" class="searchform" autocomplete="off" accept-charset="UTF-8">
								<input type="hidden" name="searchsubmit" value="true" />
								<input type="hidden" name="op" value="$_GET[op]" />
								<input type="hidden" name="mod" value="spacecp" />
								<input type="hidden" name="ac" value="search" />
								<input type="hidden" name="type" value="all" />
								<input type="text" autocomplete="off" class="input" name="username" value="" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#21517;">
						    </form>
							</a>
						</li>
					</ul>
				</div>
				<div class="bz-p10 color-c">&#25214;&#21040;&#20197;&#19979;&#29992;&#25143;</div>
				<!--{template home/space_list}-->
			<!--{/if}-->
			
		<!--{else}-->
		
			<div class="ptm scf">
				
			<!--{if $_GET['op'] == 'sex'}-->
			
				<h2>{lang seek_bgfriend}1</h2>
				<div id="s_sex" class="bm bmn">
					<form action="home.php" method="get">
						<table cellpadding="0" cellspacing="0" class="tfm">
							<!--{loop array('affectivestatus','lookingfor','zodiac','constellation') $key}-->
							<!--{if $fields[$key]}-->
							<tr>
								<th>{$fields[$key][title]}</th>
								<td>{$fields[$key][html]}</td>
							</tr>
							<!--{/if}-->
							<!--{/loop}-->
							<tr>
								<th>{lang sex}:</th>
								<td>
									<select id="gender" name="gender">
										<option value="0">{lang random}</option>
										<option value="1">{lang male}</option>
										<option value="2">{lang female}</option>
									</select>
								</td>
							</tr>
							<tr>
								<th>{lang age_segment}</th>
								<td><input type="text" name="startage" value="" size="10" class="px" style="width: 114px;" /> ~ <input type="text" name="endage" value="" size="10" class="px" style="width: 114px;" /></td>
							</tr>
							<tr>
								<th>{lang upload_avatar}</th>
								<td class="pcl"><label><input type="checkbox" name="avatarstatus" value="1" class="pc" />{lang uploaded_avatar}</label></td>
							</tr>
							<tr>
								<th>{lang username}</th>
								<td><input type="text" name="username" value="" class="px" /></td>
							</tr>
							<tr>
								<th>&nbsp;</th>
								<td>
									<input type="hidden" name="searchsubmit" value="true" />
									<button type="submit" class="pn"><em>{lang seek}</em></button>
								</td>
							</tr>
						</table>
						<input type="hidden" name="op" value="$_GET[op]" />
						<input type="hidden" name="mod" value="spacecp" />
						<input type="hidden" name="ac" value="search" />
						<input type="hidden" name="type" value="base" />
					</form>
				</div>
				<!--{elseif $_GET['op'] == 'reside' }-->
				<h2>{lang seek_same_city}2</h2>
				<div id="s_reside" class="bm bmn">
					<form action="home.php" method="get">
						<table cellpadding="0" cellspacing="0" class="tfm">
							<tr>
								<th>{lang reside_city}</th>
								<td id="residecitybox">$residecityhtml</td>
							</tr>
							<tr>
								<th>{lang username}</th>
								<td><input type="text" name="username" value="" class="px" /></td>
							</tr>
							<tr>
								<th>&nbsp;</th>
								<td>
									<input type="hidden" name="searchsubmit" value="true" />
									<button type="submit" class="pn"><em>{lang seek}</em></button>
								</td>
							</tr>
						</table>
						<input type="hidden" name="op" value="$_GET[op]" />
						<input type="hidden" name="mod" value="spacecp">
						<input type="hidden" name="ac" value="search">
						<input type="hidden" name="type" value="base">
					</form>
				</div>
				<!--{elseif $_GET['op'] == 'birth' }-->
				<h2>{lang seek_same_city_people}3</h2>
				<div id="s_birth" class="bm bmn">
					<form action="home.php" method="get">
						<table cellpadding="0" cellspacing="0" class="tfm">
							<tr>
								<th>{lang birth_city}</th>
								<td id="birthcitybox">$birthcityhtml</td>
							</tr>
							<tr>
								<th>{lang username}</th>
								<td><input type="text" name="username" value="" class="px" /></td>
							</tr>
							<tr>
								<th>&nbsp;</th>
								<td>
									<input type="hidden" name="searchsubmit" value="true" />
									<button type="submit" class="pn"><em>{lang seek}</em></button>
								</td>
							</tr>
						</table>
						<input type="hidden" name="op" value="$_GET[op]" />
						<input type="hidden" name="mod" value="spacecp" />
						<input type="hidden" name="ac" value="search" />
						<input type="hidden" name="type" value="base" />
					</form>
				</div>
				<!--{elseif $_GET['op'] == 'birthyear' }-->
				<h2>{lang seek_same_birthday}4</h2>
				<div id="s_birthyear" class="bm bmn">
					<form action="home.php" method="get">
						<table cellpadding="0" cellspacing="0" class="tfm">
							<tr>
								<th>{lang birthday}</th>
								<td>
									<select id="birthyear" name="birthyear" onchange="showbirthday();" class="ps">
										<option value="0">&nbsp;</option>
										$birthyeayhtml
									</select> {lang year}
									<select id="birthmonth" name="birthmonth" onchange="showbirthday();" class="ps">
										<option value="0">&nbsp;</option>
										$birthmonthhtml
									</select> {lang month}
									<select id="birthday" name="birthday" class="ps">
										<option value="0">&nbsp;</option>
										$birthdayhtml
									</select> {lang day}
								</td>
							</tr>
							<tr>
								<th>{lang username}</th>
								<td><input type="text" name="username" value="" class="px" /></td>
							</tr>
							<tr>
								<th>&nbsp;</th>
								<td>
									<input type="hidden" name="searchsubmit" value="true" />
									<button type="submit" class="pn"><em>{lang seek}</em></button>
								</td>
							</tr>
						</table>
						<input type="hidden" name="op" value="$_GET[op]" />
						<input type="hidden" name="mod" value="spacecp" />
						<input type="hidden" name="ac" value="search" />
						<input type="hidden" name="type" value="base" />
					</form>
				</div>
				<!--{elseif $_GET['op'] == 'edu' }-->
				<!--{if $fields['graduateschool'] || $fields['education']}-->
				<h2>{lang seek_classmate}5</h2>
				<div id="s_edu" class="bm bmn">
					<form action="home.php" method="get">
						<table cellpadding="0" cellspacing="0" class="tfm">
							<!--{loop array('graduateschool','education') $key}-->
							<!--{if $fields[$key]}-->
							<tr>
								<th>{$fields[$key][title]}</th>
								<td>{$fields[$key][html]}</td>
							</tr>
							<!--{/if}-->
							<!--{/loop}-->
							<tr>
								<th>{lang username}</th>
								<td><input type="text" name="username" value="" class="px"></td>
							</tr>
							<tr>
								<th>&nbsp;</th>
								<td>
									<input type="hidden" name="searchsubmit" value="true" />
									<button type="submit" class="pn"><em>{lang seek}</em></button>
								</td>
							</tr>
						</table>
						<input type="hidden" name="op" value="$_GET[op]" />
						<input type="hidden" name="mod" value="spacecp" />
						<input type="hidden" name="ac" value="search" />
						<input type="hidden" name="type" value="edu" />
					</form>
				</div>
				<!--{/if}-->
				<!--{elseif $_GET['op'] == 'work' }-->
				<!--{if $fields['occupation'] || $fields['title']}-->
				<h2>{lang seek_colleague}6</h2>
				<div id="s_work" class="bm bmn">
					<form action="home.php" method="get">
						<table cellpadding="0" cellspacing="0" class="tfm">
							<!--{loop array('occupation','title') $key}-->
							<!--{if $fields[$key]}-->
							<tr>
								<th>{$fields[$key][title]}</th>
								<td>{$fields[$key][html]}</td>
							</tr>
							<!--{/if}-->
							<!--{/loop}-->
							<tr>
								<th>{lang username}</th>
								<td><input type="text" name="username" value="" class="px" /></td>
							</tr>
							<tr>
								<th>&nbsp;</th>
								<td>
									<input type="hidden" name="searchsubmit" value="true" />
									<button type="submit" class="pn"><em>{lang seek}</em></button>
								</td>
							</tr>
						</table>
						<input type="hidden" name="op" value="$_GET[op]" />
						<input type="hidden" name="mod" value="spacecp" />
						<input type="hidden" name="ac" value="search" />
						<input type="hidden" name="type" value="work" />
					</form>
				</div>
				<!--{/if}-->
				
			<!--{else}-->
			
				<div class="bz_search">
					<ul>
						<li>
							<a>
							<em class="iconfont icon-search"></em>
							<form action="home.php" method="post" class="searchform" autocomplete="off" accept-charset="UTF-8">
								<input type="hidden" name="searchsubmit" value="true" />
								<input type="hidden" name="op" value="$_GET[op]" />
								<input type="hidden" name="mod" value="spacecp" />
								<input type="hidden" name="ac" value="search" />
								<input type="hidden" name="type" value="all" />
								<input type="text" autocomplete="off" class="input" name="username" value="" placeholder="&#35831;&#36755;&#20837;&#29992;&#25143;&#21517;">
						    </form>
							</a>
						</li>
					</ul>
				</div>
				
			<!--{/if}-->
			</div>
			
		<!--{/if}-->

	</div>
</div>

<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
<div class="banzhuan-clear"></div>
<div id="mask" style="display:none;"></div>
<!--{if !$nofooter}-->
<div class="footer banzhuan-clear"><p>&copy; $_G['setting']['sitename']</p></div>
<!--{/if}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->


