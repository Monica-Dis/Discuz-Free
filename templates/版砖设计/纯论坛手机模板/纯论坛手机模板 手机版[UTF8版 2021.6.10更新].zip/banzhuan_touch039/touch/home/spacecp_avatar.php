<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<div class="bz-mobile">
	<div class="bz-mobile-left">
		<a href="javascript:history.back();" class="iconfont icon-fanhui"></a>
	</div>
	<h2>{lang edit_avatar}</h2>
	<div class="bz-mobile-right">
		<a href="search.php?mod=forum&mobile=2" class="iconfont icon-search4"></a>
	</div>
</div>
<div class="banzhuan-top" style="background: #09AE5D;"></div>
<div class="avatarbar">
    <div class="bz-p10">
        <div id="changeAvatar" class="hm bz-p10"><span>{avatar($_G[uid],big)}{avatar($_G[uid],big)}</span></div>
    </div>
    <div class="anniu hm bz-p10">
        <a href="javascript:;" class="buttonav">{lang upload_avatar}<input id="image" type="file" accept="image/*" capture="camera"></a>
    </div>
</div>
<div id="showEdit">
    <div id="report"></div>
    <div class="anniu">
        <div>
	        	<span id="dataWidth"></span>
	        	<span id="dataHeight"></span>
        </div>
        <dl style="padding:10px;">
	        <a href="javascript:;" id="cancleBtn">{lang cancel}</a>
	        <a href="javascript:;" id="rotateBtn"><em class="iconfont icon-shuaxin"></em></a>
	        <a href="javascript:;" id="confirmBtn">{lang save}</a>
        </dl>
    </div>
</div>

<script type="text/javascript">
$(function() {
	$('#image').on('change', function() {
		var startTimestamp = (new Date()).valueOf();
		var that = this;
		lrz(this.files[0], {
			width: 800,
			height: 800,
			quality: 1
		})
		.then(function(rst) {
			//console.log(rst);
			doFinish(startTimestamp, that.files[0].size, rst);
			return rst;
		})
		.then(function(rst) {
			// Θ&#65533;
			// αajax(rst.base64)..
			// then,Promise \(^o^)/~
			return rst;
		})
		.catch(function(err) {
			// &#65533;
			// εthen&#65533;

			alert(err);
		})
		.always(function() {
			// dz
		});
	});
	
	function cutImg() {
		$("#showEdit").fadeIn();
		var image = $('#report > img');
		image.cropper({
			aspectRatio: 1 / 1,
			autoCropArea: .95,
			strict: true,
			highlight: false,
			dragCrop: false,
			cropBoxMovable: false,
			cropBoxResizable: false,
			responsive: false,
			crop: function (data) {
				if(!$('.cropper-crop-box .live').length){
					$('.cropper-crop-box').append('<span class="live" data-height="'+Math.round(data.height)+'px"></span>'); 
				}
				$('.cropper-crop-box').addClass('change').attr('data-width', Math.round(data.width)+'px');
				$('.cropper-crop-box .live').attr('data-height', Math.round(data.height)+'px');
			}
		});
	}
    
	function toFixed2(num) {
		return parseFloat(+num.toFixed(2));
	}
		
	function doFinish(startTimestamp, sSize, rst) {
		var sourceSize = toFixed2(sSize / 1024),
			resultSize = toFixed2(rst.base64Len / 1024),
			scale = parseInt(100 - (resultSize / sourceSize * 100));
		$("#report").html('<img src="' + rst.base64 + '" style="width: 100%;height:100%">');
		cutImg();
	}
	
	$('#rotateBtn').on('tap', function() {
		$('#report > img').cropper('rotate', 90);
	});
			
	$('#cancleBtn').on('tap', function() {
		$("#showEdit").fadeOut();
	});
	$('#confirmBtn').on('tap', function() {
		var image = $('#report > img');
		var dataURL = image.cropper("getCroppedCanvas");
		var imgurl = dataURL.toDataURL("image/jpeg", 0.5);
		popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
		$("#showEdit").fadeOut();
		$.ajax({
			type : 'post',
			dataType: 'text',
			data: imgurl,
			url: 'home.php?mod=spacecp&ac=avatar',
			success: function (s){ 
				popup.close();
				$("#changeAvatar img").attr("src", imgurl);
				history.go(0);
			}
		});
	});

});
</script>

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

