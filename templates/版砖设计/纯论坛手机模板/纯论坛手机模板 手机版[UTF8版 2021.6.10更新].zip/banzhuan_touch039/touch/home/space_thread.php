<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->

	<!--{template home/space_profile_top}-->
	<div class="my_thread">
		<ul class="bz-bg-fff bzbt1 bzbb1">
		<!--{if $list}-->
			<!--{loop $list $thread}-->
				<li>
					<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]">$thread[subject]
					<div class="item-info">
						<span class="by">{lang show}:{$thread[views]}</span>
						<span class="by">{lang reply}:{$thread[replies]}</span>
						<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
							<em class="iconfont icon-top01 color-b y fz12"></em>
						<!--{elseif $thread['digest'] > 0}-->
							<em class="iconfont icon-jing color-b y fz12"></em>
						<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
							<em class="iconfont icon-tupian color-b y"></em>
						<!--{/if}-->	
					</div>
					</a>
				</li>
			<!--{/loop}-->
		<!--{else}-->
		    <li class="guide-no">
			    <p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
				<p class="color-b">{lang no_related_posts}</p>
			</li>
		<!--{/if}-->
		</ul>
		$multi
	</div>

<!--{else}-->

	<!--{if !$diymode}-->

		<div class="bz-header">
			<div class="bz-header-left"><a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="iconfont icon-fanhui"></a></div>
			<h2>{lang myitem}{lang post}</h2>
			<div class="bz-header-right"><a href="forum.php" class="iconfont icon-home"></a></div>
		</div>
		<div class="my_thread">
			<ul class="bz-bg-fff bzbt1 bzbb1">
			<!--{if $list}-->
				<!--{loop $list $thread}-->
					<li>
						<a href="forum.php?mod=viewthread&tid=$thread[tid]" {if $thread['displayorder'] == -1}{/if}>$thread[subject]
						<div class="item-info">
							<span class="by">{lang show}:{$thread[views]}</span>
							<span class="by">{lang reply}:{$thread[replies]}</span>
							<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
								<em class="iconfont icon-top01 color-b y fz12"></em>
							<!--{elseif $thread['digest'] > 0}-->
								<em class="iconfont icon-jing color-b y fz12"></em>
							<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
								<em class="iconfont icon-tupian color-b y"></em>
							<!--{/if}-->	
						</div>
						</a>
					</li>
				<!--{/loop}-->
			<!--{else}-->
			    <li class="guide-no">
				    <p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang no_related_posts}</p>
				</li>
			<!--{/if}-->
			</ul>
			$multi
		</div>
	
	<!--{else}-->

		<!--{template home/space_profile_top}-->
		<div class="my_thread">
			<ul class="bz-bg-fff bzbt1 bzbb1">
			<!--{if $list}-->
				<!--{loop $list $thread}-->
					<li>
						<a href="forum.php?mod=viewthread&tid=$thread[tid]" {if $thread['displayorder'] == -1}{/if}>$thread[subject]
						<div class="item-info">
							<span class="by">{lang show}:{$thread[views]}</span>
							<span class="by">{lang reply}:{$thread[replies]}</span>
							<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
								<em class="iconfont icon-top01 color-b y fz12"></em>
							<!--{elseif $thread['digest'] > 0}-->
								<em class="iconfont icon-jing color-b y fz12"></em>
							<!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
								<em class="iconfont icon-tupian color-b y"></em>
							<!--{/if}-->	
						</div>
						</a>
					</li>
				<!--{/loop}-->
			<!--{else}-->
			    <li class="guide-no">
				    <p class="iconfont icon-nothing color-b" style="font-size: 50px;"></p>
					<p class="color-b">{lang no_related_posts}</p>
				</li>
			<!--{/if}-->
			</ul>
			$multi
		</div>
	
	<!--{/if}-->

<!--{/if}-->


<div class="banzhuan-bottom"></div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

