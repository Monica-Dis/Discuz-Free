<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if empty($diymode)}-->

	<!--{template common/header}-->
	<div class="bz-header">
		<div class="bz-header-left">
			<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="iconfont icon-fanhui"></a>
		</div>
		<h2>{lang myitem}{lang friends}</h2>
		<div class="bz-header-right">
			<a href="search.php?mod=forum&mobile=2" class="iconfont icon-search4"></a>
		</div>
	</div>
	<div class="banzhuan-top"></div>
	
	<div id="ct" class="ct2_a wp cl">
		<div class="mn">
			<div class="bz-mtb10">
				
				<!--{if $space[self]}-->
				
					<div class="bz-fe-appl">
						<div class="tbn">
							<ul>
								<li$actives[me]><a href="home.php?mod=space&do=friend">{lang friend_list}</a></li>
								<li$actives[search]><a href="home.php?mod=spacecp&ac=search">{lang search_friend}</a></li>
								<li$actives[find]><a href="home.php?mod=spacecp&ac=friend&op=find">{lang people_might_know}</a></li>
								<!--{if $_G['setting']['regstatus'] > 1}-->
									<!--<li$actives[invite]><a href="home.php?mod=spacecp&ac=invite">{lang invite_friend}</a></li>-->
								<!--{/if}-->
								<li$actives[request]><a href="home.php?mod=spacecp&ac=friend&op=request">{lang friend_request}</a></li>	
								<li$actives[group]><a href="home.php?mod=spacecp&ac=friend&op=group">{lang set_friend_group}</a></li>
							</ul>
						</div>
					</div>
					<div class="bz-fesub-appl">
						<ul class="tb cl">
							<li{$a_actives[me]}><a href="home.php?mod=space&do=friend">{lang all_friend_list}</a></li>
							<!--{if empty($_G['setting']['sessionclose'])}-->
							<li{$a_actives[onlinefriend]}><a href="home.php?mod=space&do=friend&view=online&type=friend">{lang online_friend}</a></li>
							<li{$a_actives[onlinemember]}><a href="home.php?mod=space&do=friend&view=online&type=member">{lang online_member}</a></li>
							<!--{/if}-->
							<li{$a_actives[onlinenear]}><a href="home.php?mod=space&do=friend&view=online&type=near">{lang online_near}</a></li>
							<li{$a_actives[visitor]}><a href="home.php?mod=space&do=friend&view=visitor">{lang my_visitor}</a></li>
							<li{$a_actives[trace]}><a href="home.php?mod=space&do=friend&view=trace">{lang my_trace}</a></li>
							<li{$a_actives[blacklist]}><a href="home.php?mod=space&do=friend&view=blacklist">{lang my_blacklist}</a></li>
						</ul>
					</div>
					
					<div class="tbmu cl bz-p10">
						<!--{if $_GET['view']=='blacklist'}-->
							{lang blacklist_message}
						<!--{elseif $_GET['view']=='me'}-->
							<p class="y">
								{lang count_member}
							<!--{if $maxfriendnum}-->
								({lang max_friend_num})
								<!--{if $_G['setting']['magicstatus'] && $_G[setting][magics][friendnum]}-->
									<img src="{STATICURL}image/magic/friendnum.small.gif" alt="friendnum" class="vm" />
									{lang expansion_friend}
								<!--{/if}-->
							<!--{/if}-->
							</p>
							<p class="z">{lang friend_message}</p>
						<!--{elseif $_GET['view']=='online'}-->
							<!--{if $_GET['type'] == 'friend'}-->
								{lang online_friend_visit}
							<!--{elseif $_GET['type']=='near'}-->
								{lang near_friend_visit}
							<!--{else}-->
								{lang view_online_friend}
							<!--{/if}-->
						<!--{elseif $_GET['view']=='visitor'}-->
							{lang visitor_list}
						<!--{elseif $_GET['view']=='trace'}-->
							{lang trace_list}
						<!--{/if}-->
					</div>
	
					<!--{if $_GET['view']=='blacklist'}-->
					<h2 class="bz-p10">{lang add_blacklist}</h2>
					<div class="bz-p10 bz-bg-fff cl">
						<form method="post" autocomplete="off" name="blackform" action="home.php?mod=spacecp&ac=friend&op=blacklist&start=$_GET[start]">
							<table cellpadding="0" cellspacing="0" class="tfm">
								<tr>
									<th>{lang username}</th>
									<td>
										<input type="text" name="username" value="" size="15" class="px vm" />
										<button type="submit" name="blacklistsubmit_btn" id="moodsubmit_btn" value="true" class="pn vm"><em>{lang add}</em></button>
									</td>
								</tr>
							</table>
							<input type="hidden" name="blacklistsubmit" value="true" />
							<input type="hidden" name="formhash" value="{FORMHASH}" />
						</form>
					</div>
					<!--{/if}-->
					
				<!--{/if}-->
	
	
	
<!--{else}-->



				<!--{if $_G[setting][homepagestyle]}-->
					<!--{subtemplate home/space_header}-->
					<div id="ct" class="ct2 wp cl">
						<div class="mn">
							<div class="bm">
								<div class="bm_h">
									<h1 class="mt">{lang friends}</h1>
								</div>
							<div class="bm_c">
				<!--{else}-->
					<!--{template common/header}-->
					<!--{template home/space_menu}-->
					<div id="ct" class="ct1 wp cl">
						<div class="mn">
							<div class="bm bw0">
								<div class="bm_c">
				<!--{/if}-->



<!--{/if}-->




			<!--{if $space[self]}-->
			
			
						<!--{if $groups}-->
							<div class="cl">
								<div>
		
									<!--{if $_G['setting']['my_app_status']}-->
										<script type="text/javascript">
											function my_sync_tip(msg, close_time) {;
												showDialog(msg, 'notice');
											}
											function my_sync_friend() {
												my_sync_tip('{lang syn_friend}', 0);
												var my_scri = document.createElement("script");
												document.getElementsByTagName("head")[0].appendChild(my_scri);
												my_scri.charset = "UTF-8";
												var url = "http://uchome.manyou.com/user/syncFriends";
												my_scri.src = url + "?sId=$_G['setting'][my_siteid]&uUchId=$space[uid]&ts=$_G[timestamp]&key=<!--{eval echo md5($_G['setting'][my_siteid] . $_G['setting'][my_sitekey] . $space[uid] . $_G[timestamp]);}-->";
											}
										</script>
										<div class="bm mtm">
											<div class="bm_h cl">
												<h3>{lang cannot_find_friend}</h3>
											</div>
											<div class="bm_c">
												<p>{lang click_syn}</p>
												<p class="pns mtm hm"><button type="button" onclick="my_sync_friend(); return false;" title="{lang friend_manyou_message}" class="pn"><em>{lang refresh_friend}</em></button></p>
											</div>
										</div>
									<!--{/if}-->
		
		
		                            <!--
									<div class="bm mtm">
										<div class="bm_c">
											<ul class="buddy_group">
												<li{if $_GET['group'] == -1} class="a"{/if}><a href="home.php?mod=space&do=friend&group=-1">{lang all_friends}</a></li>
												<!--{loop $groups $key $value}-->
												<li{$groupselect[$key]}>
													<a href="home.php?mod=spacecp&ac=friend&op=groupignore&group=$key&handlekey=ignorehk_{$key}" id="c_ignore_$key" onclick="showWindow('ignoregroup', this.href, 'get', 0);" title="{lang ignore_group_feed}" class="b"><!--{if isset($space['privacy']['filter_gid'][$key])}-->{lang cancel}<!--{else}-->{lang shield}<!--{/if}--></a>
													<!--{if $key}-->
														<a href="home.php?mod=spacecp&ac=friend&op=groupname&group=$key&handlekey=edithk_{$key}" id="c_edit_$key" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang edit_group_name}" class="o">{lang edit}</a>
													<!--{/if}-->
													<a href="home.php?mod=space&do=friend&group=$key" id="friend_groupname_$key" groupname="$value"><!--{if isset($space['privacy']['filter_gid'][$key])}--><span class="xg1">[{lang shield}]</span><!--{/if}-->$value</a>
												</li>
												<!--{/loop}-->
											</ul>
										</div>
									</div>
									<script type="text/javascript">
										function succeedhandle_ignoregroup(url, msg, values) {
											var liObj = $('friend_groupname_'+values['group']);
											var prefix = '';
											if(values['ignore']) {
												prefix = '<span class="xg1">[{lang shield}]</span>';
											}
											$('c_ignore_'+values['group']).innerHTML = values['ignore'] ? '{lang cancel}' : '{lang shield}';
											liObj.innerHTML = prefix + liObj.getAttribute('groupname');
										}
									</script>
								    -->
								
								
								</div>
							<div>	
						<!--{/if}-->
				
						<!--{if $list}-->
						
							<div id="friend_ul" class="bz-p10 banzhuan-clear bz-bg-fff bz-fe-list">
								<ul class="buddy cl 111">
								<!--{loop $list $key $value}-->
								
									<li id="friend_{$value[uid]}_li" class="cl">
										
									<!--{if $value[username] == ''}-->
										<div class="avt"><img src="{STATICURL}image/magic/hidden.gif" alt="{lang anonymity}" /></div>
										<h4>{lang anonymity}</h4>
									<!--{else}-->
										<div class="z avt">
											<a href="home.php?mod=space&uid=$value[uid]" c="1">
												<!--{if $ols[$value[uid]]}--><em class="gol" title="{lang online} {date($ols[$value[uid]], 'H:i')}"></em><!--{/if}-->
												<!--{avatar($value[uid],middle)}-->
											</a>
										</div>
										<div class="z ntbody">
											<div style="margin-left: 10px;">
												<p>
													<span class="y">
													<!--{if $_GET['view'] == 'blacklist'}-->
														<a href="home.php?mod=spacecp&ac=friend&op=blacklist&subop=delete&uid=$value[uid]&start=$_GET[start]">{lang delete_blacklist}</a>
													<!--{elseif $_GET['view'] == 'visitor' || $_GET['view'] == 'trace'}-->
														<!--{date($value[dateline], 'n{lang month}j{lang day}')}-->
													<!--{elseif $_GET['view'] == 'online'}-->
														<!--{date($ols[$value[uid]], 'H:i')}-->
													<!--{else}-->
														<a href="home.php?mod=spacecp&ac=friend&op=changenum&uid=$value[uid]&handlekey=hotuserhk_{$value[uid]}" id="friendnum_$value[uid]" onclick="showWindow(this.id, this.href, 'get', 0);" class="color-b">{lang hot}(<span id="spannum_$value[uid]">$value[num]</span>)</a>
													<!--{/if}-->
													</span>
													<a href="home.php?mod=space&uid=$value[uid]"{eval g_color($value[groupid]);}>$value[username]</a>
													<!--{eval g_icon($value[groupid]);}-->
													<!--{if $value['videostatus']}-->
														<img src="{IMGDIR}/videophoto.gif" alt="videophoto" class="vm" />
													<!--{/if}-->
													<!--{if $space[self]}-->
													<!--{/if}-->
												</p>
												<p class="a">
													<!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != ''}-->
														<a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&fuid=$value[uid]&hash={FORMHASH}&from=a_followmod_" id="a_followmod_$key" onclick="showWindow('followmod', this.href, 'get', 0)"><!--{if $value['follow']}-->{lang follow_del}<!--{else}-->{lang follow_add}TA<!--{/if}--></a>
													<!--{/if}-->
												</p>
											</div>
										</div>
									<!--{/if}-->
									
											
										
									</li>
									
								<!--{/loop}-->
								</ul>
							</div>
							
							<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
							
						<!--{else}-->
						
		                	<!--{if $_GET['view'] == 'me' && !$friendnum}-->
		                	
			                    	<!--{if $specialuser_list}-->
			                            <div id="friend_ul">
			                            	<h2 class="mtw">{lang recommend_friend}</h2>
			                                <ul class="buddy cl 222">
			                                	<!--{loop $specialuser_list $key $value}-->
			                                    	<li id="friend_{$value[uid]}_li">
			                                        	<div class="avt">
			                                                <a href="home.php?mod=space&uid=$value[uid]" c="1">
			                                                    <!--{if $ols[$value[uid]]}--><em class="gol" title="{lang online} {date($ols[$value[uid]], 'H:i')}"></em><!--{/if}-->
			                                                    <!--{avatar($value[uid],small)}-->
			                                                </a>
			                                            </div>
			                                            <h4>
			                                                <a href="home.php?mod=space&uid=$value[uid]">$value[username]</a>
			                                            </h4>
			                                            <p class="maxh">$value[reason]</p>
			                                            <div class="xg1">
			                                            <!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != ''}-->
														<a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&fuid=$value[uid]&hash={FORMHASH}&from=a_specialuser_" id="a_specialuser_$key" onclick="showWindow('followmod', this.href, 'get', 0)"><!--{if $value['follow']}-->{lang follow_del}<!--{else}-->{lang follow_add}TA<!--{/if}--></a>
														<span class="pipe">|</span>
														<!--{/if}-->
														<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=adduserhk_{$value[uid]}" id="a_friend_$key" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang add_friend}">{lang add_friend}</a></div>
			                                        </li>
			                                    <!--{/loop}-->
			                                </ul>
			                            </div>
			                        <!--{/if}-->
			                        <!--{if $online_list}-->
			                        	<div id="friend_ul">
			                            	<h2 class="mtw">{lang online_member}</h2>
			                                <ul class="buddy cl 333">
			                                	<!--{loop $online_list $key $value}-->
			                                    	<li id="friend_{$value[uid]}_li">
			                                        	<div class="avt">
			                                                <a href="home.php?mod=space&uid=$value[uid]" c="1">
			                                                    <!--{if $ols[$value[uid]]}--><em class="gol" title="{lang online} {date($ols[$value[uid]], 'H:i')}"></em><!--{/if}-->
			                                                    <!--{avatar($value[uid],small)}-->
			                                                </a>
			                                            </div>
			                                            <h4>
			                                                <a href="home.php?mod=space&uid=$value[uid]">$value[username]</a>
			                                            </h4>
			                                            <p class="maxh">$value[recentnote]</p>
			                                            <div class="xg1">
			                                            <!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != '' && helper_access::check_module('follow')}-->
														<a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&fuid=$value[uid]&hash={FORMHASH}&from=a_online_" id="a_online_$key" onclick="showWindow('followmod', this.href, 'get', 0)"><!--{if $value['follow']}-->{lang follow_del}<!--{else}-->{lang follow_add}TA<!--{/if}--></a>
														<span class="pipe">|</span>
														<!--{/if}-->
														<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=adduserhk_{$value[uid]}" id="a_friend_$key" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang add_friend}">{lang add_friend}</a></div>
			                                        </li>
			                                    <!--{/loop}-->
			                                </ul>
			                            </div>
			                        <!--{/if}-->
		                        
		                    <!--{else}-->
		                    
			                    <div class="guide-no">
									<p class="iconfont icon-quxiaoguanzhu color-b" style="font-size: 50px;"></p>
									<p class="color-b">{lang no_friend_list}</p>
								</div>
								
		                    <!--{/if}-->
		                    
						<!--{/if}-->
						
						<script type="text/javascript">
							function succeedhandle_followmod(url, msg, values) {
								var fObj = $(values['from']+values['fuid']);
								if(values['type'] == 'add') {
									fObj.innerHTML = '{lang follow_del}';
									fObj.className = 'flw_btn_unfo';
									fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid']+'&from='+values['from'];
								} else if(values['type'] == 'del') {
									fObj.innerHTML = '{lang follow_add}TA';
									fObj.className = 'flw_btn_fo';
									fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid']+'&from='+values['from'];
								}
							}
						</script>
				<!--{if $groups}-->
						</div>
					</div>
				<!--{/if}-->
				
			<!--{else}-->
			
				<p class="tbmu">{lang count_member}</p>
				<!--{template home/space_list}-->
				
			<!--{/if}-->
			
<!--{if empty($diymode)}-->
</div>
	</div>
	
</div>

<!--{else}-->

		</div>
	</div>
</div>
	
	<!--{if $_G[setting][homepagestyle]}-->
	<div class="sd">
			<!--{subtemplate home/space_userabout}-->
	</div>
	<!--{/if}-->
	
<!--{/if}-->

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

