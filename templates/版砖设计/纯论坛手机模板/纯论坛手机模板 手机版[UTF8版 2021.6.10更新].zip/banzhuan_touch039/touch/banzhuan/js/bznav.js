$(function () {

    var left = $('.bzleft');
    var right = $('.bzright');
    var down = $('.bzdown');
    var up = $('.bzup');
    var bg = $('.bgDiv');
    var leftNav = $('.leftNav');
    var rightNav = $('.rightNav');
    var downNav = $('.downNav');
    var upNav = $('.upNav');

    showNav(left, leftNav, "bzleft");
    showNav(right, rightNav, "bzright");
    showNav(up, upNav, "bzup");
    showNav(down, downNav, "bzdown");

    function showNav(btn, navDiv, direction) {
        btn.on('click', function () {
            bg.css({
                display: "block",
                transition: "opacity .5s"
            });
            if (direction == "bzright") {
                navDiv.css({
                    right: "0px",
                    transition: "right 0.5s"
                });
            } else if (direction == "bzleft") {
                navDiv.css({
                    left: "0px",
                    transition: "left 0.5s"
                });
            } else if (direction == "bzup") {
                navDiv.css({
                    top: "0px",
                    transition: "top 0.5s"
                });
            } else if (direction == "bzdown") {
                navDiv.css({
                    bottom: "0px",
                    transition: "bottom 0.5s"
                });
            }


        });
    }


    bg.on('click', function () {
        hideNav();
    });

    function hideNav() {
        leftNav.css({
            left: "-60%",
            transition: "left .5s"
        });
        rightNav.css({
            right: "-60%",
            transition: "right .5s"
        });
        upNav.css({
            top: "-70%",
            transition: "top .5s"
        });
        downNav.css({
            bottom: "-50%",
            webkitTransition:"bottom .5s",
            oTransition:"bottom .5s",
            mozTransition:"bottom .5s",
            transition: "bottom .5s"
        });
        bg.css({
            display: "none",
            transition: "display 1s"
        });
    }
});


$(document).ready(function() {
    $('#stylelist b').on('click',function(){
		$(this).addClass('cover').siblings().removeClass("cover");
		var css = $(this).attr('data-id');
		$('#css_extstyle').attr('href', css ? css + '/style.css' : './template/banzhuan_touch039/style/t1/style.css');
		setcookie('extstyle', css, 86400 * 30);
	});
});

