<?php echo 'From: DisM.taobao.com';exit;?>
<div class="threadlist bz-mtb10">
	<!--{if empty($threadlist)}-->
	<ul class="bzbt1 bzbb1 bz-bg-fff hm"><li class="b_p"><a class="grey">{lang search_nomatch}</a></li></ul>
	<!--{else}-->
	<ul class="bzbt1 bz-bg-fff">
		<!--{loop $threadlist $thread}-->
		<li> 
            <div class="bz-fd-card">
                <header class="bzfdtlh">
		            <div class="bzfdtlh-left">
				        <!--{if !$thread[author]}-->
		              	<a class="avatar">{avatar($thread[0],middle)}</a>
		              	<!--{else}-->
		              	<a class="avatar" href="home.php?mod=space&uid=$thread[authorid]&do=profile">{avatar($thread[authorid],middle)}</a>
		              	<!--{/if}-->
				    </div>
				    	<div class="bzfdtlh-middle">
					    <div class="name">
							<!--{if !$thread[author]}-->
							<a class="blue">{lang anonymous}{lang guest}</a>
							<!--{else}-->
							<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="blue">$thread[author]</a>
								<!--{if !empty($verify[$thread['authorid']])}-->
									$verify[$thread[authorid]]
								<!--{/if}-->
							<!--{/if}-->
							<!--{eval $thread[agroupid] = DB::result_first('SELECT groupid FROM '.DB::table('common_member').' WHERE uid='.$thread[authorid].'')}-->
							<!--{if $thread[agroupid]}-->
								<!--{eval $thread[astars] = DB::result_first('SELECT stars FROM '.DB::table('common_usergroup').' WHERE groupid='.$thread[agroupid].'')}-->
							<!--{else}-->
								<!--{eval $thread[astars] = 0}-->
							<!--{/if}-->
							<!--{if !$thread[author]}-->
							<!--{else}-->
								<!--{if $thread[astars]}--><span class="name-lv"> Lv.$thread['astars']</span><!--{/if}-->
							<!--{/if}-->
					    </div>
					    <div class="data">
					   		<span class="color-c fz12">$thread[dateline] </span>
							<!--{if $thread['special'] == 1}-->
							<span class="name-a name-b">{lang thread_poll}</span>
							<!--{elseif $thread['special'] == 2}-->
							<span class="name-a name-b">{lang thread_trade}</span>
							<!--{elseif $thread['special'] == 3}-->
							<span class="name-a name-b">{lang thread_reward}</span>
							<!--{elseif $thread['special'] == 4}-->
							<span class="name-a name-b">{lang thread_activity}</span>
							<!--{elseif $thread['special'] == 5}-->
							<span class="name-a name-b">{lang thread_debate}</span>
							<!--{/if}-->
							<!--{if $thread['digest'] > 0 }-->
							<span class="name-a">{lang thread_digest}$thread[digest]</span>
							<!--{/if}-->
							<span class="y color-c"><i class="iconfont icon-attention fz12"></i><em>$thread[views]</em></span>
							<!--{if $thread[replies] > 0}--><span class="y color-c"><i class="iconfont icon-message fz12"></i><em>{$thread[replies]}</em><i class="color-b fz12 i"> / </i></span><!--{/if}-->
							<!--{if $thread[recommendicon] && $filter != 'recommend'}--><span class="y color-c"><i class="iconfont icon-appreciatelight fz12"></i><em>$thread[recommends]</em><i class="color-b fz12 i"> / </i></span><!--{/if}-->
							<!--{if $thread[heatlevel]}--><span class="y color-c"><!--{if $_GET['orderby'] == 'heats' }--><i class="iconfont icon-hotfill fz12 color-red"></i><!--{else}--><i class="iconfont icon-hot fz12"></i><!--{/if}--><em>{$thread[heats]}</em><i class="color-b fz12 i"> / </i></span><!--{/if}-->
					    </div>
				    </div>
                </header>
				<section class="bzfdtld" style="padding-bottom: 20px;">
                    <a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]">
                        <h2><span $thread[highlight]>$thread[subject]</span></h2>
               	   </a>
                </section>
             </div>
        </li>
		<!--{/loop}-->
	</ul>
	<!--{/if}-->
	$multipage
</div>

