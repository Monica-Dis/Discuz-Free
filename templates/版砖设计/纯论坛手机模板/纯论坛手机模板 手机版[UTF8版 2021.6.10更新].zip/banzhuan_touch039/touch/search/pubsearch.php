<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="{lang enter_content}...">
<input type="hidden" name="searchsubmit" value="yes">

