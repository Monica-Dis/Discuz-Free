<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="bz-header">
	<div class="bz-header-left"><a href="javascript:history.back();" class="iconfont icon-fanhui"></a></div>
	<h2>
		<ul>
			<li class="a"><a href="search.php?mod=forum&mobile=2">{lang thread}</a></li>
			<li><a href="home.php?mod=spacecp&ac=search&mobile=2">{lang users}</a></li>
		</ul>
	</h2>
	<div class="bz-header-right"><a href="forum.php" class="iconfont icon-home"></a></div>
</div>
<div class="bz_search bz-bg-fff bzbb1">
	<ul>
		<li>
			<a>
			<em class="iconfont icon-search4"></em>
		    <form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<!--{subtemplate search/pubsearch}-->
				<!--{eval $policymsgs = $p = '';}-->
				<!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
				<!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
				<!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
				<!--{/loop}-->
				<!--{if $policymsgs}--><p>{lang search_credit_msg}</p><!--{/if}-->
			 </form>
			</a>
		</li>
	</ul>
</div>
<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
	<!--{subtemplate search/thread_list}-->
<!--{/if}-->
<!--{if $_GET['searchsubmit'] !== 'yes'}-->
	<!--{if $_G['setting']['srchhotkeywords']}-->
	<div class="search-hot bz-plr10 bz-mtb10 bz-bg-fff bzbt1">
		<div id="scbar_hot" class="bz-pt10">
			<div class="tab-title bzbb1 color-c bz-ptb10">
				<a class="iconfont icon-hot">&nbsp;{lang hot_search}</a>
			</div>
			<div class="scbar-hot-title">
				<ul>
					<!--{loop $_G['setting']['srchhotkeywords'] $val}-->
					<!--{if $val=trim($val)}-->
					<!--{eval $valenc=rawurlencode($val);}-->
					<!--{block srchhotkeywords[]}-->
					<!--{if !empty($searchparams[url])}-->
					<li class="bz-ptb10 bzbb1"><a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}" sc="1">$val</a></li>
					<!--{else}-->
					<li class="bz-ptb10 bzbb1"><a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch" sc="1">$val</a></li>
					<!--{/if}-->
					<!--{/block}-->
					<!--{/if}-->
					<!--{/loop}-->
					<!--{echo implode('', $srchhotkeywords);}-->
				</ul>
			</div>
		</div>
	</div>
	<!--{/if}-->
<!--{/if}-->

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->


