<?php echo 'From: DisM.taobao.com';exit;?>
<div class="bz-sorttype cl">
    <div id="bz-sorttype">
		<ul>
			<li class="{if $_GET['op'] == 'base'}a{/if}"><a href="home.php?mod=spacecp&ac=credit&op=base">{lang my_credits}</a></li>
			<li class="{if $_GET['op'] == 'log'}a{/if}"><a href="home.php?mod=spacecp&ac=credit&op=log&suboperation=creditrulelog">{lang memcp_credits_log}</a></li>
			<li class="{if $_GET['op'] == 'rule'}a{/if}"><a href="home.php?mod=spacecp&ac=credit&op=rule">{lang credit_rule}</a></li>
				
			<!--{if $_G[setting][ec_ratio] && ($_G[setting][ec_account] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_tenpay_bargainor]) || $_G['setting']['card']['open']}-->
			<li class="{if $_GET['op'] == 'buy'}a{/if}"><a href="home.php?mod=spacecp&ac=credit&op=buy">{lang buy_credits}</a></li>
			<!--{/if}-->
			<!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
			<li class="{if $_GET['op'] == 'transfer'}a{/if}"><a href="home.php?mod=spacecp&ac=credit&op=transfer">{lang transfer_credits}</a></li>
			<!--{/if}-->
			<!--{if $_G[setting][exchangestatus]}-->
			<li class="{if $_GET['op'] == 'exchange'}a{/if}"><a href="home.php?mod=spacecp&ac=credit&op=exchange">{lang exchange_credits}</a></li>
			<!--{/if}-->
			
			<!--{if !empty($_G['setting']['plugins']['spacecp_credit'])}-->
				<!--{loop $_G['setting']['plugins']['spacecp_credit'] $id $module}-->
					<!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}--><li class="{if $_GET[id] == $id}a{/if}"><a href="home.php?mod=spacecp&ac=plugin&op=credit&id=$id">$module[name]</a></li><!--{/if}-->
				<!--{/loop}-->
			<!--{/if}-->
		</ul>
    </div>
</div>

<!--{if $op == 'rule'}-->
<div class="b_m credit_rule">
	<select onchange="location.href='home.php?mod=spacecp&ac=credit&op=rule&fid='+this.value"><option value="">{lang credit_rule_global}</option>$select</select>
</div>
<!--{/if}-->

