<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="loginbox registerbox">
	<div class="login_from">
	<form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}&mobile=2">
		<input type="hidden" name="regsubmit" value="yes" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
		<input type="hidden" name="referer" value="$dreferer" />
		<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
		<input type="hidden" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
		<!--{if $_G['setting']['sendregisterurl']}-->
		<input type="hidden" name="hash" value="$_GET[hash]" />
		<!--{/if}-->
		<ul>
			<!--{if $sendurl}-->
			<li><input type="email" tabindex="1" class="bz-input" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail} *" fwin="login"></li>
			<!--{else}-->
				<li><input type="text" tabindex="1" class="bz-input" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip} *" fwin="login"></li>
				<li><input type="password" tabindex="2" class="bz-input" size="30" value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password} *" fwin="login"></li>
				<li><input type="password" tabindex="3" class="bz-input" size="30" value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2} *" fwin="login"></li>
				<li class="bl_none"><input type="email" tabindex="4" class="bz-input" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail} *" fwin="login"></li>
				<!--{if empty($invite) && ($_G['setting']['regstatus'] == 2 || $_G['setting']['regstatus'] == 3)}-->
				<li><input type="text" name="invitecode" autocomplete="off" tabindex="5" class="bz-input" size="30" value="" placeholder="{lang invite_code} *" fwin="login"></li>
				<!--{/if}-->
				<!--{if $_G['setting']['regverify'] == 2}-->
				<li><input type="text" name="regmessage" autocomplete="off" tabindex="6" class="bz-input" size="30" value="" placeholder="{lang register_message} *" fwin="login"></li>
				<!--{/if}-->
				<!--{loop $_G['cache']['fields_register'] $field}-->
					<!--{if $htmls[$field['fieldid']]}-->
					<li class="diy"><span>$field[title]<!--{if $field['required']}--> *<!--{/if}--></span>$htmls[$field['fieldid']]</li>
					<!--{/if}-->
				<!--{/loop}-->
			<!--{/if}-->
		</ul>
		<!--{if $secqaacheck || $seccodecheck}-->
			<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
	</div>
	<p class="mbw cl b_plr10">
		<!--{if $bbrules}-->
		<input type="checkbox" class="pc" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" /><label for="agreebbrule" class="grey">{lang agree}<a href="#BzBBRules" class="blue BzBBRules"> {lang rulemessage}</a></label>
		<!--{/if}-->
		<input type="reset" value="{lang reset}" class="y grey bz_reset" />
	</p>
	<div class="btn_register"><button tabindex="7" value="true" name="regsubmit" type="submit" class="formdialog pn"><span>{lang quickregister}</span></button></div>
	</form>
	<p class="reg_link hm">
		<a href="member.php?mod=logging&action=login" class="grey">{lang login}</a>
	</p>
</div>

<!--{if $bbrules}-->

<div id="BzBBRules" class="BzBBRules" style="display: none;">
    <div class="BzBBRulesBox">
    		<h2 class="hm">{lang rulemessage}</h2>
   	 	<div class="BzBBRulesBoxTxt">
   	 		$bbrulestxt
   	 	</div>
    </div>
    <div href="#BzBBRules" class="BzBBRulesMask MaskBg"></div>
	<div href="#BzBBRules" class="BzBBRulesClose blue">{lang agree}</div>
</div>
<script type="text/javascript">
	(function() {
		$('.BzBBRules').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
			} else {
				subobj.css('display', 'none');
			}
		});
	 })();
	 (function() {
		$('.BzBBRulesMask').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
			} else {
				subobj.css('display', 'none');
			}
		});
	 })();
	 (function() {
		$('.BzBBRulesClose').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
			} else {
				subobj.css('display', 'none');
			}
		});
	 })();
</script>

<!--{/if}-->

<div class="bz_bottom"></div>
<div id="footbar">
    <div class="fbc">
        <ul>
            <li><a href="forum.php?forumlist=1&mobile=2" class="iconfont icon-home-o"><span>$_G['setting']['sitename']</span></a></li>
            <li class="a"><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}" class="iconfont icon-yonghu"><span>{lang myitem}</span><!--{if $_G[member][newpm]}--><i class="iconfont icon-dian1"></i><!--{/if}--></a></li>
        </ul>
    </div>
</div>

<!--{eval updatesession();}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

