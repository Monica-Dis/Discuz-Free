<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<!--{if $_G['setting']['domain']['app']['mobile']}-->
	{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
<!--{else}-->
	{eval $nav = "forum.php";}
<!--{/if}-->

<div class="bz-in-sehot">
	<ul>
		<li class="bz-bg-fff">
			<a>
				<em class="iconfont icon-search1"></em>
			    <form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<!--{if !empty($srchtype)}-->
					<input type="hidden" name="srchtype" value="$srchtype" />
					<!--{/if}-->
					<input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="{lang search}&#24863;&#20852;&#36259;&#30340;{lang thread_content}">
					<input type="hidden" name="searchsubmit" value="yes">
					<input type="submit" value="{lang search}" id="scform_submit" style="display: none;">
					<!--{eval $policymsgs = $p = '';}-->
					<!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
					<!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
					<!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
					<!--{/loop}-->
				 </form>
			</a>
		</li>
		<!--{if $policymsgs}-->
		<p class="fz12 grey hm b_p5">{lang search_credit_msg}</p>
		<!--{/if}-->
	</ul>
</div>


<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
	<!--{subtemplate search/thread_list}-->
<!--{/if}-->
<!--{if $_GET['searchsubmit'] !== 'yes'}-->
	<!--{if $_G['setting']['srchhotkeywords']}-->
	<div class="search-hot b_p">
		<div class="hot-title">
			<!--{loop $_G['setting']['srchhotkeywords'] $val}-->
			<!--{if $val=trim($val)}-->
			<!--{eval $valenc=rawurlencode($val);}-->
			<!--{block srchhotkeywords[]}-->
			<!--{if !empty($searchparams[url])}-->
			<a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}" sc="1">$val</a>
			<!--{else}-->
			<a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch" sc="1">$val</a>
			<!--{/if}-->
			<!--{/block}-->
			<!--{/if}-->
			<!--{/loop}-->
			<!--{echo implode('', $srchhotkeywords);}-->
		</div>
	</div>
	<!--{/if}-->
<!--{/if}-->

<div class="bz_bottom"></div>
<div id="footbar">
    <div class="fbc">
        <ul>
            <li><a href="forum.php?forumlist=1&mobile=2" class="iconfont icon-home-o"><span>$_G['setting']['sitename']</span></a></li>
            <li><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}" class="iconfont icon-yonghu-xianxing"><span>{lang myitem}</span><!--{if $_G[member][newpm]}--><i class="iconfont icon-dian1"></i><!--{/if}--></a></li>
        </ul>
    </div>
</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

