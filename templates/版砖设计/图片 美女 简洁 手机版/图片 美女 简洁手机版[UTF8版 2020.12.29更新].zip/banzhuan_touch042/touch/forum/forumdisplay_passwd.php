<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<div class="b_p15 cl">
	<div class="bz_passwd">
		<div class="hm">
			<p class="grey fz14">&#26412;&#29256;&#22359;&#38656;&#35201;&#23494;&#30721;&#25165;&#21487;&#20197;&#35775;&#38382;</p>
			<p class="grey fz14">&#35831;&#22312;&#19979;&#26041;&#36755;&#20837;&#23494;&#30721;</p>
		</div>
		<div class="b_p15 hm mtw">
			<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=pwverify">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="password" name="pw" class="bz_passwd_px" placeholder="&#35831;&#36755;&#20837;&#23494;&#30721;" />
				<div class="mtw btn-big">
					<button class="touch" type="submit" name="loginsubmit" value="true">{lang submit}</button>
				</div>
				<div class="mtw mbw btn-big-bor">
					<button class="touch" type="button" onclick="history.go(-1)">{lang cancel}</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!--{hook/forumdisplay_bottom_mobile}-->

<div id="footbar">
    <div class="fbc">
        <ul>
            <li class="a"><a href="forum.php?forumlist=1&mobile=2" class="iconfont icon-home1"><span>$_G['setting']['sitename']</span></a></li>
            <li><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}" class="iconfont icon-yonghu-xianxing"><span>{lang myitem}</span><!--{if $_G[member][newpm]}--><i class="iconfont icon-dian1"></i><!--{/if}--></a></li>
        </ul>
    </div>
</div>
<!--{template common/footer}-->
