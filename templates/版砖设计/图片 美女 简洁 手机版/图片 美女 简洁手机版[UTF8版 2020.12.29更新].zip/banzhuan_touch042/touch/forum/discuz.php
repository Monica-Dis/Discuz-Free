<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:forum.php?forumlist=1');exit;}-->
<!--{/if}-->
<!--{template common/header}-->

<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<!--{if $_GET['visitclient']}-->

<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->

<!--{if $showvisitclient}-->
<div class="visitclienttip vm" style="display:block;">
	<a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>	
	<p>{lang downloadzslttoshareview}</p>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
		$('.visitclienttip').css('display', 'block');
	}
</script>
<!--{/if}-->

<!--{if $_G['setting']['domain']['app']['mobile']}-->
	{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
<!--{else}-->
	{eval $nav = "forum.php";}
<!--{/if}-->

<!--{hook/index_top_mobile}-->

<div class="bz-in-logo bz-bg-fff hm">
	<img src="template/banzhuan_touch042/touch/abz/logo.png" />
</div>

<div class="bz-in-sehot bz-bg-fff">
	<ul>
		<li>
			<a>
				<em class="iconfont icon-search1"></em>
			    <form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<!--{if !empty($srchtype)}-->
					<input type="hidden" name="srchtype" value="$srchtype" />
					<!--{/if}-->
					<input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="{lang search}{lang all}{lang thread_content}">
					<input type="hidden" name="searchsubmit" value="yes">
					<input type="submit" value="{lang search}" id="scform_submit" style="display: none;">
					<!--{eval $policymsgs = $p = '';}-->
					<!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
					<!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
					<!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
					<!--{/loop}-->
					<!--{if $policymsgs}-->
					<p>{lang search_credit_msg}</p>
					<!--{/if}-->
				 </form>
			</a>
		</li>
		
	</ul>
</div>

<div class="bz-bg-fff">
	<div class="clear" style="overflow: hidden;">
		<div class="sub_forum">
			<ul>
			<!--{loop $catlist $key $cat}-->
			<!--{loop $cat[forums] $forumid}-->
			<!--{eval $forum=$forumlist[$forumid];}-->
			<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
			<li>
				<div class="name-pic">
		            <!--{if $forum[icon]}-->
		                {$forum[icon]}
		            <!--{else}-->
		                <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"></a>
		            <!--{/if}-->
			    </div>
			    <div class="mcover">
		            	<div class="name-tit">
		            		<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
		            			<div style="height: 50px;position: relative;">
		            				<div style="position: absolute;bottom: 15px;width: 100%;"><span>{$forum[name]}</span></div>
		            	        	</div>
		            	    </a>
		            	</div>
		        	</div>
			</li>
			<!--{/loop}-->
			<!--{/loop}-->
			</ul>
		</div>
	</div>
</div>

<div class="bz-bg-fff b_p cl bzbb1">
<!--{template abz/diy}-->
</div>

<!--{if empty($gid) && ($_G['cache']['forumlinks'][0] || $_G['cache']['forumlinks'][1] || $_G['cache']['forumlinks'][2])}-->
<div class="mtm clear">
	<div class="hm b_p15 bzbt1 bz-bg-fff" style="font-size: 18px;font-family: STLiti;">&#21451;&#24773;{lang link}</div>
	<div id="category_lk" class="bzbb1">
		<!--{if $_G['cache']['forumlinks'][0]}-->
		<ul class="m cl 0">$_G['cache']['forumlinks'][0]</ul>
		<!--{/if}-->
		<!--{if $_G['cache']['forumlinks'][1]}-->
		<div class="n cl 1">
			$_G['cache']['forumlinks'][1]
		</div>
		<!--{/if}-->
		<!--{if $_G['cache']['forumlinks'][2]}-->
		<ul class="x cl 2">
			$_G['cache']['forumlinks'][2]
		</ul>
		<!--{/if}-->
	</div>
</div>
<!--{/if}-->

<!--{hook/index_middle_mobile}-->

<!--{/if}-->

<div id="footbar">
    <div class="fbc">
        <ul>
            <li class="a"><a href="forum.php?forumlist=1&mobile=2" class="iconfont icon-home1"><span>$_G['setting']['sitename']</span></a></li>
            <li><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}" class="iconfont icon-yonghu-xianxing"><span>{lang myitem}</span><!--{if $_G[member][newpm]}--><i class="iconfont icon-dian1"></i><!--{/if}--></a></li>
        </ul>
    </div>
</div>

<!--{template common/footer}-->

