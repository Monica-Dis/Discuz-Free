<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<div class="cl banzhuan-debate bg b_p15 mtw mbw">
	<div class="hm mtw">$_G[forum_thread][subject]</div>
	<!--{if $debate[endtime]}-->
	<div class="grey fz12 cl hm">{lang endtime}: $debate[endtime] <!--{if $debate[umpire]}-->{lang debate_umpire}: $debate[umpire]<!--{/if}--></div>
	<!--{/if}-->
	<div class="mtw mbw cl">
	    <div class="z bz-bg-fff" style="width: 48%;">
		    	<div class="b_p">
		    		<div class="hm mtw mbw">{lang debate_square_point}</div>
		        <p class="mbw">" $debate[affirmpoint] "</p>
		        <div class="grey fz12 cl">{lang debate_support}: $debate[affirmvotes] &#20154;</div>
		        <!--{if $debate[affirmdebaters] > 0 }-->
		        <div class="grey fz12 cl mbw">{lang debater}: <!--{loop $debate[affirmavatars] $user}--><a href="home.php?mod=space&uid=$user[authorid]" class="blue">$user[author] </a><!--{/if}--></div>
		        <!--{/if}-->
		        <!--{if !$_G['forum_thread']['is_archived']}-->
		        <div class="clear"></div>
		        <div class="mtw mbw btn-big">
					 <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" id="affirmbutton" class="touch">{lang debate_support}</a>
				</div>
				<!--{/if}-->
		    </div>
	    	</div>
	    <div class="y bz-bg-fff" style="width: 48%;">
		    	<div class="b_p">
		    		<div class="hm mtw mbw">{lang debate_opponent_point}</div>
		        <p class="mbw">" $debate[negapoint] "</p>
		        <div class="grey fz12 cl">{lang debate_support}: $debate[negavotes] &#20154;</div>
		        <!--{if $debate[negadebaters] > 0 }-->
		        <div class="grey fz12 cl mbw">{lang debater}: <!--{loop $debate[negaavatars] $user}--><a href="home.php?mod=space&uid=$user[authorid]" class="blue">$user[author] </a><!--{/if}--></div>
		        <!--{/if}-->
		        <div class="clear"></div>
		        <div class="mtw mbw btn-big">
					<a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" id="negabutton" class="touch">{lang debate_support}</a>
				</div>
		    </div>
	    </div>
    </div>
	<!--{if $debate[umpire] && $_G['username'] && $debate[umpire] == $_G['member']['username']}-->
	<div class="clear"></div>
	<div class="mtw mbw grey fz12 cl hm">
		<p>{lang mobile2version}&#26242;&#19981;{lang debate_support} " {lang debate_umpire_end}/{lang debate_umpirepoint_edit} "</p>
		<p>&#35831;&#20351;&#29992;{lang nomobiletype}{lang manage}{lang thread_debate}&#20027;&#39064;</p>
	</div>
	<!--{/if}-->
</div>

<!--{if $debate[umpire]}-->
	<!--{if $debate['umpirepoint']}-->
	<div class="cl banzhuan-debate bg b_p15 mtw mbw">
		<div class="hm mtw">
		<!--{if $debate[winner]}-->
			<!--{if $debate[winner] == 1}-->{lang debate_square}{lang debate_winner}<!--{elseif $debate[winner] == 2}-->{lang debate_opponent}{lang debate_winner}<!--{else}-->{lang debate_draw}<!--{/if}-->
		<!--{/if}-->
		</div>
		<div class="grey fz12 cl hm">{lang debate_comment_dateline}: $debate[endtime]</div>
		<!--{if $debate[bestdebater]}-->
		<div class="hm mtw">{lang debate_bestdebater}</div>
		<div class="blue fz12 cl hm">$debate[bestdebater]</div>
		<!--{/if}-->
		<!--{if $debate[umpirepoint]}-->
		<div class="hm mtw">{lang debate_umpirepoint}</div>
		<div class="grey fz12 cl hm mbw">$debate[umpirepoint]</div>
		<!--{/if}-->
	</div>
	<!--{/if}-->
<!--{/if}-->

<div class="clear"></div>
<div id="postmessage_$post[pid]" class="postmessage mtw mbw">$post[message]</div>


