<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<div class="bz-post-reward">
    <!--{if $_GET[action] == 'newthread'}-->
    		<p class="bz-post-reward-p">
	        <label for="rewardprice">{lang reward_price} : </label>
	        <input type="text" name="rewardprice" id="rewardprice" class="txt_s" value="{$_G['group']['minrewardprice']}"  />
		</p>
        <p class="grey">{lang you_have} <em class="color-red"><!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--></em> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</p>
    <!--{elseif $_GET[action] == 'edit'}-->
        <!--{if $isorigauthor}-->
            <!--{if $thread['price'] > 0}-->
                <label for="rewardprice">{lang reward_price} : </label>
                <input type="text" name="rewardprice" id="rewardprice" class="txt_s" size="6" value="$rewardprice"  />
                {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
                ({lang reward_tax_add} <span id="realprice">0</span> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]} , {lang reward_low} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{if $_G['group']['maxrewardprice'] > 0}--> - {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->)
                <p class="grey">{lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</p>
            <!--{else}-->
                {lang post_reward_resolved}
                <input type="hidden" name="rewardprice" value="$rewardprice"  />
            <!--{/if}-->
        <!--{else}-->
            <!--{if $thread['price'] > 0}-->
                {lang reward_price}: $rewardprice {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
            <!--{else}-->
                {lang post_reward_resolved}
            <!--{/if}-->
        <!--{/if}-->
    <!--{/if}-->
    <!--{if $_G['setting']['rewardexpiration'] > 0}-->
        <p class="grey" style="font-style: italic;padding-top: 10px;">$_G['setting']['rewardexpiration']{lang post_reward_message}</p>
    <!--{/if}-->
</div>
