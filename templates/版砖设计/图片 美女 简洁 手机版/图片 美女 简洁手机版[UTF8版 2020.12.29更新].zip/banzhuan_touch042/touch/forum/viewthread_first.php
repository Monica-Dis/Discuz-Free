<?php echo 'From: DisM.taobao.com';exit;?>
<div class="plc cl bz-bg-fff" id="pid$post[pid]">
    <div class="display pi" href="#replybtn_$post[pid]" style="padding: 0 0 10px 0;">
    		
    		<!--{if $post[first]}-->
    		<!--{if $_G['forum_thread']['attachment'] == 2 && $_G['group']['allowgetimage'] && (!$_G['setting']['guestviewthumb']['flag'] || $_G['setting']['guestviewthumb']['flag'] && $_G['uid'])}-->
		<!--<div class="bz_v_bigpic"><a href="forum.php?mod=viewthread&tid=$_G[tid]&from=album" class="grey">{lang view_bigpic}</a></div>-->
		<!--{/if}-->
		<!--{/if}-->
		
		<div class="message bz_message">
			
            	<!--{if $post['warned']}-->
                    <span class="grey quote">{lang warn_get}</span>
                <!--{/if}-->
                <!--{if !$post['first'] && !empty($post[subject])}-->
                    <h2><strong>$post[subject]</strong></h2>
                <!--{/if}-->
                <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                    <div class="grey quote">{lang message_banned}</div>
                <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                    <div class="grey quote">{lang message_single_banned}</div>
                <!--{elseif $needhiddenreply}-->
                    <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
                <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
					<!--{template forum/viewthread_pay}-->
				<!--{else}-->

                	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                        <div class="grey quote">{lang admin_message_banned}</div>
                    <!--{elseif $post['status'] & 1}-->
                        <div class="grey quote">{lang admin_message_single_banned}</div>
                    <!--{/if}-->
                    
                    <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                    		<!--{if $post['first']}-->
                       		<div class="pay_view b_p15 bg mtw mbw">
                            		{lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</strong>
                            		<a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" class="dialog y blue">{lang pay_view}</a>
                       		</div>
                        <!--{/if}-->
                    <!--{/if}-->

                    <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                    	   <!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                            <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                {lang has_expired}
                            <!--{else}-->
                                <div class="box_ex2 viewsort cl bg b_p15 mtw mbw">
						            <div class="bz-at-form mtw mbw">
						            	<h4 class="hm mbn">$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
									<table cellpadding="0" cellspacing="1" border="0">
							            <!--{loop $threadsortshow['optionlist'] $option}--> 
							            <!--{if $option['type'] != 'info'}-->
										<tr>
											<th>$option[title]:</th>
											<td><!--{if $option['value']}--><!--{eval preg_match("/(".str_replace("/",'\/',$_G['setting']['attachurl']).")(.*?)((.gif)|(.jpg)|(.jpeg)|(.bmp)|(.png))/",strtolower($option['value']),$dzlab_match);}--><!--{if count($dzlab_match)}--><img src='$dzlab_match[0]' /><!--{else}-->$option[value]<!--{/if}-->$option[unit]<!--{else}-->--<!--{/if}--></td>
										</tr>
							            <!--{/if}-->
							            <!--{/loop}-->
					              	</table>
								    </div>
                                </div>
                            <!--{/if}-->
                        <!--{/if}-->
                    <!--{/if}-->
                    
                    <!--{if $post['first']}-->
                        <!--{if !$_G[forum_thread][special]}-->
                            <div class="bz_message_table">$post[message]</div>
                        <!--{elseif $_G[forum_thread][special] == 1}-->
                            <!--{template forum/viewthread_poll}-->
                        <!--{elseif $_G[forum_thread][special] == 2}-->
                            <!--{template forum/viewthread_trade}-->
                        <!--{elseif $_G[forum_thread][special] == 3}-->
                            <!--{template forum/viewthread_reward}-->
                        <!--{elseif $_G[forum_thread][special] == 4}-->
                            <!--{template forum/viewthread_activity}-->
                        <!--{elseif $_G[forum_thread][special] == 5}-->
                            <!--{template forum/viewthread_debate}-->
                        <!--{elseif $threadplughtml}-->
                            $threadplughtml
                            $post[message]
                        <!--{else}-->
                        	$post[message]
                        <!--{/if}-->
                    <!--{else}-->
                        $post[message]
                    <!--{/if}-->
					
				<!--{/if}-->

			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
				<!--{if $post['attachment']}-->
					<div class="grey quote">
					{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
					</div>
				<!--{elseif $post['imagelist'] || $post['attachlist']}-->
					<!--{if $post['imagelist']}-->
						<!--{if count($post['imagelist']) == 1}-->
						<ul class="img_one">{echo showattach($post, 1)}</ul>
						<!--{else}-->
						<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
						<!--{/if}-->
					<!--{/if}-->
					<!--{if $post['attachlist']}-->
					<ul>{echo showattach($post)}</ul>
					<!--{/if}-->
				<!--{/if}-->
			<!--{/if}-->
				
				
		</div>

		<div class="cl">
			<h2>
		        	<!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
					[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
		        <!--{/if}-->
		        <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
		            [{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]
				<!--{/if}-->
				$_G[forum_thread][subject]
		        <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
		        <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
		        <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
		        <!--{/if}-->
			</h2>
			<div class="clear"></div>
			<div class="bzvt-type">
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="z blue">{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}</a>
				<em class="y grey"><i class="fz14 iconfont icon-chakan"></i>$_G[forum_thread][views]</em>
				<em class="y grey"><i class="fz14 iconfont icon-message"></i>$_G[forum_thread][allreplies]&nbsp;&nbsp;</em>
				<!--{if $_G['forum_thread']['digest'] > 0}-->
				<em class="y grey fz12">{lang digest}&nbsp;&nbsp;</em>
				<!--{/if}-->
		    </div>
			<div class="clear"></div>
			<div class="cl" style="position: relative;margin-left: 2%;margin-right: 2%;">
	    			<span class="avatar">
	    				<a <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->href="home.php?mod=space&uid=$post[authorid]&do=profile"<!--{/if}-->>
	    					<img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, middle, true)}--><!--{else}--><!--{avatar($post[authorid], middle, true)}--><!--{/if}-->" style="width:34px;height:34px;" />
	    				</a>
	    			</span>
	    			<ul class="authi">
					<li class="grey name">
						<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
						<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="blue">$post[author]</a>
						<!--{else}-->
							<!--{if !$post['authorid']}-->
							{lang guest} <i>$post[useip]{if $post[port]}:$post[port]{/if}</i>
							<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
								<!--{if $_G['forum']['ismoderator']}-->{lang anonymous}<!--{else}-->{lang anonymous}<!--{/if}-->
							<!--{else}-->
							$post[author] <em>{lang member_deleted}</em>
							<!--{/if}-->
						<!--{/if}-->
						
						<!--{if !$post[first] && $_G['forum_thread']['special'] == 5}-->
							<!--{if $post[stand] == 1}--><a class="grey" title="{lang debate_view_square}"> / {lang debate_square}</a>
								<!--{elseif $post[stand] == 2}--><a class="grey" title="{lang debate_view_opponent}"> / {lang debate_opponent}</a>
								<!--{else}--><a class="grey" title="{lang debate_view_neutral}"> / {lang debate_neutral}</a>
								<!--{/if}-->
							<!--{if $post[stand]}-->
								<!--<a class="b" href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]" id="voterdebate_$post[pid]" onclick="ajaxmenu(this);doane(event);">{lang debate_support} $post[voters]</a>-->
							<!--{/if}-->
						<!--{/if}-->
						
						<em><a href="#bztn_$post[pid]" class="popup"><i class="iconfont icon-switch"></i></a></em>
						<div id="bztn_$post[pid]" popup="true" style="display:none;">
							<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
						    <!--{if $post[authorid] != $_G[uid]}-->
	                         <em class="bztn_em"><a href="home.php?mod=spacecp&ac=pm&touid=$post[authorid]&pmid=0&daterange=2&pid=$post[pid]" style="font-size:12px;font-weight:normal;">{lang send_pm}</a></em>
	                         <!--{/if}-->
	                         <!--{/if}-->
							<!--{if $post[first]}-->
							<em class="bztn_em"><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn">{lang favorite}</a></em>
							<!--{/if}-->
							<!--{if $post[first]}-->
				        		<!--{if $_G['forum_thread']['attachment'] == 2 && $_G['group']['allowgetimage'] && (!$_G['setting']['guestviewthumb']['flag'] || $_G['setting']['guestviewthumb']['flag'] && $_G['uid'])}-->
							<em class="bztn_em"><a href="forum.php?mod=viewthread&tid=$_G[tid]&from=album" class="favbtn">{lang view_bigpic}</a></em>
							<!--{/if}-->
							<!--{/if}-->
							<!--{if $post[first]}-->
							<!--{else}-->
								<!--{if $_G[forum_thread][special] != 2 && $_G[forum_thread][special] != 4}-->
									<!--{if $_G[uid] && $allowpostreply && !$post[first]}-->
									<em class="bztn_em"><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page">{lang reply}</a></em>
									<!--{/if}-->
								<!--{/if}-->
							<!--{/if}-->
							<!--{if $post[first] && $post['authorid'] && $post['username'] && !$post['anonymous']}-->
							<em class="bztn_em">
								<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
								<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&authorid=$_G[forum_thread][authorid]" rel="nofollow" style="font-size:12px;font-weight:normal;">{lang viewonlyauthorid}</a>
								<!--{elseif !$_G['forum_thread']['archiveid']}-->
								<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page" rel="nofollow" style="font-size:12px;font-weight:normal;">{lang thread_show_all}</a>
								<!--{/if}-->
							</em>
							<!--{/if}-->
						</div>
						
						
					</li>
					<li class="grey rela">
						<!--{if isset($post[isstick])}-->
							 {lang replystick} {lang from}{$post[number]}&#27004;
						<!--{elseif $post[number] == -1}-->
							{lang recommend_post}
						<!--{else}-->
							<!--{if !empty($postno[$post[number]])}-->
							    $postno[$post[number]]
							<!--{else}-->
							    {$post[number]}&#27004;
							<!--{/if}-->
						<!--{/if}-->
						&nbsp;$post[dateline]
						
						<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid']))}-->
						<!--{if $_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first']}-->
						<!--{if $_G['forum']['ismoderator']}-->
						<!--{else}-->
						<a class="blue" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">&nbsp;{lang edit}</a>
						<!--{/if}-->
						<!--{/if}-->
						<!--{/if}-->
						
						<!--{if $_G['forum']['ismoderator']}-->
						<!-- manage start -->
						<!--{if $post[first]}-->
							<a href="#moption_$post[pid]" class="popup blue">&nbsp;{lang manage}</a>
							<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
								<!--{if !$_G['forum_thread']['special']}-->
								<input type="button" value="{lang edit}" class="redirect bz_button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
								<!--{/if}-->
								<input type="button" value="{lang delete}" class="dialog bz_button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
								<input type="button" value="{lang close}" class="dialog bz_button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
								<input type="button" value="{lang admin_banpost}" class="dialog bz_button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
								<input type="button" value="{lang topicadmin_warn_add}" class="dialog bz_button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
							</div>
						<!--{else}-->
							<a href="#moption_$post[pid]" class="popup blue">&nbsp;{lang manage}</a>
							<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
								<input type="button" value="{lang edit}" class="redirect bz_button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
								<!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog bz_button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
								<!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog bz_button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
								<!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog bz_button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
							</div>
						<!--{/if}-->
						<!-- manage end -->
						<!--{/if}-->
						<!--<!--{if $post['status'] & 8}-->{lang from_mobile}&nbsp;<!--{else}-->&#26469;&#33258;PC&nbsp;<!--{/if}-->-->
					</li>
	            	</ul>
	    		</div>
		</div>
   </div>
</div>

<!--{if !IS_ROBOT && $post['first'] && !$_G['forum_thread']['archiveid']}-->
<!--{if $post['invisible'] == 0}-->
<div class="bz_postfirst_btn">
	<ul>
		<li><a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" class="recbtn iconfont icon-praise"><span>{lang support_reply}<em id="recommendv_add"{if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>&nbsp;{$_G['forum_thread']['recommend_add']}</em></span></a></li>
		<li><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" class="iconfont icon-message"><span>{lang reply}<em{if !$_G[forum_thread][allreplies]} style="display:none"{/if}>&nbsp;$_G[forum_thread][allreplies]</em></span></a></li>
		<li><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn iconfont icon-collection"><span>{lang thread_favorite}<em id="favoritenumber"{if !$_G['forum_thread']['favtimes']} style="display:none"{/if}>&nbsp;{$_G['forum_thread']['favtimes']}</em></span></a></li>
	</ul>
</div>
<!--{/if}-->
<!--{/if}-->

<div class="bz_replylist_title b_p bz-bg-fff bzbt1 cl">
	<h1 class="z">{lang all}{lang reply}</h1><em{if !$_G[forum_thread][allreplies]} style="display:none"{/if} class="z color-bbb">&nbsp;&nbsp;$_G[forum_thread][allreplies]</em>
	<!--{if $ordertype != 1}-->
	<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1" class="y grey" style="margin-left: 15px;"><i class="iconfont icon-paixujiang"></i></a>
	<!--{else}-->
	<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2" class="y grey" style="margin-left: 15px;"><i class="iconfont icon-paixusheng"></i></a>
	<!--{/if}-->
	<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
	<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
	<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&authorid=$_G[forum_thread][authorid]" rel="nofollow" class="y grey"><i class="iconfont icon-yonghu-xianxing"></i></a>
	<!--{elseif !$_G['forum_thread']['archiveid']}-->
	<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page" rel="nofollow" class="y grey"><i class="iconfont icon-yonghu"></i></a>
	<!--{/if}-->
	<!--{/if}-->
</div>
<div class="clear"></div>
