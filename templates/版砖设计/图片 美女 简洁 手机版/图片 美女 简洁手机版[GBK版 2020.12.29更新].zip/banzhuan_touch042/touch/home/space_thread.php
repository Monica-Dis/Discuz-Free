<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<!--{template common/header}-->

<!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->

	<div class="bz-header">
		<div class="bz-header-left"><a href="javascript:;" onclick="history.go(-1);" class="iconfont icon-fanhui1"></a></div>
		<h2>$space[username]&#30340;{lang reply}</h2>
	</div>
	<!--{if $list}-->
	<div class="threadlist">
		<ul>
			<!--{loop $list $stid $thread}-->
				<li>
					<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]">
						<span $thread[highlight] >{$thread[subject]}</span>
						<p>
							<!--{if !$thread[author]}-->
			              	<span class="avt">{avatar($thread[0],small)}</span>
			              	<!--{else}-->
			              	<span class="avt">{avatar($thread[authorid],small)}</span>
			              	<!--{/if}-->
							<span class="grey fz14">
							<!--{if $thread['authorid'] && $thread['author']}-->
							$thread[author]&nbsp;
							<!--{else}-->
							$_G[setting][anonymoustext]&nbsp;
							<!--{/if}-->
							</span>
							<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
							<i class="color-blue fz12 bor">&#32622;&#39030;</i>
							<!--{/if}-->
							<!--{if $thread['digest'] > 0}-->
							<i class="color-red fz12 bor">&#31934;&#21326;</i>
							<!--{/if}-->
							<!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
							<i class="grey fz12 bor">&#26377;&#22270;</i>
							<!--{/if}-->
							<!--{if $tbid && !$picnum == 0}-->
							<i class="grey fz12 bor"><!--{$picnum}-->P</i>
							<!--{/if}-->
							<span class="y grey fz12 iconfont icon-chakan" style="margin-left: 5px;">{$thread[views]}</span>
							<!--{if $thread[replies] > 0}-->
							<span class="y grey fz12 iconfont icon-message">{$thread[replies]}</span>
							<!--{/if}-->
						</p>
					</a>
					<!--{if $actives[me] && $viewtype=='reply'}-->
					<div class="bzstidlist">
						<em class="arrow"></em>
						<div>
						<!--{loop $tids[$stid] $pid}-->
						<!--{eval $post = $posts[$pid];}-->
						<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid"><span class="blue">$space[username]</span><span class="grey"><!--{if $post[message]}-->: {$post[message]}<!--{else}-->...<!--{/if}--></span></a>
						<!--{/loop}-->
						</div>
					</div>
					<!--{/if}-->
				</li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{else}-->
	<div class="b_p hm grey">{lang no_related_posts}</div>
	<!--{/if}-->

<!--{else}-->

	<div class="bz-header">
		<div class="bz-header-left"><a href="javascript:;" onclick="history.go(-1);" class="iconfont icon-fanhui1"></a></div>
		<h2>$space[username]&#30340;{lang topic}</h2>
	</div>
	<!--{if $list}-->
	<div class="threadlist">
		<ul>
			<!--{loop $list $thread}-->
				<li>
					<a href="forum.php?mod=viewthread&tid=$thread[tid]">
						<span $thread[highlight] >{$thread[subject]}</span>
						<p>
							<!--{if !$thread[author]}-->
			              	<span class="avt">{avatar($thread[0],small)}</span>
			              	<!--{else}-->
			              	<span class="avt">{avatar($thread[authorid],small)}</span>
			              	<!--{/if}-->
							<span class="grey fz14">
							<!--{if $thread['authorid'] && $thread['author']}-->
							$thread[author]&nbsp;
							<!--{else}-->
							$_G[setting][anonymoustext]&nbsp;
							<!--{/if}-->
							</span>
							<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
							<i class="color-blue fz12 bor">&#32622;&#39030;</i>
							<!--{/if}-->
							<!--{if $thread['digest'] > 0}-->
							<i class="color-red fz12 bor">&#31934;&#21326;</i>
							<!--{/if}-->
							<!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
							<i class="grey fz12 bor">&#26377;&#22270;</i>
							<!--{/if}-->
							<!--{if $tbid && !$picnum == 0}-->
							<i class="grey fz12 bor"><!--{$picnum}-->P</i>
							<!--{/if}-->
							<span class="y grey fz12 iconfont icon-chakan" style="margin-left: 5px;">{$thread[views]}</span>
							<!--{if $thread[replies] > 0}-->
							<span class="y grey fz12 iconfont icon-message">{$thread[replies]}</span>
							<!--{/if}-->
						</p>
					</a>
				</li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{else}-->
	<div class="b_p hm grey">{lang no_related_posts}</div>
	<!--{/if}-->

<!--{/if}-->

<!--{if $multi}-->$multi<!--{/if}-->		
<div class="clear"></div>
<div class="bz_bottom"></div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
