<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->

<!--{if !$_GET['mycenter']}-->
	<div class="porfile_card">
		<div class="porfile_card_cover" style="background-image: url(<!--{avatar($space[uid], big, true)}-->);background-size: cover;">
			<div class="card_cover_colorBlock">
				<div class="colorBlock_header">
					<div class="left"><a href="javascript:;" onclick="history.go(-1);" class="iconfont icon-fanhui1"></a></div>
					<div class="right"><a href="forum.php" class="iconfont icon-home-o"></a></div>
				</div>
				<div id="BottomRightTriangle"></div>
			</div>
		</div>
		<div class="porfile_card_wrapper">
			<div class="card_wrapper_main">
				<div class="main_avt">
					<img src="<!--{avatar($space[uid], big, true)}-->" />
				</div>
				<div class="main_content">
					<div class="name hm">$space[username]</div>
					<!--{if $space[group][maxsigsize] && $space[sightml]}--><div class="sig fz14 grey">$space[sightml]</div><!--{/if}-->
				</div>
			</div>
		</div>
	</div>
	<!--{if $space[customstatus]}-->
	<div class="b_p cl">
		<div class="bz_medals">
			<div class="b_p bzbb1 fz14"><strong>{lang permission_basic_status}</strong></div>
			<div class="b_p fz14">$space[customstatus]</div>
		</div>
	</div>
	<!--{/if}-->
	<!--{if $space['medals']}-->
	<div class="b_p cl">
		<div class="bz_medals">
			<div class="b_p bzbb1 fz14"><strong>{lang medals}</strong></div>
			<div class="b_p">
			<!--{loop $space['medals'] $medal}-->
				<img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" id="md_{$medal[medalid]}" />
			<!--{/loop}-->
			</div>
		</div>
	</div>
	<!--{/if}-->
	<!--{if $_G['setting']['verify']['enabled']}-->
		<!--{eval $showverify = true;}-->
		<!--{loop $_G['setting']['verify'] $vid $verify}-->
			<!--{if $verify['available']}-->
				<!--{if $showverify}-->
				<div class="b_p cl">
				<div class="bz_medals">
				<div class="b_p bzbb1 fz14"><strong>{lang profile_verify}</strong></div>
				<div class="b_p">
				<!--{eval $showverify = false;}-->
				<!--{/if}-->
				<!--{if $space['verify'.$vid] == 1}-->
					<!--{if $verify['icon']}--><img src="$verify['icon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{else}-->$verify[title]<!--{/if}-->&nbsp;
				<!--{elseif !empty($verify['unverifyicon'])}-->
					<!--{if $verify['unverifyicon']}--><img src="$verify['unverifyicon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{/if}-->&nbsp;
				<!--{/if}-->
			<!--{/if}-->
		<!--{/loop}-->
		<!--{if !$showverify}--></div></div></div><!--{/if}-->
	<!--{/if}-->
	<div class="b_p cl">
		<div class="userinfo-brief">
			<div class="b_p bzbb1 fz14"><strong>{lang stat_info}</strong></div>
			<ul class="cl">
				<!--{if $_G['setting']['allowviewuserthread'] !== false}-->
				<!--{eval $space['posts'] = $space['posts'] - $space['threads'];}-->
				<li>
					<div><a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=reply&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread&type=reply{/if}" class="blue"><em>{lang replay_num}</em></a></div>
					<div><span>$space[posts]</span></div>
				</li>
				<li>
					<div><a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=thread&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread{/if}" class="blue"><em>{lang threads_num}</em></a></div>
					<div><span>$space[threads]</span></div>
				</li>
				<!--{/if}-->
				<li>
					<div><em>{lang friends_num}</em></div>
					<div><span>$space[friends]</span></div>
				</li>
			</ul>
			<ul class="cl">
				<li>
					<div><em>{lang credits}</em></div>
					<div><span>$space[credits]</span></div>
				</li>
				<!--{loop $_G[setting][extcredits] $key $value}-->
				<!--{if $value[title]}-->
				<li>
					<div><em>$value[title]</em></div>
					<div><span>{$space["extcredits$key"]} $value[unit]</span></div>
				</li>
				<!--{/if}-->
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{if $profiles}-->
	<div class="b_p cl">
		<div class="bz_per_info">
			<div class="b_p bzbb1 fz14"><strong>&#20010;&#20154;&#20449;&#24687;</strong></div>
			<ul class="cl" style="padding: 10px 0;">
				<!--{loop $profiles $value}-->
				<li><a>$value[title]<span>$value[value]</span></a></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{/if}-->
	<!--{if in_array($_G[adminid], array(1, 2))}-->
	<div class="b_p cl">
		<div class="bz_medals">
			<div class="b_p bzbb1 fz14"><strong>Email</strong></div>
			<div class="b_p fz14">$space[email]</div>
		</div>
	</div>
	<!--{/if}-->
	
	<!--{if $space[spacenote]}-->
	
	<!--{/if}-->
	<div class="b_p cl">
		<div class="bz_per_info">
			<div class="b_p bzbb1 fz14"><strong>{lang active_profile}</strong></div>
			<ul class="cl" style="padding: 10px 0;">
				<!--{if $space[adminid]}-->
				<li><a>{lang management_team}<span>{$space[admingroup][grouptitle]}</span></a></li>
				<!--{/if}-->
				<li><a>{lang usergroup}<span>{$space[group][grouptitle]}</span></a></li>
				<!--{if $space[extgroupids]}-->
				<li><a>{lang group_expiry_type_ext}<span>$space[extgroupids]</span></a></li>
				<!--{/if}-->
				<!--{if $space[oltime]}-->
				<!--<li><a>{lang online_time}<span>$space[oltime] {lang hours}</span></a></li>-->
				<!--{/if}-->
				<li><a>{lang regdate}<span>$space[regdate]</span></a></li>
				<!--<li><a>{lang last_visit}<span>$space[lastvisit]</span></a></li>-->
				<!--{if $space[lastactivity]}-->
				<!--<li><a>{lang last_activity_time}<span>$space[lastactivity]</span></a></li>-->
				<!--{/if}-->
				<!--{if $space[lastpost]}-->
				<!--<li><a>{lang last_post_time}<span>$space[lastpost]</span></a></li>-->
				<!--{/if}-->
				<!--{if $space[lastsendmail]}-->
				<li><a>{lang last_send_email}<span>$space[lastsendmail]</span></a></li>
				<!--{/if}-->
				<!--{eval $timeoffset = array({lang timezone});}-->
				<!--<li><a>{lang time_offset}<span>$timeoffset[$space[timeoffset]]</span></a></li>-->
			</ul>
		</div>
	</div>


<!--{else}-->

	<!--{if $_G['setting']['domain']['app']['mobile']}-->
		{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
	<!--{else}-->
		{eval $nav = "forum.php";}
	<!--{/if}-->
	<div class="userinfo">
		<div class="user_avatar bzbb1">
			<div class="avatar_m"><span><img src="<!--{avatar($_G[uid], big, true)}-->" /></span></div>
			<h2 class="name">$_G[username]</h2>
		</div>
		<div class="myinfo_list cl">
			<ul>
				<!--<li class="bzbt1 bzbb1"><a href="plugin.php?id=banzhuan_avatar">{lang memcp_avatar}&#x0068;&#x0074;&#x0074;&#x0070;&#x003a;&#x002f;&#x002f;&#x0077;&#x0077;&#x0077;&#x002e;banzhuanlove&#x002e;&#x0063;&#x006e;<span class="y iconfont icon-gengduo"></span></a></li>-->
				<li class="mtm bzbt1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile" class="bzbb1">{lang myitem}&#31354;&#38388;<span class="y iconfont icon-gengduo"></span></a></li>
				<li><a href="home.php?mod=space&do=pm" class="bzbb1">{lang mypm}<span class="y iconfont icon-gengduo"></span><!--{if $_G[member][newpm]}--><em class="y iconfont icon-dian1 rq"></em><!--{/if}--></a></li>
				<li><a href="home.php?mod=space&do=favorite&type=all" class="bzbb1">{lang myfavorite}<span class="y iconfont icon-gengduo"></span></a></li>
				<li><a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me&from=space&type=thread" class="bzbb1">{lang mythread}<span class="y iconfont icon-gengduo"></span></a></li>
				<li class="bzbb1"><a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me&from=space&type=reply">{lang myitem}{lang reply}<span class="y iconfont icon-gengduo"></span></a></li>
				<li class="mtm bzbt1"><a href="home.php?mod=spacecp&ac=credit" class="bzbb1">{lang my_credits}<span class="y iconfont icon-gengduo"></span><em class="y fz12 grey">$space[credits]&nbsp;{lang credits}&nbsp;&nbsp;</em></a></li>
				<li class="bzbb1"><a href="home.php?mod=spacecp&ac=usergroup">{lang my_usergroups}<span class="y iconfont icon-gengduo"></span><em class="y fz12 grey">$_G[group][grouptitle]&nbsp;&nbsp;</em></a></li>
				<li class="mtm bzbt1 bzbb1"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout_mobile}<span class="y iconfont icon-gengduo"></span></a></li>
			</ul>
		</div>
	</div>
	<div id="footbar">
	    <div class="fbc">
	        <ul>
	            <li><a href="forum.php?forumlist=1&mobile=2" class="iconfont icon-home-o"><span>$_G['setting']['sitename']</span></a></li>
	            <li class="a"><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}" class="iconfont icon-yonghu"><span>{lang myitem}</span><!--{if $_G[member][newpm]}--><i class="iconfont icon-dian1"></i><!--{/if}--></a></li>
	        </ul>
	    </div>
	</div>
<!--{/if}-->

<div class="bz_bottom"></div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->



