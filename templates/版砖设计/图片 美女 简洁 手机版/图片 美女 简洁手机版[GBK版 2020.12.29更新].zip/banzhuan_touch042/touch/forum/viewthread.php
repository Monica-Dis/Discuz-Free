<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<!--{hook/viewthread_top_mobile}-->
<div class="postlist">
	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
	<!--{hook/viewthread_posttop_mobile $postcount}-->
	<!--{if $post[first]}-->
		<!--{subtemplate forum/viewthread_first}-->
	<!--{else}-->
		<!--{subtemplate forum/viewthread_reply}-->
	<!--{/if}-->
   	<!--{hook/viewthread_postbottom_mobile $postcount}-->
   	<!--{eval $postcount++;}-->
   	<!--{/loop}-->
	<!--{subtemplate forum/forumdisplay_fastpost}-->
</div>

$multipage

<!--{hook/viewthread_bottom_mobile}-->

<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>

<a href="<!--{if $_GET[fromguid] == 'hot'}-->forum.php?mod=guide&view=hot&page=$_GET[page]<!--{else}-->forum.php?mod=forumdisplay&fid=$_G[fid]&<!--{eval echo rawurldecode($_GET[extra]);}--><!--{/if}-->" class="bz-return2"><i class="iconfont icon-fanhui1"></i></a>
<a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a>
<div class="bz_bottom"></div>
<!--{template common/footer}-->
