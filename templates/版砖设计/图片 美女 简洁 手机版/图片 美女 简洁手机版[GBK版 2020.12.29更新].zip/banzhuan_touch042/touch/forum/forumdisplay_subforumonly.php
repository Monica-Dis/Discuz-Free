<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<!--{if $sublist > 0}-->
<div class="clear"></div>
<div class="bz-mb10">
	<div class="b_p15 bzbb1 cl"><h2 class="fz16">$_G['forum'][name]</h2></div>
	<div class="sub_forum_only">
		<ul>
			<!--{loop $sublist $sub}-->
			<li>
				<div class="gengduo"><a href="forum.php?mod=forumdisplay&fid={$sub[fid]}"><i class="iconfont icon-gengduo"></i></a></div>
				<div class="name-pic">
                    <!--{if $sub[icon]}-->
                    {$sub[icon]}
                    <!--{else}-->
                    <a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
						<img src="template/banzhuan_touch042/touch/bzcji/images/forum-icon.jpg" align="left" />
                    </a>
                    <!--{/if}-->
			    </div>
                	<div class="name-tit">
                		<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
                			<span>{$sub['name']}</span>
                			<!--{if $sub[todayposts] > 0}-->
                	        	<p>{lang forum_threads} <!--{echo dnumber($sub[threads])}--> / {lang posts} <!--{echo dnumber($sub[posts])}--> / <em class="rq">{lang index_today}: $sub[todayposts]</em></p>
                	        <!--{else}-->
                	        	<p>{lang forum_threads} <!--{echo dnumber($sub[threads])}--> / {lang posts} <!--{echo dnumber($sub[posts])}--></p>
                	        	<!--{/if}-->
                	    </a>
                	</div>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
</div>
<div class="clear"></div>
<!--{else}-->
<div class="bz-mb10">
	<div class="b_p15 bzbb1 cl"><h2 class="fz16">$_G['forum'][name]</h2></div>
	<div class="b_p15 grey bz-bg-fff bzbb1">{lang none}{lang forum_subforums}</div>
</div>
<!--{/if}-->

