<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<div class="b_p15 cl">
	<div class="bz_pay">
		<p class="b_p15 hm grey mtw fz14">{lang youneedpay} <strong class="rq">$paycredits {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit']}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title']}</strong> {lang onlyintoforum}</p>
		<div class="b_p15">
			<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=paysubmit">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="mtw btn-big">
					<button class="touch" type="submit" name="loginsubmit" value="true">{lang confirmyourpay}</button>
				</div>
				<div class="mtw mbw btn-big-bor">
					<button class="touch" type="button" onclick="history.go(-1)">{lang cancel}</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!--{hook/forumdisplay_bottom_mobile}-->

<div id="footbar">
    <div class="fbc">
        <ul>
            <li class="a"><a href="forum.php?forumlist=1&mobile=2" class="iconfont icon-home1"><span>$_G['setting']['sitename']</span></a></li>
            <li><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}member.php?mod=logging&action=login{/if}" class="iconfont icon-yonghu-xianxing"><span>{lang myitem}</span><!--{if $_G[member][newpm]}--><i class="iconfont icon-dian1"></i><!--{/if}--></a></li>
        </ul>
    </div>
</div>
<!--{template common/footer}-->
