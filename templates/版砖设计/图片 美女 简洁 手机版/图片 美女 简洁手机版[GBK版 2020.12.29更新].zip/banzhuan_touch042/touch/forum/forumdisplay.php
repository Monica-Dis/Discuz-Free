<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<!--{hook/forumdisplay_top_mobile}-->

<!--{if !$subforumonly}-->
	<div class="bz_h10"></div>
	<!--{if $subexists && $_G['page'] == 1}-->
	<div class="bz-sub-nav b_plrb10">
		<a style="background: #F2F2F2;">{lang forum_subforums}&nbsp;&nbsp;:</a>
		<!--{loop $sublist $sub}-->
		<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}<!--{if empty($sub[redirect])}--><!--{if $sub[threads] > 0}--><i class="grey" style="-webkit-transform: scale(0.8,0.8); display: inline-block;">&nbsp;&nbsp;<!--{echo dnumber($sub[threads])}--></i><!--{/if}--><!--{/if}--></a>
		<!--{/loop}-->
	</div>
	<div class="clear"></div>
	<!--{/if}-->
<!--{else}-->
	<!--{subtemplate forum/forumdisplay_subforumonly}-->
<!--{/if}-->

<!--{if !$subforumonly}-->

	<!--{if !empty($_G['forum']['picstyle']) && !$_G['cookie']['forumdefstyle']}-->
		<!--{if $_G['forum_threadcount']}-->
		<div class="bz-sub-nav b_plrb10">
			<a style="background: #F2F2F2;">{lang orderby}&nbsp;&nbsp;:</a>
			<a href="forum.php?mod=forumdisplay&fid={$_G[fid]}" <!--{if $_GET[orderby] != 'dateline'}-->class="a"<!--{/if}-->>{lang default}</a>
			<a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter=author&orderby=dateline" <!--{if $_GET[orderby] != 'dateline'}--><!--{else}-->class="a"<!--{/if}-->>{lang latest}</a>
			<!--{eval}-->
			if($_G['uid']){$favfids = C::t('home_favorite')->fetch_all_by_uid_idtype($_G['uid'], 'fid');foreach($favfids as $val){if($val['id'] == $_G[fid]){$isFav = $val['favid'];}}}
			<!--{/eval}-->
			<!--{if $isFav}-->
			<a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}&formhash={FORMHASH}" class="forum-fav a"><i class="iconfont icon-collection_fill fz12"></i>{lang favorite}</a>
			<!--{else}-->
			<a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}&formhash={FORMHASH}" class="forum-fav"><i class="iconfont icon-collection fz12"></i>{lang favorite}</a>
			<!--{/if}-->
		</div>
		<div class="piclist cl">
			<!--{loop $_G['forum_threadlist'] $key $thread}-->
				<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
					{eval continue;}
				<!--{/if}-->
	        		<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
	        		{eval $displayorder_thread = 1;}
	            <!--{/if}-->
				<!--{if $thread['moved']}-->
					<!--{eval $thread[tid]=$thread[closed];}-->
				<!--{/if}-->
				<div class="card">
					<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="$thread[subject]">
						<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4)) && $thread['digest'] > 0}-->
						<i>{lang thread_sticky} / {lang thread_digest}</i>
						<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
						<i>{lang thread_sticky}</i>
						<!--{elseif $thread['digest'] > 0}-->
						<i>{lang thread_digest}</i>
						<!--{else}-->
						<!--{/if}-->
						<!--{if $thread['cover']}-->
						<img src="$thread[coverpath]" alt="$thread[subject]"/>
						<!--{else}-->
						<img src="./template/banzhuan_touch042/touch/bzcji/images/nophoto.gif">
						<!--{/if}-->
					</a>
				</div>
			<!--{/loop}-->
		</div>
		<script type="text/javascript">
	        $(function(){
	            $('.piclist').waterbzfall({ item: '.card' });
	        });
		</script>
		<!--{else}-->
		<div class="b_p hm grey">{lang forum_nothreads}</div>
		<!--{/if}-->
	<!--{else}-->
		<!--{if $_G['forum_threadcount']}-->
		<div class="bz-sub-nav b_plrb10">
			<a style="background: #F2F2F2;">{lang orderby}&nbsp;&nbsp;:</a>
			<a href="forum.php?mod=forumdisplay&fid={$_G[fid]}" <!--{if $_GET[orderby] != 'dateline'}-->class="a"<!--{/if}-->>{lang default}</a>
			<a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter=author&orderby=dateline" <!--{if $_GET[orderby] != 'dateline'}--><!--{else}-->class="a"<!--{/if}-->>{lang latest}</a>
			<!--{eval}-->
			if($_G['uid']){$favfids = C::t('home_favorite')->fetch_all_by_uid_idtype($_G['uid'], 'fid');foreach($favfids as $val){if($val['id'] == $_G[fid]){$isFav = $val['favid'];}}}
			<!--{/eval}-->
			<!--{if $isFav}-->
			<a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}&formhash={FORMHASH}" class="forum-fav a"><i class="iconfont icon-collection_fill fz12"></i>{lang favorite}</a>
			<!--{else}-->
			<a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}&formhash={FORMHASH}" class="forum-fav"><i class="iconfont icon-collection fz12"></i>{lang favorite}</a>
			<!--{/if}-->
		</div>
		<div class="threadlist cl bzbt1">
			<ul>
				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{eval require_once(DISCUZ_ROOT.'./template/banzhuan_touch042/touch/php/databz.php');}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
		        		<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
		        		{eval $displayorder_thread = 1;}
		            <!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<!--{eval $threadtable = substr($thread[tid], -1);}-->
					<!--{eval $img_number = databz_img_num($thread[tid], $thread[authorid], $threadtable);}-->
					<li>
						<!--{hook/forumdisplay_thread_mobile $key}-->
			            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
							<span $thread[highlight] >{$thread[subject]}</span>
							<!--{if $img_number == 1}-->
								<!--{eval $list_img1 = databz_img($thread[tid], $thread[authorid], 1, $threadtable);}-->
								<div class="img_one">
									<!--{loop $list_img1 $list_img1_1}-->
									<em style="background-image:url({eval echo(getforumimg($list_img1_1[aid],0,500,500))});"></em>
									<!--{/loop}-->
								</div>
								<div class="clear"></div>
							<!--{elseif $img_number > 1}-->
								<div class="img_three">
									<!--{eval $list_img3 = databz_img($thread[tid], $thread[authorid], 3, $threadtable);}-->
									<!--{loop $list_img3 $list_img3_1}-->
									<em style="background-image:url({eval echo(getforumimg($list_img3_1[aid],0,200,200))});"></em>
									<!--{/loop}-->
								</div>
								<div class="clear"></div>
							<!--{/if}-->
							<p>
								<!--{if !$thread[author]}-->
				              	<span class="avt">{avatar($thread[0],small)}</span>
				              	<!--{else}-->
				              	<span class="avt">{avatar($thread[authorid],small)}</span>
				              	<!--{/if}-->
								<span class="grey fz14 name">
								<!--{if $thread['authorid'] && $thread['author']}-->
								$thread[author]&nbsp;
								<!--{else}-->
								$_G[setting][anonymoustext]&nbsp;
								<!--{/if}-->
								</span>
								<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
								<i class="color-blue fz12 bor">{lang thread_stick}</i>
								<!--{/if}-->
								<!--{if $thread['digest'] > 0}-->
								<i class="color-red fz12 bor">{lang thread_digest}</i>
								<!--{/if}-->
								<span class="y grey fz12 iconfont icon-chakan" style="margin-left: 5px;">{$thread[views]}</span>
								<!--{if $thread[replies] > 0}-->
								<span class="y grey fz12 iconfont icon-message">{$thread[replies]}</span>
								<!--{/if}-->
							</p>
						</a>
					</li>
		        <!--{/loop}-->
			</ul>
		</div>
		<!--{else}-->
		<div class="b_p hm grey">{lang forum_nothreads}</div>
		<!--{/if}-->
	<!--{/if}-->	

	$multipage
<!--{/if}-->

<!--{hook/forumdisplay_bottom_mobile}-->
<div class="bz_bottom"></div>
<!--{if !$subforumonly}-->
<a href="forum.php?mod=post&action=newthread&fid=$_G['fid']" class="bz-return1"><i class="iconfont icon-post"></i></a>
<!--{/if}-->
<a href="forum.php?forumlist=1" class="bz-post"><i class="iconfont icon-fanhui1"></i></a>
<script type="text/javascript">
	$('.forum-fav').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=forum-fav&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
