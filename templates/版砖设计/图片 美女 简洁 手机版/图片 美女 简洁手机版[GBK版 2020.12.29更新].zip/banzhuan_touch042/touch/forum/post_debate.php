<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<div class="bz-post-debate">
    <p class="bz-post-debate-p">
	    	<label for="affirmpoint">{lang debate_square_point}<strong class="color-red"> *</strong></label>
	    	<textarea name="affirmpoint" id="affirmpoint" class="txt" rows="3" >$debate[affirmpoint]</textarea>
    </p>
    <p class="bz-post-debate-p">
	    	<label for="negapoint">{lang debate_opponent_point}<strong class="color-red"> *</strong></label>
	    	<textarea name="negapoint" id="negapoint" class="txt"  rows="3">$debate[negapoint]</textarea>
    </p>
    <p class="bz-post-debate-p">
	    	<label for="endtime">{lang endtime} : <em class="grey" style="font-style: italic;font-size: 12px;">{lang threadsort_calendar} 08:15</em></label>
	    <input type="text" name="endtime" id="endtime" class="txt_s" autocomplete="off" value="$debate[endtime]"  />
    </p>
    <p class="bz-post-debate-p">
	    	<label for="umpire">{lang debate_umpire} : </label>
	    <input type="text" name="umpire" id="umpire" class="txt_s" value="$debate[umpire]"  />
    </p>
</div>
