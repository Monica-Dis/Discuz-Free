<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<div class="search">
	<table width="100%" cellspacing="0" cellpadding="0">
		<tbody>
			<tr>
				<td>
					<input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="{lang search}&#24863;&#20852;&#36259;&#30340;{lang thread_content}" style="border-radius: 5px;">
				</td>
				<td width="60" align="right" class="scbar_btn_td">
					<div><input type="hidden" name="searchsubmit" value="yes"><input type="submit" value="{lang search}" class="button2" id="scform_submit" style="border-radius: 5px;"></div>
				</td>
			</tr>
		</tbody>
	</table>
</div>
