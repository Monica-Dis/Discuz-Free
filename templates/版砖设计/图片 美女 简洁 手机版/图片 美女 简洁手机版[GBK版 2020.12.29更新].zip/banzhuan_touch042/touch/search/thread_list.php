<?php echo 'DisM!Ӧ������ https://dism.taobao.com';exit;?>
<div class="threadlist">
	<!--{if empty($threadlist)}-->
	<p class="mtw b_p hm grey">{lang search_nomatch}</p>
	<!--{else}-->
	<ul class="bzbt1">
		<!--{loop $threadlist $thread}-->
		<li>
			<a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]">
				<span $thread[highlight]>$thread[subject]</span>
				<p>
					<!--{if !$thread[author]}-->
	              	<span class="avt">{avatar($thread[0],small)}</span>
	              	<!--{else}-->
	              	<span class="avt">{avatar($thread[authorid],small)}</span>
	              	<!--{/if}-->
					<span class="grey fz14">
					<!--{if $thread['authorid'] && $thread['author']}-->
					$thread[author]&nbsp;<!--{if !empty($verify[$thread['authorid']])}-->$verify[$thread[authorid]]&nbsp;<!--{/if}-->
					<!--{else}-->
					$_G[setting][anonymoustext]&nbsp;
					<!--{/if}-->
					</span>
					<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					<i class="color-blue fz12 bor">&#32622;&#39030;</i>
					<!--{/if}-->
					<!--{if $thread['digest'] > 0}-->
					<i class="color-red fz12 bor">&#31934;&#21326;</i>
					<!--{/if}-->
					<!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
					<i class="grey fz12 bor">&#26377;&#22270;</i>
					<!--{/if}-->
					<span class="y grey fz12 iconfont icon-chakan" style="margin-left: 5px;">{$thread[views]}</span>
					<!--{if $thread[replies] > 0}-->
					<span class="y grey fz12 iconfont icon-message"><!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span>
					<!--{/if}-->
				</p>
			</a>
		</li>
		<!--{/loop}-->
	</ul>
	<!--{/if}-->
	$multipage
</div>
