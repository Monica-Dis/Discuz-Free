<?php echo 'From: DisM.taobao.com';exit;?>	

<!--{template common/header}-->

<!-- header start -->
<header class="header">
	<div class="nav cl">
		<div class="header_l z"><a href="javascript:history.back();"><i class="fa fa-angle-left"></i></a></div>
		<span class="category"><span class="name" style="line-height: 34px; font-size: 16px;">վ�㹫��</span></span>
		<div class="header_r y">&nbsp;</div>
	</div>
</header>
<!-- header end -->

<div class="yide_announcement cl"> 
<!--{loop $announcelist $ann}-->
     <li>
        <h2 class="transition">$ann[subject]<i class="fa fa-angle-down" aria-hidden="true"></i></h2>
        <div class="yide_ann_c">$ann[message]</div>
         <div class="yide_ann_ft">
              <a href="home.php?mod=space&username=$ann[authorenc]">$ann[author]</a>
			  <p class="y">$ann[starttime]</p>
         </div>
     </li>
<!--{/loop}-->
</div>

<script type='text/javascript'>    
   $(".yide_announcement li").click(function(){
       $(this).toggleClass("c_open");
     });
</script>

<!--{template common/footer}-->