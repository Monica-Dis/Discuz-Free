<?php echo 'From: DisM.taobao.com';exit;?>	

<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:forum.php?mod=guide&view=newthread&mobile=2');exit;}-->
<!--{/if}-->
<!--{template common/header}-->

<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<script src="$_G['style'][styleimgdir]/js/jquery.yide.slide.js?{VERHASH}"></script>
<!--{eval}-->
<!--
$announcedata = C::t('forum_announcement')->fetch_all_by_date($_G['timestamp']);
if($announcedata) {
		$readapmids = !empty($_G['cookie']['readapmid']) ? explode('D', $_G['cookie']['readapmid']) : array();
		foreach($announcedata as $announce) {
			if(!$announce['endtime'] || $announce['endtime'] > TIMESTAMP && (empty($announce['groups']) || in_array($_G['member']['groupid'], $announce['groups']))) {
				if(empty($announce['type'])) {
					$announces .= '<li><span><a href="forum.php?mod=announcement&id='.$announce['id'].'" class="xi2">'.$announce['subject'].
						'</a></span><em>('.dgmdate($announce['starttime'], 'd').')</em></li>';
				} elseif($announce['type'] == 1) {
					$announces .= '<li><span><a href="'.$announce['message'].'" target="_blank" class="xi2">'.$announce['subject'].
						'</a></span><em>('.dgmdate($announce['starttime'], 'd').')</em></li>';
				}
			}
		}
	}
-->
<!--{/eval}-->
<!--{if $_GET['visitclient']}-->

<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->

<!-- header start -->
<!--{if $showvisitclient}-->

<div class="visitclienttip vm" style="display:block;">
	<a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>	
	<p>
		{lang downloadzslttoshareview}
	</p>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
		$('.visitclienttip').css('display', 'block');
	}
</script>

<!--{/if}-->

<header class="header">
	<div class="nav">
		<!--{if $_G['setting']['domain']['app']['mobile']}-->
			{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
		<!--{else}-->
			{eval $nav = "forum.php";}
		<!--{/if}-->
        <div class="header_l z"><a href="javascript:history.back();"><i class="fa fa-angle-left"></i></a></div>
		<span class="category"><span class="name" style="line-height: 34px; font-size: 16px;">���</span></span>
		<div class="header_r y">
			<a href="forum.php?mod=misc&action=nav&mobile=2"><i class="fa fa-pencil-square-o"></i></a>
		</div>
	</div>
</header>
<!-- header end -->

<!--{hook/index_top_mobile}-->
<!-- main forumlist start -->
<div class="wp cl" id="wp">

<div class="yide_forum_rank">
     <ul class="cl">
         <li><span>{lang index_today}<p>$todayposts</p></span></li>
         <li><span>{lang index_posts}<p>$posts</p></span></li>
         <li><span style=" border-right: none;">{lang index_members}<p id="number_favorite_num">$_G['cache']['userstats']['totalmembers']</p></span></li>
     </ul>
</div>

<!--{if empty($gid) && $announces}--> 
  <div id="announces">
    <dl class="cl">
      <dt class="yide_ann_tit z">{lang announcements}</dt>
      <dd>
        <div class="bd">
          <ul>
            $announces
          </ul>
        </div>
      </dd>
    </dl>
  </div>
  <script type="text/javascript">
	jQuery("#announces").slide({ mainCell:".bd ul", effect:"topLoop", autoPlay:true,interTime:3000});
  </script>  
<!--{/if}--> 

<!--{loop $catlist $key $cat}-->
  <div class="yide_forum_subarea cl">
    <div class="subforumshow yide_forum_head cl" href="#sub_forum_$cat[fid]"> <span class="o"><img src="$_G['style']['styleimgdir']/touch/images/collapsed_<!--{if !$_G[setting][mobile][mobileforumview]}-->yes<!--{else}-->no<!--{/if}-->.png"></span>
      <h2><a href="javascript:;">$cat[name]</a></h2>
    </div>
    <div id="sub_forum_$cat[fid]" class="sub_forum yide_forum_unit">
      <ul>
        <!--{loop $cat[forums] $forumid}--> 
        <!--{eval $forum=$forumlist[$forumid];}-->
        <li>
		 
          <div class="yide_forumicon"> 
		      <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
            <!--{if $forum[icon]}--> 
            $forum[icon] 
            <!--{else}--> 
            <img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /> 
            <!--{/if}--> 
			</a>
          </div>
          <h2><a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">{$forum[name]}</a></h2>
          <p>����:<!--{echo dnumber($forum[threads])}-->, ����:<!--{echo dnumber($forum[posts])}--></p>
		  </li>
        <!--{/loop}-->
      </ul>
    </div>
  </div>
<!--{/loop}-->
</div>
<!-- main forumlist end -->
<!--{hook/index_middle_mobile}-->
<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			$('.sub_forum').css('display', 'block');
		<!--{else}-->
			$('.sub_forum').css('display', 'none');
		<!--{/if}-->
		$('.subforumshow').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.slideDown();
				obj.find('img').attr('src', '$_G['style']['styleimgdir']/touch/images/collapsed_yes.png');
			} else {
				subobj.slideUp();
				obj.find('img').attr('src', '$_G['style']['styleimgdir']/touch/images/collapsed_no.png');
			}
		});
	 })();
</script>

<!--{/if}-->
<!--{template common/footer}-->
