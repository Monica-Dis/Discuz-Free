<?php echo 'From: DisM.taobao.com';exit;?>	

<!--{template common/header}-->
<!-- header start -->
<header class="header">
    <div class="nav">
        <div class="header_l z"><a href="javascript:history.back();"><i class="fa fa-angle-left"></i></a></div>
		<span class="category">
			<!--{if $subexists && $_G['page'] == 1}-->
			<span class="display name vm" href="#subname_list">
				<h2 class="tit"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></h2>
				<i class="fa fa-angle-down"></i>
			</span>
			<div id="subname_list" class="subname_list" display="true" style="display:none;">
				<ul>
				<!--{loop $sublist $sub}-->
				<li>
					<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a>
				</li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{else}-->
			<span class="name" style=" line-height: 34px;font-size: 16px;">
				<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
			</span>
			<!--{/if}-->
		</span>
		<div class="header_r y"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}"><i class="fa fa-pencil-square-o"></i></a></div>
    </div>
</header>
<!-- header end -->

<div class="yide_t_forumtop">
    <div class="yide_t_forumtop_icon"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" title="$_G['forum'][name]"><img alt="$_G['forum'][name]" src="<!--{if $_G['forum'][icon]}-->data/attachment/common/$_G['forum'][icon]<!--{else}-->{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif<!--{/if}-->"></a></div>
    <h2><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></h2>
    <p class="yide_forum_num">
	   <span>{lang index_today} <em>$_G[forum][todayposts]</em></span>
	   <span>{lang index_threads} <em>$_G[forum][threads]</em></span>
	</p>
    <div class="yide_forum_fav">
	    <a class="dialog" href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}">+ ��ע</a>
	</div>
</div>

<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->
<!--{if !$subforumonly}-->
<div class="threadlist">
			<ul>
			<!--{if $_G['forum_threadcount']}-->
				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
                	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<li>

					<div class="yide_td_avt">
					     <a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><!--{avatar($thread[authorid],midlle)}--></a>
                    </div>
					<!--{hook/forumdisplay_thread_mobile $key}-->
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="yide_td_txt">
					  <h2>
					     {$thread[subject]}
					     <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
						    <img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" align="absmiddle" />
						 <!--{/if}-->
						 <!--{if $thread['digest'] > 0}-->
						    <img src="{IMGDIR}/digest_$thread[digest].gif" align="absmiddle" alt="digest" title="{lang thread_digest} $thread[digest]" />
						 <!--{/if}-->
						 <!--{if $thread['attachment'] == 2}-->
							<img src="{STATICURL}image/filetype/image_s.gif" alt="attach_img" title="{lang attach_img}" align="absmiddle" />
						 <!--{elseif $thread['attachment'] == 1}-->
							<img src="{STATICURL}image/filetype/common.gif" alt="attachment" title="{lang attachment}" align="absmiddle" />
						<!--{/if}-->
					  </h2>

					  <div class="yide_auth_msg cl">
   
      <span class="yide_txt">$thread[author]</span>      
	  <span class="yide_txt" style=" color: #bbb;">@</span>
   <span class="yide_txt">$thread[dateline]</span>

   </div>
					</a>
					
					</li>
                <!--{/loop}-->
            <!--{else}-->
			<li>{lang forum_nothreads}</li>
			<!--{/if}-->
		</ul>
</div>
$multipage
<!--{/if}-->
<!-- main threadlist end -->
<!--{hook/forumdisplay_bottom_mobile}-->
<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}-->
