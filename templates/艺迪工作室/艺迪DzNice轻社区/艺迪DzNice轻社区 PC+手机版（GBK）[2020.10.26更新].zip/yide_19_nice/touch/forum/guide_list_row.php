<?php echo 'From: DisM.taobao.com';exit;?>	

<div class="yide_threadlists">
<div class="yide_common_title cl">
     <ul>
        <li><a href="forum.php?mod=guide&view=newthread" class="{if $view == 'newthread'}a{/if}">���·���</a></li>
	    <li><a href="forum.php?mod=guide&view=new" class="{if $view == 'new'}a{/if}">���»ظ�</a></li>
        <li><a href="forum.php?mod=guide&view=hot" class="{if $view == 'hot'}a{/if}">��������</a></li> 
	    <li><a href="forum.php?mod=guide&view=digest" class="{if $view == 'digest'}a{/if}">��������</a></li> 
	 </ul>
</div>

<!--{if $list['threadcount']}-->

<!--{loop $list['threadlist'] $key $thread}-->
<!--{eval $threadpic_tid = substr($thread[tid], -1);}-->
<!--{eval $threadpic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$threadpic_tid.'')." WHERE `tid`= $thread[tid] AND isimage = '1' ORDER BY `dateline` DESC limit 0,1");}-->
<div class="yide-thread-list">
    <div class="thread-item cl">
          <!--{if $threadpic}-->
		  <div class="item-pic z">
              <a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
			      <!--{loop $threadpic $thread_pic}-->
                  <!--{eval $thread_pics = getforumimg($thread_pic[aid], 0, 240, 170); }-->
	                  <img src="$thread_pics" style=" width: 100%;">
                  <!--{/loop}-->
              </a>
         </div>
		 <!--{/if}-->
         <div class="item-intro" {if !$threadpic}style="height: auto;margin-left: 0;padding-bottom: 10px;"{/if}>
             <a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="item-title">$thread[subject]</a>
             <div class="item-push-info cl">
	              <div class="ifi-left z"><span><a href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</span></a></div>
                  <div class="ifi-right y">
                      <span><i class="fa fa-eye"></i>$thread[views]</span>
                      <span><i class="fa fa-comments"></i><!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span></span>
                  </div>
             </div>
        </div>
	</div>
</div>
<!--{/loop}-->

<!--{else}-->
	<p style="background-color: #fff;height: 50px;line-height: 50px;padding: 20px 0;text-align: center;font-size: 14px;color: #999;border-top: 1px solid #f0f0f0;">{lang guide_nothreads}</p>
<!--{/if}-->

</div>