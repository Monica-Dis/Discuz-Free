<?php echo 'From: DisM.taobao.com';exit;?>	

<!--{template common/header}-->
<!-- header start -->
<header class="header">
	<div class="nav cl">
		<!--{if $_G['setting']['domain']['app']['mobile']}-->
			{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
		<!--{else}-->
			{eval $nav = "forum.php";}
		<!--{/if}-->
		<div class="header_l z"><a href="javascript:history.back();"><i class="fa fa-angle-left"></i></a></div>
        <span class="category"><span class="name" style="line-height: 34px; font-size: 16px;">����</span></span>
        <div class="header_r y">&nbsp;</div>
	</div>
</header>
<!-- header end -->
<form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
    <!--{subtemplate search/pubsearch}-->

	<!--{eval $policymsgs = $p = '';}-->
	<!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
	!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
	<!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
	<!--{/loop}-->
	<!--{if $policymsgs}--><p>{lang search_credit_msg}</p><!--{/if}-->
</form>

<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}--> 
<!--{else}--> 
<!--{if $_G['setting']['srchhotkeywords']}-->
<div class="yide_scbar_hot">
    <h2>��������</h2>
	<div class="yide_scbar_c cl">
	<ul>
    <!--{loop $_G['setting']['srchhotkeywords'] $val}--> 
        <!--{if $val=trim($val)}--> 
            <!--{eval $valenc=rawurlencode($val);}--> 
            <!--{block srchhotkeywords[]}--> 
                 <!--{if !empty($searchparams[url])}--> 
                     <li><a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}">$val</a></li> 
                 <!--{else}--> 
                     <li><a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch">$val</a></li> 
                 <!--{/if}--> 
            <!--{/block}--> 
        <!--{/if}--> 
    <!--{/loop}--> 
	
    <!--{echo implode('', $srchhotkeywords);}--> 
	</ul>
	</div>
</div>
<!--{/if}--> 
<!--{/if}--> 

<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
	<!--{subtemplate search/thread_list}-->
<!--{/if}-->
<!--{template common/footer}-->
