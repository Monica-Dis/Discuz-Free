<?php echo 'From: DisM.taobao.com';exit;?>	

<!--{template common/header}-->

<!-- header start -->
<header class="header">
    <div class="nav">
	    <div class="header_l z">
		     <a href="javascript:history.back();" class="z"><i class="fa fa-angle-left"></i></a>
		</div>
		<span class="category"><span class="name" style="line-height: 34px; font-size: 16px;">{lang mythread}</span></span>
	    <div class="header_r y">&nbsp;</div>
   </div>
</header>
<!-- header end -->
<!-- main threadlist start -->
<div class="threadlist">
	<ul>
	<!--{if $list}-->
		<!--{loop $list $thread}-->
			<li>
			    <!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
			        <a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]">
			    <!--{else}-->
			        <a href="forum.php?mod=viewthread&tid=$thread[tid]" {if $thread['displayorder'] == -1}class="grey"{/if}>
			    <!--{/if}-->
				<h2>
					{$thread[subject]}
			            <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					       <img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" align="absmiddle" />
				        <!--{/if}-->
				        <!--{if $thread['digest'] > 0}-->
					        <img src="{IMGDIR}/digest_$thread[digest].gif" align="absmiddle" alt="digest" title="{lang thread_digest} $thread[digest]" />
				        <!--{/if}-->
				        <!--{if $thread['attachment'] == 2}-->
					        <img src="{STATICURL}image/filetype/image_s.gif" alt="attach_img" title="{lang attach_img}" align="absmiddle" />
				        <!--{elseif $thread['attachment'] == 1}-->
					        <img src="{STATICURL}image/filetype/common.gif" alt="attachment" title="{lang attachment}" align="absmiddle" />
				        <!--{/if}-->
				   </h2>
				   <div class="yide_auth_msg cl">
                        <span class="yide_txt">$thread[author]</span>      
	                    <span class="yide_txt" style=" color: #bbb;">@</span>
                        <span class="yide_txt">$thread[dateline]</span>
                   </div>
			    </a>
			</li>
		<!--{/loop}-->
	<!--{else}-->
		<li>{lang no_related_posts}</li>
	<!--{/if}-->
	</ul>
	$multi
</div>
<!-- main threadlist end -->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
