<?php echo 'From: DisM.taobao.com';exit;?>	

<!--{template common/header}-->
<!-- header start -->
<header class="header">
    <div class="nav">
		<div class="header_l z">
		     <a href="javascript:history.back();" class="z"><i class="fa fa-angle-left"></i></a>
		</div>
		<!--{if $_GET['type'] == 'forum'}-->
		<span class="category">
			<span class="display name vm" href="#subname_list">
				<h2 class="tit">{lang favforum}</h2>
				<i class="fa fa-angle-down"></i>
			</span>
	        <div id="subname_list" class="subname_list" display="true">
				<ul>
				<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang favthread}</a></li>
				</ul>
	        </div>
		</span>
		<!--{else}-->
		<span class="category">
			<span class="display name vm" href="#subname_list">
				<h2 class="tit">{lang favthread}</h2>
				<i class="fa fa-angle-down"></i>
			</span>
	        <div id="subname_list" class="subname_list" display="true">
				<ul>
				<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=forum">{lang favforum}</a></li>
				</ul>
	        </div>
		</span>
		<!--{/if}-->
		<div class="header_r y">&nbsp;</div>
    </div>
</header>

<!-- main collectlist start -->
<!--{if $_GET['type'] == 'forum'}-->
<div class="coll_list b_radius">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li><a href="$value[url]">$value[title]</a></li>
			<!--{/loop}-->
		<!--{else}-->
		<li>{lang no_favorite_yet}</li>
		<!--{/if}-->

	</ul>
</div>
<!--{else}-->
<div class="threadlist">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li><a href="$value[url]" style="padding: 0;">$value[title]</a></li>
			<!--{/loop}-->
		<!--{else}-->
		<li>{lang no_favorite_yet}</li>
		<!--{/if}-->
	</ul>
</div>
<!--{/if}-->
<!-- main collectlist end -->
$multi
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
