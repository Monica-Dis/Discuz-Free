<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}

$yide_author_thread = C::t('forum_thread')->fetch_all_by_authorid_displayorder($_G[forum_thread][authorid], 0,'>=',  0,  '', 0, 10);

?>