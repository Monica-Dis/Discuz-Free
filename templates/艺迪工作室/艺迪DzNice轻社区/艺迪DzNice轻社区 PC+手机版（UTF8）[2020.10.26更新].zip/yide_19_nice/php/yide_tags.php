<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}

$yiede_tagbg1 = rand(1,8);
$yiede_tagbg2 = rand(1,8);
$yiede_tagbg3 = rand(1,8);
$yiede_tagbg4 = rand(1,8);
$yiede_tagbg5 = rand(1,8);
$yiede_tagbg6 = rand(1,8);
$yiede_tagbg7 = rand(1,8);
$yiede_tagbg8 = rand(1,8);


?>
