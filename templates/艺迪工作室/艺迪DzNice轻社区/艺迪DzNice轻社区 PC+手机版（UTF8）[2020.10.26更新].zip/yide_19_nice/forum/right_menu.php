<?php echo 'From: DisM.taobao.com';exit;?>		      

<div class="tab-hd">				
     <ul class="tab-nav">				
		 <li class="on"><a href="javascript:;">公告</a></li>				
		 <li><a href="javascript:;">社区认证</a></li>								
		 <li><a href="javascript:;" style="border-right: none;">联系我们</a></li>			
	 </ul>		
</div>	

<div class="tab-bd">			
	 <div class="tab-pal">					
		 <ul class="yide_points">							
		     <li> 
				<h2>社区金币</h2> 
				<p class="yide_points_txt">
					<span><i class="left_line"></i>金币可以在社区兑换及消费<i class="right_line bluebg"></i></span>
				</p> 
				<p class="yide_points_btn">
					<a href="http://t.cn/Aiux1012" target="_blank">看看能做啥<em>?</em></a>
					<small class="pipe"></small>
					<a href="http://t.cn/Aiux1012" target="_blank">金币全攻略<em>?</em></a>
				</p> 
			 </li> 
    	  </ul>			
	 </div>			

     <div class="tab-pal">					
		  <ul class="yide_points">							
		      <li> 
				  <h2>尊贵身份</h2> 
				  <p class="yide_points_txt">
					  <span><i class="left_line"></i>认证可获得身份标识及金币奖励<i class="right_line bluebg"></i></span>
				  </p> 
				  <p class="yide_points_btn">
					  <a href="http://t.cn/Aiux1012" target="_blank">认证特权<em>?</em></a>
					  <small class="pipe"></small>
					  <a href="http://t.cn/Aiux1012" target="_blank">立刻认证<em>?</em></a>
				  </p> 
			  </li> 
    	  </ul>			
	 </div>	

	<div class="tab-pal">					
		<ul class="yide_points">							
		     <li> 
				  <h2 style="margin-top: 69px;font-size: 19px;">如有疑问,请留言或邮件咨询 <br>admin@admin.com</h2>
			 </li> 
    	</ul>			
	</div>	
</div>	
