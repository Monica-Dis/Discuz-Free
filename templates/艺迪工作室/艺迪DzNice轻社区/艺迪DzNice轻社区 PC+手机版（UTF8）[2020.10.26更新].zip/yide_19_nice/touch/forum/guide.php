<?php echo 'From: DisM.taobao.com';exit;?>	

<!--{template common/header}-->

<script src="$_G['style'][styleimgdir]/js/jquery.yide.slide.js?{VERHASH}"></script>
<script src="$_G['style']['styleimgdir']/touch/js/touchslide.1.1.js"></script>
<!-- header start -->
<header class="header">
		<div class="nav">
		<!--{if $_G['setting']['domain']['app']['mobile']}-->
			{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
		<!--{else}-->
			{eval $nav = "forum.php";}
		<!--{/if}-->
        <div class="header_l z"><span class="search_btn"><a href="search.php?mod=forum"><i class="fa fa-search"></i></a></span></div>
		<span class="category"><span class="name" style="line-height: 34px; font-size: 24px;">DzNice</span></span>
		<div class="header_r y">
			<a href="forum.php?mod=misc&action=nav&mobile=2"><i class="fa fa-pencil-square-o"></i></a>
		</div>

</header>
<!-- header end -->
<!-- main threadlist start -->

<!--{eval include TPLDIR.'/php/yide_ann.php';}-->

<div id="slideBox" class="slideBox">
    <div class="bd">
	   <ul>
		 <li>
			<a href="#">
			    <div class="pic"><img src="$_G['style']['styleimgdir']/touch/focus/01.png"></div>
			    <div class="txt">在今年最火的教育赛道上</div>
			    <div class="shadow"></div>
			</a>
		 </li>
		 <li>
			<a href="#">
			    <div class="pic"><img src="$_G['style']['styleimgdir']/touch/focus/02.png"></div>
			    <div class="txt">中国新造车公司都做了什么？</div>
			    <div class="shadow"></div>
			</a>
		 </li>
		 <li>
			<a href="#">
			    <div class="pic"><img src="$_G['style']['styleimgdir']/touch/focus/03.png"></div>
			    <div class="txt">继续「不赚钱」的钉钉如何</div>
			    <div class="shadow"></div>
			</a>
		 </li>
		 <li>
			<a href="#">
			    <div class="pic"><img src="$_G['style']['styleimgdir']/touch/focus/04.png"></div>
			    <div class="txt">苹果股价暴跌10%，市值</div>
			    <div class="shadow"></div>
			</a>
		 </li>
	   </ul>
	 </div>

	 <div class="hd">
		 <ul>
		     <li></li>
		 </ul>
	 </div>
</div>

<!--{if empty($gid) && $announces}--> 
  <div id="announces">
    <dl class="cl">
      <dt class="yide_ann_tit z">{lang announcements}</dt>
      <dd>
        <div class="bd">
          <ul>
            $announces
          </ul>
        </div>
      </dd>
    </dl>
  </div>
  <script type="text/javascript">
	jQuery("#announces").slide({ mainCell:".bd ul", effect:"topLoop", autoPlay:true,interTime:3000});
  </script>  
<!--{/if}--> 

	<!--{loop $data $key $list}-->
		<!--{subtemplate forum/guide_list_row}-->
	<!--{/loop}-->

<!-- main threadlist end -->

$multipage

<script type="text/javascript">
		TouchSlide({ 
			slideCell:"#slideBox",
			titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
			mainCell:".bd ul", 
			effect:"leftLoop", 
            autoPage:true,//自动分页
			autoPlay:true //自动播放
	   });
</script>

<!--{template common/footer}-->

