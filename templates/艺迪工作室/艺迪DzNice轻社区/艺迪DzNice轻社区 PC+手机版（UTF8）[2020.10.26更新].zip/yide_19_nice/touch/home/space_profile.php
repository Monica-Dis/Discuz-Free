<?php echo 'From: DisM.taobao.com';exit;?>	

<style type="text/css">
.nav i, .category .name {
    color: #fff !important;
}
</style>

<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !$_GET['mycenter']}-->

<!-- userinfo start -->
<div class="userinfo">
	<div class="user_avatar">
	<!-- header start -->
<header class="header">
	<div class="nav cl" style="background: transparent;border-bottom: 0;box-shadow: none;">
		<div class="header_l z"><a href="javascript:history.back();"><i class="fa fa-angle-left"></i></a></div>
		<span class="category"><span class="name" style="line-height: 34px; font-size: 16px;"><!--{if $_G['uid'] == $space['uid']}-->{lang myprofile}<!--{else}-->$space[username]{lang otherprofile}<!--{/if}--></span></span>
		<div class="header_r y">&nbsp;</div>
	</div>
</header>
<!-- header end -->
	<div class="avatar_m"><span><img src="<!--{avatar($space[uid], middle, true)}-->" /></span></div>
		<h2 class="user_name">$space[username]</h2>
	</div>

<div class="yide_user_box">
  <div class="yide_uesr_list cl">
    <h2 class="mbn"> {$space[username]} 
      <!--{if $_G['ols'][$space[uid]]}--> 
      <img src="{IMGDIR}/ol.gif" alt="online" title="{lang online}" class="vm" />&nbsp; 
      <!--{/if}--> 
      <span class="xw0">(UID: {$space[uid]} 
      <!--{eval $isfriendinfo = 'home_friend_info_'.$space['uid'].'_'.$_G[uid];}--> 
      <!--{if $_G[$isfriendinfo][note]}--> 
      , <span class="xg1">$_G[$isfriendinfo][note]</span> 
      <!--{/if}--> 
      )</span> </h2>
    <div class="yide_uesr_list_box cl">
      <ul class="bbda pbn mbn cl">
        <!--{loop $profiles $value}-->
        <li><em>$value[title]：</em>$value[value]</li>
        <!--{/loop}-->
      </ul>
      <ul class="cl mtn">
        <li> <em>{lang stat_info}：</em> {lang friends_num} $space[friends] 
          <!--{if helper_access::check_module('doing')}--> 
          <span class="pipe">&nbsp;|</span> {lang doings_num} $space[doings] 
          <!--{/if}--> 
          <!--{if helper_access::check_module('blog')}--> 
          <span class="pipe">&nbsp;|</span> {lang blogs_num} $space[blogs] 
          <!--{/if}--> 
          <!--{if helper_access::check_module('album')}--> 
          <span class="pipe">&nbsp;|</span> {lang albums_num} $space[albums] 
          <!--{/if}--> 
          <!--{if $_G['setting']['allowviewuserthread'] !== false}--> 
          <span class="pipe">&nbsp;|</span> 
          <!--{eval $space['posts'] = $space['posts'] - $space['threads'];}--> 
          {lang replay_num} $space[posts] <span class="pipe">&nbsp;|</span> {lang threads_num} $space[threads] 
          <!--{/if}--> 
          <!--{if helper_access::check_module('share')}--> 
          <span class="pipe">&nbsp;|</span> {lang shares_num} $space[sharings] 
          <!--{/if}--> 
        </li>
      </ul>
    </div>
  </div>
  <!--{if $space['medals']}-->
  <div class="yide_uesr_list cl">
    <h2 class="mbn">{lang medals}</h2>
    <div class="yide_uesr_list_box cl">
      <p class="md_ctrl"> 
        <!--{loop $space['medals'] $medal}--> 
        <img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" id="md_{$medal[medalid]}" /> 
        <!--{/loop}--> 
      </p>
    </div>
  </div>
  <!--{/if}--> 
  <!--{if $_G['setting']['verify']['enabled']}--> 
  <!--{eval $showverify = true;}--> 
  <!--{loop $_G['setting']['verify'] $vid $verify}--> 
  <!--{if $verify['available']}--> 
  <!--{if $showverify}-->
  <div class="yide_uesr_list cl">
    <h2 class="mbn">{lang profile_verify}</h2>
    <!--{eval $showverify = false;}-->
    <div class="yide_uesr_list_box cl"> 
      <!--{/if}--> 
      <!--{if $space['verify'.$vid] == 1}--> 
      <!--{if $verify['icon']}--><img src="$verify['icon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{else}-->$verify[title]<!--{/if}-->&nbsp; 
      <!--{elseif !empty($verify['unverifyicon'])}--> 
      <!--{if $verify['unverifyicon']}--><img src="$verify['unverifyicon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{/if}-->&nbsp; 
      <!--{/if}--> 
      <!--{/if}--> 
      <!--{/loop}--> 
      <!--{if !$showverify}--></div>
  </div>
  <!--{/if}--> 
  <!--{/if}--> 
  <!--{if $groupcount}-->
  <div class="yide_uesr_list cl">
    <h2 class="mbn">{lang joined_group}</h2>
    <div class="yide_uesr_list_box cl"> 
      <!--{loop $usergrouplist $key $value}--> 
      <a href="forum.php?mod=group&fid={$value['fid']}" target="_blank">$value['name']</a> &nbsp; 
      <!--{/loop}--> 
    </div>
  </div>
  <!--{/if}-->
  <div class="yide_uesr_list cl" id="psts">
    <h2 class="mbn">{lang stat_info}</h2>
    <div class="yide_uesr_list_box cl">
      <ul class="pf_l">
        <li><em>{lang credits}：</em>$space[credits]</li>
        <!--{loop $_G[setting][extcredits] $key $value}--> 
        <!--{if $value[title]}-->
        <li><em>$value[title]：</em>{$space["extcredits$key"]} $value[unit]</li>
        <!--{/if}--> 
        <!--{/loop}-->
      </ul>
    </div>
  </div>
  <div class="yide_uesr_list cl">
    <h2 class="mbn">{lang active_profile}</h2>
    <div class="yide_uesr_list_box cl">
      <ul>
        <!--{if $space[adminid]}-->
        <li><em>{lang management_team}：</em>{$space[admingroup][grouptitle]}</li>
        <!--{/if}-->
        <li><em>{lang usergroup}：</em>{$space[group][grouptitle]}</li>
        <!--{if $space[extgroupids]}-->
        <li><em>{lang group_expiry_type_ext}：</em>$space[extgroupids]</li>
        <!--{/if}-->
      </ul>
      <ul id="pbbs" class="pf_l">
        <!--{if $space[oltime]}-->
        <li><em>{lang online_time}：</em>$space[oltime] {lang hours}</li>
        <!--{/if}-->
        <li><em>{lang regdate}：</em>$space[regdate]</li>
        <li><em>{lang last_visit}：</em>$space[lastvisit]</li>
        <!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
        <li><em>{lang register_ip}：</em>$space[regip] - $space[regip_loc]</li>
        <li><em>{lang last_visit_ip}：</em>$space[lastip]:$space[port] - $space[lastip_loc]</li>
        <!--{/if}--> 
        <!--{if $space[lastactivity]}-->
        <li><em>{lang last_activity_time}：</em>$space[lastactivity]</li>
        <!--{/if}--> 
        <!--{if $space[lastpost]}-->
        <li><em>{lang last_post_time}：</em>$space[lastpost]</li>
        <!--{/if}--> 
        <!--{if $space[lastsendmail]}-->
        <li><em>{lang last_send_email}：</em>$space[lastsendmail]</li>
        <!--{/if}-->
        <li><em>{lang time_offset}：</em> 
          <!--{eval $timeoffset = array({lang timezone});}--> 
          $timeoffset[$space[timeoffset]] </li>
      </ul>
    </div>
  </div>
</div>

	<!--{if $space['uid'] == $_G['uid']}-->
	<div class="yide_logout_btn">
	    <a class="dialog"href="member.php?mod=logging&action=logout&formhash={FORMHASH}" >{lang logout}{lang login}</a>
	</div>
	<!--{/if}-->
</div>
<!-- userinfo end -->

<!--{else}-->

<!-- userinfo start -->
<div class="userinfo">
	<div class="user_avatar">
	    <!-- header start -->
<header class="header">
	<div class="nav cl" style="background: transparent;border-bottom: 0;box-shadow: none;">
		<!--{if $_G['setting']['domain']['app']['mobile']}-->
			{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
		<!--{else}-->
			{eval $nav = "forum.php";}
		<!--{/if}-->
		<div class="header_l z"><a href="forum.php?mobile=2"><i class="fa fa-angle-left"></i></a></div>
		<span class="category"><span class="name" style="line-height: 34px; font-size: 16px;">个人空间</span></span>
		<div class="header_r y">&nbsp;</div>
	</div>
</header>
<!-- header end -->
		<div class="avatar_m"><span><img src="<!--{avatar($_G[uid], middle, true)}-->" /></span></div>
		<h2 class="user_name">$_G[username]</h2>
	</div>
	<div class="myinfo_list cl">
		<ul>
			<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread"><i class="fa fa-star-o"></i>{lang myfavorite}<i class="fa fa-angle-right"></i></a></li>
			<li><a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me"><i class="fa fa-align-left"></i>{lang mythread}<i class="fa fa-angle-right"></i></a></li>
			<li class="tit_msg"><a href="home.php?mod=space&do=pm"><i class="fa fa-envelope-o"></i>{lang mypm}<i class="fa fa-angle-right"></i></a></li>
			<li><a href="home.php?mod=space&uid={$_G[uid]}"><i class="fa fa-address-card-o"></i>{lang myprofile}<i class="fa fa-angle-right"></i></a></li>
		</ul>
	</div>
	<!--{if $space['uid'] == $_G['uid']}-->
	<div class="yide_logout_btn">
	    <a class="dialog"href="member.php?mod=logging&action=logout&formhash={FORMHASH}" >{lang logout}{lang login}</a>
	</div>
	<!--{/if}-->
</div>
<!-- userinfo end -->

<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

