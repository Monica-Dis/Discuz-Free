<?php echo '�빺�����ӽ�discuz��ҵģ�壬�ͷ�QQ:2413248487';exit;?>
<!--{template common/header}-->
<script type="text/javascript" src="$_G['style']['styleimgdir']/js/jquery.slider.js"></script>

<script type="text/javascript" src="$_G['style']['styleimgdir']/js/jquery.threadlist.js"></script>

<style type="text/css"> 
  .scrollDiv{ height:25px;/* ��ҪԪ�� */line-height:25px;overflow:hidden;/* ��ҪԪ�� */} 
   .scrollDiv li {
    height: 25px;
    margin-left: 80px;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}
   .scrollDiv li span { height:25px;padding-left:10px;} 
      .scrollDiv li em {display: none;}
     .scrollDiv ul,.scrollDiv li{ list-style-type:none;}

	.foucebox {width: 834px;height: 365px;background:#fff;margin:0 auto;}
	.foucebox .bd{position:relative;float:left;width: 670px;height: 365px;overflow:hidden;}
	.foucebox .showDiv {position:relative; width: 670px;height: 365px;}
	.foucebox .showDiv img { width: 670px;height: 365px;}
	.foucebox .showDiv p { position:absolute;left: 0;bottom:0;padding: 0 15px; font-size: 16px;color:#aaa;z-index:9; height:44px; }
	.foucebox .showDiv h2 { position:absolute;left: 0; bottom:0; width:380px;height:34px; padding: 0 15px;font-size: 22px;line-height:34px;z-index:9;overflow:hidden;}
	.foucebox .showDiv h2 a {color:#fff;font-weight:normal;}
	.foucebox .foucebox_bg {position:absolute;left:0;bottom:0;width:670px;height:107px;background:#000;filter:alpha(opacity=60);opacity:0.6;z-index:8;overflow:hidden;}

	.foucebox .hd{width: 145px; height: 365px;float:right;}

.foucebox .hd ul li {
 display:inline; 
 position:relative;
     float:left;
    width: 145px;
    margin-bottom: 12px;
	font-size: 13px;
	font-weight: bold;
	color: #fff;
}
.foucebox .hd ul li+li+li {
    margin-bottom: 13px;
}
.foucebox .hd ul li+li+li+li {
    margin-bottom: 0;
	font-size: 13px;
	font-weight: bold;
	color: #fff;
}
.foucebox .hd ul a {display:block;    width: 125px;height: 68px;padding: 7px 10px; 	font-size: 13px;
	font-weight: bold;
	color: #fff;}

.foucebox .hd ul li.color1 {
	background-color: #75CFD9;
}
.foucebox .hd ul li.color2 {
	background-color: #E4A17E;
}
.foucebox .hd ul li.color3 {
	background-color: #D0838C;
}
.foucebox .hd ul li.color4 {
	background-color: #7CAA77;
}

.foucebox .hd ul li.color1.on {
	background-color: #08a7b9;
}
.foucebox .hd ul li.color2.on{
	background-color: #e5611d;
}
.foucebox .hd ul li.color3.on {
	background-color: #c75663;
}
.foucebox .hd ul li.color4.on {
	background-color: #588753;
}

</style>

<!--{if empty($gid)}-->
	<!--{ad/text/wp a_t}-->
<!--{/if}-->

<style id="diy_style" type="text/css"></style>

<div id="ct" class="wp h2o_forums{if $_G['setting']['forumallowside']} ct2{/if} cl">

   <div class="mainnews box">
       <div class="newsl">       
	       <!--[diy=diyforumslides]--><div id="diyforumslides" class="area"></div><!--[/diy]-->
       </div>
       <div class="newsr y">
	       <!--[diy=diyforumnews]--><div id="diyforumnews" class="area"></div><!--[/diy]-->
       </div>
   </div>

<div class="mn">

<div class="h2o_first_box box cl">
<!--{if empty($gid) && $announcements}-->
<div class="h2o_announcement y cl">
<div id="scrollDiv_keleyi_com" class="scrollDiv"> 
   <div class="z">��������:&nbsp;&nbsp;</div>
   <ul>$announcements</ul> 
</div> 
</div>
<!--{/if}-->
<span class="z"><iframe scrolling="no" src="//tianqiapi.com/api.php?style=td&skin=pitaya" frameborder="0" width="350" height="24" allowtransparency="true"></iframe></span>
</div> 

<!--{if !empty($_G['setting']['grid']['showgrid'])}-->
		<!-- index four grid -->
		<div class="fl bm">
			<div class="bm bmw cl">
				<div id="category_grid" class="bm_c" >
					<table cellspacing="0" cellpadding="0"><tr>
					<!--{if !$_G['setting']['grid']['gridtype']}-->
						<td valign="top" class="category_l1">
							<div class="newimgbox">
								<h4><span class="tit_newimg"></span>{lang latest_images}</h4>
								<div class="module cl slidebox_grid" style="width:218px">
									<script type="text/javascript">
									var slideSpeed = 5000;
									var slideImgsize = [218,200];
									var slideBorderColor = '{$_G['style']['specialborder']}';
									var slideBgColor = '{$_G['style']['commonbg']}';
									var slideImgs = new Array();
									var slideImgLinks = new Array();
									var slideImgTexts = new Array();
									var slideSwitchColor = '{$_G['style']['tabletext']}';
									var slideSwitchbgColor = '{$_G['style']['commonbg']}';
									var slideSwitchHiColor = '{$_G['style']['specialborder']}';
									{eval $k = 1;}
									<!--{loop $grids['slide'] $stid $svalue}-->
										slideImgs[<!--{echo $k}-->] = '$svalue[image]';
										slideImgLinks[<!--{echo $k}-->] = '{$svalue[url]}';
										slideImgTexts[<!--{echo $k}-->] = '$svalue[subject]';
										{eval $k++;}
									<!--{/loop}-->
									</script>
									<script language="javascript" type="text/javascript" src="{$_G[setting][jspath]}forum_slide.js?{VERHASH}"></script>
								</div>
							</div>
						</td>
					<!--{/if}-->
					<td valign="top" class="category_l2">
						<div class="subjectbox">
							<h4><span class="tit_subject"></span>{lang collection_lastthread}</h4>
					        <ul class="category_newlist">
					        	<!--{loop $grids['newthread'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
								<li><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['showtips']} tip="{lang title}: <strong>$thread[oldsubject]</strong><br/>{lang author}: $thread[author] ($thread[dateline])<br/>{lang show}/{lang reply}: $thread[views]/$thread[replies]" onmouseover="showTip(this)"{else} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}>$thread[subject]</a></li>
								<!--{/loop}-->
					         </ul>
				         </div>
					</td>
					<td valign="top" class="category_l3">
						<div class="replaybox">
							<h4><span class="tit_replay"></span>{lang show_newthreads}</h4>
					        <ul class="category_newlist">
					        	<!--{loop $grids['newreply'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
								<li><a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['showtips']}tip="{lang title}: <strong>$thread[oldsubject]</strong><br/>{lang author}: $thread[author] ($thread[dateline])<br/>{lang show}/{lang reply}: $thread[views]/$thread[replies]" onmouseover="showTip(this)"{else} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}>$thread[subject]</a></li>
								<!--{/loop}-->
					         </ul>
				         </div>
					</td>
					<td valign="top" class="category_l3">
						<div class="hottiebox">
							<h4><span class="tit_hottie"></span>{lang hot_thread}</h4>
					        <ul class="category_newlist">
					        	<!--{loop $grids['hot'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
								<li><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['showtips']} tip="{lang title}: <strong>$thread[oldsubject]</strong><br/>{lang author}: $thread[author] ($thread[dateline])<br/>{lang show}/{lang reply}: $thread[views]/$thread[replies]" onmouseover="showTip(this)"{else} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}>$thread[subject]</a></li>
								<!--{/loop}-->
					         </ul>
				         </div>
					</td>
					<!--{if $_G['setting']['grid']['gridtype']}-->
						<td valign="top" class="category_l4">
							<div class="goodtiebox">
								<h4><span class="tit_goodtie"></span>{lang post_digest_thread}</h4>
								<ul class="category_newlist">
									<!--{loop $grids['digest'] $thread}-->
										<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
											<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
										<li><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['showtips']} tip="{lang title}: <strong>$thread[oldsubject]</strong><br/>{lang author}: $thread[author] ($thread[dateline])<br/>{lang show}/{lang reply}: $thread[views]/$thread[replies]" onmouseover="showTip(this)"{else} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}>$thread[subject]</a></li>
									<!--{/loop}-->
								 </ul>
						 	</div>
						</td>
					<!--{/if}-->
					</table>
				</div>
			</div>
		</div>
		<!-- index four grid end -->
	<!--{/if}-->


<!--{if empty($gid)}-->
		<div id="chart" class="bm h2o_chart cl">
			<p class="chart z">{lang index_today}: <em>$todayposts</em><span class="pipe">|</span>{lang index_yesterday}: <em>$postdata[0]</em><span class="pipe">|</span>{lang index_posts}: <em>$posts</em><span class="pipe">|</span>{lang index_members}: <em>$_G['cache']['userstats']['totalmembers']</em><!--{if $_G['cache']['userstats']['newsetuser']}--><span class="pipe">|</span>{lang welcome_new_members}: <em><a href="home.php?mod=space&username={echo rawurlencode($_G['cache']['userstats']['newsetuser'])}" target="_blank" class="xi2">$_G['cache']['userstats']['newsetuser']</a></em><!--{/if}--></p>
			<div class="y">
				<!--{hook/index_nav_extra}-->
				<!--{hook/index_status_extra}-->
				<!--{if $_G['uid']}--><a href="forum.php?mod=guide&view=my" title="{lang my_posts}" class="xi2">{lang my_posts}</a><!--{/if}--><!--{if !empty($_G['setting']['search']['forum']['status'])}--><!--{if $_G['uid']}--><span class="pipe">|</span><!--{/if}--><a href="forum.php?mod=guide&view=new" title="{lang show_newthreads}" class="xi2">{lang show_newthreads}</a><!--{/if}-->
			</div>
		</div>
<!--{/if}-->

<!--{hook/index_top}-->

		<!--{if !empty($_G['cache']['heats']['message'])}-->
			<div class="bm">
				<div class="bm_h cl">
					<h2>{lang hotthreads_forum}</h2>
				</div>
				<div class="bm_c cl">
					<div class="heat z">
						<!--{loop $_G['cache']['heats']['message'] $data}-->
							<dl class="xld">
								<dt><!--{if $_G['adminid'] == 1}--><a class="d" href="forum.php?mod=misc&action=removeindexheats&tid=$data[tid]" onclick="return removeindexheats()">delete</a><!--{/if}-->
								<a href="forum.php?mod=viewthread&tid=$data[tid]" target="_blank" class="xi2">$data[subject]</a></dt>
								<dd>$data[message]</dd>
							</dl>
						<!--{/loop}-->
					</div>
					<ul class="xl xl1 heatl">
					<!--{loop $_G['cache']['heats']['subject'] $data}-->
						<li><!--{if $_G['adminid'] == 1}--><a class="d" href="forum.php?mod=misc&action=removeindexheats&tid=$data[tid]" onclick="return removeindexheats()">delete</a><!--{/if}-->&middot; <a href="forum.php?mod=viewthread&tid=$data[tid]" target="_blank" class="xi2">$data[subject]</a></li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
		<!--{/if}-->

		<!--{hook/index_catlist_top}-->
		<div class="h2o-forumlist-fl cl">
			<!--{if !empty($collectiondata['follows'])}-->

			<!--{eval $forumscount = count($collectiondata['follows']);}-->
			<!--{eval $forumcolumns = 4;}-->

			<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->

			<div class="bm bmw {if $forumcolumns} flg{/if} cl">
				<div class="bm_h cl">
					<span class="o">
						<img id="category_-1_img" src="{IMGDIR}/$collapse['collapseimg_-1']" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_-1');" />
					</span>
					<h2><a href="forum.php?mod=collection&op=my">{lang my_order_collection}</a></h2>
				</div>
				<div id="category_-1" class="bm_c" style="{echo $collapse['category_-1']}">
					<table cellspacing="0" cellpadding="0" class="fl_tb">
						<tr>
						<!--{eval $ctorderid = 0;}-->
						<!--{loop $collectiondata['follows'] $key $colletion}-->
							<!--{if $ctorderid && ($ctorderid % $forumcolumns == 0)}-->
								</tr>
								<!--{if $ctorderid < $forumscount}-->
									<tr class="fl_row">
								<!--{/if}-->
							<!--{/if}-->
							<td class="fl_g"{if $forumcolwidth} width="$forumcolwidth"{/if}>
								<div class="fl_icn_g">
								<a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}" target="_blank"><img src="{IMGDIR}/forum{if $followcollections[$key]['lastvisit'] < $colletion['lastupdate']}_new{/if}.gif" alt="$colletion[name]" /></a>
								</div>
								<dl>
									<dt><a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}">$colletion[name]</a></dt>
									<dd><em>{lang forum_threads}: <!--{echo dnumber($colletion[threadnum])}--></em>, <em>{lang collection_commentnum}: <!--{echo dnumber($colletion[commentnum])}--></em></dd>
									<dd>
									<!--{if $colletion['lastpost']}-->
										<!--{if $forumcolumns < 3}-->
											<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($colletion[lastsubject], 30)}--></a> <cite><!--{date($colletion[lastposttime])}--> <!--{if $colletion['lastposter']}-->$colletion['lastposter']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>
										<!--{else}-->
											<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost">{lang forum_lastpost}: <!--{date($colletion[lastposttime])}--></a>
										<!--{/if}-->
									<!--{else}-->
										{lang never}
									<!--{/if}-->
									</dd>
									<!--{hook/index_followcollection_extra $colletion[ctid]}-->
								</dl>
							</td>
							<!--{eval $ctorderid++;}-->

						<!--{/loop}-->
						<!--{if ($columnspad = $ctorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->
						</tr>
					</table>

				</div>
			</div>

			<!--{/if}-->
			<!--{if empty($gid) && !empty($forum_favlist)}-->
			<!--{eval $forumscount = count($forum_favlist);}-->
			<!--{eval $forumcolumns = $forumscount > 1 ? ($forumscount == 4 ? 2 : 2) : 1;}-->

			<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->

			<div class="h2o-forumlist-chunk {if $forumcolumns} flg{/if} cl">
				<div class="h2o-forumlist-gid cl">
					<span class="y">
						<img id="category_0_img" src="{IMGDIR}/$collapse['collapseimg_0']" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_0');" />
					</span>
					<h2 style="position: relative;float: left;font-size: 16px;font-weight: 400;">{lang forum_myfav}<a href="home.php?mod=space&do=favorite&type=forum" style="position: absolute;top: 1px;left: 102px;font-size: 12px;font-weight: 400;"><span class="xi2">( ������� )</span></a></h2>
				</div>
			<div id="category_0" class="h2o-forumlist-box" style="{echo $collapse['category_0']}">
					<table cellspacing="0" cellpadding="0">
						<tr>
						<!--{eval $favorderid = 0;}-->
						<!--{loop $forum_favlist $key $favorite}-->
						<!--{if $favforumlist[$favorite[id]]}-->
						<!--{eval $forum=$favforumlist[$favorite[id]];}-->
						<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
							<!--{if $forumcolumns>1}-->
								<!--{if $favorderid && ($favorderid % $forumcolumns == 0)}-->
									</tr>
									<!--{if $favorderid < $forumscount}-->
										<tr class="fl_row">
									<!--{/if}-->
								<!--{/if}-->
						<td class="fl_g"{if $forumcolwidth} width="$forumcolwidth"{/if}>
							 <table border="0" cellspacing="0" cellpadding="0">
                                 <tr>
                                  <td class="h2o-forumlist-icon">
								        <!--{if $forum[icon]}-->
									        $forum[icon]
								        <!--{else}-->
									        <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
								        <!--{/if}-->
							      </td>

								  <td class="h2o-forumlist-content">
									 <div class="h2o-forumlist-tit">
										 <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a><!--{if $forum[todayposts] && !$forum['redirect']}--><em class="xw0 xi1" title="{lang forum_todayposts}">$forum[todayposts]</em><!--{/if}-->
									 </div>

									 <div class="h2o-forumlist-desc"><!--{if $forum[description]}-->  $forum[description]<!--{else}-->���ް����<!--{/if}--></div>

                                     <!--{if empty($forum[redirect])}-->
                                         <div class="h2o-forumlist-count">
                                              <em>{lang forum_threads}: <span class="xi2"><!--{echo dnumber($forum[threads])}--></span></em> 
											  <span class="pipe">|</span>
	                                          <em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em>
                                         </div>
                                     <!--{/if}-->

									 <!--{hook/index_favforum_extra $forum[fid]}-->

								   </td>
                                </tr>
                            </table>	
                         </td>
                       
						 <!--{eval $favorderid++;}-->
						 <!--{else}-->
                         <td class="h2o-forumlist-icon">
							 <!--{if $forum[icon]}-->
								 $forum[icon]
							 <!--{else}-->
								 <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
							 <!--{/if}-->
						  </td>

						  <td class="h2o-forumlist-content">
							  <div class="h2o-forumlist-tit">
								  <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a><!--{if $forum[todayposts] && !$forum['redirect']}--><em class="xw0 xi1" title="{lang forum_todayposts}">$forum[todayposts]</em><!--{/if}-->
								  <!--{hook/index_favforum_extra $forum[fid]}-->
							  </div>

							  <div class="h2o-forumlist-desc"><!--{if $forum[description]}-->  $forum[description]<!--{else}-->���ް����<!--{/if}--></div>

							  <!--{if $forum['moderators']}--><div class="h2o-forumlist-moderators">{lang forum_moderators}: <span class="xi2">$forum[moderators]</span></div><!--{/if}-->
								<!--{hook/index_forum_extra $forum[fid]}-->
							</td>

							<td class="h2o-forumlist-countfirst">
								<!--{if empty($forum[redirect])}--><span class="xi2"><!--{echo dnumber($forum[threads])}--></span><span class="xg1"> / <!--{echo dnumber($forum[posts])}--></span><!--{/if}-->
							</td>

							<td class="h2o-forumlist-lastpost">
								<!--{if $forum['permission'] == 1}-->
									{lang private_forum}
								<!--{else}-->
									<!--{if $forum['redirect']}-->
										<cite><a href="$forumurl" class="xi2">{lang url_link}</a></cite>
									<!--{elseif is_array($forum['lastpost'])}-->
										<cite><a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a></cite> 
										<div class="lastdate">$forum[lastpost][dateline] <!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}-->
										</div>
									<!--{else}-->
										{lang never}
									<!--{/if}-->
								<!--{/if}-->
							</td>
							</tr>
							<tr class="fl_row">

							<!--{/if}-->
						<!--{/if}-->
						<!--{/loop}-->
						<!--{if ($columnspad = $favorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->
						</tr>
					</table>

				</div>
			</div>
			<!--{ad/intercat/bm a_c/-1}-->
		<!--{/if}-->

		<!--{loop $catlist $key $cat}-->
			<!--{hook/index_catlist $cat[fid]}-->
			<div class="h2o-forumlist-chunk {if $cat['forumcolumns']}flg{/if} cl">
				<div class="h2o-forumlist-gid cl">
					<span class="y" style="cursor:pointer;">
						<img id="category_$cat[fid]_img" src="{IMGDIR}/$cat[collapseimg]" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_$cat[fid]');" />
					</span>
					<!--{if $cat['moderators']}--><span class="y" style="margin-right: 12px;">{lang forum_category_modedby}: $cat[moderators]</span><!--{/if}-->
					<!--{eval $caturl = !empty($cat['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$cat['domain'].'.'.$_G['setting']['domain']['root']['forum'] : '';}-->
					<h2><a href="{if !empty($caturl)}$caturl{else}forum.php?gid=$cat[fid]{/if}" style="{if $cat[extra][namecolor]}color: {$cat[extra][namecolor]};{/if}">$cat[name]</a></h2>
				</div>
				<div id="category_$cat[fid]" class="h2o-forumlist-box" style="{echo $collapse['category_'.$cat[fid]]}">
					<table cellspacing="0" cellpadding="0">
						<tr>
						<!--{loop $cat[forums] $forumid}-->
						<!--{eval $forum=$forumlist[$forumid];}-->
						<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->

						<!--{if $cat['forumcolumns']}-->
							<!--{if $forum['orderid'] && ($forum['orderid'] % $cat['forumcolumns'] == 0)}-->
								</tr>
								<!--{if $forum['orderid'] < $cat['forumscount']}-->
									<tr class="fl_row">
								<!--{/if}-->
							<!--{/if}-->
                            
					 <td class="fl_g" width="$cat[forumcolwidth]">
							<table border="0" cellspacing="0" cellpadding="0">
                                 <tr>
                                     <td class="h2o-forumlist-icon">
								        <!--{if $forum[icon]}-->
									        $forum[icon]
								        <!--{else}-->
									        <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
								        <!--{/if}-->
							         </td>
                                     <td class="h2o-forumlist-content">
									     <div class="h2o-forumlist-tit">
									         <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a><!--{if $forum[todayposts] && !$forum['redirect']}--><em class="xw0 xi1" title="{lang forum_todayposts}">$forum[todayposts]</em><!--{/if}-->
									     </div>

                                         <div class="h2o-forumlist-desc"><!--{if $forum[description]}-->  $forum[description]<!--{else}-->���ް����<!--{/if}--></div>

                                         <!--{if empty($forum[redirect])}-->
                                         <div class="h2o-forumlist-count">
                                              <em>{lang forum_threads}: <span class="xi2"><!--{echo dnumber($forum[threads])}--></span></em> 
											  <span class="pipe">|</span>
	                                          <em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em>
                                         </div>
                                         <!--{/if}-->

									     <!--{hook/index_forum_extra $forum[fid]}-->
								
							           </td>
                                   </tr>
                              </table>	
						 </td>

						<!--{else}-->

                         <td class="h2o-forumlist-icon">
							 <!--{if $forum[icon]}-->
								 $forum[icon]
							 <!--{else}-->
								 <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
							 <!--{/if}-->
						  </td>

						  <td class="h2o-forumlist-content">
							  <div class="h2o-forumlist-tit">
								  <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a><!--{if $forum[todayposts] && !$forum['redirect']}--><em class="xw0 xi1" title="{lang forum_todayposts}">$forum[todayposts]</em><!--{/if}-->
							  </div>

							  <div class="h2o-forumlist-desc"><!--{if $forum[description]}-->  $forum[description]<!--{else}-->���ް����<!--{/if}--></div>

							  <!--{if $forum['moderators']}--><div class="h2o-forumlist-moderators">{lang forum_moderators}: <span class="xi2">$forum[moderators]</span></div><!--{/if}-->
								<!--{hook/index_forum_extra $forum[fid]}-->
							</td>

							<td class="h2o-forumlist-countfirst">
								<!--{if empty($forum[redirect])}--><span class="xi2"><!--{echo dnumber($forum[threads])}--></span><span class="xg1"> / <!--{echo dnumber($forum[posts])}--></span><!--{/if}-->
							</td>

							<td class="h2o-forumlist-lastpost">
								<!--{if $forum['permission'] == 1}-->
									{lang private_forum}
								<!--{else}-->
									<!--{if $forum['redirect']}-->
										<cite><a href="$forumurl" class="xi2">{lang url_link}</a></cite>
									<!--{elseif is_array($forum['lastpost'])}-->
										<cite><a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a></cite> 
										<div class="lastdate">$forum[lastpost][dateline] <!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}-->
										</div>
									<!--{else}-->
										{lang never}
									<!--{/if}-->
								<!--{/if}-->
							</td>
						</tr>
						<tr class="fl_row">
						<!--{/if}-->
						<!--{/loop}-->
						$cat['endrows']

						</tr>
					</table>
				</div>
			</div>
			<!--{ad/intercat/bm a_c/$cat[fid]}-->
		<!--{/loop}-->
			<!--{if !empty($collectiondata['data'])}-->

			<!--{eval $forumscount = count($collectiondata['data']);}-->
			<!--{eval $forumcolumns = 4;}-->

			<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->

			<div class="bm bmw {if $forumcolumns} flg{/if} cl">
				<div class="bm_h cl">
					<span class="o">
						<img id="category_-2_img" src="{IMGDIR}/$collapse['collapseimg_-2']" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_-2');" />
					</span>
					<h2><a href="forum.php?mod=collection">{lang recommend_collection}</a></h2>
				</div>
				<div id="category_-2" class="bm_c" style="{echo $collapse['category_-2']}">
					<table cellspacing="0" cellpadding="0" class="fl_tb">
						<tr>
						<!--{eval $ctorderid = 0;}-->
						<!--{loop $collectiondata['data'] $key $colletion}-->
							<!--{if $ctorderid && ($ctorderid % $forumcolumns == 0)}-->
								</tr>
								<!--{if $ctorderid < $forumscount}-->
									<tr class="fl_row">
								<!--{/if}-->
							<!--{/if}-->
							<td class="fl_g"{if $forumcolwidth} width="$forumcolwidth"{/if}>
								<div class="fl_icn_g">
								<a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}" target="_blank"><img src="{IMGDIR}/forum.gif" alt="$colletion[name]" /></a>
								</div>
								<dl>
									<dt><a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}">$colletion[name]</a></dt>
									<dd><em>{lang forum_threads}: <!--{echo dnumber($colletion[threadnum])}--></em>, <em>{lang collection_commentnum}: <!--{echo dnumber($colletion[commentnum])}--></em></dd>
									<dd>
									<!--{if $colletion['lastpost']}-->
										<!--{if $forumcolumns < 3}-->
											<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($colletion[lastsubject], 30)}--></a> <cite><!--{date($colletion[lastposttime])}--> <!--{if $colletion['lastposter']}-->$colletion['lastposter']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>
										<!--{else}-->
											<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost">{lang forum_lastpost}: <!--{date($colletion[lastposttime])}--></a>
										<!--{/if}-->
									<!--{else}-->
										{lang never}
									<!--{/if}-->
									</dd>
									<!--{hook/index_datacollection_extra $colletion[ctid]}-->
								</dl>
							</td>
							<!--{eval $ctorderid++;}-->

						<!--{/loop}-->
						<!--{if ($columnspad = $ctorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->
						</tr>
					</table>

				</div>
			</div>

			<!--{/if}-->

		</div>

		<!--{hook/index_middle}-->
		<div class="wp">
			<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
		</div>

		<!--{if empty($gid) && $_G['setting']['whosonlinestatus']}-->
			<div id="online" class="bm oll box" style=" margin-bottom: 16px;">
				<div class="bm_h" style="background: #F2F2F2;height: 40px;line-height: 45px;padding: 0 10px;border: solid #eee;border-width: 0 0 1px;">
				<!--{if $detailstatus}-->
					<span class="o"><a href="forum.php?showoldetails=no#online" title="{lang spread}"><img src="{IMGDIR}/collapsed_no.gif" alt="{lang spread}" style="margin-top: 11px;" /></a></span>
					<h3 style="font-size: 16px;font-weight: 400;">
						<a href="home.php?mod=space&do=friend&view=online&type=member" style="font-weight: 400;">{lang onlinemember}</a>
						<span style="font-size: 12px;color: #777;font-weight: 400;">- <strong>$onlinenum</strong> {lang onlines}
						- <strong>$membercount</strong> {lang index_members}(<strong>$invisiblecount</strong> {lang index_invisibles}),
						<strong>$guestcount</strong> {lang index_guests}
						- {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>
					</h3>
				<!--{else}-->
					<!--{if empty($_G['setting']['sessionclose'])}-->
						<span class="o"><a href="forum.php?showoldetails=yes#online" title="{lang spread}"><img src="{IMGDIR}/collapsed_yes.gif" alt="{lang spread}" /></a></span>
					<!--{/if}-->
					<h3>
						<strong>
							<!--{if !empty($_G['setting']['whosonlinestatus'])}-->
								{lang onlinemember}
							<!--{else}-->
								<a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a>
							<!--{/if}-->
						</strong>
						<span class="xs1">- {lang total} <strong>$onlinenum</strong> {lang onlines}
						<!--{if $membercount}-->- <strong>$membercount</strong> {lang index_members},<strong>$guestcount</strong> {lang index_guests}<!--{/if}-->
						- {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>
					</h3>
				<!--{/if}-->
				</div>
			<!--{if $_G['setting']['whosonlinestatus'] && $detailstatus}-->
				<dl id="onlinelist" class="bm_c" style="padding: 10px 15px;">
					<dt class="ptm pbm bbda">$_G[cache][onlinelist][legend]</dt>
					<!--{if $detailstatus}-->
						<dd class="ptm pbm">
						<ul class="cl">
						<!--{if $whosonline}-->
							<!--{loop $whosonline $key $online}-->
								<li title="{lang time}: $online[lastactivity]">
								<img src="{STATICURL}image/common/$online[icon]" alt="icon" />
								<!--{if $online['uid']}-->
									<a href="home.php?mod=space&uid=$online[uid]">$online[username]</a>
								<!--{else}-->
									$online[username]
								<!--{/if}-->
								</li>
							<!--{/loop}-->
						<!--{else}-->
							<li style="width: auto">{lang online_only_guests}</li>
						<!--{/if}-->
						</ul>
					</dd>
					<!--{/if}-->
				</dl>
			<!--{/if}-->
			</div>
		<!--{/if}-->

		<!--{if empty($gid) && ($_G['cache']['forumlinks'][0] || $_G['cache']['forumlinks'][1] || $_G['cache']['forumlinks'][2])}-->
		<div class="bm lk">
			<div id="category_lk" class="bm_c ptm">
				<!--{if $_G['cache']['forumlinks'][0]}-->
					<ul class="m mbn cl">$_G['cache']['forumlinks'][0]</ul>
				<!--{/if}-->
				<!--{if $_G['cache']['forumlinks'][1]}-->
					<div class="mbn cl">
						$_G['cache']['forumlinks'][1]
					</div>
				<!--{/if}-->
				<!--{if $_G['cache']['forumlinks'][2]}-->
					<ul class="x mbm cl">
						$_G['cache']['forumlinks'][2]
					</ul>
				<!--{/if}-->
			</div>
		</div>
		<!--{/if}-->

		<!--{hook/index_bottom}-->
	</div>

<!--{if $_G['setting']['forumallowside']}-->
<div id="sd" class="sd">

<div class="h2o_diy_box cl">
   <ul class="signIn box cl" style="width: 308px;margin: 16px 0;">
        <li>
        	<a href="forum.php?mod=misc&amp;action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="ftTit">
    			<div class="ftTit_icon z"></div>
    			<div class="ftTit_title z">����</div>
        	</a>
        </li>
        <li>
            <a href="#" class="qdTit">
                <div class="qdTit_icon z"></div>
    			<div class="qdTit_title z">��ע</div>
	        </a>
        </li>
    </ul>
 </div>

   <!--{hook/index_side_top}-->
   
	<div class="h2o_diy_box cl">
		<!--[diy=diyforumlisthy]--><div id="diyforumlisthy" class="area"></div><!--[/diy]-->
    </div>

	<div class="h2o_diy_box cl">
		<!--[diy=diyforumlisthot]--><div id="diyforumlisthot" class="area"></div><!--[/diy]-->
    </div>

	<!--{subtemplate common/about}-->

	<div class="h2o_diy_box cl">
		<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
	</div>
	
    <!--{hook/index_side_bottom}-->

</div>

<!--{/if}-->

</div>
<!--{if $_G['group']['radminid'] == 1}-->
	<!--{eval helper_manyou::checkupdate();}-->
<!--{/if}-->
<!--{if empty($_G['setting']['disfixednv_forumindex']) }--><script>fixed_top_nv();</script><!--{/if}-->

<script type="text/javascript"> 
function AutoScroll(obj){ 
jQuery(obj).find("ul:first").animate({ 
marginTop:"-25px" 
},500,function(){ 
jQuery(this).css({marginTop:"0px"}).find("li:first").appendTo(this); 
}); 
} 
jQuery(document).ready(function(){ 
setInterval('AutoScroll("#scrollDiv_keleyi_com")',3500); 
}); 
</script> 

<script type="text/javascript">
		jQuery(".foucebox").slide({ effect:"fold", autoPlay:true, delayTime:300, startFun:function(i){
				//����������������ʾ
				jQuery(".foucebox .showDiv").eq(i).find("h2").css({display:"none",bottom:0}).animate({opacity:"show",bottom:"60px"},300);
				jQuery(".foucebox .showDiv").eq(i).find("p").css({display:"none",bottom:0}).animate({opacity:"show",bottom:"10px"},300);
			}
		});

	jQuery('.layout01 .hotInfor .list ul li').hover(function () {
        jQuery(this).addClass('on').siblings().removeClass('on');
    });

</script>
<!--{template common/footer}-->
