<?php echo '�빺�����ӽ�discuz��ҵģ�壬�ͷ�QQ:2413248487';exit;?>
<!--{if $_G['uid']}-->
<div class="h2o_ad_user z cl">

<div id="h2o_pm_ntc" class="h2o-top-rightbox z">  
   <!--{eval settype($_G[member][newprompt], 'integer');}-->
   <!--{eval settype($_G[member][newpm], 'integer');}-->
   <!--{eval $noticenum = $_G[member][newprompt] + $_G[member][newpm];}-->
   <span class="h2o-top-rightcontent">��Ϣ<!--{if $_G[member][newprompt] || $_G[member][newpm]}-->($noticenum)<!--{/if}--></span>
    <div class="dropdown-menu xxcontent">
      <ul>
          <li><a href="home.php?mod=space&do=pm" rel="nofollow">��Ϣ<!--{if $_G[member][newpm]}--><i>($_G[member][newpm])</i><!--{/if}--></a></li>	
		  <li><a href="home.php?mod=space&do=notice" rel="nofollow">����<!--{if $_G[member][newprompt]}--><i>($_G[member][newprompt])</i><!--{/if}--></a></li>
		  <li><a href="home.php?mod=space&do=notice&view=interactive&type=comment" rel="nofollow">���ҵ�����</a></li>
		  <li><a href="home.php?mod=space&do=notice&view=interactive&type=wall" rel="nofollow">���ҵ�����</a></li>
		  <li><a href="home.php?mod=space&do=notice&view=system" rel="nofollow">ϵͳ����</a></li>
	  </ul>
    </div>
</div>

<div id="h2o-userpanel" class="h2o-top-rightbox y">
   <span class="h2o-top-rightcontent" title="$_G[member][username]" style=" padding: 0 5px;"><!--{avatar($_G[uid],small)}--><a href="home.php?mod=space&uid=$_G[uid]">$_G[member][username]</a></span>
   
   <div class="dropdown-menu usercontent">
      <ul>
	     <li><a href="forum.php?mod=guide&view=my">�ҵ�����</a></li>
		 <li><a href="home.php?mod=space&do=favorite&view=me">�ҵ��ղ�</a></li>
		 <!--{if check_diy_perm($topic)}-->
			<li><a href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();">DIY�༭</a></li>
		 <!--{/if}-->
		 <li><a href="home.php?mod=spacecp">�˺�����</a></li>
		 <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
		 <li><a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
		<!--{/if}-->
         <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
         <li><a rel="nofollow" href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>
         <!--{/if}-->
         <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
         <li><a rel="nofollow" href="admin.php" target="_blank">��̨����</a></li>
         <!--{/if}-->

		 <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">��ȫ�˳�</a></li>
	  </ul>
    </div>
</div>

</div>

<!--{elseif !empty($_G['cookie']['loginuser'])}-->
<p>
	<strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
</p>
<!--{elseif !$_G[connectguest]}-->


<!--{if CURMODULE != 'logging'}-->
   <script type="text/javascript" src="{$_G[setting][jspath]}logging.js?{VERHASH}"></script>
<div class="z cl">
   <form method="post" autocomplete="off" id="lsform" action="member.php?mod=logging&action=login&loginsubmit=yes&infloat=yes&lssubmit=yes" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('ls_password');{/if}return lsSubmit();">
       <span id="return_ls" style="display:none"></span>
       <input type="hidden" name="fastloginfield" value="username">

       <input type="text" tabindex="901" name="username" id="ls_username" autocomplete="off" class="h2o-ls-prefix" onblur="if(this.value == ''){this.value = '�������û���';}" onfocus="if(this.value == '�������û���'){this.value = '';}" value="�������û���"/>
       <input type="password" tabindex="902" name="password" id="ls_password" class="h2o-ls-prefix" autocomplete="off" placeholder="����������" />
       <label for="ls_cookietime"><input type="checkbox" tabindex="903"name="cookietime" id="ls_cookietime" class="pc" value="2592000" />{lang login_permanent}</label>&nbsp;
	   <a href="javascript:;" onclick="showWindow('login', 'member.php?mod=logging&action=login&viewlostpw=1')">{lang forgotpw}</a>
       
	   <button type="submit" class="orange" tabindex="904"><em>��¼</em></button>
       <button type="button" class="white" onclick="window.location.href='member.php?mod={$_G[setting][regname]}'" ><em>ע��</em></button>
       <input type="hidden" name="quickforward" value="yes" />
       <input type="hidden" name="handlekey" value="ls" />
    </form>
</div>
<!--{if $_G['setting']['pwdsafety']}-->
       <script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
    <!--{/if}-->
<!--{/if}-->


<!--{else}-->

<div class="h2o_ad_user z cl">

<div id="h2o_pm_ntc" class="h2o-top-rightbox z">  
   <span class="h2o-top-rightcontent">$_G[member][username]</span>
    <div class="dropdown-menu xxcontent">
      <ul>
		  <li><a href="member.php?mod=connect" target="_blank" rel="nofollow">�����ʺ���Ϣ</a></li>	
		  <li><a href="member.php?mod=connect&amp;ac=bind" target="_blank" rel="nofollow">�������ʺ�</a></li>
		  <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">��ȫ�˳���¼</a></li>
	  </ul>
    </div>
</div>

</div>

<!--{/if}-->