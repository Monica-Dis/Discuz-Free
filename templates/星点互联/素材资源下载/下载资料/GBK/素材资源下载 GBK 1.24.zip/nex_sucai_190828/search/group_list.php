<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<div>
	<!--{ad/search/y mtw}-->
<!--{if $viewgroup}-->
	<!--{if empty($grouplist)}-->
		<div class="nex_emp_notice">
        	<em></em>
            <h5>{lang search_nomatch}</h5>
        </div>
	<!--{else}-->
		<div class="nex_view_grouplist nex_group_list">
        	<ul>
			<!--{loop $grouplist $group}-->
				<li>
					<div class="nex_grouppic_cover"><a href="forum.php?mod=group&fid=$group[fid]" target="_blank"><img src="$group[icon]" alt="" /></a></div>
                    <div class="nex_group_intels">
                    	<h5><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><!--{if $group['gviewperm'] == 1}-->({lang public})<!--{/if}--></h5>
                        <p>{lang member}: $group[membernum], {lang threads}: $group[threads]</p>
                        <p>{lang credits}: $group[commoncredits], {lang creating_time}: $group[dateline]</p>
                    </div>
                    <div class="clear"></div>
				</li>
			<!--{/loop}-->
            <div class="clear"></div>
            </ul>
		</div>
		<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
	<!--{/if}-->
<!--{else}-->
	<!--{if !empty($grouplist) && $page < 2}-->
		<div class="nex_group_list">
        	<ul>
			<!--{loop $grouplist $group}-->
				<li>
					<div class="nex_grouppic_cover"><a href="forum.php?mod=group&fid=$group[fid]" target="_blank"><img src="$group[icon]" alt="" /></a></div>
					<div class="nex_group_intels">
                    	<h5><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><!--{if $group['gviewperm'] == 1}-->({lang public})<!--{/if}--></h5>
                        <p>{lang member}: $group[membernum], {lang threads}: $group[threads]</p>
                        <p>{lang credits}: $group[commoncredits], {lang creating_time}: $group[dateline]</p>
                    </div>
                    <div class="clear"></div>
				</li>
			<!--{/loop}-->
            <div class="clear"></div>
            </ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($threadlist)}-->
		<div class="nex_groupthreadlist">
			<ul>
				<!--{loop $threadlist $thread}-->
                <!--{eval include 'template/nex_sucai_190828/php/nex_multiops.php'}-->
                <li>
                    <!--{if $nex_threadlistspic}-->
                    <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
                    <div class="nex_group_showpics"><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank"  style=" background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></a></div>
                    <!--{/loop}-->
                    <div class="nex_group_showinfos">
                        <h3><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">$thread[subject]</a></h3>
                        <div class="nex_showfrom"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$thread[forumname]</a></div>
                        <div class="nex_showbtms">
                        	<div class="nex_showavator">
                            	<!--{if $thread['authorid'] && $thread['author']}-->
								<a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">
                                	<!--{avatar($thread[authorid],small)}-->
                                	<em>$thread[author]</em>
                                    <div class="clear"></div>
                                </a>
                                <!--{else}-->
                                    <!--{if $_G['forum']['ismoderator']}-->
                                    <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">
                                    	<img src="$_G['style'][styleimgdir]/search/anonymous.png" />
                                        <em>{lang anonymous}</em>
                                        <div class="clear"></div>
                                    </a>
                                    <!--{else}-->
                                    <em>{lang anonymous}</em>
                                    <div class="clear"></div>
                                    <!--{/if}-->
                                <!--{/if}-->
                            </div>
                            <div class="nex_showintels">
                                <span class="nex_showintels_view">$thread[views]{lang a_visit}</span>
                                <span class="nex_showintels_reply">$thread[replies]{lang a_comment_thread}</span>
                                <span class="nex_showintels_date">$thread[dateline]</span>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
				</li>
                <!--{else}-->
                <div class="nex_group_showinfos_null">
                    <h3><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">$thread[subject]</a></h3>
                    <div class="nex_showfrom"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$thread[forumname]</a></div>
                    <div class="nex_showbtms">
                        <div class="nex_showavator">
                            <!--{if $thread['authorid'] && $thread['author']}-->
                            <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">
                                <!--{avatar($thread[authorid],small)}-->
                                <em>$thread[author]</em>
                                <div class="clear"></div>
                            </a>
                            <!--{else}-->
                                <!--{if $_G['forum']['ismoderator']}-->
                                <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">
                                    <img src="$_G['style'][styleimgdir]/search/anonymous.png" />
                                    <em>{lang anonymous}</em>
                                    <div class="clear"></div>
                                </a>
                                <!--{else}-->
                                <em>{lang anonymous}</em>
                                <div class="clear"></div>
                                <!--{/if}-->
                            <!--{/if}-->
                        </div>
                        <div class="nex_showintels">
                            <span class="nex_showintels_view">$thread[views]{lang a_visit}</span>
                            <span class="nex_showintels_reply">$thread[replies]{lang a_comment_thread}</span>
                            <span class="nex_showintels_date">$thread[dateline]</span>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <!--{/if}-->
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
    <!--{else}-->
    <div class="nex_emp_notice">
        <em></em>
        <h5>{lang search_nomatch}</h5>
    </div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
<!--{/if}-->
</div>