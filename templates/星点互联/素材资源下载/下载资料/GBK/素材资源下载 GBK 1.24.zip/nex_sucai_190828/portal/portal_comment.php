<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<div id="comment" class="bm">
	<!--{if $data[commentnum] == 0}-->
    <div class="nex_article_nocomment">
    	<div class="nex_article_nocomment_top">�����������ۣ�������ɳ��!</div>
        <div class="nex_arttitleR">
        <!--{if $_G['uid']}-->
            <!--{else}-->
            <ul>
                <li class="nex_artcomment_logtxt">����δ��¼��</li>
                <li class="nex_artcomment_login"><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">��¼�˺�</a></li>
                <li class="nex_artcomment_reg"><a href="member.php?mod={$_G[setting][regname]}">����ע��</a></li>
                <div class="clear"></div>
            </ul>
        <!--{/if}-->
        </div>
        <div class="clear"></div>
    </div>
    <!--{else}-->
    <div class="nex_artcomment"> 
    	<div class="nex_arttitleL">����</div>
        <div class="nex_arttitleM"><span>{$article[viewnum]}</span>�˲��룬<span>$data[commentnum]</span>������</div>
        <div class="nex_arttitleR">
        <!--{if $_G['uid']}-->
        <!--{else}-->
        <ul>
        	<li class="nex_artcomment_logtxt">����δ��¼��</li>
        	<li class="nex_artcomment_login"><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">��¼�˺�</a></li>
            <li class="nex_artcomment_reg"><a href="member.php?mod={$_G[setting][regname]}">����ע��</a></li>
            <div class="clear"></div>
        </ul>
        <!--{/if}-->
        </div>
        <div class="clear"></div>
    </div>
    <!--{/if}-->
  
  <div id="comment_ul"> 
    <!--{if !empty($pricount)}-->
    <p class="mtn mbn y">{lang hide_portal_comment}</p>
    <!--{/if}--> 
    <!--{if !$data[htmlmade]}-->
    <form id="cform" name="cform" action="$form_url" method="post" autocomplete="off">
        <div class="tedt" id="tedt">
            <div class="area">
                <textarea name="message" rows="3" class="pt" id="message"  {if !$_G['uid']} placeholder="������¼�������Ŀ�����"{else} placeholder="���ھͷ������۰�"{/if} onkeydown="ctrlEnter(event, 'commentsubmit_btn');"></textarea>
            </div>
        </div>
        <div class="nexpostreplys">
        <!--{if $secqaacheck || $seccodecheck}-->
            <!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
            <div class="mtm z"><!--{subtemplate common/seccheck}--></div>
        <!--{/if}-->
        <!--{if !empty($topicid) }-->
            <input type="hidden" name="referer" value="$topicurl#comment" />
            <input type="hidden" name="topicid" value="$topicid">
        <!--{else}-->
            <input type="hidden" name="portal_referer" value="$viewurl#comment">
            <input type="hidden" name="referer" value="$viewurl#comment" />
            <input type="hidden" name="id" value="$data[id]" />
            <input type="hidden" name="idtype" value="$data[idtype]" />
            <input type="hidden" name="aid" value="$aid">
        <!--{/if}-->
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="replysubmit" value="true">
        <input type="hidden" name="commentsubmit" value="true" />
        <p class="pt10 cl y"><button type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="true" class="pn y">{lang comment}</button></p>
        </div>
    </form>
    <script type="text/javascript">
    jQuery(function(){
		jQuery("#tedt .pt").focus(function(){
			  jQuery(this).addClass("bgchange");
		}).blur(function(){
			  jQuery(this).removeClass("bgchange");
		});
    });
    </script> 
	<div class="clear"></div>
    <!--{/if}--> 
    <!--{if $data[commentnum] == 0}-->
    <!--{else}-->
    <div class="nex_allcomments_top">
    	<span>��������</span>
        <div class="clear"></div>
    </div>
    <!--{/if}-->
    <div class="nex_comment_alllist">
        <ul>
        <!--{loop $commentlist $comment}--> 
        <!--{template portal/comment_li}--> 
        <!--{if !empty($aimgs[$comment[cid]])}--> 
        <script type="text/javascript" reload="1">aimgcount[{$comment[cid]}] = [<!--{echo implode(',', $aimgs[$comment[cid]]);}-->];attachimgshow($comment[cid]);</script> 
        <!--{/if}--> 
        <!--{/loop}-->
        </ul>
    </div>
    <p class="ptn cl nex_allarticle_comments">
        <!--{if $data[commentnum]}--><a href="$common_url" class="xi2">�鿴ȫ������>></a><!--{/if}-->
      </p>
  </div>
</div>
