<?php echo 'Copyright@Neoconex�ǵ㻥��-��Ȩ����';exit;?>
<!--{block diynav}-->
		<a id="diy-tg" href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" title="{lang open_diy}" >DIY</a>
<!--{/block}-->