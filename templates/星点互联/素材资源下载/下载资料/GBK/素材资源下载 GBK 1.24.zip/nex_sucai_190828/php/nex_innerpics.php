<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
$firstpids = intval($post['pid']);
$nex_attnums = substr($thread[tid], -1); $nex_localpic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$thread[tid]' AND pid = '$firstpids' AND isimage = '1' ORDER BY `aid` ASC LIMIT 5");

$nextotlepivs = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$thread[tid]' AND isimage = '1'"));

$nex_authorid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]'")); 
$usergroupID = DB::fetch_first("SELECT t1.*, t2.* FROM ".DB::table('common_member')." t1 LEFT JOIN ".DB::table('common_usergroup')." t2 ON t1.groupid=t2.groupid WHERE t1.uid ='$nex_authorid'");

include_once libfile('function/post');
include_once libfile('function/attachment');
$thread['post'] = C::t('forum_post')->fetch_all_by_tid_position($thread['posttableid'],$thread['tid'],1);
$thread['post'] = array_shift($thread['post']);
$thread['nex_sums'] = messagecutstr($thread['post']['message'], 200);

$attachments = C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid']);
$attachs = $imgattachs = array();
foreach(C::t('forum_attachment')->fetch_all_by_id('pid', $thread['post']['pid'], 'aid') as $attach) {
$attach = array_merge($attach, $attachments[$attach['aid']]);
$attach['filenametitle'] = $attach['filename'];
$attach['ext'] = fileext($attach['filename']);
getattach_row($attach, $attachs, $imgattachs);
}
$thread['attachments'] = $imgattachs;
?>