<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$nex_blogpic = DB::result(DB::query("SELECT pic FROM ".DB::table('home_blogfield')." WHERE blogid = '$blog[blogid]'"));
$nex_catids = DB::result(DB::query("SELECT catname FROM ".DB::table('portal_category')." WHERE catid = '$article[catid]'"));
?>