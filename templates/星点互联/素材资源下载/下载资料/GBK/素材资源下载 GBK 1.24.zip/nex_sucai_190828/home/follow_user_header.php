<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>

<div class="nex_Home_Gr_xulie">
    <ul>
        <li>
            <div class="nex_Gr_fenshu Gr_broadcast">
                <p>{$nex_user_elements[extcredits2]}</p>
                <span>��Ǯ</span>
            </div>
        </li>
        <li>
            <div class="nex_Gr_fenshu Gr_received">
                <p>{$nex_user_elements[following]}</p>
                <span>{lang follow_add}</span>
            </div>        			
        </li>
        <li>
            <div class="nex_Gr_fenshu Gr_followers">
                <p>{$nex_user_elements[follower]}</p>
                <span>{lang follow_follower}</span>
            </div>
        </li>
        <li>
            <div class="nex_Gr_fenshu Gr_scores">
                <p>$space[credits]</p>
                <span>{lang credits}</span>
            </div>
        </li>
        <div class="clear"></div>
    </ul>   
          
</div>