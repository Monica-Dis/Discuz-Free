<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}

$nex_userterms= DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$nex_userlist_put[uid]' ORDER BY `extcredits2` DESC");
?>