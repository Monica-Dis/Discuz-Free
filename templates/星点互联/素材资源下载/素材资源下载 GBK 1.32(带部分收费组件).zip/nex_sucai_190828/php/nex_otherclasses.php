<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}


$nex_attachsk = DB::result(DB::query("SELECT attachment FROM ".DB::table('forum_post')." WHERE tid = '$nex_other_case[tid]'"));

?>
