<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}


$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($nex_other_case['tid']);
$firstpids = intval($post['pid']);
$getclassid = substr($nex_other_case[tid], -1); $nexclasspiccover = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$getclassid.'')." WHERE tid = '$nex_other_case[tid]' AND pid = '$firstpids' AND isimage = '1' ORDER BY `aid` ASC LIMIT 1");

?>
