<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_catids = DB::result(DB::query("SELECT catname FROM ".DB::table('portal_category')." WHERE catid = '$article[catid]'"));
$nex_curtid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$_G[tid]'"));
$nex_catid = DB::result(DB::query("SELECT catid FROM ".DB::table('portal_category')." WHERE catid = '$article[catid]'"));

?>
