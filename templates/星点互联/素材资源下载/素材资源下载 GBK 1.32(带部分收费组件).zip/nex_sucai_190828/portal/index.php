<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header_index}-->

<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <!--index_main-->
    
    <div class="nex_index_maintop">
        <div class="nexfullSlide">
            <div class="bd">
                <!--[diy=bd]--><div id="bd" class="area"></div><!--[/diy]-->
               
                
            </div>
            <div class="hd">
                <ul>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
            <a class="prev" href="javascript:void(0)"></a>
            <a class="next" href="javascript:void(0)"></a>
        </div>
        <script type="text/javascript">
            jQuery(".nexfullSlide").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:true, autoPage:true, trigger:"click" });
        </script>
        <!--advanced-->
        <div class="nex_adv_box">
        	<div class="w1240">
            	<div class="nex_adv_list">
                	<ul>
                    	<!--[diy=nex_adv_list]--><div id="nex_adv_list" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--select types-->
        <div class="nex_select_types">
        	<div class="w1240">
                <div class="nex_select_types_top">
                    <ul>
                    	<!--[diy=nex_select_types_top]--><div id="nex_select_types_top" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="nex_common_center_txt">��ѡר����Դ</div>
                <div class="nex_select_types_btm">
                	<ul>
                    	<!--[diy=nex_select_types_btm]--><div id="nex_select_types_btm" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!--�����ز�-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">�����ز�</div>
                <div class="nex_icb_top_more"><a href="http://t.cn/Aiux1eta" target="_blank">MORE</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_grids">
            	<ul>
                	<!--[diy=nex_sucai_grids1]--><div id="nex_sucai_grids1" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_index_sep_ads">
            	<ul>
                	<!--[diy=nex_index_sep_ads]--><div id="nex_index_sep_ads" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    
    <!--�ر��ز�-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">���ʦ�ر��ز�</div>
                <div class="nex_icb_top_more"><a href="http://t.cn/Aiux1eta" target="_blank">MORE</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_grids">
            	<ul>
                	<!--[diy=nex_sucai_grids2]--><div id="nex_sucai_grids2" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            
        </div>
    </div>
    
    <!--�زķ���-->
    <div class="nex_index_common_bd nex_index_common_bd_bgg">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">�زķ�������</div>
                <div class="nex_icb_top_tab">
                	<dl>
                    	<dd class="cur">HTMLģ��</dd>
                        <dd>���Ԫ��</dd>
                        <dd>PPTģ��</dd>
                        <dd>�����Ա�</dd>
                        <dd>ƽ���ز�</dd>
                        <dd>���屳��ͼ</dd>
                        <dd>���Ԫ��</dd>
                        <div class="clear"></div>
                    </dl>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_sort_btm">
            	<dl>	
                    <dd style="display:block;">
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids3]--><div id="nex_sucai_grids3" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
            		</dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids4]--><div id="nex_sucai_grids4" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids5]--><div id="nex_sucai_grids5" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids6]--><div id="nex_sucai_grids6" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids7]--><div id="nex_sucai_grids7" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids8]--><div id="nex_sucai_grids8" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids9]--><div id="nex_sucai_grids9" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
            	</dl>
            </div>
			<script type="text/javascript">
				jQuery(".nex_icb_top_tab dl dd").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("cur").siblings().removeClass("cur");
						jQuery(".nex_sucai_sort_btm dl dd").eq(s).show().siblings().hide();
						})
					})
			</script>
            
        </div>
    </div>
    <!--VIP�ز�-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">VIP�ز�����</div>
                <div class="nex_icb_top_more"><a href="http://t.cn/Aiux1eta" target="_blank">MORE</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_grids">
            	<ul>
                	<!--[diy=nex_sucai_grids91]--><div id="nex_sucai_grids91" class="area"></div><!--[/diy]-->
                    <div class="clear"></div>
                </ul>
            </div>
            
        </div>
    </div>
    <!--������������-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
            <div class="nex_sucai_rk_title">
                <span>�����������а�</span>
                <em>�����Ѹ���<i>2964</i>���ز�</em>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_rklist">
                <div class="nex_sucai_rkcont_left">
                    <ul>
                    	<!--[diy=nex_sucai_rkcont_left]--><div id="nex_sucai_rkcont_left" class="area"></div><!--[/diy]-->
                        
                    </ul>
                </div>
                <div class="nex_sucai_rkcont_right">
                    <ul>
                    	<!--[diy=nex_sucai_rkcont_right]--><div id="nex_sucai_rkcont_right" class="area"></div><!--[/diy]-->
                        
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <!--����������ط���-->
    <div class="nex_index_common_bd nex_index_common_bd_bgg">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">����������ط���</div>
                <div class="nex_icb_top_more"><a href="http://t.cn/Aiux1eta" target="_blank">MORE</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_teach_articles">
            	<ul>
                	<!--��ά����-->
                	<li>
                    	<div class="nex_teach_inner">
                        	<div class="nex_teach_inner_title nex_teach_inner_title1">��ά��������</div>
                            <div class="nex_software_list">
                            	<dl>
                                	<!--[diy=nex_software_list]--><div id="nex_software_list" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </div>
                    </li>
                    <!--��Ⱦ����-->
                    <li>
                    	<div class="nex_teach_inner">
                        	<div class="nex_teach_inner_title nex_teach_inner_title2">��Ⱦ��������</div>
                            <div class="nex_software_list">
                            	<dl>
                                	<!--[diy=nex_software_list1]--><div id="nex_software_list1" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </div>
                    </li>
                    <!--��������-->
                    <li>
                    	<div class="nex_teach_inner">
                        	<div class="nex_teach_inner_title nex_teach_inner_title3">������������</div>
                            <div class="nex_software_list">
                            	<dl>
                                	<!--[diy=nex_software_list2]--><div id="nex_software_list2" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                        </div>
                    </li>
                    <!--ͼֽ����-->
                    <li class="nex_ta_last">
                    	<div class="nex_teach_inner">
                        	<div class="nex_teach_inner_title nex_teach_inner_title4">ͼֽ��������</div>
                            <div class="nex_software_list">
                            	<dl>
                                	<!--[diy=nex_software_list3]--><div id="nex_software_list3" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </div>
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    <!--��������-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_created_art">
            	
                <div class="nex_create_top_line">
                	<div class="nex_icb_top">
                        <div class="nex_icb_top_l">��������</div>
                        <div class="nex_icb_top_more"><a href="http://t.cn/Aiux1eta" target="_blank">MORE</a></div>
                        <div class="clear"></div>
                    </div>
                	<div class="nex_create_artlisting">
                    	<ul>
                        	<!--[diy=nex_create_artlisting]--><div id="nex_create_artlisting" class="area"></div><!--[/diy]-->
                        	
                            <div class="clear"></div>
                        </ul>
                    </div>
                </div>
                <div class="nex_create_btm_line">
                	<div class="nex_icb_top">
                        <div class="nex_icb_top_l">�Ƽ������̳��Ķ�</div>
                        <div class="nex_icb_top_more"><a href="http://t.cn/Aiux1eta" target="_blank">MORE</a></div>
                        <div class="clear"></div>
                    </div>
                	<div class="nex_listing_style">
                    	<ul>
                        	<!--[diy=nex_listing_style]--><div id="nex_listing_style" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                </div>
            </div>
            <div class="nex_totle_right">
            	<!--VIP ads-->
                <div class="nex_vip_guide_link">
                	<!--[diy=nex_vip_guide_link]--><div id="nex_vip_guide_link" class="area"></div><!--[/diy]-->
                	
                </div>
                <div class="nex_vip_guide_link">
                	<a href="http://t.cn/Aiux1eta" target="_blank"></a>
                </div>
                <!--���ű�ǩ-->
                <div class="nex_side_frame nex_side_frame_tag">
                	<div class="nex_side_frame_tt">
                    	<span>���ű�ǩ</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_tag_list">
                    	<!--[diy=nex_tag_list]--><div id="nex_tag_list" class="area"></div><!--[/diy]-->
                                          
                     </div>
                </div>
                <!--��Ա����-->
                <div class="nex_side_frame">
                	<div class="nex_side_frame_tt">
                    	<span>��Ա����</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_member_list">
                    	<ul>
                        	<!--[diy=nex_member_list]--><div id="nex_member_list" class="area"></div><!--[/diy]-->
                            
                        </ul>
                    </div>
                </div>
                <!--�л����а�-->
                <div class="nex_switch_listbox">
                    <div class="nex_tab_switch">
                    	<ul>
                        	<li class="cur">�ղ����</li>
                            <li>�����ز�</li>
                            <li>����ϲ��</li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_tab_contants">
                    	<ul>
                        	<li style="display:block;">
                            	<div class="nex_tab_listboxs">
                                	<dl>
                                    	<!--[diy=nex_tab_listboxs]--><div id="nex_tab_listboxs" class="area"></div><!--[/diy]-->
                                    	
                                    </dl>
                                </div>
                            </li>
                            <li>
                            	<div class="nex_tab_listboxs">
                                	<dl>
                                    	<!--[diy=nex_tab_listboxs1]--><div id="nex_tab_listboxs1" class="area"></div><!--[/diy]-->
                                    	
                                    </dl>
                                </div>
                            </li>
                            <li>
                            	<div class="nex_tab_listboxs">
                                	<dl>
                                    	<!--[diy=nex_tab_listboxs2]--><div id="nex_tab_listboxs2" class="area"></div><!--[/diy]-->
                                    	
                                    </dl>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <script type="text/javascript">
						jQuery(".nex_tab_switch ul li").each(function(s){
							jQuery(this).click(function(){
								jQuery(this).addClass("cur").siblings().removeClass("cur");
								jQuery(".nex_tab_contants ul li").eq(s).show().siblings().hide();
								})
							})
					</script>
                </div>
               
            </div>
            <div class="clear"></div>
        	<!--ads-->
            <div class="nex_index_sep_ads_three">
            	<ul>
                	<!--[diy=nex_index_sep_ads_three]--><div id="nex_index_sep_ads_three" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            
        </div>
    </div>
    <!--��������-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">��������</div>
                <div class="nex_icb_top_more"><a href="http://t.cn/Aiux1eta" target="_blank">������������������QQ{$_G['setting']['site_qq']}</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_link_to">
                <ul>
                	<!--[diy=nex_link_to]--><div id="nex_link_to" class="area"></div><!--[/diy]-->
                
                <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    
    
    
    
</div>    
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->


