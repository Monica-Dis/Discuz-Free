<?php

if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}


$nex_myfav_col = DB::result(DB::query("SELECT icon FROM ".DB::table('forum_forumfield')." WHERE fid = '$value[id]'"));
$nex_myfav_pic = DB::result(DB::query("SELECT attachment FROM ".DB::table('forum_threadimage')." WHERE tid = '$value[id]'"));
$nex_myfav_author = DB::result(DB::query("SELECT author FROM ".DB::table('forum_thread')." WHERE tid = '$value[id]'"));
$nex_myfav_aid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$value[id]'"));

?>