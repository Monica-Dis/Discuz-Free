<?php

if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_bbs_date = DB::result(DB::query("SELECT dateline FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_sortypes = DB::result(DB::query("SELECT attachment FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_tdsconts = DB::result(DB::query("SELECT message FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]' AND first = '1' ")); 
$summary_echo = preg_replace ("/\[[a-z][^\]]*\]|\[\/[a-z]+\]/i",'',preg_replace("/\[attach\]\d+\[\/attach\]/i",'',$nex_tdsconts));
$nex_sortfid = DB::result(DB::query("SELECT typeid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_sorttypename = DB::result(DB::query("SELECT name FROM ".DB::table('forum_threadclass')." WHERE typeid = '$nex_sortfid'"));
$nex_attnums = substr($thread[tid], -1); 
$nex_threadlistspic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$thread[tid]' AND isimage = '1' ORDER BY `aid` ASC LIMIT 1");
$nex_authoridx = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_attnums = substr($thread[tid], -1); 
$nex_threadlistspic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$thread[tid]' AND isimage = '1' ORDER BY `aid` ASC LIMIT 1");
$nex_fidnum = DB::result(DB::query("SELECT fid FROM ".DB::table('forum_thread')." WHERE tid = '$_G[tid]'"));
$nex_bbname = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$nex_fidnum'"));
$nex_grids = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$nex_authoridx[uid]'"));
$nex_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_grids[groupid]'"));
$usergroupID = DB::fetch_first("SELECT t1.*, t2.* FROM ".DB::table('common_member')." t1 LEFT JOIN ".DB::table('common_usergroup')." t2 ON t1.groupid=t2.groupid WHERE t1.uid ='$nex_authoridx[uid]'");

?>