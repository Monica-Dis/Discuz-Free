<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<div class="nex_Search">
    <div id="nex_scform_tb">
        <!--{if helper_access::check_module('portal') && $_G['setting']['search']['portal']['status'] && ($_G['group']['allowsearch'] & 1 || $_G['adminid'] == 1)}--><!--{block slist[portal]}--><a href="search.php?mod=portal{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'portal'} class="a"{/if}>{lang portal}</a><!--{/block}--><!--{/if}-->
        <!--{if $_G['setting']['search']['forum']['status'] && ($_G['group']['allowsearch'] & 2 || $_G['adminid'] == 1)}--><!--{block slist[forum]}--><a href="search.php?mod=forum{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}"{if CURMODULE == 'forum'} class="a"{/if}>{lang thread}</a><!--{/block}--><!--{/if}-->
        <!--{if helper_access::check_module('collection') && $_G['setting']['search']['collection']['status'] && ($_G['group']['allowsearch'] & 64 || $_G['adminid'] == 1)}--><!--{/if}-->
        <!--{echo implode("", $slist);}-->
    </div>                 
    <input value="$keyword" autocomplete="off" class="nex_Search_input" name="srchtxt" id="scform_srchtxt" value="" placeholder="点击输入搜索内容">

    <div class="nex_Seachbtns"><input type="hidden" name="searchsubmit" value="yes"><input type="submit" value="{lang search}" class="nex_sbtns" id="scform_submit"></div>
</div>                
	