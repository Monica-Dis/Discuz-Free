<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<div id="mask" style="display:none;"></div>

<!--{if !$nofooter}-->
<div class="footer nex_footer">
    <div class="nex_footer_contact_way">
    	<div class="nex_footer_aboLink"><a href="http://t.cn/Aiux1012">关于我们</a><a href="http://t.cn/Aiux1012">服务条款</a><a href="http://t.cn/Aiux1012">联系我们</a><a href="http://t.cn/Aiux1012">投稿激励</a><a href="http://t.cn/Aiux1012">意见反馈</a></div>
    	<div class="nex_footer_feedback">反馈建议：feedback@neoconex.com</div>
        <div class="nex_footer_feedback">商务合作：Dism.Taobao.Com</div>
        <div class="nex_footer_gz"><img src="$_G['style'][styleimgdir]/footer/wx.jpg" /></div>
        <div class="nex_footer_gztxt">微信公众号</div>
    </div>
    <div class="nex_footer_contact_btm">
    	<div class="nex_footer_contact_btm_top">
        	<a href="http://t.cn/Aiux1012">限制性规定</a><em>|</em>
            <a href="http://t.cn/Aiux1012">隐私条款</a>
        </div>
        <div class="nex_footer_contact_btm_inter">
        	<p>&copy; Comsenz Inc.&nbsp;Neoconex星点互联</p>
            <p><!--{if $_G['setting']['icp']}--> <a href="http://www.miitbeian.gov.cn/" target="_blank">$_G['setting']['icp']</a> <!--{/if}--></p>
        </div>
    </div>
	
    
</div>
<!--{/if}-->

</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->
