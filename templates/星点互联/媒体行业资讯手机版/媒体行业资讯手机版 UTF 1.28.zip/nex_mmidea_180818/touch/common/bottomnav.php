<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<style type="text/css">
.nex_footer{ padding:40px 20px 80px 20px;}
.nex_user_Profile{ padding:15px 15px 80px 15px;}
</style>
<div class="nex_bottomnav">
	<div class="nex_bottominter">
    	<ul>
        	<li>
            	<a href="portal.php?mod=index&mobile=2">
                	<i class="nex_iconbtm1"></i>
                    <p>门户</p>
                </a>
            </li>
            <li>
            	<a href="forum.php?mod=guide&view=newthread&mobile=2">
                	<i class="nex_iconbtm2"></i>
                    <p>导读</p>
                </a>
            </li>
            <li>
            	<a href="forum.php?forumlist=1&mobile=2">
                	<i class="nex_iconbtm3"></i>
                    <p>论坛</p>
                </a>
            </li>
            <li>
            	<a href="forum.php?mod=misc&action=nav">
                	<i class="nex_iconbtm4"></i>
                    <p>发帖</p>
                </a>
            </li>
            <li>
            	<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1&mobile=2">
                	<i class="nex_iconbtm5"></i>
                    <p>我的</p>
                </a>
            </li>
            <div class="clear"></div>
        </ul>
    </div>
</div>