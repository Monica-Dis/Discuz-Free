<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_portal.css" />
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        <!--slider-->
        <div id="nex_index_focus" class="nex_index_focus">
            <div class="hd">
                <ul></ul>
            </div>
            <div class="bd">
				<!--门户幻灯模块-->
                
            </div>
        </div>
        <script type="text/javascript">
            TouchSlide({ 
                slideCell:"#nex_index_focus",
                titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
                mainCell:".bd ul", 
                effect:"left", 
                autoPlay:true,//自动播放
                autoPage:true, //自动分页
                switchLoad:"_src" //切换加载，真实图片路径为"_src" 
            });
        </script>
        <!--快讯-->
        <div class="nex_fnbox">
        	<div class="nex_fnbox_l"></div>
            <div class="nex_fnbox_r">
				<!--门户快讯模块-->
            	
            </div>
            <script type="text/javascript">
			jQuery(".nex_fnbox_r").slide({ mainCell:"ul", effect:"topLoop", vis:1, opp:true, autoPlay:true, delayTime:600 });
			</script>
            <div class="clear"></div>
        </div>
        <!--今日头条-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>今日头条</span>
                <a href="http://t.cn/Aiux1012">查看更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_today_top">
            	<ul>
					<!--门户今日头条模块-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--行业动态-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>行业动态</span>
                <a href="http://t.cn/Aiux1012">查看更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_taody_mid">
                <ul>
					<!--门户行业动态模块-->
                	
                </ul>
            </div>
        </div>
        
        
        <!--ads1-->
        <div class="nex_bdco_box">
			<!--门户广告位1模块-->
        	
        </div>
        
        <!--热门阅读-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>热门阅读</span>
                <a href="http://t.cn/Aiux1012">查看更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_today_btm">
                <ul>
					<!--门户热门阅读模块-->
                    
                </ul>
            </div>
        </div>
        <!--ads2-->
        <div class="nex_bdco_box">
			<!--门户广告位2模块-->
        	
        </div>
        <!--行业排行榜-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>资讯排行榜</span>
                <ul>
                	<li class="on">日榜</li>
                    <em>|</em>
                    <li>周榜</li>
                    <em>|</em>
                    <li>月榜</li>
                    <div class="clear"></div>
                </ul>
                <div class="clear"></div>
            </div>
            <div class="nex_rk_list">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_rklist">
                        	<dl>
								<!--门户行业排行榜-日榜模块-->
                            	
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_rklist">
                        	<dl>
                            	<!--门户行业排行榜-周榜模块-->
                                
                            </dl>
                        </div>
                    </li>
                    <li>
						<div class="nex_rklist">
                        	<dl>
                            	<!--门户行业排行榜-月榜模块-->
                                
                            </dl>
                        </div>
					</li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_bdco_box_top ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_rk_list ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
        </div>
        <!--区块课堂-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>区块课堂</span>
                <a href="http://t.cn/Aiux1012">查看更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_classbox">
            	<ul>
					<!--门户区块课堂模块-->
                                    	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--ads3-->
        <div class="nex_bdco_box">
			<!--门户广告位3模块-->
            
        	
        </div>
        
        <!--行业干货-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>行业干货</span>
                <a href="http://t.cn/Aiux1012">查看更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_ganhuo">
            	<ul>
					<!--门户行业干货模块-->
                    
                	
                </ul>
            </div>
        </div>
        <!--名家专栏-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>名家专栏</span>
                <a href="http://t.cn/Aiux1012">查看更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_zjboxs">
            	<ul>
					<!--门户名家专栏模块-->
                    
                	
                </ul>
            </div>
        </div>
        <!--精选资讯-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>精选资讯</span>
                <a href="http://t.cn/Aiux1012">查看更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_loadingpat">
                <div class="nex_selecteds">
                    <ul>
						<!--门户精选资讯模块-->
                        
                        
                    </ul>
                </div>
                <ul class="nex_load_end">数据加载中，请稍后...</ul>
                <div class="nex_load_more"><a href="javascript:;" onClick="moreload.loadMore();">点击加载更多</a></div>
            </div>
            <script type="text/javascript">
				var _content = []; //临时存储li循环内容
				var moreload = {
					_default:10, //默认显示图片个数
					_loading:5,  //每次点击按钮后加载的个数
					init:function(){
						var lis = $(".nex_loadingpat .nex_selecteds li");
						$(".nex_loadingpat ul.nex_load_end").html("");
						for(var n=0;n<moreload._default;n++){
							lis.eq(n).appendTo(".nex_loadingpat ul.nex_load_end");
						}
						$(".nex_loadingpat ul.nex_load_end li .nex_zx_listspic img").each(function(){
							$(this).attr('src',$(this).attr('realSrc'));
						})
						for(var i=moreload._default;i<lis.length;i++){
							_content.push(lis.eq(i));
						}
						$(".nex_loadingpat .nex_selecteds").html("");
					},
					loadMore:function(){
						var mLis = $(".nex_loadingpat ul.nex_load_end li").length;
						for(var i =0;i<moreload._loading;i++){
							var target = _content.shift();
							if(!target){
								$('.nex_loadingpat .nex_load_more').html("<p>全部加载完毕...</p>");
								break;
							}
							$(".nex_loadingpat ul.nex_load_end").append(target);
							$(".nex_loadingpat ul.nex_load_end li .nex_zx_listspic img").eq(mLis+i).each(function(){
								$(this).attr('src',$(this).attr('realSrc'));
							});
						}
					}
				}
				moreload.init();
			</script>
            
        </div>
        <!--友情链接-->
        <div class="nex_bdco_box nex_bdco_box_no">
        	<div class="nex_bdco_box_top">
            	<span>友情链接</span>
                <a href="http://t.cn/Aiux1012">查看更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_linkport">
            	<ul>
					<!--门户友情链接模块-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
            
            
        </div>
	</div>	
</div>
<!--{template common/bottomnav}-->
<!--{template common/footer_more}-->
<div class="pullrefresh" style="display:none;"></div>

