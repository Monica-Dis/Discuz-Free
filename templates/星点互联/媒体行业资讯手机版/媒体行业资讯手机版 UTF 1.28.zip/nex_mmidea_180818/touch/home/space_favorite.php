<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<!-- header start -->
<div class="nex_uc_mylisttop">
	<i></i>
	<div class="nex_uc_mylisttopinter">
    	<a href="javascript:history.back()" class="nex_uc_mylisttop_back"></a>
		<span class="nex_uc_mylisttop_txt">{lang myfavorite}</span>
    </div>
</div>
<div class="nex_My_Collections">
	<ul>
		<li><a <!--{if $_GET['type'] == 'thread'}-->class="cur"<!--{/if}--> href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang favthread}<em></em></a></li>
		<li><a <!--{if $_GET['type'] == 'forum'}-->class="cur"<!--{/if}--> href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=forum">{lang favforum}<em></em></a></li>
        <div class="clear"></div>
	</ul>
</div>
<!-- main collectlist start -->
<!--{if $_GET['type'] == 'forum'}-->
<div class="nex_My_CollectionBBS">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li>
            	<!--{eval include 'template/nex_mmidea_180818/touch/php/nex_ufav.php'}-->
            	<a href="$value[url]">
                	<div class="nex_fav_coicon"><img src="data/attachment/common/$nex_myfav_col" /></div>
                    <div class="nex_fav_cotail">
                    	<h5>{$value[title]}</h5>
                        <p><em>收藏于:</em><!--{date($value[dateline], 'u')}--></p>
                    </div>
                    <div class="clear"></div>
                </a>
				<div class="nex_MY_ptxtx"><a id="a_delete_$k" href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k" onclick="showWindow(this.id, this.href, 'get', 0);">{lang delete}</a></div>
			</li>
			<!--{/loop}-->
		<!--{else}-->
			<li class="noData">{lang no_favorite_yet}</li>
		<!--{/if}-->

	</ul>
</div>
<!--{else}-->
<div class="nex_My_CollectionList">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li>
                <!--{eval include 'template/nex_mmidea_180818/touch/php/nex_ufav.php'}-->
                <a class="nex_myfav_part" href="$value[url]">
                    <div class="nex_myfav_top_l">
                    	<div class="nex_myfav_top_name"><img src="uc_server/avatar.php?uid=$nex_myfav_aid&size=middle" /><span>$nex_myfav_author</span></div>
                        <div class="nex_myfav_toptxt">{$value[title]}</div>
                        <div class="nex_MY_ptxt"><em>收藏于:</em><!--{date($value[dateline], 'u')}--></div>
                    </div>
                    <!--{if $nex_myfav_pic}-->
                    <div class="nex_myfav_top_r" style="background:url(data/attachment/forum/$nex_myfav_pic) center no-repeat; background-size:cover;"></div>
                    <!--{else}-->
                    <div class="nex_myfav_top_r" style="background:url($_G['style'][styleimgdir]/ucenter/no-image.png) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <div class="clear"></div>
				</a>
                <a class="nex_delmyfav" id="a_delete_$k" href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k" onclick="showWindow(this.id, this.href, 'get', 0);">{lang delete}</a>
			</li>
			<!--{/loop}-->
		<!--{else}-->
			<li class="noData">{lang no_favorite_yet}</li>
		<!--{/if}-->
	</ul>
</div>
<!--{/if}-->
<script type="text/javascript">
$('.nex_My_CollectionList ul').each(function(){
  
  $(this).children(':last').addClass('nex_My_CollectionList_lasts')

})
</script>
<!-- main collectlist end -->
$multi
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
