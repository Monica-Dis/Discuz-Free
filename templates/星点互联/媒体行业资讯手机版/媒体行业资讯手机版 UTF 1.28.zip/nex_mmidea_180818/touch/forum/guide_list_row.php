<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_guide.css" />
<!--{if $list['threadcount']}-->
<ul>
	<!--{loop $list['threadlist'] $key $thread}-->
    <!--{eval include 'template/nex_mmidea_180818/touch/php/forum.php'}-->
    <!--{if $nex_sortypes == '0'}-->
    <li class="nex_guide_null">
    	<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
        	<div class="nex_guidelist_top">
            	<div class="nex_guidelist_topl">
                	<div class="nex_guidelist_avator"><!--{avatar($thread[authorid],big)}--></div>
                    <div class="nex_guidelist_zzintel">
                    	<h5>$thread[author]</h5>
                        <p><!--{echo date("Y-m-d",{$nex_bbs_date})}--></p>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_guidelist_from">{$list['forumnames'][$thread[fid]]['name']}</div>
                <div class="clear"></div>
            </div>
            <div class="nex_guidelist_txts $thread[highlight]">{$thread[subject]}</div>
            <div class="nex_guidelist_btm">
            	<div class="nex_guidelist_info">
                	<span class="nex_guidelist_views">{$thread[views]}</span>
                    <span class="nex_guidelist_replys">{$thread[replies]}</span>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
            </div>
        </a>
    </li>
    <!--{else}-->
        <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
        <li class="nex_guide_type_first">
        	<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
                <div class="nex_guidelist_top">
                    <div class="nex_guidelist_topl">
                        <div class="nex_guidelist_avator"><!--{avatar($thread[authorid],big)}--></div>
                        <div class="nex_guidelist_zzintel">
                            <h5>$thread[author]</h5>
                            <p><!--{echo date("Y-m-d",{$nex_bbs_date})}--></p>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_guidelist_from">{$list['forumnames'][$thread[fid]]['name']}</div>
                    <div class="clear"></div>
                </div>
                <div class="nex_guidelist_txt $thread[highlight]">{$thread[subject]}</div>
                <div class="nex_guidelist_mit">
                    <div class="nex_guidelist_pic" style="background:url(<!--{if $nex_threadsinpivs['remote']}-->                    			
                    {$_G['setting']['ftp']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                    <!--{else}-->         			
                    {$_G['setting']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                    <!--{/if}-->) center no-repeat; background-size:cover;"></div>
                    <div class="nex_guidelist_mik">
                        <div class="nex_guidelist_infos">
                            <span class="nex_guidelist_views">{$thread[views]}</span>
                            <span class="nex_guidelist_replys">{$thread[replies]}</span>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
        	</a>
        </li>
        <!--{/loop}-->
    <!--{/if}-->
	<!--{/loop}-->
    <div class="nex_bbs_pagetops">本页已经到底了~</div>
</ul>
<!--{else}-->
<p class="noData">{lang guide_nothreads}</p>
<!--{/if}-->


