<?php echo 'Ӧ�ø���֧�֣�https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<div class="nex_BG_slidering nex_BG_slidering1"></div>
<!-- header start -->
<div class="nex_login_topnav">
	<a href="javascript:history.back()"></a>
    <span>����ע��</span>
    <div class="clear"></div>
</div>
<!-- header end -->
<!-- registerbox start -->
<div class="loginbox registerbox">
	<div class="login_from">
		<div class="nex_login_from">
            <form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}&mobile=2">
            <input type="hidden" name="regsubmit" value="yes" />
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
            <input type="hidden" name="referer" value="$dreferer" />
            <input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
            <input type="hidden" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
            <!--{if $_G['setting']['sendregisterurl']}-->
                <input type="hidden" name="hash" value="$_GET[hash]" />
            <!--{/if}-->
            <ul>
                <!--{if $sendurl}-->
                    <li class="bl_none"><input type="email" tabindex="1" class="px p_fre" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login"></li>
                <!--{else}-->
                    <!--{if empty($invite) && $_G['setting']['regstatus'] == 2 && !$invitestatus}-->
                        <li><input type="text" tabindex="1" class="px p_fre" size="30" autocomplete="off" value="{lang invite_code}" name="invitecode" placeholder="{lang invite_code}" fwin="login"></li>
                    <!--{/if}-->
                    <li><input type="text" tabindex="2" class="px p_fre" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip}" fwin="login"></li>
                    <li><input type="password" tabindex="3" class="px p_fre" size="30" value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password}" fwin="login"></li>
                    <li><input type="password" tabindex="4" class="px p_fre" size="30" value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2}" fwin="login"></li>
                    <li><input type="email" tabindex="5" class="px p_fre" size="30" autocomplete="off" value="$hash[0]" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login"></li>
                    <!--{if $_G['setting']['regverify'] == 2}-->
                        <li><input type="text" tabindex="6" class="px p_fre" size="30" autocomplete="off" value="{lang register_message}" name="regmessage" placeholder="{lang register_message}" fwin="login"></li>
                    <!--{/if}-->
                    <!--{if empty($invite) && $_G['setting']['regstatus'] == 3}-->
                        <li><input type="text" tabindex="7" class="px p_fre" size="30" autocomplete="off" value="{lang invite_code}" name="invitecode" placeholder="{lang invite_code}" fwin="login"></li>
                    <!--{/if}-->
                    <!--{loop $_G['cache']['fields_register'] $field}-->
                        <!--{if $htmls[$field['fieldid']]}-->
                            <li><strong>$field[title]</strong><br />$htmls[$field['fieldid']]</li>	
                        <!--{/if}-->
                    <!--{/loop}-->
                <!--{/if}-->
            </ul>
            <!--{if $secqaacheck || $seccodecheck}-->
                <!--{subtemplate common/seccheck}-->
            <!--{/if}-->
        
            <div class="btn_register"><button tabindex="7" value="true" name="regsubmit" type="submit" class="formdialog pn pnc nex_DL_btn"><span>{lang quickregister}</span></button></div>
            <div class="nex_fastlogin"><a href="member.php?mod=logging&action=login&mobile=2">�����˺ţ�</a></div>
            </form>
        </div>
    </div>
</div>
<!-- registerbox end -->

<!--{eval updatesession();}-->

