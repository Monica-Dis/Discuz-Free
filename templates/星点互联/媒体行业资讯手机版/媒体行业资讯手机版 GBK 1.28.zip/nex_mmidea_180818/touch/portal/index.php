<?php echo 'Ӧ�ø���֧�֣�https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_portal.css" />
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        <!--slider-->
        <div id="nex_index_focus" class="nex_index_focus">
            <div class="hd">
                <ul></ul>
            </div>
            <div class="bd">
				<!--�Ż��õ�ģ��-->
                
            </div>
        </div>
        <script type="text/javascript">
            TouchSlide({ 
                slideCell:"#nex_index_focus",
                titCell:".hd ul", //�����Զ���ҳ autoPage:true ����ʱ���� titCell Ϊ����Ԫ�ذ�����
                mainCell:".bd ul", 
                effect:"left", 
                autoPlay:true,//�Զ�����
                autoPage:true, //�Զ���ҳ
                switchLoad:"_src" //�л����أ���ʵͼƬ·��Ϊ"_src" 
            });
        </script>
        <!--��Ѷ-->
        <div class="nex_fnbox">
        	<div class="nex_fnbox_l"></div>
            <div class="nex_fnbox_r">
				<!--�Ż���Ѷģ��-->
            	
            </div>
            <script type="text/javascript">
			jQuery(".nex_fnbox_r").slide({ mainCell:"ul", effect:"topLoop", vis:1, opp:true, autoPlay:true, delayTime:600 });
			</script>
            <div class="clear"></div>
        </div>
        <!--����ͷ��-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>����ͷ��</span>
                <a href="http://t.cn/Aiux1012">�鿴����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_today_top">
            	<ul>
					<!--�Ż�����ͷ��ģ��-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--��ҵ��̬-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>��ҵ��̬</span>
                <a href="http://t.cn/Aiux1012">�鿴����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_taody_mid">
                <ul>
					<!--�Ż���ҵ��̬ģ��-->
                	
                </ul>
            </div>
        </div>
        
        
        <!--ads1-->
        <div class="nex_bdco_box">
			<!--�Ż����λ1ģ��-->
        	
        </div>
        
        <!--�����Ķ�-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>�����Ķ�</span>
                <a href="http://t.cn/Aiux1012">�鿴����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_today_btm">
                <ul>
					<!--�Ż������Ķ�ģ��-->
                    
                </ul>
            </div>
        </div>
        <!--ads2-->
        <div class="nex_bdco_box">
			<!--�Ż����λ2ģ��-->
        	
        </div>
        <!--��ҵ���а�-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>��Ѷ���а�</span>
                <ul>
                	<li class="on">�հ�</li>
                    <em>|</em>
                    <li>�ܰ�</li>
                    <em>|</em>
                    <li>�°�</li>
                    <div class="clear"></div>
                </ul>
                <div class="clear"></div>
            </div>
            <div class="nex_rk_list">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_rklist">
                        	<dl>
								<!--�Ż���ҵ���а�-�հ�ģ��-->
                            	
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_rklist">
                        	<dl>
                            	<!--�Ż���ҵ���а�-�ܰ�ģ��-->
                                
                            </dl>
                        </div>
                    </li>
                    <li>
						<div class="nex_rklist">
                        	<dl>
                            	<!--�Ż���ҵ���а�-�°�ģ��-->
                                
                            </dl>
                        </div>
					</li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_bdco_box_top ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_rk_list ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
        </div>
        <!--�������-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>�������</span>
                <a href="http://t.cn/Aiux1012">�鿴����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_classbox">
            	<ul>
					<!--�Ż��������ģ��-->
                                    	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--ads3-->
        <div class="nex_bdco_box">
			<!--�Ż����λ3ģ��-->
            
        	
        </div>
        
        <!--��ҵ�ɻ�-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>��ҵ�ɻ�</span>
                <a href="http://t.cn/Aiux1012">�鿴����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_ganhuo">
            	<ul>
					<!--�Ż���ҵ�ɻ�ģ��-->
                    
                	
                </ul>
            </div>
        </div>
        <!--����ר��-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>����ר��</span>
                <a href="http://t.cn/Aiux1012">�鿴����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_zjboxs">
            	<ul>
					<!--�Ż�����ר��ģ��-->
                    
                	
                </ul>
            </div>
        </div>
        <!--��ѡ��Ѷ-->
        <div class="nex_bdco_box">
        	<div class="nex_bdco_box_top">
            	<span>��ѡ��Ѷ</span>
                <a href="http://t.cn/Aiux1012">�鿴����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_loadingpat">
                <div class="nex_selecteds">
                    <ul>
						<!--�Ż���ѡ��Ѷģ��-->
                        
                        
                    </ul>
                </div>
                <ul class="nex_load_end">���ݼ����У����Ժ�...</ul>
                <div class="nex_load_more"><a href="javascript:;" onClick="moreload.loadMore();">������ظ���</a></div>
            </div>
            <script type="text/javascript">
				var _content = []; //��ʱ�洢liѭ������
				var moreload = {
					_default:10, //Ĭ����ʾͼƬ����
					_loading:5,  //ÿ�ε����ť����صĸ���
					init:function(){
						var lis = $(".nex_loadingpat .nex_selecteds li");
						$(".nex_loadingpat ul.nex_load_end").html("");
						for(var n=0;n<moreload._default;n++){
							lis.eq(n).appendTo(".nex_loadingpat ul.nex_load_end");
						}
						$(".nex_loadingpat ul.nex_load_end li .nex_zx_listspic img").each(function(){
							$(this).attr('src',$(this).attr('realSrc'));
						})
						for(var i=moreload._default;i<lis.length;i++){
							_content.push(lis.eq(i));
						}
						$(".nex_loadingpat .nex_selecteds").html("");
					},
					loadMore:function(){
						var mLis = $(".nex_loadingpat ul.nex_load_end li").length;
						for(var i =0;i<moreload._loading;i++){
							var target = _content.shift();
							if(!target){
								$('.nex_loadingpat .nex_load_more').html("<p>ȫ���������...</p>");
								break;
							}
							$(".nex_loadingpat ul.nex_load_end").append(target);
							$(".nex_loadingpat ul.nex_load_end li .nex_zx_listspic img").eq(mLis+i).each(function(){
								$(this).attr('src',$(this).attr('realSrc'));
							});
						}
					}
				}
				moreload.init();
			</script>
            
        </div>
        <!--��������-->
        <div class="nex_bdco_box nex_bdco_box_no">
        	<div class="nex_bdco_box_top">
            	<span>��������</span>
                <a href="http://t.cn/Aiux1012">�鿴����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_linkport">
            	<ul>
					<!--�Ż���������ģ��-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
            
            
        </div>
	</div>	
</div>
<!--{template common/bottomnav}-->
<!--{template common/footer_more}-->
<div class="pullrefresh" style="display:none;"></div>


