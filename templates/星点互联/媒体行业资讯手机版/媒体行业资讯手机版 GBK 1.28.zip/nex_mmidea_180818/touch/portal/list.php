<?php echo 'Ӧ�ø���֧�֣�https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_article.css" />
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->

<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        <div class="nex_Info_list_bg">
            <h5>$cat[catname]</h5>
            <div id="pt" class="bm cl">
                <a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
                <a href="$_G[setting][navs][1][filename]">{lang portal}</a> <em>&rsaquo;</em>
                <!--{loop $cat[ups] $value}--> <a href="{$portalcategory[$value['catid']]['caturl']}">$value[catname]</a><em>&rsaquo;</em><!--{/loop}-->
                $cat[catname]
            </div>
            <!--{if $cat[subs]}-->
            <div class="nex_nextnav">
                <ul>
                <!--{eval $i = 1;}-->
                <!--{loop $cat[subs] $value}-->
                <!--{if $i != 1}--><!--{/if}--><li><a href="{$portalcategory[$value['catid']]['caturl']}" >$value[catname]</a></li><!--{eval $i--;}-->
                <!--{/loop}-->
                <div class="clear"></div>
                </ul>
            </div>
            <!--{/if}-->
        </div>
        <div class="nex_articalport">
            <!--{ad/text/wp a_t}-->
            <!--{ad/articlelist/mbm hm/1}--><!--{ad/articlelist/mbm hm/2}-->
            <div class="nex_artice">
                <ul>
                    <!--{loop $list['list'] $value}-->
                    <!--{eval $highlight = article_title_style($value);}-->
                    <!--{eval $article_url = fetch_article_url($value);}-->
                    <!--{eval include 'template/nex_mmidea_180818/touch/php/nex_art.php'}-->
                    <!--{if $value[pic]}-->
                        <li class="nex_artpic_box">
                            <a href="$article_url">
                            	<div class="nex_artpic_halfintelm">
                                    <div class="nex_artpic_halfintelml"><img src="uc_server/avatar.php?uid=$value[uid]&size=middle" /><span>$value[username]</span><div class="clear"></div></div>
                                    <div class="nex_artpic_halfintelmr">$value[dateline]</div>
                                    <div class="clear"></div>
                                </div>
                                <div class="nex_artpic_half">
                                    <div class="nex_artpic_halfintel">
                                    	<h5>$value[title]</h5>
                                        <div class="nex_artpic_halfintelb">
                                        	<!--{if $value[catname] && $cat[subs]}-->
                                        	<div class="nex_artpic_halfintelbr">$value[catname]</div>
                                            <!--{else}-->
                                            <div class="nex_artpic_halfintelbr">$value[catname]</div>
                                            <!--{/if}-->
                                        	<div class="nex_artpic_halfintelbl">
                                            	<span class="nex_artpic_fullbtmm_view">$nex_article_view</span>
                                            	<span class="nex_artpic_fullbtmm_reply">$nex_article_comment</span>
                                            </div>
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                    <div class="nex_artpic_halfpic"><img src="$value[pic]" /></div>
                                    <div class="clear"></div>
                                </div>
                            </a>
                        </li>
                    <!--{else}-->
                    <li>
                        <a href="$article_url">
                            <div class="nex_artpic_low">
                            	<i></i>
                                <h5>$value[title]</h5>
                                <div class="nex_artpic_lowsums">$value[summary]</div>
                                <div class="nex_artpic_lowbbtm">
                                	<div class="nex_artpic_lowbtml"><img src="uc_server/avatar.php?uid=$value[uid]&size=middle" /></div>
                                    <div class="nex_artpic_lowbtmr">
                                    	<div class="nex_artpic_lowbtmrt">
                                            <span>$value[username]</span>
                                            <!--{if $value[catname] && $cat[subs]}-->
                                            <em>$value[catname]</em>
                                            <!--{else}-->
                                        	<em>$value[catname]</em>
                                            <!--{/if}-->
                                            <div class="clear"></div>
                                        </div>
                                        <div class="nex_artpic_lowbbtmm">
                                        	<span class="nex_artpic_lowbbtmm_view">$nex_article_view</span>
                                            <span class="nex_artpic_lowbbtmm_reply">$nex_article_comment</span>
                                            <span class="nex_artpic_lowbbtmm_date">$value[dateline]</span>
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </a>
                    </li>
                    <!--{/if}-->
                    <div class="clear"></div>
                    <!--{/loop}-->
                </ul>
            </div>
            <!--{ad/articlelist/mbm hm/3}--><!--{ad/articlelist/mbm hm/4}-->
            <!--{if $list['multi']}--><div class="pgs cl">{$list['multi']}</div><!--{/if}-->
        </div>

		<!--{template common/footer}-->
	</div>
</div>









<!--�ǵ㻥����Ȩ����-->
