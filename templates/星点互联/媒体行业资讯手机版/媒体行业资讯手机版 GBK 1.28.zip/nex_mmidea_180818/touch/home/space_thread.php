<?php echo 'Ӧ�ø���֧�֣�https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<!-- header start -->
<div class="nex_uc_mylisttop">
	<i style="background:url(<!--{avatar($space[uid], big, true)}-->) center no-repeat; background-size:cover;"></i>
	<div class="nex_uc_mylisttopinter">
    	<a href="javascript:history.back()" class="nex_uc_mylisttop_back"></a>
		<span class="nex_uc_mylisttop_txt">{lang mythread}</span>
    </div>
</div>
<!-- header end -->
<!-- main threadlist start -->
<div class="nex_MY_threadlist nex_UC_mylists">
	<ul>
	<!--{if $list}-->
		<!--{loop $list $nexmythread}-->
		<!--{eval include 'template/nex_mmidea_180818/touch/php/multiops.php'}-->
			<li>
            	<a href="forum.php?mod=viewthread&tid=$nexmythread[tid]&extra=$extra">
					
                    <!--{if $nex_attachs == '0'}-->
                    <div class="nex_UC_mylists_title">
                    	<!--{if $nexmythread['special'] == 1}-->
                            <em class="nex_thread_poll">{lang thread_poll}</em>
                        <!--{elseif $nexmythread['special'] == 2}-->
                            <em class="nex_thread_trade">{lang thread_trade}</em>
                        <!--{elseif $nexmythread['special'] == 3}-->
                            <em class="nex_thread_reward">{lang thread_reward}</em>
                        <!--{elseif $nexmythread['special'] == 4}-->
                            <em class="nex_thread_activity">{lang thread_activity}</em>
                        <!--{elseif $nexmythread['special'] == 5}-->
                            <em class="nex_thread_debate">{lang thread_debate}</em>
                        <!--{elseif $nexmythread['digest'] > 0}-->
                            <em class="threadAttrjh">����</em>
                        <!--{/if}-->
                        <span  $nexmythread[highlight]>{$nexmythread[subject]}</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_mythread_others">
                    	<div class="nex_mythread_ol">{$nex_mythreadfrom}</div>
                        <div class="nex_mythread_or">
                        	<span class="nex_mythread_orview">{$nexmythread[views]}</span>
                            <span class="nex_mythread_orreply">{$nexmythread[replies]}</span>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <!--{else}-->
					<!--{if $nex_threadlistspic}-->
						<!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
						<!--{eval include 'template/nex_mmidea_180818/touch/php/nex_mylist.php'}-->
							<!--{if $attrss == '1'}-->
							<div class="nex_UC_mylists_title">
								<!--{if $nexmythread['special'] == 1}-->
									<em class="nex_thread_poll">{lang thread_poll}</em>
								<!--{elseif $nexmythread['special'] == 2}-->
									<em class="nex_thread_trade">{lang thread_trade}</em>
								<!--{elseif $nexmythread['special'] == 3}-->
									<em class="nex_thread_reward">{lang thread_reward}</em>
								<!--{elseif $nexmythread['special'] == 4}-->
									<em class="nex_thread_activity">{lang thread_activity}</em>
								<!--{elseif $nexmythread['special'] == 5}-->
									<em class="nex_thread_debate">{lang thread_debate}</em>
								<!--{elseif $nexmythread['digest'] > 0}-->
									<em class="threadAttrjh">����</em>
								<!--{/if}-->
								<span  $nexmythread[highlight]>{$nexmythread[subject]}</span>
								<div class="clear"></div>
							</div>
							<div class="nex_UC_mylist_date">����ʱ�䣺<!--{echo date("Y/m/d",{$nex_mythreaddate})}--></div>
							<div class="nex_mythreadpic" style="background:url(<!--{if $nex_threadsinpivs['remote']}-->                    			
                            {$_G['setting']['ftp']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                            <!--{else}-->         			
                            {$_G['setting']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                            <!--{/if}-->) center no-repeat; background-size:cover;"></div>
							<div class="nex_mythread_others">
								<div class="nex_mythread_ol">{$nex_mythreadfrom}</div>
								<div class="nex_mythread_or">
									<span class="nex_mythread_orview">{$nexmythread[views]}</span>
									<span class="nex_mythread_orreply">{$nexmythread[replies]}</span>
									<div class="clear"></div>
								</div>
								<div class="clear"></div>
							</div>
							<!--{else}-->
							<div class="nex_UC_mylists_title">
								<!--{if $nexmythread['special'] == 1}-->
									<em class="nex_thread_poll">{lang thread_poll}</em>
								<!--{elseif $nexmythread['special'] == 2}-->
									<em class="nex_thread_trade">{lang thread_trade}</em>
								<!--{elseif $nexmythread['special'] == 3}-->
									<em class="nex_thread_reward">{lang thread_reward}</em>
								<!--{elseif $nexmythread['special'] == 4}-->
									<em class="nex_thread_activity">{lang thread_activity}</em>
								<!--{elseif $nexmythread['special'] == 5}-->
									<em class="nex_thread_debate">{lang thread_debate}</em>
								<!--{elseif $nexmythread['digest'] > 0}-->
									<em class="threadAttrjh">����</em>
								<!--{/if}-->
								<span  $nexmythread[highlight]>{$nexmythread[subject]}</span>
								<div class="clear"></div>
							</div>
							<div class="nex_mythreadpics" style="background:url(<!--{if $nex_threadsinpivs['remote']}-->                    			
                            {$_G['setting']['ftp']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                            <!--{else}-->         			
                            {$_G['setting']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                            <!--{/if}-->) center no-repeat; background-size:cover;"></div>
							<div class="nex_mythreadintel">
								<div class="nex_mythread_btm">
									<div class="nex_mythread_btml">{$nex_mythreadfrom}</div>
										<div class="nex_mythread_btmr">
										<span class="nex_mythread_orview">{$nexmythread[views]}</span>
										<span class="nex_mythread_orreply">{$nexmythread[replies]}</span>
										<div class="clear"></div>
									</div>
									<div class="clear"></div>
								</div>
							</div>
							<div class="clear"></div>
							
							<!--{/if}-->
						<!--{/loop}-->
					<!--{else}-->
					<div class="nex_UC_mylists_title">
                    	<!--{if $nexmythread['special'] == 1}-->
                            <em class="nex_thread_poll">{lang thread_poll}</em>
                        <!--{elseif $nexmythread['special'] == 2}-->
                            <em class="nex_thread_trade">{lang thread_trade}</em>
                        <!--{elseif $nexmythread['special'] == 3}-->
                            <em class="nex_thread_reward">{lang thread_reward}</em>
                        <!--{elseif $nexmythread['special'] == 4}-->
                            <em class="nex_thread_activity">{lang thread_activity}</em>
                        <!--{elseif $nexmythread['special'] == 5}-->
                            <em class="nex_thread_debate">{lang thread_debate}</em>
                        <!--{elseif $nexmythread['digest'] > 0}-->
                            <em class="threadAttrjh">����</em>
                        <!--{/if}-->
                        <span  $nexmythread[highlight]>{$nexmythread[subject]}</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_mythread_others">
                    	<div class="nex_mythread_ol">{$nex_mythreadfrom}</div>
                        <div class="nex_mythread_or">
                        	<span class="nex_mythread_orview">{$nexmythread[views]}</span>
                            <span class="nex_mythread_orreply">{$nexmythread[replies]}</span>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
					<!--{/if}-->
                    <div class="clear"></div>
                          
                        
                    <!--{/if}-->
                </a>
        	</li>
		<!--{/loop}-->
	<!--{else}-->
		<li>{lang no_related_posts}</li>
	<!--{/if}-->
	</ul>
	$multi
</div>
<!-- main threadlist end -->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

