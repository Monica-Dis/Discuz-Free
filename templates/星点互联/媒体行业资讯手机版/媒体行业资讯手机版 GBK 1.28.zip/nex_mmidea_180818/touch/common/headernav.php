<?php echo 'Ӧ�ø���֧�֣�https://dism.taobao.com';exit;?>
<!--{eval include 'template/nex_mmidea_180818/touch/php/nex_users.php'}-->
<nav class="st-menu st-effect-3" id="menu-3">
        <div class="nex_nav_dlbox">
        <!--{if $_G['uid']}-->
            <div class="nex_nav_dlbox_top">
                <div class="nex_nav_dlbox_top_iner">
                    <div class="nex_nav_dlbox_top_inertop">
                        <div class="nex_nav_tx">
                            <!--{avatar($_G[uid],big)}-->
                            <!--{if $_G[member][newpm]}-->
                            <em><b>{$_G[member][newpm]}</b></em>
                            <!--{elseif $_G[member][newprompt]}-->
                            <em><b>{$_G[member][newprompt]}</b></em>
                            <!--{/if}-->
                        </div>
                        <div class="nex_nav_intel">
                            <div class="nex_nav_username"><em>{$_G[group][grouptitle]}</em>{$_G[member][username]}</div>
                            <div class="nex_nav_userinfos">
                                <!--{if $nex_province == '' && $nex_adds == ''}-->
                                <span>��������</span>
                                <!--{else}-->
                                <span>{$nex_province}{$nex_adds}</span>
                                <!--{/if}-->
                                <!--{if $nex_occu == ''}-->
                                <span class="nex_hd_spline">δְ֪ҵ</span>
                                <!--{else}-->
                                <span class="nex_hd_spline">{$nex_occu}</span>
                                <!--{/if}-->
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_nav_dlbox_top_inerbtm"><!--{if $nex_intros == ''}-->����˺�����ʲôҲû������<!--{else}-->{$nex_intros}<!--{/if}--></div>
                </div>
                <div class="nex_nav_enters">
                    <ul>
                        <li class="nex_nav_usercenter"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1">��������</a></li>
                        <li class="nex_nav_quitebtn"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout_mobile}</a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <!--{elseif !$_G[connectguest]}-->
            <div class="nex_nav_dlboxstd">
            	<div class="nex_nav_user"><img src="$_G['style'][styleimgdir]/headertop/default_avator.png"></div>
                <div class="nex_nav_userbns">
                    <a class="nex_nav_dl" href="member.php?mod=logging&amp;action=login&amp;mobile=2">��¼</a>
                    <a class="nex_nav_zc" href="member.php?mod=register&amp;mobile=2">ע��</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_nav_welcome">�װ����οͣ�����</div>
                <div class="clear"></div>
            </div>
            <!--{/if}-->
            </div>
            <div class="nex_navbox">
                <ul>
                    <li><a href="portal.php?mod=index&mobile=2">�ֻ��Ż�<em>PORTAL</em></a></li>
                    <li><a href="forum.php?forumlist=1&mobile=2">��̳���<em>FORUM</em></a></li>
                    <li><a href="forum.php?mod=guide&view=newthread&mobile=2">����<em>GUIDES</em></a></li>
                    <li><a href="forum.php?mod=forumdisplay&fid=2&mobile=2">�������<em>CLASS</em></a></li>
                    <li><a href="hd.php?mod=index&mobile=2">��վ�<em>ACTIVITIES</em></a></li>
                    <li><a href="portal.php?mod=list&catid=3">��ҵ��Ѷ<em>INFOMATION</em></a></li>
                    <li><a href="vip.php?mod=index&mobile=2">VIP��Ա<em>VIP MEMBER</em></a></li>
                    <li><a href="about.php?mod=index&mobile=2">��������<em>ABOUT</em></a></li>
                    <li><a href="plugin.php?id=nex_incs_180626&mobile=2">Ѱ�󱨵�<em>REPORTING</em></a></li>
                </ul>
            </div>
        </nav>
                
                
<div class="nex_navbar">
    <div class="nex_navleft">
        <div id="st-trigger-effects" class="nex_navtop_column"><button class="nex_subnavs" data-effect="st-effect-3"></button></div>
    </div>
    <div class="nextoplogo"><img src="$_G['style'][styleimgdir]/index/logo.png" /></div>
    <div class="nex_navright">
        <a href="search.php?mod=forum&mobile=2"></a>
    </div>
    
</div>
<script src="$_G['style'][styleimgdir]/js/define.js"></script>
<script src="$_G['style'][styleimgdir]/js/effect.js"></script>

