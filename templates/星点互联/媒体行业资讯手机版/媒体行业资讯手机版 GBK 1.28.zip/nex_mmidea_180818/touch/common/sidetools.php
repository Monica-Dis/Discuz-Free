<?php echo 'Ӧ�ø���֧�֣�https://dism.taobao.com';exit;?>
<div class="nex_threadinertools">
	<ul>
    	<li class="nex_threadinertools_post"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&mobile=2"></a></li>
    	<li class="nex_threadinertools_home"><a href="portal.php?mod=index&mobile=2"></a></li>
        <li class="nex_threadinertools_back"><a href="javascript:;" onclick="history.go(-1);"></a></li>
        <li class="nex_threadinertools_scrolltop"><a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a></li>
    </ul>
</div>

