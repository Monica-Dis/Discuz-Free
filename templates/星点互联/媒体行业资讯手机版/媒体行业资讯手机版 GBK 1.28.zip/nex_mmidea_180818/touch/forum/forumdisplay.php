<?php echo 'Ӧ�ø���֧�֣�https://dism.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template common/bottomnav}--> 
<!--{template common/sidetools}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_forum.css" />
<!-- header start -->
<div class="nex_bbstopnav_displaylist">
    <div class="nex_postbbsbtn"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]"></a></div>
    <h3>$_G['forum'][name]</h3>
    <a href="forum.php?forumlist=1" class="nexback"></a>
</div>
<div class="nex_forumbody">
<!-- header end -->
<div class="nex_bbsiners">
    <div class="nex_bbslist_icon">
        <!--{if $_G[forum][icon]}-->
        <!--{eval require_once libfile('function/group');}-->
        <img src="data/attachment/common/$_G[forum][icon]" alt="$_G[forum][name]" />
        <!--{else}-->
        <img src="$_G[style][styleimgdir]/bbs/forum_icon.jpg" alt="$_G[forum][name]" />
        <!--{/if}-->
    </div>	
    <div class="nex_bbslist_infos">
        <p>
            <span>{lang index_today}: $_G[forum][todayposts]</span>
            <span>{lang index_threads}: $_G[forum][threads]</span>
            <!--{if $_G[forum][rank]}-->
            <span>{lang rank}: $_G[forum][rank]</span>
            <!--{/if}-->
        </p>
        <a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum" id="a_favorite" class="nex_sc" onclick="showWindow(this.id, this.href, 'get', 0);">
        <span id="number_favorite_num">$_G[forum][favtimes]</span>
        <span id="number_favorite" {if !$_G[forum][favtimes]} {/if}>��ע</span>
        </a>
        
    </div>
    <div class="clear"></div>
</div>
<div class="nex_bbs_top_select">
    <ul>
        <li>
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter={if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == ''}on{/if}">ȫ��</a>
        </li>
        <li>
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'lastpost'}on{/if}">{lang latest}</a>
        </li>
        <li>
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'heat'}on{/if}">{lang order_heats}</a>
        </li>
        <li>
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'digest'}on{/if}">{lang digest_posts}</a>
        </li>
        <div class="clear"></div>
    </ul>
</div>
<!--{if $subexists && $_G['page'] == 1}-->
<div class="nex_sub_bk">
	<h5>�Ӱ��</h5>
	<ul>
        <!--{loop $sublist $sub}-->
        <li>
            <div class="nex_sublisticons">
            	<div class="nex_sub_list_Icon">
                <!--{if $sub[icon]}-->
                    <a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">$sub[icon]</a>
                <!--{else}-->
                	<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
                    	<img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" alt="$sub[name]" />
                    </a>
                <!--{/if}-->
                </div>
                <div class="nex_sub_list_Names"><a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a></div>
                <div class="clear"></div>
            </div>
        </li>
        <!--{/loop}-->
        <div class="clear"></div>
    </ul>
</div>
<!--{/if}-->

<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->
<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
<div class="nex_sortTypes">
    <ul>
        <!--{hook/forumdisplay_threadtype_inner}-->
        <li id="ttp_all" {if !$_GET['typeid'] && !$_GET['sortid']}class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a></li>
        <!--{if $_G['forum']['threadtypes']}-->
            <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
                <!--{if $_GET['typeid'] == $id}-->
                <li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
                <!--{else}-->
                <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
                <!--{/if}-->
            <!--{/loop}-->
        <!--{/if}-->
    
        <!--{if $_G['forum']['threadsorts']}-->
            <!--{if $_G['forum']['threadtypes']}--><li><span class="pipe">|</span></li><!--{/if}-->
            <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
                <!--{if $_GET['sortid'] == $id}-->
                <li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
                <!--{else}-->
                <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
                <!--{/if}-->
            <!--{/loop}-->
        <!--{/if}-->
        <!--{hook/forumdisplay_filter_extra}-->
        <div class="clear"></div>
    </ul>
</div>
<div class="clear"></div>
<script type="text/javascript">showTypes('thread_types');</script>
<!--{/if}-->
<!--{if !$subforumonly}-->
<!--{if $quicksearchlist && !$_GET['archiveid']}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_forum.css" />
<style type="text/css">
.nex_sortTypes,.nex_bbsiners,.nex_bbstopnav_displaylist{ display:none;}
.nex_forumbody{ background:#f7f7f7;}
</style>
<div class="nex_Sort_bg">
	<div class="nex_Sort_bginter">
    	<h5>$_G['forum'][name]</h5>
    	<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">��������</a>
    </div>
</div>
<!--{template forum/search_sortoption}-->
<!--{/if}-->
<!--{eval include 'template/nex_mmidea_180818/touch/php/picstylejustice.php'}-->
<!--{if $picstyle == '1'}-->
<div class="threadlist nex_threadlistpics">
    <ul class="nexwaterfall">
        <!--{if $_G['forum_threadcount']}-->
            <!--{loop $_G['forum_threadlist'] $key $thread}-->
            <!--{eval include 'template/nex_mmidea_180818/touch/php/picstyle.php'}-->
                <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
                    {eval continue;}
                <!--{/if}-->
                <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                    {eval $displayorder_thread = 1;}
                <!--{/if}-->
                <!--{if $thread['moved']}-->
                    <!--{eval $thread[tid]=$thread[closed];}-->
                <!--{/if}-->
                <li class="nexwateritems">
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] >	
                        <!--{hook/forumdisplay_thread_mobile $key}-->
                        <div class="nex_waterfallpic">
                        <!--{eval include 'template/nex_mmidea_180818/touch/php/picstyle.php'}-->
                        <!--{if $nextupian}-->
                        <img src="data/attachment/forum/$nextupian" style="width:100%;">
                        <!--{else}-->
                        <span class="nopic"></span>
                        <!--{/if}-->
                        <em>{$nextotlepivs}��</em>
                        </div>
                        <div class="nex_water_botm">
                            <h5 class="threadSubject $thread[highlight]">{$thread[subject]}</h5>
                            <div class="nex_water_tails">
                                <span class="nex_wt_view">$thread[views]</span>
                                <span class="nex_wt_reply">$thread[replies]</span>
                                <div class="clear"></div>
                            </div>
                        </div>
                     </a>
                </li>
            <!--{/loop}-->
        <!--{else}-->
        <li>{lang forum_nothreads}</li>
        <!--{/if}-->
    </ul>
</div>
<!--{else}-->
<!--{if empty($_G['forum']['sortmode'])}-->
<div class="nex_threadlisttxt">
	<ul>
	<!--{if $_G['forum_threadcount']}-->
		<!--{loop $_G['forum_threadlist'] $key $thread}-->
			<!--{eval include 'template/nex_mmidea_180818/touch/php/forum.php'}-->
			<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
				{eval continue;}
			<!--{/if}-->
			<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
				{eval $displayorder_thread = 1;}
			<!--{/if}-->
			<!--{if $thread['moved']}-->
				<!--{eval $thread[tid]=$thread[closed];}-->
			<!--{/if}-->
			<!--{if $nex_sortypes == '0'}-->
            <li>
            	<div class="nex_threadListNud">
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
                    	<div class="nex_threadListNud_txt">
                        	<h5>{$thread[subject]}</h5>
                            <div class="nex_threadlist_picmids">
                                <div class="nex_threadlist_picauthor">
                                    <!--{avatar($thread[authorid],big)}--><span>{$thread[author]}</span><div class="clear"></div>
                                </div>
                                <div class="nex_threadlist_picdate"><!--{echo date("Y-m-d",{$nex_bbs_date})}--></div>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_threadsums">$summary_echo</div>
                            <div class="nex_threadlist_picbtmsd">
                                <span class="nex_threadlist_picviews">$thread[views]</span>
                                <span class="nex_threadlist_picreplys">$thread[replies]</span>
                                <span class="nex_threadlist_picstypes">{$nex_sorttypename}</span>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </a>
                </div>
            </li>
            <!--{else}-->
                <!--{if $nex_threadlistspic}-->
                <li>
                    <div class="nex_threadListTit">
                        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
                            <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
                            <div class="nex_threadlist_picstylex"><img src="<!--{if $nex_threadsinpivs['remote']}-->                    			
                            {$_G['setting']['ftp']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                            <!--{else}-->         			
                            {$_G['setting']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                            <!--{/if}-->" /></div>
                            <!--{/loop}-->
                            <div class="nex_threadlist_picintels">
                                <h5>{$thread[subject]}</h5>
                                <div class="nex_threadlist_picmids">
                                    <div class="nex_threadlist_picauthor">
                                        <!--{avatar($thread[authorid],big)}--><span>{$thread[author]}</span><div class="clear"></div>
                                    </div>
                                    <div class="nex_threadlist_picdate"><!--{echo date("Y-m-d",{$nex_bbs_date})}--></div>
                                    <div class="clear"></div>
                                </div>
                                <div class="nex_threadlist_picbtmsd">
                                    <span class="nex_threadlist_picviews">$thread[views]</span>
                                    <span class="nex_threadlist_picreplys">$thread[replies]</span>
                                    <span class="nex_threadlist_picstypes">{$nex_sorttypename}</span>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </a>
                        
                    </div>
                </li>
                <!--{else}-->
                <li>
                    <div class="nex_threadListNud">
                        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
                            <div class="nex_threadListNud_txt">
                                <h5>{$thread[subject]}</h5>
                                <div class="nex_threadlist_picmids">
                                    <div class="nex_threadlist_picauthor">
                                        <!--{avatar($thread[authorid],big)}--><span>{$thread[author]}</span><div class="clear"></div>
                                    </div>
                                    <div class="nex_threadlist_picdate"><!--{echo date("Y-m-d",{$nex_bbs_date})}--></div>
                                    <div class="clear"></div>
                                </div>
                                <div class="nex_threadlist_picbtmsd">
                                    <span class="nex_threadlist_picviews">$thread[views]</span>
                                    <span class="nex_threadlist_picreplys">$thread[replies]</span>
                                    <span class="nex_threadlist_picstypes">{$nex_sorttypename}</span>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </a>
                    </div>
                </li>
                <!--{/if}-->
            <!--{/if}-->
            
		<!--{/loop}-->
		<div class="nex_bbs_pagetops">�ף���ҳ�Ѿ�������~</div>
	<!--{else}-->
		<li class="noData"></li>
	<!--{/if}-->
	</ul>
</div>
<!--{else}-->
<!--{subtemplate forum/forumdisplay_sort}-->
<style type="text/css">
.nex_bbs_top_select{ display:none;}
</style>
<!--{/if}-->
<!--{/if}-->
$multipage
<!--{/if}-->
<!-- main threadlist end -->
<!--{hook/forumdisplay_bottom_mobile}-->
<div class="pullrefresh" style="display:none;"></div>
</div>
<!--{template common/footer}-->

