<?php echo 'Copyright@Neoconex�ǵ㻥��-��Ȩ����';exit;?>
<!--{template common/header}-->
<div class="nex_bbstopnav_viewthread" style="border-bottom:0;">
    <a href="javascript:history.back()" class="z nexback"></a>
    <span class="category">
        ��������
    </span>
</div>

<div class="nex_main_search">
    <form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=portal&mobile=2">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <!--{subtemplate search/pubsearch}-->
        <!--{eval $policymsgs = $p = '';}-->
        <!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
        <!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
        <!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
        <!--{/loop}-->
        <!--{if $policymsgs}--><p>{lang search_credit_msg}</p><!--{/if}-->
    </form>
    <!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
        <!--{subtemplate search/portal_list}-->
    <!--{/if}-->
</div>


<!--{template common/footer}-->


