<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}


$nex_catids = DB::result(DB::query("SELECT catname FROM ".DB::table('portal_category')." WHERE catid = '$nex_search_article[catid]'"));
$nex_attachs = DB::result(DB::query("SELECT attachment FROM ".DB::table('forum_thread')." WHERE tid = '$nexsearch_thread[tid]'"));
$nex_search_threadfid = DB::result(DB::query("SELECT fid FROM ".DB::table('forum_thread')." WHERE tid = '$nexsearch_thread[tid]'"));
$nex_search_column = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$nex_search_threadfid'"));
?>
