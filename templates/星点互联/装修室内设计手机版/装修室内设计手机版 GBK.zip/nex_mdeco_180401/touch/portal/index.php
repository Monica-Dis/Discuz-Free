<?php echo 'Copyright@Neoconex�ǵ㻥��-ģ���Ȩ����';exit;?>
<!--{template common/header}-->
<!--{if file_exists('source/plugin/nex_decos_180401/inc.php') && $_G['cache']['plugin']['nex_decos_180401']}-->
<!--{eval require_once("source/plugin/nex_decos_180401/inc.php");}-->
<!--{/if}-->
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        
        <!--slider-->
        <div id="nex_index_focus" class="nex_index_focus">
        	
            <div class="hd">
                <ul></ul>
            </div>
			<!--�Ż�ͼƬ�õ�-->
            <!--{block/183}-->
        </div>
        
        <!--���-->
        
        <script type="text/javascript">
            TouchSlide({ 
                slideCell:"#nex_index_focus",
                titCell:".hd ul", //�����Զ���ҳ autoPage:true ����ʱ���� titCell Ϊ����Ԫ�ذ�����
                mainCell:".bd ul", 
                effect:"left", 
                autoPlay:true,//�Զ�����
                autoPage:true, //�Զ���ҳ
                switchLoad:"_src" //�л����أ���ʵͼƬ·��Ϊ"_src" 
            });
        </script>
        <!--fenlei-->
        <div class="nex_commonport">
       	  <div class="nex_sliderTOps">
		  	<!--�Ż���̬ͨ���л�-->
            	<!--{block/184}-->
            </div>
            <script type="text/javascript">
				jQuery(".nex_sliderTOps").slide({ mainCell:"ul", effect:"topLoop", vis:1,autoPlay:true, delayTime:1200,interTime:3500,easing:"easeInCubic"});
			</script>
            <div class="nex_iconsorts">
            	<ul>
					<!--�Ż���̬�Զ�������-->
                	<!--{block/185}-->
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--��������-->
        <div class="nex_applybox">
        	<div class="nex_applyboxTOP">
            	<i class="pre"></i>
                <span><em>10</em>�����������������</span>
                <i class="nex"></i>
            </div>
            
            <div class="nex_applyboxSUMMIT">
            <!--���������������ʼ-->
            	{$form[0]}
            	
            <!--�����������������-->
            </div>
        </div>
        <!--ads���λ-->
        <div class="nex_indexAds">
		<!--�Ż����λ1-->
		<!--{block/186}-->
		</div>
        <!--װ�ޱ���-->
        <div class="nex_offerbox">
        	<div class="nex_offerboxTOP">
            	<i class="pre"></i>
                <span><em>��ʱ��</em>���װ����Ʒ���</span>
                <i class="nex"></i>
                <div class="clear"></div>
            </div>
            <!--װ�ޱ������뿪ʼ-->
            {$form[1]}
            
            <!--װ�ޱ����������-->
        </div>
        <!--��ѡװ�ް���-->
        <div class="nex_normalport">
        	<div class="nex_normalportTOP">
            	<span>װ�ް���չʾ</span>
                <a href="#">����+</a>
                <div class="clear"></div>
            </div>
        	<div class="nex_casesort">
            	<ul>
					<!--�Ż�װ�ް���չʾ-->
                	<!--{block/187}-->
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--ads���λ-->
        <div class="nex_indexAds">
		<!--�Ż����λ2-->
                	<!--{block/188}-->
		</div>
        <!--���ʦչʾ-->
        <div class="nex_normalport">
        	<div class="nex_normalportTOP">
            	<span>���ʦչʾ</span>
                <a href="#">����+</a>
                <div class="clear"></div>
            </div>
            <div class="nex_designerbox">
            	<ul>
                	<!--�Ż����ʦչʾ-->
                	<!--{block/189}-->
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--ads���λ-->
        <div class="nex_indexAds">
		<!--�Ż����λ3-->
        <!--{block/190}-->
		</div>
        <!--װ��Ч��ͼ-->
        <div class="nex_normalport">
        	<div class="nex_normalportTOP">
            	<span>װ��Ч��ͼ</span>
                <a href="#">����+</a>
                <div class="clear"></div>
            </div>
            <div class="nex_showpic">
				<!--�Ż�װ��Ч��ͼ-->
				<!--{block/191}-->
                <div class="clear"></div>
            </div>
            <div class="nex_showsorts">
            	<ul>
				<!--�Ż��ֲ�װ��Ч��ͼ-->
				<!--{block/192}-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--ѧװ���ʴ�ģ��-->
        <div class="nex_normalport">
        	<div class="nex_normalportTOP">
            	<span>ѧװ���ʴ�</span>
                <a href="#">����+</a>
                <div class="clear"></div>
            </div>
            <div class="nex_zxglport">
            	<ul>
                	<li class="ons">���¾�ѡ</li>
                    <li>װ���ʴ�</li>
                    <li>װ���ռ�</li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_zxcontsd">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_glTop">
                        	<dl>
								<!--�Ż�ѧװ���ʴ��Զ�������-->
								<!--{block/193}-->
                            	
                                <div class="clear"></div>
                            </dl>
                        </div>
                        <div class="nex_glBtm">
                        	<dl>
								<!--�Ż�ѧװ����Ѷ����-->
								<!--{block/194}-->
                            	
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_glBtsm">
                        	<dl>
                            	<!--�Ż�ѧװ��װ���ʴ�-->
								<!--{block/195}-->
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_glBtsm">
                        	<dl>
                            	<!--�Ż�ѧװ��װ���ռ�-->
								<!--{block/196}-->
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_zxglport ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("ons").siblings().removeClass("ons");
						jQuery(".nex_zxcontsd ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
        </div>
        <!--ads���λ-->
        <div class="nex_indexAds">
		<!--�Ż����λ4-->
		<!--{block/197}-->
		</div>
        <!--װ�޹���-->
        <div class="nex_normalport">
        	<div class="nex_normalportTOP">
            	<span>��ѡװ�޹���</span>
                <a href="#">����+</a>
                <div class="clear"></div>
            </div>
            <div class="nex_zxInfo">
            	<ul>
                	<!--�Ż���ѡװ�޹���-->
					<!--{block/198}-->
                </ul>
            </div>
        </div>
        <!--��������-->
        <div class="nex_normalport">
			<!--�Ż��������ǽ���-->
			<!--{block/199}-->
        	
        </div>
        <!--���߿ͷ�-->
        <div class="nex_normalport">
        	<div class="nex_onlineservl"></div>
            <div class="nex_onlineservr">
				<!--�Ż��ͷ�ģ��-->
				<!--{block/200}-->
            	
            </div>
            <div class="clear"></div>
        </div>
        
        <!--{template common/footer}-->
	</div>	
</div>

<div class="pullrefresh" style="display:none;"></div>


