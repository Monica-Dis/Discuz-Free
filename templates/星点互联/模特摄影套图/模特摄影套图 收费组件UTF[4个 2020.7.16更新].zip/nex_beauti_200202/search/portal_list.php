<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval include 'template/nex_beauti_200202/php/nex_blog.php'}-->
<div class="tl">
	<!--{ad/search/y mtw}-->
	<!--{if empty($articlelist)}-->
		<div class="nex_emp_notice">
        	<em></em>
            <h5>{lang search_nomatch}</h5>
        </div>
	<!--{else}-->
		<div class="nex_showarticles">
			<ul>
				<!--{loop $articlelist $article}-->
                <!--{if $article[pic]}-->
                <li>
                    <div class="nex_search_article_inner">
                        <div class="nex_show_article_pics"><a href="{echo fetch_article_url($article);}" target="_blank" style="background:url($article[pic]) center no-repeat; background-size:cover;"></a></div>
                        <div class="nex_show_article_info">
                        	<h5><em>{$nex_catids}</em><a href="{echo fetch_article_url($article);}" target="_blank">$article[title]</a></h5>
                            <div class="nex_art_sums">$article[summary]</div>
                            <div class="nex_show_article_tools">
                                <span>by<a href="home.php?mod=space&uid={$article[uid]}&do=thread&view=me&from=space" target="_blank">{$article[username]}</a></span>
                                <em>
                                    <i>{$article[viewnum]} 阅读</i>
                                    <i>{$article[commentnum]} 评论</i>
                                    <i>{$article[dateline]} 发布</i>
                                </em>
                                <div class="clear"></div>
                            </div>
                        </div>
                        <div class="clear"></div>
                        
                    </div>
                </li>
                <!--{else}-->
                <li>
                    <div class="nex_search_article_inner">
                        <div class="nex_show_article_info_null">
                        	<h5><em>{$nex_catids}</em><a href="{echo fetch_article_url($article);}" target="_blank">$article[title]</a></h5>
                            <div class="nex_art_sums">$article[summary]</div>
                            <div class="nex_show_article_tools">
                                <span>by<a href="home.php?mod=space&uid={$article[uid]}&do=thread&view=me&from=space" target="_blank">{$article[username]}</a></span>
                                <em>
                                    <i>{$article[viewnum]} 阅读</i>
                                    <i>{$article[commentnum]} 评论</i>
                                    <i>{$article[dateline]} 发布</i>
                                </em>
                                <div class="clear"></div>
                            </div>
                        </div>
                        <div class="clear"></div>
                        
                    </div>
                </li>
                <!--{/if}-->
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>