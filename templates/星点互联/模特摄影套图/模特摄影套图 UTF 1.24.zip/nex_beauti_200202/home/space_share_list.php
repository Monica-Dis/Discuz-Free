<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<!--{if $diymode}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
		<div id="ct" class="ct2 wp cl">
			<div class="mn">
				<div class="bm">
					<div class="bm_h">
						<h1 class="mt">{lang share}</h1>
					</div>
				<div class="bm_c">
	<!--{else}-->
		<!--{template common/header}-->
		<div id="pt" class="bm cl">
			<div class="z">
				<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
				<a href="home.php?mod=space&uid=$space[uid]">{$space[username]}</a> <em>&rsaquo;</em>
				<a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space">{lang share}</a>
			</div>
		</div>
		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="ct1 wp cl">
			<div class="mn">
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<div class="bm bw0">
					<div class="bm_c">
	<!--{/if}-->
	<!--{if helper_access::check_module('share') && $space[self]}-->
	<!--{template home/space_share_form}-->
	<!--{/if}-->
<!--{else}-->
	<!--{template common/header}-->
	<div id="pt" class="bm cl">
		<div class="z">
			<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
			<a href="home.php?mod=space&do=share">{lang share}</a>
		</div>
	</div>
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ct" class="ct2_a wp cl">
		<!--{if $_G[setting][homestyle]}-->
			<div class="appl">
				<!--{subtemplate common/userabout}-->
			</div>
			<div class="mn pbm">
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<!--{if helper_access::check_module('share') && $space[self]}-->
				<!--{template home/space_share_form}-->
				<!--{/if}-->
				<div class="bm bw0">
					<ul class="tb cl">
						<li$actives[we]><a href="home.php?mod=space&do=share&view=we">{lang friend_share}</a></li>
						<li$actives[me]><a href="home.php?mod=space&do=share&view=me">{lang my_share}</a></li>
						<li$actives[all]><a href="home.php?mod=space&do=share&view=all">{lang view_all}</a></li>
					</ul>
				</div>
		<!--{else}-->
			<div class="appl">
				<div class="tbn">
					<h2 class="mt bbda">{lang share}</h2>
					<ul>
						<li$actives[we]><a href="home.php?mod=space&do=share&view=we">{lang friend_share}</a></li>
						<li$actives[me]><a href="home.php?mod=space&do=share&view=me">{lang my_share}</a></li>
						<li$actives[all]><a href="home.php?mod=space&do=share&view=all">{lang view_all}</a></li>
					</ul>
				</div>
			</div>
			<div class="mn pbm">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<!--{if helper_access::check_module('share') && $space[self]}-->
			<!--{template home/space_share_form}-->
			<!--{/if}-->
		<!--{/if}-->
<!--{/if}-->
		<p class="tbmu">
			{lang order_by_type}:
			<a href="$navtheurl&type=all"$sub_actives[type_all]>{lang share_all}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=link"$sub_actives[type_link]>{lang share_link}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=video"$sub_actives[type_video]>{lang share_video}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=music"$sub_actives[type_music]>{lang share_music}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=flash"$sub_actives[type_flash]>{lang share_flash}</a><span class="pipe">|</span>
			<!--{if helper_access::check_module('blog')}-->
			<a href="$navtheurl&type=blog"$sub_actives[type_blog]>{lang share_blog}</a><span class="pipe">|</span>
			<!--{/if}-->
			<!--{if helper_access::check_module('album')}-->
			<a href="$navtheurl&type=album"$sub_actives[type_album]>{lang share_album}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=pic"$sub_actives[type_pic]>{lang share_pic}</a><span class="pipe">|</span>
			<!--{/if}-->
			<a href="$navtheurl&type=poll"$sub_actives[type_poll]>{lang share_poll}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=space"$sub_actives[type_space]>{lang share_space}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=thread"$sub_actives[type_thread]>{lang share_thread}</a>
			<!--{if helper_access::check_module('portal')}-->
			<span class="pipe">|</span>
			<a href="$navtheurl&type=article"$sub_actives[type_article]>{lang share_article}</a>
			<!--{/if}-->
		</p>
		<!--{if $list}-->
			<ul id="share_ul" class="el sl">
				<!--{loop $list $k $value}-->
					<!--{template home/space_share_li}-->
				<!--{/loop}-->
			</ul>
			<!--{if $pricount}-->
				<p class="mtm">{lang hide_share}</p>
			<!--{/if}-->
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
		<!--{else}-->
			<ul id="share_ul" class="el sl"></ul>
            <div class="nex_emp_notice">
                <em></em>
                <h5>{lang not_share_yet}</h5>
            </div>
		<!--{/if}-->
		
		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="sd">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->


<script type="text/javascript">
	function succeedhandle_shareadd(url, msg, values) {
		share_add(values['sid']);
	}
</script>
<!--{template common/footer}-->