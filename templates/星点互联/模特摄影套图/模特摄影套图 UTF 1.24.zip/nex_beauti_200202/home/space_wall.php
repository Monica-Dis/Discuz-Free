<?php echo 'Copyright@Neoconex星点互联-模板版权所有';exit;?>
<!--{eval $_G['home_tpl_titles'] = array('{lang message}');}-->


<!--{if $_G[setting][homepagestyle]}-->
	<!--{subtemplate home/space_header}-->
	<div id="ct" class="ct2 wp cl">
		<div class="mn">
			<div class="bm">
				<div class="bm_h">
					<h1 class="mt">{lang message}</h1>
				</div>
			<div class="bm_c">
<!--{else}-->
	<!--{template common/header}-->
	<div id="pt" class="bm cl">
		<div class="z">
			<a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a> <em>&rsaquo;</em>
			<a href="home.php?mod=space&uid=$space[uid]">{$space[username]}</a> <em>&rsaquo;</em>
			<a href="home.php?mod=space&uid=$space[uid]&do=wall&from=space">{lang message}</a>
		</div>
	</div>
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<!--{template home/space_menu}-->
	<div id="ct" class="ct1 wp cl">
		<div class="mn">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<div class="bm_c">
<!--{/if}-->
		<!--{if helper_access::check_module('wall')}-->
		<form id="quickcommentform_{$space[uid]}" action="home.php?mod=spacecp&ac=comment" method="post" autocomplete="off" onsubmit="ajaxpost('quickcommentform_{$space[uid]}', 'return_qcwall_$space[uid]');doane(event);">
			<p>
				<span id="comment_face" title="{lang insert_emoticons}" onclick="showFace(this.id, 'comment_message');return false;" class="cur1"><img src="{IMGDIR}/facelist.gif" alt="facelist" class="vm" /></span>
				<!--{hook/space_wall_face_extra}-->
				<!--{if $_G['setting']['magicstatus'] && $_G['setting']['magics']['doodle']}-->
				<a id="a_magic_doodle" href="home.php?mod=magic&mid=doodle&showid=comment_doodle&target=comment_message" onclick="showWindow(this.id, this.href, 'get', '0')"><img src="{STATICURL}image/magic/doodle.small.gif" alt="doodle" class="vm" />{$_G[setting][magics][doodle]}</a>
				<!--{/if}-->
			</p>
			<div class="tedt mtn mbn">
				<div class="area">
					<!--{if $_G['uid'] || $_G['group']['allowcomment']}-->
						<textarea id="comment_message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');" name="message" rows="5" class="pt"></textarea>
					<!--{elseif $_G['connectguest']}-->
						<div class="pt hm">{lang connect_fill_profile_to_comment}</div>
					<!--{else}-->
						<div class="pt hm">{lang login_to_wall} <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)" class="xi2">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}" class="xi2">$_G['setting']['reglinkname']</a></div>
					<!--{/if}-->
				</div>
			</div>
			<p>
				<input type="hidden" name="referer" value="home.php?mod=space&uid=$wall[uid]&do=wall" />
				<input type="hidden" name="id" value="$space[uid]" />
				<input type="hidden" name="idtype" value="uid" />
				<input type="hidden" name="handlekey" value="qcwall_{$space[uid]}" />
				<input type="hidden" name="commentsubmit" value="true" />
				<input type="hidden" name="quickcomment" value="true" />
				<button type="submit" name="commentsubmit_btn"value="true" id="commentsubmit_btn" class="pn"><strong>{lang leave_comments}</strong></button>
				<span id="return_qcwall_{$space[uid]}"></span>
			</p>
			<input type="hidden" name="formhash" value="{FORMHASH}" />
		</form>
		<hr class="da mtm m0" />
		<!--{/if}-->
		<div id="div_main_content" class="mtm mbm nex_comment_borde">
			<div id="comment">
				<!--{if $cid}-->
				<div class="i">
					{lang view_one_operation_message},<a href="home.php?mod=space&uid=$space[uid]&do=wall">{lang click_view_message}</a>
				</div>
				<!--{/if}-->
				<div id="comment_ul" class="xld xlda">
                	<ul>
                    <!--{loop $list $k $value}-->
                        <!--{template home/space_comment_li}-->
                    <!--{/loop}-->
                    </ul>
				</div>
			</div>
			<div class="pgs cl mtm">$multi</div>
		</div>
		<script type="text/javascript">
			var elems = selector('dd[class~=magicflicker]');
			for(var i=0; i<elems.length; i++){
				magicColor(elems[i]);
			}
			function succeedhandle_qcwall_{$space[uid]}(url, msg, values) {
				wall_add(values['cid']);
			}
		</script>

		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="sd">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->

<!--{template common/footer}-->