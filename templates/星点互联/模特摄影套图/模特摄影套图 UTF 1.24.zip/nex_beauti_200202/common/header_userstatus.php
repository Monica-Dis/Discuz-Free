<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<div class="nexlogin">                 
		<!--{if $_G['uid']}-->
        <!--{eval include 'template/nex_beauti_200202/php/nex_users.php'}-->
        <div class="nexallmember">
            <div id="nexmemberinfo_layer">
                <a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">
                	<div class="nex_layer_avator"><!--{avatar($_G[uid],big)}--></div>
                    <div class="nex_layer_name">{$_G[member][username]}</div>
                    <div class="clear"></div>
                </a>
            </div>
            <div id="nexmembercontent_layer">
                <div class="nex_mem_topbox">
                	<div class="nex_mem_tools">
                    	<ul>
                        	<li class="nex_mem_notice">
                            	<a href="home.php?mod=space&do=pm&filter=newpm" title="消息短信" target="_blank">
                                    <!--{if $_G[member][newpm]}-->
                                    <em></em>
                                    <!--{elseif $_G[member][newprompt]}-->
                                    <em></em>
                                    <!--{/if}-->
                                </a>
                            </li>
                            <li class="nex_mem_settings"><a href="home.php?mod=spacecp&ac=avatar" title="个人设置" target="_blank"></a></li>
                        </ul>
                    </div>
                	<div class="nex_mem_topbox_users">
                    	<div class="nexmemberavator"><!--{avatar($_G[uid],big)}--></div>
                        <div class="nexmemberintels">
                        	<h5>{$_G[member][username]}</h5>
                            <p>ID：{$nex_userid}</p>
                            <ul>
                            	<!--{if $nex_uc_province == '' || $nex_uc_adds == ''}-->
                                <li>未知地域</li>
                                <!--{else}-->
                            	<li>{$nex_uc_province}{$nex_uc_adds}</li>
                                <!--{/if}-->
                                <!--{if $nex_uc_occu == ''}-->
                                <!--{else}-->
                                <li>{$nex_uc_occu}</li>
                                <!--{/if}-->
                                </li>
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="nex_member_pad">
                    <div class="nex_mem_midbox">
                        <div class="nexmemberinfos">
                            <ul>
                                <li class="nexmemberinfos_1">
                                    <p>$_G[member][credits]</p>
                                    <div class="nexmemberinfoterms">积分</div>
                                </li>
                                <li class="nexmemberinfos_2">
                                    <p>{$nex_user_element[threads]}</p>
                                    <div class="nexmemberinfoterms">发布</div>
                                </li>
                                <li class="nexmemberinfos_3">
                                    <p>{$nex_user_element[following]}</p>
                                    <div class="nexmemberinfoterms">关注</div>
                                </li>
                                <li class="nexmemberinfos_4">
                                    <p>{$nex_user_element[follower]}</p>
                                    <div class="nexmemberinfoterms">粉丝</div>
                                </li>
                                
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="nexmemberinfobtn"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}"><b></b>{lang visit_my_space}</a></div>
                    </div>
                    <div class="nexmembercontent_Btm">
                        <ul>
                            <li>
                                <!--{if check_diy_perm($topic)}-->
                                $diynav
                                <!--{else}-->
                                <a href="home.php?mod=space&do=notice&view=interactive&type=friend" target="_blank">
                                    <span class="nex_icon1"></span>
                                    <p>好友</p>
                                </a>
                                <!--{/if}-->
                            </li>
                            <li>
                                <a href="forum.php?mod=guide&view=my" target="_blank">
                                    <span class="nex_icon2"></span>
                                    <p>帖子</p>
                                </a>								
                            </li>
                            <li>
                                <a class="" href="home.php?mod=space&amp;do=notice&amp;type=post&amp;isread=$_G[uid]" target="_blank">
                                    <span class="nex_icon3"></span>
                                    <p>回复</p>
                                </a>							
                            </li>
                            <li>
                                <a href="home.php?mod=space&do=favorite&view=me" target="_blank">
                                    <span class="nex_icon4"></span>
                                    <p>收藏</p>
                                </a>
                            </li>
                            <li>
                                <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">
                                    <span class="nex_icon5"></span>
                                    <p>退出</p>
                                </a>
                            </li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nexmembercontent_hook"><!--{hook/global_usernav_extra1}--><!--{hook/global_usernav_extra2}--><!--{hook/global_usernav_extra3}--><!--{hook/global_usernav_extra4}--></div>
                    <div class="clear"></div>
                </div>
            </div>
            <script type="text/javascript">
                jQuery("#nexmemberinfo_layer").hover(
                    function(){
                        jQuery(this).siblings("#nexmembercontent_layer").show();
                        },
                    function(){
                        jQuery(this).siblings("#nexmembercontent_layer").hide();
                        })
                 jQuery("#nexmembercontent_layer").hover(
                    function(){
                        jQuery(this).show();
                        jQuery(this).siblings("#nexmemberinfo_layer").addClass("nex_curs");
                        },
                    function(){
                        jQuery(this).hide();
                        jQuery(this).siblings("#nexmemberinfo_layer").removeClass("nex_curs");
                        })
            </script>
        </div>
   		<ul>
     	<!--{elseif !empty($_G['cookie']['loginuser'])}-->
            <li><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></li>
            <li><a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang activation}</a></li>
            <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
    	<!--{elseif !$_G[connectguest]}-->
            <div class="nexmain_dls_layer">
                <ul>
                	<li><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">登陆</a></li>
                    <li><a href="member.php?mod={$_G[setting][regname]}">注册</a></li>
                    <div class="clear"></div>
                </ul>
            </div>
     	<!--{else}-->
            <div class="nex_qq_kuang">
                <div class="nex_qq_kuang_before">QQ资料</div>
                <div class="nex_qq_kuang_after">
                    <div id="um">
                        <div class="avt y"><!--{avatar(0,small)}--></div>
                        <div class="nex_qq_lines">
                            <strong class="vwmy qq">{$_G[member][username]}</strong>
                            <!--{hook/global_usernav_extra1}-->
                            <span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
                        </div>
                        <div class="nex_qq_lines">
                            <a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a>
                            <span class="pipe">|</span>{lang usergroup}: $_G[group][grouptitle]
                        </div>
                    </div>
                </div>
                <script type="text/javascript">
                    jq(".nex_qq_kuang").hover(
                        function(){
                            jq(this).children(".nex_qq_kuang_after").show();
                            },
                        function(){
                            jq(this).children(".nex_qq_kuang_after").hide();
                            })
                    
                </script>
            </div>
        <!--{/if}-->
    	</ul>
</div>