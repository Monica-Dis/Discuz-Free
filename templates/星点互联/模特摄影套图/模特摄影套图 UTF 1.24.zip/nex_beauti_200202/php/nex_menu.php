<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_authorid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]'"));
$nex_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_occu = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_pos = DB::result(DB::query("SELECT position FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_comp = DB::result(DB::query("SELECT company FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_usercp = DB::result(DB::query("SELECT customstatus FROM ".DB::table('common_member_field_forum')." WHERE uid = '$space[uid]'"));
$nex_intro = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_style = DB::result(DB::query("SELECT interest FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_designer_threads = DB::result(DB::query("SELECT threads FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]'"));
$nex_pricerange = DB::result(DB::query("SELECT affectivestatus FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_exp = DB::result(DB::query("SELECT lookingfor FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_upids = DB::result(DB::query("SELECT fid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'")); $nex_fromname = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$nex_upids'"));
$nex_catids = DB::result(DB::query("SELECT catname FROM ".DB::table('portal_category')." WHERE catid = '$article[catid]'"));
$nexgroup = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$space[uid]'"));
$nex_user_elements = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]'");
?>