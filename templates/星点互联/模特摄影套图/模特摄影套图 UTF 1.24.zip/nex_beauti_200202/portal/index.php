<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<!--{template common/header_index}-->

<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <!--index_main-->
	<div class="nex_displacement">
    	<div class="w1240">
        	<div class="nex_displacement_l">
            	<div class="nex_displacement_focusBox">
                	<!--[diy=nex_displacement_focusBox]--><div id="nex_displacement_focusBox" class="area"></div><!--[/diy]-->
                    
                    <a class="prev" href="javascript:void(0)"></a>
                    <a class="next" href="javascript:void(0)"></a>
                    <ul class="hd">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                    </ul>
                </div>
            
                <script type="text/javascript">
                    jQuery(".nex_displacement_focusBox").slide({ mainCell:".pic",effect:"left", autoPlay:true, delayTime:300});
                </script>
                <div class="nex_displacement_collection">
                	<ul>
                    	<!--[diy=nex_displacement_collection]--><div id="nex_displacement_collection" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <div class="nex_displacement_r">
            	<div class="nex_displacement_r_ads"><!--[diy=nex_displacement_r_ads]--><div id="nex_displacement_r_ads" class="area"></div><!--[/diy]--></div>
                <div class="nex_displacement_r_rk">
                	<div class="nex_inner_title"><span>小编推荐</span></div>
                    <div class="nex_displacement_rklist">
                    	<ul>
                        	<!--[diy=nex_displacement_rklist]--><div id="nex_displacement_rklist" class="area"></div><!--[/diy]-->
                            
                            
                        </ul>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <div class="nex_rt_local">
        
        <!--最新上传-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>最新上传</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                    	<!--[diy=nex_photo_grid_box1]--><div id="nex_photo_grid_box1" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--萝莉套图-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>萝莉套图</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                        <!--[diy=nex_photo_grid_box2]--><div id="nex_photo_grid_box2" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--私房写真套图-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>私房写真套图</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                       <!--[diy=nex_photo_grid_box3]--><div id="nex_photo_grid_box3" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--COSPLAY套图-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>COSPLAY套图</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                        <!--[diy=nex_photo_grid_box4]--><div id="nex_photo_grid_box4" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--唯美清纯美女套图-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>唯美清纯美女套图</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                        <!--[diy=nex_photo_grid_box5]--><div id="nex_photo_grid_box5" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--列表-->
        <div class="nex_model_list">
            <div class="w1240">
                <div class="nex_model_grids">
                	<ul>
                    	<li>
                        	<div class="nex_model_title"><span class="nex_mg_num1">最新上传套图</span></div>
                            <div class="nex_liststyles">
                            	<dl>
                                	<!--[diy=nex_liststyles1]--><div id="nex_liststyles1" class="area"></div><!--[/diy]-->
                                    
                                    
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_model_title"><span class="nex_mg_num2">综合排行</span></div>
                            <div class="nex_liststyles">
                            	<dl>
                                	<!--[diy=nex_liststyles2]--><div id="nex_liststyles2" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_model_title"><span class="nex_mg_num3">人气最旺</span></div>
                            <div class="nex_liststyles">
                            	<dl>
                                	<!--[diy=nex_liststyles13]--><div id="nex_liststyles13" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_model_title"><span class="nex_mg_num4">热门标签</span></div>
                            <div class="nex_tage_lists">
                            	<dl>
                                	<!--[diy=nex_tage_lists]--><div id="nex_tage_lists" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--友情链接-->
        <div class="nex_friendly_link">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>友情链接</span>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">交换友情链接，联系QQ1234646123</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_fl_box">
                    <ul>
                    	<!--[diy=nex_fl_box]--><div id="nex_fl_box" class="area"></div><!--[/diy]-->
                   
                    	<div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>    
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

