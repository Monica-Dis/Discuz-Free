<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<!--{ad/search/y mtw}-->
	<!--{if empty($albumlist)}-->
		<div class="nex_emp_notice">
        	<em></em>
            <h5>{lang search_nomatch}</h5>
        </div>
	<!--{else}-->
		<div class="nex_album_list">
			<ul>
				<!--{loop $albumlist $key $value}-->
					<li>
						<div class="nex_album_cover"><a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" target="_blank"><!--{if $value[pic]}--><img src="$value[pic]" /><!--{/if}--></a></div>
						<h5><a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" target="_blank">$value[albumname]</a></h5>
					</li>
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
		<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
	<!--{/if}-->
</div>

