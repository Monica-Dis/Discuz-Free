<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}

$nex_authoridx = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'")); 
$nex_author_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_author_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_author_occu = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));

$nex_grids = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$nex_authoridx'"));
$nex_online = DB::result(DB::query("SELECT msn FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_grids'"));
$usergroupID = DB::fetch_first("SELECT t1.*, t2.* FROM ".DB::table('common_member')." t1 LEFT JOIN ".DB::table('common_usergroup')." t2 ON t1.groupid=t2.groupid WHERE t1.uid ='$nex_authoridx'");
$nex_userid = DB::result(DB::query("SELECT uid FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_user_coins = DB::result(DB::query("SELECT extcredits2 FROM ".DB::table('common_member_count')." WHERE uid = '$nex_authoridx'"));
$nex_user_elements = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$nex_authoridx'");
$nex_intros = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));


$nex_curtid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$_G[tid]'"));
$nexgroup = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$nex_curtid'"));
$nex_designer_pop = DB::fetch_first("SELECT * FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_curtid'");
$nex_designer_quantity = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$nex_curtid'");

$nex_ucthread = C::t('forum_thread')->fetch_all_by_authorid($_G['forum_thread']['authorid'], 0,5);
$nex_ucauthor = DB::fetch_first("SELECT `follower`,`threads`,`following` FROM ".DB::table('common_member_count')." WHERE uid = ".$_G['forum_thread']['authorid']);

$nex_medal_list=array();
$mls=DB::query("SELECT a.*,b.* FROM ".DB::table("common_member_medal")." a LEFT JOIN ".DB::table("forum_medal")." b on b.medalid=a.medalid WHERE b.`available` <> 0 AND a.`uid`='$nex_authoridx' ORDER BY b.`displayorder` ASC LIMIT 0,20");
while ($ml=DB::fetch($mls)) {
        $nex_medal_list[]=$ml;
}


$nex_tintros = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_curtid'"));


?>
