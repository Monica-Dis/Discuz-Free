<?php echo 'Ӧ�ø���֧�֣�https://dism.taobao.com';exit;?>
<!--{template common/header_index}-->

<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <!--index_main-->
	<div class="nex_displacement">
    	<div class="w1240">
        	<div class="nex_displacement_l">
            	<div class="nex_displacement_focusBox">
                	<!--[diy=nex_displacement_focusBox]--><div id="nex_displacement_focusBox" class="area"></div><!--[/diy]-->
                    
                    <a class="prev" href="javascript:void(0)"></a>
                    <a class="next" href="javascript:void(0)"></a>
                    <ul class="hd">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                    </ul>
                </div>
            
                <script type="text/javascript">
                    jQuery(".nex_displacement_focusBox").slide({ mainCell:".pic",effect:"left", autoPlay:true, delayTime:300});
                </script>
                <div class="nex_displacement_collection">
                	<ul>
                    	<!--[diy=nex_displacement_collection]--><div id="nex_displacement_collection" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <div class="nex_displacement_r">
            	<div class="nex_displacement_r_ads"><!--[diy=nex_displacement_r_ads]--><div id="nex_displacement_r_ads" class="area"></div><!--[/diy]--></div>
                <div class="nex_displacement_r_rk">
                	<div class="nex_inner_title"><span>С���Ƽ�</span></div>
                    <div class="nex_displacement_rklist">
                    	<ul>
                        	<!--[diy=nex_displacement_rklist]--><div id="nex_displacement_rklist" class="area"></div><!--[/diy]-->
                            
                            
                        </ul>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <div class="nex_rt_local">
        
        <!--�����ϴ�-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>�����ϴ�</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                    	<!--[diy=nex_photo_grid_box1]--><div id="nex_photo_grid_box1" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--������ͼ-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>������ͼ</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                        <!--[diy=nex_photo_grid_box2]--><div id="nex_photo_grid_box2" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--˽��д����ͼ-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>˽��д����ͼ</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                       <!--[diy=nex_photo_grid_box3]--><div id="nex_photo_grid_box3" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--COSPLAY��ͼ-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>COSPLAY��ͼ</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                        <!--[diy=nex_photo_grid_box4]--><div id="nex_photo_grid_box4" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--Ψ���崿��Ů��ͼ-->
        <div class="nex_photo_grid">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>Ψ���崿��Ů��ͼ</span>
                    <ul></ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_photo_grid_box">
                    <ul>
                        <!--[diy=nex_photo_grid_box5]--><div id="nex_photo_grid_box5" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--�б�-->
        <div class="nex_model_list">
            <div class="w1240">
                <div class="nex_model_grids">
                	<ul>
                    	<li>
                        	<div class="nex_model_title"><span class="nex_mg_num1">�����ϴ���ͼ</span></div>
                            <div class="nex_liststyles">
                            	<dl>
                                	<!--[diy=nex_liststyles1]--><div id="nex_liststyles1" class="area"></div><!--[/diy]-->
                                    
                                    
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_model_title"><span class="nex_mg_num2">�ۺ�����</span></div>
                            <div class="nex_liststyles">
                            	<dl>
                                	<!--[diy=nex_liststyles2]--><div id="nex_liststyles2" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_model_title"><span class="nex_mg_num3">��������</span></div>
                            <div class="nex_liststyles">
                            	<dl>
                                	<!--[diy=nex_liststyles13]--><div id="nex_liststyles13" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_model_title"><span class="nex_mg_num4">���ű�ǩ</span></div>
                            <div class="nex_tage_lists">
                            	<dl>
                                	<!--[diy=nex_tage_lists]--><div id="nex_tage_lists" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--��������-->
        <div class="nex_friendly_link">
            <div class="w1240">
                <div class="nex_photo_grid_title">
                    <span>��������</span>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank">�����������ӣ���ϵQQ1234646123</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_fl_box">
                    <ul>
                    	<!--[diy=nex_fl_box]--><div id="nex_fl_box" class="area"></div><!--[/diy]-->
                   
                    	<div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>    
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->


