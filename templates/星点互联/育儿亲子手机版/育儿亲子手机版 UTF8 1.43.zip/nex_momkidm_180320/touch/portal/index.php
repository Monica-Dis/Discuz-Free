<?php echo 'Copyright@DISM.TAOBAO.COM dism.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template common/bottomnav}-->
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        
        <!--顶部菜单导航-->
        <div class="nex_index_rollmenus">
        	<ul>
            	<li><a href="#">推荐阅读</a></li>
                <li><a href="#">孕妈备孕</a></li>
                <li><a href="#">时尚美容</a></li>
                <li><a href="#">辣妈晒照</a></li>
                <li><a href="#">情感婚姻</a></li>
                <li><a href="#">美食厨房</a></li>
                <li><a href="#">谈天说地</a></li>
                <li><a href="#">家有两宝</a></li>
                <li><a href="#">难孕难育</a></li>
                <li><a href="#">穿衣搭配</a></li>
                <div class="clear"></div>
            </ul>
        </div>
        <!--slider-->
        <div id="nex_index_focus" class="nex_index_focus">
        	
            <div class="hd">
                <ul></ul>
            </div>
            <div class="bd">
            	<!--门户幻灯资讯-->
                
                
            </div>
        </div>
        
        <!--板块-->
        
        <div class="nex_index_favs">
        	<div class="nex_waveBox">
            <canvas id="myCanvas1" height="200"></canvas>
            <canvas id="myCanvas2" height="200"></canvas>
            <canvas id="myCanvas3" height="200"></canvas>
        </div>
        <script type="text/javascript">
            TouchSlide({ 
                slideCell:"#nex_index_focus",
                titCell:".hd ul", //开启自动分页 autoPage:true ，此时设置 titCell 为导航元素包裹层
                mainCell:".bd ul", 
                effect:"left", 
                autoPlay:true,//自动播放
                autoPage:true, //自动分页
                switchLoad:"_src" //切换加载，真实图片路径为"_src" 
            });
        </script>
        
        <script>
		(function () {
			wave2();wave3();
		})();
		
			params = {
				ctx :  document.getElementById("myCanvas1"),
				waveHeight:15,//波浪高度
				waveCount:6,//波浪个数
				progress:100,//波浪位置的高度
				// fillStyle:'#95cef7', //颜色
				fillStyle:'rgba(255, 255, 255, 0.6)', //颜色
			}
			DrawBall(params)
		function DrawBall (Params){
			var waveWidth = 3300, offset = 0, startX = -1000, startY = 200,   //canvas 高度
			d2 = waveWidth / Params.waveCount,d = d2 / 2, hd = d / 2;
			Params.ctx.width = 675
			ctx = Params.ctx.getContext("2d");
			function tick() {
				offset -= 5;
				if (-1 * offset === d2) offset = 0;
				ctx.clearRect(0, 0, Params.ctx.width, Params.ctx.height);
				ctx.fillStyle = Params.fillStyle;  
				ctx.beginPath();
				var offsetY = startY - Params.progress;
				ctx.moveTo(startX - offset, offsetY);
				for (var i = 0; i < Params.waveCount; i++) {
					var dx = i * d2;
					var offsetX = dx + startX - offset;
					ctx.quadraticCurveTo(offsetX + hd, offsetY + Params.waveHeight, offsetX + d, offsetY);
					ctx.quadraticCurveTo(offsetX + hd + d, offsetY - Params.waveHeight, offsetX + d2, offsetY);
				}
				ctx.lineTo(startX + waveWidth, 3000);
				ctx.lineTo(startX, 3000);
				ctx.fill();
				requestAnimationFrame(tick);
			}
			tick();
		}
		 /* 第二条 */
		function wave2(){
			var waveWidthB = 3300,
			offsetB = 0,
			waveHeightB = 15,  //波浪高度
			waveCountB = 5,  //波浪个数
			startXB = -1000,
			startYB = 200,   //canvas 高度
			progressB = 90,  //波浪位置的高度
			d2B = waveWidthB / waveCountB,
			dB = d2B / 2,
			hdB = dB / 2,
			cB = document.getElementById("myCanvas2");
			cB.width = 675
			ctxB = cB.getContext("2d");
			function tickB() {
				offsetB -= 5;
				if (-1 * offsetB === d2B) offsetB = 0;
				ctxB.clearRect(0, 0, cB.width, cB.height);
				ctxB.fillStyle = 'rgba(255, 255, 255, 0.8)';  
				ctxB.beginPath();
				var offsetYB = startYB - progressB;  
				ctxB.moveTo(startXB - offsetB, offsetYB);
				for (var i = 0; i < waveCountB; i++) {
					var dxB = i * d2B;
					var offsetXB = dxB + startXB - offsetB;
					ctxB.quadraticCurveTo(offsetXB + hdB, offsetYB + waveHeightB, offsetXB + dB, offsetYB);
					ctxB.quadraticCurveTo(offsetXB + hdB + dB, offsetYB - waveHeightB, offsetXB + d2B, offsetYB);
				}
				ctxB.lineTo(startXB + waveWidthB, 3000);
				ctxB.lineTo(startXB, 3000);
				ctxB.fill();
				// setTimeout(tickB,5000 / 60); //速度
				requestAnimationFrame(tickB);
			}
			tickB();
		}
		 /* 第三条 */
		function wave3(){
			var waveWidthC = 3300,
			offsetC = 0,
			waveHeightC = 18,  //波浪高度
			waveCountC = 4,  //波浪个数
			startXC = -1000,
			startYC = 200,   //canvas 高度
			progressC = 100,  //波浪位置的高度
			d2C = waveWidthC / waveCountC,
			dC = d2C / 2,
			hdC = dC / 2,
			cC = document.getElementById("myCanvas3");
			cC.width = 675
			ctxC = cC.getContext("2d");
			function tickC() {
				offsetC -= 5;
				if (-1 * offsetC === d2C) offsetC = 0;
				ctxC.clearRect(0, 0, cC.width, cC.height);
				ctxC.fillStyle = 'rgba(255, 255, 255, 0.9)';  
				ctxC.beginPath();
				var offsetYC = startYC - progressC;  
				ctxC.moveTo(startXC - offsetC, offsetYC);
				for (var i = 0; i < waveCountC; i++) {
					var dxC = i * d2C;
					var offsetXC = dxC + startXC - offsetC;
					ctxC.quadraticCurveTo(offsetXC + hdC, offsetYC + waveHeightC, offsetXC + dC, offsetYC);
					ctxC.quadraticCurveTo(offsetXC + hdC + dC, offsetYC - waveHeightC, offsetXC + d2C, offsetYC);
				}
				ctxC.lineTo(startXC + waveWidthC, 3000);
				ctxC.lineTo(startXC, 3000);
				ctxC.fill();
				// setTimeout(tickC,5000 / 60); //速度
				requestAnimationFrame(tickC);
			}
			tickC();
		}
		</script>
        	<ul>
            <!--自定义静态链接地址-->
            <!--{block/219}-->
            	
                <div class="clear"></div>
            </ul>
        </div>
        <!--今日头条-->
        <div class="nex_index_commonbox nex_index_commonbox_nullpd">
        	<i></i>
            <div class="nex_topindexs">
            	<span>今日<em>头条</em><b>Today Tropicals</b></span>
                <a href="#">往期回顾></a>
                <div class="clear"></div>
            </div>
            <div class="nex_todays">
            	<ul>
                	<!--今日头条模块-->
                    
                	
                </ul>
            </div>
            <div class="nex_todaylist">
            	<ul>
                	<!--今日头条图片模块-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--孕育百科-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>孕育<em>百科</em><b>Aknowledge</b></span>
                <a href="#">更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_bkbox">
            	<div class="nex_bk_tops">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--孕育百科模块-->
                                    
                                	
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">备孕怀孕百科知识</a></div>
                        </li>
                        <li>
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--孕育百科模块-->
                                    
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">分娩百科知识</a></div>
                        </li>
                        <li>
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--孕育百科模块-->
                                    
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">新生儿百科知识</a></div>
                        </li>
                        <li>
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--孕育百科模块-->
                                    
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">0-1岁百科知识</a></div>
                        </li>
                        <li>
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--孕育百科模块-->
                                    
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">1-3岁百科知识</a></div>
                        </li>
                    </ul>
                </div>
                <div class="nex_bk_btms">
                	<ul>
                    	<li class="cur">备孕怀孕</li>
                        <li>分娩期</li>
                        <li>新生儿</li>
                        <li>0-1岁</li>
                        <li>1-3岁</li>
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <script type="text/javascript">
				jQuery(".nex_bk_btms ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("cur").siblings().removeClass("cur");
						jQuery(".nex_bk_tops ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
           	<div class="nex_bk_froms">
            	<ul>
                	<!--孕育百科焦点图文模块-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_hot_bklists">
            	<div class="nex_hbkl"></div>
                <div class="nex_hbkr">
                	<ul>
                    	<!--百科关注列表模块-->
                        
                    	
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <!--ads-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>手机版<em>广告位1</em><b>Advertisment</b></span>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads">
            	<!--广告位模块-->
                
            </div>
        </div>
        <!--推荐话题-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>推荐<em>话题</em><b>Recommends</b></span>
                <a href="#">更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_ht_froms">
            	<ul>
                	<!--推荐话题模块-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_ht_lists">
            	<ul>
                	<!--推荐话题列表模块-->
                    
                	
                </ul>
            </div>
            <div class="nex_ht_tuijian">
            	<div class="nex_ht_tuijianl">推荐阅读</div>
                <div class="nex_ht_tuijianr">
                	<ul>
                    	<!--推荐阅读帖子模块-->
                        
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <!--ads-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>手机版<em>广告位2</em><b>Advertisment</b></span>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads">
            <!--广告位2模块-->
            
            
            </div>
        </div>
        <!--育儿问答-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>育儿<em>问答</em><b>Questions</b></span>
                <a href="#">更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_qnas">
            	<!--育儿问答帖子模块-->
                
            	
            </div>
            <script type="text/javascript">
						jQuery(".nex_qnas").slide({ mainCell:"ul", effect:"topLoop", vis:5,autoPlay:true, delayTime:1200,interTime:3500,easing:"easeInCubic"});
					</script>
        </div>
        <!--热门帖子-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>论坛<em>热帖</em><b>Forum hot threads</b></span>
                <a href="#">更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_hotthreads">
            	<ul>
                	<!--论坛热门帖子模块-->
                    
                	
                </ul>
            </div>
        </div>
        <!--ads-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>手机版<em>广告位3</em><b>Advertisment</b></span>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads">
            	<!--广告位3模块-->
                
            </div>
        </div>
        <!--辣妈晒照-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>辣妈<em>晒照</em><b>Photography</b></span>
                <a href="#">更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_mompiv">
            	<ul>
                	<!--辣妈晒照图文帖子模块-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--亲子活动-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>亲子<em>活动</em><b>Activities</b></span>
                <a href="#">更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_hd_list">
            	<ul>
                	<!--亲子活动模块-->
                    
                	
                </ul>
            </div>
        </div>
        <!--ads-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>手机版<em>广告位4</em><b>Advertisment</b></span>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads">
            	<!--广告位4模块-->
                
            </div>
        </div>
        <!--友情链接-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>友情<em>链接</em><b>Links</b></span>
                <a href="#">更多></a>
                <div class="clear"></div>
            </div>
            <div class="nex_linksd">
            	<ul>
                	<!--友情链接模块-->
                    
                	
                    
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
	</div>	
</div>

<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}-->
