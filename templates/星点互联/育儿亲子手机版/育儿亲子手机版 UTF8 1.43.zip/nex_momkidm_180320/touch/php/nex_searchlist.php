<?php

if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}


$nex_catids = DB::result(DB::query("SELECT catname FROM ".DB::table('portal_category')." WHERE catid = '$nex_search_article[catid]'"));

?>