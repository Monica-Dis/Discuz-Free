<?php echo 'Copyright@DISM.TAOBAO.COM';exit;?>
<style type="text/css">
.nex_footer{padding:10px 0 75px 0;background:#111; }
</style>
<div class="nex_bottomnav">
	<div class="nex_bottominter">
    	<ul>
        	<li>
            	<a href="portal.php?mod=index&mobile=2">
                	<i class="nex_iconbtm1"></i>
                    <p>首页</p>
                </a>
            </li>
            <li>
            	<a href="plugin.php?id=nex_momcj_180327&pid=qa&mobile=2">
                	<i class="nex_iconbtm2"></i>
                    <p>问答</p>
                </a>
            </li>
            <li class="nex_btmnav_sp">
            	<a href="forum.php?mod=misc&action=nav">
                	<i class="nex_iconbtm3"></i>
                    <p>发布</p>
                </a>
            </li>
            <li>
            	<a href="#">
                	<i class="nex_iconbtm4"></i>
                    <p>百科</p>
                </a>
            </li>
            <li>
            	<a href="home.php?mod=space&uid={$_G['uid']}&do=profile&mycenter=1&mobile=2">
                	<i class="nex_iconbtm5"></i>
                    <p>我的</p>
                </a>
            </li>
            <div class="clear"></div>
        </ul>
    </div>
</div>