<?php echo 'Copyright@DISM.TAOBAO.COM dism.taobao.com';exit;?>
<!--{template common/header}-->
<style type="text/css">
.st-pusher,.nex_bg_cl{ background:#fff!important;}
</style>
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        <div class="nex_main_search">
            <form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
                <input type="hidden" name="formhash" value="{FORMHASH}" />
                <!--{subtemplate search/pubsearch}-->
                
                <!--{eval $policymsgs = $p = '';}-->
                <!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
                <!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
                <!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
                <!--{/loop}-->
                <!--{if $policymsgs}--><p>{lang search_credit_msg}</p><!--{/if}-->
            </form>
            <!--{if $_G['setting']['srchhotkeywords']}-->
            <div class="nex_hot_searchtags">
                <div class="nex_Search_title">热搜词</div>
                <div id="scbar_hot">
                    <!--{loop $_G['setting']['srchhotkeywords'] $val}-->
                        <!--{if $val=trim($val)}-->
                            <!--{eval $valenc=rawurlencode($val);}-->
                            <!--{block srchhotkeywords[]}-->
                                <!--{if !empty($searchparams[url])}-->
                                    <a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}" class="xi2" sc="1">$val</a>
                                <!--{else}-->
                                    <a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch" class="xi2" sc="1">$val</a>
                                <!--{/if}-->
                            <!--{/block}-->
                        <!--{/if}-->
                    <!--{/loop}-->
                    <!--{echo implode('', $srchhotkeywords);}-->
                </div>
            </div>
            <!--{/if}--> 
            <!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
                <!--{subtemplate search/thread_list}-->
            <!--{/if}-->
        </div>

	</div>
</div>
