<?php echo 'Copyright@DISM.TAOBAO.COM';exit;?>
<nav class="st-menu st-effect-7" id="menu-7">
            <div class="nex_nav_dlbox">
            <!--{if $_G['uid']}-->
                <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1">
                    <div class="nex_nav_tx">
                    	<!--{avatar($_G[uid],big)}-->
                        <!--{if $_G[member][newpm]}-->
                        <em><b>{$_G[member][newpm]}</b></em>
                        <!--{elseif $_G[member][newprompt]}-->
                        <em><b>{$_G[member][newprompt]}</b></em>
                        <!--{/if}-->
                    </div>
                    <div class="nex_nav_name">$_G[group][grouptitle]��{$_G[member][username]}</div>
                    <div class="nex_nav_infos">
                        <!--{eval include 'template/nex_momkidm_180320/touch/php/nex_users.php'}-->
                        <div class="nexmemberinfos">
                            <ul>
                                <li class="nexmemberinfosones">
                                    <p>
                                        <!--{if $nex_gender == '1'}-->
                                        <em>��</em>
                                        <!--{/if}-->
                                        <!--{if $nex_gender == '2'}-->
                                        <em>Ů</em>
                                        <!--{/if}-->
                                        <!--{if $nex_gender == '0'}-->
                                        <em>����</em>
                                        <!--{/if}-->
                                    </p>
                                    <div class="nexmemberinfoterms">�Ա�</div>
                                </li>
                                <li class="nexmemberinfosthrees">
                                    <!--{if $nex_occu == ''}-->
                                    <p>δ��д</p>
                                    <!--{else}-->
                                    <p>{$nex_occu}</p>
                                    <!--{/if}-->
                                    <div class="nexmemberinfoterms">ְҵ</div>
                                </li>
                                <li class="nexmemberinfostwos">
                                    <!--{if $nex_kidstatus == ''}-->
                                    <p>δ��д</p>
                                    <!--{else}-->
                                    <p>{$nex_kidstatus}</p>
                                    <!--{/if}-->
                                    <div class="nexmemberinfoterms">״̬</div>
                                </li>
                                
                                <div class="clear"></div>
                            </ul>
                        </div>
                        
                    </div>
                    <div class="clear"></div>
                </a>
            <!--{elseif !$_G[connectguest]}-->
            <div class="nex_nav_user"><img src="$_G['style'][styleimgdir]/headertop/default_avator.png" /></div>
            <h2>�װ����οͣ�����</h2>
            <div class="nex_nav_userbns">
                <a class="nex_nav_dl" href="member.php?mod=logging&action=login">������¼</a>
                <a class="nex_nav_zc" href="member.php?mod={$_G[setting][regname]}">ע���û�</a>
                <div class="clear"></div>
            </div>
            <!--{/if}-->
            </div>
            <div class="nex_navbox">
                <ul>
                    <li><a class="icon icon-one" href="portal.php?mod=index&mobile=2">�ֻ��Ż�</a></li>
                    <li><a class="icon icon-two" href="forum.php?forumlist=1&mobile=2">��̳���</a></li>
                    <li><a class="icon icon-two" href="forum.php?mod=guide&view=newthread&mobile=2">��������</a></li>
                    <li><a class="icon icon-three" href="#">ĸӤ��Ʒ</a></li>
                    <li><a class="icon icon-three" href="#">�����̼�</a></li>
                    <li><a class="icon icon-three" href="qna.php?mod=index&mobile=2">�����ʴ�</a></li>
                    <li><a class="icon icon-four" href="hd.php?mod=index&mobile=2">���ӻ</a></li>
                    <li><a class="icon icon-four" href="portal.php?mod=list&catid=4">�����ٿ�</a></li>
                    <li><a class="icon icon-five" href="forum.php?mod=forumdisplay&fid=60&mobile=2">ͼ��</a></li>
                    <li><a class="icon icon-seven" href="about.php?mod=index&mobile=2">��������</a></li>
                </ul>
            </div>
        </nav>
                
                
<div class="nex_navbar">
    <div class="nex_navleft">
        <div id="st-trigger-effects" class="nex_navtop_column"><button class="nex_subnavs" data-effect="st-effect-7"></button></div>
    </div>
    <div class="nextoplogo"><img src="$_G['style'][styleimgdir]/index/logo.png" /></div>
    <div class="nex_navright">
        <a href="search.php?mod=forum&mobile=2"></a>
    </div>
    
</div>
<script src="$_G['style'][styleimgdir]/js/define.js"></script>
<script src="$_G['style'][styleimgdir]/js/effect.js"></script>

