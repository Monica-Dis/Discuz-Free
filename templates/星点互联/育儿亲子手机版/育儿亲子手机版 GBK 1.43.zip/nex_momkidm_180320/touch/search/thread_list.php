<?php echo 'Copyright@DISM.TAOBAO.COM dism.taobao.com';exit;?>
<div class="nex_searchlists">
	<h2 class="thread_tit"><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	<!--{if empty($threadlist)}-->
	<ul>
    	<li class="noDate">{lang search_nomatch}</li>
    </ul>
	<!--{else}-->
    <ul>
        <!--{loop $threadlist $nexsearch_thread}-->
        <li>
            <a href="forum.php?mod=viewthread&tid=$nexsearch_thread[realtid]&highlight=$index[keywords]" $nexsearch_thread[highlight]>
            	<div class="nexsearch_pic">
                	<!--{eval include 'template/nex_momkidm_180320/touch/php/nex_searchthread.php'}-->
                    <!--{if $nex_attachs == '0'}-->
                    <img src="$_G['style'][styleimgdir]/search/no_pic.jpg" />
                    <!--{else}-->
                    <!--{eval include 'template/nex_momkidm_180320/touch/php/nex_searchthread.php'}-->
                    <!--{loop $nex_search_listspic $nex_search_threadsinpivs}-->
                    <div class="nexsearch_pic_iner" style=" background:url(<!--{if $nex_search_threadsinpivs['remote']}-->{$_G['setting']['ftp']['attachurl']}forum/{$nex_search_threadsinpivs[attachment]}
					<!--{else}-->         			
					{$_G['setting']['attachurl']}forum/{$nex_search_threadsinpivs[attachment]}
					<!--{/if}-->) center no-repeat; background-size:cover;"></div>
                    <!--{/loop}-->
                    <!--{/if}-->
                </div>
                <div class="nexsearch_info">
                	<h5>{$nexsearch_thread[subject]}</h5>
                    <div class="nexsearch_info_btm">
                    	<i>{$nex_search_column}</i><em>{$nexsearch_thread[dateline]}</em>
                    </div>
                </div>
                <div class="clear"></div>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
	<!--{/if}-->
	$multipage
</div>

