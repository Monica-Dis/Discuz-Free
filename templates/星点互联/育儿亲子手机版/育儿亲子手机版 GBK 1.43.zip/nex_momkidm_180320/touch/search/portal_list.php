<?php echo 'Copyright@DISM.TAOBAO.COM dism.taobao.com';exit;?>
<div class="nex_searchlists">
	<h2 class="thread_tit"><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	<!--{if empty($articlelist)}-->
	<ul>
    	<li class="noDate">{lang search_nomatch}</li>
    </ul>
	<!--{else}-->
    <div class="nex_showarticles">
			<ul>
				<!--{loop $articlelist $nex_search_article}-->
                <!--{eval include 'template/nex_momkidm_180320/touch/php/nex_searchlist.php'}-->
				<li>
                	<a href="{echo fetch_article_url($nex_search_article);}">
                    	<div class="nex_showarticles_top">
                        	<div class="nex_showarticles_tl">
                            	<img src="uc_server/avatar.php?uid=$nex_search_article[uid]&size=large">
                                <span>$nex_search_article[username]</span>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_showarticles_tr">$nex_search_article[dateline]</div>
                            <div class="clear"></div>
                        </div>
                        
                        <!--{if $nex_search_article[pic]}-->
                        <div class="nex_show_article_pics" style="background:url($nex_search_article[pic]) center no-repeat; background-size:cover;"></div>
                        <!--{else}-->
                        <div class="nex_show_article_pics" style="background:url($_G['style'][styleimgdir]/search/no_pic.jpg) center no-repeat; background-size:cover;"></div>
                        <!--{/if}-->
                        <div class="nex_search_articlebtm">
                            <h5>$nex_search_article[title]</h5>
                            <div class="nex_search_armid">
                            	<div class="nex_search_armidl">
                                	<span class="nex_search_armidl_view">$nex_search_article[viewnum]</span>
                                    <span class="nex_search_armidl_reply">$nex_search_article[commentnum]</span>
                                    <div class="clear"></div>
                                </div>
                                <div class="nex_search_armidr">{$nex_catids}</div>
                                <div class="clear"></div>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </a>
				</li>
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
    <!--{/if}-->
    $multipage
</div>
