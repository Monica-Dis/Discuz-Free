<?php echo 'Copyright@DISM.TAOBAO.COM dism.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template common/bottomnav}-->
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        
        <!--�����˵�����-->
        <div class="nex_index_rollmenus">
        	<ul>
            	<li><a href="#">�Ƽ��Ķ�</a></li>
                <li><a href="#">���豸��</a></li>
                <li><a href="#">ʱ������</a></li>
                <li><a href="#">����ɹ��</a></li>
                <li><a href="#">��л���</a></li>
                <li><a href="#">��ʳ����</a></li>
                <li><a href="#"≯��˵��</a></li>
                <li><a href="#">��������</a></li>
                <li><a href="#">��������</a></li>
                <li><a href="#">���´���</a></li>
                <div class="clear"></div>
            </ul>
        </div>
        <!--slider-->
        <div id="nex_index_focus" class="nex_index_focus">
        	
            <div class="hd">
                <ul></ul>
            </div>
            <div class="bd">
            	<!--�Ż��õ���Ѷ-->
                
                
            </div>
        </div>
        
        <!--���-->
        
        <div class="nex_index_favs">
        	<div class="nex_waveBox">
            <canvas id="myCanvas1" height="200"></canvas>
            <canvas id="myCanvas2" height="200"></canvas>
            <canvas id="myCanvas3" height="200"></canvas>
        </div>
        <script type="text/javascript">
            TouchSlide({ 
                slideCell:"#nex_index_focus",
                titCell:".hd ul", //�����Զ���ҳ autoPage:true ����ʱ���� titCell Ϊ����Ԫ�ذ�����
                mainCell:".bd ul", 
                effect:"left", 
                autoPlay:true,//�Զ�����
                autoPage:true, //�Զ���ҳ
                switchLoad:"_src" //�л����أ���ʵͼƬ·��Ϊ"_src" 
            });
        </script>
        
        <script>
		(function () {
			wave2();wave3();
		})();
		
			params = {
				ctx :  document.getElementById("myCanvas1"),
				waveHeight:15,//���˸߶�
				waveCount:6,//���˸���
				progress:100,//����λ�õĸ߶�
				// fillStyle:'#95cef7', //��ɫ
				fillStyle:'rgba(255, 255, 255, 0.6)', //��ɫ
			}
			DrawBall(params)
		function DrawBall (Params){
			var waveWidth = 3300, offset = 0, startX = -1000, startY = 200,   //canvas �߶�
			d2 = waveWidth / Params.waveCount,d = d2 / 2, hd = d / 2;
			Params.ctx.width = 675
			ctx = Params.ctx.getContext("2d");
			function tick() {
				offset -= 5;
				if (-1 * offset === d2) offset = 0;
				ctx.clearRect(0, 0, Params.ctx.width, Params.ctx.height);
				ctx.fillStyle = Params.fillStyle;  
				ctx.beginPath();
				var offsetY = startY - Params.progress;
				ctx.moveTo(startX - offset, offsetY);
				for (var i = 0; i < Params.waveCount; i++) {
					var dx = i * d2;
					var offsetX = dx + startX - offset;
					ctx.quadraticCurveTo(offsetX + hd, offsetY + Params.waveHeight, offsetX + d, offsetY);
					ctx.quadraticCurveTo(offsetX + hd + d, offsetY - Params.waveHeight, offsetX + d2, offsetY);
				}
				ctx.lineTo(startX + waveWidth, 3000);
				ctx.lineTo(startX, 3000);
				ctx.fill();
				requestAnimationFrame(tick);
			}
			tick();
		}
		 /* �ڶ��� */
		function wave2(){
			var waveWidthB = 3300,
			offsetB = 0,
			waveHeightB = 15,  //���˸߶�
			waveCountB = 5,  //���˸���
			startXB = -1000,
			startYB = 200,   //canvas �߶�
			progressB = 90,  //����λ�õĸ߶�
			d2B = waveWidthB / waveCountB,
			dB = d2B / 2,
			hdB = dB / 2,
			cB = document.getElementById("myCanvas2");
			cB.width = 675
			ctxB = cB.getContext("2d");
			function tickB() {
				offsetB -= 5;
				if (-1 * offsetB === d2B) offsetB = 0;
				ctxB.clearRect(0, 0, cB.width, cB.height);
				ctxB.fillStyle = 'rgba(255, 255, 255, 0.8)';  
				ctxB.beginPath();
				var offsetYB = startYB - progressB;  
				ctxB.moveTo(startXB - offsetB, offsetYB);
				for (var i = 0; i < waveCountB; i++) {
					var dxB = i * d2B;
					var offsetXB = dxB + startXB - offsetB;
					ctxB.quadraticCurveTo(offsetXB + hdB, offsetYB + waveHeightB, offsetXB + dB, offsetYB);
					ctxB.quadraticCurveTo(offsetXB + hdB + dB, offsetYB - waveHeightB, offsetXB + d2B, offsetYB);
				}
				ctxB.lineTo(startXB + waveWidthB, 3000);
				ctxB.lineTo(startXB, 3000);
				ctxB.fill();
				// setTimeout(tickB,5000 / 60); //�ٶ�
				requestAnimationFrame(tickB);
			}
			tickB();
		}
		 /* ������ */
		function wave3(){
			var waveWidthC = 3300,
			offsetC = 0,
			waveHeightC = 18,  //���˸߶�
			waveCountC = 4,  //���˸���
			startXC = -1000,
			startYC = 200,   //canvas �߶�
			progressC = 100,  //����λ�õĸ߶�
			d2C = waveWidthC / waveCountC,
			dC = d2C / 2,
			hdC = dC / 2,
			cC = document.getElementById("myCanvas3");
			cC.width = 675
			ctxC = cC.getContext("2d");
			function tickC() {
				offsetC -= 5;
				if (-1 * offsetC === d2C) offsetC = 0;
				ctxC.clearRect(0, 0, cC.width, cC.height);
				ctxC.fillStyle = 'rgba(255, 255, 255, 0.9)';  
				ctxC.beginPath();
				var offsetYC = startYC - progressC;  
				ctxC.moveTo(startXC - offsetC, offsetYC);
				for (var i = 0; i < waveCountC; i++) {
					var dxC = i * d2C;
					var offsetXC = dxC + startXC - offsetC;
					ctxC.quadraticCurveTo(offsetXC + hdC, offsetYC + waveHeightC, offsetXC + dC, offsetYC);
					ctxC.quadraticCurveTo(offsetXC + hdC + dC, offsetYC - waveHeightC, offsetXC + d2C, offsetYC);
				}
				ctxC.lineTo(startXC + waveWidthC, 3000);
				ctxC.lineTo(startXC, 3000);
				ctxC.fill();
				// setTimeout(tickC,5000 / 60); //�ٶ�
				requestAnimationFrame(tickC);
			}
			tickC();
		}
		</script>
        	<ul>
            <!--�Զ��徲̬���ӵ�ַ-->
            <!--{block/219}-->
            	
                <div class="clear"></div>
            </ul>
        </div>
        <!--����ͷ��-->
        <div class="nex_index_commonbox nex_index_commonbox_nullpd">
        	<i></i>
            <div class="nex_topindexs">
            	<span>����<em>ͷ��</em><b>Today Tropicals</b></span>
                <a href="#">���ڻع�></a>
                <div class="clear"></div>
            </div>
            <div class="nex_todays">
            	<ul>
                	<!--����ͷ��ģ��-->
                    
                	
                </ul>
            </div>
            <div class="nex_todaylist">
            	<ul>
                	<!--����ͷ��ͼƬģ��-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--�����ٿ�-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>����<em>�ٿ�</em><b>Aknowledge</b></span>
                <a href="#">����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_bkbox">
            	<div class="nex_bk_tops">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--�����ٿ�ģ��-->
                                    
                                	
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">���л��аٿ�֪ʶ</a></div>
                        </li>
                        <li>
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--�����ٿ�ģ��-->
                                    
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">����ٿ�֪ʶ</a></div>
                        </li>
                        <li>
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--�����ٿ�ģ��-->
                                    
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">�������ٿ�֪ʶ</a></div>
                        </li>
                        <li>
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--�����ٿ�ģ��-->
                                    
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">0-1��ٿ�֪ʶ</a></div>
                        </li>
                        <li>
                        	<div class="nex_bkbods">
                            	<dl>
                                	<!--�����ٿ�ģ��-->
                                    
                                </dl>
                            </div>
                            <div class="nex_bk_links"><a href="#">1-3��ٿ�֪ʶ</a></div>
                        </li>
                    </ul>
                </div>
                <div class="nex_bk_btms">
                	<ul>
                    	<li class="cur">���л���</li>
                        <li>������</li>
                        <li>������</li>
                        <li>0-1��</li>
                        <li>1-3��</li>
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <script type="text/javascript">
				jQuery(".nex_bk_btms ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("cur").siblings().removeClass("cur");
						jQuery(".nex_bk_tops ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
           	<div class="nex_bk_froms">
            	<ul>
                	<!--�����ٿƽ���ͼ��ģ��-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_hot_bklists">
            	<div class="nex_hbkl"></div>
                <div class="nex_hbkr">
                	<ul>
                    	<!--�ٿƹ�ע�б�ģ��-->
                        
                    	
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <!--ads-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>�ֻ���<em>���λ1</em><b>Advertisment</b></span>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads">
            	<!--���λģ��-->
                
            </div>
        </div>
        <!--�Ƽ�����-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>�Ƽ�<em>����</em><b>Recommends</b></span>
                <a href="#">����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_ht_froms">
            	<ul>
                	<!--�Ƽ�����ģ��-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_ht_lists">
            	<ul>
                	<!--�Ƽ������б�ģ��-->
                    
                	
                </ul>
            </div>
            <div class="nex_ht_tuijian">
            	<div class="nex_ht_tuijianl">�Ƽ��Ķ�</div>
                <div class="nex_ht_tuijianr">
                	<ul>
                    	<!--�Ƽ��Ķ�����ģ��-->
                        
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <!--ads-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>�ֻ���<em>���λ2</em><b>Advertisment</b></span>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads">
            <!--���λ2ģ��-->
            
            
            </div>
        </div>
        <!--�����ʴ�-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>����<em>�ʴ�</em><b>Questions</b></span>
                <a href="#">����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_qnas">
            	<!--�����ʴ�����ģ��-->
                
            	
            </div>
            <script type="text/javascript">
						jQuery(".nex_qnas").slide({ mainCell:"ul", effect:"topLoop", vis:5,autoPlay:true, delayTime:1200,interTime:3500,easing:"easeInCubic"});
					</script>
        </div>
        <!--��������-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>��̳<em>����</em><b>Forum hot threads</b></span>
                <a href="#">����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_hotthreads">
            	<ul>
                	<!--��̳��������ģ��-->
                    
                	
                </ul>
            </div>
        </div>
        <!--ads-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>�ֻ���<em>���λ3</em><b>Advertisment</b></span>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads">
            	<!--���λ3ģ��-->
                
            </div>
        </div>
        <!--����ɹ��-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>����<em>ɹ��</em><b>Photography</b></span>
                <a href="#">����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_mompiv">
            	<ul>
                	<!--����ɹ��ͼ������ģ��-->
                    
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--���ӻ-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>����<em>�</em><b>Activities</b></span>
                <a href="#">����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_hd_list">
            	<ul>
                	<!--���ӻģ��-->
                    
                	
                </ul>
            </div>
        </div>
        <!--ads-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>�ֻ���<em>���λ4</em><b>Advertisment</b></span>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads">
            	<!--���λ4ģ��-->
                
            </div>
        </div>
        <!--��������-->
        <div class="nex_index_commonbox">
        	<i></i>
            <div class="nex_topindexs">
            	<span>����<em>����</em><b>Links</b></span>
                <a href="#">����></a>
                <div class="clear"></div>
            </div>
            <div class="nex_linksd">
            	<ul>
                	<!--��������ģ��-->
                    
                	
                    
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
	</div>	
</div>

<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}-->

