<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$nex_decos_log= DB::table("nex_decos_log");
$sql = <<<EOF
CREATE TABLE `$nex_decos_log` (
  `id` int(10) NOT NULL auto_increment,
  `type` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `area` varchar(20) NOT NULL,
  `mansionname` varchar(50) NOT NULL default '1',
  `decostyles` varchar(20) NOT NULL,
  `huxing` varchar(15) NOT NULL,
  `zxyusuan` varchar(20) NOT NULL,
  `mianji` varchar(10) NOT NULL,
  `state` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401.xml');
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/nex_decos_180401/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/nex_decos_180401/upgrade.php');
?>