<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401.xml');
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/nex_decos_180401/discuz_plugin_nex_decos_180401_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/nex_decos_180401/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/nex_decos_180401/upgrade.php');
?>