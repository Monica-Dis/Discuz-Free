<?php echo 'Copyright@DisM.Taobao.COM-http://t.cn/Aiux1Qh0';exit;?>
<!--{block diynav}-->
		<a id="diy-tg" href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" title="{lang open_diy}" >DIY</a>
<!--{/block}-->
