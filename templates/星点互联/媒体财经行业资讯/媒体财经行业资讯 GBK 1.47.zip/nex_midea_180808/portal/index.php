<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="wp">
    <!--main-->
    <div class="nex_main_bd">
    	<div class="w1180">
            <div class="nex_main_left">
            	<!--left-top-->
                <div class="nex_onestep_part">
                    <div class="nex_onestep_partL">
                    	<div class="nex_onestep_slider">
                        	<!--[diy=nex_onestep_slider]--><div id="nex_onestep_slider" class="area"></div><!--[/diy]-->
                        	
                            <a class="prev" href="javascript:void(0)"></a>
                            <a class="next" href="javascript:void(0)"></a>
                            <ul class="hd">
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                                <li></li>
                            </ul>
                        </div>
                        <script type="text/javascript">
                            jQuery(".nex_onestep_slider").hover(function(){ jQuery(this).find(".prev,.next").stop(true,true) },function(){ jQuery(this).find(".prev,.next") });
                            jQuery(".nex_onestep_slider").slide({ mainCell:".pic",effect:"fold", autoPlay:true, delayTime:800, trigger:"click"});
                        </script>
                        <div class="nex_onestep_news">
                        	<ul>
                            	<!--[diy=nex_onestep_news]--><div id="nex_onestep_news" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </div>
                    <div class="nex_onestep_partR">
                    	<div class="nex_today_title"><span>����Ҫ��</span><em>TODAY NEWS</em><div class="clear"></div></div>
                        <div class="nex_todaynews">
                        	<ul>
                            	<!--[diy=nex_todaynews]--><div id="nex_todaynews" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
                <!--side_ads-->
                <div class="nex_left_ads"><!--[diy=nex_left_ads]--><div id="nex_left_ads" class="area"></div><!--[/diy]--></div>
                <!--Blockchain-->
                <div class="nex_Blockchainl">
                	<div class="nex_bcl_top">
                    	<i></i>
                        <!--[diy=nex_bcl_top]--><div id="nex_bcl_top" class="area"></div><!--[/diy]-->
                        
                    </div>
                    
                    <div class="nex_bcl_btm">
                    	<!--[diy=nex_bcl_btm]--><div id="nex_bcl_btm" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <script type="text/javascript">
						jQuery(".nex_bcl_btm").slide({ mainCell:"ul", effect:"topLoop", vis:7,autoPlay:true, delayTime:1200,interTime:3500,easing:"easeInCubic"});
					</script>
                    <div class="nex_more_bllinks"><!--[diy=nex_more_bllinks]--><div id="nex_more_bllinks" class="area"></div><!--[/diy]--></div>
                </div>
                <div class="nex_Blockchain">
                	<div class="nex_common_title">
                    	<span>��������Ѷ</span><em>BLOCKCHAIN INFOS</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">����></a>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_bcboxc">
                    	<!--[diy=nex_bcboxc]--><div id="nex_bcboxc" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </div>
                    <div class="nex_sortLIne">
                    	<div class="nex_sortLInes">
                            <ul>
                            	<!--[diy=nex_sortLInes]--><div id="nex_sortLInes" class="area"></div><!--[/diy]-->
                                
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="clear"></div>
                <!--MARKETING INFOMATION-->
                <div class="nex_rolllist">
                	<div class="nex_common_title">
                    	<span>������Ѷ</span><em>MARKETING INFOMATION</em>
                    </div>
                    <div class="nex_rollingboxs">
                    	<!--[diy=nex_rollingboxs]--><div id="nex_rollingboxs" class="area"></div><!--[/diy]-->
                    	
                        <a class="prev" href="javascript:void(0)"></a>
                		<a class="next" href="javascript:void(0)"></a>
                    </div>
                	<script type="text/javascript">
					jQuery(".nex_rollingboxs").slide({ mainCell:".nexproul", effect:"leftLoop", vis:3, scroll:1, autoPlay:true,  autoPage:true, switchLoad:"_src" });
					</script>
                </div>
                <!--side_ads-->
                <div class="nex_left_ads"><!--[diy=nex_left_ads1]--><div id="nex_left_ads1" class="area"></div><!--[/diy]--></div>
                <!--newslist-->
                <div class="nex_wholelist">
                	<div class="nex_common_title">
                    	<span>ȫ����ѡ����</span><em>ALL SELECTED NEWS</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">����></a>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_infotexh_box">
                    	<ul>
                        	<!--[diy=nex_infotexh_box]--><div id="nex_infotexh_box" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                    <div class="jquery_pagnation"></div>
					<script type="text/javascript">
                        (function(dfsj_jq){
                            var dfsj_items = dfsj_jq('.nex_infotexh_box li');
                            var dfsj_items2 = 17;//ÿҳ��ʾ������
                            var total = dfsj_items.size();
                            total>0 && dfsj_jq('.jquery_pagnation').pagination({pagetotal:total,target:dfsj_items,perpage:dfsj_items2});
                            })(jQuery);
                    </script>
                </div>
            </div>
            
            <div class="nex_main_right">
            	<!--focus_on-->
            	<div class="nex_Info_Right_focus">
                	<!--[diy=nex_Info_Right_focus]--><div id="nex_Info_Right_focus" class="area"></div><!--[/diy]-->
                    
                </div>
                <!--side_ads-->
                <div class="nex_side_ads"><!--[diy=nex_side_ads1]--><div id="nex_side_ads1" class="area"></div><!--[/diy]--></div>
                <!--side_current_intel-->
                <div class="nex_side_box">
                	<div class="nex_side_top_txt">
                        <span>7*24���鱨</span>
                    </div>
                	<div class="nex_newintel_box">
                    	<ul>
                        	<!--[diy=nex_newintel_box]--><div id="nex_newintel_box" class="area"></div><!--[/diy]-->
                        </ul>
                    </div>
                    
                </div>
                <!--side_ads-->
                <div class="nex_side_ads"><!--[diy=nex_side_ads2]--><div id="nex_side_ads2" class="area"></div><!--[/diy]--></div>
                <!--side_hot_articles-->
                <div class="nex_side_box">
                	<div class="nex_side_top_txt">
                        <span>�ȵ���Ѷ</span>
                    </div>
                	<div class="nex_mainhot_news">
                    	<ul>
                        	<!--[diy=nex_mainhot_news]--><div id="nex_mainhot_news" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                </div>
                
                <!--side_articles_ranklist-->
                <div class="nex_side_box">
                	<div class="nex_side_top_txt">
                        <span>�Ķ����а�</span>
                    </div>
                    <div class="nex_readlist_tab">
                    	<ul>
                        	<li class="cur">�հ�</li>
                            <li>�ܰ�</li>
                            <li>�°�</li>
                            <div class="clear"></div>
                        </ul>
                    </div>	
                    <div class="nex_readlist">
                    	<ul>
                        	<li style="display:block">
                            	<div class="nex_readinglists">
                                	<dl>
                                    	<!--[diy=nex_readinglists]--><div id="nex_readinglists" class="area"></div><!--[/diy]-->
                                    	
                                    </dl>
                                </div>
                            </li>
                            <li>
                            	<div class="nex_readinglists">
                                	<dl>
                                    	<!--[diy=nex_readinglists1]--><div id="nex_readinglists1" class="area"></div><!--[/diy]-->
                                    </dl>
                                </div>
                            </li>
                            <li>
                            	<div class="nex_readinglists">
                                	<dl>
                                    	<!--[diy=nex_readinglists3]--><div id="nex_readinglists3" class="area"></div><!--[/diy]-->
                                    </dl>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <script type="text/javascript">
						jQuery(".nex_readlist_tab ul li").each(function(s){
							jQuery(this).click(function(){
								jQuery(this).addClass("cur").siblings().removeClass("cur");
								jQuery(".nex_readlist ul li").eq(s).show().siblings().hide();
								})
							})
					</script>
                </div>
                <!--side_ads-->
                <div class="nex_side_ads"><!--[diy=nex_side_ads3]--><div id="nex_side_ads3" class="area"></div><!--[/diy]--></div>
                <!--side_famous_articles_list-->
                <div class="nex_side_box">
                	<div class="nex_side_top_txt">
                        <span>����ר��</span>
                    </div>
                	<div class="nex_famous_txt">
                    	<ul>
                        	<!--[diy=nex_famous_txt]--><div id="nex_famous_txt" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                </div>
                <script type="text/javascript">
					jQuery(".nex_famous_txt ul li").each(function(s){
						jQuery(this).hover(function(){
							jQuery(this).addClass("on").siblings().removeClass("on");
							})
						})
				</script>
                <!--side_articles_author-->
                <div class="nex_side_box">
                	<div class="nex_side_top_txt">
                        <span>ר������</span>
                    </div>
                    
                    <div class="nex_authorlist">
                    	<ul>
                        	<!--[diy=nex_authorlist]--><div id="nex_authorlist" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                    
                </div>
                <!--side_ads-->
                <div class="nex_side_ads"><!--[diy=nex_side_ads4]--><div id="nex_side_ads4" class="area"></div><!--[/diy]--></div>
                <!--side_hot_tropicals-->
                <div class="nex_side_box">
                	<div class="nex_side_top_txt">
                        <span>����ר��</span>
                    </div>
                    <div class="nex_tropicals">
                    	<ul>
                        	<!--[diy=nex_tropicals]--><div id="nex_tropicals" class="area"></div><!--[/diy]-->
                            
                        </ul>
                    </div>
                </div>
                
            </div>
            <div class="clear"></div>
            <div class="nex_index_ads"><!--[diy=nex_index_ads3]--><div id="nex_index_ads3" class="area"></div><!--[/diy]--></div>
            <!--tastics-->
            <div class="nex_tastics_box">
            	<div class="nex_tastics_boxL">
                	<div class="nex_tastics_boxL_top">
                    	<div class="nex_tastics_boxL_iner">
                        	<!--[diy=nex_tastics_boxL_iner]--><div id="nex_tastics_boxL_iner" class="area"></div><!--[/diy]-->
                            
                        </div>
                    </div>
                    <div class="nex_tastics_boxL_btm">
                    	<ul>
                        	<!--[diy=nex_tastics_boxL_btm]--><div id="nex_tastics_boxL_btm" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                </div>
                
                <div class="nex_tastics_boxM">
                	<div class="nex_common_title">
                    	<span>�������</span><em>PLAYGROUND</em>
                        <ul>
                        	<li class="on">�����ռ�</li>
                            <li>��Ŀ��̸</li>
                            <li>��ҵ����</li>
                            <div class="clear"></div>
                        </ul>
                        <div class="clear"></div>
                    </div>
                	<div class="nex_playbc">
                    	<ul>
                        	<li style="display:block;">
                            	<div class="nex_playbox">
                                	<dl>
                                    	<!--[diy=nex_playbox]--><div id="nex_playbox" class="area"></div><!--[/diy]-->
                                    	
                                        <div class="clear"></div>
                                    </dl>
                                </div>
                            </li>
                            <li>
                            	<div class="nex_playbox">
                                	<dl>
                                    	<!--[diy=nex_playbox1]--><div id="nex_playbox1" class="area"></div><!--[/diy]-->
                                        <div class="clear"></div>
                                    </dl>
                                </div>
                            </li>
                            <li>
                            	<div class="nex_playbox">
                                	<dl>
                                    	<!--[diy=nex_playbox2]--><div id="nex_playbox2" class="area"></div><!--[/diy]-->
                                        <div class="clear"></div>
                                    </dl>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <script type="text/javascript">
						jQuery(".nex_common_title ul li").each(function(s){
							jQuery(this).click(function(){
								jQuery(this).addClass("on").siblings().removeClass("on");
								jQuery(".nex_playbc ul li").eq(s).show().siblings().hide();
								})
							})
					</script>
                </div>
                <div class="nex_tastics_boxR">
                	<div class="nex_common_title">
                    	<span>��ҵ�ɻ�</span><em>INDUSTRY</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">����&gt;</a>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_ganhuobox">
                    	<ul>
                        	<!--[diy=nex_ganhuobox]--><div id="nex_ganhuobox" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <!--links-->
            <div class="nex_linkbox">
            	<div class="nex_common_title">
                    <span>��������</span><em>RELATED LINKS</em>
                    <a href="tencent://Message/?Uin=���qq����&amp;websiteName=#=&amp;Menu=yes">��������������</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_linkpart">
                	<ul>
                    	<!--[diy=nex_linkpart]--><div id="nex_linkpart" class="area"></div><!--[/diy]-->
                				
					<div class="clear"></div>		
					</ul>
                </div>
            </div>
        </div>
    </div>
    
    
</div>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->


