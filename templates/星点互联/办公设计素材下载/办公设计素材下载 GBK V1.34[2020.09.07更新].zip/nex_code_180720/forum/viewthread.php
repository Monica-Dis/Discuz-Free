<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{eval $ucthread = C::t('forum_thread')->fetch_all_by_authorid($_G['forum_thread']['authorid'], 0,8);}-->
<!--{eval $ucauthor = DB::fetch_first("SELECT `follower`,`threads`,`following` FROM ".DB::table('common_member_count')." WHERE uid = ".$_G['forum_thread']['authorid']);}-->
<script type="text/javascript">var fid = parseInt('$_G[fid]'), tid = parseInt('$_G[tid]');</script>
<!--{if $modmenu['thread'] || $modmenu['post']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->
<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';var aimgcount = new Array();</script>

<style id="diy_style" type="text/css"></style>
<!--[diy=diynavtop]--><div id="diynavtop" class="area"></div><!--[/diy]-->
<!--{hook/viewthread_top}-->
<!--{ad/text/wp a_t}-->
<div id="pt" class="bm cl">
    <div class="z">
        <a href="./" class="nvhm" title="{lang homepage}">$_G[setting][bbname]</a>$navigation <em>&rsaquo;</em> <a href="forum.php?mod=viewthread&tid=$_G[tid]">$_G[forum_thread][short_subject]</a>
    </div>
</div>
<style id="diy_style" type="text/css"></style>
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>

<div class="nex_viewthread_top_ads"><!--[diy=nex_viewthread_top_ads]--><div id="nex_viewthread_top_ads" class="area"></div><!--[/diy]--></div>

<div id="ct" class="wp cl {if $close_leftinfo} ct2{/if}">
    <div class="mn" <!--{if !$close_leftinfo}--> <script type="text/javascript" src='$_G['style'][styleimgdir]/js/jquery-1.8.3.min.js'></script>
		<script type="text/javascript" src='$_G['style'][styleimgdir]/js/jquery.SuperSlide.2.1.1.js'></script>
        <!--��˾��Ʒ-->
        <div class="nex_Product_unextend">
            <div class="nex_PU_top">
                <h5>�������ط���</h5>
                <ul>
                    <li class="on"><span>HTMLģ��</span></li>
                    <li><span>���ͼԪ��</span></li>
                    <li><span>PPTģ��</span></li>
                    <li><span>ƽ������ز�</span></li>
                    <li><span>�����Ա��ز�</span></li>
                    <li><span>���屳��ͼ</span></li>
                </ul>
                <div class="clear"></div>
            </div>
            <div class="nex_PU_bottom">
                <ul>
                    <li style="display:block;">
                        <div class="nex_PU_Lists">
                            <dl>
                                <!--[diy=nex_PU_Lists1]--><div id="nex_PU_Lists1" class="area"></div><!--[/diy]-->
                                
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                        <div class="nex_PU_Lists">
                            <dl>
                                <!--[diy=nex_PU_Lists2]--><div id="nex_PU_Lists2" class="area"></div><!--[/diy]-->
                                
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                        <div class="nex_PU_Lists">
                            <dl>
                                <!--[diy=nex_PU_Lists3]--><div id="nex_PU_Lists3" class="area"></div><!--[/diy]-->
                                
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                        <div class="nex_PU_Lists">
                            <dl>
                                <!--[diy=nex_PU_Lists4]--><div id="nex_PU_Lists4" class="area"></div><!--[/diy]-->
                                
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                        <div class="nex_PU_Lists">
                            <dl>
                                <!--[diy=nex_PU_Lists5]--><div id="nex_PU_Lists5" class="area"></div><!--[/diy]-->
                                
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                        <div class="nex_PU_Lists">
                            <dl>
                                <!--[diy=nex_PU_Lists6]--><div id="nex_PU_Lists6" class="area"></div><!--[/diy]-->
                                
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
                jQuery(".nex_PU_top ul li").each(function(s){
                    jQuery(this).click(function(){
                        jQuery(this).addClass("on").siblings().removeClass("on");
                        jQuery(".nex_PU_bottom ul li").eq(s).show().siblings().hide();
                        })
                    })
            </script>
         </div>
        
        <!--{/if}-->
        <script type="text/javascript" src='$_G['style'][styleimgdir]/js/jquery.SuperSlide.2.1.1.js'></script>
        
        <div id="pgt" class="pgs mbm cl {if $modmenu['thread']}pbm bbs{/if}" style=" display:none;">
            <div class="pgt">$multipage</div>
            <span class="y pgb"{if $_G['setting']['visitedforums']} id="visitedforums" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id,'pos':'34'})"{/if}><a href="$upnavlink">{lang return_forumdisplay}</a></span>
            <!--{if $_G['forum']['threadsorts'] && $_G['forum']['threadsorts']['templatelist']}-->
                <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
                    <button id="newspecial" class="pn pnc" onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id'"><strong>{lang i_want}$name</strong></button>
                <!--{/loop}-->
            <!--{else}-->
                <!--{if !$_G['forum_thread']['is_archived']}--><a id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} href="javascript:;" title="{lang send_posts}"><img src="{IMGDIR}/pn_post.png" alt="{lang send_posts}" /></a><!--{/if}-->
            <!--{/if}-->
            <!--{if $allowpostreply && !$_G['forum_thread']['archiveid']}-->
                <a id="post_reply" onclick="showWindow('reply', 'forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]')" href="javascript:;" title="{lang reply}"><img src="{IMGDIR}/pn_reply.png" alt="{lang reply}" /></a>
            <!--{/if}-->
            <!--{hook/viewthread_postbutton_top}-->
        </div>
    
   		<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
        <ul class="p_pop" id="newspecial_menu" style="display: none">
            <!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang post_newthread}</a></li><!--{/if}-->
            <!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
                <!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
                    <!--{if $_G['forum']['threadsorts']['show'][$id]}-->
                        <li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&sortid=$id">$threadsorts</a></li>
                    <!--{/if}-->
                <!--{/loop}-->
            <!--{/if}-->
            <!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
            <!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
            <!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
            <!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
            <!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
            <!--{if $_G['setting']['threadplugins']}-->
                <!--{loop $_G['forum']['threadplugin'] $tpid}-->
                    <!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
                        <li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url(source/plugin/$tpid/$_G['setting']['threadplugins'][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G['setting']['threadplugins'][$tpid][name]}</a></li>
                    <!--{/if}-->
                <!--{/loop}-->
            <!--{/if}-->
        </ul>
    	<!--{/if}-->
    
    	<!--{if $modmenu['post']}-->
        <div id="mdly" class="fwinmask" style="display:none;z-index:350;">
            <table cellspacing="0" cellpadding="0" class="fwin">
                <tr>
                    <td class="t_l"></td>
                    <td class="t_c"></td>
                    <td class="t_r"></td>
                </tr>
                <tr>
                    <td class="m_l">&nbsp;&nbsp;</td>
                    <td class="m_c">
                        <div class="f_c">
                            <div class="c">
                                <h3>{lang admin_select}&nbsp;<strong id="mdct" class="xi1"></strong>&nbsp;{lang piece}: </h3>
                                <!--{if $_G['forum']['ismoderator']}-->
                                    <!--{if $_G['group']['allowwarnpost']}--><a href="javascript:;" onclick="modaction('warn')">{lang modmenu_warn}</a><span class="pipe">|</span><!--{/if}-->
                                    <!--{if $_G['group']['allowbanpost']}--><a href="javascript:;" onclick="modaction('banpost')">{lang modmenu_banpost}</a><span class="pipe">|</span><!--{/if}-->
                                    <!--{if $_G['group']['allowdelpost'] && !$rushreply}--><a href="javascript:;" onclick="modaction('delpost')">{lang modmenu_deletepost}</a><span class="pipe">|</span><!--{/if}-->
                                <!--{/if}-->
                                <!--{if $_G['forum']['ismoderator'] && $_G['group']['allowstickreply'] || $_G['forum_thread']['authorid'] == $_G['uid']}--><a href="javascript:;" onclick="modaction('stickreply')">{lang modmenu_stickpost}</a><span class="pipe">|</span><!--{/if}-->
                                <!--{if $_G['forum_thread']['pushedaid'] && $allowpostarticle}--><a href="javascript:;" onclick="modaction('pushplus', '', 'aid=$_G[forum_thread][pushedaid]', 'portal.php?mod=portalcp&ac=article&op=pushplus')">{lang modmenu_pushplus}</a><span class="pipe">|</span><!--{/if}-->
                            </div>
                        </div>
                    </td>
                    <td class="m_r"></td>
                </tr>
                <tr>
                    <td class="b_l"></td>
                    <td class="b_c"></td>
                    <td class="b_r"></td>
                </tr>
            </table>
        </div>
    	<!--{/if}-->

    	<!--{hook/viewthread_modoption}-->
    	<!--{hook/viewthread_beginline}-->
    
    
    
    	<div id="postlist" class="pl bm {if !$close_leftinfo}nex_conone{else}nex_others{/if}">
  		<!--{if $_G['forum_thread']['replycredit'] > 0 || $rushreply}-->
            <div id="pl_top" class="box mb20">
                <table cellspacing="0" cellpadding="0">
                    <tr class="ad">
                        <td class="pls"></td>
                        <td class="plc"></td>
                    </tr>
                    <!--{if $_G['forum_thread']['replycredit'] > 0 }-->
                        <tr>
                            <!--{if !$close_leftinfo}-->
                            <td class="pls vm ptm">
                            <!--{else}-->
                            <td class="pls ptm pbm xi1" colspan="2">
                            <!--{/if}-->
                                <img src="{IMGDIR}/thread_prize_s.png" class="hm" alt="{lang replycredit}" />
                                    <strong>{$_G['forum_thread']['replycredit']} {$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][unit]}{$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][title]}</strong>
                            <!--{if !$close_leftinfo}-->
                            </td>
                            <td class="plc ptm pbm xi1">
                            <!--{else}-->
                            &nbsp;&nbsp;&nbsp;&nbsp;
                            <!--{/if}-->
                                {lang thread_replycredit_tips1} {lang thread_replycredit_tips2}<!--{if $_G['forum_thread']['replycredit_rule'][random] > 0}--><span class="xg1">{lang thread_replycredit_tips3}</span><!--{/if}-->
                            </td>
                        </tr>
                        <!--{if $rushreply}-->
                        <tr class="ad">
                            <td class="pls"></td>
                            <td class="plc"></td>
                        </tr>
                        <!--{/if}-->
                <!--{/if}-->
        
                <!--{if $rushreply}-->
                    <tr>
                        <!--{if !$close_leftinfo}-->
                        <td class="pls vm ptm">
                            <img src="{IMGDIR}/rushreply_s.png" class="vm" alt="{lang rushreply}" />
                            <strong>{lang rushreply}</strong>
                        </td>
                        <td class="plc ptm pbm xi1">
                        <!--{else}-->
                        <td class="plc ptm pbm xi1" colspan="2">
                            <img src="{IMGDIR}/rushreply_s.png" class="vm" alt="{lang rushreply}" />
                        <!--{/if}-->
                            <!--{if $rushresult[rewardfloor]}-->
                                <span class="y">
                                <!--{if $_G['uid'] == $_G['thread']['authorid'] || $_G['forum']['ismoderator']}--><a href="javascript:;" onclick="showWindow('membernum', 'forum.php?mod=ajax&action=get_rushreply_membernum&tid=$_G[tid]')" class="y pn xi2"><span>{lang thread_rushreply_statnum}</span></a><!--{/if}-->
                                <!--{if !$_GET['checkrush']}-->
                                        <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" class="y pn xi2"><span>{lang rushreply_view}</span></a>
                                <!--{/if}-->
                                </span>
                            <!--{/if}-->
                            <!--{if $rushresult[creditlimit] == ''}-->
                                {lang thread_rushreply}&nbsp;
                            <!--{else}-->
                                {lang thread_rushreply_limit} &nbsp;
                            <!--{/if}-->
                            <!--{if $rushresult['timer']}-->
                            <span id="rushtimer_$thread[tid]"> {lang havemore_special} <span id="rushtimer_body_$thread[tid]"></span> <script language="javascript">settimer($rushresult['timer'], 'rushtimer_body_$thread[tid]');</script>{if $rushresult['timertype'] == 'start'} {lang header_start} {else} {lang over} {/if} {lang right_special}</span>
                            <!--{/if}-->
                            <!--{if $rushresult[stopfloor]}-->
                                {lang thread_rushreply_end}$rushresult[stopfloor]&nbsp;
                            <!--{/if}-->
                            <!--{if $rushresult[rewardfloor]}-->
                                {lang thread_rushreply_floor}: $rushresult[rewardfloor]&nbsp;
                            <!--{/if}-->
                            <!--{if $rushresult[rewardfloor] && $_GET['checkrush']}-->
                                <p class="ptn">
                                    <!--{if $countrushpost}-->[<strong>$countrushpost</strong>]{lang thread_rushreply_rewardnum}<!--{else}--> {lang thread_rushreply_noreward} <!--{/if}-->&nbsp;&nbsp;
                                    <a href="forum.php?mod=viewthread&tid=$_G[tid]" class="xi2">{lang thread_rushreply_check_back}</a>
                                </p>
                            <!--{/if}-->
                        </td>
                    </tr>
                <!--{/if}-->
                </table>
            </div>
            <!--{/if}-->
            
        <div class="vwthdtit cl">
            <!--{if $_G['setting']['close_leftinfo_userctrl']}-->
             
                <!--{if !$close_leftinfo}-->
                    <a onclick="setcookie('close_leftinfo', 1);location.reload();" title="{lang collapse_the_left}" class="btn_s_close" href="javascript:;"><img src="$_G['style'][styleimgdir]/viewthread/control_l.png" alt="{lang collapse_the_left}" class="vm" /></a>
                <!--{else}-->
                    <a onclick="setcookie('close_leftinfo', 2);location.reload();" title="{lang open_the_left}" class="btn_s_open" href="javascript:;"><img src="$_G['style'][styleimgdir]/viewthread/control_r.png" alt="{lang open_the_left}" class="vm" /></a>
                <!--{/if}-->
                
            <!--{/if}-->
            <!--{if !$close_leftinfo}-->
			<div class="vwthduser cl z">
				<!--{if $_G['page'] > 1}-->
					<!--{if $_G[forum_thread][authorid] && $_G[forum_thread][author]}-->
						<a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" title="$_G[forum_thread][author]"><!--{avatar($_G[forum_thread][authorid],middle)}--></a>
						{lang thread_author}: <a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" title="$_G[forum_thread][author]">$_G[forum_thread][author]</a>
					<!--{else}-->
						{lang thread_author}:
						<!--{if $_G['forum']['ismoderator']}-->
							<a href="home.php?mod=space&uid=$_G[forum_thread][authorid]">{lang anonymous}</a>
						<!--{else}-->
							{lang anonymous}
						<!--{/if}-->
					<!--{/if}-->
				<!--{/if}-->
			</div>
			<!--{/if}-->
            <!--{if $close_leftinfo}-->
            
            <!--{else}-->
            <h1 class="vwthdts z">
                <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
                    <!--{if !IS_ROBOT && ($_G['forum']['threadtypes']['listable'] || $_G['forum']['status'] == 3)}-->
                        <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$_G[forum_thread][typeid]">[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]</a>
                    <!--{else}-->
                        [{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
                    <!--{/if}-->
                <!--{/if}-->
                <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
                    <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_G[forum_thread][sortid]">[{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]</a>
                <!--{/if}-->
                <span id="thread_subject">$_G[forum_thread][subject]</span>
            </h1>
            <span class="xg1">
                <!--{if $_G['forum_thread'][displayorder] == -2}-->({lang moderating})
                <!--{elseif $_G['forum_thread'][displayorder] == -3}-->({lang have_ignored})
                <!--{elseif $_G['forum_thread'][displayorder] == -4}-->({lang draft})
                    <!--{if $post['first'] && $post['invisible'] == -3}-->
                        <a class="psave" href="forum.php?mod=misc&action=pubsave&tid=$_G[tid]">{lang published}</a>
                    <!--{/if}-->
                <!--{/if}-->
                <!--{if $_G['setting']['threadhidethreshold'] && $_G['forum_thread']['hidden'] >= $_G['setting']['threadhidethreshold']}-->						
                    <!--{if $_G['forum_thread']['authorid'] == $_G['uid']}--><a class="psave" id="hiderecover" title="{lang hiderecover_tips}" href="forum.php?mod=misc&action=hiderecover&tid=$_G[tid]&formhash={FORMHASH}" onclick="showWindow(this.id, this.href, 'get', 0);">{lang hidden}</a><!--{else}-->({lang hidden})<!--{/if}-->
                    &nbsp;
                <!--{/if}-->
                <!--{if $_G['forum_thread']['recommendlevel']}-->
                    &nbsp;<img src="{IMGDIR}/recommend_$_G['forum_thread']['recommendlevel'].gif" alt="" title="{lang thread_recommend} $_G['forum_thread'][recommends]" />
                <!--{/if}-->
                <!--{if $_G['forum_thread'][heatlevel]}-->
                    &nbsp;<img src="{IMGDIR}/hot_$_G['forum_thread'][heatlevel].gif" alt="" title="{lang heats}: $_G['forum_thread']['heats']" />
                <!--{/if}-->
                <!--{if $_G['forum_thread']['closed'] == 1}-->
                    &nbsp;<img src="{IMGDIR}/locked.gif" alt="{lang close}" title="{lang close}" class="vm" />
                <!--{/if}-->
                <a href="forum.php?mod=viewthread&tid=$_G[tid]$fromuid" onclick="return copyThreadUrl(this, '$_G[setting][bbname]')" {if $fromuid}title="{lang share_url_copy_comment}"{/if}>[{lang share_url_copy}]</a>
            </span>
            
            <!--{hook/viewthread_title_extra}-->
            <!--{/if}-->
            
            
            <!--{if !$close_leftinfo}-->
            <span class="vwthdreplies y">
            	<strong>$_G[forum_thread][allreplies]</strong></br>{lang reply}
            </span>
            <span class="vwthdviews y">
            	<strong>$_G[forum_thread][views]</strong></br>{lang show}
            </span>
             <!--{if !IS_ROBOT}-->
                <div class="y">
                    <!--{if $post['invisible'] == 0}--><a href="forum.php?mod=viewthread&action=printable&tid=$_G[tid]" title="{lang thread_printable}" target="_blank"><img src="{IMGDIR}/print.png" alt="{lang thread_printable}" class="vm" /></a>
                    <!--{/if}-->
                    <a href="forum.php?mod=redirect&goto=nextoldset&tid=$_G[tid]" title="{lang last_thread}"><img src="{IMGDIR}/thread-prev.png" alt="{lang last_thread}" class="vm" /></a>
                    <a href="forum.php?mod=redirect&goto=nextnewset&tid=$_G[tid]" title="{lang next_thread}"><img src="{IMGDIR}/thread-next.png" alt="{lang next_thread}" class="vm" /></a>
                </div>
            <!--{/if}-->
            <!--{/if}-->
            
        </div>
        
        
        <script type="text/javascript">
		jQuery(".vwthdewm").hover(function(){
			jQuery(this).children(".vwthdewmsub").show();
			},function(){
			jQuery(this).children(".vwthdewmsub").hide();
			})
		</script>
        
        <!--{hook/viewthread_title_row}-->
    
        <table cellspacing="0" cellpadding="0" class="ad" style=" display:none;">
            <tr>
                <td class="pls">
                <!--{if !$close_leftinfo}-->
                </td>
                <td class="plc">
                <!--{/if}-->
                </td>
            </tr>
        </table>
        <!--{eval $postcount = 0;}-->
        <!--{loop $postlist $post}-->
            <!--{if $rushreply && $_GET['checkrush'] && $post['rewardfloor'] != 1}-->
                <!--{eval continue;}-->
            <!--{/if}--> 
            <div id="post_$post[pid]" class="viewbox {if $post['first']}firstfloor{else}otherfloor{/if} cl" {if $_G['blockedpids'] && $post['inblacklist']}style="display:none;"{/if}>
                <!--{subtemplate forum/viewthread_node}-->
            </div>
            <!--{eval $postcount++;}-->
        <!--{/loop}-->
        <div id="postlistreply" class="pl"><div id="post_new" class="viewthread_table" style="display: none"></div></div>
        <!--{if $_G['blockedpids']}-->
            <div id='hiddenpoststip'><a href='javascript:display_blocked_post();'>{lang other_reply_hide}</a></div>
            <div id="hiddenposts"></div>
        <!--{/if}-->
    </div>
    
    
    <form method="post" autocomplete="off" name="modactions" id="modactions">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="optgroup" />
        <input type="hidden" name="operation" />
        <input type="hidden" name="listextra" value="$_GET[extra]" />
        <input type="hidden" name="page" value="$page" />
    </form>
    
    $_G['forum_tagscript']
    
    <!--{if $multipage && $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->
    <!--{eval $nxtpage = $page + 1;}-->
        <div class="pgbtn"><a href="forum.php?mod=viewthread&tid=$_G[tid]{if $_GET[authorid]}&authorid=$_GET[authorid]{/if}&page=$nxtpage" hidefocus="true">{lang next_page_extra}</a></div>
    <!--{/if}-->
    
    <div class="pgs mtm mbm cl">
        $multipage
        <span class="pgb y"{if $_G['setting']['visitedforums']} id="visitedforumstmp" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id,'pos':'21'})"{/if}><a href="$upnavlink">{lang return_forumdisplay}</a></span>
        <div class="nex_canyubox">
            <a class="nex_side_post" onclick="showWindow('newthread', 'forum.php?mod=post&amp;action=newthread&amp;fid=$_G[fid]')" href="javascript:;" title="{lang send_posts}">����</a>
        <!--{if $allowpostreply && !$_G['forum_thread']['archiveid']}-->
            <a class="nex_side_reply" onclick="showWindow('reply', 'forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]')" href="javascript:;" title="{lang reply}">�ظ�</a>
        <!--{/if}-->
            <div class="clear"></div>
        </div>
    </div>
    
    <!--{hook/viewthread_middle}-->
    <!--[diy=diyfastposttop]--><div id="diyfastposttop" class="area"></div><!--[/diy]-->
    <!--{if $fastpost}-->
        <!--{subtemplate forum/viewthread_fastpost}-->
    <!--{/if}-->
    
    <!--{hook/viewthread_bottom}-->
    
    <!--{if ($_G['setting']['visitedforums']) && $_G['forum']['status'] != 3}-->
        <div id="visitedforums_menu" class="p_pop blk cl" style="display: none;">
            <table cellspacing="0" cellpadding="0">
                <tr>
                    <td id="v_forums">
                        <h3 class="mbn pbn bbda xg1">{lang viewed_forums}</h3>
                        <ul class="xl xl1">
                            $_G['setting']['visitedforums']
                        </ul>
                    </td>
                </tr>
            </table>
        </div>
    <!--{/if}-->
    <!--{if $_G['medal_list']}-->
    <!--{loop $_G['medal_list'] $medalid $medal}-->
        <div id="md_{$medalid}_menu" class="tip tip_4" style="display: none;">
            <div class="tip_horn"></div>
            <div class="tip_c">
                <h4>$medal[name]</h4>
                <p>$medal[description]</p>
            </div>
        </div>
    <!--{/loop}-->
    <!--{/if}-->
    
    <!--{if !IS_ROBOT && !empty($_G[setting][lazyload])}-->
        <script type="text/javascript">
        new lazyload();
        </script>
    <!--{/if}-->
    
    <!--{if !IS_ROBOT && $_G['setting']['threadmaxpages'] > 1}-->
        <script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=viewthread&tid=$_G[tid]<!--{if $_GET[authorid]}-->&authorid=$_GET[authorid]<!--{/if}-->', $page);}</script>
    <!--{/if}-->
    </div>
    
</div>

<div class="wp mtn">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>
<!--{if $_G['relatedlinks'] || $_GET['highlight']}-->
	<script type="text/javascript">
		var relatedlink = [];
		<!--{loop $_G['relatedlinks'] $key $link}-->
		relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
		<!--{/loop}-->
		{eval $highlights = explode(' ', str_replace(array('\'', chr(125)), array('&#039;', '&#125;'), dhtmlspecialchars($_GET['highlight'])));}
		<!--{loop $highlights $word}-->
		{eval $key++;}
		relatedlink[$key] = {'sname':'$word', 'surl':''};
		<!--{/loop}-->
		relatedlinks('postmessage_$_G[forum_firstpid]');
	</script>
<!--{/if}-->

<!--{if !empty($_G['cookie']['clearUserdata']) && $_G['cookie']['clearUserdata'] == 'forum'}-->
	<script type="text/javascript">saveUserdata('forum_'+discuz_uid, '')</script>
<!--{/if}-->

<script type="text/javascript">
<!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->
function showsetcover(obj) {
	if(obj.parentNode.id == 'postmessage_$_G[forum_firstpid]') {
		var defheight = $_G['setting']['forumpicstyle']['thumbheight'];
		var defwidth = $_G['setting']['forumpicstyle']['thumbwidth'];
		var newimgid = 'showcoverimg';
		var imgsrc = obj.src ? obj.src : obj.file;
		if(!imgsrc) return;

		var tempimg=new Image();
		tempimg.src=imgsrc;
		if(tempimg.complete) {
			if(tempimg.width < defwidth || tempimg.height < defheight) return;
		} else {
			return;
		}
		if($(newimgid) && obj.id != newimgid) {
			$(newimgid).id = 'img'+Math.random();
		}
		if($(newimgid+'_menu')) {
			var menudiv = $(newimgid+'_menu');
		} else {
			var menudiv = document.createElement('div');
			menudiv.className = 'tip tip_4 aimg_tip';
			menudiv.id = newimgid+'_menu';
			menudiv.style.position = 'absolute';
			menudiv.style.display = 'none';
			obj.parentNode.appendChild(menudiv);
		}
		menudiv.innerHTML = '<div class="tip_c xs0"><a onclick="showWindow(\'setcover_'+newimgid+'\', this.href)" href="forum.php?mod=ajax&amp;action=setthreadcover&amp;tid=$_G[tid]&amp;pid=$_G[forum_firstpid]&amp;fid=$_G[fid]&imgurl='+imgsrc+'">{lang set_cover}</a></div>';
		obj.id = newimgid;
		showMenu({'ctrlid':newimgid,'pos':'12'});
	}
	return;
}
<!--{/if}-->
function succeedhandle_followmod(url, msg, values) {
	var fObj = $('followmod_'+values['fuid']);
	if(values['type'] == 'add') {
		fObj.innerHTML = '{lang nofollow}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
	} else if(values['type'] == 'del') {
		fObj.innerHTML = '{lang follow}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
	}
}
<!--{if $_G['blockedpids']}-->
var blockedPIDs = [<!--{echo implode(',', $_G['blockedpids'])}-->];
<!--{/if}-->
<!--{if $postlist && empty($_G['setting']['disfixedavatar'])}-->
fixed_avatar([<!--{echo implode(',', array_keys($postlist))}-->], {if empty($_G['setting']['disfixednv_viewthread']) }1{else}0{/if});
<!--{elseif empty($_G['setting']['disfixednv_viewthread'])}-->
fixed_top_nv();
<!--{/if}-->
</script>
<!--{if $close_leftinfo}-->
<!--��˾��Ʒ-->
<div class="nex_Product_unextend">
    <div class="nex_PU_top">
        <h5>�������ط���</h5>
        <ul>
            <li class="on"><span>HTMLģ��</span></li>
            <li><span>���ͼԪ��</span></li>
            <li><span>PPTģ��</span></li>
            <li><span>ƽ������ز�</span></li>
            <li><span>�����Ա��ز�</span></li>
            <li><span>���屳��ͼ</span></li>
        </ul>
        <div class="clear"></div>
    </div>
    <div class="nex_PU_bottom">
        <ul>
            <li style="display:block;">
                <div class="nex_PU_Lists">
                    <dl>
                        <!--[diy=nex_PU_Lists1]--><div id="nex_PU_Lists1" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </dl>
                </div>
            </li>
            <li>
                <div class="nex_PU_Lists">
                    <dl>
                        <!--[diy=nex_PU_Lists2]--><div id="nex_PU_Lists2" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </dl>
                </div>
            </li>
            <li>
                <div class="nex_PU_Lists">
                    <dl>
                        <!--[diy=nex_PU_Lists3]--><div id="nex_PU_Lists3" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </dl>
                </div>
            </li>
            <li>
                <div class="nex_PU_Lists">
                    <dl>
                        <!--[diy=nex_PU_Lists4]--><div id="nex_PU_Lists4" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </dl>
                </div>
            </li>
            <li>
                <div class="nex_PU_Lists">
                    <dl>
                        <!--[diy=nex_PU_Lists5]--><div id="nex_PU_Lists5" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </dl>
                </div>
            </li>
            <li>
                <div class="nex_PU_Lists">
                    <dl>
                        <!--[diy=nex_PU_Lists6]--><div id="nex_PU_Lists6" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </dl>
                </div>
            </li>
        </ul>
    </div>
    <script type="text/javascript">
        jQuery(".nex_PU_top ul li").each(function(s){
            jQuery(this).click(function(){
                jQuery(this).addClass("on").siblings().removeClass("on");
                jQuery(".nex_PU_bottom ul li").eq(s).show().siblings().hide();
                })
            })
    </script>
 </div>
  
<!--{/if}-->
<!--{template common/footer}-->