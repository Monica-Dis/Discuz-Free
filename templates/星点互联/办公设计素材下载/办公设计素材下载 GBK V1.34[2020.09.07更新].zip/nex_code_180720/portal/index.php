<?php echo 'Copyright@Neoconex�ǵ㻥��-��Ȩ����';exit;?>
<!--{template common/header_index}-->
<div class="wp">
	<!--ͷ���õ�-->
    <div class="nex_slider">
    	<div class="w1180">
        	<div class="nex_focusBox">
            	<!--[diy=nex_focusBox]--><div id="nex_focusBox" class="area"></div><!--[/diy]-->
                
                <a class="prev" href="javascript:void(0)"></a>
                <a class="next" href="javascript:void(0)"></a>
                <ul class="hd">
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
        
            <script type="text/javascript">
                jQuery(".nex_focusBox").hover(function(){ jQuery(this).find(".prev,.next").stop(true,true).fadeTo("show",0.2) },function(){ jQuery(this).find(".prev,.next").fadeOut() });
                jQuery(".nex_focusBox").slide({ mainCell:".pic",effect:"fold", autoPlay:true, delayTime:600, trigger:"click"});
            </script>
            <div class="nex_features">
            	<ul>
                	<!--[diy=nex_features]--><div id="nex_features" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    <!--ר��-->
    <div class="nex_zhuantibox">
    	<div class="w1180">
        	<div class="nex_commonTop">
            	<h2>��ѡר����Դ</h2>
                <p>���ʾ�ѡ��ר����Դ���������ɹ�</p>
            </div>
            <div class="nex_zhuantipart">
            	<div class="nex_zhuantipartL">
                	<!--[diy=nex_zhuantipartL]--><div id="nex_zhuantipartL" class="area"></div><!--[/diy]-->
                	
                </div>
                <div class="nex_zhuantipartR">
                	<div class="nex_zhuantipartRT">
                    	<!--[diy=nex_zhuantipartRT]--><div id="nex_zhuantipartRT" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_zhuantipartRB">
                    	<ul>
                        	<li class="nex_ztbg3">
                            	<!--[diy=nex_ztbg3]--><div id="nex_ztbg3" class="area"></div><!--[/diy]-->
                            	
                            </li>
                            <li class="nex_ztbg4">
                            	<!--[diy=nex_ztbg4]--><div id="nex_ztbg4" class="area"></div><!--[/diy]-->
                            	
                            </li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                </div>
                <div class="nex_zhuantipartR">
                	<div class="nex_zhuantipartRT nex_zhuantipartRT1">
                    	<!--[diy=nex_zhuantipartRT1]--><div id="nex_zhuantipartRT1" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_zhuantipartRB">
                    	<ul>
                        	<li class="nex_ztbg6">
                            	<!--[diy=nex_ztbg6]--><div id="nex_ztbg6" class="area"></div><!--[/diy]-->
                            	
                            </li>
                            <li class="nex_ztbg7">
                            	<!--[diy=nex_ztbg7]--><div id="nex_ztbg7" class="area"></div><!--[/diy]-->
                            	
                            </li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <!--HTMLģ��-->
    <div class="nex_codeaeras">
    	<div class="w1180">
        	<div class="nex_toptitle_part">
            	<h2>HTML TEMPLATE</h2>
                <h5><em class="nex_title_decor1"></em><em class="nex_title_decor2"></em>HTMLģ��</h5>
                <p>- HTMLģ����ͼ���� -</p>
            </div>
            <div class="nex_tab_box">
            	<ul>
                	<li class="on"><span>��ѡģ��</span></li>
                    <li><span>��ҵ��˾</span></li>
                    <li><span>��ҵ��Ѷ</span></li>
                    <li><span>������ѵ</span></li>
                    <li><span>�����Ż�</span></li>
                    <li><span>�����̳�</span></li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_tab_part">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox]--><div id="nex_contentbox" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox1]--><div id="nex_contentbox1" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox2]--><div id="nex_contentbox2" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox3]--><div id="nex_contentbox3" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox4]--><div id="nex_contentbox4" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox5]--><div id="nex_contentbox5" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_tab_box ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_tab_part ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
            <div class="nex_more_btn"><a href="http://t.cn/Aiux1012" target="_blank">����HTMLģ��</a></div>
        </div>
    </div>
    <!--���ͼԪ��-->
    <div class="nex_codeaeras nex_free_element">
    	<div class="w1180">
        	<div class="nex_toptitle_part nex_fe_top">
            	<h2>THRUST FREE ELEMENT</h2>
                <h5><em class="nex_title_decor1"></em><em class="nex_title_decor2"></em>���ͼԪ��</h5>
                <p>- �Ӵ���������׶��� -</p>
            </div>
            <div class="nex_tab_box nex_element_tab">
            	<ul>
                	<li class="on"><span>��ѡԪ��</span></li>
                    <li><span>��ͨ����</span></li>
                    <li><span>������״</span></li>
                    <li><span>������ͼ</span></li>
                    <li><span>Ư���ز�</span></li>
                    <li><span>װ��ͼ��</span></li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_tab_part nex_element_part">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox6]--><div id="nex_contentbox6" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox7]--><div id="nex_contentbox7" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox8]--><div id="nex_contentbox8" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox9]--><div id="nex_contentbox9" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox10]--><div id="nex_contentbox10" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox11]--><div id="nex_contentbox11" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_element_tab ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_element_part ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
            <div class="nex_more_btn"><a href="http://t.cn/Aiux1012" target="_blank">�������ͼԪ��</a></div>
        </div>
    </div>
    <!--PPT��ѡģ��-->
    <div class="nex_codeaeras nex_ppt_template">
    	<div class="w1180">
        	<div class="nex_toptitle_part nex_ppt_top">
            	<h2>FREE PPT TEMPLATES</h2>
                <h5><em class="nex_title_decor1"></em><em class="nex_title_decor2"></em>PPT��ѡģ��</h5>
                <p>- �����������ŵ�PPT�ĵ� -</p>
            </div>
            <div class="nex_tab_box nex_ppt_tab">
            	<ul>
                	<li class="on"><span>�����ܽ�PPT</span></li>
                    <li><span>˵��PPT</span></li>
                    <li><span>��ѧ���PPT</span></li>
                    <li><span>��ѵPPT</span></li>
                    <li><span>��ְ����PPT</span></li>
                    <li><span>����PPT</span></li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_tab_part nex_ppt_part">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox12]--><div id="nex_contentbox12" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox13]--><div id="nex_contentbox13" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox14]--><div id="nex_contentbox14" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox15]--><div id="nex_contentbox15" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox16]--><div id="nex_contentbox16" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox17]--><div id="nex_contentbox17" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_ppt_tab ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_ppt_part ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
            <div class="nex_more_btn"><a href="http://t.cn/Aiux1012" target="_blank">����PPTģ��</a></div>
        </div>
    </div>
    <!--ƽ������ز�-->
    <div class="nex_codeaeras nex_free_element">
    	<div class="w1180">
        	<div class="nex_toptitle_part nex_fe_top">
            	<h2>GRAPHIC DESIGN MATERIALS</h2>
                <h5><em class="nex_title_decor1"></em><em class="nex_title_decor2"></em>ƽ������ز�</h5>
                <p>- ��ȡ������������ -</p>
            </div>
            <div class="nex_tab_box nex_flat_tab">
            	<ul>
                	<li class="on"><span>ƽ����</span></li>
                    <li><span>��ҳUI</span></li>
                    <li><span>ICON���</span></li>
                    <li><span>�������</span></li>
                    <li><span>ԭ���廭</span></li>
                    <li><span>LOGO��ʶ</span></li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_tab_part nex_flat_part">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox18]--><div id="nex_contentbox18" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox19]--><div id="nex_contentbox19" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox20]--><div id="nex_contentbox20" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox21]--><div id="nex_contentbox21" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox22]--><div id="nex_contentbox22" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox23]--><div id="nex_contentbox23" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_flat_tab ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_flat_part ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
            <div class="nex_more_btn"><a href="http://t.cn/Aiux1012" target="_blank">����ƽ������ز�</a></div>
        </div>
    </div>
    <!--�����Ա��ز�-->
    <div class="nex_codeaeras nex_ppt_template">
    	<div class="w1180">
        	<div class="nex_toptitle_part nex_ppt_top">
            	<h2>E-COMMERCE TEMPLATES</h2>
                <h5><em class="nex_title_decor1"></em><em class="nex_title_decor2"></em>�����Ա��ز�</h5>
                <p>- �Ա�����װ�����ɸ㶨 -</p>
            </div>
            <div class="nex_tab_box nex_ecom_tab">
            	<ul>
                	<li class="on"><span>ֱͨ��/��ͼ</span></li>
                    <li><span>��ҳģ��</span></li>
                    <li><span>���մ���</span></li>
                    <li><span>����ҳģ��</span></li>
                    <li><span>ͨ�õ���ģ��</span></li>
                    <li><span>����/�Ա�����</span></li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_tab_part nex_ecom_part">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox24]--><div id="nex_contentbox24" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox25]--><div id="nex_contentbox25" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox26]--><div id="nex_contentbox26" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox27]--><div id="nex_contentbox27" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox28]--><div id="nex_contentbox28" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox29]--><div id="nex_contentbox29" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_ecom_tab ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_ecom_part ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
            <div class="nex_more_btn"><a href="http://t.cn/Aiux1012" target="_blank">��������Ա�ģ���ز�</a></div>
        </div>
    </div>
    <!--���屳��ͼ-->
    <div class="nex_codeaeras nex_free_element">
    	<div class="w1180">
        	<div class="nex_toptitle_part nex_fe_top">
            	<h2>HD BACKGROUND IMAGES</h2>
                <h5><em class="nex_title_decor1"></em><em class="nex_title_decor2"></em>���屳��ͼ</h5>
                <p>- �����������ʦ�Ĵ������� -</p>
            </div>
            <div class="nex_tab_box nex_hds_tab">
            	<ul>
                	<li class="on"><span>���̱���</span></li>
                    <li><span>banner����</span></li>
                    <li><span>���彥�䱳��</span></li>
                    <li><span>��ͼ/ֱͨ��</span></li>
                    <li><span>�ļ�����</span></li>
                    <li><span>�����ֽ</span></li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_tab_part nex_hds_part">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox30]--><div id="nex_contentbox30" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox31]--><div id="nex_contentbox31" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox32]--><div id="nex_contentbox32" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox33]--><div id="nex_contentbox33" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox34]--><div id="nex_contentbox34" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox35]--><div id="nex_contentbox35" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_hds_tab ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_hds_part ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
            <div class="nex_more_btn"><a href="http://t.cn/Aiux1012" target="_blank">������屳��ͼ�ز�</a></div>
        </div>
    </div>
    <!--��������-->
    <div class="nex_codeaeras nex_ppt_template">
    	<div class="w1180">
        	<div class="nex_toptitle_part nex_rk_top">
            	<h2>DOWNLOAD RANKLIST</h2>
                <h5><em class="nex_title_decor1"></em><em class="nex_title_decor2"></em>�ز���������</h5>
                <p>- ������Ҫ��Ҳ��������Ҳ��Ҫ�� -</p>
            </div>
            <div class="nex_tab_box nex_rk_tab">
            	<ul>
                	<li class="on"><span>��ҳHTMLģ��</span></li>
                    <li><span>���ͼԪ��</span></li>
                    <li><span>PPT�칫</span></li>
                    <li><span>ƽ�����</span></li>
                    <li><span>�����Ա�</span></li>
                    <li><span>����ͼ</span></li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_tab_part nex_rk_part">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox36]--><div id="nex_contentbox36" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox37]--><div id="nex_contentbox37" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox38]--><div id="nex_contentbox38" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox39]--><div id="nex_contentbox39" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox40]--><div id="nex_contentbox40" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_contentbox">
                        	<dl>
                            	<!--[diy=nex_contentbox41]--><div id="nex_contentbox41" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_rk_tab ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_rk_part ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
            <div class="nex_index_ads"><!--[diy=nex_contentbox411]--><div id="nex_contentbox411" class="area"></div><!--[/diy]--></div>
        </div>
    </div>
    <!--����VIP-->
    <div class="nex_joinus">
    	<div class="w1180">
        	<div class="nex_toptitle_part nex_fe_top">
            	<h2>JOININ VIP MEMBER</h2>
                <h5><em class="nex_title_decor1"></em><em class="nex_title_decor2"></em>����VIP</h5>
                <p>- �������� 10,700,285 ���ز�ֻ�� 0.13Ԫ/�� -</p>
            </div>
            <div class="nex_mainvip">
                <div class="nex_vip_lbox">
                	<!--[diy=nex_vip_lbox]--><div id="nex_vip_lbox" class="area"></div><!--[/diy]-->
                	
                </div>
                <div class="nex_vip_rbox">
                	<ul>
                    	<li>
                        	<h5><i class="nex_vip_icon1"></i><span>��ʱVIP</span></h5>
                            <div class="nex_vip_price">5<em>Ԫ</em></div>
                            <p>��ʱ���غ��ò���</p>
                            <!--{if $_G['uid']}-->
                            <a href="portal.php?mod=list&catid=7" target="_blank">������ͨ</a>
                            <!--{else}-->
                            <div class="nex_vip_before">���ȵ�¼</div>
                            <!--{/if}-->
                        </li>
                        <li>
                        	<h5><i class="nex_vip_icon2"></i><span>һ��VIP</span></h5>
                            <div class="nex_vip_price">69<em>Ԫ</em></div>
                            <p>365���ز�������</p>
                            <!--{if $_G['uid']}-->
                            <a href="portal.php?mod=list&catid=7" target="_blank">������ͨ</a>
                            <!--{else}-->
                            <div class="nex_vip_before">���ȵ�¼</div>
                            <!--{/if}-->
                        </li>
                        <li>
                        	<h5><i class="nex_vip_icon3"></i><span>����VIP</span></h5>
                            <div class="nex_vip_price">99<em>Ԫ</em></div>
                            <p>һ�θ�����������</p>
                            <!--{if $_G['uid']}-->
                            <a href="portal.php?mod=list&catid=7" target="_blank">������ͨ</a>
                            <!--{else}-->
                            <div class="nex_vip_before">���ȵ�¼</div>
                            <!--{/if}-->
                        </li>
                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <!--��������-->
    <div class="nex_flinkpot">
    	<div class="w1180">
        	<div class="nex_flinktop">
            	<ul>
                	<li class="on">��������</li>
                    <li>�����ز�</li>
                    <li>�Ƽ�ר��</li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_flinkbtm">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_dlinks">
                        	<dl>
                            	<!--[diy=nex_dlinks]--><div id="nex_dlinks" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_dlinks">
                        	<dl>
                            	<!--[diy=nex_dlinks1]--><div id="nex_dlinks1" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_dlinks">
                        	<dl>
                            	<!--[diy=nex_dlinks2]--><div id="nex_dlinks2" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_flinktop ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("on").siblings().removeClass("on");
						jQuery(".nex_flinkbtm ul li").eq(s).show().siblings().hide();
						})
					})
			</script>
            
        </div>
    </div>
    
</div>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

