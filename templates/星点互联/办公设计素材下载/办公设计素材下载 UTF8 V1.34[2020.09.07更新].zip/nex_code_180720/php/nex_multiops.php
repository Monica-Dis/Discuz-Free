<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_attachs = DB::result(DB::query("SELECT attachment FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]'"));
$nex_attnums = substr($thread[tid], -1); $nex_threadlistspic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$thread[tid]' AND isimage = '1' ORDER BY `aid` ASC LIMIT 1");
$nex_Mythreads_conts = DB::result(DB::query("SELECT message FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]'")); $summary_echo = preg_replace ("/\[[a-z][^\]]*\]|\[\/[a-z]+\]/i",'',preg_replace("/\[attach\]\d+\[\/attach\]/i",'',$nex_Mythreads_conts));
$nex_authorid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]'")); $nex_gender = DB::result(DB::query("SELECT gender FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authorid[uid]'"));
$nex_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_occus = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_upids = DB::result(DB::query("SELECT fid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'")); $nex_fromname = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$nex_upids'"));
$nex_blogpic = DB::result(DB::query("SELECT pic FROM ".DB::table('home_blogfield')." WHERE blogid = '$blog[blogid]'"));
$nex_threaddate = DB::result(DB::query("SELECT dateline FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_authoridx = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'")); 
$nex_bbs_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_bbs_occu = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_bbs_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
?>
