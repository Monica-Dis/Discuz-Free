<?php echo 'Copyright@Neoconex星点互联-版权所有';exit;?>
<!--{subtemplate common/header_common}-->

<style type="text/css">
.wp, #wp{ width:100%!important; min-width:1180px;}
#ct{ margin:0!important;}
.nexfooter{ margin-top:0;}
.nex_Searchbox{ display:none;}
.nex_search_bg{ width:100%; min-width:1180px; background:url(template/nex_code_180720/neoconex/search/search_bg.jpg) center no-repeat; padding:40px 0; height:600px;}
.nex_search_logo{ margin-top:100px!important;}
.nex_search_logo img{ height:50px;}
#scform_tb{}
#scform_tb .y a{margin: 0 3px 0 7px!important;}
.nex_search_bg #scform_tb a{ width:60px; margin:0 0 0 5px; height:35px; line-height:29px; overflow:hidden; text-align:center;font-size:14px;color:#fff;  text-align:center;}
.nex_search_bg #scform_tb a.a{ background: -webkit-linear-gradient(left,#ff9000 0,#ff5700 100%); border-radius:4px 4px 0 0;color:#fff; }
.nex_content_search{ padding:90px 0; width:100%; min-width:1180px; background:url(template/nex_code_180720/neoconex/search/search_bg1.jpg) center no-repeat; background-size:cover;}
.nex_content_search #scform_tb a{ width:60px; margin:0 0 0 5px; height:35px; line-height:29px; overflow:hidden; text-align:center;font-size:14px;color:#fff;  text-align:center;}
.nex_content_search #scform_tb a.a{ background: -webkit-linear-gradient(left,#ff9000 0,#ff5700 100%); border-radius:4px 4px 0 0;color:#fff; }
.nex_scarbox{margin:40px auto!important;}
#scform_form{ background:none; border:2px solid #FF5700;}
.td_srchtxt{ background:#fff!important; height:42px; line-height:42px;}
.td_srchbtn{background: -webkit-linear-gradient(left,#ff9000 0,#ff5700 100%)!important; font-size:14px; color:#fff;}
#scform_submit{ font-size:16px; color:#fff; opacity:1!important;background: -webkit-linear-gradient(left,#ff9000 0,#ff5700 100%); font-family:Microsoft Yahei; letter-spacing:2px; font-weight:500; }
.tl{ width:1180px; margin:20px auto;}
#ct .nex_emp_notice{ height:50px; line-height:50px; text-align:center; font-size:18px!important; color:#ff5700; font-weight:500; letter-spacing:2px;}
.nex_search_result{ padding:20px; width:1140px; margin:20px auto!important; border-bottom:0!important; text-align:center; font-size:16px; color:#666; letter-spacing:2px;}

.nex_showresults{ width:1180px;}
.nex_showresults ul{ width:1200px;}
.nex_showresults ul li{ width: 280px; float: left; margin: 0 20px 20px 0; border-radius: 4px; box-shadow: 0 3px 9px rgba(0,0,0,.1); padding-bottom:0!important; -webkit-transition:all 0.3s linear;-moz-transition:all 0.3s linear;-o-transition:all 0.3s linear;-ms-transition:all 0.3s linear;transition:all 0.3s linear;}
.nex_showresults ul li:hover{ box-shadow: 0 2px 10px rgba(0,0,0,0.2); -webkit-transform: translate(0,-2px); -moz-transform: translate(0,-2px); -o-transform: translate(0,-2px); -ms-transform: translate(0,-2px); transform: translate(0,-2px);}
.nex_showpics{ width:270px; height:360px; overflow:hidden;  padding: 5px 5px 0 5px; background: #fff; height: 360px; position: relative; overflow: hidden;}
.nex_showpics a{ display:block; width:270px; height:355px;}
.nex_showinfos{ padding: 5px 20px 20px 20px; background: #fff;}
.nex_showinfos h3{ width: 100%; height: 44px; line-height: 44px; text-align: center; border-bottom: 1px solid #eceff1; text-overflow: ellipsis; white-space: nowrap; overflow: hidden; margin-bottom: 15px;}
.nex_showinfos h3 a{font-size: 14px; color: #252525; font-weight: 400; text-decoration:none;}
.nex_showinfos h3 a:hover{ color:#ff5700;}
.nex_contgyu{ height: 15px; line-height: 15px;}
.nex_contgyu span{ font-size: 14px; color: #838383; height: 15px; line-height: 15px; display: inline-block; padding-left: 22px;}
.nex_contgyu span.nex_download_nums{float: left; background:url(template/nex_code_180720/neoconex/search/down_num.png) left center no-repeat;}
.nex_contgyu span.nex_update_time{float: right; background:url(template/nex_code_180720/neoconex/search/date_up.png) left center no-repeat;}

.nex_showarticles{width:1180px;}
.nex_showarticles ul{ width:1200px;}
.nex_showarticles ul li{float: left;margin: 0 20px 20px 0;box-shadow: 1px 3px 6px rgba(0,0,0,.07); padding-bottom:0;width: 280px;-webkit-transition: all 0.3s linear;-moz-transition: all 0.3s linear;
-o-transition: all 0.3s linear;-ms-transition: all 0.3s linear;transition: all 0.3s linear;}
.nex_showarticles ul li:hover {box-shadow: 3px 5px 15px rgba(0,0,0,0.15);}
.nex_show_article_pics{width: 280px;height: 200px; position:relative;}
.nex_show_article_pics a{display: block;width: 280px;height: 200px; overflow:hidden;}
.nex_search_articlebtm{padding: 20px 20px 15px 20px;background: #fff;}
.nex_search_articlebtm h5{height: 50px;line-height: 25px;overflow: hidden;margin-bottom: 15px;}
.nex_search_articlebtm h5 a{font-size: 16px;color: #333!important;font-weight: 500;letter-spacing: 2px; text-decoration:none;}
.nex_search_articlebtm h5 a:hover{ color:#ff5700!important;}
.nex_search_armid{ height:20px; line-height:20px; margin:10px 0; overflow:hidden;}
.nex_search_armid span{ margin-right:10px; font-size:12px; color:#666;}
.nex_art_sums{height: 72px;line-height: 24px;font-size: 12px;color: #999;overflow: hidden;}
.nex_art_user{ border-top:1px solid #eee; padding-top:10px; margin-top:10px;}
.nex_art_user a{ display:block; float:left;}
.nex_art_user a img{ display:block; width:25px; height:25px; float:left; border-radius:100%;}
.nex_art_user a span{ display:block; float:left; margin-left:10px; height:25px; line-height:25px; font-size:12px; color:#999;}
.nex_art_user a:hover span{ color:#ff5700;}


.nex_blog_list{ width:1180px;}
.nex_blog_list ul{ width:1200px;}
.nex_blog_list ul li{ width:580px; float:left; margin:0 20px 20px 0;}
.nex_blog_pic{ width:150px; height:110px;float:left;}
.nex_blog_pic a{ display:block;width:150px; height:110px;}
.nex_blog_info{ float:right; width:410px;}
.nex_blog_info h3{ max-height:50px; line-height:25px; overflow:hidden; margin-bottom:10px;}
.nex_blog_info h3 a{ font-size:16px; color:#333!important; font-weight:400; text-decoration:none;}
.nex_blog_info h3 a:hover{ color:#ff5700!important;}
.nex_blog_vt{ height:20px; line-height:20px; margin-bottom:10px;}
.nex_blog_vt span{ margin-right:10px; font-size:12px; color:#999; overflow:hidden;}
.nex_blog_btms{ height:20px; line-height:20px; overflow:hidden;}
.nex_blog_btms a{ float:left;}
.nex_blog_btms a img{ width:20px; height:20px; border-radius:100%; float:left;}
.nex_blog_btms a em{ display:block; float:left; margin-left:10px; font-size:12px; color:#666;}
.nex_blog_btms a:hover em{ color:#ff5700;}
.nex_blog_btms span{ display:block; float:left; margin-left:10px; color:#ff5700; font-size:12px;}


.nex_collection_box{ padding:20px 0;width:1180px;}
.nex_collection_box ul{ width:1200px;}
.nex_collection_box ul li{ width:338px; margin:0 20px 20px 0; float:left; padding:20px; border:1px solid #eee; background:#fefefe;}
.nex_collection_box ul li h5{ height:20px; line-height:20px; overflow:hidden; margin-bottom:10px;}
.nex_collection_box ul li h5 a{ font-size:16px; color:#333; font-weight:500; letter-spacing:2px; text-decoration:none;}
.nex_collection_box ul li h5 a:hover{ color:#ff5700;}
.nex_collection_status{ height:20px; line-height:20px; overflow:hidden; font-size:12px; color:#999; margin-bottom:10px;}
.nex_collection_desc{ height:44px; line-height:22px; font-size:12px; color:#666; overflow:hidden;}


.nex_album_list{ margin-top:20px;width:1180px;}
.nex_album_list ul{ width:1255px;}
.nex_album_list ul li{ float:left; width:140px; margin:0 33px 20px 0;}
.nex_album_cover{ width:140px; height:140px; background:url(template/nex_code_180720/neoconex/search/album_cover.png) center no-repeat; background-size:cover; overflow:hidden; position:relative;}
.nex_album_cover img{ display:block; width:120px; height:120px; position:absolute; top:8px; left:8px;}
.nex_album_list ul li h5{ height:30px; line-height:30px; text-align:center; margin:5px 0; overflow:hidden;}
.nex_album_list ul li h5 a{ font-size:14px; color:#666; letter-spacing:2px; font-weight:400;}
.nex_album_list ul li h5 a:hover{ color:#ff5700;}

.nex_view_grouplist,.nex_group_list{ width:1180px; margin:20px auto;}
.nex_group_list{width:1180px;}
.nex_group_list ul{ width:1200px;}
.nex_group_list ul li{ float:left; width:338px; padding:20px; border:1px solid #eee;}
.nex_grouppic_cover{ float:left; width:60px; height:60px;}
.nex_grouppic_cover a{}
.nex_grouppic_cover a img{width:60px; height:60px;}
.nex_group_intels{ float:right; width:258px;}
.nex_group_intels h5{ height:20px; line-height:20px; overflow:hidden; margin-bottom:5px;}
.nex_group_intels h5 a{ font-size:16px; color:#333; font-weight:400;}
.nex_group_intels h5 a:hover{color:#ff5700;}
.nex_group_intels p{ height:20px; line-height:20px; font-size:12px; color:#999; overflow:hidden;}
.nex_groupthreadlist{ width:1180px; margin:20px auto;}
.nex_groupthreadlist ul{ width:1200px;}
.nex_groupthreadlist ul li{ width:280px; float:left; padding-bottom:0!important; margin:0 20px 20px 0;-webkit-transition:all 0.3s linear;-moz-transition:all 0.3s linear;-o-transition:all 0.3s linear;-ms-transition:all 0.3s linear;transition:all 0.3s linear;}
.nex_groupthreadlist ul li:hover{ box-shadow: 0 2px 10px rgba(0,0,0,0.2); -webkit-transform: translate(0,-2px); -moz-transform: translate(0,-2px); -o-transform: translate(0,-2px); -ms-transform: translate(0,-2px); transform: translate(0,-2px);}
.pg a, .pg strong, .pgb a, .pg label {float: left;height: 28px;line-height: 28px;margin-right: 2px;padding: 0 10px;border: 1px solid #eee; overflow: hidden; border-radius: 0;background-repeat: no-repeat; background: #FFFFFF;}
.pg strong { background: #ff5700 ; border-color:#ff5700 ;color: #FFFFFF;}
.pg a.nxt { padding-right: 10px; background: #FFFFFF;}
.pg a.nxt:hover{background: #ff5700 ; color: #FFFFFF;}
.pg a.prev{ background:#fff url(template/nex_code_180720/neoconex/forumlist/arrowleft.png) center no-repeat;}
.pg a.prev:hover{background:#ff5700 url(template/nex_code_180720/neoconex/forumlist/arrowleft1.png) center no-repeat;}

</style>

<body id="nv_search" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<div id="toptb" class="cl" style="display:none;">
		<div class="z">
			<a href="./" id="navs" class="showmenu xi2" onMouseOver="showMenu(this.id)">{lang return_homepage}</a>
		</div>
		<div class="y">
			<!--{if $_G['uid']}-->
				<strong><a href="home.php?mod=space" target="_blank" title="{lang visit_my_space}">{$_G[member][username]}</a></strong>
				<a href="javascript:;" id="myspace" class="showmenu xi2" onMouseOver="showMenu(this.id);">{lang my_nav}</a>
				<!--{hook/global_usernav_extra1}-->
				<a href="home.php?mod=spacecp">{lang setup}</a>
				<!--{if $_G['uid'] && ($_G['group']['radminid'] == 1 || getstatus($_G['member']['allowadmincp'], 1))}--><a href="admin.php" target="_blank">{lang admincp}</a><!--{/if}-->
				<!--{hook/global_usernav_extra2}-->
				<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
			<!--{elseif !empty($_G['cookie']['loginuser'])}-->
				<strong><a id="loginuser"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
				<a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang activation}</a>
				<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
			<!--{else}-->
				<a href="member.php?mod={$_G[setting][regname]}">$_G['setting']['reglinkname']</a>
				<a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang login}</a>
			<!--{/if}-->
		</div>
	</div>
	<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
		<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
		<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
		     <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
		     <li>$module[url]</li>
		     <!--{/if}-->
		<!--{/loop}-->
		</ul>
	<!--{/if}-->
	$_G[setting][menunavs]

	<!--{if $_G['setting']['navs']}-->
		<ul class="p_pop h_pop" id="navs_menu" style="display: none">
		<!--{loop $_G['setting']['navs'] $nav}-->
			<!--{eval $nav_showmenu = strpos($nav['nav'], 'onmouseover="showMenu(');}-->
		    <!--{eval $nav_navshow = strpos($nav['nav'], 'onmouseover="navShow(')}-->
		    <!--{if $nav_hidden !== false || $nav_navshow !== false}-->
			<!--{eval $nav['nav'] = preg_replace("/onmouseover\=\"(.*?)\"/i", '',$nav['nav'])}-->
		    <!--{/if}-->
			<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li $nav[nav]></li><!--{/if}-->
		<!--{/loop}-->
		</ul>
	<!--{/if}-->

	<ul id="myspace_menu" class="p_pop" style="display:none;">
		<!--{loop $_G['setting']['mynavs'] $nav}-->
			<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->
				<li>$nav[code]</li>
			<!--{/if}-->
		<!--{/loop}-->
	</ul>
