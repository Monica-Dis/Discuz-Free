<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<div class="sttl mbn nex_search_result">
		<h2><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($articlelist)}-->
		<p class="emp xg2 xs2 nex_emp_notice">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="slst mtw nex_showarticles">
			<ul>
				<!--{loop $articlelist $article}-->
				<li>
                	<div class="nex_show_article_pics">
                    	<!--{if $article[pic]}-->
                    	<a href="{echo fetch_article_url($article);}" target="_blank" style="background:url($article[pic]) center no-repeat; background-size:cover;"></a>
                        <!--{else}-->
                        <a href="{echo fetch_article_url($article);}" target="_blank" style="background:url($_G['style'][styleimgdir]/search/nopic.jpg) center no-repeat; background-size:cover;"></a>
                        <!--{/if}-->
                    </div>
                    <div class="nex_search_articlebtm">
                    	<h5><a href="{echo fetch_article_url($article);}" target="_blank">$article[title]</a></h5>
                        <div class="nex_search_armid"><span>$article[commentnum] {lang a_comment}</span><span>$article[viewnum] {lang a_visit}</span><span>$article[dateline]</span></div>
                        <div class="nex_art_sums">$article[summary]</div>
                        <div class="nex_art_user">
                        	<a href="home.php?mod=space&uid=$article[uid]" target="_blank">
                            	<img src="uc_server/avatar.php?uid=$article[uid]&size=large">
                                <span>$article[username]</span>
                                <div class="clear"></div>
                            </a>
                            <div class="clear"></div>
                        </div>
                    </div>
                    
				</li>
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>
