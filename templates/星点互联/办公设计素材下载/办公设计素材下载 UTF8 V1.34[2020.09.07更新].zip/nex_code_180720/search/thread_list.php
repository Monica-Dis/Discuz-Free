<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<div class="sttl mbn nex_search_result">
		<h2><!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page" target="_blank">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($threadlist)}-->
		<p class="emp xs2 xg2 nex_emp_notice">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="slst mtw nex_showresults" id="threadlist" {if $modfid} style="position: relative;"{/if}>
			<!--{if $modfid}-->
			<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$modfid&infloat=yes&nopost=yes">
			<!--{/if}-->
			<ul>
				<!--{loop $threadlist $thread}-->
				<li id="$thread[tid]">
                	<!--{eval include 'template/nex_code_180720/php/nex_multiops.php'}-->
                    <!--{if $nex_attachs == '0'}-->
                    <div class="nex_showpics">
                        <img src="$_G['style'][styleimgdir]/search/nopic_cover.jpg" />
                    </div>
                    <!--{else}-->
                    <!--{eval include 'template/nex_code_180720/php/nex_multiops.php'}-->
                    <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
                    <div class="nex_showpics"><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank"  style=" background:url(<!--{if $nex_threadsinpivs['remote']}-->                    			
{$_G['setting']['ftp']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
<!--{else}-->         			
{$_G['setting']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
<!--{/if}-->) center no-repeat; background-size:cover;"></a></div>
                    <!--{/loop}-->
                    <!--{/if}-->
                    <div class="nex_showinfos">
                        <h3><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">$thread[subject]</a></h3>
                        <div class="nex_contgyu">
                            <span class="nex_download_nums">$thread[views]</span>
                            <span class="nex_update_time">$thread[dateline]</span>
                            <div class="clear"></div>
                        </div>
                    </div>
				</li>
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		<!--{if $modfid}-->
			</form>
			<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
			<!--{template forum/topicadmin_modlayer}-->
		<!--{/if}-->
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>
