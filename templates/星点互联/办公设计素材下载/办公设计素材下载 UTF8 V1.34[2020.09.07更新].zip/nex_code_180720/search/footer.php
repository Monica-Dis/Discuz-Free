<?php echo 'Copyright@Neoconex星点互联-版权所有';exit;?>
</div>
<!--{eval $focusid = getfocus_rand($_G[basescript]);}-->
<!--{if $focusid !== null}-->
	<!--{eval $focus = $_G['cache']['focus']['data'][$focusid];}-->
	<div class="focus" id="focus">
		<div class="bm">
			<div class="bm_h cl">
				<a href="javascript:;" onclick="setcookie('nofocus_$focusid', 1, $_G['cache']['focus']['cookie']*3600);$('focus').style.display='none'" class="y" title="{lang close}">{lang close}</a>
				<h2><!--{if $_G['cache']['focus']['title']}-->{$_G['cache']['focus']['title']}<!--{else}-->{lang focus_hottopics}<!--{/if}--></h2>
			</div>
			<div class="bm_c">
				<dl class="xld cl bbda">
					<dt><a href="{$focus['url']}" class="xi2" target="_blank">$focus['subject']</a></dt>
					<!--{if $focus[image]}-->
					<dd class="m"><a href="{$focus['url']}" target="_blank"><img src="{$focus['image']}" alt="$focus['subject']" /></a></dd>
					<!--{/if}-->
					<dd>$focus['summary']</dd>
				</dl>
				<p class="ptn hm"><a href="{$focus['url']}" class="xi2" target="_blank">{lang focus_show} &raquo;</a></p>
			</div>
		</div>
	</div>
<!--{/if}-->

<!--{ad/footerbanner/wp a_f hm/1}--><!--{ad/footerbanner/wp a_f hm/2}--><!--{ad/footerbanner/wp a_f hm/3}-->
<!--{ad/float/a_fl/1}--><!--{ad/float/a_fr/2}-->
<!--{ad/couplebanner/a_fl a_cb/1}--><!--{ad/couplebanner/a_fr a_cb/2}-->

<!--{hook/global_footer}-->
<div class="nexfooter">
    <div class="nexfttop">
        <div class="w1180">
            <div class="nexfttop_L">
                <ul>
                    <li>
                        <h5>常见问题</h5>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">售后服务</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">注册登录</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">帐号/密码</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">充值/售后</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">版权投诉</a></p>
                    </li>
                    <li>
                        <h5>关于我们</h5>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">关于我们</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">媒体报道</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">帮助中心</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">心系星点</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">加入我们</a></p>
                    </li>
                    <li>
                        <h5>产品服务</h5>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">HTML模板代码</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">设计素材</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">jQuery特效</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">PPT办公素材</a></p>
                        <p><a href="http://t.cn/Aiux1012" target="_blank">设计元素</a></p>
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nexfttop_M">
                <div class="nex_ftrightop">关注我们</div>
                <ul>
                    <li>
                        <div class="nex_ftbarcode"><img src="$_G['style'][styleimgdir]/footer/wx.jpg" /></div>
                        <div class="nex_fticondesc">官方微信公众号</div>
                    </li>
                    <li>
                        <div class="nex_ftbarcode"><img src="$_G['style'][styleimgdir]/footer/app.jpg" /></div>
                        <div class="nex_fticondesc">APP应用下载</div>
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nexfttop_R">
                <div class="nex_ftrightop">客服咨询</div>
                <div class="nex_ftconts">
                    <ul>
                        <li class="nex_fttels">400-123-4567<em>(工作日：9:00-16:00)</em></li>
                        <li class="nex_ftemails">enquire@neoconex.com</li>
                    </ul>
                </div>
                <div class="nex_ftqqkf"><a href="tencent://Message/?Uin=$_G['setting']['site_qq']&amp;websiteName=#=&amp;Menu=yes"><i></i>客服咨询</a></div>
            </div>
            <div class="clear"></div>
        </div>	
    </div>
    <div class="nexftbottom">
        <div class="w1180">
            <div class="nexftbtn_L">
                <p>所有资源均是网上搜集或网友上传提供，任何涉及商业盈利目的均不得使用，否则产生的一切后果将由您自己承担。如有侵犯您的版权，请及时发邮件联系我们</p>
                <p>Powered by <a href="https://dism.taobao.com/category-1476983554.htm" target="_blank">DisM!</a> <em>$_G['setting']['version']</em><!--{if !empty($_G['setting']['boardlicensed'])}--> <a href="http://license.comsenz.com/?pid=1&host=$_SERVER[HTTP_HOST]" target="_blank">Licensed</a><!--{/if}-->&nbsp;&copy; 2020-2021 <a href="https://dism.taobao.com/category-1477014018.htm" target="_blank">DisM.Taobao.Com.</a> <em>DisM.Taobao.Com</em> <!--{if $_G['setting']['icp']}-->( <a href="http://www.miitbeian.gov.cn/" target="_blank">$_G['setting']['icp']</a> )<!--{/if}--><!--{hook/global_footerlink}--> <!--{if $_G['setting']['statcode']}-->$_G['setting']['statcode']<!--{/if}--></p>
            </div>
            <div class="nexftbtn_R"><img src="$_G['style'][styleimgdir]/footer/ftlogo.png" /></div>
            <div class="clear"></div>
        </div>
    </div>
</div>
<div id="ft" class="w cl" style="display:none;">
	<em>Powered by <strong><a href="https://dism.taobao.com/category-1476983554.htm" target="_blank">DisM!</a></strong> <em>$_G['setting']['version']</em><!--{if !empty($_G['setting']['boardlicensed'])}--> <a href="http://license.comsenz.com/?pid=1&host=$_SERVER[HTTP_HOST]" target="_blank">Licensed</a><!--{/if}--></em> &nbsp;
	<em>&copy; 2020-2021 <a href="https://dism.taobao.com/category-1477014018.htm" target="_blank">DisM.Taobao.Com.</a></em>
	<span class="pipe">|</span>
	<!--{loop $_G['setting']['footernavs'] $nav}--><!--{if $nav['available'] && ($nav['type'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1)) ||
			!$nav['type'] && ($nav['id'] == 'stat' && $_G['group']['allowstatdata'] || $nav['id'] == 'report' && $_G['uid'] || $nav['id'] == 'archiver'))}-->$nav[code]<span class="pipe">|</span><!--{/if}--><!--{/loop}-->
	<strong><a href="$_G['setting']['siteurl']" target="_blank">$_G['setting']['sitename']</a></strong>
	<!--{if $_G['setting']['icp']}-->( <a href="http://www.miibeian.gov.cn/" target="_blank">$_G['setting']['icp']</a> )<!--{/if}-->
	<!--{hook/global_footerlink}-->
	<!--{if $_G['setting']['statcode']}--><span class="pipe">| $_G['setting']['statcode']</span><!--{/if}-->
	<!--{eval updatesession();}-->
</div>
<!--{if $_G[uid] && !isset($_G['cookie']['checkpm'])}-->
<script language="javascript"  type="text/javascript" src="home.php?mod=spacecp&ac=pm&op=checknewpm&rand=$_G[timestamp]"></script>
<!--{/if}-->
<!--{eval output();}-->
<script type="text/javascript">
function click(e) {
if (document.all) {
if (event.button==2||event.button==3) { alert("支持正版！！！有需求请与管理联系QQ:1691000615！谢谢您的合作！！！");
oncontextmenu='return false';
}
}
if (document.layers) {
if (e.which == 3) {
oncontextmenu='return false';
}
}
}
if (document.layers) {
document.captureEvents(Event.MOUSEDOWN);
}
document.onmousedown=click;
document.oncontextmenu = new Function("return false;")
document.onkeydown =document.onkeyup = document.onkeypress=function(){ 
if(window.event.keyCode == 123) { 
window.event.returnValue=false;
return(false); 
} 
}
</script>
</body>
</html>


