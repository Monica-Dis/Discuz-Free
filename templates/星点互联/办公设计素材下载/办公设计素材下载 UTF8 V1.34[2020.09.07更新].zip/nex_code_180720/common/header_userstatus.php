<?php echo 'From: DisM.taobao.com';exit;?>
<div class="nexlogin">                 
		<!--{if $_G['uid']}-->
        <div class="nexallmember">
            <div id="nexmemberinfo">
                <a class="nexvwmy" href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">
                    <!--{avatar($_G[uid],small)}-->
                    <span>{$_G[member][username]}</span>
                    <i></i>
                    <div class="clear"></div>
                </a>
            </div>
            <div id="nexmembercontent">
            	<!--{eval include 'template/nex_code_180720/php/nex_users.php'}-->
            	<i></i>
                <div class="nexmembercontent_Top">
                	<b></b>
                	<div class="nexmembercontent_Top_left">
                    	<div class="nexmemberavator"><!--{avatar($_G[uid],big)}--></div>
                        <div class="nexmemberintels">
                        	<h5>{$_G[member][username]}</h5>
                            <p>ID：{$nex_userid}</p>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="nexmembercontent_Top_right">
                    	<!--{if check_diy_perm($topic)}-->$diynav<em></em><!--{/if}-->
                    	<a href="home.php?mod=spacecp&ac=avatar" title="个人设置" target="_blank">设置</a>
                        <em></em>
                        <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">退出</a>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nexmembercontent_Mid">
                	<div class="nexmemberinfos">
                        <ul>
                            <li class="nexmemberinfosones">
                                <!--{if $nex_province == '' && $nex_adds == ''}-->
                                <p>未知地区</p>
                                <!--{else}-->
                                <p>{$nex_province}{$nex_adds}</p>
                                <!--{/if}-->
                                <div class="nexmemberinfoterms">所在地</div>
                            </li>
                            <li class="nexmemberinfostwos">
                                <!--{if $nex_occu == ''}-->
                                <p>未填写</p>
                                <!--{else}-->
                                <p>{$nex_occu}</p>
                                <!--{/if}-->
                                <div class="nexmemberinfoterms">职业</div>
                            </li>
                            <li class="nexmemberinfosthrees">
                            	<p>$_G[member][credits]</p>
                                <div class="nexmemberinfoterms">积分</div>
                                
                            </li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nexmemberinfobtn"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">{lang visit_my_space}</a></div>
                </div>
                <div class="nexmembercontent_Btm">
                	<ul>
                        <li class="nexnewinfo">
                            <a href="home.php?mod=space&do=pm&filter=newpm" target="_blank">
                                <span class="nex_icon1">
                                    <!--{if $_G[member][newpm]}-->
                                    <em><b>{$_G[member][newpm]}</b></em>
                                    <!--{elseif $_G[member][newprompt]}-->
                                    <em><b>{$_G[member][newprompt]}</b></em>
                                    <!--{/if}-->
                                </span>
                                <p>消息</p>
                            </a>
                        </li>
                        <li class="nexatme">
                            <a href="home.php?mod=space&do=notice" target="_blank">
                                <span class="nex_icon2">
                                    <!--{if $_G[member][newprompt]}--><em><b>$_G[member][newprompt]</b></em><!--{/if}-->
                                </span>
                                <p>通知</p>
                            </a>
                        </li>
                        <li class="nexmypost">
                            <a href="forum.php?mod=guide&view=my" target="_blank">
                                <span class="nex_icon3"></span>
                                <p>帖子</p>
                            </a>								
                        </li>
                        <li class="nexhuifume">
                            <a class="" href="home.php?mod=space&amp;do=notice&amp;type=post&amp;isread=$_G[uid]" target="_blank">
                                <span class="nex_icon4"></span>
                                <p>回复</p>
                            </a>							
                        </li>
                        <li class="nexmycollection">
                            <a href="home.php?mod=space&do=favorite&view=me" target="_blank">
                                <span class="nex_icon5"></span>
                                <p>收藏</p>
                            </a>
                        </li>
                        
                        <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
                        <li class="nexfriend">
                            <a class="nexguanli" href="admin.php" target="_blank">
                                <span class="nex_icon7"></span>
                                <p>管理</p>
                            </a>
                        </li>
                        <!--{/if}-->
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="nexmem_M_btms">
                    <!--{hook/global_usernav_extra1}--><!--{hook/global_usernav_extra2}--><!--{hook/global_usernav_extra3}--><!--{hook/global_usernav_extra4}-->
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
                
            </div>
            <script type="text/javascript">
                jQuery("#nexmemberinfo").hover(
                    function(){
                        jQuery(this).siblings("#nexmembercontent").show();
                        },
                    function(){
                        jQuery(this).siblings("#nexmembercontent").hide();
                        })
                jQuery("#nexmembercontent").hover(
                    function(){
                        jQuery(this).show();
                        jQuery(this).siblings("#nexmemberinfo").addClass("nex_curs");
                        },
                    function(){
                        jQuery(this).hide();
                        jQuery(this).siblings("#nexmemberinfo").removeClass("nex_curs");
                        })
            </script>
        </div>
   		<ul>
     	<!--{elseif !empty($_G['cookie']['loginuser'])}-->
            <li><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></li>
            <li><a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang activation}</a></li>
            <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
    	<!--{elseif !$_G[connectguest]}-->
        	<div class="nexmain_dls">
                <div class="nexDL_before">
                    <div class="nexDL_unknown"><img src="$_G['style'][styleimgdir]/top/admin.png" /></div>
                    <div class="clear"></div>
                    <i></i>
                </div>
                <div class="nexbd_mains">
                    <em></em>
                    <div class="nexbd_Iner">
                    	<div class="nexbd_Ineravt"><img src="$_G['style'][styleimgdir]/top/admin.png" /></div>
                        <div class="nexbd_welcome">游客您好</div>
                        <div class="nexbd_DLplace">
                        	<ul>
                            	<h4>已有账号？</h4>
                            	<li class="nexbdLogin"><a href="member.php?mod=logging&action=login">登陆账号</a></li>
                                <h4>注册后更精彩</h4>
                                <li class="nexbdRegs"><a href="member.php?mod={$_G[setting][regname]}">立即注册</a></li>
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="nexbdthirdparts"><i class="nex_lineleft"></i><span>第三方账号登陆</span><i class="nex_lineright"></i></div>
                        <div class="nexbdthirdlogins">
                        	<ul>
                            	<li>
                                	<a href="#">
                                    	<img src="$_G['style'][styleimgdir]/top/third_qq.png" />
                                        <p>QQ登陆</p>
                                    </a>
                                </li>
                                <li>
                                	<a href="#">
                                    	<img src="$_G['style'][styleimgdir]/top/third_weixin.png" />
                                        <p>微信登陆</p>
                                    </a>
                                </li>
                                <li>
                                	<a href="#">
                                    	<img src="$_G['style'][styleimgdir]/top/third_weibo.png" />
                                        <p>微博登陆</p>
                                    </a>
                                </li>
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
                <script type="text/javascript">
                    jQuery(".nexDL_before").hover(
                        function(){
                            jQuery(this).siblings(".nexbd_mains").show();
                            },
                        function(){
                            jQuery(this).siblings(".nexbd_mains").hide();
                            })
                    jQuery(".nexbd_mains").hover(
                        function(){
                            jQuery(this).show();
                            jQuery(this).siblings(".nexDL_before").addClass("nexuppers");
                            },
                        function(){
                            jQuery(this).hide();
                            jQuery(this).siblings(".nexDL_before").removeClass("nexuppers");
                            })
                </script>
            </div>
            
     	<!--{else}-->
            <div class="nex_qq_kuang">
                <div class="nex_qq_kuang_before">QQ资料</div>
                <div class="nex_qq_kuang_after">
                    <div id="um">
                        <div class="avt y"><!--{avatar(0,small)}--></div>
                        <div class="nex_qq_lines">
                            <strong class="vwmy qq">{$_G[member][username]}</strong>
                            <!--{hook/global_usernav_extra1}-->
                            <span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
                        </div>
                        <div class="nex_qq_lines">
                            <a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a>
                            <span class="pipe">|</span>{lang usergroup}: $_G[group][grouptitle]
                        </div>
                    </div>
                </div>
                <script type="text/javascript">
                    jq(".nex_qq_kuang").hover(
                        function(){
                            jq(this).children(".nex_qq_kuang_after").show();
                            },
                        function(){
                            jq(this).children(".nex_qq_kuang_after").hide();
                            })
                    
                </script>
            </div>
        <!--{/if}-->
    	</ul>
</div>
