<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header_index}-->
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <!--index_main-->
	<div class="nex_displacement">
    	<div class="w1240">
        	<div class="nex_displacement_l">
            	<div class="nex_displacement_focusBox">
                	<!--[diy=nex_displacement_focusBox]--><div id="nex_displacement_focusBox" class="area"></div><!--[/diy]-->
                    
                    <a class="prev" href="javascript:void(0)"></a>
                    <a class="next" href="javascript:void(0)"></a>
                    <ul class="hd">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                    </ul>
                </div>
            
                <script type="text/javascript">
                    jQuery(".nex_displacement_focusBox").slide({ mainCell:".pic",effect:"left", autoPlay:true, delayTime:600,interTime:5000});
                </script>
                <div class="nex_the_latest_news">
                	<div class="nex_the_latest_news_icon"></div>
                    <div class="nex_the_latest_news_list">
                    	<!--[diy=nex_the_latest_news_list]--><div id="nex_the_latest_news_list" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_the_latest_news_more"><a href="http://t.cn/Aiux1Qh0" target="_blank" title="更多快讯"></a></div>
                    <div class="clear"></div>
                </div>
                <script type="text/javascript">
                	jQuery(".nex_the_latest_news_list").slide({ mainCell:"ul", effect:"topLoop", vis:2, opp:true, autoPlay:true, delayTime:600,interTime:5000 });
                </script>
            </div>
            <div class="nex_displacement_m">
            	<ul>
                	<!--[diy=nex_displacement_m]--><div id="nex_displacement_m" class="area"></div><!--[/diy]-->
                    
                </ul>
            </div>
            
            <div class="nex_displacement_r">
                <div class="nex_displacement_r_rk">
                	<div class="nex_displacement_r_rk_title"><span></span></div>
                    <div class="nex_displacement_rklist">
                    	<ul>
                        	<!--[diy=nex_displacement_rklist]--><div id="nex_displacement_rklist" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    
    <div class="nex_rt_local">
    	<div class="w1240">
            <!--mid_bd-->
            <div class="nex_mid_bd">
            	<div class="nex_mid_bd_l">
                    <!--新项目资讯-->
                    <div class="nex_finance_new_project">
                    	<div class="nex_finance_news_title">
                        	<span>新项目资讯</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="更多新项目资讯"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_new_project">
                        	<ul>
                            	<!--[diy=nex_new_project]--><div id="nex_new_project" class="area"></div><!--[/diy]-->
                                
                                
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </div>
                    <!--ads1-->
                	<div class="nex_finance_ads"><!--[diy=nex_finance_ads]--><div id="nex_finance_ads" class="area"></div><!--[/diy]--></div>
                    <!--列表-->
                    <div class="nex_finance_news">
                    	<div class="nex_finance_news_title">
                        	<span>区块资讯</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="更多区块资讯"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_finance_news_list">
                            <ul>
                            	<!--[diy=nex_finance_news_list]--><div id="nex_finance_news_list" class="area"></div><!--[/diy]-->
                                
                            </ul>
                        </div>
                        <div class="jquery_pagnation"></div>
						<script type="text/javascript">
                            (function(dfsj_jq){
                                var dfsj_items = dfsj_jq('.nex_finance_news_list li');
                                var dfsj_items2 = 18;//每页显示数量；
                                var total = dfsj_items.size();
                                total>0 && dfsj_jq('.jquery_pagnation').pagination({pagetotal:total,target:dfsj_items,perpage:dfsj_items2});
                                })(jQuery);
                        </script>
                    </div>
                    
                </div>
                <div class="nex_mid_bd_r">
                	<!--关注-->
                    <div class="nex_side_focus">
                    	<div class="nex_side_focus_top">
                        	<ul>
                            	<li class="on">官方微信</li>
                                <li>APP下载</li>
                                <li>联系我们</li>
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="nex_side_focus_btm">
                        	<ul>
                            	<li style="display:block;">
                                	<div class="nex_side_focus_inner nex_side_focus_bg1">
                                    	<!--[diy=nex_side_focus_bg1]--><div id="nex_side_focus_bg1" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                </li>
                                <li>
                                	<div class="nex_side_focus_inner nex_side_focus_bg2">
                                    	<!--[diy=nex_side_focus_bg2]--><div id="nex_side_focus_bg2" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                </li>
                                <li>
                                	<div class="nex_side_focus_inner nex_side_focus_bg3">
                                    	<!--[diy=nex_side_focus_bg3]--><div id="nex_side_focus_bg3" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                </li>
                            </ul>
                        
                        </div>
                        <script type="text/javascript">
							jQuery(".nex_side_focus_top ul li").each(function(s){
								jQuery(this).click(function(){
									jQuery(this).addClass("on").siblings().removeClass("on");
									jQuery(".nex_side_focus_btm ul li").eq(s).show().siblings().hide();
									})
								})
						</script>
                    </div>
                    <!--资讯解读-->
                    <div class="nex_mid_bd_side">
                    	<div class="nex_mid_bd_side_title">
                        	<span>资讯解读</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="更多资讯解读"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_zx_analysis">
                        	<ul>
                            	<!--[diy=nex_zx_analysis]--><div id="nex_zx_analysis" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                    <!--市场行情-->
                    <div class="nex_mid_bd_side">
                    	<div class="nex_mid_bd_side_title">
                        	<span>行情动态</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="更多行情动态"></a>
                            <div class="clear"></div>
                        </div>
                        
                        <div class="nex_market_place_box">
                        	<!--[diy=nex_market_place_box]--><div id="nex_market_place_box" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <script type="text/javascript">	
						  jQuery(".nex_market_place_box").slide({ mainCell:"ul", effect:"topLoop", vis:4, opp:true, autoPlay:true, delayTime:800 });
					 </script>
                    </div>
                    <!--行业动态-->
                    <div class="nex_mid_bd_side">
                    	<div class="nex_mid_bd_side_title">
                        	<span>行业动态</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="更多行业动态"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_industrial_list">
                        	<ul>
                            	<!--[diy=nex_industrial_list]--><div id="nex_industrial_list" class="area"></div><!--[/diy]-->
                                
                                
                            </ul>
                        </div>
                    </div>
                    <!--侧边广告位-->
                    <div class="nex_side_ads">
                    	<!--[diy=nex_side_ads]--><div id="nex_side_ads" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <!--热门资讯排行-->
                    <div class="nex_mid_bd_side">
                    	<div class="nex_mid_bd_side_title">
                        	<span>热门排行</span>
                            <ul>
                            	<li class="on">日排行榜</li>
                                <li>周排行榜</li>
                                <div class="clear"></div>
                            </ul>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_zx_rk">
                        	<ul>
                            	<li style="display:block;">
                                	<div class="nex_zx_rk_list">
                                    	<dl>
                                        	<!--[diy=nex_zx_rk_list1]--><div id="nex_zx_rk_list1" class="area"></div><!--[/diy]-->
                                        	
                                        </dl>
                                    </div>
                                </li>
                                <li>
                                	<div class="nex_zx_rk_list">
                                    	<dl>
                                        	<!--[diy=nex_zx_rk_list12]--><div id="nex_zx_rk_list12" class="area"></div><!--[/diy]-->
                                        	
                                        </dl>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <script type="text/javascript">
							jQuery(".nex_mid_bd_side_title ul li").each(function(s){
								jQuery(this).click(function(){
									jQuery(this).addClass("on").siblings().removeClass("on");
									jQuery(".nex_zx_rk ul li").eq(s).show().siblings().hide();
									})
								});
							jQuery(".nex_zx_rk_list dl dd").each(function(s){
								jQuery(this).hover(function(){
									jQuery(this).addClass("curr").siblings().removeClass("curr");
									})
								});
						</script>
                    </div>
                    <!--标签云-->
                    <div class="nex_cloud_tag">
                    	<div class="nex_mid_bd_side_title">
                        	<span>标签云</span>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_cloud_tag_inter">
                        	<!--门户标签云内部调用接口-->
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">Banana-Pi</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">分布式技术</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">DEXON</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">TokenInsight</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">货币量</a>
                            <a class="nex_fz_4" href="http://t.cn/Aiux1Qh0" target="_blank">POSEIDON</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">PoS共识</a>
                            <a class="nex_fz_5" href="http://t.cn/Aiux1Qh0" target="_blank">电子表格</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">科学区块链</a>
                            <a class="nex_fz_3" href="http://t.cn/Aiux1Qh0" target="_blank">Bloxberg</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">涡轮网络</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">VolumeNetwork</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">区块链用户</a>
                            <a class="nex_fz_5" href="http://t.cn/Aiux1Qh0" target="_blank">Binance</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">蚂蚁矿机</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">跨链交互</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">Cobo金库</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">LadderNetwork</a>
                            <a class="nex_fz_3" href="http://t.cn/Aiux1Qh0" target="_blank">分布式文件系统</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">无状态客户端</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">ArcBlock</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">Wright</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">跨侧链</a>
                            <a class="nex_fz_4" href="http://t.cn/Aiux1Qh0" target="_blank">网络安全</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">开放式金融</a>
                            <a class="nex_fz_4" href="http://t.cn/Aiux1Qh0" target="_blank">以太坊</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">ABT</a>
                            <a class="nex_fz_5" href="http://t.cn/Aiux1Qh0" target="_blank">Reserve</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">莱特币矿机</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">比特币混合</a>
                        </div>
                    </div>
                    <script type="text/javascript">
						tagcloud({
							selector: ".nex_cloud_tag_inter",  //元素选择器
							fontsize: 16,       //基本字体大小, 单位px
							radius: 90,         //滚动半径, 单位px 页面宽度和高度的五分之一
							mspeed: "slow",   //滚动最大速度, 取值: slow, normal(默认), fast
							ispeed: "slow",   //滚动初速度, 取值: slow, normal(默认), fast
							direction: 135,     //初始滚动方向, 取值角度(顺时针360): 0对应top, 90对应left, 135对应right-bottom(默认)...
							keep: false          //鼠标移出组件后是否继续随鼠标滚动, 取值: false, true(默认) 对应 减速至初速度滚动, 随鼠标滚动
						});
					</script>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads"><!--[diy=nex_index_ads2]--><div id="nex_index_ads2" class="area"></div><!--[/diy]--></div>
            <!--intel sort-->
            <div class="nex_blockchain_sort">
            	<div class="nex_finance_news_title">
                    <span>区块产业</span>
                    <ul>
                    	<li class="cur">实战操作</li>
                        <li>技术分享</li>
                        <li>知识百科</li>
                        <li>新手入门</li>
                        <li>展会活动</li>
                        <div class="clear"></div>
                    </ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank" title="更多区块产业资讯"></a>
                    <div class="clear"></div>
                </div>
            	<div class="nex_technic_block">
                	<div class="nex_technic_block_l">
                    	<!--bbs broadcast-->
                        <div class="nex_technic_block_title">论坛热议</div>
                        <div class="nex_technic_block_list">
                        	<!--[diy=nex_technic_block_list]--><div id="nex_technic_block_list" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <script type="text/javascript">
							jQuery(".nex_technic_block_list").slide({ mainCell:"ul", effect:"topLoop", vis:3, opp:true, autoPlay:true, delayTime:600,interTime:5000 });
						</script>
                        <div class="nex_bbs_btms">
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">更多热帖</a>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">进入论坛</a>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nex_technic_block_r">
                    	<dl>
                        	<dd style="display:block;">
                            	<div class="nex_technic_sort1">
                                	<ul>
                                    	<!--[diy=nex_technic_sort1]--><div id="nex_technic_sort1" class="area"></div><!--[/diy]-->
                                    	
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                            <dd>
                            	<div class="nex_technic_sort4">
                                	<ul>
                                    	<!--[diy=nex_technic_sort5]--><div id="nex_technic_sort5" class="area"></div><!--[/diy]-->
                                        
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                            <dd>
                            	<div class="nex_technic_sort2">
                                	<ul>
                                    	<!--[diy=nex_technic_sort51]--><div id="nex_technic_sort51" class="area"></div><!--[/diy]-->
                                    	
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                            <dd>
                            	<div class="nex_technic_sort1">
                                	<ul>
                                    	<!--[diy=nex_technic_sort6]--><div id="nex_technic_sort6" class="area"></div><!--[/diy]-->
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                            <dd>
                            	<div class="nex_technic_sort3">
                                	<ul>
                                    	<!--[diy=nex_technic_sort7]--><div id="nex_technic_sort7" class="area"></div><!--[/diy]-->
                                    	
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                        </dl>
                    </div>
                    <div class="clear"></div>
                </div>
                <script type="text/javascript">
					jQuery(".nex_finance_news_title ul li").each(function(a){
						jQuery(this).click(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_technic_block_r dl dd").eq(a).show().siblings().hide();
							})
						})
				</script>
            </div>
            
        </div>
    </div>
    <div class="nex_chain_video_box">
    	<div class="nex_chain_study">
        	<div class="nex_finance_news_title nex_finance_news_title_acadamy">
                <span>区块财经学院</span>
                <ul>
                    <li class="cur">实操VIP课程</li>
                    <li>大咖公益课</li>
                    <div class="clear"></div>
                </ul>
                <a href="http://t.cn/Aiux1Qh0" target="_blank" title="更多区块视频课程"></a>
                <div class="clear"></div>
            </div>
            <div class="nex_video_switch">
            	<dl>
                	<dd style="display:block;">
                    	<div class="nex_acadamy_units">
                        	<ul>
                            	<!--[diy=nex_acadamy_units]--><div id="nex_acadamy_units" class="area"></div><!--[/diy]-->
                            	
                                
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_acadamy_units">
                        	<ul>
                            	<!--[diy=nex_acadamy_unit]--><div id="nex_acadamy_unit" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                </dl>
            </div>
        	
            <script type="text/javascript">
				jQuery(".nex_finance_news_title_acadamy ul li").each(function(c){
					jQuery(this).click(function(){
						jQuery(this).addClass("cur").siblings().removeClass("cur");
						jQuery(".nex_video_switch dl dd").eq(c).show().siblings().hide();
						})
					})
			</script>
        </div>
    </div>
    <div class="nex_fl_box">
    	<div class="w1240">
        	<div class="nex_fl_bd">
            	<div class="nex_btmfooter_title">
                    <ul>
                    	<li class="on">战略合作媒体</li>
                        <li>货币交易所</li>
                        <div class="clear"></div>
                    </ul>
                    <div class="clear"></div>
                </div>
                <div class="nex_fl_btms">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_globle_coorperation">
                            	<dl>
                                	<!--[diy=nex_globle_coorperation]--><div id="nex_globle_coorperation" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_globle_coorperation nex_globle_exchange">
                            	<dl>
                                	<!--[diy=nex_globle_exchange]--><div id="nex_globle_exchange" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>        
                        	
                        </li>
                    </ul>
                </div>
                
				<script type="text/javascript">
                    jQuery(".nex_btmfooter_title ul li").each(function(s){
                        jQuery(this).click(function(){
                            jQuery(this).addClass("on").siblings().removeClass("on");
                            jQuery(".nex_fl_btms ul li").eq(s).show().siblings().hide();
                            })
                        })
                </script>
                <div class="nex_finance_news_title">
                    <span>友情链接</span>
                    <a href="tencent://Message/?Uin=填写你的QQ号码&websiteName=#=&Menu=yes" title="交换友情链接请联系QQ号码"></a>
                    <div class="clear"></div>
                </div>
                <div class="nex_fl_links">
                	<ul>
                    	<!--[diy=nex_fl_links]--><div id="nex_fl_links" class="area"></div><!--[/diy]-->
                    
                    	<div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
</div>    
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->


