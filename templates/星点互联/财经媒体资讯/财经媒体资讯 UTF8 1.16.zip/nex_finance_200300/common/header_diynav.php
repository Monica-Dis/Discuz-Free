<?php echo 'Copyright@Neoconex星点互联-版权所有';exit;?>
<!--{block diynav}-->
		<a id="diy-tg" href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" title="{lang open_diy}" >
        	<span class="nex_icon0"></span>
            <p>DIY</p>
        </a>
<!--{/block}-->
