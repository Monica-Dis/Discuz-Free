<?php echo 'From: DisM.taobao.com';exit;?>
<!--{subtemplate common/header_common}-->
	<meta name="application-name" content="$_G['setting']['bbname']" />
	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
	<!--{/if}-->
	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
	<!--{if widthauto()}-->
		<link rel="stylesheet" id="css_widthauto" type="text/css" href="data/cache/style_{STYLEID}_widthauto.css?{VERHASH}" />
		<script type="text/javascript">HTMLNODE.className += ' widthauto'</script>
	<!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'portal'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
	<link rel="stylesheet" type="text/css" id="diy_common" href="data/cache/style_{STYLEID}_css_diy.css?{VERHASH}" />
	<!--{/if}-->
	<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery1.8.3.min.js"></script>

    <script type="text/javascript">
    	var jq=jQuery.noConflict();
    </script>
    <script language="javascript" type="text/javascript">
		function killErrors() {
		return true;
		}
		window.onerror = killErrors;
    </script>
	<script src="$_G['style'][styleimgdir]/js/nexactions.min.js"></script>
    <link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/js/animate.min.css">
    <script>
    var wow = new WOW({boxClass: 'nexactions',});wow.init();
    </script>
    <script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.SuperSlide.2.1.3.js"></script>
    <script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.pagnation.js"></script>
    <script type="text/javascript">
		jQuery(function(){
		jQuery('#nexGoToTop').click(function(){jQuery('html,body').animate({scrollTop:jQuery('#nextopsxx').offset().top}, 600);});})
    </script>
    <link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/style.css">
	<script src="$_G['style'][styleimgdir]/js/nex_bubble.js"></script>
	
</head>

<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if}" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<!--{template common/header_diy}-->
	<!--{/if}-->
	<!--{if check_diy_perm($topic)}-->
		<!--{template common/header_diynav}-->
	<!--{/if}-->
	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
		$diynav
	<!--{/if}-->
	<!--{if empty($topic) || $topic['useheader']}-->
		<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
			<div class="xi1 bm bm_c">
			    {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a>
			</div>
		<!--{/if}-->
		<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
			<div id="shortcut">
				<span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span>
				{lang shortcut_notice}
				<a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a>

			</div>
			<script type="text/javascript">setTimeout(setShortcut, 2000);</script>
		<!--{/if}-->
		<div id="toptb" class="cl" style="display:none;">
			<!--{hook/global_cpnav_top}-->
			<div class="wp">
				<div class="z">
					<!--{loop $_G['setting']['topnavs'][0] $nav}-->
						<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
					<!--{/loop}-->
					<!--{hook/global_cpnav_extra1}-->
				</div>
				<div class="y">
					<!--{hook/global_cpnav_extra2}-->
				</div>
                <div class="clear"></div>
			</div>
		</div>
		<div class="nex_plugin_reserved">
			<!--{hook/global_cpnav_top}-->
			<div class="w1240">
				<div class="z">
					<!--{hook/global_cpnav_extra1}-->
				</div>
				<div class="y">
					<!--{hook/global_cpnav_extra2}-->
				</div>
                <div class="clear"></div>
			</div>
		</div>
		<!--{if !IS_ROBOT}-->
			<!--{if $_G['uid']}-->
			<ul id="myprompt_menu" class="p_pop" style="display: none;">
				<li><a href="home.php?mod=space&do=pm" id="pm_ntc" style="background-repeat: no-repeat; background-position: 0 50%;"><em class="prompt_news{if empty($_G[member][newpm])}_0{/if}"></em>{lang pm_center}</a></li>

					<li><a href="home.php?mod=follow&do=follower"><em class="prompt_follower{if empty($_G[member][newprompt_num][follower])}_0{/if}"></em><!--{lang notice_interactive_follower}-->{if $_G[member][newprompt_num][follower]}($_G[member][newprompt_num][follower]){/if}</a></li>

				<!--{if $_G[member][newprompt] && $_G[member][newprompt_num][follow]}-->
					<li><a href="home.php?mod=follow"><em class="prompt_concern"></em><!--{lang notice_interactive_follow}-->($_G[member][newprompt_num][follow])</a></li>
				<!--{/if}-->
				<!--{if $_G[member][newprompt]}-->
					<!--{loop $_G['member']['category_num'] $key $val}-->
						<li><a href="home.php?mod=space&do=notice&view=$key"><em class="notice_$key"></em><!--{echo lang('template', 'notice_'.$key)}-->(<span class="rq">$val</span>)</a></li>
					<!--{/loop}-->
				<!--{/if}-->
				<!--{if empty($_G['cookie']['ignore_notice'])}-->
				<li class="ignore_noticeli"><a href="javascript:;" onClick="setcookie('ignore_notice', 1);hideMenu('myprompt_menu')" title="{lang temporarily_to_remind}"><em class="ignore_notice"></em></a></li>
				<!--{/if}-->
				</ul>
			<!--{/if}-->
			<!--{if $_G['uid'] && !empty($_G['style']['extstyle'])}-->
				<div id="sslct_menu" class="cl p_pop" style="display: none;">
					<!--{if !$_G[style][defaultextstyle]}--><span class="sslct_btn" onClick="extstyle('')" title="{lang default}"><i></i></span><!--{/if}-->
					<!--{loop $_G['style']['extstyle'] $extstyle}-->
						<span class="sslct_btn" onClick="extstyle('$extstyle[0]')" title="$extstyle[1]"><i style='background:$extstyle[2]'></i></span>
					<!--{/loop}-->
				</div>
			<!--{/if}-->
            <!--{if $_G['uid']}-->
				<ul id="myitem_menu" class="p_pop" style="display: none;">
					<li><a href="forum.php?mod=guide&view=my">{lang mypost}</a></li>
					<li><a href="home.php?mod=space&do=favorite&view=me">{lang favorite}</a></li>
					<li><a href="home.php?mod=space&do=friend">{lang friends}</a></li>
					<!--{hook/global_myitem_extra}-->
				</ul>
			<!--{/if}-->
			<!--{subtemplate common/header_qmenu}-->
		<!--{/if}-->

		<!--{ad/headerbanner/wp a_h}-->
		<div id="hd" class="nex_hd_common">
        	<div id="nextopsxx"></div>
            <div class="nex_fully_top">
            	<div class="nex_fully_bg">
                	<div class="nex_fully_bg_img1"><img src="$_G['style'][styleimgdir]/index/bg_item1.png"></div>
                    <div class="nex_fully_bg_img2"><img src="$_G['style'][styleimgdir]/index/bg_item2.png"></div>
                    <div class="nex_fully_bg_img3"><img src="$_G['style'][styleimgdir]/index/bg_item3.png"></div>
                    <div class="nex_fully_bg_img4"><img src="$_G['style'][styleimgdir]/index/bg_item1.png"></div>
                    <div class="nex_fully_bg_img5"><img src="$_G['style'][styleimgdir]/index/bg_item1.png"></div>
                </div>
                <div class="nex_waveBox">
                    <canvas id="myCanvas1" height="200"></canvas>
                    <canvas id="myCanvas2" height="200"></canvas>
                    <canvas id="myCanvas3" height="200"></canvas>
                </div>
                <script type="text/javascript">
                (function () {
                    wave2();wave3();
                })();
                
                    params = {
                        ctx :  document.getElementById("myCanvas1"),
                        waveHeight:20,//波浪高度
                        waveCount:6,//波浪个数
                        progress:100,//波浪位置的高度
                        // fillStyle:'#95cef7', //颜色
                        fillStyle:'rgba(255, 255, 255, 0.6)', //颜色
                    }
                    DrawBall(params)
                function DrawBall (Params){
                    var waveWidth = 3300, offset = 0, startX = -1000, startY = 200,   //canvas 高度
                    d2 = waveWidth / Params.waveCount,d = d2 / 2, hd = d / 2;
                    Params.ctx.width = 2560
                    ctx = Params.ctx.getContext("2d");
                    function tick() {
                        offset -= 5;
                        if (-1 * offset === d2) offset = 0;
                        ctx.clearRect(0, 0, Params.ctx.width, Params.ctx.height);
                        ctx.fillStyle = Params.fillStyle;  
                        ctx.beginPath();
                        var offsetY = startY - Params.progress;
                        ctx.moveTo(startX - offset, offsetY);
                        for (var i = 0; i < Params.waveCount; i++) {
                            var dx = i * d2;
                            var offsetX = dx + startX - offset;
                            ctx.quadraticCurveTo(offsetX + hd, offsetY + Params.waveHeight, offsetX + d, offsetY);
                            ctx.quadraticCurveTo(offsetX + hd + d, offsetY - Params.waveHeight, offsetX + d2, offsetY);
                        }
                        ctx.lineTo(startX + waveWidth, 5000);
                        ctx.lineTo(startX, 5000);
                        ctx.fill();
                        requestAnimationFrame(tick);
                    }
                    tick();
                }
                 /* 第二条 */
                function wave2(){
                    var waveWidthB = 3300,
                    offsetB = 0,
                    waveHeightB = 15,  //波浪高度
                    waveCountB = 5,  //波浪个数
                    startXB = -1000,
                    startYB = 200,   //canvas 高度
                    progressB = 90,  //波浪位置的高度
                    d2B = waveWidthB / waveCountB,
                    dB = d2B / 2,
                    hdB = dB / 2,
                    cB = document.getElementById("myCanvas2");
                    cB.width = 2560
                    ctxB = cB.getContext("2d");
                    function tickB() {
                        offsetB -= 5;
                        if (-1 * offsetB === d2B) offsetB = 0;
                        ctxB.clearRect(0, 0, cB.width, cB.height);
                        ctxB.fillStyle = 'rgba(255, 255, 255, 0.8)';  
                        ctxB.beginPath();
                        var offsetYB = startYB - progressB;  
                        ctxB.moveTo(startXB - offsetB, offsetYB);
                        for (var i = 0; i < waveCountB; i++) {
                            var dxB = i * d2B;
                            var offsetXB = dxB + startXB - offsetB;
                            ctxB.quadraticCurveTo(offsetXB + hdB, offsetYB + waveHeightB, offsetXB + dB, offsetYB);
                            ctxB.quadraticCurveTo(offsetXB + hdB + dB, offsetYB - waveHeightB, offsetXB + d2B, offsetYB);
                        }
                        ctxB.lineTo(startXB + waveWidthB, 5000);
                        ctxB.lineTo(startXB, 5000);
                        ctxB.fill();
                        // setTimeout(tickB,5000 / 60); //速度
                        requestAnimationFrame(tickB);
                    }
                    tickB();
                }
                 /* 第三条 */
                function wave3(){
                    var waveWidthC = 3300,
                    offsetC = 0,
                    waveHeightC = 30,  //波浪高度
                    waveCountC = 4,  //波浪个数
                    startXC = -1000,
                    startYC = 200,   //canvas 高度
                    progressC = 100,  //波浪位置的高度
                    d2C = waveWidthC / waveCountC,
                    dC = d2C / 2,
                    hdC = dC / 2,
                    cC = document.getElementById("myCanvas3");
                    cC.width = 2560
                    ctxC = cC.getContext("2d");
                    function tickC() {
                        offsetC -= 5;
                        if (-1 * offsetC === d2C) offsetC = 0;
                        ctxC.clearRect(0, 0, cC.width, cC.height);
                        ctxC.fillStyle = 'rgba(255, 255, 255, 0.9)';  
                        ctxC.beginPath();
                        var offsetYC = startYC - progressC;  
                        ctxC.moveTo(startXC - offsetC, offsetYC);
                        for (var i = 0; i < waveCountC; i++) {
                            var dxC = i * d2C;
                            var offsetXC = dxC + startXC - offsetC;
                            ctxC.quadraticCurveTo(offsetXC + hdC, offsetYC + waveHeightC, offsetXC + dC, offsetYC);
                            ctxC.quadraticCurveTo(offsetXC + hdC + dC, offsetYC - waveHeightC, offsetXC + d2C, offsetYC);
                        }
                        ctxC.lineTo(startXC + waveWidthC, 6000);
                        ctxC.lineTo(startXC, 6000);
                        ctxC.fill();
                        // setTimeout(tickC,5000 / 60); //速度
                        requestAnimationFrame(tickC);
                    }
                    tickC();
                }
                </script>
                <div class="nex_common_top" id="nex_common_top">
                    <div class="w1240">
                        <div class="nex_common_logo">
                            <!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}-->
                        </div>
                        <div class="nex_common_nav">
                            <!--{eval $mnid = getcurrentnav();}-->
                            <ul>
                            <!--{loop $_G['setting']['navs'] $nav}-->
                                <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
                            <!--{/loop}-->
                            </ul>
                            <!--{hook/global_nav_extra}-->
                        </div>
                        <!--{if $_G['uid']}-->
                        <style>
                        .nex_common_nav{ width:720px;}
                        </style>
                        <!--{else}-->
                        <!--{/if}-->
                        <div class="nex_common_search"><!--{subtemplate common/pubsearchform_index}--></div>
                        <div class="nex_common_dl"><!--{template common/header_userstatus_index}--></div>
                        <div class="clear"></div>
                    </div>
                </div>
                <script type="text/javascript" src="$_G['style'][styleimgdir]/js/nv1.js"></script>
            </div>
            <!--侧边工具栏-->
            <div class="nexsidetls">
                <div class="nexsidetools">
                    <ul class="nex_sdt_1">
                    	<li class="nexsd_kf">
                            <div class="nexstout">
                                <i></i>
                                <p>售前</p>
                            </div>
                        </li>
                        <li class="nexsd_kf_aft">
                            <div class="nexstout">
                                <i></i>
                                <p>售后</p>
                            </div>
                        </li>
                     </ul>
                     
                     <ul class="nex_sdt_2">   
                        <li class="nexsd_ft">
                            <div class="nexstout">
                                <a onClick="showWindow('nav', this.href, 'get', 0)" href="forum.php?mod=misc&amp;action=nav">
                                    <i></i>
                                    <p>发帖</p>
                                </a>
                            </div>
                        </li>
                        <li class="nexsd_app">
                            <div class="nexstout nexstout_app">
                                <i></i>
                                <p>APP</p>
                            </div>
                        </li>
                        <li class="nexsd_wx">
                            <div class="nexstout nexstout_wx">
                                <i></i>
                                <p>交流群</p>
                            </div>
                        </li>
                        <!--返回顶部-->
                        <li id="scrolltop">
                            <div class="nexstout nexstout_up">
                                <a id="nexGoToTop">
                                    <i></i>
                                    <p>返回</p>
                                </a>
                            </div>
                            
                        </li>
                    </ul>
                </div>
                <div class="nexsidecons">
                	<ul>
                    	<li style="display:none;">
                        	<div class="nexsthds nexsthds_kf">
                                <div class="nexsthdc_btm">
                                	<h5>工作时间</h5>
                                    <p>工作日：9:00-21:00</p>
                                    <p>节假日：9:00-18:00</p>
                                </div>
                                <div class="nexsthdstops nexsthdstops_qq">
                                    <a href="tencent://Message/?Uin=$_G['setting']['site_qq']&amp;websiteName=#=&amp;Menu=yes">点击联系客服</a>
                                </div>
                                <div class="nexsthdstops nexsthdstops_skype">
                                    <a href="#">点击联系客服</a>
                                </div>
                            </div>
                        </li>
                        <li style="display:none;">
                        	<div class="nexsthds nexsthds_kf">
                                <div class="nexsthdc_btm">
                                	<h5>工作时间</h5>
                                    <p>工作日：9:00-21:00</p>
                                    <p>节假日：9:00-18:00</p>
                                </div>
                                <div class="nexsthdstops nexsthdstops_qq">
                                    <a href="tencent://Message/?Uin=$_G['setting']['site_qq']&amp;websiteName=#=&amp;Menu=yes">点击联系客服</a>
                                </div>
                                <div class="nexsthdstops nexsthdstops_skype">
                                    <a href="#">点击联系客服</a>
                                </div>
                            </div>
                        </li>
                        <li style="display:none;"></li>
                        <li style="display:none;">
                        	<div class="nexsthds nexsthds_app nexAPPuiBox">
                                <div class="nexstappsd nexAPPui">
                                	<i></i>
                                    <div class="nexAPPinters">
                                        <p>手机版二维码</p>
                                        <p>随时手机查素材</p>
                                        <img src="$_G['style'][styleimgdir]/sidetools/cell_code.jpg">
                                        <a href="http://t.cn/Aiux1Qh0" target="_blank">点击下载</a>
                                    </div>
                                    <em></em>
                                </div>
                            </div>
                        </li>
                        <li style="display:none;">
                        	<div class="nexsthds nexsthds_weixin">
                                <div class="nexstwxsd">
                                    <p>扫描二维码</p>
                                    <p>加入官方微信群</p>
                                    <img src="$_G['style'][styleimgdir]/sidetools/q_code.jpg">
                                    <a href="http://t.cn/Aiux1Qh0" target="_blank">点击加入</a>
                                </div>
                            </div>
                        </li>
                        <li style="display:none;"></li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nexsidetools ul li").each(function(s){
						jQuery(this).hover(function(){
							jQuery(".nexsidecons ul li").eq(s).show().siblings().hide();
							})
						})
				</script>
                <script type="text/javascript">
				jQuery(".nexsidetls").each(function(s){
						jQuery(this).mouseleave(function(){
							jQuery(".nexsidecons ul li").css("display","none");
							})
						})
				</script>
            </div>
			<div class="wp">
				<div class="hdc cl">
				</div>
				<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
					<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
					<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
						 <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
						 <li>$module[url]</li>
						 <!--{/if}-->
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
				$_G[setting][menunavs]
				<div id="mu" class="cl">
				<!--{if $_G['setting']['subnavs']}-->
					<!--{loop $_G[setting][subnavs] $navid $subnav}-->
						<!--{if $_G['setting']['navsubhover'] || $mnid == $navid}-->
						<ul class="cl {if $mnid == $navid}current{/if}" id="snav_$navid" style="display:{if $mnid != $navid}none{/if}">
						$subnav
						</ul>
						<!--{/if}-->
					<!--{/loop}-->
				<!--{/if}-->
				</div>
				<!--{ad/subnavbanner/a_mu}-->
				
			</div>
        </div>

		<!--{hook/global_header}-->
	<!--{/if}-->

	<div id="wp" class="wp">
    
		
