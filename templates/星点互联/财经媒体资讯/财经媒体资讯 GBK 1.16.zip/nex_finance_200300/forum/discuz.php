<?php echo 'Copyright@Neoconex_�ǵ㻥��';exit;?>
<!--{template common/header}-->
        <!--[diy=diy_chart]--><div id="diy_chart" class="area"></div><!--[/diy]-->
        <!--����һ��-->
        <div class="nex_quotation_list">
        	<div class="w1240">
                <div class="nex_quotation_inner">
                	<!--[diy=nex_quotation_inner]--><div id="nex_quotation_inner" class="area"></div><!--[/diy]-->
                    
                    <ul class="hd">
                        <li></li>
                        <li></li>
                    </ul>
                </div>
                <script type="text/javascript">jQuery(".nex_quotation_list").slide({ mainCell:".bd", effect:"topLoop", autoPlay:true ,delayTime:800,interTime:5000});</script>
            </div>
        </div>
        <!--��̳�ṹ�������Ƿ����ùر���̳��ҳ������������������ʾ-->
        <div class="nex_discuz_frame">
        	<!--{hook/index_nav_extra}-->
        	<!--��̳��ѡ-->
            <div class="nex_discuz_selection">
            	<!--��̳��ѡͼ��-->
                <div class="nex_discuz_foucus">
                    <div class="nex_discuz_slider">
                        <!--[diy=nex_discuz_slider]--><div id="nex_discuz_slider" class="area"></div><!--[/diy]-->
                        
                        <a class="prev" href="javascript:void(0)"></a>
                        <a class="next" href="javascript:void(0)"></a>
                        
                    </div>
                </div>
                <script type="text/javascript">
                    jQuery(".nex_discuz_slider").slide({ mainCell:".pic",effect:"fold", autoPlay:true, delayTime:600, trigger:"click"});
                </script>
                <!--��̳��ѡ����-->
                <div class="nex_discuz_jxthreads">
                	<ul>
                    	<!--[diy=nex_discuz_jxthreads]--><div id="nex_discuz_jxthreads" class="area"></div><!--[/diy]-->
                    	
                    </ul>
                </div>
                <!--��̳���Ż-->
                <div class="nex_discuz_active">
                	<!--[diy=nex_discuz_active]--><div id="nex_discuz_active" class="area"></div><!--[/diy]-->
                	
                </div>
                <div class="clear"></div>
            </div>
            <!--��̳����-->
            <div class="nex_discuz_main">
            	<!--��̳�������-->
                <div class="nex_discuz_main_left">
                	<!--��̳�Ƽ��Ķ�-->
                    <div class="nex_discuz_recoms_read">
                    	<div class="nex_discuz_recoms_read_top">
                        	<span class="nex_tjyd_icon">�Ƽ��Ķ�</span>
                            <!--{if empty($gid) && $announcements}-->
                            <div class="nex_discuz_notice">
                                <div id="an">
                                    <dl class="cl">
                                        <dd>
                                            <div id="anc"><ul id="ancl">$announcements</ul></div>
                                        </dd>
                                    </dl>
                                </div>
                                <script type="text/javascript">announcement();</script>
                            </div>
                            <!--{/if}-->
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                        <div class="nex_discuz_recoms_read_btm">
                        	<!--[diy=nex_discuz_recoms_read_btm]--><div id="nex_discuz_recoms_read_btm" class="area"></div><!--[/diy]-->
                            
                        </div>
                        <script type="text/javascript">	
						  jQuery(".nex_discuz_recoms_read_btm").slide({ mainCell:"ul", effect:"topLoop", vis:6, opp:true, autoPlay:true, delayTime:800, innerTime:3000 });
						 </script>
                    </div>
                    <!--{hook/index_status_extra}-->
                    <!--{if empty($gid)}-->
                        <!--{ad/text/wp a_t}-->
                    <!--{/if}-->
                    <!--��̳����б�-->
                    <div class="nex_discuz_columns">
                        <!--{hook/index_top}-->
                        <!--{if !empty($_G['cache']['heats']['message'])}-->
                        <div class="bm">
                            <div class="bm_h cl">
                                <h2>{lang hotthreads_forum}</h2>
                            </div>
                            <div class="bm_c cl">
                                <div class="heat z">
                                    <!--{loop $_G['cache']['heats']['message'] $data}-->
                                        <dl class="xld">
                                            <dt><!--{if $_G['adminid'] == 1}--><a class="d" href="forum.php?mod=misc&action=removeindexheats&tid=$data[tid]" onclick="return removeindexheats()">delete</a><!--{/if}-->
                                            <a href="forum.php?mod=viewthread&tid=$data[tid]" target="_blank" class="xi2">$data[subject]</a></dt>
                                            <dd>$data[message]</dd>
                                        </dl>
                                    <!--{/loop}-->
                                </div>
                                <ul class="xl xl1 heatl">
                                <!--{loop $_G['cache']['heats']['subject'] $data}-->
                                    <li><!--{if $_G['adminid'] == 1}--><a class="d" href="forum.php?mod=misc&action=removeindexheats&tid=$data[tid]" onclick="return removeindexheats()">delete</a><!--{/if}-->&middot; <a href="forum.php?mod=viewthread&tid=$data[tid]" target="_blank" class="xi2">$data[subject]</a></li>
                                <!--{/loop}-->
                                </ul>
                            </div>
                        </div>
                        <!--{/if}-->
                        <!--{hook/index_catlist_top}-->
                        <div class="fl bm">
                        <!--{if empty($gid) && !empty($forum_favlist)}-->
                            <!--{eval $forumscount = count($forum_favlist);}-->
                            <!--{eval $forumcolumns = $forumscount > 3 ? ($forumscount == 4 ? 4 : 5) : 1;}-->
                
                            <!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->
                
                            <div class="bm bmw {if $forumcolumns} flg{/if} cl">
                                <div class="bm_h cl">
                                    <h2><a href="home.php?mod=space&do=favorite&type=forum">{lang forum_myfav}</a></h2>
                                </div>
                                <div id="category_0" class="bm_c" style="{echo $collapse['category_0']}">
                                    <div class="nex_fav_discuz">
                                        <ul>
                                            <!--{eval $favorderid = 0;}-->
                                            <!--{loop $forum_favlist $key $favorite}-->
                                            <!--{if $favforumlist[$favorite[id]]}-->
                                            <!--{eval $forum=$favforumlist[$favorite[id]];}-->
                                            <!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
                                                <li>
                                                    <div class="nex_fav_discuz_top">
                                                        <div class="fl_icn_g nex_favbks">
                                                        <!--{if $forum[icon]}-->
                                                            $forum[icon]
                                                        <!--{else}-->
                                                            <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
                                                        <!--{/if}-->
                                                        </div>
                                                        <div class="nex_fav_discuz_intel">
                                                            <div class="nex_fav_discuz_intel_top">
                                                                <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a>
                                                                <!--{if $forum[todayposts] && !$forum['redirect']}--><em>$forum[todayposts]</em><!--{/if}-->
                                                                <div class="clear"></div>
                                                            </div>
                                                            <!--{if empty($forum[redirect])}-->
                                                            <div class="nex_forum_details">
                                                                <em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em>&middot;<em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em>
                                                            </div>
                                                            <!--{/if}-->
                                                        </div>
                                                        <div class="clear"></div>
                                                    </div>
                                                    
                                                    <!--{if $forum[description]}-->
                                                    <div class="nex_fav_discuz_sums">$forum[description]</div>
                                                    <!--{else}-->
                                                    <div class="nex_fav_discuz_sums">�������ް����</div>
                                                    <!--{/if}-->
                                                    <div class="nex_forum_newpost">
                                                    <!--{if $forum['permission'] == 1}-->
                                                        {lang private_forum}
                                                    <!--{else}-->
                                                        <!--{if $forum['redirect']}-->
                                                            <a href="$forumurl" class="xi2">{lang url_link}</a>
                                                        <!--{elseif is_array($forum['lastpost'])}-->
                                                            <!--{if $cat['forumcolumns'] < 3}-->
                                                                <a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a><em class="nex_lastpost_date">$forum[lastpost][dateline]</em><!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}-->
                                                            <!--{else}-->
                                                                <a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" target="_blank">���������⣬�鿴����������</a>
                                                            <!--{/if}-->
                                                        <!--{else}-->
                                                            <em>���滹û���κ�����</em>
                                                        <!--{/if}-->
                                                    <!--{/if}-->
                                                    </div>
                                                    <!--{hook/index_forum_extra $forum[fid]}-->
                                                    <!--{hook/index_followcollection_extra $colletion[ctid]}-->
                                                </li>
                                            
                                            <!--{/if}-->
                                            <!--{/loop}-->
                                            <!--{hook/index_favforum_extra $forum[fid]}-->
                                        </ul>
                                    </div>
                                    <!--{if ($columnspad = $favorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->
                                </div>
                            </div>
                            <!--{ad/intercat/bm a_c/-1}-->
                        <!--{/if}-->
                        <!--{hook/index_favforum_extra $forum[fid]}-->
                        
                        <!--{loop $catlist $key $cat}-->
                            <!--{hook/index_catlist $cat[fid]}-->
                            <div class="bm bmw {if $cat['forumcolumns']} flg{/if} cl">
                                <div class="bm_h cl">
                                    <!--{if $cat['moderators']}--><span class="y">{lang forum_category_modedby}: $cat[moderators]</span><!--{/if}-->
                                    <!--{eval $caturl = !empty($cat['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$cat['domain'].'.'.$_G['setting']['domain']['root']['forum'] : '';}-->
                                    <h4><a href="{if !empty($caturl)}$caturl{else}forum.php?gid=$cat[fid]{/if}" style="{if $cat[extra][namecolor]}color: {$cat[extra][namecolor]};{/if}">$cat[name]</a></h4>
                                </div>
                                <div id="category_$cat[fid]" class="bm_c" style="{echo $collapse['category_'.$cat[fid]]}">
                                    <div class="nex_fav_discuz">
                                        <ul>
                                        <!--{loop $cat[forums] $forumid}-->
                                        <!--{eval $forum=$forumlist[$forumid];}-->
                                        <!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
                                        <li>
                                            <div class="nex_fav_discuz_top">
                                                <div class="fl_icn_g nex_favbks">
                                                <!--{if $forum[icon]}-->
                                                    $forum[icon]
                                                <!--{else}-->
                                                    <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
                                                <!--{/if}-->
                                                </div>
                                                <div class="nex_fav_discuz_intel">
                                                    <div class="nex_fav_discuz_intel_top">
                                                        <a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a>
                                                        <!--{if $forum[todayposts] && !$forum['redirect']}--><em>$forum[todayposts]</em><!--{/if}-->
                                                        <div class="clear"></div>
                                                    </div>
                                                    <!--{if empty($forum[redirect])}-->
                                                    <div class="nex_forum_details">
                                                        <em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em>&middot;<em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em>
                                                    </div>
                                                    <!--{/if}-->
                                                </div>
                                                <div class="clear"></div>
                                            </div>
                                            
                                            <!--{if $forum[description]}-->
                                            <div class="nex_fav_discuz_sums">$forum[description]</div>
                                            <!--{else}-->
                                            <div class="nex_fav_discuz_sums">�������ް����</div>
                                            <!--{/if}-->
                                            <div class="nex_forum_newpost">
                                            <!--{if $forum['permission'] == 1}-->
                                                {lang private_forum}
                                            <!--{else}-->
                                                <!--{if $forum['redirect']}-->
                                                    <a href="$forumurl" class="xi2">{lang url_link}</a>
                                                <!--{elseif is_array($forum['lastpost'])}-->
                                                    <!--{if $cat['forumcolumns'] < 3}-->
                                                        <a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a><em class="nex_lastpost_date">$forum[lastpost][dateline]</em><!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}-->
                                                    <!--{else}-->
                                                        <a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" target="_blank">���������⣬�鿴����������</a>
                                                    <!--{/if}-->
                                                <!--{else}-->
                                                    <em>���滹û���κ�����</em>
                                                <!--{/if}-->
                                            <!--{/if}-->
                                            </div>
                                            <!--{hook/index_forum_extra $forum[fid]}-->
                                            <!--{hook/index_followcollection_extra $colletion[ctid]}-->
                                        </li>
                                        <!--{/loop}-->
                                        <!--{hook/index_datacollection_extra $colletion[ctid]}-->
                                       </ul>
                                    </div>
                                </div>
                            </div>
                            <!--{ad/intercat/bm a_c/$cat[fid]}-->
                        <!--{/loop}-->
                        </div>
                        <div class="clear"></div>
                    </div>
                    <!--��̳��ҳ���߻�Ա-->
                    <!--{hook/index_middle}-->
                    <div class="mtn">
                        <!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
                    </div>
            
                    <!--{if empty($gid) && $_G['setting']['whosonlinestatus']}-->
                    <div id="online" class="bm oll">
                        <div class="bm_h">
                        <!--{if $detailstatus}-->
                            <span class="o"><a href="forum.php?showoldetails=no#online" title="{lang spread}"><img src="$_G['style'][styleimgdir]/discuz/collapsed_no.gif" alt="{lang spread}" /></a></span>
                            <h3>
                                <strong><a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a></strong>
                                <span class="xs1">- <strong>$onlinenum</strong> {lang onlines}
                                - <strong>$membercount</strong> {lang index_members}(<strong>$invisiblecount</strong> {lang index_invisibles}),
                                <strong>$guestcount</strong> {lang index_guests}
                                - {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>
                            </h3>
                        <!--{else}-->
                            <!--{if empty($_G['setting']['sessionclose'])}-->
                                <span class="o"><a href="forum.php?showoldetails=yes#online" title="{lang spread}"><img src="$_G['style'][styleimgdir]/discuz/collapsed_yes.gif" alt="{lang spread}" /></a></span>
                            <!--{/if}-->
                            <h3>
                                <strong>
                                    <!--{if !empty($_G['setting']['whosonlinestatus'])}-->
                                        {lang onlinemember}
                                    <!--{else}-->
                                        <a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a>
                                    <!--{/if}-->
                                </strong>
                                <span class="xs1">- {lang total} <strong>$onlinenum</strong> {lang onlines}
                                <!--{if $membercount}-->- <strong>$membercount</strong> {lang index_members},<strong>$guestcount</strong> {lang index_guests}<!--{/if}-->
                                - {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>
                            </h3>
                        <!--{/if}-->
                        </div>
                    <!--{if $_G['setting']['whosonlinestatus'] && $detailstatus}-->
                        <dl id="onlinelist" class="bm_c">
                            <dt class="ptm pbm bbda">$_G[cache][onlinelist][legend]</dt>
                            <!--{if $detailstatus}-->
                                <dd class="ptm pbm">
                                <ul class="cl">
                                <!--{if $whosonline}-->
                                    <!--{loop $whosonline $key $online}-->
                                        <li title="{lang time}: $online[lastactivity]">
                                        <img src="{STATICURL}image/common/$online[icon]" alt="icon" />
                                        <!--{if $online['uid']}-->
                                            <a href="home.php?mod=space&uid=$online[uid]">$online[username]</a>
                                        <!--{else}-->
                                            $online[username]
                                        <!--{/if}-->
                                        </li>
                                    <!--{/loop}-->
                                <!--{else}-->
                                    <li style="width: auto">{lang online_only_guests}</li>
                                <!--{/if}-->
                                </ul>
                            </dd>
                            <!--{/if}-->
                        </dl>
                    <!--{/if}-->
                    </div>
                    <!--{/if}-->
                    <!--��̳��ҳ��������-->
                    <!--{if empty($gid) && ($_G['cache']['forumlinks'][0] || $_G['cache']['forumlinks'][1] || $_G['cache']['forumlinks'][2])}-->
                    <div class="bm lk">
                        <div id="category_lk" class="bm_c ptm">
                            <!--{if $_G['cache']['forumlinks'][0]}-->
                                <ul class="m mbn cl">$_G['cache']['forumlinks'][0]</ul>
                            <!--{/if}-->
                            <!--{if $_G['cache']['forumlinks'][1]}-->
                                <div class="mbn cl">
                                    $_G['cache']['forumlinks'][1]
                                </div>
                            <!--{/if}-->
                            <!--{if $_G['cache']['forumlinks'][2]}-->
                                <ul class="x mbm cl">
                                    $_G['cache']['forumlinks'][2]
                                </ul>
                            <!--{/if}-->
                        </div>
                    </div>
                    <!--{/if}-->
                    <!--{hook/index_bottom}-->
                </div>
                <!--��̳�����Ҳ�-->
                <!--{hook/index_side_top}-->
                <div class="nex_discuz_main_right">
                	<!--��̳�����Ҳ���������-->
                	<div class="nex_discuz_side_box">
                    	<div class="nex_forum_common_title">
                        	<span>��������</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="����"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_entrance_list">
                        	<ul>
                            	<!--[diy=nex_entrance_list]--><div id="nex_entrance_list" class="area"></div><!--[/diy]-->
                                
                            </ul>
                        </div>
                    </div>
                    
                    <!--��̳�����Ҳ��Ա��-->
                	<div class="nex_discuz_side_box">
                    	<div class="nex_forum_common_title">
                        	<span>��Ծ��Ա</span>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_discuz_member_list">
                        	<ul>
                            	<!--[diy=nex_discuz_member_list]--><div id="nex_discuz_member_list" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                    
                    <!--��̳�����Ҳྫ�����Ķ�-->
                	<div class="nex_discuz_side_box">
                    	<div class="nex_forum_common_title">
                        	<span>�������Ķ�</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_diguest_list">
                        	<ul>
                            	<!--[diy=nex_diguest_list]--><div id="nex_diguest_list" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                    
                    <!--��̳�����Ҳ��ע-->
                	<div class="nex_discuz_side_box">
                    	<!--[diy=nex_discuz_focus_top]--><div id="nex_discuz_focus_top" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <!--{hook/index_side_bottom}-->
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <!--{if empty($gid)}-->
            <div class="wp">
                <!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
            </div>
        <!--{/if}-->
        
    

<!--{if $_G['group']['radminid'] == 1}-->
	<!--{eval helper_manyou::checkupdate();}-->
<!--{/if}-->
<!--{if empty($_G['setting']['disfixednv_forumindex']) }--><script>fixed_top_nv();</script><!--{/if}-->

<!--{template common/footer}-->
