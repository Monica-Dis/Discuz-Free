<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header_index}-->
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <!--index_main-->
	<div class="nex_displacement">
    	<div class="w1240">
        	<div class="nex_displacement_l">
            	<div class="nex_displacement_focusBox">
                	<!--[diy=nex_displacement_focusBox]--><div id="nex_displacement_focusBox" class="area"></div><!--[/diy]-->
                    
                    <a class="prev" href="javascript:void(0)"></a>
                    <a class="next" href="javascript:void(0)"></a>
                    <ul class="hd">
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                        <li></li>
                    </ul>
                </div>
            
                <script type="text/javascript">
                    jQuery(".nex_displacement_focusBox").slide({ mainCell:".pic",effect:"left", autoPlay:true, delayTime:600,interTime:5000});
                </script>
                <div class="nex_the_latest_news">
                	<div class="nex_the_latest_news_icon"></div>
                    <div class="nex_the_latest_news_list">
                    	<!--[diy=nex_the_latest_news_list]--><div id="nex_the_latest_news_list" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_the_latest_news_more"><a href="http://t.cn/Aiux1Qh0" target="_blank" title="�����Ѷ"></a></div>
                    <div class="clear"></div>
                </div>
                <script type="text/javascript">
                	jQuery(".nex_the_latest_news_list").slide({ mainCell:"ul", effect:"topLoop", vis:2, opp:true, autoPlay:true, delayTime:600,interTime:5000 });
                </script>
            </div>
            <div class="nex_displacement_m">
            	<ul>
                	<!--[diy=nex_displacement_m]--><div id="nex_displacement_m" class="area"></div><!--[/diy]-->
                    
                </ul>
            </div>
            
            <div class="nex_displacement_r">
                <div class="nex_displacement_r_rk">
                	<div class="nex_displacement_r_rk_title"><span></span></div>
                    <div class="nex_displacement_rklist">
                    	<ul>
                        	<!--[diy=nex_displacement_rklist]--><div id="nex_displacement_rklist" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    
    <div class="nex_rt_local">
    	<div class="w1240">
            <!--mid_bd-->
            <div class="nex_mid_bd">
            	<div class="nex_mid_bd_l">
                    <!--����Ŀ��Ѷ-->
                    <div class="nex_finance_new_project">
                    	<div class="nex_finance_news_title">
                        	<span>����Ŀ��Ѷ</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="��������Ŀ��Ѷ"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_new_project">
                        	<ul>
                            	<!--[diy=nex_new_project]--><div id="nex_new_project" class="area"></div><!--[/diy]-->
                                
                                
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </div>
                    <!--ads1-->
                	<div class="nex_finance_ads"><!--[diy=nex_finance_ads]--><div id="nex_finance_ads" class="area"></div><!--[/diy]--></div>
                    <!--�б�-->
                    <div class="nex_finance_news">
                    	<div class="nex_finance_news_title">
                        	<span>������Ѷ</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="����������Ѷ"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_finance_news_list">
                            <ul>
                            	<!--[diy=nex_finance_news_list]--><div id="nex_finance_news_list" class="area"></div><!--[/diy]-->
                                
                            </ul>
                        </div>
                        <div class="jquery_pagnation"></div>
						<script type="text/javascript">
                            (function(dfsj_jq){
                                var dfsj_items = dfsj_jq('.nex_finance_news_list li');
                                var dfsj_items2 = 18;//ÿҳ��ʾ������
                                var total = dfsj_items.size();
                                total>0 && dfsj_jq('.jquery_pagnation').pagination({pagetotal:total,target:dfsj_items,perpage:dfsj_items2});
                                })(jQuery);
                        </script>
                    </div>
                    
                </div>
                <div class="nex_mid_bd_r">
                	<!--��ע-->
                    <div class="nex_side_focus">
                    	<div class="nex_side_focus_top">
                        	<ul>
                            	<li class="on">�ٷ�΢��</li>
                                <li>APP����</li>
                                <li>��ϵ����</li>
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="nex_side_focus_btm">
                        	<ul>
                            	<li style="display:block;">
                                	<div class="nex_side_focus_inner nex_side_focus_bg1">
                                    	<!--[diy=nex_side_focus_bg1]--><div id="nex_side_focus_bg1" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                </li>
                                <li>
                                	<div class="nex_side_focus_inner nex_side_focus_bg2">
                                    	<!--[diy=nex_side_focus_bg2]--><div id="nex_side_focus_bg2" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                </li>
                                <li>
                                	<div class="nex_side_focus_inner nex_side_focus_bg3">
                                    	<!--[diy=nex_side_focus_bg3]--><div id="nex_side_focus_bg3" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                </li>
                            </ul>
                        
                        </div>
                        <script type="text/javascript">
							jQuery(".nex_side_focus_top ul li").each(function(s){
								jQuery(this).click(function(){
									jQuery(this).addClass("on").siblings().removeClass("on");
									jQuery(".nex_side_focus_btm ul li").eq(s).show().siblings().hide();
									})
								})
						</script>
                    </div>
                    <!--��Ѷ���-->
                    <div class="nex_mid_bd_side">
                    	<div class="nex_mid_bd_side_title">
                        	<span>��Ѷ���</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="������Ѷ���"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_zx_analysis">
                        	<ul>
                            	<!--[diy=nex_zx_analysis]--><div id="nex_zx_analysis" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                    <!--�г�����-->
                    <div class="nex_mid_bd_side">
                    	<div class="nex_mid_bd_side_title">
                        	<span>���鶯̬</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="�������鶯̬"></a>
                            <div class="clear"></div>
                        </div>
                        
                        <div class="nex_market_place_box">
                        	<!--[diy=nex_market_place_box]--><div id="nex_market_place_box" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <script type="text/javascript">	
						  jQuery(".nex_market_place_box").slide({ mainCell:"ul", effect:"topLoop", vis:4, opp:true, autoPlay:true, delayTime:800 });
					 </script>
                    </div>
                    <!--��ҵ��̬-->
                    <div class="nex_mid_bd_side">
                    	<div class="nex_mid_bd_side_title">
                        	<span>��ҵ��̬</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank" title="������ҵ��̬"></a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_industrial_list">
                        	<ul>
                            	<!--[diy=nex_industrial_list]--><div id="nex_industrial_list" class="area"></div><!--[/diy]-->
                                
                                
                            </ul>
                        </div>
                    </div>
                    <!--��߹��λ-->
                    <div class="nex_side_ads">
                    	<!--[diy=nex_side_ads]--><div id="nex_side_ads" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <!--������Ѷ����-->
                    <div class="nex_mid_bd_side">
                    	<div class="nex_mid_bd_side_title">
                        	<span>��������</span>
                            <ul>
                            	<li class="on">�����а�</li>
                                <li>�����а�</li>
                                <div class="clear"></div>
                            </ul>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_zx_rk">
                        	<ul>
                            	<li style="display:block;">
                                	<div class="nex_zx_rk_list">
                                    	<dl>
                                        	<!--[diy=nex_zx_rk_list1]--><div id="nex_zx_rk_list1" class="area"></div><!--[/diy]-->
                                        	
                                        </dl>
                                    </div>
                                </li>
                                <li>
                                	<div class="nex_zx_rk_list">
                                    	<dl>
                                        	<!--[diy=nex_zx_rk_list12]--><div id="nex_zx_rk_list12" class="area"></div><!--[/diy]-->
                                        	
                                        </dl>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <script type="text/javascript">
							jQuery(".nex_mid_bd_side_title ul li").each(function(s){
								jQuery(this).click(function(){
									jQuery(this).addClass("on").siblings().removeClass("on");
									jQuery(".nex_zx_rk ul li").eq(s).show().siblings().hide();
									})
								});
							jQuery(".nex_zx_rk_list dl dd").each(function(s){
								jQuery(this).hover(function(){
									jQuery(this).addClass("curr").siblings().removeClass("curr");
									})
								});
						</script>
                    </div>
                    <!--��ǩ��-->
                    <div class="nex_cloud_tag">
                    	<div class="nex_mid_bd_side_title">
                        	<span>��ǩ��</span>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_cloud_tag_inter">
                        	<!--�Ż���ǩ���ڲ����ýӿ�-->
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">Banana-Pi</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">�ֲ�ʽ����</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">DEXON</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">TokenInsight</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">������</a>
                            <a class="nex_fz_4" href="http://t.cn/Aiux1Qh0" target="_blank">POSEIDON</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">PoS��ʶ</a>
                            <a class="nex_fz_5" href="http://t.cn/Aiux1Qh0" target="_blank">���ӱ���</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">��ѧ������</a>
                            <a class="nex_fz_3" href="http://t.cn/Aiux1Qh0" target="_blank">Bloxberg</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">��������</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">VolumeNetwork</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">�������û�</a>
                            <a class="nex_fz_5" href="http://t.cn/Aiux1Qh0" target="_blank">Binance</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">���Ͽ��</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">��������</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">Cobo���</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">LadderNetwork</a>
                            <a class="nex_fz_3" href="http://t.cn/Aiux1Qh0" target="_blank">�ֲ�ʽ�ļ�ϵͳ</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">��״̬�ͻ���</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">ArcBlock</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">Wright</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">�����</a>
                            <a class="nex_fz_4" href="http://t.cn/Aiux1Qh0" target="_blank">���簲ȫ</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">����ʽ����</a>
                            <a class="nex_fz_4" href="http://t.cn/Aiux1Qh0" target="_blank">��̫��</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">ABT</a>
                            <a class="nex_fz_5" href="http://t.cn/Aiux1Qh0" target="_blank">Reserve</a>
                            <a class="nex_fz_1" href="http://t.cn/Aiux1Qh0" target="_blank">���رҿ��</a>
                            <a class="nex_fz_2" href="http://t.cn/Aiux1Qh0" target="_blank">���رһ��</a>
                        </div>
                    </div>
                    <script type="text/javascript">
						tagcloud({
							selector: ".nex_cloud_tag_inter",  //Ԫ��ѡ����
							fontsize: 16,       //���������С, ��λpx
							radius: 90,         //�����뾶, ��λpx ҳ����Ⱥ͸߶ȵ����֮һ
							mspeed: "slow",   //��������ٶ�, ȡֵ: slow, normal(Ĭ��), fast
							ispeed: "slow",   //�������ٶ�, ȡֵ: slow, normal(Ĭ��), fast
							direction: 135,     //��ʼ��������, ȡֵ�Ƕ�(˳ʱ��360): 0��Ӧtop, 90��Ӧleft, 135��Ӧright-bottom(Ĭ��)...
							keep: false          //����Ƴ�������Ƿ������������, ȡֵ: false, true(Ĭ��) ��Ӧ ���������ٶȹ���, ��������
						});
					</script>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_index_ads"><!--[diy=nex_index_ads2]--><div id="nex_index_ads2" class="area"></div><!--[/diy]--></div>
            <!--intel sort-->
            <div class="nex_blockchain_sort">
            	<div class="nex_finance_news_title">
                    <span>�����ҵ</span>
                    <ul>
                    	<li class="cur">ʵս����</li>
                        <li>��������</li>
                        <li>֪ʶ�ٿ�</li>
                        <li>��������</li>
                        <li>չ��</li>
                        <div class="clear"></div>
                    </ul>
                    <a href="http://t.cn/Aiux1Qh0" target="_blank" title="���������ҵ��Ѷ"></a>
                    <div class="clear"></div>
                </div>
            	<div class="nex_technic_block">
                	<div class="nex_technic_block_l">
                    	<!--bbs broadcast-->
                        <div class="nex_technic_block_title">��̳����</div>
                        <div class="nex_technic_block_list">
                        	<!--[diy=nex_technic_block_list]--><div id="nex_technic_block_list" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <script type="text/javascript">
							jQuery(".nex_technic_block_list").slide({ mainCell:"ul", effect:"topLoop", vis:3, opp:true, autoPlay:true, delayTime:600,interTime:5000 });
						</script>
                        <div class="nex_bbs_btms">
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">��������</a>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">������̳</a>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nex_technic_block_r">
                    	<dl>
                        	<dd style="display:block;">
                            	<div class="nex_technic_sort1">
                                	<ul>
                                    	<!--[diy=nex_technic_sort1]--><div id="nex_technic_sort1" class="area"></div><!--[/diy]-->
                                    	
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                            <dd>
                            	<div class="nex_technic_sort4">
                                	<ul>
                                    	<!--[diy=nex_technic_sort5]--><div id="nex_technic_sort5" class="area"></div><!--[/diy]-->
                                        
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                            <dd>
                            	<div class="nex_technic_sort2">
                                	<ul>
                                    	<!--[diy=nex_technic_sort51]--><div id="nex_technic_sort51" class="area"></div><!--[/diy]-->
                                    	
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                            <dd>
                            	<div class="nex_technic_sort1">
                                	<ul>
                                    	<!--[diy=nex_technic_sort6]--><div id="nex_technic_sort6" class="area"></div><!--[/diy]-->
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                            <dd>
                            	<div class="nex_technic_sort3">
                                	<ul>
                                    	<!--[diy=nex_technic_sort7]--><div id="nex_technic_sort7" class="area"></div><!--[/diy]-->
                                    	
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </dd>
                        </dl>
                    </div>
                    <div class="clear"></div>
                </div>
                <script type="text/javascript">
					jQuery(".nex_finance_news_title ul li").each(function(a){
						jQuery(this).click(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_technic_block_r dl dd").eq(a).show().siblings().hide();
							})
						})
				</script>
            </div>
            
        </div>
    </div>
    <div class="nex_chain_video_box">
    	<div class="nex_chain_study">
        	<div class="nex_finance_news_title nex_finance_news_title_acadamy">
                <span>����ƾ�ѧԺ</span>
                <ul>
                    <li class="cur">ʵ��VIP�γ�</li>
                    <li>�󿧹����</li>
                    <div class="clear"></div>
                </ul>
                <a href="http://t.cn/Aiux1Qh0" target="_blank" title="����������Ƶ�γ�"></a>
                <div class="clear"></div>
            </div>
            <div class="nex_video_switch">
            	<dl>
                	<dd style="display:block;">
                    	<div class="nex_acadamy_units">
                        	<ul>
                            	<!--[diy=nex_acadamy_units]--><div id="nex_acadamy_units" class="area"></div><!--[/diy]-->
                            	
                                
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_acadamy_units">
                        	<ul>
                            	<!--[diy=nex_acadamy_unit]--><div id="nex_acadamy_unit" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                </dl>
            </div>
        	
            <script type="text/javascript">
				jQuery(".nex_finance_news_title_acadamy ul li").each(function(c){
					jQuery(this).click(function(){
						jQuery(this).addClass("cur").siblings().removeClass("cur");
						jQuery(".nex_video_switch dl dd").eq(c).show().siblings().hide();
						})
					})
			</script>
        </div>
    </div>
    <div class="nex_fl_box">
    	<div class="w1240">
        	<div class="nex_fl_bd">
            	<div class="nex_btmfooter_title">
                    <ul>
                    	<li class="on">ս�Ժ���ý��</li>
                        <li>���ҽ�����</li>
                        <div class="clear"></div>
                    </ul>
                    <div class="clear"></div>
                </div>
                <div class="nex_fl_btms">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_globle_coorperation">
                            	<dl>
                                	<!--[diy=nex_globle_coorperation]--><div id="nex_globle_coorperation" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_globle_coorperation nex_globle_exchange">
                            	<dl>
                                	<!--[diy=nex_globle_exchange]--><div id="nex_globle_exchange" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>        
                        	
                        </li>
                    </ul>
                </div>
                
				<script type="text/javascript">
                    jQuery(".nex_btmfooter_title ul li").each(function(s){
                        jQuery(this).click(function(){
                            jQuery(this).addClass("on").siblings().removeClass("on");
                            jQuery(".nex_fl_btms ul li").eq(s).show().siblings().hide();
                            })
                        })
                </script>
                <div class="nex_finance_news_title">
                    <span>��������</span>
                    <a href="tencent://Message/?Uin=��д���QQ����&websiteName=#=&Menu=yes" title="����������������ϵQQ����"></a>
                    <div class="clear"></div>
                </div>
                <div class="nex_fl_links">
                	<ul>
                    	<!--[diy=nex_fl_links]--><div id="nex_fl_links" class="area"></div><!--[/diy]-->
                    
                    	<div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
</div>    
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

