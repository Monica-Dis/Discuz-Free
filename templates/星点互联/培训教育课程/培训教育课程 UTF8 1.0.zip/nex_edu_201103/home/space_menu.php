<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval include 'template/nex_edu_201103/php/nex_users.php'}-->
<!--{eval include 'template/nex_edu_201103/php/nex_menu.php'}-->
<!--{eval include 'template/nex_edu_201103/php/nex_userid.php'}-->
<!--{eval require_once("source/plugin/nex_callgroupid/nex_callgroupid.php");}-->
<!--{if $nexgroup == $getID}-->
<link rel="stylesheet" type="text/css" href="template/nex_edu_201103/neoconex/home/teacher.css">
<div class="nex_teacher_info_top">
    <!--teacher intel-->
    <div class="nex_teacher_introbox">
        <div class="nex_teacher_intros_left">
            <div class="nex_teacher_avatar"><!--{avatar($space[uid],big)}--></div>
            <div class="nex_teacher_top">
                <div class="nex_teacher_intels">
                    <h5><span>{$space[username]}</span><!--{if $nex_occu}--><em>{$nex_occu}</em><!--{/if}--><div class="clear"></div></h5>
                    <div class="nex_teacher_intros">
                        <!--{if $nex_intro}-->
                        <p>{$nex_intro}</p>
                        <!--{/if}-->
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="clear"></div>
            
        </div>
        <div class="nex_teacher_intros_right">
            <div class="nex_teacher_intros_right_top">
                <ul>
                    <!--{if helper_access::check_module('follow')}-->
                    <li>
                        <!--{if !ckfollow($space['uid'])}-->
                            <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]" title="{lang follow_add}TA">{lang follow_add}TA</a>
                        <!--{else}-->
                            <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]" title="{lang follow_del}">{lang follow_del}</a>
                        <!--{/if}-->
                    </li>
                    <!--{/if}-->
                    <li>
                        <a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onclick="showWindow('showMsgBox', this.href, 'get', 0)" title="{lang send_pm}">{lang send_pm}</a>
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_teacher_intros_right_btm">
                <div class="nex_teacher_status">
                    <ul>
                        <li class="nex_teacher_classnum"><em>{$nex_designer_threads}</em>课程</li>
                        <li class="nex_teacher_followers"><em>{$nex_user_elements[follower]}</em>粉丝</li>
                        <li class="nex_teacher_joinindate"><em><!--{echo date("Y/m/d",{$nex_regdate})}--></em>加入</li>
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <div class="clear"></div>
    </div>
    <!--nav-->
    <div class="nex_teacher_Navtabs">
        <ul>
            <li {if $do=='thread'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space">全部课程</a></li>
            <li {if $do=='profile'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=profile&from=space">讲师资料</a></li>
            <div class="clear"></div>
        </ul>
    </div>
    <!--class-->
    <div class="nex_teacher_class_list">
        <ul>
            <!--{loop $list $stid $thread}-->
                <!--{eval include 'template/nex_edu_201103/php/nex_picstyle.php'}-->
                <!--{eval include 'template/nex_edu_201103/php/nex_profilemenu.php'}-->
                <li>
                    <div class="nex_teacher_class_pic">
                        <!--{if $nex_attachs == '0'}-->
                        <div class="nex_teacher_class_emps">
                            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" target="_blank" style="background:url($_G['style'][styleimgdir]/nex_common/unloading.jpg) center no-repeat; background-size:cover;"></a>
                        </div>
                        <!--{else}-->
                        <!--{if $nex_formatpic}-->
                        <div class="nex_teacher_classimg">
                        <!--{loop $nex_formatpic $nex_picpuin}-->
                            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" target="_blank" style=" background:url(<!--{if $nex_picpuin['remote']}-->                    			
                            {$_G['setting']['ftp']['attachurl']}forum/{$nex_picpuin[attachment]}
                            <!--{else}-->         			
                            {$_G['setting']['attachurl']}forum/{$nex_picpuin[attachment]}
                            <!--{/if}-->) center no-repeat; background-size:cover;"></a>
                        <!--{/loop}-->
                        </div>
                        <!--{else}-->
                        <div class="nex_teacher_classimg">
                            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" target="_blank" style=" background:url($_G['style'][styleimgdir]/nex_common/attachement.jpg) center no-repeat; background-size:cover;"></a>
                        </div>
                        <!--{/if}-->
                        <!--{/if}-->
                    </div>
                    <div class="nex_teacher_class_box">
                        <h5>
                            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" target="_blank">
                                <!--{if $thread['special'] == 1}-->
                                    <span class="threadType">{lang thread_poll}</span>
                                <!--{elseif $thread['special'] == 2}-->
                                    <span class="threadType">{lang thread_trade}</span>
                                <!--{elseif $thread['special'] == 3}-->
                                    <span class="threadType">{lang thread_reward}</span>
                                <!--{elseif $thread['special'] == 4}-->
                                    <span class="threadType">{lang thread_activity}</span>
                                <!--{elseif $thread['special'] == 5}-->
                                    <span class="threadType">{lang thread_debate}</span>
                                <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                                    <span class="threadAttr">$_G[setting][threadsticky][3-$thread[displayorder]]</span>
                                <!--{elseif $thread['digest'] > 0}-->
                                    <span class="threadAttrjh">精华</span>
                                <!--{/if}-->
                                <em  $thread[highlight]>{$thread[subject]}</em>
                            </a>
                        </h5>
                        
                        <div class="nex_teacher_class_mid">
                            <div class="nex_teacher_class_source"><a href="forum.php?mod=forumdisplay&fid={$nex_upids}" target="_blank">{$nex_fromname}</a></div>
                            <div class="nex_teacher_class_date">{$thread[dateline]}</div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_teacher_class_btm">
                             <span><em>{$thread[views]}</em>人学习</span>
                             <!--{if $thread[recommends]}--><span><em>{$thread[recommends]}</em>人推荐</span><!--{/if}-->
                             <div class="clear"></div>
                         </div>
                    </div>	
                    <div class="clear"></div>
                </li>
            <!--{/loop}-->
            <div class="clear"></div>
        </ul>
    </div>
    
</div>
<!--{else}-->
<div class="nex_user_info_box">
	<!--{if $space[uid]}-->
        <!--users-->
        <div class="nex_user_swrapes">
        	<div class="nex_user_swrapes_avatar_bg"></div>
            <div class="nex_user_swrapes_bd">
            	<div class="nex_user_swrapes_avaintel">{$space[username]}<em>{$nex_user_level}</em></div>
                <!--{if $nex_intro}-->
                <div class="nex_UC_author_intro">
                    {$nex_intro}
                </div>
                <!--{/if}-->
                <!--{if $nex_medal_list}-->
                <div class="nex_UC_medalbox">
                    <ul>
                        <!--{loop $nex_medal_list $medal}-->
                        <li>
                            <img src="{$_G['style'][imgdir]}/{$medal['image']}"alt="" id="md_{$medal['medalid']}" onmouseover="showMenu({'ctrlid':this.id, 'menuid':'md_{$medal['medalid']}_menu', 'pos':'12!'});" initialized="true"/>
                            <div class="nex_medaltip_c">
                                <i class="nex_tip_horn"></i>
                                <h4>$medal[name]</h4>
                                <div class="nex_medaldes">$medal[description]</div>
                            </div>
                        </li>
                        <!--{/loop}-->
                        <div class="clear"></div>
                     </ul>
                </div>
                <!--{/if}-->
                <div class="nex_out_term_gave">
                <!--{subtemplate home/follow_user_header}-->
                </div>
                <div class="nex_Gr_User_btm">
                    <!--{if CURMODULE == 'follow'}-->
                    <style type="text/css">
                    .nex_out_term_gave{ display:none;}
                    </style>
                    <!--{subtemplate home/follow_user_header}-->
                    <!--{elseif !$space[self]}-->
                    <div class="nex_Home_tools">
                        <ul>
                            <!--{if helper_access::check_module('follow')}-->
                            <li>
                                <!--{if !ckfollow($space['uid'])}-->
                                    <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]">{lang follow_add}TA</a>
                                <!--{else}-->
                                    <a id="followmod" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]">{lang follow_del}</a>
                                <!--{/if}-->
                            </li>
                            <!--{/if}-->
                            
                            <li>
                                <a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onclick="showWindow('showMsgBox', this.href, 'get', 0)" title="{lang send_pm}">{lang send_pm}</a>
                            </li>
                            <div class="clear"></div>
                        </ul>
                        <!--{if helper_access::check_module('follow')}-->
                        <script type="text/javascript">
                        function succeedhandle_followmod(url, msg, values) {
                            var fObj = $('followmod');
                            if(values['type'] == 'add') {
                                fObj.innerHTML = '{lang follow_del}';
                                fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
                            } else if(values['type'] == 'del') {
                                fObj.innerHTML = '{lang follow_add}TA';
                                fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
                            }
                        }
                        </script>
                        <!--{/if}-->
                    </div>
                    <!--{/if}-->
                </div>
                <div class="nex_user_base">
                	<h5>个人名片</h5>
                    <ul>
                    	<!--{if $nex_province || $nex_adds}-->
                    	<li><em>所在地</em>{$nex_province}{$nex_adds}</li>
                        <!--{/if}-->
                        <!--{if $nex_occu}-->
                        <li><em>职业</em>{$nex_occu}</li>
                        <!--{/if}-->
                        <!--{if $nex_regdate}-->
                        <li><em>加入时间</em><!--{echo date("Y/m/d",{$nex_regdate})}--></li>
                        <!--{/if}-->
                        <!--{if $nex_threads}-->
                        <li><em>主题</em>{$nex_threads}</li>
                        <!--{/if}-->
                    </ul>
                </div>
                <div class="nex_user_base">
                	<h5>所属用户组</h5>
                    <div class="nex_user_group_id"><span>{$nex_user_group[grouptitle]}</span></div>
                </div>
                
            </div>
            <div class="nex_user_swrapes_avt"><!--{avatar($space[uid],big)}--></div>
        </div>
    <!--{/if}-->
    <!--nav-->
    <div class="nex_Home_Navtabs">
        <!--{hook/space_menu_extra}-->
        <ul class="nex_Home_Navs">
            <!--{if helper_access::check_module('follow')}-->
            <li{if CURMODULE == 'follow'} class="a"{/if}><a href="home.php?mod=follow&uid=$space[uid]&do=view&from=space">{lang follow}</a></li>
            <!--{/if}-->
            <li{if $do=='thread'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space">{lang topic}</a></li>
            <!--{if helper_access::check_module('blog')}-->
            <li{if $do=='blog'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space">{lang blog}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('album')}-->
            <li{if $do=='album'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space">{lang album}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('doing')}-->
            <li{if $do=='doing'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space">{lang doing}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('home')}-->
            <li{if $do=='home'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=home&view=me&from=space">{lang feed}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('share')}-->
            <li{if $do=='share'} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space">{lang share}</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('wall')}-->
            <li{if $do==wall} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=wall&from=space">{lang message}</a></li>
            <!--{/if}-->
            <li{if $do==profile} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=profile&from=space">{lang memcp_profile}</a></li>
        </ul>
    </div>
    <div class="clear"></div>
    
</div>
<!--{/if}-->


