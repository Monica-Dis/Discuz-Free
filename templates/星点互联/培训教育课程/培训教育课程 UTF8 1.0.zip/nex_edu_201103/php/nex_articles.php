<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_catids = DB::result(DB::query("SELECT catname FROM ".DB::table('portal_category')." WHERE catid = '$article[catid]'"));
$nex_curtid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$_G[tid]'"));
$nex_catid = DB::result(DB::query("SELECT catid FROM ".DB::table('portal_category')." WHERE catid = '$article[catid]'"));
$nex_relative = DB::fetch_all("SELECT * FROM ".DB::table('portal_article_title')." WHERE uid= '$article[uid]' ORDER BY `dateline` DESC LIMIT 6");
$nex_artitems = DB::fetch_first("SELECT `follower`,`threads`,`following` FROM ".DB::table('common_member_count')." WHERE uid = ".$article[uid]);
$nex_artintro = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$article[uid]'"));
$nex_artical_attchcover = DB::result(DB::query("SELECT pic FROM ".DB::table('portal_article_title')." WHERE aid = '$article[aid]'"));
$nex_artical_attchs = DB::result(DB::query("SELECT attachment FROM ".DB::table('portal_attachment')." WHERE aid = '$article[aid]'"));
$nex_relatives = DB::fetch_all("SELECT * FROM ".DB::table('portal_article_title')." WHERE uid= '$article[uid]' ORDER BY `dateline` DESC LIMIT 4");
$nex_firstdata = DB::result(DB::query("SELECT count(*) FROM ".DB::table('portal_article_title')." WHERE uid= '$article[uid]'"));
function nex_user_follow($followuid) {
	global $_G;
	if(empty($_G['uid'])) return false;
	$var = 'home_follow_'.$_G['uid'].'_'.$followuid;
	if(isset($_G[$var])) return $_G[$var];
	$_G[$var] = false;
	$follow = C::t('home_follow')->fetch_status_by_uid_followuid($_G['uid'], $followuid);
	if(isset($follow[$_G['uid']])) {
		$_G[$var] = true;
	}
	return $_G[$var];
}
//From: Dism_taobao-com
?>
