<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_authorid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]'"));
$nex_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_occu = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_regdate = DB::result(DB::query("SELECT regdate FROM ".DB::table('common_member')." WHERE uid = '$space[uid]'"));
$nex_threads = DB::result(DB::query("SELECT threads FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]'"));
$nex_pos = DB::result(DB::query("SELECT position FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_comp = DB::result(DB::query("SELECT company FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_usercp = DB::result(DB::query("SELECT customstatus FROM ".DB::table('common_member_field_forum')." WHERE uid = '$space[uid]'"));
$nex_intro = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_style = DB::result(DB::query("SELECT interest FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_designer_threads = DB::result(DB::query("SELECT threads FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]'"));
$nex_pricerange = DB::result(DB::query("SELECT affectivestatus FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_exp = DB::result(DB::query("SELECT lookingfor FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_upids = DB::result(DB::query("SELECT fid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'")); $nex_fromname = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$nex_upids'"));
$nex_catids = DB::result(DB::query("SELECT catname FROM ".DB::table('portal_category')." WHERE catid = '$article[catid]'"));
$nexgroup = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$space[uid]'"));
$nex_user_level = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nexgroup'"));

$nex_user_group = DB::fetch_first("SELECT t1.*, t2.* FROM ".DB::table('common_member')." t1 LEFT JOIN ".DB::table('common_usergroup')." t2 ON t1.groupid=t2.groupid WHERE t1.uid ='$space[uid]'");

$nex_user_elements = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]'");
$nex_medal_list=array();
$mls=DB::query("SELECT a.*,b.* FROM ".DB::table("common_member_medal")." a LEFT JOIN ".DB::table("forum_medal")." b on b.medalid=a.medalid WHERE b.`available` <> 0 AND a.`uid`='$space[uid]' ORDER BY b.`displayorder` ASC LIMIT 0,20");
while ($ml=DB::fetch($mls)) {
        $nex_medal_list[]=$ml;
}
//From: Dism_taobao-com
?>
