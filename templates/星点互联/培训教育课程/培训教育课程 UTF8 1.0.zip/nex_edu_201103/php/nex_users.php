<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_user_coins = DB::result(DB::query("SELECT extcredits2 FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]'"));
$nex_self_intros = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_uc_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_uc_gender = DB::result(DB::query("SELECT gender FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_uc_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_uc_occu = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_user_follows = DB::result(DB::query("SELECT follower FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]'"));
$nex_user_element = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]'");
$nex_userid = DB::result(DB::query("SELECT uid FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_dl_uid = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$_G[uid]'"));
$nex_dl_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_dl_uid'"));
$usergroupID = DB::fetch_first("SELECT t1.*, t2.* FROM ".DB::table('common_member')." t1 LEFT JOIN ".DB::table('common_usergroup')." t2 ON t1.groupid=t2.groupid WHERE t1.uid ='$_G[uid]'");

?>
