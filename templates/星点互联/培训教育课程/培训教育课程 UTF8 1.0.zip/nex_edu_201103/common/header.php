<?php echo 'From: DisM.taobao.com';exit;?>
<!--{subtemplate common/header_common}-->
	<meta name="application-name" content="$_G['setting']['bbname']" />
	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
	<!--{/if}-->
	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
	<!--{if widthauto()}-->
		<link rel="stylesheet" id="css_widthauto" type="text/css" href="data/cache/style_{STYLEID}_widthauto.css?{VERHASH}" />
		<script type="text/javascript">HTMLNODE.className += ' widthauto'</script>
	<!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'portal'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
	<link rel="stylesheet" type="text/css" id="diy_common" href="data/cache/style_{STYLEID}_css_diy.css?{VERHASH}" />
	<!--{/if}-->
	<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery1.8.3.min.js"></script>

    <script type="text/javascript">
    	var jq=jQuery.noConflict();
    </script>
    <script language="javascript" type="text/javascript">
		function killErrors() {
		return true;
		}
		window.onerror = killErrors;
    </script>
    <script src="$_G['style'][styleimgdir]/js/nex_pic.js"></script>
    <script src="$_G['style'][styleimgdir]/js/nex_loading.js"></script>
    <link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/js/animate.min.css">
    <script src="$_G['style'][styleimgdir]/js/nexactions.min.js"></script>
    <script>
    var wow = new WOW({boxClass: 'nexactions',});wow.init();
    </script>
    <script src="$_G['style'][styleimgdir]/js/nexinorder.js" type="text/javascript"></script>
	<script type="text/javascript">
        jQuery(function(){
            jQuery('.nex_portboxul').nex_inordered({ item: '.nexwateritems' });
        });
    </script>
    <script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.SuperSlide.2.1.3.js"></script>
    <script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.pagnation.js"></script>
	<script src="$_G['style'][styleimgdir]/js/nex_bubble.js"></script>
    <link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/style.css">
</head>

<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if}" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<!--{template common/header_diy}-->
	<!--{/if}-->
	<!--{if check_diy_perm($topic)}-->
		<!--{template common/header_diynav}-->
	<!--{/if}-->
	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
		$diynav
	<!--{/if}-->
	<!--{if empty($topic) || $topic['useheader']}-->
		<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
			<div class="xi1 bm bm_c">
			    {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a>
			</div>
		<!--{/if}-->
		<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
			<div id="shortcut">
				<span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span>
				{lang shortcut_notice}
				<a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a>

			</div>
			<script type="text/javascript">setTimeout(setShortcut, 2000);</script>
		<!--{/if}-->
		<div id="toptb" class="cl" style="display:none;">
			<!--{hook/global_cpnav_top}-->
			<div class="wp">
				<div class="z">
					<!--{loop $_G['setting']['topnavs'][0] $nav}-->
						<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
					<!--{/loop}-->
					<!--{hook/global_cpnav_extra1}-->
				</div>
				<div class="y">
					<!--{hook/global_cpnav_extra2}-->
				</div>
                <div class="clear"></div>
			</div>
		</div>
		<div class="nex_plugin_reserved">
			<!--{hook/global_cpnav_top}-->
			<div class="w1240">
				<div class="z">
					<!--{hook/global_cpnav_extra1}-->
				</div>
				<div class="y">
					<!--{hook/global_cpnav_extra2}-->
				</div>
                <div class="clear"></div>
			</div>
		</div>
		<!--{if !IS_ROBOT}-->
			<!--{if $_G['uid']}-->
			<ul id="myprompt_menu" class="p_pop" style="display: none;">
				<li><a href="home.php?mod=space&do=pm" id="pm_ntc" style="background-repeat: no-repeat; background-position: 0 50%;"><em class="prompt_news{if empty($_G[member][newpm])}_0{/if}"></em>{lang pm_center}</a></li>

					<li><a href="home.php?mod=follow&do=follower"><em class="prompt_follower{if empty($_G[member][newprompt_num][follower])}_0{/if}"></em><!--{lang notice_interactive_follower}-->{if $_G[member][newprompt_num][follower]}($_G[member][newprompt_num][follower]){/if}</a></li>

				<!--{if $_G[member][newprompt] && $_G[member][newprompt_num][follow]}-->
					<li><a href="home.php?mod=follow"><em class="prompt_concern"></em><!--{lang notice_interactive_follow}-->($_G[member][newprompt_num][follow])</a></li>
				<!--{/if}-->
				<!--{if $_G[member][newprompt]}-->
					<!--{loop $_G['member']['category_num'] $key $val}-->
						<li><a href="home.php?mod=space&do=notice&view=$key"><em class="notice_$key"></em><!--{echo lang('template', 'notice_'.$key)}-->(<span class="rq">$val</span>)</a></li>
					<!--{/loop}-->
				<!--{/if}-->
				<!--{if empty($_G['cookie']['ignore_notice'])}-->
				<li class="ignore_noticeli"><a href="javascript:;" onClick="setcookie('ignore_notice', 1);hideMenu('myprompt_menu')" title="{lang temporarily_to_remind}"><em class="ignore_notice"></em></a></li>
				<!--{/if}-->
				</ul>
			<!--{/if}-->
			<!--{if $_G['uid'] && !empty($_G['style']['extstyle'])}-->
				<div id="sslct_menu" class="cl p_pop" style="display: none;">
					<!--{if !$_G[style][defaultextstyle]}--><span class="sslct_btn" onClick="extstyle('')" title="{lang default}"><i></i></span><!--{/if}-->
					<!--{loop $_G['style']['extstyle'] $extstyle}-->
						<span class="sslct_btn" onClick="extstyle('$extstyle[0]')" title="$extstyle[1]"><i style='background:$extstyle[2]'></i></span>
					<!--{/loop}-->
				</div>
			<!--{/if}-->
            <!--{if $_G['uid']}-->
				<ul id="myitem_menu" class="p_pop" style="display: none;">
					<li><a href="forum.php?mod=guide&view=my">{lang mypost}</a></li>
					<li><a href="home.php?mod=space&do=favorite&view=me">{lang favorite}</a></li>
					<li><a href="home.php?mod=space&do=friend">{lang friends}</a></li>
					<!--{hook/global_myitem_extra}-->
				</ul>
			<!--{/if}-->
			<!--{subtemplate common/header_qmenu}-->
		<!--{/if}-->

		<!--{ad/headerbanner/wp a_h}-->
		<div id="hds" class="nex_hd_common">
            <div class="nex_hd_top" id="nex_hd_top">
            	<div class="w1240">
                    <div class="nex_hd_logo"><!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']"><img src="$_G['style'][styleimgdir]/logo.png"></a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}--></div>
                    <div class="nex_hd_nav">
                    	<!--{eval $mnid = getcurrentnav();}-->
                        <ul>
                        <!--{loop $_G['setting']['navs'] $nav}-->
                            <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
                        <!--{/loop}-->
                        </ul>
                        <!--{hook/global_nav_extra}-->
                    </div>
                    <div class="nex_hd_search"><!--{subtemplate common/pubsearchform}--></div>
                    <div class="nex_hd_member"><!--{template common/header_userstatus}--></div>
                    <div class="clear"></div>
                </div>
            </div>
            <!--{if !$_G[uid]}-->
            <style type="text/css">
            .nex_hd_nav{ width:630px;}
            </style>
            <!--{/if}-->
        	<script type="text/javascript" src="$_G['style'][styleimgdir]/js/nv.js"></script>
            <!--侧边工具栏-->
            <div class="nex_sidetool_bar">
            	<div class="nex_sidetool_bar_inner">
                	<div class="nex_sidetool_bar_top">
                    	<div class="nex_sidetool_bar_item">
                        	<a href="home.php?mod=space&uid=$_G[uid]" target="_blank">
                                <i class="nex_stb_ucenter"></i> 
                                <span class="nex_stb_desc">个人中心</span>
                            </a>
                        </div> 
                        <div class="nex_sidetool_bar_item">
                        	<a href="http://t.cn/Aiux1Qh0" target="_blank">
                                <i class="nex_stb_checkin"></i> 
                                <span class="nex_stb_desc">今日签到</span>
                            </a>
                        </div> 
                        <div class="nex_sidetool_bar_item">
                        	<a href="home.php?mod=space&do=pm&filter=newpm" target="_blank">
                                <i class="nex_stb_pm"></i> 
                                <span class="nex_stb_desc">私信列表</span>
                            </a>
                        </div> 
                        <div class="nex_sidetool_bar_item">
                        	<a href="home.php?mod=space&do=notice&view=mypost" target="_blank">
                                <i class="nex_stb_notice"></i> 
                                <span class="nex_stb_desc">消息中心</span>
                            </a>
                        </div> 
                        <div class="nex_sidetool_bar_item">
                        	<a href="search.php" target="_blank">
                                <i class="nex_stb_search"></i> 
                                <span class="nex_stb_desc">搜索全站</span>
                            </a>
                        </div>
						
                    </div>
                    <div class="nex_sidetool_bar_btm">
						<!--{if file_exists('source/plugin/nex_summitform/inc.php') && $_G['cache']['plugin']['nex_summitform']}-->
                        <div class="nex_sidetool_bar_item nexsd_summit">
                            <a href="javascript:;">
								<b></b>
                                <i class="nex_stb_summit"></i> 
                                <div class="nex_stb_summit_box">
                                	<!--{if file_exists('source/plugin/nex_summitform/inc.php') && $_G['cache']['plugin']['nex_summitform']}-->
									<!--{eval require_once("source/plugin/nex_summitform/inc.php");}-->
									<!--{/if}-->
									<!--{$form}-->
                                </div>
                            </a>
                        </div>
						<!--{/if}-->
                    	<div class="nex_sidetool_bar_item">
                        	<a href="javascript:;">
                                <i class="nex_stb_qrcode"></i> 
                                <div class="nex_stb_qrcode_box">
                                	<img src="$_G['style'][styleimgdir]/sidetools/q_code.jpg">
                                    <p>扫码关注官方微信</p>
                                </div>
                            </a>
                        </div> 
                        <div class="nex_sidetool_bar_item">
                        	<a href="javascript:;">
                                <i class="nex_stb_appcode"></i> 
                                <div class="nex_stb_appcode_box">
                                	<img src="$_G['style'][styleimgdir]/sidetools/cell_code.jpg">
                                    <p>扫码下载APP</p>
                                </div>
                            </a>
                        </div>
                        <div class="nex_sidetool_bar_item" id="nex_rolltoptop">
                            <i class="nex_stb_scrolltop"></i> 
                            <span class="nex_stb_desc">返回顶部</span>
                        </div> 
                        <script type="text/javascript">
						 jQuery(function(){
							jQuery("#nex_rolltoptop").hide();
							//当滚动条的位置处于距顶部50像素以下时，跳转链接出现，否则消失
							jQuery(function() {
							  jQuery(window).scroll(function() {
								if (jQuery(window).scrollTop() > 50) {
								  jQuery("#nex_rolltoptop").fadeIn(200);
								} else {
								  jQuery("#nex_rolltoptop").fadeOut(200);
								}
							  });
							  //当点击跳转链接后，回到页面顶部位置
							  jQuery("#nex_rolltoptop").click(function() {
								jQuery('body,html').animate({
								  scrollTop: 0
								},
								500);
								return false;
							  });
							});
						  })
						</script>
                    </div>
                </div>
            </div>
			<div class="wp">
				<div class="hdc cl">
				</div>
				<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
					<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
					<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
						 <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
						 <li>$module[url]</li>
						 <!--{/if}-->
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
				$_G[setting][menunavs]
				<div id="mu" class="cl">
				<!--{if $_G['setting']['subnavs']}-->
					<!--{loop $_G[setting][subnavs] $navid $subnav}-->
						<!--{if $_G['setting']['navsubhover'] || $mnid == $navid}-->
						<ul class="cl {if $mnid == $navid}current{/if}" id="snav_$navid" style="display:{if $mnid != $navid}none{/if}">
						$subnav
						</ul>
						<!--{/if}-->
					<!--{/loop}-->
				<!--{/if}-->
				</div>
				<!--{ad/subnavbanner/a_mu}-->
				
			</div>
        </div>

		<!--{hook/global_header}-->
	<!--{/if}-->

	<div id="wp" class="wp">
    
		
