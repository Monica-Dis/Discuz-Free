<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if empty($_G['uploadjs'])}-->
	<link rel="stylesheet" type="text/css" href="{STATICURL}js/webuploader/webuploader.css?{VERHASH}">
	<script src="{STATICURL}js/webuploader/webuploader.min.js?{VERHASH}"></script>
	<script type="text/javascript" src="{$_G[setting][jspath]}webuploader.js?{VERHASH}"></script>
	{eval $_G['uploadjs'] = 1;}
<!--{/if}-->
