<?php echo '应用更新支持：https://dism.taobao.com';exit;?>
<!--{block diynav}-->
<a href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" title="DIY操作">DIY</a>
<!--{/block}-->
