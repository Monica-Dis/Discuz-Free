<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--门户结构-->
<!--首页幻灯-->
<div class="nex_fullSlide">
	<!--[diy=nex_fullSlide]--><div id="nex_fullSlide" class="area"></div><!--[/diy]-->
    
    <div class="hd"><ul></ul></div>
</div>
<script type="text/javascript">
    jQuery(".nex_fullSlide").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"left",  autoPlay:true, interTime:5000, autoPage:true, trigger:"click" });
</script>
<!--首页推荐-->
<div class="nex_recommendTag_wrap">
	<div class="w1240">
        <div class="nex_recommend_skill">
            <div class="nex_tag_head">
                <img src="template/nex_edu_201103/neoconex/index/nex_essential_skill_icon.png" alt="必备技能">
                <span>必备技能</span>
                <div class="clear"></div>
            </div>
            <div class="nex_tag_cons">
            	<!--[diy=nex_tag_cons1]--><div id="nex_tag_cons1" class="area"></div><!--[/diy]-->
                
            </div>
        </div>
        <div class="nex_hot_course">
        	<div class="nex_tag_head">
                <img src="template/nex_edu_201103/neoconex/index/nex_hot_course_icon.png" alt="热搜教程">
                <span>热搜教程</span>
                <div class="clear"></div>
            </div>
            <div class="nex_tag_cons">
            	<!--[diy=nex_tag_cons2]--><div id="nex_tag_cons2" class="area"></div><!--[/diy]-->
                
            </div>
        </div>
        <div class="nex_career_path">
        	<div class="nex_tag_head">
                <img src="template/nex_edu_201103/neoconex/index/nex_career_path_icon.png" alt="职业路线">
                <span>职业路线</span>
                <div class="clear"></div>
            </div>
            <div class="nex_tag_cons">
            	<!--[diy=nex_tag_cons3]--><div id="nex_tag_cons3" class="area"></div><!--[/diy]-->
                
            </div>
        </div>
        <div class="clear"></div>
    </div>
</div>
<!--系列课程-->
<div class="nex_series_course">
	<div class="w1240">
    	<div class="nex_series_course_ads">
        	<ul>
            	<!--[diy=nex_series_course_ads]--><div id="nex_series_course_ads" class="area"></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
        </div>
    </div>
</div>
<!--行业专题课程-->
<div class="nex_software_box">
	<div class="w1240">
    	<div class="nex_common_index_top">
        	<span class="nex_hot_indus_icon">热门行业专题课程</span>
            <em>职业晋升系统化学习，快来了解一下哪个课程适合你吧</em>
            <div class="clear"></div>
        </div>
    	<div class="nex_zhuanti_box">
            <ul>
            	<!--[diy=nex_zhuanti_box]--><div id="nex_zhuanti_box" class="area"></div><!--[/diy]-->
                
                <div class="clear"></div>
            </ul>
        </div>
    </div>
</div>
<!--热门推荐课程-->
<div class="nex_common_index_columns">
	<div class="w1240">
    	<div class="nex_common_index_top">
        	<span class="nex_hot_class_icon">热门推荐课程</span>
            <ul>
            	<!--[diy=nex_common_index_top1]--><div id="nex_common_index_top1" class="area"></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
            <div class="clear"></div>
        </div>
        <div class="nex_index_course_grids">
        	<ul>
            	<!--[diy=nex_index_course_grids1]--><div id="nex_index_course_grids1" class="area"></div><!--[/diy]-->
                
                <div class="clear"></div>
            </ul>
        </div>
        
    </div>
</div>
<!--免费课程-->
<div class="nex_common_index_columns nex_common_index_columns_free">
	<div class="w1240">
    	<div class="nex_common_index_top">
        	<span class="nex_free_class_icon">免费课程</span>
            <em>精选免费好课，入门好选择</em>
            <div class="clear"></div>
        </div>
        <div class="nex_index_course_grids nex_index_course_grids_free">
        	<ul>
            	<!--[diy=nex_index_course_grids2]--><div id="nex_index_course_grids2" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
            </ul>
        </div>
	</div>
</div>
<!--设计创作课程-->
<div class="nex_common_index_columns">
	<div class="w1240">
    	<div class="nex_common_index_top">
        	<span>设计创作</span>
            <ul>
            	<!--[diy=nex_common_index_top2]--><div id="nex_common_index_top2" class="area"></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
            <div class="clear"></div>
        </div>
        <div class="nex_index_course_grids nex_index_course_grids_free">
        	<ul>
            	<!--[diy=nex_index_course_grids3]--><div id="nex_index_course_grids3" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
            </ul>
        </div>
	</div>
</div>
<!--IT互联网课程-->
<div class="nex_common_index_columns nex_common_index_columns_free">
	<div class="w1240">
    	<div class="nex_common_index_top">
        	<span>IT互联网</span>
            <ul>
            	<!--[diy=nex_common_index_top3]--><div id="nex_common_index_top3" class="area"></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
            <div class="clear"></div>
        </div>
        <div class="nex_index_course_grids nex_index_course_grids_free">
        	<ul>
            	<!--[diy=nex_index_course_grids4]--><div id="nex_index_course_grids4" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
            </ul>
        </div>
	</div>
</div>
<!--职场技能课程-->
<div class="nex_common_index_columns">
	<div class="w1240">
    	<div class="nex_common_index_top">
        	<span>职场技能</span>
            <ul>
            	<!--[diy=nex_common_index_top4]--><div id="nex_common_index_top4" class="area"></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
            <div class="clear"></div>
        </div>
        <div class="nex_index_course_grids nex_index_course_grids_free">
        	<ul>
            	<!--[diy=nex_index_course_grids5]--><div id="nex_index_course_grids5" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
            </ul>
        </div>
	</div>
</div>
<!--外语语言课程-->
<div class="nex_common_index_columns nex_common_index_columns_free">
	<div class="w1240">
    	<div class="nex_common_index_top">
        	<span>外语语言</span>
            <ul>
            	<!--[diy=nex_common_index_top5]--><div id="nex_common_index_top5" class="area"></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
            <div class="clear"></div>
        </div>
        <div class="nex_index_course_grids nex_index_course_grids_free">
        	<ul>
            	<!--[diy=nex_index_course_grids6]--><div id="nex_index_course_grids6" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
            </ul>
        </div>
	</div>
</div>
<!--金融投资课程-->
<div class="nex_common_index_columns">
	<div class="w1240">
    	<div class="nex_common_index_top">
        	<span>金融投资</span>
            <ul>
            	<!--[diy=nex_common_index_top6]--><div id="nex_common_index_top6" class="area"></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
            <div class="clear"></div>
        </div>
        <div class="nex_index_course_grids nex_index_course_grids_free">
        	<ul>
            	<!--[diy=nex_index_course_grids7]--><div id="nex_index_course_grids7" class="area"></div><!--[/diy]-->
                <div class="clear"></div>
            </ul>
        </div>
        <div class="nex_vip_ads"><!--[diy=nex_vip_ads]--><div id="nex_vip_ads" class="area"></div><!--[/diy]--></div>
	</div>
</div>
<!--实力讲师-->
<div class="nex_common_index_columns">
	<div class="w1240">
    	<div class="nex_common_index_top">
        	<span class="nex_hot_teacher_icon">实力讲师</span>
            <em>丰富实战经验的实力讲师，为您传授全面设计方法</em>
            <div class="clear"></div>
        </div>
        <div class="nex_teacher_box">
        	<div class="nex_teacher_slider">
            	<div class="nex_teacher_scrollBox">
                    <div class="nex_teacher_ohbox">
                    	<!--[diy=nex_teacher_ohbox]--><div id="nex_teacher_ohbox" class="area"></div><!--[/diy]-->
                        
                    </div>
                    <div class="nex_pageBtn">
                        <span class="prev"></span>
                        <span class="next"></span>
                    </div>
                    <ul class="list"><li></li><li></li></ul>
            	</div>
            	<script type="text/javascript">jQuery(".nex_teacher_scrollBox").slide({ titCell:".list li", mainCell:".piclist", effect:"left",vis:5,scroll:5, delayTime:800,trigger:"click",easing:"easeOutCirc"});</script>
            </div>
            
        </div>
	</div>
</div>
<!--广告-->
<div class="nex_series_course">
	<div class="w1240">
    	<div class="nex_index_ads"><!--[diy=nex_index_ads]--><div id="nex_index_ads" class="area"></div><!--[/diy]--></div>
    	<div class="nex_series_course_ads">
        	<ul>
            	<!--[diy=nex_series_course_ads2]--><div id="nex_series_course_ads2" class="area"></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
        </div>
    </div>
</div>
<!--介绍-->
<div class="nex_statistic_container">
	<div class="w1240">
    	<div class="nex_sta_col_item">
        	<ul>
            	<!--[diy=nex_sta_col_item]--><div id="nex_sta_col_item" class="area"></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
        </div>
    </div>
</div>    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
   
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->


