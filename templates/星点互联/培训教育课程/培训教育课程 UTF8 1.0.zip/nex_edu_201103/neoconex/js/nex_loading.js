jQuery(function() {
	var echo_list = function(jQuerychildren, n) {
	var jQueryhiddenChildren = jQuerychildren.filter(":hidden");
	var cnt = jQueryhiddenChildren.length;
	for (var i = 0; i < n && i < cnt; i++) {
		jQueryhiddenChildren.eq(i).fadeIn();
	}
	return cnt - n; 
}

jQuery(".nex_finance_newslists").each(function() {
	var pagenum = jQuery(this).attr("pagenum") || 25;//每页显示数量
	var jQuerychildren = jQuery(this).children();
	if (jQuerychildren.length > pagenum) {
		for (var i = pagenum; i < jQuerychildren.length; i++) {
			 jQuerychildren.eq(i).hide();
		}
		jQuery("<div class=\"nex_load_more\"><a id=\"nex_added_plus\" class=\"nex_click_more\">点击加载更多</a></div>").insertAfter(jQuery(this)).click(function() {
			if (echo_list(jQuerychildren, pagenum) <= 0) {
				jQuery(this).html("<p id=\"more\" class=\"nex_full_loaded\">已经到底啦~</p>");
			};
		});
	}
});
});
