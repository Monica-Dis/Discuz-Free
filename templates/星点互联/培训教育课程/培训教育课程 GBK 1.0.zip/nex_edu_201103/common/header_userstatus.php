<?php echo 'From: DisM.taobao.com';exit;?>
<div class="nexlogin_index">                 
		<!--{if $_G['uid']}-->
        <!--{eval include 'template/nex_edu_201103/php/nex_users.php'}-->
        <div class="nexallmember">
            <div id="nexmemberinfo">
            	<div class="nex_member_top_notice">
                	<dl>
                    	<dd class="nex_member_notice_icon">
                        	<a href="home.php?mod=space&do=pm&filter=newpm"target="_blank" title="�鿴֪ͨ">
                                <!--{if $_G[member][newpm]}-->
                                <em></em>
                                <!--{/if}-->
                            </a>
                        </dd>
                        <dd class="nex_member_pm_icon">
                        	<a href="home.php?mod=space&do=pm&filter=newprompt"target="_blank" title="�鿴��Ϣ">
                                <!--{if $_G[member][newprompt]}-->
                                <em></em>
                                <!--{/if}-->
                            </a>
                        </dd>
                        <div class="clear"></div>
                    </dl>
                    
                </div>
                <div class="nex_member_top_space">
                    <a href="home.php?mod=space&uid=$_G[uid]&do=profile&from=space" target="_blank" title="{lang visit_my_space}">
                        <div class="nex_member_avator">
                            <!--{avatar($_G[uid],big)}-->
                            <span>{$_G[member][username]}</span>
                            <div class="clear"></div>
                        </div>
                    </a>
                </div>
                <div class="clear"></div>
            </div>
            <div id="nexmembercontent">
                <div class="nex_member_incontent">
                	<div class="nex_member_inleft">
                        <div class="nex_member_inavators">
                            <a href="home.php?mod=space&uid=$_G[uid]&do=profile&from=space" target="_blank" title="{lang visit_my_space}">
                                <!--{avatar($_G[uid],big)}-->
                                <!--{if $nex_uc_gender == '1'}-->
                                <i></i>
                                <!--{elseif $nex_uc_gender == '2'}-->
                                <em></em>
                                <!--{else}-->
                                <!--{/if}-->
                            </a>
                        </div>
                        <!--{if check_diy_perm($topic)}-->
                        <div class="nex_member_inner_diy">{$diynav}</div>
                        <!--{/if}-->
                    </div>
                	<div class="nex_member_inothers">
                    	<div class="nex_member_in_name">
                            <a href="home.php?mod=spacecp&ac=avatar" target="_blank" title="��������">
                            	{$_G[member][username]}
                                <i>ID:{$nex_userid}</i>
                                <!--{if $nex_dl_levels == '0'}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_0.png" />
                                <!--{elseif $nex_dl_levels == '1'}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_1.png" />
                                <!--{elseif $nex_dl_levels == '2'}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_2.png" />
                                <!--{elseif $nex_dl_levels == '3'}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_3.png" />
                                <!--{elseif $nex_dl_levels == '4'}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_4.png" />
                                <!--{elseif $nex_dl_levels == '5'}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_5.png" />
                                <!--{elseif $nex_dl_levels == '6'}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_6.png" />
                                <!--{elseif $nex_dl_levels == '7'}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_7.png" />
                                <!--{elseif $nex_dl_levels == '8'}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_8.png" />
                                <!--{else}-->
                                <img src="$_G['style'][styleimgdir]/usermenu/nex_level_9.png" />
                                <!--{/if}-->
                                <em></em>
                                <div class="clear"></div>
                            </a>
                        </div>
                        <div class="nex_member_in_status">
                        	<span>��ע��{$nex_user_element[following]}</span>
                            <span>��˿��{$nex_user_element[follower]}</span>
                            <span>���֣�{$_G[member][credits]}</span>
                        </div>
                        <div class="nex_member_in_intro">
                        	<!--{if $nex_self_intros}-->
                            {$nex_self_intros}
                            <!--{else}-->
                            ����һ������ʲôҲû�����¡�
                            <!--{/if}-->
                        </div>
                        <div class="nex_member_in_btms">
                        	<dl>
                                <dd class="nex_member_btn_2">
                                	<a href="home.php?mod=spacecp&ac=avatar"target="_blank">��������</a>
                                </dd>
                                <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
                                <dd class="nex_member_btn_1">
                                    <a href="admin.php" target="_blank">{lang admincp}</a>
                                </dd>
                                <!--{else}-->
                                <dd class="nex_member_btn_1">
                                    <a href="forum.php?mod=guide&view=my" target="_blank">����</a>
                                </dd>
                                <!--{/if}-->
                                <dd class="nex_member_btn_1">
                                    <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">�˳�</a> 
                                </dd>
                                <div class="clear"></div>
                            </dl>
                        </div>
                        <div class="nex_member_content_hook">
                            <!--{hook/global_usernav_extra1}--><!--{hook/global_usernav_extra2}--><!--{hook/global_usernav_extra3}--><!--{hook/global_usernav_extra4}-->
                            <div class="clear"></div>
                        </div>   
                    </div>
                	<div class="clear"></div>
                </div>
            </div>
            <script type="text/javascript">
                jQuery("#nexmemberinfo").hover(
                    function(){
                        jQuery(this).siblings("#nexmembercontent").show();
                        },
                    function(){
                        jQuery(this).siblings("#nexmembercontent").hide();
                        })
                jQuery("#nexmembercontent").hover(
                    function(){
                        jQuery(this).show();
                        jQuery(this).siblings("#nexmemberinfo").addClass("nex_curs");
                        },
                    function(){
                        jQuery(this).hide();
                        jQuery(this).siblings("#nexmemberinfo").removeClass("nex_curs");
                        })
            </script>
        </div>
   		<ul>
     	<!--{elseif !empty($_G['cookie']['loginuser'])}-->
            <li><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></li>
            <li><a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang activation}</a></li>
            <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
    	<!--{elseif !$_G[connectguest]}-->
            <div class="nexmain_dls_layer">
                <ul>
                	<li><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">��½</a></li>
                    <li class="nex_sepline">|</li>
                    <li><a href="member.php?mod={$_G[setting][regname]}">ע��</a></li>
                    <div class="clear"></div>
                </ul>
            </div>
     	<!--{else}-->
            <div class="nex_qq_kuang">
                <div class="nex_qq_kuang_before">QQ����</div>
                <div class="nex_qq_kuang_after">
                    <div id="um">
                        <div class="avt y"><!--{avatar(0,small)}--></div>
                        <div class="nex_qq_lines">
                            <strong class="vwmy qq">{$_G[member][username]}</strong>
                            <!--{hook/global_usernav_extra1}-->
                            <span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
                        </div>
                        <div class="nex_qq_lines">
                            <a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a>
                            <span class="pipe">|</span>{lang usergroup}: $_G[group][grouptitle]
                        </div>
                    </div>
                </div>
                <script type="text/javascript">
                    jq(".nex_qq_kuang").hover(
                        function(){
                            jq(this).children(".nex_qq_kuang_after").show();
                            },
                        function(){
                            jq(this).children(".nex_qq_kuang_after").hide();
                            })
                    
                </script>
            </div>
        <!--{/if}-->
    	</ul>
</div>