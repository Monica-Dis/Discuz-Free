<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}

$nex_attachs = DB::result(DB::query("SELECT attachment FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]'"));
$nex_sortid = DB::result(DB::query("SELECT sortid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
$firstpids = intval($post['pid']);
$nex_attnums = substr($thread[tid], -1); $nex_threadlistspic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$thread[tid]' AND pid = '$firstpids' AND isimage = '1' ORDER BY `aid` ASC LIMIT 9");
$nex_pic_range = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$thread[tid]' AND isimage = '1'"));

require_once(DISCUZ_ROOT."./source/function/function_post.php");
$summary_echo = messagecutstr(DB::result_first('SELECT `message` FROM '.DB::table('forum_post').' WHERE `tid` ='.$thread[tid].' AND `first` =1'),400);
$nex_authorid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]'"));
$nex_school_name = DB::result(DB::query("SELECT graduateschool FROM ".DB::table('common_member_profile')." WHERE uid = $nex_authorid")); 
$nex_gender = DB::result(DB::query("SELECT gender FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authorid'"));
$nex_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_occus = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_upids = DB::result(DB::query("SELECT fid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'")); $nex_fromname = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$nex_upids'"));
$nex_blogpic = DB::result(DB::query("SELECT pic FROM ".DB::table('home_blogfield')." WHERE blogid = '$blog[blogid]'"));
$nex_threaddate = DB::result(DB::query("SELECT dateline FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));

$nex_authoridx = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'")); 
$nex_bbs_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_bbs_occu = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_bbs_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_threadID = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$thread[fid]'"));
$usergroupID = DB::fetch_first("SELECT t1.*, t2.* FROM ".DB::table('common_member')." t1 LEFT JOIN ".DB::table('common_usergroup')." t2 ON t1.groupid=t2.groupid WHERE t1.uid ='$nex_authoridx'");

$nex_thread_typeid = DB::result(DB::query("SELECT typeid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_thread_type = DB::result(DB::query("SELECT name FROM ".DB::table('forum_threadclass')." WHERE typeid = '$nex_thread_typeid'"));
$nex_thread_fid = DB::result(DB::query("SELECT fid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_thread_fidname = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$nex_thread_fid'"));

?>