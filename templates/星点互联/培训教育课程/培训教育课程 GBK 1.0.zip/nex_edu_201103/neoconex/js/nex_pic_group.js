jQuery(function(jQuery){
  jQuery('.nex_group_digest_mid_img').each(function(){
  var imgsrc=jQuery(this).find(".nex_index_showpic").attr('src');
  if (imgsrc=="static/image/common/nophoto.gif") {
  jQuery(this).css('display','none');
  jQuery(this).parent().addClass('nex_main_line_mid_long');
  }
})
})
