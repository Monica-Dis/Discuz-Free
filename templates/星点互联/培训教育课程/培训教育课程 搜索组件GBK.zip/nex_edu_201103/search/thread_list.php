<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>

<div class="tl">
    <!--{ad/search/y mtw}-->
    <!--{if empty($threadlist)}-->
        <div class="nex_emp_notice">
        	<em></em>
        </div>
    <!--{else}-->
           <div class="nex_showresults_class">
                <ul>
                    <!--{loop $threadlist $nex_search_thread}-->
                    	
                        <!--{if $nex_search_thread['sortid'] != 0}-->
                        <div class="nex_result_title nex_result_title_class">�γ��������</div>
                        <li>
                            <a href="forum.php?mod=viewthread&tid=$nex_search_thread[realtid]&highlight=$index[keywords]" target="_blank">
                            	<!--{eval include 'template/nex_edu_201103/php/nex_search.php'}-->
                                <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
                                <div class="nex_course_coverimg" style="background:url(<!--{if $nex_threadsinpivs['remote']}-->                    			
                                    {$_G['setting']['ftp']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                                    <!--{else}-->         			
                                    {$_G['setting']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                                    <!--{/if}-->) center no-repeat; background-size:cover;">
                                    <span></span>
                                </div>
                                <!--{/loop}-->
                                <div class="nex_course_coverinfo">
                                    <h5>{$nex_search_thread[subject]}</h5>
                                    <div class="nex_course_infobtm">
                                        <span>{$nex_search_thread[author]}</span>
                                        <em>{$nex_search_thread[views]}����ѧ</em>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </a>
                        </li>  
                        <!--{/if}-->
                    <!--{/loop}-->
                    <div class="clear"></div>
                </ul>
        	</div>
            <div class="nex_thread_sort_qna">
            	<ul>
                <!--{loop $threadlist $nex_search_qna}-->
                    <!--{if $nex_search_qna['special'] == 3}-->
                    <div class="nex_result_title nex_result_title_qna">�����ʴ�</div>
                    <li>
                    	<!--{if $nex_search_qna['price'] > 0}-->
                    	<div class="nex_scqna_price">
                        	<em>$nex_search_qna['price']</em>
                            <span>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</span>
                        </div>
                        <!--{else}-->
                        <div class="nex_scqna_pricex">
                        	<i>�ѽ��</i>
                        </div>
                        <!--{/if}-->
                        <div class="nex_scresult_qna">
                        	<h2><a href="forum.php?mod=viewthread&tid=$nex_search_qna[realtid]&highlight=$index[keywords]" target="_blank">$nex_search_qna[subject]</a></h2>
                            <div class="nex_scresult_mid">
                            	<span>$nex_search_qna[replies]<em>�ش�</em></span><i>-</i>
                                <span>����<a href="forum.php?mod=forumdisplay&fid=$nex_search_qna[fid]" target="_blank">$nex_search_qna[forumname]</a></span>
                            </div>
                            <div class="nex_scresult_sums">$nex_search_qna[message]</div>
                            <div class="nex_scresult_btm">
                            	<span>
                                	<!--{if $nex_search_qna['authorid'] && $nex_search_qna['author']}-->
                                        <a href="home.php?mod=space&uid=$nex_search_qna[authorid]" target="_blank">$nex_search_qna[author]</a>
                                    <!--{else}-->
                                        <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$nex_search_qna[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
                                    <!--{/if}-->
                                </span>
                                <i>-</i>
                                <em>$nex_search_qna[dateline]</em>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </li>
                    <!--{/if}-->
                   
                <!--{/loop}-->
                </ul>
        	</div>
        	<div class="nex_thread_sort_normal">
            	<ul>
                	<!--{loop $threadlist $thread}-->
                    <!--{if $thread['special'] != 3 && $thread['sortid'] == 0}-->
                    <div class="nex_result_title nex_result_title_other">��������</div>
                    <li>
                    	<!--{eval include 'template/nex_edu_201103/php/nex_multiops.php'}-->
                        <!--{if $nex_attachs == 0}-->
                        <div class="nex_scresult_other">
                            <h2><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">$thread[subject]</a></h2>
                            <div class="nex_scresult_sums">$thread[message]</div>
                            <div class="nex_scresult_midx">
                                <span>
                                    <!--{if $thread['authorid'] && $thread['author']}-->
                                        <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">$thread[author]</a>
                                    <!--{else}-->
                                        <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
                                    <!--{/if}-->
                                </span>
                                <i>-</i>
                                <em>$thread[dateline]</em>
                                <i>-</i>
                                <span>$thread[views]<em>�鿴</em><i>-</i>$thread[replies]<em>�ظ�</em></span>
                                <i>-</i>
                                <span>����<a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$thread[forumname]</a></span>
                                <div class="clear"></div>
                            </div>
                        </div>
                        <!--{else}-->
                            <!--{eval include 'template/nex_edu_201103/php/nex_search_ot.php'}-->
                            <!--{if $nex_threadlistspic}-->
                            <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
                            <div class="nex_search_showpics"><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank" style="background:url(
                            <!--{if $nex_threadsinpivs['remote']}-->                    			
                            {$_G['setting']['ftp']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                            <!--{else}-->         			
                            {$_G['setting']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
                            <!--{/if}-->) center no-repeat; background-size:cover;"></a></div>
                            <div class="nex_sciterm_info">
                            	<h5><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">$thread[subject]</a></h5>
                                <div class="nex_scresult_sums">$thread[message]</div>
                                <div class="nex_scresult_midx">
                                	<span>
                                        <!--{if $thread['authorid'] && $thread['author']}-->
                                            <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">$thread[author]</a>
                                        <!--{else}-->
                                            <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
                                        <!--{/if}-->
                                    </span>
                                    <i>-</i>
                                    <em>$thread[dateline]</em>
                                    <i>-</i>
                                    <span>$thread[views]<em>�鿴</em><i>-</i>$thread[replies]<em>�ظ�</em></span>
                                    <i>-</i>
                                    <span>����<a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$thread[forumname]</a></span>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="clear"></div>
                            <!--{/loop}-->
                            <!--{else}-->
                            <div class="nex_scresult_other">
                                <h2><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">$thread[subject]</a></h2>
                                <div class="nex_scresult_sums">$thread[message]</div>
                                <div class="nex_scresult_midx">
                                	<span>
                                        <!--{if $thread['authorid'] && $thread['author']}-->
                                            <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">$thread[author]</a>
                                        <!--{else}-->
                                            <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
                                        <!--{/if}-->
                                    </span>
                                    <i>-</i>
                                    <em>$thread[dateline]</em>
                                    <i>-</i>
                                    <span>$thread[views]<em>�鿴</em><i>-</i>$thread[replies]<em>�ظ�</em></span>
                                    <i>-</i>
                                    <span>����<a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$thread[forumname]</a></span>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <!--{/if}-->
                        <!--{/if}-->
                    	
                    </li>
                    <!--{/if}-->
                    <!--{/loop}-->
                </ul>
            	
        	</div>
    <!--{/if}-->
    <!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>