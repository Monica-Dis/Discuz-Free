<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}


$nex_attnums = substr($nex_search_thread[tid], -1); $nex_threadlistspic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$nex_search_thread[tid]' AND isimage = '1' ORDER BY `aid` ASC LIMIT 1");

?>
