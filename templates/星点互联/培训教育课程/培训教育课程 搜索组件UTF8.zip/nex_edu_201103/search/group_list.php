<?php echo 'Copyright@Neoconex星点互联';exit;?>
<div>
	<!--{ad/search/y mtw}-->
<!--{if $viewgroup}-->
	<!--{if empty($grouplist)}-->
		<div class="nex_emp_notice">
        	<em></em>
        </div>
	<!--{else}-->
		<div class="nex_view_grouplist nex_group_list">
        	<div class="nex_sc_group_title">群组列表</div>
        	<ul>
			<!--{loop $grouplist $group}-->
				<li>
					<div class="nex_grouppic_cover"><a href="forum.php?mod=group&fid=$group[fid]" target="_blank"><img src="$group[icon]" alt="" /></a></div>
                    <div class="nex_group_intels">
                    	<h5><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><!--{if $group['gviewperm'] == 1}-->({lang public})<!--{/if}--></h5>
                        <p>{lang member}: $group[membernum], {lang threads}: $group[threads]</p>
                        <p>{lang credits}: $group[commoncredits], {lang creating_time}: $group[dateline]</p>
                    </div>
                    <div class="clear"></div>
				</li>
			<!--{/loop}-->
            <div class="clear"></div>
            </ul>
		</div>
		<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
	<!--{/if}-->
<!--{else}-->
	<!--{if !empty($grouplist) && $page < 2}-->
		<div class="nex_group_list">
        	<div class="nex_sc_group_title">群组列表</div>
        	<ul>
			<!--{loop $grouplist $group}-->
				<li>
					<div class="nex_grouppic_cover"><a href="forum.php?mod=group&fid=$group[fid]" target="_blank"><img src="$group[icon]" alt="" /></a></div>
					<div class="nex_group_intels">
                    	<h5><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><!--{if $group['gviewperm'] == 1}-->({lang public})<!--{/if}--></h5>
                        <p>{lang member}: $group[membernum], {lang threads}: $group[threads]</p>
                        <p>{lang credits}: $group[commoncredits], {lang creating_time}: $group[dateline]</p>
                    </div>
                    <div class="clear"></div>
				</li>
			<!--{/loop}-->
            <div class="clear"></div>
            </ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($threadlist)}-->
		<div class="nex_groupthreadlist">
        	<div class="nex_sc_group_thread_title">群组帖子</div>
			<ul>
				<!--{loop $threadlist $nex_search_thread}-->
                <!--{eval include 'template/nex_edu_201103/php/nex_search.php'}-->
                <li>
                    <!--{if $nex_threadlistspic}-->
                    <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
                    <div class="nex_group_showpics"><a href="forum.php?mod=viewthread&tid=$nex_search_thread[realtid]&highlight=$index[keywords]" target="_blank"  style=" background:url(<!--{if $nex_threadsinpivs['remote']}-->                    			
{$_G['setting']['ftp']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
<!--{else}-->         			
{$_G['setting']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
<!--{/if}-->) center no-repeat; background-size:cover;"></a></div>
                    <!--{/loop}-->
                    <div class="nex_group_showinfos">
                        <h3><a href="forum.php?mod=viewthread&tid=$nex_search_thread[realtid]&highlight=$index[keywords]" target="_blank">$nex_search_thread[subject]</a></h3>
                        <div class="nex_showfrom"><a href="forum.php?mod=forumdisplay&fid=$nex_search_thread[fid]" target="_blank">$nex_search_thread[forumname]</a></div>
                        <div class="nex_showbtms">
                        	<div class="nex_showavator">
                            	<!--{if $nex_search_thread['authorid'] && $nex_search_thread['author']}-->
								<a href="home.php?mod=space&uid=$nex_search_thread[authorid]" target="_blank">
                                	<!--{avatar($nex_search_thread[authorid],small)}-->
                                	<em>$nex_search_thread[author]</em>
                                    <div class="clear"></div>
                                </a>
                                <!--{else}-->
                                    <!--{if $_G['forum']['ismoderator']}-->
                                    <a href="home.php?mod=space&uid=$nex_search_thread[authorid]" target="_blank">
                                    	<img src="$_G['style'][styleimgdir]/search/anonymous.png" />
                                        <em>{lang anonymous}</em>
                                        <div class="clear"></div>
                                    </a>
                                    <!--{else}-->
                                    <em>{lang anonymous}</em>
                                    <div class="clear"></div>
                                    <!--{/if}-->
                                <!--{/if}-->
                            </div>
                            <div class="nex_showintels">
                                <span class="nex_showintels_view">$nex_search_thread[views]{lang a_visit}</span><i>-</i>
                                <!--{if $nex_search_thread[replies]}--><span class="nex_showintels_reply">$nex_search_thread[replies]{lang a_comment_thread}</span><i>-</i><!--{/if}-->
                                <span class="nex_showintels_date">$nex_search_thread[dateline]</span>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
				</li>
                <!--{else}-->
                <div class="nex_group_showinfos_null">
                    <h3><a href="forum.php?mod=viewthread&tid=$nex_search_thread[realtid]&highlight=$index[keywords]" target="_blank">$nex_search_thread[subject]</a></h3>
                    <div class="nex_showfrom"><a href="forum.php?mod=forumdisplay&fid=$nex_search_thread[fid]" target="_blank">$nex_search_thread[forumname]</a></div>
                    <div class="nex_showbtms">
                        <div class="nex_showavator">
                            <!--{if $nex_search_thread['authorid'] && $nex_search_thread['author']}-->
                            <a href="home.php?mod=space&uid=$nex_search_thread[authorid]" target="_blank">
                                <!--{avatar($nex_search_thread[authorid],small)}-->
                                <em>$nex_search_thread[author]</em>
                                <div class="clear"></div>
                            </a>
                            <!--{else}-->
                                <!--{if $_G['forum']['ismoderator']}-->
                                <a href="home.php?mod=space&uid=$nex_search_thread[authorid]" target="_blank">
                                    <img src="$_G['style'][styleimgdir]/search/anonymous.png" />
                                    <em>{lang anonymous}</em>
                                    <div class="clear"></div>
                                </a>
                                <!--{else}-->
                                <em>{lang anonymous}</em>
                                <div class="clear"></div>
                                <!--{/if}-->
                            <!--{/if}-->
                        </div>
                        <div class="nex_showintels">
                            <span class="nex_showintels_view">$nex_search_thread[views]{lang a_visit}</span><i>-</i>
                            <!--{if $nex_search_thread[replies]}--><span class="nex_showintels_reply">$nex_search_thread[replies]{lang a_comment_thread}</span><i>-</i><!--{/if}-->
                            <span class="nex_showintels_date">$nex_search_thread[dateline]</span>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <!--{/if}-->
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
    <!--{else}-->
    <div class="nex_emp_notice">
        <em></em>
    </div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
<!--{/if}-->
</div>
