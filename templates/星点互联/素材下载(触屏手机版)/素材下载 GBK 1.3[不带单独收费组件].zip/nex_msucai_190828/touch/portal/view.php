<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template common/bottomnav}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_article.css" />
	<!--{eval include 'template/nex_msucai_190828/touch/php/nex_artlist.php'}-->
	<div class="nex_pd_content">
    	<div class="nex_art_top_bg">
            
            <!--{if $nex_artical_attchcover == ''}-->
            <div class="nex_pd_txt_bg" style=" background:url($_G['style'][styleimgdir]/portal/uncover.jpg) center no-repeat;background-size:cover;"></div>
            <!--{else}-->
            
            <div class="nex_pd_txt_bg" style="background:url(data/attachment/portal/$nex_artical_attchs) center no-repeat; background-size:cover;"></div>
            <!--{/if}-->
            <div class="nex_artical_txtcounts">����Լ��<!--{echo intval($nex_articalzishu);}-->����</div>
            
        </div>
        <div class="nex_artical_Tops">
        	<div class="nex_artical_TopsL">
            	<div class="nex_art_author_ava">
                	<a href="home.php?mod=space&uid=$article[uid]">
                        <img src="uc_server/avatar.php?uid=$article[uid]&size=big">
                    </a>
                </div>
                <div class="nex_art_author_inf">
                	<div class="nex_art_author_infname">$article[username]</div>
                    <div class="nex_art_author_infbtm">
                        <em>$article[dateline]</em><span>|</span>
                        {lang view_views}��<!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}--><span>|</span>
                        {lang view_comments}��<!--{if $article[commentnum] > 0}-->$article[commentnum]<!--{else}-->0<!--{/if}-->
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_artical_TopsR"><a href="home.php?mod=space&uid=$article[uid]">��ע</a></div>
            <div class="clear"></div>
        </div>
        <div class="nex_mntitles">$article[title]</div>
        <div class="clear"></div>
        <div class="nex_mnsummarys">
        	<em class="nex_sumintro_quote1"></em><em class="nex_sumintro_quote2"></em>
            <!--{if $article[summary] && empty($cat[notshowarticlesummay])}--> $article[summary]<!--{hook/view_article_summary}--><!--{/if}-->
        </div>
		<div class="nex_pdcontent">
			<div class="nex_mncontent">
				$content[content]
				<!--{if $multi}--><div class="ptw pbw cl">$multi</div><!--{/if}-->
				<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
				<!--{if !empty($contents)}-->
				<!--{/if}-->
			</div>
            <div id="click_div">
                <!--{template home/space_click}-->
            </div>
            
			<!--{if !empty($aimgs[$content[pid]])}-->
				<script type="text/javascript" reload="1">aimgcount[{$content[pid]}] = [<!--{echo implode(',', $aimgs[$content[pid]]);}-->];attachimgshow($content[pid]);</script>
			<!--{/if}-->

			<!--{if !empty($_G['setting']['pluginhooks']['view_share_method'])}-->
				<div class="tshare cl">
					<strong>{lang viewthread_share_to}:</strong>
					<!--{hook/view_share_method}-->
				</div>
			<!--{/if}-->
			
			
			<div class="nex_relatedarts">
            	<!--{if $article['preaid']}-->
				<div class="nex_relateds"><!--{if $article['prearticle']}--><em>��һƪ</em><a href="{$article['prearticle']['url']}">{$article['prearticle']['title']}</a><!--{/if}--></div>
                <!--{/if}-->
                <!--{if $article['nextaid']}-->
				<div class="nex_relateds"><!--{if $article['nextarticle']}--><em>��һƪ</em><a href="{$article['nextarticle']['url']}">{$article['nextarticle']['title']}</a><!--{/if}--></div>
                <!--{/if}-->
			</div>
			
		</div>
		<!--{ad/article/mbm hm/2}--><!--{ad/article/mbm hm/3}-->
		<!--{if $article['related']}-->
        
		<div id="related_article">
			<h3><span>{lang view_related}</span></h3>
			<div class="nex_relatedbox">
				<ul class="xl xl2 cl" id="raid_div">
				<!--{loop $article['related'] $raid $rvalue}-->
                	<!--{if $rvalue[pic] == ''}-->
                	<li>
                    	<a href="{$rvalue[uri]}">
                        	<div class="nex_related_art_pic"><img src="$_G['style'][styleimgdir]/portal/nopic.jpg"></div>
                            <div class="nex_related_art_info">
                            	<h5>{$rvalue[title]}</h5>
                                <p><span>$rvalue[username]</span><em><!--{echo date("Y/m/d",{$rvalue[dateline]})}--></em></p>
                            </div>
                            <div class="clear"></div>
                        </a>
                    </li>
                    <!--{else}-->
					<li>
                    	<a href="{$rvalue[uri]}">
                        	<div class="nex_related_art_pic" style="background:url(data/attachment/$rvalue[pic]) center no-repeat; background-size:cover;"></div>
                            <div class="nex_related_art_info">
                            	<h5>{$rvalue[title]}</h5>
                                <p><span>$rvalue[username]</span><em><!--{echo date("Y/m/d",{$rvalue[dateline]})}--></em></p>
                            </div>
                            <div class="clear"></div>
                        </a>
                    </li>
                    <!--{/if}-->
				<!--{/loop}-->
				</ul>
			</div>
		</div>
		<!--{/if}-->
		<!--{if $article['allowcomment']==1}-->
			<!--{eval $data = &$article}-->
			<!--{subtemplate portal/portal_comment}-->
		<!--{/if}-->
	</div>

<!--{if $_G['relatedlinks']}-->
	<script type="text/javascript">
		var relatedlink = [];
		<!--{loop $_G['relatedlinks'] $key $link}-->
		relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
		<!--{/loop}-->
		relatedlinks('article_content');
	</script>
<!--{/if}-->

<input type="hidden" id="portalview" value="1">

<!--{template touch/common/footer}-->








<!--�ǵ㻥����Ȩ����-->
