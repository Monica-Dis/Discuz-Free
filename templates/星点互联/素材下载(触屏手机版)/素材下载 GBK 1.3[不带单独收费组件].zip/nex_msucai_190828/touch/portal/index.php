<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template common/bottomnav}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_portal.css" />
<div id="nex_mainbd_top"></div>
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        <div class="nex_rolltoptop"><a id="nex_rolltoptop"></a></div>
        <script type="text/javascript">
		 jQuery(function(){
		  jQuery('#nex_rolltoptop').click(function(){jQuery('html,body').animate({scrollTop:jQuery('#nex_mainbd_top').offset().top}, 600);});})
		</script>
        <!--bg-->
        <div class="nex_index_top_bg">
        	<!--search bar-->
        	<div class="nex_navsearch"><!--{template common/pubsearchform}--></div>
            <!--fast link-->
            <div class="nex_index_fast_link">
            	<div class="nex_index_fast_link_inner">
                    <ul>
						<!--�Զ�������-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <div class="nex_index_other">
            <!--hot tropicals-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>����ר��</span>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_tropicals">
                	<ul>

						<!--����ר��-->
                        

                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            
            <!--new update-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>�����ز�</span>
                    <a href="#">����</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_sucai_grids">
                	<ul>
						<!--�����ز�-->
                        
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <!--must have-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>���ʦ�ر��ز�</span>
                    <a href="#">����</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_sucai_grids">
                	<ul>
                    	<!--���ʦ�ر��ز�-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <!--sort options-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>�زķ�������</span>
                    <div class="clear"></div>
                </div>
                <div class="nex_sort_options">
                	<ul>
                    	<li class="cur">HTMLģ��</li>
                        <li>PPTģ��</li>
                        <li>���Ԫ��</li>
                        <li>�����Ա�</li>
                        <li>ƽ���ز�</li>
                        <li>���屳��</li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="nex_sort_contents">
                	<dl>
                    	<dd style="display:block;">
                        	<div class="nex_sucai_grids">
                                <ul>
                                    <!--HTMLģ��-->
                                    
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </dd>
                        <dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--PPTģ��-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
						<dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--���Ԫ��-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
						<dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--�����Ա�-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
						<dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--ƽ���ز�-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
						<dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--���屳��-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
                    </dl>
                </div>
                <script type="text/javascript">
					jQuery(".nex_sort_options ul li").each(function(s){
						jQuery(this).click(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_sort_contents dl dd").eq(s).show().siblings().hide();
							})
						})
				</script>
            </div>
            <!--VIP sort-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>VIP�ز�����</span>
                    <a href="#">����</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_sucai_grids">
                    <ul>
                        <!--VIP�ز�����-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <!--ranklist-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>�������а�</span>
                    <ul>
                    	<li class="cur">����</li>
                        <li>����</li>
                        <div class="clear"></div>
                    </ul>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_dlrk">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_index_rklist">
                            	<dl>
									<!--�����ز��������а�-->
                                    
                                	
                                </dl>
                            </div>
                        </li>
                    	<li>
							<div class="nex_index_rklist">
                            	<dl>
									<!--�����ز��������а�-->
                                    
                                </dl>
                            </div>
						</li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nex_index_common_box_top ul li").each(function(s){
						jQuery(this).click(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_index_dlrk ul li").eq(s).show().siblings().hide();
							})
						})
				</script>
            </div>
            <!--teach articles-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>�̳��Ķ�</span>
                    <a href="#">����</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_tart">
                	<ul>
						<!--�̳��Ķ�-->
                        
                    	
                    </ul>
                </div>
            </div>
            <!--ads-->
            <div class="nex_index_common_box">
            	<div class="nex_index_ads">
					<!--�Ż����λ-->
                    
                	
                </div>
            </div>
            <!--members-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>��Ա����</span>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_members">
                	<ul>
						<!--�Ż���Ա����-->
                        
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
           
            <!--friend links-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>��������</span>
                    <a href="#">����</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_flinks">
                	<ul>
						<!--�Ż���������-->
                        
                    	

                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
	</div>	
    
	<!--{template common/footer}-->
    
</div>


<div class="pullrefresh" style="display:none;"></div>


