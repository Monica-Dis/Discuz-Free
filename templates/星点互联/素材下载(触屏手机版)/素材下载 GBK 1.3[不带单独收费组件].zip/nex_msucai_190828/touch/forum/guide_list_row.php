<?php echo 'From: DisM.taobao.com';exit;?>
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_guide.css" />
<ul>
<!--{if $list['threadcount']}-->
	<!--{loop $list['threadlist'] $key $thread}-->
    <!--{eval include 'template/nex_msucai_190828/touch/php/nex_forum.php'}-->
    <!--{if $nex_sortypes == '0'}-->
    <li class="nex_guide_null">
    	<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
        	<div class="nex_guide_top">
            	<div class="nex_guide_author"><!--{avatar($thread[authorid],big)}--></div>
                <div class="nex_guide_authorinfos">
                	<div class="nex_guide_name">
                    	<h4>{$thread[author]}</h4>
                        <div class="nex_Guide_userLevel">
                        	<!--{if $nex_thread_levels <= '1'}-->
                            <i class="nex_level1"><em>{$nex_thread_levels}</em></i>
                            <!--{elseif $nex_thread_levels > '1' and $nex_thread_levels <= '3'}-->
                            <i class="nex_level2"><em>{$nex_thread_levels}</em></i>
                            <!--{elseif $nex_thread_levels > '3' and $nex_thread_levels <= '6'}-->
                            <i class="nex_level3"><em>{$nex_thread_levels}</em></i>
                            <!--{elseif $nex_thread_levels > '6'}-->
                            <i class="nex_level4"><em>{$nex_thread_levels}</em></i>
                            <!--{/if}-->
                        </div>
                    	<div class="clear"></div>
                    </div>
                    <div class="nex_Guide_usebtm">
                    	<span>{$list['forumnames'][$thread[fid]]['name']}</span>
                        <em></em>
                        <!--{if $nex_g_province == '' and $nex_g_adds == ''}-->
                        <!--{else}-->
                        <i>{$nex_g_province}{$nex_g_adds}</i>
                        <em></em>
                        <!--{/if}-->
                        <span>{$usergroupID[grouptitle]}</span>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_guide_mid">
            	<h5>
                	<!--{if $thread['special'] == 1}-->
                        <em class="threadType nex_thread_poll">{lang thread_poll}</em>
                    <!--{elseif $thread['special'] == 2}-->
                        <em class="threadType nex_thread_trade">{lang thread_trade}</em>
                    <!--{elseif $thread['special'] == 3}-->
                        <em class="threadType nex_thread_reward">{lang thread_reward}</em>
                    <!--{elseif $thread['special'] == 4}-->
                        <em class="threadType nex_nex_thread_activity">{lang thread_activity}</em>
                    <!--{elseif $thread['special'] == 5}-->
                        <em class="threadType nex_thread_debate">{lang thread_debate}</em>
                    
                    <!--{elseif $thread['digest'] > 0}-->
                        <em class="threadAttrjh">����</em>
                    <!--{/if}-->
                    <span>{$thread[subject]}</span>
                </h5>
                <div class="nex_guide_nullsums"><!--{echo cutstr({$summary_echo},160)}--></div>
            </div>
            <div class="nex-guide_attpics"></div>
            <div class="nex_guide_btm">
            	<div class="nex_guide_datefrom"><!--{if $nex_thread_typehtml}--><span>{$nex_thread_typehtml}</span><em></em><!--{/if}--><span><!--{echo date("Y-m-d",{$nex_bbs_date})}--></span><div class="clear"></div></div>
                <div class="nex_guide_viewreply">
                	<span class="nex_guide_views">{$thread[views]}</span>
                    <span class="nex_guide_replies">{$thread[replies]}</span>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
            </div>
        </a>
    </li>
    <!--{else}-->
    	<!--{if $nex_localpic}-->
        <li class="nex_guide_null">
    	<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
        	<div class="nex_guide_top">
            	<div class="nex_guide_author"><!--{avatar($thread[authorid],big)}--></div>
                <div class="nex_guide_authorinfos">
                	<div class="nex_guide_name">
                    	<h4>{$thread[author]}</h4>
                        <div class="nex_Guide_userLevel">
                        	<!--{if $nex_thread_levels <= '1'}-->
                            <i class="nex_level1"><em>{$nex_thread_levels}</em></i>
                            <!--{elseif $nex_thread_levels > '1' and $nex_thread_levels <= '3'}-->
                            <i class="nex_level2"><em>{$nex_thread_levels}</em></i>
                            <!--{elseif $nex_thread_levels > '3' and $nex_thread_levels <= '6'}-->
                            <i class="nex_level3"><em>{$nex_thread_levels}</em></i>
                            <!--{elseif $nex_thread_levels > '6'}-->
                            <i class="nex_level4"><em>{$nex_thread_levels}</em></i>
                            <!--{/if}-->
                        </div>
                    	<div class="clear"></div>
                    </div>
                    <div class="nex_Guide_usebtm">
                    	<span>{$list['forumnames'][$thread[fid]]['name']}</span>
                        <em></em>
                        <!--{if $nex_g_province == '' and $nex_g_adds == ''}-->
                        <!--{else}-->
                        <i>{$nex_g_province}{$nex_g_adds}</i>
                        <em></em>
                        <!--{/if}-->
                        <span>{$usergroupID[grouptitle]}</span>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_guide_mid">
            	<h5>
                	<!--{if $thread['special'] == 1}-->
                        <em class="threadType nex_thread_poll">{lang thread_poll}</em>
                    <!--{elseif $thread['special'] == 2}-->
                        <em class="threadType nex_thread_trade">{lang thread_trade}</em>
                    <!--{elseif $thread['special'] == 3}-->
                        <em class="threadType nex_thread_reward">{lang thread_reward}</em>
                    <!--{elseif $thread['special'] == 4}-->
                        <em class="threadType nex_nex_thread_activity">{lang thread_activity}</em>
                    <!--{elseif $thread['special'] == 5}-->
                        <em class="threadType nex_thread_debate">{lang thread_debate}</em>
                    
                    <!--{elseif $thread['digest'] > 0}-->
                        <em class="threadAttrjh">����</em>
                    <!--{/if}-->
                    <span>{$thread[subject]}</span>
                </h5>
                <div class="nex_guide_nullsums"><!--{echo cutstr({$summary_echo},160)}--></div>
            </div>
            <div class="nex_guide_attpics">
            	<div class="nex_threadList_picscrolls">
                    <!--{eval include 'template/nex_msucai_190828/touch/php/nex_pforum.php'}-->
                    <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
                    <!--{eval include 'template/nex_msucai_190828/touch/php/nex_nforum.php'}-->
                    <!--{if $nex_attnumx == '1'}-->
                    <div class="nex_threadList_img_1" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <!--{if $nex_attnumx == '2'}-->
                    <div class="nex_threadList_img_2" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <!--{if $nex_attnumx == '3'}-->
                    <div class="nex_threadList_img_3" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <!--{if $nex_attnumx == '4'}-->
                    <div class="nex_threadList_img_4" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <!--{if $nex_attnumx == '5'}-->
                    <div class="nex_threadList_img_5" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <!--{if $nex_attnumx == '6'}-->
                    <div class="nex_threadList_img_6" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <!--{if $nex_attnumx == '7'}-->
                    <div class="nex_threadList_img_6" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <!--{if $nex_attnumx == '8'}-->
                    <div class="nex_threadList_img_6" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <!--{if $nex_attnumx >= '9'}-->
                    <div class="nex_threadList_img_6" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                    <!--{/if}-->
                    <!--{/loop}-->
                    <div class="clear"></div>
                </div>
            </div>
            <div class="nex_guide_btm">
            	<div class="nex_guide_datefrom"><!--{if $nex_thread_typehtml}--><span>{$nex_thread_typehtml}</span><em></em><!--{/if}--><span><!--{echo date("Y-m-d",{$nex_bbs_date})}--></span><div class="clear"></div></div>
                <div class="nex_guide_viewreply">
                	<span class="nex_guide_views">{$thread[views]}</span>
                    <span class="nex_guide_replies">{$thread[replies]}</span>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
            </div>
        </a>
    </li>
        <!--{else}-->
        <li class="nex_guide_null">
    	<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
        	<div class="nex_guide_top">
            	<div class="nex_guide_author"><!--{avatar($thread[authorid],big)}--></div>
                <div class="nex_guide_authorinfos">
                	<div class="nex_guide_name">
                    	<h4>{$thread[author]}</h4>
                        <div class="nex_Guide_userLevel">
                        	<!--{if $nex_thread_levels <= '1'}-->
                            <i class="nex_level1"><em>{$nex_thread_levels}</em></i>
                            <!--{elseif $nex_thread_levels > '1' and $nex_thread_levels <= '3'}-->
                            <i class="nex_level2"><em>{$nex_thread_levels}</em></i>
                            <!--{elseif $nex_thread_levels > '3' and $nex_thread_levels <= '6'}-->
                            <i class="nex_level3"><em>{$nex_thread_levels}</em></i>
                            <!--{elseif $nex_thread_levels > '6'}-->
                            <i class="nex_level4"><em>{$nex_thread_levels}</em></i>
                            <!--{/if}-->
                        </div>
                    	<div class="clear"></div>
                    </div>
                    <div class="nex_Guide_usebtm">
                    	<span>{$list['forumnames'][$thread[fid]]['name']}</span>
                        <em></em>
                        <!--{if $nex_g_province == '' and $nex_g_adds == ''}-->
                        <!--{else}-->
                        <i>{$nex_g_province}{$nex_g_adds}</i>
                        <em></em>
                        <!--{/if}-->
                        <span>{$usergroupID[grouptitle]}</span>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_guide_mid">
            	<h5>
                	<!--{if $thread['special'] == 1}-->
                        <em class="threadType nex_thread_poll">{lang thread_poll}</em>
                    <!--{elseif $thread['special'] == 2}-->
                        <em class="threadType nex_thread_trade">{lang thread_trade}</em>
                    <!--{elseif $thread['special'] == 3}-->
                        <em class="threadType nex_thread_reward">{lang thread_reward}</em>
                    <!--{elseif $thread['special'] == 4}-->
                        <em class="threadType nex_nex_thread_activity">{lang thread_activity}</em>
                    <!--{elseif $thread['special'] == 5}-->
                        <em class="threadType nex_thread_debate">{lang thread_debate}</em>
                    
                    <!--{elseif $thread['digest'] > 0}-->
                        <em class="threadAttrjh">����</em>
                    <!--{/if}-->
                    <span>{$thread[subject]}</span>
                </h5>
                <div class="nex_guide_nullsums"><!--{echo cutstr({$summary_echo},160)}--></div>
            </div>
            <div class="nex-guide_attpics"></div>
            <div class="nex_guide_btm">
            	<div class="nex_guide_datefrom"><!--{if $nex_thread_typehtml}--><span>{$nex_thread_typehtml}</span><em></em><!--{/if}--><span><!--{echo date("Y-m-d",{$nex_bbs_date})}--></span><div class="clear"></div></div>
                <div class="nex_guide_viewreply">
                	<span class="nex_guide_views">{$thread[views]}</span>
                    <span class="nex_guide_replies">{$thread[replies]}</span>
                    <div class="clear"></div>
                </div>
                <div class="clear"></div>
            </div>
        </a>
    </li>
        <!--{/if}-->
    <!--{/if}-->
	<!--{/loop}-->
    
    <div class="nex_bbs_pagetops">��ҳ�Ѿ�������~</div>

<!--{else}-->
	<li class="noData">
    	<em></em>
    	<p>{lang guide_nothreads}</p>
    </li>
<!--{/if}-->
</ul>


