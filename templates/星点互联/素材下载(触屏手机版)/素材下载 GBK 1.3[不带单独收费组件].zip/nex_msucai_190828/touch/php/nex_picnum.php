<?php

if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}


$nex_getnumbefore = substr($thread[tid], -1);$nextotlepivs = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$nex_getnumbefore.'')." WHERE tid = '$thread[tid]' AND isimage = '1'"));

?>
