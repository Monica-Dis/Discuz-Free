<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_userid = DB::result(DB::query("SELECT uid FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_intros = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_comps = DB::result(DB::query("SELECT company FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_occu = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_pos = DB::result(DB::query("SELECT position FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$_G[uid]'"));
$nex_grids = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$_G[uid]'"));
$nex_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_grids'"));
$nex_user_elements = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]'");
$nex_usercp = DB::result(DB::query("SELECT customstatus FROM ".DB::table('common_member_field_forum')." WHERE uid = '$_G[uid]'"));
?>
