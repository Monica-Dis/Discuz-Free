<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_self_intros = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_uc_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_uc_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_uc_occu = DB::result(DB::query("SELECT occupation FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));
$nex_otheruser_elements = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]'");

$nex_user_follows = DB::result(DB::query("SELECT follower FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]'"));
$nex_user_coins = DB::result(DB::query("SELECT extcredits2 FROM ".DB::table('common_member_count')." WHERE uid = '$space[uid]'"));

$nex_user_threads = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_thread')." WHERE authorid = '$space[uid]'"));
$nex_user_posts = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_post')." WHERE authorid = '$space[uid]'"));
    


$nex_Userx_grids = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$space[uid]'"));

$nex_Userx_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_Userx_grids'"));


$nex_Userx_gender = DB::result(DB::query("SELECT gender FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));

$nex_Userx_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));

$nex_Userx_city = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$space[uid]'"));

?>
