<?php

if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_attachment = substr($nex_threadsinpivs[tid], -1);$nex_attnumx = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$nex_attachment.'')." WHERE tid = '$nex_threadsinpivs[tid]' AND isimage = '1'"));

?>
