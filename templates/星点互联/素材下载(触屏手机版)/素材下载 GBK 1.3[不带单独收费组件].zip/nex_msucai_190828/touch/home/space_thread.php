<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template home/space_profile_top}-->
<div class="nex_uc_mylistbtm">

<!-- header start -->

<div class="nex_tl_inner_top">
	<span>����</span>
    <em>��{$nex_user_threads}������</em>
    <div class="clear"></div>
</div>
<!-- header end -->
<!-- main threadlist start -->
<div class="nex_MY_threadlist nex_UC_mylists">
	<ul>
	<!--{if $list}-->
		<!--{loop $list $nexmythread}-->
        <!--{eval include 'template/nex_msucai_190828/touch/php/nex_home_thread.php'}-->
        <li>
            <a href="forum.php?mod=viewthread&tid=$nexmythread[tid]&extra=$extra">
                <!--{if $nex_attachs == '0'}-->
                <div class="nex_UC_mythread_null">
                	<div class="nex_UC_mylists_title">
                        <!--{if $nexmythread['special'] == 1}-->
                        <em class="nex_thread_poll">{lang thread_poll}</em>
                        <!--{elseif $nexmythread['special'] == 2}-->
                        <em class="nex_thread_trade">{lang thread_trade}</em>
                        <!--{elseif $nexmythread['special'] == 3}-->
                        <em class="nex_thread_reward">{lang thread_reward}</em>
                        <!--{elseif $nexmythread['special'] == 4}-->
                        <em class="nex_thread_activity">{lang thread_activity}</em>
                        <!--{elseif $nexmythread['special'] == 5}-->
                        <em class="nex_thread_debate">{lang thread_debate}</em>
                        <!--{elseif $nexmythread['digest'] > 0}-->
                        <em class="threadAttrjh">����</em>
                        <!--{/if}-->
                        <span $nexmythread[highlight]>{$nexmythread[subject]}</span>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="nex_mythreadsums"><!--{echo cutstr({$nex_summary_echo},120)}--></div>
                <div class="nex_mythread_others">
                    <div class="nex_mythread_ol"><span>{$nex_mythreadfrom}</span><em><!--{echo date("Y-m-d",{$nex_mythreaddate})}--></em></div>
                    <div class="nex_mythread_or">
                        <span class="nex_mythread_orview">{$nexmythread[views]}</span>
                        <span class="nex_mythread_orreply">{$nexmythread[replies]}</span>
                        <div class="clear"></div>
                    </div>
                    <div class="clear"></div>
                </div>
                <!--{else}-->
                	<!--{if $nex_mine_pic}-->
                    <div class="nex_UC_mythread_attpic">
                    	<div class="nex_UC_mythread_attTop">
                        	<div class="nex_UC_mythread_attTopL">
                                <div class="nex_UC_mylists_title">
                                    <!--{if $nexmythread['special'] == 1}-->
                                    <em class="nex_thread_poll">{lang thread_poll}</em>
                                    <!--{elseif $nexmythread['special'] == 2}-->
                                    <em class="nex_thread_trade">{lang thread_trade}</em>
                                    <!--{elseif $nexmythread['special'] == 3}-->
                                    <em class="nex_thread_reward">{lang thread_reward}</em>
                                    <!--{elseif $nexmythread['special'] == 4}-->
                                    <em class="nex_thread_activity">{lang thread_activity}</em>
                                    <!--{elseif $nexmythread['special'] == 5}-->
                                    <em class="nex_thread_debate">{lang thread_debate}</em>
                                    <!--{elseif $nexmythread['digest'] > 0}-->
                                    <em class="threadAttrjh">����</em>
                                    <!--{/if}-->
                                    <span $nexmythread[highlight]>{$nexmythread[subject]}</span>
                                    <div class="clear"></div>
                                </div>
                                <div class="nex_mythreadsums"><!--{echo cutstr({$nex_summary_echo},120)}--></div>
                            </div>
                            <!--{loop $nex_mine_pic $nex_minepic}-->
                            <div class="nex_UC_mythread_attTopR" style="background:url(data/attachment/forum/$nex_minepic[attachment]) center no-repeat; background-size:cover;"></div>
                            <!--{/loop}-->
                            <div class="clear"></div>
                        </div>
                        <div class="nex_UC_mythread_attBtm">
                        	<div class="nex_mythread_others">
                                <div class="nex_mythread_ol"><span>{$nex_mythreadfrom}</span><em><!--{echo date("Y-m-d",{$nex_mythreaddate})}--></em></div>
                                <div class="nex_mythread_or">
                                    <span class="nex_mythread_orview">{$nexmythread[views]}</span>
                                    <span class="nex_mythread_orreply">{$nexmythread[replies]}</span>
                                    <div class="clear"></div>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <!--{else}-->
                    <div class="nex_UC_mythread_null">
                        <div class="nex_UC_mylists_title">
                            <!--{if $nexmythread['special'] == 1}-->
                            <em class="nex_thread_poll">{lang thread_poll}</em>
                            <!--{elseif $nexmythread['special'] == 2}-->
                            <em class="nex_thread_trade">{lang thread_trade}</em>
                            <!--{elseif $nexmythread['special'] == 3}-->
                            <em class="nex_thread_reward">{lang thread_reward}</em>
                            <!--{elseif $nexmythread['special'] == 4}-->
                            <em class="nex_thread_activity">{lang thread_activity}</em>
                            <!--{elseif $nexmythread['special'] == 5}-->
                            <em class="nex_thread_debate">{lang thread_debate}</em>
                            <!--{elseif $nexmythread['digest'] > 0}-->
                            <em class="threadAttrjh">����</em>
                            <!--{/if}-->
                            <span $nexmythread[highlight]>{$nexmythread[subject]}</span>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nex_mythreadsums"><!--{echo cutstr({$nex_summary_echo},120)}--></div>
                    <div class="nex_mythread_others">
                        <div class="nex_mythread_ol"><span>{$nex_mythreadfrom}</span><em><!--{echo date("Y-m-d",{$nex_mythreaddate})}--></em></div>
                        <div class="nex_mythread_or">
                            <span class="nex_mythread_orview">{$nexmythread[views]}</span>
                            <span class="nex_mythread_orreply">{$nexmythread[replies]}</span>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <!--{/if}-->
                <!--{/if}-->
            </a>
        </li>
		<!--{/loop}-->
	<!--{else}-->
		<li class="nex_mythreadNone">{lang no_related_posts}</li>
	<!--{/if}-->
	</ul>
	$multi
</div>
<!-- main threadlist end -->
<!--{eval $nofooter = true;}-->
</div>
<!--{template common/footer}-->

