<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<div class="nex_usertopnav">
    <a href="javascript:;" onclick="history.go(-1);" class="nex_usercenter_back"></a>
    <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="nex_usercenter_btn"></a>
</div>

<div class="nex_Upload_main">
  <form method="post" autocomplete="off" id="albumform" action="home.php?mod=spacecp&ac=upload" onsubmit="return validate(this);">
  <input type="hidden" name="albumsubmit" id="albumsubmit" value="true" />
  <input type="hidden" name="formhash" value="{FORMHASH}" />
  <div class="selectalbum nex_postbar">
    <div class="nex_Ablum_termimgs">
        <div class="nex_At_lines">
            <span class="nex_selection_bar_name">ѡ������</span>
            <span class="nex_selection_bar">
            <label for="albumop_selectalbum" class="lb"><input type="radio" name="albumop" id="albumop_selectalbum" class="pr" value="selectalbum" checked="checked" onclick="album_op(this.value);" />{lang add_to_existing_album}</label>
			<label for="albumop_creatalbum" class="lb"><input type="radio" name="albumop" id="albumop_creatalbum" class="pr" value="creatalbum" onclick="album_op(this.value);" />{lang create_new_album}</label>
            <div class="clear"></div>
            </span>
        </div>
        <div class="nex_switch_box">
        	<ul>
            	<li style="display:block;">
                	<div class="nex_At_lines">
                        <span class="nex_selection_bar_name">{lang select_album}</span>
                        <span class="nex_selection_bar">
                            <select name="albumid" id="uploadalbumid">
                            <!--{loop $albums $value}-->
                            <option value="$value[albumid]" {if $value['albumid'] == $_GET['albumid']}selected="selected"{/if}>$value[albumname]</option>
                            <!--{/loop}-->
                            </select>
                        </span>
                    </div>
                </li>
                <li>
                	<div id="creatalbum" class="nex_creatnew_ablum">
                      <div class="nex_At_lines">
                      <span class="nex_selection_bar_name">{lang album_name}</span>
                      <span class="nex_selection_bar">
                        <input type="text" name="albumname" id="albumname" class="px" size="20" placeholder="��д����" />
                        </span>
                        </div>
                      <div class="nex_At_lines">
                        <span class="nex_selection_bar_name">{lang album_depict}</span></div>
                      <div class="nex_At_lines">
                          <span class="nex_selection_bar">
                            <textarea name="depict" class="pt" style="height:70px;"></textarea>
                            </span>
                        </div>
                      <!--{if $_G['setting']['albumcategorystat'] && $categoryselect}-->
                      <div class="nex_At_lines">
                          <span class="nex_selection_bar_name">{lang site_categories}</span>
                          <span class="nex_selection_bar">$categoryselect</span>
                      </div>
                      <!--{/if}-->
                      <div class="nex_At_lines">
                      <span class="nex_selection_bar_name">{lang privacy_settings}</span>
                      <span class="nex_selection_bar">
                        <select name="friend" id="uploadfriend" onchange="passwordShow(this.value);" class="ps">
                          <option value="0">{lang friendname_0}</option>
                          <option value="1">{lang friendname_1}</option>
                          <option value="2">{lang friendname_2}</option>
                          <option value="3">{lang friendname_3}</option>
                          <option value="4">{lang friendname_4}</option>
                        </select>
                        </span>
                        </div>
                      <dl id="tb_selectgroup" style="display:none;">
                        <div class="nex_At_lines">
                            <span class="nex_selection_bar_name"></span> 
                            <span class="nex_selection_bar">
                                <select name="selectgroup" onchange="getgroup(this.value);" class="ps">
                                <option value="">{lang from_friends_group}</option>
                                <!--{loop $groups $key $value}-->
                                <option value="$key">$value</option>
                                <!--{/loop}-->
                                </select>
                            </span> 
                          </div>
                        <div class="nex_At_lines"><span class="nex_selection_bar_name">{lang friend_name_space}</span></div>
                        <div class="nex_At_lines">
                          <textarea name="target_names" id="target_names">$blog[target_names]</textarea>
                        </div>
                        <div style="height:15px;"></div>
                      </dl>
                      <div id="span_password" class="nex_At_lines" style="display:none;">
                      <span class="nex_selection_bar_name">{lang password}</span>
                      <span class="nex_selection_bar">
                        <input type="text" name="password" value="$blog[password]" size="10" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')" class="px" placeholder="��������"/>
                        </span>
                        </div>
                    </div>
                </li>
                
            </ul>
        	
            
        </div>
        <script type="text/javascript">
			jQuery(".nex_selection_bar label").each(function(s){
				jQuery(this).hover(function(){
					jQuery(".nex_switch_box ul li").eq(s).show().siblings().hide();
					})
				})
		</script>
        
        
        
        
      </div>
      <div class="nex_At_lines"><span class="nex_selection_bar_name">{lang upload_pic}</span></div>
    </div>
    <div id="imglist" class="imagebox">
      
      <div id="filedata"><em>&nbsp;</em></div>
    </div>
    <div class="nex_Ablum_startingbtn">
      <button type="submit" name="albumsubmit_btn" id="albumsubmit_btn" class="pn button" value="true"{if $_G['setting']['albumcategoryrequired']} onclick="return validate(this);"{/if}>{lang upload_start}</button>
    </div>
  </div>
  </form>
</div>
<script type="text/javascript" src="template/nex_mgame_190319/neoconex/js/upload.min.js" charset="{CHARSET}"></script>
<script type="text/javascript">
function passwordShow(value) {
	if(value==4) {
		$('#span_password').fadeIn();
		$('#tb_selectgroup').fadeOut();
	} else if(value==2) {
		$('#span_password').fadeOut();
		$('#tb_selectgroup').fadeIn();
	} else {
		$('#span_password,#tb_selectgroup').fadeOut();
	}
}

function getgroup(gid)
{
	if(gid)
	{
		$.ajax({
			type:'GET',
			url:'home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid='+gid,
			dataType:'xml'
		})
		.success(function(s)
		{
			s = s.lastChild.firstChild.nodeValue
			var testStr = s.replace(/<\/?.+?>/g,"");

			var resultStr = testStr.replace(/\ +/g, ""); //ȥ���ո�
            resultStr = resultStr.replace(/[\r\n]/g, ""); //ȥ���س�����

			resultStr = resultStr + ' ';
			document.getElementById('target_names').innerHTML += resultStr;
	    });
	}
}

var uploader = WebUploader.create({
	server: 'misc.php?mod=swfupload&action=swfupload&operation=album',
	formData:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
	fileVal: 'Filedata',
	pick: '#filedata',
	auto: true,
	compress:
	{
		width: 1980,
		height: 1080,
		quality: 95,
		preserveHeaders: true,
		noCompressIfLarger: true
	},
	accept:
	{
		title: 'Image File',
		mimeTypes:'image/*,text/plain'
	}
	
});
uploader.on('fileQueued', function(file) {
	var bar = $('#rt_'+file.source.ruid).parent().parent();
	$(bar).prepend('<div class="nex_At_lines" id="file_'+file.id+'"><div class="nex_uploadingimg"><img src="template/nex_mgame_190319/neoconex/home/loading.gif" style="height:40px;width:40px;"></div><div class="nex_selection_bar nex_selection_bar_desc"></div></div>');
});

uploader.on('uploadProgress', function( file, percentage ) {
	$('#file_'+file.id+' i').html(Math.round(percentage * 100) + '%');
});

uploader.on('uploadSuccess', function(file, data) {
	var bar = $('#rt_'+file.source.ruid).parent().parent();
	if(data.picid) {
		$('#file_'+file.id).find('.nex_uploadingimg').html('<span aid="'+data.picid+'" class="del"><a href="javascript:;"><img src="'+STATICURL+'image/mobile/images/icon_del.png"></a></span><span class="nex_uploading_img"><img id="aimg_'+data.picid+'" src="'+data.url+'" /></span><input type="hidden" name="title['+data.picid+']" />');
		$('#file_'+file.id).find('.nex_selection_bar_desc').html('<textarea class="nex_pic_desc_area" name="title['+data.picid+']" cols="40" placeholder="��дͼƬ����;"></textarea>');
	}
});

$(document).on('click', '.del', function() {
	var obj = $(this);
	$.ajax({
		type:'GET',
		url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
	})
	.success(function(s) {
		obj.parent().parent().remove();
	})
	.error(function() {
		popup.open('{lang networkerror}', 'alert');
	});
	return false;
});
</script> 
<!--{template common/footer}-->
