<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{template common/bottomnav}-->
<!--{eval include 'template/nex_msucai_190828/touch/php/nex_home_base.php'}-->
<div class="nex_ucenter_bd">
    <!--{if $space[self]}-->
    <div class="nex_ucenter_topnav">
        <a href="javascript:history.back()" class="z nexback"></a>
        <h3>{$_G[username]}�ĸ�������</h3>
    </div>
    <div class="nex_self_ucenter">
    	<div class="nex_self_ucenter_userinfo">
        	<!--self intel-->
        	<div class="nex_self_ucenter_user_avator">
            	<div class="nex_sua_img"><img src="<!--{avatar($space[uid], big, true)}-->" /></div>
                <!--{if $_G['uid']}-->
                <div class="nex_sua_edit"><a href="home.php?mod=spacecp&ac=profile">�༭����</a></div>
                <!--{/if}-->
                <div class="clear"></div>
            </div>
            <!--self details-->
            <div class="nex_self_ucenter_user_items">
            	<h5><span>{$space[username]}</span><i></i><div class="clear"></div></h5>
                <p>
                	<!--{if $nex_self_intros}-->
                    {$nex_self_intros}
                    <!--{else}-->
                    ����˺�����ʲôҲû�����¡�
                    <!--{/if}-->
                </p>
            </div>
            <!--menu-->
            <div class="nex_self_ucenter_btu">
                <ul>
                	<li><em>{$nex_otheruser_elements[threads]}</em><p>����</p></li>
                    <li><em>{$nex_otheruser_elements[follower]}</em><p>��˿</p></li>
                    <li><em>{$nex_otheruser_elements[following]}</em><p>��ע</p></li>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <div class="nex_self_ucenter_recom_art">
            <div class="nex_ucenter_function">
                <ul>
                    <li class="nex_ucenter_icon1"><a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me"><i></i><span>����</span></a></li>
                    <li class="nex_ucenter_icon2"><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread"><i></i><span>�ղ�</span></a></li>
                    <li class="nex_ucenter_icon3">
                        <a href="home.php?mod=space&do=pm">
                            <i></i>
                            <span>��Ϣ</span>
                            <!--{if $_G[member][newpm]}-->
                            <em></em>
                            <!--{elseif $_G[member][newprompt]}-->
                            <em></em>
                            <!--{/if}-->
                        </a>
                    </li>
                    <li class="nex_ucenter_icon4"><a href="home.php?mod=space&do=friend&mobile=2"><i></i><span>����</span></a></li>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!--DIY-->
        <div class="nex_self_ucenter_zplist">
        	<div class="nex_self_ucenter_zplist_top">
            	<span>�Ƽ��ز�</span>
                <a href="#">����</a>
                <div class="clear"></div>
            </div>
            <div class="nex_self_ucenter_zplist_list">
            	<ul>
					<!--�û�����-->
                    <!--{block/168}-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <div class="nex_user_quits"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout_mobile}</a></div>
    </div>	
    <!--{else}-->
    <div class="nex_ucenter_topnav">
        <a href="javascript:history.back()" class="z nexback"></a>
        <h3>{$space[username]}�ĸ�������</h3>
    </div>
    <div class="nex_ucenter_other_box">
        <div class="nex_ucenter_other_bg">
            <div class="nex_ucenter_other_inner">
                <div class="nex_ucenter_othername">{$space[username]}</div>
                <div class="nex_ucenter_other_info">
                    <ul>
                        <li>{$space[group][grouptitle]}</li>
                        <!--{if $nex_uc_province == '' && $nex_uc_adds == ''}-->
                        <!--{else}-->
                        <em></em>
                        <li>{$nex_uc_province}{$nex_uc_adds}</li>
                        <!--{/if}-->
                        <!--{if $nex_uc_occu == ''}-->
                        <!--{else}-->
                        <em></em>
                        <li>{$nex_uc_occu}</li>
                        <!--{/if}-->
                        <div class="clear"></div>
                    </ul>
                </div>
                
                <div class="nex_otheruser_avator"><img src="<!--{avatar($space[uid], big, true)}-->" /></div>
                <div class="nex_junction_userdata">
                    <ul>
                        <li><strong>$nex_otheruser_elements[posts]</strong><span>����</span></li>
                        <li><strong>$nex_otheruser_elements[threads]</strong><span>����</span></li>
                        <li><strong>$nex_otheruser_elements[following]</strong><span>��ע</span></li>
                        <li class="nex_otheruser_last"><strong>$nex_otheruser_elements[follower]</strong><span>��˿</span></li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="nex_ucenter_otherlinks">
                    <a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space">Ta������</a>
                </div>
            </div>
        </div>
        <div class="nex_ucenter_otheriners_btm">
            <div class="nex_ucenter_iners_btmtxt"><span>{$space[username]}�ĸ�������</span><div class="clear"></div></div>
            <div class="nex_user_Profile">
                <div class="pbm mbm bbda cl">
                    <ul class="pf_l cl pbm mbm">
                        <!--{if $_G['setting']['allowspacedomain'] && $_G['setting']['domain']['root']['home'] && checkperm('domainlength') && !empty($space['domain'])}-->
                        <!--{eval $spaceurl = 'http://'.$space['domain'].'.'.$_G['setting']['domain']['root']['home'];}-->
                        <li><em>{lang second_domain}</em>$spaceurl</li>
                        <!--{/if}-->
                        <!--{if $_G[setting][homepagestyle]}-->
                        <li><em>{lang space_visits}</em>$space[views]</li>
                        <!--{/if}-->
                        <!--{if in_array($_G[adminid], array(1, 2))}-->
                        <li><em>Email</em>$space[email]</li>
                        <!--{/if}-->
                        <li><em>{lang email_status}</em><!--{if $space[emailstatus] > 0}-->{lang profile_verified}<!--{else}-->{lang profile_no_verified}<!--{/if}--></li>
                        <li><em>{lang video_certification}</em><!--{if $space[videophotostatus] > 0}-->{lang profile_certified} <!--{if $showvideophoto}-->&nbsp;&nbsp;({lang view_certification_photos})<!--{/if}--><!--{else}-->{lang profile_no_certified}<!--{/if}--></li>
                    </ul>
                    <!--{if CURMODULE == 'space'}-->
                        <!--{hook/space_profile_baseinfo_middle}-->
                    <!--{elseif CURMODULE == 'follow'}-->
                        <!--{hook/follow_profile_baseinfo_middle}-->
                    <!--{/if}-->
                    <ul class="pf_l cl">
                        <!--{loop $profiles $value}-->
                        <li><em>$value[title]</em>$value[value]</li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="pbm mbm bbda cl">
                    <ul>
                        <!--{if $space[adminid]}--><li><em class="xg1">{lang management_team}&nbsp;&nbsp;</em><span style="color:{$space[admingroup][color]}">{$space[admingroup][grouptitle]}</span> {$space[admingroup][icon]}</li><!--{/if}-->
                        <li><em class="xg1">{lang usergroup}&nbsp;&nbsp;</em><span style="color:{$space[group][color]}"{if $upgradecredit !== false} class="xi2" onMouseOver="showTip(this)" tip="{lang credits} $space[credits], {lang thread_groupupgrade} $upgradecredit {lang credits}"{/if}>{$space[group][grouptitle]}</span> {$space[group][icon]} <!--{if !empty($space['groupexpiry'])}-->&nbsp;{lang group_useful_life}&nbsp;<!--{date($space[groupexpiry], 'Y-m-d H:i')}--><!--{/if}--></li>
                        <!--{if $space[extgroupids]}--><li><em class="xg1">{lang group_expiry_type_ext}&nbsp;&nbsp;</em>$space[extgroupids]</li><!--{/if}-->
                    </ul>
                    <ul id="pbbs" class="pf_l">
                        <!--{if $space[oltime]}--><li><em>{lang online_time}</em>$space[oltime] {lang hours}</li><!--{/if}-->
                        <li><em>{lang regdate}</em>$space[regdate]</li>
                        <li><em>{lang last_visit}</em>$space[lastvisit]</li>
                        <!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
                        <li><em>{lang register_ip}</em>$space[regip] - $space[regip_loc]</li>
                        <li><em>{lang last_visit_ip}</em>$space[lastip]:$space[port] - $space[lastip_loc]</li>
                        <!--{/if}-->
                        <!--{if $space[lastactivity]}--><li><em>{lang last_activity_time}</em>$space[lastactivity]</li><!--{/if}-->
                        <!--{if $space[lastpost]}--><li><em>{lang last_post_time}</em>$space[lastpost]</li><!--{/if}-->
                        <!--{if $space[lastsendmail]}--><li><em>{lang last_send_email}</em>$space[lastsendmail]</li><!--{/if}-->
                        <li><em>{lang time_offset}</em>
                            <!--{eval $timeoffset = array({lang timezone});}-->
                            $timeoffset[$space[timeoffset]]
                        </li>
                    </ul>
                </div>
                <!--{if CURMODULE == 'space'}-->
                <!--{hook/space_profile_extrainfo}-->
                <!--{elseif CURMODULE == 'follow'}-->
                <!--{hook/follow_profile_extrainfo}-->
                <!--{/if}-->
               
            </div>
        </div>
    </div>
    <!--{/if}-->
</div>
<!--{template touch/common/footer}-->

