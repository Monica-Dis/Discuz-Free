<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval include 'template/nex_msucai_190828/touch/php/nex_users.php'}-->
<nav class="st-menu st-effect-3" id="menu-3">
    <div class="nex_nav_dlbox">
    	<!--{if $_G['uid']}-->
        <div class="nex_nav_user_top">
            <div class="nex_nav_user_avator">
                <!--{avatar($_G[uid],big)}-->
                <!--{if $_G[member][newpm]}-->
                <em><b>{$_G[member][newpm]}</b></em>
                <!--{elseif $_G[member][newprompt]}-->
                <em><b>{$_G[member][newprompt]}</b></em>
                <!--{/if}-->
            </div>
           	<div class="nex_nav_user_info">
                <div class="nex_nav_users_name">{$_G[member][username]}<a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1">�û�����</a></div>
                <!--{if $nex_occu}-->
                <div class="nex_nav_users_custometitle">{$nex_occu}</div>
                <!--{else}-->
                <div class="nex_nav_users_custometitle">δ����ְҵ</div>
                <!--{/if}-->
            </div>
            <div class="clear"></div>
        </div>
		<div class="nex_nav_user_btu">
            <ul>
                <li><em>{$nex_user_elements[following]}</em><p>��ע</p></li>
                <li class="nex_nav_user_sep"><em>{$nex_user_elements[follower]}</em><p>��˿</p></li>
                <li><em>{$nex_user_elements[threads]}</em><p>����</p></li>
                <div class="clear"></div>
            </ul>
        </div>
        <!--{elseif !$_G[connectguest]}-->
        <div class="nex_nav_dlbefore">
            <div class="nex_dlbin">
                <a href="member.php?mod=logging&amp;action=login&amp;mobile=2">
                    <div class="nex_dltouxiang"><img src="$_G['style'][styleimgdir]/headertop/default_avator.png" /></div>
                    <div class="nex_nav_beforetxt">
                        <h5>��½�������</h5>
                        <span>�����¼</span>
                    </div>
                    <div class="clear"></div>
                </a>
            </div>
        </div>  
        <!--{/if}--> 
        <div class="nex_comnav_bd">
            <div class="nex_navbox">
                <ul>
                    <li><a href="portal.php?mod=index&mobile=2">�Ż�<em>portal</em></a></li>
                    <li><a href="forum.php?forumlist=1&mobile=2">��̳<em>forum</em></a></li>
                    <li><a href="forum.php?mod=guide&view=newthread&mobile=2">����<em>guide</em></a></li>
					<li><a href="#">��ƽ���<em>designer</em></a></li>
                    <li><a href="#">CGƵ��<em>cger</em></a></li>
                    <li><a href="#">��Ƶ��ЧƵ��<em>midea</em></a></li>
                    <li><a href="#">�̳�Ƶ��<em>tutorial</em></a></li>
					<li><a href="#">����<em>vip</em></a></li>
                    <li><a href="#">��ֵ<em>topup</em></a></li>
                    <li><a href="#">��������<em>about</em></a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>
                
<div class="nex_navbar">
	<div class="nex_navleft">
        <div id="st-trigger-effects" class="nex_navtop_column">
        	<button class="nex_active_nav" data-effect="st-effect-3"></button>
        </div>
    </div>
	<div class="nextoplogo"></div>
    <div class="nex_navright">
        <!--{if $_G['uid']}-->
        <!--{avatar($_G[uid],big)}-->
        <!--{else}-->
        <em></em>
        <!--{/if}-->
    </div>
    <div class="clear"></div>
</div>
<script src="$_G['style'][styleimgdir]/js/define.js"></script>
<script src="$_G['style'][styleimgdir]/js/effect.js"></script>

