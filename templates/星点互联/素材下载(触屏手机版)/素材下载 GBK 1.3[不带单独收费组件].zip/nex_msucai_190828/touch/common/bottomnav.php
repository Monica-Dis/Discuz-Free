<?php echo 'From: DisM.taobao.com';exit;?>

<div class="nex_bottomnav">
	<div class="nex_bottominter">
    	<ul>
        	<li>
            	<a href="portal.php?mod=index&mobile=2">
                	<i class="nex_iconbtm1"></i>
                    <p>�Ż�</p>
                </a>
            </li>
            <li>
            	<a href="forum.php?mod=forumdisplay&fid=49&mobile=2">
                	<i class="nex_iconbtm2"></i>
                    <p>���</p>
                </a>
            </li>
            <li class="nex_bottombtns">
            	<a href="forum.php?mod=forumdisplay&fid=49&mobile=2">
                	<i class="nex_iconbtm3"></i>
                    <p>��Ʒ</p>
                </a>
            </li>
            <li>
            	<a href="portal.php?mod=list&catid=2&mobile=2">
                	<i class="nex_iconbtm4"></i>
                    <p>�̳�</p>
                </a>
            </li>
            <li>
            	<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1&mobile=2">
                	<i class="nex_iconbtm5"></i>
                    <p>�ҵ�</p>
                    <!--{if $_G[member][newpm]}-->
                    <em></em>
                    <!--{elseif $_G[member][newprompt]}-->
                    <em></em>
                    <!--{/if}-->
                </a>
            </li>
            <div class="clear"></div>
        </ul>
    </div>
</div>
