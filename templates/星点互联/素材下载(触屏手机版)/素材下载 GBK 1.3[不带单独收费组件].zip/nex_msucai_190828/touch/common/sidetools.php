<?php echo 'From: DisM.taobao.com';exit;?>
<div class="nex_threadinertools">
	<ul>
    	<li class="nex_threadinertools_home"><a href="portal.php?mod=index&mobile=2"></a></li>
        <li class="nex_threadinertools_scrolltop"><a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a></li>
    </ul>
</div>

