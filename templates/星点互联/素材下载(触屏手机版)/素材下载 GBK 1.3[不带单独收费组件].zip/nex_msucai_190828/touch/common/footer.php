<?php echo 'From: DisM.taobao.com';exit;?>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<div id="mask" style="display:none;"></div>

<!--{if !$nofooter}-->
<div class="footer nex_footer">
    <div class="nex_footer_btm">
    	
        <div class="nex_ft_intel_links">
            <a href="http://t.cn/Aiux1eta" target="_blank">��������</a><em>|</em><a href="http://t.cn/Aiux1eta" target="_blank">��ϵ����</a><em>|</em><a href="http://t.cn/Aiux1eta" target="_blank">��Ʒ��Դ</a><em>|</em><a href="http://t.cn/Aiux1eta" target="_blank">�����Ա</a><em>|</em><a href="http://t.cn/Aiux1eta" target="_blank">��������</a>
        </div>
    	<div class="nex_footer_btmintel">
        	<ul>
            	<li>&copy; Comsenz Inc.&nbsp;Neoconex�ǵ㻥��</li>
                <li><!--{if $_G['setting']['icp']}--> <a href="http://www.miitbeian.gov.cn/" target="_blank">$_G['setting']['icp']</a> <!--{/if}--></li>
                <div class="clear"></div>
            </ul>
        </div>
    </div>
    
    
    
</div>
<div class="nex_footer_djs"></div>
<!--{/if}-->

</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->

