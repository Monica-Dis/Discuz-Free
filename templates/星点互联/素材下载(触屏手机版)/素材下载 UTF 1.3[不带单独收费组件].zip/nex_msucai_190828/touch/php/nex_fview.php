<?php

if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}

$nex_post_grids = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$post[uid]'"));
$nex_post_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_post_grids'"));
$nex_post_gender = DB::result(DB::query("SELECT gender FROM ".DB::table('common_member_profile')." WHERE uid = '$post[uid]'"));
$nex_fidnum = DB::result(DB::query("SELECT fid FROM ".DB::table('forum_thread')." WHERE tid = '$_G[tid]'"));
$nex_bbname = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$nex_fidnum'"));

$nex_post_grids = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$post[uid]'"));
$nex_post_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_post_grids'"));
$nex_post_gender = DB::result(DB::query("SELECT gender FROM ".DB::table('common_member_profile')." WHERE uid = '$post[uid]'"));


?>