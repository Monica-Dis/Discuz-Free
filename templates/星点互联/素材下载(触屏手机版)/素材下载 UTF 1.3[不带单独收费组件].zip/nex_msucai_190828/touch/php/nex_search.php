<?php
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_attachs = DB::result(DB::query("SELECT attachment FROM ".DB::table('forum_thread')." WHERE tid = '$nexsearch_thread[tid]'"));
$nex_search_threadfid = DB::result(DB::query("SELECT fid FROM ".DB::table('forum_thread')." WHERE tid = '$nexsearch_thread[tid]'"));
$nex_search_column = DB::result(DB::query("SELECT name FROM ".DB::table('forum_forum')." WHERE fid = '$nex_search_threadfid'"));
$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($nexsearch_thread['tid']);
$firstpids = intval($post['pid']);
$nex_search_thread = substr($nexsearch_thread[tid], -1); $nex_search_listspic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$nex_search_thread.'')." WHERE tid = '$nexsearch_thread[tid]' AND pid='$firstpids' AND isimage = '1' ORDER BY `aid` ASC LIMIT 1");

?>