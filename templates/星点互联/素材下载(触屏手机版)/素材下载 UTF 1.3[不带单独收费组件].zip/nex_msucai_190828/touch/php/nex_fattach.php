<?php

if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_threadpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($nex_threadsinpivs['tid']);
$firstpids = intval($nex_threadpost['pid']);
$nex_attnums = substr($nex_threadsinpivs[tid], -1);$attrss = DB::result(DB::query("SELECT count(*) FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$nex_threadsinpivs[tid]' AND pid='$firstpids' AND isimage = '1'"));



?>