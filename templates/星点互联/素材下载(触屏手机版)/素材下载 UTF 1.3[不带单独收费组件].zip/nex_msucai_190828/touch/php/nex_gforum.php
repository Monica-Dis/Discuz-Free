<?php

if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}

$nex_authoridx = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_bbs_date = DB::result(DB::query("SELECT dateline FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_sortypes = DB::result(DB::query("SELECT attachment FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_tdsconts = DB::result(DB::query("SELECT message FROM ".DB::table('forum_post')." WHERE tid = '$thread[tid]' AND first = '1' ")); 
$summary_echo = preg_replace ("/\[[a-z][^\]]*\]|\[\/[a-z]+\]/i",'',preg_replace("/\[attach\]\d+\[\/attach\]/i",'',$nex_tdsconts));
$nex_thread_grids = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$nex_authoridx'"));
$nex_thread_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_thread_grids'"));
$nex_user_gender = DB::result(DB::query("SELECT gender FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_user_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_user_city = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_usercp = DB::result(DB::query("SELECT customstatus FROM ".DB::table('common_member_field_forum')." WHERE uid = '$nex_authoridx'"));
$usergroupID = DB::fetch_first("SELECT t1.*, t2.* FROM ".DB::table('common_member')." t1 LEFT JOIN ".DB::table('common_usergroup')." t2 ON t1.groupid=t2.groupid WHERE t1.uid ='$nex_authoridx'");


        

$nex_thread_identities = DB::result(DB::query("SELECT typeid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'"));
$nex_thread_typehtml = DB::result(DB::query("SELECT name FROM ".DB::table('forum_threadclass')." WHERE typeid = '$nex_thread_identities'"));


$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
$firstpids = intval($post['pid']);
$thread_id = substr($thread[tid], -1); $nex_localpic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$thread_id.'')." WHERE tid = '$thread[tid]' AND pid='$firstpids' AND isimage = '1' ORDER BY `aid` ASC LIMIT 6");


$nex_g_province = DB::result(DB::query("SELECT resideprovince FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_g_adds = DB::result(DB::query("SELECT residecity FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));

$nex_thread_grids = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$nex_authoridx'"));
$nex_thread_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_thread_grids'"));


?>