<?php

if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread['tid']);
$firstpids = intval($post['pid']);
$nex_attnums = substr($thread[tid], -1); 
$nex_threadlistspic = DB::fetch_all("SELECT * FROM ".DB::table('forum_attachment_'.$nex_attnums.'')." WHERE tid = '$thread[tid]' AND pid='$firstpids' AND isimage = '1' ORDER BY `aid` ASC LIMIT 9");


?>