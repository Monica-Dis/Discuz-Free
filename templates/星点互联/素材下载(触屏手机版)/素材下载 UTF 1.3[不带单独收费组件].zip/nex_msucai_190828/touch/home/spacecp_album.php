<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $_G[home_tpl_titles] = array($album[albumname], '{lang album}');}-->
<!--{template common/header}-->

<!--{if $_GET['op'] == 'edit'}-->
<div class="nex_usertopnav">
    <a href="javascript:;" onclick="history.go(-1);" class="nex_usercenter_back"></a>
    <span>{lang edit_album_information}</span>
</div>
<form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=edit&albumid=$albumid">
  <input type="hidden" name="formhash" value="{FORMHASH}" />
  <div style="height:15px;"></div>
  <div class="post_from">
    <ul class="postlist">
      <li class="nex_Ablum_bulks"> 
        <span class="nex_text_name">{lang album_name}</span>
        <span class="nex_text_htmlbox"><input type="text" id="albumname" name="albumname" value="$album[albumname]" size="20" class="px" /></span> 
      </li>
      <li class="nex_Ablum_bulks">{lang album_depict}</li>
      <li class="nex_Ablum_bulks"> 
        <span class="nex_text_htmlbox"><textarea name="depict" id="depict" class="pt" cols="40" style="height:100px;">$album[depict]</textarea></span> 
      </li>
      <!--{if $categoryselect}-->
      <li class="nex_Ablum_bulks"> 
        <span class="nex_text_name">{lang site_categories}</span>
        <span class="html nex_Ablum_bulks">$categoryselect</span> 
      </li>
      <!--{/if}-->
      <li class="nex_Ablum_bulks"> 
        <span class="nex_text_name">{lang privacy_settings}</span>
        <span class="html nex_Ablum_bulks">
          <select name="friend" onchange="passwordShow(this.value);" class="ps">
              <option value="0"$friendarr[0]>{lang friendname_0}</option>
              <option value="1"$friendarr[1]>{lang friendname_1}</option>
              <option value="2"$friendarr[2]>{lang friendname_2}</option>
              <option value="3"$friendarr[3]>{lang friendname_3}</option>
              <option value="4"$friendarr[4]>{lang friendname_4}</option>
          </select>
          
        </span> 
      </li>
    </ul>
      
    <ul id="span_password" class="postlist" style="$passwordstyle">
      <li class="nex_Ablum_bulks"> 
        <span class="nex_text_name">{lang password}</span>
        <span class="nex_text_htmlbox"><input type="text" name="password" value="$album[password]" size="10" class="px" /></span> 
      </li>
    </ul>
    
    <ul id="tb_selectgroup" class="postlist" style="$selectgroupstyle">
      <li class="nex_Ablum_bulks"> 
        <span class="nex_text_name">{lang specified_friends}</span>
        <span class="html nex_Ablum_bulks">
          <select name="selectgroup" onchange="getgroup(this.value);" class="ps">
              <option value="">{lang from_friends_group}</option>
              <!--{loop $groups $key $value}-->
              <option value="$key">$value</option>
              <!--{/loop}-->
          </select>
          
        </span> 
      </li>
      <li class="nex_Ablum_bulks">{lang friend_name_space}</li>
      <li class="nex_Ablum_bulks"> 
        <span class="nex_text_htmlbox"><textarea name="target_names" id="target_names" style="height:100px;" class="pt">$album[target_names]</textarea></span> 
      </li>
    </ul>
    
    <p>
      <input type="hidden" name="referer" value="{echo dreferer()}" />
	  <input type="hidden" name="editsubmit" value="true" />
	  <button name="submit" type="submit" class="pn button" value="true">{lang determine}</button>
    </p>
  </div>
  
</form>
<script>
function passwordShow(value)
{
	if(value==4) {
		document.getElementById('span_password').style.display = '';
		document.getElementById('tb_selectgroup').style.display = 'none';
	} else if(value==2) {
		document.getElementById('span_password').style.display = 'none';
		document.getElementById('tb_selectgroup').style.display = '';
	} else {
		document.getElementById('span_password').style.display = 'none';
		document.getElementById('tb_selectgroup').style.display = 'none';
	}
}

function getgroup(gid)
{
	if(gid)
	{
		$.ajax({
			type:'GET',
			url:'home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid='+gid,
			dataType:'xml'
		})
		.success(function(s)
		{
			s = s.lastChild.firstChild.nodeValue
			var testStr = s.replace(/<\/?.+?>/g,"");

			var resultStr = testStr.replace(/\ +/g, ""); //去掉空格
            resultStr = resultStr.replace(/[\r\n]/g, ""); //去掉回车换行

			resultStr = resultStr + ' ';
			document.getElementById('target_names').innerHTML += resultStr;
	    });
	}
}
</script>
<!--{elseif $_GET['op'] == 'editpic'}--> 
  <form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=editpic&albumid=$albumid&nojump=1">
    <input type="hidden" name="page" value="$page" />
    <input type="hidden" name="editpicsubmit" value="true" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="ids[{$value[picid]}]" value="{$value[picid]}">
    
    <div class="tip">
      <h3 class="nex_Ablum_edit_title">{lang edit_pic}</h3>
      
      <div class="c">
        <ul class="postlist">
          
          <li class="nex_Ablum_bulks"> 
            <span class="nex_text_name">&#23558;&#22270;&#29255;</span>
            <span class="html nex_Ablum_bulks">
              <select name="subop" class="ps vm" onchange="passwordShow(this.value);">
                <option value="delete">{lang delete}</option>
                <option value="move">{lang move_to}</option>
              </select>
              
            </span> 
          </li>
          
          <!--{if $albumlist}-->
          <li class="nex_Ablum_bulks" id="move_to" style="display:none;"> 
            <span class="html nex_Ablum_bulks">
              <select name="newalbumid" class="ps vm">
                <!--{loop $albumlist $key $value}--> 
                <!--{if $albumid != $value[albumid]}-->
                <option value="$value[albumid]">$value[albumname]</option>
                <!--{/if}--> 
                <!--{/loop}--> 
                <!--{if $albumid>0}-->
                <option value="0">{lang default_album}</option>
                <!--{/if}-->
              </select>
              
            </span> 
          </li>
          <!--{/if}-->
        </ul>
        
      </div>
      
       <div class="o pns nex_pns_btm">
          <button type="submit" name="deletesubmitbtn" value="true" class="pn pnc formdialog nex_confirmedbtn">{lang determine}</button>
          <a class="pnc nex_canceled" href="javascript:;" onclick="popup.close();">{lang cancel}</a>
           <div class="clear"></div>
      </div>
      
    </div>
    
  </form>
<script>
function passwordShow(value)
{
	if(value == 'move')
	{
		document.getElementById('move_to').style.display = '';
	} else {
		document.getElementById('move_to').style.display = 'none';
	}
}
</script>
<!--{elseif $_GET['op'] == 'delete'}-->
<form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=delete&albumid=$albumid&uid=$_GET[uid]&nojump=1">
  <input type="hidden" name="referer" value="{echo dreferer()}" />
  <input type="hidden" name="deletesubmit" value="true" />
  <input type="hidden" name="formhash" value="{FORMHASH}" />
  <div class="tip">
    <h3 class="nex_Ablum_edit_title">{lang delete_album}</h3>
    
    <div class="nex_Ablum_edit_bds">
      <p class="nex_Album_select">
        <select name="moveto" class="ps">
          <option value="-1">{lang completely_remove}</option>
          <option value="0">{lang move_to_default_album}</option>
          <!--{loop $albums $value}-->
          <option value="$value[albumid]">{lang move_to} $value[albumname]</option>
          <!--{/loop}-->
        </select>
        
      </p>
    </div>
    
    <div class="o pns nex_pns_btm">
        <button type="submit" name="deletesubmitbtn" value="true" class="pn pnc formdialog nex_confirmedbtn">{lang determine}</button>
        <a class="pnc nex_canceled" href="javascript:;" onclick="popup.close();">{lang cancel}</a>
        <div class="clear"></div>
    </div>
    
  </div>
</form>
<!--{elseif $_GET['op'] == 'edittitle'}-->
<form id="titleform" name="titleform" action="home.php?mod=spacecp&ac=album&op=editpic&subop=update&albumid=$pic[albumid]&nojump=1" method="post" autocomplete="off">
  <input type="hidden" name="referer" value="{echo dreferer()}" />
  <input type="hidden" name="formhash" value="{FORMHASH}" />
  <input type="hidden" name="editpicsubmit" value="true" />
  <!--{if $_G[inajax]}-->
  <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
  <!--{/if}-->
  <div class="tip">
    <h3 class="nex_Ablum_edit_title">{lang edit_description}</h3>
    
    <div class="c">
      <textarea name="title[{$pic[picid]}]" cols="50" rows="7" class="pt">$pic[title]</textarea>
    </div>
  
     <div class="o pns nex_pns_btm">
        <button type="submit" name="editpicsubmit_btn" value="true" class="pn pnc formdialog nex_confirmedbtn">{lang update}</button>
        <a class="pnc nex_canceled" href="javascript:;" onclick="popup.close();">{lang cancel}</a>
         <div class="clear"></div>
    </div>
    
  </div>
</form>
<!--{elseif $_GET[op] == 'edithot'}-->
<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=album&op=edithot&picid=$picid&nojump=1">
  <input type="hidden" name="referer" value="{echo dreferer()}" />
  <input type="hidden" name="hotsubmit" value="true" />
  <input type="hidden" name="formhash" value="{FORMHASH}" />
  <div class="tip">
    <h3 class="nex_Ablum_edit_title">{lang adjust_hot}</h3>
    
    <div class="c postlist nex_Ablum_bulks">
      <span class="nex_text_name">{lang new_hot}</span>
      <span class="nex_text_htmlbox"><input type="text" name="hot" value="$pic[hot]" size="10" class="px align_center" /></span>
    </div>
  
     <div class="o pns nex_pns_btm">
        <button type="submit" name="btnsubmit" value="true" class="pn pnc formdialog nex_confirmedbtn">{lang determine}</button>
        <a class="pnc nex_canceled" href="javascript:;" onclick="popup.close();">{lang cancel}</a>
         <div class="clear"></div>
    </div>
    
  </div>
</form>
<!--{elseif $_GET[op] == 'saveforumphoto'}-->
<form id="saveforumphoto" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=album&op=saveforumphoto&aid=$_GET[aid]&nojump=1">
  <input type="hidden" name="referer" value="{echo dreferer()}" />
  <input type="hidden" name="savephotosubmit" value="true" />
  <input type="hidden" name="formhash" value="{FORMHASH}" />
  <input type="hidden" name="aid" value="$_GET[aid]" />
  <!--{if $_G[inajax]}-->
  <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
  <!--{/if}-->
  <div class="tip">
    <h3 class="nex_Ablum_edit_title">{lang save_to_album}</h3>
    
    <div class="c postlist nex_Ablum_bulks">
     <span class="nex_text_name">{lang save_to}</span>
     <span class="html nex_Ablum_bulks">
      <select name="albumid" class="ps vm">
        <!--{loop $albumlist $key $value}-->
        <option value="$value[albumid]">$value[albumname]</option>
        <!--{/loop}-->
        <option value="0">{lang default_album}</option>
      </select>
      
      </span>
    </div>

     <div class="o pns nex_pns_btm">
        <button type="submit" name="btnsubmit" value="true" class="pn pnc formdialog nex_confirmedbtn">{lang determine}</button>
        <a class="pnc nex_canceled" href="javascript:;" onclick="popup.close();">{lang cancel}</a>
         <div class="clear"></div>
    </div>
    
  </div>
</form>
<!--{/if}--> 

<!--{template common/footer}--> 
