<?php echo 'From: DisM.taobao.com';exit;?>
<li class="nex_Blog_comment"> 
    <div class="nex_Blog_commentUps">
        <div class="nex_Blog_Cnote">
        	<a href="home.php?mod=space&uid=$value[authorid]&do=profile"><!--{avatar($value[authorid],small)}--></a>
        </div>
        <div class="nex_Blog_Cintel">
            <h5><a href="home.php?mod=space&uid=$value[authorid]" id="author_$value[cid]">{$value[author]}</a></h5>
            <p><!--{date($value[dateline])}--></p>
        </div>
        <div class="clear"></div>
    </div>
    <div class="nex_Blog_message">$value[message]</div>
  
</li>
