<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval parse_str(dreferer(),$surl);}-->

<!--{if (!in_array($surl['do'],array('profile','thread','blog','album','doing')) && !in_array($surl['op'],array('style','background'))) || $surl['mycenter']}-->
    <!--{eval $dreferer = dreferer(); dsetcookie('dreferer', $dreferer);}-->
<!--{else}-->
    <!--{eval $dreferer = $_G['cookie']['dreferer'] ? $_G['cookie']['dreferer'] : dreferer();}-->
<!--{/if}-->

<div class="nex_uc_mylisttop">
	<div class="nex_uc_mylisttopinter">
    	<a href="javascript:history.back()" class="nex_uc_mylisttop_back"></a>
		
    </div>
    <!--{eval include 'template/nex_msucai_190828/touch/php/nex_home_base.php'}-->
    <div class="nex_TL_Top">
    	<div class="nex_TL_Top_avator">
        	<div class="nex_TL_Top_avator_left"><img src="<!--{avatar($space[uid], big, true)}-->" /></div>
            <div class="nex_TL_Top_avator_right">
            	<!--{if $space[self]}-->
                <div class="nex_TL_Top_avator_right_pm">
                	<a href="home.php?mod=space&do=pm"></a>
                </div>
                <!--{/if}-->
                <!--{if !$space[self]}-->
                <div class="nex_TL_Top_avator_right_adds">
                	<a href="home.php?mod=spacecp&amp;ac=friend&amp;op=add&amp;uid={$space[uid]}&amp;handlekey=addfriendhk_{$space[uid]}" id="a_friend_li_{$space[uid]}" onclick="showWindow(this.id, this.href, 'get', 0);">+好友</a>
                </div>
                <!--{/if}-->
                </div>
            <div class="clear"></div>
        </div>
        <div class="nex_TL_Top_infos">
        	<!--self details-->
            <h5><span>{$space[username]}</span><i></i><div class="clear"></div></h5>
            <p>
                <!--{if $nex_self_intros}-->
                {$nex_self_intros}
                <!--{else}-->
                这个人很懒，什么也没有留下。
                <!--{/if}-->
            </p>
        </div>
        <div class="nex_TL_Top_btm">
            <ul>
                <li><em>{$nex_otheruser_elements[threads]}</em><p>主题</p></li>
                <li><em>{$nex_otheruser_elements[posts]}</em><p>发布</p></li>
                <li><em>{$nex_otheruser_elements[follower]}</em><p>粉丝</p></li>
                <li><em>{$nex_otheruser_elements[following]}</em><p>关注</p></li>
                <div class="clear"></div>
            </ul>
        </div>
        
    </div>
	
</div>



