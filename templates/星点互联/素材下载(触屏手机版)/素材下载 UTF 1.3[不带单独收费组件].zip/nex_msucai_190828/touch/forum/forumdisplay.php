<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template common/bottomnav}-->
<!--{template common/sidetools}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_forum.css" />
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/extend_video/audio.css" />
<!-- header start -->
<div class="nex_bbstopnav_displaylist">
    <div class="nex_postbbsbtn"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]"></a></div>
    <h3>$_G['forum'][name]</h3>
    <a href="forum.php?forumlist=1" class="nexback"></a>
</div>
<div class="nex_forumbody">
<!-- header end -->
<!--{if $_G[forum][banner] && !$subforumonly}-->
<div class="nex_bkjsbg_topimg" style="background:url($_G[forum][banner]) center no-repeat; background-size:cover;"></div>
<!--{else}-->
<div class="nex_bkjsbg_topnone"></div>
<!--{/if}-->
<div class="nex_bbsiners">
    <div class="nex_bbslist_icon">
        <!--{if $_G[forum][icon]}-->
        <!--{eval require_once libfile('function/group');}-->
        <img src="data/attachment/common/$_G[forum][icon]" alt="$_G[forum][name]" />
        <!--{else}-->
        <img src="$_G[style][styleimgdir]/bbs/forum_icon.jpg" alt="$_G[forum][name]" />
        <!--{/if}-->
    </div>	
    <div class="nex_bbslist_infos">
        <p>
            <span>{lang index_today}: $_G[forum][todayposts]</span>
            <span>{lang index_threads}: $_G[forum][threads]</span>
            <!--{if $_G[forum][rank]}-->
            <span>{lang rank}: $_G[forum][rank]</span>
            <!--{/if}-->
        </p>
        <a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum" id="a_favorite" class="nex_sc" onclick="showWindow(this.id, this.href, 'get', 0);">
        <span id="number_favorite_num">$_G[forum][favtimes]</span>
        <span id="number_favorite" {if !$_G[forum][favtimes]} {/if}>关注</span>
        </a>
        
    </div>
    <div class="clear"></div>
</div>
<div class="nex_bbs_top_select">
    <ul>
        <li>
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter={if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == ''}on{/if}">全部</a>
        </li>
        <li>
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'lastpost'}on{/if}">{lang latest}</a>
        </li>
        <li>
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'heat'}on{/if}">{lang order_heats}</a>
        </li>
        <li>
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'digest'}on{/if}">{lang digest_posts}</a>
        </li>
        <div class="clear"></div>
    </ul>
</div>
<!--{if $subexists && $_G['page'] == 1}-->
<div class="nex_sub_bk">
	<h5>子版块</h5>
	<ul>
        <!--{loop $sublist $sub}-->
        <li>
            <div class="nex_sublisticons">
            	<div class="nex_sub_list_Icon">
                <!--{if $sub[icon]}-->
                    <a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">$sub[icon]</a>
                <!--{else}-->
                	<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
                    	<img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" alt="$sub[name]" />
                    </a>
                <!--{/if}-->
                </div>
                <div class="nex_sub_list_Names"><a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a></div>
                <div class="clear"></div>
            </div>
        </li>
        <!--{/loop}-->
        <div class="clear"></div>
    </ul>
</div>
<!--{/if}-->
<!--{eval include 'template/nex_msucai_190828/touch/php/nex_puting.php'}-->
<!--{if $nex_putin_tops}-->
<div class="nex_Putintops">
	<ul>
	<!--{loop $nex_putin_tops $key $nex_get_putins}-->
		<li><a href="forum.php?mod=viewthread&tid=$nex_get_putins[tid]&extra=$extra"><em>置顶</em><span>{$nex_get_putins[subject]}</span><i><!--{echo date("Y-m-d",{$nex_get_putins[dateline]})}--></i></a></li>
	<!--{/loop}-->
	</ul>
</div>
<!--{else}-->
<!--{/if}-->
<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->
<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
<div class="nex_sortTypes">
    <ul>
        <!--{hook/forumdisplay_threadtype_inner}-->
        <li id="ttp_all" {if !$_GET['typeid'] && !$_GET['sortid']}class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a></li>
        <!--{if $_G['forum']['threadtypes']}-->
            <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
                <!--{if $_GET['typeid'] == $id}-->
                <li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
                <!--{else}-->
                <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="xg1 num">$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
                <!--{/if}-->
            <!--{/loop}-->
        <!--{/if}-->
    
        <!--{if $_G['forum']['threadsorts']}-->
            <!--{if $_G['forum']['threadtypes']}--><li><span class="pipe">|</span></li><!--{/if}-->
            <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
                <!--{if $_GET['sortid'] == $id}-->
                <li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
                <!--{else}-->
                <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
                <!--{/if}-->
            <!--{/loop}-->
        <!--{/if}-->
        <!--{hook/forumdisplay_filter_extra}-->
        <div class="clear"></div>
    </ul>
</div>
<div class="clear"></div>
<script type="text/javascript">showTypes('thread_types');</script>
<!--{/if}-->
<!--{if !$subforumonly}-->
<!--{if $quicksearchlist && !$_GET['archiveid']}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_forum.css" />
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/fenlei/sortlist.css">
<link rel="stylesheet" type="text/css" href="template/nex_sucai_190828/neoconex/extend_video/audio.css">
<!--{template forum/search_sortoption}-->
<!--{/if}-->
<!--{eval include 'template/nex_msucai_190828/touch/php/nex_picstyle.php'}-->
<!--{if $picstyle == '1'}-->
<div class="threadlist nex_threadlistpics">
    <ul class="nexwaterfall">
        <!--{if $_G['forum_threadcount']}-->
            <!--{loop $_G['forum_threadlist'] $key $thread}-->
            <!--{eval include 'template/nex_msucai_190828/touch/php/nex_attachpic.php'}-->
                <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
                    {eval continue;}
                <!--{/if}-->
                <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                    {eval $displayorder_thread = 1;}
                <!--{/if}-->
                <!--{if $thread['moved']}-->
                    <!--{eval $thread[tid]=$thread[closed];}-->
                <!--{/if}-->
                <li class="nexwateritems">
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] >	
                        <!--{hook/forumdisplay_thread_mobile $key}-->
                        <div class="nex_waterfallpic">
                        <!--{if $nextupian}-->
                        <img src="data/attachment/forum/$nextupian" style="width:100%;">
                        <!--{else}-->
                        <span class="nopic"></span>
                        <!--{/if}-->
                        <!--{eval include 'template/nex_msucai_190828/touch/php/nex_picnum.php'}-->
                        <em>{$nextotlepivs}张</em>
                        </div>
                        <div class="nex_water_botm">
                            <h5 class="threadSubject $thread[highlight]">{$thread[subject]}</h5>
                            <div class="nex_water_tails">
                                <span class="nex_wt_view">$thread[views]</span>
                                <span class="nex_wt_reply">$thread[replies]</span>
                                <div class="clear"></div>
                            </div>
                        </div>
                     </a>
                </li>
            <!--{/loop}-->
        <!--{else}-->
        <li class="noData">
        	<em></em>
            <p>{lang forum_nothreads}</p>
        </li>
        <!--{/if}-->
    </ul>
</div>
<!--{else}-->
<!--{if empty($_G['forum']['sortmode'])}-->
<div class="nex_threadlisttxt">
	<ul>
	<!--{if $_G['forum_threadcount']}-->
		<!--{loop $_G['forum_threadlist'] $key $thread}-->
        	<!--{eval include 'template/nex_msucai_190828/touch/php/nex_forum.php'}-->
			<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
				{eval continue;}
			<!--{/if}-->
			<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
				{eval $displayorder_thread = 1;}
			<!--{/if}-->
			<!--{if $thread['moved']}-->
				<!--{eval $thread[tid]=$thread[closed];}-->
			<!--{/if}-->
            <li>
            	<!--{if $nex_sortypes == '0'}-->
                <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
                	<div class="nex_thread_style2">
                    	<div class="nex_thread_top">
                            <div class="nex_thread_tl">
                                <!--{avatar($thread[authorid],big)}-->
                                <!--{if $nex_user_gender == '1'}-->
                                <i class="nex_gender_1"></i>
                                <!--{elseif $nex_user_gender == '2'}-->
                                <i class="nex_gender_2"></i>
                                <!--{elseif $nex_user_gender == '0'}-->
                                <!--{/if}-->
                            </div>
                            <div class="nex_thread_tr">
                                <div class="nex_thread_username">
                                    <span>{$thread[author]}</span>
                                </div>
                                <div class="nex_thread_userintel">
                                    <dl>
                                        <!--{if $nex_user_province == '' && $nex_user_city == ''}-->
                                        <!--{else}-->
                                        <dd>{$nex_user_province}{$nex_user_city}</dd>
                                        <em></em>
                                        <!--{/if}-->
                                        <!--{if $nex_usercp}-->
                                        <dd>{$nex_usercp}</dd>
                                        <em></em>
                                        <!--{else}-->
                                        <!--{/if}-->
                                        <dd>Lv.{$nex_thread_levels}</dd>
                                        <div class="clear"></div>
                                    </dl>
                                </div>
                               
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_thread_mid"><!--{if $nex_thread_typehtml}--><em>#{$nex_thread_typehtml}#</em><!--{/if}-->{$thread[subject]}</div>
                        <div class="nex_thread_sums"><!--{echo cutstr($summary_echo,120)}--></div>
                        <div class="nex_thread_btm">
                            <div class="nex_thread_date">{$thread[dateline]}</div>
                            <div class="nex_thread_ingos">
                                <span class="views_icon"><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
                                <span class="replies_icon">{$thread[replies]}</span>
                                <span class="zans_icon">{$thread[recommends]}</span>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        
                    </div>
                </a>
                <!--{else}-->
                	<!--{if $nex_localpic}-->
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
                    	<div class="nex_thread_style1">
                        	<div class="nex_thread_top">
                            	<div class="nex_thread_tl">
                                	<!--{avatar($thread[authorid],big)}-->
                                    <!--{if $nex_user_gender == '1'}-->
                                    <i class="nex_gender_1"></i>
                                    <!--{elseif $nex_user_gender == '2'}-->
                                    <i class="nex_gender_2"></i>
                                    <!--{elseif $nex_user_gender == '0'}-->
                                    <!--{/if}-->
                                </div>
                                <div class="nex_thread_tr">
                                    <div class="nex_thread_username">
                                        <span>{$thread[author]}</span>
                                    </div>
                                    <div class="nex_thread_userintel">
                                        <dl>
                                            <!--{if $nex_user_province == '' && $nex_user_city == ''}-->
                                            <!--{else}-->
                                            <dd>{$nex_user_province}{$nex_user_city}</dd>
                                            <em></em>
                                            <!--{/if}-->
                                            <!--{if $nex_usercp}-->
                                            <dd>{$nex_usercp}</dd>
                                            <em></em>
                                            <!--{else}-->
                                            <!--{/if}-->
                                            <dd>Lv.{$nex_thread_levels}</dd>
                                            <div class="clear"></div>
                                        </dl>
                                    </div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_thread_mid"><!--{if $nex_thread_typehtml}--><em>#{$nex_thread_typehtml}#</em><!--{/if}-->{$thread[subject]}</div>
                            
                            <div class="nex_thread_pics">
                            	<!--{loop $nex_localpic $nex_threadsinpivs}-->
                                <!--{eval include 'template/nex_msucai_190828/touch/php/nex_fattach.php'}-->
                                <!--{if $attrss == '1'}-->
                                <div class="nex_attachpic_one" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                                <!--{/if}-->
                                <!--{if $attrss == '2'}-->
                                <div class="nex_attachpic_two" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                                <!--{/if}-->
                                <!--{if $attrss == '3'}-->
                                <div class="nex_attachpic_three" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                                <!--{/if}-->
                                <!--{if $attrss == '4'}-->
                                <div class="nex_attachpic_four" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                                <!--{/if}-->
                                <!--{if $attrss == '5'}-->
                                <div class="nex_attachpic_five" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                                <!--{/if}-->
                                <!--{if $attrss == '6'}-->
                                <div class="nex_attachpic_six" style="background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></div>
                                <!--{/if}-->
                                <!--{/loop}-->
                                <div class="clear"></div>
                            </div>
                            <div class="nex_thread_btm">
                            	<div class="nex_thread_date">{$thread[dateline]}</div>
                                <div class="nex_thread_ingos">
                                	<span class="views_icon"><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
                                    <span class="replies_icon">{$thread[replies]}</span>
                                    <span class="zans_icon">{$thread[recommends]}</span>
                                    <div class="clear"></div>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </div>
                    </a>
                    <!--{else}-->
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
                        <div class="nex_thread_style2">
                            <div class="nex_thread_top">
                                <div class="nex_thread_tl">
                                    <!--{avatar($thread[authorid],big)}-->
                                    <!--{if $nex_user_gender == '1'}-->
                                    <i class="nex_gender_1"></i>
                                    <!--{elseif $nex_user_gender == '2'}-->
                                    <i class="nex_gender_2"></i>
                                    <!--{elseif $nex_user_gender == '0'}-->
                                    <!--{/if}-->
                                </div>
                                <div class="nex_thread_tr">
                                    <div class="nex_thread_username">
                                        <span>{$thread[author]}</span>
                                    </div>
                                    <div class="nex_thread_userintel">
                                        <dl>
                                            <!--{if $nex_user_province == '' && $nex_user_city == ''}-->
                                            <!--{else}-->
                                            <dd>{$nex_user_province}{$nex_user_city}</dd>
                                            <em></em>
                                            <!--{/if}-->
                                            <!--{if $nex_usercp}-->
                                            <dd>{$nex_usercp}</dd>
                                            <em></em>
                                            <!--{else}-->
                                            <!--{/if}-->
                                            <dd>Lv.{$nex_thread_levels}</dd>
                                            <div class="clear"></div>
                                        </dl>
                                    </div>
                                    <div class="nex_threadnullimg nex_threadnullimgx">附件</div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_thread_mid"><!--{if $nex_thread_typehtml}--><em>#{$nex_thread_typehtml}#</em><!--{/if}-->{$thread[subject]}</div>
                            <div class="nex_thread_sums"><!--{echo cutstr($summary_echo,120)}--></div>
                            <div class="nex_thread_btm">
                                <div class="nex_thread_date">{$thread[dateline]}</div>
                                <div class="nex_thread_ingos">
                                    <span class="views_icon"><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span>
                                    <span class="replies_icon">{$thread[replies]}</span>
                                    <span class="zans_icon">{$thread[recommends]}</span>
                                    <div class="clear"></div>
                                </div>
                                <div class="clear"></div>
                            </div>
                            
                        </div>
                    </a>
                    <!--{/if}-->
                <!--{/if}-->
            </li>
		<!--{/loop}-->
        
		<div class="nex_bbs_pagetops">我是有底线的~</div>
	<!--{else}-->
		<li class="noData">
        	<em></em>
            <p>{lang forum_nothreads}</p>
        </li>
	<!--{/if}-->
	</ul>
</div>
<!--{else}-->
<!--{subtemplate forum/forumdisplay_sort}-->
<style type="text/css">
.nex_bbs_top_select{ display:none;}
</style>
<!--{/if}-->
<!--{/if}-->
$multipage
<!--{/if}-->
<!-- main threadlist end -->
<div class="pullrefresh" style="display:none;"></div>
</div>
<script type="text/javascript">

	jQuery(".nex_tab_video_tag ul li").each(function(s){
		
		jQuery(this).click(function(){
			
			jQuery(this).addClass("cur").siblings().removeClass("cur");
			
			jQuery(".nex_tab_video_conts ul li").eq(s).show().siblings().hide();
			
			})
		});
	var video = jQuery('.nex_video_grids');
	var videoLi = jQuery('dd');

	videoLi.hover(function() {
		var videoData = jQuery(this).data('video-url');

		jQuery(this).find('video').attr('src', videoData);

	}, function() {

		jQuery(this).find('video').attr('src', '');
	});
	jQuery( function()
	{
		jQuery( 'audio' ).audioPlayer();
	});
</script>
<!--{template common/footer}-->

