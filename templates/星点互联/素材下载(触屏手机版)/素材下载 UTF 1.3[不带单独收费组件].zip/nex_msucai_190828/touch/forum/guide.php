<?php echo 'From: DisM.taobao.com';exit;?>
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_guide.css" />
<!--{template common/header}-->

<!--{template common/bottomnav}--> 

<div id="st-container" class="st-container">
	<div class="st-pusher">
	<!--{template common/headernav}-->
    <div class="nex_Guider_BD">
        <div class="nex_Guide_mian">
            <div class="nex_Guidetop_select">
                <ul>
                  <li $currentview['newthread']><a href="forum.php?mod=guide&view=newthread">最新帖子</a></li>
                    <li $currentview['hot']><a href="forum.php?mod=guide&view=hot">热门帖子</a></li>
                    <li $currentview['digest']><a href="forum.php?mod=guide&view=digest">精华帖子</a></li>
                    <li $currentview['new']><a href="forum.php?mod=guide&view=new">最新回复</a></li>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
        <!-- main threadlist start -->
        <div class="nex_threadlisttxt nex_Guide_rolling">
            <!--{loop $data $key $list}-->
                <!--{subtemplate forum/guide_list_row}-->
            <!--{/loop}-->
        </div>
        <!-- main threadlist end -->
        
        $multipage
        
        <div class="pullrefresh" style="display:none;"></div>
        <!--{template common/sidetools}-->
    
    
    </div>
	</div>
</div>
<!--{template common/footer}-->
