<?php echo 'From: DisM.taobao.com';exit;?>
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/extend_video/audio.css" />
<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->
<!--{template common/sidetools}-->
<!--{hook/viewthread_top_mobile}-->
<div class="nex_bbstopnav_displaylist">
    <div class="nex_postbbsbtn"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]"></a></div>
    <a href="javascript:;" onclick="history.go(-1);" class="nexback"></a>
</div>
<div class="nex_vt_container">
<!-- main postlist start -->
<div class="postlist">
	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{if $post[first]}-->
    <div class="nex_viewthreadTop">
        <div class="nex_viewthread_intel">
            <h3>
                <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
                    [{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
                <!--{/if}-->
                <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
                    [{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]
                <!--{/if}-->
                $_G[forum_thread][subject]
                <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
                <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
                <!--{/if}-->
            </h3>
            <!-- manage start -->
            <!--{if $post[first]}-->
            <a href="#moption_$post[pid]" class="nex_Managing_btn popup blue"></a>
            <div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
                <!--{if !$_G['forum_thread']['special']}-->
                <a type="button" value="{lang edit}" class="nex_redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a>
                <!--{/if}-->
                <input type="button" value="{lang delete}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
                <input type="button" value="{lang close}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
                <input type="button" value="{lang admin_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
                <input type="button" value="{lang topicadmin_warn_add}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
            </div>
            <!--{else}-->
            <!--{/if}-->
            <div class="clear"></div>
            <!-- manage end -->
        </div>
        <!--{eval include 'template/nex_msucai_190828/touch/php/nex_fview.php'}-->
        <div class="nex_viewthread_info">
        	<div class="nex_viewthread_include">
            	<div class="nex_viewthreadtop_avatar">
                    <a href="home.php?mod=space&uid=space&uid=$_G[forum_thread][authorid]&do=profile&from=space">
                        <img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, big, true)}--><!--{else}--><!--{avatar($post[authorid], big, true)}--><!--{/if}-->" />
                    </a>
                </div>
                <div class="nex_viewthreadtop_others">
                	<div class="nex_viewthreadtop_ost">
                    	<h4>$_G[forum_thread][author]</h4>
                        <div class="nex_vt_lvnid">
                        	<!--{if $nex_post_levels <= '1'}-->
                            <i class="nex_level1"><em>{$nex_post_levels}</em></i>
                            <!--{elseif $nex_post_levels > '1' and $nex_post_levels <= '3'}-->
                            <i class="nex_level2"><em>{$nex_post_levels}</em></i>
                            <!--{elseif $nex_post_levels > '3' and $nex_post_levels <= '6'}-->
                            <i class="nex_level3"><em>{$nex_post_levels}</em></i>
                            <!--{elseif $nex_post_levels > '6'}-->
                            <i class="nex_level4"><em>{$nex_post_levels}</em></i>
                            <!--{/if}-->
                        </div>
                    	<div class="clear"></div>
                    </div>
                    <div class="nex_viewthreadtop_osb">
                    	<span>{$nex_bbname}</span><em></em><i>$post[dateline]</i>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_viewthread_topfav"><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="nex_favs favbtn blue">+收藏</a></div>
            <div class="clear"></div>
        </div>    
        
    </div>  
    
    <div class="nex_vtpostbox_main">
        <!--{if $post['warned']}-->
           <span class="grey quote">{lang warn_get}</span>
            <!--{/if}-->
            <!--{if !$post['first'] && !empty($post[subject])}-->
                <h2><strong>$post[subject]</strong></h2>
            <!--{/if}-->
            <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                <div class="grey quote">{lang message_banned}</div>
            <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                <div class="grey quote">{lang message_single_banned}</div>
            <!--{elseif $needhiddenreply}-->
                <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
            <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
                <!--{template forum/viewthread_pay}-->
            <!--{else}-->

                <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                   <div class="grey quote">{lang admin_message_banned}</div>
                <!--{elseif $post['status'] & 1}-->
                    <div class="grey quote">{lang admin_message_single_banned}</div>
                <!--{/if}-->

                <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                    <!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                        <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                            {lang has_expired}
                        <!--{else}-->
                        
                            <div class="box_ex2 viewsort">
                                <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                            <!--{loop $threadsortshow['optionlist'] $option}-->
                                <!--{if $option['type'] != 'info'}-->
                                    $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                                <!--{/if}-->
                            <!--{/loop}-->
                            </div>
                        <!--{/if}-->
                    <!--{/if}-->
                <!--{/if}-->
                <!--{if $post['first']}-->
                    <!--{if $threadsortshow['typetemplate']}-->
                    <style type="text/css">
                    .nex_bbstopnav_viewthread{ display:none;}
                    </style>
                        $threadsortshow[typetemplate]
                        <div class="clear"></div>
                        <div class="nex_reply_contant">
                        $post[message]
                        </div>
                    <!--{elseif $threadsortshow['optionlist']}-->
                        <div class="typeoption">
                            <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                {lang has_expired}
                            <!--{else}-->
                                    <h3>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h3>
                                        <!--{loop $threadsortshow['optionlist'] $option}-->
                                            <!--{if $option['type'] != 'info'}-->
                                                <li class="n_sort">
                                                    <span>$option[title]:</span>
                                                    <span><!--{if $option['value'] !== ''}-->$option[value] $option[unit]<!--{else}-->-<!--{/if}--></span>
                                                </li>
                                            <!--{/if}-->
                                        <!--{/loop}-->
                            <!--{/if}-->
                        </div>
                        <div class="clear"></div>
                        <div class="nex_reply_contant">
                        $post[message]
                        </div>
                   <!--{elseif !$_G[forum_thread][special]}-->
                        <div class="nex_reply_contant">
                        $post[message]
                        </div>
                    <!--{elseif $_G[forum_thread][special] == 1}-->
                       <div class="nex_reply_contant"> <!--{template forum/viewthread_poll}--></div>
                    <!--{elseif $_G[forum_thread][special] == 2}-->
                        <div class="nex_reply_contant"><!--{template forum/viewthread_trade}--></div>
                    <!--{elseif $_G[forum_thread][special] == 3}-->
                        <div class="nex_reply_contant"><!--{template forum/viewthread_reward}--></div>
                    <!--{elseif $_G[forum_thread][special] == 4}-->
                        <div class="nex_reply_contant"><!--{template forum/viewthread_activity}--></div>
                    <!--{elseif $_G[forum_thread][special] == 5}-->
                        <div class="nex_reply_contant"><!--{template forum/viewthread_debate}--></div>
                    <!--{elseif $threadplughtml}-->
                        <div class="nex_reply_contant">
                        $threadplughtml
                        $post[message]
                        </span>
                    <!--{else}-->
                        <div class="nex_reply_contant">
                        $post[message]
                        </div>
                    <!--{/if}-->
                <!--{else}-->
                        <div class="nex_reply_contant">
                        $post[message]
                        </div>
                <!--{/if}-->
            <!--{/if}-->
        
        <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
        <div class="nex_reply_contant">
        <!--{if $post['attachment']}-->
           <div class="grey quote">
           {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
           </div>
        <!--{elseif $post['imagelist'] || $post['attachlist']}-->
           <!--{if $post['imagelist']}-->
            <!--{if count($post['imagelist']) == 1}-->
            <ul class="img_one">{echo showattach($post, 1)}</ul>
            <!--{else}-->
            <ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $post['attachlist']}-->
            <ul>{echo showattach($post)}</ul>
            <!--{/if}-->
        <!--{/if}-->
        </div>
        <!--{/if}-->	
        <!--signature start-->
        <!--{if $post['signature'] && ($_G['setting']['bannedmessages'] & 4 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)))}-->
            <div class="sign">{lang member_signature_banned}</div>
        <!--{elseif $post['signature'] && !$post['anonymous'] && $showsignatures}-->
            <div class="sign"><div style="max-height:{$_G['setting']['maxsigrows']}px;maxHeightIE:{$_G['setting']['maxsigrows']}px;overflow:hidden;">$post[signature]</div><span></span></div>
        <!--{elseif !$post['anonymous'] && $showsignatures && $_G['setting']['globalsightml']}-->
            <div class="sign">$_G['setting']['globalsightml']</div>
        <!--{/if}-->
        <!--signature end-->	
        <div id="nex_height_dot" style="height:30px;"></div>	
        
        <!--{if !IS_ROBOT && $post['first'] && !$_G['forum_thread']['archiveid']}-->
			<!--{if $post['invisible'] == 0}-->
				<div id="p_btn" class="nex_vt_inner_fuction">
					<!--{if !empty($_G['setting']['pluginhooks']['viewthread_share_method'])}-->
						<!--{hook/viewthread_share_method}-->
					<!--{/if}-->
					<ul>
                    	<li class="nex_vt_if_read"><em>$_G[forum_thread][views]</em><p>阅读</p></li>
                        <li class="nex_vt_if_reply"><em>$_G[forum_thread][allreplies]</em><p>回复</p></li>
                        <li class="nex_vt_if_fav">
                        	<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" id="k_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" onmouseover="this.title = $('favoritenumber').innerHTML + ' {lang activity_member_unit}{lang thread_favorite}'">
                                <em>{$_G['forum_thread']['favtimes']}</em>
                                <p>{lang thread_favorite}</p>
                        	</a>
                        </li>
                        <!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
                            <!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
                            <li class="nex_vt_if_support">
                                <a id="recommend_add" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', 'recommendupdate({$_G['group']['allowrecommend']})');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = $('recommendv_add').innerHTML + ' {lang activity_member_unit}$_G[setting][recommendthread][addtext]'">
                                	<em>$_G[forum_thread][recommend_add]</em>
                                    <p>$_G['setting']['recommendthread'][addtext]</p>
                                    
                                </a>
                            </li>
                            <!--{/if}-->
                            <!--{if !empty($_G['setting']['recommendthread']['subtracttext'])}-->
                            <li class="nex_vt_if_drop">
                                <a id="recommend_subtract" href="forum.php?mod=misc&action=recommend&do=subtract&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', 'recommendupdate(-{$_G['group']['allowrecommend']})');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = $('recommendv_subtract').innerHTML + ' {lang activity_member_unit}$_G[setting][recommendthread][subtracttext]'" title="{lang makebottomonce}">
                                	<em>$_G[forum_thread][recommend_sub]</em>
                                    <p>$_G['setting']['recommendthread'][subtracttext]</p>
                                    
                                </a>
                            </li>
                            <!--{/if}-->
                        <!--{/if}-->
                        <!--{hook/viewthread_useraction}-->
                        <div class="clear"></div>
                    </ul>
				</div>
			<!--{/if}-->

		<!--{/if}-->			
        
        <div class="clear"></div>
        
    </div>
    <!--{/if}-->
    
	<!--{hook/viewthread_posttop_mobile $postcount}-->
    <div class="nex_vt_post_box">
        <div class="plc cl display pi" href="#replybtn_$post[pid]" id="pid$post[pid]">
        <!--{eval include 'template/nex_msucai_190828/touch/php/nex_fview.php'}-->
            <!--{if !$post[first]}-->
            <div class="nex_vt_postreply_box">
                <div class="nex_vt_replyavator"><a href="home.php?mod=space&uid=$post[authorid]"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, big, true)}--><!--{else}--><!--{avatar($post[authorid], big, true)}--><!--{/if}-->" /></a></div>
                <div class="nex_vt_replyothers">
                    <div class="nex_vt_replyothers_top">
                        <div class="nex_vt_replyothers_topl">
                            <div class="nex_vt_replyothers_topname">
                                <h4>{$post[author]}</h4>
                                <div class="nex_vt_lvnid">
                                    <!--{if $nex_post_levels <= '1'}-->
                                    <i class="nex_level1"><em>{$nex_post_levels}</em></i>
                                    <!--{elseif $nex_post_levels > '1' and $nex_post_levels <= '3'}-->
                                    <i class="nex_level2"><em>{$nex_post_levels}</em></i>
                                    <!--{elseif $nex_post_levels > '3' and $nex_post_levels <= '6'}-->
                                    <i class="nex_level3"><em>{$nex_post_levels}</em></i>
                                    <!--{elseif $nex_post_levels > '6'}-->
                                    <i class="nex_level4"><em>{$nex_post_levels}</em></i>
                                    <!--{/if}-->
                                </div>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_vt_replyothers_topintel">
                                <span><!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}--></span><em></em><i>$post[dateline]</i>
                                <div class="clear"></div>
                            </div>
                        </div>
                        <div class="nex_vt_replyothers_toprtools">
                            <!--{if $_G['forum']['ismoderator']}-->
                            <!-- manage start -->
                            <!--{if $post[first]}-->
                                <div class="nex_vt_replytools"><a href="#moption_$post[pid]" class="nex_vt_modifications y"></a></div>
                                <div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
                                    <!--{if !$_G['forum_thread']['special']}-->
                                    <input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
                                    <!--{/if}-->
                                    <input type="button" value="{lang delete}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
                                    <input type="button" value="{lang close}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
                                    <input type="button" value="{lang admin_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
                                    <input type="button" value="{lang topicadmin_warn_add}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
                                </div>
                            <!--{else}-->
                                <div class="nex_vt_replytools"><a href="#moption_$post[pid]" class="popup nex_vt_modifications y"></a></div>
                                <div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
                                    <input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
                                    <!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
                                    <!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
                                    <!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
                                </div>
                            <!--{/if}-->
                            <!-- manage end -->
                            <!--{/if}-->
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_vt_replyothers_sums">
                        <div class="nex_vtpostbox_bt">
                            <!--{if $post['warned']}-->
                               <span class="grey quote">{lang warn_get}</span>
                                <!--{/if}-->
                                <!--{if !$post['first'] && !empty($post[subject])}-->
                                    <h2><strong>$post[subject]</strong></h2>
                                <!--{/if}-->
                                <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                                    <div class="grey quote">{lang message_banned}</div>
                                <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                                    <div class="grey quote">{lang message_single_banned}</div>
                                <!--{elseif $needhiddenreply}-->
                                    <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
                                <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
                                    <!--{template forum/viewthread_pay}-->
                                <!--{else}-->
            
                                    <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                                       <div class="grey quote">{lang admin_message_banned}</div>
                                    <!--{elseif $post['status'] & 1}-->
                                        <div class="grey quote">{lang admin_message_single_banned}</div>
                                    <!--{/if}-->
            
                                    <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                                        <!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                                            <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                                {lang has_expired}
                                            <!--{else}-->
                                            
                                                <div class="box_ex2 viewsort">
                                                    <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                                                <!--{loop $threadsortshow['optionlist'] $option}-->
                                                    <!--{if $option['type'] != 'info'}-->
                                                        $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                                                    <!--{/if}-->
                                                <!--{/loop}-->
                                                </div>
                                            <!--{/if}-->
                                        <!--{/if}-->
                                    <!--{/if}-->
                                    
                                    <!--{if $post['first']}-->
                                    <!--{if $threadsortshow['typetemplate']}-->
                                    <style type="text/css">
                                    .nex_bbstopnav_viewthread{ display:none;}
                                    </style>
                                        $threadsortshow[typetemplate]
                                        <div class="clear"></div>
                                        <span class="nex_reply_contant">
                                        $post[message]
                                        </span>
                                    <!--{elseif $threadsortshow['optionlist']}-->
                                        <div class="typeoption">
                                            <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                                {lang has_expired}
                                            <!--{else}-->
                                                    <h3>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h3>
                                                        <!--{loop $threadsortshow['optionlist'] $option}-->
                                                            <!--{if $option['type'] != 'info'}-->
                                                                <li class="n_sort">
                                                                    <span>$option[title]:</span>
            
                                                                    <span><!--{if $option['value'] !== ''}-->$option[value] $option[unit]<!--{else}-->-<!--{/if}--></span>
                                                                </li>
                                                            <!--{/if}-->
                                                        <!--{/loop}-->
                                            <!--{/if}-->
                                        </div>
                                        <div class="clear"></div>
                                        <span class="nex_reply_contant">
                                        $post[message]
                                        </span>
                                   <!--{elseif !$_G[forum_thread][special]}-->
                                        <span class="nex_reply_contant">
                                        $post[message]
                                        </span>
                                    <!--{elseif $_G[forum_thread][special] == 1}-->
                                       <span class="nex_reply_contant"> <!--{template forum/viewthread_poll}--></span>
                                    <!--{elseif $_G[forum_thread][special] == 2}-->
                                        <span class="nex_reply_contant"><!--{template forum/viewthread_trade}--></span>
                                    <!--{elseif $_G[forum_thread][special] == 3}-->
                                        <span class="nex_reply_contant"><!--{template forum/viewthread_reward}--></span>
                                    <!--{elseif $_G[forum_thread][special] == 4}-->
                                        <span class="nex_reply_contant"><!--{template forum/viewthread_activity}--></span>
                                    <!--{elseif $_G[forum_thread][special] == 5}-->
                                        <span class="nex_reply_contant"><!--{template forum/viewthread_debate}--></span>
                                    <!--{elseif $threadplughtml}-->
                                        <span class="nex_reply_contant">
                                        $threadplughtml
                                        $post[message]
                                        </span>
                                    <!--{else}-->
                                        <span class="nex_reply_contant">
                                        $post[message]
                                        </span>
                                    <!--{/if}-->
                                <!--{else}-->
                                        <span class="nex_reply_contant">
                                        $post[message]
                                        </span>
                                <!--{/if}-->
                            <!--{/if}-->
                            
                            <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                            <span class="nex_reply_contant">
                            <!--{if $post['attachment']}-->
                               <div class="grey quote">
                               {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
                               </div>
                            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
                               <!--{if $post['imagelist']}-->
                                <!--{if count($post['imagelist']) == 1}-->
                                <ul class="img_one">{echo showattach($post, 1)}</ul>
                                <!--{else}-->
                                <ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
                                <!--{/if}-->
                                <!--{/if}-->
                                <!--{if $post['attachlist']}-->
                                <ul>{echo showattach($post)}</ul>
                                <!--{/if}-->
                            <!--{/if}-->
                            </span>
                            <!--{/if}-->	
                                        
                            <!--{if $post[first]}-->
                            <div class="nex_nex_viewthread_td_rd">
                                <ul>
                                    <li><em class="nex_nod_views">$_G[forum_thread][views]</em></li>
                                    <li><em class="nex_nod_replys">$_G[forum_thread][allreplies]</em></li>
                                    <li><a id="recommend_add" class="replyadd_a nex_dianzan" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', 'recommendupdate({$_G['group']['allowrecommend']})');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = $('recommendv_add').innerHTML + ' {lang activity_member_unit}$_G[setting][recommendthread][addtext]'" title="{lang maketoponce}">点赞<span id="recommendv_add"{if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>$_G[forum_thread][recommend_add]</span></a></li>
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <!--{/if}-->
                            <div class="clear"></div>
                        </div>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            <!--{/if}-->
            
            <!--{if $_G[uid] && $allowpostreply && !$post[first]}-->
            <div id="replybtn_$post[pid]" class="replybtn" display="true" style="display:none;position:absolute;right:0px;top:5px;">
                <input type="button" class="redirect nex_redirect button" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" value="{lang reply}">
            </div>
            <!--{/if}-->
            
            
        </div>
        <!--{if $post['first']}-->
        <div class="nex_vt_posttitles" id="nex_quickreplies">
            <div class="nex_vt_reply_bdl">
                <!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
                <span>全部回复</span>
                <a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&authorid=$_G[forum_thread][authorid]" rel="nofollow" class="nex_lookonly">{lang viewonlyauthorid}</a>
                <!--{elseif !$_G['forum_thread']['archiveid']}-->
                <a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page" rel="nofollow" class="nex_lookall">全部回复</a>
                <span>{lang viewonlyauthorid}</span>
                <!--{/if}-->
                <div class="clear"></div>
            </div>
            <div class="nex_vt_reply_order">
                <ul>
                <!--{if !IS_ROBOT && !$_G['forum_thread']['archiveid'] && $post['first'] }-->
                    <!--{if !$rushreply}-->
                    <li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1"  class="show">倒序</a></li>
                    <li><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2"  class="show">正序</a></li>
                    <!--{/if}-->
                <!--{/if}-->
                </ul>
            </div>
            <div class="clear"></div>
        </div>
        <!--{/if}-->
    </div>
   <!--{hook/viewthread_postbottom_mobile $postcount}-->
   <!--{eval $postcount++;}-->
   <!--{/loop}-->
   <!--{if $_G[forum_thread][replies]<=0}-->
	<div class="nex_vt_nonfirst">
		<P>暂无评论，赶紧抢沙发吧</P>
	</div>
	<!--{/if}-->
   $multipage
	<!--{subtemplate forum/forumdisplay_fastpost}-->  
	<div id="mask" style="display:none;"></div>
</div>
<!-- main postlist end -->

<!--{hook/viewthread_bottom_mobile}-->

<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		}); 
		return false;
	});
	jQuery( function()
	{
		jQuery( 'audio' ).audioPlayer();
	});
	jQuery(function(){
	jQuery('#nex_favtocell').click(function(){jQuery('html,body').animate({scrollTop:jQuery('#nex_height_dot').offset().top}, 600);});})
</script>
<script type="text/javascript">
	jQuery(".nex_class_mianeds ul li").each(function(s){
		jQuery(this).click(function(){
			jQuery(this).addClass("cur").siblings().removeClass("cur");
			jQuery(".nex_class_swipes ul li").eq(s).show().siblings().hide();
			})
		});
		var nex = jQuery('#nex_class_video');
	var video = function (src) {
		nex.attr('src', src);
		jQuery('.nex_mask_video,#nex_class_video').fadeIn();
		nex[0].play();
	}
	jQuery('.nex_mask_video').on('click', function () {
		nex[0].pause();
		jQuery('.nex_mask_video').fadeOut();
		nex.hide();
		nex[0].src = '';
	})
</script>
<script type="text/javascript">
	jQuery(".nex_class_xform dl dd").each(function(s){
		jQuery(this).hover(function(){
			jQuery(this).addClass("kr").siblings().removeClass("kr");
			})
		})
</script>
<!--{template common/footer}-->

