<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template common/bottomnav}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_article.css" />
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->

<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        <div class="nex_Info_list_bg">
            <h5>$cat[catname]</h5>
        </div>
        <!--{if $cat[subs]}-->
        <div class="nex_nextnav">
            <ul>
                <!--{eval $i = 1;}-->
                <!--{loop $cat[subs] $value}-->
                <!--{if $i != 1}--><!--{/if}--><li><a href="{$portalcategory[$value['catid']]['caturl']}" >$value[catname]</a></li><!--{eval $i--;}-->
                <!--{/loop}-->
                <div class="clear"></div>
            </ul>
        </div>
        <!--{/if}-->
        <div class="nex_articalport">
            <!--{ad/text/wp a_t}-->
            <!--{ad/articlelist/mbm hm/1}--><!--{ad/articlelist/mbm hm/2}-->
            <div class="nex_artice">
                <ul>
                    <!--{loop $list['list'] $value}-->
                    <!--{eval $article_url = fetch_article_url($value);}-->
                    <!--{eval include 'template/nex_msucai_190828/touch/php/nex_artlists.php'}-->
                    <!--{if $value[pic]}-->
                        <!--{eval $nex_formats = (@end(explode(".",$value[pic])));}-->
                        <li class="nex_artpic_box">
                            <a href="$article_url">
                            	<div class="nex_artpic_halfintelm">
                                    <div class="nex_artpic_halfintelml"><img src="uc_server/avatar.php?uid=$value[uid]&size=middle" /><span>$value[username]</span><div class="clear"></div></div>
                                    <div class="nex_artpic_halfintelmr">$value[dateline]</div>
                                    <div class="clear"></div>
                                </div>
                                <div class="nex_artpic_halfpic" style="background:url($value[pic]) center no-repeat; background-size:cover;"></div>
                                <div class="nex_artpic_half">
                                    <div class="nex_artpic_halfintel">
                                    	<h5>$value[title]</h5>
                                        <div class="nex_artpic_halfintelb">
                                        	<!--{if $value[catname] && $cat[subs]}-->
                                        	<div class="nex_artpic_halfintelbr">$value[catname]</div>
                                            <!--{else}-->
                                            <div class="nex_artpic_halfintelbr">$value[catname]</div>
                                            <!--{/if}-->
                                        	<div class="nex_artpic_halfintelbl">
                                            	<span class="nex_artpic_fullbtmm_view">$nex_article_details[viewnum]</span>
                                            	<span class="nex_artpic_fullbtmm_reply">$nex_article_details[commentnum]</span>
                                            </div>
                                            
                                            <div class="clear"></div>
                                        </div>
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </a>
                        </li>
                    <!--{else}-->
                    <li>
                        <a href="$article_url">
                            <div class="nex_artpic_low">
                                <h5>$value[title]<em></em></h5>
                                <div class="nex_artmid_level">
                                	<div class="nex_artpic_author">
                                    	<img src="uc_server/avatar.php?uid=$value[uid]&size=middle" />
                                        <span>$value[username]</span>
                                        <div class="clear"></div>
                                    </div>
                                    <div class="nex_artpic_mid_date">$value[dateline]</div>
                                    <div class="clear"></div>
                                </div>
                                
                                <div class="nex_artpic_lowsums">$value[summary]</div>
                                
                                <div class="nex_artpic_lowbbtm">
                                	<div class="nex_artpic_lowbtml">
                                        <!--{if $value[catname] && $cat[subs]}-->
                                        <em>$value[catname]</em>
                                        <!--{else}-->
                                        <em>$cat[catname]</em>
                                        <!--{/if}-->
                                        <div class="clear"></div>
                                    </div>
                                    <div class="nex_artpic_lowbtmr">
                                        <span class="nex_artpic_lowbbtmm_view">$nex_article_details[viewnum]</span>
                                        <span class="nex_artpic_lowbbtmm_reply">$nex_article_details[commentnum]</span>
                                        <div class="clear"></div>
                                    </div>
                                    
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </a>
                    </li>
                    <!--{/if}-->
                    <div class="clear"></div>
                    <!--{/loop}-->
                </ul>
            </div>
            <!--{ad/articlelist/mbm hm/3}--><!--{ad/articlelist/mbm hm/4}-->
            <!--{if $list['multi']}--><div class="pgs cl">{$list['multi']}</div><!--{/if}-->
        </div>
		<!--{template common/footer}-->
	</div>
</div>

















<!--星点互联版权所有-->