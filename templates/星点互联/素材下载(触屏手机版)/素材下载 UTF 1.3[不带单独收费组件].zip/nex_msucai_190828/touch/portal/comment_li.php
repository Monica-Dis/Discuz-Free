<?php echo 'From: DisM.taobao.com';exit;?>
<li>
    <a name="comment_anchor_$comment[cid]"></a>
    <div id="comment_{$comment[cid]}_li" class="ptm pbm bbda cl">
        <div class="nex_portrait_left">
            <a href="home.php?mod=space&uid=$comment[uid]"><!--{avatar($comment[uid],big)}--></a>
        </div>
        <div class="nex_portrait_right">
            <div class="nex_portrait_rightTop">
            	<div class="nex_portrait_rT_l">
                    <!--{if !empty($comment['uid'])}-->
                    <em>$comment[username]</em>
                    <!--{else}-->
                    <em>{lang guest}</em>
                    <!--{/if}-->
                    <span><!--{date($comment[dateline])}--></span>
                </div>
                <div class="nex_portrait_rT_r"><!--{if $nex_artlc == '1'}--><span>最新评论</span><!--{else}--><em>{$nex_artlc}#</em><!--{/if}--></span></div>
                <div class="clear"></div>
            </div>
            <div class="nex_portrait_sums"><!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->$comment[message]<!--{else}--> {lang moderate_not_validate}<!--{/if}--></div>
        </div>
    </div>
</li>
