<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template common/bottomnav}-->
<link rel="stylesheet" type="text/css" href="$_G['style'][styleimgdir]/style/mobile_portal.css" />
<div id="nex_mainbd_top"></div>
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        <div class="nex_rolltoptop"><a id="nex_rolltoptop"></a></div>
        <script type="text/javascript">
		 jQuery(function(){
		  jQuery('#nex_rolltoptop').click(function(){jQuery('html,body').animate({scrollTop:jQuery('#nex_mainbd_top').offset().top}, 600);});})
		</script>
        <!--bg-->
        <div class="nex_index_top_bg">
        	<!--search bar-->
        	<div class="nex_navsearch"><!--{template common/pubsearchform}--></div>
            <!--fast link-->
            <div class="nex_index_fast_link">
            	<div class="nex_index_fast_link_inner">
                    <ul>
						<!--自定义链接-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <div class="nex_index_other">
            <!--hot tropicals-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>热门专题</span>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_tropicals">
                	<ul>

						<!--热门专题-->
                        

                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            
            <!--new update-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>最新素材</span>
                    <a href="#">更多</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_sucai_grids">
                	<ul>
						<!--最新素材-->
                        
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <!--must have-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>设计师必备素材</span>
                    <a href="#">更多</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_sucai_grids">
                	<ul>
                    	<!--设计师必备素材-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <!--sort options-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>素材分类下载</span>
                    <div class="clear"></div>
                </div>
                <div class="nex_sort_options">
                	<ul>
                    	<li class="cur">HTML模板</li>
                        <li>PPT模板</li>
                        <li>免扣元素</li>
                        <li>电商淘宝</li>
                        <li>平面素材</li>
                        <li>高清背景</li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="nex_sort_contents">
                	<dl>
                    	<dd style="display:block;">
                        	<div class="nex_sucai_grids">
                                <ul>
                                    <!--HTML模板-->
                                    
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </dd>
                        <dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--PPT模板-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
						<dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--免扣元素-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
						<dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--电商淘宝-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
						<dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--平面素材-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
						<dd>
                        	<div class="nex_sucai_grids">
								<ul>
									<!--高清背景-->
                                    
									<div class="clear"></div>
								</ul>
							</div>
                        </dd>
                    </dl>
                </div>
                <script type="text/javascript">
					jQuery(".nex_sort_options ul li").each(function(s){
						jQuery(this).click(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_sort_contents dl dd").eq(s).show().siblings().hide();
							})
						})
				</script>
            </div>
            <!--VIP sort-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>VIP素材下载</span>
                    <a href="#">更多</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_sucai_grids">
                    <ul>
                        <!--VIP素材下载-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
            <!--ranklist-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>下载排行榜</span>
                    <ul>
                    	<li class="cur">本周</li>
                        <li>本月</li>
                        <div class="clear"></div>
                    </ul>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_dlrk">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_index_rklist">
                            	<dl>
									<!--本周素材下载排行榜-->
                                    
                                	
                                </dl>
                            </div>
                        </li>
                    	<li>
							<div class="nex_index_rklist">
                            	<dl>
									<!--本月素材下载排行榜-->
                                    
                                </dl>
                            </div>
						</li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nex_index_common_box_top ul li").each(function(s){
						jQuery(this).click(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_index_dlrk ul li").eq(s).show().siblings().hide();
							})
						})
				</script>
            </div>
            <!--teach articles-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>教程阅读</span>
                    <a href="#">更多</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_tart">
                	<ul>
						<!--教程阅读-->
                        
                    	
                    </ul>
                </div>
            </div>
            <!--ads-->
            <div class="nex_index_common_box">
            	<div class="nex_index_ads">
					<!--门户广告位-->
                    
                	
                </div>
            </div>
            <!--members-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>会员排行</span>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_members">
                	<ul>
						<!--门户会员排行-->
                        
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
           
            <!--friend links-->
            <div class="nex_index_common_box">
                <div class="nex_index_common_box_top">
                    <span>友情链接</span>
                    <a href="#">更多</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_flinks">
                	<ul>
						<!--门户友情链接-->
                        
                    	

                        
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
	</div>	
    
	<!--{template common/footer}-->
    
</div>


<div class="pullrefresh" style="display:none;"></div>

