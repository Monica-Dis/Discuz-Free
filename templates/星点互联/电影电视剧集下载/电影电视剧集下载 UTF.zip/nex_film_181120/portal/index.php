<?php echo 'Copyright@DISM.TAOBAO.COM -版权所有';exit;?>
<!--{template common/header}-->
<div class="wp">
	<!--头部幻灯-->
    <div class="nex_fullSlide">
		<div class="bd">
			<!--[diy=nex_fullSlide]--><div id="nex_fullSlide" class="area"></div><!--[/diy]-->
			
		</div>
		<a class="prev" href="javascript:void(0)"></a>
        <a class="next" href="javascript:void(0)"></a>
		<div class="hd"><ul></ul></div>
	</div>

	<script type="text/javascript">
		jQuery(".nex_fullSlide").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:true, autoPage:true, trigger:"click" });
	</script>
    <!--main-->
    <div class="nex_main_bd">
    	<div class="w1180">
        	<!--电影专题-->
            <div class="nex_mov_intel_txt">
                <h5 class="nex_txt_icon0">影视专题<span>精选影视专题</span></h5>
                <div class="nex_mov_intel_roll">
                    <ul>
                        <li><a href="http://t.cn/Aiux1Qh0" target="_blank">奥斯卡金像奖作品</a></li>
                        <li class="nex_speline"></li>
                        <li><a href="http://t.cn/Aiux1Qh0" target="_blank">灾难大片专区</a></li>
                        <li class="nex_speline"></li>
                        <li><a href="http://t.cn/Aiux1Qh0" target="_blank">最强科幻电影</a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_movie_type_class">
            	<ul>
					<!--[diy=nex_movie_type_class]--><div id="nex_movie_type_class" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <!--热播电影-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon1">热播电影<span>最热最火的电影大片</span></h5>
                    <div class="nex_mov_intel_roll">
                    	<ul>
                        	<li><a href="http://t.cn/Aiux1Qh0" target="_blank">品质齐聚文艺院线</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">必看灾难大片强势来袭</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">最强电影独播专区</a></li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_movies">
                	<dl>
						<!--[diy=nex_hot_movies]--><div id="nex_hot_movies" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <!--最近更新-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon2">最新大片<span>最新影线大片</span></h5>
                    <div class="nex_mov_intel_roll">
                    	<ul>
                        	<li><a href="http://t.cn/Aiux1Qh0" target="_blank">国产喜剧</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">文艺小清新</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">好莱坞动作大片</a></li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_movies">
                	<dl>
                    	<!--[diy=nex_update_movies]--><div id="nex_update_movies" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <!--每日推荐-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon3">每日推荐<span>每天更多人看的优质片源</span></h5>
                    
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_movies">
                	<dl>
                    	<!--[diy=nex_today_movies]--><div id="nex_today_movies" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <!--ads-->
            <div class="nex_mov_ads"><!--[diy=nex_mov_ads1]--><div id="nex_mov_ads1" class="area"></div><!--[/diy]--></div>
            <!--电视剧-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon4">电视剧场<span>美剧、韩剧、国产剧应有尽有</span></h5>
                    <div class="nex_mov_intel_roll nex_mov_intel_rollx">
                    	<em>分类切换</em>
                    	<ul>
                        	<li class="cur"><a href="http://t.cn/Aiux1Qh0" target="_blank">热播美剧<i></i></a></li>
                            <b class="nex_speline"></b>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">国产好剧<i></i></a></li>
                            <b class="nex_speline"></b>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">日韩热剧<i></i></a></li>
                            <b class="nex_speline"></b>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">港台经典<i></i></a></li>
                            <div class="clear"></div>
                        </ul>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_drama_bd">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_hot_movies">
                                <dl>
									<!--[diy=nex_drama_1]--><div id="nex_drama_1" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
							<div class="nex_hot_movies">
                                <dl>
									<!--[diy=nex_drama_2]--><div id="nex_drama_2" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </dl>
                            </div>
						</li>
                        <li>
							<div class="nex_hot_movies">
                                <dl>
									<!--[diy=nex_drama_3]--><div id="nex_drama_3" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </dl>
                            </div>
						</li>
                        <li>
							<div class="nex_hot_movies">
                                <dl>
									<!--[diy=nex_drama_4]--><div id="nex_drama_4" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </dl>
                            </div>
						</li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nex_mov_intel_rollx ul li").each(function(s){
						jQuery(this).hover(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_drama_bd ul li").eq(s).show().siblings().hide();
							})
						})
				</script>
            </div>
            <!--ads-->
            <div class="nex_mov_ads"><!--[diy=nex_mov_ads2]--><div id="nex_mov_ads2" class="area"></div><!--[/diy]--></div>
            <!--综艺娱乐-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon5">综艺娱乐<span>每天更多人看的优质片源</span></h5>
                    <div class="nex_mov_intel_roll">
                    	<ul>
                        	<li><a href="http://t.cn/Aiux1Qh0" target="_blank">地表最强真人秀</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">强档推荐</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">情感类节目</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">开口跪福利社</a></li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_vsbox">
                	<dl>
						<!--[diy=nex_hot_vsbox]--><div id="nex_hot_vsbox" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <div class="nex_vsboxed">
            	<div class="nex_vsboxed_l">
                	<i></i>
                    <p>热门</p>
                    <p>必看</p>
                </div>
                <div class="nex_vsboxed_r">
                	<ul>
						<!--[diy=nex_vsboxed_r]--><div id="nex_vsboxed_r" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            
            <!--动漫剧场-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon6">动漫剧场<span>最热最火动漫剧场</span></h5>
                    <div class="nex_mov_intel_roll">
                    	<ul>
                        	<li><a href="http://t.cn/Aiux1Qh0" target="_blank">日漫剧场</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">欧美动画</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">国漫新番</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">其它类型</a></li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_movies">
                    <dl>
						<!--[diy=nex_vsboxed_r2]--><div id="nex_vsboxed_r2" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <!--ads-->
            <div class="nex_mov_ads"><!--[diy=nex_mov_ads3]--><div id="nex_mov_ads3" class="area"></div><!--[/diy]--></div>
            <div class="nex_rankbox">
            	<ul>
                	<li>
                    	<div class="nex_rklist">
                        	<div class="nex_rklist_top"><span>电影下载排行</span><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a><div class="clear"></div></div>
                            <div class="nex_rankinglist">
                            	<dl>
									<!--[diy=nex_rankinglist]--><div id="nex_rankinglist" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_rankinglist dl dd").each(function(s){
									jQuery(this).hover(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										})
									})
							</script>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_rklist">
                        	<div class="nex_rklist_top"><span>电视剧下载排行</span><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a><div class="clear"></div></div>
                            <div class="nex_rankinglist">
                            	<dl>
                                	<!--[diy=nex_rankinglist2]--><div id="nex_rankinglist2" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_rankinglist dl dd").each(function(s){
									jQuery(this).hover(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										})
									})
							</script>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_rklist">
                        	<div class="nex_rklist_top"><span>综艺下载排行</span><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a><div class="clear"></div></div>
                            <div class="nex_rankinglist">
                            	<dl>
                                	<!--[diy=nex_rankinglist3]--><div id="nex_rankinglist3" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_rankinglist dl dd").each(function(s){
									jQuery(this).hover(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										})
									})
							</script>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_rklist">
                        	<div class="nex_rklist_top"><span>动漫下载排行</span><a href="http://t.cn/Aiux1Qh0" target="_blank">更多</a><div class="clear"></div></div>
                            <div class="nex_rankinglist">
                            	<dl>
                                	<!--[diy=nex_rankinglist34]--><div id="nex_rankinglist34" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_rankinglist dl dd").each(function(s){
									jQuery(this).hover(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										})
									})
							</script>
                        </div>
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
            <!--友情链接-->
            <div class="nex_Flinks">
            	<div class="nex_Flink_top">
                	<span>友情链接</span>
                    <a href="#">交换链接，请联络QQ：$_G['setting']['site_qq']</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_Flink_btm">
                	<ul>
						<!--[diy=nex_rankinglist324]--><div id="nex_rankinglist324" class="area"></div><!--[/diy]-->
						<div class="clear"></div>
					</ul>
                </div>
            </div>
            
            
            
            
        </div>
    </div>
    
    
</div>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

