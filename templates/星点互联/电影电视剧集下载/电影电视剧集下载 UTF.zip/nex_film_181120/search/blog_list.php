<?php echo 'Copyright@DISM.TAOBAO.COM (https://dism.taobao.com/)';exit;?>
<div class="tl">
	<div class="sttl mbn nex_search_result">
		<h2><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></h2>
	</div>
	<!--{ad/search/y mtw}-->
	<!--{if empty($bloglist)}-->
		<p class="emp xs2 xg2 nex_emp_notice">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="slst mtw nex_blog_list">
			<ul>
				<!--{loop $bloglist $blog}-->
				<li>
                	<div class="nex_blog_pic">
                    	<!--{eval include 'template/nex_code_180720/php/nex_blog.php'}-->
                        <!--{if $nex_blogpic == ''}-->
                        <a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]" target="_blank" style="background:url($_G['style'][styleimgdir]/search/novocer.jpg) center no-repeat; background-size:cover;"></a>
                        <!--{else}-->
                    	<a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]" target="_blank" style="background:url(data/attachment/album/$nex_blogpic) center no-repeat; background-size:cover;"></a>
                        <!--{/if}-->
                    </div>
                    <div class="nex_blog_info">
                    	<h3><a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"{if $blog[magiccolor]} class="magiccolor$blog[magiccolor]"{/if} target="_blank">$blog[subject]</a></h3>
                        <div class="nex_blog_vt"><span>$blog[viewnum] {lang a_visit}</span><span>$blog[replynum] {lang a_comment}</span><span>$blog[hot] {lang heat}</span></div>
                        <div class="nex_blog_btms">
                        	<a href="home.php?mod=space&uid=$blog[uid]" target="_blank">
                            	<img src="uc_server/avatar.php?uid=$blog[uid]&size=small">
                                <em>$blog[username]</em>
                                <div class="clear"></div>
                            </a>
                            <span>&middot; $blog[dateline]</span>
                            <div class="clear"></div>
                        </div>
                    </div>
                    
				</li>
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>