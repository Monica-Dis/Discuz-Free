<?php echo 'Copyright@DISM.TAOBAO.COM (https://dism.taobao.com/)';exit;?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="template/nex_film_181120/neoconex/dl/reg.css">
<script type="text/javascript">
	var strongpw = new Array();
	<!--{if $_G['setting']['strongpw']}-->
		<!--{loop $_G['setting']['strongpw'] $key $val}-->
		strongpw[$key] = $val;
		<!--{/loop}-->
	<!--{/if}-->
	var pwlength = <!--{if $_G['setting']['pwlength']}-->$_G['setting']['pwlength']<!--{else}-->0<!--{/if}-->;
</script>

<script type="text/javascript" src="{$this->setting[jspath]}register.js?{VERHASH}"></script>

<div id="ct" class="ptm wp cl">
	<div class="nfl" id="main_succeed" style="display: none">
		<div class="f_c altw">
			<div class="alert_right">
				<p id="succeedmessage"></p>
				<p id="succeedlocation" class="alert_btnleft"></p>
				<p class="alert_btnleft"><a id="succeedmessage_href">{lang message_forward}</a></p>
			</div>
		</div>
	</div>
	<div class="mn nex_Mainbod">
        <div class="nex_zctop_inner" id="main_message">
        	<div class="nex_zhuce_bgs"></div>
            <div class="nex_bm_h bbs" id="main_hnav">
                <span class="y" style="display:none;">
                    <!--{hook/register_side_top}-->
                    <!--{if $_GET[action] == 'activation'}-->
                        {lang login_inactive}
                    <!--{else}-->
                        <a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" onclick="showWindow('login', this.href);return false;" class="xi2">{lang login_now}</a>
                    <!--{/if}-->
                </span>
                <h3 id="layer_reginfo_t">
                    <!--{if $_GET[action] != 'activation'}-->$this->setting['reglinkname']<!--{else}-->{lang index_activation}<!--{/if}-->
                </h3>
                <!--{if $this->showregisterform}-->
                <form method="post" autocomplete="off" name="register" id="registerform" enctype="multipart/form-data" onsubmit="checksubmit();return false;" action="member.php?mod=$regname">
                    <div id="layer_reg">
                        <input type="hidden" name="regsubmit" value="yes" />
                        <input type="hidden" name="formhash" value="{FORMHASH}" />
                        <input type="hidden" name="referer" value="$dreferer" />
                        <input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
                        <!--{if $_G['setting']['sendregisterurl']}-->
                            <input type="hidden" name="hash" value="$_GET[hash]" />
                        <!--{/if}-->
                        <div class="mtw">
                            <div id="reginfo_a">
                                <!--{hook/register_top}-->
                                <!--{if $sendurl}-->
                                    <div class="nex_liner_box">
                                        <input type="text" placeholder="{lang email}" id="{$this->setting['reginput']['email']}" name="$this->setting['reginput']['email']" autocomplete="off" size="25" tabindex="1" class="px" required /><br /><em id="emailmore">&nbsp;</em>
                                        <input type="hidden" name="handlekey" value="sendregister"/>
                                        <div class="nex_nesscerry_tips">
                                            <i id="tip_{$this->setting['reginput']['email']}" class="p_tip">{lang register_email_tips}</i>
                                            <kbd id="chk_{$this->setting['reginput']['email']}" class="p_chk"></kbd>
                                        </div>
                                        <div class="nex_nesscerry_tips">
                                        {lang register_validate_email_tips}
                                        </div>
                                        <script type="text/javascript">
                                        function succeedhandle_sendregister(url, msg, values) {
                                        showDialog(msg, 'notice');
                                        }
                                        </script>
                                    </div>
                                <!--{else}-->
                                    <!--{if $invite}-->
                                        <!--{if $invite['uid']}-->
                                        <div class="nex_liner_box">
                                            {lang register_from}:<a href="home.php?mod=space&uid=$invite[uid]" target="_blank">$invite[username]</a>
                                        </div>
                                        <!--{else}-->
                                        <div class="nex_liner_box">
                                            $_GET[invitecode]<input type="hidden" placeholder="{lang invite_code}" id="invitecode" name="invitecode" value="$_GET[invitecode]" />
                                        </div>
                                        <!--{eval $invitecode = 1;}-->
                                        <!--{/if}-->
                                    <!--{/if}-->
            
                                    <!--{if empty($invite) && $this->setting['regstatus'] == 2 && !$invitestatus}-->
                                    <div class="nex_liner_box">
                                        <input type="text" placeholder="*{lang invite_code}" id="invitecode" name="invitecode" autocomplete="off" size="25" onblur="checkinvite()" tabindex="1" class="px" required /><!--{if $this->setting['inviteconfig']['buyinvitecode'] && $this->setting['inviteconfig']['invitecodeprice'] && ($this->setting[ec_tenpay_bargainor] || $this->setting[ec_tenpay_opentrans_chnid] || $this->setting[ec_account])}--><p><a href="misc.php?mod=buyinvitecode" target="_blank" class="xi2">{lang register_buyinvitecode}</a></p><!--{/if}-->
                                        <div class="nex_nesscerry_tips">
                                            <i id="tip_invitecode" class="p_tip"><!--{if $this->setting['inviteconfig']['invitecodeprompt']}-->$this->setting[inviteconfig][invitecodeprompt]<!--{/if}--></i>
                                            <kbd id="chk_invitecode" class="p_chk"></kbd>
                                        </div>
                                    </div>
                                    <!--{eval $invitecode = 1;}-->
                                    <!--{/if}-->
            
                                    <!--{if $_GET[action] != 'activation'}-->
                                        <div class="nex_liner_box">
                                            <input type="text" placeholder="*{lang username}" id="{$this->setting['reginput']['username']}" name="" class="px" tabindex="1" value="{echo dhtmlspecialchars($_GET[defaultusername])}" autocomplete="off" size="25" maxlength="15" required />
                                            <div class="nex_nesscerry_tips">
                                                <i id="tip_{$this->setting['reginput']['username']}" class="p_tip">{lang register_username_tips}</i>
                                                <kbd id="chk_{$this->setting['reginput']['username']}" class="p_chk"></kbd>
                                            </div>
                                        </div>
            
                                        <div class="nex_liner_box">
                                            <input type="password" placeholder="*{lang password}" id="{$this->setting['reginput']['password']}" name="" size="25" tabindex="1" class="px" required />
                                            <div class="nex_nesscerry_tips">
                                                <i id="tip_{$this->setting['reginput']['password']}" class="p_tip">{lang register_password_tips}<!--{if $_G['setting']['pwlength']}-->, {lang register_password_length_tips1} $_G['setting']['pwlength'] {lang register_password_length_tips2}<!--{/if}--></i>
                                                <kbd id="chk_{$this->setting['reginput']['password']}" class="p_chk"></kbd>
                                            </div>
                                        </div>
            
                                        <div class="nex_liner_box">
                                            <input type="password" placeholder="*{lang password_confirm}" id="{$this->setting['reginput']['password2']}" name="" size="25" tabindex="1" value="" class="px" required />
                                            <div class="nex_nesscerry_tips">
                                                <i id="tip_{$this->setting['reginput']['password2']}" class="p_tip">{lang register_repassword_tips}</i>
                                                <kbd id="chk_{$this->setting['reginput']['password2']}" class="p_chk"></kbd>
                                            </div>
                                        </div>
            
                                        <div class="nex_liner_box">
                                            <input type="text" placeholder="<!--{if !$_G['setting']['forgeemail']}-->*<!--{/if}-->{lang email}" id="{$this->setting['reginput']['email']}" name="" autocomplete="off" size="25" tabindex="1" class="px" value="$hash[0]" {if !$_G['setting']['forgeemail']}required{/if} />
                                            <div class="nex_nesscerry_tips">
                                                <i id="tip_{$this->setting['reginput']['email']}" class="p_tip">{lang register_email_tips}</i>
                                                <kbd id="chk_{$this->setting['reginput']['email']}" class="p_chk"></kbd>
                                            </div>
                                            <em id="emailmore">&nbsp;</em>
                                        </div>
                                    <!--{/if}-->
            
                                    <!--{if $_GET[action] == 'activation'}-->
                                    <div id="activation_user" class="nex_liner_box">
                                        <div class="nex_nesscerry_tips">
                                            {lang username}: $username
                                         </div>
                                    </div>
                                    <!--{/if}-->
            
                                    <!--{if $this->setting['regverify'] == 2}-->
                                    <div class="nex_liner_box">
                                        <input id="regmessage" placeholder="*{lang register_message}" name="regmessage" class="px" autocomplete="off" size="25" tabindex="1" required />
                                        <div class="nex_nesscerry_tips">
                                            <i id="tip_regmessage" class="p_tip">{lang register_message1}</i>
                                        </div>
                                    </div>
                                    <!--{/if}-->
            
                                    <!--{if empty($invite) && $this->setting['regstatus'] == 3}-->
                                    <div class="nex_liner_box">
                                        <input type="text" placeholder="{lang invite_code}" name="invitecode" autocomplete="off" size="25" id="invitecode"{if $this->setting['regstatus'] == 2} onblur="checkinvite()"{/if} tabindex="1" class="px" />
                                    </div>
                                    <!--{eval $invitecode = 1;}-->
                                    <!--{/if}-->
            
                                    <!--{loop $_G['cache']['fields_register'] $field}-->
                                        <!--{if $htmls[$field['fieldid']]}-->
                                        <div class="nex_liner_box">
                                            $htmls[$field['fieldid']]
                                            <div class="nex_nesscerry_tips">
                                                <i id="tip_$field['fieldid']" class="p_tip"><!--{if $field['description']}--><!--{echo dhtmlspecialchars($field[description])}--><!--{/if}--></i>
                                                <kbd id="chk_$field['fieldid']" class="p_chk"></kbd>
                                            </div>
                                        </div>
                                        <!--{/if}-->
                                    <!--{/loop}-->
                                <!--{/if}-->
                                <!--{hook/register_input}-->
            
                                <!--{if $secqaacheck || $seccodecheck}-->
                                    <!--{block sectpl}--><div class="nex_liner_box nex_liner_box_valides"><table><tr><th style="display: none;"><span class="rq">*</span><sec>: </th><td><sec><br /><sec></td></tr></table></div><!--{/block}-->
                                    <!--{subtemplate common/seccheck}-->
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                    
                    <div id="layer_reginfo_b">
                        <div class="nex_liner_box mbw bw0">
                            <div id="reginfo_a_btn">
                                <button class="pn pnc" id="registerformsubmit" type="submit" name="regsubmit" value="true" tabindex="1"><strong><!--{if $_GET[action] == 'activation'}-->{lang activation}<!--{else}-->{lang submit}<!--{/if}--></strong></button>
                            </div>
                            
                            <!--{if $this->setting['sitemessage'][register]}--><a href="javascript:;" id="custominfo_register" class="y"><img src="{IMGDIR}/info_small.gif" alt="{lang faq}" /></a><!--{/if}-->
                        </div>
                        <!--{if $bbrules}-->
                        <div id="reginfo_a_Rule">
                            <input type="checkbox" class="pc" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" /> <label for="agreebbrule">{lang agree}<a href="javascript:;" onclick="showBBRule()">{lang rulemessage}</a></label>
                        </div>
                        <!--{/if}-->
                        
                        
                        <!--{if !empty($_G['setting']['pluginhooks']['register_logging_method'])}-->
                            <div class="nex_liner_box bw0 {if empty($_GET['infloat'])} mbw{/if}">
                                <hr class="l" />
                                <table>
                                    <tr>
                                        <th>{lang login_method}:</th>
                                        <td><!--{hook/register_logging_method}--></td>
                                    </tr>
                                </table>
                            </div>
                        <!--{/if}-->
                    </div>
                    
                    <div class="nex_reg_btms">
                        <div class="nex_reg_btms_l">
                            已有账号？请
                            <a href="member.php?mod=logging&action=login">登陆</a>
                        </div>
                        <div class="nex_reg_btms_r">
                            <h5>第三方账号登陆：</h5>
                            <ul>
                                <li class="nex_tl_qq"><a href="connect.php?mod=login&amp;op=init&amp;referer=forum.php&amp;statfrom=login" title="qq登陆"></a></li>
                                <li class="nex_tl_wx"><a href="plugin.php?id=wechat:login" title="微信登陆"></a></li>
                                <li class="nex_tl_wb"><a href="#" title="微博登陆"></a></li>
                                <div class="clear"></div>
                            </ul>
                            <div class="clear"></div>
                        </div>
                        <div class="clear"></div>
                    </div>
                    
                </form>
                <!--{/if}-->
                <!--{hook/register_bottom}-->
            </div>
        	<div class="clear"></div>
            <p id="returnmessage4"></p>
        
            
        </div>
        <div class="clear"></div>
        <div id="layer_regmessage"class="f_c blr nfl" style="display: none">
            <div class="c"><div class="alert_right">
                <div id="messageleft1"></div>
                <p class="alert_btnleft" id="messageright1"></p>
            </div>
        </div>
        
        <div id="layer_bbrule" style="display: none">
            <div class="c" style="width:700px;height:350px;overflow:auto">$bbrulestxt</div>
            <p class="fsb pns cl hm">
                <button class="pn pnc" onclick="$('agreebbrule').checked = true;hideMenu('fwin_dialog', 'dialog');{if $this->setting['sitemessage'][register] && ($bbrules && $bbrulesforce)}showRegprompt();{/if}"><span>{lang agree}</span></button>
                <button class="pn" onclick="location.href='$_G[siteurl]'"><span>{lang disagree}</span></button>
            </p>
        </div>
        
        <script type="text/javascript">
        var ignoreEmail = <!--{if $_G['setting']['forgeemail']}-->true<!--{else}-->false<!--{/if}-->;
        <!--{if $bbrules && $bbrulesforce}-->
            showBBRule();
        <!--{/if}-->
        <!--{if $this->showregisterform}-->
            <!--{if $sendurl}-->
            addMailEvent($('{$this->setting['reginput']['email']}'));
            <!--{else}-->
            addFormEvent('registerform', <!--{if $_GET[action] != 'activation' && !($bbrules && $bbrulesforce) && !empty($invitecode)}-->1<!--{else}-->0<!--{/if}-->);
            <!--{/if}-->
            <!--{if $this->setting['sitemessage'][register]}-->
                function showRegprompt() {
                    showPrompt('custominfo_register', 'mouseover', '<!--{echo trim($this->setting['sitemessage'][register][array_rand($this->setting['sitemessage'][register])])}-->', $this->setting['sitemessage'][time]);
                }
                <!--{if !($bbrules && $bbrulesforce)}-->
                    showRegprompt();
                <!--{/if}-->
            <!--{/if}-->
            function showBBRule() {
                showDialog($('layer_bbrule').innerHTML, 'info', '<!--{echo addslashes($this->setting['bbname']);}--> {lang rulemessage}');
                $('fwin_dialog_close').style.display = 'none';
            }
        <!--{/if}-->
        </script>

	</div>
</div>

<!--{eval updatesession();}-->

<!--{template common/footer}-->