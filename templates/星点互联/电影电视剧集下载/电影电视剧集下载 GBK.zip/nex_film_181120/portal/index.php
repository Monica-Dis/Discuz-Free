<?php echo 'Copyright@DISM.TAOBAO.COM -��Ȩ����';exit;?>
<!--{template common/header}-->
<div class="wp">
	<!--ͷ���õ�-->
    <div class="nex_fullSlide">
		<div class="bd">
			<!--[diy=nex_fullSlide]--><div id="nex_fullSlide" class="area"></div><!--[/diy]-->
			
		</div>
		<a class="prev" href="javascript:void(0)"></a>
        <a class="next" href="javascript:void(0)"></a>
		<div class="hd"><ul></ul></div>
	</div>

	<script type="text/javascript">
		jQuery(".nex_fullSlide").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:true, autoPage:true, trigger:"click" });
	</script>
    <!--main-->
    <div class="nex_main_bd">
    	<div class="w1180">
        	<!--��Ӱר��-->
            <div class="nex_mov_intel_txt">
                <h5 class="nex_txt_icon0">Ӱ��ר��<span>��ѡӰ��ר��</span></h5>
                <div class="nex_mov_intel_roll">
                    <ul>
                        <li><a href="http://t.cn/Aiux1Qh0" target="_blank">��˹��������Ʒ</a></li>
                        <li class="nex_speline"></li>
                        <li><a href="http://t.cn/Aiux1Qh0" target="_blank">���Ѵ�Ƭר��</a></li>
                        <li class="nex_speline"></li>
                        <li><a href="http://t.cn/Aiux1Qh0" target="_blank">��ǿ�ƻõ�Ӱ</a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_movie_type_class">
            	<ul>
					<!--[diy=nex_movie_type_class]--><div id="nex_movie_type_class" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <!--�Ȳ���Ӱ-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon1">�Ȳ���Ӱ<span>�������ĵ�Ӱ��Ƭ</span></h5>
                    <div class="nex_mov_intel_roll">
                    	<ul>
                        	<li><a href="http://t.cn/Aiux1Qh0" target="_blank">Ʒ���������Ժ��</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">�ؿ����Ѵ�Ƭǿ����Ϯ</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">��ǿ��Ӱ����ר��</a></li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_movies">
                	<dl>
						<!--[diy=nex_hot_movies]--><div id="nex_hot_movies" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <!--�������-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon2">���´�Ƭ<span>����Ӱ�ߴ�Ƭ</span></h5>
                    <div class="nex_mov_intel_roll">
                    	<ul>
                        	<li><a href="http://t.cn/Aiux1Qh0" target="_blank">����ϲ��</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">����С����</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">�����붯����Ƭ</a></li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_movies">
                	<dl>
                    	<!--[diy=nex_update_movies]--><div id="nex_update_movies" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <!--ÿ���Ƽ�-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon3">ÿ���Ƽ�<span>ÿ������˿�������ƬԴ</span></h5>
                    
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_movies">
                	<dl>
                    	<!--[diy=nex_today_movies]--><div id="nex_today_movies" class="area"></div><!--[/diy]-->
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <!--ads-->
            <div class="nex_mov_ads"><!--[diy=nex_mov_ads1]--><div id="nex_mov_ads1" class="area"></div><!--[/diy]--></div>
            <!--���Ӿ�-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon4">���Ӿ糡<span>���硢���硢������Ӧ�о���</span></h5>
                    <div class="nex_mov_intel_roll nex_mov_intel_rollx">
                    	<em>�����л�</em>
                    	<ul>
                        	<li class="cur"><a href="http://t.cn/Aiux1Qh0" target="_blank">�Ȳ�����<i></i></a></li>
                            <b class="nex_speline"></b>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">�����þ�<i></i></a></li>
                            <b class="nex_speline"></b>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">�պ��Ⱦ�<i></i></a></li>
                            <b class="nex_speline"></b>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">��̨����<i></i></a></li>
                            <div class="clear"></div>
                        </ul>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_drama_bd">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_hot_movies">
                                <dl>
									<!--[diy=nex_drama_1]--><div id="nex_drama_1" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
							<div class="nex_hot_movies">
                                <dl>
									<!--[diy=nex_drama_2]--><div id="nex_drama_2" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </dl>
                            </div>
						</li>
                        <li>
							<div class="nex_hot_movies">
                                <dl>
									<!--[diy=nex_drama_3]--><div id="nex_drama_3" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </dl>
                            </div>
						</li>
                        <li>
							<div class="nex_hot_movies">
                                <dl>
									<!--[diy=nex_drama_4]--><div id="nex_drama_4" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </dl>
                            </div>
						</li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nex_mov_intel_rollx ul li").each(function(s){
						jQuery(this).hover(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_drama_bd ul li").eq(s).show().siblings().hide();
							})
						})
				</script>
            </div>
            <!--ads-->
            <div class="nex_mov_ads"><!--[diy=nex_mov_ads2]--><div id="nex_mov_ads2" class="area"></div><!--[/diy]--></div>
            <!--��������-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon5">��������<span>ÿ������˿�������ƬԴ</span></h5>
                    <div class="nex_mov_intel_roll">
                    	<ul>
                        	<li><a href="http://t.cn/Aiux1Qh0" target="_blank">�ر���ǿ������</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">ǿ���Ƽ�</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">������Ŀ</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">���ڹ�����</a></li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_vsbox">
                	<dl>
						<!--[diy=nex_hot_vsbox]--><div id="nex_hot_vsbox" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <div class="nex_vsboxed">
            	<div class="nex_vsboxed_l">
                	<i></i>
                    <p>����</p>
                    <p>�ؿ�</p>
                </div>
                <div class="nex_vsboxed_r">
                	<ul>
						<!--[diy=nex_vsboxed_r]--><div id="nex_vsboxed_r" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            
            <!--�����糡-->
            <div class="nex_mov_intel">
            	<div class="nex_mov_intel_txt">
                	<h5 class="nex_txt_icon6">�����糡<span>����������糡</span></h5>
                    <div class="nex_mov_intel_roll">
                    	<ul>
                        	<li><a href="http://t.cn/Aiux1Qh0" target="_blank">�����糡</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">ŷ������</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">�����·�</a></li>
                            <li class="nex_speline"></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank">��������</a></li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_mov_intel_more"><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a></div>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_movies">
                    <dl>
						<!--[diy=nex_vsboxed_r2]--><div id="nex_vsboxed_r2" class="area"></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
            <!--ads-->
            <div class="nex_mov_ads"><!--[diy=nex_mov_ads3]--><div id="nex_mov_ads3" class="area"></div><!--[/diy]--></div>
            <div class="nex_rankbox">
            	<ul>
                	<li>
                    	<div class="nex_rklist">
                        	<div class="nex_rklist_top"><span>��Ӱ��������</span><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a><div class="clear"></div></div>
                            <div class="nex_rankinglist">
                            	<dl>
									<!--[diy=nex_rankinglist]--><div id="nex_rankinglist" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_rankinglist dl dd").each(function(s){
									jQuery(this).hover(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										})
									})
							</script>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_rklist">
                        	<div class="nex_rklist_top"><span>���Ӿ���������</span><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a><div class="clear"></div></div>
                            <div class="nex_rankinglist">
                            	<dl>
                                	<!--[diy=nex_rankinglist2]--><div id="nex_rankinglist2" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_rankinglist dl dd").each(function(s){
									jQuery(this).hover(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										})
									})
							</script>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_rklist">
                        	<div class="nex_rklist_top"><span>������������</span><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a><div class="clear"></div></div>
                            <div class="nex_rankinglist">
                            	<dl>
                                	<!--[diy=nex_rankinglist3]--><div id="nex_rankinglist3" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_rankinglist dl dd").each(function(s){
									jQuery(this).hover(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										})
									})
							</script>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_rklist">
                        	<div class="nex_rklist_top"><span>������������</span><a href="http://t.cn/Aiux1Qh0" target="_blank">����</a><div class="clear"></div></div>
                            <div class="nex_rankinglist">
                            	<dl>
                                	<!--[diy=nex_rankinglist34]--><div id="nex_rankinglist34" class="area"></div><!--[/diy]-->
                                </dl>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_rankinglist dl dd").each(function(s){
									jQuery(this).hover(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										})
									})
							</script>
                        </div>
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
            <!--��������-->
            <div class="nex_Flinks">
            	<div class="nex_Flink_top">
                	<span>��������</span>
                    <a href="#">�������ӣ�������QQ��$_G['setting']['site_qq']</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_Flink_btm">
                	<ul>
						<!--[diy=nex_rankinglist324]--><div id="nex_rankinglist324" class="area"></div><!--[/diy]-->
						<div class="clear"></div>
					</ul>
                </div>
            </div>
            
            
            
            
        </div>
    </div>
    
    
</div>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->


