<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<!--{template common/header}-->

<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <!--index_main-->
    <div class="nex_measure_box">
        <div class="nex_measure_box_inner">
        	<div class="nex_measure_main">
            	<!--����������ǰ̨���뿪ʼ-->
            	{if file_exists('source/plugin/nex_apply_190725/inc.php')}
				<!--{eval require_once("source/plugin/nex_apply_190725/inc.php");}-->
				{$form[0]}
				{/if}
                <!--����������ǰ̨�������-->
            </div>
        </div>
    </div>
    
    <div class="nexfullSlide">
    	<div class="bd">
        	<!--[diy=bd]--><div id="bd" class="area"></div><!--[/diy]-->
            
        </div>
        <div class="hd">
        	<ul>
            	<li></li>
                <li></li>
                <li></li>
                <li></li>
                <li></li>
            </ul>
        </div>
        <a class="prev" href="javascript:void(0)"></a>
        <a class="next" href="javascript:void(0)"></a>
    </div>
    <script type="text/javascript">
		jQuery(".nexfullSlide").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:true, autoPage:true, trigger:"click" });
	</script>
    <!--��˾����-->
    <div class="nex_index_advance_box">
    	<div class="w1240">
        	<div class="nex_advance_list">
            	<ul>
                	<!--[diy=nex_advance_list]--><div id="nex_advance_list" class="area"></div><!--[/diy]-->
                    
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    <!--ʵ������-->
    <div class="nex_index_cases_box">
    	<div class="w1240">
        	<div class="nex_index_common_title">
            	<div class="nex_ict_l">
                	<h5>��ѡ��װʵ������</h5>
                    <p>10���ֳ�����װ��������׾�Ʒ������Ʒ�����������ҵ���װ���</p>
                </div>
                <div class="nex_ict_r">
                	<ul>
                    	<li><a href="#" target="_blank">��Լ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">ŷʽ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��ʽ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">����ʽ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��ʽ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��ŷ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��԰</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">���</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">���к�</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">ȫ������</a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_index_cases">
            	<ul>
                	<!--[diy=nex_index_cases]--><div id="nex_index_cases" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_index_gif_ads"><!--[diy=nex_index_gif_ads]--><div id="nex_index_gif_ads" class="area"></div><!--[/diy]--></div>
        </div>
    </div>
    <!--װ������-->
    <div class="nex_index_advance_box">
    	<div class="w1240">
        	<div class="nex_index_common_title">
            	<div class="nex_ict_l">
                	<h5>װ�޷�������</h5>
                    <p>����7�������㶨װ��</p>
                </div>
                <div class="nex_ict_r">
                	
                </div>
                <div class="clear"></div>
            </div>
        	<div class="nex_decor_process">
                <ul>
                	<!--[diy=nex_decor_process]--><div id="nex_decor_process" class="area"></div><!--[/diy]-->
                    
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    <!--������Ч��ͼ-->
    <div class="nex_index_cases_box">
    	<div class="w1240">
        	<div class="nex_index_common_title">
            	<div class="nex_ict_l">
                	<h5>������Ч��ͼ</h5>
                    <p>����<span>154550</span>��װ�����ͼ��Ϊ���ҵ�װ�����</p>
                </div>
                <div class="nex_ict_r">
                	<ul>
                    	<li><a href="#" target="_blank">��Լ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">ŷʽ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��ʽ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">����ʽ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��ʽ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��ŷ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��԰</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">���</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">���к�</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">����װ��Ч��ͼ</a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_design_sketch">
            	<ul>	
                	<!--[diy=nex_design_sketch]--><div id="nex_design_sketch" class="area"></div><!--[/diy]-->
                	
                </ul>
            </div>
            <div class="nex_sort_types">
            	<ul>
                	<!--[diy=nex_sort_types]--><div id="nex_sort_types" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_index_ads">
            	<ul>
                	<li><!--[diy=nex_index_ads1]--><div id="nex_index_ads1" class="area"></div><!--[/diy]--></li>
                    <li><!--[diy=nex_index_ads2]--><div id="nex_index_ads2" class="area"></div><!--[/diy]--></li>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    <!--��װ���ʦ-->
    <div class="nex_index_cases_box">
    	<div class="w1240">
        	<div class="nex_index_common_title">
            	<div class="nex_ict_l">
                	<h5>רҵ��װ���ʦ</h5>
                    <p>���ڼҵ���� ����Ϊ�� ������������</p>
                </div>
                <div class="nex_ict_r">
                	<ul>
                    	<li><a href="#" target="_blank">������լ���ʦ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��ƽ�����ʦ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">Ծ�����ʦ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">С�������ʦ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��Ԣ�����ʦ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">�������ʦ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">ȫ��</a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_designer_mian">
            	<ul>
                	<!--[diy=nex_designer_mian]--><div id="nex_designer_mian" class="area"></div><!--[/diy]-->
                    <div class="clear"></div>
                </ul>
            </div>
            <!--ԤԼ���ʦ���-->
            <div class="nex_booking_designer_plugin">
            	<div class="nex_booking_inner_box">
					<div class="nex_booking_position">
                	<!--ԤԼ���ʦ���ǰ̨���뿪ʼ-->
					{if file_exists('source/plugin/nex_apply_190725/inc.php')}
					<!--{eval require_once("source/plugin/nex_apply_190725/inc.php");}-->
					{$form[1]}
					
					{/if}
					
					
                	
                    <!--ԤԼ���ʦ���ǰ̨�������-->
					<div class="clear"></div>
					<p><strong>���ǳ�ŵ��</strong>�ϸ����û���˽��ά���û��������Լ�רҵװ��ƽ̨�ڱ�����������ṩ����רҵװ�޷�������װ�޸�ʡǮ��ʡ�ġ�ʡʱ�䣡</p>
					</div>
                </div>
            </div>
        </div>
    </div>
    <!--װ�޹���/�ٿ�/�ʴ�-->
    <div class="nex_index_advance_box">
    	<div class="w1240">
        	<div class="nex_index_common_title">
            	<div class="nex_ict_l">
                	<h5>װ�޹���/ѧ��/�ٿ�/�ʴ�</h5>
                    <p>���������õ�װ�޹��ԡ�ʵ������װ��è�壬�������ר��</p>
                </div>
                <div class="nex_ict_r">
                	<ul>
                    	<li><a href="#" target="_blank">װ������</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">װ�δ���</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��ˮ֪ʶ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��װ���</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">����֪ʶ</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">װ�޽���</a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_four_charts">
            	<div class="nex_tab_tops">
                	<ul>
                    	<li class="cur nex_tab_top_bg1"><a href="#" target="_blank"></a></li>
                        <li class="nex_tab_top_bg2"><a href="#" target="_blank"></a></li>
                        <li class="nex_tab_top_bg3"><a href="#" target="_blank"></a></li>
                        <li class="nex_tab_top_bg4"><a href="#" target="_blank"></a></li>
                        <div class="clear"></div>
                    </ul>
                </div>	
                <div class="nex_tab_btms">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_ackinter">
                            	<em></em>
                                <div class="nex_ack_seps">
                                    <h2>װ������</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps1]--><div id="nex_ack_seps1" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>װ�δ���</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps2]--><div id="nex_ack_seps2" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>ѡ�ľ���</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps3]--><div id="nex_ack_seps3" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>��ˮ֪ʶ</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps4]--><div id="nex_ack_seps4" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_ackinter nex_ackinter1">
                            	<em></em>
                                <div class="nex_ack_seps">
                                    <h2>װ��ǰ</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps5]--><div id="nex_ack_seps5" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>װ����</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps6]--><div id="nex_ack_seps6" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>װ�޺�</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps7]--><div id="nex_ack_seps7" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>���</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps8]--><div id="nex_ack_seps8" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_ackinter nex_ackinter2">
                            	<em></em>
                                <div class="nex_ack_seps">
                                    <h2>��װ�ٿ�</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps9]--><div id="nex_ack_seps9" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>�Ҿ߰ٿ�</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps10]--><div id="nex_ack_seps10" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>�����ٿ�</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps11]--><div id="nex_ack_seps11" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>����ٿ�</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps12]--><div id="nex_ack_seps12" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_ackinter nex_ackinter3">
                            	<em></em>
                                <div class="nex_ack_seps">
                                    <h2>װ������</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps13]--><div id="nex_ack_seps13" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>װ�޽���</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps14]--><div id="nex_ack_seps14" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>��װ���</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps16]--><div id="nex_ack_seps16" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="nex_ack_seps">
                                    <h2>����֪ʶ</h2>
                                    <dl>
                                    	<!--[diy=nex_ack_seps15]--><div id="nex_ack_seps15" class="area"></div><!--[/diy]-->
                                        
                                    </dl>
                                    <div class="nex_ack_more"><a href="#" target="_blank">�鿴����</a></div>
                                </div>
                                <div class="clear"></div>
                            </div>
                        </li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nex_tab_tops ul li").each(function(s){
						jQuery(this).hover(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_tab_btms ul li").eq(s).show().siblings().hide();
							})
						})
				</script>

            </div>
        </div>
    </div>
    <!--װ����Ѷ-->
    <div class="nex_index_cases_box">
        <div class="w1240">
            <div class="nex_index_common_title">
                <div class="nex_ict_l">
                    <h5>װ����Ѷ</h5>
                    <p>������װ���ԣ����������˽��װ�������ڣ��ü�װ������������</p>
                </div>
                <div class="nex_ict_r">
                    <ul>
                        <li><a href="#" target="_blank">��Ѷ����</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">���ʦ���ֲ�</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��Ʒ�ػ�</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">����������</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">�Ҿӿ�Ѷ</a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_intel_box">
            	<div class="nex_intel_box_l">
                	<div class="nex_intel_box_l_bg nex_intel_box_l_bg1">
                    	<h5>��Ѷ����</h5>
                        <p>�����˽⹫˾�¶�̬������Ѷ</p>
                    </div>
                    <div class="nex_detail_boxs">
                    	<ul>
                        	<!--[diy=nex_detail_boxs1]--><div id="nex_detail_boxs1" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                </div>
                <div class="nex_intel_box_m">
                	<div class="nex_intel_box_l_bg nex_intel_box_l_bg2">
                    	<h5>�ͻ�����</h5>
                        <p>����ҵ������ʵ������</p>
                    </div>
                    <div class="nex_detail_boxs">
                    	<ul>
                        	<!--[diy=nex_detail_boxs11]--><div id="nex_detail_boxs11" class="area"></div><!--[/diy]-->
                        </ul>
                    </div>
                </div>
                <div class="nex_intel_box_r">
                	<div class="nex_intel_box_l_bg nex_intel_box_l_bg3">
                    	<h5>�̼��Żݶ�̬</h5>
                        <p>�����̼��Ż��Ź��</p>
                    </div>
                    <div class="nex_detail_boxs">
                    	<ul>
                        	<!--[diy=nex_detail_boxs12]--><div id="nex_detail_boxs12" class="area"></div><!--[/diy]-->
                        </ul>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <!--Ϊʲôѡ������-->
    <div class="nex_index_advance_box nex_index_why_box">
    	<div class="w1240">
        	<div class="nex_index_common_title">
            	<div class="nex_ict_l">
                	<h5>Ϊʲôѡ������</h5>
                    <p>ʵ�����ͻԻͣ������������ǲ���ǰ�еĶ���</p>
                </div>
                <div class="nex_ict_r">
                	<ul>
                    	<li><a href="#" target="_blank">�����������</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">��ѱ���</a></li>
                        <li class="nex_sep_lines"></li>
                        <li><a href="#" target="_blank">ԤԼ���ʦ</a></li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_why_content">
            	<ul>
                	<!--[diy=nex_why_content]--><div id="nex_why_content" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    <!--��������-->
    <div class="nex_index_cases_box">
    	<div class="w1240">
        	<div class="nex_index_common_title">
            	<div class="nex_ict_l">
                	<h5>��������</h5>
                    <p>PR��3������ϵ$_G[setting][site_qq]������������</p>
                </div>
                <div class="nex_ict_r nex_tab_links">
                	<ul>
                    	<li class="ons">��������</li>
                        <li>���ų���</li>
                        <li>�ܱ߳���</li>
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_link_box">
            	<ul>
                	<li style="display:block;">
                    	<div class="nex_link_bds">
                        	<dl>
                            	<!--[diy=nex_link_bds1]--><div id="nex_link_bds1" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_link_bds">
                        	<dl>
                            	<!--[diy=nex_link_bds2]--><div id="nex_link_bds2" class="area"></div><!--[/diy]-->
                    			
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                    <li>
                    	<div class="nex_link_bds">
                        	<dl>
                            	<!--[diy=nex_link_bds3]--><div id="nex_link_bds3" class="area"></div><!--[/diy]-->
                    			
                                <div class="clear"></div>
                            </dl>
                        </div>
                    </li>
                </ul>
            </div>
            <script type="text/javascript">
				jQuery(".nex_tab_links ul li").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("ons").siblings().removeClass("ons");
						jQuery(".nex_link_box ul li").eq(s).show().siblings().hide();
						})
					})
			</script>

        </div>
    </div>
    
    
    <!--���۱����ǰ�˴��뿪ʼ-->
   
	{if file_exists('source/plugin/nex_apply_190725/inc.php')}
	<!--{eval require_once("source/plugin/nex_apply_190725/inc.php");}-->
	<!--���۱����ǰ�˴��뿪ʼ-->
    {$form[3]}
    <!--���۱����ǰ�˴������-->
    {$form[4]}
	{/if}
	
    <script>
		jQuery(function(){
			setInterval(function(){
			jQuery('.nex_form_circle').toggleClass('nex_animated');
			},3000);
		});
	</script>
    <script type="text/javascript">
	jQuery(function(){
		jQuery(".nex_quota_form_title").click(function(){
		jQuery(".nex_quotation_form_btm").slideToggle(300);
		});
	});
	</script>
	<script type="text/javascript">
		jQuery(".nex_quota_form_title").click(function () {
		jQuery('.nex_quota_form_title_arrow').toggleClass('nex_quota_form_title_arrow1');
		});
		jQuery(".nex_qform_close a").click(function () {
			jQuery('.nex_quotation_form').hide();	
		});
		
	</script>
	<script>
	function nex_running_num(min = 1000, max = 10000, mid = 100000){
		var num = Math.floor(max + (mid - max) * Math.random());
		var num1 = Math.floor(max + (mid - max) * Math.random());
		var num2 = Math.floor(max + (mid - max) * Math.random());
		var num3 = Math.floor(min + (max - min) * Math.random());
		var num4 = Math.floor(min + (max - min) * Math.random());
		jQuery('#totleprice').html(num);
		jQuery('#meterial').html(num1);
		jQuery('#man_make').html(num2);
		jQuery('#design').html(num3);
		jQuery('#quality').html(num4);
		}
	function nexRadomNum(time) {
			setInterval(function(){
				nex_running_num();
			}, time);
		}
	nexRadomNum(110);
	</script>
    
    
</div>    
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

