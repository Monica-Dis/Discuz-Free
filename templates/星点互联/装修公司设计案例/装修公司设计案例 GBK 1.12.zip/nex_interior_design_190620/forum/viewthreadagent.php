<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<div class="nex_vt_agent_intel cl">
    <div class="nex_vt_agent_intel_top">
    	<div class="nex_vt_agent_intel_avator">
        	 <a href="home.php?mod=space&uid={$_G[forum_thread][authorid]}&do=thread&view=me&from=space" target="_blank" title="�鿴Ta�����з�Դ"><!--{avatar($_G[forum_thread][authorid],large)}--></a>
        </div>
        <div class="nex_vt_agent_intel_infos">
        	<div class="nex_vt_agent_intel_infos_top">
            	<a href="home.php?mod=space&uid={$_G[forum_thread][authorid]}" target="_blank" c="1">{$_G[forum_thread][author]}</a>
                <em>{$nex_agent_comps}</em>
                <div class="clear"></div>
            </div>
            <div class="nex_vt_agent_intel_infos_btm"><em>�ó���</em>{$nex_agent_special}</div>
        	
        </div>
        <div class="clear"></div>
    </div>
    <div class="nex_vt_agent_intel_btm">
    	<div class="nex_vt_agent_intel_tel">{$nex_agent_tel}</div>
        <div class="nex_vt_agent_intel_onlinetalk"><a href="tencent://Message/?Uin={$nex_agent_qq}&amp;websiteName=#=&amp;Menu=yes
">������</a></div>
        <div class="clear"></div>
    </div>
</div>