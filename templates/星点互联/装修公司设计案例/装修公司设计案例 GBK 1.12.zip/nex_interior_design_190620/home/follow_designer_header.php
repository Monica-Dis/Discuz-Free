<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>

<div class="nex_designer_columns">
    <ul>
        <li>
            <div class="nex_DC_fenshu DC_broadcast">
                <p>{$nex_user_element[extcredits2]}</p>
                <span>��Ǯ</span>
            </div>
        </li>
        <li>
            <div class="nex_DC_fenshu DC_received">
                <p>{$nex_user_element[following]}</p>
                <span>{lang follow_add}</span>
            </div>        			
        </li>
        <li>
            <div class="nex_DC_fenshu DC_followers">
                <p>{$nex_user_element[follower]}</p>
                <span>{lang follow_follower}</span>
            </div>
        </li>
        <li>
            <div class="nex_DC_fenshu DC_scores">
                <p>$space[credits]</p>
                <span>{lang credits}</span>
            </div>
        </li>
        <div class="clear"></div>
    </ul>   
          
</div>