<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<!--{eval include 'template/nex_interior_design_190620/php/nex_articles.php'}-->
<div class="tl">
	<!--{ad/search/y mtw}-->
	<!--{if empty($articlelist)}-->
		<p class="emp xg2 xs2 nex_emp_notice">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="nex_showarticles">
			<ul>
				<!--{loop $articlelist $article}-->
				<!--{if $article[pic]}-->
                <li class="nex_getcoverimg">
                	<div class="nex_show_article_pics">
                        <a href="{echo fetch_article_url($article);}" target="_blank" style="background:url($article[pic]) center no-repeat; background-size:cover;"></a>
                    </div>	
                    <div class="nex_show_article_info">
                    	<h5><a href="{echo fetch_article_url($article);}" target="_blank">$article[title]</a></h5>
                        <div class="nex_art_sums">$article[summary]<a href="{echo fetch_article_url($article);}" target="_blank">[����]</a></div>
                        <div class="nex_art_fds">
                            <span class="nex_art_columns"><a href="portal.php?mod=list&catid={$nex_catid}" target="_blank">{$nex_catids}</a></span>
                            <span class="nex_art_dateline">{$article[dateline]}</span>
                        	<div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </li>
                <!--{else}-->
                <li>
                	<div class="nex_show_article_info">
                    	<h5><a href="{echo fetch_article_url($article);}" target="_blank">$article[title]</a></h5>
                        <div class="nex_art_sums">$article[summary]<a href="{echo fetch_article_url($article);}" target="_blank">[����]</a></div>
                        <div class="nex_art_fds">
                            <span class="nex_art_columns"><a href="portal.php?mod=list&catid={$nex_catid}" target="_blank">{$nex_catids}</a></span>
                            <span class="nex_art_dateline">{$article[dateline]}</span>
                        	<div class="clear"></div>
                        </div>
                    </div>
                </li>
                <!--{/if}-->
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>