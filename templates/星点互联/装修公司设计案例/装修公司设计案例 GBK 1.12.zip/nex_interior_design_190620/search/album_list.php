<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<div class="tl">
	<!--{ad/search/y mtw}-->
	<!--{if empty($albumlist)}-->
		<p class="emp xs2 xg2 nex_emp_notice">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="nex_album_list">
			<ul>
				<!--{loop $albumlist $key $value}-->
					<li>
						<div class="nex_album_cover"><!--{if $value[pic]}--><a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" target="_blank" style="background:url($value[pic]) center no-repeat; background-size:cover;"></a><!--{/if}--></div>
						<h5><a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" target="_blank">$value[albumname]</a></h5>
					</li>
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
		<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
	<!--{/if}-->
</div>
