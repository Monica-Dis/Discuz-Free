<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<div class="tl">
	<!--{ad/search/y mtw}-->
	<!--{if empty($bloglist)}-->
		<p class="emp xs2 xg2 nex_emp_notice">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="slst mtw nex_blog_list">
			<ul>
				<!--{loop $bloglist $blog}-->
                <!--{eval include 'template/nex_interior_design_190620/php/nex_blog.php'}-->
                <!--{if $nex_blogpic == ''}-->
				<li>
                	<div class="nex_blog_info_null">
                        <h3>
                            <a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"{if $blog[magiccolor]} class="magiccolor$blog[magiccolor]"{/if} target="_blank">$blog[subject]</a>
                            <div class="nex_blog_vt"><span>$blog[viewnum] {lang a_visit}</span><span>$blog[replynum] {lang a_comment}</span><span>$blog[hot] {lang heat}</span></div>
                            <div class="clear"></div>
                        </h3>
                        
                        <div class="nex_blog_btms">
                            <a href="home.php?mod=space&uid=$blog[uid]" target="_blank">
                                <img src="uc_server/avatar.php?uid=$blog[uid]&size=small">
                                <em>$blog[username]</em>
                                <div class="clear"></div>
                            </a>
                            <span>&middot; $blog[dateline]</span>
                            <div class="clear"></div>
                        </div>
                    </div>
                    
				</li>
                <!--{else}-->
                <li>
                	<div class="nex_blog_pic"><a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]" target="_blank" style="background:url(data/attachment/album/$nex_blogpic) center no-repeat; background-size:cover;">{$ext}</a></div>
                    <div class="nex_blog_info">
                        <h3>
                            <a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"{if $blog[magiccolor]} class="magiccolor$blog[magiccolor]"{/if} target="_blank">$blog[subject]</a>
                            <div class="nex_blog_vt"><span>$blog[viewnum] {lang a_visit}</span><span>$blog[replynum] {lang a_comment}</span><span>$blog[hot] {lang heat}</span></div>
                            <div class="clear"></div>
                        </h3>
                        
                        <div class="nex_blog_btms">
                            <a href="home.php?mod=space&uid=$blog[uid]" target="_blank">
                                <img src="uc_server/avatar.php?uid=$blog[uid]&size=small">
                                <em>$blog[username]</em>
                                <div class="clear"></div>
                            </a>
                            <span>&middot; $blog[dateline]</span>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </li>
                <!--{/if}-->
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>