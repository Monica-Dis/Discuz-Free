<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<div class="tl">
    <!--{ad/search/y mtw}-->
    <!--{if empty($threadlist)}-->
        <p class="emp xs2 xg2 nex_emp_notice">{lang search_nomatch}</p>
    <!--{else}-->
        <div class="nex_showresults" id="threadlist" {if $modfid} style="position: relative;"{/if}>
            <!--{if $modfid}-->
            <form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$modfid&infloat=yes&nopost=yes">
            <!--{/if}-->
            <ul>
                <!--{loop $threadlist $thread}-->
                <!--{eval include 'template/nex_interior_design_190620/php/nex_multiops.php'}-->
                <!--{if $nex_attachs == '0'}-->
                	<li id="$thread[tid]">
                    	<div class="nex_showinfos_null">
                            <h3>
                            	<span>{$nex_threadID}</span>
                            	<a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">$thread[subject]</a>
                            	<div class="clear"></div>
                            </h3>
                            <div class="nex_contgyu"><!--{echo cutstr($summary_echo,220)}--></div>
                            <div class="nex_show_nullterms">
                            	<div class="nex_show_null_midl">
                                    <a href="home.php?mod=space&uid=$nex_authorid&do=thread&view=me&from=space" target="_blank"><!--{avatar($thread[authorid],big)}--><span>$thread[author]</span><div class="clear"></div></a>
                                    <em>$thread[dateline]</em>
                                    <div class="clear"></div>
                                </div>
                            	<div class="nex_show_null_midr">
                                	$thread[views]�����
                                </div>
                            	<div class="clear"></div>
                            </div>
                            
                        </div>
                    </li>
                <!--{else}-->
                    <li id="$thread[tid]">
                        <!--{eval include 'template/nex_interior_design_190620/php/nex_multiops.php'}-->
                        <!--{if $nex_threadlistspic}-->
                        <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
                        <div class="nex_showpics"><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank"  style=" background:url(data/attachment/forum/$nex_threadsinpivs[attachment]) center no-repeat; background-size:cover;"></a></div>
                        <!--{/loop}-->
                        <!--{/if}-->
                        <div class="nex_showinfos">
                            <div class="nex_show_forum"><span>{$nex_threadID}</span><em>$thread[views]�����</em><div class="clear"></div></div>
                            <h3><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">$thread[subject]</a></h3>
                            <div class="nex_contgyu"><!--{echo cutstr($summary_echo,220)}--></div>
                            <div class="nex_show_interms">
                                <a href="home.php?mod=space&uid=$nex_authorid&do=thread&view=me&from=space" target="_blank"><!--{avatar($thread[authorid],big)}--><span>$thread[author]</span><div class="clear"></div></a>
                                <em>$thread[dateline]</em>
                                <div class="clear"></div>
                            </div>
                            
                        </div>
                        <div class="clear"></div>
                    </li>
                <!--{/if}-->
                <!--{/loop}-->
                <div class="clear"></div>
            </ul>
        <!--{if $modfid}-->
            </form>
            <script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
            <!--{template forum/topicadmin_modlayer}-->
        <!--{/if}-->
        </div>
    <!--{/if}-->
    <!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>