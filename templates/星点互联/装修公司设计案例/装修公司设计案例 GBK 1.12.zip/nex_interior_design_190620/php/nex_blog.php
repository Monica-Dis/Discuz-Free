<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$nex_blogpic = DB::result(DB::query("SELECT pic FROM ".DB::table('home_blogfield')." WHERE blogid = '$blog[blogid]'"));
?>