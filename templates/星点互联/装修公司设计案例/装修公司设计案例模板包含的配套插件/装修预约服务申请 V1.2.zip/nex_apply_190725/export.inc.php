<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
loadcache('plugin');
require_once DISCUZ_ROOT.'./source/plugin/nex_apply_190725/function.php';

if(!($_G['adminid']==1)){
	showmessage('No privileges');
	exit;
}
$type=$_GET['type']?intval($_GET['type']):1;
$where = $where = _getwhere($type);
switch ($type){
	case 2:
	$titlearr=array('id'=>'ID','name'=>lang('plugin/nex_apply_190725', 'f01'),'style'=>lang('plugin/nex_apply_190725', 'f02'),'compoundname'=>lang('plugin/nex_apply_190725', 'f03'),'tel'=>lang('plugin/nex_apply_190725', 'f04'),'designer'=>lang('plugin/nex_apply_190725', 'f05'));
	break;  
	case 1:
	$titlearr=array('id'=>'ID','name'=>lang('plugin/nex_apply_190725', 'f01'),'tel'=>lang('plugin/nex_apply_190725', 'f04'),'compoundname'=>lang('plugin/nex_apply_190725', 'f03'),'area'=>lang('plugin/nex_apply_190725', 'f07'),'measure'=>lang('plugin/nex_apply_190725', 'f08'));
	break;
	case 3:
	$titlearr=array('id'=>'ID','tel'=>lang('plugin/nex_apply_190725', 'f04'),'area'=>lang('plugin/nex_apply_190725', 'f07'),'name'=>lang('plugin/nex_apply_190725', 'f01'));
	break;
	case 4:
	$titlearr=array('id'=>'ID','area'=>lang('plugin/nex_apply_190725', 'f07'),'compoundname'=>lang('plugin/nex_apply_190725', 'f03'),'measure'=>lang('plugin/nex_apply_190725', 'f08'),'room'=>lang('plugin/nex_apply_190725', 'f09'),'tel'=>lang('plugin/nex_apply_190725', 'f04'));
	break;
}
$titlearr['time']=lang('plugin/nex_apply_190725', 'f06');
foreach($titlearr as $k=>$v){
	$tarr[]=gbkutf($v);
}
$query = C::t('#nex_apply_190725#nex_apply_190725_log')->fetch_all_by_where($where);
foreach($query as $val){
	$d = array();
	foreach($titlearr as $tk=>$tv){
		if($tk=='time'){
			$d[]=dgmdate($val['time'], 'Y/m/d H:i:s');
		}else{
			$d[]=gbkutf($val[$tk]);
		}
	}
	$expdata[]=$d;
}
exportExcel($tarr, $expdata, TIMESTAMP, './', true);