<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
loadcache('plugin');
if(!empty($_G['cache']['plugin']['nex_apply_190725'])) {
	require_once DISCUZ_ROOT.'./source/plugin/nex_apply_190725/deco_class.php';
	$t=new deco_class_from();
	$form=$t->form_output();
}