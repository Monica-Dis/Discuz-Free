<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
loadcache('plugin');
require_once DISCUZ_ROOT.'./source/plugin/nex_apply_190725/deco_class.php';
$api=new deco_class_api();
$modarray = array('bookdesigner', 'freedesign', 'freemeasure', 'getbudget');
$_GET['op'] = !in_array($_GET['op'], $modarray) ? 'bookdesigner' : $_GET['op'];
if(checkmobile() && $_GET['op'] && !$_GET['type']){
	$api->_showtmp($_GET['op']);
}else{
	exit($api->adddecoinfo());
}