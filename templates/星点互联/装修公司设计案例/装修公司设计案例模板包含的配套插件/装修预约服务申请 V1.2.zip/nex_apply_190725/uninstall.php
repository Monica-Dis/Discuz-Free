<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$nex_apply_190725_log= DB::table("nex_apply_190725_log");
$sql = <<<EOF
DROP TABLE IF EXISTS `$nex_apply_190725_log`;
EOF;
runquery($sql);
$finish = true;