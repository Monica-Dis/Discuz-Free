<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$nex_apply_190725_log= DB::table("nex_apply_190725_log");
$sql = <<<EOF
CREATE TABLE `$nex_apply_190725_log` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL DEFAULT '0',
  `tel` varchar(15) NOT NULL DEFAULT '',
  `compoundname` varchar(100) NOT NULL DEFAULT '0',
  `area` varchar(50) NOT NULL,
  `measure` float(50,2) NOT NULL,
  `type` int(1) NOT NULL,
  `room` varchar(255) NOT NULL,
  `style` varchar(200) NOT NULL,
  `designer` varchar(100) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = true;
