<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class deco_class_from{
	function __construct() {
		global $_G;
		$this->setvar = $_G['cache']['plugin']['nex_apply_190725'];
		$this->plugin='nex_apply_190725';
	}
	
	public function make_select($cname='',$seid='',$sou='',$selected='',$all=0){
		$strdata=dhtmlspecialchars($this->setvar[$sou]);
		$oparr=$this->cut_str($strdata);
		$opt=$all?'<option value="0" '.$sele.'>'.lang('plugin/nex_apply_190725', 'f16').'</option>':'';
		foreach($oparr as $k=>$v){
			$sele=$selected==$v?'selected':'';
			$opt.='<option value="'.$v.'" '.$sele.'>'.$v.'</option>';
		}
		
		include template($this->plugin.':form');
		
		return $returns;
	}
	
	public function form_output(){
		global $_G;
		$select=$this->make_select('nex_City_Area','nex_City_Area','nex_plugin_quyu');
		$total=$this->countby_offer();
		include template($this->plugin.':form');
		return array($return,$return1,$return2,$return3,$return4);
	}
	
	public function cut_str($str){
		$strs=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$str));
		return $strs;
	}
	
	public function countby_offer(){
		global $_G;
		$designcount = C::t('#nex_apply_190725#nex_apply_190725_log')->count_all('where type=3');
		$offercount = C::t('#nex_apply_190725#nex_apply_190725_log')->count_all('where type=4');
		return array($designcount+$this->setvar['designtotal'],$offercount+$this->setvar['offertotal']);
	}
	

	
}

class deco_class_api{
	function __construct() {
		global $_G;
		$this->setvar = $_G['cache']['plugin']['nex_apply_190725'];
		$this->plugin='nex_apply_190725';
	}
	public function filterget(){
		$postkey=array(
			'type','nex_real_name','nex_ur_mobile','nex_City_Area','nex_ur_residential','nex_measure_area','nex_type_in_style','nex_type_in_des','nex_rooms_id','nex_tings_id','nex_kitchens_id','nex_toilets_id','nex_balconys_id'
		);
		foreach($_GET as $k=>$v){
			if(in_array($k,$postkey)){
				$getarr[$k]=$this->utfgbk(urldecode($v));
			}
		}
		return $getarr;
	}
	
	public function adddecoinfo(){
		$data=$this->filterget();
		
		if($data['type']==1){
			$checkkey=array(
				'nex_real_name'=>lang('plugin/nex_apply_190725', 'f17'),
				'nex_ur_mobile'=>lang('plugin/nex_apply_190725', 'f18'),
				'nex_ur_residential'=>lang('plugin/nex_apply_190725', 'f19'),
				'nex_City_Area'=>lang('plugin/nex_apply_190725', 'f20'),
				'nex_measure_area'=>lang('plugin/nex_apply_190725', 'f22'),
			);
			$this->checkdata($data,$checkkey,'nex_ur_mobile');
			
			$arr=array(
				'name'=>$data['nex_real_name'],
				'tel'=>$data['nex_ur_mobile'],
				'area'=>$data['nex_City_Area'],
				'compoundname'=>$data['nex_ur_residential'],
				'measure'=>$data['nex_measure_area']
			);
		}elseif($data['type']==2){
			$checkkey=array(
				'nex_real_name'=>lang('plugin/nex_apply_190725', 'f17'),
				'nex_ur_mobile'=>lang('plugin/nex_apply_190725', 'f18'),
				'nex_ur_residential'=>lang('plugin/nex_apply_190725', 'f19'),
				'nex_type_in_style'=>lang('plugin/nex_apply_190725', 'f21'),
			);
			$this->checkdata($data,$checkkey,'nex_ur_mobile');
			
			$arr=array(
				'name'=>$data['nex_real_name'],
				'tel'=>$data['nex_ur_mobile'],
				'area'=>$data['nex_City_Area'],
				'compoundname'=>$data['nex_ur_residential'],
				'style'=>$data['nex_type_in_style'],
				'designer'=>$data['nex_type_in_des']
			);
		}elseif($data['type']==3){
			$checkkey=array(
				'nex_real_name'=>lang('plugin/nex_apply_190725', 'f17'),
				'nex_ur_mobile'=>lang('plugin/nex_apply_190725', 'f18'),
				'nex_City_Area'=>lang('plugin/nex_apply_190725', 'f20'),
			);
			$this->checkdata($data,$checkkey,'nex_ur_mobile');
			
			$arr=array(
				'name'=>$data['nex_real_name'],
				'tel'=>$data['nex_ur_mobile'],
				'area'=>$data['nex_City_Area'],
			);
		}elseif($data['type']==4){
			$checkkey=array(
				'nex_ur_mobile'=>lang('plugin/nex_apply_190725', 'f18'),
				'nex_ur_residential'=>lang('plugin/nex_apply_190725', 'f19'),
				'nex_City_Area'=>lang('plugin/nex_apply_190725', 'f20'),
				'nex_measure_area'=>lang('plugin/nex_apply_190725', 'f22'),
			);
			$this->checkdata($data,$checkkey,'nex_ur_mobile');
			$room=$data['nex_rooms_id'].$data['nex_tings_id'].$data['nex_kitchens_id'].$data['nex_toilets_id'].$data['nex_balconys_id'];
			$arr=array(
				'name'=>$data['nex_real_name'],
				'tel'=>$data['nex_ur_mobile'],
				'area'=>$data['nex_City_Area'],
				'compoundname'=>$data['nex_ur_residential'],
				'measure'=>$data['nex_measure_area'],
				'room'=>$room
			);
		}
		$arr['type']=$data['type'];
		$arr['time']=TIMESTAMP;
		
		
		$id=C::t('#nex_apply_190725#nex_apply_190725_log')->insert($arr);
		if($this->setvar['tip'])$this->_postemail($arr);
		if($id){
			return json_encode(array('err' =>''));
		}
	}
	
	public function _showDialog($err,$dlog){
		$return=json_encode(array('err' =>$err,'msg'=>$this->gbkutf($dlog)));
		if($err){
			exit($return);
		}else{
			return $return;
		}
	}
	
	public function _showtmp($op){
		global $_G;
		$this->setvar = $_G['cache']['plugin']['nex_apply_190725'];
		$deco=new deco_class_from();
		$select=$deco->make_select('nex_City_Area','nex_City_Area','nex_plugin_quyu');
		$total=$deco->countby_offer();
		include template('nex_apply_190725:'.$op.'_index');
	}
	
	
	public function _postemail($data){
		global $_G;
		include libfile('function/mail');
		$date = date('Y-m-d H:i:s');
		$typename=($data['type']==1)?lang('plugin/nex_apply_190725', 'l035'):lang('plugin/nex_apply_190725', 'l036');
		$add_subject=lang('plugin/nex_apply_190725', 'l037').$typename.lang('plugin/nex_apply_190725', 'l038');
		$add_message="<br/>".lang('plugin/nex_apply_190725', 'l016').':'.$data['name']."<br/>".lang('plugin/nex_apply_190725', 'l017').':'.$data['tel']."<br/>".lang('plugin/nex_apply_190725', 'l018').':'.$data['area']."<br/>".lang('plugin/nex_apply_190725', 'l019').':'.$data['mansionname']."<br/><br/>".$date.lang('plugin/nex_apply_190725', 'l038').','.lang('plugin/nex_apply_190725', 'l039');
		$setemail=sendmail($this->setvar['email'], $add_subject, $add_message,$this->setvar['formemail']);
		if(!$setemail) {
			runlog('sendmail', $email." sendmail failed.");
		}
	}
	
	public function checkdata($data,$checkkey,$phonekey){
		global $_G;
		if(!$_G['uid'] && !$this->setvar['tourists']){
			$this->_showDialog(1,lang('plugin/nex_apply_190725', 'f23'));
		}
		foreach($checkkey as $tk=>$tv){
			if($data[$tk]==''){
				$this->_showDialog(1,$tv);
			}
			if(!$this->checkMobile($data[$phonekey])){
				$this->_showDialog(1,lang('plugin/nex_apply_190725', 'f24'));
			}
		}
	}
	
	public function checkMobile($phonenumber){ 
		if (preg_match("/^1[345789]{1}\d{9}$/",$phonenumber)) { 
        	return true; 
     	}else{ 
			return false;
		} 
	} 
	
	public function utfgbk($data){
		$data=dhtmlspecialchars($data);
		$data1 = diconv($data,'utf-8','gbk');
		$data0 = diconv($data1,'gbk','utf-8');
		if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
		if(CHARSET=='gbk'){
			return $tmpstr;
		}else{
			return $this->gbkutf($data);
		}
	}
	
	public function gbkutf($data){
		$data1 = diconv($data,'utf-8','gbk');
		$data0 = diconv($data1,'gbk','utf-8');
		if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
		return diconv($tmpstr,'gbk','utf-8');
	}
}