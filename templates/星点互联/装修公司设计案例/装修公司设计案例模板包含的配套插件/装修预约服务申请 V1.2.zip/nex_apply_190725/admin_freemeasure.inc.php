<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
$var = $_G['cache']['plugin']['nex_apply_190725'];
$type=1;
$pmod='admin_freemeasure';
$titlearr=array('ID',lang('plugin/nex_apply_190725', 'f01'),lang('plugin/nex_apply_190725', 'f04'),lang('plugin/nex_apply_190725', 'f03'),lang('plugin/nex_apply_190725', 'f07'),lang('plugin/nex_apply_190725', 'f08'),lang('plugin/nex_apply_190725', 'f06'));
require_once DISCUZ_ROOT.'./source/plugin/nex_apply_190725/admin.inc.php';