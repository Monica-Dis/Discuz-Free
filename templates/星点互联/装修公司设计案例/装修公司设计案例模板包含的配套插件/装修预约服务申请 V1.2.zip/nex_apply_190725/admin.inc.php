<?php
/*
 * CopyRight  : [DisM!(dism.taobao.com) $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


	loadcache('plugin');
	$var = $_G['cache']['plugin']['nex_apply_190725'];
	require_once DISCUZ_ROOT.'./source/plugin/nex_apply_190725/function.php';
	require_once DISCUZ_ROOT.'./source/plugin/nex_apply_190725/deco_class.php';


	$api=new deco_class_from();
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
				C::t('#nex_apply_190725#nex_apply_190725_log')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/nex_apply_190725', 'f10'), 'action=plugins&operation=config&identifier=nex_apply_190725&pmod='.$pmod, 'succeed');
	}
	if (submitcheck("export")) {
		dheader('location: plugin.php?id=nex_apply_190725:export&type='.$type.'&mintime='.$_GET['mintime'].'&maxtime='.$GET['maxtime']);
	}
	echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
	showtableheader(lang('plugin/nex_apply_190725', 'f11'));
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=nex_apply_190725&type='.$type.'&pmod='.$pmod, 'testhd');
	$opt=$api->make_select();
	
	showtablerow('', array('width="60"'),
		array(
			lang('plugin/nex_apply_190725', 'f12'),
			"<input  type=\"text\" name=\"mintime\" value=\"".$_GET['mintime']."\" onclick=\"showcalendar(event, this, false)\" /> - 
			<input  type=\"text\" name=\"maxtime\" value=\"".$_GET['maxtime']."\" onclick=\"showcalendar(event, this, false)\"/>"
		)
    );
	showsubmit('searchsubmit',lang('plugin/nex_apply_190725', 'f13'),'','<input type="submit" class="btn" id="submit_searchsubmit" name="export" style=" margin-right:10px;margin-left:10px;" value="'.lang('plugin/nex_apply_190725', 'f14').'"> '); 
	showformfooter();
	showtablefooter();/*Dism-taobao_com*/
   	$where = _getwhere($type);
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=".$pmod);
	showtableheader(lang('plugin/nex_apply_190725', 'f15'));
    showsubtitle($titlearr);
	
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=nex_apply_190725&pmod='.$pmod;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = C::t('#nex_apply_190725#nex_apply_190725_log')->count_all($where);
	if($allcount){
		$query = C::t('#nex_apply_190725#nex_apply_190725_log')->fetch_all_by_limit($startlimit,$ppp,$where);
		foreach($query as $val){
			$table = array();
			if($type==1){
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />'.$val['id'];
				$table[1] = $val['name'];
				$table[2] = $val['tel'];
				$table[3] = $val['compoundname'];
				$table[4] = $val['area'];
				$table[5] = $val['measure'].' m<sup>2</sup>';
				$table[6] = dgmdate($val['time'], 'Y/m/d H:i:s');
			}elseif($type==2){
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />'.$val['id'];
				$table[1] = $val['name'];
				$table[2] = $val['style'];
				$table[3] = $val['compoundname'];
				$table[4] = $val['tel'];
				$table[5] = $val['designer'];
				$table[6] = dgmdate($val['time'], 'Y/m/d H:i:s');
			}elseif($type==4){
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />'.$val['id'];
				$table[1] = $val['area'];
				$table[2] = $val['compoundname'];
				$table[3] = $val['measure'].' m<sup>2</sup>';
				$table[4] = $val['room'];
				$table[5] = $val['tel'];
				$table[6] = dgmdate($val['time'], 'Y/m/d H:i:s');
			}else{
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />'.$val['id'];
				$table[1] = $val['tel'];
				$table[2] = $val['area'];
				$table[3] = $val['name'];
				$table[4] = dgmdate($val['time'], 'Y/m/d H:i:s');
			}
			showtablerow('',array('class="td32"'), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter();/*Dism-taobao_com*/
    showformfooter();

