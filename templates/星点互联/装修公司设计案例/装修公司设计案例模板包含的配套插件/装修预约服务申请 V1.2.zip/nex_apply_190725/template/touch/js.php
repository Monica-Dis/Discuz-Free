<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<script type="text/javascript">
	var init= jQuery(function(){
		jQuery(".nex_Submit_Btn").on("click", function() {
				var type=jQuery(this).data("type");
				jQuery.post('{$_G[siteurl]}plugin.php?id=nex_apply_190725:api', jQuery("#form"+type).serialize(),function (data){
						if(data.err){
							_showDialog(data.msg);
							return false;
						}else{
							_showDialog('{$this->setvar[success]}');
							setTimeout(function() {window.location.reload();}, 2000);
						}
					}, "json");
				});
	});
	function _showDialog(dlog){
		popup.open(dlog, 'alert');
	}
	init();
</script>