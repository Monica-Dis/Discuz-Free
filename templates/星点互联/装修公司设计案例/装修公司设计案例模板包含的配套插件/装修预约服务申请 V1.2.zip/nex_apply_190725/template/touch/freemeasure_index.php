<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="source/plugin/nex_apply_190725/static/plugin_freemeasure/mobile_freemeasure.css" />
<div class="nex_common_topbar">
	<a class="nex_return_back" href="javascript:history.back()"></a>
    <span>{lang nex_apply_190725:f44}</span>
    <div class="clear"></div>
</div>        
<div class="nex_freemeasure_plugin_body">
	<div class="nex_measure_box">
        <div class="nex_measure_bd">
        	<form action="" id="form1" onsubmit="return false">
  			<input type="hidden" name="type" value="1">
            <div class="nex_measure_tips">
                <h5>{lang nex_apply_190725:f01}</h5>
                <p>{lang nex_apply_190725:f02}</p>
            </div>
            <!--����������ǰ̨���뿪ʼ-->
            <div class="nex_measure_list">
                <input type="text" name="nex_real_name" class="nex_Your_Name" placeholder="{lang nex_apply_190725:f03}">
            </div>
            <div class="nex_measure_list">
                <input type="text" name="nex_ur_mobile" class="nex_Your_Mobile" placeholder="{lang nex_apply_190725:f04}">
            </div>
            <div class="nex_measure_list">
                <input type="text" name="nex_ur_residential" class="nex_Your_Residential" placeholder="{lang nex_apply_190725:f05}">
            </div>
            <div class="nex_measure_list_state">
                <div class="nex_measure_location">
                    {$select}
                </div>
                <div class="nex_measure_area">
                    <input type="text" name="nex_measure_area" class="nex_Builtup_Area" placeholder="{lang nex_apply_190725:f06}">
                    <span>{lang nex_apply_190725:f07}</span>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_measure_submit">
                <input type="submit" class="nex_measure_buttons nex_Submit_Btn"  data-type="1" id="nex_Submit_Btn" value="{lang nex_apply_190725:f08}">
            </div>
            <!--����������ǰ̨�������-->
            <div class="nex_measure_tipb">{lang nex_apply_190725:f09}</div>
            </form>
        </div>
    </div>
    <div class="nex_measure_img">
    	<ul>
        	<li><img src="source/plugin/nex_apply_190725/static/plugin_freemeasure/nex_img1.png" /></li>
            <li><img src="source/plugin/nex_apply_190725/static/plugin_freemeasure/nex_img2.png" /></li>
            <li><img src="source/plugin/nex_apply_190725/static/plugin_freemeasure/nex_img3.png" /></li>
            <li><img src="source/plugin/nex_apply_190725/static/plugin_freemeasure/nex_img4.png" /></li>
        </ul>
    </div>   
        
</div>	
 <!--{eval include(template('nex_apply_190725:js'));}-->
<!--{template common/footer}-->

<div class="pullrefresh" style="display:none;"></div>

