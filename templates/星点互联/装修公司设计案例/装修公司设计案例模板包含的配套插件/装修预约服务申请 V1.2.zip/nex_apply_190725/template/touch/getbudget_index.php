<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="source/plugin/nex_apply_190725/static/plugin_getbudget/mobile_getbudget.css" />
<div class="nex_common_topbar">
	<a class="nex_return_back" href="javascript:history.back()"></a>
    <span>{lang nex_apply_190725:f43}</span>
    <div class="clear"></div>
</div>        
<div class="nex_getbudget_plugin_body">
	<div class="nex_getbudget_adv">
    	<img src="source/plugin/nex_apply_190725/static/plugin_getbudget/nex_adv.jpg" />
    </div>
    
    <!--���۱����ǰ�˴��뿪ʼ-->
    <div class="nex_quotation_form">
        <div class="nex_quotation_form_inner">
            <div class="nex_quotation_form_btm">
            	<div class="nex_new_bottom_formL">
                	<h3>{lang nex_apply_190725:f18}<span>{lang nex_apply_190725:f19}<em>{$total[1]}{lang nex_apply_190725:f20}</em>{lang nex_apply_190725:f21}</span></h3>
                    
                    <form action="" id="form4" onsubmit="return false">
              		<input type="hidden" name="type" value="4">
                    <div class="nex_form_items">                                        
                        <div class="nex_form_items_txt">                                            
                            <em>{lang nex_apply_190725:f22}</em>                                          
                            <span>*</span> 
                            <div class="clear"></div>
                        </div>                                           
                        <div class="nex_form_items_seps">                                                
                        	<div class="nex_form_items_typein_area">
                            	{$select}
                            </div>
                            <div class="nex_form_items_typein_building">
                            	<input type="txt" name="nex_ur_residential" class="nex_housename" placeholder="{lang nex_apply_190725:f23}">
                            </div>
                            <div class="clear"></div>                                    
                        </div> 
                        <div class="clear"></div>                                       
                    </div> 
                    <div class="nex_form_items">                                        
                        <div class="nex_form_items_txt">                                            
                            <em>{lang nex_apply_190725:f24}</em>                                          
                            <span>*</span> 
                            <div class="clear"></div>
                        </div>                                           
                        <div class="nex_form_items_typein">                                                
                            <input type="txt" name="nex_measure_area" class="nex_housearea" placeholder="{lang nex_apply_190725:f25}">
                            <span>m2</span>                                            
                        </div> 
                        <div class="clear"></div>                                       
                    </div>  
                                                          
                    <div class="nex_form_items nex_form_items1">                                        
                        <div class="nex_form_items_txt">                                            
                            <em>{lang nex_apply_190725:f26}</em>                                          
                            <span>*</span> 
                            <div class="clear"></div>
                        </div>                                           
                        <div class="nex_form_items_selectionpart">                                                
                        	<div class="nex_form_items_selection_area">
                            	<select id="nex_room_selector" name="nex_rooms_id" class="nex_Room_Selection">
                                    <option value="1{lang nex_apply_190725:f27}">1{lang nex_apply_190725:f27}</option>
                                    <option value="2{lang nex_apply_190725:f27}">2{lang nex_apply_190725:f27}</option>
                                    <option value="3{lang nex_apply_190725:f27}">3{lang nex_apply_190725:f27}</option>
                                    <option value="4{lang nex_apply_190725:f27}">4{lang nex_apply_190725:f27}</option>
                                    <option value="5{lang nex_apply_190725:f27}">5{lang nex_apply_190725:f27}</option>
                                    <option value="6{lang nex_apply_190725:f27}">6{lang nex_apply_190725:f27}</option>
                                </select>
                            </div>
                            <div class="nex_form_items_selection_area">
                            	<select id="nex_ting_selector" name="nex_tings_id" class="nex_Ting_Selection">
                                    <option value="1{lang nex_apply_190725:f28}">1{lang nex_apply_190725:f28}</option>
                                    <option value="2{lang nex_apply_190725:f28}">2{lang nex_apply_190725:f28}</option>
                                    <option value="3{lang nex_apply_190725:f28}">3{lang nex_apply_190725:f28}</option>
                                    <option value="4{lang nex_apply_190725:f28}">4{lang nex_apply_190725:f28}</option>
                                    <option value="5{lang nex_apply_190725:f28}">5{lang nex_apply_190725:f28}</option>
                                    <option value="6{lang nex_apply_190725:f28}">6{lang nex_apply_190725:f28}</option>
                                </select>
                            </div>
                            <div class="nex_form_items_selection_area nex_form_items_selection_area1">
                            	<select id="nex_kitchen_selector" name="nex_kitchens_id" class="nex_Kitchen_Selection">
                                    <option value="1{lang nex_apply_190725:f29}">1{lang nex_apply_190725:f29}</option>
                                    <option value="2{lang nex_apply_190725:f29}">2{lang nex_apply_190725:f29}</option>
                                    <option value="3{lang nex_apply_190725:f29}">3{lang nex_apply_190725:f29}</option>
                                    <option value="4{lang nex_apply_190725:f29}">4{lang nex_apply_190725:f29}</option>
                                </select>
                            </div>
                            <div class="nex_form_items_selection_area nex_form_items_selection_area1">
                            	<select id="nex_toilet_selector" name="nex_toilets_id" class="nex_Toilet_Selection">
                                    <option value="1{lang nex_apply_190725:f30}">1{lang nex_apply_190725:f30}</option>
                                    <option value="2{lang nex_apply_190725:f30}">2{lang nex_apply_190725:f30}</option>
                                    <option value="3{lang nex_apply_190725:f30}">3{lang nex_apply_190725:f30}</option>
                                    <option value="4{lang nex_apply_190725:f30}">4{lang nex_apply_190725:f30}</option>
                                </select>
                            </div>
                            <div class="nex_form_items_selection_area nex_form_items_selection_area1">
                            	<select id="nex_balcony_selector" name="nex_balconys_id" class="nex_Balcony_Selection">
                                    <option value="1{lang nex_apply_190725:f31}">1{lang nex_apply_190725:f31}</option>
                                    <option value="2{lang nex_apply_190725:f31}">2{lang nex_apply_190725:f31}</option>
                                    <option value="3{lang nex_apply_190725:f31}">3{lang nex_apply_190725:f31}</option>
                                </select>
                            </div>
                            <div class="clear"></div>                                    
                        </div> 
                        <div class="clear"></div>                                       
                    </div>
                    <div class="nex_form_items">                                        
                        <div class="nex_form_items_txt">                                            
                            <em>{lang nex_apply_190725:f34}</em>                                          
                            <span>*</span> 
                            <div class="clear"></div>
                        </div>                                           
                        <div class="nex_form_items_typein">                                                
                            <input type="txt" name="nex_ur_mobile" class="nex_housearea" placeholder="{lang nex_apply_190725:f33}">
                        </div> 
                        <div class="clear"></div>                                       
                    </div> 
                    
                </div>
                <div class="nex_form_circle">   
                	<em></em>                                     
                    <input type="submit" class="nex_apply_buttons nex_Submit_Btn" data-type="4" id="nex_Apply_Btn" value="{lang nex_apply_190725:f32}">                                
                    <div class="nex_circle nex_circle_1"></div>
                    <div class="nex_circle nex_circle_2"></div>
                    <div class="nex_circle nex_circle_3"></div>
                </div>
				</form>
                <div class="nex_new_bottom_formR">
                	<div class="nex_result_title">{lang nex_apply_190725:f35}<span id="totleprice"></span>{lang nex_apply_190725:f36}</div>
                    <ul>                                        
                       <li>{lang nex_apply_190725:f37}<span id="meterial"></span>{lang nex_apply_190725:f36}</li>                                        
                        <li>{lang nex_apply_190725:f38}<span id="man_make"></span>{lang nex_apply_190725:f36}</li>                                        
                        <li>{lang nex_apply_190725:f39}<span id="design"></span>{lang nex_apply_190725:f36}</li>                                       
                        <li>{lang nex_apply_190725:f40}<span id="quality"></span>{lang nex_apply_190725:f36}</li>
                        <div class="clear"></div>                                 
                    </ul>
                    <p>* {lang nex_apply_190725:f41}</p>
					<p>{lang nex_apply_190725:f42}{$this->setvar['tel']}</p>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    	<div class="nex_quotation_form_top_abg"></div>
        
    </div>
    <!--���۱����ǰ�˴������-->
	<script>
	function nex_running_num(min = 1000, max = 10000, mid = 100000){
		var num = Math.floor(max + (mid - max) * Math.random());
		var num1 = Math.floor(max + (mid - max) * Math.random());
		var num2 = Math.floor(max + (mid - max) * Math.random());
		var num3 = Math.floor(min + (max - min) * Math.random());
		var num4 = Math.floor(min + (max - min) * Math.random());
		jQuery('#totleprice').html(num);
		jQuery('#meterial').html(num1);
		jQuery('#man_make').html(num2);
		jQuery('#design').html(num3);
		jQuery('#quality').html(num4);
		}
	function nexRadomNum(time) {
			setInterval(function(){
				nex_running_num();
			}, time);
		}
	nexRadomNum(110);
	</script>
    <div class="nex_getbudget_adv">
    	<img src="source/plugin/nex_apply_190725/static/plugin_getbudget/adv.jpg" />
    </div>
</div>        
        
        
        
        
	
<!--{eval include(template('nex_apply_190725:js'));}-->
<!--{template common/footer}-->

<div class="pullrefresh" style="display:none;"></div>

