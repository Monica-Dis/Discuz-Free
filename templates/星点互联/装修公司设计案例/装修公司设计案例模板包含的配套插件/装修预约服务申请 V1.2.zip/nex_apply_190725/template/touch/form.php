<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<!--{block returns}--><select class="{$cname}" id="{$seid}" name="{$seid}"><!--{$opt}--></select><!--{/block}-->