<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="source/plugin/nex_apply_190725/static/plugin_bookdesigner/mobile_bookdesigner.css" />
<div class="nex_common_topbar">
	<a class="nex_return_back" href="javascript:history.back()"></a>
    <span>{lang nex_apply_190725:f49}</span>
    <div class="clear"></div>
</div>        
<div class="nex_bookdesigner_plugin_body">
	 <div class="nex_bookdesigner_bg">
     	<div class="nex_bd_bg_txt">
        	<h5>{lang nex_apply_190725:f50}</h5>
            <p>{lang nex_apply_190725:f51}</p>
        </div>
        <div class="nex_bd_bg_inner">
        	<ul>
            	<li>
                	<em class="nex_bd_bg_icon1"></em>
                    <h2>5000+</h2>
                    <p>{lang nex_apply_190725:f52}</p>
                </li>
                <li>
                	<em class="nex_bd_bg_icon2"></em>
                    <h2>800W+</h2>
                    <p>{lang nex_apply_190725:f53}</p>
                </li>
                <li>
                	<em class="nex_bd_bg_icon3"></em>
                    <h2>70+</h2>
                    <p>{lang nex_apply_190725:f54}</p>
                </li>
                <div class="clear"></div>
            </ul>
        </div>
     </div>
     <div class="nex_bd_box">
     	<h5>{lang nex_apply_190725:f55}</h5>
        <div class="nex_bd_box_img"><img src="source/plugin/nex_apply_190725/static/plugin_bookdesigner/bd_img1.png" /></div>
        <h5>{lang nex_apply_190725:f56}</h5>
        <div class="nex_bd_box_img"><img src="source/plugin/nex_apply_190725/static/plugin_bookdesigner/bd_img2.png" /></div>
        <h5>{lang nex_apply_190725:f57}</h5>
        <div class="nex_bd_box_img"><img src="source/plugin/nex_apply_190725/static/plugin_bookdesigner/bd_img3.png" /></div>
        <h5>{lang nex_apply_190725:f58}</h5>
        <div class="nex_bd_box_img"><img src="source/plugin/nex_apply_190725/static/plugin_bookdesigner/bd_img4.png" /></div>
        <!--ԤԼ���ʦ���-->
        <div class="nex_booking_designer_plugin">
            <div class="nex_booking_inner_box">
            	<div class="nex_booking_title">
                	<h5>{lang nex_apply_190725:f59}</h5>
                    <p>{lang nex_apply_190725:f60}</p>
                </div>
                <!--ԤԼ���ʦ���ǰ̨���뿪ʼ-->
                <div class="nex_booking_position">
                	<form action="" id="form2" onsubmit="return false">
 					<input type="hidden" name="type" value="2">
                    <div class="nex_booking_term nex_booking_name">
                        <input name="nex_real_name" type="text" class="nex_type_in_name" placeholder="{lang nex_apply_190725:f03}" />
                    </div>
                    <div class="nex_booking_term nex_booking_style">
                        <input name="nex_type_in_style" type="text" class="nex_type_in_style" placeholder="{lang nex_apply_190725:f10}" />
                    </div>
                    <div class="nex_booking_term nex_booking_address">
                        <input name="nex_ur_residential" type="text" class="nex_type_in_add" placeholder="{lang nex_apply_190725:f05}"  />
                    </div>
                    <div class="nex_booking_term nex_booking_tel">
                        <input name="nex_ur_mobile" type="text" class="nex_type_in_tel" placeholder="{lang nex_apply_190725:f04}"  />
                    </div>
                    <div class="nex_booking_term nex_booking_designer">
                        <input name="nex_type_in_des" type="text" class="nex_type_in_des" placeholder="{lang nex_apply_190725:f11}"  />
                    </div>
                    <div class="nex_booking_term nex_booking_submit">
                        <input name="booking_btn" type="submit" class="nex_type_in_btn nex_Submit_Btn" data-type="2" value="{lang nex_apply_190725:f12}">
                    </div>
                    </form>
                    <div class="clear"></div>
                    <p><strong>{lang nex_apply_190725:f61}</strong>{lang nex_apply_190725:f62}</p>
                </div>
                <!--ԤԼ���ʦ���ǰ̨�������-->
            </div>
        </div>
     </div>   
</div>	
 <!--{eval include(template('nex_apply_190725:js'));}-->
<div class="pullrefresh" style="display:none;"></div>

<!--{template common/footer}-->