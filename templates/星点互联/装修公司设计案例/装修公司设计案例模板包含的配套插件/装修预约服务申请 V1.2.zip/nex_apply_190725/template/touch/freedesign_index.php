<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="source/plugin/nex_apply_190725/static/plugin_freedesign/mobile_freedesign.css" />
<div class="nex_common_topbar">
	<a class="nex_return_back" href="javascript:history.back()"></a>
    <span>{lang nex_apply_190725:f47}</span>
    <div class="clear"></div>
</div>        
<div class="nex_freedesign_plugin_body">
	<div class="nex_fd_p_top">
    	<div class="nex_fd_p_top_inner">
        	<span>{lang nex_apply_190725:f45}<em>{$total[0]}</em>{lang nex_apply_190725:f46}</span>
        </div>
    </div>
    <div class="nex_freedesign_steps">
    	<img src="source/plugin/nex_apply_190725/static/plugin_freedesign/step_img.png" />
    </div>
    <div class="nex_QNA_free_service">
        <div class="nex_QNA_free_service_intel">
            <!--���װ����Ʒ���ʼ-->
            <div class="nex_QNA_pulish_home_form">
            	 <form action="" id="form3" onsubmit="return false">
  				 <input type="hidden" name="type" value="3">
            
                <div class="nex_QNA_form_item">
                    <input type="text" name="nex_ur_mobile" class="nex_QNA_cellphone" placeholder="{lang nex_apply_190725:f16}">
                </div>
                <div class="nex_QNA_form_items">
                    <div class="nex_QNA_form_address">
                        {$select}
                    </div>
                    <div class="nex_QNA_form_name">
                        <input type="text" name="nex_real_name" class="nex_QNA_applier" placeholder="{lang nex_apply_190725:f03}">
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_QNA_form_submit">
                    <input type="submit" class="nex_QNA_form_buttons nex_Submit_Btn" data-type="3" id="nex_QNA_form_Btn" value="{lang nex_apply_190725:f48}">
                </div>
                </form>
                <!--���װ����ѯ�������-->
                <h1>*{lang nex_apply_190725:f17}</h1>
                
            </div>
        </div>
    </div>
    <div class="nex_freedesign_adv">
        <div class="nex_fd_adv_pic"><img src="source/plugin/nex_apply_190725/static/plugin_freedesign/nex_aplf.jpg" /></div>
        <div class="nex_fd_adv_pic"><img src="source/plugin/nex_apply_190725/static/plugin_freedesign/design_house.jpg" /></div>
        <div class="nex_fd_adv_pic" style="margin-bottom:70px;"><img src="source/plugin/nex_apply_190725/static/plugin_freedesign/pk_price.jpg" /></div>
        <div class="nex_fd_adv_tt"><img src="source/plugin/nex_apply_190725/static/plugin_freedesign/house_future.png" /></div>
        <div class="nex_fd_dualCollumn">
        	<ul>
            	<li><img src="source/plugin/nex_apply_190725/static/plugin_freedesign/vp2.jpg" /></li>
                <li><img src="source/plugin/nex_apply_190725/static/plugin_freedesign/vp1.jpg" /></li>
                <li><img src="source/plugin/nex_apply_190725/static/plugin_freedesign/vp3.jpg" /></li>
            </ul>
        </div>
    </div>
    <div class="nex_fd_adv_btm"><img src="source/plugin/nex_apply_190725/static/plugin_freedesign/getprice_bottom.jpg" /></div>
    
    
    
    
</div>        
        
        
        
<!--{eval include(template('nex_apply_190725:js'));}-->
	
<!--{template common/footer}-->


<div class="pullrefresh" style="display:none;"></div>

