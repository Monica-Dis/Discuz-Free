<?php echo 'Copyright@Neoconex�ǵ㻥��';exit;?>
<!--{block return}-->
<div class="nex_measure_bd">
    <div class="nex_measure_tips">
        <p>{lang nex_apply_190725:f01}</p>
        <p>{lang nex_apply_190725:f02}</p>
    </div>
    <form action="" id="form1" onsubmit="return false">
    <div class="nex_measure_list">
        <input type="text" name="nex_real_name" class="nex_Your_Name" placeholder="{lang nex_apply_190725:f03}">
    </div>
    <div class="nex_measure_list">
        <input type="text" name="nex_ur_mobile" class="nex_Your_Mobile" placeholder="{lang nex_apply_190725:f04}">
    </div>
    <div class="nex_measure_list">
        <input type="text" name="nex_ur_residential" class="nex_Your_Residential" placeholder="{lang nex_apply_190725:f05}">
    </div>
    
    <div class="nex_measure_list_state">
        <div class="nex_measure_location">
            {$select}
        </div>
        <div class="nex_measure_area">
            <input type="text" name="nex_measure_area" class="nex_Builtup_Area" placeholder="{lang nex_apply_190725:f06}">
            <span>{lang nex_apply_190725:f07}</span>
        </div>
        <div class="clear"></div>
    </div>
    <div class="nex_measure_submit">
        <input type="submit" class="nex_measure_buttons nex_Submit_Btn"  data-type="1" id="nex_Submit_Btn" value="{lang nex_apply_190725:f08}">
    </div>
    <input type="hidden" name="type" value="1">
    </form>
    <div class="nex_measure_tipb">{lang nex_apply_190725:f09}</div>
</div>

<!--{/block}--><!--{block returns}--><select class="{$cname}" id="{$seid}" name="{$seid}"><!--{$opt}--></select><!--{/block}--><!--{block return1}-->
 <form action="" id="form2" onsubmit="return false">
 <input type="hidden" name="type" value="2">
 <div class="nex_booking_term nex_booking_name">
      <input name="nex_real_name" type="text" class="nex_type_in_name" placeholder="{lang nex_apply_190725:f03}" />
  </div>
  <div class="nex_booking_term nex_booking_style">
      <input name="nex_type_in_style" type="text" class="nex_type_in_style" placeholder="{lang nex_apply_190725:f10}" />
  </div>
  <div class="nex_booking_term nex_booking_address">
      <input name="nex_ur_residential" type="text" class="nex_type_in_add" placeholder="{lang nex_apply_190725:f05}"  />
  </div>
  <div class="nex_booking_term nex_booking_tel">
      <input name="nex_ur_mobile" type="text" class="nex_type_in_tel" placeholder="{lang nex_apply_190725:f04}"  />
  </div>
  <div class="nex_booking_term nex_booking_designer">
      <input name="nex_type_in_des" type="text" class="nex_type_in_des" placeholder="{lang nex_apply_190725:f11}"  />
  </div>
  <div class="nex_booking_term nex_booking_submit">
      <input name="booking_btn" type="submit" data-type="2" class="nex_type_in_btn nex_Submit_Btn"  id="nex_Submit_Btn" value="{lang nex_apply_190725:f12}">
  </div>
</form>
<!--{/block}--><!--{block return2}-->
 <form action="" id="form3" onsubmit="return false">
  <input type="hidden" name="type" value="3">
 <div class="nex_QNA_free_service_intel">
                <div class="nex_QNA_free_servicetitle">
                    {lang nex_apply_190725:f13}
                    <span>{lang nex_apply_190725:f14}<em>{$total[0]}</em>{lang nex_apply_190725:f15}</span>
                </div>
                <div class="nex_QNA_pulish_home_form">
                    <div class="nex_QNA_form_item">
                        <input type="text" name="nex_ur_mobile" class="nex_QNA_cellphone" placeholder="{lang nex_apply_190725:f16}">
                    </div>
                    <div class="nex_QNA_form_items">
                        <div class="nex_QNA_form_address">
                         	{$select}
                        </div>
                        <div class="nex_QNA_form_name">
                            <input type="text" name="nex_real_name" class="nex_QNA_applier" placeholder="{lang nex_apply_190725:f03}">
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_QNA_form_submit">
                        <input type="submit" class="nex_QNA_form_buttons nex_Submit_Btn" data-type="3" id="nex_QNA_form_Btn"  value="{lang nex_apply_190725:f08}">
                    </div>
                    <h1>*{lang nex_apply_190725:f17}</h1>
                </div>
            </div>
          </form>
<!--{/block}--><!--{block return3}-->
<div class="nex_quotation_form">
    	<div class="nex_quotation_form_top_bbg"></div>
        <div class="nex_quotation_form_inner">
        	<div class="nex_qform_close"><a href="javascript:;"></a></div>
            <div class="nex_quota_form_title">                                
                <div class="nex_quota_form_title_img"></div>                                
                <div class="nex_quota_form_title_arrow">                                    
                    <div class="arrow_bg"></div>                                    
                    <div class="arrow_img"></div>                                
                </div>   
                <div class="clear"></div>                         
            </div>
             <form action="" id="form4" onsubmit="return false">
              <input type="hidden" name="type" value="4">
            <div class="nex_quotation_form_btm">
            	<div class="nex_new_bottom_formL">
                	<h3>{lang nex_apply_190725:f18}<span>{lang nex_apply_190725:f19}<em>{$total[1]}{lang nex_apply_190725:f20}</em>{lang nex_apply_190725:f21}</span></h3>
                    <div class="nex_form_items">                                        
                        <div class="nex_form_items_txt">                                            
                            <em>{lang nex_apply_190725:f22}</em>                                          
                            <span>*</span> 
                            <div class="clear"></div>
                        </div>                                           
                        <div class="nex_form_items_seps">                                                
                        	<div class="nex_form_items_typein_area">
                            	{$select}
                            </div>
                            <div class="nex_form_items_typein_building">
                            	<input type="txt" name="nex_ur_residential" class="nex_housename" placeholder="{lang nex_apply_190725:f23}">
                            </div>
                            <div class="clear"></div>                                    
                        </div> 
                        <div class="clear"></div>                                       
                    </div> 
                    <div class="nex_form_items">                                        
                        <div class="nex_form_items_txt">                                            
                            <em>{lang nex_apply_190725:f24}</em>                                          
                            <span>*</span> 
                            <div class="clear"></div>
                        </div>                                           
                        <div class="nex_form_items_typein">                                                
                            <input type="txt" name="nex_measure_area" class="nex_housearea" placeholder="{lang nex_apply_190725:f25}">
                            <span>m2</span>                                            
                        </div> 
                        <div class="clear"></div>                                       
                    </div>  
                                                          
                    <div class="nex_form_items nex_form_items1">                                        
                        <div class="nex_form_items_txt">                                            
                            <em>{lang nex_apply_190725:f26}</em>                                          
                            <span>*</span> 
                            <div class="clear"></div>
                        </div>                                           
                        <div class="nex_form_items_selectionpart">                                                
                        	<div class="nex_form_items_selection_area">
                            	<select id="nex_room_selector" name="nex_rooms_id" class="nex_Room_Selection">
                                    <option value="1{lang nex_apply_190725:f27}">1{lang nex_apply_190725:f27}</option>
                                    <option value="2{lang nex_apply_190725:f27}">2{lang nex_apply_190725:f27}</option>
                                    <option value="3{lang nex_apply_190725:f27}">3{lang nex_apply_190725:f27}</option>
                                    <option value="4{lang nex_apply_190725:f27}">4{lang nex_apply_190725:f27}</option>
                                    <option value="5{lang nex_apply_190725:f27}">5{lang nex_apply_190725:f27}</option>
                                    <option value="6{lang nex_apply_190725:f27}">6{lang nex_apply_190725:f27}</option>
                                </select>
                            </div>
                            <div class="nex_form_items_selection_area">
                            	<select id="nex_ting_selector" name="nex_tings_id" class="nex_Ting_Selection">
                                    <option value="1{lang nex_apply_190725:f28}">1{lang nex_apply_190725:f28}</option>
                                    <option value="2{lang nex_apply_190725:f28}">2{lang nex_apply_190725:f28}</option>
                                    <option value="3{lang nex_apply_190725:f28}">3{lang nex_apply_190725:f28}</option>
                                    <option value="4{lang nex_apply_190725:f28}">4{lang nex_apply_190725:f28}</option>
                                    <option value="5{lang nex_apply_190725:f28}">5{lang nex_apply_190725:f28}</option>
                                    <option value="6{lang nex_apply_190725:f28}">6{lang nex_apply_190725:f28}</option>
                                </select>
                            </div>
                            <div class="nex_form_items_selection_area nex_form_items_selection_area1">
                            	<select id="nex_kitchen_selector" name="nex_kitchens_id" class="nex_Kitchen_Selection">
                                    <option value="1{lang nex_apply_190725:f29}">1{lang nex_apply_190725:f29}</option>
                                    <option value="2{lang nex_apply_190725:f29}">2{lang nex_apply_190725:f29}</option>
                                    <option value="3{lang nex_apply_190725:f29}">3{lang nex_apply_190725:f29}</option>
                                    <option value="4{lang nex_apply_190725:f29}">4{lang nex_apply_190725:f29}</option>
                                </select>
                            </div>
                            <div class="nex_form_items_selection_area nex_form_items_selection_area1">
                            	<select id="nex_toilet_selector" name="nex_toilets_id" class="nex_Toilet_Selection">
                                    <option value="1{lang nex_apply_190725:f30}">1{lang nex_apply_190725:f30}</option>
                                    <option value="2{lang nex_apply_190725:f30}">2{lang nex_apply_190725:f30}</option>
                                    <option value="3{lang nex_apply_190725:f30}">3{lang nex_apply_190725:f30}</option>
                                    <option value="4{lang nex_apply_190725:f30}">4{lang nex_apply_190725:f30}</option>
                                </select>
                            </div>
                            <div class="nex_form_items_selection_area nex_form_items_selection_area1">
                            	<select id="nex_balcony_selector" name="nex_balconys_id" class="nex_Balcony_Selection">
                                    <option value="1{lang nex_apply_190725:f31}">1{lang nex_apply_190725:f31}</option>
                                    <option value="2{lang nex_apply_190725:f31}">2{lang nex_apply_190725:f31}</option>
                                    <option value="3{lang nex_apply_190725:f31}">3{lang nex_apply_190725:f31}</option>
                                </select>
                            </div>
                            <div class="clear"></div>                                    
                        </div> 
                        <div class="clear"></div>                                       
                    </div>
                    <div class="nex_form_items">                                        
                        <div class="nex_form_items_txt">                                            
                            <em>{lang nex_apply_190725:f34}</em>                                          
                            <span>*</span> 
                            <div class="clear"></div>
                        </div>                                           
                        <div class="nex_form_items_typein">                                                
                            <input type="txt" name="nex_ur_mobile" class="nex_housearea" placeholder="{lang nex_apply_190725:f33}">
                        </div> 
                        <div class="clear"></div>                                       
                    </div> 
                    
                </div>
                <div class="nex_form_circle">   
                	<em></em>                                     
                    <input type="submit" class="nex_apply_buttons nex_Submit_Btn" data-type="4" id="nex_QNA_form_Btn" value="{lang nex_apply_190725:f32}">                                
                    <div class="nex_circle nex_circle_1"></div>
                    <div class="nex_circle nex_circle_2"></div>
                    <div class="nex_circle nex_circle_3"></div>
                </div>
				</form>
                <div class="nex_new_bottom_formR">
                	<div class="nex_result_title">{lang nex_apply_190725:f35}<span id="totleprice"></span>{lang nex_apply_190725:f36}</div>
                    <ul>                                        
                        <li>{lang nex_apply_190725:f37}<span id="meterial"></span>{lang nex_apply_190725:f36}</li>                                        
                        <li>{lang nex_apply_190725:f38}<span id="man_make"></span>{lang nex_apply_190725:f36}</li>                                        
                        <li>{lang nex_apply_190725:f39}<span id="design"></span>{lang nex_apply_190725:f36}</li>                                       
                        <li>{lang nex_apply_190725:f40}<span id="quality"></span>{lang nex_apply_190725:f36}</li>                                   
                    </ul>
                    <p>* {lang nex_apply_190725:f41}</p>
					<p>{lang nex_apply_190725:f42}{$this->setvar['tel']}</p>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    	<div class="nex_quotation_form_top_abg"></div>
        
    </div>
<!--{/block}--><!--{block return4}-->
<script>
	var init= jQuery(function(){
		jQuery(".nex_Submit_Btn").on("click", function() {
				var type=jQuery(this).data("type");
				jQuery.post('{$_G[siteurl]}plugin.php?id=nex_apply_190725:api', jQuery("#form"+type).serialize(),function (data){
						if(data.err){
							_showDialog(data.msg);
							return false;
						}else{
							showDialog('{$this->setvar[success]}', 'right', '', '',true,'','','','','',2);
							setTimeout(function() {window.location.reload();}, 2000);
						}
					}, "json");
				});
	});
	function _showDialog(dlog){
		showDialog(dlog, 'alert', '', '',true);
	}
	init();
</script>

<!--{/block}-->