<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


global $_G;
$cacheval = $_G['cache']['plugin']['nex_callgroupid'];
$getID=intval($cacheval['groupid']);
