<?php


define('UC_CONNECT', 'mysql');

define('UC_DBHOST', 'localhost');
define('UC_DBUSER', 'nex_sucai');
define('UC_DBPW', 'nex_sucai');
define('UC_DBNAME', 'nex_sucai');
define('UC_DBCHARSET', 'utf8');
define('UC_DBTABLEPRE', '`nex_sucai`.pre_ucenter_');
define('UC_DBCONNECT', 0);

define('UC_CHARSET', 'utf-8');
define('UC_KEY', 'UcS0T405PbK2m639efa4T4e9Z8a28518h6I326lbm6l8odOcU8C5N8p3we7e8aJ4');
define('UC_API', 'http://127.0.0.1/nex_sucai_190828/uc_server');
define('UC_APPID', '1');
define('UC_IP', '');
define('UC_PPP', 20);
?>