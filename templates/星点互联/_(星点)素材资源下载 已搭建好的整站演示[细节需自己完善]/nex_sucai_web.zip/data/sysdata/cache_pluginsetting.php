<?php
//Discuz! cache file, DO NOT modify me!
//Identify: c7ecfc74634e0c5938843d4b820bfaff

$pluginsetting = array (
);
?>