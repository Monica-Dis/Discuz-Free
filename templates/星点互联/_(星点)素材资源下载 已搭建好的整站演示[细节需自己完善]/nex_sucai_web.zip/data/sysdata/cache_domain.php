<?php
//Discuz! cache file, DO NOT modify me!
//Identify: 2739c57076e2f6072a8f23d13e08fa00

$domain = array (
  'defaultindex' => 'forum.php',
  'holddomain' => 'www|*blog*|*space*|*bbs*',
  'list' => 
  array (
  ),
  'app' => 
  array (
    'portal' => '',
    'forum' => '',
    'group' => '',
    'home' => '',
    'default' => '',
  ),
  'root' => 
  array (
    'home' => '',
    'group' => '',
    'forum' => '',
    'topic' => '',
    'channel' => '',
  ),
);
?>