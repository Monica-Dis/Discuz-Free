<?php
//Discuz! cache file, DO NOT modify me!
//Identify: e15d815807bb648da9904e8d46b8dd8a

$mobilecheck = '{"discuzversion":"X3.4","charset":"utf-8","version":"4","pluginversion":"1.4.8","oemversion":"0","regname":"register","qqconnect":"0","sitename":"Discuz! Board","mysiteid":"","ucenterurl":"http:\\/\\/127.0.0.1\\/nex_sucai_190828\\/uc_server","setting":{"closeforumorderby":null},"extends":{"used":null,"lastupdate":null}}';
?>