<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('list_2');
block_get('101,102,103,104,105,106,107,108,109,110');?><?php include template('common/header'); ?><link rel="stylesheet" type="text/css" href="template/nex_sucai_190828/neoconex/about/main.css">
<div id="pt" class="bm cl">
<div class="z">
<a href="./" class="nvhm" title="首页"><?php echo $_G['setting']['bbname'];?></a> <em>&rsaquo;</em>
<a href="<?php echo $_G['setting']['navs']['1']['filename'];?>"><?php echo $_G['setting']['navs']['1']['navname'];?></a> <em>&rsaquo;</em><?php if(is_array($cat['ups'])) foreach($cat['ups'] as $value) { ?> <a href="<?php echo $portalcategory[$value['catid']]['caturl'];?>"><?php echo $value['catname'];?></a><em>&rsaquo;</em><?php } ?>
<?php echo $cat['catname'];?>
</div>
</div>
<div class="nexabtbd">
<div class="nexabtbd_left">
        <div class="nex_ab_top nex_plugin_grids">
            <ul>
                <li class="cur">VIP介绍</li>
                <li>关于我们</li>
                <li>联系我们</li>
                <li>网站协议</li>
                <li>法律声明</li>
                <li>上传声明</li>
                <li class="nex_lastlistli">版权声明</li>
                <div class="clear"></div>
            </ul>
        </div>
        <script type="text/javascript">
            jQuery(window).scroll(function(){
                var rightH = jQuery('.nexabtbd_left').height();
                var t = jQuery(".nexabtbd_left").offset().top;
                var cH = jQuery(document).height();
                var h=jQuery(this).scrollTop();
                var fH = jQuery('.nexfooter').height();
                var wH = jQuery(window).height();
                var hH = cH-(h+wH);
                if(h>rightH && hH > fH){
                    jQuery(".nex_plugin_grids").addClass('nexfixed');
                }else{
                    jQuery(".nex_plugin_grids").removeClass('nexfixed');
                }
            });
        </script>
    </div>
    <div class="nex_ab_main">
        <div class="nex_ab_bottom">
            <ul>
                <li style="display:block;">
                    <div class="nex_abtitle_wrap">
                        <em>VIP介绍</em>
                        <span>最后更新于 2017-7-6 02:12</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_abvip_box">
                    	<!--[diy=nex_abvip_box]--><div id="nex_abvip_box" class="area"><div id="framekqtUeh" class="frame move-span cl frame-1"><div id="framekqtUeh_left" class="column frame-1-c"><div id="framekqtUeh_left_temp" class="move-span temp"></div><?php block_display('101');?></div></div></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_abvip_box">
                    	<!--[diy=nex_abvip_box1]--><div id="nex_abvip_box1" class="area"><div id="frames6K06o" class="frame move-span cl frame-1"><div id="frames6K06o_left" class="column frame-1-c"><div id="frames6K06o_left_temp" class="move-span temp"></div><?php block_display('102');?></div></div></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_abvip_box">
                    	<!--[diy=nex_abvip_box2]--><div id="nex_abvip_box2" class="area"><div id="frameia4p4X" class="frame move-span cl frame-1"><div id="frameia4p4X_left" class="column frame-1-c"><div id="frameia4p4X_left_temp" class="move-span temp"></div><?php block_display('103');?></div></div></div><!--[/diy]-->
                    	
                    </div>
                </li>
                <li>
                    <div class="nex_abtitle_wrap">
                        <em>关于我们</em>
                        <span>最后更新于 2017-7-6 02:12</span>
                        <div class="clear"></div>
                    </div>
                    <!--[diy=nex_abvip_box3]--><div id="nex_abvip_box3" class="area"><div id="framemHiKkn" class="frame move-span cl frame-1"><div id="framemHiKkn_left" class="column frame-1-c"><div id="framemHiKkn_left_temp" class="move-span temp"></div><?php block_display('104');?></div></div></div><!--[/diy]-->
                    
                </li>
                <li>
                	<div class="nex_abtitle_wrap">
                        <em>联系我们</em>
                        <span>最后更新于 2017-7-6 02:12</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_contactbox">
                    	<div class="nex_contact_map"><!--[diy=nex_contact_map]--><div id="nex_contact_map" class="area"><div id="frameju58Un" class="frame move-span cl frame-1"><div id="frameju58Un_left" class="column frame-1-c"><div id="frameju58Un_left_temp" class="move-span temp"></div><?php block_display('105');?></div></div></div><!--[/diy]--></div>
                        <div class="nex_contact_intel">
                        	<dl>
                            	<!--[diy=nex_contact_intel]--><div id="nex_contact_intel" class="area"><div id="framesWzFn4" class="frame move-span cl frame-1"><div id="framesWzFn4_left" class="column frame-1-c"><div id="framesWzFn4_left_temp" class="move-span temp"></div><?php block_display('106');?></div></div></div><!--[/diy]-->
                            	
                            </dl>
                        </div>
                        <div class="clear"></div>
                    </div>
                </li>
                <li>
                	<div class="nex_abtitle_wrap">
                        <em>网站协议</em>
                        <span>最后更新于 2017-7-6 02:12</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_abvip_box">
                    	<!--[diy=nex_abvip_box5]--><div id="nex_abvip_box5" class="area"><div id="frameQkA5fR" class="frame move-span cl frame-1"><div id="frameQkA5fR_left" class="column frame-1-c"><div id="frameQkA5fR_left_temp" class="move-span temp"></div><?php block_display('107');?></div></div></div><!--[/diy]-->
                    	
                    </div>
                </li>
                <li>
                	<div class="nex_abtitle_wrap">
                        <em>法律声明</em>
                        <span>最后更新于 2017-7-6 02:12</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_abvip_box">
                    	<!--[diy=nex_abvip_box6]--><div id="nex_abvip_box6" class="area"><div id="frameAKkNJ7" class="frame move-span cl frame-1"><div id="frameAKkNJ7_left" class="column frame-1-c"><div id="frameAKkNJ7_left_temp" class="move-span temp"></div><?php block_display('108');?></div></div></div><!--[/diy]-->
                    	
                    </div>
                </li>
                <li>
                	<div class="nex_abtitle_wrap">
                        <em>上传声明</em>
                        <span>最后更新于 2017-7-6 02:12</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_abvip_box">
                    	<!--[diy=nex_abvip_box7]--><div id="nex_abvip_box7" class="area"><div id="frameoKBG6T" class="frame move-span cl frame-1"><div id="frameoKBG6T_left" class="column frame-1-c"><div id="frameoKBG6T_left_temp" class="move-span temp"></div><?php block_display('109');?></div></div></div><!--[/diy]-->
                        
                    </div>
                </li>
                <li>
                	<div class="nex_abtitle_wrap">
                        <em>版权声明</em>
                        <span>最后更新于 2017-7-6 02:12</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_abvip_box">
                    	<!--[diy=nex_abvip_box8]--><div id="nex_abvip_box8" class="area"><div id="framePWE8iw" class="frame move-span cl frame-1"><div id="framePWE8iw_left" class="column frame-1-c"><div id="framePWE8iw_left_temp" class="move-span temp"></div><?php block_display('110');?></div></div></div><!--[/diy]-->
                        
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <div class="clear"></div>
    <script type="text/javascript">
        jQuery(function(){
            jQuery(".nex_ab_top li").each(function(a){
                jQuery(this).click(function(){
                    jQuery(this).addClass("cur").siblings().removeClass("cur");
                    jQuery(".nex_ab_bottom li").eq(a).show().siblings().hide();
                    })
                })
            })
    </script>
</div><?php include template('common/footer'); ?>                                      
                                        