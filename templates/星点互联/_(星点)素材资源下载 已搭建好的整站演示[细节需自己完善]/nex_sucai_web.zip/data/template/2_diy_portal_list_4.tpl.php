<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('list_4');
block_get('142,143,144,145,141');?><?php include template('common/header'); ?><link rel="stylesheet" type="text/css" href="template/nex_sucai_190828/neoconex/vip/main.css">
<div class="nex_vipbox">
<div class="nex_vipbgs"></div>
    <div class="nex_vipbox_inter">
    	<div class="nex_vip_txtop">— 加入VIP后的10项超级特权 —</div>
        <div class="nex_vip_hot_right">
            <div class="nex_vip_hot_right_l">热门特权</div> 
            <div class="nex_vip_server">VIP专属客服1对1支持：6天x12小时</div>
            <div class="clear"></div>
        </div>
    	<div class="nex_youshi_box">
        	<ul>
            	<!--[diy=nex_youshi_box]--><div id="nex_youshi_box" class="area"><div id="frameKb6b04" class="frame move-span cl frame-1"><div id="frameKb6b04_left" class="column frame-1-c"><div id="frameKb6b04_left_temp" class="move-span temp"></div><?php block_display('142');?></div></div></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
        </div>
        <div class="nex_vip_hot_right">
            <div class="nex_vip_hot_right_l">其他特权</div>
            <div class="clear"></div>
        </div>
        <div class="nex_vip_other_right">
        	<ul>
            	<!--[diy=nex_vip_other_right]--><div id="nex_vip_other_right" class="area"><div id="framefl44Zk" class="frame move-span cl frame-1"><div id="framefl44Zk_left" class="column frame-1-c"><div id="framefl44Zk_left_temp" class="move-span temp"></div><?php block_display('143');?></div></div></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
        </div>
        <!--[diy=nex_vip_joinin_btn]--><div id="nex_vip_joinin_btn" class="area"><div id="framezaQpuT" class="frame move-span cl frame-1"><div id="framezaQpuT_left" class="column frame-1-c"><div id="framezaQpuT_left_temp" class="move-span temp"></div><?php block_display('144');?></div></div></div><!--[/diy]-->
        
        <div class="nex_vip_txtop">— VIP特权对比 —</div>
        <div class="nex_vip_form">
            <ul>
            	<!--[diy=nex_vip_form]--><div id="nex_vip_form" class="area"><div id="framePnkrGk" class="frame move-span cl frame-1"><div id="framePnkrGk_left" class="column frame-1-c"><div id="framePnkrGk_left_temp" class="move-span temp"></div><?php block_display('145');?></div></div></div><!--[/diy]-->
                
                <div class="clear"></div>
            </ul>
        </div>
        <!--[diy=nex_vip_qnabox]--><div id="nex_vip_qnabox" class="area"><div id="frameIk20gk" class="frame move-span cl frame-1"><div id="frameIk20gk_left" class="column frame-1-c"><div id="frameIk20gk_left_temp" class="move-span temp"></div><?php block_display('141');?></div></div></div><!--[/diy]-->
        
    </div>
</div><?php include template('common/footer'); ?>                                      
                                        