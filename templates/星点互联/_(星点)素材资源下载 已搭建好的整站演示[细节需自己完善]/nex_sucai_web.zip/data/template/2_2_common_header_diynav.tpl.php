<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?><?php
$diynav = <<<EOF

<a id="diy-tg" href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" title="打开 DIY 面板" >DIY</a>

EOF;
?>