<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('view_3');
0
|| checktplrefresh('data/diy/./template/nex_sucai_190828//portal/view_3.htm', './template/nex_sucai_190828/portal/portal_comment.htm', 1595216039, 'diy', './data/template/2_diy_portal_view_3.tpl.php', 'data/diy/./template/nex_sucai_190828/', 'portal/view_3')
|| checktplrefresh('data/diy/./template/nex_sucai_190828//portal/view_3.htm', './template/default/common/seccheck.htm', 1595216039, 'diy', './data/template/2_diy_portal_view_3.tpl.php', 'data/diy/./template/nex_sucai_190828/', 'portal/view_3')
;
block_get('131,135,132,133,134');?><?php include template('common/header'); ?><script src="<?php echo $_G['setting']['jspath'];?>forum_viewthread.js?<?php echo VERHASH;?>" type="text/javascript"></script>
<script type="text/javascript">zoomstatus = parseInt(<?php echo $_G['setting']['zoomstatus'];?>), imagemaxwidth = '<?php echo $_G['setting']['imagemaxwidth'];?>', aimgcount = new Array();</script>
<link rel="stylesheet" type="text/css" href="template/nex_sucai_190828/neoconex/info/view.css">
<?php if(!empty($_G['setting']['pluginhooks']['view_article_top'])) echo $_G['setting']['pluginhooks']['view_article_top'];?><?php echo adshow("text/wp a_t");?><div class="wp">
<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>

<div class="nex_intel_top">
    <div class="w1240">
        <div id="pt" class="bm cl">
            <a href="./" class="nvhm" title="首页"><?php echo $_G['setting']['bbname'];?></a> <em>&rsaquo;</em>
            <a href="<?php echo $_G['setting']['navs']['1']['filename'];?>"><?php echo $_G['setting']['navs']['1']['navname'];?></a> <em>&rsaquo;</em>
            <?php if(is_array($cat['ups'])) foreach($cat['ups'] as $value) { ?>                <a href="<?php echo getportalcategoryurl($value['catid']); ?>"><?php echo $value['catname'];?></a><em>&rsaquo;</em>
            <?php } ?>
            <a href="<?php echo getportalcategoryurl($cat['catid']); ?>"><?php echo $cat['catname'];?></a> <em>&rsaquo;</em>
            <?php if(($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])) { ?>
            <a href="portal.php?mod=portalcp&amp;ac=article&amp;catid=<?php echo $cat['catid'];?>">发表</a>
            <?php } ?>
        </div>
    </div>
</div>
<div class="nex_ART_content">
<div class="w1240">
    	<div class="nex_ART_ads_top">
        	<!--[diy=nex_ART_ads_top]--><div id="nex_ART_ads_top" class="area"><div id="frameCHHRxh" class="frame move-span cl frame-1"><div id="frameCHHRxh_left" class="column frame-1-c"><div id="frameCHHRxh_left_temp" class="move-span temp"></div><?php block_display('131');?></div></div></div><!--[/diy]-->
        	
        </div>
    	<div class="nex_ART_content_l">
        	<div class="nex_neirong_c">
                <div class="nex_acticletop"><h4><?php echo $article['title'];?> <?php if($article['status'] == 1) { ?>(待审核)<?php } elseif($article['status'] == 2) { ?>(已忽略)<?php } ?></h4></div>
                <div class="nex_nr_infos">
                	<?php if($cat['catname']) { ?>
                	<em><?php echo $cat['catname'];?></em>
                    <?php } ?>
                    <a href="home.php?mod=space&amp;uid=<?php echo $article['uid'];?>&amp;do=thread&amp;view=me&amp;from=space" target="_blank">
                    	<img src="uc_server/avatar.php?uid=<?php echo $article['uid'];?>&amp;size=large">
                        <?php echo $article['username'];?>
                        <div class="clear"></div>
                    </a>
                    <i></i>
                    <span><?php echo $article['dateline'];?></span>
                    <i></i>
                    <span><?php echo $article['viewnum'];?>人浏览</span>
                    <i></i>
                    <span><?php echo $article['commentnum'];?>人回复</span>
                    <div class="clear"></div>
                </div>
                
                <div class="nexmanagerart">
                    <span class="nex_edit"><?php if($article['author']) { ?>原作者: <?php echo $article['author'];?><?php } ?>
                            <?php if($article['from']) { ?>来自: <?php if($article['fromurl']) { ?><a href="<?php echo $article['fromurl'];?>" target="_blank"><?php echo $article['from'];?></a><?php } else { ?><?php echo $article['from'];?><?php } } ?>
                            <?php if($_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']) { ?>
                            <a href="portal.php?mod=portalcp&amp;ac=article&amp;op=edit&amp;aid=<?php echo $article['aid'];?>">编辑</a>
                         </span>
                         <span class="nex_delete">
                            <?php if($article['status']>0 && ($_G['group']['allowmanagearticle'] || $categoryperm[$value['catid']]['allowmanage'])) { ?>
                            <a href="portal.php?mod=portalcp&amp;ac=article&amp;op=verify&amp;aid=<?php echo $article['aid'];?>" id="article_verify_<?php echo $article['aid'];?>" onclick="showWindow(this.id, this.href, 'get', 0);">审核</a>
                                <?php } else { ?>
                                    <a href="portal.php?mod=portalcp&amp;ac=article&amp;op=delete&amp;aid=<?php echo $article['aid'];?>" id="article_delete_<?php echo $article['aid'];?>" onclick="showWindow(this.id, this.href, 'get', 0);">删除</a>
                                <?php } ?>
                            <?php } ?>
                            <?php if(!empty($_G['setting']['pluginhooks']['view_article_subtitle'])) echo $_G['setting']['pluginhooks']['view_article_subtitle'];?>
                         </span>
                         <span class="nex_shoucang"><a href="home.php?mod=spacecp&amp;ac=favorite&amp;type=article&amp;id=<?php echo $article['aid'];?>&amp;handlekey=favoritearticlehk_<?php echo $article['aid'];?>" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);">收藏</a></span>
                        <?php if(helper_access::check_module('share')) { ?>
                        <span class="nex_fenxianga"><a href="home.php?mod=spacecp&amp;ac=share&amp;type=article&amp;id=<?php echo $article['aid'];?>&amp;handlekey=sharearticlehk_<?php echo $article['aid'];?>" id="a_share" onclick="showWindow(this.id, this.href, 'get', 0);">分享</a></span>
                        <?php } ?>
                        <span class="nex_yaoqing"><a href="misc.php?mod=invite&amp;action=article&amp;id=<?php echo $article['aid'];?>" id="a_invite" onclick="showWindow('invite', this.href, 'get', 0);">邀请</a></span>
                        <?php if($_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']) { ?>
                        <span class="nex_adds"><a id="related_article" href="portal.php?mod=portalcp&amp;ac=related&amp;aid=<?php echo $article['aid'];?>&amp;catid=<?php echo $article['catid'];?>&amp;update=1" onclick="showWindow(this.id, this.href, 'get', 0);return false;">添加相关文章</a></span>
                        
                        <?php } ?>
                        <?php if($article['status']==0 && ($_G['group']['allowdiy']  || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 5) || getstatus($_G['member']['allowadmincp'], 6))) { ?>
                        <span class="nex_pushed"><a href="portal.php?mod=portalcp&amp;ac=portalblock&amp;op=recommend&amp;idtype=aid&amp;id=<?php echo $article['aid'];?>" onclick="showWindow('recommend', this.href, 'get', 0)">模块推送</a></span>
                        <?php } ?>
                </div>
                <?php if($article['summary'] && empty($cat['notshowarticlesummay'])) { ?>
                <div class="nex_list_summary">
                	<em>摘要</em>
                    <p><?php echo $article['summary'];?></p>
                </div>
                <?php if(!empty($_G['setting']['pluginhooks']['view_article_summary'])) echo $_G['setting']['pluginhooks']['view_article_summary'];?>
                <?php } ?>
                <div class="bm vw">
                    <div class="d"> 
                        <table cellpadding="0" cellspacing="0" class="vwtb">
                          <tr>
                            <td id="article_content"><?php echo adshow("article/a_af/1");?> 
                              <?php if($content['title']) { ?>
                              
                              <div class="vm_pagetitle xw1"><?php echo $content['title'];?></div>
                              
                              <?php } ?> 
                              <?php echo $content['content'];?> </td>
                          </tr>
                        </table>
                        <?php if(!empty($_G['setting']['pluginhooks']['view_article_content'])) echo $_G['setting']['pluginhooks']['view_article_content'];?> 
                        <?php if($multi) { ?>
                        <div class="ptw pbw cl"><?php echo $multi;?></div>
                        <?php } ?>
                        
                        <div class="nex_ART_inner_btm"> 
                            <?php if(!empty($_G['setting']['pluginhooks']['view_article_op_extra'])) echo $_G['setting']['pluginhooks']['view_article_op_extra'];?> 
                            <script src="<?php echo $_G['setting']['jspath'];?>home.js?<?php echo VERHASH;?>" type="text/javascript"></script>
                            <div id="click_div"> 
                              <?php include template('home/space_click'); ?> 
                            </div>
                            
                            <?php if(!empty($contents)) { ?>
                            <div id="inner_nav" class="ptn xs1">
                                <h3>本文导航</h3>
                                <ul class="xl xl2 cl">
                                    <?php if(is_array($contents)) foreach($contents as $key => $value) { ?> 
                                    <?php $curpage = $key+1;?> 
                                    <?php $inner_view_url = helper_page::mpurl($viewurl, 'page=', $curpage);?>                                    <li>&bull; <a href="<?php echo $inner_view_url;?>"<?php if($key === $start) { ?> class="xi1"<?php } ?>>第 <?php echo $curpage;?> 页 <?php echo $value['title'];?></a></li>
                                    <?php } ?>
                                </ul>
                            </div>
                            <?php } ?> 
                                
                            <!--[diy=diycontentclickbottom]--><div id="diycontentclickbottom" class="area"></div><!--[/diy]--> 
                            <!--分享功能插件-->
                            <div class="bshare-custom nex_ART_share"><div class="bsPromo bsPromo1"></div><a title="分享到QQ空间" class="bshare-qzone"></a><a title="分享到新浪微博" class="bshare-sinaminiblog"></a><a title="分享到微信" class="bshare-weixin"></a><a title="分享到花瓣" class="bshare-huaban"></a><a title="分享到QQ好友" class="bshare-qqim" href="javascript:void(0);"></a><a title="更多平台" class="bshare-more bshare-more-icon more-style-addthis"></a><div class="clear"></div></div><script src="http://static.bshare.cn/b/button.js#style=-1&uuid=&pophcol=3&lang=zh" type="text/javascript"></script><a class="bshareDiv" onclick="javascript:return false;"></a><script src="http://static.bshare.cn/b/bshareC0.js" type="text/javascript"></script>
                            <?php if(!empty($aimgs[$content['pid']])) { ?> 
                            <script type="text/javascript" reload="1">aimgcount[<?php echo $content['pid'];?>] = [<?php echo implode(',', $aimgs[$content['pid']]);; ?>];attachimgshow(<?php echo $content['pid'];?>);</script> 
                            <?php } ?> 
                            <!--上一篇下一篇-->
                            <?php if($article['preaid'] || $article['nextaid']) { ?>
                            <div class="nex_xgydbox">
                                <div class="nex_updownsbox">
                                    <?php if($article['prearticle']) { ?>
                                    <div class="nex_upbox">
                                        <a href="<?php echo $article['prearticle']['url'];?>"><i></i><em>上一篇：</em><?php echo $article['prearticle']['title'];?></a>
                                    </div>
                                    <?php } ?>
                                    <?php if($article['nextarticle']) { ?>
                                    <div class="nex_downbox">
                                        <a href="<?php echo $article['nextarticle']['url'];?>"><i></i><em>下一篇：</em><?php echo $article['nextarticle']['title'];?></a>
                                    </div>
                                    <?php } ?>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <?php } ?>
                            <!--内部广告位-->
                            <div class="nex_content_inerads">
                            	<!--[diy=nex_content_inerads]--><div id="nex_content_inerads" class="area"><div id="framenwxgsS" class="frame move-span cl frame-1"><div id="framenwxgsS_left" class="column frame-1-c"><div id="framenwxgsS_left_temp" class="move-span temp"></div><?php block_display('135');?></div></div></div><!--[/diy]-->
                            	
                            </div>
                            <!--相关文章阅读-->
                            <?php if($article['related']) { ?>
                            <div class="nex_xgydbox_pd">
                                <h3>相关阅读</h3>
                                <div id="related_article" class="bm">
                                    <ul class="nex_Info_threadslists" id="raid_div">
                                      <?php if(is_array($article['related'])) foreach($article['related'] as $raid => $rvalue) { ?>                                      <li>
                                        <div class="nex_toppicfd">
                                            <?php if($rvalue['pic']) { ?>
                                            <a href="<?php echo $rvalue['uri'];?>" target="_blank" style="background:url(data/attachment/<?php echo $rvalue['pic'];?>) center no-repeat; background-size:cover;"></a>
                                            <?php } else { ?><a href="<?php echo $article_url;?>" target="_blank" style="background:url(<?php echo $_G['style']['styleimgdir'];?>/info/nopic.jpg) center no-repeat; background-size:cover;"></a><?php } ?>
                                        </div>
                                        <div class="nex_rpingfdf">
                                            <h5><a href="<?php echo $rvalue['uri'];?>"><?php echo $rvalue['title'];?></a></h5>
                                            
                                        </div>
                                        <div class="clear"></div>
                                      </li>
                                      <?php } ?>
                                      <div class="clear"></div>
                                    </ul>
                                </div>
                            </div>
                            <?php } ?>
                            <?php if(!empty($_G['setting']['pluginhooks']['view_share_method'])) { ?>
                            <div class="tshare cl"> <strong>!viewthread_share_to!:</strong> 
                            <?php if(!empty($_G['setting']['pluginhooks']['view_share_method'])) echo $_G['setting']['pluginhooks']['view_share_method'];?> 
                            </div>
                            <?php } ?> 
                          
                        </div>
                        <?php echo adshow("article/mbm hm/2");?><?php echo adshow("article/mbm hm/3");?> 
                        <?php if($article['allowcomment']==1) { ?> 
                        <?php $data = &$article?> 
                        <div id="comment" class="bm">
<?php if($data['commentnum'] == 0) { ?>
    <div class="nex_article_nocomment">
    	<div class="nex_article_nocomment_top">本文暂无评论，快来抢沙发!</div>
        <div class="nex_arttitleR">
        <?php if($_G['uid']) { ?>
            <?php } else { ?>
            <ul>
                <li class="nex_artcomment_logtxt">您还未登录：</li>
                <li class="nex_artcomment_login"><a href="member.php?mod=logging&amp;action=login" onclick="showWindow('login', this.href)">登录账号</a></li>
                <li class="nex_artcomment_reg"><a href="member.php?mod=<?php echo $_G['setting']['regname'];?>">立即注册</a></li>
                <div class="clear"></div>
            </ul>
        <?php } ?>
        </div>
        <div class="clear"></div>
    </div>
    <?php } else { ?>
    <div class="nex_artcomment"> 
    	<div class="nex_arttitleL">评论</div>
        <div class="nex_arttitleM"><span><?php echo $article['viewnum'];?></span>人参与，<span><?php echo $data['commentnum'];?></span>条评论</div>
        <div class="nex_arttitleR">
        <?php if($_G['uid']) { ?>
        <?php } else { ?>
        <ul>
        	<li class="nex_artcomment_logtxt">您还未登录：</li>
        	<li class="nex_artcomment_login"><a href="member.php?mod=logging&amp;action=login" onclick="showWindow('login', this.href)">登录账号</a></li>
            <li class="nex_artcomment_reg"><a href="member.php?mod=<?php echo $_G['setting']['regname'];?>">立即注册</a></li>
            <div class="clear"></div>
        </ul>
        <?php } ?>
        </div>
        <div class="clear"></div>
    </div>
    <?php } ?>
  
  <div id="comment_ul"> 
    <?php if(!empty($pricount)) { ?>
    <p class="mtn mbn y">提示：本页有 <?php echo $pricount;?> 个评论因未通过审核而被隐藏</p>
    <?php } ?> 
    <?php if(!$data['htmlmade']) { ?>
    <form id="cform" name="cform" action="<?php echo $form_url;?>" method="post" autocomplete="off">
        <div class="tedt" id="tedt">
            <div class="area">
                <textarea name="message" rows="3" class="pt" id="message"  <?php if(!$_G['uid']) { ?> placeholder="立即登录发表您的看法吧"<?php } else { ?> placeholder="现在就发表评论吧"<?php } ?> onkeydown="ctrlEnter(event, 'commentsubmit_btn');"></textarea>
            </div>
        </div>
        <div class="nexpostreplys">
        <?php if($secqaacheck || $seccodecheck) { ?>
            <?php
$sectpl = <<<EOF
<sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div>
EOF;
?>
            <div class="mtm z"><?php $sechash = !isset($sechash) ? 'S'.($_G['inajax'] ? 'A'.random(3) : '').$_G['sid'] : $sechash.random(3);
$sectpl = str_replace("'", "\'", $sectpl);?><?php if($secqaacheck) { ?>
<span id="secqaa_q<?php echo $sechash;?>"></span>		
<script type="text/javascript" reload="1">updatesecqaa('q<?php echo $sechash;?>', '<?php echo $sectpl;?>', '<?php echo $_G['basescript'];?>::<?php echo CURMODULE;?>');</script>
<?php } if($seccodecheck) { ?>
<span id="seccode_c<?php echo $sechash;?>"></span>		
<script type="text/javascript" reload="1">updateseccode('c<?php echo $sechash;?>', '<?php echo $sectpl;?>', '<?php echo $_G['basescript'];?>::<?php echo CURMODULE;?>');</script>
<?php } ?></div>
        <?php } ?>
        <?php if(!empty($topicid) ) { ?>
            <input type="hidden" name="referer" value="<?php echo $topicurl;?>#comment" />
            <input type="hidden" name="topicid" value="<?php echo $topicid;?>">
        <?php } else { ?>
            <input type="hidden" name="portal_referer" value="<?php echo $viewurl;?>#comment">
            <input type="hidden" name="referer" value="<?php echo $viewurl;?>#comment" />
            <input type="hidden" name="id" value="<?php echo $data['id'];?>" />
            <input type="hidden" name="idtype" value="<?php echo $data['idtype'];?>" />
            <input type="hidden" name="aid" value="<?php echo $aid;?>">
        <?php } ?>
        <input type="hidden" name="formhash" value="<?php echo FORMHASH;?>">
        <input type="hidden" name="replysubmit" value="true">
        <input type="hidden" name="commentsubmit" value="true" />
        <p class="pt10 cl y"><button type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="true" class="pn y">评论</button></p>
        </div>
    </form>
    <script type="text/javascript">
    jQuery(function(){
jQuery("#tedt .pt").focus(function(){
  jQuery(this).addClass("bgchange");
}).blur(function(){
  jQuery(this).removeClass("bgchange");
});
    });
    </script> 
<div class="clear"></div>
    <?php } ?> 
    <?php if($data['commentnum'] == 0) { ?>
    <?php } else { ?>
    <div class="nex_allcomments_top">
    	<span>精彩评论</span>
        <div class="clear"></div>
    </div>
    <?php } ?>
    <div class="nex_comment_alllist">
        <ul>
        <?php if(is_array($commentlist)) foreach($commentlist as $comment) { ?> 
        <?php include template('portal/comment_li'); ?> 
        <?php if(!empty($aimgs[$comment['cid']])) { ?> 
        <script type="text/javascript" reload="1">aimgcount[<?php echo $comment['cid'];?>] = [<?php echo implode(',', $aimgs[$comment['cid']]);; ?>];attachimgshow(<?php echo $comment['cid'];?>);</script> 
        <?php } ?> 
        <?php } ?>
        </ul>
    </div>
    <p class="ptn cl nex_allarticle_comments">
        <?php if($data['commentnum']) { ?><a href="<?php echo $common_url;?>" class="xi2">查看全部评论>></a><?php } ?>
      </p>
  </div>
</div>
 
                        <?php } ?>     
                    </div>
            	</div>
            </div>
        </div>
        <div class="nex_ART_content_r">
        	<!--推荐阅读-->
        	<div class="nex_right_grids nex_plugin_grids">
                <div class="nex_new_zx_top"><span>推荐阅读</span><div class="clear"></div></div>
                <div class="nex_tj_read_list">
                    <ul>
                    	<!--[diy=nex_tj_read_list]--><div id="nex_tj_read_list" class="area"><div id="framemrtuuT" class="frame move-span cl frame-1"><div id="framemrtuuT_left" class="column frame-1-c"><div id="framemrtuuT_left_temp" class="move-span temp"></div><?php block_display('132');?></div></div></div><!--[/diy]-->
                        
                    </ul>
                </div>
            </div>
            <!--热门教程-->
            <div class="nex_right_grids">
                <div class="nex_new_zx_top"><span>热门教程</span><div class="clear"></div></div>
                <div class="nex_new_zx_list">
                    <ul>
                        <!--[diy=nex_new_zx_list]--><div id="nex_new_zx_list" class="area"><div id="frameznmqZ2" class="frame move-span cl frame-1"><div id="frameznmqZ2_left" class="column frame-1-c"><div id="frameznmqZ2_left_temp" class="move-span temp"></div><?php block_display('133');?></div></div></div><!--[/diy]-->
                    </ul>
                </div>
            </div>
            <!--广告位-->
            <div class="nex_right_ads">
            	<!--[diy=nex_right_ads]--><div id="nex_right_ads" class="area"><div id="frameONiDAe" class="frame move-span cl frame-1"><div id="frameONiDAe_left" class="column frame-1-c"><div id="frameONiDAe_left_temp" class="move-span temp"></div><?php block_display('134');?></div></div></div><!--[/diy]-->
                
            </div>
            <script type="text/javascript">
jQuery(window).scroll(function(){
var rightH = jQuery('.nex_ART_content_r').height();
var t = jQuery(".nex_ART_content_r").offset().top;
var cH = jQuery(document).height();
var h=jQuery(this).scrollTop();
var fH = jQuery('.nexfooter').height();
var wH = jQuery(window).height();
var hH = cH-(h+wH);
if(h>rightH && hH > fH){
jQuery(".nex_plugin_grids").addClass('nexfixed');
}else{
jQuery(".nex_plugin_grids").removeClass('nexfixed');
}
});
</script>
        </div>
        <div class="clear"></div>
    </div>
</div>    
       

<?php if($_G['relatedlinks']) { ?>
<script type="text/javascript">
var relatedlink = [];<?php if(is_array($_G['relatedlinks'])) foreach($_G['relatedlinks'] as $key => $link) { ?>relatedlink[<?php echo $key;?>] = {'sname':'<?php echo $link['name'];?>', 'surl':'<?php echo $link['url'];?>'};
<?php } ?>
relatedlinks('article_content');
</script>
<?php } ?>

<div class="wp mtn">
<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>
<input type="hidden" id="portalview" value="1"><?php include template('common/footer'); ?>