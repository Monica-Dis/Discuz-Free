<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); ?>
<div class="nexlogin">                 
<?php if($_G['uid']) { ?>
        <?php include 'template/nex_sucai_190828/php/nex_users.php'?>        <div class="nexallmember">
            <div id="nexmemberinfo">
                <a class="nexvwmy" href="home.php?mod=space&amp;uid=<?php echo $_G['uid'];?>" target="_blank" title="访问我的空间">
                <?php echo avatar($_G[uid],big);?>                    <span><?php echo $_G['member']['username'];?></span>
                    <i></i>
                    <div class="clear"></div>
                </a>
            </div>
            <div id="nexmembercontent">
            	<i></i>
                <div class="nex_mem_topbox">
                	<div class="nex_mem_tools">
                    	<ul>
                        	<li class="nex_mem_notice">
                            	<a href="home.php?mod=space&amp;do=pm&amp;filter=newpm" title="消息短信" target="_blank">
                                    <?php if($_G['member']['newpm']) { ?>
                                    <em></em>
                                    <?php } elseif($_G['member']['newprompt']) { ?>
                                    <em></em>
                                    <?php } ?>
                                </a>
                            </li>
                            <li class="nex_mem_settings"><a href="home.php?mod=spacecp&amp;ac=avatar" title="个人设置" target="_blank"></a></li>
                        </ul>
                    </div>
                	<div class="nex_mem_topbox_users">
                    	<div class="nexmemberavator"><?php echo avatar($_G[uid],big);?></div>
                        <div class="nexmemberintels">
                        	<h5><?php echo $_G['member']['username'];?></h5>
                            <p>ID：<?php echo $nex_userid;?></p>
                            <ul>
                            	<?php if($nex_uc_province == '' || $nex_uc_adds == '') { ?>
                                <li>未知地域</li>
                                <?php } else { ?>
                            	<li><?php echo $nex_uc_province;?><?php echo $nex_uc_adds;?></li>
                                <?php } ?>
                                <?php if($nex_uc_occu == '') { ?>
                                <?php } else { ?>
                                <li><?php echo $nex_uc_occu;?></li>
                                <?php } ?>
                                </li>
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="nex_member_pad">
                    <div class="nex_mem_midbox">
                        <div class="nexmemberinfos">
                            <ul>
                                <li class="nexmemberinfos_1">
                                    <p><?php echo $_G['member']['credits'];?></p>
                                    <div class="nexmemberinfoterms">积分</div>
                                </li>
                                <li class="nexmemberinfos_2">
                                    <p><?php echo $nex_user_element['threads'];?></p>
                                    <div class="nexmemberinfoterms">发布</div>
                                </li>
                                <li class="nexmemberinfos_3">
                                    <p><?php echo $nex_user_element['following'];?></p>
                                    <div class="nexmemberinfoterms">关注</div>
                                </li>
                                <li class="nexmemberinfos_4">
                                    <p><?php echo $nex_user_element['follower'];?></p>
                                    <div class="nexmemberinfoterms">粉丝</div>
                                </li>
                                
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="nexmemberinfobtn"><a href="home.php?mod=space&amp;uid=<?php echo $_G['uid'];?>" target="_blank" title="访问我的空间"><b></b>访问我的空间</a></div>
                    </div>
                    <div class="nexmembercontent_Btm">
                        <ul>
                            <li>
                                <?php if(check_diy_perm($topic)) { ?>
                                <?php echo $diynav;?>
                                <?php } else { ?>
                                <a href="home.php?mod=space&amp;do=notice&amp;view=interactive&amp;type=friend" target="_blank">
                                    <span class="nex_icon1"></span>
                                    <p>好友</p>
                                </a>
                                <?php } ?>
                            </li>
                            <li>
                                <a href="forum.php?mod=guide&amp;view=my" target="_blank">
                                    <span class="nex_icon2"></span>
                                    <p>帖子</p>
                                </a>								
                            </li>
                            <li>
                                <a class="" href="home.php?mod=space&amp;do=notice&amp;type=post&amp;isread=<?php echo $_G['uid'];?>" target="_blank">
                                    <span class="nex_icon3"></span>
                                    <p>回复</p>
                                </a>							
                            </li>
                            <li>
                                <a href="home.php?mod=space&amp;do=favorite&amp;view=me" target="_blank">
                                    <span class="nex_icon4"></span>
                                    <p>收藏</p>
                                </a>
                            </li>
                            <li>
                                <a href="member.php?mod=logging&amp;action=logout&amp;formhash=<?php echo FORMHASH;?>">
                                    <span class="nex_icon5"></span>
                                    <p>退出</p>
                                </a>
                            </li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nexmembercontent_hook"><?php if(!empty($_G['setting']['pluginhooks']['global_usernav_extra1'])) echo $_G['setting']['pluginhooks']['global_usernav_extra1'];?><?php if(!empty($_G['setting']['pluginhooks']['global_usernav_extra2'])) echo $_G['setting']['pluginhooks']['global_usernav_extra2'];?><?php if(!empty($_G['setting']['pluginhooks']['global_usernav_extra3'])) echo $_G['setting']['pluginhooks']['global_usernav_extra3'];?><?php if(!empty($_G['setting']['pluginhooks']['global_usernav_extra4'])) echo $_G['setting']['pluginhooks']['global_usernav_extra4'];?></div>
                    <div class="clear"></div>
                </div>
            </div>
            <script type="text/javascript">
                jQuery("#nexmemberinfo").hover(
                    function(){
                        jQuery(this).siblings("#nexmembercontent").show();
                        },
                    function(){
                        jQuery(this).siblings("#nexmembercontent").hide();
                        })
                jQuery("#nexmembercontent").hover(
                    function(){
                        jQuery(this).show();
                        jQuery(this).siblings("#nexmemberinfo").addClass("nex_curs");
                        },
                    function(){
                        jQuery(this).hide();
                        jQuery(this).siblings("#nexmemberinfo").removeClass("nex_curs");
                        })
            </script>
        </div>
   		<ul>
     	<?php } elseif(!empty($_G['cookie']['loginuser'])) { ?>
            <li><a id="loginuser" class="noborder"><?php echo dhtmlspecialchars($_G['cookie']['loginuser']); ?></a></li>
            <li><a href="member.php?mod=logging&amp;action=login" onClick="showWindow('login', this.href)">激活</a></li>
            <li><a href="member.php?mod=logging&amp;action=logout&amp;formhash=<?php echo FORMHASH;?>">退出</a></li>
    	<?php } elseif(!$_G['connectguest']) { ?>
        	<div class="nexmain_dls">
                <ul>
                	<li class="nexbdLogin"><a href="member.php?mod=logging&amp;action=login" onclick="showWindow('login', this.href)">登陆</a></li>
                    <li class="nexbdRegs"><a href="member.php?mod=<?php echo $_G['setting']['regname'];?>">注册</a></li>
                    <div class="clear"></div>
                </ul>
            </div>
            
     	<?php } else { ?>
            <div class="nex_qq_kuang">
                <div class="nex_qq_kuang_before">QQ资料</div>
                <div class="nex_qq_kuang_after">
                    <div id="um">
                        <div class="avt y"><?php echo avatar(0,small);?></div>
                        <div class="nex_qq_lines">
                            <strong class="vwmy qq"><?php echo $_G['member']['username'];?></strong>
                            <?php if(!empty($_G['setting']['pluginhooks']['global_usernav_extra1'])) echo $_G['setting']['pluginhooks']['global_usernav_extra1'];?>
                            <span class="pipe">|</span><a href="member.php?mod=logging&amp;action=logout&amp;formhash=<?php echo FORMHASH;?>">退出</a>
                        </div>
                        <div class="nex_qq_lines">
                            <a href="home.php?mod=spacecp&amp;ac=credit&amp;showcredit=1">积分: 0</a>
                            <span class="pipe">|</span>用户组: <?php echo $_G['group']['grouptitle'];?>
                        </div>
                    </div>
                </div>
                <script type="text/javascript">
                    jq(".nex_qq_kuang").hover(
                        function(){
                            jq(this).children(".nex_qq_kuang_after").show();
                            },
                        function(){
                            jq(this).children(".nex_qq_kuang_after").hide();
                            })
                    
                </script>
            </div>
        <?php } ?>
    	</ul>
</div>