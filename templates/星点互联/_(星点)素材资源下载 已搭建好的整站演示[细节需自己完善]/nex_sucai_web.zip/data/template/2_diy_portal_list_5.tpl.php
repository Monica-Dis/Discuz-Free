<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('list_5');?><?php include template('common/header'); ?><link rel="stylesheet" type="text/css" href="template/nex_sucai_190828/neoconex/topup/main.css">
<!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->
<div class="nex_topupbox">
<div class="w1240">
    	<div class="nex_VIP_bd">
            <div class="nex_VIP_authority">
                <div class="nex_VIP_authorityTOp">
                	<div class="nex_inner_conts">
                    	<h5><span>超值全站VIP服务</span><em>内容持续上新</em></h5>
                    	<p>元素 + 背景 + 模板 + 摄影图 + 艺术字 + UI + GIF + 插画 + 办公 + 视听 = 全站VIP</p>
                    </div>
                </div>
                <div class="nex_VIP_Body">
                    <?php if($_G['uid']) { ?>
                    <h5>
                        <span>1.请选择您要充值的金额</span>
                        <a href="#" target="_blank">查看详细VIP授权对比</a>
                        <div class="clear"></div>
                    </h5>
                    <?php } else { ?>
                    <h4>
                        <em>您当前未登录,请</em><a href="member.php?mod=logging&amp;action=login">点击登录</a><div class="clear"></div>
                    </h4>
                    <?php } ?>
                    <div class="nex_VIP_tabs">
                        <ul>
                            <li class="nex_VIP_labels ons">
                            	<div class="nex_VIP_recommend">最具性价比VIP</div>
                            	<div class="nex_VIP_tops">包月VIP会员</div>
                                <div class="nex_VIP_tagINter"><em>39</em>元/月</div>
                                <p>包月VIP，平均每天低至1.9元</p>
                                <strong></strong>
                            </li>
                            <li>
                            	<div class="nex_VIP_tops">包年VIP会员</div>
                                <div class="nex_VIP_tagINter"><em>99</em>元/年</div>
                                <p>全站整年全部免费下载</p>
                                <strong></strong>
                            </li>
                            <li>
                            	<div class="nex_VIP_tops">全站终身VIP</div>
                                <div class="nex_VIP_tagINter"><em>199</em>元/终身</div>
                                <p>全站终身免费下载</p>
                                <strong></strong>
                            </li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_VIP_pay">
                        <ul>
                            <li style="display:block;">
                                <div class="nex_VIP_price">应付金额：<em>￥39.00</em></div>
                            </li>
                            <li>
                                <div class="nex_VIP_price">应付金额：<em>￥69.00</em></div>
                            </li>
                            <li>
                                <div class="nex_VIP_price">应付金额：<em>￥199.00</em></div>
                            </li>
                        </ul>
                    </div>
                    <h5><span>2.请选择支付方式</span></h5>
                    <div class="nex_VIP_selections">
                        <ul>
                            <li style="display:block;">
                                <div class="nex_VIP_ewmbox">
                                    <dl>
                                        <dd>
                                            <div class="nex_VIP_ewmpic nex_VIP_ewmpic_wx">
                                                <?php if($_G['uid']) { ?>
                                                <img src="template/nex_sucai_190828/neoconex/topup/wxpay_1.png" />
                                                <?php } else { ?>
                                                <div class="nex_VIP_unlogin">
                                                    <a href="member.php?mod=logging&amp;action=login">会员登录后才能购买</a>
                                                </div>
                                                <?php } ?>
                                            </div>
                                            <div class="nex_VIP_ewmbtm nex_wxpay"></div>
                                        </dd>
                                        <dd>
                                            <div class="nex_VIP_ewmpic nex_VIP_ewmpic_ali">
                                                <?php if($_G['uid']) { ?>
                                                <img src="template/nex_sucai_190828/neoconex/topup/alipay_1.jpg" />
                                                <?php } else { ?>
                                                <div class="nex_VIP_unlogin">
                                                    <a href="member.php?mod=logging&amp;action=login">会员登录后才能购买</a>
                                                </div>
                                                <?php } ?>
                                            </div>
                                            <div class="nex_VIP_ewmbtm nex_zfbpay"></div>
                                        </dd>
                                        <div class="clear"></div>
                                    </dl>
                                </div>
                            </li>
                            <li>
                                <div class="nex_VIP_ewmbox">
                                    <dl>
                                        <dd>
                                            <div class="nex_VIP_ewmpic nex_VIP_ewmpic_wx">
                                                <?php if($_G['uid']) { ?>
                                                <img src="template/nex_sucai_190828/neoconex/topup/wxpay_2.png" />
                                                <?php } else { ?>
                                                <div class="nex_VIP_unlogin">
                                                    <a href="member.php?mod=logging&amp;action=login">会员登录后才能购买</a>
                                                </div>
                                                <?php } ?>
                                            </div>
                                            <div class="nex_VIP_ewmbtm nex_wxpay"></div>
                                        </dd>
                                        <dd>
                                            <div class="nex_VIP_ewmpic nex_VIP_ewmpic_ali">
                                                <?php if($_G['uid']) { ?>
                                                <img src="template/nex_sucai_190828/neoconex/topup/alipay_2.jpg" />
                                                <?php } else { ?>
                                                <div class="nex_VIP_unlogin">
                                                    <a href="member.php?mod=logging&amp;action=login">会员登录后才能购买</a>
                                                </div>
                                                <?php } ?>
                                            </div>
                                            <div class="nex_VIP_ewmbtm nex_zfbpay"></div>
                                        </dd>
                                        <div class="clear"></div>
                                    </dl>
                                </div>
                            </li>
                            <li>
                                <div class="nex_VIP_ewmbox">
                                    <dl>
                                        <dd>
                                            <div class="nex_VIP_ewmpic nex_VIP_ewmpic_wx">
                                                <?php if($_G['uid']) { ?>
                                                <img src="template/nex_sucai_190828/neoconex/topup/wxpay_3.png" />
                                                <?php } else { ?>
                                                <div class="nex_VIP_unlogin">
                                                    <a href="member.php?mod=logging&amp;action=login">会员登录后才能购买</a>
                                                </div>
                                                <?php } ?>
                                            </div>
                                            <div class="nex_VIP_ewmbtm nex_wxpay"></div>
                                        </dd>
                                        <dd>
                                            <div class="nex_VIP_ewmpic nex_VIP_ewmpic_ali">
                                                <?php if($_G['uid']) { ?>
                                                <img src="template/nex_sucai_190828/neoconex/topup/alipay_3.jpg" />
                                                <?php } else { ?>
                                                <div class="nex_VIP_unlogin">
                                                    <a href="member.php?mod=logging&amp;action=login">会员登录后才能购买</a>
                                                </div>
                                                <?php } ?>
                                            </div>
                                            <div class="nex_VIP_ewmbtm nex_zfbpay"></div>
                                        </dd>
                                        <div class="clear"></div>
                                    </dl>
                                </div>
                            </li>
                        </ul>
                    </div>
                    
                    <script type="text/javascript">
                        jQuery(".nex_VIP_tabs ul li").each(function(s){
                            jQuery(this).click(function(){
                                jQuery(this).addClass("ons").siblings().removeClass("ons");
                                jQuery(".nex_VIP_pay ul li").eq(s).show().siblings().hide();
                                jQuery(".nex_VIP_selections ul li").eq(s).show().siblings().hide();
                                })
                            })
                    </script>
                    <div class="nex_VIP_Advs">特殊说明</div>
                    <div class="nex_VIP_desc">
                        <p><em>**</em>注册会员充值为VIP会员后，请联络管理员<a href="tencent://Message/?Uin=<?php echo $_G['setting']['site_qq'];?>&amp;websiteName=#=&amp;Menu=yes">QQ<?php echo $_G['setting']['site_qq'];?></a>修改用户组<em>**</em></p>
                        <p><em>**</em>本论坛所收集的部分公开资料来源于互联网，转载的目的在于传递更多信息及用于网络分享，并不代表本论坛赞同其观点和对其真实性负责，也不构成任何其他建议。本论坛不保证信息的准确性、有效性、及时性和完整性。本论坛及其雇员一概毋须以任何方式就任何信息传递或传送的失误、不准确或错误，对用户或任何其他人士负任何直接或间接责任。在法律允许的范围内，本论坛在此声明，不承担用户或任何人士就使用或未能使用本论坛所提供的信息或任何链接所引致的任何直接、间接、附带、从属、特殊、惩罚性或惩戒性的损害赔偿。</p>
                        <p><em>**</em>本论坛部分作品是由网友自主投稿和发布、编辑整理上传，对此类作品本论坛仅供提供学习交流和参考，禁止用户用于商业行为，并请于下载后24小时内删除，若喜欢该作品请联系原作者购买正版。如果您发现论坛上有侵犯您的知识产权的作品，请与我们取得联系，我们会及时修改或删除。</p>
        
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div><?php include template('common/footer'); ?>                                      
                                        