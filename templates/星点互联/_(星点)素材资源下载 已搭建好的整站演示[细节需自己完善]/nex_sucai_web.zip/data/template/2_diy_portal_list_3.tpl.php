<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('list_3');
block_get('140,136,137,138,139');?><?php include template('common/header'); $list = array();?><?php $wheresql = category_get_wheresql($cat);?><?php $list = category_get_list($cat, $wheresql, $page);?><?php echo adshow("text/wp a_t");?><link rel="stylesheet" type="text/css" href="template/nex_sucai_190828/neoconex/info/list.css">
<div class="wp">
<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <div class="nex_intel_top">
    	<div class="w1240">
        	<div id="pt" class="bm cl">
                <a href="./" class="nvhm" title="首页"><?php echo $_G['setting']['bbname'];?></a> <em>&rsaquo;</em>
                <a href="<?php echo $_G['setting']['navs']['1']['filename'];?>"><?php echo $_G['setting']['navs']['1']['navname'];?></a> <em>&rsaquo;</em>
                <?php if(is_array($cat['ups'])) foreach($cat['ups'] as $value) { ?> <a href="<?php echo $portalcategory[$value['catid']]['caturl'];?>"><?php echo $value['catname'];?></a><em>&rsaquo;</em><?php } ?>
                <?php echo $cat['catname'];?>
                <?php if(($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])) { ?>
                <em>&rsaquo;</em><a href="portal.php?mod=portalcp&amp;ac=article&amp;catid=<?php echo $cat['catid'];?>">发表</a>
                <?php } ?>
            </div>
        </div>
    </div>
    <div class="nex_ART_frame_box">
    	<div class="w1240">
        	<div class="nex_ART_top_link">
            	<ul>
                	<!--[diy=nex_ART_top_link]--><div id="nex_ART_top_link" class="area"><div id="framec0f4hI" class="frame move-span cl frame-1"><div id="framec0f4hI_left" class="column frame-1-c"><div id="framec0f4hI_left_temp" class="move-span temp"></div><?php block_display('140');?></div></div></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <!--下级分类-->
            <?php if($cat['subs']) { ?>
            <div class="nex_subnav_grids">
                <ul>
                <?php $i = 1;?>                <?php if(is_array($cat['subs'])) foreach($cat['subs'] as $value) { ?>                <?php if($i != 1) { } ?><li><a href="<?php echo $portalcategory[$value['catid']]['caturl'];?>" ><?php echo $value['catname'];?></a></li><?php $i--;?>                <?php } ?>
                <div class="clear"></div>
                </ul>
            </div>
            <?php } ?>
            <div class="nex_ART_frame_left">
            	<div class="nex_ART_frame_list">
                	<ul>
                        <?php if(is_array($list['list'])) foreach($list['list'] as $value) { ?>                            <?php $highlight = article_title_style($value);?>                            <?php $article_url = fetch_article_url($value);?>                            <?php if($value['pic']) { ?>
                            <li>
                                <div class="nex_ART_img">
                                	<a href="<?php echo $article_url;?>" target="_blank" style="background:url(<?php echo $value['pic'];?>) center no-repeat; background-size:cover;"></a>
                                </div>
                                <div class="nex_ART_value">
                                	<div class="nex_ART_value_top">
                                    	<?php if($value['catname'] && $cat['subs']) { ?>
                                        <em><a href="<?php echo $portalcategory[$value['catid']]['caturl'];?>" target="_blank"><?php echo $value['catname'];?></a></em>
                                        <?php } ?>
                                        <h5><a href="<?php echo $article_url;?>" target="_blank"><?php echo $value['title'];?></a></h5>
                                    </div>
                                    <div class="nex_ART_summary"><?php echo cutstr($value['summary'],160); ?></div>
                                    <div class="nex_ART_btm_info">
                                    	<div class="nex_ART_btm_info_l">
                                        	By
                                        	<a href="home.php?mod=space&amp;uid=<?php echo $value['uid'];?>&amp;do=thread&amp;view=me&amp;from=space" target="_blank"><?php echo $value['username'];?></a>
                                            Date
                                            <em><?php echo $value['dateline'];?></em>
                                        </div>
                                        <div class="nex_ART_btm_info_r">
                                        	<span>View</span><em><?php $nex_viewnum = DB::query("SELECT t1.viewnum from ".DB::table('portal_article_count')." t1 inner join ".DB::table('portal_article_title')." t2 on t1.aid=t2.aid WHERE t2.aid=$value[aid]"); $nex_ = DB::fetch($nex_viewnum);echo $nex_['viewnum'];?></em>
                                            
                                            <span>Comment</span><em><?php $nex_commentnum = DB::query("SELECT t1.commentnum from ".DB::table('portal_article_count')." t1 inner join ".DB::table('portal_article_title')." t2 on t1.aid=t2.aid WHERE t2.aid=$value[aid]"); $nex_ = DB::fetch($nex_commentnum);echo $nex_['commentnum'];?></em>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                                <div class="clear"></div>
                            </li> 
                            <?php } else { ?>
                            <li>
                                <div class="nex_ART_value_null">
                                	<div class="nex_ART_value_top">
                                    	<?php if($value['catname'] && $cat['subs']) { ?>
                                        <em><a href="<?php echo $portalcategory[$value['catid']]['caturl'];?>" target="_blank"><?php echo $value['catname'];?></a></em>
                                        <?php } ?>
                                        <h5><a href="<?php echo $article_url;?>" target="_blank"><?php echo $value['title'];?></a></h5>
                                    </div>
                                    <div class="nex_ART_summary"><?php echo cutstr($value['summary'],160); ?></div>
                                    <div class="nex_ART_btm_info">
                                    	<div class="nex_ART_btm_info_l">
                                        	By
                                        	<a href="home.php?mod=space&amp;uid=<?php echo $value['uid'];?>&amp;do=thread&amp;view=me&amp;from=space" target="_blank"><?php echo $value['username'];?></a>
                                            Date
                                            <em><?php echo $value['dateline'];?></em>
                                        </div>
                                        <div class="nex_ART_btm_info_r">
                                        	<span>View</span><em><?php $nex_viewnum = DB::query("SELECT t1.viewnum from ".DB::table('portal_article_count')." t1 inner join ".DB::table('portal_article_title')." t2 on t1.aid=t2.aid WHERE t2.aid=$value[aid]"); $nex_ = DB::fetch($nex_viewnum);echo $nex_['viewnum'];?></em>
                                            
                                            <span>Comment</span><em><?php $nex_commentnum = DB::query("SELECT t1.commentnum from ".DB::table('portal_article_count')." t1 inner join ".DB::table('portal_article_title')." t2 on t1.aid=t2.aid WHERE t2.aid=$value[aid]"); $nex_ = DB::fetch($nex_commentnum);echo $nex_['commentnum'];?></em>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                            </li> 
                            <?php } ?>  
                        <?php } ?>
                    </ul>
                </div>
                <?php echo adshow("articlelist/mbm hm/3");?><?php echo adshow("articlelist/mbm hm/4");?>                <?php if($list['multi']) { ?><div class="pgs cl" id="nex_page"><?php echo $list['multi'];?></div><?php } ?>
                <!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->
            </div>
            <div class="nex_ART_frame_right">
            	<!--关注二维码-->
                <div class="nex_right_ads">
                	<!--[diy=nex_right_ads]--><div id="nex_right_ads" class="area"><div id="frameJE9RR9" class="frame move-span cl frame-1"><div id="frameJE9RR9_left" class="column frame-1-c"><div id="frameJE9RR9_left_temp" class="move-span temp"></div><?php block_display('136');?></div></div></div><!--[/diy]-->
                   
                </div>
            	<!--热门教程-->
                <div class="nex_right_grids nex_plugin_grids">
                    <div class="nex_new_zx_top"><span>热门教程</span><div class="clear"></div></div>
                    <div class="nex_new_zx_list">
                        <ul>
                        	<!--[diy=nex_new_zx_list]--><div id="nex_new_zx_list" class="area"><div id="frameUu530E" class="frame move-span cl frame-1"><div id="frameUu530E_left" class="column frame-1-c"><div id="frameUu530E_left_temp" class="move-span temp"></div><?php block_display('137');?></div></div></div><!--[/diy]-->
                           
                        </ul>
                    </div>
                </div>
                
                <script type="text/javascript">
                    jQuery(window).scroll(function(){
                        var rightH = jQuery('.nex_ART_frame_right').height();
                        var t = jQuery(".nex_ART_frame_right").offset().top;
                        var cH = jQuery(document).height();
                        var h=jQuery(this).scrollTop();
                        var fH = jQuery('.nexfooter').height();
                        var wH = jQuery(window).height();
                        var hH = cH-(h+wH);
                        if(h>rightH && hH > fH){
                            jQuery(".nex_plugin_grids").addClass('nexfixed');
                        }else{
                            jQuery(".nex_plugin_grids").removeClass('nexfixed');
                        }
                    });
                </script>
                <!--阅读排行-->
                <div class="nex_right_grids">
                    <div class="nex_new_zx_top"><span>阅读排行</span><div class="clear"></div></div>
                    <div class="nex_new_read_list">
                        <ul>
                        	<!--[diy=nex_new_read_list]--><div id="nex_new_read_list" class="area"><div id="framexhNwga" class="frame move-span cl frame-1"><div id="framexhNwga_left" class="column frame-1-c"><div id="framexhNwga_left_temp" class="move-span temp"></div><?php block_display('138');?></div></div></div><!--[/diy]-->
                            
                        </ul>
                    </div>
                </div>
                <!--广告位-->
                <div class="nex_right_ads">
                	<!--[diy=nex_right_ads2]--><div id="nex_right_ads2" class="area"><div id="framewPfdGA" class="frame move-span cl frame-1"><div id="framewPfdGA_left" class="column frame-1-c"><div id="framewPfdGA_left_temp" class="move-span temp"></div><?php block_display('139');?></div></div></div><!--[/diy]-->
                    
                </div>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    
</div><?php include template('common/footer'); ?>