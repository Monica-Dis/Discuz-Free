<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); 
block_get('3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33');?><?php include template('common/header_index'); ?><div class="wp">
<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <!--index_main-->
    
    <div class="nex_index_maintop">
        <div class="nexfullSlide">
            <div class="bd">
                <!--[diy=bd]--><div id="bd" class="area"><div id="frameh70OrO" class="frame move-span cl frame-1"><div id="frameh70OrO_left" class="column frame-1-c"><div id="frameh70OrO_left_temp" class="move-span temp"></div><?php block_display('3');?></div></div></div><!--[/diy]-->
               
                
            </div>
            <div class="hd">
                <ul>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                    <li></li>
                </ul>
            </div>
            <a class="prev" href="javascript:void(0)"></a>
            <a class="next" href="javascript:void(0)"></a>
        </div>
        <script type="text/javascript">
            jQuery(".nexfullSlide").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:true, autoPage:true, trigger:"click" });
        </script>
        <!--advanced-->
        <div class="nex_adv_box">
        	<div class="w1240">
            	<div class="nex_adv_list">
                	<ul>
                    	<!--[diy=nex_adv_list]--><div id="nex_adv_list" class="area"><div id="frameDg6x8t" class="frame move-span cl frame-1"><div id="frameDg6x8t_left" class="column frame-1-c"><div id="frameDg6x8t_left_temp" class="move-span temp"></div><?php block_display('4');?></div></div></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--select types-->
        <div class="nex_select_types">
        	<div class="w1240">
                <div class="nex_select_types_top">
                    <ul>
                    	<!--[diy=nex_select_types_top]--><div id="nex_select_types_top" class="area"><div id="frameny8E8l" class="frame move-span cl frame-1"><div id="frameny8E8l_left" class="column frame-1-c"><div id="frameny8E8l_left_temp" class="move-span temp"></div><?php block_display('5');?></div></div></div><!--[/diy]-->
                        
                        <div class="clear"></div>
                    </ul>
                </div>
                <div class="nex_common_center_txt">精选专题资源</div>
                <div class="nex_select_types_btm">
                	<ul>
                    	<!--[diy=nex_select_types_btm]--><div id="nex_select_types_btm" class="area"><div id="frameXZfp3z" class="frame move-span cl frame-1"><div id="frameXZfp3z_left" class="column frame-1-c"><div id="frameXZfp3z_left_temp" class="move-span temp"></div><?php block_display('6');?></div></div></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <!--最新素材-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">最新素材</div>
                <div class="nex_icb_top_more"><a href="#" target="_blank">MORE</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_grids">
            	<ul>
                	<!--[diy=nex_sucai_grids1]--><div id="nex_sucai_grids1" class="area"><div id="framelmEjIZ" class="frame move-span cl frame-1"><div id="framelmEjIZ_left" class="column frame-1-c"><div id="framelmEjIZ_left_temp" class="move-span temp"></div><?php block_display('7');?></div></div></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_index_sep_ads">
            	<ul>
                	<!--[diy=nex_index_sep_ads]--><div id="nex_index_sep_ads" class="area"><div id="frameJWNBzr" class="frame move-span cl frame-1"><div id="frameJWNBzr_left" class="column frame-1-c"><div id="frameJWNBzr_left_temp" class="move-span temp"></div><?php block_display('8');?></div></div></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    
    <!--必备素材-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">设计师必备素材</div>
                <div class="nex_icb_top_more"><a href="#" target="_blank">MORE</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_grids">
            	<ul>
                	<!--[diy=nex_sucai_grids2]--><div id="nex_sucai_grids2" class="area"><div id="framemZr509" class="frame move-span cl frame-1"><div id="framemZr509_left" class="column frame-1-c"><div id="framemZr509_left_temp" class="move-span temp"></div><?php block_display('9');?></div></div></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            
        </div>
    </div>
    
    <!--素材分类-->
    <div class="nex_index_common_bd nex_index_common_bd_bgg">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">素材分类下载</div>
                <div class="nex_icb_top_tab">
                	<dl>
                    	<dd class="cur">HTML模板</dd>
                        <dd>免抠元素</dd>
                        <dd>PPT模板</dd>
                        <dd>电商淘宝</dd>
                        <dd>平面素材</dd>
                        <dd>高清背景图</dd>
                        <dd>设计元素</dd>
                        <div class="clear"></div>
                    </dl>
                </div>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_sort_btm">
            	<dl>	
                    <dd style="display:block;">
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids3]--><div id="nex_sucai_grids3" class="area"><div id="frameJfclTh" class="frame move-span cl frame-1"><div id="frameJfclTh_left" class="column frame-1-c"><div id="frameJfclTh_left_temp" class="move-span temp"></div><?php block_display('10');?></div></div></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
            		</dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids4]--><div id="nex_sucai_grids4" class="area"><div id="framee5RRFn" class="frame move-span cl frame-1"><div id="framee5RRFn_left" class="column frame-1-c"><div id="framee5RRFn_left_temp" class="move-span temp"></div><?php block_display('11');?></div></div></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids5]--><div id="nex_sucai_grids5" class="area"><div id="framenfjsEZ" class="frame move-span cl frame-1"><div id="framenfjsEZ_left" class="column frame-1-c"><div id="framenfjsEZ_left_temp" class="move-span temp"></div><?php block_display('12');?></div></div></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids6]--><div id="nex_sucai_grids6" class="area"><div id="framem6KNe6" class="frame move-span cl frame-1"><div id="framem6KNe6_left" class="column frame-1-c"><div id="framem6KNe6_left_temp" class="move-span temp"></div><?php block_display('13');?></div></div></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids7]--><div id="nex_sucai_grids7" class="area"><div id="frameEQP7pC" class="frame move-span cl frame-1"><div id="frameEQP7pC_left" class="column frame-1-c"><div id="frameEQP7pC_left_temp" class="move-span temp"></div><?php block_display('14');?></div></div></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids8]--><div id="nex_sucai_grids8" class="area"><div id="frameFfR1jJ" class="frame move-span cl frame-1"><div id="frameFfR1jJ_left" class="column frame-1-c"><div id="frameFfR1jJ_left_temp" class="move-span temp"></div><?php block_display('15');?></div></div></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_sucai_grids">
                            <ul>
                                <!--[diy=nex_sucai_grids9]--><div id="nex_sucai_grids9" class="area"><div id="frameb622OB" class="frame move-span cl frame-1"><div id="frameb622OB_left" class="column frame-1-c"><div id="frameb622OB_left_temp" class="move-span temp"></div><?php block_display('16');?></div></div></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
            	</dl>
            </div>
<script type="text/javascript">
jQuery(".nex_icb_top_tab dl dd").each(function(s){
jQuery(this).click(function(){
jQuery(this).addClass("cur").siblings().removeClass("cur");
jQuery(".nex_sucai_sort_btm dl dd").eq(s).show().siblings().hide();
})
})
</script>
            
        </div>
    </div>
    <!--VIP素材-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">VIP素材下载</div>
                <div class="nex_icb_top_more"><a href="#" target="_blank">MORE</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_grids">
            	<ul>
                	<!--[diy=nex_sucai_grids91]--><div id="nex_sucai_grids91" class="area"><div id="framePbtUSI" class="frame move-span cl frame-1"><div id="framePbtUSI_left" class="column frame-1-c"><div id="framePbtUSI_left_temp" class="move-span temp"></div><?php block_display('17');?></div></div></div><!--[/diy]-->
                    <div class="clear"></div>
                </ul>
            </div>
            
        </div>
    </div>
    <!--上周下载排行-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
            <div class="nex_sucai_rk_title">
                <span>上周下载排行榜</span>
                <em>上周已更新<i>2964</i>个素材</em>
                <div class="clear"></div>
            </div>
            <div class="nex_sucai_rklist">
                <div class="nex_sucai_rkcont_left">
                    <ul>
                    	<!--[diy=nex_sucai_rkcont_left]--><div id="nex_sucai_rkcont_left" class="area"><div id="framec313DT" class="frame move-span cl frame-1"><div id="framec313DT_left" class="column frame-1-c"><div id="framec313DT_left_temp" class="move-span temp"></div><?php block_display('18');?></div></div></div><!--[/diy]-->
                        
                    </ul>
                </div>
                <div class="nex_sucai_rkcont_right">
                    <ul>
                    	<!--[diy=nex_sucai_rkcont_right]--><div id="nex_sucai_rkcont_right" class="area"><div id="frameN7yW19" class="frame move-span cl frame-1"><div id="frameN7yW19_left" class="column frame-1-c"><div id="frameN7yW19_left_temp" class="move-span temp"></div><?php block_display('19');?></div></div></div><!--[/diy]-->
                        
                    </ul>
                </div>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <!--设计软件下载分类-->
    <div class="nex_index_common_bd nex_index_common_bd_bgg">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">设计软件下载分类</div>
                <div class="nex_icb_top_more"><a href="#" target="_blank">MORE</a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_teach_articles">
            	<ul>
                	<!--三维软件-->
                	<li>
                    	<div class="nex_teach_inner">
                        	<div class="nex_teach_inner_title nex_teach_inner_title1">三维软件下载</div>
                            <div class="nex_software_list">
                            	<dl>
                                	<!--[diy=nex_software_list]--><div id="nex_software_list" class="area"><div id="frameh7ogQg" class="frame move-span cl frame-1"><div id="frameh7ogQg_left" class="column frame-1-c"><div id="frameh7ogQg_left_temp" class="move-span temp"></div><?php block_display('20');?></div></div></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </div>
                    </li>
                    <!--渲染软件-->
                    <li>
                    	<div class="nex_teach_inner">
                        	<div class="nex_teach_inner_title nex_teach_inner_title2">渲染软件下载</div>
                            <div class="nex_software_list">
                            	<dl>
                                	<!--[diy=nex_software_list1]--><div id="nex_software_list1" class="area"><div id="frameLQt1bn" class="frame move-span cl frame-1"><div id="frameLQt1bn_left" class="column frame-1-c"><div id="frameLQt1bn_left_temp" class="move-span temp"></div><?php block_display('21');?></div></div></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </div>
                    </li>
                    <!--后期软件-->
                    <li>
                    	<div class="nex_teach_inner">
                        	<div class="nex_teach_inner_title nex_teach_inner_title3">后期软件下载</div>
                            <div class="nex_software_list">
                            	<dl>
                                	<!--[diy=nex_software_list2]--><div id="nex_software_list2" class="area"><div id="frameZ4KTgi" class="frame move-span cl frame-1"><div id="frameZ4KTgi_left" class="column frame-1-c"><div id="frameZ4KTgi_left_temp" class="move-span temp"></div><?php block_display('22');?></div></div></div><!--[/diy]-->
                                </dl>
                            </div>
                        </div>
                    </li>
                    <!--图纸软件-->
                    <li class="nex_ta_last">
                    	<div class="nex_teach_inner">
                        	<div class="nex_teach_inner_title nex_teach_inner_title4">图纸软件下载</div>
                            <div class="nex_software_list">
                            	<dl>
                                	<!--[diy=nex_software_list3]--><div id="nex_software_list3" class="area"><div id="framerBlbZx" class="frame move-span cl frame-1"><div id="framerBlbZx_left" class="column frame-1-c"><div id="framerBlbZx_left_temp" class="move-span temp"></div><?php block_display('23');?></div></div></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </div>
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    <!--创意文章-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_created_art">
            	
                <div class="nex_create_top_line">
                	<div class="nex_icb_top">
                        <div class="nex_icb_top_l">创意文章</div>
                        <div class="nex_icb_top_more"><a href="#" target="_blank">MORE</a></div>
                        <div class="clear"></div>
                    </div>
                	<div class="nex_create_artlisting">
                    	<ul>
                        	<!--[diy=nex_create_artlisting]--><div id="nex_create_artlisting" class="area"><div id="framet7UlXG" class="frame move-span cl frame-1"><div id="framet7UlXG_left" class="column frame-1-c"><div id="framet7UlXG_left_temp" class="move-span temp"></div><?php block_display('24');?></div></div></div><!--[/diy]-->
                        	
                            <div class="clear"></div>
                        </ul>
                    </div>
                </div>
                <div class="nex_create_btm_line">
                	<div class="nex_icb_top">
                        <div class="nex_icb_top_l">推荐软件教程阅读</div>
                        <div class="nex_icb_top_more"><a href="#" target="_blank">MORE</a></div>
                        <div class="clear"></div>
                    </div>
                	<div class="nex_listing_style">
                    	<ul>
                        	<!--[diy=nex_listing_style]--><div id="nex_listing_style" class="area"><div id="frametuFKNB" class="frame move-span cl frame-1"><div id="frametuFKNB_left" class="column frame-1-c"><div id="frametuFKNB_left_temp" class="move-span temp"></div><?php block_display('25');?></div></div></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                </div>
            </div>
            <div class="nex_totle_right">
            	<!--VIP ads-->
                <div class="nex_vip_guide_link">
                	<!--[diy=nex_vip_guide_link]--><div id="nex_vip_guide_link" class="area"><div id="frameybwPUk" class="frame move-span cl frame-1"><div id="frameybwPUk_left" class="column frame-1-c"><div id="frameybwPUk_left_temp" class="move-span temp"></div><?php block_display('26');?></div></div></div><!--[/diy]-->
                	
                </div>
                <div class="nex_vip_guide_link">
                	<a href="#" target="_blank"></a>
                </div>
                <!--热门标签-->
                <div class="nex_side_frame nex_side_frame_tag">
                	<div class="nex_side_frame_tt">
                    	<span>热门标签</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_tag_list">
                    	<!--[diy=nex_tag_list]--><div id="nex_tag_list" class="area"><div id="frameTAH4yd" class="frame move-span cl frame-1"><div id="frameTAH4yd_left" class="column frame-1-c"><div id="frameTAH4yd_left_temp" class="move-span temp"></div><?php block_display('27');?></div></div></div><!--[/diy]-->
                                          
                     </div>
                </div>
                <!--会员排行-->
                <div class="nex_side_frame">
                	<div class="nex_side_frame_tt">
                    	<span>会员排行</span>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_member_list">
                    	<ul>
                        	<!--[diy=nex_member_list]--><div id="nex_member_list" class="area"><div id="framemfCj3i" class="frame move-span cl frame-1"><div id="framemfCj3i_left" class="column frame-1-c"><div id="framemfCj3i_left_temp" class="move-span temp"></div><?php block_display('28');?></div></div></div><!--[/diy]-->
                            
                        </ul>
                    </div>
                </div>
                <!--切换排行榜-->
                <div class="nex_switch_listbox">
                    <div class="nex_tab_switch">
                    	<ul>
                        	<li class="cur">收藏最多</li>
                            <li>热门素材</li>
                            <li>猜你喜欢</li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="nex_tab_contants">
                    	<ul>
                        	<li style="display:block;">
                            	<div class="nex_tab_listboxs">
                                	<dl>
                                    	<!--[diy=nex_tab_listboxs]--><div id="nex_tab_listboxs" class="area"><div id="frameog612G" class="frame move-span cl frame-1"><div id="frameog612G_left" class="column frame-1-c"><div id="frameog612G_left_temp" class="move-span temp"></div><?php block_display('29');?></div></div></div><!--[/diy]-->
                                    	
                                    </dl>
                                </div>
                            </li>
                            <li>
                            	<div class="nex_tab_listboxs">
                                	<dl>
                                    	<!--[diy=nex_tab_listboxs1]--><div id="nex_tab_listboxs1" class="area"><div id="frameFdB886" class="frame move-span cl frame-1"><div id="frameFdB886_left" class="column frame-1-c"><div id="frameFdB886_left_temp" class="move-span temp"></div><?php block_display('30');?></div></div></div><!--[/diy]-->
                                    	
                                    </dl>
                                </div>
                            </li>
                            <li>
                            	<div class="nex_tab_listboxs">
                                	<dl>
                                    	<!--[diy=nex_tab_listboxs2]--><div id="nex_tab_listboxs2" class="area"><div id="framebPDfP6" class="frame move-span cl frame-1"><div id="framebPDfP6_left" class="column frame-1-c"><div id="framebPDfP6_left_temp" class="move-span temp"></div><?php block_display('31');?></div></div></div><!--[/diy]-->
                                    	
                                    </dl>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <script type="text/javascript">
jQuery(".nex_tab_switch ul li").each(function(s){
jQuery(this).click(function(){
jQuery(this).addClass("cur").siblings().removeClass("cur");
jQuery(".nex_tab_contants ul li").eq(s).show().siblings().hide();
})
})
</script>
                </div>
               
            </div>
            <div class="clear"></div>
        	<!--ads-->
            <div class="nex_index_sep_ads_three">
            	<ul>
                	<!--[diy=nex_index_sep_ads_three]--><div id="nex_index_sep_ads_three" class="area"><div id="frameMHpp53" class="frame move-span cl frame-1"><div id="frameMHpp53_left" class="column frame-1-c"><div id="frameMHpp53_left_temp" class="move-span temp"></div><?php block_display('32');?></div></div></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            
        </div>
    </div>
    <!--友情链接-->
    <div class="nex_index_common_bd">
    	<div class="w1240">
        	<div class="nex_icb_top">
            	<div class="nex_icb_top_l">友情链接</div>
                <div class="nex_icb_top_more"><a href="#" target="_blank">交换友情链接请联络QQ<?php echo $_G['setting']['site_qq'];?></a></div>
                <div class="clear"></div>
            </div>
            <div class="nex_link_to">
                <ul>
                	<!--[diy=nex_link_to]--><div id="nex_link_to" class="area"><div id="frameJKIjoO" class="frame move-span cl frame-1"><div id="frameJKIjoO_left" class="column frame-1-c"><div id="frameJKIjoO_left_temp" class="move-span temp"></div><?php block_display('33');?></div></div></div><!--[/diy]-->
                
                <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    
    
    
    
</div>    <?php include template('common/footer'); ?>