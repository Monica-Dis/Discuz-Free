<?php if(!defined('IN_DISCUZ')) exit('Access Denied'); hookscriptoutput('list_1');
block_get('112,113,114,115,116,120,117,118,119,111');?><?php include template('common/header'); ?><link rel="stylesheet" type="text/css" href="template/nex_sucai_190828/neoconex/extend_video/audio.css">
<link rel="stylesheet" type="text/css" href="template/nex_sucai_190828/neoconex/rk/main.css">
<!--[diy=nex_RK_btm_top1]--><div id="nex_RK_btm_top1" class="area"></div><!--[/diy]-->
<div class="nex_RK_bd">
    <div class="w1240">
        <div id="pt" class="bm cl">
            <div class="z">
                <a href="./" class="nvhm" title="首页"><?php echo $_G['setting']['bbname'];?></a> <em>&rsaquo;</em>
                <a href="<?php echo $_G['setting']['navs']['1']['filename'];?>"><?php echo $_G['setting']['navs']['1']['navname'];?></a> <em>&rsaquo;</em>
                <?php if(is_array($cat['ups'])) foreach($cat['ups'] as $value) { ?> <a href="<?php echo $portalcategory[$value['catid']]['caturl'];?>"><?php echo $value['catname'];?></a><em>&rsaquo;</em><?php } ?>
                <?php echo $cat['catname'];?>
            </div>
        </div>
        <!--[diy=nex_sort_read_list2]--><div id="nex_sort_read_list2" class="area"></div><!--[/diy]-->
        <!--HTML模板下载排行-->
        <div class="nex_ranklist_part">
            <div class="nex_ranklist_part_title">HTML模板下载排行</div>
            <div class="nex_ranklist_box">
                <div class="nex_sucai_grids">
                    <ul>
                        <!--[diy=nex_sucai_grids]--><div id="nex_sucai_grids" class="area"><div id="framewhYK9k" class="frame move-span cl frame-1"><div id="framewhYK9k_left" class="column frame-1-c"><div id="framewhYK9k_left_temp" class="move-span temp"></div><?php block_display('112');?></div></div></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--PPT模板下载排行-->
        <div class="nex_ranklist_part">
            <div class="nex_ranklist_part_title">PPT模板下载排行</div>
            <div class="nex_ranklist_box">
                <div class="nex_sucai_grids">
                    <ul>
                        <!--[diy=nex_sucai_grids2]--><div id="nex_sucai_grids2" class="area"><div id="frameZOCl03" class="frame move-span cl frame-1"><div id="frameZOCl03_left" class="column frame-1-c"><div id="frameZOCl03_left_temp" class="move-span temp"></div><?php block_display('113');?></div></div></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--设计元素下载排行-->
        <div class="nex_ranklist_part">
            <div class="nex_ranklist_part_title">设计元素PNG素材下载排行</div>
            <div class="nex_ranklist_box">
                <div class="nex_sucai_grids">
                    <ul>
                        <!--[diy=nex_sucai_grids3]--><div id="nex_sucai_grids3" class="area"><div id="frameGBBZ2u" class="frame move-span cl frame-1"><div id="frameGBBZ2u_left" class="column frame-1-c"><div id="frameGBBZ2u_left_temp" class="move-span temp"></div><?php block_display('114');?></div></div></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--电商淘宝素材下载排行-->
        <div class="nex_ranklist_part">
            <div class="nex_ranklist_part_title">电商淘宝素材下载排行</div>
            <div class="nex_ranklist_box">
                <div class="nex_sucai_grids">
                    <ul>
                        <!--[diy=nex_sucai_grids4]--><div id="nex_sucai_grids4" class="area"><div id="frameEyCanl" class="frame move-span cl frame-1"><div id="frameEyCanl_left" class="column frame-1-c"><div id="frameEyCanl_left_temp" class="move-span temp"></div><?php block_display('115');?></div></div></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--高清背景图下载排行-->
        <div class="nex_ranklist_part">
            <div class="nex_ranklist_part_title">高清背景图下载排行</div>
            <div class="nex_ranklist_box">
                <div class="nex_sucai_grids">
                    <ul>
                        <!--[diy=nex_sucai_grids5]--><div id="nex_sucai_grids5" class="area"><div id="framerp1A6k" class="frame move-span cl frame-1"><div id="framerp1A6k_left" class="column frame-1-c"><div id="framerp1A6k_left_temp" class="move-span temp"></div><?php block_display('116');?></div></div></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        
        <!--CG素材下载排行-->
        <div class="nex_ranklist_part">
            <div class="nex_ranklist_part_title">CG素材下载排行</div>
            <div class="nex_ranklist_box">
                <div class="nex_sucai_grids">
                    <ul>
                        <!--[diy=nex_sucai_grids0]--><div id="nex_sucai_grids0" class="area"><div id="frameDFYxr4" class="frame move-span cl frame-1"><div id="frameDFYxr4_left" class="column frame-1-c"><div id="frameDFYxr4_left_temp" class="move-span temp"></div><?php block_display('120');?></div></div></div><!--[/diy]-->
                        <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
        <!--视频素材下载排行-->
        <div class="nex_ranklist_part">
            <div class="nex_ranklist_part_title">视频素材下载排行</div>
            <div class="nex_ranklist_box">
                <div class="nex_tab_video_conts">
                    <div class="nex_video_grids">
                        <dl>
                            <!--[diy=nex_sucai_grids6]--><div id="nex_sucai_grids6" class="area"><div id="frameZhZjr5" class="frame move-span cl frame-1"><div id="frameZhZjr5_left" class="column frame-1-c"><div id="frameZhZjr5_left_temp" class="move-span temp"></div><?php block_display('117');?></div></div></div><!--[/diy]-->
                            <div class="clear"></div>
                        </dl>
                    </div>
                </div>
            </div>
        </div>
        <!--音频素材下载排行-->
        <div class="nex_ranklist_part">
            <div class="nex_ranklist_part_title">音频素材下载排行</div>
            <div class="nex_ranklist_box">
                <div class="nex_audio_grids">
                    <dl>
                        <!--[diy=nex_sucai_grids7]--><div id="nex_sucai_grids7" class="area"><div id="frameOy3jRf" class="frame move-span cl frame-1"><div id="frameOy3jRf_left" class="column frame-1-c"><div id="frameOy3jRf_left_temp" class="move-span temp"></div><?php block_display('118');?></div></div></div><!--[/diy]-->
                        <div class="clear"></div>
                    </dl>
                </div>
            </div>
        </div>
        <!--软件下载排行-->
        <div class="nex_ranklist_part">
            <div class="nex_ranklist_part_title">软件下载排行</div>
            <div class="nex_ranklist_box">
                <div class="nex_software_grids">
                    <ul>
                        <!--[diy=nex_sucai_grids8]--><div id="nex_sucai_grids8" class="area"><div id="framefhItp3" class="frame move-span cl frame-1"><div id="framefhItp3_left" class="column frame-1-c"><div id="framefhItp3_left_temp" class="move-span temp"></div><?php block_display('119');?></div></div></div><!--[/diy]-->
                        
                       <div class="clear"></div>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<!--底部广告位-->
<div class="nex_RK_btm">
<div class="w1240">
    	<div class="nex_RK_btm_top">
        	<ul>
            	<!--[diy=nex_RK_btm_top]--><div id="nex_RK_btm_top" class="area"><div id="framebAy1Ms" class="frame move-span cl frame-1"><div id="framebAy1Ms_left" class="column frame-1-c"><div id="framebAy1Ms_left_temp" class="move-span temp"></div><?php block_display('111');?></div></div></div><!--[/diy]-->
            	
                <div class="clear"></div>
            </ul>
        </div>
    </div>
</div>
<script type="text/javascript">
var video = jQuery('.nex_video_grids');
var videoLi = jQuery('dd');

videoLi.hover(function() {
var videoData = jQuery(this).data('video-url');

jQuery(this).find('video').attr('src', videoData);

}, function() {

jQuery(this).find('video').attr('src', '');
});
</script>

<script>
jQuery( function()
{
jQuery( 'audio' ).audioPlayer();
});
</script><?php include template('common/footer'); ?>                                      
                                        