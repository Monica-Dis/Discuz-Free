<?php echo 'Copyright@DISM.TAOBAO.COM';exit;?>
<!--{template common/header}-->
<style type="text/css">
.st-pusher{ background:#fff!important;}
.nex_hd_focus{ width:100%; height:126px;position:relative; overflow:hidden; }
.nex_hd_focus .hd{ width:95%; height:11px;  position:absolute; z-index:1; bottom:16px; right:5%; text-align:right;  }
.nex_hd_focus .hd ul{ display:inline-block;}
.nex_hd_focus .hd ul li{ display:inline-block; width:8px; height:8px; border-radius:100%; background:rgba(255,255,255,0.9); margin:0 2px;  vertical-align:top; overflow:hidden; line-height:200px;  }
.nex_hd_focus .hd ul .on{ background: #6ABF4B;}
.nex_hd_focus .bd{ position:relative; z-index:0; }
.nex_hd_focus .bd a{ display:block; width:100%; height:126px; position:relative;}
.nex_hd_focus .bd a img{width:100%; height:126px;}
.nex_HD_title{ text-align:center; margin:20px auto;}
.nex_HD_title h5{ height:30px; line-height:30px; font-size:20px; color:#4c4c4c; font-weight:600; overflow:hidden;}
.nex_HD_title p{ height:30px; line-height:30px; font-size:14px; color:#999; font-weight:400; overflow:hidden;}

.nex_hdparts{ padding:0 10px 10px;}
.nex_hd_hidden li{}
.nex_hd_hidden li a{}
.nex_hd_Picsd{width:100%; height:200px; position:relative;}
.nex_hd_Picsd img{ width:100%; height:200px;}
.nex_hd_Picsd span{ display:block; min-width:60px; padding:0 10px; text-align:center; overflow:hidden; height:30px; line-height:33px; font-size:14px; color:#fff; position:absolute; top:0; left:0; background:rgba(0,0,0,0.6)}
.nex_hd_bds{ padding:10px;}
.nex_hd_txt{ height:30px; line-height:30px; font-size: 16px; color:#4c4c4c; overflow:hidden; margin-bottom:10px; font-weight:600;}
.nex_hd_terms{ height:20px; line-height:20px; margin-bottom:5px; font-size:14px; color:#4c4c4c; overflow:hidden;}
.nex_hd_terms em{ color:#999; margin-right:5px;}
.nex_hd_Ner{ height:44px; line-height:22px; overflow:hidden; font-size:12px; color:#999;}
.nex_load_end{}
.nex_load_end li{ width:100%; height:100%;border:1px solid #eee; margin-bottom:10px; }
.nex_load_end li a{ display:block; background:#fff;transition: all .5s linear; -webkit-transition: all .5s linear; -moz-transition: all .5s linear; -ms-transition: all .5s linear;}
.nex_hdparts .nex_load_more{overflow: hidden;padding:10px;text-align: center;}
.nex_hdparts .nex_load_more a{display: block;width: 120px;padding:8px 0; font-size:12px;color:#fff;margin:0 auto;background: #6ABF4B;text-align:center;}
.nex_hdparts .nex_load_more a:hover{text-decoration: none;background: #6ABF4B;color: #fff;}
.nex_hdparts .nex_load_more p{text-align: center;padding: 10px; font-size:14px; color:#4c4c4c;}

</style>
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        <!--�õ�Ƭ-->
        <div id="nex_hd_focus" class="nex_hd_focus">
            <div class="hd">
                <ul></ul>
            </div>
            <div class="bd">
                <ul>
                <!--�Ƶ���������λ�л��ڲ����ô���-->
                    {$nex_qa_arr['hd_top']}
                </ul>
            </div>
        </div>
        <script type="text/javascript">
            TouchSlide({ 
                slideCell:"#nex_hd_focus",
                titCell:".hd ul", //�����Զ���ҳ autoPage:true ����ʱ���� titCell Ϊ����Ԫ�ذ�����
                mainCell:".bd ul", 
                effect:"left", 
                autoPlay:true,//�Զ�����
                autoPage:true, //�Զ���ҳ
                switchLoad:"_src" //�л����أ���ʵͼƬ·��Ϊ"_src" 
            });
        </script>
        <div class="nex_HD_title">
        	<h5>��վ�</h5>
            <p>10��רҵ���֯�������ʻ��Դһ������</p>
        </div>
        <div class="nex_hdparts">
            <div class="nex_hd_hidden">
            	<!--�Ƶ��������ڲ����ô���-->
                {$nex_qa_arr['hd_th']}
            </div>
        	<ul class="nex_load_end">���ݼ����У����Ժ�...</ul>
        	<div class="nex_load_more"><a href="javascript:;" onClick="moreload.loadMore();">������ظ���</a></div>
        </div>
        <script type="text/javascript">
		var _content = []; 
		var moreload = {
			_default:5, 
			_loading:2, 
			init:function(){
				var lis = $(".nex_hdparts .nex_hd_hidden li");
				$(".nex_hdparts ul.nex_load_end").html("");
				for(var n=0;n<moreload._default;n++){
					lis.eq(n).appendTo(".nex_hdparts ul.nex_load_end");
				}
				$(".nex_hdparts ul.nex_load_end li .nex_hd_Picsd img").each(function(){
					$(this).attr('src',$(this).attr('realSrc'));
				})
				for(var i=moreload._default;i<lis.length;i++){
					_content.push(lis.eq(i));
				}
				$(".nex_hdparts .nex_hd_hidden").html("");
			},
			loadMore:function(){
				var mLis = $(".nex_hdparts ul.nex_load_end li").length;
				for(var i =0;i<moreload._loading;i++){
					var target = _content.shift();
					if(!target){
						$('.nex_hdparts .nex_load_more').html("<p>ȫ���������...</p>");
						break;
					}
					$(".nex_hdparts ul.nex_load_end").append(target);
					$(".nex_hdparts ul.nex_load_end li .nex_hd_Picsd img").eq(mLis+i).each(function(){
						$(this).attr('src',$(this).attr('realSrc'));
					});
				}
			}
		}
		moreload.init();
	</script>
	</div>
</div>


<!--{template common/footer}-->

