<?php echo 'Copyright@DISM.TAOBAO.COM';exit;?>
<!--{template common/header}-->
<style type="text/css">
.nex_navbar{ background:none;}
.nextoplogo{ display:none;}
.st-pusher{ background:#fff!important;}
.nex_wendabg{ width:100%; height:300px; background:-webkit-gradient(linear,0 0,100% 0,from(#ff937c),to(#ff6565));; position:absolute; top:0; left:0; z-index:-1;}
.nex_wendabg_inter{ width:80%; margin:100px auto;}
.nex_wendabg_inter h5{ height:50px; line-height:50px; margin-bottom:10px; text-align:center; font-size:26px; color:#fff; font-weight:600; position:relative;}
.nex_wendabg_inter h5:after{ content:''; display:block; width:50px; height:2px; background:#fff; position:absolute; left:42%; top:50px;}
.nex_wendabg_inter p{height:30px; line-height:30px; text-align:center; font-size:16px; color:#fff; font-weight:400; overflow:hidden;}
.nex_wendabg_inter a{ display:block; width:150px; height:40px; line-height:40px; border-radius:4px; background:#fff; color:#FF927B; text-align:center; margin:20px auto;}
.nex_wendabds{ margin-top:250px; padding:15px;}
.nex_wendatags{ margin-bottom:20px; overflow:hidden;}
.nex_wendatags ul{ width:105%;}
.nex_wendatags ul li{ float:left; margin:0 2% 2% 0;}
.nex_wendatags ul li a{ display:block;padding: 2px 6px;  background:ffe8e1;  border: 1px solid #FF927B; height: 30px; line-height: 30px; font-size: 14px; color:#FF927B; text-align: center; border-radius: 4px; overflow: hidden;}
.nex_wendabd_title{ height:40px; line-height:40px; border-bottom:1px solid #eee; margin-bottom:20px; }
.nex_wendabd_title span{ display:block; font-size:18px; color:#2E333F; font-weight:600;}
.nex_wendabd_title span em{ color:#FF927B; font-weight:600; margin-right:5px;}
.nex_wendalists{ margin-bottom:30px;}
.nex_wendalists ul li{ padding-bottom:10px; margin-bottom:10px; border-bottom:1px dashed #eee;}
.nex_wendalists ul li:last-child{ padding-bottom:0; margin-bottom:0; border-bottom:0;}
.nex_wendalists ul li a{ display:block; width:100%;}
.nex_wdtops{ max-height:60px; line-height:30px; overflow:hidden; padding-left:35px; font-size:16px; color:#2E333F; font-weight:400; background:url(./template/nex_momkidm_180320/neoconex/qna/q.png) left 4px no-repeat; background-size:26px; margin-bottom:5px;}
.nex_wdbtms{ height:20px; line-height:20px; overflow:hidden; font-size:12px; color:#999;padding-left:35px; }
.nex_wdbtms em{ padding:0 8px; color:#eee;}
</style>
<div id="st-container" class="st-container">
	<div class="st-pusher">
		<!--{template common/headernav}-->
        <div class="nex_wendabg">
        	<div class="nex_wendabg_inter">
                <h5>�����ʴ�Ƶ��</h5>
                <p>����ר��רҵ�����������</p>
                <a href="#">�����ʴ���</a>
            </div>
        </div>
		<div class="nex_wendabds">
        	<div class="nex_wendatags">
            	<ul>
                <!--��������ڲ����ô���-->
                {$nex_qa_arr['qa_channel']}
                    <div class="clear"></div>
                </ul>
            </div>
        	<div class="nex_wendabd_title">
            	<span><em>����</em>�ʴ�</span>
            </div>
            <div class="nex_wendalists">
            	<ul>
                	<!--�������������ڲ����ô���-->
                    {$nex_qa_arr['essence']}
                </ul>
            </div>
            <div class="nex_wendabd_title">
            	<span><em>����</em>�ʴ�</span>
            </div>
            <div class="nex_wendalists">
            	<ul>
                	<!--�������������ڲ����ô���-->
                    {$nex_qa_arr['qa_hot']}
                </ul>
            </div>
            <div class="nex_wendabd_title">
            	<span><em>����</em>�ʴ�</span>
            </div>
            <div class="nex_wendalists">
            	<ul>
                	<!--�������������ڲ����ô���-->
                    {$nex_qa_arr['qa_new']}
                </ul>
            </div>
            <div class="nex_wendabd_title">
            	<span><em>����</em>�ʴ�</span>
            </div>
            <div class="nex_wendalists">
            	<ul>
                	<!--���ⰴ��������������ڲ����ô���-->
                    {$nex_qa_arr['qa_ranking']}
                </ul>
            </div>
        </div>
    
        
	</div>
</div>   

<!--{template common/footer}-->

