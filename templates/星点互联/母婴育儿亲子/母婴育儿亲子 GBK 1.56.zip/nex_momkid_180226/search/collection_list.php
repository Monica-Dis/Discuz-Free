<?php echo 'Copyright@DISM.TAOBAO.COM';exit;?>
<div class="tl">
	<!--{ad/search/y mtw}-->
	<!--{if empty($collectionlist)}-->
		<p class="emp xs2 xg2 nex_emp_notice">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="nex_collection_box">
        	<ul>
                <!--{loop $collectionlist $key $value}-->
                <li>
                    <h5><a href="forum.php?mod=collection&action=view&ctid=$value[ctid]" target="_blank">$value[name]</a></h5>
                    <div class="nex_collection_status">{lang threads}: $value[threadnum], {lang comment}: $value[commentnum], {lang subscribe}: $value[follownum], {lang lastupdate}: $value[lastupdate]</div>
                    <div class="nex_collection_desc">$value[desc]&nbsp;</div>
                </li>
                <!--{/loop}-->
                <div class="clear"></div>
            </ul>
		</div>
		<!--{if !empty($multipage)}--><br /><div class="pgs cl mbm">$multipage</div><!--{/if}-->
	<!--{/if}-->
</div>

