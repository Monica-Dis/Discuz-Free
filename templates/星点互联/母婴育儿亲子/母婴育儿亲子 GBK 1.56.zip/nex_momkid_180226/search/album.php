<?php echo 'Copyright@DISM.TAOBAO.COM-��Ȩ����';exit;?>
<!--{subtemplate search/header}-->
<div id="ct" class="w">
	<form class="searchform" method="post" autocomplete="off" action="search.php?mod=album" onsubmit="if($('scform_srchtxt')) searchFocus($('scform_srchtxt'));">
		<input type="hidden" name="formhash" value="{FORMHASH}" />

		<!--{subtemplate search/pubsearch}-->
		<!--{hook/album_top}-->

	</form>

	<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
		<!--{subtemplate search/album_list}-->
	<!--{/if}-->
	
</div>
<!--{hook/album_bottom}-->

<!--{subtemplate search/footer}-->
