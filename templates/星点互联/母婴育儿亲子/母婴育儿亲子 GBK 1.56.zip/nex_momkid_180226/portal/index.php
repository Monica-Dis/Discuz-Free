<?php echo 'Copyright@DISM.TAOBAO.COM';exit;?>
<!--{template common/header}-->
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <!--index_main-->
    <div class="nex_portalbd">
        <div class="w1180">
            <!--����-->
            <div class="nex_main_fl">
            	<ul>
                	<li class="nex_mfl_one">
                    	<!--[diy=nex_mfl_one]--><div id="nex_mfl_one" class="area"></div><!--[/diy]-->
                    	
                    </li>
                    <li class="nex_mfl_two">
                    	<!--[diy=nex_mfl_two]--><div id="nex_mfl_two" class="area"></div><!--[/diy]-->
                    	
                    </li>
                    <li class="nex_mfl_three">
                    	<!--[diy=nex_mfl_three]--><div id="nex_mfl_three" class="area"></div><!--[/diy]-->
                    	
                    </li>
                    <li class="nex_mfl_four">
                    	<!--[diy=nex_mfl_four]--><div id="nex_mfl_four" class="area"></div><!--[/diy]-->
                    	
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
            <!--ads-->
            <div class="nex_index_fullads">
            	<!--[diy=nex_index_fullads]--><div id="nex_index_fullads" class="area"></div><!--[/diy]-->
            	
            </div>
            <!--�Ż���һ����-->
            <div class="nex_mainpart_one">
            	<div class="nex_mpo_l">
                	<!--һ�����õ�-->
                    <div class="nex_sliderbar">
                    	<!--[diy=nex_sliderbar]--><div id="nex_sliderbar" class="area"></div><!--[/diy]-->
                    	
                        <a class="prev" href="javascript:void(0)"></a>
						<a class="next" href="javascript:void(0)"></a>
                        <ul class="hd">
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                        </ul>
                    </div>
                    <script type="text/javascript">
						jQuery(".nex_sliderbar").hover(function(){ jQuery(this).find(".prev,.next").stop(true,true).fadeTo("show",0.2) },function(){ jQuery(this).find(".prev,.next").fadeOut() });
						jQuery(".nex_sliderbar").slide({ mainCell:".pic",effect:"fold", autoPlay:true, delayTime:600, trigger:"click"});
					</script>
                    <!--С���λ-->
                    <div class="nex_small_tiny_ads"><!--[diy=nex_small_tiny_ads]--><div id="nex_small_tiny_ads" class="area"></div><!--[/diy]--></div>
                    <!--�����ע-->
                    <div class="nex_focus_on">
                    	<div class="nex_focus_on_top">
                        	<span>�����ע</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_focus_on_bom">
                        	<ul>
                            	<!--[diy=nex_focus_on_bom]--><div id="nex_focus_on_bom" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="nex_mpo_m">
                	<div class="nex_mpo_m_Title">
                    	<span></span><em>/TODAY'S NEWS</em><div class="clear"></div>
                    </div>
                    <!--ͷ����Ѷ-->
                    <div class="nex_header_tops">
                    	<!--[diy=nex_header_tops]--><div id="nex_header_tops" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_header_topk">
                    	<!--[diy=nex_header_topk]--><div id="nex_header_topk" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <!--������Ѷ-->
                    <div class="nex_roll_zx">
                    	<div class="nex_rzxl">������̬<i></i></div>
                        <div class="nex_rzxr">
                        	<div class="nex_rzxfocusBox">
                            	<!--[diy=nex_rzxfocusBox]--><div id="nex_rzxfocusBox" class="area"></div><!--[/diy]-->
                                
                                <a class="prev" href="javascript:void(0)"></a>
                                <a class="next" href="javascript:void(0)"></a>
                            </div>
                        
                            <script type="text/javascript">
                                jQuery(".nex_rzxfocusBox").slide({ mainCell:".pic",effect:"left", autoPlay:true, delayTime:300});
                            </script>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <!--ͷ���б�-->
                    <div class="nex_header_lists">
                    	<ul>
                        	<!--[diy=nex_header_lists]--><div id="nex_header_lists" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                    <!--ads-->
                    <div class="nex_mpo_mads"><!--[diy=nex_mpo_mads]--><div id="nex_mpo_mads" class="area"></div><!--[/diy]--></div>
                    <!--ͷ���б�-->
                    <div class="nex_header_lists">
                    	<ul>
                        	<!--[diy=nex_header_lists1]--><div id="nex_header_lists1" class="area"></div><!--[/diy]-->
                        </ul>
                    </div>
                    <!--����ר��-->
                    <div class="nex_yuer_zt">
                    	<div class="nex_yuer_zttop">
                        	<span>����ר��</span>
                            <em>/parenting topicals</em>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">����ר��</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_yuer_ztbom">
                        	<div class="nex_yuer_ztboml">
                            	<ul>
                                	<!--[diy=nex_yuer_ztboml]--><div id="nex_yuer_ztboml" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_yuer_ztbomr">
                            	<ul>
                                	<!--[diy=nex_yuer_ztbomr]--><div id="nex_yuer_ztbomr" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    
                </div>
                <div class="nex_mpo_r">
                	<!--�ر��Ƽ�-->
                    <div class="nex_sp_recomends">
                    	<div class="nex_sp_recomends_top">
                        	<span>�ر��Ƽ�</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">����&gt;</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_sp_putings">
                        	<ul>
                            	<!--[diy=nex_sp_putings]--><div id="nex_sp_putings" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                    <!--����С����-->
                    <div class="nex_yunyutools">
                    	<div class="nex_yytops">����С����</div>
                        <div class="nex_yy_tools">
                        	<ul>
                            	<!--[diy=nex_yy_tools]--><div id="nex_yy_tools" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </div>
                    
                    <!--���ӻ-->
                    <div class="nex_hd_box">
                    	<div class="nex_hd_box_top">
                        	<span>�������ӻ</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">����&gt;</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_hd_inerbox">
                        	<!--[diy=nex_hd_inerbox]--><div id="nex_hd_inerbox" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <script type="text/javascript">
						jQuery(".nex_hd_inerbox").slide({ mainCell:"ul", effect:"topLoop", vis:3,autoPlay:true, delayTime:1200,interTime:3500,easing:"easeInCubic"});
					</script>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            
            <!--�����ٿ�֪ʶ-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_yy">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_yy"><i>����</i>֪ʶ</span><em>/Acknowledge</em>
                    </div>
                    <div class="nex_cbd_swrapsR">
                    	<a href="http://t.cn/Aiux1Qh0" target="_blank">׼������</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">��̥ʮ��</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">��ǰ����</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">������</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">Ӥ����</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">�����ע</a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_cbd_mains">
                	<div class="nex_cbd_mainsL">
                    	<div class="nex_yy_part">
                        	<div class="nex_yy_bods">
                            	<div class="nex_yy_top_txt">
                                	<span><i>����</i>����</span>
                                    <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                                    <div class="clear"></div>
                                </div>
                            	<div class="nex_yy_bom_bod">
                                	<div class="nex_yybomls">
                                    	<ul>
                                        	<!--[diy=nex_yybomls]--><div id="nex_yybomls" class="area"></div><!--[/diy]-->
                                        	
                                        </ul>
                                    </div>
                                    <div class="nex_yybomrs">
                                    	<!--[diy=nex_yybomrs]--><div id="nex_yybomrs" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            
                            </div>
                            <div class="nex_yy_bods">
                            	<div class="nex_yy_top_txt">
                                	<span><i>����</i>����</span>
                                    <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                                    <div class="clear"></div>
                                </div>
                            	<div class="nex_yy_bom_bod">
                                	<div class="nex_yybomls">
                                    	<ul>
                                        	<!--[diy=nex_yybomls1]--><div id="nex_yybomls1" class="area"></div><!--[/diy]-->
                                        	
                                        </ul>
                                    </div>
                                    <div class="nex_yybomrs">
                                    	<!--[diy=nex_yybomrs1]--><div id="nex_yybomrs1" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_pointo_ads"><!--[diy=nex_pointo_ads1]--><div id="nex_pointo_ads1" class="area"></div><!--[/diy]--></div>
                        <div class="nex_yy_part">
                        	<div class="nex_yy_bods">
                            	<div class="nex_yy_top_txt">
                                	<span><i>������</i>֪ʶ</span>
                                    <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                                    <div class="clear"></div>
                                </div>
                            	<div class="nex_yy_bom_bod">
                                	<div class="nex_yybomls">
                                    	<ul>
                                        	<!--[diy=nex_yybomls2]--><div id="nex_yybomls2" class="area"></div><!--[/diy]-->
                                        	
                                        </ul>
                                    </div>
                                    <div class="nex_yybomrs">
                                    	<!--[diy=nex_yybomrs2]--><div id="nex_yybomrs2" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="nex_yy_bods">
                            	<div class="nex_yy_top_txt">
                                	<span><i>Ӥ����</i>�ٿ�</span>
                                    <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                                    <div class="clear"></div>
                                </div>
                            	<div class="nex_yy_bom_bod">
                                	<div class="nex_yybomls">
                                    	<ul>
                                        	<!--[diy=nex_yybomls3]--><div id="nex_yybomls3" class="area"></div><!--[/diy]-->
                                        	
                                        </ul>
                                    </div>
                                    <div class="nex_yybomrs">
                                    	<!--[diy=nex_yybomrs3]--><div id="nex_yybomrs3" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nex_cbd_mainsR">
                    	<div class="nex_side_ads">
                        	<!--[diy=nex_side_ads]--><div id="nex_side_ads" class="area"></div><!--[/diy]-->
                        	
                        </div>
                    	<div class="nex_cbd_mR">
                        	<div class="nex_cbd_smtxt">
                            	<span>ĸӤӪ��<i></i></span>
                                <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_cbd_listrts">
                            	<ul>
                                	<!--[diy=nex_cbd_listrts]--><div id="nex_cbd_listrts" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                        
                        <div class="nex_cbd_mR">
                        	<div class="nex_cbd_smtxt">
                            	<span>ĸӤ������<i></i></span>
                                <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_cbd_listrts">
                            	<ul>
                                	<!--[diy=nex_cbd_listrts1]--><div id="nex_cbd_listrts1" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
                <!--��ǩ-->
                <div class="nex_index_labels">
                    <div class="nex_index_label_leftpart">
                        <h5>��������֪ʶ</h5>
                        <i></i>
                    </div>
                    <div class="nex_index_label_righttpart">
                        <div class="nex_labels_tops">
                        	<!--[diy=nex_labels_tops]--><div id="nex_labels_tops" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <div class="nex_labels_tops nex_labels_botms">
                        	<!--[diy=nex_labels_botms]--><div id="nex_labels_botms" class="area"></div><!--[/diy]-->
                        	
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <!--��ɫ��Ŀ-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_ts">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_ts"><i>ĸӤ</i>��ɫ��Ŀ</span><em>/Special Columns</em>
                    </div>
                    <div class="nex_cbd_swrapsR nex_cbd_swrapsR_ts">
                    	<a href="http://t.cn/Aiux1Qh0" target="_blank">ר��������̸</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">��������</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">��������</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">�����ʴ�</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">ĸӤ��Ʒ</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">Ȧ�ӻ���</a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_tercel">
                	<div class="nex_tercel_L">
                    	<div class="nex_tercel_toptxt">
                            <span><i>ʳ��</i>��ת</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_foods">
                        	<ul>
                            	<!--[diy=nex_foods]--><div id="nex_foods" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                    <div class="nex_tercel_M">
                    	<div class="nex_tercel_toptxt">
                            <span><i>����</i>ѧ��</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_tercemains">
                        	<div class="nex_tcml">
                            	<ul>
                                	<!--[diy=nex_tcml]--><div id="nex_tcml" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                            <div class="nex_tcmr">
                            	<ul>
                                	<!--[diy=nex_tcmr]--><div id="nex_tcmr" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_zhutisd">
                        	<ul>
                            	<li class="nex_zhutisd_one">
                                	<span>���������ֲ�<i></i></span>
                                    <div class="nex_lamamains">
                                    	<!--[diy=nex_lamamains]--><div id="nex_lamamains" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    
                                	<div class="nex_lama100">
                                    	<dl>
                                        	<!--[diy=nex_lama100]--><div id="nex_lama100" class="area"></div><!--[/diy]-->
                                        	
                                            <div class="clear"></div>
                                        </dl>
                                    </div>
                                </li>
                                <li class="nex_zhutisd_two">
                                	<h5><span>��������</span><a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a></h5>
                                    <div class="nex_zt_mom">
                                    	<!--[diy=nex_zt_mom]--><div id="nex_zt_mom" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <script type="text/javascript">
										jQuery(".nex_zt_mom").slide({ mainCell:"dl", effect:"topLoop", vis:2,autoPlay:true, delayTime:1200,interTime:3500,easing:"easeInCubic"});
									</script>
                                </li>
                                <div class="clear"></div>
                            </ul>
                        </div>
                        
                    </div>
                    <div class="nex_tercel_R">
                    	<div class="nex_side_ads">
                        	<!--[diy=nex_side_ads2]--><div id="nex_side_ads2" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <div class="nex_yyys_box">
                        	<div class="nex_tercel_toptxt">
                                <span><i>Ϊ��</i>Ű����</span>
                                <a href="http://t.cn/Aiux1Qh0" target="_blank">����+</a>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_momlists">
                            	<ul>
                                	<!--[diy=nex_momlists]--><div id="nex_momlists" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                    	<div class="nex_darings">
                        	<div class="nex_daring_top">��������</div>
                            <div class="nex_daringlists">
                            	<ul>
                                	<!--[diy=nex_daringlists]--><div id="nex_daringlists" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <!--Ʒ��ר��-->
            <div class="nex_my_brands">
            	<div class="nex_mybl">����Ʒ��</div>
                <div class="nex_mybr">
                	<!--[diy=nex_mybr]--><div id="nex_mybr" class="area"></div><!--[/diy]-->
                	
                    <a class="prev" href="javascript:void(0)"></a>
                    <a class="next" href="javascript:void(0)"></a>
                </div>
                <script type="text/javascript">
				jQuery(".nex_mybr").slide({ mainCell:"ul", effect:"leftLoop", vis:5, scroll:1, autoplay:true,  autoPage:true, switchLoad:"_src" });
				</script>
                <div class="clear"></div>
            </div>
            <!--��̳��ͼ-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_yy">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_yy"><i>��̳</i>��ͼ</span><em>/Wonderful Images</em>
                    </div>
                    <div class="nex_cbd_swrapsR">
                    	<a href="http://t.cn/Aiux1Qh0" target="_blank">����д��</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">�ȱ����</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">��������</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">��ɹ����</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">���ͱ���</a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_lt_picbox">
                	<div class="nex_lt_picboxl">
                    	<div class="nex_lt_picboxlt">
                        	<ul>
                            	<!--[diy=nex_lt_picboxlt]--><div id="nex_lt_picboxlt" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="nex_lt_picboxlb">
                        	<!--[diy=nex_lt_picboxlb]--><div id="nex_lt_picboxlb" class="area"></div><!--[/diy]-->
                        	
                        </div>
                    </div>
                    <div class="nex_lt_picboxm">
                    	<div class="nex_lt_picboxm_l">
                        	<ul>
                            	<!--[diy=nex_lt_picboxm_l]--><div id="nex_lt_picboxm_l" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="nex_lt_picboxm_r">
                        	<!--[diy=nex_lt_picboxm_r]--><div id="nex_lt_picboxm_r" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_lt_picboxr">
                    	<ul>
                        	<!--[diy=nex_lt_picboxr]--><div id="nex_lt_picboxr" class="area"></div><!--[/diy]-->
                            
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            
            <!--ĸӤ��̳-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_lt">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_lt"><i>����</i>����</span><em>/Forum Communication</em>
                    </div>
                    <div class="nex_cbd_swrapsR nex_cbd_swrapsR_lt">
                    	<a href="http://t.cn/Aiux1Qh0" target="_blank">Ȧ��</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">ͬ��Ȧ</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">ͬ��Ȧ</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">���ֻ���</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">��Դ��</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">��������Ȧ</a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_ltbox">
                	<div class="nex_ltbox_l">
                        <div class="nex_tjydbox">
                        	<div class="nex_tjydbox_top">
                            	<!--[diy=nex_tjydbox_top]--><div id="nex_tjydbox_top" class="area"></div><!--[/diy]-->
                            	
                            </div>
                            <div class="nex_tjydbox_btm">
                            	<ul>
                                	<!--[diy=nex_tjydbox_btm]--><div id="nex_tjydbox_btm" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                         <div class="nex_small_tiny_ads"><!--[diy=nex_small_tiny_ads3]--><div id="nex_small_tiny_ads3" class="area"></div><!--[/diy]--></div>
                         <div class="nex_ltbox_ltops"><span>�Ƽ��Ķ�</span></div>
                         <div class="nex_ltjxs">
                         	<i>ԭ��</i>
                            <!--[diy=nex_ltjxs]--><div id="nex_ltjxs" class="area"></div><!--[/diy]-->
                            
                            <div class="clear"></div>
                         </div>
                    </div>
                    <div class="nex_ltbox_m">
                    	<div class="nex_ltbox_mtop">
                        	<div class="nex_ltbox_mtopl">
                            	<div class="nex_lt_headerlines">
                                	<!--[diy=nex_lt_headerlines]--><div id="nex_lt_headerlines" class="area"></div><!--[/diy]-->
                                	
                                </div>
                                <div class="nex_lt_hdlists">
                                	<ul>
                                    	<!--[diy=nex_lt_hdlists]--><div id="nex_lt_hdlists" class="area"></div><!--[/diy]-->
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                                <div class="nex_lt_headerlines">
                                	<!--[diy=nex_lt_headerlines1]--><div id="nex_lt_headerlines1" class="area"></div><!--[/diy]-->
                                	
                                </div>
                                <div class="nex_lt_hdlists">
                                	<ul>
                                    	<!--[diy=nex_lt_hdlists1]--><div id="nex_lt_hdlists1" class="area"></div><!--[/diy]-->
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </div>
                            <div class="nex_ltbox_mtopr">
                            	<ul>
                                	<!--[diy=nex_mtoprpiv]--><div id="nex_mtoprpiv" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_mpo_mads"><!--[diy=nex_mpo_mads3]--><div id="nex_mpo_mads3" class="area"></div><!--[/diy]--></div>
                        <div class="nex_ltbox_mqa">
                        	<div class="nex_ltbox_mqatop">
                            	<h2>�����ʴ�</h2>
                                <div class="nex_ltbox_mqatopr"><i></i>��Ϊ<em>35623</em>λ����������</div>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_ltbox_mqamain">
                            	<div class="nex_ltbox_mqamainl">
                                	<i></i>
                                	<h5>QNA</h5>
                                    <p>�����ʴ�</p>
                                </div>
                                <div class="nex_ltbox_mqamainr">
                                	<!--[diy=nex_ltbox_mqamainr]--><div id="nex_ltbox_mqamainr" class="area"></div><!--[/diy]-->
                                	
                                </div>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_ltbox_mqabtm">
                            	<ul>
                                	<!--[diy=nex_ltbox_mqabtm]--><div id="nex_ltbox_mqabtm" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="nex_ltbox_r">
                    	<div class="nex_side_ads">
                        	<!--[diy=nex_side_ads5]--><div id="nex_side_ads5" class="area"></div><!--[/diy]-->
                        	
                        </div>
                    	<div class="nex_lt_ranklist">
                        	<div class="nex_lt_ranklisttop">
                            	<ul>
                                	<li class="cur">24Сʱ</li>
                                    <li>������</li>
                                    <li>������</li>
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_lt_ranklistbtm">
                            	<ul>
                                	<li style=" display:block;">
                                    	<div class="nex_ranklists">
                                        	<dl>
                                            	<!--[diy=nex_ranklists]--><div id="nex_ranklists" class="area"></div><!--[/diy]-->
                                            	
                                            </dl>
                                        </div>
                                    </li>
                                    <li>
                                    	<div class="nex_ranklists">
                                        	<dl>
                                            	<!--[diy=nex_ranklists2]--><div id="nex_ranklists2" class="area"></div><!--[/diy]-->
                                            	
                                            </dl>
                                        </div>
                                    </li>
                                    <li>
                                    	<div class="nex_ranklists">
                                        	<dl>
                                            	<!--[diy=nex_ranklists1]--><div id="nex_ranklists1" class="area"></div><!--[/diy]-->
                                            	
                                            </dl>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_lt_ranklisttop ul li").each(function(s){
									jQuery(this).click(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										jQuery(".nex_lt_ranklistbtm ul li").eq(s).show().siblings().hide();
										})
									})
							</script>
                        </div>
                        
                        <div class="nex_lt_hotspurs">
                        	<div class="nex_lt_hotspurstop">
                            	<span>��������</span>
                                <a href="http://t.cn/Aiux1Qh0" target="_blank">��������+</a>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_lt_hotspursbtm">
                            	<ul>
                                	<!--[diy=nex_lt_hotspursbtm]--><div id="nex_lt_hotspursbtm" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            
            <div class="nex_index_fullads">
            	<!--[diy=nex_index_fullads5]--><div id="nex_index_fullads5" class="area"></div><!--[/diy]-->
            	
            </div>
            
            <!--�ٿ�-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_bk">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_bk"><i>����</i>�ٿ�</span><em>/Encyclopedia</em>
                    </div>
                    <div class="nex_cbd_swrapsR_bk">
                    	<ul>
                        	<li class="cur">�ȴ�</li>
                            <em>|</em>
                            <li>����</li>
                            <em>|</em>
                            <li>����</li>
                            <em>|</em>
                            <li>����</li>
                            <em>|</em>
                            <li>0-1��</li>
                            <em>|</em>
                            <li>1-3��</li>
                            <em>|</em>
                            <li>3-5��</li>
                            <div class="clear"></div>
                        </ul>
                    	
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_enpy">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box]--><div id="nex_index_enpy_box" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box1]--><div id="nex_index_enpy_box1" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box2]--><div id="nex_index_enpy_box2" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box3]--><div id="nex_index_enpy_box3" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box4]--><div id="nex_index_enpy_box4" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box5]--><div id="nex_index_enpy_box5" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box6]--><div id="nex_index_enpy_box6" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nex_cbd_swrapsR_bk ul li").each(function(s){
						jQuery(this).hover(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_index_enpy ul li").eq(s).show().siblings().hide();
							})
						})
				</script>
            </div>
            <!--��������-->
            <div class="nex_common_bd">
            	<div class="nex_flink">
                	<div class="nex_flinkl">
                    	<!--[diy=nex_flinkl]--><div id="nex_flinkl" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_flinkr">
                    	<ul>
                        	<!--[diy=nex_flinkr]--><div id="nex_flinkr" class="area"></div><!--[/diy]-->
                            
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->


