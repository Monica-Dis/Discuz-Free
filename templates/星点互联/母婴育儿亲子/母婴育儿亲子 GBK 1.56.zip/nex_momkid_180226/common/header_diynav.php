<?php echo 'Copyright@DISM.TAOBAO.COM';exit;?>
<!--{block diynav}-->
		<a id="diy-tg" href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();" title="{lang open_diy}" >DIY</a>
<!--{/block}-->
