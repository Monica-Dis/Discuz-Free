<?php echo 'Copyright@DISM.TAOBAO.COM';exit;?>
<!--{template common/header}-->
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
    <!--index_main-->
    <div class="nex_portalbd">
        <div class="w1180">
            <!--分类-->
            <div class="nex_main_fl">
            	<ul>
                	<li class="nex_mfl_one">
                    	<!--[diy=nex_mfl_one]--><div id="nex_mfl_one" class="area"></div><!--[/diy]-->
                    	
                    </li>
                    <li class="nex_mfl_two">
                    	<!--[diy=nex_mfl_two]--><div id="nex_mfl_two" class="area"></div><!--[/diy]-->
                    	
                    </li>
                    <li class="nex_mfl_three">
                    	<!--[diy=nex_mfl_three]--><div id="nex_mfl_three" class="area"></div><!--[/diy]-->
                    	
                    </li>
                    <li class="nex_mfl_four">
                    	<!--[diy=nex_mfl_four]--><div id="nex_mfl_four" class="area"></div><!--[/diy]-->
                    	
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
            <!--ads-->
            <div class="nex_index_fullads">
            	<!--[diy=nex_index_fullads]--><div id="nex_index_fullads" class="area"></div><!--[/diy]-->
            	
            </div>
            <!--门户第一部分-->
            <div class="nex_mainpart_one">
            	<div class="nex_mpo_l">
                	<!--一部左侧幻灯-->
                    <div class="nex_sliderbar">
                    	<!--[diy=nex_sliderbar]--><div id="nex_sliderbar" class="area"></div><!--[/diy]-->
                    	
                        <a class="prev" href="javascript:void(0)"></a>
						<a class="next" href="javascript:void(0)"></a>
                        <ul class="hd">
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                            <li></li>
                        </ul>
                    </div>
                    <script type="text/javascript">
						jQuery(".nex_sliderbar").hover(function(){ jQuery(this).find(".prev,.next").stop(true,true).fadeTo("show",0.2) },function(){ jQuery(this).find(".prev,.next").fadeOut() });
						jQuery(".nex_sliderbar").slide({ mainCell:".pic",effect:"fold", autoPlay:true, delayTime:600, trigger:"click"});
					</script>
                    <!--小广告位-->
                    <div class="nex_small_tiny_ads"><!--[diy=nex_small_tiny_ads]--><div id="nex_small_tiny_ads" class="area"></div><!--[/diy]--></div>
                    <!--焦点关注-->
                    <div class="nex_focus_on">
                    	<div class="nex_focus_on_top">
                        	<span>焦点关注</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_focus_on_bom">
                        	<ul>
                            	<!--[diy=nex_focus_on_bom]--><div id="nex_focus_on_bom" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="nex_mpo_m">
                	<div class="nex_mpo_m_Title">
                    	<span></span><em>/TODAY'S NEWS</em><div class="clear"></div>
                    </div>
                    <!--头条资讯-->
                    <div class="nex_header_tops">
                    	<!--[diy=nex_header_tops]--><div id="nex_header_tops" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_header_topk">
                    	<!--[diy=nex_header_topk]--><div id="nex_header_topk" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <!--滚动资讯-->
                    <div class="nex_roll_zx">
                    	<div class="nex_rzxl">育儿动态<i></i></div>
                        <div class="nex_rzxr">
                        	<div class="nex_rzxfocusBox">
                            	<!--[diy=nex_rzxfocusBox]--><div id="nex_rzxfocusBox" class="area"></div><!--[/diy]-->
                                
                                <a class="prev" href="javascript:void(0)"></a>
                                <a class="next" href="javascript:void(0)"></a>
                            </div>
                        
                            <script type="text/javascript">
                                jQuery(".nex_rzxfocusBox").slide({ mainCell:".pic",effect:"left", autoPlay:true, delayTime:300});
                            </script>
                        </div>
                        <div class="clear"></div>
                    </div>
                    <!--头条列表-->
                    <div class="nex_header_lists">
                    	<ul>
                        	<!--[diy=nex_header_lists]--><div id="nex_header_lists" class="area"></div><!--[/diy]-->
                        	
                        </ul>
                    </div>
                    <!--ads-->
                    <div class="nex_mpo_mads"><!--[diy=nex_mpo_mads]--><div id="nex_mpo_mads" class="area"></div><!--[/diy]--></div>
                    <!--头条列表-->
                    <div class="nex_header_lists">
                    	<ul>
                        	<!--[diy=nex_header_lists1]--><div id="nex_header_lists1" class="area"></div><!--[/diy]-->
                        </ul>
                    </div>
                    <!--育儿专题-->
                    <div class="nex_yuer_zt">
                    	<div class="nex_yuer_zttop">
                        	<span>育儿专题</span>
                            <em>/parenting topicals</em>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">更多专题</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_yuer_ztbom">
                        	<div class="nex_yuer_ztboml">
                            	<ul>
                                	<!--[diy=nex_yuer_ztboml]--><div id="nex_yuer_ztboml" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_yuer_ztbomr">
                            	<ul>
                                	<!--[diy=nex_yuer_ztbomr]--><div id="nex_yuer_ztbomr" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    
                </div>
                <div class="nex_mpo_r">
                	<!--特别推荐-->
                    <div class="nex_sp_recomends">
                    	<div class="nex_sp_recomends_top">
                        	<span>特别推荐</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">更多&gt;</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_sp_putings">
                        	<ul>
                            	<!--[diy=nex_sp_putings]--><div id="nex_sp_putings" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                    <!--孕育小工具-->
                    <div class="nex_yunyutools">
                    	<div class="nex_yytops">孕育小工具</div>
                        <div class="nex_yy_tools">
                        	<ul>
                            	<!--[diy=nex_yy_tools]--><div id="nex_yy_tools" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </div>
                    
                    <!--亲子活动-->
                    <div class="nex_hd_box">
                    	<div class="nex_hd_box_top">
                        	<span>最新亲子活动</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">更多活动&gt;</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_hd_inerbox">
                        	<!--[diy=nex_hd_inerbox]--><div id="nex_hd_inerbox" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <script type="text/javascript">
						jQuery(".nex_hd_inerbox").slide({ mainCell:"ul", effect:"topLoop", vis:3,autoPlay:true, delayTime:1200,interTime:3500,easing:"easeInCubic"});
					</script>
                    </div>
                </div>
                <div class="clear"></div>
            </div>
            
            <!--孕育百科知识-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_yy">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_yy"><i>孕育</i>知识</span><em>/Acknowledge</em>
                    </div>
                    <div class="nex_cbd_swrapsR">
                    	<a href="http://t.cn/Aiux1Qh0" target="_blank">准备怀孕</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">怀胎十月</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">产前产后</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">新生儿</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">婴儿期</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">焦点关注</a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_cbd_mains">
                	<div class="nex_cbd_mainsL">
                    	<div class="nex_yy_part">
                        	<div class="nex_yy_bods">
                            	<div class="nex_yy_top_txt">
                                	<span><i>备孕</i>怀孕</span>
                                    <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                                    <div class="clear"></div>
                                </div>
                            	<div class="nex_yy_bom_bod">
                                	<div class="nex_yybomls">
                                    	<ul>
                                        	<!--[diy=nex_yybomls]--><div id="nex_yybomls" class="area"></div><!--[/diy]-->
                                        	
                                        </ul>
                                    </div>
                                    <div class="nex_yybomrs">
                                    	<!--[diy=nex_yybomrs]--><div id="nex_yybomrs" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            
                            </div>
                            <div class="nex_yy_bods">
                            	<div class="nex_yy_top_txt">
                                	<span><i>分娩</i>护理</span>
                                    <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                                    <div class="clear"></div>
                                </div>
                            	<div class="nex_yy_bom_bod">
                                	<div class="nex_yybomls">
                                    	<ul>
                                        	<!--[diy=nex_yybomls1]--><div id="nex_yybomls1" class="area"></div><!--[/diy]-->
                                        	
                                        </ul>
                                    </div>
                                    <div class="nex_yybomrs">
                                    	<!--[diy=nex_yybomrs1]--><div id="nex_yybomrs1" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_pointo_ads"><!--[diy=nex_pointo_ads1]--><div id="nex_pointo_ads1" class="area"></div><!--[/diy]--></div>
                        <div class="nex_yy_part">
                        	<div class="nex_yy_bods">
                            	<div class="nex_yy_top_txt">
                                	<span><i>新生儿</i>知识</span>
                                    <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                                    <div class="clear"></div>
                                </div>
                            	<div class="nex_yy_bom_bod">
                                	<div class="nex_yybomls">
                                    	<ul>
                                        	<!--[diy=nex_yybomls2]--><div id="nex_yybomls2" class="area"></div><!--[/diy]-->
                                        	
                                        </ul>
                                    </div>
                                    <div class="nex_yybomrs">
                                    	<!--[diy=nex_yybomrs2]--><div id="nex_yybomrs2" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="nex_yy_bods">
                            	<div class="nex_yy_top_txt">
                                	<span><i>婴儿期</i>百科</span>
                                    <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                                    <div class="clear"></div>
                                </div>
                            	<div class="nex_yy_bom_bod">
                                	<div class="nex_yybomls">
                                    	<ul>
                                        	<!--[diy=nex_yybomls3]--><div id="nex_yybomls3" class="area"></div><!--[/diy]-->
                                        	
                                        </ul>
                                    </div>
                                    <div class="nex_yybomrs">
                                    	<!--[diy=nex_yybomrs3]--><div id="nex_yybomrs3" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
                    <div class="nex_cbd_mainsR">
                    	<div class="nex_side_ads">
                        	<!--[diy=nex_side_ads]--><div id="nex_side_ads" class="area"></div><!--[/diy]-->
                        	
                        </div>
                    	<div class="nex_cbd_mR">
                        	<div class="nex_cbd_smtxt">
                            	<span>母婴营养<i></i></span>
                                <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_cbd_listrts">
                            	<ul>
                                	<!--[diy=nex_cbd_listrts]--><div id="nex_cbd_listrts" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                        
                        <div class="nex_cbd_mR">
                        	<div class="nex_cbd_smtxt">
                            	<span>母婴产后护理<i></i></span>
                                <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_cbd_listrts">
                            	<ul>
                                	<!--[diy=nex_cbd_listrts1]--><div id="nex_cbd_listrts1" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
                <!--标签-->
                <div class="nex_index_labels">
                    <div class="nex_index_label_leftpart">
                        <h5>育儿热门知识</h5>
                        <i></i>
                    </div>
                    <div class="nex_index_label_righttpart">
                        <div class="nex_labels_tops">
                        	<!--[diy=nex_labels_tops]--><div id="nex_labels_tops" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <div class="nex_labels_tops nex_labels_botms">
                        	<!--[diy=nex_labels_botms]--><div id="nex_labels_botms" class="area"></div><!--[/diy]-->
                        	
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <!--特色栏目-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_ts">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_ts"><i>母婴</i>特色栏目</span><em>/Special Columns</em>
                    </div>
                    <div class="nex_cbd_swrapsR nex_cbd_swrapsR_ts">
                    	<a href="http://t.cn/Aiux1Qh0" target="_blank">专家育儿访谈</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">焦点新闻</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">育儿宝典</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">育儿问答</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">母婴用品</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">圈子话题</a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_tercel">
                	<div class="nex_tercel_L">
                    	<div class="nex_tercel_toptxt">
                            <span><i>食来</i>孕转</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_foods">
                        	<ul>
                            	<!--[diy=nex_foods]--><div id="nex_foods" class="area"></div><!--[/diy]-->
                            	
                            </ul>
                        </div>
                    </div>
                    <div class="nex_tercel_M">
                    	<div class="nex_tercel_toptxt">
                            <span><i>好孕</i>学堂</span>
                            <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_tercemains">
                        	<div class="nex_tcml">
                            	<ul>
                                	<!--[diy=nex_tcml]--><div id="nex_tcml" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                            <div class="nex_tcmr">
                            	<ul>
                                	<!--[diy=nex_tcmr]--><div id="nex_tcmr" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_zhutisd">
                        	<ul>
                            	<li class="nex_zhutisd_one">
                                	<span>新妈入门手册<i></i></span>
                                    <div class="nex_lamamains">
                                    	<!--[diy=nex_lamamains]--><div id="nex_lamamains" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    
                                	<div class="nex_lama100">
                                    	<dl>
                                        	<!--[diy=nex_lama100]--><div id="nex_lama100" class="area"></div><!--[/diy]-->
                                        	
                                            <div class="clear"></div>
                                        </dl>
                                    </div>
                                </li>
                                <li class="nex_zhutisd_two">
                                	<h5><span>辣妈辣语</span><a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a></h5>
                                    <div class="nex_zt_mom">
                                    	<!--[diy=nex_zt_mom]--><div id="nex_zt_mom" class="area"></div><!--[/diy]-->
                                    	
                                    </div>
                                    <script type="text/javascript">
										jQuery(".nex_zt_mom").slide({ mainCell:"dl", effect:"topLoop", vis:2,autoPlay:true, delayTime:1200,interTime:3500,easing:"easeInCubic"});
									</script>
                                </li>
                                <div class="clear"></div>
                            </ul>
                        </div>
                        
                    </div>
                    <div class="nex_tercel_R">
                    	<div class="nex_side_ads">
                        	<!--[diy=nex_side_ads2]--><div id="nex_side_ads2" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <div class="nex_yyys_box">
                        	<div class="nex_tercel_toptxt">
                                <span><i>为娘</i>虐心事</span>
                                <a href="http://t.cn/Aiux1Qh0" target="_blank">更多+</a>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_momlists">
                            	<ul>
                                	<!--[diy=nex_momlists]--><div id="nex_momlists" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                    	<div class="nex_darings">
                        	<div class="nex_daring_top">妈妈会客厅</div>
                            <div class="nex_daringlists">
                            	<ul>
                                	<!--[diy=nex_daringlists]--><div id="nex_daringlists" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                        
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            <!--品牌专区-->
            <div class="nex_my_brands">
            	<div class="nex_mybl">合作品牌</div>
                <div class="nex_mybr">
                	<!--[diy=nex_mybr]--><div id="nex_mybr" class="area"></div><!--[/diy]-->
                	
                    <a class="prev" href="javascript:void(0)"></a>
                    <a class="next" href="javascript:void(0)"></a>
                </div>
                <script type="text/javascript">
				jQuery(".nex_mybr").slide({ mainCell:"ul", effect:"leftLoop", vis:5, scroll:1, autoplay:true,  autoPage:true, switchLoad:"_src" });
				</script>
                <div class="clear"></div>
            </div>
            <!--论坛美图-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_yy">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_yy"><i>论坛</i>美图</span><em>/Wonderful Images</em>
                    </div>
                    <div class="nex_cbd_swrapsR">
                    	<a href="http://t.cn/Aiux1Qh0" target="_blank">宝宝写真</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">萌宝天地</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">生活随拍</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">爱晒爱秀</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">加油宝宝</a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_lt_picbox">
                	<div class="nex_lt_picboxl">
                    	<div class="nex_lt_picboxlt">
                        	<ul>
                            	<!--[diy=nex_lt_picboxlt]--><div id="nex_lt_picboxlt" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="nex_lt_picboxlb">
                        	<!--[diy=nex_lt_picboxlb]--><div id="nex_lt_picboxlb" class="area"></div><!--[/diy]-->
                        	
                        </div>
                    </div>
                    <div class="nex_lt_picboxm">
                    	<div class="nex_lt_picboxm_l">
                        	<ul>
                            	<!--[diy=nex_lt_picboxm_l]--><div id="nex_lt_picboxm_l" class="area"></div><!--[/diy]-->
                            	
                                <div class="clear"></div>
                            </ul>
                        </div>
                        <div class="nex_lt_picboxm_r">
                        	<!--[diy=nex_lt_picboxm_r]--><div id="nex_lt_picboxm_r" class="area"></div><!--[/diy]-->
                        	
                        </div>
                        <div class="clear"></div>
                    </div>
                    <div class="nex_lt_picboxr">
                    	<ul>
                        	<!--[diy=nex_lt_picboxr]--><div id="nex_lt_picboxr" class="area"></div><!--[/diy]-->
                            
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            
            <!--母婴论坛-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_lt">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_lt"><i>社区</i>互动</span><em>/Forum Communication</em>
                    </div>
                    <div class="nex_cbd_swrapsR nex_cbd_swrapsR_lt">
                    	<a href="http://t.cn/Aiux1Qh0" target="_blank">圈子</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">同城圈</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">同龄圈</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">积分换礼</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">资源库</a>
                        <em>|</em>
                        <a href="http://t.cn/Aiux1Qh0" target="_blank">怀孕妈妈圈</a>
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_ltbox">
                	<div class="nex_ltbox_l">
                        <div class="nex_tjydbox">
                        	<div class="nex_tjydbox_top">
                            	<!--[diy=nex_tjydbox_top]--><div id="nex_tjydbox_top" class="area"></div><!--[/diy]-->
                            	
                            </div>
                            <div class="nex_tjydbox_btm">
                            	<ul>
                                	<!--[diy=nex_tjydbox_btm]--><div id="nex_tjydbox_btm" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                         <div class="nex_small_tiny_ads"><!--[diy=nex_small_tiny_ads3]--><div id="nex_small_tiny_ads3" class="area"></div><!--[/diy]--></div>
                         <div class="nex_ltbox_ltops"><span>推荐阅读</span></div>
                         <div class="nex_ltjxs">
                         	<i>原创</i>
                            <!--[diy=nex_ltjxs]--><div id="nex_ltjxs" class="area"></div><!--[/diy]-->
                            
                            <div class="clear"></div>
                         </div>
                    </div>
                    <div class="nex_ltbox_m">
                    	<div class="nex_ltbox_mtop">
                        	<div class="nex_ltbox_mtopl">
                            	<div class="nex_lt_headerlines">
                                	<!--[diy=nex_lt_headerlines]--><div id="nex_lt_headerlines" class="area"></div><!--[/diy]-->
                                	
                                </div>
                                <div class="nex_lt_hdlists">
                                	<ul>
                                    	<!--[diy=nex_lt_hdlists]--><div id="nex_lt_hdlists" class="area"></div><!--[/diy]-->
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                                <div class="nex_lt_headerlines">
                                	<!--[diy=nex_lt_headerlines1]--><div id="nex_lt_headerlines1" class="area"></div><!--[/diy]-->
                                	
                                </div>
                                <div class="nex_lt_hdlists">
                                	<ul>
                                    	<!--[diy=nex_lt_hdlists1]--><div id="nex_lt_hdlists1" class="area"></div><!--[/diy]-->
                                        <div class="clear"></div>
                                    </ul>
                                </div>
                            </div>
                            <div class="nex_ltbox_mtopr">
                            	<ul>
                                	<!--[diy=nex_mtoprpiv]--><div id="nex_mtoprpiv" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_mpo_mads"><!--[diy=nex_mpo_mads3]--><div id="nex_mpo_mads3" class="area"></div><!--[/diy]--></div>
                        <div class="nex_ltbox_mqa">
                        	<div class="nex_ltbox_mqatop">
                            	<h2>育儿问答</h2>
                                <div class="nex_ltbox_mqatopr"><i></i>已为<em>35623</em>位宝妈解决问题</div>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_ltbox_mqamain">
                            	<div class="nex_ltbox_mqamainl">
                                	<i></i>
                                	<h5>QNA</h5>
                                    <p>今日问答</p>
                                </div>
                                <div class="nex_ltbox_mqamainr">
                                	<!--[diy=nex_ltbox_mqamainr]--><div id="nex_ltbox_mqamainr" class="area"></div><!--[/diy]-->
                                	
                                </div>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_ltbox_mqabtm">
                            	<ul>
                                	<!--[diy=nex_ltbox_mqabtm]--><div id="nex_ltbox_mqabtm" class="area"></div><!--[/diy]-->
                                    
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="nex_ltbox_r">
                    	<div class="nex_side_ads">
                        	<!--[diy=nex_side_ads5]--><div id="nex_side_ads5" class="area"></div><!--[/diy]-->
                        	
                        </div>
                    	<div class="nex_lt_ranklist">
                        	<div class="nex_lt_ranklisttop">
                            	<ul>
                                	<li class="cur">24小时</li>
                                    <li>周排行</li>
                                    <li>月排行</li>
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_lt_ranklistbtm">
                            	<ul>
                                	<li style=" display:block;">
                                    	<div class="nex_ranklists">
                                        	<dl>
                                            	<!--[diy=nex_ranklists]--><div id="nex_ranklists" class="area"></div><!--[/diy]-->
                                            	
                                            </dl>
                                        </div>
                                    </li>
                                    <li>
                                    	<div class="nex_ranklists">
                                        	<dl>
                                            	<!--[diy=nex_ranklists2]--><div id="nex_ranklists2" class="area"></div><!--[/diy]-->
                                            	
                                            </dl>
                                        </div>
                                    </li>
                                    <li>
                                    	<div class="nex_ranklists">
                                        	<dl>
                                            	<!--[diy=nex_ranklists1]--><div id="nex_ranklists1" class="area"></div><!--[/diy]-->
                                            	
                                            </dl>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                            <script type="text/javascript">
								jQuery(".nex_lt_ranklisttop ul li").each(function(s){
									jQuery(this).click(function(){
										jQuery(this).addClass("cur").siblings().removeClass("cur");
										jQuery(".nex_lt_ranklistbtm ul li").eq(s).show().siblings().hide();
										})
									})
							</script>
                        </div>
                        
                        <div class="nex_lt_hotspurs">
                        	<div class="nex_lt_hotspurstop">
                            	<span>热门帖子</span>
                                <a href="http://t.cn/Aiux1Qh0" target="_blank">更多热帖+</a>
                                <div class="clear"></div>
                            </div>
                            <div class="nex_lt_hotspursbtm">
                            	<ul>
                                	<!--[diy=nex_lt_hotspursbtm]--><div id="nex_lt_hotspursbtm" class="area"></div><!--[/diy]-->
                                	
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
            
            <div class="nex_index_fullads">
            	<!--[diy=nex_index_fullads5]--><div id="nex_index_fullads5" class="area"></div><!--[/diy]-->
            	
            </div>
            
            <!--百科-->
            <div class="nex_common_bd">
            	<div class="nex_cbd_swraps nex_cbd_swraps_bk">
                	<div class="nex_cbd_swrapsL">
                    	<span class="nex_txt_bk"><i>亲子</i>百科</span><em>/Encyclopedia</em>
                    </div>
                    <div class="nex_cbd_swrapsR_bk">
                    	<ul>
                        	<li class="cur">热词</li>
                            <em>|</em>
                            <li>备孕</li>
                            <em>|</em>
                            <li>孕期</li>
                            <em>|</em>
                            <li>分娩</li>
                            <em>|</em>
                            <li>0-1岁</li>
                            <em>|</em>
                            <li>1-3岁</li>
                            <em>|</em>
                            <li>3-5岁</li>
                            <div class="clear"></div>
                        </ul>
                    	
                    </div>
                    <div class="clear"></div>
                </div>
                <div class="nex_index_enpy">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box]--><div id="nex_index_enpy_box" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box1]--><div id="nex_index_enpy_box1" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box2]--><div id="nex_index_enpy_box2" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box3]--><div id="nex_index_enpy_box3" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box4]--><div id="nex_index_enpy_box4" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box5]--><div id="nex_index_enpy_box5" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_index_enpy_box">
                            	<dl>
                                	<!--[diy=nex_index_enpy_box6]--><div id="nex_index_enpy_box6" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </dl>
                            </div>
                        </li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nex_cbd_swrapsR_bk ul li").each(function(s){
						jQuery(this).hover(function(){
							jQuery(this).addClass("cur").siblings().removeClass("cur");
							jQuery(".nex_index_enpy ul li").eq(s).show().siblings().hide();
							})
						})
				</script>
            </div>
            <!--友情链接-->
            <div class="nex_common_bd">
            	<div class="nex_flink">
                	<div class="nex_flinkl">
                    	<!--[diy=nex_flinkl]--><div id="nex_flinkl" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_flinkr">
                    	<ul>
                        	<!--[diy=nex_flinkr]--><div id="nex_flinkr" class="area"></div><!--[/diy]-->
                            
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

