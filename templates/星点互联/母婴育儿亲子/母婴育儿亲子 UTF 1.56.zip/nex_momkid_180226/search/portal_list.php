<?php echo 'Copyright@DISM.TAOBAO.COM';exit;?>
<!--{eval include 'template/nex_momkid_180226/php/nex_searchportal.php'}-->
<div class="tl">
	<!--{ad/search/y mtw}-->
	<!--{if empty($articlelist)}-->
		<p class="emp xg2 xs2 nex_emp_notice">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="nex_showarticles">
			<ul>
				<!--{loop $articlelist $article}-->
				<li>
                	
                    <div class="nex_search_articlebtm">
                    	<div class="nex_show_article_pics">
                            <!--{if $article[pic]}-->
                            <a href="{echo fetch_article_url($article);}" target="_blank" style="background:url($article[pic]) center no-repeat; background-size:cover;"></a>
                            <!--{else}-->
                            <a href="{echo fetch_article_url($article);}" target="_blank" style="background:url($_G['style'][styleimgdir]/search/novocer.jpg) center no-repeat; background-size:cover;"></a>
                            <!--{/if}-->
                        </div>
                    	<h5><a href="{echo fetch_article_url($article);}" target="_blank">$article[title]</a></h5>
                        
                        <div class="nex_art_sums">$article[summary]</div>
                        <div class="nex_art_fds">
                            <div class="nex_art_columns">{$nex_catids}</div>
                            <div class="nex_art_dateline">{$article[dateline]}</div>
                        	<div class="clear"></div>
                        </div>
                        <div class="nex_artbtms">
                        	<div class="nex_art_user">
                                <a href="home.php?mod=space&uid=$article[uid]" target="_blank">
                                    <img src="uc_server/avatar.php?uid=$article[uid]&size=large">
                                    <span>$article[username]</span>
                                    <div class="clear"></div>
                                </a>
                            </div>
                            <div class="nex_search_armid">
                            	<span class="nex_search_armid_l">$article[viewnum]</span>
                                <span class="nex_search_armid_r">$article[commentnum]</span>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                        
                    </div>
				</li>
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>