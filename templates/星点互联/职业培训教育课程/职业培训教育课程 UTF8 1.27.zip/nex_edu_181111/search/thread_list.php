<?php echo 'From: DisM.taobao.com';exit;?>
<div class="tl">
	<!--{ad/search/y mtw}-->
	<!--{if empty($threadlist)}-->
		<p class="emp xs2 xg2 nex_emp_notice">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="nex_showresults" id="threadlist" {if $modfid} style="position: relative;"{/if}>
			<!--{if $modfid}-->
			<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$modfid&infloat=yes&nopost=yes">
			<!--{/if}-->
			<ul>
				<!--{loop $threadlist $thread}-->
				<li id="$thread[tid]">
                	<!--{eval include 'template/nex_edu_181111/php/nex_multiops.php'}-->
                    <!--{if $nex_attachs == '0'}-->
                    <div class="nex_showpics">
                    	<a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">
                        	<img src="$_G['style'][styleimgdir]/search/nopic.jpg" />
                        </a>
                    </div>
                    <!--{else}-->
                    <!--{eval include 'template/nex_edu_181111/php/nex_multiops.php'}-->
					<!--{if $nex_threadlistspic}-->
                    <!--{loop $nex_threadlistspic $nex_threadsinpivs}-->
                    <div class="nex_showpics"><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank" style=" background:url(<!--{if $nex_threadsinpivs['remote']}-->{$_G['setting']['ftp']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
					<!--{else}-->         			
					{$_G['setting']['attachurl']}forum/{$nex_threadsinpivs[attachment]}
					<!--{/if}-->) center no-repeat; background-size:cover;"></a></div>
                    <!--{/loop}-->
					<!--{else}-->
					<div class="nex_showpics">
                    	<a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">
                        	<img src="$_G['style'][styleimgdir]/search/attachments.jpg" />
                        </a>
                    </div>
					<!--{/if}-->
                    <!--{/if}-->
                    <div class="nex_showinfos">
                        <h3><a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]" target="_blank">$thread[subject]</a></h3>
                        <div class="nex_show_forum"><span>{$nex_threadID}</span><div class="clear"></div></div>
                        <div class="nex_show_interms">
                        	<em class="nex_conbtms_view">$thread[views]</em>
                            <em class="nex_conbtms_reply">$thread[replies]</em>
                            <em class="nex_conbtms_fav">$thread[favtimes]</em>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_contgyu">
                        	<div class="nex_conbtms">
                            	<a href="home.php?mod=space&uid=$nex_authorid&do=thread&view=me&from=space" target="_blank"><!--{avatar($thread[authorid],big)}--><span>$thread[author]</span><div class="clear"></div></a>
                                <div class="nex_conbtmsrights">$thread[dateline]</div>
                                <div class="clear"></div>
                            </div>
                            <div class="clear"></div>
                        </div>
                    </div>
				</li>
				<!--{/loop}-->
                <div class="clear"></div>
			</ul>
		<!--{if $modfid}-->
			</form>
			<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
			<!--{template forum/topicadmin_modlayer}-->
		<!--{/if}-->
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
</div>
