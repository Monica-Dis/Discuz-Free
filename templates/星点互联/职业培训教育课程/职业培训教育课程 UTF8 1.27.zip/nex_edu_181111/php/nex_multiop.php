<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if ( !defined( "IN_DISCUZ" ) )
{
		exit( "Access Denied" );
}
$nex_teacher_nonetitle = '暂无职位';
$nex_teacher_noneintro = '这位讲师还没有填写个人介绍';
$nex_teacher_nonestudents = '暂无任何学员';
$nex_teacher_noneintros = '这个人很懒，什么也没有留下。';
$nex_authoridx = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$thread[tid]'")); 
$nex_grids = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$nex_authoridx'"));
$nex_online = DB::result(DB::query("SELECT msn FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_levels = DB::result(DB::query("SELECT stars FROM ".DB::table('common_usergroup')." WHERE groupid = '$nex_grids'"));
$usergroupID = DB::fetch_first("SELECT t1.*, t2.* FROM ".DB::table('common_member')." t1 LEFT JOIN ".DB::table('common_usergroup')." t2 ON t1.groupid=t2.groupid WHERE t1.uid ='$nex_authoridx'");
$nex_userid = DB::result(DB::query("SELECT uid FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_user_coins = DB::result(DB::query("SELECT extcredits2 FROM ".DB::table('common_member_count')." WHERE uid = '$nex_authoridx'"));
$nex_user_elements = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$nex_authoridx'");
$nex_intros = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_authoridx'"));
$nex_catids = DB::result(DB::query("SELECT catname FROM ".DB::table('portal_category')." WHERE catid = '$article[catid]'"));
$nex_curtid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$_G[tid]'"));
$nexgroup = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE uid = '$nex_curtid'"));
$nex_tintros = DB::result(DB::query("SELECT bio FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_curtid'"));
$nex_online = DB::result(DB::query("SELECT qq FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_curtid'"));
$nex_teacher_title = DB::result(DB::query("SELECT position FROM ".DB::table('common_member_profile')." WHERE uid = '$nex_curtid'"));

$nex_medal_list=array();
$mls=DB::query("SELECT a.*,b.* FROM ".DB::table("common_member_medal")." a LEFT JOIN ".DB::table("forum_medal")." b on b.medalid=a.medalid WHERE b.`available` <> 0 AND a.`uid`='$nex_authoridx' ORDER BY b.`displayorder` ASC LIMIT 0,20");
while ($ml=DB::fetch($mls)) {
        $nex_medal_list[]=$ml;
}
//From: Dism_taobao_com
?>
