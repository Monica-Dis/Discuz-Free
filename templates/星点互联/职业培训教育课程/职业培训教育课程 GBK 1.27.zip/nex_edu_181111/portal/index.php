<?php echo 'Copyright@Neoconex�ǵ㻥��-��Ȩ����';exit;?>
<!--{template common/header}-->
<div class="wp">
	<!--ͷ���õ�-->
    <div class="nex_fullSlide">
    	<div class="nex_slider_control">
            <div class="nex_sort_types">
            	<ul>
                	<li class="nex_sort_fl1">
                    	<div class="nex_sort_out">
                        	<div class="nex_sort_outl nex_sort_outl1"><!--[diy=nex_sort_outl1]--><div id="nex_sort_outl1" class="area"></div><!--[/diy]--></div>
                            <div class="nex_sort_outr"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_sort_in nex_sort_in1">
                        	<div class="nex_sort_intitle">ѧϰ����</div>
                            <div class="nex_sort_interms">
                            	<ul>
                                	<!--[diy=nex_sort_interms1]--><div id="nex_sort_interms1" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_sort_intitle">�Ƽ��γ�</div>
                            <div class="nex_sort_initems">
                            	<ul>
                                	<!--[diy=nex_sort_initems]--><div id="nex_sort_initems" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nex_sort_fl2">
                    	<div class="nex_sort_out">
                        	<div class="nex_sort_outl nex_sort_outl2"><!--[diy=nex_sort_outl2]--><div id="nex_sort_outl2" class="area"></div><!--[/diy]--></div>
                            <div class="nex_sort_outr"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_sort_in nex_sort_in2">
                        	<div class="nex_sort_intitle">ѧϰ����</div>
                            <div class="nex_sort_interms">
                            	<ul>
                                	<!--[diy=nex_sort_interms2]--><div id="nex_sort_interms2" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_sort_intitle">�Ƽ��γ�</div>
                            <div class="nex_sort_initems">
                            	<ul>
                                	<!--[diy=nex_sort_initems2]--><div id="nex_sort_initems2" class="area"></div><!--[/diy]-->
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nex_sort_fl3">
                    	<div class="nex_sort_out">
                        	<div class="nex_sort_outl nex_sort_outl3"><!--[diy=nex_sort_outl3]--><div id="nex_sort_outl3" class="area"></div><!--[/diy]--></div>
                            <div class="nex_sort_outr"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_sort_in nex_sort_in3">
                        	<div class="nex_sort_intitle">ѧϰ����</div>
                            <div class="nex_sort_interms">
                            	<ul>
                                	<!--[diy=nex_sort_interms3]--><div id="nex_sort_interms3" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_sort_intitle">�Ƽ��γ�</div>
                            <div class="nex_sort_initems">
                            	<ul>
                                	<!--[diy=nex_sort_initems3]--><div id="nex_sort_initems3" class="area"></div><!--[/diy]-->
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nex_sort_fl4">
                    	<div class="nex_sort_out">
                        	<div class="nex_sort_outl nex_sort_outl4"><!--[diy=nex_sort_outl4]--><div id="nex_sort_outl4" class="area"></div><!--[/diy]--></div>
                            <div class="nex_sort_outr"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_sort_in nex_sort_in4">
                        	<div class="nex_sort_intitle">ѧϰ����</div>
                            <div class="nex_sort_interms">
                            	<ul>
                                	<!--[diy=nex_sort_interms4]--><div id="nex_sort_interms4" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_sort_intitle">�Ƽ��γ�</div>
                            <div class="nex_sort_initems">
                            	<ul>
                                	<!--[diy=nex_sort_initems4]--><div id="nex_sort_initems4" class="area"></div><!--[/diy]-->
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nex_sort_fl5">
                    	<div class="nex_sort_out">
                        	<div class="nex_sort_outl nex_sort_outl5"><!--[diy=nex_sort_outl5]--><div id="nex_sort_outl5" class="area"></div><!--[/diy]--></div>
                            <div class="nex_sort_outr"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_sort_in nex_sort_in5">
                        	<div class="nex_sort_intitle">ѧϰ����</div>
                            <div class="nex_sort_interms">
                            	<ul>
                                	<!--[diy=nex_sort_interms5]--><div id="nex_sort_interms5" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_sort_intitle">�Ƽ��γ�</div>
                            <div class="nex_sort_initems">
                            	<ul>
                                	<!--[diy=nex_sort_initems5]--><div id="nex_sort_initems5" class="area"></div><!--[/diy]-->
                                    <div class="clear"></div>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="nex_sort_fl6">
                    	<div class="nex_sort_out">
                        	<div class="nex_sort_outl nex_sort_outl6"><!--[diy=nex_sort_outl6]--><div id="nex_sort_outl6" class="area"></div><!--[/diy]--><b></b></div>
                            <div class="nex_sort_outr"></div>
                            <div class="clear"></div>
                        </div>
                        <div class="nex_sort_in nex_sort_in6">
                        	<div class="nex_sort_intitle">ѧϰ����</div>
                            <div class="nex_sort_interms">
                            	<ul>
                                	<!--[diy=nex_sort_interms6]--><div id="nex_sort_interms6" class="area"></div><!--[/diy]-->
                                	
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            <div class="nex_sort_intitle">�Ƽ��γ�</div>
                            <div class="nex_sort_initems">
                            	<ul>
                                	<!--[diy=nex_sort_initems6]--><div id="nex_sort_initems6" class="area"></div><!--[/diy]-->
                                    <div class="clear"></div>
                                </ul>
                            </div>
                            
                        </div>
                    </li>
                </ul>
            </div>
        </div>
		<div class="bd">
        	<!--[diy=bd]--><div id="bd" class="area"></div><!--[/diy]-->
		</div>
		<a class="prev" href="javascript:void(0)"></a>
        <a class="next" href="javascript:void(0)"></a>
		<div class="hd"><ul></ul></div>
	</div>

	<script type="text/javascript">
		jQuery(".nex_fullSlide").slide({ titCell:".hd ul", mainCell:".bd ul", effect:"fold",  autoPlay:true, autoPage:true, trigger:"click" });
	</script>
    <!--main-->
    <!--�Զ�������-->
    <div class="nex_course_advsbox">
    	<div class="w1240">	
            <div class="nex_course_advs">
                <ul>
                	<!--[diy=nex_course_advs]--><div id="nex_course_advs" class="area"></div><!--[/diy]-->
                    
                    <div class="clear"></div>
                </ul>
            </div>
    	</div>
    </div>
    <!--ѧϰͷ��-->
    <div class="nex_course_studybox">
    	<div class="w1240">
        	<div class="nex_studybox">
            	<div class="nex_studyboxl"></div>
                <div class="nex_studyboxr">
                	<div class="nex_study_tt_cons">
                    	<!--[diy=nex_study_tt_cons]--><div id="nex_study_tt_cons" class="area"></div><!--[/diy]-->
                    	
                    </div>
                    <div class="nex_study_tt_more"><!--[diy=nex_study_tt_more]--><div id="nex_study_tt_more" class="area"></div><!--[/diy]--></div>
                    <div class="clear"></div>
                </div>
                <script type="text/javascript">
				jQuery(".nex_study_tt_cons").slide({ mainCell:".nexproul", effect:"leftLoop", vis:3, scroll:3, autoPlay:true,  autoPage:true, switchLoad:"_src" });
				</script>
                <div class="clear"></div>
            </div>
        </div>
    </div>
    <!--�γ̽���·��-->
    <div class="nex_common_indexbox">
    	<div class="w1240">
        	<div class="nex_common_index_title">
            	<!--[diy=nex_common_index_title1]--><div id="nex_common_index_title1" class="area"></div><!--[/diy]-->
            	
            </div>
            <div class="nex_common_indexcons">
            	<ul>
                	<li>
                    	<!--[diy=nex_common_indexcons1]--><div id="nex_common_indexcons1" class="area"></div><!--[/diy]-->
                    </li>
                    <li>
                    	<!--[diy=nex_common_indexcons2]--><div id="nex_common_indexcons2" class="area"></div><!--[/diy]-->
                        
                    </li>
                    <li>
                    	<!--[diy=nex_common_indexcons3]--><div id="nex_common_indexcons3" class="area"></div><!--[/diy]-->
                        
                    </li>
                    <li>
                    	<!--[diy=nex_common_indexcons4]--><div id="nex_common_indexcons4" class="area"></div><!--[/diy]-->
                        
                    </li>
                    <li>
                    	<!--[diy=nex_common_indexcons5]--><div id="nex_common_indexcons5" class="area"></div><!--[/diy]-->
                        
                    </li>
                    <li>
                    	<!--[diy=nex_common_indexcons6]--><div id="nex_common_indexcons6" class="area"></div><!--[/diy]-->
                        
                    </li>
                    <li>
                    	<!--[diy=nex_common_indexcons7]--><div id="nex_common_indexcons7" class="area"></div><!--[/diy]-->
                        
                    </li>
                    <li>
                    	<!--[diy=nex_common_indexcons8]--><div id="nex_common_indexcons8" class="area"></div><!--[/diy]-->
                        
                    </li>
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    
    <!--�γ̿�-->
    <div class="nex_common_indexbox nex_common_indexbox_pdtop">
    	<div class="w1240">
        	<div class="nex_common_index_title">
            	<!--[diy=nex_common_index_title2]--><div id="nex_common_index_title2" class="area"></div><!--[/diy]-->
            	
            </div>
    		<div class="nex_class_tab">
            	<dl>
                	<dd class="cur">��֤����</dd>
                    <dd>��ǰ��</dd>
                    <dd>��ά������</dd>
                    <dd>UI���</dd>
                    <dd>�ƶ�����</dd>
                    <dd>���鼼��</dd>
                    <div class="clear"></div>
                </dl>
            </div>
            <div class="nex_class_content">
            	<dl>
                	<dd style="display:block;">
                    	<div class="nex_Edu_box">
                        	<ul>
                            	<!--[diy=nex_Edu_box1]--><div id="nex_Edu_box1" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_Edu_box">
                        	<ul>
                            	<!--[diy=nex_Edu_box2]--><div id="nex_Edu_box2" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_Edu_box">
                        	<ul>
                            	<!--[diy=nex_Edu_box3]--><div id="nex_Edu_box3" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_Edu_box">
                        	<ul>
                            	<!--[diy=nex_Edu_box4]--><div id="nex_Edu_box4" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_Edu_box">
                        	<ul>
                            	<!--[diy=nex_Edu_box6]--><div id="nex_Edu_box6" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                    <dd>
                    	<div class="nex_Edu_box">
                        	<ul>
                            	<!--[diy=nex_Edu_box5]--><div id="nex_Edu_box5" class="area"></div><!--[/diy]-->
                                <div class="clear"></div>
                            </ul>
                        </div>
                    </dd>
                </dl>
            </div>
            <script type="text/javascript">
				jQuery(".nex_class_tab dl dd").each(function(s){
					jQuery(this).click(function(){
						jQuery(this).addClass("cur").siblings().removeClass("cur");
						jQuery(".nex_class_content dl dd").eq(s).show().siblings().hide();
						})
					})
			</script>
            <div class="nex_all_class"><!--[diy=nex_all_class1]--><div id="nex_all_class1" class="area"></div><!--[/diy]--></div>
    	</div>
    </div>
    <!--��ʦ-->
    <div class="nex_common_indexbox nex_common_teacherboxs">
    	<div class="w1240">
        	<div class="nex_common_index_title">
            	<!--[diy=nex_common_index_title3]--><div id="nex_common_index_title3" class="area"></div><!--[/diy]-->
            	
            </div>
            <div class="nex_teacherboxs">
            	<!--[diy=nex_teacherboxs]--><div id="nex_teacherboxs" class="area"></div><!--[/diy]-->
                
                <div class="nex_teacher_ids"><ul><li></li></ul></div>
            </div>
            <script type="text/javascript">
			jQuery(".nex_teacherboxs").slide({ titCell:".nex_teacher_ids ul", mainCell:".nex_teacul", effect:"leftLoop", vis:6, scroll:6, autoPlay:false,  autoPage:true, switchLoad:"_src" });
			</script>
    	</div>
    </div>
    <!--ר��γ̺���ѿγ�-->
    <div class="nex_common_indexbox">
    	<div class="w1240">
        	<div class="nex_common_index_title">
            	<!--[diy=nex_common_index_title4]--><div id="nex_common_index_title4" class="area"></div><!--[/diy]-->
            	
            </div>
            <div class="nex_subject_title">
            	<!--[diy=nex_subject_title]--><div id="nex_subject_title" class="area"></div><!--[/diy]-->
                
                <div class="clear"></div>
            </div>
            <div class="nex_free_class">
            	<ul>
                	<!--[diy=nex_free_class]--><div id="nex_free_class" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="nex_subject_title">
            	<!--[diy=nex_subject_title2]--><div id="nex_subject_title2" class="area"></div><!--[/diy]-->
                
                <div class="clear"></div>
            </div>
            <div class="nex_free_course">
            	<a class="prev" href="javascript:void(0)"></a>
        		<a class="next" href="javascript:void(0)"></a>
                <!--[diy=nex_free_course]--><div id="nex_free_course" class="area"></div><!--[/diy]-->
            	
            </div>
            <script type="text/javascript">
			jQuery(".nex_free_course").slide({ mainCell:".nex_freecul", effect:"leftLoop", vis:4, scroll:1, autoPlay:true,  autoPage:true, switchLoad:"_src" });
			</script>
            <div class="nex_index_ads"><!--[diy=nex_index_ads1]--><div id="nex_index_ads1" class="area"></div><!--[/diy]--></div>
    	</div>
    </div>
    
    
    <!--�����ʴ�����-->
    <div class="nex_common_indexbox nex_common_indexbox_dark">
    	<div class="w1240">
        	<div class="nex_bbs_aera">
                <div class="nex_bbs_aera_tops">
                    <span>���ŷ���</span>
                    <ul>
                        <li class="curs">24h����</li>
                        <li>�����ʴ�<i class="nex_icon_qna"></i></li>
                        <li>�μ�����<i class="nex_icon_dws"></i></li>
                        <div class="clear"></div>
                    </ul>
                    <div class="clear"></div>
                </div>
                <div class="nex_bbs_aerabox">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_bbs_listing">
                            	<dl>
                                	<!--[diy=nex_bbs_listing13]--><div id="nex_bbs_listing13" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_bbs_listing">
                            	<dl>
                                	<!--[diy=nex_bbs_listing22]--><div id="nex_bbs_listing22" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_bbs_listing">
                            	<dl>
                                	<!--[diy=nex_bbs_listing34]--><div id="nex_bbs_listing34" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nex_bbs_aera_tops ul li").each(function(s){
						jQuery(this).click(function(){
							jQuery(this).addClass("curs").siblings().removeClass("curs");
							jQuery(".nex_bbs_aerabox ul li").eq(s).show().siblings().hide();
							})
						})
				</script>
                <div class="nex_bbs_serial_tops">
                    <span>�γ�ָ��</span>
                    <a href="http://t.cn/Aiux1012" target="_blank">����</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_class_guides">
                	<ul>
                    	<!--[diy=nex_class_guides]--><div id="nex_class_guides" class="area"></div><!--[/diy]-->
                    	
                        <div class="clear"></div>
                    </ul>
                </div>

            </div>
            <div class="nex_hot_arts">
            	<div class="nex_hot_arts_tops">
                    <span>�¿�Ԥ��</span>
                    <a href="http://t.cn/Aiux1012" target="_blank">����</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_roll_intels">
                	<ul>
                    	<!--[diy=nex_roll_intels1]--><div id="nex_roll_intels1" class="area"></div><!--[/diy]-->
                    	
                    </ul>
                </div>
            </div>
            <div class="clear"></div>
                
        </div>
    </div>
    
    <!--�̳̣���������-->
    <div class="nex_common_indexbox">
    	<div class="w1240">
        	<div class="nex_arts_aera">
                <div class="nex_arts_aera_tops">
                    <span>�Ƽ��̳�</span>
                    <ul>
                        <li class="curs">�����Ķ�</li>
                        <li>ͼ�Ľ̳�</li>
                        <li>��������</li>
                        <div class="clear"></div>
                    </ul>
                    <div class="clear"></div>
                </div>
                <div class="nex_arts_aerabox">
                	<ul>
                    	<li style="display:block;">
                        	<div class="nex_jcbox">
                            	<dl>
                                	<!--[diy=nex_roll_intels122]--><div id="nex_roll_intels122" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_jcbox">
                            	<dl>
                                	<!--[diy=nex_roll_intels123]--><div id="nex_roll_intels123" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </li>
                        <li>
                        	<div class="nex_jcbox">
                            	<dl>
                                	<!--[diy=nex_roll_intels124]--><div id="nex_roll_intels124" class="area"></div><!--[/diy]-->
                                	
                                </dl>
                            </div>
                        </li>
                    </ul>
                </div>
                <script type="text/javascript">
					jQuery(".nex_arts_aera_tops ul li").each(function(s){
						jQuery(this).click(function(){
							jQuery(this).addClass("curs").siblings().removeClass("curs");
							jQuery(".nex_arts_aerabox ul li").eq(s).show().siblings().hide();
							})
						})
				</script>
                <div class="nex_loadingmore"><!--[diy=nex_loadingmore3]--><div id="nex_loadingmore3" class="area"></div><!--[/diy]--></div>

            </div>
            <div class="nex_arts_sd">
            	<div class="nex_hot_arts_tops nex_ranklist_tops">
                    <span>���ſγ�����</span>
                    <a href="http://t.cn/Aiux1012" target="_blank">����</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_class_ranklistings">
                	<ul>
                    	<!--[diy=nex_class_ranklistings]--><div id="nex_class_ranklistings" class="area"></div><!--[/diy]-->
                    	
                    </ul>
                </div>
            	<script type="text/javascript">
					jQuery(".nex_class_ranklistings ul li").each(function(s){
						jQuery(this).hover(function(){
							jQuery(this).addClass("ons").siblings().removeClass("ons");
							})
						})
				</script>
            
            
                <div class="nex_hot_arts_tops nex_selected_tops">
                    <span>��ѡ�γ�</span>
                    <a href="http://t.cn/Aiux1012" target="_blank">����</a>
                    <div class="clear"></div>
                </div>
                <div class="nex_hot_classes">
                	<ul>
                    	<!--[diy=nex_hot_classes]--><div id="nex_hot_classes" class="area"></div><!--[/diy]-->
                    	
                    </ul>
                </div>
            </div>
            <div class="clear"></div>
            <div class="nex_index_ads"><!--[diy=nex_index_ads2]--><div id="nex_index_ads2" class="area"></div><!--[/diy]--></div>
        </div>
    </div>
    <!--ѧԱ��̸-->
    <div class="nex_common_indexbox nex_common_indexbox_dark">
    	<div class="w1240">
        	<div class="nex_common_index_title">
            	<!--[diy=nex_common_index_title8]--><div id="nex_common_index_title8" class="area"></div><!--[/diy]-->
            	
            </div>
            <div class="nex_talkmain">
                <div class="nex_talkmain_title"><span>�ɹ�����</span><div class="clear"></div></div>
                <div class="nex_talk_roll">
                    <!--[diy=nex_talk_roll]--><div id="nex_talk_roll" class="area"></div><!--[/diy]-->
                    
                </div>
                <script type="text/javascript">
					jQuery(".nex_talk_roll").slide({ mainCell:"dl", effect:"topLoop", vis:3,autoPlay:true, delayTime:1200,interTime:3500,easing:"easeInCubic"});
				</script>
            </div>
            <div class="nex_talkbox">
            	<ul>
                    <!--[diy=nex_talk_roll2]--><div id="nex_talk_roll2" class="area"></div><!--[/diy]-->
                    
                    <div class="clear"></div>
                </ul>
            </div>
            <div class="clear"></div>
        </div>
    </div>
    <!--������ҵ-->
    <div class="nex_common_indexbox">
    	<div class="w1240">
        	<div class="nex_common_index_title">
            	<!--[diy=nex_common_index_title9]--><div id="nex_common_index_title9" class="area"></div><!--[/diy]-->
            	
            </div>
            <div class="nex_common_coorprition">
            	<ul>
                	<!--[diy=nex_common_coorprition]--><div id="nex_common_coorprition" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    
    <!--�˽����-->
    <div class="nex_learn_more">
    	<div class="w1240">
        	<div class="nex_common_index_title nex_common_index_title_white">
            	<!--[diy=nex_common_index_title11]--><div id="nex_common_index_title11" class="area"></div><!--[/diy]-->
            	
            </div>
            <div class="nex_learn_more_btn">
            	<!--[diy=nex_learn_more_btn2]--><div id="nex_learn_more_btn2" class="area"></div><!--[/diy]-->
            	
            </div>
            <div class="nex_why_us">
            	<ul>
                	<!--[diy=nex_why_us]--><div id="nex_why_us" class="area"></div><!--[/diy]-->
                	
                    <div class="clear"></div>
                </ul>
            </div>
        </div>
    </div>
    
</div>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->

