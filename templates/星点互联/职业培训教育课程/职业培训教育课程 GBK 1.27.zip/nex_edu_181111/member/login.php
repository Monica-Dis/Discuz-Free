<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="template/nex_edu_181111/neoconex/dl/login.css">
<!--{eval $loginhash = 'L'.random(4);}-->
    <!--{if empty($_GET['infloat'])}-->
    <div id="ct" class="ptm wp w cl">
        <div class="nex_Mainbod">
            <div class="mn nex_zhucekuangbox" id="main_message">
                <div class="nex_denglu_bgs"></div>
                <div class="bmx nex_denglu_side">
                    <!--{hook/logging_side_top}-->
                <div>
                <div class="clear"></div>
    <!--{else}-->
    <!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}-->
       <div class="nex_mask_bg"></div>
    <!--{/if}-->
<!--{/if}-->
    
    <div class="nex_denglu_box" id="main_messaqge_$loginhash"{if $auth} style="width: auto"{/if}>
        <div id="layer_login_$loginhash">
            <h3 class="flb nex_dlzc_txt" {if !empty($_GET['infloat']) && !isset($_GET['frommessage']) && !$auth}style=" margin-bottom: 22px; text-align: center;"{/if}>
				<em id="returnmessage_$loginhash">
                    �û���¼
                </em>
                <!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}--><span><a href="javascript:;" class="flbc" onclick="hideWindow('$_GET[handlekey]', 0, 1);" title="{lang close}">{lang close}</a></span><!--{/if}-->
            </h3>
            
            <!--{hook/logging_top}-->
            <form method="post" autocomplete="off" name="login" id="loginform_$loginhash" class="cl" onsubmit="{if $this->setting['pwdsafety']}pwmd5('password3_$loginhash');{/if}pwdclear = 1;ajaxpost('loginform_$loginhash', 'returnmessage_$loginhash', 'returnmessage_$loginhash', 'onerror');return false;" action="member.php?mod=logging&action=login&loginsubmit=yes{if !empty($_GET['handlekey'])}&handlekey=$_GET[handlekey]{/if}{if isset($_GET['frommessage'])}&frommessage{/if}&loginhash=$loginhash">
                <div class="c cl">
                    <input type="hidden" name="formhash" value="{FORMHASH}" />
                    <input type="hidden" name="referer" value="{echo dreferer()}" />
                    <!--{if $auth}-->
                        <input type="hidden" name="auth" value="$auth" />
                    <!--{/if}-->
                    
                    <!--{if $invite}-->
                    <div class="nex_liner_box">
                        <table>
                            <tr>
                                <th>{lang register_from}</th>
                                <td><a href="home.php?mod=space&uid=$invite[uid]" target="_blank">$invite[username]</a></td>
                            </tr>
                        </table>
                    </div>
                    <!--{/if}-->
    
                    <!--{if !$auth}-->
                    <div class="nex_liner_box">
                        <input type="text" placeholder="{lang username}/{lang uid}/{lang email}" name="username" id="username_$loginhash" autocomplete="off" size="30" class="log-input" tabindex="1" value="$username" />
                    </div>
                    <div class="nex_liner_box">
                        <input type="password" placeholder="{lang login_password}" id="password3_$loginhash" name="password" onfocus="clearpwd()" size="30" class="px p_fre" tabindex="1" />
                    </div>
                    <!--{/if}-->
    
                    <!--{if empty($_GET['auth']) || $questionexist}-->
                    <div class="nex_liner_box">
                            <select id="loginquestionid_$loginhash" name="questionid"{if !$questionexist} onchange="if($('loginquestionid_$loginhash').value > 0) {$('loginanswer_row_$loginhash').style.display='';} else {$('loginanswer_row_$loginhash').style.display='none';}"<!--{/if}-->>
                                <option value="0"><!--{if $questionexist}-->{lang security_question_0}<!--{else}-->{lang security_question}<!--{/if}--></option>
                                <option value="1">{lang security_question_1}</option>
                                <option value="2">{lang security_question_2}</option>
                                <option value="3">{lang security_question_3}</option>
                                <option value="4">{lang security_question_4}</option>
                                <option value="5">{lang security_question_5}</option>
                                <option value="6">{lang security_question_6}</option>
                                <option value="7">{lang security_question_7}</option>
                            </select>
                    </div>
                    <div class="nex_liner_box" id="loginanswer_row_$loginhash" {if !$questionexist} style="display:none"{/if}>
                          <input type="text"  placeholder="�������" name="answer" id="loginanswer_$loginhash" autocomplete="off" size="30" class="px p_fre" tabindex="1" />
                    </div>
                    <!--{/if}-->
    
                    <!--{if $seccodecheck}-->
					<!--{block sectpl}--><div class="nex_liner_box nex_liner_box_valides"><table><tr><th {if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}style=" display: none;"{else}style=" display: none;"{/if}><sec>: </th><td><sec><br /><sec></td></tr></table></div><!--{/block}-->
					<!--{subtemplate common/seccheck}-->
				<!--{/if}-->
    
                    <!--{hook/logging_input}-->
    				<div class="nex_dl_columns">
                    	<div class="nex_dl_columns_l"><input type="checkbox" class="pc" name="cookietime" id="cookietime_$loginhash" tabindex="1" value="2592000" $cookietimecheck />{lang login_permanent}</div>
                        <div class="nex_dl_columns_r">
                        	<a href="javascript:;" onclick="showWindow('login', 'member.php?mod=logging&action=login&viewlostpw=1')">{lang getpassword}</a><span class="pipe">|</span>{lang login_guest}</span>
                        </div>
                        <div class="clear"></div>
                    	
                    </div>
    
                    <div class="nex_liner_box mbw bw0">
                        <button class="pn pnc" type="submit" name="loginsubmit" value="true" tabindex="1"><strong>{lang login}</strong></button>
                        <!--{if $this->setting['sitemessage'][login] && empty($_GET['infloat'])}--><a href="javascript:;" id="custominfo_login_$loginhash" class="y">&nbsp;<img src="{IMGDIR}/info_small.gif" alt="{lang faq}" class="vm" /></a><!--{/if}-->
                    </div>
    				<div class="nexbdthirdpart"><i class="nex_linelefts"></i><span>�������˺ŵ�½</span><i class="nex_linerights"></i></div>
                    <div class="nexbdthirdlogin">
                    	<ul>
                            <li class="nex_tl_qq"><a href="connect.php?mod=login&amp;op=init&amp;referer=forum.php&amp;statfrom=login" title="qq��½"></a></li>
                            <li class="nex_tl_wx"><a href="plugin.php?id=wechat:login" title="΢�ŵ�½"></a></li>
                            <li class="nex_tl_wb"><a href="#" title="΢����½"></a></li>
                            <div class="clear"></div>
                        </ul>
                    </div>
                    <!--{if !empty($_G['setting']['pluginhooks']['logging_method'])}-->
                        <div class="nex_liner_box bw0 {if empty($_GET['infloat'])} mbw{/if}">
                            <hr class="l" />
                            <table>
                                <tr>
                                    <th>{lang login_method}:</th>
                                    <td><!--{hook/logging_method}--></td>
                                </tr>
                            </table>
                        </div>
                    <!--{/if}-->
                </div>
            </form>
        </div>
        <!--{if $_G['setting']['pwdsafety']}-->
            <script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
        <!--{/if}-->
        <div id="layer_lostpw_$loginhash" style="display: none;">
            <h3 class="flb nex_dlzc_txt">
                <em id="returnmessage3_$loginhash">{lang getpassword}</em>
                <span><!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}--><a href="javascript:;" class="flbc" onclick="hideWindow('login')" title="{lang close}">{lang close}</a><!--{/if}--></span>
            </h3>
            <form method="post" autocomplete="off" id="lostpwform_$loginhash" class="cl" onsubmit="ajaxpost('lostpwform_$loginhash', 'returnmessage3_$loginhash', 'returnmessage3_$loginhash', 'onerror');return false;" action="member.php?mod=lostpasswd&lostpwsubmit=yes&infloat=yes">
                <div class="c cl">
                    <input type="hidden" name="formhash" value="{FORMHASH}" />
                    <input type="hidden" name="handlekey" value="lostpwform" />
                    <div class="nex_liner_box">
                         <input type="text" placeholder="*{lang email}" name="email" id="lostpw_email" size="30" value=""  tabindex="1" class="px p_fre" />
                    </div>
                    <div class="nex_liner_box">
                          <input type="text" placeholder="{lang username}" name="username" id="lostpw_username" size="30" value=""  tabindex="1" class="px p_fre" />
                    </div>
                    <div class="nex_liner_box mbw bw0">
                    	<button class="pn pnc" type="submit" name="lostpwsubmit" value="true" tabindex="100"><span>{lang submit}</span></button>
                    </div>
                    <div class="nex_third_loginfunc">
                        <h5>��������¼</h5>
                        <ul>
                            <li class="nex_tl_qq"><a href="connect.php?mod=login&amp;op=init&amp;referer=forum.php&amp;statfrom=login"></a></li>
                            <li class="nex_tl_wx"><a href="plugin.php?id=wechat:login"></a></li>
                            <li class="nex_tl_wb"><a href="javasrcipt;;"></a></li>
                            <div class="clear"></div>
                        </ul>
                        <div class="clear"></div>
                    </div>
                </div>
            </form>
        </div>
    </div>
    
    <div id="layer_message_$loginhash"{if empty($_GET['infloat'])} class="f_c blr nfl"{/if} style="display: none;">
        <h3 class="flb" id="layer_header_$loginhash">
            <!--{if !empty($_GET['infloat']) && !isset($_GET['frommessage'])}-->
            <em>{lang login_member}</em>
            <span><a href="javascript:;" class="flbc" onclick="hideWindow('login')" title="{lang close}">{lang close}</a></span>
            <!--{/if}-->
        </h3>
        <div class="c"><div class="alert_right">
            <div id="messageleft_$loginhash"></div>
            <p class="alert_btnleft" id="messageright_$loginhash"></p>
        </div>
    </div>
    
    <script type="text/javascript" reload="1">
    <!--{if !isset($_GET['viewlostpw'])}-->
        var pwdclear = 0;
        function initinput_login() {
            document.body.focus();
            <!--{if !$auth}-->
                if($('loginform_$loginhash')) {
                    $('loginform_$loginhash').username.focus();
                }
                <!--{if !$this->setting['autoidselect']}-->
                    simulateSelect('loginfield_$loginhash');
                <!--{/if}-->
            <!--{elseif $seccodecheck && !(empty($_GET['auth']) || $questionexist)}-->
                if($('loginform_$loginhash')) {
                    safescript('seccodefocus', function() {$('loginform_$loginhash').seccodeverify.focus()}, 500, 10);
                }			
            <!--{/if}-->
        }
        initinput_login();
        <!--{if $this->setting['sitemessage']['login']}-->
        showPrompt('custominfo_login_$loginhash', 'mouseover', '<!--{echo trim($this->setting['sitemessage'][login][array_rand($this->setting['sitemessage'][login])])}-->', $this->setting['sitemessage'][time]);
        <!--{/if}-->
    
        function clearpwd() {
            if(pwdclear) {
                $('password3_$loginhash').value = '';
            }
            pwdclear = 0;
        }
    <!--{else}-->
        display('layer_login_$loginhash');
        display('layer_lostpw_$loginhash');
        $('lostpw_email').focus();
    <!--{/if}-->
    </script>
    
    <!--{eval updatesession();}-->
    <!--{if empty($_GET['infloat'])}-->
        </div></div></div></div>
        
    </div>
</div>

<!--{/if}-->
<!--{template common/footer}-->