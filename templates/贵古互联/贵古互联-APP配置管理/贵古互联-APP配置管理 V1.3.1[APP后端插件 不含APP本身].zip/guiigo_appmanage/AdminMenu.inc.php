<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include_once libfile('class/AppCommon', 'plugin/guiigo_appmanage');
$config = AppCommon::config();
$setting = C::t('common_setting')->fetch_all(array('guiigo_appmanage'));
$setting = (array) unserialize($setting['guiigo_appmanage']);
$basicurl = 'plugins&operation=config&do=' . $_GET['do'] . '&identifier=guiigo_appmanage&pmod=' . $_GET['pmod'];
if (!submitcheck('settingsubmit')) {
	showtips(lang('plugin/guiigo_appmanage', 'slang_10015'));
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_appmanage', 'slang_10016'), 'nobottom');
	showsubtitle(array(lang('plugin/guiigo_appmanage', 'slang_10008'), lang('plugin/guiigo_appmanage', 'slang_10009'), lang('plugin/guiigo_appmanage', 'slang_10010'), lang('plugin/guiigo_appmanage', 'slang_10011'), lang('plugin/guiigo_appmanage', 'slang_10012'), lang('plugin/guiigo_appmanage', 'slang_10013'), lang('plugin/guiigo_appmanage', 'slang_10014')), 'header', array('class="td21"'));
	$global_menu = menu_array_merge($setting['bottom_menu_config']);
	foreach ($global_menu as $key => $value) {
		$checked1 = $checked2 = '';
		if ($value['global_menu_open']) {
			$checked1 = 'checked';
		}
		if ($value['global_menu_custom']) {
			$checked2 = 'checked';
		}
		if ($value['global_menu_mark'] == 'portal') {
			showtablerow('', array('class="td21"', 'class="td21"', 'class="td21"', 'class="rowform"', 'class="rowform"', 'class="td25"'), array('<input type="text" class="txt" name="settingnew[global_menu_sort][' . $key . ']" value="' . $value['global_menu_sort'] . '" ' . $isreadonly . '/>', '<input type="text" class="txt" name="settingnew[global_menu_mark][' . $key . ']" value="' . $value['global_menu_mark'] . '" readonly/>', '<input type="text" class="txt" name="settingnew[global_menu_name][' . $key . ']" value="' . $value['global_menu_name'] . '" ' . $isreadonly . '/>', lang('plugin/guiigo_appmanage', 'slang_10017'), lang('plugin/guiigo_appmanage', 'slang_10017'), '<input type="hidden" class="txt" name="settingnew[global_menu_open][' . $key . ']" value="1" />', '<input type="hidden" class="txt" name="settingnew[global_menu_custom][' . $key . ']" value="0" />' . '<input type="hidden" name="settingnew[global_menu_tmb][' . $key . ']" value="' . $value['global_menu_tmb'] . '" />'));
		} else {
			showtablerow('', array('class="td21"', 'class="td21"', 'class="td21"', 'class="rowform"', 'class="rowform"', 'class="td25"'), array('<input type="text" class="txt" name="settingnew[global_menu_sort][' . $key . ']" value="' . $value['global_menu_sort'] . '" ' . $isreadonly . '/>', '<input type="text" class="txt" name="settingnew[global_menu_mark][' . $key . ']" value="' . $value['global_menu_mark'] . '" readonly/>', '<input type="text" class="txt" name="settingnew[global_menu_name][' . $key . ']" value="' . $value['global_menu_name'] . '" ' . $isreadonly . '/>', '<input type="text" class="txt" name="settingnew[global_menu_icon][' . $key . ']" value="' . $value['global_menu_icon'] . '" ' . $isreadonly . '/>', '<input type="text" class="txt" name="settingnew[global_menu_link][' . $key . ']" value="' . $value['global_menu_link'] . '" ' . $isreadonly . '/>', '<input type="checkbox" class="txt" name="settingnew[global_menu_open][' . $key . ']" value="1" ' . $checked1 . ' ' . $disabled . '/>', '<input type="checkbox" class="txt" name="settingnew[global_menu_custom][' . $key . ']" value="1" ' . $checked2 . ' ' . $disabled . '/>' . '<input type="hidden" name="settingnew[global_menu_tmb][' . $key . ']" value="' . $value['global_menu_tmb'] . '" />'));
		}
	}
	showtablefooter();/*Dism��taobao��com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism_taobao_com*/
} else {
	$newdata = array();
	foreach ($_POST['settingnew']['global_menu_mark'] as $key => $val) {
		$newdata[$key]['global_menu_sort'] = $_POST['settingnew']['global_menu_sort'][$key];
		$newdata[$key]['global_menu_mark'] = $_POST['settingnew']['global_menu_mark'][$key];
		$newdata[$key]['global_menu_tmb'] = $_POST['settingnew']['global_menu_tmb'][$key];
		$newdata[$key]['global_menu_name'] = $_POST['settingnew']['global_menu_name'][$key];
		$newdata[$key]['global_menu_icon'] = $_POST['settingnew']['global_menu_icon'][$key];
		$newdata[$key]['global_menu_link'] = $_POST['settingnew']['global_menu_link'][$key];
		$newdata[$key]['global_menu_open'] = !empty($_POST['settingnew']['global_menu_open'][$key]) ? 1 : 0;
		$newdata[$key]['global_menu_custom'] = $_POST['settingnew']['global_menu_custom'][$key];
	}
	array_multisort(array_column($newdata, 'global_menu_sort'), SORT_ASC, $newdata);
	$setting['bottom_menu_config'] = $newdata;
	C::t('common_setting')->update_batch(array('guiigo_appmanage' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
function menu_array_merge($ary)
{
	if ($ary) {
		return $ary;
	}
	return array(array('global_menu_name' => lang('plugin/guiigo_appmanage', 'slang0113'), 'global_menu_mark' => 'portal', 'global_menu_tmb' => 'sy', 'global_menu_icon' => '', 'global_menu_link' => '', 'global_menu_open' => 1, 'global_menu_custom' => 0, 'global_menu_sort' => 1), array('global_menu_name' => lang('plugin/guiigo_appmanage', 'slang0114'), 'global_menu_mark' => 'forum', 'global_menu_tmb' => 'sq', 'global_menu_icon' => '', 'global_menu_link' => '', 'global_menu_open' => 1, 'global_menu_custom' => 0, 'global_menu_sort' => 2), array('global_menu_name' => lang('plugin/guiigo_appmanage', 'slang0115'), 'global_menu_mark' => 'group', 'global_menu_tmb' => 'qz', 'global_menu_icon' => '', 'global_menu_link' => '', 'global_menu_open' => 1, 'global_menu_custom' => 0, 'global_menu_sort' => 3), array('global_menu_name' => lang('plugin/guiigo_appmanage', 'slang0116'), 'global_menu_mark' => 'newmsg', 'global_menu_tmb' => 'xx', 'global_menu_icon' => '', 'global_menu_link' => '', 'global_menu_open' => 1, 'global_menu_custom' => 0, 'global_menu_sort' => 4), array('global_menu_name' => lang('plugin/guiigo_appmanage', 'slang0117'), 'global_menu_mark' => 'home', 'global_menu_tmb' => 'wd', 'global_menu_icon' => '', 'global_menu_link' => '', 'global_menu_open' => 1, 'global_menu_custom' => 0, 'global_menu_sort' => 5));
}