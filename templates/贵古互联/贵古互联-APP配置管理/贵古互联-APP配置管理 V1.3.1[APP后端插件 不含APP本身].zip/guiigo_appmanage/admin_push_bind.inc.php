<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!class_exists('AppCommon')){	include_once libfile('class/AppCommon','plugin/guiigo_appmanage');}

$config = AppCommon::config();

if(submitcheck('submit')){
	$post = daddslashes($_POST);
	
	$data = array();
	$data['push_appid'] = $post['push_appid'];
	$data['push_appkey'] = $post['push_appkey'];
	$data['push_master_secret'] = $post['push_master_secret'];
    $data['iosAppid'] = $post['iosAppid'];
    $data['androidAppid'] = $post['androidAppid'];
	$data['appid'] = $post['appid'];
	$data['p_order'] = $post['p_order'];

	$url = 'http://push.gzqtjr.com/source/plugin/qst_application/index.php/push.serverBind';
	$sign = md5('url=push.serverBind&version=V1.0&time=' .date('Y-m-d', TIMESTAMP) . '&domain=push.gzqtjr.com');
	$reqData = array(
		'sign' => $sign,
		'data' => $data
	);
	$res = dfsockopen($url, 0,$reqData);
	$res = json_decode($res, true);
	if($res['type'] == 'succeed' && $res['data']){
		AppCommon::savecache('guiigo_appmanage_push',$res['data']);
	}
	if('gbk' == strtolower(CHARSET)){
	   $res = mb_convert_encoding($res,'gbk' ,'utf-8');
	}
	cpmsg($res['msg'],'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_appmanage&pmod='.$_GET['pmod'],'succeed');
	
}else{

	$resData = AppCommon::savecache('guiigo_appmanage_push');
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=guiigo_appmanage&pmod='.$_GET['pmod']);
	if($resData){
		showtableheader(lang('plugin/guiigo_appmanage', 'slang_10123'));
		showsetting(lang('plugin/guiigo_appmanage', 'slang_10124'),'', $resData['token'],'text');
		showsetting(lang('plugin/guiigo_appmanage', 'slang_10146'),'', $resData['appid'],'text');
		showsetting(lang('plugin/guiigo_appmanage', 'slang_10125'),'', $resData['iosid'],'text');
		showsetting(lang('plugin/guiigo_appmanage', 'slang_10126'),'', $resData['androidid'],'text');
		showsetting(lang('plugin/guiigo_appmanage', 'slang_10127'),'', dgmdate($resData['expire_datelin'],'Y-m-d h:i:s'),'text');
	}

	showtableheader(lang('plugin/guiigo_appmanage', 'slang_10128'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang_10145'), 'appid', '', 'text');
	showsetting(lang('plugin/guiigo_appmanage', 'slang_10129'), 'iosAppid', '', 'text');
	showsetting(lang('plugin/guiigo_appmanage', 'slang_10130'), 'androidAppid', '', 'text');
	showsetting(lang('plugin/guiigo_appmanage', 'slang_10131'), 'push_appid', '', 'text');
	showsetting(lang('plugin/guiigo_appmanage', 'slang_10132'), 'push_appkey', '', 'text');
	showsetting(lang('plugin/guiigo_appmanage', 'slang_10133'), 'push_master_secret', '', 'text');
    showsetting(lang('plugin/guiigo_appmanage', 'slang_10134'), 'p_order', '', 'text');

	showsubmit('submit',lang('plugin/guiigo_appmanage', 'slang_10135'));
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism_taobao_com*/
	
}

