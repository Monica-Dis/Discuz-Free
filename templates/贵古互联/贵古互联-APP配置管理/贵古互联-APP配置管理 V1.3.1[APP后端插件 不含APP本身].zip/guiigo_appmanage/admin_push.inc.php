<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if(!class_exists('AppCommon')){	include_once libfile('class/AppCommon','plugin/guiigo_appmanage');}

$config = AppCommon::config();

function apiPushSend($data){
	$url = 'http://push.gzqtjr.com/source/plugin/qst_application/index.php/push.appPushSend';
	$sign = md5('url=push.appPushSend&version=V1.0&time=' .date('Y-m-d', TIMESTAMP) . '&domain=push.gzqtjr.com');
	$reqData = array(
		'sign' => $sign,
		'data' => $data
	);
	$res = dfsockopen($url, 0,$reqData);
	return json_decode($res, true);
}

function submitPushSend($post,$where){
    global $pluginid;
	$resData = AppCommon::savecache('guiigo_appmanage_push');
	if(empty($resData)){
		cpmsg(lang('plugin/guiigo_appmanage', 'slang_10104'),'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_appmanage&pmod='.$_GET['pmod']);
	}
	$countpage = 0;
	$size = 50;
	$page = 1;
	$retData = array();
	$count = C::t('#guiigo_appmanage#guiigo_appmanage_userbind_push')->count();
	if($count==0){
		cpmsg(lang('plugin/guiigo_appmanage', 'slang_10105'),'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_appmanage&pmod='.$_GET['pmod']);
	}

	if($count > 50){
		$countpage = ceil($count / 50);
		for($i=0; $i<$countpage; $i++){
			$start = ($page-1)*$size;
			$ret = C::t('#guiigo_appmanage#guiigo_appmanage_userbind_push')->fetch_all($start, $size, $where);
			$retData[$i] = $ret;
			$page++;
		}
	}else{
		$retData[0] = C::t('#guiigo_appmanage#guiigo_appmanage_userbind_push')->fetch_all(0, $size, $where);
	}

	if('gbk' == strtolower(CHARSET)){
	   $post = mb_convert_encoding($post,'utf-8','gbk');
	}
	
	$title = $post['title'];
	$content = $post['content'];
	$customPush = $post['customPush'];
	$payload = array(
		'title' => $title,
		'msg' => $content,
		'id' => 'Pushid',
		'type' => 'appPush',
		'urltype' => '',
		'url' => $post['url']
	);

	if($url == '/pages/forum/forum' || $url == '/pages/group/group' || $url == '/pages/notice/notice' || $url == '/pages/index/index' || $url == '/pages/home/home'){
		$payload['urltype'] = 'tab';
	}else if(strexists($url,'pages/') !== FALSE){
		$payload['urltype'] = 'nto';
	}else if($post['url']){
		$payload['urltype'] = 'web';
	}

	$pushData = array(
		'pushtoken' => $resData['token'],
		'pushData' => array(
			'title' => $title,
			'content' => $content,
			'customPush' => $customPush,
			'payload' => $payload,
			'cid' => array(),
			'package' => ''
		)
	);

	$retPush = array();
	foreach($retData as $key => $val){
		$iosCids = array();
		$androidCids = array();
		$iospackage = '';
		$androidpackage = '';
		foreach($val as $v){
			if($v['t_client_type'] == 'ios'){
				$iosCids[] = $v['t_cid'];
				$iospackage = $resData['iosid'];
			}else if($v['t_client_type'] == 'android'){
				$androidCids[] = $v['t_cid'];
				$androidpackage = $resData['androidid'];
			}
		}

		if($iosCids && $iospackage){
			$pushData['pushData']['cid'] = $iosCids;
			$pushData['pushData']['package'] = $iospackage;
			$retPush = apiPushSend($pushData);
		}
		if($androidCids && $androidpackage){
			$pushData['pushData']['cid'] = $androidCids;
			$pushData['pushData']['package'] = $androidpackage;
			$retPush = apiPushSend($pushData);
		}
		sleep(1);
	}
	return $retPush;
}

if(submitcheck('submit')){
	
	$post = daddslashes($_POST);
	$senduser = $post[$post['senduser']];
	if(!$post['title']){
		cpmsg(lang('plugin/guiigo_appmanage', 'slang_10106'),'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_appmanage&pmod='.$_GET['pmod']);
	}
	if(!$post['content']){
		cpmsg(lang('plugin/guiigo_appmanage', 'slang_10107'),'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_appmanage&pmod='.$_GET['pmod']);
	}

    $where = array();
	if($post['senduser'] == 'alluser'){

	}else if($post['senduser'] == 'uids'){
		$uids = $senduser;
		if(strexists($senduser,',') !== FALSE){
			$uids = explode(",",$senduser);
		}
		$where['uids'] = $uids;
	}else if($post['senduser'] == 'groupids'){
		$where['groupids'] = $senduser;
	}
	submitPushSend($post,$where);

	cpmsg(lang('plugin/guiigo_appmanage', 'slang_10108'),'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_appmanage&pmod='.$_GET['pmod'],'succeed');
	
}else{
	
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=guiigo_appmanage&pmod='.$_GET['pmod']);
	showtableheader(lang('plugin/guiigo_appmanage', 'slang_10109'), 'nobottom');
		showsetting(lang('plugin/guiigo_appmanage', 'slang_10110'), array('senduser', array(
				array(
					'alluser', 
					lang('plugin/guiigo_appmanage', 'slang_10111'), 
					array(
						'alluser' => '',
						'uid' => 'none',
						'groupid' => 'none'
					)
				),
				array(
					'uids',
					lang('plugin/guiigo_appmanage', 'slang_10112'), 
					array(
						'alluser' => 'none',
						'uid' => '',
						'groupid' => 'none'
					)
				),
				array(
					'groupids',
					lang('plugin/guiigo_appmanage', 'slang_10113'), 
					array(
						'alluser' => 'none',
						'uid' => 'none',
						'groupid' => ''
					)
				)
			)),'alluser', 'mradio2');
	
			showtagheader('tbody', 'alluser','', 'sub');
			showtagfooter('tbody');
			showtagheader('tbody', 'uid', '', 'sub');
				showsetting(lang('plugin/guiigo_appmanage', 'slang_10112'), 'uids', '', 'text', '', '',lang('plugin/guiigo_appmanage', 'slang_10114'));
			showtagfooter('tbody');
	
			showtagheader('tbody', 'groupid','', 'sub');
	             showsetting(lang('plugin/guiigo_appmanage', 'slang_10115'), 'groupids', '', '<select name="groupids[]" multiple="multiple" size="10">'.AppCommon::get_group_selected().'</select>');
			showtagfooter('tbody');
	
		 showsetting(lang('plugin/guiigo_appmanage', 'slang_10116'), 'title', '', 'text', '', '',lang('plugin/guiigo_appmanage', 'slang_10117'));
		 showsetting(lang('plugin/guiigo_appmanage', 'slang_10118'), 'content', '', 'textarea', '', '',lang('plugin/guiigo_appmanage', 'slang_10119'));
		 showsetting(lang('plugin/guiigo_appmanage', 'slang_10120'), 'url', '', 'text', '', '',lang('plugin/guiigo_appmanage', 'slang_10121'));
		 showsetting(lang('plugin/guiigo_appmanage', 'slang_10122'), 'customPush','1', 'radio');
	
	showsubmit('submit','submit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism_taobao_com*/
}

