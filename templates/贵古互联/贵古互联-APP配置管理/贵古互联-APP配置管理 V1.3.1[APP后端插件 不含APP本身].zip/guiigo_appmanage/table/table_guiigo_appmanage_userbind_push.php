<?php

/**
 * author: laoyang
 * description: 
 * @param 
 * @return 
 * @createTime: 2020-10-5 01:37:53
 */

if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}

class table_guiigo_appmanage_userbind_push extends discuz_table{
	
    public function __construct() {
        $this->_table = 'guiigo_appmanage_userbind_push';
		
        $this->_pk = 't_id';
		$this->_pre_cache_key = 'guiigo_appmanage_userbind_push_';
		$this->_cache_ttl = 3600;
		
        parent::__construct();
    }
	
	public function fetch_by_uid($uid,$client_type) {
		$user = array();
		if(!empty($uid)) {
			$user = $this->fetch_cache($uid);
			if($user === false) {
				$user = DB::fetch_first('SELECT * FROM %t WHERE t_uid=%d AND t_client_type=%s ', array($this->_table, $client_type));
				if(!empty($user)) $this->store_cache($uid, $user);
			}
		}
		return $user;
	}
	
	public function fetch_by_cid($cid) {
		$user = array();
		if(!empty($cid)) {
			$user = $this->fetch_cache($cid);
			if($user === false) {
				$user = DB::fetch_first('SELECT * FROM %t WHERE t_cid=%s ', array($this->_table, $cid));
				if(!empty($user)) $this->store_cache($cid, $user);
			}
		}
		return $user;
	}
 
    public function count($where = array()){
        $sql = "SELECT count(*) FROM %t WHERE 1";
        $condition[] = $this->_table;
		if(isset($where['t_uid'])){
		    $sql .=" AND t_uid=%d ";
		    $condition[] = $where['t_uid'];
		}
		if(isset($where['t_cid'])){
		    $sql .=" AND t_cid=%s ";
		    $condition[] = $where['t_cid'];
		}
		if(isset($where['t_groupid'])){
		    $sql .=" AND t_groupid=%d ";
		    $condition[] = $where['t_groupid'];
		}
		
		if(isset($where['uids']) && is_array($where['uids'])){
		    $sql .=" AND t_uid IN (%i) ";
		    $condition[] = implode(',',$where['uids']);
		}else if(isset($where['uids'])){
			$sql .=" AND t_uid=%d ";
			$condition[] = $where['uids'];
		}
		
		if(isset($where['groupids']) && is_array($where['groupids'])){
			$sql .=" AND t_groupid IN (%i) ";
		    $condition[] = implode(',',$where['groupids']);
		}

        return (int)DB::result_first($sql,$condition);
    }

	public function fetch_all($start, $size, $where = array(),$key = false){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if(isset($where['t_uid'])){
		    $sql .=" AND t_uid=%d ";
		    $condition[] = $where['t_uid'];
		}
		if(isset($where['t_cid'])){
		    $sql .=" AND t_cid=%s ";
		    $condition[] = $where['t_cid'];
		}
		if(isset($where['t_groupid'])){
		    $sql .=" AND t_groupid=%d ";
		    $condition[] = $where['t_groupid'];
		}
		
		if(isset($where['uids']) && is_array($where['uids'])){
		    $sql .=" AND t_uid IN (%i) ";
		    $condition[] = implode(',',$where['uids']);
		}else if(isset($where['uids'])){
			$sql .=" AND t_uid=%d ";
			$condition[] = $where['uids'];
		}
		
		if(isset($where['groupids']) && is_array($where['groupids'])){
			$sql .=" AND t_groupid IN (%i) ";
		    $condition[] = implode(',',$where['groupids']);
		}
		
		$sql .= " ORDER BY t_dateline DESC LIMIT %d,%d ";
		$condition[] = $start;
		$condition[] = $size;
		return DB::fetch_all($sql,$condition, $key ? $key :'');
	}
	
	public function fetch_first($where){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if(isset($where['t_id'])){     
            $sql .=" AND t_id=%d ";
            $condition[] = $where['t_id'];
        }
		if(isset($where['t_uid'])){
		    $sql .=" AND t_uid=%d ";
		    $condition[] = $where['t_uid'];
		}
		if(isset($where['t_cid'])){
		    $sql .=" AND t_cid=%s ";
		    $condition[] = $where['t_cid'];
		}
		if(isset($where['t_groupid'])){
		    $sql .=" AND t_groupid=%d ";
		    $condition[] = $where['t_groupid'];
		}
		return DB::fetch_first($sql,$condition);
	}
	
    public function insert($data){
		if(empty($data)) {
			return false;
		}
        return DB::insert($this->_table,$data,true);
    }
	
    public function update($data,$condition){
		if(empty($data) || empty($condition)) {
			return false;
		}
		if($condition['t_uid']){
			$this->update_cache($condition['t_uid'], $data, $this->_cache_ttl, $this->_pre_cache_key);
		}
		if($condition['t_cid']){
			$this->update_cache($condition['t_cid'], $data, $this->_cache_ttl, $this->_pre_cache_key);
		}
        return DB::update($this->_table,$data,$condition,true);
    }
	
    public function delete($condition){
		if(empty($condition)) {
			return false;
		}
		if($condition['t_uid']){
			$this->clear_cache($condition['t_uid'], $this->_pre_cache_key);
		}
		if($condition['t_cid']){
			$this->clear_cache($condition['t_cid'], $this->_pre_cache_key);
		}
		return DB::delete($this->_table, $condition);
    }

}
