<?php
//cronname:guiigo_appmanage
//available:1
//week:
//day:
//hour:
//minute:00,10,20,30,40,50,60

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

	if(!class_exists('AppCommon')){		include_once libfile('class/AppCommon','plugin/guiigo_appmanage');	}

	$config = AppCommon::config();

	$pushType = dunserialize($config['pushType']);
	$resData = AppCommon::savecache('guiigo_appmanage_push');
	if($config['openPush'] && !empty($pushType) && $resData['token']){

		$dateline = TIMESTAMP - (86400*30);
		$sql = ' t.new=1 ';
		$sql .= ' AND t.dateline > '.intval($dateline);
		$sql .= ' AND m.t_uid >0';
		$sql .= ' AND t.'.DB::field('category', $pushType);
		$sql .= ' ORDER BY m.t_id DESC '.DB::limit(0,1000);
		$data = DB::fetch_all('SELECT m.*,t.* FROM %t m LEFT JOIN %t t on m.t_uid=t.uid WHERE %i ',array('guiigo_appmanage_userbind_push','home_notification',$sql));
		
		$lang = array(
			1 => lang('plugin/guiigo_appmanage', 'slang_10136'),
			2 => lang('plugin/guiigo_appmanage', 'slang_10137'),
			3 => lang('plugin/guiigo_appmanage', 'slang_10138'),
			4 => lang('plugin/guiigo_appmanage', 'slang_10139'),
			6 => lang('plugin/guiigo_appmanage', 'slang_10140')
		);
		$newdata = array();
		foreach($data as $v) {
			if($v['type'] == 'poke'){
				continue;
			}
			$v['note'] = preg_replace_callback("/<\s*a\s+[^>]*?href\s*=\s*(\'|\")(.*?)\\1[^>]*?\/?\s*>\s*(.*?)\s*<\/a>/is", 'parsenote', $v['note']);
			$v['url'] = '';
			if(preg_match_all("/\{{(.*?)\}}/is", $v['note'], $mat)){
				$v['url'] = $mat[1][0];
				if(strexists($v['url'],'http') === false){
					$v['url'] = $_G['siteurl'].$v['url'];
				}
				$v['note'] = preg_replace("/\{{(.*?)\}}/is","",$v['note']);
			}

			$v['note'] = preg_replace(array("/\t/","/\r\n/","/\r/","/\n/","/ /","/  /"),array("","","","","",""),$v['note']);
			$v['note'] = preg_replace('/\&nbsp;/', '', $v['note']);
			$v['note'] = cutstr(strip_tags($v['note']),65,'...');
			
			$v['title'] = $lang[$v['category']] ? $lang[$v['category']] : lang('plugin/guiigo_appmanage', 'slang_10141');
			$v['title'] = $v['title'];
			$v['content'] = $v['note'];
			if('gbk' == strtolower(CHARSET)){
			   $v['title'] = mb_convert_encoding($v['title'],'utf-8','gbk');
			   $v['content'] = mb_convert_encoding($v['note'],'utf-8','gbk');
			}
			$payload = array(
				'title' => $v['title'],
				'msg' => $v['content'],
				'id' => $v['id'],
				'type' => $v['type'],
				'urltype' => 'web',
				'url' => $v['url'],
			);
			$v['customPush'] = $v['url'] ? 1 : '';
			$v['payload'] = $payload;
			$v['cid'] = $v['t_cid'];
			$v['package'] = '';
			if($v['t_client_type'] == 'ios'){
				$v['package'] = $resData['iosid'];
			}else if($v['t_client_type'] == 'android'){
				$v['package'] = $resData['androidid'];
			}
			$newdata[] = $v;
		}

		$pushData = array(
			'pushtoken' => $resData['token'],
			'pushData' => array()
		);

		$ids = array();
		foreach($newdata as $key => $val){
		    $ids[] = $val['id'];
			$pushData['pushData'] = array(
				'title' => $val['title'],
				'content' => $val['content'],
				'customPush' => $val['customPush'],
				'payload' => $val['payload'],
				'cid' => $val['cid'],
				'package' => $val['package']
			);
			autoApiPushSend($pushData);
			sleep(1);
		}
		if($ids && is_array($ids)){
			foreach($ids as $vid) {
				DB::query('UPDATE %t SET new=0 WHERE id=%d', array('home_notification', $vid));
			}
		}
	}
	
function autoApiPushSend($data){
	$url = 'http://push.gzqtjr.com/source/plugin/qst_application/index.php/push.appPushSend';
	$sign = md5('url=push.appPushSend&version=V1.0&time=' .date('Y-m-d', TIMESTAMP) . '&domain=push.gzqtjr.com');
	$reqData = array(
		'sign' => $sign,
		'data' => $data
	);
	$res = dfsockopen($url, 0,$reqData);
	return json_decode($res, true);
}

function parsenote($m){
	$str = $m[3];
	if(strpos($m[3],lang('plugin/guiigo_appmanage', 'slang_10142')) !== false || strpos($m[3], lang('plugin/guiigo_appmanage', 'slang_10143')) !== false || strpos($m[3], lang('plugin/guiigo_appmanage', 'slang_10144')) !== false){	
		$str = '{{'.$m[2].'}}';
	}
	return $str;
}
