<?phpif(!defined('IN_DISCUZ')) {	exit('Access Denied');}
function _dzcutstr($string, $length = 100, $dot = '...') {
	$GLOBALS['miles'] = array();
	$string = preg_replace_callback(array("/\s?\{miles}(.+?)\{\/miles\}\s?/is"), function($p){
		array_push($GLOBALS['miles'],$p[0]);
		return '['.count($GLOBALS['miles']).']';
	},$string);
	$string = cutstr($string, $length, $dot);
	$string = preg_replace_callback(array("/\s?\[(.+?)\]\s?/is"), function($p){
		if($p[1]){
			return $GLOBALS['miles'][$p[1]-1];
		}else{
			return '';
		}
	},$string);
	return $string;
}