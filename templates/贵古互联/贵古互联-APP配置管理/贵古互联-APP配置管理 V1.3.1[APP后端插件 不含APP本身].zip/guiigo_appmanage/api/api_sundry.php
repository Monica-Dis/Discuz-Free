<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($_GET['act'] == 'setTplStyle') {
	$style = daddslashes($_GET['style']);
	$op = daddslashes($_GET['op']);
	if (!$_G['uid']) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0139');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($style)) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0139');
		AppCommon::RetMsgJson($msgarr);
	}
	require_once libfile('function/cache');
	$setting = AppCommon::getGuiigoManageSetting();
	if ($setting) {
		$userstyle = array();
		$newstyle = array();
		$newstyle[$_G['uid']] = $style;
		if ($op == 'tpl') {
			$setting['usertplstyle'] = $newstyle;
			$userstyle['usertplstyle'] = $style;
			$userstyle['userHstyle'] = $setting['userHstyle'][$_G['uid']];
		} else {
			$setting['userHstyle'] = $newstyle;
			$userstyle['usertplstyle'] = $setting['usertplstyle'][$_G['uid']];
			$userstyle['userHstyle'] = $style;
		}
		C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
		updatecache('setting');
		$msgarr['code'] = 1;
		$msgarr['data'] = $userstyle;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0140');
	} else {
		$msgarr['code'] = 0 - 3;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10083');
	}
	AppCommon::RetMsgJson($msgarr);
} elseif ($_GET['act'] == 'getHomeVisitLog') {
	if (!$_G['uid']) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0139');
		AppCommon::RetMsgJson($msgarr);
	}
	$udata = array();
	foreach (AppCommon::GetVisitorByUid($_G['uid'], 0, $config['tpldata']['userconfig']['show_visitorhead']) as $key => $val) {
		$udata[$key] = $val;
		$udata[$key]['avatar'] = avatar($val['uid'], 'big', true);
	}
	$msgarr['code'] = 1;
	$msgarr['data'] = $udata;
	$msgarr['msg'] = 'ok';
	AppCommon::RetMsgJson($msgarr);
} elseif ($_GET['act'] == 'report') {
	if (!$_G['uid']) {
		$msgarr['code'] = 1001;
		$msgarr['msg'] = '';
		AppCommon::RetMsgJson($msgarr);
	}
	$rtype = $_GET['rtype'];
	$rid = intval($_GET['rid']);
	$tid = intval($_GET['tid']);
	$fid = intval($_GET['fid']);
	$uid = intval($_GET['uid']);
	$default_url = array('user' => 'home.php?mod=space&uid=', 'post' => 'forum.php?mod=redirect&goto=findpost&ptid=' . $tid . '&pid=', 'thread' => 'forum.php?mod=viewthread&tid=', 'group' => 'forum.php?mod=group&fid=', 'album' => 'home.php?mod=space&do=album&uid=' . $uid . '&id=', 'blog' => 'home.php?mod=space&do=blog&uid=' . $uid . '&id=', 'pic' => 'home.php?mod=space&do=album&uid=' . $uid . '&picid=');
	$url = '';
	if ($rid && !empty($default_url[$rtype])) {
		$url = $default_url[$rtype] . intval($rid);
	} else {
		$url = addslashes(dhtmlspecialchars(base64_decode($_GET['url'])));
		$url = preg_match('/^http[s]?:\\/\\/[^\\["\']+$/i', trim($url)) ? trim($url) : '';
	}
	if (empty($url)) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0139');
		AppCommon::RetMsgJson($msgarr);
	}
	$urlkey = md5($url);
	$message = censor(cutstr(dhtmlspecialchars(trim($_GET['message'])), 200, ''));
	$message = $_G['username'] . '&nbsp;:&nbsp;' . rtrim($message, '\\');
	if ($reportid = C::t('common_report')->fetch_by_urlkey($urlkey)) {
		C::t('common_report')->update_num($reportid, $message);
	} else {
		$data = array('url' => $url, 'urlkey' => $urlkey, 'uid' => $_G['uid'], 'username' => $_G['username'], 'message' => $message, 'dateline' => TIMESTAMP);
		if ($fid) {
			$data['fid'] = $fid;
		}
		C::t('common_report')->insert($data);
		$report_receive = unserialize($_G['setting']['report_receive']);
		$moderators = array();
		if ($report_receive['adminuser']) {
			foreach ($report_receive['adminuser'] as $touid) {
				notification_add($touid, 'report', 'new_report', array('from_id' => 1, 'from_idtype' => 'newreport'), 1);
			}
		}
		if ($fid && $rtype == 'post') {
			foreach (C::t('forum_moderator')->fetch_all_by_fid($fid, false) as $row) {
				$moderators[] = $row['uid'];
			}
			if ($report_receive['supmoderator']) {
				$moderators = array_unique(array_merge($moderators, $report_receive['supmoderator']));
			}
			foreach ($moderators as $touid) {
				!($touid == $_G['uid']) && !in_array($touid, $report_receive) && notification_add($touid, 'report', 'new_post_report', array('fid' => $fid, 'from_id' => 1, 'from_idtype' => 'newreport'), 1);
			}
		}
	}
	$msgarr['code'] = 1;
	$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10084');
	AppCommon::RetMsgJson($msgarr);
}