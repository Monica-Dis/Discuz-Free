<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require './source/function/function_forum.php';
$_GET['archiver'] = '';
$_G['setting']['archiverredirect'] = false;
loadforum();
require_once libfile('function/group');
$actionarray = array('join', 'out');
$action = $_GET['action'] && in_array($_GET['action'], $actionarray) ? $_GET['action'] : 'error';
if ($action == 'error') {
	$msgarr['code'] = 1002;
	$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0001');
	AppCommon::RetMsgJson($msgarr);
}
if (in_array($action, array('join', 'out'))) {
	if (empty($_G['uid'])) {
		$msgarr['code'] = 1001;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0138');
		AppCommon::RetMsgJson($msgarr);
	}
}
if (empty($_GET['fid'])) {
	$msgarr['code'] = 0 - 1;
	$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0001');
	AppCommon::RetMsgJson($msgarr);
}
if ($_G['fid']) {
	if ($_G['forum']['status'] != 3) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10085');
		AppCommon::RetMsgJson($msgarr);
	} else {
		if ($_G['forum']['level'] == 0 - 1) {
			$msgarr['code'] = 0 - 3;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10086');
			AppCommon::RetMsgJson($msgarr);
		} else {
			if ($_G['forum']['jointype'] < 0 && !$_G['forum']['ismoderator']) {
				$msgarr['code'] = 0 - 4;
				$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10087');
				AppCommon::RetMsgJson($msgarr);
			}
		}
	}
	$groupuser = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $_G['fid']);
	$groupmanagers = $_G['forum']['moderators'];
}
if (in_array($action, array('out'))) {
	$status = groupperm($_G['forum'], $_G['uid'], $action, $groupuser);
	if ($status == 0 - 1) {
		$msgarr['code'] = 0 - 5;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10085');
		AppCommon::RetMsgJson($msgarr);
	} elseif ($status == 1) {
		$msgarr['code'] = 0 - 6;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10087');
		AppCommon::RetMsgJson($msgarr);
	}
	if ($status == 2) {
		$msgarr['code'] = 0 - 7;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10088');
		AppCommon::RetMsgJson($msgarr);
	} elseif ($status == 3) {
		$msgarr['code'] = 0 - 8;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10089');
		AppCommon::RetMsgJson($msgarr);
	}
}
if ($action == 'join') {
	$inviteuid = 0;
	$membermaximum = $_G['current_grouplevel']['specialswitch']['membermaximum'];
	if (!empty($membermaximum)) {
		$curnum = C::t('forum_groupuser')->fetch_count_by_fid($_G['fid']);
		if ($curnum >= $membermaximum) {
			$msgarr['code'] = 0 - 9;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10090') . $membermaximum . lang('plugin/guiigo_appmanage', 'slang_10091');
			AppCommon::RetMsgJson($msgarr);
		}
	}
	if ($groupuser['uid']) {
		$msgarr['code'] = 0 - 10;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10092');
		AppCommon::RetMsgJson($msgarr);
	} else {
		$modmember = 4;
		$msgarr['code'] = 1;
		$msgarr['data'] = array('fid' => $_G['fid']);
		$showmessage = lang('plugin/guiigo_appmanage', 'slang_10093');
		$confirmjoin = true;
		$inviteuid = C::t('forum_groupinvite')->fetch_uid_by_inviteuid($_G['fid'], $_G['uid']);
		if ($_G['forum']['jointype'] == 1) {
			if (!$inviteuid) {
				$confirmjoin = false;
				$msgarr['code'] = 0 - 11;
				$showmessage = lang('plugin/guiigo_appmanage', 'slang_10094');
			}
		} elseif ($_G['forum']['jointype'] == 2) {
			$modmember = !empty($groupmanagers[$inviteuid]) || $_G['adminid'] == 1 ? 4 : 0;
			if (!empty($groupmanagers[$inviteuid])) {
				$msgarr['code'] = 1;
				$showmessage = lang('plugin/guiigo_appmanage', 'slang_10095');
			}
		}
		if ($confirmjoin) {
			C::t('forum_groupuser')->insert($_G['fid'], $_G['uid'], $_G['username'], $modmember, TIMESTAMP, TIMESTAMP);
			if ($_G['forum']['jointype'] == 2 && (empty($inviteuid) || empty($groupmanagers[$inviteuid]))) {
				foreach ($groupmanagers as $manage) {
					notification_add($manage['uid'], 'group', 'group_member_join', array('fid' => $_G['fid'], 'groupname' => $_G['forum']['name'], 'url' => $_G['siteurl'] . 'forum.php?mod=group&action=manage&op=checkuser&fid=' . $_G['fid']), 1);
				}
			}
			if ($inviteuid) {
				C::t('forum_groupinvite')->delete_by_inviteuid($_G['fid'], $_G['uid']);
			}
			if ($modmember == 4) {
				C::t('forum_forumfield')->update_membernum($_G['fid']);
			}
			C::t('forum_forumfield')->update($_G['fid'], array('lastupdate' => TIMESTAMP));
		}
		include_once libfile('function/stat');
		updatestat('groupjoin');
		delgroupcache($_G['fid'], array('activityuser', 'newuserlist'));
		$msgarr['msg'] = $showmessage;
		AppCommon::RetMsgJson($msgarr);
	}
} elseif ($action == 'out') {
	if ($_G['uid'] == $_G['forum']['founderuid']) {
		$msgarr['code'] = 0 - 12;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10096');
		AppCommon::RetMsgJson($msgarr);
	}
	C::t('forum_groupuser')->delete_by_fid($_G['fid'], $_G['uid']);
	C::t('forum_forumfield')->update_membernum($_G['fid'], 0 - 1);
	update_groupmoderators($_G['fid']);
	delgroupcache($_G['fid'], array('activityuser', 'newuserlist'));
	$msgarr['code'] = 1;
	$msgarr['data'] = array('fid' => $_G['fid']);
	$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10097');
	AppCommon::RetMsgJson($msgarr);
}