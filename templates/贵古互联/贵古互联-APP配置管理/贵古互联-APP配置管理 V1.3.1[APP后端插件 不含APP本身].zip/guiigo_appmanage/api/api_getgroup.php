<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!class_exists('Group')) {
	include_once libfile('class/Group', 'plugin/guiigo_appmanage');
}
if (!isset($_G['cache']['grouptype'])) {
	loadcache('grouptype');
}
if ($_GET['act'] == 'getGroupAnv') {
	$first = $_G['cache']['grouptype']['first'];
	$second = $_G['cache']['grouptype']['second'];
	$_group_recommend = $_G['setting']['group_recommend'] ? dunserialize($_G['setting']['group_recommend']) : array();
	$group_recommend = array();
	foreach ($_group_recommend as $rfid => $recommend) {
		$group_recommend[$rfid] = $recommend;
		$group_recommend[$rfid]['icon'] = $_G['siteurl'] . $recommend['icon'];
		$group_recommend[$rfid]['pageurl'] = $_G['siteurl'] . 'forum.php?mod=forumdisplay&action=list&fid=' . $rfid;
	}
	$firstanv = array();
	foreach ($first as $firstv) {
		$firstanv[] = $firstv;
	}
	array_unshift($firstanv, array('fid' => 0, 'fup' => 0, 'name' => lang('plugin/guiigo_appmanage', 'slang_10050')));
	$msgarr['code'] = 1;
	$msgarr['data'] = array('deffirst' => $first, 'first' => $firstanv, 'second' => $second, 'recommend' => $group_recommend);
	$msgarr['msg'] = 'ok';
	AppCommon::RetMsgJson($msgarr);
} elseif ($_GET['act'] == 'getGroupList') {
	$gid = intval($_GET['gid']);
	$orderby = in_array($_GET['orderby'], array('membernum', 'dateline', 'thread', 'activity')) ? $_GET['orderby'] : 'displayorder';
	$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
	$groupids = array();
	$first = $_G['cache']['grouptype']['first'];
	if ($first[$gid]['secondlist']) {
		$groupids = $first[$gid]['secondlist'];
	}
	$list = array();
	$perpage = 10;
	$page = $page > 65535 ? 1 : $page;
	if ($groupids) {
		$start = ($page - 1) * $perpage;
		$getcount = Group::grouplist('', '', '', $groupids, 1, 1);
		if ($getcount) {
			$list = Group::grouplist($orderby, '', array($start, $perpage), $groupids, 1);
		}
	} else {
		if ($page <= 1) {
			$list = Group::grouplist('activity', '', 10);
			$getcount = count($list);
		}
	}
	$msgarr['code'] = 1;
	$msgarr['data'] = array('count' => $getcount, 'perpage' => $perpage, 'page' => $page, 'list' => $list);
	$msgarr['msg'] = 'ok';
	AppCommon::RetMsgJson($msgarr);
}