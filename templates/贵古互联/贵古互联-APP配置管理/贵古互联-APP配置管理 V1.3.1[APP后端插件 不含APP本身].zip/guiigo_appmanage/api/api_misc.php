<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($_GET['action'] == 'recommend') {
	$_G['tid'] = $tid = dintval($_GET['tid']);
	if (empty($_G['uid'])) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0138');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($tid)) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0001');
		AppCommon::RetMsgJson($msgarr);
	}
	$thread = C::t('forum_thread')->fetch($tid);
	if (!$_G['setting']['recommendthread']['status'] || !$_G['group']['allowrecommend']) {
		$msgarr['code'] = 0 - 3;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10074');
		AppCommon::RetMsgJson($msgarr);
	}
	if (!$thread) {
		$msgarr['code'] = 0 - 4;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10075');
		AppCommon::RetMsgJson($msgarr);
	}
	if ($thread['authorid'] == $_G['uid'] && !$_G['setting']['recommendthread']['ownthread']) {
		$msgarr['code'] = 0 - 5;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10076');
		AppCommon::RetMsgJson($msgarr);
	}
	if (C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $tid) && $_GET['do'] == 'add') {
		$msgarr['code'] = 0 - 6;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10077');
		AppCommon::RetMsgJson($msgarr);
	}
	$recommendcount = C::t('forum_memberrecommend')->count_by_recommenduid_dateline($_G['uid'], $_G['timestamp'] - 86400);
	if ($_G['setting']['recommendthread']['daycount'] && $recommendcount >= $_G['setting']['recommendthread']['daycount'] && $_GET['do'] == 'add') {
		$msgarr['code'] = 0 - 6;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10078');
		AppCommon::RetMsgJson($msgarr);
	}
	$_G['group']['allowrecommend'] = intval($_GET['do'] == 'add' ? $_G['group']['allowrecommend'] : 0 - $_G['group']['allowrecommend']);
	$fieldarr = array();
	if ($_GET['do'] == 'add') {
		$fieldarr['recommend_add'] = 1;
	} else {
		$fieldarr['recommend_add'] = 0 - 1;
	}
	_update_threadpartake($_G['tid'], $_GET['do']);
	$fieldarr['heats'] = 0;
	$fieldarr['recommends'] = $_G['group']['allowrecommend'];
	C::t('forum_thread')->increase($_G['tid'], $fieldarr);
	if (empty($thread['closed'])) {
		C::t('forum_thread')->update($_G['tid'], array('lastpost' => TIMESTAMP));
	}
	$msgtext = lang('plugin/guiigo_appmanage', 'slang_10073');
	if ($_GET['do'] == 'add') {
		C::t('forum_memberrecommend')->insert(array('tid' => $_G['tid'], 'recommenduid' => $_G['uid'], 'dateline' => $_G['timestamp']));
	} elseif ($_GET['do'] == 'del') {
		DB::delete('forum_memberrecommend', array('tid' => $_G['tid'], 'recommenduid' => $_G['uid']));
		$msgtext = lang('plugin/guiigo_appmanage', 'slang_10072');
	}
	$recommendv = $_G['group']['allowrecommend'];
	if ($_G['setting']['recommendthread']['daycount'] && $_GET['do'] == 'add') {
		$daycount = $_G['setting']['recommendthread']['daycount'] - $recommendcount;
		$msgarr['data'] = array('recommendv' => $recommendv, 'recommendc' => $thread['recommends'], 'daycount' => $daycount, 'tid' => $thread['tid']);
		$msgarr['msg'] = $msgtext . lang('plugin/guiigo_appmanage', 'slang_10079') . $daycount . lang('plugin/guiigo_appmanage', 'slang_10080');
	} else {
		$msgarr['data'] = array('recommendv' => $recommendv, 'recommendc' => $thread['recommends'], 'tid' => $thread['tid']);
		$msgarr['msg'] = $msgtext;
	}
	$msgarr['code'] = 1;
	AppCommon::RetMsgJson($msgarr);
} elseif ($_GET['action'] == 'postreview') {
	$tid = dintval($_GET['tid']);
	$pid = dintval($_GET['pid']);
	if (!$_G['setting']['repliesrank'] || empty($_G['uid'])) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0138');
		AppCommon::RetMsgJson($msgarr);
	}
	$doArray = array('support', 'against', 'delsupport');
	$post = C::t('forum_post')->fetch('tid:' . $_GET['tid'], $_GET['pid'], false);
	if (!in_array($_GET['do'], $doArray) || empty($post) || $post['first'] == 1 || $_G['setting']['threadfilternum'] && $_G['setting']['filterednovote'] && getstatus($post['status'], 11)) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0001');
		AppCommon::RetMsgJson($msgarr);
	}
	$hotreply = C::t('forum_hotreply_number')->fetch_by_pid($post['pid']);
	if ($_G['uid'] == $post['authorid']) {
		$msgarr['code'] = 0 - 3;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10081');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($hotreply)) {
		$hotreply['pid'] = C::t('forum_hotreply_number')->insert(array('pid' => $post['pid'], 'tid' => $post['tid'], 'support' => 0, 'against' => 0, 'total' => 0), true);
	} else {
		if ($_GET['do'] != 'delsupport') {
			if (C::t('forum_hotreply_member')->fetch($post['pid'], $_G['uid'])) {
				$msgarr['code'] = 0 - 3;
				$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10082');
				AppCommon::RetMsgJson($msgarr);
			}
		}
	}
	if ($_GET['do'] == 'delsupport') {
		$typename = 'support';
		DB::query('UPDATE %t SET ' . $typename . '=' . $typename . '-1, total=total-1 WHERE pid=%d', array('forum_hotreply_number', $post['pid']));
	} else {
		$typeid = $_GET['do'] == 'support' ? 1 : 0;
		C::t('forum_hotreply_number')->update_num($post['pid'], $typeid);
	}
	if ($_GET['do'] == 'delsupport') {
		$hotreply['support']--;
		DB::delete('forum_hotreply_member', array('tid' => $post['tid'], 'pid' => $post['pid'], 'uid' => $_G['uid']));
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10072');
	} else {
		$hotreply[$_GET['do']]++;
		C::t('forum_hotreply_member')->insert(array('tid' => $post['tid'], 'pid' => $post['pid'], 'uid' => $_G['uid'], 'attitude' => $typeid));
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10073');
	}
	$msgarr['code'] = 1;
	$msgarr['data'] = $hotreply;
	AppCommon::RetMsgJson($msgarr);
}
function _update_threadpartake($tid, $op, $getsetarr = false)
{
	global $_G;
	$setarr = array();
	$heats = 1;
	if ($op == 'del') {
		$heats = 0 - 1;
	}
	if ($_G['uid'] && $tid) {
		if ($_G['setting']['heatthread']['period']) {
			$partaked = C::t('forum_threadpartake')->fetch($tid, $_G['uid']);
			$partaked = $partaked['uid'];
			if (!$partaked) {
				C::t('forum_threadpartake')->insert(array('tid' => $tid, 'uid' => $_G['uid'], 'dateline' => TIMESTAMP));
				$setarr = C::t('forum_thread')->increase($tid, array('heats' => $heats), false, 0, $getsetarr);
			} else {
				if ($op == 'del') {
					DB::delete('forum_threadpartake', array('tid' => $tid, 'uid' => $_G['uid']));
					$setarr = C::t('forum_thread')->increase($tid, array('heats' => $heats), false, 0, $getsetarr);
				}
			}
		} else {
			$setarr = C::t('forum_thread')->increase($tid, array('heats' => $heats), false, 0, $getsetarr);
		}
	}
	if ($getsetarr) {
		return $setarr;
	}
}