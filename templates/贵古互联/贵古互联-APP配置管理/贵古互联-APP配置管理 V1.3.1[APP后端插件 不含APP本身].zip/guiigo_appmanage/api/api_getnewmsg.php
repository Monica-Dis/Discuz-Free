<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($_GET['act'] == 'getPmList') {
	loaducenter(); /*dis'.'m.t'.'ao'.'bao.com*/
	if (!$_G['uid']) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = 'ok';
		AppCommon::RetMsgJson($msgarr);
	}
	$filter = in_array($_GET['filter'], array('newpm', 'privatepm')) ? $_GET['filter'] : 'getnewmsg';
	$grouppms = $list = $notice_text = $tabnewmsg = $gpmids = $gpmstatus = array();
	$cunm = $newpm = $newpmcount = 0;
	if ($filter == 'getnewmsg') {
		foreach ($_G['notice_structure'] as $k => $v) {
			if ($_G['member']['newprompt'] && !$_G['member']['category_num']) {
				$_G['member']['newprompt_num'] = C::t('common_member_newprompt')->fetch($_G['member']['uid']);
				$_G['member']['newprompt_num'] = unserialize($_G['member']['newprompt_num']['data']);
				$_G['member']['category_num'] = helper_notification::get_categorynum($_G['member']['newprompt_num']);
			}
			$cunm = intval($_G['member']['category_num'][$k]) + $cunm;
			$notice_text[$k] = lang('template', 'notice_' . $k);
		}
		$announcepm = 0;
		foreach (C::t('common_member_grouppm')->fetch_all_by_uid($_G['uid'], 0) as $gpmid => $gpuser) {
			$gpmstatus[$gpmid] = $gpuser['status'];
			if ($gpuser['status'] == 0) {
				$announcepm++;
			}
		}
		$gpmids = array_keys($gpmstatus);
		if ($gpmids) {
			foreach (C::t('common_grouppm')->fetch_all_by_id_authorid($gpmids) as $grouppm) {
				$grouppm['message'] = cutstr(strip_tags($grouppm['message']), 100, '');
				$grouppms[] = $grouppm;
			}
		}
		if (!empty($grouppms)) {
			foreach ($grouppms as $key => $value) {
				$value['message'] = str_replace('&amp;', ' ', $value['message']);
				$value['message'] = preg_replace('/&[a-z]+\\;/i', '', $value['message']);
				$value['dateline'] = str_replace('&nbsp;', '', dgmdate($value['dateline'], 'u'));
				$grouppms[$key] = $value;
			}
		}
		$newpmarr = uc_pm_checknew($_G['uid'], 1);
		$newpm = $newpmarr['newpm'];
		$newpmcount = $newpm + $announcepm;
		$tabnewmsg = array('newmsg' => $cunm + $newpmcount, 'follower' => $_G['member']['newprompt_num']['follower'] ? $_G['member']['newprompt_num']['follower'] : 0);
	} else {
		if ($filter == 'privatepm' || $filter == 'newpm') {
			$perpage = 10;
			if ($_GET['perpage']) {
				$perpage = intval($_GET['perpage']);
			}
			$page = empty($_GET['page']) ? 1 : intval($_GET['page']);
			$result = uc_pm_list($_G['uid'], $page, $perpage, 'inbox', $filter, 200);
			$count = $result['count'];
			$list = $result['data'];
			if (!empty($list)) {
				$today = $_G['timestamp'] - ($_G['timestamp'] + $_G['setting']['timeoffset'] * 3600) % 86400;
				foreach ($list as $key => $value) {
					$value['lastsummary'] = str_replace('&amp;', ' ', $value['lastsummary']);
					$value['lastsummary'] = preg_replace('/&[a-z]+\\;/i', '', $value['lastsummary']);
					$value['daterange'] = 5;
					if ($value['lastdateline'] >= $today) {
						$value['daterange'] = 1;
					} elseif ($value['lastdateline'] >= $today - 86400) {
						$value['daterange'] = 2;
					} elseif ($value['lastdateline'] >= $today - 172800) {
						$value['daterange'] = 3;
					} elseif ($value['lastdateline'] >= $today - 604800) {
						$value['daterange'] = 4;
					}
					$value['lastsummary'] = AppCommon::feedFace($value['lastsummary']);
					$value['touidAvatar'] = AppCommon::avatar($value['touid']);
					$value['lastdateline'] = str_replace('&nbsp;', '', dgmdate($value['lastdateline'], 'u'));
					$list[$key] = $value;
				}
			}
		}
	}
	$msgarr['code'] = 1;
	$msgarr['data'] = array('newpmcount' => $newpmcount, 'tabnewmsg' => $tabnewmsg, 'notice_structure' => $filter == 'getnewmsg' ? $_G['notice_structure'] : array(), 'notice_text' => $notice_text, 'category_num' => $_G['member']['category_num'] ? $_G['member']['category_num'] : array(), 'grouppms_list' => $grouppms, 'notice_list' => array('count' => $count, 'perpage' => $perpage, 'page' => $page, 'list' => $list));
	$msgarr['msg'] = 'ok';
	AppCommon::RetMsgJson($msgarr);
}