<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!class_exists('ForumPost')) {
	include_once libfile('class/ForumPost', 'plugin/guiigo_appmanage');
}
if ($_GET['act'] == 'getIndexList') {
	if (!is_array($_G['cache']['usergroups'])) {
		loadcache('usergroups');
	}
	$orderid = daddslashes($_GET['orderid']);
	$perpage = 10;
	if ($_GET['perpage']) {
		$perpage = intval($_GET['perpage']);
	}
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage - 1) * $perpage;
	$poatstyle = 1;
	$postlist = array();
	$data_html = array();
	$userlist = array();
	$postCount = 0;
	if ($orderid == 'nocontent') {
		if ($config['appdata']['setIndex']['module_ids'] && $_GET['page'] <= 1) {
			$data_html = ForumPost::get_block_html($config['appdata']['setIndex']['module_ids']);
		}
		if ($config['appdata']['setIndex']['recommend_content'] == 'forum') {
			$where = $config['appdata']['setIndex']['forum'];
			if ($where['style']) {
				$poatstyle = $where['style'];
			}
			$where['fid'] = $where['forumids'];
			$where['attachment'] = $where['isimg'] ? 2 : '';
			$where['authorid'] = $where['uids'] ? $where['uids'] : '';
			$where['isgroup'] = 0;
		} elseif ($config['appdata']['setIndex']['recommend_content'] == 'Portal') {
			$poatstyle = 31;
			$where = $config['appdata']['setIndex']['Portal'];
			$where['catid'] = $where['Portalids'];
			$where['pic'] = $where['isimg'] ? true : false;
			$where['uid'] = $where['uids'] ? $where['uids'] : '';
			$resData = ForumPost::fetch_all_get_Portal_post($where, $start, $perpage);
			$postCount = $resData['count'];
			$postlist = $resData['data'];
		} elseif ($config['appdata']['setIndex']['recommend_content'] == 'group') {
			$where = $config['appdata']['setIndex']['group'];
			if ($where['style']) {
				$poatstyle = $where['style'];
			}
			$where['fid'] = $where['groupids'];
			$where['attachment'] = $where['isimg'] ? 2 : '';
			$where['authorid'] = $where['uids'] ? $where['uids'] : '';
			$where['isgroup'] = 1;
		}
		if ($config['appdata']['setIndex']['recommend_content'] == 'group' || $config['appdata']['setIndex']['recommend_content'] == 'forum') {
			$resData = ForumPost::fetch_all_get_post($where, $start, $perpage);
			$postCount = $resData['count'];
			$postlist = $resData['data'];
		}
	} elseif ($orderid == 'user_interest') {
		$where = array();
		if ($app_uid) {
			$uids = AppCommon::getUserList($app_uid, 'follow');
			if ($uids) {
				$where['authorid'] = $uids;
				$where['noauthorid'] = $app_uid;
				$resData = ForumPost::fetch_all_get_post($where, $start, $perpage, 'BY p.dateline DESC');
				$postCount = $resData['count'];
				$postlist = $resData['data'];
			}
		}
		if (!$postlist && $config['appdata']['setIndex']['user_follow_uids'] && $_GET['page'] <= 1) {
			$newuids = array();
			$uids = explode(',', $config['appdata']['setIndex']['user_follow_uids']);
			if ($app_uid) {
				$myuids = AppCommon::getUserList($app_uid, 'follow');
				foreach ($uids as $y => $u) {
					if (!in_array($u, $myuids)) {
						$newuids[$y] = $u;
					}
				}
			} else {
				$newuids = $uids;
			}
			$member_count = C::t('common_member_count')->fetch_all($newuids);
			$ii = 0;
			foreach (C::t('common_member')->fetch_all($newuids) as $uid => $val) {
				$userlist[$ii]['uid'] = $uid;
				$userlist[$ii]['authorid'] = $uid;
				$userlist[$ii]['username'] = $val['username'];
				$userlist[$ii]['avatarurl'] = AppCommon::avatar($uid);
				$userlist[$ii]['followData'] = $member_count[$uid];
				$ii++;
			}
			unset($newuids);
			unset($uid);
			unset($val);
		}
	} else {
		$orderid = intval($_GET['orderid']);
		$navs = $config['appdata']['nav'];
		if ($orderid) {
			$navarray = array();
			foreach ($navs as $k => $v) {
				if ($v['order'] == $orderid) {
					$navarray = $v;
					break;
				}
			}
			if ($navarray['channel_extension'] == 'information') {
				$param = $navarray[$navarray['channel_extension']][$navarray['recommend_content']];
				if ($navarray['module_ids'] && $_GET['page'] <= 1) {
					$data_html = ForumPost::get_block_html($navarray['module_ids']);
				}
				if ($param['style']) {
					$poatstyle = $param['style'];
				}
				$where = $param;
				if ($navarray['recommend_content'] == 'Portal') {
					$poatstyle = 31;
					$where['catid'] = $param['Portalids'] ? $param['Portalids'] : '';
					$where['pic'] = $param['isimg'] ? true : false;
					$where['uid'] = $param['uids'] ? $param['uids'] : '';
					$resData = ForumPost::fetch_all_get_Portal_post($where, $start, $perpage);
					$postCount = $resData['count'];
					$postlist = $resData['data'];
				} else {
					$where['fid'] = $navarray['recommend_content'] == 'forum' ? $param['forumids'] : $param['groupids'];
					$where['isgroup'] = $navarray['recommend_content'] == 'forum' ? 0 : 1;
					$where['attachment'] = $param['isimg'] ? 2 : '';
					$where['authorid'] = $param['uids'] ? $param['uids'] : '';
					$resData = ForumPost::fetch_all_get_post($where, $start, $perpage);
					$postCount = $resData['count'];
					$postlist = $resData['data'];
				}
			} elseif ($navarray['channel_extension'] == 'video') {
				$poatstyle = 4;
				$where = array();
				$where['fid'] = $navarray['video'];
				$where['isgroup'] = 0;
				$resData = ForumPost::fetch_all_get_post($where, $start, $perpage);
				$postCount = $resData['count'];
				$postlist = $resData['data'];
			} elseif ($navarray['channel_extension'] == 'modules') {
				$data_html = ForumPost::get_block_html($navarray['module_ids']);
			}
		}
	}
	$newpostlist = array();
	if ($postlist && $poatstyle == 31) {
		foreach ($postlist as $k => $post) {
			$newpostlist[$k] = $post;
			$newpostlist[$k]['highlight'] = ForumPost::article_title_style($post);
			$newpostlist[$k]['posturl'] = ForumPost::fetch_article_url($post);
			$newpostlist[$k]['dateline'] = str_replace('&nbsp;', '', dgmdate($post['dateline'], 'u'));
			$newpostlist[$k]['pic'] = $post['pic'] ? $_G['siteurl'] . $post['pic'] : '';
			$newpostlist[$k]['viewnum'] = AppCommon::dnumber($post['viewnum']);
		}
	} else {
		if ($postlist) {
			$recommenustid = $postusers = $postlocations = array();
			$postarr = AppCommon::getPostIdsFall($postlist);
			if ($postarr['uids']) {
				$postusers = AppCommon::getPostUserListByids($postarr['uids']);
			}
			if ($postarr['locationpids']) {
				$postlocations = AppCommon::getPostLocationpByids($postarr['locationpids']);
			}
			if ($postarr['tids'] && $_G['setting']['recommendthread']['status'] && $_G['uid']) {
				$recommenustid = AppCommon::getMemberRecommenus($postarr['tids']);
			}
			$k = 0;
			foreach ($postlist as $pid => $post) {
				if ($post['closed'] > 1 || $post['moved']) {
					$post['tid'] = $post['closed'];
				}
				$attachimg = ForumPost::getForumdisplayAttachByid($post['tid'], $post['pid']);
				if ($poatstyle == 4) {
					$post['video'] = array('cover' => '', 'source' => '');
					$message = ForumPost::messageAnalysis($post['message']);
					$param = getPostVideo($post);
					if ($param['data']) {
						$post['video'] = $param['data'];
					}
					if (!$post['video']['source']) {
						$post['video']['cover'] = $attachimg['attachsList'][0]['pic'];
					}
					$post['message'] = AppCommon::dzcutstr($message, 90);
				} else {
					$message = ForumPost::messageAnalysis($post['message']);
					$message = AppCommon::dzcutstr($message, 90);
					$post['message'] = substr($message, 0, strlen($post['subject'])) == $post['subject'] ? '' : $message;
				}
				$post['posturl'] = $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $post['tid'];
				$post['avatarurl'] = $_G['siteurl'] . 'guiigo_appmanage/static/img/davatar.jpg';
				$post['dateline'] = str_replace('&nbsp;', '', dgmdate($post['dateline'], 'u'));
				$post['authorurl'] = '';
				if ($post['authorid'] && $post['author']) {
					$post['avatarurl'] = AppCommon::avatar($post['authorid']);
					$post['authorurl'] = $_G['siteurl'] . 'home.php?mod=space&uid=' . $post['authorid'] . '&do=profile';
				} else {
					$post['author'] = $_G['setting']['anonymoustext'];
				}
				$post['isrecommenus'] = 0;
				if ($post['first'] == 1 && !empty($recommenustid) && $recommenustid[$post['tid']]['recommenduid'] > 0) {
					$post['isrecommenus'] = 1;
				}
				$post['replies'] = AppCommon::dnumber($post['replies']);
				$post['views'] = AppCommon::dnumber($post['views']);
				$post['recommend_add'] = AppCommon::dnumber($post['recommend_add']);
				$newpostlist[$k] = array_merge($post, (array) $postusers[$post['authorid']], (array) $postlocations[$pid], (array) $attachimg);
				$k++;
			}
		}
	}
	$returnData = array('orderid' => $orderid, 'poatStyle' => $poatstyle, 'moduleList' => $data_html, 'userList' => $userlist, 'postList' => $newpostlist, 'page' => $curpage, 'count' => $postCount, 'perpage' => $perpage, 'resDate' => TIMESTAMP);
	$msgarr['code'] = 1;
	$msgarr['data'] = $returnData;
	$msgarr['msg'] = 'ok';
	AppCommon::RetMsgJson($msgarr);
}
function getPostVideo($post)
{
	global $_G;
	$param = array();
	if (in_array('guiigo_video', $_G['setting']['plugins']['available'])) {
		include_once libfile('class/guiigovideo', 'plugin/guiigo_video');
	} else {
		return $param;
	}
	if ($post['message'] && strexists($post['message'], '[/guiigo_video]') !== false) {
		if (preg_match('/\\[guiigo_video\\]\\s*([^\\[\\<\\r\\n]+?)\\s*\\[\\/guiigo_video\\]/is', $post['message'], $matches)) {
			$vdata = DB::fetch_first('select v_tid,v_videoid,v_videourl,v_videocover,v_authentication  from %t where v_videoid=%s', array('guiigo_video_videolog', $matches[1]));
		}
	} else {
		$vdata = DB::fetch_first('select v_tid,v_videoid,v_videourl,v_videocover,v_authentication from %t where v_fid=%d AND v_tid=%d AND v_pid=%d ', array('guiigo_video_videolog', $post['fid'], $post['tid'], $post['pid']));
	}
	if (!empty($vdata)) {
		$param = GuiigoVideo::getPlayerParam($vdata);
	}
	return $param;
}