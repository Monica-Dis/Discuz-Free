<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($_GET['act'] == 'getForumList') {
	$catlist = $forumlist = $forumname = $favforumlist = $announcements = array();
	$threads = $posts = $todayposts = $totalmembers = 0;
	$postdata = $_G['cache']['historyposts'] ? explode('	', $_G['cache']['historyposts']) : array(0, 0);
	$postdata[0] = intval($postdata[0]);
	$postdata[1] = intval($postdata[1]);
	if (!isset($_G['cache']['userstats'])) {
		loadcache('userstats');
	}
	$totalmembers = $_G['cache']['userstats']['totalmembers'];
	$announcements = get_index_announcements();
	if (!isset($_G['cache']['forumindex'])) {
		loadcache('forumindex');
	}
	$forums = $_G['cache']['forumindex']['forums'];
	$forum_fields = $_G['cache']['forumindex']['forum_fields'];
	$fids = $_G['cache']['forumindex']['fids'];
	$forum_access = $_G['cache']['forumindex']['forum_access'];
	$cachetimeupdate = TIMESTAMP - intval($_G['cache']['forumindex']['updateline']);
	if (empty($_G['cache']['forumindex']) || $cachetimeupdate > 3600 || empty($forums) || empty($forum_fields) || !$forum_access && $_G['uid'] && !empty($_G['member']['accessmasks'])) {
		$data = array();
		$data['updateline'] = TIMESTAMP;
		$data['forums'] = $forums = C::t('forum_forum')->fetch_all_by_status(1);
		$fids = array();
		foreach ($forums as $forum) {
			$fids[$forum['fid']] = $forum['fid'];
		}
		$data['fids'] = $fids;
		$data['forum_fields'] = $forum_fields = C::t('forum_forumfield')->fetch_all($fids);
		if (!empty($_G['member']['accessmasks']) && $_G['uid']) {
			$data['forum_access'] = $forum_access = C::t('forum_access')->fetch_all_by_fid_uid($fids, $_G['uid']);
		}
		savecache('forumindex', $data);
	}
	$_favorite = array();
	if ($app_uid) {
		$_favorite = AppCommon::getUserList($_G['uid'], 'favorite', 'fid');
		$favforumlist = array();
		foreach ($_favorite as $id => $forum) {
			if ($forum_fields[$id]['fid']) {
				$vforumlist = AppCommon::getForumByFid($id);
				$forum_ret = forum($vforumlist);
				$forum_ret['extra'] = empty($forum_ret['extra']) ? array() : dunserialize($forum_ret['extra']);
				$forum_ret['forum_isfavorite'] = 0;
				$forum_ret['forum_favid'] = '';
				if ($_favorite[$forum_ret['fid']] && $forum_ret['fid'] == $_favorite[$forum_ret['fid']]['id']) {
					$forum_ret['forum_isfavorite'] = 1;
					$forum_ret['forum_favid'] = $_favorite[$forum_ret['fid']]['favid'];
				}
				if ($forum_ret) {
					$favforumlist[$id] = $forum_ret;
				}
			}
		}
		unset($id);
		unset($forum);
		unset($forum_ret);
	}
	foreach ($forums as $forum) {
		if ($forum_fields[$forum['fid']]['fid']) {
			$forum = array_merge($forum, $forum_fields[$forum['fid']]);
		}
		if ($forum_access['fid']) {
			$forum = array_merge($forum, $forum_access[$forum['fid']]);
		}
		$forumname[$forum['fid']] = strip_tags($forum['name']);
		$forum['extra'] = empty($forum['extra']) ? array() : dunserialize($forum['extra']);
		if (!is_array($forum['extra'])) {
			$forum['extra'] = array();
		}
		if ($forum['type'] != 'group') {
			$threads += $forum['threads'];
			$posts += $forum['posts'];
			$todayposts += $forum['todayposts'];
			if ($forum['type'] == 'forum' && isset($catlist[$forum['fup']])) {
				$forum_ret = forum($forum);
				if ($forum_ret) {
					$forum = $forum_ret;
					$catlist[$forum['fup']]['forums'][] = $forum['fid'];
					$forum['orderid'] = $catlist[$forum['fup']]['forumscount']++;
					$forum['subforums'] = array();
					$forum['forum_isfavorite'] = 0;
					$forum['forum_favid'] = '';
					if ($_favorite[$forum['fid']] && $forum['fid'] == $_favorite[$forum['fid']]['id']) {
						$forum['forum_isfavorite'] = 1;
						$forum['forum_favid'] = $_favorite[$forum['fid']]['favid'];
					}
					$forumlist[$forum['fid']] = $forum;
				}
				unset($forum_ret);
			} else {
				if (isset($forumlist[$forum['fup']])) {
					$forumlist[$forum['fup']]['threads'] += $forum['threads'];
					$forumlist[$forum['fup']]['posts'] += $forum['posts'];
					$forumlist[$forum['fup']]['todayposts'] += $forum['todayposts'];
					if ($_G['setting']['subforumsindex'] && $forumlist[$forum['fup']]['permission'] == 2 && !($forumlist[$forum['fup']]['simple'] & 16) || $forumlist[$forum['fup']]['simple'] & 8) {
						$subforum_isfavorite = 0;
						$subforum_favid = '';
						if ($_favorite[$forum['fid']] && $forum['fid'] == $_favorite[$forum['fid']]['id']) {
							$subforum_isfavorite = 1;
							$subforum_favid = $_favorite[$forum['fid']]['favid'];
						}
						$forumlist[$forum['fup']]['subforums'][] = array('subforumfid' => $forum['fid'], 'subforumurl' => $_G['siteurl'] . 'forum.php?mod=forumdisplay&fid=' . $forum['fid'], 'subforumname' => strip_tags($forum['name']), 'subnamecolor' => $forum['extra']['namecolor'], 'subforum_isfavorite' => $subforum_isfavorite);
					}
				}
			}
		} else {
			if ($forum['moderators']) {
				$forum['moderators'] = moddisplay($forum['moderators'], 'flat');
			}
			$forum['forumscount'] = 0;
			$catlist[$forum['fid']] = $forum;
		}
	}
	unset($forum_access);
	unset($forum_fields);
	if (isset($catlist[0]) && $catlist[0]['forumscount']) {
		$catlist[0]['fid'] = 0;
		$catlist[0]['type'] = 'group';
		$catlist[0]['name'] = $_G['setting']['bbname'];
	} else {
		unset($catlist[0]);
	}
	$_catlist = array();
	foreach ($catlist as $x => $v) {
		$_catlist[$x] = $v;
		$_catlist[$x]['showforum'] = 1;
	}
	$msgarr['code'] = 1;
	$msgarr['data'] = array('catlist' => $_catlist, 'forumlist' => $forumlist, 'forumname' => $forumname, 'favforumlist' => $favforumlist, 'announcements' => $announcements, 'threadsData' => array('yesterday' => $postdata[0], 'threads' => $threads, 'posts' => $posts, 'todayposts' => $todayposts, 'totalmembers' => $totalmembers));
	$msgarr['msg'] = 'ok';
	AppCommon::RetMsgJson($msgarr);
}
function forum($forum)
{
	global $_G;
	if (!$forum['viewperm'] || $forum['viewperm'] && forumperm($forum['viewperm']) || !empty($forum['allowview']) || isset($forum['users']) && strstr($forum['users'], '	' . $_G['uid'] . '	')) {
		$forum['permission'] = 2;
	} else {
		if (!$_G['setting']['hideprivate']) {
			$forum['permission'] = 1;
		} else {
			return false;
		}
	}
	$forum['icon'] = $forum['icon'] ? get_forumimg($forum['icon']) : '';
	$forum['forumurl'] = $_G['siteurl'] . 'forum.php?mod=forumdisplay&fid=' . $forum['fid'];
	$lastpost = array(0, 0, '', '');
	$forum['lastpost'] = is_string($forum['lastpost']) ? explode('	', $forum['lastpost']) : $forum['lastpost'];
	$forum['lastpost'] = !(count($forum['lastpost']) == 4) ? $lastpost : $forum['lastpost'];
	list($lastpost['tid'], $lastpost['subject'], $lastpost['dateline'], $lastpost['author']) = $forum['lastpost'];
	if ($lastpost['tid']) {
		$lastpost['dateline'] = str_replace('&nbsp;', '', dgmdate($lastpost['dateline'], 'u'));
		$lastpost['authorusername'] = $lastpost['author'];
		$lastpost['authorurl'] = $lastpost['author'] ? $_G['siteurl'] . 'home.php?mod=space&username=' . rawurlencode($lastpost['author']) : '';
		$forum['lastpost'] = $lastpost;
	} else {
		$forum['lastpost'] = $lastpost['authorusername'] = '';
	}
	$forum['moderators'] = moddisplay($forum['moderators'], $_G['setting']['moddisplay'], !empty($forum['inheritedmod']));
	if (isset($forum['subforums'])) {
		$forum['subforums'] = implode(', ', $forum['subforums']);
	}
	return $forum;
}
function get_forumimg($imgname)
{
	global $_G;
	if ($imgname) {
		$parse = parse_url($imgname);
		if (isset($parse['host'])) {
			$imgpath = $imgname;
		} else {
			if ($_G['forum']['status'] != 3) {
				$imgpath = $_G['siteurl'] . $_G['setting']['attachurl'] . 'common/' . $imgname;
			} else {
				$imgpath = $_G['siteurl'] . $_G['setting']['attachurl'] . 'group/' . $imgname;
			}
		}
		return $imgpath;
	}
}
function moddisplay($moderators, $type, $inherit = 0)
{
	global $_G;
	$modlist = array();
	if ($moderators) {
		foreach (explode('	', $moderators) as $key => $moderator) {
			$modlist[$key]['url'] = $_G['siteurl'] . 'home.php?mod=space&username=' . rawurlencode($moderator);
			$modlist[$key]['username'] = $moderator;
		}
	}
	return $modlist;
}
function get_index_announcements()
{
	global $_G;
	$announcements = array();
	if (!isset($_G['cache']['announcements'])) {
		loadcache('announcements');
	}
	if ($_G['cache']['announcements']) {
		foreach ($_G['cache']['announcements'] as $key => $announcement) {
			if (!$announcement['endtime'] || $announcement['endtime'] > TIMESTAMP && (empty($announcement['groups']) || in_array($_G['member']['groupid'], $announcement['groups']))) {
				$announcement[$key]['type'] = $announcement['type'];
				if (empty($announcement['type'])) {
					$announcements[$key]['subject'] = strip_tags($announcement['subject']);
					$announcements[$key]['starttime'] = dgmdate($announcement['starttime'], 'd');
					$announcements[$key]['url'] = $_G['siteurl'] . 'forum.php?mod=announcement&id=' . $announcement['id'];
				} else {
					if ($announcement['type'] == 1) {
						$announcements[$key]['subject'] = strip_tags($announcement['subject']);
						$announcements[$key]['starttime'] = dgmdate($announcement['starttime'], 'd');
						$announcements[$key]['url'] = $announcement['message'];
					}
				}
			}
		}
	}
	return $announcements;
}