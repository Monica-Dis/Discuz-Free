<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!class_exists('UserLogin')) {
	include_once libfile('class/UserLogin', 'plugin/guiigo_appmanage');
}
if (!in_array('guiigo_login', $_G['setting']['plugins']['available'])) {
	$msgarr['code'] = 0 - 3;
	$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10051');
	AppCommon::RetMsgJson($msgarr);
}
if ($_GET['act'] == 'regUserLogin') {
	$mobile = daddslashes($_GET['mobile']);
	$password = daddslashes($_GET['password']);
	$code = dintval($_GET['code']);
	$username = daddslashes($_GET['username']);
	$bindmobile = daddslashes($_GET['bindmobile']);
	if (empty($username)) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10052');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($mobile)) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10053');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($code)) {
		$msgarr['code'] = 0 - 3;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10054');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($password)) {
		$msgarr['code'] = 0 - 4;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10055');
		AppCommon::RetMsgJson($msgarr);
	}
	$sms_list = GuiigoLogin::getSmsList($mobile, $code);
	if (!$sms_list['t_id']) {
		$msgarr['code'] = 0 - 5;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10056');
		AppCommon::RetMsgJson($msgarr);
	}
	if ($sms_list['t_notice_date'] + $config['codedata'] < TIMESTAMP) {
		$msgarr['code'] = 0 - 6;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10057');
		AppCommon::RetMsgJson($msgarr);
	}
	$resuid = AppCommon::GetUidByPhone($mobile);
	if ($resuid) {
		$msgarr['code'] = 0 - 7;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10058');
		AppCommon::RetMsgJson($msgarr);
	}
	$userinfo = array('mobile' => $mobile, 'password' => $password, 'username' => $username, 'bindmobile' => $bindmobile);
	$ret = UserLogin::regUserlogin($userinfo);
	if ($ret['code'] == 1) {
		$msgarr['code'] = 1;
		$msgarr['data'] = AppCommon::refreshTokenReturnUser($ret['data']['uid']);
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10038');
	} else {
		$msgarr['code'] = 0 - 8;
		$msgarr['msg'] = $ret['msg'];
	}
	AppCommon::RetMsgJson($msgarr);
} elseif ($_GET['act'] == 'userLogin') {
	$mobile = daddslashes($_GET['mobile']);
	$password = daddslashes($_GET['password']);
	if (empty($mobile)) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10059');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($password)) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10055');
		AppCommon::RetMsgJson($msgarr);
	}
	$ret = UserLogin::Login($mobile, $password);
	if ($ret['code'] == 1) {
		$msgarr['code'] = 1;
		$msgarr['data'] = AppCommon::refreshTokenReturnUser($ret['data']['uid']);
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10048');
	} else {
		$msgarr['code'] = 0 - 3;
		$msgarr['msg'] = $ret['msg'];
	}
	AppCommon::RetMsgJson($msgarr);
} elseif ($_GET['act'] == 'initPassword') {
	$mobile = daddslashes($_GET['mobile']);
	$password = daddslashes($_GET['password']);
	$code = dintval($_GET['code']);
	if (empty($mobile)) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10053');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($code)) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10054');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($password)) {
		$msgarr['code'] = 0 - 3;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10060');
		AppCommon::RetMsgJson($msgarr);
	}
	if (strlen($password) < 6) {
		$msgarr['code'] = 0 - 4;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10061');
		AppCommon::RetMsgJson($msgarr);
	}
	$sms_list = GuiigoLogin::getSmsList($mobile, $code);
	if (!$sms_list['t_id']) {
		$msgarr['code'] = 0 - 5;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10056');
		AppCommon::RetMsgJson($msgarr);
	}
	if ($sms_list['t_notice_date'] + $config['codedata'] < TIMESTAMP) {
		$msgarr['code'] = 0 - 6;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10057');
		AppCommon::RetMsgJson($msgarr);
	}
	$uid = AppCommon::GetUidByPhone($mobile);
	if ($uid) {
		loaducenter(); /*dis'.'m.t'.'ao'.'bao.com*/
		$member = getuserbyuid($uid);
		uc_user_edit($member['username'], $password, $password, '', 1, 0);
		$password = md5(random(10));
		C::t('common_member')->update($uid, array('password' => $password));
		$msgarr['code'] = 1;
		$msgarr['data'] = AppCommon::refreshTokenReturnUser($uid);
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10062');
	} else {
		$msgarr['code'] = 0 - 7;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10063');
	}
	AppCommon::RetMsgJson($msgarr);
} elseif ($_GET['act'] == 'getUserInfoByToken') {
	$token = daddslashes($_GET['token']);
	if (empty($token)) {
		$msgarr['code'] = 1001;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10064');
		AppCommon::RetMsgJson($msgarr);
	}
	$islong = AppCommon::CheckLonginByTonken(daddslashes($token));
	$uid = AppCommon::DecodeTonken($token);
	if (!$islong || !$uid) {
		$msgarr['code'] = 1001;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10065');
		AppCommon::RetMsgJson($msgarr);
	} else {
		AppCommon::loadLoginStatus($uid);
		$msgarr['code'] = 1;
		$msgarr['data'] = AppCommon::refreshTokenReturnUser($uid);
		$msgarr['msg'] = 'ok';
	}
	AppCommon::RetMsgJson($msgarr);
} elseif ($_GET['act'] == 'AllLongin') {
	$get = daddslashes($_GET);
	if (empty($get['type'])) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10069');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($get['openid'])) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10069') . '-openid';
		AppCommon::RetMsgJson($msgarr);
	}
	$u_uid = 0;
	$userinfo = array();
	if ($get['type'] == 'weixin' && $get['unionid']) {
		if (!$get['unionid']) {
			$msgarr['code'] = 0 - 4;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10070');
			AppCommon::RetMsgJson($msgarr);
		}
		$u_uid = DB::result_first('select u_uid from %t where u_wx_unionid=%s', array('guiigo_login_user', $get['unionid']));
		$userinfo['username'] = 'WX_' . strtolower(random(10));
		$userinfo['u_wx_unionid'] = $get['unionid'];
	} elseif ($get['type'] == 'sinaweibo') {
		$u_uid = DB::result_first('select u_uid from %t where u_sina_openid=%s', array('guiigo_login_user', $get['openid']));
		$userinfo['username'] = 'WB_' . strtolower(random(10));
		$userinfo['u_sina_openid'] = $get['openid'];
	} elseif ($get['type'] == 'qq') {
		$url = 'https://graph.qq.com/oauth2.0/me?access_token=' . $get['access_token'] . '&unionid=1&fmt=json';
		$res = json_decode(dfsockopen($url), true);
		if (!$res['unionid']) {
			$msgarr['code'] = 0 - 5;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10071');
			AppCommon::RetMsgJson($msgarr);
		}
		$u_uid = DB::result_first('select u_uid from %t where u_qq_unionid=%s', array('guiigo_login_user', $res['unionid']));
		$userinfo['username'] = 'QQ_' . strtolower(random(10));
		$userinfo['u_qq_unionid'] = $res['unionid'];
	} elseif ($get['type'] == 'apple') {
		$u_uid = DB::result_first('select u_uid from %t where u_apple_openid=%s', array('guiigo_login_user', $get['openid']));
		$userinfo['username'] = 'apple_' . strtolower(random(8));
		$userinfo['u_apple_openid'] = $get['openid'];
	}
	if ($get['nickname']) {
		if (strtolower(CHARSET) == 'gbk') {
			$get['nickname'] = AppCommon::iconvArrayA($get['nickname'], 'utf-8', 'gbk');
		}
		$userinfo['username'] = UserLogin::get_wxregname($get['nickname']);
	}
	if ($get['headimgurl']) {
		$userinfo['headimgurl'] = $get['headimgurl'];
	}
	if ($u_uid) {
		AppCommon::loadLoginStatus($u_uid);
		$msgarr['code'] = 1;
		$msgarr['data'] = AppCommon::refreshTokenReturnUser($u_uid);
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10048');
		AppCommon::RetMsgJson($msgarr);
	} else {
		$hashid = random(10);
		AppCommon::savecache($hashid, $userinfo);
		$msgarr['code'] = 2;
		$msgarr['data'] = array('hashid' => $hashid);
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10098');
		AppCommon::RetMsgJson($msgarr);
	}
} elseif ($_GET['act'] == 'bindRegUser') {
	$type = daddslashes($_GET['type']);
	$hashid = daddslashes($_GET['hashid']);
	$username = daddslashes($_GET['username']);
	$password = daddslashes($_GET['password']);
	$userinfo = AppCommon::savecache($hashid);
	if (empty($userinfo)) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10099');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($username)) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10100');
		AppCommon::RetMsgJson($msgarr);
	}
	if (empty($password)) {
		$msgarr['code'] = 0 - 3;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10101');
		AppCommon::RetMsgJson($msgarr);
	}
	$userinfo['username'] = $username;
	if ($type == 'bind') {
		if (!function_exists('uc_user_login')) {
			loaducenter(); /*dis'.'m.t'.'ao'.'bao.com*/
		}
		$result = uc_user_login($username, $password, 0);
		if ($result[0] > 0) {
			$u_id = DB::result_first('select u_id from %t where u_uid=%d', array('guiigo_login_user', $result[0]));
			if ($userinfo['headimgurl']) {
				UserLogin::syncavatar($result[0], $userinfo['headimgurl']);
			}
			unset($userinfo['username']);
			unset($userinfo['headimgurl']);
			if (!$u_id) {
				$userinfo['u_uid'] = $result[0];
				$userinfo['u_dateline'] = TIMESTAMP;
				C::t('#guiigo_login#guiigo_login_user')->insert($userinfo);
			} else {
				C::t('#guiigo_login#guiigo_login_user')->update($userinfo, array('u_id' => $u_id));
			}
			$msgarr['code'] = 1;
			$msgarr['data'] = AppCommon::refreshTokenReturnUser($result[0]);
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10102');
		} else {
			$msgarr['code'] = 0 - 4;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10103');
		}
		AppCommon::RetMsgJson($msgarr);
	} elseif ($type == 'reg') {
		$userinfo['password'] = $password;
		$ret = UserLogin::regUserlogin($userinfo);
		if ($ret['code'] == 1) {
			if ($userinfo['headimgurl']) {
				UserLogin::syncavatar($ret['data']['uid'], $userinfo['headimgurl']);
			}
			unset($userinfo['username']);
			unset($userinfo['headimgurl']);
			unset($userinfo['password']);
			$u_id = DB::result_first('select u_id from %t where u_uid=%d', array('guiigo_login_user', $ret['data']['uid']));
			if (!$u_id) {
				$userinfo['u_uid'] = $ret['data']['uid'];
				$userinfo['u_dateline'] = TIMESTAMP;
				C::t('#guiigo_login#guiigo_login_user')->insert($userinfo);
			} else {
				C::t('#guiigo_login#guiigo_login_user')->update($userinfo, array('u_id' => $u_id));
			}
			$msgarr['code'] = 1;
			$msgarr['data'] = AppCommon::refreshTokenReturnUser($ret['data']['uid']);
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10038');
		} else {
			$msgarr['code'] = 0 - 4;
			$msgarr['msg'] = $ret['msg'];
		}
		AppCommon::RetMsgJson($msgarr);
	}
} elseif ($_GET['act'] == 'OutLongin') {
	if (empty($token)) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10066');
		AppCommon::RetMsgJson($msgarr);
	}
	$uid = AppCommon::DecodeTonken($token);
	AppCommon::loadLoginStatus($uid);
	$logout = AppCommon::logout();
	if ($logout) {
		$msgarr['code'] = 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10067');
	} else {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10068');
	}
	AppCommon::RetMsgJson($msgarr);
}