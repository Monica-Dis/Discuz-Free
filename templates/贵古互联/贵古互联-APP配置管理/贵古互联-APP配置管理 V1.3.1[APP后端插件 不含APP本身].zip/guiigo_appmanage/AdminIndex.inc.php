<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include_once libfile('class/AppCommon', 'plugin/guiigo_appmanage');
$config = AppCommon::config();
require_once libfile('function/forumlist');
$setting = C::t('common_setting')->fetch_all(array('guiigo_appmanage'));
$settingappmanage = (array) unserialize($setting['guiigo_appmanage']);
$setting = $settingappmanage['setIndex'];
$basicurl = 'plugins&operation=config&do=' . $_GET['do'] . '&identifier=guiigo_appmanage&pmod=' . $_GET['pmod'];
if (!submitcheck('settingsubmit')) {
	$forum_style_select = array();
	$forum_style_select[] = array(1, lang('plugin/guiigo_appmanage', 'slang0023'));
	$forum_style_select[] = array(2, lang('plugin/guiigo_appmanage', 'slang0024'));
	$forum_style_select[] = array(3, lang('plugin/guiigo_appmanage', 'slang0025'));
	$forum_special_select = array();
	$forum_special_select[] = array(0, lang('plugin/guiigo_appmanage', 'slang0180'));
	$forum_special_select[] = array(1, lang('plugin/guiigo_appmanage', 'slang0181'));
	$forum_special_select[] = array(2, lang('plugin/guiigo_appmanage', 'slang0182'));
	$forum_special_select[] = array(3, lang('plugin/guiigo_appmanage', 'slang0183'));
	$forum_special_select[] = array(4, lang('plugin/guiigo_appmanage', 'slang0184'));
	$forum_special_select[] = array(5, lang('plugin/guiigo_appmanage', 'slang0185'));
	$forum_special_select[] = array(127, lang('plugin/guiigo_appmanage', 'slang0186'));
	$forum_orderby_select = array();
	$forum_orderby_select[] = array('lastpost', lang('plugin/guiigo_appmanage', 'slang0187'));
	$forum_orderby_select[] = array('dateline', lang('plugin/guiigo_appmanage', 'slang0188'));
	$forum_orderby_select[] = array('replies', lang('plugin/guiigo_appmanage', 'slang0189'));
	$forum_orderby_select[] = array('views', lang('plugin/guiigo_appmanage', 'slang0190'));
	$forum_orderby_select[] = array('heats', lang('plugin/guiigo_appmanage', 'slang0191'));
	$forum_orderby_select[] = array('recommends', lang('plugin/guiigo_appmanage', 'slang0192'));
	$forum_dateline_select = array();
	$forum_dateline_select[] = array(3600, lang('plugin/guiigo_appmanage', 'slang0193'));
	$forum_dateline_select[] = array(86400, lang('plugin/guiigo_appmanage', 'slang0194'));
	$forum_dateline_select[] = array(604800, lang('plugin/guiigo_appmanage', 'slang0195'));
	$forum_dateline_select[] = array(2592000, lang('plugin/guiigo_appmanage', 'slang0196'));
	$Portal_orderby_select = array();
	$Portal_orderby_select[] = array('dateline', lang('plugin/guiigo_appmanage', 'slang0197'));
	$Portal_orderby_select[] = array('viewnum', lang('plugin/guiigo_appmanage', 'slang0198'));
	$Portal_orderby_select[] = array('commentnum', lang('plugin/guiigo_appmanage', 'slang0199'));
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_appmanage', 'slang0077'), 'nobottom');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0078'), 'settingnew[second_level_channel]', $setting['second_level_channel'], 'radio');
	showsetting(lang('plugin/guiigo_appmanage', 'slang_10002'), 'settingnew[second_level_channel_color]', $setting['second_level_channel_color'], 'radio');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0079'), array('settingnew[user_interest]', array(array(1, lang('plugin/guiigo_appmanage', 'slang_10003'), array('interest' => '')), array(0, lang('plugin/guiigo_appmanage', 'slang_10004'), array('interest' => 'none')))), $setting['user_interest'] ? $setting['user_interest'] : 0, 'mradio2');
	showtagheader('tbody', 'interest', $setting['user_interest'] ? $setting['user_interest'] : 0, 'sub');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0081'), 'settingnew[user_follow_uids]', $setting['user_follow_uids'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0009'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang_10005'), 'settingnew[user_follow_tabbg]', $setting['user_follow_tabbg'], 'text', '', lang('plugin/guiigo_appmanage', 'slang_10007'));
	showtagfooter('tbody');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0143'), 'settingnew[module_ids]', $setting['module_ids'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0053'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang_10006'), 'settingnew[recommend_tabbg]', $setting['recommend_tabbg'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang_10007'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0082'), array('settingnew[recommend_content]', array(array('nocontent', lang('plugin/guiigo_appmanage', 'slang0083'), array('forum' => 'none', 'Portal' => 'none', 'group' => 'none')), array('forum', lang('plugin/guiigo_appmanage', 'slang0055'), array('forum' => '', 'Portal' => 'none', 'group' => 'none')), array('Portal', lang('plugin/guiigo_appmanage', 'slang0056'), array('forum' => 'none', 'Portal' => '', 'group' => 'none')), array('group', lang('plugin/guiigo_appmanage', 'slang0057'), array('forum' => 'none', 'Portal' => 'none', 'group' => '')))), $setting['recommend_content'] ? $setting['recommend_content'] : 'nocontent', 'mradio2');
	showtagheader('tbody', 'forum', $setting['forum'], 'sub');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0058'), '', '', '<select name="settingnew[forum][forumids][]" multiple="multiple" size="10">' . forumselect(0, 0, $setting['forum']['forumids'], true) . '</select>');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0059'), 'settingnew[forum][digest]', $setting['forum']['digest'], 'radio');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0060'), 'settingnew[forum][isimg]', $setting['forum']['isimg'], 'radio');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0061'), 'settingnew[forum][uids]', $setting['forum']['uids'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0062'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0200'), 'settingnew[forum][stick]', $setting['forum']['stick'], 'radio');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0201'), '', '', AppCommon::get_select('settingnew[forum][special][]', $forum_special_select, $setting['forum']['special'], array(0 - 5, lang('plugin/guiigo_appmanage', 'slang0028')), 6));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0202'), 'settingnew[forum][tagkeyword]', $setting['forum']['tagkeyword'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0207'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0203'), 'settingnew[forum][keyword]', $setting['forum']['keyword'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0208'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0204'), '', '', AppCommon::get_select('settingnew[forum][orderby]', $forum_orderby_select, $setting['forum']['orderby'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0205'), '', '', AppCommon::get_select('settingnew[forum][postdateline]', $forum_dateline_select, $setting['forum']['postdateline'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0206'), '', '', AppCommon::get_select('settingnew[forum][lastpost]', $forum_dateline_select, $setting['forum']['lastpost'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0063'), '', '', AppCommon::get_select('settingnew[forum][style]', $forum_style_select, $setting['forum']['style'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showtagfooter('tbody');
	showtagheader('tbody', 'Portal', $setting['Portal'], 'sub');
	$portalcpselect = category_showselect('portal', $setting['Portal']['Portalids']);
	showsetting(lang('plugin/guiigo_appmanage', 'slang0064'), '', '', '<select name="settingnew[Portal][Portalids][]" multiple="multiple" size="10">' . $portalcpselect . '</select>');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0060'), 'settingnew[Portal][isimg]', $setting['Portal']['isimg'], 'radio');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0065'), 'settingnew[Portal][uids]', $setting['Portal']['uids'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0062'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0203'), 'settingnew[Portal][keyword]', $setting['Portal']['keyword'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0208'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0205'), '', '', AppCommon::get_select('settingnew[Portal][postdateline]', $forum_dateline_select, $setting['Portal']['postdateline'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0204'), '', '', AppCommon::get_select('settingnew[Portal[orderby]', $Portal_orderby_select, $setting['Portal']['orderby'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showtagfooter('tbody');
	showtagheader('tbody', 'group', $setting['group'], 'sub');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0067'), 'settingnew[group][groupids]', $setting['group']['groupids'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0142'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0059'), 'settingnew[group][digest]', $setting['group']['digest'], 'radio');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0060'), 'settingnew[group][isimg]', $setting['group']['isimg'], 'radio');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0061'), 'settingnew[group][uids]', $setting['group']['uids'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0062'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0200'), 'settingnew[group][stick]', $setting['group']['stick'], 'radio');
	showsetting(lang('plugin/guiigo_appmanage', 'slang0201'), '', '', AppCommon::get_select('settingnew[group][special][]', $forum_special_select, $setting['group']['special'], array(0 - 5, lang('plugin/guiigo_appmanage', 'slang0028')), 6));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0202'), 'settingnew[group][tagkeyword]', $setting['group']['tagkeyword'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0207'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0203'), 'settingnew[group][keyword]', $setting['group']['keyword'], 'text', '', '', lang('plugin/guiigo_appmanage', 'slang0208'));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0204'), '', '', AppCommon::get_select('settingnew[group][orderby]', $forum_orderby_select, $setting['group']['orderby'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0205'), '', '', AppCommon::get_select('settingnew[group][postdateline]', $forum_dateline_select, $setting['group']['postdateline'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0206'), '', '', AppCommon::get_select('settingnew[group][lastpost]', $forum_dateline_select, $setting['group']['lastpost'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_appmanage', 'slang0063'), '', '', AppCommon::get_select('settingnew[group][style]', $forum_style_select, $setting['group']['style'], array(0, lang('plugin/guiigo_appmanage', 'slang0028'))));
	showtagfooter('tbody');
	showtablefooter();/*Dism��taobao��com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism_taobao_com*/
} else {
	if ($_POST['settingnew']['recommend_content'] == 'nocontent') {
		$_POST['settingnew']['forum'] = array();
		$_POST['settingnew']['Portal'] = array();
		$_POST['settingnew']['group'] = array();
	} elseif ($_POST['settingnew']['recommend_content'] == 'forum') {
		$_POST['settingnew']['Portal'] = array();
		$_POST['settingnew']['group'] = array();
	} elseif ($_POST['settingnew']['recommend_content'] == 'Portal') {
		$_POST['settingnew']['forum'] = array();
		$_POST['settingnew']['group'] = array();
	} elseif ($_POST['settingnew']['recommend_content'] == 'group') {
		$_POST['settingnew']['forum'] = array();
		$_POST['settingnew']['Portal'] = array();
	}
	if (!$_POST['settingnew']['user_interest']) {
		$_POST['settingnew']['user_follow_uids'] = '';
		$_POST['settingnew']['user_follow_tabbg'] = '';
	}
	$appCacheData = array('setIndex' => $_POST['settingnew']);
	if ($settingappmanage) {
		$appCacheData = array_merge($settingappmanage, $appCacheData);
	}
	C::t('common_setting')->update_batch(array('guiigo_appmanage' => serialize($appCacheData)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
function category_showselect($type, $current = array(), $shownull = true)
{
	global $_G;
	if (!in_array($type, array('portal', 'blog', 'album'))) {
		return '';
	}
	loadcache($type . 'category');
	$category = $_G['cache'][$type . 'category'];
	$select = '';
	if ($shownull) {
		$select .= '<option value="">' . lang('portalcp', 'select_category') . '</option>';
	}
	foreach ($category as $value) {
		if ($value['level'] == 0) {
			$selected = in_array($value['catid'], $current) ? 'selected="selected"' : '';
			$select .= '<option value="' . $value['catid'] . '"' . $selected . '>' . $value['catname'] . '</option>';
			if ($value['children']) {
				foreach ($value['children'] as $catid) {
					$selected = in_array($catid, $current) ? 'selected="selected"' : '';
					$select .= '<option value="' . $category[$catid][catid] . '"' . $selected . '>-- ' . $category[$catid][catname] . '</option>';
					if ($category[$catid]['children']) {
						foreach ($category[$catid]['children'] as $catid2) {
							$selected = in_array($catid2, $current) ? 'selected="selected"' : '';
							$select .= '<option value="' . $category[$catid2][catid] . '"' . $selected . '>----' . $category[$catid2][catname] . '</option>';
						}
					}
				}
			}
		}
	}
	return $select;
}