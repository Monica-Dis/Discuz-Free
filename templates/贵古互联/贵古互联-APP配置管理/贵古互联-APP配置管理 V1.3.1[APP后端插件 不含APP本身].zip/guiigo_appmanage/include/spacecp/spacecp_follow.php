<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$ops = array('add', 'del');
$op = in_array($_GET['op'], $ops) ? $_GET['op'] : '';
if ($op == 'add') {
	$followuid = intval($_GET['fuid']);
	if (empty($followuid)) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10025');
		AppCommon::RetMsgJson($msgarr);
	}
	if ($_G['uid'] == $followuid) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10026');
		AppCommon::RetMsgJson($msgarr);
	}
	$special = intval($_GET['special']) ? intval($_GET['special']) : 0;
	$followuser = getuserbyuid($followuid);
	$mutual = 0;
	$followed = C::t('home_follow')->fetch_by_uid_followuid($followuid, $_G['uid']);
	if (!empty($followed)) {
		if ($followed['status'] == '-1') {
			$msgarr['code'] = 0 - 3;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10027');
			AppCommon::RetMsgJson($msgarr);
		}
		$mutual = 1;
		C::t('home_follow')->update_by_uid_followuid($followuid, $_G['uid'], array('mutual' => 1));
	}
	$followed = C::t('home_follow')->fetch_by_uid_followuid($_G['uid'], $followuid);
	if (empty($followed)) {
		$followdata = array('uid' => $_G['uid'], 'username' => $_G['username'], 'followuid' => $followuid, 'fusername' => $followuser['username'], 'status' => 0, 'mutual' => $mutual, 'dateline' => TIMESTAMP);
		C::t('home_follow')->insert($followdata, false, true);
		C::t('common_member_count')->increase($_G['uid'], array('following' => 1));
		C::t('common_member_count')->increase($followuid, array('follower' => 1, 'newfollower' => 1));
		notification_add($followuid, 'follower', 'member_follow_add', array('count' => $count, 'from_id' => $_G['uid'], 'from_idtype' => 'following'), 1);
	} else {
		if ($special) {
			$status = $special == 1 ? 1 : 0;
			C::t('home_follow')->update_by_uid_followuid($_G['uid'], $followuid, array('status' => $status));
			$special = $special == 1 ? 2 : 1;
		} else {
			$msgarr['code'] = 0 - 4;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10028');
			AppCommon::RetMsgJson($msgarr);
		}
	}
	$type = !$special ? 'add' : 'special';
	$msgarr['code'] = 1;
	$msgarr['data'] = array('userlist' => $_GET['returnUser'] ? AppCommon::refreshTokenReturnUser($_G['uid']) : array(), 'fuid' => $followuid, 'type' => $type, 'special' => $special, 'from' => !empty($_GET['from']) ? $_GET['from'] : 'list');
	$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10029');
	AppCommon::RetMsgJson($msgarr);
} elseif ($op == 'del') {
	$delfollowuid = intval($_GET['fuid']);
	if (empty($delfollowuid)) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10030');
		AppCommon::RetMsgJson($msgarr);
	}
	$affectedrows = C::t('home_follow')->delete_by_uid_followuid($_G['uid'], $delfollowuid);
	if ($affectedrows) {
		C::t('home_follow')->update_by_uid_followuid($delfollowuid, $_G['uid'], array('mutual' => 0));
		C::t('common_member_count')->increase($_G['uid'], array('following' => 0 - 1));
		C::t('common_member_count')->increase($delfollowuid, array('follower' => 0 - 1, 'newfollower' => 0 - 1));
	}
	$msgarr['code'] = 1;
	$msgarr['data'] = array('userlist' => $_GET['returnUser'] ? AppCommon::refreshTokenReturnUser($_G['uid']) : array(), 'fuid' => $delfollowuid, 'type' => 'del', 'from' => !empty($_GET['from']) ? $_GET['from'] : 'list');
	$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10031');
	AppCommon::RetMsgJson($msgarr);
}