<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$_GET['type'] = in_array($_GET['type'], array('thread', 'forum', 'group', 'blog', 'album', 'article', 'all')) ? $_GET['type'] : 'all';
if ($_GET['op'] == 'delete') {
	if ($_GET['checkall']) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10018');
		if ($_GET['favorite']) {
			$deletecounter = array();
			$data = C::t('home_favorite')->fetch_all($_GET['favorite']);
			foreach ($data as $dataone) {
				switch ($dataone['idtype']) {
					case 'fid':
						$deletecounter['fids'][] = $dataone['id'];
				}
			}
			if ($deletecounter['fids']) {
				C::t('forum_forum')->update_forum_counter($deletecounter['fids'], 0, 0, 0, 0, 0 - 1);
			}
			C::t('home_favorite')->delete($_GET['favorite'], false, $_G['uid']);
			$msgarr['code'] = 1;
			$msgarr['data'] = $_GET['returnUser'] ? AppCommon::refreshTokenReturnUser($_G['uid']) : array();
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10019');
		}
		AppCommon::RetMsgJson($msgarr);
	} else {
		$favid = intval($_GET['favid']);
		$thevalue = C::t('home_favorite')->fetch($favid);
		if (empty($thevalue) || $thevalue['uid'] != $_G['uid']) {
			$msgarr['code'] = 0 - 1;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10020');
			AppCommon::RetMsgJson($msgarr);
		}
		switch ($thevalue['idtype']) {
			case 'fid':
				C::t('forum_forum')->update_forum_counter($thevalue['id'], 0, 0, 0, 0, 0 - 1);
		}
		C::t('home_favorite')->delete($favid);
		$msgarr['code'] = 1;
		$msgarr['data'] = array('newuserlist' => $_GET['returnUser'] ? AppCommon::refreshTokenReturnUser($_G['uid']) : array(), 'favid' => $favid, 'id' => $thevalue['id']);
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10021');
		AppCommon::RetMsgJson($msgarr);
	}
} else {
	AppCommon::cknewuser();
	$type = empty($_GET['type']) ? '' : $_GET['type'];
	$id = empty($_GET['id']) ? 0 : intval($_GET['id']);
	$spaceuid = empty($_GET['spaceuid']) ? 0 : intval($_GET['spaceuid']);
	$idtype = $title = '';
	switch ($type) {
		case 'thread':
			$idtype = 'tid';
			$thread = C::t('forum_thread')->fetch($id);
			$title = $thread['subject'];
			break;
		case 'forum':
			$idtype = 'fid';
			$foruminfo = C::t('forum_forum')->fetch($id);
			loadcache('forums');
			$forum = $_G['cache']['forums'][$id];
			if (!$forum['viewperm'] || $forum['viewperm'] && forumperm($forum['viewperm']) || strstr($forum['users'], '	' . $_G['uid'] . '	')) {
				$title = !($foruminfo['status'] == 3) ? $foruminfo['name'] : '';
			}
			break;
		case 'blog':
			$idtype = 'blogid';
			$bloginfo = C::t('home_blog')->fetch($id);
			$title = $bloginfo['uid'] == $spaceuid ? $bloginfo['subject'] : '';
			break;
		case 'group':
			$idtype = 'gid';
			$foruminfo = C::t('forum_forum')->fetch($id);
			$title = $foruminfo['status'] == 3 ? $foruminfo['name'] : '';
			break;
		case 'album':
			$idtype = 'albumid';
			$result = C::t('home_album')->fetch($id, $spaceuid);
			$title = $result['albumname'];
			break;
		case 'space':
			$idtype = 'uid';
			$_member = getuserbyuid($id);
			$title = $_member['username'];
			$unset($_member);
			break;
		case 'article':
			$idtype = 'aid';
			$article = C::t('portal_article_title')->fetch($id);
			$title = $article['title'];
	}
	if (empty($idtype) || empty($title)) {
		$msgarr['code'] = 0 - 1;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10022');
		AppCommon::RetMsgJson($msgarr);
	}
	$fav = C::t('home_favorite')->fetch_by_id_idtype($id, $idtype, $_G['uid']);
	if ($fav) {
		$msgarr['code'] = 0 - 2;
		$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10023');
		AppCommon::RetMsgJson($msgarr);
	}
	$fav_count = C::t('home_favorite')->count_by_id_idtype($id, $idtype);
	$arr = array('uid' => intval($_G['uid']), 'idtype' => $idtype, 'id' => $id, 'spaceuid' => $spaceuid, 'title' => getstr($title, 255), 'description' => getstr($_POST['description'], '', 0, 0, 1), 'dateline' => TIMESTAMP);
	$favid = C::t('home_favorite')->insert($arr, true);
	switch ($type) {
		case 'thread':
			C::t('forum_thread')->increase($id, array('favtimes' => 1));
			require_once libfile('function/forum');
			update_threadpartake($id);
			break;
		case 'forum':
			C::t('forum_forum')->update_forum_counter($id, 0, 0, 0, 0, 1);
			break;
		case 'blog':
			C::t('home_blog')->increase($id, $spaceuid, array('favtimes' => 1));
			break;
		case 'group':
			C::t('forum_forum')->update_forum_counter($id, 0, 0, 0, 0, 1);
			break;
		case 'album':
			C::t('home_album')->update_num_by_albumid($id, 1, 'favtimes', $spaceuid);
			break;
		case 'space':
			C::t('common_member_status')->increase($id, array('favtimes' => 1));
			break;
		case 'article':
			C::t('portal_article_count')->increase($id, array('favtimes' => 1));
	}
	$msgarr['code'] = 1;
	$msgarr['data'] = array('newuserlist' => $_GET['returnUser'] ? AppCommon::refreshTokenReturnUser($_G['uid']) : array(), 'type' => $type, 'id' => $id, 'favid' => $favid);
	$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10024');
	AppCommon::RetMsgJson($msgarr);
}