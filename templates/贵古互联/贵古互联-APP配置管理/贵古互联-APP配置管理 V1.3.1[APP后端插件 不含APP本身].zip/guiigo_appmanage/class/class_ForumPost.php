<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class ForumPost
{
	public static function fetch_all_get_post($where, $start, $perpage, $roder = false)
	{
		if (!$roder) {
			$roder = ' BY p.dateline DESC,t.views DESC,t.favtimes DESC,t.comments DESC ';
		}
		if ($where['orderby']) {
			$roder = ' BY t.' . $where['orderby'] . ' DESC ';
		}
		$wheresql = array();
		if ($where['fid']) {
			if (!is_array($where['fid'])) {
				$where['fid'] = explode(',', $where['fid']);
			}
			$wheresql[] = 'p.' . DB::field('fid', $where['fid']);
		}
		if ($where['noauthorid']) {
			$wheresql[] = 't.' . DB::field('authorid', $where['noauthorid'], '<>');
		}
		if ($where['authorid']) {
			if (!is_array($where['authorid'])) {
				$where['authorid'] = explode(',', $where['authorid']);
			}
			$wheresql[] = 'p.' . DB::field('authorid', $where['authorid']);
		}
		if (!$where['postall']) {
			$wheresql[] = 'p.' . DB::field('first', 1);
		}
		$wheresql[] = 'p.' . DB::field('invisible', 0);
		$wheresql[] = 'p.' . DB::field('anonymous', 0);
		$wheresql[] = 'p.' . DB::field('status', 1, '<>');
		if ($where['digest']) {
			$wheresql[] = 't.' . DB::field('digest', $where['digest'], '>=');
		}
		if (is_array($where['special'])) {
			$specialsql = array();
			foreach ($where['special'] as $spv) {
				$specialsql[] = 't.' . DB::field('special', $spv, '<>');
			}
			$wheresql[] = '(' . implode(' OR ', $specialsql) . ')';
		}
		if (!$where['stick']) {
			$specialsql[] = 't.' . DB::field('displayorder', 0, '<=');
		}
		if ($where['tagkeyword'] || $where['keyword']) {
			$tagkeyword = $keyword = array();
			foreach (explode(',', $where['tagkeyword']) as $v1) {
				if ($v1) {
					$tagkeyword[] = 'p.' . DB::field('tags', '%' . $v1 . '%', 'like');
				}
			}
			foreach (explode(',', $where['keyword']) as $v2) {
				if ($v2) {
					$keyword[] = 'p.' . DB::field('subject', '%' . $v2 . '%', 'like');
				}
			}
			$newsql = array_merge($tagkeyword, $keyword);
			if ($newsql) {
				$wheresql[] = '(' . implode(' OR ', $newsql) . ')';
			}
		}
		if ($where['postdateline']) {
			$wheresql[] = 't.' . DB::field('dateline', TIMESTAMP - $where['postdateline'], '>=');
		}
		if ($where['lastpost']) {
			$wheresql[] = 't.' . DB::field('lastpost', TIMESTAMP - $where['attachment'], '>=');
		}
		if ($where['attachment']) {
			$wheresql[] = 't.' . DB::field('attachment', $where['attachment']);
		}
		$wheresql[] = 't.' . DB::field('closed', 0);
		if (!empty($where['isgroup'])) {
			$wheresql[] = 't.' . DB::field('isgroup', $where['isgroup']);
		}
		if (!$wheresql) {
			$wheresql[] = '0';
		}
		$count = DB::fetch_first('SELECT count(*) as count 
			FROM %t p
			LEFT JOIN %t t on t.tid=p.tid
			WHERE %i ', array('forum_post', 'forum_thread', implode(' AND ', $wheresql)));
		if ($count['count']) {
			$data = DB::fetch_all('SELECT p.*,t.*
					FROM %t p
					LEFT JOIN %t t on t.tid=p.tid
					WHERE %i
					ORDER ' . $roder . ' ' . DB::limit($start, $perpage), array('forum_post', 'forum_thread', implode(' AND ', $wheresql)), 'pid');
			return array('count' => $count['count'], 'data' => $data);
		}
		return array('count' => 0, 'data' => array());
	}
	public static function fetch_all_get_Portal_post($where, $start, $perpage, $roder = false)
	{
		if (!$roder) {
			$roder = ' BY a.dateline DESC ';
		}
		if ($where['orderby']) {
			if ($where['orderby'] == 'dateline') {
				$roder = ' BY a.' . $where['orderby'] . ' DESC ';
			} else {
				$roder = ' BY b.' . $where['orderby'] . ' DESC ';
			}
		}
		$wheresql = array();
		if ($where['catid']) {
			if (!is_array($where['catid'])) {
				$where['catid'] = explode(',', $where['catid']);
			}
			$wheresql[] = 'a.' . DB::field('catid', $where['catid']);
		}
		if ($where['pic']) {
			$wheresql[] = 'a.' . DB::field('pic', '', '<>');
		}
		if ($where['uid']) {
			if (!is_array($where['uid'])) {
				$where['uid'] = explode(',', $where['uid']);
			}
			$wheresql[] = 'a.' . DB::field('uid', $where['uid']);
		}
		if ($where['keyword']) {
			$keyword = array();
			foreach (explode(',', $where['keyword']) as $v2) {
				if ($v2) {
					$keyword[] = 'a.' . DB::field('title', '%' . $v2 . '%', 'like');
				}
			}
			if ($keyword) {
				$wheresql[] = '(' . implode(' OR ', $keyword) . ')';
			}
		}
		if ($where['postdateline']) {
			$wheresql[] = 'a.' . DB::field('dateline', TIMESTAMP - $where['postdateline'], '>=');
		}
		$wheresql[] = 'a.' . DB::field('status', 0);
		if (!$wheresql) {
			$wheresql[] = '0';
		}
		$count = DB::fetch_first('SELECT count(*) as count 
			FROM %t a
			LEFT JOIN %t b on b.aid=a.aid 
			LEFT JOIN %t c on c.aid=a.aid
			WHERE %i ', array('portal_article_title', 'portal_article_count', 'portal_article_content', implode(' AND ', $wheresql)));
		if ($count['count']) {
			$data = DB::fetch_all('SELECT a.*,b.*,c.cid,c.aid,c.id,c.idtype,c.content 
				FROM %t a
				LEFT JOIN %t b on b.aid=a.aid 
				LEFT JOIN %t c on c.aid=a.aid
				WHERE %i
				ORDER ' . $roder . ' ' . DB::limit($start, $perpage), array('portal_article_title', 'portal_article_count', 'portal_article_content', implode(' AND ', $wheresql)));
			$resdata = array();
			foreach ($data as $k => $val) {
				$resdata[$k] = $val;
				$attachimg = self::get_Portal_pic($val['aid'], false);
				$resdata[$k] = $resdata[$k] + $attachimg;
			}
			return array('count' => $count['count'], 'data' => $resdata);
		}
		return array('count' => 0, 'data' => array());
	}
	public static function get_Portal_pic($aid, $isthumb = true)
	{
		$config = AppCommon::config();
		$attachs = array('attachsCount' => 0, 'attachsList' => array());
		if (!$aid) {
			return $attachs;
		}
		$cacheconfig = array('optype' => 'get_cache', 'filedir' => 'cache_portal_attach');
		$arg = array('key' => 'cache_portal_attach_' . $aid);
		$cachedata = AppCommon::CacheData($cacheconfig, $arg);
		if ($cachedata) {
			return $cachedata;
		}
		$countImg = DB::result_first('SELECT COUNT(*) FROM %t WHERE aid=%d AND isimage=1', array('portal_attachment', $aid));
		if (!$countImg) {
			return $attachs;
		}
		$attachlist = DB::fetch_all('SELECT * FROM %t WHERE aid=%d AND isimage=1' . DB::limit(0, 6), array('portal_attachment', $aid));
		if (!$attachlist) {
			return $attachs;
		}
		$attacharr = array();
		foreach ($attachlist as $k => $value) {
			$attacharr[$k] = self::pic_get($value['attachid'], $value['attachment'], 'portal', $isthumb, $value['remote'], 1);
			$attacharr[$k]['aid'] = $value['attachid'];
		}
		$attachs['attachsCount'] = $countImg;
		$attachs['attachsList'] = $attacharr;
		if ($config['attach_cache_time']) {
			$cacheconfig = array('optype' => 'set_cache', 'filedir' => 'cache_portal_attach');
			$arg = array('key' => 'cache_portal_attach_' . $aid, 'value' => $attachs, 'life' => 60 * $config['attach_cache_time']);
			AppCommon::CacheData($cacheconfig, $arg);
		}
		return $attachs;
	}
	public static function pic_get($attachid, $filepath, $type, $thumb, $remote, $return_thumb = 1, $hastype = '')
	{
		global $_G;
		$url = $filepath;
		if ($return_thumb && $thumb) {
			$url = getimgthumbname($url);
		}
		if ($remote > 1 && $type == 'album') {
			$type = 'forum';
		}
		$type = $hastype ? '' : $type . '/';
		$attachurl = $_G['siteurl'] . $_G['setting']['attachurl'] . $type . $url;
		$imgPath = DISCUZ_ROOT . $_G['setting']['attachurl'] . $type . $url;
		if ($attach['remote']) {
			$attachurl = $_G['setting']['ftp']['attachurl'] . $type . $url;
			$imgPath = $attachurl;
		}
		$thumbData = AppCommon::thumbImage($imgPath, $attachid, 220, 220);
		$attachData = array('imginfo' => array(), 'pic' => $attachurl);
		if ($thumbData) {
			$attachData = $thumbData;
		}
		$attachData['beforepic'] = $attachurl;
		return $attachData;
	}
	public static function article_title_style($value = array())
	{
		$style = array();
		$highlight = '';
		if ($value['highlight']) {
			$style = explode('|', $value['highlight']);
			$highlight = '';
			$highlight .= $style[0] ? 'color: ' . $style[0] . ';' : '';
			$highlight .= $style[1] ? 'font-weight: bold;' : '';
			$highlight .= $style[2] ? 'font-style: italic;' : '';
			$highlight .= $style[3] ? 'text-decoration: underline;' : '';
		}
		return $highlight;
	}
	public static function fetch_article_url($article)
	{
		global $_G;
		if (!empty($_G['setting']['makehtml']['flag']) && $article && $article['htmlmade']) {
			if (empty($_G['cache']['portalcategory'])) {
				loadcache('portalcategory');
			}
			$caturl = '';
			if (!empty($_G['cache']['portalcategory'][$article['catid']])) {
				$topid = $_G['cache']['portalcategory'][$article['catid']]['topid'];
				$caturl = $_G['cache']['portalcategory'][$topid]['domain'] ? $_G['cache']['portalcategory'][$topid]['caturl'] : '';
			}
			if (strexists($caturl, 'http') === false) {
				$caturl = $_G['siteurl'] . $caturl;
			}
			return $caturl . $article['htmldir'] . $article['htmlname'] . '.' . $_G['setting']['makehtml']['extendname'];
		}
		return $_G['siteurl'] . 'portal.php?mod=view&aid=' . $article['aid'];
	}
	public static function getViewthreadAttachByid($tid, $pids, $cutimg = array())
	{
	}
	public static function getForumdisplayAttachByid($tid, $pid, $isimage = 1, $cutimg = array())
	{
		global $_G;
		$attachs = array('attachsCount' => 0, 'attachsList' => array());
		$config = AppCommon::config();
		$thumbnail = array('one' => array('width' => 400, 'height' => 9999), 'two' => array('width' => 220, 'height' => 220), 'three' => array('width' => 200, 'height' => 200));
		if ($cutimg && $cutimg['one']) {
			$thumbnail = $cutimg;
		}
		$cacheconfig = array('optype' => 'get_cache', 'filedir' => 'cache_forum_attach');
		$arg = array('key' => 'cache_forum_attach_' . $tid . '_' . $pid);
		$cachedata = AppCommon::CacheData($cacheconfig, $arg);
		if ($cachedata) {
			return $cachedata;
		}
		$aidtb = getattachtablebytid($tid);
		if ($aidtb == 'forum_attachment_unused') {
			return $attachs;
		}
		$countImg = DB::result_first('SELECT COUNT(*) FROM %t WHERE tid=%d AND pid=%d AND isimage=%d', array($aidtb, $tid, $pid, $isimage));
		if (!$countImg) {
			return $attachs;
		}
		$attachlist = DB::fetch_all('SELECT * FROM %t WHERE tid=%d AND pid=%d AND isimage=%d ' . DB::limit(0, 6), array($aidtb, $tid, $pid, $isimage));
		if (!$attachlist) {
			return $attachs;
		}
		$attacharr = array();
		foreach ($attachlist as $attach) {
			$attachurl = $_G['siteurl'] . $_G['setting']['attachurl'] . 'forum/';
			$imgPath = DISCUZ_ROOT . $_G['setting']['attachurl'] . 'forum/' . $attach['attachment'];
			if ($attach['remote']) {
				$attachurl = $_G['setting']['ftp']['attachurl'] . 'forum/';
				$imgPath = $attachurl . $attach['attachment'];
			}
			if (empty($attach['readperm']) && empty($attach['price'])) {
				$thumbData = array();
				if ($isimage == 1) {
					if ($countImg == 1) {
						$thumbData = AppCommon::thumbImage($imgPath, $attach['aid'], $thumbnail['one']['width'], $thumbnail['one']['height']);
					} elseif ($countImg == 2) {
						$thumbData = AppCommon::thumbImage($imgPath, $attach['aid'], $thumbnail['two']['width'], $thumbnail['two']['height']);
					} else {
						if ($countImg >= 3) {
							$thumbData = AppCommon::thumbImage($imgPath, $attach['aid'], $thumbnail['three']['width'], $thumbnail['three']['height']);
						}
					}
				}
				$attachData = array('imginfo' => array(), 'pic' => $attachurl . $attach['attachment']);
				if ($thumbData) {
					$attachData = $thumbData;
				}
				$attachData['beforepic'] = $attachurl . $attach['attachment'];
				$attachData['type'] = strtolower(fileext($attach['filename']));
				$attacharr[] = array_merge($attach, (array) $attachData);
			}
		}
		$attachs['attachsCount'] = $countImg;
		$attachs['attachsList'] = $attacharr;
		if ($config['attach_cache_time']) {
			$cacheconfig = array('optype' => 'set_cache', 'filedir' => 'cache_forum_attach');
			$arg = array('key' => 'cache_forum_attach_' . $tid . '_' . $pid, 'value' => $attachs, 'life' => 60 * $config['attach_cache_time']);
			AppCommon::CacheData($cacheconfig, $arg);
		}
		return $attachs;
	}
	public static function messageAnalysis($message)
	{
		if (!$message) {
			return '';
		}
		if (!class_exists('message')) {
			include_once libfile('class/message', 'plugin/guiigo_appmanage');
		}
		$getdata = array('gettext' => true, 'getmiles' => false);
		$messageObj = new message($getdata);
		$message = $messageObj->discuzcode($message);
		return $message['message'];
	}
	public static function get_block_html($bids)
	{
		global $_G;
		include_once libfile('function/block');
		block_get_batch($bids);
		$bidsary = is_array($bids) ? $bids : ($bids ? explode(',', $bids) : array());
		$data = array();
		foreach ($bidsary as $k => $bid) {
			$data[$k] = self::_block_fetch_content($bid);
		}
		return $data;
	}
	public static function _block_fetch_content($bid)
	{
		global $_G;
		$returnarr = array();
		$block = empty($_G['block'][$bid]) ? array() : $_G['block'][$bid];
		if (!$block) {
			return $returnarr;
		}
		block_updatecache($bid, true);
		$block = $_G['block'][$bid];
		$returnarr['moduleName'] = $block['name'];
		$returnarr['moduleList'] = array('html' => '', 'list' => array());
		if ($block['summary']) {
			$returnarr['moduleList']['html'] = $block['summary'];
		}
		$returnarr['moduleList']['list'] = self::_block_template($bid);
		return $returnarr;
	}
	public static function _block_template($bid)
	{
		global $_G;
		$block = empty($_G['block'][$bid]) ? array() : $_G['block'][$bid];
		$theclass = block_getclass($block['blockclass'], false);
		$thestyle = !empty($block['styleid']) ? block_getstyle($block['styleid']) : dunserialize($block['blockstyle']);
		if (empty($block) || empty($theclass) || empty($thestyle)) {
			return array();
		}
		$template = block_build_template($thestyle['template']);
		$dynamicparts = array();
		if (!empty($block['itemlist'])) {
			if ($thestyle['moreurl']) {
				$template = str_replace('{moreurl}', $_G['siteurl'] . 'portal.php?mod=block&bid=' . $bid, $template);
			}
			$fields = array('picwidth' => array(), 'picheight' => array(), 'currentorder' => array());
			if ($block['hidedisplay']) {
				$fields = array_merge($fields, $theclass['fields']);
			} else {
				$thestyle['fields'] = !empty($thestyle['fields']) && is_array($thestyle['fields']) ? $thestyle['fields'] : block_parse_fields($template);
				foreach ($thestyle['fields'] as $k) {
					if (isset($theclass['fields'][$k])) {
						$fields[$k] = $theclass['fields'][$k];
					}
				}
			}
			$order = 0;
			foreach ($block['itemlist'] as $position => $blockitem) {
				$itemid = $blockitem['itemid'];
				$order++;
				$rkey = $rpattern = $rvalue = $rtpl = array();
				$blockitem['fields'] = !empty($blockitem['fields']) ? $blockitem['fields'] : array();
				$blockitem['fields'] = is_array($blockitem['fields']) ? $blockitem['fields'] : dunserialize($blockitem['fields']);
				if (!empty($blockitem['showstyle'])) {
					$blockitem['fields']['showstyle'] = dunserialize($blockitem['showstyle']);
				}
				$blockitem = $blockitem['fields'] + $blockitem;
				$blockitem['picwidth'] = !empty($block['picwidth']) ? intval($block['picwidth']) : 'auto';
				$blockitem['picheight'] = !empty($block['picheight']) ? intval($block['picheight']) : 'auto';
				$blockitem['currentorder'] = $order;
				$blockitem['parity'] = $order % 2;
				$replacearr = array();
				foreach ($fields as $key => $field) {
					$replacevalue = $blockitem[$key];
					if ($blockitem['forumname']) {
						$replacearr['forumname'] = $blockitem['forumname'];
					}
					if ($blockitem['catname']) {
						$replacearr['forumname'] = $blockitem['catname'];
					}
					if ($key == 'url') {
						$replacevalue = $_G['siteurl'] . $replacevalue;
					}
					$field['datatype'] = !empty($field['datatype']) ? $field['datatype'] : '';
					if ($field['datatype'] == 'int') {
						$replacevalue = intval($replacevalue);
					} elseif ($field['datatype'] == 'string') {
						$replacevalue = $replacevalue;
					} elseif ($field['datatype'] == 'date') {
						$replacevalue = strip_tags(dgmdate($replacevalue, $block['dateuformat'] ? 'u' : $block['dateformat'], '9999', $block['dateuformat'] ? $block['dateformat'] : ''));
					} elseif ($field['datatype'] == 'title') {
						$replacevalue = !empty($blockitem['fields']['fulltitle']) ? $blockitem['fields']['fulltitle'] : dhtmlspecialchars($replacevalue);
					} elseif ($field['datatype'] == 'summary') {
						$replacevalue = $replacevalue;
					} elseif ($field['datatype'] == 'pic') {
						if ($blockitem['picflag'] == '1') {
							$replacevalue = $_G['setting']['attachurl'] . $replacevalue;
							if (strexists($replacevalue, 'http') === false) {
								$replacevalue = $_G['siteurl'] . $replacevalue;
							}
						} elseif ($blockitem['picflag'] == '2') {
							$replacevalue = $_G['setting']['ftp']['attachurl'] . $replacevalue;
						}
						$attachs = array();
						$cacheconfig = array('optype' => 'get_cache', 'filedir' => 'cache_block_attach');
						$arg = array('key' => 'cache_block_attach_' . $itemid);
						$cachedata = AppCommon::CacheData($cacheconfig, $arg);
						if ($cachedata) {
							$replacevalue = $cachedata;
						} else {
							$thumbData = AppCommon::thumbImage($replacevalue, $itemid, 400, 350);
							$cacheconfig = array('optype' => 'set_cache', 'filedir' => 'cache_block_attach');
							$arg = array('key' => 'cache_block_attach_' . $itemid, 'value' => $thumbData['pic'], 'life' => 86000);
							AppCommon::CacheData($cacheconfig, $arg);
						}
					}
					$replacearr[$key] = $replacevalue;
					$replacearr['parity'] = $blockitem['parity'];
				}
				$dynamicparts[$position] = $replacearr;
			}
		}
		return $dynamicparts;
	}
}