<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class AppCommon
{
	public static function config()
	{
		global $_G;
		if (empty($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$config = $_G['cache']['plugin']['guiigo_appmanage'];
		$setting;
		if ($_G['setting']['guiigo_appmanage']) {
			$setting = $_G['setting']['guiigo_appmanage'];
		} else {
			$resetting = C::t('common_setting')->fetch_all(array('guiigo_appmanage'));
			$setting = $resetting['guiigo_appmanage'];
		}
		$config['appdata'] = empty($setting) ? array() : (array) unserialize($setting);
		$config['tpldata'] = array('forumconfig' => array(), 'menuconfig' => array(), 'userconfig' => array());
		$tpldata = self::getGuiigoManageSetting();
		if ($tpldata) {
			$config['tpldata']['forumconfig'] = $tpldata['forumconfig'] ? $tpldata['forumconfig'] : array();
			$config['tpldata']['menuconfig'] = $tpldata['menuconfig'] ? $tpldata['menuconfig'] : array();
			$config['tpldata']['userconfig'] = $tpldata['userconfig'] ? $tpldata['userconfig'] : array();
			if ($config['tpldata']['userconfig']) {
				$config['tpldata']['userconfig']['show_ad_slide'] = self::GetTypeArr($config['tpldata']['userconfig']['show_ad_slide']);
			}
			$config['default_style'] = $_G['cache']['plugin']['guiigo_manage']['default_style'];
		}
		$config['codedata'] = $_G['cache']['plugin']['guiigo_login']['code_time'];
		$config['StarCover'] = $config['StarCover'] ? explode(PHP_EOL, $config['StarCover']) : array();
		$config['bbname'] = $_G['setting']['bbname'];
		$config['siteurl'] = $_G['siteurl'];
		$config['isguiigoapp'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'guiigoapp') === false);
		return $config;
	}
	public static function verifyKey($config)
	{
		global $_G;
		$cache_name = 'guiigo_appmanage_authorization_key';
		if (!function_exists('curl_version')) {
			exit('Please open curl extension');
		}
		loadcache($cache_name);
		$accredit_key = $_G['cache'][$cache_name];
				savecache($cache_name, $res['data']['key']);
				return true;
	}
	public static function intconfig()
	{
		$config = self::config();
		$arrays = array();
		foreach ($config as $key => $val) {
			if (in_array($key, array('bbname', 'siteurl', 'codedata', 'appdata', 'appstart', 'StarCover', 'tpldata', 'default_style', 'alltpl', 'contactUs', 'closesinaweibo', 'closeqq', 'closeweixin', 'closeapple', 'mapkey', 'evalCSS', 'evalJS', 'assignUrl', 'openBar'))) {
				$arrays[$key] = $val;
			}
		}
		self::bindUserCid();
		$resData = AppCommon::savecache('guiigo_appmanage_push');
		$arrays['WebSocketKey'] = $resData['token'];
		return $arrays;
	}
	public static function bindUserCid()
	{
		global $_G;
		global $header;
		$config = self::config();
		$cid = daddslashes($header['cid']);
		$client_type = daddslashes($header['clienttype']);
		$data = array('t_uid' => $_G['uid'], 't_cid' => $cid, 't_groupid' => $_G['groupid'], 't_client_type' => $client_type ? $client_type : 'web', 't_dateline' => TIMESTAMP);
		if ($cid) {
			$ret = C::t('#guiigo_appmanage#guiigo_appmanage_userbind_push')->fetch_by_cid($cid);
			if ($ret['t_id']) {
				if ($_G['uid'] && !$ret['t_uid']) {
					C::t('#guiigo_appmanage#guiigo_appmanage_userbind_push')->update(array('t_uid' => $_G['uid'], 't_groupid' => $_G['groupid']), array('t_id' => $ret['t_id']));
				}
			} else {
				C::t('#guiigo_appmanage#guiigo_appmanage_userbind_push')->insert($data);
			}
		}
	}
	public static function refreshTokenReturnUser($uid)
	{
		global $_G;
		if ($uid <= 0) {
			return array();
		}
		$_G['member'] = $user = getuserbyuid($uid);
		space_merge($user, 'count');
		space_merge($user, 'status');
		space_merge($user, 'field_forum');
		space_merge($user, 'profile');
		space_merge($user, 'verify');
		$user['token'] = self::Tonken($uid);
		$user['avatarurl'] = avatar($uid, 'big', true);
		$user['userstyle'] = array('usertplstyle' => '', 'userHstyle' => '');
		$tpldata = self::getGuiigoManageSetting();
		if ($tpldata) {
			$user['userstyle'] = array('usertplstyle' => $tpldata['usertplstyle'][$_G['uid']], 'userHstyle' => $tpldata['userHstyle'][$_G['uid']]);
		}
		$userStars = self::getUserStars();
		$user['userStars'] = $userStars ? $userStars : 0;
		self::bindUserCid();
		return $user;
	}
	public static function GetVisitorByUid($uid, $start, $perpage)
	{
		$count = C::t('home_visitor')->count_by_uid($uid);
		$list = array();
		if ($count) {
			$visitors = C::t('home_visitor')->fetch_all_by_uid($uid, $start, $perpage);
			foreach ($visitors as $value) {
				$value['uid'] = $value['vuid'];
				$value['username'] = $value['vusername'];
				$list[$value['uid']] = $value;
			}
		}
		return $list;
	}
	public static function GetTypeArr($str)
	{
		$tclx_type = array();
		if (!$str) {
			return array();
		}
		foreach (explode("\r\n", $str) as $key => $val) {
			$type = explode('|', $val);
			if ($type[0]) {
				$tclx_type[$key]['type1'] = $type[0];
				$tclx_type[$key]['type2'] = $type[1];
				if ($type[2]) {
					$tclx_type[$key]['extend1'] = $type[2];
				}
				if ($type[3]) {
					$tclx_type[$key]['extend2'] = $type[3];
				}
			}
		}
		return $tclx_type;
	}
	public static function get_group_selected($groupid = null)
	{
		global $lang;
		$groupselect = array();
		$group_list = C::t('common_usergroup')->range();
		foreach ($group_list as $group) {
			$course = unserialize($groupid);
			$group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
			if (in_array($group['groupid'], $course)) {
				$groupselect[$group['type']] .= '<option value="' . $group['groupid'] . '" selected >' . $group['grouptitle'] . '</option>';
			} else {
				$groupselect[$group['type']] .= '<option value="' . $group['groupid'] . '">' . $group['grouptitle'] . '</option>';
			}
		}
		$groupselect = '<optgroup label="' . $lang['usergroups_member'] . '">' . $groupselect['member'] . '</optgroup>' . ($groupselect['special'] ? '<optgroup label="' . $lang['usergroups_special'] . '">' . $groupselect['special'] . '</optgroup>' : '') . ($groupselect['specialadmin'] ? '<optgroup label="' . $lang['usergroups_specialadmin'] . '">' . $groupselect['specialadmin'] . '</optgroup>' : '') . '<optgroup label="' . $lang['usergroups_system'] . '">' . $groupselect['system'] . '</optgroup>';
		return $groupselect;
	}
	public static function get_select($name, $data, $selected, $initial, $multiplesize = false)
	{
		$multiple = $multiplesize ? 'multiple="multiple" size="' . $multiplesize . '"' : '';
		$select = '<select name="' . $name . '" id="' . $name . '" ' . $multiple . '>';
		if ($initial) {
			$select .= '<option value="' . $initial[0] . '">' . $initial[1] . '</option>';
		}
		foreach ($data as $v) {
			$sed = '';
			if (is_array($selected)) {
				foreach ($selected as $val) {
					$sed = $val == $v[0] ? 'selected' : '';
					if ($val == $v[0]) {
						$sed = 'selected';
						break;
					}
				}
			} else {
				$sed = $selected == $v[0] && !$multiplesize ? 'selected' : '';
			}
			$select .= '<option value="' . $v[0] . '" ' . $sed . '>' . $v[1] . '</option>';
		}
		$select .= '</select>';
		return $select;
	}
	public static function CacheData($cacheconfig, $arg)
	{
		if (!class_exists('CacheFile')) {
			include_once libfile('class/CacheFile', 'plugin/guiigo_appmanage');
		}
		$CacheObj;
		if ($CacheObj == NULL) {
			if (!$cacheconfig['filepath']) {
				$cacheconfig['filepath'] = DISCUZ_ROOT . 'source/plugin/guiigo_appmanage/cachefile';
			}
			$CacheObj = CacheFile::instance($cacheconfig);
		}
		switch ($cacheconfig['optype']) {
			case 'set_cache':
				return $CacheObj->set_cache($arg['key'], $arg['value'], $arg['life'], $arg['del_time']);
			case 'get_cache':
				return $CacheObj->get_cache($arg['key']);
			case 'del_cache':
				return $CacheObj->del_cache($arg['key']);
			case 'del_dir':
				return $CacheObj->del_dir($arg['key'], $arg['del_time']);
			case 'object':
				return $CacheObj;
		}
		return false;
	}
	public static function savecache($key, $value = array())
	{
		$cacheconfig = array('optype' => 'get_cache', 'filedir' => 'cache_data');
		if ($key == 'guiigo_appmanage_push') {
			$cacheconfig = array('optype' => 'get_cache', 'filedir' => 'cache_push_data');
		}
		$arg = array('key' => $key);
		if ($value) {
			$cacheconfig['optype'] = 'set_cache';
			$arg['value'] = $value;
			$arg['life'] = 86400;
			$arg['del_time'] = 3600;
			if ($key == 'guiigo_appmanage_push') {
				$arg['life'] = 0;
				$arg['del_time'] = 0;
			}
		}
		return self::CacheData($cacheconfig, $arg);
	}
	public static function thumbImage($imgUrl, $daid, $dw, $dh, $type = 1)
	{
		global $_G;
		if (!class_exists('image')) {
			include_once libfile('class/image');
		}
		$image = new image();
		$systemAttachurl = $_G['setting']['attachurl'];
		$systemAttachdir = $_G['setting']['attachdir'];
		$_G['setting']['attachurl'] = 'source/plugin/guiigo_appmanage/thumbfile/';
		$_G['setting']['attachdir'] = DISCUZ_ROOT . './source/plugin/guiigo_appmanage/thumbfile/';
		$thumbfile = 'image/' . helper_attach::makethumbpath($daid, $dw, $dh);
		$attachurl = helper_attach::attachpreurl();
		$picUrl = $imgUrl;
		if (file_exists($_G['setting']['attachdir'] . $thumbfile)) {
			@unlink($_G['setting']['attachdir'] . $thumbfile);
		}
		$image->Thumb($imgUrl, $thumbfile, $dw, $dh, $type);
		if (file_exists($_G['setting']['attachdir'] . $thumbfile)) {
			$picUrl = $attachurl . $thumbfile;
		}
		$_G['setting']['attachurl'] = $systemAttachurl;
		$_G['setting']['attachdir'] = $systemAttachdir;
		list($width, $height, $type) = getimagesize($picUrl);
		$imginfo = array('width' => $width, 'height' => $height, 'type' => $type);
		return array('imginfo' => $imginfo, 'pic' => $picUrl);
	}
	public static function DecodeTonken($tonken, $DECODE = true)
	{
		if (empty($tonken)) {
			return false;
		}
		if ($DECODE) {
			$tonken = str_replace(' ', '+', $tonken);
			$tonkens = authcode($tonken, 'DECODE', self::_Getkey());
			$data = explode('|', $tonkens);
			return $data[1];
		}
		return authcode(random(16) . '|' . $tonken, 'ENCODE', self::_Getkey());
	}
	public static function _Getkey()
	{
		global $_G;
		if ($_G['config']['security']['authkey']) {
			return $_G['config']['security']['authkey'];
		}
		$setting = DB::fetch_all('select * from %t', array('common_setting'));
		$authkey = '';
		foreach ($setting as $val) {
			if ($val['skey'] == 'authkey') {
				$authkey = $val['svalue'];
			}
		}
		return $authkey;
	}
	public static function tokenLoadLogin($token)
	{
		global $_G;
		$msgarr = array();
		if (!$token) {
			return false;
		}
		$islogin = self::CheckLonginByTonken($token);
		if (!$islogin) {
			$msgarr['code'] = 1001;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10032') . '-1001';
			self::RetMsgJson($msgarr);
		}
		$uid = self::DecodeTonken($token);
		if (!$uid) {
			$msgarr['code'] = 1001;
			$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10032') . '-10012';
			self::RetMsgJson($msgarr);
		}
		self::loadLoginStatus($uid);
		return $uid;
	}
	public static function loadLoginStatus($uid)
	{
		require_once libfile('function/member');
		loaducenter(); /*dis'.'m.t'.'ao'.'bao.com*/
		$member = getuserbyuid($uid, 1);
		$cookietime = 1296000;
		setloginstatus($member, $cookietime);
	}
	public static function logout()
	{
		global $_G;
		if (!$_G['uid']) {
			return false;
		}
		$cachename = 'app_longin_' . $_G['uid'];
		savecache($cachename, '');
		self::_clearcookies();
		$_G['groupid'] = $_G['member']['groupid'] = 7;
		$_G['uid'] = $_G['member']['uid'] = 0;
		$_G['username'] = $_G['member']['username'] = $_G['member']['password'] = '';
		$_G['setting']['styleid'] = $_G['setting']['styleid'];
		return true;
	}
	public static function _clearcookies()
	{
		global $_G;
		foreach ($_G['cookie'] as $k => $v) {
			if ($k != 'widthauto') {
				dsetcookie($k);
			}
		}
		$_G['uid'] = $_G['adminid'] = 0;
		$_G['username'] = $_G['member']['password'] = '';
	}
	public function _Cache($cachename, $array = '')
	{
		global $_G;
		if (!$cachename) {
			return NULL;
		}
		if (!$array) {
			loadcache($cachename);
			return $_G['cache'][$cachename];
		}
		savecache($cachename, $array);
		return true;
	}
	public static function CheckLonginByTonken($tonken)
	{
		$uid = self::DecodeTonken($tonken);
		if ($uid <= 0) {
			return false;
		}
		$cachename = 'app_longin_' . $uid;
		$userlist = self::_Cache($cachename);
		if (!$userlist || !$userlist['token'] || $userlist['expiration'] < TIMESTAMP || $userlist['uid'] != $uid) {
			savecache($cachename, '');
			return false;
		}
		return $tonken;
	}
	public static function Tonken($uid, $isnew = false, $date = false)
	{
		if (!$date) {
			$date = 1296000;
		}
		$cachename = 'app_longin_' . $uid;
		$newtoken = self::DecodeTonken($uid, false);
		$cachedata = array('uid' => $uid, 'token' => $newtoken, 'expiration' => TIMESTAMP + $date);
		if ($isnew) {
			self::_Cache($cachename, $cachedata);
			return $newtoken;
		}
		$userlist = self::_Cache($cachename);
		if (!$userlist || !$userlist['token'] || $userlist['expiration'] < TIMESTAMP || $userlist['uid'] != $uid) {
			self::_Cache($cachename, $cachedata);
			return $newtoken;
		}
		return $userlist['token'];
	}
	public static function getGuiigoManageSetting()
	{
		global $_G;
		if (in_array('guiigo_manage', $_G['setting']['plugins']['available'])) {
			if ($_G['setting']['guiigo_manage']) {
				$tplsetting = $_G['setting']['guiigo_manage'];
			} else {
				$resetting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
				$tplsetting = $resetting['guiigo_manage'];
			}
			return empty($tplsetting) ? array() : (array) unserialize($tplsetting);
		}
		return false;
	}
	public static function getUserStars()
	{
		global $_G;
		if (!$_G['groupid']) {
			return NULL;
		}
		return DB::result_first('select stars from %t where groupid=%d', array('common_usergroup', $_G['groupid']));
	}
	public function gethotreplybyid($pid, $uid)
	{
		if (!$uid || !$pid) {
			return '';
		}
		return DB::result_first('SELECT pid FROM %t WHERE pid=%d AND uid=%d', array('forum_hotreply_member', $pid, $uid));
	}
	public static function getrecommendbyid($tid, $uid = null, $page = 1, $perpage = 10)
	{
		if ($tid && $uid) {
			return DB::result_first('SELECT recommenduid FROM %t WHERE recommenduid=%d AND tid=%d', array('forum_memberrecommend', $uid, $tid));
		}
		if ($tid) {
			$start = ($page - 1) * $perpage;
			return DB::fetch_all('SELECT a.recommenduid,a.dateline,b.username,b.uid FROM %t a LEFT JOIN %t b on b.uid=a.recommenduid WHERE a.tid=' . $tid . ' AND b.status=0 ORDER BY a.dateline DESC ' . DB::limit($start, $perpage), array('forum_memberrecommend', 'common_member', $tid));
		}
	}
	public static function getUserList($uid, $table, $type = 'tid')
	{
		if (!$uid) {
			return array();
		}
		if (in_array($table, array('status', 'verify', 'count', 'field_forum'))) {
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('common_member_' . $table, $uid));
		}
		if ($table == 'favorite' && $type) {
			$favorite = array();
			if ($type == 'all') {
				$result = DB::fetch_all('SELECT * FROM %t WHERE uid=%d ', array('home_' . $table, $uid));
			} else {
				$result = DB::fetch_all('SELECT * FROM %t WHERE uid=%d and idtype=\'' . $type . '\'', array('home_' . $table, $uid));
			}
			foreach ($result as $v) {
				$favorite[$v['id']]['id'] = $v['id'];
				$favorite[$v['id']]['favid'] = $v['favid'];
				$favorite[$v['id']]['idtype'] = $v['idtype'];
			}
			return $favorite;
		}
		if ($table == 'follow') {
			$follow = array();
			$result = DB::fetch_all('SELECT * FROM %t WHERE uid=%d', array('home_' . $table, $uid));
			foreach ($result as $v) {
				$follow[] = $v['followuid'];
			}
			return $follow;
		}
		if ($table == 'count') {
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('common_member_' . $table, $uid));
		}
		if ($table == 'profile') {
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('common_member_' . $table, $uid));
		}
	}
	public static function diconv_out_utf8($str)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$str = self::iconvArrayA($str);
		} else {
			return $str;
		}
	}
	public static function diconv_u8Tg($str)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$str = self::iconvArrayA($str, 'utf-8', 'gbk');
		} else {
			return $str;
		}
	}
	public static function RetMsgJson($arr, $isecho = true)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$arr = self::iconvArrayA($arr);
		}
		if ($isecho) {
			echo json_encode($arr);
			exit(0);
		} else {
			return json_encode($arr);
		}
	}
	public static function iconvArrayA($data, $in_charset = 'gbk', $out_charset = 'utf-8', $ForceTable = false)
	{
		if (is_array($data)) {
			foreach ($data as $key => $val) {
				$data[$key] = self::iconvArrayA($val, $in_charset, $out_charset, $ForceTable);
			}
			return $data;
		}
		return diconv($data, $in_charset, $out_charset, $ForceTable);
	}
	public static function isphone($phone)
	{
		if (is_numeric($phone)) {
			return preg_match('#^1[3,4,5,7,8,9][\\d]{9}$|^14[5,7]{1}\\d{8}$|^15[^4]{1}\\d{8}$|^17[0,1,6,7,8]{1}\\d{8}$|^18[\\d]{9}$#', $phone) ? true : false;
		}
		return false;
	}
	public static function GetUidByPhone($phone)
	{
		return DB::result_first('select uid from %t where mobile=%s', array('common_member_profile', $phone));
	}
	public static function cknewuser($return = 0)
	{
		global $_G;
		$msgarr = array();
		$result = true;
		if (!$_G['uid']) {
			return true;
		}
		if ($_G['group']['disablepostctrl']) {
			return $result;
		}
		$ckuser = $_G['member'];
		if ($_G['setting']['newbiespan'] && $_G['timestamp'] - $ckuser['regdate'] < $_G['setting']['newbiespan'] * 60) {
			if (empty($return)) {
				$msgarr['code'] = 0 - 1;
				$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10033') . $_G['setting']['newbiespan'] . lang('plugin/guiigo_appmanage', 'slang_10034');
				self::RetMsgJson($msgarr);
			}
			$result = false;
		}
		if ($_G['setting']['need_avatar'] && empty($ckuser['avatarstatus'])) {
			if (empty($return)) {
				$msgarr['code'] = 0 - 2;
				$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10035');
				self::RetMsgJson($msgarr);
			}
			$result = false;
		}
		if ($_G['setting']['need_friendnum']) {
			space_merge($ckuser, 'count');
			if ($ckuser['friends'] < $_G['setting']['need_friendnum']) {
				if (empty($return)) {
					$msgarr['code'] = 0 - 3;
					$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang_10036') . $_G['setting']['need_friendnum'] . lang('plugin/guiigo_appmanage', 'slang_10037');
					self::RetMsgJson($msgarr);
				}
				$result = false;
			}
		}
		return $result;
	}
	public static function getForumByFid($fid)
	{
		global $_G;
		if (!isset($_G['cache']['forumindex'])) {
			loadcache('forumindex');
		}
		$forums = $_G['cache']['forumindex']['forums'];
		$forum_fields = $_G['cache']['forumindex']['forum_fields'];
		foreach ($forums as $key => $vforum) {
			if ($vforum['fid'] == $fid) {
				return array_merge((array) $vforum, (array) $forum_fields[$fid]);
			}
		}
	}
	public static function avatar($uid)
	{
		return avatar($uid, 'small', true);
	}
	public static function dnumber($number)
	{
		return abs($number) > 10000 ? intval($number / 10000) . lang('core', '10k') : $number;
	}
	public static function feedFace($val)
	{
		global $_G;
		preg_match_all('/\\:(.*?)\\:/is', $val, $matches);
		if ($matches[1]) {
			foreach ($matches[1] as $v) {
				$img = '{miles}' . $_G['siteurl'] . STATICURL . 'image/smiley/comcom/' . $v . '.gif{/miles}';
				$val = preg_replace('/\\[(.*?)\\]/is', $img, $val);
			}
		} else {
			if (strexists($val, '{:') !== false) {
				if (!class_exists('message')) {
					include_once libfile('class/message', 'plugin/guiigo_appmanage');
				}
				$messageObj = new message();
				$val = $messageObj->parsesmiles($val);
			}
		}
		return $val;
	}
	public static function dzcutstr($string, $length = 100, $dot = '...')
	{
		if (!function_exists('_dzcutstr')) {
			include_once libfile('function/common', 'plugin/guiigo_appmanage');
		}
		return _dzcutstr($string, $length, $dot);
	}
	public static function getHotreplyIsRecommenus($pids)
	{
		global $_G;
		return DB::fetch_all('SELECT * FROM %t WHERE pid IN (%n) AND uid=%d', array('forum_hotreply_member', $pids, $_G['uid']), 'pid');
	}
	public static function getMemberRecommenus($tids)
	{
		global $_G;
		return DB::fetch_all('SELECT * FROM %t WHERE tid IN (%n) AND recommenduid=%d', array('forum_memberrecommend', $tids, $_G['uid']), 'tid');
	}
	public static function getPostIdsFall($postlist)
	{
		global $_G;
		$tids = $pids = $postusers = $tids = $attachpids = $locationpids = array();
		$pids = array_keys($postlist);
		foreach ($postlist as $pid => $post) {
			$postusers[$post['authorid']] = array();
			$tids[$post['tid']] = array();
			if ($post['attachment']) {
				$attachpids[] = $pid;
			}
			if (getstatus($post['status'], 6)) {
				$locationpids[] = $pid;
			}
		}
		unset($pid);
		unset($post);
		$uids = array_keys($postusers);
		$tids = array_keys($tids);
		return array('pids' => $pids, 'tids' => $tids, 'uids' => $uids, 'attachpids' => $attachpids, 'locationpids' => $locationpids);
	}
	public static function getPostUserListByids($uids)
	{
		global $_G;
		$member_follow = $postusers = $member_verify = $member_field_forum = $member_status = $member_profile = $member_field_home = array();
		if (!$_G['setting']['threadguestlite'] || $_G['uid']) {
			if ($_G['setting']['verify']['enabled']) {
				$member_verify = C::t('common_member_verify')->fetch_all($uids);
				foreach ($member_verify as $uid => $data) {
					foreach ($_G['setting']['verify'] as $vid => $verify) {
						if ($verify['available'] && $verify['showicon']) {
							if ($data['verify' . $vid] == 1) {
								$member_verify[$uid]['verifyicon'][] = array('verifurl' => $_G['siteurl'] . 'home.php?mod=spacecp&ac=profile&op=verify&vid=' . $vid, 'verificon' => $_G['siteurl'] . $verify['icon']);
							} else {
								if (!empty($verify['unverifyicon'])) {
									$member_verify[$uid]['unverifyicon'][] = array('verifurl' => $_G['siteurl'] . 'home.php?mod=spacecp&ac=profile&op=verify&vid=' . $vid, 'verificon' => $_G['siteurl'] . $verify['icon']);
								}
							}
						}
					}
				}
			}
			$member_status = C::t('common_member_status')->fetch_all($uids);
			$member_field_forum = C::t('common_member_field_forum')->fetch_all($uids);
			$member_profile = C::t('common_member_profile')->fetch_all($uids);
			$member_profile = C::t('common_member_profile')->fetch_all($uids);
			if ($_G['uid']) {
				$member_follow = $follow = self::getUserList($_G['uid'], 'follow');
			}
		}
		foreach (C::t('common_member')->fetch_all($uids) as $uid => $postuser) {
			$postuser['memberstatus'] = $postuser['status'];
			$postuser['authorinvisible'] = $member_status[$uid]['invisible'];
			$postuser['signature'] = $member_field_forum[$uid]['sightml'];
			unset($postuser['status']);
			unset($member_status[$uid]['invisible']);
			unset($member_field_forum[$uid]['sightml']);
			$postusers[$uid] = array_merge((array) $member_verify[$uid], (array) $member_profile[$uid], (array) $member_status[$uid], (array) $member_field_forum[$uid], $postuser);
			if ($postusers[$uid]['regdate'] + $postusers[$uid]['oltime'] * 3600 > TIMESTAMP) {
				$postusers[$uid]['oltime'] = 0;
			}
			$postusers[$uid]['isfollow'] = 0;
			if ($_G['uid'] && $_G['uid'] != $uid && !empty($member_follow) && in_array($uid, $member_follow)) {
				$postusers[$uid]['isfollow'] = 1;
			}
			$postusers[$uid]['groupstars'] = 'Lv.' . $_G['cache']['usergroups'][$postuser['groupid']]['stars'];
			$postusers[$uid]['grouptitle'] = strip_tags($_G['cache']['usergroups'][$postuser['groupid']]['grouptitle']);
			$postusers[$uid]['office'] = $postusers[$uid]['position'];
			$postusers[$uid]['groupcolor'] = $_G['cache']['usergroups'][$postuser['groupid']]['color'];
			unset($postusers[$uid]['position']);
		}
		unset($member_field_forum);
		unset($member_status);
		unset($member_profile);
		return $postusers;
	}
	public static function getPostLocationpByids($locationpids)
	{
		$locations = C::t('forum_post_location')->fetch_all($locationpids);
		return $locations;
	}
}