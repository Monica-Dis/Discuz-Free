<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class Group
{
	public static function grouplist($orderby = 'displayorder', $fieldarray = array(), $num = 1, $fids = array(), $sort = 0, $getcount = 0, $grouplevel = array())
	{
		global $_G;
		global $app_uid;
		$query = C::t('forum_forum')->fetch_all_for_grouplist($orderby, $fieldarray, $num, $fids, $sort, $getcount);
		if ($getcount) {
			return $query;
		}
		$grouplist = array();
		foreach ($query as $group) {
			$group['iconstatus'] = $group['icon'] ? 1 : 0;
			isset($group['icon']) && ($group['icon'] = self::get_groupimg($group['icon'], 'icon'));
			isset($group['banner']) && ($group['banner'] = self::get_groupimg($group['banner']));
			$group['orderid'] = $orderid ? intval($orderid) : '';
			isset($group['dateline']) && ($group['dateline'] = $group['dateline'] ? str_replace('&nbsp;', '', dgmdate($group['dateline'], 'd')) : '');
			isset($group['lastupdate']) && ($group['lastupdate'] = $group['lastupdate'] ? str_replace('&nbsp;', '', dgmdate($group['lastupdate'], 'd')) : '');
			$group['level'] = !empty($grouplevel) ? intval($grouplevel[$group['fid']]) : 0;
			isset($group['description']) && ($group['description'] = cutstr($group['description'], 130));
			$group['moderators'] = $group['moderators'] ? dunserialize($group['moderators']) : array();
			$group['name'] = $group['name'];
			$group['pageurl'] = $_G['siteurl'] . 'forum.php?mod=forumdisplay&action=list&fid=' . $group['fid'];
			$group = self::isGroupUser($group, $app_uid);
			$grouplist[$group['fid']] = $group;
			$orderid++;
		}
		return $grouplist;
	}
	public static function isGroupUser($forum, $uid)
	{
		$forum['isgroupuser'] = 0;
		if (!empty($forum['founderuid']) && $forum['founderuid'] == $uid) {
			$forum['isgroupuser'] = 1;
			return $forum;
		}
		if ($uid) {
			$isgroupuser = C::t('forum_groupuser')->fetch_userinfo($uid, $forum['fid']);
			if ($isgroupuser['level'] > 0) {
				$forum['isgroupuser'] = 1;
			}
		}
		return $forum;
	}
	public static function get_groupimg($imgname, $imgtype = '')
	{
		global $_G;
		$imgpath = $_G['siteurl'] . $_G['setting']['attachurl'] . 'group/' . $imgname;
		if ($imgname) {
			return $imgpath;
		}
		if ($imgtype == 'icon') {
			return $_G['siteurl'] . 'static/image/common/groupicon.gif';
		}
		return '';
	}
}