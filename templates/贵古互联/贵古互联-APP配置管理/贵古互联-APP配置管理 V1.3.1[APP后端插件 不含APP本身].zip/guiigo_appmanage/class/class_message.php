<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class message
{
	public $getdata = array('gettext' => false, 'attachlist' => array(), 'getpassword' => true, 'getcode' => true, 'getattach' => true, 'getmiles' => true, 'getmedia' => true, 'getaudio' => true, 'geturl' => true, 'getimg' => true);
	public $returndata = array('message' => '', 'attachstate' => array(), 'quote' => array());
	public function __construct($getdata = array())
	{
		if (isset($getdata)) {
			$this->getdata = array_merge((array) $this->getdata, (array) $getdata);
		}
	}
	public function discuzcode($message)
	{
		global $_G;
		if ($this->getdata['gettext']) {
			$message = preg_replace('/\\[(.*?)\\]\\s*(.*?)\\s*((\\[\\/(.*?)\\])|\\.\\.\\.)/is', '', $message);
			if (strexists($message, '{:') !== false && $this->getdata['getmiles']) {
				$message = $this->parsesmiles($message);
			} else {
				$message = preg_replace('/\\{:(.*?)\\:}/is', '', $message);
			}
			$message = self::_DeleteHtml($message);
			$this->returndata['message'] = $message;
			return $this->returndata;
		}
		if (strpos($message, '[/quote]') !== false) {
			$message = preg_replace_callback("/\\s?\\[quote\\][\n\r]*(.+?)[\n\r]*\\[\\/quote\\]\\s?/is", array(__CLASS__, 'parsequote'), $message);
		}
		if (strpos($message, '[/password]') !== false) {
			if ($authorid != $_G['uid'] && !$_G['forum']['ismoderator'] && $this->getdata['getpassword']) {
				$message = preg_replace_callback('/\\s?\\[password\\](.+?)\\[\\/password\\]\\s?/i', array(__CLASS__, 'parsepassword'), $message);
			} else {
				$message = preg_replace('/\\s?\\[password\\](.+?)\\[\\/password\\]\\s?/i', '', $message);
			}
		}
		if ((strpos($message, '[/code]') || strpos($message, '[/CODE]')) !== false && $this->getdata['getcode']) {
			$message = preg_replace_callback('/\\s?\\[code\\](.+?)\\[\\/code\\]\\s?/is', array(__CLASS__, 'discuzcode_callback_codedisp_1'), $message);
		} else {
			$message = preg_replace('/\\s?\\[code\\](.+?)\\[\\/code\\]\\s?/is', '', $message);
		}
		$msglower = strtolower($message);
		$message = dhtmlspecialchars($message);
		$message = preg_replace('/<script[^\\>]*?>(.*?)<\\/script>/i', '', $message);
		if (strexists($message, '{:') !== false && $this->getdata['getmiles']) {
			$message = $this->parsesmiles($message);
		} else {
			$message = preg_replace('/\\{:(.*?)\\:}/is', '', $message);
		}
		if (strpos($msglower, 'attach://') !== false) {
			$message = preg_replace('/attach:\\/\\/(\\d+)\\.?(\\w*)/i', '', $message);
		}
		if (strpos($msglower, '[/attach]') !== false && $this->getdata['getattach']) {
			$message = preg_replace_callback('/\\[attach\\](\\d+)\\[\\/attach\\]/is', array(__CLASS__, 'discuzcode_callback_attach_1'), $message);
		} else {
			$message = preg_replace('/\\[attach\\](\\d+)\\[\\/attach\\]/is', '', $message);
		}
		if (strpos($msglower, '[/url]') !== false) {
			$message = preg_replace_callback('/\\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\\/\\/|www\\.|mailto:)?([^
\\["\']+?))?\\](.+?)\\[\\/url\\]/is', array(__CLASS__, 'discuzcode_callback_parseurl_152'), $message);
		}
		if (strpos($msglower, '[/email]') !== false) {
			$message = preg_replace_callback('/\\[email(=([a-z0-9\\-_.+]+)@([a-z0-9\\-_]+[.][a-z0-9\\-_.]+))?\\](.+?)\\[\\/email\\]/is', array(__CLASS__, 'discuzcode_callback_parseemail_14'), $message);
		}
		if (strpos($msglower, '[/media]') !== false) {
			$message = preg_replace_callback("/\\[media=([\\w,]+)\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/media\\]/is", array(__CLASS__, 'discuzcode_callback_parsemedia_12'), $message);
		}
		if (strpos($msglower, '[/audio]') !== false) {
			$message = preg_replace_callback("/\\[audio(=1)*\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/audio\\]/is", array(__CLASS__, 'discuzcode_callback_parseaudio_2'), $message);
		}
		if (strpos($msglower, '[/img]') !== false) {
			$message = preg_replace_callback("/\\[img\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/img\\]/is", array(__CLASS__, 'discuzcode_callback_parseimg_1'), $message);
			$message = preg_replace_callback("/\\[img=(\\d{1,4})[x|\\,](\\d{1,4})\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/img\\]/is", array(__CLASS__, 'discuzcode_callback_parseimg_2'), $message);
		}
		unset($msglower);
		$message = preg_replace('/\\[(.*?)\\]\\s*(.*?)\\s*((\\[\\/(.*?)\\])|\\.\\.\\.)/is', '', $message);
		$message = self::_DeleteHtml($message);
		$this->returndata['message'] = $message;
		return $this->returndata;
	}
	public function _DeleteHtml($str)
	{
		$str = trim($str);
		$str = strip_tags($str, '');
		$str = preg_replace('/	/', '', $str);
		$str = preg_replace("/\r\n/", '', $str);
		$str = preg_replace("/\r/", '', $str);
		$str = preg_replace("/\n/", '', $str);
		$str = preg_replace('/ /', '', $str);
		$str = preg_replace('/  /', '', $str);
		return trim($str);
	}
	public function parsepassword($matches)
	{
		if ($matches[1]) {
			return '{password}' . md5($matches[1]) . '{/password}';
		}
		return '';
	}
	public function discuzcode_callback_codedisp_1($matches)
	{
		if ($matches[1]) {
			return '{code}' . $matches[1] . '{/code}';
		}
		return '';
	}
	public function parsesmiles($message)
	{
		global $_G;
		if (!is_array($_G['cache']['smilies'])) {
			loadcache(array('smilies', 'smileytypes'));
		}
		$replacearray = array();
		$enablesmiles = NULL;
		if ($enablesmiles === NULL) {
			$enablesmiles = false;
			if (!empty($_G['cache']['smilies']) && is_array($_G['cache']['smilies'])) {
				foreach ($_G['cache']['smilies']['replacearray'] as $key => $smiley) {
					$label = '<img src="' . $_G['siteurl'] . STATICURL . 'image/smiley/' . $_G['cache']['smileytypes'][$_G['cache']['smilies']['typearray'][$key]]['directory'] . '/' . $smiley . '" smilieid="' . $key . '" border="0" alt="" />';
					$replacearray[$key] = $label;
				}
				$enablesmiles = true;
			}
		}
		$enablesmiles && ($message = preg_replace($_G['cache']['smilies']['searcharray'], $replacearray, $message, $_G['setting']['maxsmilies']));
		$message = preg_replace_callback('/<\\s*img\\s+[^>]*?src\\s*=\\s*(\\\'|")(.*?)\\1[^>]*?\\/?\\s*>/is', array(__CLASS__, 'getmilesurl'), $message);
		return $message;
	}
	public function getmilesurl($matches)
	{
		if ($matches[2]) {
			return '{miles}' . $matches[2] . '{/miles}';
		}
		return '';
	}
	public function discuzcode_callback_attach_1($matches)
	{
		global $_G;
		$attachlist = $this->getdata['attachlist'];
		if ($matches[1] && $attachlist[$matches[1]]) {
			$attach = $attachlist[$matches[1]];
			$attachurl = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['siteurl'] . $_G['setting']['attachurl']) . 'forum/';
			$attachurl = $attachurl . $attach['attachment'];
			array_push($this->returndata['attachstate'], $matches[1]);
			if ($attach['isimage'] == 1) {
				return '{showimg}' . $attachurl . '{/showimg}';
			}
			return self::parsemedia($attachurl, $matches[1]);
		}
		return '';
	}
	public function parsemedia($url, $aid = '')
	{
		$type = strtolower(fileext($url));
		switch ($type) {
			case 'mp3':
			case 'wma':
			case 'ram':
			case 'wav':
				return self::parseaudio($url, $aid);
			case 'mp4':
			case 'mov':
				$attachlist = $this->getdata['attachlist'];
				if ($aid && $attachlist[$aid]['mediapar']) {
					return '{videojson}' . $attachlist[$aid]['mediapar'] . '{/videojson}';
				}
				return '{video}' . $url . '{/video}';
		}
		return $aid ? self::parseattachurl($aid, '', 1) : '';
	}
	public function parseaudio($url, $aid = '')
	{
		$type = strtolower(fileext($url));
		switch ($type) {
			case 'mp3':
			case 'wma':
			case 'ram':
			case 'wav':
				$attachlist = $this->getdata['attachlist'];
				if ($aid && $attachlist[$aid]['mediapar']) {
					return '{audiojson}' . $attachlist[$aid]['mediapar'] . '{/audiojson}';
				}
				return '{audio}' . $url . '{/audio}';
		}
		return $aid ? self::parseattachurl($aid, '', 1) : '';
	}
	public function parseattachurl($aid, $ext, $ignoretid = 0)
	{
		global $_G;
		$attachurl = $_G['siteurl'] . 'forum.php?mod=attachment&aid=' . aidencode($aid, $ext, $ignoretid ? '' : $_G['tid']) . ($ext ? '&request=yes&_f=.' . $ext : '');
		return '{downloadattach}' . $attachurl . '{/downloadattach}';
	}
	public function discuzcode_callback_parseurl_152($matches)
	{
		return self::parseurl($matches[1], $matches[5], $matches[2]);
	}
	public function parseurl($url, $text, $scheme)
	{
		global $_G;
		if (!$url && preg_match('/((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\\/\\/|www\\.)[^\\["\']+/i', trim($text), $matches)) {
			$url = $matches[0];
			$length = 65;
			if (strlen($url) > $length) {
				$text = substr($url, 0, intval($length * 0)) . ' ... ' . substr($url, 0 - intval($length * 0));
			}
			$uri = substr(strtolower($url), 0, 4) == 'www.' ? 'http://' . $url : $url;
			if ($this->getdata['geturl']) {
				return '{url}' . $uri . ($text ? '|' . $text : '') . '{/url}';
			}
			return $uri . $text;
		}
		$url = substr($url, 1);
		if (substr(strtolower($url), 0, 4) == 'www.') {
			$url = 'http://' . $url;
		}
		$url = !$scheme ? $_G['siteurl'] . $url : $url;
		if ($this->getdata['geturl']) {
			return '{url}' . $url . ($text ? '|' . $text : '') . '{/url}';
		}
		return $url . $text;
	}
	public function discuzcode_callback_parseemail_14($matches)
	{
		return self::parseemail($matches[1], $matches[4]);
	}
	public function parseemail($matches, $text)
	{
		$text = str_replace('\\"', '"', $text);
		if (!$email && preg_match('/\\s*([a-z0-9\\-_.+]+)@([a-z0-9\\-_]+[.][a-z0-9\\-_.]+)\\s*/i', $text, $matches)) {
			$email = trim($matches[0]);
			return 'mail:' . $email;
		}
		return 'mail:' . substr($email, 1) . '[' . $text . ']';
	}
	public function discuzcode_callback_parsemedia_12($matches)
	{
		if ($this->getdata['getmedia'] && $matches[2]) {
			return self::parsemedia($matches[2]);
		}
		return '';
	}
	public function discuzcode_callback_parseaudio_2($matches)
	{
		if ($this->getdata['getaudio'] && $matches[2]) {
			return self::parseaudio($matches[2]);
		}
		return '';
	}
	public function discuzcode_callback_parseimg_1($matches)
	{
		if ($this->getdata['getimg'] && $matches[1]) {
			return self::parseimg($matches[1]);
		}
		return '';
	}
	public function discuzcode_callback_parseimg_2($matches)
	{
		if ($this->getdata['getimg'] && $matches[3]) {
			return self::parseimg($matches[3]);
		}
		return '';
	}
	public function parseimg($url)
	{
		return '{showimg}' . $url . '{/showimg}';
	}
	public function parsequote($matches)
	{
		if ($matches[1] && strpos($matches[1], '[/url]') !== false) {
			preg_match('/\\[url(=((https?|ftp|gopher|news|telnet|rtsp|mms|callto|bctp|thunder|qqdl|synacast){1}:\\/\\/|www\\.|mailto:)?([^
\\["\']+?))?\\](.+?)\\[\\/url\\]/is', $matches[1], $urlmatches);
			if ($urlmatches[1]) {
				$quote = array();
				$arr1 = explode('&', $urlmatches[1]);
				foreach ((array) $arr1 as $val) {
					if (strexists($val, 'ptid=') !== false) {
						$quote['tid'] = str_replace('ptid=', '', $val);
					}
					if (strexists($val, 'pid=') !== false) {
						$quote['pid'] = str_replace('pid=', '', $val);
					}
				}
				$this->returndata['quote'] = $quote;
			}
			return '';
		}
		return '';
	}
}