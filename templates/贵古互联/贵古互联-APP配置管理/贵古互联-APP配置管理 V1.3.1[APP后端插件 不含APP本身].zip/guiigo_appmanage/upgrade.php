<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$entire = C::t('#guiigo_appmanage#guiigo_appmanage_userbind_push')->fetch_all_field();

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_guiigo_appmanage_userbind_push` (
  `t_id` int(10) NOT NULL AUTO_INCREMENT,
  `t_uid` int(10) NOT NULL DEFAULT 0,
  `t_cid` varchar(255) NOT NULL DEFAULT '0',
  `t_groupid` int(10) NOT NULL DEFAULT 0,
  `t_client_type` varchar(25) NOT NULL,
  `t_dateline` int(10) NOT NULL,
  PRIMARY KEY (`t_id`),
  KEY `t_uid` (`t_uid`) USING BTREE,
  KEY `t_cid` (`t_cid`) USING BTREE,
  KEY `t_client_type` (`t_client_type`) USING BTREE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;EOF;

if(!$entire['t_id']){
	runquery($sql);
}$finish = TRUE;
?>
