<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!class_exists('AppCommon')){
	include_once libfile('class/AppCommon','plugin/guiigo_appmanage');
}
$config = AppCommon::config();

if(!empty($_GET['api'])){

	$header = array();
	if(!function_exists('apache_request_headers')) {
	   foreach($_SERVER as $key => $value) {
	       if(substr($key, 0, 5) == 'HTTP_') {
	           $header[str_replace(' ', '-', ucwords(str_replace('_', ' ', strtolower(substr($key, 5)))))] = $value;
	       }
	   }
	   unset($key,$value);
	}else{
		$header = apache_request_headers();
	}
	
	if(!empty($header) && is_array($header)){
		foreach($header as $i => $v) {
		    $header[strtolower($i)] = $v;
		}
		unset($i,$v);
	}

	$postData = file_get_contents('php://input');
	if (empty($_POST)) {
		$requests = !empty($postData) ? json_decode($postData, true) : null;
		if ($requests != null && is_array($requests)) {
			$_GET = array_merge((array)$_GET, $requests);
		}
		unset($postData,$requests);
	}

	$msgarr = array();
	$msgarr['code'] = 1000;
	$msgarr['data'] = array();
	$msgarr['msg'] = lang('plugin/guiigo_appmanage', 'slang0002');
	$msgarr['timestamp'] = TIMESTAMP;

	if($_SERVER['REQUEST_METHOD'] == 'OPTIONS'){
		$msgarr['code'] = -1;
		$msgarr['msg'] = 'OPTIONS-ok';
		AppCommon::RetMsgJson($msgarr);
	}

	$api = 'error';
	$app_uid = 0;
	if(in_array($_GET['api'], array(
		'init',
		'login',
		'smssend',
		'getpost',
		'getforum',
		'getgroup',
		'getnewmsg',
		'usertoken',
		'sundry',
		'misc',
		'download',
	))){
	   $api = $_GET['api'];
	}
	
	$token = $header['token'];
	if($token){
		AppCommon::tokenLoadLogin($token);
		$app_uid = $_G['uid'];
	}

	if($_GET['p_dataid']){
		$_GET['id'] = $_GET['p_dataid'];
	}
	
	if(strexists($_GET['api'],'_') !== FALSE){
		list($folder, $filename) = explode('_', $_GET['api']);
		include_once libfile($_GET['api'],'plugin/guiigo_appmanage/api/'.$folder);
	}else{
		include_once libfile('api/'.$api,'plugin/guiigo_appmanage');
	}

}else if($_GET['act'] == 'xyh5'){
	if($_GET['type'] == 1){
		include template('guiigo_appmanage:xyh5');
	}else if($_GET['type'] == 2){
        include template('guiigo_appmanage:ysh5');
	}
}


