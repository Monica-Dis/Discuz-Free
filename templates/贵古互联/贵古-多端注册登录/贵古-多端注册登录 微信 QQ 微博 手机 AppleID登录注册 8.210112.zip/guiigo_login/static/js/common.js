var gajax = new Ajax();
gajax.setRecvType('JSON');
var sendtime = 0;

function paramSerialize(data) {
	if (typeof data === 'object') {
		var str = '';
		var value = '';
		for (var key in data) {
			if (data[key]) {
				value = data[key];
				if (data && data[key].indexOf('&') !== -1) {
					value = data[key].replace(/&/g, escape('&'));
				}
				if (key.indexOf('&') !== -1) {
					key = key.replace(/&/g, escape('&'));
				}
				str += key + '=' + value + '&';
			}
		}
		data = str.substring(0, str.length - 1);
	}
	return data;
}

function smssend(code_time) {
	var mobileReg = /^(13[0-9]|14[5-9]|15[012356789]|166|17[0-8]|18[0-9]|19[8-9])[0-9]{8}$/;
	var _countsec = code_time;
	var countsec = _countsec;
	var phone = $('phone').value;

	if (!mobileReg.test(phone)) {
		showPrompt(null, null, '<span style="font-size:15px;">\u8bf7\u8f93\u5165\u6b63\u786e\u624b\u673a\u53f7</span>', 3000,
			"popuptext");
		return;
	}

	var targetUrl = 'plugin.php?id=guiigo_login:api&api=smssend&act=sms_send&send_type=1&u_phone=' + phone;
	gajax.get(targetUrl, function(res) {
		if (res.code == 1) {
			showPrompt(null, null, '<span style="font-size:15px;">' + res.msg + '</span>', 3000);
			$('subcode').className = 'pcreg-bts pcreg-btsr';
		} else {
			clearInterval(sendtime);
			showPrompt(null, null, '<span style="font-size:15px;">' + res.msg + '</span>', 3000, "popuptext");
		}
	})
	sendtime = setInterval(function() {
		if (countsec == 0) {
			$('subcode').value = '\u83b7\u53d6\u9a8c\u8bc1\u7801';
			$('subcode').className = 'pcreg-bts pcreg-btsc';
			$('code').value = '';
			countsec = _countsec;
			clearInterval(sendtime);
			return;
		} else {
			$('subcode').value = '\u6709\u6548\u65f6\u95f4' + countsec + '\u79d2';
			countsec--;
		}
	}, 1000);
}
