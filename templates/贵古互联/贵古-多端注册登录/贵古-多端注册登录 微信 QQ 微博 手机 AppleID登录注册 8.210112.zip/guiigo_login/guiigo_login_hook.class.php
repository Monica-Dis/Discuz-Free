<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!class_exists('GuiigoLogin')){include_once libfile('class/GuiigoLogin','plugin/guiigo_login');}

class plugin_guiigo_login {

	function common(){
		global $_G;
		$config = GuiigoLogin::config();
	}

	function global_footer(){
		global $_G;
		$config = GuiigoLogin::config();
		$remind_time = getcookie('guiigo_login_mobile_bind_time');
		if($config['mobile_bind_open'] && $_G['uid'] && !$remind_time && $_GET['id'] != 'guiigo_login:bind'){
			$u_mobile = DB::result_first('select u_mobile from %t where u_uid=%d', array('guiigo_login_user', $_G['uid']));
			if(!$u_mobile){
				dsetcookie('guiigo_login_mobile_bind_time', '1', $config['mobile_bind_time']);
				$msgtp = lang('plugin/guiigo_login', 'langs075');
return <<<EOF
<script type="text/javascript">
	showDialog("{$config['mobile_bind_content']}", "confirm","{$msgtp}",
	function(){
		window.location.href= 'home.php?mod=spacecp&ac=plugin&id=guiigo_login:bind';
	},0)
</script>
EOF;

			}
		}
	}
	
	function global_login_extra(){
		return GuiigoLogin::getLoginHtml();
	}

}

class plugin_guiigo_login_member extends plugin_guiigo_login {
	
	function logging_guiigologin_output(){
		global $_G;
		$config = GuiigoLogin::config();
		if($config['mobile_open'] && $_GET['action'] == 'login' && $_GET['viewlostpw'] == 1 && !$_GET['retrieve']){
			include template('guiigo_login:getpassword');
		}
	}
	
	function logging_top(){
		global $_G;
		$config = GuiigoLogin::config();
		$username = daddslashes($_POST['username']);
		if($config['mobile_open'] && !empty($username) && $_GET['action'] == 'login') {
			if(GuiigoLogin::isphone($username)){
		        $uid = GuiigoLogin::GetUidByPhone($username);
				$user = getuserbyuid($uid);
				$_GET['username'] = $_POST['username'] = $user['username'];
			}
		}
	}

	function logging_method(){
		return GuiigoLogin::getLoginHtml(true);
	}
	
	function register_logging_method(){
		return GuiigoLogin::getLoginHtml();
	}

}


class mobileplugin_guiigo_login extends plugin_guiigo_login {
	
	function common(){
        global $_G;
		$config = GuiigoLogin::config();
		if($_G['uid'] && !getcookie('GuiigoLoginTonken')){
			$cookietime = 3600;
			$cookieval = GuiigoLogin::DecodeTonken($_G['uid'],FALSE);
			dsetcookie('GuiigoLoginTonken', $cookieval, $cookietime);
		}
	}

	function global_footer_mobile(){
		global $_G;
		$config = GuiigoLogin::config();
		$remind_time = getcookie('guiigo_login_mobile_bind_time');
		if($config['mobile_bind_open'] && $_G['uid'] && !$remind_time){
			$u_mobile = DB::result_first('select u_mobile from %t where u_uid=%d', array('guiigo_login_user', $_G['uid']));
			if(!$u_mobile){
				dsetcookie('guiigo_login_mobile_bind_time', '1', $config['mobile_bind_time']);
return <<<EOF
<script type="text/javascript">
	$(function(){
		popup.open("{$config['mobile_bind_content']}", "confirm", "plugin.php?id=guiigo_login#/pages/bind");
	})
</script>
EOF;

			}
		}
	}
	
}

class mobileplugin_guiigo_login_member extends mobileplugin_guiigo_login{

	function register_guiigologin_output(){
		global $_G;
		$config = GuiigoLogin::config();
		 if(!$_GET['inajax'] && !$_G['uid'] && $config['plugin_tpl_open'] && !$config['isminiprogram']){
			$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();
		    if(dstrpos($referer,'member.php') !== false){
		       $referer = $_G['siteurl'];
		    }
			$logurl ='plugin.php?id=guiigo_login#/pages/register?lasurl='.urlencode($referer);
			header('Location:' .$logurl);
			exit();
		}
	}
	
	function logging_guiigologin_output(){
		global $_G;
		$config = GuiigoLogin::config();
		if(!$_GET['inajax'] && !$_G['uid'] && $config['plugin_tpl_open'] && !$config['isminiprogram'] && !$config['isguiigoapp']){
			$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();
		    if(dstrpos($referer,'member.php') !== false){
		       $referer = $_G['siteurl'];
		    }
			$logurl ='plugin.php?id=guiigo_login#/?lasurl='.urlencode($referer);
			header('Location:' .$logurl);
			exit();
		}else if($_GET['action'] == 'logout'){
			dsetcookie('GuiigoLoginTonken','');
		}
	}

	function logging_top(){
		global $_G;
		$config = GuiigoLogin::config();
		$username = daddslashes($_POST['username']);
		if($config['mobile_open'] && !empty($username) && $_GET['action'] == 'login' && $_GET['mod'] == 'logging') {
			if(GuiigoLogin::isphone($username)){
	            $uid = GuiigoLogin::GetUidByPhone($username);
				$user = getuserbyuid($uid);
				$_GET['username'] = $_POST['username'] = $user['username'];
			}
		}
	}

	function logging_bottom_mobile(){
		global $_G;
		$config = GuiigoLogin::config();
		$login_tplcode = $config['login_tplcode'];
		$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();
        if(dstrpos($referer,'member.php') !== false){
           $referer = $_G['siteurl'];
        }
		
		$login_tplcode .= '<div class="guiigo_login_login"><div class="guiigo_login_hd">'.lang('plugin/guiigo_login', 'langs074').'</div><div class="guiigo_login_hb">';

		if($config['isminiprogram'] && in_array('guiigo_applet',$_G['setting']['plugins']['available']) && $config['wx_open']){
			$login_tplcode .= '<a href="javascript:;" id="miniProgramlogin" class="guiigo_login_bt" data-no-cache="true"><img src="source/plugin/guiigo_login/static/img/wx.png"></a>';

		}else if($config['wx_open'] && !$config['isminiprogram']){
			$wxlogurl = GuiigoLogin::getCodeUrl('wxweb',$referer,0);
			$login_tplcode .= '<a href="'.$wxlogurl.'" class="guiigo_login_bt" data-no-cache="true"><img src="source/plugin/guiigo_login/static/img/wx.png"></a>';
		}
 
		if(!$config['isminiprogram'] && $config['wb_open']){
	        $wblogurl = GuiigoLogin::getCodeUrl('wbweb',$referer,0);
			$login_tplcode .= '<a href="'.$wblogurl.'" class="guiigo_login_bt" data-no-cache="true"><img src="source/plugin/guiigo_login/static/img/wb.png"></a>';
		}

		if(!$config['isminiprogram'] && $config['qqopen']){
			$qqlogurl = GuiigoLogin::getCodeUrl('qqweb',$referer,0);
			$login_tplcode .= '<a href="'.$qqlogurl.'" class="guiigo_login_bt" data-no-cache="true"><img src="source/plugin/guiigo_login/static/img/qq.png"></a>';
		}

		if($config['mobile_open']){
			$mobilelogurl = $_G['siteurl'].'plugin.php?id=guiigo_login#/pages/mblogin?lasurl='.urlencode($referer);
			$login_tplcode .= '<a href="'.$mobilelogurl.'" class="guiigo_login_bt" data-no-cache="true"><img src="source/plugin/guiigo_login/static/img/sj.png"></a>';
		}
		return $login_tplcode .= '</div></div>';
	}
}
//From: dis'.'m.tao'.'bao.com
?>
