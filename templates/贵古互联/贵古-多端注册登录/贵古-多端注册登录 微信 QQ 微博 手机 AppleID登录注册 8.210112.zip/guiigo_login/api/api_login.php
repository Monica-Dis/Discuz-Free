<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once libfile('class/UserLogin','plugin/guiigo_login');

if($_GET['act'] == 'getUserList'){

    $msgarr['code'] = 1;
	$msgarr['msg'] = 'ok';
	if($_G['uid']) {
		$msgarr['data'] = GuiigoLogin::ReturnUserList($_G['uid']);
	}
	GuiigoLogin::RetMsgJson($msgarr);

}else if($_GET['act'] == 'regUserLogin'){

	$invitecode = daddslashes($_GET['invitecode']);
	$nameData = daddslashes($_GET['nameData']);
	$phoneData = daddslashes($_GET['phoneData']);
	$passData = daddslashes($_GET['passData']);
	$verCode = dintval($_GET['verCode']);
	$seccodehash = daddslashes($_GET['seccodehash']);
	$seccodeverify = daddslashes($_GET['seccodeverify']);

    require_once libfile('function/member');
	$invite = array();
	if($config['invite_verify'] && ($_G['setting']['regstatus'] == 2 || $_G['setting']['regstatus'] == 3)){
        if(!$invitecode) {
        	$msgarr['code'] = -1;
        	$msgarr['msg'] = lang('plugin/guiigo_login', 'langs038');
        	GuiigoLogin::RetMsgJson($msgarr);
        }
		$_GET['invitecode'] = $invitecode;
		$invite = getinvite();
		if(!$invite) {
			$msgarr['code'] = -2;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs039');
			GuiigoLogin::RetMsgJson($msgarr);
		}
	}

	if($config['reg_verify']){
		if(!$seccodeverify) {
			$msgarr['code'] = -3;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs040');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		list($seccodecheck, $secqaacheck) = seccheck('register');
		if(!GuiigoLogin::seccodecheck($seccodecheck)){
			$msgarr['code'] = -4;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs041');
			GuiigoLogin::RetMsgJson($msgarr);
		}
	}

	if($config['mobile_open']){
		if(!$phoneData) {
			$msgarr['code'] = -5;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs034');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		if(empty($verCode)){
			$msgarr['code'] = -6;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs045');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		if(!GuiigoLogin::isphone($phoneData)){
			$msgarr['code'] = -7;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs035');
			GuiigoLogin::RetMsgJson($msgarr);
		}

		$sms_list = GuiigoLogin::getSmsList($phoneData, $verCode);
		if(!$sms_list['t_id']){
			$msgarr['code'] = -8;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs042');
			GuiigoLogin::RetMsgJson($msgarr);
		}

		if(($sms_list['t_notice_date'] + $config['code_time']) < TIMESTAMP){
			$msgarr['code'] = -9;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs043');
			GuiigoLogin::RetMsgJson($msgarr);
		}

		if(GuiigoLogin::GetUidByPhone($phoneData)){
			$msgarr['code'] = -10;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs044');
			GuiigoLogin::RetMsgJson($msgarr);
		}
	}

	GuiigoLogin::UsernameCheck($nameData);
	GuiigoLogin::PasswordCheck($passData);

	if(!$_G['cache']['ipctrl']){loadcache('ipctrl');}
	if($_G['cache']['ipctrl']['ipregctrl']) {
		foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
			if(preg_match("/^(".preg_quote(($ctrlip = trim($ctrlip)), '/').")/", $_G['clientip'])) {
				$ctrlip = $ctrlip.'%';
				$_G['setting']['regctrl'] = $_G['setting']['ipregctrltime']; 
				break;
			} else {
				$ctrlip = $_G['clientip'];
			}
		}
	} else {
		$ctrlip = $_G['clientip'];
	}
	if($_G['setting']['regctrl']) {
		if(C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp']-$_G['setting']['regctrl']*3600)) {
			$msgarr['code'] = -11;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs046').$_G['setting']['regctrl'].lang('plugin/guiigo_login', 'langs047');
			GuiigoLogin::RetMsgJson($msgarr);
		}
	}
	$setregip = false;
	if($_G['setting']['regfloodctrl']) {
		$regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp']-86400);
		if($regip) {
			if($regip['count'] >= $_G['setting']['regfloodctrl']) {
				$msgarr['code'] = -12;
				$msgarr['msg'] = lang('plugin/guiigo_login', 'langs048').$_G['setting']['regfloodctrl'].lang('plugin/guiigo_login', 'langs049');
				GuiigoLogin::RetMsgJson($msgarr);
			} else {
				$setregip = true;
			}
		}
	}

	$email = strtolower(random(10)).$config['reg_email_prefix'];
	$retdata = UserLogin::UserRegister($nameData,$passData,$email);
	if($retdata['code'] == 1){
        $uid = $retdata['data'];
		if($setregip) {
			C::t('common_regip')->update_count_by_ip($_G['clientip']);
		} else {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => 1, 'dateline' => $_G['timestamp']));
		}
		if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
			C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
			if($_G['setting']['regctrl']) {
				C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
			}
		}
	 
		if($invite && $_G['setting']['inviteconfig']['invitegroupid']) {
			$groupid = $_G['setting']['inviteconfig']['invitegroupid'];
		}else{
			if($config['mobile_open']){
				$groupid = $config['mobile_group'] ? $config['mobile_group'] : 10;
			}else{
				$groupid = 10;
			}
		}

		$init_arr = array('credits' => explode(',', $_G['setting']['initcredits']),'emailstatus' => 0);
		C::t('common_member')->insert($uid, $nameData, md5(random(10)), $email, $_G['clientip'], $groupid, $init_arr);
	 
		if(!function_exists('uc_user_login')){
		     loaducenter();
		}
		$result = uc_user_login($nameData,$passData,0);
		if ($result[0] > 0) {
			$member = getuserbyuid($result[0], 1);
			if(isset($member['_inarchive'])) {
				C::t('common_member_archive')->move_to_master($result[0]);
			}
			$cookietime = 1296000;
			setloginstatus($member, $cookietime);
			dsetcookie('lip', $_G['member']['lastip'].','.$_G['member']['lastvisit']);
			C::t('common_member_status')->update($result[0], array('lastip' => $_G['clientip'], 'lastvisit' =>TIMESTAMP, 'lastactivity' => TIMESTAMP));
			include_once libfile('function/stat');
			updatestat('register');
			if(!function_exists('build_cache_userstats')) {
				require_once libfile('cache/userstats', 'function');
			}
			build_cache_userstats();

			if($config['mobile_open'] && $phoneData){
				GuiigoLogin::setLoginBind('u_mobile',$result[0],$phoneData);
			}
			
			if($invite){
				UserLogin::UpInvite($invite,$result[0]);
			}

			UserLogin::Dz_welcome($result[0]);
			
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($result[0]);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs050');
			GuiigoLogin::RetMsgJson($msgarr);

		}else{
			$msgarr['code'] = -14;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs051');
			GuiigoLogin::RetMsgJson($msgarr);
		}

	}else{
		$msgarr['code'] = -13;
		$msgarr['msg'] = $retdata['msg'];
		GuiigoLogin::RetMsgJson($msgarr);
	}

}else if($_GET['act'] == 'userLogin'){

	$nameData = daddslashes($_GET['mobile']);
	$password = daddslashes($_GET['password']);
	$seccodehash = daddslashes($_GET['seccodehash']);
	$seccodeverify = daddslashes($_GET['seccodeverify']);

	if(empty($nameData)){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs052');
		GuiigoLogin::RetMsgJson($msgarr);
	}

	if(empty($password)){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs053');
		GuiigoLogin::RetMsgJson($msgarr);
	}

	if($config['login_verify']){
		if(!$seccodeverify) {
			$msgarr['code'] = -3;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs040');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		if(!GuiigoLogin::seccodecheck(1)){
			$msgarr['code'] = -4;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs041');
			GuiigoLogin::RetMsgJson($msgarr);
		}
	}
    $name = $nameData;
	if(GuiigoLogin::isphone($nameData)){
		$phoneuid = GuiigoLogin::GetUidByPhone($phone);
		$user = getuserbyuid($phoneuid);
		$name = $user['username'];
	}

	$ret = UserLogin::Login($name,$password);
	if($ret['code'] == 1){
		$msgarr['code'] = 1;
		$msgarr['data'] = GuiigoLogin::ReturnUserList($ret['data']['uid']);
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs054');
	}else{
	   $msgarr['code'] = -5;
	   $msgarr['msg'] = $ret['msg'];
	}
	GuiigoLogin::RetMsgJson($msgarr);

}else if($_GET['act'] == 'initPassword'){

	$mobile = daddslashes($_GET['mobile']);
	$password = daddslashes($_GET['password']);
	$code = dintval($_GET['code']);
    GuiigoLogin::PasswordCheck($password);

	if(!$mobile) {
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs034');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	if(empty($code)){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs045');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	if(!GuiigoLogin::isphone($mobile)){
		$msgarr['code'] = -3;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs035');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	
	$sms_list = GuiigoLogin::getSmsList($mobile, $code);
	if(!$sms_list['t_id']){
		$msgarr['code'] = -4;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs042');
		GuiigoLogin::RetMsgJson($msgarr);
	}

	if(($sms_list['t_notice_date'] + $config['code_time']) < TIMESTAMP){
		$msgarr['code'] = -5;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs043');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	
	$mobileuid = GuiigoLogin::GetUidByPhone($mobile);
	if(!$mobileuid){
		$msgarr['code'] = -6;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs055');
		GuiigoLogin::RetMsgJson($msgarr);
	}

	if($mobileuid){
		loaducenter();
		$member = getuserbyuid($mobileuid);
		uc_user_edit($member['username'],$password, $password, '', 1, 0);
		$password = md5(random(10));
		C::t('common_member')->update($mobileuid, array('password' => $password));

		$msgarr['code'] = 1;
		$msgarr['data'] = GuiigoLogin::ReturnUserList($mobileuid);
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs056');
	}else{
		$msgarr['code'] = -7;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs057');
	}
	GuiigoLogin::RetMsgJson($msgarr);

}else if($_GET['act'] == 'userMobileLogin'){

	$mobile = daddslashes($_GET['mobile']);
	$code = dintval($_GET['code']);

	if(!$mobile) {
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs034');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	if(empty($code)){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs045');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	if(!GuiigoLogin::isphone($mobile)){
		$msgarr['code'] = -3;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs035');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	
	$sms_list = GuiigoLogin::getSmsList($mobile, $code);
	if(!$sms_list['t_id']){
		$msgarr['code'] = -4;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs042');
		GuiigoLogin::RetMsgJson($msgarr);
	}

	if(($sms_list['t_notice_date'] + $config['code_time']) < TIMESTAMP){
		$msgarr['code'] = -5;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs043');
		GuiigoLogin::RetMsgJson($msgarr);
	}

	$mobileuid = GuiigoLogin::GetUidByPhone($mobile);
	$hashid	= random(10);
	if(!$mobileuid){
		$name = $config['reg_user_prefix'].strtolower(random(5));
		$userinfo = array(
			'type'=>'mobile',
			'data'=> array('mobile'=>$mobile,'username'=>$name)
		);
		GuiigoLogin::savecache($hashid, $userinfo);
		$msgarr['code'] = 3;
		$msgarr['data'] = array('name' => $name,'dataid'=>$hashid);
		$msgarr['msg'] = 'ok';
		GuiigoLogin::RetMsgJson($msgarr);
	}

	$mobileuidplugin = GuiigoLogin::GetUidByPhoneByplugin($mobile);

	if(!$mobileuidplugin){
		GuiigoLogin::setLoginBind('u_mobile',$mobileuid,$mobile);
	}
	
	$ret = UserLogin::UidLogin($mobileuid);
	if($ret['code'] == 1){
		$msgarr['code'] = 1;
		$msgarr['data'] = GuiigoLogin::ReturnUserList($ret['data']['uid']);
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs054');
	}else{
	   $msgarr['code'] = -6;
	   $msgarr['msg'] = $ret['msg'];
	}
	GuiigoLogin::RetMsgJson($msgarr);

}else if($_GET['act'] == 'userBindLogin'){

	$invitecode = daddslashes($_GET['invitecode']);
	$nameData = daddslashes($_GET['nameData']);
	
	if(!checkmobile()){
		$nameData = diconv($nameData, 'utf-8', CHARSET);
	}

	$passData = daddslashes($_GET['passData']);
	$optype = daddslashes($_GET['optype']);
	$dataid = daddslashes($_GET['dataid']);

	if(empty($optype)){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs059');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	if(empty($nameData)){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs052');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	
	GuiigoLogin::PasswordCheck($passData);

	$userinfo = GuiigoLogin::savecache($dataid);
	if(!$userinfo){
		$msgarr['code'] = -3;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs059');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	
	$binduid = false;
	if($optype == 'bind'){
		$ret = UserLogin::Login($nameData,$passData);
		if($ret['code'] == 1){
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($ret['data']['uid']);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs054');
			$binduid = $ret['data']['uid'];
		}else{
		   $msgarr['code'] = -4;
		   $msgarr['msg'] = $ret['msg'];
		}
	}else if($optype == 'newuser'){

		GuiigoLogin::UsernameCheck($nameData);
		$invite = array();
		if($config['invite_verify'] && ($_G['setting']['regstatus'] == 2 || $_G['setting']['regstatus'] == 3)){
			if(!function_exists('getinvite')){
				require_once libfile('function/member');
			}
		    if(!$invitecode) {
		    	$msgarr['code'] = -5;
		    	$msgarr['msg'] = lang('plugin/guiigo_login', 'langs038');
		    	GuiigoLogin::RetMsgJson($msgarr);
		    }
			$_GET['invitecode'] = $invitecode;
			$invite = getinvite();
			if(!$invite) {
				$msgarr['code'] = -6;
				$msgarr['msg'] = lang('plugin/guiigo_login', 'langs039');
				GuiigoLogin::RetMsgJson($msgarr);
			}
		}

		$email = strtolower(random(10)).$config['reg_email_prefix'];
		$retdata = UserLogin::UserRegister($nameData,$passData,$email);
		if($retdata['code'] == 1){
			$uid = $retdata['data'];
			if($invite && $_G['setting']['inviteconfig']['invitegroupid']) {
				$groupid = $_G['setting']['inviteconfig']['invitegroupid'];
			}else{
				if($userinfo['type'] == 'mobile'){
					$groupid = $config['mobile_group'] ? $config['mobile_group'] : 10;
				}else if($userinfo['type'] == 'wx'){
					$groupid = $config['wx_group'] ? $config['wx_group'] : 10;
				}else if($userinfo['type'] == 'wb'){
					$groupid = $config['wb_group'] ? $config['wb_group'] : 10;
				}else{
					$groupid = 10;
				}
			}

			$init_arr = array('credits' => explode(',', $_G['setting']['initcredits']),'emailstatus' => 0);
			C::t('common_member')->insert($uid, $nameData, md5(random(10)), $email, $_G['clientip'], $groupid, $init_arr);
		 
			if(!function_exists('uc_user_login')){
				loaducenter();
			}

			$result = uc_user_login($nameData,$passData,0);
			if ($result[0] <= 0) {
				$msgarr['code'] = -8;
				$msgarr['msg'] = $retdata['msg'];
				GuiigoLogin::RetMsgJson($msgarr);
			}
			
			if ($result[0] > 0) {
				$member = getuserbyuid($result[0], 1);
				if(isset($member['_inarchive'])) {
					C::t('common_member_archive')->move_to_master($result[0]);
				}
				if(!function_exists('setloginstatus')) {
					require_once libfile('function/member');
				}

				$cookietime = 1296000;
				setloginstatus($member, $cookietime);
				dsetcookie('lip', $_G['member']['lastip'].','.$_G['member']['lastvisit']);
				C::t('common_member_status')->update($result[0], array('lastip' => $_G['clientip'], 'lastvisit' =>TIMESTAMP, 'lastactivity' => TIMESTAMP));

				include_once libfile('function/stat');
				updatestat('register');
				if(!function_exists('build_cache_userstats')) {
					require_once libfile('cache/userstats', 'function');
				}
				build_cache_userstats();

				if($invite){
					UserLogin::UpInvite($invite,$result[0]);
				}

				UserLogin::Dz_welcome($result[0]);

				$msgarr['code'] = 1;
				$msgarr['data'] = GuiigoLogin::ReturnUserList($result[0]);
				$msgarr['msg'] = lang('plugin/guiigo_login', 'langs054');
				$binduid = $result[0];

			}else{
				$msgarr['code'] = -7;
				$msgarr['msg'] = lang('plugin/guiigo_login', 'langs060');
				GuiigoLogin::RetMsgJson($msgarr);
			}
		}else{
			$msgarr['code'] = -8;
			$msgarr['msg'] = $retdata['msg'];
			GuiigoLogin::RetMsgJson($msgarr);
		}
	}

    if($binduid){
		if($optype == 'bind'){
		    if($userinfo['type'] == 'wb'){
				unset($userinfo['data']['avatar_hd']);
			}else if($userinfo['type'] == 'wx' || $userinfo['type'] == 'qq'){
				unset($userinfo['data']['headimgurl']);
			}
		}
		UserLogin::UsernameBind($binduid, $userinfo);
	}
	GuiigoLogin::RetMsgJson($msgarr);

}else if($_GET['act'] == 'wxPcUserBindVerify'){

	$type = daddslashes($_GET['type']);
	if(!$type){
		$type = 'u_wx_openid';
	}

	if(!$_G['uid']){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs061');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$uid = $_G['uid'];
    $restype = DB::result_first('select '.$type.' from %t where u_uid=%d', array('guiigo_login_user',$_G['uid']));
	if($restype){
		$msgarr['code'] = 1;
		$msgarr['msg'] = 'ok';
	}else{
		$msgarr['code'] = 2;
		$msgarr['msg'] = 'await';
	}
	GuiigoLogin::RetMsgJson($msgarr);

}else if($_GET['act'] == 'wxPcUserLoginVerify'){

	$hash = daddslashes($_GET['hash']);
    $userinfo = GuiigoLogin::savecache($hash);
	if(!$userinfo){
		$msgarr['code'] = 3;
		$msgarr['msg'] = 'ok';
		GuiigoLogin::RetMsgJson($msgarr);
	}
	if($userinfo['op'] == 'loginok'){
		$ret = UserLogin::UidLogin($userinfo['data']['uid']);
		if($ret['code'] == 1){
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($ret['data']['uid']);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs054');
		}else{
		   $msgarr['code'] = -2;
		   $msgarr['msg'] = $ret['msg'];
		}
		GuiigoLogin::RetMsgJson($msgarr);
	}else if($userinfo['op'] == 'newuser'){
        $pageurl = 'plugin.php?id=guiigo_login&act=information&optype=newuser&dataid='.$hash;
    	$msgarr['code'] = 2;
    	$msgarr['data'] = array('pageurl'=> $pageurl);
    	$msgarr['msg'] = 'ok';
        GuiigoLogin::RetMsgJson($msgarr);
	}

}else if($_GET['act'] == 'wxUserLogin'){
   
	$optype = daddslashes($_GET['optype']);
	$hash = daddslashes($_GET['hash']);
    $getcode = daddslashes($_GET['getcode']);

	if(!$getcode || !$optype){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs062');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$reslist = UserLogin::WX_getAccessTokenByCode($getcode);
	if(!$reslist['access_token'] || !$reslist['openid']){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs063');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$resWxlist = UserLogin::WX_getUserinfoByAccessToken($reslist['access_token'],$reslist['openid']);
	$u_uid = DB::result_first('select u_uid from %t where u_wx_openid=%s', array('guiigo_login_user',$reslist['openid']));
	if(!$u_uid && $resWxlist['unionid']){
		$u_uid = DB::result_first('select u_uid from %t where u_wx_unionid=%s', array('guiigo_login_user',$reslist['unionid']));
	}
	
	if(!$u_uid && in_array('guiigo_applet',$_G['setting']['plugins']['available']) && $resWxlist['unionid']){
      $u_uid = DB::result_first('select u_uid from %t where u_unionid=%s', array('guiigo_applet_user',$resWxlist['unionid']));
	}

	if(!$u_uid){
		$u_uid = GuiigoLogin::getUidByTable('wx',array('openid'=> $resWxlist['openid'],'unionid'=> $resWxlist['unionid']));
	}

	$userinfo = array(
		'type'=>'wx',
		'data'=> array(
			'openid'=>$resWxlist['openid'],
			'unionid'=>$resWxlist['unionid'],
			'headimgurl'=>$resWxlist['headimgurl'],
			'gender'=>$resWxlist['sex']
		)
	);

	if($u_uid){
		$ret = UserLogin::UidLogin($u_uid);
		if($ret['code'] == 1){
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($ret['data']['uid']);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs054');
            unset($userinfo['data']['headimgurl']);
			UserLogin::UsernameBind($ret['data']['uid'], $userinfo);
			if($optype == 'wxpc'){
				$userinfo['op'] = 'loginok';
				$userinfo['data']['uid'] = $ret['data']['uid'];
				GuiigoLogin::savecache($hash, $userinfo);
			}
		}else{
		   $msgarr['code'] = -3;
		   $msgarr['msg'] = $ret['msg'];
		}
		GuiigoLogin::RetMsgJson($msgarr);
		
	}else{

		$username = GuiigoLogin::diconv_out_nowiconv($resWxlist['nickname']);
        $username = UserLogin::getregname($username);

		if($optype == 'wxpc'){
			$userinfo['op'] = 'newuser';
			$userinfo['data']['username'] = $username;
		}
		GuiigoLogin::savecache($hash, $userinfo);

		$msgarr['code'] = 2;
		$msgarr['data'] = array('name' => $username,'dataid'=>$hash);
		$msgarr['msg'] = 'ok';
		GuiigoLogin::RetMsgJson($msgarr);
	}

}else if($_GET['act'] == 'wbUserLogin'){

    $optype = daddslashes($_GET['optype']);
	$hash = daddslashes($_GET['hash']);
    $getcode = daddslashes($_GET['getcode']);

	if(!$getcode || !$optype){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs062');
		GuiigoLogin::RetMsgJson($msgarr);
	}

	$reslist = UserLogin::WB_getAccessTokenByCode($getcode);
	if(!$reslist['access_token']){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs064');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$access_token = daddslashes($reslist['access_token']);
	$connect_uid = daddslashes($reslist['uid']);
	$u_uid = DB::result_first('select u_uid from %t where u_sina_openid=%s', array('guiigo_login_user',$connect_uid));
	if(!$u_uid){
		$u_uid = GuiigoLogin::getUidByTable('wb',array('openid'=> $connect_uid));
	}

	$resWB = UserLogin::WB_getUserinfoByAccessToken($access_token,$connect_uid);
	$userinfo = array(
		'type'=>'wb',
		'data'=> array(
					'openid'=> $connect_uid,
					'avatar_hd'=>$resWB['avatar_hd'],
					'gender'=> strtolower($resWB['gender'])
				)
	);

	if($u_uid){
		$ret = UserLogin::UidLogin($u_uid);
		if($ret['code'] == 1){
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($ret['data']['uid']);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs054');
			unset($userinfo['data']['avatar_hd']);
			UserLogin::UsernameBind($ret['data']['uid'], $userinfo);
		}else{
		   $msgarr['code'] = -3;
		   $msgarr['msg'] = $ret['msg'];
		}
		GuiigoLogin::RetMsgJson($msgarr);
	}else{
		
		$username = GuiigoLogin::diconv_out_nowiconv($resWB['screen_name']);
		$username = UserLogin::getregname($username);
		$userinfo['data']['username'] = $username;
		GuiigoLogin::savecache($hash, $userinfo);

        $pageurl = $_G['siteurl'].'plugin.php?id=guiigo_login&act=information&optype=newuser&dataid='.$hash.'&name='.$username;
		$msgarr['code'] = 2;
		$msgarr['data'] = array('name' => $username,'dataid'=>$hash,'pageurl'=> $pageurl);
		$msgarr['msg'] = 'ok';
		GuiigoLogin::RetMsgJson($msgarr);
    }
	
}else if($_GET['act'] == 'qqUserLogin'){
	$optype = daddslashes($_GET['optype']);
	$hash = daddslashes($_GET['hash']);
	$getcode = daddslashes($_GET['getcode']);
	
	if(!$getcode || !$optype){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs062');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$access_token = UserLogin::QQ_getAccessTokenByCode($getcode);
	if(!$access_token){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs063');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$openid = UserLogin::QQ_getOpidByAccessToken($access_token);
	if(!$openid){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs063');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$reDatas = DB::fetch_first('select u_uid,u_qq_unionid from %t where u_qq_openid=%s', array('guiigo_login_user',$openid));
	$u_uid = $reDatas['u_uid'];
	$unionid = $reDatas['u_qq_unionid'];
	
	if(!$u_uid || !$unionid){
		$unionid = UserLogin::QQ_getUnionidByAccessToken($access_token);
		if(!$u_uid){
			$u_uid = DB::result_first('select u_uid from %t where u_qq_unionid=%s', array('guiigo_login_user',$unionid));
		}
	}

    $userList = UserLogin::QQ_getUserinfoByAccessToken($access_token,$openid);
	if($userList['ret'] != 0){
		$msgarr['code'] = -2;
		$msgarr['msg'] = 'error get-userList';
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$gender = 1;
	if($userList['gender'] == '&#22899;'){
		$gender = 2;
	}
	$userinfo = array(
		'type'=>'qq',
		'data'=> array(
					'openid'=> $openid,
					'unionid'=> $unionid ? $unionid : '',
					'headimgurl'=> $userList['figureurl_2'] ? $userList['figureurl_2'] : $userList['figureurl_qq_1'],
					'gender'=> $gender
				)
	);
	if($u_uid){
		$ret = UserLogin::UidLogin($u_uid);
		if($ret['code'] == 1){
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($ret['data']['uid']);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs054');
	        unset($userinfo['data']['headimgurl']);
			UserLogin::UsernameBind($ret['data']['uid'], $userinfo);
		}else{
		   $msgarr['code'] = -3;
		   $msgarr['msg'] = $ret['msg'];
		}
		GuiigoLogin::RetMsgJson($msgarr);
	}else{
		$username = GuiigoLogin::diconv_out_nowiconv($userList['nickname']);
		$username = UserLogin::getregname($username);
		$userinfo['data']['username'] = $username;
		GuiigoLogin::savecache($hash, $userinfo);
		
		$pageurl = $_G['siteurl'].'plugin.php?id=guiigo_login&act=information&optype=newuser&dataid='.$hash.'&name='.$username;
		$msgarr['code'] = 2;
		$msgarr['data'] = array('name' => $username,'dataid'=>$hash,'pageurl'=> $pageurl);
		$msgarr['msg'] = 'ok';
		GuiigoLogin::RetMsgJson($msgarr);
	}
	
}else if($_GET['act'] == 'userNameBind'){

    $optype = daddslashes($_GET['optype']);
	$mobile = daddslashes($_GET['mobile']);
	$code = dintval($_GET['code']);
    $getcode = daddslashes($_GET['getcode']);
    $hash = daddslashes($_GET['hash']);
	
	if($hash){
		$luid = GuiigoLogin::savecache($hash);;
		UserLogin::UidLogin($luid);
	}
	
	if(!$_G['uid']){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs065');
		GuiigoLogin::RetMsgJson($msgarr);
	}

	$uid = $_G['uid'];
	if(!$optype){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs066');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	
	if($optype != 'mobile' && empty($getcode)) {
		$msgarr['code'] = -3;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs067');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	
    if($optype == 'mobile'){
		if(!$mobile) {
			$msgarr['code'] = -4;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs034');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		if(empty($code)){
			$msgarr['code'] = -5;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs045');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		if(!GuiigoLogin::isphone($mobile)){
			$msgarr['code'] = -6;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs035');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		
		$sms_list = GuiigoLogin::getSmsList($mobile, $code);
		if(!$sms_list['t_id']){
			$msgarr['code'] = -7;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs042');
			GuiigoLogin::RetMsgJson($msgarr);
		}

		if(($sms_list['t_notice_date'] + $config['code_time']) < TIMESTAMP){
			$msgarr['code'] = -8;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs043');
			GuiigoLogin::RetMsgJson($msgarr);
		}

		$mobileuidplugin = GuiigoLogin::GetUidByPhoneByplugin($mobile);
		if($mobileuidplugin){
			$msgarr['code'] = -9;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs068');
			GuiigoLogin::RetMsgJson($msgarr);
		}

		if($uid){
			$userinfo = array(
				'type'=>'mobile',
				'data'=> array('mobile'=>$mobile)
			);
			UserLogin::UsernameBind($uid, $userinfo);
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($uid);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs069');
			GuiigoLogin::RetMsgJson($msgarr);
		}

	}else if($optype == 'wxpc' || $optype == 'wxweb'){

		$reslist = UserLogin::WX_getAccessTokenByCode($getcode);
		if(!$reslist['access_token'] || !$reslist['openid']){
			$msgarr['code'] = -10;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs063');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		$resWxlist = UserLogin::WX_getUserinfoByAccessToken($reslist['access_token'],$reslist['openid']);
		if($resWxlist['unionid']){
			$u_uid = DB::result_first('select u_uid from %t where u_wx_unionid=%s', array('guiigo_login_user',$resWxlist['unionid']));
		}else{
			$u_uid = DB::result_first('select u_uid from %t where u_wx_openid=%s', array('guiigo_login_user',$reslist['openid']));
		}

		if($u_uid){
			$msgarr['code'] = -11;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs070');
			GuiigoLogin::RetMsgJson($msgarr);
		}else{
			$userinfo = array(
				'type'=>'wx',
				'data'=> array(
							'openid'=>$resWxlist['openid'],
							'unionid'=>$resWxlist['unionid'],
							'gender'=>$resWxlist['sex']
						)
			);
			UserLogin::UsernameBind($uid, $userinfo);
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($uid);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs069');
			GuiigoLogin::RetMsgJson($msgarr);
		}

	}else if($optype == 'wbweb' || $optype == 'wbpc'){

		$reslist = UserLogin::WB_getAccessTokenByCode($getcode);
		if(!$reslist['access_token']){
			$msgarr['code'] = -12;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs064');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		$access_token = daddslashes($reslist['access_token']);
		$connect_uid = daddslashes($reslist['uid']);
		$u_uid = DB::result_first('select u_uid from %t where u_sina_openid=%s', array('guiigo_login_user',$access_token));

		if($u_uid){
			$msgarr['code'] = -13;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs070');
			GuiigoLogin::RetMsgJson($msgarr);
		}else{
			$resWB = UserLogin::WB_getUserinfoByAccessToken($access_token,$connect_uid);
			$userinfo = array(
				'type'=>'wb',
				'data'=> array(
							'openid'=> $connect_uid,
							'gender'=> strtolower($resWB['gender'])
						)
			);

			UserLogin::UsernameBind($uid, $userinfo);
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($uid);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs069');
			GuiigoLogin::RetMsgJson($msgarr);
		}
	}else if($optype == 'qqweb' || $optype == 'qqpc'){
	
	    $access_token = UserLogin::QQ_getAccessTokenByCode($getcode);
	    if(!$access_token){
	    	$msgarr['code'] = -2;
	    	$msgarr['msg'] = lang('plugin/guiigo_login', 'langs063');
	    	GuiigoLogin::RetMsgJson($msgarr);
	    }
	    $openid = UserLogin::QQ_getOpidByAccessToken($access_token);
	    if(!$openid){
	    	$msgarr['code'] = -2;
	    	$msgarr['msg'] = lang('plugin/guiigo_login', 'langs063');
	    	GuiigoLogin::RetMsgJson($msgarr);
	    }
	    $u_uid = DB::result_first('select u_uid from %t where u_qq_openid=%s', array('guiigo_login_user',$openid));
		if($u_uid){
			$msgarr['code'] = -13;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs070');
			GuiigoLogin::RetMsgJson($msgarr);
		}else{
			$unionid = UserLogin::QQ_getUnionidByAccessToken($access_token);
			$userList = UserLogin::QQ_getUserinfoByAccessToken($access_token,$openid);
			if($userList['ret'] != 0){
				$msgarr['code'] = -2;
				$msgarr['msg'] = '&#33719;&#21462;&#29992;&#25143;&#25968;&#25454;&#38169;&#35823;';
				GuiigoLogin::RetMsgJson($msgarr);
			}
			$gender = 1;
			if($userList['gender'] == '&#22899;'){
				$gender = 2;
			}
			$userinfo = array(
				'type'=>'qq',
				'data'=> array(
							'openid'=> $openid,
							'unionid'=> $unionid ? $unionid : '',
							'headimgurl'=> $userList['figureurl_2'] ? $userList['figureurl_2'] : $userList['figureurl_qq_1'],
							'gender'=> $gender
						)
			);
			UserLogin::UsernameBind($uid, $userinfo);
			$msgarr['code'] = 1;
			$msgarr['data'] = GuiigoLogin::ReturnUserList($uid);
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs069');
			GuiigoLogin::RetMsgJson($msgarr);
		}
	}

}else if($_GET['act'] == 'userBindRelieve'){

    $optype = daddslashes($_GET['optype']);

	if(!$_G['uid']){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs065');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$uid = $_G['uid'];

	if(!$optype){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs067');
		GuiigoLogin::RetMsgJson($msgarr);
	}
	$retuser = DB::fetch_first('select * from %t where u_uid=%d', array('guiigo_login_user', $uid));
	
    if($optype == 'mobile'){
		if(!$retuser['u_mobile']){
			$msgarr['code'] = -4;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs071');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		GuiigoLogin::setLoginBind('u_mobile',$uid,'',1);

	}elseif($optype == 'wx'){
		if(!$retuser['u_wx_openid']){
			$msgarr['code'] = -5;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs071');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		GuiigoLogin::setLoginBind('wx',$uid,array('u_wx_openid'=>'','u_wx_unionid'=>''));
	}elseif($optype == 'wb'){
		if(!$retuser['u_sina_openid']){
			$msgarr['code'] = -6;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs071');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		GuiigoLogin::setLoginBind('u_sina_openid',$uid,'');
	}elseif($optype == 'qq'){
		if(!$retuser['u_qq_openid']){
			$msgarr['code'] = -7;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs071');
			GuiigoLogin::RetMsgJson($msgarr);
		}
		GuiigoLogin::setLoginBind('qq',$uid,array('u_qq_openid'=>'','u_qq_unionid'=>''));
	}

	$msgarr['code'] = 1;
	$msgarr['data'] = GuiigoLogin::ReturnUserList($uid);
	$msgarr['msg'] = lang('plugin/guiigo_login', 'langs072');
    GuiigoLogin::RetMsgJson($msgarr);
}
