<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$config = GuiigoLogin::config();

if ($_GET['act'] == 'wxqrcode') {
	$hash = random(16);
	$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();
	if(dstrpos($referer,'member.php') !== false){
	   $referer = $_G['siteurl'];
	}
	if($_GET['bind'] == 1 && $hash && $_G['uid']) {
		GuiigoLogin::savecache($hash, $_G['uid']);
	}
	$wxurl = GuiigoLogin::getCodeUrl('wxpc', $referer, $_GET['bind'], $hash);
	$qrsize = 5;
	$dir = 'source/plugin/guiigo_login/cache/';
	$file = $dir.'guiigo_login_'.$hash.'.jpg';
	
	if (!file_exists($file) || !filesize($file)) {
		dmkdir($dir);
		include_once libfile('class/qrcode', 'plugin/guiigo_login');
		QRcode::png($wxurl, $file, QR_ECLEVEL_L, $qrsize);
	}
	
	$qrcode = base64_encode(file_get_contents($file));
	@unlink($file);
	include template('guiigo_login:wx_qrcode');

} elseif ($_GET['act'] == 'information') {

	$lasurl = $_GET['lasurl'];
	if(dstrpos($lasurl,'member.php') !== false){
	   $lasurl = $_G['siteurl'];
	}
	
	$userinfo = array();
	if ($_GET['dataid']) {
		$dataid = daddslashes($_GET['dataid']);
		$userinfo = GuiigoLogin::savecache($dataid);
	}
	include template('guiigo_login:information');
	
} elseif ($_GET['act'] == 'getpassword') {
	
	include template('guiigo_login:getpassword');
	
} elseif ($_GET['act'] == 'phonelogin') {
	
	$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();
	if(dstrpos($referer,'member.php') !== false){
	   $referer = $_G['siteurl'];
	}
	include template('guiigo_login:phonelogin');
} elseif ($_GET['act'] == 'd') {
		$openid = 'olhDawLjXjT7v1KPmaPYQlNqSykg';
		$unionid = 'orAs9s542xx7iw028TGmVujiLoPE';
		
		$reDatas = DB::fetch_all('select * from %t where u_wx_openid=%s', array('guiigo_login_user',$openid));
		debug($reDatas);
		
}else{
	$URIARR = parse_url($_G['siteurl']);
	$URI_PATH = 'source/plugin/guiigo_login/template/touch/';
	$tpldir = $URI_PATH.'index.php';
	$URI_PATH = $URIARR['path'].$URI_PATH;
	include DISCUZ_ROOT.$tpldir;
}
