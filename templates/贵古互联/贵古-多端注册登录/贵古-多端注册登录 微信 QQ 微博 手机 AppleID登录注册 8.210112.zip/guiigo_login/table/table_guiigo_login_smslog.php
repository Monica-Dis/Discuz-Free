<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_guiigo_login_smslog extends discuz_table{
    public function __construct() {
        $this->_table = 'guiigo_login_smslog';
        $this->_pk = 't_id';
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function get_guiigo_login_smslog_count($where = null){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
		if($where['t_uid']){     
            $sql .=" AND t_uid=%d ";
            $condition[] = $where['t_uid'];
        }
		if($where['t_phone']){
		    $sql .=" AND t_phone=%s ";
		    $condition[] = $where['t_phone'];
		}
		if($where['t_notice_type']){
		    $sql .=" AND t_notice_type=%d ";
		    $condition[] = $where['t_notice_type'];
		}
		if($where['t_notice_state']){
		    $sql .=" AND t_notice_state=%d ";
		    $condition[] = $where['t_notice_state'];
		}
		if($where['t_code']){
		    $sql .=" AND t_code=%d ";
		    $condition[] = $where['t_code'];
		}
		if($where['t_notice_date']){
            $sql .=" AND t_notice_date=%d ";
            $condition[] = $where['t_notice_date'];
        }
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }

	public function get_guiigo_login_smslog_list($start,$size,$where = null){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['t_uid']){     
            $sql .=" AND t_uid=%d ";
            $condition[] = $where['t_uid'];
        }
		if($where['t_phone']){
		    $sql .=" AND t_phone=%s ";
		    $condition[] = $where['t_phone'];
		}
		if($where['t_notice_type']){
		    $sql .=" AND t_notice_type=%d ";
		    $condition[] = $where['t_notice_type'];
		}
		if($where['t_notice_state']){
		    $sql .=" AND t_notice_state=%d ";
		    $condition[] = $where['t_notice_state'];
		}
		if($where['t_code']){
		    $sql .=" AND t_code=%d ";
		    $condition[] = $where['t_code'];
		}
		if($where['t_notice_date']){
            $sql .=" AND t_notice_date=%d ";
            $condition[] = $where['t_notice_date'];
        }
		$sql .= " ORDER BY t_notice_date DESC LIMIT %d,%d ";
		$condition[] = $start;
		$condition[] = $size;
		return DB::fetch_all($sql,$condition);
	}

    public function insert($data){
        return DB::insert($this->_table,$data,true);
    }
	
    public function update($data,$condition){
        return DB::update($this->_table,$data,$condition,true);
    }
	
    public function delete($condition){
        return DB::delete($this->_table, $condition);
    }

	public function get_guiigo_login_smslog_first($where){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['t_id']){     
            $sql .=" AND t_id=%d ";
            $condition[] = $where['t_id'];
        }
		if($where['t_uid']){     
            $sql .=" AND t_uid=%d ";
            $condition[] = $where['t_uid'];
        }
		if($where['t_phone']){
		    $sql .=" AND t_phone=%s ";
		    $condition[] = $where['t_phone'];
		}
		if($where['t_notice_type']){
		    $sql .=" AND t_notice_type=%d ";
		    $condition[] = $where['t_notice_type'];
		}
		if($where['t_notice_state']){
		    $sql .=" AND t_notice_state=%d ";
		    $condition[] = $where['t_notice_state'];
		}
		if($where['t_code']){
		    $sql .=" AND t_code=%d ";
		    $condition[] = $where['t_code'];
		}
		if($where['t_notice_date']){
            $sql .=" AND t_notice_date=%d ";
            $condition[] = $where['t_notice_date'];
        }
		return DB::fetch_first($sql,$condition);
	}
}
//From: Dism_taobao-com
?>