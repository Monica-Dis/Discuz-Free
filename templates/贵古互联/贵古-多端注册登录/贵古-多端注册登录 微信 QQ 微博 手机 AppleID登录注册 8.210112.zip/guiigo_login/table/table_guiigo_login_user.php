<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_guiigo_login_user extends discuz_table{
    public function __construct() {
        $this->_table = 'guiigo_login_user';
        $this->_pk = 'u_id';
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function get_guiigo_login_user_count($where = null){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
		if($where['u_uid']){     
            $sql .=" AND u_uid=%d ";
            $condition[] = $where['u_uid'];
        }
		if($where['u_dateline']){
            $sql .=" AND u_dateline=%d ";
            $condition[] = $where['u_dateline'];
        }
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }

	public function get_guiigo_login_user_list($start,$size,$where = null){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['u_uid']){     
            $sql .=" AND u_uid=%d ";
            $condition[] = $where['u_uid'];
        }
		if($where['u_dateline']){
            $sql .=" AND u_dateline=%d ";
            $condition[] = $where['u_dateline'];
        }
		$sql .= " ORDER BY u_dateline DESC LIMIT %d,%d ";
		$condition[] = $start;
		$condition[] = $size;
		return DB::fetch_all($sql,$condition);
	}

    public function insert($data){
        return DB::insert($this->_table,$data,true);
    }
	
    public function update($data,$condition){
        return DB::update($this->_table,$data,$condition,true);
    }
	
    public function delete($condition){
        return DB::delete($this->_table, $condition);
    }

	public function get_guiigo_login_user_first($where){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['u_id']){     
            $sql .=" AND u_id=%d ";
            $condition[] = $where['u_id'];
        }
		if($where['u_uid']){     
            $sql .=" AND u_uid=%d ";
            $condition[] = $where['u_uid'];
        }
		if($where['u_wx_openid']){
            $sql .=" AND u_wx_openid=%s ";
            $condition[] = $where['u_wx_openid'];
        }
		if($where['u_wx_unionid']){
            $sql .=" AND u_wx_unionid=%s ";
            $condition[] = $where['u_wx_unionid'];
        }
		if($where['u_sina_openid']){
            $sql .=" AND u_sina_openid=%s ";
            $condition[] = $where['u_sina_openid'];
        }
		if($where['u_qq_openid']){
            $sql .=" AND u_qq_openid=%s ";
            $condition[] = $where['u_qq_openid'];
        }
		if($where['u_mobile']){
            $sql .=" AND u_mobile=%s ";
            $condition[] = $where['u_mobile'];
        }
		if($where['u_dateline']){
            $sql .=" AND u_dateline=%d ";
            $condition[] = $where['u_dateline'];
        }
		return DB::fetch_first($sql,$condition);
	}
}
//From: Dism_taobao-com
?>