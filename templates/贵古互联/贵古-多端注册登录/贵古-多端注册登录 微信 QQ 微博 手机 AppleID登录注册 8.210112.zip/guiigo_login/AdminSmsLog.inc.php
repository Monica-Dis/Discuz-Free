<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if (submitcheck('delsubmit')){
	
	if (empty($_POST['delete'])){
		cpmsg(lang('plugin/guiigo_login', 'langs011'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_login&pmod=AdminSmsLog', 'error');
	}else{
		foreach ($_POST['delete'] as $del){
			C::t('#guiigo_login#guiigo_login_smslog')->delete(array('t_id' => $del));
		}
		cpmsg(lang('plugin/guiigo_login', 'langs012'),'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_login&pmod=AdminSmsLog', 'succeed');
	}
	
}else{
	
	$perpage = 20;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage-1)*$perpage;
	$count = C::t('#guiigo_login#guiigo_login_smslog')->get_guiigo_login_smslog_count();
	$mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=guiigo_login&pmod=AdminSmsLog";
	$multipage = multi($count, $perpage,$curpage,$mpurl, 0, 5);
	$s_list = C::t('#guiigo_login#guiigo_login_smslog')->get_guiigo_login_smslog_list($start,$perpage);
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=guiigo_login&pmod=AdminSmsLog','enctype');
	showtableheader(lang('plugin/guiigo_login', 'langs008'));
		showtablerow('class="header"',array('class="td25"'),array(
			'<label><input type="checkbox" name="chkall" class="checkbox" onclick="checkall(this.form,\'delete\')" />'.lang('plugin/guiigo_login', 'langs013').'</label>',
			'ID',
			lang('plugin/guiigo_login', 'langs001'),
			lang('plugin/guiigo_login', 'langs002'),
			lang('plugin/guiigo_login', 'langs003'),
			lang('plugin/guiigo_login', 'langs004'),
			lang('plugin/guiigo_login', 'langs005'),
			lang('plugin/guiigo_login', 'langs006'),
			lang('plugin/guiigo_login', 'langs007'),
		));
		foreach ($s_list as $v) {
			$user = getuserbyuid($v['t_uid']);
			$t_notice_type = '';
			if($v['t_notice_type'] == 1){
				$t_notice_type = lang('plugin/guiigo_login', 'langs009');
			}else{
				$t_notice_type = lang('plugin/guiigo_login', 'langs010');
			}
			showtablerow('', array('class="td25"'), array(
				'<input class="checkbox" type="checkbox" name="delete['.$v['t_id'].']" value="' .$v['t_id'].'">',
				$v['t_id'],
				$user['username'] ? $user['username'] : '--',
				$v['t_phone'],
				$t_notice_type,
				$v['t_notice_state'] == 1 ? '<em style="color:#4CAF50;">'.lang('plugin/guiigo_login', 'langs014').'</em>' :'<em style="color:#FF9800;">'.lang('plugin/guiigo_login', 'langs015').'</em>',
				$v['t_code'],
				$v['t_cause'],
				dgmdate($v['t_notice_date'])
			));
		}
		showsubmit('delsubmit', 'del', '','', $multipage);
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*dism _ taobao _com*/

}
//From: Dism_taobao-com
?>
