<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


if (submitcheck('delsubmit')){
	
	if (empty($_POST['delete'])){
		cpmsg(lang('plugin/guiigo_login', 'langs011'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_login&pmod=AdminUserLog', 'error');
	}else{
		foreach ($_POST['delete'] as $del){
			C::t('#guiigo_login#guiigo_login_user')->delete(array('u_id' => $del));
		}
		cpmsg(lang('plugin/guiigo_login', 'langs012'),'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_login&pmod=AdminUserLog', 'succeed');
	}
	
}else{

	$perpage = 20;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage-1)*$perpage;
	$count = C::t('#guiigo_login#guiigo_login_user')->get_guiigo_login_user_count();
	$mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=guiigo_login&pmod=AdminUserLog";
	$multipage = multi($count, $perpage,$curpage,$mpurl, 0, 5);
	$paylist = C::t('#guiigo_login#guiigo_login_user')->get_guiigo_login_user_list($start,$perpage);
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=guiigo_login&pmod=AdminUserLog','enctype');
	showtableheader(lang('plugin/guiigo_login', 'langs019'));
		showtablerow('class="header"',array('class="td25"'),array(
			lang('plugin/guiigo_login', 'langs020'),
			lang('plugin/guiigo_login', 'langs021'),
			lang('plugin/guiigo_login', 'langs022'),
			lang('plugin/guiigo_login', 'langs105'),
			lang('plugin/guiigo_login', 'langs024'),
			'qq_openid',
			lang('plugin/guiigo_login', 'langs106'),
			lang('plugin/guiigo_login', 'langs026'),
			lang('plugin/guiigo_login', 'langs027'),
			lang('plugin/guiigo_login', 'langs028'),
			lang('plugin/guiigo_login', 'langs029'),
			'QQ',
			'apple',
			lang('plugin/guiigo_login', 'langs030')
		));
		foreach($paylist as $key => $val) {
			$user = getuserbyuid($val['u_uid']);
			showtablerow('header', array(
			'colspan="0" class="td25"',
			'colspan="0" class="td25"',
			'colspan="0" class="td25"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"',
			'colspan="0" class="td32"'
			), array(
				'<input class="checkbox" type="checkbox" name="delete['.$val['u_id'].']" value="' .$val['u_id'].'">',
				$val['u_uid'],
				$user['username'],
				'<img src="'.avatar($val['u_uid'], 'small', true).'" style="width:35px;" />',
				'openid:'.$val['u_wx_openid'].'<br />unionid:'.$val['u_wx_unionid'],
				'openid:'.$val['u_qq_openid'].'<br />unionid:'.$val['u_qq_unionid'],
				$val['u_sina_openid'],
				$val['u_mobile'],
				$val['u_mobile'] ? '<em style="color:#4CAF50;">'.lang('plugin/guiigo_login', 'langs017').'</em>' : '<em style="color:#FF9800;">'.lang('plugin/guiigo_login', 'langs018').'</em>',
				$val['u_wx_openid'] ? '<em style="color:#4CAF50;">'.lang('plugin/guiigo_login', 'langs017').'</em>' : '<em style="color:#FF9800;">'.lang('plugin/guiigo_login', 'langs018').'</em>',
				$val['u_sina_openid'] ? '<em style="color:#4CAF50;">'.lang('plugin/guiigo_login', 'langs017').'</em>' : '<em style="color:#FF9800;">'.lang('plugin/guiigo_login', 'langs018').'</em>',
				$val['u_qq_openid'] ? '<em style="color:#4CAF50;">'.lang('plugin/guiigo_login', 'langs017').'</em>' : '<em style="color:#FF9800;">'.lang('plugin/guiigo_login', 'langs018').'</em>',
				$val['u_apple_openid'] ? '<em style="color:#4CAF50;">'.lang('plugin/guiigo_login', 'langs017').'</em>' : '<em style="color:#FF9800;">'.lang('plugin/guiigo_login', 'langs018').'</em>',
				dgmdate($val['u_dateline'])
			));
		}
		showsubmit('delsubmit',lang('plugin/guiigo_login', 'langs016'), '<label><input type="checkbox" name="chkall" class="checkbox" onclick="checkall(this.form,\'delete\')" />'.lang('plugin/guiigo_login', 'langs013').'</label>','',$multipage,'');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*dism _ taobao _com*/

}
//From: Dism_taobao-com
?>
