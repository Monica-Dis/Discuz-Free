<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class GuiigoLogin
{
	public static function config()
	{
		global $_G;
		if (empty($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$config = $_G['cache']['plugin']['guiigo_login'];
		$config['bbname'] = $_G['setting']['bbname'];
		$config['siteurl'] = $_G['siteurl'];
		$config['bbrules'] = $_G['setting']['bbrules'];
		$config['bbrulestxt'] = $_G['setting']['bbrulestxt'];
		$config['regstatus'] = $_G['setting']['regstatus'];
		$config['al_sms_tpl'] = self::GetTypeArr($config['al_sms_tpl']);
		$config['dxb_sms_tpl'] = self::GetTypeArr($config['dxb_sms_tpl']);
		$config['cookiepre'] = $_G['config']['cookie']['cookiepre'];
		$config['isFromWeixin'] = !(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false);
		$config['isminiprogram'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'miniprogram') === false);
		$config['isguiigoapp'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'guiigoapp') === false);
		$config['p'] = $config['authorization_key'];
		return $config;
	}
	public static function savecache($key, $value = array())
	{
		$cacheconfig = array('optype' => 'get_cache', 'filedir' => 'cache_data');
		$arg = array('key' => $key);
		if ($value) {
			$cacheconfig['optype'] = 'set_cache';
			$arg['value'] = $value;
			$arg['life'] = 86400;
			$arg['del_time'] = 3600;
		}
		return self::CacheData($cacheconfig, $arg);
	}
	public static function CacheData($cacheconfig, $arg)
	{
		if (!class_exists('CacheFile')) {
			include_once libfile('class/CacheFile', 'plugin/guiigo_login');
		}
		$CacheObj;
		if ($CacheObj == NULL) {
			if (!$cacheconfig['filepath']) {
				$cacheconfig['filepath'] = DISCUZ_ROOT . 'source/plugin/guiigo_login/cachefile';
			}
			$CacheObj = CacheFile::instance($cacheconfig);
		}
		switch ($cacheconfig['optype']) {
			case 'set_cache':
				return $CacheObj->set_cache($arg['key'], $arg['value'], $arg['life'], $arg['del_time']);
			case 'get_cache':
				return $CacheObj->get_cache($arg['key']);
			case 'del_cache':
				return $CacheObj->del_cache($arg['key']);
			case 'del_dir':
				return $CacheObj->del_dir($arg['key'], $arg['del_time']);
			case 'object':
				return $CacheObj;
		}
		return false;
	}
	public static function post($url, $data = array())
	{
		if (!function_exists('curl_init')) {
			return '';
		}
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$data = curl_exec($ch);
		if (!$data) {
			error_log(curl_error($ch));
		}
		curl_close($ch);
		return $data;
	}
	public static function verifyKey($config = array())
	{
		global $_G;
		if (!$config) {
			$config = self::config();
		}
		if (!function_exists('curl_version')) {
			exit('Please open curl extension');
		}
				return true;
	}
	public static function GetTypeArr($str)
	{
		$tlparr = array();
		if (!$str) {
			return $tlparr;
		}
		$val = explode('|', $str);
		$tlparr['tlpId'] = $val[0];
		$tlparr['tlpText'] = $val[1];
		$tlparr['tlpSign'] = $val[2];
		return $tlparr;
	}
	public static function diconv_out_nowiconv($str)
	{
		if (strtolower(CHARSET) == 'gbk') {
			return self::iconvArrayA($str, 'utf-8', 'gbk');
		}
		return $str;
	}
	public static function diconv_out_utf8($str)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$str = self::iconvArrayA($str);
		}
		return $str;
	}
	public static function get_select($name, $data, $selected = '', $initial = '', $style = '')
	{
		$select = '<select name="' . $name . '" id="' . $name . '" ' . $style . '>';
		if ($initial) {
			$select .= '<option value="' . $initial[0] . '">' . $initial[1] . '</option>';
		}
		foreach ($data as $v) {
			$sed = $selected == $v[0] ? 'selected' : '';
			$select .= '<option value="' . $v[0] . '" ' . $sed . '>' . $v[1] . '</option>';
		}
		$select .= '</select>';
		return $select;
	}
	public static function RetMsgJson($arr, $isecho = true)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$arr = self::iconvArrayA($arr);
		}
		if ($isecho) {
			echo json_encode($arr);
			exit(0);
		} else {
			return json_encode($arr);
		}
	}
	public static function DecodeTonken($tonken, $DECODE = true)
	{
		if ($DECODE) {
			$tonken = str_replace(' ', '+', $tonken);
			$tonkens = authcode($tonken, 'DECODE', self::_Getkey());
			$data = explode('|', $tonkens);
			return $data[1];
		}
		return authcode(random(16) . '|' . $tonken, 'ENCODE', self::_Getkey());
	}
	public static function _Getkey()
	{
		global $_G;
		if ($_G['config']['security']['authkey']) {
			return $_G['config']['security']['authkey'];
		}
		$setting = DB::fetch_all('select * from %t', array('common_setting'));
		$authkey = '';
		foreach ($setting as $val) {
			if ($val['skey'] == 'authkey') {
				$authkey = $val['svalue'];
			}
		}
		return $authkey;
	}
	public static function loadLoginStatus($uid)
	{
		require_once libfile('function/member');
		loaducenter();
		$member = getuserbyuid($uid, 1);
		$cookietime = 1296000;
		setloginstatus($member, $cookietime);
	}
	public static function seccodecheck($seccodecheck = 0)
	{
		global $_G;
		if (checkperm('seccode')) {
			if ($seccodecheck && !check_seccode($_POST['seccodeverify'], $_POST['seccodehash'], 0, $_POST['seccodemodid'])) {
				return false;
			}
		}
		return true;
	}
	public static function iconvArrayA($data, $in_charset = 'gbk', $out_charset = 'utf-8', $ForceTable = false)
	{
		if (is_array($data)) {
			foreach ($data as $key => $val) {
				$dataA[$key] = self::iconvArrayA($val, $in_charset, $out_charset, $ForceTable);
			}
			return $dataA;
		}
		return diconv($data, $in_charset, $out_charset, $ForceTable);
	}
	public static function ReturnUserList($uid)
	{
		if ($uid <= 0) {
			return array();
		}
		$user = getuserbyuid($uid);
		$user['avatarurl'] = avatar($uid, 'big', true, false, true) . '?' . rand(1000, 9999);
		$retuser = DB::fetch_first('select * from %t where u_uid=%d', array('guiigo_login_user', $uid));
		return array_merge($user, $retuser);
	}
	public static function SendSms($send_type, $phone)
	{
		$config = self::config();
		$code = rand(1000, 9999);
		if ($config['dxb_sms_tpl']) {
			if (!$config['dxb_id'] || !$config['dxb_key']) {
				return false;
			}
			$statusStr = array('0' => lang('plugin/guiigo_login', 'langs086'), '-1' => lang('plugin/guiigo_login', 'langs087'), '-2' => lang('plugin/guiigo_login', 'langs088'), '30' => lang('plugin/guiigo_login', 'langs089'), '40' => lang('plugin/guiigo_login', 'langs090'), '41' => lang('plugin/guiigo_login', 'langs091'), '42' => lang('plugin/guiigo_login', 'langs092'), '43' => lang('plugin/guiigo_login', 'langs093'), '50' => lang('plugin/guiigo_login', 'langs094'), '96' => 'Incorrect key');
			preg_match_all('/\\Q$\\E\\{(.*?)\\}/is', $config['dxb_sms_tpl']['tlpText'], $matches);
			$str = array();
			foreach ($matches[1] as $k => $v) {
				switch ($v) {
					case 'code':
						$str[$k] = $code;
						break;
					case 'time':
						$str[$k] = $config['code_time'];
				}
			}
			$temptxt = str_replace($matches[0], $str, $config['dxb_sms_tpl']['tlpText']);
			$smsid = self::sendsmsinsert($phone, $code, $send_type, 2);
			if ($smsid) {
				$temptxt = self::diconv_out_utf8($temptxt . lang('plugin/guiigo_login', 'langs103') . $config['dxb_sms_tpl']['tlpSign'] . lang('plugin/guiigo_login', 'langs104'));
				$smsapi = 'http://www.smsbao.com/';
				$user = $config['dxb_id'];
				$pass = md5($config['dxb_key']);
				$sendurl = $smsapi . 'sms?u=' . $user . '&p=' . $pass . '&m=' . $phone . '&c=' . urlencode($temptxt);
				$result = dfsockopen($sendurl);
				if ($result == 0) {
					C::t('#guiigo_login#guiigo_login_smslog')->update(array('t_notice_state' => 1, 't_cause' => $statusStr[$result]), array('t_id' => $smsid));
					return true;
				}
				C::t('#guiigo_login#guiigo_login_smslog')->update(array('t_cause' => $statusStr[$result]), array('t_id' => $smsid));
			}
		} elseif ($config['al_sms_tpl']) {
			if (!$config['al_accessid'] || !$config['al_accessidkey']) {
				return false;
			}
			$SignName = self::diconv_out_utf8($config['al_sms_tpl']['tlpSign']);
			$accessKeyId = $config['al_accessid'];
			$accessKeySecret = $config['al_accessidkey'];
			preg_match_all('/\\Q$\\E\\{(.*?)\\}/is', $config['al_sms_tpl']['tlpText'], $matches);
			$TemplateParam = array();
			foreach ($matches[1] as $k => $v) {
				switch ($v) {
					case 'code':
						$TemplateParam['code'] = $code;
						break;
					case 'time':
						$TemplateParam['time'] = $config['code_time'];
				}
			}
			$params = array();
			$params['PhoneNumbers'] = $phone;
			$params['SignName'] = $SignName;
			$params['TemplateCode'] = $config['al_sms_tpl']['tlpId'];
			$params['TemplateParam'] = $TemplateParam;
			if (!empty($params['TemplateParam']) && is_array($params['TemplateParam'])) {
				$params['TemplateParam'] = json_encode($params['TemplateParam'], JSON_UNESCAPED_UNICODE);
			}
			if (!class_exists('SignatureHelper')) {
				@(include_once DISCUZ_ROOT . './source/plugin/guiigo_login/lib/SignatureHelper.php');
			}
			$helper = new SignatureHelper();
			$smsid = self::sendsmsinsert($phone, $code, $send_type, 1);
			if ($smsid) {
				$content = $helper->request($accessKeyId, $accessKeySecret, 'dysmsapi.aliyuncs.com', array_merge($params, array('RegionId' => 'cn-hangzhou', 'Action' => 'SendSms', 'Version' => '2017-05-25')));
				$contarray = json_decode(json_encode($content), true);
				$Message = self::diconv_out_nowiconv($contarray['Message']);
				if ($Message == 'OK' && $contarray['Code'] == 'OK') {
					C::t('#guiigo_login#guiigo_login_smslog')->update(array('t_notice_state' => 1, 't_cause' => $Message), array('t_id' => $smsid));
					return true;
				}
				C::t('#guiigo_login#guiigo_login_smslog')->update(array('t_cause' => $Message), array('t_id' => $smsid));
			}
		}
		return false;
	}
	public static function sendsmsinsert($phone, $code, $send_type, $api_type)
	{
		global $_G;
		$data = array();
		$data['t_uid'] = $_G['uid'] ? $_G['uid'] : '';
		$data['t_phone'] = $phone;
		$data['t_notice_type'] = $send_type;
		$data['t_api_type'] = $api_type;
		$data['t_notice_state'] = 2;
		$data['t_code'] = $code;
		$data['t_cause'] = '';
		$data['t_notice_date'] = TIMESTAMP;
		$sms_id = C::t('#guiigo_login#guiigo_login_smslog')->insert($data);
		return $sms_id;
	}
	public static function getSmsList($phone, $code, $t_notice_type = 1)
	{
		$where = array();
		$where['t_phone'] = $phone;
		$where['t_code'] = $code;
		$where['t_notice_type'] = $t_notice_type;
		$where['t_notice_state'] = 1;
		return C::t('#guiigo_login#guiigo_login_smslog')->get_guiigo_login_smslog_first($where);
	}
	public static function isphone($phone)
	{
		if (is_numeric($phone)) {
			return preg_match('#^1[3,4,5,7,8,9][\\d]{9}$|^14[5,7]{1}\\d{8}$|^15[^4]{1}\\d{8}$|^17[0,1,6,7,8]{1}\\d{8}$|^18[\\d]{9}$#', $phone) ? true : false;
		}
		return false;
	}
	public static function GetUidByPhone($phone)
	{
		return DB::result_first('select uid from %t where mobile=%s', array('common_member_profile', $phone));
	}
	public static function GetUidByPhoneByplugin($phone)
	{
		return DB::result_first('select u_uid from %t where u_mobile=%s', array('guiigo_login_user', $phone));
	}
	public static function setLoginBind($bindtype, $uid, $val, $insert = 0)
	{
		$retuser = DB::fetch_first('select * from %t where u_uid=%d', array('guiigo_login_user', $uid));
		$condition = array('u_uid' => $uid);
		if (is_array($val)) {
			$data = $val;
		} else {
			$data = array($bindtype => $val);
		}
		if ($retuser['u_id']) {
			C::t('#guiigo_login#guiigo_login_user')->update($data, $condition);
		} else {
			if (!$insert) {
				$data['u_uid'] = $uid;
				$data['u_dateline'] = TIMESTAMP;
				C::t('#guiigo_login#guiigo_login_user')->insert($data);
			}
		}
		if ($bindtype == 'u_mobile') {
			DB::query('update %t set mobile=%s where uid=%d', array('common_member_profile', $val, $uid));
			self::_setPhoneVerify($uid, $act ? 0 : 1);
		}
	}
	public static function _setPhoneVerify($uid, $val = 1)
	{
		$verifyid = self::getPhoneVerifyid();
		if (!$verifyid || $uid) {
			return false;
		}
		$verify = DB::fetch_first('select verify' . $verifyid . ',uid from %t where uid=%d', array('common_member_verify', $uid));
		if (!empty($verify['uid'])) {
			return DB::query('update %t set verify' . $verifyid . '=%d where uid=%d', array('common_member_verify', $val, $uid));
		}
		if ($val) {
			return DB::insert('common_member_verify', array('verify' . $verifyid => $val, 'uid' => $uid), true);
		}
	}
	public static function getPhoneVerifyid()
	{
		$config = self::config();
		if ($config['mobile_verify_fields']) {
			return $config['mobile_verify_fields'];
		}
		$verify = (array) unserialize(C::t('common_setting')->fetch(array('skey' => 'verify')));
		foreach ($verify as $key => $value) {
			if (isset($value['field']['mobile'])) {
				return $key;
			}
		}
	}
	public static function UsernameCheck($username)
	{
		$msgarr = array();
		$msgarr['code'] = 0 - 1001;
		$msgarr['data'] = array();
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs095');
		if (!$username) {
			$msgarr['code'] = 0 - 1002;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs096');
			self::RetMsgJson($msgarr);
		}
		$usernamelen = dstrlen($username);
		if ($usernamelen < 3) {
			$msgarr['code'] = 0 - 1003;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs097');
			self::RetMsgJson($msgarr);
		} else {
			if ($usernamelen > 15) {
				$msgarr['code'] = 0 - 1004;
				$msgarr['msg'] = lang('plugin/guiigo_login', 'langs098');
				self::RetMsgJson($msgarr);
			}
		}
		if (C::t('common_member')->fetch_uid_by_username($username) || C::t('common_member_archive')->fetch_uid_by_username($username)) {
			$msgarr['code'] = 0 - 1005;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs099');
			self::RetMsgJson($msgarr);
		}
	}
	public static function PasswordCheck($password)
	{
		global $_G;
		$msgarr = array();
		$msgarr['code'] = 0 - 1000;
		$msgarr['data'] = array();
		$msgarr['msg'] = lang('plugin/guiigo_login', 'langs095');
		if (!$password) {
			$msgarr['code'] = 0 - 1001;
			$msgarr['msg'] = lang('plugin/guiigo_login', 'langs100');
			self::RetMsgJson($msgarr);
		}
		if ($_G['setting']['pwlength']) {
			if (strlen($password) < $_G['setting']['pwlength']) {
				$msgarr['code'] = 1002;
				$msgarr['msg'] = lang('plugin/guiigo_login', 'langs101') . $_G['setting']['pwlength'] . lang('plugin/guiigo_login', 'langs102');
				self::RetMsgJson($msgarr);
			}
		}
		if ($_G['setting']['strongpw']) {
			$strongpw_str = array();
			if (in_array(1, $_G['setting']['strongpw']) && !preg_match('/\\d+/', $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_1');
			}
			if (in_array(2, $_G['setting']['strongpw']) && !preg_match('/[a-z]+/', $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_2');
			}
			if (in_array(3, $_G['setting']['strongpw']) && !preg_match('/[A-Z]+/', $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_3');
			}
			if (in_array(4, $_G['setting']['strongpw']) && !preg_match('/[^a-zA-z0-9]+/', $password)) {
				$strongpw_str[] = lang('member/template', 'strongpw_4');
			}
			if ($strongpw_str) {
				$msg = lang('member/template', 'password_weak') . implode(',', $strongpw_str);
				$msgarr['code'] = 0 - 1003;
				$msgarr['msg'] = $msg;
				self::RetMsgJson($msgarr);
			}
		}
	}
	public static function getUidByTable($type, $val)
	{
		$uid = NULL;
		$config = self::config();
		if ($type == 'wx' && $config['wx_table']) {
			if ($config['wx_table_openid'] && $val['openid']) {
				$uid = DB::result_first('select ' . $config['wx_table_uid'] . ' from %t where ' . $config['wx_table_openid'] . '=%s', array($config['wx_table'], $val['openid']));
			}
			if (!$uid && $config['wx_table_unionid'] && $val['unionid']) {
				$uid = DB::result_first('select ' . $config['wx_table_uid'] . ' from %t where ' . $config['wx_table_unionid'] . '=%s', array($config['wx_table'], $val['unionid']));
			}
		} else {
			if ($type == 'wb' && $config['wb_table']) {
				if ($config['wb_table_access_token'] && $val['openid']) {
					$uid = DB::result_first('select ' . $config['wb_table_access_uid'] . ' from %t where ' . $config['wb_table_access_token'] . '=%s', array($config['wb_table'], $val['openid']));
				}
			}
		}
		return $uid;
	}
	public static function getCodeUrl($type, $referer, $bind, $hash = '')
	{
		global $_G;
		$config = self::config();
		$url = '';
		if (!$hash) {
			$hash = random(16);
		}
		if ($type == 'wxpc' || $type == 'wxweb') {
			$returl = $_G['siteurl'] . 'plugin.php?id=guiigo_login#/pages/getcode?optype=' . $type . '&bind=' . $bind . '&hash=' . $hash . '&referer=' . urlencode($referer);
			$url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $config['wx_appid'] . '&redirect_uri=' . urlencode($returl) . '&response_type=code&scope=snsapi_userinfo&state=' . $hash . '#wechat_redirect';
		} else {
			if ($type == 'wbpc' || $type == 'wbweb') {
				$redirect_uri = $_G['siteurl'] . 'plugin.php?id=guiigo_login#/pages/getcode';
				$state = urlencode($referer) . '|' . $type . '|' . $bind . '|' . $hash;
				$url .= 'https://api.weibo.com/oauth2/authorize?client_id=' . $config['wb_appkey'];
				$url .= '&response_type=code&redirect_uri=' . urlencode($redirect_uri);
				$url .= '?state=' . urlencode($state);
			} else {
				if ($type == 'qqpc' || $type == 'qqweb') {
					$redirect_uri = $_G['siteurl'] . 'plugin.php?id=guiigo_login#/pages/getcode/?';
					$state = urlencode($referer) . '|' . $type . '|' . $bind . '|' . $hash;
					$url .= 'https://graph.qq.com/oauth2.0/authorize?client_id=' . $config['qqappid'];
					$url .= '&response_type=code&redirect_uri=' . urlencode($redirect_uri);
					$url .= '&state=' . urlencode($state);
					if ($type == 'qqweb') {
						$url .= '&display=mobile';
					}
				}
			}
		}
		return $url;
	}
	public static function getLoginHtml($showpw = false)
	{
		global $_G;
		$config = self::config();
		$html = '';
		if ($config['mobile_open']) {
			$html .= '<a href="javascript:;" onclick="hideWindow(\'login\', 0, 1);showWindow(\'phonelogin\', \'plugin.php?id=guiigo_login&act=phonelogin\');" target="_top" rel="nofollow"><img src="source/plugin/guiigo_login/static/img/sj_login.png" class="vm" style="padding:3px 0px 3px 5px;"></a>';
			if ($showpw) {
				$html .= '<a href="javascript:;" onclick="showWindow(\'login\', \'member.php?mod=logging&action=login&viewlostpw=1\');" target="_top" rel="nofollow"><img src="source/plugin/guiigo_login/static/img/sms_zh.png" class="vm" style="padding:3px 0px 3px 5px;"></a>';
			}
		}
		if ($config['wx_open']) {
			$html .= '<a href="javascript:;" onclick="showWindow(\'login\', \'plugin.php?id=guiigo_login&act=wxqrcode&bind=0\');" target="_top" rel="nofollow"><img src="source/plugin/guiigo_login/static/img/weixin_login.png" class="vm" style="padding:3px 0px 3px 5px;"></a>';
		}
		if ($config['wb_open']) {
			$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();
			if (dstrpos($referer, 'member.php') !== false) {
				$referer = $_G['siteurl'];
			}
			$url = self::getCodeUrl('wbpc', $referer, 0);
			$html .= '<a href="' . $url . '"><img src="source/plugin/guiigo_login/static/img/wb_login.png" class="vm" style="padding:3px 0px 3px 5px;"></a>';
		}
		if ($config['qqopen']) {
			$referer = $_GET['referer'] ? $_GET['referer'] : dreferer();
			if (dstrpos($referer, 'member.php') !== false) {
				$referer = $_G['siteurl'];
			}
			$url = self::getCodeUrl('qqpc', $referer, 0);
			$html .= '<a href="' . $url . '"><img src="static/image/common/qq_login.gif" class="vm" style="padding:3px 0px 3px 5px;"></a>';
		}
		return $html;
	}
}