<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class UserLogin
{
	public static function UpInvite($invite, $uid)
	{
		global $_G;
		if ($invite['id']) {
			$result = C::t('common_invite')->count_by_uid_fuid($invite['uid'], $uid);
			if (!$result) {
				C::t('common_invite')->update($invite['id'], array('fuid' => $uid, 'fusername' => $_G['username'], 'regdateline' => $_G['timestamp'], 'status' => 2));
				updatestat('invite');
			} else {
				$invite = array();
			}
		}
		if ($invite['uid']) {
			if ($_G['setting']['inviteconfig']['inviteaddcredit']) {
				updatemembercount($uid, array($_G['setting']['inviteconfig']['inviterewardcredit'] => $_G['setting']['inviteconfig']['inviteaddcredit']));
			}
			if ($_G['setting']['inviteconfig']['invitedaddcredit']) {
				updatemembercount($invite['uid'], array($_G['setting']['inviteconfig']['inviterewardcredit'] => $_G['setting']['inviteconfig']['invitedaddcredit']));
			}
			require_once libfile('function/friend');
			friend_make($invite['uid'], $invite['username'], false);
			notification_add($invite['uid'], 'friend', 'invite_friend', array('actor' => '<a href="home.php?mod=space&uid=' . $invite['uid'] . '" target="_blank">' . $invite['username'] . '</a>'), 1);
			space_merge($invite, 'field_home');
			if (!empty($invite['privacy']['feed']['invite'])) {
				require_once libfile('function/feed');
				$tite_data = array('username' => '<a href="home.php?mod=space&uid=' . $_G['uid'] . '">' . $_G['username'] . '</a>');
				feed_add('friend', 'feed_invite', $tite_data, '', array(), '', array(), array(), '', '', '', 0, 0, '', $invite['uid'], $invite['username']);
			}
			if ($invite['appid']) {
				updatestat('appinvite');
			}
		}
	}
	public static function Dz_welcome($uid)
	{
		global $_G;
		$welcomemsgtxt = $_G['setting']['welcomemsgtxt'];
		$welcomemsg = $_G['setting']['welcomemsg'];
		$welcomemsgtitle = $_G['setting']['welcomemsgtitle'];
		if ($welcomemsg && !empty($welcomemsgtxt)) {
			$welcomemsgtitle = replacesitevar($welcomemsgtitle);
			$welcomemsgtxt = replacesitevar($welcomemsgtxt);
			if ($welcomemsg == 1) {
				$welcomemsgtxt = nl2br(str_replace(':', '&#58;', $welcomemsgtxt));
				notification_add($uid, 'system', $welcomemsgtxt, array('from_id' => 0, 'from_idtype' => 'welcomemsg'), 1);
			} elseif ($welcomemsg == 2) {
			} elseif ($welcomemsg == 3) {
				$welcomemsgtxt = nl2br(str_replace(':', '&#58;', $welcomemsgtxt));
				notification_add($uid, 'system', $welcomemsgtxt, array('from_id' => 0, 'from_idtype' => 'welcomemsg'), 1);
			}
		}
	}
	public static function UserRegister($username, $password, $email)
	{
		global $_G;
		if (!function_exists('uc_user_register')) {
			loaducenter();
		}
		$uid = uc_user_register($username, $password, $email, '', '', $_G['clientip']);
		$code = 1;
		$msg = '';
		if ($uid <= 0) {
			$code = 0 - 1;
			if ($uid == 0 - 1) {
				$msg = lang('plugin/guiigo_login', 'langs076');
			} elseif ($uid == 0 - 2) {
				$msg = lang('plugin/guiigo_login', 'langs077');
			} elseif ($uid == 0 - 3) {
				$msg = lang('plugin/guiigo_login', 'langs078');
			} elseif ($uid == 0 - 4) {
				$msg = lang('plugin/guiigo_login', 'langs079');
			} elseif ($uid == 0 - 5) {
				$msg = lang('plugin/guiigo_login', 'langs080');
			} elseif ($uid == 0 - 6) {
				$msg = lang('plugin/guiigo_login', 'langs081');
			} else {
				$msg = lang('plugin/guiigo_login', 'langs082');
			}
		}
		return array('code' => $code, 'data' => $uid, 'msg' => $msg);
	}
	public static function Login($name, $password)
	{
		global $_G;
		loaducenter();
		$result = uc_user_login($name, $password, 0);
		if ($result[0] <= 0) {
			return array('code' => 0 - 1, 'data' => array(), 'msg' => lang('plugin/guiigo_login', 'langs083'));
		}
		return self::UidLogin($result[0]);
	}
	public static function UidLogin($uid)
	{
		global $_G;
		require_once libfile('function/member');
		loaducenter();
		$member = getuserbyuid($uid, 1);
		if ($member) {
			if (isset($member['_inarchive'])) {
				C::t('common_member_archive')->move_to_master($uid);
			}
			$cookietime = 1296000;
			setloginstatus($member, $cookietime);
			C::t('common_member_status')->update($member['uid'], array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));
			return array('code' => 1, 'data' => array('uid' => $uid), 'msg' => lang('plugin/guiigo_login', 'langs084'));
		}
		return array('code' => 0 - 2, 'data' => array(), 'msg' => lang('plugin/guiigo_login', 'langs085'));
	}
	public static function syncavatar($uid, $avatar)
	{
		if (!$uid || !$avatar) {
			return false;
		}
		if (!($content = dfsockopen($avatar))) {
			return false;
		}
		$tmpFile = DISCUZ_ROOT . './data/avatar/' . TIMESTAMP . random(6);
		file_put_contents($tmpFile, $content);
		if (!is_file($tmpFile)) {
			return false;
		}
		$result = self::uploadUcAvatar($uid, $tmpFile);
		unlink($tmpFile);
		C::t('common_member')->update($uid, array('avatarstatus' => 1));
		return $result;
	}
	public static function uploadUcAvatar($uid, $localFile)
	{
		global $_G;
		if (!$uid || !$localFile) {
			return false;
		}
		list($width, $height, $type, $attr) = getimagesize($localFile);
		if (!$width) {
			return false;
		}
		if ($width < 10 || $height < 10 || $type == 4) {
			return false;
		}
		$imageType = array(1 => '.gif', 2 => '.jpg', 3 => '.png');
		$fileType = $imgType[$type];
		if (!$fileType) {
			$fileType = '.jpg';
		}
		$avatarPath = $_G['setting']['attachdir'];
		$tmpAvatar = $avatarPath . './temp/upload' . $uid . $fileType;
		file_exists($tmpAvatar) && @unlink($tmpAvatar);
		file_put_contents($tmpAvatar, file_get_contents($localFile));
		if (!is_file($tmpAvatar)) {
			return false;
		}
		$tmpAvatarBig = './temp/upload' . $uid . 'big' . $fileType;
		$tmpAvatarMiddle = './temp/upload' . $uid . 'middle' . $fileType;
		$tmpAvatarSmall = './temp/upload' . $uid . 'small' . $fileType;
		$image = new image();
		if ($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
			return false;
		}
		if ($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
			return false;
		}
		if ($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
			return false;
		}
		$tmpAvatarBig = $avatarPath . $tmpAvatarBig;
		$tmpAvatarMiddle = $avatarPath . $tmpAvatarMiddle;
		$tmpAvatarSmall = $avatarPath . $tmpAvatarSmall;
		$avatar1 = self::byte2hex(file_get_contents($tmpAvatarBig));
		$avatar2 = self::byte2hex(file_get_contents($tmpAvatarMiddle));
		$avatar3 = self::byte2hex(file_get_contents($tmpAvatarSmall));
		$extra = '&avatar1=' . $avatar1 . '&avatar2=' . $avatar2 . '&avatar3=' . $avatar3;
		$result = self::uc_api_post_ex('user', 'rectavatar', array('uid' => $uid), $extra);
		@unlink($tmpAvatar);
		@unlink($tmpAvatarBig);
		@unlink($tmpAvatarMiddle);
		@unlink($tmpAvatarSmall);
		return true;
	}
	public static function byte2hex($string)
	{
		$buffer = '';
		$value = unpack('H*', $string);
		$value = str_split($value[1], 2);
		$b = '';
		foreach ($value as $k => $v) {
			$b .= strtoupper($v);
		}
		return $b;
	}
	public static function uc_api_post_ex($module, $action, $arg = array(), $extra = '')
	{
		if (!function_exists('uc_api_requestdata')) {
			loaducenter();
		}
		$s = $sep = '';
		foreach ($arg as $k => $v) {
			$k = urlencode($k);
			if (is_array($v)) {
				$s2 = $sep2 = '';
				foreach ($v as $k2 => $v2) {
					$k2 = urlencode($k2);
					$s2 .= $sep2 . $k . '[' . $k2 . ']=' . urlencode(uc_stripslashes($v2));
					$sep2 = '&';
				}
				$s .= $sep . $s2;
			} else {
				$s .= $sep . $k . '=' . urlencode(uc_stripslashes($v));
			}
			$sep = '&';
		}
		$postdata = uc_api_requestdata($module, $action, $s, $extra);
		return uc_fopen2(UC_API . '/index.php', 500000, $postdata, '', true, UC_IP, 20);
	}
	public static function UsernameBind($uid, $userinfo)
	{
		if ($userinfo['type'] == 'mobile') {
			GuiigoLogin::setLoginBind('u_mobile', $uid, $userinfo['data']['mobile']);
		} elseif ($userinfo['type'] == 'wb') {
			GuiigoLogin::setLoginBind('u_sina_openid', $uid, $userinfo['data']['openid']);
			if ($userinfo['data']['avatar_hd']) {
				self::syncavatar($uid, $userinfo['data']['avatar_hd']);
			}
			if ($userinfo['data']['gender']) {
				$gender = $userinfo['data']['gender'] == 'm' ? 1 : ($userinfo['data']['gender'] == 'f' ? 2 : 0);
				return DB::query('update %t set gender=%d where uid=%d', array('common_member_profile', $gender, $uid));
			}
		} elseif ($userinfo['type'] == 'wx') {
			$val = array('u_wx_openid' => $userinfo['data']['openid'], 'u_wx_unionid' => $userinfo['data']['unionid']);
			GuiigoLogin::setLoginBind('wx', $uid, $val);
			if ($userinfo['data']['headimgurl']) {
				self::syncavatar($uid, $userinfo['data']['headimgurl']);
			}
			if ($userinfo['data']['gender']) {
				DB::query('update %t set gender=%d where uid=%d', array('common_member_profile', $userinfo['data']['gender'], $uid));
			}
		} elseif ($userinfo['type'] == 'qq') {
			$val = array('u_qq_openid' => $userinfo['data']['openid'], 'u_qq_unionid' => $userinfo['data']['unionid']);
			GuiigoLogin::setLoginBind('qq', $uid, $val);
			if ($userinfo['data']['headimgurl']) {
				self::syncavatar($uid, $userinfo['data']['headimgurl']);
			}
			if ($userinfo['data']['gender']) {
				DB::query('update %t set gender=%d where uid=%d', array('common_member_profile', $userinfo['data']['gender'], $uid));
			}
		}
	}
	public static function WX_getAccessTokenByCode($code)
	{
		$config = GuiigoLogin::config();
		$appid = $config['wx_appid'];
		$appsecret = $config['wx_appsecret'];
		$url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' . $appid . '&secret=' . $appsecret . '&code=' . $code . '&grant_type=authorization_code';
		$res = json_decode(dfsockopen($url), true);
		return $res;
	}
	public static function WX_getUserinfoByAccessToken($access_token, $openid)
	{
		$url = 'https://api.weixin.qq.com/sns/userinfo?access_token=' . $access_token . '&openid=' . $openid . '&lang=zh_CN';
		$res = json_decode(dfsockopen($url), true);
		return $res;
	}
	public static function WB_getAccessTokenByCode($code)
	{
		global $_G;
		$config = GuiigoLogin::config();
		$Surl = $_G['siteurl'] . 'plugin.php?id=guiigo_login#/pages/getcode';
		$url = 'https://api.weibo.com/oauth2/access_token?client_id=' . $config['wb_appkey'];
		$url .= '&client_secret=' . $config['wb_appsecret'] . '&grant_type=authorization_code&redirect_uri=' . urlencode($Surl) . '&code=' . $code;
		$json = GuiigoLogin::post($url);
		return json_decode($json, true);
	}
	public static function WB_getUserinfoByAccessToken($access_token, $WBuid)
	{
		$url = 'https://api.weibo.com/2/users/show.json?';
		$url .= 'access_token=' . $access_token . '&uid=' . $WBuid;
		$json = dfsockopen($url);
		return json_decode($json, true);
	}
	public static function QQ_getAccessTokenByCode($code)
	{
		global $_G;
		$config = GuiigoLogin::config();
		$client_id = $config['qqappid'];
		$client_secret = $config['qqappkey'];
		$Surl = $_G['siteurl'] . 'plugin.php?id=guiigo_login#/pages/getcode';
		$url = 'https://graph.qq.com/oauth2.0/token?client_id=' . $client_id . '&client_secret=' . $client_secret . '&redirect_uri=' . urlencode($Surl) . '&code=' . $code . '&grant_type=authorization_code&fmt=json';
		$res = json_decode(dfsockopen($url), true);
		if ($res['access_token']) {
			return $res['access_token'];
		}
		return false;
	}
	public static function QQ_getOpidByAccessToken($access_token)
	{
		$url = 'https://graph.qq.com/oauth2.0/me?access_token=' . $access_token . '&fmt=json';
		$res = json_decode(dfsockopen($url), true);
		if ($res['openid']) {
			return $res['openid'];
		}
		return false;
	}
	public static function QQ_getUnionidByAccessToken($access_token)
	{
		$url = 'https://graph.qq.com/oauth2.0/me?access_token=' . $access_token . '&unionid=1&fmt=json';
		$res = json_decode(dfsockopen($url), true);
		if ($res['unionid']) {
			return $res['unionid'];
		}
		return false;
	}
	public static function QQ_getUserinfoByAccessToken($access_token, $openid)
	{
		$config = GuiigoLogin::config();
		$client_id = $config['qqappid'];
		$url = 'https://graph.qq.com/user/get_user_info?access_token=' . urlencode($access_token);
		$url .= '&oauth_consumer_key=' . urlencode($client_id);
		$url .= '&openid=' . urlencode($openid);
		$res = json_decode(dfsockopen($url), true);
		return $res;
	}
	public static function getregname($username)
	{
		global $_G;
		$newname = cutstr($username, 15, '');
		if ($newname) {
			$censorexp = '/^(' . str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote($_G['setting']['censoruser'] = trim($_G['setting']['censoruser']), '/')) . ')$/i';
			$newname = preg_replace($censorexp, '', $newname);
			$guestexp = '\\xA1\\xA1|\\xAC\\xA3|^Guest|^\\xD3\\xCE\\xBF\\xCD|\\xB9\\x43\\xAB\\xC8';
			$newname = preg_replace('/\\s+|^c:\\con\\con|[%,\\*"\\s\\<\\>\\&]|' . $guestexp . '/is', '', $newname);
		}
		return $newname;
	}
}