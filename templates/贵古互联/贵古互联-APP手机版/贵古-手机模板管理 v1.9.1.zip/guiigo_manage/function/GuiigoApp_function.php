<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function GuiigoApp_output($mobtle=true) {
	global $_G;
	if(defined('DISCUZ_OUTPUTED')) {
		return;
	} else {
		define('DISCUZ_OUTPUTED', 1);
	}

	if(!empty($_G['blockupdate'])) {
		block_updatecache($_G['blockupdate']['bid']);
	}

	if(defined('IN_MOBILE') && $mobtle) {
		_mobileoutput();
	}
	
	$havedomain = implode('', $_G['setting']['domain']['app']);
	if($_G['setting']['rewritestatus'] || !empty($havedomain)) {
		$content = ob_get_contents();
		$content = _output_replace($content);
		ob_end_clean();
		$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
		echo $content;
	}
	if(isset($_G['makehtml'])) {
		helper_makehtml::make_html();
	}

	if($_G['setting']['ftp']['connid']) {
		@ftp_close($_G['setting']['ftp']['connid']);
	}

	if(defined('DISCUZ_DEBUG') && DISCUZ_DEBUG && @include(libfile('function/debug'))) {
		function_exists('debugmessage') && debugmessage();
	}
}

function _output_replace($content) {
	global $_G;
	if(defined('IN_MODCP') || defined('IN_ADMINCP')) return $content;
	if(!empty($_G['setting']['output']['str']['search'])) {
		if(empty($_G['setting']['domain']['app']['default'])) {
			$_G['setting']['output']['str']['replace'] = str_replace('{CURHOST}', $_G['siteurl'], $_G['setting']['output']['str']['replace']);
		}
		$content = str_replace($_G['setting']['output']['str']['search'], $_G['setting']['output']['str']['replace'], $content);
	}

	if(!empty($_G['setting']['output']['preg']['search']) && (empty($_G['setting']['rewriteguest']) || empty($_G['uid']))) {
		if(empty($_G['setting']['domain']['app']['default'])) {
			$_G['setting']['output']['preg']['search'] = str_replace('\{CURHOST\}', preg_quote($_G['siteurl'], '/'), $_G['setting']['output']['preg']['search']);
			$_G['setting']['output']['preg']['replace'] = str_replace('{CURHOST}', $_G['siteurl'], $_G['setting']['output']['preg']['replace']);
		}

$forum_viewthread_search ='/<a href\="()forum.php\?mod\=viewthread&(amp;)?tid\=(\d+)(&amp;extra\=(page\%3D(\d+))?)?(&amp;page\=(\d+))?(.*?)?"([^\>]*)\>/';
$forum_viewthread_replace = $_G['setting']['output']['preg']['replace']['forum_viewthread'];
$forum_viewthread_replace = str_replace(array('rewriteoutput','$matches[9])'),array('_rewriteoutput','$matches[9],$matches[10])'),$forum_viewthread_replace);
$content = preg_replace_callback($forum_viewthread_search, create_function('$matches', 'return '.$forum_viewthread_replace.';'), $content);

		foreach($_G['setting']['output']['preg']['search'] as $key => $value){
			$content = preg_replace_callback($value, create_function('$matches', 'return '.$_G['setting']['output']['preg']['replace'][$key].';'), $content);
		}
	}
	return $content;
}

function _rewriteoutput($type, $returntype, $host) {
	global $_G;
	$fextra = '';
	if($type == 'forum_viewthread') {
		list(,,,$tid, $page, $prevpage, $extra2, $extra) = func_get_args();
		if(strexists($extra2,'fromguid=hot&amp;') !== FALSE){
			$extra2 = str_replace('fromguid=hot&amp;','',$extra2);
		}
		if(!empty($extra2) && strexists($extra2,'filter') !== FALSE || strexists($extra2,'sortid') !== FALSE || strexists($extra2,'sortid') !== FALSE){
			$fextra = '?'.$extra2;
		}
		$r = array(
			'{tid}' => $tid,
			'{page}' => $page ? $page : 1,
			'{prevpage}' => $prevpage && !IS_ROBOT ? $prevpage : 1,
		);
	}
	$href = str_replace(array_keys($r), $r, $_G['setting']['rewriterule'][$type]).$fextra;
	if(!$returntype) {
		return '<a href="'.$host.$href.'"'.(!empty($extra) ? stripslashes($extra) : '').'>';
	} else {
		return $host.$href;
	}
}

function _mobileoutput() {
	global $_G;
	if(!defined('TPL_DEFAULT')) {
		$content = ob_get_contents();
		ob_end_clean();
		ob_start();
		$content = '<?xml version="1.0" encoding="utf-8"?>'.$content;
		if('utf-8' != CHARSET) {
			$content = diconv($content, CHARSET, 'utf-8');
		}
		@header('Content-Type: text/html; charset=utf-8');
		echo $content;
		//exit();
	} elseif (defined('TPL_DEFAULT') && !$_G['cookie']['dismobilemessage'] && $_G['mobile']) {
		ob_end_clean();
		ob_start();
		$_G['forcemobilemessage'] = true;
		parse_str($_SERVER['QUERY_STRING'], $query);
		$query['forcemobile'] = '1';
		$query_sting_tmp = http_build_query($query);
		$_G['setting']['mobile']['pageurl'] = $_G['siteurl'].basename($_G['PHP_SELF']).'?'.$query_sting_tmp;
		unset($query_sting_tmp);
		showmessage('not_in_mobile');
		exit;
	}
}