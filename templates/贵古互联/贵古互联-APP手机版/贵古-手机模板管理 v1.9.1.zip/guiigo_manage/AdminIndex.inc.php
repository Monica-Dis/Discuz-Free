<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
$config = GuiigoApp::config();
GuiigoApp::verifyKey();/*From: DisM - Taobao - Com*/
require_once libfile('function/forumlist');
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
if (!submitcheck('settingsubmit')) {
	$forum_style_select = array();
	$forum_style_select[] = array(1, lang('plugin/guiigo_manage', 'slang0023'));
	$forum_style_select[] = array(2, lang('plugin/guiigo_manage', 'slang0024'));
	$forum_style_select[] = array(3, lang('plugin/guiigo_manage', 'slang0025'));
	$forum_style_select[] = array(4, lang('plugin/guiigo_manage', 'slang0268'));
	$header_style_select = array();
	$header_style_select[] = array(1, lang('plugin/guiigo_manage', 'slang0162'));
	$header_style_select[] = array(2, lang('plugin/guiigo_manage', 'slang0163'));
	$forum_special_select = array();
	$forum_special_select[] = array(0, lang('plugin/guiigo_manage', 'slang0180'));
	$forum_special_select[] = array(1, lang('plugin/guiigo_manage', 'slang0181'));
	$forum_special_select[] = array(2, lang('plugin/guiigo_manage', 'slang0182'));
	$forum_special_select[] = array(3, lang('plugin/guiigo_manage', 'slang0183'));
	$forum_special_select[] = array(4, lang('plugin/guiigo_manage', 'slang0184'));
	$forum_special_select[] = array(5, lang('plugin/guiigo_manage', 'slang0185'));
	$forum_special_select[] = array(127, lang('plugin/guiigo_manage', 'slang0186'));
	$forum_orderby_select = array();
	$forum_orderby_select[] = array('lastpost', lang('plugin/guiigo_manage', 'slang0187'));
	$forum_orderby_select[] = array('dateline', lang('plugin/guiigo_manage', 'slang0188'));
	$forum_orderby_select[] = array('replies', lang('plugin/guiigo_manage', 'slang0189'));
	$forum_orderby_select[] = array('views', lang('plugin/guiigo_manage', 'slang0190'));
	$forum_orderby_select[] = array('heats', lang('plugin/guiigo_manage', 'slang0191'));
	$forum_orderby_select[] = array('recommends', lang('plugin/guiigo_manage', 'slang0192'));
	$forum_dateline_select = array();
	$forum_dateline_select[] = array(3600, lang('plugin/guiigo_manage', 'slang0193'));
	$forum_dateline_select[] = array(86400, lang('plugin/guiigo_manage', 'slang0194'));
	$forum_dateline_select[] = array(604800, lang('plugin/guiigo_manage', 'slang0195'));
	$forum_dateline_select[] = array(2592000, lang('plugin/guiigo_manage', 'slang0196'));
	$Portal_orderby_select = array();
	$Portal_orderby_select[] = array('dateline', lang('plugin/guiigo_manage', 'slang0197'));
	$Portal_orderby_select[] = array('viewnum', lang('plugin/guiigo_manage', 'slang0198'));
	$Portal_orderby_select[] = array('commentnum', lang('plugin/guiigo_manage', 'slang0199'));
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0164'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0165'), '', '', GuiigoApp::get_select('settingnew[index_header_style]', $header_style_select, $setting['index_header_style'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0166'), 'settingnew[index_header_style_open]', $setting['index_header_style_open'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0167'));
	showsetting(lang('plugin/guiigo_manage', 'slang0168'), 'settingnew[index_header_title_d]', $setting['index_header_title_d'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0169'));
	showsetting(lang('plugin/guiigo_manage', 'slang0170'), 'settingnew[index_header_title_x]', $setting['index_header_title_x'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0171'));
	showsetting(lang('plugin/guiigo_manage', 'slang0172'), 'settingnew[index_header_window]', $setting['index_header_window'], 'text');
	showsetting(lang('plugin/guiigo_manage', 'slang0173'), 'settingnew[index_header_window_content]', $setting['index_header_window_content'], 'textarea', '', '', lang('plugin/guiigo_manage', 'slang0174'));
	showsetting(lang('plugin/guiigo_manage', 'slang0175'), 'settingnew[index_header_window_ad]', $setting['index_header_window_ad'], 'textarea', '', '', lang('plugin/guiigo_manage', 'slang0176'));
	showtablefooter(); /*Dism_taobao-com*/
	showtableheader(lang('plugin/guiigo_manage', 'slang0077'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0078'), 'settingnew[second_level_channel]', $setting['second_level_channel'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0052'), 'settingnew[module_ids]', $setting['module_ids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0053'));
	showsetting(lang('plugin/guiigo_manage', 'slang0079'), 'settingnew[user_interest]', $setting['user_interest'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0080'));
	showsetting(lang('plugin/guiigo_manage', 'slang0081'), 'settingnew[user_follow_uids]', $setting['user_follow_uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0009'));
	showsetting(lang('plugin/guiigo_manage', 'slang0082'), array('settingnew[recommend_content]', array(array('nocontent', lang('plugin/guiigo_manage', 'slang0083'), array('forum' => 'none', 'Portal' => 'none', 'group' => 'none')), array('forum', lang('plugin/guiigo_manage', 'slang0055'), array('forum' => '', 'Portal' => 'none', 'group' => 'none')), array('Portal', lang('plugin/guiigo_manage', 'slang0056'), array('forum' => 'none', 'Portal' => '', 'group' => 'none')), array('group', lang('plugin/guiigo_manage', 'slang0057'), array('forum' => 'none', 'Portal' => 'none', 'group' => '')))), $setting['recommend_content'], 'mradio2');
	showtagheader('tbody', 'forum', $setting['forum'], 'sub');
	showsetting(lang('plugin/guiigo_manage', 'slang0058'), '', '', '<select name="settingnew[forum][forumids][]" multiple="multiple" size="10">' . forumselect(0, 0, $setting['forum']['forumids'], true) . '</select>');
	showsetting(lang('plugin/guiigo_manage', 'slang0059'), 'settingnew[forum][digest]', $setting['forum']['digest'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0060'), 'settingnew[forum][isimg]', $setting['forum']['isimg'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0061'), 'settingnew[forum][uids]', $setting['forum']['uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0062'));
	showsetting(lang('plugin/guiigo_manage', 'slang0200'), 'settingnew[forum][stick]', $setting['forum']['stick'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0201'), '', '', GuiigoApp::get_select('settingnew[forum][special][]', $forum_special_select, $setting['forum']['special'], array(0 - 5, lang('plugin/guiigo_manage', 'slang0028')), 6));
	showsetting(lang('plugin/guiigo_manage', 'slang0202'), 'settingnew[forum][tagkeyword]', $setting['forum']['tagkeyword'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0207'));
	showsetting(lang('plugin/guiigo_manage', 'slang0203'), 'settingnew[forum][keyword]', $setting['forum']['keyword'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0208'));
	showsetting(lang('plugin/guiigo_manage', 'slang0204'), '', '', GuiigoApp::get_select('settingnew[forum][orderby]', $forum_orderby_select, $setting['forum']['orderby'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0205'), '', '', GuiigoApp::get_select('settingnew[forum][postdateline]', $forum_dateline_select, $setting['forum']['postdateline'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0206'), '', '', GuiigoApp::get_select('settingnew[forum][lastpost]', $forum_dateline_select, $setting['forum']['lastpost'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0063'), '', '', GuiigoApp::get_select('settingnew[forum][style]', $forum_style_select, $setting['forum']['style'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showtagfooter('tbody');
	showtagheader('tbody', 'Portal', $setting['Portal'], 'sub');
	$portalcpselect = category_showselect('portal', $setting['Portal']['Portalids']);
	showsetting(lang('plugin/guiigo_manage', 'slang0064'), '', '', '<select name="settingnew[Portal][Portalids][]" multiple="multiple" size="10">' . $portalcpselect . '</select>');
	showsetting(lang('plugin/guiigo_manage', 'slang0060'), 'settingnew[Portal][isimg]', $setting['Portal']['isimg'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0065'), 'settingnew[Portal][uids]', $setting['Portal']['uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0062'));
	showsetting(lang('plugin/guiigo_manage', 'slang0203'), 'settingnew[Portal][keyword]', $setting['Portal']['keyword'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0208'));
	showsetting(lang('plugin/guiigo_manage', 'slang0205'), '', '', GuiigoApp::get_select('settingnew[Portal][postdateline]', $forum_dateline_select, $setting['Portal']['postdateline'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0204'), '', '', GuiigoApp::get_select('settingnew[Portal[orderby]', $Portal_orderby_select, $setting['Portal']['orderby'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showtagfooter('tbody');
	showtagheader('tbody', 'group', $setting['group'], 'sub');
	showsetting(lang('plugin/guiigo_manage', 'slang0067'), 'settingnew[group][groupids]', $setting['group']['groupids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0142'));
	showsetting(lang('plugin/guiigo_manage', 'slang0059'), 'settingnew[group][digest]', $setting['group']['digest'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0060'), 'settingnew[group][isimg]', $setting['group']['isimg'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0061'), 'settingnew[group][uids]', $setting['group']['uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0062'));
	showsetting(lang('plugin/guiigo_manage', 'slang0200'), 'settingnew[group][stick]', $setting['group']['stick'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0201'), '', '', GuiigoApp::get_select('settingnew[group][special][]', $forum_special_select, $setting['group']['special'], array(0 - 5, lang('plugin/guiigo_manage', 'slang0028')), 6));
	showsetting(lang('plugin/guiigo_manage', 'slang0202'), 'settingnew[group][tagkeyword]', $setting['group']['tagkeyword'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0207'));
	showsetting(lang('plugin/guiigo_manage', 'slang0203'), 'settingnew[group][keyword]', $setting['group']['keyword'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0208'));
	showsetting(lang('plugin/guiigo_manage', 'slang0204'), '', '', GuiigoApp::get_select('settingnew[group][orderby]', $forum_orderby_select, $setting['group']['orderby'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0205'), '', '', GuiigoApp::get_select('settingnew[group][postdateline]', $forum_dateline_select, $setting['group']['postdateline'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0206'), '', '', GuiigoApp::get_select('settingnew[group][lastpost]', $forum_dateline_select, $setting['group']['lastpost'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0063'), '', '', GuiigoApp::get_select('settingnew[group][style]', $forum_style_select, $setting['group']['style'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showtagfooter('tbody');
	showtablefooter(); /*Dism_taobao-com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter(); /*Dism_taobao-com*/
	showformfooter(); /*dism��taobao��com*/
} else {
	if ($_POST['settingnew']['recommend_content'] == 'nocontent') {
		$_POST['settingnew']['forum'] = array();
		$_POST['settingnew']['Portal'] = array();
		$_POST['settingnew']['group'] = array();
	} elseif ($_POST['settingnew']['recommend_content'] == 'forum') {
		$_POST['settingnew']['Portal'] = array();
		$_POST['settingnew']['group'] = array();
	} elseif ($_POST['settingnew']['recommend_content'] == 'Portal') {
		$_POST['settingnew']['forum'] = array();
		$_POST['settingnew']['group'] = array();
	} elseif ($_POST['settingnew']['recommend_content'] == 'group') {
		$_POST['settingnew']['forum'] = array();
		$_POST['settingnew']['Portal'] = array();
	}
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize(array_merge($setting, $_POST['settingnew']))));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
function category_showselect($type, $current = array(), $shownull = true)
{
	global $_G;
	if (!in_array($type, array('portal', 'blog', 'album'))) {
		return '';
	}
	loadcache($type . 'category');
	$category = $_G['cache'][$type . 'category'];
	$select = '';
	if ($shownull) {
		$select .= '<option value="">' . lang('portalcp', 'select_category') . '</option>';
	}
	foreach ($category as $value) {
		if ($value['level'] == 0) {
			$selected = in_array($value['catid'], $current) ? 'selected="selected"' : '';
			$select .= '<option value="' . $value['catid'] . '"' . $selected . '>' . $value['catname'] . '</option>';
			if ($value['children']) {
				foreach ($value['children'] as $catid) {
					$selected = in_array($catid, $current) ? 'selected="selected"' : '';
					$select .= '<option value="' . $category[$catid][catid] . '"' . $selected . '>-- ' . $category[$catid][catname] . '</option>';
					if ($category[$catid]['children']) {
						foreach ($category[$catid]['children'] as $catid2) {
							$selected = in_array($catid2, $current) ? 'selected="selected"' : '';
							$select .= '<option value="' . $category[$catid2][catid] . '"' . $selected . '>----' . $category[$catid2][catname] . '</option>';
						}
					}
				}
			}
		}
	}
	return $select;
}