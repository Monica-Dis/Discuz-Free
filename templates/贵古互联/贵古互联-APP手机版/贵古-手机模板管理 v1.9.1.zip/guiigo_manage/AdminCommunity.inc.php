<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
$config = GuiigoApp::config();
GuiigoApp::verifyKey();/*From: DisM - Taobao - Com*/
require_once libfile('function/forumlist');
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
if (!submitcheck('settingsubmit')) {
	$forumstyle_select = array();
	$forumstyle_select[] = array(1, lang('plugin/guiigo_manage', 'slang0141'));
	$forumstyle_select[] = array(2, lang('plugin/guiigo_manage', 'slang0142'));
	$forumstyle2_select = array();
	$forumstyle2_select[] = array(1, lang('plugin/guiigo_manage', 'slang0143'));
	$forumstyle2_select[] = array(2, lang('plugin/guiigo_manage', 'slang0144'));
	$forumstyle2_select[] = array(3, lang('plugin/guiigo_manage', 'slang0145'));
	$fxx_select = array();
	$fxx_select[] = array(1, lang('plugin/guiigo_manage', 'slang0146'));
	$fxx_select[] = array(2, lang('plugin/guiigo_manage', 'slang0147'));
	$forumstyle3_select = array();
	$forumstyle3_select[] = array(1, lang('plugin/guiigo_manage', 'slang0226'));
	$forumstyle3_select[] = array(2, lang('plugin/guiigo_manage', 'slang0227'));
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0235'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0148'), '', '', GuiigoApp::get_select('settingnew[forumstyle]', $forumstyle_select, $setting['forumconfig']['forumstyle'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0178'), 'settingnew[show_wdgzqb]', $setting['forumconfig']['show_wdgzqb'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0179'));
	showsetting(lang('plugin/guiigo_manage', 'slang0005'), 'settingnew[show_statistics]', $setting['forumconfig']['show_statistics'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0006'), 'settingnew[show_notice]', $setting['forumconfig']['show_notice'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0007'), 'settingnew[show_follow_ad_html]', $setting['forumconfig']['show_follow_ad_html'], 'textarea');
	showsetting(lang('plugin/guiigo_manage', 'slang0008'), 'settingnew[recommend_forum_ids]', $setting['forumconfig']['recommend_forum_ids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0009'));
	showsetting(lang('plugin/guiigo_manage', 'slang0010'), 'settingnew[recommend_forum_ad_html]', $setting['forumconfig']['recommend_forum_ad_html'], 'textarea');
	showtableheader(lang('plugin/guiigo_manage', 'slang0236'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0011'), 'settingnew[show_top_unfold]', $setting['forumconfig']['show_top_unfold'], 'text');
	showsetting(lang('plugin/guiigo_manage', 'slang0161'), 'settingnew[show_flqbzs]', $setting['forumconfig']['show_flqbzs'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0270'), 'settingnew[show_pyqbt]', $setting['forumconfig']['show_pyqbt'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0272'));
	showsetting(lang('plugin/guiigo_manage', 'slang0271'), 'settingnew[show_pyqzg]', $setting['forumconfig']['show_pyqzg'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0273'));
	showsetting(lang('plugin/guiigo_manage', 'slang0274'), 'settingnew[show_pyqhd]', $setting['forumconfig']['show_pyqhd'], 'textarea', '', '', lang('plugin/guiigo_manage', 'slang0275'));
	showtableheader(lang('plugin/guiigo_manage', 'slang0237'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0012'), 'settingnew[show_reward]', $setting['forumconfig']['show_reward'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0013'), 'settingnew[reward_text]', $setting['forumconfig']['reward_text'], 'text');
	showsetting(lang('plugin/guiigo_manage', 'slang0225'), '', '', GuiigoApp::get_select('settingnew[show_rewardan]', $forumstyle3_select, $setting['forumconfig']['show_rewardan'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0228'), 'settingnew[show_rewardlb]', $setting['forumconfig']['show_rewardlb'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0229'));
	showsetting(lang('plugin/guiigo_manage', 'slang0230'), 'settingnew[show_rewardsl]', $setting['forumconfig']['show_rewardsl'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0231'));
	showsetting(lang('plugin/guiigo_manage', 'slang0014'), 'settingnew[show_tag]', $setting['forumconfig']['show_tag'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0015'), 'settingnew[show_give]', $setting['forumconfig']['show_give'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0016'), 'settingnew[show_content_sources]', $setting['forumconfig']['show_content_sources'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0017'), 'settingnew[show_like]', $setting['forumconfig']['show_like'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0018'), 'settingnew[show_look_posts]', $setting['forumconfig']['show_look_posts'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0019'), 'settingnew[show_reply_order]', $setting['forumconfig']['show_reply_order'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0020'), 'settingnew[show_reply_data]', $setting['forumconfig']['show_reply_data'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0021'), 'settingnew[show_give_data]', $setting['forumconfig']['show_give_data'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0022'), 'settingnew[show_favorite_data]', $setting['forumconfig']['show_favorite_data'], 'radio');
	showtablefooter(); /*Dism_taobao-com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter(); /*Dism_taobao-com*/
	showformfooter(); /*dism��taobao��com*/
} else {
	$setting['forumconfig'] = $_GET['settingnew'];
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}