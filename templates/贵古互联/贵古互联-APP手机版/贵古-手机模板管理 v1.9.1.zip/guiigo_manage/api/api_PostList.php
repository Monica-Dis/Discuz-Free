<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($guiigo_config['urluewriter']) {
	@(include_once DISCUZ_ROOT . './source/plugin/guiigo_manage/function/GuiigoApp_function.php');
}
if ($_GET['act'] == 'getIndexList') {
	$orderid = daddslashes($_GET['orderid']);
	$perpage = 10;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage - 1) * $perpage;
	$poatstyle = 1;
	$mods = 1;
	$postlist = array();
	$data_html = '';
	if ($orderid == 'recommend_content' || $orderid == 'nocontent') {
		if ($config['appsetting']['module_ids'] && $_GET['page'] <= 1) {
			$data_html = GuiigoApp::get_block_htnl($config['appsetting']['module_ids']);
		}
		if ($config['appsetting']['recommend_content'] == 'nocontent') {
			$data_html .= '<div id="nolist" style="display:none;"></div>';
		} elseif ($config['appsetting']['recommend_content'] == 'forum') {
			$where = $config['appsetting']['forum'];
			if ($where['style']) {
				$poatstyle = $where['style'];
			}
			$where['fid'] = $where['forumids'];
			$where['attachment'] = $where['isimg'] ? 2 : '';
			$where['authorid'] = $where['uids'] ? $where['uids'] : '';
			$where['isgroup'] = 0;
		} elseif ($config['appsetting']['recommend_content'] == 'Portal') {
			$mods = 2;
			$where = $config['appsetting']['Portal'];
			if ($where['style']) {
				$poatstyle = $where['style'];
			}
			$where['catid'] = $where['Portalids'] ? $where['Portalids'] : '';
			$where['pic'] = $where['isimg'] ? true : false;
			$where['uid'] = $where['uids'] ? $where['uids'] : '';
			$postlist = GuiigoApp::fetch_all_get_Portal_post($where, $start, $perpage);
		} elseif ($config['appsetting']['recommend_content'] == 'group') {
			$where = $config['appsetting']['group'];
			if ($where['style']) {
				$poatstyle = $where['style'];
			}
			$where['fid'] = $where['groupids'];
			$where['attachment'] = $where['isimg'] ? 2 : '';
			$where['authorid'] = $where['uids'] ? $where['uids'] : '';
			$where['isgroup'] = 1;
		}
		if ($config['appsetting']['recommend_content'] == 'group' || $config['appsetting']['recommend_content'] == 'forum') {
			$data = GuiigoApp::fetch_all_get_post($where, $start, $perpage);
			$postlist = getlistp($data);
		}
	} else {
		if ($orderid == 'user_interest') {
			$isopengz = true;
			if ($_G['uid']) {
				$uids = GuiigoApp::getUserList($_G['uid'], 'follow');
				if ($uids) {
					$where = array();
					$where['authorid'] = $uids;
					$where['noauthorid'] = $_G['uid'];
					$data = GuiigoApp::fetch_all_get_post($where, $start, $perpage, 'BY p.dateline DESC');
					$postlist = getlistp($data);
				}
				if ($postlist) {
					$isopengz = false;
				}
			}
			if ($isopengz && $_GET['page'] <= 1 && $config['appsetting']['user_follow_uids']) {
				$userlist = array();
				foreach (explode(',', $config['appsetting']['user_follow_uids']) as $k => $val) {
					$guser = getuserbyuid($val);
					$userlist[$k]['uid'] = $guser['uid'];
					$userlist[$k]['username'] = $guser['username'];
					$userlist[$k]['avatarurl'] = avatar($guser['uid'], 'big', true);
				}
				$data_html .= '<div id="nolist" style="display:none;"></div>';
			}
		} else {
			$pluginanv = false;
			if (strpos($_GET['orderid'], '_plugin') !== false) {
				$_GET['orderid'] = str_replace('_plugin', '', $_GET['orderid']);
				$pluginanv = true;
			}
			$orderid = intval($_GET['orderid']);
			$navs = $config['appsetting']['nav'];
			if ($orderid) {
				if ($pluginanv) {
					$navs = $config['appsetting']['nav2'];
				}
				$navarray = $navs[$orderid];
				if ($navarray['channel_extension'] == 'information') {
					$param = $navarray[$navarray['channel_extension']][$navarray['recommend_content']];
					if ($navarray['module_ids'] && $_GET['page'] <= 1) {
						$data_html = GuiigoApp::get_block_htnl($navarray['module_ids']);
					}
					if ($param['style']) {
						$poatstyle = $param['style'];
					}
					$where = $param;
					if ($navarray['recommend_content'] == 'Portal') {
						$mods = 2;
						$where['catid'] = $param['Portalids'] ? $param['Portalids'] : '';
						$where['pic'] = $param['isimg'] ? true : false;
						$where['uid'] = $param['uids'] ? $param['uids'] : '';
						$postlist = GuiigoApp::fetch_all_get_Portal_post($where, $start, $perpage);
					} else {
						$where['fid'] = $navarray['recommend_content'] == 'forum' ? $param['forumids'] : $param['groupids'];
						$where['isgroup'] = $navarray['recommend_content'] == 'forum' ? 0 : 1;
						$where['attachment'] = $param['isimg'] ? 2 : '';
						$where['authorid'] = $param['uids'] ? $param['uids'] : '';
						$data = GuiigoApp::fetch_all_get_post($where, $start, $perpage);
						$postlist = getlistp($data);
					}
				} elseif ($navarray['channel_extension'] == 'htmlcode') {
					$data_html = $navarray['htmlcode'];
					$data_html .= '<div id="nolist" style="display:none;"></div>';
				} elseif ($navarray['channel_extension'] == 'modules') {
					$data_html = GuiigoApp::get_block_htnl($navarray['modules']);
					$data_html .= '<div id="nolist" style="display:none;"></div>';
				}
			}
		}
	}
	if ($poatstyle == 1) {
		$mods == 1 ? include template('guiigo_manage:indexView') : (include template('guiigo_manage:PortalView'));
	} elseif ($poatstyle == 2) {
		include template('guiigo_manage:indexView2');
	} elseif ($poatstyle == 3) {
		include template('guiigo_manage:indexView3');
	} elseif ($poatstyle == 4) {
		$postlist = addfloor($postlist);
		include template('guiigo_manage:indexView4');
	}
	if ($guiigo_config['urluewriter']) {
		GuiigoApp_output(false);
	}
} elseif ($_GET['act'] == 'getGrougList') {
	$perpage = 10;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage - 1) * $perpage;
	$poatstyle = 1;
	$postlist = array();
	$groupary = $config['appsetting']['groupconfig'];
	if ($groupary['group_content_style']) {
		$poatstyle = $groupary['group_content_style'];
	}
	$where = array();
	$where['fid'] = $groupary['group_content_ids'];
	$where['authorid'] = $groupary['uids'];
	$where['isgroup'] = 1;
	$data = GuiigoApp::fetch_all_get_post($where, $start, $perpage);
	$postlist = getlistp($data);
	if (count($postlist) < $perpage && $_GET['page'] <= 1) {
		$data_html = '<div id="nolist" style="display:none;"></div>';
	}
	if ($poatstyle == 1) {
		include template('guiigo_manage:groupIndexView');
	} elseif ($poatstyle == 2) {
		include template('guiigo_manage:groupIndexView2');
	}
	if ($guiigo_config['urluewriter']) {
		GuiigoApp_output(false);
	}
}
function addfloor($data)
{
	foreach ($data as $pid => $post) {
		$data[$pid]['floor'] = GuiigoApp::GetPostlistFloor($post['tid']);
	}
	return $data;
}
function getlistp($data)
{
	global $_G;
	if (in_array('guiigo_video', $_G['setting']['plugins']['available']) && !class_exists('GuiigoVideo')) {
		include_once libfile('class/guiigovideo', 'plugin/guiigo_video');
	}
	$tids = $recommenustid = $postusers = $uids = $postlist = array();
	foreach ($data as $k => $v) {
		$tids[] = $v['tid'];
		$uids[$v['authorid']] = array();
	}
	$uids = array_keys($uids);
	$postusers = GuiigoApp::getPostUserListByids($uids);
	if ($_G['setting']['recommendthread']['status'] && $_G['uid']) {
		$recommenustid = DB::fetch_all('SELECT * FROM %t WHERE tid IN (%n) AND recommenduid=%d', array('forum_memberrecommend', $tids, $_G['uid']), 'tid');
	}
	foreach ($data as $pid => $post) {
		$post['message2'] = GuiigoApp::FloorMessageAnalysis($post['message']);
		$post['message'] = GuiigoApp::_messageAnalysis($post['message']);
		if (in_array('guiigo_video', $_G['setting']['plugins']['available'])) {
			$vtlp = GuiigoVideo::postlist_replace($post, 1);
			if ($vtlp['PlayerParam']) {
				$post['message'] = $vtlp['PlayerParam'];
			}
		}
		$post['message'] = substr($post['message'], 0, strlen($post['subject'])) == $post['subject'] ? '' : $post['message'];
		$post['forumlist'] = GuiigoApp::getForumByFid($post['fid']);
		$post['attapic'] = GuiigoApp::AttachImg($post['tid'], $post['pid']);
		$post['isrecommenus'] = 0;
		if (!empty($recommenustid) && $recommenustid[$post['tid']]['recommenduid'] > 0) {
			$post['isrecommenus'] = 1;
		}
		$postlist[$pid] = array_merge($post, (array) $postusers[$post['authorid']]);
	}
	return $postlist;
}