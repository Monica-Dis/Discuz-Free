<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache(array('pluginlanguage_script', 'pluginlanguage_template'));
if (submitcheck('submittemplate')) {
	$partpl = array();
	if (!empty($_GET['template'])) {
		$partpl = unserialize(DB::result_first('SELECT DATA FROM ' . DB::table('common_syscache') . ' WHERE cname=\'pluginlanguage_template\''));
		$partpl['guiigo_manage'] = array_merge($partpl['guiigo_manage'], $_GET['template']);
		C::t('common_syscache')->update('pluginlanguage_template', $partpl);
		unset($partpl);
		if ($_G['config']['output']['tplrefresh']) {
			cleartemplatecache();
		}
		cpmsg('setting_update_succeed', dreferer(), 'succeed');
	}
}
if (submitcheck('submitscript')) {
	$parscript = array();
	if (!empty($_GET['script'])) {
		$parscript = unserialize(DB::result_first('SELECT DATA FROM ' . DB::table('common_syscache') . ' WHERE cname=\'pluginlanguage_script\''));
		$parscript['guiigo_manage'] = array_merge($parscript['guiigo_manage'], $_GET['script']);
		C::t('common_syscache')->update('pluginlanguage_script', $parscript);
		unset($parscript);
		if ($_G['config']['output']['tplrefresh']) {
			cleartemplatecache();
		}
		cpmsg('setting_update_succeed', dreferer(), 'succeed');
	}
}
$scriptarr = array_chunk($_G['cache']['pluginlanguage_script']['guiigo_manage'], 20, true);
$templatearr = array_chunk($_G['cache']['pluginlanguage_template']['guiigo_manage'], 20, true);
showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=guiigo_manage&pmod=AdminLang');
foreach ($templatearr as $tk => $tv) {
	showtableheader(lang('plugin/guiigo_manage', 'slang0251') . ($tk + 1));
	foreach ($tv as $k => $v) {
		showsetting($k, 'template[' . $k . ']', $v, 'text', 0, 0);
	}
	showsubmit('submittemplate');
	showtablefooter(); /*Dism_taobao-com*/
}
unset($tk);
unset($tv);
unset($k);
unset($v);
foreach ($scriptarr as $tk => $tv) {
	showtableheader(lang('plugin/guiigo_manage', 'slang0263') . ($tk + 1));
	foreach ($tv as $k => $v) {
		showsetting($k, 'script[' . $k . ']', $v, 'text', 0, 0);
	}
	showsubmit('submitscript');
	showtablefooter(); /*Dism_taobao-com*/
}
showformfooter(); /*dism��taobao��com*/