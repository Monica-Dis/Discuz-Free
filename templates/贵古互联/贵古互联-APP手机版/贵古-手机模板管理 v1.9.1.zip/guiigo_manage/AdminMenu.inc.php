<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
include_once libfile('class/upload', 'plugin/guiigo_manage');
$upload = new upload();
$config = GuiigoApp::config();
GuiigoApp::verifyKey();/*From: DisM - Taobao - Com*/
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
$project_style_select = array();
$project_style_select[] = array('s1', lang('plugin/guiigo_manage', 'slang0239'));
$project_style_select[] = array('s2', lang('plugin/guiigo_manage', 'slang0240'));
$project_style_select[] = array('s3', lang('plugin/guiigo_manage', 'slang0241'));
$project_style_select[] = array('s4', lang('plugin/guiigo_manage', 'slang0242'));
$project_style_select[] = array('s5', lang('plugin/guiigo_manage', 'slang0243'));
$project_style_select[] = array('s6', lang('plugin/guiigo_manage', 'slang0244'));
$project_style_select[] = array('s7', lang('plugin/guiigo_manage', 'slang0245'));
$project_style_select[] = array('s8', lang('plugin/guiigo_manage', 'slang0246'));
$project_style_select[] = array('s9', lang('plugin/guiigo_manage', 'slang0247'));
if (!$_GET['save']) {
	showtips(lang('plugin/guiigo_manage', 'slang0248'));
	showformheader($basicurl . '&save=yes', 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0249'), 'nobottom');
	$html = lang('plugin/guiigo_manage', 'slang0250');
	if ($_GET['style'] && !$setting['menuconfig']['global_tab_menu'][$_GET['style']]) {
		$html = lang('plugin/guiigo_manage', 'slang0251');
	}
	foreach ($project_style_select as $sk => $sv) {
		$sy = 'style="color:#090;margin:0 10px;"';
		if ($sv[0] == $_GET['style']) {
			$sy = 'style="color: #e8594d;margin: 0 10px;font-weight: bold;"';
		}
		if ($setting['menuconfig']['global_tab_menu'][$sv[0]]) {
			$html .= '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'] . '&style=' . $sv[0] . '" ' . $sy . '>' . $sv[1] . '</a>';
		}
	}
	$html .= '</td></tr>';
	echo $html;
	showsubtitle(array(lang('plugin/guiigo_manage', 'slang0158'), lang('plugin/guiigo_manage', 'slang0252'), lang('plugin/guiigo_manage', 'slang0253'), lang('plugin/guiigo_manage', 'slang0254'), lang('plugin/guiigo_manage', 'slang0255'), lang('plugin/guiigo_manage', 'slang0256'), lang('plugin/guiigo_manage', 'slang0257'), lang('plugin/guiigo_manage', 'slang0258'), lang('plugin/guiigo_manage', 'slang0259'), lang('plugin/guiigo_manage', 'slang0260'), lang('plugin/guiigo_manage', 'slang0261')), 'header', array('class="td21"'));
	$style = $_GET['style'] ? $_GET['style'] : '0';
	$project_style = GuiigoApp::get_select('project_style', $project_style_select, $style, array('0', lang('plugin/guiigo_manage', 'slang0262')));
	$global_tab_menu = tab_menu_array_merge($setting['menuconfig']['global_tab_menu'][$style]);
	foreach ($global_tab_menu as $key => $value) {
		$icon = $deficon = $checked1 = $checked2 = $checked3 = '';
		if ($value['global_tab_menu_cache']) {
			$checked1 = 'checked';
		}
		if ($value['global_tab_menu_verify_login']) {
			$checked2 = 'checked';
		}
		if ($value['global_tab_menu_bulge']) {
			$checked3 = 'checked';
		}
		if ($value['global_tab_menu_icon']) {
			$icon = '<img src="source/plugin/guiigo_manage/navfile/' . $value['global_tab_menu_icon'] . '" style="width:30px;"/>';
		}
		if ($value['global_tab_menu_deficon']) {
			$deficon = '<img src="source/plugin/guiigo_manage/navfile/' . $value['global_tab_menu_deficon'] . '" style="width:30px;"/>';
		}
		$coloid = rand(10000, 99999);
		$coloid1 = rand(10000, 99999);
		showtablerow('', array('class="td25"', 'class="td25"', 'class="td25"', 'class="rowform"', 'class="rowform"', 'class="rowform"', 'class="td31"', 'class="td31"', 'class="td32"', 'class="td32"', 'class="td32"'), array('<input type="text" class="txt" name="settingnew[global_tab_menu_sort][' . $key . ']" value="' . $value['global_tab_menu_sort'] . '" />', '<input type="text" class="txt" name="settingnew[global_tab_menu_mark][' . $key . ']" value="' . $value['global_tab_menu_mark'] . '" />', '<input type="text" class="txt" name="settingnew[global_tab_menu_name][' . $key . ']" value="' . $value['global_tab_menu_name'] . '" />', '<input type="text" class="txt" name="settingnew[global_tab_menu_link][' . $key . ']" value="' . $value['global_tab_menu_link'] . '" />', '<input type="hidden" class="txt" name="settingnew[global_tab_menu_icon][' . $key . ']" value="' . $value['global_tab_menu_icon'] . '" readonly/><input style="" name="global_tab_menu_icon_file' . $key . '" value="" type="file" class="txt uploadbtn marginbot">' . $icon, '<input type="hidden" class="txt" name="settingnew[global_tab_menu_deficon][' . $key . ']" value="' . $value['global_tab_menu_deficon'] . '" readonly/><input style="" name="global_tab_menu_deficon_file' . $key . '" value="" type="file" class="txt uploadbtn marginbot">' . $deficon, '<input type="text" name="settingnew[global_tab_menu_activate_color][' . $key . ']" id="' . $coloid . '_v" type="text" class="txt" style="width:60px;display:block;" value="' . $value['global_tab_menu_activate_color'] . '" onchange="updatecolorpreview(' . $coloid . ')">
					<input id="' . $coloid . '" type="button" class="colorwd" onclick="return showcolors(' . $coloid . ');" style="background:' . $value['global_tab_menu_activate_color'] . '">
						<span id="' . $coloid . '_menu" style="display:none"><iframe id="' . $coloid . '_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe>', '<input type="text" name="settingnew[global_tab_menu_color][' . $key . ']" id="' . $coloid1 . '_v" type="text" class="txt" style="width:60px;display:block;" value="' . $value['global_tab_menu_color'] . '" onchange="updatecolorpreview(' . $coloid1 . ')">
					<input id="' . $coloid1 . '" type="button" class="colorwd" onclick="return showcolors(' . $coloid1 . ');" style="background:' . $value['global_tab_menu_color'] . '">
						<span id="' . $coloid1 . '_menu" style="display:none"><iframe id="' . $coloid1 . '_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe>', '<input type="checkbox" class="txt" name="settingnew[global_tab_menu_bulge][' . $key . ']" value="1" ' . $checked3 . ' />', '<input type="checkbox" class="txt" name="settingnew[global_tab_menu_cache][' . $key . ']" value="1" ' . $checked1 . ' />', '<input type="checkbox" class="txt" name="settingnew[global_tab_menu_verify_login][' . $key . ']" value="1" ' . $checked2 . ' />'));
	}
	echo lang('plugin/guiigo_manage', 'slang0265') . $project_style . lang('plugin/guiigo_manage', 'slang0266');
	echo '<script>
					function showcolors(coloid) {
						document.getElementById(coloid+\'_frame\').src=\'static/image/admincp/getcolor.htm?\'+coloid+\'|\'+coloid+\'_v\';
						showMenu({ctrlid:coloid});
					}
				</script>';
	showtablefooter(); /*Dism_taobao-com*/
	showtableheader('', 'notop');
	showsubmit('settabsubmit');
	showtablefooter(); /*Dism_taobao-com*/
	showformfooter(); /*dism��taobao��com*/
	unset($key);
	unset($value);
	unset($icon);
	unset($deficon);
	unset($checked1);
	unset($checked2);
	unset($checked3);
	showformheader($basicurl . '&save=yes', 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0105'), 'nobottom');
	showsubtitle(array(lang('plugin/guiigo_manage', 'slang0158'), lang('plugin/guiigo_manage', 'slang0106'), lang('plugin/guiigo_manage', 'slang0107'), lang('plugin/guiigo_manage', 'slang0108')), 'header', array('class="td21"'));
	$global_broadside_menu = broadside_menu_array_merge($setting['menuconfig']['global_broadside_menu']);
	foreach ($global_broadside_menu as $key => $value) {
		$checked = '';
		if ($value['global_broadside_menu_open']) {
			$checked = 'checked';
		}
		$deleterow = '<td><div><a href="javascript:;"></a></div></td>';
		$readonly = 'readonly';
		if (!$value['global_broadside_menu_default']) {
			$deleterow = '<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . lang('plugin/guiigo_manage', 'slang0043') . '</a></div></td>';
			$readonly = '';
		}
		showtablerow('', array('class="td25"', 'class="td21"', 'class="rowform"', 'class="rowform"', 'class="td31"', 'class="td25"'), array('<input type="text" class="txt" name="settingnew[global_broadside_menu_sort][' . $key . ']" value="' . $value['global_broadside_menu_sort'] . '" />', '<input type="text" class="txt" name="settingnew[global_broadside_menu_name][' . $key . ']" value="' . $value['global_broadside_menu_name'] . '"  ' . $readonly . '/>', '<input type="text" class="txt" name="settingnew[global_broadside_menu_icon][' . $key . ']" value="' . $value['global_broadside_menu_icon'] . '"  ' . $readonly . '/>', '<input type="text" class="txt" name="settingnew[global_broadside_menu_link][' . $key . ']" value="' . $value['global_broadside_menu_link'] . '"  ' . $readonly . '/>', lang('plugin/guiigo_manage', 'slang0109') . '<input type="checkbox" class="txt" name="settingnew[global_broadside_menu_open][' . $key . ']" value="1" ' . $checked . '/>', '<input type="hidden" name="settingnew[global_broadside_menu_default][' . $key . ']" value="' . $value['global_broadside_menu_default'] . '"/>' . $deleterow));
	}
	echo '<tr><td><div><a href="javascript:;" onclick="addrow(this, 0);" class="addtr">' . lang('plugin/guiigo_manage', 'slang0110') . '</a></div></td></tr>';
	unset($key);
	unset($value);
	showtablefooter(); /*Dism_taobao-com*/
	showtableheader(lang('plugin/guiigo_manage', 'slang0112'), 'nobottom');
	showsubtitle(array(lang('plugin/guiigo_manage', 'slang0158'), lang('plugin/guiigo_manage', 'slang0106'), lang('plugin/guiigo_manage', 'slang0107'), lang('plugin/guiigo_manage', 'slang0108')), 'header', array('class="td21"'));
	$global_personage_menu = personage_menu_array_merge($setting['menuconfig']['global_personage_menu']);
	foreach ($global_personage_menu as $key => $value) {
		$checked2 = '';
		if ($value['global_personage_menu_open']) {
			$checked2 = 'checked';
		}
		$deleterow2 = '<td><div><a href="javascript:;"></a></div></td>';
		$readonly2 = 'readonly';
		if (!$value['global_personage_menu_default']) {
			$deleterow2 = '<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . lang('plugin/guiigo_manage', 'slang0043') . '</a></div></td>';
			$readonly2 = '';
		}
		showtablerow('', array('class="td25"', 'class="td21"', 'class="rowform"', 'class="rowform"', 'class="td31"', 'class="td25"'), array('<input type="text" class="txt" name="settingnew[global_personage_menu_sort][' . $key . ']" value="' . $value['global_personage_menu_sort'] . '" />', '<input type="text" class="txt" name="settingnew[global_personage_menu_name][' . $key . ']" value="' . $value['global_personage_menu_name'] . '"  ' . $readonly2 . '/>', '<input type="text" class="txt" name="settingnew[global_personage_menu_icon][' . $key . ']" value="' . $value['global_personage_menu_icon'] . '"   ' . $readonly2 . '/>', '<input type="text" class="txt" name="settingnew[global_personage_menu_link][' . $key . ']" value="' . $value['global_personage_menu_link'] . '"   ' . $readonly2 . '/>', lang('plugin/guiigo_manage', 'slang0109') . '<input type="checkbox" class="txt" name="settingnew[global_personage_menu_open][' . $key . ']" value="1" ' . $checked2 . '/>', '<input type="hidden" name="settingnew[global_personage_menu_default][' . $key . ']" value="' . $value['global_personage_menu_default'] . '"/>' . $deleterow2));
	}
	echo '<tr><td><div><a href="javascript:;" onclick="addrow(this, 1);" class="addtr">' . lang('plugin/guiigo_manage', 'slang0110') . '</a></div></td></tr>';
	unset($key);
	unset($value);
	showtablefooter(); /*Dism_taobao-com*/
	showtableheader(lang('plugin/guiigo_manage', 'slang0111'), 'nobottom');
	showsubtitle(array(lang('plugin/guiigo_manage', 'slang0158'), lang('plugin/guiigo_manage', 'slang0106'), lang('plugin/guiigo_manage', 'slang0107'), lang('plugin/guiigo_manage', 'slang0108')), 'header', array('class="td21"'));
	$global_information_menu = information_menu_array_merge($setting['menuconfig']['global_information_menu']);
	foreach ($global_information_menu as $key => $value) {
		$checked3 = '';
		if ($value['global_information_menu_open']) {
			$checked3 = 'checked';
		}
		$deleterow3 = '<td><div><a href="javascript:;"></a></div></td>';
		$readonly3 = 'readonly';
		if (!$value['global_information_menu_default']) {
			$deleterow3 = '<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . lang('plugin/guiigo_manage', 'slang0043') . '</a></div></td>';
			$readonly3 = '';
		}
		showtablerow('', array('class="td25"', 'class="td21"', 'class="rowform"', 'class="rowform"', 'class="td31"', 'class="td25"'), array('<input type="text" class="txt" name="settingnew[global_information_menu_sort][' . $key . ']" value="' . $value['global_information_menu_sort'] . '" />', '<input type="text" class="txt" name="settingnew[global_information_menu_name][' . $key . ']" value="' . $value['global_information_menu_name'] . '"  ' . $readonly3 . '/>', '<input type="text" class="txt" name="settingnew[global_information_menu_icon][' . $key . ']" value="' . $value['global_information_menu_icon'] . '"  ' . $readonly3 . '/>', '<input type="text" class="txt" name="settingnew[global_information_menu_link][' . $key . ']" value="' . $value['global_information_menu_link'] . '"  ' . $readonly3 . '/>', lang('plugin/guiigo_manage', 'slang0109') . '<input type="checkbox" class="txt" name="settingnew[global_information_menu_open][' . $key . ']" value="1" ' . $checked3 . ' />', '<input type="hidden" name="settingnew[global_information_menu_default][' . $key . ']" value="' . $value['global_information_menu_default'] . '"/>' . $deleterow3));
	}
	echo '<tr><td><div><a href="javascript:;" onclick="addrow(this, 2);" class="addtr">' . lang('plugin/guiigo_manage', 'slang0110') . '</a></div></td></tr>';
	$txtopen = lang('plugin/guiigo_manage', 'slang0109');
	$txtdel = lang('plugin/guiigo_manage', 'slang0043');
	echo '	<script type="text/JavaScript">
		var rowtypedata = [
			[
					[0,\'<input type="text" class="txt" name="settingnew[global_broadside_menu_sort][]" value="">\', \'td21\'],
					[0,\'<input type="text" class="txt" name="settingnew[global_broadside_menu_name][]" value="">\', \'td31\'],
					[0,\'<input type="text" class="txt" name="settingnew[global_broadside_menu_icon][]" value="">\', \'rowform\'],
					[0,\'<input type="text" class="txt" name="settingnew[global_broadside_menu_link][]" value="">\', \'rowform\'],
					[0,\'' . $txtopen . '<input type="checkbox" class="text" name="settingnew[global_broadside_menu_open][]" value="1" checked>\', \'td31\'],
					[0,\'<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . $txtdel . '</a></div></td>\'],
				
			],
			[
				[0,\'<input type="text" class="txt" name="settingnew[global_personage_menu_sort][]" value="">\', \'td21\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_personage_menu_name][]" value="">\', \'td31\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_personage_menu_icon][]" value="">\', \'rowform\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_personage_menu_link][]" value="">\', \'rowform\'],
				[0,\'' . $txtopen . '<input type="checkbox" class="text" name="settingnew[global_personage_menu_open][]" value="1" checked>\', \'td31\'],
				[0,\'<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . $txtdel . '</a></div></td>\']
			],
			[
				[0,\'<input type="text" class="txt" name="settingnew[global_information_menu_sort][]" value="">\', \'td21\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_information_menu_name][]" value="">\', \'td31\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_information_menu_icon][]" value="">\', \'rowform\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_information_menu_link][]" value="">\', \'rowform\'],
				[0,\'' . $txtopen . '<input type="checkbox" class="text" name="settingnew[global_personage_menu_open][]" value="1" checked>\', \'td31\'],
				[0,\'<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . $txtdel . '</a></div></td>\']
			]
		];
	</script>';
	unset($key);
	unset($value);
	showtablefooter(); /*Dism_taobao-com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter(); /*Dism_taobao-com*/
	showformfooter(); /*dism��taobao��com*/
}
if (submitcheck('settabsubmit')) {
	$newdata = array();
	foreach ($_POST['settingnew']['global_tab_menu_name'] as $key => $val) {
		$file = $_FILES['global_tab_menu_icon_file' . $key];
		$deficon = $_FILES['global_tab_menu_deficon_file' . $key];
		$delfile = $_POST['settingnew']['global_tab_menu_icon'][$key];
		$defdelfile = $_POST['settingnew']['global_tab_menu_deficon'][$key];
		$fileimgurl = $defdelfileimgurl = '';
		if ($file && $file['name']) {
			$fileimgurl = $upload->upFileSave($_FILES['global_tab_menu_icon_file' . $key], $delfile);
		}
		if ($deficon && $deficon['name']) {
			$defdelfileimgurl = $upload->upFileSave($_FILES['global_tab_menu_deficon_file' . $key], $defdelfile);
		}
		$newdata[$key]['global_tab_menu_sort'] = $_POST['settingnew']['global_tab_menu_sort'][$key];
		$newdata[$key]['global_tab_menu_mark'] = $_POST['settingnew']['global_tab_menu_mark'][$key];
		$newdata[$key]['global_tab_menu_name'] = $_POST['settingnew']['global_tab_menu_name'][$key];
		$newdata[$key]['global_tab_menu_link'] = $_POST['settingnew']['global_tab_menu_link'][$key];
		$newdata[$key]['global_tab_menu_icon'] = $fileimgurl ? $fileimgurl : $_POST['settingnew']['global_tab_menu_icon'][$key];
		$newdata[$key]['global_tab_menu_deficon'] = $defdelfileimgurl ? $defdelfileimgurl : $_POST['settingnew']['global_tab_menu_deficon'][$key];
		$newdata[$key]['global_tab_menu_activate_color'] = $_POST['settingnew']['global_tab_menu_activate_color'][$key];
		$newdata[$key]['global_tab_menu_color'] = $_POST['settingnew']['global_tab_menu_color'][$key];
		$newdata[$key]['global_tab_menu_bulge'] = $_POST['settingnew']['global_tab_menu_bulge'][$key];
		$newdata[$key]['global_tab_menu_cache'] = $_POST['settingnew']['global_tab_menu_cache'][$key];
		$newdata[$key]['global_tab_menu_verify_login'] = $_POST['settingnew']['global_tab_menu_verify_login'][$key];
	}
	array_multisort(array_column($newdata, 'global_tab_menu_sort'), SORT_ASC, $newdata);
	if (!$_POST['project_style'] || $_POST['project_style'] == '0') {
		cpmsg(lang('plugin/guiigo_manage', 'slang0267'), dreferer(), 'succeed');
	}
	if ($_POST['delproject_style']) {
		$newdata = '';
	}
	$setting['menuconfig']['global_tab_menu'][$_POST['project_style']] = $newdata;
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
if (submitcheck('settingsubmit')) {
	$newdata = array();
	$newdata['global_tab_menu'] = $setting['menuconfig']['global_tab_menu'];
	$newdata['global_broadside_menu'] = array();
	foreach ($_POST['settingnew']['global_broadside_menu_name'] as $key => $val) {
		if ($_POST['settingnew']['global_broadside_menu_link'][$key] == 'portal.php?mod=index') {
			$_POST['settingnew']['global_broadside_menu_link'][$key] = 'plugin.php?id=guiigo_manage&act=index';
		}
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_sort'] = $_POST['settingnew']['global_broadside_menu_sort'][$key];
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_name'] = $_POST['settingnew']['global_broadside_menu_name'][$key];
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_icon'] = $_POST['settingnew']['global_broadside_menu_icon'][$key];
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_link'] = $_POST['settingnew']['global_broadside_menu_link'][$key];
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_open'] = !empty($_POST['settingnew']['global_broadside_menu_open'][$key]) ? 1 : 0;
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_default'] = $_POST['settingnew']['global_broadside_menu_default'][$key];
	}
	array_multisort(array_column($newdata['global_broadside_menu'], 'global_broadside_menu_sort'), SORT_ASC, $newdata['global_broadside_menu']);
	$newdata['global_personage_menu'] = array();
	foreach ($_POST['settingnew']['global_personage_menu_name'] as $key => $val) {
		$newdata['global_personage_menu'][$key]['global_personage_menu_sort'] = $_POST['settingnew']['global_personage_menu_sort'][$key];
		$newdata['global_personage_menu'][$key]['global_personage_menu_name'] = $_POST['settingnew']['global_personage_menu_name'][$key];
		$newdata['global_personage_menu'][$key]['global_personage_menu_icon'] = $_POST['settingnew']['global_personage_menu_icon'][$key];
		$newdata['global_personage_menu'][$key]['global_personage_menu_link'] = $_POST['settingnew']['global_personage_menu_link'][$key];
		$newdata['global_personage_menu'][$key]['global_personage_menu_open'] = !empty($_POST['settingnew']['global_personage_menu_open'][$key]) ? 1 : 0;
		$newdata['global_personage_menu'][$key]['global_personage_menu_default'] = $_POST['settingnew']['global_personage_menu_default'][$key];
	}
	array_multisort(array_column($newdata['global_personage_menu'], 'global_personage_menu_sort'), SORT_ASC, $newdata['global_personage_menu']);
	$newdata['global_information_menu'] = array();
	foreach ($_POST['settingnew']['global_information_menu_name'] as $key => $val) {
		$newdata['global_information_menu'][$key]['global_information_menu_sort'] = $_POST['settingnew']['global_information_menu_sort'][$key];
		$newdata['global_information_menu'][$key]['global_information_menu_name'] = $_POST['settingnew']['global_information_menu_name'][$key];
		$newdata['global_information_menu'][$key]['global_information_menu_icon'] = $_POST['settingnew']['global_information_menu_icon'][$key];
		$newdata['global_information_menu'][$key]['global_information_menu_link'] = $_POST['settingnew']['global_information_menu_link'][$key];
		$newdata['global_information_menu'][$key]['global_information_menu_open'] = !empty($_POST['settingnew']['global_information_menu_open'][$key]) ? 1 : 0;
		$newdata['global_information_menu'][$key]['global_information_menu_default'] = $_POST['settingnew']['global_information_menu_default'][$key];
	}
	array_multisort(array_column($newdata['global_information_menu'], 'global_information_menu_sort'), SORT_ASC, $newdata['global_information_menu']);
	$setting['menuconfig'] = $newdata;
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
echo "\r\n\r\n";
function broadside_menu_array_merge($ary)
{
	$newary = array(array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0113'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-sy.png', 'global_broadside_menu_link' => 'plugin.php?id=guiigo_manage&act=index', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 1), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0114'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-sq.png', 'global_broadside_menu_link' => 'forum.php?forumlist=1&do=guanzhu', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 2), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0115'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-qz.png', 'global_broadside_menu_link' => 'group.php?mod=index', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 3), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0116'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-xx.png', 'global_broadside_menu_link' => 'home.php?mod=space&do=pm&filter=privatepm', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 4), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0117'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-tt.png', 'global_broadside_menu_link' => 'portal.php?mod=list&catid=1', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 5), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0118'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-dd.png', 'global_broadside_menu_link' => 'forum.php?mod=guide&view=hot', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 6), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0119'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-xc.png', 'global_broadside_menu_link' => 'home.php?mod=space&do=album&view=all', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 7), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0120'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-sb.png', 'global_broadside_menu_link' => 'home.php?mod=space&do=doing&view=all', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 7), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0121'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-rz.png', 'global_broadside_menu_link' => 'home.php?mod=space&do=blog&view=all', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 9), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0122'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-yp.png', 'global_broadside_menu_link' => 'misc.php?mod=ranklist&type=member&view=post', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 10), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0123'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-tp.png', 'global_broadside_menu_link' => 'misc.php?mod=ranklist&type=thread&view=replies&orderby=all', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 11), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0124'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-bp.png', 'global_broadside_menu_link' => 'misc.php?mod=ranklist&type=forum&view=threads', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 12), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0125'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-qp.png', 'global_broadside_menu_link' => 'misc.php?mod=ranklist&type=group&view=credit', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 13), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0126'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-ss.png', 'global_broadside_menu_link' => 'search.php?mod=forum', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 14), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0127'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-rw.png', 'global_broadside_menu_link' => 'home.php?mod=task', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 15), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0128'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-xz.png', 'global_broadside_menu_link' => 'home.php?mod=medal', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 16), array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0129'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-bq.png', 'global_broadside_menu_link' => 'misc.php?mod=tag', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1', 'global_broadside_menu_sort' => 17));
	return $ary && is_array($ary) ? $ary : $newary;
}
function personage_menu_array_merge($ary)
{
	$newary = array(array('global_personage_menu_name' => lang('plugin/guiigo_manage', 'slang0130'), 'global_personage_menu_icon' => 'template/guiigo_app/static/images/cgd-xc.png', 'global_personage_menu_link' => 'home.php?mod=space&do=album&view=me', 'global_personage_menu_open' => '1', 'global_personage_menu_default' => '1', 'global_personage_menu_sort' => 1), array('global_personage_menu_name' => lang('plugin/guiigo_manage', 'slang0131'), 'global_personage_menu_icon' => 'template/guiigo_app/static/images/cgd-rz.png', 'global_personage_menu_link' => 'home.php?mod=space&do=blog&view=me', 'global_personage_menu_open' => '1', 'global_personage_menu_default' => '1', 'global_personage_menu_sort' => 2), array('global_personage_menu_name' => lang('plugin/guiigo_manage', 'slang0132'), 'global_personage_menu_icon' => 'template/guiigo_app/static/images/cgd-rw.png', 'global_personage_menu_link' => 'home.php?mod=task&item=doing', 'global_personage_menu_open' => '1', 'global_personage_menu_default' => '1', 'global_personage_menu_sort' => 3));
	return $ary && is_array($ary) ? $ary : $newary;
}
function information_menu_array_merge($ary)
{
	$newary = array(array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0133'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-a.png', 'global_information_menu_link' => 'plugin.php?id=guiigo_sign', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 1), array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0134'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-b.png', 'global_information_menu_link' => 'forum.php?mod=misc&action=nav', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 2), array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0135'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-c.png', 'global_information_menu_link' => 'forum.php?mod=forumdisplay&fid=100', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 3), array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0136'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-d.png', 'global_information_menu_link' => 'group.php?mod=index', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 4), array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0137'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-e.png', 'global_information_menu_link' => 'home.php?mod=space&do=doing&view=all', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 5), array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0276'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-f.png', 'global_information_menu_link' => 'home.php?mod=spacecp&ac=blog', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 6), array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0277'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-g.png', 'global_information_menu_link' => 'home.php?mod=spacecp&ac=upload', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 7), array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0278'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-h.png', 'global_information_menu_link' => 'portal.php?mod=list&catid=1', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 8), array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0279'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-i.png', 'global_information_menu_link' => 'home.php?mod=task', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 9), array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0280'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-j.png', 'global_information_menu_link' => 'forum.php?mod=forumdisplay&fid=96', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1', 'global_information_menu_sort' => 10));
	return $ary && is_array($ary) ? $ary : $newary;
}
function tab_menu_array_merge($ary)
{
	global $_G;
	$newary = array(array('global_tab_menu_sort' => 1, 'global_tab_menu_mark' => 'sy', 'global_tab_menu_name' => lang('plugin/guiigo_manage', 'slang0113'), 'global_tab_menu_link' => $_G['siteurl'] . 'plugin.php?id=guiigo_manage&act=index&navactivate=sy', 'global_tab_menu_icon' => '', 'global_tab_menu_deficon' => '', 'global_tab_menu_activate_color' => '', 'global_tab_menu_color' => '', 'global_tab_menu_bulge' => 0, 'global_tab_menu_cache' => 1, 'global_tab_menu_verify_login' => 0), array('global_tab_menu_sort' => 2, 'global_tab_menu_mark' => 'sq', 'global_tab_menu_name' => lang('plugin/guiigo_manage', 'slang0114'), 'global_tab_menu_link' => $_G['siteurl'] . 'forum.php?forumlist=1&do=guanzhu&navactivate=sq', 'global_tab_menu_icon' => '', 'global_tab_menu_deficon' => '', 'global_tab_menu_activate_color' => '', 'global_tab_menu_color' => '', 'global_tab_menu_bulge' => 0, 'global_tab_menu_cache' => 1, 'global_tab_menu_verify_login' => 0), array('global_tab_menu_sort' => 3, 'global_tab_menu_mark' => 'qz', 'global_tab_menu_name' => lang('plugin/guiigo_manage', 'slang0115'), 'global_tab_menu_link' => $_G['siteurl'] . 'group.php?mod=index&navactivate=qz', 'global_tab_menu_icon' => '', 'global_tab_menu_deficon' => '', 'global_tab_menu_activate_color' => '', 'global_tab_menu_color' => '', 'global_tab_menu_bulge' => 0, 'global_tab_menu_cache' => 1, 'global_tab_menu_verify_login' => 0), array('global_tab_menu_sort' => 4, 'global_tab_menu_mark' => 'xx', 'global_tab_menu_name' => lang('plugin/guiigo_manage', 'slang0116'), 'global_tab_menu_link' => $_G['siteurl'] . 'home.php?mod=space&do=pm&filter=privatepm&navactivate=xx', 'global_tab_menu_icon' => '', 'global_tab_menu_deficon' => '', 'global_tab_menu_activate_color' => '', 'global_tab_menu_color' => '', 'global_tab_menu_bulge' => 0, 'global_tab_menu_cache' => 1, 'global_tab_menu_verify_login' => 1), array('global_tab_menu_sort' => 5, 'global_tab_menu_mark' => 'wd', 'global_tab_menu_name' => lang('plugin/guiigo_manage', 'slang0264'), 'global_tab_menu_link' => $_G['siteurl'] . 'home.php?mod=space&uid={uid}&do=profile&mycenter=1&navactivate=wd', 'global_tab_menu_icon' => '', 'global_tab_menu_deficon' => '', 'global_tab_menu_activate_color' => '', 'global_tab_menu_color' => '', 'global_tab_menu_bulge' => 0, 'global_tab_menu_cache' => 1, 'global_tab_menu_verify_login' => 1));
	return $ary && is_array($ary) ? $ary : $newary;
}