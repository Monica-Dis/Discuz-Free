<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class CacheFile
{
	public $path;
	public $dir;
	public function instance($cacheconfig)
	{
		$object;
		if ($object == NULL) {
			$object = new CacheFile($cacheconfig);
		}
		return $object;
	}
	public function __construct($cacheconfig)
	{
		$this->path = $cacheconfig['filepath'];
		if ($cacheconfig['filedir']) {
			$this->dir = $cacheconfig['filedir'];
		}
	}
	public function get_cache($key)
	{
		if ($this->cache_exists($key)) {
			$data = $this->_get_cache($key);
			return $data['data'];
		}
		return false;
	}
	public function set_cache($key, $value, $life = '', $del_time = '')
	{
		global $_G;
		if ($del_time) {
			$this->del_dir($key, $del_time);
		}
		$data = array($key => array('data' => $value, 'life' => $life));
		$cache_file = $this->get_cache_file_path($key);
		dmkdir(dirname($cache_file));
		$cachedata = "\$data = " . $this->arrayeval($data) . ";\n";
		if ($fp = @fopen($cache_file, 'wb')) {
			fwrite($fp, '<?php
//Discuz! cache file, DO NOT modify me!' . '
//Created: ' . date('M j, Y, G:i') . '
//Identify: ' . md5($cache_file . $cachedata . $_G['config']['security']['authkey']) . ('

if(!defined(\'IN_DISCUZ\')) {
	exit(\'Access Denied\');
}

' . $cachedata . '?>'));
			fclose($fp);
		} else {
			exit('Can not write to cache files, please check directory ' . $this->path . ' ');
		}
		return true;
	}
	public function del_cache($key)
	{
		$cache_file = $this->get_cache_file_path($key);
		if (file_exists($cache_file)) {
			return @unlink($cache_file);
		}
		return true;
	}
	public function _get_cache($key)
	{
		$data = NULL;
		if (!isset($data[$key])) {
			include $this->get_cache_file_path($key);
		}
		return $data[$key];
	}
	public function cache_exists($key)
	{
		$cache_file = $this->get_cache_file_path($key);
		if (!file_exists($cache_file)) {
			return false;
		}
		$data = $this->_get_cache($key);
		if ($data['life'] && filemtime($cache_file) < time() - $data['life']) {
			$this->del_cache($cache_file);
			return false;
		}
		return true;
	}
	public function del_dir($key, $del_time, $fndir = '')
	{
		if ($fndir) {
			$dir = $fndir;
		} else {
			if ($this->dir) {
				$dir = $this->path . '/' . $this->dir;
			} else {
				if ($key) {
					$dir = $this->path . '/' . hexdec($key[0] . $key[1] . $key[2]) % 1000;
				} else {
					return false;
				}
			}
		}
		if ($directory = @dir($dir)) {
			while ($entry = $directory->read()) {
				$filename = $dir . '/' . $entry;
				if ($entry != '.' && $entry != '..') {
					if (is_file($filename) && filemtime($filename) < time() - $del_time) {
						@unlink($filename);
					} else {
						$this->del_dir($key, $del_time, $filename);
						@rmdir($filename);
					}
				}
			}
			$directory->close();
		}
	}
	public function get_cache_file_path($key)
	{
		$cache_path = NULL;
		if (!isset($cache_path[$key])) {
			if ($this->dir) {
				$dir = $this->dir;
			} else {
				$dir = hexdec($key[0] . $key[1] . $key[2]) % 1000;
			}
			$cache_path[$key] = $this->path . '/' . $dir . '/' . $key . '.php';
		}
		return $cache_path[$key];
	}
	public function arrayeval($array, $level = 0)
	{
		if (!is_array($array)) {
			return '\'' . $array . '\'';
		}
		if (is_array($array) && function_exists('var_export')) {
			return var_export($array, true);
		}
		$space = '';
		for ($i = 0; $i <= $level; $i++) {
			$space .= '	';
		}
		$evaluate = "Array\n" . $space . "(\n";
		$comma = $space;
		if (is_array($array)) {
			foreach ($array as $key => $val) {
				$key = is_string($key) ? '\'' . addcslashes($key, '\'\\') . '\'' : $key;
				$val = !is_array($val) && (!preg_match('/^\\-?[1-9]\\d*$/', $val) || strlen($val) > 12) ? '\'' . addcslashes($val, '\'\\') . '\'' : $val;
				if (is_array($val)) {
					$evaluate .= $comma . $key . ' => ' . arrayeval($val, $level + 1);
				} else {
					$evaluate .= $comma . $key . ' => ' . $val;
				}
				$comma = ",\n" . $space;
			}
		}
		$evaluate .= "\n" . $space . ")";
		return $evaluate;
	}
}