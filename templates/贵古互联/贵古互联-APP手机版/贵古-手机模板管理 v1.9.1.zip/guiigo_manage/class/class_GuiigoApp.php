<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!is_array($_G['cache']['usergroups'])) {
	loadcache('usergroups');
}
class GuiigoApp
{
	public static function config()
	{
		global $_G;
		if (!isset($_G['cache']['plugin']) || !isset($_G['cache']['Ggroups'])) {
			loadcache(array('plugin', 'Ggroups'));
		}
		$Ggroups = $_G['cache']['Ggroups']['groups'];
		$cachetimeupdate = TIMESTAMP - intval($_G['cache']['Ggroups']['updateline']);
		if (empty($_G['cache']['Ggroups']) || $cachetimeupdate > 86400 || empty($Ggroups)) {
			$data = array();
			$data['updateline'] = TIMESTAMP;
			$data['groups'] = $Ggroup = DB::fetch_all('SELECT* FROM %t WHERE type=%s AND status=%d', array('forum_forum', 'sub', 3), 'fid');
			savecache('Ggroups', $data);
		}
		$pluginConfig = $_G['cache']['plugin']['guiigo_manage'];
		$pluginConfig['siteurl'] = $_G['siteurl'];
		$setting;
		if ($_G['setting']['guiigo_manage']) {
			$setting = $_G['setting']['guiigo_manage'];
		} else {
			$resetting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
			$setting = $resetting['guiigo_manage'];
		}
		$pluginConfig['appsetting'] = empty($setting) ? array() : (array) unserialize($setting);
		$pluginConfig['appsetting']['userconfig']['show_ad_slide'] = self::GetTypeArr($pluginConfig['appsetting']['userconfig']['show_ad_slide']);
		$pluginConfig['appsetting']['userconfig']['search_slide'] = self::GetTypeArr($pluginConfig['appsetting']['userconfig']['search_slide']);
		$pluginConfig['appsetting']['forumconfig']['show_pyqhd'] = self::GetTypeArr($pluginConfig['appsetting']['forumconfig']['show_pyqhd']);
		$pluginConfig['appsetting']['groupconfig']['group_slide'] = self::GetTypeArr($pluginConfig['appsetting']['groupconfig']['group_slide']);
		$pluginConfig['appsetting']['index_header_window_content'] = self::GetTypeArr($pluginConfig['appsetting']['index_header_window_content']);
		$nav = $pluginConfig['appsetting']['nav'];
		$pluginConfig['appsetting']['nav'] = self::ksortary($nav);
		$pluginConfig['appsetting']['nav2'] = self::ksortary($nav, 'order', 2);
		$pluginConfig['isguiigoapp'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'guiigoapp') === false);
		$browser = self::getHtUsAgent();
		$pluginConfig['browser'] = array('iswx' => $browser['iswx'], 'isqq' => $browser['isqq'], 'isuc' => $browser['isuc']);
		return $pluginConfig;
	}
	public static function CacheData($cacheconfig, $arg)
	{
		if (!class_exists('CacheFile')) {
			include_once libfile('class/CacheFile', 'plugin/guiigo_manage');
		}
		$CacheObj;
		if ($CacheObj == NULL) {
			if (!$cacheconfig['filepath']) {
				$cacheconfig['filepath'] = DISCUZ_ROOT . 'source/plugin/guiigo_manage/cachefile';
			}
			$CacheObj = CacheFile::instance($cacheconfig);
		}
		switch ($cacheconfig['optype']) {
			case 'set_cache':
				return $CacheObj->set_cache($arg['key'], $arg['value'], $arg['life'], $arg['del_time']);
			case 'get_cache':
				return $CacheObj->get_cache($arg['key']);
			case 'del_cache':
				return $CacheObj->del_cache($arg['key']);
			case 'del_dir':
				return $CacheObj->del_dir($arg['key'], $arg['del_time']);
			case 'object':
				return $CacheObj;
		}
		return false;
	}
	public static function getHtUsAgent()
	{
		$type = array();
		$type['iswx'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') === false);
		$type['isqq'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'mqqbrowser') === false);
		$type['isuc'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'ucbrowser') === false);
		return $type;
	}
	public static function get($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		if (!curl_exec($ch)) {
			error_log(curl_error($ch));
			$data = '';
		} else {
			$data = curl_multi_getcontent($ch);
		}
		curl_close($ch);
		return $data;
	}
	public static function getSignPackage($url)
	{
		$config = self::config();
		$jsapiTicket = self::getJsApiTicket();
		$timestamp = time();
		$nonceStr = self::createNonceStr();
		$string = 'jsapi_ticket=' . $jsapiTicket . '&noncestr=' . $nonceStr . '&timestamp=' . $timestamp . '&url=' . $url;
		$signature = sha1($string);
		$signPackage = array('appid' => $config['wx_appid'], 'nonceStr' => $nonceStr, 'timestamp' => $timestamp, 'signature' => $signature);
		return $signPackage;
	}
	public static function createNonceStr($length = 16)
	{
		$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		$str = '';
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}
	public static function getJsApiTicket()
	{
		global $_G;
		include_once libfile('function/cache');
		$config = self::config();
		$appid = $config['wx_appid'];
		$appsecret = $config['wx_appsecret'];
		$cache_jsapi_ticket = 'fxtickets_' . $appid . $appsecret;
		loadcache($cache_jsapi_ticket);
		$jsapi_ticket = $_G['cache'][$cache_jsapi_ticket];
		if ($jsapi_ticket['jsapi_ticket'] && $jsapi_ticket['expire_time'] > time()) {
			return $jsapi_ticket['jsapi_ticket'];
		}
		$accessToken = self::getAccessToken();
		$url = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=' . $accessToken;
		$res = json_decode(self::get($url), true);
		$ticket = $res['ticket'];
		$jsapi_tickets = array('jsapi_ticket' => $ticket, 'expire_time' => time() + 7000);
		savecache($cache_jsapi_ticket, $jsapi_tickets);
		return $ticket;
	}
	public static function getAccessToken()
	{
		global $_G;
		include_once libfile('function/cache');
		$config = self::config();
		$appid = $config['wx_appid'];
		$appsecret = $config['wx_appsecret'];
		$cache_access_token = 'fxtokens_' . $appid . $appsecret;
		loadcache($cache_access_token);
		$token = $_G['cache'][$cache_access_token];
		if ($token['access_token'] && $token['expire_time'] > time()) {
			return $token['access_token'];
		}
		$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' . $appid . '&secret=' . $appsecret;
		$res = json_decode(self::get($url), true);
		$access_token = $res['access_token'];
		$access_tokens = array('access_token' => $access_token, 'expire_time' => time() + 7000);
		savecache($cache_access_token, $access_tokens);
		return $access_token;
	}
	public static function verifyKey()
	{
		global $_G;
		$config = self::config();
		if (!function_exists('curl_version')) {
			exit('Please open curl extension');
		}
		$accredit_key = self::getwriteKey();
				self::writeKey($res['data']['key']);
				return true;
	}
	public static function writeKey($key)
	{
		$dirfile = DISCUZ_ROOT . './source/plugin/guiigo_manage/api.inc.php';
		$filetext = file_get_contents($dirfile);
		$targetIndex = strpos($filetext, 'if(!defined(');
		if ($targetIndex !== false) {
			$AfterChLineIndex = strpos(substr($filetext, $targetIndex), "\n") + $targetIndex;
			if ($AfterChLineIndex !== false) {
				$phptext = 'if(!defined(\'IN_DISCUZ\')){';
				$filetext = $phptext . substr($filetext, $AfterChLineIndex);
				$filetext = str_replace('?>', '', $filetext);
			}
		} else {
			$filetext = str_replace(array('<?php', '?>'), array('', ''), $filetext);
		}
		if ($fp = @fopen($dirfile, 'wb')) {
			fwrite($fp, "<?php\n//Copyright www.guiigo.com\n//RandomStr: " . $key . ("\n\n" . $filetext . "?>"));
			fclose($fp);
		} else {
			exit('Can not write to cache files, please check directory ./source/plugin/guiigo_manage/ .');
		}
	}
	public static function getwriteKey()
	{
		$dirfile = DISCUZ_ROOT . './source/plugin/guiigo_manage/api.inc.php';
		$key = '';
		$str = '//RandomStr:';
		$fp = @fopen($dirfile, 'r');
		if ($fp = @fopen($dirfile, 'r')) {
			$i = 1;
			while (!feof($fp)) {
				$isfgets = fgets($fp);
				if ($isfgets && stripos($isfgets, $str) !== false) {
					$key = trim(str_replace($str, '', $isfgets));
					break;
				}
				$i++;
			}
			fclose($fp);
		} else {
			exit('Can not write to cache files, please check directory ./source/plugin/guiigo_manage/ .');
		}
		return $key;
	}
	public static function post($url, $data)
	{
		if (!function_exists('curl_init')) {
			return '';
		}
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$data = curl_exec($ch);
		if (!$data) {
			error_log(curl_error($ch));
		}
		curl_close($ch);
		return $data;
	}
	public static function ksortary($ary, $orderStr = 'order', $type = 1)
	{
		$newary = array();
		if (!$ary) {
			return array();
		}
		foreach ($ary as $key => $val) {
			if ($orderStr != 'order' || $val['type'] != $type) {
				$newary[$val[$orderStr]] = $val;
			}
		}
		ksort($newary);
		return $newary;
	}
	public static function GetTypeArr($str)
	{
		$tclx_type = array();
		if (!$str) {
			return array();
		}
		foreach (explode("\r\n", $str) as $key => $val) {
			$type = explode('|', $val);
			if ($type[0]) {
				$tclx_type[$key]['type1'] = $type[0];
				$tclx_type[$key]['type2'] = $type[1];
				if ($type[2]) {
					$tclx_type[$key]['extend1'] = $type[2];
				}
				if ($type[3]) {
					$tclx_type[$key]['extend2'] = $type[3];
				}
			}
		}
		return $tclx_type;
	}
	public static function RetMsgJson($arr, $isecho = true)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$arr = self::iconvArrayA($arr);
		}
		if ($isecho) {
			echo json_encode($arr);
			exit(0);
		} else {
			return json_encode($arr);
		}
	}
	public static function iconvArrayA($data, $in_charset = 'gbk', $out_charset = 'utf-8')
	{
		if (is_array($data)) {
			foreach ($data as $key => $val) {
				$dataA[$key] = self::iconvArrayA($val, $in_charset, $out_charset);
			}
			return $dataA;
		}
		return iconv($in_charset, $out_charset, $data);
	}
	public static function diconv_out_nowiconv($arr)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$arr = self::iconvArrayA($arr, 'utf-8', 'gbk');
			return $arr;
		}
		return $arr;
	}
	public static function diconvarr_out_utf8($arr)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$arr = self::iconvArrayA($arr, 'gbk', 'utf-8');
			return $arr;
		}
		return $arr;
	}
	public static function get_select($name, $data, $selected, $initial, $multiplesize = false)
	{
		$multiple = $multiplesize ? 'multiple="multiple" size="' . $multiplesize . '"' : '';
		$select = '<select name="' . $name . '" id="' . $name . '" ' . $multiple . '>';
		if ($initial) {
			$select .= '<option value="' . $initial[0] . '">' . $initial[1] . '</option>';
		}
		foreach ($data as $v) {
			$sed = '';
			if (is_array($selected) && $multiplesize) {
				foreach ($selected as $val) {
					$sed = $val == $v[0] ? 'selected' : '';
					if ($val == $v[0]) {
						$sed = 'selected';
						break;
					}
				}
			} else {
				$sed = $selected == $v[0] && !$multiplesize ? 'selected' : '';
			}
			$select .= '<option value="' . $v[0] . '" ' . $sed . '>' . $v[1] . '</option>';
		}
		$select .= '</select>';
		return $select;
	}
	public static function getForumStyleByfid($fid)
	{
		global $setting;
		if (!$setting) {
			$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
			$setting = (array) unserialize($setting['guiigo_manage']);
		}
		$forumlist = array();
		foreach ($setting['forumstyle'] as $forum) {
			if ($forum['forum_id'] == $fid) {
				$forumlist = $forum;
				break;
			}
		}
		return $forumlist;
	}
	public static function isGroup($fid)
	{
		$info = C::t('forum_forum')->fetch_info_by_fid($fid);
		return $info['status'] == 3 ? true : false;
	}
	public static function getUserGroupByUid($uid)
	{
		global $_G;
		if (!$uid) {
			return NULL;
		}
		$res = DB::fetch_all('SELECT g.fid,f.fid,f.name,fd.fid,fd.icon FROM %t g
				 LEFT JOIN %t f ON  f.fid=g.fid 
				 LEFT JOIN %t fd ON fd.fid=g.fid 
				 WHERE g.uid=%d', array('forum_groupuser', 'forum_forum', 'forum_forumfield', $uid));
		$forum = array();
		foreach ($res as $k => $val) {
			$forum[$k] = $val;
			$forum[$k]['url'] = 'forum.php?mod=group&fid=' . $val['fid'];
			$forum[$k]['icon'] = $val['icon'] ? $_G['setting']['attachurl'] . 'group/' . $val['icon'] : '';
		}
		return $forum;
	}
	public static function getForumIconByFid($fid, $type = 1)
	{
		global $_G;
		if (!$fid) {
			return NULL;
		}
		$icon = DB::result_first('SELECT icon FROM %t WHERE fid=%d', array('forum_forumfield', $fid));
		$dir = 'common/';
		if ($type == 2) {
			$dir = 'forum/';
		} elseif ($type == 3) {
			$dir = 'group/';
		}
		return $icon ? $_G['setting']['attachurl'] . $dir . $icon : '';
	}
	public static function GetVisitorByUid($uid, $start, $perpage)
	{
		$count = C::t('home_visitor')->count_by_uid($uid);
		$list = array();
		if ($count) {
			$visitors = C::t('home_visitor')->fetch_all_by_uid($uid, $start, $perpage);
			foreach ($visitors as $value) {
				$value['uid'] = $value['vuid'];
				$value['username'] = $value['vusername'];
				$list[$value['uid']] = $value;
			}
		}
		return $list;
	}
	public static function getStickBlogs($uid, $blogid)
	{
		$res = false;
		$space = array();
		$space['uid'] = $uid;
		space_merge($space, 'field_home');
		$stickblogs = explode(',', $space['stickblogs']);
		$stickblogs = array_filter($stickblogs);
		if (!empty($stickblogs) && in_array($blogid, $stickblogs)) {
			$res = true;
		}
		return $res;
	}
	public static function fetch_all_get_post($where, $start, $perpage, $roder = false)
	{
		if (!$roder) {
			$roder = ' BY p.dateline DESC,t.views DESC,t.favtimes DESC,t.comments DESC ';
		}
		if ($where['orderby']) {
			$roder = ' BY t.' . $where['orderby'] . ' DESC ';
		}
		$wheresql = array();
		if ($where['fid']) {
			if (!is_array($where['fid'])) {
				$where['fid'] = explode(',', $where['fid']);
			}
			$wheresql[] = 'p.' . DB::field('fid', $where['fid']);
		}
		if ($where['noauthorid']) {
			$wheresql[] = 't.' . DB::field('authorid', $where['noauthorid'], '<>');
		}
		if ($where['authorid']) {
			if (!is_array($where['authorid'])) {
				$where['authorid'] = explode(',', $where['authorid']);
			}
			$wheresql[] = 'p.' . DB::field('authorid', $where['authorid']);
		}
		$wheresql[] = 'p.' . DB::field('first', 1);
		$wheresql[] = 'p.' . DB::field('invisible', 0);
		$wheresql[] = 'p.' . DB::field('anonymous', 0);
		$wheresql[] = 'p.' . DB::field('status', 1, '<>');
		if ($where['digest']) {
			$wheresql[] = 't.' . DB::field('digest', $where['digest'], '>=');
		}
		if (is_array($where['special'])) {
			$specialsql = array();
			foreach ($where['special'] as $spv) {
				$specialsql[] = 't.' . DB::field('special', $spv, '<>');
			}
			$wheresql[] = '(' . implode(' OR ', $specialsql) . ')';
		}
		if (!$where['stick']) {
			$specialsql[] = 't.' . DB::field('displayorder', 0, '<=');
		}
		if ($where['tagkeyword'] || $where['keyword']) {
			$tagkeyword = $keyword = array();
			foreach (explode(',', $where['tagkeyword']) as $v1) {
				if ($v1) {
					$tagkeyword[] = 'p.' . DB::field('tags', '%' . $v1 . '%', 'like');
				}
			}
			foreach (explode(',', $where['keyword']) as $v2) {
				if ($v2) {
					$keyword[] = 'p.' . DB::field('subject', '%' . $v2 . '%', 'like');
				}
			}
			$newsql = array_merge($tagkeyword, $keyword);
			if ($newsql) {
				$wheresql[] = '(' . implode(' OR ', $newsql) . ')';
			}
		}
		if ($where['postdateline']) {
			$wheresql[] = 't.' . DB::field('dateline', TIMESTAMP - $where['postdateline'], '>=');
		}
		if ($where['lastpost']) {
			$wheresql[] = 't.' . DB::field('lastpost', TIMESTAMP - $where['attachment'], '>=');
		}
		if ($where['attachment']) {
			$wheresql[] = 't.' . DB::field('attachment', $where['attachment']);
		}
		$wheresql[] = 't.' . DB::field('closed', 0);
		if (!empty($where['isgroup'])) {
			$wheresql[] = 't.' . DB::field('isgroup', $where['isgroup']);
		}
		if (!$wheresql) {
			$wheresql[] = '0';
		}
		return DB::fetch_all('SELECT p.*,t.*
			FROM %t p
			LEFT JOIN %t t on t.tid=p.tid
			WHERE %i
			ORDER ' . $roder . ' ' . DB::limit($start, $perpage), array('forum_post', 'forum_thread', implode(' AND ', $wheresql)), 'pid');
	}
	public static function fetch_all_get_Portal_post($where, $start, $perpage, $roder = false)
	{
		if (!$roder) {
			$roder = ' BY a.dateline DESC ';
		}
		if ($where['orderby']) {
			if ($where['orderby'] == 'dateline') {
				$roder = ' BY a.' . $where['orderby'] . ' DESC ';
			} else {
				$roder = ' BY b.' . $where['orderby'] . ' DESC ';
			}
		}
		$wheresql = array();
		if ($where['catid']) {
			if (!is_array($where['catid'])) {
				$where['catid'] = explode(',', $where['catid']);
			}
			$wheresql[] = 'a.' . DB::field('catid', $where['catid']);
		}
		if ($where['pic']) {
			$wheresql[] = 'a.' . DB::field('pic', '', '<>');
		}
		if ($where['uid']) {
			if (!is_array($where['uid'])) {
				$where['uid'] = explode(',', $where['uid']);
			}
			$wheresql[] = 'a.' . DB::field('uid', $where['uid']);
		}
		if ($where['keyword']) {
			$keyword = array();
			foreach (explode(',', $where['keyword']) as $v2) {
				if ($v2) {
					$keyword[] = 'a.' . DB::field('title', '%' . $v2 . '%', 'like');
				}
			}
			if ($keyword) {
				$wheresql[] = '(' . implode(' OR ', $keyword) . ')';
			}
		}
		if ($where['postdateline']) {
			$wheresql[] = 'a.' . DB::field('dateline', TIMESTAMP - $where['postdateline'], '>=');
		}
		$wheresql[] = 'a.' . DB::field('status', 0);
		$wheresql[] = 'c.' . DB::field('pageorder', 1);
		if (!$wheresql) {
			$wheresql[] = '0';
		}
		$data = DB::fetch_all('SELECT a.*,b.*,c.cid,c.aid,c.id,c.idtype,c.content 
			FROM %t a
			LEFT JOIN %t b on b.aid=a.aid 
			LEFT JOIN %t c on c.aid=a.aid
			WHERE %i
			ORDER ' . $roder . ' ' . DB::limit($start, $perpage), array('portal_article_title', 'portal_article_count', 'portal_article_content', implode(' AND ', $wheresql)));
		$resdata = array();
		foreach ($data as $k => $val) {
			$resdata[$k] = $val;
			$resdata[$k]['attachment'] = self::get_Portal_pic($val['aid'], false);
		}
		return $resdata;
	}
	public static function article_title_style($value = array())
	{
		$style = array();
		$highlight = '';
		if ($value['highlight']) {
			$style = explode('|', $value['highlight']);
			$highlight = ' style="';
			$highlight .= $style[0] ? 'color: ' . $style[0] . ';' : '';
			$highlight .= $style[1] ? 'font-weight: bold;' : '';
			$highlight .= $style[2] ? 'font-style: italic;' : '';
			$highlight .= $style[3] ? 'text-decoration: underline;' : '';
			$highlight .= '"';
		}
		return $highlight;
	}
	public static function fetch_article_url($article)
	{
		global $_G;
		if (!empty($_G['setting']['makehtml']['flag']) && $article && $article['htmlmade']) {
			if (empty($_G['cache']['portalcategory'])) {
				loadcache('portalcategory');
			}
			$caturl = '';
			if (!empty($_G['cache']['portalcategory'][$article['catid']])) {
				$topid = $_G['cache']['portalcategory'][$article['catid']]['topid'];
				$caturl = $_G['cache']['portalcategory'][$topid]['domain'] ? $_G['cache']['portalcategory'][$topid]['caturl'] : '';
			}
			return $caturl . $article['htmldir'] . $article['htmlname'] . '.' . $_G['setting']['makehtml']['extendname'];
		}
		return 'portal.php?mod=view&aid=' . $article['aid'];
	}
	public static function get_Portal_pic($aid, $isthumb = true)
	{
		$attachs = array();
		if (!$aid) {
			return $attachs;
		}
		$config = self::config();
		$cacheconfig = array('optype' => 'get_cache', 'filedir' => 'cache_portal_attach');
		$arg = array('key' => 'cache_portal_attach_' . $aid);
		$cachedata = self::CacheData($cacheconfig, $arg);
		if ($cachedata) {
			return $cachedata;
		}
		$countImg = DB::result_first('SELECT COUNT(*) FROM %t WHERE aid=%d AND isimage=1', array('portal_attachment', $aid));
		if (!$countImg) {
			return $attachs;
		}
		$attachlist = DB::fetch_all('SELECT * FROM %t WHERE aid=%d AND isimage=1' . DB::limit(0, 6), array('portal_attachment', $aid));
		if (!$attachlist) {
			return $attachs;
		}
		foreach ($attachlist as $k => $value) {
			$attachs[$k] = $value;
			$attachs[$k]['attachment'] = self::pic_get($value['attachment'], 'portal', $isthumb, $value['remote'], 1);
		}
		if ($config['attach_cache_time']) {
			$cacheconfig = array('optype' => 'set_cache', 'filedir' => 'cache_portal_attach');
			$arg = array('key' => 'cache_portal_attach_' . $aid, 'value' => $attachs, 'life' => 60 * $config['attach_cache_time']);
			self::CacheData($cacheconfig, $arg);
		}
		return $attachs;
	}
	public static function pic_get($filepath, $type, $thumb, $remote, $return_thumb = 1, $hastype = '')
	{
		global $_G;
		$url = $filepath;
		if ($return_thumb && $thumb) {
			$url = getimgthumbname($url);
		}
		if ($remote > 1 && $type == 'album') {
			$remote -= 2;
			$type = 'forum';
		}
		$type = $hastype ? '' : $type . '/';
		return ($remote ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . $type . $url;
	}
	public static function get_pid($tid)
	{
		return DB::fetch_all('SELECT pid,first FROM %t WHERE tid=%d', array('forum_post', $tid));
	}
	public static function getpostfirstbypid($tid)
	{
		return DB::fetch_first('SELECT pid,authorid FROM %t WHERE tid=%d AND first=1', array('forum_post', $tid));
	}
	public static function GetGoruplist($goruplist, $cutimg = array())
	{
		$tids = array();
		foreach ($goruplist as $k => $v) {
			$tids[] = $k;
		}
		unset($k);
		unset($v);
		$result = DB::fetch_all('SELECT p.*,t.* FROM %t p LEFT JOIN %t t on t.tid=p.tid WHERE p.tid in(' . dimplode($tids) . ') AND first=1', array('forum_post', 'forum_thread'), 'tid');
		$postusers = $uids = $newpostlist = array();
		foreach ($goruplist as $tid => $post) {
			$uids[$result[$tid]['authorid']] = array();
			$message = $result[$tid]['message'];
			$result[$tid]['message'] = self::_messageAnalysis($message);
			$result[$tid]['attapic'] = self::AttachImg($tid, $result[$tid]['pid'], $cutimg);
			$newpostlist[$tid] = array_merge($post, (array) $result[$tid]);
		}
		$uids = array_keys($uids);
		unset($tid);
		unset($post);
		$postusers = self::getPostUserListByids($uids);
		foreach ($newpostlist as $tid => $post) {
			$newpostlist[$tid] = array_merge($post, (array) $postusers[$post['authorid']]);
		}
		unset($tid);
		unset($post);
		return $newpostlist;
	}
	public static function getviewthreadList($postlist)
	{
		global $_G;
		$member_follow = $pids = $recommenuspid = array();
		$pids = array_keys($postlist);
		if ($_G['setting']['recommendthread']['status'] && $_G['uid'] && $pids) {
			$recommenuspid = DB::fetch_all('SELECT * FROM %t WHERE pid IN (%n) AND uid=%d', array('forum_hotreply_member', $pids, $_G['uid']), 'pid');
		}
		$uids = array();
		foreach ($postlist as $k => $v) {
			$uids[$v['authorid']] = array();
		}
		$uids = array_keys($uids);
		$member_field_forum = C::t('common_member_field_forum')->fetch_all($uids);
		$recommenus = false;
		if ($_G['uid']) {
			$recommenus = self::getrecommendbyid($_G['tid'], $_G['uid']);
			$member_follow = self::getUserList($_G['uid'], 'follow');
		}
		foreach ($postlist as $pid => $post) {
			$post['isrecommenus'] = 0;
			if ($post['first'] == 1 && $recommenus) {
				$post['isrecommenus'] = 1;
			} else {
				if (!empty($recommenuspid) && $recommenuspid[$pid]['pid'] > 0) {
					$post['isrecommenus'] = 1;
				}
			}
			$post['isfollow'] = 0;
			if ($_G['uid'] != $post['authorid'] && !empty($member_follow) && in_array($post['authorid'], $member_follow)) {
				$post['isfollow'] = 1;
			}
			$post['grouptitle'] = strip_tags($_G['cache']['usergroups'][$post['groupid']]['grouptitle']);
			$post['groupstars'] = 'Lv.' . $_G['cache']['usergroups'][$post['groupid']]['stars'];
			$post['signature'] = $member_field_forum[$post['authorid']]['sightml'];
			$postlist[$pid] = $post;
		}
		unset($pid);
		unset($post);
		return $postlist;
	}
	public static function GetPostlistFloor($tid)
	{
		$ret = DB::fetch_all('SELECT pid,tid,message,first,authorid,author,dateline,anonymous,invisible,status,comment,subject FROM %t WHERE invisible>=0 AND first=0 AND tid=%d ORDER BY dateline DESC ' . DB::limit(0, 6), array('forum_post', $tid));
		foreach ($ret as $k => $p) {
			$p['message'] = self::FloorMessageAnalysis($p['message']);
			$p['dateline'] = dgmdate($p['dateline'], 'u');
			$p['avatarurl'] = avatar($p['authorid'], 'small', true);
			$ret[$k] = $p;
		}
		return $ret;
	}
	public static function FloorMessageAnalysis($message, $length = 350, $str = '...')
	{
		if (!$message) {
			return '';
		}
		if (!function_exists('GtplQuote')) {
			include_once libfile('function/code', 'plugin/guiigo_manage');
		}
		$message2 = $message;
		if (strpos($message2, '[/quote]') !== false) {
			$message = preg_replace_callback("/\\s?\\[quote\\][\n\r]*(.+?)[\n\r]*\\[\\/quote\\]\\s?/is", 'GtplQuote', $message2);
		}
		$message = preg_replace('/\\[(.*?)\\]\\s*(.*?)\\s*((\\[\\/(.*?)\\])|\\.\\.\\.)/is', '', $message);
		$message = self::_DeleteHtml($message);
		$message = self::_parsesmiles($message);
		$message = cutstr($message, $length, $str);
		$message = preg_replace('/\\s*\\<s*img\\s*(.*?)\\s*\\.\\.\\./is', '', $message);
		return $message;
	}
	public static function GetPostlist($postlist, $cutimg = array())
	{
		global $_G;
		$tids = $postusers = $uids = $locationpids = $recommenustid = array();
		foreach ($postlist as $k => $v) {
			$tids[] = $v['tid'];
			$uids[$v['authorid']] = array();
		}
		$uids = array_keys($uids);
		$postusers = self::getPostUserListByids($uids);
		if ($_G['setting']['recommendthread']['status'] && $_G['uid']) {
			$recommenustid = DB::fetch_all('SELECT * FROM %t WHERE tid IN (%n) AND recommenduid=%d', array('forum_memberrecommend', $tids, $_G['uid']), 'tid');
		}
		$result = DB::fetch_all('SELECT pid,tid,message,first,authorid,dateline,anonymous,invisible,status,comment,subject FROM %t WHERE tid IN (%n) AND first=%d', array('forum_post', $tids, 1), 'tid');
		$newpostlist = array();
		foreach ($postlist as $k2 => $post) {
			$message = $result[$post['tid']]['message'];
			$message = self::_messageAnalysis($message);
			$message2 = self::FloorMessageAnalysis($result[$post['tid']]['message']);
			$result[$post['tid']]['message2'] = $message2;
			$result[$post['tid']]['message'] = substr($message, 0, strlen($post['subject'])) == $post['subject'] ? '' : $message;
			$result[$post['tid']]['attapic'] = self::AttachImg($post['tid'], $result[$post['tid']]['pid'], $cutimg);
			$result[$post['tid']]['isrecommenus'] = 0;
			if (!empty($recommenustid) && $recommenustid[$post['tid']]['recommenduid'] > 0) {
				$result[$post['tid']]['isrecommenus'] = 1;
			}
			$post['floor'] = self::GetPostlistFloor($post['tid']);
			if (CURSCRIPT == 'search') {
				$result[$post['tid']]['subject'] = $post['subject'];
			}
			$newpostlist[$k2] = array_merge($post, (array) $result[$post['tid']], (array) $postusers[$post['authorid']]);
		}
		return $newpostlist;
	}
	public static function getPostUserListByids($uids)
	{
		global $_G;
		$member_follow = $postusers = $member_verify = $member_field_forum = $member_status = $member_profile = $member_field_home = array();
		if (!$_G['setting']['threadguestlite'] || $_G['uid']) {
			if ($_G['setting']['verify']['enabled']) {
				$member_verify = C::t('common_member_verify')->fetch_all($uids);
				foreach ($member_verify as $uid => $data) {
					foreach ($_G['setting']['verify'] as $vid => $verify) {
						if ($verify['available'] && $verify['showicon']) {
							if ($data['verify' . $vid] == 1) {
								$member_verify[$uid]['verifyicon'][] = array('verifurl' => $_G['siteurl'] . 'home.php?mod=spacecp&ac=profile&op=verify&vid=' . $vid, 'verificon' => $_G['siteurl'] . $verify['icon']);
							} else {
								if (!empty($verify['unverifyicon'])) {
									$member_verify[$uid]['unverifyicon'][] = array('verifurl' => $_G['siteurl'] . 'home.php?mod=spacecp&ac=profile&op=verify&vid=' . $vid, 'verificon' => $_G['siteurl'] . $verify['icon']);
								}
							}
						}
					}
				}
			}
			$member_status = C::t('common_member_status')->fetch_all($uids);
			$member_field_forum = C::t('common_member_field_forum')->fetch_all($uids);
			$member_profile = C::t('common_member_profile')->fetch_all($uids);
			$member_profile = C::t('common_member_profile')->fetch_all($uids);
			if ($_G['uid']) {
				$member_follow = $follow = self::getUserList($_G['uid'], 'follow');
			}
		}
		foreach (C::t('common_member')->fetch_all($uids) as $uid => $postuser) {
			$postuser['memberstatus'] = $postuser['status'];
			$postuser['authorinvisible'] = $member_status[$uid]['invisible'];
			$postuser['signature'] = $member_field_forum[$uid]['sightml'];
			unset($postuser['status']);
			unset($member_status[$uid]['invisible']);
			unset($member_field_forum[$uid]['sightml']);
			$postusers[$uid] = array_merge((array) $member_verify[$uid], (array) $member_profile[$uid], (array) $member_status[$uid], (array) $member_field_forum[$uid], $postuser);
			if ($postusers[$uid]['regdate'] + $postusers[$uid]['oltime'] * 3600 > TIMESTAMP) {
				$postusers[$uid]['oltime'] = 0;
			}
			$postusers[$uid]['isfollow'] = 0;
			if ($_G['uid'] && $_G['uid'] != $uid && !empty($member_follow) && in_array($uid, $member_follow)) {
				$postusers[$uid]['isfollow'] = 1;
			}
			$postusers[$uid]['groupstars'] = 'Lv.' . $_G['cache']['usergroups'][$postuser['groupid']]['stars'];
			$postusers[$uid]['grouptitle'] = strip_tags($_G['cache']['usergroups'][$postuser['groupid']]['grouptitle']);
			$postusers[$uid]['office'] = $postusers[$uid]['position'];
			$postusers[$uid]['groupcolor'] = $_G['cache']['usergroups'][$postuser['groupid']]['color'];
			unset($postusers[$uid]['position']);
		}
		unset($member_field_forum);
		unset($member_status);
		unset($member_profile);
		return $postusers;
	}
	public static function AttachImg($tid, $pid, $cutimg = array())
	{
		global $_G;
		$thumbnail = array('one' => array('nocache' => 0, 'width' => 400, 'height' => 9999), 'two' => array('nocache' => 0, 'width' => 400, 'height' => 400), 'three' => array('nocache' => 0, 'width' => 300, 'height' => 300));
		$config = self::config();
		$attachs = array();
		$cacheconfig = array('optype' => 'get_cache', 'filedir' => 'cache_forum_attach');
		$arg = array('key' => 'cache_forum_attach_' . $tid . '_' . $pid);
		$cachedata = self::CacheData($cacheconfig, $arg);
		if ($cachedata) {
			return $cachedata;
		}
		$aidtb = getattachtablebytid($tid);
		if ($aidtb == 'forum_attachment_unused') {
			return $attachs;
		}
		$countImg = DB::result_first('SELECT COUNT(*) FROM %t WHERE tid=%d and pid=%d and isimage=1', array($aidtb, $tid, $pid));
		if (!$countImg) {
			return $attachs;
		}
		$attachlist = DB::fetch_all('SELECT aid,pid,readperm,price,attachment,remote,filesize,description FROM %t WHERE tid=%d and pid=%d and isimage=1 ' . DB::limit(0, 6), array($aidtb, $tid, $pid));
		if (!$attachlist) {
			return $attachs;
		}
		foreach ($attachlist as $attach) {
			$attachurl = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . 'forum/';
			if (empty($attach['readperm']) && empty($attach['price'])) {
				$_attach = $attachurl . $attach['attachment'];
				if ($cutimg && $cutimg['width']) {
					$_attach = getforumimg($attach['aid'], $cutimg['nocache'], $cutimg['width'], $cutimg['height']);
				} elseif ($countImg == 1) {
					$_attach = getforumimg($attach['aid'], $thumbnail['one']['nocache'], $thumbnail['one']['width'], $thumbnail['one']['height']);
				} elseif ($countImg == 2 || $countImg == 3) {
					$_attach = getforumimg($attach['aid'], $thumbnail['two']['nocache'], $thumbnail['two']['width'], $thumbnail['two']['height']);
				} elseif ($countImg >= 4) {
					$_attach = getforumimg($attach['aid'], $thumbnail['three']['nocache'], $thumbnail['three']['width'], $thumbnail['three']['height']);
				}
				$attachs[] = array('attach' => $_attach, 'description' => $attach['description'], 'aid' => $attach['aid'], 'countImg' => $countImg);
			}
		}
		if ($config['attach_cache_time']) {
			$cacheconfig = array('optype' => 'set_cache', 'filedir' => 'cache_forum_attach');
			$arg = array('key' => 'cache_forum_attach_' . $tid . '_' . $pid, 'value' => $attachs, 'life' => 60 * $config['attach_cache_time']);
			self::CacheData($cacheconfig, $arg);
		}
		return $attachs;
	}
	public static function style()
	{
		$sty = self::getwriteKey();
		$style = DISCUZ_ROOT . './template/guiigo_app/static/font/iconfont.css';
		if (function_exists('file_get_contents') && function_exists('file_put_contents') && $sty) {
			$h = file_get_contents($style);
			if (stripos($h, $sty) == false) {
				$str = '.guiigoapp-clshequtt:before {content: "' . $sty . '";}';
				file_put_contents($style, $str, FILE_APPEND);
			}
		}
	}
	public static function _messageAnalysis($message, $length = 100, $str = '')
	{
		if (!$message) {
			return '';
		}
		$message = preg_replace('/\\[(.*?)\\]\\s*(.*?)\\s*((\\[\\/(.*?)\\])|\\.\\.\\.)/is', '', $message);
		$message = self::_DeleteHtml($message);
		$message = preg_replace('/\\{:(.*?)\\:}/is', '', $message);
		return cutstr($message, $length, $str);
	}
	public static function _DeleteHtml($str)
	{
		$str = trim($str);
		$str = strip_tags($str, '');
		$str = preg_replace('/	/', '', $str);
		$str = preg_replace("/\r\n/", '', $str);
		$str = preg_replace("/\r/", '', $str);
		$str = preg_replace("/\n/", '', $str);
		$str = preg_replace('/ /', '', $str);
		$str = preg_replace('/  /', '', $str);
		return trim($str);
	}
	public static function _parsesmiles($message)
	{
		global $_G;
		if (!is_array($_G['cache']['smilies']) || !is_array($_G['cache']['smileytypes'])) {
			loadcache(array('smilies', 'smileytypes'));
		}
		if (strexists($message, '{:') === false) {
			return $message;
		}
		$replacearray = array();
		$enablesmiles = NULL;
		if ($enablesmiles === NULL) {
			$enablesmiles = false;
			if (!empty($_G['cache']['smilies']) && is_array($_G['cache']['smilies'])) {
				foreach ($_G['cache']['smilies']['replacearray'] as $key => $smiley) {
					$label = '<img src="' . $_G['siteurl'] . STATICURL . 'image/smiley/' . $_G['cache']['smileytypes'][$_G['cache']['smilies']['typearray'][$key]]['directory'] . '/' . $smiley . '" smilieid="' . $key . '" border="0" alt="" />';
					$replacearray[$key] = $label;
				}
				$enablesmiles = true;
			}
		}
		$enablesmiles && ($message = preg_replace($_G['cache']['smilies']['searcharray'], $replacearray, $message, $_G['setting']['maxsmilies']));
		return $message;
	}
	public static function feedFace($val)
	{
		global $_G;
		preg_match_all('/\\:(.*?)\\:/is', $val, $matches);
		if ($matches[1]) {
			foreach ($matches[1] as $v) {
				$img = '<img src="' . STATICURL . 'image/smiley/comcom/' . $v . '.gif" class="fimg"/>';
				$val = preg_replace('/\\[(.*?)\\]/is', $img, $val);
			}
		} else {
			if (strexists($val, '{:') !== false) {
				$val = self::_parsesmiles($val);
			}
		}
		return $val;
	}
	public static function getUserList($uid, $table, $type = null)
	{
		if (!$uid) {
			return '';
		}
		if (in_array($table, array('status', 'verify', 'count', 'field_forum'))) {
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('common_member_' . $table, $uid));
		}
		if ($table == 'favorite' && $type) {
			$favorite = array();
			$result = DB::fetch_all('SELECT * FROM %t WHERE uid=%d and idtype=\'' . $type . '\'', array('home_' . $table, $uid));
			foreach ($result as $v) {
				$favorite[$v['id']]['id'] = $v['id'];
				$favorite[$v['id']]['favid'] = $v['favid'];
			}
			return $favorite;
		}
		if ($table == 'follow') {
			$follow = array();
			$result = DB::fetch_all('SELECT * FROM %t WHERE uid=%d', array('home_' . $table, $uid));
			foreach ($result as $v) {
				$follow[] = $v['followuid'];
			}
			return $follow;
		}
		if ($table == 'count') {
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('common_member_' . $table, $uid));
		}
		if ($table == 'profile') {
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('common_member_' . $table, $uid));
		}
	}
	public static function getUserStars($uid)
	{
		if (!$uid) {
			return NULL;
		}
		$user = getuserbyuid($uid);
		return DB::result_first('select stars from %t where groupid=%d', array('common_usergroup', $user['groupid']));
	}
	public static function getrecommendbyid($tid, $uid = '', $page = 1, $perpage = 10)
	{
		if ($uid === 0) {
			return '';
		}
		if ($uid && $tid) {
			return DB::result_first('SELECT recommenduid FROM %t WHERE recommenduid=%d AND tid=%d', array('forum_memberrecommend', $uid, $tid));
		}
		if ($tid) {
			$start = ($page - 1) * $perpage;
			return DB::fetch_all('SELECT a.recommenduid,a.dateline,b.username,b.uid FROM %t a LEFT JOIN %t b on b.uid=a.recommenduid WHERE a.tid=' . $tid . ' AND b.status=0 ORDER BY a.dateline DESC ' . DB::limit($start, $perpage), array('forum_memberrecommend', 'common_member', $tid));
		}
	}
	public static function geforumbyuid($fid, $page = 1, $perpage = 5)
	{
		global $_G;
		$start = ($page - 1) * $perpage;
		$limit = $perpage;
		return DB::fetch_all('SELECT * FROM ' . DB::table('home_favorite') . ' WHERE id=' . $fid . ' ORDER BY ' . DB::order('favid') . DB::limit($start, $limit), NULL, 'favid');
	}
	public static function DateFormatting($arr)
	{
		if (is_array($arr)) {
			return dgmdate(TIMESTAMP + $arr[0] * 86400 + $arr[1] * 3600 + $arr[2] * 60, 'Y-m-d h:i:s');
		}
		if (is_int($arr) && substr($arr) < 10) {
			$arr = $arr + TIMESTAMP;
		} else {
			$arr = dmktime($arr);
		}
		return dgmdate($arr, 'Y-m-d h:i:s');
	}
	public function gethotreplybyid($pid, $uid)
	{
		if (!$uid) {
			return '';
		}
		return DB::result_first('SELECT pid FROM %t WHERE pid=%d AND uid=%d', array('forum_hotreply_member', $pid, $uid));
	}
	public static function get_block_htnl($bids)
	{
		include_once libfile('function/block');
		block_get_batch($bids);
		$bidsary = is_array($bids) ? $bids : ($bids ? explode(',', $bids) : array());
		$datahtml = '';
		foreach ($bidsary as $bid) {
			$datahtml .= block_fetch_content($bid);
		}
		return $datahtml;
	}
	public static function getgrouplist($fid)
	{
		global $_G;
		$groupcache = getgroupcache($fid, array('replies', 'views', 'digest', 'lastpost', 'ranking', 'activityuser', 'newuserlist'), 604800);
		$activityuserlist = array();
		$activityuserlist = array_slice($groupcache['activityuser']['data'], 0, 8);
		return $activityuserlist;
	}
	public static function addHomeVisitor($space)
	{
		global $_G;
		if (!$_G['setting']['preventrefresh'] || $_G['uid'] && !$space['self'] && $_G['cookie']['viewid'] != 'uid_' . $space['uid']) {
			member_count_update($space['uid'], array('views' => 1));
			dsetcookie('viewid', 'uid_' . $space['uid']);
		}
		if (!$space['self'] && $_G['uid'] && $_GET['additional'] != 'removevlog') {
			$visitor = C::t('home_visitor')->fetch_by_uid_vuid($space['uid'], $_G['uid']);
			$is_anonymous = empty($_G['cookie']['anonymous_visit_' . $_G['uid'] . '_' . $space['uid']]) ? 0 : 1;
			if (empty($visitor['dateline'])) {
				$setarr = array('uid' => $space['uid'], 'vuid' => $_G['uid'], 'vusername' => $is_anonymous ? '' : $_G['username'], 'dateline' => $_G['timestamp']);
				C::t('home_visitor')->insert($setarr, false, true);
				self::show_credit($space);
			} else {
				if ($_G['timestamp'] - $visitor['dateline'] >= 300) {
					C::t('home_visitor')->update_by_uid_vuid($space['uid'], $_G['uid'], array('dateline' => $_G['timestamp'], 'vusername' => $is_anonymous ? '' : $_G['username']));
				}
				if ($_G['timestamp'] - $visitor['dateline'] >= 3600) {
					self::show_credit($space);
				}
			}
			updatecreditbyaction('visit', 0, array(), $space['uid']);
		}
	}
	public static function show_credit($space)
	{
		global $_G;
		$showinfo = C::t('home_show')->fetch($space['uid']);
		if ($showinfo['credit'] > 0) {
			$showinfo['unitprice'] = intval($showinfo['unitprice']);
			if ($showinfo['credit'] <= $showinfo['unitprice']) {
				notification_add($space['uid'], 'show', 'show_out');
				C::t('home_show')->delete($space['uid']);
			} else {
				C::t('home_show')->update_credit_by_uid($space['uid'], 0 - $showinfo['unitprice']);
			}
		}
	}
	public static function getAttachByTid($tid, $pid)
	{
		global $_G;
		$attachs = array();
		$aidtb = getattachtablebytid($tid);
		if ($aidtb == 'forum_attachment_unused') {
			return $attachs;
		}
		$attachlist = DB::fetch_all('SELECT * FROM %t WHERE tid=%d AND pid=%d', array($aidtb, $tid, $pid));
		if (!$attachlist) {
			return $attachs;
		}
		foreach ($attachlist as $ak => $attach) {
			$attachurl = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . 'forum/';
			$attachs[$ak] = $attach;
			$attachs[$ak]['attachment'] = $attachurl . $attach['attachment'];
			if ($attach['isimage'] == 0 - 1) {
				$attachs[$ak]['isimage'] = self::_is_image_ext($attach['filename']);
			}
		}
		return $attachs;
	}
	public static function _is_image_ext($filename)
	{
		$ext = addslashes(strtolower(substr(strrchr($filename, '.'), 1, 10)));
		$imgext = array('jpg', 'jpeg', 'gif', 'png', 'bmp');
		return in_array($ext, $imgext) ? 1 : 0;
	}
	public static function getForumByFid($fid)
	{
		global $_G;
		if (!isset($_G['cache']['forums']) || !isset($_G['cache']['Ggroups'])) {
			loadcache(array('forums', 'Ggroups'));
		}
		$Ggroups = $_G['cache']['Ggroups']['groups'];
		$newData = $_G['cache']['forums'] + $Ggroups;
		return $newData[$fid];
	}
}