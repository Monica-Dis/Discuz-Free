<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
$config = GuiigoApp::config();
GuiigoApp::verifyKey();/*From: DisM - Taobao - Com*/
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
if (!submitcheck('settingsubmit')) {
	$select = array();
	$select[] = array(1, lang('plugin/guiigo_manage', 'slang0084'));
	$select[] = array(2, lang('plugin/guiigo_manage', 'slang0085'));
	$select[] = array(3, lang('plugin/guiigo_manage', 'slang0086'));
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0087'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0088'), 'settingnew[show_buygroup]', $setting['userconfig']['show_buygroup'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0089'));
	showsetting(lang('plugin/guiigo_manage', 'slang0221'), 'settingnew[show_buygroupl]', $setting['userconfig']['show_buygroupl'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0222'));
	showsetting(lang('plugin/guiigo_manage', 'slang0223'), 'settingnew[show_buygroupz]', $setting['userconfig']['show_buygroupz'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0224'));
	showsetting(lang('plugin/guiigo_manage', 'slang0090'), 'settingnew[show_ad_slide]', $setting['userconfig']['show_ad_slide'], 'textarea', '', '', lang('plugin/guiigo_manage', 'slang0091'));
	showsetting(lang('plugin/guiigo_manage', 'slang0092'), 'settingnew[show_photo_tip]', $setting['userconfig']['show_photo_tip'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0093'));
	showsetting(lang('plugin/guiigo_manage', 'slang0094'), 'settingnew[show_sign_url]', $setting['userconfig']['show_sign_url'], 'text');
	showsetting(lang('plugin/guiigo_manage', 'slang0095'), 'settingnew[show_certification]', $setting['userconfig']['show_certification'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0096'), 'settingnew[show_colourmatching]', $setting['userconfig']['show_colourmatching'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0097'), 'settingnew[show_colourmatchingpg]', $setting['userconfig']['show_colourmatchingpg'], 'text');
	showsetting(lang('plugin/guiigo_manage', 'slang0098'), 'settingnew[show_night]', $setting['userconfig']['show_night'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0099'), 'settingnew[show_visitor]', $setting['userconfig']['show_visitor'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0100'), 'settingnew[show_visitorhead]', $setting['userconfig']['show_visitorhead'], 'text');
	showsetting(lang('plugin/guiigo_manage', 'slang0101'), 'settingnew[show_invitation]', $setting['userconfig']['show_invitation'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0102'));
	showsetting(lang('plugin/guiigo_manage', 'slang0103'), 'settingnew[show_invitationpg]', $setting['userconfig']['show_invitationpg'], 'text');
	showsetting(lang('plugin/guiigo_manage', 'slang0104'), '', '', GuiigoApp::get_select('settingnew[home_show_selection]', $select, $setting['userconfig']['home_show_selection'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0159'), 'settingnew[show_credit]', $setting['userconfig']['show_credit'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0160'));
	showtableheader(lang('plugin/guiigo_manage', 'slang0232'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0233'), 'settingnew[search_slide]', $setting['userconfig']['search_slide'], 'textarea', '', '', lang('plugin/guiigo_manage', 'slang0234'));
	showsetting(lang('plugin/guiigo_manage', 'slang0238'), 'settingnew[search_tite]', $setting['userconfig']['search_tite'], 'text');
	showtablefooter(); /*Dism_taobao-com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter(); /*Dism_taobao-com*/
	showformfooter(); /*dism��taobao��com*/
} else {
	$setting['userconfig'] = $_POST['settingnew'];
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}