var app = new ckRpe()
var safescripts = {}, evalscripts = [],JSLOADED= [],cacheloadAudio= [];
var endtop = 0,stop = 0,endzy = 0,szy = 0;

var loadAudio = function(type,callback) {
	var wid = 'audio-'+ type;
	if(ck8.inArray(wid, cacheloadAudio) != -1){
		if (typeof callback === "function") {
			callback()
		}
		return;
	}
	cacheloadAudio.push(wid);
	var audio = document.createElement("audio");
	audio.style.display = "none";
	audio.id = wid;
	audio.src = CKPATH +'images/music/'+ wid +'.wav';
	audio.oncanplay= function (e) {
		if (typeof callback === "function") {
			callback()
		}
	}
	document.body.appendChild(audio);
}

var defPage = {
	converthtml : function() {
		var prevpage = $('div.pg .prev').prop('href');
		var nextpage = $('div.pg .nxt').prop('href');
		var lastpage = $('div.pg label span').text().replace(/[^\d]/g, '') || 0;
		var curpage = $('div.pg input').val() || 1;

		if(!lastpage) {
			prevpage = $('div.pg .pgb a').prop('href');
		}

		var prevpagehref = nextpagehref = '';
		if(prevpage == undefined) {
			prevpagehref = 'javascript:;" class="grey';
		} else {
			prevpagehref = prevpage;
		}
		if(nextpage == undefined) {
			nextpagehref = 'javascript:;" class="grey';
		} else {
			nextpagehref = nextpage;
		}

		var selector = '';
		if(lastpage) {
			selector += '<a id="select_a" style="margin:0 2px;padding:1px 0 0 0;border:0;display:inline-block;position:relative;width:100px;height:31px;line-height:27px;background:url('+STATICURL+'/image/mobile/images/pic_select.png) no-repeat;text-align:left;text-indent:20px;">';
			selector += '<select id="dumppage" style="position:absolute;left:0;top:0;height:27px;opacity:0;width:100px;">';
			for(var i=1; i<=lastpage; i++) {
				selector += '<option value="'+i+'" '+ (i == curpage ? 'selected' : '') +'>\u7b2c'+i+'\u9875</option>';
			}
			selector += '</select>';
			selector += '<span>\u7b2c'+curpage+'\u9875</span>';
		}

		$('div.pg').removeClass('pg').addClass('page').html('<a href="'+ prevpagehref +'">\u4e0a\u4e00\u9875</a>'+ selector +'<a href="'+ nextpagehref +'">\u4e0b\u4e00\u9875</a>');
		$('#dumppage').on('change', function() {
			var href = (prevpage || nextpage);
			window.location.href = href.replace(/page=\d+/, 'page=' + $(this).val());
		});
	},
};

var popup = {
	open : function(pop, type, url) {
	    var _this = this, popModal = false;
		_this.close();        
		if(!url){
			url = ck8(pop).find('a').attr('href');
		}
		if(typeof pop == 'string') {
			if(type == 'alert') {
				ck8.alert(pop, '\u6e29\u99a8\u63d0\u793a', function () {
					_this.close()
				});
				return false;
			} else if(type == 'confirm') {
				ck8.confirm(pop, '\u6e29\u99a8\u63d0\u793a',
					function () { 
						if(url) _this.router(url)
                        _this.close()
					},
					function () {
					  _this.close()
					}
				);
				return false;
			}else{
                popModal = true;
			}
		}
		if(popModal && pop){
            app.popModal(pop)
		}
	},
	router : function(url) {
		ck8.router.load(url, true);
	},
	close : function() {
		ck8.closeModal();
	}
}

var dialog = {
	init : function() {
		ck8(document).off('click', '.dialog').on('click', '.dialog', function(event) {
            var obj = ck8(this);
			var pObj = app.AnalysisAll(obj);
			if(typeof pObj !== 'object'){
                pObj ={}
			}
			var _confirm = obj.attr('ck-confirm') ? obj.attr('ck-confirm') : false,
				cus = pObj.cus ? pObj.cus : '',
				allparam = pObj.param ? pObj.param : {},
				param = allparam.callpar ? allparam.callpar : {},
				fn = allparam.fn ? allparam.fn : '',
				load = allparam.load ? allparam.load : false,
				uid = parseInt(allparam.uid) ? parseInt(allparam.uid) : false,
				verifyLoging = allparam.verifyLoging ? true : false;
				if(cus && (uid == false || uid <= 0 || parseInt(discuz_uid) != uid) && !verifyLoging){
					if(!parseInt(discuz_uid)){
						login.GoLogin();
						return false;
					}
				}
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			if(_confirm == 'true'){
				ck8.confirm('<div class="c9">'+(allparam.msg ? allparam.msg : '\u786e\u5b9a\u8981\u53d6\u6d88\u5173\u6ce8\u0054\u0041\u5417\uff1f') +'</div>', (allparam.title ? allparam.title : '\u6e29\u99a8\u63d0\u793a'), function (){
					_ajaxGet(obj,cus,load,fn,param)
				})
			}else{
				_ajaxGet(obj,cus,load,fn,param)
			}
			return false;
		})
	}
}

function _ajaxGet(obj,cus,load,fn,param){
	if(!load)
	    ck8.showPreloader('','load');
	ck8.ajax({
		type : 'GET',
		url : obj.attr('href') + '&inajax=1&fn='+ fn,
		dataType : 'xml',
		success: function(s){
			ck8.hidePreloader()
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
			if(cus == 'true' && (Docs.indexOf("=='function')") != -1)){
				if(app.Devalscript(Docs,fn,param))return false;
			}else if(cus == 'true' && (Docs.indexOf(">window.location.href='") != -1)){
				var isfn = false,url='',Msgfn;
				try{
					isfn = typeof(eval(fn)) == 'function';
				}catch(e){
					console.log(e)
				}
				if(isfn){
					var result = Docs.match(/href=(\S*)(<\/script>)$/i);
					if(result[1]){
						url = result[1].match(/'(\S*)'/)[1].replace('&mobile=2','');
					}
					Msgfn = eval(fn)
					Msgfn({'msg':'isjmurl', 'url':url},{}, param)
					return false;
				}
			}else if(Docs.indexOf('data-mod="login"') != -1){
				login.GoLogin();
				return;
			}
			popup.open(Docs);
			evalscript(Docs);
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

var formdialog = {
	init : function() {
		ck8(document).off('click', '.formdialog').on('click', '.formdialog', function() {
			var ft = Object;
            var formobj = ck8(this.form)
			var pObj = app.AnalysisAll(formobj);
			if(typeof pObj !== 'object'){
                pObj ={}
			}
			var cus = pObj.cus ? pObj.cus : '',
				allparam = pObj.param ? pObj.param : {},
				param = allparam.callpar ? allparam.callpar : {},
				fn = allparam.fn ? allparam.fn : '',
				load = allparam.load ? allparam.load : false,
				uid = parseInt(allparam.uid) ? parseInt(allparam.uid) : false,
                verifyLoging = allparam.verifyLoging ? true : false;
				if(cus && (uid == false || uid <= 0 || parseInt(discuz_uid) != uid) && !verifyLoging){
					if(!parseInt(discuz_uid)){
						login.GoLogin();
						return false;
					}
				}
			
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			
			if(allparam.verify != undefined && allparam.verify){
				if(eval('('+ allparam.verify +'())')){
					return false;
				}
			}
			
			if(allparam.upfiles == undefined){
				allparam.upfiles = false;
			}
			
			if(allparam.upfiles){
				ft = new FormData(formobj[0]);
			}

			var postAata = {
				type:'POST',
				url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&fn='+ fn +'&inajax=1',
				data: allparam.upfiles ? ft : formobj.serialize(),
				dataType:'xml',
				success: function(e){success(e)},
				error: function(e){error(e)}
			};
            if(allparam.upfiles){
				postAata.processData = false;
				postAata.contentType = false;
			}

			var	success = function(s){
				ck8.hidePreloader()
				var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
				if(Docs && Docs.indexOf("show_success(") != -1 ||  Docs.indexOf("show_error(") != -1){
					 eval(Docs)
				    return;
				}
				if(cus == 'true' && (Docs.indexOf("=='function')") != -1)){
					if(app.Devalscript(Docs,fn,param))return false;
				}else if(cus == 'true' && (Docs.indexOf(">window.location.href='") != -1)){
					var isfn = false,url='',Msgfn;
					try{
						isfn = typeof(eval(fn)) == 'function';
					}catch(e){
						console.log(e)
					}
					if(isfn){
						var result = Docs.match(/href=(\S*)(<\/script>)$/i);
						if(result[1]){
							url = result[1].match(/'(\S*)'/)[1].replace('&mobile=2','');
						}
						Msgfn = eval(fn)
						Msgfn({'msg':'isjmurl', 'url':url},{}, param)
						return false;
					}
				}else if(Docs.indexOf('data-mod="login"') != -1){
					login.GoLogin();
					return;
				}
				popup.open(Docs);
				evalscript(Docs);
			}
				
			var	error = function(){
				ck8.hidePreloader();
				ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
			}
			
			if(load)
				ck8.showPreloader('','load');
			ck8.ajax(postAata)
			return false;
		})
	}
}

function evalscript(s) {
	if(s.indexOf('<script') == -1) return s;
	var p = /<script[^\>]*?>([^\x00]*?)<\/script>/ig;
	var arr = [];
	while(arr = p.exec(s)) {
		var p1 = /<script[^\>]*?src=\"([^\>]*?)\"[^\>]*?(reload=\"1\")?(?:charset=\"([\w\-]+?)\")?><\/script>/i;
		var arr1 = [];
		arr1 = p1.exec(arr[2]);
		if(arr1) {
			appendscript(arr1[1], '', arr1[2], arr1[3]);
		} else {
			p1 = /<script(.*?)>([^\x00]+?)<\/script>/i;
			arr1 = p1.exec(arr[0]);
			if(!arr1) return;
			appendscript('', arr1[2], arr1[1].indexOf('reload=') != -1);
		}
	}
	return s;
}

function appendscript(src, text, reload, charset) {
	var id = hash(src + text);
	if(!reload && in_array(id, evalscripts)) return;
	if(reload && $('#' + id)[0]) {
		ck8('#' + id)[0].parentNode.removeChild(ck8('#' + id)[0]);
	}
	evalscripts.push(id);
	var scriptNode = document.createElement("script");
	scriptNode.type = "text/javascript";
	scriptNode.id = id;
	scriptNode.charset = charset ? charset : (!document.charset ? document.characterSet : document.charset);
	try {
		if(src) {
			scriptNode.src = src;
			scriptNode.onloadDone = false;
			scriptNode.onload = function () {
				scriptNode.onloadDone = true;
				JSLOADED[src] = 1;
			};
			scriptNode.onreadystatechange = function () {
				if((scriptNode.readyState == 'loaded' || scriptNode.readyState == 'complete') && !scriptNode.onloadDone) {
					scriptNode.onloadDone = true;
					JSLOADED[src] = 1;
				}
			};
		} else if(text){
			scriptNode.text = text;
		}
		document.getElementsByTagName('head')[0].appendChild(scriptNode);
	} catch(e) {}
}

function hash(string, length) {
	var length = length ? length : 32;
	var start = 0;
	var i = 0;
	var result = '';
	filllen = length - string.length % length;
	for(i = 0; i < filllen; i++){
		string += "0";
	}
	while(start < string.length) {
		result = stringxor(result, string.substr(start, length));
		start += length;
	}
	return result;
}

function stringxor(s1, s2) {
	var s = '';
	var hash = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	var max = Math.max(s1.length, s2.length);
	for(var i=0; i<max; i++) {
		var k = s1.charCodeAt(i) ^ s2.charCodeAt(i);
		s += hash.charAt(k % 52);
	}
	return s;
}

function isUndefined(variable) {
	return typeof variable == 'undefined' ? true : false;
}

function relatekw(obj,maxlen,msg) {
	var v = obj.value, charlen = 0, maxlen = !maxlen ? 200 : maxlen, curlen = maxlen, len = v.length;
	for(var i = 0; i < v.length; i++) {
		if(v.charCodeAt(i) < 0 || v.charCodeAt(i) > 255) {
			curlen -= charset == 'utf-8' ? 2 : 1;
		}
	}
	if(curlen <= len) {
		if(!msg){
			msg = '\u6700\u5927\u9650\u5236\u6807\u9898\u957f\u5ea6'+ maxlen;
		}else{
			msg = msg + maxlen;
		}
		obj.value = mb_cutstr(v, maxlen, 0);
		ck8.toast(msg,'shibai');
	}
}

function mb_cutstr(str, maxlen, dot) {
	var len = 0;
	var ret = '';
	var dot = !dot ? '' : dot;
	maxlen = maxlen - dot.length;
	for(var i = 0; i < str.length; i++) {
		len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? (charset == 'utf-8' ? 3 : 2) : 1;
		if(len > maxlen) {
			ret += dot;
			break;
		}
		ret += str.substr(i, 1);
	}
	return ret;
}

function strLenCalc(obj, checklen, maxlen) {
	var v = obj.value, charlen = 0, maxlen = !maxlen ? 200 : maxlen, curlen = maxlen, len = v.length;
	for(var i = 0; i < v.length; i++) {
		if(v.charCodeAt(i) < 0 || v.charCodeAt(i) > 255) {
			curlen -= charset == 'utf-8' ? 2 : 1;
		}
	}
	if(curlen >= len) {
		Dz(checklen).innerHTML = curlen - len;
	} else {
		obj.value = mb_cutstr(v, maxlen, 0);
	}
}

function setcookie(cookieName, cookieValue, seconds, path, domain, secure) {
	if(cookieValue == '' || seconds < 0) {
		cookieValue = '';
		seconds = -2592000;
	}
	if(seconds) {
		var expires = new Date();
		expires.setTime(expires.getTime() + seconds * 1000);
	}
	domain = !domain ? cookiedomain : domain;
	path = !path ? cookiepath : path;
	document.cookie = escape(cookiepre + cookieName) + '=' + escape(cookieValue)
		+ (expires ? '; expires=' + expires.toGMTString() : '')
		+ (path ? '; path=' + path : '/')
		+ (domain ? '; domain=' + domain : '')
		+ (secure ? '; secure' : '');
}

function getcookie(name, nounescape) {
	name = cookiepre + name;
	var cookie_start = document.cookie.indexOf(name);
	var cookie_end = document.cookie.indexOf(";", cookie_start);
	if(cookie_start == -1) {
		return '';
	} else {
		var v = document.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : document.cookie.length));
		return !nounescape ? unescape(v) : v;
	}
}

function inserattach(aid) {
	insertText2focus(Dz('needmessage'),"[attachimg]"+ aid +"[/attachimg]");
}

function insertat(str) {
	insertText2focus(Dz('needmessage'),str);
}

function delFile(obj,id){
	var obj = ck8(obj),
		aid = obj.attr('aid');
	if(!aid)return false;
	if(!navigator.onLine){
		ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	ck8.showPreloader('',true);
	ck8.get(
		'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + aid,
		function(s) {
			setTimeout(function(){$.hidePreloader()}, 100);
			var _val = ck8('#needmessage').val();
			ck8('#needmessage').val(_val.replace('[attachimg]' + obj.attr('aid') + '[/attachimg]',''));
			if(id){ck8('#'+id).remove();}else{obj.parent().remove();}
		}
	)
	return false;
}

function Dz(id) {
	return !id ? null : document.getElementById(id);
}

function mb_strlen(str) {
	var len = 0;
	for(var i = 0; i < str.length; i++) {
		len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? (charset == 'utf-8' ? 3 : 2) : 1;
	}
	return len;
}

function in_array(needle, haystack) {
	if(typeof needle == 'string' || typeof needle == 'number') {
		for(var i in haystack) {
			if(haystack[i] == needle) {
				return true;
			}
		}
	}
	return false;
}

function clnavOp(){
	if(ck8('.guiigo-clnav').length){
		app.handleEvent(function(e,r){
			if(r == 'touchstart'){
			  stop = e.sy;
			  szy = e.sx;
			}else if(r == 'touchmove'){
				if(e.ey > 0){
					endtop = e.ey;
				}
				if(e.ey > 0){
					endzy = e.ex;
				}
			}else if(r == 'touchend'){
				if(e.isScrolling == 1 && stop > endtop){
					try {
						ck8('.guiigo-clnav')[0].style.transform = "translatex(100px)";
						ck8('.guiigo-clnav')[0].style.transition = "transform .2s";
					}catch(e){}
				}else if(e.isScrolling == 1 && stop < endtop){
					try {
						ck8('.guiigo-clnav')[0].style.transform = "translatex(0px)";
						ck8('.guiigo-clnav')[0].style.transition = "transform .2s";
					}catch(e){}
				}
				if(e.direction == 'right' && Math.abs(szy-endzy) > 50){
					try {
						ck8('.guiigo-clnav')[0].style.transform = "translatex(100px)";
						ck8('.guiigo-clnav')[0].style.transition = "transform .2s";
					}catch(e){}
				}else if(e.direction == 'left' && Math.abs(szy-endzy) > 50){
					try {
						ck8('.guiigo-clnav')[0].style.transform = "translatex(0px)";
						ck8('.guiigo-clnav')[0].style.transition = "transform .2s";
					}catch(e){}
				}
			}
		},'.content')
	}
}

var pageScrollTop = {
	init : function() {
		clnavOp();
		ck8('.content').on('scroll',function(e){
			app.lazyLoad()
			var hdoc = ck8(this).scrollTop();
			app.ScrollAutoTop(hdoc);
			app.HeadShade(hdoc);
			titleshow(hdoc,135,'.gg-nytp-xq','.gg-nyto-yh');
			try {
				if (hdoc > 450){
					if(ck8('.ck8-top').length){
						ck8('.ck8-top').css({'opacity': 1})
					}
					var tops = 5;
					if(ck8('.bar-rep').length <= 0 || ck8('nav').length <= 0)
					   tops = 4;
					var h = (ck8(window).height() / tops);
					if (ck8('.ck8-to-top').css('display') == 'block') return;
					if(ck8('.ck8-to-top').length){
						ck8('.ck8-to-top').css({'bottom': h + 'px'}).fadeIn(1500,function(){
							ck8(this).show()
						})
					}
				}else{
					if(ck8('.ck8-top').length){
						ck8('.ck8-top').css({'opacity': 0})
					}
					ck8('.ck8-to-top').fadeOut(1500)
				}
			} catch(e) {}
		})

		ck8(document).off('click', '.ck8-to-top').on('click', '.ck8-to-top', function() {
			ck8('.content')._scrollTo({toT: 0});
		})
		ck8(document).off('click', '.ck8-top').on('click', '.ck8-top', function() {
			ck8('.content')._scrollTo({toT: 0});
		})
		ck8(document).off('click', '.postselect-popup').on('click','.postselect-popup', function (){
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			ck8.ajax({
				type : 'GET',
				url :'forum.php?mod=misc&action=nav&inajax=1',
				dataType : 'xml',
				success: function(s){
                    ck8.popup(s.lastChild.firstChild.nodeValue)
				},
				error: function(){
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			})
		})
		
        ck8(document).off('click', '.getpm-popup').on('click','.getpm-popup', function (){
			var url = ck8(this).attr('data-url')
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			ck8.ajax({
				type : 'GET',
				url : url +'&inajax=1',
				dataType : 'xml',
				success: function(s){
					var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
					ck8.popup(Docs)
					var top =  $('#msglist')[0].clientHeight
					$('.content-pm')._scrollTo({ toT:top,durTime:0});
				},
				error: function(){
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			})
		})

		ck8(document).off('click', '.postrepl-popup').on('click','.postrepl-popup', function (){
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			var url = ck8(this).attr('data-url')
			ck8.ajax({
				type : 'GET',
				url :url+'&inajax=1',
				dataType : 'xml',
				success: function(s){
                    ck8.popup(s.lastChild.firstChild.nodeValue)
				},
				error: function(){
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			})
		})
	}
}

function sdialog(){
	var dialog = ck8('.ck8-dialog');
 	if(dialog.css('display') == 'none')
    dialog._show(300);
    else
	dialog.hide();
}

var login = {
	init : function() {
		ck8(document).off('click', '.login').on('click', '.login', function(){
            login._login()
			return false;
		})
	},
	GoLogin : function() {
        login._login()
	},
	_login: function() {
		var url = encodeURIComponent(window.location.href.replace('#','') +'&run=yes');
		ck8.confirm('\u4f60\u5c1a\u672a\u767b\u5f55\uff0c\u8bf7\u5148\u767b\u5f55', '\u767b\u5f55\u63d0\u793a',
			function (){
				app.close_popup();
				if(ck8.isApp && ck8.isApp()){
					ck8.redirectTo('/pages/login/login?weblastUrl='+url)
				}else{
					ck8.router.load('member.php?mod=logging&action=login&referer=' + url, true);
				}
			},
			function (){}
		)
		return false;
	}
}

function ajaxget(_this,url,objid,isappend,callback) {
	var page = 0;
	if(_this){
		page = parseInt(ck8(_this).attr('data-page'));
	}
	if(!navigator.onLine){
	   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	ck8.showPreloader('',true);
	ck8.ajax({
		type:'GET',
		url: url +'&page='+ page +'&inajax=1',
		dataType:'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 100);
			var html = ck8.trim(app.initAtr(s.lastChild.firstChild.nodeValue))
			if(html && html != ''){
				if(isappend){
					ck8('#'+ objid).append(html);
				}else{
					ck8('#'+ objid).html(html);
				}
				if(_this)
					ck8(_this).attr('data-page',page +1);
			}else{
				var msg = ck8(_this).attr('data-msg') || '\u6ca1\u6709\u4e86';
				if(_this){
					ck8(_this).html(msg).attr('onclick','');
				}else{
					ck8('#'+objid).html('');
				}
			}
			if(typeof callback === 'function'){
				callback(html);
			}
			ck8.refreshScroller()
		}
	})
	return false;
}

function modaction(obj,action, pid, extra, mod) {
	if(!action || !obj) {return;}
	var mod = mod ? mod : 'forum.php?mod=topicadmin',
	    extra = !extra ? '' : '&' + extra,
	    pObj = app.AnalysisAll(obj);
	if(typeof pObj !== 'object'){
		pObj ={}
	}
	var cus = pObj.cus ? pObj.cus : '',
		allparam = pObj.param ? pObj.param : {},
		param = allparam.callpar ? allparam.callpar : {},
		fn = allparam.fn ? allparam.fn : '',
		load = allparam.load ? allparam.load : false,
		uid = parseInt(allparam.uid) ? parseInt(allparam.uid) : false,
		verifyLoging = allparam.verifyLoging ? true : false;
		if(cus && (uid == false || uid <= 0 || parseInt(discuz_uid) != uid) && !verifyLoging){
			if(!parseInt(discuz_uid)){
				login.GoLogin();
				return false;
			}
		}
	if(!pid) {
        pid = param.pid ? param.pid : '';
	}
	var tid = param.tid ? param.tid : '',
		fid = param.fid ? param.fid : '',
		cpid = param.cpid ? param.cpid : '';

	if(!pid || !tid || !fid){
		ck8.toast('param_error');
		return false;
	}
	var actionurl = mod + '&action='+ action +'&fid=' + fid + '&tid=' + tid + '&fnpid=' + cpid +'&handlekey=mods&infloat=yes&nopost=yes' + (!pid ? '' : '&topiclist[]=' + pid) + extra + '&r' + Math.random();
	if(!navigator.onLine){
	   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	if(load)
	    ck8.showPreloader('','load');
	ck8.ajax({
		type:'POST',
		url: actionurl +'&inajax=1&fn='+ fn,
		dataType: 'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 200);
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
			if(cus == 'true' && (Docs.indexOf("=='function')") != -1)){
				if(app.Devalscript(Docs,fn,param))return false;
			}
			popup.open(Docs);
			evalscript(Docs);
		},
		error: function(){
			ck8.hidePreloader();
            ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

function modthreads(obj, optgroup, operation) {
	var operation = !operation ? '' : operation,
	    pObj = app.AnalysisAll(obj);
	if(typeof pObj !== 'object'){
		pObj ={}
	}
	var cus = pObj.cus ? pObj.cus : '',
		allparam = pObj.param ? pObj.param : {},
		param = allparam.callpar ? allparam.callpar : {},
		fn = allparam.fn ? allparam.fn : '',
		load = allparam.load ? allparam.load : false,
		uid = parseInt(allparam.uid) ? parseInt(allparam.uid) : false,
		verifyLoging = allparam.verifyLoging ? true : false;
		if(cus && (uid == false || uid <= 0 || parseInt(discuz_uid) != uid) && !verifyLoging){
			if(!parseInt(discuz_uid)){
				login.GoLogin();
				return false;
			}
		}
    var pid = param.pid ? param.pid : '',
		tid = param.tid ? param.tid : '',
		fid = param.fid ? param.fid : '';
	if(!tid || !fid || !optgroup){
		ck8.toast('param_error');
		return false;
	}
	var actionurl = 'forum.php?mod=topicadmin&action=moderate&fnpid=' + pid + '&fid=' + fid + '&moderate[]=' + tid + '&handlekey=mods&infloat=yes&nopost=yes' + (optgroup != 3 && optgroup != 2 ? '&from=' + tid : '')+ '&operation='+ operation +'&optgroup='+ optgroup;
	if(!navigator.onLine){
	   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	if(load)
	    ck8.showPreloader('','load');
	ck8.ajax({
		type:'POST',
		url: actionurl +'&inajax=1&fn='+ fn,
		dataType: 'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 200);
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
			if(cus == 'true' && (Docs.indexOf("=='function')") != -1)){
				if(app.Devalscript(Docs,fn,param))return false;
			}
			popup.open(Docs);
			evalscript(Docs);
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

function display(_this,el) {
	ck8(el).each(function(index, item){
		if(ck8(item).hasClass('none')){
            ck8(item).removeClass('none').addClass('show')
		}else if(ck8(item).hasClass('show')){
            ck8(item).removeClass('show').addClass('none')
		}
	})
	if(ck8(_this).find('i').hasClass('guiigoapp-xxzk')){
		ck8(_this).html('\u6536\u8d77<i class="icon guiigoapp-xszk"></i>')
	}else if(ck8(_this).find('i').hasClass('guiigoapp-xszk')){
		ck8(_this).html('\u66f4\u591a<i class="icon guiigoapp-xxzk zy-c"></i>')
	}
}

function poll_checkbox(obj) {
	if(obj.checked) {
		p++;
		for (var i = 0; i < Dz('poll').elements.length; i++) {
			var e = Dz('poll').elements[i];
			if(p == max_obj) {
				if(e.name.match('pollanswers') && !e.checked) {
					e.disabled = true;
				}
			}
		}
	} else {
		p--;
		for (var i = 0; i < Dz('poll').elements.length; i++) {
			var e = Dz('poll').elements[i];
			if(e.name.match('pollanswers') && e.disabled) {
				e.disabled = false;
			}
		}
	}
	Dz('pollsubmit').disabled = p <= max_obj && p > 0 ? false : true;
}

function setanswer(tid, pid, from,formhash,fn,param){
	if(!formhash) return false;
	if(!fn) fn = '';
	if(!param) param ={};
	var actionurl = 'forum.php?mod=misc&action=bestanswer&tid=' + tid + '&pid=' + pid + '&from=' + from + '&bestanswersubmit=yes&formhash='+ formhash;
	if(!navigator.onLine){
	   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	ck8.confirm('<div class="c9">\u60a8\u786e\u8ba4\u8981\u628a\u8be5\u56de\u590d\u9009\u4e3a\u201c\u6700\u4f73\u7b54\u6848\u201d\u5417\uff1f</div>', '\u8bbe\u7f6e\u6700\u4f73\u7b54\u6848', function (){
		ck8.showPreloader('','load');
		ck8.ajax({
			type:'POST',
			url: actionurl +'&inajax=1&fn='+ fn,
			dataType: 'xml',
			success: function(s){
				setTimeout(function(){ck8.hidePreloader()}, 200);
				var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
				if(Docs.indexOf("=='function')") != -1){
					if(app.Devalscript(Docs,fn,param))return false;
				}
				popup.open(Docs);
				evalscript(Docs);
			},
			error: function(){
				ck8.hidePreloader();
				ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
			}
		})
	})
}

function checkall(form, prefix, checkall) {
	var checkall = checkall ? checkall : 'chkall';
	count = 0;
	var ch;
	if(form.elements[checkall].checked){
		ch = false;
	}else{
		ch = true;
	}
	for(var i = 0; i < form.elements.length; i++) {
		var e = form.elements[i];
		if(e.name && e.name != checkall && !e.disabled && (!prefix || (prefix && e.name.match(prefix)))) {
			e.checked = ch;
			if(e.checked) {
				count++;
			}
		}
	}
	return count;
}

function submitpostpw(pid, tid) {
	var obj = Dz('postpw_' + pid),url='';
	ck8.showPreloader('\u5904\u7406\u4e2d...');
	app.loadScript('md5',function(){
		safescript('md5_js', function (){
			setcookie('postpw_' + pid, hex_md5(obj.value));
			setTimeout(function(){ck8.hidePreloader()}, 200);
			if(!tid) {
				url = location.href;
			} else {
				url = 'forum.php?mod=viewthread&tid='+ tid +'&viewpid='+ pid;
			}
			app.PageRefresh('','#pid'+ pid,url +'&inajax=1')
		}, 100, 50);
	})
}

function safescript(id, call, seconds, times, timeoutcall, endcall, index) {
	seconds = seconds || 1000;
	times = times || 0;
	var checked = true;
	try {
		if(typeof call == 'function') {
			call();
		} else {
			eval(call);
		}
	} catch(e) {
		checked = false;
	}
	if(!checked) {
		if(!safescripts[id] || !index) {
			safescripts[id] = safescripts[id] || [];
			safescripts[id].push({
				'times':0,
				'si':setInterval(function () {
					safescript(id, call, seconds, times, timeoutcall, endcall, safescripts[id].length);
				}, seconds)
			});
		} else {
			index = (index || 1) - 1;
			safescripts[id][index]['times']++;
			if(safescripts[id][index]['times'] >= times) {
				clearInterval(safescripts[id][index]['si']);
				if(typeof timeoutcall == 'function') {
					timeoutcall();
				} else {
					eval(timeoutcall);
				}
			}
		}
	} else {
		try {
			index = (index || 1) - 1;
			if(safescripts[id][index]['si']) {
				clearInterval(safescripts[id][index]['si']);
			}
			if(typeof endcall == 'function') {
				endcall();
			} else {
				eval(endcall);
			}
		} catch(e) {}
	}
}

function inSwiper(el){
	if(ck8(el).length==0)return;
	app.loadScript('jsswiper-4.3.3.min', function() {
		new Swiper(el, {
			loop: true,
			autoplay: true,
			pagination: {
				el: '.swiper-pagination',
				bulletClass : 'ck8-bullet',
				bulletActiveClass: 'ck8-bullet-active',
				clickable: true,
			}
		})
		ck8(el).css({
			'visibility': 'visible'
		});
	})
}

function inSwiperTab(el,cut,Offset){
	var nW = 0, cW = 0, nWt = 0, nAL = 0;
   if(!Offset) Offset = 0;
   if(ck8(el).length==0) return;
   var slide = ck8(el).find('.swiper-slide');
   var width ='20%';
	if(slide.length && slide.length == 4){
		width ='25%';
    }else if(slide.length && slide.length == 3){
		width ='33.33%';
	}else if(slide.length && slide.length == 2){
		width ='50%';
	}else if(slide.length && slide.length == 1){
		width ='35%';
	}
   slide.css({width});
	new Swiper(el, {
		slidesPerView: 'auto',
		freeMode: true,
		slidesOffsetAfter: Offset,
		on: {
			init: function() {
				nW = this.slides.eq(0).css('width');
				cW = parseInt(this.$wrapperEl.css('width'));
				for (var i = 0; i < this.slides.length; i++) {
					nWt += parseInt(this.slides.eq(i).css('width'));
				}
				this.$el.css({'visibility':'visible'})
			},
			tap: function() {
				if(this.slides[this.clickedIndex]){
					nAL = this.slides[this.clickedIndex].offsetLeft;
					this.slides.removeClass('on')
					this.slides.eq(this.clickedIndex).addClass('on')
					if(slide.length && slide.length >4){
						this.setTransition(300);
						if(nAL < (cW - parseInt(nW)) / 2){
							this.setTranslate(0)
						}else if(nAL > nWt - (parseInt(nW) + cW) / 2) {
							this.setTranslate(cW - nWt);
						}else{
							this.setTranslate((cW - parseInt(nW)) / 2 - nAL)
						}
					}
				}
			}
		}
	})
}

function passwordShow(value) {
	if(value==4) {
		Dz('span_password').style.display = '';
		Dz('tb_selectgroup').style.display = 'none';
	} else if(value==2) {
		Dz('span_password').style.display = 'none';
		Dz('tb_selectgroup').style.display = '';
	} else {
		Dz('span_password').style.display = 'none';
		Dz('tb_selectgroup').style.display = 'none';
	}
}

function getgroup(gid) {
	if(gid) {
		ck8.showPreloader('',true);
		ck8.ajax({
			type:'GET',
			url: 'home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid='+ gid,
			dataType:'xml',
			success: function(s){
				setTimeout(function(){ck8.hidePreloader()}, 100);
				s = s.lastChild.firstChild.nodeValue;
				s = s.replace(/<[^>]+>/g,"");
				s = s.replace(/(^\s*)|(\s*$)/g, ""); 
				s = s + ' ';
				Dz('target_names').innerHTML += s;
			}
		})
	}
}

/////////////////////2019-7-29////////////////////////////////
function trim(str) {
	return (str + '').replace(/(\s+)$/g, '').replace(/^\s+/g, '');
}

function _display(id) {
	var obj = Dz(id);
	if(obj.style.visibility) {
		obj.style.visibility = obj.style.visibility == 'visible' ? 'hidden' : 'visible';
	} else {
		obj.style.display = obj.style.display == '' ? 'none' : '';
	}
}

function uploadWindow(recall, type) {
	var type = isUndefined(type) ? 'image' : type;
	UPLOADWINRECALL = recall;
	var url = 'forum.php?mod=misc&action=upload&fid=' + fid + '&type=' + type;
	ck8.ajax({
		type : 'GET',
		url : url + '&inajax=1',
		dataType : 'xml',
		success: function(s){
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
			popup.open(Docs);
			evalscript(Docs); 
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

function uploadWindowload() {
	var str = Dz('uploadattachframe').contentWindow.document.body.innerHTML;
	if(str == '') return;
	var arr = str.split('|');
	if(arr[0] == 'DISCUZUPLOAD' && arr[2] == 0) {
		UPLOADWINRECALL(arr[3], arr[5], arr[6]);
		ck8.closeModal();
	} else {
		var sizelimit = '';
		if(arr[7] == 'ban') {
			sizelimit = '(\u9644\u4ef6\u7c7b\u578b\u88ab\u7981\u6b62)';
		} else if(arr[7] == 'perday') {
			sizelimit = '(\u4e0d\u80fd\u8d85\u8fc7 ' + arr[8] + ' \u5b57\u8282)';
		} else if(arr[7] > 0) {
			sizelimit = '(\u4e0d\u80fd\u8d85\u8fc7 ' + arr[7] + ' \u5b57\u8282)';
		}
		ck8.toast(STATUSMSG[arr[2]] + sizelimit);
	}
}

//////////////2019-7-31//////////////////////
function validate(theform) {
	var theform = ck8(theform).find('form')[0];
	var message = theform.message.value;
	if(nosubject){
		if(!sortid && !special && ck8.trim(message) == "") {
			ck8.toast('&#20869;&#23481;&#19981;&#33021;&#20026;&#31354;','shibai');
			return false;
		}
	}else{
		
		if((Dz('postsubmit').name != 'replysubmit' && !(Dz('postsubmit').name == 'editsubmit' && !isfirstpost) && theform.subject.value == "") || !sortid && !special && ck8.trim(message) == "") {
			ck8.toast('\u62b1\u6b49\uff0c\u60a8\u5c1a\u672a\u8f93\u5165\u6807\u9898\u6216\u5185\u5bb9','shibai');
			return false;
		}
		if(theform.subject && mb_strlen(theform.subject.value) > 80) {
			ck8.toast('\u60a8\u7684\u6807\u9898\u8d85\u8fc7\u0020\u0038\u0030\u0020\u4e2a\u5b57\u7b26\u7684\u9650\u5236','shibai');
			return false;
		}
	}
	
	if(in_array(Dz('postsubmit').name, ['topicsubmit', 'editsubmit'])) {
		if(theform.typeid && (theform.typeid.options && theform.typeid.options[theform.typeid.selectedIndex].value == 0) && typerequired) {
			ck8.toast('\u8bf7\u9009\u62e9\u4e3b\u9898\u5bf9\u5e94\u7684\u5206\u7c7b','shibai');
			return false;
		}
		if(theform.sortid && (theform.sortid.options && theform.sortid.options[theform.sortid.selectedIndex].value == 0) && sortrequired) {
			ck8.toast('\u8bf7\u9009\u62e9\u4e3b\u9898\u5bf9\u5e94\u7684\u5206\u7c7b\u4fe1\u606f','shibai');
			return false;
		}
	}
	
	for(i in EXTRAFUNC['validator']) {
		try {
			eval('var v = ' + EXTRAFUNC['validator'][i] + '()');
			if(!v) {
				return false;
			}
		} catch(e) {}
	}

	if(!disablepostctrl && !sortid && !special && ((postminchars != 0 && mb_strlen(message) < postminchars) || (postmaxchars != 0 && mb_strlen(message) > postmaxchars))) {
		ck8.toast('\u60a8\u7684\u5e16\u5b50\u957f\u5ea6\u4e0d\u7b26\u5408\u8981\u6c42\u3002 \n\n \u5f53\u524d\u957f\u5ea6: ' + mb_strlen(message) + ' \u5b57\u8282 \n \u7cfb\u7edf\u9650\u5236: ' + postminchars + ' \u5230 ' + postmaxchars + ' \u5b57\u8282','shibai');
		return false;
	}

	if(isfirstpost && Dz('adddynamic') != null && Dz('adddynamic').checked && Dz('postsave') != null && isNaN(parseInt(Dz('postsave').value)) && (Dz('readperm') != null && Dz('readperm').value || Dz('price') != null && Dz('price').value)) {
		ck8.confirm('\u7531\u4e8e\u60a8\u8bbe\u7f6e\u4e86\u9605\u8bfb\u6743\u9650\u6216\u51fa\u552e\u5e16\uff0c\u60a8\u786e\u8ba4\u8fd8\u8f6c\u64ad\u7ed9\u60a8\u7684\u542c\u4f17\u770b\u5417\uff1f',
			function (){return true;},function (){ return false;}
		)
	}
    return true;
}

//////////////2019-8-11//////////////////////
function showFace(showid, target,obj) {
	if(Dz(showid + '_menu') == null) {
		var faceDiv = document.createElement("div");
		faceDiv.id = showid+'_menu';
		faceDiv.className = 'bqnr-imgs bqnr-wdbj cl';
		var faceul = document.createElement("ul");
		for(i=1; i<31; i++) {
			var faceli = document.createElement("li");
			faceli.innerHTML = '<a><img src="' + STATICURL + 'image/smiley/comcom/'+i+'.gif" onclick="insertFace(\''+showid+'\','+i+', \''+ target +'\')" style="cursor:pointer; position:relative;" /></a>';
			faceul.appendChild(faceli);
		}
		faceDiv.appendChild(faceul);
		Dz(showid).appendChild(faceDiv)
	}
	if(Dz(showid).style.display == 'none'){
		Dz(showid).style.display = 'block';
		ck8(obj).removeClass('zy-c').addClass('zy-be')
	}else{
		Dz(showid).style.display = 'none';
		ck8(obj).removeClass('zy-be').addClass('zy-c')
	}
	ck8(document).off('click', '#'+target).on('click', '#'+target, function(event) {
		Dz(showid).style.display = 'none';
		ck8().removeClass('zy-be').addClass('zy-c')
	})
}

function insertFace(showid, id, target) {
	var faceText = '[em:'+id+':]';
	var m = ck8('#'+target).val()
	ck8('#'+target).val(m + faceText);
    Dz(target).focus();
}

function portal_comment_requote(cid, aid) {
	ck8.showPreloader('','load');
	ck8.ajax({
		type:'POST',
		url:'portal.php?mod=portalcp&ac=comment&op=requote&cid='+cid+'&aid='+aid+'&inajax=1',
		dataType: 'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 200);
			s = s.lastChild.firstChild.nodeValue;
			Dz('message').focus();
            ck8('#message').val(s);
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

/////////////////2019-09-08/////////////////

function showWindowMsgfn(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if(msg.msg.indexOf('\u6210\u529f') != -1){
			ck8.toast(msg.msg);
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

function MsgCallRaterange3(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u62db\u547c\u5df2\u5ffd\u7565') != -1){
			ck8.toast('\u5ffd\u7565\u6210\u529f');
			app.PageRefresh(false,['gg-kj-sdzh','gg-xx-txzt'])
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

function showWindow(el, url, res){
	if(!url){
		doane();
		return;
	}
	var fn='showWindowMsgfn',param={id:el};
	ck8.showPreloader('','load');
	ck8.ajax({
		type : res == 'get' ? 'GET' : 'POST',
		url : url + '&inajax=1&fn='+ fn,
		dataType : 'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 100);
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
			if(Docs.indexOf('data-mod="spacecp-poke"') != -1){
				var newDoc = ck8(Docs).find('.list-block').html();
				var _html = '<div class="popup popup-about-js">\
								<div class="content">\
									<header class="tcca-tops bar bar-nav guiigo-nydb bg-c xh-b guiigo-dydb app-header">\
										<a href="javascript:;" class="tops-gblt button button-link pull-left zy-f" onclick="ck8.closeModal();"><i class="icon guiigoapp-guanbi zy-c"></i></a>\
										<h1 class="title zy-h">\u6253\u62db\u547c</h1>\
									</header>\
									<div class="list-block gg-kj-txdz">'+ newDoc +'</div>\
								</div>\
							</div>';
				ck8.popup(_html);
				doane();
				appTplinit(ck8('.page'))
				return;
			}
			if(Docs.indexOf('data-mod="login"') != -1){
				var newDoc = ck8(Docs).find('.list-block').html();
				var _html = '<div class="popup popup-about-js">\
								<div class="content">\
									<header class="tcca-tops bar bar-nav guiigo-nydb bg-c guiigo-dydb app-header">\
										<a href="javascript:;" class="tops-gblt button button-link pull-left zy-f" onclick="ck8.closeModal();"><i class="icon guiigoapp-guanbi zy-c"></i></a>\
										<h1 class="title zy-h">\u8d26\u53f7\u767b\u5f55</h1>\
									</header>\
									<div class="loginclass">'+ newDoc +'</div>\
								</div>\
							</div>';
				ck8.popup(_html);
				doane();
				appTplinit(ck8('.page'))
				return;
			}
			if(Docs.indexOf("=='function')") != -1){
				
				if(app.Devalscript(Docs,fn,param))return false;
				
			}else if(Docs.indexOf(">window.location.href='") != -1){
				var isfn = false,url='',Msgfn;
				try{
					isfn = typeof(eval(fn)) == 'function';
				}catch(e){
					console.log(e)
				}
				if(isfn){
					var result = Docs.match(/href=(\S*)(<\/script>)$/i);
					if(result[1]){
						url = result[1].match(/'(\S*)'/)[1].replace('&mobile=2','');
					}
					Msgfn = eval(fn)
					Msgfn({'msg':'isjmurl', 'url':url},{}, param)
					return false;
				}
			}
			popup.open(Docs);
			evalscript(Docs);
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
	doane();
}

function doane(event, preventDefault, stopPropagation) {
	var preventDefault = isUndefined(preventDefault) ? 1 : preventDefault;
	var stopPropagation = isUndefined(stopPropagation) ? 1 : stopPropagation;
	e = event ? event : window.event;
	if(!e) {
		e = getEvent();
	}
	if(!e) {
		return null;
	}
	if(preventDefault) {
		if(e.preventDefault) {
			e.preventDefault();
		} else {
			e.returnValue = false;
		}
	}
	if(stopPropagation) {
		if(e.stopPropagation) {
			e.stopPropagation();
		} else {
			e.cancelBubble = true;
		}
	}
	return e;
}

/////////////////2019-08-18/////////////////
function scrollRely(Obj,id){
	if(!id) id= '#comment';
	var type = ck8(Obj).attr('data-type')
	if(type == '1'){
		app.scrollToEnd(id,48)
		ck8(Obj).attr('data-type','2')
		ck8(Obj).find('i').removeClass('guiigoapp-nydbpl').addClass('guiigoapp-neirong')
	}else if(type == '2'){
		ck8('.content')._scrollTo({toT: 0});
		ck8(Obj).attr('data-type','1')
		ck8(Obj).find('i').removeClass('guiigoapp-neirong').addClass('guiigoapp-nydbpl')
	}
}

function MsgCallLogin(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u4f7f\u7528\u6b64\u0020\u0045\u006d\u0061\u0069\u006c\u0020\u7684\u7528\u6237\u4e0d\u5b58\u5728') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u4f7f\u7528\u6b64\u0045\u006d\u0061\u0069\u006c\u7684\u7528\u6237\u4e0d\u5b58\u5728\uff0c\u8bf7\u68c0\u67e5');
		}else if (msg.msg.indexOf('\u62e5\u6709\u7ad9\u70b9\u8bbe\u7f6e\u6743\u9650\u7684\u7528\u6237') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u4f7f\u7528\u5f53\u524d\u0045\u006d\u0061\u0069\u006c\u7684\u7528\u6237\u4e3a\u7279\u6b8a\u7528\u6237\uff0c\u4e0d\u80fd\u4f7f\u7528\u8be5\u529f\u80fd');
		}else if (msg.msg.indexOf('\u60a8\u586b\u5199\u7684\u8d26\u6237\u8d44\u6599\u4e0d\u5339\u914d') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u60a8\u586b\u5199\u7684\u8d26\u6237\u8d44\u6599\u4e0d\u5339\u914d\uff0c\u8bf7\u68c0\u67e5');
		}else if (msg.msg.indexOf('\u53d6\u56de\u5bc6\u7801\u7684\u65b9\u6cd5\u5df2\u901a\u8fc7\u0020\u0045\u006d\u0061\u0069\u006c\u0020\u53d1\u9001\u5230\u60a8\u7684\u4fe1\u7bb1\u4e2d') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u53d6\u56de\u5bc6\u7801\u7684\u65b9\u6cd5\u5df2\u53d1\u9001\u81f3\u60a8\u90ae\u7bb1\uff0c\u8bf7\u67e5\u6536');
		}else if (msg.msg.indexOf('\u6b22\u8fce\u60a8\u56de\u6765') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u6b22\u8fce\u56de\u6765'+ par.username +'\uff0c\u73b0\u5728\u5c06\u8f6c\u5165\u767b\u5f55\u524d\u9875\u9762');
			getAppToken(msg.url)
		}else if (msg.msg.indexOf('\u60a8\u8f93\u5165\u7684\u7528\u6237\u540d\u5c0f\u4e8e') != -1 && param.type == 'regpwform'){
			ck8.toast('\u7528\u6237\u540d\u592a\u77ed\u4e86\uff0c\u8bf7\u91cd\u65b0\u8f93\u5165');
		}else if (msg.msg.indexOf('\u611f\u8c22\u60a8\u6ce8\u518c') != -1 && param.type == 'regpwform'){
			ck8.toast(par.username +' \u606d\u559c\u60a8\u6ce8\u518c\u6210\u529f\uff0c\u8bf7\u7a0d\u540e');
			getAppToken(msg.url)
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

function getAppToken(url){
	if(ck8.isApp()){
		ck8.ajax({
			type : 'GET',
			url : 'plugin.php?id=guiigo_appmanage&api=usertoken&act=getusertoken',
			dataType : 'json',
			success: function(s){
				if(s.code == 1){
					ck8.postMessage({
						datatype: 'webuserlogin',
						token:s.data
					});
					setTimeout(function(){
						if(ISALLTPL>0){
						    window.location.replace(url);
						}else{
							ck8.redirectTo('/pages/webview/webview?weburl='+ encodeURIComponent(url));
						}
					}, 2500);
				}else {
		           ck8.toast(s.msg,'shibai');
				}
			},
			error: function(e){
				ck8.hidePreloader();
				ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
			}
		})
	}else{
		setTimeout(function(){
			window.location.replace(url);
		}, 2500);
	}
}

function MsgCallLogout(msg,par){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u60a8\u5df2\u9000\u51fa\u7ad9\u70b9') != -1){
            ck8.toast('\u60a8\u5df2\u9000\u51fa\uff0c\u8bf7\u7a0d\u540e');
			if(ck8.isApp()){
				ck8.postMessage({
					datatype: 'userlogout'
				});
				if(msg.url.indexOf('&token') !=-1){
					msg.url = msg.url.substring(0,msg.url.indexOf('&token'))
				}
				setTimeout(function(){
					if(ISALLTPL>0){
					    window.location.replace(msg.url);
					}else{
						ck8.redirectTo('/pages/webview/webview?weburl='+ encodeURIComponent(msg.url));
					}
				}, 2000);
            }else{
				setTimeout(function(){
					window.location.replace(msg.url);
				}, 2000);
			}
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

function replaceParamVal(uri,paramName,replaceWith) {
    var oUrl = uri.toString();
    var re = eval('/('+ paramName+'=)([^&]*)/gi');
    return oUrl.replace(re,paramName+'='+replaceWith);
}

function MsgCallPasswdbk(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u5bc6\u7801\u9a8c\u8bc1\u6210\u529f') != -1){
			ck8.toast('\u5bc6\u7801\u9a8c\u8bc1\u6210\u529f\uff0c\u8bf7\u7a0d\u540e');
			setTimeout(function(){
				window.location.href = msg.url;
			}, 2500);
		}else if (msg.msg.indexOf('\u652f\u4ed8\u6210\u529f') != -1){
			ck8.toast('\u652f\u4ed8\u6210\u529f\uff0c\u8bf7\u7a0d\u540e');
			setTimeout(function(){
				window.location.href = msg.url;
			}, 2500);
		}else if (msg.msg.indexOf('\u9a8c\u8bc1\u6210\u529f\uff0c\u73b0\u5728\u8fdb\u5165\u67e5\u770b\u9875\u9762') != -1){
			ck8.toast('\u5bc6\u7801\u9a8c\u8bc1\u6210\u529f\uff0c\u8bf7\u7a0d\u540e');
			setTimeout(function(){
				window.location.href = msg.url;
			}, 2500);
		}else if (msg.msg.indexOf('\u60a8\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u6b63\u786e') != -1){
			ck8.toast('\u60a8\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u6b63\u786e\uff0c\u8bf7\u91cd\u65b0\u8f93\u5165');
		}else if (msg.msg.indexOf('\u60a8\u8f93\u5165\u7684\u7f51\u7ad9\u767b\u5f55\u5bc6\u7801\u4e0d\u6b63\u786e') != -1){
			ck8.toast('\u60a8\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u6b63\u786e\uff0c\u8bf7\u91cd\u65b0\u8f93\u5165');
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

function MsgCallReport(msg,par){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u4e3e\u62a5\u6210\u529f') != -1){
            ck8.toast(msg.msg);
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

/////////////2019-9-19///////////
function infinite(TabId) {
	if(!TabId) TabId ='.type-scroll';
	var url = $(TabId).attr('data-url'),
		page = (parseInt($(TabId).attr('data-page')) +1),
		islod = $(TabId).attr('data-islod');
	if(!url || !page) return;
	if(islod == 'true') return;
	$(TabId).attr('data-islod','true');
	ck8(TabId).find('.guiigo-zdjz').show().html('<div class="preloader preloader-load"></div><span class="loading">\u52a0\u8f7d\u4e2d\u002e\u002e\u002e</span>')
	ck8(TabId).find('.loadpage').hide()
	$.ajax({
		type:'GET',
		url: url +'&page='+ page +'&inajax=1',
		dataType: 'xml',
		success: function(res){
			var res = app.initAtr(res.lastChild.firstChild.nodeValue),
				doc = $.getDom(res),
				dataObj = doc.find(TabId),
				_url = dataObj.attr('data-url'),
				_pages = parseInt(dataObj.attr('data-pages')),
				_page = parseInt(dataObj.attr('data-page')),
				_ppp = parseInt(dataObj.attr('data-ppp'));
			$(TabId).attr('data-url',_url).attr('data-pages',_pages).attr('data-page',_page).attr('data-ppp',_ppp);
			if($(dataObj).find('.list-container').length>0 || $.trim($(dataObj).find('.list-container').html()) !=''){
				ck8(TabId).find('.list-container').append($(dataObj).find('.list-container').html());
				ck8(TabId).find('.guiigo-zdjz').hide()
				ck8(TabId).find('.loadpage').show()
				$(TabId).attr('data-islod','false');
			}else{
				ck8(TabId).find('.guiigo-zdjz').html('<span class="loading">\u6ca1\u6709\u66f4\u591a\u4e86</span>');
			}
		}
	}) 
}

function showdistrict(container, elems, totallevel, changelevel, containertype) {
	var getdid = function(elem) {
		var op = elem.options[elem.selectedIndex];
		return op['did'] || op.getAttribute('did') || '0';
	};
	var pid = changelevel >= 1 && elems[0] && Dz(elems[0]) ? getdid(Dz(elems[0])) : 0;
	var cid = changelevel >= 2 && elems[1] && Dz(elems[1]) ? getdid(Dz(elems[1])) : 0;
	var did = changelevel >= 3 && elems[2] && Dz(elems[2]) ? getdid(Dz(elems[2])) : 0;
	var coid = changelevel >= 4 && elems[3] && Dz(elems[3]) ? getdid(Dz(elems[3])) : 0;
	var url = "home.php?mod=misc&ac=ajax&op=district&container="+container+"&containertype="+containertype
		+"&province="+elems[0]+"&city="+elems[1]+"&district="+elems[2]+"&community="+elems[3]
		+"&pid="+pid + "&cid="+cid+"&did="+did+"&coid="+coid+'&level='+totallevel+'&handlekey='+container+'&inajax=1'+(!changelevel ? '&showdefault=1' : '');
	ajaxget(false,url, container);
}

function fileup(obj,id){
	var reads = new FileReader();
	reads.readAsDataURL(obj.files[0])
	reads.onload = function(){
		ck8(id).attr('src',this.result)
	}
}

function updatestring(str1, str2, clear) {
	str2 = '_' + str2 + '_';
	return clear ? str1.replace(str2, '') : (str1.indexOf(str2) == -1 ? str1 + str2 : str1);
}
function toggle_collapse(objname, noimg, complex, lang) {
	var obj = Dz(objname);
	if(obj) {
		obj.style.display = obj.style.display == '' ? 'none' : '';
		var collapsed = getcookie('collapse');
		collapsed = updatestring(collapsed, objname, !obj.style.display);
		setcookie('collapse', collapsed, (collapsed ? 2592000 : -2592000));
	}
	if(!noimg) {
		var img = Dz(objname + '_img');
		if(img.tagName != 'IMG') {
			if(img.className.indexOf('_yes') == -1) {
				img.className = img.className.replace(/_no/, '_yes');
				if(lang) {
					img.innerHTML = lang[0];
				}
			} else {
				img.className = img.className.replace(/_yes/, '_no');
				if(lang) {
					img.innerHTML = lang[1];
				}
			}
		} else {
			img.src = img.src.indexOf('_yes.gif') == -1 ? img.src.replace(/_no\.gif/, '_yes\.gif') : img.src.replace(/_yes\.gif/, '_no\.gif');
		}
		img.blur();
	}
	if(complex) {
		var objc = Dz(objname + '_c');
		if(objc) {
			objc.className = objc.className == 'umh' ? 'umh umn' : 'umh';
		}
	}
}

function passwordTabtype(_this,el){
	var ptype = ck8(el).attr('type');
	if(ptype == 'password'){
		ck8(el).attr('type','text')
		ck8(_this).find('i').removeClass('guiigoapp-zhengyan').addClass('guiigoapp-biyan')
	}else{
		ck8(el).attr('type','password')
		ck8(_this).find('i').removeClass('guiigoapp-biyan').addClass('guiigoapp-zhengyan')
	}
}

function getMore(pageid,type){
	var scrollPreloader = {
		1:'<span class="loading">\u4e0a\u62c9\u52a0\u8f7d\u66f4\u591a</span>',
		2:'<div class="preloader preloader-load"></div><span class="loading">\u52a0\u8f7d\u4e2d\u002e\u002e\u002e</span>',
		3:'<span class="loading">\u5df2\u7ecf\u5230\u5e95\u4e86</span>',
		4:'<span class="loading">\u65e0\u76f8\u5173\u6570\u636e</span>',
	};
	if(!pageid){
		if(type == 'refresh'){
			ck8.pullToRefreshDone('.pull-to-refresh-content');
		}
		return;
	}
	var loadpageObj = ck8('#loadpage_'+pageid);
	var page = loadpageObj.attr('data-page');
	var orderid = loadpageObj.attr('data-orderid');
	var loadstate = loadpageObj.attr('data-loadstate');
	var scrollTop = loadpageObj.attr('data-scrollTop');
	var scrollTopEnd = loadpageObj.attr('data-scrollTopEnd');
	var url = loadpageObj.attr('data-url');
	
	if(type == 'refresh'){
		page = 0;
		scrollTop = 0;
		loadpageObj.attr('data-scrollTopEnd','1');
	}

	if(!type && scrollTop){
		ck8('.content').scrollTop(parseInt(scrollTop))
	}
	if(typeof swiperPlaye == 'function'){
		swiperPlaye(pageid)
	}
	var isget = true;
	if(page != '0' && !type){
		isget = false;
	}
	if(pageid != orderid){
		isget = false;
	}
	if(loadstate == '2' || loadstate == '3' || loadstate == '4'){
		isget = false;
	}
	if(scrollTopEnd == '2'){
		isget = false;
	}
	if(!isget){
		if(type == 'refresh'){
			ck8.pullToRefreshDone('.pull-to-refresh-content');
		}
		return;
	}
	if(loadstate == '1'){
		ck8('#scroll-preloader_'+pageid).html(scrollPreloader[1]);
	}
	loadpageObj.attr('data-loadstate',2);
	ck8('#scroll-preloader_'+pageid).html(scrollPreloader[2]);
    var apiurl = 'plugin.php?id=guiigo_manage:api&api=PostList&act=getIndexList';
	if(url){
		apiurl = url;
	}
	if(!orderid){
		orderid = '';
	}
	page = parseInt(page) +1;
	ck8.ajax({
		type : 'GET',
		url : apiurl + '&page='+ page +'&orderid='+orderid,
		dataType : 'html',
		success: function(s){
			var Docs = app.initAtr(s);
			loadpageObj.attr('data-page',page);
            if(page == 1 && !Docs){
				loadpageObj.attr('data-loadstate',4);
				ck8('#scroll-preloader_'+pageid).html(scrollPreloader[4]);
				if(type == 'refresh'){
					ck8.pullToRefreshDone('.pull-to-refresh-content');
				}
				return;
			}
            if(page >=2 && !Docs){
				loadpageObj.attr('data-loadstate',3);
				ck8('#scroll-preloader_'+pageid).html(scrollPreloader[3]);
				if(type == 'refresh'){
					ck8.pullToRefreshDone('.pull-to-refresh-content');
				}
				return;
			}
            if(Docs){
				loadpageObj.attr('data-loadstate',1);
				ck8('#scroll-preloader_'+pageid).html(scrollPreloader[1]);
				if(type == 'refresh'){
					loadpageObj.find('.appendpage').html(Docs)
					ck8.pullToRefreshDone('.pull-to-refresh-content');
				}else{
					loadpageObj.find('.appendpage').append(Docs)
				}
            }
			if(page == 1){
				app.lazyLoad('',true)
			}
			app.lazyLoad()
			ck8.refreshScroller();
			if(Docs.indexOf('<div id="nolist"') != -1){
				loadpageObj.attr('data-scrollTopEnd',2);
				ck8('#scroll-preloader_'+pageid).hide();
			}
		},
		error: function(){
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

function initSwitchStyle(style){
	var hrefstyl = ck8('#stylefile').attr('href');
	if(hrefstyl){
		var url = hrefstyl.substring(0,hrefstyl.indexOf('guiigo-colour-'));
		url = url + 'guiigo-colour-' + style + '.css?' +hash('guiigocolour', 6);
		ck8('#stylefile').attr('href',url);
	}
	__imgAllReplace('nav',style)
	var menuJson =null;
	if(tab_menuJson){
		try{
			menuJson = JSON.parse(tab_menuJson);
		}catch(e){
			//TODO handle the exception
		}
	}
	if(ck8('.guiigo-lnav').length >0){
		var html = '';
		var myNewPm = parseInt(ck8('#setIntervalnewmsg').attr('data-setInterval'));
		clearInterval(myNewPm);
		if(menuJson && menuJson[style]){
			for (var i = 0; i < menuJson[style].length; i++) {
				var anv = menuJson[style][i];
				var url = anv.global_tab_menu_link;
				if(url.indexOf('{uid}') != -1){
					url = url.replace('{uid}',discuz_uid)
				}
				if(anv.global_tab_menu_deficon){
					anv.global_tab_menu_deficon = SITEURL+'source/plugin/guiigo_manage/navfile/'+anv.global_tab_menu_deficon;
				}
				if(anv.global_tab_menu_icon){
					anv.global_tab_menu_icon = SITEURL+'source/plugin/guiigo_manage/navfile/'+anv.global_tab_menu_icon;
				}
				html +='<a class="tab-item '+(anv.global_tab_menu_bulge ? 'add-action':'')+'" href="'+url+'" ';
				html += (anv.global_tab_menu_cache ? 'external':'')+' data-mark="'+anv.global_tab_menu_mark+'" ';
				html += 'data-sort="'+anv.global_tab_menu_sort+'">';
				html +='<span class="icon img1def"><img src="'+anv.global_tab_menu_deficon+'"></span>';
				html += '<span class="icon imgactivate"><img src="'+anv.global_tab_menu_icon+'"></span>';
				html += '<span class="tab-label colordef" style="color:'+anv.global_tab_menu_color+';">'+anv.global_tab_menu_name+'</span>';
				html += '<span class="tab-label colorctivate" style="color:'+anv.global_tab_menu_activate_color+';">'+anv.global_tab_menu_name+'</span>';
				if(anv.global_tab_menu_mark =='xx'){
					html +='<i class="guiigo-yjsz bg-j zy-a newmsg pmnewmsg" style="display:none;" data-setInterval="0"></i>';
				}
				if(anv.global_tab_menu_mark =='wd'){
					html +='<i class="guiigo-yjsz bg-j zy-a newmsg followermsg" style="display:none;"></i>';
				}
				html +='</a>';
			}
		ck8('.guiigo-lnav-min').html(html);
		getNewPm()
		}else{
			__imgAllReplace('#anvhide',style)
			ck8('.guiigo-lnav-min').html(ck8('#anvhide').html());
		}
		ck8('.guiigo-lnav-min').find('[data-mark=wd]').addClass('tab-item-activate');
	}
}

function __imgAllReplace(el,style){
	var navstyl = ck8(el).find('img');
	if(navstyl.length){
		for(var i=0; i < navstyl.length; i++){
			var imgurl = ck8(navstyl[i]).attr('src');
			var reg =/(images\/[^{]*\/)/g;
			imgurl = imgurl.replace(reg,'images/'+style+'/');
			imgurl = imgurl+'?'+hash('guiigocolour', 6);
			ck8(navstyl[i]).attr('src',imgurl);
		}
	}
}

function SwitchStyle(obj,style){
	ck8('#styleall').find('a').removeClass('on')
	if(obj){
		ck8.showPreloader('','load');
		ck8.ajax({
			type : 'GET',
			url : 'plugin.php?id=guiigo_manage:api&api=Style&act=setHomeStyle&op=tpl&style='+style,
			dataType : 'json',
			success: function(s){
				setTimeout(function(){ck8.hidePreloader()}, 100);
				if(typeof tplstyle != 'undefined'){
				    tplstyle =style;
				}
				if(s.code == 1){
					ck8(obj).addClass('on')
					ck8.toast(s.msg,'shibai');
					initSwitchStyle(style)
				}else{
		           ck8.toast(s.msg,'shibai');
				}
			},
			error: function(){
				ck8.hidePreloader();
				ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
			}
		})
	}else{
		var datastyle = ck8('#styleall').find('a');
		if(datastyle.length){
			for(var i=0; i < datastyle.length; i++){
				var ds = ck8(datastyle[i]).attr('data-style');
                if(ds == style){
					ck8(datastyle[i]).addClass('on')
					break;
				}
			}
		}
	}
}

function homeSwitchStyle(obj,homestyle){
	ck8.showPreloader('','load');
	ck8.ajax({
		type : 'GET',
		url : 'plugin.php?id=guiigo_manage:api&api=Style&act=setHomeStyle&style='+homestyle,
		dataType : 'json',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 100);
			if(s.code == 1){
				ck8.toast(s.msg,'shibai');
				ck8('#kjstyleall').find('a').removeClass('on')
				if(obj){
					ck8(obj).addClass('on')
				}else{
					var datastyle = ck8('#kjstyleall').find('a');
					if(datastyle.length){
						for(var i=0; i < datastyle.length; i++){
							var ds = ck8(datastyle[i]).attr('data-style');
				            if(ds == homestyle){
								ck8(datastyle[i]).addClass('on')
								break;
							}
						}
					}
				}
				ck8('.gg-kj-kjdb').attr('class','gg-kj-kjdb gg-kjbg-'+homestyle)
				ck8('.panel-yhxx').attr('class','panel-yhxx gg-kjbg-'+homestyle)
			}else {
	           ck8.toast(s.msg,'shibai');
			}
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

function copy(self,text){
	var msg = '\u94fe\u63a5\u5df2\u590d\u5236\u5230\u526a\u8d34\u677f';
	var u = window.location.href.replace('&mobile=2','');
	if(!text){
		cptext = u;
	}else{
		cptext = text;
	}
	var cptextid = ck8(self).attr('id')
	if(!cptext){
		ck8.toast('\u94fe\u63a5\u590d\u5236\u5931\u8d25');
		return;
	}
	app.loadScript('clipboard.min',function(){
		var clipboard = new Clipboard('#'+cptextid, {
			text: function (e) {
				setTimeout(function(){
					ck8.toast(msg);
				}, 600);
				return cptext;
			}
		})
	})
}

function getShareData(el,imgid,dos){
	if(!imgid){
		imgid = '.content';
	}
	var imgs = share_img;
	var picurl = ck8(imgid).find('img');
	var title = ck8(el).html();
	var link = window.location.href.replace('&mobile=2','');
	var dosc = '';
	if(dos){
		dosc = getFhareText(dos)
	}else{
		dosc = title ? title : share_title
	}
	for(var i=0; i < picurl.length; i++){
		if(picurl[i].naturalWidth > 80 || picurl[i].naturalHeight > 80){
		    imgs = picurl[i].src;
			break;
		}
	}
	return {
		title: title ? title : share_title,
		desc: dosc,
		link:link,
		imgUrl: imgs,
	};
}

function getFhareText(dos){
	var doss = ck8(dos);
	var s = doss.text();
	if(s){
		s = s.replace(/<[^>]+>/g,'');
		s = s.replace(/&nbsp;/ig,'');
		s = s.replace(/\ +/g,"");
		s = s.replace(/[\r\n]/g,"");
		return s.substring(0,150);
	}
}

function appShareAllview(titleId,imgAllId,dos){
	var config = getShareData(titleId,imgAllId,dos);
	ck8.postMessage({
		datatype: 'webShare',
		data:config
	})
}

function nativeShare(config) {
    var qApiSrc = {
        lower: "http://3gimg.qq.com/html5/js/qb.js",
        higher: "http://jsapi.qq.com/get?api=app.share"
    };
    var bLevel = {
        qq: {forbid: 0, lower: 1, higher: 2},
        uc: {forbid: 0, allow: 1}
    };
    var UA = navigator.appVersion;
    var isqqBrowser = (UA.split("MQQBrowser/").length > 1) ? bLevel.qq.higher : bLevel.qq.forbid;
    var isucBrowser = (UA.split("UCBrowser/").length > 1) ? bLevel.uc.allow : bLevel.uc.forbid;
    var version = {
        uc: "",
        qq: ""
    };
	
    var isWeixin = false;
    config = config || {};
    this.url = config.link || '';
    this.title = config.title || '';
    this.desc = this.title;
    this.img = config.imgUrl || '';
    this.img_title = config.title || document.title || '';
	this.from = this.title || '';
    this.ucAppList = {
        sinaWeibo: ['kSinaWeibo', 'SinaWeibo', 11, '{lang ck8_share:lang_002}'],
        weixin: ['kWeixin', 'WechatFriends', 1, '{lang ck8_share:lang_003}'],
        weixinFriend: ['kWeixinFriend', 'WechatTimeline', '8', '{lang ck8_share:lang_004}'],
        QQ: ['kQQ', 'QQ', '4', '{lang ck8_share:lang_005}'],
        QZone: ['kQZone', 'QZone', '3', '{lang ck8_share:lang_006}']
    };
    this.share = function (to_app) {
        var title = this.title, url = this.url, desc = this.desc, img = this.img, img_title = this.img_title, from = this.from;
        if (isucBrowser) {
            to_app = to_app == '' ? '' : (platform_os == 'iPhone' ? this.ucAppList[to_app][0] : this.ucAppList[to_app][1]);
            if (to_app == 'QZone') {
                B = "mqqapi://share/to_qzone?src_type=web&version=1&file_type=news&req_type=1&image_url="+img+"&title="+title+"&description="+desc+"&url="+url+"&app_name="+from;
                k = document.createElement("div"), k.style.visibility = "hidden", k.innerHTML = '<iframe src="' + B + '" scrolling="no" width="1" height="1"></iframe>', document.body.appendChild(k), setTimeout(function () {
                    k && k.parentNode && k.parentNode.removeChild(k)
                }, 5E3);
            }
            if (typeof(ucweb) != "undefined") {
                ucweb.startRequest("shell.page_share", [title, title, url, to_app, "", "@" + from, ""])
            } else {
                if (typeof(ucbrowser) != "undefined") {
                    ucbrowser.web_share(title, title, url, to_app, "", "@" + from, '')
                } else {
                }
            }
        } else {
            if (isqqBrowser && !isWeixin) {
                to_app = to_app == '' ? '' : this.ucAppList[to_app][2];
                var ah = {
                    url: url,
                    title: title,
                    description: desc,
                    img_url: img,
                    img_title: img_title,
                    to_app: to_app,
                    cus_txt: "\u8bf7\u8f93\u5165\u6b64\u65f6\u6b64\u523b\u60f3\u8981\u5206\u4eab\u7684\u5185\u5bb9"
                };
                ah = to_app == '' ? '' : ah;
                if (typeof(browser) != "undefined") {
                    if (typeof(browser.app) != "undefined" && isqqBrowser == bLevel.qq.higher) {
                        browser.app.share(ah)
                    }
                } else {
                    if (typeof(window.qb) != "undefined" && isqqBrowser == bLevel.qq.lower) {
                        window.qb.share(ah)
                    } else {
                    }
                }
            } else {
            }
        }
    };
    this.isloadqqApi = function () {
        if (isqqBrowser) {
            var b = (version.qq < 5.4) ? qApiSrc.lower : qApiSrc.higher;
            var d = document.createElement("script");
            var a = document.getElementsByTagName("body")[0];
            d.setAttribute("src", b);
            a.appendChild(d)
        }
    };
    this.getPlantform = function () {
        ua = navigator.userAgent;
        if ((ua.indexOf("iPhone") > -1 || ua.indexOf("iPod") > -1)) {
            return "iPhone"
        }
        return "Android"
    };
    this.is_weixin = function () {
        var a = UA.toLowerCase();
        if (a.match(/MicroMessenger/i) == "micromessenger") {
            return true;
        } else {
            return false;
        }
    };
    this.getVersion = function (c) {
        var a = c.split("."), b = parseFloat(a[0] + "." + a[1]);
        return b
    };
    this.init = function () {
        platform_os = this.getPlantform();
        version.qq = isqqBrowser ? this.getVersion(UA.split("MQQBrowser/")[1]) : 0;
        version.uc = isucBrowser ? this.getVersion(UA.split("UCBrowser/")[1]) : 0;
        isWeixin = this.is_weixin();
        if ((isqqBrowser && version.qq < 5.4 && platform_os == "iPhone") || (isqqBrowser && version.qq < 5.3 && platform_os == "Android")) {
            isqqBrowser = bLevel.qq.forbid
        } else {
            if (isqqBrowser && version.qq < 5.4 && platform_os == "Android") {
                isqqBrowser = bLevel.qq.lower
            } else {
                if (isucBrowser && ((version.uc < 10.2 && platform_os == "iPhone") || (version.uc < 9.7 && platform_os == "Android"))) {
                    isucBrowser = bLevel.uc.forbid
                }
            }
        }
        this.isloadqqApi();
        if (isqqBrowser || isucBrowser){}
    };
    this.init();
    var share = this;
    var items = document.getElementsByClassName('nativeShare');
    for (var i=0;i<items.length;i++) {
        items[i].onclick = function(){
            share.share(this.getAttribute('data-app'));
        }
    }
	return this;
}

function webShare(config){
	ck8('.weixin').on('click',function () {
		setTimeout(function(){
		    ck8.toast('\u8bf7\u5728\u0041\u0050\u0050\u6216\u5fae\u4fe1\u4e2d\u4f7f\u7528','shibai');
		}, 300);
	});
	ck8('.weixin_timeline').on('click',function () {
		setTimeout(function(){
		    ck8.toast('\u8bf7\u5728\u0041\u0050\u0050\u6216\u5fae\u4fe1\u4e2d\u4f7f\u7528','shibai');
		}, 300);
	});
	ck8('.qq').on('click',function () {
		var qqurl = 'http://connect.qq.com/widget/shareqq/index.html?url='+config.link+'&desc='+config.desc+'&summary=&title='+config.title+'&site=&pics='+config.imgUrl;
		window.location.href = qqurl;
	});
	ck8('.weibo').on('click',function () {
		var weibourl = 'http://service.weibo.com/share/share.php?url='+config.link+'&appkey=&title='+config.title+'&pic='+config.imgUrl+'&language=zh_cn';
		window.location.href = weibourl;
	});
	ck8('.qzone').on('click',function () {
		var qzoneurl = 'http://openmobile.qq.com/api/check2?page=qzshare.html&loginpage=loginindex.html&logintype=qzone&url='+config.link+'&summary='+config.title+'&desc='+config.desc+'&title='+config.title+'&imageUrl='+config.imgUrl+'&successUrl=&failUrl=&callbackUrl=&sid=';
		window.location.href = qzoneurl;
	});
}

function wxshareJssdkAjax(config){
	config.link = location.href.split('#')[0];
	app.loadScript('jweixin-1.4.0',function(){
		ck8.ajax({
			url:'plugin.php?id=guiigo_manage:api&api=wxshare&act=getwxshare&url='+ encodeURIComponent(config.link),
			dataType: "json",
			type: "GET",
			success:function(e){
				if(e.code == 1){
					wx.config({
						debug:false,
						appId:e.data.appid,
						timestamp:e.data.timestamp,
						nonceStr:e.data.nonceStr,
						signature:e.data.signature,
						jsApiList:[
							'onMenuShareTimeline',
							'onMenuShareAppMessage',
							'onMenuShareQQ',
							'onMenuShareWeibo',
							'onMenuShareQZone',
							'getLocation',
							'openLocation'
						]
					});
					wx.ready(function(){
						wx.onMenuShareAppMessage(config);
						wx.onMenuShareQQ(config);
						wx.onMenuShareWeibo(config);
						wx.onMenuShareQZone(config);
						wx.onMenuShareTimeline(config);
					});
					ck8('.nativeShare').on('click',function(){
						ck8('.share-layer').show();
					})
					ck8('.share-layer').on('click',function(){
						ck8('.share-layer').hide();
					})
				}else{
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			}
		})
	})
}

function getData(){
	var title = '';
	if(ck8('#share_title')){
		title = ck8('#share_title').html();
	}
	var link = window.location.href.replace('&mobile=2','');
	return {
		title: title ? title : share_title,
		link:link,
	};
}

function miniProgramwxJssdk(){
	var FXCONFIG = getData();
	var aus = window.navigator.userAgent.toLowerCase();
	if(aus.match(/MicroMessenger/i) == 'micromessenger'){
		app.loadScript('jweixin-1.4.0',function(){
			wx.miniProgram.getEnv(function(res){
				if (res.miniprogram) {
					wx.miniProgram.postMessage({
						 data: FXCONFIG,
					 });
					if(ck8('#miniProgramlogin')){
						ck8('#miniProgramlogin').on('click',function () {
							wx.miniProgram.navigateTo({url: '/pages/login/login'});
						});
					}
				}
			})
		})
	}
}

function setClass(int){
	var styleclass = ck8('.styleclass');
	var stylefont = localStorage.getItem('stylefont');
	if(int && stylefont){
		ck8('html').addClass(stylefont);
	}else{
		if(styleclass.length > 0){
			ck8('html').removeClass('styleclass');
			ck8('.btfont').html('&#22823;&#21495;&#23383;&#20307;');
			localStorage.removeItem('stylefont');
		}else{
			ck8('html').addClass('styleclass');
			ck8('.btfont').html('&#40664;&#35748;&#23383;&#20307;');
			localStorage.setItem('stylefont','styleclass');
		}
	}
}

function titleshow(hdoc,h,hide,show){
	if (hdoc > h){
		ck8(hide).hide()
		ck8(show).show()
	}else{
		ck8(show).hide()
		ck8(hide).show()
	}
}

function getNewPm(){
	if(ck8('#setIntervalnewmsg').length ==0){
		var divE = document.createElement('div');
		divE.id = "setIntervalnewmsg";
		var divdata = document.createAttribute("data-setInterval");
		divdata.value = 0;
		divE.setAttributeNode(divdata);
		var bo = document.body;
		bo.insertBefore(divE, bo.lastChild);
	}else{
		var myNewPm = parseInt(ck8('#setIntervalnewmsg').attr('data-setInterval'));
		if(myNewPm>0){
			clearInterval(myNewPm);
		}
	}
	if(ck8('nav').length>0 || ck8('.guiigo-lnav').length>0){
		_getNewPm()
		var NewPm = setInterval(function(){
			_getNewPm()
		},10000);
		ck8('#setIntervalnewmsg').attr('data-setInterval',NewPm);
	}
}

function _getNewPm(){
	var myNewPm = parseInt(ck8('#setIntervalnewmsg').attr('data-setInterval'));
	if(ck8('.pmnewmsg').length==0 && myNewPm>0){
		clearInterval(myNewPm);
		return;
	}
	if(ck8('.guiigo-lnav').length>0 && ck8('.guiigo-lnav').css('display') == 'none' && myNewPm>0){
		clearInterval(myNewPm);
		return;
	}
	ck8.ajax({
		type : 'GET',
		url : 'plugin.php?id=guiigo_manage:api&api=newpm&act=getnewpm',
		dataType : 'json',
		success: function(s){
			if(s.code == 1){
				if(s.data && s.data.newmsg>0){
					ck8('.pmnewmsg').show().html(s.data.newmsg);
				}else{
					ck8('.pmnewmsg').hide().html(s.data.newmsg);
				}
				if(s.data && s.data.follower>0){
					ck8('.followermsg').show().html(s.data.follower);
				}else{
					ck8('.followermsg').hide().html(s.data.follower);
				}
			}else {
			   clearInterval(myNewPm);
			   ck8('.pmnewmsg').hide()
			   ck8('.followermsg').hide()
			}
		},
		error: function(){
			clearInterval(myNewPm);
		}
	})
}

function openShowMn(uri){
	var PageC = null;
	if(ISALLTPL>0 || !ck8.isApp()){
	   ck8.router.load(uri);
	   return;
	}
	if(uri.indexOf('forum.php?forumlist=1') !=-1){
	   PageC = 'forum';
	}else if(uri == "group.php?mod=index"){
	   PageC = 'group';
	}else if(uri == "home.php?mod=space&do=pm&filter=privatepm"){
	   PageC = 'newmsg';
	   if(discuz_uid <=0){
		   ck8.confirm('\u4f60\u5c1a\u672a\u767b\u5f55\uff0c\u8bf7\u5148\u767b\u5f55', '\u767b\u5f55\u63d0\u793a',
		   	function (){
				var url = encodeURIComponent(window.location.href.replace('#',''));
				app.close_popup();
		   	    ck8.redirectTo('/pages/login/login?weblastUrl='+url)
		   	},
		   	function (){}
		   )
		   return;
	   }
	}else if(uri.indexOf('plugin.php?id=guiigo_manage') !=-1){
	   PageC = 'portal';
	}
	if(PageC){
		ck8.postMessage({
			datatype:'h5Back',
			page:PageC
		});
	}else{
       ck8.router.load(uri);
	}
}

function showMn(el){
	var Obj = ck8('.guiigo-barcd-s')
	if(el){
		Obj = ck8(el)
	}
	if(Obj.css('display') == 'none'){
		Obj._show(200)
		if(el){
			ck8('#pm_uls').show()
		}
	}else{
		Obj.hide()
		if(el){
			ck8('#pm_uls').hide()
		}
	}
}

var delRecommenus = {
	init:function() {
		ck8(document).off('click', '.delRecommenus').on('click', '.delRecommenus', function(e) {
			e.preventDefault();
			if(getcookie('delrecommend')){
				ck8.toast('&#35831;&#31245;&#21518;&#46;&#46;&#46;');
				return;
			}
			var _this = this;
			ck8.showPreloader('','load');
			ck8.ajax({
				type : 'GET',
				url : ck8(_this).attr('href'),
				dataType : 'json',
				success: function(res){
					setTimeout(function(){ck8.hidePreloader()},100);
                    if(res && res.code == 1){
						if(ck8(_this).attr('data-op') =='viewthread' && res.data){
							res.data.pid = ck8(_this).attr('data-pid') || 0;
							viewthreadRecommenus(res)
						}else{
							var r = res.data;
							var foObj = ck8('#recommend_add_'+r.tid);
							foObj.addClass('zy-c bg-l').removeClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzan"></i>');
							ck8('#recommend_add_sum'+r.tid).html((parseInt(r.recommendc) + parseInt(r.recommendv)));
							foObj.find('a').addClass('dialog').removeClass('delRecommenus').attr('href',r.url);
							ck8.toast(res.msg);
						}
					}else if(res && res.msg){
						ck8.toast(res.msg);
					}
				},
				error: function(){
					ck8.hidePreloader();
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			})
		}),
		ck8(document).off('click', '.delhotreply').on('click', '.delhotreply', function(e) {
			e.preventDefault();
			if(getcookie('delhotreply')){
				ck8.toast('&#35831;&#31245;&#21518;&#46;&#46;&#46;');
				return;
			}
			var _this = this;
			ck8.showPreloader('','load');
			ck8.ajax({
				type : 'GET',
				url : ck8(_this).attr('href'),
				dataType : 'json',
				success: function(res){
					setTimeout(function(){ck8.hidePreloader()},100);
		            if(res && res.code == 1){
						ck8.toast(res.msg);
						res = res.data;
						var foObj = ck8('#recommendv_add_'+ res.pid);
						if(res.support==0){
							foObj.hide().html(0)
						}else{
							foObj.html(res.support)
						}
						foObj.prev().removeClass('zy-i guiigoapp-dianzanon').addClass('guiigoapp-dianzan')
						foObj.parent().removeClass('delhotreply').addClass('dialog').attr('href',res.url);
					}else if(res && res.msg){
						ck8.toast(res.msg);
					}
				},
				error: function(){
					ck8.hidePreloader();
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			})
		})
	}
}

function viewthreadRecommenus(res){
	var par = res.data;
	ck8.toast(res.msg);
	var foObj = ck8('#recommendv_add_'+ par.pid);
    var reconut = parseInt(par.recommendc) + parseInt(par.recommendv);
	if(reconut == 0){
		foObj.hide().html(reconut);
	}else{
		foObj.html(reconut)
	}
	ck8('#recommendv_add_lz'+ par.pid +'').html(reconut)
	foObj.prev().removeClass('guiigoapp-nydbdzon zy-i').addClass('guiigoapp-nydbdz zy-e');
	foObj.parent().removeClass('delRecommenus').addClass('dialog').attr('href',par.url);
	if(par.pid){
		if(ck8('#recommendv_add_lz_a_'+ par.pid +'').length>0 && reconut == 0){
			ck8('#recommendv_add_lz_a_'+ par.pid +'').removeClass('ab-b delRecommenus').addClass('ab-az zy-ac dialog').attr('href',par.url);
			ck8('#delrecommenlist_'+ par.pid +'').html('')
		}else{
			var url = 'forum.php?mod=viewthread&tid='+par.tid+'&viewpid='+ par.pid +'&inajax=1';
			app.PageRefresh('','#post_topo_'+ par.pid,url);
		}
	}
}

function addViewthreadViewpid(tid,pid,callback){
	ck8.ajax({
		type:'GET',
		url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid +'&inajax=1',
		dataType:'xml',
		success: function(s){
			if(typeof(callback) == 'function'){
				callback(s)
			}else{
				ck8('.list-container-none').remove();
				ck8('.list-container-s').after(app.initAtr(s.lastChild.firstChild.nodeValue))
				app.lazyLoad()
				var plsl = parseInt(ck8('.plsl').html());
				if(!plsl) plsl = 0;
				ck8('.plsl').html(plsl + 1)
				if(ck8('#pid'+pid).length){
					app.scrollToEnd('#pid'+pid)
				}
			}
		}
	})
}

function appTplinit(e){
	if(ck8.isApp()){
		if(!window.plus){
			ck8.SdkPlusReady(function(){
				ck8.plusReady(function(){
				   __appTplinit(e)
				})
			})
		}else{
			__appTplinit(e)
		}
	}
}

function __appTplinit(e){
	var mod = e.attr('data-mod');
	var isimmersed = ck8.isimmersedStatusbar();
	var lh = ck8.getStatusbarHeight();
	if(lh>5 && isimmersed){
		var barObj = e.find('.bar-nav'),
			cusbar = e.find('.app-top'),
			appHeader = ck8('.app-header'),
			barh = 0,
			appTop = null;
		if(barObj.length>0 && !barObj.attr('data-top-lock')){
			barh = barObj.height();
			styleadd(lh,function(val){
				barObj.css({height:(barh+val)+'px',paddingTop:val+'px'});
				if(mod == 'group-list' || mod == 'space-profile' || mod == 'trade-info'){
					return;
				}
			})
			if(e.find('.content').hasClass('pull-to-refresh-content')){
				e.find('.content').css({top:lh+'px !important'});
			}else{
				if(mod == 'group-list' || mod == 'space-profile'){
					if(e.find('.guiigo-barcd')){
						e.find('.guiigo-barcd').css({top:(barh+lh)+'px'});
					}
					if(e.find('.kjdb-txzl')){
						e.find('.kjdb-txzl').css({paddingTop:lh+'px'});
					}
					e.find('.content').css({top:0+'px'});
				}else{
					e.find('.content').css({top:(barh+lh)+'px'});
				}
			}
			e.find('.ztsx_sxbt').css({height:(barh+lh)+'px',paddingTop:lh+'px'});
			e.find('.kjdb-txzl').css({paddingTop:lh+'px'});
			barObj.attr('data-top-lock','true');
		}
		if(cusbar.length>0 && !cusbar.attr('data-top-lock')){
			if(e.find('.guiigo-barcd')){
				e.find('.guiigo-barcd').css({top:(barh+lh)+'px'});
			}
			cusbar.css({height:(cusbar.height()+lh)+'px',paddingTop:lh+'px'});
			cusbar.attr('data-top-lock','true');
		}
		if(appHeader.length>0 && !appHeader.attr('data-top-lock')){
			var ah = appHeader.height()
			if(ah<=0){
				ah = 50;
			}
			appHeader.css({height:(ah+lh)+'px',paddingTop:lh+'px'});
			appHeader.next().css({paddingTop:lh+'px'});
			appHeader.attr('data-top-lock','true');
		}
	}
}

function styleadd(val,callback){
	var timer = null;
	var cm = val,rcm = 0;
	timer = window.setInterval(function() {
		if(cm <=0 || !cm){
			window.clearInterval(timer);
		}else{
			callback(rcm)
			cm--;
			rcm++;
		}
	},10);
}

function insertText2focus(obj, str) {
	if (document.selection) {
		var sel = document.selection.createRange();
		sel.text = str;
	} else if (typeof obj.selectionStart === 'number' && typeof obj.selectionEnd === 'number') {
		var startPos = obj.selectionStart,
			endPos = obj.selectionEnd,
			cursorPos = startPos,
			tmpStr = obj.value;
		obj.value = tmpStr.substring(0, startPos) + str + tmpStr.substring(endPos, tmpStr.length);
		cursorPos += str.length;
		obj.selectionStart = obj.selectionEnd = cursorPos;
	} else {
		obj.value += str;
	}
	TextMoveEnd(obj)
}

function TextMoveEnd(obj) {
	obj.focus();
	var len = obj.value.length;
	if (document.selection) {
		var sel = obj.createTextRange();
		sel.moveStart('character', len);
		sel.collapse();
		sel.select();
	} else if (typeof obj.selectionStart == 'number' && typeof obj.selectionEnd == 'number') {
		obj.selectionStart = obj.selectionEnd = len;
	}
}

function initSelect(dom){
	if(!dom) dom = document;
	loadAudio('select',function(){
		ck8(dom).find('.select-picker').each(function(){
			var _this = this;
			var selectId = ck8(this).attr('data-select')
			if(selectId){
				var selectArr = ck8('#'+ selectId).find('option')
				var colsObj = {
						textAlign: 'center',
						values:[],
						displayValues:[],
						selectedval:0
					};
				if(selectArr.length > 0 && selectArr.selector){
					for (var i = 0; i < selectArr.selector.length; i++) {
						colsObj.values.push(selectArr.selector[i].value);
						colsObj.displayValues.push(selectArr.selector[i].text);
						if(selectArr.selector[i].selected == true){
							ck8(_this).val(selectArr.selector[i].text);
							colsObj.selectedval = selectArr.selector[i].value;
						}
					}
				}
				ck8(_this).picker({
					toolbarTemplate: '<header class="bar bar-nav">\
					<button class="button button-link pull-right close-picker">\u786e\u5b9a</button>\
					<h1 class="title">\u8bf7\u9009\u62e9</h1>\
					</header>',
					cols:[colsObj],
					onOpen:function(e){
						e.setValue([colsObj.selectedval])
					},
					formatValue:function(picker, value, displayValue){
						if(ck8('#audio-select').length>0){
							ck8('#audio-select')[0].play();
						}
						colsObj.selectedval = value.join('');
						ck8('#'+ selectId).val(value.join(''));
						return displayValue.join(' ');
					}
				})
			}
		})
	});
}

function tabnavMusic(){
	var tabnavmusic = ck8('.tabnavmusic');
	if(tabnavmusic.length ==0){
		return;
	}
	var music = tabnavmusic.attr('data-music');
	loadAudio(music,function(){
		tabnavmusic.off('click', 'a').on('click', 'a', function(e) {
			ck8('#audio-'+music)[0].play();
		})
	})
}

function tabnavshow(Dom){
	var activate = getUrlParams('navactivate');
	var guiigoLnav = ck8('.guiigo-lnav');
	if(guiigoLnav.length==0){
		return;
	}
	var mod = Dom.attr('data-mod');
	if(activate || mod=='space-profile-my' || mod=='discuz' || mod=='index' || mod=='group' || mod=='space_pm'){
		guiigoLnav.show();
		ck8('.page-group').addClass('tab-margin-activate');
		switch (mod) {
			case 'space-profile-my':
			    activate ='wd';
		        break;
		    case 'discuz': 
			    activate ='sq';
                break;
			case 'index':
			    activate ='sy';
			    break;
			case 'group': 
			    activate ='qz';
			    break;
			case 'space_pm': 
			    activate ='xx';
		}
		guiigoLnav.find('.tab-item-activate').removeClass('tab-item-activate')
		if(guiigoLnav.find('[data-mark='+activate+']').length>0){
			guiigoLnav.find('[data-mark='+activate+']').addClass('tab-item-activate')
		}
	}else{
		guiigoLnav.hide();
		ck8('.page-group').removeClass('tab-margin-activate');
	}
	if(!guiigoLnav.attr('data-lock')){
		guiigoLnav.off('click', '.tab-item').on('click', '.tab-item', function(e) {
			if(!ck8(this).hasClass('login')){
				guiigoLnav.find('.tab-item').each(function(e,dom){
					if(ck8(dom).hasClass('tab-item-activate')){
						ck8(dom).removeClass('tab-item-activate')
					}
				})
				ck8(this).addClass('tab-item-activate')
			}
		})
		guiigoLnav.attr('data-lock',true)
	}
}

function getUrlParams(objName) {
    var data = window.location.href;
    if(data.indexOf("?")<0) return false;//判断是否存在参数
    var allParamsArr = data.split("?")[1].split("&"), returnObj = {};
    if(allParamsArr.length==0) return false; //参数是否带惨，狗屁的有的人无聊带问号不带参数的
    for(var i =0; i<allParamsArr.length; i++) {
        returnObj[`${allParamsArr[i].split("=")[0]}`] = allParamsArr[i].split("=")[1];
    }
    return returnObj[`${objName}`];
}


function extraCheck(op) {
	if(!op && Dz('extra_replycredit_chk')) {
		Dz('extra_replycredit_chk').className = Dz('replycredit_extcredits').value > 0 && Dz('replycredit_times').value > 0 ? 'a' : '';
	} else if(op == 1 && Dz('readperm')) {
		Dz('extra_readperm_chk').className = Dz('readperm').value !== '' ? 'a' : '';
	} else if(op == 2 && Dz('price')) {
		Dz('extra_price_chk').className = Dz('price').value > 0 ? 'a' : '';
	} else if(op == 3 && Dz('rushreply')) {
		Dz('extra_rushreplyset_chk').className = Dz('rushreply').checked ? 'a' : '';
	} else if(op == 4 && Dz('tags')) {
		Dz('extra_tag_chk').className = Dz('tags').value !== '' ? 'a' : '';
	} else if(op == 5 && Dz('cronpublish')) {
		Dz('extra_pubdate_chk').className = Dz('cronpublish').checked ? 'a' : '';
	}
}

function getreplycredit() {
	var replycredit_extcredits = Dz('replycredit_extcredits');
	var replycredit_times = Dz('replycredit_times');
	var credit_once = parseInt(replycredit_extcredits.value) > 0 ? parseInt(replycredit_extcredits.value) : 0;
	var times = parseInt(replycredit_times.value) > 0 ? parseInt(replycredit_times.value) : 0;
	if(parseInt(credit_once * times) - have_replycredit > 0) {
		var real_reply_credit = Math.ceil(parseInt(credit_once * times) - have_replycredit + ((parseInt(credit_once * times) - have_replycredit) * creditstax));
	} else {
		var real_reply_credit = Math.ceil(parseInt(credit_once * times) - have_replycredit);
	}

	var reply_credits_sum = Math.ceil(parseInt(credit_once * times));

	if(real_reply_credit > userextcredit) {
		Dz('replycredit').innerHTML = '<em class="zy-i">\u56de\u5e16\u5956\u52b1\u79ef\u5206\u603b\u989d\u8fc7\u5927('+real_reply_credit+')</em>';
	} else {
		if(have_replycredit > 0 && real_reply_credit < 0) {
			Dz('replycredit').innerHTML = "<em class='zy-i'>\u8fd4\u8fd8"+Math.abs(real_reply_credit)+"</em>";
		} else {
			Dz('replycredit').innerHTML = replycredit_result_lang + (real_reply_credit > 0 ? real_reply_credit : 0 );
		}
		Dz('replycredit_sum').innerHTML = reply_credits_sum > 0 ? reply_credits_sum : 0 ;
	}
}

var initcommon = function(Dom){
	if(ck8('div.pg').length > 0){
		defPage.converthtml();
	}
	tabnavshow(Dom);
	initSelect(Dom);
	appTplinit(Dom);
	tabnavMusic();
    login.init();
    pageScrollTop.init();
	dialog.init();
	delRecommenus.init();
	formdialog.init();
	miniProgramwxJssdk();
	getNewPm();
}

