<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="gg-ss-amjg">
	<div class="gg-ss-jgbt xh-b zy-g"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
	<!--{if empty($bloglist)}-->
		<div class="guiigo-wnrtx">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
			<p class="zy-c">{lang guiigo_manage:tlang0882}</p>
		</div>
	<!--{else}-->
		<div class="gg-kj-rzlb list-block-no">
			<ul class="list-container">
			<!--{loop $bloglist $blog}-->
			<!--{eval $pic = DB::result_first("SELECT pic FROM %t WHERE blogid=%d", array('home_blogfield',$blog['blogid']));}-->
			<!--{eval $blog[pic] = pic_cover_get($pic,$blog['picflag']);}-->
				<li class="xh-b">
					<!--{if $blog[pic]}--><div class="twlbm-img"><a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"><img lazysrc="$blog[pic]" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"></a></div><!--{/if}-->
					<div class="twlbm-nr<!--{if !$blog[pic]}--> twlbm-wtnr<!--{/if}-->">
						<!--{eval $stickflag = isset($blog['stickflag']) ? 0 : 1;}-->
						<h2><!--{if !$stickflag}--><i class="icon guiigoapp-zhiding zy-a bg-d"></i><!--{/if}--><a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"{if $blog[magiccolor]} style="color: {$_G[colorarray][$blog[magiccolor]]}"{/if} class="zy-e">$blog[subject]</a></h2>
						<p><span class="twlbm-nr-hf"><a href="home.php?mod=space&uid=$blog[uid]&do=profile" class="zy-c"><!--{avatar($blog[uid],small)}-->$blog[username]</a></span><span class="twlbm-nr-sj zy-c">$blog[dateline]</span></p>
					</div>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}-->
		<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
			<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
		</div>
	<!--{/if}-->
</div>