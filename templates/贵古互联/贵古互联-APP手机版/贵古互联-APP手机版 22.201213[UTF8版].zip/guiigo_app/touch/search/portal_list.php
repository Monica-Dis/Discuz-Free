<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="gg-ss-amjg">
	<div class="gg-ss-jgbt xh-b zy-g">
		<!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}-->
	</div>
	<!--{if empty($articlelist)}-->
		<div class="guiigo-wnrtx">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
			<p class="zy-c">{lang guiigo_manage:tlang0882}</p>
		</div>
	<!--{else}-->
		<div class="gg-zx-zxls list-block-no bg-c">
			<ul class="list-container">
			<!--{loop $articlelist $article}-->
				<!--{eval $resdata = GuiigoApp::get_Portal_pic($article['aid']);}-->
				<!--{eval $piccount = count($resdata);}-->
				<li class="xh-b">
					<a href="{echo fetch_article_url($article);}">
							<!--{if $piccount == 2 || $piccount == 1}-->
									<div class="zxls-pico">
									<!--{if $resdata[0]['attachment']}-->
									<img src="{$resdata[0]['attachment']}">
									<!--{/if}-->
									</div>
									<!--{/if}-->
						<h2 class="zy-e<!--{if $piccount == 2 || $piccount == 1}--> zxbx-bttd<!--{else}--> zxbx-btte<!--{/if}-->" $highlight>$article[title]</h2>
						<!--{if $piccount >= 3}-->
							<div class="zxls-tico list-block-no">
								<ul>
									<!--{loop $resdata $vkey $vpic}-->
										<li><img src="{$vpic['attachment']}" />
										<!--{if $vkey == 2}-->
										<!--{eval break;}-->
										<!--{/if}-->
										</li>
									<!--{/loop}-->
								</ul>
							</div>
						<!--{/if}-->
						<p class="zy-c<!--{if !$article[pic]}--> zxbx-ysjd<!--{/if}-->"><i class="zy-c"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($article[viewnum])}--><!--{else}-->$article[viewnum]<!--{/if}-->{lang guiigo_manage:tlang0381}</i>$article[dateline]</p>
					</a>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}-->
	<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
		<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
	</div>
	<!--{/if}-->
</div>