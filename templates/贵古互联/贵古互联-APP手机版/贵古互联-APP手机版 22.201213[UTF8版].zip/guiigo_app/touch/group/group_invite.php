<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="page page-current" data-mod="group-invite">
	<header class="bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0413}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<div class="bm" id="main_messaqge">
				<form method="post" autocomplete="off" name="groupform" id="groupform" class="s_clear" action="forum.php?mod=group&action=invite">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="fid" value="$_G[fid]" />
					<input type="hidden" name="referer" value="{echo dreferer()}" />
					<!--{loop $friendarray $uid $member}-->
						<input type="checkbox" name="inviteuid[]" value="$uid">$member[username] $member[avatar]
					<!--{/loop}-->
					<table cellspacing="0" cellpadding="0" class="tfm" summary="{lang group_join_type_invite}">
						<caption>{lang group_choose_friend_to_invite}</caption>
						<tbody>
							<tr>
								<th>{lang group_invite_list}</th>
								<td><textarea rows="4" cols="40" name="invitemsg" class="pt"></textarea></td>
							</tr>
							<tr>
								<th>&nbsp;</th>
								<td><button class="pn pnc" type="submit" name="invitesubmit" value="true" tabindex="1"><strong>{lang finished}</strong></button></td>
							</tr>
						</tbody>
					</table>
				</form>
			</div>
		</div>
	</div>
</div>