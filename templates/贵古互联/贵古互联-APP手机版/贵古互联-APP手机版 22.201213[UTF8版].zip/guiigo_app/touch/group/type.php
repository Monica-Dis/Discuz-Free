<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="type">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0481}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-qz-qbss">
				<div class="gg-qz-qzss">
					<a href="javascript:;" onclick="ck8('.gg-qz-qzss').hide();ck8('.gg-qz-qzsc').show();ck8('#scform_srchtxt').focus()" class="bg-c zy-c"><i class="icon guiigoapp-sousuo"></i>{lang guiigo_manage:tlang0482}</a>
				</div>
				<div class="gg-qz-qzsc" style="display:none;">
					<form class="searchform" method="post" autocomplete="off" action="search.php?mod=group">
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="hidden" name="srchfid" value="$srchfid" />
						<input type="hidden" name="searchsubmit" value="yes" />
						<ul class="guiigo-flex">
							<input type="search" id="scform_srchtxt" name="srchtxt" class="qzsc-sssr bg-c zy-c" placeholder="{lang guiigo_manage:tlang0483}"/>
							<a href="javascript:;" onclick="ck8('.gg-qz-qzsc').hide();ck8('.gg-qz-qzss').show()"><i class="icon guiigoapp-guanbix zy-g"></i></a>
							<button type="submit" id="scform_submit" class="qzsc-ssqr ab-az zy-a zy-ac">{lang search}</button>
						</ul>
					</form>
				</div>
			</div>
			<div class="row no-gutter tab-bbs">
				<div class="col-25 gg-sq-tazc bg-e" style="height: calc(86vh);">
					<!--{eval $qunzudh = DB::fetch_all("SELECT * FROM ".DB::table('forum_forum')." WHERE `type`= 'group' AND status = '3' ORDER BY `displayorder` ASC");}-->
					<!--{loop $qunzudh $htfq}-->
					<a href="javascript:;" onclick="app.PageRefresh(false,'tab-bbs','group.php?gid=$htfq[fid]');" class="item-inner qbqz-link{if $_GET['gid'] == $htfq[fid]} active{/if}">$htfq[name]<span class="bg-b"></span></a>
					<!--{/loop}-->
				</div>
				<div class="col-75 tabs gg-sq-tayc bg-c type-scroll" style="height: calc(86vh);"
				data-url="$url&orderby=$orderby" 
				data-pages="{$getcount}" 
				data-ppp="{$perpage}" 
				data-page="$page" 
				data-islod="false" 
				data-distance="20"
				>
					<div id="tab_sc" class="tab active gg-sq-wdbk list-block-no">
						<!--{if $list}-->
						<ul class="list-container">
							<!--{loop $list $fid $val}-->
							<!--{if $_G['uid']}-->
							<!--{eval $groupuser = DB::fetch_first('select level,joindateline from %t where uid=%d AND fid=%d ', array('forum_groupuser', $_G['uid'],$fid));}-->
							<!--{/if}-->
							<li class="xh-a">
							<!--{if $groupuser['level'] == 0 && $groupuser['joindateline']}-->
								<span style="padding:0;"><a href="forum.php?mod=group&action=join&fid=$fid&hash={FORMHASH}" class="dialog bg-i zy-a"
                                ck-cus="true" 
								ck-param="{type:'modal',callpar:{refid:'refid$fid'},fn:'MsgCallType',load:'true',uid: '$_G[uid]'}" 
								external ><i class="icon guiigoapp-bkscj"></i></a></span>
							<!--{elseif $groupuser['level'] >= 1}-->
								<span style="padding:0;"><a href="forum.php?mod=group&action=join&fid=$fid&hash={FORMHASH}" class="dialog bg-i zy-a"
                                ck-cus="true" 
								ck-param="{type:'modal',callpar:{refid:'refid$fid'},fn:'MsgCallType',load:'true',uid: '$_G[uid]'}" 
								external ><i class="icon guiigoapp-bkscj"></i></a></span>
							<!--{else}-->
								<span style="padding:0;"><a href="forum.php?mod=group&action=join&fid=$fid&hash={FORMHASH}" class="dialog bg-h zy-a zy-ac"
                                ck-cus="true" 
								id="refid$fid"
								ck-param="{type:'modal',callpar:{refid:'refid$fid'},fn:'MsgCallType',load:'true',uid: '$_G[uid]'}" 
								external ><i class="icon guiigoapp-bkscj"></i></a></span>
							<!--{/if}-->
								<div class="bkys-bkico">
									<a href="forum.php?mod=forumdisplay&action=list&fid=$fid"><img src="$val[icon]" alt="$val[name]" /></a>
								</div>
								<a href="forum.php?mod=forumdisplay&action=list&fid=$fid" class="bkys-bkmc zy-e"><!--{echo cutstr($val[name],20)}--></a>
								<p class="zy-g">{lang guiigo_manage:tlang0490}: $val[membernum]&nbsp;&nbsp;{lang guiigo_manage:tlang0417}: $val[threads]</p>
							</li>
							<!--{/loop}-->
						</ul>
						<!--{else}-->
							<div class="guiigo-wnrtx">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
								<p class="zy-c">{lang guiigo_manage:tlang0491}</p>
								<a href="<!--{if $_G[uid]}-->forum.php?mod=group&action=create<!--{else}-->javascript:;<!--{/if}-->" class="ab-az zy-a zy-ac<!--{if !$_G[uid]}--> login<!--{/if}-->">{lang guiigo_manage:tlang0478}</a>
							</div>
						<!--{/if}-->
					</div>
					<!--{if $list}-->
					<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
						<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
					</div>
					<div onclick="infinite()" class="loadpage bg-e bk-e zy-c">{lang guiigo_manage:tlang0492}<i class="icon guiigoapp-ssxx zy-c"></i></div>
					<!--{/if}-->
				</div>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	function MsgCallType(msg,par,param) {
		if(typeof msg === 'object' || typeof par === 'object'){
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0489}') != -1){
			ck8('#'+param.refid).removeClass('bg-h').addClass('bg-i')
			$.toast(msg.msg);
			}else {
				$.toast(msg.msg);
			}
		}else{
			$.toast('{lang guiigo_manage:tlang0056}');
		}
	}
	</script>
</div>
<!--{template common/footer}-->