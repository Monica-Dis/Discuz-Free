<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['forum_threadlist']=GuiigoApp::GetPostlist($_G['forum_threadlist']);}-->
<div class="page page-current" data-mod="group-list">
	<div class="content infinite-scroll grouplist-scroll">
		<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-kbhddb"
		ck-cus="true" 
		ck-param="{ftcolo:{sta:'#ffffff',end:'#666666',class:['title','guiigoapp-xzfh','guiigoapp-mkbtgd','guiigoapp-caidan','guiigoapp-fabu']},rollt:'50',ori:'false',type:1}">
			<!--{if $guiigo_config['isguiigoapp']}-->
			<a class="button button-link pull-left app-back guiigo-kjfh zy-a"><i class="icon guiigoapp-xzfh"></i></a>
			<!--{else}-->
			<a class="button button-link pull-left open-panel guiigo-kjfh zy-a anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan"></i></a>
			<a class="button button-link pull-left back guiigo-kjfh zy-a anvbks"><i class="icon guiigoapp-xzfh"></i></a>
			<!--{/if}-->
			<!--{if helper_access::check_module('group')}-->
				<!--{if $status == 'isgroupuser'}-->
					<a href="javascript:;" class="button button-link pull-right zy-a" onclick="app.ActionsManage('#guiigo-bkfbx','t', 'auto');"><i class="icon guiigoapp-fabu"></i></a>
				<!--{/if}-->
			<!--{/if}-->
			<a href="javascript:;" class="button button-link pull-right zy-a" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd"></i></a>
			<h1 class="title">{lang guiigo_manage:tlang0079}</h1>
		</header>
		<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
			<div class="popup-actions" id="guiigo-bkfbx">
				<div class="actions-text guiigo-hdfx gg-sq-fbsx">
					<div class="hdfx-hdxm bg-c">
						<!--{if !$_G['forum']['allowspecialonly']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="zy-f" data-no-cache="true"><span style="background:#3ebbfd;"><i class="icon guiigoapp-huati zy-a"></i></span>{lang guiigo_manage:tlang0123}</a><!--{/if}-->
						<!--{if $_G['group']['allowpostpoll']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1" class="zy-f" data-no-cache="true"><span style="background:#ff9900;"><i class="icon guiigoapp-toupiao zy-a"></i></span>{lang guiigo_manage:tlang0124}</a><!--{/if}-->
						<!--{if $_G['group']['allowpostreward']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3" class="zy-f" data-no-cache="true"><span style="background:#9dca06;"><i class="icon guiigoapp-xuanshang zy-a"></i></span>{lang guiigo_manage:tlang0125}</a><!--{/if}-->
						<!--{if $_G['group']['allowpostdebate']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5" class="zy-f" data-no-cache="true"><span style="background:#ff6060;"><i class="icon guiigoapp-taolunqu zy-a"></i></span>{lang guiigo_manage:tlang0126}</a><!--{/if}-->
						<!--{if $_G['group']['allowpostactivity']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4" class="zy-f" data-no-cache="true"><span style="background:#da99db;"><i class="icon guiigoapp-huodong zy-a"></i></span>{lang guiigo_manage:tlang0127}</a><!--{/if}-->
						<!--{if $_G['group']['allowposttrade']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2" class="zy-f" data-no-cache="true"><span style="background:#7b8ce2;"><i class="icon guiigoapp-shangpin zy-a"></i></span>{lang guiigo_manage:tlang0128}</a><!--{/if}-->
					</div>
					<div class="gg-zt-jgys bg-g"></div>
					<div class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</div>
				</div>
			</div>
		<!--{/if}-->
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<!--{if $status == 'isgroupuser'}-->
						<li><a href="forum.php?mod=group&action=out&fid=$_G[fid]" 
							class="dialog zy-f xh-b"
							ck-cus="true" 
							ck-param="{type:'modal',callpar:{},fn:'MsgCallGroupjt',load:'true',uid: '$_G[uid]'}" 
							external ><i class="icon guiigoapp-tbxhtc"></i>{lang guiigo_manage:tlang0414}</a></li>
						<!--{else}-->
						<li><a href="forum.php?mod=group&action=join&fid=$_G[fid]" 
							class="dialog zy-f xh-b"
							ck-cus="true" 
							ck-param="{type:'modal',callpar:{},fn:'MsgCallGroupjt',load:'true',uid: '$_G[uid]'}" 
							external ><i class="icon guiigoapp-tbxhjr"></i>{lang guiigo_manage:tlang0392}</a></li>
						<!--{/if}-->
						<li><a href="home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}" 
							class="zy-f xh-b dialog" 
							ck-cus="true"
							ck-param="{type:'modal',callpar:{},fn:'MsgCallAlbsc',load:'true',uid: '$_G[uid]'}" 
							external ><i class="icon guiigoapp-tbxhsc"></i>{lang guiigo_manage:tlang0415}</a></li>
						<!--{if $_G['forum']['ismoderator']}-->
						<li><a href="forum.php?mod=group&action=manage&fid=$_G[fid]" class="zy-f xh-b" data-no-cache="true"><i class="icon guiigoapp-shezhi"></i>{lang guiigo_manage:tlang0416}</a></li>
						<!--{/if}-->
						<!--{if $status == 'isgroupuser' && helper_access::check_module('group')}-->
						<li><a href="misc.php?mod=invite&action=group&id=$_G[fid]" 
								class="zy-f xh-b dialog"
								ck-cus="true"
								ck-param="{type:'modal',callpar:{'pid':'$post[pid]',type:'invite'},fn:'MsgCallInvite',load:'true',uid:'$_G[uid]'}"
								external ><i class="icon guiigoapp-tbxhyq"></i>{lang guiigo_manage:tlang0413}</a></li>
						<!--{/if}-->
						<!--{if $guiigo_config['isguiigoapp']}-->
						<li><a href="javascript:;" onclick="appShareAllview('#share_title','#share_img','#share_introduce');" class="zy-f"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						<!--{else}-->
						<li><a href="javascript:;" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');" class="zy-f"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						<!--{/if}-->
					</ul>
				</div>
			</div>
			<div class="gg-qz-qztb bg-c xh-b">
				<div class="qztb-qzbg" style="background: url(<!--{if $_G['forum']['banner']}-->$_G[forum][banner]<!--{else}-->{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/group.png<!--{/if}-->) no-repeat 0 0;background-size: cover;">
					<div id="share_img" class="qzbg-qico"><img src="$_G[forum][icon]" alt="$_G[forum][name]"/></div>
				</div>
				<div class="qztb-qzxx bg-c">
					<h2 class="qzxx-qzmc zy-e">#<!--{echo cutstr($_G[forum][name],32)}-->#</h2>
					<div id="share_title" style="display: none;">$_G[forum][name] - {lang guiigo_manage:tlang0977}</div>
					<div class="qzxx-qzsj list-block-no cl">
						<ul>
							<li class="yh-a zy-g"><em class="qzsj-sjnr zy-h"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][membernum])}--><!--{else}-->$_G[forum][membernum]<!--{/if}--></em>{lang member}</li>
							<li class="yh-a zy-g"><em class="qzsj-sjnr zy-h"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][posts])}--><!--{else}-->$_G[forum][posts]<!--{/if}--></em>{lang guiigo_manage:tlang0417}</li>
							<li class="yh-a zy-g"><em class="qzsj-sjnr zy-h"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][commoncredits])}--><!--{else}-->$_G[forum][commoncredits]<!--{/if}--></em>{lang credits}</li>
							<li class="zy-g"><em class="qzsj-sjnr zy-h"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($groupcache[ranking][data][today])}--><!--{else}-->$groupcache[ranking][data][today]<!--{/if}--></em>{lang group_member_rank}</li>
						</ul>
					</div>
					<div class="qzxx-qzcy bg-g">
						<a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]">
							<div class="qzcy-qcjz yh-b">
								<!--{loop $groupmanagers $manage}-->
									<!--{avatar($manage[uid],middle)}-->
									<h2 class="qcjz-cjmc zy-h">$manage[username]</h2>
									<p class="qcjz-cjbt zy-g">{lang guiigo_manage:tlang0418}</p>
									<!--{eval break;}-->
								<!--{/loop}-->
							</div>
							<div class="qzcy-cyzs list-block-no">
								<span class="zy-g">{lang guiigo_manage:tlang0419}<i class="icon guiigoapp-xzdk"></i></span>
								<ul>
									<!--{eval $activityuserlist = GuiigoApp::getgrouplist($_G['fid']);}-->
									<!--{loop $activityuserlist $cykey $user}-->
										<!--{if $cykey<= 3}-->
											<li><!--{avatar($user[uid],middle)}--></li>
										<!--{/if}-->
									<!--{/loop}-->
								</ul>
							</div>
						</a>
					</div>
					<!--{if $_G[forum][description]}-->
						<div id="share_introduce" class="qzxx-qzjj zy-h">$_G[forum][description]</div>
					<!--{/if}-->
				</div>
			</div>
			<!--{if $_G['forum']['threadtypes']}-->
				<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
				<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-grouplist list-block-no xh-b bg-c">
					<ul class="swiper-wrapper">
						<li class="swiper-slide{if !$_GET['typeid']} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.grouplist-scroll','forum.php?mod=forumdisplay&action=list&fid=$_G[fid]',['gg-qz-lbkz']);">{lang guiigo_manage:tlang0420}</a><span class="bg-b"></span></li>
						<!--{if $_G['forum']['threadtypes']}-->
							<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
								<li class="swiper-slide{if $_GET['typeid'] == $id} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.grouplist-scroll','forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}',['gg-qz-lbkz']);">$name</a><span class="bg-b"></span></li>
							<!--{/loop}-->
						<!--{/if}-->
					</ul>
				</div>
				<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<!--{/if}-->
			<div class="gg-qz-lbkz">
			<!--{if $_G['forum_threadcount']}-->
				<div class="gg-sq-ggzd ms-a bg-c xh-b">
					<!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
					<div class="ggzd-ggnr xh-a">
						<!--{if empty($announcement['type'])}-->
						<a href="forum.php?mod=announcement&id=$announcement[id]">
							<span class="zy-c">$announcement[starttime]</span><i class="icon guiigoapp-gonggao zy-a bg-j"></i><em class="zy-h">$announcement[subject]</em>
						</a>
						<!--{else}-->
						<a href="$announcement[message]"><i class="icon guiigoapp-gonggao zy-a bg-j"></i><em class="zy-h">$announcement[subject]</em></a><!--{/if}-->
					</div>
					<!--{/if}-->
					<div class="ggzd-zdnr list-block-no">
						<ul>
						<!--{eval $isdisplayorder=0;}-->
						<!--{loop $_G['forum_threadlist'] $key $thread}-->
							<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
							<!--{/if}-->
							<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
								<!--{eval continue;}-->
							<!--{/if}-->
							<!--{if $thread['moved']}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
							<!--{/if}-->
							<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
								<li class="xh-a listtop {if $isdisplayorder >= $guiigo_config['appsetting']['forumconfig']['show_top_unfold']}none{/if}">
									<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
										<span class="zy-c">$thread[author]</span>
										<i class="icon guiigoapp-zhiding zy-a{if $thread['displayorder'] == 1} bg-d{/if}{if $thread['displayorder'] == 2} bg-k{/if}{if $thread['displayorder'] == 3} bg-h{/if}{if $thread['displayorder'] == 4} bg-h{/if}"></i>
										<em class="zy-h">{$thread[subject]}</em>
									</a>
								</li>
							<!--{eval $isdisplayorder++;}-->
							<!--{/if}-->
						<!--{/loop}-->
						<!--{eval unset($key,$thread);}-->
						</ul>
					</div>
					<!--{if $isdisplayorder > $guiigo_config['appsetting']['forumconfig']['show_top_unfold']}-->
					<div class="ggzd-gdzk zy-c" onclick="display(this,'.listtop');">{lang guiigo_manage:tlang0136}<i class="icon guiigoapp-xxzk zy-c"></i></div>
					<!--{/if}-->
				</div>
				<div class="guiigo-ztlb list-block-no ">
					<ul class="list-container bg-g">
					<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))> 0 }-->
					<!--{if $post['closed'] > 1 || $post['moved']}-->
						<!--{eval $post[tid]=$post[closed];}-->
					<!--{/if}-->
					<!--{if (!$_G['setting']['mobile']['mobiledisplayorder3'] && $post['displayorder'] > 0) ||  $post['displayorder'] < 0}-->
						{eval continue;}
					<!--{/if}-->
						<li class="gztlb-ztys bg-c xh-b sh-a">
							<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><!--{elseif $thread['digest'] > 0}-->
								<div class="gztlb-jhzt"><i class="icon guiigoapp-jinghua zy-i"></i></div>
							<!--{/if}-->
							<div class="gztlb-tbyh">
								<div class="tbyh-lztx guiigo-ty"><!--{if $thread['authorid'] && $thread['author']}--><a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><!--{avatar($thread[authorid],middle)}--></a><!--{else}--><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg"><!--{/if}--></div>
								<div class="tbyh-mcxx">
									<h1>
										<!--{if $thread['authorid'] && $thread['author']}-->
											<!--{if $thread['isfollow'] ==1}-->
											<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$thread['authorid']" 
											class="followmod_$thread[authorid] dialog mcxx-gzan zy-c bk-c bg-e" 
											ck-cus="true" 
											ck-confirm="true" 
											ck-param="{type:'modal',callpar:{tid:'$thread['authorid']'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}" 
											external >{lang guiigo_manage:tlang0003}</a>
											<!--{else}-->
											<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]"
											class="followmod_$thread[authorid] dialog mcxx-gzan zy-b bk-b"  
											ck-cus="true"
											ck-confirm="false"
											ck-param="{type:'modal',callpar:{tid:'$thread[authorid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}"
											external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
											<!--{/if}-->
											<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="mcxx-yhmc zy-f">$thread[author]</a>
											
											<span class="mcxx-yhdj zy-a" style="background: {$thread[groupcolor]};">{$thread[groupstars]} {$thread[grouptitle]}</span>
											<!--{if $thread['gender'] == 1 || $thread['gender'] == 0}-->
											<i class="icon guiigoapp-nan bg-n"></i>
											<!--{elseif $thread['gender'] == 2}-->
											<i class="icon guiigoapp-nv bg-o"></i>
											<!--{/if}-->
											<!--{if !empty($verify[$thread['authorid']])}--> 
												<!--{eval $verifyicon = str_replace('target="_blank"', $verify[$thread['authorid']]);}--> 
												<span class="verify-icon y">$verify[$thread['authorid']]</span>
											<!--{/if}-->
										<!--{else}-->
											<a href="javascript:void(0);" class="mcxx-yhmc zy-f">$_G[setting][anonymoustext]</a>
										<!--{/if}-->
									</h1>
									<div class="mcxx-fbxx">
										<i class="zy-g"><!--{eval echo dgmdate($thread[dateline], 'u');}--></i>
									</div>
								</div>
							</div>
							<div class="gztlb-nrdy">
								<h1>
									<!--{if $thread[special] == 1}-->
										<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0138}</span>
									<!--{elseif $thread[special] == 2}-->
										<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0139}</span>
									<!--{elseif $thread[special] == 3}-->
										<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0140}</span>
									<!--{elseif $thread[special] == 4}-->
										<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0141}</span>
									<!--{elseif $thread[special] == 5}-->
										<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0142}</span>
									<!--{elseif $thread['rushreply']}-->
										<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0143}</span>
									<!--{/if}-->
									<!--{if $thread['replycredit'] > 0}-->
										<span class="nrdy-ztlx bg-j zy-a">{lang guiigo_manage:tlang1028}</span>
									<!--{/if}-->
									<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]>{$thread['subject']}</a>
								</h1>

								<!--{if $thread['message']}-->
								<p class="zy-c"><!--{$thread['message']}--></p>
								<!--{/if}-->
								<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
									<div class="nrdy-imgs">
										<ul style="display: flex;justify-content: left;flex-wrap: wrap;">
									<!--{loop $thread[attapic] $imgkey $imglist}-->
										<!--{if $imglist['countImg'] == 1}-->
											<li class="imgs-tpsa"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
										<!--{elseif $imglist['countImg'] == 2}-->
											<li class="imgs-tpsb"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
										<!--{elseif $imglist['countImg'] == 3}-->
											<li class="imgs-tpsb imgs-tpsp"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
										<!--{else}-->
											<li class="imgs-tpsc<!--{if $imglist['countImg'] > 6}--> imgs-tpsd<!--{/if}-->"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/><!--{if $imglist['countImg'] > 6}--><div class="tpsd-gdtp"><span class="tpsd-jtnr"><i class="icon guiigoapp-mkbtgd"></i>{$imglist['countImg']}</span></div><!--{/if}--></li>
										<!--{/if}-->
									<!--{/loop}-->
										</ul>
									</div>
								</a>
							</div>
							<div class="gztlb-ztcz">
								<!--{eval $typehtmls=str_replace(array('[',']'),'',$thread[typehtml]);}-->
								<!--{eval $sorthtmls=str_replace(array('[',']'),'',$thread[sorthtml]);}-->
								<div class="ztcz-lyrd cl">
									<!--{if $typehtmls || $sorthtmls}-->
										<div class="ztcz-bkht"><i class="icon guiigoapp-huati1"></i>$typehtmls $sorthtmls</div>
									<!--{/if}-->
									<!--{if $thread['displayorder'] == 0}-->
										<!--{if $thread[heatlevel]}-->
											<div class="ztcz-bkht ztcz-ztrd"><i class="icon guiigoapp-lredu"></i>{lang guiigo_manage:tlang0879} {$thread[heats]}</div>
										<!--{/if}-->
									<!--{/if}-->
								</div>
								<ul>
									<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-huifu"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[replies])}--><!--{else}-->$thread[replies]<!--{/if}--></a></li>
									<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-chakan"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[views])}--><!--{else}-->$thread[views]<!--{/if}--></a></li>
									<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
										<!--{eval $recommenus=$thread['isrecommenus']==1 ? 1 :'';}-->
										<li class="ztcz-ybcz">
											<div class="ztcz-dzkz{if $recommenus} zy-b bg-m{else} zy-c bg-l{/if}" id="recommend_add_$thread[tid]">
												<a href="{if $recommenus}plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid=$thread[tid]{else}forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&hash={FORMHASH}&handlekey=recommend_add{/if}"  
													class="{if $recommenus}delRecommenus{else}dialog{/if}" 
													ck-cus="true"
													ck-param="{
														type:'modal',
														callpar:{tid:'$thread[tid]'},
														fn:'MsgCallFn',
														load:'true',
														uid:'{$_G[uid]}'
													}" 
													external ><i class="icon{if $recommenus} guiigoapp-dianzanon{else} guiigoapp-dianzan{/if}"></i>
												</a>
												<em id="recommend_add_sum$thread[tid]"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[recommend_add])}--><!--{else}-->$thread[recommend_add]<!--{/if}--></em>
											</div>
										</li>
									<!--{/if}-->
								</ul>
							</div>
						</li>
					<!--{/if}-->
					<!--{/loop}-->
					</ul>
					<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;display:none">
						<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
					</div>
				</div>
			<!--{else}-->
				<div class="guiigo-wnrtx">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang guiigo_manage:tlang0421}</p>
				</div>
			<!--{/if}-->
			</div>
			<div class="popup-actions" id="guiigo-nrdbfx">
				<div class="actions-text guiigo-hdfx">
					<div class="gg-app-hide hdfx-hdxm xh-b bg-e">
						<a href="javascript:;"  data-app="weixin" class="nativeShare weixin zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wx.png" class="vm"></span>{lang guiigo_manage:tlang0153}</a>
						<a href="javascript:;" data-app="weixinFriend" class="nativeShare weixin_timeline zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/pyq.png" class="vm"></span>{lang guiigo_manage:tlang0154}</a>
						<a href="javascript:;" data-app="QQ" class="nativeShare qq zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/qq.png" class="vm"></span>{lang guiigo_manage:tlang0155}</a>
						<a href="javascript:;" data-app="QZone" class="nativeShare qzone zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kj.png" class="vm"></span>{lang guiigo_manage:tlang0156}</a>
						<a href="javascript:;" data-app="sinaWeibo" class="nativeShare weibo zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wb.png" class="vm"></span>{lang guiigo_manage:tlang0157}</a>
					</div>
					<div class="hdfx-hdxm bg-e">
						<a href="javascript:;" class="zy-f zd-12" onclick="copy(this);" id="cptextid"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/fz.png" class="vm"></span>{lang guiigo_manage:tlang0158}</a>
					</div>
					<div class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</div>
				</div>
			</div>
			<div class="share-layer"></div>
			$guiigo_config['footer_html']
		</div>
	</div>
<script>
ck8(function(){
	if(ck8('#focbtn').length > 0){
		ck8('#focbtn').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('#rewardbut').length > 0){
		ck8('#rewardbut').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('.debatereply').length > 0){
		ck8('.debatereply').click(function(e){
			Dz('needmessage').focus()
		})
	}
})

function ShareAllgroup(){
		var config = getShareData('#share_title','#share_img','#share_introduce');
	<!--{if ($guiigo_config['browser']['isqq'] || $guiigo_config['browser']['isuc']) && !$guiigo_config['browser']['iswx']}-->
		nativeShare(config);
	<!--{elseif $guiigo_config['browser']['iswx']}-->
		wxshareJssdkAjax(config)
	<!--{else}-->
		webShare(config)
	<!--{/if}-->
}

function MsgCallGroupjt(msg,par){
	if(typeof msg == 'object' || typeof par == 'object'){
		if(msg.msg.indexOf('{lang guiigo_manage:tlang0422}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0423}')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0424}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0425}')
		}else{
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}
	
function MsgCallAlbsc(msg,par){
	if(typeof msg == 'object' || typeof par == 'object'){
		if(msg.msg.indexOf('{lang guiigo_manage:tlang0014}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0177}')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0015}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0426}')
		}else{
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}
	
function MsgCallInvite(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0168}') != -1){
			ck8.closeModal('.popup-about-js')
			ck8.toast(msg.msg);
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}
function MsgCallFn(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = $('.followmod_'+ par.fuid +'');
		var foObj = $('#recommend_add_'+ param.tid +'');
		var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
			$.toast('{lang guiigo_manage:tlang0003}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
			Obj.attr('ck-confirm','true')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			$.toast('{lang guiigo_manage:tlang0009}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
			Obj.attr('ck-confirm','false')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			$.toast('{lang guiigo_manage:tlang0007}');
		}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
			foObj.addClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzanon"></i>');
			$('#recommend_add_sum'+ param.tid).html(''+ (recommendcut + parseInt(par.recommendv)));
			foObj.find('a').addClass('delRecommenus').removeClass('dialog').attr('href','plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid='+ param.tid)
			$.toast('{lang guiigo_manage:tlang0045}');
			if(par.daycount){
				setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
			}
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
			$.toast('{lang guiigo_manage:tlang0049}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
			$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
				$.router.load('home.php?mod=spacecp&ac=usergroup');
			});
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
			$.toast('{lang guiigo_manage:tlang0053}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
			$.toast('{lang guiigo_manage:tlang0055}');
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}
</script>
</div>
