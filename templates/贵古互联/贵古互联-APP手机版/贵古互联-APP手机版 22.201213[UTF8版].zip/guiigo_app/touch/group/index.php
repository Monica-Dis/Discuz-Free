<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval loadcache('forums');}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="group">
	<header class="gg-app-hide bar bar-nav bg-a">
		<a class="button button-link pull-left open-panel"><i class="icon guiigoapp-txcl zy-a zy-ac yz-a"></i><span class="bar-tx"><!--{if $_G[uid]}--><!--{if !$_G[member][avatarstatus]}--><!--{avatar($_G[uid])}--><!--{else}--><img src="<!--{eval echo avatar($_G[uid], 'middle', true,FALSE,true).'?'.rand(1000, 9999);}-->"/><!--{/if}--><!--{else}--><!--{avatar($_G[uid])}--><!--{/if}--></span></a>
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-a zy-ac yz-a" style="font-size: 1rem;"></i></a>
		<h1 class="title zy-a zy-ac yz-a">{lang guiigo_manage:tlang0079}</h1>
	</header>
	<!--{template common/footer_nav}-->
	<div class="content infinite-scroll group-scroll">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<li><a href="<!--{if $_G[uid]}-->group.php?mod=my&view=join<!--{else}-->javascript:;<!--{/if}-->" class="zy-f xh-b<!--{if !$_G[uid]}--> login<!--{/if}-->"><i class="icon guiigoapp-tbgrzx"></i>{lang guiigo_manage:tlang0473}</a></li>
						<li><a href="group.php?gid=$guiigo_config['appsetting']['groupconfig']['group_ids']" class="zy-f xh-b"><i class="icon guiigoapp-kjsyqz"></i>{lang guiigo_manage:tlang0481}</a></li>
						<li><a href="<!--{if $_G[uid]}-->forum.php?mod=group&action=create<!--{else}-->javascript:;<!--{/if}-->" class="zy-f<!--{if !$_G[uid]}--> login<!--{/if}-->"><i class="icon guiigoapp-chuangjian"></i>{lang guiigo_manage:tlang0400}</a></li>
					</ul>
				</div>
			</div>
			<div class="gg-qz-qzss">
				<a href="javascript:;" onclick="ck8('.gg-qz-qzss').hide();ck8('.gg-qz-qzsc').show();ck8('#scform_srchtxt').focus()"><i class="icon guiigoapp-sousuo"></i>{lang guiigo_manage:tlang0482}</a>
			</div>
			<div class="gg-qz-qzsc" style="display:none;">
				<form class="searchform" method="post" autocomplete="off" action="search.php?mod=group">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="srchfid" value="$srchfid" />
					<input type="hidden" name="searchsubmit" value="yes" />
					<ul class="guiigo-flex">
						<input type="search" id="scform_srchtxt" name="srchtxt" class="qzsc-sssr" placeholder="{lang guiigo_manage:tlang0483}"/>
						<a href="javascript:;" onclick="ck8('.gg-qz-qzsc').hide();ck8('.gg-qz-qzss').show()"><i class="icon guiigoapp-guanbix"></i></a>
						<button type="submit" id="scform_submit" class="qzsc-ssqr ab-az zy-a zy-ac">{lang search}</button>
					</ul>
				</form>
			</div>
			<!--{if $guiigo_config['appsetting']['groupconfig']['group_slide']}-->
			<div id="guii-qz-qzhd" class="mx-a">
				<div class="swiper-container show-swiper">
    			    <div class="swiper-wrapper">
						<!--{loop $guiigo_config['appsetting']['groupconfig']['group_slide'] $val}-->
							<div class="swiper-slide">
								<div class="gg-qz-hdys">
									<a href="$val['type2']"><img src="$val['type1']" width="100%"><span class="zy-a">$val['extend1']</span></a>    
								</div>
								<div class="">&nbsp;</div>
							</div>
						<!--{/loop}-->
      					<div class="swiper-slide last-slide">
      					</div>
    				</div>
				</div>
  				<div class="swiper-container gg-qz-hdbg swiper-no-swiping">
    				<div class="swiper-wrapper">
						<!--{loop $guiigo_config['appsetting']['groupconfig']['group_slide'] $val}-->
							<div class="swiper-slide"><img src="$val['type1']"></div>
						<!--{/loop}-->
					</div>
				</div>
			</div>
			<!--{/if}-->
			<div class="guiigo-tmkbt bg-c sh-a">
				<a href="group.php?gid=$guiigo_config['appsetting']['groupconfig']['group_ids']" class="tmkbt-ycgdz zy-c">{lang guiigo_manage:tlang0481}<i class="icon guiigoapp-xzdk"></i></a>
				<h2 class="zy-e">{lang guiigo_manage:tlang0484}</h2>
			</div>
			<div class="gg-sq-tayc list-block-no mx-a bg-c xh-b sh-a">
				<ul>
					<!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->
					<!--{if $_G['uid']}-->
						<!--{eval $groupuser = DB::fetch_first('select level,joindateline from %t where uid=%d AND fid=%d ', array('forum_groupuser', $_G['uid'],$val[fid]));}-->
					<!--{/if}-->
					<li class="xh-a">
						<!--{if $groupuser['level'] == 0 && $groupuser['joindateline']}-->
							<span style="padding:0;"><a href="forum.php?mod=group&action=join&fid=$val[fid]&hash={FORMHASH}" class="dialog bg-i zy-a"
							ck-cus="true" 
							ck-param="{type:'modal',callpar:{refid:'refid$val[fid]'},fn:'MsgCallType',load:'true',uid: '$_G[uid]'}" 
							external ><i class="icon guiigoapp-bkscj"></i></a></span>
						<!--{elseif $groupuser['level'] >= 1}-->
							<span style="padding:0;"><a href="forum.php?mod=group&action=join&fid=$val[fid]&hash={FORMHASH}" class="dialog bg-i zy-a"
							ck-cus="true" 
							ck-param="{type:'modal',callpar:{refid:'refid$val[fid]'},fn:'MsgCallType',load:'true',uid: '$_G[uid]'}" 
							external ><i class="icon guiigoapp-bkscj"></i></a></span>
						<!--{else}-->
							<span style="padding:0;"><a href="forum.php?mod=group&action=join&fid=$val[fid]&hash={FORMHASH}" class="dialog bg-h zy-a zy-ac"
							ck-cus="true" 
							id="refid$val[fid]"
							ck-param="{type:'modal',callpar:{refid:'refid$val[fid]'},fn:'MsgCallType',load:'true',uid: '$_G[uid]'}" 
							external ><i class="icon guiigoapp-bkscj"></i></a></span>
						<!--{/if}-->
						<div class="bkys-bkico">
							<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]"><img lazySrc="$val[icon]" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"></a>
						</div>
						<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="bkys-bkmc zy-e">$val[name]</a>
						<p class="zy-g"><!--{echo cutstr($val[description],40)}--></p>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{if $topgrouplist}-->
			<div class="guiigo-tmkbt bg-c sh-a">
				<a href="<!--{if $_G[uid]}-->group.php?mod=my&view=join<!--{else}-->javascript:;<!--{/if}-->" class="tmkbt-ycgdz zy-c<!--{if !$_G[uid]}--> login<!--{/if}-->">{lang guiigo_manage:tlang0473}<i class="icon guiigoapp-xzdk"></i></a>
				<h2 class="zy-e">{lang guiigo_manage:tlang0485}</h2>
			</div>
			<div class="swiper-container list-block-no gg-qz-rmqz mx-a bg-c xh-b sh-a">
				<ul class="swiper-wrapper">
					<!--{loop $topgrouplist $fid $group}-->
					<li class="swiper-slide">
						<a href="forum.php?mod=forumdisplay&action=list&fid=$group[fid]">
							<img lazySrc="$group[icon]" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm">
							<h2 class="zy-a zs-a">$group[name]</h2>
						</a>
					</li>
					<!--{/loop}-->
					<li class="swiper-slide" style="display: block;"></li>
					<li class="swiper-slide" style="display: block;"></li>
				</ul>
			</div>
			<!--{/if}-->
			<!--{if $guiigo_config['appsetting']['groupconfig']['show_group_content']}-->
           <div id="loadpage_group"
				data-scrollTopEnd="1" 
				data-page="0" 
				data-loadstate="1"
				data-orderid="group"
				data-url="plugin.php?id=guiigo_manage:api&api=PostList&act=getGrougList">
				<div class="appendpage"></div>
				<div class="infinite-scroll-preloader guiigo-zdjz" id="scroll-preloader_group" style="visibility:hidden;"></div>
           </div>
		   <!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	ck8(function(){
		getMore('group')
	})
	function MsgCallFn(msg,par,param) {
		if(typeof msg === 'object' || typeof par === 'object'){
			var Obj = $('.followmod_'+ par.fuid +'');
			var foObj = $('#recommend_add_'+ param.tid +'');
			var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
				$.toast('{lang guiigo_manage:tlang0003}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
				Obj.attr('ck-confirm','true')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
				$.toast('{lang guiigo_manage:tlang0009}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
				Obj.attr('ck-confirm','false')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
				$.toast('{lang guiigo_manage:tlang0007}');
			}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
				foObj.addClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzanon"></i>');
				$('#recommend_add_sum'+ param.tid).html(''+ (recommendcut + parseInt(par.recommendv)));
				foObj.find('a').addClass('delRecommenus').removeClass('dialog').attr('href','plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid='+ param.tid)
				$.toast('{lang guiigo_manage:tlang0045}');
				if(par.daycount){
					setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
				}
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
				$.toast('{lang guiigo_manage:tlang0049}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
				$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
					$.router.load('home.php?mod=spacecp&ac=usergroup');
				});
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
				$.toast('{lang guiigo_manage:tlang0053}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
				$.toast('{lang guiigo_manage:tlang0055}');
			}else {
				$.toast(msg.msg);
			}
		}else{
			$.toast('{lang guiigo_manage:tlang0056}');
		}
	}
	function MsgCallType(msg,par,param) {
		if(typeof msg === 'object' || typeof par === 'object'){
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0489}') != -1){
			ck8('#'+param.refid).removeClass('bg-h').addClass('bg-i')
			$.toast(msg.msg);
			}else {
				$.toast(msg.msg);
			}
		}else{
			$.toast('{lang guiigo_manage:tlang0056}');
		}
	}
	</script>
</div>
<!--{template common/footer}-->