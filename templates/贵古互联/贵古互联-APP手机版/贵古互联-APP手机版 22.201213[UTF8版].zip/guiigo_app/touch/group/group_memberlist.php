<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="page page-current" data-mod="group-memberlist">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0438}</h1>
	</header>
	<div class="content">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
		<!--{if $op == 'alluser'}-->
			<!--{if $adminuserlist}-->
				<div class="gg-qz-cyjb ms-a bg-c zy-h">{lang guiigo_manage:tlang0470}</div>
				<div class="guiigo-hylb list-block-no sh-a xh-b bg-c">
					<ul class="ms-c">
						<!--{loop $adminuserlist $user}-->
						<li class="sh-a">
							<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="hylb-ls hylb-lsd">
								<!--{echo avatar($user[uid], 'middle')}-->
								<i class="icon guiigoapp-xzdk zy-g"></i>
								<h2 class="hylb-bt zy-h">$user[username]</h2>
								<p class="hylb-jj lbmc-tsqz bg-d zy-a"><!--{if $user['level'] == 1}-->{lang guiigo_manage:tlang0436}<!--{elseif $user['level'] == 2}-->{lang guiigo_manage:tlang0437}<!--{/if}--></p>
							</a>
						</li>
						<!--{/loop}-->
					</ul>
				</div>
			<!--{/if}-->
			<!--{if $staruserlist || $alluserlist}-->
				<div class="gg-qz-cyjb ms-a bg-c zy-h">{lang guiigo_manage:tlang0438}</div>
				<div class="guiigo-hylb list-block-no sh-a xh-b bg-c">
					<ul class="ms-c">
						<!--{if $staruserlist}-->
						<!--{loop $staruserlist $user}-->
						<li class="sh-a">
							<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="hylb-ls hylb-lsd">
								<!--{echo avatar($user[uid], 'middle')}-->
								<i class="icon guiigoapp-xzdk zy-g"></i>
								<h2 class="hylb-bt zy-h">$user[username]</h2>
								<p class="hylb-jj lbmc-tsqz bg-j zy-a">{lang guiigo_manage:tlang0439}</p>
							</a>
						</li>
						<!--{/loop}-->
						<!--{/if}-->
						<!--{if $alluserlist}-->
						<!--{loop $alluserlist $user}-->
						<li class="sh-a">
							<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="hylb-ls hylb-lsd">
								<!--{echo avatar($user[uid], 'middle')}-->
								<i class="icon guiigoapp-xzdk zy-g"></i>
								<h2 class="hylb-bt zy-h">$user[username]</h2>
								<p class="hylb-jj zy-g">{lang guiigo_manage:tlang0440}: <!--{echo dgmdate($user[joindateline], 'u', '9999', getglobal('setting/dateformat'))}--></p>
							</a>
						</li>
						<!--{/loop}-->
						<!--{/if}-->
					</ul>
				</div>
			<!--{else}-->
				<div class="guiigo-wnrtx">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang guiigo_manage:tlang0471}</p>
				</div>
			<!--{/if}-->
			<!--{if $multipage}--><div class="pgs cl">$multipage</div><!--{/if}-->
		<!--{/if}-->
		$guiigo_config['footer_html']
		</div>
	</div>
</div>