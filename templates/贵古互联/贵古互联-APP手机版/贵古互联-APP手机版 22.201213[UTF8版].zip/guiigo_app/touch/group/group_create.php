<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="page page-current" data-mod="group-create">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0400}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-qz-flts bg-c ms-a">
				<div class="flts-tsnr bk-d bg-p zy-b">
					<p>{lang group_you_have}</p>
					<!--{if $_G['group']['buildgroupcredits']}--><p>{lang group_create_buildcredits} $_G['group']['buildgroupcredits'] $_G['setting']['extcredits'][$creditstransextra]['unit']{$_G['setting']['extcredits'][$creditstransextra]['title']}</p><!--{/if}-->
					<!--{if $_G['setting']['groupmod']}--><p>{lang guiigo_manage:tlang0407}</p><!--{/if}-->
				</div>
			</div>
			<form method="post" 
			autocomplete="off" 
			name="groupform" 
			id="groupform" 
			action="forum.php?mod=group&action=create"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pmid:'',type:'groupform'},fn:'MsgCallCreate',load:'true',uid:'$_G[uid]'}"
			>
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="referer" value="{echo dreferer()}" />
				<input type="hidden" name="handlekey" value="creategroup" />
				<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang group_name} <span class="zy-i">*</span></div>
							<div class="wblb-wbnr zy-h"><input type="text" name="name" id="name" class="guiigo-px s-a" value="" autocomplete="off" placeholder="{lang guiigo_manage:tlang0401}"/></div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang group_category} <span class="zy-i">*</span></div>
							<div class="wblb-wbnr zy-h">
								<select name="parentid" tabindex="2" class="guiigo-ps" onchange="__ajaxget(this.value);">
									<option value="0">{lang choose_please}</option>
									$groupselect[first]
								</select>
							</div>
						</li>
						<li class="guiigo-flex xh-b cl" id="second" style="display:none;">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0402} <span class="zy-i">*</span></div>
							<div id="secondgroup" class="wblb-wbnr zy-h"></div>
						</li>
						<li class="wblb-dkbt bg-g xh-b zy-c cl">
							{lang group_description}
						</li>
						<li class="wblb-nrsr xh-b zy-h cl">
							<div class="wblb-wbnr zy-h"><textarea id="descriptionmessage" name="descriptionnew" class="guiigo-pt s-a" placeholder="{lang guiigo_manage:tlang0403}"></textarea></div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang group_perm_visit} <span class="zy-i">*</span></div>
							<div class="wblb-wbnr">
								<label class="guiigo-pds"><input type="radio" name="gviewperm" class="guiigo-pd-k" value="1" checked="checked" /><span></span>{lang group_perm_all_user}</label>
								<label class="guiigo-pds"><input type="radio" name="gviewperm" class="guiigo-pd-k" value="0" /><span></span>{lang group_perm_member_only}</label>
							</div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang group_join_type} <span class="zy-i">*</span></div>
							<div class="wblb-wbnr">
								<label class="guiigo-pds"><input type="radio" name="jointype" class="guiigo-pd-k" value="0" checked="checked" /><span></span>{lang guiigo_manage:tlang0404}</label>
								<label class="guiigo-pds"><input type="radio" name="jointype" class="guiigo-pd-k" value="2" /><span></span>{lang guiigo_manage:tlang0405}</label>
								<label class="guiigo-pds"><input type="radio" name="jointype" class="guiigo-pd-k" value="1" /><span></span>{lang guiigo_manage:tlang0406}</label>
							</div>
						</li>
					</ul>
				</div>
				<input type="hidden" name="createsubmit" value="true">
				<div class="mn-a">
					<button type="submit" name="privacysubmit" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang create}</button>
				</div>
			</form>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript">
		function MsgCallCreate(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0409}') != -1 && param.type == 'groupform'){
					ck8.toast('{lang guiigo_manage:tlang0410}');
					setTimeout(function(){
						ck8.router.load('group.php?mod=my&view=manager',true)
					},2000)
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0411}') != -1 && param.type == 'groupform'){
					ck8.toast('{lang guiigo_manage:tlang0410}{lang guiigo_manage:tlang0412}');
					setTimeout(function(){
						ck8.router.back()
					},2000)
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}
		function checkgroupname() {
			var groupname = $.trim(Dz('name').value);
			ajaxget('','forum.php?mod=ajax&forumcheck=1&infloat=creategroup&handlekey=creategroup&action=checkgroupname&groupname=' + (document.charset == 'utf-8' ? encodeURIComponent(groupname) : groupname), 'groupnamecheck');
		}
		function checkCategory(){
			var groupcategory = $.trim(Dz('fup').value);
			if(groupcategory == ''){
				Dz('groupcategorycheck').innerHTML = '{lang group_create_selete_categroy}';
				return false;
			} else {
				Dz('groupcategorycheck').innerHTML = '';
			}
		}
		<!--{if $_GET['fupid']}-->
				ajaxget('','forum.php?mod=ajax&action=secondgroup&fupid=$_GET[fupid]<!--{if $_GET[groupid]}-->&groupid=$_GET[groupid]<!--{/if}-->', 'secondgroup');
		<!--{/if}-->
		$(function(){
			if(Dz('name')) {
				Dz('name').focus();
			}
		})
		function __ajaxget(val){
			ajaxget(
				'',
				'forum.php?mod=ajax&action=secondgroup&fupid='+ val, 
				'secondgroup',
				'',
				function(res){
					if(res){
						$('#second').show()
					}else{
						$('#second').hide()
					}
				}
			)
		}
	</script>
</div>