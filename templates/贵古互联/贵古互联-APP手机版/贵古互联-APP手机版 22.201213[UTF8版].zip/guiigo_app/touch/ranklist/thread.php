<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="ranklist-thread">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="search.php?mod=forum" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-f"></i></a>
		<h1 class="title zy-h">{lang ranklist_thread}</h1>
	</header>
	<div class="content phthread-scroll bg-c gg-yjms">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-kj-rwbg">
				<img src="template/guiigo_app/static/images/tpbg.jpg" class="vm">
				<div class="guiigo-bwdx">
					<div class="guiigo-bwdx-a"></div>
					<div class="guiigo-bwdx-b"></div>
				</div>
			</div>
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-ranklistthread list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $_GET[view] == 'replies'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phthread-scroll','misc.php?mod=ranklist&type=thread&view=replies&orderby=$orderby',['gg-ph-tpzt']);">{lang guiigo_manage:tlang0863}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[view] == 'views'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phthread-scroll','misc.php?mod=ranklist&type=thread&view=views&orderby=$orderby',['gg-ph-tpzt']);">{lang guiigo_manage:tlang0876}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[view] == 'favtimes'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phthread-scroll','misc.php?mod=ranklist&type=thread&view=favtimes&orderby=$orderby',['gg-ph-tpzt']);">{lang guiigo_manage:tlang0877}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[view] == 'heats'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phthread-scroll','misc.php?mod=ranklist&type=thread&view=heats&orderby=$orderby',['gg-ph-tpzt']);">{lang guiigo_manage:tlang0878}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-zt-jgys bg-g"></div>
			<div class="gg-ph-tpzt sh-a">
				<div id="before" class="tpzt-rqsx xh-b">
					<a href="javascript:;" onclick="app.LoadPageForumView('.phthread-scroll','misc.php?mod=ranklist&type=thread&view=$_GET[view]&orderby=thisweek',['tpzt-phon','tpzt-rqsx']);" id="604800" class="{if $orderby == 'thisweek'}zy-be{else}zy-c{/if}">{lang ranklist_week}</a>
					<span class="zy-g">|</span>
					<a href="javascript:;" onclick="app.LoadPageForumView('.phthread-scroll','misc.php?mod=ranklist&type=thread&view=$_GET[view]&orderby=thismonth',['tpzt-phon','tpzt-rqsx']);" id="2592000" class="{if $orderby == 'thismonth'}zy-be{else}zy-c{/if}">{lang ranklist_month}</a>
					<span class="zy-g">|</span>
					<a href="javascript:;" onclick="app.LoadPageForumView('.phthread-scroll','misc.php?mod=ranklist&type=thread&view=$_GET[view]&orderby=today',['tpzt-phon','tpzt-rqsx']);" id="86400" class="{if $orderby == 'today'}zy-be{else}zy-c{/if}">{lang ranklist_today}</a>
					<span class="zy-g">|</span>
					<a href="javascript:;" onclick="app.LoadPageForumView('.phthread-scroll','misc.php?mod=ranklist&type=thread&view=$_GET[view]&orderby=all',['tpzt-phon','tpzt-rqsx']);" id="all" class="{if $orderby == 'all'}zy-be{else}zy-c{/if}">{lang all}</a>
				</div>
				<div class="tpzt-phon">
					<!--{if $threadlist}-->
						<div class="gg-ph-tzlb list-block-no">
							<ul>
								<!--{loop $threadlist $thread}-->
									<li class="xh-b">
										<div class="tzlb-phsj yh-b zy-f"><!--{if $thread['rank'] <= 3}--><img src="template/guiigo_app/static/images/ggph-$thread['rank'].png" alt="$thread['rank']" /><!--{else}-->$thread['rank']<!--{/if}--></div>
										<a href="forum.php?mod=viewthread&tid={$thread['tid']}" class="tzlb-ztbt zy-e">$thread['subject']</a>
										<p>
											<i class="zy-c">
												<!--{if $_GET[view] == 'views'}-->
													{lang guiigo_manage:tlang0381}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread['views'])}--><!--{else}-->$thread['views']<!--{/if}-->
												<!--{elseif $_GET[view] == 'favtimes'}-->
													{lang guiigo_manage:tlang0708}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread['favtimes'])}--><!--{else}-->$thread['favtimes']<!--{/if}-->
												<!--{elseif $_GET[view] == 'heats'}-->
													{lang guiigo_manage:tlang0879}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread['heats'])}--><!--{else}-->$thread['heats']<!--{/if}-->
												<!--{else}-->
													{lang guiigo_manage:tlang0148}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread['replies'])}--><!--{else}-->$thread['replies']<!--{/if}-->
												<!--{/if}-->
											</i>
											<a href="home.php?mod=space&uid={$thread['authorid']}&do=profile" class="zy-l"><!--{avatar($thread['authorid'],middle)}-->$thread['author']</a>
											<em class="zy-g">$thread['dateline']</em>
										</p>
									</li>
								<!--{/loop}-->
							</ul>
						</div>
					<!--{else}-->
						<div class="guiigo-wnrtx">
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
							<p class="zy-c">{lang guiigo_manage:tlang0880}</p>
						</div>
					<!--{/if}-->
					<!--{if $threadlist}-->
						<div class="gg-ph-hcsm mn-a zy-c">{lang ranklist_update}</div>
					<!--{/if}-->
				</div>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->