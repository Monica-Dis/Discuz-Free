<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="ranklist-member">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="home.php?mod=spacecp&ac=search" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-f"></i></a>
		<h1 class="title zy-h">{lang ranklist_member}</h1>
	</header>
	<div class="content member-scroll bg-c gg-yjms">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-ranklistmember list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $a_actives[post]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.member-scroll','misc.php?mod=ranklist&type=member&view=post',['gg-ph-phzk']);">{lang guiigo_manage:tlang0866}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $a_actives[credit]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.member-scroll','misc.php?mod=ranklist&type=member&view=credit',['gg-ph-phzk']);">{lang guiigo_manage:tlang0867}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $a_actives[onlinetime]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.member-scroll','misc.php?mod=ranklist&type=member&view=onlinetime',['gg-ph-phzk']);">{lang guiigo_manage:tlang0868}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $a_actives[beauty]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.member-scroll','misc.php?mod=ranklist&type=member&view=beauty',['gg-ph-phzk']);">{lang guiigo_manage:tlang0869}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $a_actives[handsome]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.member-scroll','misc.php?mod=ranklist&type=member&view=handsome',['gg-ph-phzk']);">{lang guiigo_manage:tlang0870}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-ph-phzk bg-c">
				<!--{template ranklist/member_list}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->