<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $list}-->
	<div class="gg-ph-qsyh list-block-no">
		<ul>
			<!--{loop $list $key $value}-->
				<!--{if $value[rank] <= 3}-->
					<!--{eval $userLists = GuiigoApp::getUserList($value[uid],'profile');}-->
					<li>
						<a href="home.php?mod=space&uid=$value[uid]&do=profile">
							<div class="qsyh-txys">
								<div class="txys-bgys">
									<i class="icon guiigoapp-phhg"></i>
									<span class="txys-txmb bg-c"><!--{avatar($value[uid],middle)}--></span>
								</div>
							</div>
							<div class="qsyh-dqpm bg-c zy-be"><!--{if $value[rank] == 1}-->{lang guiigo_manage:tlang0871}<!--{elseif $value[rank] == 2}-->{lang guiigo_manage:tlang0872}<!--{elseif $value[rank] == 3}-->{lang guiigo_manage:tlang0873}<!--{/if}--></div>
							<h2>
								<em class="zy-a">$value[username]</em>
								<!--{if $userLists['gender'] == 1}-->
								<i class="icon guiigoapp-nan bg-n"></i>
								<!--{elseif $userLists['gender'] == 2}-->
								<i class="icon guiigoapp-nv bg-o"></i>
								<!--{/if}-->
							</h2>
							<p class="zy-a">
								<!--{eval g_icon($value[groupid]);}-->
								<!--{if $value['credits']}-->{lang credit_num}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($value[credits])}--><!--{else}-->$value[credits]<!--{/if}--><!--{/if}-->
								<!--{if $value['posts']}-->{lang posts_num}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($value[posts])}--><!--{else}-->$value[posts]<!--{/if}--><!--{/if}-->
								<!--{if $value['onlinetime']}-->{lang guiigo_manage:tlang0874}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($value[onlinetime])}--><!--{else}-->$value[onlinetime]<!--{/if}--> {lang minute}<!--{/if}-->
							</p>
						</a>
					</li>
				<!--{/if}-->
			<!--{/loop}-->
		</ul>
		<div class="guiigo-bwdx">
			<div class="guiigo-bwdx-a"></div>
			<div class="guiigo-bwdx-b"></div>
		</div>
	</div>
	<div class="gg-ph-hsyh list-block-no">
		<ul>
			<!--{loop $list $key $value}-->
				<!--{if $value[rank] >= 4}-->
				    <!--{eval $userList = GuiigoApp::getUserList($value[uid],'profile');}-->
					<li class="xh-b">
						<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="guiigo-ty">
							<span class="hsyh-xgsj zy-c">
								<!--{eval g_icon($value[groupid]);}-->
								<!--{if $value['credits']}-->{lang credit_num}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($value[credits])}--><!--{else}-->$value[credits]<!--{/if}--><!--{/if}-->
								<!--{if $value['posts']}-->{lang posts_num}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($value[posts])}--><!--{else}-->$value[posts]<!--{/if}--><!--{/if}-->
								<!--{if $value['onlinetime']}-->{lang guiigo_manage:tlang0874}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($value[onlinetime])}--><!--{else}-->$value[onlinetime]<!--{/if}--> {lang minute}<!--{/if}-->
							</span>
							<span class="hsyh-dqpm zy-g">$value[rank]</span>
							<!--{avatar($value[uid],middle)}-->
							<h2 class="zy-h">$value[username]</h2>
							<!--{if $userList['gender'] == 1}-->
							<i class="icon guiigoapp-nan bg-n"></i>
							<!--{elseif $userList['gender'] == 2}-->
							<i class="icon guiigoapp-nv bg-o"></i>
							<!--{/if}-->
						</a>
					</li>
				<!--{/if}-->
			<!--{/loop}-->
		</ul>
	</div>
	<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
<!--{else}-->
	<div class="guiigo-wnrtx">
		<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
		<p class="zy-c">{lang guiigo_manage:tlang0875}</p>
	</div>
<!--{/if}-->
<!--{if $cachetip}--><div class="gg-ph-hcsm mn-a zy-c">{lang ranklist_update}</div><!--{/if}-->