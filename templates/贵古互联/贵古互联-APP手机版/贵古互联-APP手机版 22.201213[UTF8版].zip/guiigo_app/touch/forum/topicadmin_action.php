<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="list-block guiigo-adsz">
	<form id="topicadminform" 
		method="post" 
		autocomplete="off" 
		action="forum.php?mod=topicadmin&action=$_GET[action]&modsubmit=yes&infloat=yes&modclick=yes" 
		ck-cus="true"
		ck-param="{type:'modal',callpar:{action:'$_GET[action]',pid:'$_GET[topiclist][0]',cpid:'$_GET[fnpid]'},fn:'{if $_GET['fn']}$_GET['fn']{/if}',load:'true',title:'{lang guiigo_manage:tlang0319}'}">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="fid" value="$_G[fid]">
		<input type="hidden" name="tid" value="$_G[tid]">
		<!--{if !empty($_GET['page'])}--><input type="hidden" name="page" value="$_GET['page']" /><!--{/if}-->
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
		<!--{if $_GET[action] == 'delpost'}-->
			$deleteid
			<!--{if ($modpostsnum == 1 || $authorcount == 1) && $crimenum > 0}-->
			<div class="adsz-scts zy-h">
				{lang topicadmin_crime_delpost_nums}
			</div>
			<!--{/if}-->
		<!--{elseif $_GET[action] == 'delcomment'}-->
			$deleteid
			<div class="adsz-scts zy-h">{lang guiigo_manage:tlang0332}</div>
		<!--{elseif $_GET[action] == 'restore'}-->
			<input type="hidden" name="archiveid" value="$archiveid"/>
			<div class="adsz-scts zy-h">
				{lang admin_threadsplit_restore}
			</div>
		<!--{elseif $_GET[action] == 'copy'}-->
			<div class="adsz-szxm guiigo-flex">
				<div class="szxm-xmbt zy-c">{lang admin_target}</div>
				<div class="szxm-xmnr guiigo-flexy">
					<select name="copyto" id="copyto" class="guiigo-ps zy-h" onchange="ajaxget('','forum.php?mod=ajax&action=getthreadtypes&fid=' + this.value, 'threadtypes')">
						$forumselect
					</select>
				</div>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmbt zy-c">{lang admin_targettype}</div>
				<div class="szxm-xmnr szxm-xzys guiigo-flexy" id="threadtypes">
					<select name="threadtypeid" class="guiigo-ps zy-h"><option value="0" /></option></select>
				</div>
			</div>
		<!--{elseif $_GET[action] == 'banpost'}-->
			$banid
			<div class="adsz-szxm guiigo-flex">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="banned" class="guiigo-pd-k" value="1" $checkban />
					<span></span>{lang admin_banpost}
				</label>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="banned" class="guiigo-pd-k" value="0" $checkunban />
					<span></span>{lang admin_unbanpost}
				</label>
			</div>
			<!--{if ($modpostsnum == 1 || $authorcount == 1) && $crimenum > 0}-->
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmsm bk-d bg-p zy-b">{lang topicadmin_crime_banpost_nums}</div>
			</div>
			<!--{/if}-->
		<!--{elseif $_GET[action] == 'warn'}-->
			$warnpid
			<div class="adsz-szxm guiigo-flex">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="warned" class="guiigo-pd-k" value="1" $checkwarn />
					<span></span>{lang topicadmin_warn_add}
				</label>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="warned" class="guiigo-pd-k" value="0" $checkunwarn />
					<span></span>{lang topicadmin_warn_delete}
				</label>
			</div>
			<!--{if ($modpostsnum == 1 || $authorcount == 1) && $authorwarnings > 0}-->
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmsm bk-d bg-p zy-b">{lang topicadmin_warn_nums}</div>
			</div>
			<!--{/if}-->
		<!--{elseif $_GET[action] == 'merge'}-->
			<div class="adsz-szxm guiigo-flex">
				<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0333}</div>
				<div class="szxm-xmnr szxm-dsrk guiigo-flexy">
					<input type="text" name="othertid" id="othertid" class="guiigo-px bg-e" size="10">
				</div>
			</div>
		<!--{elseif $_GET[action] == 'refund'}-->
			<label class="label-checkbox item-content">
				<div class="item-inner innerdel">
					<div class="item-subtitle">
					{lang pay_buyers}: $payment[payers]
					</div>
				</div>
			</label>
			<label class="label-checkbox item-content">
				<div class="item-inner innerdel">
					<div class="item-subtitle">
					{lang pay_author_income}: $payment[income] 
					{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}
					</div>
				</div>
			</label>
		<!--{elseif $_GET[action] == 'split'}-->
			<div class="adsz-szxm guiigo-flex">
				<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0334}</div>
				<div class="szxm-xmnr szxm-dsrk guiigo-flexy">
					<input type="text" name="subject" id="subject" class="guiigo-px bg-e" size="20">
				</div>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0335}</div>
				<div class="szxm-xmnr szxm-czsm guiigo-flexy">
					<textarea name="split" id="split" class="guiigo-px bg-e" placeholder="{lang guiigo_manage:tlang0336}"></textarea>
				</div>
			</div>
		<!--{elseif $_GET[action] == 'live'}-->
			<div class="adsz-szxm guiigo-flex">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="live" class="guiigo-pd-k" value="1" <!--{if $_G[forum][livetid] != $_G[tid]}-->checked<!--{/if}-->/>
					<span></span>{lang admin_live}
				</label>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="live" class="guiigo-pd-k" value="0" <!--{if $_G[forum][livetid] == $_G[tid]}-->checked<!--{/if}-->/>
					<span></span>{lang admin_live_cancle}
				</label>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmsm bk-d bg-p zy-b">{lang admin_live_tips}</div>
			</div>
		<!--{elseif $_GET[action] == 'stamp'}-->
			<div class="adsz-szxm guiigo-flex">
				<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0337}</div>
				<div class="szxm-xmnr guiigo-flexy">
					<input type="text" class="guiigo-ps s-a zy-h select-picker" value="{lang admin_stamp_none}" data-select="stamp" />
					<select name="stamp" id="stamp" onchange="updatestampimg()" style="display:none;">
						<option value="">{lang admin_stamp_none}</option>
					<!--{loop $_G['cache']['stamps'] $stampid $stamp}-->
						<!--{if $stamp['type'] == 'stamp'}-->
							<option value="$stampid" {if $thread[stamp] == $stampid}selected="selected"{/if}> $stamp[text]</option>
						<!--{/if}-->
					<!--{/loop}-->
					</select>
				</div>
			</div>
			<script type="text/javascript" reload="1">
				if(Dz('threadstamp')) {
					var oldthreadstamp = Dz('threadstamp').innerHTML;
				}
				var stampurls = new Array();
				<!--{loop $_G['cache']['stamps'] $stampid $stamp}-->
				stampurls[$stampid] = '$stamp[url]';
				<!--{/loop}-->
				function updatestampimg() {
					if(Dz('threadstamp')) {
						Dz('threadstamp').innerHTML = Dz('stamp').value ? '<img src="{STATICURL}image/stamp/' + stampurls[Dz('stamp').value] + '">' : '<img src="{STATICURL}image/common/none.gif">';
					}
				}
			</script>
		<!--{elseif $_GET[action] == 'stamplist'}-->
			<div class="adsz-szxm guiigo-flex">
				<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0338}</div>
				<div class="szxm-xmnr guiigo-flexy">
					<input type="text" class="guiigo-ps s-a zy-h select-picker" value="{lang admin_stamplist_current}" data-select="stamplist" />
					<select name="stamplist" id="stamplist" onchange="updatestamplistimg()" style="display:none;">
					<!--{if $thread[icon] >= 0}--><option value="$thread[icon]">{lang admin_stamplist_current}</option><!--{/if}-->
					<option value="">{lang admin_stamplist_none}</option>
					<!--{loop $_G['cache']['stamps'] $stampid $stamp}-->
						<!--{if $stamp['type'] == 'stamplist' && $stamp['icon']}-->
							<option value="$stampid"{if $thread[icon] == $stampid} selected="selected"{/if}>$stamp[text]</option>
						<!--{/if}-->
					<!--{/loop}-->
					</select>
				</div>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmnr guiigo-flexy">
					<em id="stamplistprev"></em>
				</div>
			</div>
			<script type="text/javascript" reload="1">
				var stampurls = new Array();
				<!--{loop $_G['cache']['stamps'] $stampid $stamp}-->
				stampurls[$stampid] = '$stamp[url]';
				<!--{/loop}-->
				function updatestamplistimg(icon) {
					icon = !icon ? Dz('stamplist').value : icon;
					if(Dz('stamplistprev')) {
						Dz('stamplistprev').innerHTML = icon && icon >= 0 ? '<img src="{STATICURL}image/stamp/' + stampurls[icon] + '">' : '<img src="{STATICURL}image/common/none.gif">';
					}
				}
				<!--{if $thread[icon]}-->
					updatestamplistimg($thread[icon]);
				<!--{/if}-->
			</script>
		<!--{elseif $_GET[action] == 'stickreply'}-->
			$stickpid
			<div class="adsz-szxm guiigo-flex">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="stickreply" class="guiigo-pd-k" value="1"{if empty($_GET['undo'])} checked="checked"{/if}/>
					<span></span>{lang guiigo_manage:tlang0339}
				</label>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="stickreply" class="guiigo-pd-k" value="0"{if !empty($_GET['undo'])} checked="checked"{/if}/>
					<span></span>{lang guiigo_manage:tlang0340}
				</label>
			</div>
		<!--{/if}-->
		
		<!--{if $_GET[action] == 'delpost' && $_G['group']['allowbanuser']}-->
			<div class="adsz-scts zy-h">
				{lang guiigo_manage:tlang0332}
			</div>
	    <!--{/if}-->
		<div class="adsz-szxm guiigo-flex ms-a sh-a" style="padding-top: .55rem;">
			<div class="szxm-xmbt zy-c">{lang admin_operation_explain}</div>
			<div class="szxm-xmnr szxm-czsm guiigo-flexy">
				<textarea name="reason" id="reason" rows="3" class="guiigo-px bg-e"></textarea>
			</div>
		</div>
	    <!--{if $_GET[action] == 'delpost' && $_G['group']['allowbanuser']}-->
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmbt zy-c">{lang topicadmin_banuser}</div>
				<div class="szxm-xmnr guiigo-flexy guiigo-pc">
					<input type="checkbox" name="banuser" id="userban"/>
					<label for="userban"><em></em></label>
				</div>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmbt zy-c">{lang topicadmin_userdelpost}</div>
				<div class="szxm-xmnr guiigo-flexy guiigo-pc">
					<input type="checkbox" name="userdelpost" id="userdelpost"/>
					<label for="userdelpost"><em></em></label>
				</div>
			</div>
	    <!--{/if}-->
		<div class="adsz-szxm guiigo-flex ms-a">
			<div class="szxm-xmbt zy-c">{lang crimerecord}</div>
			<div class="szxm-xmnr guiigo-flexy guiigo-pc">
				<input type="checkbox" name="crimerecord" id="crimerecord" />
				<label for="crimerecord"><em></em></label>
			</div>
		</div>
		<div class="adsz-szxm guiigo-flex ms-a">
			<div class="szxm-xmbt zy-c">{lang admin_pm}</div>
			<div class="szxm-xmnr guiigo-flexy guiigo-pc">
				<input type="checkbox" name="sendreasonpm" id="sendreasonpm" {if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />
				<label for="sendreasonpm"><em></em></label>
			</div>
		</div>
	</form>
</div>
<script>ck8(function(){initSelect()})</script>
<!--{template common/footer}-->