<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="gg-sq-bxyb" style="background: url(<!--{if $_G[forum][banner] && !$subforumonly}-->$_G[forum][banner]<!--{else}-->{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/gg-forumb.jpg<!--{/if}-->) no-repeat;background-size: cover;background-position: center;">
	<div class="bxyb-zz">
		<div class="bxyb-tmjg">
			<img src="<!--{if $_G['forum'][icon]}-->data/attachment/common/$_G['forum'][icon]<!--{else}-->{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png<!--{/if}-->" alt="$_G['forum'][name]" class="tmjg-img">
			<div class="tmjg-mfjj">
				<h2 class="zy-a"><!--{echo cutstr($_G['forum'][name],18)}--></h2>
				<p><!--{echo cutstr($_G['forum'][description],30)}--></p>
				<a href="javascript:;" class="mfjj-fb zy-a<!--{if !$_G[uid]}--> login<!--{/if}-->"<!--{if $_G[uid]}--> onclick="app.ActionsManage('#guiigo-bkfbx','t', 'auto');"<!--{/if}-->><i class="icon guiigoapp-fatie"></i>{lang guiigo_manage:tlang0077}</a>
			</div>	
			<div class="tmjg-gzbh">
				<div class="xgsj-gzhy list-block-no cl">
					<ul class="cl">
						<!--{loop $gzlist $vals}-->
							<li><img src="<!--{avatar($vals[uid],middle,true)}-->"></li>
						<!--{/loop}-->
					</ul>
					<span><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][favtimes])}--><!--{else}-->$_G[forum][favtimes]<!--{/if}-->{lang guiigo_manage:tlang0027}</span>
				</div>
				<!--{eval $favorite=GuiigoApp::getUserList($_G['uid'],'favorite','fid');}-->
				<!--{if $favorite && $_G['fid'] == $favorite[$_G['fid']]['id']}-->
				<!--{eval $favids=$favorite[$_G['fid']]['favid'];}-->
					<a id="post_favc_forum_" 
					href="home.php?mod=spacecp&ac=favorite&op=delete&type=forum&favid=$favids" 
					class="dialog posonts-off favorbtn ab-b zy-a" 
					ck-cus="true" ck-param="{type:'modal',callpar:{},fn:'MsgCallPostFavcForum',load:'true',uid: '$_G[uid]'}" external>
					{lang guiigo_manage:tlang0003}</a>
				<!--{else}-->
					<a id="post_favc_forum_" 
					href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" 
					class="dialog posonts favorbtn ab-f zy-a zy-ac" 
					ck-cus="true" ck-param="{type:'modal',callpar:{},fn:'MsgCallPostFavcForum',load:'true',uid: '$_G[uid]'}" external>{lang guiigo_manage:tlang0024}</a>
				<!--{/if}-->
			</div>
		</div>
		<div class="bxyb-bksj<!--{if $_G['page'] == 1 && $_G['forum']['rules']}--><!--{else}--> bxyb-bksjs<!--{/if}-->">
			<div class="bxyb-sz">
				<div class="sgsj-sjon">
					<span><em><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][todayposts])}--><!--{else}-->$_G[forum][todayposts]<!--{/if}--></em>{lang index_today}</span>
					<span><em><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][threads])}--><!--{else}-->$_G[forum][threads]<!--{/if}--></em>{lang index_threads}</span>
					<span><em><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][rank])}--><!--{else}-->$_G[forum][rank]<!--{/if}--></em>{lang guiigo_manage:tlang0133}</span>
					<span><em>$_G[fid]</em>ID</span>
				</div>
			</div>
		</div>
		<!--{if $_G['page'] == 1 && $_G['forum']['rules']}-->
			<div class="bxyb-bkgz bg-c xh-b">
				<h2 class="zy-e">{lang guiigo_manage:tlang1005}</h2>
				<p class="zy-f">$_G['forum'][rules]</p>
			</div>
		<!--{else}-->
			<div class="bxyb-dbzz bg-c"></div>
		<!--{/if}-->
	</div>
</div>
