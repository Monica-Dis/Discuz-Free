<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div id="certainstarttime" class="guiigo-wblb list-block-no ms-a bg-c sh-a xh-b cl" {if $activity['starttimeto']}style="display: none"{/if}>
	<ul>
		<li class="guiigo-flex cl">
			<div class="wblb-wbbt zy-c">{lang post_event_time} <span class="zy-i">*</span></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="starttimefrom[0]" id="starttimefrom_0" class="guiigo-px s-a" autocomplete="off" placeholder="{lang guiigo_manage:tlang0252}" value="$activity[starttimefrom]" tabindex="1" /></div>
		</li>
	</ul>
</div>
<div id="uncertainstarttime" class="guiigo-wblb list-block-no ms-a bg-c sh-a xh-b cl" {if !$activity['starttimeto']}style="display: none"{/if}>
	<ul>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0253} <span class="zy-i">*</span></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="starttimefrom[1]" id="starttimefrom_1" class="guiigo-px s-a" autocomplete="off" placeholder="{lang guiigo_manage:tlang0252}" value="$activity[starttimefrom]" tabindex="1" /></div>
		</li>
		<li class="guiigo-flex cl">
			<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0254} <span class="zy-i">*</span></div>
			<div class="wblb-wbnr zy-h"><input type="text" autocomplete="off" id="starttimeto" name="starttimeto" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0252}" value="{if $activity['starttimeto']}$activity[starttimeto]{/if}" tabindex="1" /></div>
		</li>
	</ul>
</div>
<div class="guiigo-wblb list-block-no bg-c xh-b cl">
	<ul>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-f">{lang activity_starttime_endtime}</div>
			<div class="wblb-wbnr zy-h">
				<div class="guiigo-pc"><input type="checkbox" id="activitytime" name="activitytime" onclick="if(this.checked) {Dz('certainstarttime').style.display='none';Dz('uncertainstarttime').style.display='';} else {Dz('certainstarttime').style.display='';Dz('uncertainstarttime').style.display='none';}" value="1" {if $activity['starttimeto']}checked{/if} tabindex="1" /><label for="activitytime"><em></em></label></div>
			</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="activityplace">{lang activity_space}</label> <span class="zy-i">*</span></div>
			<div class="wblb-wbnr zy-h">
				<input type="text" name="activityplace" id="activityplace" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0255}" value="$activity[place]" tabindex="1" />
			</div>
		</li>
		<!--{if $_GET[action] == 'newthread'}-->
			<li class="guiigo-flex xh-b cl">
				<div class="wblb-wbbt zy-c"><label for="activitycity">{lang activity_city}</label></div>
				<div class="wblb-wbnr zy-h"><input name="activitycity" id="activitycity" class="guiigo-px s-a" type="text" placeholder="{lang guiigo_manage:tlang0256}" tabindex="1" /></div>
			</li>
		<!--{/if}-->
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="activityclass">{lang activiy_sort}</label> <span class="zy-i">*</span></div>
			<div class="wblb-wbnr zy-h">
				<input type="text" id="activityclass" name="activityclass" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0257}" value="$activity[class]" tabindex="1" />
				<!--{if $activitytypelist}-->
					<ul id="activitytypelist" class="gg-fb-hdlb" style="display: none">
					<!--{loop $activitytypelist $type}-->
						<li class="bk-a bg-e zy-c">$type</li>
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
			</div>
			<!--{if $activitytypelist}-->
				<div class="wblb-hdlb"><a href="javascript:;" class="bk-a bg-e zy-c" onclick="showselect(this, 'activityclass', 'activitytypelist')"><i class="icon guiigoapp-xxzk"></i></a>
			<!--{/if}-->
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="activitynumber">{lang activity_need_member}</label></div>
			<div class="wblb-wbnr zy-h">
				<input type="text" name="activitynumber" id="activitynumber" class="guiigo-px s-a" onkeyup="checkvalue(this.value, 'activitynumbermessage')" placeholder="{lang guiigo_manage:tlang0258}" value="$activity[number]" tabindex="1" />
			</div>
			<span id="activitynumbermessage"></span>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0259}</div>
			<div class="wblb-wbnr zy-h">
				<input type="text" class="guiigo-ps s-a select-picker" value="{lang unlimited}" data-select="gender" />
				<select name="gender" id="gender" style="display:none;">
					<option value="0" {if !$activity['gender']}selected="selected"{/if}>{lang unlimited}</option>
					<option value="1" {if $activity['gender'] == 1}selected="selected"{/if}>{lang male}</option>
					<option value="2" {if $activity['gender'] == 2}selected="selected"{/if}>{lang female}</option>
				</select>
			</div>
		</li>
		<!--{if $_G['setting']['activityfield']}-->
			<li class="guiigo-flex xh-b cl">
				<div class="wblb-wbbt zy-c">{lang optional_data}</div>
				<div class="wblb-wbnr zy-h">
					<!--{loop $_G['setting']['activityfield'] $key $val}-->
					<label class="guiigo-pd" for="userfield_$key"><input type="checkbox" name="userfield[]" id="userfield_$key" class="guiigo-pd-k" value="$key"{if $activity['ufield']['userfield'] && in_array($key, $activity['ufield']['userfield'])} checked="checked"{/if} /><span></span>$val</label>
					<!--{/loop}-->
				</div>
			</li>
		<!--{/if}-->
		<!--{if $_G['setting']['activityextnum']}-->
			<li class="wblb-dkbt bg-g xh-b zy-c cl"><label for="extfield">{lang other_data}</label></li>
			<li class="wblb-nrsr xh-b zy-h cl">				
				<textarea name="extfield" id="extfield" class="guiigo-pt s-a" placeholder="{lang post_activity_message} $_G['setting']['activityextnum'] {lang post_option}" cols="50"><!--{if $activity['ufield']['extfield']}-->$activity[ufield][extfield]<!--{/if}--></textarea>
			</li>
		<!--{/if}-->
		<!--{if $_G['setting']['activitycredit']}-->
			<li class="guiigo-flex xh-b cl">
				<div class="wblb-wbbt zy-c"><label for="activitycredit">{lang consumption_credit}</label></div>
				<div class="wblb-wbnr zy-h">
					<input type="text" name="activitycredit" id="activitycredit" class="guiigo-px s-a" placeholder="{lang user_consumption_money}" value="$activity[credit]" />
				</div>
				<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</div>
			</li>
		<!--{/if}-->
			<li class="guiigo-flex xh-b cl">
				<div class="wblb-wbbt zy-c"><label for="activityexpiration">{lang post_closing}</label></div>
				<div class="wblb-wbnr zy-h">
					<input type="text" name="activityexpiration" id="activityexpiration" class="guiigo-px s-a" onclick="showcalendar(event, this, true)" autocomplete="off" placeholder="{lang guiigo_manage:tlang0260}" value="$activity[expiration]" tabindex="1" />
				</div>
			</li>
		<!--{if $allowpostimg}-->
			<li class="guiigo-flex xh-b cl">
				<div class="wblb-wbbt zy-c">{lang post_topic_image}</div>
				<div class="wblb-wbnr zy-h">
					<button type="button" class="guiigo-pn wbnr-flim bg-e bk-e zy-c" onclick="uploadWindow(function (aid, url){activityaid_upload(aid, url)})"><i class="icon guiigoapp-tupian zy-f"></i><!--{if $activityattach[attachment]}-->{lang guiigo_manage:tlang0261}<!--{else}-->{lang guiigo_manage:tlang0262}<!--{/if}--></button>
					<input type="hidden" name="activityaid" id="activityaid" {if $activityattach[attachment]}value="$activityattach[aid]" {/if}/>
					<input type="hidden" name="activityaid_url" id="activityaid_url" />
					<div id="activityattach_image" class="wbnr-fimz">
					<!--{if $activityattach[attachment]}-->
						<img src="$activityattach[url]/{if $activityattach['thumb']}{eval echo getimgthumbname($activityattach['attachment']);}{else}$activityattach[attachment]{/if}"/>
					<!--{/if}-->
					</div>
				</div>
			</li>
		<!--{/if}-->
	</ul>
</div>	
<script type="text/javascript" reload="1">
ck8(function(){
	ck8("#starttimefrom_0").datetimePicker({
		value: ['2020', '01', '01', '12', '00']
	})
	ck8("#starttimefrom_1").datetimePicker({
		value: ['2020', '01', '01', '12', '00']
	})
	ck8("#activityexpiration").datetimePicker({
		value: ['2020', '01', '01', '12', '00']
	})
	ck8("#starttimeto").datetimePicker({
		value: ['2020', '01', '01', '12', '00']
	})
})


function showselect(obj, el1, el2){
   _display(el2)
   ck8('#'+ el2).find('li').click(
	   function(){
			ck8('#'+ el1).val(ck8(this).html());
	   }
   )
}

function checkvalue(value, message){
	if(!value.search(/^\d+$/)) {
		Dz(message).innerHTML = '';
	} else {
		Dz(message).innerHTML = '<b>{lang input_invalid}</b>';
	}
}

EXTRAFUNC['validator']['special'] = 'validateextra';
function validateextra() {
	if(Dz('postform').starttimefrom_0.value == '' && Dz('postform').starttimefrom_1.value == '') {
		ck8.confirm('{lang post_error_message_1}',
			function () {
				 Dz('postform').starttimefrom_0.focus()
			},
			function () {}
		)
		return false;
	}
	if(Dz('postform').activityplace.value == '') {
		ck8.confirm('{lang post_error_message_2}',
			function () {
				 Dz('postform').activityplace.focus()
			},
			function () {}
		)
		return false;
	}
	if(Dz('postform').activityclass.value == '') {
		ck8.confirm('{lang post_error_message_3}',
			function () {
				 Dz('postform').activityclass.focus()
			},
			function () {}
		)
		return false;
	}
	return true;
}

function activityaid_upload(aid, url) {
	Dz('activityaid_url').value = url;
	updateactivityattach(aid, url, '{$_G['setting']['attachurl']}forum');
}

function updateactivityattach(aid, url, attachurl) {
	Dz('activityaid').value = aid;
	Dz('activityattach_image').innerHTML = '<img src="' + attachurl + '/' + url + '" class="spimg" />';
}

</script>