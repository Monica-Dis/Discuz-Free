<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="poll-voter">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang poll_voters}</h1>
	</header>
	<!--{eval $pageurl = "forum.php?mod=misc&action=viewvote&tid=$_G[tid]&polloptionid=$polloptionid";}-->
	<div class="content infinite-scroll poll-voter-scroll" 
		data-url="$pageurl" 
		data-pages="{$count}" 
		data-ppp="{$perpage}" 
		data-page="$page" 
		data-islod="false" 
		data-distance="10">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
				<ul>
					<li class="guiigo-flex xh-b cl">
						<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0395}</div>
						<div class="wblb-wbnr zy-h">
							<select class="guiigo-ps" onchange="selectpoll(this.value);">
							<!--{loop $polloptions $options}-->
								<option value="$options[polloptionid]"{if $options[polloptionid] == $polloptionid} selected="selected"{/if}>$options[polloption]</option>
							<!--{/loop}-->
							</select>
						</div>
					</li>
				</ul>
			</div>
			<!--{if $voterlist}-->
				<div class="guiigo-hylb list-block-no ms-a sh-a xh-b bg-c">
					<ul class="ms-c list-container">
						<!--{loop $voterlist $voter}-->
						<!--{eval $date = DB::result_first('SELECT dateline FROM '.DB::table('forum_pollvoter').' WHERE uid='.$voter[uid].' AND tid='.$_GET[tid]);}-->
						<li class="sh-a">
							<a href="home.php?mod=space&uid=$voter[uid]&do=profile" class="hylb-ls hylb-ds guiigo-tys">
							<!--{avatar($voter[uid],middle)}-->
							<i class="icon guiigoapp-xzdk zy-g"></i>
							<h2 class="hylb-bt zy-h">$voter[username]</h2>
							<p class="hylb-jj zy-g">{lang guiigo_manage:tlang0396}: {eval echo dgmdate($date);}</p>
							</a>
						</li>
						<!--{/loop}-->
					</ul>
				</div>
			<!--{else}-->
				<div class="guiigo-wnrtx">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang guiigo_manage:tlang0397}</p>
				</div>
			<!--{/if}-->
		</div>
		<!--{if $count > 10 && $voterlist}-->
		<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
			<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
		</div>
		<!--{/if}-->
	</div>
	<script>
	function selectpoll(val){
		var url = 'forum.php?mod=misc&action=viewvote&tid=$_G[tid]&polloptionid=' + val;
		app.PageRefresh(false,'page',url)
	}
	</script>
</div>
<!--{template common/footer}-->