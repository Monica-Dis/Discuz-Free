<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="trade">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="javascript:;" 
			class="button button-link pull-right getpm-popup" 
			data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$trade[sellerid]&touid=$trade[sellerid]&pmid=0&daterange=2" 
			external><i class="icon guiigoapp-lxmaijia zy-f"></i></a>
		<h1 class="title zy-h">{lang trade_confirm_buy}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<script type="text/javascript" src="{$_G[setting][jspath]}forum_viewthread.js?{VERHASH}"></script>
			<script type="text/javascript">
			zoomstatus = parseInt($_G[setting][zoomstatus]);
			var feevalue = 0;
			<!--{if $trade[price] > 0}-->var price = $trade[price];<!--{/if}-->
			<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->var credit = $trade[credit];var currentcredit = <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][5])}-->;<!--{/if}-->
			</script>
			<form method="post" 
			autocomplete="off" 
			id="tradepost" 
			name="tradepost" 
			action="forum.php?mod=trade&action=trade&tid=$_G[tid]&pid=$pid"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pmid:'',type:'tradepost'},fn:'MsgCallTeagm',load:'true',uid:'$_G[uid]'}" 
			>
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="gg-sq-qrsp gg-sq-sznr bg-c sh-a xh-b ms-a">
					<li>
						<div class="sznr-sptp bg-e">
						<!--{if $trade['aid']}-->
							<img lazySrc="{echo getforumimg($trade[aid])}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
						<!--{else}-->
							<img lazySrc="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-wt.jpg" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
						<!--{/if}-->
						</div>
						<h4 class="zy-h sh-a">$trade[subject]</h4>
						<p class="sznr-pzdq zy-g">
							<!--{if $trade['quality'] == 1}--><span class="bg-j zy-a">{lang trade_new}</span><!--{elseif $trade['quality'] == 2}--><span class="bg-j zy-a">{lang trade_old}</span><!--{/if}-->
							<!--{if $trade[locus]}-->$trade[locus]<!--{/if}-->
						</p>
						<p class="sznr-jgjf zy-b">
							<!--{if $trade[price] > 0}-->
								<span>{lang guiigo_manage:tlang0347}</span>$trade[price]
							<!--{/if}-->
							<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
								<em class="zy-g"><!--{if $trade['price'] > 0}-->{lang trade_additional}<!--{/if}--> $trade[credit]{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</em>
							<!--{/if}-->
						</p>
					</li>
				</div>
				<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang trade_credits_total}</div>
							<div class="wblb-wbnr">
								<div class="wnmr-sznr zy-h">
									<!--{if $trade[price] > 0}--><strong id="caculate"></strong>&nbsp;{lang trade_units}&nbsp;&nbsp;<!--{/if}-->
									<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}&nbsp;<strong id="caculatecredit"></strong>&nbsp;{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}&nbsp;<span id="crediterror"></span><!--{/if}-->
								</div>
							</div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang trade_nums}</div>
							<div class="wblb-wbnr"><input type="text" id="number" name="number" onkeyup="calcsum()" value="1" class="guiigo-px s-a" /></div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang post_trade_transport}</div>
							<div class="wblb-wbnr">
								<!--{if $trade['transport'] == 1 or $trade['transport'] == 2 or $trade['transport'] == 4}-->
									<!--{if !empty($trade['ordinaryfee'])}--><label class="guiigo-pds"><input class="guiigo-pd-k" type="radio" name="fee" value="1" checked="checked" {if $trade['transport'] == 2}onclick="feevalue = $trade[ordinaryfee];calcsum()"{/if} /><span></span>{lang post_trade_transport_mail} $trade[ordinaryfee] {lang payment_unit}</label><!--{if $trade['transport'] == 2}--><script type="text/javascript">feevalue = $trade[ordinaryfee]</script><!--{/if}--><!--{/if}-->
									<!--{if !empty($trade['expressfee'])}--><label class="guiigo-pds"><input class="guiigo-pd-k" type="radio" name="fee" value="3" checked="checked" {if $trade['transport'] == 2}onclick="feevalue = $trade[expressfee];calcsum()"{/if} /><span></span>{lang post_trade_transport_express} $trade[expressfee] {lang payment_unit}</label><!--{if $trade['transport'] == 2}--><script type="text/javascript">feevalue = $trade[expressfee]</script><!--{/if}--><!--{/if}-->
									<!--{if !empty($trade['emsfee'])}--><label class="guiigo-pds"><input class="guiigo-pd-k" type="radio" name="fee" value="2" checked="checked" {if $trade['transport'] == 2}onclick="feevalue = $trade[emsfee];calcsum()"{/if} /><span></span>EMS $trade[emsfee] {lang payment_unit}</label><!--{if $trade['transport'] == 2}--><script type="text/javascript">feevalue = $trade[emsfee]</script><!--{/if}--><!--{/if}-->
								<!--{/if}-->
								<div class="wbnr-t bg-e bk-e zy-f"
								<!--{if $trade['transport'] == 1}--><input type="hidden" name="transport" value="1">{lang post_trade_transport_seller}<!--{/if}-->
								<!--{if $trade['transport'] == 2}--><input type="hidden" name="transport" value="2">{lang post_trade_transport_buyer}<!--{/if}-->
								<!--{if $trade['transport'] == 3}--><input type="hidden" name="transport" value="3">{lang post_trade_transport_virtual}<!--{/if}-->
								<!--{if $trade['transport'] == 4}--><input type="hidden" name="transport" value="4">{lang post_trade_transport_physical}<!--{/if}-->
								</div>
							</div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang trade_paymethod}</div>
							<div class="wblb-wbnr">
								<!--{if !$_G['uid']}-->
									<div class="wnmr-sznr zy-h"><label><input type="hidden" name="offline" value="0" checked="checked" />{lang trade_pay_alipay}</label></div>
								<!--{elseif !$trade['account'] && !$trade['tenpayaccount']}-->
									<div class="wnmr-sznr zy-h"><input type="hidden" name="offline" value="1" checked="checked" />{lang trade_pay_offline}</div>
								<!--{else}-->
									<label class="guiigo-pds"><input type="radio" class="guiigo-pd-k" name="offline" value="1" /><span></span>{lang trade_pay_offline}</label>
								<!--{/if}-->
							</div>
						</li>
						<!--{if $trade['transport'] != 3}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="buyername">{lang trade_buyername}</label></div>
								<div class="wblb-wbnr"><input type="text" id="buyername" name="buyername" maxlength="50" value="$lastbuyerinfo[buyername]" class="guiigo-px s-a" /></div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="buyercontact">{lang trade_buyercontact}</label></div>
								<div class="wblb-wbnr"><input type="text" id="buyercontact" name="buyercontact" maxlength="100" size="40" value="$lastbuyerinfo[buyercontact]" class="guiigo-px s-a" /></div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="buyerzip">{lang trade_buyerzip}</label></div>
								<div class="wblb-wbnr"><input type="text" id="buyerzip" name="buyerzip" maxlength="10" value="$lastbuyerinfo[buyerzip]" class="guiigo-px s-a" /></div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="buyerphone">{lang trade_buyerphone}</label></div>
								<div class="wblb-wbnr"><input type="text" id="buyerphone" name="buyerphone" maxlength="20" value="$lastbuyerinfo[buyerphone]" class="guiigo-px s-a" /></div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="buyermobile">{lang trade_buyermobile}</label></div>
								<div class="wblb-wbnr"><input type="text" id="buyermobile" name="buyermobile" maxlength="20" value="$lastbuyerinfo[buyermobile]" class="guiigo-px s-a" /></div>
							</li>
						<!--{else}-->
							<input type="hidden" name="buyername" value="" />
							<input type="hidden" name="buyercontact" value="" />
							<input type="hidden" name="buyerzip" value="" />
							<input type="hidden" name="buyerphone" value="" />
							<input type="hidden" name="buyermobile" value="" />
						<!--{/if}-->
						<li class="wblb-dkbt bg-g xh-b zy-c cl"><label for="buyermsg">{lang trade_seller_remark}</label></li>
						<li class="wblb-nrsr xh-b zy-h cl">
							<div class="wblb-wbnr zy-h">
								<textarea id="buyermsg" name="buyermsg" rows="5" class="guiigo-pt s-a" placeholder="{lang trade_seller_remark_comment}"></textarea>
							</div>
						</li>
					</ul>
				</div>
				<div class="mn-a">
				    <input type="hidden" name="tradesubmit" value="true" />
					<button class="formdialog guiigo-pn ab-az zy-a zy-ac" type="button" id="tradesubmit">{lang trade_buy_confirm}</button>
				</div>
			</form>
			<script type="text/javascript">
			function calcsum() {
				<!--{if $trade[price] > 0}-->Dz('caculate').innerHTML = (price * Dz('tradepost').number.value + feevalue);<!--{/if}-->
				<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
					v = (credit * Dz('tradepost').number.value + feevalue);
					if(v > currentcredit) {
						Dz('crediterror').innerHTML = '{lang trade_buy_crediterror}';
						Dz('tradesubmit').disabled = true;
					} else {
						Dz('crediterror').innerHTML = '';
					}
					Dz('caculatecredit').innerHTML = v;
				<!--{/if}-->
			}
			ck8(function(){
				calcsum();
			})
			</script>
			<!--{if $usertrades}-->
				<div class="gg-sq-qtsp ms-a bg-c sh-a xh-b">
					<h2 class="xh-b zy-h">$trade[seller] {lang trade_recommended_goods}</h2>
					<div class="gg-sq-sznr qtsp-yssd list-block-no cl">
						<ul>
						<!--{loop $usertrades $usertrade}-->
							<li>
								<!--{if $usertrade['displayorder'] > 0}--><div class="sznr-tjsp"><i class="icon guiigoapp-tuijian zy-m"></i></div><!--{/if}-->
								<a href="forum.php?mod=viewthread&tid=$usertrade[tid]&do=tradeinfo&pid=$usertrade[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}">
									<div class="sznr-sptp bg-e">
									<!--{if $usertrade['aid']}-->
										<img lazySrc="{echo getforumimg($usertrade[aid])}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
									<!--{else}-->
										<img lazySrc="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-wt.jpg" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
									<!--{/if}-->
										<span class="sptp-sysj ab-e zy-a zs-a">{lang guiigo_manage:tlang0348} $usertrade[totalitems] {lang guiigo_manage:tlang0349}</span>
									</div>
									<h4 class="zy-h sh-a">$usertrade[subject]</h4>
									<p class="sznr-pzdq zy-g">
										<!--{if $usertrade['quality'] == 1}--><span class="bg-j zy-a">{lang trade_new}</span><!--{elseif $usertrade['quality'] == 2}--><span class="bg-j zy-a">{lang trade_old}</span><!--{/if}-->
										<!--{if $usertrade[locus]}-->$usertrade[locus]<!--{/if}-->
									</p>
									<p class="sznr-jgjf zy-b">
										<!--{if $usertrade[price] > 0}-->
											<span>{lang guiigo_manage:tlang0347}</span>$usertrade[price]
										<!--{/if}-->
										<!--{if $_G['setting']['creditstransextra'][5] != -1 && $usertrade[credit]}-->
											<em class="zy-g"><!--{if $usertrade['price'] > 0}-->{lang trade_additional}<!--{/if}--> $usertrade[credit]{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</em>
										<!--{/if}-->
									</p>
								</a>
							</li>
						<!--{/loop}-->
						</ul>
					</div>
				</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
		function MsgCallTeagm(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0350}') != -1 && param.type == 'tradepost'){
					ck8.toast('{lang guiigo_manage:tlang0351}');
					setTimeout(function(){
						
						ck8.router.load(msg.url,true);
					}, 2000)
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}
	</script>
</div>
<!--{template common/footer}-->