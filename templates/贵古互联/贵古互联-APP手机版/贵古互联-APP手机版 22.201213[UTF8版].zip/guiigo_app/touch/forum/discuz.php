<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:plugin.php?id=guiigo_manage&act=index&navactivate=sy');exit;}-->
<!--{/if}-->
<!--{if $_G['uid']}-->
    <!--{eval $_favorite=GuiigoApp::getUserList($_G['uid'],'favorite','fid');}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="discuz">
	<header class="gg-app-hide bar bar-nav bg-a yb-a">
		<a class="button button-link pull-left open-panel"><i class="icon guiigoapp-txcl zy-a zy-ac yz-a"></i><span class="bar-tx"><!--{if $_G[uid]}--><!--{if !$_G[member][avatarstatus]}--><!--{avatar($_G[uid])}--><!--{else}--><img src="<!--{eval echo avatar($_G[uid], 'middle', true,FALSE,true).'?'.rand(1000, 9999);}-->"/><!--{/if}--><!--{else}--><!--{avatar($_G[uid])}--><!--{/if}--></span></a>
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-a zy-ac yz-a" style="font-size: 1rem;"></i></a>
		<!--{if $guiigo_config['appsetting']['forumconfig']['forumstyle'] == 1}-->
			<h1 class="title zy-a">
				<div class="title-tab">
					<a href="javascript:;" onclick="app.LoadPageForumView('.discuz-scroll','forum.php?forumlist=1&do=guanzhu',['title-tab','discuz-mson']);" class="zy-ac yz-a{if CURSCRIPT == 'forum' && $_GET['do'] == 'guanzhu'} on{/if}">{lang guiigo_manage:tlang0113}</a>
					<a href="javascript:;" onclick="app.LoadPageForumView('.discuz-scroll','forum.php?forumlist=1',['title-tab','discuz-mson']);" class="zy-ac yz-a{if CURSCRIPT == 'forum' && $_GET['do'] != 'guanzhu'} on{/if}">{lang guiigo_manage:tlang0114}</a>
				</div>
			</h1>
		<!--{else}-->
			<h1 class="title zy-a zy-ac yz-a">{lang guiigo_manage:tlang0078}</h1>
		<!--{/if}-->
	</header>
	<!--{template common/footer_nav}-->
	<div class="content discuz-scroll">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<li><a href="forum.php?mod=guide&view=hot" class="zy-f xh-b"><i class="icon guiigoapp-xldaodu"></i>{lang guiigo_manage:tlang0111}</a></li>
						<li><a href="search.php?mod=forum" class="zy-f"><i class="icon guiigoapp-xlsousuo"></i>{lang guiigo_manage:tlang0112}</a></li>
					</ul>
				</div>
			</div>
			<div class="gg-app-show">
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-discuz list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if CURSCRIPT == 'forum' && $_GET['do'] == 'guanzhu'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.discuz-scroll','forum.php?forumlist=1&do=guanzhu',['discuz-mson']);">{lang guiigo_manage:tlang0113}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if CURSCRIPT == 'forum' && $_GET['do'] != 'guanzhu'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.discuz-scroll','forum.php?forumlist=1',['discuz-mson']);">{lang guiigo_manage:tlang0114}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			</div>
			<!--{if $guiigo_config['appsetting']['forumconfig']['forumstyle'] == 1}-->
				<div class="discuz-mson">
					<!--{if CURSCRIPT == 'forum' && $_GET['do'] == 'guanzhu'}-->
						<!--{hook/index_top_mobile}-->
						$guiigo_config['appsetting']['forumconfig']['show_follow_ad_html']
						<!--{if $guiigo_config['appsetting']['forumconfig']['show_statistics']}-->
						<div class="guiigo-sjtjm list-block-no bg-c xh-b">
							<ul>
								<li class="yh-a"><span class="zy-c">{lang index_today}</span><p class="zy-f"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($todayposts)}--><!--{else}-->$todayposts<!--{/if}--></p></li>
								<li class="yh-a"><span class="zy-c">{lang index_yesterday}</span><p class="zy-f"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($postdata[0])}--><!--{else}-->$postdata[0]<!--{/if}--></p></li>
								<li class="yh-a"><span class="zy-c">{lang index_posts}</span><p class="zy-f"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($posts)}--><!--{else}-->$posts<!--{/if}--></p></li>
								<li><span class="zy-c">{lang index_members}</span><p class="zy-f"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G['cache']['userstats']['totalmembers'])}--><!--{else}-->$_G['cache']['userstats']['totalmembers']<!--{/if}--></p></li>
							</ul>
						</div>
						<!--{/if}-->
						<!--{if $guiigo_config['appsetting']['forumconfig']['show_notice']}-->
						<div data-news-id="scrollnew1" class="ck8-news guiigo-dlwzh bg-c xh-b data-news">
							<div class="dlwzh-btys ab-a zy-a">{lang guiigo_manage:tlang0115}</div>
							<div class="ck8-scroll-news dlwzh-nrsj list-block-no">
								<ul id="scrollnew1">
									<!--{eval echo str_replace('<li>','<li class="ck8-scroll-news-items">',$announcements);}-->
								</ul>
							</div>
						</div>
						<!--{/if}-->
						<!--{if $favorite}-->
							<div class="ms-a bg-c sh-a xh-b yb-b">
								<div class="gg-sq-bklb">
									<div id="sub_forum_$cat[fid]" class="bklb-bkys list-block-no">
										<ul>
											<!--{eval $favorderid = 0;}-->
											<!--{loop $forum_favlist $key $favorite}-->
											<!--{if $favforumlist[$favorite[id]]}-->
											<!--{eval $forum=$favforumlist[$favorite[id]];}-->
											<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
											<li class="xh-b">
												<span style="padding:0;"><!--{if $forum[todayposts] > 0}--><em class="bg-j zy-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum[todayposts])}--><!--{else}-->$forum[todayposts]<!--{/if}--></em><!--{/if}--><i class="icon guiigoapp-xzdk zy-d"></i></span>
												<div class="bkys-bkico">
												<!--{if $forum[icon]}-->
													<!--{eval $Newimgurl = str_replace('align="left"','',$forum[icon]);}-->
													$Newimgurl 
												<!--{else}-->
													<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png" alt="$forum[name]" /></a>
												<!--{/if}-->
												</div>
												<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="bkys-bkmc zy-e"><i>{$forum[name]}</i></a>
												<p class="zy-g">{lang guiigo_manage:tlang0116}:<!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum['threads'])}--><!--{else}-->$forum['threads']<!--{/if}-->&nbsp;&nbsp;{lang guiigo_manage:tlang0117}:<!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum['posts'])}--><!--{else}-->$forum['posts']<!--{/if}--></p>
											</li>
											<!--{/if}-->
											<!--{/loop}-->
										</ul>
									</div>
								</div>
							</div>
						<!--{else}-->
							<div class="guiigo-wnrtx guiigo-wnrtxx">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
								<p class="zy-c"><!--{if $guiigo_config['appsetting']['forumconfig']['recommend_forum_ids']}-->{lang guiigo_manage:tlang0026}<!--{else}-->{lang guiigo_manage:tlang1008}<!--{/if}--></p>
							</div>
							<!--{if $guiigo_config['appsetting']['forumconfig']['recommend_forum_ids']}-->
							<!--{eval $recommend_forum_ids = explode(',',$guiigo_config['appsetting']['forumconfig']['recommend_forum_ids']);}-->
							<div class="gg-sq-tayc gg-sq-tayct bg-c">
								<ul>
									<!--{loop $catlist $catr}-->
										<!--{loop $catr[forums] $k $forumidr}-->
										<!--{eval $forum=$forumlist[$forumidr];}-->
										<!--{eval $favidss=$_favorite[$forum['fid']]['favid'];}-->
										<!--{if in_array($forum['fid'],$recommend_forum_ids)}-->
											<li class="xh-a">
												<!--{if $forum['fid'] == $_favorite[$forum['fid']]['id']}-->
												<span class="bg-h bg-i" id="favorite_{$forum['fid']}" style="padding:0;">
													<a href="home.php?mod=spacecp&ac=favorite&op=delete&type=forum&favid=$favidss&key=delfidfavorite" class="dialog zy-a" 
													ck-cus="true" 
													ck-param="{type:'modal',callpar:{},fn:'MsgCall',load:'true',uid: '$_G[uid]'}" 
													external><i class="icon guiigoapp-bkscj"></i></a>
												</span>
												<!--{else}-->
												<span class="bg-h" id="favorite_{$forum['fid']}" style="padding:0;">
													<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$forum['fid']&handlekey=favoriteforum&formhash={FORMHASH}" class="dialog zy-a zy-ac" 
													ck-cus="true" 
													ck-param="{type:'modal',callpar:{},fn:'MsgCall',load:'true',uid: '$_G[uid]'}" 
													external><i class="icon guiigoapp-bkscj"></i></a>
												</span>
												<!--{/if}-->
												<div class="bkys-bkico">
												<!--{if $forum[icon]}-->
													<!--{eval $Newimgurl = str_replace('align="left"','',$forum[icon]);}-->
													$Newimgurl 
												<!--{else}-->
													<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png" alt="$forum[name]" /></a>
												<!--{/if}-->
												</div>
												<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="bkys-bkmc zy-e"><i>{$forum[name]}</i><!--{if $forum[todayposts] > 0}--><em class="zy-c bg-g"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum[todayposts])}--><!--{else}-->$forum[todayposts]<!--{/if}--></em><!--{/if}--></a>
												<p class="zy-g">$forum[description]</p>
											</li>
										<!--{/if}-->
										<!--{/loop}-->
									<!--{/loop}-->
								</ul>
							</div>
							<!--{/if}-->
						<!--{/if}-->
						<!--{hook/index_middle_mobile}-->
					<!--{else}-->
						<div class="row no-gutter tab-bbs">
							<div class="col-25 gg-sq-tazc bg-e" style="height: calc(86vh);">
							<div href="#tab_tj" class="item-inner tab-link active">{lang guiigo_manage:tlang0118}<span class="bg-b"></span></div>
							<!--{loop $catlist $key $cat}-->
								<div href="#tab_$cat[fid]" class="item-inner tab-link">{$cat['name']}<span class="bg-b"></span></div>
							<!--{eval $sid++;}-->
							<!--{/loop}-->
							</div>
							<div class="col-75 tabs gg-sq-tayc bg-c" style="height: calc(86vh);">
								<div id="tab_tj" class="tab list-block-no active">
									$guiigo_config['appsetting']['forumconfig']['recommend_forum_ad_html']
									<!--{if $guiigo_config['appsetting']['forumconfig']['recommend_forum_ids']}-->
										<ul>
											<!--{eval $recommend_forum_ids = explode(',',$guiigo_config['appsetting']['forumconfig']['recommend_forum_ids']);}-->
											<!--{loop $catlist $catr}-->
												<!--{loop $catr[forums] $k $forumidr}-->
												<!--{eval $forum=$forumlist[$forumidr];}-->
												<!--{eval $favidss=$_favorite[$forum['fid']]['favid'];}-->
												<!--{if in_array($forum['fid'],$recommend_forum_ids)}-->
													<li class="xh-a">
														<!--{if $forum['fid'] == $_favorite[$forum['fid']]['id']}-->
														<span class="bg-h bg-i" id="favorite_{$forum['fid']}" style="padding:0;">
															<a href="home.php?mod=spacecp&ac=favorite&op=delete&type=forum&favid=$favidss&key=delfidfavorite" class="dialog zy-a" 
															ck-cus="true" 
															ck-param="{type:'modal',callpar:{},fn:'MsgCall',load:'true',uid: '$_G[uid]'}" 
															external><i class="icon guiigoapp-bkscj"></i></a>
														</span>
														<!--{else}-->
														<span class="bg-h" id="favorite_{$forum['fid']}" style="padding:0;">
															<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$forum['fid']&handlekey=favoriteforum&formhash={FORMHASH}" class="dialog zy-a zy-ac" 
															ck-cus="true" 
															ck-param="{type:'modal',callpar:{},fn:'MsgCall',load:'true',uid: '$_G[uid]'}" 
															external><i class="icon guiigoapp-bkscj"></i></a>
														</span>
														<!--{/if}-->
														<div class="bkys-bkico">
														<!--{if $forum[icon]}-->
															<!--{eval $Newimgurl = str_replace('align="left"','',$forum[icon]);}-->
															$Newimgurl 
														<!--{else}-->
															<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png" alt="$forum[name]" /></a>
														<!--{/if}-->
														</div>
														<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="bkys-bkmc zy-e"><i>{$forum[name]}</i><!--{if $forum[todayposts] > 0}--><em class="zy-c bg-g"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum[todayposts])}--><!--{else}-->$forum[todayposts]<!--{/if}--></em><!--{/if}--></a>
														<p class="zy-g">$forum[description]</p>
													</li>
												<!--{/if}-->
												<!--{/loop}-->
											<!--{/loop}-->
										</ul>
									<!--{else}-->
										<div class="guiigo-wnrtx guiigo-wnrtxx">
											<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
											<p class="zy-c">{lang guiigo_manage:tlang1007}</p>
										</div>
									<!--{/if}-->
								</div>
								<!--{loop $catlist $key $cat}-->
								<div id="tab_$cat[fid]" class="tab list-block-no">
									<ul>
									<!--{loop $cat[forums] $k $forumid}-->
									<!--{eval $forum=$forumlist[$forumid];}-->
									<!--{eval $favids=$_favorite[$forum['fid']]['favid'];}-->
									<li class="xh-a">
										<!--{if $forum['fid'] == $_favorite[$forum['fid']]['id']}-->
										<span class="bg-h bg-i" id="favorite_{$forum['fid']}" style="padding:0;">
											<a href="home.php?mod=spacecp&ac=favorite&op=delete&type=forum&favid=$favids&key=delfidfavorite" class="dialog zy-a" 
											ck-cus="true" 
											ck-param="{type:'modal',callpar:{},fn:'MsgCall',load:'true',uid: '$_G[uid]'}" 
											external><i class="icon guiigoapp-bkscj"></i></a>
										</span>
										<!--{else}-->
										<span class="bg-h" id="favorite_{$forum['fid']}" style="padding:0;">
											<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$forum['fid']&handlekey=favoriteforum&formhash={FORMHASH}" class="dialog zy-a zy-ac" 
											ck-cus="true" 
											ck-param="{type:'modal',callpar:{},fn:'MsgCall',load:'true',uid: '$_G[uid]'}" 
											external><i class="icon guiigoapp-bkscj"></i></a>
										</span>
										<!--{/if}-->
										<div class="bkys-bkico">
										<!--{if $forum[icon]}-->
											<!--{eval $Newimgurl = str_replace('align="left"','',$forum[icon]);}-->
											$Newimgurl 
										<!--{else}-->
											<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png" alt="$forum[name]" /></a>
										<!--{/if}-->
										</div>
										<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="bkys-bkmc zy-e"><i>{$forum[name]}</i><!--{if $forum[todayposts] > 0}--><em class="zy-c bg-g"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum[todayposts])}--><!--{else}-->$forum[todayposts]<!--{/if}--></em><!--{/if}--></a>
										<p class="zy-g">$forum[description]</p>
									</li>
									<!--{/loop}-->
									</ul>
								</div>
								<!--{/loop}-->
							</div> 
						</div>
					<!--{/if}-->
				</div>
			<!--{else}-->
				<!--{hook/index_top_mobile}-->
				$guiigo_config['appsetting']['forumconfig']['show_follow_ad_html']
				<!--{if $guiigo_config['appsetting']['forumconfig']['show_statistics']}-->
					<div class="guiigo-sjtjm list-block-no bg-c xh-b">
						<ul>
							<li class="yh-a"><span class="zy-c">{lang index_today}</span><p class="zy-f"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($todayposts)}--><!--{else}-->$todayposts<!--{/if}--></p></li>
							<li class="yh-a"><span class="zy-c">{lang index_yesterday}</span><p class="zy-f"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($postdata[0])}--><!--{else}-->$postdata[0]<!--{/if}--></p></li>
							<li class="yh-a"><span class="zy-c">{lang index_posts}</span><p class="zy-f"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($posts)}--><!--{else}-->$posts<!--{/if}--></p></li>
							<li><span class="zy-c">{lang index_members}</span><p class="zy-f"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G['cache']['userstats']['totalmembers'])}--><!--{else}-->$_G['cache']['userstats']['totalmembers']<!--{/if}--></p></li>
						</ul>
					</div>
				<!--{/if}-->
				<!--{if $guiigo_config['appsetting']['forumconfig']['show_notice']}-->
					<div data-news-id="scrollnew1" class="ck8-news guiigo-dlwzh bg-c xh-b data-news">
						<div class="dlwzh-btys ab-a zy-a">{lang guiigo_manage:tlang0115}</div>
						<div class="ck8-scroll-news dlwzh-nrsj list-block-no">
							<ul id="scrollnew1">
								<!--{eval echo str_replace('<li>','<li class="ck8-scroll-news-items">',$announcements);}-->
							</ul>
						</div>
					</div>
				<!--{/if}-->
				<div class="gg-sq-wdbk cl">
					<!--{if empty($gid) && !empty($forum_favlist)}-->
					<div class="wdbk-gzbt cl"><a href="home.php?mod=space&amp;uid=1&amp;do=favorite&amp;view=me&amp;type=forum&amp;mobile=2" class="zy-f bk-a">{lang guiigo_manage:tlang0993}<i class="icon guiigoapp-xzdk zy-f"></i></a>
						<h2>{lang guiigo_manage:tlang0113}</h2>
					</div>
					<div class="wdbk-gznr swiper-containerbk bg-c">
						<ul class="swiper-wrapper">
						<!--{eval $favorderid = 0;}-->
						<!--{loop $forum_favlist $key $favorite}-->
							<li class="swiper-slide">
							<!--{if $favforumlist[$favorite[id]]}-->
							<!--{eval $forum=$favforumlist[$favorite[id]];}-->
							<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
								<!--{if $forum[icon]}-->
									<!--{eval $Newimgurl = str_replace('align="left"','',$forum[icon]);}-->
									$Newimgurl 
								<!--{else}-->
									<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png" alt="$forum[name]" /></a>
								<!--{/if}-->
									<p><a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="zy-f">{$forum[name]}</a></p>
							<!--{/if}-->
							</li>
						<!--{/loop}-->
						</ul>
						<div class="swiper-paginationbk wdbk-wzjt"></div>
					</div>
					<!--{/if}-->
					<div class="wdbk-gzbt cl"><h2>{lang guiigo_manage:tlang0114}</h2></div>
				</div>
				<div class="bg-c sh-a xh-b">
					<!--{loop $catlist $key $cat}-->
					<div class="gg-sq-bklb">
						<div class="bklb-fqys" href="#sub_forum_$cat[fid]">
							<i class="<!--{if !$_G[setting][mobile][mobileforumview]}-->icon guiigoapp-guanbibk zy-f<!--{else}-->icon guiigoapp-zhankaibk zy-f<!--{/if}-->"></i>
							<h2><a href="javascript:;" class="zy-f">$cat[name]</a></h2>
						</div>
						<div id="sub_forum_$cat[fid]" class="bklb-bkys list-block-no">
							<ul>
								<!--{loop $cat[forums] $forumid}-->
								<!--{eval $forum=$forumlist[$forumid];}-->
								<!--{eval $favids=$_favorite[$forum['fid']]['favid'];}-->
								<li>
									<!--{if $forum['fid'] == $_favorite[$forum['fid']]['id']}-->
									<span class="bg-h bg-i" id="favorite_{$forum['fid']}"><a href="home.php?mod=spacecp&ac=favorite&op=delete&type=forum&favid=$favids&key=delfidfavorite" class="dialog zy-a" 
									ck-cus="true" 
									ck-param="{type:'modal',callpar:{},fn:'MsgCall',load:'true',uid: '$_G[uid]'}" 
									external><i class="icon guiigoapp-bkscj"></i></a></span>
									<!--{else}-->
									<span class="bg-h" id="favorite_{$forum['fid']}"><a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$forum['fid']&handlekey=favoriteforum&formhash={FORMHASH}" class="dialog zy-a" 
									ck-cus="true"
									ck-param="{type:'modal',callpar:{},fn:'MsgCall',load:'true',uid: '$_G[uid]'}" 
									external><i class="icon guiigoapp-bkscj"></i></a>
									</span>
									<!--{/if}-->
									<div class="bkys-bkico">
									<!--{if $forum[icon]}-->
										<!--{eval $Newimgurl = str_replace('align="left"','',$forum[icon]);}-->
										$Newimgurl 
									<!--{else}-->
										<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png" alt="$forum[name]" /></a>
									<!--{/if}-->
									</div>
									<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="bkys-bkmc zy-e"><i>{$forum[name]}</i><!--{if $forum[todayposts] > 0}--><em class="zy-c bg-g">$forum[todayposts]</em><!--{/if}--></a>
									<p class="zy-g">$forum[description]</p>
								</li>
								<!--{/loop}-->
							</ul>
						</div>
					</div>
					<!--{/loop}-->
				</div>	
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	function MsgCall(msg,par){
		if(typeof msg == 'object' || typeof par == 'object'){
			if(msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1){
				ck8.toast('{lang guiigo_manage:tlang0008}')
				ck8('#favorite_'+ par.id).find('a').attr('href','home.php?mod=spacecp&ac=favorite&type=forum&id='+ par.id +'&handlekey=favoriteforum&formhash={FORMHASH}')
				ck8('#favorite_'+ par.id).removeClass('bg-i');//.find('i').addClass('').removeClass('')
				app.PageRefresh('.page','gg-sq-wdbk')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0014}') != -1){
				ck8.toast('{lang guiigo_manage:tlang0012}','chenggong')
				ck8('#favorite_'+ par.id).find('a').attr('href','home.php?mod=spacecp&ac=favorite&op=delete&type=forum&favid='+ par.favid +'&key=delfidfavorite')
				ck8('#favorite_'+ par.id).addClass('bg-i');//.find('i').addClass('').removeClass('')
				app.PageRefresh('.page','gg-sq-wdbk')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0015}') != -1){
				ck8.toast('{lang guiigo_manage:tlang0016}','shibai')
			}else{
				ck8.toast(msg.msg)
			}

		}else{
			ck8.toast('error')
		}
	}
	
	$(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			$('.bklb-bkys').css('display', 'block');
		<!--{else}-->
			$('.bklb-bkys').css('display', 'none');
		<!--{/if}-->
		$('.bklb-fqys').click(function(){
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
				obj.find('i').attr('class', 'icon guiigoapp-guanbibk zy-c');
			} else {
				subobj.css('display', 'none');
				obj.find('i').attr('class', 'icon guiigoapp-zhankaibk zy-c');
			}
		});
	})
	</script>
</div>
<!--{template common/footer}-->