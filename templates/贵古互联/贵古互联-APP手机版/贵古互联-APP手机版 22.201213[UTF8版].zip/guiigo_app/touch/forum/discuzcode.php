<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>

<!--{eval}-->
<!--
function tpl_hide_credits_hidden($creditsrequire) {
	global $_G;
-->
<!--{/eval}-->

<!--{block return}--><div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i><!--{if $_G[uid]}-->{$_G[username]}<!--{else}-->{lang guest}<!--{/if}-->{lang post_hide_credits_hidden}</div><!--{/block}-->

<!--{eval}-->
<!--
	return $return;
}

function tpl_hide_credits($creditsrequire, $message) {
-->
<!--{/eval}-->
<!--{block return}--><div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang post_hide_credits}</div><!--����������Ҫ���ָ��ڶ��ٲ��ܿ�-->
$message
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_codedisp($code) {
	$randomid = 'code_'.random(3);
-->
<!--{/eval}-->
<!--{block return}--><div class="blockcode bg-g bk-d zy-h"><div id="$randomid" class="bg-c zy-l"><ol><li>$code</ol></div></div><!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_quote() {
-->
<!--{/eval}-->
<!--{block return}--><div class="gg-sq-hfys bg-e zy-f"><i class="icon guiigoapp-zsyh zy-d"></i><i class="icon guiigoapp-ysyh zy-d"></i>{lang e_quote}: \\1</div><!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_free() {
-->
<!--{/eval}-->
<!--{block return}--><div class="gg-sq-yynr bg-e zy-f"><i class="icon guiigoapp-zsyh zy-d"></i><i class="icon guiigoapp-ysyh zy-d"></i>\\1</div><!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_hide_reply() {
	global $_G;
-->
<!--{/eval}-->
<!--{block return}--><div class="gg-sq-ycnr bg-e bk-d zy-h"><h4 class="xh-b zy-c">{lang post_hide}</h4>\\1</div>
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_hide_reply_hidden() {
	global $_G;
-->
<!--{/eval}-->
<!--{block return}--><div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i><!--{if $_G[uid]}-->{$_G[username]}<!--{else}-->{lang guest}<!--{/if}-->{lang guiigo_manage:tlang1041} <a href="javascript:;" id="focbtn" onclick="app.ActionsManage('#guiigo-hfdp','t','auto','closehfdp');openReply();">{lang guiigo_manage:tlang0148}</a></div><!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}
function attachlist($attach) {
	global $_G;
	$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
	$aidencode = packaids($attach);
	$widthcode = attachwidth($attach['width']);
	$is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G[forum_thread][archiveid] : '';
	$pluginhook = !empty($_G['setting']['pluginhooks']['viewthread_attach_extra'][$attach[aid]]) ? $_G['setting']['pluginhooks']['viewthread_attach_extra'][$attach[aid]] : '';
-->
<!--{/eval}-->

<!--{block return}-->
<div class="gg-sq-nrfj">
	<div class="attach bg-e bk-e">
		<p>
			$attach[attachicon]
			<!--{if !$attach['price'] || $attach['payed']}-->
				<a href="forum.php?mod=attachment{$is_archive}&aid=$aidencode" class="zy-l">$attach[filename]</a>
			<!--{else}-->
				<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" class="zy-l">$attach[filename]</a>
			<!--{/if}-->
			<span class="zy-g">$attach[dateline]{lang upload}</span>
		</p>
		<p class="attach-xs zy-c">$attach[attachsize], {lang downloads}: $attach[downloads]
			<!--{if $attach['readperm']}-->, {lang readperm}: $attach[readperm]<!--{/if}-->
			<!--{if !$guestviewthumb}-->
				<!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->, {lang attachcredits}: $_G[getattachcredits]<!--{/if}-->
			<!--{/if}-->
			<!--{if $attach['description']}-->
				<br/>{$attach[description]}
			<!--{/if}-->
		</p>
		<!--{if $attach['price']}-->
		<p class="attach-xs-s sh-a zy-c">
			{lang guiigo_manage:tlang0119}: <em class="zy-b">$attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</em>
			<a href="forum.php?mod=misc&action=viewattachpayments&aid=$attach[aid]" class="ab-c zy-a">{lang guiigo_manage:tlang0120}</a>
			<!--{if !$attach['payed']}-->
			<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" class="dialog ab-a zy-a" 
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pid:'$post[pid]'},fn:'MsgCallDownload',load:'true',uid: '$_G[uid]'}" 
			external >{lang guiigo_manage:tlang0121}</a>
			<!--{/if}-->
		</p>
		<!--{/if}-->
	</div>
</div>
$pluginhook
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function imagelist($attach, $firstpost = 0) {
	global $_G;
	$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
	$aidencode = packaids($attach);
	$widthcode = attachwidth($attach['width']);
	$is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G[forum_thread][archiveid] : '';
	$attachthumb = getimgthumbname($attach['attachment']);
	$pluginhook = !empty($_G['setting']['pluginhooks']['viewthread_attach_extra'][$attach[aid]]) ? $_G['setting']['pluginhooks']['viewthread_attach_extra'][$attach[aid]] : '';
	$guestviewthumb = !empty($_G['setting']['guestviewthumb']['flag']) && !$_G['uid'];
	if($guestviewthumb) {
		$guestviewthumbcss = guestviewthumbstyle();
	}
-->
<!--{/eval}-->
<!--{block return}-->
	<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && (($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) || (($guestviewthumb)))}-->
	<div class="gg-sq-nrfj">
	<!--{if !IS_ROBOT}-->
		<!--{if $guestviewthumb}-->
			<!--{eval}-->
			<!--
				$makefile = 'forum.php?mod=image&aid='.$attach['aid'].'&size='.$_G['setting']['guestviewthumb']['width'].'x'.$_G['setting']['guestviewthumb']['height'].'&key='.dsign($attach['aid'].'|'.$_G['setting']['guestviewthumb']['width'].'|'.$_G['setting']['guestviewthumb']['height']).'&type=1';
			-->
			<!--{/eval}-->
			{$guestviewthumbcss}
			<div class="islogin">
				<img lazySrc="$makefile" 
				src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" 
				class="ck8-lazy vm login" 
				alt="$attach[imgalt]"
				title="$attach[description]"/>
				<p><a href="javascript:ck8.router.load('member.php?mod=logging&action=login&referer='+encodeURIComponent(location));" class="slogin zy-l">{lang guestviewthumb}</a></p>
			</div>
		<!--{elseif !$attach['price'] || $attach['payed']}-->
			<div class="savephotop">
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
				<img
				class="{if $attach['price'] && $_G['forum_attachmentdown'] && $_G['uid'] != $attach['uid']}attprice{/if} ck8-lazy vimg_{$attach[pid]} vm gg-tpsb"
				data-fid="pid$attach[pid]" 
				data-mid="{$attach[pid]}" 
				src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" 
				alt="$attach[imgalt]"
				title="$attach[description]"
				lazySrc="{if $attach[refcheck]}forum.php?mod=attachment{$is_archive}&aid=$aidencode&noupdate=yes&nothumb=yes{else}{$attach[url]}$attach[attachment]{/if}"
				file="{if $attach[refcheck]}forum.php?mod=attachment{$is_archive}&aid=$aidencode&noupdate=yes{else}{$attach[url]}$attach[attachment]{/if}" 
				onclick="app.previewImg(this);"/>
			<!--{/if}-->
			</div>
		<!--{/if}-->
	<!--{/if}-->
	</div>
	<!--{/if}-->
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function attachinpost($attach, $post) {
	global $_G;
	$firstpost = $post['first'];
	$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
	$aidencode = packaids($attach);
	$widthcode = attachwidth($attach['width']);
	$is_archive = $_G['forum_thread']['is_archived'] ? '&fid='.$_G['fid'].'&archiveid='.$_G[forum_thread][archiveid] : '';
	$attachthumb = getimgthumbname($attach['attachment']);
	$musiccode = getstatus($post[status], 7) && fileext($attach['attachment']) == 'mp3' ? (browserversion('ie') > 8 || browserversion('safari') ? '<audio controls="controls"><source src="'.$attach['url'].$attach['attachment'].'"></audio>' : parseaudio($attach['url'].$attach['attachment'], 400)) : '';
	$guestviewthumb = !empty($_G['setting']['guestviewthumb']['flag']) && !$_G['uid'];
	if($guestviewthumb) {
		$guestviewthumbcss = guestviewthumbstyle();
	}
-->
<!--{/eval}-->
<!--{block return}-->
<div class="gg-sq-nrfj">
	<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && (((!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid'])) || (($guestviewthumb)))}-->
		<!--{if $guestviewthumb}-->
			<!--{eval}-->
			<!--
				$makefile = 'forum.php?mod=image&aid='.$attach['aid'].'&size='.$_G['setting']['guestviewthumb']['width'].'x'.$_G['setting']['guestviewthumb']['height'].'&key='.dsign($attach['aid'].'|'.$_G['setting']['guestviewthumb']['width'].'|'.$_G['setting']['guestviewthumb']['height']).'&type=1';
			-->
			<!--{/eval}-->
			{$guestviewthumbcss}
			<div class="islogin">
				<img lazySrc="$makefile" 
				src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" 
				class="ck8-lazy vm login" 
				alt="$attach[imgalt]"
				title="$attach[description]"/>
				<p><a href="javascript:ck8.router.load('member.php?mod=logging&action=login&referer='+encodeURIComponent(location));" class="slogin zy-l">{lang guestviewthumb}</a></p>
			</div>
		<!--{else}-->
			<div class="savephotop">
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
				<img
				class="{if $attach['price'] && $_G['forum_attachmentdown'] && $_G['uid'] != $attach['uid']}attprice{/if} ck8-lazy vimg_{$attach[pid]} vm gg-tpsb"
				data-fid="pid$attach[pid]" 
				data-mid="{$attach[pid]}" 
				src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" 
				alt="$attach[imgalt]"
				title="$attach[description]"
				lazySrc="{if $attach[refcheck]}forum.php?mod=attachment{$is_archive}&aid=$aidencode&noupdate=yes&nothumb=yes{else}{$attach[url]}$attach[attachment]{/if}"
				file="{if $attach[refcheck]}forum.php?mod=attachment{$is_archive}&aid=$aidencode&noupdate=yes{else}{$attach[url]}$attach[attachment]{/if}" 
				onclick="app.previewImg(this);"/>
			<!--{/if}-->
			</div>
		<!--{/if}-->
	<!--{else}--> 
		<!--{if $musiccode}-->
		<div class="attach-viod">$musiccode</div>
		<!--{/if}-->
		<div class="attach bg-e bk-e">
			<p>
				$attach[attachicon]
				<!--{if !$attach['price'] || $attach['payed']}-->
					<a href="forum.php?mod=attachment{$is_archive}&aid=$aidencode" class="zy-l">$attach[filename]</a>
				<!--{else}-->
					<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" class="zy-l">$attach[filename]</a>
				<!--{/if}-->
				<span class="zy-g">$attach[dateline]{lang upload}</span>
			</p>
			<p class="attach-xs zy-c">$attach[attachsize], {lang downloads}: $attach[downloads]
				<!--{if $attach['readperm']}-->, {lang readperm}: $attach[readperm]<!--{/if}-->
				<!--{if !$guestviewthumb}-->
					<!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->, {lang attachcredits}: $_G[getattachcredits]<!--{/if}-->
				<!--{/if}-->
				<!--{if $attach['description']}-->
					<br/>{$attach[description]}
				<!--{/if}-->
			</p>
			<!--{if $attach['price']}-->
			<p class="attach-xs-s sh-a zy-c">
				{lang guiigo_manage:tlang0119}: <em class="zy-b">$attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</em>
				<a href="forum.php?mod=misc&action=viewattachpayments&aid=$attach[aid]" class="ab-c zy-a">{lang guiigo_manage:tlang0120}</a>
				<!--{if !$attach['payed']}-->
				<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" 
					class="dialog ab-a zy-a" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{type:'attachpay',aid:'$attach[aid]'},fn:'MsgCallDownload',load:'true',uid: '$_G[uid]'}" 
					external >{lang guiigo_manage:tlang0121}</a>
				<!--{/if}-->
			</p>
			<!--{/if}-->
		</div>
	<!--{/if}-->
</div>
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}
-->
<!--{/eval}-->