<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="popup-actions" id="guiigo-lchd-$post[pid]">
	<div class="actions-text guiigo-hdfx">
		<div class="hdfx-tbjs bg-c xh-b">
			<a href="home.php?mod=space&uid=$post[authorid]&do=profile&view=me" class="tbjs-tx"><img src="<!--{avatar($post[authorid], middle, true)}-->" class="vm"></a>
			<div class="tbjs-mc">
				<a href="home.php?mod=space&uid=$post[authorid]&do=profile&view=me" class="tbjs-mcon zy-e">$post[author]</a>
				<!--{if $post['gender'] == 1 || $post['gender'] == 0}-->
				<i class="icon guiigoapp-nan bg-n"></i>
				<!--{elseif $post['gender'] == 2}-->
				<i class="icon guiigoapp-nv bg-o"></i>
				<!--{/if}-->
			</div>
			<div class="tbjs-dz zy-h"><i class="icon guiigoapp-hfweizhi"></i><em><!--{if $post['resideprovince']}-->$post['resideprovince'] $post['residecity']<!--{else}-->{lang guiigo_manage:tlang1033}<!--{/if}--></em></div>
			<div class="tbjs-qm zy-c"><!--{if $post['signature']}-->$post['signature']<!--{else}-->{lang guiigo_manage:tlang1034}<!--{/if}--></div>
			<div class="tbjs-sj">
				<a href="home.php?mod=follow&do=follower&uid=$post[authorid]" class="tbjs-sjon zy-e"><i>$post['follower']</i><p>{lang guiigo_manage:tlang0041}</p></span></a>
				<a href="home.php?mod=follow&do=following&uid=$post[authorid]" class="tbjs-sjon zy-e"><i>$post['following']</i><p>{lang guiigo_manage:tlang0002}</p></span></a>
				<a href="home.php?mod=space&uid=$post[authorid]&do=thread&view=me&from=space" class="tbjs-sjon zy-e"><i>$post[threads]</i><p>{lang guiigo_manage:tlang0417}</p></span></a>
			</div>
		</div>

		<div class="hdfx-hdcz list-block-no bg-c">
			<!--{if $_G[uid]}-->
				<!--{if $allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])}-->
					<a href="forum.php?mod=misc&action=comment&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page{if $_G['forum_thread']['special'] == 127}&special=$specialextra{/if}" 
						class="dialog link link-c zy-h" 
						ck-cus="true" 
						ck-param="{type:'modal',callpar:{tid:'$post[tid]',pid:'$post[pid]'},load:'true',fn:'MsgCallComment',uid:'$_G[uid]'}"
						external>
						<span style="background:#ffc72c;"><i class="icon guiigoapp-fbxhfb zy-a"></i></span>{lang guiigo_manage:tlang0104}
					</a>
				<!--{else}-->
					<a href="javascript:ck8.toast('{lang guiigo_manage:tlang0343}','shibai');" class="link link-c zy-h"><span style="background:#ffc72c;"><i class="icon guiigoapp-fbxhfb zy-a"></i></span>{lang guiigo_manage:tlang0104}</a>
				<!--{/if}-->
				<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" class="zy-h"><span style="background:#3ca0ff;"><i class="icon guiigoapp-lchuifu zy-a"></i></span>{lang guiigo_manage:tlang0148}</a>
				<!--{if $guiigo_config['appsetting']['forumconfig']['show_reward']}-->
					<a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]" class="zy-h dialog" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]'},fn:'MsgCallRaterange',load:'true',uid: '$_G[uid]'}"
					external ><span style="background:#ff6b6e;"><i class="icon guiigoapp-lchongbao zy-a"></i></span>{lang guiigo_manage:tlang0344}</a>
				<!--{/if}-->
				<!--{if $post['authorid'] && $post['author'] && !$post['anonymous']}-->
					<!--{if !($_G['setting']['threadguestlite'] && !$_G['uid'])}-->
						<!--{if !in_array($post['authorid'], $follow)}-->
						<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$post[authorid]" 
							class="followmod_$post[authorid] dialog zy-h" 
							ck-cus="true"
							ck-param="{type:'modal',fn:'MsgCallFnl',load:'true',uid:'$_G[uid]'}" 
							external><span style="background:#21d5bc;"><i class="icon guiigoapp-guanzhu zy-a"></i></span>{lang guiigo_manage:tlang0002}</a>
						<!--{else}-->
						<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$post['authorid']" 
							class="followmod_$post[authorid] dialog zy-h" 
							ck-cus="true"
							ck-param="{type:'modal',fn:'MsgCallFnl',load:'true',uid:'$_G[uid]'}" 
							external><span style="background:#21d5bc;"><i class="icon guiigoapp-guanzhu zy-a"></i></span>{lang guiigo_manage:tlang0003}</a>
						<!--{/if}-->
					<!--{/if}-->
				<!--{/if}-->
				<a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" 
				class="dialog zy-h"
				ck-cus="true"
				ck-param="{type:'modal',fn:'MsgCallReport',load:'true',uid:'$_G[uid]'}"  
				external ><span style="background:#ff7d0e;"><i class="icon guiigoapp-tbxhjb zy-a"></i></span>{lang guiigo_manage:tlang0345}</a>
			<!--{else}-->
				<a href="javascript:ck8.toast('{lang guiigo_manage:tlang0342}','shibai');" class="zy-h"><span style="background:#ffc72c;"><i class="icon guiigoapp-fbxhfb zy-a"></i></span>{lang guiigo_manage:tlang0104}</a>
				<a href="javascript:ck8.toast('{lang guiigo_manage:tlang0342}','shibai');" class="zy-h"><span style="background:#3ca0ff;"><i class="icon guiigoapp-lchuifu zy-a"></i></span>{lang guiigo_manage:tlang0148}</a>
				<a href="javascript:ck8.toast('{lang guiigo_manage:tlang0342}','shibai');" class="zy-h"><span style="background:#ff6b6e;"><i class="icon guiigoapp-lchongbao zy-a"></i></span>{lang guiigo_manage:tlang0344}</a>
				<a href="javascript:ck8.toast('{lang guiigo_manage:tlang0342}','shibai');" class="zy-h"><span style="background:#21d5bc;"><i class="icon guiigoapp-guanzhu zy-a"></i></span>{lang guiigo_manage:tlang0002}</a>
				<a href="javascript:ck8.toast('{lang guiigo_manage:tlang0342}','shibai');" class="zy-h"><span style="background:#ff7d0e;"><i class="icon guiigoapp-tbxhjb zy-a"></i></span>{lang guiigo_manage:tlang0345}</a>
			<!--{/if}-->
		</div>
		<div class="hdfx-abts bg-c">
			<a href="javascript:;" class="abts-on"></a>
		</div>
	</div>
</div>
<div class="popup-actions" id="actions_{$post[pid]}">
		<!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
		<a href="javascript:;" onclick="setanswer($post[tid],$post['pid'], '$_GET[from]','{FORMHASH}','MsgCallModmenu',{'pid':{$firstlist[pid]}})">{lang reward_set_bestanswer}</a>
		<!--{/if}-->
</div>
<!--{if $_G['forum']['ismoderator']}-->
<div class="popup-actions" id="guiigo-lcgl-$post[pid]">
	<div class="actions-text guiigo-hdfx">
		<div class="hdfx-ztgl bg-c cl">
			<!--{if $modmenu['post']}-->
				<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowstickreply'] || $_G['forum_thread']['authorid'] == $_G['uid']}-->
					<a href="javascript:;" class="zy-h" 
					onclick="modaction(this,'stickreply')" 
					data-no-cache="true"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<i class="icon guiigoapp-shen"></i>
					{lang guiigo_manage:tlang0346}</a>
				<!--{/if}-->
				<!--{if $_G['forum']['ismoderator']}-->
					<!--{if $_G['group']['allowwarnpost']}-->
					<a href="javascript:;" class="zy-h" 
					onclick="modaction(this,'warn')" 
					data-no-cache="true"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<i class="icon guiigoapp-shishijinggao"></i>
					{lang modmenu_warn}</a>
					<!--{/if}-->
					<!--{if $_G['group']['allowbanpost']}-->
					<a href="javascript:;"  class="zy-h" 
					onclick="modaction(this,'banpost')" 
					data-no-cache="true"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<i class="icon guiigoapp-pingbi"></i>
					{lang modmenu_banpost}</a>
					<!--{/if}-->
					<!--{if $_G['group']['allowdelpost'] && !$rushreply}-->
					<a href="javascript:;"  class="zy-h" 
					onclick="modaction(this,'delpost')" 
					data-no-cache="true"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<i class="icon guiigoapp-shanchu1"></i>
					{lang modmenu_deletepost}</a>
					<!--{/if}-->
				<!--{/if}-->
				<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
					<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="zy-h" data-no-cache="true"><i class="icon guiigoapp-bianji1"></i>{lang guiigo_manage:tlang0227}</a>
				<!--{/if}-->
			<!--{/if}-->
		</div>
		<div class="hdfx-abts bg-c">
			<a href="javascript:;" class="abts-on"></a>
		</div>
	</div>
</div>
<!--{/if}-->
<!--{if $modmenu['thread'] && $post['first']}-->
<div class="popup-actions" id="guiigo-lcgl-lzgl">
	<div class="actions-text guiigo-hdfx">
		<div class="hdfx-ztgl bg-c cl">
		<!--{eval $modopt=0;}-->
		<!--{if $_G['forum']['ismoderator']}-->
			<!--{if $_G['group']['allowdelpost']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;" class="zy-e" 
				onclick="modthreads(this, 3, 'delete')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-shanchu1"></i>
				{lang modmenu_deletethread}
				</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowbumpthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;" class="zy-e" 
				onclick="modthreads(this, 3, 'bump')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-shengjiangji"></i>
				{lang modmenu_updown}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;" class="zy-e" 
				onclick="modthreads(this, 1, 'stick')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-zhiding-copy"></i>
				{lang modmenu_stickthread}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowlivethread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;" class="zy-e" 
				onclick="modaction(this, 'live')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-live-start"></i>
				{lang modmenu_live}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowhighlightthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modthreads(this, 1, 'highlight')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-wenzigaoliang"></i>
				{lang modmenu_highlight}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modthreads(this, 1, 'digest')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-zuanshi"></i>
				{lang modmenu_digestpost}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1 && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modthreads(this, 1, 'recommend')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-tuijian1"></i>
				{lang modmenu_recommend}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowstampthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modaction(this, 'stamp')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-gaizhangzuobiaopeizhi"></i>
				{lang modmenu_stamp}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowstamplist'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modaction(this, 'stamplist')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-biaoji"></i>
				{lang modmenu_icon}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowclosethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modthreads(this, 4)" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-suo"></i>
				<!--{if !$_G['forum_thread']['closed']}-->
				{lang modmenu_switch_off}
				<!--{else}-->
				{lang modmenu_switch_on}
				<!--{/if}-->
				</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modthreads(this, 2, 'move')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-yidong"></i>
				{lang modmenu_move}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowedittypethread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modthreads(this, 2, 'type')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-classifi"></i>
				{lang modmenu_type}</a>
			<!--{/if}-->
			<!--{if !$_G['forum_thread']['special'] && !$_G['forum_thread']['is_archived']}-->
				<!--{if $_G['group']['allowcopythread'] && $_G['forum']['status'] != 3}-->
					<!--{eval $modopt++}-->
					<a href="javascript:;"  class="zy-e" 
					onclick="modaction(this, 'copy')" 
					data-no-cache="true" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<i class="icon guiigoapp-fuzhi"></i>
					{lang modmenu_copy}</a>
				<!--{/if}-->
				<!--{if $_G['group']['allowmergethread'] && $_G['forum']['status'] != 3}-->
					<!--{eval $modopt++}-->
					<a href="javascript:;"  class="zy-e" 
					onclick="modaction(this, 'merge')" 
					data-no-cache="true" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<i class="icon guiigoapp-hebing"></i>
					{lang modmenu_merge}</a>
				<!--{/if}-->
				<!--{if $_G['group']['allowrefund'] && $_G['forum_thread']['price'] > 0}-->
					<!--{eval $modopt++}-->
					<a href="javascript:;"  class="zy-e" 
					onclick="modaction(this, 'refund')" 
					data-no-cache="true" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<i class="icon guiigoapp-tuikuan"></i>
					{lang modmenu_restore}</a>
				<!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowsplitthread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modaction(this, 'split')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-fengexian"></i>
				{lang modmenu_split}</a>
			<!--{/if}-->
			<!--{if $_G['group']['allowrepairthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modaction(this, 'repair')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-xiufu"></i>
				{lang modmenu_repair}</a>
			<!--{/if}-->
			<!--{if $_G['forum_thread']['is_archived'] && $_G['adminid'] == 1}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modaction(this, 'restore', '', 'archiveid={$_G[forum_thread][archiveid]}')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-cundang"></i>
				{lang modmenu_archive}</a>
			<!--{/if}-->
			<!--{if $_G['forum_firstpid']}-->
				<!--{if $_G['group']['allowwarnpost']}-->
					<!--{eval $modopt++}-->
					<a href="javascript:;"  class="zy-e" 
					onclick="modaction(this, 'warn', '$_G[forum_firstpid]')" 
					data-no-cache="true" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<i class="icon guiigoapp-shishijinggao"></i>
					{lang modmenu_warn}</a>
				<!--{/if}-->
				<!--{if $_G['group']['allowbanpost']}-->
					<!--{eval $modopt++}-->
					<a href="javascript:;"  class="zy-e" 
					onclick="modaction(this, 'banpost', '$_G[forum_firstpid]')" 
					data-no-cache="true" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<i class="icon guiigoapp-pingbi"></i>
					{lang modmenu_banthread}</a>
				<!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowremovereward'] && $_G['forum_thread']['special'] == 3 && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<a href="javascript:;"  class="zy-e" 
				onclick="modaction(this, 'removereward')" 
				data-no-cache="true" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				<i class="icon guiigoapp-shangjin"></i>
				{lang modmenu_removereward}</a>
			<!--{/if}-->
			<!--{if $_G['forum']['status'] == 3 && in_array($_G['adminid'], array('1','2')) && $_G['forum_thread']['closed'] < 1}-->
			<a href="javascript:;"  class="zy-e" 
			onclick="modthreads(this, 5, 'recommend_group');" 
			data-no-cache="true" 
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
			<i class="icon guiigoapp-tuisong"></i>
			{lang modmenu_grouprecommend}</a>
			<!--{/if}-->
		<!--{/if}-->
		<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
			<a class="zy-e" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" data-no-cache="true"><i class="icon guiigoapp-bianji1"></i><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}<!--{/if}--></a>
		<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
			<a class="zy-e" href="forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page" data-no-cache="true"><i class="icon guiigoapp-buchongxinxi"></i>{lang postappend}</a>
		<!--{/if}-->
		</div>
		<div class="hdfx-abts bg-c">
			<a href="javascript:;" class="abts-on"></a>
		</div>
	</div>
</div>
<!--{/if}-->