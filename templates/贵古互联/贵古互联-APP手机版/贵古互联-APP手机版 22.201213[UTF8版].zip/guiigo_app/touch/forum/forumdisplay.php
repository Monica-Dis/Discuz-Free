<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval $_G['forum_threadlist'] = GuiigoApp::GetPostlist($_G['forum_threadlist']);}-->
<!--{eval $gzlist = GuiigoApp::geforumbyuid($_G['fid']);}-->
<!--{if $quicksearchlist && !$_GET['archiveid']}-->
<div class="panel panel-1 panel-right panel-cover gg-kz-sxsx bg-c zy-e">
	<div class="close-panel gg-sq-sxbt zy-e xh-b app-header" 
		style="display: flex;
		justify-content: space-between;
		align-items: center;
		max-width: 85%;">
		<span>{lang guiigo_manage:tlang0122}</span>
		<span class="icon guiigoapp-guanbi zy-c"></span>
	</div>
	<!--{subtemplate forum/search_sortoption}-->
</div>
<!--{/if}-->
<div class="page page-current" data-mod="forumdisplay">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_id']}-->
		<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forums_top_tyle'] == 2}-->
		<a href="javascript:;" class="button button-link pull-right<!--{if !$_G[uid]}--> login<!--{/if}-->"<!--{if $_G[uid]}--> onclick="app.ActionsManage('#guiigo-bkfbx','t', 'auto');"<!--{/if}-->><i class="icon guiigoapp-fabu zy-f"></i></a>
		<!--{/if}-->
		<!--{/if}-->
		<a href="search.php?mod=forum" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-f"></i></a>
		<h1 class="title zy-h" onclick="app.ActionsManage('#actions_1','b', 'auto');"><em><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--><i class="icon guiigoapp-xxzk zy-h"></i></em></h1>
	</header>
	<!--{if empty($_G['forum']['sortmode'])}-->
		<div class="popup-actions" id="guiigo-bkfbx">
			<div class="actions-text guiigo-hdfx gg-sq-fbsx">
				<div class="hdfx-hdxm bg-c">
					<!--{if !$_G['forum']['allowspecialonly']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="zy-f" data-no-cache="true"><span style="background:#3ebbfd;"><i class="icon guiigoapp-huati zy-a"></i></span>{lang guiigo_manage:tlang0123}</a><!--{/if}-->
					<!--{if $_G['group']['allowpostpoll']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1" class="zy-f" data-no-cache="true"><span style="background:#ff9900;"><i class="icon guiigoapp-toupiao zy-a"></i></span>{lang guiigo_manage:tlang0124}</a><!--{/if}-->
					<!--{if $_G['group']['allowpostreward']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3" class="zy-f" data-no-cache="true"><span style="background:#9dca06;"><i class="icon guiigoapp-xuanshang zy-a"></i></span>{lang guiigo_manage:tlang0125}</a><!--{/if}-->
					<!--{if $_G['group']['allowpostdebate']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5" class="zy-f" data-no-cache="true"><span style="background:#ff6060;"><i class="icon guiigoapp-taolunqu zy-a"></i></span>{lang guiigo_manage:tlang0126}</a><!--{/if}-->
					<!--{if $_G['group']['allowpostactivity']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4" class="zy-f" data-no-cache="true"><span style="background:#da99db;"><i class="icon guiigoapp-huodong zy-a"></i></span>{lang guiigo_manage:tlang0127}</a><!--{/if}-->
					<!--{if $_G['group']['allowposttrade']}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2" class="zy-f" data-no-cache="true"><span style="background:#7b8ce2;"><i class="icon guiigoapp-shangpin zy-a"></i></span>{lang guiigo_manage:tlang0128}</a><!--{/if}-->
				</div>
				<div class="gg-zt-jgys bg-g"></div>
				<div class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</div>
			</div>
		</div>
	<!--{else}-->
		<div class="popup-actions" id="guiigo-bkfbx">
			<div class="actions-text guiigo-hdfx">
				<div class="hdfx-glxm list-block-no bg-e">
					<ul>
						<!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
							<!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
								<!--{if $_G['forum']['threadsorts']['show'][$id]}-->
									<li class="bg-c"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id" class="zy-h" data-no-cache="true">$threadsorts</a></li>
								<!--{/if}-->
							<!--{/loop}-->
						<!--{/if}-->
						<!--{if $_G['group']['allowpostpoll']}--><li class="bg-c"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1" class="zy-h" data-no-cache="true">{lang guiigo_manage:tlang0124}</a></li><!--{/if}-->
						<!--{if $_G['group']['allowpostreward']}--><li class="bg-c"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3" class="zy-h" data-no-cache="true">{lang guiigo_manage:tlang0125}</a></li><!--{/if}-->
						<!--{if $_G['group']['allowpostdebate']}--><li class="bg-c"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5" class="zy-h" data-no-cache="true">{lang guiigo_manage:tlang0126}</a></li><!--{/if}-->
						<!--{if $_G['group']['allowpostactivity']}--><li class="bg-c"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4" class="zy-h" data-no-cache="true">{lang guiigo_manage:tlang0127}</a></li><!--{/if}-->
						<!--{if $_G['group']['allowposttrade']}--><li class="bg-c"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2" class="zy-h" data-no-cache="true">{lang guiigo_manage:tlang0128}</a></li><!--{/if}-->
					</ul>
				</div>
				<div class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</div>
			</div>
		</div>
	<!--{/if}-->
	<!--{eval $pageurl = "forum.php?mod=forumdisplay&fid=$_G[fid]".$forumdisplayadd['page'].($multiadd ? '&'.implode('&', $multiadd) : '')."$multipage_archive";}-->
	<div class="content infinite-scroll pull-to-refresh-content thread-scroll" data-url="$pageurl" data-pages="{$_G['forum_threadcount']}" data-ppp="{$_G['tpp']}" data-page="$page" data-islod="false" data-distance="10" data-ptr-distance="50">
	
	<div class="pull-to-refresh-layer gg-app-hide">
		<div class="preloader"></div>
		<div class="pull-to-refresh-arrow"></div>
	</div>

		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="popup-actions" id="actions_1">
				<div class="actions-text gg-sq-ztsx">
					<div class="ztsx_sxbt bg-c xh-b zy-e cl">{lang guiigo_manage:tlang0129}<i class="icon guiigoapp-guanbi zy-c"></i></div>
					<div class="ztsx_sxnr list-block-no bg-c cl">
						<!--{if empty($_G['forum']['sortmode'])}-->
						<ul class="sxnr_jgul cl">
							<li><a class="sxngwbg">{lang guiigo_manage:tlang0122}:</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" class="xi1{if $_GET['filter'] == 'lastpost'} xw1{/if}">{lang guiigo_manage:tlang0130}</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" class="{if $_GET['filter'] == 'heat'}xw1{/if}">{lang order_heats}</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=hot',['guiigo-kz-sxkz','ztsx_sxnr']);" class="{if $_GET['filter'] == 'hot'}xw1{/if}">{lang hot_thread}</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" class="{if $_GET['filter'] == 'digest'}xw1{/if}">{lang digest_posts}</a></li>
						</ul>
						<!--{/if}-->
						<ul class="sxnr_jgul cl">
							<li><a class="sxngwbg">{lang guiigo_manage:tlang0131}:</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" {if $_GET['orderby'] == 'dateline'}class="xw1"{/if}>{lang list_post_time}</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" {if $_GET['orderby'] == 'replies'}class="xw1"{/if}>{lang replies}</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" {if $_GET['orderby'] == 'views'}class="xw1"{/if}>{lang views}</a></li>
						</ul>
						<ul class="sxnr_jgul cl">
							<li><a class="sxngwbg">{lang guiigo_manage:tlang0132}:</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" {if !$_GET['dateline']}class="xw1"{/if}>{lang all}{lang search_any_date}</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" {if $_GET['dateline'] == '86400'}class="xw1"{/if}>{lang last_1_days}</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" {if $_GET['dateline'] == '172800'}class="xw1"{/if}>{lang last_2_days}</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" {if $_GET['dateline'] == '604800'}class="xw1"{/if}>{lang list_one_week}</a></li>
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','ztsx_sxnr']);" {if $_GET['dateline'] == '2592000'}class="xw1"{/if}>{lang list_one_month}</a></li>
						</ul>
					</div>
				</div>
			</div>
			<!--{hook/forumdisplay_top_mobile}-->

			<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_style'] == 4}-->
				<!--{if $guiigo_config['appsetting']['forumconfig']['show_pyqbt']}-->
					<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_id']}-->
						<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forums_top_tyle'] == 1}-->
							<!--{subtemplate forum/forumdisplay_top_a}-->
						<!--{elseif $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forums_top_tyle'] == 2}-->
							<!--{subtemplate forum/forumdisplay_top_b}-->
						<!--{else}-->
							<!--{subtemplate forum/forumdisplay_top_a}-->
						<!--{/if}-->
					<!--{else}-->
						<!--{subtemplate forum/forumdisplay_top_a}-->
					<!--{/if}-->
				<!--{else}-->
				<!--{if $guiigo_config['appsetting']['forumconfig']['show_pyqhd']}-->
					<div class="gg-kj-xchd ms-a bg-c">
						<div class="swiper-container guiigo-hdmka xchd-hdkz">
							<div class="swiper-wrapper go-hdmka-ys">
								<!--{loop $guiigo_config['appsetting']['forumconfig']['show_pyqhd'] $val}-->
									<div class="swiper-slide"><a href="$val['type2']"><img src="$val['type1']" alt="$val['extend1']"/></a></div>
								<!--{/loop}-->
							</div>
							<div class="swiper-pagination swiper-pagination-white swiper-r-box go-hdmka-xzfy"></div>
						</div>
					</div>
				<!--{/if}-->
				<!--{/if}-->
			<!--{else}-->
				<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_id']}-->
					<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forums_top_tyle'] == 1}-->
						<!--{subtemplate forum/forumdisplay_top_a}-->
					<!--{elseif $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forums_top_tyle'] == 2}-->
						<!--{subtemplate forum/forumdisplay_top_b}-->
					<!--{else}-->
						<!--{subtemplate forum/forumdisplay_top_a}-->
					<!--{/if}-->
				<!--{else}-->
					<!--{subtemplate forum/forumdisplay_top_a}-->
				<!--{/if}-->
			<!--{/if}-->

			<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
				<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
					<!--{if $_G['forum']['threadsorts']}--><!--{if $quicksearchlist && !$_GET['archiveid']}-->
					<div class="guiigo-cjdh-sx cl">
						<div class="cjdh-sx-a cl">
					<!--{/if}-->
					<!--{/if}-->
						<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-forumdisplay list-block-no mx-a xh-b bg-c">
							<ul class="swiper-wrapper">
								<!--{if !$_G['forum']['threadsorts']}-->
									<li class="swiper-slide{if !$_GET['typeid'] && !$_GET['sortid']} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz']);"><!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_style'] == 4}-->{lang guiigo_manage:tlang0420}<!--{else}-->{lang guiigo_manage:tlang0134}<!--{/if}--></a><span class="bg-b"></span></li>
									<!--{if $_G['forum']['threadtypes']}-->
									<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
									<!--{if $_GET['typeid'] == $id}-->
									<li class="swiper-slide swiper-slide-active"><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz']);">$name</a><span class="bg-b"></span></li>
									<!--{else}-->
									<li class="swiper-slide"><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz']);">$name</a><span class="bg-b"></span></li>
									<!--{/if}-->
									<!--{/loop}-->
									<!--{/if}-->
								<!--{/if}-->
								<!--{if $_G['forum']['threadsorts']}-->
									<!--{if $guiigo_config['appsetting']['forumconfig']['show_flqbzs']}-->
										<li class="swiper-slide{if !$_GET['typeid'] && !$_GET['sortid']} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz']);">{lang guiigo_manage:tlang0130}</a><span class="bg-b"></span></li>
									<!--{/if}-->
									<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
									<!--{if $_GET['sortid'] == $id}-->
										<li class="swiper-slide on"><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','gg-kz-sxsx']);">$name</a><span class="bg-b"></span></li>
									<!--{else}-->
										<li class="swiper-slide"><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}',['guiigo-kz-sxkz','gg-kz-sxsx']);">$name</a><span class="bg-b"></span></li>
									<!--{/if}-->
									<!--{/loop}-->
								<!--{/if}-->
							</ul>
							<!--{if $_G['forum']['threadsorts']}--><!--{if $quicksearchlist && !$_GET['archiveid']}-->
							<div class="cjdh-flfg bg-i"></div>
							<!--{/if}--><!--{/if}-->
						</div>
					</div>
					<!--{if $_G['forum']['threadsorts']}-->
					<!--{if $quicksearchlist && !$_GET['archiveid']}-->
					<div class="cjdh-sx-b cl">
						<a class="open-panel gg-sq-xxsx bg-c xh-b zy-e" data-panel=".panel-1" external><i class="icon guiigoapp-shaixuan zy-e"></i>{lang guiigo_manage:tlang0122}</a>
					</div>
				</div>
				<!--{/if}-->
				<!--{/if}-->
				<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<!--{/if}-->
			<!--{if $subexists && $_G['page'] == 1}-->
			<div class="gg-sq-ejbt bg-c sh-a xh-b zy-e">{lang guiigo_manage:tlang0135}</div>
			<div class="gg-sq-ejbks list-block-no mx-a bg-c">
				<ul>
					<!--{loop $sublist $sub}-->
					<!--{eval $forumurl = !empty($sub['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$sub['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$sub['fid'];}-->
					<li>
						<span class="yh-a xh-b">
							<!--{if $sub[icon]}-->
								<!--{eval $ejbkicon = str_replace('align="left"','',$sub[icon]);}-->
								$ejbkicon 
							<!--{else}-->
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png"/>
							<!--{/if}-->
							<p><a href="$forumurl" class="zy-f"><!--{echo cutstr($sub[name],8)}--></a></p>
						</span>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<div class="guiigo-kz-sxkz<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}--><!--{else}--> list-container gg-sq-pbly<!--{/if}-->">
			<!--{if !$subforumonly}-->
				<!--{if empty($_G['forum']['sortmode'])}-->
					<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
						<!--{if $_G['forum_threadcount']}-->
							<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_style'] == 4}-->
								<!--{if $guiigo_config['appsetting']['forumconfig']['show_pyqzg']}-->
									<div class="gg-sq-ggzd bg-c xh-b">
										<!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
										<div class="ggzd-ggnr xh-a">
											<!--{if empty($announcement['type'])}-->
											<a href="forum.php?mod=announcement&id=$announcement[id]">
												<span class="zy-c">$announcement[starttime]</span><i class="icon guiigoapp-gonggao zy-a bg-j"></i><em class="zy-h">$announcement[subject]</em>
											</a>
											<!--{else}-->
											<a href="$announcement[message]"><i class="icon guiigoapp-gonggao zy-a bg-j"></i><em class="zy-h">$announcement[subject]</em></a>
											<!--{/if}-->
										</div>
										<!--{/if}-->
										<!--{if $livethread}-->
											<div class="ggzd-ggnr xh-a">
												<a href="forum.php?mod=viewthread&tid=$livethread[tid]">
													<span class="zy-c">$livethread[replies]{lang guiigo_manage:tlang0148}</span><i class="icon guiigoapp-bofang zy-a bg-d"></i><em class="zy-h">$livethread[subject]</em>
												</a>
											</div>
										<!--{/if}-->
										<div class="ggzd-zdnr list-block-no">
											<ul>
											<!--{eval $isdisplayorder=0;}-->
											<!--{loop $_G['forum_threadlist'] $key $thread}-->
												<!--{if !$_thread['forumstick'] && $_thread['closed'] > 1 && ($_thread['isgroup'] == 1 || $_thread['fid'] != $_G['fid'])}-->
													<!--{eval $_thread[tid]=$_thread[closed];}-->
												<!--{/if}-->
												<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $_thread['displayorder'] > 0}-->
													<!--{eval continue;}-->
												<!--{/if}-->
												<!--{if $_thread['moved']}-->
													<!--{eval $_thread[tid]=$_thread[closed];}-->
												<!--{/if}-->
												<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
													<li class="xh-a listtop {if $isdisplayorder >= $guiigo_config['appsetting']['forumconfig']['show_top_unfold']}none{/if}">
														<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
															<span class="zy-c">$thread[author]</span>
															<i class="icon guiigoapp-zhiding zy-a{if $thread['displayorder'] == 1} bg-d{/if}{if $thread['displayorder'] == 2} bg-k{/if}{if $thread['displayorder'] == 3} bg-h{/if}{if $thread['displayorder'] == 4} bg-h{/if}"></i>
															<em class="zy-h">{$thread[subject]}</em>
														</a>
													</li>
												<!--{eval $isdisplayorder++;}-->
												<!--{/if}-->
											<!--{/loop}-->
											</ul>
										</div>
										<!--{if $isdisplayorder > $guiigo_config['appsetting']['forumconfig']['show_top_unfold']}-->
										<div class="ggzd-gdzk zy-c" onclick="display(this,'.listtop');">{lang guiigo_manage:tlang0136}<i class="icon guiigoapp-xxzk zy-c"></i></div>
										<!--{/if}-->
									</div>
								<!--{/if}-->
							<!--{else}-->
								<div class="gg-sq-ggzd bg-c xh-b">
									<!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
									<div class="ggzd-ggnr xh-a">
										<!--{if empty($announcement['type'])}-->
										<a href="forum.php?mod=announcement&id=$announcement[id]">
											<span class="zy-c">$announcement[starttime]</span><i class="icon guiigoapp-gonggao zy-a bg-j"></i><em class="zy-h">$announcement[subject]</em>
										</a>
										<!--{else}-->
										<a href="$announcement[message]"><i class="icon guiigoapp-gonggao zy-a bg-j"></i><em class="zy-h">$announcement[subject]</em></a>
										<!--{/if}-->
									</div>
									<!--{/if}-->
									<!--{if $livethread}-->
										<div class="ggzd-ggnr xh-a">
											<a href="forum.php?mod=viewthread&tid=$livethread[tid]">
												<span class="zy-c">$livethread[replies]{lang guiigo_manage:tlang0148}</span><i class="icon guiigoapp-bofang zy-a bg-d"></i><em class="zy-h">$livethread[subject]</em>
											</a>
										</div>
									<!--{/if}-->
									<div class="ggzd-zdnr list-block-no">
										<ul>
										<!--{eval $isdisplayorder=0;}-->
										<!--{loop $_G['forum_threadlist'] $key $thread}-->
											<!--{if !$_thread['forumstick'] && $_thread['closed'] > 1 && ($_thread['isgroup'] == 1 || $_thread['fid'] != $_G['fid'])}-->
												<!--{eval $_thread[tid]=$_thread[closed];}-->
											<!--{/if}-->
											<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $_thread['displayorder'] > 0}-->
												<!--{eval continue;}-->
											<!--{/if}-->
											<!--{if $_thread['moved']}-->
												<!--{eval $_thread[tid]=$_thread[closed];}-->
											<!--{/if}-->
											<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
												<li class="xh-a listtop {if $isdisplayorder >= $guiigo_config['appsetting']['forumconfig']['show_top_unfold']}none{/if}">
													<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
														<span class="zy-c">$thread[author]</span>
														<i class="icon guiigoapp-zhiding zy-a{if $thread['displayorder'] == 1} bg-d{/if}{if $thread['displayorder'] == 2} bg-k{/if}{if $thread['displayorder'] == 3} bg-h{/if}{if $thread['displayorder'] == 4} bg-h{/if}"></i>
														<em class="zy-h">{$thread[subject]}</em>
													</a>
												</li>
											<!--{eval $isdisplayorder++;}-->
											<!--{/if}-->
										<!--{/loop}-->
										</ul>
									</div>
									<!--{if $isdisplayorder > $guiigo_config['appsetting']['forumconfig']['show_top_unfold']}-->
									<div class="ggzd-gdzk zy-c" onclick="display(this,'.listtop');">{lang guiigo_manage:tlang0136}<i class="icon guiigoapp-xxzk zy-c"></i></div>
									<!--{/if}-->
								</div>
							<!--{/if}-->	
							<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_id']}-->
								<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_style'] == 1}-->
									<!--{subtemplate forum/forumdisplay_list_a}-->
								<!--{elseif $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_style'] == 2}-->
									<!--{subtemplate forum/forumdisplay_list_b}-->
								<!--{elseif $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_style'] == 3}-->
									<!--{subtemplate forum/forumdisplay_list_c}-->
								<!--{elseif $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_style'] == 4}-->
									<!--{subtemplate forum/forumdisplay_list_d}-->
							    <!--{else}-->
							    	<!--{subtemplate forum/forumdisplay_list_a}-->
							    <!--{/if}-->
							<!--{else}-->
								<!--{subtemplate forum/forumdisplay_list_a}-->
							<!--{/if}-->
							<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
								<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
							</div>
						<!--{else}-->
							<div class="guiigo-wnrtx">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
								<p class="zy-c">{lang guiigo_manage:tlang0145}</p>
							</div>
						<!--{/if}-->
					<!--{else}-->
						<!--{if $_G['forum_threadcount']}-->	
							<div id="waterfall" class="gg-sq-pbkz cl">
								<!--{loop $_G['forum_threadlist'] $key $thread}-->
									<!--{if $thread['hidden']}-->
										<!--{eval continue;}-->
									<!--{/if}-->
									<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
										<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
											<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
									<!--{/if}-->
									<!--{if $thread['moved']}-->
										<!--{eval $thread[tid]=$thread[closed];}-->
									<!--{/if}-->
									<div class="ck8-water-items mx-a bg-c bk-e" ck-cus="water" id="thread_{$thread[tid]}">
										<div class="pic">
											<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
											<!--{if $thread['cover']}-->
											<img lazySrc="$thread[coverpath]" 
												src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" 
												class="ck8-lazy vimg_{$thread[tid]} vm" 
												/>
											<!--{else}-->
											<img lazySrc="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-mrxc.png" 
												src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" 
												class="ck8-lazy vm"/>
											<!--{/if}-->
											</a>
										</div>
										<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" $thread[highlight] class="subject zy-e">
											<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><!--{elseif $thread['digest'] > 0}-->
												<i class="zy-i">{lang guiigo_manage:tlang0221}</i>
											<!--{/if}-->
											$thread[subject]
										</a>
										<div id="Templ_{$thread[tid]}">
										<div class="repliesauth row no-gutter">
											<div class="user">
												<!--{if $thread['authorid'] && $thread['author']}-->
													<span class="avatar">
														<!--{eval echo avatar($thread['authorid'],'small');}-->
														<a href="home.php?mod=space&uid=$thread[authorid]" class="zy-c">$thread[author]</a>
													</span>
												<!--{else}-->
													<span class="avatar">
														<a href="javascript:;" class="zy-c">$_G[setting][anonymoustext]</a>
													</span>
												<!--{/if}-->
											</div>
											<div class="replies">
												<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
													<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="like zy-c"><i class="icon guiigoapp-nydbpl"></i>$thread[replies]</a>
												 <!--{/if}-->
											</div>
										</div>
										</div>
									</div>
								<!--{/loop}-->
							</div>
							<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
								<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
							</div>
						<!--{else}-->
							<div class="guiigo-wnrtx">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
								<p class="zy-c">{lang guiigo_manage:tlang0145}</p>
							</div>
						<!--{/if}-->
					<!--{/if}-->
				<!--{else}-->
					<div class="guiigo-wapf bg-c">
						<ul class="list-container">
							<!--{eval echo str_replace(array("{lang guiigo_manage:tlang0893}&nbsp;","{lang guiigo_manage:tlang0894}&nbsp;","{lang guiigo_manage:tlang0895}&nbsp;","{lang guiigo_manage:tlang0896}&nbsp;","{lang guiigo_manage:tlang0897}&nbsp;","{lang guiigo_manage:tlang0898}&nbsp;","{lang guiigo_manage:tlang0899}&nbsp;","{lang guiigo_manage:tlang0900}&nbsp;","{lang guiigo_manage:tlang0901}&nbsp;","{lang guiigo_manage:tlang0902}&nbsp;","{lang guiigo_manage:tlang0903}&nbsp;","{lang guiigo_manage:tlang0904}&nbsp;","{lang guiigo_manage:tlang0905}&nbsp;","{lang guiigo_manage:tlang0906}&nbsp;","{lang guiigo_manage:tlang0907}&nbsp;","{lang guiigo_manage:tlang0908}&nbsp;","{lang guiigo_manage:tlang0909}&nbsp;","{lang guiigo_manage:tlang0910}&nbsp;","{lang guiigo_manage:tlang0911}&nbsp;","{lang guiigo_manage:tlang0912}&nbsp;","{lang guiigo_manage:tlang0913}&nbsp;","{lang guiigo_manage:tlang0914}&nbsp;","{lang guiigo_manage:tlang0915}&nbsp;","{lang guiigo_manage:tlang0916}&nbsp;","{lang guiigo_manage:tlang0917}&nbsp;","{lang guiigo_manage:tlang0918}&nbsp;","{lang guiigo_manage:tlang0919}&nbsp;","{lang guiigo_manage:tlang0920}&nbsp;","{lang guiigo_manage:tlang0921}&nbsp;","{lang guiigo_manage:tlang0922}&nbsp;"),array("<i>{lang guiigo_manage:tlang0893}</i>","<i>{lang guiigo_manage:tlang0894}</i>","<i>{lang guiigo_manage:tlang0895}</i>","<i>{lang guiigo_manage:tlang0896}</i>","<i>{lang guiigo_manage:tlang0897}</i>","<i>{lang guiigo_manage:tlang0898}</i>","<i>{lang guiigo_manage:tlang0899}</i>","<i>{lang guiigo_manage:tlang0900}</i>","<i>{lang guiigo_manage:tlang0901}</i>","<i>{lang guiigo_manage:tlang0902}</i>","<i>{lang guiigo_manage:tlang0903}</i>","<i>{lang guiigo_manage:tlang0904}</i>","<i>{lang guiigo_manage:tlang0905}</i>","<i>{lang guiigo_manage:tlang0906}</i>","<i>{lang guiigo_manage:tlang0907}</i>","<i>{lang guiigo_manage:tlang0908}</i>","<i>{lang guiigo_manage:tlang0909}</i>","<i>{lang guiigo_manage:tlang0910}</i>","<i>{lang guiigo_manage:tlang0911}</i>","<i>{lang guiigo_manage:tlang0912}</i>","<i>{lang guiigo_manage:tlang0913}</i>","<i>{lang guiigo_manage:tlang0914}</i>","<i>{lang guiigo_manage:tlang0915}</i>","<i>{lang guiigo_manage:tlang0916}</i>","<i>{lang guiigo_manage:tlang0917}</i>","<i>{lang guiigo_manage:tlang0918}</i>","<i>{lang guiigo_manage:tlang0919}</i>","<i>{lang guiigo_manage:tlang0920}</i>","<i>{lang guiigo_manage:tlang0921}</i>","<i>{lang guiigo_manage:tlang0922}</i>"),$sorttemplate['body']);}-->
						</ul>
					</div>
					<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
						<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
					</div>
				<!--{/if}-->
			<!--{/if}-->
			</div>
			<!--{hook/forumdisplay_bottom_mobile}-->
			$guiigo_config['footer_html']
		</div>
	</div>
<script>
function MsgCallPostFavcForum(msg,par){
	var favor = ck8('#post_favc_forum_');
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1){
			ck8('#post_favc_forum_').attr('href','home.php?mod=spacecp&ac=favorite&type=forum&id='+ par.id +'&handlekey=favoriteforum&formhash={FORMHASH}').addClass('posonts ab-f').removeClass('posonts-off ab-b').html('{lang guiigo_manage:tlang0024}');
			ck8.toast('{lang guiigo_manage:tlang0009}');
			app.PageRefresh('','xgsj-gzhy','forum.php?mod=forumdisplay&fid=$_GET[fid]')
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0014}') != -1){
			favor.attr('href','home.php?mod=spacecp&ac=favorite&op=delete&type=forum&favid='+ par.favid +'&&fn=MsgCallPostFavcForum').addClass('posonts-off ab-b').removeClass('posonts ab-f').html('{lang guiigo_manage:tlang0003}');
			ck8.toast('{lang guiigo_manage:tlang0003}');
			app.PageRefresh('','xgsj-gzhy','forum.php?mod=forumdisplay&fid=$_GET[fid]')
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0018}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0020}');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0021}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0022}');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0023}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0020}');
		}else {
			ck8.toast(msg.msg);
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0146}');
	}
}
function MsgCallFn(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = $('.followmod_'+ par.fuid +'');
		var foObj = $('#recommend_add_'+ param.tid +'');
		var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
			$.toast('{lang guiigo_manage:tlang0003}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
			Obj.attr('ck-confirm','true')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			$.toast('{lang guiigo_manage:tlang0009}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
			Obj.attr('ck-confirm','false')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			$.toast('{lang guiigo_manage:tlang0007}');
		}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
			foObj.addClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzanon"></i>');
			$('#recommend_add_sum'+ param.tid).html(''+ (recommendcut + parseInt(par.recommendv)));
			foObj.find('a').addClass('delRecommenus').removeClass('dialog').attr('href','plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid='+ param.tid)
			$.toast('{lang guiigo_manage:tlang0045}');
			if(par.daycount){
				setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
			}
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
			$.toast('{lang guiigo_manage:tlang0049}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
			$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
				$.router.load('home.php?mod=spacecp&ac=usergroup');
			});
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
			$.toast('{lang guiigo_manage:tlang0053}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
			$.toast('{lang guiigo_manage:tlang0055}');
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}

function MsgCallFnp(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = $('.followmod_'+ par.fuid +'');
		var foObj = $('#recommendp_add_'+ param.tid +'');
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
			$.toast('{lang guiigo_manage:tlang0003}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('bg-e zy-g').removeClass('bg-j zy-a').html('{lang guiigo_manage:tlang0003}')
			Obj.attr('ck-confirm','true')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			$.toast('{lang guiigo_manage:tlang0009}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('bg-j zy-a').removeClass('bg-e zy-g').html('+ {lang guiigo_manage:tlang0002}')
			Obj.attr('ck-confirm','false')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			$.toast('{lang guiigo_manage:tlang0007}');
		}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
			foObj.find('a').html('<i class="icon guiigoapp-aixin1 zy-i"></i>{lang guiigo_manage:tlang1042}');
			foObj.find('a').addClass('delRecommenus').removeClass('dialog').attr('href','plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid='+ param.tid)
			$.toast('{lang guiigo_manage:tlang0045}');
			if(par.daycount){
				setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
			}
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
			$.toast('{lang guiigo_manage:tlang0049}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
			$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
				$.router.load('home.php?mod=spacecp&ac=usergroup');
			});
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
			$.toast('{lang guiigo_manage:tlang0053}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
			$.toast('{lang guiigo_manage:tlang0055}');
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}
</script>
</div>
<!--{template common/footer}-->

