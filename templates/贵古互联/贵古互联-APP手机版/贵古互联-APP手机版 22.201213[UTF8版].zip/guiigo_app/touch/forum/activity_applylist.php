<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="applylistform gg-sq-hdgl">
<form id="applylistform" 
	method="post" 
	autocomplete="off" 
	action="forum.php?mod=misc&action=activityapplylist&tid=$_G[tid]&applylistsubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}" 
	ck-cus="true"
	ck-param="{type:'popup',callpar:{pid:'$_G[pid]',type:'applylistform'},fn:{if $_GET['fn']}'$_GET['fn']'{/if},load:'true',title:{if $isactivitymaster}'{lang activity_applylist_manage}'{else}'{lang activity_applylist}'{/if},height:'100%',uid:'$_G[uid]' }">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="operation" value="" />
	<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
	<!--{if $applylist}-->
	<div class="hdgl-yhsj bg-c sh-a xh-b">
		<ul>
			<!--{loop $applylist $apply}-->
				<li class="xh-b">
					<!--{if $isactivitymaster}-->
					<!--{if $apply[uid] != $_G[uid]}-->
						<label class="label-checkbox checkbox guiigo-pd">
							<input type="checkbox" class="guiigo-pd-k" name="applyidarray[]" value="$apply[applyid]"/>
							<span></span>
						</label>
					<!--{else}-->
					&nbsp;&nbsp;
					<!--{/if}-->
					<!--{/if}-->
					<div class="yhsj-yhim">
						<a href="home.php?mod=space&uid=$apply[uid]" class="guiigo-ty"><!--{avatar($apply[uid],middle)}--></a>
					</div>
					<div class="yhsj-mcjj">
						<a href="home.php?mod=space&uid=$apply[uid]" class="zy-h">$apply[username]</a>
						<p class="zy-c">$apply[dateline]</p>
					</div>
					<a href="javascript:;" id="showmenu_$apply[uid]" class="jdxx-zkqt icon guiigoapp-xxzk bk-a bg-e zy-c" onclick="_showMenu($apply[uid]);"></a>
					<!--{if $isactivitymaster}-->
						<div class="jdxx-dqzt zy-c">
							<!--{if $apply[verified] == 1}-->
								<i class="icon guiigoapp-hd-yx zy-o"></i>{lang activity_allow_join}
							<!--{elseif $apply[verified] == 2}-->
								<i class="icon guiigoapp-hd-dd zy-n"></i>{lang activity_do_replenish}
							<!--{else}-->
								<i class="icon guiigoapp-hd-ws zy-i"></i>{lang activity_cant_audit}
							<!--{/if}-->
						</div>
					<!--{/if}-->
					<div class="yhsj-kzhl ms-a bg-e bk-e" id="actl_$apply[uid]_menu" style="display:none;">
						<ul>
							<!--{eval $ufielddata=str_replace('&nbsp;','',$apply[ufielddata]);}-->
							$ufielddata
							<!--{if $activity['cost']}-->
							<li>{lang guiigo_manage:tlang0096}:<!--{if $apply[payment] >= 0}-->$apply[payment] {lang payment_unit}<!--{else}-->{lang activity_self}<!--{/if}--></li>
							<!--{/if}-->
							<li>{lang guiigo_manage:tlang0097}:<!--{if $apply[message]}-->$apply[message]<!--{else}-->{lang guiigo_manage:tlang0098}<!--{/if}--></li>
						</ul>
					</div>
				</li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{else}-->
		<div class="guiigo-wnrtx">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
			<p class="zy-c">{lang guiigo_manage:tlang0099}</p>
		</div>
	<!--{/if}-->
	<!--{if $isactivitymaster}-->
		<div class="hdgl-qspt bg-c">
			<div class="qspt-qxfy guiigo-flex">
				<label class="label-checkbox checkbox guiigo-pd" onclick="checkall(this.form, 'applyid')">
					<input type="checkbox" class="guiigo-pd-k" name="chkall"/>
					<em class="item-title">{lang checkall}</em>
				</label>
				<input type="text" name="reason" class="guiigo-px guiigo-flexy bg-e bk-e" placeholder="{lang activity_ps}" maxlength="20"/>
			</div>
			<div class="qspt-pxfj">
				<button class="guiigo-pn ab-f zy-a zy-ac formdialog" type="submit" value="true" name="applylistsubmit">{lang confirm}</button>
				<button class="guiigo-pn ab-b zy-a formdialog" type="submit" value="true" name="applylistsubmit" onclick="Dz('applylistform').operation.value='replenish';">{lang to_improve}</button>
				<button class="guiigo-pn ab-b zy-a formdialog" type="submit" value="true" name="applylistsubmit" onclick="Dz('applylistform').operation.value='notification';">{lang send_notification}</button>
				<button class="guiigo-pn ab-b zy-a formdialog" type="submit" value="true" name="applylistsubmit" onclick="Dz('applylistform').operation.value='delete';">{lang activity_refuse}</button>
			</div>
		</div>
	<!--{/if}-->
</form>
<script>
	function _showMenu(id) {
		var obj = ck8('#actl_'+ id +'_menu')
		if(obj.css('display') == 'none'){
			ck8('.dpbtnhide').css({'display':'none'})
			ck8('#showmenu_'+ id).removeClass('guiigoapp-xxzk').addClass('guiigoapp-xszk')
			obj.css({'display':'block'}).find('li').off('click').on('click',function(){
				obj.css({'display':'none'})
				ck8('#showmenu_'+ id).removeClass('guiigoapp-xszk').addClass('guiigoapp-xxzk')
			})
		}else if(obj.css('display') == 'block'){
			obj.css({'display':'none'})
			ck8('#showmenu_'+ id).removeClass('guiigoapp-xszk').addClass('guiigoapp-xxzk')
		}
	}
</script>
</div>
<!--{template common/footer}-->