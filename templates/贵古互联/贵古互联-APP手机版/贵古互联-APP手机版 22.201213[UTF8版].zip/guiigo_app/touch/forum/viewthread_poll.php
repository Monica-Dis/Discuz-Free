<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
$post[message]
<div class="gg-sq-poll sh-a">
	<form id="poll" 
	name="poll" 
	method="post" 
	autocomplete="off" 
	action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes"
	ck-cus="true"
	ck-param="{type:'modal',callpar:{tid:'$_G[tid]',type:'poll'},fn:'MsgCallInvite',load:'true',uid:'$_G[uid]'}"
	>
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="poll-btys">
			<div class="btys-icon"><i class="icon guiigoapp-toupiao zy-a"></i></div>
			<div class="btys-btnr">
				<h2 class="zy-h"><!--{if $multiple}-->{lang poll_multiple}{lang thread_poll}<!--{if $maxchoices}--><span class="zy-g">{lang poll_more_than}</span><!--{/if}--><!--{else}-->{lang poll_single}{lang thread_poll}<!--{/if}--></h2>
				<p class="zy-c">{lang poll_voterscount}<!--{if $visiblepoll && $_G['group']['allowvote']}--> {lang poll_after_result}<!--{/if}--></p>
				<!--{if !$visiblepoll && ($overt || $_G['adminid'] == 1 || $thread['authorid'] == $_G['uid']) && $post['invisible'] == 0}-->
				<a href="forum.php?mod=misc&action=viewvote&tid=$_G[tid]" class="bk-a zy-l" data-no-cache="true"><i class="icon guiigoapp-tbgrzx"></i>{lang guiigo_manage:tlang0394}</a>
				<!--{/if}-->
			</div>
		</div>
		<!--{if $_G[forum_thread][remaintime]}-->
		<div class="poll-tpjs bg-g zy-f">
			{lang poll_count_down}: 
			<!--{eval $date = GuiigoApp::DateFormatting($_G[forum_thread][remaintime]);}-->
			<div class="data-timer zy-h" data-timer="$date" data-timer-id="poll_$post[pid]" data-timer-status="false"></div>
		</div>
		<!--{elseif $expiration && $expirations < TIMESTAMP}-->
		<div class="poll-tpjs bg-g zy-h">{lang poll_end}</div>
		<!--{/if}-->
		<div id="poll-on">
			<!--{if $isimagepoll}-->
				<div class="poll-yttp cl">
				<!--{eval $i = 0;}-->
				<!--{loop $polloptions $key $option}-->
				<!--{eval $i++;}-->
				<!--{eval $imginfo=$option['imginfo'];}-->
					<div id="polloption_$option[polloptionid]">
						<div class="yttp-tpsj bk-e cl">
							<!--{if $imginfo}-->
								<img lazySrc="$imginfo[small]" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
							<!--{else}-->
								<img lazySrc="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-wt.jpg" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
							<!--{/if}-->
							<!--{if $_G['group']['allowvote']}-->
							<div class="tpsj-tpxz zy-e">
								<label class="<!--{if $optiontype == radio}-->guiigo-pds<!--{else}-->guiigo-pd<!--{/if}-->">
									<input class="guiigo-pd-k" type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]"/>
									<span></span>
									$option[polloption]
								</label>
							</div>
							<!--{/if}-->
							<!--{if !$visiblepoll}-->
							<div class="tpsj-tpjd bg-i<!--{if !$_G['group']['allowvote']}--> ms-a<!--{/if}-->">
								<span class="jdt" style="width: $option[width]; background-color:#$option[color]"></span>
								<p class="imgfc zy-a">
									<span class="z">$option[votes]{lang debate_poll}</span>
									<span class="y">{$option[percent]}% </span>
								</p>
							</div>
							<!--{/if}-->
						</div>
					</div>
				<!--{/loop}-->
				</div>
			<!--{else}-->
				<div class="poll-wttp cl">
				<!--{loop $polloptions $key $option}-->
					<div class="wttp-tpsj">
						<div class="tpsj-tpxz zy-e">
						<!--{if $_G['group']['allowvote']}-->
							<label class="<!--{if $optiontype == radio}-->guiigo-pds<!--{else}-->guiigo-pd<!--{/if}-->">
								<input class="guiigo-pd-k" type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]"/>
								<span></span>
								$option[polloption]
							</label>
						<!--{else}-->
							<p>$option[polloption]</p>
						<!--{/if}-->
						</div>
					<!--{if !$visiblepoll}-->
						<div class="tpsj-tpjd cl">
							<div class="tpjd-jdta bg-e">
								<div class="tpjd-jdtb" style="width: $option[width]; background-color:#$option[color]"></div>
							</div>
							<div class="tpjd-tpsz" style="color:#$option[color]">$option[percent]% ($option[votes])</div>
						</div>
					<!--{/if}-->
					</div>
				<!--{/loop}-->
				</div>
			<!--{/if}-->
			<!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
				<button class="formdialog guiigo-pn ms-b ab-az zy-a zy-ac" type="submit" name="pollsubmit" id="pollsubmit" value="true">{lang submit}</button>
				<!--{if $overt}-->
					<div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang poll_msg_overt}</div>
				<!--{/if}-->
			<!--{elseif !$allwvoteusergroup}-->
				<div class="gg-sq-wdlfj ms-b bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang poll_msg_allwvoteusergroup}</div>
			<!--{elseif !$allowvotepolled}-->
				<div class="gg-sq-wdlfj ms-b bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang poll_msg_allowvotepolled}</div>
			<!--{elseif !$allowvotethread}-->
				<div class="gg-sq-wdlfj ms-b bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang poll_msg_allowvotethread}</div>
			<!--{/if}-->
		</div>
	</form>
</div>