<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';</script>
<div class="page page-current" data-mod="announcement">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="javascript:;" onclick="app.ActionsManage('#actions_1','b', 'auto');" class="button button-link pull-right"><i class="icon guiigoapp-mkbtgd zy-f"></i></a>
		<h1 class="title zy-h">{lang announcement}</h1>
	</header>
	<div class="content announcement-scroll">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="popup-actions" id="actions_1">
				<div class="actions-text gg-sq-ztsx">
					<a href="javascript:;" class="ztsx_sxbt bg-c xh-b zy-e cl">{lang guiigo_manage:tlang0100}<i class="icon guiigoapp-guanbi zy-c"></i></a>
					<div class="ztsx_sxnr list-block-no bg-c cl">
						<ul class="sxnr_jgul cl">
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.announcement-scroll','forum.php?mod=announcement',['gg-gg-ggon','ztsx_sxnr']);" class="xi1{if empty($_GET[m])} xw1{/if}">{lang all}</a></li>
							<!--{loop $months $month}-->
							<li><a href="javascript:;" onclick="app.LoadPageForumView('.announcement-scroll','forum.php?mod=announcement&m=$month[0].$month[1]',['gg-gg-ggon','ztsx_sxnr']);" class="xi1{if $_GET[m] == $month[0].$month[1]} xw1{/if}">$month[0] {lang year} $month[1] {lang month}</a></li>
							<!--{/loop}-->
						</ul>
					</div>
				</div>
			</div>
			<div class="gg-gg-ggon ms-a bg-c sh-a">
				<ul>
					<!--{loop $announcelist $ann}-->
						<li class="xh-b">
							<div id="announce$ann[id]_c" class="umh{if $messageid != $ann[id]} umn{/if}">
								<a href="javascript:;" onclick="toggle_collapse('announce$ann[id]', 1, 1);">$ann[subject]</a>
							</div>
							<div class="ggon-zzrq">
								<p class="zy-c">{lang author}: <a href="home.php?mod=space&username=$ann[authorenc]" class="zy-l">$ann[author]</a></p>
								<em class="zy-c">$ann[starttime]</em>
							</div>
							<div id="announce$ann[id]" class="um bg-p bk-d zy-f" style="display: none">
								$ann[message]
							</div>
						</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	</div>
	<script type="text/javascript">
	<!--{if !empty($annid)}-->
	ck8(function(){
		toggle_collapse('announce$annid', 1, 1);
	})
	<!--{/if}-->
	</script>
</div>
<!--{template common/footer}-->