<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="printable">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0398}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{eval $recommend_users = DB::fetch_all("SELECT a.recommenduid,a.dateline,b.username,b.uid FROM ".DB::table('forum_memberrecommend')." a LEFT JOIN ".DB::table('common_member')." b on b.uid=a.recommenduid WHERE a.`tid` = '$_G[tid]' AND b.`status`=0 ORDER BY a.`dateline` DESC LIMIT 0,20000");}-->
			<div class="guiigo-hylb list-block-no ms-a sh-a xh-b bg-c">
				<ul class="ms-c">
				<!--{if $recommend_users}-->
				<!--{loop $recommend_users $rdu}-->
					<li class="sh-a">
						<a href="home.php?mod=space&uid={$rdu['uid']}&do=profile" class="hylb-ls hylb-ds"><img src="uc_server/avatar.php?uid={$rdu['uid']}&size=middle" class="guiigo-ty"><i class="icon guiigoapp-xzdk zy-g"></i>
							<h2 class="hylb-bt zy-h">{$rdu['username']}</h2>
							<p class="hylb-jj zy-g">{echo date("Y-m-d H:i",$rdu['dateline'])}</p>
						</a>
					</li>
				<!--{/loop}-->
				<!--{/if}-->
				</ul>
			</div>
		</div>
	</div>
</div>
<!--{template common/footer}-->