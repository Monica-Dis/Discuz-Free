<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="debate-umpire">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang debate_umpirecomment}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<form method="post" 
			autocomplete="off" 
			id="postform" 
			name="postform" 
			action="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&umpiresubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{tid:'$_G[tid]',pid:'$_GET[pid]',type:'postform'},fn:'MsgCallDeumre',load:'true',uid:'$_G[uid]'}"
			>
				<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
				<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
				<div id="umpore-on" class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0108}</div>
							<div class="wblb-wbnr">
								<label class="guiigo-pds"><input type="radio" name="winner" value="1" class="guiigo-pd-k" $winnerchecked[1] id="winner1" /><span></span>{lang debate_square}</label>
								<label class="guiigo-pds"><input type="radio" name="winner" value="2" class="guiigo-pd-k" $winnerchecked[2] id="winner2" /><span></span>{lang debate_opponent}</label>
								<label class="guiigo-pds"><input type="radio" name="winner" value="3" class="guiigo-pd-k" $winnerchecked[3] id="winner3" /><span></span>{lang debate_draw}</label>
							</div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang debate_bestdebater}</div>
							<div class="wblb-wbnr zy-h">
								<input type="text" class="guiigo-ps s-a select-picker" value="{lang debate_recommend_list}" data-select="debateumpire" />
								<select onchange="$('bestdebater').value=this.options[this.options.selectedIndex].value" id="debateumpire" style="display:none;">
									<option value=""><strong>{lang debate_recommend_list}</strong></option>
									<option value="">------------------------------</option>
									<!--{loop $candidates $candidate}-->
										<option value="$candidate[username]"{if $candidate[username] == $debate[bestdebater]} selected="selected"{/if}>$candidate[username] ( $candidate[voters] {lang debate_poll}, <!--{if $candidate[stand] == 1}-->{lang debate_square}<!--{elseif $candidate[stand] == 2}-->{lang debate_opponent}<!--{/if}-->)</option>
									<!--{/loop}-->
								</select>
							</div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang debate_bestdebater}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="bestdebater" id="bestdebater" class="guiigo-px s-a" value="$debate[bestdebater]" autocomplete="off" placeholder="{lang debate_list_nonexistence}"/></div>
						</li>
						<li class="wblb-dkbt bg-g xh-b zy-c cl">
							{lang debate_umpirepoint}
						</li>
						<li class="wblb-nrsr xh-b zy-h cl">
							<div class="wblb-wbnr zy-h"><textarea id="umpirepoint" name="umpirepoint" class="guiigo-pt s-a" placeholder="{lang guiigo_manage:tlang0109}">$debate[umpirepoint]</textarea></div>
						</li>
					</ul>
				</div>
				<div class="mn-a">
					<button class="guiigo-pn ab-az zy-a zy-ac formdialog" type="submit" name="umpiresubmit" value="true">{lang submit}</button>
				</div>
			</form>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript" reload="1">
		<!--{if !empty($_GET['infloat'])}-->
		function succeedhandle_$_GET['handlekey'](locationhref) {
			<!--{if !empty($_GET['from'])}-->
				location.href = locationhref;
			<!--{else}-->
				ajaxget('forum.php?mod=viewthread&tid=$_G[tid]&viewpid=$_GET[pid]', 'post_$_GET[pid]');
				hideWindow('$_GET['handlekey']');
			<!--{/if}-->
		}
		<!--{/if}-->
		function MsgCallDeumre(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0110}') != -1 && param.type == 'postform'){
					ck8.toast('{lang guiigo_manage:tlang0110}');
					app.PageRefresh(false,'#umpore-on','forum.php?mod=misc&action=debateumpire&tid='+ param.tid +'&pid='+ param.pid)
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}
	</script>
</div>
<!--{template common/footer}-->