<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="list-block guiigo-adsz">
    <div id="append_highlight_color"></div>
    <div id="append_highlight_bgcolor_ctrl"></div>
	<form id="moderateform" 
		method="post" 
		autocomplete="off" 
		action="forum.php?mod=topicadmin&action=moderate&optgroup=$optgroup&modsubmit=yes&infloat=yes"
		ck-cus="true"
		<!--{if $_GET['optgroup'] == 2 && !$typeselect && $operation == 'type'}-->
		    ck-param="{type:'modal',callpar:{optgroup:'$_GET[optgroup]',pid:'$_GET[fnpid]'},fn:'{if $_GET['fn']}$_GET['fn']{/if}',load:'true',title:'{lang guiigo_manage:tlang0319}',cancel:'{lang guiigo_manage:tlang0105}'}"
		<!--{else}-->
		    ck-param="{type:'modal',callpar:{optgroup:'$_GET[optgroup]',pid:'$_GET[fnpid]'},fn:'{if $_GET['fn']}$_GET['fn']{/if}',load:'true',title:'{lang guiigo_manage:tlang0319}'}"
		<!--{/if}-->>
		<input type="hidden" name="frommodcp" value="$frommodcp" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="fid" value="$_G[fid]" />
		<input type="hidden" name="redirect" value="{echo dreferer()}" />
		<!--{if !empty($_GET['listextra'])}--><input type="hidden" name="listextra" value="$_GET['listextra']" /><!--{/if}-->
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
		<!--{loop $threadlist $thread}-->
			<input type="hidden" name="moderate[]" value="$thread[tid]" />
		<!--{/loop}-->
		<!--{if $_GET['optgroup'] == 1}-->
		    <!--{if count($threadlist) > 1 || empty($defaultcheck[recommend])}-->
			<!--{if $_G['group']['allowstickthread']}-->
			<div id="itemcp_stick">
				
				<div class="adsz-szxm guiigo-flex">
					<label class="guiigo-pds">
						<div class="szxm-xmbt zy-c">
							<input type="checkbox" name="operations[]" class="guiigo-pd-k" value="stick" $defaultcheck[stick] />
							<span></span><em class="zy-h">{lang guiigo_manage:tlang0320}</em>
						</div>
					</label>
					<div class="szxm-xmnr szxm-xzys guiigo-flexy">
						<input type="text" class="guiigo-ps s-a zy-f select-picker" value="{lang guiigo_manage:tlang0321}" data-select="topicadminzd" />
						<select id="topicadminzd" name="sticklevel" style="display:none;">
							<!--{if $_G['forum']['status'] != 3}-->
								<option value="0">{lang guiigo_manage:tlang0321}</option>
								<option value="1" $stickcheck[1]>$_G['setting']['threadsticky'][2]</option>
								<!--{if $_G['group']['allowstickthread'] >= 2}-->
									<option value="2" $stickcheck[2]>$_G['setting']['threadsticky'][1]</option>
									<!--{if $_G['group']['allowstickthread'] == 3}-->
										<option value="3" $stickcheck[3]>$_G['setting']['threadsticky'][0]</option>
									<!--{/if}-->
								<!--{/if}-->
							<!--{else}-->
								<option value="0">{lang no}&nbsp;</option>
								<option value="1" $stickcheck[1]>{lang yes}&nbsp;</option>
							<!--{/if}-->
						</select>
					</div>
				</div>
				<div class="adsz-szxm guiigo-flex ms-a" style="margin-left: 0.85rem;">
					<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0322}</div>
					<div class="szxm-xmnr szxm-dsrk guiigo-flexy">
						<input type="text" placeholder="{lang guiigo_manage:tlang0323}" id="expirationstick" name="expirationstick" class="guiigo-px bg-e" value="$expirationstick"/>
					</div>
				</div>
			</div>
			<!--{/if}-->
			<!--{if $_G['group']['allowdigestthread']}-->
			<div id="itemcp_digest">
				<div class="adsz-szxm guiigo-flex ms-a">
					<label class="guiigo-pds">
						<div class="szxm-xmbt zy-c">
							<input type="checkbox" name="operations[]" class="guiigo-pd-k" value="digest" $defaultcheck[digest] />
							<span></span><em class="zy-h">{lang guiigo_manage:tlang0324}</em>
						</div>
					</label>
					<div class="szxm-xmnr szxm-xzys guiigo-flexy">
						<input type="text" class="guiigo-ps s-a zy-f select-picker" value="{lang admin_digest_remove}" data-select="topicadminjh" />
						<select id="topicadminjh" name="digestlevel" style="display:none;">
							<option value="0">{lang admin_digest_remove}</option>
							<option value="1" $digestcheck[1]>{lang thread_digest} 1</option>
							<!--{if $_G['group']['allowdigestthread'] >= 2}-->
								<option value="2" $digestcheck[2]>{lang thread_digest} 2</option>
								<!--{if $_G['group']['allowdigestthread'] == 3}-->
									<option value="3" $digestcheck[3]>{lang thread_digest} 3</option>
								<!--{/if}-->
							<!--{/if}-->
						</select>
					</div>
				</div>
				<div class="adsz-szxm guiigo-flex ms-a" style="margin-left: 0.85rem;">
					<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0325}</div>
					<div class="szxm-xmnr szxm-dsrk guiigo-flexy">
						<input type="text" placeholder="{lang guiigo_manage:tlang0323}" name="expirationdigest" id="expirationdigest" class="guiigo-px bg-e" value="$expirationdigest"/>
					</div>
				</div>
			</div>
			<!--{/if}-->
			<!--{if $_G['group']['allowbumpthread']}-->
			<div id="itemcp_bump">
				<div class="adsz-szxm guiigo-flex ms-a">
					<label class="guiigo-pds">
						<div class="szxm-xmbt zy-c">
							<input type="checkbox" name="operations[]" class="guiigo-pd-k" value="bump" $defaultcheck[bump] />
							<span></span><em class="zy-h">{lang guiigo_manage:tlang0326}</em>
						</div>
					</label>
				</div>	
				<div class="adsz-szxm guiigo-flex ms-a" style="margin-left: 0.85rem;">
					<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0327}</div>
					<div class="szxm-xmnr szxm-dsrk guiigo-flexy">
						<input type="text" placeholder="{lang guiigo_manage:tlang0323}" name="expirationbump" id="expirationbump" class="guiigo-px bg-e" value=""/>
					</div>
				</div>
			</div>
			<!--{/if}-->
			<!--{if $_G['group']['allowhighlightthread']}-->
			<div id="itemcp_highlight">
				<div class="adsz-szxm guiigo-flex ms-a">
					<label class="guiigo-pds">
						<div class="szxm-xmbt zy-c">
							<input type="checkbox" name="operations[]" class="guiigo-pd-k" value="highlight" $defaultcheck[highlight] />
							<span></span><em class="zy-h">{lang guiigo_manage:tlang0328}</em>
						</div>
					</label>
					<div class="szxm-xmnr szxm-glxx guiigo-flexy">
						<!--{eval $_G['forum_colorarray'] = array(1=>'#EE1B2E', 2=>'#EE5023', 3=>'#996600', 4=>'#3C9D40', 5=>'#2897C5', 6=>'#2B65B7', 7=>'#8F2A90', 8=>'#EC1282');}-->
						<input type="hidden" id="highlight_color" name="highlight_color" value="$colorcheck" />
						<input type="hidden" id="highlight_style_1" name="highlight_style[1]" value="$stylecheck[1]" />
						<input type="hidden" id="highlight_style_2" name="highlight_style[2]" value="$stylecheck[2]" />
						<input type="hidden" id="highlight_style_3" name="highlight_style[3]" value="$stylecheck[3]" />
						<a href="javascript:;" id="highlight_color_ctrl" onclick="showHighLightColor('highlight_color')" class="pn colorwd"{if $colorcheck} style="background-: $_G[forum_colorarray][$colorcheck]"{/if} /></a>
						<a href="javascript:;" id="highlight_op_1" onclick="switchhl(this, 1)" class="dopt_b{if $stylecheck[1]} cnt{/if}" style="text-indent:0;text-decoration:none;font-weight:700;" title="{lang e_bold}">B</a>
						<a href="javascript:;" id="highlight_op_2" onclick="switchhl(this, 2)" class="dopt_i{if $stylecheck[2]} cnt{/if}" style="text-indent:0;text-decoration:none;font-style:italic;" title="{lang e_italic}">I</a>
						<a href="javascript:;" id="highlight_op_3" onclick="switchhl(this, 3)" class="dopt_l{if $stylecheck[3]} cnt{/if}" style="text-indent:0;text-decoration:underline;" title="{lang e_underline}">U</a>
					</div>
				</div>
				<div class="adsz-szxm guiigo-flex ms-a" style="margin-left: 0.85rem;">
					<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0329}</div>
					<div class="szxm-xmnr szxm-dsrk guiigo-flexy">
						<input type="text" placeholder="{lang guiigo_manage:tlang0323}" name="expirationhighlight" id="expirationhighlight" class="guiigo-px bg-e" value="$expirationhighlight"/>
					</div>
				</div>
			</div>
			<!--{/if}-->
		    <!--{/if}-->
			<!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1}-->
				<div id="itemcp_recommend">
					<label class="label-checkbox item-content">
						<input type="checkbox" name="operations[]" value="recommend" $defaultcheck[recommend] />
						<div class="item-media"><i class="icon icon-form-checkbox"></i></div>
						<div class="item-inner innerdel">
							<div class="item-subtitle">{lang recommend}</div>
							<div class="item-title">
								<label class="label-checkbox checkbox" style="margin-top:0;">
									<input type="radio" name="isrecommend" value="1" checked="checked"/>
									<div class="item-media radio">
									<i class="icon icon-form-checkbox"></i>{lang recommend}
									</div>
								</label>
								<label class="label-checkbox checkbox" style="margin-top:0;">
									<input type="radio" name="isrecommend" value="0"/>
									<div class="item-media radio">
									<i class="icon icon-form-checkbox"></i>{lang admin_unrecommend}
									</div>
								</label>
							</div>
						</div>
						<div class="item-inner innerdel labe-data">
							<div class="item-subtitle">{lang expire}</div>
							<div class="item-title">
								<div class="item-input ">
									<input type="text" placeholder="{lang guiigo_manage:tlang0323}" name="expirationrecommend" id="expirationrecommend" value="$expirationrecommend"/>
								</div>
							</div>
						</div>
					</label>
				</div>
			<!--{/if}-->
		<!--{elseif $_GET['optgroup'] == 2}-->
			<!--{if $operation != 'type'}-->
				<div class="adsz-szxm guiigo-flex">
					<div class="szxm-xmbt zy-c">{lang admin_target}</div>
					<input type="hidden" name="operations[]" value="move" />
					<div class="szxm-xmnr guiigo-flexy">
						<select name="moveto" id="moveto" class="guiigo-ps zy-h" onchange="ajaxget('','forum.php?mod=ajax&action=getthreadtypes&fid=' + this.value, 'threadtypes');if(this.value) {Dz('moveext').style.display='';} else {Dz('moveext').style.display='none';}">
						$forumselect
						</select>
					</div>
				</div>
				<div class="adsz-szxm guiigo-flex ms-a">
					<div class="szxm-xmbt zy-c">{lang admin_targettype}</div>
					<div class="szxm-xmnr szxm-xzys guiigo-flexy" id="threadtypes">
						<select name="threadtypeid" class="guiigo-ps zy-h"><option value="0" /></option></select>
					</div>
				</div>
				<div id="moveext" style="display:none;">
					<div class="adsz-szxm guiigo-flex ms-a">
						<label class="guiigo-pds zy-h">
							<input type="radio" name="type" class="guiigo-pd-k" value="normal" checked="checked" />
							<span></span>{lang admin_move}
						</label>
					</div>
					<div class="adsz-szxm guiigo-flex ms-a">
						<label class="guiigo-pds zy-h">
							<input type="radio" name="type" class="guiigo-pd-k" value="redirect" />
							<span></span>{lang admin_move_hold}
						</label>
					</div>
				</div>
			<!--{else}-->
				<!--{if $typeselect}-->
					<div class="adsz-szxm guiigo-flex">
						<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0330}</div>
						<input type="hidden" name="operations[]" value="type"/>
						<div class="szxm-xmnr szxm-xzys guiigo-flexy">
							$typeselect
						</div>
					</div>
				<!--{else}-->
					<div class="adsz-scts zy-h" style="padding: 0;">
						{lang admin_type_msg}<!--{eval $hiddensubmit = true;}-->
					</div>
				<!--{/if}-->
			<!--{/if}-->
		<!--{elseif $_GET['optgroup'] == 3}-->
			<!--{if $operation == 'delete'}-->
				<!--{if $_G['group']['allowdelpost']}-->
					<input name="operations[]" type="hidden" value="delete"/>
					<div class="adsz-scts zy-h">{lang admin_delthread_confirm}</div>
				<!--{else}-->
					<div class="adsz-scts zy-h">{lang admin_delthread_nopermission}</div>
				<!--{/if}-->
				<!--{if ($modpostsnum == 1 || $authorcount == 1) && $crimenum > 0}-->
					<div class="adsz-szxm guiigo-flex">
						<div class="szxm-xmsm bk-d bg-p zy-b">{lang topicadmin_crime_delpost_nums}</div>
					</div>
				<!--{/if}-->
			<!--{elseif $operation == 'down' || $operation='bump'}-->
				<div class="adsz-szxm guiigo-flex">
					<label class="guiigo-pds zy-h" onclick="switchitemcp('#expirationbump_bump','show');">
						<input type="radio" name="operations[]" class="guiigo-pd-k" value="bump" checked="checked"/>
						<span></span>{lang admin_bump}
					</label>
				</div>
				<div class="adsz-szxm guiigo-flex ms-a" id="expirationbump_bump" style="margin-left: 0.85rem;">
					<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0331}</div>
					<div class="szxm-xmnr szxm-dsrk guiigo-flexy">
						<input type="text" id="expirationbump" name="expirationbump" class="guiigo-px bg-e" placeholder="{lang guiigo_manage:tlang0323}">
					</div>
				</div>
				<div class="adsz-szxm guiigo-flex ms-a">
					<label class="guiigo-pds zy-h" onclick="switchitemcp('#expirationbump_bump','none');">
						<input type="radio" name="operations[]" class="guiigo-pd-k" value="down"/>
						<span></span>{lang admin_down}
					</label>
				</div>
			<!--{/if}-->
		<!--{elseif $_GET['optgroup'] == 4}-->
			<div class="adsz-szxm guiigo-flex">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="operations[]" class="guiigo-pd-k" value="open" $closecheck[0]  onclick="Dz('expirationclose').value='';" />
					<span></span>{lang admin_open}
				</label>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<label class="guiigo-pds zy-h">
					<input type="radio" name="operations[]" class="guiigo-pd-k" value="close" $closecheck[1] />
					<span></span>{lang admin_close}
				</label>
			</div>
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmbt zy-c">{lang guiigo_manage:tlang0331}</div>
				<div class="szxm-xmnr szxm-dsrk guiigo-flexy">
					<input type="text" placeholder="{lang guiigo_manage:tlang0323}" name="expirationclose" id="expirationclose" class="guiigo-px bg-e" value="$expirationclose"/>
				</div>
			</div>
		<!--{elseif $_GET['optgroup'] == 5}-->
			<!--{if $operation == 'recommend_group'}-->
				<div class="adsz-szxm guiigo-flex">
					<div class="szxm-xmbt zy-c">{lang admin_target}</div>
					<input type="hidden" name="operations[]" value="recommend_group" />
					<div class="szxm-xmnr szxm-xzys guiigo-flexy" id="threadtypes">
						<select id="moveto" class="guiigo-ps zy-h" name="moveto" >$forumselect</select>
					</div>
				</div>
			<!--{/if}-->
		<!--{/if}-->
		<!--{if empty($hiddensubmit)}-->
			<div class="adsz-szxm guiigo-flex ms-a sh-a" style="padding-top: .55rem;">
				<div class="szxm-xmbt zy-c">{lang admin_operation_explain}</div>
				<div class="szxm-xmnr szxm-czsm guiigo-flexy">
					<textarea name="reason" id="reason" rows="3" class="guiigo-px bg-e"></textarea>
				</div>
			</div>
		<!--{/if}-->
		<!--{if empty($hiddensubmit)}-->
			<!--{if $_GET['optgroup'] == 3 && $operation == 'delete' && $_G['group']['allowbanuser']}-->
				<div class="adsz-szxm guiigo-flex ms-a">
					<div class="szxm-xmbt zy-c">{lang topicadmin_banuser}</div>
					<div class="szxm-xmnr guiigo-flexy guiigo-pc">
						<input type="checkbox" name="banuser" id="userban"/>
						<label for="userban"><em></em></label>
					</div>
				</div>
				<div class="adsz-szxm guiigo-flex ms-a">
					<div class="szxm-xmbt zy-c">{lang topicadmin_userdelpost}</div>
					<div class="szxm-xmnr guiigo-flexy guiigo-pc">
						<input type="checkbox" name="userdelpost" id="userdelpost"/>
						<label for="userdelpost"><em></em></label>
					</div>
				</div>
			<!--{/if}-->
			<!--{if $_GET['optgroup'] == 3 && $operation == 'delete'}-->
				<div class="adsz-szxm guiigo-flex ms-a">
					<div class="szxm-xmbt zy-c">{lang crimerecord}</div>
					<div class="szxm-xmnr guiigo-flexy guiigo-pc">
						<input type="checkbox" name="crimerecord" id="crimerecord"/>
						<label for="crimerecord"><em></em></label>
					</div>
				</div>
			<!--{/if}-->
			<div class="adsz-szxm guiigo-flex ms-a">
				<div class="szxm-xmbt zy-c">{lang admin_pm}</div>
				<div class="szxm-xmnr guiigo-flexy guiigo-pc">
					<input type="checkbox" name="sendreasonpm" id="sendreasonpm" {if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />
					<label for="sendreasonpm"><em></em></label>
				</div>
			</div>
		<!--{/if}-->
	</form>
<script type="text/javascript" reload="1">
ck8(function(){
	ck8('#expirationbump').datetimePicker({})
	ck8('#expirationstick').datetimePicker({})
	ck8('#expirationdigest').datetimePicker({})
	ck8('#expirationrecommend').datetimePicker({})
	ck8('#expirationhighlight').datetimePicker({})
	ck8('#expirationclose').datetimePicker({})
})

function switchitemcp(id,sty) {
	if(sty == 'show'){
		ck8(id).show()
	}else if(sty == 'none'){
		ck8(id).hide()
	}
}

function switchhl(obj, v) {
	if(parseInt(Dz('highlight_style_' + v).value)) {
		Dz('highlight_style_' + v).value = 0;
		obj.className = obj.className.replace(/ cnt/, '');
	} else {
		Dz('highlight_style_' + v).value = 1;
		obj.className += ' cnt';
	}
}

function showHighLightColor(hlid) {
	var showid = hlid + '_ctrl';
	if(!Dz(showid + '_menu')) {
		var str = '';
		var coloroptions = {'0' : '#000', '1' : '#EE1B2E', '2' : '#EE5023', '3' : '#996600', '4' : '#3C9D40', '5' : '#2897C5', '6' : '#2B65B7', '7' : '#8F2A90', '8' : '#EC1282'};
		var menu = document.createElement('div');
		menu.id = showid + '_menu';
		menu.className = 'cmen';
		menu.style.display = 'none';
		for(var i in coloroptions) {
			str += '<a href="javascript:;" onclick="Dz(\'' + hlid + '\').value=' + i + ';Dz(\'' + showid + '\').style.backgroundColor=\'' + coloroptions[i] + '\';hideMenu(\'' + menu.id + '\')" style="background:' + coloroptions[i] + ';color:' + coloroptions[i] + ';">' + coloroptions[i] + '</a>';
		}
		menu.innerHTML = str;
		Dz('append_'+ hlid).appendChild(menu);
	}
	var showoffset = ck8('#'+ showid).offset();
	var apptop = ck8('#append_'+ hlid).offset().top;
    var style = {'position':'absolute','zIndex': 10,'left': (showoffset.left / 2) + ck8('#'+ showid).width() ,'top': showoffset.top - apptop + ck8('#'+ showid).height()}
    ck8('#'+ showid + '_menu').css(style).show()
}

function createPalette(colorid, id, domid) {
	var iframe = "<iframe name=\"c"+colorid+"_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe>";
	if (!Dz("c"+colorid+"_menu")) {
		var dom = document.createElement('span');
		dom.id = "c"+colorid+"_menu";
		dom.style.display = 'none';
		dom.innerHTML = iframe;
		Dz('append_'+ colorid).appendChild(dom);
	}
	var iframeid = "c"+colorid+"_menu";
	window.frames["c"+colorid+"_frame"].location.href = SITEURL +"template/ck8_appmobile/touch/static/imgs/getcolor.htm?c"+colorid+"|"+id+"|"+iframeid;
	var showoffset = ck8('#'+ domid).offset();
	var apptop = ck8('#append_'+ colorid).offset().top;
    var style = {'position':'absolute','zIndex': 10,'left': (showoffset.left / 2) - ck8('#'+ domid).width() ,'top': showoffset.top - apptop + ck8('#'+ domid).height()}
	ck8('#'+ iframeid).css(style).show()
}

function hideMenu(id){
    ck8('#'+ id).hide()
}
</script>
</div>
<script>ck8(function(){initSelect()})</script>
<!--{template common/footer}-->