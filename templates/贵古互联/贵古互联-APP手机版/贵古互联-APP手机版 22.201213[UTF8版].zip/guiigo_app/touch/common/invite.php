<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="invite-postform" 
    id="tipmessage"
	ck-cus="true" 
	ck-param="{type:'popup',height:'100%',title:'{if $at != 1}{lang invite_friend}{/if}$invitename'}" 
	data-isjs="false">
	<script type="text/javascript">var invitefs, clearlist = 0;</script>
	<div class="gg-yq-sssj xh-b">
		<div class="sssj-skys">
			<div class="skys-hysx bg-c">
				<input type="text" class="guiigo-ps s-a zy-f select-picker" value="{lang invite_all_friend}" data-select="invites" />
				<select id="invites" onchange="clearlist=1;getUser(1, this.value)" style="display:none;">
					<option value="-1">{lang invite_all_friend}</option>
					<!--{if $at == 1 && $_G['group']['allowat']}-->
						<option value="-2">{lang invite_my_follow}</option>
					<!--{/if}-->     
					<!--{loop $friendgrouplist $groupid $group}-->
						<option value="$groupid">$group</option>
					<!--{/loop}-->
				</select>
				<i class="icon ck8-icon-xuanze"></i>
			</div>
			<div class="searchbar">
			  <a class="searchbar-cancel ab-a zy-a" onclick="clearlist=1;getUser();">{lang find}</a>
			  <div class="search-input">
				<label class="icon ck8-icon-search1" for="username"></label>
				<input type="search" name="username" size="25" id="username" class="guiigo-px bg-c zy-c" value="" autocomplete="off" placeholder="{lang invite_orderby_name}"/>
			  </div>
			</div>
		</div>
		
		<div class="item-content zy-e">
		  <div class="item-inner innerdel">
			<div class="item-title">
				<span id="showUser_0" onclick="invitefs.showUser(0)">{lang invite_all_friend}</span>
				<span id="showUser_1" onclick="invitefs.showUser(1)">{lang selected}<strong id="selectNum">0</strong></span>
				<span id="showUser_2" onclick="invitefs.showUser(2)">{lang unselected}<strong id="unSelectTab">0</strong></span>
			</div>
			<div class="item-after">{lang invite_still_choose}<strong id="remainNum">0</strong>{lang unit}</div>
		  </div>
		</div>
	</div>
	<ul class="gg-yq-hylb bg-c" id="friends"></ul>
	<script type="text/javascript" reload="1">
		var isjs = ck8('#tipmessage').attr('data-isjs')
		var page = 1;
		var gid = -1;
		var showNum = 0;
		var haveFriend = true;
		var username = '';
		function getUser(pageId, gid) {
			if(!isUndefined(pageId))
			  page = parseInt(pageId);
			gid = isUndefined(gid) ? -1 : parseInt(gid);
			var um = Dz('username').value;
           
		   if(um){
			   username =  encodeURIComponent(encodeURIComponent(um));
		   }
		   
			ck8.showPreloader('','load');
			ck8.ajax({
				type : 'GET',
				url : 'home.php?mod=spacecp&ac=friend&op=getinviteuser&inajax=1&page='+ page + '&gid=' + gid + '&at={$at}&username='+ username + '&' + Math.random(),
				dataType : 'xml',
				success: function(s){
					setTimeout(function(){ck8.hidePreloader()}, 100);
					var data = eval('('+s.lastChild.firstChild.nodeValue+')');
					var singlenum = parseInt(data['singlenum']);
					var maxfriendnum = parseInt(data['maxfriendnum']);
					invitefs.addDataSource(data, clearlist);
					haveFriend = singlenum && singlenum == 20 ? true : false;
					if(singlenum && invitefs.allNumber < 20 && invitefs.allNumber < maxfriendnum && maxfriendnum > 20 && haveFriend) {
						page++;
						clearlist = 0;
						getUser(page);
					}
					username = '';
				},
				error: function(){
					ck8.hidePreloader();
					ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
				}
			})
		}
		function selector() {
			var parameter = {'searchId':'username', 'showId':'friends', 'formId':'inviteform', 'showType':1, 'handleKey':'invitefs', 'maxSelectNumber':'20', 'selectTabId':'selectNum', 'unSelectTabId':'unSelectTab', 'maxSelectTabId':'remainNum'};
			<!--{if $at == 1 && $_G['group']['allowat']}-->
				parameter.maxSelectNumber = $maxselect;
			<!--{/if}-->
			invitefs = new friendSelector(parameter);
			<!--{if $inviteduids}-->
			invitefs.addFilterUser([$inviteduids]);
			<!--{/if}-->
			var listObj = Dz('friends');
			listObj.onscroll = function(){
				clearlist = 0;
				if(this.scrollTop >= (this.scrollHeight/5-5)) {
					page++;
					gid = isUndefined(gid) ? -1 : parseInt(gid);
					if(haveFriend) {
						getUser(page, gid);
					}
				}
			}
			getUser(page);
		}
		if(ck8('#friendselector_js').length > 0 && typeof friendSelector != 'undefined' && isjs == 'false') {
			selector();
			ck8('#tipmessage').attr('data-isjs','true')
		}else if(isjs == 'false'){
			var scriptNode = document.createElement("script");
			scriptNode.id = 'friendselector_js';
			scriptNode.type = "text/javascript";
			scriptNode.src = './template/guiigo_app/static/js/mod-js/home_friendselector.js?{VERHASH}';
			scriptNode.onload = selector;
			Dz('append_parent').appendChild(scriptNode);
			ck8('#tipmessage').attr('data-isjs','true')
		}
	</script>
	<div class="mn-a">
		<form method="post" 
			autocomplete="off" 
			name="invite" 
			id="inviteform" 
			action="misc.php?mod=invite&action=$_GET[action]&id=$id{if $_GET['activity']}&activity=1{/if}&invitesubmit=yes"
			ck-cus="true" 
			ck-param="{type:'modal',load:'true',callpar:{pid:'$_GET[pid]',type:{if $_GET['activity']}'activity'{else}'invite'{/if}},fn:{if $_GET['fn']}'$_GET['fn']'{/if},uid:'$_G[uid]'}">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<!--{if !empty($_G['inajax'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
			<button type="submit" class="guiigo-pn ab-a zy-a formdialog" name="invitesubmit" value="yes">{lang invite_send}</button>
		</form>
	</div>
</div>
<script>
ck8(function(){
	initSelect()
	appTplinit(ck8('.page'))
})
</script>
<!--{template common/footer}-->
