<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if !$guiigo_config['open_tabnav']}-->
<!--{if !$guiigo_config['isguiigoapp'] || $_G['cache']['plugin']['guiigo_appmanage']['alltpl']}-->
<nav class="bar bar-tab guiigo-tab guiigo-taba bg-c {if $guiigo_config['tabnavmusic']>1}tabnavmusic{/if}" data-music="tab$guiigo_config['tabnavmusic']">
	<a class="tab-item" href="{$_G['siteurl']}plugin.php?id=guiigo_manage&act=index">
		<span class="icon"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/{if $_GET['id'] == 'guiigo_manage' || $_GET['act'] == 'index'}sy_on{else}sy{/if}.png"></span>
		<span class="tab-label{if $_GET['id'] == 'guiigo_manage' || $_GET['act'] == 'index'} zy-be{else} zy-c{/if}">{lang guiigo_manage:tlang0076}</span>
	</a>
	<a class="tab-item{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])} tab-ksft{/if}" href="{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])}$_G['siteurl']forum.php?mod=misc&action=nav{else}{if $guiigo_config['appsetting']['forumconfig']['forumstyle'] == 1}{if $guiigo_config['appsetting']['forumconfig']['show_wdgzqb']}$_G['siteurl']forum.php?forumlist=1&do=guanzhu{else}$_G['siteurl']forum.php?forumlist=1{/if}{else}$_G['siteurl']forum.php?forumlist=1{/if}{/if}">
		<span class="icon"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])}sq_kf{else}sq{/if}.png"></span>
		<span class="tab-label{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])} zy-be{else} zy-c{/if}">{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])}{lang guiigo_manage:tlang0077}{else}{lang guiigo_manage:tlang0078}{/if}</span>
	</a>
	<a class="tab-item" href="$_G['siteurl']group.php?mod=index">
		<span class="icon"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/{if CURSCRIPT == 'group'}qz_on{else}qz{/if}.png"></span>
		<span class="tab-label{if CURSCRIPT == 'group'} zy-be{else} zy-c{/if}">{lang guiigo_manage:tlang0079}</span>
	</a>
	<a class="tab-item gg-xcx-sh<!--{if !$_G[uid]}--> login<!--{/if}-->" href="<!--{if $_G[uid]}-->$_G['siteurl']home.php?mod=space&do=pm&filter=privatepm<!--{else}-->javascript:;<!--{/if}-->">
		<span class="icon">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/{if CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'pm'}xx_on{else}xx{/if}.png">
				<i class="guiigo-yjsz bg-j zy-a pmnewmsg" style="display:none;" data-setInterval="0"></i>
		</span>
		<span class="tab-label {if CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'pm'}zy-be{else}zy-c{/if}">{lang guiigo_manage:tlang0080}</span>
	</a>
	<a class="tab-item<!--{if !$_G[uid]}--> login<!--{/if}-->" href="<!--{if $_G[uid]}-->$_G['siteurl']home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->javascript:;<!--{/if}-->">
		<span class="icon">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/{if CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'profile'}wd_on{else}wd{/if}.png">
			  <i class="guiigo-yjsz bg-j zy-a followermsg" style="display:none;"></i>
		</span>
		<span class="tab-label {if CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'profile'}zy-be{else}zy-c{/if}">{lang guiigo_manage:tlang0081}</span>
	</a>
</nav>
<!--{/if}-->
<!--{/if}-->

