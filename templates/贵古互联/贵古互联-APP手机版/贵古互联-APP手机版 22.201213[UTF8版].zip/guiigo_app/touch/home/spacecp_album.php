<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G[home_tpl_titles] = array($album[albumname], '{lang album}');}-->
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<!--{if $_GET['op'] == 'edit'}-->
<div class="page page-current" data-mod="spacecp-album">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang edit_album_information}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<form method="post" 
			autocomplete="off" 
			id="theform" 
			name="theform" 
			action="home.php?mod=spacecp&ac=album&op=edit&albumid=$albumid"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{aid:'$albumid',type:'albumxcxx'},fn:'MsgCallAlbum',load:'true',uid:'$_G[uid]'}"
			>
				<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang album_name}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="albumname" id="albumname" class="guiigo-px s-a" value="$album[albumname]"/></div>
						</li>
						<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang album_depict}</li>
						<li class="wblb-nrsr xh-b zy-h cl">
							<div class="wblb-wbnr zy-h"><textarea id="depict" name="depict" class="guiigo-pt s-a">$album[depict]</textarea></div>
						</li>
						<!--{if $categoryselect}-->
						<style type="text/css">
						#catid {background: url(template/guiigo_app/static/images/guiigo-ps.png) no-repeat;background-position: right;background-size: .55rem auto;-webkit-appearance: none;width: 100%;height: 1rem;line-height: 1rem;font-size: inherit;border: none;outline: none;border-radius: 0;}
						</style>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang site_categories}</div>
							<div class="wblb-wbnr zy-h">$categoryselect</div>
						
						</li>
						<!--{/if}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang privacy_settings}</div>
							<div class="wblb-wbnr zy-h">
								<select name="friend" class="guiigo-ps" onchange="passwordShow(this.value);">
									<option value="0"$friendarr[0]>{lang friendname_0}</option>
									<option value="1"$friendarr[1]>{lang friendname_1}</option>
									<option value="2"$friendarr[2]>{lang friendname_2}</option>
									<option value="3"$friendarr[3]>{lang friendname_3}</option>
									<option value="4"$friendarr[4]>{lang friendname_4}</option>
								</select>
							</div>
						</li>
						<li class="guiigo-flex xh-b cl" id="span_password" style="$passwordstyle">
							<div class="wblb-wbbt zy-c">{lang password}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="password" class="guiigo-px s-a" value="$album[password]"/></div>
						</li>
						<li class="guiigo-flex xh-b cl" id="tb_selectgroup" style="$selectgroupstyle">
							<div class="wblb-wbbt zy-c">{lang specified_friends}</div>
							<div class="wblb-wbnr zy-h">
								<select name="selectgroup" onchange="getgroup(this.value);" class="guiigo-ps">
									<option value="">{lang from_friends_group}</option>
									<!--{loop $groups $key $value}-->
									<option value="$key">$value</option>
									<!--{/loop}-->
								</select>
							</div>
						</li>
						<li class="wblb-dkbt bg-g xh-b zy-c cl" id="tb_selectgroup" style="$selectgroupstyle">{lang friend_name_space}</li>
						<li class="wblb-nrsr xh-b zy-h cl" id="tb_selectgroup" style="$selectgroupstyle">
							<textarea name="target_names" id="target_names" rows="3" class="guiigo-pt s-a">$album[target_names]</textarea>
						</li>
					</ul>
				</div>
				<div class="mn-a">
					<input type="hidden" name="referer" value="{echo dreferer()}" />
					<input type="hidden" name="editsubmit" value="true" />
					<button name="submit" type="submit" class="formdialog guiigo-pn ab-az zy-a zy-ac" value="true">{lang determine}</button>
				</div>
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			</form>
		</div>
	</div>
</div>
<!--{elseif $_GET['op'] == 'editpic'}-->
<div class="page page-current" data-mod="spacecp-album">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<h1 class="title zy-h">{lang edit_pic}</h1>
	</header>
	<div class="content bg-c gg-jxbg">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
		<!--{if $list}-->
		<div id="posttheform"> 
			<form method="post" 
			autocomplete="off" 
			id="theform" 
			name="theform" 
			action="home.php?mod=spacecp&ac=album&op=editpic&albumid=$albumid"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{aid:'$albumid',type:'albumbjtp'},fn:'MsgCallAlbum',load:'true',uid:'$_G[uid]'}">
				<div class="gg-qz-flts bg-c"><div class="flts-tsnr bk-d bg-p zy-b">{lang delete_pic_notice}</div></div>
				<!--{eval $common = '';}-->
				<div id="bjtp-sxon" class="gg-kj-bjtp list-block-no bg-c">
					<ul>
						<!--{loop $list $value}-->
						<li class="guiigo-flex xh-b">
							<div class="bjtp-xztp"><label class="guiigo-pd"><input type="checkbox" name="ids[{$value[picid]}]" value="{$value[picid]}" {$value[checked]} class="guiigo-pd-k"><span></span></label></div>
							
							<div class="bjtp-swfm">
								<div class="swfm-yskz">
									<!--{eval $ids .= $common.$value['picid'].':'.$value['picid'];}-->
									<!--{eval $common = ',';}-->
									<!--{if $album[albumname]}-->
									<a href="home.php?mod=spacecp&ac=album&op=setpic&albumid=$value[albumid]&picid=$value[picid]&handlekey=setpichk" 
									id="a_picid_$value[picid]"
									class="dialog"
									ck-cus="true"
									ck-param="{type:'modal',callpar:{aid:'$albumid',type:'albumfmsz'},fn:'MsgCallAlbum',load:'true',uid: '$_G[uid]'}"
									external>
										<img src="$value[pic]">
										<p class="zy-a">{lang set_to_conver}</p>
									</a>
									<!--{/if}-->
								</div>
							</div>
							<div class="bjtp-tpjs guiigo-flexy"><textarea name="title[{$value[picid]}]" rows="4" cols="70" class="guiigo-pt zy-h">$value[title]</textarea><input type="hidden" name="oldtitle[{$value[picid]}]" value="$value[title]"></div>
						</li>
						<!--{/loop}-->
					</ul>
				</div>
				<div class="gg-kj-tpan bg-g">
					<div class="tpan-qxsc xh-c cl">
						<div class="qxsc-tpqx"><label for="chkall" class="guiigo-pd zy-h" onclick="checkall(this.form, 'ids')"><input type="checkbox" name="chkall" id="chkall" class="guiigo-pd-k" />{lang select_all}</label></div>
						<input type="hidden" name="editpicsubmit" value="true" />
						<div class="qxsc-tpsc"><button type="button"  class=" guiigo-pn zy-i" onclick="FormDialog('#posttheform','&subop=delete');"><i class="icon guiigoapp-shanchu"></i>{lang delete}</button></div>
					</div>
					<div class="tpan-gxzy guiigo-flex">	
						<button type="submit" name="editpicsubmit" value="true" class="formdialog guiigo-pn flex-xyjl ab-a zy-a">{lang update_explain}</button>
						<!--{if $albumlist}-->
						<input type="hidden" name="editpicsubmit" value="true" />
						<button type="button" class="guiigo-pn ab-c zy-a" onclick="FormDialog('#posttheform','&subop=move');">{lang move_to}</button>
						<div class="guiigo-flexy">
							<input type="text" class="ps s-a select-picker" value="{lang default_album}" data-select="newalbumid" />
							<select name="newalbumid" id="newalbumid" style="display:none;">
							<!--{loop $albumlist $key $value}-->
							<!--{if $albumid != $value[albumid]}--><option value="$value[albumid]">$value[albumname]</option><!--{/if}-->
							<!--{/loop}-->
							<!--{if $albumid>0}--><option value="0">{lang default_album}</option><!--{/if}-->
							</select>
						</div>
						<!--{/if}-->
					</div>
				</div>
				<input type="hidden" name="page" value="$page" />
				<input type="hidden" name="editpicsubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			</form>
		</div>
			<!--{if $multi}--><div class="pgs cl">$multi</div><!--{/if}-->
			<script type="text/javascript">
				var picObj = {{$ids}};
				function succeedhandle_setpichk(url, msg, values) {
					for(var id in picObj) {
						ck8('a_picid_' + picObj[id]).innerHTML = "{lang set_to_conver}";
					}
					if(values['picid']) {
						ck8('a_picid_' + values['picid']).innerHTML = "{lang cover_pic}";
					}
				}
				function FormDialog(id,action) {
					var formobj = ck8(id).find("form");
					var faction = formobj.attr('action');		 
					if(faction == '&subop=move' || faction == '&subop=delete'){
						action = ''
					}
					formobj.attr('action', faction + action )
					ischeck('theform', 'ids',id)
				}					
				function ischeck(id, prefix,fid) {
					form = document.getElementById(id);
					var isok = true;
					for(var i = 0; i < form.elements.length; i++) {
						var e = form.elements[i];
						if(e.name.match(prefix) && e.checked) {
							ck8.confirm('{lang guiigo_manage:tlang0516}', '{lang guiigo_manage:tlang0042}',
								function (){
									app.FormDialog(fid)
								},
								function (){
									return false;
								}
							)
							isok = false;
							break;
						}
					}
					if(isok)
					ck8.alert('{lang guiigo_manage:tlang0517}');
				}
			</script>
		<!--{else}-->
			<div class="guiigo-wnrtx guiigo-wnrtxx">
				<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
				<p class="zy-c">{lang no_pics}</p>
			</div>
		<!--{/if}-->
		$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{elseif $_GET['op'] == 'delete'}-->
	<div id="theform">
		<form method="post" 
		autocomplete="off" 
		id="theform" 
		name="theform" 
		action="home.php?mod=spacecp&ac=album&op=delete&albumid=$albumid&uid=$_GET[uid]"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{aid:'$albumid',type:'albumscxc'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}"
		>
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="deletesubmit" value="true" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<div class="gg-kj-xstc">
				<p>{lang delete_album_message}</p>
				<div class="xstc-psys bg-e">
					<input type="text" class="ps s-a select-picker" value="{lang completely_remove}" data-select="moveto" />
					<select name="moveto" id="moveto" style="display:none;">
						<option value="-1">{lang completely_remove}</option>
						<option value="0">{lang move_to_default_album}</option>
						<!--{loop $albums $value}-->
						<option value="$value[albumid]">{lang move_to} $value[albumname]</option>
						<!--{/loop}-->
					</select>
				</div>
			</div>
			<!--
			<p class="o pns">
				<button type="submit" name="submit" class="pn pnc" value="true"><strong>{lang determine}</strong></button>
			</p>
			-->
		</form>
	</div>
<!--{elseif $_GET['op'] == 'edittitle'}-->
	<h3 class="flb">
		<em id="return_$_GET[handlekey]">{lang edit_description}</em>
		<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
	</h3>
	<form id="titleform" name="titleform" action="home.php?mod=spacecp&ac=album&op=editpic&subop=update&albumid=$pic[albumid]" method="post" autocomplete="off" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="editpicsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="c">
			<textarea name="title[{$pic[picid]}]" cols="50" rows="7" class="pt">$pic[title]</textarea>
		</div>
		<p class="o pns">
			<button type="submit" name="editpicsubmit_btn" class="pn pnc" value="true"><strong>{lang update}</strong></button>
		</p>
	</form>
	<script type="text/javascript">
		function succeedhandle_$_GET['handlekey'] (url, message, values) {
			$('$_GET[handlekey]').innerHTML = values['title'];
		}
	</script>
<!--{elseif $_GET[op] == 'edithot'}-->
	<h3 class="flb">
		<em>{lang adjust_hot}</em>
		<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
	</h3>
	<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=album&op=edithot&picid=$picid">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="hotsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="c">
			{lang new_hot}:<input type="text" name="hot" value="$pic[hot]" size="10" class="px" />
		</div>
		<p class="o pns">
			<button type="submit" name="btnsubmit" value="true" class="pn pnc"><strong>{lang determine}</strong></button>
		</p>
	</form>
<!--{elseif $_GET[op] == 'saveforumphoto'}-->
	<h3 class="flb">
		<em id="return_$_GET[handlekey]">{lang save_to_album}</em>
		<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
	</h3>
	<form id="saveforumphoto" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=album&op=saveforumphoto&aid=$_GET[aid]" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');return false;"{/if}>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="savephotosubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="aid" value="$_GET[aid]" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="c">
			{lang save_to}: <select name="albumid" class="ps vm">
			<!--{loop $albumlist $key $value}-->
				<option value="$value[albumid]">$value[albumname]</option>
			<!--{/loop}-->
			<option value="0">{lang default_album}</option>
			</select>
		</div>
		<p class="o pns">
			<button type="submit" name="btnsubmit" value="true" class="pn pnc"><strong>{lang determine}</strong></button>
		</p>
	</form>
	<script type="text/javascript">
		function succeedhandle_$_GET['handlekey'] (url, message, values) {
			
		}
	</script>
<!--{/if}-->
<script>			
	function MsgCallAlbum(msg,par,param){
		if(typeof msg === 'object' || typeof par === 'object'){
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0518}') != -1 && param.type == 'albumxcxx'){
				ck8.toast('{lang guiigo_manage:tlang0519}');
				setTimeout(function(){
					ck8.router.back()
				},2000)
			}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'albumscxc'){
				ck8.toast('{lang guiigo_manage:tlang0520}');
				setTimeout(function(){
					ck8.router.back()
				},2000)
			}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'albumbjtp'){
				ck8.toast('{lang guiigo_manage:tlang0521}');
				app.PageRefresh(false,'#bjtp-sxon','home.php?mod=spacecp&ac=album&op=editpic&albumid='+ param.aid)
			}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'albumfmsz'){
				ck8.toast('{lang guiigo_manage:tlang0522}');
			}else {
				ck8.toast(msg.msg,'shibai');
			}
		}else{
			ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
		}
	}
</script>
<script>ck8(function(){initSelect()})</script>
<!--{template common/footer}-->