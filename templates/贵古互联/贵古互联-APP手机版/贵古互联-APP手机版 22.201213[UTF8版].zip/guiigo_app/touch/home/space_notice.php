<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['home_tpl_titles'] = array('{lang remind}');}-->
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space_notice">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="home.php?mod=spacecp&ac=privacy&op=filter" class="button button-link pull-right" data-no-cache="true"><i class="icon guiigoapp-kjzlbj zy-f"></i></a>
		<h1 class="title zy-h">
			<!--{if $_GET['view'] == 'mypost'}-->
				{lang guiigo_manage:tlang0742}
			<!--{elseif $_GET['view'] == 'interactive'}-->
				{lang guiigo_manage:tlang0743}
			<!--{elseif $_GET['view'] == 'system'}-->
				{lang guiigo_manage:tlang0744}
			<!--{elseif $_GET['view'] == 'manage'}-->
				{lang guiigo_manage:tlang0745}
			<!--{elseif $_GET['view'] == 'app'}-->
				{lang guiigo_manage:tlang0746}
			<!--{/if}-->
		</h1>
	</header>
	<div class="content infinite-scroll ontice-scroll">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $_G['notice_structure'][$view] && ($view == 'mypost' || $view == 'interactive')}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacenotice list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<!--{loop $_G['notice_structure'][$view] $subtype}-->
						<li class="swiper-slide<!--{if $readtag[$subtype]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.ontice-scroll','home.php?mod=space&do=notice&view=$view&type=$subtype',['gg-xx-txzt']);"><!--{eval echo lang('template', 'notice_'.$view.'_'.$subtype)}--><!--{if $_G['member']['newprompt_num'][$subtype]}-->($_G['member']['newprompt_num'][$subtype])<!--{/if}--></a><span class="bg-b"></span></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<!--{/if}-->
			<div class="gg-xx-txzt list-block-no ms-a">
				<!--{if empty($list)}-->
				<div class="guiigo-wnrtx">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<!--{if $new == 1}-->
						<p class="zy-c">{lang no_new_notice}<a href="home.php?mod=space&do=notice&isread=1" class="zy-l">{lang guiigo_manage:tlang0747}</a></p>
					<!--{else}-->
						<p class="zy-c">{lang no_notice}</p>
					<!--{/if}-->
				</div>
				<!--{/if}-->
				<script type="text/javascript">
					function deleteQueryNotice(uid, type) {
						var dlObj = Dz(type + '_' + uid);
						if(dlObj != null) {
							var id = dlObj.getAttribute('notice');
						}
					}
					function errorhandle_pokeignore(msg, values) {
						deleteQueryNotice(values['uid'], 'pokeQuery');
					}
				</script>
				<!--{if $list}-->
				<ul>
					<!--{loop $list $key $value}-->
						<li class="bg-c xh-b" $value[rowid] notice="$value[id]">
							<!--{if $value[authorid]}-->
							<a href="home.php?mod=space&uid=$value[authorid]&do=profile" class="txzt-txys guiigo-ty"><!--{avatar($value[authorid],middle)}--></a>
							<!--{else}-->
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/xtxx.jpg" class="guiigo-ty" />
							<!--{/if}-->
							<div class="txzt-txnr zy-h">$value[note]</div>
							<div class="txzt-sjpb">
								<a href="home.php?mod=spacecp&ac=common&op=ignore&authorid=$value[authorid]&type=$value[type]&handlekey=addfriendhk_{$value[authorid]}" id="a_note_$value[id]" class="bg-e zy-g bk-e dialog" 
								ck-cus="true"
								ck-param="{type:'modal',callpar:{pid:'$value[id]'},fn:'MsgCallRaterange3',load:'true',uid: '$_G[uid]',cancel:'{lang guiigo_manage:tlang0105}',confirm:'{lang guiigo_manage:tlang0106}'}"
								external ><i class="icon guiigoapp-shanchu"></i></a>
								<span class="zy-c"><!--{date($value[dateline], 'u')}--></span>
							</div>
							<!--{if $value[from_num]}-->
							<div class="txzt-xtnr bg-e zy-m">{lang ignore_same_notice_message}</div>
							<!--{/if}-->
						</li>
					<!--{/loop}-->
				</ul>
				<!--{if $view!='userapp' && $space[notifications]}-->
				<div class="txtz-hltx bg-c"><a href="home.php?mod=space&do=notice&ignore=all" class="zy-f">{lang ignore_same_notice_message} <em>&rsaquo;</em></a></div>
				<!--{/if}-->
				<!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->