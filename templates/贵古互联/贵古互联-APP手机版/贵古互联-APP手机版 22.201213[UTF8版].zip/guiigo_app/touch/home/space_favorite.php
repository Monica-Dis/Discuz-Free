<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-favorite">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0708}</h1>
	</header>
	<div class="content favorite-scroll type-scroll">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacefavorite list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $actives[all]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.favorite-scroll','home.php?mod=space&do=favorite&type=all',['gg-kj-wdsc']);">{lang guiigo_manage:tlang0130}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[thread]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.favorite-scroll','home.php?mod=space&do=favorite&type=thread',['gg-kj-wdsc']);">{lang favorite_thread}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[forum]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.favorite-scroll','home.php?mod=space&do=favorite&type=forum',['gg-kj-wdsc']);">{lang favorite_forum}</a><span class="bg-b"></span></li>
					<!--{if helper_access::check_module('group')}--><li class="swiper-slide<!--{if $actives[group]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.favorite-scroll','home.php?mod=space&do=favorite&type=group',['gg-kj-wdsc']);">{lang favorite_group}</a><span class="bg-b"></span></li><!--{/if}-->
					<!--{if helper_access::check_module('blog')}--><li class="swiper-slide<!--{if $actives[blog]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.favorite-scroll','home.php?mod=space&do=favorite&type=blog',['gg-kj-wdsc']);">{lang favorite_blog}</a><span class="bg-b"></span></li><!--{/if}-->
					<!--{if helper_access::check_module('album')}--><li class="swiper-slide<!--{if $actives[album]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.favorite-scroll','home.php?mod=space&do=favorite&type=album',['gg-kj-wdsc']);">{lang favorite_album}</a><span class="bg-b"></span></li><!--{/if}-->
					<!--{if helper_access::check_module('portal')}--><li class="swiper-slide<!--{if $actives[article]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.favorite-scroll','home.php?mod=space&do=favorite&type=article',['gg-kj-wdsc']);">{lang favorite_article}</a><span class="bg-b"></span></li><!--{/if}-->
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-kj-wdsc" id="wdscqxsx">
				<div 
					id="favorite-scroll-page-$_GET['type']"
					data-url="$theurl"
					data-pages="{$count}" 
					data-ppp="{$perpage}" 
					data-page="$page" 
					data-islod="false">
					<!--{if $list}-->
					<div class="wdsc-sclb bg-c sh-a xh-b ms-a">
						<ul class="list-container">
							<!--{loop $list $k $value}-->
							<li id="fav_$k" class="sh-a">
								<a class="sclb-scsc bg-e zy-g bk-e dialog" id="a_delete_$k" href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k"
								ck-cus="true"
								ck-param="{type:'modal',callpar:{pid:'$value[id]'},fn:'MsgCallRaterange2',load:'true',uid: '$_G[uid]',cancel:'{lang guiigo_manage:tlang0105}',confirm:'{lang guiigo_manage:tlang0106}'}"
								external ><i class="icon guiigoapp-shanchu"></i></a>
								<!--{if $_GET['type'] == 'all'}-->$value[icon]<!--{/if}-->
								<a href="$value[url]" class="sclb-scbt zy-h">$value[title]</a>
							</li>
							<!--{/loop}-->
						</ul>
					</div>
					<!--{else}-->
						<div class="guiigo-wnrtx">
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
							<p class="zy-c">{lang no_favorite_yet}</p>
						</div>
					<!--{/if}-->
					<!--{if $list}-->
					<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
						<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
					</div>
					<div onclick="infinite('#favorite-scroll-page-$_GET['type']')" class="loadpage bg-c bk-e zy-c">{lang guiigo_manage:tlang0492}<i class="icon guiigoapp-ssxx zy-c"></i></div>
					<!--{/if}-->
				</div>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	function MsgCallRaterange2(msg,par,param){
		if(typeof msg === 'object' || typeof par === 'object'){
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1){
				ck8.toast('{lang guiigo_manage:tlang0237}');
			}else {
				ck8.toast(msg.msg,'shibai');
			}
		}else{
			ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
		}
	}
	</script>
</div>
<!--{template common/footer}-->