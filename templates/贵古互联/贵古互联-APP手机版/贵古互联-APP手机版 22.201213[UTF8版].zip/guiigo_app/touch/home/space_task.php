<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-task">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c<!--{if $do == 'view'}--> xh-b<!--{/if}-->">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h"><!--{if empty($do)}-->{lang guiigo_manage:tlang0797}<!--{elseif $do == 'view'}-->{lang task_detail}<!--{/if}--></h1>
	</header>
	<div class="content task-scroll">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
		<!--{if empty($do)}-->
			<div class="gg-kj-rwbg">
				<img src="template/guiigo_app/static/images/rwbg.jpg" class="vm">
				<div class="guiigo-bwdx">
					<div class="guiigo-bwdx-a"></div>
					<div class="guiigo-bwdx-b"></div>
				</div>
			</div>
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacetask list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $actives[new]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.task-scroll','home.php?mod=task&item=new',['gg-kj-rwzt']);">{lang task_new}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[doing]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.task-scroll','home.php?mod=task&item=doing',['gg-kj-rwzt']);">{lang guiigo_manage:tlang0798}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[done]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.task-scroll','home.php?mod=task&item=done',['gg-kj-rwzt']);">{lang guiigo_manage:tlang0799}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[failed]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.task-scroll','home.php?mod=task&item=failed',['gg-kj-rwzt']);">{lang guiigo_manage:tlang0800}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-kj-rwzt">
				<!--{subtemplate home/space_task_list}-->
			</div>
		<!--{elseif $do == 'view'}-->
			<!--{subtemplate home/space_task_detail}-->
		<!--{/if}-->
		$guiigo_config['footer_html']
		</div>
	</div>
	<script>
		function MsgCallTasklist(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if(param.type == 'applytask'){
					if(msg.msg.indexOf('{lang guiigo_manage:tlang0801}') != -1){
						ck8.toast('{lang guiigo_manage:tlang0801}','shibai');
						ck8('#taskli-'+ param.rid).remove()
						ck8.router.load('home.php?mod=task&item=doing',true)
					}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0802}') != -1){
						ck8.toast('{lang guiigo_manage:tlang0803}','shibai');
						app.PageRefresh(false,'page')
					}else {
						ck8.toast(msg.msg,'shibai');
					}
				}else if(param.type == 'tasknrsq'){
					if(msg.msg.indexOf('{lang guiigo_manage:tlang0801}') != -1){
						ck8.toast('{lang guiigo_manage:tlang0801}','shibai');
						app.PageRefresh(false,'page')
					}else {
						ck8.toast(msg.msg,'shibai');
					}
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}
	</script>
</div>
<!--{template common/footer}-->