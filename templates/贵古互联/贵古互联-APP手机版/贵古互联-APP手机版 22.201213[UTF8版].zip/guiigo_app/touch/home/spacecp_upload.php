<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp_upload">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang upload_pic}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $haveattachsize}-->
			<div class="gg-qz-flts bg-c"><div class="flts-tsnr bk-d bg-p zy-b">{lang hava_attach_size} $haveattachsize</div></div>
			<!--{/if}-->
			<!--{if empty($_GET['op'])}-->
				<form method="post" 
					autocomplete="off" 
					id="albumform" 
					action="home.php?mod=spacecp&ac=upload" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{type:'upalbum'},fn:'uploadalbum',load:'true',uid: $_G[uid]}">
					
					<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
						<ul>
						<!--{if $albums}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0645}</div>
								<div class="wblb-wbnr zy-h">
									<select name="albumop" id="albumop" class="guiigo-ps" onchange="album_op(this.value);">
										<option value="selectalbum" checked="checked">{lang guiigo_manage:tlang0646}</option>
										<option value="creatalbum">{lang guiigo_manage:tlang0647}</option>
									</select>
								</div>
							</li>
							<li id="selectalbum" class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0648}</div>
								<div class="wblb-wbnr zy-h">
									<select name="albumid" class="guiigo-ps" id="uploadalbumid">
									<!--{loop $albums $value}-->
										<!--{if $value['albumid'] == $_GET['albumid']}-->
											<option value="{$value[albumid]}" selected="selected">{$value[albumname]}</option>
										<!--{else}-->
											<option value="{$value[albumid]}">{$value[albumname]}</option>
										<!--{/if}-->
									<!--{/loop}-->
									</select>
								</div>
							</li>
							<div id="creatalbum" style="display:none;">
						<!--{else}-->
							<input type="hidden" name="albumop" value="creatalbum" />
							<div id="creatalbum">
						<!--{/if}-->
								<div class="tfm">
									<li class="guiigo-flex xh-b cl">
										<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0649}</div>
										<div class="wblb-wbnr zy-h"><input type="text" name="albumname" id="albumname" class="guiigo-px s-a" value="" autocomplete="off" placeholder="{lang guiigo_manage:tlang0298}"></div>
									</li>
									<li class="wblb-nrsr xh-b zy-h cl">
										<div class="wblb-wbnr zy-h"><textarea name="depict" class="guiigo-pt s-a" placeholder="{lang album_depict}"></textarea></div>
									</li>
									<!--{if $_G['setting']['albumcategorystat'] && $categoryselect}-->
									<style type="text/css">
									#catid {background: url(template/guiigo_app/static/images/guiigo-ps.png) no-repeat;background-position: right;background-size: .55rem auto;-webkit-appearance: none;width: 100%;height: 1rem;line-height: 1rem;font-size: inherit;border: none;outline: none;border-radius: 0;}
									</style>
									<li class="guiigo-flex xh-b cl">
										<div class="wblb-wbbt zy-c">{lang site_categories}</div>
										<div class="wblb-wbnr zy-h">$categoryselect</div>
									</li>
									<!--{/if}-->
									<li class="guiigo-flex xh-b cl">
										<div class="wblb-wbbt zy-c">{lang privacy_settings}</div>
										<div class="wblb-wbnr zy-h">
											<select name="friend" id="uploadfriend" class="guiigo-ps" onchange="passwordShow(this.value);">
												<option value="0">{lang friendname_0}</option>
												<option value="1">{lang friendname_1}</option>
												<option value="2">{lang friendname_2}</option>
												<option value="3">{lang friendname_3}</option>
												<option value="4">{lang friendname_4}</option>
											</select>
										</div>
									</li>
									<li id="span_password" class="guiigo-flex xh-b cl" style="display:none;">
										<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0650}</div>
										<div class="wblb-wbnr zy-h"><input type="text" name="password" id="uploadpassword" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0216}"/></div>
									</li>
									<div id="tb_selectgroup" style="display:none;">
										<li class="guiigo-flex xh-b cl">
											<div class="wblb-wbbt zy-c">{lang specified_friends}</div>
											<div class="wblb-wbnr zy-h">
												<select name="selectgroup" class="guiigo-ps" onchange="getgroup(this.value);">
													<option value="">{lang from_friends_group}</option>
													<!--{loop $groups $key $value}-->
													<option value="$key">$value</option>
													<!--{/loop}-->
												</select>
											</div>
										</li>
										<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang friend_name_space}</li>
										<li class="guiigo-flex xh-b cl">
											<div class="wblb-wbnr zy-h"><textarea id="target_names" name="target_names" class="guiigo-pt s-a"></textarea></div>
										</li>
									</div>
								</div>
							</div>
						</ul>
					</div>
					<div class="uploadform">
						<div class="menus guiigo-wbtb list-block-no ms-a bg-c sh-a cl">
							<div class="menus-img">
							<div class="ck8-upimg">
								<ul>
									<li class="wbtb-tbli guiigo-flex xh-b cl">
										<div class="wbtb-wbxm guiigo-flexy zy-c"><h2>{lang guiigo_manage:tlang0651}</h2></div>
										<div class="wbtb-scan zy-h">
											<ul>
												<li class="guiigo-flex scan-liks">
													<a class="bg-e zy-c" href="javascript:;">
														<i class="icon guiigoapp-sctp"></i>{lang guiigo_manage:tlang0366}
														<input type="file" id="filedata" class="pf vm" size="25" name="Filedata" accept="image/*" multiple="multiple" onchange="fileup(this);"/>
													</a>
												</li>
											</ul>
										</div>
									</li>
								</ul>
							</div>
							</div>
						</div>
						<div class="gg-kj-bjtp gg-kj-bjtps list-block-no bg-c mx-b">
							<ul id="attachbody">
							</ul>
						</div>
					</div>
					<div class="mn-a">
						<input type="hidden" name="albumsubmit" id="albumsubmit" value="true" />
						<button type="submit" name="albumsubmit_btn" id="albumsubmit_btn" class="guiigo-pn ab-az zy-a zy-ac formdialog" value="true">{lang upload_start}</button>
						<input type="hidden" name="formhash" value="{FORMHASH}" />
					</div>
				</form>
			<!--{/if}-->
			$guiigo_config['footer_html']
	     </div>
	</div>
	<script type="text/javascript">
		var check = false;
		<!--{if empty($albums)}-->
			ck8(function(){ 
				if(typeof Dz('albumname') == 'object') {
					Dz('albumname').select();
				}
			})
		<!--{/if}-->

		function album_op(id) {
			Dz('selectalbum').style.display = 'none';
			Dz('creatalbum').style.display = 'none';
			Dz(id).style.display = '';
			check = false;
			if(id == 'creatalbum') {
				check = true;
				Dz('albumname').select();
			}
		}

		function fileup(obj){
			var par = {
				upid:'Filedata',
				upurl: "{$_G[siteurl]}misc.php?mod=swfupload&action=swfupload&operation=album",
				uid: discuz_uid ? parseInt(discuz_uid) : 0,
				hash: "$swfconfig[hash]",
				filetype : "$swfconfig[imageexts][ext]",
				maxsize: "$swfconfig[max]",
				callback: fileupcallback,
			}
			app.ImgUpFile(obj,par)
		}
		
		function fileupcallback(e){
			ck8.closeModal();
			var data = eval('('+e+')');
			if(data.picid && data.url){
				var htms = '<li class="guiigo-flex xh-b">\
								<div class="p_img bjtp-swfm bjtp-swfms">\
									<div class="swfm-yskz">\
										<img id="aimg_'+ data.picid +'" src="'+ data.url +'" />\
									</div>\
								</div>\
								<div class="p_img_title bjtp-tpjs guiigo-flexy">\
									<textarea name="title['+ data.picid +']" rows="2" cols="40" class="guiigo-pt zy-h" placeholder="{lang guiigo_manage:tlang0652}"></textarea>\
								</div>\
							</li>';
					ck8('#attachbody').append(htms);
			} else {
                 ck8.toast('{lang guiigo_manage:tlang0305}','jinggao');
			}
		}

		function uploadalbum(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (param.type == 'upalbum' && msg.msg.indexOf('{lang guiigo_manage:tlang0653}') != -1){
					ck8.toast(msg.msg);
					if(!msg.url)
                      msg.url ="home.php?mod=space&uid=$space[uid]&do=album&view=me";
					  setTimeout(function(){
						  ck8.router.load(msg.url, true);
					  },2000)
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}

	</script>
</div>
<!--{template common/footer}-->