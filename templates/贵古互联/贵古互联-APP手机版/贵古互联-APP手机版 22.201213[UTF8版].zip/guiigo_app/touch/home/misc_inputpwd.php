<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="forumdisplay">
	<header class="bar bar-nav guiigo-nydb guiigo-dydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
	</header>
	<div class="content bg-c">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-sq-mbts">
				<h1 class="zy-e">{lang guiigo_manage:tlang0089}</h1>
				<p class="zy-h">{lang guiigo_manage:tlang0503}</p>
			</div>
			<div class="gg-sq-mbsr">
				<form method="post" 
				autocomplete="off" 
				id="invalueform" 
				name="invalueform" 
				action="home.php?mod=misc&ac=inputpwd"
				ck-cus="true"
				ck-param="{type:'modal',callpar:{fid:'$_G[fid]'},fn:'MsgCallPasswdbk',load:'true',uid:'$_G[uid]'}">
					<input type="hidden" name="refer" value="$_SERVER[REQUEST_URI]" />
					<input type="hidden" name="blogid" value="$invalue[blogid]" />
					<input type="hidden" name="albumid" value="$invalue[albumid]" />
					<input type="hidden" name="pwdsubmit" value="true" />
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="xh-b"><input type="password" name="viewpwd" class="guiigo-px" placeholder="{lang guiigo_manage:tlang0216}"/></div>
					<div class="ms-b"><button type="submit" name="submit" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang submit}</button></div>
				</form>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->