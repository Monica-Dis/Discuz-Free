<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
	$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=blog&view=me\">{lang they_blog}</a>";
	$friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');
}-->
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-blog-list">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-f" style="font-size: 1rem;"></i></a>
		<h1 class="title zy-h">{lang blog}</h1>
	</header>
	<div class="content blog-scroll">
		<div class="list-block">
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<!--{if helper_access::check_module('blog')}-->
							<li><a href="<!--{if $_G[uid]}-->home.php?mod=spacecp&ac=blog<!--{else}-->javascript:;<!--{/if}-->" class="zy-f xh-b<!--{if !$_G[uid]}--> login<!--{/if}-->"><i class="icon guiigoapp-bianji"></i>{lang guiigo_manage:tlang0531}</a></li>
						<!--{/if}-->
						<li><a href="<!--{if $_G[uid]}-->search.php?mod=blog<!--{else}-->javascript:;<!--{/if}-->" class="zy-f<!--{if !$_G[uid]}--> login<!--{/if}-->"><i class="icon guiigoapp-xlsousuo"></i>{lang guiigo_manage:tlang0985}</a></li>
					</ul>
				</div>
			</div>
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacebloglist list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $actives[me]}--> on<!--{/if}-->"><a {if $_G[uid]}href="javascript:;" onclick="app.LoadPageForumView('.blog-scroll','home.php?mod=space&do=blog&view=me',['gg-kj-blzt']);"{else}href="javascript:;" class="login"{/if}><!--{if $space[self]}-->{lang guiigo_manage:tlang0667}<!--{else}-->TA<!--{/if}-->{lang guiigo_manage:tlang0679}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[we]}--> on<!--{/if}-->"><a {if $_G[uid]}href="javascript:;" onclick="app.LoadPageForumView('.blog-scroll','home.php?mod=space&do=blog&view=we',['gg-kj-blzt']);"{else}href="javascript:;" class="login"{/if}>{lang guiigo_manage:tlang0680}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[all]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.blog-scroll','home.php?mod=space&do=blog&view=all',['gg-kj-blzt']);">{lang view_all}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div id="prkonzs3" class="gg-kj-blzt">
				<div id="prkonzs3-page" class="ms-a"
				data-url="$theurl" 
				data-pages="{$count}" 
				data-ppp="{$perpage}" 
				data-page="$page" 
				data-islod="false" 
				data-distance="20">
				<!--{if $count}-->
					<div class="gg-kj-rzlb list-block-no bg-c xh-b sh-a">
						<ul class="list-container">
						<!--{loop $list $k $value}-->
							<li class="xh-b">
								<!--{if $value[pic]}--><div class="twlbm-img"><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]"><img lazysrc="$value[pic]" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"></a></div><!--{/if}-->
								<div class="twlbm-nr<!--{if !$value[pic]}--> twlbm-wtnr<!--{/if}-->">
									<!--{eval $stickflag = isset($value['stickflag']) ? 0 : 1;}-->
									<h2><!--{if !$stickflag}--><i class="icon guiigoapp-zhiding zy-a bg-d"></i><!--{/if}--><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]"{if $value[magiccolor]} style="color: {$_G[colorarray][$value[magiccolor]]}"{/if} class="zy-e"><!--{if $value['friend']}--><em class="zy-i">[{lang guiigo_manage:tlang0681}]</em><!--{/if}-->$value[subject]</a></h2>
									<p><span class="twlbm-nr-hf"><a href="home.php?mod=space&uid=$value[uid]&do=profile" class="zy-c"><!--{avatar($value[uid],small)}-->$value[username]</a></span><span class="twlbm-nr-sj zy-c">$value[dateline]</span></p>
								</div>
							</li>
						<!--{/loop}-->
						</ul>
					</div>
					<!--{if $multi}-->
						<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
							<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
						</div>
						<div onclick="infinite('#prkonzs3-page')" class="loadpage bg-c bk-e zy-c">{lang guiigo_manage:tlang0492}<i class="icon guiigoapp-ssxx zy-c"></i></div>
					<!--{/if}-->
				<!--{else}-->
					<div class="guiigo-wnrtx guiigo-wnrtxx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0682}</p>
					</div>
				<!--{/if}-->
				</div>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
<script type="text/javascript">
function fuidgoto(fuid) {
	var parameter = fuid != '' ? '&fuid='+fuid : '';
	window.location.href = 'home.php?mod=space&do=blog&view=we'+parameter;
}
</script>
</div>
<!--{template common/footer}-->