<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<!--{subtemplate home/spacecp_poke_type}-->
<!--{if $op != 'ignore'}-->
<div class="page page-current" data-mod="spacecp-poke">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0610}</h1>
	</header>
	<div class="content poke-scroll">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacecppoke list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $actives[poke]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.poke-scroll','home.php?mod=spacecp&ac=poke',['gg-kj-dgzh']);">{lang guiigo_manage:tlang0611}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[send]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.poke-scroll','home.php?mod=spacecp&ac=poke&op=send',['gg-kj-dgzh']);">{lang guiigo_manage:tlang0612}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<!--{/if}-->
			<div class="gg-kj-dgzh">
				<!--{if $op == 'send' || $op == 'reply'}-->
				<form method="post" 
				autocomplete="off" 
				id="pokeform_{$tospace[uid]}" 
				name="pokeform_{$tospace[uid]}" 
				action="home.php?mod=spacecp&ac=poke&op=$op&uid=$tospace[uid]"
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pmid:'',type:'pokeform_{$tospace[uid]}'},fn:'MsgCallPriv',load:'true',uid:'$_G[uid]'}"
				>
					<input type="hidden" name="referer" value="{echo dreferer()}">
					<input type="hidden" name="pokesubmit" value="true" />
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="from" value="$_GET[from]" />
					<!--{if $tospace[uid]}-->
						<div class="gg-kj-dzmb ms-a bg-c xh-b sh-a zy-e cl">
							<a href="home.php?mod=space&uid=$tospace[uid]&do=profile" class="dzmb-yhtx"><!--{avatar($tospace[uid],middle)}--></a>
							{lang to} <a href="home.php?mod=space&uid=$tospace[uid]&do=profile" class="zy-l">{$tospace[username]}</a> {lang say_hi}:
						</div>
					<!--{else}-->
						<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
							<ul>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0613}</div>
									<div class="wblb-wbnr zy-h"><input type="text" name="username" value="" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0614}"/></div>
								</li>
							</ul>
						</div>
					<!--{/if}-->
					<div class="gg-kj-dzhy bg-c xh-b">
						<ul>
							<!--{loop $icons $k $v}-->
							<li class="zy-f"><label class="guiigo-pds" for="poke_$k"><input type="radio" name="iconid" id="poke_$k" class="guiigo-pd-k" value="{$k}" {if $k==3}checked="checked"{/if} /><span></span>{$v}</label></li>
							<!--{/loop}-->
						</ul>
					</div>
					<div class="guiigo-wblb list-block-no bg-c sh-a cl">
						<ul>
							<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang max_text_poke_message}</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbnr zy-h"><input type="text" name="note" id="note" value="" size="30" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0229}"/></div>
							</li>
						</ul>
					</div>
					<div class="mn-a">
						<button type="submit" name="pokesubmit_btn" id="pokesubmit_btn" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang send}</button>
						<input type="hidden" name="pokesubmit_btn" value="true" />
					</div>
				</form>
				<script type="text/javascript">
					function succeedhandle_{$_GET[handlekey]}(url, msg, values) {
						if(values['from'] == 'notice') {
							deleteQueryNotice(values['uid'], 'pokeQuery');
						}
						showCreditPrompt();
					}
					function MsgCallPriv(msg,par,param){
						if(typeof msg === 'object' || typeof par === 'object'){
							if (msg.msg.indexOf('{lang guiigo_manage:tlang0615}') != -1 && param.type == 'pokeform_{$tospace[uid]}'){
								ck8.toast('{lang guiigo_manage:tlang0616}');
								setTimeout(function(){
									ck8.router.back()
								},2000)
							}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0586}') != -1 && param.type == 'pokeform_{$tospace[uid]}'){
								ck8.toast('{lang guiigo_manage:tlang0609}');
							}else {
								ck8.toast(msg.msg,'shibai');
							}
						}else{
							ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
						}
					}
				</script>
				<!--{elseif $op == 'view'}-->
				kaikaikai
				<!--{loop $list $key $subvalue}-->
				<p class="pbm mbm bbda">
					<!--{if $subvalue[fromuid]==$space[uid]}-->{lang me}<!--{else}--><a href="home.php?mod=space&uid=$subvalue[fromuid]" class="xi2">{$value[fromusername]}</a><!--{/if}-->:
					<span class="xw0">
						<!--{if $subvalue[iconid]}-->{$icons[$subvalue[iconid]]}<!--{else}-->{lang say_hi}<!--{/if}-->
						<!--{if $subvalue[note]}-->, {lang say}: $subvalue[note]<!--{/if}-->
						&nbsp; <span class="xg1"><!--{date($subvalue[dateline],'n-j H:i')}--></span>
					</span>
				</p>
				<!--{/loop}-->
				<div class="pbn ptm xg1 xw0">
					<a href="home.php?mod=spacecp&ac=poke&op=reply&uid=$value[uid]&handlekey=pokehk_{$value[uid]}" id="a_p_r_$value[uid]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang back_to_say_hello}</a><span class="pipe">|</span>
					<a href="home.php?mod=spacecp&ac=poke&op=ignore&uid=$value[uid]" id="a_p_i_$value[uid]" onclick="showWindow('pokeignore', this.href, 'get', 0);">{lang ignore}</a>
					<!--{if !$value['isfriend']}--><span class="pipe">|</span><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=addfriendhk_{$value[uid]}" id="a_friend_$value[uid]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang add_friend}</a> <!--{/if}-->
				</div>
				<!--{elseif $op == 'ignore'}-->
				<form method="post" autocomplete="off" id="friendform_{$uid}" name="friendform_{$uid}" action="home.php?mod=spacecp&ac=poke&op=ignore&uid=$uid" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{type:'$_GET['op']'},fn:'MsgCallRaterange',load:'true',uid:'$_G[uid]'}">
					<input type="hidden" name="referer" value="{echo dreferer()}">
					<input type="hidden" name="ignoresubmit" value="true" />
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="from" value="$_GET[from]" />
					<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
					<div class="c altw mtm mbm">{lang determine_lgnore_poke}</div>
				</form>
				<!--{else}-->
				<!--{if $list}-->
				<div class="gg-kj-hyts ms-a bg-c sh-a zy-c">
					<a href="home.php?mod=spacecp&ac=poke&op=ignore" id="a_poke" class="gg-kj-hlqz zy-l dialog" 
					ck-cus="true" 
					ck-param="{type:'modal',callpar:{pid:'$value[id]'},fn:'MsgCallRaterange',load:'true',uid: '$_G[uid]'}" 
					external ><i class="icon guiigoapp-dzhhl"></i>{lang ignore_all}</a>
					<i class="icon guiigoapp-biaoqing"></i>{lang you_can_reply_ignore}
				</div>
				<div id="poke_ul" class="gg-kj-sdzh bg-c sh-a">
					<ul>
						<!--{loop $list $key $value}-->
						<li id="poke_$value[uid]" class="xh-b cl">
							<div class="sdzh-yhtx"><a href="home.php?mod=space&uid=$value[uid]&do=profile"><!--{avatar($value[uid],middle)}--></a></div>
							<div id="poke_td_$value[uid]" class="sdzh-nrcz">
								<div class="nrcz-zhdz zy-h">
									<span class="zy-c"><!--{date($value[dateline], 'n-j H:i')}--></span>
									<a href="home.php?mod=space&uid=$value[fromuid]&do=profile" class="zy-l">{$value[fromusername]}</a>:
									<!--{if $value[iconid]}-->{$icons[$value[iconid]]}<!--{else}-->{lang say_hi}<!--{/if}-->
								</div>
								<!--{if $value[note]}--><div class="nrcz-zhnr bg-c"><div class="zhnr-nrys bk-d bg-p zy-b">$value[note]</div></div><!--{/if}-->
								<div class="nrcz-hyhd">
									<a href="home.php?mod=spacecp&ac=poke&op=reply&uid=$value[uid]&handlekey=pokereply" id="a_p_r_$value[uid]" style="color:#FF9900;"><i class="icon guiigoapp-tabkdzh"></i>{lang guiigo_manage:tlang0617}</a>
									<!--{if !$value['isfriend']}-->
										<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=addfriendhk_{$value[uid]}" 
										id="a_friend_$value[uid]" 
										class="dialog" 
										style="color:#9dca06;" 
										ck-cus="true" 
										ck-confirm="falsea" 
										ck-param="{type:'modal',callpar:{fuid:'$space[uid]'},fn:'MsgCallGrfoll',load:'true',uid:'{$_G[uid]}'}" 
										external ><i class="icon guiigoapp-tabkjhy"></i>{lang guiigo_manage:tlang0618}</a>
									<!--{/if}-->
									<a href="home.php?mod=spacecp&ac=poke&op=ignore&uid=$value[uid]&handlekey=pokeignore" id="a_p_i_$value[uid]" class="dialog" style="color:#ff6060;" 
									ck-cus="true" 
									ck-param="{type:'modal',callpar:{pid:'$value[id]'},fn:'MsgCallRaterange',load:'true',uid: '$_G[uid]'}" 
									external ><i class="icon guiigoapp-dzhhl"></i>{lang ignore}</a>
								</div>
							</div>
						</li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang no_new_poke}</p>
					</div>
				<!--{/if}-->
				<script type="text/javascript">
					function succeedhandle_pokereply(url, msg, values) {
						if(parseInt(values['uid'])) {
							$('poke_'+values['uid']).style.display = "none";
						}
						showCreditPrompt();
					}
					function errorhandle_pokeignore(msg, values) {
						if(parseInt(values['uid'])) {
							$('poke_'+values['uid']).style.display = "none";
						}
					}
					function errorhandle_allignore(msg, values) {
						if($('poke_ul')) {
							$('poke_ul').innerHTML = '<p class="emp">{lang ignore_all_poke}</p>';
						}
					}
				</script>
				<!--{/if}-->
			</div>
		<!--{if $op != 'ignore'}-->
		$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{/if}-->
<!--{template common/footer}-->