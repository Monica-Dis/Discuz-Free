<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
	$_G['home_tpl_titles'] = array('{lang invite_friend}');
}-->
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="invite">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<a class="button button-link pull-left open-panel" style="margin-left: 0;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a href="javascript:;" class="button button-link pull-right" onclick="appShareAllview('#share_title','#share_img');"><i class="icon guiigoapp-fenxiang zy-f"></i></a>
		<!--{else}-->
		<a href="javascript:;" class="button button-link pull-right" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');"><i class="icon guiigoapp-fenxiang zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang invite_friends}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div id="share_title" style="display: none;">$guiigo_config['site_name'] - {lang guiigo_manage:tlang0978}</div>
			<div class="popup-actions" id="guiigo-nrdbfx">
				<div class="actions-text guiigo-hdfx">
					<div class="gg-app-hide hdfx-hdxm xh-b bg-e">
						<a href="javascript:;"  data-app="weixin" class="nativeShare weixin zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wx.png" class="vm"></span>{lang guiigo_manage:tlang0153}</a>
						<a href="javascript:;" data-app="weixinFriend" class="nativeShare weixin_timeline zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/pyq.png" class="vm"></span>{lang guiigo_manage:tlang0154}</a>
						<a href="javascript:;" data-app="QQ" class="nativeShare qq zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/qq.png" class="vm"></span>{lang guiigo_manage:tlang0155}</a>
						<a href="javascript:;" data-app="QZone" class="nativeShare qzone zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kj.png" class="vm"></span>{lang guiigo_manage:tlang0156}</a>
						<a href="javascript:;" data-app="sinaWeibo" class="nativeShare weibo zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wb.png" class="vm"></span>{lang guiigo_manage:tlang0157}</a>
					</div>
					<div class="gg-app-show hdfx-xcxt xh-b bg-e">
						<span class="icon guiigoapp-xiaochengxu"></span>
						<h2>{lang guiigo_manage:tlang1002}</h2>
						<p>{lang guiigo_manage:tlang1003}</p>
					</div>
					<div class="hdfx-hdxm bg-e">
						<a href="javascript:;" class="zy-f zd-12" onclick="copy(this);" id="cptextid"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/fz.png" class="vm"></span>{lang guiigo_manage:tlang0158}</a>
					</div>
					<a href="javascript:;" class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</a>
				</div>
			</div>
			<div class="share-layer"></div>
			<div id="share_img" class="gg-kj-rwbg gg-yq-yqbg">
				<img src="template/guiigo_app/static/images/yqbg.jpg" class="vm">
				<div class="yqbg-gnms bg-c">
					<div class="gnms-jtxx list-block-no">
						<ul>
							<li class="zy-f"><i class="icon guiigoapp-duigou" style="color:#ffa545;"></i>{lang guiigo_manage:tlang0495}</li>
							<li class="zy-f"><i class="icon guiigoapp-duigou" style="color:#ffd300;"></i>{lang guiigo_manage:tlang0496}</li>
							<li class="zy-f"><i class="icon guiigoapp-duigou" style="color:#83da56;"></i>{lang guiigo_manage:tlang0497}</li>
							<li class="zy-f"><i class="icon guiigoapp-duigou" style="color:#f47584;"></i>{lang guiigo_manage:tlang0498}</li>
							<li class="zy-f"><i class="icon guiigoapp-duigou" style="color:#3cb4fb;"></i>{lang guiigo_manage:tlang0499}</li>
							<li class="zy-f"><i class="icon guiigoapp-duigou" style="color:#b03be9;"></i>{lang guiigo_manage:tlang0500}</li>
						</ul>
					</div>
					<div class="gnms-jran">
						<!--{if $_G['uid']}-->
							<a href="home.php?mod=invite&accept=yes" 
							class="dialog guiigo-pn ab-a zy-a" 
							ck-cus="true" 
							ck-param="{type:'modal',callpar:{uid:'$_G['uid']'},fn:'MsgCallInvite',load:'true',uid: '$_G[uid]'}" 
							external >{lang accept_invitation}</a>
							<a href="home.php?mod=invite&accept=no" 
							class="dialog guiigo-pn jran-wbjk ab-b zy-a" 
							ck-cus="true" 
							ck-param="{type:'modal',callpar:{uid:'$_G['uid']'},fn:'MsgCallInvite',load:'true',uid: '$_G[uid]'}" 
							external >{lang lgnore_invitation}</a>
						<!--{else}-->
							<!--{if $_G['setting']['regstatus']}-->
							<a href="member.php?mod={$_G[setting][regname]}&referer=$jumpurl" class="guiigo-pn ab-a zy-a">{lang want_to_register}</a>
							<!--{/if}-->
							<a href="member.php?mod=logging&action=login&referer=$jumpurl" class="guiigo-pn jran-wbjk ab-c zy-a<!--{if !$_G['setting']['regstatus']}--> jran-wzcq<!--{/if}-->" >{lang register_immediately}</a>
						<!--{/if}-->
					</div>
				</div>
			</div>
			<div class="gg-kj-yqxq list-block-no">
				<ul>
					<li class="bg-c">
						<a href="home.php?mod=space&uid=$uid&do=profile">
							<div class="yqxq-yhtx guiigo-ty">
								<!--{avatar($space[uid],middle)}-->
							</div>
							<h2 class="zy-h">{$space[username]}</h2>
							<p class="zy-b">{lang guiigo_manage:tlang0501}</p>
						</a>
					</li>
					<!--{loop $flist $key $value}-->
						<li class="bg-c">
							<a href="home.php?mod=space&uid=$value[uid]&do=profile">
								<div class="yqxq-yhtx guiigo-ty">
									<!--{avatar($value[uid],middle)}-->
								</div>
								<h2 class="zy-h">$value[username]</h2>
								<p class="zy-g">{lang guiigo_manage:tlang0152}</p>
							</a>
						</li>
					<!--{/loop}-->
				</ul>
			</div>
			<div class="gg-kj-dbta"><img src="template/guiigo_app/static/images/yqbg-d.png" class="vm"></div>
			$guiigo_config['footer_html']
		</div>
	</div>
<script>
ck8(function(){
	if(ck8('#focbtn').length > 0){
		ck8('#focbtn').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('#rewardbut').length > 0){
		ck8('#rewardbut').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('.debatereply').length > 0){
		ck8('.debatereply').click(function(e){
			Dz('needmessage').focus()
		})
	}
})

function ShareAllinvite(){
	//�õ���������
		var config = getShareData('#share_title','#share_img');
	<!--{if ($guiigo_config['browser']['isqq'] || $guiigo_config['browser']['isuc']) && !$guiigo_config['browser']['iswx']}-->
		//����� UC qq �����
		nativeShare(config);
	<!--{elseif $guiigo_config['browser']['iswx']}-->
		//�����΢�������
		wxshareJssdkAjax(config)
	<!--{else}-->
		//������� ΢������� UC qq �����
		webShare(config)
	<!--{/if}-->
}

function MsgCallInvite(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0502}') != -1){
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}
</script>
</div>
<!--{template common/footer}-->