<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $list}-->
<ul id="{$_GET[key]}_getcomment_{$value[doid]}">
<!--{loop $list $value}-->
	<!--{if $value[uid]}-->
	<li class="xh-b zy-f" id="{$_GET[key]}_doing_delete_{$value[doid]}_{$value[id]}" >
		<a href="home.php?mod=space&uid=$value[uid]" class="zy-l">$value[username]</a>: $value[message] <span class="zy-g"><!--{date($value['dateline'], 'n-j H:i')}--></span>
		<!--{if $value[uid]==$_G[uid] || $dv['uid']==$_G[uid] || checkperm('managedoing')}-->
			<a href="home.php?mod=spacecp&ac=doing&op=delete&doid=$value[doid]&id=$value[id]&handlekey={$_GET[key]}_doing_delete_{$value[doid]}_{$value[id]}&keys={$_GET[key]}_{$value[doid]}" 
			class="zy-i dialog" 
			ck-cus="true" 
			ck-param="{type:'modal',callpar:{type:'shanchu'},fn:'MsgCallwzplx',load:'true',uid: '$_G[uid]'}" 
			external >{lang delete}</a>
		<!--{/if}-->
	</li>
	<!--{/if}-->
<!--{/loop}-->
</ul>
<!--{/if}-->
