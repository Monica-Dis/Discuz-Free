<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $op == 'delete'}-->
<div id="">
	<form method="post"
		autocomplete="off" 
		action="portal.php?mod=portalcp&ac=article&op=delete&aid=$_GET[aid]"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{type:'$_GET['op']',catid:'$_GET['delcatid']'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}">
		<div class="gg-zx-wzsc">
			<!--{if $_G['group']['allowpostarticlemod'] && $article['status'] == 1}-->
			{lang article_delete_sure}
			<input type="hidden" name="optype" value="0" class="pc" />
			<!--{else}-->
			<label class="guiigo-pds"><input type="radio" name="optype" value="0" class="guiigo-pd-k" /><span></span>{lang article_delete_direct}&nbsp;&nbsp;&nbsp;</label>
			<label class="guiigo-pds"><input type="radio" name="optype" value="1" class="guiigo-pd-k" checked="checked" /><span></span>{lang article_delete_recyclebin}</label>
			<!--{/if}-->
		</div>
		<input type="hidden" name="btnsubmit" value="true" />
		<input type="hidden" name="aid" value="$_GET[aid]" />
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
	</form>
</div>
<!--{elseif $op == 'related'}-->
	<!--{if $ra}-->
	<li id="raid_li_$ra[aid]"><input type="hidden" name="raids[]" value="$ra[aid]" size="5">[ $ra[aid] ] <a href="{echo fetch_article_url($ra);}" target="_blank">$ra[title]</a> <a href="javascript:;" onclick="raid_delete($ra[aid]);">{lang delete}</a></li>
	<!--{/if}-->
<!--{elseif $op == 'add_success'}-->
{eval 
$eideurl = "$article_add_url&op=edit&aid=$aid";
$url = "portal.php?mod=view&aid=$aid";
$arr1 = array('aid' => $aid,'wurl' => $url,'eideurl' => $eideurl,'sendurl'=>$article_add_url);
showmessage("{lang guiigo_manage:tlang0839}",NULL,$arr1);

}
<!--{else}-->
<!--{if !empty($_GET['inajax'])}-->
<div class="popup popup-about">
	<header class="bar bar-nav postsel">
		<a class="icon ck8-icon-guanbi3 pull-left close-popup c9 f1-3"></a>
		<button id="postbtn" class="button pull-right btns" onclick="locations('forum.php?mod=post&action=newthread&fid=' + selectfid + '&special=$special');" disabled="disabled"></button>
	</header>
<!--{/if}-->
<div class="page page-current" data-mod="portal-post">
	<header class="bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b app-header">
		<a class="button button-link pull-left close-popup zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<h1 class="title zy-h"><!--{if !empty($aid)}-->{lang article_edit}<!--{else}-->{lang article_publish}<!--{/if}--></h1>
	</header>
	<div class="content">
		<div class="list-block">
		<div id="append_color_style"></div>
		<div id="pl-postform">
			<form method="post" 
				autocomplete="off" 
				id="articleform" 
				action="portal.php?mod=portalcp&ac=article{if $_GET[modarticlekey]}&modarticlekey=$_GET[modarticlekey]{/if}" 
				enctype="multipart/form-data"
				ck-cus="true" 
				ck-param="{type:'modal',load:'true',fn:'MsgCallPost',callpar:{type:'post'},uid:'$_G[uid]'}">
				<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang article_title}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="title" id="title" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0298}" value="$article[title]" size="80" /></div>
							<a href="javascript:;" class="poll-sxan" onclick="_display('setstyle')"><i class="icon guiigoapp-wzbtys {if $stylecheck[1] || $stylecheck[2] || $stylecheck[3] || $stylecheck[0]}zy-b{else}zy-c{/if}"></i></a>
						</li>
						<li class="guiigo-flex xh-b cl" style="display:none;" id="setstyle">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0840}</div>
							<div class="wblb-wbnr gg-zx-btys zy-h">
								<input type="hidden" id="highlight_style_0" name="highlight_style[0]" value="$stylecheck[0]" />
								<input type="hidden" id="highlight_style_1" name="highlight_style[1]" value="$stylecheck[1]" />
								<input type="hidden" id="highlight_style_2" name="highlight_style[2]" value="$stylecheck[2]" />
								<input type="hidden" id="highlight_style_3" name="highlight_style[3]" value="$stylecheck[3]" />
								<a href="javascript:;" id="color_style" class="pn colorwd" fwin="eleStyle" onclick="change_title_color(this.id);" style="background-color:$stylecheck[0]" /></a>
								<a href="javascript:;" id="highlight_op_1" onclick="switchhl(this, 1)" class="dopt_b{if $stylecheck[1]} cnt{/if}" style="text-indent:0;text-decoration:none;font-weight:700;" title="{lang e_bold}">B</a>
								<a href="javascript:;" id="highlight_op_2" onclick="switchhl(this, 2)" class="dopt_i{if $stylecheck[2]} cnt{/if}" style="text-indent:0;text-decoration:none;font-style:italic;" title="{lang e_italic}">I</a>
								<a href="javascript:;" id="highlight_op_3" onclick="switchhl(this, 3)" class="dopt_l{if $stylecheck[3]} cnt{/if}" style="text-indent:0;text-decoration:underline;" title="{lang e_underline}">U</a>
							</div>
						</li>
						<!--{if $_G['cache']['portalcategory'] && $categoryselect}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang article_category}</div>
								<div class="wblb-wbnr zy-h">$categoryselect</div>
							</li>
						<!--{/if}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang article_source}</div>
							<div class="wblb-wbnr zy-h"><input type="text" id="from" name="from" class="guiigo-px s-a" value="$article[from]" {if $from_cookie}size="10"{else}size="30"{/if} /></div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang article_source_url}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="fromurl" class="guiigo-px s-a" value="$article[fromurl]" size="30" /></div>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang article_dateline}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="dateline" id="dateline" class="guiigo-px s-a" value="$article[dateline]" size="30" /></div>
						</li>
						<!--{if empty($article['aid'])}-->
							<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang article_auto_grab}</li>
							<li class="guiigo-flex xh-b cl">
								<select name="from_idtype" id="from_idtype" class="guiigo-ps gg-zx-fbid zy-f bk-e">
									<option value="tid"$idtypes[tid]>{lang thread} tid</option>
									<option value="blogid"$idtypes[blogid]>{lang blog} id</option>
								</select>
								<input type="text" name="from_id" id="from_id" value="$_GET[from_id]" size="8" class="guiigo-px gg-zx-fbic guiigo-flexy zy-e" />
								<button type="button" name="from_button" class="guiigo-pn gg-zx-fbia ab-az zy-a zy-ac" onclick="return from_get();">{lang grab}</button>
								<input type="hidden" name="id" value="$_GET[from_id]" />
								<input type="hidden" name="idtype" value="$_GET[from_idtype]" />
							</li>
						<!--{/if}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang article_url}</div>
							<div class="wblb-wbnr zy-h"><input type="text" class="guiigo-px s-a" name="url" value="$article[url]" size="30" /></div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang article_author}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="author" class="guiigo-px s-a" value="$article[author]" size="30" /></div>
						</li>
						<!--{if $category[$catid][allowcomment]}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-f">{lang article_forbidcomment_description}</div>
								<div class="wblb-wbnr zy-h"><div class="guiigo-pc"><input type="checkbox" name="forbidcomment" id="ck_allowcomment" value="1"{if isset($article['allowcomment']) && empty($article['allowcomment'])}checked="checked"{/if} /><label for="ck_allowcomment"><em></em></label></div></div>
							</li>
						<!--{/if}-->
						<input type="hidden" id="conver" name="conver" value="" />
						<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang article_tag}</li>
						<li class="wblb-nrsr xh-b zy-h cl">
							<div class="wblb-wbnr zy-h">
								<div class="gg-fb-dxpx">
									<!--{loop $article_tags $key $tag}-->
									<label for="article_tag_$key" class="guiigo-pd"><input type="checkbox" name="tag[$key]" id="article_tag_$key" class="guiigo-pd-k"{if $article_tags[$key]} checked="checked"{/if} /><span></span>$tag_names[$key]</label>
									<!--{/loop}-->
								</div>
							</div>
						</li>
					</ul>
				</div>
				<div class="fbon-txim">
					<div class="txim-bt bg-g xh-b zy-c">{lang guiigo_manage:tlang0841}</div>
					<div class="txim-tx bg-c"><textarea class="guiigo-pt zy-e" name="content" id="needmessage" placeholder="{lang guiigo_manage:tlang0842}">$article_content[content]</textarea></div>
					<div class="txim-im bg-c cl" id="imglist">
						<div class="txim-scan">
							<a href="JavaScript:void(0)" class="bg-e zy-c bk-d">
								<i class="icon guiigoapp-tpscjh zy-g"></i>
								<input type="file" name="Filedata" id="filedata" class="mediaup" accept="image/*" multiple="multiple" onchange="fileup(this);"/>
							</a>
						</div>
					</div>
				</div>
				<!--{if $secqaacheck || $seccodecheck}-->
					<div class="gg-fb-yzmy ms-a xh-b">
						<!--{subtemplate common/seccheck}-->
					</div>
				<!--{/if}-->
				<div class="mn-a">
					<button type="button" id="issuance" class="guiigo-pn ab-az zy-a zy-ac" name="articlebutton" onclick="Postreyl();">{lang submit}</button>
				</div>
				<input type="hidden" id="aid" name="aid" value="$article[aid]" />
				<input type="hidden" name="cid" value="$article_content[cid]" />
				<input type="hidden" id="attach_ids" name="attach_ids" value="0" />
				<input type="hidden" name="articlesubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			</form>
			</div>
			<script type="text/javascript">
			function fileup(obj){
				var catid = '$catid';
				catid = parseInt(catid);
				if(!catid || catid <= 0){
					ck8.toast('{lang guiigo_manage:tlang0843}','shibai');
					return false;
				}
				
				app.ImgUpFile(obj,{
					upurl: {
						url:"{$_G[siteurl]}misc.php?mod=swfupload&action=swfupload&operation=portal",
						data:{
							uid: '$_G[uid]',
							hash: "$swfconfig[hash]",
							catid: "$catid",
							aid:"$aid"
						}
					},
	
					maxsize: 2048,
					filetype:"*.jpg;*.jpeg;*.gif;*.png;*.bmp",
					callback:function(res){
						res = eval("("+res+")"); 
						if(!res.errorcode && res.aid){
							var htms = '<div class="imgviwe">\
										<span aid="'+ res.aid +'" class="icon guiigoapp-cuo bg-j zy-a" onclick="pldelFile(this,\''+res.bigimg+'\');"></span>\
										<div class="p_img">\
											<img style="height:54px;width:54px;" id="aimg_'+ res.aid +'" src="'+ SITEURL + res.smallimg +'" />\
										</div>\
										<label class="guiigo-pds">\
											<input type="radio" name="setconver" id="setconver'+ res.aid +'" class="guiigo-pd-k" value="1" \
											onclick="setConver(ck8(this).attr(\'coverstr\'));" coverstr=\''+res.cover+'\' /><span></span>{lang guiigo_manage:tlang0844}\
										</label>\
									</div>';
							ck8('#imglist').append(htms);
							insertImage(res.bigimg)
							ck8('#filedata').val('');
                            var ids = ck8('#attach_ids').val()
							ck8('#attach_ids').val(ids+','+res.aid)
						}else{
							ck8.toast('{lang guiigo_manage:tlang0305}','shibai');
						} 
					}
				})
			}

			function insertImage(text) {
				var img = '\n<img src="'+text+'" />\n';
				ck8('#needmessage').val(ck8('#needmessage').val()+img);
			}

			function pldelFile(obj,text){
				var obj = ck8(obj),
					aid = obj.attr('aid');
				if(!aid)return false;
				if(!navigator.onLine){
					ck8.toast('{lang guiigo_manage:tlang0845}','jinggao');
				   return false;
				}
				ck8.showPreloader('',true);
				ck8.get(
					'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + aid,
					function(s) {
						setTimeout(function(){$.hidePreloader()}, 100);
						var _val = ck8('#needmessage').val();
						var tt = '<img src="'+text+'"';
						tt = tt+' />';
						ck8('#needmessage').val(_val.replace(tt,''));
						obj.parent().remove();
					}
				)
				return false;
			}

			ck8(function(){
				ck8("#dateline").datetimePicker({})
				if(Dz('title')) {
					Dz('title').focus();
				}
				<!--{if !empty($article['conver'])}-->
				setConver('$article[conver]');
				<!--{/if}-->
			})
			function hideMenu(id){
				ck8('#'+ id).hide()
			}
			function switchhl(obj, v) {
				if(parseInt(Dz('highlight_style_' + v).value)) {
					Dz('highlight_style_' + v).value = 0;
					obj.className = obj.className.replace(/ cnt/, '');
				} else {
					Dz('highlight_style_' + v).value = 1;
					obj.className += ' cnt';
				}
			}
			function change_title_color(hlid) {
				var showid = hlid;
				if(!Dz(showid + '_menu')) {
					var str = '';
					var coloroptions = {'0' : '#000', '1' : '#EE1B2E', '2' : '#EE5023', '3' : '#996600', '4' : '#3C9D40', '5' : '#2897C5', '6' : '#2B65B7', '7' : '#8F2A90', '8' : '#EC1282'};
					var menu = document.createElement('div');
					menu.id = showid + '_menu';
					menu.className = 'cmen';
					menu.style.display = 'none';
					for(var i in coloroptions) {
						str += '<a href="javascript:;" onclick="Dz(\'' + hlid + '\').value=' + i + ';Dz(\'' + showid + '\').style.backgroundColor=\'' + coloroptions[i] + '\';hideMenu(\'' + menu.id + '\')" style="background:' + coloroptions[i] + ';color:' + coloroptions[i] + ';">' + coloroptions[i] + '</a>';
					}
					menu.innerHTML = str;
					Dz('append_'+ hlid).appendChild(menu);
				}
				var showoffset = ck8('#'+ showid).offset();
				var apptop = ck8('#append_'+ hlid).offset().top;
				var style = {'position':'absolute','zIndex': 10,'left': (showoffset.left / 2) + ck8('#'+ showid).width() ,'top': showoffset.top - apptop + ck8('#'+ showid).height()}
				ck8('#'+ showid + '_menu').css(style).show()
			}		
			function setConver(attach) {
				Dz('conver').value = attach;
			}
			function from_get() {
				var el = Dz('catid');
				var catid = el ? el.value : 0;
				var href='portal.php?mod=portalcp&ac=article&from_idtype='+Dz('from_idtype').value+'&catid='+catid+'&from_id='+Dz('from_id').value+'&getauthorall=';
				app.PageRefresh('','page',href+'&inajax=1')
				return true;
			}
			function Postreyl() {
				var Objform = ck8('#pl-postform').find('form')[0];
				if(pvalidate(Objform)){
					 app.FormDialog('#pl-postform')
				}
			}
			function MsgCallPost(msg,par,param){
				if(typeof msg === 'object' || typeof par === 'object'){
					if (msg.msg.indexOf('{lang guiigo_manage:tlang0839}') != -1 && param.type == 'post'){
						ck8.toast(msg.msg,'shibai');
						setTimeout(function(){
							ck8.router.load(par.wurl.replace('amp;',''),true);
						},2000)

					}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0242}') != -1 && param.type == 'post'){
						ck8.toast(msg.msg,'shibai');
						seccode(ck8('.seccodeimg'))
					}else {
						ck8.toast(msg.msg,'shibai');
					}
				}else{
					ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
				}
			}
			function pvalidate(obj) {
 				var title = Dz('title');
				if(title) {
					var slen = mb_strlen(title.value);
					if (slen < 1 || slen > 80) {
						ck8.toast("{lang article_validate_title}",'shibai');
						title.focus();
						return false;
					}
				}
				
				if(!check_catid()) {
					return false;
				}

				return true;
			}
			function check_catid(){
				var catObj = Dz("catid");
				if(catObj) {
					if (catObj.value < 1) {
						ck8.toast("{lang article_validate_category}",'shibai');
						catObj.focus();
						return false;
					}
				}
				return true;
			}
			appTplinit(ck8('.page'))
			</script>
		</div>
	</div>
</div>
<!--{if !empty($_GET['inajax'])}-->
</div>
<!--{/if}-->
<!--{/if}-->
<!--{template common/footer}-->

