<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<a name="comment_anchor_$comment[cid]"></a>
<li id="comment_{$comment[cid]}_li" class="xh-b cl">
	<div class="sssj-sstx guiigo-ty">
		<!--{if !empty($comment['uid'])}-->
			<a href="home.php?mod=space&uid=$comment[uid]&do=profile"><!--{avatar($comment[uid],middle)}--></a>
		<!--{else}-->
			<a href="javascript:void(0)"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg"/></a>
		<!--{/if}-->
	</div>
	<div class="sssj-ssnr sssj-ssnrp">
		<h1>
			<span class="gg-kj-plcz">
				<!--{if !isset($_G[makehtml])}-->
					<a href="javascript:;" {if $_G[uid]}onclick="app.ActionsManage('#guiigo-hfdp','t','auto','closehfdp');portal_comment_requote($comment[cid], '$article[aid]');" class="bg-e zy-g bk-e"{else}class="login bg-e zy-g bk-e"{/if}><i class="icon guiigoapp-sshuifu"></i></a>
				<!--{/if}-->
				<!--{if ($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']}-->
					<a href="portal.php?mod=portalcp&ac=comment&op=edit&cid=$comment[cid]" id="c_$comment[cid]_edit" class="bg-e zy-g bk-e dialog"
					ck-cus="true" 
					ck-param="{type:'modal',callpar:{liid:'{$cid}',type:'bianji'},fn:'MsgCallwzplx',load:'true',uid: '$_G[uid]'}" 
					external ><i class="icon guiigoapp-fbxhfb"></i></a>
					<a href="portal.php?mod=portalcp&ac=comment&op=delete&cid=$comment[cid]" id="c_$comment[cid]_delete" class="bg-e zy-g bk-e dialog"
					ck-cus="true" 
					ck-param="{type:'modal',callpar:{liid:'{$cid}',type:'shanchu'},fn:'MsgCallwzplx',load:'true',uid: '$_G[uid]'}" 
					external ><i class="icon guiigoapp-shanchu"></i></a>
				<!--{/if}-->
			</span>
			<!--{if !empty($comment['uid'])}-->
				<a href="home.php?mod=space&uid=$comment[uid]&do=profile" class="zy-h">$comment[username]</a>
			<!--{else}-->
				<a href="javascript:void(0)" class="zy-h">{lang guest}</a>
			<!--{/if}-->
			<p class="zy-c"><!--{date($comment[dateline])}--><!--{if $comment[status] == 1}--><em class="zy-i"> {lang moderate_need}</em><!--{/if}--></p>
		</h1>
		<div id="comment_$value[cid]" class="gg-kj-plnr zy-e"><!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->$comment[message]<!--{else}-->{lang moderate_not_validate}<!--{/if}--></div>
	</div>
</li>