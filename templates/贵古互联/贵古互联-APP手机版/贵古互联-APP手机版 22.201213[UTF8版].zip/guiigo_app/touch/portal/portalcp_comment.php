<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $_GET['op'] == 'requote'}-->
	[quote]{$comment[username]}: {$comment[message]}[/quote]
<!--{elseif $_GET['op'] == 'edit'}-->
<div id="editcommentform">
	<form id="editcommentform_{$cid}" name="editcommentform_{$cid}" method="post" 
	autocomplete="off" 
	action="portal.php?mod=portalcp&ac=comment&op=edit&cid=$cid{if $_GET[modarticlecommentkey]}&modarticlecommentkey=$_GET[modarticlecommentkey]{/if}"
	ck-cus="true"
	ck-param="{type:'modal',callpar:{liid:'{$cid}',type:'bianji'},fn:'MsgCallwzplx',load:'true',uid:'$_G[uid]'}">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="c">
			<textarea id="message_{$cid}" name="message" cols="70" rows="8" class="guiigo-pt bg-e bk-e pq-a" style="height: 2rem;margin-top: -1rem;margin-bottom: -1rem;">$comment[message]</textarea>
		</div>
	</form>
</div>
<!--{elseif $_GET['op'] == 'delete'}-->
<div id="deletecommentform">
	<form id="deletecommentform_{$cid}" name="deletecommentform_{$cid}" method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=comment&op=delete&cid=$cid"
	ck-cus="true"
	ck-param="{type:'modal',callpar:{liid:'{$cid}',type:'shanchu'},fn:'MsgCallwzplx',load:'true',uid:'$_G[uid]'}">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="c">{lang comment_delete_confirm}</div>
	</form>
</div>
<!--{/if}-->
<!--{template common/footer}-->