var lastusername = '', lastpassword = '', lastemail = '', lastinvitecode = '', stmp = new Array(), modifypwd = false, profileTips = '\u5982\u4e0d\u9700\u8981\u66f4\u6539\u5bc6\u7801\uff0c\u6b64\u5904\u8bf7\u7559\u7a7a';

function errormessage(id, msg) {
	if(Dz(id)) {
		try{
			showInputTip();
		} catch (e) {}
		msg = !msg ? '' : msg;
		if(Dz('tip_' + id)) {
			if(msg == 'succeed') {
				msg = '';
				Dz('tip_' + id).parentNode.className = Dz('tip_' + id).parentNode.className.replace(/ p_right/, '');
				Dz('tip_' + id).parentNode.className += ' p_right';
			} else if(msg !== '') {
				Dz('tip_' + id).parentNode.className = Dz('tip_' + id).parentNode.className.replace(/ p_right/, '');
			}
		}
		if(Dz('chk_' + id)) {
			Dz('chk_' + id).innerHTML = msg;
		}
		Dz(id).className = Dz(id).className.replace(/ er/, '');
		Dz(id).className += !msg ? '' : ' er';
	}
}

function addFormEvent(formid, focus){
	var si = 0;
	var formNode = Dz(formid).getElementsByTagName('input');
	for(i = 0;i < formNode.length;i++) {
		if(formNode[i].name == '') {
			formNode[i].name = formNode[i].id;
			stmp[si] = i;
			si++;
		}
		if(formNode[i].type == 'text' || formNode[i].type == 'password'){
			formNode[i].onfocus = function(){
				showInputTip(!this.id ? this.name : this.id);
			}
		}
	}
	if(!si) {
		return;
	}
	formNode[stmp[0]].onblur = function () {
		checkusername(formNode[stmp[0]].id);
	};
	checkPwdComplexity(formNode[stmp[1]], formNode[stmp[2]]);
	try {
		if(!ignoreEmail) {
			addMailEvent(formNode[stmp[3]]);
		}
	} catch(e) {}

	try {
		if(focus) {
			Dz('invitecode').focus();
		} else {
			formNode[stmp[0]].focus();
		}
	} catch(e) {}
}

function checkPwdComplexity(firstObj, secondObj, modify) {
	modifypwd = modify || false;
	firstObj.onblur = function () {
		if(firstObj.value == '') {
			var pwmsg = !modifypwd ? '\u8bf7\u586b\u5199\u5bc6\u7801' : profileTips;
			if(pwlength > 0) {
				pwmsg += ', \u6700\u5c0f\u957f\u5ea6\u4e3a '+pwlength+' \u4e2a\u5b57\u7b26';
			}
			errormessage(firstObj.id, pwmsg);
		}else{
			errormessage(firstObj.id, !modifypwd ? 'succeed' : '');
		}
		checkpassword(firstObj.id, secondObj.id);
	};
	firstObj.onkeyup = function () {
		if(pwlength == 0 || Dz(firstObj.id).value.length >= pwlength) {
			var passlevels = new Array('','\u5f31','\u4e2d','\u5f3a');
			var passlevel = checkstrongpw(firstObj.id);
			errormessage(firstObj.id, '<span class="passlevel passlevel'+passlevel+'">\u5bc6\u7801\u5f3a\u5ea6:'+passlevels[passlevel]+'</span>');
		}
	};
	secondObj.onblur = function () {
		if(secondObj.value == '') {
			errormessage(secondObj.id, !modifypwd ? '\u8bf7\u518d\u6b21\u8f93\u5165\u5bc6\u7801' : profileTips);
		}
		checkpassword(firstObj.id, secondObj.id);
	};
}

function addMailEvent(mailObj) {

	mailObj.onclick = function (event) {
		emailMenu(event, mailObj.id);
	};
	mailObj.onkeyup = function (event) {
		emailMenu(event, mailObj.id);
	};
	mailObj.onkeydown = function (event) {
		emailMenuOp(4, event, mailObj.id);
	};
	mailObj.onblur = function () {
		if(mailObj.value == '') {
			errormessage(mailObj.id, '\u8bf7\u8f93\u5165\u90ae\u7bb1\u5730\u5740');
		}
		emailMenuOp(3, null, mailObj.id);
	};
	stmp['email'] = mailObj.id;
}
function checkstrongpw(id) {
	var passlevel = 0;
	if(Dz(id).value.match(/\d+/g)) {
		passlevel ++;
	}
	if(Dz(id).value.match(/[a-z]+/ig)) {
		passlevel ++;
	}
	if(Dz(id).value.match(/[^a-z0-9]+/ig)) {
		passlevel ++;
	}
	return passlevel;
}
function showInputTip(id) {
	var p_tips = Dz('registerform').getElementsByTagName('i');
	for(i = 0;i < p_tips.length;i++){
		if(p_tips[i].className == 'p_tip'){
			p_tips[i].style.display = 'none';
		}
	}
	if(Dz('tip_' + id)) {
		Dz('tip_' + id).style.display = 'block';
	}
}

function showbirthday(){
	var el = Dz('birthday');
	var birthday = el.value;
	el.length=0;
	el.options.add(new Option('\u65e5', ''));
	for(var i=0;i<28;i++){
		el.options.add(new Option(i+1, i+1));
	}
	if(Dz('birthmonth').value!="2"){
		el.options.add(new Option(29, 29));
		el.options.add(new Option(30, 30));
		switch(Dz('birthmonth').value){
			case "1":
			case "3":
			case "5":
			case "7":
			case "8":
			case "10":
			case "12":{
				el.options.add(new Option(31, 31));
			}
		}
	} else if(Dz('birthyear').value!="") {
		var nbirthyear=Dz('birthyear').value;
		if(nbirthyear%400==0 || (nbirthyear%4==0 && nbirthyear%100!=0)) el.options.add(new Option(29, 29));
	}
	el.value = birthday;
}

function trim(str) {
	return str.replace(/^\s*(.*?)[\s\n]*$/g, '$1');
}

var emailMenuST = null, emailMenui = 0, emaildomains = ['qq.com', '163.com', 'sina.com', 'sohu.com', 'yahoo.com', 'gmail.com', 'hotmail.com'];
function emailMenuOp(op, e, id) {
	if(op == 3) {
		checkemail(id);
	}
	if(!Dz('emailmore_menu')) {
		return;
	}
	if(op == 1) {
		Dz('emailmore_menu').style.display = 'none';
	} else if(op == 2) {
		showMenu({'ctrlid':'emailmore','pos': '13!'});
	} else if(op == 3) {
		emailMenuST = setTimeout(function () {
			emailMenuOp(1, id);
			checkemail(id);
		}, 500);
	} else if(op == 4) {
	       	e = e ? e : window.event;
                var obj = Dz(id);
        	if(e.keyCode == 13) {
                        var v = obj.value.indexOf('@') != -1 ? obj.value.substring(0, obj.value.indexOf('@')) : obj.value;
                        obj.value = v + '@' + emaildomains[emailMenui];
                        doane(e);
        	}
	} else if(op == 5) {
                var as = Dz('emailmore_menu').getElementsByTagName('a');
                for(i = 0;i < as.length;i++){
                        as[i].className = '';
                }
	}
}

function emailMenu(e, id) {
	e = e ? e : window.event;
        var obj = Dz(id);
	if(obj.value.indexOf('@') != -1) {
		Dz('emailmore_menu').style.display = 'none';
		return;
	}
	var value = e.keyCode;
	var v = obj.value;
	if(!obj.value.length) {
		emailMenuOp(1);
		return;
	}

        if(value == 40) {
		emailMenui++;
		if(emailMenui >= emaildomains.length) {
			emailMenui = 0;
		}
	} else if(value == 38) {
		emailMenui--;
		if(emailMenui < 0) {
			emailMenui = emaildomains.length - 1;
		}
	} else if(value == 13) {
  		Dz('emailmore_menu').style.display = 'none';
  		return;
 	}
        if(!Dz('emailmore_menu')) {
		menu = document.createElement('div');
		menu.id = 'emailmore_menu';
		menu.style.display = 'none';
		menu.className = 'p_pop';
		menu.setAttribute('disautofocus', true);
		Dz('append_parent').appendChild(menu);
	}
	var s = '<ul>';
	for(var i = 0; i < emaildomains.length; i++) {
		s += '<li><a href="javascript:;" ' + (emailMenui == i ? 'class="a" ' : '') + 'onclick="Dz(stmp[\'email\']).value=this.innerHTML;display(\'emailmore_menu\');checkemail(stmp[\'email\']);">' + v + '@' + emaildomains[i] + '</a></li>';
	}
	s += '</ul>';
	Dz('emailmore_menu').innerHTML = s;
	emailMenuOp(2);
}


function checkusername(id) {
	errormessage(id);
	var username = trim(Dz(id).value);
	if(Dz('tip_' + id).parentNode.className.match(/ p_right/) && (username == '' || username == lastusername)) {
		return;
	} else {
		lastusername = username;
	}
	if(username.match(/<|"/ig)) {
		errormessage(id, '\u7528\u6237\u540d\u5305\u542b\u654f\u611f\u5b57\u7b26');
		return;
	}
	var unlen = username.replace(/[^\x00-\xff]/g, "**").length;
	if(unlen < 3 || unlen > 15) {
		errormessage(id, unlen < 3 ? '\u7528\u6237\u540d\u4e0d\u5f97\u5c0f\u4e8e\u0020\u0033\u0020\u4e2a\u5b57\u7b26' : '\u7528\u6237\u540d\u4e0d\u5f97\u8d85\u8fc7\u0020\u0031\u0035\u0020\u4e2a\u5b57\u7b26');
		return;
	}
}

function checkpassword(id1, id2) {
	if(!Dz(id1).value && !Dz(id2).value) {
		return;
	}
	if(pwlength > 0) {
		if(Dz(id1).value.length < pwlength) {
			errormessage(id1, '\u5bc6\u7801\u592a\u77ed\uff0c\u4e0d\u5f97\u5c11\u4e8e '+pwlength+' \u4e2a\u5b57\u7b26');
			return;
		}
	}
	if(strongpw) {
		var strongpw_error = false, j = 0;
		var strongpw_str = new Array();
		for(var i in strongpw) {
			if(strongpw[i] === 1 && !Dz(id1).value.match(/\d+/g)) {
				strongpw_error = true;
				strongpw_str[j] = '\u6570\u5b57';
				j++;
			}
			if(strongpw[i] === 2 && !Dz(id1).value.match(/[a-z]+/g)) {
				strongpw_error = true;
				strongpw_str[j] = '\u5c0f\u5199\u5b57\u6bcd';
				j++;
			}
			if(strongpw[i] === 3 && !Dz(id1).value.match(/[A-Z]+/g)) {
				strongpw_error = true;
				strongpw_str[j] = '\u5927\u5199\u5b57\u6bcd';
				j++;
			}
			if(strongpw[i] === 4 && !Dz(id1).value.match(/[^A-Za-z0-9]+/g)) {
				strongpw_error = true;
				strongpw_str[j] = '\u7279\u6b8a\u7b26\u53f7';
				j++;
			}
		}
		if(strongpw_error) {
			errormessage(id1, '\u5bc6\u7801\u592a\u5f31\uff0c\u5bc6\u7801\u4e2d\u5fc5\u987b\u5305\u542b '+strongpw_str.join('��'));
			return;
		}
	}
	errormessage(id2);
	if(Dz(id1).value != Dz(id2).value) {
		errormessage(id2, '\u4e24\u6b21\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u4e00\u81f4');
	} else {
		errormessage(id2, !modifypwd ? 'succeed' : '');
	}
}

function checkemail(id) {
	errormessage(id);
	var email = trim(Dz(id).value);
	if(Dz(id).parentNode.className.match(/ p_right/) && (email == '' || email == lastemail)) {
		return;
	} else {
		lastemail = email;
	}
	if(email.match(/<|"/ig)) {
		errormessage(id, 'Email \u5305\u542b\u654f\u611f\u5b57\u7b26');
		return;
	}
}

function checkinvite() {
	errormessage('invitecode');
	var invitecode = trim(Dz('invitecode').value);
	if(invitecode == '' || invitecode == lastinvitecode) {
		return;
	} else {
		lastinvitecode = invitecode;
	}
	if(invitecode.match(/<|"/ig)) {
		errormessage('invitecode', '\u9080\u8bf7\u7801\u5305\u542b\u654f\u611f\u5b57\u7b26');
		return;
	}
}
