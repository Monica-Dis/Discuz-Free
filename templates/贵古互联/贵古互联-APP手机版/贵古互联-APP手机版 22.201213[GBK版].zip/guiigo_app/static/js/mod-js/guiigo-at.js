
var atKeywords = null, keyMenuObj = null,atResult = [];
var curatli = 0, atsubmitid = '';
function atSearch(kw, call) {
	if(atKeywords === null) {
		atKeywords = '';
		ck8.get('misc.php?mod=getatuser&inajax=1', function(s) {
			s = s.lastChild.firstChild.nodeValue;
			if(s) {
				atKeywords = s.split(',');
			}
			if(typeof call == 'function') {
				call();
			} else {
				eval(call);
			}
		})
	}
	var lsi = 0;
	for(i in atKeywords) {
		if(atKeywords[i].indexOf(kw) !== -1 || kw === '') {
			atResult[lsi] = kw !== '' ? atKeywords[i].replace(kw, '<i style="color:#ff9645;">' + kw + '</i>') : atKeywords[i];
			lsi++;
			if(lsi > 10) {
				break;
			}
		}
	}
	if(kw && !lsi) {
		curatli = -1;
	}
}

function atEnter(e, call) {
	if(e) {
		if(e.keyCode == 38 && curatli > 0) {
			curatli--;
			return false;
		}
		if(e.keyCode == 40 && curatli < (atResult.length -1)) {
			curatli++;
			return false;
		}
		if(e.keyCode == 13) {
			var call = !call ? 'insertText' : call;
			if(curatli > -1) {
				eval(call+'(Dz(\'atli_'+curatli+'\').innerText)');
			}
			return true;
		}
	}
	return false;
}

function atFilter(kw, id, call, e, nae) {
	var nae = !nae ? false : nae;
	atResult = ['\u65e0\u5339\u914d\u6570\u636e'];
	atSearch(kw, function () { atFilter(kw, id, call); });
	if(nae || !atEnter(e, call)) {
		var newlist = '';
		if(atResult.length) {
			Dz(id).style.visibility = 'visible';
			for(i in atResult) {
				var atclass = i == curatli ? ' class="a bg-g zy-h"' : '';
				newlist += '<a id="atli_'+i+'"'+atclass+' class="bg-g zy-h" onclick="'+call+'(this.innerText)">'+ atResult[i] +'</a>';
			}
			Dz(id).innerHTML = newlist;
		} else {
			Dz(id).style.visibility = 'hidden';
		}
	}
}

function atListSet(kw) {
	Dz('atkeyword').value = kw;
	at_submit();
}

function at_friend() {
	var modal = ck8.modal({
	  title: '<span class=""><i class="f1-3">@</i>\u670b\u53cb\u8d26\u53f7\uff0c\u63d0\u9192\u770b\u5e16</span>',
	  text: '<div class="list-block"><div class="kznr-atss">'+
				'<input type="text" id="atkeyword" class="guiigo-px bg-e" value="" placeholder="\u641c\u7d22\u7528\u6237\u540d\u002e\u002e\u002e" '+
				'onkeyup="atFilter(this.value, \'at_list\',\'atListSet\',event, true);"/>'+
			'</div>'+
			'<div id="at_list" class="kznr-atlb">'+
			'</div></div>',
	  buttons: [
		{
			text: '\u53d6\u6d88',
			onClick: function() {
                Dz('needmessage').focus()
			}
		}
	  ]
	})
	atFilter('', 'at_list','atListSet','', true)
}

function at_submit(){
	var val = Dz('atkeyword').value;
	if(val && val.indexOf('\u65e0\u5339\u914d\u6570\u636e') == -1) {
		str = '@' + val + ' ';
		insertat(str);
	}
	ck8.closeModal();
	Dz('needmessage').focus()
}

