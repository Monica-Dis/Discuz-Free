<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp_avatar">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b{if CURSCRIPT == 'home' && CURMODULE == spacecp && $_GET['do'] == 'chszshi'}{else} guiigo-dydb{/if}">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon{if CURSCRIPT == 'home' && CURMODULE == spacecp && $_GET['do'] == 'chszshi'} guiigoapp-xzfh{else} guiigoapp-guanbi{/if} zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon{if CURSCRIPT == 'home' && CURMODULE == spacecp && $_GET['do'] == 'chszshi'} guiigoapp-xzfh{else} guiigoapp-guanbi{/if} zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h"><!--{if CURSCRIPT == 'home' && CURMODULE == spacecp && $_GET['do'] == 'chszshi'}-->{lang guiigo_manage:tlang0268}<!--{else}-->{lang guiigo_manage:tlang0523}<!--{/if}--></h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if CURSCRIPT == 'home' && CURMODULE == spacecp && $_GET['do'] == 'chszshi'}-->
				<div class="gg-kj-ejcz ms-a bg-c">
					<div class="guiigo-tbdh">
						<!--{if in_array('guiigo_upavatar',$_G['setting']['plugins']['available'])}-->
						<a class="xh-a" href="plugin.php?id=guiigo_upavatar">
							<div class="go-grzx-fk list-block-no">
								<ul>
									<li><img src="<!--{if !$_G[member][avatarstatus]}--><!--{avatar($_G[uid], middle, true)}--><!--{else}--><!--{eval echo avatar($_G[uid], 'middle', true,FALSE,true).'?'.rand(1000, 9999);}--><!--{/if}-->"></li>
								</ul>
							</div>
							<div class="go-tbdh-mc zy-f" style="margin-left: 0;">{lang guiigo_manage:tlang0523}</div>
							<i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i>
						</a>
						<!--{else}-->
						<a class="xh-a" onclick="ck8.toast('{lang guiigo_manage:tlang1000}')">
							<div class="go-grzx-fk list-block-no">
								<ul>
									<li><img src="<!--{eval echo avatar($_G[uid], 'middle', true,FALSE,true).'?'.rand(1000, 9999);}-->"></li>
								</ul>
							</div>
							<div class="go-tbdh-mc zy-f" style="margin-left: 0;">{lang guiigo_manage:tlang0523}</div>
							<i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i>
						</a>
						<!--{/if}-->
						<a href="home.php?mod=spacecp&ac=profile" class="xh-a" data-no-cache="true"><div class="go-tbdh-mc zy-f" style="margin-left: 0;">{lang guiigo_manage:tlang0524}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
						<a href="home.php?mod=spacecp&ac=profile&op=password" class="xh-a" data-no-cache="true"><div class="go-tbdh-mc zy-f" style="margin-left: 0;">{lang guiigo_manage:tlang0525}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
						<!--{if $_G['setting']['verify']['enabled'] && allowverify()}-->
							<a href="home.php?mod=spacecp&ac=profile&op=verify" class="xh-a" data-no-cache="true"><div class="go-tbdh-mc zy-f" style="margin-left: 0;">{lang guiigo_manage:tlang0526}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
						<!--{/if}-->
						<a {if in_array('guiigo_login',$_G['setting']['plugins']['available'])}href="javascript:location.href='plugin.php?id=guiigo_login#/pages/bind';"{else}onclick="ck8.toast('{lang guiigo_manage:tlang1001}')"{/if} class="xh-a" data-no-cache="true"><div class="go-tbdh-mc zy-f" style="margin-left: 0;">{lang guiigo_manage:tlang0999}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
					</div>
				</div>
				
				<div class="gg-kj-ejcz ms-a bg-c">
					<div class="guiigo-tbdh">
						<a href="home.php?mod=spacecp&ac=privacy&op=base" class="xh-a" data-no-cache="true" data-no-cache="true"><div class="go-tbdh-mc zy-f" style="margin-left: 0;">{lang guiigo_manage:tlang0527}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
						<a href="home.php?mod=spacecp&ac=privacy&op=filter" data-no-cache="true"><div class="go-tbdh-mc zy-f" style="margin-left: 0;">{lang guiigo_manage:tlang0619}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
					</div>
				</div>

				<div class="gg-kj-ejcz ms-a bg-c">
					<div class="guiigo-tbdh">
						<a class="xh-a" onclick="ck8.toast('{lang guiigo_manage:tlang0272}')"><div class="go-tbdh-mc zy-f" style="margin-left: 0;">{lang guiigo_manage:tlang0529}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
						<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}"
							class="dialog"
							ck-cus="true" 
							ck-param="{type:'modal',fn:'MsgCallLogout',load:'true',uid: '$_G[uid]'}" 
							external ><span class="gg-app-show zy-i">{lang guiigo_manage:tlang0990}</span><div class="go-tbdh-mc zy-i" style="margin-left: 0;">{lang guiigo_manage:tlang0530}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
					</div>
				</div>
				
				<div class="guiigo-version">GUIIGO-APP v22.201213</div>
			<!--{else}-->
				<script type="text/javascript">
					function updateavatar() {
						window.location.href = document.location.href.replace('&reload=1', '') + '&reload=1';
					}
					<!--{if !$reload}-->
					saveUserdata('avatar_redirect', document.referrer);
					<!--{/if}-->
				</script>
				<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=avatar&ref">
					<table cellspacing="0" cellpadding="0" class="tfm">
						<caption>
							<span id="retpre" class="y xi2"></span>
							<h2 class="xs2">{lang current_my_space}</h2>
							<p>{lang setting_avatar_message}</p>
						</caption>
						<tr>
							<td>
								<!--{avatar($space[uid],big)}-->
							</td>
						</tr>
					</table>
					<table cellspacing="0" cellpadding="0" class="tfm">
						<caption>
							<h2 class="xs2">{lang setting_my_new_avatar}</h2>
							<p>{lang setting_my_new_avatar_message}</p>
						</caption>
						<tr>
							<td>
								<script type="text/javascript">document.write(AC_FL_RunContent('<!--{echo implode("','", $uc_avatarflash);}-->'));</script>
							</td>
						</tr>
					</table>
					<input type="hidden" name="formhash" value="{FORMHASH}" />
				</form>
				<script type="text/javascript">
					var redirecturl = loadUserdata('avatar_redirect');
					if(redirecturl) {
						$('retpre').innerHTML = '<a href="' + redirecturl + '">{lang previous_page}</a>';
					}
				</script>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->
