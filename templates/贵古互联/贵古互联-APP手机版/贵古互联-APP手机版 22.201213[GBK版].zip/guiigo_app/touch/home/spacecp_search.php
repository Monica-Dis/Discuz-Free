<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp_search">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0637}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if !empty($_GET['searchsubmit'])}-->
				<!--{if empty($list)}-->
					<div class="guiigo-wnrtx">
						<img src="template/guiigo_app/static/images/wnr.png">
						<p class="zy-c">{lang no_search_friend}</p>
						<a class="back ab-az zy-a zy-ac">{lang guiigo_manage:tlang0638}</a>
					</div>
				<!--{else}-->
					<div class="gg-kj-hyts gg-kj-czhy ms-a bg-c sh-a zy-c"><i class="icon guiigoapp-biaoqing"></i>{lang guiigo_manage:tlang0639}<a class="back zy-l">{lang guiigo_manage:tlang0640}</a></div>
					<!--{template home/space_list}-->
				<!--{/if}-->
			<!--{else}-->
				<form action="home.php" method="get">
					<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
						<ul>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0641}</div>
								<div class="wblb-wbnr zy-h"><input type="text" name="username" value="" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0614}"/></div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang sex}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" class="guiigo-ps s-a select-picker" value="{lang random}" data-select="gender" />
									<select id="gender" name="gender" style="display:none;">
										<option value="0">{lang random}</option>
										<option value="1">{lang male}</option>
										<option value="2">{lang female}</option>
									</select>
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0642}</div>
								<div class="wblb-wbnr">
									<label class="guiigo-pd"><input type="checkbox" name="avatarstatus" value="1" class="guiigo-pd-k" /><span></span>{lang uploaded_avatar}</label>
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0643}</div>
								<div class="wblb-wbnr zy-h"><input type="text" name="startage" value="" size="10" class="guiigo-px s-a" style="width: 40%;" placeholder="{lang guiigo_manage:tlang0644}" /> ~ <input type="text" name="endage" value="" size="10" class="guiigo-px s-a" style="width: 40%;" placeholder="{lang guiigo_manage:tlang0644}" /></div>
							</li>
						</ul>
					</div>
					<div class="mn-a">
						<input type="hidden" name="searchsubmit" value="true" />
						<button type="submit" class="guiigo-pn ab-az zy-a zy-ac">{lang seek}</button>
					</div>
					<input type="hidden" name="op" value="$_GET[op]" />
					<input type="hidden" name="mod" value="spacecp" />
					<input type="hidden" name="ac" value="search" />
					<input type="hidden" name="type" value="all" />
				</form>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->
