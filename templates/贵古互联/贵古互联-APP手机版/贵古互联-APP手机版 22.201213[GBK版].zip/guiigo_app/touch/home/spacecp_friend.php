<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $op =='ignore'}-->
	<div id="friendform_{$uid}">
		<form method="post" autocomplete="off" id="friendform_{$uid}" name="friendform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=ignore&uid=$uid&confirm=1"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{fuid:'{$uid}',type:'delfined'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}">
			<input type="hidden" name="referer" value="{echo dreferer()}">
			<input type="hidden" name="friendsubmit" value="true" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="from" value="$_GET[from]" />
			<input type="hidden" name="handlekey" value="$_GET[handlekey]" />
			<div class="c">{lang determine_lgnore_friend}</div>
		</form>
	</div>
<!--{elseif $op=='changenum'}-->
	<div id="changenumform_{$uid}">
		<form method="post" autocomplete="off" id="changenumform_{$uid}" name="changenumform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=changenum&uid=$uid"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{fuid:'{$uid}',type:'setfined'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]',class:'gg-kj-sstd'}">
			<input type="hidden" name="referer" value="{echo dreferer()}">
			<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="changenumsubmit" value="true" />
			<div class="gg-kg-scsm guiigo-flex">
				<div class="scsm-xmbt zy-c">{lang new_hot}</div>
				<div class="scsm-xmnr guiigo-flexy"><input type="text" name="num" value="$friend[num]" placeholder="{lang num_0_999}" size="5" class="guiigo-px bg-e" /></div>
			</div>
			<div class="sstd-qdqx sh-a">
				<span class="modal-button" onclick="ck8.closeModal()">{lang guiigo_manage:tlang0105}</span>
				<button name="deletesubmit" type="button" class="guiigo-pn bg-c zh-a zy-b" onclick="setshush();">{lang determine}</button>
			</div>
		</form>
		<script>
		function setshush(){
			var formobj = ck8('#changenumform_{$uid}').find('form');
			ck8.showPreloader('','load');
			ck8.ajax({
				type:'POST',
				url: formobj.attr('action')+'&inajax=1',
				data:formobj.serialize(),
				dataType:'xml',
				success: function(s){
					setTimeout(function(){ck8.hidePreloader()}, 200);
					app.Devalscript(s.lastChild.firstChild.nodeValue,function(msg,par){
						ck8.closeModal();
						if(typeof msg === 'object' || typeof par === 'object'){
							ck8.toast('{lang guiigo_manage:tlang0568}');
						    ck8('#spannum_'+par['fuid']).html(par['num']);
						}else{
							ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
						}
					},{})
				},
				error: function(){
					ck8.hidePreloader();
					ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
				}
			});
		}
		</script>
	</div>
<!--{elseif $op=='add'}-->
	<div id="addform_{$tospace[uid]}">
		<form method="post" 
		autocomplete="off" 
		id="addform_{$tospace[uid]}" 
		name="addform_{$tospace[uid]}" 
		action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{fuid:'$tospace[uid]'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}">
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="addsubmit" value="true" />
			<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<div class="gg-kj-jhtc">
				<div class="jhtc-dqim bg-c"><!--{avatar($tospace[uid],middle)}--></div>
				<div class="jhtc-dqbt xh-b zy-f">{lang add} <em class="zy-b">{$tospace[username]}</em> {lang guiigo_manage:tlang0569}</div>
				<div class="guiigo-wblb list-block-no ms-a">
					<ul>
						<li class="guiigo-flex" style="padding: .25rem 0;">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0570}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="note" size="35" placeholder="{lang guiigo_manage:tlang0229}" class="guiigo-px bg-e s-a" style="height: 1.25rem;line-height: 1.25rem;padding: .2rem;font-size: .64rem;"></div>
						</li>
						<li class="guiigo-flex" style="padding: .25rem 0;">
							<div class="wblb-wbbt zy-c">{lang friend_group}</div>
							<div class="wblb-wbnr zy-h">
								<select name="gid" class="guiigo-ps zy-c" style="font-size: .64rem;">
								<!--{loop $groups $key $value}-->
									<option value="$key" {if empty($space['privacy']['groupname']) && $key==1} selected="selected"{/if}>$value</option>
								<!--{/loop}-->
								</select>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</form>
	</div>
<!--{elseif $op=='add2'}-->
	<div id="addratifyform_{$tospace[uid]}">
		<form method="post" 
		autocomplete="off" 
		id="addratifyform_{$tospace[uid]}" 
		name="addratifyform_{$tospace[uid]}" 
		action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{fuid:'$tospace[uid]'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}">
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="add2submit" value="true" />
			<input type="hidden" name="from" value="$_GET[from]" />
			<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<div class="gg-kj-jhtc">
				<div class="jhtc-dqim bg-c"><!--{avatar($tospace[uid],middle)}--></div>
				<div class="jhtc-dqbt xh-b zy-f">{lang guiigo_manage:tlang0571} <em class="zy-b">{$tospace[username]}</em> {lang guiigo_manage:tlang0572}</div>
				<div class="jhtc-fzxz ms-a">
					<!--{eval $i=0;}-->
					<!--{loop $groups $key $value}-->
					<label for="group_$key" class="guiigo-pds"><input type="radio" name="gid" id="group_$key" class="guiigo-pd-k zy-f" value="$key"$groupselect[$key] /><span></span>$value</label>
					<!--{if $i%2==1}--></tr><tr><!--{/if}-->
					<!--{eval $i++;}-->
					<!--{/loop}-->
				</div>
			</div>
		</form>
		<script type="text/javascript">
			function succeedhandle_$_GET[handlekey](url, msg, values) {
				if(values['from'] == 'notice') {
					deleteQueryNotice(values['uid'], 'pendingFriend');
				} else {
					myfriend_post(values['uid']);
				}
			}
		</script>
	</div>
<!--{elseif $op=='getinviteuser'}-->
	$jsstr
<!--{/if}-->
<!--{template common/footer}-->

