<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $_GET['op'] == 'delete'}-->
	<div id="shushu">
		<form method="post" autocomplete="off" id="doingform_{$doid}_{$id}" name="doingform" action="home.php?mod=spacecp&ac=doing&op=delete&doid=$doid&id=$id"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{},fn:'MsgCallwzplx',load:'true',uid:'$_G[uid]',class:'gg-kj-sstd',cancel:'{lang guiigo_manage:tlang0105}'}">
			<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="deletesubmit" value="true" />
			<div class="c">{lang determine_delete_doing}</div>
			<div class="sstd-qdqx sh-a">
				<span class="modal-button" onclick="ck8.closeModal()">{lang guiigo_manage:tlang0105}</span>
				<button name="deletesubmit" type="button" class="guiigo-pn bg-c zh-a zy-b" onclick="delshush()">{lang determine}</button>
			</div>
		</form>
		<script>
		function delshush(){
			var formobj = ck8('#shushu').find('form');
			ck8.showPreloader('','load');
			ck8.ajax({
				type:'POST',
				url: formobj.attr('action')+'&inajax=1',
				data:formobj.serialize(),
				dataType:'xml',
				success: function(s){
					setTimeout(function(){ck8.hidePreloader()}, 200);
					ck8.closeModal();
					ck8.toast('{lang guiigo_manage:tlang0561}');
					ck8('#$_GET[handlekey]').remove();
				    var sli = ck8('#$_GET[keys]').find('li')
					if(sli.length <= 0){
						ck8('#$_GET[keys]').css({'display':'none'});
					}
				},
				error: function(){
					ck8.hidePreloader();
					ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
				}
			});
		}
		</script>
	</div>
<!--{elseif $_GET['op'] == 'spacenote'}-->
	<!--{if $space[spacenote]}-->$space[spacenote]<!--{/if}-->
<!--{elseif $_GET['op'] == 'docomment' || $_GET['op'] == 'getcomment'}-->
	<!--{if helper_access::check_module('doing') && $_GET['op'] == 'docomment'}-->
	<div>
	<form id="{$_GET[key]}_docommform_{$doid}_{$id}" method="post" autocomplete="off" 
	action="home.php?mod=spacecp&ac=doing&op=comment&doid=$doid&id=$id" 
	class="pns" 
	ck-cus="true"
	ck-param="{type:'modal',callpar:{type:'repltxt',key:'$_GET[key]',id:'$id'},fn:'MsgCallwzplx',load:'true',uid:'$_G[uid]',class:'gg-kj-sstd',cancel:'{lang guiigo_manage:tlang0105}'}">
		<div class="sstd-srkz">
			<textarea name="message" id="{$_GET[key]}_form_{$doid}_{$id}_t" placeholder="{lang guiigo_manage:tlang0229}" cols="40" class="guiigo-px bg-e bk-e"></textarea>
		</div>
		<input type="hidden" name="commentsubmit" value="true" />
		<input type="hidden" name="do_button" value="true" />
		<div class="sstd-qdqx sh-a">
			<span class="modal-button" onclick="ck8.closeModal()">{lang guiigo_manage:tlang0105}</span>
			<button type="button" name="buttons" class="formdialog guiigo-pn bg-c zh-a zy-b">{lang reply}</button>
			<input type="hidden" name="formhash" value="{FORMHASH}" />
		</div>
	</form>
	</div>
	<!--{/if}-->
	<!--{if $_GET['op'] == 'getcomment'}-->
		<!--{template home/space_doing_li}-->
	<!--{/if}-->
<!--{else}-->
<div id="content">
	<!--{if helper_access::check_module('doing')}-->
	<!--{template home/space_doing_form}-->
	<!--{/if}-->
</div>
<!--{/if}-->
<!--{template common/footer}-->
