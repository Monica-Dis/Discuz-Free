<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="popup popup-style close-popup guiigo-kfon">
	<div class="kfon-kfnv bg-c">
		<div class="kfnv-xznr zy-g">{lang guiigo_manage:tlang0504}</div>
		<div class="kfnv-fgqh" id="styleall">
			<!--{if $guiigo_config['appsetting']['userconfig']['show_night']}-->
				<a href="javascript:;" onclick="SwitchStyle(this,'sy');" data-style="sy" class="{if $tplstyle == 'sy'}on{/if}" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/sy/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0505}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			<!--{/if}-->
			
			<!--
			<a href="javascript:;" onclick="SwitchStyle(this,'sd');" data-style="sd" class="{if $tplstyle == 'sd'}on{/if}"style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/sd/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0515}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			-->
			
			<a href="javascript:;" onclick="SwitchStyle(this,'s1');" data-style="s1" class="{if $tplstyle == 's1'}on{/if}" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/s1/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0506}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" onclick="SwitchStyle(this,'s2');" data-style="s2" class="{if $tplstyle == 's2'}on{/if}"style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/s2/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0507}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" onclick="SwitchStyle(this,'s3');" data-style="s3" class="{if $tplstyle == 's3'}on{/if}"style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/s3/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0508}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" onclick="SwitchStyle(this,'s4');" data-style="s4" class="{if $tplstyle == 's4'}on{/if}"style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/s4/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0509}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" onclick="SwitchStyle(this,'s5');" data-style="s5" class="{if $tplstyle == 's5'}on{/if}"style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/s5/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0510}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" onclick="SwitchStyle(this,'s6');" data-style="s6" class="{if $tplstyle == 's6'}on{/if}"style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/s6/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0511}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" onclick="SwitchStyle(this,'s7');" data-style="s7" class="{if $tplstyle == 's7'}on{/if}"style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/s7/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0512}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" onclick="SwitchStyle(this,'s8');" data-style="s8" class="{if $tplstyle == 's8'}on{/if}"style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/s8/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0513}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" onclick="SwitchStyle(this,'s9');" data-style="s9" class="{if $tplstyle == 's9'}on{/if}"style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/s9/fgqh.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0514}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
		</div>
		<a href="javascript:;" class="kfnv-clan close-popup"><i class="icon guiigoapp-cuo bg-e zy-g zy-ac"></i></a>
	</div>
</div>

