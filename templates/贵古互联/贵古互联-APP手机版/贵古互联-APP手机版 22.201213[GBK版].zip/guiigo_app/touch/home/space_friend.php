<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-friend">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<!--{if $space[self]}--><a href="home.php?mod=spacecp&ac=search" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-f"></i></a><!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0152}</h1>
	</header>
	<div class="content friend-scroll">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $space[self]}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacefriend list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $a_actives[me]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.friend-scroll','home.php?mod=space&do=friend',['gg-kj-hyfs']);">{lang guiigo_manage:tlang0709}</a><span class="bg-b"></span></li>
					<!--{if empty($_G['setting']['sessionclose'])}-->
					<li class="swiper-slide<!--{if $a_actives[onlinefriend]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.friend-scroll','home.php?mod=space&do=friend&view=online&type=friend',['gg-kj-hyfs']);">{lang guiigo_manage:tlang0710}</a><span class="bg-b"></span></li>
					<!--{/if}-->
					<li class="swiper-slide<!--{if $a_actives[visitor]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.friend-scroll','home.php?mod=space&do=friend&view=visitor',['gg-kj-hyfs']);">{lang guiigo_manage:tlang0711}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $a_actives[trace]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.friend-scroll','home.php?mod=space&do=friend&view=trace',['gg-kj-hyfs']);">{lang guiigo_manage:tlang0712}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $a_actives[blacklist]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.friend-scroll','home.php?mod=space&do=friend&view=blacklist',['gg-kj-hyfs']);">{lang guiigo_manage:tlang0713}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div id="gg-hy-hmxs" class="gg-kj-hyfs">
				<!--{if $_GET['view']=='blacklist'}-->
					<div class="gg-qz-flts bg-c ms-a"><div class="flts-tsnr bk-d bg-p zy-b">{lang blacklist_message}</div></div>
					<div class="gg-qz-qbss">
						<div class="gg-qz-qzsc">
							<form method="post" 
							autocomplete="off" 
							id="blackform" 
							name="blackform"
							action="home.php?mod=spacecp&ac=friend&op=blacklist&start=$_GET[start]"
							ck-cus="true"
							ck-param="{type:'modal',callpar:{pmid:'',type:'blackform'},fn:'MsgCallFrihmd',load:'true',uid:'$_G[uid]'}">
								<ul class="guiigo-flex">
									<input type="text" class="qzsc-sssr bg-c zy-c" name="username" placeholder="{lang guiigo_manage:tlang0714}"/>
									<button type="submit" name="blacklistsubmit_btn" id="moodsubmit_btn" value="true" class="formdialog qzsc-ssqr ab-az zy-a zy-ac">{lang add}</button>
								</ul>
								<input type="hidden" name="blacklistsubmit" value="true" />
								<input type="hidden" name="formhash" value="{FORMHASH}" />
							</form>
						</div>
					</div>
					<script type="text/javascript">
						function MsgCallFrihmd(msg,par,param){
							if(typeof msg === 'object' || typeof par === 'object'){
								if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'blackform'){
									ck8.toast('{lang guiigo_manage:tlang0715}');
									app.PageRefresh(false,'#gg-hy-hmxs','home.php?mod=space&do=friend&view=blacklist')
								}else {
									ck8.toast(msg.msg,'shibai');
								}
							}else{
								ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
							}
						}
					</script>
				<!--{/if}-->
				<!--{if $list}-->
					<!--{if $_GET['view']=='me'}-->
						<div class="gg-qz-flts bg-c ms-a"><div class="flts-tsnr bk-d bg-p zy-b">{lang guiigo_manage:tlang0716}</div></div>
						<div class="gg-kj-hyts ms-a bg-c sh-a zy-c cl">
							<p class="hyts-hypx"><a href="javascript:;" onclick="app.LoadPageForumView('.friend-scroll','home.php?mod=space&amp;do=friend&amp;order=num',['gg-sq-tayc']);" class="zy-f"><i class="icon guiigoapp-redu zy-i"></i>{lang guiigo_manage:tlang0717}</a></p>
							<p class="hyts-hytj"><i class="icon guiigoapp-biaoqing"></i>{lang count_member}</p>
						</div>
					<!--{elseif $_GET['view']=='online'}-->
						<div class="gg-kj-hyts ms-a bg-c sh-a zy-c"><i class="icon guiigoapp-zaixian"></i>{lang online_friend_visit}</div>
					<!--{elseif $_GET['view']=='visitor'}-->
						<div class="gg-kj-hyts ms-a bg-c sh-a zy-c"><i class="icon guiigoapp-biaoqing"></i>{lang visitor_list}</div>
					<!--{elseif $_GET['view']=='trace'}-->
						<div class="gg-kj-hyts ms-a bg-c sh-a zy-c"><i class="icon guiigoapp-zuji"></i>{lang trace_list}</div>
					<!--{/if}-->
				<!--{/if}-->
				
				
				<div id="friend_ul_page"  
				data-url="$theurl" 
				data-pages="{$count}" 
				data-ppp="{$perpage}" 
				data-page="$page" 
				data-islod="false" 
				data-distance="20">
				<!--{if $list}-->
					<div id="friend_ul" class="gg-sq-tayc list-block-no sh-a xh-b bg-c">
						<ul class="list-container ms-c">
						<!--{loop $list $key $value}-->
							<li id="friend_{$value[uid]}_li" class="xh-a">
							<!--{if $value[username] == ''}-->
								<div class="bkys-bkico bkys-bkicoy guiigo-ty">
									<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg">
								</div>
								<a href="javascript:void(0)" class="bkys-bkmc zy-e">{lang guiigo_manage:tlang0718}</a>
							<!--{else}-->
								<div class="gg-kj-hycz">
									<!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != ''}-->
										<!--{if !$value['follow']}-->
											<a href="home.php?mod=spacecp&ac=follow&op=add&fuid=$value[uid]&hash={FORMHASH}&from=a_followmod_" 
											id="a_followmod_$key" 
											style="color:#9dca06;" 
											class="followmod_$value[uid] dialog"
											ck-cus="true"
											ck-confirm="false"
											ck-param="{type:'modal',callpar:{fuid:'$value[uid]'},fn:'MsgCallFrifoll',load:'true',uid:'{$_G[uid]}'}" 
											external ><i class="icon guiigoapp-tabkgzt"></i><p>{lang guiigo_manage:tlang0011}</p></a>
										<!--{else}-->
											<a href="home.php?mod=spacecp&ac=follow&op=del&fuid=$value[uid]&hash={FORMHASH}&from=a_followmod_" 
											id="a_followmod_$key" 
											style="color:#9dca06;" 
											class="followmod_$value[uid] dialog"
											ck-cus="true"
											ck-confirm="false"
											ck-param="{type:'modal',callpar:{fuid:'$value[uid]'},fn:'MsgCallFrifoll',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}" 
											external ><i class="icon guiigoapp-tabkgzt"></i><p>{lang guiigo_manage:tlang0719}</p></a>
										<!--{/if}-->
									<!--{/if}-->
									<!--{if $value[uid] != $_G['uid'] && $value[username] != ''}-->
									<a href="home.php?mod=spacecp&ac=poke&op=send&uid=$value[uid]" id="a_poke_$key" style="color:#FF9900;" data-no-cache="true"><i class="icon guiigoapp-tabkdzh"></i><p>{lang guiigo_manage:tlang0610}</p></a>
									<a href="javascript:;" 
										id="a_sendpm_$key" 
										style="color:#ff6060;"
										class="getpm-popup"
										data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$value[uid]&touid=$value[uid]&pmid=0&daterange=2"
										external><i class="icon guiigoapp-tabkfxx"></i><p>{lang guiigo_manage:tlang0720}</p></a>
									<!--{/if}-->
									<!--{if !$value[isfriend] && $value[username] != ''}-->
									<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=adduserhk_{$value[uid]}" 
									id="a_friend_$key" 
									class="dialog" 
									style="color:#3ebbfd;" 
									ck-cus="true"
									ck-confirm="falsea"
									ck-param="{type:'modal',callpar:{fuid:'$value[uid]'},fn:'MsgCallfined',load:'true',uid:'{$_G[uid]}'}" 
									external ><i class="icon guiigoapp-tabkjhy"></i><p>{lang guiigo_manage:tlang0618}</p></a>
									<!--{elseif !in_array($_GET['view'], array('blacklist', 'visitor', 'trace', 'online'))}-->
									<a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$value[uid]&handlekey=delfriendhk_{$value[uid]}" id="a_ignore_$key" style="color:#3ebbfd;" class="dialog"
									ck-cus="true"
									ck-param="{type:'modal',callpar:{fuid:'$value[uid]',type:'delfined'},fn:'MsgCallfined',load:'true',uid: '$_G[uid]'}"
									external ><i class="icon guiigoapp-tabkjhy"></i><p>{lang guiigo_manage:tlang0721}</p></a>
									<!--{/if}-->
								</div>
								<div class="bkys-bkico bkys-bkicoy">
									<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="guiigo-ty">
										<!--{avatar($value[uid],middle)}-->
									</a>
								</div>
								<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="bkys-bkmc zy-e">$value[username]</a>
								<p class="zy-g">
									<!--{if $_GET['view'] == 'blacklist'}-->
										<a href="home.php?mod=spacecp&ac=friend&op=blacklist&subop=delete&uid=$value[uid]&start=$_GET[start]" 
										class="zy-l dialog"
										ck-cus="true"
										ck-param="{type:'modal',callpar:{fuid:'$value[uid]',type:'removefined'},fn:'MsgCallfined',load:'true',uid: '$_G[uid]'}"
										external><i class="icon guiigoapp-tcqzn"></i>{lang guiigo_manage:tlang0722}</a>
									<!--{elseif $_GET['view'] == 'visitor' || $_GET['view'] == 'trace'}-->
										<!--{date($value[dateline], 'n{lang month}j{lang day}')}-->
									<!--{elseif $_GET['view'] == 'online'}-->
										<!--{date($ols[$value[uid]], 'H:i')}-->
									<!--{else}-->
										<a href="home.php?mod=spacecp&ac=friend&op=changenum&uid=$value[uid]&handlekey=hotuserhk_{$value[uid]}" id="friendnum_$value[uid]" class="dialog zy-i"
										ck-cus="true"
										ck-param="{type:'modal',callpar:{fuid:'$value[uid]',type:'setfined'},fn:'MsgCallfined',load:'true',uid: '$_G[uid]'}"
										external ><i class="icon guiigoapp-redu"></i><em id="spannum_$value[uid]">$value[num]</em></a>
									<!--{/if}-->
								</p>
							<!--{/if}-->
							</li>
						<!--{/loop}-->
						</ul>
					</div>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang no_friend_list}</p>
					</div>
				<!--{/if}-->
				<!--{if $list}-->
					<!--{if $multi}-->
						<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
							<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
						</div>
						<div onclick="infinite('#friend_ul_page')" class="loadpage bg-c bk-e zy-c">{lang guiigo_manage:tlang0492}<i class="icon guiigoapp-ssxx zy-c"></i></div>
					<!--{/if}-->
				<!--{/if}-->
				</div>
			</div>
			<!--{else}-->
				<!--{template home/space_list}-->
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript">
		function MsgCallfined(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'removefined'){
					ck8.toast('{lang guiigo_manage:tlang0723}');
				    ck8('#friend_'+param.fuid+'_li').remove()
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'delfined'){
					ck8.toast('{lang guiigo_manage:tlang0561}');
				    ck8('#friend_'+param.fuid+'_li').remove()
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'setfined'){
					ck8.toast('{lang guiigo_manage:tlang0724}');
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1 && param.type == 'delfined'){
					ck8.toast('{lang guiigo_manage:tlang0049}','shibai');
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}
		function MsgCallFrifoll(msg,par,param) {
			if(typeof msg === 'object' || typeof par === 'object'){
				var Obj = $('.followmod_'+ par.fuid +'');
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
					$.toast('{lang guiigo_manage:tlang0003}')
					Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&fuid='+ par.fuid +'&hash={FORMHASH}&from=a_followmod_').html('<i class="icon guiigoapp-tabkgzt"></i><p>{lang guiigo_manage:tlang0719}</p>')
					Obj.attr('ck-confirm','true')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
					$.toast('{lang guiigo_manage:tlang0009}')
					Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&fuid='+ par.fuid +'&hash={FORMHASH}&from=a_followmod_').html('<i class="icon guiigoapp-tabkgzt"></i><p>{lang guiigo_manage:tlang0011}</p>')
					Obj.attr('ck-confirm','false')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
					$.toast('{lang guiigo_manage:tlang0007}');
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				$.toast('{lang guiigo_manage:tlang0056}');
			}
		}
		function MsgCallFrifolli(msg,par,param) {
			if(typeof msg === 'object' || typeof par === 'object'){
				var Obj = $('.followmod_'+ par.fuid +'');
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
					$.toast('{lang guiigo_manage:tlang0003}')
					Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid='+ par.fuid).html('<i class="icon guiigoapp-tabkgzt"></i><p>{lang guiigo_manage:tlang0719}</p>')
					Obj.attr('ck-confirm','true')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
					$.toast('{lang guiigo_manage:tlang0009}')
					Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+ par.fuid).html('<i class="icon guiigoapp-tabkgzt"></i><p>{lang guiigo_manage:tlang0011}</p>')
					Obj.attr('ck-confirm','false')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
					$.toast('{lang guiigo_manage:tlang0007}');
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				$.toast('{lang guiigo_manage:tlang0056}');
			}
		}
	</script>
</div>
<!--{template common/footer}-->
