<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $spaceList = GuiigoApp::getUserList($space[uid],'profile');}-->
<!--{eval $spacecount = GuiigoApp::getUserList($space[uid],'count');}-->
<!--{eval $userHstyle = $guiigo_config['appsetting']['userHstyle'][$space[uid]];}-->
<!--{if !$userHstyle}-->
	<!--{eval $userHstyle = 'k1';}-->
<!--{/if}-->
<div id="share_title" style="display: none;">$space[username] - {lang guiigo_manage:tlang0980}</div>
<div class="gg-kj-kjdb gg-kjbg-{$userHstyle} app-top cl">
	<section class="gg-kj-zkkz">
		<div class="kjdb-txzl cl">
			<div id="share_img" class="txzl-yhtx">
			<img
				class="ck8-lazy vimg_{$space[uid]} vm"
				data-fid="pid$space[uid]" 
				data-mid="{$space[uid]}" 
				src="" 
				lazySrc="<!--{if $space[self]}--><!--{if !$_G[member][avatarstatus]}--><!--{avatar($_G[uid], big, true)}--><!--{else}--><!--{eval echo avatar($space[uid], 'big', true,FALSE,true).'?'.rand(1000, 9999);}--><!--{/if}--><!--{else}--><!--{avatar($space[uid], big, true)}--><!--{/if}-->"
				onclick="app.previewImg(this);"/>
			</div>
			<h2 class="zy-a zs-a"><!--{echo cutstr($space[username],18)}--></h2>
			<div class="txzl-jbxx cl">
				<a href="<!--{if $space[self]}-->home.php?mod=space&do=friend&view=visitor<!--{else}-->javascript:;<!--{/if}-->" class="zy-d zs-a"><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($space[views])}--><!--{else}-->$space[views]<!--{/if}--></em>{lang guiigo_manage:tlang0789}</a>
				<a{if $_G[uid]} href="home.php?mod=follow&do=follower&uid=$space[uid]" class="zy-d zs-a"{else} href="javascript:;" class="zy-d zs-a login"{/if}><em id="jbxx-fssx" class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($spacecount['follower'])}--><!--{else}-->$spacecount['follower']<!--{/if}--><!--{if $space[self]}--><!--{if $_G[member][newprompt_num][follower]}--><span class="zy-b">+$_G[member][newprompt_num][follower]</span><!--{/if}--><!--{/if}--></em>{lang guiigo_manage:tlang0041}</a>
				<a{if $_G[uid]} href="home.php?mod=follow&do=following&uid=$space[uid]" class="zy-d zs-a"{else} href="javascript:;" class="zy-d zs-a login"{/if}><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($spacecount['following'])}--><!--{else}-->$spacecount['following']<!--{/if}--></em>{lang guiigo_manage:tlang0002}</a>
				<input id="ac-1" name="accordion-1" type="checkbox">
				<label for="ac-1"></label>
				<article id="peofilexx" class="kjdb-jfzs cl" >
					<a{if $_G[uid]} href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space" class="zy-d zs-a"{else} href="javascript:;" class="zy-d zs-a login"{/if}><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($space[threads])}--><!--{else}-->$space[threads]<!--{/if}--></em>{lang guiigo_manage:tlang0116}</a>
					<!--{eval $space['posts'] = $space['posts'] - $space['threads'];}-->
					<a{if $_G[uid]} href="home.php?mod=space&do=thread&view=me&type=reply&uid=$space[uid]&from=space" class="zy-d zs-a"{else} href="javascript:;" class="zy-d zs-a login"{/if}><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($space[posts])}--><!--{else}-->$space[posts]<!--{/if}--></em>{lang guiigo_manage:tlang0148}</a>
					<a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space" class="zy-d zs-a"><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($space[blogs])}--><!--{else}-->$space[blogs]<!--{/if}--></em>{lang guiigo_manage:tlang0790}</a>
					<a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space" class="zy-d zs-a"><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($space[albums])}--><!--{else}-->$space[albums]<!--{/if}--></em>{lang guiigo_manage:tlang0791}</a>
					<a href="home.php?mod=space&uid=$space[uid]&do=friend&view=me&from=space" class="zy-d zs-a"><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($space[friends])}--><!--{else}-->$space[friends]<!--{/if}--></em>{lang guiigo_manage:tlang0152}</a>
					<a{if $_G[uid]} href="home.php?mod=follow&do=follower&uid=$space[uid]" class="zy-d zs-a"{else} href="javascript:;" class="zy-d zs-a login"{/if}><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($spacecount['follower'])}--><!--{else}-->$spacecount['follower']<!--{/if}--></em>{lang guiigo_manage:tlang0041}</a>
					<a{if $_G[uid]} href="home.php?mod=follow&do=following&uid=$space[uid]" class="zy-d zs-a"{else} href="javascript:;" class="zy-d zs-a login"{/if}><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($spacecount['following'])}--><!--{else}-->$spacecount['following']<!--{/if}--></em>{lang guiigo_manage:tlang0002}</a>
					<a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space" class="zy-d zs-a"><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($space[doings])}--><!--{else}-->$space[doings]<!--{/if}--></em>{lang guiigo_manage:tlang0621}</a>
					<a href="<!--{if $space[self]}-->home.php?mod=space&do=friend&view=visitor<!--{else}-->javascript:;<!--{/if}-->" class="zy-d zs-a"><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($space[views])}--><!--{else}-->$space[views]<!--{/if}--></em>{lang guiigo_manage:tlang0789}</a>
					<a href="<!--{if $space[self]}-->home.php?mod=spacecp&ac=credit<!--{else}-->javascript:;<!--{/if}-->" class="zy-d zs-a"><em class="zy-a zs-a"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($space[credits])}--><!--{else}-->$space[credits]<!--{/if}--></em>{lang guiigo_manage:tlang0543}</a>
				</article>
			</div>
		</div>
	</section>
	<div class="kjdb-kxbq cl">
		<!--{if $spaceList['gender'] != 0}--><span><!--{if $spaceList['gender'] == 1}--><i class="icon guiigoapp-nan zy-j"></i>{lang guiigo_manage:tlang0792}<!--{elseif $spaceList['gender'] == 2}--><i class="icon guiigoapp-nv zy-k"></i>{lang guiigo_manage:tlang0793}<!--{/if}--></span><!--{/if}-->
		<span>Lv.<!--{eval echo GuiigoApp::getUserStars($space[uid]);}--></span>
		<!--{if $spaceList['constellation']}--><span>$spaceList['constellation']</span><!--{/if}-->
		<!--{if $guiigo_config['appsetting']['userconfig']['home_show_selection'] == 1}-->
			<!--{if $spaceList['resideprovince']}--><span>$spaceList['resideprovince'] $spaceList['residecity']</span><!--{/if}-->
		<!--{elseif $guiigo_config['appsetting']['userconfig']['home_show_selection'] == 2}-->
			<!--{if $spaceList['residecity']}--><span>$spaceList['residecity'] $spaceList['residedist']</span><!--{/if}-->
		<!--{elseif $guiigo_config['appsetting']['userconfig']['home_show_selection'] == 3}-->	
			<!--{if $spaceList['residedist']}--><span>$spaceList['residedist'] $spaceList['residecommunity']</span><!--{/if}-->
		<!--{/if}-->
	</div>
	<!--{if $space[customstatus]}-->
	<div class="kjdb-kxbq cl">
		<span>$space[customstatus]</span>
	</div>
	<!--{/if}-->
	<div class="kjdb-idqm cl">
		<!--{if !$space[self]}-->
			<!--{eval $follow = 0;}-->
			<!--{eval $follow = C::t('home_follow')->fetch_all_by_uid_followuid($_G['uid'], $space['uid']);}-->
			<!--{if !$follow}-->
				<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]" 
				id="followmod" 
				class="followmod_$space[uid] idqm-gz dialog bg-h zy-a zy-ac"
				ck-cus="true"
				ck-confirm="false"
				ck-param="{type:'modal',callpar:{fuid:'$space[uid]'},fn:'MsgCallGrfoll',load:'true',uid:'{$_G[uid]}'}" 
				external ><i class="icon guiigoapp-bkscj"></i></a>
			<!--{else}-->
				<a href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]" 
				id="followmod" 
				class="followmod_$space[uid] idqm-gz dialog bg-h zy-a zy-ac"
				ck-cus="true"
				ck-confirm="false"
				ck-param="{type:'modal',callpar:{fuid:'$space[uid]'},fn:'MsgCallGrfoll',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}" 
				external ><i class="icon guiigoapp-dui"></i></a>
			<!--{/if}-->
		<!--{/if}-->
		<span class="zy-d zs-a">UID: {$space[uid]}</span>
		<p id="share_introduce" class="zy-d zs-a"><!--{if $space[group][maxsigsize] && $space[sightml]}--><!--{echo strip_tags($space[sightml])}--><!--{else}--><!--{if $space[self]}--><a href="home.php?mod=spacecp&ac=profile&op=info" class="zy-d zs-a">{lang guiigo_manage:tlang1040}</a><!--{else}-->TA{lang guiigo_manage:tlang0794}<!--{/if}--><!--{/if}--></p>
	</div>
	<div class="guiigo-bwdx">
		<div class="guiigo-bwdx-a"></div>
		<div class="guiigo-bwdx-b"></div>
	</div>
	<div class="guiigo-fgtx"></div>
</div>
<div class="popup-actions" id="guiigo-nrdbfx">
	<div class="actions-text guiigo-hdfx">
		<div class="gg-app-hide hdfx-hdxm xh-b bg-e">
			<a href="javascript:;"  data-app="weixin" class="nativeShare weixin zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wx.png" class="vm"></span>{lang guiigo_manage:tlang0153}</a>
			<a href="javascript:;" data-app="weixinFriend" class="nativeShare weixin_timeline zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/pyq.png" class="vm"></span>{lang guiigo_manage:tlang0154}</a>
			<a href="javascript:;" data-app="QQ" class="nativeShare qq zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/qq.png" class="vm"></span>{lang guiigo_manage:tlang0155}</a>
			<a href="javascript:;" data-app="QZone" class="nativeShare qzone zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kj.png" class="vm"></span>{lang guiigo_manage:tlang0156}</a>
			<a href="javascript:;" data-app="sinaWeibo" class="nativeShare weibo zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wb.png" class="vm"></span>{lang guiigo_manage:tlang0157}</a>
		</div>
		<div class="gg-app-show hdfx-xcxt xh-b bg-e">
			<span class="icon guiigoapp-xiaochengxu"></span>
			<h2>{lang guiigo_manage:tlang1002}</h2>
			<p>{lang guiigo_manage:tlang1003}</p>
		</div>
		<div class="hdfx-hdxm bg-e">
			<a href="javascript:;" class="zy-f zd-12" onclick="copy(this);" id="cptextid"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/fz.png" class="vm"></span>{lang guiigo_manage:tlang0158}</a>
		</div>
		<a href="javascript:;" class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</a>
	</div>
</div>
<div class="share-layer"></div>
<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
<div class="buttons-tab gg-kj-kjqh bg-c xh-b">
	<a href="#prkonzs" class="tab-link active button">{lang guiigo_manage:tlang0796}<span class="bg-b"></span></a>
	<a href="#prkonzs1" class="tab-link button" onclick="app.PageRefresh(false,'#prkonzs1','home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space')">{lang guiigo_manage:tlang0417}<span class="bg-b"></span></a>
	<a href="#prkonzs2" class="tab-link button" onclick="app.PageRefresh(false,'#prkonzs2','home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space')">{lang guiigo_manage:tlang0791}<span class="bg-b"></span></a>
	<a href="#prkonzs3" class="tab-link button" onclick="app.PageRefresh(false,'#prkonzs3','home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space')">{lang guiigo_manage:tlang0790}<span class="bg-b"></span></a>
	<a href="#prkonzs4" class="tab-link button" onclick="app.PageRefresh(false,'#prkonzs4','home.php?mod=space&uid=$space[uid]&do=wall')">{lang guiigo_manage:tlang0620}<span class="bg-b"></span></a>
</div>
<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
<script>
ck8(function(){
	if(ck8('#focbtn').length > 0){
		ck8('#focbtn').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('#rewardbut').length > 0){
		ck8('#rewardbut').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('.debatereply').length > 0){
		ck8('.debatereply').click(function(e){
			Dz('needmessage').focus()
		})
	}
})

function ShareAllprofile(){
	//�õ���������
		var config = getShareData('#share_title','#share_img','#share_introduce');
	<!--{if ($guiigo_config['browser']['isqq'] || $guiigo_config['browser']['isuc']) && !$guiigo_config['browser']['iswx']}-->
		//����� UC qq �����
		nativeShare(config);
	<!--{elseif $guiigo_config['browser']['iswx']}-->
		//�����΢�������
		wxshareJssdkAjax(config)
	<!--{else}-->
		//������� ΢������� UC qq �����
		webShare(config)
	<!--{/if}-->
}

function MsgCallGrfoll(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var favor = ck8('#jbxx-fssx');
		var favorcun = parseInt(favor.html());
		var Obj = $('.followmod_'+ par.fuid +'');
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
			$.toast('{lang guiigo_manage:tlang0003}')
			var fdelurl='home.php?mod=space&uid='+ par.fuid +'&do=profile';
			if(favor.css('display') == 'block'){
				favor.html(favorcun + 1)
			}
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&fuid='+ par.fuid).html('<i class="icon guiigoapp-dui"></i></a>')
			Obj.attr('ck-confirm','true')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			$.toast('{lang guiigo_manage:tlang0009}')
			var fdelurl='home.php?mod=space&uid='+ par.fuid +'&do=profile';
			if(favorcun == 1){
				favor.html(favorcun - 1)
			}else{
				favor.html(favorcun - 1)
			}
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+ par.fuid).html('<i class="icon guiigoapp-bkscj"></i>')
			Obj.attr('ck-confirm','false')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1){
			$.toast('{lang guiigo_manage:tlang0671}')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0795}') != -1){
			$.toast('{lang guiigo_manage:tlang0795}')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			$.toast('{lang guiigo_manage:tlang0007}');
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}
</script>
