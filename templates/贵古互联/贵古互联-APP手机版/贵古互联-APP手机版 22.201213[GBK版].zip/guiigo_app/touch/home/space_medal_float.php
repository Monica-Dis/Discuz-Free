<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<form id="medalform" 
name="medalform" 
method="post" 
autocomplete="off" 
action="home.php?mod=medal&action=apply&medalsubmit=yes"
ck-cus="true"
ck-param="{type:'modal',callpar:{pmid:'',xzmc:'$medal[name]',type:'medalform'},fn:'MsgCallFloat',load:'true',uid:'$_G[uid]',cancel:'{lang guiigo_manage:tlang0105}',class:'gg-kj-xzhq'}">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="medalid" value="$medal[medalid]" />
	<input type="hidden" name="operation" value="" />
	<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
	<div class="xzhq-xztb bg-g">
		<img src="{STATICURL}image/common/$medal[image]" alt="$medal[name]"/>
		<h1 class="zy-h">$medal[name]</h1>
		<p class="zy-c">$medal[description]</p>
	</div>
	<div class="xzhq-xzja bg-c">
		<p class="zy-b">
			<!--{if $medal[expiration]}-->
				{lang expire} $medal[expiration] {lang days}<br />
			<!--{/if}-->
			<!--{if $medal[permission]}-->
				$medal[permission]<br />
			<!--{/if}-->
			<!--{if $medal[type] == 0}-->
				{lang medals_type_0}
			<!--{elseif $medal[type] == 1}-->
				<!--{if $medal['price']}-->
					<!--{if {$_G['setting']['extcredits'][$medal[credit]][unit]}}-->
						{$_G['setting']['extcredits'][$medal[credit]][title]} $medal[price] {$_G['setting']['extcredits'][$medal[credit]][unit]}
					<!--{else}-->
						$medal[price] {$_G['setting']['extcredits'][$medal[credit]][title]}
					<!--{/if}-->
				<!--{else}-->
					{lang medals_type_1}
				<!--{/if}-->
			<!--{elseif $medal[type] == 2}-->
				{lang medals_type_2}
			<!--{/if}-->
		</p>
		<!--{if $medal[type] && $_G['uid']}-->
			<button class="formdialog guiigo-pn ab-az zy-a zy-ac" type="submit" value="true" name="medalsubmit">
				<!--{if $medal['price']}-->
					{lang space_medal_buy}
				<!--{else}-->
					<!--{if !$medal[permission]}-->
						{lang medals_apply}
					<!--{else}-->
						{lang medals_draw}
					<!--{/if}-->
				<!--{/if}-->
			</button>
		<!--{/if}-->
	</div>
</form>
<script>			
	function MsgCallFloat(msg,par,param){
		if(typeof msg === 'object' || typeof par === 'object'){
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0734}') != -1 && param.type == 'medalform'){
				ck8.toast('{lang guiigo_manage:tlang0734}'+ param.xzmc +'{lang guiigo_manage:tlang0735}');
				app.PageRefresh(false,'#xzkx-on','home.php?mod=medal')
			}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0736}') != -1){
				ck8.toast('{lang guiigo_manage:tlang0737}'+ param.xzmc +'{lang guiigo_manage:tlang0735}');
			}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0738}') != -1){
				ck8.toast('{lang guiigo_manage:tlang0739}'+ param.xzmc +'{lang guiigo_manage:tlang0735}');
			}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0740}') != -1){
				ck8.toast(param.xzmc +'{lang guiigo_manage:tlang0741}');
				app.PageRefresh(false,'#xzkx-on','home.php?mod=medal')
			}else {
				ck8.toast(msg.msg,'shibai');
			}
		}else{
			ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
		}
	}
</script>
<!--{template common/footer}-->
