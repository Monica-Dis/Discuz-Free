<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<!--{if $activeus[usergroup] || $activeus[list] || $activeus[expiry]}-->
<div class="page page-current" data-mod="spacecp-usergroup">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0654}</h1>
	</header>
	<div class="content usergroup-scroll">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacecpusergroup list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $activeus[usergroup]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.usergroup-scroll','home.php?mod=spacecp&ac=usergroup',['gg-kj-wddj']);">{lang guiigo_manage:tlang0655}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $activeus[list] || $activeus[expiry]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.usergroup-scroll','home.php?mod=spacecp&ac=usergroup&do=list',['gg-kj-wddj']);">{lang guiigo_manage:tlang0656}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
<!--{/if}-->
<!--{if in_array($do, array('buy', 'exit'))}-->
	<em id="return_$_GET[handlekey]" class="djgm-gmbt zy-h"><!--{if $join}-->{lang memcp_usergroups_joinbuy}<!--{else}-->{lang memcp_usergroups_joinexit}<!--{/if}--></em>
	<div id="buygroupform_{$groupid}">
		<form id="buygroupform_{$groupid}" 
		name="buygroupform_{$groupid}" 
		method="post" 
		autocomplete="off" 
		action="home.php?mod=spacecp&ac=usergroup&do=$do&groupid=$groupid"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{gid:'$groupid'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}"
		>
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="buysubmit" value="true" />
			<input type="hidden" name="gid" value="$_GET[gid]" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
				<!--{if $join}-->
					<!--{if $group['dailyprice']}-->
						<div class="djgm-gmxq list-block-no sh-a">
							<ul>
								<li class="guiigo-flex xh-b cl">
									<div class="gmxq-xqbt zy-c">{lang memcp_usergroups_dailyprice}</div>
									<div class="guiigo-flexy zy-b">$group[dailyprice] {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}</div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="gmxq-xqbt zy-c">{lang memcp_usergroups_credit}</div>
									<div class="guiigo-flexy zy-b">$usermaxdays {lang days}</div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="gmxq-xqbt zy-c">{lang memcp_usergroups_span}</div>
									<div class="guiigo-flexy"><input type="text" size="2" name="days" value="$group[minspan]" class="guiigo-px bg-e" onkeyup="change_credits_need(this.value)" /></div>
									<div class="qmxq-xqdw zy-c">{lang days}</div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="gmxq-xqbt zy-c">{lang credits_need}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}</div>
									<div class="guiigo-flexy zy-b"><span id="credits_need"></span> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}
									<script language="javascript">
										var dailyprice = $group[dailyprice];
										function change_credits_need(daynum) {
											if(!isNaN(parseInt(daynum))) {
												Dz('credits_need').innerHTML = parseInt(daynum) * dailyprice;
											} else {
												Dz('credits_need').innerHTML = '0';
											}
										}
										change_credits_need($group[minspan]);
									</script>
									</div>
								</li>
							</ul>
						</div>
						<div class="djgm-gmsms bg-p bk-d zy-b">
							{lang memcp_usergroups_explain}:
							<!--{if $join}-->
								{lang memcp_usergroups_join_comment}
							<!--{else}-->
								{lang memcp_usergroups_exit_comment}
							<!--{/if}-->
						</div>
					<!--{else}-->
						<div class="djgm-gmsm sh-a zy-f">{lang memcp_usergroups_explain}: {lang memcp_usergroups_free_comment}</div>
					<!--{/if}-->
				<!--{else}-->
					<div class="djgm-gmsm sh-a zy-f">
						{lang memcp_usergroups_explain}:
						<!--{if $group[type] != 'special' || $group[system]=='private'}-->
							{lang memcp_usergroups_admin_exit_comment}
						<!--{elseif $group['dailyprice']}-->
							{lang memcp_usergroups_exit_comment}
						<!--{else}-->
							{lang memcp_usergroups_open_exit_comment}
						<!--{/if}-->
					</div>
				<!--{/if}-->
			<!--
			<p class="o pns">
				<button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="pn pnc"><strong>{lang submit}</strong></button>
			</p>
			-->
		</form>
	</div>
<!--{elseif $do == 'switch'}-->
	<em id="return_$_GET[handlekey]" class="djgm-gmbt zy-h">{lang memcp_usergroups_switch}</em>
	<div id="switchgroupform_{$groupid}">
		<form id="switchgroupform_{$groupid}" 
		name="switchgroupform_{$groupid}" 
		method="post" 
		autocomplete="off" 
		action="home.php?mod=spacecp&ac=usergroup&do=switch&groupid=$groupid"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{gid:'$groupid'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}"
		>
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="groupsubmit" value="true" />
			<input type="hidden" name="gid" value="$_GET[gid]" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<div class="djgm-gmxq list-block-no">
				<ul>
					<li class="guiigo-flex xh-b cl">
						<div class="gmxq-xqbt zy-c">{lang memcp_usergroups_main_old}</div>
						<div class="guiigo-flexy zy-h">$_G[group][grouptitle]</div>
					</li>
					<li class="guiigo-flex xh-b cl">
						<div class="gmxq-xqbt zy-c">{lang memcp_usergroups_main_new}</div>
						<div class="guiigo-flexy zy-h">$group[grouptitle]</div>
					</li>
				</ul>
			</div>
			<!--
			<p class="o pns">
				<button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="pn pnc"><strong>{lang submit}</strong></button>
			</p>
			-->
		</form>
	</div>
<!--{elseif $do == 'expiry' || $do == 'list'}-->
	<div class="gg-kj-wddj">
		<div id="wddj-sxon">
			<div class="gg-kj-djdb">
				<div class="djdb-dqyh"><!--{avatar($_G[uid])}--></div>
				<div class="djdb-dqdj zy-a zy-ac">{lang guiigo_manage:tlang0655}: Lv.{$_G['cache']['usergroups'][$_G[groupid]]['stars']} <!--{eval echo strip_tags($_G['cache']['usergroups'][$_G[groupid]]['grouptitle'],'') }--></div>
				<div class="djdb-sjdj zy-a zy-ac">
				<!--{if $do == 'expiry'}-->
					{lang guiigo_manage:tlang0657}
				<!--{else}-->
					{lang youhave} $usermoney {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}
				<!--{/if}-->
				</div>
			</div>
			<!--{if $expirylist}-->
			<div class="djgm-djlb list-block-no bg-c xh-b">
				<ul>
					<!--{loop $expirylist $groupid $group}-->
						<li class="xh-b">
							<p class="djlb-czan">
								<!--{if in_array($groupid, $extgroupids) || $groupid == $_G['groupid']}-->
									<!--{if $groupid != $_G['groupid']}-->
										<!--{if !$group[noswitch]}-->
											<a href="home.php?mod=spacecp&ac=usergroup&do=switch&groupid=$groupid&handlekey=switchgrouphk" class="ab-az zy-a zy-ac dialog"
											ck-cus="true"
											ck-param="{type:'modal',callpar:{gid:'$groupid'},fn:'MsgCallUsergr',load:'true',uid: '$_G[uid]'}"
											external >{lang memcp_usergroups_set_main}</a>
										<!--{/if}-->
										<!--{if !$group['maingroup']}-->
											<!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy'}-->
												<a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="ab-az zy-a zy-ac dialog"
												ck-cus="true"
												ck-param="{type:'modal',callpar:{gid:'$groupid'},fn:'MsgCallUsergr',load:'true',uid: '$_G[uid]'}" 
												external >{lang renew}</a>
											<!--{/if}-->
											<a href="home.php?mod=spacecp&ac=usergroup&do=exit&groupid=$groupid&handlekey=exitgrouphk" class="ab-az zy-a zy-ac dialog"
											ck-cus="true"
											ck-param="{type:'modal',callpar:{gid:'$groupid'},fn:'MsgCallUsergr',load:'true',uid: '$_G[uid]'}" 
											external >{lang memcp_usergroups_exit}</a>
										<!--{/if}-->
									<!--{else}-->
										<!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy'}-->
											<a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="ab-az zy-a zy-ac dialog"
											ck-cus="true"
											ck-param="{type:'modal',callpar:{gid:'$groupid'},fn:'MsgCallUsergr',load:'true',uid: '$_G[uid]'}" 
											external >{lang renew}</a>
										<!--{/if}-->
										<span class="bg-e zy-f bk-e">{lang main_usergroup}</span>
									<!--{/if}-->
								<!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'free'}-->
									<a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="ab-az zy-a zy-ac dialog"
									ck-cus="true"
									ck-param="{type:'modal',callpar:{gid:'$groupid'},fn:'MsgCallUsergr',load:'true',uid: '$_G[uid]'}" 
									external >{lang free_buy}</a>
								<!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy'}-->
									<a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="ab-az zy-a zy-ac dialog"
									ck-cus="true"
									ck-param="{type:'modal',callpar:{gid:'$groupid'},fn:'MsgCallUsergr',load:'true',uid: '$_G[uid]'}" 
									external >{lang memcp_usergroups_buy}</a>
								<!--{/if}-->
							</p>
							<p class="djlb-djmc zy-h">$group[grouptitle]</p>
							<p class="djlb-jgxq zy-c">
								<!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy' && $group[dailyprice]}-->
									<em class="zy-b">$group[dailyprice]{$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}/{lang guiigo_manage:tlang0658}</em>
								<!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'free'}-->
									<em class="zy-b">{lang free}</em>
								<!--{/if}-->
								<!--{if $group[time]}--> , <em class="zy-i">$group[time]{lang guiigo_manage:tlang0659}</em><!--{else}--><!--{if $group[usermaxdays]}--> , {lang guiigo_manage:tlang0660}$group[usermaxdays]{lang days}<!--{/if}--><!--{/if}-->
							</p>
						</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{else}-->
				<div class="guiigo-wnrtx guiigo-wnrtxx">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang memcp_usergroup_unallow}</p>
				</div>
			<!--{/if}-->
		</div>
	</div>
<!--{else}-->
	<div class="gg-kj-wddj">
		<div class="gg-kj-djdb">
			<div class="djdb-dqyh"><!--{avatar($_G[uid])}--></div>
			<div class="djdb-dqdj zy-a">{lang guiigo_manage:tlang0655}: Lv.{$_G['cache']['usergroups'][$_G[groupid]]['stars']} <!--{eval echo strip_tags($maingroup[grouptitle],'') }--></div>
			<div class="djdb-sjdj zy-a">
			<!--{if $group}-->
				{lang guiigo_manage:tlang0661}$currentgrouptitle<!--{if $group['grouptype'] == 'member'}-->
										<!--{eval $v = $group[groupcreditshigher] - $_G['member']['credits'];}-->
										<!--{if $_G['group']['grouptype'] == 'member' && $v > 0}-->
											, <span class="notice">{lang guiigo_manage:tlang0662} $v {lang guiigo_manage:tlang0543}</span>
										<!--{else}-->
											, <span class="notice">{lang spacecp_usergroup_message2} $group[groupcreditshigher]</span>
										<!--{/if}-->
									<!--{/if}-->
			<!--{else}-->
				{lang guiigo_manage:tlang0663}: $space[credits]
			<!--{/if}-->
			</div>
		</div>
		<div class="gg-kj-djxm">
			<div class="djxm-xmnr list-block-no">
				<ul>
					<!--{echo permtbody($maingroup)}-->
				</ul>
			</div>
			<!--{eval
				$permtype = array(0 => '{lang permission_menu_normaloptions}', 1 => '{lang permission_modoptions_name}');
			}-->
			<div class="djxm-xmbt list-block-no">
				<ul>
					<li>{lang user_level}</li>
					<!--{loop $bperms $key $perm}-->
						<li>$permlang['perms_'.$perm]</li>
					<!--{/loop}-->
					<!--{loop $pperms $key $perm}-->
						<li>$permlang['perms_'.$perm]</li>
					<!--{/loop}-->
					<!--{loop $sperms $key $perm}-->
						<li>$permlang['perms_'.$perm]</li>
					<!--{/loop}-->
					<!--{loop $aperms $key $perm}-->
						<li>$permlang['perms_'.$perm]</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
		<div id="gmy_menu" class="p_pop" style="display:none">$usergroups[my]</div>
		<div id="gupgrade_menu" class="p_pop" style="display:none">$usergroups[upgrade]</div>
		<div id="guser_menu" class="p_pop" style="display:none">$usergroups[user]</div>
		<div id="gadmin_menu" class="p_pop" style="display:none">$usergroups[admin]</div>
	</div>
<!--{/if}-->
{eval
function permtbody($maingroup) {
global $_G, $bperms, $pperms, $sperms, $aperms;
}
<li><!--{echo showstars($_G['cache']['usergroups'][$maingroup['groupid']]['stars']);}--></li>
	<!--{loop $bperms $key $groupbperm}-->
		<li>
			<!--{if $groupbperm == 'creditshigher' || $groupbperm == 'readaccess' || $groupbperm == 'maxpmnum'}-->
			$maingroup[$groupbperm]
			<!--{elseif $groupbperm == 'allowsearch'}-->
				<!--{if $maingroup['allowsearch'] == '0'}-->{lang permission_basic_disable_sarch}<!--{elseif $maingroup['allowsearch'] == '1'}-->{lang permission_basic_search_title}<!--{else}-->{lang permission_basic_search_content}<!--{/if}-->
			<!--{else}-->
				<!--{if $maingroup[$groupbperm] >= 1}--><i class="icon guiigoapp-dui zy-o"></i><!--{else}--><i class="icon guiigoapp-cuo zy-i"></i><!--{/if}-->
			<!--{/if}-->
		</li>
	<!--{/loop}-->
	<!--{loop $pperms $key $grouppperm}-->
		<li>
			<!--{if in_array($grouppperm, array('maxsigsize', 'maxbiosize'))}-->
				$maingroup[$grouppperm] {lang bytes}
			<!--{elseif $grouppperm == 'allowrecommend'}-->
				<!--{if $maingroup[allowrecommend] > 0}-->+$maingroup[allowrecommend]<!--{else}--><i class="icon guiigoapp-cuo zy-i"></i><!--{/if}-->
			<!--{elseif in_array($grouppperm, array('allowat', 'allowcreatecollection'))}-->
				<!--{echo intval($maingroup[$grouppperm])}-->
			<!--{else}-->
				<!--{if $maingroup[$grouppperm] == 1 || (in_array($grouppperm, array('raterange', 'allowcommentpost')) && !empty($maingroup[$grouppperm]))}--><i class="icon guiigoapp-dui zy-o"></i><!--{else}--><i class="icon guiigoapp-cuo zy-i"></i><!--{/if}-->
			<!--{/if}-->
		</li>
	<!--{/loop}-->
	<!--{loop $sperms $key $perm}-->
		<li>
			<!--{if in_array($perm, array('maxspacesize', 'maximagesize'))}-->
				<!--{if $maingroup[$perm]}-->$maingroup[$perm]<!--{else}-->{lang permission_attachment_nopermission}<!--{/if}-->
			<!--{else}-->
				<!--{if $maingroup[$perm] == 1}--><i class="icon guiigoapp-dui zy-o"></i><!--{else}--><i class="icon guiigoapp-cuo zy-i"></i><!--{/if}-->
			<!--{/if}-->
		</li>
	<!--{/loop}-->
	<!--{loop $aperms $key $groupaperm}-->
		<li>
			<!--{if in_array($groupaperm, array('maxattachsize', 'maxsizeperday', 'maxattachnum'))}-->
				<!--{if $maingroup[$groupaperm]}-->$maingroup[$groupaperm]<!--{else}-->{lang permission_attachment_nopermission}<!--{/if}-->
			<!--{elseif $groupaperm == 'attachextensions'}-->
				<!--{if $maingroup[allowpostattach] == 1}--><!--{if $maingroup[attachextensions]}--><p class="nwp" title="$maingroup[attachextensions]">$maingroup[attachextensions]</p><!--{else}-->{lang permission_attachment_nopermission}<!--{/if}--><!--{else}--><i class="icon guiigoapp-cuo zy-i"></i><!--{/if}-->
			<!--{else}-->
				<!--{if $maingroup[$groupaperm] == 1}--><i class="icon guiigoapp-dui zy-o"></i><!--{else}--><i class="icon guiigoapp-cuo zy-i"></i><!--{/if}-->
			<!--{/if}-->
		</li>
	<!--{/loop}-->
<!--{eval
}
}-->
<!--{if $activeus[usergroup] || $activeus[list] || $activeus[expiry]}-->
		$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript">
	function MsgCallUsergr(msg,par,param){
		if(typeof msg === 'object' || typeof par === 'object'){
			if(msg.msg.indexOf('{lang guiigo_manage:tlang0664}') != -1){
				ck8.toast('{lang guiigo_manage:tlang0664} '+ par.group);
				app.PageRefresh(false,'#wddj-sxon','home.php?mod=spacecp&ac=usergroup&do=list')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0665}') != -1){
				ck8.toast('{lang guiigo_manage:tlang0665} '+ par.group);
				app.PageRefresh(false,'#wddj-sxon','home.php?mod=spacecp&ac=usergroup&do=list')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0666}') != -1){
				ck8.toast('{lang guiigo_manage:tlang0666} '+ par.group);
				app.PageRefresh(false,'#wddj-sxon','home.php?mod=spacecp&ac=usergroup&do=list')
			}else {
				ck8.toast(msg.msg,'shibai');
			}
		}else{
			ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
		}
	}
	</script>
</div>
<!--{/if}-->
<!--{template common/footer}-->
