<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="popup-actions" id="moodfm">
	<div class="actions-text guiigo-hfdp bg-c">
		<form method="post" 
		autocomplete="off" 
		id="mood_addform" 
		action="home.php?mod=spacecp&ac=doing&view=$_GET[view]">
			<div class="hfdp-btys xh-b bg-g">
				<a href="javascript:;" class="btys-gbck closehfdp"><i class="icon guiigoapp-guanbi zy-c"></i></a>
				<h2 class="zy-h">{lang guiigo_manage:tlang0704}</h2>
			</div>
			<div class="hfdp-srys xh-b bg-c">
				<textarea name="message" id="message" class="guiigo-pt zy-f" placeholder="{lang guiigo_manage:tlang0229}" onkeyup="strLenCalc(this, 'maxlimit')"></textarea>
				<div class="gg-kj-ssjs zy-c">{lang doing_maxlimit_char}</div>
			</div>
			<div class="hfdp-crqd xh-b bg-g">
				<div class="crqd-gdqd gg-kj-ssfb">
					<button type="button" name="add" value="true" id="add" class="formdajax guiigo-pn ab-az zy-a zy-ac">{lang publish}</button>
				</div>
				<div class="crqd-btat">
					<ul>
						<li><a href="JavaScript:void(0)" class="zy-c" onclick="showFace('appendface', 'message',this)"><i class="icon guiigoapp-biaoqing" style="font-size: .75rem;height: .85rem;line-height: .85rem;"></i><p>{lang guiigo_manage:tlang0150}</p></a></li>
					</ul>
				</div>
				<!--{if $_G['group']['maxsigsize']}-->
				<div class="crqd-btat gg-kj-sstb">
					<span class="zy-f">{lang doing_update_personal_signature}</span>
					<div class="guiigo-pc">
						<input type="checkbox" name="to_signhtml" id="to_sign"><label for="to_sign"><em></em></label>
					</div>
				</div>
				<!--{/if}-->
			</div>
			<div class="list-block-no bg-c">
				<ul>
					<div class="kznr-bqnr cl" style="display:none;" id="appendface"></div>
				</ul>
			</div>
			<input type="hidden" name="addsubmit" value="true" />
			<input type="hidden" name="refer" value="$theurl" />
			<input type="hidden" name="topicid" value="$topicid" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
		</form>
	</div>
</div>
<script>
ck8('.formdajax').click(function() {
	var formobj = ck8(this.form)
	if(ck8('#message').val().length < 10){
		ck8.toast('{lang guiigo_manage:tlang0705}');
		return;
	}
	<!--{if !$_G['uid']}--->
		ck8.toast('{lang guiigo_manage:tlang0706}');
		return;
	<!--{/if}--->
	ck8.showPreloader('','load');
	ck8.ajax({
		type:'POST',
		url:formobj.attr('action')+'&inajax=1',
		data:formobj.serialize(),
		dataType:'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 200);
			ck8('#message').val('')
            app.close_popup()
			app.PageRefresh(false,'#ssol-jz')
			ck8.toast('{lang guiigo_manage:tlang0707}');
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
		}
	})
})
</script>
