<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !$_GET['op'] == 'pm_report' || !$_GET['op'] == 'getpmuser' || !$_GET['op'] == 'showmsg' }-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp-pm">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0562}</h1>
	</header>
	<div class="content">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
<!--{/if}-->
<!--{if $_GET['op'] == 'pm_report'}-->
		<!--{lang guiigo_manage:tlang0368}-->
		<div id="$pmid">
			<form id="pmreportform_{$pmid}" name="pmreportform_{$pmid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=pm&op=pm_report&pmid=$pmid"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pmid:'$pmid,type:'pm_report'},fn:'fn:{if $_GET['fn']}'$_GET['fn']'{/if}',load:'true',uid:'$_G[uid]',cancel:'{lang guiigo_manage:tlang0105}',confirm:'{lang guiigo_manage:tlang0106}'}">
				<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
				<input type="hidden" name="referer" value="{echo dreferer()}" />
				<input type="hidden" name="pmreportsubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="c">{lang determine_report_pm}</div>
				<input type="hidden"name="pmreportsubmit_btn" value="true" />
                <script type="text/javascript" reload="1">if(typeof succeedhandle_=='function')</script>
			</form>
		</div>
<!--{elseif $_GET['op'] == 'getpmuser'}-->
	$jsstr
<!--{elseif $_GET['op'] == 'showmsg'}-->

	<!--{if $msgonly}-->
		<!--{loop $msglist $day $msgarr}-->
			<div class="caon-rqzl cl">
				<span class="bg-i zy-a zd-12">$day</span>
			</div>
			<!--{loop $msgarr $key $value}-->
			<!--{eval $class=$value['touid']==$_G['uid']?'xxnr-dfxx cl':'xxnr-wdxx cl';}-->
			<div class="$class">
				<div class="xxnr-yhtx"><a href="home.php?mod=space&uid=$value[msgfromid]&do=profile" class="guiigo-ty"><img src="<!--{avatar($value[msgfromid], middle, true)}-->" /></a></div>
				<div class="xxnr-xxlb">
					<div class="xxnr-xxlb-a zy-h<!--{if $value[msgfromid] != $_G['uid']}--> bg-c<!--{else}--> bg-q<!--{/if}-->">{$value[message]}</div>
					<div class="xxnr-xxlb-s zy-g"><!--{date($value[dateline], 'u')}--></div>
				</div>
			</div>
			<!--{/loop}-->
		<!--{/loop}-->
	<!--{else}-->

	<!--{if $_GET[inajax] == 1}-->
	<div class="popup popup-about spacecp-pm-newmsg" style="position:fixed;">
	<!--{else}-->
	<div class="page page-current" data-mod="spacecp-pm-newmsg">
	<!--{/if}-->
		<div class="content content-pm bg-g gg-jxbg">
			<div class="gg-xx-tcca">
				<div class="tcca-tops bg-c xh-b app-top" data-content-class="tcca-caon-top">
					<div style="position:relative;">
					<!--{if $_GET[inajax] == 1}-->
						<a href="javascript:;" class="tops-gblt" onclick="closeModalpm()"><i class="icon guiigoapp-guanbi zy-c"></i></a>
						<a href="home.php?mod=space&do=pm&subop=view&touid=$touid" class="tops-lsjl" onclick="closeModalpm()"><i class="icon guiigoapp-lishi zy-c"></i></a>
					<!--{else}-->
						<!--{if $guiigo_config['isguiigoapp']}-->
							<a class="tops-gblt button-link app-back"><i class="icon guiigoapp-guanbi zy-c"></i></a>
						<!--{else}-->
							<a class="tops-gblt button-link back"><i class="icon guiigoapp-guanbi zy-c"></i></a>
						<!--{/if}-->
						<a href="home.php?mod=space&do=pm&subop=view&touid=$touid" class="tops-lsjl"><i class="icon guiigoapp-lishi zy-c"></i></a>
					<!--{/if}-->
					<!--{eval $userlist = getuserbyuid($touid);}-->
					<h1 class="zy-h">{$userlist['username']} <em class="zd-14"><!--{if $online}-->{lang online}<!--{else}-->{lang offline}<!--{/if}--></em></h1>
					</div>
				</div>
				<div id="msglist" class="tcca-caon gg-xx-xxnr gg-xx-json tcca-caon-top">
					<!--{loop $msglist $day $msgarr}-->
						<div class="caon-rqzl cl">
							<span class="bg-i zy-a zd-12">$day</span>
						</div>
						<!--{loop $msgarr $key $value}-->
						<!--{eval $class=$value['touid']==$_G['uid']?'xxnr-dfxx cl':'xxnr-wdxx cl';}-->
						<div class="$class">
							<div class="xxnr-yhtx"><a href="home.php?mod=space&uid=$value[msgfromid]&do=profile" class="guiigo-ty" onclick="closeModalpm()"><img src="<!--{avatar($value[msgfromid], middle, true)}-->" /></a></div>
							<div class="xxnr-xxlb">
								<div class="xxnr-xxlb-a zy-h<!--{if $value[msgfromid] != $_G['uid']}--> bg-c<!--{else}--> bg-q<!--{/if}-->">{$value[message]}</div>
								<div class="xxnr-xxlb-s zy-g"><!--{date($value[dateline], 'u')}--></div>
							</div>
						</div>
						<!--{/loop}-->
					<!--{/loop}-->
				</div>
				<script type="text/javascript">
				var refresh = true;
				var refreshHandle = -1;
				</script>
				<div class="gg-xx-dfsr bg-c sh-a">
					<form id="pmform_{$touid}" 
						name="pmform_{$touid}" 
						method="post" 
						autocomplete="off" 
						ck-cus="true"
						action="home.php?mod=spacecp&ac=pm&op=send&touid=$touid" 
						 ck-param="{type:'modal',callpar:{type:'pm'},fn:'MsgCallPm',load:'true',uid:'{$_G['uid']}'}">
						<input type="hidden" name="pmsubmit" value="true" />
						<input type="hidden" name="touid" value="$touid" />
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<!--{if $_G[inajax]}-->
						<div id="return_$_GET[handlekey]" class="xi1"></div>
						<input type="hidden" name="handlekey" value="$_GET[handlekey]" />
						<!--{/if}-->
						<div class="guiigo-flex dfsr-xxsr">
							<div class="xxsr-bqkz"><a href="JavaScript:void(0)" class="zy-c" onclick="opensmliiess();"><i class="icon guiigoapp-biaoqing"></i></a></div>
							<div class="xxsr-srky guiigo-flexy"><textarea rows="3" cols="80" name="message" class="guiigo-px xh-b" id="needmessage" placeholder="{lang guiigo_manage:tlang0583}"></textarea></div>
							<input type="hidden" name="messageappend" id="messageappend" value="$messageappend" />
							<div class="xxsr-qrfb"><button type="button" class="guiigo-pn ab-az zy-a zy-ac formdialog" id="pmsubmit_btn">{lang send}</button></div>
						</div>
						<div class="bg-c cl guiigo-hfdp opensmliiess hides">
							<div class="kznr-bqnr cl">
								<div class="bqnr-imgs cl swiper-container ck8-smiliestab">
									<div class="swiper-wrapper cl" id="ck8_data"></div>
									<div class="swiper-pagination"></div>
								</div>
								<div class="bqnr-bqqh bg-e cl swiper-container ck8-smiliestabs" style="overflow:hidden;">
									<div class="swiper-wrapper buttons-row" id="smilies"></div>
								</div>
							</div>
						</div>
					</form>
					<script type="text/javascript">var forumallowhtml = 0,allowhtml = 0,allowsmilies = true,allowbbcode = parseInt('{$_G[group][allowsigbbcode]}'),allowimgcode = parseInt('{$_G[group][allowsigimgcode]}');var DISCUZCODE = [];DISCUZCODE['num'] = '-1';DISCUZCODE['html'] = [];</script>
					<script type="text/javascript">
		 				var msgListObj = $('#msglist');
						function MsgCallPm(msg,par,param){
							if(typeof msg === 'object' || typeof par === 'object'){
								if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'pm'){
								var msgs = $('#needmessage').val()
								var html = '<div class="xxnr-wdxx cl">'
									+  '<div class="xxnr-yhtx"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile" class="guiigo-ty"><img src="{avatar($_G[uid], middle, true)}"></a></div>'
									+  '<div class="xxnr-xxlb">'
									+  '<div class="xxnr-xxlb-a zy-h bg-q">'+ msgs +'</div>'
									+  '<div class="xxnr-xxlb-s zy-g">{lang guiigo_manage:tlang0584}</div>'
									+  '</div>'
									+  '</div>';
								msgListObj.append(html)
								ck8.toast('{lang guiigo_manage:tlang0585}');
								var top =  $('#msglist')[0].clientHeight
								$('.content-pm')._scrollTo({ toT:top,durTime:0});
						          $('#needmessage').val('')
                                  ck8('.opensmliiess').removeClass('shows').addClass('hides')
								}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0586}') != -1 && param.type == 'pm'){
									ck8.toast('{lang guiigo_manage:tlang0593}');
								}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0587}') != -1 && param.type == 'pm'){
									ck8.toast('{lang guiigo_manage:tlang0594}');
								}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0588}') != -1 && param.type == 'pm'){
									ck8.toast('{lang guiigo_manage:tlang0589}');
								}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0590}') != -1 && param.type == 'pm'){
									ck8.toast('{lang guiigo_manage:tlang0595}');
								}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0591}') != -1 && param.type == 'pm'){
									ck8.toast('{lang guiigo_manage:tlang0596}');
								}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0592}') != -1 && param.type == 'pm'){
									ck8.toast('{lang guiigo_manage:tlang0597}');
								}else {
									ck8.toast(msg.msg,'shibai');
								}
							}else{
								ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
							}
						}
						
						function refreshMsg() {
							if(refresh) {			
								ck8.ajax({
									type : 'GET',
									url :'home.php?mod=spacecp&ac=pm&op=showmsg&msgonly=1&touid=$touid&pmid=$pmid&inajax=1&daterange=$daterange&inajax=1',
									dataType : 'xml',
									success: function(s){
										var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
										msgListObj.html(Docs)
									},
									error: function(){
										ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
									}
								})
							} else {
								window.clearInterval(refreshHandle);
							}
						}
						refreshHandle = window.setInterval('refreshMsg();', 8000); 
						function closeModalpm(){
							window.clearInterval(refreshHandle);
							$.closeModal()
						}
						
						function opensmliiess(){
								if(ck8('.opensmliiess').hasClass('hides')){
									ck8('.opensmliiess').removeClass('hides').addClass('shows')
								}else if(ck8('.opensmliiess').hasClass('shows')){
									ck8('.opensmliiess').removeClass('shows').addClass('hides')
								}
							if(!ck8('.opensmliiess').attr('data-smliiess')){
								app.loadScript('smiliess');
								app.loadStyle('cssswiper-4.3.3.min');
								app.loadScript('jsswiper-4.3.3.min',function(){
									new Swiper('.ck8-smiliestabs', {
										slidesPerView : 8,
										slideToClickedSlide : true,
										freeMode : true,
										observer : true,
										observeParents : true,
									})
									new Swiper('.ck8-smiliestab', {
										observer : true,
										observeParents : true,
										pagination: {
											el: '.swiper-pagination',
										},
									})
									ck8('.ck8-smiliestabs').css({'visibility':'visible'});
									
									setTimeout(function(){
										smilies_show(39, 'ck8-')
										
										ck8('#msglist').on('click',function(){
											 ck8('.opensmliiess').removeClass('shows').addClass('hides')	 
										})
										 ck8('.opensmliiess').on('click','.bqimg',function(){
											 ck8('.opensmliiess').removeClass('shows').addClass('hides')	 
										 })
									},500)

								})
							}
							ck8('.opensmliiess').attr('data-smliiess','open')
						}
						setTimeout(function(){
							appTplinit(ck8('.spacecp-pm-newmsg'))
						},500)
					</script>
				</div>
			</div>
		</div>
	</div>
	<!--{/if}-->
<!--{else}-->
	<!--{if !$type}-->
		<div id="__pmform_{$pmid}">
			<form id="pmform_{$pmid}" 
			name="pmform_{$pmid}" 
			method="post" 
			autocomplete="off" 
			action="home.php?mod=spacecp&ac=pm&op=send&touid=$touid&pmid=$pmid"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pmid:'',type:'pm_submit'},fn:'MsgCallPm',load:'true',uid:'$_G[uid]'}"  
			>
				<input type="hidden" name="referer" value="{echo dreferer()}" />
				<input type="hidden" name="pmsubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
					<ul>
						<!--{if !$touid}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0598}</div>
								<div class="wblb-wbnr zy-h"><input type="text" class="guiigo-px s-a" name="username" id="username" autocomplete="off" placeholder="{lang guiigo_manage:tlang0599}"/></div>
							</li>
						<!--{/if}-->
						<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang guiigo_manage:tlang0600}</li>
						<li class="wblb-nrsr xh-b zy-h cl">
							<div class="wblb-wbnr zy-h"><textarea rows="8" cols="40" name="message" class="guiigo-pt s-a" id="sendmessage" onkeydown="strLenCalc(this,'pmsubmit_btn',200);"></textarea></div>
						</li>
					</ul>
				</div>
				<div class="gg-xx-fbsx zy-c">{lang guiigo_manage:tlang0601} <i id="pmsubmit_btn" class="zy-b">200</i> {lang guiigo_manage:tlang0602}</div>
				<div class="mn-a">
					<button type="submit" name="pmsubmit_btn" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang send}</button>
				</div>
			</form>
		</div>
		<script>			
			function MsgCallPm(msg,par,param){
				if(typeof msg === 'object' || typeof par === 'object'){
					if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'pm_submit' && par.succeed ==1){
						ck8.toast('{lang guiigo_manage:tlang0585}');
						setTimeout(function(){
							ck8.router.back()
						},1000)
					}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0603}') != -1 && param.type == 'pm_submit'){
						ck8.toast('{lang guiigo_manage:tlang0604}');
					}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0605}') != -1 && param.type == 'pm_submit'){
						ck8.toast('{lang guiigo_manage:tlang0606}');
					}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0607}') != -1 && param.type == 'pm_submit'){
						ck8.toast('{lang guiigo_manage:tlang0608}');
					}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0586}') != -1 && param.type == 'pm_submit'){
						ck8.toast('{lang guiigo_manage:tlang0609}');
					}else {
						ck8.toast(msg.msg,'shibai');
					}
				}else{
					ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
				}
			}
		</script>
	<!--{/if}-->
<!--{/if}-->
<!--{if !$_GET['op'] == 'pm_report' || !$_GET['op'] == 'getpmuser' || !$_GET['op'] == 'showmsg' }-->
		</div>
	</div>
</div>
<!--{/if}-->
<!--{template common/footer}-->
