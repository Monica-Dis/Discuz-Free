<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div id="friend_ul_page"  
data-url="$theurl" 
data-pages="{$count}" 
data-ppp="{$perpage}" 
data-page="$page" 
data-islod="false" 
data-distance="20">
<!--{if $list}-->
	<div class="gg-sq-tayc list-block-no ms-a sh-a xh-b bg-c">
		<ul class="list-container ms-c">
			<!--{loop $list $key $value}-->
			<li class="xh-a">
				<div class="gg-kj-hycz">
					<!--{if isset($value['follow']) && $key != $_G['uid']}-->
						<!--{if !$value['follow']}-->
							<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$value[uid]" 
							id="a_followmod_$key" 
							style="color:#9dca06;"
							class="followmod_$value[uid] dialog"
							ck-cus="true"
							ck-confirm="false"
							ck-param="{type:'modal',callpar:{fuid:'$value[uid]'},fn:'MsgCallFrifolli',load:'true',uid:'{$_G[uid]}'}" 
							external ><i class="icon guiigoapp-tabkgzt"></i><p>{lang guiigo_manage:tlang0011}</p></a>
						<!--{else}-->
							<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$value[uid]" 
							id="a_followmod_$key" 
							style="color:#9dca06;"
							class="followmod_$value[uid] dialog"
							ck-cus="true"
							ck-confirm="false"
							ck-param="{type:'modal',callpar:{fuid:'$value[uid]'},fn:'MsgCallFrifolli',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}" 
							external ><i class="icon guiigoapp-tabkgzt"></i><p>{lang guiigo_manage:tlang0719}</p></a>
						<!--{/if}-->
					<!--{/if}-->
					<a {if $_G[uid]}href="home.php?mod=spacecp&ac=poke&op=send&uid=$value[uid]" id="a_poke_$key" style="color:#FF9900;" data-no-cache="true"{else}href="javascript:;" class="login" style="color:#FF9900;"{/if}><i class="icon guiigoapp-tabkdzh"></i><p>{lang guiigo_manage:tlang0610}</p></a>
					<a href="javascript:;" 
						{if $_G[uid]}
						id="a_sendpm_$key" 
						style="color:#ff6060;"
						class="getpm-popup"
						data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$value[uid]&touid=$value[uid]&pmid=0&daterange=2"
						external
						{else}
						style="color:#ff6060;"
						class="login"
						{/if}
						><i class="icon guiigoapp-tabkfxx"></i><p>{lang guiigo_manage:tlang0720}</p></a>
					<!--{if isset($value['isfriend']) && !$value['isfriend']}-->
						<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]" 
						id="a_friend_$key" 
						class="dialog" 
						style="color:#3ebbfd;"
						ck-cus="true"
						ck-confirm="falsea"
						ck-param="{type:'modal',callpar:{fuid:'$value[uid]'},fn:'MsgCallfined',load:'true',uid:'{$_G[uid]}'}" 
						external ><i class="icon guiigoapp-tabkjhy"></i><p>{lang guiigo_manage:tlang0618}</p></a>
					<!--{/if}-->
				</div>
				<div class="bkys-bkico bkys-bkicoy">
					<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="guiigo-ty">
						<!--{avatar($value[uid],middle)}-->
					</a>
				</div>
				<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="bkys-bkmc zy-e">$value[username]</a>
				<p class="zy-g">{$_G['cache']['usergroups'][$value['groupid']]['grouptitle']}</p>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
<!--{else}-->
	<div class="guiigo-wnrtx">
		<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
		<p class="zy-c">{lang guiigo_manage:tlang0725}</p>
	</div>
<!--{/if}-->
<!--{if $list}-->
	<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
		<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
	</div>
	<div onclick="infinite('#friend_ul_page')" class="loadpage bg-c bk-e zy-c">{lang guiigo_manage:tlang0492}<i class="icon guiigoapp-ssxx zy-c"></i></div>
<!--{/if}-->
</div>
