<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-thread">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="search.php?mod=forum" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-f"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0116}</h1>
	</header>
	<div class="content gthread-scroll">
		<div class="list-block">
		{eval
			$filter = array( 'common' => '{lang have_posted}', 'save' => '{lang draft}', 'close' => '{lang closed}', 'aduit' => '{lang pending}', 'ignored' => '{lang ignored}', 'recyclebin' => '{lang recyclebin}');
			$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=thread&view=me\">{lang they_thread}</a>";
		}
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacethread list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $orderactives[thread]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.gthread-scroll','home.php?mod=space&do=thread&view=me&type=thread',['gg-thread-s']);">{lang guiigo_manage:tlang0809}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $orderactives[reply]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.gthread-scroll','home.php?mod=space&do=thread&view=me&type=reply',['gg-thread-s']);">{lang guiigo_manage:tlang0810}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $orderactives[postcomment]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.gthread-scroll','home.php?mod=space&do=thread&view=me&type=postcomment',['gg-thread-s']);">{lang guiigo_manage:tlang0811}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-thread-s">
				<!--{if !$diymode && $space[self]}-->
					<!--{if $_GET['view'] == 'me'}-->
						<!--{if $viewtype != 'postcomment'}-->
							<div class="gg-wdzt-sx cl">
								<a href="javascript:;" onclick="app.LoadPageForumView('.gthread-scroll','home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=',['gg-kj-ztlb','gg-wdzt-sx']);" {if !$_GET[filter]}class="a"{/if}>{lang all}</a>
								<!--{loop $filter $key $name}--><a href="javascript:;" onclick="app.LoadPageForumView('.gthread-scroll','home.php?mod=space&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=$key',['gg-kj-ztlb','gg-wdzt-sx']);" {if $key == $_GET[filter]}class="a"{/if}>$name</a><!--{/loop}-->
							</div>
						<!--{/if}-->
					<!--{/if}-->
				<!--{/if}-->
				<div id="prkonzs1" class="gg-kj-ztlb">
					<div id="prkonzs1-page-$_GET['type']" 
						data-url="$theurl" 
						data-pages="{$listcount}" 
						data-ppp="{$perpage}" 
						data-page="$page" 
						data-islod="false">
					<!--{if $list}-->
					<!--{eval $list = GuiigoApp::GetPostlist($list);}-->
							<div class="guiigo-ztlb list-block-no">
								<ul class="list-container bg-g">
									<!--{loop $list $stid $thread}-->
										<li class="gztlb-ztys bg-c xh-b sh-a">
											<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><!--{elseif $thread['digest'] > 0}-->
												<div class="gztlb-jhzt"><i class="icon guiigoapp-jinghua zy-i"></i></div>
											<!--{/if}-->
											<div class="gztlb-tbyh">
												<div class="tbyh-lztx guiigo-ty"><!--{if $thread['authorid'] && $thread['author']}--><a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><!--{avatar($thread[authorid],middle)}--></a><!--{else}--><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg"><!--{/if}--></div>
												<div class="tbyh-mcxx">
													<h1>
														<!--{if $thread['authorid'] != $_G['uid']}-->
														<!--{if $thread['isfollow'] ==1}-->
														<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$thread['authorid']" 
														class="followmod_$thread[authorid] dialog mcxx-gzan zy-c bk-c bg-e" 
														ck-cus="true" 
														ck-confirm="true" 
														ck-param="{type:'modal',callpar:{tid:'$thread['authorid']'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}" 
														external >{lang guiigo_manage:tlang0003}</a>
														<!--{else}-->
														<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]"
														class="followmod_$thread[authorid] dialog mcxx-gzan zy-b bk-b"  
														ck-cus="true"
														ck-confirm="false"
														ck-param="{type:'modal',callpar:{tid:'$thread[authorid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}"
														external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
														<!--{/if}-->
														<!--{/if}-->
														
														<!--{if $thread['authorid'] && $thread['author']}-->
															<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="mcxx-yhmc zy-f">$thread[author]</a>
															
															<span class="mcxx-yhdj zy-a" style="background: {$thread[groupcolor]};">{$thread[groupstars]} {$thread[grouptitle]}</span>
															<!--{if $thread['gender'] == 1 || $thread['gender'] == 0}-->
															<i class="icon guiigoapp-nan bg-n"></i>
															<!--{elseif $thread['gender'] == 2}-->
															<i class="icon guiigoapp-nv bg-o"></i>
															<!--{/if}-->
															<!--{if $_G['setting']['verify']['enabled']}-->
																<span class="verify-icon y">
																<!--{loop $thread['verifyicon'] $verify}-->
																	<a href="{$verify['verifurl']}" class="ck8-avatar-icon">
																	   <img src="{$verify['verificon']}" class="vm" />
																	</a>
																<!--{/loop}-->
																</span>
															<!--{/if}-->
														<!--{else}-->
															<a href="javascript:void(0);" class="mcxx-yhmc zy-f">$_G[setting][anonymoustext]</a>
														<!--{/if}-->
													</h1>
													<div class="mcxx-fbxx">
														<i class="zy-g"><!--{eval echo dgmdate($thread[dateline], 'u');}--></i>
													</div>
												</div>
											</div>
											<div class="gztlb-nrdy">
												<h1>
													<!--{if $thread[special] == 1}-->
														<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0138}</span>
													<!--{elseif $thread[special] == 2}-->
														<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0139}</span>
													<!--{elseif $thread[special] == 3}-->
														<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0140}</span>
													<!--{elseif $thread[special] == 4}-->
														<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0141}</span>
													<!--{elseif $thread[special] == 5}-->
														<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0142}</span>
													<!--{elseif $thread['rushreply']}-->
														<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0143}</span>
													<!--{/if}-->
													<!--{if $thread['replycredit'] > 0}-->
														<span class="nrdy-ztlx bg-j zy-a">{lang guiigo_manage:tlang1028}</span>
													<!--{/if}-->
													<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]>{$thread['subject']}</a>
												</h1>
												<!--{if $thread['message']}-->
													<p class="zy-c"><!--{$thread['message']}--></p>
												<!--{/if}-->
												<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
													<div class="nrdy-imgs">
														<ul style="display: flex;justify-content: left;flex-wrap: wrap;">
														<!--{loop $thread[attapic] $imgkey $imglist}-->
															<!--{if $imglist['countImg'] == 1}-->
																<li class="imgs-tpsa"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
															<!--{elseif $imglist['countImg'] == 2}-->
																<li class="imgs-tpsb"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
															<!--{elseif $imglist['countImg'] == 3}-->
																<li class="imgs-tpsb imgs-tpsp"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
															<!--{else}-->
																<li class="imgs-tpsc<!--{if $imglist['countImg'] > 6}--> imgs-tpsd<!--{/if}-->"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/><!--{if $imglist['countImg'] > 6}--><div class="tpsd-gdtp"><span class="tpsd-jtnr"><i class="icon guiigoapp-mkbtgd"></i>{$imglist['countImg']}</span></div><!--{/if}--></li>
															<!--{/if}-->
														<!--{/loop}-->
														</ul>
													</div>
												</a>
											</div>
											<div class="gztlb-ztcz">
												<div class="ztcz-lyrd cl">
													<div class="ztcz-bkht"><i class="icon guiigoapp-huati1 ab-a"></i><em><a href="forum.php?mod=forumdisplay&fid=$thread[fid]">$forums[$thread[fid]]</a></em></div>
													<!--{if $thread[heats] > 0}-->
														<div class="ztcz-bkht ztcz-ztrd"><i class="icon guiigoapp-lredu"></i>{lang guiigo_manage:tlang0879} {$thread[heats]}</div>
													<!--{/if}-->
												</div>
												<ul>
													<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-huifu"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[replies])}--><!--{else}-->$thread[replies]<!--{/if}--></a></li>
													<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-chakan"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[views])}--><!--{else}-->$thread[views]<!--{/if}--></a></li>
													<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
														<!--{eval $recommenus=$thread['isrecommenus']==1 ? 1 :'';}-->
														<li class="ztcz-ybcz">
															<div class="ztcz-dzkz{if $recommenus} zy-b bg-m{else} zy-c bg-l{/if}" id="recommend_add_$thread[tid]">
																<a href="{if $recommenus}plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid=$thread[tid]{else}forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&hash={FORMHASH}&handlekey=recommend_add{/if}"  
																	class="{if $recommenus}delRecommenus{else}dialog{/if}" 
																	ck-cus="true"
																	ck-param="{
																		type:'modal',
																		callpar:{tid:'$thread[tid]'},
																		fn:'MsgCallFn',
																		load:'true',
																		uid:'{$_G[uid]}'
																	}" 
																	external ><i class="icon{if $recommenus} guiigoapp-dianzanon{else} guiigoapp-dianzan{/if}"></i>
																</a>
																<em id="recommend_add_sum$thread[tid]"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[recommend_add])}--><!--{else}-->$thread[recommend_add]<!--{/if}--></em>
															</div>
														</li>
													<!--{/if}-->
												</ul>
											</div>
											<!--{if $thread['displayorder'] == -1}--><i class="icon guiigoapp-yishanchu gg-kj-yszt zy-i"></i><!--{/if}-->
										</li>
									<!--{/loop}-->
								</ul>
							</div>
							<!--{if $multi}-->
							<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
								<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
							</div>
							<div onclick="infinite('#prkonzs1-page-$_GET[type]')" class="loadpage bg-c bk-e zy-c">{lang guiigo_manage:tlang0492}<i class="icon guiigoapp-ssxx zy-c"></i></div>
							<!--{/if}-->
						<!--{else}-->
							<div class="guiigo-wnrtx guiigo-wnrtxx">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
								<p class="zy-c">{lang guiigo_manage:tlang0225}</p>
							</div>
						<!--{/if}-->
					</div>
				</div>
			</div>
			{$guiigo_config['footer_html']}
	</div>
</div>
<script>
function MsgCallFn(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = $('.followmod_'+ par.fuid +'');
		var foObj = $('#recommend_add_'+ param.tid +'');
		var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
			$.toast('{lang guiigo_manage:tlang0003}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
			Obj.attr('ck-confirm','true')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			$.toast('{lang guiigo_manage:tlang0009}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
			Obj.attr('ck-confirm','false')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			$.toast('{lang guiigo_manage:tlang0007}');
		}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
			foObj.addClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzanon"></i>');
			$('#recommend_add_sum'+ param.tid).html(''+ (recommendcut + parseInt(par.recommendv)));
			foObj.find('a').addClass('delRecommenus').removeClass('dialog').attr('href','plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid='+ param.tid)
			$.toast('{lang guiigo_manage:tlang0045}');
			if(par.daycount){
				setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
			}
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
			$.toast('{lang guiigo_manage:tlang0049}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
			$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
				$.router.load('home.php?mod=spacecp&ac=usergroup');
			});
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
			$.toast('{lang guiigo_manage:tlang0053}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
			$.toast('{lang guiigo_manage:tlang0055}');
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}
</script>
<!--{template common/footer}-->
