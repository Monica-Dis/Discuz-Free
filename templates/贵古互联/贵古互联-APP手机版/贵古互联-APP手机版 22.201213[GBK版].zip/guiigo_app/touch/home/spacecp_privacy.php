<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp_privacy">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">
			<!--{if $operation == 'base'}-->
			{lang guiigo_manage:tlang0527}
			<!--{else}-->
			{lang guiigo_manage:tlang0619}
			<!--{/if}-->
		</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-qz-flts bg-c ms-a">
				<div class="flts-tsnr bk-d bg-p zy-b">
					<!--{if $operation == 'base'}-->
						{lang guiigo_manage:tlang0628}
					<!--{else}-->
						{lang guiigo_manage:tlang0629}
					<!--{/if}-->
				</div>
			</div>
			<form id="privacykz" 
			name="privacykz"
			method="post" 
			autocomplete="off" 
			action="home.php?mod=spacecp&ac=privacy&op=$operation"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pmid:'',type:'privacykz'},fn:'MsgCallPriv',load:'true',uid:'$_G[uid]'}">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			<!--{if $operation == 'base'}-->
				<div class="gg-kj-yssz ms-a">
					<div class="yssz-szxm bg-c xh-b">
						<div class="szxm-sznr">
							<span class="zy-h">{lang guiigo_manage:tlang0152}</span>
							<input type="text" class="guiigo-ps s-a zy-c select-picker" value="{lang open_privacy}" data-select="basea" />
							<select name="privacy[view][friend]" id="basea" style="display:none;">
								<option value="0"$sels[view][friend][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][friend][1]>{lang friend_privacy}</option>
								<option value="2"$sels[view][friend][2]>{lang secrecy}</option>
								<option value="3"$sels[view][friend][3]>{lang privacy_register}</option>
							</select>
						</div>
					</div>
				
					<!--{if helper_access::check_module('wall')}-->
					<div class="yssz-szxm bg-c xh-b">
						<div class="szxm-sznr">
							<span class="zy-h">{lang guiigo_manage:tlang0620}</span>
							<input type="text" class="guiigo-ps s-a zy-c select-picker" value="{lang open_privacy}" data-select="baseb" />
							<select name="privacy[view][wall]" id="baseb" style="display:none;">
								<option value="0"$sels[view][wall][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][wall][1]>{lang friend_privacy}</option>
								<option value="2"$sels[view][wall][2]>{lang secrecy}</option>
								<option value="3"$sels[view][wall][3]>{lang privacy_register}</option>
							</select>
						</div>
					</div>
					<!--{/if}-->
					<!--{if helper_access::check_module('doing')}-->
					<div class="yssz-szxm bg-c xh-b">
						<div class="szxm-sznr">
							<span class="zy-h">{lang guiigo_manage:tlang0621}</span>
							<input type="text" class="guiigo-ps s-a zy-c select-picker" value="{lang open_privacy}" data-select="basec" />
							<select name="privacy[view][doing]" id="basec" style="display:none;">
								<option value="0"$sels[view][doing][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][doing][1]>{lang friend_privacy}</option>
								<option value="3"$sels[view][doing][3]>{lang privacy_register}</option>
							</select>
						</div>
					</div>
					<!--{/if}-->
					<!--{if helper_access::check_module('blog')}-->
					<div class="yssz-szxm bg-c xh-b">
						<div class="szxm-sznr">
							<span class="zy-h">{lang blog}</span>
							<input type="text" class="guiigo-ps s-a zy-c select-picker" value="{lang open_privacy}" data-select="based" />
							<select name="privacy[view][blog]" id="based" style="display:none;">
								<option value="0"$sels[view][blog][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][blog][1]>{lang friend_privacy}</option>
								<option value="3"$sels[view][blog][3]>{lang privacy_register}</option>
							</select>
						</div>
					</div>
					<!--{/if}-->
					<!--{if helper_access::check_module('album')}-->
					<div class="yssz-szxm bg-c xh-b">
						<div class="szxm-sznr">
							<span class="zy-h">{lang album}</span>
							<input type="text" class="guiigo-ps s-a zy-c select-picker" value="{lang open_privacy}" data-select="basee" />
							<select name="privacy[view][album]" id="basee" style="display:none;">
								<option value="0"$sels[view][album][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][album][1]>{lang friend_privacy}</option>
								<option value="3"$sels[view][album][3]>{lang privacy_register}</option>
							</select>
						</div>
					</div>
					<!--{/if}-->
					<!--{if helper_access::check_module('share')}-->
					<div class="yssz-szxm bg-c xh-b">
						<div class="szxm-sznr">
							<span class="zy-h">{lang share}</span>
							<input type="text" class="guiigo-ps s-a zy-c select-picker" value="{lang open_privacy}" data-select="basef" />
							<select name="privacy[view][share]" id="basef" style="display:none;">
								<option value="0"$sels[view][share][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][share][1]>{lang friend_privacy}</option>
								<option value="3"$sels[view][share][3]>{lang privacy_register}</option>
							</select>
						</div>
					</div>
					<!--{/if}-->
				</div>
				<div class="mn-a">
					<button type="submit" name="privacysubmit" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang save}</button>
					<input type="hidden" name="privacysubmit" value="true" />
				</div>
				<script>			
					function MsgCallPriv(msg,par,param){
						if(typeof msg === 'object' || typeof par === 'object'){
							if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'privacykz'){
								ck8.toast('{lang guiigo_manage:tlang0455}');
								setTimeout(function(){
									ck8.router.back()
								},2000)
							}else {
								ck8.toast(msg.msg,'shibai');
							}
						}else{
							ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
						}
					}
				</script>
			<!--{else}-->
				{eval 
					$iconnames['wall'] = '{lang message}';
					$iconnames['piccomment'] = '{lang pic_comment}';
					$iconnames['blogcomment'] = '{lang blog_comment}';
					$iconnames['sharecomment'] = '{lang share_comment}';
					$iconnames['magic'] = '{lang magics_title}';
					$iconnames['sharenotice'] = '{lang share_notification}';
					$iconnames['clickblog'] = '{lang blog_position}';
					$iconnames['clickpic'] = '{lang pic_position}';
					$iconnames['credit'] = '{lang credits}';
					$iconnames['doing'] = '{lang doing}';
					$iconnames['pcomment'] = '{lang topic_comment}';
					$iconnames['post'] = '{lang topic_reply}';
					$iconnames['show'] = '{lang friend_top}';
					$iconnames['task'] = '{lang task}';
					$iconnames['goods'] = '{lang trade}';
					$iconnames['group'] = $_G[setting][navs][3][navname];
					$iconnames['thread'] = '{lang theme}';
					$iconnames['system'] = '{lang system}';
					$iconnames['friend'] = '{lang friends}';
					$iconnames['debate'] = '{lang debate}';
					$iconnames['album'] = '{lang album}';
					$iconnames['blog'] = '{lang blog}';
					$iconnames['poll'] = '{lang poll}';
					$iconnames['activity'] = '{lang activity}';
					$iconnames['reward'] = '{lang reward}';
					$iconnames['share'] = '{lang share}';
					$iconnames['profile'] = '{lang update_presonal_profile}';
					$iconnames['pusearticle'] = '{lang article_push}';
					$iconnames['poke'] = '{lang guiigo_manage:tlang0610}';
					$iconnames['verify'] = '{lang guiigo_manage:tlang0622}';
					$iconnames['pmreport'] = '{lang guiigo_manage:tlang0623}';
					$iconnames['verify_1'] = '{lang guiigo_manage:tlang0624}';
					$iconnames['verify_2'] = '{lang guiigo_manage:tlang0624}';
					$iconnames['verify_3'] = '{lang guiigo_manage:tlang0624}';
					$iconnames['verify_4'] = '{lang guiigo_manage:tlang0624}';
					$iconnames['verify_5'] = '{lang guiigo_manage:tlang0624}';
					$iconnames['verify_6'] = '{lang guiigo_manage:tlang0624}';
					$iconnames['verifyrecyclepost'] = '{lang guiigo_manage:tlang0625}';
					$iconnames['verifyrecycle'] = '{lang guiigo_manage:tlang0626}';
				}
				<!--{if $types}-->
					<div class="gg-xx-pblb ms-a">
						<!--{loop $types $key $type}-->
						<!--{eval $uid = $uids[$key];$type_uid="$type|$uid";}-->
						<label class="guiigo-pd bg-c xh-b zy-h">
							<input type="checkbox" class="guiigo-pd-k" name="privacy[filter_note][$type_uid]" value="1" checked="checked" />
							<span></span>
							<!--{if isset($iconnames[$type])}-->$iconnames[$type]<!--{else}-->$type<!--{/if}--><em class="zy-c"> - <!--{if $users[$uid]}--><a href="home.php?mod=space&uid=$uid&do=profile" class="zy-l">$users[$uid]</a><!--{else}-->{lang all_friends}<!--{/if}--></em>
						</label>
						<!--{/loop}-->
					</div>
					<div class="mn-a">
						<button type="submit" name="privacy2submit" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang save}</button>
						<input type="hidden" name="privacy2submit" value="true" />
					</div>
					<script>			
						function MsgCallPriv(msg,par,param){
							if(typeof msg === 'object' || typeof par === 'object'){
								if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'privacykz'){
									ck8.toast('{lang guiigo_manage:tlang0455}');
									setTimeout(function(){
										ck8.router.back()
									},2000)
								}else {
									ck8.toast(msg.msg,'shibai');
								}
							}else{
								ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
							}
						}
					</script>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0627}</p>
					</div>					
				<!--{/if}-->
			<!--{/if}-->
			</form>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->
