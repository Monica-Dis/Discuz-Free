<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="popup close-popup popup-kjbgq guiigo-kfon">
	<div class="kfon-kfnv bg-c">
		<div class="kfnv-xznr zy-g">{lang guiigo_manage:tlang0504}</div>
		<!--{eval $userHstyle = $guiigo_config['appsetting']['userHstyle'][$space[uid]];}-->
		<!--{if !$userHstyle}-->
			<!--{eval $userHstyle = 'k1';}-->
		<!--{/if}-->
		<div class="kfnv-fgqh" id="kjstyleall">
			<a href="javascript:;" {if $userHstyle =='k1'}class="on"{/if} onclick="homeSwitchStyle(this,'k1');" data-style="k1" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k1b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0956}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k2'}class="on"{/if} onclick="homeSwitchStyle(this,'k2');" data-style="k2" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k2b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0957}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k3'}class="on"{/if} onclick="homeSwitchStyle(this,'k3');" data-style="k3" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k3b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0958}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k4'}class="on"{/if} onclick="homeSwitchStyle(this,'k4');" data-style="k4" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k4b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0959}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k5'}class="on"{/if} onclick="homeSwitchStyle(this,'k5');" data-style="k5" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k5b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0960}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k6'}class="on"{/if} onclick="homeSwitchStyle(this,'k6');" data-style="k6" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k6b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0961}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k7'}class="on"{/if} onclick="homeSwitchStyle(this,'k7');" data-style="k7" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k7b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0962}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k18'}class="on"{/if} onclick="homeSwitchStyle(this,'k8');" data-style="k8" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k8b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0963}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k9'}class="on"{/if} onclick="homeSwitchStyle(this,'k9');" data-style="k9" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k9b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0964}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k10'}class="on"{/if} onclick="homeSwitchStyle(this,'k10');" data-style="k10" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k10b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0965}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k11'}class="on"{/if} onclick="homeSwitchStyle(this,'k11');" data-style="k11" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k11b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0966}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k12'}class="on"{/if} onclick="homeSwitchStyle(this,'k12');" data-style="k12" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k12b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0967}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k13'}class="on"{/if} onclick="homeSwitchStyle(this,'k13');" data-style="k13" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k13b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0968}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k14'}class="on"{/if} onclick="homeSwitchStyle(this,'k14');" data-style="k14" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k14b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0969}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k15'}class="on"{/if} onclick="homeSwitchStyle(this,'k15');" data-style="k15" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k15b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0970}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
			
			<a href="javascript:;" {if $userHstyle =='k16'}class="on"{/if} onclick="homeSwitchStyle(this,'k16');" data-style="k16" style="background: url({$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kjbg/kjbg-k16b.jpg) no-repeat 0 0;background-size: cover;"><p class="zy-a">{lang guiigo_manage:tlang0971}</p><span class="bg-c"><i class="icon guiigoapp-dui zy-b"></i></a>
		</div>
		<a href="javascript:;" class="kfnv-clan close-popup"><i class="icon guiigoapp-cuo bg-e zy-g zy-ac"></i></a>
	</div>
</div>
