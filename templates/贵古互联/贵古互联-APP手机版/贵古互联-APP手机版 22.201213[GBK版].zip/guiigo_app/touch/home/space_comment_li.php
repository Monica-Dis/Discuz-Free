<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<a name="comment_anchor_$value[cid]"></a>
<!--{if empty($ajax_edit)}--><li id="comment_$value[cid]_li" class="xh-b cl"><!--{/if}-->
	<div class="sssj-sstx guiigo-ty">
		<!--{if $value[author]}-->
		<a href="home.php?mod=space&uid=$value[authorid]&do=profile"><!--{avatar($value[authorid],middle)}--></a>
		<!--{else}-->
		<a href="javascript:void(0)"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg"/></a>
		<!--{/if}-->
	</div>
	<div class="sssj-ssnr sssj-ssnrp">
		<h1>
			<span class="gg-kj-plcz">
				<!--{if $value[authorid]!=$_G[uid] && ($value['idtype'] != 'uid' || $space[self]) && $value[author]}-->
					<a href="home.php?mod=spacecp&ac=comment&op=reply&cid=$value[cid]&feedid=$feedid&handlekey=replycommenthk_{$value[cid]}" 
					id="c_$value[cid]_reply" 
					class="bg-e zy-g bk-e dialog"
					ck-cus="true" 
					ck-param="{type:'modal',callpar:{liid:'{$cid}',type:'huifu'},fn:'MsgCallwzplx',load:'true',uid: '$_G[uid]'}" 
					external ><i class="icon guiigoapp-sshuifu"></i></a>
				<!--{/if}-->
				<!--{if $_G[uid]}-->
					<!--{if $value[authorid]==$_G[uid]}-->
						<a href="home.php?mod=spacecp&ac=comment&op=edit&cid=$value[cid]&handlekey=editcommenthk_{$value[cid]}" 
						id="c_$value[cid]_edit" 
						class="bg-e zy-g bk-e dialog"
						ck-cus="true" 
						ck-param="{type:'modal',callpar:{liid:'{$cid}',type:'bianji'},fn:'MsgCallwzplx',load:'true',uid: '$_G[uid]'}" 
						external ><i class="icon guiigoapp-fbxhfb"></i></a>
					<!--{/if}-->
					<!--{if $value[authorid]==$_G[uid] || $value[uid]==$_G[uid] || checkperm('managecomment')}-->
						<a href="home.php?mod=spacecp&ac=comment&op=delete&cid=$value[cid]&handlekey=delcommenthk_{$value[cid]}" 
						id="c_$value[cid]_delete" 
						class="bg-e zy-g bk-e dialog"
						ck-cus="true" 
						ck-param="{type:'modal',callpar:{liid:'$value[cid]',type:'shanchu'},fn:'MsgCallwzplx',load:'true',uid: '$_G[uid]'}" 
						external ><i class="icon guiigoapp-shanchu"></i></a>
					<!--{/if}-->
				<!--{/if}-->
			</span>
			<!--{if $value[author]}-->
				<a href="home.php?mod=space&uid=$value[authorid]&do=profile" id="author_$value[cid]" class="zy-h">{$value[author]}</a>
			<!--{else}-->
				<a href="javascript:void(0)" class="zy-h">$_G[setting][anonymoustext]</a>
			<!--{/if}-->
			<p class="zy-c"><!--{date($value[dateline])}--><!--{if checkperm('managecomment')}--><em class="zy-g"> IP: $value[ip]</em><!--{/if}--><!--{if $value[status] == 1}--><em class="zy-i"> {lang moderate_need}</em><!--{/if}--></p>
		</h1>
		<div id="comment_$value[cid]" class="gg-kj-plnr zy-e{if $value[magicflicker]} magicflicker{/if}"><!--{if $value[status] == 0 || $value[authorid] == $_G[uid] || $_G[adminid] == 1}-->$value[message]<!--{else}-->{lang moderate_not_validate}<!--{/if}--></div>
	</div>
<!--{if empty($ajax_edit)}--></li><!--{/if}-->
