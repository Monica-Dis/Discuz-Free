<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-friend">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h"><!--{if $do=='following'}-->{lang guiigo_manage:tlang0002}<!--{elseif $do=='follower'}-->{lang guiigo_manage:tlang0041}<!--{else}-->{lang guiigo_manage:tlang0042}<!--{/if}--></h1>
	</header>
	<div class="content">
		<div class="list-block" 
			id="fuser-page"  
			data-url="$theurl" 
			data-pages="{$count}" 
			data-ppp="{$perpage}" 
			data-page="$page" 
			data-islod="false" 
			data-distance="20">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if in_array($do, array('following', 'follower'))}-->
				<!--{if $list}-->
				<div class="gg-sq-tayc list-block-no ms-a sh-a xh-b bg-c">
					<ul class="list-container ms-c">
					<!--{loop $list $fuid $fuser}-->
						<li class="xh-a<!--{if in_array($fuser['uid'], $newfollower_list)}--> unread<!--{/if}-->" style="margin: 0;padding: .55rem;">
						<!--{if $do=='following'}-->
							<div class="gg-kj-thycz">
							<!--{if $viewself}-->
								<a id="a_followmod_{$fuser['followuid']}" 
								href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['followuid']" 
								class="followmod_$fuser['followuid'] dialog zy-c bk-c bg-e"
								ck-cus="true"
								ck-confirm="false"
								ck-param="{type:'modal',callpar:{fuid:'$fuser['followuid']'},fn:'MsgCallFeedli',load:'true',uid:'{$_G[uid]}'}" 
								external >{lang guiigo_manage:tlang0003}</a>
							<!--{elseif $fuser[followuid] != $_G[uid]}-->
								<!--{if $fuser['mutual']}-->
									<a id="a_followmod_{$fuser['followuid']}" 
									href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['followuid']" 
									class="followmod_$fuser['followuid'] dialog zy-c bk-c bg-e"
									ck-cus="true"
									ck-confirm="false"
									ck-param="{type:'modal',callpar:{fuid:'$fuser['followuid']'},fn:'MsgCallFeedli',load:'true',uid:'{$_G[uid]}'}" 
									external >{lang guiigo_manage:tlang0003}</a>
								<!--{else}-->
									<a id="a_followmod_{$fuser['followuid']}" 
									href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['followuid']" 
									class="followmod_$fuser['followuid'] dialog zy-b bk-b"
									ck-cus="true"
									ck-confirm="false"
									ck-param="{type:'modal',callpar:{fuid:'$fuser['followuid']'},fn:'MsgCallFeedli',load:'true',uid:'{$_G[uid]}'}" 
									external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
								<!--{/if}-->
							<!--{/if}-->
							</div>
							<div class="bkys-bkico bkys-bkicoy bkys-fshg">
								<a href="home.php?mod=space&uid=$fuser['followuid']&do=profile">
									<!--{avatar($fuser['followuid'],middle)}-->
								</a>
								<!--{if $fuser['mutual'] > 0}--><i class="icon guiigoapp-huguan bg-d zy-a"></i><!--{/if}-->
							</div>
							<a href="home.php?mod=space&uid=$fuser['followuid']&do=profile" class="bkys-bkmc zy-e">$fuser['fusername']</a>
							<p class="zy-g">
								{lang guiigo_manage:tlang0041}: <a href="home.php?mod=follow&do=follower&uid=$fuser['followuid']"><em class="zy-c" id="followernum_$fuser['followuid']"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($memberinfo[$fuid]['follower'])}--><!--{else}-->$memberinfo[$fuid]['follower']<!--{/if}--></em></a> &nbsp;
								{lang guiigo_manage:tlang0002}: <a href="home.php?mod=follow&do=following&uid=$fuser['followuid']"><em class="zy-c"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($memberinfo[$fuid]['following'])}--><!--{else}-->$memberinfo[$fuid]['following']<!--{/if}--></em></a>
							</p>
						<!--{else}-->
							<!--{if $fuser[uid] != $_G[uid]}-->
							<div class="gg-kj-thycz">
								<!--{if $fuser['mutual']}-->
									<a id="a_followmod_{$fuser['uid']}" 
									href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['uid']" 
									class="followmod_$fuser['uid'] dialog zy-c bk-c bg-e"
									ck-cus="true"
									ck-confirm="false"
									ck-param="{type:'modal',callpar:{fuid:'$fuser['uid']'},fn:'MsgCallFeedli',load:'true',uid:'{$_G[uid]}'}" 
									external >{lang guiigo_manage:tlang0003}</a>
								<!--{else}-->
									<a id="a_followmod_{$fuser['uid']}" 
									href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['uid']" 
									class="followmod_$fuser['uid'] dialog zy-b bk-b"
									ck-cus="true"
									ck-confirm="false"
									ck-param="{type:'modal',callpar:{fuid:'$fuser['uid']'},fn:'MsgCallFeedli',load:'true',uid:'{$_G[uid]}'}" 
									external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
								<!--{/if}-->
							</div>
							<!--{/if}-->
							<div class="bkys-bkico bkys-bkicoy bkys-fshg">
								<a href="home.php?mod=space&uid=$fuser['uid']&do=profile">
									<!--{avatar($fuser['uid'],middle)}-->
								</a>
								<!--{if $fuser['mutual'] > 0}--><i class="icon guiigoapp-huguan bg-d zy-a"></i><!--{/if}-->
							</div>
							<a href="home.php?mod=space&uid=$fuser['uid']&do=profile" class="bkys-bkmc zy-e">$fuser['username']</a>
							<p class="zy-g">
								{lang guiigo_manage:tlang0041}: <a href="home.php?mod=follow&do=follower&uid=$fuser['uid']"><em class="zy-c" id="followernum_$fuser['uid']"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($memberinfo[$fuid]['follower'])}--><!--{else}-->$memberinfo[$fuid]['follower']<!--{/if}--> </em></a> &nbsp;
								{lang guiigo_manage:tlang0002}: <a href="home.php?mod=follow&do=following&uid=$fuser['uid']"><em class="zy-c"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($memberinfo[$fuid]['following'])}--><!--{else}-->$memberinfo[$fuid]['following']<!--{/if}--> </em></a>
							</p>
						<!--{/if}-->
						</li>
					<!--{/loop}-->
					</ul>
				</div>
				<!--{if $list}-->
					<!--{if !empty($multi)}-->
						<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
							<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
						</div>
						<div onclick="infinite('#fuser-page')" class="loadpage bg-c bk-e zy-c">{lang guiigo_manage:tlang0492}<i class="icon guiigoapp-ssxx zy-c"></i></div>
					<!--{/if}-->
				<!--{/if}-->
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">
							<!--{if $viewself}-->
								<!--{if $do=='following'}-->
									{lang guiigo_manage:tlang0028}
								<!--{else}-->
									{lang guiigo_manage:tlang0029}
								<!--{/if}-->
							<!--{else}-->
								<!--{if $do=='following'}-->
									{lang guiigo_manage:tlang0030}
								<!--{else}-->
									{lang guiigo_manage:tlang0031}
								<!--{/if}-->
							<!--{/if}-->
						</p>
					</div>
				<!--{/if}-->
			<!--{else}-->
				<div class="guiigo-wnrtx">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang guiigo_manage:tlang0493}</p>
					<!--{if $_G['adminid'] == 1 }--><a href="admin.php" class="ab-az zy-a zy-ac">{lang guiigo_manage:tlang0494}</a><!--{/if}-->
				</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript">
		function MsgCallFeedli(msg,par,param) {
			if(typeof msg === 'object' || typeof par === 'object'){
				var Obj = $('.followmod_'+ par.fuid +'');
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
					$.toast('{lang guiigo_manage:tlang0003}')
					Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&fuid='+ par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
					Obj.attr('ck-confirm','true')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
					$.toast('{lang guiigo_manage:tlang0009}')
					Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+ par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
					Obj.attr('ck-confirm','false')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
					$.toast('{lang guiigo_manage:tlang0007}');
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				$.toast('{lang guiigo_manage:tlang0056}');
			}
		}
	</script>
</div>
<!--{template common/footer}-->
