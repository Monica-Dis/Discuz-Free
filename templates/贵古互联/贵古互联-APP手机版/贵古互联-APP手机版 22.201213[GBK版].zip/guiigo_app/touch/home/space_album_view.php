<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['home_tpl_titles'] = array($album['albumname'], '{lang album}');}-->
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-album-view">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<!--{if $album[albumid]>0}-->
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-f" style="font-size: 1rem;"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h"><!--{echo cutstr($space[username],16)}-->{lang guiigo_manage:tlang0668}</h1>
	</header>
	<div class="content">
		<div class="list-block bg-c gg-jxbg">
			<!--{if $album[albumid]>0}-->
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<!--{if $space[self] || ($_G[uid] == $album[uid] || checkperm('managealbum')) && $album[albumid] > 0}-->
							<a href="javascript:;" class="zy-f xh-b" onclick="app.ActionsManage('#guiigo-lcgl-lzgl','t', 'auto');"><i class="icon guiigoapp-kjzlbj zy-f"></i>{lang guiigo_manage:tlang0988}</a>
						<!--{/if}-->
						<!--{if helper_access::check_module('album')}-->
							<!--{if $_G[uid] == $album[uid]}-->
							<li><a href="home.php?mod=spacecp&ac=upload" class="zy-f xh-b" data-no-cache="true"><i class="icon guiigoapp-xiangji4"></i>{lang guiigo_manage:tlang0262}</a></li>
							<!--{/if}-->
						<!--{/if}-->
						<!--{if $guiigo_config['isguiigoapp']}-->
						<li><a href="javascript:;" onclick="appShareAllview('#share_title','#share_img','#share_introduce');" class="zy-f xh-b"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						<!--{else}-->
						<li><a href="javascript:;" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');" class="zy-f xh-b"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						<!--{/if}-->
						<li><a href="home.php?mod=spacecp&ac=favorite&type=album&id=$album[albumid]&spaceuid=$space[uid]&handlekey=sharealbumhk_{$album[albumid]}" id="a_favorite" class="zy-f{if $_G[uid] != $album[uid]} xh-b{/if} dialog"
						ck-cus="true"
						ck-param="{type:'modal',callpar:{},fn:'MsgCallAlbsc',load:'true',uid: '$_G[uid]'}" 
						external ><i class="icon guiigoapp-tbxhsc"></i>{lang guiigo_manage:tlang0672}</a></li>
						<!--{if $_G[uid] != $album[uid]}-->
						<li><a href="misc.php?mod=report&rtype=album&uid=$album[uid]&rid=$album[albumid]" 
							class="blue-inner dialog zy-f" 
							ck-cus="true" 
							ck-param="{type:'modal',load:'true',uid:'$_G[uid]',fn:'MsgCallReport'}"
							external ><i class="icon guiigoapp-tbxhjb"></i>{lang guiigo_manage:tlang0673}</a>
						</li>
						<!--{/if}-->
					</ul>
				</div>
			</div>
			<!--{/if}-->
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="popup-actions" id="guiigo-nrdbfx">
				<div class="actions-text guiigo-hdfx">
					<div class="gg-app-hide hdfx-hdxm xh-b bg-e">
						<a href="javascript:;"  data-app="weixin" class="nativeShare weixin zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wx.png" class="vm"></span>{lang guiigo_manage:tlang0153}</a>
						<a href="javascript:;" data-app="weixinFriend" class="nativeShare weixin_timeline zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/pyq.png" class="vm"></span>{lang guiigo_manage:tlang0154}</a>
						<a href="javascript:;" data-app="QQ" class="nativeShare qq zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/qq.png" class="vm"></span>{lang guiigo_manage:tlang0155}</a>
						<a href="javascript:;" data-app="QZone" class="nativeShare qzone zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kj.png" class="vm"></span>{lang guiigo_manage:tlang0156}</a>
						<a href="javascript:;" data-app="sinaWeibo" class="nativeShare weibo zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wb.png" class="vm"></span>{lang guiigo_manage:tlang0157}</a>
					</div>
					<div class="gg-app-show hdfx-xcxt xh-b bg-e">
						<span class="icon guiigoapp-xiaochengxu"></span>
						<h2>{lang guiigo_manage:tlang1002}</h2>
						<p>{lang guiigo_manage:tlang1003}</p>
					</div>
					<div class="hdfx-hdxm bg-e">
						<a href="javascript:;" class="zy-f zd-12" onclick="copy(this);" id="cptextid"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/fz.png" class="vm"></span>{lang guiigo_manage:tlang0158}</a>
					</div>
					<a href="javascript:;" class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</a>
				</div>
			</div>
			<div class="share-layer"></div>
			<div class="popup-actions" id="guiigo-lcgl-lzgl">
				<div class="actions-text guiigo-hdfx">
					<div class="hdfx-glxm hdfx-glxmh list-block-no bg-e">
						<ul>
							<!--{if $space[self]}-->
							<!--{if $album[albumid] > 0}--><li class="bg-c"><a href="home.php?mod=spacecp&ac=album&op=edit&albumid=$album[albumid]" class="zy-h sh-a">{lang guiigo_manage:tlang0674}</a></li><!--{/if}-->
							<li class="bg-c"><a href="{if $album[albumid] > 0}home.php?mod=spacecp&ac=album&op=editpic&albumid=$album[albumid]{else}home.php?mod=spacecp&ac=album&op=editpic&albumid=0{/if}" class="zy-h sh-a">{lang guiigo_manage:tlang0675}</a></li>
							<!--{/if}-->
							<!--{if ($_G[uid] == $album[uid] || checkperm('managealbum')) && $album[albumid] > 0}-->
							<li class="bg-c xh-b"><a href="home.php?mod=spacecp&ac=album&op=delete&albumid=$album[albumid]&uid=$album[uid]&handlekey=delalbumhk_{$album[albumid]}" id="album_delete_$album[albumid]" class="zy-h sh-a dialog"
							ck-cus="true"
							ck-param="{type:'modal',callpar:{aid:'$album[albumid]'},fn:'MsgCallAlbum',load:'true',uid: '$_G[uid]'}" 
							external >{lang guiigo_manage:tlang0676}</a></li>
							<!--{/if}-->
						</ul>
					</div>
					<a href="javascript:;" class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</a>
				</div>
			</div>
			<div class="gg-kj-xcxx xh-b">
				<h2 class="zy-e"><!--{if $album[picnum]}--><span class="zy-c">{lang total} $album[picnum] {lang album_pics}</span><!--{/if}-->$album[albumname]</h2>
				<!--{if $album[depict]}--><p id="share_introduce" class="zy-c">$album[depict]</p><!--{/if}-->
			</div>
			<div id="share_title" style="display: none;">$album[albumname] - {lang guiigo_manage:tlang0979}</div>
			<!--{if $list}-->
				<div id="waterfall" class="list-container gg-sq-pbly ms-a">
				<!--{loop $list $key $value}-->
					<div class="ck8-water-items mx-b" ck-cus="water">
						<div id="share_img" class="pic">
							<!--{if $value[pic]}-->
							<img lazySrc="{eval echo str_replace('.thumb.jpg','',$value['pic'])}" 
								src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" 
								class="ck8-lazy vimg_5 vm gg-tpsb"
								data-fid="waterfall" 
								data-mid="5" 
								onclick="albumpreviewImg(this);"/>
							<!--{/if}-->
						</div>
					</div>
				<!--{/loop}-->
				</div>
				<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
			<!--{else}-->
				<div class="guiigo-wnrtx px-a">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c"><!--{if !$pricount}-->{lang no_pics}<!--{/if}--><!--{if $pricount}-->{lang hide_pic}<!--{/if}--></p>
				</div>
			<!--{/if}-->
			<!--{if $albumlist}-->
			<div class="gg-kj-qtxc">
				<div class="qtxc-btys xh-b zy-b"><i class="icon guiigoapp-clxiangce"></i><!--{echo cutstr($space[username],16)}-->{lang guiigo_manage:tlang0677}{lang switch_pics}</div>
				<div id="pnv" class="gg-kj-amzt">
					<!--{if $albumlist}-->	
					<!--{loop $albumlist $key $albums}-->
					<div class="amzt-yssz list-block-no bg-c">
						<ul>
							<!--{loop $albums $akey $value}-->
							<!--{eval $pwdkey = 'view_pwd_album_'.$value['albumid'];}-->
							<li>
								<a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" title="$value[albumname]">
									<!--{if $value[pic]}--><img src="$value[pic]" alt="$value[albumname]"><!--{/if}-->
									<!--{if $value[picnum]}--><span class="amzt-xcsl zy-a"><i class="icon guiigoapp-tupian zy-a"></i>$value[picnum]</span><!--{/if}-->
									<span class="amzt-xcmc">$value[albumname]</span>
								</a>
							</li>
							<!--{/loop}-->
						</ul>
					</div>
					<!--{/loop}-->
					<!--{/if}-->
				</div>
			</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
<script>
ck8(function(){
	if(ck8('#focbtn').length > 0){
		ck8('#focbtn').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('#rewardbut').length > 0){
		ck8('#rewardbut').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('.debatereply').length > 0){
		ck8('.debatereply').click(function(e){
			Dz('needmessage').focus()
		})
	}
})

function albumpreviewImg(obj){
	app.loadScript('potextend',function(e){
		var items = [], fid = ck8(obj).attr('data-fid'),mid = ck8(obj).attr('data-mid');
		items = [{url : ck8(obj).attr('src'), caption : ck8(obj).attr('title')}];
		ck8('#'+ fid).addClass('lazy_'+fid);
		ck8('.lazy_'+fid).find('.vimg_'+mid).each(function(index,obj){
			var url = obj.getAttribute('src');
			if(url.indexOf('lazy') != -1 || url.indexOf('tpljz') != -1){
				url = obj.getAttribute('lazySrc');
			}
			var imgObj = {url : url, caption : ''};
			items.push(imgObj);
		})
		ck8('#'+fid).removeClass('lazy_'+fid);
		ck8.photoBrowser({
			photos : items,
			theme: 'dark',
			type: 'standalone',
			toolbarTemplate: '',
		}).open();
	})
}

function ShareAllalbum(){
	//�õ���������
		var config = getShareData('#share_title','#share_img','#share_introduce');
	<!--{if ($guiigo_config['browser']['isqq'] || $guiigo_config['browser']['isuc']) && !$guiigo_config['browser']['iswx']}-->
		//����� UC qq �����
		nativeShare(config);
	<!--{elseif $guiigo_config['browser']['iswx']}-->
		//�����΢�������
		wxshareJssdkAjax(config)
	<!--{else}-->
		//������� ΢������� UC qq �����
		webShare(config)
	<!--{/if}-->
}

function MsgCallAlbsc(msg,par){
	if(typeof msg == 'object' || typeof par == 'object'){
		if(msg.msg.indexOf('{lang guiigo_manage:tlang0014}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0177}','chenggong')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0015}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0678}','shibai')
		}else{
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}
</script>
</div>
<!--{template common/footer}-->
