<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $tasklist}-->
	<div class="gg-sq-tayc list-block-no ms-a sh-a xh-b bg-c">
		<ul>
			<!--{loop $tasklist $task}-->
			<li id="taskli-$task[taskid]" class="xh-a">
				<!--{if $_GET['item'] == 'new'}-->
					<span style="padding:0;">
					<!--{if $task['noperm']}-->
						<a href="javascript:;" class="bg-i zy-a" onclick="ck8.alert('{lang task_group_nopermission}')">{lang guiigo_manage:tlang0035}</a>
					<!--{elseif $task['appliesfull']}-->
						<a href="javascript:;" class="bg-i zy-a" onclick="ck8.alert('{lang task_applies_full}')">{lang guiigo_manage:tlang0035}</a>
					<!--{else}-->
						<a href="home.php?mod=task&do=apply&id=$task[taskid]" 
						class="dialog bg-h zy-a zy-ac"
						ck-cus="true" 
						ck-param="{type:'modal',load:'true',callpar:{rid:'$task[taskid]',type:'applytask'},fn:'MsgCallTasklist',uid:'$_G[uid]'}"
						external>{lang guiigo_manage:tlang0035}</a>
					<!--{/if}-->
					</span>
				<!--{elseif $_GET['item'] == 'doing'}-->
					<span style="padding:0;"><a class="{if $task[csc] >=100}bg-h zy-a zy-ac{else}bg-i zy-a{/if}" href="javascript:;"{if $task[csc] >=100} data-href="home.php?mod=task&do=draw&id=$task[taskid]" onclick="coutomAjaxGet(this)" external{else} onclick="ck8.toast('{lang guiigo_manage:tlang0036}')"{/if}>{lang guiigo_manage:tlang0037}</a></span>
					<script>
						function coutomAjaxGet(obj){
							ck8.showPreloader('','load');
							ck8.ajax({
								type : 'GET',
								url : ck8(obj).attr('data-href') + '&inajax=1',
								dataType : 'xml',
								success: function(s){
									setTimeout(function(){ck8.hidePreloader()}, 100);
									s = s.lastChild.firstChild.nodeValue;
									var msg = '';
									if(s){
										msg = s.split('|')[1]
									}
									if(msg = 'task_reward_credit'){
										msg = '{lang guiigo_manage:tlang0038}'
									}
									app.PageRefresh(false,'gg-kj-rwzt','home.php?mod=task&item=doing')
									popup.open(msg);
								},
								error: function(){
									ck8.hidePreloader();
									ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
								}
							})
						}
					</script>	
				<!--{/if}-->
				<div class="bkys-bkico">
					<img src="$task[icon]" alt="$task[name]" />
				</div>
				<a href="home.php?mod=task&do=view&id=$task[taskid]" class="bkys-bkmc zy-e"><i>$task[name]</i><em class="zy-c bg-g">$task[applicants]</em></a>
				<p class="zy-g">
					<!--{if $_GET['item'] == 'doing'}-->
						{lang task_complete}: $task[csc]%
					<!--{elseif $_GET['item'] == 'done'}-->
						{lang task_complete_on}$task[dateline]<!--{if $task['period'] && $task[t]}--><!--{if $task[allowapply]}-->, <a href="home.php?mod=task&do=apply&id=$task[taskid]">{lang task_applyagain_now}</a><!--{else}-->, {$task[t]}{lang task_applyagain}<!--{/if}--><!--{/if}-->
					<!--{elseif $_GET['item'] == 'failed'}-->
						{lang task_lose_on}$task[dateline]<!--{if $task['period'] && $task[t]}--><!--{if $task[allowapply]}-->, <a href="home.php?mod=task&do=apply&id=$task[taskid]">{lang task_applyagain_now}</a><!--{else}-->, {$task[t]}{lang task_reapply}<!--{/if}--><!--{/if}-->
					<!--{else}-->
						<!--{if $task['reward'] == 'credit'}-->
							{lang credits} $_G['setting']['extcredits'][$task[prize]][title] $task[bonus] $_G['setting']['extcredits'][$task[prize]][unit]
						<!--{elseif $task['reward'] == 'magic'}-->
							{lang magics_title} $listdata[$task[prize]] $task[bonus] {lang magics_unit}
						<!--{elseif $task['reward'] == 'medal'}-->
							{lang medals} $listdata[$task[prize]] <!--{if $task['bonus']}-->{lang expire} $task[bonus] {lang days} <!--{/if}-->
						<!--{elseif $task['reward'] == 'invite'}-->
							{lang invite_code} $task[prize] {lang expire} $task[bonus] {lang days}
						<!--{elseif $task['reward'] == 'group'}-->
							{lang usergroup} $listdata[$task[prize]] <!--{if $task['bonus']}--> $task[bonus] {lang days} <!--{/if}-->
						<!--{/if}-->
					<!--{/if}-->
				</p>
			</li>
			<!--{/loop}-->
		</ul>
	</div>
<!--{else}-->
	<div class="guiigo-wnrtx">
		<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
		<p class="zy-c"><!--{if $_GET['item'] == 'new'}-->{lang guiigo_manage:tlang0032}<!--{elseif $_GET['item'] == 'doing'}-->{lang guiigo_manage:tlang0033}<!--{else}-->{lang guiigo_manage:tlang0034}<!--{/if}--></p>
	</div>
<!--{/if}-->
