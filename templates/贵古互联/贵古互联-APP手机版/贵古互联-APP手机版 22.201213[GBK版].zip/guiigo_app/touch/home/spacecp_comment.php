<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $_GET['op'] == 'edit'}-->
	<form id="editcommentform_{$cid}" name="editcommentform_{$cid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment&op=edit&cid=$cid{if $_GET[modcommentkey]}&modcommentkey=$_GET[modcommentkey]{/if}"
	ck-cus="true"
	ck-param="{type:'modal',callpar:{liid:'{$cid}',type:'bianji'},fn:'MsgCallwzplx',load:'true',uid:'$_G[uid]'}">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="c">
			<textarea id="message_{$cid}" name="message" cols="70" rows="8" class="guiigo-pt bg-e bk-e pq-a" style="height: 5rem;margin-top: -1.1rem;margin-bottom: -1rem;">$comment[message]</textarea>
		</div>
	</form>
	<script type="text/javascript">
		function succeedhandle_$_GET['handlekey'] (url, message, values) {
			comment_edit(values['cid']);
		}
	</script>
<!--{elseif $_GET['op'] == 'delete'}-->
	<form id="deletecommentform_{$cid}" name="deletecommentform_{$cid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment&op=delete&cid=$cid"
	ck-cus="true"
	ck-param="{type:'modal',callpar:{liid:'{$cid}',type:'shanchu'},fn:'MsgCallwzplx',load:'true',uid:'$_G[uid]'}">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="c">{lang guiigo_manage:tlang0332}</div>
	</form>
	<script type="text/javascript">
		function succeedhandle_$_GET['handlekey'] (url, message, values) {
			comment_delete(values['cid']);
		}
	</script>
<!--{elseif $_GET['op'] == 'reply'}-->
	<form id="replycommentform_{$comment[cid]}" name="replycommentform_{$comment[cid]}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment"
	ck-cus="true"
	ck-param="{type:'modal',callpar:{liid:'{$cid}',type:'huifu'},fn:'MsgCallwzplx',load:'true',uid:'$_G[uid]'}">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="id" value="$comment[id]" />
		<input type="hidden" name="idtype" value="$comment[idtype]" />
		<input type="hidden" name="cid" value="$comment[cid]" />
		<input type="hidden" name="commentsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div id="reply_msg_{$comment[cid]}">
			<div class="c">
				<textarea id="message_pop_{$comment[cid]}" name="message" rows="8" cols="70" class="guiigo-pt bg-e bk-e pq-a" style="height: 2rem;margin-top: -1rem;margin-bottom: -1rem;"></textarea>
				<!--{if $secqaacheck || $seccodecheck}-->
					<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu({'ctrlid':this.id,'win':'{$_GET[handlekey]}'});"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
					<div class="gg-qj-tcyz bk-e"><!--{subtemplate common/seccheck}--></div>
				<!--{/if}-->
			</div>
		</div>
	</form>
<!--{/if}-->
<!--{template common/footer}-->
