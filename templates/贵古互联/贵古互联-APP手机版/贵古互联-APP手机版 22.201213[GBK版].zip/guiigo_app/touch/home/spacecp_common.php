<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $_GET['op'] == 'ignore'}-->
	<form method="post" autocomplete="off" id="ignoreform_{$formid}" 
	name="ignoreform_{$formid}" 
	action="home.php?mod=spacecp&ac=common&op=ignore&type=$type" 
	ck-cus="true"
	ck-param="{type:'modal',callpar:{type:'$_GET['op']'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}">
		<input type="hidden" name="handlekey" value="$_GET[handlekey]" />
		<input type="hidden" name="ignoresubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="referer" value="{echo dreferer()}">
		<div class="gg-xx-pbtz">
			<p>{lang guiigo_manage:tlang0542}</p>
			<p class="zkz"><label class="guiigo-pds"><input type="radio" name="authorid" id="authorid1" class="guiigo-pd-k" value="$_GET[authorid]" checked="checked" /><span></span>{lang shield_this_friend}</label></p>
			<p class="zkz"><label class="guiigo-pds"><input type="radio" name="authorid" id="authorid0" class="guiigo-pd-k" value="0" /><span></span>{lang shield_all_friend}</label></p>
		</div>
	</form>
<!--{elseif $_GET['op']=='modifyunitprice'}-->
	<h3 class="flb">
		<em id="return_$_GET[handlekey]">{lang modify_unitprice}</em>
		<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
	</h3>
	<form method="post" autocomplete="off" id="ignoreform_{$formid}" name="ignoreform_{$formid}" action="home.php?mod=spacecp&ac=common&op=modifyunitprice" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="modifysubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="referer" value="{echo dreferer()}">
		<div class="c altw">
			<p>{lang modify_unitprice_note}</p>
			<p class="ptn"><label>{lang bid_single_price}: <input type="text" name="unitprice" class="px" value="$showinfo[unitprice]" /></label></p>
		</div>
		<p class="o pns">
			<button type="submit" name="unitpriceysubmit" value="true" class="pn pnc"><strong>{lang determine}</strong></button>
		</p>
	</form>
	<script type="text/javascript">
		function succeedhandle_$_GET['handlekey'] (url, message, values) {
			var priceObj = $('show_unitprice');
			if(priceObj) {
				priceObj.innerHTML = values['unitprice'];
			}

		}
	</script>
<!--{/if}-->
<!--{template common/footer}-->
