<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if count($list)-1 == $key && empty($lastanchor)}--><a name="last"></a><!--{eval $lastanchor=1;}--><!--{/if}-->
<!--{if $value[msgfromid] != $_G['uid']}-->
<div id="pmlist_$value[pmid]" class="xxnr-dfxx cl pmlistno">
	<div class="xxnr-yhtx"><a href="home.php?mod=space&uid=$value[msgfromid]&do=profile" class="guiigo-ty"><img src="<!--{avatar($value[msgfromid], middle, true)}-->" /></a></div>
	<div class="xxnr-xxlb">
		<div class="xxnr-xxlb-a bg-c zy-h"<!--{if $value['pmtype'] == 1 || $value['authorid'] && $value['authorid'] != $_G['uid'] && $_G['setting']['pmreportuser']}--> onclick="showMn('#pop_$value[pmid]');"<!--{/if}-->>$value[message]</div>
		<!--{if $value['pmtype'] == 1 || $value['authorid'] && $value['authorid'] != $_G['uid'] && $_G['setting']['pmreportuser']}-->
		<div id="pop_$value[pmid]" class="xxnr-xxsj list-block-no bg-r pmlistmn" style="display:none;" onclick="showMn('#pop_$value[pmid]');">
			<ul>
				<!--{if $value['pmtype'] == 1}-->
					<li class="xh-e"><a href="home.php?mod=spacecp&ac=pm&op=delete&deletepm_pmid[]=$value[pmid]&touid=$touid&deletesubmit=1&handlekey=pmdeletehk_{$value[pmid]}&formhash={FORMHASH}" class="dialog zy-a" 
					ck-confirm="true"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pmid:'$value[pmid]',type:'deletepm'},fn:'MsgCallPm',load:'true',uid:'$_G[uid]',msg: '{lang guiigo_manage:tlang0761}'}"  
					external >{lang delete}</a></li>
				<!--{/if}-->
				<!--{if $value['authorid'] && $value['authorid'] != $_G['uid'] && $_G['setting']['pmreportuser']}-->
					<li><a href="home.php?mod=spacecp&ac=pm&op=pm_report&pmid=$value[pmid]&handlekey=pmreporthk_{$value[pmid]}" 
					class="zy-a dialog"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pmid:'$value[pmid]',type:'pm_report'},fn:'MsgCallPm',load:'true',uid:'$_G[uid]',cancel:'{lang guiigo_manage:tlang0105}',confirm:'{lang guiigo_manage:tlang0106}'}"  
					external>{lang pmreport}</a></li>
				<!--{/if}-->
			</ul>
		</div>
		<!--{/if}-->
		<div class="xxnr-xxlb-s zy-g"><!--{date($value[dateline], 'u')}--></div>
	</div>
</div>
<!--{else}-->
	<div id="pmlist_$value[pmid]" class="xxnr-wdxx cl pmlistno">
		<div class="xxnr-yhtx guiigo-ty"><img src="<!--{avatar($value[msgfromid], middle, true)}-->" /></div>
		<div class="xxnr-xxlb">
			<div class="xxnr-xxlb-a bg-q zy-h"<!--{if $value['pmtype'] == 1 || $value['authorid'] && $value['authorid'] != $_G['uid'] && $_G['setting']['pmreportuser']}--> onclick="showMn('#pop_$value[pmid]');"<!--{/if}-->>
			<!--{eval echo GuiigoApp::feedFace($value[message]);}-->
			</div>
			<!--{if $value['pmtype'] == 1 || $value['authorid'] && $value['authorid'] != $_G['uid'] && $_G['setting']['pmreportuser']}-->
			<div id="pop_$value[pmid]" class="xxnr-xxsj list-block-no bg-r pmlistmn" style="display:none;" onclick="showMn('#pop_$value[pmid]');">
				<ul>
					<!--{if $value['pmtype'] == 1}-->
						<li class="xh-e"><a href="home.php?mod=spacecp&ac=pm&op=delete&deletepm_pmid[]=$value[pmid]&touid=$touid&deletesubmit=1&handlekey=pmdeletehk_{$value[pmid]}&formhash={FORMHASH}" class="dialog zy-a" 
						ck-confirm="true"
						ck-cus="true"
						ck-param="{type:'modal',callpar:{pmid:'$value[pmid]',type:'deletepm'},fn:'MsgCallPm',load:'true',uid:'$_G[uid]',msg: '{lang guiigo_manage:tlang0761}'}"  
						external >{lang delete}</a></li>
					<!--{/if}-->
				</ul>
			</div>
			<!--{/if}-->
			<div class="xxnr-xxlb-s zy-g"><!--{date($value[dateline], 'u')}--></div>
		</div>
	</div>
<!--{/if}-->
