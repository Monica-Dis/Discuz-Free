<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $isfirstpost && $sortid}-->
<script type="text/javascript">
	var forum_optionlist_obj = new Object();
	var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
	$(function(){
		app.loadScript('threadsort', function(e) {
			var xml = new xmlobj();
			var xmlpar = xml.createXMLDoc(forum_optionlist);
			xml.xml2json(forum_optionlist_obj, xmlpar);
		})
	})
</script>
<!--{/if}-->
<input type="hidden" name="selectsortid" size="45" value="$_G['forum_selectsortid']" />
<!--{loop $_G['forum_optionlist'] $optionid $option}-->
	<!--{if in_array($option['type'], array('radio', 'checkbox', 'textarea'))}-->
		<li class="wblb-dkbt bg-g xh-b zy-c cl"><span id="check{$option[identifier]}"></span>$option[title]<!--{if $option['required']}--> <span class="zy-i">*</span><!--{/if}--></li>
	<!--{else}-->
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><span id="check{$option[identifier]}"></span>$option[title]<!--{if $option['required']}--> <span class="zy-i">*</span><!--{/if}--></div>
	<!--{/if}-->
	<!--{if in_array($option['type'], array('number', 'text', 'email', 'calendar', 'image', 'url', 'range', 'upload', 'range'))}-->
		<!--{if $option['type'] == 'calendar'}-->
				<div id="select_$option[identifier]" class="wblb-wbnr zy-h">
					<input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" tabindex="1" size="$option[inputsize]" value="$option[value]" $option[unchangeable] class="guiigo-px s-a" <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->placeholder="<!--{if $option['maxnum']}-->{lang maxnum} $option[maxnum]<!--{/if}--><!--{if $option['minnum']}-->{lang minnum} $option[minnum]<!--{/if}--><!--{if $option['maxlength']}-->{lang maxlength} $option[maxlength]<!--{/if}--><!--{if $option['unchangeable']}-->{lang unchangeable}<!--{/if}--><!--{if $option[description]}-->$option[description]<!--{/if}-->"<!--{/if}-->/>
				</div>
				<div class="wblb-wbdw zy-g">$option[unit]</div>
				<script type="text/javascript" reload="1">
					ck8(function(){
						$("#typeoption_$option[identifier]").calendar({
						});
					})
				</script>
			</li>
		<!--{elseif $option['type'] == 'image'}-->
			<!--{if !($option[unchangeable] && $option['value'])}-->
				<div id="select_$option[identifier]" class="wblb-wbnr zy-h">
					<button type="button" class="guiigo-pn wbnr-flim bg-e bk-e zy-c" onclick="uploadWindow(function (aid, url){sortaid_{$option[identifier]}_upload(aid, url)})"><i class="icon guiigoapp-tupian zy-f"></i><!--{if $option['value']}-->{lang guiigo_manage:tlang0261}<!--{else}-->{lang guiigo_manage:tlang0262}<!--{/if}--></button>
					<input type="hidden" name="typeoption[{$option[identifier]}][aid]" value="$option[value][aid]" id="sortaid_{$option[identifier]}" />
					<input type="hidden" name="sortaid_{$option[identifier]}_url" id="sortaid_{$option[identifier]}_url" />
					<!--{if $option[value]}--><input type="hidden" name="oldsortaid[{$option[identifier]}]" value="$option[value][aid]" tabindex="1" /><!--{/if}-->
					<input type="hidden" name="typeoption[{$option[identifier]}][url]" id="sortattachurl_{$option[identifier]}" {if $option[value][url]}value="$option[value][url]"{/if} tabindex="1" />
					<!--{/if}-->
					<div id="sortattach_image_{$option[identifier]}" class="wbnr-fimz">
					<!--{if $option['value']['url']}-->
						<a href="$option[value][url]" target="_blank"><img class="spimg" src="$option[value][url]" alt="" /></a>
					<!--{/if}-->
					</div>
					<script type="text/javascript" reload="1">
						function sortaid_{$option[identifier]}_upload(aid, url) {
							Dz('sortaid_{$option[identifier]}_url').value = url;
							updatesortattach(aid, url, '{$_G['setting']['attachurl']}forum', '{$option[identifier]}');
						}
					</script>
				</div>
			</li>
		<!--{else}-->
				<div id="select_$option[identifier]" class="wblb-wbnr zy-h">
					<input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="guiigo-px s-a" tabindex="1" size="$option[inputsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]'{if $option[maxnum]}, '$option[maxnum]'{else}, '0'{/if}{if $option[minnum]}, '$option[minnum]'{else}, '0'{/if}{if $option[maxlength]}, '$option[maxlength]'{/if})" value="{if $_G['tid']}$option[value]{else}{if $member_profile[$option['profile']]}$member_profile[$option['profile']]{else}$option['defaultvalue']{/if}{/if}" $option[unchangeable] <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->placeholder="<!--{if $option['maxnum']}-->{lang maxnum} $option[maxnum]<!--{/if}--><!--{if $option['minnum']}-->{lang minnum} $option[minnum]<!--{/if}--><!--{if $option['maxlength']}-->{lang maxlength} $option[maxlength]<!--{/if}--><!--{if $option['unchangeable']}-->{lang unchangeable}<!--{/if}--><!--{if $option[description]}-->$option[description]<!--{/if}-->"<!--{/if}--> />
				</div>
				<div class="wblb-wbdw zy-g">$option[unit]</div>
			</li>
		<!--{/if}-->
	<!--{elseif in_array($option['type'], array('radio', 'checkbox', 'select'))}-->
		<!--{if $option[type] == 'select'}-->
			<!--{loop $option['value'] $selectedkey $selectedvalue}-->
				<!--{if $selectedkey}-->
					<div id="select_$option[identifier]" class="wblb-wbnr zy-h"></div>
					<script type="text/javascript">
					$(function(){
						setTimeout(function(){
							changeselectthreadsort('$selectedkey', $optionid, 'update');
						},500);
					})
					</script>
				<!--{else}-->
					<div id="select_$option[identifier]" class="wblb-wbnr zy-h">
						<select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable] class="guiigo-ps">
							<option value="0">{lang please_select}</option>
							<!--{loop $option['choices'] $id $value}-->
								<!--{if !$value[foptionid]}-->
								<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
								<!--{/if}-->
							<!--{/loop}-->
						</select>
					</div>
				</li>
				<!--{/if}-->
			<!--{/loop}-->
			<!--{if !is_array($option['value'])}-->
					<div id="select_$option[identifier]" class="wblb-wbnr zy-h">
						<select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable] class="guiigo-ps">
							<option value="0">{lang please_select}</option>
							<!--{loop $option['choices'] $id $value}-->
								<!--{if !$value[foptionid]}-->
								<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
								<!--{/if}-->
							<!--{/loop}-->
						</select>
					</div>
				</li>
			<!--{/if}-->
		<!--{elseif $option['type'] == 'radio'}-->
			<li class="wblb-nrsr xh-b zy-h cl">
				<div class="wblb-wbnr zy-h">
					<div class="gg-fb-dxpx">
					<!--{loop $option['choices'] $id $value}-->
						<label class="guiigo-pds"><input type="radio" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" class="guiigo-pd-k" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id] $option[unchangeable]><span></span>$value</label>
					<!--{/loop}-->
					</div>
				</div>
			</li>
		<!--{elseif $option['type'] == 'checkbox'}-->
			<li class="wblb-nrsr xh-b zy-h cl">
				<div class="wblb-wbnr zy-h">
					<div class="gg-fb-dxpx">
					<!--{loop $option['choices'] $id $value}-->
						<label class="guiigo-pd"><input type="checkbox" name="typeoption[{$option[identifier]}][]" id="typeoption_$option[identifier]" class="guiigo-pd-k" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id][$id] $option[unchangeable]><span></span>$value</label>
					<!--{/loop}-->
					</div>
				</div>
			</li>
		<!--{/if}-->
	<!--{elseif in_array($option['type'], array('textarea'))}-->
		<li class="wblb-nrsr xh-b zy-h cl">
			<div class="wblb-wbnr zy-h">
				<textarea name="typeoption[{$option[identifier]}]" tabindex="1" id="typeoption_$option[identifier]" rows="$option[rowsize]" cols="$option[colsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]', 0, 0{if $option[maxlength]}, '$option[maxlength]'{/if})" $option[unchangeable] class="guiigo-pt s-a" <!--{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}-->placeholder="<!--{if $option['maxnum']}-->{lang maxnum} $option[maxnum]<!--{/if}--><!--{if $option['minnum']}-->{lang minnum} $option[minnum]<!--{/if}--><!--{if $option['maxlength']}-->{lang maxlength} $option[maxlength]<!--{/if}--><!--{if $option['unchangeable']}-->{lang unchangeable}<!--{/if}--><!--{if $option[description]}-->$option[description]<!--{/if}-->"<!--{/if}-->>$option[value]</textarea>
			</div>
		</li>
	<!--{/if}-->
<!--{/loop}-->
<script type="text/javascript" reload="1">
	var CHECKALLSORT = false;
	function warning(obj, msg) {
		obj.style.display = '';
		obj.innerHTML = '<i class="icon guiigoapp-jinggao zy-i"></i>';
		obj.className = "gg-fl-wtjg";
		ck8.toast(msg,'shibai');
		if(CHECKALLSORT) {
			ck8.toast(msg,'shibai');
		}
	}

	EXTRAFUNC['validator']['special'] = 'validateextra';
	function validateextra() {
		CHECKALLSORT = true;
		<!--{loop $_G['forum_optionlist'] $optionid $option}-->
			if(!checkoption('$option[identifier]', '$option[required]', '$option[type]')) {
				return false;
			}
		<!--{/loop}-->
		return true;
	}
</script>

