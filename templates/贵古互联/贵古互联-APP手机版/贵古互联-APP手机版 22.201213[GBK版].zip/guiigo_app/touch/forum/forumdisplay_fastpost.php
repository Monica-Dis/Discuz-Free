<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="bar bar-rep list-block-no guiigo-tabs bg-c sh-a">
	<!--{if $_G[uid]}-->
		<!--{eval $favorite=GuiigoApp::getUserList($_G['uid'],'favorite','tid');}-->
	<!--{/if}-->
	<ul>
		<!--{if $guiigo_config['isguiigoapp']}-->
		<li><a href="javascript:;" onclick="appShareAllview('#share_title','#share_img','#share_img');"><i class="icon guiigoapp-nydbfx zy-e"></i></a></li>
		<!--{else}-->
		<li><a href="javascript:;" onclick="app.ActionsManage('.guiigo-nrdbfx-f','t', 'auto','guiigo-hdfx');"><i class="icon guiigoapp-nydbfx zy-e"></i></a></li>
		<!--{/if}-->
		<!--{eval $favid=$favorite[$_G[tid]][favid];}-->
		<!--{if $_G['uid'] && $_G['tid'] == $favorite[$_G['tid']]['id']}-->
			<!--{eval $favorurl="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favid&formhash=".FORMHASH."";}-->
			<!--{eval $favorclass='icon guiigoapp-nydbscon zy-m';}-->
		<!--{else}-->
			<!--{eval $favorurl="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash=".FORMHASH."";}-->
			<!--{eval $favorclass='icon guiigoapp-nydbsc zy-e';}-->
		<!--{/if}-->
		<li>
		<a href="$favorurl" class="dialog links" ck-cus="true" ck-param="{type:'modal',fn:'MsgCallFavor',load:'true',uid:'$_G['uid']'}" external>
			<i class="icon $favorclass"></i>
			<!--{if $guiigo_config['appsetting']['forumconfig']['show_favorite_data']}-->
				<span class="guiigo-yjsz bg-j zy-a" id="favoritenumber" {if !$_G['forum_thread']['favtimes']} style="display:none"{/if}>
				{$_G['forum_thread']['favtimes']}</span>
			<!--{else}-->
			<span class="guiigo-yjsz zy-a" id="favoritenumber" {if !$_G['forum_thread']['favtimes']} style="display:none"{/if}></span>
			<!--{/if}-->
		</a>
		</li>
		<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
			<!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
			<li>
			<!--{if $postlist[$firstpid]['isrecommenus'] ==1}-->
			    <a href="plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid=$_G[tid]" 
					class="{if !$_G['uid']}login {else} delRecommenus{/if} links" 
					ck-cus="true" 
					data-op="viewthread" 
					data-pid="$firstpid"
					ck-param="{type:'modal',callpar:{pid:'$firstpid'},fn:'MsgCallRecommendv',load:'true',uid:'$_G['uid']'}" external>
					<i class="icon guiigoapp-nydbdzon zy-i"></i>
					<!--{if $guiigo_config['appsetting']['forumconfig']['show_give_data']}-->
					<span class="guiigo-yjsz bg-j zy-a" id="recommendv_add_$firstpid" {if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>{$_G[forum_thread][recommend_add]}</span>
					<!--{/if}-->
				</a>
			<!--{else}-->
				<a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" 
					class="{if !$_G['uid']}login {else} dialog{/if} links" 
					ck-cus="true" 
					data-op="viewthread" 
					data-pid="$firstpid"
					ck-param="{type:'modal',callpar:{pid:'$firstpid'},fn:'MsgCallRecommendv',load:'true',uid:'$_G['uid']'}" external>
					<i class="icon guiigoapp-nydbdz zy-e"></i>
					<!--{if $guiigo_config['appsetting']['forumconfig']['show_give_data']}-->
					<span class="guiigo-yjsz bg-j zy-a" id="recommendv_add_$firstpid" {if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>{$_G[forum_thread][recommend_add]}</span>
					<!--{/if}-->
				</a>
			<!--{/if}-->
			</li>
			<!--{/if}-->
		<!--{/if}-->
		<li>
			<a href="javascript:;" onclick="scrollRely(this);" data-type="1"><i class="icon guiigoapp-nydbpl zy-e"></i>
			<!--{if $guiigo_config['appsetting']['forumconfig']['show_reply_data']}-->
				<span class="guiigo-yjsz bg-j zy-a plsl"{if $_G[forum_thread][allreplies] == 0 } style="display:none"{/if}>$_G[forum_thread][allreplies]</span>
			<!--{/if}-->
			</a>
		</li>
		<li class="tabs-hfys"><a href="javascript:;" class="{if !$_G[uid]}login {/if}bg-g zy-c" id="focbtn" <!--{if $_G[uid]}-->onclick="app.ActionsManage('#guiigo-hfdp','t','auto','closehfdp');openReply();"<!--{/if}-->><i class="icon guiigoapp-xiepinglun"></i>{lang guiigo_manage:tlang0147}</a></li>
	</ul>
</div>
<div class="popup-actions" id="guiigo-hfdp">
	<div class="actions-text guiigo-hfdp bg-c">
		<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes&mobile=2">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
			<div class="hfdp-btys xh-b bg-g">
				<a href="javascript:;" class="btys-gbck closehfdp"><i class="icon guiigoapp-guanbi zy-c"></i></a>
				<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" class="btys-gjhf" onclick="ck8('.closehfdp').trigger('click');" data-no-cache="true"><i class="icon guiigoapp-khshipin zy-c"></i></a>
				<h2 class="zy-h">{lang guiigo_manage:tlang0148}</h2>
			</div>
			<div class="hfdp-srys xh-b bg-c">
				<textarea type="text" class="guiigo-pt zy-f" color="gray" name="message" id="needmessage" onkeyup="app.ResizeTextarea();" data-meun="message" onclick="menuTab(this);"  placeholder="{lang guiigo_manage:tlang0149}"></textarea>
			</div>
			<!--{if $secqaacheck || $seccodecheck}--><!--{subtemplate common/seccheck}--><!--{/if}-->
			<div class="hfdp-crqd xh-b bg-g">
				<div class="crqd-gdqd">
					<!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->
					<input type="text" class="guiigo-ps s-a bk-a bg-c zy-h select-picker" value="{lang debate_viewpoint}" data-select="stand" />
					<select id="stand" name="stand" style="display:none;">
						<option value="">{lang debate_viewpoint}</option>
						<option value="0">{lang debate_neutral}</option>
						<option value="1">{lang debate_square}</option>
						<option value="2">{lang debate_opponent}</option>
					</select>
					<!--{/if}-->
					<input type="button" value="{lang reply}" class="guiigo-pn ab-az zy-a zy-ac" name="replysubmit" data-fpid="{$firstpid}" onclick="fastpostsubmit(this);">
				</div>
				<div class="crqd-btat">
					<ul>
						<li><a href="JavaScript:void(0)" class="zy-c" data-meun="sml_menu" onclick="menuTab(this);"><i class="icon guiigoapp-biaoqing"></i><p>{lang guiigo_manage:tlang0150}</p></a></li>
						<li><a href="JavaScript:void(0)" class="zy-c" data-meun="img_menu" onclick="menuTab(this);"><i class="icon guiigoapp-tupian"></i><p>{lang guiigo_manage:tlang0151}</p></a></li>
						<!--{if $_G['group']['allowat']}-->
							<li><a href="JavaScript:void(0)" class="zy-c" data-meun="at_menu" onclick="menuTab(this);"><i class="icon guiigoapp-aite"></i><p>{lang guiigo_manage:tlang0152}</p></a></li>
						<!--{/if}-->	
					</ul>
				</div>
			</div>
			<div class="bg-c cl menu">
				<div class="kznr-bqnr cl hides sml_menu">
					<div class="bqnr-imgs cl swiper-container ck8-smiliestab">
						<div class="swiper-wrapper cl" id="ck8_data">
							<span style="width:100%;font-size:0.7rem;text-align:center;padding:25px 0;color:#333333;">
							{lang guiigo_manage:tlang1004}
							</span>
						</div>
						<div class="swiper-pagination"></div>
					</div>
					<div class="bqnr-bqqh bg-e cl swiper-container ck8-smiliestabs" style="overflow:hidden;">
						<div class="swiper-wrapper buttons-row" id="smilies"></div>
					</div>
				</div>
				<div class="kznr-tpsc cl hides img_menu" id="imglist">
					<div class="tpsc-scan">
						<a href="JavaScript:void(0)" class="bg-e zy-c bk-d">
							<i class="icon guiigoapp-tpscjh zy-g"></i>
							<input type="file" name="Filedata" id="filedata" class="mediaup" accept="image/*" multiple="multiple" onchange="fileup(this);"/>
						</a>
					</div>
				</div>
			</div>
			<div class="bg-g"><!--{hook/viewthread_fastpost_button_mobile}--></div>
		</form>
	</div>
</div>
<div class="popup-actions guiigo-nrdbfx-f">
	<div class="actions-text guiigo-hdfx">
		<div class="gg-app-hide hdfx-hdxm xh-b bg-e">
			<a href="javascript:;" data-app="weixin" class="nativeShare weixin zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wx.png" class="vm"></span>{lang guiigo_manage:tlang0153}</a>
			<a href="javascript:;" data-app="weixinFriend" class="nativeShare weixin_timeline zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/pyq.png" class="vm"></span>{lang guiigo_manage:tlang0154}</a>
			<a href="javascript:;" data-app="QQ" class="nativeShare qq zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/qq.png" class="vm"></span>{lang guiigo_manage:tlang0155}</a>
			<a href="javascript:;" data-app="QZone" class="nativeShare qzone zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kj.png" class="vm"></span>{lang guiigo_manage:tlang0156}</a>
			<a href="javascript:;" data-app="sinaWeibo" class="nativeShare weibo zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wb.png" class="vm"></span>{lang guiigo_manage:tlang0157}</a>
		</div>
		<div class="gg-app-show hdfx-xcxt xh-b bg-e">
			<span class="icon guiigoapp-xiaochengxu"></span>
			<h2>{lang guiigo_manage:tlang1002}</h2>
			<p>{lang guiigo_manage:tlang1003}</p>
		</div>
		<div class="hdfx-hdxm bg-e">
			<a href="javascript:;" class="zy-f zd-12" onclick="copy(this);" id="cptextid"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/fz.png" class="vm"></span>{lang guiigo_manage:tlang0158}</a>
			<a href="javascript:;" class="zy-f zd-12" onclick="setClass();"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/zt.png" class="vm"></span><em class="btfont">{lang guiigo_manage:tlang0997}</em></a>
		</div>
		<a href="javascript:;" class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</a>
	</div>
</div>

<div class="share-layer"></div>
<script type="text/javascript">
ck8(function(){
	if(ck8('#focbtn').length > 0){
		ck8('#focbtn').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('#rewardbut').length > 0){
		ck8('#rewardbut').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('.debatereply').length > 0){
		ck8('.debatereply').click(function(e){
			Dz('needmessage').focus()
		})
	}
})

function ShareAllview(){
		var config = getShareData('#share_title','#share_img','#share_img');
	<!--{if ($guiigo_config['browser']['isqq'] || $guiigo_config['browser']['isuc']) && !$guiigo_config['browser']['iswx']}-->
		nativeShare(config);
	<!--{elseif $guiigo_config['browser']['iswx']}-->
		wxshareJssdkAjax(config)
	<!--{else}-->
		webShare(config)
	<!--{/if}-->
}

function menuTab(e){
	var classMun = ck8(e).attr('data-meun')
    ck8('.crqd-btat').find('a').removeClass('zy-be').addClass('zy-c');
    ck8(e).addClass('zy-be')
	var Munisopen = ck8('.'+classMun).css('display');
 	if(Munisopen == 'block'){
		ck8('.'+classMun).hide()
		ck8('.crqd-btat').find('a').removeClass('zy-be').addClass('zy-c');
	}else if(Munisopen == 'none'){
		ck8('.menu').find('.hides').each(function(index, odj){
			ck8(odj).hide()
		})
		ck8('.'+classMun).show()
	}
	if(classMun == 'message'){
        ck8('.menu').find('.hides').hide()
		ck8(e).addClass('zy-c')
	}else if(classMun == 'at_menu'){
		at_friend()
		ck8('.menu').find('.hides').each(function(index, odj){
			ck8(odj).hide()
		})
		ck8(e).removeClass('zy-be').addClass('zy-c');
	}
}

function fileup(obj){
	app.ImgUpFile(obj)
}

function MsgCallInvite(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('isjmurl') != -1 && param.type == 'poll'){
			ck8.toast('{lang guiigo_manage:tlang0160}');
		    app.PageRefresh(false,'#poll-on','forum.php?mod=viewthread&tid='+ param.tid)
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0160}') != -1 && param.type == 'debate'){
			ck8.toast('{lang guiigo_manage:tlang0161}');
			app.PageRefresh(false,'#voterdebate_'+ param.pid,'forum.php?mod=viewthread&tid='+ param.tid)
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0162}') != -1 && param.type == 'debate'){
			ck8.toast('{lang guiigo_manage:tlang0163}');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0164}') != -1 && param.type == 'activity'){
			ck8.toast('{lang guiigo_manage:tlang0008}');
			app.PageRefresh(false,'#hdnr-on','forum.php?mod=viewthread&tid='+ param.tid)
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0165}') != -1 && param.type == 'activity'){
			ck8.toast('{lang guiigo_manage:tlang0166}');
			app.PageRefresh(false,'#hdnr-on','forum.php?mod=viewthread&tid='+ param.tid)
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0167}') != -1 && param.type == 'rushresult'){
			ck8.toast(msg.msg);
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0168}') != -1){
			ck8.closeModal('.popup-about-js')
            ck8.toast(msg.msg);
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0169}') != -1){
			ck8.closeModal('.popup-about-js')
            ck8.toast(msg.msg);
			if(param.pid){
                app.PageRefresh('','#pid'+ param.pid,'forum.php?mod=viewthread&tid=$_G[tid]&viewpid='+ param.pid +'&inajax=1')
				app.close_popup()
			}
		}else if (msg.msg.indexOf('window.location.href') != -1 && param.type == 'videbate'){
			ck8.toast('{lang guiigo_manage:tlang0161}');
			app.PageRefresh(false,'#deba-cgkz','forum.php?mod=viewthread&tid='+ param.tid)
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0170}') != -1 && param.type == 'videbate'){
			ck8.toast('{lang guiigo_manage:tlang0171}');
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallModmenu(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if(msg.msg.indexOf('{lang guiigo_manage:tlang0172}') != -1){
			ck8.toast(msg.msg);
			app.PageRefresh(false,'#gg-sq-nrzt')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1){
			
			if(param.action && param.action == 'delcomment' && param.pid){
			    ck8.toast('{lang guiigo_manage:tlang0173}');
                ck8('#delcomment_'+ param.pid).remove()
				var obj = ck8.trim(ck8('#comment_'+ param.cpid).html());
				if(!obj || obj == ''){
					ck8('#comment_'+ param.cpid).removeClass('ck8-comment')
				}
			}else{
				ck8.toast(msg.msg);
			}
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0174}') != -1){
			ck8.toast(msg.msg);
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0175}') != -1){
			ck8.alert(msg.msg, '{lang guiigo_manage:tlang0176}', function (){})
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallFnl(msg,par) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = ck8('.followmod_'+ par.fuid +'');
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid='+ par.fuid +'').html('<span style="background:#21d5bc;"><i class="icon guiigoapp-guanzhu zy-a"></i></span>{lang guiigo_manage:tlang0003}');
			ck8.toast('{lang guiigo_manage:tlang0003}');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+ par.fuid +'').html('<span style="background:#21d5bc;"><i class="icon guiigoapp-guanzhu zy-a"></i></span>{lang guiigo_manage:tlang0011}');
			ck8.toast('{lang guiigo_manage:tlang0009}');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0022}','shibai');
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallFn(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = $('.followmod_'+ param.tid);
		var foObj = $('#recommend_add_'+ param.tid);
		var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1 || msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			$.toast('{lang guiigo_manage:tlang0003}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + param.tid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
			Obj.attr('ck-confirm','true')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			$.toast('{lang guiigo_manage:tlang0009}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + param.tid).html('{lang guiigo_manage:tlang0002}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
			Obj.attr('ck-confirm','false')
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}

function MsgCallPostFavcForum(msg,par){
	var favor = ck8('#post_favc_forum_');
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1){
			favor.attr('href','home.php?mod=spacecp&ac=favorite&type=forum&id='+ par.id +'&handlekey=favoriteforum&formhash={FORMHASH}').addClass('posonts').removeClass('posonts-off').html('{lang guiigo_manage:tlang0017}');
			ck8.toast('{lang guiigo_manage:tlang0019}');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0014}') != -1){
			favor.attr('href','home.php?mod=spacecp&ac=favorite&op=delete&type=forum&favid='+ par.favid +'&&fn=MsgCallPostFavcForum').addClass('posonts-off').removeClass('posonts').html('{lang guiigo_manage:tlang0003}');
			ck8.toast('{lang guiigo_manage:tlang0003}');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0018}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0020}','shibai');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0021}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0022}','shibai');
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallFavor(msg,par){
	if(typeof msg === 'object' || typeof par === 'object'){
		var favor = ck8('#favoritenumber');
		var favorcun = parseInt(favor.html());
		if(msg.msg && msg.msg.indexOf('{lang guiigo_manage:tlang0014}') != -1) {
			ck8.toast('{lang guiigo_manage:tlang0177}');
			var fdelurl='home.php?mod=spacecp&ac=favorite&op=delete&favid='+ par.favid +'&formhash={FORMHASH}';
			if(favor.css('display') == 'none'){
				favor.html(1).show()
			}else{
				favor.html(favorcun + 1)
			}
			favor.parent().attr('href',fdelurl)
			favor.prev().removeClass('guiigoapp-nydbsc zy-e').addClass('guiigoapp-nydbscon zy-m')

		}else if(msg.msg && msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && par.favid && par.id){
			ck8.toast('{lang guiigo_manage:tlang0178}');
			var favorurl ='home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}';
			if(favorcun == 1){
				favor.html(0).hide()
			}else{
				favor.html(favorcun - 1)
			}
			favor.parent().attr('href',favorurl)
			favor.prev().removeClass('guiigoapp-nydbscon zy-m').addClass('guiigoapp-nydbsc zy-e')
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallDownload(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
	if((msg.msg.indexOf('{lang guiigo_manage:tlang0179}') != -1 || msg.msg.indexOf('{lang guiigo_manage:tlang0180}') != -1) && param.type == 'attachpay'){//attachpay
		ck8.closeModal();
		ck8.confirm(msg.msg, '{lang guiigo_manage:tlang0181}',
			function (){
				window.open(msg.url.replace('&mobile=2',''))
			})
		}else {
			ck8.toast(msg.msg,'shibai');
		}	
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallRaterange(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
        if(msg.msg.indexOf('{lang guiigo_manage:tlang0182}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0183}','shibai');
        }else if(msg.msg.indexOf('{lang guiigo_manage:tlang0184}') != -1){
			var newmsg = msg.msg.replace('{lang guiigo_manage:tlang0185}','{lang guiigo_manage:tlang0186}')
			ck8.closeModal('.popup-about-js')
			ck8.toast(newmsg,'shibai');
        }else if(msg.msg.indexOf('{lang guiigo_manage:tlang0187}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0188}','shibai');
        }else if(msg.msg.indexOf('{lang guiigo_manage:tlang0189}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0190}','shibai');
			ck8.closeModal('.popup-about-js')
        }else if(msg.msg.indexOf('{lang guiigo_manage:tlang0191}') != -1){
            ck8.toast('{lang guiigo_manage:tlang0192}','shibai');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0193}') != -1){
            ck8.toast('{lang guiigo_manage:tlang0192}','shibai');
        }else if(msg.msg.indexOf('{lang guiigo_manage:tlang0194}') != -1){
			var name = param.user ? param.user +'{lang guiigo_manage:tlang0195}' : '';
			ck8.toast(name + '{lang guiigo_manage:tlang0196}','',2000);
			ck8.closeModal('.popup-about-js')
			if(param.pid){
				var url = 'forum.php?mod=viewthread&tid=$_G[tid]&viewpid='+ param.pid +'&inajax=1';
				app.PageRefresh('','#post_topo_'+ param.pid,url)
			}
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0197}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0198}'+ par.title +'{lang guiigo_manage:tlang0199}'+ par.minbalance +'{lang guiigo_manage:tlang0200}');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0201}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0201}');
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0202}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0203}');
			app.PageRefresh(false,'#gg-sq-lznr')
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallComment(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (par.pid && par.tid && msg.msg.indexOf('{lang guiigo_manage:tlang0204}') != -1){
            ck8.toast(msg.msg);
            app.PageRefresh(false,'#dpkx-on-'+ param.pid,'forum.php?mod=viewthread&tid='+ param.tid)
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0205}') != -1){
			ck8.alert('{lang guiigo_manage:tlang0206}', '{lang guiigo_manage:tlang0042}', function () {
			   ck8.closeModal('.popup-about-js')
			})
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallRecommendv(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		var foObj = ck8('#recommendv_add_'+ param.pid);
		var recommendcut = parseInt(foObj.html());
		if (par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0207}');
            if(param && param.type && param.type =='hotreply') return;
			if(par.daycount){
				setTimeout(function(){
					ck8.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')
				}, 2300);
			}
			if(foObj.css('display') == 'none'){
				foObj.html(1).show()
			}else{
				ck8('#recommendv_add_lz'+ param.pid +'').html(recommendcut + parseInt(par.recommendv))
				foObj.html(recommendcut + parseInt(par.recommendv))
			}
			foObj.prev().removeClass('guiigoapp-nydbdz zy-e').addClass('guiigoapp-nydbdzon zy-i');
			foObj.parent().removeClass('dialog').addClass('delRecommenus').attr('href','plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid=$_G[tid]');
			if(param.pid){
				var url = 'forum.php?mod=viewthread&tid=$_G[tid]&viewpid='+ param.pid +'&inajax=1';
				app.PageRefresh('','#post_topo_'+ param.pid,url)
			}
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0049}','shibai');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
			ck8.confirm('{lang guiigo_manage:tlang0208}', '{lang guiigo_manage:tlang0042}', function () {
				ck8.router.load('home.php?mod=spacecp&ac=usergroup',true);
			});
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0053}','shibai');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0055}','shibai');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0160}') != -1){
			 if(param && param.type && param.type =='hotreply'){
				 ck8.toast('{lang guiigo_manage:tlang0207}~');
				 if(foObj.css('display') == 'none'){
				 	foObj.html(1).show()
				 }else{
				 	foObj.html(recommendcut + 1)
				 }
				 foObj.prev().removeClass('guiigoapp-dianzan').addClass('zy-i guiigoapp-dianzanon')
				 foObj.parent().removeClass('dialog').addClass('delhotreply').attr('href','plugin.php?id=guiigo_manage:api&api=misc&action=postreview&do=delsupport&tid=$_G[tid]&pid='+param.pid);
			 }
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0209}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0053}','shibai');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0210}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0049}','shibai');
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function fastpostsubmit(obj){
    var form = ck8('#fastpostform');
	var msgobj = ck8('#fastpostmessage');
	var fpid = ck8(obj).attr('data-fpid');
	if(msgobj.val() == '{lang send_reply_fast_tip}') {
		msgobj.attr('value', '');
	}
	var needmessage = ck8('#needmessage').val();
	if(needmessage == '') {
        ck8.toast('{lang guiigo_manage:tlang0211}','shibai');
		return;
	}
	if(mb_strlen(needmessage) < 5) {
        ck8.toast('{lang guiigo_manage:tlang0212}','shibai');
		return;
	}
	ck8.ajax({
		type:'POST',
		url: form.attr('action') + '&handlekey=fastpost&loc=1&inajax=1',
		data: form.serialize(),
		dataType: 'xml',
		success: function(s){
			app.Devalscript(app.initAtr(s.lastChild.firstChild.nodeValue),succeedhandle_fastpost);
			<!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->
			if(fpid){
				app.PageRefresh('','#pid'+fpid,'forum.php?mod=viewthread&tid=$_G[tid]');
			}
			<!--{/if}-->
		}
	})
}

function closeRrply(){
    ck8('#filedata').val('');
    ck8('#needmessage').val('');
	ck8('#imglist').find('.imgviwe').remove();
	ck8('#guiigo-hfdp').hide()
	if(ck8('header').css('display') == 'none'){
		ck8('header').show().removeClass('on-bar')
	}
	if(ck8('nav').length>0 && ck8('nav').css('display') == 'none'){
		ck8('nav')._show(300)
	}
	if(ck8('.bar-rep').length>0 && ck8('.bar-rep').css('display') == 'none'){
		ck8('.bar-rep')._show(300)
	}
}

function succeedhandle_fastpost(msg,par){
	if(typeof msg !== 'object' || typeof par !== 'object'){
		ck8.toast('{lang guiigo_manage:tlang0146}','jinggao');
		return;
	}
	var pid = par['pid'];
	var tid = par['tid'];
	var fid = par['fid'];
	if(msg.msg && msg.msg.indexOf('{lang guiigo_manage:tlang0213}') != -1) {
		ck8.toast('{lang guiigo_manage:tlang0214}');
		closeRrply()
	}else if(msg.msg) {
		ck8.toast(msg.msg,'shibai');
	}else if(!msg.msg) {
		msg.msg = '{lang postreplyneedmod}';
		ck8.toast(msg.msg,'shibai');
	}
	if(pid && tid && fid){
		addViewthreadViewpid(tid,pid);
	}
    ck8('[name=seccodeverify]').val('');
	if(par['sechash']) {
		seccode(ck8('.seccodeimg'))
	}
}

function openReply(url){
	if(!url) url ='';
	<!--{if !$_G[uid] || ($_G[uid] && !$allowpostreply)}-->
		<!--{if !$_G[uid]}-->
            login.GoLogin()
		<!--{else}-->
			popup.open('{lang nopostreply}', 'alert');
		<!--{/if}-->
        return;
	<!--{else}-->
		if(url){
			ck8('#fastpostform').attr('action',url);
		}
		app.loadScript('smiliess');
		app.loadStyle('cssswiper-4.3.3.min');
		app.loadScript('jsswiper-4.3.3.min',function(){
			new Swiper('.ck8-smiliestabs', {
				slidesPerView : 8,
				slideToClickedSlide : true,
				freeMode : true,
				observer : true,
				observeParents : true,
			})
			new Swiper('.ck8-smiliestab', {
				observer : true,
				observeParents : true,
				pagination: {
					el: '.swiper-pagination',
				},
			})
			ck8('.ck8-smiliestabs').css({'visibility':'visible'});
			setTimeout(function(){
				smilies_show(39, 'ck8-')
					 ck8('.sml_menu').on('click','.bqimg',function(){
						 ck8('.crqd-btat').find('a').removeClass('zy-be').addClass('zy-c');					 
					 })
		    },500)
		})
		app.loadScript('at')
	<!--{/if}-->
	ck8('.seccodeimg').click();
	ck8('.seccodeimg').click();
}
</script>

