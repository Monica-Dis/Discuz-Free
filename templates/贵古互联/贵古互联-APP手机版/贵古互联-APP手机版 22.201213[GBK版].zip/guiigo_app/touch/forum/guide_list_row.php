<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $list['threadcount']}-->
	<div class="guiigo-ztlb list-block-no ">
		<ul class="list-container bg-g">
		<!--{eval $list['threadlist'] = GuiigoApp::GetPostlist($list['threadlist']);}-->
			<!--{loop $list['threadlist'] $key $thread}-->
				<!--{if $post['closed'] > 1 || $post['moved']}-->
					<!--{eval $post[tid]=$post[closed];}-->
				<!--{/if}-->
				<!--{if (!$_G['setting']['mobile']['mobiledisplayorder3'] && $post['displayorder'] > 0) ||  $post['displayorder'] < 0}-->
					{eval continue;}
				<!--{/if}-->
				<li class="gztlb-ztys bg-c xh-b sh-a">
					<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><!--{elseif $thread['digest'] > 0}-->
						<div class="gztlb-jhzt"><i class="icon guiigoapp-jinghua zy-i"></i></div>
					<!--{/if}-->
					<div class="gztlb-tbyh">
						<div class="tbyh-lztx guiigo-ty"><!--{if $thread['authorid'] && $thread['author']}--><a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><!--{avatar($thread[authorid],middle)}--></a><!--{else}--><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg"><!--{/if}--></div>
						<div class="tbyh-mcxx">
							<h1>
								<!--{if $thread['authorid'] && $thread['author']}-->
									<!--{if $thread['isfollow'] ==1}-->
									<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$thread['authorid']"
									class="followmod_$thread[authorid] dialog mcxx-gzan zy-c bk-c bg-e" 
									ck-cus="true" 
									ck-confirm="true" 
									ck-param="{type:'modal',callpar:{tid:'$thread['authorid']'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}"  
									external >{lang guiigo_manage:tlang0003}</a>
									<!--{else}-->
									 <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]" 
									class="followmod_$thread[authorid] dialog mcxx-gzan zy-b bk-b"  
									ck-cus="true"
									ck-confirm="false"
									ck-param="{type:'modal',callpar:{tid:'$thread[authorid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}" 
									external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
									<!--{/if}-->
									<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="mcxx-yhmc zy-f">$thread[author]</a>
									<span class="mcxx-yhdj zy-a" style="background: {$thread[groupcolor]};">{$thread[groupstars]} {$thread[grouptitle]}</span>
									<!--{if $thread['gender'] == 1 || $thread['gender'] == 0}-->
									<i class="icon guiigoapp-nan bg-n"></i>
									<!--{elseif $thread['gender'] == 2}-->
									<i class="icon guiigoapp-nv bg-o"></i>
									<!--{/if}-->
									<!--{if $_G['setting']['verify']['enabled']}-->
										<span class="verify-icon y">
										<!--{loop $thread['verifyicon'] $verify}-->
											<a href="{$verify['verifurl']}" class="ck8-avatar-icon">
											   <img src="{$verify['verificon']}" class="vm" />
											</a>
										<!--{/loop}-->
										</span>
									<!--{/if}-->
								<!--{else}-->
									<a href="javascript:void(0);" class="mcxx-yhmc zy-f">$_G[setting][anonymoustext]</a>
								<!--{/if}-->
							</h1>
							<div class="mcxx-fbxx">
								<i class="zy-g"><!--{eval echo dgmdate($thread[dateline], 'u');}--></i>
							</div>
						</div>
					</div>
					<div class="gztlb-nrdy">
						<h1>
							<!--{if $thread[special] == 1}-->
								<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0138}</span>
							<!--{elseif $thread[special] == 2}-->
								<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0139}</span>
							<!--{elseif $thread[special] == 3}-->
								<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0140}</span>
							<!--{elseif $thread[special] == 4}-->
								<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0141}</span>
							<!--{elseif $thread[special] == 5}-->
								<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0142}</span>
							<!--{elseif $thread['rushreply']}-->
								<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0143}</span>
							<!--{/if}-->
							<!--{if $thread['replycredit'] > 0}-->
								<span class="nrdy-ztlx bg-j zy-a">{lang guiigo_manage:tlang1028}</span>
							<!--{/if}-->
							<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]>{$thread['subject']}</a>
						</h1>
						<!--{if $thread['message']}-->
							<p class="zy-c"><!--{$thread['message']}--></p>
						<!--{/if}-->
						<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
							<div class="nrdy-imgs">
								<ul style="display: flex;justify-content: left;flex-wrap: wrap;">
								<!--{loop $thread[attapic] $imgkey $imglist}-->
									<!--{if $imglist['countImg'] == 1}-->
										<li class="imgs-tpsa"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
									<!--{elseif $imglist['countImg'] == 2}-->
										<li class="imgs-tpsb"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
									<!--{elseif $imglist['countImg'] == 3}-->
										<li class="imgs-tpsb imgs-tpsp"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
									<!--{else}-->
										<li class="imgs-tpsc<!--{if $imglist['countImg'] > 6}--> imgs-tpsd<!--{/if}-->"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/><!--{if $imglist['countImg'] > 6}--><div class="tpsd-gdtp"><span class="tpsd-jtnr"><i class="icon guiigoapp-mkbtgd"></i>{$imglist['countImg']}</span></div><!--{/if}--></li>
									<!--{/if}-->
									<!--{if $imgkey >= 5}-->
										<!--{eval break;}-->
									<!--{/if}-->
								<!--{/loop}-->
								</ul>
							</div>
						</a>
					</div>
					<div class="gztlb-ztcz">
						<div class="ztcz-lyrd cl">
							<div class="ztcz-bkht"><i class="icon guiigoapp-huati1 ab-a"></i><em><a href="forum.php?mod=forumdisplay&fid=$thread[fid]">$list['forumnames'][$thread[fid]]['name']</a></em></div>
							<!--{if $thread['displayorder'] == 0}-->
								<!--{if $thread[heatlevel]}-->
									<div class="ztcz-bkht ztcz-ztrd"><i class="icon guiigoapp-lredu"></i>{lang guiigo_manage:tlang0879} {$thread[heats]}</div>
								<!--{/if}-->
							<!--{/if}-->
						</div>
						<ul>
							<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-huifu"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[replies])}--><!--{else}-->$thread[replies]<!--{/if}--></a></li>
							<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-chakan"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[views])}--><!--{else}-->$thread[views]<!--{/if}--></a></li>
							<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
								<!--{eval $recommenus=$thread['isrecommenus']==1 ? 1 :'';}-->
								<li class="ztcz-ybcz">
									<div class="ztcz-dzkz{if $recommenus} zy-b bg-m{else} zy-c bg-l{/if}" id="recommend_add_$thread[tid]">
										<a href="{if $recommenus}plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid=$thread[tid]{else}forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&hash={FORMHASH}&handlekey=recommend_add{/if}"  
											class="{if $recommenus}delRecommenus{else}dialog{/if}" 
											ck-cus="true"
											ck-param="{
												type:'modal',
												callpar:{tid:'$thread[tid]'},
												fn:'MsgCallFn',
												load:'true',
												uid:'{$_G[uid]}'
											}" 
											external ><i class="icon{if $recommenus} guiigoapp-dianzanon{else} guiigoapp-dianzan{/if}"></i>
										</a>
										<em id="recommend_add_sum$thread[tid]"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[recommend_add])}--><!--{else}-->$thread[recommend_add]<!--{/if}--></em>
									</div>
								</li>
							<!--{/if}-->
						</ul>
					</div>
				</li>
			<!--{/loop}-->
		</ul>
		<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
			<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
		</div>
	</div>
<!--{else}-->
	<div class="guiigo-wnrtx">
		<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
		<p class="zy-c">{lang guiigo_manage:tlang0225}</p>
	</div>
<!--{/if}-->
