<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<input type="hidden" name="trade" value="yes" />
<input type="hidden" name="item_type" value="1" />
<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
	<ul>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="item_name">{lang post_trade_name}</label> <span class="zy-i">*</span></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="item_name" id="item_name" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0307}" value="$trade[subject]" tabindex="1" /></div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="item_number">{lang post_trade_number}</label> <span class="zy-i">*</span></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="item_number" id="item_number" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0308}" value="$trade[amount]" tabindex="1" /></div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0309}</div>
			<div class="wblb-wbnr zy-h">
				<input type="text" class="guiigo-ps s-a select-picker" value="{lang trade_new}" data-select="item_quality" />
				<select id="item_quality" name="item_quality" tabindex="1" style="display:none;">
					<option value="1" {if $trade['quality'] == 1}selected="selected"{/if}>{lang trade_new}</option>
					<option value="2" {if $trade['quality'] == 2}selected="selected"{/if}>{lang trade_old}</option>
				</select>
			</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="transport">{lang post_trade_transport}</label></div>
			<div class="wblb-wbnr zy-h">
				<input type="text" class="guiigo-ps s-a select-picker" value="{lang post_trade_transport_virtual}" data-select="transport" />
				<select name="transport" id="transport" onchange="transportselect(this)" style="display:none;">
					<option value="virtual" {if $trade['transport'] == 3}selected="selected"{/if}>{lang post_trade_transport_virtual}</option>
					<option value="seller" {if $trade['transport'] == 1}selected="selected"{/if}>{lang post_trade_transport_seller}</option>
					<option value="buyer" {if $trade['transport'] == 2}selected="selected"{/if}>{lang post_trade_transport_buyer}</option>
					<option value="logistics" {if $trade['transport'] == 4}selected="selected"{/if}>{lang trade_type_transport_physical}</option>
					<option value="offline" {if $trade['transport'] == 0}selected="selected"{/if}>{lang post_trade_transport_offline}</option>
				</select>
			</div>
			<script>
				function transportselect(e){
					Dz('logisticssetting').style.display = Dz('transport').value == 'virtual' ? 'none' : ''
				}
			</script>
		</li>
		<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang post_trade_price} <span class="zy-i">*</span></li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="item_price">{lang post_current_price}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="item_price" id="item_price" class="guiigo-px s-a" value="$trade[price]" tabindex="1" /></div>
			<div class="wblb-wbdw zy-g">{lang guiigo_manage:tlang0310}</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="item_costprice">{lang post_original_price}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="item_costprice" id="item_costprice" class="guiigo-px s-a" value="$trade[costprice]" tabindex="1" /></div>
			<div class="wblb-wbdw zy-g">{lang guiigo_manage:tlang0310}</div>
		</li>
		<!--{if $_G['setting']['creditstransextra'][5] != -1}-->
			<li class="guiigo-flex xh-b cl">
				<div class="wblb-wbbt zy-c"><label for="item_credit">{lang post_current_credit}</label></div>
				<div class="wblb-wbnr zy-h"><input type="text" name="item_credit" id="item_credit" class="guiigo-px s-a" value="$trade[credit]" tabindex="1" /></div>
				<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</div>
			</li>
			<li class="guiigo-flex xh-b cl">
				<div class="wblb-wbbt zy-c"><label for="item_costcredit">{lang post_original_credit}</label></div>
				<div class="wblb-wbnr zy-h"><input type="text" name="item_costcredit" id="item_costcredit" class="guiigo-px s-a" value="$trade[costcredit]" tabindex="1" /></div>
				<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</div>
			</li>
		<!--{/if}-->
	</ul>
</div>
<div class="guiigo-wblb list-block-no bg-c cl" id="logisticssetting" style="display:{if !$trade['transport'] || $trade['transport'] == 3}none{/if}">
	<ul>
		<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang guiigo_manage:tlang0311} <span class="zy-i">*</span></li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="postage_mail">{lang post_trade_transport_mail}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="postage_mail" id="postage_mail" class="guiigo-px s-a" value="$trade[ordinaryfee]" tabindex="1" /></div>
			<div class="wblb-wbdw zy-g">{lang guiigo_manage:tlang0310}</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="postage_express">{lang post_trade_transport_express}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="postage_express" id="postage_express" class="guiigo-px s-a" value="$trade[expressfee]" tabindex="1" /></div>
			<div class="wblb-wbdw zy-g">{lang guiigo_manage:tlang0310}</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="postage_ems">EMS</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="postage_ems" id="postage_ems" class="guiigo-px s-a" value="$trade[emsfee]" tabindex="1" /></div>
			<div class="wblb-wbdw zy-g">{lang guiigo_manage:tlang0310}</div>
		</li>
	</ul>
</div>
<div class="guiigo-wblb list-block-no bg-c cl">
	<ul>
		<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang guiigo_manage:tlang0312}</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="paymethod">{lang post_trade_paymethod}</label></div>
			<div class="wblb-wbnr zy-h">
				<input type="text" class="guiigo-ps s-a select-picker" value="{lang post_trade_paymethod_offline}" data-select="paymethod" />
				<select name="paymethod" id="paymethod" change="display('tenpayseller')" tabindex="1" style="display:none;">
					<option value="1" {if !$trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_offline}</option>
				</select>
			</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="item_locus">{lang post_trade_locus}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="item_locus" id="item_locus" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0313}" value="$trade[locus]" tabindex="1" /></div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="item_expiration">{lang valid_before}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="item_expiration" id="item_expiration" class="guiigo-px s-a" autocomplete="off" value="$trade[expiration]" tabindex="1" /></div>
		</li>
		<!--{if $allowpostimg}-->
			<li class="guiigo-flex xh-b cl">
				<div class="wblb-wbbt zy-c">{lang post_trade_picture}</div>
				<div class="wblb-wbnr zy-h">
					<button type="button" class="guiigo-pn wbnr-flim bg-e bk-e zy-c" onclick="uploadWindow(function (aid, url){tradeaid_upload(aid, url)})"><i class="icon guiigoapp-tupian zy-f"></i><!--{if $tradeattach[attachment]}-->{lang guiigo_manage:tlang0261}<!--{else}-->{lang guiigo_manage:tlang0262}<!--{/if}--></button>
					<input type="hidden" name="tradeaid" id="tradeaid" {if $tradeattach[attachment]}value="$tradeattach[aid]" {/if}/>
					<input type="hidden" name="tradeaid_url" id="tradeaid_url" />
					<div id="tradeattach_image" class="wbnr-fimz">
					<!--{if $tradeattach[attachment]}-->
						<img src="$tradeattach[url]/{if $tradeattach['thumb']}{eval echo getimgthumbname($tradeattach['attachment']);}{else}$tradeattach[attachment]{/if}" />
					<!--{/if}-->
					</div>
				</div>
			</li>
		<!--{/if}-->
	</ul>
</div>
<script type="text/javascript" reload="1">
ck8(function(){
	ck8("#item_expiration").calendar({});
})

EXTRAFUNC['validator']['special'] = 'validateextra';
function validateextra() {
	if(Dz('postform').item_name.value == '') {
		ck8.confirm('{lang post_goods_error_message_1}',
			function () {
				 Dz('postform').item_name.focus();
			},
			function () {}
		)
		return false;
	}
	if(Dz('postform').item_number.value == '') {
		ck8.confirm('{lang post_goods_error_message_2}',
			function () {
				 Dz('postform').item_number.focus();
			},
			function () {}
		)
		return false;
	}
	if(Dz('postform').item_price.value == '' && Dz('postform').item_credit.value == '') {
	    ck8.confirm('{lang post_goods_error_message_3}',
			function () {
				 Dz('postform').item_price.focus();
			},
			function () {}
		)
		return false;
	}
	return true;
}
function tradeaid_upload(aid, url) {
	Dz('tradeaid_url').value = url;
	updatetradeattach(aid, url, '{$_G['setting']['attachurl']}forum');
}
function updatetradeattach(aid, url, attachurl) {
	Dz('tradeaid').value = aid;
	Dz('tradeattach_image').innerHTML = '<img src="' + attachurl + '/' + url + '" class="spimg" />';
}
</script>
