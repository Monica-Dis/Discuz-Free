<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $_GET['inajax'] == 1 && $_GET['cus']== 'yes'}-->
{eval 
$url = "";
$arr1 = array('aid' => '');
showmessage("{lang guiigo_manage:tlang0013}",NULL,$arr1);
}
<!--{else}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="trade-view">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0360}</h1>
	</header>
	<div class="content">
		<div class="list-block" id="tradepost-form">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<form method="post" 
			autocomplete="off" 
			id="tradepost" 
			name="tradepost" 
			action="forum.php?mod=trade&orderid=$orderid"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pmid:'',type:'tradepost'},fn:'MsgCallTeagm',load:'true',uid:'$_G[uid]'}" 
			>
				<!--{if !empty($_G['gp_modthreadkey'])}-->
					<input type="hidden" name="modthreadkey" value="$_G[gp_modthreadkey]" />
				<!--{/if}-->
				<!--{if !empty($_G['gp_tid'])}-->
					<input type="hidden" name="tid" value="$_G[gp_tid]" />
				<!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}" />

				<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0361}</div>
							<div class="wblb-wbnr">$tradelog[statusview] <em class="zy-c zd-12">($tradelog[lastupdate])</em></div>
						</li>
						<!--{if $tradelog[offline] && $offlinenext}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="password">{lang trade_password}</label></div>
								<div class="wblb-wbnr"><input id="password" name="password" type="password" class="guiigo-px s-a" /></div>
							</li>
							<li class="wblb-dkbt bg-g xh-b zy-c cl"><label for="message">{lang trade_message}</label></li>
							<li class="wblb-nrsr xh-b zy-h cl">
								<div class="wblb-wbnr zy-h">
									<textarea id="buyermsg" id="message" name="message" rows="5" class="guiigo-pt s-a" placeholder="$trade_message {lang trade_seller_remark_comment}"></textarea>
								</div>
							</li>
							<div class="gg-sq-ztan">
								<!--{loop $offlinenext $nextid $nextbutton}-->
									<button class="guiigo-pn mx-a ab-az zy-a zy-ac" type="button" onclick="Dz('tradepost').offlinestatus.value = '$nextid';Dz('offlinesubmit').click();">$nextbutton</button>
								<!--{/loop}-->
								<input type="hidden" name="offlinestatus" value="" />
								<input type="hidden" name="offlinesubmit" value="true" />
								<input type="submit" id="offlinesubmit"  style="display: none" class="formdialog"/>
							</div>
						<!--{/if}-->
						<!--{if trade_typestatus('successtrades', $tradelog[status]) || trade_typestatus('refundsuccess', $tradelog[status])}-->
							<!--{if $tradelog[ratestatus] == 3}-->
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0362}</div>
									<div class="wblb-wbnr"><div class="wnmr-sznr zy-h">{lang eccredit_post_between}</div></div>
								</li>
							<!--{elseif ($_G['uid'] == $tradelog[buyerid] && $tradelog[ratestatus] == 1) || ($_G['uid'] == $tradelog[sellerid] && $tradelog[ratestatus] == 2)}-->
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0362}</div>
									<div class="wblb-wbnr"><div class="wnmr-sznr zy-h">{lang eccredit_post_waiting}</div></div>
								</li>
							<!--{else}-->
								<!--{if ($_G['uid'] == $tradelog[buyerid] && $tradelog[ratestatus] == 2) || ($_G['uid'] == $tradelog[sellerid] && $tradelog[ratestatus] == 1)}-->
									<li class="guiigo-flex xh-b cl">
										<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0362}</div>
										<div class="wblb-wbnr"><div class="wnmr-sznr zy-h">{lang eccredit_post_already}</div></div>
									</li>
								<!--{else}-->
								<!--{/if}-->
								<div class="gg-sq-ztan">
								<!--{if $_G['uid'] == $tradelog[buyerid]}-->
									<a href="home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=0" class="guiigo-pn mx-a ab-az zy-a zy-ac">{lang eccredit1}</a>
								<!--{elseif $_G['uid'] == $tradelog[sellerid]}-->
									<a href="home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=1" class="guiigo-pn mx-a ab-az zy-a zy-ac">{lang eccredit1}</a>
								<!--{/if}-->
								</div>
							<!--{/if}-->
						<!--{/if}-->
					</ul>
				</div>
				<div class="gg-sq-ddxq ms-a bg-c sh-a xh-b">
					<h2 class="xh-b zy-h">{lang guiigo_manage:tlang0312}</h2>
					<div class="gg-sq-qrsp gg-sq-sznr ddxq-spxq bg-c">
						<li>
							<div class="sznr-sptp bg-e">
							<!--{if $trade['aid']}-->
								<img lazySrc="{echo getforumimg($trade[aid])}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
							<!--{else}-->
								<img lazySrc="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-wt.jpg" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
							<!--{/if}-->
							</div>
							<h4 class="zy-h sh-a">$trade[subject]</h4>
							<p class="sznr-pzdq zy-g">
								<!--{if $trade['quality'] == 1}--><span class="bg-j zy-a">{lang trade_new}</span><!--{elseif $trade['quality'] == 2}--><span class="bg-j zy-a">{lang trade_old}</span><!--{/if}-->
								<!--{if $trade[locus]}-->$trade[locus]<!--{/if}-->
							</p>
							<p class="sznr-jgjf zy-b">
								<!--{if $trade[price] > 0}-->
									<span>{lang guiigo_manage:tlang0347}</span>$trade[price]
								<!--{/if}-->
								<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
									<em class="zy-g"><!--{if $trade['price'] > 0}-->{lang trade_additional}<!--{/if}--> $trade[credit]{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</em>
								<!--{/if}-->
							</p>
						</li>
					</div>
					<!--{if $tradelog[status] == 0}--><div class="ddxq-csts bk-d bg-p zy-b">{lang guiigo_manage:tlang0363}</div><!--{/if}-->
					<div class="guiigo-wblb list-block-no cl">
						<ul>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang trade_payment}</div>
								<div class="wblb-wbnr">
									<div class="wnmr-sznr zy-h">
										<!--{if $tradelog[price] > 0}-->$tradelog[price]&nbsp;{lang payment_unit}&nbsp;&nbsp;<!--{/if}-->
										<!--{if $_G['setting']['creditstransextra'][5] != -1 && $tradelog[credit]}-->{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}&nbsp;$tradelog[credit]&nbsp;{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}&nbsp;&nbsp;<!--{/if}-->
									</div>
								</div>
							</li>
							<!--{if $tradelog[tradeno]}-->
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang trade_order_no}</div>
									<div class="wblb-wbnr"><a href="$loginurl" class="zy-h">$tradelog[tradeno]</a></div>
								</li>
							<!--{/if}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang trade_seller}</div>
								<div class="wblb-wbnr">
									<a href="home.php?mod=space&uid=$tradelog[sellerid]&do=profile" class="zy-l"><span class="wbnr-yhtx"><!--{avatar($tradelog[sellerid],middle)}--></span>$tradelog[seller]</a>
									<!--{if $_G['uid'] != $tradelog['sellerid']}-->
										<a href="javascript:;" 
										class="getpm-popup lxmj-lxan bk-b zy-b" 
										data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$tradelog[sellerid]&touid=$tradelog[sellerid]&pmid=0&daterange=2" 
										external>{lang guiigo_manage:tlang0355}</a>
									<!--{/if}-->
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang trade_buyer}</div>
								<div class="wblb-wbnr">
									<a href="home.php?mod=space&uid=$tradelog[buyerid]&do=profile" class="zy-l"><span class="wbnr-yhtx"><!--{avatar($tradelog[buyerid],middle)}--></span>$tradelog[buyer]</a>
									<!--{if $_G['uid'] != $tradelog['buyerid']}-->
										<a href="javascript:;" 
										class="getpm-popup lxmj-lxan bk-b zy-b" 
										data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$tradelog[buyerid]&touid=$tradelog[buyerid]&pmid=0&daterange=2" 
										external>{lang guiigo_manage:tlang0364}</a>
									<!--{/if}-->
								</div>
							</li>
							<!--{if $tradelog[status] == 0 && $tradelog[sellerid] == $_G['uid']}-->
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c"><label for="newprice">{lang trade_baseprice}</label></div>
									<div class="wblb-wbnr">
										<span><input type="text" id="newprice" name="newprice" value="$tradelog[baseprice]" class="guiigo-px bg-e zy-b s-a" style="width:30%;padding: 0 .3rem;" /></span> <em class="zy-c">{lang payment_unit}</em>&nbsp;&nbsp;
										<!--{if $_G['setting']['creditstransextra'][5] != -1 && $tradelog[credit]}-->
											<em class="zy-c">{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}</em> <input type="text" id="newcredit" name="newcredit" value="$tradelog[basecredit]" class="guiigo-px bg-e zy-b s-a" style="width:30%;padding: 0 .3rem;" /> <em class="zy-c">{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}</em>
										<!--{/if}-->
									</div>
								</li>
							<!--{/if}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="newnumber">{lang trade_nums}</label></div>
								<div class="wblb-wbnr">
									<!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
										<input type="text" id="newnumber" name="newnumber" value="$tradelog[number]" class="guiigo-px zy-b s-a" style="width:100px" />
									<!--{else}-->
										<div class="wnmr-sznr zy-h">$tradelog[number]</div>
									<!--{/if}-->
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang post_trade_transport}</div>
								<div class="wblb-wbnr">
									<!--{if $tradelog['transport'] == 0}-->{lang post_trade_transport_offline}<!--{/if}-->
									<!--{if $tradelog['transport'] == 1}-->{lang post_trade_transport_seller}<!--{/if}-->
									<!--{if $tradelog['transport'] == 2}-->{lang post_trade_transport_buyer}<!--{/if}-->
									<!--{if $tradelog['transport'] == 3}-->{lang post_trade_transport_virtual}<!--{/if}-->
									<!--{if $tradelog['transport'] == 4}-->{lang post_trade_transport_physical}<!--{/if}-->
									<!--{if $tradelog['transport']}-->
										&nbsp;<em class="zy-c">{lang trade_transportfee}</em>
										<!--{if $tradelog[status] == 0 && $tradelog[sellerid] == $_G['uid']}--><input type="text" name="newfee" value="$tradelog['transportfee']" class="guiigo-px bg-e zy-b s-a" style="width:30%;padding: 0 .3rem;" />&nbsp;<!--{else}--><em class="zy-b">$tradelog[transportfee]</em>&nbsp;<!--{/if}-->
										<em class="zy-c">{lang payment_unit}</em>
									<!--{/if}-->
								</div>
							</li>
							<!--{if $tradelog['transport'] != 3}-->
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c"><label for="newbuyername">{lang trade_buyername}</label></div>
									<div class="wblb-wbnr"><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyername" name="newbuyername" value="$tradelog[buyername]" maxlength="50" class="guiigo-px s-a" /><!--{else}--><div class="wnmr-sznr zy-h">$tradelog[buyername]</div><!--{/if}--></div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c"><label for="newbuyercontact">{lang trade_buyercontact}</label></div>
									<div class="wblb-wbnr"><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyercontact" name="newbuyercontact" value="$tradelog[buyercontact]" maxlength="100" size="40" class="guiigo-px s-a" /><!--{else}--><div class="wnmr-sznr zy-h">$tradelog[buyercontact]</div><!--{/if}--></div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c"><label for="newbuyerzip">{lang trade_buyerzip}</label></div>
									<div class="wblb-wbnr"><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyerzip" name="newbuyerzip" value="$tradelog[buyerzip]" maxlength="10" class="guiigo-px s-a" /><!--{else}--><div class="wnmr-sznr zy-h">$tradelog[buyerzip]</div><!--{/if}--></div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c"><label for="newbuyerphone">{lang trade_buyerphone}</label></div>
									<div class="wblb-wbnr"><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyerphone" name="newbuyerphone" value="$tradelog[buyerphone]" maxlength="20" class="guiigo-px s-a" /><!--{else}--><div class="wnmr-sznr zy-h">$tradelog[buyerphone]</div><!--{/if}--></div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c"><label for="newbuyermobile">{lang trade_buyermobile}</label></div>
									<div class="wblb-wbnr"><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyermobile" name="newbuyermobile" value="$tradelog[buyermobile]" maxlength="20" class="guiigo-px s-a" /><!--{else}--><div class="wnmr-sznr zy-h">$tradelog[buyermobile]</div><!--{/if}--></div>
								</li>
							<!--{else}-->
								<input type="hidden" name="newbuyername" value="" />
								<input type="hidden" name="newbuyercontact" value="" />
								<input type="hidden" name="newbuyerzip" value="" />
								<input type="hidden" name="newbuyerphone" value="" />
								<input type="hidden" name="newbuyermobile" value="" />
							<!--{/if}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c" valign="top"><label for="newbuyermsg">{lang trade_seller_remark}</label></div>
								<div class="wblb-wbnr"><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyermsg" name="newbuyermsg" rows="5" class="guiigo-px s-a" value="$tradelog[buyermsg]"><!--{else}--><div class="wnmr-sznr zy-h">$tradelog[buyermsg]</div><!--{/if}--></div>
							</li>
							<!--{if $tradelog[status] == 0 && ($_G['uid'] == $tradelog['sellerid'] || $_G['uid'] == $tradelog['buyerid'])}-->
								<div class="gg-sq-ztan">
			
									 <input type="hidden" name="tradesubmit" value="true" />
									<button class="guiigo-pn mx-a ab-az zy-a zy-ac" type="button" onclick="formajax('#tradepost-form');">{lang trade_submit_order}</button>
								</div>
							<!--{/if}-->
						</ul>
					</div>
				</div>
				<!--{if $tradelog['offline'] && !empty($messagelist)}-->
					<div class="gg-sq-mjly ms-a bg-c sh-a xh-b">
						<h2 class="xh-b zy-h">{lang trade_message}</h2>
						<div class="mjly-lynr">
							<ul>
							<!--{loop $messagelist $message}-->
								<li class="xh-b">
									<div class="lynr-yhtx"><a href="home.php?mod=space&uid=$message[0]&do=profile" class="guiigo-ty"><!--{avatar($message[0],middle)}--></a></div>
									<div class="lynr-yhxx">
										<h2><a href="home.php?mod=space&uid=$message[0]&do=profile" class="zy-l">$message[1]</a><span class="zy-g">$message[2]</span></h2>
										<p class="zy-h">$message[3]</p>
									</div>
								</li>
							<!--{/loop}-->
							</ul>
						</div>
					</div>
				<!--{/if}-->
			</form>
			<!--{if $usertrades}-->
				<div class="gg-sq-qtsp ms-a bg-c sh-a xh-b">
					<h2 class="xh-b zy-h">$trade[seller] {lang trade_recommended_goods}</h2>
					<div class="gg-sq-sznr qtsp-yssd list-block-no cl">
						<ul>
						<!--{loop $usertrades $usertrade}-->
							<li>
								<!--{if $usertrade['displayorder'] > 0}--><div class="sznr-tjsp"><i class="icon guiigoapp-tuijian zy-m"></i></div><!--{/if}-->
								<a href="forum.php?mod=viewthread&tid=$usertrade[tid]&do=tradeinfo&pid=$usertrade[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}">
									<div class="sznr-sptp bg-e">
									<!--{if $usertrade['aid']}-->
										<img lazySrc="{echo getforumimg($usertrade[aid])}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
									<!--{else}-->
										<img lazySrc="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-wt.jpg" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
									<!--{/if}-->
										<span class="sptp-sysj ab-e zy-a zs-a">{lang guiigo_manage:tlang0348} $usertrade[totalitems] {lang guiigo_manage:tlang0349}</span>
									</div>
									<h4 class="zy-h sh-a">$usertrade[subject]</h4>
									<p class="sznr-pzdq zy-g">
										<!--{if $usertrade['quality'] == 1}--><span class="bg-j zy-a">{lang trade_new}</span><!--{elseif $usertrade['quality'] == 2}--><span class="bg-j zy-a">{lang trade_old}</span><!--{/if}-->
										<!--{if $usertrade[locus]}-->$usertrade[locus]<!--{/if}-->
									</p>
									<p class="sznr-jgjf zy-b">
										<!--{if $usertrade[price] > 0}-->
											<span>{lang guiigo_manage:tlang0347}</span>$usertrade[price]
										<!--{/if}-->
										<!--{if $_G['setting']['creditstransextra'][5] != -1 && $usertrade[credit]}-->
											<em class="zy-g"><!--{if $usertrade['price'] > 0}-->{lang trade_additional}<!--{/if}--> $usertrade[credit]{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</em>
										<!--{/if}-->
									</p>
								</a>
							</li>
						<!--{/loop}-->
						</ul>
					</div>
				</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
		function formajax(id) {
            var formobj = ck8(id).find("form");
			ck8.showPreloader('','load');
			ck8.ajax({
				type:'POST',
				url:formobj.attr('action') + '&cus=yes&inajax=1',
				data:formobj.serialize(),
				dataType:'xml',
				success: function(s){
					setTimeout(function(){ck8.hidePreloader()}, 200);
					var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
					if(Docs.indexOf("=='function')") != -1){
						if(app.Devalscript(Docs,'MsgCallTeagm',{}))return false;
					}
				}
			})
		}
		function MsgCallTeagm(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0350}') != -1 && param.type == 'tradepost'){
					ck8.toast('{lang guiigo_manage:tlang0351}');
					setTimeout(function(){
						ck8.router.load(msg.url,true);
					}, 2000)
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0365}') != -1 && param.type == 'tradepost'){
					ck8.toast('{lang guiigo_manage:tlang0365}');
					app.PageRefresh(false,'page',msg.url)
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}
	</script>
</div>
<!--{/if}-->
<!--{template common/footer}-->
