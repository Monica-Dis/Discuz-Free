<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page" data-mod="forumselect">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0301}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div style="display: none">
				<ul id="fs_group">$grouplist</ul>
				<ul id="fs_forum_common">$commonlist</ul>
				<!--{loop $forumlist $forumid $forum}-->
					<ul id="fs_forum_$forumid">$forum</ul>
				<!--{/loop}-->
				<!--{loop $subforumlist $forumid $forum}-->
					<ul id="fs_subforum_$forumid">$forum</ul>
				<!--{/loop}-->
			</div>
			<div style="display: none">
				<span class="pbnv">{$_G['setting']['bbname']}<span id="pbnv"></span> 
				<a id="enterbtn" class="xg1" href="javascript:;" onclick="locationforums(currentblock, currentfid)">[{lang nav_forum}]</a>
				</span>
			</div>
			<div class="gg-sq-ksft bg-c">
				<ul>
					<li id="block_group"></li>
					<li id="block_forum"></li>
					<li id="block_subforum"></li>
				</ul>
			</div>
			<!--{if $_G['group']['allowpost'] || !$_G['uid']}-->
				<div class="mn-a">
				<!--{if $special === null}-->
					<button id="postbtn" class="guiigo-pn ab-b zy-a" onclick="locations('forum.php?mod=post&action=newthread&fid=' + selectfid);" disabled="disabled">{lang send_posts}</button>
				<!--{else}-->
					<button id="postbtn" class="guiigo-pn ab-b zy-a" onclick="locations('forum.php?mod=post&action=newthread&fid=' + selectfid + '&special=$special');" disabled="disabled">$actiontitle</button>
				<!--{/if}-->
				</div>
			<!--{/if}-->
		</div>
	</div>
<script type="text/javascript">
	var currentblock =0,
		currentfid =0,
		lastswitchobj = null,
		selectfid = 0;
	var switchforum = switchsubforum = '';
	ck8(function() {
		var s = '<!--{if $commonfids}--><p><a id="commonforum" href="javascript:;" onclick="switchforums(this, 1, \'common\')" class="pbsb lightlink">{lang nav_forum_frequently}</a></p><!--{/if}-->';
		var lis = Dz('fs_group').getElementsByTagName('LI');
		for(i = 0;i < lis.length;i++) {
			var gid = lis[i].getAttribute('fid');
			if(Dz('fs_forum_' + gid)) {
				s += '<p><a href="javascript:;" ondblclick="locationforums(1, ' + gid + ')" onclick="switchforums(this, 1, ' + gid + ')" class="pbsb">' + lis[i].innerHTML + '</a></p>';
			}
		}
		Dz('block_group').innerHTML = s;
		switchforums(Dz('commonforum'), 1, 'common');
	})

	function switchforums(obj, block, fid) {
		if(lastswitchobj != obj) {
			if(lastswitchobj) {
				lastswitchobj.parentNode.className = '';
			}
			obj.parentNode.className = 'pbls';
		}
		var s = '';
		if(fid != 'common') {
			Dz('enterbtn').className = 'xi2';
			currentblock = block;
			currentfid = fid;
		} else {
			Dz('enterbtn').className = 'xg1';
		}
		if(block == 1) {
			var lis = Dz('fs_forum_' + fid).getElementsByTagName('LI');
			for(i = 0;i < lis.length;i++) {
				fid = lis[i].getAttribute('fid');
				if(fid != '') {
					s += '<p><a href="javascript:;" ondblclick="locationforums(2, ' + fid + '\)" onclick="switchforums(this, 2, ' + fid + ')"' + (Dz('fs_subforum_' + fid) ?  ' class="pbsb"' : '') + '>' + lis[i].innerHTML + '</a></p>';
				}
			}
			Dz('block_forum').innerHTML = s;
			Dz('block_subforum').innerHTML = '';
			switchforum = switchsubforum = '';
			selectfid = 0;
			Dz('postbtn').setAttribute("disabled", "disabled");
			Dz('postbtn').className = 'guiigo-pn ab-b zy-a';
		} else if(block == 2) {
			selectfid = fid;
			if(Dz('fs_subforum_' + fid)) {
				var lis = Dz('fs_subforum_' + fid).getElementsByTagName('LI');
				for(i = 0;i < lis.length;i++) {
					fid = lis[i].getAttribute('fid');
					s += '<p><a href="javascript:;" ondblclick="locationforums(3, ' + fid + ')" onclick="switchforums(this, 3, ' + fid + ')">' + lis[i].innerHTML + '</a></p>';
				}
				Dz('block_subforum').innerHTML = s;
			} else {
				Dz('block_subforum').innerHTML = '';
			}
			switchforum = obj.innerHTML;
			switchsubforum = '';
			Dz('postbtn').removeAttribute("disabled");
			Dz('postbtn').className = 'guiigo-pn ab-az zy-a zy-ac';
		} else {
			selectfid = fid;
			switchsubforum = obj.innerHTML;
			Dz('postbtn').removeAttribute("disabled");
			Dz('postbtn').className = 'guiigo-pn ab-az zy-a zy-ac';
		}
		lastswitchobj = obj;
		Dz('pbnv').innerHTML = switchforum ? '&nbsp;&gt;&nbsp;' + switchforum + (switchsubforum ? '&nbsp;&gt;&nbsp;' + switchsubforum : '') : '';
	}

	function locationforums(block, fid) {
		var urls = block == 1 ? 'forum.php?gid=' + fid : 'forum.php?mod=forumdisplay&fid=' + fid;
		ck8.router.load(urls, true);
	}
	function locations(url) {
		ck8.router.load(url, true);
	}
</script>
</div>
<!--{template common/footer}-->
