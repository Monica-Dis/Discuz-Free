<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div id="payform">
<form id="payform" 
	method="post" 
	autocomplete="off" 
	action="forum.php?mod=misc&action=pay&paysubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}"
	ck-cus="true"
	ck-param="{type:'modal',callpar:{pid:'$_GET[pid]'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="tid" value="$_G[tid]" />
	<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
		<div class="gg-sq-gmtc">
			<div class="gmtc-gmsj"><em class="zy-c">{lang author}</em><span class="zy-h">$thread[author]</span></div>
			<div class="gmtc-gmsj"><em class="zy-c">{lang price}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</em><span class="zy-b">$thread[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</span></div>
			<div class="gmtc-gmsj"><em class="zy-c">{lang pay_author_income}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</em><span class="zy-b">$thread[netprice] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</span></div>
			<div class="gmtc-gmsj"><em class="zy-c">{lang pay_balance}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</em><span class="zy-b">$balance {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</span></div>
		</div>
</form>
</div>
<!--{if !empty($_GET['infloat'])}-->
<script type="text/javascript" reload="1">
function succeedhandle_$_GET['handlekey'](locationhref) {
	<!--{if !empty($_GET['from'])}-->
		location.href = locationhref;
	<!--{else}-->
		ajaxget('forum.php?mod=viewthread&tid=$_G[tid]&viewpid=$_GET[pid]', 'post_$_GET[pid]');
		hideWindow('$_GET['handlekey']');
		showCreditPrompt();
	<!--{/if}-->
}
</script>
<!--{/if}-->
<!--{template common/footer}-->
