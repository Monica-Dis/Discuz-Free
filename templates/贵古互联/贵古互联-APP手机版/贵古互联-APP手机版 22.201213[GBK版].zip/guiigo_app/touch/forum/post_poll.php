<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<input type="hidden" name="polls" value="yes" />
<input type="hidden" name="fid" value="$_G[fid]" />
<!--{if $_GET[action] == 'newthread'}-->
	<input type="hidden" name="tpolloption" value="1" />
	<div class="guiigo-wblb list-block-no bg-c cl">
		<ul>
			<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang post_poll_comment}<div class="gg-fb-tpmq"><label for="pollchecked" class="guiigo-pds"><input id="pollchecked" type="checkbox" class="guiigo-pd-k" onclick="switchpollm(1)" /><span></span>{lang post_single_frame_mode}</label></div></li>
		</ul>
	</div>
	<div id="pollm_c_1" class="guiigo-wblb list-block-no bg-c cl">
		<ul>
			<div id="polloption_new"></div>
			<li id="polloption_hidden" class="guiigo-flex xh-b cl" style="display: none">
				<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0302}</div>
				<div class="wblb-wbnr zy-h"><input type="text" name="polloption[]" class="guiigo-px s-a" autocomplete="off" tabindex="1" placeholder="{lang guiigo_manage:tlang0303}"/></div>
				<span id="newpoll" class="poll-ttzs"></span>
				<a href="javascript:;" class="poll-sxan">
					<input type="file" name="pollUploadProgress" id="pollUploadProgress" class="mediaup" accept="image/*" onchange="pollfileup(this);"/>
					<i class="icon guiigoapp-tupian zy-f"></i>
				</a>
				<a href="javascript:;" class="poll-sxan" onclick="delpolloption(this)"><i class="icon guiigoapp-cuo zy-i"></i></a>
			</li>
			<li class="guiigo-flex cl"><a href="javascript:;" class="zy-l" onclick="addpolloption()">+{lang post_poll_add}</a></li>
		</ul>
	</div>
	<div id="pollm_c_2" class="guiigo-wblb list-block-no bg-c cl" style="display:none">
		<ul>
			<li class="wblb-nrsr xh-b zy-h cl">
				<div class="wblb-wbnr zy-h"><textarea name="polloptions" class="guiigo-pt s-a" tabindex="1" rows="6" onchange="switchpollm(0)" placeholder="{lang post_poll_comment_s}"/></textarea></div>
			</li>
		</ul>
	</div>
<!--{else}-->
	<div class="guiigo-wblb list-block-no ms-a bg-c cl">
		<ul>
			<!--{loop $poll['polloption'] $key $option}-->
				<!--{eval $ppid = $poll['polloptionid'][$key];}-->
				<li class="guiigo-flex xh-b cl">
					<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0302}</div>
					<input type="hidden" name="polloptionid[{$poll[polloptionid][$key]}]" value="$poll[polloptionid][$key]" />
					<div class="wblb-plpx">
						<input type="text" name="displayorder[{$poll[polloptionid][$key]}]" class="guiigo-px bg-g zy-f" autocomplete="off" tabindex="1" value="$poll[displayorder][$key]" />
					</div>
					
					<div class="wblb-wbnr zy-h">
						<input type="text" name="polloption[{$poll[polloptionid][$key]}]" class="guiigo-px s-a" autocomplete="off" tabindex="1" value="$option"{if !$_G['group']['alloweditpoll']} readonly="readonly"{/if} />
					</div>

				<span id="newpoll_{$key}" class="poll-ttzs">
				<!--{if $poll[isimage]}-->
					<div class="imgviwe">
						<div class="p_img">
					          <img style="height:54px;width:54px;" id="aimg_$poll[imginfo][$ppid][aid]" src="$poll[imginfo][$ppid][small]" />
						</div>
					</div>
					<!--{/if}-->
					<input type="hidden" name="pollimage[{$poll[polloptionid][$key]}]" id="pollUploadProgress_{$key}_aid" value="$poll[imginfo][$ppid][aid]" />
				</span>
				<a href="javascript:;" class="poll-sxan">
					<input type="file" name="pollUploadProgress_{$key}" id="pollUploadProgress_{$key}" class="mediaup" accept="image/*" onchange="pollfileup(this);"/>
					<i class="icon guiigoapp-tupian zy-f"></i>
				</a>
				</li>
			<!--{/loop}-->
			<div id="polloption_new"></div>
		</ul>
	</div>
	<li id="polloption_hidden" class="guiigo-flex xh-b cl" style="display: none">
		<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0302}</div>
		<div class="wblb-plpx">
			<input type="text" name="displayorder[]" class="guiigo-px bg-g zy-f" autocomplete="off" tabindex="1" />
		</div>
		<div class="wblb-wbnr zy-h">
			<input type="text" name="polloption[]" class="guiigo-px s-a" autocomplete="off" tabindex="1" placeholder="{lang guiigo_manage:tlang0303}"/>
		</div>
		<span id="newpoll" class="poll-ttzs"></span>
		<a href="javascript:;" class="poll-sxan">
			<input type="file" name="pollUploadProgress" id="pollUploadProgress" class="mediaup" accept="image/*" onchange="pollfileup(this);"/>
			<i class="icon guiigoapp-tupian zy-f"></i>
		</a>
		<a href="javascript:;" class="poll-sxan" onclick="delpolloption(this)"><i class="icon guiigoapp-cuo zy-i"></i></a>
	</li>
	<div class="gg-fb-plzj bg-c cl"><a href="javascript:;" class="zy-l" onclick="addpolloption()">+{lang post_poll_add}</a></div>
<!--{/if}-->
<div class="guiigo-wblb list-block-no ms-a sh-a bg-c cl">
	<ul>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="maxchoices">{lang post_poll_allowmultiple}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="maxchoices" id="maxchoices" class="guiigo-px s-a" value="{if $_GET[action] == 'edit' && $poll[maxchoices]}$poll[maxchoices]{else}1{/if}" tabindex="1" /></div>
			<div class="wblb-wbdw zy-g">{lang post_option}</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="polldatas">{lang post_poll_expiration}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="expiration" id="polldatas" class="guiigo-px s-a" value="{if $_GET[action] == 'edit'}{if !$poll[expiration]}0{elseif $poll[expiration] < 0}{lang poll_close}{elseif $poll[expiration] < TIMESTAMP}{lang poll_finish}{else}{echo (round(($poll[expiration] - TIMESTAMP) / 86400))}{/if}{/if}" tabindex="1" /></div>
			<div class="wblb-wbdw zy-g">{lang days}</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-f">{lang poll_after_result}</div>
			<div class="wblb-wbnr zy-h">
				<div class="guiigo-pc"><input type="checkbox" name="visibilitypoll" id="visibilitypoll" value="1"{if $_GET[action] == 'edit' && !$poll[visible]} checked{/if} tabindex="1" /><label for="visibilitypoll"><em></em></label></div>
			</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-f">{lang post_poll_overt}</div>
			<div class="wblb-wbnr zy-h">
				<div class="guiigo-pc"><input type="checkbox" name="overt" id="overt" value="1"{if $_GET[action] == 'edit' && $poll[overt]} checked{/if} tabindex="1" /><label for="overt"><em></em></label></div>
			</div>
		</li>
	</ul>
</div>
<script type="text/javascript" reload="1">
var maxoptions = parseInt('$_G[setting][maxpolloptions]');
<!--{if $_GET[action] == 'newthread'}-->
	var curoptions = 0;
	var curnumber = 1;
	ck8(function(){
		addpolloption();
		addpolloption();
		addpolloption();
	})
<!--{else}-->
	var curnumber = curoptions = <!--{echo count($poll['polloption'])}-->;
<!--{/if}-->

function switchpollm(swt) {
	t = Dz('pollchecked').checked && swt ? 2 : 1;
	var v = '';
	for(var i = 0; i < Dz('postform').elements.length; i++) {
		var e = Dz('postform').elements[i];
		if(!isUndefined(e.name)) {			
			if(e.name.match('^polloption')) {
				if(t == 2 && e.tagName == 'INPUT') {
					v += e.value + '\n';
				} else if(t == 1 && e.tagName == 'TEXTAREA') {
					v += e.value;
				}
			}
		}
	}
	if(t == 1) {
		var a = v.split('\n');
		var pcount = 0;
		for(var i = 0; i < Dz('postform').elements.length; i++) {
			var e = Dz('postform').elements[i];
			if(!isUndefined(e.name)) {
				if(e.name.match('^polloption')) {
					pcount++;
					if(e.tagName == 'INPUT') e.value = '';
				}
			}
		}
		for(var i = 0; i < a.length - pcount + 2; i++) {
			addpolloption();
		}
		var ii = 0;
		for(var i = 0; i < Dz('postform').elements.length; i++) {
			var e = Dz('postform').elements[i];
			if(!isUndefined(e.name)) {
				if(e.name.match('^polloption') && e.tagName == 'INPUT' && a[ii]) {
					e.value = a[ii++];
				}
			}
		}
	} else if(t == 2) {
		Dz('postform').polloptions.value = trim(v);

	}
	Dz('postform').tpolloption.value = t;
	if(swt) {
		_display('pollm_c_1');
		_display('pollm_c_2');
	}
}

function addpolloption() {
	if(curoptions < maxoptions) {
		var imgid = 'newpoll_'+curnumber;
		var proid = 'pollUploadProgress_'+curnumber;
		var pollstr = Dz('polloption_hidden').innerHTML.replace('newpoll', imgid);
		pollstr = pollstr.replace('name="pollUploadProgress', 'name="'+proid).replace('id="pollUploadProgress', 'id="'+proid);
		Dz('polloption_new').outerHTML = '<li class="guiigo-flex xh-b cl">' + pollstr + '</li>' + Dz('polloption_new').outerHTML;
		curoptions++;
		curnumber++;
	} else {
		ck8.toast('{lang guiigo_manage:tlang0304}'+maxoptions,'shibai');
	}
}

function delpolloption(obj) {
	obj.parentNode.parentNode.removeChild(obj.parentNode);
	curoptions--;
	var fobj = ck8(obj).parents()
	delFile(fobj)
}

function pollfileup(obj){
	var upid = ck8(obj).attr('id'),addid ='newpoll';
	var strs = upid.split("_");
	if(strs.length >=2){
	    addid =	'newpoll_'+ strs[1];
	}
 	app.ImgUpFile(obj,{
		upurl:SITEURL + 'misc.php?mod=swfupload&action=swfupload&operation=poll&fid=$_G[fid]',
		uid: '$_G[uid]',
		hash: "$swfconfig[hash]",
		maxsize: 2048,
		filetype:"*.jpg;*.jpeg;*.gif;*.png;*.bmp",
		callback:function(res){
			res = eval("("+res+")"); 
			if(!res.errorcode && res.aid){
				var htms = '<div class="imgviwe">\
							<span aid="'+ res.aid +'" class="icon guiigoapp-cuo bg-j zy-a" onclick="delFile(this);"></span>\
							<div class="p_img">\
								<img style="height:54px;width:54px;" id="aimg_'+ res.aid +'" src="'+ SITEURL + res.smallimg +'" />\
							</div>\
							<input type="hidden" name="pollimage[]" id="'+upid+'_aid" value="'+ res.aid +'">\
						</div>';
				$('#'+ addid).html(htms);
				$('#'+ upid).val('');
				$('#'+ upid).parents().attr('aid',res.aid);
			}else{
				ck8.toast('{lang guiigo_manage:tlang0305}','shibai');
			}
		}
	})
	
}
</script>
