<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="rate-view">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0318}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-sq-dsjf bg-c xh-b mx-a zy-f">
				<em class="zy-b">{lang total}:</em>&nbsp;
				<!--{loop $logcount $id $count}-->
				&nbsp;{$_G['setting']['extcredits'][$id][title]} <!--{if $count>0}-->+<!--{/if}-->$count {$_G['setting']['extcredits'][$id][unit]} &nbsp;
				<!--{/loop}-->
			</div>
			<div class="guiigo-hylb list-block-no sh-a xh-b bg-c">
				<ul class="ms-c">
					<!--{loop $loglist $log}-->
					<li class="sh-a">
						<a href="home.php?mod=space&uid=$log[uid]&do=profile" class="guiigo-tys">
							<!--{avatar($log[uid],middle)}-->
							<h2 class="zy-h"><i class="zy-c">$log[dateline]</i>$log[username]<span class="zy-b">{$_G['setting']['extcredits'][$log[extcredits]][title]} $log[score] {$_G['setting']['extcredits'][$log[extcredits]][unit]}</span></h2>
							<p class="zy-g">$log[reason]</p>
						</a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->
