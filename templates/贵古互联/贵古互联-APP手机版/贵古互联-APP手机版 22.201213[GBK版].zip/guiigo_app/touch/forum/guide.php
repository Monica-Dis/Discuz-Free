<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="guide">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="search.php?mod=forum" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-f"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0219}</h1>
	</header>
	<div class="content infinite-scroll guide-scroll" data-url="$theurl" data-pages="{$data[$view]['threadcount']}" data-ppp="{$perpage}" data-page="$_G['page']" data-islod="false" data-distance="10">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-sq-ddxc">
				<div class="ddxc-xctp"><a href="javascript:void(0)"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/ddbg.jpg" class="vm" /></a></div>
				<div class="guiigo-bwdx">
					<div class="guiigo-bwdx-a"></div>
					<div class="guiigo-bwdx-b"></div>
				</div>
			</div>
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-guide list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $currentview['hot']}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.guide-scroll','forum.php?mod=guide&view=hot',['gg-sq-ddlb']);">{lang guiigo_manage:tlang0220}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $currentview['digest']}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.guide-scroll','forum.php?mod=guide&view=digest',['gg-sq-ddlb']);">{lang guiigo_manage:tlang0221}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $currentview['newthread']}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.guide-scroll','forum.php?mod=guide&view=newthread',['gg-sq-ddlb']);">{lang guiigo_manage:tlang0222}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $currentview['new']}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.guide-scroll','forum.php?mod=guide&view=new',['gg-sq-ddlb']);">{lang guiigo_manage:tlang0223}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $currentview['sofa']}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.guide-scroll','forum.php?mod=guide&view=sofa',['gg-sq-ddlb']);">{lang guiigo_manage:tlang0224}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-sq-ddlb">
				<!--{loop $data $key $list}-->
					<!--{subtemplate forum/guide_list_row}-->
				<!--{/loop}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	function MsgCallFn(msg,par,param) {
		if(typeof msg === 'object' || typeof par === 'object'){
			var Obj = $('.followmod_'+ par.fuid +'');
			var foObj = $('#recommend_add_'+ param.tid +'');
			var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
				$.toast('{lang guiigo_manage:tlang0003}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
				Obj.attr('ck-confirm','true')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
				$.toast('{lang guiigo_manage:tlang0009}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
				Obj.attr('ck-confirm','false')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
				$.toast('{lang guiigo_manage:tlang0007}');
			}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
				foObj.addClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzanon"></i>');
				$('#recommend_add_sum'+ param.tid).html(''+ (recommendcut + parseInt(par.recommendv)));
				foObj.find('a').addClass('delRecommenus').removeClass('dialog').attr('href','plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid='+ param.tid)
				$.toast('{lang guiigo_manage:tlang0045}');
				if(par.daycount){
					setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
				}
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
				$.toast('{lang guiigo_manage:tlang0049}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
				$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
					$.router.load('home.php?mod=spacecp&ac=usergroup');
				});
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
				$.toast('{lang guiigo_manage:tlang0053}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
				$.toast('{lang guiigo_manage:tlang0055}');
			}else {
				$.toast(msg.msg);
			}
		}else{
			$.toast('{lang guiigo_manage:tlang0056}');
		}
	}
	</script>
</div>
<!--{template common/footer}-->
