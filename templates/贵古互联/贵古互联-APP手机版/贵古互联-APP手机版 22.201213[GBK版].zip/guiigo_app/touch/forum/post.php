<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval $attachlist = GuiigoApp::getAttachByTid($_GET['tid'],$_GET['pid']);}-->
<div class="page page-current" data-mod="post">
	<header class="bar bar-nav guiigo-nydb bg-c{if $_GET[action] != 'newthread'} xh-b{/if}">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<!--{if $_GET[action] == 'edit' && $isorigauthor && ($isfirstpost && $thread['replies'] < 1 || !$isfirstpost) && !$rushreply && $_G['setting']['editperdel']}-->
			<button type="button" class="button button-link pull-right" onclick="deleteThread();"><i class="icon guiigoapp-shanchu zy-i"></i></button>
		<!--{/if}-->
		<h1 class="gg-app-hide title zy-h"><!--{if $_GET[action] == 'newthread'}-->{lang guiigo_manage:tlang0086}<!--{elseif $_GET[action] == 'edit'}-->{lang guiigo_manage:tlang0227}<!--{elseif $_GET[action] == 'reply'}-->{lang guiigo_manage:tlang0148}<!--{/if}--></h1>
	</header>
	<div class="content post-scroll">
		<script type="text/javascript">
			var allowpostattach = parseInt('{$_G['group']['allowpostattach']}');
			var allowpostimg = parseInt('$allowpostimg');
			var pid = parseInt('$pid');
			var tid = parseInt('$_G[tid]');
			var extensions = '{$_G['group']['attachextensions']}';
			var imgexts = '$imgexts';
			var postminchars = parseInt('$_G['setting']['minpostsize']');
			var postmaxchars = parseInt('$_G['setting']['maxpostsize']');
			var disablepostctrl = parseInt('{$_G['group']['disablepostctrl']}');
			var seccodecheck = parseInt('<!--{if $seccodecheck}-->1<!--{else}-->0<!--{/if}-->');
			var secqaacheck = parseInt('<!--{if $secqaacheck}-->1<!--{else}-->0<!--{/if}-->');
			var typerequired = parseInt('{$_G[forum][threadtypes][required]}');
			var sortrequired = parseInt('{$_G[forum][threadsorts][required]}');
			var special = parseInt('$special');
			var isfirstpost = <!--{if $isfirstpost}-->1<!--{else}-->0<!--{/if}-->;
			var allowposttrade = parseInt('{$_G['group']['allowposttrade']}');
			var allowpostreward = parseInt('{$_G['group']['allowpostreward']}');
			var allowpostactivity = parseInt('{$_G['group']['allowpostactivity']}');
			var sortid = parseInt('$sortid');
			var special = parseInt('$special');
			var fid = $_G['fid'];
			var postaction = '{$_GET['action']}';
			var ispicstyleforum = <!--{if $_G['forum']['picstyle']}-->1<!--{else}-->0<!--{/if}-->;
		</script>
		<!--{if $_GET[action] == 'edit'}-->
		<!--{eval $editor[value] = $postinfo[message];}-->
		<!--{else}-->
		<!--{eval $editor[value] = $message;}-->
		<!--{/if}-->
		<!--{block actiontitle}-->
			<!--{if $_GET['action'] == 'newthread'}-->
				<!--{if $special == 0}-->{lang post_newthread}
				<!--{elseif $special == 1}-->{lang post_newthreadpoll}
				<!--{elseif $special == 2}-->{lang post_newthreadtrade}
				<!--{elseif $special == 3}-->{lang post_newthreadreward}
				<!--{elseif $special == 4}-->{lang post_newthreadactivity}
				<!--{elseif $special == 5}-->{lang post_newthreaddebate}
				<!--{elseif $specialextra}-->{$_G['setting']['threadplugins'][$specialextra][name]}
				<!--{/if}-->
			<!--{elseif $_GET['action'] == 'reply' && !empty($_GET['addtrade'])}-->
				{lang trade_add_post}
			<!--{elseif $_GET['action'] == 'reply'}-->
				{lang join_thread}
			<!--{elseif $_GET['action'] == 'edit'}-->
				<!--{if $special == 2}-->{lang edit_trade}<!--{else}-->{lang edit_thread}<!--{/if}-->
			<!--{/if}-->
		<!--{/block}-->
		<!--{block icon}-->
			<!--{if $special == 1}-->poll
			<!--{elseif $special == 2}-->trade
			<!--{elseif $special == 3}-->reward
			<!--{elseif $special == 4}-->activity
			<!--{elseif $special == 5}-->debate
			<!--{elseif $isfirstpost && $sortid}-->sort
			<!--{/if}-->
		<!--{/block}-->
		<!--{if $_GET['action'] != 'newthread'}-->
			<!--{eval $subjectcut = cutstr($thread[subject], 30);}-->
		<!--{/if}-->
		<!--{if $_GET[action] == 'newthread'}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-post list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<!--{if !$_G['forum']['threadsorts']['required'] && !$_G['forum']['allowspecialonly']}-->
						<li class="swiper-slide{if $postspecialcheck[0]} on{/if}"><a href="javascript:;" onclick="switchpost('forum.php?mod=post&action=newthread')">{lang guiigo_manage:tlang0123}</a><span class="bg-b"></span></li>
					<!--{/if}-->
					<!--{loop $_G['forum']['threadsorts'][types] $tsortid $name}-->
						<li class="swiper-slide{if $sortid == $tsortid} on{/if}"><a href="javascript:;" onclick="switchpost('forum.php?mod=post&action=newthread&sortid=$tsortid')"><!--{echo strip_tags($name);}--></a><span class="bg-b"></span></li>
					<!--{/loop}-->
					<!--{if $_G['group']['allowpostpoll']}-->
						<li class="swiper-slide{if $postspecialcheck[1]} on{/if}"><a href="javascript:;" onclick="switchpost('forum.php?mod=post&action=newthread&special=1')">{lang post_newthreadpoll}</a><span class="bg-b"></span></li>
					<!--{/if}-->
					<!--{if $_G['group']['allowpostreward']}-->
						<li class="swiper-slide{if $postspecialcheck[3]} on{/if}"><a href="javascript:;" onclick="switchpost('forum.php?mod=post&action=newthread&special=3')">{lang post_newthreadreward}</a><span class="bg-b"></span></li>
					<!--{/if}-->
					<!--{if $_G['group']['allowpostdebate']}-->
						<li class="swiper-slide{if $postspecialcheck[5]} on{/if}"><a href="javascript:;" onclick="switchpost('forum.php?mod=post&action=newthread&special=5')">{lang post_newthreaddebate}</a><span class="bg-b"></span></li>
					<!--{/if}-->
					<!--{if $_G['group']['allowpostactivity']}-->
						<li class="swiper-slide{if $postspecialcheck[4]} on{/if}"><a href="javascript:;" onclick="switchpost('forum.php?mod=post&action=newthread&special=4')">{lang guiigo_manage:tlang0127}</a><span class="bg-b"></span></li>
					<!--{/if}-->
					<!--{if $_G['group']['allowposttrade']}-->
						<li class="swiper-slide{if $postspecialcheck[2]} on{/if}"><a href="javascript:;" onclick="switchpost('forum.php?mod=post&action=newthread&special=2')">{lang guiigo_manage:tlang0128}</a><span class="bg-b"></span></li>
					<!--{/if}-->
					<!--{if $_G['setting']['threadplugins']}-->
						<!--{loop $_G['forum']['threadplugin'] $tpid}-->
							<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
								<li{if $specialextra==$tpid} class="a"{/if}><a href="javascript:;" onclick="switchpost('forum.php?mod=post&action=newthread&specialextra=$tpid')">{$_G[setting][threadplugins][$tpid][name]}</a><span class="bg-b"></span></li>
							<!--{/if}-->
						<!--{/loop}-->
					<!--{/if}-->
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
		<!--{/if}-->		
		<div class="list-block" id="del-postform">
			<!--{eval $adveditor = $isfirstpost && $special || $special == 2 && ($_GET['action'] == 'newthread' || $_GET['action'] == 'reply' && !empty($_GET['addtrade']) || $_GET['action'] == 'edit' && $thread['special'] == 2);}-->
			<!--{eval $advmore = !$showthreadsorts && !$special || $_GET['action'] == 'reply' && empty($_GET['addtrade']) || $_GET['action'] == 'edit' && !$isfirstpost && ($thread['special'] == 2 && !$special || $thread['special'] != 2);}-->
			<form method="post" autocomplete="off" id="postform"
				{if $_GET[action] == 'newthread'}action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes"
				{elseif $_GET[action] == 'reply'}action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes"
				{elseif $_GET[action] == 'edit'}action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes" $enctype
				{/if}
				ck-cus="true" 
				ck-param="{type:'modal',load:'true',fn:'MsgCallPost',callpar:{type:'post'},uid:'$_G[uid]'}">
				<!--{if $_GET[action] == 'edit' && $isorigauthor && ($isfirstpost && $thread['replies'] < 1 || !$isfirstpost) && !$rushreply && $_G['setting']['editperdel']}-->
					<input type="hidden" name="delete" id="delete" value="0" />
				<!--{/if}-->
				<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
				<input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}" />
				<!--{if $_GET['action'] == 'edit'}-->
					<input type="hidden" name="delattachop" id="delattachop" value="0" />
				<!--{/if}-->
				<!--{if !empty($_GET['modthreadkey'])}--><input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" /><!--{/if}-->
				<input type="hidden" name="wysiwyg" id="{$editorid}_mode" value="$editormode" />
				<!--{if $_GET[action] == 'reply'}-->
					<input type="hidden" name="noticeauthor" value="$noticeauthor" />
					<input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
					<input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
					<!--{if $reppid}-->
						<input type="hidden" name="reppid" value="$reppid" />
					<!--{/if}-->
					<!--{if $_GET[reppost]}-->
						<input type="hidden" name="reppost" value="$_GET[reppost]" />
					<!--{elseif $_GET[repquote]}-->
						<input type="hidden" name="reppost" value="$_GET[repquote]" />
					<!--{/if}-->
				<!--{/if}-->
				<!--{if $_GET[action] == 'edit'}-->
					<input type="hidden" name="fid" id="fid" value="$_G[fid]" />
					<input type="hidden" name="tid" value="$_G[tid]" />
					<input type="hidden" name="pid" value="$pid" />
					<input type="hidden" name="page" value="$_GET[page]" />
				<!--{/if}-->
				<!--{if $special}-->
					<input type="hidden" name="special" value="$special" />
				<!--{/if}-->
				<!--{if $specialextra}-->
					<input type="hidden" name="specialextra" value="$specialextra" />
				<!--{/if}-->
				<div class=""{if !$showthreadsorts && !$adveditor} id="editorbox"{/if}>
					<div id="postbox" class="gg-fb-fbon">
						<script>
						function switchpost(href) {
							 href = href + '&fid=$_G[fid]<!--{if !empty($_G[tid])}-->&tid=$_G[tid]<!--{/if}--><!--{if !empty($modelid)}-->&modelid=$modelid<!--{/if}-->&extra=$extra';
							 app.PageRefresh(false,'list-block',href)
						}
						</script>
						<!--{subtemplate forum/post_editor_extra}-->
						<div class="fbon-txim">
							<!--{if $_GET[action] != 'reply'}--><div class="txim-bt bg-g xh-b zy-c">{lang guiigo_manage:tlang0228}</div><!--{/if}-->
							<div class="txim-tx bg-c"><textarea name="$editor[textarea]" id="needmessage" class="guiigo-pt zy-e" rows="15" tabindex="2" placeholder="{lang guiigo_manage:tlang0229}">$editor[value]</textarea></div>
							<div class="txim-im bg-c cl" id="imglist">
								<!--{if $allowpostimg}-->
									<div class="txim-scan">
										<a href="JavaScript:void(0)" class="bg-e zy-c bk-d">
											<i class="icon guiigoapp-tpscjh zy-g"></i>
											<input 
												type="file" 
												name="Filedata" 
												class="mediaup" 
												accept="image/*" 
												multiple="multiple" 
												onchange="fileup(this);"/>
										</a>
									</div>
								<!--{/if}-->
								<!--{loop $attachlist $attachval}-->
								<div class="imgviwe" id="delattac_{$attachval['aid']}"{if $attachval['isimage'] !=1} style="display:none;"{/if}>
									<div class="p_img">
										<img style="height:54px;width:54px;" src="{$attachval['attachment']}">
									</div>
									<a class="p_input" href="javascript:;" 
										data-aid="{$attachval['aid']}" 
										data-isimage="{$attachval['isimage']}" 
										data-tid="{$_GET['tid']}" 
										data-pid="{$_GET['pid']}" 
										onclick="delattac(this);">{lang guiigo_manage:tlang0992}</a>
								</div>
								<!--{/loop}-->
							</div>
						</div>
						<!--{subtemplate forum/post_editor_attribute}-->
						<!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
						<div class="gg-fb-yzmy xh-b">
							<!--{subtemplate common/seccheck}-->
						</div>
						<!--{/if}-->
						<div class="mn-a">
							<button type="button" id="postsubmit" class="guiigo-pn ab-az zy-a zy-ac" value="true" onclick="Postreyl()" name="{if $_GET[action] == 'newthread'}topicsubmit{elseif $_GET[action] == 'reply'}replysubmit{elseif $_GET[action] == 'edit'}editsubmit{/if}">
							<!--{if $_GET[action] == 'newthread'}-->
								<!--{if $special == 0}-->{lang post_newthread}
								<!--{elseif $special == 1}-->{lang guiigo_manage:tlang0230}
								<!--{elseif $special == 2}-->{lang post_newthreadtrade}
								<!--{elseif $special == 3}-->{lang guiigo_manage:tlang0231}
								<!--{elseif $special == 4}-->{lang post_newthreadactivity}
								<!--{elseif $special == 5}-->{lang guiigo_manage:tlang0232}
								<!--{elseif $special == 127}-->
									<!--{if $buttontext}-->$buttontext<!--{else}-->{lang post_newthread}<!--{/if}-->
								<!--{/if}-->
							<!--{elseif $_GET[action] == 'reply' && !empty($_GET['addtrade'])}-->{lang trade_add_post}
							<!--{elseif $_GET[action] == 'reply'}-->{lang join_thread}
							<!--{elseif $_GET[action] == 'edit' && $isfirstpost && $thread['displayorder'] == -4}-->
								{lang post_newthread}
							<!--{elseif $_GET[action] == 'edit'}-->{lang edit_save}
							<!--{/if}-->
							</button>
						</div>
						<!--{hook/post_bottom_mobile}-->
					</div>
				</div>
			</form>
		<script type="text/javascript">
		<!--{if !empty($userextcredit)}-->
			var have_replycredit = 0;
			var creditstax = $_G['setting']['creditstax'];
			var replycredit_result_lang = "{lang replycredit_revenue}{$_G['setting']['extcredits'][$extcreditstype][title]} ";
			var userextcredit = $userextcredit;
			<!--{if $thread['replycredit'] > 0}-->
				have_replycredit = {$thread['replycredit']};
			<!--{/if}-->
		<!--{/if}-->
		var upload = {
			url: "{$_G[siteurl]}misc.php?mod=swfupload&action=swfupload&operation=upload&fid=$_G[fid]&simple=2",
			params: {"uid" : "$_G[uid]", "hash":"$swfconfig[hash]"},
			filesize : "$swfconfig[max]",
			filetypes : "$_G['group']['attachextensions']",
		}
		ck8(function(){
			ck8("#rushreplyfrom").datetimePicker({});
			ck8("#rushreplyto").datetimePicker({});
		})
		
		function delattac(obj){
			var othis = ck8(obj),
				isimage = othis.attr('data-isimage'),
				tid = othis.attr('data-tid'),
				pid = othis.attr('data-pid'),
				aid = othis.attr('data-aid');
			if(!aid) return;
			ck8.showPreloader('',true);
			ck8.get('forum.php?mod=ajax&action=deleteattach&inajax=yes&tid='+ tid +'&pid='+ pid +'&aids[]=' + aid,
				function(s) {
					setTimeout(function(){$.hidePreloader()}, 100);
					ck8('#delattac_'+aid).remove();
					var _val = ck8('#needmessage').val();
					var rep = '[attach]' + aid + '[/attach]';
					if(parseInt(isimage) == 1){
						rep = '[attachimg]' + aid + '[/attachimg]';
					}
					ck8('#needmessage').val(_val.replace(rep,''));
				}
			)
		}
		function fileupattach(obj){
			if(ck8(obj).length == 0){
				ck8.toast('{lang guiigo_manage:tlang1013}');
				ck8(obj).val('');
				return;
			}
            var file = ck8(obj)[0].files[0];
			var fileSize = 0,fileSizeExt = '', fileSize2='';
			if (file) {
			    fileSize = Math.floor(file.size * 100 / 1024) / 100;
				fileSizeExt = file.name.substr((file.name.lastIndexOf("."))+1);
				if (file.size > 1024 * 1024){
				    fileSize2 = (Math.round(file.size * 100 / (1024 * 1024)) / 100).toString() + 'MB';
				}else{
				    fileSize2 = (Math.round(file.size * 100 / 1024) / 100).toString() + 'KB';
				}
			}
            if(upload.filesize && fileSize > parseInt(upload.filesize)){
				ck8.toast('{lang guiigo_manage:tlang1014}'+fileSize2+'{lang guiigo_manage:tlang1015}');
				ck8(obj).val('');
				return;
			}
			if(upload.filetypes && upload.filetypes.indexOf(fileSizeExt) == -1){
				ck8.toast('{lang guiigo_manage:tlang1016}'+upload.filetypes);
				ck8(obj).val('');
				return;
			}
			var fd = new FormData();
			fd.append("Filedata", file);
			fd.append("uid",upload.params.uid);
			fd.append("hash",upload.params.hash);
			var xhr = new XMLHttpRequest();
			xhr.upload.addEventListener("progress", function (evt) {
				if (evt.lengthComputable) {
					var percentComplete = Math.round(evt.loaded * 100 / evt.total);
					ck8('#fileupprogress').css({"width":+percentComplete+"%","display":"block"});
					ck8('#anyswzkz').css({"color":"#ffffff"});
					ck8('#anyswzkz').html('{lang guiigo_manage:tlang1030}');
				}
			}, false);
			xhr.addEventListener("load", function (evt) {
				if (evt.target.readyState == 4 && evt.target.status == 200) {
					var data = evt.target.responseText;
					if(data == '') {
						ck8.toast('{lang uploadpicfailed}');
					}
					var dataarr = data.split('|');
					if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
						var html = '<div class="imgviwe xh-b" id="delattac_'+dataarr[3]+'">'
						+ '<img src="template/guiigo_app/static/images/guiigo-fj.png">'
						+ '<a class="p_input" href="javascript:;" data-aid="'+dataarr[3]+'" data-isimage="" data-tid="0" data-pid="0" onclick="delattac(this);">{lang guiigo_manage:tlang0685}</a>'
						+	 '<div class="setting cl">'
						+		'<div class="ction atds"><span>{lang guiigo_manage:tlang0991}</span><input type="text" name="attachnew['+dataarr[3]+'][description]" '
						+		'class="px" value="" size="6" style="float: left;width: 89%;padding: 0 2%;height: 22px;line-height: 22px;border: 0;'
						+		'border-radius: 2px;background: #f7f7f7;"/></div>'
								<!--{if $_G['group']['allowsetattachperm']}-->
						+		'<div class="ction attv">'
						+		   '<span>{lang guiigo_manage:tlang1009}</span>'
									<!--{if $_G['cache']['groupreadaccess']}-->
						+			'<input type="text" class="guiigo-ps s-a select-picker" value="{lang guiigo_manage:tlang1023}" data-select="readperm3"'
						+			'style="float: left;width: 70%;height: 22px;line-height: 22px;padding-left: 5px;border: 0;color: #000;border-radius: 2px;'
						+			'background-color: #f7f7f7;background-position: 95%;background-size: .35rem auto;">'
						+			'<select class="ps" name="attachnew['+dataarr[3]+'][readperm]" id="readperm3" tabindex="1"'
						+			        'style="display: none;">'
						+					'<option value="">{lang guiigo_manage:tlang1023}</option>'
										<!--{loop $_G['cache']['groupreadaccess'] $val3}-->
						+					'<option value="{$val3[readaccess]}">{$val3[grouptitle]}</option>'
										<!--{/loop}-->
						+					'<option value="255">{lang guiigo_manage:tlang1024}</option>'
						+			'</select>'
									<!--{/if}-->
						+		'</div>'
								<!--{/if}-->
								<!--{if $_G['group']['maxprice']}-->
						+		'<div class="ction attpr">'
						+			'<span>{lang guiigo_manage:tlang1025}</span>'
						+			'<input type="text" name="attachnew['+dataarr[3]+'][price]" class="px" value="" '
						+			'size="1" style="float: left;width: 50%;padding: 0 1%;height: 22px;line-height: 22px;border: 0;border-radius: 2px;background: #f7f7f7;"/>'
						+			'<span class="fj-dw">$_G[setting][extcredits][$_G[setting][creditstransextra][1]][title]</span>'
						+		'</div>'
								<!--{/if}-->
						+		'</div>'
						+ '</div>';
						ck8('#fjon').append(html);
						initSelect(ck8('#fjon'));
					} else {
						var sizelimit = '';
						if(dataarr[7] == 'ban') {
							sizelimit = '{lang uploadpicatttypeban}';
						} else if(dataarr[7] == 'perday') {
							sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
						} else if(dataarr[7] > 0) {
							sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
						}
						ck8.toast(STATUSMSG[dataarr[2]] + sizelimit);
					}
				}
				ck8('#fileupprogress').css({"width":"0%","display":"none"});
				ck8('#anyswzkz').css({"color":"#929292"});
				ck8('#anyswzkz').html('<i class="icon guiigoapp-shangchuan"></i>{lang guiigo_manage:tlang1022}');
			}, false);
			xhr.addEventListener("error", function(){
				ck8.toast('{lang guiigo_manage:tlang1017}');
				ck8(obj).val('');
				ck8('#fileupprogress').css({"width":"0%","display":"none"});
				ck8('#anyswzkz').css({"color":"#929292"});
				ck8('#anyswzkz').html('<i class="icon guiigoapp-shangchuan"></i>{lang guiigo_manage:tlang1022}');
			}, false);
			xhr.open("POST", upload.url);
			xhr.send(fd);
		}

		function deleteThread() {
			ck8.confirm('{lang guiigo_manage:tlang0233}','{lang guiigo_manage:tlang0234}', function (){
				ck8('#delete').val(1);
			    app.FormDialog('#del-postform')
			})
		}
		
		function Postreyl() {
			if(validate('#del-postform')){
				 app.FormDialog('#del-postform')
			}
		}
		
		function MsgCallPost(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0235}') != -1 && param.type == 'post'){
					ck8.toast('{lang guiigo_manage:tlang0236}');
					setcookie('forumdisplay_newpost', 'forum.php?mod=forumdisplay&fid='+par.fid);
					setTimeout(function(){
						ck8.router.back();
					},1000)
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0213}') != -1 && param.type == 'post'){
					ck8.toast('{lang guiigo_manage:tlang0239}');
					setcookie('viewthread_fn', 'addViewthreadViewpid');
					setcookie('viewthread_fn_par', par.tid+'_'+par.pid);
					setTimeout(function(){
						ck8.router.back();
					},1000)
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0240}') != -1 && param.type == 'post'){
					ck8.toast('{lang guiigo_manage:tlang0237}');
					setcookie('forumdisplay_newpost', msg.url);
					setcookie('delpost', 1);
					setTimeout(function(){
						ck8.router.back()
					},1000)
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0241}') != -1 && param.type == 'post'){
					ck8.toast('{lang guiigo_manage:tlang0238}');
					setcookie('eitpost',par.pid+'_'+par.tid);
					setTimeout(function(){
						ck8.router.back()
					},1000)
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0242}') != -1 && param.type == 'post'){
	                ck8.toast(msg.msg,'shibai');
	                seccode(ck8('.seccodeimg'))
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}

		function fileup(obj){
			app.ImgUpFile(obj)
		}

		function updatesortattach(aid, url, attachurl, identifier) {
			Dz('sortaid_' + identifier).value = aid;
			Dz('sortattachurl_' + identifier).value = attachurl + '/' + url;
			Dz('sortattach_image_' + identifier).innerHTML = '<img src="' + attachurl + '/' + url + '" class="spimg" />';
			ATTACHORIMAGE = 1;
		}

		function tabMun(e){
			var classMun = ck8(e).attr('data-meun')
			ck8('.tabmuns').find('a').removeClass('bk-ba zy-be').addClass('bk-e zy-g');
			ck8(e).find('a').removeClass('bk-e zy-g').addClass('bk-ba zy-be');
			ck8('.tabmunszml').find('.hidesmun').each(function(index, obj){
				ck8(obj).css('display','none')
			})
			ck8('.'+classMun).css('display','block')
			if(classMun == 'at_menu'){
				app.loadScript('at',function(){
					setTimeout(function(){
						at_friend()
						ck8('#at_list').on('click','a',function(){
							ck8('.tabmuns').find('a').removeClass('bk-ba zy-be').addClass('bk-e zy-g');
						})
					},500)
				})
			}
		}

		function tabPost(e){
			var classMun = ck8(e).attr('data-meun')
			ck8('.tabanv').find('a').removeClass('zy-be').addClass('zy-g');
			ck8(e).find('a').removeClass('zy-g').addClass('zy-be');
            var gnonisopen = ck8('.gnon-'+classMun).css('display');
			if(gnonisopen == 'block'){
				ck8('.gnon-'+classMun).hide()
				ck8(e).find('a').removeClass('zy-be').addClass('zy-g');
			}else if(gnonisopen == 'none'){
				ck8('#gnon-onks').find('.hides').each(function(index, obj){
					ck8(obj).hide();
				}) 
				ck8('.gnon-'+classMun).show()
			}
			if(classMun == 'bqs'){
				app.loadScript('smiliess');
				app.loadStyle('cssswiper-4.3.3.min');
				app.loadScript('jsswiper-4.3.3.min',function(){
					new Swiper('.ck8-smiliestabs', {
						slidesPerView : 8,
						slideToClickedSlide : true,
						freeMode : true,
						observer : true,
						observeParents : true,
					})
					new Swiper('.ck8-smiliestab', {
						observer : true,
						observeParents : true,
						pagination: {
							el: '.swiper-pagination',
						}
					})
					ck8('.ck8-smiliestabs').css({'visibility':'visible'});
					setTimeout(function(){
						smilies_show(39, 'ck8-')
					},300)
				})
			}else if(classMun == 'cr'){
				$('#gnjt-mp3').click(function(){
					if($("#gncr-pm3").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0243}');
					}else{
						$("#needmessage").val($("#needmessage").val()+"[audio]"+$("#gncr-pm3").val()+"[/audio]");
					}
					return;
				});
				$('#gnjt-wzlj').click(function(){
					if($("#gncr-ljwz").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0244}');
					}else if($("#gncr-ljzs").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0245}');
					}else{
						$("#needmessage").val($("#needmessage").val()+"[url="+$("#gncr-ljwz").val()+"]"+$("#gncr-ljzs").val()+"[/url]");
					}
					return;
				});
				$('#gnjt-wltp').click(function(){
					if($("#gncr-wltp").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0246}');
					}else{
						$("#needmessage").val($("#needmessage").val()+"[img]"+$("#gncr-wltp").val()+"[/img]");
					}
					return;
				});
				$('#gnjt-yynr').click(function(){
					if($("#gncr-yynr").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0247}');
					}else{
						$("#needmessage").val($("#needmessage").val()+"[quote]"+$("#gncr-yynr").val()+"[/quote]");
					}
					return;
				});
				$('#gnjt-mp4').click(function(){
					if($("#gncr-pm4").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0248}');
					}else{
						$("#needmessage").val($("#needmessage").val()+"[media=x,500,380]"+$("#gncr-pm4").val()+"[/media]");
					}
					return;
				});
				$('#gnjt-flas').click(function(){
					if($("#gncr-flas").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0249}');
					}else{
						$("#needmessage").val($("#needmessage").val()+"[flash]"+$("#gncr-flas").val()+"[/flash]");
					}
					return;
				});
				$('#gnjt-mfxx').click(function(){
					if($("#gncr-mfxx").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0250}');
					}else{
						$("#needmessage").val($("#needmessage").val()+"[free]"+$("#gncr-mfxx").val()+"[/free]");
					}
					return;
				});
				$('#gnjt-dmnr').click(function(){
					if($("#gncr-dmnr").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0251}');
					   
					}else{
						$("#needmessage").val($("#needmessage").val()+"[code]"+$("#gncr-dmnr").val()+"[/code]");
					}
					return;
				});
				$('#gnjt-mmzt').click(function(){
					if($("#gncr-mmzt").val() == ''){
						ck8.toast('{lang guiigo_manage:tlang0216}');
					}else{
						$("#needmessage").val($("#needmessage").val()+"[password]"+$("#gncr-mmzt").val()+"[/password]");
					}
					return;
				});
			}
		}
		</script>
		{$guiigo_config['footer_html']}
		</div>
	</div>
</div>
<!--{template common/footer}-->


