<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval $firstpid=$_G['forum_firstpid'];}-->
<!--{eval $postlist = GuiigoApp::getviewthreadList($postlist);}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="viewthread">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back gg-nyto-bj" style="width: 1.25rem;">
			<i class="icon guiigoapp-xzfh zy-f"></i>
		</a>
		<!--{else}-->
		<a class="button button-link pull-left open-panel anvbk gg-nyto-bj" style="width: 1.25rem;margin-left: 0;display:none;">
			<i class="icon guiigoapp-caidan zy-f"></i>
		</a>
		<a class="button button-link pull-left back anvbks gg-nyto-bj" style="width: 1.25rem;">
			<i class="icon guiigoapp-xzfh zy-f"></i>
		</a>
		<!--{/if}-->
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-f" style="font-size: 1rem;"></i></a>
		<h1 class="gg-nytp-xq title zy-h">{lang guiigo_manage:tlang0369}</h1>
		<div class="gg-nyto-yh" style="display: none;">
			<a href="home.php?mod=space&uid={$_G[forum_thread][authorid]}&do=profile&view=me&mobile=2" class="nyto-yhxx guiigo-ty"><img src="<!--{avatar($_G[forum_thread][authorid], middle, true)}-->"><em class="zy-h">{$_G[forum_thread][author]}</em></a>
			<!--{if $_G['forum_thread']['authorid'] != $_G[uid]}-->
				<!--{if $postlist[$firstpid]['isfollow'] ==1}-->
					<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$_G['forum_thread']['authorid']" 
					class="followmod_$_G['forum_thread']['authorid'] dialog mcxx-gzan zy-c bk-c bg-e" 
					ck-cus="true" 
					ck-confirm="true" 
					ck-param="{type:'modal',callpar:{tid:'$_G['forum_thread']['authorid']'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}" 
					external >{lang guiigo_manage:tlang0003}</a>
				<!--{else}-->
					<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$_G['forum_thread']['authorid']" 
					class="followmod_$_G['forum_thread']['authorid'] dialog mcxx-gzan zy-b bk-b"
					ck-cus="true"
					ck-confirm="false"
					ck-param="{type:'modal',callpar:{tid:'$_G['forum_thread'][authorid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}"
					external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
				<!--{/if}-->
			<!--{/if}-->
		</div>
	</header>
	<!--{eval 
		$murl = 'forum.php?mod=viewthread&tid='.$_G['tid'].
			($_G['forum_thread']['is_archived'] ? '&archive='.$_G['forum_thread']['archiveid'] : '').
			'&amp;extra='.$_GET['extra'].
			($ordertype && $ordertype != getstatus($_G['forum_thread']['status'], 4) ? '&amp;ordertype='.$ordertype : '').
			(isset($_GET['highlight']) ? '&amp;highlight='.rawurlencode($_GET['highlight']) : '').
			(!empty($_GET['authorid']) ? '&amp;authorid='.$_GET['authorid'] : '').
			(!empty($_GET['from']) ? '&amp;from='.$_GET['from'] : '').
			(!empty($_GET['checkrush']) ? '&amp;checkrush='.$_GET['checkrush'] : '').
			(!empty($_GET['modthreadkey']) ? '&amp;modthreadkey='.rawurlencode($_GET['modthreadkey']) : '').$specialextra;
	}-->
	<div class="content infinite-scroll post-scroll content-bts" 
		data-url="$murl" 
		data-pages="{eval echo $_G['forum_thread']['replies'] + 1}" 
		data-ppp="{$_G['ppp']}" 
		data-page="$page" 
		data-islod="false"
		data-distance="10">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<!--{if $_G['forum']['ismoderator']}--><li><a href="javascript:;" class="zy-f xh-b" onclick="app.ActionsManage('#guiigo-lcgl-lzgl','t', 'auto');"><i class="icon guiigoapp-shezhi"></i>{lang guiigo_manage:tlang0367}</a></li><!--{/if}-->
						<!--{if !$_G['forum']['ismoderator']}-->
							<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
								<li><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="zy-f xh-b"><i class="icon guiigoapp-fbxhfb"></i>{lang guiigo_manage:tlang0227}</a></li>
							<!--{/if}-->
						<!--{/if}-->
						<!--{if $guiigo_config['isguiigoapp']}-->
						<li><a href="javascript:;" onclick="appShareAllview('#share_title','#share_img','#share_img');" class="zy-f xh-b"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						<!--{else}-->
						<li><a href="javascript:;" onclick="app.ActionsManage('.guiigo-nrdbfx-f','t', 'auto','guiigo-hdfx');" class="zy-f xh-b"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						<!--{/if}-->
						<!--{if !$_G['forum_thread']['archiveid']}-->
							<li>
								<a href="misc.php?mod=report&rtype=post&rid=$firstpid&tid=$_G[tid]&fid=$_G[fid]" 
									class="blue-inner dialog zy-f xh-b"
									ck-cus="true" 
									ck-param="{type:'modal',load:'true',uid:'$_G[uid]',fn:'MsgCallReport'}"
									external >
								<i class="icon guiigoapp-tbxhjb"></i>{lang guiigo_manage:tlang0368}</a>
							</li>
						<!--{/if}-->
						<li><a href="javascript:;" class="zy-f"><i class="icon guiigoapp-ggztid"></i>$_G[tid]</a></li>
					</ul>
				</div>
			</div>
			<div id="gg-sq-nrzt" class="gg-sq-nrzt list-container">
				<!--{hook/viewthread_top_mobile}-->
				<!--{eval $postcount = 0;}-->
				<!--{loop $postlist $post}-->
				<!--{if $post[first]}-->
					<!--{if $guiigo_config['appsetting']['forumstyle'][$_G[fid]]['forum_style'] != 4}-->
					<div class="gg-sq-ztbt bg-c">
						<!--{if $_G['forum_thread'][displayorder] == -2}--><span class="zy-i">{lang moderating}</span><!--{elseif $_G['forum_thread'][displayorder] == -3}--><span class="zy-i">{lang have_ignored}</span><!--{elseif $_G['forum_thread'][displayorder] == -4}--><span class="zy-i">{lang draft}</span><!--{/if}--><em class="zy-e" id="share_title">$_G[forum_thread][subject]</em>
						<!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
							<div class="ztbt-zttz"><img src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" /></div>
						<!--{/if}-->
					</div>
					<!--{/if}-->
					<!--{if $_G['forum_thread']['replycredit'] > 0 }-->
					<div class="gg-sq-hbzt bg-c">
						<div class="hbzt-on zy-i">
							<i class="icon guiigoapp-htjl zy-i"></i>
							{lang guiigo_manage:tlang1029} {$_G['forum_thread']['replycredit']}{$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][unit]} {$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][title]}
							<br/>{lang thread_replycredit_tips1} {lang thread_replycredit_tips2}<!--{if $_G['forum_thread']['replycredit_rule'][random] > 0}--> {lang thread_replycredit_tips3}<!--{/if}-->
						</div>
					</div>
					<!--{/if}-->
				<!--{/if}-->
				<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
				<!--{hook/viewthread_posttop_mobile $postcount}-->
				<div class="gg-sq-ztmk bg-c<!--{if !$post[first]}--> sh-a<!--{/if}--> cl" id="pid$post[pid]">
				    <!--{subtemplate forum/topicadmin_modmenu}-->
					<div class="gg-sq-lzxx<!--{if $post[first]}--> gg-sq-flyl<!--{/if}-->">
						<div class="guiigo-ty<!--{if $post[first]}--> lzxx-lztx<!--{else}--> lzxx-hftx<!--{/if}-->"><!--{if !$post['authorid'] || $post['anonymous']}--><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg"><!--{else}--><a href="javascript:;" onclick="app.ActionsManage('#guiigo-lchd-$post[pid]','t', 'auto');"><img src="<!--{avatar($post[authorid], middle, true)}-->"<!--{if !$post['first'] && $post['rewardfloor']}--> class="bk-ba"<!--{/if}-->></a><!--{/if}--></div>
						<!--{if !$post['first'] && $post['rewardfloor']}-->
							<div class="gg-sq-qzlc bg-b zy-a">{lang guiigo_manage:tlang0370}</div>
						<!--{/if}-->
						<!--{if $post[first]}-->
						<div class="lzxx-lzwx">
							<h1>
								<!--{if !$post['authorid'] || $post['anonymous']}-->
									<a href="javascript:void(0);" class="mcxx-yhmc zy-f">$_G[setting][anonymoustext]</a>
								<!--{else}-->
									<!--{if $post[authorid] != $_G[uid]}-->
										<!--{if $post['isfollow'] ==1}-->
										<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$post['authorid']"
										class="followmod_$post[authorid] dialog mcxx-gzan zy-c bk-c bg-e" 
										ck-cus="true" 
										ck-confirm="true" 
										ck-param="{type:'modal',callpar:{tid:'$post[authorid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}" 
										external >{lang guiigo_manage:tlang0003}</a>
										<!--{else}-->
										<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$post[authorid]" 
										class="followmod_$post[authorid] dialog mcxx-gzan zy-b bk-b"
										ck-cus="true"
										ck-confirm="false"
										ck-param="{type:'modal',callpar:{tid:'$post[authorid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}"
										external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
										<!--{/if}-->
									<!--{/if}-->
									<!--{if !$_G['forum']['ismoderator']}-->
										<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
											<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="mcxx-gzan zy-c bk-c bg-e"><i class="icon guiigoapp-fbxhfb"></i>{lang guiigo_manage:tlang0227}</a>
										<!--{/if}-->
									<!--{/if}-->
									<a href="javascript:;" onclick="app.ActionsManage('#guiigo-lchd-$post[pid]','t', 'auto');" class="mcxx-yhmc zy-f">$post[author]</a>
									<span class="mcxx-yhdj zy-a" style="background: {$post[groupcolor]};">{$post[groupstars]} {$post[grouptitle]}</span>
									<!--{if $post['gender'] == 1 || $post['gender'] == 0}-->
									<i class="icon guiigoapp-nan bg-n"></i>
									<!--{elseif $post['gender'] == 2}-->
									<i class="icon guiigoapp-nv bg-o"></i>
									<!--{/if}-->
									<!--{if $_G['setting']['verify']['enabled']}-->
										<span class="verify-icon y">
										<!--{loop $post['verifyicon'] $vid}-->
											<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" class="ck8-avatar-icon">
											   <img src="$_G['setting']['verify'][$vid]['icon']" class="vm" />
											</a>
										<!--{/loop}-->
										</span>
									<!--{/if}-->
								<!--{/if}-->
							</h1>
							<div class="mcxx-fbxx">
								<i class="zy-g">$post[dateline]</i>
								<a href="forum.php?mod=forumdisplay&fid=$post[fid]" class="zy-g"><!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->#{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}#<!--{/if}--></a>
							</div>
						</div>
						<!--{/if}-->
					</div>
					<div id="<!--{if $post[first]}-->gg-sq-lznr<!--{else}-->gg-sq-hfnr<!--{/if}-->" class="gg-sq-qbnr <!--{if $post[first]}-->gg-sq-lznr<!--{else}-->gg-sq-hfnr<!--{/if}-->">
						<!--{if !$post[first]}-->
						<div class="gg-sq-lzxx" style="padding:0;">
							<div class="lzxx-lzwx" style="margin-left:0;padding-bottom: .3rem;">
								<h1>
									<!--{if !$post['authorid'] || $post['anonymous']}-->
										<a href="javascript:void(0);" class="mcxx-yhmc zy-f">$_G[setting][anonymoustext]</a>
									<!--{else}-->
										<!--{if $post['authorid'] && $post['author']}--><a href="javascript:;" onclick="app.ActionsManage('#guiigo-lchd-$post[pid]','t', 'auto');" class="mcxx-yhmc zy-f">$post[author]</a><!--{else}--><a href="javascript:void(0);" class="mcxx-yhmc zy-f">$_G[setting][anonymoustext]</a><!--{/if}-->
										<span class="mcxx-yhdj zy-a" style="background: {$post[groupcolor]};">{$post[groupstars]} {$post[grouptitle]}</span>
										<!--{if $post['gender'] == 1 || $post['gender'] == 0}-->
										<i class="icon guiigoapp-nan bg-n"></i>
										<!--{elseif $post['gender'] == 2}-->
										<i class="icon guiigoapp-nv bg-o"></i>
										<!--{/if}-->
										<!--{if $_G['setting']['verify']['enabled']}-->
											<span class="verify-icon y">
											<!--{loop $post['verifyicon'] $vid}-->
												<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" class="ck8-avatar-icon">
												   <img src="$_G['setting']['verify'][$vid]['icon']" class="vm" />
												</a>
											<!--{/loop}-->
											</span>
										<!--{/if}-->
									<!--{/if}-->
								</h1>
								<div class="mcxx-fbxx">
									<i class="zy-g">$post[dateline]</i>
									<em class="zy-g"><!--{if isset($post[isstick])}--><i class="icon guiigoapp-shenping zy-p"></i><!--{elseif $post[number] == -1}-->{lang recommend_post}<!--{else}--><!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}--><!--{/if}--></em>
								</div>
								<div class="mcxx-hfcz">
									<!--{if $_G['forum']['ismoderator']}-->
									<a href="javascript:;" class="zy-c" onclick="app.ActionsManage('#guiigo-lcgl-$post[pid]','t', 'auto');"><i class="icon guiigoapp-shezhi"></i></a>
									<!--{/if}-->
									<!--{if !$post['authorid'] || $post['anonymous']}--><!--{else}-->
										<!--{if !$_G['forum']['ismoderator']}-->
										<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
											<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="zy-c"><i class="icon guiigoapp-bianji"></i></a>
										<!--{/if}-->
										<!--{/if}-->
										<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
											
											<!--{if $post['isrecommenus'] ==1}-->
											<a href="plugin.php?id=guiigo_manage:api&api=misc&action=postreview&do=delsupport&tid=$_G[tid]&pid=$post[pid]"
												class="{if !$_G['uid']}login {else} delhotreply{/if} link link-c zy-c" 
												ck-cus="true" 
												ck-param="{type:'modal',load:'true',callpar:{pid:'$post[pid]',type:'hotreply'},fn:'MsgCallRecommendv',uid:'$_G[uid]'}"
												external>
												<i class="icon guiigoapp-dianzanon zy-i"></i>
												<!--{if $guiigo_config['appsetting']['forumconfig']['show_give_data']}-->
													<span class="guiigo-yjsz bg-j zy-a" id="recommendv_add_$post[pid]"{if !$post['postreview']['support']} style="display:none"{/if}>{$post[postreview][support]}</span>
												<!--{/if}-->
											</a>
											<!--{else}-->
											<a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}"
												class="{if !$_G['uid']}login {else} dialog{/if} link link-c zy-c" 
												ck-cus="true" 
												ck-param="{type:'modal',load:'true',callpar:{pid:'$post[pid]',type:'hotreply'},fn:'MsgCallRecommendv',uid:'$_G[uid]'}"
												external>
												<i class="icon guiigoapp-dianzan"></i>
												<!--{if $guiigo_config['appsetting']['forumconfig']['show_give_data']}-->
													<span class="guiigo-yjsz bg-j zy-a" id="recommendv_add_$post[pid]"{if !$post['postreview']['support']} style="display:none"{/if}>{$post[postreview][support]}</span>
												<!--{/if}-->
											</a>
											<!--{/if}-->
										<!--{/if}-->
										<a href="javascript:;" class="zy-c" onclick="app.ActionsManage('#guiigo-lchd-$post[pid]','t', 'auto');"><i class="icon guiigoapp-mkbtgd"></i></a>
									<!--{/if}-->
								</div>
							</div>
						</div>
						<!--{/if}-->
						<div id="share_img" class="gg-sq-nrzt zy-e guiigo-external">
						<!--{if $post['warned']}-->
							<div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang warn_get}</div>
						<!--{/if}-->
						<!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
							<div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang message_banned}</div>
						<!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
							<div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang message_single_banned}</div>
						<!--{elseif $needhiddenreply}-->
							<div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang message_ishidden_hiddenreplies}</div>
						<!--{elseif $post['first'] && $_G['forum_threadpay']}-->
							<!--{template forum/viewthread_pay}-->
						<!--{elseif $_G['forum_discuzcode']['passwordlock'][$post[pid]]}-->
							<div class="gg-sq-mmty bg-p bk-d zy-b">
								<p><i class="icon guiigoapp-quanxian zy-b"></i>{lang guiigo_manage:tlang0371}</p>
								<div class="mmty-sran">
									<input type="text" id="postpw_$post[pid]" class="guiigo-px bg-e bk-e zy-h" placeholder="{lang guiigo_manage:tlang0216}"/>
									<button class="guiigo-pn ab-az zy-a zy-ac" type="button" onclick="submitpostpw($post[pid]{if $_GET['from'] == 'preview'},{$post[tid]}{else}{/if})">{lang submit}</button>
								</div>
							</div>
						<!--{else}-->
							<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
								<div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang admin_message_banned}</div>
							<!--{elseif $post['status'] & 1}-->
								<div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang admin_message_single_banned}</div>
							<!--{/if}-->
							<!--{if $post[first]}-->
								<!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
									<div class="gg-sq-gmzs mx-a bg-p bk-d">
										<a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" class="gmzs-ddlj zy-l">{lang guiigo_manage:tlang0120}</a>
										<i class="icon guiigoapp-shoufei gmzs-ddkz zy-b"></i><em class="zy-b">{lang pay_threads}: $_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</em>
									</div>
								<!--{/if}-->
								<!--{if $rushreply}-->
									<div class="gg-sq-gmzs mx-a bg-p bk-d">
										<div class="gmzs-zstb"><i class="icon guiigoapp-hongbao zy-b"></i></div>
										<div class="gmzs-zsnr zy-b">
											<em style="font-size: .72rem;"><!--{if $rushresult[creditlimit] == ''}-->{lang thread_rushreply}<!--{else}-->{lang thread_rushreply_limit}<!--{/if}--></em>
											<!--{if $rushresult[stopfloor]}--><p class="zy-g">{lang thread_rushreply_end}$rushresult[stopfloor]</p><!--{/if}-->
											<!--{if $rushresult[rewardfloor]}--><p class="zy-g">{lang thread_rushreply_floor}: $rushresult[rewardfloor]</p><!--{/if}-->
										</div>
									</div>
								<!--{/if}-->
							<!--{/if}-->
							<!--{if $post['first'] && $threadsort && $threadsortshow}-->
								<!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
									<!--{if $threadsortshow['typetemplate']}-->
										<!--{eval echo str_replace(array("guiigo-flbt","guiigo-fbsj","guiigo-ckcs","{lang guiigo_manage:tlang0923}&nbsp;","{lang guiigo_manage:tlang0924}&nbsp;","{lang guiigo_manage:tlang0925}&nbsp;","{lang guiigo_manage:tlang0926}&nbsp;","{lang guiigo_manage:tlang0927}&nbsp;","{lang guiigo_manage:tlang0928}&nbsp;","{lang guiigo_manage:tlang0929}&nbsp;","{lang guiigo_manage:tlang0930}&nbsp;","{lang guiigo_manage:tlang0931}&nbsp;","{lang guiigo_manage:tlang0932}&nbsp;","{lang guiigo_manage:tlang0933}&nbsp;","{lang guiigo_manage:tlang0934}&nbsp;","{lang guiigo_manage:tlang0935}&nbsp;","{lang guiigo_manage:tlang0936}&nbsp;","{lang guiigo_manage:tlang0937}&nbsp;","{lang guiigo_manage:tlang0938}&nbsp;","{lang guiigo_manage:tlang0893}&nbsp;","{lang guiigo_manage:tlang0894}&nbsp;","{lang guiigo_manage:tlang0895}&nbsp;","{lang guiigo_manage:tlang0896}&nbsp;","{lang guiigo_manage:tlang0897}&nbsp;","{lang guiigo_manage:tlang0898}&nbsp;","{lang guiigo_manage:tlang0899}&nbsp;","{lang guiigo_manage:tlang0900}&nbsp;","{lang guiigo_manage:tlang0901}&nbsp;","{lang guiigo_manage:tlang0902}&nbsp;","{lang guiigo_manage:tlang0903}&nbsp;","{lang guiigo_manage:tlang0904}&nbsp;","{lang guiigo_manage:tlang0905}&nbsp;","{lang guiigo_manage:tlang0906}&nbsp;","{lang guiigo_manage:tlang0907}&nbsp;","{lang guiigo_manage:tlang0908}&nbsp;","{lang guiigo_manage:tlang0909}&nbsp;","{lang guiigo_manage:tlang0910}&nbsp;","{lang guiigo_manage:tlang0911}&nbsp;","{lang guiigo_manage:tlang0912}&nbsp;","{lang guiigo_manage:tlang0913}&nbsp;","{lang guiigo_manage:tlang0914}&nbsp;","{lang guiigo_manage:tlang0915}&nbsp;","{lang guiigo_manage:tlang0916}&nbsp;","{lang guiigo_manage:tlang0917}&nbsp;","{lang guiigo_manage:tlang0918}&nbsp;","{lang guiigo_manage:tlang0919}&nbsp;","{lang guiigo_manage:tlang0920}&nbsp;","{lang guiigo_manage:tlang0921}&nbsp;","{lang guiigo_manage:tlang0922}&nbsp;","{lang guiigo_manage:tlang0939}&nbsp;","{lang guiigo_manage:tlang0940}&nbsp;","{lang guiigo_manage:tlang0941}&nbsp;","{lang guiigo_manage:tlang0942}&nbsp;","{lang guiigo_manage:tlang0943}&nbsp;","ESP&nbsp;","{lang guiigo_manage:tlang0944}&nbsp;","{lang guiigo_manage:tlang0945}&nbsp;","{lang guiigo_manage:tlang0946}&nbsp;","{lang guiigo_manage:tlang0947}&nbsp;","{lang guiigo_manage:tlang0948}&nbsp;","{lang guiigo_manage:tlang0949}&nbsp;","{lang guiigo_manage:tlang0950}&nbsp;","{lang guiigo_manage:tlang0951}&nbsp;","{lang guiigo_manage:tlang0952}&nbsp;","{lang guiigo_manage:tlang0953}&nbsp;","{lang guiigo_manage:tlang0954}&nbsp;","GUIIGO-APP"),array($_G[forum_thread][subject],$post[dateline],$thread[views],'<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzchuang zy-h"></i>{lang guiigo_manage:tlang0923}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzshafa zy-h"></i>{lang guiigo_manage:tlang0924}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzzhuoyi zy-h"></i>{lang guiigo_manage:tlang0925}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzyigui zy-h"></i>{lang guiigo_manage:tlang0926}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzdianshi zy-h"></i>{lang guiigo_manage:tlang0927}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzbingxiang zy-h"></i>{lang guiigo_manage:tlang0928}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzxiyiji zy-h"></i>{lang guiigo_manage:tlang0929}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-zidongkongtiaox zy-h"></i>{lang guiigo_manage:tlang0930}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-hpktcc zy-h"></i>{lang guiigo_manage:tlang0931}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzkongtiao zy-h"></i>{lang guiigo_manage:tlang0932}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzreshuiqi zy-h"></i>{lang guiigo_manage:tlang0933}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzranqizao zy-h"></i>{lang guiigo_manage:tlang0934}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzweibolu zy-h"></i>{lang guiigo_manage:tlang0935}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzchouyanji zy-h"></i>{lang guiigo_manage:tlang0936}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzkuandai zy-h"></i>{lang guiigo_manage:tlang0937}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-pzwupeizhi zy-h"></i>{lang guiigo_manage:tlang0938}</div>',"<i>{lang guiigo_manage:tlang0893}</i>","<i>{lang guiigo_manage:tlang0894}</i>","<i>{lang guiigo_manage:tlang0895}</i>","<i>{lang guiigo_manage:tlang0896}</i>","<i>{lang guiigo_manage:tlang0897}</i>","<i>{lang guiigo_manage:tlang0898}</i>","<i>{lang guiigo_manage:tlang0899}</i>","<i>{lang guiigo_manage:tlang0900}</i>","<i>{lang guiigo_manage:tlang0901}</i>","<i>{lang guiigo_manage:tlang0902}</i>","<i>{lang guiigo_manage:tlang0903}</i>","<i>{lang guiigo_manage:tlang0904}</i>","<i>{lang guiigo_manage:tlang0905}</i>","<i>{lang guiigo_manage:tlang0906}</i>","<i>{lang guiigo_manage:tlang0907}</i>","<i>{lang guiigo_manage:tlang0908}</i>","<i>{lang guiigo_manage:tlang0909}</i>","<i>{lang guiigo_manage:tlang0910}</i>","<i>{lang guiigo_manage:tlang0911}</i>","<i>{lang guiigo_manage:tlang0912}</i>","<i>{lang guiigo_manage:tlang0913}</i>","<i>{lang guiigo_manage:tlang0914}</i>","<i>{lang guiigo_manage:tlang0915}</i>","<i>{lang guiigo_manage:tlang0916}</i>","<i>{lang guiigo_manage:tlang0917}</i>","<i>{lang guiigo_manage:tlang0918}</i>","<i>{lang guiigo_manage:tlang0919}</i>","<i>{lang guiigo_manage:tlang0920}</i>","<i>{lang guiigo_manage:tlang0921}</i>","<i>{lang guiigo_manage:tlang0922}</i>",'<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-tianchuang zy-f"></i>{lang guiigo_manage:tlang0939}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-daocheyx zy-f"></i>{lang guiigo_manage:tlang0940}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-wolunzengya zy-f"></i>{lang guiigo_manage:tlang0941}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-wysqdcc zy-f"></i>{lang guiigo_manage:tlang0942}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-zidongzhuchex zy-f"></i>{lang guiigo_manage:tlang0943}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-espkai zy-f"></i>ESP</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-taocanhuandang zy-f"></i>{lang guiigo_manage:tlang0944}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-zidongbochex zy-f"></i>{lang guiigo_manage:tlang0945}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-gps zy-f"></i>{lang guiigo_manage:tlang0946}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-dingsuxunhangx zy-f"></i>{lang guiigo_manage:tlang0947}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-taiya zy-f"></i>{lang guiigo_manage:tlang0948}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-chachepian zy-f"></i>{lang guiigo_manage:tlang0949}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-spfzcc zy-f"></i>{lang guiigo_manage:tlang0950}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-hangchedeng zy-f"></i>{lang guiigo_manage:tlang0951}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-fadongjiqitingjishux zy-f"></i>{lang guiigo_manage:tlang0952}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-zhuanxiangzhidong zy-f"></i>{lang guiigo_manage:tlang0953}</div>','<div class="fwpz-pzli zy-c"><i class="icon guiigoapp-qiche zy-f"></i>{lang guiigo_manage:tlang0954}</div>',"GUIIGO-APP"),$threadsortshow[typetemplate]);}-->
										<!--{if $threadsortshow['optionlist'] == 'expire'}--><div class="gg-fl-gqxx bg-j zy-a"><i class="icon guiigoapp-hd-ws"></i>{lang guiigo_manage:tlang0955}</div><!--{/if}-->
									<!--{/if}-->
								<!--{/if}-->
							<!--{/if}-->
							<!--{if $post['first']}-->
								<!--{if !$_G[forum_thread][special]}-->
									$post[message]
								<!--{elseif $_G[forum_thread][special] == 1}-->
									<!--{template forum/viewthread_poll}-->
								<!--{elseif $_G[forum_thread][special] == 2}-->
									<!--{template forum/viewthread_trade}-->
								<!--{elseif $_G[forum_thread][special] == 3}-->
									<!--{template forum/viewthread_reward}-->
								<!--{elseif $_G[forum_thread][special] == 4}-->
									<!--{template forum/viewthread_activity}-->
								<!--{elseif $_G[forum_thread][special] == 5}-->
									<!--{template forum/viewthread_debate}-->
								<!--{elseif $threadplughtml}-->
									$threadplughtml
									$post[message]
								<!--{else}-->
									$post[message]
								<!--{/if}-->
							<!--{else}-->
								<!--{if !$post['first'] && $post['replycredit'] > 0}-->
									<div class="gg-sq-lcjl zy-i">
										{lang replycredit} +{$post['replycredit']} {$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][unit]}{$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][title]}
									</div>
								<!--{/if}-->
								<!--{if !$post[first] && $_G['forum_thread']['special'] == 5}-->
									<a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]"
									id="voterdebate_$post[pid]"
									name="debate" 
									class="dialog gg-sq-blzc<!--{if $post[stand] == 1}--> bg-k<!--{elseif $post[stand] == 2}--> bg-j<!--{else}--> bg-l<!--{/if}-->"
									ck-cus="true"
									ck-param="{type:'modal',callpar:{tid:'$_G[tid]',pid:'$post[pid]',type:'debate'},fn:'MsgCallInvite',load:'true',uid: '$_G[uid]'}"
									external> 
										<div class="blzc-bfpd zy-a<!--{if !$post[stand] == 1 || !$post[stand] == 2}--> zy-c<!--{/if}-->"<!--{if !$post[stand] == 1 || !$post[stand] == 2}--> style="width: 100%;"<!--{/if}-->><!--{if $post[stand] == 1}-->{lang debate_square}<!--{elseif $post[stand] == 2}-->{lang debate_opponent}<!--{else}-->{lang debate_neutral}<!--{/if}--></div>
										<!--{if $post[stand]}-->
										<div class="blzc-czsl bg-c<!--{if $post[stand] == 1}--> zy-n<!--{elseif $post[stand] == 2}--> zy-i<!--{else}--> zy-c<!--{/if}-->">{lang debate_support} $post[voters]</div>
										<!--{/if}-->
									</a>
								<!--{/if}-->
								<!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
									<a href="javascript:;" class="gg-sq-zjdn ab-c zy-a" onclick="setanswer($post[tid],$post['pid'], '$_GET[from]','{FORMHASH}','MsgCallModmenu',{'pid':{$firstpid}})">{lang guiigo_manage:tlang0372}</a>
								<!--{/if}-->
								$post[message]
							<!--{/if}-->
						<!--{/if}-->
						<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
						<!--{if $post['attachment']}-->
							<div class="gg-sq-wdlfj bg-p bk-d zy-b">
								<i class="icon guiigoapp-tishi zy-b"></i>
								{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
							</div>
						<!--{elseif $post['imagelist'] || $post['attachlist']}-->
							<!--{if $post['imagelist']}-->
							<!--{if count($post['imagelist']) == 1}-->
							<ul class="img_one">{echo showattach($post, 1)}</ul>
							<!--{else}-->
							<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
							<!--{/if}-->
							<!--{/if}-->
							<!--{if $post['attachlist']}-->
							<ul>{echo showattach($post)}</ul>
							<!--{/if}-->
						<!--{/if}-->
						<!--{/if}-->
						</div>
					<div id="post_topo_{$post[pid]}">
						<!--{if $post[first]}-->
							<div id="gg-sq-lzhd">
								<!--{if $guiigo_config['appsetting']['forumconfig']['show_reward']}-->
									<!--{if $post['authorid'] && !$post['anonymous']}-->
										<div class="gg-sq-ztds">
											<p class="ztds-dsby{if $_G['guiigoapp']['appsetting']['forumconfig']['show_rewardan'] == 2} ztds-dsbys{/if} zy-f">$guiigo_config['appsetting']['forumconfig']['reward_text']</p>
											<!--{if $_G['guiigoapp']['appsetting']['forumconfig']['show_rewardan'] == 2}-->
											<a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]" 
												class="ztds-dsans zy-a bg-j dialog" 
												ck-cus="true"
												ck-param="{type:'modal',callpar:{pid:'$post[pid]'},fn:'MsgCallRaterange',load:'true',uid: '$_G[uid]'}"
												external >{lang guiigo_manage:tlang0344}</a>
											<!--{else}-->
											<a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]" 
												class="ztds-dsan zy-a dialog" 
												ck-cus="true"
												ck-param="{type:'modal',callpar:{pid:'$post[pid]'},fn:'MsgCallRaterange',load:'true',uid: '$_G[uid]'}"
												external >
												<i class="icon guiigoapp-dashang"></i>
											</a>
											<!--{/if}-->
											<!--{if !empty($post['ratelog'])}-->
												<!--{if $guiigo_config['appsetting']['forumconfig']['show_rewardlb']}-->
													<!--{if count($postlist[$post[pid]][totalrate]) > $guiigo_config['appsetting']['forumconfig']['show_rewardsl']}-->
														<p class="ztds-dssl{if $_G['guiigoapp']['appsetting']['forumconfig']['show_rewardan'] == 2} ztds-dssls{/if}"><a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" data-no-cache="true" class="zy-c">{lang guiigo_manage:tlang0373}<span class="{if $_G['guiigoapp']['appsetting']['forumconfig']['show_rewardan'] == 2}zy-i{else}zy-b{/if}"><!--{echo count($postlist[$post[pid]][totalrate]);}--></span>{lang guiigo_manage:tlang0374}<i class="icon guiigoapp-xzdk"></i></a></p>
													<!--{/if}-->
												<!--{else}-->	
													<p class="ztds-dssl{if $_G['guiigoapp']['appsetting']['forumconfig']['show_rewardan'] == 2} ztds-dssls{/if}"><a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" data-no-cache="true" class="zy-c">{lang guiigo_manage:tlang0373}<span class="{if $_G['guiigoapp']['appsetting']['forumconfig']['show_rewardan'] == 2}zy-i{else}zy-b{/if}"><!--{echo count($postlist[$post[pid]][totalrate]);}--></span>{lang guiigo_manage:tlang0374}<i class="icon guiigoapp-xzdk"></i></a></p>
												<!--{/if}-->
												<!--{if $guiigo_config['appsetting']['forumconfig']['show_rewardlb']}-->
													<div class="ztds-dsyh list-block-no">
														<ul>
															<!--{eval $ratelogkey = 0;}-->
															<!--{loop $post['ratelog'] $uid $ratelog}-->
																<!--{if $ratelogkey == $guiigo_config['appsetting']['forumconfig']['show_rewardsl']}-->
																	<!--{eval break;}-->
																<!--{/if}-->
																<li id="rate_{$post[pid]}_{$uid}" class="bg-e">
																	<a href="home.php?mod=space&uid=$uid&do=profile" class="yhsj-hyim guiigo-ty"><!--{echo avatar($uid, 'middle');}--></a>
																	<div class="dsyh-yhsj cl">
																		<a href="home.php?mod=space&uid=$uid&do=profile" class="zy-c">$ratelog[username]</a>
																		<span class="{if $_G['guiigoapp']['appsetting']['forumconfig']['show_rewardan'] == 2}zy-i{else}zy-b{/if}">
																			<!--{loop $post['ratelogextcredits'] $id $score}-->
																				<!--{if $ratelog['score'][$id] > 0}-->
																					<i>{$_G['setting']['extcredits'][$id][title]}+$ratelog[score][$id]</i>
																				<!--{/if}-->
																			<!--{/loop}-->
																		</span>
																	</div>
																	<p class="zy-e">$ratelog[reason]</p>
																</li>
																
															<!--{eval $ratelogkey++;}-->
															<!--{/loop}-->
														</ul>
													</div>
												<!--{/if}-->
											<!--{/if}-->	
										</div>
									<!--{/if}-->
								<!--{/if}-->
								<div class="gg-sq-bqxh">
									<!--{if $guiigo_config['appsetting']['forumconfig']['show_tag']}-->
									<!--{if $post['first'] && ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
									<!--{if $post[tags]}-->
									<div class="gg-sq-tags">
										<!--{eval $tagi = 0;}-->
										<!--{loop $post[tags] $var}-->
										<a title="$var[1]" href="misc.php?mod=tag&id=$var[0]&type=thread" class="bg-l zy-h">$var[1]</a>
										<!--{/loop}-->
									</div>
									<!--{/if}-->
									<!--{/if}-->
									<!--{/if}-->
									<!--{if $guiigo_config['appsetting']['forumconfig']['show_give']}-->
										<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
										<!--{if $_G[tid]}-->
											<!--{eval $recommenlist=GuiigoApp::getrecommendbyid($_G[tid],'',1,6);}-->
										<!--{/if}-->
										<div class="gg-sq-xhbt">
											<div class="xhbt-txlb list-block-no" id="delrecommenlist_$post[pid]">
										<!--{if $recommenlist}-->
												<ul>
										<!--{loop $recommenlist $tkey $rval}-->
										<!--{eval $avatarurl = avatar($rval['uid'],'small', true);}-->
											<li><a href="home.php?mod=space&uid=$rval['uid']&do=profile"><img lazySrc="$avatarurl" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm" ></a></li>
											<!--{if $tkey == 5}-->
												<li class="bg-l"><a href="forum.php?mod=viewthread&action=printable&tid=$_G[tid]"><i class="icon guiigoapp-mkbtgd zy-f"></i></a></li>
											<!--{/if}-->
										<!--{/loop}-->	
												</ul>
										<!--{else}-->
											<em class="zy-c"><i class="icon guiigoapp-bukaixin zy-c"></i>{lang guiigo_manage:tlang0375}</em>
										<!--{/if}-->
											</div>
											<div class="xhbt-dzan">
											<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
											<!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
												<!--{if $post['isrecommenus'] ==1}-->
												<a href="plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid=$_G[tid]" class="{if !$_G['uid']}login {else} delRecommenus{/if} links links-d zy-a ab-b" 
													ck-cus="true" 
													data-op="viewthread"
													data-pid="$post[pid]"
													id="recommendv_add_lz_a_$post[pid]"
													ck-param="{type:'modal',load:'true',callpar:{pid:'$post[pid]'},fn:'MsgCallRecommendv',uid:'$_G[uid]'}" external><i class="icon guiigoapp-dianzan"></i>
													<em id="recommendv_add_lz$post[pid]">{$_G[forum_thread][recommend_add]}</em>
												</a>
												<!--{else}-->
												<a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" 
												    id="recommendv_add_lz_a_$post[pid]" 
													class="{if !$_G['uid']}login {else} dialog{/if} links links-d zy-a ab-az zy-ac" ck-cus="true" data-op="viewthread" data-pid="$post[pid]" ck-param="{type:'modal',load:'true',callpar:{pid:'$post[pid]'},fn:'MsgCallRecommendv',uid:'$_G[uid]'}" external><i class="icon guiigoapp-dianzan"></i>
													<em id="recommendv_add_lz$post[pid]">{$_G[forum_thread][recommend_add]}</em>
												</a>
												<!--{/if}-->
											<!--{/if}-->
											<!--{/if}-->
											</div>
										</div>
										<!--{/if}-->
									<!--{/if}-->
								</div>
							</div>
						<!--{else}-->
							<div id="dpkx-on-$post[pid]">
								<!--{if !$post['first'] && $_GET['from'] != 'preview' && $_G['setting']['commentnumber'] && !empty($comments[$post[pid]])}-->
									<div id="comment_$post[pid]" class="gg-sq-dplb bg-e ms-a" >
										<!--{loop $comments[$post[pid]] $comment}-->
											<div class="dplb-lbzt" id="delcomment_$comment[id]">
												<div class="dplb-dptx">{$comment[avatar]}</div>
												<div class="dplb-dpnr xh-b">
													<div class="dpnr-yhsj">
														<!--{if $comment['authorid']}-->
															<a href="home.php?mod=space&uid=$comment[authorid]&do=profile" class="yhsj-yhmc zy-l">$comment[author]</a>
														<!--{else}-->
															<a href="javascript:;" class="yhsj-yhmc zy-l">{lang guest}</a>
														<!--{/if}-->
														<em class="zy-g"><!--{date($comment[dateline], 'u')}--></em>
														<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
															<a href="javascript:;" 
															class="yhsj-scan bk-a zy-g"
															onclick="modaction(this, 'delcomment',$comment[id])"
															ck-cus="true" 
															ck-param="{type:'modal',load:'true',callpar:{cpid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',uid:'$_G[uid]'}"><i class="icon guiigoapp-shanchu"></i></a>
														<!--{/if}-->
													</div>
													<div class="dpnr-nrzt zy-h">$comment[comment]</div>
												</div>
											</div>
										<!--{/loop}-->
									</div>
								<!--{/if}-->
								<!--{if !$post['first'] && $commentcount[$post[pid]] > $_G['setting']['commentnumber']}-->
									<div class="gg-sq-dpgd bg-e">
										<a href="javascript:;" class="zy-f" 
										onclick="ajaxget(this,'forum.php?mod=misc&action=commentmore&tid=$post[tid]&pid=$post[pid]', 'comment_$post[pid]',1);" data-page="2">{lang guiigo_manage:tlang0376}<i class="icon guiigoapp-xxzk zy-g"></i></a>
									</div>
								<!--{/if}-->
							</div>
							<!--{if $guiigo_config['appsetting']['forumconfig']['show_reward']}-->
							<!--{if $post['authorid'] && !$post['anonymous']}-->
							<!--{if !empty($post['ratelog'])}-->
							<div class="gg-sq-hfds">
								<a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" data-no-cache="true">
									<div class="hfds-dstj">
										<i class="icon guiigoapp-hongbao zy-i"></i>
										<em class="zy-i"><!--{echo count($postlist[$post[pid]][totalrate]);}-->{lang guiigo_manage:tlang0377}</em>
									</div>
									<div class="xhbt-txlb list-block-no">
										<ul>
										<!--{eval $i =0;}-->
											<!--{loop $post['ratelog'] $uid $ratelog}-->
											<!--{eval $azyavatar = avatar($uid,'small', true);}-->
											<li><img lazySrc="$azyavatar" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm" /></li>
											<!--{if $i == 5}-->
											<!--{eval break;}-->
											<!--{/if}-->
											<!--{eval $i++;}-->
											<!--{/loop}-->
										</ul>
									</div>
								</a>
							</div>
							<!--{/if}-->
							<!--{/if}-->
							<!--{/if}-->
						<!--{/if}-->
					</div>
					</div>
				</div>
				<!--{hook/viewthread_postbottom_mobile $postcount}-->
				<!--{if $post[first]}-->
					<!--{if $guiigo_config['isguiigoapp']}-->
					<div class="gg-sq-appdf">
						<a href="javascript:;" class="bg-c zy-e" onclick="appShareAllview('#share_title','#share_img','#share_img');"><img src="template/guiigo_app/static/images/wx.png">{lang guiigo_manage:tlang0153}</a>
						<a href="javascript:;" class="bg-c zy-e" style="margin: 0 3.5%" onclick="appShareAllview('#share_title','#share_img','#share_img');"><img src="template/guiigo_app/static/images/pyq.png">{lang guiigo_manage:tlang0154}</a>
						<a href="javascript:;" class="bg-c zy-e" onclick="appShareAllview('#share_title','#share_img','#share_img');"><img src="template/guiigo_app/static/images/qq.png">{lang guiigo_manage:tlang0155}</a>
					</div>
					<!--{/if}-->
					<!--{if $guiigo_config['appsetting']['forumconfig']['show_content_sources']}-->
						<div class="gg-sq-lybk ms-a bg-c xh-b sh-a">
							<a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="zy-c">
								<i class="icon guiigoapp-xzdk zy-g"></i>
								<img lazySrc="<!--{if $_G['forum'][icon]}-->{if GuiigoApp::isGroup($_G['fid'])}data/attachment/group/$_G['forum'][icon]{else}data/attachment/common/$_G['forum'][icon]{/if}<!--{else}-->{if GuiigoApp::isGroup($_G['fid'])}static/image/common/groupicon.gif{else}{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png{/if}<!--{/if}-->" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/>
								{lang guiigo_manage:tlang0378}<span class="zy-l">$_G['forum'][name]</span>{lang guiigo_manage:tlang0379}
							</a>
						</div>
					<!--{/if}-->
					<!--{if $guiigo_config['appsetting']['forumconfig']['show_like']}-->
						<!--{if $post['relateitem']}-->
							<div class="gg-sq-cnxh ms-a bg-c xh-b sh-a">
								<div class="cnxh-btys xh-b zy-h">{lang guiigo_manage:tlang0380}</div>
								<div class="cnxh-xhnr list-block-no">
									<ul class="ms-c">
										<!--{loop $post['relateitem'] $var}-->
										<!--{eval $postpid=GuiigoApp::getpostfirstbypid($var['tid']);}-->
										<!--{eval $postimg=GuiigoApp::AttachImg($var['tid'],$postpid[pid],array('nocache'=>0,'width'=>200,'height'=>150));}-->
										<!--{eval $picts=count($postimg);}-->
										<!--{if $picts >= 3}-->
										<li class="sh-a">
											<a href="forum.php?mod=viewthread&tid=$var[tid]">
												<h2 class="zy-h">{$var[subject]}</h2>
												<div class="cnxh-imgs">
													<ul>
														<!--{loop $postimg $imsarrkey $imsarr}-->
															<!--{if $imsarrkey <= 2}-->
																<li><img lazySrc="{$imsarr['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
															<!--{/if}--> 
														<!--{/loop}-->
													</ul>
												</div>
												<p class="zy-c">
													<span class="zy-c">{$var[views]}{lang guiigo_manage:tlang0381}</span>
													<!--{eval echo dgmdate($var[dateline], 'u');}-->
												</p>
											</a>
										</li>
										<!--{elseif $picts == 0}-->
										<li class="sh-a">
											<a href="forum.php?mod=viewthread&tid=$var[tid]">
												<h2 class="zy-h">{$var[subject]}</h2>
												<p class="zy-c">
													<span class="zy-c">{$var[views]}{lang guiigo_manage:tlang0381}</span>
													<!--{eval echo dgmdate($var[dateline], 'u');}-->
												</p>
											</a>
										</li>
										<!--{elseif $picts <= 2}-->
										<li class="sh-a">
											<a href="forum.php?mod=viewthread&tid=$var[tid]">
												<div class="cnxh-imgs cnxh-imgd">
													<!--{loop $postimg $imsarr}-->
													<img lazySrc="{$imsarr['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/>
													<!--{/loop}-->
												</div>
												<div class="xnxh-dtbs">
													<h2 class="zy-h">{$var[subject]}</h2>
													<p class="zy-c">
														<span class="zy-c">{$var[views]}{lang guiigo_manage:tlang0381}</span>
														<!--{eval echo dgmdate($var[dateline], 'u');}-->
													</p>
												</div>
											</a>
										</li>
										<!--{/if}--> 
										<!--{/loop}-->
									</ul>
								</div>
							</div>
						<!--{/if}-->
					<!--{/if}-->
					<div id="comment" class="gg-sq-hfsx ms-a bg-c sh-a list-container-s">
						<h2 class="zy-h">{lang guiigo_manage:tlang0382}<em class="zy-g plsl">$_G[forum_thread][allreplies]</em></h2>
						<span class="hfsx-ycgn">
							<!--{if $guiigo_config['appsetting']['forumconfig']['show_look_posts']}-->
								<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
									<a href="javascript:;" onclick="app.LoadPageForumView('.post-scroll','forum.php?mod=viewthread&tid=$post[tid]&page=$page&authorid=$post[authorid]',['gg-sq-hfsx','gg-sq-hfsxkz']);" class="zy-g"><i class="icon guiigoapp-zhikanlz"></i>{lang guiigo_manage:tlang0383}</a>
								<!--{elseif !$_G['forum_thread']['archiveid']}-->	
									<a href="javascript:;" onclick="app.LoadPageForumView('.post-scroll','forum.php?mod=viewthread&tid=$post[tid]&page=$page',['gg-sq-hfsx','gg-sq-hfsxkz']);" class="zy-g"><i class="icon guiigoapp-zhikanlouzhu"></i>{lang guiigo_manage:tlang0130}</a>
								<!--{/if}-->
							<!--{/if}-->
							<!--{if $guiigo_config['appsetting']['forumconfig']['show_reply_order']}-->
								<!--{if $ordertype != 1}-->
									<a href="javascript:;" onclick="app.LoadPageForumView('.post-scroll','forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1',['gg-sq-hfsx','gg-sq-hfsxkz']);" class="zy-g"><i class="icon guiigoapp-shunxutu"></i>{lang guiigo_manage:tlang0384}</a>
								<!--{else}-->
									<a href="javascript:;" onclick="app.LoadPageForumView('.post-scroll','forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2',['gg-sq-hfsx','gg-sq-hfsxkz']);" class="zy-g"><i class="icon guiigoapp-shunxutu1"></i>{lang guiigo_manage:tlang0385}</a>
								<!--{/if}-->
							<!--{/if}-->
						</span>
					</div>
					<!--{if $_G[forum_thread][allreplies] == 0 }-->
					<div class="gg-sq-zwhf bg-c list-container-none">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0386}</p>
					</div>
					<!--{/if}-->
				<!--{/if}-->
				<!--{eval $postcount++;}-->
				<!--{/loop}-->
			</div>
			<!--{if !$_G[forum_thread][allreplies] == 0 }-->
			<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
				<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
			</div>
			<!--{/if}-->
			<!--{hook/viewthread_bottom_mobile}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<!--{subtemplate forum/forumdisplay_fastpost}-->
</div>
<!--{template common/footer}-->

