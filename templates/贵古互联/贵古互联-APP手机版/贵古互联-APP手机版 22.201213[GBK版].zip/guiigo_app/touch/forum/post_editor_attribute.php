<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div id="post_extra" class="gg-fb-gnon">
	<div class="gnon-gnqh list-block-no sh-a xh-b bg-e">
		<ul class="tabanv">
			<li onclick="tabPost(this)" data-meun="bqs"><a href="JavaScript:void(0)" class="zy-g"><i class="icon guiigoapp-biaoqing"></i><p>{lang guiigo_manage:tlang0150}</p></a></li>
			<!--{if in_array('guiigo_video',$_G['setting']['plugins']['available'])}-->
				<!--{if in_array($_G['fid'], dunserialize($_G['cache']['plugin']['guiigo_video']['video_openform'])) && in_array($_G['groupid'], dunserialize($_G['cache']['plugin']['guiigo_video']['video_opengid'])) && in_array('guiigo_manage',$_G['setting']['plugins']['available'])}-->
				<li onclick="tabPost(this)" data-meun="sp"><a href="JavaScript:void(0)" class="zy-g"><i class="icon guiigoapp-shipin"></i><p>{lang guiigo_manage:tlang0267}</p></a></li>
				<!--{/if}-->
			<!--{/if}-->
			<li onclick="tabPost(this)" data-meun="sz"><a href="JavaScript:void(0)" class="zy-g"><i class="icon guiigoapp-shezhi1"></i><p>{lang guiigo_manage:tlang0268}</p></a></li>
			<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
				<!--{if $_G['group']['maxprice'] && !$special}-->
					<li onclick="tabPost(this)" data-meun="sf"><a href="JavaScript:void(0)" class="zy-g"><i class="icon guiigoapp-daishoufei"></i><p>{lang guiigo_manage:tlang0269}</p></a></li>
				<!--{/if}-->
				<!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
					<li onclick="tabPost(this)" data-meun="ql"><a href="JavaScript:void(0)" class="zy-g"><i class="icon guiigoapp-quick_answer"></i><p>{lang guiigo_manage:tlang0143}</p></a></li>
				<!--{/if}-->
				<!--{if $_G['group']['allowreplycredit'] && !in_array($special, array(2, 3))}-->
					<!--{if $_GET[action] == 'newthread'}-->
						<!--{eval $extcreditstype = $_G['setting']['creditstransextra'][10];}-->
					<!--{else}-->
						<!--{eval $extcreditstype = $replycredit_rule['extcreditstype'] ? $replycredit_rule['extcreditstype'] : $_G['setting']['creditstransextra'][10];}-->
					<!--{/if}-->
					<!--{eval $userextcredit = getuserprofile('extcredits'.$extcreditstype);}-->
					<!--{if ($_GET[action] == 'newthread' && $userextcredit > 0) || ($_GET[action] == 'edit' && $isorigauthor && isfirstpost)}-->
						<li onclick="tabPost(this)" data-meun="jl"><a href="JavaScript:void(0)" class="zy-g"><i class="icon guiigoapp-htjl"></i><p>{lang guiigo_manage:tlang1018}</p></a></li>
					<!--{/if}-->
				<!--{/if}-->
				<!--{if $_G['group']['allowposttag']}-->
					<li onclick="tabPost(this)" data-meun="bq"><a href="JavaScript:void(0)" class="zy-g"><i class="icon guiigoapp-biaoqian"></i><p>{lang guiigo_manage:tlang0270}</p></a></li>
				<!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowpostattach']}-->
			<li onclick="tabPost(this)" data-meun="fj"><a href="JavaScript:void(0)" class="zy-g"><i class="icon guiigoapp-fujian"></i><p>{lang guiigo_manage:tlang1021}</p></a>
			<!--{if $attachlist}-->
				<!--{if $attachval['isimage'] !=1}-->
					<span class="gnqh-fjts bg-j"></span>
				<!--{/if}-->
			<!--{/if}-->
			</li>
			<!--{/if}-->
			<li onclick="tabPost(this)" data-meun="cr"><a href="JavaScript:void(0)" class="zy-g"><i class="icon guiigoapp-zhifeiji"></i><p>{lang guiigo_manage:tlang0271}</p></a></li>
		</ul>
	</div>
	<div id="gnon-onks">
		<div class="gnon-bqs mx-a bg-c xh-b cl hides">
			<div class="guiigo-hfdp">
				<div class="kznr-bqnr sml_menu">
					<div class="bqnr-imgs cl swiper-container ck8-smiliestab">
						<div class="swiper-wrapper cl" id="ck8_data">
							<span style="width:100%;font-size:0.7rem;text-align:center;padding:25px 0;color:#333333;">
							{lang guiigo_manage:tlang1004}
							</span>
						</div>
						<div class="swiper-pagination"></div>
					</div>
					<div class="bqnr-bqqh bg-e cl swiper-container ck8-smiliestabs" style="overflow:hidden;">
						<div class="swiper-wrapper buttons-row" id="smilies"></div>
					</div>
				</div>
			</div>
		</div>
		
		<!--{if in_array('guiigo_video',$_G['setting']['plugins']['available'])}-->
		<!--{if in_array($_G['fid'], dunserialize($_G['cache']['plugin']['guiigo_video']['video_openform'])) && in_array($_G['groupid'], dunserialize($_G['cache']['plugin']['guiigo_video']['video_opengid'])) && in_array('guiigo_manage',$_G['setting']['plugins']['available'])}-->
		<div class="gnon-sp gnon-spsc mx-a bg-c xh-b cl hides">
			<!--{hook/post_guiigo_video_bottom_mobile}-->
		</div>
		<!--{/if}-->
		<!--{/if}-->
	
		<div class="gnon-sz gg-fb-fjgn mx-a bg-c xh-b cl hides">
			<div class="guiigo-wblb list-block-no cl">
				<ul>
					<!--{if $_GET[action] != 'edit'}-->
						<!--{if $_G['group']['allowanonymous']}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-f">{lang post_anonymous}</div>
								<div class="wblb-wbnr zy-h">
									<div class="guiigo-pc"><input type="checkbox" name="isanonymous" id="isanonymous" value="1" /><label for="isanonymous"><em></em></label></div>
								</div>
							</li>
						<!--{/if}-->
					<!--{else}-->
						<!--{if $_G['group']['allowanonymous'] || (!$_G['group']['allowanonymous'] && $orig['anonymous'])}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-f">{lang post_anonymous}</div>
								<div class="wblb-wbnr zy-h">
									<div class="guiigo-pc"><input type="checkbox" name="isanonymous" id="isanonymous" value="1" {if $orig['anonymous']}checked="checked"{/if} /><label for="isanonymous"><em></em></label></div>
								</div>
							</li>
						<!--{/if}-->
					<!--{/if}-->
					<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-f">{lang hiddenreplies}</div>
							<div class="wblb-wbnr zy-h">
								<div class="guiigo-pc"><input type="checkbox" name="hiddenreplies" id="hiddenreplies"{if $thread['hiddenreplies']} checked="checked"{/if} value="1"><label for="hiddenreplies"><em></em></label></div>
							</div>
						</li>
					<!--{/if}-->
					<!--{if $_G['uid'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost) && $special != 3}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-f">{lang post_descviewdefault}</div>
							<div class="wblb-wbnr zy-h">
								<div class="guiigo-pc"><input type="checkbox" name="ordertype" id="ordertype" value="1" $ordertypecheck /><label for="ordertype"><em></em></label></div>
							</div>
						</li>
					<!--{/if}-->
					<!--{if ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-f">{lang post_noticeauthor}</div>
							<div class="wblb-wbnr zy-h">
								<div class="guiigo-pc"><input type="checkbox" name="allownoticeauthor" id="allownoticeauthor" value="1"{if $allownoticeauthor} checked="checked"{/if} /><label for="allownoticeauthor"><em></em></label></div>
							</div>
						</li>
					<!--{/if}-->
					<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
						<!--{if $_G['group']['allowsetreadperm']}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-f">{lang readperm}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" class="guiigo-ps s-a select-picker" value="{lang unlimited}" data-select="readperm" />
									<select name="readperm" id="readperm" style="display:none;">
										<option value="">{lang unlimited}</option>
										<!--{loop $_G['cache']['groupreadaccess'] $val}-->
											<option value="$val[readaccess]" title="{lang readperm}: $val[readaccess]"{if $thread['readperm'] == $val[readaccess]} selected="selected"{/if}>$val[grouptitle]</option>
										<!--{/loop}-->
										<option value="255"{if $thread['readperm'] == 255} selected="selected"{/if}>{lang highest_right}</option>
									</select>
								</div>
							</li>
						<!--{/if}-->
					<!--{/if}-->
					<!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts'])}-->
						<!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts']) && ($_G['group']['allowstickthread'] || $_G['group']['allowdigestthread'])}-->
							<!--{if $_G['group']['allowstickthread']}-->
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-f">{lang post_stick_thread}</div>
									<div class="wblb-wbnr zy-h">
										<div class="guiigo-pc"><input type="checkbox" name="sticktopic" id="sticktopic" value="1" $stickcheck /><label for="sticktopic"><em></em></label></div>
									</div>
								</li>
							<!--{/if}-->
							<!--{if $_G['group']['allowdigestthread']}-->
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-f">{lang post_digest_thread}</div>
									<div class="wblb-wbnr zy-h">
										<div class="guiigo-pc"><input type="checkbox" name="addtodigest" id="addtodigest" value="1" $digestcheck /><label for="addtodigest"><em></em></label></div>
									</div>
								</li>
							<!--{/if}-->
						<!--{/if}-->
					<!--{elseif $_GET[action] == 'edit' && $_G['forum_auditstatuson']}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-f">{lang auditstatuson}</div>
							<div class="wblb-wbnr zy-h">
								<div class="guiigo-pc"><input type="checkbox" name="audit" id="audit" value="1"><label for="audit"><em></em></label></div>
							</div>
						</li>
					<!--{/if}-->
				</ul>
			</div>
		</div>
	
		<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->

			<!--{if $_G['group']['maxprice'] && !$special}-->
				<div class="gnon-sf gg-fb-fjgn mx-a bg-c xh-b cl hides">
					<div class="guiigo-wblb list-block-no cl">
						<ul>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang price}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" id="price" name="price" class="guiigo-px s-a" value="$thread[pricedisplay]" placeholder="{lang post_price_comment}" />
								</div>
								<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</div>
							</li>
						</ul>
					</div>
					<!--{if $_G['group']['maxprice'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
						<div class="gg-qz-flts bg-c" style="padding: 0;margin-bottom: .55rem;">
							<div class="flts-tsnr bk-d bg-p zy-b">
								<!--{if $_G['setting']['maxincperthread']}-->
									{lang post_price_income_comment}
								<!--{/if}-->
								<!--{if $_G['setting']['maxchargespan']}-->
									{lang post_price_charge_comment}
									<!--{if $_GET[action] == 'edit' && $freechargehours}-->
										{lang post_price_free_chargehours}
									<!--{/if}-->
								<!--{/if}-->
							</div>
						</div>
					<!--{/if}-->
				</div>
			<!--{/if}-->
			
			<!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
				<div class="gnon-ql gg-fb-fjgn mx-a bg-c xh-b cl hides">
					<div class="guiigo-wblb list-block-no cl">
						<ul>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang rushreply_change}</div>
								<div class="wblb-wbnr zy-h">
									<div class="guiigo-pc"><input type="checkbox" name="rushreply" id="rushreply" value="1" {if $_GET[action] == 'edit' && getstatus($thread['status'], 3)}disabled="disabled" checked="checked"{/if} /><label for="rushreply"><em></em></label></div>
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0275}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" name="rushreplyfrom" id="rushreplyfrom" class="guiigo-px s-a" autocomplete="off" value="$postinfo[rush][starttimefrom]" onkeyup="Dz('rushreply').checked = true;" placeholder="{lang guiigo_manage:tlang0276}" />
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0254}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" name="rushreplyto" id="rushreplyto"  class="guiigo-px s-a" autocomplete="off" value="$postinfo[rush][starttimeto]" onkeyup="Dz('rushreply').checked = true;" placeholder="{lang guiigo_manage:tlang0277}" />
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0278}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" name="rewardfloor" id="rewardfloor" class="guiigo-px s-a" value="$postinfo[rush][rewardfloor]" onkeyup="$('rushreply').checked = true;" placeholder="{lang guiigo_manage:tlang0279}" />
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="stopfloor">{lang stopfloor}</label></div>
								<div class="wblb-wbnr zy-h">
									<input type="text" name="replylimit" id="replylimit" class="guiigo-px s-a" autocomplete="off" value="$postinfo[rush][replylimit]" onkeyup="$('rushreply').checked = true;" placeholder="{lang replylimit}" />
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="stopfloor">{lang guiigo_manage:tlang0280}</label></div>
								<div class="wblb-wbnr zy-h">
									<input type="text" name="stopfloor" id="stopfloor" class="guiigo-px s-a" autocomplete="off" value="$postinfo[rush][stopfloor]" onkeyup="$('rushreply').checked = true;" placeholder="{lang guiigo_manage:tlang0281}"/>
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c"><label for="creditlimit"><!--{if $_G['setting']['creditstransextra'][11]}-->{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]}<!--{else}-->{lang credits}<!--{/if}-->{lang min_limit}</label></div>
								<div class="wblb-wbnr zy-h">
									<input type="text" name="creditlimit" id="creditlimit" class="guiigo-px s-a" autocomplete="off" value="$postinfo[rush][creditlimit]" onkeyup="$('rushreply').checked = true;" placeholder="<!--{if $_G['setting']['creditstransextra'][11]}-->({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]})<!--{else}-->{lang total_credits}<!--{/if}-->{lang post_rushreply_credit}" />
								</div>
							</li>
						</ul>
					</div>
				</div>
			<!--{/if}-->
			
			
			<!--{if !empty($userextcredit)}-->
				<div class="gnon-jl gg-fb-fjgn mx-a bg-c xh-b cl hides">
					<div class="guiigo-wblb list-block-no cl">
						<ul>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang1019}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" name="replycredit_extcredits" id="replycredit_extcredits" class="guiigo-px s-a" value="{if $replycredit_rule['extcredits'] && $thread['replycredit'] > 0}{$replycredit_rule['extcredits']}{else}0{/if}" onkeyup="javascript:getreplycredit();" onblur="extraCheck(0)" />
								</div>
								<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$extcreditstype][unit]}{$_G['setting']['extcredits'][$extcreditstype][title]}</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang1020}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" name="replycredit_times" id="replycredit_times" class="guiigo-px s-a" value="{if $replycredit_rule['lasttimes']}{$replycredit_rule['lasttimes']}{else}1{/if}" onkeyup="javascript:getreplycredit();" onblur="extraCheck(0)" />
								</div>
								<div class="wblb-wbdw zy-g">{lang replycredit_time}</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang1026}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" class="guiigo-ps s-a select-picker" value="1" data-select="replycredit_membertimes">
									<select id="replycredit_membertimes" name="replycredit_membertimes" style="display:none;">
									<!--{eval for($i=1;$i<11;$i++) {;}-->
									<option value="$i"{if $replycredit_rule['membertimes'] == $i} selected="selected"{/if}>$i</option>
									<!--{eval };}-->
									</select>
								</div>
								<div class="wblb-wbdw zy-g">{lang replycredit_time}</div>
							</li>
							
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang1027}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" class="guiigo-ps s-a select-picker" value="100" data-select="replycredit_random">
									<select id="replycredit_random" name="replycredit_random" style="display:none;">
									<!--{eval for($i=100;$i>9;$i=$i-10) {;}-->
									<option value="$i"{if $replycredit_rule['random'] == $i} selected="selected"{/if}>$i</option>
									<!--{eval };}-->
									</select>
								</div>
								<div class="wblb-wbdw zy-g">%</div>
							</li>
					
						</ul>
					</div>
					<div class="gg-qz-flts bg-c" style="padding: 0;margin-bottom: .55rem;">
						<div class="flts-tsnr bk-d bg-p zy-b">
							{lang replycredit_total}<span id="replycredit_sum"><!--{if $thread['replycredit']}-->{$thread['replycredit']}<!--{else}-->0<!--{/if}--></span>{$_G['setting']['extcredits'][$extcreditstype][unit]}{$_G['setting']['extcredits'][$extcreditstype][title]}<!--{if $thread['replycredit']}--><span class="xg1">({lang replycredit_however} {$thread['replycredit']} {$_G['setting']['extcredits'][$extcreditstype][unit]}{$_G['setting']['extcredits'][$extcreditstype][title]})</span><!--{/if}-->, <span id="replycredit">{lang replycredit_revenue} {$_G['setting']['extcredits'][$extcreditstype][title]} 0</span>{$_G['setting']['extcredits'][$extcreditstype][unit]}, {lang you_have} {$_G['setting']['extcredits'][$extcreditstype][title]} $userextcredit {$_G['setting']['extcredits'][$extcreditstype][unit]}
						</div>
					</div>
				</div>
			<!--{/if}-->
			<!--{if $_G['group']['allowposttag']}-->
				<div class="gnon-bq gg-fb-fjgn mx-a bg-c xh-b cl hides">
					<div class="guiigo-wblb list-block-no cl">
						<ul>
							<li class="guiigo-flex xh-b">
								<div class="wblb-wbbt zy-c">{lang post_tag}</div>
								<div class="wblb-wbnr zy-h">
									<input type="text" class="guiigo-px s-a" size="60" id="tags" name="tags" value="$postinfo[tag]" placeholder="{lang guiigo_manage:tlang0282}" />
								</div>
							</li>
						</ul>
					</div>
					<!--{eval $recent_use_tag = recent_use_tag();}-->
					<!--{if $recent_use_tag}-->
						<div class="fjgn-bqzx sh-a cl">
							<h2 class="zy-g">{lang recent_use_tag}</h2>
							<!--{eval $tagi = 0;}-->
							<!--{loop $recent_use_tag $var}-->
								<a href="javascript:;" class="bg-g zy-h" onclick="Dz('tags').value == '' ? Dz('tags').value += '$var' : Dz('tags').value += ',$var';">$var</a>
							<!--{/loop}-->
						</div>
					<!--{/if}-->
				</div>
			<!--{/if}-->
		<!--{/if}-->
		<!--{if $_G['group']['allowpostattach']}-->
		<div class="gnon-fj gg-fb-fjgn mx-a bg-c xh-b cl hides">
			<a href="JavaScript:void(0)" class="fjon-anys bg-e">
				<div id="fileupprogress" class="anys-jd"></div>
				<div id="anyswzkz" class="anys-wz"><i class="icon guiigoapp-shangchuan"></i>{lang guiigo_manage:tlang1022}</div>
				<input type="file" name="Filedata" class="mediaup" multiple="multiple" onchange="fileupattach(this);"/>
			</a>
			<div id="fjon" class="fjon-fjli">
				<!--{loop $attachlist $attachval2}-->
				<div class="imgviwe xh-b" id="delattac_{$attachval2['aid']}"{if $attachval2['isimage'] ==1} style="display:none;"{/if}>
					<img src="template/guiigo_app/static/images/guiigo-fj.png">
					<a class="p_input" href="javascript:;" 
						data-aid="{$attachval2['aid']}" 
						data-isimage="{$attachval2['isimage']}" 
						data-tid="{$_GET['tid']}" 
						data-pid="{$_GET['pid']}" 
						onclick="delattac(this);">{lang guiigo_manage:tlang0685}</a>
						<!--{if $_G['group']['maxprice'] || $_G['group']['allowsetattachperm']}-->	
							<div class="setting cl">
								<div class="ction atds">
									<span>{lang guiigo_manage:tlang0991}</span>
									<input type="text" name="attachnew[{$attachval2['aid']}][description]" class="px" value="$attachval2[description]" size="6" style="float: left;width: 89%;padding: 0 2%;height: 22px;line-height: 22px;border: 0;border-radius: 2px;background: #f7f7f7;"/>
								</div>
								<!--{if $_G['group']['allowsetattachperm']}-->
									<div class="ction attv">
										<span>{lang guiigo_manage:tlang1009}</span>
										<!--{if $_G['cache']['groupreadaccess']}-->
											<input type="text" class="guiigo-ps s-a select-picker" value="{lang guiigo_manage:tlang1023}" data-select="readperm2" style="float: left;width: 70%;height: 22px;line-height: 22px;padding-left: 5px;border: 0;color: #000;border-radius: 2px;background-color: #f7f7f7;background-position: 95%;background-size: .35rem auto;">
											<select class="ps" name="attachnew[{$attachval2['aid']}][readperm]" id="readperm2" tabindex="1" style="display: none;">
												<option value="">{lang guiigo_manage:tlang1023}</option>
												<!--{loop $_G['cache']['groupreadaccess'] $val2}-->
													<option value="$val2[readaccess]" {if $attachval2[readperm] == $val2[readaccess]} selected{/if}>$val2[grouptitle]</option>
												<!--{/loop}-->
												<option value="255" {if $attachval2[readperm] == 255}selected{/if}>{lang guiigo_manage:tlang1024}</option>
											</select>
										<!--{/if}-->
									</div>
								<!--{/if}-->
								<!--{if $_G['group']['maxprice']}-->
									<div class="ction attpr">
										<span>{lang guiigo_manage:tlang1025}</span>
										<input type="text" name="attachnew[{$attachval2['aid']}][price]" class="px" value="$attachval2[price]" size="1" style="float: left;width: 50%;padding: 0 1%;height: 22px;line-height: 22px;border: 0;border-radius: 2px;background: #f7f7f7;"/>
										<span class="fj-dw">{$_G[setting][extcredits][$_G[setting][creditstransextra][1]][title]}</span>
									</div>
								<!--{/if}-->
							</div>
						<!--{/if}-->
				</div>
				<!--{/loop}-->
			</div>
			<!--{if $_G['group']['maxattachsize'] || $_G['group']['attachextensions']}-->
			<div class="gg-qz-flts bg-c" style="padding: 0;margin-top: .75rem;">
				<div class="flts-tsnr bk-d bg-p zy-b">
					<p>
					<!--{if $_G['group']['maxattachsize'] && $maxattachsize_mb}-->
						{lang guiigo_manage:tlang1010}$maxattachsize_mb 
					<!--{else}-->
						{lang guiigo_manage:tlang1011}
					<!--{/if}-->
					</p>
					<!--{if $_G['group']['attachextensions']}-->
					<p>{lang guiigo_manage:tlang1012}{$_G['group']['attachextensions']}</p>
					<!--{/if}-->
				</div>
			</div>
			<!--{/if}-->
		</div>
		<!--{/if}-->
		<div class="gnon-cr onks-crgn xh-b mx-a cl hides tabmunszml">
			<div class="crgn-gndf list-block-no bg-c xh-b cl">
				<ul class="tabmuns">
					<!--{if ($_GET[action] == 'newthread' || $_GET[action] == 'reply' || $_GET[action] == 'edit') && $_G['group']['allowat']}-->
						<li onclick="tabMun(this)" data-meun="at_menu"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-fbcrat"></i>{lang guiigo_manage:tlang0283}</a></li>
					<!--{/if}-->
					<li onclick="tabMun(this)" data-meun="wz"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-fbcrlj"></i>{lang guiigo_manage:tlang0284}</a></li>
					<li onclick="tabMun(this)" data-meun="tp"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-fbcrtp"></i>{lang guiigo_manage:tlang0285}</a></li>
					<!--{if $_G['forum']['allowmediacode'] && $_G['group']['allowmediacode']}-->
						<li onclick="tabMun(this)" data-meun="yl"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-fbcryy"></i>{lang guiigo_manage:tlang0286}</a></li>
						<li onclick="tabMun(this)" data-meun="sp"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-fbcrsp"></i>{lang guiigo_manage:tlang0287}</a></li>
						<li onclick="tabMun(this)" data-meun="fl"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-fbcrfs"></i>Flash</a></li>
					<!--{/if}-->
					<li onclick="tabMun(this)" data-meun="yy"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-fbcryr"></i>{lang guiigo_manage:tlang0288}</a></li>
					<!--{if $isfirstpost}-->
						<li onclick="tabMun(this)" data-meun="mf"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-fbcrmf"></i>{lang guiigo_manage:tlang0289}</a></li>
					<!--{/if}-->
					<li onclick="tabMun(this)" data-meun="dm"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-fbcrdm"></i>{lang guiigo_manage:tlang0290}</a></li>
					<li onclick="tabMun(this)" data-meun="mm"><a href="javascript:;" class="bk-e zy-g"><i class="icon guiigoapp-mima"></i>{lang guiigo_manage:tlang0291}</a></li>
				</ul>
			</div>
			<div class="crgn-gnjt bg-c wz hidesmun" style="display: none;">
				<div class="gnjt-dxys guiigo-flex xh-b">
					<input type="text" name="text" id="gncr-ljwz" class="guiigo-px guiigo-flexy s-a" placeholder="{lang guiigo_manage:tlang0244}">
				</div>
				<div class="gnjt-dxys guiigo-flex xh-b">
					<input type="text" name="text" id="gncr-ljzs" class="guiigo-px guiigo-flexy s-a" placeholder="{lang guiigo_manage:tlang0245}">
					<a href="javascript:;" id="gnjt-wzlj" class="guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0271}</a>
				</div>
			</div>
			
			<div class="crgn-gnjt bg-c tp hidesmun" style="display: none;">
				<div class="gnjt-dxys guiigo-flex xh-b">
					<input type="text" name="text" id="gncr-wltp" class="guiigo-px guiigo-flexy s-a" placeholder="{lang guiigo_manage:tlang0246}">
					<a href="javascript:;" id="gnjt-wltp" class="guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0271}</a>
				</div>
			</div>
			
			<div class="crgn-gnjt bg-c yy hidesmun" style="display: none;">
				<div class="gnjt-dxys gnjt-dxyx guiigo-flex">
					<textarea id="gncr-yynr" class="guiigo-px bg-e" placeholder="{lang guiigo_manage:tlang0247}"></textarea>
				</div>
				<div class="gnjt-dxys gnjt-dxya guiigo-flex">
					<a href="javascript:;" id="gnjt-yynr" class="guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0271}</a>
				</div>
			</div>
			
			<!--{if $_G['forum']['allowmediacode'] && $_G['group']['allowmediacode']}-->
				<div class="crgn-gnjt bg-c yl hidesmun" style="display: none;">
					<div class="gnjt-dxys guiigo-flex xh-b">
						<input type="text" name="text" id="gncr-pm3" class="guiigo-px guiigo-flexy s-a" placeholder="{lang guiigo_manage:tlang0243}">
						<a href="javascript:;" id="gnjt-mp3" class="guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0271}</a>
					</div>
					<div class="gnjt-tsnr zy-g">{lang guiigo_manage:tlang0292}</div>
				</div>
				
				<div class="crgn-gnjt bg-c sp hidesmun" style="display: none;">
					<div class="gnjt-dxys guiigo-flex xh-b">
						<input type="text" name="text" id="gncr-pm4" class="guiigo-px guiigo-flexy s-a" placeholder="{lang guiigo_manage:tlang0248}">
						<a href="javascript:;" id="gnjt-mp4" class="guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0271}</a>
					</div>
					<div class="gnjt-tsnr zy-g">{lang guiigo_manage:tlang0293}</div>
				</div>
				
				<div class="crgn-gnjt bg-c fl hidesmun" style="display: none;">
					<div class="gnjt-dxys guiigo-flex xh-b">
						<input type="text" name="text" id="gncr-flas" class="guiigo-px guiigo-flexy s-a" placeholder="{lang guiigo_manage:tlang0249}">
						<a href="javascript:;" id="gnjt-flas" class="guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0271}</a>
					</div>
					<div class="gnjt-tsnr zy-g">{lang guiigo_manage:tlang0294}</div>
				</div>
			<!--{/if}-->
			
			<!--{if $isfirstpost}-->
				<div class="crgn-gnjt bg-c mf hidesmun" style="display: none;">
					<div class="gnjt-dxys gnjt-dxyx guiigo-flex">
						<textarea id="gncr-mfxx" class="guiigo-px bg-e" placeholder="{lang guiigo_manage:tlang0295}"></textarea>
					</div>
					<div class="gnjt-dxys gnjt-dxya guiigo-flex">
						<a href="javascript:;" id="gnjt-mfxx" class="guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0271}</a>
					</div>
				</div>
			<!--{/if}-->
			
			<div class="crgn-gnjt bg-c dm hidesmun" style="display: none;">
				<div class="gnjt-dxys gnjt-dxyx guiigo-flex">
					<textarea id="gncr-dmnr" class="guiigo-px bg-e" placeholder="{lang guiigo_manage:tlang0251}"></textarea>
				</div>
				<div class="gnjt-dxys gnjt-dxya guiigo-flex">
					<a href="javascript:;" id="gnjt-dmnr" class="guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0271}</a>
				</div>
			</div>
			
			<div class="crgn-gnjt bg-c mm hidesmun" style="display: none;">
				<div class="gnjt-dxys guiigo-flex xh-b">
					<input type="text" name="text" id="gncr-mmzt" class="guiigo-px guiigo-flexy s-a" placeholder="{lang guiigo_manage:tlang0216}">
					<a href="javascript:;" id="gnjt-mmzt" class="guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0106}</a>
				</div>
				<div class="gnjt-tsnr zy-i">{lang guiigo_manage:tlang0296}</div>
			</div>
		
		</div>
	</div>
</div>

