<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div id="hdnr-on">
	<div class="gg-sq-hdnr">
		<!--{if $activity['thumb']}--><img src="$activity['thumb']"/><!--{else}--><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/gg-hdfm.jpg" /><!--{/if}-->
		<div class="hdnr-hdmx ms-a sh-a yh-a zh-a cl">
			<dl class="xh-b"><dt class="bg-e yh-a zy-f">{lang activity_type}</dt><dd class="zy-h">$activity[class]</dd></dl>
			<dl class="xh-b"><dt class="bg-e yh-a zy-f">{lang activity_starttime}</dt><dd class="zy-h"><!--{if $activity['starttimeto']}-->{lang activity_start_between}<!--{else}-->$activity[starttimefrom]<!--{/if}--></dd></dl>
			<dl class="xh-b"><dt class="bg-e yh-a zy-f">{lang activity_space}</dt><dd class="zy-h">$activity[place]</dd></dl>
			<dl class="xh-b"><dt class="bg-e yh-a zy-f">{lang gender}</dt><dd class="zy-h"><!--{if $activity['gender'] == 1}-->{lang male}<!--{elseif $activity['gender'] == 2}-->{lang female}<!--{else}-->{lang unlimited}<!--{/if}--></dd></dl>
			<!--{if $activity['cost']}-->
				<dl class="xh-b"><dt class="bg-e yh-a zy-f">{lang activity_payment}</dt><dd class="zy-h">$activity[cost] {lang payment_unit}</dd></dl>
			<!--{/if}-->
			<!--{if !$_G['forum_thread']['is_archived']}-->
				<dl class="xh-b">
					<dt class="bg-e yh-a zy-f">{lang activity_already}</dt>
					<dd class="zy-h">
						$allapplynum {lang activity_member_unit}
						<!--{if $post['invisible'] == 0 && ($_G['forum_thread']['authorid'] == $_G['uid'] || (in_array($_G['group']['radminid'], array(1, 2)) && $_G['group']['alloweditactivity']) || ( $_G['group']['radminid'] == 3 && $_G['forum']['ismoderator'] && $_G['group']['alloweditactivity']))}-->
							<span class="hdnr-glxx">
								<a href="misc.php?mod=invite&action=thread&id=$_G[tid]&pid=$post[pid]&activity=1" 
									class="bg-e zy-g bk-e dialog"
									ck-cus="true"
									ck-param="{type:'modal',callpar:{'pid':'$post[pid]',type:'invite'},fn:'MsgCallInvite',load:'true',uid:'$_G[uid]'}"
									external >{lang invite}</a>
								<a href="forum.php?mod=misc&action=activityapplylist&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}" 
									class="bg-e zy-g bk-e dialog"
									ck-cus="true"
									ck-param="{type:'modal',callpar:{'pid':'$post[pid]',type:'invite'},fn:'MsgCallInvite',load:'true',uid:'$_G[uid]'}" 
									external >{lang manage}</a>
								<a href="forum.php?mod=misc&action=activityexport&tid=$_G[tid]" class="bg-e zy-g bk-e">{lang pm_archive}</a>
							</span>
						<!--{/if}-->
					</dd>
				</dl>
				<!--{if $activity['number']}-->
					<dl class="xh-b"><dt class="bg-e yh-a zy-f">{lang activity_about_member}</dt><dd class="zy-h">$aboutmembers {lang activity_member_unit}</dd></dl>
				<!--{/if}-->
				<!--{if $activity['expiration']}-->
					<dl class="xh-b"><dt class="bg-e yh-a zy-f">{lang post_closing}</dt><dd class="zy-h">$activity[expiration]</dd></dl>
				<!--{/if}-->
				<!--{if $post['invisible'] == 0}-->
					<!--{if $applied && $isverified < 2}-->
						<dl class="xh-b"><dt class="bg-e yh-a zy-f">{lang guiigo_manage:tlang0387}</dt><dd class="zy-h"><!--{if !$isverified}-->{lang guiigo_manage:tlang0388}<!--{else}-->{lang guiigo_manage:tlang0389}<!--{/if}--></dd></dl>
						<!--{if !$activityclose}-->
						<!--{/if}-->
					<!--{/if}-->
				<!--{/if}-->
			<!--{/if}-->
		</div>
	</div>
	<div id="postmessage_$post[pid]" class="gg-sq-hdjs zy-f">
		<!--{if $_G['uid'] && !$activityclose && (!$applied || $isverified == 2)}--><a href="JavaScript:void(0)" class="guiigo-pn ab-az zy-a zy-ac" onclick="app.ActionsManage('#gg-sq-hdbm','t', 'auto','closehfdp');"><!--{if $isverified != 2}-->{lang activity_join}<!--{else}-->{lang complete_data}<!--{/if}--></a><!--{elseif $_G['uid'] && !$activityclose && $applied}--><a href="JavaScript:void(0)"  class="guiigo-pn ab-az zy-a zy-ac" onclick="app.ActionsManage('#gg-sq-qxbm','t', 'auto','closehfdp');">{lang activity_join_cancel}</a><!--{/if}-->
		<h1 class="xh-b zy-h">{lang guiigo_manage:tlang0390}</h1>
		$post[message]
	</div>
	<!--{if $applylist}-->
	<div class="gg-sq-hdhy">
		<h1 class="xh-b zy-h">{lang activity_new_join}<em class="zy-f">$applynumbers {lang activity_member_unit}</em></h1>
		<div class="guiigo-hylb guiigo-hlmw list-block-no bg-c">
			<ul class="ms-c">
				<!--{loop $applylist $apply}-->
				<li class="sh-a">
					<a href="home.php?mod=space&uid=$apply[uid]&amp;do=profile" class="guiigo-tys">
						<!--{echo avatar($apply[uid], 'middle')}-->
						<h2 class="zy-h"><i class="zy-c">$apply[dateline]</i>$apply[username]</h2>
						<p class="zy-g"><!--{if $apply[message]}--><!--{echo cutstr($apply[message],40)}--><!--{else}-->{lang guiigo_manage:tlang0391}<!--{/if}--></p>
					</a>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{/if}-->
	<!--{if $applylistverified}-->
	<div class="gg-sq-hdhy">
		<h1 class="xh-b zy-h">{lang activity_new_signup}<em class="zy-f">$noverifiednum {lang activity_member_unit}</em></h1>
		<div class="guiigo-hylb guiigo-hlmw list-block-no bg-c">
			<ul class="ms-c">
				<!--{loop $applylistverified $apply}-->
				<li class="sh-a">
					<a href="home.php?mod=space&uid=$apply[uid]&amp;do=profile" class="guiigo-tys">
						<!--{echo avatar($apply[uid], 'middle')}-->
						<h2 class="zy-h"><i class="zy-c">$apply[dateline]</i>$apply[username]</h2>
						<p class="zy-g"><!--{if $_G['forum_thread']['authorid'] == $_G['uid'] && $apply[message]}--><!--{echo cutstr($apply[message],40)}--><!--{else}-->{lang guiigo_manage:tlang0391}<!--{/if}--></p>
					</a>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{/if}-->
	<div class="popup-actions" id="gg-sq-hdbm">
		<div class="actions-text guiigo-hfdp bg-c">
			<div class="hfdp-btys xh-b bg-g">
				<a href="javascript:;" class="btys-gbck closehfdp"><i class="icon guiigoapp-guanbi zy-c"></i></a>
				<h2 class="zy-h"><!--{if $isverified != 2}-->{lang activity_join}<!--{else}-->{lang complete_data}<!--{/if}--></h2>
			</div>
			<!--{if $_G['forum']['status'] == 3 && helper_access::check_module('group') && $isgroupuser != 'isgroupuser'}-->
				<div class="guiigo-wnrtx guiigo-wnrtxx">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang activity_no_member}</p>
					<a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="ab-az zy-a zy-ac">{lang guiigo_manage:tlang0392}</a>
				</div>
			<!--{else}-->
				<form name="activity" 
				id="activity" 
				method="post" 
				autocomplete="off" 
				action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}&mobile=2" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{tid:'$_G[tid]',type:'activity'},fn:'MsgCallInvite',load:'true',uid:'$_G[uid]'}"
				>
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="guiigo-wblb list-block-no cl">
						<ul>
						<!--{if $activity['cost']}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang activity_paytype}</div>
								<div class="wblb-wbnr">
									<label class="guiigo-pds"><input class="guiigo-pd-k" type="radio" value="0" name="payment" id="payment_0" checked="checked" /><span></span>{lang activity_pay_myself}</label>
									<label class="guiigo-pds guiigo-pdsj"><input class="guiigo-pd-k" type="radio" value="1" name="payment" id="payment_1" /><span></span>{lang activity_would_payment}</label> 
									<input name="payvalue" size="3" class="guiigo-px guiigo-pxkd bk-e" /> {lang payment_unit}
								</div>
							</li>
						<!--{/if}-->
						<!--{if !empty($activity['ufield']['userfield'])}-->
							<!--{loop $activity['ufield']['userfield'] $fieldid}-->
							<!--{if $settings[$fieldid][available]}-->
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">$settings[$fieldid][title] <span class="zy-i">*</span></div>
									<div class="wblb-wbnr gg-sq-hdqq zy-h">$htmls[$fieldid]</div>
								</li>
							<!--{/if}-->
							<!--{/loop}-->
						<!--{/if}-->
						<!--{if !empty($activity['ufield']['extfield'])}-->
							<!--{loop $activity['ufield']['extfield'] $extname}-->
								<li class="wblb-dkbt bg-g xh-b zy-c cl">$extname</li>
								<li class="wblb-nrsr xh-b zy-h cl">
									<div class="wblb-wbnr zy-h"><input type="text" name="$extname" maxlength="200" class="guiigo-pt s-a" value="{if !empty($ufielddata)}$ufielddata[extfield][$extname]{/if}" /></div>
								</li>
							<!--{/loop}-->
						<!--{/if}-->
							<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang leaveword}</li>
							<li class="wblb-nrsr xh-b zy-h cl">
								<div class="wblb-wbnr zy-h"><textarea name="message" maxlength="200" cols="28" rows="1" class="guiigo-pt s-a">$applyinfo[message]</textarea></div>
							</li>
						</ul>
					</div>
					<div class="mn-a">
						<!--{if $_G['setting']['activitycredit'] && $activity['credit'] && checklowerlimit(array('extcredits'.$_G['setting']['activitycredit'] => '-'.$activity['credit']), $_G['uid'], 1, 0, 1) !== true}-->
							<div class="gg-sq-wdlfj gg-sq-cyqx bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]} {lang not_enough}$activity['credit']</div>
						<!--{else}-->
							<input type="hidden" name="activitysubmit" value="true">
							<em class="xi1" id="return_activityapplies"></em>
							<button type="submit" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang submit}</button>
							<!--{if $_G['setting']['activitycredit'] && $activity['credit'] && !$applied}--><div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang activity_need_credit} $activity[credit]{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</div><!--{/if}-->
						<!--{/if}-->
					</div>
				</form>
				<script type="text/javascript">
					function succeedhandle_activityapplies(locationhref, message) {
						showDialog(message, 'notice', '', 'location.href="' + locationhref + '"');
					}
				</script>
			<!--{/if}-->
		</div>
	</div>
	<div class="popup-actions" id="gg-sq-qxbm">
		<div class="actions-text guiigo-hfdp bg-c">
			<div class="hfdp-btys xh-b bg-g">
				<a href="javascript:;" class="btys-gbck closehfdp"><i class="icon guiigoapp-guanbi zy-c"></i></a>
				<h2 class="zy-h">{lang activity_join_cancel}</h2>
			</div>
			<form name="activity" 
			id="activity" 
			method="post" 
			autocomplete="off" 
			action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{tid:'$_G[tid]',type:'activity'},fn:'MsgCallInvite',load:'true',uid:'$_G[uid]'}"
			>
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<div class="guiigo-wblb list-block-no cl">
				<ul>
					<li class="guiigo-flex cl">
						<div class="wblb-wbbt zy-c">{lang leaveword}</div>
						<div class="wblb-wbnr zy-h"><input type="text" name="message" maxlength="200" class="guiigo-px s-a" value="" placeholder="{lang guiigo_manage:tlang0393}"/></div>
					</li>
				</ul>
			</div>
			<div class="mn-a">
				<button type="submit" id="activitycancel" name="activitycancel" class="formdialog guiigo-pn ab-az zy-a zy-ac" value="true">{lang submit}</button>
				<input type="hidden" name="activitycancel" value="true" />
			</div>
			</form>
		</div>
	</div>
</div>
