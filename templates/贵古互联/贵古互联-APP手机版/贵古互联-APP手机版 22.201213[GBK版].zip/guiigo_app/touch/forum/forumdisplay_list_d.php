<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="guiigo-pyq list-block-no bg-c ms-a">
	<ul class="list-container">
	<!--{loop $_G['forum_threadlist'] $key $thread}-->
	<!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))> 0 }-->
	<!--{if $thread['closed'] > 1 || $thread['moved']}-->
		<!--{eval $thread[tid]=$thread[closed];}-->
	<!--{/if}-->
	<!--{if (!$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0) || $thread['displayorder'] < 0}-->
		{eval continue;}
	<!--{/if}-->
		<li class="gpql-li">
			<div class="qlli-yhtx guiigo-ty">
				<!--{if $thread['authorid'] && $thread['author']}--><a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><!--{avatar($thread[authorid],middle)}--></a><!--{else}--><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg"><!--{/if}-->
			</div>
			<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><!--{elseif $thread['digest'] > 0}-->
				<div class="gztlb-jhzt gztlb-pjhzt"><i class="icon guiigoapp-jinghua zy-i"></i></div>
			<!--{/if}-->
			<div class="qlli-xxon">
				<!--{if $thread['authorid'] && $thread['author']}-->
					<div class="xxon-xxgz">
						<!--{if $thread['isfollow'] ==1}-->
						<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$thread['authorid']" 
						class="followmod_$thread[authorid] dialog xxgz-gzan bg-e zy-g"
						ck-cus="true" 
						ck-confirm="true" 
						ck-param="{type:'modal',callpar:{tid:'$thread['authorid']'},fn:'MsgCallFnp',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}" 
						external >{lang guiigo_manage:tlang0003}</a>
						<!--{else}-->
						<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]" 
						class="followmod_$thread[authorid] dialog xxgz-gzan bg-j zy-a" 
						ck-cus="true"
						ck-confirm="false"
						ck-param="{type:'modal',callpar:{tid:'$thread[authorid]'},fn:'MsgCallFnp',load:'true',uid:'{$_G[uid]}'}"
						external >+ {lang guiigo_manage:tlang0002}</a>
						<!--{/if}-->
						<h1 class="ggpyq-flex">
							<a href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
							<!--{if $thread['gender'] == 1 || $thread['gender'] == 0}-->
							<i class="icon guiigoapp-nan bg-n"></i>
							<!--{elseif $thread['gender'] == 2}-->
							<i class="icon guiigoapp-nv bg-o"></i>
							<!--{/if}-->
							<!--{if !empty($verify[$thread['authorid']])}--> 
								<!--{eval $verifyicon = str_replace('target="_blank"', $verify[$thread['authorid']]);}--> 
								<span>$verify[$thread['authorid']]</span>
							<!--{/if}-->
						</h1>
						<div class="xxgz-djsj">
							<a href="javascript:;">{$thread[grouptitle]}</a><!--{eval echo dgmdate($thread[dateline], 'u');}-->
						</div>
					</div>
				<!--{else}-->
					<div class="xxon-xxgz">
						<h1 class="ggpyq-flex">
							<a href="javascript:void(0);">$_G[setting][anonymoustext]</a>
						</h1>
						<div class="xxgz-djsj"><!--{eval echo dgmdate($thread[dateline], 'u');}--></div>
					</div>
				<!--{/if}-->
				<div class="xxon-nror">
					<!--{eval $typehtmls=str_replace(array('[',']'),'',$thread[typehtml]);}-->
					<div class="nror-nron">
						<span><!--{if $typehtmls || $sorthtmls}-->#$typehtmls#<!--{/if}--></span>
						<!--{if $thread[special] == 1}-->
							<span><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">#{lang guiigo_manage:tlang0138}#</a></span>
						<!--{elseif $thread[special] == 2}-->
							<span><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">#{lang guiigo_manage:tlang0139}#</a></span>
						<!--{elseif $thread[special] == 3}-->
							<span><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">#{lang guiigo_manage:tlang0140}#</a></span>
						<!--{elseif $thread[special] == 4}-->
							<span><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">#{lang guiigo_manage:tlang0141}#</a></span>
						<!--{elseif $thread[special] == 5}-->
							<span><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">#{lang guiigo_manage:tlang0142}#</a></span>
						<!--{elseif $thread['rushreply']}-->
							<span><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">#{lang guiigo_manage:tlang0143}#</a></span>
						<!--{/if}-->
						<!--{if $thread['replycredit'] > 0}-->
							<span class="zy-i"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-i">#{lang guiigo_manage:tlang1046}#</a></span>
						<!--{/if}-->
						<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"><!--{$thread['message2']}--></a>
					</div>
					<!--{eval $cunm = count($thread[attapic]);}-->
					<!--{if $cunm > 0}-->
					<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
						<div class="nror-img">
							<ul style="display: flex;justify-content: left;flex-wrap: wrap;">
								<!--{loop $thread[attapic] $imgkey $imglist}-->
									<li class="imgs{if $imglist['countImg'] == 1} imgs-1{elseif $imglist['countImg'] == 2 || $imglist['countImg'] == 4} imgs-24{elseif $imglist['countImg'] == 3 || $imglist['countImg'] == 5 || $imglist['countImg'] >= 6} imgs-356{/if}"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
									
								<!--{/loop}-->
								<!--{if $imglist['countImg'] > 6}--><div class="imgs-sl">{$imglist['countImg']}{lang guiigo_manage:tlang1043}</div><!--{/if}-->
							</ul>
						</div>
					</a>
					<!--{/if}-->
					<div class="nror-cjkz"><!--{hook/forumdisplay_thread_mobile $key}--></div>
				</div>
				<div class="xxon-czgn ggpyq-flex">
					<a href="javascript:;"{if $_G[uid]} onclick="ActionsManage('$thread[fid]','$thread[tid]')"{else} class="login"{/if}><i class="icon guiigoapp-wenda"></i>{lang guiigo_manage:tlang0148}</a>
					<div style="display:none;">
						<div id="username_{$thread[tid]}">{$_G['username']}</div>
						<div id="avatar_{$thread[tid]}">{eval echo avatar($_G['uid'], 'small', true);}</div>
						<div id="time_{$thread[tid]}">{eval echo dgmdate(time(),'u');}</div>
					</div>
					<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
						<!--{eval $recommenus=$thread['isrecommenus']==1 ? 1 :'';}-->
						<span id="recommendp_add_$thread[tid]">
							<a href="{if $recommenus}plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid=$thread[tid]{else}forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&hash={FORMHASH}&handlekey=recommend_add{/if}" 
							class="{if $recommenus}delRecommenus{else}dialog{/if}" 
							ck-cus="true"
							ck-param="{
								type:'modal',
								callpar:{tid:'$thread[tid]'},
								fn:'MsgCallFnp',
								load:'true',
								uid:'{$_G[uid]}'
							}" 
							external ><i class="icon{if $recommenus} guiigoapp-aixin1 zy-i{else} guiigoapp-aixin{/if}"></i>{lang guiigo_manage:tlang1042}
							</a>
						</span>
					<!--{/if}-->
					
					<!--
					<a href="javascript:;" class="czgn-gdcz" onclick="ck8.toast('&#30041;&#23384;&#22791;&#29992;')"><i class="icon guiigoapp-caozuo"></i></a>
					-->
				</div>
				<!--{eval $recommenlist=GuiigoApp::getrecommendbyid($thread[tid],'',1,100);}-->
				<!--{if $thread[replies] > 0 || $recommenlist}-->
					<div class="xxon-pldz">
						<!--{if $thread[replies] > 0}-->
						<div class="pldz-plon">
							<ul>
								<!--{loop $thread[floor] $key2 $fval}-->
									<li><a href="home.php?mod=space&uid=$fval['authorid']&do=profile">{$fval['author']} </a>{$fval['message']}</li>
								<!--{/loop}-->
								<!--{if $thread[replies] > 6}-->
									<li class="plon-zkgd"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">{lang guiigo_manage:tlang0130}<i>$thread[replies]</i>{lang guiigo_manage:tlang1044}</a></li>
								<!--{/if}-->
							</ul>
						</div>
						<!--{/if}-->
						<!--{if $recommenlist}-->
						<div class="pldz-dzon">
							<div class="dzon-dzbz"><i class="icon guiigoapp-aixin1"></i></div>
							<ul class="cl">
								<!--{loop $recommenlist $tkey $rval}-->
								<!--{eval $avatarurl = avatar($rval['uid'],'small', true);}-->
								<li><a href="home.php?mod=space&uid=$rval['uid']&do=profile"><img lazySrc="$avatarurl" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy"></a></li>
								<!--{/loop}-->	
							</ul>
						</div>
						<!--{/if}-->
					</div>
				<!--{/if}-->
			</div>
		</li>
		<!--{hook/forumdisplay_threads_mobile $key}-->
	<!--{/if}-->
	<!--{/loop}-->
	</ul>
	<div class="popup-actions" id="guiigo-hfdp-floor">
		<div class="actions-text guiigo-hfdp bg-c">
			<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&replysubmit=yes">
			    <input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="hfdp-btys xh-b bg-g">
					<a href="javascript:;" class="btys-gbck floorclosehfdp"><i class="icon guiigoapp-guanbi zy-c"></i></a>
					<h2 class="zy-h">{lang guiigo_manage:tlang0148}</h2>
				</div>
				<div class="hfdp-srys xh-b bg-c">
				<textarea type="text" class="guiigo-pt zy-f" color="gray" name="message" 
				id="needmessage" placeholder="{lang guiigo_manage:tlang0149}"></textarea>
				</div>
				<div class="hfdp-crqd xh-b bg-g">
					<div class="crqd-gdqd">
					<input type="button" 
					value="{lang reply}" 
					class="guiigo-pn ab-az zy-a zy-ac" 
					name="replysubmit"
					id="floor_fastpostform"
					data-fid="" 
					data-tid="" 
					onclick="fastpostsubmit(this);">
					</div>
					<div class="crqd-gjts">{lang guiigo_manage:tlang1045}</div>
				</div>
			</form>
		</div>
	</div>
	<script>
	function ActionsManage(fid, tid){
		ck8('#floor_fastpostform').attr('data-fid',fid).attr('data-tid',tid);
		app.ActionsManage('#guiigo-hfdp-floor','t','auto','floorclosehfdp');
	}
	function fastpostsubmit(obj){
		var form = ck8('#fastpostform');
		var fid = ck8(obj).attr('data-fid');
        var tid = ck8(obj).attr('data-tid');
		var needmessage = ck8('#needmessage').val();
		if(needmessage == '') {
			ck8.toast('{lang guiigo_manage:tlang0211}','shibai');
			return;
		}
		if(mb_strlen(needmessage) < 5) {
			ck8.toast('{lang guiigo_manage:tlang0212}','shibai');
			return;
		}
		ck8.ajax({
			type:'POST',
			url: form.attr('action') + '&handlekey=floorfastpost&loc=1&inajax=1&fid='+fid+'&tid='+tid,
			data: form.serialize(),
			dataType: 'xml',
			success: function(s){
				app.Devalscript(app.initAtr(s.lastChild.firstChild.nodeValue),function(msg,par){
					if(typeof msg !== 'object' || typeof par !== 'object'){
						ck8.toast('{lang guiigo_manage:tlang0146}','jinggao');
						return;
					}
					var pid = par['pid'];
					var tid = par['tid'];
					var fid = par['fid'];
					if(msg.msg && msg.msg.indexOf('{lang guiigo_manage:tlang0213}') != -1) {
						ck8.toast('{lang guiigo_manage:tlang0214}');
						ck8('#needmessage').val('');
						ck8('#guiigo-hfdp-floor').hide();

						var username = ck8('#username_'+ tid).html()
						var avatar = ck8('#avatar_'+ tid).html()
						var time = ck8('#time_'+ tid).html()
						
						var html = '<div class="f-1-1">'+
							' <img src="'+avatar+'" style="width:30px;height:30px;margin-right:10px;"/>'+
							 '<span>'+username+' : '+needmessage+' '+time+'</span>'+
						    '</div>';
							
                        ck8(html).prependTo('#floor_'+ tid)
					}else if(msg.msg) {
						ck8.toast(msg.msg,'shibai');
					}else if(!msg.msg) {
						msg.msg = '{lang postreplyneedmod}';
						ck8.toast(msg.msg,'shibai');
					}
				});
			}
		})
	}
	</script>
</div>
