<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'guiigoapp') !== false && !$_G['cache']['plugin']['guiigo_appmanage']['alltpl']}-->
<script type="text/javascript">
ck8(function() {
	if(!window.plus){
		ck8.SdkPlusReady(function(){
			ck8.plusReady(function(){
			   ck8.redirectTo('/pages/login/register');
			})
		})
	}else{
		ck8.redirectTo('/pages/login/register');
	}
});
</script>
<!--{else}-->
<div class="page page-current guiigo-dlbg" data-mod="login">
	<!--{if CURSCRIPT == 'member' && CURMODULE == {$_G[setting][regname]} && $_GET['do'] == 'bbrule'}-->
		<header class="bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
			<!--{if $_G['cache']['plugin']['guiigo_manage']['isguiigoapp']}-->
			<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
			<!--{else}-->
			<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
			<!--{/if}-->
			<h1 class="title zy-h">{lang guiigo_manage:tlang0833}</h1>
		</header>
	<!--{else}-->
		<script type="text/javascript">
			var strongpw = new Array();
			var pwlength = <!--{if $_G['setting']['pwlength']}-->$_G['setting']['pwlength']<!--{else}-->0<!--{/if}-->;
			<!--{if $_G['setting']['strongpw']}-->
				<!--{loop $_G['setting']['strongpw'] $key $val}-->
				strongpw[$key] = $val;
				<!--{/loop}-->
			<!--{/if}-->
			ck8(function(){
				app.loadScript('register')
			})
		</script>
		<!--{if $_G['guiigoapp']['appsetting']['regconfig']['regstyle'] == 1}-->
			<div class="swiper-container gg-dz-dlbg bg-r">
				<div class="swiper-wrapper dlbg-ysks">
					<!--{loop $_G['guiigoapp']['appsetting']['regconfig']['regsbjimg'] $val}-->
						<div class="swiper-slide" data-swiper-autoplay="7000"><img src="$val" /></div>
					<!--{/loop}-->
				</div>
			</div>
		<!--{else}-->
			<header class="bar bar-nav guiigo-nydb guiigo-dydb bg-c">
				<!--{if $_G['cache']['plugin']['guiigo_manage']['isguiigoapp']}-->
				<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
				<!--{else}-->
				<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
				<!--{/if}-->
				<h1 class="title zy-h">{lang guiigo_manage:tlang0995}</h1>
			</header>
		<!--{/if}-->
	<!--{/if}-->
	<div class="content{if CURSCRIPT == 'member' && CURMODULE == {$_G[setting][regname]} && $_GET['do'] == 'bbrule'} bg-c{/if}">
		<!--{if CURSCRIPT == 'member' && CURMODULE == {$_G[setting][regname]} && $_GET['do'] != 'bbrule'}-->
			<!--{if $_G['guiigoapp']['appsetting']['regconfig']['regstyle'] == 1}-->
				<header class="bar bar-nav guiigo-nydb guiigo-kbhddb"
				ck-cus="true" 
				ck-param="{ftcolo:{sta:'#ffffff',end:'#666666',class:['title','guiigoapp-xzfh','guiigoapp-mkbtgd']},rollt:'50',ori:'false',type:1}">
					<!--{if $_G['cache']['plugin']['guiigo_manage']['isguiigoapp']}-->
					<a class="button button-link pull-left app-back guiigo-kjfh zy-f"><i class="icon guiigoapp-xzfh"></i></a>
					<!--{else}-->
					<a class="button button-link pull-left back guiigo-kjfh zy-f"><i class="icon guiigoapp-xzfh"></i></a>
					<!--{/if}-->
				</header>
			<!--{/if}-->
		<!--{/if}-->
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if CURSCRIPT == 'member' && CURMODULE == {$_G[setting][regname]} && $_GET['do'] == 'bbrule'}-->
				<div id="layer_bbrule" class="gg-dz-fwtk">
					<div class="fwtk-tknr zy-f">$bbrulestxt</div>
					<div class="fwtk-tkan">
						<!--{if $_G['cache']['plugin']['guiigo_manage']['isguiigoapp']}-->
						<a class="guiigo-pn app-back ab-f zy-a zy-ac">{lang agree}</a>
						<!--{else}-->
						<a class="guiigo-pn back ab-f zy-a zy-ac">{lang agree}</a>
						<!--{/if}-->
						<a href="$_G[siteurl]" class="guiigo-pn ab-b zy-a">{lang disagree}</a>
					</div>
				</div>
			<!--{else}-->
				<style type="text/css">
					#birthdistrictbox .ps, #residedistrictbox .ps {background-color: rgba(255, 255, 255, 0.37);border: none;}
					#birthyear,#birthmonth,#birthday {width: 25%;padding: 0 .35rem;background-color: rgba(255, 255, 255, 0.37) !important;border: none !important;border-radius: .15rem;}
					<!--{if $_G['guiigoapp']['appsetting']['regconfig']['regstyle'] == 2}-->
					#birthyear,#birthmonth,#birthday,#birthdistrictbox .ps, #residedistrictbox .ps,.list-block .zckz-yszd .pt {background-color: #f7f7f7 !important;}
					.list-block .gg-dz-dllb textarea {color: #000000 !important;}
					<!--{/if}-->
				</style>
				<!--{if $_G['guiigoapp']['appsetting']['regconfig']['regstyle'] == 1}-->
					<div class="gg-dz-dllg">
						<img src="$_G['guiigoapp']['appsetting']['regconfig']['regslogo']">
					</div>
				<!--{/if}-->
				<div id="main_message">
					<!--{if $this->showregisterform}-->
					<form method="post" 
					autocomplete="off" 
					name="register" 
					id="registerform" 
					enctype="multipart/form-data" 
					action="member.php?mod=$regname"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{id:'',type:'regpwform'},fn:'MsgCallLogin',load:'true',verifyLoging:'1',upfiles:'1'}">
						<div id="layer_reg">
							<input type="hidden" name="regsubmit" value="yes" />
							<input type="hidden" name="formhash" value="{FORMHASH}" />
							<input type="hidden" name="referer" value="$dreferer" />
							<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
							<!--{if $_G['setting']['sendregisterurl']}-->
								<input type="hidden" name="hash" value="$_GET[hash]" />
							<!--{/if}-->
							<div id="reginfo_a" class="gg-dz-dllb{if $_G['guiigoapp']['appsetting']['regconfig']['regstyle'] == 2} gg-dz-dzjj bg-c{/if} list-block-no">
								<!--{if $sendurl}-->
									<ul>
										<li class="guiigo-flex xh-d">
											<div class="dllb-bico zy-a"><i class="icon guiigoapp-youxiang"></i>{lang guiigo_manage:tlang0818}<em class="zy-i">*</em></div>
											<div class="guiigo-flexy"><input type="text" id="{$this->setting['reginput']['email']}" name="$this->setting['reginput']['email']" autocomplete="off" size="25" tabindex="1" class="guiigo-px" placeholder="{lang guiigo_manage:tlang0819}" required /></div>
											<input type="hidden" name="handlekey" value="sendregister"/>
										</li>
										<li class="dllb-tshl">
											{lang register_validate_email_tips}
										</li>
								<!--{else}-->
									<!--{if $invite}-->
										<!--{if $invite['uid']}-->
										<li class="guiigo-flex xh-d">
											<div class="dllb-bico zy-a"><i class="icon guiigoapp-yaoqingren"></i>{lang register_from}</div>
											<div class="dllb-yqrx guiigo-flexy"><a href="home.php?mod=space&uid=$invite[uid]&do=profile"><!--{avatar($invite[uid],middle)}--><em class="zy-a">$invite[username]</em></a></div>
										</li>
										<!--{else}-->
										<li class="guiigo-flex xh-d">
											<div class="dllb-bico zy-a"><i class="icon guiigoapp-yaoqingma"></i>{lang invite_code}</div>
											<div class="guiigo-flexy zy-a">$_GET[invitecode]<input type="hidden" id="invitecode" name="invitecode" class="guiigo-px" value="$_GET[invitecode]" /></div>
										</li>
										<!--{eval $invitecode = 1;}-->
										<!--{/if}-->
									<!--{/if}-->
									<!--{if empty($invite) && $this->setting['regstatus'] == 2 && !$invitestatus}-->
									<li class="guiigo-flex xh-d">
										<div class="dllb-bico zy-a"><i class="icon guiigoapp-yaoqingma"></i>{lang invite_code}<em class="zy-i">*</em></div>
										<div class="dllb-fdkz guiigo-flexy">
											<input type="text" id="invitecode" name="invitecode" autocomplete="off" size="25" onblur="checkinvite()" tabindex="1" class="guiigo-px" placeholder="{lang guiigo_manage:tlang0834}" required />
											<!--{if $this->setting['inviteconfig']['buyinvitecode'] && $this->setting['inviteconfig']['invitecodeprice'] && ($this->setting[ec_tenpay_bargainor] || $this->setting[ec_tenpay_opentrans_chnid] || $this->setting[ec_account])}-->
												<a href="misc.php?mod=buyinvitecode" class="bllb-mmyc zy-a"><i class="icon guiigoapp-goumai"></i></a>
											<!--{/if}-->
										</div>
									</li>
									<!--{eval $invitecode = 1;}-->
									<!--{/if}-->
									<!--{if $_GET[action] != 'activation'}-->
										<li class="guiigo-flex xh-d">
											<div class="dllb-bico zy-a"><i class="icon guiigoapp-yonghu"></i>{lang username}<em class="zy-i">*</em></div>
											<div class="guiigo-flexy"><input type="text" name="{$_G['setting']['reginput']['username']}" class="guiigo-px" tabindex="1" value="{echo dhtmlspecialchars($_GET[defaultusername])}" autocomplete="off" size="25" maxlength="15" placeholder="{lang guiigo_manage:tlang0821}" required /></div>
										</li>
										<li class="guiigo-flex xh-d">
											<div class="dllb-bico zy-a"><i class="icon guiigoapp-mimaicon"></i>{lang password}<em class="zy-i">*</em></div>
											<div class="dllb-fdkz guiigo-flexy">
												<input type="password" name="{$_G['setting']['reginput']['password']}" size="25" tabindex="1" id="password" class="guiigo-px" placeholder="{lang guiigo_manage:tlang0216}" required />
												<a href="javascript:;" class="bllb-mmyc zy-a" onclick="passwordTabtype(this,'#password')"><i class="icon guiigoapp-zhengyan"></i></a>
											</div>
										</li>
										<li class="guiigo-flex xh-d">
											<div class="dllb-bico zy-a"><i class="icon guiigoapp-querenmima"></i>{lang password_confirm}<em class="zy-i">*</em></div>
											<div class="dllb-fdkz guiigo-flexy">
												<input type="password" name="{$_G['setting']['reginput']['password2']}" size="25" tabindex="1" id="passwordq" class="guiigo-px" placeholder="{lang guiigo_manage:tlang0835}" required />
												<a href="javascript:;" class="bllb-mmyc zy-a" onclick="passwordTabtype(this,'#passwordq')"><i class="icon guiigoapp-zhengyan"></i></a>
											</div>	
										</li>
										<li class="guiigo-flex xh-d">
											<div class="dllb-bico zy-a"><i class="icon guiigoapp-youxiang"></i>{lang guiigo_manage:tlang0818}<!--{if !$_G['setting']['forgeemail']}--><em class="zy-i">*</em><!--{/if}--></div>
											<div class="guiigo-flexy"><input type="text" name="{$_G['setting']['reginput']['email']}" autocomplete="off" size="25" tabindex="1" class="guiigo-px" value="$hash[0]" placeholder="{lang guiigo_manage:tlang0819}" {if !$_G['setting']['forgeemail']}required{/if} /></div>		
										</li>
									<!--{/if}-->
									<!--{if $_GET[action] == 'activation'}-->
									<li id="activation_user" class="guiigo-flex xh-d">
										<div class="dllb-bico zy-a"><i class="icon guiigoapp-yonghu"></i>{lang username}</div>
										<div class="dllb-yqrx guiigo-flexy zy-a">$username</div>
									</li>
									<!--{/if}-->
									<!--{if $this->setting['regverify'] == 2}-->
									<li id="activation_user" class="guiigo-flex xh-d">
										<div class="dllb-bico zy-a"><i class="icon guiigoapp-gantanhao"></i>{lang register_message}<em class="zy-i">*</em></div>
										<div class="guiigo-flexy"><input id="regmessage" name="regmessage" class="guiigo-px" autocomplete="off" size="25" tabindex="1" placeholder="{lang guiigo_manage:tlang0836}" required /></div>
									</li>
									<!--{/if}-->
									<!--{if empty($invite) && $this->setting['regstatus'] == 3}-->
									<li class="guiigo-flex xh-d">
										<div class="dllb-bico zy-a"><i class="icon guiigoapp-yaoqingma"></i>{lang invite_code}</div>
										<div class="guiigo-flexy"><input type="text" name="invitecode" autocomplete="off" size="25" id="invitecode"{if $this->setting['regstatus'] == 2} onblur="checkinvite()"{/if} tabindex="1" class="guiigo-px" placeholder="{lang guiigo_manage:tlang0834}" /></div>
									</li>
									<!--{eval $invitecode = 1;}-->
									<!--{/if}-->
									<!--{loop $_G['cache']['fields_register'] $key  $field}-->
										<!--{if $htmls[$field['fieldid']]}-->
											<li class="guiigo-flex xh-d" id="tr_$field['fieldid']">
												<div id="th_$field['fieldid']" class="dllb-bico zy-a"><i class="icon guiigoapp-$field['fieldid']"></i>$field[title]<!--{if $field['required']}--><em class="zy-i">*</em><!--{/if}--></div>
												<div class="guiigo-flexy zckz-yszd{if $_G['guiigoapp']['appsetting']['regconfig']['regstyle'] == 1} zy-a{else} zy-h{/if}" id="td_$field['fieldid']">$htmls[$field['fieldid']]</div>
											</li>
										<!--{/if}-->
									<!--{/loop}-->
									<script type="text/javascript">
										ck8(function(){
											var inputfile = ck8('input[type="file"]')
											for(var i=0; i< inputfile.length; i++){
												var obj = ck8(inputfile[i]);
												obj.on('change',function(o){
													_fileup(o)
												})
												var Dom = '<div class="zlxk-tpsc bg-e zy-c"><i class="icon guiigoapp-sctp"></i>{lang guiigo_manage:tlang0262}</div>';
												inputfile.addClass('zlxk-gnkz').after(Dom)
											}
										})

										function _fileup(obj){
											var reads = new FileReader();
											var objid = ck8('#td_' + obj.srcElement.id);

											var ahtml ='';
											reads.readAsDataURL(obj.target.files[0])
											reads.onload = function(){
												if(objid.find('a').length <= 0){
													ahtml = ck8('<a />',{href:'javascript:;'});
													ahtml = ck8(ahtml).append(
													'<img src="'+ this.result+'" width="200" class="mtm">'
													);
												}
												if(ahtml){
													objid.append(ahtml)
												}else{
													objid.find('a').html(
													'<img src="'+ this.result+'" width="200" class="mtm">'
													)
												}
											}
										}
									</script>
								<!--{/if}-->
								</ul>
							</div>
							<!--{if $secqaacheck || $seccodecheck}-->
								<div class="gg-dz-dyzm{if $_G['guiigoapp']['appsetting']['regconfig']['regstyle'] == 2} gg-dz-dzjy{/if} xh-d">
									<li class="guiigo-flex">
										<div class="dyzm-yico zy-a"><i class="icon guiigoapp-yanzheng"></i>{lang guiigo_manage:tlang0828}</div>
										<div class="guiigo-flexy">
											<!--{subtemplate common/seccheck}-->
										</div>
									</li>
								</div>
							<!--{/if}-->
						</div>
						<div id="layer_reginfo_b">
							<div id="reginfo_a_btn" class="gg-dz-dlan gg-dz-dlanx">
								<button class="formdialog guiigo-pn ab-f zy-a zy-ac" id="registerformsubmit" type="button" tabindex="1">
								<!--{if $_GET[action] == 'activation'}-->{lang activation}<!--{else}-->{lang submit}<!--{/if}-->
							    </button>
								<div class="dlan-zcwj{if $_G['guiigoapp']['appsetting']['regconfig']['regstyle'] == 2} gg-dz-jjzw{/if}">
									<!--{if $bbrules}-->
									<label class="guiigo-pd{if $_G['guiigoapp']['appsetting']['regconfig']['regstyle'] == 1} zy-a{else} zy-h{/if}" for="agreebbrule">
										<input type="checkbox" class="guiigo-pd-k guiigo-pd-c" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" /><span></span>{lang agree}
										<!--{if $_G['setting']['sendregisterurl']}-->
											<input type="hidden" name="hash" value="$_GET[hash]" />
										<!--{/if}-->
									</label>
									<a href="member.php?mod={$_G[setting][regname]}&do=bbrule" class="zcwj-tkxh zy-a">{lang rulemessage}</a>
									<!--{/if}-->
									<!--{if $_GET[action] == 'activation'}-->
										<a href="member.php?mod={$_G[setting][regname]}" class="zcwj-wjmm zy-a">{lang guiigo_manage:tlang0837}</a>
									<!--{else}-->
										<a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" class="zcwj-wjmm zy-a">{lang login_now}</a>
									<!--{/if}-->
								</div>
							</div>
						</div>
					</form>
					<!--{/if}-->
				</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{eval updatesession();}-->
<!--{/if}-->
<!--{template common/footer}-->

