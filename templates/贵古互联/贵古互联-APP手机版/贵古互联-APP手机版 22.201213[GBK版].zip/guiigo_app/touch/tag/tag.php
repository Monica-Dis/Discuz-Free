<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $type != 'countitem'}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="tag-index">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0884}</h1>
	</header>
	<div class="content bg-c gg-yjms">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-qz-qbss bg-g xh-b">
				<div class="gg-qz-qzss">
					<a href="javascript:;" onclick="ck8('.gg-qz-qzss').hide();ck8('.gg-qz-qzsc').show();ck8('#scform_srchtxt').focus()" class="bg-c zy-c"><i class="icon guiigoapp-sousuo"></i>{lang guiigo_manage:tlang0885}</a>
				</div>
				<div class="gg-qz-qzsc" style="display:none;">
					<form method="post" action="misc.php?mod=tag&type=thread">
						<ul class="guiigo-flex">
							<input type="search" id="scform_srchtxt" name="name" class="qzsc-sssr bg-c zy-c" placeholder="{lang guiigo_manage:tlang0886}"/>
							<a href="javascript:;" onclick="ck8('.gg-qz-qzsc').hide();ck8('.gg-qz-qzss').show()"><i class="icon guiigoapp-guanbix zy-g"></i></a>
							<button type="submit" class="qzsc-ssqr ab-az zy-a zy-ac">{lang search}</button>
						</ul>
					</form>
				</div>
			</div>
			<div class="gg-ss-rmss">
				<!--{if $tagarray}-->
					<div class="rmss-btys zy-g">{lang guiigo_manage:tlang0887}</div>
					<!--{loop $tagarray $tag}-->
						<a href="misc.php?mod=tag&id=$tag[tagid]&type=thread" class="bg-g zy-h">$tag[tagname]</a>
					<!--{/loop}-->
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0888}</p>
					</div>
				<!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{else}-->
$num
<!--{/if}-->
<!--{template common/footer}-->
