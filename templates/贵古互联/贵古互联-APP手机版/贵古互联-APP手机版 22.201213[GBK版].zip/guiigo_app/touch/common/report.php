<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<form 
	method="post" 
	autocomplete="off" 
	id="form_$_GET[handlekey]" 
	name="form_$_GET[handlekey]" 
	action="misc.php?mod=report"
	ck-cus="true" 
	ck-param="{type:'modal',load:'true',fn:{if $_GET['fn']}'$_GET['fn']'{/if},title:'{lang report}'}">
	<div id="return_$_GET[handlekey]">
		<div class="gg-jb-jbxx" id="report_reasons"></div>
		<div class="gg-jb-qtxx" id="report_other" style="display:none">
			<textarea id="report_message" name="message" class="guiigo-px bg-e" onkeyup="strLenCalc(this, 'checklen');" rows="4" placeholder="{lang report_reason_other}"></textarea>	
			<div class="qtxx-zsts zy-c" id="report_msg" style="display:none">{lang input_message1} <strong class="zy-b" id="checklen">200</strong> {lang input_message2}</div>
		</div>
	</div>
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="reportsubmit" value="true" />
	<input type="hidden" name="rtype" value="$_GET[rtype]" />
	<input type="hidden" name="rid" value="$_GET[rid]" />
	<!--{if $_GET['fid']}-->
	<input type="hidden" name="fid" value="$_GET[fid]" />
	<!--{/if}-->
	<!--{if $_GET['uid']}-->
	<input type="hidden" name="uid" value="$_GET[uid]" />
	<!--{/if}-->
	<input type="hidden" name="url" value="$_GET[url]" />
	<input type="hidden" name="inajax" value="$_G[inajax]" />
	<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
	<input type="hidden" name="formhash" value="{FORMHASH}" />
</form>
<script type="text/javascript" reload="1">
var reasons = {lang report_reason_message};
var reasonstring = '';
for (i=0; i<reasons.length; i++) {
	reasonstring += '<div class="gg-jb-jblb"><label class="guiigo-pds" \
	onclick="' + (i < reasons.length -1 ? 'Dz(\'report_message\').innerHTML=ck8(\'#report_select'+ i +'\').val();' : '') + 'Dz(\'report_other\').style.display=\'' + (i < reasons.length -1 ? 'none' : '') + '\';Dz(\'report_msg\').style.display=\'' + (i < reasons.length -1 ? 'none' : '') + '\'">\
		<input type="radio" name="report_select" id="report_select'+ i +'" class="guiigo-pd-k" value="'+ reasons[i]+'">\
		<span></span>' + reasons[i] + '\
	</label></div>';
}
Dz('report_reasons').innerHTML = reasonstring;
</script>
<!--{template common/footer}-->
