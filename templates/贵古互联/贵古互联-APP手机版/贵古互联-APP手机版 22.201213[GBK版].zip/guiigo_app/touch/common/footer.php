<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
$guiigo_config['homepageSeo']
<!--{hook/global_footer_mobile}-->
<!--{if $_GET['id'] == 'guiigo_manage' && $_GET['act'] == 'index'}-->
<div class="popup popup-tipmsgdate">
	<div class="guiigo-ttad close-popup">
		<a href="{if $guiigo_config['ttad_link']}$guiigo_config['ttad_link']{else}javascript:;{/if}" class="ttad-adon" external>
			<img src="$guiigo_config['ttad_img']">
		</a>
		<a href="javascript:;" class="ttad-adgb close-popup"><i class="icon guiigoapp-cuo"></i></a>
	</div>
</div>
<!--{/if}-->
</div>
<!--{template common/footer_nav2}-->
<!--{if CURSCRIPT != 'plugin' || $_GET['id'] == 'guiigo_manage'}-->
<a href="javascript:;" class="panel-overlay"></a>
<a href="javascript:;" class="panel-ztbg"></a>
<div class="panel panel-left panel-cover close-panel bg-c yb-a">
	<div class="guiigo-panel">
		<!--{eval $userHstyle = $guiigo_config['appsetting']['userHstyle'][$_G['uid']];}-->
		<!--{if !$userHstyle}-->
		    <!--{eval $userHstyle = 'k1';}-->
		<!--{/if}-->
		<div class="panel-yhxx gg-kjbg-{$userHstyle}">
			<div class="panel-yhxx-xx">
				<h1><a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="zy-a zs-a yz-a">
					<!--{if $_G[uid]}-->
						<!--{echo cutstr({$_G[member][username]},12)}-->
					<!--{else}-->
						<span id="nowgetHours"></span>{lang guiigo_manage:tlang0063}
					<!--{/if}-->
				</a></h1>
				<!--{eval $aryStr = GuiigoApp::getUserList($_G[uid],'field_forum');}-->
				<p class="zy-d zs-a yz-a">
					<!--{if $_G[uid]}-->
						<!--{if $aryStr['sightml']}-->
							<!--{echo strip_tags($aryStr['sightml'])}-->
						<!--{else}-->
							<a href="home.php?mod=spacecp&ac=profile&op=info" class="zy-d zs-a yz-a"><i class="icon guiigoapp-fbxhfb"></i>{lang guiigo_manage:tlang0064}</a>
						<!--{/if}-->
					<!--{else}-->
						{lang guiigo_manage:tlang0065}
					<!--{/if}-->
				</p>
			</div>
			<div class="panel-yhxx-tx"><a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->"><!--{if $_G[uid]}--><!--{if !$_G[member][avatarstatus]}--><!--{avatar($_G[uid])}--><!--{else}--><img src="<!--{eval echo avatar($_G[uid], 'middle', true,FALSE,true).'?'.rand(1000, 9999);}-->"/><!--{/if}--><!--{else}--><!--{avatar($_G[uid])}--><!--{/if}--></a></div>
			<div class="panel-yhxx-gn">
				<!--{if $_G[uid]}-->
					<a href="home.php?mod=spacecp&ac=promotion" class="go-clewm"><i class="icon guiigoapp-clewm zy-a"></i></a>
					<!--{if $guiigo_config['isguiigoapp'] && !$_G['cache']['plugin']['guiigo_appmanage']['alltpl']}-->
					    <a href="javascript:ck8.navigateTo('/pages/setting/setting');" class="go-clewm" ><i class="icon guiigoapp-clgsz zy-a"></i></a>
					<!--{else}-->
						<a href="home.php?mod=spacecp&ac=avatar&do=chszshi" class="go-clewm"><i class="icon guiigoapp-clgsz zy-a"></i></a>
					<!--{/if}-->
					<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="gg-app-hide dialog go-clewm"
						ck-cus="true" 
						ck-param="{type:'modal',fn:'MsgCallLogout',load:'true',uid: '$_G[uid]'}" 
						external ><i class="icon guiigoapp-tcqzn zy-a"></i></a>
				<!--{else}-->
					<a href="member.php?mod=logging&action=login" class="go-clewm"><i class="icon guiigoapp-cldly zy-a"></i></a>
				<!--{/if}-->
			</div>
			<div class="guiigo-bwdx">
				<div class="guiigo-bwdx-a"></div>
				<div class="guiigo-bwdx-b"></div>
			</div>
		</div>
		<div class="panel-cldh">
			<div class="guiigo-tbdh">
				<!--{loop $guiigo_config['appsetting']['menuconfig']['global_broadside_menu'] $val}-->
					<!--{if $val['global_broadside_menu_open'] == 1}-->
						<a href="javascript:;" class="xh-a" onclick="openShowMn('{$val['global_broadside_menu_link']}');">
							<img src="$val['global_broadside_menu_icon']" class="go-tbdh-ico">
							<div class="go-tbdh-mc zy-f">$val['global_broadside_menu_name']</div>
							<i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i>
						</a>
					<!--{/if}-->
				<!--{/loop}-->
				<!--{if $_GET['id'] != 'guiigo_manage' || $_GET['act'] != 'index'}-->
					<!--{if $guiigo_config['open_navpc']}-->
						<a href="{$_G['setting']['mobile']['nomobileurl']}" class="xh-a"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/cgd-dn.png" class="go-tbdh-ico"><div class="go-tbdh-mc zy-f">{lang guiigo_manage:tlang0066}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
					<!--{/if}-->
				<!--{/if}-->
				<!--{if $guiigo_config['open_navam']}-->
					<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
						<a href="$_G['siteurl']/admin.php"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/cgd-sz.png" class="go-tbdh-ico"><div class="go-tbdh-mc zy-f">{lang guiigo_manage:tlang0067}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
					<!--{/if}-->
				<!--{/if}-->
			</div>
			<div class="panel-dzbq"></div>
		</div>
	</div>
</div>
<script type="text/javascript">
ck8(function(){
	var b = document.referrer;
	if(b == ""){
        ck8('.anvbk').show()
	    ck8('.anvbks').remove()
	}
	ck8('#nowgetHours').html(nowgetHours())
})
function nowgetHours(){
	var now = new Date(),hour = now.getHours();
	if(hour < 6){return "{lang guiigo_manage:tlang0068}"}
	else if (hour < 9){return "{lang guiigo_manage:tlang0069}"}
	else if (hour < 12){return "{lang guiigo_manage:tlang0070}"}
	else if (hour < 14){return "{lang guiigo_manage:tlang0071}"}
	else if (hour < 17){return "{lang guiigo_manage:tlang0072}"}
	else if (hour < 19){return "{lang guiigo_manage:tlang0073}"}
	else if (hour < 22){return "{lang guiigo_manage:tlang0074}"}
	else {return "{lang guiigo_manage:tlang0075}"}
}
</script>
<script src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/js/guiigoSpa.min.js?{VERHASH}" charset="{CHARSET}"></script>
<script src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/js/app.js?{VERHASH}" charset="{CHARSET}"></script>
<script src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/js/wow.min.js"></script>
<script>
if (!(/msie [6|7|8|9]/i.test(navigator.userAgent))){
	new WOW().init();
};
</script>
<!--{/if}-->
<script src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/js/apph5plus.js?{VERHASH}" charset="{CHARSET}"></script>
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{eval GuiigoApp::style();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{if $guiigo_config['urluewriter']==1}-->
		<!--{eval @include_once DISCUZ_ROOT.'./source/plugin/guiigo_manage/function/GuiigoApp_function.php';}-->
		<!--{eval GuiigoApp_output();}-->
	<!--{else}-->
	    <!--{eval output();}-->
	<!--{/if}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->

