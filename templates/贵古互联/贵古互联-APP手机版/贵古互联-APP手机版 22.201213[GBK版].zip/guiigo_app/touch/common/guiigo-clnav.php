<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="guiigo-clnav">
	<input type="checkbox" href="javascript:;" class="clnav-open" name="clnav-open" id="clnav-open"/>
	<label id="clnav-wjkz" class="clnav-wjon ab-a zy-a" for="clnav-open"><i class="icon guiigoapp-clnavcd"></i><p>{lang guiigo_manage:tlang0981}</p></label>
	<div class="clnav-menu">
		<a href="javascript:;" class="clnav-item ck8-top zy-a"><i class="icon guiigoapp-clnavdb"></i><p>{lang guiigo_manage:tlang0083}</p></a>
		<a href="javascript:;" class="clnav-item open-panel zy-a"><i class="icon guiigoapp-clnavdh"></i><p>{lang guiigo_manage:tlang0084}</p></a>
		<a href="javascript:;" class="clnav-item zy-a" onclick="location.reload()"><i class="icon guiigoapp-clnavsx"></i><p>{lang guiigo_manage:tlang0085}</p></a>
		<a href="javascript:;" class="gg-app-show clnav-item back zy-a" onclick="javascript:history.back(-1);"><i class="icon guiigoapp-shangyiye"></i><p>{lang guiigo_manage:tlang0989}</p></a>
	</div>
	<!--{if CURSCRIPT == 'member' && CURMODULE == 'logging' || CURSCRIPT == 'member' && CURMODULE == 'register'}--><!--{else}-->
	<a href="javascript:;" class="clnav-ksfb zy-a<!--{if CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' || CURSCRIPT == 'home' && $_GET['do'] == 'doing'}--> ab-i<!--{else}--> ab-c<!--{/if}--><!--{if !$_G[uid]}--> login<!--{/if}-->"<!--{if CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay'}--> <!--{if $_G[uid]}-->onclick="app.ActionsManage('#guiigo-bkfbx','t', 'auto');"<!--{/if}--><!--{elseif CURSCRIPT == 'home' && $_GET['do'] == 'doing'}--> <!--{if $_G[uid]}-->onclick="app.ActionsManage('#moodfm','t','auto','closehfdp');$('#message').focus();"<!--{/if}--><!--{else}--> <!--{if $_G[uid]}-->onclick="ck8.popup('.popup-about')"<!--{/if}--><!--{/if}-->><i class="icon guiigoapp-clnavfb"></i><p><!--{if CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay'}-->{lang guiigo_manage:tlang0077}<!--{elseif CURSCRIPT == 'home' && $_GET['do'] == 'doing'}-->{lang guiigo_manage:tlang0696}<!--{else}-->{lang guiigo_manage:tlang0086}<!--{/if}--></p></a>
	<!--{/if}-->
	<!--{if CURSCRIPT == 'forum' && $_GET['do'] == 'guanzhu' || CURSCRIPT == 'forum' && CURMODULE == 'viewthread' || CURSCRIPT == 'group' && CURMODULE == 'index' || CURSCRIPT == 'forum' && $_GET['action'] == 'list' || ($filter == 'privatepm') || $filter == 'privatepm' && $newpm || $filter == 'newpm' || CURSCRIPT == 'portal' && CURMODULE == 'list' || CURSCRIPT == 'portal' && CURMODULE == 'view' || CURSCRIPT == 'home' && $_GET['do'] == 'profile' || CURSCRIPT == 'home' && $_GET['do'] == 'blog' || CURSCRIPT == 'home' && $_GET['do'] == 'album'}-->
	<a href="javascript:;" class="gg-app-show clnav-kzgn ab-h zy-a" onclick="showMn();"><i class="icon guiigoapp-caidang"></i><p>{lang guiigo_manage:tlang0082}</p></a>
	<!--{/if}-->
	<!--{if CURSCRIPT == 'forum' && CURMODULE == 'announcement'}-->
	<a href="javascript:;" class="gg-app-show clnav-kzgn ab-h zy-a" onclick="app.ActionsManage('#actions_1','b', 'auto');"><i class="icon guiigoapp-caidang"></i><p>{lang guiigo_manage:tlang0132}</p></a>
	<!--{/if}-->
</div>



