<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="popup popup-about close-popup{if $guiigo_config['kf_ys'] == 1} guiigo-ksfb{else} guiigo-ksfbj{/if}">
<!--{if $guiigo_config['kf_ys'] == 1}-->
	<div class="ksfb-txrq">
		<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="txrq-dqyh"><!--{if !$_G[member][avatarstatus]}--><!--{avatar($_G[uid])}--><!--{else}--><img src="<!--{eval echo avatar($_G[uid], 'middle', true,FALSE,true).'?'.rand(1000, 9999);}-->"/><!--{/if}-->
			<h2 class="zy-e"><!--{echo cutstr({$_G[member][username]},12)}--></h2>
			<p class="zy-c">$_G[group][grouptitle]</p>
		</a>
		<div class="txrq-rqon guiigo-flex">
			<div class="rqon-z">
				<div id="ksfb-n" class="rqon-n"></div>
				<div id="ksfb-y" class="rqon-y"></div>
			</div>
			<div id="ksfb-r" class="rqon-r"></div>
			<script>
			var today = new Date();
			document.getElementById("ksfb-n").innerHTML = today.getFullYear() + '{lang guiigo_manage:tlang1048}'
			document.getElementById("ksfb-y").innerHTML = (today.getMonth() + 1)+ '{lang guiigo_manage:tlang1049}'
			document.getElementById("ksfb-r").innerHTML = today.getDate()
			</script>
		</div>
	</div>
	<!--{if $guiigo_config['kf_img']}-->
	<div class="ksfb-sbad wow flipInX">
		<a href="$guiigo_config['kf_url']">
			<img src="$guiigo_config['kf_img']" class="vm">
			<em>{lang guiigo_manage:tlang1047}</em>
		</a>
	</div>
	<!--{/if}-->
	<div class="ksfb-fbon">
		<div class="fbon-bt">$guiigo_config['kf_title']</div>
		<div class="fbon-cd">
			<ul>
				<!--{loop $guiigo_config['appsetting']['menuconfig']['global_information_menu'] $val}-->
					<!--{if $val['global_information_menu_open'] == 1}-->
						<li class="wow bounceInDown"><a href="$val['global_information_menu_link']"><img src="$val['global_information_menu_icon']"><p class="zy-f">$val['global_information_menu_name']</p></a></li>
					<!--{/if}-->
				<!--{/loop}-->
			</ul>
		</div>
		<a href="javascript:;" class="fbon-no close-popup wow bounceInUp"><i class="icon guiigoapp-cuo zy-e"></i></a>
	</div>
<!--{else}-->
	<div class="kfjj-xmon">
		<ul class="guiigo-flex">
			<!--{loop $guiigo_config['appsetting']['menuconfig']['global_information_menu'] $val}-->
				<!--{if $val['global_information_menu_open'] == 1}-->
					<li class="wow bounceInDown"><a href="$val['global_information_menu_link']" class="guiigo-flex bg-c"><img src="$val['global_information_menu_icon']"><p class="zy-e">$val['global_information_menu_name']</p></a></li>
				<!--{/if}-->
			<!--{/loop}-->
		</ul>
	</div>
	<a href="javascript:;" class="fbon-no close-popup wow bounceInUp"><i class="icon guiigoapp-cuo zy-g"></i></a>
<!--{/if}-->
</div>
