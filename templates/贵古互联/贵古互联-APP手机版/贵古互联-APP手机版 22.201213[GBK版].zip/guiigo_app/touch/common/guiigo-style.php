<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<style type="text/css">
<!--{if $guiigo_config['isphotoSquare']}-->
.guiigo-ty {border-radius: .2rem !important;}
.guiigo-ty img {border-radius: .2rem !important;}
.guiigo-tys img {border-radius: .2rem !important;}
<!--{else}-->
.guiigo-ty {border-radius: 50% !important;}
.guiigo-ty img {border-radius: 50% !important;}
.guiigo-tys img {border-radius: 50% !important;}
<!--{/if}-->
<!--{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'miniprogram')}-->
.gg-app-hide {display:none !important;}
.gg-app-hide~.content {top:0;}
.auto-top {top:0 !important;}
.gg-app-show {display: block;}
.guiigo-clnav .clnav-menu {top: -10rem;}
.bar-nav~.pull-to-refresh-content, .bar-footer~.pull-to-refresh-content, .bar-tab~.pull-to-refresh-content {top: 0;}
<!--{else}-->
.gg-app-show {display: none !important;}
.guiigo-clnav .clnav-menu {top: -7.5rem;}
.bar-nav~.pull-to-refresh-content, .bar-footer~.pull-to-refresh-content, .bar-tab~.pull-to-refresh-content {top: 2.25rem;}
<!--{/if}-->
<!--{if $guiigo_config['iphoneztkz']}-->
/*����ƻ��X*/
@media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 3) {* {word-wrap: break-word;font-weight: 400;}}
@media only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 3) {* {word-wrap: break-word;font-weight: 400;}}
@media only screen and (device-width: 375px) and (device-height: 812px) and (-webkit-device-pixel-ratio: 2) {* {word-wrap: break-word;font-weight: 400;}}
@media only screen and (device-width: 414px) and (device-height: 896px) and (-webkit-device-pixel-ratio: 2) {* {word-wrap: break-word;font-weight: 400;}}
@media only screen and (device-width: 375px) and (device-height: 667px) and (-webkit-device-pixel-ratio: 2) {* {word-wrap: break-word;font-weight: 400;}}
@media only screen and (device-width: 414px) and (device-height: 736px) and (-webkit-device-pixel-ratio: 3) {* {word-wrap: break-word;font-weight: 400;}}
@media only screen and (device-width: 320px) and (device-height: 568px) and (-webkit-device-pixel-ratio: 2) {* {word-wrap: break-word;font-weight: 400;}}
@media only screen and (device-width: 320px) and (device-height: 480px) and (-webkit-device-pixel-ratio: 2) {* {word-wrap: break-word;font-weight: 400;}}
<!--{/if}-->
</style>
