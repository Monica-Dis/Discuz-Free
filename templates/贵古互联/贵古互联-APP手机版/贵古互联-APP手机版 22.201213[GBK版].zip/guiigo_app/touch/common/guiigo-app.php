<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="guiigo-appt gg-app-hide guiigo-flex">
	<div class="appt-logo"><a href="$guiigo_config['appurl']"><img src="$guiigo_config['applogo']" class="vm"></a></div>
	<div class="appt-msjs">$guiigo_config['appintroduce']</div>
	<a href="$guiigo_config['appurl']" class="appt-xzdz">{lang guiigo_manage:tlang1039}</a>
	<a href="javascript:;" class="appt-gbtc" onclick="ck8('.guiigo-appt').hide()"><i class="icon guiigoapp-cuo"></i></a>
</div>
