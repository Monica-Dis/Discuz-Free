<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="ranklist-forum">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="search.php?mod=forum" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-f"></i></a>
		<h1 class="title zy-h">{lang ranklist_forum}</h1>
	</header>
	<div class="content phforum-scroll bg-c gg-yjms">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-kj-rwbg">
				<img src="template/guiigo_app/static/images/bpbg.jpg" class="vm">
				<div class="guiigo-bwdx">
					<div class="guiigo-bwdx-a"></div>
					<div class="guiigo-bwdx-b"></div>
				</div>
			</div>
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-ranklistforum list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $_GET[view] == 'threads'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phforum-scroll','misc.php?mod=ranklist&type=forum&view=threads',['gg-ph-bkph']);">{lang ranklist_post}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[view] == 'posts'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phforum-scroll','misc.php?mod=ranklist&type=forum&view=posts',['gg-ph-bkph']);">{lang ranklist_reply}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[view] == 'today'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phforum-scroll','misc.php?mod=ranklist&type=forum&view=today',['gg-ph-bkph']);">{lang guiigo_manage:tlang0857}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-zt-jgys bg-g"></div>
			<div class="gg-ph-bkph sh-a">
				<!--{if $forumsrank}-->
					<div class="bkph-bklb list-block-no ms-a">
						<ul>
							<!--{loop $forumsrank $forum}-->
							<!--{eval $forumIcon = GuiigoApp::getForumIconByFid($forum['fid']);}-->
								<li>
									<a href="forum.php?mod=forumdisplay&fid=$forum['fid']">
										<i class="zy-c">
											<!--{if $_GET[view] == 'threads' || $_GET[view] == 'today'}-->{lang guiigo_manage:tlang0117}<!--{elseif $_GET[view] == 'posts'}-->{lang guiigo_manage:tlang0148}<!--{/if}-->: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum['posts'])}--><!--{else}-->$forum['posts']<!--{/if}--></i>
										<span class="bklb-phys zy-f"><!--{if $forum['rank'] <= 3}--><img src="template/guiigo_app/static/images/ggph-$forum['rank'].png" alt="$forum['rank']" /><!--{else}-->$forum['rank']<!--{/if}--></span>
										<!--{if $forumIcon}-->
											<img src="$forumIcon" class="bklb-bktb">
										<!--{else}-->
											<img src="template/guiigo_app/static/images/forum.png" class="bklb-bktb">
										<!--{/if}-->
										<h2 class="zy-h">$forum['name']</h2>
									</a>
								</li>
							<!--{/loop}-->
						</ul>
					</div>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0858}</p>
					</div>
				<!--{/if}-->
				<!--{if $forumsrank}-->
					<div class="gg-ph-hcsm mn-a zy-c">{lang ranklist_update}</div>
				<!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->
