<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $keywordenc = $keyword ? rawurlencode($keyword) : '';}-->
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<ul class="guiigo-flex">
	<div class="ssxs-xzsn"><a href="javascript:;" class="" onclick="showMn();" ><em class="zy-c"><!--{if CURMODULE == 'portal'}-->{lang portal}<!--{elseif CURMODULE == 'forum'}-->{lang thread}<!--{elseif CURMODULE == 'blog'}-->{lang blog}<!--{elseif CURMODULE == 'album'}-->{lang album}<!--{elseif CURMODULE == 'group'}-->$_G['setting']['navs'][3]['navname']<!--{elseif CURMODULE == 'user'}-->{lang user}<!--{/if}--></em><i class="icon guiigoapp-ssxx zy-c"></i></a></div>
	<div class="guiigo-barcd-s guiigo-barcd-ss" style="display:none;" onclick="showMn();">
		<div class="gg-ss-sstj list-block-no bg-c bk-e">
			<ul>
				<!--{if helper_access::check_module('portal') && $_G['setting']['search']['portal']['status'] && ($_G['group']['allowsearch'] & 1 || $_G['adminid'] == 1)}--><!--{block slist[portal]}--><li><a href="search.php?mod=portal{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}" class="zy-f xh-b">{lang portal}</a></li><!--{/block}--><!--{/if}-->
				<!--{if $_G['setting']['search']['forum']['status'] && ($_G['group']['allowsearch'] & 2 || $_G['adminid'] == 1)}--><!--{block slist[forum]}--><li><a href="search.php?mod=forum{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}" class="zy-f xh-b">{lang thread}</a></li><!--{/block}--><!--{/if}-->
				<!--{if helper_access::check_module('group') && $_G['setting']['search']['group']['status'] && ($_G['group']['allowsearch'] & 16 || $_G['adminid'] == 1)}--><!--{block slist[group]}--><li><a href="search.php?mod=group{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}" class="zy-f xh-b">$_G['setting']['navs'][3]['navname']</a></li><!--{/block}--><!--{/if}-->
				<!--{if helper_access::check_module('blog') && $_G['setting']['search']['blog']['status'] && ($_G['group']['allowsearch'] & 4 || $_G['adminid'] == 1) && helper_access::check_module('blog')}--><!--{block slist[blog]}--><li><a href="search.php?mod=blog{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}" class="zy-f xh-b">{lang blog}</a></li><!--{/block}--><!--{/if}-->
				<!--{if helper_access::check_module('album') && $_G['setting']['search']['album']['status'] && ($_G['group']['allowsearch'] & 8 || $_G['adminid'] == 1) && helper_access::check_module('album')}--><!--{block slist[album]}--><li><a href="search.php?mod=album{if $keyword}&srchtxt=$keywordenc&searchsubmit=yes{/if}" class="zy-f xh-b">{lang album}</a></li><!--{/block}--><!--{/if}-->
				<!--{echo implode("", $slist);}-->
				<li><a href="search.php?mod=user" class="zy-f">{lang user}</a></li>
			</ul>
		</div>
	</div>
	<input type="search" id="scform_srchtxt" name="srchtxt" size="65" maxlength="40" class="ssxs-xspx" value="$keyword" tabindex="1"  placeholder="{lang guiigo_manage:tlang0883}"/>
	<input type="hidden" name="searchsubmit" value="yes">
</ul>
