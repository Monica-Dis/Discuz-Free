<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="page page-current" data-mod="group-manage">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0416}</h1>
	</header>
	<div class="content infinite-scroll groupmanage-scroll">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-groupmanage list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide{if $_GET['op'] == 'group'} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmanage-scroll','forum.php?mod=group&action=manage&op=group&fid=$_G[fid]',['gg-qz-qzgl','gg-qz-dbsx']);">{lang group_setup}</a><span class="bg-b"></span></li>
					<!--{if !empty($groupmanagers[$_G[uid]]) || $_G['adminid'] == 1}-->
					<li class="swiper-slide{if $_GET['op'] == 'checkuser'} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmanage-scroll','forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]',['gg-qz-qzgl','gg-qz-dbsx']);">{lang group_member_moderate}</a><span class="bg-b"></span></li>
					<li class="swiper-slide{if $_GET['op'] == 'manageuser'} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmanage-scroll','forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]',['gg-qz-qzgl','gg-qz-dbsx']);">{lang group_member_management}</a><span class="bg-b"></span></li>
					<!--{/if}-->
					<!--{if $_G['forum']['founderuid'] == $_G['uid'] || $_G['adminid'] == 1}-->
					<li class="swiper-slide{if $_GET['op'] == 'threadtype'} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmanage-scroll','forum.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]',['gg-qz-qzgl','gg-qz-dbsx']);">{lang guiigo_manage:tlang0427}</a><span class="bg-b"></span></li>
					<li class="swiper-slide{if $_GET['op'] == 'demise'} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmanage-scroll','forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]',['gg-qz-qzgl','gg-qz-dbsx']);">{lang group_demise}</a><span class="bg-b"></span></li>
					<!--{/if}-->
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div id="gg-qz-qzgl" class="gg-qz-qzgl">
			<!--{if $_GET['op'] == 'group'}-->
				<form enctype="multipart/form-data" 
				action="forum.php?mod=group&action=manage&op=group&fid=$_G[fid]" 
				name="manage" 
				method="post" 
				autocomplete="off"
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pmid:'',type:'manage'},fn:'MsgCallManage',load:'true',uid:'$_G[uid]',upfiles:'1'}">
					<input type="hidden" value="{FORMHASH}" name="formhash" />
					<div class="guiigo-wbtb list-block-no ms-a bg-c sh-a cl">
						<ul>
							<li class="wbtb-tbli guiigo-flex xh-b cl">
								<div class="wbtb-wbxm guiigo-flexy zy-c">
									<h2>{lang group_icon}</h2>
									<!--{if $_G['forum']['icon']}-->
									<img src="$_G[forum][icon]?{TIMESTAMP}" id="iconnew_img" />
									<!--{else}-->
									<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/groupicon.gif" id="iconnew_img"/>
									<!--{/if}-->
								</div>
								<div class="wbtb-scan zy-h">
									<ul>
										<li class="guiigo-flex scan-liks">
											<a class="bg-e zy-c" href="javascript:;">
												<i class="icon guiigoapp-sctp"></i>{lang guiigo_manage:tlang0428}
												<input type="file" id="iconnew" class="pf vm" size="25" name="iconnew" onchange="fileup(this,'#iconnew_img');"/>
											</a>
										</li>
									</ul>
								</div>
							</li>
							<!--{if !empty($_G['group']['allowupbanner']) || $_G['adminid'] == 1}-->
							<li class="wbtb-tbli guiigo-flex xh-b cl">
								<div class="wbtb-wbxm guiigo-flexy zy-c">
									<h2>{lang guiigo_manage:tlang0429}</h2>
									<!--{if $_G['forum']['banner']}-->
									<img src="$_G[forum][banner]?{TIMESTAMP}" id="bannernew_img"/>
									<!--{else}-->
									<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/groupicon.gif" id="bannernew_img" />
									<!--{/if}-->
									<!--{if $_G['forum']['banner']}-->
									<div class="guiigo-pc"><input type="checkbox" name="deletebanner" id="date" value="1" /><label for="date"><em></em></label></div>
									<!--{/if}-->
								</div>
								<div class="wbtb-scan zy-h">
									<ul>
										<li class="guiigo-flex scan-liks">
											<a class="bg-e zy-c" href="javascript:;">
												<i class="icon guiigoapp-sctp"></i>{lang guiigo_manage:tlang0430}
												<input type="file" id="bannernew" class="pf vm" size="25" name="bannernew" onchange="fileup(this,'#bannernew_img');"/>
											</a>
										</li>
									</ul>
								</div>
							</li>
							<!--{/if}-->
						</ul>
					</div>
					<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
						<ul>
							<!--{if !empty($specialswitch['allowchangename']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang group_name} <span class="zy-i">*</span></div>
								<div class="wblb-wbnr zy-h"><input type="text" name="name" class="guiigo-px s-a" autocomplete="off" value="$_G[forum][name]"/></div>
							</li>
							<!--{/if}-->
							<!--{if !empty($specialswitch['allowchangetype']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang group_category} <span class="zy-i">*</span></div>
								<div class="wblb-wbnr zy-h">
									<select name="parentid" tabindex="2" class="guiigo-ps" onchange="__ajaxget(this.value);">
										$groupselect[first]
									</select>
								</div>
							</li>
							<li class="guiigo-flex xh-b cl" id="second" style="display:none;">
								<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0402} <span class="zy-i">*</span></div>
								<div id="secondgroup" class="wblb-wbnr zy-h"></div>
							</li>
							<!--{/if}-->
							<li class="wblb-dkbt bg-g xh-b zy-c cl">
								{lang group_description}
							</li>
							<li class="wblb-nrsr xh-b zy-h cl">
								<div class="wblb-wbnr zy-h"><textarea id="descriptionmessage" name="descriptionnew" class="guiigo-pt s-a">$_G[forum][descriptionnew]</textarea></div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang group_perm_visit} <span class="zy-i">*</span></div>
								<div class="wblb-wbnr">
									<label class="guiigo-pds"><input type="radio" name="gviewpermnew" class="guiigo-pd-k" value="1" $gviewpermselect[1] /><span></span>{lang group_perm_all_user}</label>
									<label class="guiigo-pds"><input type="radio" name="gviewpermnew" class="guiigo-pd-k" value="0" $gviewpermselect[0] /><span></span>{lang group_perm_member_only}</label>
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang group_join_type} <span class="zy-i">*</span></div>
								<div class="wblb-wbnr">
									<label class="guiigo-pds"><input type="radio" name="jointypenew" class="guiigo-pd-k" value="0" $jointypeselect[0] /><span></span>{lang guiigo_manage:tlang0404}</label>
									<label class="guiigo-pds"><input type="radio" name="jointypenew" class="guiigo-pd-k" value="2" $jointypeselect[2] /><span></span>{lang guiigo_manage:tlang0405}</label>
									<label class="guiigo-pds"><input type="radio" name="jointypenew" class="guiigo-pd-k" value="1" $jointypeselect[1] /><span></span>{lang guiigo_manage:tlang0406}</label>
									<!--{if !empty($specialswitch['allowclosegroup'])}-->
									<label class="guiigo-pds"><input type="radio" name="jointypenew" class="guiigo-pd-k" value="-1" $jointypeselect[-1] /><span></span>{lang guiigo_manage:tlang0088}</label>
									<!--{/if}-->
								</div>
							</li>
						</ul>
					</div>
					<div class="mn-a">
						<button type="button" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang submit}</button>
						<input type="hidden" name="groupmanage" value="1" />
					</div>
				</form>
			<!--{elseif $_GET['op'] == 'checkuser'}-->
				<!--{if $checkusers}-->
					<div class="gg-qz-psqy bg-c sh-a xh-b ms-a">
						<h2 class="zy-h">{lang guiigo_manage:tlang0431}</h2>
						<span>
							<a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=1" 
							type="submit" 
							name="checkusertrue" 
							id="checkusertrue" 
							class="dialog ab-az zy-a zy-ac"
							value="true" 
							ck-cus="true"
							ck-param="{type:'modal',callpar:{fuid:'$value[uid]',type:'checkusertrue'},fn:'MsgCallManage',load:'true',uid: '$_G[uid]'}"
							external>{lang pass}</a>
							<a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=2" 
							type="submit" 
							name="checkusertrue" 
							id="checkusertrue" 
							class="dialog bg-i zy-f"
							value="true" 
							ck-cus="true"
							ck-param="{type:'modal',callpar:{fuid:'$value[uid]',type:'checkusertrue'},fn:'MsgCallManage',load:'true',uid: '$_G[uid]'}"
							external>{lang ignore}</a>
						</span>
					</div>
					<div class="gg-sq-tayc list-block-no bg-c sh-a xh-b ms-a">
						<ul>
							<!--{loop $checkusers $uid $user}-->
							<li id="#manage-$user[uid]-li" class="xh-a">
								<div class="bkys-anxx">
									<a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=1" 
									type="submit" 
									name="checkusertrue" 
									id="checkusertrue" 
									class="dialog guiigo-pn ab-az zy-a zy-ac" 
									value="true" 
									ck-cus="true"
									ck-param="{type:'modal',callpar:{fuid:'$value[uid]',type:'checkusertrue'},fn:'MsgCallManage',load:'true',uid: '$_G[uid]'}"
									external>{lang pass}</a>
									<a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=2" 
									type="submit" 
									name="checkuserfalse" 
									id="checkusertrue" 
									class="dialog guiigo-pn bg-i zy-f" 
									value="true" 
									ck-cus="true"
									ck-param="{type:'modal',callpar:{fuid:'$user[uid]',type:'checkusertrue'},fn:'MsgCallManage',load:'true',uid: '$_G[uid]'}"
									external>{lang ignore}</a>
								</div>
								<div class="bkys-bkico bkys-bkicoy">
									<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="guiigo-ty"><!--{echo avatar($user[uid], 'middle')}--></a>
								</div>
								<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="bkys-bkmc zy-e">$user[username]</a>
								<p class="zy-g">{lang guiigo_manage:tlang0432}: $user['joindateline']</p>
							</li>
							<!--{/loop}-->
						</ul>
					</div>
					<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0433}</p>
					</div>
				<!--{/if}-->
			<!--{elseif $_GET['op'] == 'manageuser'}-->
				<script type="text/javascript">
					function groupManageUser(targetlevel_val) {
						Dz('targetlevel').value = targetlevel_val;
					}
				</script>
				<div class="gg-qz-qbss">
					<div class="gg-qz-qzss">
						<a href="javascript:;" onclick="ck8('.gg-qz-qzss').hide();ck8('.gg-qz-qzsc').show();ck8('#groupsearch').focus()" class="bg-c zy-c"><i class="icon guiigoapp-sousuo"></i>{lang guiigo_manage:tlang0434}</a>
					</div>
					<div class="gg-qz-qzsc" style="display:none;">
						<form action="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]" method="post">
							<ul class="guiigo-flex">
								<input type="search" class="qzsc-sssr bg-c zy-c" id="groupsearch" name="srchuser" placeholder="{lang guiigo_manage:tlang0435}"/>
								<a href="javascript:;" onclick="ck8('.gg-qz-qzsc').hide();ck8('.gg-qz-qzss').show()"><i class="icon guiigoapp-guanbix zy-g"></i></a>
								<button type="submit" class="qzsc-ssqr ab-az zy-a zy-ac">{lang search}</button>
							</ul>
						</form>
					</div>
				</div>
				<form action="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]&manageuser=true" 
				name="manageuser" 
				id="manageuser" 
				method="post" 
				autocomplete="off" 
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pmid:'',type:'manageuser'},fn:'MsgCallManage',load:'true',uid:'$_G[uid]'}">
					<input type="hidden" value="{FORMHASH}" name="formhash" />
					<input type="hidden" value="0" name="targetlevel" id="targetlevel" />
					<!--{if $adminuserlist}-->
						<div class="gg-qz-cygl bg-c mx-a sh-a xh-b">
							<div class="cygl-btys bg-c zy-h">{lang group_admin_member}</div>
							<div class="cygl-cylb sh-a bg-c">
								<!--{loop $adminuserlist $user}-->
									<label class="guiigo-pd xh-b zy-h">
										<!--{if $_G['adminid'] == 1 || ($_G['uid'] != $user['uid'] && ($_G['uid'] == $_G['forum']['founderuid'] || $user['level'] > $groupuser['level']))}--><input type="checkbox" class="guiigo-pd-k" name="muid[{$user[uid]}]" value="$user[level]" /><!--{/if}-->
										<span></span>
										<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="cylb-lbtx guiigo-ty"><!--{echo avatar($user[uid], 'middle')}--></a>
										<div class="cylb-lbmc">
											<h2><a href="home.php?mod=space&uid=$user[uid]&do=profile" class="zy-e">$user[username]</a></h2>
											<p class="zy-b"><!--{if $user['level'] == 1}-->{lang guiigo_manage:tlang0436}<!--{elseif $user['level'] == 2}-->{lang guiigo_manage:tlang0437}<!--{/if}--></p>
										</div>
									</label>
								<!--{/loop}-->
							</div>
						</div>
					<!--{/if}-->
					<!--{if $staruserlist || $userlist}-->
						<div class="gg-qz-cygl gg-qz-cyglx bg-c sh-a xh-b">
							<div class="cygl-btys bg-c zy-h">{lang guiigo_manage:tlang0438}</div>
							<div class="cygl-cylb sh-a bg-c">
							<!--{if $staruserlist}-->
								<!--{loop $staruserlist $user}-->
									<label class="guiigo-pd xh-b zy-h">
										<!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}--><input type="checkbox" class="guiigo-pd-k" name="muid[{$user[uid]}]" value="$user[level]" /><!--{/if}-->
										<span></span>
										<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="cylb-lbtx guiigo-ty"><!--{echo avatar($user[uid], 'middle')}--></a>
										<div class="cylb-lbmc">
											<h2><a href="home.php?mod=space&uid=$user[uid]&do=profile" class="zy-e">$user[username]</a></h2>
											<p class="zy-i">{lang guiigo_manage:tlang0439}</p>
										</div>
									</label>
								<!--{/loop}-->
							<!--{/if}-->
							<!--{if $userlist}-->
								<!--{loop $userlist $user}-->
									<label class="guiigo-pd xh-b zy-h">
										<!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}--><input type="checkbox" class="guiigo-pd-k" name="muid[{$user[uid]}]" value="$user[level]" /><!--{/if}-->
										<span></span>
										<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="cylb-lbtx guiigo-ty"><!--{echo avatar($user[uid], 'middle')}--></a>
										<div class="cylb-lbmc">
											<h2><a href="home.php?mod=space&uid=$user[uid]&do=profile" class="zy-e">$user[username]</a></h2>
											<p class="zy-g">{lang guiigo_manage:tlang0440}: <!--{echo dgmdate($user[joindateline], 'u', '9999', getglobal('setting/dateformat'))}--></p>
										</div>
									</label>
								<!--{/loop}-->
							<!--{/if}-->
							</div>
						</div>
					<!--{/if}-->
					<!--{if $multipage}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
					<div class="gg-sq-cgan bg-c">
						<div class="cgan-hdkz">
							<ul>
							<!--{loop $mtype $key $name}-->
								<!--{if $_G['forum']['founderuid'] == $_G['uid'] || $key > $groupuser['level'] || $_G['adminid'] == 1}-->
								<!--{if $name == '{lang guiigo_manage:tlang0441}'}-->
                                 <button type="button" name="manageuser" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac" onclick="groupManageUser('{$key}')"><span>{lang guiigo_manage:tlang0442}</span></button>
								<!--{elseif $name == '{lang guiigo_manage:tlang0443}'}-->
								<button type="button" name="manageuser" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac" onclick="groupManageUser('{$key}')"><span>{lang guiigo_manage:tlang0444}</span></button>
								<!--{elseif $name == '{lang guiigo_manage:tlang0445}'}-->
								<button type="button" name="manageuser" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac" onclick="groupManageUser('{$key}')"><span>{lang guiigo_manage:tlang0439}</span></button>
								<!--{else}-->
								<button type="button" name="manageuser" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac" onclick="groupManageUser('{$key}')"><span>$name</span></button>
								<!--{/if}-->
								<!--{/if}-->
							<!--{/loop}-->
								<div class="guiigo-pn"></div>
								<input type="hidden" name="manageuser" value="true" />
							</ul>
						</div>
					</div>
				</form>
			<!--{elseif $_GET['op'] == 'threadtype'}-->
				<!--{if empty($specialswitch['allowthreadtype'])}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0446}</p>
					</div>
				<!--{else}-->
				<div id="threadtypes">
					<form id="threadtypeform" 
					action="forum.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]" 
					autocomplete="off" 
					method="post" 
					name="threadtypeform"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pmid:'',type:'threadtypeform'},fn:'MsgCallManage',load:'true',uid:'$_G[uid]'}"
					>
						<input type="hidden" value="{FORMHASH}" name="formhash" />
						
						<div class="gg-qz-flts bg-c ms-a"><div class="flts-tsnr bk-d bg-p zy-b">{lang threadtype_turn_on_comment}</div></div>
						<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
							<ul>
								<li class="guiigo-flex cl">
									<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0447}</div>
									<div class="wblb-wbnr">
										<label class="guiigo-pds"><input type="radio" name="threadtypesnew[status]" class="guiigo-pd-k" value="1" onclick="Dz('threadtypes_config').style.display = '';Dz('threadtypes_manage').style.display = '';" $checkeds[status][1] /><span></span>{lang yes}</label>
										<label class="guiigo-pds"><input type="radio" name="threadtypesnew[status]" class="guiigo-pd-k" value="0" onclick="Dz('threadtypes_config').style.display = 'none';Dz('threadtypes_manage').style.display = 'none';"  $checkeds[status][0] /><span></span>{lang no}</label>
									</div>
								</li>
							</ul>
						</div>
						<div class="guiigo-wblb list-block-no bg-c sh-a cl" id="threadtypes_config" style="display: $display">
							<ul>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang threadtype_required}</div>
									<div class="wblb-wbnr">
										<label class="guiigo-pds"><input type="radio" name="threadtypesnew[required]" class="guiigo-pd-k" value="1" $checkeds[required][1] /><span></span>{lang yes}</label>
										<label class="guiigo-pds"><input type="radio" name="threadtypesnew[required]" class="guiigo-pd-k" value="0" $checkeds[required][0] /><span></span>{lang no}</label>
									</div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0448}</div>
									<div class="wblb-wbnr">
										<label class="guiigo-pds"><input type="radio" name="threadtypesnew[prefix]" class="guiigo-pd-k" value="0" $checkeds[prefix][0] /><span></span>{lang threadtype_prefix_off}</label>
										<label class="guiigo-pds"><input type="radio" name="threadtypesnew[prefix]" class="guiigo-pd-k" value="1" $checkeds[prefix][1] /><span></span>{lang threadtype_prefix_on}</label>
									</div>
								</li>
							</ul>
						</div>
						<div class="gg-qz-fllb bg-c cl" id="threadtypes_manage" style="display: $display">
							<h2 class="bg-g xh-b zy-c cl">{lang guiigo_manage:tlang0427}</h2>
							<table cellspacing="0" cellpadding="0" class="fllb-xzfl">
								<thead>
									<tr>
										<th width="13%" class="xh-b zy-c">{lang delete}</th>
										<th width="13%" class="xh-b zy-c">{lang enable}</th>
										<th width="15%" class="xh-b zy-c">{lang displayorder}</th>
										<th width="40%" class="xh-b zy-c">{lang threadtype_name}</th>
										<th width="19%" class="xh-b"><a href="javascript:;" onclick="addrow(this,0)" class="zy-b">{lang guiigo_manage:tlang0449}</a></th>
									</tr>
								</thead>
								<!--{if $threadtypes}-->
									<!--{loop $threadtypes $val}-->
									<tbody>
										<tr>
											<td><label class="guiigo-pd"><input type="checkbox" class="guiigo-pd-k" name="threadtypesnew[options][delete][]" value="{$val[typeid]}" /><span></span></label></td>
											<td><label class="guiigo-pd"><input type="checkbox" class="guiigo-pd-k" name="threadtypesnew[options][enable][{$val[typeid]}]" value="1" $val[enablechecked] /><span></span></label></td>
											<td><input type="text" name="threadtypesnew[options][displayorder][{$val[typeid]}]" class="guiigo-px px-sa" size="2" value="$val[displayorder]" /></td>
											<td><input type="text" name="threadtypesnew[options][name][{$val[typeid]}]" class="guiigo-px px-sa" value="$val[name]" placeholder="{lang guiigo_manage:tlang0450}"/></td>
											<td></td>
										</tr>
									</tbody>
									<!--{/loop}-->
								<!--{/if}-->
							</table>
						</div>
						<script>
							var rowtypedata = [
								[
									[1,'<label class="guiigo-pd"><input type="checkbox" class="guiigo-pd-k" disabled="disabled" /><span></span></label>', ''],
									[1,'<label class="guiigo-pd"><input type="checkbox" class="guiigo-pd-k" name="newenable[]" checked="checked" value="1" /><span></span></label>', ''],
									[1,'<input class="guiigo-px px-sa" type="text" size="2" name="newdisplayorder[]" placeholder="0" />'],
									[1,'<input class="guiigo-px px-sa" type="text" name="newname[]" placeholder="{lang guiigo_manage:tlang0450}"/>'],
									[1,'']
								],
							];
							var addrowdirect = 0;
							var typenumlimit = $typenumlimit;
							function addrow(obj, type) {
								var table = obj.parentNode.parentNode.parentNode.parentNode;
								if(typenumlimit <= obj.parentNode.parentNode.parentNode.rowIndex - 1) {
									alert('{lang group_threadtype_limit_1}'+typenumlimit+'{lang group_threadtype_limit_2}');
									return false;
								}
								if(!addrowdirect) {
									var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
								} else {
									var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
								}

								var typedata = rowtypedata[type];
								for(var i = 0; i <= typedata.length - 1; i++) {
									var cell = row.insertCell(i);
									cell.colSpan = typedata[i][0];
									var tmp = typedata[i][1];
									if(typedata[i][2]) {
										cell.className = typedata[i][2];
									}
									tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return addrow.arguments[parseInt($2) + 1];});
									cell.innerHTML = tmp;
								}
								addrowdirect = 0;
							};
						</script>
						<div class="mn-a">
							<button type="submit" class="formdialog guiigo-pn ab-az zy-a zy-ac" name="groupthreadtype" value="1">{lang submit}</button>
							<input type="hidden" name="groupthreadtype" value="true" />
						</div>
					</form>
				</div>
				<!--{/if}-->
			<!--{elseif $_GET['op'] == 'demise'}-->
				<!--{if $groupmanagers}-->
					<div class="gg-qz-flts bg-c ms-a">
						<div class="flts-tsnr bk-d bg-p zy-b">{lang guiigo_manage:tlang0451}</div>
					</div>
					<form action="forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]" 
					id="groupdemise"
					name="groupdemise" 
					method="post" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pmid:'',type:'groupdemise'},fn:'MsgCallManage',load:'true',uid:'$_G[uid]'}"
					>
						<input type="hidden" value="{FORMHASH}" name="formhash" />
						<div class="gg-qz-cygl ms-a bg-c sh-a xh-b">
							<div class="cygl-btys bg-c zy-h">{lang transfer_group_to}</div>
							<div class="cygl-cylb sh-a bg-c">
								<!--{loop $groupmanagers $user}-->
									<label class="guiigo-pd guiigo-pds xh-b zy-h">
										<!--{if $user['uid'] != $_G['uid']}--><input type="radio" class="guiigo-pd-k" name="suid" value="$user[uid]" /><!--{/if}-->
										<span></span>
										<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="cylb-lbtx guiigo-ty"><!--{echo avatar($user[uid], 'middle')}--></a>
										<div class="cylb-lbmc">
											<h2><a href="home.php?mod=space&uid=$user[uid]&do=profile" class="zy-e">$user[username]</a></h2>
											<p class="zy-g"><!--{if $user['level'] == 1}-->{lang guiigo_manage:tlang0452}<!--{elseif $user['level'] == 2}-->{lang guiigo_manage:tlang0453}<!--{/if}--></p>
										</div>
									</label>
								<!--{/loop}-->
							</div>
						</div>
						<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
							<ul>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0454} <span class="zy-i">*</span></div>
									<div class="wblb-wbnr zy-h"><input type="password" name="grouppwd" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0216}"/></div>
								</li>
							</ul>
						</div>
						<div class="mn-a">
							<button type="submit" name="groupdemise" class="formdialog guiigo-pn ab-az zy-a zy-ac" value="1">{lang submit}</button>
							<input type="hidden" name="groupdemise" value="true" />
						</div>
					</form>
				<!--{else}-->
					<p class="emp">{lang group_no_admin_member}</p>
				<!--{/if}-->
			<!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript">
		function checkgroupname() {
			var groupname = $.trim(Dz('name').value);
			ajaxget('','forum.php?mod=ajax&forumcheck=1&infloat=creategroup&handlekey=creategroup&action=checkgroupname&groupname=' + (document.charset == 'utf-8' ? encodeURIComponent(groupname) : groupname), 'groupnamecheck');
		}
		function checkCategory(){
			var groupcategory = $.trim(Dz('fup').value);
			if(groupcategory == ''){
				Dz('groupcategorycheck').innerHTML = '{lang group_create_selete_categroy}';
				return false;
			} else {
				Dz('groupcategorycheck').innerHTML = '';
			}
		}
		<!--{if $_GET['fupid']}-->
				ajaxget('','forum.php?mod=ajax&action=secondgroup&fupid=$_GET[fupid]<!--{if $_GET[groupid]}-->&groupid=$_GET[groupid]<!--{/if}-->', 'secondgroup');
		<!--{/if}-->
		$(function(){
			if(Dz('name')) {
				Dz('name').focus();
			}
		})
		function __ajaxget(val){
			ajaxget(
				'',
				'forum.php?mod=ajax&action=secondgroup&fupid='+ val, 
				'secondgroup',
				'',
				function(res){
					if(res){
						$('#second').show()
					}else{
						$('#second').hide()
					}
				}
			)
		}
		function MsgCallManage(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0455}') != -1 && param.type == 'manage'){
					ck8.toast('{lang guiigo_manage:tlang0456}');
					app.PageRefresh(false,'#gg-qz-qzgl','forum.php?mod=group&action=manage&op=group&fid=$_G[fid]')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0457}') != -1 && param.type == 'manage'){
					ck8.toast('{lang guiigo_manage:tlang0458}');
					app.PageRefresh(false,'#gg-qz-qzgl','forum.php?mod=group&action=manage&op=group&fid=$_G[fid]')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0459}') != -1 && param.type == 'threadtypeform'){
					ck8.toast('{lang guiigo_manage:tlang0460}');
					app.PageRefresh(false,'#gg-qz-qzgl','forum.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0455}') != -1 && param.type == 'manageuser'){
					ck8.toast('{lang guiigo_manage:tlang0461}');
					app.PageRefresh(false,'#gg-qz-qzgl','forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0462}') != -1 && param.type == 'manageuser'){
					ck8.toast('{lang guiigo_manage:tlang0463}');
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0464}') != -1 && param.type == 'checkusertrue'){
					ck8.toast('{lang guiigo_manage:tlang0465}');
					app.PageRefresh(false,'#gg-qz-qzgl','forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]')
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0466}') != -1 && param.type == 'checkusertrue'){
					ck8.toast('{lang guiigo_manage:tlang0467}');
					app.PageRefresh(false,'#gg-qz-qzgl','forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]')
				}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0468}') != -1 && param.type == 'groupdemise'){
					ck8.toast('{lang guiigo_manage:tlang0469}');
					app.PageRefresh(false,'#gg-qz-qzgl','forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]')
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}
	</script>
</div>
