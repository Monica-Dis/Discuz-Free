<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="group-my">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0473}</h1>
	</header>
	<div class="content groupmy-scroll infinite-scroll" 
		data-url="$pageurl" 
		data-pages="50" 
		data-ppp="{$perpage}" 
		data-page="$page" 
		data-islod="false" 
		data-distance="10">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-groupmy list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $actives[join]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmy-scroll','group.php?mod=my&view=join',['gg-qz-wdqz']);">{lang my_join}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[manager]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmy-scroll','group.php?mod=my&view=manager',['gg-qz-wdqz']);">{lang my_manage}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[mythread]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmy-scroll','group.php?mod=my&view=mythread',['gg-qz-wdqz']);">{lang my_thread}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-qz-wdqz">
			<!--{if $view == 'groupthread' || $view == 'mythread'}-->
				<!--{if $groupthreadlist}-->
				    <!--{eval $groupthreadlist = GuiigoApp::GetGoruplist($groupthreadlist);}-->
					<div class="guiigo-ztlb list-block-no ">
						<ul class="list-container bg-g">
							<!--{loop $groupthreadlist $tid $post}-->
								<!--{if $post['closed'] > 1 || $post['moved']}-->
									<!--{eval $post[tid]=$post[closed];}-->
								<!--{/if}-->
								<!--{if (!$_G['setting']['mobile']['mobiledisplayorder3'] && $post['displayorder'] > 0) ||  $post['displayorder'] < 0}-->
									{eval continue;}
								<!--{/if}-->
								<li class="gztlb-ztys bg-c xh-b sh-a">
									<div class="gztlb-tbyh">
										<div class="tbyh-lztx"><a href="home.php?mod=space&uid=$post[authorid]&do=profile"><!--{avatar($post[authorid],middle)}--></a></div>
										<div class="tbyh-mcxx">
											<h1>
												<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="mcxx-yhmc zy-f">$post[author]</a>
												<span class="mcxx-yhdj zy-a" style="background: {$post[groupcolor]};">{$post[groupstars]} {$post[grouptitle]}</span>
												<!--{if $post['gender'] == 1 || $post['gender'] == 0}-->
												<i class="icon guiigoapp-nan bg-n"></i>
												<!--{elseif $post['gender'] == 2}-->
												<i class="icon guiigoapp-nv bg-o"></i>
												<!--{/if}-->
												<!--{if $_G['setting']['verify']['enabled']}-->
													<span class="verify-icon y">
													<!--{loop $post['verifyicon'] $verify}-->
														<a href="{$verify['verifurl']}" class="ck8-avatar-icon">
														   <img src="{$verify['verificon']}" class="vm" />
														</a>
													<!--{/loop}-->
													</span>
												<!--{/if}-->
											</h1>
											<div class="mcxx-fbxx">
												<i class="zy-g"><!--{eval echo dgmdate($post[dateline], 'u');}--></i>
											</div>
										</div>
									</div>
									<div class="gztlb-nrdy">
										<h1>
											<a href="forum.php?mod=viewthread&tid=$tid" class="zy-e">{$thread['subject']}</a>
										</h1>
										<!--{if $post['message']}-->
										<p class="zy-c"><!--{$post['message']}--></p>
										<!--{/if}-->
										<a href="forum.php?mod=viewthread&tid=$tid">
											<div class="nrdy-imgs">
												<ul style="display: flex;justify-content: left;flex-wrap: wrap;">
												<!--{loop $post[attapic] $imgkey $imglist}-->
													<!--{if $imglist['countImg'] == 1}-->
														<li class="imgs-tpsa"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
													<!--{elseif $imglist['countImg'] == 2}-->
														<li class="imgs-tpsb"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
													<!--{elseif $imglist['countImg'] == 3}-->
														<li class="imgs-tpsb imgs-tpsp"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
													<!--{else}-->
														<li class="imgs-tpsc<!--{if $imglist['countImg'] > 6}--> imgs-tpsd<!--{/if}-->"><img lazySrc="{$imglist['attach']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/><!--{if $imglist['countImg'] > 6}--><div class="tpsd-gdtp"><span class="tpsd-jtnr"><i class="icon guiigoapp-mkbtgd"></i>{$imglist['countImg']}</span></div><!--{/if}--></li>
													<!--{/if}-->
												<!--{/loop}-->
												</ul>
											</div>
										</a>
									</div>
									<div class="gztlb-ztcz">
										<div class="ztcz-lyrd cl">
											<div class="ztcz-bkht"><i class="icon guiigoapp-huati1 ab-a"></i><em><a href="forum.php?mod=group&fid=$post[fid]">$post[groupname]</a></em></div>
											<!--{if $post[heats] > 0}-->
												<div class="ztcz-bkht ztcz-ztrd"><i class="icon guiigoapp-lredu"></i>{lang guiigo_manage:tlang0879} {$post[heats]}</div>
											<!--{/if}-->
										</div>
										<ul>
											<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$tid" class="zy-c bg-l"><i class="icon guiigoapp-huifu"></i>$thread[replies]</a></li>
											<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$tid" class="zy-c bg-l"><i class="icon guiigoapp-chakan"></i>$thread[views]</a></li>
										</ul>
									</div>
								</li>	
							<!--{/loop}-->
						</ul>
						<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;display:none">
							<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
						</div>
					</div>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0474}</p>
					</div>
				<!--{/if}-->
				<!--{if $multipage}--><div class="pgs cl">$multipage</div><!--{/if}-->
			<!--{elseif $view == 'manager' || $view == 'join'}-->
				<!--{if $grouplist}-->
					<div class="guiigo-hylb list-block-no ms-a sh-a xh-b bg-c">
						<ul class="ms-c">
							<!--{loop $grouplist $groupid $group}-->
							<li class="sh-a">
								<a href="forum.php?mod=forumdisplay&action=list&fid=$groupid" class="hylb-ls">
									<img src="$group[icon]" alt="$group[name]" class="hylb-fx"/>
									<i class="icon guiigoapp-xzdk zy-g"></i>
									<h2 class="hylb-bt zy-h">$group[name]<!--{if $group['flevel'] == '-1'}--><span class="zy-i">{lang guiigo_manage:tlang0475}</span><!--{/if}--></h2>
									<p class="hylb-jj zy-g">{lang guiigo_manage:tlang0417}: $group[threads]&nbsp;&nbsp;{lang guiigo_manage:tlang0476}: $group[todayposts]</p>
								</a>
							</li>
							<!--{/loop}-->
						</ul>
					</div>
					<!--{if $multipage}--><div class="pgs">$multipage</div><!--{/if}-->
				<!--{else}-->
					<!--{if $view == 'manager'}-->
						<div class="guiigo-wnrtx">
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
							<p class="zy-c">{lang guiigo_manage:tlang0477}</p>
							<a href="forum.php?mod=group&action=create" class="ab-az zy-a zy-ac">{lang guiigo_manage:tlang0478}</a>
						</div>
					<!--{elseif $view == 'join'}-->
						<div class="guiigo-wnrtx">
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
							<p class="zy-c">{lang guiigo_manage:tlang0479}</p>
							<a href="group.php?gid=$guiigo_config['appsetting']['groupconfig']['group_ids']" class="ab-az zy-a zy-ac">{lang guiigo_manage:tlang0480}</a>
						</div>
					<!--{/if}-->
				<!--{/if}-->
			<!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	function MsgCallFn(msg,par,param) {
		if(typeof msg === 'object' || typeof par === 'object'){
			var Obj = $('.followmod_'+ par.fuid +'');
			var foObj = $('#recommend_add_'+ param.tid +'');
			var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
				$.toast('{lang guiigo_manage:tlang0003}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
				Obj.attr('ck-confirm','true')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
				$.toast('{lang guiigo_manage:tlang0009}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
				Obj.attr('ck-confirm','false')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
				$.toast('{lang guiigo_manage:tlang0007}');
			}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
				foObj.addClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzanon"></i>');
				$('#recommend_add_sum'+ param.tid).html(''+ (recommendcut + parseInt(par.recommendv)));
				foObj.find('a').addClass('delRecommenus').removeClass('dialog').attr('href','plugin.php?id=guiigo_manage:api&api=misc&action=recommend&do=del&tid='+ param.tid)
				$.toast('{lang guiigo_manage:tlang0045}');
				if(par.daycount){
					setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
				}
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
				$.toast('{lang guiigo_manage:tlang0049}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
				$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
					$.router.load('home.php?mod=spacecp&ac=usergroup');
				});
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
				$.toast('{lang guiigo_manage:tlang0053}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
				$.toast('{lang guiigo_manage:tlang0055}');
			}else {
				$.toast(msg.msg);
			}
		}else{
			$.toast('{lang guiigo_manage:tlang0056}');
		}
	}
	</script>
</div>
<!--{template common/footer}-->
