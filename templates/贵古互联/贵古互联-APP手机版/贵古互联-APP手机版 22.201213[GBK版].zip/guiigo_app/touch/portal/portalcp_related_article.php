<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if ($op == 'manual')}-->
	<!--{if $ra}-->
		<li id="$ra[aid]" class="gg-zx-xgqx">
			<em>$ra[title]</em>
			<span class="xggx-kzgn">
				<a href="javascript:;" onclick="uparticle($ra[aid]);"><i class="icon guiigoapp-xgwzxs zy-o vm"></i></a>
				<a href="javascript:;" onclick="downarticle($ra[aid]);"><i class="icon guiigoapp-xgwzxx zy-n vm"></i></a>
				<a href="javascript:;" onclick="delarticle($ra[aid]);"><i class="icon guiigoapp-xgwzsc zy-i vm"></i></a>
			</span>
		</li>
	<!--{/if}-->
<!--{elseif ($op == 'get')}-->
	<!--{loop $articlelist $list}-->
		<li id="$list[aid]" class="gg-zx-xgqx">
			<em>$list[title]</em>
			<span class="xggx-kzgn">
				<a href="javascript:;" onclick="uparticle($list[aid]);"><i class="icon guiigoapp-xgwzxs zy-o vm"></i></a>
				<a href="javascript:;" onclick="downarticle($list[aid]);"><i class="icon guiigoapp-xgwzxx zy-n vm"></i></a>
				<a href="javascript:;" onclick="delarticle($list[aid]);"><i class="icon guiigoapp-xgwzsc zy-i vm"></i></a>
			</span>
		</li>
	<!--{/loop}-->
<!--{elseif ($op == 'search')}-->
	<!--{loop $articlelist $list}-->
		<li>
			<label for="article_$list[aid]_pc" id="article_$list[aid]" class="guiigo-pd">
				<input type="checkbox" name="article" id="article_$list[aid]_pc" class="guiigo-pd-k" value="$list[aid]" onclick="getarticlenum();"/><span></span>$list[title]
			</label>
		</li>
	<!--{/loop}-->
<!--{elseif ($op == 'add')}-->
	<!--{loop $articlelist $raid $rvalue}-->
	<!--{eval $resdata = GuiigoApp::get_Portal_pic($rvalue['aid']);}-->
	<!--{eval $piccount = count($resdata);}-->
		<li class="xh-b" id="raid_li_$rvalue[aid]">
			<a href="{$rvalue[uri]}">
				<!--{if $piccount == 2 || $piccount == 1}-->
					<div class="zxls-pico">
					<!--{if $resdata[0]['attachment']}-->
					<img src="{$resdata[0]['attachment']}">
					<!--{/if}-->
					</div>
				<!--{/if}-->
				<h2 class="zy-e<!--{if $piccount == 2 || $piccount == 1}--> zxbx-bttd<!--{else}--> zxbx-btte<!--{/if}-->">{$rvalue[title]}</h2>
				<!--{if $piccount >= 3}-->
					<div class="zxls-tico list-block-no">
						<ul>
							<!--{loop $resdata $vkey $vpic}-->
								<li><img src="{$vpic['attachment']}" />
								<!--{if $vkey == 2}-->
								<!--{eval break;}-->
								<!--{/if}-->
								</li>
							<!--{/loop}-->
						</ul>
					</div>
				<!--{/if}-->
				<p class="zy-c<!--{if !$rvalue[pic]}--> zxbx-ysjd<!--{/if}-->"><i class="zy-c"><!--{eval echo DB::result_first("SELECT viewnum FROM %t WHERE aid=%d",array('portal_article_count',$rvalue['aid']));}-->{lang guiigo_manage:tlang0381}</i><!--{echo date("Y-m-d H:i",$rvalue[dateline])}--></p>
			</a>
		</li>
	<!--{/loop}-->
<!--{else}-->
	<div class="popup popup-about">
		<header class="bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b postsel app-header">
			<a class="pull-left close-popup zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
			<h1 class="title close-popup zy-h">{lang guiigo_manage:tlang0846}</h1>
		</header>
		<div class="content bg-g gg-yjms">
			<div class="list-block">
				<div class="guiigo-wblb list-block-no ms-a sh-a bg-c cl" id="chkalldiv">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0847}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="manualid" id="manualid" class="guiigo-px s-a" placeholder="{lang guiigo_manage:tlang0848}" size="10" /></div>
							<button type="button" name="raid_button" class="guiigo-pn gg-zx-fbia ab-az zy-a zy-ac" value="false" onclick="manualadd();">{lang guiigo_manage:tlang0849}</button>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0850}</div>
							<div class="wblb-wbnr zy-h">{$category}</div>
							<button type="button" name="search_button" class="guiigo-pn gg-zx-fbia ab-az zy-a zy-ac" value="false" onclick="articlesearch();">{lang guiigo_manage:tlang0851}</button>
						</li>
						<li class="wblb-dkbt bg-g xh-b zy-c cl">
							{lang wait_select} <span id="articlenum">0</span>/<span id="articlenumall">$count</span> {lang max_wait_select}
							<div class="gg-fb-tpmq"><label for="chkall" class="guiigo-pd"><input type="checkbox" name="chkall" id="chkall" class="guiigo-pd-k" value="" onclick="selectall();"/><span></span>{lang select_all}</label></div>
						</li>
						<ul id="articlelist" class="gg-zx-xgwz">
							<!--{loop $articlelist $list}-->
								<li>
									<label for="article_$list[aid]_pc" id="article_$list[aid]" class="guiigo-pd"><input type="checkbox" name="article" id="article_$list[aid]_pc" class="guiigo-pd-k" value="$list[aid]" onclick="getarticlenum();"/><span></span>$list[title]</label>
								</li>
							<!--{/loop}-->
						</ul>
						<li class="wblb-dkbt bg-g xh-b zy-c cl">
							<span style="line-height: 1.25rem;">{lang already_select} <i id="selectednum">0</i> {lang guiigo_manage:tlang0852}</span>
							<div class="gg-fb-tpmq"><button name="choosebutton" class="guiigo-pn gg-zx-fbia mx-b ab-az zy-a zy-ac" onclick="choosearticle();">{lang guiigo_manage:tlang0849}</button></div>
						</li>
						<ul id="selectedarticle" class="gg-zx-xgwz"></ul>
					</ul>
				</div>
				<div class="mn-a">
					<input type="hidden" id="selectedarray" name="selectedarray" value="" />
					<!--{if $_GET['update']}-->
					<input type="hidden" id="update" name="update" value="1" />
					<!--{/if}-->
					<button type="submit" name="dsf" class="guiigo-pn ab-az zy-a zy-ac" onclick="addrelatearticle();">{lang confirms}</button>
				</div>
				<script type="text/javascript" reload="1">
				function choosearticle() {
					var article = document.getElementsByName("article");
					for(var i = 0; i < article.length; i++){
						if(article[i].checked) {
							var choosed = Dz("article_"+article[i].value).innerHTML;
							choosed ='<li id="'+article[i].value+'" class="gg-zx-xgqx"><em>'+choosed+'</em><span class="xggx-kzgn"><a href="javascript:;" onclick="uparticle('+article[i].value+');" ><i class="icon guiigoapp-xgwzxs zy-o vm"></i></a><a href="javascript:;" onclick="downarticle('+article[i].value+');"><i class="icon guiigoapp-xgwzxx zy-n vm"></i></a> <a href="javascript:;" onclick="delarticle('+article[i].value+');"><i class="icon guiigoapp-xgwzsc zy-i vm"></i></a></span></li>';
							if(!Dz(article[i].value)) {
								Dz("selectedarticle").innerHTML += choosed;
							}
						}
					}
					updatearticlearray();
				}
				function uparticle(id) {
					var lastid = getdivid(id, 'last');
					if(lastid) {
						var lastdiv = Dz(lastid);
						var div = Dz(id);
						Dz("selectedarticle").insertBefore(div,lastdiv);
					}
					updatearticlearray();
				}
				function downarticle(id) {
					var nextid = getdivid(id, 'next');
					if(nextid) {
						var nextdiv = Dz(nextid);
						var div = Dz(id);
						Dz("selectedarticle").insertBefore(nextdiv,div);
					}
					updatearticlearray();
				}
				function delarticle(id) {
					var div = Dz(id);
					div.parentNode.removeChild(div);
					updatearticlearray();
				}
				function updatearticlearray() {
					var list = document.getElementById("selectedarticle").getElementsByTagName("li");
					var str = '';
					for(var i = 0; i < list.length; i++)
					{
						if(str == '') {
							str = list[i].id;
						} else {
							str = str + ',' + list[i].id;
						}

					}
					Dz('selectedarray').value = str;
					Dz('selectednum').innerHTML = list.length;
				}
				function getdivid(id,type) {
					var str = Dz('selectedarray').value;
					var arr = new Array();
					var rstr = '';
					arr = str.split(",");

					for (var i = 0; i < arr.length; i++) {
						if (arr[i] == id) {
							if(type == 'last') {
								if(arr[i-1]) {
									rstr = arr[i-1];
								}
							} else if(type == 'next') {
								if(arr[i+1]) {
									rstr = arr[i+1];
								}
							}
							break;
						}
					}
					return rstr;
				}
				function manualadd() {
					var manualid = Dz('manualid').value;
					if(Dz(manualid)) {
						ck8.toast('{lang article_validate_has_added}','shibai');
						return false;
					}
					var url = 'portal.php?mod=portalcp&ac=related&op=manual&catid=$catid&aid=$aid&inajax=1&manualid='+manualid;
					ck8.ajax({
						type : 'GET',
						url : url +'&inajax=1',
						dataType : 'xml',
						success: function(s){
							setTimeout(function(){ck8.hidePreloader()}, 100);
							s = trim(s.lastChild.firstChild.nodeValue);
							if(s) {
								Dz('selectedarticle').innerHTML += s;
								updatearticlearray();
							} else {
								ck8.toast('{lang article_validate_noexist}','shibai');
								return false;
							}
						},
						error: function(){
							ck8.hidePreloader();
							ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
						}
					})
				}
				function articlesearch() {
					ck8.showPreloader('','load');
					var searchkey = '';
					var searchcate = Dz('searchcate').value;
					var url = 'portal.php?mod=portalcp&ac=related&op=search&catid=$catid&aid=$aid&inajax=1&searchkey='+searchkey+'&searchcate='+searchcate;
					ck8.ajax({
						type : 'GET',
						url : url +'&inajax=1',
						dataType : 'xml',
						success: function(s){
							setTimeout(function(){ck8.hidePreloader()}, 100);
							s = trim(s.lastChild.firstChild.nodeValue);
							if(s) {
								Dz('articlelist').innerHTML = s;
								getarticlenum();
							} else {
								Dz('articlelist').innerHTML = '';
								getarticlenum();
								return false;
							}
						},
						error: function(){
							ck8.hidePreloader();
							ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
						}
					})
				}
				function getarticlenum() {
					var article = document.getElementsByName("article");
					for(var i = 0, j = 0; i < article.length; i++){
						if(article[i].checked) {
							j++;
						}
					}
					Dz('articlenum').innerHTML = j;
					Dz('articlenumall').innerHTML = article.length;
				}
				
				
				function addrelatearticle() {
					var relatedid = Dz("selectedarray").value;
					if(relatedid) {
						var url = 'portal.php?mod=portalcp&ac=related&op=add&catid=$catid&aid=$aid&inajax=1&relatedid='+relatedid;
						if(Dz('update')) {
							url += '&update=1';
						}
						ck8.ajax({
							type : 'GET',
							url : url +'&inajax=1',
							dataType : 'xml',
							success: function(s){
								setTimeout(function(){ck8.hidePreloader()}, 100);
								s = trim(s.lastChild.firstChild.nodeValue);
								if(s) {
									if(Dz('portalview')) {
										ck8.toast('{lang add_portal_related_success}');
									} else {
	
										Dz('raid_div_show').style.display = 'block';
										Dz('related_article').style.display = 'block';
										Dz('raid_div').innerHTML = s;
									}
								}
							},
							error: function(){
								ck8.hidePreloader();
								ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
							}
						})
					} else {
						Dz('raid_div_show').style.display = 'none';
						Dz('related_article').style.display = 'none';
						Dz('raid_div').innerHTML = '';
					}
					ck8.closeModal()
				}
				
				function getrelatedarticle() {
					var input = document.getElementById("raid_div").getElementsByTagName("input");
					if(input) {
						var id = '';
						for(var i = 0;i < input.length;i++)
						{
							if(id) {
								id = id + ',' + input[i].value;
							} else {
								id = input[i].value;
							}
						}
						if(id != '') {
							var url = 'portal.php?mod=portalcp&ac=related&op=get&catid=$catid&aid=$aid&inajax=1&id='+id;
							var x = new Ajax();
							x.get(url, function(s){
							s = trim(s);
							if(s) {
								Dz("selectedarray").value = id;
								Dz('selectedarticle').innerHTML = s;
								Dz('selectednum').innerHTML = input.length;
							}
							});
						}

					} else {
						return true;
					}
				}
				function selectall() {
					var input = document.getElementById("chkalldiv").getElementsByTagName("input");
					var checkall = 'chkall';
					count = 0;
					for(var i = 0; i < input.length; i++) {
						var e = input[i];
						if(e.name && e.name != checkall) {
							e.checked = input[checkall].checked;
							if(e.checked) {
								count++;
							}
						}
					}
					return count;
				}
				getrelatedarticle();
				appTplinit(ck8('.page'))
				</script>
			</div>
		</div>
    </div>
<!--{/if}-->
<!--{template common/footer}-->

