<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G[uid]}-->
	<!--{eval $favorite=GuiigoApp::getUserList($_G['uid'],'favorite','aid');}-->
<!--{/if}-->
<!--{eval $favid=$favorite[$article[aid]][favid];}-->
<!--{if $_G['uid'] && $article[aid] == $favorite[$article[aid]]['id'] && $favid}-->
	<!--{eval $favorurl="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favid&formhash=".FORMHASH."";}-->
	<!--{eval $favorclass='icon guiigoapp-nydbscon zy-m';}-->
<!--{else}-->
	<!--{eval $favorurl="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk&formhash=".FORMHASH."";}-->
	<!--{eval $favorclass='icon guiigoapp-nydbsc zy-e';}-->
<!--{/if}-->
<div class="bar bar-rep list-block-no guiigo-tabs bg-c sh-a">
	<ul>
		<!--{if $guiigo_config['isguiigoapp']}-->
		<li><a href="javascript:;" onclick="appShareAllview('#share_title','#share_img','#share_img');"><i class="icon guiigoapp-tbxhfx zy-e"></i></a></li>
		<!--{else}-->
		<li><a href="javascript:;" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');"><i class="icon guiigoapp-tbxhfx zy-e"></i></a></li>
		<!--{/if}-->
		<li><a href="$favorurl" 
		        class="dialog"
				id="favor_$article[aid]"
				ck-cus="true"
				ck-param="{type:'modal',fn:'MsgCallwzsc',load:'true',uid: '$_G[uid]'}" 
				external><i class="$favorclass"></i></a></li>
		<li><a href="javascript:;" onclick="scrollRely(this);" data-type="1"><i class="icon guiigoapp-nydbpl zy-e"></i></a></li>
		<li class="tabs-hfys tabs-hfysp"><a {if $_G[uid]}href="<!--{if $article['allowcomment']==1}--><!--{eval $data = &$article}-->javascript:;" onclick="app.ActionsManage('#guiigo-hfdp','t','auto','closehfdp');$('#message').focus();<!--{else}-->javascript:void(0);<!--{/if}-->" class="bg-g zy-c"{else}href="javascript:;" class="login bg-g zy-c"{/if}><i class="icon guiigoapp-xiepinglun"></i><!--{if $article['allowcomment']==1}--><!--{eval $data = &$article}-->{lang guiigo_manage:tlang0147}<!--{else}-->{lang guiigo_manage:tlang0853}<!--{/if}--></a></li>
	</ul>
</div>
<!--{if !$data[htmlmade]}-->
<div class="popup-actions" id="guiigo-hfdp">
	<div class="actions-text guiigo-hfdp bg-c">
		<form 
		id="cform"
		name="cform" 
		action="$form_url" 
		method="post" 
		autocomplete="off"
	    ck-cus="true" 
		ck-param="{type:'modal',load:'true',callpar:{type:'reply'},fn:'MsgCallportal',uid:'$_G[uid]'}">
			<div class="hfdp-btys xh-b bg-g">
				<a href="javascript:;" class="btys-gbck closehfdp"><i class="icon guiigoapp-guanbi zy-c"></i></a>
				<h2 class="zy-h">{lang guiigo_manage:tlang0689}</h2>
			</div>
			<div class="hfdp-srys xh-b bg-c">
				<!--{if $_G['uid'] || $_G['group']['allowcomment']}-->
					<textarea name="message" rows="3" class="guiigo-pt zy-f" id="message" placeholder="{lang guiigo_manage:tlang0229}"></textarea>
				<!--{else}-->
					<div class="srys-qtts"><i class="icon guiigoapp-tbxhjb"></i>{lang guiigo_manage:tlang0854} <a href="member.php?mod=logging&action=login">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}">$_G['setting']['reglinkname']</a></div>
				<!--{/if}-->
			</div>
			<!--{if $secqaacheck || $seccodecheck}--><!--{subtemplate common/seccheck}--><!--{/if}-->
			<div class="hfdp-crqd xh-b bg-g">
				<div class="crqd-gdqd">
					<!--{if !empty($topicid) }-->
					<input type="hidden" name="referer" value="$topicurl" />
					<input type="hidden" name="topicid" value="$topicid">
					<!--{else}-->
					<input type="hidden" name="portal_referer" value="$viewurl">
					<input type="hidden" name="referer" value="$viewurl" />
					<input type="hidden" name="id" value="$data[id]" />
					<input type="hidden" name="idtype" value="$data[idtype]" />
					<input type="hidden" name="aid" value="$aid">
					<!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}">
					<input type="hidden" name="replysubmit" value="true">
					<input type="hidden" name="commentsubmit" value="true" />
					<button type="submit" name="commentsubmit_btn" value="true" id="commentsubmit_btn" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang comment}</button>
				</div>
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="crqd-btat">
					<ul>
						<li><a {if $_G[uid]}href="JavaScript:void(0)" onclick="showFace('appendface', 'message',this)"{else}href="member.php?mod=logging&action=login"{/if} class="zy-c"><i class="icon guiigoapp-biaoqing"></i><p>{lang guiigo_manage:tlang0150}</p></a></li>
					</ul>
				</div>
			</div>
			<div class="bg-c cl">
				<div class="kznr-bqnr cl" style="display:none;" id="appendface"></div>
			</div>
		</form>
	</div>
</div>
<!--{/if}-->
