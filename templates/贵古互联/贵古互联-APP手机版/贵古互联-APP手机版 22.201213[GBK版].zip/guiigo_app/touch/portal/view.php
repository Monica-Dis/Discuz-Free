<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="portal-view">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-f" style="font-size: 1rem;"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0369}</h1>
	</header>
	<div class="content<!--{if $article['allowcomment']==1}--><!--{eval $data = &$article}--> content-bts<!--{/if}-->">
		<div class="list-block">
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
							<li><a href="javascript:;" class="zy-f xh-b" onclick="app.ActionsManage('#guiigo-lcgl-lzgl','t', 'auto');"><i class="icon guiigoapp-kjzlbj"></i>{lang guiigo_manage:tlang0984}</a></li>
						<!--{/if}-->
						<li><a href="home.php?mod=space&uid=$article[uid]&do=profile" class="zy-f xh-b"><i class="icon guiigoapp-kjsyzl"></i>{lang guiigo_manage:tlang0855}</a></li>
						<li><a href="misc.php?mod=invite&action=article&id=$article[aid]" 
								class="zy-f xh-b dialog"
								ck-cus="true"
								ck-param="{type:'modal',callpar:{'pid':'$post[pid]',type:'invite'},fn:'MsgCallInvite',load:'true',uid:'$_G[uid]'}"
								external ><i class="icon guiigoapp-yaoqing"></i>{lang guiigo_manage:tlang0413}</a></li>
						<!--{if $guiigo_config['isguiigoapp']}-->
						<li><a href="javascript:;" onclick="appShareAllview('#share_title','#share_img','#share_img');" class="zy-f"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						<!--{else}-->
						<li><a href="javascript:;" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');" class="zy-f"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						<!--{/if}-->
					</ul>
				</div>
			</div>
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="popup-actions" id="guiigo-nrdbfx">
				<div class="actions-text guiigo-hdfx">
					<div class="gg-app-hide hdfx-hdxm xh-b bg-e">
						<a href="javascript:;"  data-app="weixin" class="nativeShare weixin zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wx.png" class="vm"></span>{lang guiigo_manage:tlang0153}</a>
						<a href="javascript:;" data-app="weixinFriend" class="nativeShare weixin_timeline zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/pyq.png" class="vm"></span>{lang guiigo_manage:tlang0154}</a>
						<a href="javascript:;" data-app="QQ" class="nativeShare qq zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/qq.png" class="vm"></span>{lang guiigo_manage:tlang0155}</a>
						<a href="javascript:;" data-app="QZone" class="nativeShare qzone zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kj.png" class="vm"></span>{lang guiigo_manage:tlang0156}</a>
						<a href="javascript:;" data-app="sinaWeibo" class="nativeShare weibo zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wb.png" class="vm"></span>{lang guiigo_manage:tlang0157}</a>
					</div>
					<div class="gg-app-show hdfx-xcxt xh-b bg-e">
						<span class="icon guiigoapp-xiaochengxu"></span>
						<h2>{lang guiigo_manage:tlang1002}</h2>
						<p>{lang guiigo_manage:tlang1003}</p>
					</div>
					<div class="hdfx-hdxm bg-e">
						<a href="javascript:;" class="zy-f zd-12" onclick="copy(this);" id="cptextid"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/fz.png" class="vm"></span>{lang guiigo_manage:tlang0158}</a>
						<a href="javascript:;" class="zy-f zd-12" onclick="setClass();"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/zt.png" class="vm"></span><em class="btfont">{lang guiigo_manage:tlang0997}</em></a>
					</div>
					<a href="javascript:;" class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</a>
				</div>
			</div>
			<div class="share-layer"></div>
			<!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
			<div class="popup-actions" id="guiigo-lcgl-lzgl">
				<div class="actions-text guiigo-hdfx">
					<div class="hdfx-glxm hdfx-glxmh list-block-no bg-e">
						<ul>
							<li class="bg-c"><a href="javascript:;" class="postrepl-popup zy-h sh-a" data-url="portal.php?mod=portalcp&ac=article&op=edit&aid=$article[aid]" data-no-cache="true" external>{lang edit}</a></li>
							<li class="bg-c<!--{if $article[status]>0 && ($_G['group']['allowmanagearticle'] || $categoryperm[$value['catid']]['allowmanage'])}--> xh-b<!--{/if}-->"><a href="javascript:;" id="related_article"  class="zy-h sh-a postrepl-popup" data-url="portal.php?mod=portalcp&ac=related&aid=$article[aid]&catid=$article[catid]&update=1" data-no-cache="true" external>{lang article_related}</a></li>
							<!--{if !$article[status]>0 && ($_G['group']['allowmanagearticle'] || !$categoryperm[$value['catid']]['allowmanage'])}-->
							<li class="bg-c xh-b"><a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$article[aid]&delcatid=$catid" 
								id="article_delete_$article[aid]"
								class="dialog zy-h sh-a"
								ck-cus="true"
								ck-param="{type:'modal',callpar:{catid:'$catid',aid:'$article[aid]',type:'delete'},fn:'MsgCallportal',load:'true',uid:'$_G[uid]'}"
								external >{lang delete}</a></li>
							<!--{/if}-->
						</ul>
					</div>
					<a href="javascript:;" class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</a>
				</div>
			</div>
			<!--{/if}-->
			<div class="bg-c gg-yjwb">
				<div class="gg-zx-mxbt">
					<h1 id="share_title" class="zy-e">$article[title]</h1>
					<p>
						<span class="zy-g"><a href="{echo getportalcategoryurl($cat[catid])}" class="zy-g">$cat[catname]</a></span>
						<span class="zy-g"><em id="_viewnum"><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}--></em>{lang guiigo_manage:tlang0381}</span>
						<span class="zy-g">$article[dateline]</span>
					</p>
				</div>
				<!--{if $article[summary] && empty($cat[notshowarticlesummay])}-->
					<div class="gg-zx-zxdd bg-e zy-f"><span class="bg-b zy-a">{lang article_description}</span>$article[summary]</div>
				<!--{/if}-->
				<div id="share_img" class="gg-zx-zxnr zy-h guiigo-external">
					$content[content]
				</div>
				<!--{if $multi}--><div class="gg-zx-wzfy bg-c cl">$multi</div><!--{/if}-->
				<!--{if $article['preaid'] || $article['nextaid']}-->
				<div class="gg-zx-sxqh sh-a">
					<!--{if $article['prearticle']}--><a href="{$article['prearticle']['url']}" class="zy-f"><i class="icon guiigoapp-wzsyp"></i>{lang pre_article}{$article['prearticle']['title']}</a><!--{/if}-->
					<!--{if $article['nextarticle']}--><a href="{$article['nextarticle']['url']}" class="zy-f"><i class="icon guiigoapp-wzxyp"></i>{lang next_article}{$article['nextarticle']['title']}</a><!--{/if}-->
				</div>
				<!--{/if}-->
			</div>
			<!--{if $article['related']}-->
			<div class="guiigo-tmkbt ms-a bg-c sh-a xh-b" id="raid_div_show">
				<h2 class="zy-e"><span class="gg-kj-xtnr bg-j"><i class="icon guiigoapp-xihuan zy-a"></i></span>{lang view_related}</h2>
			</div>
			<div id="related_article" class="gg-zx-zxls list-block-no bg-c xh-b">
				<ul id="raid_div">
				<!--{loop $article['related'] $raid $rvalue}-->
				<!--{eval $resdata = GuiigoApp::get_Portal_pic($rvalue['aid']);}-->
				<!--{eval $piccount = count($resdata);}-->
					<li class="xh-b">
						<a href="{$rvalue[uri]}">
							<!--{if $piccount == 2 || $piccount == 1}-->
								<div class="zxls-pico">
								<!--{if $resdata[0]['attachment']}-->
								<img src="{$resdata[0]['attachment']}">
								<!--{/if}-->
								</div>
							<!--{/if}-->
							<h2 class="zy-e<!--{if $piccount == 2 || $piccount == 1}--> zxbx-bttd<!--{else}--> zxbx-btte<!--{/if}-->">{$rvalue[title]}</h2>
							<!--{if $piccount >= 3}-->
								<div class="zxls-tico list-block-no">
									<ul>
										<!--{loop $resdata $vkey $vpic}-->
											<li><img src="{$vpic['attachment']}" />
											<!--{if $vkey == 2}-->
											<!--{eval break;}-->
											<!--{/if}-->
											</li>
										<!--{/loop}-->
									</ul>
								</div>
							<!--{/if}-->
							<p class="zy-c<!--{if !$rvalue[pic]}--> zxbx-ysjd<!--{/if}-->"><i class="zy-c"><!--{eval echo DB::result_first("SELECT viewnum FROM %t WHERE aid=%d",array('portal_article_count',$rvalue['aid']));}-->{lang guiigo_manage:tlang0381}</i><!--{echo date("Y-m-d H:i",$rvalue[dateline])}--></p>
						</a>
					</li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{else}-->
				<div class="guiigo-tmkbt ms-a bg-c sh-a xh-b" id="raid_div_show" style="display:none;">
					<h2 class="zy-e"><span class="gg-kj-xtnr bg-j"><i class="icon guiigoapp-xihuan zy-a"></i></span>{lang view_related}</h2>
				</div>
				<div id="related_article" class="gg-zx-zxls list-block-no bg-c xh-b">
					<ul id="raid_div"></ul>
				</div>
			<!--{/if}-->
			<div id="comment">
				<div class="guiigo-tmkbt bg-c sh-a xh-b" style="margin-top:.55rem;">
					<h2 class="zy-e">
						<!--{if $data[commentnum]}--><!--{/if}-->
						<!--<a href="$common_url" class="tmbkt-ckqb zy-c">{lang view_all_comments}</a>-->
						<span class="gg-kj-xtnr bg-d"><i class="icon guiigoapp-nydbpl zy-a"></i></span>
						<!--{if $data[commentnum] > 0}--><span id="_commentnum">$data[commentnum]</span>{lang guiigo_manage:tlang0687}<!--{else}-->{lang comment}<!--{/if}-->
					</h2>
				</div>
				<!--{if $data[commentnum]}-->
					<div id="comment_ul" class="gg-kj-sssj bg-c">
						<!--{loop $commentlist $comment}-->
							<!--{template portal/comment_li}-->
						<!--{if !empty($aimgs[$comment[cid]])}-->
							<script type="text/javascript" reload="1">aimgcount[{$comment[cid]}] = [<!--{echo implode(',', $aimgs[$comment[cid]]);}-->];attachimgshow($comment[cid]);</script>
						<!--{/if}-->
						<!--{/loop}-->
					</div>
				<!--{else}-->
					<div class="guiigo-wnrtx bg-c">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0688}</p>
					</div>
				<!--{/if}-->
			</div>
		</div>
	</div>
	<!--{subtemplate portal/portal_comment}-->
<script>
ck8(function(){
	if(ck8('#focbtn').length > 0){
		ck8('#focbtn').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('#rewardbut').length > 0){
		ck8('#rewardbut').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('.debatereply').length > 0){
		ck8('.debatereply').click(function(e){
			Dz('needmessage').focus()
		})
	}
})

function ShareAllportal(){
	//�õ���������
		var config = getShareData('#share_title','#share_img','#share_img');
	<!--{if ($guiigo_config['browser']['isqq'] || $guiigo_config['browser']['isuc']) && !$guiigo_config['browser']['iswx']}-->
		//����� UC qq �����
		nativeShare(config);
	<!--{elseif $guiigo_config['browser']['iswx']}-->
		//�����΢�������
		wxshareJssdkAjax(config)
	<!--{else}-->
		//������� ΢������� UC qq �����
		webShare(config)
	<!--{/if}-->
}

function MsgCallportal(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0169}') != -1 && param.type == 'reply'){
			app.close_popup()
			ck8('#message').val('');
			if(typeof seccode == 'function'){
				seccode(ck8('.seccodeimg'))
			}
			app.PageRefresh(false,'#comment')
			ck8.toast('{lang guiigo_manage:tlang0690}');

		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0169}') != -1 && param.type == 'delete'){
			ck8.toast('{lang guiigo_manage:tlang0856}');
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallwzplx(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'bianji'){
			ck8.toast('{lang guiigo_manage:tlang0695}');
			app.PageRefresh(false,'#comment_'+ param.liid +'_li')
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'shanchu'){
			ck8.toast('{lang guiigo_manage:tlang0561}');
			app.PageRefresh(false,'#comment')
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallwzsc(msg,par){
	if(typeof msg === 'object' || typeof par === 'object'){
		if(msg.msg && msg.msg.indexOf('{lang guiigo_manage:tlang0014}') != -1) {
			ck8.toast('{lang guiigo_manage:tlang0177}');
			var fdelurl='home.php?mod=spacecp&ac=favorite&op=delete&favid='+ par.favid +'&formhash={FORMHASH}';
			ck8('#favor_' + par.id).attr('href',fdelurl)
			ck8('#favor_' + par.id).find('i').removeClass('guiigoapp-nydbsc zy-e').addClass('guiigoapp-nydbscon zy-m')

		}else if(msg.msg && msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && par.favid && par.id){
			ck8.toast('{lang guiigo_manage:tlang0178}');
			var favorurl ='home.php?mod=spacecp&ac=favorite&type=article&id='+ par.id +'&formhash={FORMHASH}';
			ck8('#favor_' + par.id).attr('href',favorurl)
			ck8('#favor_' + par.id).find('i').removeClass('guiigoapp-nydbscon zy-m').addClass('guiigoapp-nydbsc zy-e')
		}else {
			ck8.toast(msg.msg,'shibai');
		}
		
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallInvite(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0168}') != -1){
			ck8.closeModal('.popup-about-js')
			ck8.toast(msg.msg);
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}
</script>
</div>
<!--{template common/footer}-->
