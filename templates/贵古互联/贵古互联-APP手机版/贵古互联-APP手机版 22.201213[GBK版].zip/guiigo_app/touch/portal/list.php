<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->
<div class="page page-current" data-mod="portal-list">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c<!--{if !$cat[others]}--> xh-b<!--{/if}-->">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-f" style="font-size: 1rem;"></i></a>
		<h1 class="title zy-h">$cat[catname]</h1>
	</header>
	<!--{eval $perpage = empty($cat['perpage']) ? 15 : $cat['perpage'];}-->
	<div class="content infinite-scroll portallist-scroll" 
		data-url="$cat['caturl']" 
		data-pages="{$list['count']}" 
		data-ppp="{$perpage}" 
		data-page="$page" 
		data-islod="false" 
		data-distance="10">
		<div class="list-block">
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<!--{if ($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])}-->
							<li><a href="javascript:;" class="zy-f xh-b postrepl-popup" data-url="portal.php?mod=portalcp&ac=article&catid=$cat[catid]" data-no-cache="true" external><i class="icon guiigoapp-bianji"></i>{lang guiigo_manage:tlang0982}</a></li>
						<!--{/if}-->
						<li><a href="search.php?mod=portal" class="zy-f"><i class="icon guiigoapp-xlsousuo"></i>{lang guiigo_manage:tlang0983}</a></li>
					</ul>
				</div>
			</div>
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $cat[others]}-->
				<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
					<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-portallist list-block-no xh-b bg-c">
						<ul class="swiper-wrapper">
							<!--{loop $cat[others] $value}-->
								<li class="swiper-slide<!--{if $value['catid'] == $_GET['catid']}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.portallist-scroll','{$portalcategory[$value['catid']]['caturl']}',['gg-zx-zxon','guiigo-nydb','gg-zx-zxfy']);">$value[catname]</a><span class="bg-b"></span></li>
							<!--{/loop}-->
						</ul>
					</div>
				<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<!--{/if}-->
			<div class="gg-zx-zxon ms-a sh-a xh-b">
				<!--{if $cat[subs]}-->
				<div class="tpzt-rqsx bg-c xh-b">
					<!--{eval $i = 1;}-->
					<!--{loop $cat[subs] $value}-->
					<!--{if $i != 1}--><span class="zy-g">|</span><!--{/if}--><a href="{$portalcategory[$value['catid']]['caturl']}" class="zy-c{if $orderby == 'thisweek'} zy-be{/if}">$value[catname]</a><!--{eval $i--;}-->
					<!--{/loop}-->
				</div>
				<!--{/if}-->
				<!--{if $list['list']}-->
					<div class="gg-zx-zxls list-block-no bg-c">
						<ul class="list-container">
						<!--{loop $list['list'] $value}-->
						<!--{eval $highlight = article_title_style($value);}-->
						<!--{eval $article_url = fetch_article_url($value);}-->
						<!--{eval $resdata = GuiigoApp::get_Portal_pic($value['aid']);}-->
						<!--{eval $piccount = count($resdata);}-->
							<li class="xh-b">
								<a href="$article_url">
									<!--{if $piccount == 2 || $piccount == 1}-->
									<div class="zxls-pico">
									<!--{if $resdata[0]['attachment']}-->
									<img src="{$resdata[0]['attachment']}">
									<!--{/if}-->
									</div>
									<!--{/if}-->
									
									<h2 class="{if $piccount == 2 || $piccount == 1}zxbx-bttd{else}zxbx-btte{/if}" $highlight>$value[title]</h2>
									<!--{if $piccount >= 3}-->
										<div class="zxls-tico list-block-no">
											<ul>
												<!--{loop $resdata $vkey $vpic}-->
													<li><img lazySrc="{$vpic['attachment']}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/>
													<!--{if $vkey == 2}-->
													<!--{eval break;}-->
													<!--{/if}-->
													</li>
												<!--{/loop}-->
											</ul>
										</div>
									<!--{/if}-->
									<p class="zy-c<!--{if !$value[pic]}--> zxbx-ysjd<!--{/if}-->"><i class="zy-c"><!--{eval echo DB::result_first("SELECT viewnum FROM %t WHERE aid=%d",array('portal_article_count',$value['aid']));}-->{lang guiigo_manage:tlang0381}</i>$value[dateline]</p>
								</a>
							</li>
						<!--{/loop}-->
						</ul>
					</div>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0838}</p>
					</div>
				<!--{/if}-->
			</div>
		</div>
		<div class="gg-zx-zxfy">
			<!--{if $list['multi']}-->
			<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
				<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
			</div>
			<!--{/if}-->
		</div>
	</div>
</div>
<!--{template common/footer}-->
