<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval dheader('Location:plugin.php?id=guiigo_manage&act=index');exit;}-->
<!--{template common/footer}-->
