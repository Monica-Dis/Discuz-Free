<?php
// 指定允许其他域名访问
header('Access-Control-Allow-Origin:*');
// 响应类型
header('Access-Control-Allow-Methods:GET,POST');
// 响应头设置
header('Access-Control-Allow-Headers:x-requested-with,content-type');

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once libfile('class/guiigoapplet','plugin/guiigo_applet');
$config = GuiigoApplet::config();

$msgarr = array();
$msgarr['code'] = 1000; //1000 1001 1003
$msgarr['data'] = array();
$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs025');

if(empty($_GET['api']) || !in_array($_GET['api'], array('init','login'))) $_GET['api'] = 'error';
$gpuid = $_GET['openid'];

if(!in_array($_GET['api'], array('login','init'))){
	$Luid = GuiigoApplet::DecodeGetUid(daddslashes($gpuid));
	if($Luid <= 0 || !$gpuid){
		$msgarr = array();
		$msgarr['code'] = 1001;
		$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs026');
		GuiigoApplet::RetMsgJson($msgarr);
	}else{
		GuiigoApplet::loadLoginStatus($Luid);
	}
}

include_once libfile('api/'.$_GET['api'],'plugin/guiigo_applet');
?>