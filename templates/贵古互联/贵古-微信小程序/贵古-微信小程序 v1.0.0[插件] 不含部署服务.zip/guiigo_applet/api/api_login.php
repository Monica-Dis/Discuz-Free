<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/userlogin','plugin/guiigo_applet');

if($_GET['act'] == 'userlogin'){
    $post = daddslashes($_POST);
	if(!empty($_POST['code'])){
		$user = UserLogin::getsessionkey($post['code'], trim($config['wxappid']), trim($config['wxappsecret']));
		if(!$user['session_key']){
			$msgarr['code'] = -1;
			$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs014');
			GuiigoApplet::RetMsgJson($msgarr);
		}
		$userinfo = array('nickName'  => $post['nickName'],
						   'openid'   => $user['openid'],
						   'unionid'  => $user['unionid'],
						   'session_key' => $user['session_key'],
						   'gender'   => $post['gender'],
						   'city'     => $post['city'], 
						   'province' => $post['province'],
						   'country'  => $post['country'],
						   'avatarUrl'=> $post['avatarUrl']
				);
		$u_list = DB::fetch_first('SELECT * FROM %t WHERE u_openid=%s',array('guiigo_applet_user',$userinfo['openid']));

		if(!$u_list['u_uid'] && in_array('guiigo_login',$_G['setting']['plugins']['available']) && $userinfo['unionid']){
		    $u_list['u_uid'] = DB::result_first('select u_uid from %t where u_wx_unionid=%s', array('guiigo_login_user',$userinfo['unionid']));
		}
		
		if($u_list['u_uid']){
            $member = getuserbyuid($u_list['u_uid'], 1);
			unset($userinfo['avatarUrl']);
			$loginlist = UserLogin::wx_bind($u_list['u_uid'], $userinfo);
			if($loginlist){
				GuiigoApplet::loadLoginStatus($u_list['u_uid']);
				
				$u_list['u_openid'] = GuiigoApplet::enOpenid($u_list['u_openid']);
				$msgarr['code'] = 1;
				$msgarr['data'] = array('userlist'=> $u_list);
				$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs015');
			}else{
				$msgarr['code'] = -2;
				$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs016');
			}
			GuiigoApplet::RetMsgJson($msgarr);

		}else if($config['iswxbind']){
			$hash = random(16);
            savecache($hash, $userinfo);
			$msgarr['code'] = 2;
			$msgarr['data'] = array('userinfo'=> array('hash'=>$hash));
			$msgarr['msg'] = 'ok';
		    GuiigoApplet::RetMsgJson($msgarr);

		}else{

			$loginlist = UserLogin::wx_login($userinfo);
			if($loginlist['state'] == true && $loginlist['uid']){
				$userList = DB::fetch_first('SELECT * FROM %t WHERE u_uid=%s',array('guiigo_applet_user',$loginlist['uid']));
				$userList['u_openid'] = GuiigoApplet::enOpenid($userList['u_openid']);
				$msgarr['code'] = 1;
				$msgarr['data'] = array('userlist'=> $userList);
				$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs017');
			}else{
				$msgarr['code'] = -3;
				$msgarr['msg'] = $loginlist['statemsg'];
			}
			GuiigoApplet::RetMsgJson($msgarr);
		}
	}

}else if($_GET['act'] == 'bindlogin'){
    loaducenter(); /*dis'.'m.t'.'ao'.'bao.com*/
	$post = daddslashes($_POST);
	$hash = $post['hash'];
	loadcache($hash);
	$userinfo = $_G['cache'][$hash];
	$wxusername = $post['wxusername'];
	$wxpassword = $post['wxpassword'];
	
	if(empty($userinfo['openid'])){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs023');
		GuiigoApplet::RetMsgJson($msgarr);
	}
	
	if(empty($wxusername)){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs018');
		GuiigoApplet::RetMsgJson($msgarr);
	}

	if(empty($wxpassword)){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs019');
		GuiigoApplet::RetMsgJson($msgarr);
	}

	$result = uc_user_login($wxusername, $wxpassword);
	if($result[0] > 0 && $userinfo){
		savecache($hash,'');
		$member = getuserbyuid($result[0], 1);
		if(isset($member['_inarchive'])) {
			C::t('common_member_archive')->move_to_master($result[0]);
		}
        unset($userinfo['avatarUrl']);
		$loginlist = UserLogin::wx_bind($result[0], $userinfo);
		if($loginlist){
			GuiigoApplet::loadLoginStatus($result[0]);
			$userList = DB::fetch_first('SELECT * FROM %t WHERE u_uid=%s',array('guiigo_applet_user',$result[0]));
			$userList['u_openid'] = GuiigoApplet::enOpenid($userList['u_openid']);
			$msgarr['code'] = 1;
			$msgarr['data'] = array('userlist'=> $userList);
            $msgarr['msg'] = lang('plugin/guiigo_applet', 'langs020');
		}else{
			$msgarr['code'] = -3;
			$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs021');
		}
		GuiigoApplet::RetMsgJson($msgarr);

	}else{
		$msgarr['code'] = -4;
		$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs022');
        GuiigoApplet::RetMsgJson($msgarr);
	}
	
	
}else if($_GET['act'] == 'Newbindlogin'){

	loaducenter(); /*dis'.'m.t'.'ao'.'bao.com*/
	$post = daddslashes($_POST);
	$hash = $post['hash'];
	loadcache($hash);
	$userinfo = $_G['cache'][$hash];
	savecache($hash,'');
	if(empty($userinfo['openid'])){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_applet', 'langs023');
		GuiigoApplet::RetMsgJson($msgarr);
	}

	$loginlist = UserLogin::wx_login($userinfo);
	if($loginlist['state'] == true && $loginlist['uid']){

		$userList = DB::fetch_first('SELECT * FROM %t WHERE u_uid=%s',array('guiigo_applet_user',$loginlist['uid']));
		$userList['u_openid'] = GuiigoApplet::enOpenid($userList['u_openid']);
		$msgarr['code'] = 1;
		$msgarr['data'] = array('userlist'=> $userList);
        $msgarr['msg'] = lang('plugin/guiigo_applet', 'langs024');
	}else{
		$msgarr['code'] = -2;
		$msgarr['msg'] = $loginlist['statemsg'];
	}
	GuiigoApplet::RetMsgJson($msgarr);
}
