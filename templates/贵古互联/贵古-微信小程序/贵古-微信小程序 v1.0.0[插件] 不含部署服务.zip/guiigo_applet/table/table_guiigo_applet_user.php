<?php
 /**
 * Created by DisM.
 * ���²����http://t.cn/Aiux1Jx1
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_guiigo_applet_user extends discuz_table{
    public function __construct() {
        $this->_table = 'guiigo_applet_user';
        $this->_pk = 'u_id';
        parent::__construct();
    }

    public function get_guiigo_applet_user_count($where = null){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
		if($where['u_uid']){     
            $sql .=" AND u_uid=%d ";
            $condition[] = $where['u_uid'];
        }
		if($where['u_dateline']){
            $sql .=" AND u_dateline=%d ";
            $condition[] = $where['u_dateline'];
        }
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }

	public function get_guiigo_applet_user_list($start,$size,$where = null){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['u_uid']){     
            $sql .=" AND u_uid=%d ";
            $condition[] = $where['u_uid'];
        }
		if($where['u_dateline']){
            $sql .=" AND u_dateline=%d ";
            $condition[] = $where['u_dateline'];
        }
		$sql .= " ORDER BY u_dateline DESC LIMIT %d,%d ";
		$condition[] = $start;
		$condition[] = $size;
		return DB::fetch_all($sql,$condition);
	}

    public function insert($data){
        return DB::insert($this->_table,$data,true);
    }
	
    public function update($data,$condition){
        return DB::update($this->_table,$data,$condition,true);
    }
	
    public function delete($condition){
        return DB::delete($this->_table, $condition);
    }

	public function get_guiigo_applet_user_first($where){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['u_id']){     
            $sql .=" AND u_id=%d ";
            $condition[] = $where['u_id'];
        }
		if($where['u_uid']){     
            $sql .=" AND u_uid=%d ";
            $condition[] = $where['u_uid'];
        }
		if($where['u_openid']){
            $sql .=" AND u_openid=%s ";
            $condition[] = $where['u_openid'];
        }
		if($where['u_unionid']){
            $sql .=" AND u_unionid=%s ";
            $condition[] = $where['u_unionid'];
        }
		if($where['u_session_key']){
            $sql .=" AND u_session_key=%s ";
            $condition[] = $where['u_session_key'];
        }
		if($where['u_dateline']){
            $sql .=" AND u_dateline=%d ";
            $condition[] = $where['u_dateline'];
        }
		return DB::fetch_first($sql,$condition);
	}
}
//di'.'sm.t'.'aoba'.'o.com
?>