<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include_once libfile('class/guiigoapplet','plugin/guiigo_applet');
$config = GuiigoApplet::config();

if (submitcheck('delsubmit')){
	
	if (empty($_POST['delete'])){
		cpmsg( lang('plugin/guiigo_applet', 'langs042'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_applet&pmod=adminuserlog', 'error');
	}else{
		foreach ($_POST['delete'] as $del){
			C::t('#guiigo_applet#guiigo_applet_user')->delete(array('u_id' => $del));
		}
		cpmsg( lang('plugin/guiigo_applet', 'langs043'),'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_applet&pmod=adminuserlog', 'succeed');
	}
	
}else{
	$perpage = 20;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage-1)*$perpage;

	$uid = dintval($_GET['uid']);
	$where = array();
	if($uid){
		$where['u_uid'] = $uid;
	}

	$count = C::t('#guiigo_applet#guiigo_applet_user')->get_guiigo_applet_user_count($where);
	$mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=guiigo_applet&pmod=adminuserlog&uid=".$uid;
	$multipage = multi($count, $perpage,$curpage,$mpurl, 0, 5);
	$log_list = C::t('#guiigo_applet#guiigo_applet_user')->get_guiigo_applet_user_list($start,$perpage,$where);

	$bnt = lang('plugin/guiigo_applet', 'langs027');
	$uidtext = lang('plugin/guiigo_applet', 'langs028');
echo <<<SEARCH
        <script src="static/js/calendar.js" type="text/javascript"></script>
		<form method="post" autocomplete="off" id="tb_search" action="$mpurl">
		<table style="padding:10px 0;">
			<tbody>
			<tr>
			<th>
                <td>&nbsp;&nbsp;&nbsp;$uidtext</td><td>&nbsp;<td><input type="text" name="uid" value="" style="width:80px;"></td>
				<td>&nbsp;&nbsp;&nbsp;<input type="submit" class="btn" value="$bnt"></td>
			</th>
			</tr>
			</tbody>
		</table>
		</form>
SEARCH;

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=guiigo_applet&pmod=adminuserlog','enctype');
	showtableheader(lang('plugin/guiigo_applet', 'langs029'));
		showsubtitle(array(
		   lang('plugin/guiigo_applet', 'langs039'),
		    'ID',
            'UID',
            lang('plugin/guiigo_applet', 'langs032'),
            lang('plugin/guiigo_applet', 'langs033'),
            lang('plugin/guiigo_applet', 'langs034'),
            lang('plugin/guiigo_applet', 'langs035'),
            lang('plugin/guiigo_applet', 'langs036'),
            lang('plugin/guiigo_applet', 'langs037'),
			'openid',
			'unionid',
			lang('plugin/guiigo_applet', 'langs038'),
		));
		foreach ($log_list as $k => $v) {
			$name = getuserbyuid($v['u_uid']);
			if($v['u_sex'] == 1){
				$sex = lang('plugin/guiigo_applet', 'langs030');
			}else if($v['u_sex'] == 2){
				$sex = lang('plugin/guiigo_applet', 'langs031');
			}else{
				$sex = '--';
			}
			showtablerow('',array('class="td25"'), array(
			   '<input class="checkbox" type="checkbox" name="delete['.$v['u_id'].']" value="' .$v['u_id'].'">',
			    $v['u_id'],
				$v['u_uid'],
				'<a href="home.php?mod=space&uid='.$v['u_uid'].'" target="_black">'.$name['username'].'</a>',
                $v['u_username'],
				$v['u_openid'] ? '<img src="'.avatar($v['u_uid'], 'small', true).'" class="vm" width="35px;" height="35px;"/>' : '--',
                $sex,
				$v['u_city'],
				$v['u_province'],
				$v['u_openid'] ? $v['u_openid'] : '--',
				$v['u_unionid'] ? $v['u_unionid'] : '--',
				dgmdate($v['u_dateline'],'Y-m-d H:i:s')
			));
		}
		showsubmit('delsubmit', lang('plugin/guiigo_applet', 'langs040'), '<label><input type="checkbox" name="chkall" class="checkbox" onclick="checkall(this.form,\'delete\')" />', lang('plugin/guiigo_applet', 'langs041'),' </label>','', $multipage,'');
	showtablefooter();/*Dism��taobao��com*/
showformfooter();/*Dism_taobao_com*/
}
//di'.'sm.t'.'aoba'.'o.com
?>