<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$msgarr = array();
$msgarr['code'] = 1000;
$msgarr['data'] = array();
$msgarr['msg'] = lang('plugin/guiigo_upavatar', 'langs004');

include_once libfile('class/UpAvatar','plugin/guiigo_upavatar');
$config = UpAvatar::config();

if(!$_G['uid']){
	if($_GET['inajax']){
		$msgarr['code'] = 1001;
		$msgarr['msg'] = lang('plugin/guiigo_upavatar', 'langs001');
		UpAvatar::RetMsgJson($msgarr);
	}else {
		showmessage(lang('plugin/guiigo_upavatar', 'langs001'), 'member.php?mod=logging&action=login&referer='.urlencode($_G['siteurl'].'plugin.php?id=guiigo_upavatar'),'error');
	}
}

if($_GET['act'] == 'upavatar' && $_GET['inajax']){

	if(empty($_GET['imgdata'])){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_upavatar', 'langs005');
		UpAvatar::RetMsgJson($msgarr);
	}
	$isok = UpAvatar::syncavatar($_G['uid'], daddslashes($_GET['imgdata']));
    if($isok){
		$msgarr['code'] = 1;
		$msgarr['msg'] = lang('plugin/guiigo_upavatar', 'langs002');
	}else{
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_upavatar', 'langs003');
	}
	UpAvatar::RetMsgJson($msgarr);

}else {

	include template('guiigo_upavatar:upavatar');
}
//di'.'sm.t'.'aoba'.'o.com
?>