<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class UpAvatar {

	public static function config(){
		global $_G;
		if(empty($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		$config = $_G['cache']['plugin']['guiigo_upavatar'];
		return $config;
	}
	
	public static function RetMsgJson($arr,$isecho=true){
		if(strtolower(CHARSET) == 'gbk'){
		    $arr = self::iconvArrayA($arr);
		}
		if($isecho){
			echo json_encode($arr);exit();
		}else{
			return json_encode($arr);
		}
	}

	public static function iconvArrayA($data, $in_charset = 'gbk', $out_charset = 'utf-8'){
		if (is_array($data)) {
			foreach ($data as $key => $val){
				$dataA[$key] = self::iconvArrayA($val, $in_charset, $out_charset);
			}
			return $dataA;
		}else {
			return iconv($in_charset, $out_charset, $data);
		}
	}
	
    public static function get_bass64_array($data_str){
        if(empty($data_str)){
            return '';
        }
        $base_array = explode(',', $data_str);
        $base_file = $base_array[1];
        $base_file_type = self::get_between($base_array[0], "/", ";");
        $return_data = array(
            "flie_type" => $base_file_type,
            'file_name' => $base_file
        );
        return $return_data;
    }

    public static function get_between($input, $start, $end) {
        $substr = substr($input, strlen($start)+strpos($input, $start),(strlen($input) - strpos($input, $end))*(-1));
        return $substr;
    }

	public static function syncavatar($uid, $avatar){
		if(!$uid || !$avatar){
			return false;
		}
        $result_base64 = self::get_bass64_array($avatar);

        $upload_img = base64_decode($result_base64['file_name']);

		$tmpFile = DISCUZ_ROOT.'./source/plugin/guiigo_upavatar/cache/'.TIMESTAMP.random(6);
		$upload_result = file_put_contents($tmpFile, $upload_img);
	  
        if(empty($upload_result) || $upload_result =='0'){
           @unlink($tmpFile);
           return false;
        }

		if(!is_file($tmpFile)){
			return false;
		}
		$result = self::uploadUcAvatar($uid, $tmpFile);
		@unlink($tmpFile);
		C::t('common_member')->update($uid, array('avatarstatus' => 1));
		return $result;
	}

	public static function uploadUcAvatar($uid, $localFile){
		global $_G;
		if(!$uid || !$localFile){
			return false;
		}
	  
		list($width, $height, $type, $attr) = getimagesize($localFile);

		if (!$width) {
			return false;
		}

		if ($width < 10 || $height < 10 || $type == 4) {
			return false;
		}

		$imageType = array(
			1 => '.gif',
			2 => '.jpg',
			3 => '.png'
		);

		$fileType = $imgType[$type];
		if(!$fileType){
			$fileType = '.jpg';
		}
		$avatarPath = $_G['setting']['attachdir'];
		$tmpAvatar  = $avatarPath.'./temp/upload'.$uid.$fileType;
		file_exists($tmpAvatar) && @unlink($tmpAvatar);
		
		file_put_contents($tmpAvatar, file_get_contents($localFile));
		
		if(!is_file($tmpAvatar)){
			return false;
		}

		$tmpAvatarBig = './temp/upload'.$uid.'big'.$fileType;
		$tmpAvatarMiddle = './temp/upload'.$uid.'middle'.$fileType;
		$tmpAvatarSmall  = './temp/upload'.$uid.'small'.$fileType;

		$image = new image;
		if($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0){
			return false;
		}
		if($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0){
			return false;
		}
		if($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0){
			return false;
		}
	 
		$tmpAvatarBig    = $avatarPath . $tmpAvatarBig;
		$tmpAvatarMiddle = $avatarPath . $tmpAvatarMiddle;
		$tmpAvatarSmall  = $avatarPath . $tmpAvatarSmall;
		$avatar1         = self::byte2hex(file_get_contents($tmpAvatarBig));
		$avatar2         = self::byte2hex(file_get_contents($tmpAvatarMiddle));
		$avatar3         = self::byte2hex(file_get_contents($tmpAvatarSmall));

		$extra = '&avatar1='.$avatar1.'&avatar2='.$avatar2.'&avatar3='.$avatar3;
		$result = self::uc_api_post_ex('user', 'rectavatar', array('uid' => $uid),$extra);

		@unlink($tmpAvatar);
		@unlink($tmpAvatarBig);
		@unlink($tmpAvatarMiddle);
		@unlink($tmpAvatarSmall);
		return true;
	}

	public static function byte2hex($string){
		$buffer = '';
		$value  = unpack('H*', $string);
		$value  = str_split($value[1], 2);
		$b      = '';
		foreach ($value as $k => $v) {
			$b .= strtoupper($v);
		}
		return $b;
	}

	public static function uc_api_post_ex($module, $action, $arg=array(), $extra=''){
		if(!function_exists('uc_api_requestdata')) {
			loaducenter(); /*dis'.'m.t'.'ao'.'bao.com*/
		}
		$s = $sep = '';
		foreach($arg as $k => $v){
			$k = urlencode($k);
			if(is_array($v)){
				$s2 = $sep2 = '';
				foreach($v as $k2 => $v2){
					$k2 = urlencode($k2);
					$s2 .= "$sep2{$k}[$k2]=".urlencode(uc_stripslashes($v2));
					$sep2 = '&';
				}
				$s .= $sep.$s2;
			} else {
				$s .= "$sep$k=".urlencode(uc_stripslashes($v));
			}
			$sep = '&';
		}
		$postdata = uc_api_requestdata($module, $action, $s, $extra);
		return uc_fopen2(UC_API.'/index.php', 500000, $postdata, '', true, UC_IP, 20);
	}
}
//di'.'sm.t'.'aoba'.'o.com
?>