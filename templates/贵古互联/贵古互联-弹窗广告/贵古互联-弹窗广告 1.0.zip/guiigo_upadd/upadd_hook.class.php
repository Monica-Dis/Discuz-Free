<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once libfile('class/Upadd','plugin/guiigo_upadd');

class plugin_guiigo_upadd {

	function global_footer(){
		global $_G;
        $config = Upadd::config();
        $groups = dunserialize($config['open_groups']);
		$_adarr = Upadd::guiigo_writetocache();
		$datajson = array();
		foreach ($_adarr as $k => $v) {
			if(in_array($_G['groupid'],$groups) && $v['mod'] == CURSCRIPT){
                $data = $v;
                $datajson = json_encode($v);
				include template('guiigo_upadd:adjs');
				return $adjs;
			}
		}
	}
}

class mobileplugin_guiigo_upadd extends plugin_guiigo_upadd {

	function global_footer_mobile(){
		global $_G;
        $config = Upadd::config();
        $groups = dunserialize($config['open_groups']);
		$_adarr = Upadd::guiigo_writetocache();
		$datajson = array();
		foreach ($_adarr as $k => $v) {
			if(in_array($_G['groupid'],$groups) && $v['mod'] == CURSCRIPT){
                $data = $v;
				$datajson = json_encode($v);
				include template('guiigo_upadd:adjs');
				return $adjs;
			}
		}
	}
}