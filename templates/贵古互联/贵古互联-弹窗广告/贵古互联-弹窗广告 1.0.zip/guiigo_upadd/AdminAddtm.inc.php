<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include_once libfile('class/Upadd','plugin/guiigo_upadd');
$config = Upadd::config();

if (submitcheck('submit')) {
	$adres = daddslashes($_GET);
	$adarr = array();
	foreach ($adres['mod'] as $k => $v) {
		if(in_array($k, $adres['delete'])) {
			continue;
		}
		$adarr[$k]['mod'] = $adres['mod'][$k];
		$adarr[$k]['adimg'] = $adres['adimg'][$k];
		$adarr[$k]['adurl'] = $adres['adurl'][$k];
		$adarr[$k]['ytime'] = $adres['ytime'][$k];
		$adarr[$k]['ctime'] = $adres['ctime'][$k];
		$adarr[$k]['jtime'] = $adres['jtime'][$k];
	}
	if(!$adarr){
		$adarr = true;
	}
	Upadd::guiigo_writetocache($adarr);
	cpmsg(lang('plugin/guiigo_upadd', 'lang_s001'),dreferer(), 'success');
}

$dataarr = array();
$dataarr[] = array('portal', lang('plugin/guiigo_upadd', 'lang_s012'));
$dataarr[] = array('forum', lang('plugin/guiigo_upadd', 'lang_s013'));
$dataarr[] = array('home', lang('plugin/guiigo_upadd', 'lang_s014'));
$dataarrs = Upadd::get_select('mod[]', $dataarr, '', array(0, lang('plugin/guiigo_upadd', 'lang_s002')));

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=guiigo_upadd&pmod=AdminAddtm','enctype');
showtableheader(lang('plugin/guiigo_upadd', 'lang_s003'));
	showsubtitle(array(
	    lang('plugin/guiigo_upadd', 'lang_s004'),
	    lang('plugin/guiigo_upadd', 'lang_s005'),
	    lang('plugin/guiigo_upadd', 'lang_s006'),
	    lang('plugin/guiigo_upadd', 'lang_s007'),
	    lang('plugin/guiigo_upadd', 'lang_s008'),
	    lang('plugin/guiigo_upadd', 'lang_s009'),
	    lang('plugin/guiigo_upadd', 'lang_s010'),
	));

    $_adarr = Upadd::guiigo_writetocache();
	foreach ($_adarr as $key => $value) {
		$_dataarrs = Upadd::get_select('mod['.$key.']', $dataarr, $value['mod'], array(0, lang('plugin/guiigo_upadd', 'lang_s002')));
		showtablerow('', array('class="td25"'), array(
		            '<input type="checkbox" class="txt" name="delete['.$key.']" value="'.$key.'" />',
					$_dataarrs,
					'<input type="text" class="txt" name="adimg['.$key.']" value="'.$value['adimg'].'" style="width:200px;"/>',
					'<input type="text" class="txt" name="adurl['.$key.']" value="'.$value['adurl'].'" style="width:200px;"/>',
					'<input type="text" class="txt" name="ytime['.$key.']" value="'.$value['ytime'].'" />',
					'<input type="text" class="txt" name="ctime['.$key.']" value="'.$value['ctime'].'" />',
					'<input type="text" class="txt" name="jtime['.$key.']" value="'.$value['jtime'].'" />',
				));
	}

echo '<tr><td colspan="1"></td><td><div><a href="javascript:;" onclick="addrow(this, 0);" class="addtr">'.lang('plugin/guiigo_upadd', 'lang_s015').'</a></div></td></tr>';
echo <<<EOT
	<script type="text/JavaScript">
		var rowtypedata = [
			[
				[1,'<input type="checkbox" class="txt" name="delete[]" value="">', 'td25'],
				[1,'{$dataarrs}',''],
			    [1,'<input type="text" class="txt" name="adimg[]" value="" style="width:200px;"/>', ''],
				[1,'<input type="text" class="txt" name="adurl[]" value="" style="width:200px;"/>', ''],
				[1,'<input type="text" class="txt" name="ytime[]" value="" />', ''],
				[1,'<input type="text" class="txt" name="ctime[]" value="" />', ''],
				[1,'<input type="text" class="txt" name="jtime[]" value="" />', ''],

			]
		];
	</script>
EOT;
	showsubmit('submit',lang('plugin/guiigo_upadd', 'lang_s011'));
showtablefooter();/*Dism��taobao��com*/
showformfooter();/*Dism_taobao_com*/
?>