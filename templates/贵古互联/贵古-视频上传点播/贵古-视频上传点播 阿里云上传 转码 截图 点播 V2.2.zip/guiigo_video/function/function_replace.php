<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!class_exists('GuiigoVideo')){
	include_once libfile('class/guiigovideo','plugin/guiigo_video');
}

function guiigoVideoOutput_callback_replace($matches){
	if(!$matches[1]){
		return '';
	}
	$vdata = DB::fetch_first('select v_tid,v_videoid,v_videourl,v_videocover,v_authentication  from %t where v_videoid=%s', array('guiigo_video_videolog',$matches[1]));
	if(!$vdata['v_videourl']){
		return '';
	}
	$param = GuiigoVideo::getPlayerParam($vdata);
	if(!$param['playerid']){
		return '';
	}
	return GuiigoVideo::playerTpl($param);
}

function vpostlist_replace($postlist,$limit=10){
	$tid = $postlist['tid'];
	$pid = $postlist['pid'];
	$fid = $postlist['fid'];
	
	$postlist['PlayerParam'] = false;
	if($postlist['message'] && strexists($postlist['message'],'[/guiigo_video]') !== FALSE){
		$Tpl = preg_replace_callback("/\[guiigo_video\]\s*([^\[\<\r\n]+?)\s*\[\/guiigo_video\]/", 'guiigoVideoOutput_callback_replace', $postlist['message']);
		$postlist['message'] = $Tpl;
		$postlist['PlayerParam'] = $Tpl;
		return $postlist;
	}
	if(!$tid || !$pid || !$fid){
		return $postlist;
	}
	$_vdata = DB::fetch_all(
	'select v_tid,v_videoid,v_videourl,v_videocover,v_authentication from %t where v_fid=%d AND v_tid=%d AND v_pid=%d '.DB::limit(0,$limit), 
		array(
			'guiigo_video_videolog',
			$fid,
			$tid,
			$pid
		)
	);
	$playerTpl = '';
	foreach($_vdata as $v => $vdata){
		$param = GuiigoVideo::getPlayerParam($vdata);
		if(!$param['playerid']){
			continue;
		}
		$playerTpl .= GuiigoVideo::playerTpl($param);
	}

	$postlist['message'] = $playerTpl.$postlist['message'];
	$postlist['PlayerParam'] = $playerTpl;
	return $postlist;
}