<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!class_exists('GuiigoVideo')) {
	include_once libfile('class/guiigovideo', 'plugin/guiigo_video');
}
class plugin_guiigo_video
{
	public function global_header()
	{
		global $_G;
		GuiigoVideo::verifyKey();/*dism . taobao . com*/
		$config = GuiigoVideo::config();
		include template('guiigo_video:playerheaderjs');
		return $playerheaderjs;
	}
	public static function AddPost($p)
	{
		global $_G;
		$config = GuiigoVideo::config();
		if (($p['param'][0] == 'post_reply_succeed' || $p['param'][0] == 'post_newthread_succeed') && in_array($_G['fid'], dunserialize($config['video_openform'])) && in_array($_G['groupid'], dunserialize($config['video_opengid']))) {
			$video_upstate = array(1);
			$data = array('v_type' => 1, 'v_uid' => $_G['uid'], 'v_fid' => $p['param'][2]['fid'], 'v_tid' => $p['param'][2]['tid'], 'v_pid' => $p['param'][2]['pid'], 'v_authentication' => $config['video_aliyun_URLauthentication'] ? 1 : 0, 'v_dateline' => TIMESTAMP);
			if ($_POST['guiigo_videoid'] && is_array($_POST['guiigo_videoid'])) {
				foreach ($_POST['guiigo_videoid'] as $val) {
					$v_id = DB::result_first('select v_id from %t where v_videoid=%s', array('guiigo_video_videolog', $val));
					if ($v_id) {
						C::t('#guiigo_video#guiigo_video_videolog')->update($data, array('v_id' => $v_id));
						GuiigoVideo::Op_video_upstate($val, 1);
					} else {
						$data['v_video_upstate'] = serialize($video_upstate);
						$data['v_videoid'] = $val;
						C::t('#guiigo_video#guiigo_video_videolog')->insert($data);
					}
				}
			}
		}
	}
}
class plugin_guiigo_video_forum extends plugin_guiigo_video
{
	public function post_editorctrl_left()
	{
		global $_G;
		$config = GuiigoVideo::config();
		if (in_array($_G['fid'], dunserialize($config['video_openform'])) && in_array($_G['groupid'], dunserialize($config['video_opengid']))) {
			return '<a href="javasrcipt:;" id="e_guiigo_video">' . lang('plugin/guiigo_video', 'langs012') . '</a>';
		}
	}
	public function post_middle_output()
	{
		global $_G;
		$config = GuiigoVideo::config();
		if (in_array($_G['fid'], dunserialize($config['video_openform'])) && in_array($_G['groupid'], dunserialize($config['video_opengid']))) {
			include template('guiigo_video:upvideo');
			return $upvideo;
		}
	}
	public function post_guiigo_video_reply_message($p)
	{
		self::AddPost($p);
	}
	public function forumdisplay_output()
	{
		global $_G;
		$tids = array();
		$config = GuiigoVideo::config();
		if (!$config['video_aliyun_postlist']) {
			return array();
		}
		foreach ($_G['forum_threadlist'] as $v) {
			$tids[] = $v['tid'];
		}
		if (!$tids) {
			return array();
		}
		$resultlist = GuiigoVideo::_getpostlist($tids);
		if (!$resultlist) {
			return array();
		}
		foreach ($_G['forum_threadlist'] as $k => $val) {
			$vtlp = GuiigoVideo::postlist_replace($resultlist[$val['tid']], 1);
			if ($vtlp['PlayerParam']) {
				$_G['setting']['pluginhooks']['forumdisplay_thread'][$k] = $vtlp['PlayerParam'];
			}
		}
		return array();
	}
	public function viewthread_postbottom_output()
	{
		global $postlist;
		foreach ($postlist as $key => $val) {
			$postlist[$key] = GuiigoVideo::postlist_replace($val);
		}
		return array();
	}
}
class mobileplugin_guiigo_video extends plugin_guiigo_video
{
	public function global_header_mobile()
	{
		return parent::global_header();
	}
}
class mobileplugin_guiigo_video_forum extends mobileplugin_guiigo_video
{
	public function post_bottom_mobile()
	{
		global $_G;
		$config = GuiigoVideo::config();
		if (in_array($_G['fid'], dunserialize($config['video_openform'])) && in_array($_G['groupid'], dunserialize($config['video_opengid'])) && !in_array('guiigo_manage', $_G['setting']['plugins']['available'])) {
			include template('guiigo_video:upvideo');
			return $upvideo;
		}
	}
	public function post_guiigo_video_bottom_mobile()
	{
		global $_G;
		$config = GuiigoVideo::config();
		if (in_array($_G['fid'], dunserialize($config['video_openform'])) && in_array($_G['groupid'], dunserialize($config['video_opengid'])) && in_array('guiigo_manage', $_G['setting']['plugins']['available'])) {
			include template('guiigo_video:upvideo');
			return $upvideo;
		}
	}
	public function post_guiigo_video_reply_message($p)
	{
		self::AddPost($p);
	}
	public function forumdisplay_mobile_output()
	{
		global $_G;
		$tids = array();
		$config = GuiigoVideo::config();
		if (!$config['video_aliyun_postlist']) {
			return array();
		}
		foreach ($_G['forum_threadlist'] as $v) {
			$tids[] = $v['tid'];
		}
		if (!$tids) {
			return array();
		}
		$resultlist = GuiigoVideo::_getpostlist($tids);
		if (!$resultlist) {
			return array();
		}
		foreach ($_G['forum_threadlist'] as $k => $val) {
			$vtlp = GuiigoVideo::postlist_replace($resultlist[$val['tid']], 1);
			if ($vtlp['PlayerParam']) {
				$_G['setting']['pluginhooks']['forumdisplay_thread_mobile'][$k] = $vtlp['PlayerParam'];
			}
		}
		return array();
	}
	public function viewthread_postbottom_mobile_output()
	{
		global $postlist;
		foreach ($postlist as $key => $val) {
			$postlist[$key] = GuiigoVideo::postlist_replace($val);
		}
		return array();
	}
}