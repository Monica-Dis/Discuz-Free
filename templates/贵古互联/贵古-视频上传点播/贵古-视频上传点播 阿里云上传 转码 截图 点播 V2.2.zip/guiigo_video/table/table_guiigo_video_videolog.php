<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_guiigo_video_videolog extends discuz_table{
    public function __construct() {
        $this->_table = 'guiigo_video_videolog';
        $this->_pk = 'v_id';
        parent::__construct(); /*Dism_taobao_com*/
    }

    public function get_guiigo_video_videolog_count($where = null){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
		if($where['v_uid']){     
            $sql .=" AND v_uid=%d ";
            $condition[] = $where['v_uid'];
        }
		if($where['v_fid']){
		    $sql .=" AND v_fid=%d ";
		    $condition[] = $where['v_fid'];
		}
		if($where['v_dateline']){
            $sql .=" AND v_dateline=%d ";
            $condition[] = $where['v_dateline'];
        }
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }

	public function get_guiigo_video_videolog_list($start,$size,$where = null){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['v_uid']){     
            $sql .=" AND v_uid=%d ";
            $condition[] = $where['v_uid'];
        }
		if($where['v_fid']){
		    $sql .=" AND v_fid=%d ";
		    $condition[] = $where['v_fid'];
		}
		if($where['v_dateline']){
            $sql .=" AND v_dateline=%d ";
            $condition[] = $where['v_dateline'];
        }
		$sql .= " ORDER BY v_dateline DESC LIMIT %d,%d ";
		$condition[] = $start;
		$condition[] = $size;
		return DB::fetch_all($sql,$condition);
	}

    public function insert($data){
        return DB::insert($this->_table,$data,true);
    }
	
    public function update($data,$condition){
        return DB::update($this->_table,$data,$condition,true);
    }
	
    public function delete($condition){
        return DB::delete($this->_table, $condition);
    }

	public function get_guiigo_video_videolog_first($where){
		$sql = "SELECT * FROM %t WHERE 1";
		$condition[] = $this->_table;
		if($where['v_id']){     
            $sql .=" AND v_id=%d ";
            $condition[] = $where['v_id'];
        }
		if($where['v_uid']){     
            $sql .=" AND v_uid=%d ";
            $condition[] = $where['v_uid'];
        }
		if($where['v_uid']){     
            $sql .=" AND v_uid=%d ";
            $condition[] = $where['v_uid'];
        }
		if($where['v_fid']){
		    $sql .=" AND v_fid=%d ";
		    $condition[] = $where['v_fid'];
		}
		if($where['v_tid']){     
            $sql .=" AND v_tid=%d ";
            $condition[] = $where['v_tid'];
        }
		if($where['v_pid']){     
            $sql .=" AND v_pid=%d ";
            $condition[] = $where['v_pid'];
        }
		if($where['v_videoid']){     
            $sql .=" AND v_videoid=%s ";
            $condition[] = $where['v_videoid'];
        }
		if(isset($where['v_authentication'])){
			$sql .=" AND v_authentication=%d ";
			$condition[] = $where['v_authentication'];
		}
		if($where['v_dateline']){
            $sql .=" AND v_dateline=%d ";
            $condition[] = $where['v_dateline'];
        }
		return DB::fetch_first($sql,$condition);
	}
}
//From: Dism��taobao��com
?>