<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!class_exists('videoRequest')){
	@include_once DISCUZ_ROOT.'./source/plugin/guiigo_video/lib/aliyun/video_request.php';}
$videoObj = new videoRequest($config['video_aliyun_accseekeyid'],$config['video_aliyun_accseekeyidsecret']);

if($_GET['act'] == 'getUploadVideo'){

	$FileName = daddslashes($_POST['FileName']);
	$FileSize = daddslashes($_POST['FileSize']);

	if(!checkmobile()){
		$FileName = diconv(urldecode($FileName), 'utf-8', CHARSET);
	}
	
	$FileName = trim($FileName);
	$FileName = dhtmlspecialchars($FileName);
	
	if(!$FileName){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_video', 'langs014');
		GuiigoVideo::RetMsgJson($msgarr);
	}

	$FileExt = strtoupper(substr(strrchr($FileName, '.'), 1, 10));
	$videoext  = array('MP4', 'TS', '3GP', 'MPG', 'MPEG','DAT','VOB','ASF','MOV');
	if(!in_array($FileExt, $videoext)){
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_video', 'langs015');
		GuiigoVideo::RetMsgJson($msgarr);
	}
	
	$Title = str_replace(array('.'.strtolower($FileExt),'.'.$FileExt),array('',''),$FileName);
	if(strlen($Title) > 90) {
		$Title = cutstr($Title, 80, '');
	}

	$par = array(
		'Title'=> GuiigoVideo::diconv_gTu8($Title),
		'FileName'=> GuiigoVideo::diconv_gTu8($FileName),
		'FileSize'=> $FileSize,
		'CateId'=> $config['video_aliyun_typeid'],
		'AppId'=> $config['video_aliyun_AppId'],
		'WorkflowId'=> $config['video_aliyun_WorkflowId'],
		'TemplateGroupId'=> $config['video_aliyun_TemplateGroupId'],
		'StorageLocation'=> $config['video_aliyun_StorageLocation'],
	);

	$r = json_decode($videoObj->getCreateUploadVideo($par), true);
    if(is_array($r)){
		$msgarr['code'] = 1;
		$msgarr['data'] = $r;
		$msgarr['msg'] = 'ok';
	}else{
		$msgarr['code'] = -3;
		$msgarr['msg'] = lang('plugin/guiigo_video', 'langs016');
	}
	GuiigoVideo::RetMsgJson($msgarr);
	
}else if($_GET['act'] == 'RefreshUploadVideo'){

    $VideoId = daddslashes($_POST['VideoId']);
	if(!$VideoId){
		$msgarr['code'] = -1;
		$msgarr['msg'] = lang('plugin/guiigo_video', 'langs017');
		GuiigoVideo::RetMsgJson($msgarr);
	}
	$par = array(
		'VideoId'=>$VideoId
	);
    $r = json_decode($videoObj->getRefreshUploadVideo($par), true);
	if(is_array($r)){
		$msgarr['code'] = 1;
		$msgarr['data'] = $r;
		$msgarr['msg'] = 'ok';
	}else{
		$msgarr['code'] = -2;
		$msgarr['msg'] = lang('plugin/guiigo_video', 'langs018');
	}
	GuiigoVideo::RetMsgJson($msgarr);
}
