<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if($_GET['act'] == 'upvideo'){
	if(!class_exists('GuiigoVideo')){
		include_once libfile('class/guiigovideo','plugin/guiigo_video');
	}

	GuiigoVideo::post($_G['siteurl'].'source/plugin/guiigo_video/videoevent.php',array('EventType'=>'FileUploadComplete','VideoId'=>daddslashes($_GET['videoid'])));

	cpmsg(lang('plugin/guiigo_video', 'langs022'),'action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_video&pmod=admin_video_log', 'succeed');
	
}else{
	$perpage = 20;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage-1)*$perpage;
	$count = C::t('#guiigo_video#guiigo_video_videolog')->get_guiigo_video_videolog_count();
	$mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=guiigo_video&pmod=admin_video_log";
	$multipage = multi($count, $perpage,$curpage,$mpurl, 0, 5);
	$paylist = C::t('#guiigo_video#guiigo_video_videolog')->get_guiigo_video_videolog_list($start,$perpage);
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=guiigo_video&pmod=admin_video_log','enctype');
	showtableheader(lang('plugin/guiigo_video', 'langs011'));
		showtablerow('class="header"',array('class="td25"'),array(
			'ID',
			lang('plugin/guiigo_video', 'langs001'),
			lang('plugin/guiigo_video', 'langs002'),
			lang('plugin/guiigo_video', 'langs003'),
			lang('plugin/guiigo_video', 'langs004'),
			lang('plugin/guiigo_video', 'langs005'),
			lang('plugin/guiigo_video', 'langs019')
		));
		foreach($paylist as $key => $val) {
			$user = getuserbyuid($val['v_uid']);
			$video_upstate = dunserialize($val['v_video_upstate']);
			$text ='';
			foreach($video_upstate as $v){
				if($v == 1){
					$text .=lang('plugin/guiigo_video', 'langs006').'->';
				}else if($v == 2){
					$text .=lang('plugin/guiigo_video', 'langs007').'->';
				}else if($v == 3){
					$text .=lang('plugin/guiigo_video', 'langs008').'->';
				}else if($v == 4){
					$text .=lang('plugin/guiigo_video', 'langs009').'->';
				}else if($v == 5){
					$text .=lang('plugin/guiigo_video', 'langs010');
				}
			}
			$state_cz = lang('plugin/guiigo_video', 'langs020');
			if(!$val['v_videourl']){
				$urls = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=guiigo_video&pmod=admin_video_log&act=upvideo&videoid='.$val['v_videoid'];
			    $state_cz = '<a href="'.$urls.'">'.lang('plugin/guiigo_video', 'langs021').'</a>';
			}
			showtablerow('', array('class="td25"'), array(
				$val['v_id'],
				'(ID:'.$val['v_uid'].')'.$user['username'],
				'<a href="forum.php?mod=viewthread&tid='.$val['v_tid'].'" target="_blank">'.lang('plugin/guiigo_video', 'langs002').'</a>',
				$val['v_videoid'],
				$text,
				dgmdate($val['v_dateline']),
				$state_cz
			));
		}
		echo '<tr><th colspan="15">'.$multipage.'</th></tr>';
	showtablefooter(); /*Dism_taobao-com*/
	showformfooter(); /*dism��taobao��com*/
}
