<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class GuiigoVideo
{
	public static function config()
	{
		global $_G;
		if (empty($_G['cache']['plugin'])) {
			loadcache('plugin');
		}
		$config = $_G['cache']['plugin']['guiigo_video'];
		return $config;
	}
	public static function post($url, $data = array())
	{
		if (!function_exists('curl_init')) {
			return '';
		}
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$data = curl_exec($ch);
		if (!$data) {
			error_log(curl_error($ch));
		}
		curl_close($ch);
		return $data;
	}
	public static function verifyKey($config = array())
	{
		global $_G;
		if (!$config) {
			$config = self::config();
		}
		$cache_name = 'guiigo_video_authorization_key';
		if (!function_exists('curl_version')) {
			exit('Please open curl extension');
		}
		loadcache($cache_name);
		$accredit_key = $_G['cache'][$cache_name];
				savecache($cache_name, $res['data']['key']);
				return true;
	}
	public static function GetTypeArr($str)
	{
		$tlparr = array();
		if (!$str) {
			return $tlparr;
		}
		$val = explode('|', $str);
		$tlparr['tlpId'] = $val[0];
		$tlparr['tlpText'] = $val[1];
		$tlparr['tlpSign'] = $val[2];
		return $tlparr;
	}
	public static function diconv_u8Tg($str)
	{
		if (strtolower(CHARSET) == 'gbk') {
			return self::iconvArrayA($str, 'utf-8', 'gbk');
		}
		return $str;
	}
	public static function diconv_gTu8($str)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$str = self::iconvArrayA($str);
		}
		return $str;
	}
	public static function RetMsgJson($arr, $isecho = true)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$arr = self::iconvArrayA($arr);
		}
		if ($isecho) {
			echo json_encode($arr);
			exit(0);
		} else {
			return json_encode($arr);
		}
	}
	public static function iconvArrayA($data, $in_charset = 'gbk', $out_charset = 'utf-8', $ForceTable = false)
	{
		if (is_array($data)) {
			foreach ($data as $key => $val) {
				$dataA[$key] = self::iconvArrayA($val, $in_charset, $out_charset, $ForceTable);
			}
			return $dataA;
		}
		return diconv($data, $in_charset, $out_charset, $ForceTable);
	}
	public static function Op_video_upstate($videoid, $val = null)
	{
		$video_upstate = DB::result_first('select v_video_upstate from %t where v_videoid=%s', array('guiigo_video_videolog', $videoid));
		$video_upstatearr = array();
		if ($video_upstate) {
			$video_upstatearr = dunserialize($video_upstate);
		}
		if ($val) {
			if (!in_array($val, $video_upstatearr)) {
				array_push($video_upstatearr, $val);
				return C::t('#guiigo_video#guiigo_video_videolog')->update(array('v_video_upstate' => serialize($video_upstatearr)), array('v_videoid' => $videoid));
			}
			return true;
		}
		return $video_upstatearr;
	}
	public static function getURLByvideoid($vdata)
	{
		global $_G;
		$config = self::config();
		$urlarr = array('videocover' => '', 'videourl' => '');
		$day = 1;
		$preview_time = 0;
		if ($config['video_aliyun_day']) {
			$day = $config['video_aliyun_day'];
		}
		if ($config['video_aliyun_preview_time'] && in_array($_G['groupid'], dunserialize($config['video_playgid']))) {
			$preview_time = $config['video_aliyun_preview_time'];
		}
		if ($vdata['v_authentication'] > 1) {
			$urlarr['videocover'] = $config['video_aliyun_domain'] . $vdata['v_videocover'];
			if (empty($vdata['v_videocover'])) {
				$urlarr['videocover'] = $config['video_aliyun_videocover'];
			}
			$urlarr['videourl'] = $config['video_aliyun_domain'] . $vdata['v_videourl'];
			return $urlarr;
		}
		$curl = '/' . $vdata['v_videocover'];
		$vurl = '/' . $vdata['v_videourl'];
		$timestamp = TIMESTAMP + 86400 * $day;
		$rand = 0;
		$uid = 0;
		$chash = $curl . '-' . $timestamp . '-' . $rand . '-' . $uid . '-' . $config['video_aliyun_URLkey'];
		$vhash = $vurl . '-' . $timestamp . '-' . $rand . '-' . $uid . '-' . $config['video_aliyun_URLkey'];
		if ($preview_time > 1) {
			$vhash = $vhash . '-' . $preview_time;
		}
		$urlarr['videourl'] = $config['video_aliyun_domain'] . $vdata['v_videourl'] . '?auth_key=' . $timestamp . '-' . $rand . '-' . $uid . '-' . md5($vhash);
		if ($preview_time > 1) {
			$urlarr['videourl'] = $urlarr['videourl'] . '&end=' . $preview_time;
		}
		$urlarr['videocover'] = $config['video_aliyun_domain'] . $vdata['v_videocover'] . '?auth_key=' . $timestamp . '-' . $rand . '-' . $uid . '-' . md5($chash);
		if (empty($vdata['v_videocover'])) {
			$urlarr['videocover'] = $config['video_aliyun_videocover'];
		}
		return $urlarr;
	}
	public static function getPlayerParam($vdata)
	{
		global $_G;
		$Param = array();
		$config = self::config();
		if (!$vdata['v_videourl'] || !$vdata['v_videoid']) {
			return $Param;
		}
		$vurlarr = self::getURLByvideoid(array('v_videourl' => $vdata['v_videourl'], 'v_videocover' => $vdata['v_videocover'], 'v_authentication' => $vdata['v_authentication']));
		if (!$vurlarr['videourl']) {
			return $Param;
		}
		$width = $config['video_aliyun_vpc_width'];
		$height = $config['video_aliyun_vpc_height'];
		$m_height = '450px';
		if (checkmobile()) {
			$width = $config['video_aliyun_vm_width'];
			$height = $config['video_aliyun_vm_height'];
			$m_height = '230px';
		}
		$param['id'] = 'player_' . $vdata['v_videoid'] . '_' . random(5);
		$param['source'] = $vurlarr['videourl'];
		$param['cover'] = $vurlarr['videocover'] ? $vurlarr['videocover'] : '';
		$param['width'] = $width ? $width : '100%';
		$param['height'] = $height ? $height : $m_height;
		$Startargs = NULL;
		$Pauseargs = NULL;
		if (in_array($_G['groupid'], dunserialize($config['video_playgid']))) {
			if ($config['video_aliyun_sb_p_src']) {
				$Startargs = array($config['video_aliyun_sb_p_src'], $config['video_aliyun_sb_p_url'] ? $config['video_aliyun_sb_p_url'] : '#', $config['video_aliyun_sb_p_time'] ? $config['video_aliyun_sb_p_time'] : 5);
			}
			if ($config['video_aliyun_sb_e_src']) {
				$Pauseargs = array($config['video_aliyun_sb_e_src'], $config['video_aliyun_sb_e_url']);
			}
		} else {
			if ($config['video_aliyun_ad_p_src']) {
				$Startargs = array($config['video_aliyun_ad_p_src'], $config['video_aliyun_ad_p_url'] ? $config['video_aliyun_ad_p_url'] : '#', $config['video_aliyun_ad_p_time'] ? $config['video_aliyun_ad_p_time'] : 5);
			}
			if ($config['video_aliyun_ad_e_src']) {
				$Pauseargs = array($config['video_aliyun_ad_e_src'], $config['video_aliyun_ad_e_url']);
			}
		}
		$StartADComponent = array('name' => 'StartADComponent', 'type' => 'AliPlayerComponent.StartADComponent', 'args' => $Startargs);
		$PauseADComponent = array('name' => 'PauseADComponent', 'type' => 'AliPlayerComponent.PauseADComponent', 'args' => $Pauseargs);
		if ($Pauseargs || $Startargs) {
			$param['components'] = array($StartADComponent, $PauseADComponent);
		}
		if (!checkmobile() && (CURMODULE == 'forumdisplay' || CURMODULE == 'guiigo_manage')) {
			$param['height'] = $config['video_aliyun_vpcl_height'] ? $config['video_aliyun_vpcl_height'] : '280px';
			$param['width'] = $config['video_aliyun_vpcl_width'] ? $config['video_aliyun_vpcl_width'] : '500px';
		}
		$param['v_tid'] = $vdata['v_tid'];
		return array('playerid' => $param['id'], 'data' => $param);
	}
	public static function playerTpl($param)
	{
		$config = self::config();
		$playerid = $param['playerid'];
		if ($config['video_aliyun_postlist_play'] || CURMODULE == 'viewthread') {
			$playerparam = array();
			if ($param['data']) {
				$playerparam = json_encode($param['data'], true);
			}
			include template('guiigo_video:player');
			return $player;
		}
		$cover = $param['data']['cover'];
		$height = $param['data']['height'];
		$width = $param['data']['width'];
		$url = 'forum.php?mod=viewthread&tid=' . $param['data']['v_tid'];
		include template('guiigo_video:playerlist');
		return $playerlist;
	}
	public static function _getpostlist($tids)
	{
		$result = DB::fetch_all('SELECT fid,pid,tid FROM %t WHERE first=1 AND tid IN (%n)', array('forum_post', (array) $tids), 'tid');
		$resultlist = array();
		foreach ($tids as $tv) {
			foreach ($result as $val) {
				if ($tv == $val['tid']) {
					$resultlist[$tv] = array('tid' => $val['tid'], 'pid' => $val['pid'], 'fid' => $val['fid']);
				}
			}
		}
		return $resultlist;
	}
	public static function postlist_replace($postlist, $limit = 10)
	{
		if (!function_exists('vpostlist_replace')) {
			include_once libfile('function/replace', 'plugin/guiigo_video');
		}
		return vpostlist_replace($postlist, $limit);
	}
	public static function upvideo_upstate($VideoId, $arr, $upstate)
	{
		$config = self::config();
		$v_id = DB::result_first('select v_id from %t where v_videoid=%s', array('guiigo_video_videolog', daddslashes($VideoId)));
		if ($v_id) {
			C::t('#guiigo_video#guiigo_video_videolog')->update($arr, array('v_id' => $v_id));
			self::Op_video_upstate($VideoId, $upstate);
		} else {
			$video_upstatearr = array(1, $upstate);
			$data = array('v_type' => 1, 'v_videoid' => daddslashes($VideoId), 'v_video_upstate' => serialize($video_upstate), 'v_authentication' => $config['video_aliyun_URLauthentication'] ? 1 : 0, 'v_dateline' => TIMESTAMP);
			array_push($data, $arr);
			C::t('#guiigo_video#guiigo_video_videolog')->insert($data);
		}
	}
}