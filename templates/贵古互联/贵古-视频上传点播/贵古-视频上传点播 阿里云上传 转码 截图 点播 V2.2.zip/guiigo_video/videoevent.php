<?php

define('IN_API', true);
define('CURSCRIPT', 'videoEvent');
define('DISABLEXSSCHECK', true);
require '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

if(!class_exists('GuiigoVideo')){
	include_once libfile('class/guiigovideo','plugin/guiigo_video');
}
$config = GuiigoVideo::config();
	
$post = array();
if($_POST){
	$post = $_POST;
	$action= '==$_POST==';
}else if(file_get_contents("php://input")){
	$post = file_get_contents("php://input");
	$action= '==file_get_contents==';
}

if(!is_array($post)){
	$post = json_decode($post, true);
}

if($post[0] && is_array($post[0])){
	foreach ($post as $val) {
	   asynchronizationVideo($val);
	}
}else{
	asynchronizationVideo($post);
}

function asynchronizationVideo($post){
	global $config;
	if($post['EventType'] == 'FileUploadComplete' && $post['VideoId']){
		if(!class_exists('videoRequest')){
			@include_once DISCUZ_ROOT.'./source/plugin/guiigo_video/lib/aliyun/video_request.php';		}
		$videoObj = new videoRequest($config['video_aliyun_accseekeyid'],$config['video_aliyun_accseekeyidsecret']);
		$par = array(
			'VideoId'=> $post['VideoId'],
			//'Formats'=>,//����Ƶ����ʽ
		);
		$r = json_decode($videoObj->GetPlayInfo($par), true);
		if($r['VideoBase'] && $r['VideoBase']['Status'] == 'Normal' && $r['VideoBase']['VideoId']){
			$arr = array();
			if($r['VideoBase']['CoverURL']){
				$arr['v_videocover'] = geturl($r['VideoBase']['CoverURL']);
			}
			if($r['PlayInfoList'] && $r['PlayInfoList']['PlayInfo']){
				$vInfo = $r['PlayInfoList']['PlayInfo'];
				$arr['v_videourl'] = geturl($vInfo[0]['PlayURL']);
				GuiigoVideo::upvideo_upstate($r['VideoBase']['VideoId'],$arr,2);
			}
		}
	}


	if($post['EventType'] == 'TranscodeComplete' && $post['Status'] == 'success' && $post['VideoId']){
	   if($post['StreamInfos'][0]){
		   $arr = array();
		   $arr['v_videourl'] = geturl($post['StreamInfos'][0]['FileUrl']);
		   GuiigoVideo::upvideo_upstate($post['VideoId'],$arr,3);
	   }
	}else if($post['EventType'] == 'TranscodeComplete' && $post['Status'] == 'fail'){
		Logs($post, $post['EventType']);
	}


	if($post['EventType'] == 'SnapshotComplete' && $post['CoverUrl'] && $post['VideoId']){
		$videocover = $post['CoverUrl'];
		if(strexists($videocover, $config['video_aliyun_domain']) !== FALSE){
			$videocover = str_replace($config['video_aliyun_domain'],'',$post['CoverUrl']);
		}

		$arr = array();
		$arr['v_videocover'] = $videocover;
		GuiigoVideo::upvideo_upstate($post['VideoId'],$arr,4);

	}else if($post['EventType'] == 'SnapshotComplete' && $post['Status'] == 'fail'){
		Logs($post, $post['EventType']);
	}

}

function Logs($str, $action=' '){
    $path = dirname(__FILE__);
    $time = date('Y-m-d h:i:s', time());
    $file = $path."/"."videologs.txt";
    $fp = fopen($file, "a+");
    if(is_array($str)) {
       $str = json_encode($str, JSON_FORCE_OBJECT);
	   $action .= '<===$str is_array===>';
    }
    $content = "";
    $start = "time:".$time."\r\n"."action:".$action."\r\n"."---------- content start ----------"."\r\n";
    $end = "\r\n"."---------- content end ----------"."\r\n\n";
    $content = $start."".$str."".$end;
    fwrite($fp, $content);
    fclose($fp);
}

function geturl($str){
	global $config;
	$newPlayURL = '';
	if($config['video_aliyun_domain']){
		$urls = parse_url($config['video_aliyun_domain']);
		if(strexists($str, $urls['host']) !== FALSE){
			$newPlayURL = str_replace(array('https://','http://',$urls['host']),array('','',''),$str);
		}else{
			$newPlayURL = $str;
		}
	}
	if(strexists($newPlayURL,'?auth_key=') !== FALSE){
		$newPlayURL = stristr($newPlayURL,'?auth_key=',true);
	}
	return $newPlayURL;
}
