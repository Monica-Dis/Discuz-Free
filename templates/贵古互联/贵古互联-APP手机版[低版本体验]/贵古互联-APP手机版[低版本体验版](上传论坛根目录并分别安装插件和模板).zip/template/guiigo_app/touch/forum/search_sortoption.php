<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<script type="text/javascript">
	var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
</script>
<script type="text/javascript" src="{$_G['setting']['jspath']}threadsort.js?{VERHASH}"></script>
<!--{loop $quicksearchlist $optionid $option}-->
		<!--{eval $formsearch = '';}-->
        <!--{if getstatus($option['search'], 1)}-->
        	<!--{block formsearch}-->
	            <div class="xxss-ssmk cl">
					<div class="ssmk-btys zy-e">$option[title]</div>
					<div class="ssmk-nrys zy-f xh-b">
					<!--{if in_array($option['type'], array('radio', 'checkbox', 'select', 'range'))}-->
						<span id="select_$option[identifier]">
						<!--{if $option[type] == 'select'}-->
							<!--{if $_GET[searchoption][$optionid][value]}-->
								<script type="text/javascript">
									changeselectthreadsort('$_GET[searchoption][$optionid][value]', $optionid, 'search');
								</script>
							<!--{else}-->
								<select name="searchoption[$optionid][value]" id="$option[identifier]" onchange="changeselectthreadsort(this.value, '$optionid', 'search');" class="guiigo-ps">
									<option value="0">{lang please_select}</option>
								<!--{loop $option['choices'] $id $value}-->
									<!--{if !$value[foptionid]}-->
									<option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
									<!--{/if}-->
								<!--{/loop}-->
								</select>
								<input type="hidden" name="searchoption[$optionid][type]" value="$option[type]">
							<!--{/if}-->
						<!--{elseif $option[type] != 'checkbox'}-->
							<select name="searchoption[$optionid][value]" id="$option[identifier]" class="guiigo-ps">
								<option value="0">{lang please_select}</option>
							<!--{loop $option['choices'] $id $value}-->
								<option value="$id" {if $_GET[searchoption][$optionid][value] == $id}selected="selected"{/if}>$value</option>
							<!--{/loop}-->
							</select>
							<input type="hidden" name="searchoption[$optionid][type]" value="$option[type]">
						<!--{else}-->
							<!--{loop $option['choices'] $id $value}-->
								<label class="guiigo-pd"><input type="checkbox" class="guiigo-pd-k" name="searchoption[$optionid][value][$id]" value="$id" {if is_array($_GET[searchoption][$optionid]) && $_GET[searchoption][$optionid][value][$id]}checked="checked"{/if}><span></span>$value</label>
							<!--{/loop}-->
							<input type="hidden" name="searchoption[$optionid][type]" value="checkbox">
						<!--{/if}-->
						</span>
					<!--{else}-->
						<!--{if $option['type'] == 'calendar'}-->
							<script type="text/javascript" src="{$_G[setting][jspath]}calendar.js?{VERHASH}"></script>
							<input type="text" name="searchoption[$optionid][value]" class="guiigo-px" value="{if is_array($_GET[searchoption][$optionid])}$_GET[searchoption][$optionid][value]{/if}" onclick="showcalendar(event, this, false)" />
						<!--{else}-->
							<input type="text" name="searchoption[$optionid][value]" class="guiigo-px" value="{if is_array($_GET[searchoption][$optionid])}$_GET[searchoption][$optionid][value]{/if}" />
						<!--{/if}-->
					<!--{/if}-->
					</div>
	            </div>
	            <!--{/block}-->
		<!--{/if}-->
    <!--{eval $formsearch_html .= $formsearch;}-->
	<!--{eval $fontsearch = '';$showoption = array();$tmpcount = 0;}-->
	<!--{if getstatus($option['search'], 2)}-->
    	<!--{block fontsearch}-->
			<div class="xxsc-scmk xh-b cl">
				<div class="scmk-mkbt zy-e">$option[title]</div>
				<div class="scmk-mknr list-block-no">
	                <ul class="cl">
	                    <li{if $_GET[''.$option[identifier]] == 'all'} class="a"{/if}><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET['sortid']&searchsort=1$filterurladd&$option[identifier]=all$sorturladdarray[$option[identifier]]',['guiigo-kz-sxkz','gg-sq-xxsc']);">{lang unlimited}</a></li>
						<!--{if $option[type] == 'select'}-->
							<!--{loop $option['choices'] $id $value}-->
								<!--{if $value[foptionid] == 0}-->
								<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]',['guiigo-kz-sxkz','gg-sq-xxsc']);">$value[content]</a></li>
								<!--{/if}-->
							<!--{/loop}-->
							<!--{if !($_GET[''.$option[identifier]] == 'all' || !isset($_GET[''.$option[identifier]]))}-->
								<!--{loop $option['choices'] $id $value}-->
									<!--{if (preg_match('/^'.$value[foptionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[foptionid].'$/i', $_GET[''.$option[identifier]])) && ($showoption[$value[count]][$id] = $value)}-->
									<!--{/if}-->
								<!--{/loop}-->
								<!--{if ksort($showoption)}--><!--{/if}-->
								<!--{loop $showoption $optioncount $values}-->
									<!--{if $tmpcount != $optioncount && ($tmpcount = $optioncount)}-->
									</ul><ul class="subtsm sh-a cl">
										<!--{loop $values $id $value}-->
											<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]',['guiigo-kz-sxkz','gg-sq-xxsc']);">$value[content]</a></li>
										<!--{/loop}-->
									</ul><ul>
									<!--{/if}-->
								<!--{/loop}-->
							<!--{/if}-->
						<!--{else}-->
							<!--{loop $option['choices'] $id $value}-->
								<li{if $_GET[''.$option[identifier]] && !strcmp($id, $_GET[''.$option[identifier]])} class="a"{/if}><a href="javascript:;" onclick="app.LoadPageForumView('.thread-scroll','forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]',['guiigo-kz-sxkz','gg-sq-xxsc']);">$value</a></li>
							<!--{/loop}-->
						<!--{/if}-->
	                </ul>
				</div>
			</div>
		<!--{/block}-->
     <!--{/if}-->
     <!--{eval $fontsearch_html .= $fontsearch;}-->
<!--{/loop}-->
<!--{if $formsearch_html || $fontsearch_html}-->
	<!--{if $fontsearch_html}-->
	    <div id="fontsearch" class="gg-sq-xxsc">
		    $fontsearch_html
	    </div>
	<!--{/if}-->
	<!--{if $formsearch_html}-->
	    <form method="post" autocomplete="off" name="searhsort" id="searhsort" class="cl" action="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]">
	        <input type="hidden" name="formhash" value="{FORMHASH}" />
	        <div class="gg-sq-xxss cl">
				$formsearch_html
				<div class="ms-a cl"><button type="submit" class="guiigo-pn ab-az zy-a zy-ac" name="searchsortsubmit">{lang search}</button></div>
			</div>
	    </form>
	<!--{/if}-->
<!--{/if}-->