<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
	<ul>
	<!--{if $_GET[action] == 'newthread'}-->
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="rewardprice">{lang reward_price}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="rewardprice" id="rewardprice" class="guiigo-px s-a" size="6" onkeyup="getrealprice(this.value)" value="{$_G['group']['minrewardprice']}" tabindex="1" /></div>
			<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c">{lang reward_tax_after}</div>
			<div class="wblb-wbnr"><div id="realprice" class="wnmr-sznr zy-b">0</div></div>
			<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</div>
		</li>
		<div class="gg-qz-flts bg-c">
			<div class="flts-tsnr bk-d bg-p zy-b">
				{lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
				<!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
				, {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
				<!--{if $_G['setting']['rewardexpiration'] > 0}-->
				<p>$_G['setting']['rewardexpiration'] {lang post_reward_message}</p>
				<!--{/if}-->
			</div>
		</div>
	<!--{elseif $_GET[action] == 'edit'}-->
		<!--{if $isorigauthor}-->
			<!--{if $thread['price'] > 0}-->
				<li class="guiigo-flex xh-b cl">
					<div class="wblb-wbbt zy-c"><label for="rewardprice">{lang reward_price}</label></div>
					<div class="wblb-wbnr zy-h"><input type="text" name="rewardprice" id="rewardprice" class="guiigo-px s-a" onkeyup="getrealprice(this.value)" size="6" value="$rewardprice" tabindex="1" /></div>
					<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</div>
				</li>
				<li class="guiigo-flex xh-b cl">
					<div class="wblb-wbbt zy-c">{lang reward_tax_add}</div>
					<div class="wblb-wbnr"><div id="realprice" class="wnmr-sznr zy-b">0</div></div>
					<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</div>
				</li>
				<div class="gg-qz-flts bg-c">
					<div class="flts-tsnr bk-d bg-p zy-b">
						{lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
						<!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
						, {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
						<!--{if $_G['setting']['rewardexpiration'] > 0}-->
							<p>$_G['setting']['rewardexpiration'] {lang post_reward_message}</p>
						<!--{/if}-->
					</div>
				</div>
			<!--{else}-->
				<div class="gg-qz-flts bg-c"><div class="flts-tsnr bk-d bg-p zy-b">{lang post_reward_resolved}</div></div>
				<input type="hidden" name="rewardprice" value="$rewardprice" tabindex="1" />
			<!--{/if}-->
		<!--{else}-->
			<!--{if $thread['price'] > 0}-->
				<li class="guiigo-flex xh-b cl">
					<div class="wblb-wbbt zy-c">{lang reward_price}</div>
					<div class="wblb-wbnr"><div class="wnmr-sznr zy-b">$rewardprice</div></div>
					<div class="wblb-wbdw zy-g">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</div>
				</li>
			<!--{else}-->
				<div class="gg-qz-flts bg-c"><div class="flts-tsnr bk-d bg-p zy-b">{lang post_reward_resolved}</div></div>
			<!--{/if}-->
		<!--{/if}-->
	<!--{/if}-->
	</ul>
</div>
<script type="text/javascript" reload="1">
ck8(function(){
	if(Dz('rewardprice')) {
		getrealprice(Dz('rewardprice').value)
	}
})

function getrealprice(price){
	if(!price.search(/^\d+$/)) {
		n = Math.ceil(parseInt(price) + price * $_G['setting']['creditstax']);
		
		if(price > 32767) {
			Dz('realprice').innerHTML = '{lang reward_price_overflow}';
		}
		<!--{if $_GET[action] == 'edit'}-->	else if(price < $rewardprice) 
		{
			Dz('realprice').innerHTML = '{lang reward_cant_fall}';
		}
		<!--{/if}--> 
		else if(price < $_G['group']['minrewardprice'] || ($_G['group']['maxrewardprice'] > 0 && price > $_G['group']['maxrewardprice'])) {
			Dz('realprice').innerHTML = '{lang guiigo_manage:tlang0306}';
		} else {
			Dz('realprice').innerHTML = n;
		}
		
	}else{
		Dz('realprice').innerHTML = '{lang input_invalid}';
	}
}

EXTRAFUNC['validator']['special'] = 'validateextra';
function validateextra() {
	if(Dz('postform').rewardprice && Dz('postform').rewardprice.value == '') {
		ck8.confirm('{lang post_reward_error_message}',
			function () {
				 Dz('postform').rewardprice.focus()
			},
			function () {}
		)
		return false;
	}
	return true;
}
</script>