<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="guiigo-kpms list-block-no">
	<ul class="list-container">
	<!--{loop $_G['forum_threadlist'] $key $thread}-->
	<!--{eval $pidarr=GuiigoApp::getpostfirstbypid($thread[tid]);}-->	
	<!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))> 0 }-->
	<!--{if $post['closed'] > 1 || $post['moved']}-->
		<!--{eval $post[tid]=$post[closed];}-->
	<!--{/if}-->
	<!--{if (!$_G['setting']['mobile']['mobiledisplayorder3'] && $post['displayorder'] > 0) ||  $post['displayorder'] < 0}-->
		{eval continue;}
	<!--{/if}-->
	<!--{eval $gender = GuiigoApp::getUserList($thread['authorid'],'profile');}-->
	<!--{eval $member = getuserbyuid($thread['authorid']);}-->
	<!--{eval $follow = GuiigoApp::getUserList($_G['uid'],'follow');}-->
	<!--{hook/forumdisplay_thread_mobile $key}-->
		<li class="bg-c">
			<div class="kpms-img">
				<!--{eval $cunm = count($postlists[$pidarr[pid]][attapic]);}-->
				<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
					<!--{if $cunm >= 1}-->
						<!--{loop $postlists[$pidarr[pid]][attapic] $key $aids}-->
							<img lazySrc="{eval echo getforumimg($aids[2], 0, 400, 350)}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/>
							<!--{eval break;}-->
						<!--{/loop}-->
					<!--{else}-->
						<img lazySrc="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-mrxc.png" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/>
					<!--{/if}-->
				</a>
			</div>
			<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
				<!--{eval $recommenus=GuiigoApp::getrecommendbyid($thread[tid],$_G[uid]);}-->
				<a href="forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&hash={FORMHASH}&handlekey=recommend_add"
					class="dialog kpms-dzan{if $recommenus} zy-i{else} kpms-hmxh{/if}"
					id="recommend_add_$thread[tid]"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{tid:'$thread[tid]'},fn:'MsgCallFnkp',load:'true',uid:'{$_G[uid]}'}"
					external>
					<i class="icon guiigoapp-kpxh"></i>
					<i class="icon guiigoapp-kpxh dzan-bsbk"></i>
				</a>
			<!--{/if}-->
			<div class="hpms-bthy">
				<h2>
					<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]>
						<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><!--{elseif $thread['digest'] > 0}-->
						<i class="zy-i">{lang guiigo_manage:tlang0221}</i>
						<!--{/if}-->
						{$thread['subject']}
					</a>
				</h2>
				<div class="bthy-txck">
					<div class="txck-tx"><!--{if $thread['authorid'] && $thread['author']}--><a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="zy-g"><!--{avatar($thread[authorid],middle)}-->$thread[author]</a><!--{else}--><a href="javascript:void(0);" class="zy-g"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg">$_G[setting][anonymoustext]</a><!--{/if}--></div>
					<div class="txck-ck zy-g"><i class="icon guiigoapp-chakan"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[views])}--><!--{else}-->$thread[views]<!--{/if}--></a></div>
				</div>
			</div>
		</li>
	<!--{/if}-->
	<!--{/loop}-->
	</ul>
</div>