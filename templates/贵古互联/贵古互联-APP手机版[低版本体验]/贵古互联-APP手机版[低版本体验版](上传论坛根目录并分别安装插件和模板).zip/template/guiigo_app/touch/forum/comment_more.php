<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $comments}-->
	<!--{loop $comments $comment}-->
		<div class="dplb-lbzt" id="delcomment_$comment[id]">
			<div class="dplb-dptx">{$comment[avatar]}</div>
			<div class="dplb-dpnr xh-b">
				<div class="dpnr-yhsj">
					<!--{if $comment['authorid']}-->
						<a href="home.php?mod=space&uid=$comment[authorid]&do=profile" class="yhsj-yhmc zy-l">$comment[author]</a>
					<!--{else}-->
						<a href="javascript:;" class="zy-l">{lang guest}</a>
					<!--{/if}-->
					<em class="zy-g">{$comment[dateline]}</em>
					<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
						<a href="javascript:;" 
						class="yhsj-scan bk-a zy-g"
						onclick="modaction(this, 'delcomment',$comment[id])"
						ck-cus="true"
						ck-param="{type:'popup',callpar:{cpid:'$_GET[pid]',tid:'$_GET[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}" ><i class="icon guiigoapp-shanchu"></i></a>
					<!--{/if}-->
				</div>
				<div class="dpnr-nrzt zy-h">$comment[comment]</div>
			</div>
		</div>
	<!--{/loop}-->
<!--{/if}-->
<!--{template common/footer}-->