<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="pay-view">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0103}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $loglist}-->
			<div class="guiigo-hylb list-block-no ms-a sh-a xh-b bg-c">
				<ul class="ms-c">
					<!--{loop $loglist $log}-->
					<li class="sh-a">
						<a href="home.php?mod=space&uid=$log[uid]&do=profile" class="guiigo-ty">
							<!--{avatar($log[uid],middle)}-->
							<h2 class="zy-h"><i class="zy-c">$log[dateline]</i>$log[username]</h2>
							<p class="zy-b">{$log[$extcreditname]} {$_G[setting][extcredits][$_G[setting][creditstransextra][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</p>
						</a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{else}-->
			<div class="guiigo-wnrtx">
				<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
				<p class="zy-c">{lang attachment_buy_not}</p>
			</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->