<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="guiigo-wblb list-block-no bg-c sh-a cl">
	<ul>
		<li class="wblb-dkbt bg-g xh-b zy-c cl"><label for="affirmpoint">{lang debate_square_point}</label><span class="zy-i">*</span></li>
		<li class="wblb-nrsr xh-b zy-h cl">
			<div class="wblb-wbnr zy-h">
				<textarea name="affirmpoint" id="affirmpoint" class="guiigo-pt s-a" tabindex="1" placeholder="{lang guiigo_manage:tlang0263}{lang debate_square_point}">$debate[affirmpoint]</textarea>
			</div>
		</li>
		<li class="wblb-dkbt bg-g xh-b zy-c cl"><label for="negapoint">{lang debate_opponent_point}</label><span class="zy-i">*</span></li>
		<li class="wblb-nrsr xh-b zy-h cl">
			<div class="wblb-wbnr zy-h">
				<textarea name="negapoint" id="negapoint" class="guiigo-pt s-a" tabindex="1" placeholder="{lang guiigo_manage:tlang0263}{lang debate_opponent_point}">$debate[negapoint]</textarea>
			</div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="endtime">{lang endtime}</label></div>
			<div class="wblb-wbnr zy-h"><input type="text" name="endtime" id="endtime" class="guiigo-px s-a" autocomplete="off" placeholder="{lang guiigo_manage:tlang0264}" value="$debate[endtime]" tabindex="1" /></div>
		</li>
		<li class="guiigo-flex xh-b cl">
			<div class="wblb-wbbt zy-c"><label for="umpire">{lang guiigo_manage:tlang0265}</label></div>
			<div class="wblb-wbnr zy-h">
				<input type="text" name="umpire" id="umpire" class="guiigo-px s-a" onblur="checkuserexists(this.value, 'checkuserinfo')" placeholder="{lang guiigo_manage:tlang0266}" value="$debate[umpire]" tabindex="1" />
			</div>
			<div id="checkuserinfo" class="zy-i"></div>
		</li>
	</ul>
</div>
<script type="text/javascript" reload="1">
ck8(function(){
  ck8("#endtime").datetimePicker({})
})

function checkuserexists(username, objname) {
	if(!username) {
		Dz(objname).innerHTML = '';
		return;
	}
	username = document.charset == 'utf-8' ? encodeURIComponent(username) : username;
	ck8.ajax({
		type : 'GET',
		url : 'forum.php?mod=ajax&inajax=1&action=checkuserexists&username=' + username+ '&inajax=1',
		dataType : 'xml',
		success: function(s){
			Dz(objname).innerHTML = s.lastChild.firstChild.nodeValue;;
		},
		error: function(){
			ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
		}
	})
}

EXTRAFUNC['validator']['special'] = 'validateextra';
function validateextra() {
	if(Dz('postform').affirmpoint.value == '') {
		ck8.confirm('{lang post_debate_message_1}',
			function () {
				 Dz('postform').affirmpoint.focus()
			},
			function () {}
		)
		return false;
	}
	if(Dz('postform').negapoint.value == '') {
		ck8.confirm('{lang post_debate_message_2}',
			function () {
				 Dz('postform').negapoint.focus()
			},
			function () {}
		)
		return false;
	}
	return true;
}
</script>