<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="gg-zx-zxls list-block-no bg-c ms-a">
	<ul class="list-container">
	<!--{loop $_G['forum_threadlist'] $key $thread}-->
	<!--{eval $pidarr=GuiigoApp::getpostfirstbypid($thread[tid]);}-->	
	<!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))> 0 }-->
	<!--{if $post['closed'] > 1 || $post['moved']}-->
		<!--{eval $post[tid]=$post[closed];}-->
	<!--{/if}-->
	<!--{if (!$_G['setting']['mobile']['mobiledisplayorder3'] && $post['displayorder'] > 0) ||  $post['displayorder'] < 0}-->
		{eval continue;}
	<!--{/if}-->
	<!--{eval $gender = GuiigoApp::getUserList($thread['authorid'],'profile');}-->
	<!--{eval $member = getuserbyuid($thread['authorid']);}-->
	<!--{eval $follow = GuiigoApp::getUserList($_G['uid'],'follow');}-->
	<!--{eval $cunm = count($postlists[$pidarr[pid]][attapic]);}-->
	<!--{hook/forumdisplay_thread_mobile $key}-->
		<li class="xh-b">
			<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
				<!--{if $cunm == 2 || $cunm == 1}-->
					<div class="zxls-pico">
						<!--{loop $postlists[$pidarr[pid]][attapic] $key $aids}-->
							<img lazySrc="{eval echo getforumimg($aids[2], 0, 400, 300)}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/>
							<!--{eval break;}-->
						<!--{/loop}-->
					</div>
				<!--{/if}-->
				<h2 class="{if $cunm == 2 || $cunm == 1}zxbx-bttd{else}zxbx-btte{/if}"$thread[highlight]>
					<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><!--{elseif $thread['digest'] > 0}-->
						<i class="zy-i">{lang guiigo_manage:tlang0221}</i>
					<!--{/if}-->
					{$thread['subject']}
				</h2>
				<!--{if $cunm >= 3}-->
					<div class="zxls-tico list-block-no">
						<ul>
							<!--{loop $postlists[$pidarr[pid]][attapic] $key $aids}-->
								<li><img lazySrc="{eval echo getforumimg($aids[2], 0, 400, 300)}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/>
								<!--{if $key == 2}-->
									<!--{eval break;}-->
								<!--{/if}-->
								</li>
							<!--{/loop}-->
						</ul>
					</div>
				<!--{/if}-->
				<p class="zy-c<!--{if $cunm <= 0}--> zxbx-ysjd<!--{/if}-->"><i class="zy-c"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[views])}--><!--{else}-->$thread[views]<!--{/if}-->{lang guiigo_manage:tlang0381}</i>$thread[dateline]</p>
			</a>
		</li>
	<!--{/if}-->
	<!--{/loop}-->
	</ul>
</div>