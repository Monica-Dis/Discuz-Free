<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="popup-actions" id="guiigo-lchd-$post[pid]">
	<div class="actions-text guiigo-hdfx">
		<div class="hdfx-tbjs bg-e xh-b">
			<img src="<!--{avatar($post[authorid], middle, true)}-->" class="vm">
			<span class="zy-c">{lang guiigo_manage:tlang0341}$post[author]{lang guiigo_manage:tlang0342}</span>
		</div>
		<div class="hdfx-hdxm list-block-no bg-e">
		<!--{if $allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])}-->
			<a href="forum.php?mod=misc&action=comment&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page{if $_G['forum_thread']['special'] == 127}&special=$specialextra{/if}" 
				class="dialog link link-c zy-f" 
				ck-cus="true" 
				ck-param="{type:'modal',callpar:{tid:'$post[tid]',pid:'$post[pid]'},load:'true',fn:'MsgCallComment',uid:'$_G[uid]'}"
				external>
				<span style="background:#9dca06;"><i class="icon guiigoapp-fbxhfb zy-a"></i></span>{lang guiigo_manage:tlang0104}
			</a>
		<!--{else}-->
			<a href="javascript:ck8.toast('{lang guiigo_manage:tlang0343}','shibai');" class="link link-c zy-f"><span style="background:#9dca06;"><i class="icon guiigoapp-fbxhfb zy-a"></i></span>{lang guiigo_manage:tlang0104}</a>
		<!--{/if}-->
		<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" class="zy-f"><span style="background:#FF9900;"><i class="icon guiigoapp-lchuifu zy-a"></i></span>{lang guiigo_manage:tlang0148}</a>
		<!--{if $guiigo_config['appsetting']['forumconfig']['show_reward']}-->
			<a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]" class="zy-f dialog" 
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pid:'$post[pid]'},fn:'MsgCallRaterange',load:'true',uid: '$_G[uid]'}"
			external ><span style="background:#ff6060;"><i class="icon guiigoapp-lchongbao zy-a"></i></span>{lang guiigo_manage:tlang0344}</a>
		<!--{/if}-->
		<!--{if $post['authorid'] && $post['author'] && !$post['anonymous']}-->
			<!--{if !($_G['setting']['threadguestlite'] && !$_G['uid'])}-->
				<!--{if !in_array($post['authorid'], $follow)}-->
				<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$post[authorid]" 
					class="followmod_$post[authorid] dialog zy-f" 
					ck-cus="true"
					ck-param="{type:'modal',fn:'MsgCallFnl',load:'true',uid:'$_G[uid]'}" 
					external><span style="background:#3ebbfd;"><i class="icon guiigoapp-guanzhu zy-a"></i></span>{lang guiigo_manage:tlang0002}</a>
				<!--{else}-->
				<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$post['authorid']" 
					class="followmod_$post[authorid] dialog zy-f" 
					ck-cus="true"
					ck-param="{type:'modal',fn:'MsgCallFnl',load:'true',uid:'$_G[uid]'}" 
					external><span style="background:#3ebbfd;"><i class="icon guiigoapp-guanzhu zy-a"></i></span>{lang guiigo_manage:tlang0003}</a>
				<!--{/if}-->
			<!--{/if}-->
		<!--{/if}-->
			<a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" 
			class="dialog zy-f"
			ck-cus="true"
			ck-param="{type:'modal',fn:'MsgCallReport',load:'true',uid:'$_G[uid]'}"  
			external ><span style="background:#da99db;"><i class="icon guiigoapp-tbxhjb zy-a"></i></span>{lang guiigo_manage:tlang0345}</a>
		</div>
		<div class="hdfx-hdgb sh-a bg-c zy-i" onclick="app.ActionsManage('#guiigo-lchd-$post[pid]','t', 'auto');">{lang guiigo_manage:tlang0105}</div>
	</div>
</div>
<div class="popup-actions" id="actions_{$post[pid]}">
		<!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
		<a href="javascript:;" onclick="setanswer($post[tid],$post['pid'], '$_GET[from]','{FORMHASH}','MsgCallModmenu',{'pid':{$firstlist[pid]}})">{lang reward_set_bestanswer}</a>
		<!--{/if}-->
</div>
<!--{if $_G['forum']['ismoderator']}-->
<div class="popup-actions" id="guiigo-lcgl-$post[pid]">
	<div class="actions-text guiigo-hdfx">
		<div class="hdfx-glxm list-block-no bg-e">
			<ul>
			<!--{if $modmenu['post']}-->
				<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowstickreply'] || $_G['forum_thread']['authorid'] == $_G['uid']}-->
					<li class="bg-c">
						<a href="javascript:;"  class="zy-h" 
							onclick="modaction(this,'stickreply')"
							ck-cus="true"
							ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
							{lang guiigo_manage:tlang0346}</a>
					</li>
				<!--{/if}-->
				<!--{if $_G['forum']['ismoderator']}-->
					<!--{if $_G['group']['allowwarnpost']}-->
					<li class="bg-c">
						<a href="javascript:;" class="zy-h" 
							onclick="modaction(this,'warn')"
							ck-cus="true"
							ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
							{lang modmenu_warn}</a>
					</li>
					<!--{/if}-->
					<!--{if $_G['group']['allowbanpost']}-->
					<li class="bg-c">
						<a href="javascript:;"  class="zy-h" 
							onclick="modaction(this,'banpost')"
							ck-cus="true"
							ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
							{lang modmenu_banpost}</a>
					</li>
					<!--{/if}-->
					<!--{if $_G['group']['allowdelpost'] && !$rushreply}-->
					<li class="bg-c">
						<a href="javascript:;"  class="zy-h" 
							onclick="modaction(this,'delpost')"
							ck-cus="true"
							ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
							{lang modmenu_deletepost}</a>
					</li>
					<!--{/if}-->
				<!--{/if}-->
				<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
					<li class="bg-c">
						<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="zy-h">{lang guiigo_manage:tlang0227}</a>
					</li>
				<!--{/if}-->
			<!--{/if}-->
			</ul>
		</div>
		<div class="hdfx-hdgb sh-a bg-c zy-i" onclick="app.ActionsManage('#guiigo-lcgl-$post[pid]','t', 'auto');">{lang guiigo_manage:tlang0105}</div>
	</div>
</div>
<!--{/if}-->
<!--{if $modmenu['thread'] && $post['first']}-->
<div class="popup-actions" id="guiigo-lcgl-lzgl">
	<div class="actions-text guiigo-hdfx">
		<div class="hdfx-glxm list-block-no bg-e">
	<ul>
		<!--{eval $modopt=0;}-->
		<!--{if $_G['forum']['ismoderator']}-->
			<!--{if $_G['group']['allowdelpost']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;" class="zy-h" 
					onclick="modthreads(this, 3, 'delete')" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_deletethread}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowbumpthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;" class="zy-h" 
					onclick="modthreads(this, 3, 'bump')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_updown}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;" class="zy-h" 
					onclick="modthreads(this, 1, 'stick')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_stickthread}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowlivethread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;" class="zy-h" 
					onclick="modaction(this, 'live')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_live}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowhighlightthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modthreads(this, 1, 'highlight')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_highlight}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modthreads(this, 1, 'digest')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_digestpost}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1 && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modthreads(this, 1, 'recommend')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_recommend}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowstampthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modaction(this, 'stamp')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_stamp}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowstamplist'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modaction(this, 'stamplist')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_icon}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowclosethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modthreads(this, 4)"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					<!--{if !$_G['forum_thread']['closed']}-->
					{lang modmenu_switch_off}
					<!--{else}-->
					{lang modmenu_switch_on}
					<!--{/if}-->
				</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modthreads(this, 2, 'move')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_move}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowedittypethread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modthreads(this, 2, 'type')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_type}</a></li>
			<!--{/if}-->
			<!--{if !$_G['forum_thread']['special'] && !$_G['forum_thread']['is_archived']}-->
				<!--{if $_G['group']['allowcopythread'] && $_G['forum']['status'] != 3}-->
					<!--{eval $modopt++}-->
					<li class="bg-c"><a href="javascript:;"  class="zy-h" 
						onclick="modaction(this, 'copy')"
						ck-cus="true"
						ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
						{lang modmenu_copy}</a></li>
				<!--{/if}-->
				<!--{if $_G['group']['allowmergethread'] && $_G['forum']['status'] != 3}-->
					<!--{eval $modopt++}-->
					<li class="bg-c"><a href="javascript:;"  class="zy-h" 
						onclick="modaction(this, 'merge')"
						ck-cus="true"
						ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
						{lang modmenu_merge}</a></li>
				<!--{/if}-->
				<!--{if $_G['group']['allowrefund'] && $_G['forum_thread']['price'] > 0}-->
					<!--{eval $modopt++}-->
					<li class="bg-c"><a href="javascript:;"  class="zy-h" 
						onclick="modaction(this, 'refund')"
						ck-cus="true"
						ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
						{lang modmenu_restore}</a></li>
				<!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowsplitthread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modaction(this, 'split')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_split}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['allowrepairthread'] && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modaction(this, 'repair')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_repair}</a></li>
			<!--{/if}-->
			<!--{if $_G['forum_thread']['is_archived'] && $_G['adminid'] == 1}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modaction(this, 'restore', '', 'archiveid={$_G[forum_thread][archiveid]}')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_archive}</a></li>
			<!--{/if}-->
			<!--{if $_G['forum_firstpid']}-->
				<!--{if $_G['group']['allowwarnpost']}-->
					<!--{eval $modopt++}-->
					<li class="bg-c"><a href="javascript:;"  class="zy-h" 
						onclick="modaction(this, 'warn', '$_G[forum_firstpid]')"
						ck-cus="true"
						ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
						{lang modmenu_warn}</a></li>
				<!--{/if}-->
				<!--{if $_G['group']['allowbanpost']}-->
					<!--{eval $modopt++}-->
					<li class="bg-c"><a href="javascript:;"  class="zy-h" 
						onclick="modaction(this, 'banpost', '$_G[forum_firstpid]')"
						ck-cus="true"
						ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
						{lang modmenu_banthread}</a></li>
				<!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowremovereward'] && $_G['forum_thread']['special'] == 3 && !$_G['forum_thread']['is_archived']}-->
				<!--{eval $modopt++}-->
				<li class="bg-c"><a href="javascript:;"  class="zy-h" 
					onclick="modaction(this, 'removereward')"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
					{lang modmenu_removereward}</a></li>
			<!--{/if}-->
			<!--{if $_G['forum']['status'] == 3 && in_array($_G['adminid'], array('1','2')) && $_G['forum_thread']['closed'] < 1}-->
			<li class="bg-c"><a href="javascript:;"  class="zy-h" 
				onclick="modthreads(this, 5, 'recommend_group');"
				ck-cus="true"
				ck-param="{type:'modal',callpar:{pid:'$post[pid]',tid:'$post[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}">
				{lang modmenu_grouprecommend}</a></li>
			<!--{/if}-->
			<!--{if $_G['group']['alloweditusertag']}-->
			<li class="bg-c"><a href="forum.php?mod=misc&action=usertag&tid=$_G[tid]" 
				class="dialog zy-h"
				ck-cus="true"
				ck-param="{type:'modal',fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}"
				external >{lang usertag}</a></li>
			<!--{/if}-->
		<!--{/if}-->
		<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
			<li class="bg-c"><a class="zy-h" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}<!--{/if}--></a></li>
		<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
			<li class="bg-c"><a class="zy-h" href="forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page">{lang postappend}</a></li>
		<!--{/if}-->
	</ul>
	</div>
	<div class="hdfx-hdgb sh-a bg-c zy-i" onclick="app.ActionsManage('#guiigo-lcgl-lzgl','t', 'auto');">{lang guiigo_manage:tlang0105}</div>
	</div>
</div>
<!--{/if}-->