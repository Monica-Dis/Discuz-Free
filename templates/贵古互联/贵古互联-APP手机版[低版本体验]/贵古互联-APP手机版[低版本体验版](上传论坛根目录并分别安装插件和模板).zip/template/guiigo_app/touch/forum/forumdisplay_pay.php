<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="forumdisplay">
	<header class="bar bar-nav guiigo-nydb guiigo-dydb bg-c">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
	</header>
	<div class="content bg-c gg-yjms">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-sq-mbts">
				<h1 class="zy-e">{lang guiigo_manage:tlang0089}</h1>
				<p class="zy-h">{lang guiigo_manage:tlang0217}<span class="zy-b">$paycredits{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit']}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title']}</span>{lang guiigo_manage:tlang0218}</p>
			</div>
			<div class="gg-sq-mbsr gg-sq-ffqr">
				<form method="post" 
				autocomplete="off" 
				action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=paysubmit"
				ck-cus="true"
				ck-param="{type:'modal',callpar:{fid:'$_G[fid]'},fn:'MsgCallPasswdbk',load:'true',uid:'$_G[uid]'}"
				>
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<button class="formdialog guiigo-pn ab-az zy-a zy-ac" type="submit" name="loginsubmit" value="true">{lang confirmyourpay}</button>
					<button class="back guiigo-pn ab-b zy-a" type="button">{lang cancel}</button>
				</form>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->
