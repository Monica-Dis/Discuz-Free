<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="gg-sq-bxyb bg-c sh-a xh-b">
	<div class="bxyb-ican xh-b">
		<img alt="$_G['forum'][name]" src="<!--{if $_G['forum'][icon]}-->data/attachment/common/$_G['forum'][icon]<!--{else}-->{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/forum.png<!--{/if}-->">
		<div class="sgsj-sjon zy-c">
			<span><em class="zy-h"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][todayposts])}--><!--{else}-->$_G[forum][todayposts]<!--{/if}--></em>{lang index_today}</span>
			<span><em class="zy-h"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][threads])}--><!--{else}-->$_G[forum][threads]<!--{/if}--></em>{lang index_threads}</span>
			<span><em class="zy-h"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][rank])}--><!--{else}-->$_G[forum][rank]<!--{/if}--></em>{lang guiigo_manage:tlang0133}</span>
		</div>
		
		<div class="xgsj-gzhy list-block-no">
			<ul class="cl">
				<!--{loop $gzlist['bzlist'] $vals}-->
				<!--{if $vals['uid'] && !in_array($vals['uid'],$gzlist['uids'])}-->
					<li><img src="<!--{avatar($vals[uid],middle,true)}-->"></li>
					<!--{/if}-->
				<!--{/loop}-->
			</ul>
			<span class="zy-c"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G[forum][favtimes])}--><!--{else}-->$_G[forum][favtimes]<!--{/if}-->{lang guiigo_manage:tlang0027}</span>
		</div>
		<!--{eval $favorite=GuiigoApp::getUserList($_G['uid'],'favorite','fid');}-->
		<!--{if $favorite && $_G['fid'] == $favorite[$_G['fid']]['id']}-->
		<!--{eval $favids=$favorite[$_G['fid']]['favid'];}-->
			<a id="post_favc_forum_" 
			href="home.php?mod=spacecp&ac=favorite&op=delete&type=forum&favid=$favids" 
			class="dialog posonts-off favorbtn ab-b zy-a" 
			ck-cus="true" ck-param="{type:'modal',callpar:{},fn:'MsgCallPostFavcForum',load:'true',uid: '$_G[uid]'}" external>
			{lang guiigo_manage:tlang0003}</a>
		<!--{else}-->
			<a id="post_favc_forum_" 
			href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" 
			class="dialog posonts favorbtn ab-f zy-a zy-ac" 
			ck-cus="true" ck-param="{type:'modal',callpar:{},fn:'MsgCallPostFavcForum',load:'true',uid: '$_G[uid]'}" external>{lang guiigo_manage:tlang0024}</a>
		<!--{/if}-->
	</div>
	<p class="zy-h">$_G['forum'][description]</p>
</div>