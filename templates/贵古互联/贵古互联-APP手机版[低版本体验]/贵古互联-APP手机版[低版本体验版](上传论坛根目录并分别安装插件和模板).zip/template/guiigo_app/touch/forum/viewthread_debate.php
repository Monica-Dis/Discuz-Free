<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
$post[message]
<!--{if $debate[umpire]}-->
	<!--{if $debate['umpirepoint']}-->
	<div class="gg-sq-bljg sh-a">
		<div class="bljg-icon<!--{if $debate[winner] == 1}--> bg-k<!--{elseif $debate[winner] == 2}--> bg-j<!--{else}--> bg-l<!--{/if}-->"><i class="icon guiigoapp-taolunqu zy-a<!--{if !$debate[winner] == 1 || !$debate[winner] == 2}--> zy-c<!--{/if}-->"></i></div>
		<div class="bljg-jgnr">
			<h2 class="<!--{if $debate[winner] == 1}-->zy-n<!--{elseif $debate[winner] == 2}-->zy-i<!--{else}-->zy-c<!--{/if}-->">
				<!--{if $debate[bestdebater]}--><em class="bk-a zy-f"><i class="icon guiigoapp-tbgrzx"></i>{lang debate_bestdebater}: $debate[bestdebater]</em><!--{/if}-->
				<!--{if $debate[winner]}-->
					<!--{if $debate[winner] == 1}-->{lang debate_square}{lang debate_winner}<!--{elseif $debate[winner] == 2}-->{lang debate_opponent}{lang debate_winner}<!--{else}-->{lang debate_draw}<!--{/if}-->
				<!--{/if}-->
			</h2>
			<!--{if $debate[umpirepoint]}--><p class="zy-f">$debate[umpirepoint]</p><!--{/if}-->
		</div>
	</div>
	<!--{/if}-->
<!--{/if}-->
<!--{if $debate[endtime]}-->
	<div class="poll-tpjs bg-g zy-h">
		{lang endtime}: $debate[endtime] <!--{if $debate[umpire]}-->{lang debate_umpire}: $debate[umpire]<!--{/if}-->
	</div>
<!--{/if}-->
<div id="deba-cgkz">
	<div class="gg-sq-deba ms-a cl">
		<div class="deba-blbf deba-ds yh-a">
			<div class="blbf-blsj zy-n">{lang debate_square_point}</div>
			<div class="blbf-jdys bg-e">
				<div class="blbf-jdss bg-k" style="width: {echo $debate[affirmvoteswidth]}%;"></div>
			</div>
			<div class="blbf-bfnr zy-f">
				$debate[affirmpoint]
			</div>
		</div>
		<div class="deba-blbf deba-dr">
			<div class="blbf-blsj zy-i">{lang debate_opponent_point}</div>
			<div class="blbf-jdys bg-e">
				<div class="blbf-jdss bg-j" style="width: {echo $debate[negavoteswidth]}%;"></div>
			</div>
			<div class="blbf-bfnr zy-f">
				$debate[negapoint]
			</div>
		</div>
		<!--{if !$_G['forum_thread']['is_archived']}-->
		<div class="deba-blbf deba-ds deba-dsa cl">
			<button href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" 
			id="affirmbutton" 
			class="dialog guiigo-pn bg-k zy-a"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{tid:'$_G[tid]',type:'videbate'},fn:'MsgCallInvite',load:'true',uid: '$_G[uid]'}"
			external>{lang debate_support} $debate[affirmvotes]</button>
			<div class="blbf-bszs list-block-no bg-e cl">
				<h2 class="zy-h">{lang debater}:$debate[affirmdebaters]</h2>
				<ul>
					<!--{loop $debate[affirmavatars] $user}-->
					<li>
						<a href="home.php?mod=space&uid=$user[authorid]&do=profile">$user[avatar]</a>
					</li>
					<!--{/if}-->
				</ul>
			</div>
		</div>
		<div class="deba-blbf deba-dv zy-c cl">VS</div>
		<div class="deba-blbf deba-dr deba-dra cl">
			<button href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" 
			id="negabutton" 
			class="dialog guiigo-pn bg-j zy-a"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{tid:'$_G[tid]',type:'videbate'},fn:'MsgCallInvite',load:'true',uid: '$_G[uid]'}"
			external>{lang debate_support} $debate[negavotes]</button>
			<div class="blbf-bszs list-block-no bg-e cl">
				<h2 class="zy-h">{lang debater}:$debate[negadebaters]</h2>
				<ul>
					<!--{loop $debate[negaavatars] $user}-->
					<li>
						<a href="home.php?mod=space&uid=$user[authorid]&do=profile">$user[avatar]</a>
					</li>
					<!--{/if}-->
				</ul>
			</div>
		</div>
		<!--{/if}-->
	</div>
	<!--{if $debate[umpire] && $_G['username'] && $debate[umpire] == $_G['member']['username']}-->
		<!--{if $debate[remaintime] && !$debate[umpirepoint]}-->
		<a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" class="guiigo-pn ms-b ab-az zy-a zy-ac" data-no-cache="true">{lang debate_umpire_end}</a>
		<!--{elseif TIMESTAMP - $debate['dbendtime'] < 3600}-->
		<a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" class="guiigo-pn ms-b ab-az zy-a zy-ac" data-no-cache="true">{lang debate_umpirepoint_edit}</a>
		<!--{/if}-->
	<!--{/if}-->
</div>