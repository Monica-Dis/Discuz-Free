<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $thread['freemessage']}-->
	<div id="postmessage_$pid" class="t_f">$thread[freemessage]</div>
<!--{/if}-->
<!--{if empty($_GET['archiver'])}-->
	<div class="gg-sq-gmzs ms-a bg-p bk-d">
		<div class="gmzs-zstb"><i class="icon guiigoapp-shoufei zy-b"></i></div>
		<div class="gmzs-zsnr zy-b">
			<!--{if $_G[forum_thread][price] > 0}-->{lang pay_comment}<!--{/if}-->
			<!--{if $thread[endtime]}-->{lang pay_free_time}<!--{/if}-->
			<div class="zsnr-yggm">
			<!--{if $thread[payers]}--><span class="zy-g">{lang have} $thread[payers] {lang people_buy}</span><!--{/if}-->
			<a href="forum.php?mod=misc&action=pay&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET['from'])}&from=$_GET['from']{/if}" class="dialog guiigo-pn ab-c zy-a"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pid:'$post[pid]'},fn:'MsgCallRaterange',load:'true',uid: '$_G[uid]'}" 
			external >{lang pay}</a>
			</div>
		</div>
	</div>
<!--{else}-->
	<div class="gg-sq-gmzs ms-a bg-p bk-d">
		<div class="gmzs-zstb"><i class="icon guiigoapp-shoufei zy-b"></i></div>
		<div class="gmzs-zsnr zy-b">
		<!--{if $_G[forum_thread][price] > 0}-->{lang pay_comment}<!--{/if}-->
		<!--{if $thread[endtime]}-->{lang pay_free_time}<!--{/if}-->
		<!--{if $thread[payers]}--><div class="zsnr-yggm"><span class="zy-g">{lang have} $thread[payers] {lang people_buy}</span></div><!--{/if}-->
		</div>
	</div>
<!--{/if}-->