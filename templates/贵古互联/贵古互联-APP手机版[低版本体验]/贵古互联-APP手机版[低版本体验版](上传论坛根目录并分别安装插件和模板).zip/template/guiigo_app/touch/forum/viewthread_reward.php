<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="gg-sq-wdlfj bg-p bk-d zy-b">
	<i class="icon guiigoapp-xuanshang zy-b"></i>{lang thread_reward} $rewardprice {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}{if $_G['forum_thread']['price'] > 0} [{lang unresolved}]{elseif $_G['forum_thread']['price'] < 0} [{lang resolved}]{/if}
	<!--{if $_G['forum_thread']['price'] > 0 && !$_G['forum_thread']['is_archived']}-->
		<a href="javascript:;" class="guiigo-pn ab-c zy-a" onclick="app.ActionsManage('#guiigo-hfdp','t','auto','closehfdp');openReply();">{lang reward_answer}</a>
	<!--{/if}-->
</div>
$post[message]
<!--{if $post['attachment']}-->
	<div class="gg-sq-wdlfj bg-p bk-d zy-b">
		<i class="icon guiigoapp-tishi zy-b"></i>
		{lang attachment}: <!--{if $_G['uid']}-->{lang attach_nopermission}<!--{elseif $_G['connectguest']}-->{lang attach_nopermission_connect_fill_profile}<!--{else}-->{lang attach_nopermission_login}<!--{/if}-->
	</div>
<!--{elseif $post['imagelist'] || $post['attachlist']}-->
	<!--{if $post['imagelist']}-->
		 <!--{echo showattach($post, 1)}-->
	<!--{/if}-->
	<!--{if $post['attachlist']}-->
		 <!--{echo showattach($post)}-->
	<!--{/if}-->
<!--{/if}-->
<!--{eval $post['attachment'] = $post['imagelist'] = $post['attachlist'] = '';}-->
<!--{if $bestpost}-->
	<div class="gg-sq-dnzs">
		<div class="dnzs-dnbt bg-b zy-a">{lang reward_bestanswer}</div>
		<div class="dnzs-mctx">$bestpost[avatar] <a href="home.php?mod=space&uid=$bestpost[authorid]&do=profile" class="zy-l">$bestpost[author]</a></div>
		<div class="dnzs-annr zy-h">$bestpost[message]</div>
	</div>
<!--{/if}-->