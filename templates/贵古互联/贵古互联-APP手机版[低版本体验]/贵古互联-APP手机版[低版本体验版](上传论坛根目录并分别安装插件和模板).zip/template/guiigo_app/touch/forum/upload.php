<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="gg-fb-tpxz">
	<form id="uploadform" class="uploadform ptm pbm" method="post" autocomplete="off" target="uploadattachframe" action="misc.php?mod=swfupload&operation=upload&type=$type&inajax=yes&infloat=yes&simple=2" enctype="multipart/form-data">
		<input type="hidden" name="handlekey" value="upload" />
		<input type="hidden" name="uid" value="$_G['uid']">
		<input type="hidden" name="hash" value="{echo md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])}">
		<div class="tpxz-scan">
			<a class="bg-e bk-e zy-c" href="javascript:;">
				<i class="icon guiigoapp-tupian zy-f"></i>{lang guiigo_manage:tlang0366}
				<input type="file" name="Filedata" id="filedata" class="pf cur1" size="1" onchange="Dz('uploadform').submit()" />
			</a>
		</div>
	</form>
	<div class="tpxz-tsxx ms-a zy-g">
		<!--{if $type == 'image'}-->{lang attachment_allow_exts}: <span class="xi1">$imgexts</span><!--{elseif $_G['group']['attachextensions']}-->{lang attachment_allow_exts}: <span class="xi1">{$_G['group']['attachextensions']}</span><!--{/if}-->
	</div>
	<iframe name="uploadattachframe" id="uploadattachframe" style="display: none;" onload="uploadWindowload();"></iframe>
</div>
<!--{template common/footer}-->