<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div id="attachpayform">
<form  
	method="post" 
	autocomplete="off" 
	action="forum.php?mod=misc&action=attachpay&tid={$_G[tid]}"
	ck-cus="true"
	ck-param="{type:'popup',height:'50%',callpar:{type:'attachpay',aid:'$aid'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]',title:'{lang guiigo_manage:tlang0101}'}">
    <input type="hidden" name="paysubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="paysubmit" value="true" />
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="aid" value="$aid" />
	<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
	<div class="gg-sq-gmfj">
		<div class="gmfj-gmsj xh-b"><em class="zy-c">{lang author}</em><span class="zy-h">$attach[author]</span></div>
		<div class="gmfj-gmsj<!--{if $status != 1}--> xh-b<!--{/if}-->"><em class="zy-c">{lang price}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</em><span class="zy-b">$attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</span></div>
		<!--{if $status != 1}-->
			<div class="gmfj-gmsj xh-b"><em class="zy-c">{lang pay_author_income}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</em><span class="zy-b">$attach[netprice] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</span></div>
			<div class="gmfj-gmsj xh-b"><em class="zy-c">{lang pay_balance}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</em><span class="zy-b">$balance {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</span></div>
			<div class="gmfj-gmsj"><em class="zy-c">{lang buy_all_attch}</em><div class="guiigo-pc"><input name="buyall" type="checkbox" class="pc" value="yes" /><label><em></em></label></div></div>
			<button class="formdialog guiigo-pn ab-az zy-a zy-ac" type="button" >
			<!--{if $status == 0}-->{lang pay_attachment}<!--{else}-->{lang free_buy}<!--{/if}-->
			</button>
		<!--{else}-->
			<div class="gg-qz-flts bg-c ms-a">
				<div class="flts-tsnr bk-d bg-p zy-b" style="margin: -.55rem;">{lang guiigo_manage:tlang0102}</div>
			</div>
		<!--{/if}-->
	</div>
</form>
</div>
<!--{template common/footer}-->