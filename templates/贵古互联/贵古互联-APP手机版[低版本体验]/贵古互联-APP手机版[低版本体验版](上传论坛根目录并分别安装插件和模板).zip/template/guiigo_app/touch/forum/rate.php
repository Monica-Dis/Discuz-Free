<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div id="floatlayout_topicadmin">
<!--{if empty($_GET['showratetip'])}-->
<!--{if $_GET[action] == 'rate'}-->
	<form id="rateform" 
		method="post" 
		autocomplete="off"
		action="forum.php?mod=misc&action=rate&ratesubmit=yes&infloat=yes"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{pid:'$_GET[pid]'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]',cancel:'{lang guiigo_manage:tlang0314}',confirm:'{lang guiigo_manage:tlang0315}',class:'gg-sq-dstc'}">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<input type="hidden" name="pid" value="$_GET[pid]" />
		<input type="hidden" name="referer" value="$referer" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="rate"><!--{/if}-->
		<div class="dstc-dsmb">
			<h2>{lang guiigo_manage:tlang0316}$post[author]</h2>
			<div class="dsmb-mbtx"><img src="<!--{avatar($post[authorid], middle, true)}-->"></div>
			<div class="dsmb-dstcgb"><div class="dsmb-dstcgb-x"></div></div>
		</div>
		<div class="dstc-dsxx">
			<div class="dsxx-fzsr cl">
				<!--{eval $rateselfflag = 0;}-->
				<!--{loop $ratelist $id $options}-->
					<div class="dsxx-fzsr-a">{$_G['setting']['extcredits'][$id][img]} {$_G['setting']['extcredits'][$id][title]}</div>
					<div class="dsxx-fzsr-b">
						<input type="text" name="score$id" id="score$id" class="guiigo-px" value="0"/>
					</div>
					<div class="dsxx-fzsr-c">
						<a href="javascript:;" class="dpbtn" onclick="showselect(this,'scoreoption$id','score$id')"><i class="icon guiigoapp-xxzk"></i></a>
					</div>
					<div class="dsxx-fzsr-d">
						<ul id="scoreoption$id" class="hide" style="display:none">$options</ul>
					</div>
				<!--{/loop}-->
					<div class="dsxx-fzsr-e">
						<input type="text" name="reason" id="reason" class="guiigo-px" onkeyup="seditor_ctlent(event, 'Dz(\'rateform\').ratesubmit.click()')" value="{lang guiigo_manage:tlang0317}" />
					</div>
					<div class="dsxx-fzsr-f">
						<a href="javascript:;" class="dpbtn" onclick="showselect(this,'reasonselect')"><i class="icon guiigoapp-xxzk"></i></a>
					</div>
				<!--{eval $selectreason = modreasonselect(0, 'userreasons')}-->
				<!--{if $selectreason}-->
					<div class="dsxx-fzsr-g">
						<ul id="reasonselect" class="hide reasonselect pt" style="display:none">$selectreason</ul>
						<script type="text/javascript" reload="1">
							var reasonSelectOption = Dz('reasonselect').getElementsByTagName('li');
							if (reasonSelectOption) {
								for (i=0; i<reasonSelectOption.length; i++) {
									reasonSelectOption[i].onmouseover = function() { this.className = 'xi2 cur1'; }
									reasonSelectOption[i].onmouseout = function() { this.className = ''; }
									reasonSelectOption[i].onclick = function() {
										Dz('reason').value = this.innerHTML;
									}
								}
							}
						</script>
					</div>
				<!--{/if}-->
				<div class="dsxx-fzsr-h">{lang admin_pm}</div>
				<div class="dsxx-fzsr-i">
					<div class="guiigo-pc">
						<input type="checkbox" name="sendreasonpm" id="sendreasonpm" {if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} /><label for="sendreasonpm"><em></em></label>
					</div>
				</div>
			</div>
		</div>
	</form>
<!--{/if}-->
<!--{/if}-->
<script>
function showselect(e,showel,el){
	var Obj = $('#'+showel)
	if(Obj.css('display') == 'none'){
		$('.hide').css({'display':'none'})
		$('.dpbtn').html('<i class="icon guiigoapp-xxzk"></i>')
		$(e).html('<i class="icon guiigoapp-xszk"></i>')
	    Obj.css({'display':'block'}).find('li').on('click',function(){
			var ls = parseInt($(this).html().replace('+',''))
			$(e).html('<i class="icon guiigoapp-xxzk"></i>')
			if(el){
			$('#'+el).val(ls)
			}
			Obj.css({'display':'none'})
		})
	}else if(Obj.css('display') == 'block'){
		$(e).html('<i class="icon guiigoapp-xxzk"></i>')
		Obj.css({'display':'none'})
	}
}
</script>
</div>
<!--{template common/footer}-->