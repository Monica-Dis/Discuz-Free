<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
	<ul>
		<!--{if $sortid}-->
			<input type="hidden" name="sortid" value="$sortid" />
		<!--{/if}-->
		<!--{if $_GET[action] == 'reply' && !empty($_GET['addtrade']) || $_GET[action] == 'edit' && $thread['special'] == 2 && !$postinfo['first']}-->
			<input name="subject" type="hidden" value="" />
		<!--{else}-->
			<!--{if $_GET[action] != 'reply'}-->
				<li class="guiigo-flex xh-b cl">
					<div class="wblb-wbbt" style="color: #000;">{lang guiigo_manage:tlang0297}</div>
					<div class="wblb-wbnr zy-h">
						<input type="text" name="subject" id="subject" class="guiigo-px s-a" value="$postinfo[subject]" placeholder="<!--{if $_GET[action] == 'newthread'}-->{lang guiigo_manage:tlang0298}<!--{elseif $_GET[action] == 'edit'}-->{lang guiigo_manage:tlang0299}<!--{/if}-->" tabindex="1" />
					</div>
				</li>
			<!--{else}-->
				<li id="subjecthide">RE: $thread[subject]</li>
			<!--{/if}-->			
		<!--{/if}-->
		<!--{if $isfirstpost && !empty($_G['forum'][threadtypes][types])}-->
			<li class="guiigo-flex xh-b cl">
				<!--{if $_G['forum']['ismoderator'] || empty($_G['forum']['threadtypes']['moderators'][$thread[typeid]])}-->
				<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0300}</div>
				<div class="wblb-wbnr zy-h">
					<select name="typeid" id="typeid" class="guiigo-ps">
					<option value="0">{lang select_thread_catgory}</option>
					<!--{loop $_G['forum'][threadtypes][types] $typeid $name}-->
						<!--{if empty($_G['forum']['threadtypes']['moderators'][$typeid]) || $_G['forum']['ismoderator']}-->
						<option value="$typeid"{if $thread['typeid'] == $typeid || $_GET['typeid'] == $typeid} selected="selected"{/if}><!--{echo strip_tags($name);}--></option>
						<!--{/if}-->
					<!--{/loop}-->
					</select>
				</div>
				<!--{else}-->
				[<!--{echo strip_tags($_G['forum']['threadtypes']['types'][$thread[typeid]]);}-->]
				<!--{/if}-->
			</li>
		<!--{/if}-->
	</ul>
</div>
<!--{if $showthreadsorts}-->
	<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
		<ul>
			<!--{template forum/post_sortoption}-->
		</ul>
	</div>
<!--{elseif $adveditor}-->
	<!--{if $special == 1}--><!--{template forum/post_poll}-->
	<!--{elseif $special == 2 && ($_GET[action] != 'edit' || ($_GET[action] == 'edit' && ($thread['authorid'] == $_G['uid'] && $_G['group']['allowposttrade'] || $_G['group']['allowedittrade'])))}--><!--{template forum/post_trade}-->
	<!--{elseif $special == 3}--><!--{template forum/post_reward}-->
	<!--{elseif $special == 4}--><!--{template forum/post_activity}-->
	<!--{elseif $special == 5}--><!--{template forum/post_debate}-->
	<!--{elseif $specialextra}--><div class="specialpost s_clear">$threadplughtml</div>
	<!--{/if}-->
<!--{/if}-->
<!--{if $_GET[action] == 'reply' && $quotemessage}-->
	<div class="gg-sq-lznr gg-fb-hfms cl">
		<div class="gg-sq-nrzt">
			$quotemessage
		</div>
	</div>
<!--{/if}-->