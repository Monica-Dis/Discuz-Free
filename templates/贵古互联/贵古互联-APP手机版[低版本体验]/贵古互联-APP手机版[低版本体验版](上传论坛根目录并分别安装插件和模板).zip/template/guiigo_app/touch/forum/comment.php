<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="repcomment item-content">
	<form method="post" 
		autocomplete="off" 
		id="commentform" 
		action="forum.php?mod=post&action=reply&comment=yes&tid=$post[tid]&pid=$_GET[pid]&extra=$extra{if !empty($_GET[page])}&page=$_GET[page]{/if}&commentsubmit=yes&infloat=yes"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{tid:'$post[tid]',pid:'$_GET[pid]'},fn:{if $_GET['fn']}'$_GET['fn']'{/if},load:'true',title:'{lang guiigo_manage:tlang0104}',class:'gg-sq-dptc',confirm:'{lang guiigo_manage:tlang0086}',cancel:'{lang guiigo_manage:tlang0105}'}">
		<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
		<input type="hidden" name="handlekey" value="$_GET['handlekey']" />
		<div class="item-inner">
			<div class="item-input">
				<textarea rows="2" cols="50" name="message" id="commentmessage" onKeyUp="strLenCalc(this, 'checklen')" tabindex="2" class="guiigo-px dptc-srkk bg-e" placeholder="{lang guiigo_manage:tlang0107}"  style="overflow:auto"></textarea>
			</div>
		</div>
		<!--{if $secqaacheck || $seccodecheck}-->
			<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
		<div class="dptc-zsxz zy-c">{lang comment_message1} <i id="checklen" class="zy-b">200</i> {lang comment_message2}</div>
		<button type="submit" id="commentsubmit" value="true" name="commentsubmit" tabindex="3" style="display: none;">{lang publish}</button>
		<script type="text/javascript" reload="1">
        Dz('commentmessage').focus();
		</script>
	</form>
</div>
<!--{template common/footer}-->