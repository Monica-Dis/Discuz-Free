<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if !$post['message'] && (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0)))}-->
	<div class="gg-sq-wdlfj bg-p bk-d zy-b"><i class="icon guiigoapp-tishi zy-b"></i>{lang viewthread_trade_message1}<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&firstpid=$post[pid]&addtrade=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}"">{lang viewthread_trade_message2}</a><br/>{lang guiigo_manage:tlang0399} <a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="z pn">{lang post_add_aboutcounter}</a></div>
<!--{else}-->
	$post[message]
<!--{/if}-->
	<div class="gg-sq-szbt bg-e bk-e">
		<div class="szbt-glxx cl">
		<!--{if !$_G['forum_thread']['is_archived'] && ($_G['uid'] == $_G['forum_thread']['authorid'] || $_G['group']['allowedittrade'])}-->
		
		
			<!--<a href="forum.php?mod=misc&action=tradeorder&tid=$_G[tid]{if !empty($_GET['from'])}&from=$_GET['from']{/if}" class="zy-l" onclick="showWindow('tradeorder', this.href)">{lang trade_displayorder}</a>-->
			
			
			<!--{if $_G['uid'] == $_G['forum_thread']['authorid']}-->
				<!--{if $_G['group']['allowposttrade']}-->
					<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&firstpid=$post[pid]&addtrade=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}" class="zy-l">{lang trade_add_post}</a>
				<!--{/if}-->
				
				
				<!--<a href="javascript:;" class="zy-l" onclick="window.open('home.php?mod=space&uid=$_G[uid]&do=trade&view=tradelog','','');return false;">{lang my_trade_stat}</a>-->
				
				
			<!--{/if}-->
		<!--{/if}-->
		</div>
		<h2 class="zy-f"><i class="icon guiigoapp-shangpin zy-b"></i>{lang post_trade_totalnumber}: $tradenum</h2>
	</div>
<!--{if $tradenum}-->
	<!--{if $trades}-->
		<div class="gg-sq-sznr list-block-no xh-b yh-a zh-a cl">
			<ul>
			<!--{loop $trades $key $trade}-->
			<!--{if $tradepostlist[$trade[pid]]['invisible'] == 0}-->
				<li id="trade$trade[pid]">
					<!--{if $trade['displayorder'] > 0}--><div class="sznr-tjsp"><i class="icon guiigoapp-tuijian zy-m"></i></div><!--{/if}-->
					<a href="forum.php?mod=viewthread&do=tradeinfo&tid=$_G[tid]&pid=$trade[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}">
						<div class="sznr-sptp bg-e">
						<!--{if $trade['thumb']}-->
							<img lazySrc="$trade[thumb]" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
						<!--{else}-->
							<img lazySrc="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-wt.jpg" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
						<!--{/if}-->
							<span class="sptp-sysj ab-e zy-a zs-a">{lang guiigo_manage:tlang0348} $trade[totalitems] {lang guiigo_manage:tlang0349}</span>
						</div>
						<h4 class="zy-h sh-a">$trade[subject]</h4>
						<p class="sznr-pzdq zy-g">
							<!--{if $trade['quality'] == 1}--><span class="bg-j zy-a">{lang trade_new}</span><!--{elseif $trade['quality'] == 2}--><span class="bg-j zy-a">{lang trade_old}</span><!--{/if}-->
							<!--{if $trade[locus]}-->$trade[locus]<!--{/if}-->
						</p>
						<p class="sznr-jgjf zy-b">
							<!--{if $trade[price] > 0}-->
								<span>{lang guiigo_manage:tlang0347}</span>$trade[price]
							<!--{/if}-->
							<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
								<em class="zy-g"><!--{if $trade['price'] > 0}-->{lang trade_additional}<!--{/if}--> $trade[credit]{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</em>
							<!--{/if}-->
						</p>
					</a>
				</li>
			<!--{/if}-->
			<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
<!--{else}-->
	<div class="gg-sq-zwhf bg-c">
		<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
		<p class="zy-c">{lang trade_nogoods}</p>
	</div>
<!--{/if}-->