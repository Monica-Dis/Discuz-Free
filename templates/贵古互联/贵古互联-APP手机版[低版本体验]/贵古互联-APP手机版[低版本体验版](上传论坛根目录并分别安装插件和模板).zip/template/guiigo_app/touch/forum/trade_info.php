<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="trade-info">
	<!--{if $postlist[$post[pid]]['invisible'] != 0}-->
	<header class="bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0352}</h1>
	</header>
	<!--{/if}-->
	<div class="content content-bss">
		<!--{if $postlist[$post[pid]]['invisible'] == 0}-->
		<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-kbhddb"
		ck-cus="true" 
		ck-param="{ftcolo:{sta:'#ffffff',end:'#666666',class:['title','guiigoapp-xzfh','guiigoapp-mkbtgd','guiigoapp-caidan']},rollt:'50',ori:'false',type:1}">
			<a class="button button-link pull-left open-panel guiigo-kjfh zy-a anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan"></i></a>
			<a class="button button-link pull-left back guiigo-kjfh zy-a anvbks"><i class="icon guiigoapp-xzfh"></i></a>
			<!--{if !$_G['forum_thread']['is_archived']}-->
				<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] < $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && !$post['first'] || $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
					<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd"></i></a>
				<!--{/if}-->
			<!--{/if}-->
			<h1 class="title">{lang guiigo_manage:tlang0352}</h1>
		</header>
		<!--{/if}-->
		<div class="list-block">
		<!--{if !$_G['forum_thread']['is_archived']}-->
			<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] < $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && !$post['first'] || $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
				<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
					<div class="guiigo-barcd list-block-no bg-c">
						<ul>
							<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
							<li><a href="javascript:;" class="zy-f xh-b" 
							onclick="modaction(this,'delpost')"
							ck-cus="true"
							ck-param="{type:'modal',callpar:{pid:'$_GET[pid]',tid:'$_G[tid]',fid:'$_G[fid]'},fn:'MsgCallModmenu',load:'true',uid:'$_G[uid]'}"
							><i class="icon guiigoapp-shanchu"></i>{lang guiigo_manage:tlang0353}</a></li>
							<!--{/if}-->
							<li><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="zy-f xh-b"><i class="icon guiigoapp-fbxhfb"></i>{lang edit_trade}</a></li>
							<li><a href="javascript:;" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');" class="zy-f"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						</ul>
					</div>
				</div>	
			<!--{/if}-->
		<!--{/if}-->
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
		<!--{if $postlist[$post[pid]]['invisible'] != 0}-->
			<div class="guiigo-wnrtx">
				<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
				<p class="zy-c">{lang post_trade_removed}</p>
			</div>
		<!--{else}-->
			<div class="gg-sq-sxtb bg-c xh-b">
				<div id="share_img" class="sxtb-sptp">
					<!--{if $trade['thumb']}-->
						<img src="$trade[thumb]" alt="$trade[subject]" />
					<!--{else}-->
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/spwt.jpg" alt="$trade[subject]" />
					<!--{/if}-->
					<!--{if $trade['displayorder'] > 0}--><div class="sptp-tjsp zy-a">{lang post_trade_sticklist}</div><!--{/if}-->
				</div>
				<div class="sxtb-spxx">
					<h2 id="share_title" class="zy-e">$trade[subject]</h2>
					<div class="spxx-spjg">
						<!--{if $trade[price] > 0}-->
							<span class="spjg-xjys zy-b">{lang guiigo_manage:tlang0347} <em>$trade[price] </em><!--{/if}--><!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}--><!--{if $trade[price] > 0}-->{lang trade_additional} <!--{/if}-->$trade[credit] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}</span>
						<!--{/if}-->
						<!--{if $trade[price] && $trade['costprice'] > 0 || $_G['setting']['creditstransextra'][5] != -1 && $trade[credit] && $trade['costcredit'] > 0}-->
							<span class="spjg-yjys zy-g">{lang trade_costprice}: <!--{if $trade['costprice'] > 0}--><del>$trade[costprice] {lang payment_unit}</del> <!--{/if}--><!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade['costcredit'] > 0}--><del><!--{if $trade[costprice] > 0}-->{lang trade_additional} <!--{/if}-->$trade[costcredit] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}</del><!--{/if}--></span>
						<!--{/if}-->
					</div>
					<div class="spxx-spsj list-block-no zy-g cl">
						<ul>
							<li>{lang post_trade_number}: $trade[amount]</li>
							<li style="text-align:center;">{lang post_trade_buynumber}: $trade[totalitems]</li>
							<li style="text-align:right;"><!--{if $trade['quality'] == 1}-->{lang trade_new}<!--{/if}--><!--{if $trade['quality'] == 2}-->{lang trade_old}<!--{/if}-->{lang trade_type_buy}</li>
						</ul>
					</div>
				</div>
			</div>
			<div class="gg-sq-sxdy list-block-no ms-a bg-c sh-a xh-b">
				<ul>
					<!--{if $trade[locus]}--><li class="xh-b zy-c">{lang trade_locus}: <em class="zy-h">$trade[locus]</em></li><!--{/if}-->
					<li class="xh-b zy-c">{lang trade_transport}: <em class="zy-h"><!--{if $trade['transport'] == 0}-->{lang post_trade_transport_offline}<!--{/if}-->
							<!--{if $trade['transport'] == 1}-->{lang post_trade_transport_seller}<!--{/if}-->
							<!--{if $trade['transport'] == 2 || $trade['transport'] == 4}-->
								<!--{if $trade['transport'] == 4}-->{lang post_trade_transport_physical}<!--{/if}-->
								<!--{if !empty($trade['ordinaryfee']) || !empty($trade['expressfee']) || !empty($trade['emsfee'])}-->
									<!--{if !empty($trade['ordinaryfee'])}-->{lang post_trade_transport_mail} $trade[ordinaryfee] {lang payment_unit}<!--{/if}-->
									<!--{if !empty($trade['expressfee'])}--> {lang post_trade_transport_express} $trade[expressfee] {lang payment_unit}<!--{/if}-->
									<!--{if !empty($trade['emsfee'])}--> EMS $trade[emsfee] {lang payment_unit}<!--{/if}-->
								<!--{elseif $trade['transport'] == 2}-->
									{lang post_trade_transport_none}
								<!--{/if}-->
							<!--{/if}-->
							<!--{if $trade['transport'] == 3}-->{lang post_trade_transport_virtual}<!--{/if}--></em></li>
					<li class="zy-c">{lang trade_remaindays}: <em class="zy-h"><!--{if $trade[closed]}-->
							{lang trade_timeout}
						<!--{elseif $trade[expiration] > 0}-->
							{$trade[expiration]} {lang days} {$trade[expirationhour]} {lang trade_hour}
						<!--{elseif $trade[expiration] == 0}-->
							{$trade[expirationhour]} {lang trade_hour}
						<!--{elseif $trade[expiration] == -1}-->
							{lang trade_timeout}
						<!--{else}-->
							&nbsp;
						<!--{/if}--></em></li>
				</ul>
			</div>
			<div class="gg-sq-sxmx ms-a bg-c sh-a xh-b">
				<div class="sxmx-lxmj xh-b">
					<a href="javascript:;"
						class="{if !$_G[uid]}login{else}getpm-popup{/if} lxmj-lxan bk-b zy-b"
						{if $_G[uid]}data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$post[authorid]&touid=$post[authorid]&pmid=0&daterange=2" 
						external{/if}>{lang guiigo_manage:tlang0355}</a>
					<a href="home.php?mod=space&uid=$trade[sellerid]&do=profile" class="lxmj-mjtx"><!--{avatar($trade[sellerid],small)}--></a>
					<a href="home.php?mod=space&uid=$trade[sellerid]&do=profile" class="lxmj-mjmc zy-l">$trade[seller]</a>
					<!--{if $_G['setting']['verify']['enabled']}-->
						<!--{loop $_G['setting']['verify'] $vid $verify}-->
							<!--{if $verify['available'] && $post['verify'.$vid] == 1}-->
								<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" class="lxmj-mjrz"><img src="$verify[icon]" class="vm" alt="$verify[title]" title="$verify[title]" /></a>
							<!--{/if}-->
						<!--{/loop}-->
					<!--{/if}-->
				</div>
				<div class="sxmx-mjxy zy-h">
					{lang trade_seller_real_name}: <!--{if $post[realname]}-->$post[realname]<!--{/if}--><br/>
					{lang eccredit_sellerinfo}: $post[buyercredit]&nbsp;<img src="{STATICURL}image/traderank/buyer/$post[buyerrank].gif" border="0" style="vertical-align: middle"><br/>
					{lang eccredit_buyerinfo}: $post[sellercredit]&nbsp;<img src="{STATICURL}image/traderank/seller/$post[sellerrank].gif" border="0" style="vertical-align: middle"><br/>
				</div>
			</div>
			<div class="gg-sq-smjs ms-a bg-c sh-a xh-b">
				<h2 class="xh-b zy-h">{lang guiigo_manage:tlang0356}</h2>
				<div class="smjs-jsnr zy-h">$post[message]</div>
			</div>
			<div class="gg-sq-spdp ms-a bg-c sh-a xh-b">
				<h2 class="xh-b zy-h">{lang guiigo_manage:tlang0357}</h2>
				<!--{if !$_G[inajax]}-->
				<div id="comment_$post[pid]" class="spdp-dpon"></div>
				<!--{/if}-->
				<!--{if !$_G[inajax] && $post[comment]}-->
				<script type="text/javascript" reload="1">
				ck8(function(){
					var url = 'forum.php?mod=misc&action=commentmore&tid=$post[tid]&pid=$post[pid]';
					ajaxget(false,url,'comment_$post[pid]',false);
					
				})
				</script>
				<!--{/if}-->
			</div>
			<!--{if $usertrades}-->
			<div class="gg-sq-qtsp ms-a bg-c sh-a xh-b">
				<h2 class="xh-b zy-h">{lang guiigo_manage:tlang0358}</h2>
				<div class="gg-sq-sznr qtsp-yssd list-block-no cl">
					<ul>
					<!--{loop $usertrades $usertrade}-->
						<li>
							<!--{if $usertrade['displayorder'] > 0}--><div class="sznr-tjsp"><i class="icon guiigoapp-tuijian zy-m"></i></div><!--{/if}-->
							<a href="forum.php?mod=viewthread&tid=$usertrade[tid]&do=tradeinfo&pid=$usertrade[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}">
								<div class="sznr-sptp bg-e">
								<!--{if $usertrade['aid']}-->
									<img lazySrc="{echo getforumimg($usertrade[aid])}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
								<!--{else}-->
									<img lazySrc="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-wt.jpg" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy">
								<!--{/if}-->
									<span class="sptp-sysj ab-e zy-a zs-a">{lang guiigo_manage:tlang0348} $usertrade[totalitems] {lang guiigo_manage:tlang0349}</span>
								</div>
								<h4 class="zy-h sh-a">$usertrade[subject]</h4>
								<p class="sznr-pzdq zy-g">
									<!--{if $usertrade['quality'] == 1}--><span class="bg-j zy-a">{lang trade_new}</span><!--{elseif $usertrade['quality'] == 2}--><span class="bg-j zy-a">{lang trade_old}</span><!--{/if}-->
									<!--{if $usertrade[locus]}-->$usertrade[locus]<!--{/if}-->
								</p>
								<p class="sznr-jgjf zy-b">
									<!--{if $usertrade[price] > 0}-->
										<span>{lang guiigo_manage:tlang0347}</span>$usertrade[price]
									<!--{/if}-->
									<!--{if $_G['setting']['creditstransextra'][5] != -1 && $usertrade[credit]}-->
										<em class="zy-g"><!--{if $usertrade['price'] > 0}-->{lang trade_additional}<!--{/if}--> $usertrade[credit]{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</em>
									<!--{/if}-->
								</p>
							</a>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
			</div>
			<!--{/if}-->
		<!--{/if}-->
		$guiigo_config['footer_html']
		</div>
	</div>
	<div class="bar bar-rep list-block-no gg-sq-spgm bg-c">
		<ul>
			<li><a href="forum.php?mod=misc&action=comment&pid=$post[pid]" 
					class="dialog link yh-b zy-c"
					ck-cus="true" 
					ck-param="{type:'modal',load:'true',fn:'MsgCallComment',uid:'$_G[uid]'}"
					external><i class="icon guiigoapp-fbxhfb"></i><p>{lang guiigo_manage:tlang0104}</p></a></li>
			<li><a href="JavaScript:void(0)" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');" class="yh-b zy-c"><i class="icon guiigoapp-tbxhfx"></i><p>{lang guiigo_manage:tlang0354}</p></a></li>
			<li class="spgm-gman">
				<a href="javascript:;"
					class="{if !$_G[uid]}login{else}getpm-popup{/if} bg-h zy-a zy-ac" 
					<!--{if $_G[uid]}-->data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$post[authorid]&touid=$post[authorid]&pmid=0&daterange=2"
					external<!--{/if}-->>{lang guiigo_manage:tlang0355}</a>
			</li>
			<!--{if $trade[amount]}-->
			<li class="spgm-gman"><a href="forum.php?mod=trade&tid=$post[tid]&pid=$post[pid]" class="bg-j zy-a">{lang guiigo_manage:tlang0121}</a></li>
			<!--{else}-->
			<li class="spgm-gman"><a href="JavaScript:void(0)" class="bg-i zy-h">{lang guiigo_manage:tlang0359}</a></li>
			<!--{/if}-->
		</ul>
	</div>
	<div class="popup-actions" id="guiigo-nrdbfx">
		<div class="actions-text guiigo-hdfx">
			<div class="gg-app-hide hdfx-hdxm xh-b bg-e">
				<a href="javascript:;"  data-app="weixin" class="nativeShare weixin zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wx.png" class="vm"></span>{lang guiigo_manage:tlang0153}</a>
				<a href="javascript:;" data-app="weixinFriend" class="nativeShare weixin_timeline zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/pyq.png" class="vm"></span>{lang guiigo_manage:tlang0154}</a>
				<a href="javascript:;" data-app="QQ" class="nativeShare qq zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/qq.png" class="vm"></span>{lang guiigo_manage:tlang0155}</a>
				<a href="javascript:;" data-app="QZone" class="nativeShare qzone zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kj.png" class="vm"></span>{lang guiigo_manage:tlang0156}</a>
				<a href="javascript:;" data-app="sinaWeibo" class="nativeShare weibo zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wb.png" class="vm"></span>{lang guiigo_manage:tlang0157}</a>
			</div>
			<div class="hdfx-hdxm bg-e">
				<a href="javascript:;" class="zy-f zd-12" onclick="copy(this);" id="cptextid"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/fz.png" class="vm"></span>{lang guiigo_manage:tlang0158}</a>
			</div>
			<div class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</div>
		</div>
	</div>
	<div class="share-layer"></div>
<script>
ck8(function(){
	if(ck8('#focbtn').length > 0){
		ck8('#focbtn').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('#rewardbut').length > 0){
		ck8('#rewardbut').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('.debatereply').length > 0){
		ck8('.debatereply').click(function(e){
			Dz('needmessage').focus()
		})
	}
})

function ShareAlltrade(){
	//�õ���������
		var config = getShareData('#share_title','#share_img');
	<!--{if ($guiigo_config['browser']['isqq'] || $guiigo_config['browser']['isuc']) && !$guiigo_config['browser']['iswx']}-->
		//����� UC qq �����
		nativeShare(config);
	<!--{elseif $guiigo_config['browser']['iswx']}-->
		//�����΢�������
		wxshareJssdkAjax(config)
	<!--{else}-->
		//������� ΢������� UC qq �����
		webShare(config)
	<!--{/if}-->
}

function showMn(){
	var Obj = $('.guiigo-barcd-s')
	if(Obj.css('display') == 'none'){
		Obj._show(200)
	}else{
		Obj.hide()
	}
}

function MsgCallComment(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (par.pid && par.tid && msg.msg.indexOf('{lang guiigo_manage:tlang0204}') != -1){
			ck8.toast(msg.msg);
			ck8('#commentmessage').val('')
			ck8.closeModal('.popup-about-js')
			ck8.ajax({
				type:'POST',
				url:'forum.php?mod=misc&action=commentmore&tid='+ par.tid +'&pid='+ par.pid +'&inajax=1',
				dataType:'xml',
				success: function(s){
					var obj = ck8('#comment_'+ par.pid);
					if(!obj.hasClass('ck8-comment')) obj.addClass('ck8-comment');
					obj.html(app.initAtr(s.lastChild.firstChild.nodeValue));
				}
			})
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0205}') != -1){
			ck8.alert('{lang guiigo_manage:tlang0206}', '{lang guiigo_manage:tlang0042}', function () {
			   ck8.closeModal('.popup-about-js')
			})
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallModmenu(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if(msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1){
			if(param.action && param.action == 'delcomment' && param.pid){
				ck8.toast('{lang guiigo_manage:tlang0173}');
				ck8('#delcomment_'+ param.pid).remove()
				var obj = ck8.trim(ck8('#comment_'+ param.cpid).html());
				if(!obj || obj == ''){
					ck8('#comment_'+ param.cpid).removeClass('ck8-comment')
				}
			}else{
				ck8.toast(msg.msg);
			}
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}
</script>
</div>
<!--{template common/footer}-->