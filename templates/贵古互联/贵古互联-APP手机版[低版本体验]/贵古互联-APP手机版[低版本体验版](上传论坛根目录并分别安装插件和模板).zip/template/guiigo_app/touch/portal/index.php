<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval $navs = $guiigo_config[appsetting][nav];}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="index">
	<header class="gg-app-hide bar bar-nav bg-a yb-a">
		<a class="button button-link pull-left open-panel"><i class="icon guiigoapp-txcl zy-a zy-ac yz-a"></i><span class="bar-tx"><!--{avatar($_G[uid])}--></span></a>
		<a href="search.php?mod=forum" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-a zy-ac yz-a"></i></a>
		<h1 class="title zy-a zy-ac yz-a">$guiigo_config['site_name']</h1>
	</header>
	<!--{template common/footer_nav}-->
	<div class="content infinite-scroll index-scroll">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config[appsetting][second_level_channel]}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
				<div class="swiper-container bg-c xh-b guiigo-syse" id="ck8-nav">
					<div class="swiper-wrapper">
						<!--{if $guiigo_config[appsetting][user_interest]}-->
							<div class="swiper-slide" style="width:0px;">
								<span>{lang guiigo_manage:tlang0002}</span>
							</div>
						<!--{/if}-->
						<div class="swiper-slide" style="width:0px;">
							<span>{lang guiigo_manage:tlang0040}</span>
						</div>
						<!--{loop $navs $nal}-->
						<div class="swiper-slide" style="width:0px;">
							<span>{$nal['channelname']}</span>
						</div>
						<!--{/loop}-->
						<div class="navbar">
							<div class="color"></div>
						</div>
					</div>
				</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="swiper-container" id="nav-page">
				<div class="swiper-wrapper">
				<!--{if $guiigo_config[appsetting][user_interest]}-->
					<div id="loadpage_user_interest"
						class="swiper-slide" 
						data-scrollTopEnd="1" 
						data-page="0" 
						data-orderid="user_interest" 
						data-loadstate="1"
						data-scrollTop="0">
						<div class="appendpage"></div>
						<div class="infinite-scroll-preloader guiigo-zdjz" id="scroll-preloader_user_interest"></div>
					</div>
				<!--{/if}-->
				<div id="loadpage_recommend_content"
					class="swiper-slide" 
					data-scrollTopEnd="1" 
					data-page="0" 
					data-orderid="recommend_content" 
					data-loadstate="1"
					data-scrollTop="0">
					<div class="appendpage"></div>
					<div class="infinite-scroll-preloader guiigo-zdjz" id="scroll-preloader_recommend_content"></div>
				</div>
				<!--{loop $navs $k $pageval}-->
				<div id="loadpage_{$pageval[order]}" 
					class="swiper-slide" 
					data-scrollTopEnd="1" 
					data-page="0" 
					data-orderid="{$pageval[order]}" 
					data-loadstate="1"
					data-scrollTop="0">
					<div class="appendpage"></div>
					<div class="infinite-scroll-preloader guiigo-zdjz" id="scroll-preloader_{$pageval[order]}"></div>
				</div>
				<!--{/loop}-->
				</div>
			</div>
			<!--{else}-->
				<div id="loadpage_nocontent"
					class="nocontent-min" 
					data-scrollTopEnd="1" 
					data-page="0" 
					data-orderid="nocontent" 
					data-loadstate="1"
					data-scrollTop="0">
					<div class="appendpage"></div>
					<div class="infinite-scroll-preloader guiigo-zdjz" id="scroll-preloader_nocontent"></div>
				</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div><!-- list-block -->
	</div><!-- class="content" -->
<script>
function MsgCallFn(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = $('.followmod_'+ par.fuid +'');
		var foObj = $('#recommend_add_'+ param.tid +'');
		var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
			$.toast('{lang guiigo_manage:tlang0003}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
			Obj.attr('ck-confirm','true')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			$.toast('{lang guiigo_manage:tlang0009}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
			Obj.attr('ck-confirm','false')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			$.toast('{lang guiigo_manage:tlang0007}');
		}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
			foObj.addClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzanon"></i>');
			$('#recommend_add_sum'+ param.tid).html(''+ (recommendcut + parseInt(par.recommendv)));
			$.toast('{lang guiigo_manage:tlang0045}');
			if(par.daycount){
				setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
			}
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
			$.toast('{lang guiigo_manage:tlang0049}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
			$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
				$.router.load('home.php?mod=spacecp&ac=usergroup');
			});
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
			$.toast('{lang guiigo_manage:tlang0053}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
			$.toast('{lang guiigo_manage:tlang0055}');
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}

function MsgCallFntj(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = $('.followmod_'+ par.fuid +'');
		var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
			$.toast('{lang guiigo_manage:tlang0003}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('ab-b').removeClass('ab-a').html('{lang guiigo_manage:tlang0003}')
			Obj.attr('ck-confirm','true')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			$.toast('{lang guiigo_manage:tlang0009}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('ab-a').removeClass('ab-b').html('{lang guiigo_manage:tlang0002}')
			Obj.attr('ck-confirm','false')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			$.toast('{lang guiigo_manage:tlang0007}');
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}

function MsgCallFnkp(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = $('.followmod_'+ par.fuid +'');
		var foObj = $('#recommend_add_'+ param.tid +'');
		if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0057}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
			foObj.addClass('zy-i');
			$.toast('{lang guiigo_manage:tlang0058}');
			if(par.daycount){
				setTimeout(function(){$.toast('{lang guiigo_manage:tlang0059}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
			}
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
			$.toast('{lang guiigo_manage:tlang0060}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
			$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
				$.router.load('home.php?mod=spacecp&ac=usergroup');
			});
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
			$.toast('{lang guiigo_manage:tlang0061}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
			$.toast('{lang guiigo_manage:tlang0062}');
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}
</script>
</div>
<!--{template common/footer}-->
