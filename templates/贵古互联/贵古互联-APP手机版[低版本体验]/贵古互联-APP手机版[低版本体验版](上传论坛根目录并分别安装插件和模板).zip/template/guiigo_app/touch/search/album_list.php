<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="gg-ss-amjg">
	<div class="gg-ss-jgbt xh-b zy-g"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
	<!--{if empty($albumlist)}-->
		<div class="guiigo-wnrtx">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
			<p class="zy-c">{lang guiigo_manage:tlang0882}</p>
		</div>
	<!--{else}-->
		<div class="gg-kj-amzt">
			<div class="amzt-yssz list-block-no bg-c">
				<ul class="list-container">
					<!--{loop $albumlist $key $value}-->
					<li>
						<a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]">
							<!--{if $value[pic]}--><img src="$value[pic]"><!--{/if}-->
							<span class="amzt-xcsl zy-a"><i class="icon guiigoapp-tupian zy-a"></i>$value[picnum]</span>
							<span class="amzt-xcmc">$value[albumname]</span>
						</a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}-->
		<div class="infinite-scroll-preloader guiigo-zdjz">
			<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
		</div>
	<!--{/if}-->
</div>
