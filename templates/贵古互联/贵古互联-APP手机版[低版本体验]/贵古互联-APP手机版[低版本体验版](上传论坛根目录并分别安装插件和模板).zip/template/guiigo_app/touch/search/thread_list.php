<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="gg-ss-amjg">
	<div class="gg-ss-jgbt xh-b zy-g">
		<!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}-->
	</div>
	<!--{if empty($threadlist)}-->
		<div class="guiigo-wnrtx">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
			<p class="zy-c">{lang guiigo_manage:tlang0882}</p>
		</div>
	<!--{else}-->
		<div class="guiigo-ztlb gg-ss-tzss list-block-no bg-g">
			<ul class="list-container">
			<!--{eval $postlists=GuiigoApp::GetPostlist($threadlist);}-->
				<!--{loop $threadlist $thread}-->
					<!--{eval $pidarr=GuiigoApp::getpostfirstbypid($thread[tid]);}-->	
					<!--{if $post['closed'] > 1 || $post['moved']}-->
						<!--{eval $post[tid]=$post[closed];}-->
					<!--{/if}-->
					<!--{if (!$_G['setting']['mobile']['mobiledisplayorder3'] && $post['displayorder'] > 0) ||  $post['displayorder'] < 0}-->
						{eval continue;}
					<!--{/if}-->
					<!--{eval $gender = GuiigoApp::getUserList($thread['authorid'],'profile');}-->
					<!--{eval $member = getuserbyuid($thread['authorid']);}-->
					<!--{eval $follow = GuiigoApp::getUserList($_G['uid'],'follow');}-->
					<!--{eval $verifys=GuiigoApp::getUserList($thread['authorid'],'verify');}-->
					<li class="gztlb-ztys bg-c xh-b sh-a">
						<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><!--{elseif $thread['digest'] > 0}-->
							<div class="gztlb-jhzt"><i class="icon guiigoapp-jinghua zy-i"></i></div>
						<!--{/if}-->
						<div class="gztlb-tbyh">
							<div class="tbyh-lztx guiigo-ty"><!--{if $thread['authorid'] && $thread['author']}--><a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><!--{avatar($thread[authorid],middle)}--></a><!--{else}--><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg"><!--{/if}--></div>
							<div class="tbyh-mcxx">
								<h1>
									<!--{if !in_array($thread['authorid'], $follow)}-->
									 <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]" 
									class="followmod_$thread[authorid] dialog mcxx-gzan zy-b bk-b"  
									ck-cus="true"
									ck-confirm="false"
									ck-param="{type:'modal',callpar:{tid:'$thread[authorid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}" 
									external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
									<!--{else}-->
									<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$thread['authorid']" 
									class="followmod_$thread[authorid] dialog mcxx-gzan zy-c bk-c bg-e" 
									ck-cus="true" 
									ck-confirm="true" 
									ck-param="{type:'modal',callpar:{tid:'$thread['authorid']'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}"  
									external >{lang guiigo_manage:tlang0003}</a>
									<!--{/if}-->
									<!--{if $thread['authorid'] && $thread['author']}--><a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="mcxx-yhmc zy-f">$thread[author]</a><!--{else}--><a href="javascript:void(0);" class="mcxx-yhmc zy-f">$_G[setting][anonymoustext]</a><!--{/if}-->
									<!--{eval $grouptitle = strip_tags($_G['cache']['usergroups'][$member['groupid']]['grouptitle']);}-->
									<span class="mcxx-yhdj zy-a" style="background: {$_G['cache']['usergroups'][$member['groupid']]['color']};">Lv.{$_G['cache']['usergroups'][$member['groupid']]['stars']}</span>
									<!--{if $gender['gender'] == 1  || $gender['gender'] == 0}-->
									<i class="icon guiigoapp-nan bg-n"></i>
									<!--{elseif $gender['gender'] == 2}-->
									<i class="icon guiigoapp-nv bg-o"></i>
									<!--{/if}-->
									<!--{if $_G['setting']['verify']['enabled']}-->
										<span class="verify-icon y">
										<!--{loop $_G['setting']['verify'] $vid $verify}-->
											<!--{if $verify['available'] && $verifys['verify'.$vid] == 1 && $verify['icon']}-->
											<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" class="ck8-avatar-icon">
											   <img src="$verify['icon']" class="vm" alt="$verify[title]" />
											</a>
											<!--{/if}-->
										<!--{/loop}-->
										</span>
									<!--{/if}-->
								</h1>
								<div class="mcxx-fbxx">
									<i class="zy-g">$thread[dateline]</i>
									<em class="zy-g"> {lang guiigo_manage:tlang0137}: <a href="forum.php?mod=forumdisplay&fid=$thread[fid]">$thread[forumname]</a></em>
								</div>
							</div>
						</div>
						<div class="gztlb-nrdy">
							<h1>
								<!--{if $thread[special] == 1}-->
									<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0138}</span>
								<!--{elseif $thread[special] == 2}-->
									<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0139}</span>
								<!--{elseif $thread[special] == 3}-->
									<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0140}</span>
								<!--{elseif $thread[special] == 4}-->
									<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0141}</span>
								<!--{elseif $thread[special] == 5}-->
									<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0142}</span>
								<!--{elseif $thread['rushreply']}-->
									<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0143}</span>
								<!--{/if}-->
								<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]>{$thread['subject']}</a>
							</h1>
							<p class="zy-c"><!--{echo cutstr($thread[message],90)}--></p>
							<!--{eval $cunm = count($postlists[$pidarr[pid]][attapic]);}-->
							<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
								<div class="nrdy-imgs">
									<ul>
									<!--{loop $postlists[$pidarr[pid]][attapic] $key $aids}-->
										<!--{if $cunm == 1}-->
											<li class="imgs-tpsa"><img lazySrc="{eval echo getforumimg($aids[2], 0, 400, 9999)}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
										<!--{elseif $cunm == 2}-->
											<li class="imgs-tpsb"><img lazySrc="{eval echo getforumimg($aids[2], 0, 300, 280)}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
										<!--{else}-->
											<li class="imgs-tpsc<!--{if $cunm > 6}--> imgs-tpsd<!--{/if}-->"><img lazySrc="{eval echo getforumimg($aids[2], 0, 300, 280)}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/><!--{if $cunm > 6}--><div class="tpsd-gdtp"><span class="tpsd-jtnr"><i class="icon guiigoapp-mkbtgd"></i><!--{eval echo $cunm}--></span></div><!--{/if}--></li>
										<!--{/if}-->
										<!--{if $key >= 5}-->
											<!--{eval break;}-->
										<!--{/if}-->
									<!--{/loop}-->
									</ul>
								</div>
							</a>
						</div>
						<div class="gztlb-ztcz">
							<ul>
								<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-huifu"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[replies])}--><!--{else}-->$thread[replies]<!--{/if}--></a></li>
								<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-chakan"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[views])}--><!--{else}-->$thread[views]<!--{/if}--></a></li>
								<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
									<!--{eval $recommenus=GuiigoApp::getrecommendbyid($thread[tid],$_G[uid]);}-->
									<li class="ztcz-ybcz">
										<div class="ztcz-dzkz{if $recommenus} zy-b bg-m{else} zy-c bg-l{/if}" id="recommend_add_$thread[tid]">
											<a href="forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&hash={FORMHASH}&handlekey=recommend_add"  
												class="dialog " 
												ck-cus="true"
												ck-param="{
													type:'modal',
													callpar:{tid:'$thread[tid]'},
													fn:'MsgCallFn',
													load:'true',
													uid:'{$_G[uid]}'
												}" 
												external ><i class="icon{if $recommenus} guiigoapp-dianzanon{else} guiigoapp-dianzan{/if}"></i>
											</a>
											<em id="recommend_add_sum$thread[tid]"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[recommend_add])}--><!--{else}-->$thread[recommend_add]<!--{/if}--></em>
										</div>
									</li>
								<!--{/if}-->
							</ul>
						</div>
					</li>
				<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($multipage)}-->
	<div class="infinite-scroll-preloader guiigo-zdjz">
		<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
	</div>
	<!--{/if}-->
</div>