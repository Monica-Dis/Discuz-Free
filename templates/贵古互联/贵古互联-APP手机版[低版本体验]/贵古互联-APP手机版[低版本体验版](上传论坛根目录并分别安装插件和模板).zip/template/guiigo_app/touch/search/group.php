<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="search">
	<header class="bar bar-nav guiigo-ssdb guiigo-flex bg-c">
		<div class="ssdb-ssxs guiigo-flexy bg-g">
			<form class="searchform" method="post" autocomplete="off" action="search.php?mod=group" onsubmit="if($('scform_srchtxt')) searchFocus($('scform_srchtxt'));">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="srchfid" value="$srchfid" />
				<!--{subtemplate search/pubsearch}-->
			</form>
		</div>
		<a class="button button-link pull-right back"><i class="icon guiigoapp-guanbix zy-c"></i></a>
	</header>
	<div class="content infinite-scroll search-scroll gg-ss-sson bg-c gg-yjms"
	data-url="search.php?mod=group&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes" 
	{if $viewgroup}data-pages="{$index['num']}" {else}data-pages="{$groupnum}" {/if}
	data-ppp="{$_G['tpp']}" 
	data-page="$page" 
	data-islod="false" 
	data-distance="10">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
				<!--{if $srchfid}-->
					<!--{subtemplate search/thread_list}-->
				<!--{else}-->
					<!--{subtemplate search/group_list}-->
				<!--{/if}-->
			<!--{else}-->
				<!--{if $_G['setting']['srchhotkeywords']}-->
				<div class="gg-ss-rmss">
					<div class="rmss-btys zy-g">{lang guiigo_manage:tlang0881}</div>
					<!--{loop $_G['setting']['srchhotkeywords'] $val}-->
					<!--{if $val=trim($val)}-->
					<!--{eval $valenc=rawurlencode($val);}-->
					<!--{block srchhotkeywords[]}-->
						<!--{if !empty($searchparams[url])}-->
							<a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}" class="bg-g zy-h">$val</a>
						<!--{else}-->
							<a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch" class="bg-g zy-h">$val</a>
						<!--{/if}-->
					<!--{/block}-->
					<!--{/if}-->
					<!--{/loop}-->
					<!--{echo implode('', $srchhotkeywords);}-->
				</div>
				<!--{/if}-->
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	function MsgCallFn(msg,par,param) {
		if(typeof msg === 'object' || typeof par === 'object'){
			var Obj = $('.followmod_'+ par.fuid +'');
			var foObj = $('#recommend_add_'+ param.tid);
			var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
				$.toast('{lang guiigo_manage:tlang0003}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
				$.toast('{lang guiigo_manage:tlang0009}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
				$.toast('{lang guiigo_manage:tlang0010}');
			}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
				foObj.addClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzanon"></i>');
				$('#recommend_add_sum'+ param.tid).html(''+ (recommendcut + parseInt(par.recommendv)));
				$.toast('{lang guiigo_manage:tlang0045}');
				if(par.daycount){
					setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
				}
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
				$.toast('{lang guiigo_manage:tlang0049}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
				$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
					$.router.load('home.php?mod=spacecp&ac=usergroup');
				});
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
				$.toast('{lang guiigo_manage:tlang0053}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
				$.toast('{lang guiigo_manage:tlang0055}');
			}else {
				$.toast(msg.msg);
			}
		}else{
			$.toast('{lang guiigo_manage:tlang0056}');
		}
	}
	function showMn(){
		var Obj = $('.guiigo-barcd-s')
		if(Obj.css('display') == 'none'){
			Obj._show(200)
		}else{
			Obj.hide()
		}
	}
	</script>
</div>
<!--{template common/footer}-->