<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset={CHARSET}">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="x5-fullscreen" content="true">
<meta name="full-screen" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes" />
<meta name="apple-touch-fullscreen" content="yes">
<meta name="apple-mobile-web-app-title" content="$navtitle">
<meta name="apple-mobile-web-app-status-bar-style" content="black" />
<meta name="format-detection" content="telephone=no" />
<meta name="format-detection" content="email=no" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<base href="$guiigo_config['domain_name']" />
<link rel="shortcut icon" href="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/favicon.ico">
<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname']  <!--{/if}--> </title>
<!--{if !$guiigo_config['default_style']}-->
<!--{eval $guiigo_config['default_style'] = 's1';}-->
<!--{/if}-->
<link rel="stylesheet" href="{$_G['siteurl']}{$_G['style']['tpldir']}/static/css/guiigo.css?{VERHASH}" type="text/css" media="all">
<link rel="stylesheet" href="{$_G['siteurl']}{$_G['style']['tpldir']}/static/css/guiigo-style.css?{VERHASH}" type="text/css" media="all">
<link rel="stylesheet" id="stylefile" href="{$_G['siteurl']}{$_G['style']['tpldir']}/static/css/guiigo-colour-$guiigo_config['default_style'].css?{VERHASH}" type="text/css" media="all">
<link rel="stylesheet" href="{$_G['siteurl']}{$_G['style']['tpldir']}/static/font/iconfont.css?{VERHASH}" type="text/css" media="all">
<script src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/js/guiigo.min.js?{VERHASH}" charset="{CHARSET}"></script>
<script type="text/javascript">
var STYLEID = '{STYLEID}', 
p = 0,
STATICURL = '{STATICURL}', 
IMGDIR = '{IMGDIR}', 
VERHASH = '{VERHASH}', 
charset = '{CHARSET}', 
discuz_uid = '$_G[uid]', 
cookiepre = '{$_G[config][cookie][cookiepre]}', 
cookiedomain = '{$_G[config][cookie][cookiedomain]}', 
cookiepath = '{$_G[config][cookie][cookiepath]}', 
showusercard = '{$_G[setting][showusercard]}', 
attackevasive = '{$_G[config][security][attackevasive]}', 
perpage = '{$_G[setting][mobile][mobiletopicperpage]}', 
postperpage = '{$_G[setting][mobile][mobilepostperpage]}', 
disallowfloat = '{$_G[setting][disallowfloat]}', 
creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', 
defaultstyle = '$_G[style][defaultextstyle]',
SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]', 
CKPATH = "{$_G['siteurl']}{$_G['style']['tpldir']}/static/",
_hash = '<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->',
_attachurl = '{$_G[setting][attachurl]}forum/',
_maxsize = '{$swfconfig[max]}',
EXTRAFUNC=[],default_style ='{$guiigo_config['default_style']}',
share_title ='{$guiigo_config['share_title']}',
share_img ='{$guiigo_config['share_img']}';

</script>
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
	var STATUSMSG = { 
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	EXTRAFUNC['validator']=[];
</script>
</head>
<body>
<div id="append_parent"></div>
<!--{template common/guiigo-style}-->
<!--{if $guiigo_config['open_spad']}-->
<script type="text/javascript">
var date = -1,mxdate='$guiigo_config['spad_line']',cunm='$guiigo_config['spad_line']';
var setcum = setInterval(function(){
	date++;
	document.getElementById('date').innerText = cunm;
	cunm--;
	if(date >= mxdate){
		if(document.readyState == 'complete'){
			clearInterval(setcum)
            document.getElementById('indexad').style.display = 'none'
			sessionStorage.setItem('indexad',1);
		}
	}
}, 1000);

document.onreadystatechange = function(){
	if(document.readyState == 'complete'){
		document.getElementById('datebut').addEventListener('click', function(){
			document.getElementById('indexad').style.display = 'none'
			clearInterval(setcum)
			sessionStorage.setItem('indexad',1);
		})
		document.getElementById('datebuts').addEventListener('click', function(){
			document.getElementById('indexad').style.display = 'none'
			clearInterval(setcum)
			sessionStorage.setItem('indexad',1);
		})
		if(sessionStorage.getItem('indexad')){
			document.getElementById('indexad').style.display = 'none'
		}
	}
}

</script>
<div id="indexad">
	<span id="datebut">{lang guiigo_manage:tlang0976}<em id="date">$guiigo_config['spad_line']</em>s</span>
	<a id="datebuts" href="$guiigo_config['spad_link']"><img src="$guiigo_config['spad_img']" class="spbg-img"/></a>
	<div class="guiigo-spxc bg-c">
		<div class="grxx-dbys">
			<div class="grxx-dbys-x"></div>
		</div>
		<img src="$guiigo_config['spad_logo']"/>
		<p class="zy-c">$guiigo_config['spad_footer_text']</p>
	</div>
</div>
<script type="text/javascript">
if(sessionStorage.getItem('indexad')){
	document.getElementById('indexad').style.display = 'none'
}
</script>
<!--{/if}-->
<!--{hook/global_header_mobile}-->
<div class="page-group">