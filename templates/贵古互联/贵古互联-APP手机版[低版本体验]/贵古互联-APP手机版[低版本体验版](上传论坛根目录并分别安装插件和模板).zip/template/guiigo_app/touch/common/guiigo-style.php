<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<style type="text/css">
<!--{if $guiigo_config['isphotoSquare']}-->
.guiigo-ty {border-radius: .2rem !important;}
.guiigo-ty img {border-radius: .2rem !important;}
.guiigo-tys img {border-radius: .2rem !important;}
<!--{else}-->
.guiigo-ty {border-radius: 50% !important;}
.guiigo-ty img {border-radius: 50% !important;}
.guiigo-tys img {border-radius: 50% !important;}
<!--{/if}-->
<!--{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'miniprogram')}-->
.gg-app-hide {display:none !important;}
.gg-app-hide~.content {top:0;}
.auto-top {top:0 !important;}
.gg-app-show {display: block;}
.guiigo-clnav .clnav-menu {top: -10rem;}
<!--{else}-->
.gg-app-show {display: none !important;}
.guiigo-clnav .clnav-menu {top: -7.5rem;}
<!--{/if}-->
</style>