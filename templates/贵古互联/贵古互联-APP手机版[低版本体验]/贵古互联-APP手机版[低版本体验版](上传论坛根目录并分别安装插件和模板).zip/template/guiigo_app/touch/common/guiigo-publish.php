<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="popup popup-about close-popup guiigo-kfon">
	<div class="kfon-kfnv bg-c">
		<div class="kfnv-xznr zy-g">{lang guiigo_manage:tlang0087}<!--{if $guiigo_config['open_reply_ad']}--><a href="$guiigo_config['ad_text_link']" class="xznr-ad">$guiigo_config['ad_text']</a><!--{/if}--></div>
		<div class="kfnv-xzon">
			<ul>
				<!--{loop $guiigo_config['appsetting']['menuconfig']['global_information_menu'] $val}-->
					<!--{if $val['global_information_menu_open'] == 1}-->
						<li><a href="$val['global_information_menu_link']"><img src="$val['global_information_menu_icon']"><p class="zy-f">$val['global_information_menu_name']</p></a></li>
					<!--{/if}-->
				<!--{/loop}-->
			</ul>
		</div>
		<div class="kfnv-clan close-popup"><i class="icon guiigoapp-cuo bg-h zy-a zy-ac"></i></div>
	</div>
</div>