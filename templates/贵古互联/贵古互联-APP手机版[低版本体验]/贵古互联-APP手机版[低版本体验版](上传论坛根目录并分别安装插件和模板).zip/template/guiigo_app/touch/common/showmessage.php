<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $param['login']}-->
	<!--{if $_G['inajax']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login&inajax=1&infloat=1');exit;}-->
	<!--{else}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
	<!--{/if}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if $_G['inajax']}-->
<div class="tip" ck-cus="true" ck-param="{typ:'modal',cancel:'{lang guiigo_manage:tlang0088}',url:'$url_forward'}">
	<div id="messagetext">
		<p>$show_message</p>
        <!--{if $_G['forcemobilemessage']}-->
        	<p>
            	<a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
                <a href="javascript:ck8.router.back();">{lang goback}</a>
            </p>
        <!--{/if}-->
		<!--{if $url_forward && !$_GET['loc']}-->
			<script type="text/javascript">
				setTimeout(function() {
					popup.close();
					var urls = '$url_forward';
					ck8.router.load(urls, true);
				}, '3000');
			</script>
		<!--{elseif $allowreturn}-->

		<!--{/if}-->
	</div>
</div>
<!--{else}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current bg-c" data-mod="showmessage">
	<header class="bar bar-nav guiigo-nydb guiigo-dydb bg bg-c">
		<a class="button button-link pull-left back zy-f" href="$url_forward" data-no-cache="true"><i class="icon guiigoapp-guanbi zy-f"></i></a>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-sq-mbts gg-sq-mbcw">
				<h1 class="zy-e">{lang guiigo_manage:tlang0089}</h1>
				<p class="zy-h">$show_message<!--{if $url_forward}-->{lang guiigo_manage:tlang0090}<a class="zy-b" href="$url_forward" data-no-cache="true">{lang guiigo_manage:tlang0091}</a> {lang guiigo_manage:tlang0092}<!--{elseif $allowreturn}-->{lang guiigo_manage:tlang0093}
				<!--{/if}--></p>
				<!--{if $_G['forcemobilemessage']}-->
					<p class="zy-h ms-b"><a href="{$_G['setting']['mobile']['pageurl']}" class="zy-b" data-no-cache="true">{lang guiigo_manage:tlang0094}</a>{lang guiigo_manage:tlang0095}</p>
				<!--{/if}-->
			</div>
		</div>
	</div>
</div>
<!--{/if}-->
<!--{template common/footer}-->