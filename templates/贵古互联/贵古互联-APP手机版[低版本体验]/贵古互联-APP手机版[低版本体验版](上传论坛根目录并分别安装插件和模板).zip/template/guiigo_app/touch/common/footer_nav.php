<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<nav class="bar bar-tab guiigo-tab bg-c">
	<a class="tab-item" href="portal.php?mod=index&mobile=2" >
		<span class="icon"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$guiigo_config['default_style']/{if CURSCRIPT == 'portal'}sy_on{else}sy{/if}.png"></span>
		<span class="tab-label{if CURSCRIPT == 'portal'} zy-be{else} zy-c{/if}">{lang guiigo_manage:tlang0076}</span>
	</a>
	<a class="tab-item{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])} tab-ksft{/if}" href="{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])}$guiigo_config['domain_name']forum.php?mod=misc&action=nav{else}$guiigo_config['domain_name']forum.php?forumlist=1&do=guanzhu{/if}" data-no-cache="true">
		<span class="icon"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$guiigo_config['default_style']/{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])}sq_kf{else}sq{/if}.png"></span>
		<span class="tab-label{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])} zy-be{else} zy-c{/if}">{if CURSCRIPT == 'forum' && (CURMODULE == 'forumdisplay' || CURMODULE == 'guide' || $_GET['forumlist'])}{lang guiigo_manage:tlang0077}{else}{lang guiigo_manage:tlang0078}{/if}</span>
	</a>
	<a class="tab-item" href="$guiigo_config['domain_name']group.php?mod=index" data-no-cache="true">
		<span class="icon"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$guiigo_config['default_style']/{if CURSCRIPT == 'group'}qz_on{else}qz{/if}.png"></span>
		<span class="tab-label{if CURSCRIPT == 'group'} zy-be{else} zy-c{/if}">{lang guiigo_manage:tlang0079}</span>
	</a>
	<a class="tab-item" href="$guiigo_config['domain_name']home.php?mod=space&do=pm&filter=privatepm" data-no-cache="true">
		<span class="icon">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$guiigo_config['default_style']/{if CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'pm'}xx_on{else}xx{/if}.png">
			<!--{eval}-->
				$cunm=0;
				foreach ($_G['notice_structure'] as $k=>$v){
					$cunm = intval($_G['member']['category_num'][$k]) + $cunm;
				}
				loaducenter();
				$newpmarr = uc_pm_checknew($_G['uid'], 1);
				$newpm = $newpmarr['newpm'];
				loaducenter();
				$announcepm  = 0;
				foreach(C::t('common_member_grouppm')->fetch_all_by_uid($_G['uid'], $filter == 'announcepm' ? 1 : 0) as $gpmid => $gpuser) {
					$gpmstatus[$gpmid] = $gpuser['status'];
					if($gpuser['status'] == 0) {
						$announcepm ++;
					}
				}
			<!--{/eval}-->
			<!--{if $cunm || $newpm || $announcepm}--><i class="guiigo-yjsz bg-j zy-a"><!--{eval echo intval($cunm) + intval($newpm) + intval($announcepm);}--></i><!--{/if}-->
		</span>
		<span class="tab-label {if CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'pm'}zy-be{else}zy-c{/if}">{lang guiigo_manage:tlang0080}</span>
	</a>
	<a class="tab-item" href="$guiigo_config['domain_name']home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" data-no-cache="true">
		<span class="icon">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$guiigo_config['default_style']/{if CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'profile'}wd_on{else}wd{/if}.png">
			<!--{if $_G[member][newprompt_num][follower]}--><i class="guiigo-yjsz bg-j zy-a">$_G[member][newprompt_num][follower]</i><!--{/if}-->
		</span>
		<span class="tab-label {if CURSCRIPT == 'home' && CURMODULE == 'space' && $_GET['do'] == 'profile'}zy-be{else}zy-c{/if}">{lang guiigo_manage:tlang0081}</span>
	</a>
</nav>