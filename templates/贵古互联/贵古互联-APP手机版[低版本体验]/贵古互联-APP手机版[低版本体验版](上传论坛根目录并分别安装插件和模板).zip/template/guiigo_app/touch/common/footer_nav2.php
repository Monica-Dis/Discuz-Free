<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{if $guiigo_config['open_tabnav']}-->
<!--{if !$guiigo_config['isguiigoapp'] || $_G['cache']['plugin']['guiigo_appmanage']['alltpl']}-->
<style>
	/* tab-item-activate .tab-label 每个样式需增加 定义激活字体颜色 */
	.tab-item-activate .tab-label{
		color: rgb(255, 152, 0);
	}

</style>

<div class="guiigo-lnav bg-c{if $guiigo_config['tabnavmusic']>1} tabnavmusic{/if}" data-music="tab$guiigo_config['tabnavmusic']">
<div class="guiigo-lnav-min">
{if $tab_menu}
	{loop $tab_menu $anvkey $anvval}
{eval}
  if($_G[uid] && strexists($anvval['global_tab_menu_link'],'{uid}') !== FALSE){
	   $anvval['global_tab_menu_link'] = preg_replace("{uid}",$_G[uid],$anvval['global_tab_menu_link']);
  }
  if($guiigo_config['appsetting']['forumconfig']['show_wdgzqb'] && $guiigo_config['appsetting']['forumconfig']['forumstyle'] == 1 && $anvval['global_tab_menu_mark'] =='sq'){
	  $anvval['global_tab_menu_link'] = $_G['siteurl'].'forum.php?forumlist=1&do=guanzhu&navactivate=sq';
  }else if($anvval['global_tab_menu_mark'] =='sq'){
	   $anvval['global_tab_menu_link'] = $_G['siteurl'].'forum.php?forumlist=1&navactivate=sq';
  }
{/eval}
	{if $anvval['global_tab_menu_verify_login'] && !$_G[uid]}
        <a class="tab-item login {if $anvval['global_tab_menu_bulge']}add-action{/if}" href="javascript:;" external data-mark="{$anvval['global_tab_menu_mark']}" data-sort="{$anvval['global_tab_menu_sort']}">
	{else}
        <a class="tab-item {if $anvval['global_tab_menu_bulge']}add-action{/if}" href="{$anvval['global_tab_menu_link']}" {if !$anvval['global_tab_menu_cache']}external{/if} data-mark="{$anvval['global_tab_menu_mark']}" data-sort="{$anvval['global_tab_menu_sort']}">
	{/if}
			<span class="icon img1def">
				{if $anvval['global_tab_menu_deficon']}
				<img src="{$_G['siteurl']}source/plugin/guiigo_manage/navfile/{$anvval['global_tab_menu_deficon']}">
				{/if}
			</span>
			<span class="icon imgactivate">
				{if $anvval['global_tab_menu_icon']}
				<img src="{$_G['siteurl']}source/plugin/guiigo_manage/navfile/{$anvval['global_tab_menu_icon']}">
				{/if}
			</span>

			<span class="tab-label colordef" style="color:{$anvval['global_tab_menu_color']};">
			    {$anvval['global_tab_menu_name']}
			</span>
			<span class="tab-label colorctivate" style="color:{$anvval['global_tab_menu_activate_color']};">
			    {$anvval['global_tab_menu_name']}
			</span>

			{if $anvval['global_tab_menu_mark'] =='xx'}
			<i class="guiigo-yjsz bg-j zy-a newmsg pmnewmsg" style="display:none;" data-setInterval="0"></i>
			{/if}
			{if $anvval['global_tab_menu_mark'] =='wd'}
			<i class="guiigo-yjsz bg-j zy-a newmsg followermsg" style="display:none;"></i>
			{/if}
		</a>
	{/loop}
{else}
	<a class="tab-item" href="{$_G['siteurl']}plugin.php?id=guiigo_manage&act=index&navactivate=sy" data-mark="sy">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/sy.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/sy_on.png">
		</span>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0076}</span>
	</a>
	<a class="tab-item" href="
	{if $guiigo_config['appsetting']['forumconfig']['show_wdgzqb'] && $guiigo_config['appsetting']['forumconfig']['forumstyle'] == 1}
	   $_G['siteurl']forum.php?forumlist=1&do=guanzhu&navactivate=sq
	{else}
	   $_G['siteurl']forum.php?forumlist=1&navactivate=sq
	{/if}" data-mark="sq">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/sq.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/sq_on.png">
		</span>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0078}</span>
	</a>
	<a class="tab-item" href="$_G['siteurl']group.php?mod=index&navactivate=qz" data-mark="qz">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/qz.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/qz_on.png">
		</span>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0079}</span>
	</a>
	<a class="tab-item {if !$_G[uid]}login{/if}" href="{if $_G[uid]}$_G['siteurl']home.php?mod=space&do=pm&filter=privatepm&navactivate=xx{else}javascript:;{/if}" data-mark="xx">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/xx.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/xx_on.png">
		</span>
		<i class="guiigo-yjsz bg-j zy-a newmsg pmnewmsg" style="display:none;" data-setInterval="0"></i>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0080}</span>
	</a>
	<a class="tab-item {if !$_G[uid]}login{/if}" href="{if $_G[uid]}$_G['siteurl']home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1&navactivate=wd{else}javascript:;{/if}" data-mark="wd">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/wd.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/wd_on.png">
		</span>
		<i class="guiigo-yjsz bg-j zy-a newmsg followermsg" style="display:none;"></i>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0081}</span>
	</a>
{/if}
</div>
</div>
<div id="anvhide" style="display:none;">
	<a class="tab-item" href="{$_G['siteurl']}plugin.php?id=guiigo_manage&act=index&navactivate=sy" data-mark="sy">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/sy.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/sy_on.png">
		</span>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0076}</span>
	</a>
	<a class="tab-item" href="
	{if $guiigo_config['appsetting']['forumconfig']['show_wdgzqb'] && $guiigo_config['appsetting']['forumconfig']['forumstyle'] == 1}
	   $_G['siteurl']forum.php?forumlist=1&do=guanzhu&navactivate=sq
	{else}
	   $_G['siteurl']forum.php?forumlist=1&navactivate=sq
	{/if}" data-mark="sq">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/sq.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/sq_on.png">
		</span>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0078}</span>
	</a>
	<a class="tab-item" href="$_G['siteurl']group.php?mod=index&navactivate=qz" data-mark="qz">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/qz.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/qz_on.png">
		</span>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0079}</span>
	</a>
	<a class="tab-item {if !$_G[uid]}login{/if}" href="{if $_G[uid]}$_G['siteurl']home.php?mod=space&do=pm&filter=privatepm&navactivate=xx{else}javascript:;{/if}" data-mark="xx">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/xx.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/xx_on.png">
		</span>
		<i class="guiigo-yjsz bg-j zy-a newmsg pmnewmsg" style="display:none;" data-setInterval="0"></i>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0080}</span>
	</a>
	<a class="tab-item {if !$_G[uid]}login{/if}" href="{if $_G[uid]}$_G['siteurl']home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1&navactivate=wd{else}javascript:;{/if}" data-mark="wd">
		<span class="icon img1def">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/wd.png">
		</span>
		<span class="icon imgactivate">
			<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/$tplstyle/wd_on.png">
		</span>
		<i class="guiigo-yjsz bg-j zy-a newmsg followermsg" style="display:none;"></i>
		<span class="tab-label zy-c">{lang guiigo_manage:tlang0081}</span>
	</a>
</div>
<!--{/if}-->
<!--{/if}-->
<!-- 86406 -->