<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
{eval $loginhash = 'L'.random(4);}
<div class="page page-current guiigo-dlbg" data-mod="login">
	<div class="swiper-container gg-dz-dlbg bg-r">
		<div class="swiper-wrapper dlbg-ysks">
			<div class="swiper-slide" data-swiper-autoplay="7000"><img src="template/guiigo_app/static/images/gg-dlbg1.jpg" /></div>
			<div class="swiper-slide" data-swiper-autoplay="7000"><img src="template/guiigo_app/static/images/gg-dlbg2.jpg" /></div>
			<div class="swiper-slide" data-swiper-autoplay="7000"><img src="template/guiigo_app/static/images/gg-dlbg3.jpg" /></div>
			<div class="swiper-slide" data-swiper-autoplay="7000"><img src="template/guiigo_app/static/images/gg-dlbg4.jpg" /></div>
		</div>
	</div>
	<div class="content">
		<header class="bar bar-nav guiigo-nydb guiigo-kbhddb"
	    ck-cus="true" 
		ck-param="{ftcolo:{sta:'#ffffff',end:'#666666',class:['title','guiigoapp-xzfh','guiigoapp-mkbtgd']},rollt:'50',ori:'false',type:1}">
			<a class="button button-link pull-left back guiigo-kjfh zy-f"><i class="icon guiigoapp-xzfh"></i></a>
		</header>
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-dz-dllg">
				<img src="template/guiigo_app/static/images/dlogo.png">
			</div>
			<!--{if CURSCRIPT == 'member' && CURMODULE == logging && $_GET['do'] == 'loginhash'}-->
				<div id="layer_lostpw_$loginhash">
					<form method="post" 
					autocomplete="off" 
					id="lostpwform_$loginhash" 
					class="cl" 
					action="member.php?mod=lostpasswd&lostpwsubmit=yes&infloat=yes"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{id:'',type:'lostpwform'},fn:'MsgCallLogin',load:'true',verifyLoging:'1'}">
						<div class="gg-dz-dllb list-block-no">
							<input type="hidden" name="formhash" value="{FORMHASH}" />
							<input type="hidden" name="handlekey" value="lostpwform" />
							<ul>
								<li class="guiigo-flex xh-d">
									<div class="dllb-bico zy-a"><i class="icon guiigoapp-youxiang"></i>{lang guiigo_manage:tlang0818}</div>
									<div class="guiigo-flexy"><input type="text" name="email" id="lostpw_email" size="30" value=""  tabindex="1" class="guiigo-px" placeholder="{lang guiigo_manage:tlang0819}"/></div>
								</li>
								<li class="guiigo-flex xh-d">
									<div class="dllb-bico zy-a"><i class="icon guiigoapp-yonghu"></i>{lang guiigo_manage:tlang0820}</div>
									<div class="guiigo-flexy"><input type="text" name="username" id="lostpw_username" size="30" value=""  tabindex="1" class="guiigo-px" placeholder="{lang guiigo_manage:tlang0821}"/></div>
								</li>
							</ul>
						</div>
						<div class="gg-dz-dlan">
							<button class="formdialog guiigo-pn ab-f zy-a zy-ac" type="submit" name="lostpwsubmit" value="true" tabindex="100">{lang submit}</button>
							<div class="dlan-zcwj">
								<a class="zcwj-wjmm back zy-a">{lang guiigo_manage:tlang0822}</a>
								<!--{if $_G['setting']['regstatus']}-->
									<a href="member.php?mod={$_G[setting][regname]}" class="zcwj-zxzh zy-a">{lang guiigo_manage:tlang0823}</a>
								<!--{/if}-->
							</div>
						</div>
					</form>
				</div>
			<!--{else}-->
				<div id="loginform">
					<form id="loginform" 
					method="post" 
					action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" 
					ck-cus="true"
					ck-param="{type:'modal',callpar:{id:'',type:'lostpwform'},fn:'MsgCallLogin',load:'true',verifyLoging:'1'}">
						<input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
						<input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
						<input type="hidden" name="fastloginfield" value="username">
						<input type="hidden" name="cookietime" value="2592000">
						<!--{if $auth}-->
							<input type="hidden" name="auth" value="$auth" />
						<!--{/if}-->
						<div class="gg-dz-dllb list-block-no">
							<ul>
								<!--{if $invite}-->
									<li class="guiigo-flex xh-d">
										<div class="dllb-bico zy-a"><i class="icon guiigoapp-yaoqingren"></i>{lang register_from}</div>
										<div class="dllb-yqrx guiigo-flexy"><a href="home.php?mod=space&uid=$invite[uid]&do=profile"><!--{avatar($invite[uid],middle)}--><em class="zy-a">$invite[username]</em></a></div>
									</li>
								<!--{/if}-->
								<li class="guiigo-flex xh-d">
									<div class="dllb-bico zy-a"><i class="icon guiigoapp-yonghu"></i>{lang guiigo_manage:tlang0820}</div>
									<div class="guiigo-flexy"><input type="text" value="" tabindex="1" class="guiigo-px" size="30" autocomplete="off" value="" name="username" placeholder="{lang guiigo_manage:tlang0824}" fwin="login"></div>
								</li>
								<li class="guiigo-flex xh-d">
									<div class="dllb-bico zy-a"><i class="icon guiigoapp-mimaicon"></i>{lang guiigo_manage:tlang0681}</div>
									<div class="dllb-fdkz guiigo-flexy">
										<input type="password" tabindex="2" class="guiigo-px" size="30" value="" name="password" id="password" placeholder="{lang guiigo_manage:tlang0216}" fwin="login">
										<a href="javascript:;" class="bllb-mmyc zy-a" onclick="passwordTabtype(this,'#password')"><i class="icon guiigoapp-zhengyan"></i></a>
									</div>
								</li>
								<li class="questionli guiigo-flex xh-d">
									<div class="dllb-bico zy-a"><i class="icon guiigoapp-wenti1"></i>{lang guiigo_manage:tlang0825}</div>
									<div class="guiigo-flexy">
										<div class="login_select">
											<select id="questionid_{$loginhash}" name="questionid" class="guiigo-ps sel_list">
												<option value="0" selected="selected">{lang security_question}</option>
												<option value="1">{lang security_question_1}</option>
												<option value="2">{lang security_question_2}</option>
												<option value="3">{lang security_question_3}</option>
												<option value="4">{lang security_question_4}</option>
												<option value="5">{lang security_question_5}</option>
												<option value="6">{lang security_question_6}</option>
												<option value="7">{lang security_question_7}</option>
											</select>
										</div>
									</div>
								</li>
								<li class="bl_none answerli guiigo-flex xh-d"  style="display:none;">
									<div class="dllb-bico zy-a"><i class="icon guiigoapp-wenti"></i>{lang guiigo_manage:tlang0826}</div>
									<div class="guiigo-flexy"><input type="text" name="answer" id="answer_{$loginhash}" class="guiigo-px" size="30" placeholder="{lang guiigo_manage:tlang0827}"></div>
								</li>
							</ul>
						</div>
						<!--{if $seccodecheck}-->
							<div class="gg-dz-dyzm xh-d">
								<li class="guiigo-flex">
									<div class="dyzm-yico zy-a"><i class="icon guiigoapp-yanzheng"></i>{lang guiigo_manage:tlang0828}</div>
									<div class="guiigo-flexy">
										<!--{subtemplate common/seccheck}-->
									</div>
								</li>
							</div>
						<!--{/if}-->
						<div class="gg-dz-dlan">
							<button tabindex="3" value="true" name="submit" type="submit" class="formdialog guiigo-pn ab-f zy-a zy-ac">{lang login}</button>
							<div class="dlan-zcwj">
								<a href="member.php?mod=logging&action=login&do=loginhash" class="zcwj-wjmm zy-a">{lang guiigo_manage:tlang0829}</a>
								<!--{if $_G['setting']['regstatus']}-->
									<a href="member.php?mod={$_G[setting][regname]}" class="zcwj-zxzh zy-a">{lang guiigo_manage:tlang0823}</a>
								<!--{/if}-->
							</div>
						</div>
					</form>
				</div>
			<!--{/if}-->
			<!--{if $_G['cache']['plugin']['guiigo_manage']['open_login']}-->
				<div class="gg-dz-sfdl">
					<div class="sfdl-dlbt zy-a">{lang guiigo_manage:tlang0830}</div>
					<div class="sfdl-dllb">
						<a href="#" class="zy-f zd-12"><span class="bg-c"><img src="template/guiigo_app/static/images/sj.png" class="vm"></span></a>
						<a href="#" id="miniProgramlogin" class="zy-f zd-12"><span class="bg-c"><img src="template/guiigo_app/static/images/wx.png" class="vm"></span></a>
						<a href="#" class="zy-f zd-12"><span class="bg-c"><img src="template/guiigo_app/static/images/qq.png" class="vm"></span></a>
						<a href="#" class="zy-f zd-12"><span class="bg-c"><img src="template/guiigo_app/static/images/wb.png" class="vm"></span></a>
					</div>
				</div>
				<!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
				<p>{lang useqqconnectlogin}</p>
				<div class="btn_qqlogin"><a href="$_G[connect][login_url]&statfrom=login_simple">{lang qqconnect:connect_mobile_login}</a></div>
				<!--{/if}-->
				<!--{if $_G['setting']['pwdsafety']}-->
					<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
				<!--{/if}-->
				
				<!--{hook/logging_bottom_mobile}-->
			<!--{/if}-->
			<!--{eval updatesession();}-->
			<div id="prkonzs1" class="gg-kj-ysdl">
				<div class="guiigo-wnrtx guiigo-wnrtxx gg-kj-ysts">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang guiigo_manage:tlang0831}</p>
					<a href="member.php?mod=logging&action=login" class="ab-f zy-a">{lang guiigo_manage:tlang0832}</a>
				</div>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript">
	(function() {
		ck8(document).on('change', '.sel_list', function() {
			var obj = ck8(this);
			if(obj.val() == 0) {
				ck8('.answerli').css('display', 'none');
				ck8('.questionli').addClass('bl_none');
			} else {
				ck8('.answerli').css('display', 'flex');
				ck8('.questionli').removeClass('bl_none');
			}
		});
	})();
	</script>
</div>
<!--{template common/footer}-->