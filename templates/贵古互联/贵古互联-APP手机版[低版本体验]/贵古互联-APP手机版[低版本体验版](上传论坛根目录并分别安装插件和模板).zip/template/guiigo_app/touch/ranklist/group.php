<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="ranklist-group">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<a href="search.php?mod=group" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-f"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0859}</h1>
	</header>
	<div class="content phgroup-scroll bg-c gg-yjms">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-kj-rwbg">
				<img src="template/guiigo_app/static/images/qpbg.jpg" class="vm">
				<div class="guiigo-bwdx">
					<div class="guiigo-bwdx-a"></div>
					<div class="guiigo-bwdx-b"></div>
				</div>
			</div>
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-ranklistgroup list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $_GET[view] == 'credit'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phgroup-scroll','misc.php?mod=ranklist&type=group&view=credit',['gg-ph-bkph']);">{lang guiigo_manage:tlang0860}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[view] == 'member'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phgroup-scroll','misc.php?mod=ranklist&type=group&view=member',['gg-ph-bkph']);">{lang guiigo_manage:tlang0861}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[view] == 'threads'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phgroup-scroll','misc.php?mod=ranklist&type=group&view=threads',['gg-ph-bkph']);">{lang guiigo_manage:tlang0862}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[view] == 'posts'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phgroup-scroll','misc.php?mod=ranklist&type=group&view=posts',['gg-ph-bkph']);">{lang guiigo_manage:tlang0863}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[view] == 'today'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.phgroup-scroll','misc.php?mod=ranklist&type=group&view=today',['gg-ph-bkph']);">{lang guiigo_manage:tlang0864}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-zt-jgys bg-g"></div>
			<div class="gg-ph-bkph sh-a">
				<!--{if $groupsrank}-->
					<div class="bkph-bklb list-block-no ms-a">
						<ul>
							<!--{loop $groupsrank $forum}-->
							<!--{eval $forumIcon = GuiigoApp::getForumIconByFid($forum['fid'],3);}-->
								<li>
									<a href="forum.php?mod=forumdisplay&fid=$forum['fid']">
										<i class="zy-c">
											<!--{if $_GET[view] == 'credit'}-->{lang guiigo_manage:tlang0543}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum['commoncredits'])}--><!--{else}-->$forum['commoncredits']<!--{/if}-->
											<!--{elseif $_GET[view] == 'member'}-->{lang guiigo_manage:tlang0490}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum['membernum'])}--><!--{else}-->$forum['membernum']<!--{/if}-->
											<!--{elseif $_GET[view] == 'threads'}-->{lang guiigo_manage:tlang0417}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum['posts'])}--><!--{else}-->$forum['posts']<!--{/if}-->
											<!--{elseif $_GET[view] == 'posts'}-->{lang guiigo_manage:tlang0148}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum['posts'])}--><!--{else}-->$forum['posts']<!--{/if}-->
											<!--{elseif $_GET[view] == 'today'}-->{lang guiigo_manage:tlang0086}: <!--{if $guiigo_config['number_format']}--><!--{echo dnumber($forum['posts'])}--><!--{else}-->$forum['posts']<!--{/if}-->
											<!--{/if}-->
										</i>
										<span class="bklb-phys zy-f"><!--{if $forum['rank'] <= 3}--><img src="template/guiigo_app/static/images/ggph-$forum['rank'].png" alt="$forum['rank']" /><!--{else}-->$forum['rank']<!--{/if}--></span>
										<!--{if $forumIcon}-->
											<img src="$forumIcon" class="bklb-bktb">
										<!--{else}-->
											<img src="static/image/common/groupicon.gif" class="bklb-bktb">
										<!--{/if}-->
										<h2 class="zy-h">$forum['name']</h2>
									</a>
								</li>
							<!--{/loop}-->
						</ul>
					</div>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0865}</p>
					</div>
				<!--{/if}-->
				<!--{if $groupsrank}-->
					<div class="gg-ph-hcsm mn-a zy-c">{lang ranklist_update}</div>
				<!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->