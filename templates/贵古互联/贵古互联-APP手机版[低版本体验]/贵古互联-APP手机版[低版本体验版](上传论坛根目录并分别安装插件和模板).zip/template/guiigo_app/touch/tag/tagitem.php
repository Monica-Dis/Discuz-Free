<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="tagitem">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c<!--{if !$tagname}--> xh-b<!--{/if}-->">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<a href="misc.php?mod=tag" class="button button-link pull-right"><i class="icon guiigoapp-sousuo zy-f"></i></a>
		<h1 class="title zy-h"><!--{if $tagname}-->{lang guiigo_manage:tlang0270}: $tagname<!--{else}-->{lang guiigo_manage:tlang0884}<!--{/if}--></h1>
	</header>
	<div class="content tagitem-scroll<!--{if !$tagname}--> bg-c<!--{/if}-->">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $tagname}-->
				<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
				<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-tagitem list-block-no xh-b bg-c">
					<ul class="swiper-wrapper">
						<li class="swiper-slide<!--{if empty($showtype) || $showtype == 'thread'}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.tagitem-scroll','misc.php?mod=tag&id=$id&type=thread',['gg-tg-tgon']);">{lang guiigo_manage:tlang0889}</a><span class="bg-b"></span></li>
						<li class="swiper-slide<!--{if helper_access::check_module('blog') && (empty($showtype) || $showtype == 'blog')}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.tagitem-scroll','misc.php?mod=tag&id=$id&type=blog',['gg-tg-tgon']);">{lang guiigo_manage:tlang0890}</a><span class="bg-b"></span></li>
					</ul>
				</div>
				<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
				<div class="gg-tg-tgon">
					<!--{if empty($showtype) || $showtype == 'thread'}-->
						<!--{if $threadlist}-->
							<div class="guiigo-ztlb gg-ss-tzss list-block-no ms-a">
								<ul class="list-container">
								<!--{eval $postlists=GuiigoApp::GetPostlist($threadlist);}-->
								<!--{loop $threadlist $thread}-->
									<!--{eval $pidarr=GuiigoApp::getpostfirstbypid($thread[tid]);}-->	
									<!--{if $post['closed'] > 1 || $post['moved']}-->
										<!--{eval $post[tid]=$post[closed];}-->
									<!--{/if}-->
									<!--{if (!$_G['setting']['mobile']['mobiledisplayorder3'] && $post['displayorder'] > 0) ||  $post['displayorder'] < 0}-->
										{eval continue;}
									<!--{/if}-->
									<!--{eval $gender = GuiigoApp::getUserList($thread['authorid'],'profile');}-->
									<!--{eval $member = getuserbyuid($thread['authorid']);}-->
									<!--{eval $follow = GuiigoApp::getUserList($_G['uid'],'follow');}-->
									<!--{eval $verifys=GuiigoApp::getUserList($thread['authorid'],'verify');}-->
									<li class="gztlb-ztys bg-c xh-b sh-a">
										<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><!--{elseif $thread['digest'] > 0}-->
											<div class="gztlb-jhzt"><i class="icon guiigoapp-jinghua zy-i"></i></div>
										<!--{/if}-->
										<div class="gztlb-tbyh">
											<div class="tbyh-lztx guiigo-ty"><!--{if $thread['authorid'] && $thread['author']}--><a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><!--{avatar($thread[authorid],middle)}--></a><!--{else}--><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/niming.jpg"><!--{/if}--></div>
											<div class="tbyh-mcxx">
												<h1>
													<!--{if $thread['authorid'] && $thread['author']}-->
														<!--{if !in_array($thread['authorid'], $follow)}-->
														 <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]" 
														class="followmod_$thread[authorid] dialog mcxx-gzan zy-b bk-b"  
														ck-cus="true"
														ck-confirm="false"
														ck-param="{type:'modal',callpar:{tid:'$thread[authorid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}" 
														external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
														<!--{else}-->
														<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$thread['authorid']" 
														class="followmod_$thread[authorid] dialog mcxx-gzan zy-c bk-c bg-e" 
														ck-cus="true" 
														ck-confirm="true" 
														ck-param="{type:'modal',callpar:{tid:'$thread['authorid']'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}"  
														external >{lang guiigo_manage:tlang0003}</a>
														<!--{/if}-->
														<a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="mcxx-yhmc zy-f">$thread[author]</a>
														<!--{eval $grouptitle = strip_tags($_G['cache']['usergroups'][$member['groupid']]['grouptitle']);}-->
														<span class="mcxx-yhdj zy-a" style="background: {$_G['cache']['usergroups'][$member['groupid']]['color']};">{$grouptitle}</span>
														<!--{if $gender['gender'] == 1  || $gender['gender'] == 0}-->
														<i class="icon guiigoapp-nan bg-n"></i>
														<!--{elseif $gender['gender'] == 2}-->
														<i class="icon guiigoapp-nv bg-o"></i>
														<!--{/if}-->
														<!--{if $_G['setting']['verify']['enabled']}-->
															<span class="verify-icon y">
															<!--{loop $_G['setting']['verify'] $vid $verify}-->
																<!--{if $verify['available'] && $verifys['verify'.$vid] == 1 && $verify['icon']}-->
																<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" class="ck8-avatar-icon">
																   <img src="$verify['icon']" class="vm" alt="$verify[title]" />
																</a>
																<!--{/if}-->
															<!--{/loop}-->
															</span>
														<!--{/if}-->
													<!--{else}-->
														<a href="javascript:void(0);" class="mcxx-yhmc zy-f">$_G[setting][anonymoustext]</a>
													<!--{/if}-->
												</h1>
												<div class="mcxx-fbxx">
													<i class="zy-g">$thread[dateline]</i>
													<em class="zy-g"> {lang guiigo_manage:tlang0137}: <a href="forum.php?mod=forumdisplay&fid=$thread[fid]">$thread[forumname]</a></em>
												</div>
											</div>
										</div>
										<div class="gztlb-nrdy">
											<h1>
												<!--{if $thread[special] == 1}-->
													<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0138}</span>
												<!--{elseif $thread[special] == 2}-->
													<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0139}</span>
												<!--{elseif $thread[special] == 3}-->
													<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0140}</span>
												<!--{elseif $thread[special] == 4}-->
													<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0141}</span>
												<!--{elseif $thread[special] == 5}-->
													<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0142}</span>
												<!--{elseif $thread['rushreply']}-->
													<span class="nrdy-ztlx bg-b zy-a">{lang guiigo_manage:tlang0143}</span>
												<!--{/if}-->
												<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]>{$thread['subject']}</a>
											</h1>
											<!--{if $postlists[$pidarr[pid]] && !empty($postlists[$pidarr[pid]]['message'])}-->
												<p class="zy-c"><!--{echo cutstr($postlists[$pidarr[pid]]['message'],90)}--></p>
											<!--{/if}-->
											<!--{eval $cunm = count($postlists[$pidarr[pid]][attapic]);}-->
											<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
												<div class="nrdy-imgs">
													<ul>
													<!--{loop $postlists[$pidarr[pid]][attapic] $key $aids}-->
														<!--{if $cunm == 1}-->
															<li class="imgs-tpsa"><img lazySrc="{eval echo getforumimg($aids[2], 0, 400, 9999)}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
														<!--{elseif $cunm == 2}-->
															<li class="imgs-tpsb"><img lazySrc="{eval echo getforumimg($aids[2], 0, 300, 280)}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/></li>
														<!--{else}-->
															<li class="imgs-tpsc<!--{if $cunm > 6}--> imgs-tpsd<!--{/if}-->"><img lazySrc="{eval echo getforumimg($aids[2], 0, 300, 280)}" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"/><!--{if $cunm > 6}--><div class="tpsd-gdtp"><span class="tpsd-jtnr"><i class="icon guiigoapp-mkbtgd"></i><!--{eval echo $cunm}--></span></div><!--{/if}--></li>
														<!--{/if}-->
														<!--{if $key >= 5}-->
															<!--{eval break;}-->
														<!--{/if}-->
													<!--{/loop}-->
													</ul>
												</div>
											</a>
										</div>
										<div class="gztlb-ztcz">
											<ul>
												<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-huifu"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[replies])}--><!--{else}-->$thread[replies]<!--{/if}--></a></li>
												<li class="ztcz-zbcz"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="zy-c bg-l"><i class="icon guiigoapp-chakan"></i><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[views])}--><!--{else}-->$thread[views]<!--{/if}--></a></li>
												<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
													<!--{eval $recommenus=GuiigoApp::getrecommendbyid($thread[tid],$_G[uid]);}-->
													<li class="ztcz-ybcz">
														<div class="ztcz-dzkz{if $recommenus} zy-b bg-m{else} zy-c bg-l{/if}" id="recommend_add_$thread[tid]">
															<a href="forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&hash={FORMHASH}&handlekey=recommend_add"  
																class="dialog " 
																ck-cus="true"
																ck-param="{
																	type:'modal',
																	callpar:{tid:'$thread[tid]'},
																	fn:'MsgCallFn',
																	load:'true',
																	uid:'{$_G[uid]}'
																}" 
																external ><i class="icon{if $recommenus} guiigoapp-dianzanon{else} guiigoapp-dianzan{/if}"></i>
															</a>
															<em id="recommend_add_sum$thread[tid]"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($thread[recommend_add])}--><!--{else}-->$thread[recommend_add]<!--{/if}--></em>
														</div>
													</li>
												<!--{/if}-->
											</ul>
										</div>
									</li>
								<!--{/loop}-->
								</ul>
								<!--{if !empty($showtype)}-->
								<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
									<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
								</div>
								<!--{/if}-->
							</div>
						<!--{else}-->
							<div class="guiigo-wnrtx">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
								<p class="zy-c">{lang no_content}</p>
							</div>
						<!--{/if}-->
					<!--{/if}-->
					<!--{if helper_access::check_module('blog') && (empty($showtype) || $showtype == 'blog')}-->
						<!--{if $bloglist}-->
							<div class="gg-kj-rzlb list-block-no ms-a bg-c xh-b sh-a">
								<ul>
									<!--{loop $bloglist $blog}-->
										<li class="xh-b">
											<!--{if $blog[pic]}--><div class="twlbm-img"><a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"><img lazysrc="$blog[pic]" src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/tpljz.png" class="ck8-lazy vm"></a></div><!--{/if}-->
											<div class="twlbm-nr<!--{if !$blog[pic]}--> twlbm-wtnr<!--{/if}-->">
												<!--{eval $stickflag = isset($blog['stickflag']) ? 0 : 1;}-->
												<h2><!--{if !$stickflag}--><i class="icon guiigoapp-zhiding zy-a bg-d"></i><!--{/if}--><a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"{if $blog[magiccolor]} style="color: {$_G[colorarray][$blog[magiccolor]]}"{/if} class="zy-e">$blog[subject]</a></h2>
												<p><span class="twlbm-nr-hf"><a href="home.php?mod=space&uid=$blog[uid]&do=profile" class="zy-c"><!--{avatar($blog[uid],small)}-->$blog[username]</a></span><span class="twlbm-nr-sj zy-c">$blog[dateline]</span></p>
											</div>
										</li>
									<!--{/loop}-->
								</ul>
							</div>
							<!--{if !empty($showtype)}-->
								<!--{if $multipage}--><div class="pgs mtm cl">$multipage</div><!--{/if}-->
							<!--{/if}-->
						<!--{else}-->
							<div class="guiigo-wnrtx">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
								<p class="zy-c">{lang no_content}</p>
							</div>
						<!--{/if}-->
					<!--{/if}-->
				</div>
			<!--{else}-->
				<div class="gg-qz-qbss bg-g xh-b">
					<div class="gg-qz-qzss" style="display: none;">
						<a href="javascript:$('.gg-qz-qzss').hide();$('.gg-qz-qzsc').show();$('#scform_srchtxt').focus();" class="bg-c zy-c"><i class="icon guiigoapp-sousuo"></i>{lang guiigo_manage:tlang0885}</a>
					</div>
					<div class="gg-qz-qzsc" style="display:block;">
						<form method="post" action="misc.php?mod=tag&type=thread">
							<ul class="guiigo-flex">
								<input type="search" id="scform_srchtxt" name="name" class="qzsc-sssr bg-c zy-c" value="$searchtagname"/>
								<a href="javascript:$('.gg-qz-qzsc').hide();$('.gg-qz-qzss').show();"><i class="icon guiigoapp-guanbix zy-g"></i></a>
								<button type="submit" class="qzsc-ssqr ab-az zy-a zy-ac">{lang search}</button>
							</ul>
						</form>
					</div>
				</div>
				<div class="guiigo-wnrtx">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang guiigo_manage:tlang0891}</p>
					<a class="back ab-az zy-a zy-ac">{lang guiigo_manage:tlang0892}</a>
				</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	function MsgCallFn(msg,par,param) {
		if(typeof msg === 'object' || typeof par === 'object'){
			var Obj = $('.followmod_'+ par.fuid +'');
			var foObj = $('#recommend_add_'+ param.tid);
			var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
				$.toast('{lang guiigo_manage:tlang0003}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
				Obj.attr('ck-confirm','true')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
				$.toast('{lang guiigo_manage:tlang0009}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + par.fuid).html('{lang guiigo_manage:tlang0003}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
				Obj.attr('ck-confirm','false')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
				$.toast('{lang guiigo_manage:tlang0007}');
			}else if((par.recommendv && par.daycount && msg.msg.indexOf('{lang guiigo_manage:tlang0043}') != -1) || (par.recommendv && msg.msg.indexOf('{lang guiigo_manage:tlang0044}') != -1)){
				foObj.addClass('zy-b bg-m').find('a').html('<i class="icon guiigoapp-dianzanon"></i>');
				$('#recommend_add_sum'+ param.tid).html(''+ (recommendcut + parseInt(par.recommendv)));
				$.toast('{lang guiigo_manage:tlang0045}');
				if(par.daycount){
					setTimeout(function(){$.toast('{lang guiigo_manage:tlang0046}'+ par.daycount +'{lang guiigo_manage:tlang0047}')}, 2300)
				}
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0048}') != -1){
				$.toast('{lang guiigo_manage:tlang0049}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0050}') != -1){
				$.confirm('{lang guiigo_manage:tlang0051}', '{lang guiigo_manage:tlang0042}', function () {
					$.router.load('home.php?mod=spacecp&ac=usergroup');
				});
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0052}') != -1){
				$.toast('{lang guiigo_manage:tlang0053}');
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0054}') != -1){
				$.toast('{lang guiigo_manage:tlang0055}');
			}else {
				$.toast(msg.msg);
			}
		}else{
			$.toast('{lang guiigo_manage:tlang0056}');
		}
	}
	</script>
</div>
<!--{template common/footer}-->