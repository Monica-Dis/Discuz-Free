<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
	<!--{if $action == 'index' && $status != 2 && $status != 3}-->
		<!--{subtemplate group/group_list}-->
	<!--{elseif $action == 'list'}-->
		<!--{subtemplate group/group_list}-->
	<!--{elseif $action == 'memberlist'}-->
		<!--{subtemplate group/group_memberlist}-->
	<!--{elseif $action == 'create'}-->
		<!--{subtemplate group/group_create}-->
	<!--{elseif $action == 'invite'}-->
		<!--{subtemplate group/group_invite}-->
	<!--{elseif $action == 'manage'}-->
		<!--{subtemplate group/group_manage}-->
	<!--{/if}-->
<!--{template common/footer}-->