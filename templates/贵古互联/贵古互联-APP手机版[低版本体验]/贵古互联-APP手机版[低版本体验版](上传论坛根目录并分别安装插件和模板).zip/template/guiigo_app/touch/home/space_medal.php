<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-medal">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<h1 class="title zy-h">{lang medals_center}</h1>
	</header>
	<div class="content medal-scroll">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-kj-rwbg">
				<img src="template/guiigo_app/static/images/xzbg.jpg" class="vm">
				<div class="guiigo-bwdx">
					<div class="guiigo-bwdx-a"></div>
					<div class="guiigo-bwdx-b"></div>
				</div>
			</div>
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacemedal list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if empty($_GET[action])}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.medal-scroll','home.php?mod=medal',['gg-kj-xzsx']);">{lang guiigo_manage:tlang0726}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $_GET[action] == 'log'}--> on<!--{/if}-->"><a {if $_G[uid]}href="javascript:;" onclick="app.LoadPageForumView('.medal-scroll','home.php?mod=medal&action=log',['gg-kj-xzsx']);"{else}href="member.php?mod=logging&action=login"{/if}>{lang my_medals}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div id="xzkx-on" class="gg-kj-xzsx">
				<!--{if empty($_GET[action])}-->
					<!--{if $medallist}-->
						<!--{if $_G[uid]}-->
							<!--{if $medalcredits}-->
								<div class="gg-qz-flts rwxq-txys bg-c ms-a"><div class="flts-tsnr bk-d bg-p zy-b">
									{lang you_have_now}
									<!--{eval $i = 0;}-->
									<!--{loop $medalcredits $id}-->
										<!--{if $i != 0}-->, <!--{/if}-->{$_G['setting']['extcredits'][$id][img]} {$_G['setting']['extcredits'][$id][title]} <span class="xi1"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber(getuserprofile('extcredits'.$id))}--><!--{else}--><!--{echo getuserprofile('extcredits'.$id);}--><!--{/if}--></span> {$_G['setting']['extcredits'][$id][unit]}
										<!--{eval $i++;}-->
									<!--{/loop}-->
								</div></div>
							<!--{/if}-->
						<!--{/if}-->
						<div class="gg-sq-tayc list-block-no ms-a xh-b bg-c">
							<ul>
								<!--{loop $medallist $key $medal}-->
									<li class="xh-a">
										<span style="padding:0;">
											<!--{if in_array($medal[medalid], $membermedal)}-->
												<a href="javascript:void(0)" class="bg-i zy-a">{lang guiigo_manage:tlang0727}</a>
											<!--{elseif $medal[type] && $_G['uid']}-->
												<!--{if in_array($medal[medalid], $mymedals)}-->
													<!--{if $medal['price']}-->
														<a href="javascript:void(0)" class="bg-i zy-a">{lang guiigo_manage:tlang0728}</a>
													<!--{else}-->
														<!--{if !$medal[permission]}-->
															<a href="javascript:void(0)" class="bg-i zy-a">{lang guiigo_manage:tlang0729}</a>
														<!--{else}-->
															<a href="javascript:void(0)" class="bg-i zy-a">{lang guiigo_manage:tlang0730}</a>
														<!--{/if}-->
													<!--{/if}-->
												<!--{else}-->
													<a href="home.php?mod=medal&action=confirm&medalid=$medal[medalid]" class="bg-h zy-a zy-ac dialog"
														ck-cus="true"
														ck-param="{type:'modal',callpar:{pid:'$medal[medalid]'},fn:'MsgCallRaterange',load:'true',uid: '$_G[uid]'}"
														external >
														<!--{if $medal['price']}-->
															{lang guiigo_manage:tlang0121}
														<!--{else}-->
															<!--{if !$medal[permission]}-->
																{lang guiigo_manage:tlang0731}
															<!--{else}-->
																{lang guiigo_manage:tlang0732}
															<!--{/if}-->
														<!--{/if}-->
													</a>
												<!--{/if}-->
											<!--{else}-->
												<a href="javascript:void(0)" class="bg-i zy-a">{lang guiigo_manage:tlang0733}</a>
											<!--{/if}-->
										</span>
										<div class="bkys-xzico">
											<img src="{STATICURL}image/common/$medal[image]" alt="$medal[name]" class="vm"/>
										</div>
										<a href="javascript:void(0)" class="bkys-bkmc zy-e">
											<i>$medal[name]</i>
										</a>
										<p class="zy-g">$medal[description]</p>
									</li>
								<!--{/loop}-->
							</ul>
						</div>
					<!--{else}-->
						<div class="guiigo-wnrtx">
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
							<p class="zy-c"><!--{if $medallogs}-->{lang medals_nonexistence}<!--{else}-->{lang medals_noavailable}<!--{/if}--></p>
						</div>
					<!--{/if}-->
					<!--{if $lastmedals}-->
						<div class="rwxq-lmbt bg-g xh-b zy-c cl">{lang medals_record}</div>
						<div class="guiigo-hylb list-block-no xh-b bg-c">
							<ul class="ms-c">
								<!--{loop $lastmedals $lastmedal}-->
								<li class="sh-a">
									<a href="home.php?mod=space&uid=$lastmedal[uid]&do=profile" class="t guiigo-tys">
										<!--{avatar($lastmedal[uid],middle)}-->
										<h2 class="zy-h"><i class="zy-c">$lastmedal[dateline]</i>$lastmedalusers[$lastmedal[uid]][username]</h2>
										<p class="zy-g">{lang medals_message2} $medallist[$lastmedal['medalid']]['name'] {lang medals}</p>
									</a>
								</li>
								<!--{/loop}-->
							</ul>
						</div>
					<!--{/if}-->
				<!--{elseif $_GET[action] == 'log'}-->
					<!--{if $mymedals}-->
						<div class="ryxz-xzlb ms-a cl">
							<!--{loop $mymedals $mymedal}-->
								<a href="javascript:void(0)" class="bg-c"><img src="{STATICURL}image/common/$mymedal[image]"><p class="zy-h">$mymedal[name]</p></a>
							<!--{/loop}-->
						</div>
					<!--{/if}-->
					<!--{if $medallogs}-->
						<div class="rwxq-lmbt ms-a bg-c xh-b zy-c cl">{lang medals_record}</div>
						<div class="guiigo-hylb list-block-no xh-b bg-c">
							<ul class="ms-c">
								<!--{loop $medallogs $medallog}-->
								<li class="sh-a">
									<!--{if $medallog['type'] == 2 || $medallog['type'] == 3}-->
										<a href="javascript:void(0)" class="t guiigo-tys">
											<!--{avatar($_G[uid])}-->
											<h2 class="zy-h"><i class="zy-c">$medallog[dateline]</i>{$_G[member][username]}</h2>
											<p class="zy-g">{lang medals_message4} $medallog[name] {lang medals}, <!--{if $medallog['type'] == 2}-->{lang medals_operation_2}<!--{elseif $medallog['type'] == 3}-->{lang medals_operation_3}<!--{/if}--></p>
										</a>
									<!--{elseif $medallog['type'] != 2 && $medallog['type'] != 3}-->
										<a href="javascript:void(0)" class="t guiigo-tys">
											<!--{avatar($_G[uid])}-->
											<h2 class="zy-h"><i class="zy-c">$medallog[dateline]</i>{$_G[member][username]}</h2>
											<p class="zy-g">{lang medals_message5} $medallog[name] {lang medals}, <!--{if $medallog[expiration]}-->{lang expire}: $medallog[expiration]<!--{else}-->{lang medals_noexpire}<!--{/if}--></p>
										</a>
									<!--{/if}-->
								</li>
								<!--{/loop}-->
							</ul>
						</div>
						<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
					<!--{else}-->
						<div class="guiigo-wnrtx">
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
							<p class="zy-c">{lang medals_nonexistence_own}</p>
						</div>
					<!--{/if}-->
				<!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->