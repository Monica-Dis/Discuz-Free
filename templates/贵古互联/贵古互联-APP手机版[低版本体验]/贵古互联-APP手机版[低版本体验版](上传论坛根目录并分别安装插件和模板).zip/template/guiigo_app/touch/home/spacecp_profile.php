<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp-profile">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c{if $actives[password]} xh-b{/if}">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<!--{if $actives[profile]}--><a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="button button-link pull-right"><i class="icon guiigoapp-tbgrzx zy-f"></i></a><!--{/if}-->
		<h1 class="title zy-h"><!--{if $actives[profile]}-->{lang guiigo_manage:tlang0524}<!--{elseif $actives[verify]}-->{lang guiigo_manage:tlang0526}<!--{elseif $actives[password]}-->{lang password_security}<!--{/if}--></h1>
	</header>
	<div class="content groupmanage-scroll">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $validate}-->
				<div class="gg-qz-flts bg-c ms-a"><div class="flts-tsnr bk-d bg-p zy-b">{lang validator_comment}<br/>{lang validator_remark}: $validate[remark]</div></div>
				<form action="member.php?mod=regverify" method="post" autocomplete="off">
				<input type="hidden" value="{FORMHASH}" name="formhash" />
				<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->
				<div class="guiigo-wblb gg-wblb-zlkz list-block-no ms-a bg-c sh-a cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang validator_message}</div>
							<div class="wblb-wbnr"><input type="text" class="guiigo-px s-a" name="regmessagenew" value="" /></div>
						</li>
					</ul>
				</div>
				<!--{/if}-->
				<div class="mn-a">
					<button type="submit" name="verifysubmit" value="true" class="guiigo-pn ab-az zy-a zy-ac" />{lang validator_submit}</button>
				</div>
			<!--{else}-->
				<!--{if $operation == 'password'}-->
					<div class="gg-qz-flts bg-c ms-a">
						<div class="flts-tsnr bk-d bg-p zy-b">
							<!--{if !$_G['member']['freeze']}-->
								<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->{lang old_password_comment}<!--{elseif $wechatuser}-->{lang wechat_config_newpassword_comment}<!--{else}-->{lang connect_config_newpassword_comment}<!--{/if}-->
							<!--{elseif $_G['member']['freeze'] == 1}-->
								{lang freeze_pw_tips}
							<!--{elseif $_G['member']['freeze'] == 2}-->
								{lang freeze_email_tips}
							<!--{/if}-->
						</div>
					</div>
					<form action="home.php?mod=spacecp&ac=profile" 
					method="post" 
					autocomplete="off"
					ck-cus="true"
					ck-param="{type:'modal',fn:'MsgCallCpprof',load:'true',uid:'$_G[uid]'}">
						<input type="hidden" value="{FORMHASH}" name="formhash" />
						<div class="guiigo-wblb gg-wblb-zlkz list-block-no ms-a mx-a bg-c sh-a cl">
							<ul>
								<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->
									<li class="guiigo-flex xh-b cl">
										<div class="wblb-wbbt zy-c">{lang old_password} <span class="zy-i">*</span></div>
										<div class="wblb-wbnr"><input type="password" name="oldpassword" id="oldpassword" class="guiigo-px s-a" /></div>
									</li>
								<!--{/if}-->
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang new_password}</div>
									<div class="wblb-wbnr gg-aq-mmer">
										<input type="password" name="newpassword" id="newpassword" class="guiigo-px gg-aq-mmsq bg-e s-a"/>
										<p class="gg-aq-mmts zy-c" id="chk_newpassword">{lang memcp_profile_passwd_comment}</p>
									</div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang new_password_confirm}</div>
									<div class="wblb-wbnr gg-aq-mmer">
										<input type="password" name="newpassword2" id="newpassword2" class="guiigo-px gg-aq-mmsq bg-e s-a"/>
										<p class="gg-aq-mmts zy-c" id="chk_newpassword2">{lang memcp_profile_passwd_comment}</p>
									</div>
								</li>
								<li id="contact"{if $_GET[from] == 'contact'} style="background-color: {$_G['style']['specialbg']};"{/if} class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang email}</div>
									<div class="wblb-wbnr">
										<input type="text" name="emailnew" id="emailnew" value="$space[email]" class="guiigo-px s-a" />
										<div class="wbnr-t bg-e bk-e zy-f">
											<!--{if empty($space['newemail'])}-->{lang email_been_active}<!--{else}-->$acitvemessage<!--{/if}-->
											<!--{if $_G['setting']['regverify'] == 1 && (($_G['group']['grouptype'] == 'member' && $_G['adminid'] == 0) || $_G['groupid'] == 8) || $_G['member']['freeze']}--><br/>{lang memcp_profile_email_comment}<!--{/if}-->
										</div>
									</div>
								</li>
								<!--{if $_G['member']['freeze'] == 2}-->
									<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang freeze_reason}</li>
									<li class="wblb-nrsr xh-b zy-h cl">
										<div class="wblb-wbnr zy-h">
											<textarea rows="3" cols="80" name="freezereson" class="guiigo-pt s-a" placeholder="{lang freeze_reason_comment}">$space[freezereson]</textarea>
											<p class="d" id="chk_newpassword2">{lang freeze_reason_comment}</p>
										</div>
									</li>
								<!--{/if}-->
								<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang security_question}</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbnr">
										<select name="questionidnew" id="questionidnew" class="guiigo-ps">
											<option value="" selected>{lang memcp_profile_security_keep}</option>
											<option value="0">{lang security_question_0}</option>
											<option value="1">{lang security_question_1}</option>
											<option value="2">{lang security_question_2}</option>
											<option value="3">{lang security_question_3}</option>
											<option value="4">{lang security_question_4}</option>
											<option value="5">{lang security_question_5}</option>
											<option value="6">{lang security_question_6}</option>
											<option value="7">{lang security_question_7}</option>
										</select>
									</div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang security_answer}</div>
									<div class="wblb-wbnr">
										<input type="password" name="answernew" id="answernew" class="guiigo-px gg-aq-mmsq bg-e s-a"/>
										<p class="gg-aq-mmts zy-c">{lang memcp_profile_security_answer_comment}</p>
									</div>
								</li>
							</ul>
						</div>
						<!--{if $secqaacheck || $seccodecheck}-->
							<!--{eval $sectpl = '<table cellspacing="0" cellpadding="0" class="tfm"><tr><th><sec></th><td><sec><p class="d"><sec></p></td></tr></table>';}-->
							<!--{subtemplate common/seccheck}-->
						<!--{/if}-->
						<div class="mn-a">	
							<button type="submit" name="pwdsubmit" value="true" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang save}</button>
						</div>
						<input type="hidden" name="passwordsubmit" value="true" />
					</form>
					<script type="text/javascript">
					var strongpw = new Array();
					var pwlength = <!--{if $_G['setting']['pwlength']}-->$_G['setting']['pwlength']<!--{else}-->0<!--{/if}-->;
					<!--{if $_G['setting']['strongpw']}-->
						<!--{loop $_G['setting']['strongpw'] $key $val}-->
						strongpw[$key] = $val;
						<!--{/loop}-->
					<!--{/if}-->
					
					ck8(function(){
						app.loadScript('register', function() {
							checkPwdComplexity(Dz('newpassword'), Dz('newpassword2'), true);
						})
					})
					
					function MsgCallCpprof(msg,par,param){
						if(typeof msg === 'object' || typeof par === 'object'){
							if (msg.msg.indexOf('{lang guiigo_manage:tlang0630}') != -1){
								ck8.toast('{lang guiigo_manage:tlang0631}');
							}else {
								ck8.toast(msg.msg,'shibai');
							}
						}else{
							ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
						}
					}
	
					</script>
				<!--{else}-->
					<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
					<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacecpprofile list-block-no xh-b bg-c">
						<ul class="swiper-wrapper">
							<!--{if $operation != 'verify'}-->
								<!--{loop $profilegroup $key $value}-->
									<!--{if $value[available]}-->
									<li class="swiper-slide{if $opactives[$key]} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmanage-scroll','home.php?mod=spacecp&ac=profile&op=$key',['gg-kj-zrol']);">$value[title]</a><span class="bg-b"></span></li>
									<!--{/if}-->
								<!--{/loop}-->
							<!--{else}-->
								<!--{if $_G[setting][verify]}-->
									<!--{loop $_G['setting']['verify'] $vid $verify}-->
										<!--{if $verify['available'] && (empty($verify['groupid']) || in_array($_G['groupid'], $verify['groupid']))}-->
											<!--{if $vid != 7}-->
												<li class="swiper-slide{if $opactives['verify'.$vid]} on{/if}"><a href="javascript:;" onclick="app.LoadPageForumView('.groupmanage-scroll','home.php?mod=spacecp&ac=profile&op=verify&vid=$vid',['gg-kj-zrol']);">$verify['title']</a><span class="bg-b"></span></li>
											<!--{/if}-->
										<!--{/if}-->
									<!--{/loop}-->
								<!--{/if}-->
							<!--{/if}-->
						</ul>
					</div>
					<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
					<div class="gg-kj-zrol">
						<!--{if $vid}-->
						<div class="gg-qz-flts bg-c ms-a"><div class="flts-tsnr bk-d bg-p zy-b"><!--{if $showbtn}-->{lang spacecp_profile_message1}<!--{else}-->{lang spacecp_profile_message2}<!--{/if}--></div></div>
						<!--{/if}-->
						<iframe id="frame_profile" name="frame_profile" style="display: none"></iframe>
						<form action="{if $operation != 'plugin'}home.php?mod=spacecp&ac=profile&op=$operation{else}home.php?mod=spacecp&ac=plugin&op=profile&id=$_GET[id]{/if}" 
						method="post" 
						enctype="multipart/form-data" 
						autocomplete="off"
						{if $operation != 'plugin'} target="frame_profile"{/if} 
						onsubmit="clearErrorInfo();"
						ck-cus="true"
						ck-param="{type:'modal',callpar:{type:'grzlxg'},load:'true',uid:'$_G[uid]',upfiles:'1'}">
							<input type="hidden" value="{FORMHASH}" name="formhash" />
							<!--{if $_GET[vid]}-->
							<input type="hidden" value="$_GET[vid]" name="vid" />
							<!--{/if}-->
							<div class="guiigo-wblb gg-wblb-zlkz list-block-no ms-a bg-c sh-a cl">
								<ul>
									<li class="guiigo-flex xh-b cl">
										<div class="wblb-wbbt zy-c">{lang username}</div>
										<div class="wblb-wbnr">
											<div class="wnmr-sznr zy-h">$_G[member][username]</div>
										</div>
									</li>
								</ul>
							</div>
							<div class="guiigo-wblb gg-wblb-zlkz list-block-no bg-c cl">
								<ul>
									<!--{loop $settings $key $value}-->
									<!--{if $value[available]}-->
										<li id="tr_$key" class="guiigo-flex gg-zl-jgyd xh-b cl">
											<div id="th_$key" class="wblb-wbbt zy-c">$value[title]<!--{if $value[required]}--> <span class="zy-i">*</span><!--{/if}--></div>
											<div id="td_$key" class="wblb-wbnr gg-kj-zlxk zy-h"><!--{eval echo str_replace(array('(<a','a>)'),array('<a','a>'),$htmls[$key]);}--></div>
											<div class="wblb-wbxz">
												<!--{if $vid}-->
												<input type="hidden" name="privacy[$key]" value="3" class="wbxz-ps bg-e bk-e zy-c" />
												<!--{else}-->
												<select name="privacy[$key]" class="wbxz-ps bg-e bk-e zy-c">
													<option value="0"{if $privacy[$key] == "0"} selected="selected"{/if}>{lang open_privacy}</option>
													<option value="1"{if $privacy[$key] == "1"} selected="selected"{/if}>{lang friend_privacy}</option>
													<option value="3"{if $privacy[$key] == "3"} selected="selected"{/if}>{lang secrecy}</option>
												</select>
												<!--{/if}-->
											</div>
										</li>
									<!--{/if}-->
									<!--{/loop}-->
								</ul>
							</div>
							<!--{if $allowcstatus && in_array('customstatus', $allowitems)}-->
							<div class="guiigo-wblb gg-wblb-zlkz list-block-no bg-c cl">
								<ul>
									<li class="guiigo-flex xh-b cl">
										<div id="th_customstatus" class="wblb-wbbt zy-c">{lang permission_basic_status}</div>
										<div id="td_customstatus" class="wblb-wbnr zy-h"><input type="text" value="$space[customstatus]" name="customstatus" id="customstatus" class="px" /></div>
									</li>
								</ul>
							</div>
							<!--{/if}-->
							<!--{if $_G['group']['maxsigsize'] && in_array('sightml', $allowitems)}-->
							<div class="guiigo-wblb gg-wblb-zlkz list-block-no bg-c cl">
								<ul>
									<li id="td_sightml" class="wblb-dkbt bg-g xh-b zy-c cl">{lang personal_signature}</li>
									<li id="td_sightml" class="wblb-nrsr xh-b zy-h cl">
										<div class="wblb-wbnr zy-h"><textarea rows="3" cols="80" name="sightml" id="sightmlmessage" class="guiigo-pt s-a">$space[sightml]</textarea></div>
									</li>
								</ul>
							</div>
							<!--{/if}-->
							<!--{if $operation == 'contact'}-->
							<div class="guiigo-wblb gg-wblb-zlkz list-block-no bg-c cl">
								<ul>
									<li id="th_sightml" class="guiigo-flex xh-b cl">
										<div id="th_sightml" class="wblb-wbbt zy-c">Email</div>
										<div id="td_sightml" class="wblb-wbnr zy-h">$space[email]<a href="home.php?mod=spacecp&ac=profile&op=password">{lang modify}</a></div>
									</li>
								</ul>
							</div>
							<!--{/if}-->

							<!--{if $operation == 'plugin'}-->
								<!--{eval include(template($_GET['id']));}-->
							<!--{/if}-->
							<!--{if $showbtn}-->
								<input type="hidden" name="profilesubmit" value="true" />
								<div class="mn-a">
									<button type="button" id="profilesubmitbtn" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang save}</button>
									<input type="hidden" name="profilesubmitbtn" value="true" />
									<span id="submit_result" class="rq"></span>
								</div>
							<!--{/if}-->
						</form>
						<script type="text/javascript">
							ck8(function(){
								var inputfile = ck8('input[type="file"]')
								for(var i=0; i< inputfile.length; i++){
									var obj = ck8(inputfile[i]);
									obj.on('change',function(o){
										_fileup(o)
									})
									var Dom = '<div class="zlxk-tpsc bg-e zy-c"><i class="icon guiigoapp-sctp"></i>{lang guiigo_manage:tlang0262}</div>';
									inputfile.addClass('zlxk-gnkz').after(Dom)
								}
							})

							function _fileup(obj){
								var reads = new FileReader();
								var objid = ck8('#td_' + obj.srcElement.id);

								var ahtml ='';
								reads.readAsDataURL(obj.target.files[0])
								reads.onload = function(){
									if(objid.find('a').length <= 0){
										ahtml = ck8('<a />',{href:'javascript:;'});
										ahtml = ck8(ahtml).append(
										'<img src="'+ this.result+'" width="200" class="mtm">'
										);
									}
									if(ahtml){
										objid.append(ahtml)
									}else{
										objid.find('a').html(
										'<img src="'+ this.result+'" width="200" class="mtm">'
										)
									}
								}
							}

							function show_error(fieldid, extrainfo) {
								var elem = Dz('th_'+fieldid);
								if(elem) {
									elem.className = "wblb-wbbt icon guiigoapp-jinggao zy-i";
									extrainfo = (typeof extrainfo == "string") ? extrainfo : "";
									Dz(fieldid).focus();
								}
							}
							function show_success(message) {
								var urls = 'home.php?mod=spacecp&ac=profile';
								message = message == '' ? '{lang update_date_success}' : message;
								ck8.toast(message,'shibai');
								<!--{if $operation != 'verify'}-->
									<!--{loop $profilegroup $key $value}-->
										<!--{if $value[available]}-->
										<!--{if $opactives[$key]}-->
										
										   urls = 'home.php?mod=spacecp&ac=profile&op=$key';
											 <!--{eval break;}-->
										<!--{/if}-->
										<!--{/if}-->
									<!--{/loop}-->
								<!--{else}-->
									<!--{if $_G[setting][verify]}-->
										<!--{loop $_G['setting']['verify'] $vid $verify}-->
											<!--{if $verify['available'] && (empty($verify['groupid']) || in_array($_G['groupid'], $verify['groupid']))}-->
												<!--{if $vid != 7}-->
												<!--{if $opactives['verify'.$vid]}-->
										
										   urls = 'home.php?mod=spacecp&ac=profile&op=verify&vid=$vid';
											 <!--{eval break;}-->
										<!--{/if}-->
													
												<!--{/if}-->
											<!--{/if}-->
										<!--{/loop}-->
									<!--{/if}-->
								<!--{/if}-->
								 app.PageRefresh(false,'gg-kj-zrol',urls)
							}
							function clearErrorInfo() {
								var spanObj = Dz('profilelist').getElementsByTagName("div");
								for(var i in spanObj) {
									if(typeof spanObj[i].id != "undefined" && spanObj[i].id.indexOf("_")) {
										var ids = explode('_', spanObj[i].id);
										if(ids[0] == "showerror") {
											spanObj[i].innerHTML = '';
											Dz('th_'+ids[1]).className = '';
										}
									}
								}
							}
						</script>
					</div>
				<!--{/if}-->
			<!--{/if}-->
		$guiigo_config['footer_html']
		</div>
	</div>		
</div>
<!--{template common/footer}-->