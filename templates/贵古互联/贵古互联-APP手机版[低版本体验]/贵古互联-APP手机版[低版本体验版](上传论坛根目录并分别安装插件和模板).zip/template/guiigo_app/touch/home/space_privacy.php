<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['home_tpl_titles'] = array('{lang remind}');}-->
<!--{template common/header}-->
{eval 
	$space['isfriend'] = $space['self'];
	if(in_array($_G['uid'], (array)$space['friends'])) $space['isfriend'] = 1;
	space_merge($space, 'count');
	space_merge($space, 'field_home');
}
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-privacy">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0527}</h1>
	</header>
	<div class="content">
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-kj-xssz">
				<div id="prkonzs2">
					<div class="guiigo-wnrtx guiigo-wnrtxx gg-kj-ysts">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0762}</p>
					</div>
				</div>
				<div id="prkonzs3">
					<div class="guiigo-wnrtx guiigo-wnrtxx gg-kj-ysts">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0762}</p>
					</div>
				</div>
				<div id="prkonzs4">
					<div class="guiigo-wnrtx guiigo-wnrtxx gg-kj-ysts">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0762}</p>
					</div>
				</div>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript">
	function fuidgoto(fuid) {
		var parameter = fuid != '' ? '&fuid='+fuid : '';
		window.location.href = 'home.php?mod=space&do=album&view=we'+parameter;
	}
	</script>
</div>
<!--{template common/footer}-->