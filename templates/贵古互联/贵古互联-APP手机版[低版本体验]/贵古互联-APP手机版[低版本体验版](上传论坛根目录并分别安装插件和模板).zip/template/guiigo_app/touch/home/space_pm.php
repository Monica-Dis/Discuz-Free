<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['home_tpl_titles'] = array('{lang pm}');}-->
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space_pm">
	<header class="gg-app-hide bar bar-nav<!--{if ($filter == 'privatepm') || $filter == 'privatepm' && $newpm || $filter == 'newpm'}--> bg-a yb-a<!--{else}--> guiigo-nydb bg-c xh-b<!--{if $_GET['subop'] == 'viewg' || $_GET['subop'] == 'setting'}--> guiigo-dydb<!--{/if}--><!--{/if}-->">
		<!--{if ($filter == 'privatepm') || $filter == 'privatepm' && $newpm || $filter == 'newpm'}-->
		<a class="button button-link pull-left open-panel"><i class="icon guiigoapp-txcl zy-a zy-ac yz-a"></i><span class="bar-tx"><!--{avatar($_G[uid])}--></span></a>
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-a zy-ac yz-a" style="font-size: 1rem;"></i></a>
		<!--{elseif ($filter == 'announcepm')}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
			<!--{if $_GET['subop'] == 'view'}-->
				<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
			<!--{else}-->
				<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
			<!--{/if}-->
		<!--{/if}-->
		<h1 class="title<!--{if ($filter == 'privatepm') || $filter == 'privatepm' && $newpm || $filter == 'newpm'}--> zy-a zy-ac<!--{else}--> zy-h<!--{/if}-->">
			<!--{if ($filter == 'announcepm')}-->
				{lang guiigo_manage:tlang0748}
			<!--{elseif $_GET['subop'] == 'view'}-->
				<!--{eval $userlist = getuserbyuid($touid);}-->
				{$userlist['username']} <em class="zd-14">{lang guiigo_manage:tlang0749}</em>
			<!--{elseif $_GET['subop'] == 'viewg'}-->
				<!--{if $grouppm[author]}-->$grouppm[author]<!--{else}-->{lang guiigo_manage:tlang0748}<!--{/if}-->
			<!--{elseif $_GET['subop'] == 'setting'}-->
				{lang guiigo_manage:tlang0750}
			<!--{else}-->
				{lang news}
			<!--{/if}-->
		</h1>
	</header>
	<!--{if ($filter == 'privatepm') || $filter == 'privatepm' && $newpm || $filter == 'newpm'}--><!--{template common/footer_nav}--><!--{/if}-->
	<!--{if $_GET['subop'] == 'view'}-->
		<div id="spacepmf" class="content content-inner infinite-scroll infinite-scroll-top pm-scroll" 
			data-url="home.php?mod=space&do=pm&subop=view&touid=$touid" 
			data-pages="{$count}" 
			data-ppp="{$perpage}" 
			data-page="$page" 
			data-islod="false">
	<!--{else}-->
		<div class="content pms-scroll">
	<!--{/if}-->
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
		<!--{if ($filter == 'privatepm') || $filter == 'privatepm' && $newpm || $filter == 'newpm'}-->
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<li><a href="home.php?mod=spacecp&ac=pm" class="zy-f xh-b"><i class="icon guiigoapp-bianji"></i>{lang guiigo_manage:tlang0562}</a></li>
						<li><a href="home.php?mod=space&do=pm&subop=setting" class="zy-f"><i class="icon guiigoapp-kjzlbj"></i>{lang guiigo_manage:tlang0750}</a></li>
					</ul>
				</div>
			</div>
		<!--{/if}-->
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if ($filter == 'privatepm') || $filter == 'privatepm' && $newpm || $filter == 'newpm'}-->
				<div class="guiigo-hylb list-block-no xh-b bg-c">
					<ul class="ms-c">
						<li class="sh-a">
							<a href="home.php?mod=space&do=pm&filter=announcepm">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/xtxx.jpg" class="guiigo-ty">
								<i class="icon guiigoapp-xzdk guiigoapp-xzdks zy-g"></i>
								<span class="xttz-hdts"></span>
								<h2 class="hylb-bd zy-h">{lang guiigo_manage:tlang0748}</h2>
							</a>
						</li>
						<!--{loop $_G['notice_structure'] $key $type}-->
						<li class="sh-a">
							<a href="home.php?mod=space&do=notice&view=$key">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/gg-xx-$key.jpg" class="guiigo-ty">
								<i class="icon guiigoapp-xzdk guiigoapp-xzdks zy-g"></i>
								<!--{if $_G['member']['category_num'][$key]}--><span class="xttz-hdts guiigo-yjsz bg-j zy-a">$_G['member']['category_num'][$key]</span><!--{/if}-->
								<h2 class="hylb-bd zy-h"><!--{eval echo lang('template', 'notice_'.$key)}--></h2>
							</a>
						</li>
						<!--{/loop}-->
					</ul>
				</div>
				<script>
				function showMn(){
					var Obj = $('.guiigo-barcd-s')
					if(Obj.css('display') == 'none'){
						Obj._show(200)
					}else{
						Obj.hide()
					}
				}
				</script>
			<!--{/if}-->
			<!--{if ($filter == 'privatepm' && $newpm) || $filter == 'newpm'}-->
			<div class="gg-xx-xxsk ms-a">
				<!--{if $filter != 'newpm'}-->
					<a href="javascript:;" onclick="app.LoadPageForumView('.pms-scroll','home.php?mod=space&do=pm&filter=newpm',['gg-xx-xxsk','gg-xx-xxlb']);" class="zy-a"><i class="icon guiigoapp-nydbpl bg-b"></i>$newpmcount {lang guiigo_manage:tlang0751}<i class="icon guiigoapp-xzdk zy-a"></i></a>
				<!--{else}-->
					<a href="javascript:;" onclick="app.LoadPageForumView('.pms-scroll','home.php?mod=space&do=pm&filter=privatepm',['gg-xx-xxsk','gg-xx-xxlb']);" class="zy-a"><i class="icon guiigoapp-nydbpl bg-b"></i>{lang guiigo_manage:tlang0752}<i class="icon guiigoapp-xzdk zy-a"></i></a>
				<!--{/if}-->
			</div>
			<!--{/if}-->
			<!--{if $_GET['subop'] == 'view'}-->
				<!--{if $list && !$daterange}-->
					<div id="pm_ul" class="gg-xx-xxnr">
						<!--{loop $list $key $value}-->
							<!--{subtemplate home/space_pm_node}-->
						<!--{/loop}-->
						<div id="pm_append" style="display: none"></div>
					</div>
					<div id="pm_uls" class="gg-xx-czcx"></div>
					<script>
					$('#pm_uls').click(function(){
						var Obj = $(this)
						if(Obj.css('display') == 'none'){
							Obj.show(100)
						}else{
							Obj.hide()
						}
						$('.pmlistmn').hide()
					})
					function showMn(el){
						var Obj = $(el)
						if(Obj.css('display') == 'none'){
							Obj._show(100)
							$('#pm_uls').show()
						}else{
							Obj.hide()
							$('#pm_uls').hide()
						}
					}

					function MsgCallPm(msg,par,param){
						if(typeof msg === 'object' || typeof par === 'object'){
							if (param.type == 'pm_report'){
								ck8.toast('{lang guiigo_manage:tlang0753}');
							}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0754}') != -1 && param.type == 'deletepm'){
								ck8.toast('{lang guiigo_manage:tlang0561}');
								ck8('#pmlist_' + param.pmid).remove()
							}else {
								ck8.toast(msg.msg,'shibai');
							}
						}else{
							ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
						}
					}
					</script>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0755}</p>
					</div>
				<!--{/if}-->
			<!--{elseif $_GET['subop'] == 'viewg'}-->
				<!--{if $grouppm}-->
					<div id="pm_ul" class="gg-xx-xtxx bg-c ms-a">
						<div class="xtxx-yhxx xh-b">
							<!--{if $grouppm[author]}-->
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/glxx.jpg" class="guiigo-ty">
							<!--{else}-->
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/xtxx.jpg" class="guiigo-ty">
							<!--{/if}-->
							<h2 class="zy-h"><!--{if $grouppm['author']}-->{lang sendmultipmwho}<!--{else}-->{lang sendmultipmsystem}<!--{/if}--></h2>
							<p class="zy-c"><!--{date($grouppm[dateline], 'u')}--></p>
						</div>
						<div class="xtxx-xxnr">$grouppm[message]</div>
					</div>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0756}</p>
					</div>
				<!--{/if}-->
			<!--{elseif $_GET['subop'] == 'setting'}-->
				<div class="gg-xx-xxsz ms-a">
					<form id="pmsettingform" 
					name="pmsettingform" 
					method="post" 
					autocomplete="off" 
					action="home.php?mod=spacecp&ac=pm&op=setting"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pmid:'',type:'pmsettingform'},fn:'MsgCallPm',load:'true',uid:'$_G[uid]'}"  
					>
						<div class="xxsz-pbtr bg-c sh-a xh-b">
							<div class="pbtr-btys zy-h">{lang guiigo_manage:tlang0757}</div>
							<div class="pbtr-pbxx">
								<label class="guiigo-pds"><input type="radio" name="onlyacceptfriendpm" class="guiigo-pd-k" value="1"{if $acceptfriendpmstatus == 1} checked="checked"{/if} /><span></span>{lang yes}</label>
								<label class="guiigo-pds"><input type="radio" name="onlyacceptfriendpm" class="guiigo-pd-k" value="2"{if $acceptfriendpmstatus == 2} checked="checked"{/if} /><span></span>{lang no}</label>
							</div>
						</div>
						<div class="xxsz-pblb bg-c xh-b">
							<h2 class="zy-h">{lang guiigo_manage:tlang0758}<a href="JavaScript:void(0)" onclick="app.ActionsManage('#guiigo-xxszts','t', 'auto');"><i class="icon guiigoapp-wenhao zy-g"></i></a></h2>
							<textarea id="ignorelist" name="ignorelist" cols="40" rows="3" class="guiigo-pt bg-e">{echo htmlspecialchars($ignorelist)}</textarea>
						</div>
						<div class="mn-a">
							<button type="submit" name="settingsubmit" value="true" class="formdialog guiigo-pn ab-az zy-ac zy-a">{lang save}</button>
						</div>
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="hidden" name="settingsubmit" value="true" />
					</form>
				</div>
				<div class="popup-actions" id="guiigo-xxszts">
					<div class="actions-text gg-xx-szts">
						<div class="szts-tsnr zy-f bg-c">
							{lang ignore_member_pm_message}
						</div>
						<div class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0408}</div>
					</div>
				</div>
				<script>			
					function MsgCallPm(msg,par,param){
						if(typeof msg === 'object' || typeof par === 'object'){
							if (msg.msg.indexOf('{lang guiigo_manage:tlang0759}') != -1 && param.type == 'pmsettingform'){
								ck8.toast('{lang guiigo_manage:tlang0455}');
								setTimeout(function(){
									ck8.router.back()
								},1000)
							}else {
								ck8.toast(msg.msg,'shibai');
							}
						}else{
							ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
						}
					}
				</script>
			<!--{else}-->
				<!--{if $count || $grouppms}-->
					<div class="gg-xx-xxlb list-block-no bg-c ms-a">
						<ul class="ms-c">
						<!--{if $grouppms}-->
							<!--{loop $grouppms $grouppm}-->
								<li id="gpmlist_$grouppm[id]" class="sh-a">
									<a href="home.php?mod=space&do=pm&subop=viewg&pmid=$grouppm[id]" class="guiigo-tys">
										<!--{if $grouppm[author]}-->
											<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/glxx.jpg">
										<!--{else}-->
											<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/xtxx.jpg">
										<!--{/if}-->
										<h2 class="zy-e"><!--{if $grouppm[author]}-->$grouppm[author]<!--{else}-->{lang guiigo_manage:tlang0748}<!--{/if}--></h2>
										<p class="zy-c"><!--{echo cutstr($grouppm[message],46)}--></p>
										<span class="zy-g"><!--{date($grouppm[dateline], 'u')}--></span>
									</a>
								</li>
							<!--{/loop}-->
						<!--{/if}-->
						<!--{loop $list $key $value}-->
							<li id="pmlist_$value[plid]" class="sh-a">										
								<a href="javascript:;"
									class="guiigo-tys getpm-popup"
									data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$value[touid]&touid=$value[touid]&pmid=0&daterange=2"
									external>
									<!--{avatar($value[touid],middle)}-->
									<!--{if $value[new]}--><div class="xxlb-xxhd bg-j"></div><!--{/if}-->
									<h2 class="zy-e">{$value[tousername]}</h2>
									<p class="zy-c"><!--{echo cutstr($value[lastsummary],46)}--></p>
									<span class="zy-g"><!--{date($value[lastdateline], 'u')}--></span>
								</a>
							</li>
						<!--{/loop}-->
						</ul>
					</div>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c">{lang guiigo_manage:tlang0760}</p>
					</div>
				<!--{/if}-->
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{template common/footer}-->