<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp-credit-log">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<!--{if $guiigo_config['isguiigoapp']}-->
		<a class="button button-link pull-left app-back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{else}-->
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0545}</h1>
	</header>

	<div class="content infinite-scroll spacecp-credit-scroll" data-url="$theurl" data-pages="{$count}" data-ppp="{$perpage}" data-page="$page" data-islod="false" data-distance="10" data-ptr-distance="50">
		<div class="list-block">
			<form method="post" action="home.php?mod=spacecp&ac=credit&op=log">
				<div class="gg-jfjl list-block-no">
					<ul class="list-container">
					<!--{loop $loglist $value}-->
					<!--{eval $value = makecreditlog($value, $otherinfo);}-->
						<li class="xh-b">
							<div class="jfjl-jfzs">$value['credit']</div>
							<div class="jfjl-jfjs"><!--{if $value['operation']}-->$value['opinfo']<!--{else}-->$value['text']<!--{/if}--></div>
							<div class="jfjl-jfsj">$value['dateline']</div>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
				<input type="hidden" name="op" value="log" />
				<input type="hidden" name="ac" value="credit" />
				<input type="hidden" name="mod" value="spacecp" />
			</form>
			
			<div class="infinite-scroll-preloader guiigo-zdjz" style="visibility:hidden;">
			    <div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
			</div>
			
		</div>
	</div>
</div>
<!--{template common/footer}-->