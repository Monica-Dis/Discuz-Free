<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp-ecreta">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<h1 class="title zy-h">{lang eccredit}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<form method="post" 
			autocomplete="off" 
			id="postform" 
			name="postform" 
			action="home.php?mod=spacecp&ac=eccredit&op=rate"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{pmid:'',type:'postform'},fn:'MsgCallCprate',load:'true',uid:'$_G[uid]'}"  
			>
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="referer" value="{echo dreferer()}" />
				<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang eccredit_retee}</div>
							<div class="wblb-wbnr">
							<!--{if $_G['uid'] == $order[buyerid]}-->
								<a href="home.php?mod=space&uid=$order[sellerid]&do=profile" class="zy-h"><span class="wbnr-yhtx"><!--{avatar($order[sellerid],middle)}--></span>$order[seller]</a>
								<a href="javascript:;" 
								class="getpm-popup lxmj-lxan bk-b zy-b" 
								data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$order[sellerid]&touid=$order[sellerid]&pmid=0&daterange=2" 
								external>{lang guiigo_manage:tlang0562}</a>
							<!--{else}-->
								<a href="home.php?mod=space&uid=$order[buyerid]&do=profile" class="zy-h"><span class="wbnr-yhtx"><!--{avatar($order[buyerid],middle)}--></span>$order[buyer]</a>
								<a href="javascript:;" 
								class="getpm-popup lxmj-lxan bk-b zy-b" 
								data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$order[buyerid]&touid=$order[buyerid]&pmid=0&daterange=2" 
								external>{lang guiigo_manage:tlang0562}</a>
							<!--{/if}-->
							</div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang eccredit_tradegoods}</div>
							<div class="wblb-wbnr"><a href="forum.php?mod=redirect&goto=findpost&pid=$order[pid]" class="zy-h">$order[subject]</a></div>
						</li>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0563}</div>
							<div class="wblb-wbnr">
								<label for="rate_good" class="guiigo-pds"><input id="rate_good" name="score" value="1" type="radio" class="guiigo-pd-k" checked="checked" /><span></span> <span class="zy-i"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/reta-hp.png" border="0" width="22" height="22" class="vm"/> {lang eccredit_good}<!--{if !$order[offline]}-->{lang eccredit_good_comment}<!--{/if}--></span></label>
								<label for="rate_soso" class="guiigo-pds"><input id="rate_soso" name="score" value="0" type="radio" class="guiigo-pd-k" /><span></span> <span class="zy-o"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/reta-zp.png" border="0" width="22" height="22" class="vm"/> {lang eccredit_soso}<!--{if !$order[offline]}-->{lang eccredit_soso_comment}<!--{/if}--></span></label>
								<label for="rate_bad" class="guiigo-pds"><input id="rate_bad" name="score" value="-1" type="radio" class="guiigo-pd-k" /><span></span> <img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/reta-cp.png" border="0" width="22" height="22" class="vm"/> {lang eccredit_bad}<!--{if !$order[offline]}-->{lang eccredit_bad_comment}<!--{/if}--></label>
							</div>
						</li>
						<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang guiigo_manage:tlang0564}</li>
						<li class="wblb-nrsr xh-b zy-h cl">
							<div class="wblb-wbnr zy-h">
								<textarea name="message" rows="5" cols="60" maxlength="50" class="guiigo-pt s-a"></textarea>
							</div>
						</li>
					</ul>
				</div>
				<input type="hidden" name="orderid" value="$orderid">
				<input type="hidden" name="type" value="$type">
				<div class="mn-a">
					<button type="submit" class="formdialog guiigo-pn ab-az zy-a zy-ac" id="postsubmit" name="ratesubmit" value="true">{lang submit}</button>
				</div>
				<input type="hidden" name="ratesubmit" value="true" />
			</form>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>			
		function MsgCallCprate(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0565}') != -1 && param.type == 'postform'){
					ck8.toast('{lang guiigo_manage:tlang0566}');
					setTimeout(function(){
						ck8.router.load('portal.php?mod=index',true);
					}, 3000)
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}
	</script>
</div>
<!--{template common/footer}-->