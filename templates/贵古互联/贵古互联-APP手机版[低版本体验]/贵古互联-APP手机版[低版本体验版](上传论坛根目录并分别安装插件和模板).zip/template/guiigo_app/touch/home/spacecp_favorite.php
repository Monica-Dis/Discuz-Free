<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="tip">
<!--{if $_GET['op'] == 'delete'}-->
	<form id="favoriteform_{$favid}" 
		name="favoriteform_{$favid}" 
		method="post" 
		autocomplete="off" 
		action="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favid&type=$_GET[type]&mobile=2" 
		style="height:inherit;" 
		ck-cus="true" 
		ck-param="{type:'modal',mw:'true',load:'true',fn:{if $_GET['fn']}'$_GET['fn']'{/if}}">
		<input type="hidden" name="referer" value="{eval echo dreferer();}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="modal-text">{lang guiigo_manage:tlang0567}</div>
		<input type="hidden" name="deletesubmitbtn" value="{lang determine}" class="formdialog">
	</form>
<!--{else}-->
	<form method="post" 
		autocomplete="off" 
		id="favoriteform_{$id}" 
		name="favoriteform_{$id}" 
		action="home.php?mod=spacecp&ac=favorite&type=$type&id=$id&spaceuid=$spaceuid&mobile=2" 
		ck-cus="true" 
		ck-param="{type:'modal',load:'true',fn:{if $_GET['fn']}'$_GET['fn']'{/if}}">
		<input type="hidden" name="favoritesubmit" value="true" />
		<input type="hidden" name="referer" value="{eval echo dreferer();}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="gg-kg-scsm guiigo-flex">
			<div class="scsm-xmbt zy-c">{lang favorite_description}</div>
			<div class="scsm-xmnr guiigo-flexy"><textarea id="general_{$id}" name="description" rows="1" class="guiigo-px bg-e" ><!--{if $description}-->$description<!--{else}-->{lang favorite_description_default}<!--{/if}--></textarea></div>
			<input type="hidden" name="favoritesubmit_btn" id="favoritesubmit_btn"  value="{lang determine}" class="formdialog" >
		</div>
	</form>
<!--{/if}-->
</div>
<!--{template common/footer}-->