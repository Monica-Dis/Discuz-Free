<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['home_tpl_titles'] = array('{lang message}');}-->
<!--{template common/header}-->
<div class="page page-current" data-mod="space-profile">
	<div class="content">
		<div class="list-block">
			<div id="prkonzs4">
				<div id="prkonzs4-page" class="ms-a"
				data-url="$theurl" 
				data-pages="{$count}" 
				data-ppp="{$perpage}" 
				data-page="$page" 
				data-islod="false" 
				data-distance="20">
					<!--{if $count}-->
						<div id="comment">
							<div id="comment_ul" class="gg-kj-sssj bg-c sh-a">
								<ul class="list-container">
									<!--{loop $list $k $value}-->
										<!--{template home/space_comment_li}-->
									<!--{/loop}-->
								</ul>
							</div>
						</div>
					<!--{else}-->
						<div class="guiigo-wnrtx guiigo-wnrtxx">
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
							<p class="zy-c">{lang guiigo_manage:tlang0812}</p>
						</div>
					<!--{/if}-->
					<!--{if $count}-->
						<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
							<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
						</div>
						<div onclick="infinite('#prkonzs4-page')" class="loadpage bg-c bk-e zy-c">{lang guiigo_manage:tlang0492}</div>
					<!--{/if}-->
					<!--{if helper_access::check_module('wall')}-->
					<div class="gg-kj-lyan"><a href="javascript:;" class="zy-a bg-h zy-ac" onclick="app.ActionsManage('#guiigo-hfdp','t','auto','closehfdp');$('#message').focus();"><i class="icon guiigoapp-fbxhfb"></i></a></div>
				<!--{/if}-->
				<!--{if helper_access::check_module('wall')}-->
					<div class="popup-actions" id="guiigo-hfdp">
						<div class="actions-text guiigo-hfdp bg-c">
							<form id="quickcommentform_{$space[uid]}" 
							action="home.php?mod=spacecp&ac=comment" 
							method="post" 
							autocomplete="off"
							ck-cus="true" 
							ck-param="{type:'modal',load:'true',callpar:{uid:'$space[uid]',type:'reply'},fn:'MsgCallportal',uid:'$_G[uid]'}">
								<div class="hfdp-btys xh-b bg-g">
									<a href="javascript:;" class="btys-gbck closehfdp"><i class="icon guiigoapp-guanbi zy-c"></i></a>
									<h2 class="zy-h">{lang guiigo_manage:tlang0620}</h2>
								</div>
								<div class="hfdp-srys xh-b bg-c" style="padding: 0 .55rem;">
									<!--{if $_G['uid'] || $_G['group']['allowcomment']}-->
										<textarea id="message" name="message" rows="5" class="guiigo-pt zy-f" placeholder="{lang guiigo_manage:tlang0229}"></textarea>
									<!--{elseif $_G['connectguest']}-->
										<div class="srys-qtts"><i class="icon guiigoapp-kjsyrz"></i>{lang connect_fill_profile_to_comment}</div>
									<!--{else}-->
										<div class="srys-qtts"><i class="icon guiigoapp-tbxhjb"></i>{lang login_to_wall} <a href="member.php?mod=logging&action=login">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}">$_G['setting']['reglinkname']</a></div>
									<!--{/if}-->
								</div>
								<div class="hfdp-crqd xh-b bg-g">
									<div class="crqd-gdqd">
										<input type="hidden" name="referer" value="home.php?mod=space&uid=$wall[uid]&do=wall" />
										<input type="hidden" name="id" value="$space[uid]" />
										<input type="hidden" name="idtype" value="uid" />
										<input type="hidden" name="handlekey" value="qcwall_{$space[uid]}" />
										<input type="hidden" name="commentsubmit" value="true" />
										<input type="hidden" name="quickcomment" value="true" />
										<button type="submit" name="commentsubmit_btn" value="true" id="commentsubmit_btn" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang leave_comments}</button>
										<span id="return_qcwall_{$space[uid]}"></span>
										<input type="hidden" name="formhash" value="{FORMHASH}" />
									</div>
									<input type="hidden" name="formhash" value="{FORMHASH}" />
									<div class="crqd-btat">
										<ul>
											<li><a href="JavaScript:void(0)" class="zy-c" onclick="showFace('appendface', 'message',this)"><i class="icon guiigoapp-biaoqing" style="font-size: .75rem;height: .85rem;line-height: .85rem;"></i><p>{lang guiigo_manage:tlang0150}</p></a></li>
										</ul>
									</div>
								</div>
								<div class="bg-c cl">
									<div class="kznr-bqnr cl">
										<div class="bqnr-imgs bqnr-wdbj cl">
											<ul>
												<div class="kznr-bqnr cl" style="display:none;" id="appendface"></div>
											</ul>
										</div>
									</div>
								</div>
							</form>
						</div>
					</div>
					<script type="text/javascript">
					function MsgCallportal(msg,par,param){
						if(typeof msg === 'object' || typeof par === 'object'){
							if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'reply'){
								app.close_popup()
								ck8('#message').val('');
								app.PageRefresh(false,'#prkonzs4-page','home.php?mod=space&uid='+ param.uid +'&do=wall')
								ck8.toast('{lang guiigo_manage:tlang0813}');
							}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0814}') != -1 && param.type == 'reply'){
								ck8.toast('{lang guiigo_manage:tlang0815}');
							}else {
								ck8.toast(msg.msg,'shibai');
							}
						}else{
							ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
						}
					}
					function MsgCallwzplx(msg,par,param){
						if(typeof msg === 'object' || typeof par === 'object'){
							if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'bianji'){
								ck8.toast('{lang guiigo_manage:tlang0238}');
							}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'shanchu'){
								ck8.toast('{lang guiigo_manage:tlang0237}');
							}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0817}') != -1 && param.type == 'shanchu'){
								ck8.toast('{lang guiigo_manage:tlang0816}');
							}else {
								ck8.toast(msg.msg,'shibai');
							}
						}else{
							ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
						}
					}
					</script>
				<!--{/if}-->
				</div>
			</div>
		</div>
	</div>
	<script type="text/javascript">
	function fuidgoto(fuid) {
		var parameter = fuid != '' ? '&fuid='+fuid : '';
		window.location.href = 'home.php?mod=space&do=album&view=we'+parameter;
	}
	function showMn(){
		var Obj = $('.guiigo-barcd-s')
		if(Obj.css('display') == 'none'){
			Obj._show(200)
		}else{
			Obj.hide()
		}
	}
	</script>
</div>
<!--{template common/footer}-->