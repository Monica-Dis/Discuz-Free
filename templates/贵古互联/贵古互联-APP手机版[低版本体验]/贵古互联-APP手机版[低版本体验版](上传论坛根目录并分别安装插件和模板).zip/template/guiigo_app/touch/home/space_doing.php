<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-doing">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<!--{if helper_access::check_module('doing')}--><a href="javascript:;" class="button button-link pull-right" onclick="app.ActionsManage('#moodfm','t','auto','closehfdp');$('#message').focus();"><i class="icon guiigoapp-fabu zy-f"></i></a><!--{/if}-->
		<h1 class="title zy-h">{lang guiigo_manage:tlang0696}</h1>
	</header>
	<div class="content infinite-scroll doing-scroll"
		data-url="$theurl" 
		data-pages="{$count}" 
		data-ppp="{$perpage}" 
		data-page="$page" 
		data-islod="false" 
		data-distance="10">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="gg-kj-rwbg">
				<img src="template/guiigo_app/static/images/sbbg.jpg" class="vm">
				<div class="guiigo-bwdx">
					<div class="guiigo-bwdx-a"></div>
					<div class="guiigo-bwdx-b"></div>
				</div>
			</div>
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacedoing list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $actives[me]}--> on<!--{/if}-->"><a {if $_G[uid]}href="javascript:;" onclick="app.LoadPageForumView('.doing-scroll','home.php?mod=space&do=doing&view=me',['gg-kj-ssol']);"{else}href="member.php?mod=logging&action=login"{/if}><!--{if $space[self]}-->{lang guiigo_manage:tlang0667}<!--{else}-->TA<!--{/if}-->{lang guiigo_manage:tlang0697}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[we]}--> on<!--{/if}-->"><a {if $_G[uid]}href="javascript:;" onclick="app.LoadPageForumView('.doing-scroll','home.php?mod=space&do=doing&view=we',['gg-kj-ssol']);"{else}href="member.php?mod=logging&action=login"{/if}>{lang guiigo_manage:tlang0698}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[all]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.doing-scroll','home.php?mod=space&do=doing&view=all',['gg-kj-ssol']);">{lang view_all}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div id="ssol-jz" class="gg-kj-ssol">
				<!--{if $dolist}-->
					<div class="gg-kj-sssj ms-a bg-c sh-a">
						<ul class="list-container">
						<!--{loop $dolist $dv}-->
						<!--{eval $doid = $dv[doid];}-->
						<!--{eval $_GET[key] = $key = random(8);}-->
							<li id="{$key}dl{$doid}" class="xh-b cl">
								<!--{if $dv[status] == 1}--><div class="sssj-ddsh zy-i"><i class="icon guiigoapp-ssdsh"></i></div><!--{/if}-->
								<div class="sssj-sstx guiigo-ty"><a href="home.php?mod=space&uid=$dv[uid]&do=profile"><!--{avatar($dv[uid],middle)}--></a></div>
								<div class="sssj-ssnr sssj-ssnrp">
									<h1 class="zy-e">
										<span class="gg-kj-plcz">
											<!--{if helper_access::check_module('doing')}-->
												<a href="home.php?mod=spacecp&ac=doing&op=docomment&handlekey=msg_0&doid=$doid&id=0&key=$key" 
												class="dialog bg-e zy-g bk-e"
												ck-cus="true" 
												ck-param="{type:'modal',callpar:{type:'huifu'},fn:'MsgCallwzplx',load:'true',uid: '$_G[uid]'}" 
												external ><i class="icon guiigoapp-sshuifu"></i></a>
											<!--{/if}-->
											<!--{if $dv[uid]==$_G[uid]}-->
												<a href="home.php?mod=spacecp&ac=doing&op=delete&doid=$doid&id=$dv[id]&handlekey={$key}dl{$doid}" 
												class="dialog bg-e zy-g bk-e" 
												ck-cus="true" 
												ck-param="{type:'modal',callpar:{type:'shanchu'},fn:'MsgCallwzplx',load:'true',uid: '$_G[uid]'}" 
												external ><i class="icon guiigoapp-shanchu"></i></a>
											<!--{/if}-->
										</span>
										<a href="home.php?mod=space&uid=$dv[uid]" class="zy-c">$dv[username]</a>
										<p class="zy-c"><!--{date($dv['dateline'], 'u')}--><!--{if checkperm('managedoing')}--><em class="zy-g"> IP: $dv[ip]</em><!--{/if}--></p>
									</h1>
									<div class="gg-kj-plnr zy-e">$dv[message]</div>
									<!--{eval $list = $clist[$doid];}-->
									<div class="ssnr-hfnr list-block-no bg-e" id="{$key}_$doid" {if empty($list) || !$showdoinglist[$doid]} style="display:none;"{/if}>
										<!--{template home/space_doing_li}-->
									</div>
								</div>
							</li>
						<!--{/loop}-->
						</ul>
					</div>
				<!--{else}-->
					<div class="guiigo-wnrtx">
						<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
						<p class="zy-c"><!--{if $actives[me]}--><!--{if $space[self]}-->{lang guiigo_manage:tlang0699}<!--{else}-->TA<!--{/if}-->{lang guiigo_manage:tlang0700}<!--{elseif $actives[we]}-->{lang guiigo_manage:tlang0701}<!--{elseif $actives[all]}-->{lang guiigo_manage:tlang0702}<!--{/if}--></p>
						<!--{if $space[self]}--><!--{if helper_access::check_module('doing')}--><a href="javascript:;" class="ab-az zy-a zy-ac" onclick="app.ActionsManage('#moodfm','t','auto','closehfdp');$('#message').focus();">{lang guiigo_manage:tlang0703}</a><!--{/if}--><!--{/if}-->
					</div>
				<!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
		<!--{if $multi}-->
		<div class="infinite-scroll-preloader guiigo-zdjz">
			<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
		</div>
		<!--{/if}-->
	</div>
	<!--{if helper_access::check_module('doing')}-->
		<!--{template home/space_doing_form}-->
	<!--{/if}-->
	<script>
	function MsgCallwzplx(msg,par,param){
		ck8.closeModal();
		if(typeof msg === 'object' || typeof par === 'object'){
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'repltxt'){
				ck8.toast('{lang guiigo_manage:tlang0214}');
				docomment_get(par.doid, param.key)
			}else if(param.type == 'huifu'){
			}else if(param.type == 'shanchu'){
			}else {
				ck8.toast(msg.msg,'shibai');
			}
		}else{
			ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
		}
	}

	function docomment_get(doid, key) {
		ck8.showPreloader('','load');
		ck8.ajax({
			type : 'GET',
			url : 'home.php?mod=spacecp&ac=doing&op=getcomment&handlekey=msg_'+doid+'&doid='+doid+'&key='+key + '&inajax=1',
			dataType : 'xml',
			success: function(s){
				setTimeout(function(){ck8.hidePreloader()}, 100);
				s = s.lastChild.firstChild.nodeValue;
				var Dom = ck8.getDom(s)
				var refId = '#'+key+'_getcomment_'+doid
				var isShow = Dz(key+'_'+doid).style.display;
				if(isShow == 'none'){
					Dz(key+'_'+doid).style.display = 'block';
					ck8('#'+key+'_'+doid).html(Dom.html())
				}else{
					ck8(refId).html(Dom.find(refId).html())
				}
			},
			error: function(){
				ck8.hidePreloader();
				ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
			}
		})
	} 
	</script>
</div>
<!--{template common/footer}-->