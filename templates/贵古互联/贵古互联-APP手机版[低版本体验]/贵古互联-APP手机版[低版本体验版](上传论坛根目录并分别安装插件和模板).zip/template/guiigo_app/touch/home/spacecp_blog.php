<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<!--{if $_GET[op] == 'delete'}-->
<div id="scrz$blogid">
	<form method="post" 
		autocomplete="off" 
		action="home.php?mod=spacecp&ac=blog&op=delete&blogid=$blogid"
		ck-cus="true"
		ck-param="{type:'modal',callpar:{type:'$_GET['op']',bid:'$blogid'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="c">{lang sure_delete_blog}</div>
	</form>
</div>
<!--{elseif $_GET[op] == 'stick'}-->
<div id="rzzd$blogid">
	<form method="post" 
	autocomplete="off" 
	action="home.php?mod=spacecp&ac=blog&op=stick&blogid=$blogid"
	ck-cus="true"
	ck-param="{type:'modal',callpar:{type:'$_GET['op']',bid:'$blogid'},fn:{if $_GET['fn']}'$_GET[fn]'{/if},load:'true',uid:'$_G[uid]'}">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="sticksubmit" value="true" />
		<input type="hidden" name="stickflag" value="$stickflag" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="c"><!--{if $stickflag}-->{lang sure_stick_blog}<!--{else}-->{lang sure_cancel_stick_blog}<!--{/if}--></div>
	</form>
</div>
<!--{elseif $_GET[op] == 'addoption'}-->
	<div class="gg-kg-scsm guiigo-flex">
		<div class="scsm-xmbt zy-c">{lang name}</div>
		<div class="scsm-xmnr guiigo-flexy"><input type="text" name="newsort" id="newsort" class="guiigo-px bg-e" size="30" value=""/></div>
	</div>
<!--{else}-->
<div class="page page-current" data-mod="spacecp_blog">
	<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-dydb bg-c xh-b">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0531}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<form id="ttHtmlEditor" 
			method="post" 
			autocomplete="off" 
			action="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]{if $_GET[modblogkey]}&modblogkey=$_GET[modblogkey]{/if}" 
			enctype="multipart/form-data"
			ck-cus="true"
			ck-param="{type:'modal',callpar:{type:'addblog'},verify:'validate',fn:'addblogfn',load:'true',uid: $_G[uid]}">
				<div class="guiigo-wblb list-block-no ms-a bg-c sh-a cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0532}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="subject" id="subject" value="$blog[subject]" class="guiigo-px s-a" size="60" {if $_GET[op] != 'edit'}onkeyup="relatekw(this,60);"{/if} placeholder="{lang guiigo_manage:tlang0533}"></div>
						</li>
						<!--{if $_G['setting']['blogcategorystat'] && $categoryselect}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang site_categories}</div>
							<div class="wblb-wbnr zy-h">$categoryselect</div>
						</li>
						<!--{/if}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang personal_category}</div>
							<div class="wblb-wbnr zy-h">
								<select name="classid" id="classid" onchange="addSort(this)" class="guiigo-ps">
									<option value="0">------</option>
									<!--{loop $classarr $value}-->
									<!--{if $value['classid'] == $blog['classid']}-->
									<option value="$value[classid]" selected>$value[classname]</option>
									<!--{else}-->
									<option value="$value[classid]">$value[classname]</option>
									<!--{/if}-->
									<!--{/loop}-->
									<!--{if !$blog['uid'] || $blog['uid']==$_G['uid']}--><option value="addoption">+{lang create_new_categories}</option><!--{/if}-->
								</select>
							</div>
						</li>
						<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang guiigo_manage:tlang0534}</li>
						<li class="wblb-nrsr zy-h cl">
							<div class="wblb-wbnr zy-h"><textarea class="guiigo-pt s-a" name="message" id="uchome-ttHtmlEditor" onclick="if(ck8(this).val().indexOf('{lang guiigo_manage:tlang0535}')){ck8(this).val('')}"><!--{if $blog[message]}-->{$blog[message]}<!--{else}-->{lang guiigo_manage:tlang0535}<!--{/if}--></textarea>
							</div>
						</li>
					</ul>
				</div>
				<div class="gg-kj-rftb bg-c">
					<div class="rftb-btan list-block-no xh-b bg-g">
						<ul>
							<li><a href="javascript:;" class="icoFace zy-c" id="faceBox" onclick="showFace('showfaceid','uchome-ttHtmlEditor')"><i class="icon guiigoapp-biaoqing"></i><p>{lang guiigo_manage:tlang0150}</p></a></li>
							<li><a href="javascript:;" class="zy-c"><input type="file" name="Filedata" id="filedata" class="mediaup btan-sctp" accept="image/*" multiple="multiple" onchange="fileup(this);" onclick="showFace('showfaceid','uchome-ttHtmlEditor',1)"/><i class="icon guiigoapp-tupian"></i><p>{lang guiigo_manage:tlang0151}</p></a></li>
						</ul>
					</div>
					<div class="cl" id="showfaceid"></div>
					<div class="cl" id="showimg"></div>
				</div>
				<div class="guiigo-wblb list-block-no bg-c sh-a cl">
					<ul>
						<!--{if $_G['basescript'] != 'portal'}-->
						<li id="uploadPanel" class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0536}</div>
							<div class="wblb-wbnr zy-h">
								<select name="savealbumid" id="savealbumid" class="ps vm" onchange="if(this.value == '-1') {selectCreateTab(0);}">
									<option value="0">{lang default_album}</option>
									<!--{loop $albums $value}-->
									<option value="$value[albumid]">$value[albumname]</option>
									<!--{/loop}-->
									<option value="-1" style="color:red;">+{lang create_new_album}</option>
								</select>
							</div>
						</li>
						<!--{/if}-->
						<li id="createalbum" class="guiigo-flex xh-b cl" style="display:none">
							<div class="wblb-wbnr zy-h"><input type="text" name="newalbum" id="newalbum" class="guiigo-px" value="{lang input_album_name}"  onfocus="if(this.value == '{lang input_album_name}') {this.value = '';}" onblur="if(this.value == '') {this.value = '{lang input_album_name}';}" /></div>
							<div class="wblb-ycan">
								<button type="button" class="guiigo-pn ab-az zy-a zy-ac" onclick="createNewAlbum();">{lang create}</button>
								<button type="button" class="guiigo-pn ab-b zy-a" onclick="selectCreateTab(1);">{lang cancel}</button>
							</div>
						</li>
					</ul>
				</div>
				<div class="guiigo-wblb list-block-no bg-c cl" <!--{if $blog['uid'] && $blog['uid'] != $_G['uid']}--> style="display:none;"<!--{/if}-->>
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang privacy_settings}</div>
							<div class="wblb-wbnr zy-h">
								<select name="friend" onchange="passwordShow(this.value);" class="guiigo-ps">
									<option value="0"$friendarr[0]>{lang friendname_0}</option>
									<option value="1"$friendarr[1]>{lang friendname_1}</option>
									<option value="2"$friendarr[2]>{lang friendname_2}</option>
									<option value="3"$friendarr[3]>{lang friendname_3}</option>
									<option value="4"$friendarr[4]>{lang friendname_4}</option>
								</select>
							</div>
						</li>
						<li id="span_password" class="guiigo-flex xh-b cl" style="$passwordstyle">
							<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0537}</div>
							<div class="wblb-wbnr zy-h"><input type="text" name="password" value="$blog[password]" size="10" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')" class="guiigo-px" /></div>
						</li>
					</ul>
				</div>
				<!--{if $blog['uid'] && $blog['uid'] != $_G['uid']}-->
				    <!--{eval $selectgroupstyle='display:none';}-->
				<!--{/if}-->
				<div id="tb_selectgroup" class="guiigo-wblb list-block-no bg-c cl" style="$selectgroupstyle">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbbt zy-c">{lang specified_friends}</div>
							<div class="wblb-wbnr zy-h">
								<select name="selectgroup" onchange="getgroup(this.value);" class="guiigo-ps">
									<option value="">{lang from_friends_group}</option>
									<!--{loop $groups $key $value}-->
									<option value="$key">$value</option>
									<!--{/loop}-->
								</select>
							</div>
						</li>
						<li class="wblb-dkbt bg-g xh-b zy-c cl">{lang friend_name_space}</li>
						<li class="wblb-nrsr zy-h xh-b cl">
							<div class="wblb-wbnr zy-h"><textarea name="target_names" id="target_names" rows="3" class="guiigo-pt">$blog[target_names]</textarea></div>
						</li>
					</ul>
				</div>
				<div class="guiigo-wblb list-block-no bg-c cl">
					<ul>
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbnr zy-c">{lang comments_not_allowed}</div>
							<div class="guiigo-pc"><input type="checkbox" name="noreply" id="noreply" value="1"{if $blog[noreply]} checked="checked"{/if}><label for="noreply"><em></em></label></div>
						</li>
						<!--{if helper_access::check_module('feed')}-->
						<li class="guiigo-flex xh-b cl">
							<div class="wblb-wbnr zy-c">{lang make_feed}</div>
							<div class="guiigo-pc"><input type="checkbox" name="makefeed" id="makefeed" value="1"{if ckprivacy('blog', 'feed')} checked="checked"{/if}><label for="makefeed"><em></em></label></div>
						</li>
						<!--{/if}-->
					</ul>
				</div>
				<!--{if $secqaacheck || $seccodecheck}-->
					<!--{subtemplate common/seccheck}-->
				<!--{/if}-->
				<div class="mn-a">
					<button type="submit" id="issuance" class="guiigo-pn ab-az zy-a zy-ac formdialog">{lang save_publish}</button>
				</div>
				<input type="hidden" name="blogsubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			</form>
			<script type="text/javascript">
			ck8(function(){
				if(Dz('subject')) {
					Dz('subject').focus();
				}
			})

			function validate() {
				var ret = false;
				<!--{if $_G['setting']['blogcategorystat'] && $_G['setting']['blogcategoryrequired']}-->
				var catObj = $("catid");
				if(catObj) {
					if (catObj.value < 1) {
						 ck8.toast("{lang select_system_cat}",'jinggao');
						catObj.focus();
						ret = true;
					}
				}
				<!--{/if}-->
				return ret;
			}

			function showFace(showid, messageid,strco) {
				var show = $('#'+showid).find('ul')
				if(show.length >= 1 || strco){
					$('#'+showid).html('')
				}else{
					var faceul = document.createElement("ul");
					for(i=1; i<31; i++) {
						var faceli = document.createElement("li");
						faceli.innerHTML = '<img src="' + STATICURL + 'image/smiley/comcom/'+i+'.gif" onclick="insertFace(\''+messageid+'\','+i+')" />';
						faceul.appendChild(faceli);
					}
					$('#'+showid).append(faceul)
				}
			}

			function insertFace(messageid, id, target) {
				var faceText = '[em:'+id+':]';
				var text = $('#'+messageid).val();
				$('#'+messageid).val(text + faceText);
			}

			function fileup(obj){
				var par = {
					upid:'Filedata',
					upurl: "{$_G[siteurl]}misc.php?mod=swfupload&action=swfupload&operation=album",
					uid: discuz_uid ? parseInt(discuz_uid) : 0,
					hash: "$swfconfig[hash]",
					filetype : "$swfconfig[imageexts][ext]",
					maxsize: "$swfconfig[max]",
					callback: fileupcallback,
				}
				app.ImgUpFile(obj,par)
			}

			function fileupcallback(e){
				ck8.closeModal();
				var data = eval('('+e+')');
				if(data.picid && data.url){
					var htms = '<div class="imgviwe">\
									<div class="p_img">\
										<img style="height:60px;width:60px;" id="aimg_'+ data.picid +'" src="'+ data.url +'" />\
									</div>\
									<input type="hidden" name="picids['+ data.picid +']" value="'+ data.picid +'">\
								</div>';
						ck8('#showimg').append(htms);
				} else {
					 ck8.toast('{lang guiigo_manage:tlang0305}','jinggao');
				}
			}

			function createNewAlbum() {
				ck8.showPreloader('',true);
				var inputObj = Dz('newalbum');
				if(inputObj.value == '' || inputObj.value == '{lang input_album_name}') {
					inputObj.value = '{lang input_album_name}';
				} else {
					ck8.ajax({
						type:'GET',
						url: 'home.php?mod=misc&ac=ajax&op=createalbum&inajax=1&name=' + inputObj.value,
						dataType:'xml',
						success: function(s){
							s = s.lastChild.firstChild.nodeValue;
							var aid = parseInt(s);
							var albumList = Dz('savealbumid');
							var haveoption = false;
							for(var i = 0; i < albumList.options.length; i++) {
								if(albumList.options[i].value == aid) {
									albumList.selectedIndex = i;
									haveoption = true;
									break;
								}
							}
							if(!haveoption) {
								var oOption = document.createElement("OPTION");
								oOption.text = ck8.trim(inputObj.value);
								oOption.value = aid;
								albumList.options.add(oOption);
								albumList.selectedIndex = albumList.options.length-1;
							}
							inputObj.value = ''
						}
					})
					selectCreateTab(1)
				}
				setTimeout(function(){ck8.hidePreloader()}, 100);
			}

			function selectCreateTab(flag) {
				var vwObj = Dz('uploadPanel');
				var opObj = Dz('createalbum');
				var selObj = Dz('savealbumid');
				if(flag) {
					vwObj.style.display = '';
					opObj.style.display = 'none';
					selObj.value = selObj.options[0].value;
				} else {
					vwObj.style.display = 'none';
					opObj.style.display = '';
				}
			}

			function addSort(obj) {
				if (obj.value == 'addoption') {
					var url = 'home.php?mod=spacecp&ac=blog&op=addoption&handlekey=addoption'
					ck8.showPreloader('','load');
					ck8.ajax({
						type : 'GET',
						url : url + '&inajax=1',
						dataType : 'xml',
						success: function(s){
							setTimeout(function(){ck8.hidePreloader()}, 100);
							var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
							var buttonss = [
								{
								  text: '{lang guiigo_manage:tlang0105}',
								  onClick: function() {
									$(obj).val(0)
								  }
								},
								{
								  text: '{lang guiigo_manage:tlang0538}',
								  bold: true,
								  onClick: function(Obj) {
									if(!blogAddOption('newsort', obj.id)){
										ck8.toast('{lang guiigo_manage:tlang0539}','shibai');
										$(obj).val(0)
									}
								  }
								},
							];
							$.modal({
							  title: '{lang guiigo_manage:tlang0540}',
							  text: Docs,
							  buttons: buttonss,
							})
						},
						error: function(){
							ck8.hidePreloader();
							ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
						}
					})
				}
			}

			function blogAddOption(sid, aid) {
				var obj = Dz(aid);
				var newOption = ck8('#'+sid).val().replace(/(^\s*)|(\s*$)/g, '');
				Dz(sid).value = "";
				if (newOption != ''){
					var newOptionTag=document.createElement('option');
					newOptionTag.text=newOption;
					newOptionTag.value="new:" + newOption;
					try {
						obj.add(newOptionTag, obj.options[0]);
					} catch(ex) {
						obj.add(newOptionTag, obj.selecedIndex);
					}
					obj.value="new:" + newOption;
					return true;
				} else {
					return false;
				}
			}

			function addblogfn(msg,par,param){
				if(typeof msg === 'object' || typeof par === 'object'){
					if (param.type == 'addblog' && msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1){
						ck8.toast('{lang guiigo_manage:tlang0541}');
						if(!msg.url)
						  msg.url ='home.php?mod=space&do=blog&view=me';
						  setTimeout(function(){
							  ck8.router.load(msg.url, true);
						  },2000)
					}else {
						ck8.toast(msg.msg,'shibai');
					}
				}else{
					ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
				}
			}
			</script>
			$guiigo_config['footer_html']
		</div>
	</div>
</div>
<!--{/if}-->
<!--{template common/footer}-->