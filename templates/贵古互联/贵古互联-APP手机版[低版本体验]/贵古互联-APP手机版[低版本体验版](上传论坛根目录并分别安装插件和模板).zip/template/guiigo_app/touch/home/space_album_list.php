<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-album-list">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-f" style="font-size: 1rem;"></i></a>
		<h1 class="title zy-h">{lang album}</h1>
	</header>
	<div class="content album-scroll">
		<div class="list-block">
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<!--{if helper_access::check_module('album')}-->
							<li><a href="home.php?mod=spacecp&ac=upload" class="zy-f xh-b" data-no-cache="true"><i class="icon guiigoapp-xiangji4"></i>{lang guiigo_manage:tlang0262}</a></li>
						<!--{/if}-->
						<li><a href="search.php?mod=album" class="zy-f"><i class="icon guiigoapp-xlsousuo"></i>{lang guiigo_manage:tlang0986}</a></li>
					</ul>
				</div>
			</div>
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacealbumlist list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $actives[me]}--> on<!--{/if}-->"><a {if $_G[uid]}href="javascript:;" onclick="app.LoadPageForumView('.album-scroll','home.php?mod=space&do=album&view=me',['gg-kj-amon']);"{else}href="member.php?mod=logging&action=login"{/if}><!--{if $space[self]}-->{lang guiigo_manage:tlang0667}<!--{else}-->TA<!--{/if}-->{lang guiigo_manage:tlang0668}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[we]}--> on<!--{/if}-->"><a {if $_G[uid]}href="javascript:;" onclick="app.LoadPageForumView('.album-scroll','home.php?mod=space&do=album&view=we',['gg-kj-amon']);"{else}href="member.php?mod=logging&action=login"{/if}>{lang guiigo_manage:tlang0669}</a><span class="bg-b"></span></li>
					<li class="swiper-slide<!--{if $actives[all]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.album-scroll','home.php?mod=space&do=album&view=all',['gg-kj-amon']);">{lang view_all}</a><span class="bg-b"></span></li>
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div id="prkonzs2" class="gg-kj-amon">
				<div id="prkonzs2-page" class="gg-kj-amzt ms-a" 
				data-url="$theurl" 
				data-pages="{$count}" 
				data-ppp="{$perpage}" 
				data-page="$page" 
				data-islod="false" 
				data-distance="20">
					<!--{if $count}-->
					<div class="amzt-yssz list-block-no sh-a xh-b bg-c">
						<ul class="list-container">
							<!--{loop $list $key $value}-->
							<!--{eval $pwdkey = 'view_pwd_album_'.$value['albumid'];}-->
							<li>
								<a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]">
									<!--{if $value[pic]}--><img src="$value[pic]" alt="$value[albumname]" /><!--{/if}-->
									<!--{if $value[picnum]}--><span class="amzt-xcsl zy-a"><i class="icon guiigoapp-tupian zy-a"></i>$value[picnum]</span><!--{/if}-->
									<span class="amzt-xcmc"><!--{if $value[albumname]}-->$value[albumname]<!--{else}-->{lang default_album}<!--{/if}--></span>
								</a>
							</li>
							<!--{/loop}-->
							<!--{if $space[self] && $_GET['view']=='me'}-->
							<li>
								<a href="home.php?mod=space&uid=$value[uid]&do=album&id=-1">
									<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-mrxc.png" alt="{lang default_album}" />
									<span class="amzt-xcmc">{lang default_album}</span>
								</a>
							</li>
							<!--{/if}-->
						</ul>
					</div>
					<!--{if $multi}-->
						<div class="infinite-scroll-preloader guiigo-zdjz" style="display:none">
							<div class="preloader preloader-load"></div><span class="loading">{lang guiigo_manage:tlang0144}</span>
						</div>
						<div onclick="infinite('#prkonzs2-page')" class="loadpage bg-c bk-e zy-c">{lang guiigo_manage:tlang0492}</div>
					<!--{/if}-->
					<!--{else}-->
						<!--{if $space[self] && $_GET['view']=='me'}-->
						<div class="amzt-yssz list-block-no sh-a xh-b bg-c">
							<ul>
								<li>
									<a href="home.php?mod=space&uid=$value[uid]&do=album&id=-1">
										<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/guiigo-mrxc.png" alt="{lang default_album}" />
										<span class="amzt-xcmc">{lang default_album}</span>
									</a>
								</li>
							</ul>
						</div>
						<!--{else}-->
							<div class="guiigo-wnrtx guiigo-wnrtxx">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
								<p class="zy-c">{lang guiigo_manage:tlang0670}</p>
							</div>
						<!--{/if}-->
					<!--{/if}-->
				</div>
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript">
	function fuidgoto(fuid) {
		var parameter = fuid != '' ? '&fuid='+fuid : '';
		window.location.href = 'home.php?mod=space&do=album&view=we'+parameter;
	}
	function showMn(){
		var Obj = $('.guiigo-barcd-s')
		if(Obj.css('display') == 'none'){
			Obj._show(200)
		}else{
			Obj.hide()
		}
	}
	function MsgCallGrfoll(msg,par,param) {
		if(typeof msg === 'object' || typeof par === 'object'){
			var Obj = $('.followmod_'+ par.fuid +'');
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1){
				$.toast('{lang guiigo_manage:tlang0003}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&fuid='+ par.fuid).html('<i class="icon guiigoapp-dui"></i></a>')
				Obj.attr('ck-confirm','true')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
				$.toast('{lang guiigo_manage:tlang0009}')
				Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+ par.fuid).html('<i class="icon guiigoapp-bkscj"></i>')
				Obj.attr('ck-confirm','false')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1){
				$.toast('{lang guiigo_manage:tlang0671}')
			}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
				$.toast('{lang guiigo_manage:tlang0007}');
			}else {
				ck8.toast(msg.msg,'shibai');
			}
		}else{
			$.toast('{lang guiigo_manage:tlang0056}');
		}
	}
	</script>
</div>
<!--{template common/footer}-->