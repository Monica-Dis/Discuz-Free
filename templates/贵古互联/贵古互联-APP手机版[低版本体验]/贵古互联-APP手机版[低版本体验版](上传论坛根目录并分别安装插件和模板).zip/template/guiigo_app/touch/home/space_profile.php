<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<!--{if $_GET['mycenter']}-->
	<!--{if $guiigo_config['appsetting']['userconfig']['show_colourmatching']}--><!--{template home/space-style}--><!--{/if}-->
<!--{else}-->
	<!--{if $space[self]}-->
		<!--{template home/space-kjbgq}-->
	<!--{/if}-->
<!--{/if}-->
<div class="page page-current" data-mod="<!--{if !$_GET['mycenter']}-->space-profile<!--{else}-->space-profile-my<!--{/if}-->">
	<!--{if $_GET['mycenter']}-->
	<header class="gg-app-hide bar bar-nav bg-a yb-a">
		<a class="button button-link pull-left open-panel"><i class="icon guiigoapp-clzk zy-a zy-ac yz-a"></i></a>
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-a zy-ac yz-a" style="font-size: 1rem;"></i><!--{if $_G[member][newprompt_num][follower]}--><b class="bg-j"></b><!--{/if}--></a>
		<h1 class="title zy-a zy-ac yz-a">{lang guiigo_manage:tlang0766}</h1>
	</header>
	<!--{template common/footer_nav}-->
	<!--{else}-->
		<!--{if !$space[self]}-->
		<div class="bar bar-rep list-block-no guiigo-tabk bg-c sh-a">
			<ul>
				<!--{eval require_once libfile('function/friend');$isfriend=friend_check($space[uid]);}-->
				<!--{if !$isfriend}-->
				<li class="ul_add">
					<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=addfriendhk_{$space[uid]}" 
					id="a_friend_li_{$space[uid]}" 
					class="dialog" 
					style="color:#f37d7d;"
					ck-cus="true"
					ck-confirm="falsea"
					ck-param="{type:'modal',callpar:{fuid:'$space[uid]'},fn:'MsgCallGrfoll',load:'true',uid:'{$_G[uid]}'}" 
					external ><i class="icon guiigoapp-tabkjhy"></i>{lang guiigo_manage:tlang0618}</a>
				</li>
				<!--{else}-->
				<li class="ul_ignore">
					<a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$space[uid]&handlekey=ignorefriendhk_{$space[uid]}" 
					id="a_ignore_{$space[uid]}" 
					class="dialog" 
					style="color:#f37d7d;"
					ck-cus="true"
					ck-confirm="falsea"
					ck-param="{type:'modal',callpar:{fuid:'$space[uid]'},fn:'MsgCallGrfoll',load:'true',uid:'{$_G[uid]}'}" 
					external ><i class="icon guiigoapp-tabkjhy"></i>{lang ignore_friend}</a>
				</li>
				<!--{/if}-->
				<li><a href="home.php?mod=spacecp&ac=poke&op=send&uid=$space[uid]" style="color:#b8da42;" data-no-cache="true"><i class="icon guiigoapp-tabkdzh"></i>{lang guiigo_manage:tlang0610}</a></li>
				<li>
					<a style="color:#6fcdff;"{if $_G[uid]} href="javascript:;" id="a_sendpm_$key" class="getpm-popup" data-url="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" external{else} href="member.php?mod=logging&action=login"{/if}><i class="icon guiigoapp-tabkfxx"></i>{lang guiigo_manage:tlang0720}</a>
				</li>
			</ul>
		</div>
		<!--{/if}-->
	<!--{/if}-->
	<div class="content{if !$_GET['mycenter']}{if !$space[self]} content-bks{/if}{/if} profile-scroll">
		<!--{if !$_GET['mycenter']}-->
		<header class="gg-app-hide bar bar-nav guiigo-nydb guiigo-kbhddb"
	    ck-cus="true" 
		ck-param="{ftcolo:{sta:'#ffffff',end:'#666666',class:['title','guiigoapp-xzfh','guiigoapp-mkbtgd','guiigoapp-caidan']},rollt:'50',ori:'false',type:1}">
			<a class="button button-link pull-left open-panel guiigo-kjfh zy-a anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan"></i></a>
			<a class="button button-link pull-left back guiigo-kjfh zy-a anvbks"><i class="icon guiigoapp-xzfh"></i></a>
			<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd"></i></a>
			<h1 class="title"><!--{if $space[self]}-->{lang guiigo_manage:tlang0667}<!--{else}-->TA<!--{/if}-->{lang guiigo_manage:tlang0769}</h1>
		</header>
		<!--{/if}-->
		<div class="list-block">
		<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if !$_GET['mycenter']}-->
				<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
					<div class="guiigo-barcd list-block-no bg-c">
						<ul>
							<li><a href="portal.php?mod=index" class="zy-f xh-b"><i class="icon guiigoapp-tbxhfh"></i>{lang guiigo_manage:tlang0767}</a></li>
							<li><a href="javascript:;" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');" class="zy-f xh-b"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
							<!--{if !$space[self]}-->
							<li><a href="home.php?mod=space&uid=$_G[uid]&do=profile" class="zy-f xh-b"><i class="icon guiigoapp-tbxhsc"></i>{lang guiigo_manage:tlang0764}</a></li>
							<!--{else}-->
							<li><a href="javascript:;" onclick="ck8.popup('.popup-kjbgq')" class="zy-f xh-b"><i class="icon guiigoapp-tbxhfg"></i>{lang guiigo_manage:tlang0768}</a></li>
							<!--{/if}-->
							<li><a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="zy-f"><i class="icon guiigoapp-tbgrzx"></i>{lang guiigo_manage:tlang0766}</a></li>
						</ul>
					</div>
				</div>
				<!--{template home/space_pronav}-->
				<div class="content-block gg-kj-taby">
					<div class="tabs">
						<div id="prkonzs" class="tab active">
							<!--{if $_G['setting']['verify']['enabled']}-->
							<div class="gg-kj-rzmk ms-a sh-a xh-b bg-c">
								<span class="rzmk-mkbt zy-c"><i class="icon guiigoapp-kjsyrz"></i>{lang guiigo_manage:tlang0770}</span>
								<div class="rzmk-yhrz">
								<!--{eval $showverify = true;}-->
								<!--{loop $_G['setting']['verify'] $vid $verify}-->
									<!--{if $verify['available']}-->
										<!--{if $space['verify'.$vid] == 1}-->
											<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $verify['icon']}--><img src="$verify['icon']" class="vm"><!--{else}--><span class="bg-e bk-e zy-b">$verify[title]</span><!--{/if}--></a>
										<!--{elseif !empty($verify['unverifyicon'])}-->
											<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $verify['unverifyicon']}--><img src="$verify['unverifyicon']" class="vm"><!--{/if}--></a>
										<!--{/if}-->
									<!--{/if}-->
								<!--{/loop}-->
								</div>
							</div>
							<!--{/if}-->
							<!--{eval $forums = GuiigoApp::getUserGroupByUid($space['uid']);}-->
							<!--{if $forums}-->
							<div class="gg-kj-xzzs ms-a sh-a xh-b bg-c">
								<h2 class="zy-c"><i class="icon guiigoapp-kjsyqz"></i>{lang guiigo_manage:tlang0771}</h2>
								<div class="gg-kj-bqlb">
									<!--{loop $forums $key $val}-->
									<a href="forum.php?mod=forumdisplay&action=list&fid={$val['fid']}" class="sh-a">
										<i class="icon guiigoapp-xzdk zy-g"></i>
										<!--{if {$val['icon']}}-->
										<img src="{$val['icon']}" class="vm">
										<!--{else}-->
										<img src="static/image/common/groupicon.gif" class="vm">
										<!--{/if}-->
										<span class="zy-h">{$val['name']}</span>
									</a>
									<!--{/loop}-->
								</div>
							</div>
							<!--{/if}-->
							<!--{if $count}-->
								<div class="gg-kj-xzzs ms-a sh-a xh-b bg-c">
									<h2 class="zy-c"><i class="icon guiigoapp-kjsygl"></i>{lang guiigo_manage:tlang0772}</h2>
									<div class="gg-kj-bqlb">
										<!--{loop $manage_forum $key $value}-->
										<!--{eval $icon = GuiigoApp::getForumIconByFid($key);}-->
										<a href="forum.php?mod=forumdisplay&fid=$key" class="sh-a">
											<i class="icon guiigoapp-xzdk zy-g"></i>
											<!--{if {$icon}}-->
											<img src="$icon" class="vm">
											<!--{else}-->
											<img src="template/guiigo_app/static/images/forum.png" class="vm">
											<!--{/if}-->
											<span class="zy-h">$value</span>
										</a>
										<!--{/loop}-->
									</div>
								</div>
							<!--{/if}-->
							<!--{if $space['medals']}-->
							<div class="gg-kj-xzzs<!--{if $space['medals']}--> gg-kj-ryxz<!--{/if}--> ms-a sh-a xh-b bg-c">
								<h2 class="zy-c"><i class="icon guiigoapp-kjsyxz"></i>{lang guiigo_manage:tlang0773}</h2>
								<div class="ryxz-xzlb">
									<!--{loop $space['medals'] $medal}-->
										<a href="home.php?mod=medal" class="bg-e bk-e"><img src="{STATICURL}/image/common/$medal[image]"><p class="zy-h"><!--{echo cutstr($medal[name],8)}--></p></a>
									<!--{/loop}-->
								</div>
							</div>
							<!--{/if}-->
							<div class="gg-kj-xzzs ms-a sh-a xh-b bg-c">
								<h2 class="zy-c"><i class="icon guiigoapp-kjsyzl"></i>{lang guiigo_manage:tlang0774}</h2>
								<div class="gg-kj-xxlb list-block-no">
									<ul id="isdisplay" style="overflow: hidden;height: 220.8px;">
										<!--{if $space[adminid]}--><li class="sh-a"><em class="zy-h">{lang management_team}</em><span class="zy-c">{$space[admingroup][grouptitle]}</span></li><!--{/if}-->
										<li class="sh-a"><em class="zy-h">{lang usergroup}</em><span class="zy-c">{$space[group][grouptitle]}</span></li>
										<!--{if $space[extgroupids]}--><li class="sh-a"><em class="zy-h">{lang group_expiry_type_ext}</em><span class="zy-c">$space[extgroupids]</span></li><!--{/if}-->
										<!--{loop $profiles $value}-->
										<li class="sh-a"><span class="zy-c">$value[value]</span><em class="zy-h">$value[title]</em></li>
										<!--{/loop}-->
										<!--{if $space[oltime]}--><li class="sh-a"><span class="zy-c">$space[oltime] {lang hours}</span><em class="zy-h">{lang online_time}</em></li><!--{/if}-->
										<li class="sh-a"><span class="zy-c">$space[regdate]</span><em class="zy-h">{lang regdate}</em></li>
										<li class="sh-a"><span class="zy-c">$space[lastvisit]</span><em class="zy-h">{lang last_visit}</em></li>
										<!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
										<li class="sh-a"><span class="zy-c">$space[regip] - $space[regip_loc]</span><em class="zy-h">{lang register_ip}</em></li>
										<li class="sh-a"><span class="zy-c">$space[lastip]:$space[port] - $space[lastip_loc]</span><em class="zy-h">{lang last_visit_ip}</em></li>
										<!--{/if}-->
										<!--{if $space[lastactivity]}--><li class="sh-a"><span class="zy-c">$space[lastactivity]</span><em class="zy-h">{lang last_activity_time}</em></li><!--{/if}-->
										<!--{if $space[lastpost]}--><li class="sh-a"><span class="zy-c">$space[lastpost]</span><em class="zy-h">{lang last_post_time}</em></li><!--{/if}-->
										<!--{if $space[lastsendmail]}--><li class="sh-a"><span class="zy-c">$space[lastsendmail]</span><em class="zy-h">{lang last_send_email}</em></li><!--{/if}-->
										<li class="sh-a">
											<!--{eval $timeoffset = array({lang timezone});}-->
											<span class="zy-c">$timeoffset[$space[timeoffset]]</span>
											<em class="zy-h">{lang time_offset}</em>
										</li>
									</ul>
									<a class="xxlb-xsgd zy-l sh-a" style="display: block;" onclick="ck8('#isdisplay').css({overflow:'auto',height:'auto'});">{lang guiigo_manage:tlang0775}<i class="icon guiigoapp-xxzk"></i></a>
								</div>
							</div>
						</div>
						<div id="prkonzs1" class="tab"></div>
						<div class="tab" id="prkonzs2"></div>
						<div class="tab" id="prkonzs3"></div>
						<div class="tab" id="prkonzs4"></div>
					</div>
				</div>
			<!--{else}-->
				<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
					<div class="guiigo-barcd list-block-no bg-c">
						<ul>
							<li>
								<!--{if $_G[member][newprompt_num][follower]}-->
								<a href="home.php?mod=space&uid=$_G[uid]&do=profile" class="zy-b xh-b" data-no-cache="true"><i class="icon guiigoapp-tbxhfs zy-b"></i>{lang guiigo_manage:tlang0763}+$_G[member][newprompt_num][follower]</a>
								<!--{else}-->
								<a href="home.php?mod=space&uid=$_G[uid]&do=profile" class="zy-f xh-b" data-no-cache="true"><i class="icon guiigoapp-tbxhsc"></i>{lang guiigo_manage:tlang0764}</a>
								<!--{/if}-->
							</li>
							<li><a href="home.php?mod=spacecp&ac=promotion" class="zy-f xh-b"><i class="icon guiigoapp-xhewm"></i>{lang guiigo_manage:tlang0765}</a></li>
							<li><a href="home.php?mod=spacecp&ac=avatar&do=chszshi&wxlonguid=$_G[uid]" class="zy-f"><i class="icon guiigoapp-kjzlbj"></i>{lang guiigo_manage:tlang0268}</a></li>
						</ul>
					</div>
				</div>
				<div class="gg-kj-grxx{if $guiigo_config['appsetting']['userconfig']['show_buygroup']} gg-kj-grxg{/if}">
					<div class="grxx-dwys">
						<div class="grxx-yhtx">
							<a href="home.php?mod=spacecp&ac=avatar&do=chszshi"><img src="<!--{avatar($_G[uid], middle, true)}-->" class="vm"/></a>
						</div>
						<div class="grxx-mcqm">
							<h2><em class="zy-a zy-ac">$_G[username]</em></h2>
							<div class="grxx-djrz">
								<a href="home.php?mod=spacecp&ac=usergroup" class="zy-a zy-ac">Lv.<!--{eval echo GuiigoApp::getUserStars($_G[uid]);}--></a>		
								<!--{eval $verifys = GuiigoApp::getUserList($_G[uid],'verify');}-->
								<!--{eval $isverify = false;}-->
								<!--{if $_G['setting']['verify']['enabled']}-->
									<!--{loop $_G['setting']['verify'] $vid $verify}-->
										<!--{if $verify['available'] && $verifys['verify'.$vid] == 1}-->
											<!--{eval $isverify = true;}-->
											<!--{eval break;}-->
										<!--{/if}-->
									<!--{/loop}-->
								<!--{/if}-->
								<!--{if $isverify}-->
									<a href="home.php?mod=spacecp&ac=profile&op=verify" class="zy-a zy-ac">{lang guiigo_manage:tlang0776}<i class="icon guiigoapp-xzdk"></i></a>
								<!--{else}-->
									<a href="home.php?mod=spacecp&ac=profile&op=verify" class="zy-a zy-ac">{lang guiigo_manage:tlang0777}<i class="icon guiigoapp-xzdk"></i></a>
								<!--{/if}-->
							</div>
						</div>
					</div>
					<a href="$guiigo_config['appsetting']['userconfig']['show_sign_url']" class="grxx-qdxc ab-d zy-a"><i class="icon guiigoapp-liwu"></i>{lang guiigo_manage:tlang0778}<i class="icon guiigoapp-xzdk"></i></a>
					<!--{if $guiigo_config['appsetting']['userconfig']['show_buygroup']}-->
					<div class="grxx-vipg"><i class="icon guiigoapp-tuijian"></i>{lang guiigo_manage:tlang0779}</div>
					<a href="home.php?mod=spacecp&ac=usergroup&do=list" class="grxx-vgan">{lang guiigo_manage:tlang0121}</a>
					<!--{/if}-->
					<div class="grxx-dbys">
						<div class="grxx-dbys-x"></div>
					</div>
					<div class="guiigo-fgzs"></div>
				</div>
				<div class="gg-kj-zycz list-block-no bg-c xh-b">
					<ul>
						<li>
							<a href="home.php?mod=space&do=favorite" class="xh-b yh-a">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/grzx-sc.png" class="vm">
								<h2 class="zy-h">{lang guiigo_manage:tlang0780}</h2>
								<p class="zy-g">{lang guiigo_manage:tlang0781}</p>
							</a>
						</li>
						<li>
							<a href="home.php?mod=space&do=thread" class="xh-b">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/grzx-zt.png" class="vm">
								<h2 class="zy-h">{lang guiigo_manage:tlang0782}</h2>
								<p class="zy-g">{lang guiigo_manage:tlang0783}</p>
							</a>
						</li>
						<li>
							<a href="home.php?mod=spacecp&ac=credit" class="yh-a">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/grzx-jf.png" class="vm">
								<h2 class="zy-h">{lang guiigo_manage:tlang0784}</h2>
								<p class="zy-g">{lang guiigo_manage:tlang0785}</p>
							</a>
						</li>
						<li>
							<a href="home.php?mod=space&do=friend">
								<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/grzx-hy.png" class="vm">
								<h2 class="zy-h">{lang guiigo_manage:tlang0709}</h2>
								<p class="zy-g">{lang guiigo_manage:tlang0786}</p>
							</a>
						</li>
					</ul>
				</div>
				<!--{if $guiigo_config['appsetting']['userconfig']['show_ad_slide']}-->
				<div class="gg-kj-xchd ms-a bg-c">
					<div class="swiper-container guiigo-hdmka xchd-hdkz">
						<div class="swiper-wrapper go-hdmka-ys">
							<!--{if $guiigo_config['appsetting']['userconfig']['show_photo_tip']}-->
								<!--{if !$_G[member][avatarstatus]}-->
									<div class="swiper-slide"><a href="home.php?mod=spacecp&ac=avatar&do=chszshi"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/c0.png"/></a></div>
								<!--{/if}-->
							<!--{/if}-->
							<!--{loop $guiigo_config['appsetting']['userconfig']['show_ad_slide'] $val}-->
								<div class="swiper-slide"><a href="$val['type2']"><img src="$val['type1']" alt="$val['extend1']"/></a></div>
							<!--{/loop}-->
						</div>
						<div class="swiper-pagination swiper-pagination-white swiper-r-box go-hdmka-xzfy"></div>
					</div>
				</div>
				<!--{/if}-->
				<!--{eval $list = GuiigoApp::GetVisitorByUid($_G['uid'],0,$guiigo_config['appsetting']['userconfig']['show_visitorhead']);}-->
				<div class="gg-kj-ejcz ms-a bg-c">
					<div class="guiigo-tbdh">
						<!--{if $guiigo_config['appsetting']['userconfig']['show_colourmatching']}-->
							<a href="javascript:;" class="xh-a" onclick="ck8.popup('.popup-style')"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/cgd-fg.png" class="go-tbdh-ico"><span class="zy-i">$guiigo_config['appsetting']['userconfig']['show_colourmatchingpg']</span><div class="go-tbdh-mc zy-f">{lang guiigo_manage:tlang0787}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
						<!--{/if}-->
						<!--{if $guiigo_config['appsetting']['userconfig']['show_visitor']}-->
						<a href="home.php?mod=space&do=friend&view=visitor" class="xh-a">
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/cgd-fk.png" class="go-tbdh-ico">
							<div class="go-grzx-fk list-block-no">
								<ul>
								<!--{loop $list $key $val}-->
									<li><img src="<!--{avatar($val[uid],middle,true)}-->"></li>
                                <!--{/loop}-->
								</ul>
							</div>
							<div class="go-tbdh-mc zy-f">{lang guiigo_manage:tlang0788}</div>
							<i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i>
						</a>
						<!--{/if}-->
						<!--{if $guiigo_config['appsetting']['userconfig']['show_invitation']}-->
						<a href="home.php?mod=spacecp&ac=invite"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/cgd-hb.png" class="go-tbdh-ico"><span class="zy-b">$guiigo_config['appsetting']['userconfig']['show_invitationpg']</span><div class="go-tbdh-mc zy-f">{lang guiigo_manage:tlang0413}</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
						<!--{/if}-->
					</div>
				</div>
				<div class="gg-kj-ejcz ms-a mx-a bg-c">
					<div class="guiigo-tbdh">
						<!--{loop $guiigo_config['appsetting']['menuconfig']['global_personage_menu'] $val}-->
							<!--{if $val['global_personage_menu_open'] == 1}-->
								<a href="$val['global_personage_menu_link']" class="xh-a"><img src="$val['global_personage_menu_icon']" class="go-tbdh-ico"><div class="go-tbdh-mc zy-f">$val['global_personage_menu_name']</div><i class="icon guiigoapp-xzdk go-tbdh-xz zy-d"></i></a>
							<!--{/if}-->
						<!--{/loop}-->
					</div>
				</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	function showMn(){
		var Obj = $('.guiigo-barcd-s')
		if(Obj.css('display') == 'none'){
			Obj._show(200)
		}else{
			Obj.hide()
		}
	}
	</script>
</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->