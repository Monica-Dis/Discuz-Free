<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
{eval
	$_G['home_tpl_titles'] = array($blog['subject'], '{lang blog}');
	$_G['home_tpl_spacemenus'][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=$do&view=me\">{lang they_blog}</a>";
	$_G['home_tpl_spacemenus'][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=blog&id=$blog[blogid]\">{lang view_blog}</a>";
	$friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');
}
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="space-blog-view">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<a class="button button-link pull-left open-panel anvbk" style="margin-left: 0;display:none;"><i class="icon guiigoapp-caidan zy-f"></i></a>
		<a class="button button-link pull-left back anvbks"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<a href="javascript:;" class="button button-link pull-right" onclick="showMn();" ><i class="icon guiigoapp-mkbtgd zy-f" style="font-size: 1rem;"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0534}</h1>
	</header>
	<div class="content content-bts">
		<div class="list-block">
			<div class="guiigo-barcd-s" style="display:none;" onclick="showMn();">
				<div class="guiigo-barcd list-block-no bg-c">
					<ul>
						<!--{if $_G[uid] == $blog[uid] || checkperm('manageblog')}-->
							<li><a href="javascript:;" class="zy-f xh-b" onclick="app.ActionsManage('#guiigo-lcgl-lzgl','t', 'auto');"><i class="icon guiigoapp-kjzlbj"></i>{lang guiigo_manage:tlang0987}</a></li>
						<!--{/if}-->
						<!--{if helper_access::check_module('blog')}--><li><a href="home.php?mod=spacecp&ac=blog" class="zy-f xh-b"><i class="icon guiigoapp-fbxhfb"></i>{lang guiigo_manage:tlang0531}</a></li><!--{/if}-->
						<li><a href="misc.php?mod=invite&action=blog&id=$blog[blogid]" 
								class="zy-f xh-b dialog"
								ck-cus="true"
								ck-param="{type:'modal',callpar:{'pid':'$post[pid]',type:'invite'},fn:'MsgCallInvite',load:'true',uid:'$_G[uid]'}"
								external ><i class="icon guiigoapp-yaoqing"></i>{lang guiigo_manage:tlang0413}</a></li>
						<li><a href="javascript:;" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');" class="zy-f xh-b"><i class="icon guiigoapp-tbxhfx"></i>{lang guiigo_manage:tlang0354}</a></li>
						<li><a href="home.php?mod=spacecp&ac=favorite&type=blog&id=$blog[blogid]&spaceuid=$blog[uid]&handlekey=favoritebloghk_{$blog[blogid]}" id="a_favorite" class="zy-f {if $_G[uid] != $blog['uid']} xh-b{/if} dialog"
						ck-cus="true"
						ck-param="{type:'modal',callpar:{},fn:'MsgCallAlbsc',load:'true',uid: '$_G[uid]'}" 
						external ><i class="icon guiigoapp-tbxhsc"></i>{lang guiigo_manage:tlang0683}</a></li>
						<!--{if $_G[uid] != $blog['uid']}-->
						<li><a href="misc.php?mod=report&rtype=blog&uid=$blog[uid]&rid=$blog[blogid]" 
							class="blue-inner dialog zy-f"
							ck-cus="true" 
							ck-param="{type:'modal',load:'true',uid:'$_G[uid]',fn:'MsgCallReport'}"
							external ><i class="icon guiigoapp-tbxhjb"></i>{lang guiigo_manage:tlang0684}</a></li>
						<!--{/if}-->
					</ul>
				</div>
			</div>
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<div class="popup-actions" id="guiigo-nrdbfx">
				<div class="actions-text guiigo-hdfx">
					<div class="gg-app-hide hdfx-hdxm xh-b bg-e">
						<a href="javascript:;"  data-app="weixin" class="nativeShare weixin zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wx.png" class="vm"></span>{lang guiigo_manage:tlang0153}</a>
						<a href="javascript:;" data-app="weixinFriend" class="nativeShare weixin_timeline zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/pyq.png" class="vm"></span>{lang guiigo_manage:tlang0154}</a>
						<a href="javascript:;" data-app="QQ" class="nativeShare qq zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/qq.png" class="vm"></span>{lang guiigo_manage:tlang0155}</a>
						<a href="javascript:;" data-app="QZone" class="nativeShare qzone zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/kj.png" class="vm"></span>{lang guiigo_manage:tlang0156}</a>
						<a href="javascript:;" data-app="sinaWeibo" class="nativeShare weibo zy-f zd-12"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wb.png" class="vm"></span>{lang guiigo_manage:tlang0157}</a>
					</div>
					<div class="hdfx-hdxm bg-e">
						<a href="javascript:;" class="zy-f zd-12" onclick="copy(this);" id="cptextid"><span class="bg-c"><img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/fz.png" class="vm"></span>{lang guiigo_manage:tlang0158}</a>
					</div>
					<div class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</div>
				</div>
			</div>
			<div class="share-layer"></div>
			<!--{if $_G[uid] == $blog[uid] || checkperm('manageblog')}-->
			<div class="popup-actions" id="guiigo-lcgl-lzgl">
				<div class="actions-text guiigo-hdfx">
					<div class="hdfx-glxm hdfx-glxmh list-block-no bg-e">
						<ul>
						<!--{eval $stickflag = GuiigoApp::getStickBlogs($blog[uid],$blog[blogid]);}-->
						<!--{eval $stickflagid = $stickflag ? 0 : 1;}-->
							<li class="bg-c">
								<a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=stick&stickflag=$stickflagid&handlekey=stickbloghk" 
								id="blog_stick_$blog[blogid]" 
								class=" dialog zy-h sh-a"
								ck-cus="true"
								ck-param="{type:'modal',callpar:{bid:'$blog[blogid]',type:'stick'},fn:'MsgCallblogv',load:'true',uid:'$_G[uid]'}"
								external ><!--{if $stickflag}-->{lang cancel_stick}<!--{else}-->{lang stick}<!--{/if}--></a>
							</li>
							<li class="bg-c"><a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=edit" class="zy-h sh-a">{lang guiigo_manage:tlang0227}</a></li>
							<li class="bg-c xh-b">
								<a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=delete&handlekey=delbloghk_{$blog[blogid]}" 
								id="blog_delete_$blog[blogid]" 
								class="zy-h sh-a dialog"
								ck-cus="true"
								ck-param="{type:'modal',callpar:{bid:'$blog[blogid]',type:'delete'},fn:'MsgCallblogv',load:'true',uid:'$_G[uid]'}"
								external >{lang guiigo_manage:tlang0685}</a>
							</li>
						</ul>
					</div>
					<div class="hdfx-hdgb sh-a bg-c zy-i">{lang guiigo_manage:tlang0105}</div>
				</div>
			</div>
			<!--{/if}-->
			<!--{eval $member = getuserbyuid($blog['uid']);}-->
			<!--{eval $verifys = GuiigoApp::getUserList($blog['uid'],'verify');}-->
			<!--{eval $gender = GuiigoApp::getUserList($blog['uid'],'profile');}-->
			<!--{eval $follow = GuiigoApp::getUserList($_G['uid'],'follow');}-->
			<div class="gg-sq-ztbt bg-c">
				<!--{if $blog[status] == 1}--><span class="zy-i">{lang pending}</span><!--{/if}--><em id="share_title" class="zy-e">$blog[subject]</em>
			</div>
			<div class="gg-sq-lzxx bg-c">
				<div class="lzxx-lztx guiigo-ty"><a href="home.php?mod=space&uid=$blog[uid]&do=profile"><!--{avatar($blog[uid],middle)}--></a></div>
				<div class="lzxx-lzwx">
					<h1>
						<!--{if !in_array($blog['uid'], $follow)}-->
							<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$blog[uid]" 
							class="followmod_$blog[uid] dialog mcxx-gzan zy-b bk-b"
							ck-cus="true"
							ck-confirm="false"
							ck-param="{type:'modal',callpar:{tid:'$blog[uid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}'}"
							external ><i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}</a>
						<!--{else}-->
							<a href="home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=$blog['uid']" 
							class="followmod_$blog[uid] dialog mcxx-gzan zy-c bk-c bg-e" 
							ck-cus="true" 
							ck-confirm="true" 
							ck-param="{type:'modal',callpar:{tid:'$blog[uid]'},fn:'MsgCallFn',load:'true',uid:'{$_G[uid]}',msg:'{lang guiigo_manage:tlang0004}',}" 
							external >{lang guiigo_manage:tlang0003}</a>
						<!--{/if}-->
						<a href="home.php?mod=space&uid=$blog[uid]&do=profile" class="mcxx-yhmc zy-f">$blog[username]</a>
						<!--{eval $grouptitle = strip_tags($_G['cache']['usergroups'][$member['groupid']]['grouptitle']);}-->
						<span class="mcxx-yhdj zy-a" style="background: {$_G['cache']['usergroups'][$member['groupid']]['color']};">Lv.{$_G['cache']['usergroups'][$member['groupid']]['stars']} {$grouptitle}</span>
						<!--{if $gender['gender'] == 1  || $gender['gender'] == 0}-->
							<i class="icon guiigoapp-nan bg-n"></i>
						<!--{elseif $gender['gender'] == 2}-->
							<i class="icon guiigoapp-nv bg-o"></i>
						<!--{/if}-->
						<!--{if $_G['setting']['verify']['enabled']}-->
							<span class="verify-icon y">
							<!--{loop $_G['setting']['verify'] $vid $verify}-->
								<!--{if $verify['available'] && $verifys['verify'.$vid] == 1 && $verify['icon']}-->
								<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" class="ck8-avatar-icon">
								   <img src="$verify['icon']" class="vm" alt="$verify[title]" />
								</a>
								<!--{/if}-->
							<!--{/loop}-->
							</span>
						<!--{/if}-->
					</h1>
					<div class="mcxx-fbxx"><i class="zy-g"><!--{date($blog[dateline])}--> </i><!--{if $blog[viewnum]}--><i class="zy-g"> {lang have_read_blog}</i><!--{/if}--></div>
				</div>
			</div>
			<div id="share_img" class="gg-sq-qbnr gg-sq-lznr bg-c xh-b">
				<div id="blog_article" class="gg-sq-nrzt gg-kj-rztp zy-e">
					$blog[message]
				</div>
				<div class="gg-sq-tags ms-a">
					<!--{if $blog[tag]}-->
					<!--{eval $tagi = 0;}-->
					<!--{loop $blog[tag] $var}-->
						<a href="misc.php?mod=tag&id=$var[0]&type=blog" class="bg-l zy-h">$var[1]</a>
						<!--{eval $tagi++;}-->
					<!--{/loop}-->
					<!--{/if}-->
					<!--{if $classarr[classname]}-->
						<a href="home.php?mod=space&uid=$blog[uid]&do=blog&classid=$blog[classid]&view=me" class="bg-l zy-h">{$classarr[classname]}</a>
					<!--{/if}-->
					<!--{if $blog[catname]}-->
						<a href="home.php?mod=space&do=blog&view=all&catid=$blog[catid]" class="bg-l zy-h">$blog[catname]</a>
					<!--{/if}-->
				</div>
			</div>
			<!--{if $otherlist}-->
			<div class="guiigo-tmkbt bg-c sh-a" style="margin-top:.55rem;">
				<i class="icon guiigoapp-mkbtgd zy-g"></i>
				<a href="home.php?mod=space&uid=$blog[uid]&do=blog&view=me" class="tmkbt-ycgdl">{lang all}</a>
				<h2 class="zy-e"><span class="gg-kj-xtnr bg-j"><i class="icon guiigoapp-xihuan zy-a"></i></span>{lang guiigo_manage:tlang0686}</h2>
			</div>
			<div class="gg-kj-qtrz list-block-no bg-c xh-b">
				<ul>
					<!--{loop $otherlist $value}-->
						<li class="sh-a"><i class="icon guiigoapp-xzdk zy-g"></i><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="zy-h">$value[subject]</a></li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
			<div id="div_main_content">
				<div id="comment"></div>
				<div class="guiigo-tmkbt bg-c sh-a xh-b" style="margin-top:.55rem;">
					<h2 class="zy-e"><span class="gg-kj-xtnr bg-d"><i class="icon guiigoapp-nydbpl zy-a"></i></span><!--{if $blog[replynum] > 0}--><span id="comment_replynum">$blog[replynum]</span>{lang guiigo_manage:tlang0687}<!--{else}-->{lang comment}<!--{/if}--></h2>
				</div>
				
				<!--{if $cid}-->
				<div class="i">
					{lang current_blog_replay}<a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]">{lang click_view_all}</a>
				</div>
				<!--{/if}-->
				
				<!--{if $blog[replynum] > 0}-->
				<div id="comment_ul" class="gg-kj-sssj bg-c">
					<ul>
						<!--{loop $list $k $value}-->
							<!--{template home/space_comment_li}-->
						<!--{/loop}-->
					</ul>
				</div>
				<!--{else}-->
				<div class="guiigo-wnrtx bg-c">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang guiigo_manage:tlang0688}</p>
				</div>
				<!--{/if}-->
				<!--{if $multi}--><div class="pgs cl mbm">$multi</div><!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<!--{if $_G['relatedlinks']}-->
		<script type="text/javascript">
			var relatedlink = [];
			<!--{loop $_G['relatedlinks'] $key $link}-->
			relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
			<!--{/loop}-->
			relatedlinks('blog_article');
		</script>
	<!--{/if}-->
	<!--{if !$blog[noreply] && helper_access::check_module('blog')}-->
	<div class="bar bar-rep list-block-no guiigo-tabs bg-c sh-a">
		<ul>
			<li><a href="JavaScript:void(0)" onclick="app.ActionsManage('#guiigo-nrdbfx','t', 'auto');"><i class="icon guiigoapp-nydbfx zy-e"></i></a></li>
			<li><a href="home.php?mod=spacecp&ac=favorite&type=blog&id=$blog[blogid]&spaceuid=$blog[uid]&handlekey=favoritebloghk_{$blog[blogid]}" class="dialog"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{},fn:'MsgCall',load:'true',uid: '$_G[uid]'}" 
					external><i class="icon guiigoapp-nydbsc zy-e"></i></a></li>
			<li><a href="javascript:;" onclick="scrollRely(this);" data-type="1"><i class="icon guiigoapp-nydbpl zy-e"></i></a></li>
			<li class="tabs-hfys tabs-hfysp"><a href="javascript:;" class="bg-g zy-c" onclick="app.ActionsManage('#guiigo-hfdp','t','auto','closehfdp');$('#fastpostmessage').focus();"><i class="icon guiigoapp-xiepinglun"></i>{lang guiigo_manage:tlang0147}</a></li>
		</ul>
	</div>
	<div class="popup-actions" id="guiigo-hfdp">
		<div class="actions-text guiigo-hfdp bg-c">
			<form 
			id="quickcommentform_{$id}" 
			action="home.php?mod=spacecp&ac=comment" 
			method="post" 
			autocomplete="off"
			ck-cus="true" 
			ck-param="{type:'modal',load:'true',callpar:{type:'reply'},fn:'MsgCallblogv',uid:'$_G[uid]'}">
				<div class="hfdp-btys xh-b bg-g">
					<a href="javascript:;" class="btys-gbck closehfdp"><i class="icon guiigoapp-guanbi zy-c"></i></a>
					<h2 class="zy-h">{lang guiigo_manage:tlang0689}</h2>
				</div>
				<div class="hfdp-srys xh-b bg-c">
					<!--{if $_G['uid'] || $_G['group']['allowcomment']}-->
						<textarea id="fastpostmessage" name="message" class="guiigo-pt zy-f" placeholder="{lang guiigo_manage:tlang0229}"></textarea>
					<!--{else}-->
						<div class="srys-qtts"><i class="icon guiigoapp-tbxhjb"></i>{lang login_to_comment} <a href="member.php?mod=logging&action=login">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}">$_G['setting']['reglinkname']</a></div>
					<!--{/if}-->
				</div>
				<!--{if $secqaacheck || $seccodecheck}--><!--{subtemplate common/seccheck}--><!--{/if}-->
				<div class="hfdp-crqd xh-b bg-g">
					<div class="crqd-gdqd">
						<input type="hidden" name="referer" value="home.php?mod=space&uid=$blog[uid]&do=$do&id=$id" />
						<input type="hidden" name="id" value="$id" />
						<input type="hidden" name="idtype" value="blogid" />
						<input type="hidden" name="handlekey" value="qcblog_{$id}" />
						<input type="hidden" name="commentsubmit" value="true" />
						<input type="hidden" name="quickcomment" value="true" />
						<button type="submit" name="commentsubmit_btn" value="true" id="commentsubmit_btn" class="formdialog guiigo-pn ab-az zy-a zy-ac">{lang comment}</button>
					</div>
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<div class="crqd-btat">
						<ul>
							<li><a href="JavaScript:void(0)" class="zy-c" onclick="showFace('appendface', 'fastpostmessage',this)"><i class="icon guiigoapp-biaoqing"></i><p>{lang guiigo_manage:tlang0150}</p></a></li>
						</ul>
					</div>
				</div>
				<div class="bg-c cl">
					<div class="kznr-bqnr cl" style="display:none;" id="appendface"></div>
				</div>
			</form>
		</div>
	</div>
	<!--{/if}-->
<script>
ck8(function(){
	if(ck8('#focbtn').length > 0){
		ck8('#focbtn').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('#rewardbut').length > 0){
		ck8('#rewardbut').click(function(e){
			Dz('needmessage').focus()
		})
	}
	if(ck8('.debatereply').length > 0){
		ck8('.debatereply').click(function(e){
			Dz('needmessage').focus()
		})
	}
})

function ShareAllblog(){
	//得到分享数据
		var config = getShareData('#share_title','#share_img');
	<!--{if ($guiigo_config['browser']['isqq'] || $guiigo_config['browser']['isuc']) && !$guiigo_config['browser']['iswx']}-->
		//如果是 UC qq 浏览器
		nativeShare(config);
	<!--{elseif $guiigo_config['browser']['iswx']}-->
		//如果是微信浏览器
		wxshareJssdkAjax(config)
	<!--{else}-->
		//如果不是 微信浏览器 UC qq 浏览器
		webShare(config)
	<!--{/if}-->
}

function MsgCallAlbsc(msg,par){
	if(typeof msg == 'object' || typeof par == 'object'){
		if(msg.msg.indexOf('{lang guiigo_manage:tlang0014}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0177}','chenggong')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0015}') != -1){
			ck8.toast('{lang guiigo_manage:tlang0678}','shibai')
		}else{
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallFn(msg,par,param) {
	if(typeof msg === 'object' || typeof par === 'object'){
		var Obj = $('.followmod_'+ param.tid);
		var foObj = $('#recommend_add_'+ param.tid);
		var recommendcut = parseInt($('#recommend_add_sum'+ param.tid).html()) || 0;
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0005}') != -1 || msg.msg.indexOf('{lang guiigo_manage:tlang0006}') != -1){
			$.toast('{lang guiigo_manage:tlang0003}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=del&hash={FORMHASH}&fuid=' + param.tid).html('{lang guiigo_manage:tlang0003}').addClass('zy-c bk-c bg-e').removeClass('zy-b bk-b').html('{lang guiigo_manage:tlang0003}')
			 Obj.attr('ck-confirm','true')
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0008}') != -1){
			$.toast('{lang guiigo_manage:tlang0009}')
			Obj.attr('href','home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=' + param.tid).html('{lang guiigo_manage:tlang0002}').addClass('zy-b bk-b').removeClass('zy-c bk-c bg-e').html('<i class="icon guiigoapp-guanzhu"></i>{lang guiigo_manage:tlang0002}')
			Obj.attr('ck-confirm','false')
		}else {
			$.toast(msg.msg);
		}
	}else{
		$.toast('{lang guiigo_manage:tlang0056}');
	}
}

function showMn(){
	var Obj = $('.guiigo-barcd-s')
	if(Obj.css('display') == 'none'){
		Obj._show(200)
	}else{
		Obj.hide()
	}
}

function MsgCallblogv(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0169}') != -1 && param.type == 'reply'){
			app.close_popup()
			ck8('#message').val('');
			if(typeof seccode == 'function'){
				seccode(ck8('.seccodeimg'))
			}
			app.PageRefresh(false,'#div_main_content')
			ck8.toast('{lang guiigo_manage:tlang0690}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0169}') != -1 && param.type == 'delete'){
			ck8.toast('{lang guiigo_manage:tlang0691}');
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'stick'){
			ck8.toast('{lang guiigo_manage:tlang0692}');	
		}else if(msg.msg.indexOf('{lang guiigo_manage:tlang0693}') != -1 && param.type == 'stick'){
			ck8.toast('{lang guiigo_manage:tlang0694}');	
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallwzplx(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'bianji'){
			ck8.toast('{lang guiigo_manage:tlang0695}');
			app.PageRefresh(false,'#comment_'+ param.liid +'_li')
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'shanchu'){
			ck8.toast('{lang guiigo_manage:tlang0561}');
			app.PageRefresh(false,'#div_main_content')
		}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'huifu'){
			ck8.toast('{lang guiigo_manage:tlang0214}');
			app.PageRefresh(false,'#div_main_content')
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}

function MsgCallInvite(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('{lang guiigo_manage:tlang0168}') != -1){
			ck8.closeModal('.popup-about-js')
			ck8.toast(msg.msg);
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
	}
}
</script>
</div>
<!--{template common/footer}-->