<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp_promotion">
	<header class="bar bar-nav guiigo-nydb guiigo-dydb bg-c">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-guanbi zy-f"></i></a>
	</header>
	<div class="content bg-c gg-yjms">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}-->
			<div class="gg-kj-tgfw">
				<div class="tgfw-yhxx">
					<!--{avatar($_G[uid])}-->
					<h2 class="zy-e">$_G['username']</h2>
					<p class="zy-f">{lang guiigo_manage:tlang0632} $guiigo_config['site_name'] {lang guiigo_manage:tlang0633}</p>
				</div>
				<div class="tgfw-bewm" id="qrcode" url="$_G[siteurl]?fromuid=$_G[uid]"></div>
				<div class="tgfw-xzts">
					<!--{if $_G['setting']['creditspolicy']['promotion_visit']}--><p class="zy-c">{lang guiigo_manage:tlang0634} <i class="zy-b">$visitstr</i></p><!--{/if}-->
					<!--{if $_G['setting']['creditspolicy']['promotion_register']}-->
					<p class="zy-c">
					<!--{if $_G['setting']['creditspolicy']['promotion_visit']}-->
						{lang guiigo_manage:tlang0635} <i class="zy-b">$regstr</i>
					<!--{else}-->
						{lang guiigo_manage:tlang0636} <i class="zy-b">$regstr</i>
					<!--{/if}-->
					</p>
					<!--{/if}-->
				</div>
			</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	ck8(function(){
		app.loadScript('qrcode.min',function(){
			ck8('#qrcode').html('')
			var url = ck8('#qrcode').attr('url')
			ck8('#qrcode').qrcode({
				width: 150,
				height: 150,
				render: "canvas",
				foreground: "#000",
				background: "#FFF",
				text: url
			});
			
		})
	})

	</script>
</div>
<!--{template common/footer}-->