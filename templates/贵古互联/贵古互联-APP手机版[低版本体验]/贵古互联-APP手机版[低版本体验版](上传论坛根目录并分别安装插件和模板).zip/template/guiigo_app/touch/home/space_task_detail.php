<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="gg-kj-rwxq">
	<!--{if $task['endtime']}--><div class="gg-qz-flts rwxq-txys bg-c ms-a"><div class="flts-tsnr bk-d bg-p zy-b">{lang task_endtime}{lang guiigo_manage:tlang0804}</div></div><!--{/if}-->
	<div class="rwxq-tbjs ms-a bg-c xh-b<!--{if !$task['endtime']}--> sh-a<!--{/if}-->">
		<div class="tbjs-rwtb"><img src="$task[icon]"/></div>
		<div class="tbjs-rwbj">
			<h1 class="zy-e">$task[name]</h1>
			<p class="zy-c">
			<!--{if $task[period]}-->
				<!--{if $task[periodtype] == 0}-->
					{lang task_period_hour}, 
				<!--{elseif $task[periodtype] == 1}-->
					{lang task_period_day}, 
				<!--{elseif $task[periodtype] == 2}-->
					<!--{eval $periodweek = $_G['lang']['core']['weeks'][$task[period]];}-->
					{lang task_period_week}, 
				<!--{elseif $task[periodtype] == 3}-->
					{lang task_period_month}, 
				<!--{/if}-->
			<!--{/if}-->
				$task[description]
			</p>
		</div>
	</div>
	<div class="rwxq-lmbt bg-g xh-b zy-c cl">{lang guiigo_manage:tlang0805}</div>
	<div class="rwxq-lmnr bg-c xh-b zy-h cl">
		<!--{if $task['reward'] == 'credit'}-->
			{lang credits} $_G['setting']['extcredits'][$task[prize]][title] $task[bonus] $_G['setting']['extcredits'][$task[prize]][unit]
		<!--{elseif $task['reward'] == 'magic'}-->
			{lang magics_title} $task[rewardtext] $task[bonus] {lang magics_unit}
		<!--{elseif $task['reward'] == 'medal'}-->
			{lang medals} $task[rewardtext] <!--{if $task['bonus']}-->{lang expire} $task[bonus] {lang days} <!--{/if}-->
		<!--{elseif $task['reward'] == 'invite'}-->
			{lang invite_code} $task[prize] {lang expire} $task[bonus] {lang days}
		<!--{elseif $task['reward'] == 'group'}-->
			{lang usergroup} $task[rewardtext] <!--{if $task['bonus']}--> $task[bonus] {lang days} <!--{/if}-->
		<!--{else}-->
			{lang nothing}
		<!--{/if}-->
	</div>		
	<!--{if $task['viewmessage']}-->
	<div class="rwxq-lmbt bg-g xh-b zy-c cl">{lang guiigo_manage:tlang0806}</div>
	<div class="rwxq-lmnr bg-c xh-b zy-h cl">$task[viewmessage]</div>
	<!--{else}-->
	<div class="rwxq-lmbt bg-g xh-b zy-c cl">{lang task_complete_condition}</div>
	<div class="rwxq-lmnr list-block-no bg-c xh-b zy-h cl">
		<!--{if $taskvars['complete']}-->
			<ul>
				<!--{loop $taskvars['complete'] $taskvar}-->
					<li>$taskvar[name] : $taskvar[value]</li>
				<!--{/loop}-->
			</ul>
		<!--{else}-->
			{lang unlimited}
		<!--{/if}-->
	</div>
	<!--{/if}-->
	<div class="rwxq-lmbt bg-g xh-b zy-c cl">{lang task_apply_condition}</div>
	<div class="rwxq-lmnr list-block-no bg-c xh-b zy-h cl">
		<!--{if $task[applyperm] || $task[relatedtaskid] || $task[tasklimits] || $taskvars['apply']}-->
			<ul>
				<li><!--{if $task[grouprequired]}-->{lang usergroup}: $task[grouprequired] <!--{elseif $task['applyperm'] == 'member'}-->{lang task_general_users}<!--{elseif $task['applyperm'] == 'admin'}-->{lang task_admins}<!--{/if}--></li>
				<!--{if $task[relatedtaskid]}--><li>{lang task_relatedtask}: <a href="home.php?mod=task&do=view&id=$task[relatedtaskid]">$_G['taskrequired']</a></li><!--{/if}-->
				<!--{if $task[tasklimits]}--><li>{lang task_numlimit}: $task[tasklimits]</li><!--{/if}-->
				<!--{if $taskvars['apply']}-->
					<!--{loop $taskvars['apply'] $taskvar}-->
						<li>$taskvar[name]: $taskvar[value]</li>
					<!--{/loop}-->
				<!--{/if}-->
			</ul>
		<!--{else}-->
			{lang unlimited}
		<!--{/if}-->
	</div>
	<div class="rwxq-jdan ms-a">
		<!--{if $allowapply == '-1'}-->
			<div class="jdan-rwjd bg-i">
				<span class="rwjd-jdyt bg-b" style="width: {if $task[csc]}$task[csc]%{/if};"></span>
				<p class="rwjd-jdsj zy-a">{lang task_complete} <span id="csc_$task[taskid]">$task[csc]</span>%</p>
			</div>
			<div class="{if $task[csc] >=100}jdan-wsan{else}jdan-wsans{/if}">
				<a class="guiigo-pn zy-a{if $task[csc] >=100} ab-az zy-ac{else} ab-b{/if}" href="javascript:;"{if $task[csc] >=100} data-href="home.php?mod=task&do=draw&id=$task[taskid]" onclick="coutomAjaxGet(this)" external{else} onclick="ck8.toast('{lang guiigo_manage:tlang0036}')"{/if}>{lang guiigo_manage:tlang0037}</a>
				<!--{if $task[csc] < 100}-->
				<a href="home.php?mod=task&do=delete&id=$task[taskid]" 
				class="dialog guiigo-pn zy-a ab-az zy-ac"
				ck-cus="true" 
				ck-param="{type:'modal',load:'true',callpar:{rid:'$task[taskid]',type:'applytask'},fn:'MsgCallTasklist',uid:'$_G[uid]'}"
				external>{lang guiigo_manage:tlang0807}</a><!--{/if}-->
				<script>
					function coutomAjaxGet(obj){
						ck8.showPreloader('','load');
						ck8.ajax({
							type : 'GET',
							url : ck8(obj).attr('data-href') + '&inajax=1',
							dataType : 'xml',
							success: function(s){
								setTimeout(function(){ck8.hidePreloader()}, 100);
								s = s.lastChild.firstChild.nodeValue;
								var msg = '';
								if(s){
									msg = s.split('|')[1]
								}
								if(msg = 'task_reward_credit'){
									msg = '{lang guiigo_manage:tlang0038}'
								}
								app.PageRefresh(false,'gg-kj-rwxq','home.php?mod=task&do=view&id=$task[taskid]')
								popup.open(msg);
							},
							error: function(){
								ck8.hidePreloader();
								ck8.toast('{lang guiigo_manage:tlang0039}','shibai');
							}
						})
					}
				</script>
			</div>
		<!--{elseif $allowapply == '-2'}-->
			<div class="jdan-tsan">
				<p class="bk-d bg-p zy-b">{lang task_group_nopermission}</p>
				<a href="javascript:;" class="guiigo-pn zy-a ab-b">{lang guiigo_manage:tlang0035}</a>
			</div>
		<!--{elseif $allowapply == '-3'}-->
			<div class="jdan-tsan">
				<p class="bk-d bg-p zy-b">{lang guiigo_manage:tlang0808}</p>
				<a href="javascript:;" class="guiigo-pn zy-a ab-b">{lang guiigo_manage:tlang0035}</a>
			</div>
		<!--{elseif $allowapply == '-4'}-->
			<div class="jdan-tsan">
				<p class="bk-d bg-p zy-b">{lang task_lose_on}$task[dateline]</p>
			</div>
		<!--{elseif $allowapply == '-5'}-->
			<div class="jdan-tsan">
				<p class="bk-d bg-p zy-b">{lang task_complete_on}$task[dateline]</p>
			</div>
		<!--{elseif $allowapply == '-6'}-->
			<div class="jdan-tsan">
				<p class="bk-d bg-p zy-b">{lang task_complete_on}$task[dateline] &nbsp; {$task[t]}{lang task_applyagain}</p>
				<a href="javascript:;" class="guiigo-pn zy-a ab-b">{lang guiigo_manage:tlang0035}</a>
			</div>
		<!--{elseif $allowapply == '-7'}-->
			<div class="jdan-tsan">
				<p class="bk-d bg-p zy-b">{lang task_lose_on}$task[dateline] &nbsp; {$task[t]}{lang task_reapply}</p>
				<a href="javascript:;" class="guiigo-pn zy-a ab-b">{lang guiigo_manage:tlang0035}</a>
			</div>
		<!--{elseif $allowapply == '2'}-->
			<div class="jdan-tsan">
				<p class="bk-d bg-p zy-b">{lang task_complete_on}$task[dateline] &nbsp; {lang task_applyagain_now}</p>
			</div>
		<!--{elseif $allowapply == '3'}-->
			<div class="jdan-tsan">
				<p class="bk-d bg-p zy-b">{lang task_lose_on}$task[dateline] &nbsp; {lang task_reapply_now}</p>
			</div>
		<!--{/if}-->
		<!--{if $allowapply > '0'}-->
			<div class="jdan-tsan">
				<a href="home.php?mod=task&do=apply&id=$task[taskid]" 
				class="dialog guiigo-pn zy-a ab-az zy-ac"
				ck-cus="true" 
				ck-param="{type:'modal',load:'true',callpar:{rid:'$task[taskid]',type:'tasknrsq'},fn:'MsgCallTasklist',uid:'$_G[uid]'}"
				external>{lang guiigo_manage:tlang0035}</a>
			</div>
		<!--{/if}-->
	</div>
	<!--{if $task[applicants]}-->
		<div class="gg-yq-yylb">
			<div class="yylb-yybt zy-f">{lang task_applicants}</div>
			<div id="ajaxparter" class="yylb-lbnr ms-a"></div>
		</div>
		<script type="text/javascript">
		ck8(function(){
			ajaxget(false,'home.php?mod=task&do=parter&id=$task[taskid]','ajaxparter')
		})
		</script>
	<!--{/if}-->
</div>