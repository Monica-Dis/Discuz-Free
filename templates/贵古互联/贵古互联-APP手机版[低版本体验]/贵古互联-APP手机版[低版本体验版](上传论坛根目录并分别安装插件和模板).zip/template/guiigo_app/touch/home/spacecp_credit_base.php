<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp-credit-base">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0543}</h1>
	</header>
	<div class="content base-scroll">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if in_array($_GET['op'], array('base', 'buy', 'transfer', 'exchange'))}-->
				<div class="jfol-jfzs">
					<!--{eval $creditid=0;}-->
					<div class="jfzs-zjfx">
						<h2>{lang guiigo_manage:tlang0544}</h2>
						<div class="zjfx-jfsj zy-a zy-ac"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber($_G['member']['credits'])}--><!--{else}-->$_G['member']['credits']<!--{/if}--></div>
						<!--{if  $_GET['op'] == 'base'}-->
						<p>$creditsformulaexp</p>
						<!--{/if}-->
					</div>
					<div class="jfzs-jfdx list-block-no">
						<ul>
						<!--{loop $_G['setting']['extcredits'] $id $credit}-->
							<!--{if $id!=$creditid}-->
							<li><em>{$credit[title]}</em><p class="zy-a zy-ac"><!--{if $guiigo_config['number_format']}--><!--{echo dnumber(getuserprofile('extcredits'.$id))}--><!--{else}--><!--{echo getuserprofile('extcredits'.$id);}--><!--{/if}-->{$credit[unit]}</p></li>
							<!--{/if}-->
						<!--{/loop}-->
						</ul>
					</div>
					<div class="guiigo-bwdx">
						<div class="guiigo-bwdx-a"></div>
						<div class="guiigo-bwdx-b"></div>
					</div>
				</div>
			<!--{/if}-->
			<!--{if $guiigo_config['navigation_top']}--><div class="auto-fixd"><div class="auto-top"><!--{/if}-->
			<div id="ejdhsd" class="swiper-container guiigo-cjdh gg-cjdh-spacecpcreditbase list-block-no xh-b bg-c">
				<ul class="swiper-wrapper">
					<li class="swiper-slide<!--{if $opactives[base]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.base-scroll','home.php?mod=spacecp&ac=credit&op=base',['gg-kj-jfol']);">{lang guiigo_manage:tlang0545}</a><span class="bg-b"></span></li>
					<!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
					<li class="swiper-slide<!--{if $opactives[transfer]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.base-scroll','home.php?mod=spacecp&ac=credit&op=transfer',['gg-kj-jfol']);">{lang guiigo_manage:tlang0546}</a><span class="bg-b"></span></li>
					<!--{/if}-->
					<!--{if $_G[setting][exchangestatus]}-->
					<li class="swiper-slide<!--{if $opactives[exchange]}--> on<!--{/if}-->"><a href="javascript:;" onclick="app.LoadPageForumView('.base-scroll','home.php?mod=spacecp&ac=credit&op=exchange',['gg-kj-jfol']);">{lang guiigo_manage:tlang0547}</a><span class="bg-b"></span></li>
					<!--{/if}-->
				</ul>
			</div>
			<!--{if $guiigo_config['navigation_top']}--></div></div><!--{/if}-->
			<div class="gg-kj-jfol ms-a cl">
				<!--{if $_GET['op'] == 'base'}-->
					<!--{if $loglist}-->
						<div class="jfol-jfmx list-block-no">
							<ul>
								<!--{loop $loglist $value}-->
								<li class="bg-c xh-b">
								<!--{eval $value = makecreditlog($value, $otherinfo);}-->
									<div class="jfmx-jfzj zy-a zy-ac bg-b">$value['credit']</div>
									<p><!--{if $value['operation']}-->$value['opinfo']<!--{else}-->$value['text']<!--{/if}--></p>
									<div class="jfmx-jfsj zh-a zy-g">$value['dateline']</div>
								<!--{/loop}-->
								</li>
							</ul>
						</div>
					<!--{else}-->
						<div class="guiigo-wnrtx">
							<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
							<p class="zy-c">{lang memcp_credits_log_none}</p>
						</div>
					<!--{/if}-->
				<!--{elseif $_GET['op'] == 'transfer'}-->
					<!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
					<form id="transferform" 
					name="transferform" 
					method="post" 
					autocomplete="off" 
					action="home.php?mod=spacecp&ac=credit&op=transfer"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pmid:'',type:'transferform'},fn:'MsgCallBase',load:'true',uid:'$_G[uid]'}" 
					>
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="hidden" name="transfersubmit" value="true" />
						<input type="hidden" name="handlekey" value="transfercredit" />
						<div id="gg-jfzzon" class="guiigo-wblb list-block-no bg-c cl">
							<ul>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0548} <span class="zy-i">*</span></div>
									<div class="wblb-wbnr zy-h"><input type="text" name="transferamount" id="transferamount" class="guiigo-px s-a" size="5" placeholder="{$_G[setting][extcredits][$_G[setting][creditstransextra][9]][title]}"/></div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang guiigo_manage:tlang0549} <span class="zy-i">*</span></div>
									<div class="wblb-wbnr zy-h">
										<input type="text" name="to" id="to" class="guiigo-px s-a" size="15" placeholder="{lang guiigo_manage:tlang0550}" />
										<div class="wbnr-t bk-d bg-p zy-b">{lang memcp_credits_transfer_min_balance} $_G[setting][transfermincredits] {$_G[setting][extcredits][$_G[setting][creditstransextra][9]][unit]}<br /><!--{if intval($taxpercent) > 0}-->{lang credits_tax} $taxpercent<!--{/if}--></div>
									</div>
								</li>
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang transfer_login_password} <span class="zy-i">*</span></div>
									<div class="wblb-wbnr zy-h"><input type="password" name="password" class="guiigo-px s-a" value="" /></div>
								</li>
								
								<li class="guiigo-flex xh-b cl">
									<div class="wblb-wbbt zy-c">{lang credits_transfer_message}</div>
									<div class="wblb-wbnr zy-h"><input type="text" name="transfermessage" class="guiigo-px s-a" size="40" placeholder="{lang guiigo_manage:tlang0229}" /></div>
								</li>
							</ul>
						</div>
						<div class="mn-a">
							<button type="submit" name="transfersubmit_btn" id="transfersubmit_btn" class="formdialog guiigo-pn ab-az zy-a zy-ac" value="true">{lang guiigo_manage:tlang0551}</button>
							<span style="display: none" id="return_transfercredit"></span>
						</div>
					</form>
					<!--{/if}-->
				<!--{elseif $_GET['op'] == 'exchange'}-->
					<!--{if $_G[setting][exchangestatus] && ($_G[setting][extcredits] || $_CACHE['creditsettings'])}-->
					<form id="exchangeform" 
					name="exchangeform" 
					method="post" 
					autocomplete="off" 
					action="home.php?mod=spacecp&ac=credit&op=exchange&handlekey=credit"
					ck-cus="true"
					ck-param="{type:'modal',callpar:{pmid:'',type:'exchangeform'},fn:'MsgCallBase',load:'true',uid:'$_G[uid]'}" 
					>
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="operation" value="exchange" />
					<input type="hidden" name="exchangesubmit" value="true" />
					<input type="hidden" name="outi" value="" />
					<div id="gg-jfdhon" class="guiigo-wblb list-block-no bg-c cl">
						<ul>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang memcp_credits_exchange}</div>
								<div class="wblb-wbnr zy-h"><input type="text" id="exchangeamount" name="exchangeamount" class="guiigo-px s-a" size="5" value="0" onkeyup="exchangecalcredit()" /></div>
								<div class="wblb-wbnr zy-h">
									<select name="tocredits" id="tocredits" class="guiigo-ps" onChange="exchangecalcredit()">
									<!--{loop $_G[setting][extcredits] $id $ecredits}-->
										<!--{if $ecredits[allowexchangein] && $ecredits[ratio]}-->
											<option value="$id" unit="$ecredits[unit]" title="$ecredits[title]" ratio="$ecredits[ratio]">$ecredits[title]</option>
										<!--{/if}-->
									<!--{/loop}-->
									<!--{eval $i=0;}-->

									<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
										<!--{if $data[title]}-->
										<option value="$id" outi="$i">$data[title]</option>
										<!--{/if}-->
									<!--{/loop}-->
									</select>
								</div>
							</li>
							<li class="guiigo-flex cl">
								<div class="wblb-wbbt zy-c">{lang credits_need}</div>
								<div class="wblb-wbnr zy-h"><input type="text" id="exchangedesamount" class="guiigo-px s-a" size="5" value="0" disabled="disabled" /></div>
								<div class="wblb-wbnr zy-h">
									<select name="fromcredits" id="fromcredits_0" class="guiigo-ps" style="display: none" onChange="exchangecalcredit();">
									<!--{loop $_G[setting][extcredits] $id $credit}-->
										<!--{if $credit[allowexchangeout] && $credit[ratio]}-->
											<option value="$id" unit="$credit[unit]" title="$credit[title]" ratio="$credit[ratio]">$credit[title]</option>
										<!--{/if}-->
									<!--{/loop}-->
									</select>
									<!--{eval $i=0;}-->
									<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
										<select name="fromcredits_$i" id="fromcredits_$i" class="guiigo-ps" style="display: none" onChange="exchangecalcredit()">
										<!--{loop $data[creditsrc] $id $ratio}-->
											<option value="$id" unit="$_G['setting']['extcredits'][$id][unit]" title="$_G['setting']['extcredits'][$id][title]" ratiosrc="$data[ratiosrc][$id]" ratiodesc="$data[ratiodesc][$id]">$_G['setting']['extcredits'][$id][title]</option>
										<!--{/loop}-->
										</select>
									<!--{/loop}-->
									<script type="text/javascript">
										var tocredits = $('tocredits');
										var fromcredits = $('fromcredits_0');
										if(fromcredits.length > 1 && tocredits.value == fromcredits.value) {
											fromcredits.selectedIndex = tocredits.selectedIndex + 1;
										}
									</script>
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbnr zy-h">
									<div class="wbnr-t bk-d bg-p zy-b ms-c">
										<!--{if $_G[setting][exchangemincredits]}-->
											{lang memcp_credits_exchange_min_balance} $_G[setting][exchangemincredits]<br />
										<!--{/if}-->
										<span id="taxpercent">
										<!--{if intval($taxpercent) > 0}-->
											{lang credits_tax} $taxpercent
										<!--{/if}-->
										</span>
									</div>
								</div>
							</li>
							<li class="guiigo-flex xh-b cl">
								<div class="wblb-wbbt zy-c">{lang transfer_login_password} <span class="zy-i">*</span></div>
								<div class="wblb-wbnr zy-h"><input type="password" name="password" class="guiigo-px s-a" value="" size="20" /></div>
							</li>
						</ul>
					</div>
					<div class="mn-a">
						<button type="submit" name="exchangesubmit_btn" id="exchangesubmit_btn" class="formdialog guiigo-pn ab-az zy-a zy-ac" value="true" tabindex="2">{lang guiigo_manage:tlang0552}</button>
					</div>
					</form>
					<script type="text/javascript">
						function exchangecalcredit() {
							with(Dz('exchangeform')) {
								tocredit = tocredits[tocredits.selectedIndex];
								if(!tocredit) {
									return;
								}
								<!--{eval $i=0;}-->
								<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
									Dz('fromcredits_$i').style.display = 'none';
								<!--{/loop}-->
								if(tocredit.getAttribute('outi')) {
									outi.value = tocredit.getAttribute('outi');
									fromcredit = Dz('fromcredits_' + tocredit.getAttribute('outi'));
									Dz('taxpercent').style.display = Dz('fromcredits_0').style.display = 'none';
									fromcredit.style.display = '';
									fromcredit = fromcredit[fromcredit.selectedIndex];
									Dz('exchangeamount').value = Dz('exchangeamount').value.toInt();
									if(Dz('exchangeamount').value != 0) {
										Dz('exchangedesamount').value = Math.floor( fromcredit.getAttribute('ratiosrc') / fromcredit.getAttribute('ratiodesc') * $('exchangeamount').value);
									} else {
										Dz('exchangedesamount').value = '';
									}
								} else {
									outi.value = 0;
									Dz('taxpercent').style.display = Dz('fromcredits_0').style.display = '';
									fromcredit = fromcredits[fromcredits.selectedIndex];
									Dz('exchangeamount').value = Dz('exchangeamount').value.toInt();
									if(fromcredit.getAttribute('title') != tocredit.getAttribute('title') && Dz('exchangeamount').value != 0) {
										if(tocredit.getAttribute('ratio') < fromcredit.getAttribute('ratio')) {
											Dz('exchangedesamount').value = Math.ceil( tocredit.getAttribute('ratio') / fromcredit.getAttribute('ratio') * Dz('exchangeamount').value * (1 + $_G[setting][creditstax]));
										} else {
											Dz('exchangedesamount').value = Math.floor( tocredit.getAttribute('ratio') / fromcredit.getAttribute('ratio') * Dz('exchangeamount').value * (1 + $_G[setting][creditstax]));
										}
									} else {
										Dz('exchangedesamount').value = '';
									}
								}
							}
						}
						String.prototype.toInt = function() {
							var s = parseInt(this);
							return isNaN(s) ? 0 : s;
						}
						exchangecalcredit();
					</script>
					<!--{/if}-->
				<!--{/if}-->
			</div>
			$guiigo_config['footer_html']
		</div>
	</div>
	<script type="text/javascript">
		function MsgCallBase(msg,par,param){
			if(typeof msg === 'object' || typeof par === 'object'){
				if (msg.msg.indexOf('{lang guiigo_manage:tlang0553}') != -1){
					ck8.toast('{lang guiigo_manage:tlang0554}');
					app.PageRefresh(false,'#gg-jfzzon','home.php?mod=spacecp&ac=credit&op=transfer')
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0555}') != -1){
					ck8.toast('{lang guiigo_manage:tlang0556}');
					app.PageRefresh(false,'#gg-jfdhon','home.php?mod=spacecp&ac=credit&op=exchange')
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0557}') != -1){
					ck8.toast('{lang guiigo_manage:tlang0558}');
				}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0559}') != -1){
					ck8.toast('{lang guiigo_manage:tlang0560}');
				}else {
					ck8.toast(msg.msg,'shibai');
				}
			}else{
				ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
			}
		}
	</script>
</div>
<!--{template common/footer}-->