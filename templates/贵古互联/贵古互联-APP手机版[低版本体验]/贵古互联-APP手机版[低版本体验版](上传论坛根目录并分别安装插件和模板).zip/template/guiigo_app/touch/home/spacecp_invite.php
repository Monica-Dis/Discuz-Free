<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $_GET['op'] == 'resend'}-->
<!--{elseif $_GET['op'] == 'delete'}-->
<!--{elseif $_GET['op'] == 'showinvite'}-->
	<!--{loop $list $key $url}-->
	<tr>
		<td class="bbda"><a href="$url" onclick="setCopy('$url', '{lang copy_invite_link}');return false;">$url</a> &nbsp;<a href="$url" onclick="setCopy('$url', '{lang copy_invite_link}');return false;" class="xi2">[{lang copy}]</a></td>
		<td class="bbda"><a href="javascript:;" onclick="setCopy('$key', '{lang copy_invite_code}');return false;">$key</a> &nbsp;<a href="javascript:;" onclick="setCopy('$key', '{lang copy_invite_code}');return false;" class="xi2">[{lang copy}]</a></td>
	</tr>
	<!--{/loop}-->
<!--{else}-->
<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-publish}--><!--{/if}-->
<div class="page page-current" data-mod="spacecp-invite">
	<header class="gg-app-hide bar bar-nav guiigo-nydb bg-c xh-b">
		<a class="button button-link pull-left back zy-f"><i class="icon guiigoapp-xzfh zy-f"></i></a>
		<h1 class="title zy-h">{lang guiigo_manage:tlang0413}</h1>
	</header>
	<div class="content">
		<div class="list-block">
			<!--{if $guiigo_config['open_sidebar_menu']}--><!--{template common/guiigo-clnav}--><!--{/if}-->
			<!--{if $allowinvite}-->
				<form method="post" 
				id="newinvite" 
				autocomplete="off" 
				action="home.php?mod=spacecp&ac=invite&appid=$appid&ref"
				ck-cus="true"
				ck-param="{type:'modal',callpar:{id:'',type:'newinvite'},fn:'MsgCallInvite',load:'true',uid:'$_G[uid]'}" 
				>
					<div class="gg-qz-flts bg-c ms-a sh-a xh-b">
						<div class="flts-tsnr bk-d bg-p zy-b">{lang guiigo_manage:tlang0573}<!--{if $config[inviteaddcredit] || $config[invitedaddcredit]}-->{lang friend_invite_success}
						<!--{if $config[invitedaddcredit]}-->{lang you_get} <strong class="xi1">$config[invitedaddcredit]</strong> {lang unit}{$credittitle},<!--{/if}-->
						<!--{if $config[inviteaddcredit]}-->{lang friend_get} <strong class="xi1">$config[inviteaddcredit]</strong> {lang unit}{$credittitle},<!--{/if}-->
						{lang go_nuts}<!--{/if}--></div>
					</div>
					<div id="invitelist" class="gg-yq-yqlj">
						<!--{if $list}-->
							<div class="yqlj-ljlb ms-a sh-a xh-b bg-c">
								<ul>
									<!--{loop $list $key $url}-->
									<li class="guiigo-flex xh-b cl">
										<div class="ljlb-ljnr bg-e zy-c">$url</div>
										<a href="javascript:;" class="guiigo-flexy guiigo-pn ab-az zy-a zy-ac" cptext="$url" onclick="CkClipboard(this);" id="cptext1">{lang guiigo_manage:tlang0574}</a>
									</li>
									<!--{/loop}-->
									<!--{if !$creditnum}-->
										<li class="guiigo-flex xh-b cl">
											<div class="ljlb-ljnr bg-e zy-c">$inviteurl</div>
											<a href="javascript:;" class="guiigo-flexy guiigo-pn ab-az zy-a zy-ac" cptext="$inviteurl" onclick="CkClipboard(this);" id="cptext3">{lang guiigo_manage:tlang0574}</a>
											<span class="guiigo-yjsz bg-j zy-a">{lang guiigo_manage:tlang0575}</span>
										</li>
									<!--{/if}-->
								</ul>
							</div>
						<!--{else}-->
							<!--{if !$creditnum}-->
								<div class="yqlj-ljlb ms-a sh-a xh-b bg-c">
									<ul>
										<li class="guiigo-flex xh-b cl">
											<div class="ljlb-ljnr bg-e zy-c">$inviteurl</div>
											<a href="javascript:;" class="guiigo-flexy guiigo-pn ab-az zy-a zy-ac" cptext="$inviteurl" onclick="CkClipboard(this);" id="cptext2">{lang guiigo_manage:tlang0574}</a>
											<span class="guiigo-yjsz bg-j zy-a">{lang guiigo_manage:tlang0575}</span>
										</li>
									</ul>
								</div>
							<!--{else}-->	
								<div class="yqlj-wljt"><i class="icon guiigoapp-wyqlj zy-g"></i><p class="zy-c">{lang guiigo_manage:tlang0576}</p></div>
							<!--{/if}-->
						<!--{/if}-->
					</div>
					<div class="gg-yq-gmlj ms-a bg-c sh-a xh-b">
						<p class="gmlj-gmts xh-b zy-c">{lang invitation_code_spend}{$extcredits[title]} <strong class="xi1">$creditnum</strong> $extcredits[unit]<!--{if $_G['group']['maxinviteday']}-->, {lang max_invite_day_message}<!--{/if}--></p>
						<div class="guiigo-flex gmlj-slqr cl">
							<input type="text" name="invitenum" value="1" size="10" class="guiigo-px bg-e"/>
							<button type="submit" name="invitesubmit_btn" value="true" class="formdialog guiigo-flexy guiigo-pn ab-az zy-a zy-ac">{lang guiigo_manage:tlang0577}</button>
						</div>
						<span id="return_newinvite" style="display:none;"></span>
						<script type="text/javascript">
							function succeedhandle_newinvite(url, message, values) {
								if(values['deduction']) {
									var allCreditObj = $('haveallcredit');
									allCreditObj.innerHTML = parseInt(allCreditObj.innerHTML) - parseInt(values['deduction']);
									/* var x = new Ajax();
									x.get('home.php?mod=spacecp&ac=invite&op=showinvite&inajax=1', function(s){
										ajaxinnerhtml($('invitelist'), s);
									});
									showCreditPrompt(); */
								}
							}
						</script>
					</div>
					<!--{if $flist}-->
						<div class="gg-yq-yylb">
							<div class="yylb-yybt zy-f">{lang invited_friend}</div>
							<div class="yylb-lbnr ms-a">
								<!--{loop $flist $key $value}-->
									<a href="home.php?mod=space&uid=$value[fuid]&do=profile" class="guiigo-ty"><!--{avatar($value[fuid],middle)}--></a>
								<!--{/loop}-->
							</div>
						</div>
					<!--{/if}-->
					<input type="hidden" name="handlekey" value="newinvite" />
					<input type="hidden" name="invitesubmit" value="true" />
					<input type="hidden" name="formhash" value="{FORMHASH}" />
				</form>
			<!--{else}-->
				<div class="guiigo-wnrtx">
					<img src="{$_G['siteurl']}{$_G['style']['tpldir']}/static/images/wnr.png">
					<p class="zy-c">{lang guiigo_manage:tlang0578}</p>
				</div>
			<!--{/if}-->
			$guiigo_config['footer_html']
		</div>
	</div>
	<script>
	ck8(function(){
		app.loadScript('clipboard.min')
	})
	
	function CkClipboard(self){
		var msg = '{lang guiigo_manage:tlang0579}';
		var cptext = ck8(self).attr('cptext')
		var cptextid = ck8(self).attr('id')
		if(!cptext){
			ck8.toast('{lang guiigo_manage:tlang0580}');
			return;
		}
		var clipboard = new Clipboard('#'+cptextid, {
			text: function (e) {
				ck8.toast(msg);
				return cptext;
			}
		});
	}
	
	function MsgCallInvite(msg,par,param){
		if(typeof msg === 'object' || typeof par === 'object'){
			if (msg.msg.indexOf('{lang guiigo_manage:tlang0013}') != -1 && param.type == 'newinvite'){
				ck8.toast('{lang guiigo_manage:tlang0203}');
				app.PageRefresh(false,'#invitelist','home.php?mod=spacecp&ac=invite')
			}else if (msg.msg.indexOf('{lang guiigo_manage:tlang0581}') != -1 && param.type == 'newinvite'){
				ck8.toast('{lang guiigo_manage:tlang0582}');
			}else {
				ck8.toast(msg.msg,'shibai');
			}
		}else{
			ck8.toast('{lang guiigo_manage:tlang0025}','shibai');
		}
	}
	</script>
</div>
<!--{/if}-->
<!--{template common/footer}-->