/*
	[Discuz!] (C)2001-2099 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms
	$Id: smilies.js 29684 2012-04-25 04:00:58Z zhangguosheng $
*/

function smilies_show(smcols, seditorkey) {
	if(typeof smilies_type == 'undefined') {
		var scriptNode = document.createElement("script");
		scriptNode.type = "text/javascript";
		scriptNode.charset = charset ? charset : (BROWSER.firefox ? document.characterSet : document.charset);
		scriptNode.src = 'data/cache/common_smilies_var.js?' + VERHASH;
		Dz('append_parent').appendChild(scriptNode);
		scriptNode.onload = function() {
			smilies_onload(smcols, seditorkey);
		};
	} else {
		smilies_onload(smcols, seditorkey);
	}
}

function smilies_onload(smcols, seditorkey) {
	seditorkey = !seditorkey ? '' : seditorkey;
	smile = getcookie('smile').split('D');
	if(typeof smilies_type == 'object') {
		if(smile[0] && smilies_array[smile[0]]) {
			CURRENTSTYPE = smile[0];
		} else {
			for(i in smilies_array) {
				CURRENTSTYPE = i;break;
			}
		}
		smiliestype = '';

		for(i in smilies_type) {
			key = i.substring(1);
			if(smilies_type[i][0]) {
				picUrl = STATICURL + 'image/smiley/' + smilies_type[i][1] + '/' + smilies_array[key][1][0][2];
				smiliestype += '<div class="swiper-slide"><a href="#'+ seditorkey +'stype_'+key+'" ' + (CURRENTSTYPE == key ? 'class="tab-link btnl active"' : 'class="tab-link btnl"') + ' id="'+seditorkey+'stype_'+key+'" onclick="smilies_switch(\'' + smcols + '\', '+key+', 1, \'' + seditorkey + '\');if(CURRENTSTYPE) {Dz(\''+seditorkey+'stype_\'+CURRENTSTYPE).className=\'tab-link btnl\';}this.className=\'tab-link btnl active\';CURRENTSTYPE='+key+';"><img src="'+picUrl+'" class="vm" /></a></div>';
			}
		}
		Dz('smilies').innerHTML = smiliestype;
		smilies_switch(smcols, CURRENTSTYPE, smile[1], seditorkey);
	}
}

function smilies_switch(smcols, type, page, seditorkey) {
	page = page ? page : 1;
	if(!smilies_array[type] || !smilies_array[type][page]) return;
	setcookie('smile', type + 'D' + page, 31536000);
	smiliesdata = '<div class="swiper-slide">';
	for(var p = 0; p < smilies_array[type].length; p++) {
		if (p <= 0)continue;
		j = k = 0;
	    img = [];
		for(var i = 0; i < smilies_array[type][p].length; i++) {
			if(j >= smcols) {
				smiliesdata += '</div><div class="swiper-slide">';
				j = 0;
			}
			s = smilies_array[type][p][i];
			smilieimg = STATICURL + 'image/smiley/' + smilies_type['_' + type][1] + '/' + s[2];
			img[k] = new Image();
			img[k].src = smilieimg;
            smiliesdata += s && s[0] ? '<li><a class="bqimg" onclick="seditor_insertunit(\'' + seditorkey + '\', \'' + s[1].replace(/'/, '\\\'') + '\');" id="' + seditorkey + 'smilie_' + s[0] + '_td"><img id="smilie_' + s[0] + '" src="' + smilieimg + '" /></a></li>' : '';
			j++;k++;
		}
    }
	smiliesdata += '</div>';
	Dz('ck8_data').innerHTML = smiliesdata;
}

function seditor_insertunit(key, smilies) {
    text = Dz('needmessage');
    text.value += smilies;
    text.focus();
}