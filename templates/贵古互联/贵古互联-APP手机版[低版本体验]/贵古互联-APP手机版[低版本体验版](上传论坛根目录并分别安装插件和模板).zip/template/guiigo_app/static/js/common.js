var app = new ckRpe()
var safescripts = {}, evalscripts = [],JSLOADED= [];
var popup = {
	open : function(pop, type, url) {
	    var _this = this, popModal = false;
		_this.close();
        var url = ck8(pop).find('a').attr('href');

		if(typeof pop == 'string') {
			if(type == 'alert') {
				ck8.alert(pop, '\u6e29\u99a8\u63d0\u793a', function () {
					_this.close()
				});
				return false;
			} else if(type == 'confirm') {
				ck8.confirm(pop, '\u6e29\u99a8\u63d0\u793a',
					function () {
						if(url) _this.router(url)
                        _this.close()
					},
					function () {
					  _this.close()
					}
				);
				return false;
			}else{
                popModal = true;
			}
		}

		if(popModal && pop){
            app.popModal(pop)
		}
	},
	router : function(url) {
		ck8.router.load(url, true);
	},
	close : function() {
		ck8.closeModal();
	}
}

var dialog = {
	init : function() {
		ck8(document).off('click', '.dialog').on('click', '.dialog', function(event) {
            var obj = ck8(this);
			var pObj = app.AnalysisAll(obj);
			if(typeof pObj !== 'object'){
                pObj ={}
			}
			var _confirm = obj.attr('ck-confirm') ? obj.attr('ck-confirm') : false,
				cus = pObj.cus ? pObj.cus : '',
				allparam = pObj.param ? pObj.param : {},
				param = allparam.callpar ? allparam.callpar : {},
				fn = allparam.fn ? allparam.fn : '',
				load = allparam.load ? allparam.load : false,
				uid = parseInt(allparam.uid) ? parseInt(allparam.uid) : false,
				verifyLoging = allparam.verifyLoging ? true : false;
				if(cus && (uid == false || uid <= 0 || parseInt(discuz_uid) != uid) && !verifyLoging){
					if(!parseInt(discuz_uid)){
						login.GoLogin();
						return false;
					}
				}
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			if(_confirm == 'true'){
				ck8.confirm('<div class="c9">'+(allparam.msg ? allparam.msg : '\u786e\u5b9a\u8981\u53d6\u6d88\u5173\u6ce8\u0054\u0041\u5417\uff1f') +'</div>', (allparam.title ? allparam.title : '\u6e29\u99a8\u63d0\u793a'), function (){
					_ajaxGet(obj,cus,load,fn,param)
				})
			}else{
				_ajaxGet(obj,cus,load,fn,param)
			}
			return false;
		})
	}
}

function _ajaxGet(obj,cus,load,fn,param){
	if(load)
	    ck8.showPreloader('','load');
	ck8.ajax({
		type : 'GET',
		url : obj.attr('href') + '&inajax=1&fn='+ fn,
		dataType : 'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 100);
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);

			if(cus == 'true' && (Docs.indexOf("=='function')") != -1)){
				if(app.Devalscript(Docs,fn,param))return false;
			}else if(cus == 'true' && (Docs.indexOf(">window.location.href='") != -1)){
				var isfn = false,url='',Msgfn;
				try{
					isfn = typeof(eval(fn)) == 'function';
				}catch(e){
					console.log(e)
				}
				if(isfn){
					var result = Docs.match(/href=(\S*)(<\/script>)$/i);
					if(result[1]){
						url = result[1].match(/'(\S*)'/)[1].replace('&mobile=2','');
					}
					Msgfn = eval(fn)
					Msgfn({'msg':'isjmurl', 'url':url},{}, param)
					return false;
				}
			}else if(Docs.indexOf('data-mod="login"') != -1){
				login.GoLogin();
				return;
			}
			popup.open(Docs);
			evalscript(Docs);
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}


var formdialog = {
	init : function() {
		ck8(document).off('click', '.formdialog').on('click', '.formdialog', function() {
			var ft = Object;
            var formobj = ck8(this.form)
			var pObj = app.AnalysisAll(formobj);
			if(typeof pObj !== 'object'){
                pObj ={}
			}
			var cus = pObj.cus ? pObj.cus : '',
				allparam = pObj.param ? pObj.param : {},
				param = allparam.callpar ? allparam.callpar : {},
				fn = allparam.fn ? allparam.fn : '',
				load = allparam.load ? allparam.load : false,
				uid = parseInt(allparam.uid) ? parseInt(allparam.uid) : false,
                verifyLoging = allparam.verifyLoging ? true : false;
				if(cus && (uid == false || uid <= 0 || parseInt(discuz_uid) != uid) && !verifyLoging){
					if(!parseInt(discuz_uid)){
						login.GoLogin();
						return false;
					}
				}
			
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			
			if(allparam.verify != undefined && allparam.verify){
				if(eval('('+ allparam.verify +'())')){
					return false;
				}
			}
			
			if(allparam.upfiles == undefined){
				allparam.upfiles = false;
			}
			
			if(allparam.upfiles){
				ft = new FormData(formobj[0]);
			}

			var postAata = {
				type:'POST',
				url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&fn='+ fn +'&inajax=1',
				data: allparam.upfiles ? ft : formobj.serialize(),
				dataType:'xml',
				success: function(e){success(e)},
				error: function(e){error(e)}
			};
            if(allparam.upfiles){
				postAata.processData = false;
				postAata.contentType = false;
			}

			var	success = function(s){
				setTimeout(function(){ck8.hidePreloader()}, 200);
				var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
				if(Docs && Docs.indexOf("show_success(") != -1 ||  Docs.indexOf("show_error(") != -1){
					 eval(Docs)
				    return;
				}
				if(cus == 'true' && (Docs.indexOf("=='function')") != -1)){
					if(app.Devalscript(Docs,fn,param))return false;
				}else if(cus == 'true' && (Docs.indexOf(">window.location.href='") != -1)){
					var isfn = false,url='',Msgfn;
					try{
						isfn = typeof(eval(fn)) == 'function';
					}catch(e){
						console.log(e)
					}
					if(isfn){
						var result = Docs.match(/href=(\S*)(<\/script>)$/i);
						if(result[1]){
							url = result[1].match(/'(\S*)'/)[1].replace('&mobile=2','');
						}
						Msgfn = eval(fn)
						Msgfn({'msg':'isjmurl', 'url':url},{}, param)
						return false;
					}
				}else if(Docs.indexOf('data-mod="login"') != -1){
					login.GoLogin();
					return;
				}
				popup.open(Docs);
				evalscript(Docs);
			}
				
			var	error = function(){
				ck8.hidePreloader();
				ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
			}
			
			if(load)
				ck8.showPreloader('','load');
			ck8.ajax(postAata)
			return false;
		})
	}
}

function evalscript(s) {
	if(s.indexOf('<script') == -1) return s;
	var p = /<script[^\>]*?>([^\x00]*?)<\/script>/ig;
	var arr = [];
	while(arr = p.exec(s)) {
		var p1 = /<script[^\>]*?src=\"([^\>]*?)\"[^\>]*?(reload=\"1\")?(?:charset=\"([\w\-]+?)\")?><\/script>/i;
		var arr1 = [];
		arr1 = p1.exec(arr[2]);
		if(arr1) {
			appendscript(arr1[1], '', arr1[2], arr1[3]);
		} else {
			p1 = /<script(.*?)>([^\x00]+?)<\/script>/i;
			arr1 = p1.exec(arr[0]);
			if(!arr1) return;
			appendscript('', arr1[2], arr1[1].indexOf('reload=') != -1);
		}
	}
	return s;
}

function appendscript(src, text, reload, charset) {
	var id = hash(src + text);
	if(!reload && in_array(id, evalscripts)) return;
	if(reload && $('#' + id)[0]) {
		ck8('#' + id)[0].parentNode.removeChild(ck8('#' + id)[0]);
	}
	evalscripts.push(id);
	var scriptNode = document.createElement("script");
	scriptNode.type = "text/javascript";
	scriptNode.id = id;
	scriptNode.charset = charset ? charset : (!document.charset ? document.characterSet : document.charset);
	try {
		if(src) {
			scriptNode.src = src;
			scriptNode.onloadDone = false;
			scriptNode.onload = function () {
				scriptNode.onloadDone = true;
				JSLOADED[src] = 1;
			};
			scriptNode.onreadystatechange = function () {
				if((scriptNode.readyState == 'loaded' || scriptNode.readyState == 'complete') && !scriptNode.onloadDone) {
					scriptNode.onloadDone = true;
					JSLOADED[src] = 1;
				}
			};
		} else if(text){
			scriptNode.text = text;
		}
		document.getElementsByTagName('head')[0].appendChild(scriptNode);
	} catch(e) {}
}

function hash(string, length) {
	var length = length ? length : 32;
	var start = 0;
	var i = 0;
	var result = '';
	filllen = length - string.length % length;
	for(i = 0; i < filllen; i++){
		string += "0";
	}
	while(start < string.length) {
		result = stringxor(result, string.substr(start, length));
		start += length;
	}
	return result;
}

function stringxor(s1, s2) {
	var s = '';
	var hash = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	var max = Math.max(s1.length, s2.length);
	for(var i=0; i<max; i++) {
		var k = s1.charCodeAt(i) ^ s2.charCodeAt(i);
		s += hash.charAt(k % 52);
	}
	return s;
}

function isUndefined(variable) {
	return typeof variable == 'undefined' ? true : false;
}

function relatekw(obj,maxlen,msg) {
	var v = obj.value, charlen = 0, maxlen = !maxlen ? 200 : maxlen, curlen = maxlen, len = v.length;
	for(var i = 0; i < v.length; i++) {
		if(v.charCodeAt(i) < 0 || v.charCodeAt(i) > 255) {
			curlen -= charset == 'utf-8' ? 2 : 1;
		}
	}
	if(curlen <= len) {
		if(!msg){
			msg = '\u6700\u5927\u9650\u5236\u6807\u9898\u957f\u5ea6'+ maxlen;
		}else{
			msg = msg + maxlen;
		}
		obj.value = mb_cutstr(v, maxlen, 0);
		ck8.toast(msg,'shibai');
	}
}

function mb_cutstr(str, maxlen, dot) {
	var len = 0;
	var ret = '';
	var dot = !dot ? '' : dot;
	maxlen = maxlen - dot.length;
	for(var i = 0; i < str.length; i++) {
		len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? (charset == 'utf-8' ? 3 : 2) : 1;
		if(len > maxlen) {
			ret += dot;
			break;
		}
		ret += str.substr(i, 1);
	}
	return ret;
}

function strLenCalc(obj, checklen, maxlen) {
	var v = obj.value, charlen = 0, maxlen = !maxlen ? 200 : maxlen, curlen = maxlen, len = v.length;
	for(var i = 0; i < v.length; i++) {
		if(v.charCodeAt(i) < 0 || v.charCodeAt(i) > 255) {
			curlen -= charset == 'utf-8' ? 2 : 1;
		}
	}
	if(curlen >= len) {
		Dz(checklen).innerHTML = curlen - len;
	} else {
		obj.value = mb_cutstr(v, maxlen, 0);
	}
}

function setcookie(cookieName, cookieValue, seconds, path, domain, secure) {
	if(cookieValue == '' || seconds < 0) {
		cookieValue = '';
		seconds = -2592000;
	}
	if(seconds) {
		var expires = new Date();
		expires.setTime(expires.getTime() + seconds * 1000);
	}
	domain = !domain ? cookiedomain : domain;
	path = !path ? cookiepath : path;
	document.cookie = escape(cookiepre + cookieName) + '=' + escape(cookieValue)
		+ (expires ? '; expires=' + expires.toGMTString() : '')
		+ (path ? '; path=' + path : '/')
		+ (domain ? '; domain=' + domain : '')
		+ (secure ? '; secure' : '');
}

function getcookie(name, nounescape) {
	name = cookiepre + name;
	var cookie_start = document.cookie.indexOf(name);
	var cookie_end = document.cookie.indexOf(";", cookie_start);
	if(cookie_start == -1) {
		return '';
	} else {
		var v = document.cookie.substring(cookie_start + name.length + 1, (cookie_end > cookie_start ? cookie_end : document.cookie.length));
		return !nounescape ? unescape(v) : v;
	}
}

function inserattach(aid) {
	var v = ck8('#needmessage').val();
	v += "[attachimg]"+ aid +"[/attachimg]";
	ck8('#needmessage').val(v);
}

function insertat(str) {
	var v = ck8('#needmessage').val();
	v += str;
	ck8('#needmessage').val(v);
}

function delFile(obj,id){
	var obj = ck8(obj),
		aid = obj.attr('aid');
	if(!aid)return false;
	if(!navigator.onLine){
		ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	ck8.showPreloader('',true);
	ck8.get(
		'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + aid,
		function(s) {
			setTimeout(function(){$.hidePreloader()}, 100);
			var _val = ck8('#needmessage').val();
			ck8('#needmessage').val(_val.replace('[attachimg]' + obj.attr('aid') + '[/attachimg]',''));
			if(id){ck8('#'+id).remove();}else{obj.parent().remove();}
		}
	)
	return false;
}

function Dz(id) {
	return !id ? null : document.getElementById(id);
}

function mb_strlen(str) {
	var len = 0;
	for(var i = 0; i < str.length; i++) {
		len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? (charset == 'utf-8' ? 3 : 2) : 1;
	}
	return len;
}

function in_array(needle, haystack) {
	if(typeof needle == 'string' || typeof needle == 'number') {
		for(var i in haystack) {
			if(haystack[i] == needle) {
				return true;
			}
		}
	}
	return false;
}

ck8.fn._scrollTo = function(options){
	var defaults = {
		toT: 0,
		durTime: 500,
		delay: 30,
		callback: null
	}
	var opts = ck8.extend(defaults,options),
		timer = null,
		_this = this,
		curTop = _this.scrollTop(),
		subTop = opts.toT - curTop,
		index = 0,
		dur = Math.round(opts.durTime / opts.delay),
		smoothScroll = function(t){
			index++;
			var per = Math.round(subTop/dur);
			if(index >= dur){
				_this.scrollTop(t);
				window.clearInterval(timer);
				if(opts.callback && typeof opts.callback == 'function'){
					opts.callback();
				}
				return;
			}else{
				_this.scrollTop(curTop + index * per);
			}
		},
		timer = window.setInterval(function(){
			smoothScroll(opts.toT);
		}, opts.delay)
		
	return _this;
}


var pageScrollTop = {
	init : function() {
		ck8('.content').on('scroll',function(e){
			app.lazyLoad()
			var hdoc = ck8(this).scrollTop();
			app.ScrollAutoTop(hdoc);
			app.HeadShade(hdoc);

			if(typeof closeRrply == 'function'){
				closeRrply()
			}
			try {
				if (hdoc > 450){
		
					if(ck8('.ck8-top').length){
						ck8('.ck8-top').css({'opacity': 1})
					}
					
					var tops = 5;
					if(ck8('.bar-rep').length <= 0 || ck8('nav').length <= 0)
					   tops = 4;
					var h = (ck8(window).height() / tops);
					if (ck8('.ck8-to-top').css('display') == 'block') return;
					if(ck8('.ck8-to-top').length){
						ck8('.ck8-to-top').css({'bottom': h + 'px'}).fadeIn(1500,function(){
							ck8(this).show()
						})
					}

				}else{
					if(ck8('.ck8-top').length){
						ck8('.ck8-top').css({'opacity': 0})
					}
					ck8('.ck8-to-top').fadeOut(1500)
				}
			} catch(e) {}
		})

		ck8(document).off('click', '.ck8-to-top').on('click', '.ck8-to-top', function() {
			ck8('.content')._scrollTo({toT: 0});
		})
		ck8(document).off('click', '.ck8-top').on('click', '.ck8-top', function() {
			ck8('.content')._scrollTo({toT: 0});
		})
		ck8(document).off('click', '.postselect-popup').on('click','.postselect-popup', function (){
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			ck8.ajax({
				type : 'GET',
				url :'forum.php?mod=misc&action=nav&inajax=1',
				dataType : 'xml',
				success: function(s){
                    ck8.popup(s.lastChild.firstChild.nodeValue)
				},
				error: function(){
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			})
		})
		
        ck8(document).off('click', '.getpm-popup').on('click','.getpm-popup', function (){
			var url = ck8(this).attr('data-url')
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			ck8.ajax({
				type : 'GET',
				url : url +'&inajax=1',
				dataType : 'xml',
				success: function(s){
					var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
					ck8.popup(Docs)
										
					var top =  $('#msglist')[0].clientHeight
					$('.content-pm')._scrollTo({ toT:top,durTime:0});


					
				},
				error: function(){
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			})
		})

		ck8(document).off('click', '.postrepl-popup').on('click','.postrepl-popup', function (){
			if(!navigator.onLine){
			   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
			   return false;
			}
			var url = ck8(this).attr('data-url')

			ck8.ajax({
				type : 'GET',
				url :url+'&inajax=1',
				dataType : 'xml',
				success: function(s){
                    ck8.popup(s.lastChild.firstChild.nodeValue)
				},
				error: function(){
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			})
		})
		
	}
}

function sdialog(){
	var dialog = ck8('.ck8-dialog');
 	if(dialog.css('display') == 'none')
    dialog._show(300);
    else
	dialog.hide();
}

var login = {
	init : function() {
		ck8(document).off('click', '.login').on('click', '.login', function(){
            login._login()
			return false;
		})
	},
	GoLogin : function() {
        login._login()
	},
	_login: function() {
		var url = encodeURIComponent(window.location.href.replace('#','') +'&run=yes');
		ck8.confirm('\u4f60\u5c1a\u672a\u767b\u5f55\uff0c\u8bf7\u5148\u767b\u5f55', '\u767b\u5f55\u63d0\u793a',
			function (){
			  app.close_popup()
			  ck8.router.load('member.php?mod=logging&action=login&referer=' + url, true);
			},
			function (){}
		)
		return false;
	}
}

function ajaxget(_this,url,objid,isappend,callback) {
	var page = 0;
	if(_this){
		page = parseInt(ck8(_this).attr('data-page'));
	}
	if(!navigator.onLine){
	   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	ck8.showPreloader('',true);
	ck8.ajax({
		type:'GET',
		url: url +'&page='+ page +'&inajax=1',
		dataType:'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 100);
			var html = ck8.trim(app.initAtr(s.lastChild.firstChild.nodeValue))
			if(html && html != ''){
				if(isappend){
					ck8('#'+ objid).append(html);
				}else{
					ck8('#'+ objid).html(html);
				}
				if(_this)
					ck8(_this).attr('data-page',page +1);
			}else{
				var msg = ck8(_this).attr('data-msg') || '\u6ca1\u6709\u4e86';
				if(_this){
					ck8(_this).html(msg).attr('onclick','');
				}else{
					ck8('#'+objid).html('');
				}
			}
			if(typeof callback === 'function'){
				callback(html);
			}
			ck8.refreshScroller()
		}
	})
	return false;
}

function modaction(obj,action, pid, extra, mod) {
	if(!action || !obj) {return;}
	var mod = mod ? mod : 'forum.php?mod=topicadmin',
	    extra = !extra ? '' : '&' + extra,
	    pObj = app.AnalysisAll(obj);
	if(typeof pObj !== 'object'){
		pObj ={}
	}
	var cus = pObj.cus ? pObj.cus : '',
		allparam = pObj.param ? pObj.param : {},
		param = allparam.callpar ? allparam.callpar : {},
		fn = allparam.fn ? allparam.fn : '',
		load = allparam.load ? allparam.load : false,
		uid = parseInt(allparam.uid) ? parseInt(allparam.uid) : false,
		verifyLoging = allparam.verifyLoging ? true : false;
		if(cus && (uid == false || uid <= 0 || parseInt(discuz_uid) != uid) && !verifyLoging){
			if(!parseInt(discuz_uid)){
				login.GoLogin();
				return false;
			}
		}
	if(!pid) {
        pid = param.pid ? param.pid : '';
	}
	var tid = param.tid ? param.tid : '',
		fid = param.fid ? param.fid : '',
		cpid = param.cpid ? param.cpid : '';

	if(!pid || !tid || !fid){
		ck8.toast('param_error');
		return false;
	}
	var actionurl = mod + '&action='+ action +'&fid=' + fid + '&tid=' + tid + '&fnpid=' + cpid +'&handlekey=mods&infloat=yes&nopost=yes' + (!pid ? '' : '&topiclist[]=' + pid) + extra + '&r' + Math.random();
	if(!navigator.onLine){
	   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	if(load)
	    ck8.showPreloader('','load');
	ck8.ajax({
		type:'POST',
		url: actionurl +'&inajax=1&fn='+ fn,
		dataType: 'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 200);
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
			if(cus == 'true' && (Docs.indexOf("=='function')") != -1)){
				if(app.Devalscript(Docs,fn,param))return false;
			}
			popup.open(Docs);
			evalscript(Docs);
		},
		error: function(){
			ck8.hidePreloader();
            ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}


function modthreads(obj, optgroup, operation) {
	var operation = !operation ? '' : operation,
	    pObj = app.AnalysisAll(obj);
	if(typeof pObj !== 'object'){
		pObj ={}
	}
	var cus = pObj.cus ? pObj.cus : '',
		allparam = pObj.param ? pObj.param : {},
		param = allparam.callpar ? allparam.callpar : {},
		fn = allparam.fn ? allparam.fn : '',
		load = allparam.load ? allparam.load : false,
		uid = parseInt(allparam.uid) ? parseInt(allparam.uid) : false,
		verifyLoging = allparam.verifyLoging ? true : false;
		if(cus && (uid == false || uid <= 0 || parseInt(discuz_uid) != uid) && !verifyLoging){
			if(!parseInt(discuz_uid)){
				login.GoLogin();
				return false;
			}
		}
    var pid = param.pid ? param.pid : '',
		tid = param.tid ? param.tid : '',
		fid = param.fid ? param.fid : '';
	if(!tid || !fid || !optgroup){
		ck8.toast('param_error');
		return false;
	}
	var actionurl = 'forum.php?mod=topicadmin&action=moderate&fnpid=' + pid + '&fid=' + fid + '&moderate[]=' + tid + '&handlekey=mods&infloat=yes&nopost=yes' + (optgroup != 3 && optgroup != 2 ? '&from=' + tid : '')+ '&operation='+ operation +'&optgroup='+ optgroup;
	if(!navigator.onLine){
	   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	if(load)
	    ck8.showPreloader('','load');
	ck8.ajax({
		type:'POST',
		url: actionurl +'&inajax=1&fn='+ fn,
		dataType: 'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 200);
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
			if(cus == 'true' && (Docs.indexOf("=='function')") != -1)){
				if(app.Devalscript(Docs,fn,param))return false;
			}
			popup.open(Docs);
			evalscript(Docs);
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

function display(_this,el) {
	ck8(el).each(function(index, item){
		if(ck8(item).hasClass('none')){
            ck8(item).removeClass('none').addClass('show')
		}else if(ck8(item).hasClass('show')){
            ck8(item).removeClass('show').addClass('none')
		}
	})
	if(ck8(_this).find('i').hasClass('guiigoapp-xxzk')){
		ck8(_this).html('\u6536\u8d77<i class="icon guiigoapp-xszk"></i>')
	}else if(ck8(_this).find('i').hasClass('guiigoapp-xszk')){
		ck8(_this).html('\u66f4\u591a<i class="icon guiigoapp-xxzk zy-c"></i>')
	}
}


function poll_checkbox(obj) {
	if(obj.checked) {
		p++;
		for (var i = 0; i < Dz('poll').elements.length; i++) {
			var e = Dz('poll').elements[i];
			if(p == max_obj) {
				if(e.name.match('pollanswers') && !e.checked) {
					e.disabled = true;
				}
			}
		}
	} else {
		p--;
		for (var i = 0; i < Dz('poll').elements.length; i++) {
			var e = Dz('poll').elements[i];
			if(e.name.match('pollanswers') && e.disabled) {
				e.disabled = false;
			}
		}
	}
	Dz('pollsubmit').disabled = p <= max_obj && p > 0 ? false : true;
}

function setanswer(tid, pid, from,formhash,fn,param){
	if(!formhash) return false;
	if(!fn) fn = '';
	if(!param) param ={};
	var actionurl = 'forum.php?mod=misc&action=bestanswer&tid=' + tid + '&pid=' + pid + '&from=' + from + '&bestanswersubmit=yes&formhash='+ formhash;
	if(!navigator.onLine){
	   ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;','jinggao');
	   return false;
	}
	ck8.confirm('<div class="c9">\u60a8\u786e\u8ba4\u8981\u628a\u8be5\u56de\u590d\u9009\u4e3a\u201c\u6700\u4f73\u7b54\u6848\u201d\u5417\uff1f</div>', '\u8bbe\u7f6e\u6700\u4f73\u7b54\u6848', function (){
		ck8.showPreloader('','load');
		ck8.ajax({
			type:'POST',
			url: actionurl +'&inajax=1&fn='+ fn,
			dataType: 'xml',
			success: function(s){
				setTimeout(function(){ck8.hidePreloader()}, 200);
				var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
				if(Docs.indexOf("=='function')") != -1){
					if(app.Devalscript(Docs,fn,param))return false;
				}
				popup.open(Docs);
				evalscript(Docs);
			},
			error: function(){
				ck8.hidePreloader();
				ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
			}
		})
	})
}

function checkall(form, prefix, checkall) {
	var checkall = checkall ? checkall : 'chkall';
	count = 0;
	var ch;
	if(form.elements[checkall].checked){
		ch = false;
	}else{
		ch = true;
	}
	for(var i = 0; i < form.elements.length; i++) {
		var e = form.elements[i];
		if(e.name && e.name != checkall && !e.disabled && (!prefix || (prefix && e.name.match(prefix)))) {
			e.checked = ch;
			if(e.checked) {
				count++;
			}
		}
	}
	return count;
}

function submitpostpw(pid, tid) {
	var obj = Dz('postpw_' + pid),url='';
	ck8.showPreloader('\u5904\u7406\u4e2d...');
	app.loadScript('md5',function(){
		safescript('md5_js', function (){
			setcookie('postpw_' + pid, hex_md5(obj.value));
			setTimeout(function(){ck8.hidePreloader()}, 200);
			if(!tid) {
				url = location.href;
			} else {
				url = 'forum.php?mod=viewthread&tid='+ tid +'&viewpid='+ pid;
			}
			app.PageRefresh('','#pid'+ pid,url +'&inajax=1')
		}, 100, 50);
	})
}

function safescript(id, call, seconds, times, timeoutcall, endcall, index) {
	seconds = seconds || 1000;
	times = times || 0;
	var checked = true;
	try {
		if(typeof call == 'function') {
			call();
		} else {
			eval(call);
		}
	} catch(e) {
		checked = false;
	}
	if(!checked) {
		if(!safescripts[id] || !index) {
			safescripts[id] = safescripts[id] || [];
			safescripts[id].push({
				'times':0,
				'si':setInterval(function () {
					safescript(id, call, seconds, times, timeoutcall, endcall, safescripts[id].length);
				}, seconds)
			});
		} else {
			index = (index || 1) - 1;
			safescripts[id][index]['times']++;
			if(safescripts[id][index]['times'] >= times) {
				clearInterval(safescripts[id][index]['si']);
				if(typeof timeoutcall == 'function') {
					timeoutcall();
				} else {
					eval(timeoutcall);
				}
			}
		}
	} else {
		try {
			index = (index || 1) - 1;
			if(safescripts[id][index]['si']) {
				clearInterval(safescripts[id][index]['si']);
			}
			if(typeof endcall == 'function') {
				endcall();
			} else {
				eval(endcall);
			}
		} catch(e) {}
	}
}

function inSwiper(el){
	if(ck8(el).length<=0){
		return;
	}
	new Swiper(el, {
		loop: true,
		autoplay: true,
		pagination: {
			el: '.swiper-pagination',
			bulletClass : 'ck8-bullet',
			bulletActiveClass: 'ck8-bullet-active',
			clickable: true,
		}
	})
	ck8(el).css({
		'visibility': 'visible'
	});
}

function inSwiperTab(el,cut,Offset,W){
	var nW = 0, cW = 0, nWt = 0, nAL = 0;
	if (!Offset) 
		Offset = 'auto';
	if (!W) 
	   W= 0;
   if(ck8(el).length<=0){
	   return;
   }
	new Swiper(el, {
		slidesPerView: cut,
		freeMode: true,
		slidesOffsetAfter: Offset,
		on: {
			init: function() {
				nW = this.slides.eq(0).css('width');
				cW = parseInt(this.$wrapperEl.css('width'));
				for (var i = 0; i < this.slides.length; i++) {
					nWt += parseInt(this.slides.eq(i).css('width')) + W;
				}
			},
			tap: function() {
				if(this.slides[this.clickedIndex])
				nAL = this.slides[this.clickedIndex].offsetLeft;
				this.slides.removeClass('on')
				this.slides.eq(this.clickedIndex).addClass('on')
				this.setTransition(300);
				if(nAL < (cW - parseInt(nW)) / 2){
					this.setTranslate(0)
				}else if(nAL > nWt - (parseInt(nW) + cW) / 2) {
					this.setTranslate(cW - nWt);
				}else{
					this.setTranslate((cW - parseInt(nW)) / 2 - nAL)
				}
			}
		}
	})
	ck8(el).css({
		'visibility': 'visible'
	})
}


function passwordShow(value) {
	if(value==4) {
		Dz('span_password').style.display = '';
		Dz('tb_selectgroup').style.display = 'none';
	} else if(value==2) {
		Dz('span_password').style.display = 'none';
		Dz('tb_selectgroup').style.display = '';
	} else {
		Dz('span_password').style.display = 'none';
		Dz('tb_selectgroup').style.display = 'none';
	}
}

function getgroup(gid) {
	if(gid) {
		ck8.showPreloader('',true);
		ck8.ajax({
			type:'GET',
			url: 'home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid='+ gid,
			dataType:'xml',
			success: function(s){
				setTimeout(function(){ck8.hidePreloader()}, 100);
				s = s.lastChild.firstChild.nodeValue;
				s = s.replace(/<[^>]+>/g,"");
				s = s.replace(/(^\s*)|(\s*$)/g, ""); 
				s = s + ' ';
				Dz('target_names').innerHTML += s;
			}
		})
	}
}




/////////////////////2019-7-29////////////////////////////////

function trim(str) {
	return (str + '').replace(/(\s+)$/g, '').replace(/^\s+/g, '');
}

function _display(id) {
	var obj = Dz(id);
	if(obj.style.visibility) {
		obj.style.visibility = obj.style.visibility == 'visible' ? 'hidden' : 'visible';
	} else {
		obj.style.display = obj.style.display == '' ? 'none' : '';
	}
}

function uploadWindow(recall, type) {
	var type = isUndefined(type) ? 'image' : type;
	UPLOADWINRECALL = recall;
	var url = 'forum.php?mod=misc&action=upload&fid=' + fid + '&type=' + type;
	ck8.ajax({
		type : 'GET',
		url : url + '&inajax=1',
		dataType : 'xml',
		success: function(s){
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
			popup.open(Docs);
			evalscript(Docs); 
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

function uploadWindowload() {
	var str = Dz('uploadattachframe').contentWindow.document.body.innerHTML;
	if(str == '') return;
	var arr = str.split('|');
	if(arr[0] == 'DISCUZUPLOAD' && arr[2] == 0) {
		UPLOADWINRECALL(arr[3], arr[5], arr[6]);
		ck8.closeModal();
	} else {
		var sizelimit = '';
		if(arr[7] == 'ban') {
			sizelimit = '(\u9644\u4ef6\u7c7b\u578b\u88ab\u7981\u6b62)';
		} else if(arr[7] == 'perday') {
			sizelimit = '(\u4e0d\u80fd\u8d85\u8fc7 ' + arr[8] + ' \u5b57\u8282)';
		} else if(arr[7] > 0) {
			sizelimit = '(\u4e0d\u80fd\u8d85\u8fc7 ' + arr[7] + ' \u5b57\u8282)';
		}
		ck8.toast(STATUSMSG[arr[2]] + sizelimit);
	}
}
/////////////////////////////////////////////////////


//////////////2019-7-31//////////////////////
function validate(theform) {
	var theform = ck8(theform).find('form')[0];
	var message = theform.message.value;
	if((Dz('postsubmit').name != 'replysubmit' && !(Dz('postsubmit').name == 'editsubmit' && !isfirstpost) && theform.subject.value == "") || !sortid && !special && ck8.trim(message) == "") {
		ck8.toast('\u62b1\u6b49\uff0c\u60a8\u5c1a\u672a\u8f93\u5165\u6807\u9898\u6216\u5185\u5bb9','shibai');
		return false;
	}
	
	if(theform.subject && mb_strlen(theform.subject.value) > 80) {
		ck8.toast('\u60a8\u7684\u6807\u9898\u8d85\u8fc7\u0020\u0038\u0030\u0020\u4e2a\u5b57\u7b26\u7684\u9650\u5236','shibai');
		return false;
	}
	
	if(in_array(Dz('postsubmit').name, ['topicsubmit', 'editsubmit'])) {
		if(theform.typeid && (theform.typeid.options && theform.typeid.options[theform.typeid.selectedIndex].value == 0) && typerequired) {
			ck8.toast('\u8bf7\u9009\u62e9\u4e3b\u9898\u5bf9\u5e94\u7684\u5206\u7c7b','shibai');
			return false;
		}
		if(theform.sortid && (theform.sortid.options && theform.sortid.options[theform.sortid.selectedIndex].value == 0) && sortrequired) {
			ck8.toast('\u8bf7\u9009\u62e9\u4e3b\u9898\u5bf9\u5e94\u7684\u5206\u7c7b\u4fe1\u606f','shibai');
			return false;
		}
	}
	
	for(i in EXTRAFUNC['validator']) {
		try {
			eval('var v = ' + EXTRAFUNC['validator'][i] + '()');
			if(!v) {
				return false;
			}
		} catch(e) {}
	}

	if(!disablepostctrl && !sortid && !special && ((postminchars != 0 && mb_strlen(message) < postminchars) || (postmaxchars != 0 && mb_strlen(message) > postmaxchars))) {
		ck8.toast('\u60a8\u7684\u5e16\u5b50\u957f\u5ea6\u4e0d\u7b26\u5408\u8981\u6c42\u3002 \n\n \u5f53\u524d\u957f\u5ea6: ' + mb_strlen(message) + ' \u5b57\u8282 \n \u7cfb\u7edf\u9650\u5236: ' + postminchars + ' \u5230 ' + postmaxchars + ' \u5b57\u8282','shibai');
		return false;
	}

	if(isfirstpost && Dz('adddynamic') != null && Dz('adddynamic').checked && Dz('postsave') != null && isNaN(parseInt(Dz('postsave').value)) && (Dz('readperm') != null && Dz('readperm').value || Dz('price') != null && Dz('price').value)) {
		ck8.confirm('\u7531\u4e8e\u60a8\u8bbe\u7f6e\u4e86\u9605\u8bfb\u6743\u9650\u6216\u51fa\u552e\u5e16\uff0c\u60a8\u786e\u8ba4\u8fd8\u8f6c\u64ad\u7ed9\u60a8\u7684\u542c\u4f17\u770b\u5417\uff1f',
			function (){return true;},function (){ return false;}
		)
	}
    return true;
}

//////////////2019-8-11//////////////////////

function showFace(showid, target,obj) {
	if(Dz(showid + '_menu') == null) {
		var faceDiv = document.createElement("div");
		faceDiv.id = showid+'_menu';
		faceDiv.className = 'bqnr-imgs bqnr-wdbj cl';
		var faceul = document.createElement("ul");
		for(i=1; i<31; i++) {
			var faceli = document.createElement("li");
			faceli.innerHTML = '<a><img src="' + STATICURL + 'image/smiley/comcom/'+i+'.gif" onclick="insertFace(\''+showid+'\','+i+', \''+ target +'\')" style="cursor:pointer; position:relative;" /></a>';
			faceul.appendChild(faceli);
		}
		faceDiv.appendChild(faceul);
		Dz(showid).appendChild(faceDiv)
	}
	if(Dz(showid).style.display == 'none'){
		Dz(showid).style.display = 'block';
		ck8(obj).removeClass('zy-c').addClass('zy-be')
	}else{
		Dz(showid).style.display = 'none';
		ck8(obj).removeClass('zy-be').addClass('zy-c')
	}
	ck8(document).off('click', '#'+target).on('click', '#'+target, function(event) {
		Dz(showid).style.display = 'none';
		ck8().removeClass('zy-be').addClass('zy-c')
	})
}

function insertFace(showid, id, target) {
	var faceText = '[em:'+id+':]';
	var m = ck8('#'+target).val()
	ck8('#'+target).val(m + faceText);
    Dz(target).focus();
}

function portal_comment_requote(cid, aid) {
	ck8.showPreloader('','load');
	ck8.ajax({
		type:'POST',
		url:'portal.php?mod=portalcp&ac=comment&op=requote&cid='+cid+'&aid='+aid+'&inajax=1',
		dataType: 'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 200);
			s = s.lastChild.firstChild.nodeValue;
			Dz('message').focus();
            ck8('#message').val(s);
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

/////////////////2019-09-08/////////////////

function showWindowMsgfn(msg,par,param){
	console.log('\u901a\u77e5\u64cd\u4f5c')
	console.log(msg)
	console.log(par)
	console.log(param)
	if(typeof msg === 'object' || typeof par === 'object'){
		if(msg.msg.indexOf('\u6210\u529f') != -1){
			ck8.toast(msg.msg);


		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

function MsgCallRaterange(msg,par,param){
	console.log(msg)
	console.log(par)
	console.log(param)
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u62db\u547c\u5df2\u5ffd\u7565') != -1){
			ck8.toast('\u5ffd\u7565\u6210\u529f');
			app.PageRefresh(false,['gg-kj-sdzh','gg-xx-txzt'])
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}


function showWindow(el, url, res){
	if(!url){
		doane();
		return;
	}
	var fn='showWindowMsgfn',param={id:el};

	ck8.showPreloader('','load');
	ck8.ajax({
		type : res == 'get' ? 'GET' : 'POST',
		url : url + '&inajax=1&fn='+ fn,
		dataType : 'xml',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 100);
			var Docs = app.initAtr(s.lastChild.firstChild.nodeValue);
			if(Docs.indexOf('data-mod="spacecp-poke"') != -1){
				var newDoc = ck8(Docs).find('.list-block').html();
				var _html = '<div class="popup popup-about-js">\
								<div class="content">\
									<header class="tcca-tops bar bar-nav guiigo-nydb bg-c xh-b guiigo-dydb">\
										<a href="javascript:;" class="tops-gblt button button-link pull-left zy-f" onclick="ck8.closeModal();"><i class="icon guiigoapp-guanbi zy-c"></i></a>\
										<h1 class="title zy-h">\u6253\u62db\u547c</h1>\
									</header>\
									<div class="list-block gg-kj-txdz">'+ newDoc +'</div>\
								</div>\
							</div>';
				ck8.popup(_html);
				doane();
				return;
			}

			if(Docs.indexOf("=='function')") != -1){
				
				if(app.Devalscript(Docs,fn,param))return false;
				
			}else if(Docs.indexOf(">window.location.href='") != -1){
				var isfn = false,url='',Msgfn;
				try{
					isfn = typeof(eval(fn)) == 'function';
				}catch(e){
					console.log(e)
				}
				if(isfn){
					var result = Docs.match(/href=(\S*)(<\/script>)$/i);
					if(result[1]){
						url = result[1].match(/'(\S*)'/)[1].replace('&mobile=2','');
					}
					Msgfn = eval(fn)
					Msgfn({'msg':'isjmurl', 'url':url},{}, param)
					return false;
				}
			}
			popup.open(Docs);
			evalscript(Docs);
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
	doane();
}

function doane(event, preventDefault, stopPropagation) {
	var preventDefault = isUndefined(preventDefault) ? 1 : preventDefault;
	var stopPropagation = isUndefined(stopPropagation) ? 1 : stopPropagation;
	e = event ? event : window.event;
	if(!e) {
		e = getEvent();
	}
	if(!e) {
		return null;
	}
	if(preventDefault) {
		if(e.preventDefault) {
			e.preventDefault();
		} else {
			e.returnValue = false;
		}
	}
	if(stopPropagation) {
		if(e.stopPropagation) {
			e.stopPropagation();
		} else {
			e.cancelBubble = true;
		}
	}
	return e;
}

/////////////////2019-08-18/////////////////
function scrollRely(Obj,id){
	if(!id) id= '#comment';
	var type = ck8(Obj).attr('data-type')
	if(type == '1'){
		app.scrollToEnd(id,48)
		ck8(Obj).attr('data-type','2')
		ck8(Obj).find('i').removeClass('guiigoapp-nydbpl').addClass('guiigoapp-neirong')
	}else if(type == '2'){
		ck8('.content')._scrollTo({toT: 0});
		ck8(Obj).attr('data-type','1')
		ck8(Obj).find('i').removeClass('guiigoapp-neirong').addClass('guiigoapp-nydbpl')
	}
}

function MsgCallLogout(msg,par){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u60a8\u5df2\u9000\u51fa\u7ad9\u70b9') != -1){
            ck8.toast('\u60a8\u5df2\u9000\u51fa\uff0c\u8bf7\u7a0d\u540e');
			setTimeout(function(){
				window.location.href = msg.url;
			}, 1500);
		
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

function MsgCallLogin(msg,par,param){
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u4f7f\u7528\u6b64\u0020\u0045\u006d\u0061\u0069\u006c\u0020\u7684\u7528\u6237\u4e0d\u5b58\u5728') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u4f7f\u7528\u6b64\u0045\u006d\u0061\u0069\u006c\u7684\u7528\u6237\u4e0d\u5b58\u5728\uff0c\u8bf7\u68c0\u67e5');
		}else if (msg.msg.indexOf('\u62e5\u6709\u7ad9\u70b9\u8bbe\u7f6e\u6743\u9650\u7684\u7528\u6237') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u4f7f\u7528\u5f53\u524d\u0045\u006d\u0061\u0069\u006c\u7684\u7528\u6237\u4e3a\u7279\u6b8a\u7528\u6237\uff0c\u4e0d\u80fd\u4f7f\u7528\u8be5\u529f\u80fd');
		}else if (msg.msg.indexOf('\u60a8\u586b\u5199\u7684\u8d26\u6237\u8d44\u6599\u4e0d\u5339\u914d') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u60a8\u586b\u5199\u7684\u8d26\u6237\u8d44\u6599\u4e0d\u5339\u914d\uff0c\u8bf7\u68c0\u67e5');
		}else if (msg.msg.indexOf('\u53d6\u56de\u5bc6\u7801\u7684\u65b9\u6cd5\u5df2\u901a\u8fc7\u0020\u0045\u006d\u0061\u0069\u006c\u0020\u53d1\u9001\u5230\u60a8\u7684\u4fe1\u7bb1\u4e2d') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u53d6\u56de\u5bc6\u7801\u7684\u65b9\u6cd5\u5df2\u53d1\u9001\u81f3\u60a8\u90ae\u7bb1\uff0c\u8bf7\u67e5\u6536');
		}else if (msg.msg.indexOf('\u6b22\u8fce\u60a8\u56de\u6765') != -1 && param.type == 'lostpwform'){
			ck8.toast('\u6b22\u8fce\u56de\u6765'+ par.username +'\uff0c\u73b0\u5728\u5c06\u8f6c\u5165\u767b\u5f55\u524d\u9875\u9762');
			setTimeout(function(){
				window.location.href = msg.url;
			}, 2500);
		}else if (msg.msg.indexOf('\u60a8\u8f93\u5165\u7684\u7528\u6237\u540d\u5c0f\u4e8e') != -1 && param.type == 'regpwform'){
			ck8.toast('\u7528\u6237\u540d\u592a\u77ed\u4e86\uff0c\u8bf7\u91cd\u65b0\u8f93\u5165');
		}else if (msg.msg.indexOf('\u611f\u8c22\u60a8\u6ce8\u518c') != -1 && param.type == 'regpwform'){
			ck8.toast(par.username +' \u606d\u559c\u60a8\u6ce8\u518c\u6210\u529f\uff0c\u8bf7\u7a0d\u540e');
			setTimeout(function(){
				window.location.href = msg.url;
			}, 2500);
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

function MsgCallPasswdbk(msg,par,param){
	console.log(msg)
	console.log(par)
	console.log(param)
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u5bc6\u7801\u9a8c\u8bc1\u6210\u529f') != -1){
			ck8.toast('\u5bc6\u7801\u9a8c\u8bc1\u6210\u529f\uff0c\u8bf7\u7a0d\u540e');
			setTimeout(function(){
				window.location.href = msg.url;
			}, 2500);
		}else if (msg.msg.indexOf('\u652f\u4ed8\u6210\u529f') != -1){
			ck8.toast('\u652f\u4ed8\u6210\u529f\uff0c\u8bf7\u7a0d\u540e');
			setTimeout(function(){
				window.location.href = msg.url;
			}, 2500);
		}else if (msg.msg.indexOf('\u9a8c\u8bc1\u6210\u529f\uff0c\u73b0\u5728\u8fdb\u5165\u67e5\u770b\u9875\u9762') != -1){
			ck8.toast('\u5bc6\u7801\u9a8c\u8bc1\u6210\u529f\uff0c\u8bf7\u7a0d\u540e');
			setTimeout(function(){
				window.location.href = msg.url;
			}, 2500);
		}else if (msg.msg.indexOf('\u60a8\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u6b63\u786e') != -1){
			ck8.toast('\u60a8\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u6b63\u786e\uff0c\u8bf7\u91cd\u65b0\u8f93\u5165');
		}else if (msg.msg.indexOf('\u60a8\u8f93\u5165\u7684\u7f51\u7ad9\u767b\u5f55\u5bc6\u7801\u4e0d\u6b63\u786e') != -1){
			ck8.toast('\u60a8\u8f93\u5165\u7684\u5bc6\u7801\u4e0d\u6b63\u786e\uff0c\u8bf7\u91cd\u65b0\u8f93\u5165');
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

function MsgCallReport(msg,par){
	console.log(msg)
	if(typeof msg === 'object' || typeof par === 'object'){
		if (msg.msg.indexOf('\u4e3e\u62a5\u6210\u529f') != -1){
            ck8.toast(msg.msg);
		}else {
			ck8.toast(msg.msg,'shibai');
		}
	}else{
		ck8.toast('\u672a\u77e5\u9519\u8bef','shibai');
	}
}

/////////////2019-9-19///////////
function infinite(TabId) {
	if(!TabId) TabId ='.type-scroll';
	var url = $(TabId).attr('data-url'),
		page = (parseInt($(TabId).attr('data-page')) +1),
		islod = $(TabId).attr('data-islod');
	if(!url || !page) return;
	if(islod == 'true') return;
	$(TabId).attr('data-islod','true');
	ck8(TabId).find('.guiigo-zdjz').show().html('<div class="preloader preloader-load"></div><span class="loading">\u52a0\u8f7d\u4e2d\u002e\u002e\u002e</span>')
	ck8(TabId).find('.loadpage').hide()
	$.ajax({
		type:'GET',
		url: url +'&page='+ page +'&inajax=1',
		dataType: 'xml',
		success: function(res){
			var res = app.initAtr(res.lastChild.firstChild.nodeValue),
				doc = $.getDom(res),
				dataObj = doc.find(TabId),
				_url = dataObj.attr('data-url'),
				_pages = parseInt(dataObj.attr('data-pages')),
				_page = parseInt(dataObj.attr('data-page')),
				_ppp = parseInt(dataObj.attr('data-ppp'));
			$(TabId).attr('data-url',_url).attr('data-pages',_pages).attr('data-page',_page).attr('data-ppp',_ppp)
			if(Math.ceil(_pages / _ppp) < _page || _page == (page+1)){
				$(TabId).attr('data-islod','true')
				ck8(TabId).find('.guiigo-zdjz').html('<span class="loading">\u6ca1\u6709\u66f4\u591a\u4e86</span>')
				ck8(TabId).find('.loadpage').remove()
				return;
			}
			ck8(TabId).find('.list-container').append($(dataObj).find('.list-container').html());
			$(TabId).attr('data-islod','false')
			ck8(TabId).find('.guiigo-zdjz').hide()
		    ck8(TabId).find('.loadpage').show()
		}
	}) 
}

function showdistrict(container, elems, totallevel, changelevel, containertype) {
	var getdid = function(elem) {
		var op = elem.options[elem.selectedIndex];
		return op['did'] || op.getAttribute('did') || '0';
	};
	var pid = changelevel >= 1 && elems[0] && Dz(elems[0]) ? getdid(Dz(elems[0])) : 0;
	var cid = changelevel >= 2 && elems[1] && Dz(elems[1]) ? getdid(Dz(elems[1])) : 0;
	var did = changelevel >= 3 && elems[2] && Dz(elems[2]) ? getdid(Dz(elems[2])) : 0;
	var coid = changelevel >= 4 && elems[3] && Dz(elems[3]) ? getdid(Dz(elems[3])) : 0;
	var url = "home.php?mod=misc&ac=ajax&op=district&container="+container+"&containertype="+containertype
		+"&province="+elems[0]+"&city="+elems[1]+"&district="+elems[2]+"&community="+elems[3]
		+"&pid="+pid + "&cid="+cid+"&did="+did+"&coid="+coid+'&level='+totallevel+'&handlekey='+container+'&inajax=1'+(!changelevel ? '&showdefault=1' : '');
	ajaxget(false,url, container);
}

function fileup(obj,id){
	var reads = new FileReader();
	reads.readAsDataURL(obj.files[0])
	reads.onload = function(){
		ck8(id).attr('src',this.result)
	}
}

function updatestring(str1, str2, clear) {
	str2 = '_' + str2 + '_';
	return clear ? str1.replace(str2, '') : (str1.indexOf(str2) == -1 ? str1 + str2 : str1);
}
function toggle_collapse(objname, noimg, complex, lang) {
	var obj = Dz(objname);
	if(obj) {
		obj.style.display = obj.style.display == '' ? 'none' : '';
		var collapsed = getcookie('collapse');
		collapsed = updatestring(collapsed, objname, !obj.style.display);
		setcookie('collapse', collapsed, (collapsed ? 2592000 : -2592000));
	}
	if(!noimg) {
		var img = Dz(objname + '_img');
		if(img.tagName != 'IMG') {
			if(img.className.indexOf('_yes') == -1) {
				img.className = img.className.replace(/_no/, '_yes');
				if(lang) {
					img.innerHTML = lang[0];
				}
			} else {
				img.className = img.className.replace(/_yes/, '_no');
				if(lang) {
					img.innerHTML = lang[1];
				}
			}
		} else {
			img.src = img.src.indexOf('_yes.gif') == -1 ? img.src.replace(/_no\.gif/, '_yes\.gif') : img.src.replace(/_yes\.gif/, '_no\.gif');
		}
		img.blur();
	}
	if(complex) {
		var objc = Dz(objname + '_c');
		if(objc) {
			objc.className = objc.className == 'umh' ? 'umh umn' : 'umh';
		}
	}
}

function passwordTabtype(_this,el){
	var ptype = ck8(el).attr('type');
	if(ptype == 'password'){
		ck8(el).attr('type','text')
		ck8(_this).find('i').removeClass('guiigoapp-zhengyan').addClass('guiigoapp-biyan')
	}else{
		ck8(el).attr('type','password')
		ck8(_this).find('i').removeClass('guiigoapp-biyan').addClass('guiigoapp-zhengyan')
	}
}

function getMore(pageid,type){
	var scrollPreloader = {
		1:'<span class="loading">\u4e0a\u62c9\u52a0\u8f7d\u66f4\u591a</span>',
		2:'<div class="preloader preloader-load"></div><span class="loading">\u52a0\u8f7d\u4e2d\u002e\u002e\u002e</span>',
		3:'<span class="loading">\u5df2\u7ecf\u5230\u5e95\u4e86</span>',
		4:'<span class="loading">\u65e0\u76f8\u5173\u6570\u636e</span>',
	};
	if(!pageid){
		return;
	}
	var loadpageObj = ck8('#loadpage_'+pageid);
	var page = loadpageObj.attr('data-page');
	var orderid = loadpageObj.attr('data-orderid');
	var loadstate = loadpageObj.attr('data-loadstate');
	var scrollTop = loadpageObj.attr('data-scrollTop');
	var scrollTopEnd = loadpageObj.attr('data-scrollTopEnd');
	var url = loadpageObj.attr('data-url');
	
	if(!type && scrollTop){
		ck8('.content').scrollTop(parseInt(scrollTop))
	}
	
	if(page != '0' && !type){
		return;
	}
	if(pageid != orderid){
		return;
	}
	if(loadstate == '1'){
		ck8('#scroll-preloader_'+pageid).html(scrollPreloader[1]);
	}
	if(loadstate == '2' || loadstate == '3' || loadstate == '4'){
		return;
	}
	if(scrollTopEnd == '2'){
		return;
	}

	loadpageObj.attr('data-loadstate',2);
	ck8('#scroll-preloader_'+pageid).html(scrollPreloader[2]);
    var apiurl = 'plugin.php?id=guiigo_manage:api&api=PostList&act=getIndexList';
	if(url){
		apiurl = url;
	}
	if(!orderid){
		orderid = '';
	}

	page = parseInt(page) +1;
	ck8.ajax({
		type : 'GET',
		url :  SITEURL+'/'+apiurl + '&page='+ page +'&orderid='+orderid,
		dataType : 'html',
		success: function(s){
			var Docs = app.initAtr(s);
			loadpageObj.attr('data-page',page);
            if(page == 1 && !Docs){
				loadpageObj.attr('data-loadstate',4);
				ck8('#scroll-preloader_'+pageid).html(scrollPreloader[4]);
				return;
			}
            if(page >=2 && !Docs){
				loadpageObj.attr('data-loadstate',3);
				ck8('#scroll-preloader_'+pageid).html(scrollPreloader[3]);
				return;
			}
            if(Docs){
				loadpageObj.attr('data-loadstate',1);
				ck8('#scroll-preloader_'+pageid).html(scrollPreloader[1]);
				loadpageObj.find('.appendpage').append(Docs)
            }
			if(page == 1){
				app.lazyLoad('',true)
			}
			app.lazyLoad()
			ck8.refreshScroller();
			if(Docs.indexOf('<div id="nolist"') != -1){
				loadpageObj.attr('data-scrollTopEnd',2);
				ck8('#scroll-preloader_'+pageid).hide();
			}
		},
		error: function(){
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

function SwitchStyle(obj,style){
	var hrefstyl = ck8('#stylefile').attr('href');
	if(hrefstyl){
		var url = hrefstyl.substring(0,hrefstyl.indexOf('guiigo-colour-'));
		url = url + 'guiigo-colour-' + style + '.css?' +hash('guiigocolour', 6);
		ck8('#stylefile').attr('href',url);
	}

	var navstyl = ck8('nav').find('img');
	if(navstyl.length){
		for(var i=0; i < navstyl.length; i++){
			var imgurl = ck8(navstyl[i]).attr('src');
			var reg =/(images\/[^{]*\/)/g;
			imgurl = imgurl.replace(reg,'images/'+style+'/');
            imgurl = imgurl+'?'+hash('guiigocolour', 6);
			ck8(navstyl[i]).attr('src',imgurl);
		}
	}
	ck8('#styleall').find('a').removeClass('on')
	if(obj){
		ck8(obj).addClass('on')
		localStorage.setItem('styledata_'+discuz_uid,style);
	}else{
		var datastyle = ck8('#styleall').find('a');
		if(datastyle.length){
			for(var i=0; i < datastyle.length; i++){
				var ds = ck8(datastyle[i]).attr('data-style');
                if(ds == style){
					ck8(datastyle[i]).addClass('on')
					break;
				}
			}
		}
	}
}

function homeSwitchStyle(obj,homestyle){
	ck8.showPreloader('','load');
	ck8.ajax({
		type : 'GET',
		url : SITEURL+'/plugin.php?id=guiigo_manage:api&api=Style&act=setHomeStyle&style='+homestyle,
		dataType : 'json',
		success: function(s){
			setTimeout(function(){ck8.hidePreloader()}, 100);
			if(s.code == 1){
				ck8.toast(s.msg,'shibai');
				ck8('#kjstyleall').find('a').removeClass('on')
				if(obj){
					ck8(obj).addClass('on')
				}else{
					var datastyle = ck8('#kjstyleall').find('a');
					if(datastyle.length){
						for(var i=0; i < datastyle.length; i++){
							var ds = ck8(datastyle[i]).attr('data-style');
				            if(ds == homestyle){
								ck8(datastyle[i]).addClass('on')
								break;
							}
						}
					}
				}
				ck8('.gg-kj-kjdb').attr('class','gg-kj-kjdb gg-kjbg-'+homestyle)
				ck8('.panel-yhxx').attr('class','panel-yhxx gg-kjbg-'+homestyle)
			}else {
	           ck8.toast(s.msg,'shibai');
			}
		},
		error: function(){
			ck8.hidePreloader();
			ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
		}
	})
}

function initSwitchStyle(){
	var style = localStorage.getItem('styledata_'+discuz_uid);
	if(style){
	   SwitchStyle(false,style)
	}
}

function copy(self,text){
	var msg = '\u94fe\u63a5\u5df2\u590d\u5236\u5230\u526a\u8d34\u677f';
	var u = window.location.href.replace('&mobile=2','');
	if(!text){
		cptext = u;
	}else{
		cptext = text;
	}
	var cptextid = ck8(self).attr('id')
	if(!cptext){
		ck8.toast('\u94fe\u63a5\u590d\u5236\u5931\u8d25');
		return;
	}
	app.loadScript('clipboard.min',function(){
		var clipboard = new Clipboard('#'+cptextid, {
			text: function (e) {
				setTimeout(function(){
					ck8.toast(msg);
				}, 600);
				return cptext;
			}
		})
	})
}

function getShareData(el,imgid){
	if(!imgid){
		imgid = '.content';
	}
	var imgs = share_img;
	var picurl = ck8(imgid).find('img');
	var title = ck8(el).html();
	var link = window.location.href.replace('&mobile=2','');
	for(var i=0; i < picurl.length; i++){
		if(picurl[i].naturalWidth > 80 || picurl[i].naturalHeight > 80){
		    imgs = picurl[i].src;
			break;
		}
	}
	return {
		title: title ? title : share_title,
		desc: title ? title : share_title,
		link:link,
		imgUrl: imgs,
	};
}

function nativeShare(config) {
    var qApiSrc = {
        lower: "http://3gimg.qq.com/html5/js/qb.js",
        higher: "http://jsapi.qq.com/get?api=app.share"
    };
    var bLevel = {
        qq: {forbid: 0, lower: 1, higher: 2},
        uc: {forbid: 0, allow: 1}
    };
    var UA = navigator.appVersion;
    var isqqBrowser = (UA.split("MQQBrowser/").length > 1) ? bLevel.qq.higher : bLevel.qq.forbid;
    var isucBrowser = (UA.split("UCBrowser/").length > 1) ? bLevel.uc.allow : bLevel.uc.forbid;
    var version = {
        uc: "",
        qq: ""
    };
	
    var isWeixin = false;
    config = config || {};
    this.url = config.link || '';
    this.title = config.title || '';
    this.desc = this.title;
    this.img = config.imgUrl || '';
    this.img_title = config.title || document.title || '';
	this.from = this.title || '';
    this.ucAppList = {
        sinaWeibo: ['kSinaWeibo', 'SinaWeibo', 11, '{lang ck8_share:lang_002}'],
        weixin: ['kWeixin', 'WechatFriends', 1, '{lang ck8_share:lang_003}'],
        weixinFriend: ['kWeixinFriend', 'WechatTimeline', '8', '{lang ck8_share:lang_004}'],
        QQ: ['kQQ', 'QQ', '4', '{lang ck8_share:lang_005}'],
        QZone: ['kQZone', 'QZone', '3', '{lang ck8_share:lang_006}']
    };
    this.share = function (to_app) {
        var title = this.title, url = this.url, desc = this.desc, img = this.img, img_title = this.img_title, from = this.from;
        if (isucBrowser) {
            to_app = to_app == '' ? '' : (platform_os == 'iPhone' ? this.ucAppList[to_app][0] : this.ucAppList[to_app][1]);
            if (to_app == 'QZone') {
                B = "mqqapi://share/to_qzone?src_type=web&version=1&file_type=news&req_type=1&image_url="+img+"&title="+title+"&description="+desc+"&url="+url+"&app_name="+from;
                k = document.createElement("div"), k.style.visibility = "hidden", k.innerHTML = '<iframe src="' + B + '" scrolling="no" width="1" height="1"></iframe>', document.body.appendChild(k), setTimeout(function () {
                    k && k.parentNode && k.parentNode.removeChild(k)
                }, 5E3);
            }
            if (typeof(ucweb) != "undefined") {
                ucweb.startRequest("shell.page_share", [title, title, url, to_app, "", "@" + from, ""])
            } else {
                if (typeof(ucbrowser) != "undefined") {
                    ucbrowser.web_share(title, title, url, to_app, "", "@" + from, '')
                } else {
                }
            }
        } else {
            if (isqqBrowser && !isWeixin) {
                to_app = to_app == '' ? '' : this.ucAppList[to_app][2];
                var ah = {
                    url: url,
                    title: title,
                    description: desc,
                    img_url: img,
                    img_title: img_title,
                    to_app: to_app,
                    cus_txt: "\u8bf7\u8f93\u5165\u6b64\u65f6\u6b64\u523b\u60f3\u8981\u5206\u4eab\u7684\u5185\u5bb9"
                };
                ah = to_app == '' ? '' : ah;
                if (typeof(browser) != "undefined") {
                    if (typeof(browser.app) != "undefined" && isqqBrowser == bLevel.qq.higher) {
                        browser.app.share(ah)
                    }
                } else {
                    if (typeof(window.qb) != "undefined" && isqqBrowser == bLevel.qq.lower) {
                        window.qb.share(ah)
                    } else {
                    }
                }
            } else {
            }
        }
    };
    this.isloadqqApi = function () {
        if (isqqBrowser) {
            var b = (version.qq < 5.4) ? qApiSrc.lower : qApiSrc.higher;
            var d = document.createElement("script");
            var a = document.getElementsByTagName("body")[0];
            d.setAttribute("src", b);
            a.appendChild(d)
        }
    };
    this.getPlantform = function () {
        ua = navigator.userAgent;
        if ((ua.indexOf("iPhone") > -1 || ua.indexOf("iPod") > -1)) {
            return "iPhone"
        }
        return "Android"
    };
    this.is_weixin = function () {
        var a = UA.toLowerCase();
        if (a.match(/MicroMessenger/i) == "micromessenger") {
            return true
        } else {
            return false
        }
    };
    this.getVersion = function (c) {
        var a = c.split("."), b = parseFloat(a[0] + "." + a[1]);
        return b
    };
    this.init = function () {
        platform_os = this.getPlantform();
        version.qq = isqqBrowser ? this.getVersion(UA.split("MQQBrowser/")[1]) : 0;
        version.uc = isucBrowser ? this.getVersion(UA.split("UCBrowser/")[1]) : 0;
        isWeixin = this.is_weixin();
        if ((isqqBrowser && version.qq < 5.4 && platform_os == "iPhone") || (isqqBrowser && version.qq < 5.3 && platform_os == "Android")) {
            isqqBrowser = bLevel.qq.forbid
        } else {
            if (isqqBrowser && version.qq < 5.4 && platform_os == "Android") {
                isqqBrowser = bLevel.qq.lower
            } else {
                if (isucBrowser && ((version.uc < 10.2 && platform_os == "iPhone") || (version.uc < 9.7 && platform_os == "Android"))) {
                    isucBrowser = bLevel.uc.forbid
                }
            }
        }
        this.isloadqqApi();
        if (isqqBrowser || isucBrowser){}
    };
    this.init();
    var share = this;
    var items = document.getElementsByClassName('nativeShare');
    for (var i=0;i<items.length;i++) {
        items[i].onclick = function(){
            share.share(this.getAttribute('data-app'));
        }
    }
	return this;
}

function webShare(config){
	ck8('.weixin').on('click',function () {
		setTimeout(function(){
		    ck8.toast('\u8bf7\u5728\u0041\u0050\u0050\u6216\u5fae\u4fe1\u4e2d\u4f7f\u7528','shibai');
		}, 300);
	});
	ck8('.weixin_timeline').on('click',function () {
		setTimeout(function(){
		    ck8.toast('\u8bf7\u5728\u0041\u0050\u0050\u6216\u5fae\u4fe1\u4e2d\u4f7f\u7528','shibai');
		}, 300);
	});
	ck8('.qq').on('click',function () {
		var qqurl = 'http://connect.qq.com/widget/shareqq/index.html?url='+config.link+'&desc='+config.desc+'&summary=&title='+config.title+'&site=&pics='+config.imgUrl;
		window.location.href = qqurl;
	});
	ck8('.weibo').on('click',function () {
		var weibourl = 'http://service.weibo.com/share/share.php?url='+config.link+'&appkey=&title='+config.title+'&pic='+config.imgUrl+'&language=zh_cn';
		window.location.href = weibourl;
	});
	ck8('.qzone').on('click',function () {
		var qzoneurl = 'http://openmobile.qq.com/api/check2?page=qzshare.html&loginpage=loginindex.html&logintype=qzone&url='+config.link+'&summary='+config.title+'&desc='+config.desc+'&title='+config.title+'&imageUrl='+config.imgUrl+'&successUrl=&failUrl=&callbackUrl=&sid=';
		window.location.href = qzoneurl;
	});
}

function wxshareJssdkAjax(config){
	config.link = location.href.split('#')[0];
	app.loadScript('jweixin-1.4.0',function(){
		ck8.ajax({
			url:SITEURL+'/plugin.php?id=guiigo_manage:api&api=wxshare&act=getwxshare&url='+ encodeURIComponent(config.link),
			dataType: "json",
			type: "GET",
			success:function(e){
				if(e.code == 1){
					wx.config({
						debug:false,
						appId:e.data.appid,
						timestamp:e.data.timestamp,
						nonceStr:e.data.nonceStr,
						signature:e.data.signature,
						jsApiList:[
							'onMenuShareTimeline',
							'onMenuShareAppMessage',
							'onMenuShareQQ',
							'onMenuShareWeibo',
							'onMenuShareQZone',
							'getLocation',
							'openLocation'
						]
					});
					wx.ready(function(){
						wx.onMenuShareAppMessage(config);
						wx.onMenuShareQQ(config);
						wx.onMenuShareWeibo(config);
						wx.onMenuShareQZone(config);
						wx.onMenuShareTimeline(config);
					});
					ck8('.nativeShare').on('click',function(){
						ck8('.share-layer').show();
					})
					ck8('.share-layer').on('click',function(){
						ck8('.share-layer').hide();
					})
				}else{
					ck8.toast('\u8bf7\u6c42\u5931\u8d25','shibai');
				}
			}
		})
	})
}

function getData(){
	var title = '';
	if(ck8('#share_title')){
		title = ck8('#share_title').html();
	}
	var link = window.location.href.replace('&mobile=2','');
	return {
		title: title ? title : share_title,
		link:link,
	};
}

function miniProgramwxJssdk(){
	var FXCONFIG = getData();
	app.loadScript('jweixin-1.4.0',function(){
		if (/MicroMessenger/i.test(navigator.userAgent)) {
			wx.miniProgram.getEnv((res)=>{
				if (res.miniprogram) {
					wx.miniProgram.postMessage({
					     data: FXCONFIG,
					 });
					if(ck8('#miniProgramlogin')){
						ck8('#miniProgramlogin').on('click',function () {
							wx.miniProgram.navigateTo({url: '/pages/login/login'});
						});
					}
				}
			})
		}
	})
}

var initcommon = function(){
    login.init();
    pageScrollTop.init();
	dialog.init();
	formdialog.init();
	initSwitchStyle();
	miniProgramwxJssdk();
}