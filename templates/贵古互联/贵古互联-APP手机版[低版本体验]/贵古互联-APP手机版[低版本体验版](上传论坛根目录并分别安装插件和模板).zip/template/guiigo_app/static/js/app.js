ck8(function(){
	ck8(window).on("pageLoadError", function(e) {
		ck8.toast('&#24403;&#21069;&#32593;&#32476;&#24322;&#24120;', 'jinggao');
	})
	ck8(document).on("pageInit", function(e, pageId, Dom) {
		var mod = Dom.attr('data-mod');
		initcommon()
		app.init('#' + pageId)
		app.loadStyle('cssswiper-4.3.3.min');
		switch (mod) {
			case 'index': //��ҳ 
				app.loadScript('jsswiper-4.3.3.min', function() {
					if(ck8('#ck8-nav').length){
						var setactiveIndex = 1;
						if(window.sessionStorage.getItem('setactiveIndex')){
							setactiveIndex = window.sessionStorage.getItem('setactiveIndex');
						}
						var style = localStorage.getItem('styledata_'+discuz_uid);
						var color = {
							sy:'208,208,208',
							sd:'219,40,28',
							s1:'255, 152, 0',
							s2:'75,159,254',
							s3:'255,202,78',
							s4:'219,40,28',
							s5:'255, 152, 0',
							s6:'7,193,96',
							s7:'25,187,255',
							s8:'253,97,145',
							s9:'114,88,246',
						};
						var stylecolor = color[default_style];
						if(style){
						  stylecolor = color[style];
						}
						var tSpeed = 300;//����ʱ��
						var slidesView = 6;//Ĭ����ʾ����
						var navSwiper = new Swiper('#ck8-nav', {
							initialSlide : setactiveIndex,//Ĭ����ʾ�ڼ���TAB
							slidesPerView:slidesView,
							freeMode: true,
							on: {
								init: function() {
									ck8('#ck8-nav').find('.navbar').show();
									navSlideWidth = this.slides.eq(0).css('width');
									bar = this.$(this.el).find('.navbar');
									bar.css('width', navSlideWidth);
									if(this.activeIndex ==0){
										this.slides.eq(0).find('span').css('color','rgb('+ stylecolor +')');
									}
									bar.transition(tSpeed);
									bar.find('.color').css('background','rgb('+ stylecolor +')');
									navSum = this.slides[this.slides.length - 1].offsetLeft;
									clientWidth = parseInt(this.$(this.wrapperEl).css('width'));
									navWidth = 0;
									for (i = 0; i < this.slides.length; i++) {
										navWidth += parseInt(this.slides.eq(i).css('width'));
									}
								}
							}
						});
						
						var pageSwiper = new Swiper('#nav-page', {
							initialSlide : setactiveIndex,//Ĭ����ʾ�ڼ���TAB
							longSwipes: false,
							watchSlidesProgress: true,
							resistanceRatio: 0,
							on: {
								init: function() {
									if(setactiveIndex == 0){
										// ����activeIndex
										window.sessionStorage.setItem('setactiveIndex', this.activeIndex)
										getMore(ck8(this.slides[this.activeIndex]).attr('data-orderid'));
									}
									ck8('#nav-page').find('.swiper-slide-active').css({'minHeight':Dom[0].clientHeight-100 +'px'})
								},
								touchMove: function() {
									progress = this.progress;
									bar.transition(0);
									bar.transform('translateX(' + navSum * progress + 'px)');
									for (i = 0; i < this.slides.length; i++) {
										slideProgress = this.slides[i].progress;
										if (Math.abs(slideProgress) < 1) {
											var rgbs = stylecolor.split(',');
											r = Math.floor((rgbs[0] - 50) * (1 - Math.pow(Math.abs(slideProgress), 2)) + 50);
											g = Math.floor((rgbs[1] - 50) * (1 - Math.pow(Math.abs(slideProgress), 2)) + 50);
											b = Math.floor((rgbs[2] - 50) * (1 - Math.pow(Math.abs(slideProgress), 2)) + 50);
											navSwiper.slides.eq(i).find('span').css('color', 'rgba(' + r + ',' + g + ',' + b + ',1)');
										}
									}
								},
								transitionStart: function() {
									activeIndex = this.activeIndex;
									activeSlidePosition = navSwiper.slides[activeIndex].offsetLeft;
									bar.transition(tSpeed);
									bar.transform('translateX(' + activeSlidePosition + 'px)');
									navSwiper.slides.eq(activeIndex).find('span').transition(tSpeed)
									navSwiper.slides.eq(activeIndex).find('span').css('color', 'rgb('+ stylecolor +')');
									if (activeIndex > 0) {
										navSwiper.slides.eq(activeIndex - 1).find('span').transition(tSpeed);
										navSwiper.slides.eq(activeIndex - 1).find('span').css('color', '#888888');
										
									}
									if (activeIndex < this.slides.length) {
										navSwiper.slides.eq(activeIndex + 1).find('span').transition(tSpeed);
										navSwiper.slides.eq(activeIndex + 1).find('span').css('color', '#888888');
										
									}
									navActiveSlideLeft = navSwiper.slides[activeIndex].offsetLeft;
									navSwiper.setTransition(tSpeed);
									if (navActiveSlideLeft < (clientWidth - parseInt(navSlideWidth)) / 2) {
										navSwiper.setTranslate(0)
									} else if (navActiveSlideLeft > navWidth - (parseInt(navSlideWidth) + clientWidth) / 2) {
										navSwiper.setTranslate(clientWidth - navWidth);
									} else {
										navSwiper.setTranslate((clientWidth - parseInt(navSlideWidth)) / 2 - navActiveSlideLeft);
									}
									// ����activeIndex
									window.sessionStorage.setItem('setactiveIndex', activeIndex)
									getMore(ck8(this.slides[activeIndex]).attr('data-orderid'));
								},
							}
						});
						navSwiper.on('tap', function(e) {
							clickIndex = this.clickedIndex;
							clickSlide = this.slides.eq(clickIndex);
							pageSwiper.slideTo(clickIndex, 0);
							this.slides.find('span').css('color', '#888888');
							clickSlide.find('span').css('color', 'rgb('+ stylecolor +')');
						})
					}else{
						getMore('nocontent')
					}
					//index-scroll
					ck8('.index-scroll').on('infinite', function() {
						var torderid ='nocontent';//�޵���ʱ
						if(pageSwiper){
							torderid = ck8(pageSwiper.slides[pageSwiper.activeIndex]).attr('data-orderid');
						}
						getMore(torderid,true);
					})
					ck8('.content').on('scroll',function(e){
						var orderids ='nocontent';//�޵���ʱ
						var hdoc = ck8(this).scrollTop();
						if(pageSwiper){
							orderids = ck8(pageSwiper.slides[pageSwiper.activeIndex]).attr('data-orderid')
						}
						ck8('#loadpage_'+orderids).attr('data-scrollTop',hdoc);
					})
				})
				break;
			case 'guide'://����
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-guide', 5,10,.1)
				})
				ck8('.guide-scroll').on('infinite', function() {
					app.LoadPageForumView('.guide-scroll')
				})
				break;
			case 'discuz': //��̳��ҳ
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-discuz', 2,10,.1)
				})
				ck8('.discuz-scroll').on('infinite', function() {
					app.LoadPageForumView('.discuz-scroll')
				})
				break;	
			case 'space-profile-my': //��������
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiper('.guiigo-hdmka')
				})
				break;
			case 'space-profile': //�û��ռ�
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-profile', 5,10,.1)
				})
				if(typeof ShareAllprofile == 'function'){
					setTimeout(function(){
					   ShareAllprofile()
					}, 300);
				}
				break;
			case 'viewthread': //��������
				if(typeof ShareAllview == 'function'){
					setTimeout(function(){
					   ShareAllview()
					}, 300);
				}
				ck8('.post-scroll').on('infinite', function() {
					app.LoadPageForumView('.post-scroll')
				})
				break;
			case 'trade-info': //��Ʒ����
				if(typeof ShareAlltrade == 'function'){
					setTimeout(function(){
					   ShareAlltrade()
					}, 300);
				}
				break;
			case 'group': //Ȧ����ҳ
				app.loadScript('jsswiper-4.3.3.min', function() {
					var swiperBg = new Swiper(".gg-qz-hdbg", {
						effect: "fade",
						fadeEffect: {
							crossFade: !1
						}
					});
					new Swiper(".show-swiper", {
						slidesPerView: "auto",
						watchSlidesProgress: !0,
						slidesOffsetBefore: 37,
						spaceBetween: 20,
						resistanceRatio: 1,
						controller: {
							control: swiperBg
						},
						on: {
							progress: function(b) {
								for (i = 0; i < this.slides.length; i++) slide = this.slides.eq(i),
									slideProgress = this.slides[i].progress,
									prevIndent = 4 == i ? .3228 : .0898,
									scale = 1 > Math.abs(slideProgress + prevIndent) ? .1 * (1 - Math.abs(slideProgress + prevIndent)) +
									1 : 1,
									slide.find(".gg-qz-hdys").transform("scale3d(" + scale + "," + scale + ",1)")
							},
							setTransition: function(b) {
								for (var a = 0; a < this.slides.length; a++) this.slides.eq(a).find(".gg-qz-hdys").transition(b)
							},
							touchMove: function() {
								this.controller.control = .01 > this.progress ? "" : swiperBg
							},
							touchEnd: function() {
								-1515 > this.translate && alert("")
							}
						}
					});
					new Swiper('.gg-qz-rmqz', {
						slidesPerView: 4.9,
						freeMode: true
					});
					ck8('.gg-qz-rmqz,.show-swiper,.gg-qz-hdbg').css({
						'visibility': 'visible'
					});
				})
				
				ck8('.group-scroll').on('infinite', function() {
					getMore('group',true)
				})
				break;
			case 'forumdisplay': //�����б�
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-forumdisplay', 5,10,6)
				})
				ck8('.thread-scroll').on('infinite', function() {
					app.LoadPageForumView('.thread-scroll')
				})
				break;
			case 'search': //��������
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-forumdisplay', 5,10,6)
				})
				ck8('.search-scroll').on('infinite', function() {
					app.LoadPageForumView('.search-scroll')
				})
				break;
			case 'space_notice': //����ҳ��
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacenotice', 6,10,.1)
				})
				ck8('.ontice-scroll').on('infinite', function() {
					app.LoadPageForumView('.ontice-scroll')
				})
				break;
			case 'space_pm': //��Ϣ
				ck8(document).on('infinite', '.pm-scroll',function() {
					var TabId ='.pm-scroll',
						url = ck8(TabId).attr('data-url'),
						page = (parseInt(ck8(TabId).attr('data-page')) - 1),
						islod = ck8(TabId).attr('data-islod');
					if(!url || !page) return;
					if(islod == 'true') return;
					ck8(TabId).attr('data-islod','true');
					ck8.ajax({
						type:'GET',
						url: url +'&page='+ page +'&inajax=1',
						dataType: 'xml',
						success: function(res){
							var res = app.initAtr(res.lastChild.firstChild.nodeValue),
								doc = ck8.getDom(res),
								dataObj = doc.find(TabId),//ҳ������dom����
								_url = dataObj.attr('data-url'),
								_pages = parseInt(dataObj.attr('data-pages')),//��ҳ����
								_page = parseInt(dataObj.attr('data-page')),//��ǰ�Ѿ����ص�ҳ��
								_ppp = parseInt(dataObj.attr('data-ppp'));//ÿҳ����
							ck8(TabId).attr('data-url',_url).attr('data-pages',_pages).attr('data-page',_page).attr('data-ppp',_ppp)
							if(Math.ceil(_pages / _ppp) < _page || _page == (page+1)){
								ck8(TabId).attr('data-islod','true')
								ck8.detachInfiniteScroll(ck8(TabId))
								return false;
							}
							ck8('#pm_ul').prepend(ck8(dataObj).find('#pm_ul').html());
							ck8(TabId).attr('data-islod','false')
							ck8.refreshScroller()
						}
					})
				})
				ck8('.pms-scroll').on('infinite', function() {
					app.LoadPageForumView('.pms-scroll')
				})
				break;
			case 'type': //ȫ��Ȧ��
				ck8('.type-scroll').on('infinite', function() {
					app.LoadPageForumView('.type-scroll')
				})
				break;
			case 'group-my': //�ҵ�Ȧ��
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-groupmy', 3,10,.1)
				})
				ck8('.groupmy-scroll').on('infinite', function() {
					app.LoadPageForumView('.groupmy-scroll')
				})
				break;
			case 'group-list': //Ȧ���б�
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-grouplist', 5,10,.1)
				})
				ck8('.grouplist-scroll').on('infinite', function() {
					app.LoadPageForumView('.grouplist-scroll')
				})
				if(typeof ShareAllgroup == 'function'){
					setTimeout(function(){
					   ShareAllgroup()
					}, 300);
				}
				break;
			case 'group-manage': //Ȧ�ӹ���
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-groupmanage', 5,10,.1)
				})
				ck8('.groupmanage-scroll').on('infinite', function() {
					app.LoadPageForumView('.groupmanage-scroll')
				})
				break;
			case 'space-favorite': //�ղ�
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacefavorite', 7,10,.1)
				})
				break;
			case 'space-thread': //����
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacethread', 3,10,.1)
				})
				break;
			case 'space-friend': //����
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacefriend', 5,10,.1)
				})
				ck8('.friend-scroll').on('infinite', function() {
					app.LoadPageForumView('.friend-scroll')
				})
				break;
			case 'spacecp-poke': //�к�
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacecppoke', 2,10,.1)
				})
				ck8('.poke-scroll').on('infinite', function() {
					app.LoadPageForumView('.poke-scroll')
				})
				break;
			case 'spacecp-credit-base': //����
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacecpcreditbase', 3,10,.1)
				})
				ck8('.base-scroll').on('infinite', function() {
					app.LoadPageForumView('.base-scroll')
				})
				break;
			case 'space-task': //����
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacetask', 4,10,.1)
				})
				ck8('.task-scroll').on('infinite', function() {
					app.LoadPageForumView('.task-scroll')
				})
				break;
			case 'space-doing': //˵��
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacedoing', 3,10,.1)
				})
				ck8('.doing-scroll').on('infinite', function() {
					app.LoadPageForumView('.doing-scroll')
				})
				break;
			case 'space-medal': //ѫ��
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacemedal', 2,10,.1)
				})
				ck8('.medal-scroll').on('infinite', function() {
					app.LoadPageForumView('.medal-scroll')
				})
				break;
			case 'space-album-list': //���
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacealbumlist', 3,10,.1)
				})
				ck8('.album-scroll').on('infinite', function() {
					app.LoadPageForumView('.album-scroll')
				})
				break;
			case 'space-album-view': //�������
				if(typeof ShareAllalbum == 'function'){
					setTimeout(function(){
					   ShareAllalbum()
					}, 300);
				}
				break;
			case 'space-blog-list': //��־
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacebloglist', 3,10,.1)
				})
				ck8('.blog-scroll').on('infinite', function() {
					app.LoadPageForumView('.blog-scroll')
				})
				break;
			case 'space-blog-view': //��־����
				if(typeof ShareAllblog == 'function'){
					setTimeout(function(){
					   ShareAllblog()
					}, 300);
				}
				break;
			case 'spacecp-usergroup': //�û���
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacecpusergroup', 2,10,.1)
				})
				ck8('.usergroup-scroll').on('infinite', function() {
					app.LoadPageForumView('.usergroup-scroll')
				})
				break;
			case 'ranklist-member': //�û�����
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-ranklistmember', 5,10,.1)
				})
				ck8('.member-scroll').on('infinite', function() {
					app.LoadPageForumView('.member-scroll')
				})
				break;
			case 'ranklist-thread': //��������
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-ranklistthread', 4,10,.1)
				})
				ck8('.phthread-scroll').on('infinite', function() {
					app.LoadPageForumView('.phthread-scroll')
				})
				break;
			case 'ranklist-forum': //�������
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-ranklistforum', 3,10,.1)
				})
				ck8('.phforum-scroll').on('infinite', function() {
					app.LoadPageForumView('.phforum-scroll')
				})
				break;
			case 'ranklist-group': //Ȧ������
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-ranklistgroup', 5,10,.1)
				})
				ck8('.phgroup-scroll').on('infinite', function() {
					app.LoadPageForumView('.phgroup-scroll')
				})
				break;
			case 'tagitem': //TAG
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-tagitem', 2,10,.1)
				})
				ck8('.tagitem-scroll').on('infinite', function() {
					app.LoadPageForumView('.tagitem-scroll')
				})
				break;
			case 'portal-list': //����portal-list
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-portallist', 5,10,6)
				})
				ck8('.portallist-scroll').on('infinite', function() {
					app.LoadPageForumView('.portallist-scroll')
				})
				break;
			case 'portal-view': //��������
				if(typeof ShareAllportal == 'function'){
					setTimeout(function(){
					   ShareAllportal()
					}, 300);
				}
				break;
			case 'poll-voter': //ͶƱ��Ա
				ck8('.poll-voter-scroll').on('infinite', function() {
					app.LoadPageForumView('.poll-voter-scroll')
				})
				break;
			case 'login': //��¼
				app.loadScript('jsswiper-4.3.3.min', function() {
					new Swiper('.gg-dz-dlbg', {
						spaceBetween: 30,
						effect: 'fade',
						loop: true,
						autoplay: true,
						speed: 6000,
						fadeEffect: {crossFade: true,}
					});
					ck8('.gg-dz-dlbg').css({
						'visibility': 'visible'
					});
				})
				break;
			case 'spacecp-profile': //������֤
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-spacecpprofile', 5,10,.1)
				})
				ck8('.groupmanage-scroll').on('infinite', function() {
					app.LoadPageForumView('.groupmanage-scroll')
				})
				break;
			case 'post': //����
				app.loadScript('jsswiper-4.3.3.min', function() {
					inSwiperTab('.gg-cjdh-post', 6,10,.1)
				})
				ck8('.post-scroll').on('infinite', function() {
					app.LoadPageForumView('.post-scroll')
				})
				break;
			case 'announcement': //����
				ck8('.announcement-scroll').on('infinite', function() {
					app.LoadPageForumView('.announcement-scroll')
				})
				break;
			case 'invite': //����
				if(typeof ShareAllinvite == 'function'){
					setTimeout(function(){
					   ShareAllinvite()
					}, 300);
				}
				break;
			case 'pluginindex': //�����ҳ
				ck8('.plugin-scroll').on('infinite', function() {
					getMore(pluginorderids,true);
				})
				break;
		}
	})
	ck8.init();
})

