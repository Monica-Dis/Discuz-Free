<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache(array('pluginlanguage_script', 'pluginlanguage_template'));
if (submitcheck('submit')) {
	$parameteript = array();
	$parametertpl = array();
	if (!empty($_GET['parameteript']) || !empty($_GET['parametertpl'])) {
		$parameteript = unserialize(DB::result_first('SELECT DATA FROM ' . DB::table('common_syscache') . ' WHERE cname=\'pluginlanguage_script\''));
		$parameteript['guiigo_manage'] = $_GET['parameteript'];
		C::t('common_syscache')->update('pluginlanguage_script', $parameteript);
		unset($parameteript);
		$parametertpl = unserialize(DB::result_first('SELECT DATA FROM ' . DB::table('common_syscache') . ' WHERE cname=\'pluginlanguage_template\''));
		$parametertpl['guiigo_manage'] = $_GET['parametertpl'];
		C::t('common_syscache')->update('pluginlanguage_template', $parametertpl);
		unset($parametertpl);
		cpmsg('setting_update_succeed', dreferer(), 'succeed');
	}
}
showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=guiigo_manage&pmod=AdminLang');
showtableheader(lang('plugin/guiigo_manage', 'slang0003'));
foreach ($_G['cache']['pluginlanguage_script']['guiigo_manage'] as $key => $val) {
	showsetting($key, 'parameteript[' . $key . ']', $val, 'text', 0, 0);
}
foreach ($_G['cache']['pluginlanguage_template']['guiigo_manage'] as $k => $v) {
	showsetting($k, 'parametertpl[' . $k . ']', $v, 'text', 0, 0);
}
showsubmit('submit');
showtablefooter();/*Dism��taobao��com*/
showformfooter();/*Dism_taobao_com*/