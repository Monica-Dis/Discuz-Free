<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
$config = GuiigoApp::config();
require_once libfile('function/forumlist');
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
$operationurl = ADMINSCRIPT . '?action=' . $basicurl;
if (!$_GET['act']) {
	$nav_select = array();
	$nav_select[] = array(1, lang('plugin/guiigo_manage', 'slang0033'));
	$nav_select[] = array(2, lang('plugin/guiigo_manage', 'slang0034'));
	$temptypejs = GuiigoApp::get_select('settingnew[nav][type][]', $nav_select, '', array(0, lang('plugin/guiigo_manage', 'slang0028')));
	if (!submitcheck('savesubmit')) {
		showformheader($basicurl, 'enctype');
		showtableheader(lang('plugin/guiigo_manage', 'slang0035'));
		showsubtitle(array(lang('plugin/guiigo_manage', 'slang0036'), lang('plugin/guiigo_manage', 'slang0037'), lang('plugin/guiigo_manage', 'slang0038'), lang('plugin/guiigo_manage', 'slang0039')), 'header', array('colspan="0" class="td23"', 'colspan="0" class="td23"'));
		foreach ($setting['nav'] as $key => $val) {
			$temptype = GuiigoApp::get_select('settingnew[nav][type][' . $key . ']', $nav_select, $val['type'], array(0, lang('plugin/guiigo_manage', 'slang0028')));
			$operation = '';
			if ($val['type'] == 1) {
				$navurl = $_G['siteurl'] . 'plugin.php?id=guiigo_manage&navorderid=' . $val['order'];
				$operation .= '<a href="javascript:;" class="act" onclick="prompt(\'' . lang('plugin/guiigo_manage', 'slang0040') . '\', \'' . $navurl . '\')">' . lang('plugin/guiigo_manage', 'slang0041') . '</a>';
			} else {
				$operation .= '<a href="javascript:;" class="act lightfont">' . lang('plugin/guiigo_manage', 'slang0041') . '</a>';
			}
			$operation .= '
						<a href="' . $operationurl . '&act=edit&orderid=' . $val['order'] . '" class="act">' . lang('plugin/guiigo_manage', 'slang0042') . '</a>
						<a href="' . $operationurl . '&act=del&orderid=' . $val['order'] . '" class="act">' . lang('plugin/guiigo_manage', 'slang0043') . '</a>
					';
			showtablerow('', array('colspan="0" class="td23"', 'colspan="0" class="td23"'), array('<input type="text" class="txt" name="settingnew[nav][order][' . $key . ']" value="' . $val['order'] . '" />', '<input type="text" class="txt" name="settingnew[nav][channelname][' . $key . ']" value="' . $val['channelname'] . '" />', $temptype, $operation));
		}
		echo '<tr><td><div><a href="javascript:;" onclick="addrow(this, 0);" class="addtr">' . lang('plugin/guiigo_manage', 'slang0044') . '</a></div></td></tr>';
		echo '	<script type="text/JavaScript">
		var rowtypedata = [
			[
				[1,\'<input type="text" class="txt" name="settingnew[nav][order][]" value="">\', \'td23\'],
				[1,\'<input type="text" class="txt" name="settingnew[nav][channelname][]" value="">\', \'td23\'],
				[3,\'' . $temptypejs . '\', \'td23\']
			]
		];
	</script>';
		showsubmit('savesubmit', 'submit');
		showtablefooter();/*Dism��taobao��com*/
		showformfooter();/*Dism_taobao_com*/
	} else {
		$newnav = array();
		foreach ($_POST['settingnew']['nav']['order'] as $k => $v) {
			$newnav[$k] = array('order' => $v, 'channelname' => $_POST['settingnew']['nav']['channelname'][$k], 'type' => $_POST['settingnew']['nav']['type'][$k], 'typename' => GetTypeName($nav_select, $_POST['settingnew']['nav']['type'][$k]));
			if ($setting['nav']) {
				foreach ($setting['nav'] as $kn => $vn) {
					if ($vn['order'] == $v) {
						$newnav[$k] = array_merge($vn, $newnav[$k]);
						break;
					}
				}
			}
		}
		$setting['nav'] = $newnav;
		C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
		updatecache('setting');
		cpmsg('setting_update_succeed', dreferer(), 'succeed');
	}
} else {
	if ($_GET['act'] == 'del') {
		$orderid = intval($_GET['orderid']);
		if (empty($orderid)) {
			cpmsg(lang('plugin/guiigo_manage', 'slang0045'), dreferer(), 'error');
		}
		$newnav = array();
		foreach ($setting['nav'] as $k => $v) {
			if ($v['order'] != $orderid) {
				$newnav[$k] = $v;
			}
		}
		$setting['nav'] = $newnav;
		C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
		updatecache('setting');
		cpmsg('setting_update_succeed', dreferer(), 'succeed');
	} elseif ($_GET['act'] == 'edit') {
		$orderid = intval($_GET['orderid']);
		if (empty($orderid)) {
			cpmsg(lang('plugin/guiigo_manage', 'slang0045'), dreferer(), 'error');
		}
		$navdata = array();
		foreach ($setting['nav'] as $k => $v) {
			if ($v['order'] == $orderid) {
				$navdata = $v;
				break;
			}
		}
		if (!submitcheck('settingsubmit')) {
			$forum_style_select = array();
			$forum_style_select[] = array(1, lang('plugin/guiigo_manage', 'slang0023'));
			$forum_style_select[] = array(2, lang('plugin/guiigo_manage', 'slang0024'));
			$forum_style_select[] = array(3, lang('plugin/guiigo_manage', 'slang0025'));
			showformheader($basicurl . '&act=edit&orderid=' . $orderid, 'enctype');
			showtableheader(lang('plugin/guiigo_manage', 'slang0047'), 'nobottom');
			showsetting(lang('plugin/guiigo_manage', 'slang0037'), 'settingnew[channelname]', $navdata['channelname'], 'text');
			showsetting(lang('plugin/guiigo_manage', 'slang0048'), array('settingnew[channel_extension]', array(array('information', lang('plugin/guiigo_manage', 'slang0049'), array('information' => '', 'htmlcode' => 'none', 'modules' => 'none', 'forum' => 'none', 'Portal' => 'none', 'group' => 'none')), array('htmlcode', lang('plugin/guiigo_manage', 'slang0050'), array('information' => 'none', 'htmlcode' => '', 'modules' => 'none', 'forum' => 'none', 'Portal' => 'none', 'group' => 'none')), array('modules', lang('plugin/guiigo_manage', 'slang0051'), array('information' => 'none', 'htmlcode' => 'none', 'modules' => '', 'forum' => 'none', 'Portal' => 'none', 'group' => 'none')))), $navdata['channel_extension'], 'mradio2');
			showtagheader('tbody', 'information', $navdata['information'], 'sub');
			showsetting(lang('plugin/guiigo_manage', 'slang0052'), 'settingnew[module_ids]', $navdata['module_ids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0053'));
			showsetting(lang('plugin/guiigo_manage', 'slang0054'), array('settingnew[recommend_content]', array(array('forum', lang('plugin/guiigo_manage', 'slang0055'), array('forum' => '', 'Portal' => 'none', 'group' => 'none')), array('Portal', lang('plugin/guiigo_manage', 'slang0056'), array('forum' => 'none', 'Portal' => '', 'group' => 'none')), array('group', lang('plugin/guiigo_manage', 'slang0057'), array('forum' => 'none', 'Portal' => 'none', 'group' => '')))), $navdata['recommend_content'], 'mradio2');
			showtagheader('tbody', 'forum', $navdata['information']['forum'], 'sub');
			showsetting(lang('plugin/guiigo_manage', 'slang0058'), '', '', '<select name="settingnew[forum][forumids][]" multiple="multiple" size="10">' . forumselect(0, 0, $navdata['information']['forum']['forumids'], true) . '</select>');
			showsetting(lang('plugin/guiigo_manage', 'slang0059'), 'settingnew[forum][digest]', $navdata['information']['forum']['digest'], 'radio');
			showsetting(lang('plugin/guiigo_manage', 'slang0060'), 'settingnew[forum][isimg]', $navdata['information']['forum']['isimg'], 'radio');
			showsetting(lang('plugin/guiigo_manage', 'slang0061'), 'settingnew[forum][uids]', $navdata['information']['forum']['uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0062'));
			showsetting(lang('plugin/guiigo_manage', 'slang0063'), '', '', GuiigoApp::get_select('settingnew[forum][style]', $forum_style_select, $navdata['information']['forum']['style'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
			showtagfooter('tbody');
			showtagheader('tbody', 'Portal', $navdata['information']['Portal'], 'sub');
			$portalcpselect = category_showselect('portal', $navdata['information']['Portal']['Portalids']);
			showsetting(lang('plugin/guiigo_manage', 'slang0064'), '', '', '<select name="settingnew[Portal][Portalids][]" multiple="multiple" size="10">' . $portalcpselect . '</select>');
			showsetting(lang('plugin/guiigo_manage', 'slang0060'), 'settingnew[Portal][isimg]', $navdata['information']['Portal']['isimg'], 'radio');
			showsetting(lang('plugin/guiigo_manage', 'slang0065'), 'settingnew[Portal][uids]', $navdata['information']['Portal']['uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0062'));
			showtagfooter('tbody');
			showtagheader('tbody', 'group', $navdata['information']['group'], 'sub');
			showsetting(lang('plugin/guiigo_manage', 'slang0067'), 'settingnew[group][groupids]', $navdata['information']['group']['groupids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0068'));
			showsetting(lang('plugin/guiigo_manage', 'slang0059'), 'settingnew[group][digest]', $navdata['information']['group']['digest'], 'radio');
			showsetting(lang('plugin/guiigo_manage', 'slang0060'), 'settingnew[group][isimg]', $navdata['information']['group']['isimg'], 'radio');
			showsetting(lang('plugin/guiigo_manage', 'slang0061'), 'settingnew[group][uids]', $navdata['information']['group']['uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0062'));
			showsetting(lang('plugin/guiigo_manage', 'slang0063'), '', '', GuiigoApp::get_select('settingnew[group][style]', $forum_style_select, $navdata['information']['group']['style'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
			showtagfooter('tbody');
			showtagfooter('tbody');
			showtagheader('tbody', 'htmlcode', $navdata['htmlcode'], 'sub');
			showsetting(lang('plugin/guiigo_manage', 'slang0066'), 'settingnew[htmlcode]', $navdata['htmlcode'], 'textarea');
			showtagfooter('tbody');
			showtagheader('tbody', 'modules', $navdata['modules'], 'sub');
			showsetting(lang('plugin/guiigo_manage', 'slang0052'), 'settingnew[modules]', $navdata['modules'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0053'));
			showtagfooter('tbody');
			showtablefooter();/*Dism��taobao��com*/
			showtableheader('', 'notop');
			showsubmit('settingsubmit');
			showtablefooter();/*Dism��taobao��com*/
			showformfooter();/*Dism_taobao_com*/
		} else {
			$newdata = array('channelname' => $_POST['settingnew']['channelname'], 'channel_extension' => $_POST['settingnew']['channel_extension'], 'recommend_content' => $_POST['settingnew']['recommend_content']);
			if ($_POST['settingnew']['channel_extension'] == 'information') {
				if (empty($_POST['settingnew']['recommend_content'])) {
					cpmsg(lang('plugin/guiigo_manage', 'slang0046'), dreferer(), 'error');
				}
				if ($_POST['settingnew']['recommend_content'] == 'forum') {
					$newdata['information'] = array('forum' => $_POST['settingnew']['forum']);
				} elseif ($_POST['settingnew']['recommend_content'] == 'Portal') {
					$newdata['information'] = array('Portal' => $_POST['settingnew']['Portal']);
				} elseif ($_POST['settingnew']['recommend_content'] == 'group') {
					$newdata['information'] = array('group' => $_POST['settingnew']['group']);
				}
				$newdata['module_ids'] = $_POST['settingnew']['module_ids'];
				$newdata['htmlcode'] = '';
				$newdata['modules'] = '';
			} elseif ($_POST['settingnew']['channel_extension'] == 'htmlcode') {
				$newdata['htmlcode'] = $_POST['settingnew']['htmlcode'];
				$newdata['modules'] = '';
				$newdata['information'] = array();
				$newdata['module_ids'] = '';
				$newdata['recommend_content'] = '';
			} elseif ($_POST['settingnew']['channel_extension'] == 'modules') {
				$newdata['modules'] = $_POST['settingnew']['modules'];
				$newdata['htmlcode'] = '';
				$newdata['information'] = array();
				$newdata['module_ids'] = '';
				$newdata['recommend_content'] = '';
			}
			foreach ($setting['nav'] as $kn => $vn) {
				if ($vn['order'] == $orderid) {
					$setting['nav'][$kn] = array_merge($navdata, $newdata);
					break;
				}
			}
			C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
			updatecache('setting');
			cpmsg('setting_update_succeed', dreferer(), 'succeed');
		}
	}
}
function GetTypeName($array, $typeid)
{
	foreach ($array as $val) {
		if ($typeid == $val[0]) {
			return $val[1];
		}
	}
}
function category_showselect($type, $current = array(), $shownull = true)
{
	global $_G;
	if (!in_array($type, array('portal', 'blog', 'album'))) {
		return '';
	}
	loadcache($type . 'category');
	$category = $_G['cache'][$type . 'category'];
	$select = '';
	if ($shownull) {
		$select .= '<option value="">' . lang('portalcp', 'select_category') . '</option>';
	}
	foreach ($category as $value) {
		if ($value['level'] == 0) {
			$selected = in_array($value['catid'], $current) ? 'selected="selected"' : '';
			$select .= '<option value="' . $value['catid'] . '"' . $selected . '>' . $value['catname'] . '</option>';
			if ($value['children']) {
				foreach ($value['children'] as $catid) {
					$selected = in_array($catid, $current) ? 'selected="selected"' : '';
					$select .= '<option value="' . $category[$catid][catid] . '"' . $selected . '>-- ' . $category[$catid][catname] . '</option>';
					if ($category[$catid]['children']) {
						foreach ($category[$catid]['children'] as $catid2) {
							$selected = in_array($catid2, $current) ? 'selected="selected"' : '';
							$select .= '<option value="' . $category[$catid2][catid] . '"' . $selected . '>----' . $category[$catid2][catname] . '</option>';
						}
					}
				}
			}
		}
	}
	return $select;
}