<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
$config = GuiigoApp::config();
require_once libfile('function/forumlist');
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
$forum_style_select = array();
$forum_style_select[] = array(1, lang('plugin/guiigo_manage', 'slang0023'));
$forum_style_select[] = array(2, lang('plugin/guiigo_manage', 'slang0024'));
$forum_style_select[] = array(3, lang('plugin/guiigo_manage', 'slang0025'));
$top_style_select = array();
$top_style_select[] = array(1, lang('plugin/guiigo_manage', 'slang0026'));
$top_style_select[] = array(2, lang('plugin/guiigo_manage', 'slang0027'));
if (!isset($_G['cache']['forums'])) {
	loadcache('forums');
}
$forumcache = $_G['cache']['forums'];
$forumlist = array();
foreach ($forumcache as $fid => $forum) {
	if ($forum['status'] && $forum['type'] != 'group') {
		$forumlist[$fid] = $forum;
	}
}
if (!submitcheck('settingsubmit')) {
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0141'), 'nobottom');
	showsubtitle(array(lang('plugin/guiigo_manage', 'slang0029'), lang('plugin/guiigo_manage', 'slang0030'), lang('plugin/guiigo_manage', 'slang0031'), lang('plugin/guiigo_manage', 'slang0032')), 'header', array('colspan="0" class="td25"'));
	foreach ($forumlist as $key => $val) {
		$forumval = GuiigoApp::getForumStyleByfid($val['fid']);
		$forum_style = GuiigoApp::get_select('settingnew[forum_style][' . $key . ']', $forum_style_select, $forumval['forum_style'], array(0, lang('plugin/guiigo_manage', 'slang0028')));
		$top_style = GuiigoApp::get_select('settingnew[forums_top_tyle][' . $key . ']', $top_style_select, $forumval['forums_top_tyle'], array(0, lang('plugin/guiigo_manage', 'slang0028')));
		showtablerow('', array('colspan="0" class="td25"'), array('<input type="text" class="txt" name="settingnew[forum_id][' . $key . ']" value="' . $val['fid'] . '" />', '<input type="text" class="txt" name="settingnew[forum_name][' . $key . ']" value="' . $val['name'] . '" />', $forum_style, $top_style));
	}
	showtablefooter();/*Dism��taobao��com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism_taobao_com*/
} else {
	$newforumlist = array();
	foreach ($_POST['settingnew']['forum_id'] as $key => $val) {
		$newforumlist[$key]['forum_id'] = $_POST['settingnew']['forum_id'][$key];
		$newforumlist[$key]['forum_name'] = $_POST['settingnew']['forum_name'][$key];
		$newforumlist[$key]['forum_style'] = $_POST['settingnew']['forum_style'][$key];
		$newforumlist[$key]['forums_top_tyle'] = $_POST['settingnew']['forums_top_tyle'][$key];
	}
	$setting['forumstyle'] = $newforumlist;
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}