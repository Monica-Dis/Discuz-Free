<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
$config = GuiigoApp::config();
require_once libfile('function/forumlist');
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
if (!submitcheck('settingsubmit')) {
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0004'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0005'), 'settingnew[show_statistics]', $setting['forumconfig']['show_statistics'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0006'), 'settingnew[show_notice]', $setting['forumconfig']['show_notice'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0007'), 'settingnew[show_follow_ad_html]', $setting['forumconfig']['show_follow_ad_html'], 'textarea');
	showsetting(lang('plugin/guiigo_manage', 'slang0008'), 'settingnew[recommend_forum_ids]', $setting['forumconfig']['recommend_forum_ids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0009'));
	showsetting(lang('plugin/guiigo_manage', 'slang0010'), 'settingnew[recommend_forum_ad_html]', $setting['forumconfig']['recommend_forum_ad_html'], 'textarea');
	showsetting(lang('plugin/guiigo_manage', 'slang0011'), 'settingnew[show_top_unfold]', $setting['forumconfig']['show_top_unfold'], 'text');
	showsetting(lang('plugin/guiigo_manage', 'slang0012'), 'settingnew[show_reward]', $setting['forumconfig']['show_reward'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0013'), 'settingnew[reward_text]', $setting['forumconfig']['reward_text'], 'text');
	showsetting(lang('plugin/guiigo_manage', 'slang0014'), 'settingnew[show_tag]', $setting['forumconfig']['show_tag'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0015'), 'settingnew[show_give]', $setting['forumconfig']['show_give'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0016'), 'settingnew[show_content_sources]', $setting['forumconfig']['show_content_sources'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0017'), 'settingnew[show_like]', $setting['forumconfig']['show_like'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0018'), 'settingnew[show_look_posts]', $setting['forumconfig']['show_look_posts'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0019'), 'settingnew[show_reply_order]', $setting['forumconfig']['show_reply_order'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0020'), 'settingnew[show_reply_data]', $setting['forumconfig']['show_reply_data'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0021'), 'settingnew[show_give_data]', $setting['forumconfig']['show_give_data'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0022'), 'settingnew[show_favorite_data]', $setting['forumconfig']['show_favorite_data'], 'radio');
	showtablefooter();/*Dism��taobao��com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism_taobao_com*/
} else {
	$setting['forumconfig'] = $_GET['settingnew'];
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}