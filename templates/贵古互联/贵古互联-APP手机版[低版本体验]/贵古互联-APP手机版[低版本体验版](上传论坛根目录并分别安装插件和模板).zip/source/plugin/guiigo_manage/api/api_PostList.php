<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if ($_GET['act'] == 'getIndexList') {
	$orderid = daddslashes($_GET['orderid']);
	$perpage = 10;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage - 1) * $perpage;
	$poatstyle = 1;
	$mods = 1;
	$postlist = array();
	$data_html = '';
	if ($orderid == 'recommend_content' || $orderid == 'nocontent') {
		if ($config['appsetting']['module_ids'] && $_GET['page'] <= 1) {
			$data_html = GuiigoApp::get_block_htnl($config['appsetting']['module_ids']);
		}
		if ($config['appsetting']['recommend_content'] == 'nocontent') {
			$data_html .= '<div id="nolist" style="display:none;"></div>';
		} elseif ($config['appsetting']['recommend_content'] == 'forum') {
			$forumary = $config['appsetting']['forum'];
			if ($forumary['style']) {
				$poatstyle = $forumary['style'];
			}
			$where = array();
			$where['fid'] = $forumary['forumids'] ? $forumary['forumids'] : '';
			$where['attachment'] = $forumary['isimg'] ? 2 : '';
			$where['digest'] = $forumary['digest'] ? 1 : '';
			$where['authorid'] = $forumary['uids'] ? $forumary['uids'] : '';
		} elseif ($config['appsetting']['recommend_content'] == 'Portal') {
			$mods = 2;
			$Portalary = $config['appsetting']['Portal'];
			if ($Portalary['style']) {
				$poatstyle = $Portalary['style'];
			}
			$where = array();
			$where['catid'] = $poatstyle['Portalids'] ? $poatstyle['Portalids'] : '';
			$where['pic'] = $poatstyle['isimg'] ? true : false;
			$where['uid'] = $poatstyle['uids'] ? $poatstyle['uids'] : '';
			$postlist = GuiigoApp::fetch_all_get_Portal_post($where, $start, $perpage);
		} elseif ($config['appsetting']['recommend_content'] == 'group') {
			$groupary = $config['appsetting']['group'];
			if ($groupary['style']) {
				$poatstyle = $groupary['style'];
			}
			$where = array();
			$where['fid'] = $groupary['groupids'];
			$where['digest'] = $groupary['digest'] ? 1 : '';
			$where['attachment'] = $groupary['isimg'] ? 2 : '';
			$where['authorid'] = $groupary['uids'] ? $groupary['uids'] : '';
			$where['isgroup'] = 1;
		}
		if ($config['appsetting']['recommend_content'] == 'group' || $config['appsetting']['recommend_content'] == 'forum') {
			$data = GuiigoApp::fetch_all_get_post($where, $start, $perpage);
			$postlist = getlistp($data);
		}
	} else {
		if ($orderid == 'user_interest') {
			$isopengz = true;
			if ($_G['uid']) {
				$uids = GuiigoApp::getUserList($_G['uid'], 'follow');
				if ($uids) {
					$where = array();
					$where['authorid'] = $uids;
					$where['noauthorid'] = $_G['uid'];
					$where['noisgroup'] = 1;
					$data = GuiigoApp::fetch_all_get_post($where, $start, $perpage, 'BY p.dateline DESC');
					$postlist = getlistp($data);
				}
				if ($postlist) {
					$isopengz = false;
				}
			}
			if ($isopengz && $_GET['page'] <= 1 && $config['appsetting']['user_follow_uids']) {
				$userlist = array();
				foreach (explode(',', $config['appsetting']['user_follow_uids']) as $k => $val) {
					$guser = getuserbyuid($val);
					$userlist[$k]['uid'] = $guser['uid'];
					$userlist[$k]['username'] = $guser['username'];
					$userlist[$k]['avatarurl'] = avatar($guser['uid'], 'big', true, false, true) . '?' . rand(1000, 9999);
				}
				$data_html .= '<div id="nolist" style="display:none;"></div>';
			}
		} else {
			$pluginanv = false;
			if (strpos($_GET['orderid'], '_plugin') !== false) {
				$_GET['orderid'] = str_replace('_plugin', '', $_GET['orderid']);
				$pluginanv = true;
			}
			$orderid = intval($_GET['orderid']);
			$navs = $config['appsetting']['nav'];
			if ($orderid) {
				if ($pluginanv) {
					$navs = $config['appsetting']['nav2'];
				}
				$navarray = $navs[$orderid];
				if ($navarray['channel_extension'] == 'information') {
					$param = $navarray[$navarray['channel_extension']][$navarray['recommend_content']];
					if ($navarray['module_ids'] && $_GET['page'] <= 1) {
						$data_html = GuiigoApp::get_block_htnl($navarray['module_ids']);
					}
					if ($param['style']) {
						$poatstyle = $param['style'];
					}
					if ($navarray['recommend_content'] == 'Portal') {
						$mods = 2;
						$where = array();
						$where['catid'] = $param['Portalids'] ? $param['Portalids'] : '';
						$where['pic'] = $param['isimg'] ? true : false;
						$where['uid'] = $param['uids'] ? $param['uids'] : '';
						$postlist = GuiigoApp::fetch_all_get_Portal_post($where, $start, $perpage);
					} else {
						$where = array();
						$where['fid'] = $navarray['recommend_content'] == 'forum' ? $param['forumids'] : $param['groupids'];
						$where['isgroup'] = $navarray['recommend_content'] == 'forum' ? 0 : 1;
						$where['digest'] = $param['digest'] ? 1 : '';
						$where['attachment'] = $param['isimg'] ? 2 : '';
						$where['authorid'] = $param['uids'] ? $param['uids'] : '';
						$data = GuiigoApp::fetch_all_get_post($where, $start, $perpage);
						$postlist = getlistp($data);
					}
				} elseif ($navarray['channel_extension'] == 'htmlcode') {
					$data_html = $navarray['htmlcode'];
					$data_html .= '<div id="nolist" style="display:none;"></div>';
				} elseif ($navarray['channel_extension'] == 'modules') {
					$data_html = GuiigoApp::get_block_htnl($navarray['modules']);
					$data_html .= '<div id="nolist" style="display:none;"></div>';
				}
			}
		}
	}
	if ($poatstyle == 1) {
		$mods == 1 ? include template('guiigo_manage:indexView') : (include template('guiigo_manage:PortalView'));
	} elseif ($poatstyle == 2) {
		include template('guiigo_manage:indexView2');
	} elseif ($poatstyle == 3) {
		include template('guiigo_manage:indexView3');
	}
} elseif ($_GET['act'] == 'getGrougList') {
	$perpage = 10;
	$curpage = empty($_GET['page']) ? 1 : intval($_GET['page']);
	$start = ($curpage - 1) * $perpage;
	$poatstyle = 1;
	$postlist = array();
	$groupary = $config['appsetting']['groupconfig'];
	if ($groupary['group_content_style']) {
		$poatstyle = $groupary['group_content_style'];
	}
	$where = array();
	$where['fid'] = $groupary['group_content_ids'];
	$where['authorid'] = $groupary['uids'];
	$where['isgroup'] = 1;
	$data = GuiigoApp::fetch_all_get_post($where, $start, $perpage);
	$postlist = getlistp($data);
	if (count($postlist) < $perpage && $_GET['page'] <= 1) {
		$data_html = '<div id="nolist" style="display:none;"></div>';
	}
	if ($poatstyle == 1) {
		include template('guiigo_manage:groupIndexView');
	} elseif ($poatstyle == 2) {
		include template('guiigo_manage:groupIndexView2');
	}
}
function getlistp($data)
{
	$postlist = array();
	foreach ($data as $key => $val) {
		$attacharr = GuiigoApp::AttachImg($val['tid']);
		$postlist[$key] = $val;
		$message = preg_replace('/\\[i=([A-Z]+)\\]\\s*(.*?)\\s*((\\[\\/i\\])|\\.\\.\\.)/is', '', preg_replace('/\\{:(.*?)\\:}/is', '', $val['message']));
		$postlist[$key]['message'] = preg_replace('/[\\s]+/is', '', preg_replace('/\\[[a-z][^\\]]*\\]|\\[\\/[a-z]+\\]/i', '', preg_replace('/\\[attach\\]\\d+\\[\\/attach\\]/i', '', $message)));
		$postlist[$key]['attapic'] = $attacharr[$val['pid']];
	}
	return $postlist;
}