<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!is_array($_G['cache']['usergroups'])) {
	loadcache('usergroups');
}
class GuiigoApp
{
	public static function config()
	{
		global $_G;
		$pluginConfig = $_G['cache']['plugin']['guiigo_manage'];
		$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
		$setting = (array) unserialize($setting['guiigo_manage']);
		$pluginConfig['appsetting'] = $setting;
		$pluginConfig['appsetting']['userconfig']['show_ad_slide'] = self::GetTypeArr($pluginConfig['appsetting']['userconfig']['show_ad_slide']);
		$pluginConfig['appsetting']['groupconfig']['group_slide'] = self::GetTypeArr($pluginConfig['appsetting']['groupconfig']['group_slide']);
		$nav = $pluginConfig['appsetting']['nav'];
		$pluginConfig['appsetting']['nav'] = self::ksortary($nav);
		$pluginConfig['appsetting']['nav2'] = self::ksortary($nav, 'order', 2);
		$browser = self::getHtUsAgent();
		$pluginConfig['browser'] = array('iswx' => $browser['iswx'], 'isqq' => $browser['isqq'], 'isuc' => $browser['isuc']);
		return $pluginConfig;
		//d'.'is'.'m.ta'.'obao.com
	}
	public static function getHtUsAgent()
	{
		$type = array();
		$type['iswx'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') === false);
		$type['isqq'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'mqqbrowser') === false);
		$type['isuc'] = !(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'ucbrowser') === false);
		return $type;
	}
	public static function get($url)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		if (!curl_exec($ch)) {
			error_log(curl_error($ch));
			$data = '';
		} else {
			$data = curl_multi_getcontent($ch);
		}
		curl_close($ch);
		return $data;
	}
	public static function getSignPackage($url)
	{
		$config = self::config();
		$jsapiTicket = self::getJsApiTicket();
		$timestamp = time();
		$nonceStr = self::createNonceStr();
		$string = 'jsapi_ticket=' . $jsapiTicket . '&noncestr=' . $nonceStr . '&timestamp=' . $timestamp . '&url=' . $url;
		$signature = sha1($string);
		$signPackage = array('appid' => $config['wx_appid'], 'nonceStr' => $nonceStr, 'timestamp' => $timestamp, 'signature' => $signature);
		return $signPackage;
	}
	public static function createNonceStr($length = 16)
	{
		$chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
		$str = '';
		for ($i = 0; $i < $length; $i++) {
			$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}
	public static function getJsApiTicket()
	{
		global $_G;
		include_once libfile('function/cache');
		$config = self::config();
		$appid = $config['wx_appid'];
		$appsecret = $config['wx_appsecret'];
		$cache_jsapi_ticket = 'fxtickets_' . $appid . $appsecret;
		loadcache($cache_jsapi_ticket);
		$jsapi_ticket = $_G['cache'][$cache_jsapi_ticket];
		if ($jsapi_ticket['jsapi_ticket'] && $jsapi_ticket['expire_time'] > time()) {
			return $jsapi_ticket['jsapi_ticket'];
		}
		$accessToken = self::getAccessToken();
		$url = 'https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=' . $accessToken;
		$res = json_decode(self::get($url), true);
		$ticket = $res['ticket'];
		$jsapi_tickets = array('jsapi_ticket' => $ticket, 'expire_time' => time() + 7000);
		savecache($cache_jsapi_ticket, $jsapi_tickets);
		return $ticket;
	}
	public static function getAccessToken()
	{
		global $_G;
		include_once libfile('function/cache');
		$config = self::config();
		$appid = $config['wx_appid'];
		$appsecret = $config['wx_appsecret'];
		$cache_access_token = 'fxtokens_' . $appid . $appsecret;
		loadcache($cache_access_token);
		$token = $_G['cache'][$cache_access_token];
		if ($token['access_token'] && $token['expire_time'] > time()) {
			return $token['access_token'];
		}
		$url = 'https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=' . $appid . '&secret=' . $appsecret;
		$res = json_decode(self::get($url), true);
		$access_token = $res['access_token'];
		$access_tokens = array('access_token' => $access_token, 'expire_time' => time() + 7000);
		savecache($cache_access_token, $access_tokens);
		return $access_token;
	}
	public static function post($url, $data)
	{
		if (!function_exists('curl_init')) {
			return '';
		}
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$data = curl_exec($ch);
		if (!$data) {
			error_log(curl_error($ch));
		}
		curl_close($ch);
		return $data;
	}
	//di'.'sm.t'.'aoba'.'o.com
	public static function ksortary($ary, $orderStr = 'order', $type = 1)
	{
		$newary = array();
		if (!$ary) {
			return array();
		}
		foreach ($ary as $key => $val) {
			if ($orderStr != 'order' || $val['type'] != $type) {
				$newary[$val[$orderStr]] = $val;
			}
		}
		ksort($newary);
		return $newary;
	}
	public static function GetTypeArr($str)
	{
		$tclx_type = array();
		if (!$str) {
			return array();
		}
		foreach (explode("\r\n", $str) as $key => $val) {
			$type = explode('|', $val);
			if ($type[0]) {
				$tclx_type[$key]['type1'] = $type[0];
				$tclx_type[$key]['type2'] = $type[1];
				if ($type[2]) {
					$tclx_type[$key]['extend1'] = $type[2];
				}
				if ($type[3]) {
					$tclx_type[$key]['extend2'] = $type[3];
				}
			}
		}
		return $tclx_type;
	}
	public static function RetMsgJson($arr, $isecho = true)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$arr = self::iconvArrayA($arr);
		}
		if ($isecho) {
			echo json_encode($arr);
			exit(0);
		} else {
			return json_encode($arr);
		}
	}
	public static function iconvArrayA($data, $in_charset = 'gbk', $out_charset = 'utf-8')
	{
		if (is_array($data)) {
			foreach ($data as $key => $val) {
				$dataA[$key] = self::iconvArrayA($val, $in_charset, $out_charset);
			}
			return $dataA;
		}
		return iconv($in_charset, $out_charset, $data);
	}
	public static function diconv_out_nowiconv($arr)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$arr = self::iconvArrayA($arr, 'utf-8', 'gbk');
			return $arr;
		}
		return $arr;
	}
	public static function diconvarr_out_utf8($arr)
	{
		if (strtolower(CHARSET) == 'gbk') {
			$arr = self::iconvArrayA($arr, 'gbk', 'utf-8');
			return $arr;
		}
		return $arr;
	}
	public static function get_select($name, $data, $selected, $initial)
	{
		$select = '<select name="' . $name . '" id="' . $name . '">';
		if ($initial) {
			$select .= '<option value="' . $initial[0] . '">' . $initial[1] . '</option>';
		}
		foreach ($data as $v) {
			$sed = $selected == $v[0] ? 'selected' : '';
			$select .= '<option value="' . $v[0] . '" ' . $sed . '>' . $v[1] . '</option>';
		}
		$select .= '</select>';
		return $select;
	}
	public static function getForumStyleByfid($fid)
	{
		global $setting;
		if (!$setting) {
			$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
			$setting = (array) unserialize($setting['guiigo_manage']);
		}
		$forumlist = array();
		foreach ($setting['forumstyle'] as $forum) {
			if ($forum['forum_id'] == $fid) {
				$forumlist = $forum;
				break;
			}
		}
		return $forumlist;
	}
	public static function isGroup($fid)
	{
		$info = C::t('forum_forum')->fetch_info_by_fid($fid);
		return $info['status'] == 3 ? true : false;
	}
	//dis'.'m.tao'.'bao.com
	public static function getUserGroupByUid($uid)
	{
		global $_G;
		if (!$uid) {
			return NULL;
		}
		$res = DB::fetch_all('SELECT g.fid,f.fid,f.name,fd.fid,fd.icon FROM %t g
				 LEFT JOIN %t f ON  f.fid=g.fid 
				 LEFT JOIN %t fd ON fd.fid=g.fid 
				 WHERE g.uid=%d', array('forum_groupuser', 'forum_forum', 'forum_forumfield', $uid));
		$forum = array();
		foreach ($res as $k => $val) {
			$forum[$k] = $val;
			$forum[$k]['url'] = 'forum.php?mod=group&fid=' . $val['fid'];
			$forum[$k]['icon'] = $val['icon'] ? $_G['setting']['attachurl'] . 'group/' . $val['icon'] : '';
		}
		return $forum;
	}
	public static function getForumIconByFid($fid, $type = 1)
	{
		global $_G;
		if (!$fid) {
			return NULL;
		}
		$icon = DB::result_first('SELECT icon FROM %t WHERE fid=%d', array('forum_forumfield', $fid));
		$dir = 'common/';
		if ($type == 2) {
			$dir = 'forum/';
		} elseif ($type == 3) {
			$dir = 'group/';
		}
		return $icon ? $_G['setting']['attachurl'] . $dir . $icon : '';
	}
	public static function GetVisitorByUid($uid, $start, $perpage)
	{
		$count = C::t('home_visitor')->count_by_uid($uid);
		$list = array();
		if ($count) {
			$visitors = C::t('home_visitor')->fetch_all_by_uid($uid, $start, $perpage);
			foreach ($visitors as $value) {
				$value['uid'] = $value['vuid'];
				$value['username'] = $value['vusername'];
				$list[$value['uid']] = $value;
			}
		}
		return $list;
	}
	public static function getStickBlogs($uid, $blogid)
	{
		$res = false;
		$space = array();
		$space['uid'] = $uid;
		space_merge($space, 'field_home');
		$stickblogs = explode(',', $space['stickblogs']);
		$stickblogs = array_filter($stickblogs);
		if (!empty($stickblogs) && in_array($blogid, $stickblogs)) {
			$res = true;
		}
		return $res;
	}
	public static function fetch_all_get_post($where, $start, $perpage, $roder = false)
	{
		if (!$roder) {
			$roder = ' BY p.dateline DESC,t.views DESC,t.favtimes DESC,t.comments DESC ';
		}
		$wheresql = array();
		if ($where['fid']) {
			if (!is_array($where['fid'])) {
				$where['fid'] = explode(',', $where['fid']);
			}
			$wheresql[] = 'p.' . DB::field('fid', $where['fid']);
		}
		if ($where['noauthorid']) {
			$wheresql[] = 't.' . DB::field('authorid', $where['noauthorid'], '<>');
		}
		if ($where['authorid']) {
			if (!is_array($where['authorid'])) {
				$where['authorid'] = explode(',', $where['authorid']);
			}
			$wheresql[] = 'p.' . DB::field('authorid', $where['authorid']);
		}
		$wheresql[] = 'p.' . DB::field('first', 1);
		$wheresql[] = 'p.' . DB::field('invisible', 0);
		$wheresql[] = 'p.' . DB::field('anonymous', 0);
		$wheresql[] = 'p.' . DB::field('status', 1, '<>');
		if ($where['digest']) {
			$wheresql[] = 't.' . DB::field('digest', $where['digest'], '>=');
		}
		if ($where['special']) {
			if ($where['special'] == 'all') {
				$where['special'] = 0;
			}
			$wheresql[] = 't.' . DB::field('special', $where['special']);
		}
		if ($where['attachment']) {
			$wheresql[] = 't.' . DB::field('attachment', $where['attachment']);
		}
		$wheresql[] = 't.' . DB::field('closed', 0);
		if (!$where['noisgroup']) {
			$wheresql[] = 't.' . DB::field('isgroup', $where['isgroup'] ? $where['isgroup'] : 0);
		}
		if (!$wheresql) {
			$wheresql[] = '0';
		}
		return DB::fetch_all('SELECT p.*,t.*
			FROM %t p
			LEFT JOIN %t t on t.tid=p.tid
			WHERE %i
			ORDER ' . $roder . ' ' . DB::limit($start, $perpage), array('forum_post', 'forum_thread', implode(' AND ', $wheresql)));
	}
	public static function fetch_all_get_Portal_post($where, $start, $perpage, $roder = false)
	{
		if (!$roder) {
			$roder = ' BY a.dateline DESC ';
		}
		$wheresql = array();
		if ($where['catid']) {
			if (!is_array($where['catid'])) {
				$where['catid'] = explode(',', $where['catid']);
			}
			$wheresql[] = 'a.' . DB::field('catid', $where['catid']);
		}
		if ($where['pic']) {
			$wheresql[] = 'a.' . DB::field('pic', '', '<>');
		}
		if ($where['uid']) {
			if (!is_array($where['uid'])) {
				$where['uid'] = explode(',', $where['uid']);
			}
			$wheresql[] = 'a.' . DB::field('uid', $where['uid']);
		}
		$wheresql[] = 'a.' . DB::field('status', 0);
		if (!$wheresql) {
			$wheresql[] = '0';
		}
		$data = DB::fetch_all('SELECT a.*,b.*,c.cid,c.id,c.idtype,c.content 
			FROM %t a
			LEFT JOIN %t b on b.aid=a.aid 
			LEFT JOIN %t c on c.aid=a.aid
			WHERE %i
			ORDER ' . $roder . ' ' . DB::limit($start, $perpage), array('portal_article_title', 'portal_article_count', 'portal_article_content', implode(' AND ', $wheresql)));
		$resdata = array();
		foreach ($data as $k => $val) {
			$resdata[$k] = $val;
			$resdata[$k]['attachment'] = self::get_Portal_pic($val['aid'], false);
		}
		return $resdata;
	}
	//dis'.'m.t'.'ao'.'bao.com
	public static function article_title_style($value = array())
	{
		$style = array();
		$highlight = '';
		if ($value['highlight']) {
			$style = explode('|', $value['highlight']);
			$highlight = ' style="';
			$highlight .= $style[0] ? 'color: ' . $style[0] . ';' : '';
			$highlight .= $style[1] ? 'font-weight: bold;' : '';
			$highlight .= $style[2] ? 'font-style: italic;' : '';
			$highlight .= $style[3] ? 'text-decoration: underline;' : '';
			$highlight .= '"';
		}
		return $highlight;
	}
	public static function fetch_article_url($article)
	{
		global $_G;
		if (!empty($_G['setting']['makehtml']['flag']) && $article && $article['htmlmade']) {
			if (empty($_G['cache']['portalcategory'])) {
				loadcache('portalcategory');
			}
			$caturl = '';
			if (!empty($_G['cache']['portalcategory'][$article['catid']])) {
				$topid = $_G['cache']['portalcategory'][$article['catid']]['topid'];
				$caturl = $_G['cache']['portalcategory'][$topid]['domain'] ? $_G['cache']['portalcategory'][$topid]['caturl'] : '';
			}
			return $caturl . $article['htmldir'] . $article['htmlname'] . '.' . $_G['setting']['makehtml']['extendname'];
		}
		return 'portal.php?mod=view&aid=' . $article['aid'];
	}
	public static function get_Portal_pic($aid, $isthumb = true)
	{
		if (!$aid) {
			return array();
		}
		$query = DB::fetch_all('SELECT * FROM ' . DB::table('portal_attachment') . ' WHERE isimage=1 AND aid=' . $aid . '');
		$resdata = array();
		foreach ($query as $k => $value) {
			$resdata[$k] = $value;
			if ($value['isimage']) {
				$resdata[$k]['attachment'] = self::pic_get($value['attachment'], 'portal', $isthumb, $value['remote'], 1);
			}
		}
		return $resdata;
	}
	public static function pic_get($filepath, $type, $thumb, $remote, $return_thumb = 1, $hastype = '')
	{
		global $_G;
		$url = $filepath;
		if ($return_thumb && $thumb) {
			$url = getimgthumbname($url);
		}
		if ($remote > 1 && $type == 'album') {
			$remote -= 2;
			$type = 'forum';
		}
		$type = $hastype ? '' : $type . '/';
		return ($remote ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . $type . $url;
	}
	public static function GetPostlist($postlist, $isthumbnail = false, $nocache = 0, $w = 140, $h = 140)
	{
		$tids = array();
		foreach ($postlist as $k => $v) {
			$tids[] = $v['tid'];
		}
		$result = DB::fetch_all('SELECT pid,tid,message,first,authorid,dateline,anonymous,invisible,status,comment,subject FROM ' . DB::table('forum_post') . ' WHERE tid in(' . dimplode($tids) . ')');
		return self::Assembly($result, $tids, $isthumbnail, $nocache, $w, $h);
	}
	public static function GetGoruplist($tid, $isthumbnail = false, $nocache = 0, $w = 140, $h = 140)
	{
		$result = DB::fetch_all('SELECT p.*,t.* FROM %t p LEFT JOIN %t t on t.tid=p.tid WHERE p.tid=%d', array('forum_post', 'forum_thread', $tid));
		return self::Assembly($result, array($tid), $isthumbnail, $nocache, $w, $h);
	}
	public static function get_pid($tid)
	{
		return DB::fetch_all('SELECT pid,first FROM %t WHERE tid=%d', array('forum_post', $tid));
	}
	public static function getpostfirstbypid($tid)
	{
		return DB::fetch_first('SELECT pid,authorid FROM %t WHERE tid=%d AND first=1', array('forum_post', $tid));
	}
	public static function Assembly($result, $tids, $isthumbnail = false, $nocache = 0, $w = 140, $h = 140)
	{
		$resultlist = array();
		foreach ($tids as $v) {
			foreach ($result as $val) {
				$attachpic = self::AttachImg($val['tid'], $isthumbnail, $nocache, $w, $h);
				if ($v == $val['tid']) {
					$resultlist[$val['pid']] = $val;
					$message = preg_replace('/\\[i=([A-Z]+)\\]\\s*(.*?)\\s*((\\[\\/i\\])|\\.\\.\\.)/is', '', $val['message']);
					$message = preg_replace('/[\\s]+/is', ' ', preg_replace('/\\[[a-z][^\\]]*\\]|\\[\\/[a-z]+\\]/i', '', preg_replace('/\\[attach\\]\\d+\\[\\/attach\\]/i', '', $message)));
					$_message = substr($message, 0, strlen($val['subject'])) == $val['subject'] ? '' : $message;
					$resultlist[$val['pid']]['message'] = $_message;
					$resultlist[$val['pid']]['attapic'] = $attachpic[$val['pid']];
					$resultlist[$val['pid']]['first'] = $val['first'];
					$resultlist[$val['pid']]['authorid'] = $val['authorid'];
					$resultlist[$val['pid']]['dateline'] = $val['dateline'];
					$resultlist[$val['pid']]['anonymous'] = $val['anonymous'];
					$resultlist[$val['pid']]['invisible'] = $val['invisible'];
					$resultlist[$val['pid']]['status'] = $val['status'];
					$resultlist[$val['pid']]['comment'] = $val['comment'];
				}
			}
		}
		return $resultlist;
	}
	public static function AttachImg($tid, $isthumbnail = false, $nocache = 0, $w = 140, $h = 140)
	{
		global $_G;
		$aidtb = getattachtablebytid($tid);
		if ($aidtb == 'forum_attachment_unused') {
			return NULL;
		}
		$attachlist = DB::fetch_all('SELECT aid,pid,readperm,price,attachment,remote,filesize,description FROM %t WHERE tid=%d and isimage=1', array($aidtb, $tid));
		$attachs = array();
		foreach ($attachlist as $attach) {
			$attachurl = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . 'forum/';
			$imgsize = getimagesize($attachurl . $attach['attachment']);
			if ($imgsize[0] >= 50 && $imgsize[1] >= 50) {
				if (empty($attach['readperm']) && empty($attach['price'])) {
					if ($isthumbnail) {
						$attachs[$attach['pid']][] = array(getforumimg($attach['aid'], $nocache, $w, $h), $attach['description']);
					} else {
						$attachs[$attach['pid']][] = array($attachurl . $attach['attachment'], $attach['description'], $attach['aid']);
					}
				}
			}
		}
		return $attachs;
	}
	public static function getUserList($uid, $table, $type = null)
	{
		if (!$uid) {
			return '';
		}
		if (in_array($table, array('status', 'verify', 'count', 'field_forum'))) {
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('common_member_' . $table, $uid));
		}
		if ($table == 'favorite' && $type) {
			$favorite = array();
			$result = DB::fetch_all('SELECT * FROM %t WHERE uid=%d and idtype=\'' . $type . '\'', array('home_' . $table, $uid));
			foreach ($result as $v) {
				$favorite[$v['id']]['id'] = $v['id'];
				$favorite[$v['id']]['favid'] = $v['favid'];
			}
			return $favorite;
		}
		if ($table == 'follow') {
			$follow = array();
			$result = DB::fetch_all('SELECT * FROM %t WHERE uid=%d', array('home_' . $table, $uid));
			foreach ($result as $v) {
				$follow[] = $v['followuid'];
			}
			return $follow;
		}
		if ($table == 'count') {
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('common_member_' . $table, $uid));
		}
		if ($table == 'profile') {
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('common_member_' . $table, $uid));
		}
	}
	//d'.'i'.'sm.ta'.'o'.'bao.com
	public static function getUserStars($uid)
	{
		if (!$uid) {
			return NULL;
		}
		$user = getuserbyuid($uid);
		return DB::result_first('select stars from %t where groupid=%d', array('common_usergroup', $user['groupid']));
	}
	public static function getrecommendbyid($tid, $uid = '', $page = 1, $perpage = 10)
	{
		if ($uid === 0) {
			return '';
		}
		if ($uid && $tid) {
			return DB::result_first('SELECT recommenduid FROM %t WHERE recommenduid=%d AND tid=%d', array('forum_memberrecommend', $uid, $tid));
		}
		if ($tid) {
			$start = ($page - 1) * $perpage;
			return DB::fetch_all('SELECT a.recommenduid,a.dateline,b.username,b.uid FROM %t a LEFT JOIN %t b on b.uid=a.recommenduid WHERE a.tid=' . $tid . ' AND b.status=0 ORDER BY a.dateline DESC ' . DB::limit($start, $perpage), array('forum_memberrecommend', 'common_member', $tid));
		}
	}
	public static function geforumbyuid($getbz, $fid, $page = 1, $perpage = 5)
	{
		global $_G;
		$forum = $_G['forum']['moderators'];
		if (!$forum) {
			$_forum = C::t('forum_forumfield')->fetch($fid);
			$forum = $_forum['moderators'];
		}
		$uids = array();
		foreach (explode('	', $forum) as $k => $username) {
			$uids[$k] = DB::result_first('SELECT uid FROM %t WHERE username LIKE %s', array('common_member', stripsearchkey($username) . '%'));
		}
		$start = ($page - 1) * $perpage;
		if ($getbz) {
			$_falist = DB::fetch_all('SELECT a.favid,a.id,a.dateline,b.username,b.uid,c.gender,c.realname FROM %t a LEFT JOIN %t b on a.uid=b.uid LEFT JOIN %t c on a.uid=c.uid WHERE a.uid IN (' . dimplode($uids) . ') AND a.id=%d AND a.idtype=%s AND b.status=0 ORDER BY a.dateline DESC ' . DB::limit($start, $perpage), array('home_favorite', 'common_member', 'common_member_profile', $fid, 'fid'));
		} else {
			$_falist = DB::fetch_all('SELECT a.favid,a.id,a.dateline,b.username,b.uid,c.gender,c.realname FROM %t a LEFT JOIN %t b on a.uid=b.uid LEFT JOIN %t c on a.uid=c.uid WHERE a.id=%d AND a.idtype=%s AND b.status=0 ORDER BY a.dateline DESC ' . DB::limit($start, $perpage), array('home_favorite', 'common_member', 'common_member_profile', $fid, 'fid'));
		}
		$favoritedata = array();
		foreach ($_falist as $key => $val) {
			$favoritedata[$key] = $val;
		}
		return array('bzlist' => $favoritedata, 'uids' => $uids);
	}
	public static function DateFormatting($arr)
	{
		if (is_array($arr)) {
			return dgmdate(TIMESTAMP + $arr[0] * 86400 + $arr[1] * 3600 + $arr[2] * 60, 'Y-m-d h:i:s');
		}
		if (is_int($arr) && substr($arr) < 10) {
			$arr = $arr + TIMESTAMP;
		} else {
			$arr = dmktime($arr);
		}
		return dgmdate($arr, 'Y-m-d h:i:s');
	}
	public function gethotreplybyid($pid, $uid)
	{
		if (!$uid) {
			return '';
		}
		return DB::result_first('SELECT pid FROM %t WHERE pid=%d AND uid=%d', array('forum_hotreply_member', $pid, $uid));
	}
	public static function get_block_htnl($bids)
	{
		include_once libfile('function/block');
		block_get_batch($bids);
		$bidsary = is_array($bids) ? $bids : ($bids ? explode(',', $bids) : array());
		$datahtml = '';
		foreach ($bidsary as $bid) {
			$datahtml .= block_fetch_content($bid);
		}
		return $datahtml;
	}
	public static function getgrouplist($fid)
	{
		global $_G;
		$groupcache = getgroupcache($fid, array('replies', 'views', 'digest', 'lastpost', 'ranking', 'activityuser', 'newuserlist'), 604800);
		$activityuserlist = array();
		$activityuserlist = array_slice($groupcache['activityuser']['data'], 0, 8);
		return $activityuserlist;
	}
}
//From: d'.'is'.'m.tao'.'ba'.'o.com