<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
$config = GuiigoApp::config();
GuiigoApp::verifyKey();
require_once libfile('function/forumlist');
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
if (!submitcheck('settingsubmit')) {
	$forumstyle_select = array();
	$forumstyle_select[] = array(1, lang('plugin/guiigo_manage', 'slang0151'));
	$forumstyle_select[] = array(2, lang('plugin/guiigo_manage', 'slang0152'));
	$regsbjimg = implode(PHP_EOL, $setting['regconfig']['regsbjimg']);
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0153'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0154'), '', '', GuiigoApp::get_select('settingnew[regstyle]', $forumstyle_select, $setting['regconfig']['regstyle'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showsetting(lang('plugin/guiigo_manage', 'slang0155'), 'settingnew[regslogo]', $setting['regconfig']['regslogo'], 'text', '', '', '');
	showsetting(lang('plugin/guiigo_manage', 'slang0156'), 'settingnew[regsbjimg]', $regsbjimg, 'textarea', '', '', lang('plugin/guiigo_manage', 'slang0150'));
	showsetting(lang('plugin/guiigo_manage', 'slang0157'), 'settingnew[regstext]', $setting['regconfig']['regstext'], 'text', '', '', '');
	showtablefooter();/*Dism��taobao��com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism_taobao_com*/
} else {
	if ($_GET['settingnew']['regsbjimg']) {
		$_GET['settingnew']['regsbjimg'] = (array) explode(PHP_EOL, $_GET['settingnew']['regsbjimg']);
	}
	$setting['regconfig'] = $_GET['settingnew'];
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}