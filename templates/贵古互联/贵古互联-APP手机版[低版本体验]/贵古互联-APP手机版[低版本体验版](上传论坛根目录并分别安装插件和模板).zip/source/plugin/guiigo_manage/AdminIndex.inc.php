<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
$config = GuiigoApp::config();
require_once libfile('function/forumlist');
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
if (!submitcheck('settingsubmit')) {
	$forum_style_select = array();
	$forum_style_select[] = array(1, lang('plugin/guiigo_manage', 'slang0023'));
	$forum_style_select[] = array(2, lang('plugin/guiigo_manage', 'slang0024'));
	$forum_style_select[] = array(3, lang('plugin/guiigo_manage', 'slang0025'));
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0077'), 'nobottom');
	showsetting(lang('plugin/guiigo_manage', 'slang0078'), 'settingnew[second_level_channel]', $setting['second_level_channel'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0052'), 'settingnew[module_ids]', $setting['module_ids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0053'));
	showsetting(lang('plugin/guiigo_manage', 'slang0079'), 'settingnew[user_interest]', $setting['user_interest'], 'radio', '', '', lang('plugin/guiigo_manage', 'slang0080'));
	showsetting(lang('plugin/guiigo_manage', 'slang0081'), 'settingnew[user_follow_uids]', $setting['user_follow_uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0009'));
	showsetting(lang('plugin/guiigo_manage', 'slang0082'), array('settingnew[recommend_content]', array(array('nocontent', lang('plugin/guiigo_manage', 'slang0083'), array('forum' => 'none', 'Portal' => 'none', 'group' => 'none')), array('forum', lang('plugin/guiigo_manage', 'slang0055'), array('forum' => '', 'Portal' => 'none', 'group' => 'none')), array('Portal', lang('plugin/guiigo_manage', 'slang0056'), array('forum' => 'none', 'Portal' => '', 'group' => 'none')), array('group', lang('plugin/guiigo_manage', 'slang0057'), array('forum' => 'none', 'Portal' => 'none', 'group' => '')))), $setting['recommend_content'], 'mradio2');
	showtagheader('tbody', 'forum', $setting['forum'], 'sub');
	showsetting(lang('plugin/guiigo_manage', 'slang0058'), '', '', '<select name="settingnew[forum][forumids][]" multiple="multiple" size="10">' . forumselect(0, 0, $setting['forum']['forumids'], true) . '</select>');
	showsetting(lang('plugin/guiigo_manage', 'slang0059'), 'settingnew[forum][digest]', $setting['forum']['digest'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0060'), 'settingnew[forum][isimg]', $setting['forum']['isimg'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0061'), 'settingnew[forum][uids]', $setting['forum']['uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0062'));
	showsetting(lang('plugin/guiigo_manage', 'slang0063'), '', '', GuiigoApp::get_select('settingnew[forum][style]', $forum_style_select, $setting['forum']['style'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showtagfooter('tbody');
	showtagheader('tbody', 'Portal', $setting['Portal'], 'sub');
	$portalcpselect = category_showselect('portal', $setting['Portal']['Portalids']);
	showsetting(lang('plugin/guiigo_manage', 'slang0064'), '', '', '<select name="settingnew[Portal][Portalids][]" multiple="multiple" size="10">' . $portalcpselect . '</select>');
	showsetting(lang('plugin/guiigo_manage', 'slang0060'), 'settingnew[Portal][isimg]', $setting['Portal']['isimg'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0065'), 'settingnew[Portal][uids]', $setting['Portal']['uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0062'));
	showtagfooter('tbody');
	showtagheader('tbody', 'group', $setting['group'], 'sub');
	showsetting(lang('plugin/guiigo_manage', 'slang0067'), 'settingnew[group][groupids]', $setting['group']['groupids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0142'));
	showsetting(lang('plugin/guiigo_manage', 'slang0059'), 'settingnew[group][digest]', $setting['group']['digest'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0060'), 'settingnew[group][isimg]', $setting['group']['isimg'], 'radio');
	showsetting(lang('plugin/guiigo_manage', 'slang0061'), 'settingnew[group][uids]', $setting['group']['uids'], 'text', '', '', lang('plugin/guiigo_manage', 'slang0062'));
	showsetting(lang('plugin/guiigo_manage', 'slang0063'), '', '', GuiigoApp::get_select('settingnew[group][style]', $forum_style_select, $setting['group']['style'], array(0, lang('plugin/guiigo_manage', 'slang0028'))));
	showtagfooter('tbody');
	showtablefooter();/*Dism��taobao��com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism_taobao_com*/
} else {
	if ($_POST['settingnew']['recommend_content'] == 'nocontent') {
		$_POST['settingnew']['forum'] = array();
		$_POST['settingnew']['Portal'] = array();
		$_POST['settingnew']['group'] = array();
	} elseif ($_POST['settingnew']['recommend_content'] == 'forum') {
		$_POST['settingnew']['Portal'] = array();
		$_POST['settingnew']['group'] = array();
	} elseif ($_POST['settingnew']['recommend_content'] == 'Portal') {
		$_POST['settingnew']['forum'] = array();
		$_POST['settingnew']['group'] = array();
	} elseif ($_POST['settingnew']['recommend_content'] == 'group') {
		$_POST['settingnew']['forum'] = array();
		$_POST['settingnew']['Portal'] = array();
	}
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize(array_merge($setting, $_POST['settingnew']))));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
function category_showselect($type, $current = array(), $shownull = true)
{
	global $_G;
	if (!in_array($type, array('portal', 'blog', 'album'))) {
		return '';
	}
	loadcache($type . 'category');
	$category = $_G['cache'][$type . 'category'];
	$select = '';
	if ($shownull) {
		$select .= '<option value="">' . lang('portalcp', 'select_category') . '</option>';
	}
	foreach ($category as $value) {
		if ($value['level'] == 0) {
			$selected = in_array($value['catid'], $current) ? 'selected="selected"' : '';
			$select .= '<option value="' . $value['catid'] . '"' . $selected . '>' . $value['catname'] . '</option>';
			if ($value['children']) {
				foreach ($value['children'] as $catid) {
					$selected = in_array($catid, $current) ? 'selected="selected"' : '';
					$select .= '<option value="' . $category[$catid][catid] . '"' . $selected . '>-- ' . $category[$catid][catname] . '</option>';
					if ($category[$catid]['children']) {
						foreach ($category[$catid]['children'] as $catid2) {
							$selected = in_array($catid2, $current) ? 'selected="selected"' : '';
							$select .= '<option value="' . $category[$catid2][catid] . '"' . $selected . '>----' . $category[$catid2][catname] . '</option>';
						}
					}
				}
			}
		}
	}
	return $select;
}