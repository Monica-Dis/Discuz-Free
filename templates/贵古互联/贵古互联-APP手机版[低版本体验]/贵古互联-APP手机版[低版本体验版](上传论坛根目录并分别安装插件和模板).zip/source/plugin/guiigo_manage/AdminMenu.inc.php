<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once libfile('class/GuiigoApp', 'plugin/guiigo_manage');
$config = GuiigoApp::config();
$setting = C::t('common_setting')->fetch_all(array('guiigo_manage'));
$setting = (array) unserialize($setting['guiigo_manage']);
$basicurl = 'plugins&operation=config&do=' . $_G['gp_do'] . '&identifier=guiigo_manage&pmod=' . $_GET['pmod'];
if (!submitcheck('settingsubmit')) {
	showformheader($basicurl, 'enctype');
	showtableheader(lang('plugin/guiigo_manage', 'slang0105'), 'nobottom');
	showsubtitle(array(lang('plugin/guiigo_manage', 'slang0106'), lang('plugin/guiigo_manage', 'slang0107'), lang('plugin/guiigo_manage', 'slang0108')), 'header', array('class="td31"'));
	$global_broadside_menu = broadside_menu_array_merge($setting['menuconfig']['global_broadside_menu']);
	foreach ($global_broadside_menu as $key => $value) {
		$checked = '';
		if ($value['global_broadside_menu_open']) {
			$checked = 'checked';
		}
		$deleterow = '<td><div><a href="javascript:;"></a></div></td>';
		$readonly = 'readonly';
		if (!$value['global_broadside_menu_default']) {
			$deleterow = '<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . lang('plugin/guiigo_manage', 'slang0043') . '</a></div></td>';
			$readonly = '';
		}
		showtablerow('', array('class="td31"', 'class="rowform"', 'class="rowform"', 'class="td31"', 'class="td25"'), array('<input type="text" class="txt" name="settingnew[global_broadside_menu_name][' . $key . ']" value="' . $value['global_broadside_menu_name'] . '"  ' . $readonly . '/>', '<input type="text" class="txt" name="settingnew[global_broadside_menu_icon][' . $key . ']" value="' . $value['global_broadside_menu_icon'] . '"  ' . $readonly . '/>', '<input type="text" class="txt" name="settingnew[global_broadside_menu_link][' . $key . ']" value="' . $value['global_broadside_menu_link'] . '"  ' . $readonly . '/>', lang('plugin/guiigo_manage', 'slang0109') . '<input type="checkbox" class="txt" name="settingnew[global_broadside_menu_open][' . $key . ']" value="1" ' . $checked . '/>', '<input type="hidden" name="settingnew[global_broadside_menu_default][' . $key . ']" value="' . $value['global_broadside_menu_default'] . '"/>' . $deleterow));
	}
	echo '<tr><td><div><a href="javascript:;" onclick="addrow(this, 0);" class="addtr">' . lang('plugin/guiigo_manage', 'slang0110') . '</a></div></td></tr>';
	unset($value);
	showtablefooter();/*Dism��taobao��com*/
	showtableheader(lang('plugin/guiigo_manage', 'slang0112'), 'nobottom');
	showsubtitle(array(lang('plugin/guiigo_manage', 'slang0106'), lang('plugin/guiigo_manage', 'slang0107'), lang('plugin/guiigo_manage', 'slang0108')), 'header', array('class="td31"'));
	$global_personage_menu = personage_menu_array_merge($setting['menuconfig']['global_personage_menu']);
	foreach ($global_personage_menu as $key => $value) {
		$checked2 = '';
		if ($value['global_personage_menu_open']) {
			$checked2 = 'checked';
		}
		$deleterow2 = '<td><div><a href="javascript:;"></a></div></td>';
		$readonly2 = 'readonly';
		if (!$value['global_personage_menu_default']) {
			$deleterow2 = '<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . lang('plugin/guiigo_manage', 'slang0043') . '</a></div></td>';
			$readonly2 = '';
		}
		showtablerow('', array('class="td31"', 'class="rowform"', 'class="rowform"', 'class="td31"', 'class="td25"'), array('<input type="text" class="txt" name="settingnew[global_personage_menu_name][' . $key . ']" value="' . $value['global_personage_menu_name'] . '"  ' . $readonly2 . '/>', '<input type="text" class="txt" name="settingnew[global_personage_menu_icon][' . $key . ']" value="' . $value['global_personage_menu_icon'] . '"   ' . $readonly2 . '/>', '<input type="text" class="txt" name="settingnew[global_personage_menu_link][' . $key . ']" value="' . $value['global_personage_menu_link'] . '"   ' . $readonly2 . '/>', lang('plugin/guiigo_manage', 'slang0109') . '<input type="checkbox" class="txt" name="settingnew[global_personage_menu_open][' . $key . ']" value="1" ' . $checked2 . '/>', '<input type="hidden" name="settingnew[global_personage_menu_default][' . $key . ']" value="' . $value['global_personage_menu_default'] . '"/>' . $deleterow2));
	}
	echo '<tr><td><div><a href="javascript:;" onclick="addrow(this, 1);" class="addtr">' . lang('plugin/guiigo_manage', 'slang0110') . '</a></div></td></tr>';
	unset($value);
	showtablefooter();/*Dism��taobao��com*/
	showtableheader(lang('plugin/guiigo_manage', 'slang0111'), 'nobottom');
	showsubtitle(array(lang('plugin/guiigo_manage', 'slang0106'), lang('plugin/guiigo_manage', 'slang0107'), lang('plugin/guiigo_manage', 'slang0108')), 'header', array('class="td31"'));
	$global_information_menu = information_menu_array_merge($setting['menuconfig']['global_information_menu']);
	foreach ($global_information_menu as $key => $value) {
		$checked3 = '';
		if ($value['global_information_menu_open']) {
			$checked3 = 'checked';
		}
		$deleterow3 = '<td><div><a href="javascript:;"></a></div></td>';
		$readonly3 = 'readonly';
		if (!$value['global_information_menu_default']) {
			$deleterow3 = '<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . lang('plugin/guiigo_manage', 'slang0043') . '</a></div></td>';
			$readonly3 = '';
		}
		showtablerow('', array('class="td31"', 'class="rowform"', 'class="rowform"', 'class="td31"', 'class="td25"'), array('<input type="text" class="txt" name="settingnew[global_information_menu_name][' . $key . ']" value="' . $value['global_information_menu_name'] . '"  ' . $readonly3 . '/>', '<input type="text" class="txt" name="settingnew[global_information_menu_icon][' . $key . ']" value="' . $value['global_information_menu_icon'] . '"  ' . $readonly3 . '/>', '<input type="text" class="txt" name="settingnew[global_information_menu_link][' . $key . ']" value="' . $value['global_information_menu_link'] . '"  ' . $readonly3 . '/>', lang('plugin/guiigo_manage', 'slang0109') . '<input type="checkbox" class="txt" name="settingnew[global_information_menu_open][' . $key . ']" value="1" ' . $checked3 . ' />', '<input type="hidden" name="settingnew[global_information_menu_default][' . $key . ']" value="' . $value['global_information_menu_default'] . '"/>' . $deleterow3));
	}
	echo '<tr><td><div><a href="javascript:;" onclick="addrow(this, 2);" class="addtr">' . lang('plugin/guiigo_manage', 'slang0110') . '</a></div></td></tr>';
	$txtopen = lang('plugin/guiigo_manage', 'slang0109');
	$txtdel = lang('plugin/guiigo_manage', 'slang0043');
	echo '	<script type="text/JavaScript">
		var rowtypedata = [
			[
					[0,\'<input type="text" class="txt" name="settingnew[global_broadside_menu_name][]" value="">\', \'td31\'],
					[0,\'<input type="text" class="txt" name="settingnew[global_broadside_menu_icon][]" value="">\', \'rowform\'],
					[0,\'<input type="text" class="txt" name="settingnew[global_broadside_menu_link][]" value="">\', \'rowform\'],
					[0,\'' . $txtopen . '<input type="checkbox" class="text" name="settingnew[global_broadside_menu_open][]" value="1" checked>\', \'td31\'],
					[0,\'<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . $txtdel . '</a></div></td>\'],
				
			],
			[
				[0,\'<input type="text" class="txt" name="settingnew[global_personage_menu_name][]" value="">\', \'td31\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_personage_menu_icon][]" value="">\', \'rowform\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_personage_menu_link][]" value="">\', \'rowform\'],
				[0,\'' . $txtopen . '<input type="checkbox" class="text" name="settingnew[global_personage_menu_open][]" value="1" checked>\', \'td31\'],
				[0,\'<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . $txtdel . '</a></div></td>\']
			],
			[
				[0,\'<input type="text" class="txt" name="settingnew[global_information_menu_name][]" value="">\', \'td31\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_information_menu_icon][]" value="">\', \'rowform\'],
				[0,\'<input type="text" class="txt" name="settingnew[global_information_menu_link][]" value="">\', \'rowform\'],
				[0,\'' . $txtopen . '<input type="checkbox" class="text" name="settingnew[global_personage_menu_open][]" value="1" checked>\', \'td31\'],
				[0,\'<td><div><a href="javascript:;" onclick="deleterow(this);" class="deleterow">' . $txtdel . '</a></div></td>\']
			]
		];
	</script>';
	unset($value);
	showtablefooter();/*Dism��taobao��com*/
	showtableheader('', 'notop');
	showsubmit('settingsubmit');
	showtablefooter();/*Dism��taobao��com*/
	showformfooter();/*Dism_taobao_com*/
} else {
	$newdata = array();
	$newdata['global_broadside_menu'] = array();
	foreach ($_POST['settingnew']['global_broadside_menu_name'] as $key => $val) {
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_name'] = $_POST['settingnew']['global_broadside_menu_name'][$key];
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_icon'] = $_POST['settingnew']['global_broadside_menu_icon'][$key];
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_link'] = $_POST['settingnew']['global_broadside_menu_link'][$key];
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_open'] = !empty($_POST['settingnew']['global_broadside_menu_open'][$key]) ? 1 : 0;
		$newdata['global_broadside_menu'][$key]['global_broadside_menu_default'] = $_POST['settingnew']['global_broadside_menu_default'][$key];
	}
	$newdata['global_personage_menu'] = array();
	foreach ($_POST['settingnew']['global_personage_menu_name'] as $key => $val) {
		$newdata['global_personage_menu'][$key]['global_personage_menu_name'] = $_POST['settingnew']['global_personage_menu_name'][$key];
		$newdata['global_personage_menu'][$key]['global_personage_menu_icon'] = $_POST['settingnew']['global_personage_menu_icon'][$key];
		$newdata['global_personage_menu'][$key]['global_personage_menu_link'] = $_POST['settingnew']['global_personage_menu_link'][$key];
		$newdata['global_personage_menu'][$key]['global_personage_menu_open'] = !empty($_POST['settingnew']['global_personage_menu_open'][$key]) ? 1 : 0;
		$newdata['global_personage_menu'][$key]['global_personage_menu_default'] = $_POST['settingnew']['global_personage_menu_default'][$key];
	}
	$newdata['global_information_menu'] = array();
	foreach ($_POST['settingnew']['global_information_menu_name'] as $key => $val) {
		$newdata['global_information_menu'][$key]['global_information_menu_name'] = $_POST['settingnew']['global_information_menu_name'][$key];
		$newdata['global_information_menu'][$key]['global_information_menu_icon'] = $_POST['settingnew']['global_information_menu_icon'][$key];
		$newdata['global_information_menu'][$key]['global_information_menu_link'] = $_POST['settingnew']['global_information_menu_link'][$key];
		$newdata['global_information_menu'][$key]['global_information_menu_open'] = !empty($_POST['settingnew']['global_information_menu_open'][$key]) ? 1 : 0;
		$newdata['global_information_menu'][$key]['global_information_menu_default'] = $_POST['settingnew']['global_information_menu_default'][$key];
	}
	$setting['menuconfig'] = $newdata;
	C::t('common_setting')->update_batch(array('guiigo_manage' => serialize($setting)));
	updatecache('setting');
	cpmsg('setting_update_succeed', dreferer(), 'succeed');
}
function broadside_menu_array_merge($ary)
{
	$newary = array(0 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0113'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-sy.png', 'global_broadside_menu_link' => 'portal.php?mod=index', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 1 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0114'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-sq.png', 'global_broadside_menu_link' => 'forum.php?forumlist=1&do=guanzhu', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 2 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0115'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-qz.png', 'global_broadside_menu_link' => 'group.php?mod=index', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 3 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0116'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-xx.png', 'global_broadside_menu_link' => 'home.php?mod=space&do=pm&filter=privatepm', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 4 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0117'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-tt.png', 'global_broadside_menu_link' => 'portal.php?mod=list&catid=1', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 5 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0118'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-dd.png', 'global_broadside_menu_link' => 'forum.php?mod=guide&view=hot', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 6 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0119'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-xc.png', 'global_broadside_menu_link' => 'home.php?mod=space&do=album&view=all', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 7 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0120'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-sb.png', 'global_broadside_menu_link' => 'home.php?mod=space&do=doing&view=all', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 8 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0121'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-rz.png', 'global_broadside_menu_link' => 'home.php?mod=space&do=blog&view=all', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 9 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0122'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-yp.png', 'global_broadside_menu_link' => 'misc.php?mod=ranklist&type=member&view=post', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 10 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0123'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-tp.png', 'global_broadside_menu_link' => 'misc.php?mod=ranklist&type=thread&view=replies&orderby=all', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 11 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0124'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-bp.png', 'global_broadside_menu_link' => 'misc.php?mod=ranklist&type=forum&view=threads', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 12 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0125'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-qp.png', 'global_broadside_menu_link' => 'misc.php?mod=ranklist&type=group&view=credit', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 13 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0126'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-ss.png', 'global_broadside_menu_link' => 'search.php?mod=forum', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 14 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0127'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-rw.png', 'global_broadside_menu_link' => 'home.php?mod=task', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 15 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0128'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-xz.png', 'global_broadside_menu_link' => 'home.php?mod=medal', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'), 16 => array('global_broadside_menu_name' => lang('plugin/guiigo_manage', 'slang0129'), 'global_broadside_menu_icon' => 'template/guiigo_app/static/images/cgd-bq.png', 'global_broadside_menu_link' => 'misc.php?mod=tag', 'global_broadside_menu_open' => '1', 'global_broadside_menu_default' => '1'));
	if (!$ary) {
		return array_merge($newary, array());
	}
	return $ary;
}
function personage_menu_array_merge($ary)
{
	$newary = array(0 => array('global_personage_menu_name' => lang('plugin/guiigo_manage', 'slang0130'), 'global_personage_menu_icon' => 'template/guiigo_app/static/images/cgd-xc.png', 'global_personage_menu_link' => 'home.php?mod=space&do=album&view=me', 'global_personage_menu_open' => '1', 'global_personage_menu_default' => '1'), 1 => array('global_personage_menu_name' => lang('plugin/guiigo_manage', 'slang0131'), 'global_personage_menu_icon' => 'template/guiigo_app/static/images/cgd-rz.png', 'global_personage_menu_link' => 'home.php?mod=space&do=blog&view=me', 'global_personage_menu_open' => '1', 'global_personage_menu_default' => '1'), 2 => array('global_personage_menu_name' => lang('plugin/guiigo_manage', 'slang0132'), 'global_personage_menu_icon' => 'template/guiigo_app/static/images/cgd-rw.png', 'global_personage_menu_link' => 'home.php?mod=task&item=doing', 'global_personage_menu_open' => '1', 'global_personage_menu_default' => '1'));
	if (!$ary) {
		return array_merge($newary, array());
	}
	return $ary;
}
function information_menu_array_merge($ary)
{
	$newary = array(0 => array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0133'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-a.png', 'global_information_menu_link' => 'forum.php?mod=misc&action=nav', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1'), 1 => array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0134'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-b.png', 'global_information_menu_link' => 'group.php?mod=index', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1'), 2 => array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0135'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-c.png', 'global_information_menu_link' => 'home.php?mod=spacecp&ac=blog', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1'), 3 => array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0136'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-d.png', 'global_information_menu_link' => 'home.php?mod=spacecp&ac=upload', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1'), 4 => array('global_information_menu_name' => lang('plugin/guiigo_manage', 'slang0137'), 'global_information_menu_icon' => 'template/guiigo_app/static/images/xzon-e.png', 'global_information_menu_link' => 'home.php?mod=space&do=doing&view=all', 'global_information_menu_open' => '1', 'global_information_menu_default' => '1'));
	if (!$ary) {
		return array_merge($newary, array());
	}
	return $ary;
}