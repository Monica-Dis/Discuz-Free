<?php

/*
 * xiaoyu uninstall process
 * This is not a freeware, use is subject to license terms
 * From С������Ŷ�(www.minfish.com)
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$finish = TRUE;/*DISM-TAOBAO_COM*/
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_duitangtouch/discuz_plugin_xiaoyu_duitangtouch.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_duitangtouch/discuz_plugin_xiaoyu_duitangtouch_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_duitangtouch/discuz_plugin_xiaoyu_duitangtouch_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_duitangtouch/discuz_plugin_xiaoyu_duitangtouch_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xiaoyu_duitangtouch/discuz_plugin_xiaoyu_duitangtouch_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/xiaoyu_duitangtouch/core.inc.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xiaoyu_duitangtouch/xiaoyu_core.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xiaoyu_duitangtouch/uninstall.php');