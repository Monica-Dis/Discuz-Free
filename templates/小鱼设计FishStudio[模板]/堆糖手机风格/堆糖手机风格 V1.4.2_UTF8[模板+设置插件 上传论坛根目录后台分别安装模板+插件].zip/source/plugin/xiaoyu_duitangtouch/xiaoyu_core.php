<?php

/*
 * xiaoyu process
 * This is not a freeware, use is subject to license terms
 * From С������Ŷ�(www.minfish.com)
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once ('cert.php');
function plugin_ins_error($identifier){
	global $_G;
	cpmsg('plugins_install_succeed', 'action=plugins&hl='.$pluginid, 'succeed');
}

function cloudaddon_open($extra, $post = '') {
	return dfsockopen(cloudaddons_url('&from=s').$extra, 0, $post, '', false, CLOUDADDONS_DOWNLOAD_IP, 999);
}