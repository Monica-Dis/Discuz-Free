<?php echo 'From: DisM.taobao.com';exit;?>
<div id="fishsmile">
  <div id="smile_menu" class="shows" style="display:none">
 
  <div id="replysmiliesdiv_data">
   <table cellspacing="0" cellpadding="0" id="replysmiliesdiv_xiaoyutable">
    <tbody>
     <tr>
      <td id="replysmilie_1_td" onclick="addsmile(':)')" ><img width="20" height="20" alt=":)" src="static/image/smiley/default/smile.gif" id="smilie_1" /></td>
      <td id="replysmilie_2_td" onclick="addsmile(':(')" ><img width="20" height="20" alt=":(" src="static/image/smiley/default/sad.gif" id="smilie_2" /></td>
      <td id="replysmilie_3_td" onclick="addsmile(':D')" ><img width="20" height="20" alt=":D" src="static/image/smiley/default/biggrin.gif" id="smilie_3" /></td>
      <td id="replysmilie_4_td" onclick="addsmile(':\'(')" ><img width="20" height="20" alt=":'(" src="static/image/smiley/default/cry.gif" id="smilie_4" /></td>
      <td id="replysmilie_5_td" onclick="addsmile(':@')" ><img width="20" height="20" alt=":@" src="static/image/smiley/default/huffy.gif" id="smilie_5" /></td>
      <td id="replysmilie_6_td" onclick="addsmile(':o')" ><img width="20" height="20" alt=":o" src="static/image/smiley/default/shocked.gif" id="smilie_6" /></td>
      <td id="replysmilie_7_td" onclick="addsmile(':P')" ><img width="20" height="20" alt=":P" src="static/image/smiley/default/tongue.gif" id="smilie_7" /></td>
      <td id="replysmilie_8_td" onclick="addsmile(':$')" ><img width="20" height="20" alt=":$" src="static/image/smiley/default/skym.gif" id="smilie_8" /></td>
     </tr>
     <tr>
      <td id="replysmilie_9_td" onclick="addsmile(';P')" ><img width="20" height="20" alt=";P" src="static/image/smiley/default/titter.gif" id="smilie_9" /></td>
      <td id="replysmilie_10_td" onclick="addsmile(':L')" ><img width="20" height="20" alt=":L" src="static/image/smiley/default/sweat.gif" id="smilie_10" /></td>
      <td id="replysmilie_11_td" onclick="addsmile(':Q')" ><img width="20" height="20" alt=":Q" src="static/image/smiley/default/mad.gif" id="smilie_11" /></td>
      <td id="replysmilie_12_td" onclick="addsmile(':lol')" ><img width="20" height="20" alt=":lol" src="static/image/smiley/default/lol.gif" id="smilie_12" /></td>
      <td id="replysmilie_13_td" onclick="addsmile(':loveliness:')" ><img width="20" height="20" alt=":loveliness:" src="static/image/smiley/default/loveliness.gif" id="smilie_13" /></td>
      <td id="replysmilie_14_td" onclick="addsmile(':funk:')" ><img width="20" height="20" alt=":funk:" src="static/image/smiley/default/funk.gif" id="smilie_14" /></td>
      <td id="replysmilie_15_td" onclick="addsmile(':curse:')" ><img width="20" height="20" alt=":curse:" src="static/image/smiley/default/curse.gif" id="smilie_15" /></td>
      <td id="replysmilie_16_td" onclick="addsmile(':dizzy:')" ><img width="20" height="20" alt=":dizzy:" src="static/image/smiley/default/dizzy.gif" id="smilie_16" /></td>
     </tr>
     <tr>
      <td id="replysmilie_17_td" onclick="addsmile(':shutup:')" ><img width="20" height="20" alt=":shutup:" src="static/image/smiley/default/shutup.gif" id="smilie_17" /></td>
      <td id="replysmilie_18_td" onclick="addsmile(':sleepy:')" ><img width="20" height="20" alt=":sleepy:" src="static/image/smiley/default/sleepy.gif" id="smilie_18" /></td>
      <td id="replysmilie_19_td" onclick="addsmile(':hug:')" ><img width="20" height="20" alt=":hug:" src="static/image/smiley/default/hug.gif" id="smilie_19" /></td>
      <td id="replysmilie_20_td" onclick="addsmile(':victory:')" ><img width="20" height="20" alt=":victory:" src="static/image/smiley/default/victory.gif" id="smilie_20" /></td>
      <td id="replysmilie_21_td" onclick="addsmile(':time:')" ><img width="20" height="20" alt=":time:" src="static/image/smiley/default/time.gif" id="smilie_21" /></td>
      <td id="replysmilie_22_td" onclick="addsmile(':kiss:')" ><img width="20" height="20" alt=":kiss:" src="static/image/smiley/default/kiss.gif" id="smilie_22" /></td>
      <td id="replysmilie_23_td" onclick="addsmile(':handshake')" ><img width="20" height="20" alt=":handshake" src="static/image/smiley/default/handshake.gif" id="smilie_23" /></td>
      <td id="replysmilie_24_td" onclick="addsmile(':call:')" ><img width="20" height="20" alt=":call:" src="static/image/smiley/default/call.gif" id="smilie_24" /></td>
     </tr>
    </tbody>
   </table>
  </div>
  </div>
</div>
