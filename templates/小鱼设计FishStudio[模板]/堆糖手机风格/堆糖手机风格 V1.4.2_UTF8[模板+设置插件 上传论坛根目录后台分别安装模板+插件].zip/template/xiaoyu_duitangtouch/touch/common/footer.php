<?php echo 'From: DisM.taobao.com';exit;?>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
<!--{if !$nofooter}-->
<!--{if !$xiaoyu_dtset['xiaoyucopy']}-->
<div class="download-app"> 
     &copy; Comsenz Inc. &nbsp;|&nbsp;<a href="{$_G['setting']['mobile']['nomobileurl']}">{lang nomobiletype}</a>
   </div>
<!--{/if}-->   
<div class="xiaoyu_foot_height"></div>
  <div id="xiaoyu_foot_memu" class="xiaoyu_foot_memu bg_f b_t xfixed"> 
   <ul class="xiaoyu_flex">
    <li {if CURMODULE=='guide' && $_GET['show']!='find'}class="cur"{/if}><a href="./" ><i class="f_index"></i><span>首页</span></a></li> 
    <li {if $_GET['show']=='find'}class="cur"{/if}><a href="forum.php?mod=guide&show=find&mobile=2"><i class="f_fx"></i><span>发现</span></a></li> 
    <li {if $_G[basescript]=='forum' && CURMODULE!='guide'}class="cur"{/if}><a href="forum.php?forumlist=1mobile=2"><i class="f_bbs"></i><span>社区</span></a></li> 
    <li {if CURMODULE=='space'}class="cur"{/if}><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="f_me"></i><span>我的</span></a></li> 
   </ul> 
  </div>
<!--{/if}-->
</div>
<div id="mask" style="display:none;"></div>
<script>window.onerror=function(){return true;};
</script>
</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->

