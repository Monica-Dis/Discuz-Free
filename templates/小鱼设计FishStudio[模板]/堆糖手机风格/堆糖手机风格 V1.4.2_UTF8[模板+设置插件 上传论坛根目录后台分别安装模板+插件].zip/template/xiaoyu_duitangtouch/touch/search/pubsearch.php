<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->       
<input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="{lang searchthread}">
<input type="hidden" name="searchsubmit" value="yes">

<button type="submit" value="{lang search}" class="btn_search" id="scform_submit">&#x641c;&#x7d22;</button>



