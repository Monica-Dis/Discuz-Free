<?php echo 'From: DisM.taobao.com';exit;?>
<section class="topic-content"> 
<ul class="base-list topic-list">
<!--{if $threadlist}-->
<!--{loop $threadlist $thread}-->
<!--{template forum/forumdisplay_item}-->
<!--{/loop}-->
<!--{else}-->
<li style="padding-left:0"><h3>{lang search_nomatch}</h3></li>
<!--{/if}-->  
</ul> 
</section>   
<!--{if $multipage}--><div class="xiaoyu_mipage cl">$multipage</div><!--{/if}-->
<!--小鱼.设计56282.8385 -->
