<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<style>.db_page{ background:#f4f4f4}.download-app{ display:none}</style>
<!--{if !$_GET['mycenter']}-->
<!-- userinfo start -->
<div class="userinfo">
<div class="xiaoyu_userhd">
<div class="ghbg" style="background:url({avatar($space[uid], middle, true)}) no-repeat left center;background-size:cover;"></div>
	<div class="user_avatar">
		<div class="avatar_m"><span><img src="<!--{avatar($space[uid], small, true)}-->" /></span></div>
		<h2 class="name">$space[username]</h2>
	</div>
</div>
  <div class="xiaoyu_usermenu"> 
  <div class="xiaoyu_usermenu_group"> 
  <div class="xiaoyu_user_box cl">
		<ul>
			<li><span>$space[credits]</span>{lang credits}</li>
			<!--{loop $_G[setting][extcredits] $key $value}-->
			<!--{if $value[title]}-->
			<li><span>{$space["extcredits$key"]} $value[unit]</span>$value[title]</li>
			<!--{/if}-->
			<!--{/loop}-->
		</ul>
	</div>
    </div>
   <div class="xiaoyu_usermenu_group" style="display:none"> 
    <a href="home.php?mod=space&do=pm"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_club_more_topic.png" class="icon" /><span {if $_G[member][newpm]}style=" padding-right:10px; background:url({STATICURL}image/mobile/images/icon_msg.png) no-repeat right center;"{/if}>{lang mypm}</span></a>
    <a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_club_image.png" class="icon" />{lang mythread}</a>
    <a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_club_check.png" class="icon" />{lang myfavorite}</a>
   </div> 
   <div class="xiaoyu_usermenu_group" style="display:none"> 
    <a href="home.php?mod=space&uid={$_G[uid]}"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_club_more_explore.png" class="icon" />{lang myprofile}</a>
   </div> 
   $xiaoyu_dtset['xiaoyugzcode']
   	<!--{if $space['uid'] == $_G['uid']}-->
	<div class="xiaoyu_btn_exit"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_bind_phone.png" class="icon" />{lang logout_mobile}</a></div>
	<!--{/if}-->
  </div>
</div>


<!-- userinfo end -->

<!--{else}-->

<!-- userinfo start -->
<div class="userinfo">
<div class="xiaoyu_userhd">
<div class="ghbg" style="background:url({avatar($_G[uid], middle, true)}) no-repeat left center;background-size:cover;"></div>
	<div class="user_avatar">
		<div class="avatar_m"><span><img src="<!--{avatar($_G[uid], small, true)}-->" /></span></div>
		<h2 class="name">$_G[username]</h2>
	</div>
</div>
  <div class="xiaoyu_usermenu"> 
   <div class="xiaoyu_usermenu_group"> 
    <a href="home.php?mod=space&do=pm"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_club_more_topic.png" class="icon" /><span {if $_G[member][newpm]}style=" padding-right:10px; background:url({STATICURL}image/mobile/images/icon_msg.png) no-repeat right center;"{/if}>{lang mypm}</span></a>
    <a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_club_image.png" class="icon" />{lang mythread}</a>
    <a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_club_check.png" class="icon" />{lang myfavorite}</a>
   </div> 
   <div class="xiaoyu_usermenu_group"> 
    <a href="home.php?mod=space&uid={$_G[uid]}"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_club_more_explore.png" class="icon" />{lang myprofile}</a>
   </div> 
   $xiaoyu_dtset['xiaoyugzcode']
   	<!--{if $space['uid'] == $_G['uid']}-->
	<div class="xiaoyu_btn_exit"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}"><img src="template/xiaoyu_duitangtouch/touch/style/img/icon_bind_phone.png" class="icon" />{lang logout_mobile}</a></div>
	<!--{/if}-->
  </div>
</div>
<!-- userinfo end -->

<!--{/if}-->
<!--{eval //$nofooter = true;}-->
<!--{template common/footer}-->

