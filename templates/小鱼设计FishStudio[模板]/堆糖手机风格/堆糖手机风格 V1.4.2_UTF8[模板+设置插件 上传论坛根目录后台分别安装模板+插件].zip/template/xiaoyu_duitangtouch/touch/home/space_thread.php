<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<link href="template/xiaoyu_duitangtouch/touch/style/topic_list.css" rel="stylesheet" type="text/css" />
<!-- header start -->
<header class="header">
    <div class="nav">
       <a href="home.php?mod=space&uid=1&do=profile&mycenter=1" class="z"><img src="template/xiaoyu_duitangtouch/touch/style/img/nav_icon_back.png" /></a>
	   <span>{lang mythread}</span>
   </div>
</header>
<!-- header end -->
<div class="bbsnav" style="display:none">
<a href="javascript:;" onclick="history.go(-1);" class="fa backleft fishz"><!--{if $actives[me] && $viewtype=='reply'}--><!--{if $space['uid'] != $_G['uid']}-->{$space[username]}&#x7684;&#x56de;&#x590d;<!--{else}-->&#x6211;&#x7684;&#x56de;&#x590d;<!--{/if}--> 
       <!--{else}--><!--{if $space['uid'] != $_G['uid']}-->{$space[username]}&#x7684;&#x4e3b;&#x9898;<!--{else}-->{lang mythread}<!--{/if}--><!--{/if}--></a>
</div>
  <div class="card">  
   <section class="topic-content"> 
    <ul class="base-list topic-list"> 
        <!--{if $list}-->  
    <!--{loop $list $stid $thread}-->
    <!--{template forum/forumdisplay_item}-->
    <!--{/loop}-->
    <!--{else}-->
     <li style="padding-left:0"><h3>{lang no_related_posts}</h3></li>
    <!--{/if}-->
    </ul> 
   </section> 
<!--{if $multi}--><div class="xiaoyu_mipage cl">$multi</div><!--{/if}-->
  </div>

<!-- main threadlist end -->

<!--{template common/footer}-->

