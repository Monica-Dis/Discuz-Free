<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $value[msgfromid] != $_G['uid']}-->
<div class="friend_msg cl">
	<div class="avat z"><img style="height:32px;width:32px;" src="<!--{avatar($value[msgfromid], small, true)}-->" /></div>
	<div class="dialog_green z">
		<div class="dialog_c">
        <i class="dialog_xy"></i>
			<div class="dialog_t">$value[message]</div>
		</div>
		<div class="date"><!--{date($value[dateline], 'u')}--></div>
	</div>
</div>
<!--{else}-->
<div class="self_msg cl">
	<div class="avat y"><img style="height:32px;width:32px;" src="<!--{avatar($value[msgfromid], small, true)}-->" /></div>
	<div class="dialog_white y">			
		<div class="dialog_c">
        <i class="dialog_xy"></i>
			<div class="dialog_t">$value[message]</div>
		</div>
		<div class="date"><!--{date($value[dateline], 'u')}--></div>
	</div>
</div>
<!--{/if}-->

