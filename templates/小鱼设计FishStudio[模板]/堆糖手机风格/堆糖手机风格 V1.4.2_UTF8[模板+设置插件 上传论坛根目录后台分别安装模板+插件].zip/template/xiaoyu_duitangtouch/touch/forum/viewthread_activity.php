<?php echo 'From: DisM.taobao.com';exit;?>
<div class="xiaoyu_special xiaoyu_activity">
<!--{if $activity['thumb']}--><div class="xiaoyu_special_img"><img src="$activity['thumb']" /></div><!--{/if}-->	
<table cellspacing="0" cellpadding="0" class="xiaoyu_table">
<tbody>
    <tr><th>{lang activity_type}:</th><td>$activity[class]</strong></td></tr>
    <tr><th>{lang activity_starttime}:</th><td>
    <!--{if $activity['starttimeto']}-->
    {lang activity_start_between}
    <!--{else}-->
    $activity[starttimefrom]
    <!--{/if}-->
    </td></tr>
    <tr><th>{lang activity_space}:</th><td> $activity[place]</td></tr>
    <tr><th>{lang gender}:</th><td>
    <!--{if $activity['gender'] == 1}-->
    {lang male}
    <!--{elseif $activity['gender'] == 2}-->
    {lang female}
    <!--{else}-->
    {lang unlimited}
    <!--{/if}-->
    </td></tr>
    <!--{if $activity['cost']}-->
    <tr><th>{lang activity_payment}:</th><td>$activity[cost] {lang payment_unit}</td></tr>
    <!--{/if}-->
    		<!--{if !$_G['forum_thread']['is_archived']}-->
		
			<tr><th>{lang activity_already}:</th><td>
				<em>$allapplynum</em> {lang activity_member_unit}
			</td></tr>
	
			<!--{if $activity['number']}-->
			<tr><th>{lang activity_about_member}:</th><td>
				$aboutmembers {lang activity_member_unit}
			</td></tr>
			<!--{/if}-->
			<!--{if $activity['expiration']}-->
				<tr><th>{lang post_closing}:</th><td> $activity[expiration]</td></tr>
			<!--{/if}-->
			

		<!--{/if}-->

</tbody>
</table>
        
<!--{if $post['invisible'] == 0}-->
    <!--{if $applied && $isverified < 2}-->
        <div class="notice"><!--{if !$isverified}-->{lang activity_wait}<!--{else}-->{lang activity_join_audit}<!--{/if}--></div> 
        <!--{if !$activityclose}-->
        <!--{/if}-->
    <!--{elseif !$activityclose}-->
        <!--{if $isverified != 2}-->
        <!--{else}-->
            <div class="notice">{lang complete_data}</div>
        <!--{/if}-->
    <!--{/if}-->
   
<!--{/if}-->
</div>
<!--{if $applylistverified}-->
  <div class="xiaoyu_duitangtouchlylist cl" > 
   <h2>{lang activity_new_signup} $noverifiednum {lang activity_member_unit}</h2> 
   <ul class="cl">
    <!--{loop $applylistverified $apply}-->
    <li><a target="_blank" href="home.php?mod=space&uid=$apply[uid]" ><!--{echo avatar($apply[uid], 'small')}--><span>$apply[username]</span></a>
    <!--{/loop}-->
   </ul> 
  </div>
<!--{/if}-->


<!--{if $applylist}-->
  <div class="xiaoyu_duitangtouchlylist cl" style="display:none"> 
   <h2 class="b_b">{lang activity_new_join} $applynumbers {lang activity_member_unit}</h2> 
   <ul class="cl">
    <!--{loop $applylist $apply}-->
    <li><a target="_blank" href="home.php?mod=space&uid=$apply[uid]"><!--{echo avatar($apply[uid], 'small')}--><span class="f_b">$apply[username]</span></a>
    <!--{/loop}-->
   </ul> 
  </div>

<!--{/if}-->
<!--{if $_G['uid'] && !$activityclose && (!$applied || $isverified == 2)}-->
<div class="xiaoyu_activityjoin cl">
  <!--{if $_G['forum']['status'] == 3 && helper_access::check_module('group') && $isgroupuser != 'isgroupuser'}-->
  <div class="formnotice">
    <h5>{lang activity_no_member}</h5>
    <h4><a href="forum.php?mod=group&action=join&fid=$_G[fid]">{lang activity_join_group}</a></h4>
  </div>
  <!--{else}-->
<script language="javascript">function showpay(cost){if(cost=='1'){document.getElementById('cost').style.display=''}else{document.getElementById('cost').style.display='none'}}</script>
  <form name="activity" id="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}&mobile=2" >
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <!--{if $_G['setting']['activitycredit'] && $activity['credit'] && !$applied}-->
    <h3 class="xiaoyu_acttit">{lang activity_need_credit} $activity[credit] {$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</h3>
    <!--{/if}-->
    <!--{if $activity['cost']}-->
    <p>
    <select name="payment" onchange="showpay(this.value);">
      <option value="0" selected="selected">{lang activity_pay_myself}</option>
      <option value="1">{lang activity_would_payment}</option>
    </select>    
    </p>
    <p id="cost" style="display:none">
    <input name="payvalue" placeholder="{lang payment_unit}"/>
    </p>
    <!--{/if}-->
    <!--{if !empty($activity['ufield']['userfield'])}-->
    <!--{loop $activity['ufield']['userfield'] $fieldid}-->
    <!--{if $settings[$fieldid][available]}-->
    <p><input type="text" name="$fieldid" placeholder="$settings[$fieldid][title]"/></p>
    <!--{/if}-->
    <!--{/loop}-->
    <!--{/if}-->
    <!--{if !empty($activity['ufield']['extfield'])}-->
    <!--{loop $activity['ufield']['extfield'] $extname}-->
    <p><input type="text" name="$extname" value="{if !empty($ufielddata)}$ufielddata[extfield][$extname]{/if}" /></p>
    <!--{/loop}-->
    <!--{/if}-->
    <p class="mesbox"><textarea name="message" placeholder="{lang leaveword}">$applyinfo[message]</textarea></p>
    <!--{if $_G['setting']['activitycredit'] && $activity['credit'] && checklowerlimit(array('extcredits'.$_G['setting']['activitycredit'] => '-'.$activity['credit']), $_G['uid'], 1, 0, 1) !== true}-->
      <p>{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]} {lang not_enough}$activity['credit']</p>
    <!--{else}-->
    <input type="hidden" name="activitysubmit" value="true">
    <div class="btn"><button type="submit" class="button2">{lang activity_join}</button></div>
    <!--{/if}-->
  </form>
  <!--{/if}-->
</div>

<!--{elseif $_G['uid'] && !$activityclose && $applied}-->
<div class="xiaoyu_activityjoin cl">
  <form name="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}">
  <input type="hidden" name="formhash" value="{FORMHASH}" />
  <p class="mesbox">
   <input type="text" name="message" placeholder="{lang leaveword}"/>
  </p>
  <div class="btn">
  <button type="submit" name="activitycancel"  value="true" class="button2">{lang activity_join_cancel}</button>
  </div>
  </form>
</div>
<!--{/if}-->
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>




