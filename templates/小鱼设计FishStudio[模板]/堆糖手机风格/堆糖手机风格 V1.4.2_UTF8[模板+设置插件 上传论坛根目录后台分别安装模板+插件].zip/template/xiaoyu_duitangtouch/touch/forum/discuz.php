<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{if $_GET['forumlist'] != 1}-->
<!--{if !empty($fishindex)}--><!--{eval dheader("Location:$indexurl");exit;}-->
<!--{else}--><!--{eval dheader('Location:forum.php?mod=guide&mobile=2');exit;}--><!--{/if}-->
<!--{/if}-->
<style>#TalionNav{ display:none}.db_page{ min-height:900px}</style>
<!-- header start -->
<div class="bbsnav">
	<a href="javascript:;" onclick="history.go(-1);" class="fa backleft fishz" >话题</a>
</div>
<!-- header end -->
<!--{hook/index_top_mobile}-->
<!-- main forumlist start -->
<div class="xiaoyu_forums" >
    <div class="xiaoyubkleft cl">
    <ul>
    <!--{eval $i=1;}-->
    <!--{loop $catlist $key $cat}-->
    <li {if $i==1}class="current"{/if}>$cat[name]</li>
    <!--{eval $i++;}-->
    <!--{/loop}-->
    </ul>
    </div>
<div class="channel_list">
<!--{eval $i=1;}-->
<!--{loop $catlist $key $cat}-->
<ul {if $i==1} style="display:block"{/if}>
<!--{loop $cat[forums] $forumid}-->
<!--{eval $forum=$forumlist[$forumid];}-->
    <li class="cl"> 
        <div class="xiaoyu_bk_img"><!--{if $forum[icon]}-->$forum[icon]<!--{else}--><a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"><img src="template/xiaoyu_duitangtouch/touch/style/img/forum.png" /></a><!--{/if}--></div>
        <div class="xiaoyu_bottom">
        <div class="title"><span class="name"><a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">{$forum[name]}<!--{if $forum[todayposts] > 0}--><em style="color:#C00; font-size:14px; font-weight:normal; padding-left:5px">($forum[todayposts])</em><!--{/if}--></a></span> 
        </div> 
        <div class="desc"> 
         话题&nbsp;<!--{echo dnumber($forum[threads])}-->
        </div>
         <!--{eval $forum_favlist = C::t('home_favorite')->fetch_by_id_idtype($forum['fid'], 'fid', $_G['uid']);}-->
        <div class="xiaoyu_add" style="display:none"><a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$forum['fid']&handlekey=favoriteforum&formhash={FORMHASH}"><!--{if $forum_favlist && $_G['uid']}--><em style="color:#ddd">已关注</em><!--{else}-->关注<!--{/if}--></a></div>
        </div>
    </li>
<!--{/loop}-->
</ul>
<!--{eval $i++;}-->
<!--{/loop}-->
</div>
</div>
<!-- main forumlist end -->
<!--{hook/index_middle_mobile}-->

<script>
$(".xiaoyubkleft li").on("click", function(){
	$(this).addClass("current").siblings().removeClass("current");
	$(".channel_list ul").eq($(this).index()).show().siblings().hide();
});
</script>
<!--{eval $nofooter= true;}-->
<!--{template common/footer}-->

