<?php echo 'From: DisM.taobao.com';exit;?>
<li id="$thread[id]"> 
<a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><img class="user-avatar" src="uc_server/avatar.php?uid=$thread[authorid]&size=small" /></a> 
<a href="forum.php?mod=viewthread&tid=$thread[tid]">
<!--{eval $table='forum_attachment_'.substr($thread['tid'], -1);$tpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread[tid]);$tpid = $tpost['pid'];}-->
<!--{eval $query = DB::query("SELECT * FROM ".DB::table($table)." WHERE pid='$tpid' AND isimage!=0 ORDER BY `dateline` ASC"); 
while($value = DB::fetch($query))$thread[aids][]=$value['aid'];$thread['pics']=count($thread[aids]);}-->   
<!--{if $thread[aids]}-->
<h3 class="has-pic">{$thread[subject]}<div class="cover"><img src="{eval echo(getforumimg($thread['aids'][0],0,240,240))}" /></div></h3>
<!--{else}-->
<h3>{$thread[subject]}</h3>
<!--{/if}-->
<div class="info"> 
<span class="left">{$thread[views]}&#x6d4f;&#x89c8;</span> 
<span class="right">$thread[dateline]</span> 
</div>
</a> 
</li> 

