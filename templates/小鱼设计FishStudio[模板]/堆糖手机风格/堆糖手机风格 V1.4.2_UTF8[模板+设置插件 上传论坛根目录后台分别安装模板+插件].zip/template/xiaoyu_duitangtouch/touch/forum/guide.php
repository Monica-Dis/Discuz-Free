<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{if !$_G['cache']['plugin']['xiaoyu_duitangtouch']}-->
<!--{eval dheader("Location:forum.php?forumlist=1");exit;}-->
<!--{/if}-->
<link href="template/xiaoyu_duitangtouch/touch/style/swiper.min.css" rel="stylesheet" type="text/css" />
<script src="template/xiaoyu_duitangtouch/touch/style/js/slide.js"></script>  
<!--{if $_G['basescript'] == 'forum' && !in_array($_GET['show'],array('find'))}-->
   <div class="card">
   <!--{if $xiaoyu_dtset['xiaoyu_quicknav']}-->
    <div class="slidebx">
    <div class="swiper-container">
    <div class="swiper-wrapper">
    {$xiaoyu_dtset['xiaoyu_quicknav']}
    </div>
    <div class="swiper-pagination"></div>
    </div>
    </div>
    <!--{/if}-->
    <section id="recommend-feed">
     <div class="xiaoyu_listbox">
     <div class="tjtit">推荐内容</div>
      <div class="feed-section">
        <!--{loop $xiaoyu_duitangtouch $key $thread}-->
        <!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
        <!--{eval $table='forum_attachment_'.substr($thread['tid'], -1);$tpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread[tid]);$tpid = $tpost['pid'];}-->
        <!--{eval $query = DB::query("SELECT * FROM ".DB::table($table)." WHERE pid='$tpid' AND isimage!=0 ORDER BY `dateline` ASC"); 
        while($value = DB::fetch($query))$thread[aids][]=$value['aid'];$thread['pics']=count($thread[aids]);}-->
    <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="feed-item">
    <div class="feed-content">
    <div class="author cl"><!--{avatar($thread[authorid],small)}--><p class="name">$thread[author]</p><p>$thread[name]</p></div>
     <h3>{$thread[subject]}</h3>
    <!--{if $thread[aids]}-->
        <!--{if $thread['pics']==1}-->
		<div class="cover" style="position: relative; background:url({eval echo(getforumimg($thread['aids'][0],0,600,600))}) center center / cover no-repeat rgb(250, 250, 250);"/><div style="padding-top: 55%;"></div></div>
        <!--{elseif $thread['pics'] >= 2}-->
          <div class="photos">
           <div class="aside">
           <!--{eval $i=0}-->
           <!--{loop $thread[aids] $aid}-->
           <!--{if $i< 9}-->
           <!--{if $thread['pics'] == 2}-->
            <div class="aside-pic imgtwo"><div class="imgp"><img src="{eval echo(getforumimg($thread['aids'][$i],0,300,300))}" /></div></div>
            <!--{else}-->
            <div class="aside-pic"><div class="imgp"><img src="{eval echo(getforumimg($thread['aids'][$i],0,200,200))}" /></div></div>
            <!--{/if}-->
            <!--{/if}-->
             <!--{eval $i++}-->
          <!--{/loop}--> 
           </div>
          </div>
        <!--{/if}-->
        <!--{/if}-->
        <div class="xiaoyu_tinfo cl"><span class="xz">$thread[recommend_add]</span><span class="hf">$thread[replies]</span><span class="tshare"></span></div>
        </div>
        
       </a>
        <!--{/loop}-->
      </div>
      <!--{if $multi}--><div class="xiaoyu_mipage cl">$multi</div><!--{/if}-->
     </div>
    </section> 
   </div>
  
  <script>
    var swiper = new Swiper('.swiper-container', {
      pagination: {
        el: '.swiper-pagination',
      },
	autoplay: true,   observer:true,
	observeParents:true,
	autoplayDisableOnInteraction : false,
		spaceBetween: 40,
	centeredSlides: true,
    });
  </script>
    
 <!--{elseif $_G['basescript'] == 'forum' && $_GET['show']=='find'}-->
 <!--{eval $fidicon=DB::fetch_all("SELECT fid,icon FROM %t WHERE ".DB::field('fid',$xiaoyu_dtset['fxforum']),array('forum_forumfield'));}-->
 <style>.db_page{ background:#f4f4f4}.download-app{ display:none}</style>
<div class="bbsnav">
<a href="javascript:;" onclick="history.go(-1);" class="fa backleft fishz">发现</a>
</div>
<!--{if $fidicon}-->
<div class="xiaoyu_findmenu">
<div class="xiaoyu_findbk">
<div class="swiper-wrapper">
<!--{loop $fidicon $key $fid}-->
<!--{eval $findicon=$_G['setting']['attachurl'].'common/'.$fidicon[$key][icon];$fid=$fidicon[$key]['fid'];$fname = DB::fetch_all("SELECT name FROM ".DB::table('forum_forum')." WHERE fid=$fid");}-->
<div class="swiper-slide">
<a href="forum.php?mod=forumdisplay&fid=$fid">
<!--{if $fidicon[$key][icon]}-->
<img src="$findicon"/>
<!--{else}-->
<img src="template/xiaoyu_duitangtouch/touch/style/img/forum.png"/>
<!--{/if}-->
<p><!--{echo cutstr($fname[0]['name'], 8)}--></p>
</a>
</div>
<!--{/loop}-->
</div>
</div>
</div>
  <script>
    var swiper = new Swiper('.xiaoyu_findbk', {
      slidesPerView: 4,
      spaceBetween: 15,
    });
  </script>
<!--{/if}-->
<div id="xiaoyu_waterfall" class="xiaoyu_waterfall cl">
 <ul><div class="waterlst">
 <!--{eval $i=1;}-->
    <!--{loop $xiaoyu_duitangtouch $key $thread}-->
    <!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
    <!--{eval $table='forum_attachment_'.substr($thread['tid'], -1);$tpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread[tid]);$tpid = $tpost['pid'];}-->
    <!--{eval $query = DB::query("SELECT * FROM ".DB::table($table)." WHERE pid='$tpid' AND isimage!=0 ORDER BY `dateline` ASC"); 
    while($value = DB::fetch($query))$thread[aids][]=$value['aid'];$thread['pics']=count($thread[aids]);}-->
    <!--{if !is_int($i/2)}-->
        <li class="wli">
            <div class="libox">
                <div class="c cl"> 
              		<a href="forum.php?mod=viewthread&tid=$thread[tid]" title="$thread[subject]"><img src="{eval echo(getforumimg($thread['aids'][0],0,300,9999))}" /></a> 
                </div>
                
                <div class="tinfo">
                	<h3><a href="forum.php?mod=viewthread&tid=$thread[tid]" title="$thread[subject]">$thread[subject]</a> </h3> 
                <div class="xiaoyu_favtimes">$thread['favtimes']</div>
                	<div class="author cl"><!--{avatar($thread[authorid],small)}--><p class="name">$thread[author]</p><p>$thread[name]</p></div>
                </div>
                
            </div>
        </li> 
        <!--{/if}-->
         <!--{eval $i++;}-->
    <!--{/loop}-->
    </div>
    <div class="waterlst">
    <!--{eval $ii=1;}-->
        <!--{loop $xiaoyu_duitangtouch $key $thread}-->
    <!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
    <!--{eval $table='forum_attachment_'.substr($thread['tid'], -1);$tpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread[tid]);$tpid = $tpost['pid'];}-->
    <!--{eval $query = DB::query("SELECT * FROM ".DB::table($table)." WHERE pid='$tpid' AND isimage!=0 ORDER BY `dateline` ASC"); 
    while($value = DB::fetch($query))$thread[aids][]=$value['aid'];$thread['pics']=count($thread[aids]);}-->
    <!--{if is_int($ii/2)}-->
        <li class="wli">
            <div class="libox">
                <div class="c cl"> 
              		<a href="forum.php?mod=viewthread&tid=$thread[tid]" title="$thread[subject]"><img src="{eval echo(getforumimg($thread['aids'][0],0,300,9999))}" /></a> 
                </div>
                <div class="tinfo">
                	<h3><a href="forum.php?mod=viewthread&tid=$thread[tid]" title="$thread[subject]">$thread[subject]</a> </h3>
                    <div class="xiaoyu_favtimes">$thread['favtimes']</div>
                	<div class="author cl"><!--{avatar($thread[authorid],small)}--><p class="name">$thread[author]</p><p>$thread[name]</p></div>
                </div>
            </div>
        </li> 
        <!--{/if}-->
        <!--{eval $ii++;}-->
    <!--{/loop}-->
    </div>
  </ul>
</div>
<!--{if $multi}--><div class="xiaoyu_mipage cl" style=" margin-bottom:20px">$multi</div><!--{/if}-->
<!--{/if}-->
  <style>.slidebx .swiper-pagination{ bottom:20px;}.swiper-pagination-bullet{cursor:pointer;display:inline-block;*display:inline;zoom:1;width:5px;height:5px; margin:0 4px;background-color:rgba(0,0,0,.2);border:2px solid rgba(255,255,255,.8);border-radius:50%;transition:.3s ease-in;-webkit-transition:.3s ease-in;-moz-transition:.3s ease-in;-o-transition:.3s ease-in;-ms-transition:.3s ease-in;overflow:hidden;vertical-align: middle;line-height:9999px;}
.swiper-pagination-bullet{ border:1px solid #fff;opacity:1}.swiper-pagination .swiper-pagination-bullet-active{border-color:#ff7e7e;background-color:#FF5653}</style>
<!--{template common/footer}-->

