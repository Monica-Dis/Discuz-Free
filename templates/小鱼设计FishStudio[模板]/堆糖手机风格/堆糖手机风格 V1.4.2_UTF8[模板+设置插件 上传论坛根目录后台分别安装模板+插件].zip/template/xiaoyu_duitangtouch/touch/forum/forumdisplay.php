<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<link href="template/xiaoyu_duitangtouch/touch/style/topic_list.css" rel="stylesheet" type="text/css" />
<style>#TalionNav{ display:none}body{ padding-top:0}.bbsnav{ background:none;}
</style>
<!-- header start -->
<!--{hook/forumdisplay_top_mobile}-->
<!--{if $_G['forum'][icon]}-->
<!--{eval $parse = parse_url($_G['forum'][icon]);}-->
<!--{if !isset($parse['host'])}-->
<!--{eval $_G['forum'][icon]=$_G['setting']['attachurl'].'common/'.$_G['forum'][icon];}-->
<!--{/if}-->
<!--{/if}-->
<!-- header end -->

     <div class="group_lst_header">
    <div class="ghbg" style="background:url({if $_G['forum'][icon]}$_G['forum'][icon]{else}template/xiaoyu_duitangtouch/touch/style/img/forum.png{/if}) no-repeat center center;background-size:cover;"></div>
     <div class="flstnav">
	<a href="forum.php?forumlist=1" class="fa backleft fishz" >&nbsp;</a>
    <a onclick="xiaoyu_filter_box(1);" class="xiaoyu_ftype y">&nbsp; </a>
</div>
     <div class="group-banner" >
     <div class="ficon"><!--{if $_G['forum'][icon]}--><img src="$_G['forum'][icon]" /><!--{else}--><img src="template/xiaoyu_duitangtouch/touch/style/img/forum.png"/><!--{/if}--></div>
       <h1>
       <span>$_G['forum'][name]</span></h1>
       <h2>	<!--{if $_G['forum']['rules']}--><!--{echo cutstr($_G['forum'][rules], 64)}--><!--{else}-->版块简介，分享你的美好生活在，一起记录生命中的每一天吧<!--{/if}--></h2>
      </div>
      
     </div>
   <div class="card"> 
    <section class="topic-content"> 
     <ul class="base-list topic-list">
        <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
        {eval continue;}
        <!--{/if}-->
        <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
        {eval $displayorder_thread = 1;}
        <!--{/if}-->
        <!--{if $thread['moved']}-->
        <!--{eval $thread[tid]=$thread[closed];}-->
        <!--{/if}-->
        <li id="$thread[id]"> 
        <a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><img class="user-avatar" src="uc_server/avatar.php?uid=$thread[authorid]&size=small" /></a> 
        <a href="forum.php?mod=viewthread&tid=$thread[tid]" title="{$thread[subject]}">
        <!--{eval $table='forum_attachment_'.substr($thread['tid'], -1);$tpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread[tid]);$tpid = $tpost['pid'];}-->
<!--{eval $query = DB::query("SELECT * FROM ".DB::table($table)." WHERE pid='$tpid' AND isimage!=0 ORDER BY `dateline` ASC"); 
while($value = DB::fetch($query))$thread[aids][]=$value['aid'];$thread['pics']=count($thread[aids]);}-->
        <!--{if $thread[aids]}-->
        <h3 class="has-pic">{$thread[subject]}<div class="cover"><img src="{eval echo(getforumimg($thread['aids'][0],0,200,200))}" /></div></h3>
        <!--{else}-->
        <h3>{$thread[subject]}</h3>
        <!--{/if}-->
        <!--{hook/forumdisplay_thread_mobile $key}-->
        <div class="info"> 
        <span class="left">{$thread[views]}&#x6d4f;&#x89c8;</span> 
        <span class="right">$thread[dateline]</span> 
        </div> </a> </li> 
        <!--{/loop}-->
        <!--{else}-->
      	  <li style="padding-left:0"><h3>{lang forum_nothreads}</h3></li>
        <!--{/if}-->
     </ul> 
    </section> 
    <!--{if $multipage}--><div class="xiaoyu_mipage cl">$multipage</div><!--{/if}-->   
   </div> 
    

  <div id="xiaoyu_listmore" class="xiaoyu_filter_box"> 
    <div class="filter_head_nav b_b">
    <span class="header-tit">&#x9ad8;&#x7ea7;&#x7b5b;&#x9009;</span><a onclick="xiaoyu_filter_box(0);" class="xiaoyu_font y">&#xe7dc;</a>
    </div>
    <div class="flbox">
       <div class="xiaoyu_fmenu_list bg_f b_b cl">
        <ul>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" {if !$_GET['filter']}class="xw1"{/if}>{lang forum_viewall}</a></li>			
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'lastpost'}xw1{/if}">{lang latest}</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'heat'}xw1{/if}">{lang order_heats}</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if $_GET['filter'] == 'digest'}xw1{/if}">{lang digest_posts}</a></li>
        </ul>
   </div>  
    <!--{if $_G['forum']['threadtypes']}--><!--小鱼.设计56282.8385 -->
     <div class="xiaoyu_fmenu_tit bg_f b_t b_b cl">&#x4e3b;&#x9898;&#x5206;&#x7c7b;</div> 
     <div class="xiaoyu_fmenu_list bg_f b_b cl"> 
      <ul> 
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['filter']}class="xw1"{/if}>{lang forum_viewall}</a></li>
        <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
        <!--{if $_GET['typeid'] == $id}-->
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xw1">$name</a></li>
        <!--{else}-->
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
        <!--{/if}-->
        <!--{/loop}-->
      </ul> 
     </div> 
     <!--{/if}-->
     <div class="xiaoyu_fmenu_tit bg_f b_t b_b cl">&#x66f4;&#x591a;&#x7b5b;&#x9009;</div> 
     <div class="xiaoyu_fmenu_list bg_f b_b cl"> 
        <ul>
            <li><a>{lang orderby} </a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'dateline'}class="xw1"{/if}>{lang list_post_time}</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'replies'}class="xw1"{/if}>{lang replies}</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'views'}class="xw1"{/if}>{lang views}</a></li>
        </ul>
        <ul>
            <li><a>{lang time} </a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['dateline']}class="xw1"{/if}>{lang all}{lang search_any_date}</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '86400'}class="xw1"{/if}>{lang last_1_days}</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '172800'}class="xw1"{/if}>{lang last_2_days}</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '604800'}class="xw1"{/if}>{lang list_one_week}</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '2592000'}class="xw1"{/if}>{lang list_one_month}</a></li>
            <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '7948800'}class="xw1"{/if}>{lang list_three_month}</a></li>
      
        </ul>
     </div> 
     
<!--{if $subexists}-->
     <div class="xiaoyu_fmenu_tit bg_f b_t b_b cl">{lang forum_subforums}</div>
         <div class="xiaoyu_fmenu_list bg_f b_b cl"> 
            <ul> 
                <!--{loop $sublist $sub}-->
                <li><a href="forum.php?mod=forumdisplay&fid={$sub[fid]}" >{$sub['name']}</a></li>
                <!--{/loop}-->
            </ul>
        </div>
<!--{/if}-->
</div>
</div>
<div class="xiaoyu_fpost">
<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_threads}" >&nbsp;</a>
</div>
<!--{hook/forumdisplay_bottom_mobile}-->
<!--{template common/footer}-->

