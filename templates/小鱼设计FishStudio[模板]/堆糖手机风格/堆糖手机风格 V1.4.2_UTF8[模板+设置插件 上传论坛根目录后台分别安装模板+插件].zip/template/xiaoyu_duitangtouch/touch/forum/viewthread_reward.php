<?php echo 'From: DisM.taobao.com';exit;?>
  <table cellpadding="0" cellspacing="0" class="xiaoyu_reward"> 
   <tbody>
    <tr> 
     <td class="xiaoyu_reward_td"><i class="xiaoyu_font">&#xe69a;</i>{lang thread_reward}<strong>$rewardprice</strong>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</td> 
     <th>{if $_G['forum_thread']['price'] > 0}<span class="un">{lang unresolved}</span>{elseif $_G['forum_thread']['price'] < 0}<span class="xg1">{lang resolved}</span>{/if}</th> 
    </tr> 
   </tbody>
  </table>
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>


<!--{if $post['attachment']}-->
	<div class="warning">{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em></div>
<!--{elseif $post['imagelist'] || $post['attachlist']}-->
    <!--{if $post['imagelist']}-->
         {echo showattach($post, 1)}
    <!--{/if}-->
    <!--{if $post['attachlist']}-->
         {echo showattach($post)}
    <!--{/if}-->
<!--{/if}-->
<!--{eval $post['attachment'] = $post['imagelist'] = $post['attachlist'] = '';}-->
<!--{if $bestpost}-->
<div class="xiaoyu_rwdbst">
<h3>{lang reward_bestanswer}</h3>
<p class="psta">$bestpost[avatar]<a href="home.php?mod=space&uid=$bestpost[authorid]">$bestpost[author]</a><!--{date($bestpost[dateline])}--></p>
<div>$bestpost[message]<a href="forum.php?mod=redirect&goto=findpost&ptid=$bestpost[tid]&pid=$bestpost[pid]" class="more">{lang view_full_content}</a></div>
</div>
<!--{/if}-->
