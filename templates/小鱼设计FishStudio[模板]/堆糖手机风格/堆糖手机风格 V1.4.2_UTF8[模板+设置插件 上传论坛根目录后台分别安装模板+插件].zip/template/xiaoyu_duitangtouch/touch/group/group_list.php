<?php echo 'From: DisM.taobao.com';exit;?>
<link href="template/xiaoyu_duitangtouch/touch/style/topic_list.css" rel="stylesheet" type="text/css" />
<div class="card"> 
    <div id="group-header">
     <div class="group-header">
      <div class="group-banner" style="background-color:#2CAFBB">
       <h1>
       <img src="$_G[forum][icon]" alt="$_G[forum][name]" /><span>$_G[forum][name]</span></h1>
       <h2>$_G[forum][membernum]&#x4e2a;&#x6210;&#x5458;</h2>
       <div class="btn-group">
        <div class="btn inverse btn-opt">
        <!--{if $status != 2 && $status != 3 && $status != 5}-->
        <!--{if helper_access::check_module('group') && $status != 'isgroupuser'}-->
        <a href="forum.php?mod=group&action=join&fid=$_G[fid]" style="color:#fff">&#x7533;&#x8bf7;&#x52a0;&#x5165;&#x5c0f;&#x7ec4;</a>
        <!--{else}-->
        <a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" title="{lang send_posts}" style="color:#fff">&#x53d1;&#x5e03;&#x65b0;&#x4e3b;&#x9898;</a>
        <!--{/if}-->
        <!--{/if}-->
        </div>
        <div class="btn inverse btn-menu" onclick="location='forum.php?mod=group&action=memberlist&fid=$_G[fid]'">&middot; &middot; &middot;</div>
       </div>
      </div>
     </div>
    </div> 
    <!--{if $_G['forum_threadcount']}-->
    <section class="topic-content"> 
    <ul class="base-list topic-list">
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{template forum/forumdisplay_item}--> 
    <!--{/loop}-->
    </ul> 
    </section> 
    <!--{else}-->
    <div class="more-group" style=" margin:0; padding:30px 0; color:#999">{lang forum_nothreads}</div>
    <!--{/if}-->
    <!--{if $multipage}--><section class="pagination"><div class="xiaoyu_mipage cl">$multipage</div></section><!--{/if}--> 
  </div>
