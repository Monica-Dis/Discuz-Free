<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{eval $g_val = grouplist('lastupdate', array('ff.membernum', 'ff.icon','ff.description'), 80);}-->	
<link href="template/xiaoyu_duitangtouch/touch/style/discuz.css" rel="stylesheet" type="text/css" />

   <div class="card"> 
    <div id="root"> 
    <!--{if $_G['setting']['group_recommend']}--> 
     <section> 
      <header> 
       <h2>{lang recommend_group}</h2> 
      </header> 
      <div class="section-content"> 
       <ul class="group-list">
            <!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->
            <li>
            <a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="group">
            <div class="group-meta">
            <img src="$val[icon]" alt="$val[name]" /><span class="group-name">$val[name]</span><span class="group-member">$g_val[$val[fid]][membernum]人</span>
            </div>
            <div class="group-topic"> 
            <span class="topic-title">$val[description]</span> 
            </div>                        
            </a>
            </li>
            <!--{/loop}-->
        </ul> 
      </div> 
     </section>           
    <!--{/if}--> 	
    <!--{loop $first $groupid $group}-->
    <!--{if $lastupdategroup[$groupid]}--> 
     <section> 
      <header><h2>$group[name]</h2> </header> 
      <div class="section-content"> 
       <ul class="group-list">
        <!--{loop $lastupdategroup[$groupid] $k $val}-->
        <!--{if $k<3}--> 
        <li><a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="group">
        <div class="group-meta"> 
        <img class="group-icon" src="$g_val[$val[fid]][icon]" alt="$val[name]" />
        <span class="group-name">$val[name]</span> 
        <span class="group-member">$g_val[$val[fid]][membernum]&#x4eba;</span> 
        </div>
        <div class="group-topic"> 
        <span class="topic-title">$g_val[$val[fid]][description]</span> 
        </div>                        
        </a></li>
        <!--{elseif $k == 4}-->
        <div class="more-group" style=" margin-top:0;margin-bottom: 30px; "><a href="group.php?gid=$groupid">&#x66f4;&#x591a;&#x76f8;&#x5173;&#x5c0f;&#x7ec4;</a></div>
        <!--{/if}-->
        <!--{/loop}-->
       </ul> 
      </div> 
     </section> 
     <!--{/if}-->
     <!--{/loop}-->
     
    </div> 
   </div> 
    
<!--{template common/footer}-->
