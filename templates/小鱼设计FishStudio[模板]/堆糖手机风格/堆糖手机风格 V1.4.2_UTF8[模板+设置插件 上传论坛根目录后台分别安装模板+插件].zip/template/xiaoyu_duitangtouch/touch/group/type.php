<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{eval $g_val = grouplist('lastupdate', array('ff.membernum', 'ff.icon','ff.description'), 80);}-->	
<link href="template/xiaoyu_duitangtouch/touch/style/discuz.css" rel="stylesheet" type="text/css" />
<div class="card"> 
    <div id="root"> 
    <!--{if $list}-->
     <section> 
      <header> 
       <h2>$curtype[name]</h2> 
      </header> 
      <div class="section-content"> 
       <ul class="group-list">
            <!--{loop $list $fid $val}-->
            <li>
            <a href="forum.php?mod=forumdisplay&action=list&fid=$fid" title="$val[name]" class="group">
            <div class="group-meta">
            <img src="$val[icon]" alt="$val[name]" /><span class="group-name">$val[name]</span><span class="group-member">$val[membernum]人</span>
            </div>
            <div class="group-topic"> 
            <span class="topic-title">$val[description]</span> 
            </div>                        
            </a>
            </li>
            <!--{/loop}-->
        </ul> 
      </div> 
     </section>      
    <!--{else}-->
      <div class="more-group" style=" margin:0; padding:30px 0; color:#999">{lang group_category_no_groups}</div>
    <!--{/if}-->              
     <!--{if $multipage}--><div class="xiaoyu_page cl" style="margin-top:30px;">$multipage</div><!--{/if}-->
    </div> 
   </div>
<!--{template common/footer}-->
