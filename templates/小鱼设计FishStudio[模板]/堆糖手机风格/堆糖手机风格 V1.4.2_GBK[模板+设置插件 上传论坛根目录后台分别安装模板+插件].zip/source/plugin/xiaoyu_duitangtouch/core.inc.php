<?php

/*
 * xiaoyu process
 * This is not a freeware, use is subject to license terms
 * From С�����(www.minfish.com)
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
$xiaoyu_dtset = $_G['cache']['plugin']['xiaoyu_duitangtouch'];
$xiaoyu_dtset['xiaoyuforum'] = dunserialize($xiaoyu_dtset['xiaoyuforum']);
$xiaoyu_dtset['xiaoyupagenum'] = $xiaoyu_dtset['xiaoyupagenum'] ? $xiaoyu_dtset['xiaoyupagenum'] : 10;
$fishindex = $xiaoyu_dtset['fishindex'];
$xiaoyuheadcolor = $xiaoyu_dtset['xiaoyuheadcolor'];
$page = addslashes($_GET['page']) ? addslashes($_GET['page']) : 1;
$xiaoyu_dtset['fxforum'] = dunserialize($xiaoyu_dtset['fxforum']);
$xiaoyu_dtset['fxpagenum'] = $xiaoyu_dtset['fxpagenum'] ? $xiaoyu_dtset['fxpagenum'] : 20;
if (CURMODULE == 'guide') {
    require_once libfile('function/forumlist');
    $sql = array();
    $sql['select'] = 'SELECT t.*';
    $sql['from'] = 'FROM ' . DB::table('forum_thread') . ' t';
    $wherearr = array();
    $wherearr[] = 't.displayorder >=0';
    if ($_GET['show'] == 'find') {
        $size = $xiaoyu_dtset['fxpagenum'];
        if ($xiaoyu_dtset['fxforum'][0]) {
            $fidarr = implode(',', $xiaoyu_dtset['fxforum']);
            $wherearr[] = "t.fid IN($fidarr)";
        }
    } else {
        $size = $xiaoyu_dtset['xiaoyupagenum'];
        if ($xiaoyu_dtset['xiaoyuforum'][0]) {
            $fidarr = implode(',', $xiaoyu_dtset['xiaoyuforum']);
            $wherearr[] = "t.fid IN($fidarr)";
        }
        if ($xiaoyu_dtset['xiaoyutime'] == 2) {
            $dateline = $_G['timestamp'] - 604800;
        } elseif ($xiaoyu_dtset['xiaoyutime'] == 3) {
            $dateline = $_G['timestamp'] - 2592000;
        } elseif ($xiaoyu_dtset['xiaoyutime'] == 4) {
            $dateline = $_G['timestamp'] - 7776000;
        } elseif ($xiaoyu_dtset['xiaoyutime'] == 5) {
            $dateline = $_G['timestamp'] - 31104000;
        }
    }
    if ($page > 1) {
        $cut = ($page - 1) * $size;
    } else {
        $cut = 0;
    }
    $sql['select'].= ',f.name';
    $sql['from'].= "," . DB::table('forum_forum') . " f";
    $wherearr[] = 'f.fid =t.fid';
    if ($commoncall['time'] == 2) {
        $dateline = $_G['timestamp'] - 2592000;
    } elseif ($commoncall['time'] == 3) {
        $dateline = $_G['timestamp'] - 7776000;
    } elseif ($commoncall['time'] == 4) {
        $dateline = $_G['timestamp'] - 31104000;
    }
    if ($dateline) {
        $wherearr[] = "t.dateline >'$dateline'";
    }
    if ($_GET['show'] == 'find') {
        if ($xiaoyu_dtset['fxorder'] == 1) {
            $sql['order'] = 'ORDER BY t.lastpost DESC';
        } elseif ($xiaoyu_dtset['fxorder'] == 2) {
            $sql['order'] = 'ORDER BY t.dateline DESC';
        } elseif ($xiaoyu_dtset['fxorder'] == 3) {
            $sql['order'] = 'ORDER BY t.views DESC';
        } elseif ($xiaoyu_dtset['fxorder'] == 4) {
            $sql['order'] = 'ORDER BY t.replies DESC';
        }
    } else {
        if ($xiaoyu_dtset['xiaoyuorder'] == 1) {
            $sql['order'] = 'ORDER BY t.lastpost DESC';
        } elseif ($xiaoyu_dtset['xiaoyuorder'] == 2) {
            $sql['order'] = 'ORDER BY t.dateline DESC';
        } elseif ($xiaoyu_dtset['xiaoyuorder'] == 3) {
            $sql['order'] = 'ORDER BY t.views DESC';
        } elseif ($xiaoyu_dtset['xiaoyuorder'] == 4) {
            $sql['order'] = 'ORDER BY t.replies DESC';
        }
    }
    $sql['limit'] = "LIMIT $cut,$size";
    if (!empty($wherearr)) $sql['where'] = ' WHERE ' . implode(' AND ', $wherearr);
    $sqlstring = $sql['select'] . ' ' . $sql['from'] . ' ' . $sql['where'] . ' ' . $sql['order'] . ' ' . $sql['limit'];
    $listcount = 1;
    $num_sql = 'SELECT COUNT(*) ' . $sql['from'] . $sql['where'];
    $listcount = DB::result_first($num_sql);
    if ($listcount) {
        if ($_GET['show'] == 'find') {
            $multi = multi($listcount, $size, $page, "forum.php?mod=guide&show=find", 1000);
        } else {
            $multi = multi($listcount, $size, $page, "forum.php?mod=guide", 1000);
        }
        $query = DB::query($sqlstring);
        while ($value = DB::fetch($query)) {
            $value['dateline'] = dgmdate($value['dateline'], 'u');
            if ($xiaoyu_dtset['highlight']) {
                $_G['forum_colorarray'] = array(
                    '',
                    '#EE1B2E',
                    '#EE5023',
                    '#996600',
                    '#3C9D40',
                    '#2897C5',
                    '#2B65B7',
                    '#8F2A90',
                    '#EC1282'
                );
                if ($value['highlight']) {
                    $string = sprintf('%02d', $value['highlight']);
                    $stylestr = sprintf('%03b', $string[0]);
                    $value['highlight'] = ' style="';
                    $value['highlight'].= $stylestr[0] ? 'font-weight: bold;' : '';
                    $value['highlight'].= $stylestr[1] ? 'font-style: italic;' : '';
                    $value['highlight'].= $stylestr[2] ? 'text-decoration: underline;' : '';
                    $value['highlight'].= $string[1] ? 'color: ' . $_G['forum_colorarray'][$string[1]] . ';' : '';
                    if ($value['bgcolor']) {
                        $value['highlight'].= "background-color: $value[bgcolor];";
                    }
                    $value['highlight'].= '"';
                } else {
                    $value['highlight'] = '';
                }
            }
            $xiaoyu_duitangtouch[$value['tid']] = $value;
        }
    }
}

