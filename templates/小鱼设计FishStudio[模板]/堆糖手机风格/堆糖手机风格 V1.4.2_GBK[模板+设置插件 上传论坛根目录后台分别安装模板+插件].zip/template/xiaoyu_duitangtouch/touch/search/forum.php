<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<link href="template/xiaoyu_duitangtouch/touch/style/topic_list.css" rel="stylesheet" type="text/css" />
<link href="template/xiaoyu_duitangtouch/touch/style/search.css" rel="stylesheet" type="text/css" />
<div class="db_page">          
  <div class="search">
  <header class="search-hd">
    <form id="searchform" class="searchform xiaoyusearchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2" {if !empty($searchid) && submitcheck('searchsubmit', 1)} {/if} >
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <!--{subtemplate search/pubsearch}-->
    <!--{eval $policymsgs = $p = '';}-->
    <!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
    <!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
    <!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
    <!--{/loop}-->
    <!--{if $policymsgs}--><p>{lang search_credit_msg}</p><!--{/if}-->
    </form>
      </header>
  </div>
 
<div class="card"> 
<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
<!--{subtemplate search/thread_list}-->
<!--{/if}-->
</div>

<!--{template common/footer}-->


