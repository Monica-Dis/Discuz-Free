<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<link href="template/xiaoyu_duitangtouch/touch/style/topic_list.css" rel="stylesheet" type="text/css" />
<!-- header start -->
<header class="header">
    <div class="nav">
		<a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="z"><img src="template/xiaoyu_duitangtouch/touch/style/img/nav_icon_back.png" /></a>
		<!--{if $_GET['type'] == 'forum'}-->
		<span class="category">
			<span class="display name vm" href="#subname_list">
				<h2 class="tit">{lang favforum}</h2>
				<img src="template/xiaoyu_duitangtouch/touch/style/img/image_browser_icon_next_browser_icon_next.png" class="dw" />
			</span>
	        <div id="subname_list" class="subname_list" display="true">
				<ul>
				<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">{lang favthread}</a></li>
				</ul>
	        </div>
		</span>
		<!--{else}-->
		<span class="category">
			<span class="display name vm" href="#subname_list">
				<h2 class="tit">{lang favthread}</h2>
				<img src="template/xiaoyu_duitangtouch/touch/style/img/image_browser_icon_next_browser_icon_next.png" class="dw" />
			</span>
	        <div id="subname_list" class="subname_list" display="true">
				<ul>
				<li><a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=forum">{lang favforum}</a></li>
				</ul>
	        </div>
		</span>
		<!--{/if}-->
    </div>
</header>

       <div class="card"> 
<div id="group-header"> 
<!-- main collectlist start -->
<!--{if $_GET['type'] == 'forum'}-->
<section class="topic-content"> 
    <ul class="base-list topic-list">
        <!--{if $list}-->
        <!--{loop $list $k $value}-->
        <li style="padding-left:0"><a href="$value[url]"><h3>$value[title]</h3></a></li>
        <!--{/loop}-->
        <!--{else}-->
        <li style="padding-left:0"><h3>{lang no_favorite_yet}</h3></li>
        <!--{/if}-->
    </ul> 
</section> 
<!--{else}-->
<!-- main threadlist start -->
        <section class="topic-content"> 
        <ul class="base-list topic-list">
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
        <!--{eval $thread = C::t('forum_thread')->fetch_by_tid_displayorder($value['id'], 0);}-->
        <li> 
        <a href="home.php?mod=space&uid=$thread[authorid]&do=profile"><img class="user-avatar" src="uc_server/avatar.php?uid=$thread[authorid]&size=small" /></a> 
        <a href="$value[url]" title="$value[title]">
        <h3>$value[title]</h3>
        <div class="info"> 
        <span class="left"><!--{eval echo dgmdate($value[dateline]);}--></span> 
        </div> </a> </li> 
        <!--{/loop}-->
        <!--{else}-->
        <li style="padding-left:0"><h3>{lang no_favorite_yet}</h3></li>
        <!--{/if}-->
     </ul> 
    </section> 
<!-- main threadlist end -->
<!--{/if}-->
<!--{if $multi}--><div class="xiaoyu_mipage cl">$multi</div><!--{/if}-->
</div>
</div>

 
<!-- main collectlist end -->

<!--{template common/footer}-->


