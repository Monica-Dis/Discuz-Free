<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{if $action == 'index' && $status != 2 && $status != 3}-->
    <!--{subtemplate group/group_list}-->
<!--{elseif $action == 'list'}-->
    <!--{subtemplate group/group_list}-->
<!--{elseif $action == 'memberlist'}-->
    <!--{subtemplate group/group_memberlist}-->
<!--{/if}-->
<!--{template common/footer}-->

