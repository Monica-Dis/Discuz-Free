<?php echo 'From: DisM.taobao.com';exit;?>
<link href="template/xiaoyu_duitangtouch/touch/style/about.css" rel="stylesheet" type="text/css" />
  <div class="pop-page-header">
  <span class="title">$_G[forum][name]</span>
  <div class="btn btn-left "><a href="javascript:;" onclick="history.go(-1)">&#x5173;&#x95ed;</a></div>
</div>
<div class="card" style="margin-top:-3px;"> 
    <div class="group-about"> 
      <section> 
       <h2 style="padding-top:12px;">&#x5c0f;&#x7ec4;&#x4ecb;&#x7ecd;</h2> 
       <div class="intro">
       <!--{if $_G['forum']['description']}-->$_G['forum']['description']<!--{/if}-->
       </div> 
      </section> 
      <section>
         <h2>$_G['forum']['membernum']&#x4e2a;&#x6210;&#x5458;</h2>
         <ul class="member-list">
          <!--{if $op == 'alluser'}-->
                <!--{if $adminuserlist}-->
                <!--{loop $adminuserlist $user}-->
                <li><a href="home.php?mod=space&uid=$user[uid]" title="{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}" ><img src="uc_server/avatar.php?uid=$user[uid]&size=small" alt="$user[username]" class="avatar" /><h3>$user[username]<span class="role">{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}</span></h3></a></li>
                <!--{/loop}-->
                <!--{/if}-->
            <!--{if $staruserlist || $alluserlist}-->
                <!--{if $staruserlist}-->
                <!--{loop $staruserlist $user}-->
                <li><a href="home.php?mod=space&uid=$user[uid]" title="{lang group_star_member_title}{if $user['online']} {lang login_normal_mode}{/if}">
                <img src="uc_server/avatar.php?uid=$user[uid]&size=small" alt="$user[username]" class="avatar" /><h3>$user[username]<span class="role">{lang group_star_member_title}{if $user['online']} {lang login_normal_mode}{/if}</span></h3></a></li>
                <!--{/loop}-->
                <!--{/if}-->
                <!--{if $alluserlist}-->
                <!--{loop $alluserlist $user}-->
                <li><a href="home.php?mod=space&uid=$user[uid]"><img src="uc_server/avatar.php?uid=$user[uid]&size=small" alt="$user[username]" class="avatar" /><h3>$user[username]</h3></a></li>
                <!--{/loop}-->
                <!--{/if}-->
            <!--{/if}-->
         <!--{/if}-->
         </ul>
        </section>
        <!--{if $multipage}--><div class="xiaoyu_mipage cl">$multipage</div><!--{/if}-->
    </div> 
   </div> 

<!--{if $status == 'isgroupuser'}-->
<style>.download-app{ padding-bottom:100px;}</style>
<div class="exit_btn"><a href="forum.php?mod=group&action=out&fid=$_G[fid]" class="rep_input">{lang group_exit}</a></div><!--{/if}-->

