<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if !$post['message'] && (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid']))}-->
<p class="tradebtn"><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]&page=$page">{lang post_add_aboutcounter}</a></p>
<!--{else}-->
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>
<!--{/if}-->
<!--{if $tradenum}-->
<!--{if $trades}-->
<!--{loop $trades $key $trade}-->
<div class="xiaoyu_special xiaoyu_trade">
<!--{if $trade['thumb']}-->
<div class="xiaoyu_special_img"><img src="$trade[thumb]" /></div>
<!--{/if}-->
<table cellpadding="0" cellspacing="0" class="xiaoyu_table xiaoyu_trade_table">
  <tr><th>&#x5546;&#x54c1;&#x540d;&#x79f0;&#x003a; </th><td>$trade[subject]</td></tr>
  <tr>
  <tr>
    <th>{lang trade_type_viewthread}: </th>
    <td><!--{if $trade['quality'] == 1}-->{lang trade_new}<!--{/if}--><!--{if $trade['quality'] == 2}-->{lang trade_old}<!--{/if}-->{lang trade_type_buy}</td>                                 
  </tr>
  <tr>
    <th>{lang trade_remaindays}: </th>
    <td><!--{if $trade[closed]}--><em>{lang trade_timeout}</em><!--{elseif $trade[expiration] > 0}-->{$trade[expiration]}{lang days}{$trade[expirationhour]}{lang trade_hour}<!--{elseif $trade[expiration] == -1}--><em>{lang trade_timeout}</em><!--{else}-->&nbsp;<!--{/if}--></td>                  
  </tr>
  <!--{if $trade[price] > 0}-->
  <tr>
    <th>&#x73b0;&#x4ef7;&#x003a; </th>
    <td><strong>$trade[price]</strong>&nbsp;{lang payment_unit}&nbsp;&nbsp;
<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
{lang trade_additional}:&nbsp;<strong>$trade[credit]</strong>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}           
<!--{/if}--></td>                  
  </tr>
  <!--{/if}-->
  <!--{if $trade['costprice'] > 0}-->
  <tr>
    <th>&#x539f;&#x4ef7;&#x003a; </th>
    <td class="oldprice">$trade[costprice] {lang payment_unit}
<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade['costcredit'] > 0}-->&nbsp; &#x9644;&#x52a0;&#xff1a;
$trade[costcredit] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}
<!--{/if}-->
    </td>
  </tr>
  <!--{/if}-->
</table>    
</div>
<!--{/loop}-->
<!--{/if}-->
<!--{else}-->
<div class="notice">{lang trade_nogoods}</div>
<!--{/if}-->


