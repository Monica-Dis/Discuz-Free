<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $debate[umpire]}-->
<!--{if $debate['umpirepoint']}-->
<div class="debatend">
  <!--{if $debate[winner]}-->
  <!--{if $debate[winner] == 1}-->
  <h3><strong>{lang debate_square}</strong>{lang debate_winner}</h3>
  <!--{elseif $debate[winner] == 2}-->
  <h3><strong>{lang debate_opponent}</strong>{lang debate_winner}</h3>
  <!--{else}-->
  <h3>{lang debate_draw}</h3>
  <!--{/if}-->
  <!--{/if}-->
  <h4>{lang debate_comment_dateline}: $debate[endtime]</h4>
  <!--{if $debate[umpirepoint]}--><p>{lang debate_umpirepoint}: $debate[umpirepoint]</p><!--{/if}-->
  <!--{if $debate[bestdebater]}--><p>{lang debate_bestdebater}: $debate[bestdebater]</p><!--{/if}-->
</div>
<!--{/if}-->
<!--{/if}-->
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>

<table cellpadding="0" cellspacing="0" class="xiaoyu_table xiaoyu_debate">
  <tr>
    <td>
      <div>
        <h3><span>{lang debater}:($debate[affirmdebaters])</span>{lang debate_square}</h3>
        <p class="debateopt cl"><span><em style="background:#fb5e00; width:{echo $debate[affirmvoteswidth]}%"></em></span><strong>($debate[affirmvotes])</strong></p>
        <p class="debateinfo">$debate[affirmpoint]</p>
        <!--{if !$_G['forum_thread']['is_archived']}-->
        <p class="btn"><a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" class="button2">{lang debate_support}{lang debate_square}</a></p>
        <!--{/if}-->    
      </div>
    </td>
  </tr>
  <tr>
    <td>
      <div>
        <h3><span>{lang debater}:($debate[negadebaters])</span>{lang debate_opponent}</h3>
        <p class="debateopt cl"><span><em style="background:#00C8FB; width:{echo $debate[negavoteswidth]}%;"></em></span><strong>($debate[negavotes])</strong></p>
        <p class="debateinfo">$debate[negapoint]</p>
        <p class="btn"><a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" class="button2">{lang debate_support}{lang debate_opponent}</a></p>
      </div>
    </td>
  </tr>
</table>

<!--{if $debate[endtime]}-->
<div class="debateover">
  <p>{lang endtime}: $debate[endtime]</p>
  <!--{if $debate[umpire]}--><p>{lang debate_umpire}: <span>$debate[umpire]</span></p><!--{/if}-->
</div>
<!--{/if}-->
<!--{if $debate[umpire] && $_G['username'] && $debate[umpire] == $_G['member']['username']}-->
<div class="debatebtn">
	<!--{if $debate[remaintime] && !$debate[umpirepoint]}-->
	<p><a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}">{lang debate_umpire_end}</a></p>
	<!--{elseif TIMESTAMP - $debate['dbendtime'] < 3600}-->
	<p><a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}">{lang debate_umpirepoint_edit}</a></p>
	<!--{/if}-->
</div>
<!--{/if}-->


