<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{loop $announcelist $ann}-->
<!--{if $annid == $ann[id]}-->
<div class="xiaoyu_view_box bg_f b_t b_b">

<div class="xiaoyu_subject b_b cl">
        <h1><span class="name">$ann[subject]</span></h1>
      <p class="s_info cl">
          <span class="mr">$ann[author]</span> <span class="time mr">$ann[starttime]</span>
      </p>  
    </div> 
    <div id="announce$ann[id]" class="v_li  cl" style="min-height:230px; font-size:14px; ">         
   $ann[message]
   </div>
    
 </div>
 <!--{/if}-->
 <!--{/loop}-->   

<!--{template common/footer}-->

