<?php echo 'From: DisM.taobao.com';exit;?>
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>
<form id="poll" name="poll" method="post" autocomplete="off" action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes&mobile=2" >
	<input type="hidden" name="formhash" value="{FORMHASH}" />
  <div class="xiaoyu_poll">
    <h3><!--{if $multiple}--><!--{if $maxchoices}--><span>{lang poll_more_than}</span><!--{/if}-->{lang poll_multiple}{lang thread_poll} <!--{else}-->{lang poll_single}{lang thread_poll}<!--{/if}--></h3>
    <ul>
      <li class="info"><!--{if $visiblepoll && $_G['group']['allowvote']}-->{lang poll_after_result}<!--{/if}-->{lang poll_voterscount}</li>
      <!--{if $_G[forum_thread][remaintime]}-->
      <li class="info">
        {lang poll_count_down}:
        <!--{if $_G[forum_thread][remaintime][0]}-->$_G[forum_thread][remaintime][0] {lang days}<!--{/if}-->
        <!--{if $_G[forum_thread][remaintime][1]}-->$_G[forum_thread][remaintime][1] {lang poll_hour}<!--{/if}-->
        $_G[forum_thread][remaintime][2] {lang poll_minute}
      </li>
      <!--{elseif $expiration && $expirations < TIMESTAMP}-->
      <li class="info">{lang poll_end}</li>
      <!--{/if}-->
      
      <!--{loop $polloptions $key $option}-->
      <li class="poll_opt">
      <!--{if $_G['group']['allowvote']}-->
      <input type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if}  />
      <!--{/if}-->
      <label for="option_$key">$option[polloption]</label>
      </li>
      <!--{if !$visiblepoll}-->
      <li class="poll_bg cl"><span><em style="width:{$option[percent]}%; background:#$option[color]"></em></span><strong>($option[votes])</strong></li>
      <!--{/if}-->
      <!--{/loop}-->
      <!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
      <li class="pollbtn"><input type="submit" name="pollsubmit" id="pollsubmit" value="{lang submit}" class="button2" /></li>
      <!--{if $overt}--><li class="info">({lang poll_msg_overt})</li><!--{/if}-->
      <!--{elseif !$allwvoteusergroup}-->
      <li class="info"><!--{if !$_G['uid']}-->{lang poll_msg_allwvote_user}<!--{else}-->{lang poll_msg_allwvoteusergroup}<!--{/if}--></li>   
      <!--{elseif !$allowvotepolled}-->
      <li class="info">{lang poll_msg_allowvotepolled}</li>
      <!--{elseif !$allowvotethread}-->
      <li class="info">{lang poll_msg_allowvotethread}</li>
      <!--{/if}-->  
    </ul>

  </div>
</form>


