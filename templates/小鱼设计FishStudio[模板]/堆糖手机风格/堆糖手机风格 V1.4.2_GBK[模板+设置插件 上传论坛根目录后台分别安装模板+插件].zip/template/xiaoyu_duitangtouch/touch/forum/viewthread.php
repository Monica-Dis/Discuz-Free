<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->
<link href="template/xiaoyu_duitangtouch/touch/style/view_2.css" rel="stylesheet" type="text/css" />
<style>#TalionNav{ display:none}</style>
<!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
<!--{eval $table='forum_attachment_'.substr($thread['tid'], -1);$tpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($thread[tid]);$tpid = $tpost['pid'];}-->
<div class="vnav">
	<a href="<!--{if $_GET[fromguid] == 'hot'}-->forum.php?mod=guide&view=hot&page=$_GET[page]<!--{else}-->forum.php?mod=forumdisplay&fid=$_G[fid]&<!--{eval echo rawurldecode($_GET[extra]);}--><!--{/if}-->" class="fa backleft fishz" >��������</a><a href="javascript:;" class="xiaoyu_pop_up fishr y">&nbsp;</a>
    <span class="xiaoyuallrep y"><span class="repnum">$_G[forum_thread][allreplies]</span></span>
</div>
<!--{hook/viewthread_top_mobile}-->
<!-- main postlist start -->
   <div class="xiaoyu_view_box">
	<div class="xiaoyu_subject cl">
        <h1><a href="forum.php?mod=viewthread&tid=$_G[tid]">
            <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
            <span>[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]</span>
            <!--{/if}-->
            <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
            <span>[{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]</span>
            <!--{/if}-->
            <span class="name">$_G[forum_thread][subject]</span>
            <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
            <!--{/if}-->
        </a></h1>
      <p class="s_info cl" style="display:none">
          <span class="mr v_name">$_G[forum_thread][author]</span> <span class="time mr"> <!--{eval echo dgmdate($_G[forum_thread][dateline]);}--></span>
      </p>  
    </div>
	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
    <!--{eval $author=DB::fetch_first("SELECT m.*,g.*,p.* FROM ".DB::table('common_member')." m,".DB::table('common_usergroup')." g,".DB::table('common_member_profile')." p WHERE m.uid='$post[authorid]' AND g.groupid=m.groupid AND p.uid=m.uid");}-->
	<!--{hook/viewthread_posttop_mobile $postcount}-->
    
   <div id="pid$post[pid]" class="v_li cl">
   <div class="v_com" {if $post[first]} style=" border-bottom:none; padding-bottom:20px"{/if} >
       	<div class="xiaoyu_vavatar cl">
       <div class="reply_list_img"> <a href="home.php?mod=space&uid=$post['authorid']&do=profile" class="viewt_avatar"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->" style="width:35px;height:35px;" /></a></div><!--{if !$post[first]}-->
       
       			<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
                <div class="r_dz">
					<a class="replyadd" href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', '');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = ($('review_support_$post[pid]').innerHTML ? $('review_support_$post[pid]').innerHTML : 0) + ' {lang activity_member_unit} {lang support_reply}'"><span id="review_support_$post[pid]">{if $post[postreview][support]}$post[postreview][support]{else}0{/if}</span></a>
                    </div>
					<!--{/if}-->
       <!--{/if}-->
       
        <div class="auth_msg cl">
        <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
        <a href="home.php?mod=space&uid=$post[authorid]" class="user_name">$post[author]</a>
        <!--{else}-->
        <!--{if !$post['authorid']}-->
        <a href="javascript:;" class="user_name">{lang guest}</a>
        <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
        <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]" class="user_name">{lang anonymous}</a><!--{else}--><a href="javascript:;" class="user_name">{lang anonymous}</a><!--{/if}-->
        <!--{else}--><a href="javascript:;" class="user_name">$post[author] {lang member_deleted}</a><!--{/if}--><!--{/if}-->
        <div class="time">{$post[dateline]}<!--{if $post[first]}--> &nbsp;&middot;&nbsp;���{$_G[forum_thread][views]}<!--{/if}--></div>      

    </div>       <!--{if $post[first]}-->
                    <!--{eval $favorite = C::t('home_favorite')->fetch_by_id_idtype($_G['tid'], 'tid', $_G['uid']);}-->
					<div class="fish_favbtn"><!--{if $favorite && $_G['uid']}--><a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favorite['favid']" class="deletefavbtn">��{lang favorite}</a><!--{else}--><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" {if $_G['uid']}class="favbtn"{/if}>{lang favorite}</a><!--{/if}--></div>
					<!--{/if}-->
    </div>
       <div class="xiaoyu_message popup blue {if $post[first]}vmess{else}rep_mess{/if}" href="#moption_$post[pid]">
                	<!--{if $post['warned']}-->
                        <span class="grey quote xiaoyu_quote">{lang warn_get}</span>
                    <!--{/if}-->
                    <!--{if !$post['first'] && !empty($post[subject])}-->
                        <h2><strong>$post[subject]</strong></h2>
                    <!--{/if}-->
                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                        <div class="grey quote xiaoyu_quote">{lang message_banned}</div>
                    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                        <div class="grey quote xiaoyu_quote">{lang message_single_banned}</div>
                    <!--{elseif $needhiddenreply}-->
                        <div class="grey quote xiaoyu_quote">{lang message_ishidden_hiddenreplies}</div>
                    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
						<!--{template forum/viewthread_pay}-->
					<!--{else}-->

                    	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                            <div class="grey quote xiaoyu_quote">{lang admin_message_banned}</div>
                        <!--{elseif $post['status'] & 1}-->
                            <div class="grey quote xiaoyu_quote">{lang admin_message_single_banned}</div>
                        <!--{/if}-->
                        <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                            {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
                        <!--{/if}-->

                        <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                        	<!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                                <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                    {lang has_expired}
                                <!--{else}-->
                                    <div class="box_ex2 viewsort">
                                        <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                                    <!--{loop $threadsortshow['optionlist'] $option}-->
                                        <!--{if $option['type'] != 'info'}-->
                                            $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                                        <!--{/if}-->
                                    <!--{/loop}-->
                                    </div>
                                <!--{/if}-->
                            <!--{/if}-->
                        <!--{/if}-->
                        <!--{if $post['first']}-->
                            <!--{if !$_G[forum_thread][special]}-->
                                $post[message]
                            <!--{elseif $_G[forum_thread][special] == 1}-->
                                <!--{template forum/viewthread_poll}-->
                            <!--{elseif $_G[forum_thread][special] == 2}-->
                                <!--{template forum/viewthread_trade}-->
                            <!--{elseif $_G[forum_thread][special] == 3}-->
                                <!--{template forum/viewthread_reward}-->
                            <!--{elseif $_G[forum_thread][special] == 4}-->
                                <!--{template forum/viewthread_activity}-->
                            <!--{elseif $_G[forum_thread][special] == 5}-->
                                <!--{template forum/viewthread_debate}-->
                            <!--{elseif $threadplughtml}-->
                                $threadplughtml
                                $post[message]
                            <!--{else}-->
                            	$post[message]
                            <!--{/if}-->
                        <!--{else}-->
                            $post[message]
                        <!--{/if}-->

					<!--{/if}-->

            <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
			<!--{if $post['attachment']}-->
               <div class="grey quote xiaoyu_quote">
               {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
               </div>
            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
               <!--{if $post['imagelist']}-->
				<!--{if count($post['imagelist']) == 1}-->
				<ul class="img_one">{echo showattach($post, 1)}</ul>
				<!--{else}-->
				<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
				<!--{/if}-->
				<!--{/if}-->
                <!--{if $post['attachlist']}-->
				<ul>{echo showattach($post)}</ul>
				<!--{/if}-->
			<!--{/if}-->
			<!--{/if}-->
			</div>
            
 <!--{if $post[first]}-->           
<div class="marsk_container">
  <div class="marsk_list bg_f f_b"> 
   <ul>
   
    <!--{eval $favorite = C::t('home_favorite')->fetch_by_id_idtype($_G['tid'], 'tid', $_G['uid']);}-->
    <!--{if $favorite && $_G['uid']}--><li><a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favorite['favid']" class="deletefavbtn"><i class="xiaoyu_font">&#xe7e2;</i>&#x53d6;&#x6d88;{lang thread_favorite}</a></li><!--{else}--><li><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" {if $_G['uid']}class="favbtn"{/if}><i class="xiaoyu_font">&#xe7e2;</i>{lang thread_favorite}</a></li><!--{/if}-->
	<!--{if $_G[basescript] != 'group'}--><li><a href="$upnavlink"><i class="xiaoyu_font">&#xe679;</i>{lang return_forumdisplay}</a></li><!--{/if}--> 
    <li><a href="./"><i class="xiaoyu_font">&#xe6ee;</i>{lang homepage}</a></li> 
    </ul>
    <!--{if $_G['forum']['ismoderator']}-->
<ul class="xiaoyu_ismoder">
    <!--{if !$_G['forum_thread']['special']}-->
<li><a title="{lang edit}" class="redirect li_item" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a></li>
<!--{/if}-->
<li><a href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}" title="{lang delete}" class="dialog li_item" >{lang delete}</a></li>
<li><a href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4" title="{lang close}" class="dialog li_item" >{lang close}</a></li>
<li><a href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}" title="{lang admin_banpost}" class="dialog li_item" >{lang admin_banpost}</a></li>
<li><a href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"title="{lang topicadmin_warn_add}" class="dialog li_item" >{lang topicadmin_warn_add}</a></li>
</ul> 
<!--{/if}-->

   
  </div>
</div>
<!--{/if}-->
<!--{if $_G['forum']['ismoderator']}-->
<!-- manage start -->
<!--{if !$post[first]}-->
<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
<!-- <div id="#moption_$post[pid]" class="replybox replybtn" display="true" style="display:none;" > -->
<ul class="xiaoyu_dialogbox">     
<!--{if $_G[uid] && $allowpostreply && !$post[first]}--><li class="kym"><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" class="redirect li_item">��Ӧ $post[author]</a></li><!--{/if}-->
<li><a title="{lang edit}" class="redirect li_item" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a></li>
<!--{if $_G['group']['allowdelpost']}--><li><a title="{lang modmenu_deletepost}" class="dialog li_item" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}">{lang modmenu_deletepost}</a></li><!--{/if}-->
<!--{if $_G['group']['allowbanpost']}--><li><a title="{lang modmenu_banpost}" class="dialog li_item" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}">{lang modmenu_banpost}</a></li><!--{/if}-->
<!--{if $_G['group']['allowwarnpost']}--><li><a title="{lang modmenu_warn}" class="dialog li_item" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}">{lang modmenu_warn}</a></li><!--{/if}-->
</ul>
</div>
<!--{/if}-->
<!-- manage end -->
<!--{/if}-->

<!--{if $post['first']}-->
<div class="xiaoyu_vpost cl">
<div class="xiaoyu_vavatar">
       <div class="reply_list_img"> <a href="home.php?mod=space&uid=$post['authorid']&do=profile" class="viewt_avatar"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->" style="width:48px;height:48px;" /></a></div><!--{if !$post[first]}--><!--{/if}-->
       
       
        <div class="auth_msg cl">
        <div class="time">����</div>
        <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
        <a href="home.php?mod=space&uid=$post[authorid]" class="user_name">$post[author]</a>
        <!--{else}-->
        <!--{if !$post['authorid']}-->
        <a href="javascript:;" class="user_name">{lang guest}</a>
        <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
        <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]" class="user_name">{lang anonymous}</a><!--{else}--><a href="javascript:;" class="user_name">{lang anonymous}</a><!--{/if}-->
        <!--{else}--><a href="javascript:;" class="user_name">$post[author] {lang member_deleted}</a><!--{/if}--><!--{/if}-->
        
    </div>
    </div>
</div>
<!--{if $post['relateitem']}-->
<section id="TopicSelectionsWidget"> 
   <div class="zxtit"><span>{lang related_thread}</span></div>
   <div id="TopicSelections">
    <ul>
        <!--{loop $post['relateitem'] $var}-->
     <li>
     <a href="forum.php?mod=viewthread&tid=$var[tid]" title="$var[subject]" class="gl-topic-item">
        <!--{eval $table='forum_attachment_'.substr($var[tid], -1);$tpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($var[tid]);$tpid = $tpost['pid'];}-->
        <!--{eval $query = DB::query("SELECT * FROM ".DB::table($table)." WHERE pid='$tpid' AND isimage!=0 ORDER BY `dateline` ASC"); 
        while($value = DB::fetch($query))$var[aids][]=$value['aid'];$var['pics']=count($var[aids]);}-->
       <!--{if $var[aids]}--><div class="gl-topic-cover"><img src="{eval echo(getforumimg($var['aids'][0],0,300,300))}" /></div> <!--{/if}-->
       <div class="gl-topic-title">$var[subject]</div>
       <div class="gl-topic-info">
        <span class="gl-topic-subtitle">$var[author]</span>
       </div></a></li>
       
        <!--{/loop}-->
    </ul>
   </div> 
  </section>
  <!--{/if}-->
  
<!--{/if}-->
 </div>   
 <!--{if $post[first]}-->
<div class="note-comments">
��������
<!--{if !$_G[forum_thread][allreplies]}-->
<p class="comment_empty">��Ҳ��˵Щʲô��</p>
<!--{/if}-->
</div> 
<!--{/if}-->
</div>
<!--{hook/viewthread_postbottom_mobile $postcount}-->
<!--{eval $postcount++;}-->
<!--{/loop}-->
   <div id="post_new"></div>
   <!--{if $multipage}--><div class="xiaoyu_page cl" style="margin-top:30px;">$multipage</div><!--{/if}-->
   
</div>

<!-- main postlist end -->
<!--{hook/viewthread_bottom_mobile}-->
<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			window.location.reload();
			
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>
<script type="text/javascript">
	$('.deletefavbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'deletesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			window.location.reload();
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
	
</script>


<div class="xiaoyu_v_memu_h cl"></div>
 <div id="xiaoyu_v_memu" class="xiaoyu_v_memu"> 
   <ul>        
    <!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
    <!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
    <li class="xioayu_recommend">
    <a id="recommend_add" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', 'recommendupdate({$_G['group']['allowrecommend']})');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = $('recommendv_add').innerHTML + ' {lang activity_member_unit}$_G[setting][recommendthread][addtext]'" title="{lang maketoponce}"><span class="text" id="recommendv_add">$_G[forum_thread][recommend_add]</span></a></li> 
    <!--{/if}-->
    <!--{/if}-->
    <li class="xiaoyu_favorite">
    <a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}" id="k_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" onmouseover="this.title = $('favoritenumber').innerHTML + ' {lang activity_member_unit}{lang thread_favorite}'" title="{lang fav_thread}">{$_G['forum_thread']['favtimes']}</a></li> 
    <li class="hf_box"><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]" class="xiaoyu_openrebox">��������...</a></li> 
   </ul> 
  </div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->


