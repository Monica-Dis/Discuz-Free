/*
	Copyright (c) 2020 by dism.taobao.com
	This is NOT a freeware, use is subject to license terms

	jQueryId: seditor.js 28601 2012-03-06 02:49:55Z monkey jQuery
*/

function seditor_showimgmenu(seditorkey) {
	var imgurl = jQuery(seditorkey + '_image_param_1').value;
	var width = parseInt(jQuery(seditorkey + '_image_param_2').value);
	var height = parseInt(jQuery(seditorkey + '_image_param_3').value);
	var extparams = '';
	if(width || height) {
		extparams = '=' + width + ',' + height
	}
	seditor_insertunit(seditorkey, '[img' + extparams + ']' + imgurl, '[/img]', null, 1);
	jQuery(seditorkey + '_image_param_1').value = '';
	hideMenu();
}

function seditor_menu(seditorkey, tag) {
	var sel = false;
	if(!isUndefined(jQuery(seditorkey + 'message').selectionStart)) {
		sel = jQuery(seditorkey + 'message').selectionEnd - jQuery(seditorkey + 'message').selectionStart;
	} else if(document.selection && document.selection.createRange) {
		jQuery(seditorkey + 'message').focus();
		var sel = document.selection.createRange();
		jQuery(seditorkey + 'message').sel = sel;
		sel = sel.text ? true : false;
	}
	if(sel) {
		seditor_insertunit(seditorkey, '[' + tag + ']', '[/' + tag + ']');
		return;
	}
	var ctrlid = seditorkey + tag;
	var menuid = ctrlid + '_menu';
	if(!jQuery(menuid)) {
		switch(tag) {
			case 'at':
				curatli = 0;
				atsubmitid = ctrlid + '_submit';
				setTimeout(function() {atFilter('', 'at_list','atListSet');jQuery('atkeyword').focus();}, 100);
				str = '�����û���:<br /><input type="text" id="atkeyword" style="width:240px" value="" class="px" onkeydown="atFilter(this.value, \'at_list\',\'atListSet\',event);" /><div class="p_pop" id="at_list" style="width:250px;"><ul><li>@�����˺ţ�������������������</li></ul></div>';
				submitstr = 'seditor_insertunit(\'' + seditorkey + '\', \'@\' + jQuery(\'atkeyword\').value.replace(/<\\/?b>/g, \'\')+\' \'); hideMenu();';
				break;
			case 'url':
				str = '���������ӵ�ַ:<br /><input type="text" id="' + ctrlid + '_param_1" sautocomplete="off" style="width: 98%" value="" class="px" />' +
					'<br />��������������:<br /><input type="text" id="' + ctrlid + '_param_2" style="width: 98%" value="" class="px" />';
				submitstr = "jQuery('" + ctrlid + "_param_2').value !== '' ? seditor_insertunit('" + seditorkey + "', '[url='+seditor_squarestrip(jQuery('" + ctrlid + "_param_1').value)+']'+jQuery('" + ctrlid + "_param_2').value, '[/url]', null, 1) : seditor_insertunit('" + seditorkey + "', '[url]'+jQuery('" + ctrlid + "_param_1').value, '[/url]', null, 1);hideMenu();";
				break;
			case 'code':
			case 'quote':
				var tagl = {'quote' : '������Ҫ���������', 'code' : '������Ҫ����Ĵ���'};
					str = tagl[tag] + ':<br /><textarea id="' + ctrlid + '_param_1" style="width: 98%" cols="50" rows="5" class="txtarea"></textarea>';
				submitstr = "seditor_insertunit('" + seditorkey + "', '[" + tag + "]'+jQuery('" + ctrlid + "_param_1').value, '[/" + tag + "]', null, 1);hideMenu();";
				break;
			case 'img':
				str = '������ͼƬ��ַ:<br /><input type="text" id="' + ctrlid + '_param_1" style="width: 98%" value="" class="px" onchange="loadimgsize(this.value, \'' + seditorkey + '\',\'' + tag + '\')" />' +
					'<p class="mtm">��(��ѡ): <input type="text" id="' + ctrlid + '_param_2" style="width: 15%" value="" class="px" /> &nbsp;' +
					'��(��ѡ): <input type="text" id="' + ctrlid + '_param_3" style="width: 15%" value="" class="px" /></p>';
				submitstr = "seditor_insertunit('" + seditorkey + "', '[img' + (jQuery('" + ctrlid + "_param_2').value !== '' && jQuery('" + ctrlid + "_param_3').value !== '' ? '='+jQuery('" + ctrlid + "_param_2').value+','+jQuery('" + ctrlid + "_param_3').value : '')+']'+seditor_squarestrip(jQuery('" + ctrlid + "_param_1').value), '[/img]', null, 1);hideMenu();";
				break;
		}
		var menu = document.createElement('div');
		menu.id = menuid;
		menu.style.display = 'none';
		menu.className = 'p_pof upf';
		menu.style.width = '270px';
		jQuery('append_parent').appendChild(menu);
		menu.innerHTML = '<span class="y"><a onclick="hideMenu()" class="flbc" href="javascript:;">�ر�</a></span><div class="p_opt cl"><form onsubmit="' + submitstr + ';return false;" autocomplete="off"><div>' + str + '</div><div class="pns mtn"><button type="submit" id="' + ctrlid + '_submit" class="pn pnc"><strong>�ύ</strong></button><button type="button" onClick="hideMenu()" class="pn"><em>ȡ��</em></button></div></form></div>';
	}
	showMenu({'ctrlid':ctrlid,'evt':'click','duration':3,'cache':0,'drag':1});
}

function seditor_squarestrip(str) {
	str = str.replace('[', '%5B');
	str = str.replace(']', '%5D');
	return str;
}

function seditor_insertunit(key, text, textend, moveend, selappend) {
	if(jQuery(key + 'message')) {
		jQuery(key + 'message').focus();
	}
	textend = isUndefined(textend) ? '' : textend;
	moveend = isUndefined(textend) ? 0 : moveend;
	selappend = isUndefined(selappend) ? 1 : selappend;
	startlen = strlen(text);
	endlen = strlen(textend);
	if(!isUndefined(jQuery(key + 'message').selectionStart)) {
		if(selappend) {
			var opn = jQuery(key + 'message').selectionStart + 0;
			if(textend != '') {
				text = text + jQuery(key + 'message').value.substring(jQuery(key + 'message').selectionStart, jQuery(key + 'message').selectionEnd) + textend;
			}
			jQuery(key + 'message').value = jQuery(key + 'message').value.substr(0, jQuery(key + 'message').selectionStart) + text + jQuery(key + 'message').value.substr(jQuery(key + 'message').selectionEnd);
			if(!moveend) {
				jQuery(key + 'message').selectionStart = opn + strlen(text) - endlen;
				jQuery(key + 'message').selectionEnd = opn + strlen(text) - endlen;
			}
		} else {
			text = text + textend;
			jQuery(key + 'message').value = jQuery(key + 'message').value.substr(0, jQuery(key + 'message').selectionStart) + text + jQuery(key + 'message').value.substr(jQuery(key + 'message').selectionEnd);
		}
	} else if(document.selection && document.selection.createRange) {
		var sel = document.selection.createRange();
		if(!sel.text.length && jQuery(key + 'message').sel) {
			sel = jQuery(key + 'message').sel;
			jQuery(key + 'message').sel = null;
		}
		if(selappend) {
			if(textend != '') {
				text = text + sel.text + textend;
			}
			sel.text = text.replace(/\r?\n/g, '\r\n');
			if(!moveend) {
				sel.moveStart('character', -endlen);
				sel.moveEnd('character', -endlen);
			}
			sel.select();
		} else {
			sel.text = text + textend;
		}
	} else {
		jQuery(key + 'message').value += text;
	}
	hideMenu(2);
	if(BROWSER.ie) {
		doane();
	}
}

function seditor_ctlent(event, script) {
	if(event.ctrlKey && event.keyCode == 13 || event.altKey && event.keyCode == 83) {
		eval(script);
	}
}

function loadimgsize(imgurl, editor, p) {
	var editor = !editor ? editorid : editor;
	var s = new Object();
	var p = !p ? '_image' : p;
	s.img = new Image();
	s.img.src = imgurl;
	s.loadCheck = function () {
		if(s.img.complete) {
			jQuery(editor + p + '_param_2').value = s.img.width ? s.img.width : '';
			jQuery(editor + p + '_param_3').value = s.img.height ? s.img.height : '';
		} else {
			setTimeout(function () {s.loadCheck();}, 100);
		}
	};
	s.loadCheck();
}

