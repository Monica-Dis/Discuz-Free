<?php echo 'From: DisM.taobao.com';exit;?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml"><head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - DisM.Taobao.Com!</title>
<!--{if $_G['basescript'] == 'portal'}--><base href="{$_G['siteurl']}" /><!--{/if}--><!--{eval loadcache('plugin');}-->
<!--{if $_G['cache']['plugin']['xiaoyu_duitangtouch']}--><!--{eval require './source/plugin/xiaoyu_duitangtouch/core.inc.php';}--><!--{/if}-->
<!--<link rel="stylesheet" href="{STATICURL}image/mobile/style.css" type="text/css" media="all"> -->
<script src="template/xiaoyu_duitangtouch/touch/style/js/jquery.min.js"></script>
<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>
<!--{if $action !='nav' && CURMODULE != 'misc'}--><!--{/if}-->
<script src="{STATICURL}js/mobile/common.js?{VERHASH}" charset="{CHARSET}"></script>
<link rel="stylesheet" type="text/css" href="template/xiaoyu_duitangtouch/touch/style/xiaoyu.css" />
<link rel="stylesheet" type="text/css" href="template/xiaoyu_duitangtouch/touch/style/xiaoyu_mi.css" />
<link rel="stylesheet" type="text/css" href="template/xiaoyu_duitangtouch/touch/style/xiaoyu_db.css" />
<link href="template/xiaoyu_duitangtouch/touch/style/xiaoyu_common.css" rel="stylesheet" type="text/css" />
<style>$xiaoyu_dtset['xiaoyucss']</style>
</head>
<body id="xiaoyu_bg_{$_G[basescript]}" class="bg xiaoyu_mobile {if CURMODULE=='space' && $_GET[do]=='profile'}pg_ucenter{elseif $show_message}pg_showmessage{else}pg_{CURMODULE}{/if}">
<!--{hook/global_header_mobile}-->
  <div id="TalionNav">
   <header class="TalionNav">
    <div class="TalionNav-primary">
     <a href="./"><h1>$_G[setting][bbname]</h1></a>
     <nav>
      <ul>$xiaoyu_dtset['xiaoyu_topnav']</ul>
      <span><a href="search.php?mod=forum"></a></span>
     </nav>
    </div>
   </header>
  </div>
<div class="db_page"> 
<!-- header end -->

