<?php echo 'From: DisM.taobao.com';exit;?>
<script type="text/javascript" src="template/xiaoyu_duitangtouch/touch/style/js/common.js"></script>
<script type="text/javascript" src="template/xiaoyu_duitangtouch/touch/style/js/seditor.js"></script>
<div class="fpd cl">
	<!--{if in_array('bold', $seditor[1])}-->
		<a href="javascript:;" title="{lang e_bold}" class="xiaoyu_font fbld"{if empty($seditor[2])} onclick="seditor_insertunit('$seditor[0]', '[b]', '[/b]');doane(event);"{/if}>&#xe6fe;</a>
	<!--{/if}-->
	<!--{if in_array('color', $seditor[1])}-->
      <a href="javascript:;" title="{lang e_forecolor}" class="xiaoyu_font fclr" id="{$seditor[0]}forecolor"{if empty($seditor[2])} onclick="showMenu({'ctrlid':this.id,'evt':'click','layer':2});return false;"{/if}>&#xe6a4;</a>
	<!--{/if}-->
    
    	<!--{if in_array('img', $seditor[1])}-->
		<a id="{$seditor[0]}img" href="javascript:;" title="{lang e_image}" class="xiaoyu_font fmg"{if empty($seditor[2])} onclick="seditor_menu('$seditor[0]', 'img');doane(event);"{/if} style="display:none">&#xe6ac;</a>
	<!--{/if}-->
    
	<!--{if in_array('quote', $seditor[1])}-->
        <a href="javascript:;" title="{lang e_quote}" class="xiaoyu_font fqt"{if empty($seditor[2])} onclick="seditor_insertunit('$seditor[0]', '[quote]', '[/quote]');doane(event);"{/if}>&#xe676;</a>
	<!--{/if}-->
	<!--{if in_array('code', $seditor[1])}-->
    	
        <a href="javascript:;" title="{lang e_code}" class="xiaoyu_font fcd"{if empty($seditor[2])} onclick="seditor_insertunit('$seditor[0]', '[code]', '[/code]');doane(event);"{/if}>&#xe671;</a>
    
	<!--{/if}-->
	<!--{if in_array('smilies', $seditor[1])}-->
		<a href="javascript:;" class="xiaoyu_font fsml" id="{$seditor[0]}sml"{if empty($seditor[2])} onclick="showMenu({'ctrlid':this.id,'evt':'click','layer':2});return false;"{/if}>&#xe675;</a>
	<!--{/if}-->
	
</div>
  <div id="fastpostsml_menu" class="sllt fast_showbox" style="position: absolute; z-index: 302;  display: none;"> 
   <div id="fastpostsmiliesdiv" style="overflow: hidden;"> 
    <div id="fastpostsmiliesdiv_data"> 
     <table id="fastpostsmiliesdiv_table" cellpadding="0" cellspacing="0"> 
      <tbody> 
       <tr> 
        <td onclick="seditor_insertunit('fastpost', ':)')" id="fastpostsmilie_1_td"><img id="smilie_1" width="20" height="20" src="static/image/smiley/default/smile.gif" alt=":)" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':(')" id="fastpostsmilie_2_td" initialized="true"><img id="smilie_2" width="20" height="20" src="static/image/smiley/default/sad.gif" alt=":(" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':D')" id="fastpostsmilie_3_td" initialized="true"><img id="smilie_3" width="20" height="20" src="static/image/smiley/default/biggrin.gif" alt=":D" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':\'(')" id="fastpostsmilie_4_td" initialized="true"><img id="smilie_4" width="20" height="20" src="static/image/smiley/default/cry.gif" alt=":'(" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':@')" id="fastpostsmilie_5_td"><img id="smilie_5" width="20" height="20" src="static/image/smiley/default/huffy.gif" alt=":@" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':o')" id="fastpostsmilie_6_td"><img id="smilie_6" width="20" height="20" src="static/image/smiley/default/shocked.gif" alt=":o" /></td> 
        
       </tr>
       <tr>
        <td onclick="seditor_insertunit('fastpost', ':P')" id="fastpostsmilie_7_td"><img id="smilie_7" width="20" height="20" src="static/image/smiley/default/tongue.gif" alt=":P" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':$')" id="fastpostsmilie_8_td"><img id="smilie_8" width="20" height="20" src="static/image/smiley/default/skym.gif" alt=":$" /></td>
        <td onclick="seditor_insertunit('fastpost', ';P')" id="fastpostsmilie_9_td" initialized="true"><img id="smilie_9" width="20" height="20" src="static/image/smiley/default/titter.gif" alt=";P" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':L')" id="fastpostsmilie_10_td" initialized="true"><img id="smilie_10" width="20" height="20" src="static/image/smiley/default/sweat.gif" alt=":L" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':Q')" id="fastpostsmilie_11_td"><img id="smilie_11" width="20" height="20" src="static/image/smiley/default/mad.gif" alt=":Q" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':lol')" id="fastpostsmilie_12_td"><img id="smilie_12" width="20" height="20" src="static/image/smiley/default/lol.gif" alt=":lol" /></td> 
       </tr>
       <tr> 
       
        <td onclick="seditor_insertunit('fastpost', ':loveliness:')" id="fastpostsmilie_13_td"><img id="smilie_13" width="20" height="20" src="static/image/smiley/default/loveliness.gif" alt=":loveliness:" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':funk:')" id="fastpostsmilie_14_td"><img id="smilie_14" width="20" height="20" src="static/image/smiley/default/funk.gif" alt=":funk:" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':curse:')" id="fastpostsmilie_15_td"><img id="smilie_15" width="20" height="20" src="static/image/smiley/default/curse.gif" alt=":curse:" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':dizzy:')" id="fastpostsmilie_16_td"><img id="smilie_16" width="20" height="20" src="static/image/smiley/default/dizzy.gif" alt=":dizzy:" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':shutup:')" id="fastpostsmilie_17_td" initialized="true"><img id="smilie_17" width="20" height="20" src="static/image/smiley/default/shutup.gif" alt=":shutup:" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':sleepy:')" id="fastpostsmilie_18_td" initialized="true"><img id="smilie_18" width="20" height="20" src="static/image/smiley/default/sleepy.gif" alt=":sleepy:" /></td>
       </tr> 
       <tr> 
         
        <td onclick="seditor_insertunit('fastpost', ':hug:')" id="fastpostsmilie_19_td"><img id="smilie_19" width="20" height="20" src="static/image/smiley/default/hug.gif" alt=":hug:" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':victory:')" id="fastpostsmilie_20_td"><img id="smilie_20" width="20" height="20" src="static/image/smiley/default/victory.gif" alt=":victory:" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':time:')" id="fastpostsmilie_21_td"><img id="smilie_21" width="20" height="20" src="static/image/smiley/default/time.gif" alt=":time:" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':kiss:')" id="fastpostsmilie_22_td"><img id="smilie_22" width="20" height="20" src="static/image/smiley/default/kiss.gif" alt=":kiss:" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':handshake')" id="fastpostsmilie_23_td"><img id="smilie_23" width="20" height="20" src="static/image/smiley/default/handshake.gif" alt=":handshake" /></td> 
        <td onclick="seditor_insertunit('fastpost', ':call:')" id="fastpostsmilie_24_td"><img id="smilie_24" width="20" height="20" src="static/image/smiley/default/call.gif" alt=":call:" /></td> 
       </tr>
      </tbody> 
     </table> 
    </div> 
   </div> 
  </div> 
  <div id="fastpostforecolor_menu" class="colorbox fast_showbox" style="position: absolute; z-index: 302;  display: none;"> 
   <input type="button" style="background-color: Black" onclick="seditor_insertunit('fastpost', '[color=Black]', '[/color]')" class="" /> 
   <input type="button" style="background-color: Sienna" onclick="seditor_insertunit('fastpost', '[color=Sienna]', '[/color]')" /> 
   <input type="button" style="background-color: DarkOliveGreen" onclick="seditor_insertunit('fastpost', '[color=DarkOliveGreen]', '[/color]')" /> 
   <input type="button" style="background-color: DarkGreen" onclick="seditor_insertunit('fastpost', '[color=DarkGreen]', '[/color]')" /> 
   <input type="button" style="background-color: DarkSlateBlue" onclick="seditor_insertunit('fastpost', '[color=DarkSlateBlue]', '[/color]')" /> 
   <input type="button" style="background-color: Navy" onclick="seditor_insertunit('fastpost', '[color=Navy]', '[/color]')" /> 
   <input type="button" style="background-color: Indigo" onclick="seditor_insertunit('fastpost', '[color=Indigo]', '[/color]')" /> 
   <input type="button" style="background-color: DarkSlateGray" onclick="seditor_insertunit('fastpost', '[color=DarkSlateGray]', '[/color]')" /> 
   <br /> 
   <input type="button" style="background-color: DarkRed" onclick="seditor_insertunit('fastpost', '[color=DarkRed]', '[/color]')" /> 
   <input type="button" style="background-color: DarkOrange" onclick="seditor_insertunit('fastpost', '[color=DarkOrange]', '[/color]')" /> 
   <input type="button" style="background-color: Olive" onclick="seditor_insertunit('fastpost', '[color=Olive]', '[/color]')" /> 
   <input type="button" style="background-color: Green" onclick="seditor_insertunit('fastpost', '[color=Green]', '[/color]')" /> 
   <input type="button" style="background-color: Teal" onclick="seditor_insertunit('fastpost', '[color=Teal]', '[/color]')" /> 
   <input type="button" style="background-color: Blue" onclick="seditor_insertunit('fastpost', '[color=Blue]', '[/color]')" /> 
   <input type="button" style="background-color: SlateGray" onclick="seditor_insertunit('fastpost', '[color=SlateGray]', '[/color]')" /> 
   <input type="button" style="background-color: DimGray" onclick="seditor_insertunit('fastpost', '[color=DimGray]', '[/color]')" /> 
   <br /> 
   <input type="button" style="background-color: Red" onclick="seditor_insertunit('fastpost', '[color=Red]', '[/color]')" /> 
   <input type="button" style="background-color: SandyBrown" onclick="seditor_insertunit('fastpost', '[color=SandyBrown]', '[/color]')" /> 
   <input type="button" style="background-color: YellowGreen" onclick="seditor_insertunit('fastpost', '[color=YellowGreen]', '[/color]')" /> 
   <input type="button" style="background-color: SeaGreen" onclick="seditor_insertunit('fastpost', '[color=SeaGreen]', '[/color]')" /> 
   <input type="button" style="background-color: MediumTurquoise" onclick="seditor_insertunit('fastpost', '[color=MediumTurquoise]', '[/color]')" /> 
   <input type="button" style="background-color: RoyalBlue" onclick="seditor_insertunit('fastpost', '[color=RoyalBlue]', '[/color]')" /> 
   <input type="button" style="background-color: Purple" onclick="seditor_insertunit('fastpost', '[color=Purple]', '[/color]')" /> 
   <input type="button" style="background-color: Gray" onclick="seditor_insertunit('fastpost', '[color=Gray]', '[/color]')" /> 
   <br /> 
   <input type="button" style="background-color: Magenta" onclick="seditor_insertunit('fastpost', '[color=Magenta]', '[/color]')" /> 
   <input type="button" style="background-color: Orange" onclick="seditor_insertunit('fastpost', '[color=Orange]', '[/color]')" /> 
   <input type="button" style="background-color: Yellow" onclick="seditor_insertunit('fastpost', '[color=Yellow]', '[/color]')" /> 
   <input type="button" style="background-color: Lime" onclick="seditor_insertunit('fastpost', '[color=Lime]', '[/color]')" /> 
   <input type="button" style="background-color: Cyan" onclick="seditor_insertunit('fastpost', '[color=Cyan]', '[/color]')" /> 
   <input type="button" style="background-color: DeepSkyBlue" onclick="seditor_insertunit('fastpost', '[color=DeepSkyBlue]', '[/color]')" /> 
   <input type="button" style="background-color: DarkOrchid" onclick="seditor_insertunit('fastpost', '[color=DarkOrchid]', '[/color]')" /> 
   <input type="button" style="background-color: Silver" onclick="seditor_insertunit('fastpost', '[color=Silver]', '[/color]')" /> 
   <br /> 
   <input type="button" style="background-color: Pink" onclick="seditor_insertunit('fastpost', '[color=Pink]', '[/color]')" /> 
   <input type="button" style="background-color: Wheat" onclick="seditor_insertunit('fastpost', '[color=Wheat]', '[/color]')" /> 
   <input type="button" style="background-color: LemonChiffon" onclick="seditor_insertunit('fastpost', '[color=LemonChiffon]', '[/color]')" /> 
   <input type="button" style="background-color: PaleGreen" onclick="seditor_insertunit('fastpost', '[color=PaleGreen]', '[/color]')" /> 
   <input type="button" style="background-color: PaleTurquoise" onclick="seditor_insertunit('fastpost', '[color=PaleTurquoise]', '[/color]')" /> 
   <input type="button" style="background-color: LightBlue" onclick="seditor_insertunit('fastpost', '[color=LightBlue]', '[/color]')" /> 
   <input type="button" style="background-color: Plum" onclick="seditor_insertunit('fastpost', '[color=Plum]', '[/color]')" /> 
   <input type="button" style="background-color: White" onclick="seditor_insertunit('fastpost', '[color=White]', '[/color]')" /> 
  </div> 


