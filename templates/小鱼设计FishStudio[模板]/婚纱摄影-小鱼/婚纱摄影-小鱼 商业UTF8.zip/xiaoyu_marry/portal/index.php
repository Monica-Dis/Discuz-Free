<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<style>.xiaoyu_wp{ width:100%;}.temp{ margin:0}#scrolltop{ display:none} body{ overflow-x:hidden}.tab-content .block,.tab-content .area{ padding:0}.xiaoyu_wp{ padding-bottom:0}</style>

<!--[diy=banners]--><div id="banners" class="area"></div><!--[/diy]-->
<!--[diy=ixnews]--><div id="ixnews" class="area"></div><!--[/diy]-->   
<!--[diy=ixtitle2]--><div id="ixtitle2" class="area"></div><!--[/diy]--> 
<!--[diy=ixtitle3]--><div id="ixtitle3" class="area"></div><!--[/diy]--> 
<!--[diy=ixtitle4]--><div id="ixtitle4" class="area"></div><!--[/diy]--> 
<!--[diy=ixtitle5]--><div id="ixtitle5" class="area"></div><!--[/diy]--> 
<!--[diy=ixtitle6]--><div id="ixtitle6" class="area"></div><!--[/diy]--> 
<!--[diy=ixtitle7]--><div id="ixtitle7" class="area"></div><!--[/diy]-->
<div class="newsCenter">
<!--[diy=ixtitle7tab]--><div id="ixtitle7tab" class="area"></div><!--[/diy]--> 
<div class="tab-content">
<ul style="display:block">
<!--[diy=ixtitle7ul]--><div id="ixtitle7ul" class="area"></div><!--[/diy]--> 
</ul>
<ul style="display:none">
<!--[diy=ixtitle7ul2]--><div id="ixtitle7ul2" class="area"></div><!--[/diy]-->  
</ul>
</div> 
</div>
<div class="more"><!--[diy=lastmore]--><div id="lastmore" class="area"></div><!--[/diy]-->
</div>  
<!--[diy=fishsite]--><div id="fishsite" class="area"></div><!--[/diy]-->	
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->
