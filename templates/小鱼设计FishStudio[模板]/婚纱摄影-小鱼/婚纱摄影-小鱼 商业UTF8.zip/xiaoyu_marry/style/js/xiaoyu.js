jq(document).ready(function() {

    jq("a").focus(function() {
        jq(this).blur();
    });

    if (jq(".banner ul li").size() > 0) {
        jq(".banner ul").tabs(".banner > div", {
            effect: 'fade',
            loop: true,
            fadeOutSpeed: 1000,
            fadeInSpeed: 1000,
            rotate: true
        }).slideshow({
            autoplay: true,
            interval: 5000
        });
    }

    jq("a.b_prev").click(function() {

        jq(".banner ul li a.current").parent().prev("li").find("a").click();
    });

    jq("a.b_next").click(function() {

        jq(".banner ul li a.current").parent().next("li").find("a").click();
    });

    if (jq("#indexImgs1 ul li").size() > 0) {
        jq("#indexImgs1 ul").tabs("#indexImgs1 > div", {
            effect: 'fade',
            loop: true,
            fadeOutSpeed: 1000,
            fadeInSpeed: 1000,
            event: "mouseover",
            rotate: true
        }).slideshow({
            autoplay: true,
            interval: 4000
        });
    }

    if (jq("#indexImgs2 ul li").size() > 0) {
        jq("#indexImgs2 ul").tabs("#indexImgs2 > div", {
            effect: 'fade',
            loop: true,
            fadeOutSpeed: 1000,
            fadeInSpeed: 1000,
            event: "mouseover",
            rotate: true
        }).slideshow({
            autoplay: true,
            interval: 4000
        });
    }
/*
    if (jq(".newsCenter dl dd").size() > 0) {
        jq(".newsCenter dl").tabs(".newsCenter > div", {
            loop: true,
            fadeOutSpeed: 1000,
            fadeInSpeed: 1000,
            rotate: true
        }).slideshow({
            autoplay: false,
            interval: 4000
        });
    }
*/
    jq('.links tt').click(function() {
        jq('html, body').animate({
            scrollTop: 0
        },
        500);
    });

    if (jq(".guestImgs ul li").size() > 0) {
        jq(".guestImgs ul").tabs(".guestImgs > div", {
            effect: 'fade',
            loop: true,
            fadeOutSpeed: 1000,
            fadeInSpeed: 1000,
            rotate: true
        }).slideshow({
            autoplay: true,
            interval: 4000
        });
    }

    if (jq(".wj_imgs ul li").size() > 0) {
        jq(".wj_imgs ul").tabs(".wj_imgs > div", {
            effect: 'fade',
            loop: true,
            fadeOutSpeed: 1000,
            fadeInSpeed: 1000,
            rotate: true
        }).slideshow({
            autoplay: true,
            interval: 4000
        });
    }
    jq("a.prev").click(function() {

        jq(".wj_imgs ul li a.current").parent().prev("li").find("a").click();
    });

    jq("a.next").click(function() {

        jq(".wj_imgs ul li a.current").parent().next("li").find("a").click();
    });

    jq(function() {
        jq(window).resize(function() {
            goTop1();
        });
        jq(window).scroll(function() {
            goTop1();
        });
    });
    function goTop1() {
        jq(".piaofu").stop().animate({
            "top": (jq(window).height() + jq(window).scrollTop() - (jq(window).height() + jq(".piaofu").height()) / 2) < 860 ? 860 :

            jq(window).height() + jq(window).scrollTop() - (jq(window).height() + jq(".piaofu").height()) / 2
        },
        800);
    }

    jq(".scroDemo").scrollable({
        size: 4,
        items: ".scroDemo ul",
        loop: false,
        circular: false,
        prev: ".np1",
        next: ".np2"
    });

    if (jq(".about_img ul li").size() > 0) {
        jq(".about_img ul").tabs(".about_img > .about_txt", {
            loop: true,
            fadeOutSpeed: 1000,
            fadeInSpeed: 1000,
            rotate: true,
            event: 'mouseover'
        }).slideshow({
            autoplay: false,
            interval: 4000
        });
    }

    jq(".contact li div cite").click(function() {
        jq(this).find("tt").slideToggle();

    })

})
