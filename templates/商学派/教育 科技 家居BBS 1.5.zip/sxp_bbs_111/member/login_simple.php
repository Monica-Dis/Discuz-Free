<?php echo 'http://DisM.taobao.com/?@3982.developer';exit;?>
<!--{if CURMODULE != 'logging'}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}logging.js?{VERHASH}"></script>
	<form method="post" autocomplete="off" id="lsform" action="member.php?mod=logging&action=login&loginsubmit=yes&infloat=yes&lssubmit=yes" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('ls_password');{/if}return lsSubmit();">
	<div class="fastlg cl" >
		<span id="return_ls" style="display:none;"></span>
		<div class="y pns" >
			<table cellspacing="0" cellpadding="0">
				<tr>
                        <!--{if $sxp_qq==1}--><td><a class="sxp_qqlogin" href="$sxp_lang[5]" target="_blank" >$sxp_lang[7]</a></td><!--{/if}-->
                        <!--{if $sxp_wx==1}--><td><a class="sxp_wxlogin" href="$sxp_lang[6]" target="_blank" >$sxp_lang[8]</a></td><!--{/if}-->
						<td style="display:none"><input type="text" name="username" id="ls_username" autocomplete="off" class="px vm" tabindex="901" /></td>
						<td><a onclick="showWindow('login', this.href);return false;" href="member.php?mod=logging&amp;action=login" rel="nofollow">{lang login}</a></td>
                        <td><a href="member.php?mod={$_G[setting][regname]}" >$_G['setting']['reglinkname']</a></td>



				</tr>
				<tr>

				</tr>
			</table>
			<input type="hidden" name="quickforward" value="yes" />
			<input type="hidden" name="handlekey" value="ls" />
	  </div>
		<div style="display:none;"><!--{hook/global_login_extra}--></div>
	</div>
	</form>

	<!--{if $_G['setting']['pwdsafety']}-->
		<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
	<!--{/if}-->

<!--{/if}-->