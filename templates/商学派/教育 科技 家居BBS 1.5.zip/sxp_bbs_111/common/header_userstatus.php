<?php echo 'shangxuepai.com:http://DisM.taobao.com/?@3982.developer ';exit;?>
<!--{if $_G['uid']}-->


<div style="display:none"><!--{hook/global_usernav_extra1}--></div>
<!--{hook/global_usernav_extra4}-->


<a href="home.php?mod=space&uid=$_G[uid]" class="sxp_avatar showmenu" id="myitem" onmouseover="showMenu({'ctrlid':'myitem'});"><!--{avatar($_G[uid],small)}--><em style="margin-left:8px;font-weight:normal;">$_G[member][username]</em></a>
		
		<a href="home.php?mod=space&do=notice" id="myprompt" class="a showmenu{if $_G[member][newprompt]} new{/if}" onmouseover="showMenu({'ctrlid':'myprompt'});">{lang remind}<!--{if $_G[member][newprompt]}--><em>$_G[member][newprompt]</em><!--{/if}--></a><span id="myprompt_check"></span>
		<!--{if empty($_G['cookie']['ignore_notice']) && ($_G[member][newpm] || $_G[member][newprompt_num][follower] || $_G[member][newprompt_num][follow] || $_G[member][newprompt])}--><script language="javascript">delayShow($('myprompt'), function() {showMenu({'ctrlid':'myprompt','duration':3})});</script><!--{/if}-->
		

		 
		<!--{if $_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])}--><a href="home.php?mod=task&item=doing" id="task_ntc" class="new">{lang task_doing}</a><!--{/if}-->
		

		<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
			<a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a>
		<!--{/if}-->				
		<!--{hook/global_usernav_extra2}-->	
		<!--{hook/global_usernav_extra3}-->		
			
<!--{elseif !empty($_G['cookie']['loginuser'])}-->

	<strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
	<a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
	<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
	
	

<!--{elseif !$_G[connectguest]}-->
	<!--{template member/login_simple}-->
<!--{else}-->

	<div class="avt y"><!--{avatar(0,small)}--></div>
	
		<strong class="vwmy qq">{$_G[member][username]}</strong>
		<!--{hook/global_usernav_extra1}-->
		<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
	
	
		<a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a>
		{lang usergroup}: $_G[group][grouptitle]
	

<!--{/if}-->