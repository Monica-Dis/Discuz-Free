<?php
/* ---------------------------------
 * http://www.shangxuepai.com
----------------------------------*/

if(!defined('IN_DISCUZ')) {exit('Access Denied');}

$sxp_lang = array(
    1 => '登陆之后才能保存选择的风格',
	2 => '站点公告',
	
	
	/* 微信、QQ登陆Begain */
	
	5 => 'connect.php?mod=login&op=init&referer=index.php&statfrom=login_simple',  	               /*登陆-QQ登陆链接（默认为后台系统自带QQ插件，如不是第三方插件，请不要修改） */		
	6 => 'plugin.php?id=wechat:login',         
	/* 登陆- 微信登陆链接（默认为后台系统自带微信插件，如不是第三方插件，请不要修改）*/	
	7 => 'QQ登陆',
	8 => '微信登陆',
	
	/* 微信、QQ登陆End */
	

	
	/* 论坛首页幻灯Begain */
	
	201 => '#',                                                  /* 幻灯图片1连接*/
	202 => 'template/sxp_bbs_111/ad/portal1.jpg',                /* 幻灯图片1的图片地址*/
	
	203 => '#',                                                  /* 幻灯图片2连接*/
	204 => 'template/sxp_bbs_111/ad/portal2.jpg',                /* 幻灯图片2的图片地址*/
	
	205 => '#',                                                  /* 幻灯图片3连接*/
	206 => 'template/sxp_bbs_111/ad/portal3.jpg',                /* 幻灯图片3的图片地址*/		
	
	
	/* 论坛首页幻灯End */
	
	
	


	
	501 => '栏目导航',
	502 => '查看详情',
	503 => '全部评论',
	504 => '已有',
	505 => '人参与',
	
);
?>