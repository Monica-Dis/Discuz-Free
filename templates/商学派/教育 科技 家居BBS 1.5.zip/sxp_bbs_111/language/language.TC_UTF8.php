<?php
/* ---------------------------------
 * http://www.shangxuepai.com
----------------------------------*/

if(!defined('IN_DISCUZ')) {exit('Access Denied');}

$sxp_lang = array(
    1 => '登陸之後才能保存選擇的風格',
	2 => '站點公告',
	
	
	/* 微信、QQ登陸Begain */
	
	5 => 'connect.php?mod=login&op=init&referer=index.php&statfrom=login_simple',  	               /*登陸-QQ登陸鏈接（默認為後台系統自帶QQ插件，如不是第三方插件，請不要修改） */		
	6 => 'plugin.php?id=wechat:login',         
	/* 登陸- 微信登陸鏈接（默認為後台系統自帶微信插件，如不是第三方插件，請不要修改）*/	
	7 => 'QQ登陸',
	8 => '微信登陸',
	
	/* 微信、QQ登陸End */
	

	
	/* 論壇首頁幻燈Begain */
	
	201 => '#',                                                  /* 幻燈圖片1連接*/
	202 => 'template/sxp_bbs_111/ad/portal1.jpg',                /* 幻燈圖片1的圖片地址*/
	
	203 => '#',                                                  /* 幻燈圖片2連接*/
	204 => 'template/sxp_bbs_111/ad/portal2.jpg',                /* 幻燈圖片2的圖片地址*/
	
	205 => '#',                                                  /* 幻燈圖片3連接*/
	206 => 'template/sxp_bbs_111/ad/portal3.jpg',                /* 幻燈圖片3的圖片地址*/		
	
	
	/* 論壇首頁幻燈End */
	
	
	


	
	501 => '欄目導航',
	502 => '查看詳情',
	503 => '全部評論',
	504 => '已有',
	505 => '人參與',
	
);
?>