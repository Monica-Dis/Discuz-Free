﻿/*Banner*/
var xn_ba_js_13_autoPlay = true;
var xn_ba_js_13_interval = 6000;
var bannerW = "100%";
var xn_ba_js_13_nextfunc;
var xn_ba_js_13_timer;
FOM(document).ready(function () {
    if (FOM("#sxp_ban_box").length>0) {
        xn_ba_js_13_start();
    };
});
var xn_ba_js_13_start = function () {
    var maxLen = 0;
    var index = 0;
    var prev = -1;
    var imgW, imgH, sizeW, sizeH = 0;
    var running = false;
    maxLen = FOM(".sxp_ban_element").length;
    imgW = FOM(".sxp_ban_element").find("img").eq(0).width();
    imgH = FOM(".sxp_ban_element").find("img").eq(0).height();
    for (var i = 0; i < FOM(".sxp_ban_element").length; i++) {
        var ele = FOM(".sxp_ban_element").eq(i).find("img");
        ele.attr("src", ele.attr("data-original"));
    }
    var btnData = "";
    for (var i = 0; i < maxLen; i++) btnData += '<li class="sxp_ban_element_btn">';
    FOM(".sxp_ban_btn").html(btnData);
    var btn = FOM(".sxp_ban_btn").find("li").eq(0);
    var btnW = btn.width() + Math.round(btn.css("margin-left").replace(/[a-zA-Z]/g, ""));
    FOM(".sxp_ban_btn").css("width", maxLen * btnW);
    btn.attr("class", "sxp_ban_element_btn_on");
    FOM(".sxp_ban_box").css("visibility", "visible");
    for (var i = 0; i < maxLen; i++) {
        FOM(".sxp_ban_element").eq(i).attr("id", "ea_ba_no_b_" + i);
        var _pos = Math.round(imgW * (i - index) + sizeW / 2 - imgW / 2);
        if (i == index) _opa = 1;
        if (_pos > sizeW) {
            _pos -= maxLen * imgW
        } else if (_pos < -imgW) {
            _pos += maxLen * imgW
        }
        FOM(".sxp_ban_element").eq(i).css({
            left: _pos,
            opacity: 0
        }).animate({
            opacity: _opa
        }, {
            duration: 400,
            easing: 'linear'
        })
    }
    onResize();
    FOM(window).resize(onResize);
    function onResize() {
        for (var i = 0; i < maxLen; i++) {
            if (bannerW == "100%") {
                sizeW = FOM(window).width();
            } else {
                sizeW = parseInt(bannerW);
            }
            var _pos = Math.round(imgW * (i - index) + sizeW / 2 - imgW / 2);
            var _opa = 1;
            if (i == index) _opa = 1;
            if (_pos > sizeW) {
                _pos -= maxLen * imgW
            }
            FOM(".sxp_ban_element").eq(i).stop().css({
                left: _pos,
                opacity: _opa
            })
        }
    };
    FOM(".sxp_ban_btn li").each(function (i) {
        FOM(this).click(function () {clearInterval(xn_ba_js_13_timer);
            skipHandler((i));
        });
    });
    FOM("#sxp_ban_prev").hover(function(){
        clearInterval(xn_ba_js_13_timer);
    },function(){
        xn_ba_js_13_timer = setInterval(xn_ba_js_13_nextfunc, xn_ba_js_13_interval);
    });
    //左右切换
    FOM("#sxp_ban_prev").click(function(){
        var cur = index;
        cur++;
        if (cur > maxLen - 1) cur = 0;
        skipHandler(cur);
    });
    FOM("#sxp_ban_next").click(function(){
        var cur = index;
        cur--;
        if (cur < 0) cur = maxLen - 1;
        skipHandler(cur);
    });
    timerRepeat();
    function skipHandler(target) {
        if (target == index) return;
        var d = 1;
        var pure = index;
        if (target < pure) d = -1;
        var btn = FOM(".sxp_ban_btn").find("li");
        btn.eq(pure).attr("class", "sxp_ban_element_btn");
        btn.eq(target).attr("class", "sxp_ban_element_btn_on");
        var len;
        if (d == 1) {
            len = target - pure;
            if (len <= 1) {
                index = target;
                nextPage();
            } else {
                for (var k = pure; k <= target; k++) {
                    index = k;
                    nextPage();
                }
            }
        } else {
            len = index - target;
            if (len <= 1) {
                index = target;
                prevPage();
            } else {
                for (var k = index; k >= target; k--) {
                    index = k;
                    prevPage();
                }
            }
        }
    }
    function timerRepeat() {
        if (!xn_ba_js_13_autoPlay) return;
        xn_ba_js_13_nextfunc = isPause;
        xn_ba_js_13_timer = setInterval(xn_ba_js_13_nextfunc, xn_ba_js_13_interval);
    }
    function isPause() {
        var isRun = true;
        if (typeof parent.runonce != 'undefined') {
            isRun = parent.runonce;
        }
        if (isRun) {
            var cur = index;
            cur++;
            if (cur > maxLen - 1) cur = 0;
            skipHandler(cur);
            return false;
        } else {
            return true;
        }
    }
    function nextPage() {
        if (xn_ba_js_13_timer) {
            clearInterval(xn_ba_js_13_timer);
            timerRepeat();
        }
        if (FOM(window.parent.bannerparam).length > 0) {
            window.parent.bannerparam.cur_ba_index = index;
        }
        _pict = FOM(".sxp_ban_element");
        for (var i = 0; i < maxLen; i++) {
            var _pos = Math.round(imgW * (i - index) + sizeW / 2 - imgW / 2);
            var _opa = 1;
            if (i == index) _opa = 1;
            if (_pos > sizeW) {
                _pos -= maxLen * imgW
            } else if (_pos < -imgW * 2) {
                _pos += maxLen * imgW
            }
            _pict.eq(i).stop().css({
                left: _pos + imgW
            }).animate({
                left: _pos,
                opacity: _opa
            }, {
                duration: 700,
                easing: 'easeOutQuint'
            })
        }
    }
    function prevPage() {
        if (xn_ba_js_13_timer) {
            clearInterval(xn_ba_js_13_timer);
            timerRepeat();
        }
        if (FOM(window.parent.bannerparam).length > 0) {
            window.parent.bannerparam.cur_ba_index = index;
        }
        for (var i = 0; i < maxLen; i++) {
            var _pos = Math.round(imgW * (i - index) + sizeW / 2 - imgW / 2);
            if (_pos < -imgW) {
                _pos += maxLen * imgW
            } else if (_pos > sizeW + imgW) {
                _pos -= maxLen * imgW
            }
            FOM(".sxp_ban_element").eq(i).stop().css({
                left: _pos - imgW
            }).animate({
                left: _pos
            }, {
                duration: 700,
                easing: 'easeOutQuint'
            })
        }
    }
}
jQuery.extend(jQuery.easing, {
    def: 'easeOutQuint',
    swing: function (x, t, b, c, d) {
        return jQuery.easing[jQuery.easing.def](x, t, b, c, d);
    }, easeOutQuint: function (x, t, b, c, d) {
        return c * ((t = t / d - 1) * t * t * t * t + 1) + b;
    }
});
/*End_Banner*/

/*Slider*/
FOM(function() {
if (FOM("#sxp_slider_wrap").length>0) {
    var iSpeed=500;
    var oBigbox=FOM("#sxp_slider_bigbox");
    var oBigul=FOM("#sxp_slider_big");
    var oBigli=oBigul.children("li");
    var oSmaul=FOM("#sxp_slider_sma");
    var pSmalicurr="sxp_slider_smalicurr";
    var oPrevBtn=FOM("#sxp_slider_prev");
    var oNextBtn=FOM("#sxp_slider_next");
    var iBdl=FOM(".sxp_slider_bdl");
    var iBdd="sxp_slider_bdd";
    oBigli.each(function(){
        FOM(this).attr("index",FOM(this).index());
    })
    /*初始化 布局转换*/
    oBigul.width(100*oBigli.length+"%");
    oBigli.width(100/oBigli.length+"%");
    var oBigli_w=oBigli.outerWidth(true);
    oSmaul.children("li").first().addClass(pSmalicurr);
    iBdl.children().each(function(){
        FOM(this).addClass(iBdd+(FOM(this).index()+1))
    })
    var animateEnd = 1;
    oSmaul.children("li").click(function() {
        if (animateEnd == 0) {
            return;
        }
        FOM(this).addClass(pSmalicurr).siblings().removeClass(pSmalicurr);
        var nextindex = FOM(this).index();
        var currentindex = oBigul.children("li").first().attr("index");
        if (nextindex == currentindex) {
            return;
        }
        var oFirstLi = oBigul.children("li").first().clone();
        if (nextindex > currentindex) {
            for (var i = 0; i < nextindex - currentindex; i++) {
                oBigul.append(oBigul.children("li").first());
            }
            oBigul.prepend(oFirstLi); 
            if (animateEnd == 1) {
                animateEnd = 0;
                oBigul.stop().animate({left: (oBigli_w * -1) }, iSpeed, function() {
                    oBigul.children("li").first().remove();
                    oBigul.css("left", "0px");
                    animateEnd = 1;
                })
            }
        } else {
            for (var i = 0; i < currentindex - nextindex; i++) {
                oBigul.prepend(oBigul.children("li").last())
            }
            oBigul.children("li").eq(0).after(oFirstLi);
            oBigul.css("left", (oBigli_w * -1));
            if (animateEnd == 1) {
                animateEnd = 0;
                oBigul.stop().animate({left: "0px"}, iSpeed, function() {
                    oFirstLi.remove();
                    animateEnd = 1;
                })
            }
        }
    })
};
})
/*End_Slider*/
