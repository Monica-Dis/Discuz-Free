<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 *
 * Copyright (c) 2015-2016 http://dism.taobao.com All rights reserved.
 *
 * ���²����http://t.cn/Aiux1Jx1
 *
 * Date: 2015/09/20 Mr.Will $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}

header('location:http://dism.taobao.com/?@3982.developer');