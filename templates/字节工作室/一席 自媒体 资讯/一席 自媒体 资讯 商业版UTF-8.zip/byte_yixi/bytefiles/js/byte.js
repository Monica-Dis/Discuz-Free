/* 导航条置顶 */
function navBarAuto(){
    jQuery(window).scroll(function(event){
        var scrollTop = jQuery(window).scrollTop();
        if (scrollTop > 90) {
            jQuery('.b-header-nv').addClass('fixed');
            jQuery('.b-logo-big-img img').addClass('hide');
            jQuery('.b-index-slogan').addClass('active');
        } else {
            jQuery('.b-header-nv').removeClass('fixed');
            jQuery('.b-logo-big-img img').removeClass('hide');
            jQuery('.b-index-slogan').removeClass('active');
        }
    });

    var nvItems = document.getElementsByClassName("b-header-nv-item");
    for(var i=0; i<nvItems.length; i++){
        if(nvItems[i].hasAttribute("onmouseover")){
            var itemStr = nvItems[i].id;
            var itemId = itemStr.slice(3);
            jQuery("#mn_"+itemId+"_menu").css("width",nvItems[i].offsetWidth);
        }
        if(nvItems[i].hasAttribute("onmouseover") && jQuery("nvItems[i] a").attr("title","Plugin")){
            jQuery("#plugin_menu").css("width",nvItems[i].offsetWidth);
        }
    }

    var diyLen = jQuery("#controlpanel").length;
    if(diyLen>0){
        jQuery(".b-header-fixed").css("top","175px");
        jQuery(".b-header-nv").css("transition","none");
    }

}
/* 搜索 */
function searchMask(){
    jQuery(".b-header-search-input").on("click", function (e) {
        jQuery(".b-search-box").toggleClass("active"),
        jQuery(this).toggleClass("active"),
        jQuery(".b-header-nv-bar").toggleClass("hide"),
        e.stopPropagation()
    });
}

/* 登录 */
function showLogin(){
    jQuery("#b-login").on({
        mouseover:function(){
            jQuery(this).css("box-shadow","0px 0px 7px #efeaea");
            jQuery(".b-login-function").css("display","block");
            
        },
        mouseout:function(){
            jQuery(this).css("box-shadow","none");
            jQuery(".b-login-function").css("display","none");
        }
    });
}

/* 回到顶部 */
function scrollUp(){
    jQuery.scrollUp({
        scrollName: 'scrollUp',
        topDistance: '300',
        topSpeed: 300,
        animation: 'fade', // Fade, slide, none
        animationInSpeed: 200,
        animationOutSpeed: 200,
        activeOverlay: false
    });
    jQuery("#scrollUp").html("<span class='iconfont iconarrow-up-s-line'></span>");
}
/* banner */
function bannerLoad(){
    jQuery('.b-stage-box').hover(function () {
        var speech_text_id = 'speech_text_' + jQuery(this).attr('id');
        jQuery('.' + speech_text_id).show();
        jQuery('.b-stage-text:not(.' + speech_text_id + ')').hide();
        jQuery(this).removeClass('back').addClass('active');
        jQuery(this).siblings('.b-stage-box').removeClass('active').addClass('back');
    });

    jQuery(document).ready(function(){
        jQuery(".b-stage-box").each(function(i){
            if(i == 1){
                var speech_text_id = 'speech_text_' + jQuery(this).attr('id');
                jQuery('.' + speech_text_id).show();
                jQuery('.b-stage-text:not(.' + speech_text_id + ')').hide();
                jQuery(this).removeClass('back').addClass('active');
            }
        });
    });
}
/* 门户首页 */
function showChannel(){
    var swiperType1 = new Swiper('.j_swiper_type1', {
        slidesPerView :4,
        slidesPerColumn : 3,
        // slidesPerColumnFill:'row',
        spaceBetween: 20,
        roundLengths: true,
        prevButton: '.swiper-type1-prev',
        nextButton: '.swiper-type1-next',
    });//演讲

    var swiperZhiYa = new Swiper('.swiper-zhiya', {
        slidesPerView: 3,
        spaceBetween: 19,
        roundLengths: true,
        prevButton: '.swiper-zhiya-prev',
        nextButton: '.swiper-zhiya-next',
    });//枝桠

    var swiperRecord = new Swiper('.j_swiper_record', {
        slidesPerView: 4,
        spaceBetween: 19,
        roundLengths: true,
        prevButton: '.swiper-record-prev',
        nextButton: '.swiper-record-next',
    });//记录

    jQuery(".swiper-type1_item").on({
        mouseover:function(){
            jQuery(this).find(".first-item").css("top","0");
        },
        mouseout:function(){
            jQuery(this).find(".first-item").css("top","100%");
        }
    });
    
}

function homeHeader(){
    var nvItems = document.getElementsByClassName("b-home-nv-item");
    for(var i=0; i<nvItems.length; i++){
        if(nvItems[i].hasAttribute("onmouseover")){
            var itemStr = nvItems[i].id;
            var itemId = itemStr.slice(3);
            jQuery("#mn_"+itemId+"_menu").css("width",nvItems[i].offsetWidth);
        }
        if(nvItems[i].hasAttribute("onmouseover") && jQuery("nvItems[i] a").attr("title","Plugin")){
            jQuery("#plugin_menu").css("width",nvItems[i].offsetWidth);
        }
    }

    jQuery(".b-home-search-input").on("click", function (e) {
        jQuery("#nv_home").toggleClass("hide"),
        jQuery(".b-search-box").toggleClass("active"),
        jQuery(this).toggleClass("active"),
        jQuery(".b-home-header").toggleClass("bg"),
        e.stopPropagation()
    });

    jQuery(".b-home-header").on({
        mouseover:function(){
            jQuery(".b-home-header .b-home-nv .b-home-nv-bar li a").css("opacity","1");
            jQuery(".b-home-header .b-home-control .b-home-search-input").css("opacity","1");
            jQuery(".b-home-header .b-home-control #b-login .b-login-avatar img").css("opacity","1");
            jQuery(".b-home-header .b-home-control .b-add .addnew").css("opacity","1");
            jQuery(".b-home-header .b-home-control .b-icon-personal").css("opacity","1");
            
        },
        mouseout:function(){
            jQuery(".b-home-header .b-home-nv .b-home-nv-bar li a").css("opacity","0.3");
            jQuery(".b-home-header .b-home-control .b-home-search-input").css("opacity","0.3");
            jQuery(".b-home-header .b-home-control #b-login .b-login-avatar img").css("opacity","0.3");
            jQuery(".b-home-header .b-home-control .b-add .addnew").css("opacity","0.3");
            jQuery(".b-home-header .b-home-control .b-icon-personal").css("opacity","0.3");
        }
    });
    jQuery(".b-home-header .b-home-control  #b-login").on({
        mouseover:function(){
            jQuery(".b-login-avatar").css("background","#333");
            jQuery(this).css("box-shadow","none");
        },
        mouseout:function(){
            jQuery(".b-login-avatar").css("background","none");
        }
    });
}

function adaptation(){
    jQuery("object embed").each(function(i){

        var videoSrc = jQuery(this).attr("src");
        console.log(videoSrc);
        if(checkUrl("(player\\.youku\\.com)",videoSrc)){
            jQuery(this).parent().after( "<iframe width=740 height=480 src='"+videoSrc+"' frameborder='0' allowFullScreen='true'></iframe>" );
        }else if(checkUrl("(v\\.qq\\.com)",videoSrc)){
            jQuery(this).parent().after( "<iframe width=740 height=480 frameborder='0' src='"+videoSrc+"' allowFullScreen='true'></iframe>" );
        }else if(checkUrl("(open\\.iqiyi\\.com)",videoSrc)){
            jQuery(this).parent().after( "<iframe width=740 height=480 src='"+videoSrc+"' frameborder='0' allowfullscreen='true'></iframe>" );
        }else{
            jQuery(this).parent().after( "<video class='b-video' controls preload='auto' width='740'> <source src='"+videoSrc+"' type='video/mp4' /></video>" );
        }
        jQuery(this).parent().remove();
    });

    jQuery("object param").each(function(i){

        if(jQuery(this).attr("name") == "FlashVars"){
            var str = jQuery(this).attr("value");
            var strIndex = str.search("soundFile");
            var audioSrcEncode = str.slice(strIndex + 10);
            // console.log(audioSrcEncode);
            var audioSrcDecode = decodeURIComponent(audioSrcEncode);
            console.log(audioSrcDecode);

            if(checkUrl("(\\/music\\.163\\.com\\/outchain\\/player)",audioSrcDecode)){
                jQuery(this).parent().after("<div style='width:740px;text-align:center;'><iframe align='center' frameborder='no' border='0' marginwidth='0' marginheight='0' width=330 height=86 src='"+audioSrcDecode+"'></iframe></div>");
            }else{
                jQuery(this).parent().after("<audio src='"+audioSrcDecode+"' preload='auto' controls ></audio>");
            }
            jQuery(this).parent().remove();
        }
    });

    jQuery('audio').audioPlayer();

    function checkUrl(domain,src){
        var re1='.*?';
        var p = new RegExp(re1+domain,["i"]);
        var m = p.exec(src);
        if (m != null){
            return true;
        }
    }
}
