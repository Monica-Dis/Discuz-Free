<?php

/**
 * 会员排行榜
 * 官方网址 https://dism.taobao.com/?@qu
 * 最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$view = $_GET['view'];
$langvars = lang('plugin/qu_ranklist');
$vars = $_G['cache']['plugin']['qu_ranklist'];
$aicon = $vars['icon'];
$qujian = $vars['qujian'] ? $vars['qujian'] : 100;
$astyle = $vars['astyle'];
$touchnav = $vars['touchnav'];
$qu_listnum = $vars['num'];
$aziduan = $vars['aziduan'] ? 'extcredits'.$vars['aziduan']:'credits';

$aziduanid = $vars['aziduan'];
$auser = (array)unserialize($vars['auser']);

$navtitle = $vars['navtitle'];
$metakeywords = $vars['metakeywords'];
$metadescription = $vars['metadescription'];

if(!in_array($view, array($aziduan, 'posts', 'threads','friends'))) {
	$view = $aziduan;
}
$currentview[$view] = 'class="xw1 a"';
$perpage = $qu_listnum ? $qu_listnum : 10;
$start = $perpage * ($_G['page'] - 1);
$data = array();
$data[$view] = get_user_list($view, $auser,$start, $perpage);
$count = C::t('#qu_ranklist#plugin_qu_ranklist')->fetch_by_count($view,$auser);
if($vars['sumnum'] > 0){
    $count = $count > $vars['sumnum'] ? $vars['sumnum'] : $count;
}
$userids = $data[$view]['userids'];
if(!empty($userids)){
    $userthread = C::t('#qu_ranklist#plugin_qu_ranklist')->fetch_by_uids($userids);
}

$mpurl = 'plugin.php?id=qu_ranklist:ranklist&view='.$view;
$multipage = multi($count, $perpage, $_G['page'], $mpurl);

//获取个人信息排名
if($_G['uid']){
    $myview = C::t('#qu_ranklist#plugin_qu_ranklist')->fetch_by_num($view,$_G['uid']);
    //$mypos = C::t('#qu_ranklist#plugin_qu_ranklist')->fetch_by_conlist($view,$auser,$myview);
    if($view == 'credits'){
        $mypos = DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." where credits > ".$myview);
    }else{
        $mypos = DB::result_first('SELECT count(1) FROM '.DB::table('common_member_count').' where '.$view.'>'.$myview);
    }

    $mypos = $mypos + 1;
}

include template('qu_ranklist:index');

//获取所有会员列表
function get_user_list($view, $auser,$start = 0, $num = 10) {
	global $_G;

	$query = C::t('#qu_ranklist#plugin_qu_ranklist')->fetch_user_by_uid($view,$auser,$start,$num);
	foreach($query as $user) {
		$userids[] = $user['uid'];
        $list[$user['uid']] = $user;
	}
	$userlist = array();
	$userlist = $list;
	unset($list);
    $usercount = count($userids);
	return array('usercount' => $usercount, 'userlist' => $userlist, 'userids' => $userids);
}



?>