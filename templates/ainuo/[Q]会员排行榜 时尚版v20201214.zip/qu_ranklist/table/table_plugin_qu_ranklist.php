<?php

/**
 * 会员排行榜
 * 官方网址 https://dism.taobao.com/?@qu
 * 最新插件：http://t.cn/Aiux1Jx1
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_plugin_qu_ranklist extends discuz_table
{
	public function __construct() {

		$this->_table = '';
		$this->_pk    = '';

		parent::__construct(); /*dism·taobao·com*/
	}

	public function fetch_user_by_uid($type, $auser,$start = 0,$limit=20) {
		$tidsql = $addsql = $orderby = '';

        if($type == 'posts') {
            $orderby = 'b.posts';
        } elseif($type == 'threads') {
            $orderby = 'b.threads';
        } elseif($type == 'friends') {
            $orderby = 'b.friends';
        } elseif($type == 'credits') {
            $orderby = 'a.credits';
        } else {
            $orderby = 'b.'.$type;
        }
        if(!empty($auser)){
            $usergroup = implode(',',$auser);
            $tidsql = ' where a.groupid not in('.$usergroup.') ';
        }

        $addsql .= ' ORDER BY '.$orderby.' DESC '.DB::limit($start, $limit);

		return DB::fetch_all("SELECT a.uid,a.credits,a.username,a.groupid,b.* FROM %t as a LEFT JOIN %t as b ON a.uid = b.uid" .$tidsql.$addsql, array('common_member', 'common_member_count'));
	}

    public function fetch_by_count($type,$auser) {
        $tidsql = $orderby = '';

        if($type == 'posts') {
            $orderby = 'b.posts';
        } elseif($type == 'threads') {
            $orderby = 'b.threads';
        } elseif($type == 'friends') {
            $orderby = 'b.friends';
        } elseif($type == 'credits') {
            $orderby = 'a.credits';
        } else {
            $orderby = 'b.'.$type;
        }
        if(!empty($auser)){
            $usergroup = implode(',',$auser);
            $tidsql = ' where a.groupid not in('.$usergroup.') ';
        }

        return DB::result_first("SELECT count(1) FROM %t as a LEFT JOIN %t as b ON a.uid = b.uid" .$tidsql, array('common_member', 'common_member_count'));

    }

    public function fetch_by_conlist($conlist,$auser,$mynum) {
        if(!empty($auser)){
            $usergroup = implode(',',$auser);
            if($conlist == 'credits'){
                $tidsql = ' where groupid not in('.$usergroup.') and '.$conlist.' > '.$mynum;

            }else{
                $uids = DB::fetch_all("SELECT uid FROM ".DB::table('common_member')." where groupid not in($usergroup)");
                $tidsql = ' where '.$conlist.' > '.$mynum.' and '.DB::field('uid',$uids);
            }

        }else{
            $tidsql = ' where '.$conlist.' > '.$mynum;
        }

        switch ($conlist) {
            case 'credits' :
                return DB::result_first("SELECT count(1) FROM ".DB::table('common_member')." $tidsql");
                break;
            default :
                return DB::result_first("SELECT count(1) FROM ".DB::table('common_member_count')." $tidsql");
        }

    }

    public function fetch_by_uids($uids) {
	    $nlist = array();
	    
        $threadlist = DB::fetch_all("SELECT authorid,subject,tid FROM ".DB::table('forum_thread')." where displayorder in(0,1,2,3,4) and closed=0 and ".DB::field("authorid",$uids)." order by dateline desc");
        foreach($threadlist as $t){
            $nlist[$t['authorid']][] = $t;
        }
        return $nlist;
    }

    public function fetch_by_num($conlist,$uid) {
        $mynum = 0;
        switch ($conlist) {
            case 'credits' :
                return DB::result_first("SELECT $conlist FROM ".DB::table('common_member')." where uid=$uid");
                break;
            default :
                return DB::result_first("SELECT $conlist FROM ".DB::table('common_member_count')." where uid=$uid");
        }

    }
}
//From: Dism_taobao_com
?>