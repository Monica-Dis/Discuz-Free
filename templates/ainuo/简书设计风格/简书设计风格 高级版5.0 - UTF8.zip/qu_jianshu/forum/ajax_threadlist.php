<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header_ajax}-->
	<script type="text/javascript">
		if(!isUndefined(checkForumnew_handle)) {
			clearTimeout(checkForumnew_handle);
		}
		<!--{if $threadlist}-->
			if($('separatorline')) {
				var table = $('separatorline').parentNode;
			} else {
				var table = $('forum_' + $fid);
			}
			var newthread = [];
			<!--{eval $i = 0;}-->
			<!--{loop $threadlist $thread}-->
				{block icon}<!--{if $thread['weeknew']}--><div class="qing_threadlist_stat threadlist_stat_new"><a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost" class="xi1">{lang latest}</a></div><!--{elseif $thread[heatlevel]}--><div class="qing_threadlist_stat threadlist_stat_hot"><a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="{$thread[replies]} {lang unit}{lang reply}">{$thread[replies]}</a></div><!--{else}--><div class="qing_threadlist_stat"><a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="{$thread[replies]} {lang unit}{lang reply}">{$thread[replies]}</a></div><!--{/if}-->{/block}
				newthread[{$i}] = {'tid':$thread[tid], 'thread': {'icn':{'className':'icn','val':'$icon'}<!--{if $_G['forum']['ismoderator']}-->, 'o':{'className':'o','val':'<input type="checkbox" value="{$thread[tid]}" name="moderate[]" onclick="tmodclick(this)">'}<!--{/if}--> ,'common':{'className':'new fn','val':'<div class="q_f_title1"><div class="z qing_fenlei">$thread[typehtml] $thread[sorthtml]</div><a href="forum.php?mod=viewthread&tid=$thread[tid]" class="s xst">$thread[subject]</a></div><div class="q_f_title2"><div class="z"><!--{if $thread['authorid'] && $thread['author']}--><a href="home.php?mod=space&uid=$thread[authorid]" {if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if}>$thread[author]</a><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}--><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--> @ <span{if $thread['istoday']} class="q_xi1"{/if}> $thread[dateline]</span></div><div class="y"><!--{if $thread['lastposter']}--><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}" >$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--> @ $thread[lastpost]</div></div>'}}};
				<!--{eval $i++;}-->
			<!--{/loop}-->
			removetbodyrow(table, 'forumnewshow');
			for(var i = 0; i < newthread.length; i++) {
				if(newthread[i].tid) {
					addtbodyrow(table, ['tbody', 'newthread'], ['normalthread_', 'normalthread_'], 'separatorline', newthread[i]);
				}
			}
			function readthread(tid) {
				if($("checknewthread_"+tid)) {
					$("checknewthread_"+tid).className = "";
				}
			}
		<!--{elseif !$threadlist && $_GET['uncheck'] == 2}-->
			showDialog('{lang none_newthread}', 'notice', null, null, 0, null, null, null, null, 3);
		<!--{/if}-->
		checkForumnew_handle = setTimeout(function () {checkForumnew('{$fid}', '{$_G[timestamp]}');}, checkForumtimeout);
	</script>
<!--{template common/footer_ajax}-->