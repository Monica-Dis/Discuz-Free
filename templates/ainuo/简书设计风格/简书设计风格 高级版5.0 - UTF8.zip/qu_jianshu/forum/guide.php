<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->
<style type="text/css">
	.xl2 { background: url({IMGDIR}/vline.png) repeat-y 50% 0; }
		.xl2 li { width: 49.9%; }
			.xl2 li em { padding-right: 10px; }
				.xl2 .xl2_r em { padding-right: 0; }
			.xl2 .xl2_r i { padding-left: 10px; }
</style>

<div class="boardnav">
	<div id="ct" class="wp cl ct2">
		<div class="mn">
			<div class="cl guidetitele">
            	<img src="{$_G['style']['styleimgdir']}/guide.png" />
                <span>
                	{if $_GET[view] == 'hot'}{lang guide_hot}
                    {elseif $_GET[view] == 'digest'}{lang guide_digest}
                    {elseif $_GET[view] == 'new'}{lang guide_new}
                    {elseif $_GET[view] == 'newthread'}{lang guide_newthread}
                    {elseif $_GET[view] == 'sofa'}{lang guide_sofa}
                    {else}{lang guide_hot}
                    {/if}
                </span>
            </div>
			<!--{hook/guide_top}-->

				<!--{loop $data $key $list}-->
				<div id="threadlist" class="tl bm"{if $_G['uid']} style="position: relative;"{/if}>
                    <ul id="thread_types" class="ttp cl">
                    <li $currentview['hot']><a href="forum.php?mod=guide&view=hot">{lang guide_hot}<span></span></a></li>
                    <li $currentview['digest']><a href="forum.php?mod=guide&view=digest">{lang guide_digest}<span></span></a></li>
                    <li $currentview['new']><a href="forum.php?mod=guide&view=new">{lang guide_new}<span></span></a></li>
                    <li $currentview['newthread']><a href="forum.php?mod=guide&view=newthread">{lang guide_newthread}<span></span></a></li>
                    <li $currentview['sofa']><a href="forum.php?mod=guide&view=sofa">{lang guide_sofa}<span></span></a></li>
                    <!--{hook/guide_nav_extra}-->
                </ul>
					<div class="bm_c">
						<div id="forumnew" style="display:none"></div>
							<table cellspacing="0" cellpadding="0">
							<!--{subtemplate forum/guide_list_row}-->
							</table>
					</div>
				</div>
				<!--{/loop}-->
				<div class="bm bw0 pgs cl" style="background:none;">
					$multipage
				</div>

			<!--{hook/guide_bottom}-->
		</div>
        <div class="sd">
        	
            <!--{eval $ainuouserlist = array();}-->
			<!--{eval $ainuouserlist = DB::fetch_all("SELECT uid,username,credits FROM ".DB::table('common_member')." ORDER BY credits DESC limit 10");}-->
            {if $ainuouserlist}
            	<div class="bm hyhuiyuan">
                    <div class="bm_h cl"><h2>活跃用户</h2></div>
                    <div class=" cl">
                        <ul>
                        <!--{loop $ainuouserlist $userlist}-->
						<li class="cl"><a href="home.php?mod=space&uid=$userlist[uid]" class="avatar"><!--{avatar($userlist[uid], 'middle')}--></a> <a id="a_friend_li_{$userlist[uid]}" onclick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=friend&op=add&uid={$userlist[uid]}&handlekey=addfriendhk_{$userlist[uid]}" class="follow">+好友</a> <a href="home.php?mod=space&uid=$userlist[uid]" class="name">$userlist[username]</a></li>
                        <!--{/loop}-->
                        </ul>
                    </div>
                </div>
            
            {/if}
            
        	<!--{eval $ainuohotlist = array();}-->
			<!--{eval $ainuohotlist = DB::fetch_all("SELECT tid,views,subject FROM ".DB::table('forum_thread')." ORDER BY views DESC limit 10");}-->
            {if $ainuohotlist}
            	<div class="bm">
                    <div class="bm_h cl"><h2>热门推荐</h2></div>
                    <div class="qing_tuijianlist cl">
                        <ul>
                        <!--{loop $ainuohotlist $hotlist}-->
                        <li><span></span><a href="forum.php?mod=viewthread&tid=$hotlist[tid]" target="_blank">$hotlist[subject]</a></li>
                        <!--{/loop}-->
                        </ul>
                    </div>
                </div>
            {/if}
            
            
        </div>
	</div>
</div>
<!--{if !IS_ROBOT}-->
	<div id="filter_special_menu" class="p_pop" style="display:none">
		<ul>
			<li><a href="home.php?mod=space&do=poll&view=me" target="_blank">{lang thread_poll}</a></li>
			<li><a href="home.php?mod=space&do=trade&view=me" target="_blank">{lang thread_trade}</a></li>
			<li><a href="home.php?mod=space&do=reward&view=me" target="_blank">{lang thread_reward}</a></li>
			<li><a href="home.php?mod=space&do=activity&view=me" target="_blank">{lang thread_activity}</a></li>
		</ul>
	</div>
<!--{/if}-->
<!--{template common/footer}-->