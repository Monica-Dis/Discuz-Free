<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="bm">
	<div class="bm_h cl">
		<h2>{lang forum_subforums}</h2>
	</div>

	<div class="qing_subcontent cl">
		<ul>
        <!--{loop $sublist $sub}-->
			<!--{eval $forumurl = !empty($sub['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$sub['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$sub['fid'];}-->
            <li>
            	<!--{if $sub[icon]}-->
                	$sub[icon]
                <!--{else}-->
					<a href="$forumurl"{if $sub[redirect]} target="_blank"{/if}><img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" alt="$sub[name]" /></a>
				<!--{/if}-->
                <a href="$forumurl" {if !empty($sub[redirect])}target="_blank"{/if} style="{if !empty($sub[extra][namecolor])}color: {$sub[extra][namecolor]};{/if}"><strong>$sub[name]</strong></a>
                <p>{lang index_today} : <em>$sub[todayposts]</em><span class="pipe">|</span>{lang forum_posts} : <!--{echo dnumber($sub[threads])}--></p>
			</li>
        <!--{/loop}-->
        </ul>
	</div>
</div>