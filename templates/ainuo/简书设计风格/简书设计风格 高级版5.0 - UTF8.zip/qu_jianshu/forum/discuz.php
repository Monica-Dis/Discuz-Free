<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<div style="display:none"><!--{hook/index_status_extra}--></div>
<!--{if empty($gid)}-->
	<!--{ad/text/wp a_t}-->
<!--{/if}-->

<div class="hotzt cl"><img src="{$_G['style']['styleimgdir']}/icon/hotzt.png" width="100%" /></div>

	<style id="diy_style" type="text/css"></style>
	<!--{if empty($gid)}-->
		<div id="chart" class="bm cl">
			<p class="chart z">{lang index_today}: <em>$todayposts</em><span class="pipe">|</span>{lang index_yesterday}: <em>$postdata[0]</em><span class="pipe">|</span>{lang index_posts}: <em>$posts</em><span class="pipe">|</span>{lang index_members}: <em>$_G['cache']['userstats']['totalmembers']</em><!--{if $_G['cache']['userstats']['newsetuser']}--><span class="pipe">|</span>{lang welcome_new_members}: <em><a href="home.php?mod=space&username={echo rawurlencode($_G['cache']['userstats']['newsetuser'])}" target="_blank" class="xi2">$_G['cache']['userstats']['newsetuser']</a></em><!--{/if}--></p>
			<div class="y">
				<!--{hook/index_nav_extra}-->
				<!--{if $_G['uid']}--><a href="forum.php?mod=guide&view=my" title="{lang my_posts}">{lang my_posts}</a><!--{/if}--><!--{if !empty($_G['setting']['search']['forum']['status'])}--><!--{if $_G['uid']}--><span class="pipe">|</span><!--{/if}--><a href="forum.php?mod=guide&view=new" title="{lang show_newthreads}">{lang show_newthreads}</a><!--{/if}-->
			</div>
		</div>
	<!--{/if}-->
	<!--[diy=diy_chart]--><div id="diy_chart" class="area"></div><!--[/diy]-->
    
<!--{if empty($gid)}-->
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->

<div id="ct" class="wp cl">
	<div class="mn">

		<!--{hook/index_top}-->
		<div class="main_l cl">
    	<div class="qing_baklist cl">
                <ul>
        <!--{loop $catlist $key $cat}-->
                
<!--{loop $cat[forums] $forumid}-->
						<!--{eval $forum=$forumlist[$forumid];}-->
						<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
        	<li onMouseOver="this.className='lihover cl'" onmouseout="this.className='cl'">
            <div class="item"><!--{if $forum[icon]}-->$forum[icon]<!--{else}--><a href="$forumurl"><img src="{$_G['style']['styleimgdir']}/forum_logo.png" /></a><!--{/if}--></div>
            <div class="atit cl">
            	<h2><a href="$forumurl"{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if} class="name {if !$forum[description]}name1{/if}">
                	$forum[name]
                </a></h2>
                
                <p  class="desc cl">
                <a href="$forumurl">
                	$forum[description]
                </a>
                </p>

            </div>
            <div class="ainfo cl">
            	<!--{if empty($forum[redirect])}--><span class="abstract">{lang forum_threads} <em><!--{echo dnumber($forum[threads])}--></em>, {lang forum_posts} <em><!--{echo dnumber($forum[posts])}--></em></span><!--{/if}-->
            </div>
            
        </li>
<!--{/loop}-->

<!--{/loop}-->

        </ul></div>
    </div>

		<!--{hook/index_catlist_top}-->
		
		
		<!--{hook/index_middle}-->
		<div class="wp mtn">
			<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
		</div>

		<!--{if empty($gid) && $_G['setting']['whosonlinestatus']}-->
        <div class="fl">
			<div id="online" class="bm oll">
				<div class="bm_h">
				<!--{if $detailstatus}-->
					<span class="o"><a href="forum.php?showoldetails=no#online" title="{lang spread}"><img src="{$_G['style']['styleimgdir']}/icon/collapsed_no.png" alt="{lang spread}" /></a></span>
					<h3>
						<strong><a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a></strong>
						<span class="xs1">- <strong>$onlinenum</strong> {lang onlines}
						- <strong>$membercount</strong> {lang index_members}(<strong>$invisiblecount</strong> {lang index_invisibles}),
						<strong>$guestcount</strong> {lang index_guests}
						- {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>
					</h3>
				<!--{else}-->
					<!--{if empty($_G['setting']['sessionclose'])}-->
						<span class="o"><a href="forum.php?showoldetails=yes#online" title="{lang spread}"><img src="{$_G['style']['styleimgdir']}/icon/collapsed_yes.png" alt="{lang spread}" /></a></span>
					<!--{/if}-->
					<h3>
						<strong>
							<!--{if !empty($_G['setting']['whosonlinestatus'])}-->
								{lang onlinemember}
							<!--{else}-->
								<a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a>
							<!--{/if}-->
						</strong>
						<span class="xs1">- {lang total} <strong>$onlinenum</strong> {lang onlines}
						<!--{if $membercount}-->- <strong>$membercount</strong> {lang index_members},<strong>$guestcount</strong> {lang index_guests}<!--{/if}-->
						- {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>
					</h3>
				<!--{/if}-->
				</div>
			<!--{if $_G['setting']['whosonlinestatus'] && $detailstatus}-->
				<dl id="onlinelist" class="bm_c">
					<dt class="ptm pbm bbda">$_G[cache][onlinelist][legend]</dt>
					<!--{if $detailstatus}-->
						<dd class="ptm pbm">
						<ul class="cl">
						<!--{if $whosonline}-->
							<!--{loop $whosonline $key $online}-->
								<li title="{lang time}: $online[lastactivity]">
								<img src="{STATICURL}image/common/$online[icon]" alt="icon" />
								<!--{if $online['uid']}-->
									<a href="home.php?mod=space&uid=$online[uid]">$online[username]</a>
								<!--{else}-->
									$online[username]
								<!--{/if}-->
								</li>
							<!--{/loop}-->
						<!--{else}-->
							<li style="width: auto">{lang online_only_guests}</li>
						<!--{/if}-->
						</ul>
					</dd>
					<!--{/if}-->
				</dl>
			<!--{/if}-->
			</div>
        </div>
		<!--{/if}-->

		<!--{if empty($gid) && ($_G['cache']['forumlinks'][0] || $_G['cache']['forumlinks'][1] || $_G['cache']['forumlinks'][2])}-->
		<div class="bm qing_lk cl">
			<div id="category_lk" class="bm_c ptm">
				<!--{if $_G['cache']['forumlinks'][0]}-->
					<ul class="m cl">$_G['cache']['forumlinks'][0]</ul>
				<!--{/if}-->
				<!--{if $_G['cache']['forumlinks'][1]}-->
					<div class="cl">
						$_G['cache']['forumlinks'][1]
					</div>
				<!--{/if}-->
				<!--{if $_G['cache']['forumlinks'][2]}-->
					<ul class="x cl">
						$_G['cache']['forumlinks'][2]
					</ul>
				<!--{/if}-->
			</div>
		</div>
		<!--{/if}-->

		<!--{hook/index_bottom}-->
	</div>
    <div style="display:none"><!--{hook/index_side_top}--><!--{hook/index_side_bottom}--></div>

</div>
<div style="display:none">
<!--{hook/index_followcollection_extra $colletion[ctid]}-->
<!--{hook/index_favforum_extra $forum[fid]}-->
<!--{hook/index_favforum_extra $forum[fid]}-->
<!--{hook/index_catlist $cat[fid]}-->
<!--{hook/index_forum_extra $forum[fid]}-->
<!--{hook/index_forum_extra $forum[fid]}-->
<!--{hook/index_datacollection_extra $colletion[ctid]}-->
</div>
<!--{if $_G['group']['radminid'] == 1}-->
	<!--{eval helper_manyou::checkupdate();}-->
<!--{/if}-->
<!--{if empty($_G['setting']['disfixednv_forumindex']) }--><script>fixed_top_nv();</script><!--{/if}-->
<!--{template common/footer}-->