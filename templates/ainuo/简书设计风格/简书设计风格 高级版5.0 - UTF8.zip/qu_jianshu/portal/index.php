<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>

	<script src="{$_G['style']['styleimgdir']}/js/jquery.SuperSlide.js" type="text/javascript"></script>
	<script src="{$_G['style']['styleimgdir']}/js/jPages.js"></script>
    <script type="text/javascript">
		jq(function() {
			  jq("div.q_holder").jPages({
				containerID: "qing_indexpage",
				previous: "",
				next: "",
				perPage: 10  //设置首页左侧列表每页显示数量
			  });
			  jq("#jp-qnav").click(function(){
				  jq('html,body').animate({scrollTop:450},0);
				  return false;
			  });
		});
	</script>
<div class="wp ct2 qing_portal0 cl" style="margin:20px auto;">
	<div class="mn">
    	<!--首页左侧顶部焦点图 start 3039089614-->
        <!--[diy=q_indexdiyfocus]--><div id="q_indexdiyfocus" class="area"></div><!--[/diy]-->
        <!--首页左侧顶部焦点图 end 3039089614-->
		<!--[diy=q_indexdiyfocusb]--><div id="q_indexdiyfocusb" class="area"></div><!--[/diy]-->
        
        <!--首页左侧列表 start 3039089614-->
        <div class="qing_index_leftlist bm cl">
            <!--[diy=q_indexdiyleftlist]--><div id="q_indexdiyleftlist" class="area"></div><!--[/diy]-->
        </div>
        <div id="jp-qnav" class="q_holder"></div>
        <!--首页左侧列表 end 3039089614-->
    </div>
    <div class="sd">
    	<!--签到 start 3039089614-->
    	<!--{hook/index_side_k_misign}-->
        <!--签到 end 3039089614-->
        
    	<!--[diy=q_indexdiyright]--><div id="q_indexdiyright" class="area"></div><!--[/diy]-->
        
        <!--社区导航 start 3039089614-->
        <div class="bm qing_sqdh cl">
        	<!--[diy=q_indexdiysqdh]--><div id="q_indexdiysqdh" class="area"></div><!--[/diy]-->
		</div>
		<!--社区导航 end 3039089614-->
        
        <!--[diy=q_indexdiyrightdown]--><div id="q_indexdiyrightdown" class="area"></div><!--[/diy]-->
    </div>
    
</div>

</div>
<div class="qing_index_foot cl">
	<div class="wp cl">
		<!--[diy=q_indexdiylink]--><div id="q_indexdiylink" class="area"></div><!--[/diy]-->
    </div>
</div>
<div id="wp" class="wp">
<script type="text/javascript">
jq(".q_topltslide").slide({titCell:".rnum li",mainCell:".rpic",effect:"fold",autoPlay:true,trigger:"click",startFun:function(i){jq(".q_topltslide .rtxt li").eq(i).animate({"bottom":0}).siblings().animate({"bottom":-40})}});
</script>
<script src="misc.php?mod=diyhelp&action=get&type=index&diy=yes&r={echo random(4)}" type="text/javascript"></script>
<!--{template common/footer}-->
