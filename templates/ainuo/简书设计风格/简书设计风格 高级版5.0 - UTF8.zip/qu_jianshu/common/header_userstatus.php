<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>

<!--{if $_G['uid']}-->

<div class="cl qing_af_login">



	<a href="home.php?mod=space&uid=$_G[uid]" id="qing_user" onMouseOver="showMenu({'ctrlid':'qing_user','ctrlclass':'a'});">{$_G[member][username]} ( $_G[group][grouptitle] )<i></i></a>

    

    <a href="home.php?mod=space&do=notice" id="myprompt" class="a {if $_G[member][newprompt]} new{/if}" onmouseover="showMenu({'ctrlid':'myprompt'});" style="padding-right:0; font-size:14px;">{lang remind}<!--{if $_G[member][newprompt]}-->($_G[member][newprompt])<!--{/if}--></a><span id="myprompt_check"></span>

    

    <!--{if empty($_G['cookie']['ignore_notice']) && ($_G[member][newpm] || $_G[member][newprompt_num][follower] || $_G[member][newprompt_num][follow] || $_G[member][newprompt])}--><script language="javascript">delayShow($('myprompt'), function() {showMenu({'ctrlid':'myprompt','duration':3})});</script><!--{/if}-->

    

    <div id="qing_user_menu" class="qing_user_pop" style="display: none;">

		<a href="home.php?mod=spacecp&ac=avatar" class="qing_userinfo_avtar" target="_blank"><div class="grid_edit">{lang edit}</div><!--{avatar($_G[uid],middle)}--></a>

        <!--{subtemplate common/header_qmenu}-->

        <!--{hook/global_usernav_extra1}-->

        <!--{hook/global_usernav_extra2}-->

        <!--{hook/global_usernav_extra3}-->

        <!--{hook/global_usernav_extra4}-->



		<a href="home.php?mod=spacecp&ac=credit&showcredit=1"><span class="z">{lang credits}</span><span class="y">$_G[member][credits]</span></a>

		<a href="home.php?mod=spacecp">{lang setup}</a>

		

		<!--{if $_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])}--><a href="home.php?mod=task&item=doing" id="task_ntc"><span class="z">{lang task_doing}</span></a><!--{/if}-->

		<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->

			<a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a>

		<!--{/if}-->

		<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->

			<a href="admin.php" target="_blank">{lang admincp}</a>

		<!--{/if}-->

        
		<!--{if check_diy_perm($topic)}--><a href="javascript:openDiy();" title="{lang open_diy}"><font color="#ff0000">{lang open_diy}</font></a><!--{/if}-->
		<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>

		

    </div>

</div>



<!--{elseif !empty($_G['cookie']['loginuser'])}-->
    <div class="qing_af_login cl">
        <a href="home.php?mod=space&uid=$_G[uid]" id="qing_user" onMouseOver="showMenu({'ctrlid':'qing_user','ctrlclass':'a'});"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--><i></i></a>
        <div id="qing_user_menu" class="qing_user_pop" style="display: none;">
            <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
            <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
        </div>
    </div>
<!--{elseif !$_G[connectguest]}-->
	<div class="qing_no_login cl">
        <a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang login}</a>
        <a href="member.php?mod={$_G[setting][regname]}" class="zhuc">$_G['setting']['reglinkname']</a>
    </div>
<!--{else}-->
<div class="qing_af_login cl">
    <a href="home.php?mod=space&uid=$_G[uid]" id="qing_user" onMouseOver="showMenu({'ctrlid':'qing_user','ctrlclass':'a'});">{$_G[member][username]}<i></i></a>
    <div id="qing_user_menu" class="qing_user_pop" style="display: none;">
    	<!--{hook/global_usernav_extra1}-->
    	<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
    </div>
</div>
<!--{/if}-->