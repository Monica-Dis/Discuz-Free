<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="qing_qmenu cl">
	<a href="home.php?mod=magic">{lang magic}</a>
    <a href="home.php?mod=medal">{lang medals}</a>
    <a href="home.php?mod=task">{lang task}</a>
    <a href="home.php?mod=space&do=blog">{lang blog}</a>
    <a href="home.php?mod=space&do=album">{lang album}</a>
    <a href="home.php?mod=space&do=doing">{lang doing}</a>
</div>