<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
				<!--{if $list['threadcount']}-->
						<!--{loop $list['threadlist'] $key $thread}-->
							<tbody id="$thread[id]">
								<tr>

									<th class="$thread[folder]">
										{if $thread['attachment'] == 2}
                                          {eval $table='forum_attachment_'.substr($thread['tid'], -1);}
                                          {eval $threadaid = DB::result_first("SELECT aid FROM ".DB::table($table)." WHERE tid='$thread[tid]' AND isimage!='0'");}
                                          
                                          {if $threadaid}
                                            
                                            {eval $threadimg = 1}
                                          
                                          {else}
                                            {eval $threadimg = 0}
                                          {/if}
                                        {else}
                                            {eval $threadimg = 0}
                                        {/if}
                                    	<div class="q_f_title0 cl">
                                    		<a class="q_user_avatar" href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread[authorid], 'middle')}--></a>
                                         	<!--{hook/forumdisplay_author $key}-->
                                                <!--{if $thread['authorid'] && $thread['author']}-->
                                                <a href="home.php?mod=space&uid=$thread[authorid]" {if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if}>$thread[author]</a><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->
                                            <!--{else}-->
                                                $_G[setting][anonymoustext]
                                            <!--{/if}-->
                                            &nbsp;<span{if $thread['istoday']} class="q_xi1"{/if}> $thread[dateline]</span>
                                        
                                        </div>
                                    	<div class="q_f_title1" {if $threadimg}style="min-height:150px;"{else}style="padding-right:0;"{/if}>
                                        {if $threadimg}
                                        <div class="q_f_titlerimg">
                                        	<a href="forum.php?mod=viewthread&tid=$thread[tid]">
                                                <img src="{eval echo(getforumimg($threadaid,0,150,120))}" />
                                            </a>
                                        </div>
                                        {/if}
                                        
										<a href="javascript:;" id="content_$thread[tid]" class="showcontent y" title="{lang content_actions}" onclick="CONTENT_TID='$thread[tid]';CONTENT_ID='$thread[id]';showMenu({'ctrlid':this.id,'menuid':'content_menu'})"></a>

										<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->

										<!--{hook/forumdisplay_thread $key}-->
										<div class="z qing_fenlei">$thread[typehtml] $thread[sorthtml]</div>
										<!--{if $thread['moved']}-->
											{lang thread_moved}:<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
                                        
										<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} {if $_G[fid] == $indexfid}target="_blank"{else}onclick="atarget(this)"{/if}{/if} class="s xst">$thread[subject]</a>
										<!--{if $_G['setting']['threadhidethreshold'] && $thread['hidden'] >= $_G['setting']['threadhidethreshold']}--><span class="xg1">{lang hidden}</span>&nbsp;<!--{/if}-->
										<!--{if $thread[icon] >= 0}-->
											<img src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" />
										<!--{/if}-->
										<!--{if $thread['rushreply']}-->
											<img src="{IMGDIR}/rushreply_s.png" align="absmiddle" alt="{lang rushreply}" />
											<!--{if $rushinfo[$thread[tid]]}-->
											<span id="rushtimer_$thread[tid]"> {lang havemore_special} <span id="rushtimer_body_$thread[tid]"></span> <script language="javascript">settimer($rushinfo[$thread[tid]]['timer'], 'rushtimer_body_$thread[tid]');</script>{if $rushinfo[$thread[tid]]['timertype'] == 'start'} {lang header_start} {else} {lang over} {/if} {lang right_special}</span>
											<!--{/if}-->
										<!--{/if}-->
										<!--{if $stemplate && $sortid}-->$stemplate[$sortid][$thread[tid]]<!--{/if}-->
										<!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->
										<!--{if $thread['price'] > 0}-->
											<!--{if $thread['special'] == '3'}-->
											- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1" title="{lang show_rewarding_only}"><span class="xi1">[{lang thread_reward} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span></a>
											<!--{else}-->
											- [{lang price} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
											<!--{/if}-->
										<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
											- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2" title="{lang show_rewarded_only}">[{lang reward_solved}]</a>
										<!--{/if}-->
                                        <!--{if $thread[folder] == 'lock'}-->
                                        	<img src="{$_G['style']['styleimgdir']}/icon/lock.png" />
										<!--{elseif $thread['special'] == 1}-->
											<img src="{$_G['style']['styleimgdir']}/icon/pollsmall.gif" alt="{lang thread_poll}" />
										<!--{elseif $thread['special'] == 4}-->
											<img src="{$_G['style']['styleimgdir']}/icon/activity_s.png" alt="{lang thread_activity}" />
										<!--{elseif $thread['special'] == 5}-->
											<img src="{$_G['style']['styleimgdir']}/icon/debate_s.png" alt="{lang thread_debate}" />
										<!--{/if}-->

                                        
										<!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
											<img src="{$_G['style']['styleimgdir']}/icon/jing.gif" alt="digest" align="absmiddle" title="{lang thread_digest} $thread[digest]" />
										<!--{/if}-->
                                        
										<!--{if $thread['displayorder'] == 0}-->
											<!--{if $thread[recommendicon] && $filter != 'recommend'}-->
												<img src="{IMGDIR}/recommend_$thread[recommendicon].gif" alt="recommend" align="absmiddle" title="{lang thread_recommend} $thread[recommends]" />
											<!--{/if}-->
											<!--{if $thread[heatlevel]}-->
												<img src="{$_G['style']['styleimgdir']}/icon/hot_$thread[heatlevel].gif" alt="heatlevel" align="absmiddle" title="{lang heats}: {$thread[heats]}" />
											<!--{/if}-->
											<!--{if $thread['rate'] > 0}-->
												<img src="{$_G['style']['styleimgdir']}/icon/agree.gif" alt="agree" align="absmiddle" title="{lang rate_credit_add}" />
											<!--{elseif $thread['rate'] < 0}-->
												<img src="{$_G['style']['styleimgdir']}/icon/disagree.gif" alt="disagree" align="absmiddle" title="{lang posts_deducted}" />
											<!--{/if}-->
										<!--{/if}-->
                                        <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
											<img src="{$_G['style']['styleimgdir']}/icon/zd.gif" align="absmiddle" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
										<!--{/if}-->
										<!--{if $thread['replycredit'] > 0}-->
											- <span class="xi1">[{lang replycredit} <strong> $thread['replycredit']</strong> ]</span>
										<!--{/if}-->
                                        <div class="q_f_title1-1 cl" style="font-size:14px; color:#555; line-height:1.5; margin-top:5px;">
                                        	<!--{eval require_once(DISCUZ_ROOT."./source/function/function_post.php");}-->
                                            <!--{echo messagecutstr(DB::result_first('SELECT `message` FROM '.DB::table('forum_post').' WHERE `tid` ='.$thread[tid].' AND `first` =1'),180);}-->
                                        </div>

                                        </div>
                                        
                                        <!--{hook/forumdisplay_thread_subject $key}-->
                                        <div class="q_f_title2">
                                            <div class="z">
                                            	<div class="f_rn_title"><span class="s_view"></span>$thread[views]<span class="s_reply"></span>$thread[allreplies]</div>
                                            </div>
                                        </div>
									</th>
									
								</tr>
							</tbody>

						<!--{/loop}-->
				<!--{else}-->
						<tbody class="bw0_all"><tr><th><p class="nothread" style="background:none;">{lang guide_nothreads}</p></th></tr></tbody>
				<!--{/if}-->