<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G['forum']['recommendlist']['images'] && $_G['forum']['modrecommend']['imagenum']}-->
<script src="{$_G['style']['styleimgdir']}/js/jquery.SuperSlide.js" type="text/javascript"></script>
<div class="bm">
    <div class="bm_h cl"><h2>{lang forummanager}{lang recommend}</h2></div>
	<div class="qing_tuijianimg cl">
		<div class="q_topltslide">
            <ul class="rpic">
            <!--{loop $_G['forum']['recommendlist']['images'] $k $imginfo}-->
            <li><a href="forum.php?mod=viewthread&tid=$imginfo[tid]" target="_blank"><img src="$imginfo[filename]" width="{$_G[forum][modrecommend][imagewidth]}" height="{$_G['forum'][modrecommend][imageheight]}" /></a></li>
            <!--{/loop}-->
            </ul>
            <div class="txt-bg"></div>
            <div class="rtxt">
                <ul>
                    <!--{loop $_G['forum']['recommendlist']['images'] $k $imginfo}-->
                    <li><a href="forum.php?mod=viewthread&tid=$imginfo[tid]" target="_blank"><!--{echo $imginfo[subject]}--></a></li>
                    <!--{/loop}-->
                </ul>
            </div>
            <ul class="rnum">
            <!--{loop $_G['forum']['recommendlist']['images'] $k $imginfo}-->
            <li><a href="javascript:;"></a></li>
            <!--{/loop}-->
            </ul>
        </div>
	</div>
</div>
<script type="text/javascript">
q_jq(".q_topltslide").slide({titCell:".rnum li",mainCell:".rpic",effect:"fold",autoPlay:true,trigger:"mouseover",startFun:function(i){q_jq(".q_topltslide .rtxt li").eq(i).animate({"bottom":0}).siblings().animate({"bottom":-40})}});
</script>
<!--{/if}-->

<div class="bm">
    <div class="bm_h cl"><h2>{lang forum_recommend}</h2></div>
    <div class="qing_tuijianlist cl">
    <!--{eval unset($_G['forum']['recommendlist']['images']);}-->
		<ul>
            <!--{loop $_G['forum']['recommendlist'] $rtid $recommend}-->
                <li><span></span><a href="forum.php?mod=viewthread&tid=$rtid" $recommend[subjectstyles] target="_blank">$recommend[subject]</a></li>
            <!--{/loop}-->
        </ul>
    </div>
</div>
