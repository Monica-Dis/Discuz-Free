<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="u_profile qing_u_profile">
	<table width="100%">
    	<tr>
        	<td class="qleft">
            	{lang basic_situation}
            </td>
            <td>
                <h2 class="mbn">
                    {$space[username]}
                    <!--{if $_G['setting']['verify']['enabled']}-->
                        <!--{eval $showverify = true;}-->
                        <!--{loop $_G['setting']['verify'] $vid $verify}-->
                            <!--{if $verify['available']}-->
                                <!--{if $showverify}-->
                                <!--{eval $showverify = false;}-->
                                <!--{/if}-->
                    
                                <!--{if $space['verify'.$vid] == 1}-->
                                    <a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $verify['icon']}--><img src="$verify['icon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{else}-->$verify[title]<!--{/if}--></a>&nbsp;
                                <!--{elseif !empty($verify['unverifyicon'])}-->
                                    <a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $verify['unverifyicon']}--><img src="$verify['unverifyicon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{/if}--></a>&nbsp;
                                <!--{/if}-->
                    
                            <!--{/if}-->
                        <!--{/loop}-->
                        <!--{if !$showverify}--><!--{/if}-->
                    <!--{/if}-->
                    <!--{if $_G['ols'][$space[uid]]}-->
                        <img src="{IMGDIR}/ol.gif" alt="online" title="{lang online}" class="vm" />&nbsp;
                    <!--{/if}-->
                    <span class="xw0">(UID: {$space[uid]}
                    <!--{eval $isfriendinfo = 'home_friend_info_'.$space['uid'].'_'.$_G[uid];}-->
                    <!--{if $_G[$isfriendinfo][note]}-->
                        , <span class="xg1">$_G[$isfriendinfo][note]</span>
                    <!--{/if}-->
                    )</span>
                </h2>
                <!--{if CURMODULE == 'space'}-->
                    <!--{hook/space_profile_baseinfo_top}-->
                <!--{elseif CURMODULE == 'follow'}-->
                    <!--{hook/follow_profile_baseinfo_top}-->
                <!--{/if}-->
                <ul class="pf_l cl">
                    <!--{if $_G['setting']['allowspacedomain'] && $_G['setting']['domain']['root']['home'] && checkperm('domainlength') && !empty($space['domain'])}-->
                    <!--{eval $spaceurl = 'http://'.$space['domain'].'.'.$_G['setting']['domain']['root']['home'];}-->
                    <li><em>{lang second_domain}</em><a href="$spaceurl" onclick="setCopy('$spaceurl', '{lang copy_space_address}');return false;">$spaceurl</a></li>
                    <!--{/if}-->
                    <!--{if $_G[setting][homepagestyle]}-->
                    <li><em>{lang space_visits}</em><strong class="xi1">$space[views]</strong></li>
                    <!--{/if}-->
                    <!--{if in_array($_G[adminid], array(1, 2))}-->
                    <li><em>Email</em>$space[email]</li>
                    <!--{/if}-->
                    <li><em>{lang email_status}</em><!--{if $space[emailstatus] > 0}-->{lang profile_verified}<!--{else}-->{lang profile_no_verified}<!--{/if}--></li>
                    <li><em>{lang video_certification}</em><!--{if $space[videophotostatus] > 0}-->{lang profile_certified} <!--{if $showvideophoto}-->&nbsp;&nbsp;(<a href="home.php?mod=space&uid=$space[uid]&do=videophoto" id="viewphoto" onclick="showWindow(this.id, this.href, 'get', 0)">{lang view_certification_photos}</a>)<!--{/if}--><!--{else}-->{lang profile_no_certified}<!--{/if}--></li>
                </ul>

            </td>
        </tr>
        <!--{if $space[spacenote]}-->
        <tr>
        	<td class="qleft">{lang spacenote}</td>
            <td>$space[spacenote]</td>
        </tr>
        <!--{/if}-->
        <!--{if $space[customstatus]}-->
        <tr>
        	<td class="qleft">{lang permission_basic_status}</td>
            <td>$space[customstatus]</td>
        </tr>
        <!--{/if}-->
        <!--{if $space[group][maxsigsize] && $space[sightml]}-->
        <tr>
        	<td class="qleft">{lang personal_signature}</td>
            <td>$space[sightml]</td>
        </tr>
        <!--{/if}-->

        <tr>
        	<td class="qleft">{lang stat_info}</td>
            <td>
            	<a href="home.php?mod=space&uid=$space[uid]&do=friend&view=me&from=space" target="_blank">{lang friends_num} $space[friends]</a>
				<!--{if helper_access::check_module('doing')}-->
					<span class="pipe">|</span>
					<a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space" target="_blank">{lang doings_num} $space[doings]</a>
				<!--{/if}-->
				<!--{if helper_access::check_module('blog')}-->
					<span class="pipe">|</span>
					<a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space" target="_blank">{lang blogs_num} $space[blogs]</a>
				<!--{/if}-->
				<!--{if helper_access::check_module('album')}-->
					<span class="pipe">|</span>
					<a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space" target="_blank">{lang albums_num} $space[albums]</a>
				<!--{/if}-->
				<!--{if $_G['setting']['allowviewuserthread'] !== false}-->
					<span class="pipe">|</span>
					<!--{eval $space['posts'] = $space['posts'] - $space['threads'];}-->
					<a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=reply&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread&type=reply{/if}" target="_blank">{lang replay_num} $space[posts]</a>
					<span class="pipe">|</span>
					<a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=thread&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread{/if}" target="_blank">{lang threads_num} $space[threads]</a>
				<!--{/if}-->
				<!--{if helper_access::check_module('share')}-->
					<span class="pipe">|</span>
					<a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space" target="_blank">{lang shares_num} $space[sharings]</a>
				<!--{/if}-->
            </td>
        </tr>
        <!--{if $profiles}-->
        <tr>
        	<td class="qleft">{lang memcp_profile}</td>
            <td>
            	<ul class="pf_l cl">
                <!--{loop $profiles $value}-->
                <li><em>$value[title]</em>$value[value]</li>
                <!--{/loop}-->
                </ul>
            </td>
        </tr>
        <!--{/if}-->
        <!--{if $space['medals']}-->
        <tr>
        	<td class="qleft">{lang medals}</td>
            <td>
            	<a href="home.php?mod=medal" class="qing_home_medal">
                <!--{loop $space['medals'] $medal}-->
                    <img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" id="md_{$medal[medalid]}" onmouseover="showMenu({'ctrlid':this.id, 'menuid':'md_{$medal[medalid]}_menu', 'pos':'12!'});" />
                <!--{/loop}-->
                </a>
                	<!--{loop $space['medals'] $medal}-->
                        <div id="md_{$medal[medalid]}_menu" class="tip tip_4" style="display: none;">
                            <div class="tip_horn"></div>
                            <div class="tip_c">
                                <h4>$medal[name]</h4>
                                <p>$medal[description]</p>
                            </div>
                        </div>
                    <!--{/loop}-->
            </td>
        </tr>
        <!--{/if}-->

        <!--{if $count}-->
        <tr>
        	<td class="qleft">{lang manage_forums}</td>
            <td>
            	<!--{loop $manage_forum $key $value}-->
                <a href="forum.php?mod=forumdisplay&fid=$key" target="_blank">$value</a> &nbsp;
                <!--{/loop}-->
            </td>
        </tr>
        <!--{/if}-->
        
        <!--{if $groupcount}-->
        <tr>
        	<td class="qleft">{lang joined_group}</td>
            <td>
            	<!--{loop $usergrouplist $key $value}-->
                <a href="forum.php?mod=group&fid={$value['fid']}" target="_blank">$value['name']</a> &nbsp;
                <!--{/loop}-->
            </td>
        </tr>
        <!--{/if}-->
        
        <tr>
        	<td class="qleft">{lang active_profile}</td>
            <td>
            	<ul>
                    <!--{if $space[adminid]}--><li><em class="xg1">{lang management_team}&nbsp;&nbsp;</em><span style="color:{$space[admingroup][color]}"><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[adminid]" target="_blank">{$space[admingroup][grouptitle]}</a></span> {$space[admingroup][icon]}</li><!--{/if}-->
                    <li><em class="xg1">{lang usergroup}&nbsp;&nbsp;</em><span style="color:{$space[group][color]}"{if $upgradecredit !== false} class="xi2" onmouseover="showTip(this)" tip="{lang credits} $space[credits], {lang thread_groupupgrade} $upgradecredit {lang credits}"{/if}><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[groupid]" target="_blank">{$space[group][grouptitle]}</a></span> {$space[group][icon]} <!--{if !empty($space['groupexpiry'])}-->&nbsp;{lang group_useful_life}&nbsp;<!--{date($space[groupexpiry], 'Y-m-d H:i')}--><!--{/if}--></li>
                    <!--{if $space[extgroupids]}--><li><em class="xg1">{lang group_expiry_type_ext}&nbsp;&nbsp;</em>$space[extgroupids]</li><!--{/if}-->
                </ul>
                <ul id="pbbs" class="pf_l">
                    <!--{if $space[oltime]}--><li><em>{lang online_time}</em>$space[oltime] {lang hours}</li><!--{/if}-->
                    <li><em>{lang regdate}</em>$space[regdate]</li>
                    <li><em>{lang last_visit}</em>$space[lastvisit]</li>
                    <!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
                    <li><em>{lang register_ip}</em>$space[regip] - $space[regip_loc]</li>
                    <li><em>{lang last_visit_ip}</em>$space[lastip]:$space[port] - $space[lastip_loc]</li>
                    <!--{/if}-->
                    <!--{if $space[lastactivity]}--><li><em>{lang last_activity_time}</em>$space[lastactivity]</li><!--{/if}-->
                    <!--{if $space[lastpost]}--><li><em>{lang last_post_time}</em>$space[lastpost]</li><!--{/if}-->
                    <!--{if $space[lastsendmail]}--><li><em>{lang last_send_email}</em>$space[lastsendmail]</li><!--{/if}-->
                    <li><em>{lang time_offset}</em>
                        <!--{eval $timeoffset = array({lang timezone});}-->
                        $timeoffset[$space[timeoffset]]
                    </li>
                </ul>
            </td>
        </tr>

        <tr>
        	<td class="qleft">{lang stat_info}</td>
            <td>
            	<ul class="pf_l">
                    <li><em>{lang used_space}</em>$space[attachsize]</li>
                    <!--{if $space[buyercredit]}-->
                    <li><em>{lang eccredit_sellerinfo}</em><a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit#sellcredit" target="_blank">$space[buyercredit] <img src="{STATICURL}image/traderank/buyer/$space[buyerrank].gif" border="0" class="vm" /></a></li>
                    <!--{/if}-->
                    <!--{if $space[sellercredit]}-->
                    <li><em>{lang eccredit_buyerinfo}</em><a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit#buyercredit" target="_blank">$space[sellercredit] <img src="{STATICURL}image/traderank/seller/$space[sellerrank].gif" border="0" class="vm" /></a></li>
                    <!--{/if}-->
                    <li><em>{lang credits}</em>$space[credits]</li>
                    <!--{loop $_G[setting][extcredits] $key $value}-->
                    <!--{if $value[title]}-->
                    <li><em>$value[title]</em>{$space["extcredits$key"]} $value[unit]</li>
                    <!--{/if}-->
                    <!--{/loop}-->
                </ul>
            </td>
        </tr>
        
        <!--{if $clist}-->
        <tr>
        	<td class="qleft">{lang crime_record}</td>
            <td>
            	<table id="pcr" class="dt">
                    <tr>
                        <th width="15%">{lang crime_action}</th>
                        <th width="15%">{lang crime_dateline}</th>
                        <th>{lang crime_reason}</th>
                        <th width="15%">{lang crime_operator}</th>
                    </tr>
                    <!--{loop $clist $crime}-->
                    <tr>
                        <td>
                            <!--{if $crime[action] == 'crime_delpost'}-->
                                {lang crime_delpost}
                            <!--{elseif $crime[action] == 'crime_warnpost'}-->
                                {lang crime_warnpost}
                            <!--{elseif $crime[action] == 'crime_banpost'}-->
                                {lang crime_banpost}
                            <!--{elseif $crime[action] == 'crime_banspeak'}-->
                                {lang crime_banspeak}
                            <!--{elseif $crime[action] == 'crime_banvisit'}-->
                                {lang crime_banvisit}
                            <!--{elseif $crime[action] == 'crime_banstatus'}-->
                                {lang crime_banstatus}
                            <!--{elseif $crime[action] == 'crime_avatar'}-->
                                {lang crime_avatar}
                            <!--{elseif $crime[action] == 'crime_sightml'}-->
                                {lang crime_sightml}
                            <!--{elseif $crime[action] == 'crime_customstatus'}-->
                                {lang crime_customstatus}
                            <!--{/if}-->
                        </td>
                        <td><!--{date($crime[dateline])}--></td>
                        <td>$crime[reason]</td>
                        <td><a href="home.php?mod=space&uid=$crime[operatorid]" target="_blank">$crime[operator]</a></td>
                    </tr>
                    <!--{/loop}-->
                </table>
            </td>
        </tr>
        <!--{/if}-->
        
    </table>
		


<!--{hook/space_profile_baseinfo_middle}-->

<!--{hook/follow_profile_baseinfo_middle}-->

<!--{hook/space_profile_baseinfo_bottom}-->

<!--{hook/follow_profile_baseinfo_bottom}-->

<!--{if CURMODULE == 'space'}-->
	<!--{hook/space_profile_extrainfo}-->
<!--{elseif CURMODULE == 'follow'}-->
	<!--{hook/follow_profile_extrainfo}-->
<!--{/if}-->
</div>