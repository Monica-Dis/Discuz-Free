<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      V1.0 http://t.cn/Aiux1Jx1
 *		DISM.TAOBAO.COM
 *      dism-taobao-com
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$view = $_GET['view'];
loadcache('ranklist');
loadcache('ranklisttop');
$langvars=lang('plugin/qu_ranklist');
$vars = $_G['cache']['plugin']['qu_ranklist'];
$hy_con = $vars['hy_con'];
$jf_con = $vars['jf_con'];
$tz_con = $vars['tz_con'];
$zt_con = $vars['zt_con'];
$aicon = $vars['icon'];
$qujian = $vars['qujian'] ? $vars['qujian'] : 100;
$astyle = $vars['astyle'];
$atitle = $vars['atitle'];
$atime = $vars['atime'];
$touchcolor = $vars['touchcolor'];
$touchnav = $vars['touchnav'];
$qu_listnum = $vars['num'];
$aziduan = $vars['aziduan'] ? 'extcredits'.$vars['aziduan']:'credits';
$aziduanid = $vars['aziduan'];
$sumnum = $vars['sumnum'] ? $vars['sumnum']:'290';
$auser = (array)unserialize($vars['auser']);

$navtitle = $vars['navtitle'];
$metakeywords = $vars['metakeywords'];
$metadescription = $vars['metadescription'];

if(!in_array($view, array($aziduan, 'posts', 'threads','friends'))) {
	$view = $aziduan;
}
$currentview[$view] = 'class="xw1 a"';
$perpage = $qu_listnum ? $qu_listnum : 10;
$start = $perpage * ($_G['page'] - 1);
$data = array();
$data[$view] = get_user_list($view, $start, $perpage);
$count = $data[$view]['usercount'];
$mpurl = 'plugin.php?id=qu_ranklist:ranklist&view='.$view;
$multipage = multi($count, $perpage, $_G['page'], $mpurl);

//获取个人信息排名
if($_G['uid']){
	$mypos = 0;
	$myview = C::t('#qu_ranklist#plugin_qu_ranklist')->fetch_by_conlist($view,$_G['uid']);
	$opos = C::t('#qu_ranklist#plugin_qu_ranklist')->fetch_user_by_uid($view);
	$o=0;
	foreach($opos as $pos){
		if(!in_array($pos['groupid'], $auser)){
			continue;
		}
		$o++;
		if(($pos[$view] == $myview) && ($pos['uid'] == $_G['uid'])){
			$mypos = $o;
			break;
		}
	}
}

include template('qu_ranklist:index');

//获取所有会员列表
function get_user_list($view, $start = 0, $num = 10) {
	global $_G,$atime,$start,$auser,$sumnum;
	$query = C::t('#qu_ranklist#plugin_qu_ranklist')->fetch_user_by_uid($view,$start,$num);
	$n = 0;
	$xn = 0;
	foreach($query as $user) {
		if(!in_array($user['groupid'], $auser)){
			continue;
		}
		$xn ++;
		if($xn > $sumnum){
			break;
		}
		$userids[] = $user['uid'];
		if($uids || ($n >= $start && $n < ($start + $num))) {
			$list[$user[uid]] = $user;
		}
		$n++;
	}
	$userlist = array();
	$userlist = $list;
	unset($list);
	if($updatecache) {
		$usercount = count($userids);
		$data = array('cachetime' => TIMESTAMP, 'data' => $userids);
		$_G['cache']['ranklist'][$view] = $data;
		savecache('ranklist', $_G['cache']['ranklist']);
	}
	return array('usercount' => $usercount, 'userlist' => $userlist);
	/*$cachetimelimit = $atime ? $atime : 0;
	$cache = $_G['cache']['ranklist'][$view];
	if($cache && (TIMESTAMP - $cache['cachetime']) < $cachetimelimit) {
		$uids = $cache['data'];
		$usercount = count($uids);
		$uids = array_slice($uids, $start, $num, true);
		$updatecache = false;
		if(empty($uids)) {
			return array();
		}
	} else {
		$uids = array();
		$updatecache = true;
	}
	$query = C::t('#qu_ranklist#plugin_qu_ranklist')->fetch_user_by_uid($view,$uids);
	$n = 0;
	$xn = 0;
	foreach($query as $user) {
		if(!in_array($user['groupid'], $auser)){
			continue;
		}
		$xn ++;
		if($xn > $sumnum){
			break;
		}
		$userids[] = $user['uid'];
		if($uids || ($n >= $start && $n < ($start + $num))) {
			$list[$user[uid]] = $user;
		}
		$n++;
	}
	$userlist = array();
	if($uids) {
		$userids = array();
		foreach($uids as $key => $uid) {
			if($list[$uid]) {
				$userlist[$key] = $list[$uid];
				$userids[] = $uid;
			}
		}
	} else {
		$userlist = $list;
	}
	unset($list);
	if($updatecache) {
		$usercount = count($userids);
		$data = array('cachetime' => TIMESTAMP, 'data' => $userids);
		$_G['cache']['ranklist'][$view] = $data;
		savecache('ranklist', $_G['cache']['ranklist']);
	}
	return array('usercount' => $usercount, 'userlist' => $userlist);*/
}



?>