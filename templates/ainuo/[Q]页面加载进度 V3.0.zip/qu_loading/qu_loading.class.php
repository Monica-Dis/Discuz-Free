<?php

/**
 * 页面加载进度，支持多平台
 * 官方网址 https://dism.taobao.com/?@qu
 * 官方DISM.TAOBAO.COM
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_qu_loading {
    function global_cpnav_top(){
        global $_G;
        $q_var = $_G['cache']['plugin']['qu_loading'];
        $color = $q_var['color'] ? $q_var['color'] : '#ee3148';
        $height = intval($q_var['height']);
        $result = '';
        if($q_var['open']){
            $result .= '<link rel="stylesheet" type="text/css" href="'.$_G['siteurl'].'source/plugin/qu_loading/css/style.css" /><style>.pace .pace-progress{background:'.$color.';height:'.$height.'px}.pace .pace-activity{border-top-color:'.$color.';border-left-color:'.$color.';}</style><script src="'.$_G['siteurl'].'source/plugin/qu_loading/js/pace.min.js"></script><div class="pace pace-inactive"><div data-progress="99" data-progress-text="100%" style="transform: translate3d(100%, 0px, 0px);" class="pace-progress"><div class="pace-progress-inner"></div></div><div class="pace-activity"></div></div>';
            if(!$q_var['cicle']){
                $result .='<style>.pace .pace-activity{display:none;}</style>';
            }
            return $result;
        }
    }
}

class mobileplugin_qu_loading {
    function global_header_mobile(){
        global $_G;
        $q_var = $_G['cache']['plugin']['qu_loading'];
        $color = $q_var['color'] ? $q_var['color'] : '#ee3148';
        $height = intval($q_var['height']);
        $result = '';
        if($q_var['opentouch']){
            $result .= '<link rel="stylesheet" type="text/css" href="'.$_G['siteurl'].'source/plugin/qu_loading/css/style.css" /><style>.pace .pace-progress{background:'.$color.';height:'.$height.'px}.pace .pace-activity{border-top-color:'.$color.';border-left-color:'.$color.';}</style><script src="'.$_G['siteurl'].'source/plugin/qu_loading/js/pace.min.js"></script><div class="pace pace-inactive"><div data-progress="99" data-progress-text="100%" style="transform: translate3d(100%, 0px, 0px);" class="pace-progress"><div class="pace-progress-inner"></div></div><div class="pace-activity"></div></div>';
            if(!$q_var['cicle']){
                $result .='<style>.pace .pace-activity{display:none;}</style>';
            }
            return $result;
        }
    }
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>