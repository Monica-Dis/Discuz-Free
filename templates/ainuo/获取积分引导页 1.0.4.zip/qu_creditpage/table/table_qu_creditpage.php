<?php

/**
 * 论坛获取积分引导页
 * 官方网址 https://dism.taobao.com/?@qu
 * 官方DISM.TAOBAO.COM
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_qu_creditpage extends discuz_table {

	public function __construct() {
		$this->_table = 'qu_creditpage';
		$this->_pk    = 'id';

		parent::__construct(); /*dism _ taobao _ com*/
	}

	public function count_by_search($param) {
		return DB::result_first('SELECT COUNT(*) FROM %t %i', array($this->_table, $this->wheresql($param)));
	}

	public function fetch_all_by_search($param, $start = 0, $limit = 0, $order = 'aorder', $sort = 'ASC') {
		$ordersql =  $order ? ' ORDER BY '.DB::order($order, $sort) : '';
		return DB::fetch_all('SELECT * FROM %t %i %i '.DB::limit($start, $limit), array($this->_table, $this->wheresql($param), $ordersql));
	}
	
	public function fetch_by_first($status) {
		return DB::fetch_first('SELECT * FROM %t WHERE '.DB::field('status', $status).' ORDER BY aorder ASC LIMIT 1', array($this->_table));
	}

	public function wheresql($param) {
		foreach($param as $value) {
			if($value[1]) {
				$wherearr[] = DB::field($value[0], is_array($value[1]) ? $value[1] : $value[3].$value[1].$value[4], $value[2] ? $value[2] : '=');
			}
		}
		$wheresql = $wherearr ? 'WHERE '.implode(' AND ', $wherearr) : '';
		return $wheresql;
	}

}
//From: Dism_taobao-com
?>