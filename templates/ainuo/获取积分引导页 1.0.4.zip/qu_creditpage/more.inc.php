<?php

/**
 * 论坛获取积分引导页
 * 官方网址 https://dism.taobao.com/?@qu
 * 官方DISM.TAOBAO.COM
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
//From: dis'.'m.tao'.'bao.com
?>
<iframe src="http://dism.taobao.com/?@27402.developer" width="1220" height="6070" frameborder="0" scrolling="no" style="margin-top:-55px"></iframe> 
