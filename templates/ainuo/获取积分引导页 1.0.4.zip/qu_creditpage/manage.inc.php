<?php

/**
 * 论坛获取积分引导页
 * 官方网址 https://dism.taobao.com/?@qu
 * 官方DISM.TAOBAO.COM
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $scriptlang;
$lang = array_merge($lang, $scriptlang['qu_creditpage']);

if(empty($_GET['ac'])) {

	if(!submitcheck('creditsubmit')) {

		$perpage = 20;
		$start = ($page - 1) * $perpage;
		$mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$plugin['pluginid']."&identifier=qu_creditpage&pmod=manage";
		showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier=qu_creditpage&pmod=manage');
		showtableheader();
		showsubtitle(array('del', 'name','aorder','descript', cplang('status'), ''));
		$count = C::t('#qu_creditpage#qu_creditpage')->count_by_search($param);
		if($count) {
			$query = C::t('#qu_creditpage#qu_creditpage')->fetch_all_by_search($param, $start, $perpage);
			foreach($query as $value) {
				showtablerow('', array('class="td25"', 'class="td24"','class="td25"', '', 'class="td23"', 'class="td24"'), array(
					'<input type="checkbox" class="checkbox" name="ids[]" value="'.$value['id'].'" />',
					'<font color='.$value['acolor'].'>'.$value['title'].'</font>',
					$value['aorder'],
                    $value['descript'],
					cplang('status-'.$value['status'].''),
					"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do=".$plugin['pluginid']."&identifier=qu_creditpage&pmod=manage&ac=edit&id=$value[id]\">$lang[edit]</a>"
				));
			}
			$multipage = multi($count, $perpage, $page, $mpurl);
		}
		echo '<tr><td></td><td colspan="7"><div><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier=qu_creditpage&pmod=manage&ac=add" class="addtr">'.cplang('add').'</a></div></td></tr>';
		showsubmit('creditsubmit', 'submit', '<input type="checkbox" name="chkall" id="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')" /><label for="chkall">'.cplang('select_all').'</label><input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.cplang('delete').'</label>', '', $multipage);
		showtablefooter(); /*Dism·taobao·com*/
		showformfooter(); /*Dism_taobao_com*/

	} else {

		if(is_array($_GET['ids'])) {
			if($_GET['optype'] == 'delete') {
				C::t('#qu_creditpage#qu_creditpage')->delete($_GET['ids']);
			}
		}
		cpmsg('update_succeed', 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier=qu_creditpage&pmod=manage', 'succeed');

	}

} elseif($_GET['ac'] == 'add') {

	if(!submitcheck('addsubmit')) {

		showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier=qu_creditpage&pmod=manage&ac=add', 'enctype');
		showtableheader();
		showsetting('title', 'title', '', 'text');
		showsetting('descript', 'descript', '', 'textarea','','',$lang['dtip']);
		showsetting('aorder', 'aorder', '0', 'text');
		showsetting('url', 'url', '', 'text','','',$lang['linktip']);
        showsetting('btntxt', 'btntxt', $lang['btntxtvalue'], 'text');
		showsetting('acolor', 'acolor', '', 'color');
		showsubmit('addsubmit', 'submit');
		showtablefooter(); /*Dism·taobao·com*/
		showformfooter(); /*Dism_taobao_com*/

	} else {

		if(!$_GET['title']) {
			cpmsg('titleerror', '', 'error');
		}

		$data = array(
			'title' => daddslashes($_GET['title']),
			'descript' => $_GET['descript'],
            'btntxt' => daddslashes($_GET['btntxt']),
			'url' => $_GET['url'],
			'aorder' => intval($_GET['aorder']),
			'acolor' => $_GET['acolor'],
            'status' => 1,
		);
		$id = C::t('#qu_creditpage#qu_creditpage')->insert($data, true);
		cpmsg('add_succeed', 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier=qu_creditpage&pmod=manage', 'succeed');
	}

} elseif($_GET['ac'] == 'edit') {

	$creditPage = C::t('#qu_creditpage#qu_creditpage')->fetch($_GET['id']);
	if(empty($creditPage)) {
		cpmsg('nonexistence', '', 'error');
	}

	if(!submitcheck('editsubmit')) {
		showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier=qu_creditpage&pmod=manage&ac=edit&id='.$creditPage['id'], 'enctype');
		showtableheader();
		showsetting('title', 'title', $creditPage['title'], 'text');
		showsetting('descript', 'descript', $creditPage['descript'], 'textarea','','',$lang['dtip']);
		showsetting('aorder', 'aorder', $creditPage['aorder'], 'text');
		showsetting('acolor', 'acolor', $creditPage['acolor'], 'color');
		showsetting('url', 'url', $creditPage['url'], 'text','','',$lang['linktip']);
        showsetting('btntxt', 'btntxt', $creditPage['btntxt'], 'text');
		showsetting('status', 'status', $creditPage['status'], 'radio');
		showsubmit('editsubmit', 'submit');
		showtablefooter(); /*Dism·taobao·com*/
		showformfooter(); /*Dism_taobao_com*/

	} else {

		if(!$_GET['title']) {
			cpmsg('titleerror', '', 'error');
		}


		$data = array(
            'title' => daddslashes($_GET['title']),
            'descript' => $_GET['descript'],
            'btntxt' => daddslashes($_GET['btntxt']),
            'url' => $_GET['url'],
            'aorder' => intval($_GET['aorder']),
            'acolor' => $_GET['acolor'],
            'status' => intval($_GET['status']),
		);
		C::t('#qu_creditpage#qu_creditpage')->update($creditPage['id'], $data);

		cpmsg('edit_succeed', 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier=qu_creditpage&pmod=manage', 'succeed');
	}

}
//From: Dism_taobao-com
?>