<?php

/**
 * 论坛获取积分引导页
 * 官方网址 https://dism.taobao.com/?@qu
 * 官方DISM.TAOBAO.COM
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

DROP TABLE IF EXISTS `pre_qu_creditpage`;
CREATE TABLE `pre_qu_creditpage` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `descript` varchar(255) NOT NULL,
  `btntxt` varchar(20) NOT NULL,
  `url` varchar(100) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `aorder` smallint(2) NOT NULL,
  `acolor` char(8) NOT NULL,
  PRIMARY KEY (`id`)
) TYPE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE; /*dism·taobao·com*/

?>