<?php

/**
 * 论坛获取积分引导页
 * 官方网址 https://dism.taobao.com/?@qu
 * 官方DISM.TAOBAO.COM
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$langvars = lang('plugin/qu_creditpage');
$vars = $_G['cache']['plugin']['qu_creditpage'];
$navtitle = $vars['navtitle'];
$data =  DB::fetch_all('SELECT * FROM %t WHERE status=%d ORDER BY aorder ASC', array('qu_creditpage',1));
if(strpos($_SERVER["HTTP_USER_AGENT"],'MAGAPPX') !== false){
    $magapp = 1;
}else{
    $magapp = 0;
}
include template('qu_creditpage:page');
?>