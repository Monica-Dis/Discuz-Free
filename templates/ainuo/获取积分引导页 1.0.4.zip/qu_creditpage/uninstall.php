<?php

/**
 * 论坛获取积分引导页
 * 官方网址 https://dism.taobao.com/?@qu
 * 官方DISM.TAOBAO.COM
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_qu_creditpage`;
EOF;
runquery($sql);
$finish = TRUE; /*dism·taobao·com*/
?>