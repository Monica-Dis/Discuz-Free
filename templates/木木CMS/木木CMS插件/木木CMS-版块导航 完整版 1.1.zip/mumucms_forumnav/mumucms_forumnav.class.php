<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_mumucms_forumnav {
	public function global_nav_extra() {
		global $_G;
		$mumucms_forumnav_qiyong = $_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_qiyong'];
		$mumucms_forumnav_forumxs = unserialize($_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_forumxs']);
		$mumucms_forumnav_title = $_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_title'];
		$mumucms_forumnav_width = $_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_width'];
		$mumucms_forumnav_webwidth = $_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_webwidth'];
		$mumucms_forumnav_djuli = $_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_djuli'];
		$mumucms_forumnav_closexs = $_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_closexs'];
		$mumucms_forumnav_closetit = $_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_closetit'];
		$mumucms_forumnav_responsive = $_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_responsive'];

		$mumucms_forumnav_margin_width = $mumucms_forumnav_webwidth / 2 + 14;

		$mumucms_forumnav_xspage = unserialize($_G['cache']['plugin']['mumucms_forumnav']['mumucms_forumnav_xspage']);		
		if(!in_array(1, $mumucms_forumnav_xspage)) {
            if(CURSCRIPT == 'portal' && CURMODULE == 'index' && !in_array(2, $mumucms_forumnav_xspage)) {
                return '';           
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'index' && !in_array(3, $mumucms_forumnav_xspage)) {
                return '';
			} elseif(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && !in_array(4, $mumucms_forumnav_xspage)) {
                return '';				
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && !in_array(5, $mumucms_forumnav_xspage)) {
                return '';
            }elseif(!(CURSCRIPT == 'forum' && in_array(CURMODULE, array('index', 'forumdisplay', 'viewthread'))) && !(CURSCRIPT == 'portal' && in_array(CURMODULE, array('index'))) && !in_array(6, $page_name)) {
                return '';
            }
        }
        if(CURSCRIPT == 'member') {
                return ''; 
		 }
		loadcache('forums');//获取所有版块
		foreach($_G['cache']['forums'] as $forum) {
			if(!$forum['status']) {
				continue;
			}
			if(in_array(0, $mumucms_forumnav_forumxs) || in_array($forum['fid'], $mumucms_forumnav_forumxs)) {
				$forumlist[] = $forum;
			}
		}

		include template("mumucms_forumnav:mumucms_forumnav_index");
		return $return;
	}
}
//From: Dism·taobao·com
?>