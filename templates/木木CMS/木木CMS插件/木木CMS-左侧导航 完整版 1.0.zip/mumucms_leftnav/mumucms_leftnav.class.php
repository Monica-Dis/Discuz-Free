<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_mumucms_leftnav {
	public function global_footer() {
		global $_G;
		$mumucms_leftnav_qiyong = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_qiyong'];
		$mumucms_leftnav_zhankai = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_zhankai'];
		$mumucms_leftnav_jquery = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_jquery'];	
		$mumucms_leftnav_target = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_target'];			
		$mumucms_leftnav_bgcolor = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_bgcolor'];	
		$mumucms_leftnav_glcolor = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_glcolor'];	
		$mumucms_leftnav_closecolor = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_closecolor'];	
		$mumucms_leftnav_fontcolor = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_fontcolor'];	
		$mumucms_leftnav_navimage1 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navimage1'];	
		$mumucms_leftnav_navfont1 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navfont1'];
		$mumucms_leftnav_navlink1 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navlink1'];
		$mumucms_leftnav_navimage2 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navimage2'];	
		$mumucms_leftnav_navfont2 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navfont2'];	
		$mumucms_leftnav_navlink2 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navlink2'];
		$mumucms_leftnav_navimage3 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navimage3'];	
		$mumucms_leftnav_navfont3 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navfont3'];
		$mumucms_leftnav_navlink3 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navlink3'];
		$mumucms_leftnav_navimage4 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navimage4'];	
		$mumucms_leftnav_navfont4 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navfont4'];
		$mumucms_leftnav_navlink4 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navlink4'];
		$mumucms_leftnav_navimage5 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navimage5'];	
		$mumucms_leftnav_navfont5 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navfont5'];
		$mumucms_leftnav_navlink5 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navlink5'];
		$mumucms_leftnav_navimage6 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navimage6'];	
		$mumucms_leftnav_navfont6 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navfont6'];
		$mumucms_leftnav_navlink6 = $_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_navlink6'];
		
		$mumucms_leftnav_xspage = unserialize($_G['cache']['plugin']['mumucms_leftnav']['mumucms_leftnav_xspage']);		
		if(!in_array(1, $mumucms_leftnav_xspage)) {
            if(CURSCRIPT == 'portal' && CURMODULE == 'index' && !in_array(2, $mumucms_leftnav_xspage)) {
                return '';           
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'index' && !in_array(3, $mumucms_leftnav_xspage)) {
                return '';
			} elseif(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && !in_array(4, $mumucms_leftnav_xspage)) {
                return '';				
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && !in_array(5, $mumucms_leftnav_xspage)) {
                return '';
            }elseif(!(CURSCRIPT == 'forum' && in_array(CURMODULE, array('index', 'forumdisplay', 'viewthread'))) && !(CURSCRIPT == 'portal' && in_array(CURMODULE, array('index'))) && !in_array(6, $page_name)) {
                return '';
            }
        }
		
		include template("mumucms_leftnav:mumucms_leftnav_index");
		return $return;
	}
}
//From: Dism��taobao��com
?>