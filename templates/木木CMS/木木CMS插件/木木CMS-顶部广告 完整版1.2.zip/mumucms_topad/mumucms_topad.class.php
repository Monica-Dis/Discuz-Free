<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_mumucms_topad {
	
	public function global_footer() {
		global $_G;
		$mumucms_topad_qiyong = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_qiyong'];
		$mumucms_topad_zkadimg = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_zkadimg'];
		$mumucms_topad_ztwidth = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_ztwidth'];	
		$mumucms_topad_jquery = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_jquery'];		
		$mumucms_topad_adlink = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_adlink'];
		$mumucms_topad_newwin = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_newwin'];
		$mumucms_topad_zkheight = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_zkheight'];
		$mumucms_topad_ssheight = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_ssheight'];
		$mumucms_topad_zktime = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_zktime'];
		$mumucms_topad_responsive = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_responsive'];				
		$mumucms_topad_zktext = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_zktext'];
		$mumucms_topad_sstext = $_G['cache']['plugin']['mumucms_topad']['mumucms_topad_sstext'];

		$mumucms_topad_adpage = unserialize($_G['cache']['plugin']['mumucms_topad']['mumucms_topad_adpage']);		
		if(!in_array(1, $mumucms_topad_adpage)) {
            if(CURSCRIPT == 'portal' && CURMODULE == 'index' && !in_array(2, $mumucms_topad_adpage)) {
                return '';           
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'index' && !in_array(3, $mumucms_topad_adpage)) {
                return '';
			} elseif(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && !in_array(4, $mumucms_topad_adpage)) {
                return '';				
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && !in_array(5, $mumucms_topad_adpage)) {
                return '';
            }elseif(!(CURSCRIPT == 'forum' && in_array(CURMODULE, array('index', 'forumdisplay', 'viewthread'))) && !(CURSCRIPT == 'portal' && in_array(CURMODULE, array('index'))) && !in_array(6, $page_name)) {
                return '';
            }
        }
        if(CURSCRIPT == 'member') {
                return ''; 
		 }
		include template("mumucms_topad:mumucms_topad_index");
		return $return;
	}
}
//From: Dism��taobao��com
?>