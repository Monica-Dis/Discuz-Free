<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_mumucms_disclaimer {

}

class plugin_mumucms_disclaimer_forum extends plugin_mumucms_disclaimer {

	public function viewthread_mumucms_donate () {
		global $_G;
		$mumucms_disclaimer_qiyong = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_qiyong'];
		$mumucms_disclaimer_responsive = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_responsive'];
		$mumucms_disclaimer_xsmk = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_xsmk'];
		$mumucms_disclaimer_mingcheng = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_mingcheng'];
		$mumucms_disclaimer_content = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_content'];	
		include template("mumucms_disclaimer:mumucms_disclaimer_index");
		if($mumucms_disclaimer_xsmk==2 or $mumucms_disclaimer_xsmk==3) return $return;
	}
}

class plugin_mumucms_disclaimer_portal extends plugin_mumucms_disclaimer {

	public function view_mumucms_donate () {
		global $_G;
		$mumucms_disclaimer_qiyong = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_qiyong'];
		$mumucms_disclaimer_responsive = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_responsive'];
		$mumucms_disclaimer_xsmk = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_xsmk'];
		$mumucms_disclaimer_mingcheng = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_mingcheng'];
		$mumucms_disclaimer_content = $_G['cache']['plugin']['mumucms_disclaimer']['mumucms_disclaimer_content'];	
		include template("mumucms_disclaimer:mumucms_disclaimer_index");
		if($mumucms_disclaimer_xsmk==1 or $mumucms_disclaimer_xsmk==3) return $return;
	}
}
//From: Dism��taobao��com
?>