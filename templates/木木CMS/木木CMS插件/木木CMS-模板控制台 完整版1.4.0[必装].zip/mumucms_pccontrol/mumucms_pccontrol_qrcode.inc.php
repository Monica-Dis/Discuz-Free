<?php

/**


 */

require_once(DISCUZ_ROOT.'source/plugin/mumucms_pccontrol/function/function_phpqrcode.php');

if(!defined('IN_DISCUZ')) {

	exit('Access Denied');

}

//获取二维码内容，获取的值为空就生成网站首页的二维码
if (empty($_GET['value'])) {

	$value = $_G['siteurl'];

}
else {

	$value = $_GET['value'];
}

//判断获取的value值是否带带http(s),是否可以打开
$url = "/^http(s)?:\\/\\/.+/";
if(preg_match($url,$value)){
  
   if (!empty($_GET['tid'])) {

    	$value = $_GET['value'].'&tid='.$_GET['tid'];
	}
	elseif (!empty($_GET['aid'])) {

	    $value = $_GET['value'].'&aid='.$_GET['aid'];
	}

}
elseif (!empty($_GET['tid'])) {

    $value = $_G['siteurl'].'/'.$_GET['value'].'&tid='.$_GET['tid'];
    
}
elseif (!empty($_GET['aid'])) {

    $value = $_G['siteurl'].'/'.$_GET['value'].'&aid='.$_GET['aid'];
}

//容错级别 
$errorCorrectionLevel = 'L';

//生成图片大小 
$matrixPointSize = 10;

//生成二维码图片 
QRcode::png($value, 'qrcode.png', $errorCorrectionLevel, $matrixPointSize, 0); 

//输出二维码图片 
//echo '<img src="qrcode.png">';
$QR = 'qrcode.png';//已经生成的原始二维码图
 
$QR = imagecreatefromstring(file_get_contents($QR)); 

Header("Content-type: image/png");
ImagePng($QR);




?>