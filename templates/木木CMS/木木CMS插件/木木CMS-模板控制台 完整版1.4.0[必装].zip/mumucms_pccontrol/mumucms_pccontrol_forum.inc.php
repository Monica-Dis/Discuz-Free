<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$langs = lang('plugin/mumucms_pccontrol');
if(!submitcheck('submit')){
	require_once libfile('function/cache');
	loadcache('mumucms_forum');
	$cache =$_G['cache']['mumucms_forum'];
	include_once libfile('function/forumlist');

	$mumucms_pccontrol_forumlistside = '<select name="forumlistside[]" multiple="multiple" size="10"><option value="0"'.(in_array(0, $cache['mumucms_pccontrol_forumlistside']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>'.forumselect(FALSE, 0, $cache['mumucms_pccontrol_forumlistside'], TRUE).'</select>';


	$mumucms_pccontrol_forumviewside = '<select name="forumviewside[]" multiple="multiple" size="10"><option value="0"'.(in_array(0, $cache['mumucms_pccontrol_forumviewside']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>'.forumselect(FALSE, 0, $cache['mumucms_pccontrol_forumviewside'], TRUE).'</select>';

	$mumucms_forum_tieba = '<select name="tieba[]" multiple="multiple" size="10"><option value="0"'.(in_array(0, $cache['mumucms_forum_tieba']) ? ' selected' : '').'>'.cplang('plugins_empty').'</option>'.forumselect(FALSE, 0, $cache['mumucms_forum_tieba'], TRUE).'</select>';

	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=mumucms_pccontrol&pmod=mumucms_pccontrol_forum');
	showtableheader(lang('plugin/mumucms_pccontrol', 'setting'));
	showsetting($langs['mumucms_pccontrol_forumsige'],'mumucms_pccontrol_forumsige',$cache['mumucms_pccontrol_forumsige'],'radio');
	showsetting($langs['mumucms_pccontrol_forumindexside'],'mumucms_pccontrol_forumindexside',$cache['mumucms_pccontrol_forumindexside'],'radio');
	showsetting($langs['mumucms_pccontrol_forumlistside'], '', '', $mumucms_pccontrol_forumlistside);		
	showsetting($langs['mumucms_pccontrol_forumviewside'], '', '', $mumucms_pccontrol_forumviewside);
	showsetting($langs['mumucms_pccontrol_viewxuanfu'],'mumucms_pccontrol_viewxuanfu',$cache['mumucms_pccontrol_viewxuanfu'],'radio');
	showsetting($langs['mumucms_forum_tieba'], '', '', $mumucms_forum_tieba);
	showsubmit('submit');	
	showtablefooter();/*Dism_taobao-com*/
	showformfooter();/*Dism��taobao��com*/

}else{
	function build_cache_mumucms_forum(){ 
	    $data = array();
	    $data['mumucms_pccontrol_forumsige'] = $_GET['mumucms_pccontrol_forumsige'];
	    $data['mumucms_pccontrol_forumindexside'] = $_GET['mumucms_pccontrol_forumindexside'];   
	    $data['mumucms_pccontrol_forumlistside'] = $_GET['forumlistside'];	    
	    $data['mumucms_pccontrol_forumviewside'] = $_GET['forumviewside'];
		$data['mumucms_pccontrol_viewxuanfu'] = $_GET['mumucms_pccontrol_viewxuanfu'];   
	    $data['mumucms_forum_tieba'] = $_GET['tieba'];
	    save_syscache('mumucms_forum', $data);
	}
	updatecache('mumucms_forum');
	cpmsg('tasks_installed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=mumucms_pccontrol&pmod=mumucms_pccontrol_forum', 'succeed');
}
//From: dis'.'m.tao'.'bao.com
?>