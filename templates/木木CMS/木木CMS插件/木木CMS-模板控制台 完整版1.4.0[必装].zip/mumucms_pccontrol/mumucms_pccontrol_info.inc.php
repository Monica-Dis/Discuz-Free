<?php
/**
 * 
 * DisM!出品 必属精品
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

//获取语言包
$langs = lang('plugin/mumucms_pccontrol');

//获取普通分类信息ID和名称
$mumucms_sort = DB::query("SELECT * FROM ".DB::table('forum_threadtype')." order by displayorder" );
$mumucms_sortid= array();
$mumucms_sortid[]=array(0,$langs['mumucms_nochoose'],);
while($row = DB::fetch($mumucms_sort)) {
	$mumucms_sortid[]=array($row["typeid"],$row["name"]);
}

//获取高级分类信息ID和名称
$mumucms_gjsort = DB::query("SELECT * FROM ".DB::table('forum_threadtype')." order by displayorder" );
$mumucms_gjsortid= array();
$mumucms_gjsortid[]=array(0,$langs['mumucms_gaoji_bukaiqi'],);
while($row = DB::fetch($mumucms_gjsort)) {
	$mumucms_gjsortid[]=array($row["typeid"],$row["name"]);
}

//获取所有版块
loadcache('forums');
$mumucms_fid= array();
$mumucms_fid[]=array(0,$langs['mumucms_nochoose'],);
foreach($_G['cache']['forums'] as $fid => $forum) {//遍历版块
		$mumucms_fid[] = array($fid, ($forum['type'] == 'forum' ? str_repeat('', 4) : ($forum['type'] == 'sub' ? str_repeat('', 4) : '')).$forum['name']);
	}

//表单
if(!submitcheck('submit')){
	require_once libfile('function/cache');
	loadcache('mumucms_info');
	$cache =$_G['cache']['mumucms_info'];

	showformheader('plugins&operation=config&do='.$pluginid.'&identifier=mumucms_pccontrol&pmod=mumucms_pccontrol_info');
	showtableheader(lang('plugin/mumucms_pccontrol', 'setting'));
	showsetting($langs['mumucms_gaoji_sortid'],array('mumucms_gaoji_sortid[]',$mumucms_gjsortid),$cache['mumucms_gaoji_sortid'],'mselect','','',$langs['mumucms_gaoji_sortid_jieshao']);
	showsetting($langs['mumucms_fwcz_sortid'],array('mumucms_fwcz_sortid',$mumucms_sortid),$cache['mumucms_fwcz_sortid'],'select');
	showsetting($langs['mumucms_fwcz_fid'],array('mumucms_fwcz_fid',$mumucms_fid),$cache['mumucms_fwcz_fid'],'select');
	showsetting($langs['mumucms_fwcs_sortid'],array('mumucms_fwcs_sortid',$mumucms_sortid),$cache['mumucms_fwcs_sortid'],'select');
	showsetting($langs['mumucms_fwcs_fid'],array('mumucms_fwcs_fid',$mumucms_fid),$cache['mumucms_fwcs_fid'],'select');
	showsetting($langs['mumucms_zxlp_sortid'],array('mumucms_zxlp_sortid',$mumucms_sortid),$cache['mumucms_zxlp_sortid'],'select');
	showsetting($langs['mumucms_zxlp_fid'],array('mumucms_zxlp_fid',$mumucms_fid),$cache['mumucms_zxlp_fid'],'select');
	showsetting($langs['mumucms_qzzp_sortid'],array('mumucms_qzzp_sortid',$mumucms_sortid),$cache['mumucms_qzzp_sortid'],'select');
	showsetting($langs['mumucms_qzzp_fid'],array('mumucms_qzzp_fid',$mumucms_fid),$cache['mumucms_qzzp_fid'],'select');
	showsetting($langs['mumucms_qzxx_sortid'],array('mumucms_qzxx_sortid',$mumucms_sortid),$cache['mumucms_qzxx_sortid'],'select');
	showsetting($langs['mumucms_qzxx_fid'],array('mumucms_qzxx_fid',$mumucms_fid),$cache['mumucms_qzxx_fid'],'select');
	showsetting($langs['mumucms_jzzp_sortid'],array('mumucms_jzzp_sortid',$mumucms_sortid),$cache['mumucms_jzzp_sortid'],'select');
	showsetting($langs['mumucms_jzzp_fid'],array('mumucms_jzzp_fid',$mumucms_fid),$cache['mumucms_jzzp_fid'],'select');
	showsetting($langs['mumucms_kbsj_sortid'],array('mumucms_kbsj_sortid',$mumucms_sortid),$cache['mumucms_kbsj_sortid'],'select');
	showsetting($langs['mumucms_kbsj_fid'],array('mumucms_kbsj_fid',$mumucms_fid),$cache['mumucms_kbsj_fid'],'select');				
	showsetting($langs['mumucms_tzsc_sortid'],array('mumucms_tzsc_sortid',$mumucms_sortid),$cache['mumucms_tzsc_sortid'],'select');
	showsetting($langs['mumucms_tzsc_fid'],array('mumucms_tzsc_fid',$mumucms_fid),$cache['mumucms_tzsc_fid'],'select');
	showsetting($langs['mumucms_jyzx_sortid'],array('mumucms_jyzx_sortid',$mumucms_sortid),$cache['mumucms_jyzx_sortid'],'select');
	showsetting($langs['mumucms_jyzx_fid'],array('mumucms_jyzx_fid',$mumucms_fid),$cache['mumucms_jyzx_fid'],'select');
	showsetting($langs['mumucms_fcjjr_sortid'],array('mumucms_fcjjr_sortid',$mumucms_sortid),$cache['mumucms_fcjjr_sortid'],'select');
	showsetting($langs['mumucms_fcjjr_fid'],array('mumucms_fcjjr_fid',$mumucms_fid),$cache['mumucms_fcjjr_fid'],'select');
	showsetting($langs['mumucms_jnpx_sortid'],array('mumucms_jnpx_sortid',$mumucms_sortid),$cache['mumucms_jnpx_sortid'],'select');
	showsetting($langs['mumucms_jnpx_fid'],array('mumucms_jnpx_fid',$mumucms_fid),$cache['mumucms_jnpx_fid'],'select');
	showsetting($langs['mumucms_jjfd_sortid'],array('mumucms_jjfd_sortid',$mumucms_sortid),$cache['mumucms_jjfd_sortid'],'select');
	showsetting($langs['mumucms_jjfd_fid'],array('mumucms_jjfd_fid',$mumucms_fid),$cache['mumucms_jjfd_fid'],'select');
	showsetting($langs['mumucms_jyjg_sortid'],array('mumucms_jyjg_sortid',$mumucms_sortid),$cache['mumucms_jyjg_sortid'],'select');
	showsetting($langs['mumucms_jyjg_fid'],array('mumucms_jyjg_fid',$mumucms_fid),$cache['mumucms_jyjg_fid'],'select');
	showsetting($langs['mumucms_lxym_sortid'],array('mumucms_lxym_sortid',$mumucms_sortid),$cache['mumucms_lxym_sortid'],'select');
	showsetting($langs['mumucms_lxym_fid'],array('mumucms_lxym_fid',$mumucms_fid),$cache['mumucms_lxym_fid'],'select');	
	showsetting($langs['mumucms_wxsl_sortid'],array('mumucms_wxsl_sortid',$mumucms_sortid),$cache['mumucms_wxsl_sortid'],'select');
	showsetting($langs['mumucms_wxsl_fid'],array('mumucms_wxsl_fid',$mumucms_fid),$cache['mumucms_wxsl_fid'],'select');						
	showsubmit('submit');	
	showtablefooter();/*Dism_taobao-com*/
	showformfooter();/*Dism·taobao·com*/

}else{
	function build_cache_mumucms_info(){ 
	    $data = array();
	    $data['mumucms_gaoji_sortid'] = $_GET['mumucms_gaoji_sortid'];
	    $data['mumucms_fwcz_sortid'] = $_GET['mumucms_fwcz_sortid'];
	    $data['mumucms_fwcz_fid'] = $_GET['mumucms_fwcz_fid'];
	    $data['mumucms_fwcs_sortid'] = $_GET['mumucms_fwcs_sortid'];
	    $data['mumucms_fwcs_fid'] = $_GET['mumucms_fwcs_fid'];
	    $data['mumucms_zxlp_sortid'] = $_GET['mumucms_zxlp_sortid'];
	    $data['mumucms_zxlp_fid'] = $_GET['mumucms_zxlp_fid'];
	    $data['mumucms_qzzp_sortid'] = $_GET['mumucms_qzzp_sortid'];
	    $data['mumucms_qzzp_fid'] = $_GET['mumucms_qzzp_fid'];
	    $data['mumucms_qzxx_sortid'] = $_GET['mumucms_qzxx_sortid'];
	    $data['mumucms_qzxx_fid'] = $_GET['mumucms_qzxx_fid'];
	    $data['mumucms_jzzp_sortid'] = $_GET['mumucms_jzzp_sortid'];
	    $data['mumucms_jzzp_fid'] = $_GET['mumucms_jzzp_fid'];	     
	    $data['mumucms_kbsj_sortid'] = $_GET['mumucms_kbsj_sortid'];
	    $data['mumucms_kbsj_fid'] = $_GET['mumucms_kbsj_fid'];
	    $data['mumucms_tzsc_sortid'] = $_GET['mumucms_tzsc_sortid'];
	    $data['mumucms_tzsc_fid'] = $_GET['mumucms_tzsc_fid'];
	    $data['mumucms_jyzx_sortid'] = $_GET['mumucms_jyzx_sortid'];
	    $data['mumucms_jyzx_fid'] = $_GET['mumucms_jyzx_fid'];
	    $data['mumucms_fcjjr_sortid'] = $_GET['mumucms_fcjjr_sortid'];
	    $data['mumucms_fcjjr_fid'] = $_GET['mumucms_fcjjr_fid'];
	    $data['mumucms_jnpx_sortid'] = $_GET['mumucms_jnpx_sortid'];
	    $data['mumucms_jnpx_fid'] = $_GET['mumucms_jnpx_fid'];
	    $data['mumucms_jjfd_sortid'] = $_GET['mumucms_jjfd_sortid'];
	    $data['mumucms_jjfd_fid'] = $_GET['mumucms_jjfd_fid'];
	    $data['mumucms_jyjg_sortid'] = $_GET['mumucms_jyjg_sortid'];
	    $data['mumucms_jyjg_fid'] = $_GET['mumucms_jyjg_fid'];
	    $data['mumucms_lxym_sortid'] = $_GET['mumucms_lxym_sortid'];
	    $data['mumucms_lxym_fid'] = $_GET['mumucms_lxym_fid'];	
	    $data['mumucms_wxsl_sortid'] = $_GET['mumucms_wxsl_sortid'];
	    $data['mumucms_wxsl_fid'] = $_GET['mumucms_wxsl_fid'];		        	    	    	    	    
	    save_syscache('mumucms_info', $data);
	}
	updatecache('mumucms_info');

	cpmsg('tasks_installed', 'action=plugins&operation=config&do='.$pluginid.'&identifier=mumucms_pccontrol&pmod=mumucms_pccontrol_info', 'succeed');
}
//From: dis'.'m.tao'.'bao.com
?>