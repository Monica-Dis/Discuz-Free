<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_mumucms_scrolltop {
	public function global_footer() {
		global $_G;
		$mumucms_scrolltop_qiyong = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_qiyong'];
		$mumucms_scrolltop_responsive = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_responsive'];
		$mumucms_scrolltop_jquery = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_jquery'];
		$mumucms_scrolltop_width = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_width'];
		$mumucms_scrolltop_qqkf = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_qqkf'];	
		$mumucms_scrolltop_gzhimg = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_gzhimg'];	
		$mumucms_scrolltop_khdimg = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_khdimg'];		
		$mumucms_scrolltop_btn1_ico = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn1_ico'];	
		$mumucms_scrolltop_btn1_text = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn1_text'];	
		$mumucms_scrolltop_btn2_ico = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn2_ico'];	
		$mumucms_scrolltop_btn2_text = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn2_text'];	
		$mumucms_scrolltop_btn3_ico = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn3_ico'];	
		$mumucms_scrolltop_btn3_text = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn3_text'];	
		$mumucms_scrolltop_btn4_ico = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn4_ico'];	
		$mumucms_scrolltop_btn4_text = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn4_text'];	
		$mumucms_scrolltop_btn5_ico = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn5_ico'];	
		$mumucms_scrolltop_btn5_text = $_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_btn5_text'];	

		$mumucms_scrolltop_margin_width = $mumucms_scrolltop_width / 2 + 10;
		
		$mumucms_scrolltop_xspage = unserialize($_G['cache']['plugin']['mumucms_scrolltop']['mumucms_scrolltop_xspage']);		
		if(!in_array(1, $mumucms_scrolltop_xspage)) {
            if(CURSCRIPT == 'portal' && CURMODULE == 'index' && !in_array(2, $mumucms_scrolltop_xspage)) {
                return '';           
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'index' && !in_array(3, $mumucms_scrolltop_xspage)) {
                return '';
			} elseif(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && !in_array(4, $mumucms_scrolltop_xspage)) {
                return '';				
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && !in_array(5, $mumucms_scrolltop_xspage)) {
                return '';
            }elseif(!(CURSCRIPT == 'forum' && in_array(CURMODULE, array('index', 'forumdisplay', 'viewthread'))) && !(CURSCRIPT == 'portal' && in_array(CURMODULE, array('index'))) && !in_array(6, $page_name)) {
                return '';
            }
        }
		
		include template("mumucms_scrolltop:mumucms_scrolltop_index");
		return $return;
	}
}
//From: Dism��taobao��com
?>