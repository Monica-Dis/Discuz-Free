<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_mumucms_subnav {
	public function global_header() {
		global $_G;
		$mumucms_subnav_qiyong = $_G['cache']['plugin']['mumucms_subnav']['mumucms_subnav_qiyong'];
		$mumucms_subnav_xuanze = $_G['cache']['plugin']['mumucms_subnav']['mumucms_subnav_xuanze'];
		$mumucms_subnav_yangshi1 = $_G['cache']['plugin']['mumucms_subnav']['mumucms_subnav_yangshi1'];	
		$mumucms_subnav_yangshi2 = $_G['cache']['plugin']['mumucms_subnav']['mumucms_subnav_yangshi2'];	
		$mumucms_subnav_qiyongwap = $_G['cache']['plugin']['mumucms_subnav']['mumucms_subnav_qiyongwap'];
		$mumucms_subnav_wapstyle = $_G['cache']['plugin']['mumucms_subnav']['mumucms_subnav_wapstyle'];

		$mumucms_subnav_xspage = unserialize($_G['cache']['plugin']['mumucms_subnav']['mumucms_subnav_xspage']);		
		if(!in_array(1, $mumucms_subnav_xspage)) {
            if(CURSCRIPT == 'portal' && CURMODULE == 'index' && !in_array(2, $mumucms_subnav_xspage)) {
                return '';           
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'index' && !in_array(3, $mumucms_subnav_xspage)) {
                return '';
			} elseif(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && !in_array(4, $mumucms_subnav_xspage)) {
                return '';				
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && !in_array(5, $mumucms_subnav_xspage)) {
                return '';
            }elseif(!(CURSCRIPT == 'forum' && in_array(CURMODULE, array('index', 'forumdisplay', 'viewthread'))) && !(CURSCRIPT == 'portal' && in_array(CURMODULE, array('index'))) && !in_array(6, $page_name)) {
                return '';
            }
        }
		
		include template("mumucms_subnav:mumucms_subnav_index");
		return $return;
	}

}


?>