<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_mumucms_dialog {
	public function global_footer() {
		global $_G;
		$mumucms_dialog_qiyong = $_G['cache']['plugin']['mumucms_dialog']['mumucms_dialog_qiyong'];
		$mumucms_dialog_expire = $_G['cache']['plugin']['mumucms_dialog']['mumucms_dialog_expire'];	
		$mumucms_dialog_title = $_G['cache']['plugin']['mumucms_dialog']['mumucms_dialog_title'];	
		$mumucms_dialog_sum = $_G['cache']['plugin']['mumucms_dialog']['mumucms_dialog_sum'];			
		

		
		$mumucms_dialog_xspage = unserialize($_G['cache']['plugin']['mumucms_dialog']['mumucms_dialog_xspage']);		
		if(!in_array(1, $mumucms_dialog_xspage)) {
            if(CURSCRIPT == 'portal' && CURMODULE == 'index' && !in_array(2, $mumucms_dialog_xspage)) {
                return '';           
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'index' && !in_array(3, $mumucms_dialog_xspage)) {
                return '';
			} elseif(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay' && !in_array(4, $mumucms_dialog_xspage)) {
                return '';				
            } elseif(CURSCRIPT == 'forum' && CURMODULE == 'viewthread' && !in_array(5, $mumucms_dialog_xspage)) {
                return '';
            }elseif(!(CURSCRIPT == 'forum' && in_array(CURMODULE, array('index', 'forumdisplay', 'viewthread'))) && !(CURSCRIPT == 'portal' && in_array(CURMODULE, array('index'))) && !in_array(6, $page_name)) {
                return '';
            }
        }
		
		include template("mumucms_dialog:mumucms_dialog_index");
		return $return;
	}
}
//From: Dism��taobao��com
?>