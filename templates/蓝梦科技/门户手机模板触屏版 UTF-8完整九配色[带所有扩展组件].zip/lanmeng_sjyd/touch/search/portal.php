<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<style>
.lmkj_search {margin:10px 0 0 10px;}
.lmkj_search a{margin:0 5px;}
.lmkj_search .tab {background:#2F96C1;padding:6px 10px;color:#fff;margin:0 5px;}
.threadlist li a {padding:5px;}
</style>
<div class="lmkj_search">���� ��<a href="search.php?mod=forum">����</a> <a href="search.php?mod=portal" class="tab" >����</a> </div>

<form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=portal&mobile=2">
			
			<input type="hidden" name="formhash" value="{FORMHASH}" />

		<!--{template search/pubsearch}-->

	</form>
<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
	<div class="threadlist">
	<h2 class="thread_tit"> <!--{if $keyword}-->{lang search_result_keyword} <!--{/if}--> </h2>
	<!--{if empty($articlelist)}-->
	<ul><li><a href="javascript:;">{lang search_nomatch}</a></li></ul>
	<!--{else}-->
			<ul>
				<!--{loop $articlelist $article}-->
				<li>
					<a href="portal.php?mod=view&aid=$article[aid]" >$article[title]</a>
				</li>
				<!--{/loop}--> 
			</ul>
	<!--{/if}-->
	$multipage
</div>

<!--{/if}-->

<!--{template common/footer}-->