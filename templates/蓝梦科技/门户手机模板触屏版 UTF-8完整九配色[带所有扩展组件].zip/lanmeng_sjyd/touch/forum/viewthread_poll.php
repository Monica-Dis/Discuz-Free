<?php echo 'From: DisM.taobao.com';exit;?>
<table cellspacing="0" cellpadding="0"><tr><td class="t_f" id="postmessage_$post[pid]">$post[message]</td></tr></table>
<style>
.pcht{margin-bottom: 15px;}
.polltd{padding: 4px;border: 1px #dfdfdf solid;border-radius: 3px;}
.pcht h4 a{text-decoration: underline;}
.pcht table{table-layout: fixed;}
.pcht table td{padding: 4px;vertical-align: top;}
.pslt{width: 20px;vertical-align: middle !important;}
.pvt{width: auto;}
.pvt label{cursor: pointer;}
.pvts{width: 100px;}
.pcht table tr.ptl td{padding: 8px 2px;border-bottom: 1px solid{WRAPBORDERCOLOR};}
.pcht{width: 100%;}
.pinf{margin: 15px 0;}
.ptmr{margin: -10px 0 15px;}
.imgf2{position: relative;height: 20px;background: #e9e9e9;border-radius: 0 10px 10px 0;}
.jdt{display: block;width: 1px;height: 20px;background: #f2a61f;border-radius: 0 10px 10px 0;}
.imgfc{position: absolute;left: 0;top: 0;padding: 0 5%;width: 90%;line-height: 20px;}
.pbr{height: 16px;width: 100%;background-color: #5AAF4A;background-position: 0 -16px;background-repeat: repeat-x;-webkit-border-radius: 0 6px 6px 0;-moz-border-radius: 0 6px 6px 0;border-radius: 0 6px 6px 0;}
</style>
<script type="text/javascript">
<!--{if $optiontype=='checkbox'}-->
	var max_obj = $maxchoices;
	var p = 0;
<!--{/if}-->
</script>

<form id="poll" name="poll" method="post" autocomplete="off" action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes" onsubmit="if($('post_$post[pid]')) {ajaxpost('poll', 'post_$post[pid]', 'post_$post[pid]');return false}">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="pinf">
		<!--{if $multiple}--><strong>{lang poll_multiple}{lang thread_poll}</strong><!--{if $maxchoices}-->: ( {lang poll_more_than} )<!--{/if}--><!--{else}--><strong>{lang poll_single}{lang thread_poll}</strong><!--{/if}--><!--{if $visiblepoll && $_G['group']['allowvote']}--> , {lang poll_after_result}<!--{/if}-->, {lang poll_voterscount}
		<!--{if !$visiblepoll && ($overt || $_G['adminid'] == 1 || $thread['authorid'] == $_G['uid']) && $post['invisible'] == 0}-->
			<a href="forum.php?mod=misc&action=viewvote&tid=$_G[tid]" onclick="showWindow('viewvote', this.href)">{lang poll_view_voters}</a>
		<!--{/if}-->
	</div>

	<!--{hook/viewthread_poll_top}-->

	<!--{if $_G[forum_thread][remaintime]}-->
	<p class="ptmr">
		{lang poll_count_down}:
		<strong>
		<!--{if $_G[forum_thread][remaintime][0]}-->$_G[forum_thread][remaintime][0] {lang days}<!--{/if}-->
		<!--{if $_G[forum_thread][remaintime][1]}-->$_G[forum_thread][remaintime][1] {lang poll_hour}<!--{/if}-->
		$_G[forum_thread][remaintime][2] {lang poll_minute}
		</strong>
	</p>
	<!--{elseif $expiration && $expirations < TIMESTAMP}-->
	<p class="ptmr"><strong>{lang poll_end}</strong></p>
	<!--{/if}-->

	<div class="pcht">

		<table summary="poll panel" cellspacing="0" cellpadding="0" width="100%">
			<!--{if $isimagepoll}-->
				<!--{eval $i = 0;}-->
				<tr>
					<!--{loop $polloptions $key $option}-->
					<!--{eval $i++;}-->
					<!--{eval $imginfo=$option['imginfo'];}-->
					
					<td valign="bottom" id="polloption_$option[polloptionid]" width="100%">
						<div class="polltd cl">
							<!--{if $imginfo}-->
							<a href="javascript:;" title="$imginfo[filename]" >
								<img id="aimg_$imginfo[aid]" aid="$imginfo[aid]" src="$imginfo[small]" width="100%" onclick="zoom(this, this.getAttribute('zoomfile'), 0, 0, '{$_G[setting][showexif]}')" zoomfile="$imginfo[big]" alt="$imginfo[filename]" title="$imginfo[filename]" w="$imginfo[width]" />
							</a>
							<!--{else}-->
							<a href="javascript:;" title=""><img src="{IMGDIR}/nophoto.gif" width="100%" /></a>
							<!--{/if}-->
							<p class="mtn mbn xi2">
								<!--{if $_G['group']['allowvote']}-->
									<label><input class="pr" type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if} {if $optiontype=='checkbox'}onclick="poll_checkbox(this)"{else}onclick="$('pollsubmit').disabled = false"{/if} /></label>
								<!--{/if}-->
								$option[polloption]
							</p>
							<!--{if !$visiblepoll}-->
							<div class="imgf imgf2">
								<span class="jdt" style="width: $option[width]; background-color:#$option[color]">&nbsp;</span>
								<p class="imgfc">
									<span class="z">$option[votes]{lang debate_poll}</span>
									<span class="y">{$option[percent]}% </span>
								</p>
							</div>
							<!--{/if}-->
						</div>
					</td>
					<!--{if $key % 2 == 0 && isset($polloptions[$key])}--></tr><tr><!--{/if}-->
					<!--{/loop}-->
					<!--{if ($imgpad = $key % 4) > 0}--><!--{echo str_repeat('<td width="50%"></td>', 2 - $imgpad);}--><!--{/if}-->
				</tr>
			
			<!--{else}-->
				<!--{loop $polloptions $key $option}-->
					<tr{if $visiblepoll} class="ptl"{/if}>
						<!--{if $_G['group']['allowvote']}-->
							<td class="pslt"><input class="pr" type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if} {if $optiontype=='checkbox'}onclick="poll_checkbox(this)"{else}onclick="$('pollsubmit').disabled = false"{/if} /></td>
						<!--{/if}-->
						<td class="pvt">
							<label for="option_$key">$key. &nbsp;$option[polloption]</label>
						</td>
						<td class="pvts"></td>
					</tr>
	
					<!--{if !$visiblepoll}-->
						<tr>
							<!--{if $_G['group']['allowvote']}-->
								<td>&nbsp;</td>
							<!--{/if}-->
							<td>
								<div class="pbg">
									<div class="pbr" style="width: $option[width]; background-color:#$option[color]"></div>
								</div>
							</td>
							<td>$option[percent]% <em style="color:#$option[color]">($option[votes])</em></td>
						</tr>
					<!--{/if}-->
				<!--{/loop}-->
			
			<!--{/if}-->
			
			<tr>
				<!--{if $_G['group']['allowvote']}-->	<div style="clear:both;margin-top:20px;"></div><!--{/if}-->
				<td colspan="{if $isimagepoll}4{else}2{/if}">
					<!--{hook/viewthread_poll_bottom}-->
				
					<!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
						  <input type="submit" name="pollsubmit" id="pollsubmit" value="{lang submit}" style="padding:5px 15px; display: inline-block;background: #FF5722;color: #fff;"/>  
						<!--{if $overt}-->
							({lang poll_msg_overt})
						<!--{/if}-->
					 <!--{elseif !$allwvoteusergroup}-->
            <!--{if !$_G['uid']}-->
            <span class="xi1">{lang poll_msg_allwvote_user}</span>
            <!--{else}-->
            <span class="xi1">{lang poll_msg_allwvoteusergroup}</span>
            <!--{/if}-->
        <!--{elseif !$allowvotepolled}-->
            <span class="xi1">{lang poll_msg_allowvotepolled}</span>
        <!--{elseif !$allowvotethread}-->
            <span class="xi1">{lang poll_msg_allowvotethread}</span>
        <!--{/if}-->
				</td>
				
				
				
				
       
		
		
		
			</tr>
		</table>
		
	</div>
</form>
