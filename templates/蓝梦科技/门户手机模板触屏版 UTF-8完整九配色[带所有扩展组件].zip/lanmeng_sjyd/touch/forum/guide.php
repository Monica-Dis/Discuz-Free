<?php echo 'From: DisM.taobao.com';exit;?>
<!-- header start -->
<!--{template common/header}-->
<!-- header end --> 
<!-- main threadlist start -->
<div class="threadlist" style="margin:0 2px;">
  
  <!--{loop $data $key $list}--> 
  <!--{subtemplate forum/guide_list_row}--> 
  <!--{/loop}--> 
  
</div>
<!-- main threadlist end --> 

$multipage
<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}--> 
