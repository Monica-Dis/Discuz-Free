<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $list['threadcount']}-->

<ul class="hotlist">
  <!--{loop $list['threadlist'] $key $thread}-->
 <div class="threadlist lmkj_lists">
          <ul>
            <li> 
			 <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="a">
			 <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--> 
              <span class="icon_top">�ö�</span> 
              <!--{elseif $thread['digest'] > 0}--> 
              <span class="icon_jh">����</span> 
              <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}--> 
              <span class="icon_tu">ͼ��</span>
			    <!--{/loop}-->
			  {$thread[subject]}
              <div id="reading"><em>$thread[author]</em> - <em>$thread[lastpost] </em><span class="fangwen"><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></span><span class="huifu">{$thread[replies]}</span></div>
              </a> 
              
               </li>
            
          
            
          </ul>
        </div>
  <!--{/loop}-->
</ul>
<!--{else}-->
<p>{lang guide_nothreads}</p>
<!--{/if}--> 


