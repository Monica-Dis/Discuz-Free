<?php echo 'From: DisM.taobao.com';exit;?>
<a name="comment_anchor_$comment[cid]"></a>
<dl id="comment_{$comment[cid]}_li" class="ptm pbm bbda cl lmkj_pkq">
	<dt class="lmkj_mbm">
		
	<!--{if !empty($comment['uid'])}-->
		<a href="home.php?mod=space&uid=$_G[uid]"><!--{avatar($_G[uid],small)}--></a>
		<span><a href="home.php?mod=space&uid=$_G[uid]">{$_G[member][username]}</a></span>
	<!--{else}-->
		{lang guest}
	<!--{/if}-->
		<span class="lmkj_xg1 xw0"><!--{date($comment[dateline])}--></span>
	<!--{if $comment[status] == 1}--><b>({lang moderate_need})</b><!--{/if}-->
	</dt>
	<dd><!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->$comment[message]<!--{else}--> {lang moderate_not_validate}<!--{/if}--></dd>
</dl>