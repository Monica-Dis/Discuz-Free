<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template common/header_nav}-->
<script src="{$_G['siteurl']}template/lanmeng_sjyd/touch/mobile/common.js?{VERHASH}" charset="{CHARSET}"></script>
<div id="pt" class="cl lmkj_pt">
	<div class="z">
		<a href="{$_G['siteurl']}" title="{lang homepage}">{lang homepage}</a><em>&rsaquo;</em>
		<!--{loop $cat[ups] $value}--> <a href="{$portalcategory[$value['catid']]['caturl']}">$value[catname]</a><em>&rsaquo;</em><!--{/loop}-->
		$cat[catname]
	</div>
</div>


<!--{ad/portal_top_mobile}-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->


<div id="ct" class="ct2 wp cl">
	<div class="mn">
		
		<div class="lmkj_bm_h cl">
	<h1 class="xs2">
				<!--{if $cat[others]}-->
				Ƶ������ ��
				<!--{loop $cat[others] $value}-->
					 <a href="{$portalcategory[$value['catid']]['caturl']}"> $value[catname] </a>
					<!--{/loop}-->
				<!--{/if}-->
					
				
				<!--{if $cat[subs]}-->
		
				{lang sub_category}:&nbsp;&nbsp;
				<!--{eval $i = 1;}-->
				<!--{loop $cat[subs] $value}-->
				<!--{if $i != 1}--><!--{/if}--><a href="{$portalcategory[$value['catid']]['caturl']}">$value[catname]</a><!--{eval $i--;}-->
				<!--{/loop}-->
		
			<!--{/if}-->
				</h1>
			</div>
			
			
				<div style="clear:both"></div>
		<div class="lmkj_bm">
			
	
				
			<ul class="lmkj_bm_c xld">
			<!--{loop $list['list'] $value}-->
				<!--{eval $highlight = article_title_style($value);}-->
				<!--{eval $article_url = fetch_article_url($value);}-->
				<li>
				<a href="{$_G['siteurl']}$article_url" class="xi2" >
				<div class="lmkj_ul cl">
				
					<div class="lmkj_h2"><h2>$value[title]</h2></div>
				
					<!--{if $value[pic]}--><div class="lmkj_atc"><img src="{$_G['siteurl']}$value[pic]" alt="$value[title]" /></div><!--{/if}-->
           	<p class="lmkj_xs2"> $value[summary] </p>
						<div class="lmkj_ss">
						<!--{if $value[catname] && $cat[subs]}-->{lang category}: <a href="{$_G['siteurl']}$article_url" class="xi2">$value[catname]</a><!--{/if}-->
						<span class="xg1"> ����ʱ�� : $value[dateline]</span>
						
					</div>
					</div>	
		</a> 	
		</li>
		<!--{/loop}-->
			</ul>
			
			
			
			
			
		</div>
	
	<!--{if $list['multi']}--><div class="pgs cl">{$list['multi']}</div><!--{/if}-->

	

	</div>

</div>


<script>
$(document).ready(function(){$("#select_a").css("background-image","url({$_G['siteurl']}static/image/mobile/images/pic_select.png)");	}); 
</script>



<!--{ad/portal_bottom_mobile}-->
<!--{template common/footer}-->