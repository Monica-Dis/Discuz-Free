<?php echo 'From: DisM.taobao.com';exit;?>
<a href="javascript:;" title="{lang scrolltop}" class="scrolltop bottom"></a> 
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

<script src="{$_G['siteurl']}template/lanmeng_sjyd/touch/lmkj_tu.min.js"></script>
<script type="text/javascript">

TouchSlide({ 
	slideCell:"#slideBox",
	titCell:".hd ul", //�����Զ���ҳ autoPage:true ����ʱ���� titCell Ϊ����Ԫ�ذ�����
	mainCell:".bd ul", 
	effect:"leftLoop", 
	autoPage:true,//�Զ���ҳ
	autoPlay:true //�Զ�����
});
$(".hd ul li").html("<i></i>");

//ȫ�������ռ�
var GLOBAL={};
//���������ռ亯��
GLOBAL.namespace=function(str){
    var arr=str.split("."),o=GLOBAL;
    for(i=(arr[0]=="GLOBAL")?1:0;i<arr.length;i++){
        o[arr[i]]=o[arr[i]] || {};
        o=o[arr[i]];
    }
}

$(document).ready(function(){
	$("#lmkj_dh_more").click(function(){
		$(".lmkj_dh").css("height","120px");
		$("#nav_more").show();
		$("#lmkj_dh_more").hide();
	});
	$("#lmkj_dh_back").click(function(){
		$(".lmkj_dh").css("height","60px");
		$("#nav_more").hide();
		$("#lmkj_dh_more").show();
	});
	
	var pagenum = '';
	if(pagenum > 1)
	{
		$("#category_more").show();
		$("#category_pic_more").show();
	}
	

});



</script>

<div id="mask" style="display:none;"></div>
<!--{if !$nofooter}-->
<div class="footer">
  <div> 
    <!--{if !$_G[uid] && !$_G['connectguest']}--> 
    <a href="forum.php">{lang mobilehome}</a> | <a href="member.php?mod=logging&action=login" title="{lang login}">{lang login}</a> | <a href="<!--{if $_G['setting']['regstatus']}-->member.php?mod={$_G[setting][regname]}<!--{else}-->javascript:;" style="color:#D7D7D7;<!--{/if}-->" title="{$_G['setting']['reglinkname']}">{lang register}</a> 
    <!--{else}--> 
    <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1">{$_G['member']['username']}</a> , <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" title="{lang logout}" class="dialog">{lang logout}</a> 
    <!--{/if}--> 
  </div>
  <div> <a href="{$_G['setting']['mobile']['simpletypeurl'][0]}">{lang no_simplemobiletype}</a> | <a href="javascript:;" style="color:#0A0A0A;">{lang mobile2version}</a> | <a href="{$_G['setting']['mobile']['nomobileurl']}">{lang nomobiletype}</a> | 
    <!--{if $clienturl}--><a href="$clienturl">{lang clientversion}</a><!--{/if}--> 
  </div>
  <p>&copy; Comsenz Inc.</p>
</div>
<!--{/if}-->


<div class="lmkj_h80"></div>

<div class="lmkj_fts">
<ul>
<li class="a"><a href="{$_G['siteurl']}portal.php?mod=index&mobile=2">��ҳ</a></li>
<li class="c"><a href="{$_G['siteurl']}forum.php?forumlist=1&mobile=2">����</a></li>
<li class="f"><a href="{$_G['siteurl']}forum.php?mod=guide&view=newthread&mobile=2">����</a></li>
<li class="b"><a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="icon_userinfo">�ҵ�</a></li>
</ul>
</div>



</body></html><!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
<!--{eval output();}-->
<!--{else}-->
<!--{eval output_preview();}-->
<!--{/if}-->
