<?php echo 'From: DisM.taobao.com';exit;?>
<div class="mbn">
	<!--{if $activity['thumb']}--><img src="$activity['thumb']"/><!--{else}--><img src="{IMGDIR}/nophoto.gif" width="230" height="230" /><!--{/if}-->
		<dl>
			<dt>{lang activity_type}: <strong>$activity[class]</strong></dt>
			<dt>{lang activity_starttime}:
				<!--{if $activity['starttimeto']}-->
					{lang activity_start_between}
				<!--{else}-->
					$activity[starttimefrom]
				<!--{/if}-->
			</dt>
			<dt>{lang activity_space}: $activity[place]</dt>
			<dt>{lang gender}:
				<!--{if $activity['gender'] == 1}-->
					{lang male}
				<!--{elseif $activity['gender'] == 2}-->
					{lang female}
				<!--{else}-->
					 {lang unlimited}
				<!--{/if}-->
			</dt>
			<!--{if $activity['cost']}-->
				<dt>{lang activity_payment}: $activity[cost] {lang payment_unit}</dt>
			<!--{/if}-->
		</dl>
		<!--{if !$_G['forum_thread']['is_archived']}-->
		<dl class="mtn">
			<dt>{lang activity_already}:
				<em>$allapplynum</em> {lang activity_member_unit}
				<!--{if $post['invisible'] == 0 && ($_G['forum_thread']['authorid'] == $_G['uid'] || (in_array($_G['group']['radminid'], array(1, 2)) && $_G['group']['alloweditactivity']) || ( $_G['group']['radminid'] == 3 && $_G['forum']['ismoderator'] && $_G['group']['alloweditactivity']))}-->
					<span class="xi1">{lang activity_mod}</span>
				<!--{/if}-->
			</dt>
		</dl>
		<dl>
			<!--{if $activity['number']}-->
			<dt>{lang activity_about_member}:
				$aboutmembers {lang activity_member_unit}
			</dt>
			<!--{/if}-->
			<!--{if $activity['expiration']}-->
				<dt>{lang post_closing}: $activity[expiration]</dt>
			<!--{/if}-->
			
				<!--{if $post['invisible'] == 0}-->
				
					<!--{if $applied && $isverified < 2}-->
					<dt>
						<p class="xg1 xs1"><!--{if !$isverified}-->{lang activity_wait}<!--{else}-->{lang activity_join_audit}<!--{/if}--></p>
						<!--{if !$activityclose}-->
                        <!--{/if}-->
					<!--{elseif !$activityclose}-->
                        <!--{if $isverified != 2}-->
                        <!--{else}-->
                        <p class="pns mtn">
                            <input value="{lang complete_data}" name="ijoin" id="ijoin" />
                        </p>
                        <!--{/if}-->
						</dt>
					<!--{/if}-->
					
				<!--{/if}-->
			
		</dl>
		<!--{/if}-->
</div>


<!--{if $_G['uid'] && !$activityclose && (!$applied || $isverified == 2)}-->
	<div id="activityjoin" class="bm mtn lmkj_dds">
    	<div class="bm_c pd5 lmkj_ssa">
        <div class="xw1">{lang activity_join}</div>
	<!--{if $_G['forum']['status'] == 3 && helper_access::check_module('group') && $isgroupuser != 'isgroupuser'}-->
        <p>{lang activity_no_member}</p>
        <p><a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="xi2">{lang activity_join_group}</a></p>
	<!--{else}-->
		<form name="activity" id="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}&mobile=2" >
			<input type="hidden" name="formhash" value="{FORMHASH}" />

			<!--{if $_G['setting']['activitycredit'] && $activity['credit'] && !$applied}--><p class="xi1">{lang activity_need_credit} $activity[credit] {$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</p><!--{/if}-->
                <!--{if $activity['cost']}-->
                   <p style="margin-bottom:6px;">{lang activity_paytype}<br> <label><input class="pr" type="radio" value="0" name="payment" id="payment_0" checked="checked" />{lang activity_pay_myself}</label><label><input class="pr" type="radio" value="1" name="payment" id="payment_1" />{lang activity_would_payment} 
				  </label> <input name="payvalue" size="3" class="txt_s" /> {lang payment_unit}</p>
                <!--{/if}-->
                <!--{if !empty($activity['ufield']['userfield'])}-->
                    <!--{loop $activity['ufield']['userfield'] $fieldid}-->
                    <!--{if $settings[$fieldid][available]}-->
                        <strong>$settings[$fieldid][title]<span class="xi1">*</span></strong>
                        $htmls[$fieldid]
                    <!--{/if}-->
                    <!--{/loop}-->
                <!--{/if}-->
                <!--{if !empty($activity['ufield']['extfield'])}-->
                    <!--{loop $activity['ufield']['extfield'] $extname}-->
                        $extname<input type="text" name="$extname" maxlength="200" class="txt" value="{if !empty($ufielddata)}$ufielddata[extfield][$extname]{/if}" />
                    <!--{/loop}-->
                <!--{/if}-->
				
        <span class="xi1">{lang leaveword} *</span><textarea name="message" maxlength="200" cols="28" rows="1" class="txt">$applyinfo[message]</textarea>
			<br>
			<br>
			<div class="o pns">
				<!--{if $_G['setting']['activitycredit'] && $activity['credit'] && checklowerlimit(array('extcredits'.$_G['setting']['activitycredit'] => '-'.$activity['credit']), $_G['uid'], 1, 0, 1) !== true}-->
					<p class="xi1">{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]} {lang not_enough}$activity['credit']</p>
				<!--{else}-->
					<input type="hidden" name="activitysubmit" value="true">
					<em class="xi1" id="return_activityapplies"></em>
					<button type="submit" style="padding:5px 10px;background:#FF5722;color:#fff;"><span>{lang submit}</span></button>
				<!--{/if}-->
			</div>
		</form>

		<script type="text/javascript">
			function succeedhandle_activityapplies(locationhref, message) {
				showDialog(message, 'notice', '', 'location.href="' + locationhref + '"');
			}
		</script>
	<!--{/if}-->
    	</div>
	</div>
<!--{elseif $_G['uid'] && !$activityclose && $applied}-->
<div id="activityjoincancel" class="bm mtn">
	<div class="pd5">
       
        <form name="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <p class="lmkj_mas">
        {lang activity_join_cancel}{lang leaveword}<input type="text" name="message" maxlength="200" class="px" value="" style="margin-left: 10px;"/>
        </p>
        <p>
        <button type="submit" name="activitycancel"  value="true"><span class="lmkj_aniu">{lang submit}</span></button>
        </p>
        </form>
    </div>
</div>
<!--{/if}-->
<style>
.lmkj_ssa{padding: .8rem 1rem;background: #f7f7f7;border: 1px solid #d2d2d2;margin: 10px 0;}
.lmkj_mas{padding: .8rem 1rem; background: #ffffff; border: 1px solid #eee; margin: 10px 0;}
.pcb h1, .pcb h2{margin: 8px 0; font-size: 1.17em;}
.lmkj_hdw .dt td, .lmkj_hdw .dt th{padding: 2px!important; border-bottom: 1px solid #CDCDCD;font-size: 14px;}
.lmkj_hdw .dt th{background: #F2F2F2;}
.lmkj_hdw a img{display:inherit!important;}
.ptm .dt{width: 100%;}
.ptm .vm{vertical-align: middle;}
.ratl img{height: 24px; width: 24px; vertical-align: middle;}
.mbn dl dt{padding: .5rem 1rem; background: #ebebeb; border: 1px solid #eee; margin: 5px 0;}
.mbn dl dt:nth-child(even) , .mbn dl:nth-child(even) dt{background: #fff;}
.txt_s, .txt{border: 1px solid #ddd;}
.lmkj_dds label{padding:3px 10px 3px 0;}
.lmkj_aniu{font-size: 15px; text-align: center; background: #ff795c; display: block; margin: 0 auto; color: #ffffff; border-radius: 4px; height: 40px; line-height: 40px; padding: 0 15px;}
</style>
<!--{if $applylist}-->
	<div class="ptm pbm xs1 lmkj_hdw" id="applylist_$_G[tid]">
		<h2>{lang activity_new_join} ($applynumbers {lang activity_member_unit})</h2>
		<table class="dt">
			<tr>
				<th width="140">&nbsp;</th>
				<th>{lang leaveword}</th>
				<!--{if $activity['cost']}-->
				<th width="60">{lang activity_payment}</th>
				<!--{/if}-->
				<th width="110">{lang activity_jointime}</th>
			</tr>
			<!--{loop $applylist $apply}-->
				<tr>
					<td>
						<a target="_blank" href="home.php?mod=space&uid=$apply[uid]" class="ratl vm"><!--{echo avatar($apply[uid], 'small')}--></a>
						<a target="_blank" href="home.php?mod=space&uid=$apply[uid]">$apply[username]</a>
					</td>
					<td><!--{if $apply[message]}--><p>$apply[message]</p><!--{/if}--></td>
					<!--{if $activity['cost']}-->
					<td><!--{if $apply[payment] >= 0}-->$apply[payment] {lang payment_unit}<!--{else}-->{lang activity_self}<!--{/if}--></td>
					<!--{/if}-->
					<td>$apply[dateline]</td>
				</tr>
			<!--{/loop}-->
		</table>
		<!--{if $applynumbers > $_G['setting']['activitypp']}-->
		<br>
		<div class="pgs mbm cl">
			<div class="pg">
				<a onclick="ajaxget('forum.php?mod=misc&amp;action=getactivityapplylist&amp;tid=$_G[tid]&amp;page=2', 'applylist_$_G[tid]')" class="nxt" href="javascript:;">{lang next_page}</a>
			</div>
		</div>
		<!--{/if}-->
	</div>
<!--{/if}-->

