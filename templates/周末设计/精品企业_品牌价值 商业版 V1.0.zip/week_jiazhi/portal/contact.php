<?php echo '��ĩ�����ҵģ�屣�����빺������ģ��, �ͷ�QQ: 441576729 , http://www.haoweek.com/ ';exit;?>
<div class="wk_c_left_cont">
    <span class="wk_c_left_cont1">$week_lang[86]</span><span class="wk_c_left_cont2">$week_lang[87]</span>
</div>
<div class="wk_left_contdiv"> 
    <span>$week_lang[88]</span>
    <span>$week_lang[89]</span>
    <span>$week_lang[90]</span>
    <span>$week_lang[91]</span>
    <span>$week_lang[92]</span>
    <span>$week_lang[93]</span>
</div>
<div class="clear"></div>