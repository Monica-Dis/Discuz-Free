<?php echo '��ĩ�����ҵģ�屣�����빺������ģ��, �ͷ�QQ: 441576729 , http://www.haoweek.com/ ';exit;?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>

</div>
<div class="clear"></div>

<div class="wk_page-wrap"> 
	<div class="wk_section wk_page1">
		<div class="wk_slide-wrap">
			<ul>
				<li id="wk_s1" class="wk_selected">
                    <video loop src="template/week_jiazhi/images/portal/swf/bg1.mp4"></video>
                    <div class="bg"></div>
                    <div class="wrap">
                        <div class="img">
                          <img src="template/week_jiazhi/images/portal/imgsrc/img46.png"/>
                        </div>
                        <div class="text">
                          <img src="template/week_jiazhi/images/portal/imgsrc/img47.png"/>
                        </div>
                    </div>
				</li>
				<li id="wk_s2">
                    <video loop src="template/week_jiazhi/images/portal/swf/bg2.mp4"></video>
                    <div class="bg"></div>
                    <div class="wrap">
                        <span class="img">
                        <img src="template/week_jiazhi/images/portal/imgsrc/img48.png"/>
                            <div class="quan">
                              <img src="template/week_jiazhi/images/portal/imgsrc/img49.png"/>
                            </div>
                        </span> 
                    </div>
				</li>
				<li id="wk_s3">
                    <video loop src="template/week_jiazhi/images/portal/swf/bg3.mp4"></video>
                    <div class="bg"></div>
                    <div class="wrap">
                        <div class="img">
                          <img src="template/week_jiazhi/images/portal/imgsrc/img43.png"/>
                        </div>
                        <div class="text">$week_lang[140]</div>
                    </div>
				</li>
			</ul>
		</div>
		<div class="wk_arrow">
			<table><tr><td><a href="#services"><img src="template/week_jiazhi/images/portal/imgsrc/img1.png"/></a></td></tr></table>
		</div>
		<div class="wk_slide-nav-wrap">
			<div class="wk_nav" id="wk_slide-nav">
				<ul>
					<li class="wk_nav-line"></li>
					<li class="wk_nav-bullet-container wk_active" data-index="0">
						<a class="wk_nav-link" href="javascript:;"><div class="wk_nav-bullet"></div></a>
					</li>
					<li class="wk_nav-line">
					</li>
					<li class="wk_nav-bullet-container" data-index="1">
						<a class="wk_nav-link" href="javascript:;"><div class="wk_nav-bullet"></div></a>
					</li>
					<li class="wk_nav-line">
					</li>
					<li class="wk_nav-bullet-container" data-index="2">
						<a class="wk_nav-link" href="javascript:;"><div class="wk_nav-bullet"></div></a>
					</li>
					<li class="wk_nav-line"></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="wk_section wk_page2 wk_noql">
		<div class="wk_wrapper">
			<ul>
				<li class="wk_l1">
					<div class="wk_bg"></div>
					<div class="wk_wrap">
						<div class="wk_ico"></div>
						<h2>$week_lang[142]</h2>
						<dl>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img9.png"/></dd>
							<dd><span></span></dd>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img10.png"/></dd>
							<dd><span></span></dd>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img11.png"/></dd>
						</dl>
						<p class="wk_desc">$week_lang[143]</p>
					</div>
					<div class="wk_img"><img src="template/week_jiazhi/images/portal/imgsrc/img2-1.jpg"/></div>
				</li>
				<li class="wk_l2">
					<div class="wk_bg"></div>
					<div class="wk_wrap">
						<div class="wk_ico"></div>
						<h2>$week_lang[144]</h2>
						<dl>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img12.png"/></dd>
							<dd><span></span></dd>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img13.png"/></dd>
							<dd><span></span></dd>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img14.png"/></dd>
						</dl>
						<p class="wk_desc">$week_lang[145]</p>
					</div>
					<div class="wk_img"><img src="template/week_jiazhi/images/portal/imgsrc/img2-2.jpg"/></div>
				</li>
				<li class="wk_l3">
					<div class="wk_bg"></div>
					<div class="wk_wrap">
						<div class="wk_ico"></div>
						<h2>$week_lang[146]</h2>
						<dl>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img15.png"/></dd>
							<dd><span></span></dd>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img16.png"/></dd>
							<dd><span></span></dd>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img17.png"/></dd>
						</dl>
						<p class="wk_desc">$week_lang[147]</p>
					</div>
					<div class="wk_img"><img src="template/week_jiazhi/images/portal/imgsrc/img2-3.jpg"/></div>
				</li>
				<li class="wk_l4">
					<div class="wk_bg"></div>
					<div class="wk_wrap">
						<div class="wk_ico"></div>
						<h2>$week_lang[148]</h2>
						<dl>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img18.png"/></dd>
							<dd><span></span></dd>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img19.png"/></dd>
							<dd><span></span></dd>
							<dd><img src="template/week_jiazhi/images/portal/imgsrc/img20.png"/></dd>
						</dl>
						<p class="wk_desc">$week_lang[149]</p>
					</div>
					<div class="wk_img"><img src="template/week_jiazhi/images/portal/imgsrc/img2-4.jpg"/></div>
				</li>
			</ul>
		</div>
	</div>
	<div class="wk_section wk_page3 wk_noql">
		<div class="wk_wrapper">
			<div class="wk_head">
				<div class="wk_img"><img src="template/week_jiazhi/images/portal/imgsrc/img21.png"/></div>
				<div class="wk_nav">
					<ul>
						<li><a class="wk_jian" href="$week_lang[151]"><img src="template/week_jiazhi/images/portal/imgsrc/img44.png"/></a></li>
						<li><img src="template/week_jiazhi/images/portal/imgsrc/img23.png"/></li>
					</ul>
				</div>
				<dl class="wk_sort">
					<dt>$week_lang[154]</dt>
					<dd>$week_lang[152]</dd>
					<dd><span></span></dd>
					<dd>$week_lang[153]</dd>
				</dl>
			</div>
			<div class="wk_body">
				<!--{block/524}-->		<!--��ҳ�����ڲ�����λ��-->
			</div>
		</div>
	</div>
	<div class="wk_section wk_page4 wk_noql">
		<div class="wk_wrapper">
			<div class="wk_head">
				<div class="wk_img"><img src="template/week_jiazhi/images/portal/imgsrc/img25.png"/></div>
				<div class="wk_nav">
					<ul>
						<li><a href="$week_lang[156]" class="wk_wen"><img src="template/week_jiazhi/images/portal/imgsrc/img45.png"/></a></li>
						<li><a href="$week_lang[157]"><img src="template/week_jiazhi/images/portal/imgsrc/img27.png"/></a></li>
					</ul>
				</div>
				<div class="wk_list">
					<!--{block/525}-->		<!--��ҳ���ţ�������ʽ���ڲ�����λ��-->
				</div>
			</div>
			<div class="wk_body">
				<!--{block/526}-->			<!--��ҳ���ţ�ͼ����ʽ���ڲ�����λ��-->
			</div>
		</div>
	</div>
	<div class="wk_section wk_page5 wk_noql">
		<div class="wk_wrapper">
			<div class="wk_img-wrap">
				<div class="wk_img1"><img src="template/week_jiazhi/images/portal/imgsrc/img51.png"/></div>
				<div class="wk_img2"><img src="template/week_jiazhi/images/portal/imgsrc/img52.png"/></div>
				<div class="wk_img3"><img src="template/week_jiazhi/images/portal/imgsrc/img53.png"/></div>
				<div class="wk_img4"><img src="template/week_jiazhi/images/portal/imgsrc/img54.png"/></div>
			</div>
			<div class="wk_text">
				<h2>$week_lang[160]</h2>
				<p>$week_lang[161]</p>
                <p>$week_lang[162]</p>
                <p class="wk_more">&hellip;&hellip;</p>
			</div>
			<div class="wk_nav">
				<ul>
					<li><a href="$week_lang[165]"><img src="template/week_jiazhi/images/portal/imgsrc/img34.png"/></a></li>
					<li><a href="$week_lang[166]"><img src="template/week_jiazhi/images/portal/imgsrc/img35.png"/></a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="wk_section wk_page6 wk_noql">
		<video autoplay loop src="template/week_jiazhi/images/portal/swf/bg4.mp4"></video>
		<div class="wk_bg">
		</div>
		<div class="wk_wrapper">
			<div class="wk_img">
			  <img src="template/week_jiazhi/images/portal/imgsrc/img57.png" class="wk_quan"/>
				<div class="wk_wen"><img src="template/week_jiazhi/images/portal/imgsrc/img56.png"/></div>
			</div>
			<div class="wk_text">
				<div class="wk_time">
					<span class="wk_wrap">
						<i><img src="template/week_jiazhi/images/portal/imgsrc/img39.png"/></i>
						<h2><img src="template/week_jiazhi/images/portal/imgsrc/img55.png"/></h2>
						<h4>$week_lang[168]</h4>
					</span>
				</div>
				<div class="wk_tele">
				  <img src="template/week_jiazhi/images/portal/imgsrc/img37.png" class="wk_tel"/>
					<a href="http://wpa.qq.com/msgrd?v=3&uin=$week_lang[169]&site=qq&menu=yes" target="_blank"><img class="wk_qq" src="template/week_jiazhi/images/portal/imgsrc/img38.png"/></a>
				</div>
			</div>
		</div>
		<div class="wk_info">
			<ul id="wk_ul1">
				<li>$week_lang[171]<br/></li>
			</ul>
			<ul id="wk_ul2">
				<li>Copyright &copy; 2016 <a href="http://www.comsenz.com" target="_blank">Comsenz Inc.</a><br/>All Rights Reserved. By <a href="http://www.discuz.net" title="Discuz!" target="_blank">Discuz!</a> <em>$_G['setting']['version']</em><!--{if !empty($_G['setting']['boardlicensed'])}--> <a href="http://license.comsenz.com/?pid=1&host=$_SERVER[HTTP_HOST]" target="_blank">Licensed</a><!--{/if}--> <br/><a title="Week Design By Haoweek.com" target="_blank">$week_lang[5]</a> <!--$week_lang[6]--><br/><!--{if $_G['setting']['icp']}--><a href="http://www.miitbeian.gov.cn/" target="_blank" title="$_G['setting']['icp']">( $_G['setting']['icp'] )</a><!--{/if}-->
				</li>
			</ul>
			<ul id="wk_ul3">
				<li>$week_lang[172]<br/><!--{hook/global_footerlink}--><!--{if $_G['setting']['statcode']}-->$_G['setting']['statcode']<!--{/if}-->
				</li>
			</ul>
		</div>
  </div> 
</div>

<script type='text/javascript' src="$_G['style']['styleimgdir']/js/portal/jquery-1.7.2_index.js"></script>
<script type='text/javascript' src="$_G['style']['styleimgdir']/js/portal/jquery.fullPage.min.js"></script>
<script type='text/javascript' src="$_G['style']['styleimgdir']/js/portal/jquery.addons.js"></script>

<div class="clear"></div>
<div class="wp"><!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]--></div>
<div class="clear"></div>

<div id="wp" class="wp">

<!--{template common/footer_index}-->
