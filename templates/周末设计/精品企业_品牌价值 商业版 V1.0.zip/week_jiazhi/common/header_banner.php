<?php echo '��ĩ�����ҵģ�屣�����빺������ģ��, �ͷ�QQ: 441576729 , http://www.haoweek.com/ ';exit;?>

<div class="wk_head_banner">
	<!--{if $wk_headbanner}-->
<div class="flexslider">
        <ul class="slides">
            <li style="background:url($_G['style']['styleimgdir']/banner01.jpg) 50% 0 no-repeat;"></li>
            <li style="background:url($_G['style']['styleimgdir']/banner02.jpg) 50% 0 no-repeat;"></li>
            <li style="background:url($_G['style']['styleimgdir']/banner03.jpg) 50% 0 no-repeat;"></li>
        </ul>
    </div>
    <script type="text/javascript" src="$_G['style']['styleimgdir']/js/jquery.flexslider-min.js"></script>
	<script>
    FOM(window).load(function() {
        FOM('.flexslider').flexslider({
            directionNav: false,
            pauseOnAction: false
        });
    });
    </script>
    <!--{else}-->
    <div class="wk_content_banner"></div>
    <!--{/if}-->
</div>
