$(function(){
  var menuwidth  = 240; // 边栏宽度
  var menuspeed  = 400; // 边栏滑出耗费时间
  
  var $bdy       = $('body');
  var $container = $('#yd_zong');
  var $hcontainer = $('#header');		
  var $ffcontainer = $('.footer');
  var $fcontainer = $('.footer_menu');
  var $gucontainer = $('.gu_main');
  var $burger    = $('#bbs_hamburgermenu');
  var negwidth   = "-"+menuwidth+"px";
  var poswidth   = menuwidth+"px";
  
  $('.bbs_menubtn').on('click',function(e){
    if($bdy.hasClass('bbs_openmenu')) {
      jsAnimateMenu('close');
    } else {
      jsAnimateMenu('open');
    }
  });
  $('.bbs_overlay').on('click', function(e){
    if($bdy.hasClass('bbs_openmenu')) {
      jsAnimateMenu('close');
    }
  });
  
  function jsAnimateMenu(tog) {
    if(tog == 'open') {
      $bdy.addClass('bbs_openmenu');
      
      $container.animate({marginRight: negwidth, marginLeft: poswidth}, menuspeed);
	  $hcontainer.animate({marginRight: negwidth, marginLeft: poswidth}, menuspeed);
	  $fcontainer.animate({marginRight: negwidth, marginLeft: poswidth}, menuspeed);
	  $ffcontainer.animate({marginRight: negwidth, marginLeft: poswidth}, menuspeed);
	  $gucontainer.animate({marginRight: negwidth, marginLeft: poswidth}, menuspeed);
      $burger.animate({width: poswidth}, menuspeed);
      $('.bbs_overlay').animate({left: poswidth}, menuspeed);
    }
    
    if(tog == 'close') {
      $bdy.removeClass('bbs_openmenu');
      
      $container.animate({marginRight: "0", marginLeft: "0"}, menuspeed);
	  $hcontainer.animate({marginRight: "0", marginLeft: "0"}, menuspeed);
	  $fcontainer.animate({marginRight: "0", marginLeft: "0"}, menuspeed);
	  $ffcontainer.animate({marginRight: "0", marginLeft: "0"}, menuspeed);
	  $gucontainer.animate({marginRight: "0", marginLeft: "0"}, menuspeed);
      $burger.animate({width: "0"}, menuspeed);
      $('.bbs_overlay').animate({left: "0"}, menuspeed);
    }
  }
});