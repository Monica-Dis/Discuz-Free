<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{subtemplate common/header_common}-->
	<meta name="application-name" content="$_G['setting']['bbname']" />
	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
	<!--{/if}-->
	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
   		    	<!--{if $_G['cache']['plugin']['xlmmd']['xlmmdmh']}-->
			<link rel="stylesheet" type="text/css" href='template/xlmm_d/common/allh.css?{VERHASH}' />
<!--{/if}-->
	<!--{if widthauto()}-->
		<link rel="stylesheet" id="css_widthauto" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_widthauto.css?{VERHASH}' />
		<script type="text/javascript">HTMLNODE.className += ' widthauto'</script>
	<!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'home'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'portal'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
<SCRIPT language=javascript> 
<!-- 
window.onerror=function(){return true;} 
// --> 
</SCRIPT> 
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<link rel="stylesheet" type="text/css" id="diy_common" href="{$_G['setting']['csspath']}{STYLEID}_css_diy.css?{VERHASH}" />
	<!--{/if}-->
</head>

<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if}" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<!--{template common/header_diy}-->
	<!--{/if}-->
	<!--{if check_diy_perm($topic)}-->
		<!--{template common/header_diynav}-->
	<!--{/if}-->
	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
		$diynav
	<!--{/if}-->
						<!--{if check_diy_perm($topic)}-->
				<style>
.tdiy #diy-tg { float:none; height:24px; position: absolute; top:5px; right:10px; z-index:2;}
   .tdiy #diy-tg_menu { line-height:22px; margin:-3px 0 0 -1px;}
</style>
			<div class="tdiy">
		$diynav
				</div>
				<!--{/if}-->
<!--{if empty($topic) || $topic['useheader']}-->
		<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
			<div class="xi1 bm bm_c">
			    {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a>
			</div>
		<!--{/if}-->
		<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
			<div id="shortcut">
				<span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span>
				{lang shortcut_notice}
				<a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a>

			</div>
			<script type="text/javascript">setTimeout(setShortcut, 2000);</script>
		<!--{/if}-->
<!--top开始-->
<div class="wapper_out sitenavbg level1">
	<!--{hook/global_cpnav_top}-->
	    <div class="wapper wp sitenav overvisible">
        <ul class="z head_ul">
    <!--{$_G['cache']['plugin']['xlmmd']['xlmmdhlt']}-->   
 						 <li>					<!--{loop $_G['setting']['topnavs'][0] $nav}-->
						<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
					<!--{/loop}--><!--{hook/global_cpnav_extra1}-->
</li> 
				<!--{if empty($_G['disabledwidthauto']) && $_G['setting']['switchwidthauto']}-->
						 <li><a href="javascript:;" id="switchwidth" onClick="widthauto(this)" title="{if widthauto()}{lang switch_narrow}{else}{lang switch_wide}{/if}" class=""><!--{if widthauto()}-->{lang switch_narrow}<!--{else}-->{lang switch_wide}<!--{/if}--></a> </li>
					<!--{/if}-->
    </ul>
      <div class="y<!--{if $_G['basescript'] == 'portal' && CURMODULE == 'index' || $_G['cache']['plugin']['xlmmd']['xlmmdmh']}--><!--{else}--> forumtop<!--{/if}-->">
   		    	<!--{if $_G['basescript'] == 'portal' && CURMODULE == 'index' || $_G['cache']['plugin']['xlmmd']['xlmmdmh']}-->
  <ul id="userlogin">
   	  <li><!--{hook/global_cpnav_extra2}--></li>
	   <!--{if !$_G['uid']}-->
            <li>
                <a href="member.php?mod=logging&action=login" class="nav_login_title"><i class="sitenavico login">&nbsp;</i>登录</a>
               &nbsp; <em class="vertical">|</em>&nbsp;
                <a title="注册"  href="member.php?mod={$_G[setting][regname]}" >注册</a>
        </li>
            <li class="pr0">
                <a title="扫一扫访问微社区"  href="plugin.php?id=wechat:login"><i class="sitenavico SinaWeibo">&nbsp;</i></a>
                <a title="QQ"  href="$_G[connect][login_url]&statfrom=login_simple"><i class="sitenavico qq">&nbsp;</i></a>
            </li>
 	<!--{else}-->   
   <div class="y" style="margin-top:10px" >
<!--{hook/global_usernav_extra1}-->
</div>
					<!--{if $_G['uid'] && !empty($_G['style']['extstyle'])}--><a id="sslct" href="javascript:;" onMouseOver="delayShow(this, function() {showMenu({'ctrlid':'sslct','pos':'34!'})});" style="margin-top:10px" class="y">{lang changestyle}</a><!--{/if}-->
   <div class="y">
<li class="dropmenu avsimg" id="top1" onMouseOver="showMenu({'ctrlid':this.id,'ctrlclass':'xlmmthover','pos':'34!'})"><a class="now" href="home.php?mod=space&uid=$_G[uid]" target="_blank"><!--{avatar($_G[uid],middle)}--> {echo cutstr($_G[member][username],10)} <i class="sitenavico downward">&nbsp;</i> </a></li>
<li class="dropmenu " id="top2" onMouseOver="showMenu({'ctrlid':this.id,'ctrlclass':'xlmmthover','pos':'34!'})"><a class="" href="home.php?mod=space&do=notice" title="提醒"><i class="sitenavico remind<!--{if $_G[member][newprompt]}--> remind_have<!--{else}--><!--{/if}-->">&nbsp;</i>提醒<i class="sitenavico downward">&nbsp;</i></a></li>
<li><a class="" href="home.php?mod=space&do=pm" title="短消息"><i class="sitenavico shortMessage<!--{if $_G[member][newpm]}--> shortMessage_have<!--{else}--><!--{/if}-->">&nbsp;</i>短消息</a></li>
<li><em class="vertical">|</em></li>
<li class="dropmenu " id="top3" onMouseOver="showMenu({'ctrlid':this.id,'ctrlclass':'xlmmthover','pos':'34!'})"><a class="now" href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="个人中心">个人中心<i class="sitenavico downward">&nbsp;</i></a></li>
</div>
				<!--{/if}-->	
 </ul>
 		    	<!--{else}-->
					<!--{hook/global_cpnav_extra2}-->
					<!--{loop $_G['setting']['topnavs'][1] $nav}-->
						<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
					<!--{/loop}-->
					<!--{if $_G['uid'] && !empty($_G['style']['extstyle'])}--><a id="sslct" href="javascript:;" onMouseOver="delayShow(this, function() {showMenu({'ctrlid':'sslct','pos':'34!'})});" style="margin-top:10px">{lang changestyle}</a><!--{/if}-->
		<!--{/if}-->	
</div>
   </div>
</div>
<div class="clearfix"></div>

<!--top结束-->

		<!--{if !IS_ROBOT}-->
                <div class="weixin_tip dropdown" id="top0_menu" style="display: none; margin-left:30px"><div class="weixin_img"><img src="template/xlmm_d/image/erweima1.png" style="width:120px;height:120px;display:block;margin:0 auto 0;"></div><p class="gc6 tac mt5">打开微信扫一扫</p></div>
		   <!--{if $_G['uid']}-->
<ul class="dropdown dropdown_info_box user_msg" id="top1_menu" style="display: none; width:75px">
<li class=""><a href="home.php?mod=spacecp&ac=usergroup">$_G[group][grouptitle]</a></li>       
<li class="last"><a href="home.php?mod=spacecp&ac=credit&showcredit=1">积分:<em class="orange"> $_G[member][credits]</em></a></li></ul>
			<ul class="dropdown dropdown_info_box personal_center" id="top2_menu" style="display: none;">
				<li><a href="home.php?mod=space&do=pm">{lang pm_center}</a></li>
				<li><a href="home.php?mod=follow&do=follower"><!--{lang notice_interactive_follower}-->{if $_G[member][newprompt_num][follower]}($_G[member][newprompt_num][follower]){/if}</a></li>
				<!--{if $_G[member][newprompt] && $_G[member][newprompt_num][follow]}-->
					<li><a href="home.php?mod=follow"><!--{lang notice_interactive_follow}-->($_G[member][newprompt_num][follow])</a></li>
				<!--{/if}-->
				<!--{if $_G[member][newprompt]}-->
					<!--{loop $_G['member']['category_num'] $key $val}-->
						<li><a href="home.php?mod=space&do=notice&view=$key"><!--{echo lang('template', 'notice_'.$key)}-->(<span class="rq">$val</span>)</a></li>
					<!--{/loop}-->
				<!--{/if}-->
			</ul>

<ul class="dropdown dropdown_info_box personal_center" id="top3_menu" style="display: none; width:63px">
<li><a href="home.php?mod=spacecp&ac=avatar">修改头像</a></li>    
   <li><a href="home.php?mod=spacecp">修改资料</a></li> 
					<li><a href="forum.php?mod=guide&view=my">我的{lang mypost}</a></li>
					<li><a href="home.php?mod=space&do=favorite&view=me">我的{lang favorite}</a></li>
					<!--{hook/global_myitem_extra}-->
   <li><a href="home.php?mod=spacecp&ac=profile&op=password">修改密码</a></li>			
   <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->  <li><a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}  <!--{/if}--></a></li>  <!--{/if}-->  
   <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->  <li><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>  <!--{/if}-->  
   <!--{if $_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']}-->  <li><a href="admin.php?frames=yes&action=cloud&operation=applist" target="_blank">{lang cloudcp}</a></li>  <!--{/if}-->  
   <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->  <li><a href="admin.php" target="_blank">{lang admincp}</a></li>  <!--{/if}-->    
   <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">退出登录</a></li></ul>
		<!--{/if}-->
		<!--{/if}-->
			<!--{if $_G['uid'] && !empty($_G['style']['extstyle'])}-->
				<div id="sslct_menu" class="cl p_pop" style="display: none;">
					<!--{if !$_G[style][defaultextstyle]}--><span class="sslct_btn" onClick="extstyle('')" title="{lang default}"><i></i></span><!--{/if}-->
					<!--{loop $_G['style']['extstyle'] $extstyle}-->
						<span class="sslct_btn" onClick="extstyle('$extstyle[0]')" title="$extstyle[1]"><i style='background:$extstyle[2]'></i></span>
					<!--{/loop}-->
				</div>
			<!--{/if}-->

		<!--{ad/headerbanner/wp a_h}-->
	
 		    	<!--{if $_G['basescript'] == 'portal' && CURMODULE == 'index'  || $_G['cache']['plugin']['xlmmd']['xlmmdmh']}-->
 <div class="wp overvisible">
					<!--{eval $mnid = getcurrentnav();}-->
<h2 class="z mt20 mr10 inlines"><!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}--></h2>
<div class="head_search z mt25 clearfix inlines" style="margin-left:60px">
<form method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" onSubmit="searchFocus($('scbar_txt'))" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank" id="head_search_form" class="pr">
        			        <input type="hidden" name="mod" id="scbar_mod" value="forum" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="srchtype" value="title" />
        <input type="hidden" name="srhfid" value="" />
        <input type="hidden" name="srhlocality" value="forum::mypage" />
              <input type="hidden" name="searchsubmit" value="yes"/>
<input name="srchtxt" autocomplete="off" accesskey="s" value="" maxlength="30" class="z inlines" id="searchtxt" placeholder="输入你想搜索的关键词..." type="text">
<input class="searchbut sitenavicos y inlines" id="searchbut" value="" type="submit">
</form>
</div>
 <!--{$_G['cache']['plugin']['xlmmd']['xlmmdtk']}-->   
 <div class="blank15"></div>
</div> 
    
    <div class="wapper_out menu_boxs">
<div class="wp overvisible">
					<ul class="xlmenu wp cl">
						<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="cur" {/if}$nav[nav]></li><!--{/if}-->
						<!--{/loop}-->
		<div class="pr appw">
<a href="misc.php?mod=mobile" id="phone" onMouseOver="showMenu({'ctrlid':this.id,'ctrlclass':'xlmmthover','pos':'34!'})" class="phone" target="_blank"><span class="sitenavicos">APP客户端</span>
</a>
</div>
				</ul>
</div>
				<!--{hook/global_nav_extra}-->
</div>
	<div class="wp">
			<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
					<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
					<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
						 <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
						 <li>$module[url]</li>
						 <!--{/if}-->
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
				$_G[setting][menunavs]
				<div id="mu" class="cl">
				<!--{if $_G['setting']['subnavs']}-->
					<!--{loop $_G[setting][subnavs] $navid $subnav}-->
						<!--{if $_G['setting']['navsubhover'] || $mnid == $navid}-->
						<ul class="cl {if $mnid == $navid}current{/if}" id="snav_$navid" style="border-bottom: 1px solid #CDCDCD;
background:url(template/xlmm_d/image/no.png) no-repeat;background-color: #F2F2F2;display:{if $mnid != $navid}none{/if}">
						$subnav
						</ul>
						<!--{/if}-->
					<!--{/loop}-->
				<!--{/if}-->
				</div>
				</div>
<div id="phone_menu" class="phone-box" style="border: 1px solid rgb(48, 126, 215); display: none;">
<img src="template/xlmm_d/image/erweima2.png">
</div>
    
    <!--{$_G['cache']['plugin']['xlmmd']['xlmmdnav']}-->
    		    	<!--{else}-->
  		<!--{if !IS_ROBOT}-->
			<!--{if $_G['uid']}-->
			<ul id="myprompt_menu" class="p_pop" style="display: none;">
				<li><a href="home.php?mod=space&do=pm" id="pm_ntc" style="background-repeat: no-repeat; background-position: 0 50%;"><em class="prompt_news{if empty($_G[member][newpm])}_0{/if}"></em>{lang pm_center}</a></li>
				<li><a href="home.php?mod=follow&do=follower"><em class="prompt_follower{if empty($_G[member][newprompt_num][follower])}_0{/if}"></em><!--{lang notice_interactive_follower}-->{if $_G[member][newprompt_num][follower]}($_G[member][newprompt_num][follower]){/if}</a></li>
				<!--{if $_G[member][newprompt] && $_G[member][newprompt_num][follow]}-->
					<li><a href="home.php?mod=follow"><em class="prompt_concern"></em><!--{lang notice_interactive_follow}-->($_G[member][newprompt_num][follow])</a></li>
				<!--{/if}-->
				<!--{if $_G[member][newprompt]}-->
					<!--{loop $_G['member']['category_num'] $key $val}-->
						<li><a href="home.php?mod=space&do=notice&view=$key"><em class="notice_$key"></em><!--{echo lang('template', 'notice_'.$key)}-->(<span class="rq">$val</span>)</a></li>
					<!--{/loop}-->
				<!--{/if}-->
				<!--{if empty($_G['cookie']['ignore_notice'])}-->
					<li class="ignore_noticeli"><a href="javascript:;" onClick="setcookie('ignore_notice', 1);hideMenu('myprompt_menu')" title="{lang temporarily_to_remind}"><em class="ignore_notice"></em></a></li>
				<!--{/if}-->
			</ul>
			<!--{/if}-->
			<!--{if $_G['uid']}-->
				<ul id="myitem_menu" class="p_pop" style="display: none;">
					<li><a href="forum.php?mod=guide&view=my">{lang mypost}</a></li>
					<li><a href="home.php?mod=space&do=favorite&view=me">{lang favorite}</a></li>
					<li><a href="home.php?mod=space&do=friend">{lang friends}</a></li>
					<!--{hook/global_myitem_extra}-->
				</ul>
			<!--{/if}-->
			<!--{subtemplate common/header_qmenu}-->
		<!--{/if}-->
  <div id="hd">
			<div class="wp">
				<div class="hdc cl">
					<!--{eval $mnid = getcurrentnav();}-->
					<h2><!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}--></h2>
					<!--{template common/header_userstatus}-->
				</div>

				<div id="nv">
					<a href="javascript:;" id="qmenu" onMouseOver="delayShow(this, function () {showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2});showForummenu($_G[fid]);})">{lang my_nav}</a>
					<ul>
						<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
						<!--{/loop}-->
					</ul>
					<!--{hook/global_nav_extra}-->
				</div>
				<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
					<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
					<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
						 <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
						 <li>$module[url]</li>
						 <!--{/if}-->
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
				$_G[setting][menunavs]
				<div id="mu" class="cl">
				<!--{if $_G['setting']['subnavs']}-->
					<!--{loop $_G[setting][subnavs] $navid $subnav}-->
						<!--{if $_G['setting']['navsubhover'] || $mnid == $navid}-->
						<ul class="cl {if $mnid == $navid}current{/if}" id="snav_$navid" style="display:{if $mnid != $navid}none{/if}">
						$subnav
						</ul>
						<!--{/if}-->
					<!--{/loop}-->
				<!--{/if}-->
				</div>
    <!--{$_G['cache']['plugin']['xlmmd']['xlmmdfnav']}-->
				<!--{ad/subnavbanner/a_mu}-->
				<!--{subtemplate common/pubsearchform}-->
			</div>
		</div>
	<!--{/if}-->

		<!--{hook/global_header}-->
	<!--{/if}-->

	<div id="wp" class="wp">

