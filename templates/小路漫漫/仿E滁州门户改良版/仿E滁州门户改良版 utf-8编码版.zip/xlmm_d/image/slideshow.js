(function($){
//time 2017-10-23
//by wen
;(function($, window, document, undefined){

    $.fn.slideshow = function(options){
        !options && (options = {});
        var settings = $.extend({
            autoplay: 500,//是否自动播放,数字则为自动播放的间隔时间
            delay: 300,//设置滚动事件，动画延长时间
            loop: true//是否循环播放
        }, options);
        return this.each(function(){
//            methods.init.call($(this), settings);
            var $this       = $(this),
                n           = 1,//当前图片索引
                img_width   = $this.width(),//图片宽度
                $thisbanner = $this.find('.banner'),
                timer        = null;//用于自动播放定时器
            //如果设置为循环轮播
            if(settings.loop){
                //为了从最后一张到第一张和从第一张到最后一张的无缝过渡eg（有图片1、2、3），则：3、1、2、3、1
                $thisbanner.append($this.find('.banner li').first().clone());
                $thisbanner.prepend($this.find(".banner li").eq($this.find(".banner li").length-2).clone());
            }
            
            var new_len = $this.find(".banner li").length;//所有图片加起来总长度
            
            //点击点
            $this.find('.dot li').click(function(){
                n = settings.loop ? ($(this).index() + 1) : $(this).index();
                $thisbanner.animate({
                    marginLeft: -n*img_width + 'px'
                }, settings.delay);
                $(this).addClass('active').siblings().removeClass('active');
                
            });
            
            //上一屏
            $this.find('.pre').click(function(){
                if(!settings.loop && (n == 0)){
                    return;
                }
                commonfn('l');
            });
            //下一屏
            $this.find('.next').click(function(){
                if(!settings.loop && (n == new_len-1)){
                    return;
                }
                commonfn('r');
            });
            
            //滑动公共方法
            function commonfn(direction){
                if($thisbanner.is(':animated')){ //当ul正在执行动画的过程中，阻止执行其它动作。关键之处，不然图片切换显示不完全，到最后图片空白不显示。
                    return;
                   }
                direction == 'r' ? n++ : n--;
                $thisbanner.animate({
                    marginLeft: -n*img_width + 'px'
                }, settings.delay, function(){
                    if(settings.loop){
                        n = (n == 0) ? (new_len-2) : (n == (new_len-1) ? 1 : n);
                        $(this).css('marginLeft', -n*img_width + 'px');
                    }
                    var index = settings.loop ? n-1 : n;
                    $this.find('.dot li').eq(index).addClass('active').siblings().removeClass('active');
                })
            }
            
            //自动播放（autoplay的值需要为正数，并且loop值为true）
            if(/^\d+(?=\.{0,1}\d+$|$)/.test(settings.autoplay) && settings.loop){
                timer = setInterval(function(){
                    commonfn('r');
                }, settings.autoplay);
            }
            
            //鼠标移上banner上就停掉轮播，移出鼠标则开始自动轮播
            $this.hover(function(){
                clearInterval(timer);
            },function(){
                timer = setInterval(function(){
                    commonfn('r');
                }, settings.autoplay);
            });
        });
    }
})(jQuery, window, document)
})(jQuery);
