 <?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
  <!--{template common/header}-->
<link rel="stylesheet" href="template/xlmm_d/image/index.css">
 <script src="template/xlmm_d/image/jquery-1.8.3.min.js?{VERHASH}"></script>
     <script type="text/javascript">
     var jQ = jQuery.noConflict();</script>
<style>
#left_side_bar {
	width:110px;
	background:#fff;
	z-index:0;
	position:absolute
}
#left_side_bar .left_bar_title {
	background-position:0 -146px;
	width:108px;
	height:23px;
	margin-bottom:15px
}
#left_side_bar li a{
	font-size:16px;
	color:#307ed7;
	font-weight:700;
	height:38px;
	line-height:38px;
	text-align:center;
	cursor:pointer; display:block
}
#left_side_bar li.a a{
	color:#fff;
	background-color:#307ed7
}
</style>
			<!--{hook/guide_top}-->

<div class="blank20"></div>
<div class="wapper clearfix" id="xlmm_ajax">

	<div class="w640">
<div  class="bbs-list">
					<!--{loop $data $key $list}-->
						<!--{subtemplate forum/guide_list_row}-->
				<!--{/loop}-->
				<div class="bm bw0 pgs cl" style="margin-top:20px">
					$multipage
					<span class="pgb y"><a href="forum.php?mod=guide">{lang guide_index}</a></span>
				</div>
</div>
	</div>
	<div id="xlmmrts"></div>

		<div id="fixed">
<ul id="left_side_bar" class="sideMenu">
				<li $currentview['newthread']><a href="forum.php?mod=guide&view=newthread">{lang guide_newthread}</a></li>
				<li $currentview['hot']><a href="forum.php?mod=guide&view=hot">{lang guide_hot}</a></li>
				<li $currentview['digest']><a href="forum.php?mod=guide&view=digest">{lang guide_digest}</a></li>
				<li $currentview['new']><a href="forum.php?mod=guide&view=new">{lang guide_new}</a></li>
				<li $currentview['sofa']><a href="forum.php?mod=guide&view=sofa">{lang guide_sofa}</a></li>
				<li $currentview['my']><a id="filter_special" href="forum.php?mod=guide&view=my" onmouseover="showMenu(this.id)">{lang guide_my}</a></li>
				<!--{hook/guide_nav_extra}-->
</ul>

	</div>


</div>
			<!--{hook/guide_bottom}-->
<script type="text/ecmascript">
(function($){
  
   $.ajax({
             url:'portal.php' ,
        type:'get',
        dataType: 'html',
        success:function (data){
			     var newdatas = data.match(/<sxlmmajax><\/sxlmmajax>([\s\S]+?)<exlmmajax><\/exlmmajax>/);
 $('#xlmmrts').append(newdatas[1]);    
      },error: function() {
            $('.getMore').html("数据获取失败");
        }
  })

})(jQuery);
var xlmmnvss = $('fixed');
var xlmmnvssoffset = parseInt(fetchOffset(xlmmnvss)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop >= xlmmnvssoffset){
	if (BROWSER.ie && BROWSER.ie < 7) {
		xlmmnvss.style.position = 'absolute';
		xlmmnvss.style.top = xlmmm_scrollTop + 'px';
	}else{
		xlmmnvss.style.position = 'fixed';
		xlmmnvss.style.top = '0';
	xlmmnvss.className = 'fixed';
}
}else{
	xlmmnvss.className = '';
xlmmnvss.style.position = 'static';
		xlmmnvss.style.top = xlmmm_scrollTop + 'px';
}
});
var navs = $('userfixs');
var navsoffset = parseInt(fetchOffset(navs)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop >= navsoffset){
	if (BROWSER.ie && BROWSER.ie < 7) {
		navs.style.position = 'absolute';
		navs.style.top = xlmmm_scrollTop + 'px';
	}else{
		navs.innerHTML  = '<style>.userfix{ position:fixed; top:0px;}</style>';
	}
}else{
		navs.innerHTML  = '<style>.userfix{ position:static;}</style>';
		navs.style.top = xlmmm_scrollTop + 'px';
}
});

</script>

<!--{template common/footer}-->

