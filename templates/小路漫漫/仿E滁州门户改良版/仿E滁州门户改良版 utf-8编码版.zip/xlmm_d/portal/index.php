<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
   <!--{template common/header}-->
<link rel="stylesheet" href="template/xlmm_d/image/index.css">
 <script src="template/xlmm_d/image/jquery-1.8.3.min.js?{VERHASH}"></script>
     <script type="text/javascript">
     var jQ = jQuery.noConflict();</script>
<script src="template/xlmm_d/image/xlmm.js"></script>
     <script type="text/javascript">
var xlmmjz = {};
// 加载
xlmmjz.xlmmloadlist = function(params){

	var target = jQuery(params.target);
	function before(){

		var loading = jQuery('<div class="loaders"><div class="ball-pulse"><div></div><div></div><div></div></div><div class="dropload">Loading...</div></div>').css({
			height:target.outerHeight() <= 52 ? 52 : target.outerHeight()
		});
		target.empty().append(loading);
	}

	function success(data){
		if(data.indexOf('<xlmmajax></xlmmajax>')>=0){
			target.html(data);

			if(params['scroll']){
			}
		}else{
			target.html(' <style>.empty-list {padding-top: 10%;padding-bottom: 10%; text-align:center;background: #fff;}.empty-list span {display: inline-block;font-size: 16px;line-height: 54px;position: relative; text-align:center;}</style><div class="empty-list"><img src=\"template/xlmm_d/image/nt.png\" width=\"62\" height=\"58\"><p><span>加载失败或无权限浏览~</span></p></div>');
		}
	}
	if(window.xlmmloadonhttp){
		window.xlmmloadonhttp.abort();
		window.xlmmloadonhttp = null;
	}
	window.xlmmloadonhttp = jQuery.ajax({
		url:'forum.php?mod=forumdisplay&fid=' + params.fid + '<!--{$_G['cache']['plugin']['xlmmd']['xlmmdsjdy']}-->&ajax=t',
		cache:false,
		beforeSend:before,
		success:success
	});
};

</script>
<style id="diy_style" type="text/css"></style>
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>
<div class="blank20"></div>

<div class="wapper" style="overflow: hidden;">
<div class="z" style="width:630px;">
	<!--[diy=xlmms]--><div id="xlmms" class="area"></div><!--[/diy]-->
</div>
<div class="f_hot y">
	<!--[diy=xlmmsr]--><div id="xlmmsr" class="area"></div><!--[/diy]-->
</div>
</div>

<div class="blank20"></div>
<div class="wapper clearfix" id="xlmm_ajax">

	<div class="w640">
<div id="<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}--><!--{else}-->xlmmfresh_xlmm<!--{/if}-->" class="bbs-list"></div>
	</div>
	<sxlmmajax></sxlmmajax>
	<div class="w340">
	<!--[diy=xlmmsd]--><div id="xlmmsd" class="area"></div><!--[/diy]-->
	<!--[diy=xlmmsd1]--><div id="xlmmsd1" class="area"></div><!--[/diy]-->
<div id="userfixs"></div>
</div>
	<exlmmajax></exlmmajax>

		<div id="fixed">
<div id="left_side_bar">
	<!--[diy=xlmmleft]--><div id="xlmmleft" class="area"></div><!--[/diy]-->
	</div>
	</div>


</div>
<script type="text/ecmascript">
(function($){
  $("#slider_wapper").slide({
    titCell: ".btns ul",
    mainCell: ".hd ul",
    autoPage: true,
    effect: "left",
    autoPlay: true,
    vis: 6,
    trigger: "click"
  });
  $("#slider_wapper").slide({
    mainCell: ".bd ul",
    effect: "left",
    autoPlay: true
  });
jQuery("#index_scrolls").slide({mainCell:".act_list",effect:"topLoop",autoPlay:true,autoPage:true,vis:2,scroll:1,trigger:"click",interTime:5000});
})(jQuery);
var xlmmnvss = $('fixed');
var xlmmnvssoffset = parseInt(fetchOffset(xlmmnvss)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop >= xlmmnvssoffset){
	if (BROWSER.ie && BROWSER.ie < 7) {
		xlmmnvss.style.position = 'absolute';
		xlmmnvss.style.top = xlmmm_scrollTop + 'px';
	}else{
		xlmmnvss.style.position = 'fixed';
		xlmmnvss.style.top = '0';
	xlmmnvss.className = 'fixed';
}
}else{
	xlmmnvss.className = '';
xlmmnvss.style.position = 'static';
		xlmmnvss.style.top = xlmmm_scrollTop + 'px';
}
});
var navs = $('userfixs');
var navsoffset = parseInt(fetchOffset(navs)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop >= navsoffset){
	if (BROWSER.ie && BROWSER.ie < 7) {
		navs.style.position = 'absolute';
		navs.style.top = xlmmm_scrollTop + 'px';
	}else{
		navs.innerHTML  = '<style>.userfix{ position:fixed; top:0px;}</style>';
	}
}else{
		navs.innerHTML  = '<style>.userfix{ position:static;}</style>';
		navs.style.top = xlmmm_scrollTop + 'px';
}
});

	    <!--{if $_G['cache']['plugin']['xlmmd']['xlmmjiazai'] == 3}-->
(function($){
    $(window).scroll(function() {
if ($(document).scrollTop() <= 0) { }

var srollPos = $(window).scrollTop();  
totalheight = parseFloat($(window).height()) + parseFloat(srollPos);  
            if(($(document).height()) <= totalheight) {

document.getElementById("xlmmsdj").click()

        }

})

})(jQuery)
					<!--{/if}-->
</script>

<!--{template common/footer}-->

