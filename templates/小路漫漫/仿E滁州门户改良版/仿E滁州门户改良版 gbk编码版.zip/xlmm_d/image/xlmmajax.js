var xlmmjz = {};
// ����
xlmmjz.xlmmloadlist = function(params){

	var target = jQuery(params.target);
	function before(){

		var loading = jQuery('<div class="loaders"><div class="ball-pulse"><div></div><div></div><div></div></div><div class="dropload">Loading...</div></div>').css({
			height:target.outerHeight() <= 52 ? 52 : target.outerHeight()
		});
		target.empty().append(loading);
	}

	function success(data){
		if(data.indexOf('<!--XLMMAJAX-->')>=0){
			target.html(data);

			if(params['scroll']){
			}
		}else{
			target.html(' <style>.empty-list {padding-top: 10%;padding-bottom: 10%; text-align:center;background: #fff;}.empty-list span {display: inline-block;font-size: 16px;line-height: 54px;position: relative; text-align:center;}</style><div class="empty-list"><img src=\"template/xlmm_d/image/nt.png\" width=\"62\" height=\"58\"><p><span>����ʧ�ܻ���Ȩ�����~</span></p></div>');
		}
	}
	if(window.xlmmloadonhttp){
		window.xlmmloadonhttp.abort();
		window.xlmmloadonhttp = null;
	}
	window.xlmmloadonhttp = jQuery.ajax({
		url:'forum.php?mod=forumdisplay&fid=' + params.fid + '&ajax=t',
		cache:false,
		beforeSend:before,
		success:success
	});
};

