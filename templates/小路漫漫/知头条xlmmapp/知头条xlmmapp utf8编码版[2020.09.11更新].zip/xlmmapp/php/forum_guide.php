<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$perpage = $_G['cache']['plugin']['xlmmappgl']['xlmmappglits'] ;
$page = intval($_GET['page']);
if($page<1) $page = 1;
$start = ($page-1)*$perpage;
	$pricount = 0;

$multi = '';
        $order= $_GET['order'];
 if($_GET['view'] == 'hot') {
$perpage = 50 ;
 $xlfid = $_G['cache']['plugin']['xlmmappgl']['xlmmappglrbfid'] ;
	$xlmmrfids=$xlfid ;
	$xlmmrtid= $_G['cache']['plugin']['xlmmappgl']['xlmmappglrbtid'] ;
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglrpx']== 1) {
   $order= 'lastpost';
}
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglrpx']== 2) {
   $order= 'dateline';
}
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglrpx']== 3) {
   $order= 'views';
}
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglrpx']== 4) {
   $order= 'replies';
}
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglrpx']== 5) {
   $order= 'digest';
}
       	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglrbxs']== 1) {
$xlmmstj = 'and views>=' . $_G['cache']['plugin']['xlmmappgl']['xlmmappglrbxss'] ;
		}else if($_G['cache']['plugin']['xlmmappgl']['xlmmappglrbxs']== 2) {
$xlmmstj = 'and replies>=' . $_G['cache']['plugin']['xlmmappgl']['xlmmappglrbxss'] ;
}
   	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglrbwt']== 2) {
$xlmmwt = 'and attachment=2' ;
}
}else{
$xlfid = $_G['cache']['plugin']['xlmmappgl']['xlmmappgltjid'] ;
	$xlmmfids=$xlfid ;
	$xlmmtid= $_G['cache']['plugin']['xlmmappgl']['xlmmappgltjtid'] ;
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglzpx']== 1) {
   $order= 'lastpost';
}
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglzpx']== 2) {
   $order= 'dateline';
}
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglzpx']== 3) {
   $order= 'views';
}
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglzpx']== 4) {
   $order= 'replies';
}
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappglzpx']== 5) {
   $order= 'digest';
}
     	if($_G['cache']['plugin']['xlmmappgl']['xlmmappgltjwt']== 2) {
$xlmmwt = 'and attachment=2' ;
}
}



      	if($_GET['view'] == 'follow') {
		   $xlmmusers = DB::fetch_all("SELECT a.uid,a.regdate,a.username,b.follower,b.threads,b.posts FROM ".DB::table("common_member")." a left join ".DB::table("common_member_count")." b on b.uid=a.uid WHERE a.adminid>=0 and a.uid NOT IN(" . $_G[uid] . ") ORDER BY a.credits DESC LIMIT 0 , 30");
$xlmmuidfav=DB::fetch_all("select followuid from ".DB::table("home_follow")." WHERE `uid` = $_G[uid]");
              foreach ($xlmmuidfav as $key => $xlmmuidfavs) {
                $xlmmuid .= "," . $xlmmuidfavs['followuid'] . "";
            }
                $xlmmuidfv .= "0" . $xlmmuid . "";
$count = DB::result_first("select count(*)  FROM ".DB::table("forum_thread")." WHERE authorid IN(" . $xlmmuidfv . ")  and displayorder>=0");
}else	if($_GET['view'] == 'hot') {
$count = DB::result_first("select count(*)  FROM ".DB::table("forum_thread")." WHERE fid NOT IN(" . $xlmmrfids . ") and tid NOT IN(" . $xlmmrtid . ") $xlmmstj and displayorder>=0  $xlmmwt ");
}else{
$count = DB::result_first("select count(*)  FROM ".DB::table("forum_thread")." WHERE fid NOT IN(" . $xlmmfids . ") and tid NOT IN(" . $xlmmtid . ")  and displayorder>=0 $xlmmwt");
}
	if($count) {
      	if($_GET['view'] == 'follow') {
					$grids['newthread'] = DB::fetch_all("SELECT tid,posttableid,fid,subject,authorid,author,dateline,recommend_add,recommend_sub,replies,views FROM ".DB::table('forum_thread')." WHERE authorid IN(" . $xlmmuidfv . ")  and displayorder>=0  ORDER BY lastpost DESC LIMIT $start , $perpage");
		
		}else if($_GET['view'] == 'hot') {
	$grids['newthread'] = DB::fetch_all("SELECT tid,posttableid,fid,subject,authorid,author,dateline,recommend_add,recommend_sub,replies,views FROM ".DB::table('forum_thread')." WHERE fid NOT IN(" . $xlmmrfids . ") and tid NOT IN(" . $xlmmrtid . ") $xlmmstj and displayorder>=0  $xlmmwt ORDER BY `$order` DESC LIMIT $start , $perpage");
}else{
	$grids['newthread'] = DB::fetch_all("SELECT tid,posttableid,fid,subject,authorid,author,dateline,recommend_add,recommend_sub,replies,views FROM ".DB::table('forum_thread')." WHERE fid NOT IN(" . $xlmmfids . ") and tid NOT IN(" . $xlmmtid . ")  and displayorder>=0 $xlmmwt  ORDER BY `$order` DESC LIMIT $start , $perpage");
}
				
				
	$_G['forum_colorarray'] = array('', '#EE1B2E', '#EE5023', '#996600', '#3C9D40', '#2897C5', '#2B65B7', '#8F2A90', '#EC1282');
	foreach($grids as $type => $gridthreads) {
			foreach($gridthreads as $key => $gridthread) {
				$gridthread['dateline'] = str_replace('"', '\'', dgmdate($gridthread['dateline'], 'u', '9999', getglobal('setting/dateformat')));
				$gridthread['lastpost'] = str_replace('"', '\'', dgmdate($gridthread['lastpost'], 'u', '9999', getglobal('setting/dateformat')));
				if($gridthread['highlight'] && $_G['setting']['grid']['highlight']) {
					$string = sprintf('%02d', $gridthread['highlight']);
					$stylestr = sprintf('%03b', $string[0]);

					$gridthread['highlight'] = ' style="';
					$gridthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
					$gridthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
					$gridthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
					$gridthread['highlight'] .= $string[1] ? 'color: '.$_G['forum_colorarray'][$string[1]] : '';
					$gridthread['highlight'] .= '"';
				} else {
					$gridthread['highlight'] = '';
				}
				if($_G['setting']['grid']['textleng']) {
					$gridthread['oldsubject'] = dhtmlspecialchars($gridthread['subject']);
				}

				$grids[$type][$key] = $gridthread;
			}
}
}
    print_r($xlmmals);
	 	if($_GET['view'] == 'follow') {
	$multi = multi($count, $perpage, $page, "portal.php?mod=portal&view=follow");
		}else if($_GET['view'] == 'hot') {
	$multi = multi($count, $perpage, $page, "portal.php?mod=portal&view=hot");
	}else{
$multi = multi($count, $perpage, $page, "portal.php?mod=portal");
}
       	if($_GET['view'] == 'follow') {
$xlaj = 'xlajp0';
$xlajul = 'portal.php?mod=portal&view=follow';
		}else if($_GET['view'] == 'hot') {
$xlaj = 'xlajp2';
$xlajul = 'portal.php?mod=portal&view=hot';
		}else {
$xlaj = 'xlajp1';
$xlajul = 'portal.php?mod=portal&view=';
}
//From: dis'.'m.t'.'ao'.'bao.com
?>


