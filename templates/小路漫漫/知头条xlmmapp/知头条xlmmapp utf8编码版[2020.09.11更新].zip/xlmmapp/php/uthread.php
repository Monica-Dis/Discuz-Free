<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: portal_comment.php 33660 2013-07-29 07:51:05Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$perpage = 20;
$page = intval($_GET['page']);
if($page<1) $page = 1;
$start = ($page-1)*$perpage;
	$pricount = 0;

$multi = '';

$count = DB::result_first("select count(*)  FROM ".DB::table("forum_thread")." WHERE authorid=$space[uid]  and displayorder>=0");
	if($count) {
   $xlmmuthread = DB::fetch_all("SELECT * FROM ".DB::table("forum_thread")."   WHERE authorid=$space[uid]  and displayorder>=0 ORDER BY dateline DESC LIMIT $start , $perpage");
}

$multipage = multi($count, $perpage, $page, "home.php?mod=space&uid=$space[uid]&do=profile");



?>




