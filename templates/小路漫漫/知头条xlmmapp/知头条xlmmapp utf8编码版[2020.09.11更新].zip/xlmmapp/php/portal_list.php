<?php

/**
 *      QQ dism.taobao.com 最后修改 2020
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$article_count = C::t('portal_article_count')->fetch($value['aid']); if($article_count) $value = array_merge($article_count, $value); 
$xlmm_all=DB::result_first("select content from ".DB::table("portal_article_content")." where aid='$value[aid]'");
preg_match_all("/<img.*?src=[\'|\"](.*?(?:[\.gif.*?[\/]?|\.jpg.*?[\/]?|\.jpeg.*?[\/]?|\.png.*?[\/]?|\.GIF.*?[\/]?|\.JPG.*?[\/]?|\.JPEG.*?[\/]?|\.PNG.*?[\/]?]))[\'|\"].*?[\/]?>/", $xlmm_all, $xlmmout);
       $xlmmoutimg = $xlmmout[1];
           $xlmmal = count($xlmmoutimg);
 ?>


