<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: portal_comment.php 33660 2013-07-29 07:51:05Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$perpage = 15;
$page = intval($_GET['page']);
if($page<1) $page = 1;
$start = ($page-1)*$perpage;
	$pricount = 0;

$multi = '';

$count = DB::result_first("select count(*)  FROM ".DB::table("portal_article_title")." WHERE uid=$space[uid] ");
	if($count) {
   $query = DB::fetch_all("SELECT * FROM ".DB::table("portal_article_title")." WHERE uid=$space[uid] ORDER BY dateline DESC LIMIT $start , $perpage");
		foreach($query as $value) {
			$value['catname'] = $value['catid'] == $cat['catid'] ? $cat['catname'] : $_G['cache']['portalcategory'][$value['catid']]['catname'];
			$value['onerror'] = '';
			if($value['pic']) {
				$value['pic'] = pic_get($value['pic'], '', $value['thumb'], $value['remote'], 1, 1);
			}
			$value['dateline'] = dgmdate($value['dateline']);
			if($value['status'] == 0 || $value['uid'] == $_G['uid'] || $_G['adminid'] == 1) {
				$list[] = $value;
			} else {
				$pricount++;
			}
		}
		if(strpos($cat['caturl'], 'portal.php') === false) {
			$cat['caturl'] .= 'index.php';
		}
	}

$multipage = multi($count, $perpage, $page, "home.php?mod=space&uid=$space[uid]&do=profile&wz=$space[uid]");



?>




