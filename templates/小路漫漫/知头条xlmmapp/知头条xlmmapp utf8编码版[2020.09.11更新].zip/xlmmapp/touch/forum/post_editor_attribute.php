<?php exit;?>
<style>

.xlmmcr_crgn {}
.xlmmcr_crgn .crgn_btqh {background-color: #fff;margin-bottom:15px;padding: 8px 12px;overflow: hidden;border-bottom: 1px solid #efefef;}
.xlmmcr_crgn .crgn_btqh li {float: left;margin-right: 12px;width: calc(33.33% - 12px);overflow: hidden;}
.xlmmcr_crgn .crgn_btqh li a {display: block;height: 16px;line-height: 16px;padding: 6px 0px;margin: 6px 0;color: #bbbbbb;border: 1px solid #dadada;border-radius: 30px; text-align:center;}
.xlmmcr_crgn .crgn_btqh li a i {float: left;font-size: 14px;padding-right: 5px;}
.xlmmcr_crgn .crgn_btqh .current a {color: #15bfff;border: 1px solid #15bfff;}
.xlmmcr_crgn .crgn_qhnr {background-color: #fff;border-top: 1px solid #efefef; border-bottom: 1px solid #efefef;}
.xlmmcr_crgn .crgn_qhnr .xlmmcr_crxm {display:none;}
.xlmmcr_crgn .crgn_qhnr .xlmmcr_crxm .crlj_srys {border-bottom: 1px solid #efefef;padding: 7px 0;margin: 0 12px;}
.xlmmcr_crgn .crgn_qhnr .xlmmcr_crxm .crlj_srys .athy_hsrk {width: 100%;line-height: 30px;border: none;outline: none;background-color: transparent;color: #666;font-size: 14px;}
.xlmmcr_crgn .crgn_qhnr .xlmmcr_crxm .crlj_cran {padding: 10px 0;margin: 0 12px;width: 70px;}
.xlmmcr_crgn .crgn_qhnr .xlmmcr_crxm .crlj_cran a {line-height: 30px; padding: 0 15px;font-size: 15px;text-align: center;overflow: hidden;border-radius: 20px;display: block;background: #15bfff;color: #fff;}


.crxm_xmzt {padding: 10px 0;margin: 0 12px;background: #fff;border-bottom: 1px solid #efefef;}
.crxm_xmzt .crgn_crsr {float: left;width: 80%;}
.crxm_xmzt .crgn_crsr .crsr_srys {width: 90%;line-height: 30px;border: none;outline: none;background-color: transparent;color: #666;font-size: 14px;}
.crxm_xmzt .crgn_crqr {float: right;width: 20%;}
.crxm_xmzt .crgn_crqr a {line-height: 30px;padding: 0 15px;font-size: 15px;text-align: center;overflow: hidden;border-radius: 20px;display: block;background: #15bfff;color: #fff;}
.crgn_crts {padding: 12px 0;margin: 0 12px;color: #ff9900;font-size: 12px;}
.crxm_xmzt .crgn_crsrs {width: 100%;}
.crxm_xmzt .crgn_crsrs .crsr_wbsr {width: 96%;padding: 2%;min-height: 80px; border: 0;background: #f8f8f8;font-size: 14px;border-radius: 0;color: #000;outline: none;-webkit-appearance: none;}
.crxm_xmzt .crgn_crqrs {margin-top: 5px;width:70px;}
.crxm_xmzt .crgn_crqrs a {line-height: 30px;padding: 0 15px;font-size: 15px;text-align: center;overflow: hidden;border-radius: 20px;display: block;background: #15bfff;color: #fff;}


</style>
<div class="ztfb_gdcz cl">

<div id="xlmmfcrbq_post_tab">
<div class="exfm xlmmfcrbq_bqbox bg_f b_b cl" id="crbqs" style="display:none; margin-top:5px;">
<div class="bqbox_t b_t cl">
<ul id="xlmmfcrbq_smilies_key"></ul>
</div>
<div class="xlmmfcrbq_smiley_box b_t">
<div class="swiper-wrapper bqbox_c xlmmfcrbq_optimization"></div>
<div class="bqbox_b cl"></div>
</div>
</div>
</div>

			<div class="exfm cl"  id="fjcr" style="display:none; background:none;">
		    <div class="xlmmcr_crgn cl">
				<ul class="crgn_btqh cl">
					<li><a href="JavaScript:void(0)">@好友</a></li>
					<li><a href="JavaScript:void(0)">插入链接</a></li>
					<li><a href="JavaScript:void(0)">网络图片</a></li>
					<li><a href="JavaScript:void(0)">MP3</a></li>
					<li><a href="JavaScript:void(0)">视频地址</a></li>
					<li><a href="JavaScript:void(0)">flash</a></li>
					<li><a href="JavaScript:void(0)">引用</a></li>
					<li><a href="JavaScript:void(0)">代码内容</a></li>
					<li><a href="JavaScript:void(0)">免费信息</a></li>
				</ul>
				<div class="crgn_qhnr cl">
					<div class="xlmmcr_crxm cl">
						<div class="crxm_xmzt cl">
							<div class="crgn_crsr"><input type="text" name="text" placeholder="请输入用户名" id="fbcrwlat" class="crsr_srys"></div>
							<div class="crgn_crqr"><a href="javascript:;" id="fbcrwlatqr">添加</a></div>
						</div>
						<div class="crgn_crts cl">@好友，让更多人看见本帖。</div>
						<script type="text/javascript">
							$('#fbcrwlatqr').click(function(){
								console.log($("#fbcrwlat").val());
									if($("#fbcrwlat").val() == ''){
									alert('请输入会员名');
								return false;
								}else{
									$("#needmessage").val($("#needmessage").val()+"@"+$("#fbcrwlat").val()+" ");
								return false;
								}
							});
						</script>
					</div>
					<div class="xlmmcr_crxm cl">
						<div class="crlj_srys cl"><input type="text" name="text" placeholder="请输入链接文字" id="fbcrljwz" class="athy_hsrk"></div>
						<div class="crlj_srys cl"><input type="text" name="text" placeholder="请输入链接网址" id="fbcrljlj" class="athy_hsrk"></div>
						<div class="crlj_cran cl"><a href="javascript:;" id="btn_inputljtj">插入</a></div>
						<script type="text/javascript">
							$('#btn_inputljtj').click(function(){
								console.log($("#fbcrljwz").val());
								if($("#fbcrljwz").val() == ''){
									alert('请输入内容');
								return false;
							}else{
									$("#needmessage").val($("#needmessage").val()+"[url="+$("#fbcrljlj").val()+"]"+$("#fbcrljwz").val()+"[/url]");
								return false;
								}
							});
						</script>
					</div>
					<div class="xlmmcr_crxm cl">
						<div class="crxm_xmzt cl">
							<div class="crgn_crsr"><input type="text" name="text" placeholder="请输入网络图片网址" id="fbcrwltp" class="crsr_srys"></div>
							<div class="crgn_crqr"><a href="javascript:;" id="fbcrwltpqr">插入</a></div>
						</div>
						<script type="text/javascript">
							$('#fbcrwltpqr').click(function(){
								console.log($("#fbcrwltp").val());
									if($("#fbcrwltp").val() == ''){
									alert('请输入网络图片网址');
								return false;
								}else{
									$("#needmessage").val($("#needmessage").val()+"[img]"+$("#fbcrwltp").val()+"[/img]");
								return false;
								}
							});
						</script>
					</div>
					<div class="xlmmcr_crxm cl">
						<div class="crxm_xmzt cl">
							<div class="crgn_crsr"><input type="text" name="text" placeholder="请输入MP3网址" id="fbcrmp3" class="crsr_srys"></div>
							<div class="crgn_crqr"><a href="javascript:;" id="fbcrmp3qr">插入</a></div>
						</div>
						<div class="crgn_crts cl">支持 wma mp3 ra rm 等音乐格式网址</div>
						<script type="text/javascript">
							$('#fbcrmp3qr').click(function(){
								console.log($("#fbcrmp3").val());
									if($("#fbcrmp3").val() == ''){
									alert('请输入MP3网址');
								return false;
								}else{
									$("#needmessage").val($("#needmessage").val()+"[audio]"+$("#fbcrmp3").val()+"[/audio]");
								return false;
								}
							});
						</script>
					</div>
					<div class="xlmmcr_crxm cl">
						<div class="crxm_xmzt cl">
							<div class="crgn_crsr"><input type="text" name="text" placeholder="请插入视频网址" id="fbcrsp" class="crsr_srys"></div>
							<div class="crgn_crqr"><a href="javascript:;" id="fbcrspqr">插入</a></div>
						</div>
						<div class="crgn_crts cl">支持优酷、腾讯、iqiyi等视频网址</div>
						<script type="text/javascript">
							$('#fbcrspqr').click(function(){
								console.log($("#fbcrsp").val());
									if($("#fbcrsp").val() == ''){
									alert('请插入视频网址');
								return false;
								}else{
									$("#needmessage").val($("#needmessage").val()+"[media=x,500,380]"+$("#fbcrsp").val()+"[/media]");
								return false;
								}
							});
						</script>
					</div>
					<div class="xlmmcr_crxm cl">
						<div class="crxm_xmzt cl">
							<div class="crgn_crsr"><input type="text" name="text" placeholder="请插入flash网址" id="fbcrfls" class="crsr_srys"></div>
							<div class="crgn_crqr"><a href="javascript:;" id="fbcrflsqr">插入</a></div>
						</div>
						<div class="crgn_crts cl">支持 swf flv 格式Flash文件网址</div>
						<script type="text/javascript">
							$('#fbcrflsqr').click(function(){
								console.log($("#fbcrfls").val());
									if($("#fbcrfls").val() == ''){
									alert('请插入flash网址');
								return false;
								}else{
									$("#needmessage").val($("#needmessage").val()+"[flash]"+$("#fbcrfls").val()+"[/flash]");
								return false;
								}
							});
						</script>
					</div>
					<div class="xlmmcr_crxm cl">
						<div class="crxm_xmzt cl">
							<div class="crgn_crsrs"><textarea placeholder="请输入需要插入的引用" id="fbcryy" class="crsr_wbsr"></textarea></div>
							<div class="crgn_crqrs"><a href="javascript:;" id="fbcryyqr">插入</a></div>
						</div>
						<script type="text/javascript">
							$('#fbcryyqr').click(function(){
								console.log($("#fbcryy").val());
									if($("#fbcryy").val() == ''){
									alert('请输入需要插入的引用');
								return false;
								}else{
									$("#needmessage").val($("#needmessage").val()+"[quote]"+$("#fbcryy").val()+"[/quote]");
								return false;
								}
							});
						</script>
					</div>
					<div class="xlmmcr_crxm cl">
						<div class="crxm_xmzt cl">
							<div class="crgn_crsrs"><textarea placeholder="请输入需要插入的代码" id="fbcrdm" class="crsr_wbsr"></textarea></div>
							<div class="crgn_crqrs"><a href="javascript:;" id="fbcrdmqr">插入</a></div>
						</div>
						<script type="text/javascript">
							$('#fbcrdmqr').click(function(){
								console.log($("#fbcrdm").val());
									if($("#fbcrdm").val() == ''){
									alert('请输入需要插入的代码');
								return false;
								}else{
									$("#needmessage").val($("#needmessage").val()+"[code]"+$("#fbcrdm").val()+"[/code]");
								return false;
								}
							});
						</script>
					</div>
					<div class="xlmmcr_crxm cl">
						<div class="crxm_xmzt cl">
							<div class="crgn_crsrs"><textarea placeholder="请输入购买付费内容前可免费阅读的内容" id="fbcrmf" class="crsr_wbsr"></textarea></div>
							<div class="crgn_crqrs"><a href="javascript:;" id="fbcrmfqr">插入</a></div>
						</div>
						<script type="text/javascript">
							$('#fbcrmfqr').click(function(){
								console.log($("#fbcrmf").val());
									if($("#fbcrmf").val() == ''){
									alert('请输入购买付费内容前可免费阅读的内容');
								return false;
								}else{
									$("#needmessage").val($("#needmessage").val()+"[free]"+$("#fbcrmf").val()+"[/free]");
								return false;
								}
							});
						</script>
					</div>
				</div>
			</div>
			<script>
	(function ($) { 
		$('.xlmmcr_crgn ul.crgn_btqh li a').click(function (g) { 
			var tab = $(this).closest('.xlmmcr_crgn'), 
				index = $(this).closest('li').index();
			
			tab.find('ul.crgn_btqh > li').removeClass('current');
			$(this).closest('li').addClass('current');
			
			tab.find('.crgn_qhnr').find('div.xlmmcr_crxm').not('div.xlmmcr_crxm:eq(' + index + ')').slideUp();
			tab.find('.crgn_qhnr').find('div.xlmmcr_crxm:eq(' + index + ')').slideDown();
			
			g.preventDefault();
		} );
	})(jQuery);
</script>
		</div>
	<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
			<!--{if $_G['group']['maxprice'] && !$special}-->
				<div id="ztcs" style="display:none;" class="exfm cl" >
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z">{lang price}</div>
						<div class="czxm_xmnr z"><input type="text" id="price" name="price" class="px" placeholder="{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} {lang post_price_comment}" value="$thread[pricedisplay]" onblur="extraCheck(2)" /></div>
					</div>
					<div class="gdcz_czts cl">
					<!--{if $_G['group']['maxprice'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
						<!--{if $_G['setting']['maxincperthread']}--><p>{lang post_price_income_comment}</p><!--{/if}-->
						<!--{if $_G['setting']['maxchargespan']}--><p>{lang post_price_charge_comment}<!--{if $_GET[action] == 'edit' && $freechargehours}-->{lang post_price_free_chargehours}<!--{/if}--></p><!--{/if}-->
					<!--{/if}-->
					</div>
				</div>
			<!--{/if}-->
			<!--{if $_G['group']['allowposttag']}-->
				<div id="ztbq" style="display:none;" class="exfm cl" >
					<table cellspacing="0" cellpadding="0">
						<div class="gdcz_czxm cl">
							<div class="czxm_xmbt z">{lang post_tag}</div>
							<div class="czxm_xmnr z"><input type="text" class="px" placeholder="{lang auto_keyword}" size="60" id="tags" name="tags" value="$postinfo[tag]" onblur="extraCheck(4)" /></div>
						</div>
					</table>
				</div>
			<!--{/if}-->
			<!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
				<div class="exfm cl" id="qlzt" style="display:none;" >
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z">{lang rushreply_change}</div>
						<div class="czxm_xmnr z"><input type="checkbox" name="rushreply" id="rushreply" value="1" {if $_GET[action] == 'edit' && getstatus($thread['status'], 3)}disabled="disabled" checked="checked"{/if} onclick="extraCheck(3)" /><label for="rushreply" id="rushreply" class="y"></label></div>
					</div>
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z">{lang rushreply_time}</div>
						<div class="czxm_xmnr z"><input type="text" name="rushreplyfrom" id="rushreplyfrom" class="px" onclick="showcalendar(event, this, true)" autocomplete="off" value="$postinfo[rush][starttimefrom]" onkeyup="$('rushreply').checked = true;" /></div>
					</div>
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z">抢楼截止</div>
						<div class="czxm_xmnr z"><input type="text" onclick="showcalendar(event, this, true)" autocomplete="off" id="rushreplyto" name="rushreplyto" class="px"  value="$postinfo[rush][starttimeto]" onkeyup="$('rushreply').checked = true;" /></div>
					</div>
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z">{lang rushreply_rewardfloor}</div>
						<div class="czxm_xmnr z"><input type="text" name="rewardfloor" id="rewardfloor" class="px" value="$postinfo[rush][rewardfloor]" onkeyup="$('rushreply').checked = true;" /></div>
					</div>						
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z">{lang stopfloor}</div>
						<div class="czxm_xmnr z"><input type="text" name="replylimit" id="replylimit" class="px" placeholder="{lang replylimit}" autocomplete="off" value="$postinfo[rush][replylimit]" onkeyup="$('rushreply').checked = true;" /></div>
					</div>
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z">{lang rushreply_end}</div>
						<div class="czxm_xmnr z"><input type="text" name="stopfloor" id="stopfloor" class="px" autocomplete="off" value="$postinfo[rush][stopfloor]" onkeyup="$('rushreply').checked = true;" /></div>
					</div>
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z"><!--{if $_G['setting']['creditstransextra'][11]}-->{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]}<!--{else}-->{lang credits}<!--{/if}-->{lang min_limit}</div>
						<div class="czxm_xmnr z"><input type="text" name="creditlimit" id="creditlimit" class="px" autocomplete="off" value="$postinfo[rush][creditlimit]" onkeyup="$('rushreply').checked = true;" /></div>
					</div>
				</div>
			<!--{/if}-->
		<!--{/if}-->

		<div class="exfm cl" id="fjxx" style="display:none;" >
			<table cellspacing="0" cellpadding="0">
				<!--{if $_GET[action] != 'edit'}-->
					<!--{if $_G['group']['allowanonymous']}-->
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z">{lang post_anonymous}</div>
						<div class="czxm_xmnr z"><input type="checkbox" name="isanonymous" id="isanonymous" value="1" /><label for="isanonymous" id="isanonymous" class="y"></label></div>
					</div>
					<!--{/if}-->
				<!--{else}-->
					<!--{if $_G['group']['allowanonymous'] || (!$_G['group']['allowanonymous'] && $orig['anonymous'])}-->
					<div class="gdcz_czxm cl">
						<div class="czxm_xmbt z">{lang post_anonymous}</div>
						<div class="czxm_xmnr z"><input type="checkbox" name="isanonymous" id="isanonymous" value="1" {if $orig['anonymous']}checked="checked"{/if} /><label for="isanonymous" id="isanonymous" class="y"></label></div>
					</div>
					<!--{/if}-->
				<!--{/if}-->
				<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
				<div class="gdcz_czxm cl">
					<div class="czxm_xmbt z">{lang hiddenreplies}</div>
					<div class="czxm_xmnr z"><input type="checkbox" name="hiddenreplies" id="hiddenreplies" {if $thread['hiddenreplies']} checked="checked"{/if} value="1"><label for="hiddenreplies" id="hiddenreplies" class="y"></label></div>
				</div>
				<!--{/if}-->
				<!--{if $_G['uid'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost) && $special != 3}-->
				<div class="gdcz_czxm cl">
					<div class="czxm_xmbt z">{lang post_descviewdefault}</div>
					<div class="czxm_xmnr z"><input type="checkbox" name="ordertype" id="ordertype" value="1" $ordertypecheck /><label for="ordertype" id="ordertype" class="y"></label></div>
				</div>
				<!--{/if}-->
				<!--{if ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
				<div class="gdcz_czxm cl">
					<div class="czxm_xmbt z">{lang post_noticeauthor}</div>
					<div class="czxm_xmnr z"><input type="checkbox" name="allownoticeauthor" id="allownoticeauthor" value="1"{if $allownoticeauthor} checked="checked"{/if} /><label for="allownoticeauthor" id="allownoticeauthor" class="y"></label></div>
				</div>
				<!--{/if}-->
				<!--{if $_GET[action] != 'edit' && helper_access::check_module('feed') && $_G['forum']['allowfeed']}-->
				<div class="gdcz_czxm cl">
					<div class="czxm_xmbt z">{lang addfeed}</div>
					<div class="czxm_xmnr z"><input type="checkbox" name="addfeed" id="addfeed" value="1" $addfeedcheck><label for="addfeed" id="addfeed" class="y"></label></div>
				</div>
				<!--{/if}-->
			</table>
		</div>
	</div>











