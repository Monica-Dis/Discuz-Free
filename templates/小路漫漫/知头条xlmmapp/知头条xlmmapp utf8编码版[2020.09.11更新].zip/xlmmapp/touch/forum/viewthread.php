<?php exit;?>
<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="template/xlmmapp/m-img/viewthread.css"/>

<div class="xlmmthftc cl">
	<a {if $_G['uid']} onClick="nryhf()" {else}href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}"{/if}class="nrdb_hf {if $_G['uid']}{else}dialog{/if}">说点什么吧...</a>
	<a onClick="nrywfx()"><i class="iconfont iconfx"></i></a>
             <!--{eval $fav=DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='tid' and id=".$_G[tid]."");}-->
	<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}" class="dialog"><i {if $fav[id]}style="color:#f15450" {/if}class="iconfont iconsc"></i><em id="favoritenumber"{if !$_G['forum_thread']['favtimes']} style="display:none"{/if}>{$_G['forum_thread']['favtimes']}</em></a>
	<a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" class="dialog"><i {if C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $_G['tid'])}style="color:#f15450" {/if}class="iconfont icondin"></i><em id="recommendv_add"{if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>$_G[forum_thread][recommend_add]</em></a>
</div>

<style>
.dialogbox {
    width: 300px !important; text-align:center
}
.button {
    width: 48px;}
 .favor-wrapper {position: absolute;top: 50%;right: 0;-webkit-transform: translateY(-50%);}
 .article-info .dot {display: inline-block;width: 2px;height: 2px;border-radius: 1px;background-color: #999;   margin: 0 8px;vertical-align: middle;}
.xlmm_rec_alert { padding: 10px 16px;color: #fff; background: rgba(0,0,0,0.65);border-radius: 3px; font-size: 14px;font-weight: 100;}
p.ycbr { height:2px;}
.message .blockcode {padding: 0px 0px 0px 32px;margin: 10px 0;border: 1px dashed #d7d7d7;background: #eee;overflow: hidden;}
.message .blockcode div {border-left: 1px solid #d7d7d7;background: #f9f9f9;padding: 10px 6px 10px 0px;}
.message .blockcode ol {margin-left: 0px !important;padding: 0 !important;}
.message .blockcode ol li {padding-left: 10px;list-style-type: decimal-leading-zero;font-size: 12px;line-height: 1.8em;}
.message .showhide {padding: 10px;margin: 10px 0px;border: 1px dashed #e6e6e6;font-size: 14px;background: #f8f8f8;overflow: hidden;}
.message .showhide h4 {font-weight: 100;color: #f66;text-align: center;margin-bottom: 5px;font-size: 14px;}
.message .lcsdjg {padding: 4px 8px;text-align: center;line-height: 16px;font-size: 12px;color: #F60;border: 1px solid #f60;border-radius: 3px;position: absolute;top: 20px;right: 10px;z-index: 1;-webkit-transform: rotate(25deg); -moz-transform: rotate(25deg);-ms-transform: rotate(25deg);-o-transform: rotate(25deg);transform: rotate(25deg);overflow: hidden;}
.plc .pi .message .quote {background: #f8f8f8;}
.message .jammer {color: #fff;}
.box.attach {
    position: static;
    text-align: center;
}
.box.attach img{ width:25px !important;}</style>
<!--{eval $_G['forum_thread']['starttime'] = dgmdate($_G['forum_thread']['dateline'], 'Y-m-d H:i');}-->
<!--{hook/viewthread_top_mobile}-->
<div class="xl-ts">
    <dl>
        <dt>
            {$_G[forum_thread][subject]}
            <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
            <!--{/if}-->
        </dt>
    </dl>       
</div>

<div class="postlist">
	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
	<!--{hook/viewthread_posttop_mobile $postcount}-->
<div id="ycbr">
   <div class="plc cl {if $post['first']}tfirst{else}nfirst{/if}" id="pid$post[pid]">
       <div class="display pi">
       
           <div class="xl-tsin">
               <dl class="cl">
                   <dt> <a href="home.php?mod=space&uid=$post[authorid]&do=profile"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, big, true)}--><!--{else}--><!--{avatar($post[authorid], big, true)}--><!--{/if}-->" /></a></dt>
                   <dd class="dd1">
                       <div class="s1 cl">
                           <span class="ss1">
					       <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
							   <a href="home.php?mod=space&uid=$post[authorid]&do=profile">$post[author]</a>
						   <!--{else}-->
							   <!--{if !$post['authorid']}-->
							   <a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
							   <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
							   <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
							   <!--{else}-->
							   $post[author] <em>{lang member_deleted}</em>
							   <!--{/if}-->
						   <!--{/if}-->
                           </span>
                           <span style="font-size: 10px;-webkit-text-size-adjust: none;color: #fff;border-radius: 2px;-webkit-border-radius: 2px;-o-border-radius: 2px;-moz-border-radius: 2px;-ms-border-radius: 2px;display: inline-block;margin-left: 5px;zoom: 1; margin-top:5px;background: #a0c9ff;line-height: 13px;padding: 0 3px; text-align: center;">LV.{$post[stars]}</span>
                       </div>
                       <div class="s2"<!--{if $post['first']}-->  style="position:relative;"<!--{/if}-->  >
						 <!--{if $post['first']}--> 
                              <div class="favor-wrapper">
<span class="article-info"><span class="new-style-test-article-publish-time">$_G[forum_thread][views]次查看</span><span class="dot"></span><span class="new-style-test-article-comment">$_G[forum_thread][allreplies]条评论</span></span>    </div>
  	               <div id="fss"></div>
					   <!--{else}-->
       <!--{if $post[number] == -1}-->
							{lang recommend_post}
						   <!--{else}-->
							{$post[number]}楼
						   <!--{/if}-->                     
						   <!--{/if}-->                     
                        </div> 
                   </dd>
                   <dd class="dd2">
{$post[dateline]}</dd>
               </dl>
           </div>

		   <div class="message">
                	<!--{if $post['warned']}-->
                        <span class="grey quote">{lang warn_get}</span>
                    <!--{/if}-->
                    <!--{if !$post['first'] && !empty($post[subject])}-->
                        <h2><strong>$post[subject]</strong></h2>
                    <!--{/if}-->
                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                        <div class="grey quote">{lang message_banned}</div>
                    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                        <div class="grey quote">{lang message_single_banned}</div>
                    <!--{elseif $needhiddenreply}-->
                        <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
                    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
						<!--{template forum/viewthread_pay}-->
					<!--{else}-->

                    	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                            <div class="grey quote">{lang admin_message_banned}</div>
                        <!--{elseif $post['status'] & 1}-->
                            <div class="grey quote">{lang admin_message_single_banned}</div>
                        <!--{/if}-->
                        <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                            {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
                        <!--{/if}-->

                        <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                        	<!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                                <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                    {lang has_expired}
                                <!--{else}-->
                                    <div class="box_ex2 viewsort">
                                        <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                                    <!--{loop $threadsortshow['optionlist'] $option}-->
                                        <!--{if $option['type'] != 'info'}-->
                                            $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                                        <!--{/if}-->
                                    <!--{/loop}-->
                                    </div>
                                <!--{/if}-->
                            <!--{/if}-->
                        <!--{/if}-->
                        <!--{if $post['first']}-->
                  
                        
 	<!--{if $post['first']}--> 
		<!--{if $threadsortshow}-->
			<!--{if $threadsortshow['typetemplate']}-->
				$threadsortshow[typetemplate]
			<!--{elseif $threadsortshow['optionlist']}-->
				<div class="typeoption">
					<!--{if $threadsortshow['optionlist'] == 'expire'}-->
						{lang has_expired}
					<!--{else}-->
						<table summary="{lang threadtype_option}" cellpadding="0" cellspacing="0" class="cgtl mbm" width="100%">
							<caption>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</caption>
							<tbody>
								<!--{loop $threadsortshow['optionlist'] $option}-->
									<!--{if $option['type'] !== 'info'}-->
                                    <!--{if $option['type'] !== 'image'}-->
										<tr>
											<th>$option[title]</th>
											<td><!--{if $option['value'] || ($option['type'] == 'number' && $option['value'] !== '')}-->$option[value] $option[unit]<!--{else}-->-<!--{/if}--></td>
										</tr>
									<!--{/if}-->
                                    <!--{/if}-->
								<!--{/loop}-->
							</tbody>
						</table>
					<!--{/if}-->
				</div>
			<!--{/if}-->
		<!--{/if}-->
	<!--{/if}-->
                        

                            <!--{if !$_G[forum_thread][special]}-->
                                $post[message]
                            <!--{elseif $_G[forum_thread][special] == 1}-->
                                <!--{template forum/viewthread_poll}-->
                            <!--{elseif $_G[forum_thread][special] == 2}-->
                                <!--{template forum/viewthread_trade}-->
                            <!--{elseif $_G[forum_thread][special] == 3}-->
                                <!--{template forum/viewthread_reward}-->
                            <!--{elseif $_G[forum_thread][special] == 4}-->
                                <!--{template forum/viewthread_activity}-->
                            <!--{elseif $_G[forum_thread][special] == 5}-->
                                <!--{template forum/viewthread_debate}-->
                            <!--{elseif $threadplughtml}-->
                                $threadplughtml
                                $post[message]
                            <!--{else}-->
                            	$post[message]
                            <!--{/if}-->
                        <!--{else}-->
                            $post[message]
                        <!--{/if}-->

					<!--{/if}-->
			</div>
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->

			<!--{if $post['attachment']}-->
               <div class="grey quote">
               {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
               </div>
            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
               <!--{if $post['imagelist']}-->
				<!--{if count($post['imagelist']) == 1}-->
				<ul class="img_one">{echo showattach($post, 1)}</ul>
				<!--{else}-->
				<ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
				<!--{/if}-->
				<!--{/if}-->
                <!--{if $post['attachlist']}-->
				<ul>{echo showattach($post)}</ul>
				<!--{/if}-->
			<!--{/if}-->
		   <!--{/if}-->
 	<!--{if $post['first']}--> 

		   <style>
		   
.support_con{/*margin-top: 0.7rem;*/margin-top: 0.3rem;}
.support_con .inside{background: #ffffff;padding-bottom: 0.16rem;}
.support_con .support_btn{width: 2.2rem;height: 0.76rem;line-height: 0.76rem;text-align: center;background: #ff795c;font-size: 0.32rem;display: block;margin: 0 auto;color: #ffffff;border-radius: 4px;}
.support_con .support_btn.grey{background: #bbbbbb;color: #ffffff;}
.support_con .support_num{font-size: 0.28rem;color: #999999;text-align: center;/*margin-top:0.62rem;*/margin-top:0.3rem;margin-bottom: 0.3rem;}
.support_con .support_num .num{color:#666666;}
.support_con .avatar_line{font-size:0;margin: 0 0.34rem;}
.support_con .avatar_line .avatar_inside{width:5.67rem;margin:0 auto;max-height:2rem;overflow: hidden;text-align:center;}
.support_con .avatar_line a{display: inline-block;zoom: 1;overflow:hidden;width: 0.52rem;height: 0.52rem;margin: 0 0.06rem 0.18rem 0.05rem;border-radius: 0.56rem;}
.support_con .avatar_line a img{display: block;width: 100%;height: 100%;border-radius: 0.56rem;}
.support_con .avatar_line.textAlign{text-align: center;}
span.fffff{font-size:12px; margin-left:5px; color: #666;}
           
           
           </style>
  <div class="support_con">
                <div class="inside">
  							<!--{eval $recommend_users = DB::fetch_all("SELECT a.recommenduid,a.dateline,b.username,b.uid FROM ".DB::table('forum_memberrecommend')." a LEFT JOIN ".DB::table('common_member')." b on b.uid=a.recommenduid WHERE a.`tid` = '$_G[tid]' AND b.`status`=0 ORDER BY a.`dateline` DESC LIMIT 0,20");}-->
                  
                        <a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" class="support_btn deepshare dialog" >{if C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $_G['tid'])}已支持{else}支持楼主{/if}</a>
                    <p class="support_num"><span class="num">$_G[forum_thread][recommend_add]</span>人支持</p>
                    <div class="avatar_line clearfix deepshare">
                        <div class="avatar_inside clearfix">
          										<!--{loop $recommend_users $rdu}-->
										<a href="home.php?mod=space&uid={$rdu['uid']}"><img src="uc_server/avatar.php?uid={$rdu['uid']}&size=big" class="icon_lazy"/></a>
										<!--{/loop}-->
                                                                                    </div>
                    </div>

                </div>
            </div>
             		   <!--{/if}-->
										<!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
<form id="bestanswersubmit" method="post" autocomplete="off" action="forum.php?mod=misc&action=bestanswer&tid=$_G[tid]&pid=$post[pid]&bestanswersubmit=yes">
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="hidden" name="referer" value="{echo dreferer()}" />
						<input type="hidden" name="tid" value="$_G[tid]" />
						<input type="hidden" name="pid" value="$post[pid]" />
						<button type="submit" name="bestanswersubmit" class="xlmmmyda" value="true">{lang reward_set_bestanswer}</button>
					</form>
						<!--{/if}-->


           <div class="xlmm-ts_b">
                <div style="float:left; color: #5b83ae; font-size:14px;">
         	    #<!--{if $post['invisible'] == 0}-->
					<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
                    	<!--{if $ordertype != 1}-->
{if $post['first']}<a href="forum.php?mod=viewthread&tid=$post[tid]&page=$page&authorid=$_G[forum_thread][authorid]" rel="nofollow" style="color: #5b83ae;" >只看楼主</a>{else}<a href="forum.php?mod=viewthread&tid=$post[tid]&page=$page&authorid=$post[authorid]" rel="nofollow" style="color: #5b83ae;">{lang thread_show_author}</a>{/if}

        
                                <!--{else}-->
							<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2" style="color: #5b83ae;">{lang post_ascview}</a>


						<!--{/if}-->
					<!--{elseif !$_G['forum_thread']['archiveid']}-->
						<a href="forum.php?mod=viewthread&tid=$post[tid]&page=$page" class="mhr2" rel="nofollow" onMouseOver="showMenu({'ctrlid':'mtsw_pic'});" style="color: #5b83ae;">阅读全部</a>
			    <!--{/if}-->
                <!--{/if}-->#
            					<!--{if !($_G['setting']['threadguestlite'] && !$_G['uid'])}-->
					<!--{if $post[authorid] != $_G[uid]}-->
  <a href="home.php?mod=space&do=pm&subop=view&touid=$post[authorid]" style="margin-left:5px">{lang send_pm}</a>
 					<!--{/if}-->
				<!--{/if}-->                     

</div>
              <div class="xlmm-ts_b_menu xl-tpost cl">
        <!--{if $post['invisible'] == 0}-->
            <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" class="btn-action reply"></a>
      					<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
					<a class="btn-action like recssbtn  {if $_G['uid']}dialog{/if}" href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}">$post[postreview][support]</a>
					<!--{/if}-->

               <!--{/if}-->
               <!--{if $_G['forum']['ismoderator']}-->
                   <!--{if $post[first]}-->
						<a href="#moption_$post[pid]" class="popup blue" onclick="return false" >{lang manage}</a>
						<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
							<!--{if !$_G['forum_thread']['special']}-->
							<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
							<!--{/if}-->
							<input type="button" value="{lang delete}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
							<input type="button" value="{lang close}" class="dialog button" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
							<input type="button" value="{lang admin_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
							<input type="button" value="{lang topicadmin_warn_add}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
						</div>
					<!--{else}-->
						<a href="#moption_$post[pid]" class="popup blue">{lang manage}</a>
						<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
							<input type="button" value="{lang edit}" class="redirect button" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
							<!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog button" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
							<!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog button" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->

							<!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog button" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
						</div>
                   <!--{/if}-->
               <!--{/if}-->
               </div>       
               
               <!--{if $_GET['from'] != 'preview' && $_G['setting']['commentnumber'] && !empty($comments[$post[pid]])}-->
               <div id="comment_$post[pid]" class="xlmm-dp">
                   <em></em>
                   <ul>
                   <!--{loop $comments[$post[pid]] $comment}-->
                   <li>
                       <div class="xlmm-dp_li cl">
                       <span class="s1"><!--{if $comment['authorid']}--><a href="home.php?mod=space&uid=$comment[authorid]">$comment[author]<!--{if $comment[authorid] == $_G[forum_thread][authorid]}--><i>楼主</i><!--{/if}-->：</a><!--{else}-->{lang guest}<!--{/if}--></span><span class="s2">{$comment[comment]}</span>
                       <span class="s3"><!--{date($comment[dateline], 'u')}--></span>
                       </div>
                   </li>
                   <!--{/loop}-->
                   </div>
               </div>
               <!--{/if}-->


           </div>
           <!--viewthread main botom end-->
   </div>
 </div>
    
					<!--{if $post['first'] && ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
				<!--{if $post[tags]}-->
<style>

.xttag { margin: 15px 0 0;border-bottom: 10px solid #f4f5f6; padding-bottom:12px}
.xttagli { display: inline-block;font-size: 13px;color: #bbb; border: 1px solid currentColor;  background-color: #fff;margin: 3px 5px; text-align: center;}
 .xttaglih {height: 28px; line-height: 28px;  -webkit-tap-highlight-color: rgba(255,0,0,0);}
.iconbq:before{content:'\E015'; margin-right:8px;}

</style>
    <div class="ms_title point5 cl">
            <span class="z plr15" style="border:0; padding-left:0"><i class="iconfont iconbq colour"></i>本帖标签</span>
        </div>        
<div class="xttag plr15">
<ul>
					<!--{eval $tagi = 0;}-->
					<!--{loop $post[tags] $var}-->
<li class="xttagli"><a title="$var[1]" href="misc.php?mod=tag&id=$var[0]" class="xttaglih plr15">$var[1]</a></li>
						<!--{eval $tagi++;}-->
					<!--{/loop}-->
</ul>
</div>
            <!--{/if}-->

          <!--{/if}-->

		<!--{if $post['relateitem']}-->
			<div style="border-bottom: 10px solid #f4f5f6;">
    <div class="ms_title point5 white cl">
            <span class="z plr15">{lang related_thread}</span>
        </div>        
				<ul class="plr15 cl xlmmmgtit">
								<!--{eval $tagsi = 0;}-->
	<!--{loop $post['relateitem'] $var}-->
					<li style="white-space: nowrap;text-overflow: ellipsis;">&#8226; <a href="forum.php?mod=viewthread&tid=$var[tid]" title="$var[subject]">$var[subject]</a></li>
									<!--{eval $tagsi++;}-->
			<!--{eval if($tagsi==6) break;}-->
		<!--{/loop}-->
				</ul>
			</div>
		<!--{/if}-->

  	<!--{if $post['first']}--> 
    <div class="ms_title point5 cl">
            <span class="z plr15">全部评论</span>
        </div>        
            <!--{/if}-->
  	<!--{if $_G[forum_thread][allreplies] == '0' }--> 
       <div class="com_area">
                <a {if $_G['uid']} onClick="nryhf()" {else}href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}"{/if} class="reply {if $_G['uid']}{else}dialog{/if}">占个沙发</a>
            </div>
                 <!--{/if}-->
             </div>
  <!--{hook/viewthread_postbottom_mobile $postcount}-->
   <!--{eval $postcount++;}-->
   <!--{/loop}-->

</div>
{$multipage}

<!--{hook/viewthread_bottom_mobile}-->
<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

	$('.recbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=recbtn&inajax=1',
			data:{'postreviewsubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

	$('.recssbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=recssbtn&inajax=1',
			data:{'recommendsubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

	$('.dpbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=dpbtn&inajax=1',
			data:{'commentsubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

</script>
		<script>
var div=document.getElementById("ycbr");
div.innerHTML=div.innerHTML.replace(/<br>/g,"<p class=\"ycbr\"></p>");
</script>

<div class="nrfx_nrfx cl">
	<div class="bdsharebuttonbox" data-tag="share_1" id="nrfx_fxxm">
		<a href="#" class="bds_qzone" data-cmd="qzone">QQ空间</a>
		<a href="#" class="bds_tsina" data-cmd="tsina">新浪微博</a>
		<a href="#" class="bds_sqq" data-cmd="sqq">QQ好友</a>
		<a href="#" class="bds_tqq" data-cmd="tqq">腾讯微博</a>
		{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger')}<a onClick="nrfxgd()" class="bds_weixin">微信</a>{else}<a href="#" class="bds_weixin" data-cmd="weixin">微信</a>
		<a href="#" class="bds_copy" data-cmd="copy">复制链接</a>
	{/if}	
    <a onClick="nrfxgd()" class="fxdgd">更多</a>
	</div>
	<div class="nrfx_qxan{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger')} fxbg2{/if}">关闭</div>
</div>

	<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"$_G[forum_thread][subject] - $_G['setting'][sitename]","bdMini":"2","bdStyle":"0","bdSize":"16"},"share":{},"image":{"viewList":["qzone","tsina","tqq","renren","weixin"],"viewText":"","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='{$_G['siteurl']}template/xlmmapp/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>

{if $page=='1'} 				
<style type="text/css">
.list_pt10 {
background: #f4f5f6;
padding-top: 10px;}


</style>
<div class="list_pt10">
    <div class="ms_title point5 white cl">
            <span class="z plr15">最新推荐</span>
        </div>        
</div>
{eval include_once TPLDIR.'/php/viewthread.php'; }
<div class="xlmmdp-containers $xlaj">
<div class="plr15 white">
<ul id="xlmmjps$xlaj">

							        	<!--{loop $grids['newthread'] $key $thread}-->
  											<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
			{eval include TPLDIR.'/php/img.php';}
	<li>
<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="HotQuestionsItem<!--{if $xlmmal ==0 }--> HotQuestionsItem-mul<!--{elseif $xlmmal <= 2}--><!--{elseif $xlmmal >2}--> HotQuestionsItem-mul<!--{/if}-->">
<div class="HotQuestionsItem-contain">
	<h3 class="HotQuestionsItem-title">$thread[subject]</h3>
<!--{if $xlmmal >2}-->
<div class="HotQuestionsItem-mulImgList" style="margin-top:6px">
     <!--{eval $si=0;}-->
<!--{loop $xlmmattach $attach}-->
     					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment'] ; }
		<!--{/if}-->
	<div class="HotQuestionsItem-mulImgWrapper">
		<img class="HotQuestionsItem-mulImg" src="$xlmmimg">
	</div>
          	 <!--{eval $si++}-->
<!--{eval if($si==3) break;}-->
<!--{/loop}-->
</div>
<!--{/if}-->
	<div class="HotQuestionsItem-description">
		$thread[views] 次点击 · $thread[replies] 评论
	</div>
</div>
<!--{if $xlmmal ==0 }-->
<!--{elseif $xlmmal <= 2}-->
     <!--{eval $si=0;}-->
<!--{loop $xlmmattach $attach}-->
     					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment'] ; }
		<!--{/if}-->
<img class="HotQuestionsItem-img" src="<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->">
          	 <!--{eval $si++}-->
<!--{eval if($si==1) break;}-->
<!--{/loop}-->
<!--{/if}-->
</a>
	</li>
			<!--{/loop}-->

</ul>
	 </div>
    <div id="ajaxlast" style="text-align: center;position: relative;padding: 12px 0; padding-bottom:6px;"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" style="cursor: pointer;font-size: 14px;line-height: 22px;border-radius: 29px;color: #406599;">查看更多</a></div>
</div>
		<!--{/if}-->


<div class="xlmmhfk xlmmthf cl">
	<!--{subtemplate forum/forumdisplay_fastpost}-->
</div>
<script type="text/javascript">
	function nrywfx(){
		$(".nrfx_nrfx").addClass("am-modal-active fxdm");	
		if($(".sharebg").length>0){
			$(".sharebg").addClass("sharebg-active");
		}else{
			$("body").append('<div class="sharebg"></div>');
			$(".sharebg").addClass("sharebg-active");
		}
		$(".sharebg-active,.nrfx_qxan").click(function(){
			$(".nrfx_nrfx").removeClass("am-modal-active fxdm");	
			setTimeout(function(){
				$(".sharebg-active").removeClass("sharebg-active");	
				$(".sharebg").remove();	
			},300);
		})
	}	
</script>

<script type="text/javascript">
	function nrfxgd(){
		$(".nrfx_nrfx").addClass("am-modal-active fxgdbg");	
		$(".nrfx_nrfx").removeClass("fxdm");	
		if($(".sharebg").length>0){
			$(".sharebg").removeClass("sharebg-active");
		}else{
			$(".sharebg").removeClass("sharebg-active");
		}
		$(".sharebg-active,.nrfx_qxan").click(function(){
			$(".nrfx_nrfx").removeClass("am-modal-active fxgdbg");	
			setTimeout(function(){
				$(".sharebg-active").removeClass("sharebg-active");	
				$(".sharebg").remove();	
			},300);
		})
	}	
</script>

<script type="text/javascript">
	function nryhf(){
		$(".xlmmhfk").addClass("am-modal-active");	
		if($(".sharebg").length>0){
			$(".sharebg").addClass("sharebg-active");
		}else{
			$("body").append('<div class="sharebg"></div>');
			$(".sharebg").addClass("sharebg-active");
		}
		$(".sharebg-active,.nrfx_qxan").click(function(){
			$(".xlmmhfk").removeClass("am-modal-active");	
			setTimeout(function(){
				$(".sharebg-active").removeClass("sharebg-active");	
				$(".sharebg").remove();	
			},300);
		})
	}	
</script>

<!--{template common/footer}-->











