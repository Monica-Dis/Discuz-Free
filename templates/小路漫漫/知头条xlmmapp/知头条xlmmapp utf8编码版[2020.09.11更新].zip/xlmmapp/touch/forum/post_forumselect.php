<?php exit;?>

<!--{template common/header}-->
<script type="text/javascript" src="{$_G[setting][jspath]}common.js"></script>
<style type="text/css">
.xl-xs{display:none!important;}
.xl-ksft{width:100%;}
.xl-ksft .pbnv{float:left;white-space:nowrap;overflow:hidden;width:400px;padding:7px 0;}
.xl-ksft .pbl{overflow:hidden;margin:15px 0;width:100%;border:solid;border-color:#ececec;border-width:0;background:#fff;}
.xl-ksft .pbl li{float:left;overflow-x:hidden;overflow-y:auto;padding:5px 1.5%;width:30%;height:310px;border-left:1px solid #ececec;}
#block_group {border-left:0;}
.xl-ksft .pbl p{height:35px;line-height:35px;}
.xl-ksft .pbl a{display:block;white-space:nowrap;overflow:hidden;padding:0 4px;font-size: 14px;text-decoration:none;color:{HIGHLIGHTLINK};border:solid{WRAPBG};border-width:1px 0;}
.xl-ksft .pbl a:hover{text-decoration:none;background-color:#F3F3F3;}
.xl-ksft .pbl .highlightlink{color:#08C;}
.xl-ksft .pbls a,.pbls a:hover{background-color:#EEE;color:#ff6600;font-weight:400;}
.xl-ksft .xl-fq{margin-bottom:20px;color:#fff; background: #15bfff; border:0px outset buttonface!important;text-align:center;height:40px;width:85%;border-radius: 3px;}
.xl-ksft .xl-bk{margin-bottom:20px;color:#fff;background-color:#dedede;border:0px outset buttonface!important;text-align:center;height:40px;width:85%;border-radius: 3px;}
.xl-ksft .xl-fq span,.xl-ksft .xl-bk span {font-size: 16px;}
.xl_fbanjz {text-align: center;}
</style>	

<!--{hook/misc_kuaifa_top_mobile}-->
<div class="xl-xs">
	<ul id="fs_group">$grouplist</ul>
	<ul id="fs_forum_common">$commonlist</ul>
	<!--{loop $forumlist $forumid $forum}-->
		<ul id="fs_forum_$forumid">$forum</ul>
	<!--{/loop}-->
	<!--{loop $subforumlist $forumid $forum}-->
		<ul id="fs_subforum_$forumid">$forum</ul>
	<!--{/loop}-->
</div>
<div class="xl-ksft">
	<ul class="pbl cl">
		<li id="block_group"></li>
		<li id="block_forum"></li>
		<li id="block_subforum"></li>
	</ul>
	<p class="cl xl_fbanjz">
		<!--{if $_G['group']['allowpost'] || !$_G['uid']}-->
			<!--{if $special === null}-->
				<button id="postbtn" class="xl-qh xl-fq {if $_G['uid']}{else}xlapp_wdlts{/if}" onclick="hideWindow('nav');showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=' + selectfid)" disabled="disabled"><span>{lang send_posts}</span></button>
			<!--{else}-->
				<button id="postbtn" class="xl-qh xl-bk {if $_G['uid']}{else}xlapp_wdlts{/if}" onclick="hideWindow('nav');window.location.href='forum.php?mod=post&action=newthread&fid=' + selectfid + '&special=$special'" disabled="disabled"><span>$actiontitle</span></button>
			<!--{/if}-->
		<!--{/if}-->
		<span class="xl-xs"><span id="pbnv"></span> <a id="enterbtn" class="xg1" href="javascript:;" onclick="locationforums(currentblock, currentfid)">[{lang nav_forum}]</a></span>
	</p>
</div>
<!--{hook/misc_kuaifa_bottom_mobile}-->

<script type="text/javascript" reload="1">
var s = '<!--{if $commonfids}--><p><a id="commonforum" href="javascript:;" onclick="switchforums(this, 1, \'common\')" class="pbsb lightlink">{lang nav_forum_frequently}</a></p><!--{/if}-->';
var lis = $('fs_group').getElementsByTagName('LI');
for(i = 0;i < lis.length;i++) {
	var gid = lis[i].getAttribute('fid');
	if($('fs_forum_' + gid)) {
		s += '<p><a href="javascript:;" ondblclick="locationforums(1, ' + gid + ')" onclick="switchforums(this, 1, ' + gid + ')" class="pbsb">' + lis[i].innerHTML + '</a></p>';
	}
}
$('block_group').innerHTML = s;
var lastswitchobj = null;
var selectfid = 0;
var switchforum = switchsubforum = '';
switchforums($('commonforum'), 1, 'common');
function switchforums(obj, block, fid) {
	if(lastswitchobj != obj) {
		if(lastswitchobj) {
			lastswitchobj.parentNode.className = '';
		}
		obj.parentNode.className = 'pbls';
	}
	var s = '';
	if(fid != 'common') {
		$('enterbtn').className = 'xi2';
		currentblock = block;
		currentfid = fid;
	} else {
		$('enterbtn').className = 'xg1';
	}
	if(block == 1) {
		var lis = $('fs_forum_' + fid).getElementsByTagName('LI');
		for(i = 0;i < lis.length;i++) {
			fid = lis[i].getAttribute('fid');
			if(fid != '') {
				s += '<p><a href="javascript:;" ondblclick="locationforums(2, ' + fid + '\)" onclick="switchforums(this, 2, ' + fid + ')"' + ($('fs_subforum_' + fid) ?  ' class="pbsb"' : '') + '>' + lis[i].innerHTML + '</a></p>';
			}
		}
		$('block_forum').innerHTML = s;
		$('block_subforum').innerHTML = '';
		switchforum = switchsubforum = '';
		selectfid = 0;
		$('postbtn').setAttribute("disabled", "disabled");
		$('postbtn').className = 'xl-qh xl-bk';
	} else if(block == 2) {
		selectfid = fid;
		if($('fs_subforum_' + fid)) {
			var lis = $('fs_subforum_' + fid).getElementsByTagName('LI');
			for(i = 0;i < lis.length;i++) {
				fid = lis[i].getAttribute('fid');
				s += '<p><a href="javascript:;" ondblclick="locationforums(3, ' + fid + ')" onclick="switchforums(this, 3, ' + fid + ')">' + lis[i].innerHTML + '</a></p>';
			}
			$('block_subforum').innerHTML = s;
		} else {
			$('block_subforum').innerHTML = '';
		}
		switchforum = obj.innerHTML;
		switchsubforum = '';
		$('postbtn').removeAttribute("disabled");
		$('postbtn').className = 'xl-qh xl-fq';
	} else {
		selectfid = fid;
		switchsubforum = obj.innerHTML;
		$('postbtn').removeAttribute("disabled");
		$('postbtn').className = 'xl-qh xl-fq';
	}
	lastswitchobj = obj;
	$('pbnv').innerHTML = switchforum ? '&nbsp;&gt;&nbsp;' + switchforum + (switchsubforum ? '&nbsp;&gt;&nbsp;' + switchsubforum : '') : '';
}

function locationforums(block, fid) {
	location.href = block == 1 ? 'forum.php?gid=' + fid : 'forum.php?mod=forumdisplay&fid=' + fid;
}

</script>

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->











