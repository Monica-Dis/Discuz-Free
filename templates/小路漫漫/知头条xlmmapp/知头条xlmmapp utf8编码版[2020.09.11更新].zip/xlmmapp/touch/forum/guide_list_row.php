<?php exit;?>
					<!--{if $list['threadcount']}-->
	<ul class="app-top-list p20 white pt5" id="xlmmjps">
			<start></start>
			   <!--{eval $xlmmi=1;}-->
		<!--{loop $list['threadlist'] $key $thread}-->
		<li>
<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="HotQuestionsItem">
<div class="xlmmphbst"><span class="num icon-top-$xlmmi">$xlmmi</span></div><div class="HotQuestionsItem-contain">
	<h3 class="HotQuestionsItem-title">
    <!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
			{eval include TPLDIR.'/php/img.php';}
$thread[typehtml] $thread[sorthtml]
										$thread[subject]</h3>
	<div class="HotQuestionsItem-description">
	<!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--> 查看 · <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--> 回复
	</div>
</div>
                 <!--{if $xlmmal >0}-->
     <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
     					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment'] ; }
		<!--{/if}-->
<img class="HotQuestionsItem-img" src="$xlmmimg">
          	 <!--{eval $i++}-->
<!--{eval if($i==1) break;}-->
<!--{/loop}--> 
	<!--{/if}-->
</a>
		</li>
		 <!--{eval $xlmmi++}-->
				<!--{/loop}-->
	$multipage
				</ul>
		 <end></end>
		<!--{else}-->
<div style="text-align:center; background:#FFFFFF; padding-bottom:20px;"><svg width="150" height="120" viewBox="0 0 150 120" class="Topstory-newUserFollowCountPanelIcon" fill="currentColor"><g fill="none" fill-rule="evenodd"><path fill="#EBEEF5" d="M44 31.005v55.99A3.003 3.003 0 0 0 47.003 90h53.994A3.005 3.005 0 0 0 104 86.995v-55.99A3.003 3.003 0 0 0 100.997 28H47.003A3.005 3.005 0 0 0 44 31.005zm-3 0A6.005 6.005 0 0 1 47.003 25h53.994A6.003 6.003 0 0 1 107 31.005v55.99A6.005 6.005 0 0 1 100.997 93H47.003A6.003 6.003 0 0 1 41 86.995v-55.99z" fill-rule="nonzero"></path><path fill="#F7F8FA" d="M59 50a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 40.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5zM59 73a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 63.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5z"></path></g></svg><div style="font-size: 15px;color: grey;">还没有任何内容哦</div></div>	
				<!--{/if}-->

