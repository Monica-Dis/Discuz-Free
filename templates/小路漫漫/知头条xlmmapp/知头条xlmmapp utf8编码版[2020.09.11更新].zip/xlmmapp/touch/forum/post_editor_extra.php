<?php exit;?>
<script type="text/javascript" src="template/xlmmapp/touch/forum/post/xlmmup.js"></script>
<style>
html, body {
    background: #f2f2f2;
}

</style>
<!--{if $_GET['action'] != 'reply'}-->
<div class="xlmm_fbbt cl" >
	<div class="fbbt_btbt z">{lang thread_subject}</div>
    <div class="fbbt_btsr z"><input type="text" name="subject" value="$postinfo[subject]" id="needsubject" class="txt"  placeholder="请填写标题"/></div>
</div>
<!--{else}-->
<div class="xlmm_hfzs cl" style=" margin-bottom: 15px;
    padding: 10px 12px;
    font-size: 14px;
    background: #fff;">
    RE: $thread['subject']<!--{if $quotemessage}-->$quotemessage <!--{/if}--> 
</div>
<!--{/if}--> 
<!--{if $sortid}-->
<input type="hidden" name="sortid" value="$sortid" />
<!--{/if}--> 
<!--{if $isfirstpost && !empty($_G['forum'][threadtypes][types])}-->
<div class="xlmm_flxz cl">
	<div class="flxz_btbt z">分类</div>
    <div class="selectbox z" style="display: block;">
		<select name="typeid" id="typeid" class="flxz_xzys">
			<option value="0">{lang select_thread_catgory}</option>
			<!--{loop $_G['forum'][threadtypes][types] $typeid $name}--> 
			<!--{if empty($_G['forum']['threadtypes']['moderators'][$typeid]) || $_G['forum']['ismoderator']}-->
			<option value="$typeid"{if $thread['typeid'] == $typeid || $_GET['typeid'] == $typeid} selected="selected"{/if}>
			<!--{echo strip_tags($name);}-->
			</option>
			<!--{/if}--> 
			<!--{/loop}-->
		</select>
    </div>
</div>
<!--{/if}-->
<!--{if $showthreadsorts}-->
<div class="ztfb_flfb cl"> 
  <!--{template forum/post_sortoption}--> 
</div>
<!--{elseif $adveditor}--> 
<!--{if $special == 1}--><!--{template forum/post_poll}--> 
<!--{elseif $special == 2 && ($_GET[action] != 'edit' || ($_GET[action] == 'edit' && ($thread['authorid'] == $_G['uid'] && $_G['group']['allowposttrade'] || $_G['group']['allowedittrade'])))}-->
<!--{template forum/post_trade}--> 
<!--{elseif $special == 3}--><!--{template forum/post_reward}--> 
<!--{elseif $special == 4}--><!--{template forum/post_activity}--> 
<!--{elseif $special == 5}--><!--{template forum/post_debate}--> 
<!--{elseif $specialextra}-->
<div class="specialpost s_clear">$threadplughtml</div>
<!--{/if}--> 
<!--{/if}--> 











