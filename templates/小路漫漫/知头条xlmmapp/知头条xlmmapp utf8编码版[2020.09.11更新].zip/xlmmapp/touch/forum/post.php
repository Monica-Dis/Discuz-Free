<?php exit;?>
<!--{template common/header}-->
<link href="template/xlmmapp/touch/forum/post/post.css" rel="stylesheet" type="text/css">
<style>

.swiper-wrapper {position:relative;width:100%;z-index:1;display:-webkit-box;display:-moz-box;display:-ms-flexbox;display:-webkit-flex;display:flex;-webkit-transition-property:-webkit-transform;-moz-transition-property:-moz-transform;-o-transition-property:-o-transform;-ms-transition-property:-ms-transform;transition-property:transform;-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box}
.swiper-slide {-webkit-flex-shrink:0;-ms-flex:0 0 auto;flex-shrink:0;width:100%;position:relative}
.xlmmfcrbq_smiley_box{overflow:hidden;padding:6px 6px 8px;}
.xlmmfcrbq_bqbox .bqbox_t {height:41px;background-color:rgba(0,0,0,0.02);position:relative;}
.xlmmfcrbq_bqbox .bqbox_t ul {position:absolute;top:0px;left:0px;height:42px;line-height:42px;overflow:hidden;}
.xlmmfcrbq_bqbox .bqbox_t li {float:left;height:42px;}
.xlmmfcrbq_bqbox .bqbox_t li:first-child {margin-left:-1px;}
.xlmmfcrbq_bqbox .bqbox_t a {display:block;padding:0 15px;}
.xlmmfcrbq_bqbox .bqbox_t img {width:24px;height:24px;margin-bottom:2px;}
.xlmmfcrbq_bqbox .bqbox_c li {float:left;width:12.5%;}
.xlmmfcrbq_bqbox .bqbox_c a {display:block;padding:10px;}
.xlmmfcrbq_bqbox .bqbox_c img {width:100%;}
.xlmmfcrbq_bqbox .bqbox_b {height:10px;line-height:10px;padding:3px 5px;text-align:center;}
.xlmmfcrbq_bqbox .bqbox_b span {display:inline-block;width:6px;height:6px;margin:0 3px;border-radius:6px;background:#ebebeb;}
.xlmmfcrbq_bqbox .bqbox_b span.swiper-pagination-bullet-active{background:#FCAD30}
.bg_f {background: #fff;}
.b_r {border-right: 1px solid #efefef !important;}
.b_l {border-left: 1px solid #efefef !important;}
.b_t {border-top: 1px solid #efefef !important;}



</style>

<script>var action = '';</script>
<script src="data/cache/common_smilies_var.js?FBM" type="text/javascript" charset="{CHARSET}"></script>
<script src="template/xlmmapp/touch/forum/post/sw.js?FBM" type="text/javascript"></script>
<script type="text/javascript" src="template/xlmmapp/touch/forum/post/crbq.js?{VERHASH}"></script>
<script type="text/javascript">
	var allowpostattach = parseInt('{$_G['group']['allowpostattach']}');
	var allowpostimg = parseInt('$allowpostimg');
	var pid = parseInt('$pid');
	var tid = parseInt('$_G[tid]');
	var extensions = '{$_G['group']['attachextensions']}';
	var imgexts = '$imgexts';
	var postminchars = parseInt('$_G['setting']['minpostsize']');
	var postmaxchars = parseInt('$_G['setting']['maxpostsize']');
	var disablepostctrl = parseInt('{$_G['group']['disablepostctrl']}');
	var seccodecheck = parseInt('<!--{if $seccodecheck}-->1<!--{else}-->0<!--{/if}-->');
	var secqaacheck = parseInt('<!--{if $secqaacheck}-->1<!--{else}-->0<!--{/if}-->');
	var typerequired = parseInt('{$_G[forum][threadtypes][required]}');
	var sortrequired = parseInt('{$_G[forum][threadsorts][required]}');
	var special = parseInt('$special');
	var isfirstpost = <!--{if $isfirstpost}-->1<!--{else}-->0<!--{/if}-->;
	var allowposttrade = parseInt('{$_G['group']['allowposttrade']}');
	var allowpostreward = parseInt('{$_G['group']['allowpostreward']}');
	var allowpostactivity = parseInt('{$_G['group']['allowpostactivity']}');
	var sortid = parseInt('$sortid');
	var special = parseInt('$special');
	var fid = $_G['fid'];
	var postaction = '{$_GET['action']}';
	var ispicstyleforum = <!--{if $_G['forum']['picstyle']}-->1<!--{else}-->0<!--{/if}-->;
</script>
<!--{if $_GET[action] == 'edit'}--><!--{eval $editor[value] = $postinfo[message];}--><!--{else}--><!--{eval $editor[value] = $message;}--><!--{/if}-->
<!--{if $isfirstpost && $sortid}-->
<script type="text/javascript">
	var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
</script>
<script type="text/javascript" >
function xmlobj() {
    var obj = new Object();
    obj.createXMLDoc = function(xmlstring) {
        var xmlobj = false;
        if (window.DOMParser && document.implementation && document.implementation.createDocument) {
            try {
                var domparser = new DOMParser();
                xmlobj = domparser.parseFromString(xmlstring, 'text/xml');
            } catch(e) {}
        } else if (window.ActiveXObject) {
            var versions = ["MSXML2.DOMDocument.5.0", "MSXML2.DOMDocument.4.0", "MSXML2.DOMDocument.3.0", "MSXML2.DOMDocument", "Microsoft.XmlDom"];
            for (var i = 0; i < versions.length; i++) {
                try {
                    xmlobj = new ActiveXObject(versions[i]);
                    if (xmlobj) {
                        xmlobj.async = false;
                        xmlobj.loadXML(xmlstring);
                    }
                } catch(e) {}
            }
        }
        return xmlobj;
    };

    obj.xml2json = function(xmlobj, node) {
        var nodeattr = node.attributes;
        if (nodeattr != null) {
            if (nodeattr.length && xmlobj == null) {
                xmlobj = new Object();
            }
            for (var i = 0; i < nodeattr.length; i++) {
                xmlobj[nodeattr[i].name] = nodeattr[i].value;
            }
        }
        var nodetext = "text";
        if (node.text == null) {
            nodetext = "textContent";
        }

        var nodechilds = node.childNodes;
        if (nodechilds != null) {
            if (nodechilds.length && xmlobj == null) {
                xmlobj = new Object();
            }
            for (var i = 0; i < nodechilds.length; i++) {
                if (nodechilds[i].tagName != null) {
                    if (nodechilds[i].childNodes[0] != null && nodechilds[i].childNodes.length <= 1 && (nodechilds[i].childNodes[0].nodeType == 3 || nodechilds[i].childNodes[0].nodeType == 4)) {
                        if (xmlobj[nodechilds[i].tagName] == null) {
                            xmlobj[nodechilds[i].tagName] = nodechilds[i][nodetext];
                        } else {
                            if (typeof(xmlobj[nodechilds[i].tagName]) == "object" && xmlobj[nodechilds[i].tagName].length) {
                                xmlobj[nodechilds[i].tagName][xmlobj[nodechilds[i].tagName].length] = nodechilds[i][nodetext];
                            } else {
                                xmlobj[nodechilds[i].tagName] = [xmlobj[nodechilds[i].tagName]];
                                xmlobj[nodechilds[i].tagName][1] = nodechilds[i][nodetext];
                            }
                        }
                    } else {
                        if (nodechilds[i].childNodes.length) {
                            if (xmlobj[nodechilds[i].tagName] == null) {
                                xmlobj[nodechilds[i].tagName] = new Object();
                                this.xml2json(xmlobj[nodechilds[i].tagName], nodechilds[i]);
                            } else {
                                if (xmlobj[nodechilds[i].tagName].length) {
                                    xmlobj[nodechilds[i].tagName][xmlobj[nodechilds[i].tagName].length] = new Object();
                                    this.xml2json(xmlobj[nodechilds[i].tagName][xmlobj[nodechilds[i].tagName].length - 1], nodechilds[i]);
                                } else {
                                    xmlobj[nodechilds[i].tagName] = [xmlobj[nodechilds[i].tagName]];
                                    xmlobj[nodechilds[i].tagName][1] = new Object();
                                    this.xml2json(xmlobj[nodechilds[i].tagName][1], nodechilds[i]);
                                }
                            }
                        } else {
                            xmlobj[nodechilds[i].tagName] = nodechilds[i][nodetext];
                        }
                    }
                }
            }
        }
    };
    return obj;
}


function mb_strlen(str) {
    var len = 0;
    for (var i = 0; i < str.length; i++) {
        len += str.charCodeAt(i) < 0 || str.charCodeAt(i) > 255 ? (charset == 'utf-8' ? 3 : 2) : 1;
    }
    return len;
}

function showerror(c, k) {

    $(c).html(k);

}

function showtrue(c) {
    $(c).html('<img src="' + IMGDIR + '/check_right.gif" width="16" height="16" class="vm" />');

}

var xml = new xmlobj();

var xmlpar = xml.createXMLDoc(forum_optionlist);
var forum_optionlist_obj = new Object();
xml.xml2json(forum_optionlist_obj, xmlpar);

function changeselectthreadsort(selectchoiceoptionid, optionid, type) {
    if (selectchoiceoptionid == '0') {
        return;
    }

    var soptionid = 's' + optionid;
    var sselectchoiceoptionid = 's' + selectchoiceoptionid;

    forum_optionlist = forum_optionlist_obj['forum_optionlist'];

    var choicesarr = forum_optionlist[soptionid]['schoices'];
    var lastcount = 1;
    var name = issearch = id = nameid = '';

    if (type == 'search') {
        issearch = ', \'search\'';
        name = ' name="searchoption[' + optionid + '][value]"';
        id = 'id="' + forum_optionlist[soptionid]['sidentifier'] + '"';

    } else {
        name = ' name="typeoption[' + forum_optionlist[soptionid]['sidentifier'] + ']"';
        id = 'id="typeoption_' + forum_optionlist[soptionid]['sidentifier'] + '"';

    }
    if ((choicesarr[sselectchoiceoptionid]['slevel'] == 1 || type == 'search') && choicesarr[sselectchoiceoptionid]['scount'] == 1) {
        nameid = name + ' ' + id;
    }

    var selectoption = '<select' + nameid + ' class="select" onchange="changeselectthreadsort(this.value, \'' + optionid + '\'' + issearch + ');checkoption(\'' + forum_optionlist[soptionid]['sidentifier'] + '\', \'' + forum_optionlist[soptionid]['srequired'] + '\', \'' + forum_optionlist[soptionid]['stype'] + '\')" ' + ((forum_optionlist[soptionid]['sunchangeable'] == 1 && type == 'update') ? 'disabled': '') + '><option value="0">' + "请选择 ∨" + '</option>';
    for (var i in choicesarr) {
        nameid = '';
        if ((choicesarr[sselectchoiceoptionid]['slevel'] == 1 || type == 'search') && choicesarr[i]['scount'] == choicesarr[sselectchoiceoptionid]['scount']) {
            nameid = name + ' ' + id;
        }
        if (choicesarr[i]['sfoptionid'] != '0') {
            var patrn1 = new RegExp("^" + choicesarr[i]['sfoptionid'] + "\\.", 'i');
            var patrn2 = new RegExp("^" + choicesarr[i]['sfoptionid'] + "$", 'i');
            if (selectchoiceoptionid.match(patrn1) == null && selectchoiceoptionid.match(patrn2) == null) {
                continue;
            }
        }
        if (choicesarr[i]['scount'] != lastcount) {
            if (parseInt(choicesarr[i]['scount']) >= (parseInt(choicesarr[sselectchoiceoptionid]['scount']) + parseInt(choicesarr[sselectchoiceoptionid]['slevel']))) {
                break;
            }
            selectoption += '</select>' + "\r\n" + '<select' + nameid + ' class="select" onchange="changeselectthreadsort(this.value, \'' + optionid + '\'' + issearch + ');checkoption(\'' + forum_optionlist[soptionid]['sidentifier'] + '\', \'' + forum_optionlist[soptionid]['srequired'] + '\', \'' + forum_optionlist[soptionid]['stype'] + '\')" ' + ((forum_optionlist[soptionid]['sunchangeable'] == 1 && type == 'update') ? 'disabled': '') + '><option value="0">' + "请选择 ∨" + '</option>';

            lastcount = parseInt(choicesarr[i]['scount']);
        }

        var patrn1 = new RegExp("^" + choicesarr[i]['soptionid'] + "\\.", 'i');
        var patrn2 = new RegExp("^" + choicesarr[i]['soptionid'] + "$", 'i');
        var isnext = '';
        if (parseInt(choicesarr[i]['slevel']) != 1) {
            isnext = '&raquo;';
        }
        if (selectchoiceoptionid.match(patrn1) != null || selectchoiceoptionid.match(patrn2) != null) {
            selectoption += "\r\n" + '<option value="' + choicesarr[i]['soptionid'] + '" selected="selected">' + choicesarr[i]['scontent'] + isnext + '</option>';
        } else {
            selectoption += "\r\n" + '<option value="' + choicesarr[i]['soptionid'] + '">' + choicesarr[i]['scontent'] + isnext + '</option>';
        }
    }

    selectoption += '</select>';
    if (type == 'search') {
        selectoption += "\r\n" + '<input type="hidden" name="searchoption[' + optionid + '][type]" value="select">';
    }

    $('#select_' + forum_optionlist[soptionid]['sidentifier']).html(selectoption)

}

function checkoption(identifier, required, checktype, checkmaxnum, checkminnum, checkmaxlength) {
    var ce = $('#check' + identifier);
    if (checktype != 'image' && checktype != 'select' && !$('#typeoption_' + identifier) || !$('#check' + identifier)) {
        return true;
    }

    var ce = $('#check' + identifier);

    if (checktype == 'select') {
        var typeoption_id = document.getElementById('typeoption_' + identifier);

        if (required != '0' && (typeoption_id == null || typeoption_id.value == '0')) {

            showerror(ce, "必填项目没有填写");
            return false;
        } else if (required == '0' && (typeoption_id == null || typeoption_id.value == '0')) {
            showerror(ce, "请选择下一级");
            return true;
        }
    }

    if (checktype == 'radio') {

        var nodechecked = $('input:radio[name="typeoption[' + identifier + ']"]').is(":checked");

        if (!nodechecked && required != '0') {
            showerror(ce, "必填项目没有填写");

            return false;
        } else {
            showtrue(ce);
            return true;
        }

    }

    if (checktype == 'checkbox') {
        var nodechecked = $('input:checkbox[name="typeoption[' + identifier + '][]"]').is(":checked");

        if (!nodechecked && required != '0') {

            showerror(ce, "必填项目没有填写");
            return false;
        } else {
            showtrue(ce);
            return true;
        }

    }

    if (checktype == 'image') {
        var checkvalue = $('#sortaid_' + identifier).val();
    } else if (checktype == 'select') {
        var checkvalue = $("#select_" + identifier).find("option:selected").val();
    } else {
        var checkvalue = $('#typeoption_' + identifier).val();

    }

    if (required != '0') {
        if (checkvalue == '') {

            showerror(ce, "必填项目没有填写");
            return false;
        }
    }

    if (checkvalue) {

        if (checktype == 'email' && !(/^[\-\.\w]+@[\.\-\w]+(\.\w+)+$/.test(checkvalue))) {
            showerror(ce, "邮件地址不正确");

            return false;
        } else if ((checktype == 'text' || checktype == 'textarea') && checkmaxlength != '0' && mb_strlen(checkvalue) > checkmaxlength) {
            showerror(ce, "填写项目长度过长");
            return false;
        } else if ((checktype == 'number' || checktype == 'range')) {

            if (isNaN(checkvalue)) {
                showerror(ce, "数字填写不正确");
                return false;
            } else if (checkmaxnum != '0' && parseInt(checkvalue) > parseInt(checkmaxnum)) {
                showerror(ce, "大于设置最大值");
                return false;
            } else if (checkminnum != '0' && parseInt(checkvalue) < parseInt(checkminnum)) {
                showerror(ce, "小于设置最小值");
                return false;
            }
        } else if (checktype == 'url' && !(/(http[s]?|ftp):\/\/[^\/\.]+?\..+\w[\/]?$/i.test(checkvalue))) {
            showerror(ce, "请正确填写以http://开头的URL地址");
            return false;
        }
        showtrue(ce);
    }

    return true;

}
</script>
<!--{/if}-->
<style type="text/css">
</style>

<script src="template/xlmmapp/touch/forum/post/iscroll.js" type="text/javascript"></script>
<script src="template/xlmmapp/touch/forum/post/iscroll-2.js" type="text/javascript"></script>
<script src="template/xlmmapp/touch/forum/post/iscroll-3.js" type="text/javascript"></script>
<link href="template/xlmmapp/touch/forum/post/iscroll.css" rel="stylesheet" type="text/css">
<link href="template/xlmmapp/touch/forum/post/iscroll-3.css" rel="stylesheet" type="text/css">
<div class="xlmm_fatie cl">
<!--{eval $adveditor = $isfirstpost && $special || $special == 2 && ($_GET['action'] == 'newthread' || $_GET['action'] == 'reply' && !empty($_GET['addtrade']) || $_GET['action'] == 'edit' && $thread['special'] == 2);}--> 
<!--{eval $advmore = !$showthreadsorts && !$special || $_GET['action'] == 'reply' && empty($_GET['addtrade']) || $_GET['action'] == 'edit' && !$isfirstpost && ($thread['special'] == 2 && !$special || $thread['special'] != 2);}-->
	<form method="post" id="postform" enctype="multipart/form-data"
		{if $_GET[action] == 'newthread'}action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes&mobile=2"
		{elseif $_GET[action] == 'reply'}action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes&mobile=2"
		{elseif $_GET[action] == 'edit'}action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes&mobile=2" $enctype
		{/if}>
			<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
			<input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}" />
		<!--{if $_GET['action'] == 'edit'}-->
			<input type="hidden" name="delattachop" id="delattachop" value="0" />
		<!--{/if}--> 
		<!--{if !empty($_GET['modthreadkey'])}-->
			<input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" />
		<!--{/if}-->
		<input type="hidden" name="wysiwyg" id="{$editorid}_mode" value="$editormode" />
		<!--{if $_GET[action] == 'reply'}-->
			<input type="hidden" name="noticeauthor" value="$noticeauthor" />
			<input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
			<input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
		<!--{if $reppid}-->
			<input type="hidden" name="reppid" value="$reppid" />
		<!--{/if}--> 
		<!--{if $_GET[reppost]}-->
			<input type="hidden" name="reppost" value="$_GET[reppost]" />
		<!--{elseif $_GET[repquote]}-->
			<input type="hidden" name="reppost" value="$_GET[repquote]" />
		<!--{/if}--> 
		<!--{/if}--> 
		<!--{if $_GET[action] == 'edit'}-->
			<input type="hidden" name="fid" id="fid" value="$_G[fid]" />
			<input type="hidden" name="tid" value="$_G[tid]" />
			<input type="hidden" name="pid" value="$pid" />
			<input type="hidden" name="page" value="$_GET[page]" />
		<!--{/if}--> 
		<!--{if $special}-->
			<input type="hidden" name="special" value="$special" />
		<!--{/if}--> 
		<!--{if $specialextra}-->
			<input type="hidden" name="specialextra" value="$specialextra" />
		<!--{/if}-->
	<!--{if $_GET[action] == 'newthread'}-->
	<script src="template/xlmmapp/touch/forum/post/huak.js"></script>
	<div class="xlmm_ztfl">
		<div class="ztfl_flzt">
			<div class="ztfl_hdmk">
				<ul id="xlmm_glpd">
					<!--{if !$_G['forum']['allowspecialonly']}-->
						<li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" {if $postspecialcheck[0]} selected="selected"{/if}>{lang post_newthread}</a></li>
                    <!--{/if}--> 
                    <!--{loop $_G['forum']['threadsorts'][types] $tsortid $name}-->
						<li><a href="forum.php?mod=post&action=newthread&sortid=$tsortid&fid=$_G[fid]" {if $sortid == $tsortid} selected="selected" {/if}><!--{echo strip_tags($name);}--></a></li>
                    <!--{/loop}--> 
                    <!--{if $_G['group']['allowpostpoll']}-->
						<li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1" {if $postspecialcheck[1]} selected="selected"{/if}>{lang post_newthreadpoll}</a></li>
                    <!--{/if}--> 
                    <!--{if $_G['group']['allowpostreward']}-->
						<li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3" {if $postspecialcheck[3]} selected="selected"{/if}>{lang post_newthreadreward}</a></li>
                    <!--{/if}--> 
                    <!--{if $_G['group']['allowpostdebate']}-->
						<li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5" {if $postspecialcheck[5]} selected="selected"{/if}>{lang post_newthreaddebate}</a></li>
                    <!--{/if}--> 
                    <!--{if $_G['group']['allowpostactivity']}-->
						<li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4" {if $postspecialcheck[4]} selected="selected"{/if}>{lang post_newthreadactivity}</a></li>
                    <!--{/if}--> 
                    <!--{if $_G['group']['allowposttrade']}-->
						<li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2" {if $postspecialcheck[2]} selected="selected"{/if}>{lang post_newthreadtrade}</a></li>
                    <!--{/if}-->
				</ul>
			</div>
			<div class="ztfl_ycgd"><span></span></div>
		</div>
	</div>
	<script type="text/javascript" language="javascript">
		var nav = document.getElementById("xlmm_glpd");
		var links = nav.getElementsByTagName("li");
		var lilen = nav.getElementsByTagName("a"); 
		var currenturl = document.location.href;
		var last = 0;
		for (var i=0;i<links.length;i++)
		{
			var linkurl =  lilen[i].getAttribute("href");
				if(currenturl.indexOf(linkurl)!=-1)
			{
				last = i;
			}
		}
        links[last].className = "a";
	</script>
	<!--{/if}-->
	
	<!--{subtemplate forum/post_editor_extra}-->

	<div class="ztfb_nrsr cl">
		<textarea class="pt" id="needmessage" tabindex="3" autocomplete="off" id="{$editorid}_textarea" name="$editor[textarea]" cols="80" rows="2"  placeholder="内容区域" fwin="reply">$postinfo[message]</textarea>
	</div>
	<div class="ztfb_tpsc cl">
		<div class="tpsc_tpxz"><a href="javascript:;" id="addimg"><input type="file" name="Filedata" id="filedata"  accept="image/*"  mutiple="mutiple" style="width:54px;height:54px;font-size:50px;opacity:0;"/></a></div>
		<div class="tpsc_tplb"><ul id="imglist"></ul></div>
	</div>
	<script language="javascript">  
		function showhidediv(id){$(".exfm").not($("#" + id).show()).hide();
		var sbtitle=document.getElementById(id);  
		if(sbtitle){  
		if(sbtitle.style.display=='block'){    
			sbtitle.style.display='block';  
		}  
		}  
		}
	</script> 
	<script language="javascript">
		$(document).ready(function(){
			$(".fjxx1 a").click(function(){
				$(this).toggleClass("on").parent().siblings().find("a").removeClass("on"); 
			});
		});
	</script>


	<div class="fjxx1 cl">
		<ul>
			<li class="gnxx_bqanl xlmmfcrbq_post_ico"><a href="JavaScript:void(0)" onMouseMove='showhidediv("cjbqs")'  class="gnxx_bqan"></a></li>
			<li class="gnxx_fjxxl"><a href="javascript:void(0);" onMouseMove='showhidediv("fjxx")' class="gnxx_fjxx"></a></li>
			<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
				<!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
					<li class="gnxx_qlztl"><a href="javascript:void(0);" onMouseMove='showhidediv("qlzt")' class="gnxx_qlzt"></a></li>
				<!--{/if}-->
				<!--{if $_G['group']['maxprice'] && !$special}-->
					<li class="gnxx_ztcsl"><a href="javascript:void(0);" onMouseMove='showhidediv("ztcs")' class="gnxx_ztcs"></a></li>
				<!--{/if}-->
				<!--{if $_G['group']['allowposttag']}-->
					<li class="gnxx_ztbql"><a href="javascript:void(0);" onMouseMove='showhidediv("ztbq")' class="gnxx_ztbq"></a></li>
				<!--{/if}-->
			<!--{/if}-->
					<li style="width:40px;"><a href="javascript:void(0);" onMouseMove='showhidediv("fjcr")' style="color:red; padding-top:2px; font-size:16px;">插入</a></li>
		</ul>
	</div>

	<!--{subtemplate forum/post_editor_attribute}-->

	<!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
		<style type="text/css">
		.xlmm_ftyzm {background:#fff;padding:10px 12px;border-top: 1px solid #EEEEEE;}
		.xlmm_ftyzm .txt {width: 70%;background: #fff;border: 0;font-size: 15px;border-radius: 0;outline: none;-webkit-appearance: none;padding: 0;line-height: 23px;}
		.xlmm_ftyzm img {height: 25px;float: right;}
		</style>
		<!--{subtemplate common/seccheck}-->
	<!--{/if}-->
	<!--{if helper_access::check_module('follow') && $_GET[action] != 'edit'}-->
	<div class="ztfb_scht cl">
		<div class="scht_xxbt z cl">{lang post_relay}</div>
		<div class="scht_xxnr z cl"><input type="checkbox" name="adddynamic" id="adddynamic" value="true" {if $_G['forum']['allowfeed'] && !$_G[tid] && empty($_G['forum']['viewperm'])}checked="checked"{/if} /><label for="adddynamic" class="y" style="margin-top: 2px;"></label></div>
	</div>
	<!--{/if}-->
	<div class="ztfb_fban cl"><button id="postsubmit" class="btn_pn <!--{if $_GET[action] == 'edit'}-->btn_pn_blue" disable="false"<!--{else}-->btn_pn_grey" disable="true"<!--{/if}-->><!--{if $_GET[action] == 'newthread'}-->{lang send_thread}<!--{elseif $_GET[action] == 'reply'}-->{lang join_thread}<!--{elseif $_GET[action] == 'edit'}-->{lang edit_save}<!--{/if}--></button></div>	
	<!--{hook/post_bottom_mobile}-->
</form>
</div>

<script type="text/javascript">
	(function() {
		var needsubject = needmessage = false;

		<!--{if $_GET[action] == 'reply'}-->
			needsubject = true;
		<!--{elseif $_GET[action] == 'edit'}-->
			needsubject = needmessage = true;
		<!--{/if}-->

		<!--{if $_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost)}-->
		$('#needsubject').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				needsubject = true;
				if(needmessage == true) {
					$('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
					$('.btn_pn').attr('disable', 'false');
				}
			} else {
				needsubject = false;
				$('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
				$('.btn_pn').attr('disable', 'true');
			}
		});
		<!--{/if}-->
		$('#needmessage').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				needmessage = true;
				if(needsubject == true) {
					$('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
					$('.btn_pn').attr('disable', 'false');
				}
			} else {
				needmessage = false;
				$('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
				$('.btn_pn').attr('disable', 'true');
			}
		});

		$('#needmessage').on('scroll', function() {
			var obj = $(this);
			if(obj.scrollTop() > 0) {
				obj.attr('rows', parseInt(obj.attr('rows'))+2);
			}
		}).scrollTop($(document).height());
	 })();
</script>
<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="{STATICURL}js/mobile/buildfileupload.js?{VERHASH}"></script>
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
	var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	var form = $('#postform');
	$(document).on('change', '#addimg #filedata', function() {
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

			uploadsuccess = function(data) {
				if(data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
				var dataarr = data.split('|');
				if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
					popup.close();
					$('#imglist').append('<li><span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;"><img style="height:54px;width:54px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
				} else {
					var sizelimit = '';
					if(dataarr[7] == 'ban') {
						sizelimit = '{lang uploadpicatttypeban}';
					} else if(dataarr[7] == 'perday') {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
					} else if(dataarr[7] > 0) {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
					}
					popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
				}
			};

			if(typeof FileReader != 'undefined' && this.files[0]) {
				
				$.buildfileupload({
					uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
					files:this.files,
					uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
					uploadinputname:'Filedata',
					maxfilesize:"$swfconfig[max]",
					success:uploadsuccess,
					error:function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			} else {

				$.ajaxfileupload({
					url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
					data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
					dataType:'text',
					fileElementId:'filedata',
					success:uploadsuccess,
					error: function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			}
	});

	<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
	geo.getcurrentposition();
	<!--{/if}-->
	$('#postsubmit').on('click', function() {
		var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}

		obj.attr('disable', 'true').removeClass('btn_pn_blue').addClass('btn_pn_grey');
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
        
		var postlocation = '';
		//if(geo.errmsg === '' && geo.loc) {
//			postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
//		}

		$.ajax({
			type:'POST',
			url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

	$(document).on('click', '.del', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});
</script>
<script type="text/javascript">
    $(function () {
		var currYear = (new Date()).getFullYear();	
		var opt={};
		opt.date = {preset : 'date'};
		opt.datetime = {preset : 'datetime'};
		opt.time = {preset : 'time'};
		opt.default = {
			theme: 'android-ics light', 
		    display: 'modal', 
		    mode: 'scroller', 
			dateFormat: 'yyyy-mm-dd',
			lang: 'zh',
			showNow: true,
			nowText: "当前时间",
		    startYear: currYear - 10, 
		    endYear: currYear + 10 
		};

		$("#appDate").mobiscroll($.extend(opt['date'], opt['default']));
		var optDateTime = $.extend(opt['datetime'], opt['default']);
		var optTime = $.extend(opt['time'], opt['default']);
		$("#rushreplyfrom").mobiscroll(optDateTime).datetime(optDateTime);
		$("#rushreplyto").mobiscroll(optDateTime).datetime(optDateTime);
		$("#endtime").mobiscroll(optDateTime).datetime(optDateTime);
		$("#starttimefrom_0").mobiscroll(optDateTime).datetime(optDateTime);
		$("#starttimefrom_1").mobiscroll(optDateTime).datetime(optDateTime);
		$("#starttimeto").mobiscroll(optDateTime).datetime(optDateTime);
		$("#activityexpiration").mobiscroll(optDateTime).datetime(optDateTime);
		$("#item_expiration").mobiscroll(optDateTime).datetime(optDateTime);
		$("#typeoption_lpkp").mobiscroll(optDateTime).datetime(optDateTime);
		$("#typeoption_lpjf").mobiscroll(optDateTime).datetime(optDateTime);
		$("#typeoption_grqzzpsr").mobiscroll(optDateTime).datetime(optDateTime);
		$("#typeoption_grqzzpsj").mobiscroll(optDateTime).datetime(optDateTime);
		$("#typeoption_escsp").mobiscroll(optDateTime).datetime(optDateTime);
		$("#typeoption_escnj").mobiscroll(optDateTime).datetime(optDateTime);
		$("#typeoption_escbx").mobiscroll(optDateTime).datetime(optDateTime);
		$("#appTime").mobiscroll(optTime).time(optTime);
    });
</script>

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->












