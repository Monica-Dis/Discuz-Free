<?php exit;?>
<!--{template common/header}-->
<!-- main threadlist start -->
	<div id="s2" class="swiper-container ">
	<style>
.loading{ text-align:center;}
.loading img{ margin: 10px auto;width:40px; height:40px}
</style>

	<div class="swiper-wrapper" id="containerss">


 <div class="xlmmdp-containers" style="width:100%">

<div class="xlmmrbs xlmmflnavs-list white cl">
            <ul class="pt15 p020">
          				<li $currentview['hot']><a href="forum.php?mod=guide&view=hot" class="circle">热门</a></li>
				<li $currentview['newthread']><a href="forum.php?mod=guide&view=newthread" class="circle">新发表</a></li>
				<li $currentview['digest']><a href="forum.php?mod=guide&view=digest" class="circle">精华</a></li>
				<li $currentview['sofa']><a href="forum.php?mod=guide&view=sofa" class="circle">{lang guide_sofa}</a></li>
						 </ul>
          </div>

	<!--{loop $data $key $list}-->
		<!--{subtemplate forum/guide_list_row}-->
	<!--{/loop}-->



  	</div>


</div>
 </div>
   <script src="template/xlmmapp/m-img/dp.js?{VERHASH}"></script>
<script type="text/ecmascript">
 (function($){

$(function(){
    $('.xlmmdp-containers').dropload({
        scrollArea : window,
        domUp : {
            domClass   : 'dropload-up',
            domRefresh : '',
            domUpdate  : '<div class="dropload-update loading"><img src="template/xlmmapp/m-img/lo.png"></div>',
            domLoad    : '<div class="loading"><img src="template/xlmmapp/m-img/lo.gif"></div>'
        },
        loadUpFn : function(me){
window.location.reload()
        },


    });
});



})(jQuery);




</script>
<!--{template common/sbar}-->
<!--{template common/footer}-->

