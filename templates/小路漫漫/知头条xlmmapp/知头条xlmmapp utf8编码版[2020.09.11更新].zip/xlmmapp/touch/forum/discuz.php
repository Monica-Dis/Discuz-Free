<?php exit;?>
<!--{if  $_GET['forumlist'] == 1 || $gid}-->
<!--{template common/header}-->
<style>
.swiper-container-autoheight .swiper-wrapper { align-items: flex-start; transition-property: transform,height;}
.swiper-slide.slideauto {height: auto;}
</style>

   <script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>
<script src="template/xlmmapp/m-img/mb.js?{VERHASH}" charset="{CHARSET}"></script>
<script>var formhash = '{FORMHASH}', allowrecommend = '1';</script>
<script src="template/xlmmapp/m-img/fav.js?{VERHASH}" charset="{CHARSET}"></script>
<!--{if $_GET['visitclient']}-->

<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->

<!-- header start -->
<!--{if $showvisitclient}-->

<div class="visitclienttip vm" style="display:block;">
	<a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>	
	<p>
		{lang downloadzslttoshareview}
	</p>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
		$('.visitclienttip').css('display', 'block');
	}
</script>

<!--{/if}-->

<!-- header end -->
<!--{hook/index_top_mobile}-->
</div>
</div>
		<div id="s2" class="swiper-container ">
<div class="swiper-wrapper" >
<!-- main forumlist start -->

	<!--{if !empty($_G['setting']['grid']['showgrid']) && empty($gid)}-->
	<div class="swiper-slide slideauto">
				<!--{if !$_G['setting']['grid']['gridtype']}-->
<div id="xlmmbn" class="xlmmbnss swiper-container mt10">
  <div class="swiper-wrapper">
 									<!--{loop $grids['slide'] $stid $svalue}-->
   <div class="swiper-slide">
    <a href="{$svalue[url]}" title="{$svalue[subject]}">
      <img src="$svalue[image]" title="{$svalue[subject]}" />
      <h2>{$svalue[subject]}</h2></a></div>
									<!--{/loop}-->
   </div>
 <div class="pagination"></div>
</div>

<script>
    var xlmmbnss = new Swiper('.xlmmbnss', {
            loop: true,
      autoplay: {
           delay: 3000,
   },
passiveListeners : false,
     	resistanceRatio: 0,
        pagination: {
            el: '#xlmmbn .pagination',
          type: 'fraction',
     }
    });
</script>
<!--{/if}-->
<div class="home-sub-menu cl ">
  <a class="sub-menu-item">
    <span class="category menu-icon" style="font-size:8px;">今日</span>
    <span class="sub-title">$todayposts 篇</span></a>
  <a class="sub-menu-item">
    <span class="xlmmyest menu-icon" style="font-size:8px;">昨日</span>
    <span class="sub-title">$postdata[0]</span></a>
   <a class="sub-menu-item">
    <span class="topic menu-icon" style="font-size:8px;">主题</span>
    <span class="sub-title">$threads</span></a>
 <a class="sub-menu-item">
    <span class="must menu-icon" style="font-size:8px;">帖子</span>
    <span class="sub-title">$posts</span></a>
  <a class="sub-menu-item">
    <span class="wallpaper menu-icon" style="font-size:8px;">会员</span>
    <span class="sub-title">$_G['cache']['userstats']['totalmembers']</span></a>
</div>

 	<!--{if empty($gid) && $announcements}-->
  <div class="xlmmhd1tit cl">
  <span class="xlmmtithd1">公告板</span>
<div class="xlmmggbs">
<ul class="swiper-wrapper">
$announcements
</ul>
</div>
</div>
 <script type="text/javascript">
 $('.xlmmhd1tit li').addClass('swiper-slide'); 
  var xlmmggbs = new Swiper('.xlmmggbs',{
     direction: 'vertical',
	   loop: true,
      autoplay: {
        delay: 6000,DisableOnInteraction : false,
   },
    });
    </script>
	<!--{/if}-->
<div class="white cl" style=" padding:0 20px;margin-top:12px">
<div class="xlmmmtit cl">
<span class="y"><a href="./">查看更多&gt;&gt;</a></span>
<h2>{lang collection_lastthread}</h2>
</div>
<div class="xlmmmgtit cl">
<ul>
										{eval $xlmmts = 1;}
				        	<!--{loop $grids['newthread'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
<li><i>$thread[dateline]</i><span class="ph$xlmmts">$xlmmts</span><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">$thread[subject]</a></li>
														{eval $xlmmts++;}
				<!--{/loop}-->
</ul>
</div>
</div>            
<div class="white cl" style=" padding:0 20px;margin-top:12px">
<div class="xlmmmtit cl">
<span class="y"><a href="./">查看更多&gt;&gt;</a></span>
<h2>{lang show_newthreads}</h2>
</div>
<div class="xlmmmgtit cl">
<ul>
										{eval $xlmmtsp = 1;}
				        	<!--{loop $grids['newreply'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
<li><i>$thread[dateline]</i><span class="ph$xlmmtsp">$xlmmtsp</span><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">$thread[subject]</a></li>
														{eval $xlmmtsp++;}
				<!--{/loop}-->
</ul>
</div>
</div>            
<div class="white cl" style=" padding:0 20px;margin-top:12px">
<div class="xlmmmtit cl">
<span class="y"><a href="./">查看更多&gt;&gt;</a></span>
<h2>最新{lang hot_thread}</h2>
</div>
<div class="xlmmmgtit cl">
<ul>
										{eval $xlmmtsh = 1;}
				        	<!--{loop $grids['hot'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
<li><i>$thread[dateline]</i><span class="ph$xlmmtsh">$xlmmtsh</span><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">$thread[subject]</a></li>
														{eval $xlmmtsh++;}
				<!--{/loop}-->
</ul>
</div>
</div>            
					<!--{if $_G['setting']['grid']['gridtype']}-->
<div class="white cl" style=" padding:0 20px;margin-top:12px">
<div class="xlmmmtit cl">
<span class="y"><a href="./">查看更多&gt;&gt;</a></span>
<h2>{lang post_digest_thread}</h2>
</div>
<div class="xlmmmgtit cl">
<ul>
										{eval $xlmmtsj = 1;}
				        	<!--{loop $grids['digest'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
<li><i>$thread[dateline]</i><span class="ph$xlmmtsj">$xlmmtsj</span><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">$thread[subject]</a></li>
														{eval $xlmmtsj++;}
				<!--{/loop}-->
</ul>
</div>
</div>            
					<!--{/if}-->

</div>            
					<!--{/if}-->


<div class="swiper-slide slideauto">
<!-- main flist start -->
     
 	<!--{if empty($gid) && $announcements}-->
  <div class="xlmmhd1tit ggslide cl">
  <span class="xlmmtithd1">公告板</span>
<div class="xlmmggbs">
<ul class="swiper-wrapper">
$announcements
</ul>
</div>
</div>
 <script type="text/javascript">
 $('.xlmmhd1tit.ggslide li').addClass('swiper-slide'); 
  var xlmmggbs = new Swiper('.ggslide .xlmmggbs',{
     direction: 'vertical',
	   loop: true,
      autoplay: {
        delay: 6000,DisableOnInteraction : false,
   },
    });
    </script>
	<!--{/if}-->
          <style>
.xlmmhd1tit.ggslide li em{display: none;}
.boards-block {overflow: hidden;}
.boards-title {padding: 10px 20px; display:block;}
.boards-title-text {font-size: 16px;font-weight: 500;color: #333;}
.boards-container {display: flex;flex-wrap: wrap; padding-bottom:7px}
.boards-container .f-link {display: block;width: 50%;margin-bottom: 8px;}
.li-board {margin: 5px;background: #fff;display: flex;align-items: center;margin:0 4px;height: 88px;/*box-shadow: rgb(239, 239, 239) 0px 2px 9px 0px;border-top-left-radius: 4px;border-top-right-radius: 4px;border-bottom-right-radius: 4px;border-bottom-left-radius: 4px;*/ border:1px solid #f3f3f3}
.f-flex-img {display: flex;justify-content: center;align-items: center;overflow: hidden;background: #f2f4fa;}
.flex-none {flex: none;}
.li-board-icon {width: 44px;height: 44px;border-radius: 10px;background-color: #ebebeb;margin: 0 16px; margin-right:12px}
.li-board-icon img{ width: 44px;height: 44px;}
.li-board-left {position: relative;height: 100%;flex: auto;margin-right: 10px;}
.li-board-left-layer {position: absolute;top: 0;left: 0;width: 100%;height: 100%;display: flex;flex-direction: column;justify-content: center;}
.ellipsis-line-1 {overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}
.li-board-title{height: 20px;font-size: 14px;line-height: 20px;font-weight: 400;color: #666;}
.li-board-num {height: 18px;font-size: 13px;line-height: 18px;font-weight: 400;color: #aeaeae;display: inline-flex;align-items: center;}
.li-board-num img {width: 13px;margin-right: 4.5px;}
</style>
   <!--{eval $xlmmfi=1;}-->
<!--{eval $gidiconnum = 0;}-->
<!--{loop $catlist $key $cat}-->
<!--{eval $caturl = !empty($cat['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$cat['domain'].'.'.$_G['setting']['domain']['root']['forum'] : '';}-->
<!--{eval $gidiconnum ++;}-->  
 <div class="boards-block  white mt10">
   <a href="{if !empty($caturl)}$caturl{else}forum.php?gid=$cat[fid]{/if}" class="boards-title cl">
    <span class="boards-title-text skeleton-blk z">$cat[name]<!--{if empty($gid)}--> &gt;&gt;<!--{/if}--></span>
   </a> 
   <div class="boards-container">
				<!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->
  <div class="f-link " >
     <div class="li-board">
      <div class="f-flex-img li-board-icon flex-none ">
<!--{if $forum[icon]}-->
						$forum[icon]
					<!--{else}-->
						<a href="$forumurl"><img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" alt="$forum[name]" /></a>
					<!--{/if}-->
      </div> 
      <div class="li-board-left">
       <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="li-board-left-layer">
        <div class="li-board-title ellipsis-line-1 skeleton-blk">
      {$forum[name]}
        </div> 
        <div class="li-board-num skeleton-blk">
       主题 {echo dnumber($forum[threads])}
        </div>
       </a>
      </div>
     </div></div>
			<!--{/loop}-->
   </div>
  </div>
			<!--{/loop}-->

  <!-- main flist end -->
</div>            
<!-- main forumlist end -->
</div>
</div>
	<!--{if !empty($_G['setting']['grid']['showgrid']) && empty($gid)}-->
<script type="text/ecmascript">
 (function($){

    var swhotabsIndex = $('.swhotabs li.a').index();
var idx = swhotabsIndex;
idxChange(idx)
if($(".swhotabs li.a").length > 0) {
var xlmminx = $(".swhotabs li.a").offset().left + $(".swhotabs li.a").width() >= $(window).width() ? $(".swhotabs li.a").index() : 0;
}else{
var xlmminx = 0;
}	
     var my1 = new Swiper('#s1.swhotabs', {
        freeMode: true,
        slidesPerView: 'auto',
 initialSlide : xlmminx,
      	resistanceRatio: 0,
  });

	   var my2 = new Swiper('#s2', {
initialSlide: swhotabsIndex,
	    	resistanceRatio: 0,
  autoHeight:true,
   })

    my1.on('tap', function (event) {
        console.log(this.clickedIndex);
        idx = this.clickedIndex;
        idxChange(idx)
        this.slideTo(this.clickedIndex);
        my2.slideTo(this.clickedIndex);
    })

    my2.on('slideChange', function (event) {
        console.log(this.activeIndex);
        idx = this.activeIndex;
        idxChange(idx);
        my1.slideTo(this.activeIndex);
    });

function idxChange(idx) {
   var obj = $('#s1 .swiper-slide');
 obj.removeClass('active');
 obj.eq(idx).addClass('active');
//var obs = $("#s2 .swiper-slide").width();
//var obss = $('#s2 .xlmmfl1').css('left',obs);
//var obsss = $('#s2 .xlmmfr1').css('left',obs+105);
}
})(jQuery);
</script>
					<!--{/if}-->
<!--{hook/index_middle_mobile}-->
<!--{/if}-->
<!--{template common/footer}-->

<!--{else}-->
	<!--{eval dheader("Location: " . $_G['cache']['plugin']['xlmmappgl']['xlmmappglinx']);exit;}-->
<!--{/if}-->



