<?PHP exit('Access Deniedxiaoluanman');?>
<!--{template common/header}-->
<!--[name]{lang portalcategory_viewtplname}[/name]-->
<style type="text/css">

html {height:100%; background-color:#fff}
body{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box; position:relative; z-index:0;width:100%;min-width:300px;min-height:100%;margin:0 auto;box-shadow:0 0 10px rgba(0,0,0,0.3) ; background:#fff !important;}
body{overflow-x:hidden;line-height:1.5;background-color:#fff;}
body,input,button,select,textarea{font:12px/1.5 "microsoft yahei";color:rgb(105,105,105);}
article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block;margin:0;padding:0}
a{text-decoration:none!important;-webkit-transition:0.25s;transition:0.25s;}
a:hover,a:focus{text-decoration:none;}
.xlmm_rec_alert { padding: 10px 16px;color: #fff; background: rgba(0,0,0,0.65);border-radius: 3px; font-size: 14px;font-weight: 100;}
p.ycbr { height:2px;}
.xlmm-view{background-color:#fff; padding:0 15px;}
.xlmm-view .titss h1{font-size: 20px !important;padding-top: 16px;line-height: 28px;font-weight: bolder;color: #3A3A3A;}
.article-header {position: relative;}
.clearfix::after {visibility: hidden;display: block;font-size: 0;content: " ";clear: both;height: 0;}

.pgc-bar-top {margin-top: 12px;}
.pgc-bar-top a.avatar-link {display: block;float: left;}
.avatar {height: 32px;width: 32px;border: 0;border-radius: 32px;}
.pgc-bar-top .subtitle {padding: 1px 0 0 8px;font-size: 0;float: left;}
.pgc-bar-top .name {line-height: 16px;font-size: 12px;}
.pgc-bar-top .name a {color: #406599;}
.pgc-bar-top .subtitle a {color: #333;}
.pgc-bar-top .time {font-size: 0;}
.pgc-bar-top .time span {font-size: 11px;display: inline-block;vertical-align: middle;color: #999;}
.article-header .favor-wrapper {position: absolute;top: 50%;right: 0;-webkit-transform: translateY(-50%);}
.article-header .favor-wrapper .favor-btn {background: #2a90d7;display: block;text-align: center;color: #fff;box-sizing: border-box;width: 72px;height: 28px;line-height: 28px;font-size: 12px;border-radius: 6px;}

.xlmm-view .titss .summary{font-size:11pt;padding:10px 0px;color:#999;margin:10px 0;border-bottom:1px solid #ddd;border-top:1px solid #ddd;}
.xlmm-view .titss .summary strong{color:#FB6156}
.xlmm-view .mess{line-height:30px;font-size:18px;}
.xlmm-view .mess img{max-width:100% !important; margin-top:2px;}
.xlmm-view .mess iframe{max-width:100%!important; height:300px!important;}
.xlmm-view .xlmm_share{width:90%;padding:5px 10px;border-radius:5px;margin:10px 0;float:left;background-color:#eee;}
.xlmm-view .xlmm_share h3,.xlmm-view .xlmm_share .bdsharebuttonbox{line-height:32px;padding-right:10px;float:left}
.xlmm-view .xlmm_share .bdsharebuttonbox{width:190px;}
.xlmm-view .sxtit em{width:100%;line-height:25px;float:left;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-size:11pt;}

.xlmm-view .related{float:left;padding:5px 0; padding-bottom:10px;border-bottom:1px solid #ddd;border-top:1px solid #ddd;}
.xlmm-view .related li{list-style:noen;line-height:25px;width:92%;float:left;white-space: nowrap;text-overflow: ellipsis;overflow: hidden;}
.xlmm-view .related li a{font-size:11pt}
.xlmm-view .xlmm-comment{list-style:noen;line-height:25px;width:100%;float:left;}
.xlmm-view .xlmm-comment textarea{height:56px; margin-bottom:15px;text-indent:7px;width:100%}
.xlmm-view .xlmm-comment .btn{margin:0 0 20px 0;background-color:#0285f7;border-color:#0285f7;border:0px outset buttonface!important;text-align:center;height:30px;width:100%;line-height:30px;color: #FFFFFF;}
.xlmm-view .xlmm-comment .pinlun{position:relative;width:100%;color:#999;padding:16px 0;border-bottom:1px solid #ddd;}
.xlmm-view .xlmm-comment .pinlun .avatar{position:absolute;left:0px;top:16px;}
.xlmm-view .xlmm-comment .pinlun .avatar img{width:32px;height:32px;border-radius:50%;}
.xlmm-view .xlmm-comment .vuser,.xlmm-view .xlmm-comment .vtrim{font-size:11pt}
.xlmm-view .xlmm-comment .viewall a{display:block;text-align:center;font-size:15px;height:34px;line-height:34px;margin:10px;border-radius:2px;border:1px solid #e0e0e0;background-color:#f5f5f5;}
.xlmm-view .mb10{margin-bottom:10px}
.mt20{margin-top:20px}
.xlmm-view .plh3{font-size: 16px;display: inline-block;color: #505050;padding-bottom: 8px;font-weight: 400;border-bottom: 1px solid #f85959;}
/* 表态? */
.atd { margin: 15px auto; }
.atd img {width: 25px;}
.atd a { display: block; color: #999;}
.atd td { padding: 10px 10px 0 10px; text-align: center; vertical-align: bottom; }
.atd .atdc { position: relative; margin: 0 auto 10px; width: 10px; height: 30px; }
.atdc div { position: absolute; left: 0; bottom: 0; width: 10px; text-align: left; }
.atd .ac1 { background: #C30; }
.atd .ac2 { background: #0C0; }
.atd .ac3 { background: #F90; }
.atd .ac4 { background: #06F; }

</style>

<div class="xlmm-view">

			<div class="titss"> 
				<h1>$article[title] <!--{if $article['status'] == 1}--><span>({lang moderate_need})</span><!--{elseif $article['status'] == 2}--><span>({lang ignored})</span><!--{/if}--></h1> 

<div class="article-header">
        
            <div class="pgc-bar-top clearfix" >
                <a href="home.php?mod=space&uid=$article[uid]" class="avatar-link">
                    <div class="avatar">
                        <img src="{avatar($article[uid], small, true)}" alt="$article[username]" class="avatar">
                    </div>
                </a>
                <div class="subtitle">
                    <p class="name"><a href="home.php?mod=space&uid=$article[uid]" class="screen-name vwo-media-profile"><span style="transform-origin: 0px 0px 0px;opacity: 1;transform: scale(1, 1);">$article[username]</span>
</a></p>
                     <a href="javascript:;" class="time">
                        <span>$article[dateline]</span>
                     </a>
                </div>
            </div>
        
            <div class="favor-wrapper">
<!--{if !ckfollow($article['uid'])}-->
					<a id="xlmmfllow" class="gz_$article[uid] {if $_G['uid']}{else}dialog{/if}" onclick="xlmmfollows('xlmmfllow','gz_$article[uid]','$article[uid]')"{if $_G['uid']}  href="javascript:;"{else}href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$article[uid]"{/if}>  <span class="favor-btn xlmmjgz">立即关注</span></a>
				<!--{else}-->
					<a id="xlmmfllow" class="gz_$article[uid]" onclick="xlmmfollows('xlmmfllow','gz_$article[uid]','$article[uid]')" href="javascript:;">  <span class="favor-btn">取消关注</span></a>
				<!--{/if}-->     
            </div>
        </div>

			<!--{if $article[summary] && empty($cat[notshowarticlesummay])}--><div class="summary"><div><strong>{lang article_description}</strong> : $article[summary]</div><!--{hook/view_article_summary}--></div><!--{/if}-->
			</div>
			
			<div class="mess" id="ycbr">
			<p>$content[content]</p>                
			<!--{if $multi}--><div class="pgbox">$multi</div><!--{/if}-->      
			</div>    
	
	<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<div id="click_div">
		<!--{template home/space_click}-->
	</div>

		                                    

			<div class="sxtit w100">
				<!--{if $article['prearticle']}--><em>{lang pre_article}<a href="{$article['prearticle']['url']}">{$article['prearticle']['title']}</a></em><!--{/if}-->
				<!--{if $article['nextarticle']}--><em>{lang next_article}<a href="{$article['nextarticle']['url']}">{$article['nextarticle']['title']}</a></em><!--{/if}-->
			</div>

           
		    <!--{if $article['related']}-->
		    <div class="related mt20 w100">
<div class="xlmmmtit cl" style="border-bottom: .5px solid #e8e8e8; margin-bottom:10px">
<h2 style="font-size:16px; color:#222">相关阅读</h2>
</div>
			<ul>
            <!--{if $_G['setting']['version'] == 'X2.5'}-->
			<!--{loop $article['related'] $raid $rtitle}-->				
			<li><a href="portal.php?mod=view&aid=$raid">$rtitle</a></li>
			<!--{/loop}-->
            <!--{else}-->
			<!--{loop $article['related'] $value}-->
			<li><a href="portal.php?mod=view&aid=$value[aid]">$value[title]</a></li>
			<!--{/loop}-->
            <!--{/if}-->
			</ul>			
		    </div>
				<div class="cl">			</div>

	    <!--{/if}-->
           
           <!--{$m_share}-->

		<!--{if $article['allowcomment']==1}-->
        <!--{eval $data = &$article}-->			
            <!--{subtemplate portal/portal_comment}-->
		<!--{/if}-->
{if $_G['uid']} 
<script type="text/javascript">
        function xlmmfollows(val,clsa,aid){
            popup.close();
if(document.getElementById(val).innerHTML.indexOf("xlmmjgz") >= 0){
var xlmmhref = 'home.php?mod=spacecp&ac=follow&op=add&fuid='+aid+'&hash={FORMHASH}';
}else{
var xlmmhref = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+aid;
}
            popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
            $.ajax({
                type:'GET',
                url:xlmmhref + '&inajax=1',
                dataType:'xml',
            })
            .success(function(s) {	
                if(s.lastChild.firstChild.nodeValue.indexOf("不能关注自己") >= 0){
popup.open('<div class="xlmm_rec_alert">不能关注自己</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("成功收听") >= 0){
$("."+clsa).html('<em class="favor-btn">取消关注</em>');
popup.open('<div class="xlmm_rec_alert">关注成功</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("取消成功") >= 0){
$("."+clsa).html('<em class="favor-btn xlmmjgz">立即关注</em>');
popup.open('<div class="xlmm_rec_alert">已取消关注</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("您已经收听了") >= 0){
			popup.open('<div class="xlmm_rec_alert">您已经关注过了</div>');
}

         var xlmmclose = setTimeout(popup.close,1500);
       })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        };

    </script>
{/if} 
</div>
		<script>
var div=document.getElementById("ycbr");
div.innerHTML=div.innerHTML.replace(/<br>/g,"<p class=\"ycbr\"></p>");
</script>
		<div class="clearfix">			</div>
<div class="plr15">
<div class="xlmmmtit cl" style="border-bottom: .5px solid #e8e8e8;">
<h2 style="font-size:16px; color:#222">为您推荐</h2>
</div>
</div>
<div class="xlmmdp-containers $xlaj">
<div class="plr15 white">
<ul id="xlmmjps$xlaj">

		{eval include TPLDIR.'/php/list.php';}
	<!--{loop $list $value}-->
				<!--{eval $article_url = fetch_article_url($value);
}-->
	{eval include TPLDIR.'/php/portal_list.php';}
	<li>
<a href="$article_url" class="HotQuestionsItem<!--{if $xlmmal ==0 }--> HotQuestionsItem-mul<!--{elseif $xlmmal <= 2}--><!--{elseif $xlmmal >2}--> HotQuestionsItem-mul<!--{/if}-->">
<div class="HotQuestionsItem-contain">
	<h3 class="HotQuestionsItem-title">$value[title]</h3>
<!--{if $xlmmal >2}-->
<div class="HotQuestionsItem-mulImgList" style="margin-top:6px">
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==3) break;}-->
	<div class="HotQuestionsItem-mulImgWrapper">
		<img class="HotQuestionsItem-mulImg" src="<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->">
	</div>
<!--{/loop}-->
</div>
<!--{/if}-->
	<div class="HotQuestionsItem-description">
		<!--{if $value[viewnum] > 0}-->$value[viewnum]<!--{else}-->0<!--{/if}--> 次点击 · $value[commentnum] 评论
	</div>
</div>
<!--{if $xlmmal ==0 }-->
<!--{elseif $xlmmal <= 2}-->
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==1) break;}-->
<img class="HotQuestionsItem-img" src="<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->">
<!--{/loop}-->
<!--{/if}-->
</a>
	</li>
			<!--{/loop}-->

</ul>
	 </div>
    <div id="ajaxlast" style="text-align: center;position: relative;padding: 12px 0; padding-bottom:6px;"><a href="{echo getportalcategoryurl($cat[catid])}" style="cursor: pointer;font-size: 14px;line-height: 22px;border-radius: 29px;color: #406599;">查看更多</a></div>
</div>
		<!--{if $article['allowcomment']==1}-->
                   <!--{eval $xlmmplk=DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='aid' and id=".$article[aid]."");}--> 
                   <!--{eval $xlmmplks= DB::result_first("select count(*)  FROM ".DB::table("home_favorite")." WHERE `idtype`='aid' and id=".$article[aid]."");}--> 
<div class="xlmmthftc cl">
	<a {if $_G['uid']} onClick="nryhf()" {else}href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}"{/if}class="nrdb_hf {if $_G['uid']}{else}dialog{/if}">说点什么吧...</a>
	<a onClick="nrywfx()" style="margin-top:10px;"><i class="iconfont iconfx"></i></a>
	<a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" class="dialog"><i {if $xlmmplk[id]}style="color:#f15450" {/if}class="iconfont iconsc"></i><em id="favoritenumber"{if $xlmmplks<1} style="display:none"{/if}>$xlmmplks</em></a>
	<a onclick="javascript:document.getElementById('xlmmgpl').scrollIntoView()"><i class="iconfont iconhf"></i><em id="recommendv_add">$data[commentnum]</em></a>
</div>
	<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"$article[title] - $_G['setting'][sitename]","bdMini":"2","bdStyle":"0","bdSize":"16"},"share":{},"image":{"viewList":["qzone","tsina","tqq","renren","weixin"],"viewText":"","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='{$_G['siteurl']}template/xlmmapp/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
 <!--{/if}-->

<!--{template common/footer}-->











