<?php exit;?>
   	<xlmmajax></xlmmajax>
<div class="xlmmdp-containers $xlaj">
 <!--{if $xlmmuidfavs['followuid']}-->
 				<!--{else}-->
<!--{if $_GET['view'] == 'follow'}-->
<a class="xlmmksgz white mt10">
                                 <img src="template/xlmmapp/m-img/start.png">
<div class="xlmmksgzp mt15">
          您想要认识更多志同道合的朋友吗?
</div>
<div class="xlmmksgzbt mt15">
       开始吧
</div>

</a>

<ul class="app-box p20 white mt10">
<div style="font-size:18px; color:#000; font-weight:700; margin-bottom:8px">
     你可能感兴趣的人
</div>

    						        	<!--{loop $xlmmusers $key $urers}-->
{eval $urers['date'] = str_replace('"', '\'', dgmdate($urers['regdate'], 'u', '9999', getglobal('setting/dateformat'))); $xlmmkeys = $key + 1;}
		<li class="flexssx">
				<div class="flexs p140" style="border-bottom: .5px solid #f0f0f0;margin-left:75px">
	<a href="home.php?mod=space&uid=$urers['uid']" class="app-icon icon-66" style="margin-left:-75px"><img src="uc_server/avatar.php?uid=$urers['uid']&size=small" ></a>
			<div class="product-info">
				<a href="home.php?mod=space&uid=$urers['uid']" class="app-name"><span class="xlmmsssn"> $urers['username']</span></a>
					<p class="edit-remark">
					入驻于：$urers['date']
				</p>
			<p class="info-data">
					<span>$urers['threads']个主题</span>&nbsp;&nbsp;<span style="font-size:18px; ">·</span>&nbsp;&nbsp;<span>$urers['posts']个帖子</span>
				</p>
			</div>
			<!--{if !ckfollow($urers['uid'])}-->
	<a id="xlmmfllow_$urers['uid']" class="app-gz list-app-gz gz_$urers['uid'] {if $_G['uid']}{else}dialog{/if} btn-box" onClick="xlmmfollows('xlmmfllow_$urers['uid']','gz_$urers['uid']','$urers['uid']')"{if $_G['uid']}  href="javascript:;"{else}href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$urers['uid']"{/if}><span class="favor-btn xlmmjgz">+ 关注</span></a>
	    				<!--{else}-->
							<a id="xlmmfllow_$urers['uid']" class="app-gz list-app-gz gz_$urers['uid']" onClick="xlmmfollows('xlmmfllow_$urers['uid']','gz_$urers['uid']','$urers['uid']')" href="javascript:;">  <span class="favor-btn">已关注</span></a>
	<!--{/if}-->
				</div>
	</li>
    <!--{/loop}-->
</ul>
 
{if $_G['uid']}
{/if}
 			<!--{/if}-->
 			<!--{/if}-->
<!--{if $_GET['view'] == 'follow' ||  $_GET['view'] == 'hot'}-->
	<!--{else}-->
{eval $xlmmappglbls = xlmmappglbls();
$xlmmappglbls['xlmmin_block'] = xlmmappglbls_block($xlmmappglbls['xlmmin_block']);}
<!--{$xlmmappglbls['xlmmin_block']}-->
 			<!--{/if}-->
			<!--{if $xlmmuidfavs['followuid']}-->
			<!--{if $count==0}-->
<div class="mt10" style="text-align:center; background:#FFFFFF; padding:40px 0 80px 0; height:100%"><svg width="150" height="120" viewBox="0 0 150 120" class="Topstory-newUserFollowCountPanelIcon" fill="currentColor"><g fill="none" fill-rule="evenodd"><path fill="#EBEEF5" d="M44 31.005v55.99A3.003 3.003 0 0 0 47.003 90h53.994A3.005 3.005 0 0 0 104 86.995v-55.99A3.003 3.003 0 0 0 100.997 28H47.003A3.005 3.005 0 0 0 44 31.005zm-3 0A6.005 6.005 0 0 1 47.003 25h53.994A6.003 6.003 0 0 1 107 31.005v55.99A6.005 6.005 0 0 1 100.997 93H47.003A6.003 6.003 0 0 1 41 86.995v-55.99z" fill-rule="nonzero"></path><path fill="#F7F8FA" d="M59 50a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 40.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5zM59 73a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 63.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5z"></path></g></svg><div style="font-size: 15px;color: grey;">还没有任何内容哦</div></div>	
 			<!--{/if}-->
 			<!--{/if}-->

			<!--{if $count==0}-->
 				<!--{else}-->
<!--{if $_GET['view'] == 'hot'}-->
 				<!--{else}-->
<ul class="xlmmbw" id="xlmmjps$xlaj">
		<start$xlaj></start$xlaj>
							        	<!--{loop $grids['newthread'] $key $thread}-->
  											<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
			{eval include TPLDIR.'/php/img.php';}
<li class="note-flow p20{if $xlmmal >0} have-img{/if} white">
<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
	<!--{if $_GET['view'] == 'follow'}-->
	<div class="author " style="padding-bottom:12px">
     		<div class="avatar">
   <img src="uc_server/avatar.php?uid=$thread[authorid]&amp;size=middle">
	</div>
    <div class="name">
        $thread[author]
	</div>
	</div>
		<!--{/if}-->
<h6 class="title">
   $thread[subject]
	</h6>
<span class="xlmmcont{if $_GET['view'] == 'follow'} mt10{/if}">
{if $xlmmal >0}
     <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
     					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment'] ; }
		<!--{/if}-->
<span class="wrap-img inline-3MDdF_0" style="width: 85px; height: 65px;"><img src="$xlmmimg"></span>
          	 <!--{eval $i++}-->
<!--{eval if($i==1) break;}-->
<!--{/loop}--> 
{/if}
<div class="summary">
		<!--{if !$_GET['view'] == 'follow'}-->
	<div class="author" style="padding-right:0">
     		<div class="avatar">
   <img src="uc_server/avatar.php?uid=$thread[authorid]&amp;size=middle">
	</div>
    <div class="name">
        $thread[author]
	</div>
	</div>
			<!--{/if}-->
<p class="abstract{if $_GET['view'] == 'follow'} m0{/if}">
 $xiaolu['fmessage']
	</p>
</div>
</span>
</a>
<div class="meta oneline">
<span>$thread[views] 次浏览</span>&nbsp;&nbsp;<span style="font-size:18px; ">·</span>&nbsp;&nbsp;<span class="name">$thread[replies] 条评论</span>
</div>
</li>
<!--{/loop}--> 
    </ul>
 <end$xlaj></end$xlaj>
	<div id="allpgs$xlaj" style="display:none">{echo $thispage = ceil($count / 10);}</div><div id="oallpgs$xlaj" style="display:none">$_G['page']</div>
     <a href="javascript:;" id="xlmmsdj" class="getMore$xlaj"><div style="text-align: center;line-height:40px;color: #999;">点击加载更多</div></a>
	<!--{/if}-->
	<!--{/if}-->
<!--{if $_GET['view'] == 'hot'}-->
			<!--{if $count}-->

<div class="xlmmrbs xlmmflnavs-list white cl" data-role="navbar">
            <ul class="pt15 p020">
          				<li {if $_GET['view'] == 'hot'}class="a"{/if}><a href="forum.php?mod=guide&view=hot" class="circle">热点</a></li>
				<li $currentview['newthread']><a href="forum.php?mod=guide&view=newthread" class="circle">新发表</a></li>
				<li $currentview['digest']><a href="forum.php?mod=guide&view=digest" class="circle">新精华</a></li>
				<li $currentview['sofa']><a href="forum.php?mod=guide&view=sofa" class="circle">抢沙发</a></li>
						 </ul>
          </div>

	<ul class="app-top-list p20 white pt5" id="xlmmjps">
			<start></start>
			   <!--{eval $xlmmi=1;}-->
							        	<!--{loop $grids['newthread'] $key $thread}-->
		<li>
<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="HotQuestionsItem">
<div class="xlmmphbst"><span class="num icon-top-$xlmmi">$xlmmi</span></div><div class="HotQuestionsItem-contain">
	<h3 class="HotQuestionsItem-title">
    <!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
			{eval include TPLDIR.'/php/img.php';}
$thread[typehtml] $thread[sorthtml]
										$thread[subject]</h3>
	<div class="HotQuestionsItem-description">
	<!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--> 查看 · <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--> 回复
	</div>
</div>
                 <!--{if $xlmmal >0}-->
     <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
     					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment'] ; }
		<!--{/if}-->
<img class="HotQuestionsItem-img" src="$xlmmimg">
          	 <!--{eval $i++}-->
<!--{eval if($i==1) break;}-->
<!--{/loop}--> 
	<!--{/if}-->
</a>
		</li>
		 <!--{eval $xlmmi++}-->
				<!--{/loop}-->
					</ul>
		 <end></end>
		<!--{else}-->
<div style="text-align:center; background:#FFFFFF; padding-bottom:20px;"><svg width="150" height="120" viewBox="0 0 150 120" class="Topstory-newUserFollowCountPanelIcon" fill="currentColor"><g fill="none" fill-rule="evenodd"><path fill="#EBEEF5" d="M44 31.005v55.99A3.003 3.003 0 0 0 47.003 90h53.994A3.005 3.005 0 0 0 104 86.995v-55.99A3.003 3.003 0 0 0 100.997 28H47.003A3.005 3.005 0 0 0 44 31.005zm-3 0A6.005 6.005 0 0 1 47.003 25h53.994A6.003 6.003 0 0 1 107 31.005v55.99A6.005 6.005 0 0 1 100.997 93H47.003A6.003 6.003 0 0 1 41 86.995v-55.99z" fill-rule="nonzero"></path><path fill="#F7F8FA" d="M59 50a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 40.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5zM59 73a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 63.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5z"></path></g></svg><div style="font-size: 15px;color: grey;">还没有任何内容哦</div></div>	
				<!--{/if}-->


<!--{/if}-->
  	</div>
<script type="text/javascript">
       function xlmmfollows(val,clsa,aid){
            popup.close();
if(document.getElementById(val).innerHTML.indexOf("xlmmjgz") >= 0){
var xlmmhref = 'home.php?mod=spacecp&ac=follow&op=add&fuid='+aid+'&hash={FORMHASH}';
}else{
var xlmmhref = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+aid;
}
            popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
            $.ajax({
                type:'GET',
                url:xlmmhref + '&inajax=1',
                dataType:'xml',
            })
            .success(function(s) {	
                if(s.lastChild.firstChild.nodeValue.indexOf("不能关注自己") >= 0){
popup.open('<div class="xlmm_rec_alert">不能关注自己哦</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("成功收听") >= 0){
$("."+clsa).html('<em class="favor-btn">已关注</em>');
var numObj = $('#membernumgz');
var memberNum = parseInt(numObj.html());
numObj.html(memberNum+1);
popup.open('<div class="xlmm_rec_alert">关注成功</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("取消成功") >= 0){
$("."+clsa).html('<em class="favor-btn xlmmjgz">+ 关注</em>');
var numObj = $('#membernumgz');
var memberNum = parseInt(numObj.html());
numObj.html(memberNum-1);
popup.open('<div class="xlmm_rec_alert">已取消关注</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("您已经收听了") >= 0){
popup.open('<div class="xlmm_rec_alert">您已经关注过了</div>');
}

        {if $_G['uid']} var xlmmclose = setTimeout(popup.close,1500);{/if}
       })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        };
      //alert(window.location.href);


  xlmmurl$xlaj= "$xlajul";
 var allnum$xlaj= $("#allpgs$xlaj").text();
 var num$xlaj = $("#oallpgs$xlaj").text();
    var nomore$xlaj= "<div style=\"text-align: center;line-height:40px;color: #999;\">我也是有底线的哦</div>";
       if(num$xlaj >= allnum$xlaj) { 
 $('.getMore$xlaj').html(nomore$xlaj);;
}
  	$('.getMore$xlaj').click(function(e){
       if(num$xlaj >= allnum$xlaj) { 
}
else {
      num$xlaj++;  
 $.ajax({
             url:xlmmurl$xlaj+'&page='+num$xlaj+'' ,
        type:'get',
        dataType: 'html',
        beforeSend:function(){
            $('.getMore$xlaj').html("<div style=\"text-align: center;line-height:40px;color: #999;\"><img src=\"static/image/common/loading.gif\" width=\"16\" height=\"16\" class=\"vm\" /> 载入中...</div>"); 
        },
        success:function (data$xlaj){
		     var newdatas$xlaj = data$xlaj.match(/<start$xlaj><\/start$xlaj>([\s\S]+?)<end$xlaj><\/end$xlaj>/);
		     var newdatas1 = newdatas$xlaj;
$('#xlmmjps$xlaj').append(newdatas1[1]);    
                  $('.getMore$xlaj').html("<div style=\"text-align: center;line-height:40px;color: #999;\">点击加载更多</div>"); 
          if(num$xlaj >= allnum$xlaj) { 
 $('.getMore$xlaj').html(nomore$xlaj);;
}
 $("#containerss").css('height',$("#s2 .swiper-slide.sxlmm-active").height())
     },error: function() {
            $('.getMore$xlaj').html("<div style=\"text-align: center;line-height:40px;color: #999;\">数据获取失败</div>");
        }
  })
	        }
});

</script>
	  <xmle></xmle>

