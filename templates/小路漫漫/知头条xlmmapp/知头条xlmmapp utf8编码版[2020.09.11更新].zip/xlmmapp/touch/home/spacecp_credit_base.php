<?PHP exit('Access 积分页面，xlmm2018');?>
<!--{template common/header}-->
<style type="text/css">
/* 积分中心 */
.xlmmmycredit {}
.xlmmmycredit .xlmmcre {font-size: 12px;color: #999;margin: 0 0 10px 0px;padding: 10px 0;background: #fff;}
.xlmmmycredit .xlmmcre .jfzsxs {margin-left:16px;font-size: 20px;color: #666;}
.xlmmmycredit .xlmmcre .jfzsxs i {margin-right: 8px;font-size: 20px;}
.xlmmmycredit .xlmmcre p.jfsm {line-height: 15px;font-size: 13px;color: #999; padding:20px 0 10px; text-align:center;}
.xlmmmycredit .xlmmcre p u {text-decoration: none;}
.index-hot-list { margin-top:15px;border-top: 1px solid #efefef;}
.index-hot-list span { font-size:15px; color:#888; font-weight:500;}
.index-hot-list a {padding:15px 16px;}
	
.xlmmmycredit .xlmmcre2 {}
.xlmmmycredit .xlmmcre2 .jfjl_xm {padding: 12px 15px;background: #fff;border-bottom: 1px solid #f8f8f8;font-size: 14px;color: #333;position: relative;}
.xlmmmycredit .xlmmcre2 .jfjl_hb {font-size: 12px;color: #fff;padding-top: 5px;border-radius: 4px;text-align: center;height: 45px;width: 50px;background-color: #15bfff;}
.xlmmmycredit .xlmmcre2 .jfjl_hb span {font-size: 18px;color: #ffffff;display: block;line-height: 20px;}
.xlmmmycredit .xlmmcre2 .jfjl_sj {color: #666;position: absolute;left: 70px;padding-right: 10px;}
.xlmmmycredit .xlmmcre2 .jfjl_sj a {color: #666;display: block;}
.xlmmmycredit .xlmmcre2 .jfjl_sj a strong {font-weight: 400;}
.xlmmmycredit .xlmmjfxxx {padding: 10px 12px;font-size: 15px;background: #fff;border-bottom: 1px solid #efefef !important;}
.xlmmmycredit .xlmmjfxxx .zzxm_xmbt {width: 25%;color: #666;}
.xlmmmycredit .xlmmjfxxx .zzxm_xmnr {width: 75%;}
.xlmmzzxz{margin-top: 10px;padding: 10px;background: #fffdef;border: 1px dashed #e7e1cd;font-size: 13px;color: #999; }
.xlmmmycredit .xlmmjfxxx .zzxm_xmnr .px {width: 100%;line-height: 20px;padding: 0;background: #fff;border: 0;font-size: 15px;border-radius: 0;color: #000;outline: none;-webkit-appearance: none;}
.xlmmmycredit .xlmmjfxxx .zzxm_xmnr .ps {float: right;width: 40%;background-position:right;background-size: 15px auto;border: 0;border-radius: 0;color: #000;font-size: 15px;outline: none;-webkit-appearance: none;}
.xlmmmycredit .jfzz_zzan {margin: 15px 0 ;}
.xlmmbtss.pn, .xlmmmycredit .jfzz_zzan .pn {background: #15bfff;color: #fff;-webkit-appearance: none;display: block;margin: 0 auto;width: 100%;height: 44px;line-height: 44px;font-size: 16px;border: none;outline: none;text-align: center;text-decoration: none;overflow: hidden;border-radius: 2px;}

.tfm th {padding-bottom: 15px;width:75px;}
.tfm td { padding-bottom:15px}
.xlmmyzmx .sec_code { padding-left:0;}
</style>
<div style="padding:10px 0 0px;">
                  </div>
<div class="xlmmmycredit cl">
	<!--{if in_array($_GET['op'], array('base', 'buy', 'transfer', 'exchange'))}-->
		<div class="xlmmcre cl">
			<div class="jfzsxs cl"><i>总{lang credits}:</i>$_G['member']['credits']</div>
			<div class="index-hot-list white mt10 cl">
		   <!--{eval $xlmmji=1;}-->
		<!--{loop $_G['setting']['extcredits'] $id $credit}-->
				<!--{if $id!=$creditid}-->
<a href="javascript:;" class="b_b b_r"><h2>{$credit[title]}</h2><span><!--{echo getuserprofile('extcredits'.$id);}--></span></a>

		 <!--{eval $xlmmj++}-->
<!--{/if}-->
				<!--{/loop}-->
			<!--{if $_GET['op'] == 'buy'}-->
		<a href="home.php?mod=spacecp&ac=credit" class="b_b b_r"><h2 style="height:36px; line-height:36px;">积分首页</h2></a>
		<!--{else}-->
		<a href="home.php?mod=spacecp&ac=credit&op=buy" class="b_b b_r"><h2 style="height:36px; line-height:36px;">积分充值</h2></a>
<!--{/if}-->
</div>
<p class="jfsm">$creditsformulaexp</p>
		</div>
	<!--{/if}-->
	<!--{if $_GET['op'] == 'base'}-->
	<!--{if $loglist}-->
		<div class="xlmmcre2 cl">
			<!--{loop $loglist $value}-->
			<!--{eval $value = makecreditlog($value, $otherinfo);}-->
				<div class="jfjl_xm cl"><div class="jfjl_hb z">$value['credit']</div><div class="jfjl_sj"><!--{if $value['operation']}-->$value['opinfo']<!--{else}-->$value['text']<!--{/if}--></div></div>
			<!--{/loop}-->
		</div>
	<!--{else}-->
	<div class="white plr16" style="padding:15px 16px; font-size:15px;">
	<p  class="jfsm">暂无积分记录</p>
				</div>
	<!--{/if}-->

		<!--{elseif $_GET['op'] == 'buy'}-->
<script src="template/xlmmapp/m-img/mb.js?{VERHASH}"></script>

			<!--{if ($_G[setting][ec_ratio] && ($_G[setting][ec_account] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_tenpay_bargainor])) || $_G[setting][card][open]}-->
			<form id="addfundsform" name="addfundsform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=buy" onsubmit="ajaxpost(this.id, 'return_addfundsform');">
					<div class="white" style="padding:15px; padding-top:9px;">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="addfundssubmit" value="true" />
				<input type="hidden" name="handlekey" value="buycredit" />
				<table cellspacing="0" cellpadding="0" class="tfm mtn">
					<tr>
						<th>{lang mode_of_payment}</th>
						<td colspan="2">

							<div class="long-logo mbw">
								<ul>
								<!--{if $_G[setting][ec_ratio] && $_G[setting][ec_account]}-->
			<li class="z">
						<input name="bank_type" type="radio" value="alipay" class="vm" id="apitype_alipay" $ecchecked checked="checked"/><label class="vm" style="margin-right:18px;width:105px;height:32px; margin-top:6px; margin-left:5px;background:#FFF url({STATICURL}image/common/alipay_logo.gif) no-repeat;border:1px solid #DDD;display:inline-block;" onclick="{if $_G[setting][card][open]}document.getElementById('cardbox').style.display='none';if(document.getElementById('card_box_sec')){document.getElementById('card_box_sec').style.display='none';}document.getElementById('paybox').style.display='';{/if}" for="apitype_alipay"></label>
									</li>
								<!--{/if}-->
								<!--{if $_G[setting][ec_ratio] && ($_G[setting][ec_tenpay_bargainor] || $_G[setting][ec_tenpay_opentrans_chnid])}-->
															<li class="z">
						<input name="bank_type" type="radio" value="0" class="vm" id="apitype_tenpay" $ecchecked onclick="checkValue(this)" /><label class="vm" style="margin-right:18px;width:105px;height:32px; margin-top:6px; margin-left:5px;background:#FFF url({STATICURL}image/common/tenpay_logo.gif) no-repeat;border:1px solid #DDD;display:inline-block;" onclick="{if $_G[setting][card][open]}document.getElementById('cardbox').style.display='none';if(document.getElementById('card_box_sec')){document.getElementById('card_box_sec').style.display='none';}document.getElementById('paybox').style.display='';{/if}" for="apitype_tenpay"></label>
												</li>
								<!--{/if}-->
			<!--{if $_G[setting][card][open]}-->
									<li class="z">
										<input name="bank_type" type="radio" value="card" id="apitype_card" class="vm" $ecchecked  onclick="activatecardbox();" /><label class="vm" style="padding-left:10px;width:85px; margin-top:6px; margin-left:5px;height:32px;line-height:32px;background:#FFF;border:1px solid #DDD;display:inline-block;" onclick="activatecardbox();"><span class="xs2">{lang card_credit}</span></label>
									</li>
								<!--{/if}-->
								</ul>
							</div>
						</td>
					</tr>
					<tr id="paybox" style="{if ($_G[setting][ec_tenpay_bargainor] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_account]) && empty($ecchecked) }display:;{else}display:none;{/if}">
						<th>{lang memcp_credits_addfunds}</th>
						<td class="pns">
							<input type="text" size="5" class="px" style="width: auto;" id="addfundamount" name="addfundamount" value="0" onkeyup="addcalcredit()" />
							&nbsp;{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}&nbsp;
							{lang credits_need}&nbsp;{lang memcp_credits_addfunds_caculate_radio}
						</td>
					</tr>
					<!--{if $_G[setting][card][open]}-->
						<tr id="cardbox" style="{if $_G[setting][card][open] && $ecchecked}display:;{else}display:none;{/if}">
							<th valign="top">{lang card}</th>
							<td colspan="2" class="xlmmyzmx">
								<input type="text" class="px" id="cardid" name="cardid" />
											<!--{if $seccodecheck}-->
					<!--{subtemplate common/seccheck}-->
								<!--{/if}-->
					</td>
		</tr>
						<!--{if $seccodecheck}-->
							</table>
							<!--{block sectpl}--><table id="card_box_sec" style="{if $_G[setting][card][open] && $ecchecked}display:;{else}display:none;{/if}" cellspacing="0" cellpadding="0" class="tfm mtn"><tr><th><sec></th><td colspan="2"><span id="sec<hash>" onclick="showMenu({'ctrlid':this.id,'win':'{$_GET[handlekey]}'})"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div></td></tr></table><!--{/block}-->
							<table cellspacing="0" cellpadding="0" class="tfm mtn">
						<!--{/if}-->
					<!--{/if}-->

				</table>
								<div class="xlmmzzxz" style="margin-top:0;">
							{lang memcp_credits_addfunds_rules_ratio} =  <strong>$_G[setting][ec_ratio]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}
							<!--{if $_G[setting][ec_mincredits]}--><br />{lang memcp_credits_addfunds_rules_min}  <strong>$_G[setting][ec_mincredits]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{/if}-->
							<!--{if $_G[setting][ec_maxcredits]}--><br />{lang memcp_credits_addfunds_rules_max}  <strong>$_G[setting][ec_maxcredits]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{/if}-->
							<!--{if $_G[setting][ec_maxcreditspermonth]}--><br />{lang memcp_credits_addfunds_rules_month}  <strong>$_G[setting][ec_maxcreditspermonth]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{/if}-->
						</div>
	</div>
							<button type="submit" name="addfundssubmit_btn" class="xlmmbtss pn formdialog" style=" margin:15px 0" id="addfundssubmit_btn" value="true" xlmm="xlmmpay"><em>{lang memcp_credits_addfunds}</em></button>
	</form>
			<span style="display: none" id="return_addfundsform"></span>
			<script type="text/javascript">
function addcalcredit() {
var addfundamount = document.getElementById('addfundamount').value.replace(/^0/, '');
var addfundamount = parseInt(addfundamount);
document.getElementById('desamount').innerHTML = !isNaN(addfundamount) ? Math.ceil(((addfundamount / 10) * 100)) / 100 : 0;
}		
				<!--{if $_G[setting][card][open]}-->
				function activatecardbox() {
					document.getElementById('apitype_card').checked=true;
				document.getElementById('cardbox').style.display='';
					if(document.getElementById('card_box_sec')){
						document.getElementById('card_box_sec').style.display='';
					}
					document.getElementById('paybox').style.display='none';
				}
				<!--{/if}-->
			</script>
                    	<!--{/if}-->

	<!--{elseif $_GET['op'] == 'transfer'}-->
		<!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
			<form id="transferform" name="transferform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=transfer" onsubmit="ajaxpost(this.id, 'return_transfercredit');">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="transfersubmit" value="true" />
			<input type="hidden" name="handlekey" value="transfercredit" />
				<div class="xlmmjfxxx">
							<div class=" cl">
		<div class="zzxm_xmbt z ">转账数量</div>
					<div class="zzxm_xmnr z">
						<input type="text" name="transferamount" id="transferamount" class="px" size="5" placeholder="{$_G[setting][extcredits][$_G[setting][creditstransextra][9]][title]}" />
					</div>
						</div>
										<p class="xlmmzzxz ">{lang memcp_credits_transfer_min_balance} $_G[setting][transfermincredits] {$_G[setting][extcredits][$_G[setting][creditstransextra][9]][unit]}<!--{if intval($taxpercent) > 0}-->, {lang credits_tax} $taxpercent<!--{/if}--></p>
</div>
			<div class="xlmmjfxxx cl">
					<div class="zzxm_xmbt z">转账给</div>
					<div class="zzxm_xmnr z"><input type="text" name="to" id="to" class="px" size="15" placeholder="用户名" /></div>
				</div>
				<div class="xlmmjfxxx cl">
					<div class="zzxm_xmbt z">{lang transfer_login_password}</div>
					<div class="zzxm_xmnr z"><input type="password" name="password" class="px" value="" placeholder="密码"/></div>
				</div>
				<div class="xlmmjfxxx cl">
					<div class="zzxm_xmbt z">{lang credits_transfer_message}</div>
					<div class="zzxm_xmnr z"><input type="text" name="transfermessage" class="px" size="40" placeholder="留言"/></div>
				</div>
				<div class="jfzz_zzan cl">
					<button type="submit" name="transfersubmit_btn" id="transfersubmit_btn" class="pn" value="true">{lang memcp_credits_transfer}</button>
				</div>
				<span style="display: none" id="return_transfercredit"></span>
			</form>
		<!--{/if}-->
	<!--{elseif $_GET['op'] == 'exchange'}-->
<script type="text/javascript" src="{$_G[setting][jspath]}common.js?{VERHASH}"></script>
		<!--{if $_G[setting][exchangestatus] && ($_G[setting][extcredits] || $_CACHE['creditsettings'])}-->
			<form id="exchangeform" name="exchangeform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=exchange&handlekey=credit" onsubmit="showWindow('credit', 'exchangeform', 'post');">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="operation" value="exchange" />
			<input type="hidden" name="exchangesubmit" value="true" />
			<input type="hidden" name="outi" value="" />
				<div class="xlmmjfxxx cl">
				 	<div class="zzxm_xmbt z">兑换数</div>
					<div class="zzxm_xmnr z">
					    <input type="text" id="exchangeamount" name="exchangeamount" class="px" size="5" style="width: 55%;border-right: 1px solid #e6e6e6;" value="0" onkeyup="exchangecalcredit()" />
						<select name="tocredits" id="tocredits" class="ps" onChange="exchangecalcredit()">
						<!--{loop $_G[setting][extcredits] $id $ecredits}-->
							<!--{if $ecredits[allowexchangein] && $ecredits[ratio]}-->
								<option value="$id" unit="$ecredits[unit]" title="$ecredits[title]" ratio="$ecredits[ratio]">$ecredits[title]</option>
							<!--{/if}-->
						<!--{/loop}-->
						<!--{eval $i=0;}-->
						<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
							<!--{if $data[title]}-->
							<option value="$id" outi="$i">$data[title]</option>
							<!--{/if}-->
						<!--{/loop}-->
						</select>
					</div>
				</div>
				<div class="xlmmjfxxx">	
					<div class=" cl">	
				<div class="zzxm_xmbt z">所需数</div>
					<div class="zzxm_xmnr z">
						<input type="text" id="exchangedesamount" class="px" size="5" style="width: 55%;border-right: 1px solid #e6e6e6;" value="0" disabled="disabled" />
						<select name="fromcredits" id="fromcredits_0" class="ps" style="display: none" onChange="exchangecalcredit();">
						<!--{loop $_G[setting][extcredits] $id $credit}-->
							<!--{if $credit[allowexchangeout] && $credit[ratio]}-->
								<option value="$id" unit="$credit[unit]" title="$credit[title]" ratio="$credit[ratio]">$credit[title]</option>
							<!--{/if}-->
						<!--{/loop}-->
						</select>
						<!--{eval $i=0;}-->
						<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
							<select name="fromcredits_$i" id="fromcredits_$i" class="ps" style="display: none" onChange="exchangecalcredit()">
							<!--{loop $data[creditsrc] $id $ratio}-->
								<option value="$id" unit="$_G['setting']['extcredits'][$id][unit]" title="$_G['setting']['extcredits'][$id][title]" ratiosrc="$data[ratiosrc][$id]" ratiodesc="$data[ratiodesc][$id]">$_G['setting']['extcredits'][$id][title]</option>
							<!--{/loop}-->
						    </select>
						<!--{/loop}-->
						<script type="text/javascript">
							var tocredits = $('tocredits');
							var fromcredits = $('fromcredits_0');
							if(fromcredits.length > 1 && tocredits.value == fromcredits.value) {
								fromcredits.selectedIndex = tocredits.selectedIndex + 1;
							}
						</script>
							</div>
			</div>
							<p class="xlmmzzxz"><!--{if $_G[setting][exchangemincredits]}-->{lang memcp_credits_exchange_min_balance} $_G[setting][exchangemincredits]<!--{/if}--><span id="taxpercent"><!--{if intval($taxpercent) > 0}-->, {lang credits_tax} $taxpercent<!--{/if}--></span></p>
			</div>
				<div class="xlmmjfxxx cl">
				    <div class="zzxm_xmbt z">{lang transfer_login_password}</div>
					<div class="zzxm_xmnr z"><input type="password" name="password" class="px" value="" size="20" placeholder="必填" /></div>
				</div>
				<div class="jfzz_zzan cl">
					<button type="submit" name="exchangesubmit_btn" id="exchangesubmit_btn" class="pn" value="true" tabindex="2">{lang memcp_credits_exchange}</button>
				</div>
			</form>
			<script type="text/javascript">
				function exchangecalcredit() {
					with($('exchangeform')) {
						tocredit = tocredits[tocredits.selectedIndex];
						if(!tocredit) {
							return;
						}
						<!--{eval $i=0;}-->
						<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
							$('fromcredits_$i').style.display = 'none';
						<!--{/loop}-->
						if(tocredit.getAttribute('outi')) {
							outi.value = tocredit.getAttribute('outi');
							fromcredit = $('fromcredits_' + tocredit.getAttribute('outi'));
							$('taxpercent').style.display = $('fromcredits_0').style.display = 'none';
							fromcredit.style.display = '';
							fromcredit = fromcredit[fromcredit.selectedIndex];
							$('exchangeamount').value = $('exchangeamount').value.toInt();
							if($('exchangeamount').value != 0) {
								$('exchangedesamount').value = Math.floor( fromcredit.getAttribute('ratiosrc') / fromcredit.getAttribute('ratiodesc') * $('exchangeamount').value);
							} else {
								$('exchangedesamount').value = '';
							}
						} else {
							outi.value = 0;
							$('taxpercent').style.display = $('fromcredits_0').style.display = '';
							fromcredit = fromcredits[fromcredits.selectedIndex];
							$('exchangeamount').value = $('exchangeamount').value.toInt();
							if(fromcredit.getAttribute('title') != tocredit.getAttribute('title') && $('exchangeamount').value != 0) {
								if(tocredit.getAttribute('ratio') < fromcredit.getAttribute('ratio')) {
									$('exchangedesamount').value = Math.ceil( tocredit.getAttribute('ratio') / fromcredit.getAttribute('ratio') * $('exchangeamount').value * (1 + $_G[setting][creditstax]));
								} else {
									$('exchangedesamount').value = Math.floor( tocredit.getAttribute('ratio') / fromcredit.getAttribute('ratio') * $('exchangeamount').value * (1 + $_G[setting][creditstax]));
								}
							} else {
								$('exchangedesamount').value = '';
							}
						}
					}
				}
				String.prototype.toInt = function() {
					var s = parseInt(this);
					return isNaN(s) ? 0 : s;
				}
				exchangecalcredit();
			</script>
			<!--{/if}-->
		<!--{else}-->
	<div class="jump_c">
	<div class="xlmmtsxx cl iconfont"></div>
	<p>详细积分规则请切换电脑版查看</p>
				</div>
		<!--{/if}-->
</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->











