<?PHP exit('Access 个人中心，xlmm2020');?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
       				{eval         $getgid=getuserbyuid($space[uid]);
        $xlmmhdj = DB::result_first("SELECT stars FROM %t WHERE groupid=%d", array("common_usergroup", $getgid['groupid']));
}
<!--{if !$_GET['mycenter']}-->
<!--{template home/sheader}-->

<style>
.nav_bar .inside li.cur{border-bottom: 1px solid #0285f7;}
.nav_bar .inside li.cur a{color: #0285f7;}

.news_list{padding-top: 0.34rem;}
.news_list li{margin: 0 15px 0 25px;}
.news_list li .news_con{border-left: 1px solid #cccccc;/*padding-top: 0.25rem;*/
    padding-bottom: 0.4rem;padding-left: 0.5rem;position: relative;}
.news_list li .news_con .inside{padding: 0.3rem 0.32rem;background: #ffffff;border-radius: 5px;}
.news_list li .news_con .detail_con{margin-left: 0;width: 100%;}
.news_list li .news_con .img_con{/*position: absolute;*/
    /*top:0;*/
    /*left: 0.74rem;*/
    width: 1.38rem;height: 1.38rem;position: relative;}
.news_list li .news_con .img_con img{display: block;width: 100%;height: 100%;}
.news_list li .news_con .img_con span.num{width: 0.64rem;height: 0.36rem;line-height: 0.36rem;text-align: center;color: #ffffff;font-size: 0.3rem;background: #000;position: absolute;bottom: 0;right: 0;opacity: 0.5;}
.news_list li .news_con .img_con video{display: block;width: 100%;height: 100%;}
.news_list li .news_con .content{font-size: 0.28rem;color: #222;line-height: 0.46rem;height: 0.92rem;overflow: hidden;}
.news_list li .news_con .detail_con.wid .content_02{margin-top: -1.38rem;}
.news_list li .news_con .detail_con.wid .content_02, .news_list li .news_con  .detail_con.wid .content_info{margin-left: 1.6rem;}
.news_list li .news_con .content .topic{color: #507daf;}
.news_list li .news_con .content_info{margin-top: 0.15rem;text-align: right;font-size: 0.24rem;color: #bbb;height: 0.3rem;line-height: 0.3rem;}
.news_list li .news_con .content_info span.split{padding: 0 0.25rem;}
.news_list li .first_con .left_line{position: absolute;width: 0.6rem;left: -0.31rem;top:0;background: #F2F2F2;text-align: center;}
.news_list li .first_con .left_line span{display: block;font-family: 'Arial';}
.news_list li .first_con .left_line .date{font-size: 0.3rem;color: #666;font-weight: bold;}
.news_list li .first_con .left_line .month{color: #999;margin-top: 0.16rem;font-size: 0.26rem;}
.news_list li .first_con .left_line i{display: block;width: 0.12rem;height: 0.12rem;background: #bbbbbb;border-radius: 0.12rem;margin: 0 auto;margin-top: 0.1rem;}
.news_list li .bg_con .left_line{position: absolute;width: 0.08rem;height: 0.08rem;border: 1px solid #bbbbbb;border-radius: 0.08rem;left: -0.04rem;top:0;margin-left: -2px;}

</style>
<!--{if $_GET['grzl'] || $_GET['wz']}--><!--{else}--> 
{eval include TPLDIR.'/php/uthread.php';}
<ul class="news_list">
	<!--{if $xlmmuthread}-->
		<!--{loop $xlmmuthread $thread}-->
<!--{eval include TPLDIR.'/php/img.php';$xlmmdata=$thread['dateline'];$xlmmmt['dateline'] = date("m",$xlmmdata);$xlmmdt['dateline'] = date("d",$xlmmdata);}-->
<li>
<a <!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]<!--{else}-->href="forum.php?mod=viewthread&tid=$thread[tid]" {if $thread['displayorder'] == -1}class="grey"{/if}<!--{/if}-->">
                                        <div class="first_con news_con">
                        <div class="inside cl">
                                                <!--{if $xlmmal >0}-->                
                                             <div class="img_con z">
                                <!--{eval $xlmm=0;}-->
                 <!--{loop $xlmmattach $attach}-->
					<!--{if $attach['aid']}-->			
					{eval $forumimg = (getforumimg($attach['aid'],0,230,230));}
										<!--{/if}-->
<img src="<!--{if $attach['aid']}-->$forumimg<!--{else}-->$attach['attachment']<!--{/if}-->">
        <!--{eval $xlmm++}-->
<!--{eval if($xlmm==1) break;}-->
    <!--{/loop}--> 
                                                                            <span class="num">{$xlmmal}张</span>
                                                                    </div>
                                 <!--{/if}-->                
                                                        <div class="z detail_con <!--{if $xlmmal >0}-->wid <!--{/if}-->">
                                                                    <p class="content content_02">$thread[subject]</p>

                                    <div class="content_info">
                               			<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				<span class="icon_top z" style="color:red;">置顶</span>
			<!--{/if}-->
       <span class="read">$thread['views']阅读</span>
                                        <span class="split">|</span>

                                        <span class="pinlun">$thread[replies]评论</span>
                                    </div>
                                </div>
                            </div>
                            <div class="left_line">
                                                                    <span class="date">$xlmmdt['dateline']</span>
                                    <span class="month">$xlmmmt['dateline']月</span>
                                    <i></i>
                                
                            </div>
                        </div>
                  </a>  </li>
		<!--{/loop}-->
	<!--{else}-->
		<li style="height: 1.25rem;line-height: 1.25rem;text-align: center;font-size: 0.3rem;color: #BBB;">{lang no_related_posts}</li>
	<!--{/if}-->
	</ul>

	$multipage
<!--{/if}-->
<!--{if $_GET['wz']}-->
{eval include TPLDIR.'/php/uview.php';}
<ul class="news_list">
	<!--{if $list}-->
	<!--{loop $list $value}-->
			{eval include TPLDIR.'/php/portal_list.php';}
<!--{eval $xlmmdata=$value['dateline'];$xlmmmt['dateline'] = date("m",$xlmmdata);$xlmmdt['dateline'] = date("d",$xlmmdata);}-->
<li>
<a href="portal.php?mod=view&aid=$value[aid]">
                                        <div class="first_con news_con">
                        <div class="inside cl">
                                                <!--{if $xlmmal >0}-->                
                                             <div class="img_con z">
                                <!--{eval $xlmm=0;}-->
  <!--{loop $xlmmoutimg $key $xlmmimg}-->
                <img src="<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->">
        <!--{eval $xlmm++}-->
<!--{eval if($xlmm==1) break;}-->
    <!--{/loop}--> 
                                                                            <span class="num">{$xlmmal}张</span>
                                                                    </div>
                                 <!--{/if}-->                
                                                        <div class="z detail_con <!--{if $xlmmal >0}-->wid <!--{/if}-->">
                                                                    <p class="content content_02">$value[title]</p>

                                    <div class="content_info">
       <span class="read">$value[viewnum]阅读</span>
                                        <span class="split">|</span>

                                        <span class="pinlun">$value[commentnum]评论</span>
                                    </div>
                                </div>
                            </div>
                            <div class="left_line">
                                                                    <span class="date">$xlmmdt['dateline']</span>
                                    <span class="month">$xlmmmt['dateline']月</span>
                                    <i></i>
                                
                            </div>
                        </div>
                  </a>  </li>
		<!--{/loop}-->
	<!--{else}-->
		<li style="height: 1.25rem;line-height: 1.25rem;text-align: center;font-size: 0.3rem;color: #BBB;">没有文章或无发文权限</li>
	<!--{/if}-->
	</ul>
{$multipage}

<!--{/if}-->

<!--{if $_GET['grzl']}-->

<style>
body, #mcontent { background:#fff;}
.xlmm-bj .mv_post_nav { background:none;margin:10px 0 0 0;} 
.xlmm-bj .mv_post_nav a { padding:0 5px;}
.xlmm-bj_h { position: relative;}
.xlmm-bj_h .s1 { display:block;padding:0px;margin:0px;overflow:hidden;background:#FFF;height:130px;overflow:hidden;}
.xlmm-bj_h .s1 img { display:block;background:#000;filter: url(blur.svg#blur);/* FireFox, Chrome, Opera */ -webkit-filter: blur(15px);/* Chrome, Opera */ -moz-filter: blur(15px);-ms-filter: blur(15px);filter: blur(15px);filter: progid:DXImageTransform.Microsoft.Blur(PixelRadius=15, MakeShadow=false);/* IE6~IE9 */ width:100%}
.xlmm-bj_h .s2 { display:block;height:40px;background:#FFF;border-bottom:1px solid #F8F8F8;box-shadow: 0 3px 5px rgba(0, 0, 0, 0.2)}
.xlmm-bj_h .s3 { position:absolute;left:10px;bottom:10px;}
.xlmm-bj_h .s3  img { width:80px;height:80px;border-radius:40px;padding:2px;background:#FFF;box-shadow: 0 2px 2px rgba(0, 0, 0, 0)}
.xlmm-bj_h .s4 { position:absolute;left:110px;bottom:60px;color:#FFF;font-size:16px;text-shadow:0 3px 3px #000;}
.xlmm-bj_h .s5 { position: absolute;left:110px;bottom:9px;width:72px;height:30px;line-height:30px;font-size:14px;}
    .xlmm-bj_h .s5 a { color:#4E627C;}
.xlmm-zl { margin:10px 0 0 0; padding-top:15px;}
.xlmm-zl li { padding: 3px 30px 3px 90px;}
	.xlmm-zl li em { position: absolute;margin-left: -90px;width: 80px;color: #999;}
.mbutton {width: 50px;height: 32px;line-height: 32px;border: 0;text-align: center;color: #FFF;background: #2AA2E2}
</style>
<div class="xlmm-bj white">

<div class="plr15 xlmm-zl">
	<div class="pbm mbm bbda cl">
		<h2 class="mbn">
			{$space[username]}
			<!--{if $_G['ols'][$space[uid]]}-->
				<img src="{IMGDIR}/ol.gif" alt="online" title="{lang online}" class="vm" />&nbsp;
			<!--{/if}-->
			<span class="xw0">(UID: {$space[uid]}
			<!--{eval $isfriendinfo = 'home_friend_info_'.$space['uid'].'_'.$_G[uid];}-->
			<!--{if $_G[$isfriendinfo][note]}-->
				, <span class="xg1">$_G[$isfriendinfo][note]</span>
			<!--{/if}-->
			)</span>
		</h2>
		<!--{if CURMODULE == 'space'}-->
			<!--{hook/space_profile_baseinfo_top}-->
		<!--{elseif CURMODULE == 'follow'}-->
			<!--{hook/follow_profile_baseinfo_top}-->
		<!--{/if}-->
		<ul class="pf_l cl pbm mbm">
			<!--{if $_G['setting']['allowspacedomain'] && $_G['setting']['domain']['root']['home'] && checkperm('domainlength') && !empty($space['domain'])}-->
			<!--{eval $spaceurl = 'http://'.$space['domain'].'.'.$_G['setting']['domain']['root']['home'];}-->
			<li><em>{lang second_domain}</em><a href="$spaceurl" onclick="setCopy('$spaceurl', '{lang copy_space_address}');return false;">$spaceurl</a></li>
			<!--{/if}-->
			<!--{if $_G[setting][homepagestyle]}-->
			<li><em>{lang space_visits}</em><strong class="xi1">$space[views]</strong></li>
			<!--{/if}-->
			<!--{if in_array($_G[adminid], array(1, 2))}-->
			<li><em>Email</em>$space[email]</li>
			<!--{/if}-->
			<li><em>{lang email_status}</em><!--{if $space[emailstatus] > 0}-->{lang profile_verified}<!--{else}-->{lang profile_no_verified}<!--{/if}--></li>
			<li><em>{lang video_certification}</em><!--{if $space[videophotostatus] > 0}-->{lang profile_certified} <!--{if $showvideophoto}-->&nbsp;&nbsp;(<a href="home.php?mod=space&uid=$space[uid]&do=videophoto" id="viewphoto" onclick="showWindow(this.id, this.href, 'get', 0)">{lang view_certification_photos}</a>)<!--{/if}--><!--{else}-->{lang profile_no_certified}<!--{/if}--></li>
		</ul>
		<ul>
			<!--{if $space[spacenote]}--><li><em class="xg1">{lang spacenote}&nbsp;&nbsp;</em>$space[spacenote]</li><!--{/if}-->
			<!--{if $space[customstatus]}--><li class="xg1"><em>{lang permission_basic_status}&nbsp;&nbsp;</em>$space[customstatus]</li><!--{/if}-->
			<!--{if $space[group][maxsigsize] && $space[sightml]}--><li><em class="xg1">{lang personal_signature}&nbsp;&nbsp;</em><table><tr><td>$space[sightml]</td></tr></table></li><!--{/if}-->
		</ul>
		<ul class="cl bbda pbm mbm">
			<li>
				<em class="xg2">{lang stat_info}</em>
				<a href="home.php?mod=space&uid=$space[uid]&do=friend&view=me&from=space" target="_blank">{lang friends_num} $space[friends]</a>
				<!--{if helper_access::check_module('doing')}-->
					<span class="pipe">|</span>
					<a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space" target="_blank">{lang doings_num} $space[doings]</a>
				<!--{/if}-->
				<!--{if helper_access::check_module('blog')}-->
					<span class="pipe">|</span>
					<a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space" target="_blank">{lang blogs_num} $space[blogs]</a>
				<!--{/if}-->
				<!--{if helper_access::check_module('album')}-->
					<span class="pipe">|</span>
					<a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space" target="_blank">{lang albums_num} $space[albums]</a>
				<!--{/if}-->
				<!--{if $_G['setting']['allowviewuserthread'] !== false}-->
					<span class="pipe">|</span>
					<!--{eval $space['posts'] = $space['posts'] - $space['threads'];}-->
					<a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=reply&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread&type=reply{/if}" target="_blank">{lang replay_num} $space[posts]</a>
					<span class="pipe">|</span>
					<a href="{if CURMODULE != 'follow'}home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=thread&from=space{else}home.php?mod=space&uid=$space[uid]&view=thread{/if}" target="_blank">{lang threads_num} $space[threads]</a>
				<!--{/if}-->
				<!--{if helper_access::check_module('share')}-->
					<span class="pipe">|</span>
					<a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space" target="_blank">{lang shares_num} $space[sharings]</a>
				<!--{/if}-->
			</li>
		</ul>
		<!--{if CURMODULE == 'space'}-->
			<!--{hook/space_profile_baseinfo_middle}-->
		<!--{elseif CURMODULE == 'follow'}-->
			<!--{hook/follow_profile_baseinfo_middle}-->
		<!--{/if}-->
		<ul class="pf_l cl">
			<!--{loop $profiles $value}-->
			<li><em>$value[title]</em>$value[value]</li>
			<!--{/loop}-->
		</ul>
	</div>
<!--{if CURMODULE == 'space'}-->
	<!--{hook/space_profile_baseinfo_bottom}-->
<!--{elseif CURMODULE == 'follow'}-->
	<!--{hook/follow_profile_baseinfo_bottom}-->
<!--{/if}-->
<!--{if $space['medals']}-->
	<div class="pbm mbm bbda cl">
		<h2 class="mbn">{lang medals}</h2>
		<p class="md_ctrl">
			<a href="home.php?mod=medal">
			<!--{loop $space['medals'] $medal}-->
				<img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" id="md_{$medal[medalid]}" onmouseover="showMenu({'ctrlid':this.id, 'menuid':'md_{$medal[medalid]}_menu', 'pos':'12!'});" />
			<!--{/loop}-->
			</a>
		</p>
	</div>
	<!--{loop $space['medals'] $medal}-->
		<div id="md_{$medal[medalid]}_menu" class="tip tip_4" style="display: none;">
			<div class="tip_horn"></div>
			<div class="tip_c">
				<h4>$medal[name]</h4>
				<p>$medal[description]</p>
			</div>
		</div>
	<!--{/loop}-->
<!--{/if}-->
<!--{if $_G['setting']['verify']['enabled']}-->
	<!--{eval $showverify = true;}-->
	<!--{loop $_G['setting']['verify'] $vid $verify}-->
		<!--{if $verify['available']}-->
			<!--{if $showverify}-->
			<div class="pbm mbm bbda cl">
			<h2 class="mbn">{lang profile_verify}</h2>
			<!--{eval $showverify = false;}-->
			<!--{/if}-->

			<!--{if $space['verify'.$vid] == 1}-->
				<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $verify['icon']}--><img src="$verify['icon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{else}-->$verify[title]<!--{/if}--></a>&nbsp;
			<!--{elseif !empty($verify['unverifyicon'])}-->
				<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $verify['unverifyicon']}--><img src="$verify['unverifyicon']" class="vm" alt="$verify[title]" title="$verify[title]" /><!--{/if}--></a>&nbsp;
			<!--{/if}-->

		<!--{/if}-->
	<!--{/loop}-->
	<!--{if !$showverify}--></div><!--{/if}-->
<!--{/if}-->
<!--{if $count}-->
	<div class="pbm mbm bbda cl">
		<h2 class="mbn">{lang manage_forums}</h2>
		<!--{loop $manage_forum $key $value}-->
		<a href="forum.php?mod=forumdisplay&fid=$key" target="_blank">$value</a> &nbsp;
		<!--{/loop}-->
	</div>
<!--{/if}-->
<!--{if $groupcount}-->
	<div class="pbm mbm bbda cl">
		<h2 class="mbn">{lang joined_group}</h2>
		<!--{loop $usergrouplist $key $value}-->
		<a href="forum.php?mod=group&fid={$value['fid']}" target="_blank">$value['name']</a> &nbsp;
		<!--{/loop}-->
	</div>
<!--{/if}-->
<div class="pbm mbm bbda cl">
	<h2 class="mbn">{lang active_profile}</h2>
	<ul>
		<!--{if $space[adminid]}--><li><em class="xg1">{lang management_team}&nbsp;&nbsp;</em><span style="color:{$space[admingroup][color]}"><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[adminid]" target="_blank">{$space[admingroup][grouptitle]}</a></span> {$space[admingroup][icon]}</li><!--{/if}-->
		<li><em class="xg1">{lang usergroup}&nbsp;&nbsp;</em><span style="color:{$space[group][color]}"{if $upgradecredit !== false} class="xi2" onmouseover="showTip(this)" tip="{lang credits} $space[credits], {lang thread_groupupgrade} $upgradecredit {lang credits}"{/if}><a href="home.php?mod=spacecp&ac=usergroup&gid=$space[groupid]" target="_blank">{$space[group][grouptitle]}</a></span> {$space[group][icon]} <!--{if !empty($space['groupexpiry'])}-->&nbsp;{lang group_useful_life}&nbsp;<!--{date($space[groupexpiry], 'Y-m-d H:i')}--><!--{/if}--></li>
		<!--{if $space[extgroupids]}--><li><em class="xg1">{lang group_expiry_type_ext}&nbsp;&nbsp;</em>$space[extgroupids]</li><!--{/if}-->
	</ul>
	<ul id="pbbs" class="pf_l">
		<!--{if $space[oltime]}--><li><em>{lang online_time}</em>$space[oltime] {lang hours}</li><!--{/if}-->
		<li><em>{lang regdate}</em>$space[regdate]</li>
		<li><em>{lang last_visit}</em>$space[lastvisit]</li>
		<!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
		<li><em>{lang register_ip}</em>$space[regip] - $space[regip_loc]</li>
		<li><em>{lang last_visit_ip}</em>$space[lastip]:$space[port] - $space[lastip_loc]</li>
		<!--{/if}-->
		<!--{if $space[lastactivity]}--><li><em>{lang last_activity_time}</em>$space[lastactivity]</li><!--{/if}-->
		<!--{if $space[lastpost]}--><li><em>{lang last_post_time}</em>$space[lastpost]</li><!--{/if}-->
		<!--{if $space[lastsendmail]}--><li><em>{lang last_send_email}</em>$space[lastsendmail]</li><!--{/if}-->
		<li><em>{lang time_offset}</em>
			<!--{eval $timeoffset = array({lang timezone});}-->
			$timeoffset[$space[timeoffset]]
		</li>
	</ul>
</div>
<div id="psts" class="pbm mbm bbda cl">
	<h2 class="mbn">{lang stat_info}</h2>
	<ul class="pf_l">
		<li><em>{lang used_space}</em>$space[attachsize]</li>
		<!--{if $space[buyercredit]}-->
		<li><em>{lang eccredit_sellerinfo}</em><a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit#sellcredit" target="_blank">$space[buyercredit] <img src="{STATICURL}image/traderank/buyer/$space[buyerrank].gif" border="0" class="vm" /></a></li>
		<!--{/if}-->
		<!--{if $space[sellercredit]}-->
		<li><em>{lang eccredit_buyerinfo}</em><a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit#buyercredit" target="_blank">$space[sellercredit] <img src="{STATICURL}image/traderank/seller/$space[sellerrank].gif" border="0" class="vm" /></a></li>
		<!--{/if}-->
		<li><em>{lang credits}</em>$space[credits]</li>
		<!--{loop $_G[setting][extcredits] $key $value}-->
		<!--{if $value[title]}-->
		<li><em>$value[title]</em>{$space["extcredits$key"]} $value[unit]</li>
		<!--{/if}-->
		<!--{/loop}-->
	</ul>
</div>

</div>
		<!--{/if}-->

<!--{else}-->

<style>
.pa {position: absolute;}
 .pr {position: relative;}
 .bg { background:#fff !important;}
.my-info{/*padding:0.24rem 0.56rem 0.26rem 0.26rem;*/ padding:16px;display:block;}
.my-info .my-info-img{width:50px;height:50px;font-size:0px; }
.my-info .my-info-img img{display:inline-block;vertical-align:middle;width:100%;height:100%;border:1px solid #cccccc;border-radius:10px} 
.xuan1{background:#fff url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAYCAYAAADKx8xXAAAABGdBTUEAALGPC/xhBQAAACBjSFJNAAB6JgAAgIQAAPoAAACA6AAAdTAAAOpgAAA6mAAAF3CculE8AAAABmJLR0QAAAAAAAD5Q7t/AAAACXBIWXMAAAsSAAALEgHS3X78AAABXElEQVQ4y6XTO2tUYRDG8d/ZWGhlFbE21tHWQqwGAxIQCYiNYLz0YsCPIF4/wIKuVinSxKTSaUI0sdZa+whpkiKxCdhMLpDN2SNONw/zZ96ZeZ8mM8fxEf2IeK9j9LCMKxhk5pN/AR9ho/JXmfkiM5tRYAOZeQGfMVH6AA8jYq8VLPgcPuFySUu4ExE7rWDBZ2tR10r6gumI2Bo240FUwRQWS7qK1cw83woW/AczeFfSJL5m5sVWsOA9PMDzkiYKvjR0xmGRmY/xptLtmnl1JFjwXbzFKezidiew4BtYwBls9rqCI7fa8tTF6raL2ZFgLedDzbeNqYhYblqABs/wtKTfuB4R3znhHJk5hj5mS/pVnX7u1zRDoNOYx82SflSnjaN1///Jy1YrR6Clet4x6AAsI6879OIAt07yIvQycxJrDt3/Evfb3K9u08e+3+Yi4rUO0cM0vuFeVwj+Aja3fK+cyET3AAAAAElFTkSuQmCC) right 0.56rem center no-repeat;background-size:7px 12px;}
.my-info-name{padding-top:2px;/*padding-bottom:0.06rem;*/ margin-left:65px;padding-right:10px;}
.my-info-name b{color:#222222;font-size:0.3rem;line-height:0.5rem;display:inline-block;vertical-align:middle;}
.no-login-txt{line-height:0.5rem;color:#222222;font-size:0.3rem;font-weight:normal;}
.new_name.pink {background: #ffb2e5;}
.new_name {font-size: 10px;-webkit-text-size-adjust: none;color: #fff;border-radius: 2px;-webkit-border-radius: 2px;-o-border-radius: 2px;-moz-border-radius: 2px;-ms-border-radius: 2px;line-height: .25rem;display: inline-block;margin-left: 0.06rem;zoom: 1;vertical-align: middle;padding: 0 0.05rem;text-align: center;}

.my-info-name p{color:#666666;font-size:0.26rem;line-height:0.46rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:block;}
.my-items{padding-bottom:0.5rem;border-top:0.2rem solid #f5f5f5;}
.my-items ul{/*min-height:8.37rem;*/}
.my-items ul li{line-height:0.92rem;}
.my-items ul li a{color:#666666;font-size:0rem;display:block;vertical-align:middle;padding-left:16px;position:relative;}
.my-items ul li a:active{background:#dddddd;}
.my-items ul li i{width:22px;display:inline-block;vertical-align:middle;height:22px;position:absolute;left:14px;top:50%;margin-top:-12px;}
.my-items ul li span{position:relative;display:block;margin-left:35px;padding-left:8px;font-size:16px;}
.my-items ul li span:after{position: absolute;content:"";width: 100%;left: 0;bottom: 0;height: 1px;background-color: #d7d7d7;-webkit-transform: scale(1,.5);transform: scale(1,.5);-webkit-transform-origin: center bottom;transform-origin: center bottom}
.my-items ul li i.item-icon1 {margin-top:-0.4rem;left:0.16rem;}
.my-items ul li i.item-icon1:before {font-size:0.8rem;content:'\E631';color:#e9ad60;}
.my-items ul li i.item-icon2:before {font-size:0.5rem;content:'\E648';color:#ea6766;}
.my-items ul li i.item-icon3:before {font-size:0.5rem;content:'\E605';color:#e9ad60;}
.my-items ul li i.item-iconxc:before {font-size:0.5rem;content:'\E803';color:#ea6766;}
.my-items ul li i.item-icon4:before {font-size:0.5rem;content:'\E60F';color:#62bce6;}
.my-items ul li i.item-icon5:before {font-size:0.5rem;content:'\E653';color:#ea6766;}
.my-items ul li i.item-icon6:before {font-size:0.5rem;content:'\E914';color:#e9ad60;}
a.exit{background:#fd6363;color:#ffffff;font-size:0.34rem;line-height:0.9rem;width:5.2rem;margin-left:auto;margin-right:auto;display:block;border-radius:4px;-webkit-border-radius:4px;-o-border-radius:4px;-moz-border-radius:4px;-ms-border-radius:4px;position: relative; margin-top:30px;left:50%;margin-left:-2.6rem;text-align:center;}
</style>



<div class="white my-info xuan1 cl font0 pr" onclick="window.location='home.php?mod=space&uid=$_G[uid]&do=profile'">
    <div class="my-info-img pa"><img src="{avatar($_G[uid], big, true)}" class="circle"></div>
    <div class="my-info-name">
        <div>
            <b>$space[username]</b>
                                        <span class="new_level xlmmlvh$xlmmhdj ">LV$xlmmhdj</span>
                                        <span class="new_name pink"> $_G[group][grouptitle]</span>
                                </div>
        <p><!--{if $_G['uid']}--><!--{if $sightml = strip_tags($space['sightml'])}--><!--{echo cutstr({$sightml},26)}--><!--{else}-->暂无签名<!--{/if}--><!--{/if}--></p>
    </div>
</div>

<div class="my-items white">
    <ul>
        <li>
                        <a href="home.php?mod=space&uid=$_G[uid]&do=profile" class="xuan1">
                            <i class="iconfont item-icon1"></i>
                <span>个人主页</span>
            </a>
        </li>
        <li>
                        <a href="home.php?mod=spacecp&ac=credit" class="xuan1">
                                <i class="iconfont item-icon2" style="margin-top:-14px"></i><span>我的积分</span>
            </a>
        </li>
        <li>
                        <a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me" class="xuan1">
                            <i class="iconfont item-icon3"></i><span>帖子</span>
            </a>
        </li>
        <li>
                        <a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space" class="xuan1 none">
                            <i class="iconfont item-iconxc" style="margin-top:-13px"></i><span>相册</span>
            </a>
        </li>
        <li>
                        <a href="home.php?mod=space&do=pm" class="xuan1">
                                <i class="iconfont item-icon4"></i><span>消息</span>
            </a>
        </li>
        <li>
                        <a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread" class="xuan1">
                            <i class="iconfont item-icon5" style="margin-top:-13px"></i><span>收藏</span>
            </a>
        </li>
        <li>
                        <a href="home.php?mod=spacecp&ac=profile&op=password" class="xuan1">
                                    <i class="iconfont item-icon6" style="margin-top:-13px"></i><span>设置</span>
                </a>
        </li>


    </ul>
        <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="exit tc">退出登录</a>
    </div>




<!--{/if}-->
<div style="height:45px">
</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->














