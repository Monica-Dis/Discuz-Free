<?PHP exit('Access 个人中心，xlmm2020');?>
<!--{template common/header}-->
<style>
body, #mcontent { background:#FFF!important;}
.xlmm-bj .mv_post_nav { background:none; margin:10px 0 0 0;} 
.xlmm-bj .mv_post_nav a { padding:0 5px;}
.xlmm-bj_h { position: relative; }
.xlmm-bj_h .s1 { display:block; padding:0px; margin:0px; overflow:hidden; background:#FFF;height:130px; overflow:hidden;}
.xlmm-bj_h .s1 img { display:block; background:#000; filter: url(blur.svg#blur); /* FireFox, Chrome, Opera */ -webkit-filter: blur(15px); /* Chrome, Opera */ -moz-filter: blur(15px);-ms-filter: blur(15px);filter: blur(15px);filter: progid:DXImageTransform.Microsoft.Blur(PixelRadius=15, MakeShadow=false); /* IE6~IE9 */ width:100%}
.xlmm-bj_h .s2 { display:block; height:40px; background:#FFF; border-bottom:1px solid #F8F8F8; box-shadow: 0 3px 5px rgba(0, 0, 0, 0.2)}
.xlmm-bj_h .s3 { position:absolute; left:10px; bottom:10px;}
.xlmm-bj_h .s3  img { width:80px; height:80px; border-radius:40px; padding:2px; background:#FFF; box-shadow: 0 2px 2px rgba(0, 0, 0, 0)}
.xlmm-bj_h .s4 { position:absolute; left:110px; bottom:60px; color:#FFF; font-size:16px; text-shadow:0 3px 3px #000;}
.xlmm-bj_h .s5 { position: absolute; left:110px; bottom:9px; width:72px; height:30px; line-height:30px; font-size:14px;}
    .xlmm-bj_h .s5 a { color:#4E627C;}

.xlmm-bjzl { margin:10px; background:#FFF; border:1px solid #DDD;}
    .xlmm-bjzl textarea { border:1px solid #EEE; background:#F8F8F8; padding:5px; color:#999;}
	.xlmm-bjzl input { border:1px solid #EEE; background:#F8F8F8; padding:5px; color:#999;}
	.xlmm-bjzl select { border:1px solid #EEE; background:#F8F8F8; padding:5px; color:#999;}
	.xlmm-bjzl button { vertical-align:middle;}
	
	.xlmm-bjzl th { padding:0 5px; width:60px; text-align:right; border-bottom:1px solid #EEE; border-right:1px solid #EEE; background:#F8F8F8;}
	.xlmm-bjzl td { padding:5px; border-bottom:1px solid #EEE;}
	.xlmm-bjzl td p { color:#999;}
		.xlmmavpc img{ width:78px; height:78px;}

	.xlmm-bjzl .td_input_none input { padding:0px; margin:0px; border:none; background:none; width:150px;}
.mbutton {width: 50px; height: 32px;line-height: 32px; border: 0;text-align: center;color: #FFF; background: #2AA2E2}
</style>
		<!--{if $operation == 'password'}-->
<div class="xlmm-bj">
    <div class="xlmm-bj_h">
        <div class="s1"><img src="{avatar($space[uid], big, true)}"></div>
        <div class="s2"></div>
        <div class="s3"><img src="{avatar($space[uid], middle, true)}" /></div>
        <div class="s4">$space[username]</div>
        <div class="s5"><a href="home.php?mod=space&uid=$_G[uid]&do=profile">个人资料</a></div>
    </div>

    <div class="xlmm-bjzl">
    <form action="home.php?mod=spacecp&ac=profile" method="post" autocomplete="off">
				<input type="hidden" value="{FORMHASH}" name="formhash" />
				<table summary="{lang memcp_profile}" cellspacing="0" cellpadding="0" width="100%">
					<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->
						<tr>
							<th><span class="rq" title="{lang required}">*</span>{lang old_password}</th>
							<td><input type="password" name="oldpassword" id="oldpassword" class="px" /></td>
						</tr>
					<!--{/if}-->
					<tr>
						<th>{lang new_password}</th>
						<td>
							<input type="password" name="newpassword" id="newpassword" class="px" />
							<p class="d" id="chk_newpassword">{lang memcp_profile_passwd_comment}</p>
						</td>
					</tr>
					<tr>
						<th>{lang new_password_confirm}</th>
						<td>
							<input type="password" name="newpassword2" id="newpassword2"class="px" />
							<p class="d" id="chk_newpassword2">{lang memcp_profile_passwd_comment}</p>
						</td>
					</tr>
					<tr id="contact"{if $_GET[from] == 'contact'} style="background-color: {$_G['style']['specialbg']};"{/if}>
						<th>{lang email}</th>
						<td>
							<input type="text" name="emailnew" id="emailnew" value="$space[email]" class="px" />
							<p class="d">
								<!--{if empty($space['newemail'])}-->
									{lang email_been_active}
								<!--{else}-->
									$acitvemessage
								<!--{/if}-->
							</p>
							<!--{if $_G['setting']['regverify'] == 1 && (($_G['group']['grouptype'] == 'member' && $_G['adminid'] == 0) || $_G['groupid'] == 8) || $_G['member']['freeze']}--><p class="d">{lang memcp_profile_email_comment}</p><!--{/if}-->
						</td>
					</tr>
					
					<!--{if $_G['member']['freeze'] == 2}-->
					<tr>
						<th>{lang freeze_reason}</th>
						<td>
							<textarea rows="3" cols="80" name="freezereson" class="pt">$space[freezereson]</textarea>
							<p class="d" id="chk_newpassword2">{lang freeze_reason_comment}</p>
						</td>
					</tr>
					<!--{/if}-->

					<tr>
						<th>{lang security_question}</th>
						<td>
							<select name="questionidnew" id="questionidnew">
								<option value="" selected>{lang memcp_profile_security_keep}</option>
								<option value="0">{lang security_question_0}</option>
								<option value="1">{lang security_question_1}</option>
								<option value="2">{lang security_question_2}</option>
								<option value="3">{lang security_question_3}</option>
								<option value="4">{lang security_question_4}</option>
								<option value="5">{lang security_question_5}</option>
								<option value="6">{lang security_question_6}</option>
								<option value="7">{lang security_question_7}</option>
							</select>
							<p class="d">{lang memcp_profile_security_comment}</p>
						</td>
					</tr>

					<tr>
						<th>{lang security_answer}</th>
						<td>
							<input type="text" name="answernew" id="answernew" class="px" />
							<p class="d">{lang memcp_profile_security_answer_comment}</p>
						</td>
					</tr>					
					<!--{if $secqaacheck || $seccodecheck}-->
                    <tr>
                        <th>验证码</th>
						<td><!--{subtemplate common/seccheck}--></td>
                    </tr>
					<!--{/if}-->					
					<tr>
						<td colspan="2" align="center"><button type="submit" name="pwdsubmit" value="true" class="mbutton" /><strong>{lang save}</strong></button></td>
					</tr>
				</table>
				<input type="hidden" name="passwordsubmit" value="true" />
    </form>
    </div>
    
</div>
		<!--{else}-->
	<!--{/if}-->
</div>

<!--{template common/footer}-->












