<?PHP exit('Access 相册编辑，xlmm2020');?>
<!--{eval $_G[home_tpl_titles] = array($album[albumname], '{lang album}');}-->
<!--{template common/header}-->
	<style type="text/css">
.xlmmmets {background: #fffdef;border: 1px dashed #e7e1cd;font-size: 13px;color: #999; margin-bottom:10px;}
.emp, .mbw {height: 1.25rem;line-height: 1.25rem;text-align: center;font-size: 0.3rem;color: #BBB;}
.xlmmxced .xledx {padding: 10px 12px;border-bottom: 1px solid #efefef !important;font-size: 15px;background: #fff;}
.xlmmxced .xledx .xlexbt {width: 25%;color: #666;}
.xlmmxced .xledx .xlex1 {width: 75%;}
.xlmmxced .xledx .xlex1 .px {width: 100%;line-height: 20px;padding: 0;background: #fff;border: 0;font-size: 15px;border-radius: 0;color: #000;outline: none;-webkit-appearance: none;}
.xlmmxced .xledx .xlex1 .pt {width: 100%;min-height: 50px;border: 0;background: #fff;font-size: 15px;border-radius: 0;color: #000;outline: none;-webkit-appearance: none;}
.xlmmxced .xledx .xlex1 .ps, .xlmmxced .xledx .xlex1 #catid {width: 100%;background: #fff url(template/xlmmapp/touch/forum/post/ztfl_xxsx.png) no-repeat;background-position:right;background-size: 15px auto;border: 0;border-radius: 0;color: #000;font-size: 15px;outline: none;-webkit-appearance: none;}
.xlmmxced .xled2 {margin-top: 15px;}
.xlmmxced .xled2 .pn {float: left;color: #fff;-webkit-appearance: none;margin-left: 3%;width: 45%;height: 44px;line-height: 44px;font-size: 16px;border: none;outline: none;text-align: center;text-decoration: none;overflow: hidden;border-radius: 2px;}
.xlmmxced .xled2 a {float: left;color: #fff;background: #c7c7c7;margin-left: 3%;width: 45%;height: 44px;line-height: 44px;font-size: 16px;text-align: center;border-radius: 2px;}
.xlmmxced .xled3 {margin: 0 10px 15px 10px;padding: 10px;background: #fffdef;border: 1px dashed #e7e1cd;font-size: 13px;color: #999;}
.xlmmxced .xled4 {margin-bottom:10px;background:#fff;padding:15px;text-align: center;}
.xlmmxced .xled4 img {width: 100%;border-radius: 3px;vertical-align: top;}
.xlmmxced .xled4 p {margin-top:5px;font-size: 13px;}
.xlmmxced .xled4 .pt {width: 93%;padding:5px 3%;min-height: 50px;border: 1px solid #efefef;background: #fff;font-size: 14px;border-radius: 0;color: #666;outline: none;-webkit-appearance: none;}
.xlmmxced .xled6 {margin-bottom:15px;}
.xlmmxced .xled6 .xledc {width: 100%;margin-bottom:10px;}
.xlmmxced .xled6 .xledc .pn {color: #fff;-webkit-appearance: none;margin-left: 3%;width: 45%;height: 44px;line-height: 44px;font-size: 16px;border: none;outline: none;text-align: center;text-decoration: none;overflow: hidden;border-radius: 2px;}
.xlmmxced .xled6 .xlede {}
.xlmmxced .xled6 .xlede .pn {color: #fff;-webkit-appearance: none;margin-left: 3%;width: 45%;height: 44px;line-height: 44px;font-size: 16px;border: none;outline: none;text-align: center;text-decoration: none;overflow: hidden;border-radius: 2px;}
.xlmmxced .xled6 .xlede .ps {margin-left: 3%;margin-top: -5px;width: 45%;padding: 10px 1%;background: #fff url(template/xlmmapp/touch/forum/post/ztfl_xxsx.png) no-repeat;background-position: 95%;background-size: 15px auto;border: 0;border-radius: 2px;color: #000;font-size: 15px;outline: none;-webkit-appearance: none;}

.edittitle {width: 100%;margin: 0 auto;}
.edittitlex {background: #f8f8f8;padding: 10px;border-radius: 3px;}
.edittitlex .pt {width: 100%;height: 80px;background: #fff;border: 1px solid #f3f3f3;}
.edittitlex .pns {}
.edittitlex .pns .pn,.edittitlex .pns a  {display: block;width: 60px;height: 30px;line-height: 32px;margin-right: 10px;text-align: center;background: #99db5e;border: 0;color: #fff;font-size: 14px;border-radius: 3px;}
	</style>

<div class="xlmmxced cl">
<!--{if $_GET['op'] == 'edit'}-->
	<form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=edit&albumid=$albumid" class="mt20">
		<div class="xledx cl">
			<div class="xlexbt z"><label for="albumname">{lang album_name}</label></div>
			<div class="xlex1 z"><input type="text" id="albumname" name="albumname" value="$album[albumname]" size="20" class="px" /></div>
		</div>
		<div class="xledx cl">
			<div class="xlexbt z"><label for="depict">{lang album_depict}</label></div>
			<div class="xlex1 z"><textarea name="depict" id="depict" class="pt" cols="40" rows="3">$album[depict]</textarea></div>
		</div>
						<!--{if $categoryselect}-->
		<div class="xledx cl">
							<div class="xlexbt z">{lang site_categories}</div>
						<div class="xlex1 z">
							$categoryselect
							<p>({lang select_site_album_categories})</p>
						</div>
		</div>
					<!--{/if}-->
	<div class="xledx cl">
			<div class="xlexbt z">{lang privacy_settings}</div>
			<div class="xlex1 z">
				<select name="friend" onchange="passwordShow(this.value);" class="ps">
					<option value="0"$friendarr[0]>{lang friendname_0}</option>
					<option value="1"$friendarr[1]>{lang friendname_1}</option>
					<option value="2"$friendarr[2]>{lang friendname_2}</option>
					<option value="3"$friendarr[3]>{lang friendname_3}</option>
					<option value="4"$friendarr[4]>{lang friendname_4}</option>
				</select>
			</div>
		</div>

	<div class="xledx cl" id="span_password" style="display:none">
			<div class="xlexbt z">{lang password}</div>
			<div class="xlex1 z"><input type="text" name="password" value="$album[password]" size="10" class="px" placeholder="$album[password]"/></div>
		</div>
		<div class="xledx cl" id="tb_selectgroup" style="display:none">
			<div class="xlexbt z">{lang specified_friends}</div>
			<div class="xlex1 z">								<select name="selectgroup" class="ps">
									<option value="">{lang from_friends_group}</option>
									<!--{loop $groups $key $value}-->
									<option value="$key">$value</option>
									<!--{/loop}-->
								</select>
</div>

<div class="xlex1 z" style="width:100%; margin-top:6px;">
<textarea name="target_names" id="xlmmxcfrn" class="pt" style="border: 1px solid #efefef; padding:5px 1%; width:98%" placeholder="{lang choices_following_friends_list}"></textarea>
</div>
	</div>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editsubmit" value="true" />
		<div class="xled2 cl">
			<button name="submit" type="submit" class="pn bcolour formdialog" value="true">{lang determine}</button>
			<a href="home.php?mod=spacecp&ac=album&op=delete&albumid=$album[albumid]&handlekey=delalbumhk_{$album[albumid]}" class="dialog">{lang delete_album}</a>
		</div>
		<input type="hidden" name="formhash" value="{FORMHASH}" />
	</form>
<script>
function passwordShow(value) {
if(value==4) {
$('#span_password').css('display','');
$('#tb_selectgroup').css('display','none');
} else if(value==2) {
$('#span_password').css('display','none');
$('#tb_selectgroup').css('display','');
} else {
$('#span_password,#tb_selectgroup').css('display','none');
}
}
</script>
<!--{elseif $_GET['op'] == 'editpic'}-->
	<!--{if $list}-->
		<form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=editpic&albumid=$albumid">
		<div class="xlmmmets plr15 mt20" style="padding-top:10px; padding-bottom:10px;">{lang album_cover_notice}</div>
			<!--{eval $common = '';}-->
			<!--{loop $list $value}-->
				<div class="xled4 cl">
					<div class="z cl" style="width: 5%;"><input type="checkbox" name="ids[{$value[picid]}]" value="{$value[picid]}" {$value[checked]} class="pc"></div>
					<div class="z cl" style="width: 30%;">
						<img src="$value[pic]"/>
						<!--{eval $ids .= $common.$value['picid'].':'.$value['picid'];}-->
						<!--{eval $common = ',';}-->
						<!--{if $album[albumname]}-->
							<p><a href="home.php?mod=spacecp&ac=album&op=setpic&albumid=$value[albumid]&picid=$value[picid]&handlekey=setpichk" id="a_picid_$value[picid]" onclick="showWindow('setpichk', this.href, 'get', 0)">{lang set_to_conver}</a></p>
						<!--{/if}-->
					</div>
					<div class="y cl" style="width: 60%;"><textarea name="title[{$value[picid]}]" rows="4" cols="70" class="pt">$value[title]</textarea><input type="hidden" name="oldtitle[{$value[picid]}]" value="$value[title]"></div>
				</div>
			<!--{/loop}-->
			<div class="xled6 cl">
				<div class="plr15" style="padding-bottom:6px; padding-top:6px;">
		<input type="checkbox" name="chkall" id="chkall" class="pc" />
<label for="chkall" onclick="checkAll(this.form, 'ids')">全选</label>	
			</div>
	<div class="xledc cl">
					<button type="submit" name="editpicsubmit" value="true" class="pn bcolour " onclick="this.form.action+='&subop=update';">{lang update_explain}</button>
					<button type="submit" name="editpicsubmit" value="true" class="pn " onclick="this.form.action+='&subop=delete';return ischeck('theform', 'ids')">{lang delete}</button>
				</div>
				<!--{if $albumlist}-->
				<div class="xlede cl">
					<button type="submit" name="editpicsubmit" value="true" class="pn bcolour" onclick="this.form.action+='&subop=move';return ischeck('theform', 'ids')">{lang move_to}  →</button>
					<select name="newalbumid" class="ps vm">
						<!--{loop $albumlist $key $value}-->
							<!--{if $albumid != $value[albumid]}--><option value="$value[albumid]">$value[albumname]</option><!--{/if}-->
						<!--{/loop}-->
						<!--{if $albumid>0}--><option value="0">{lang default_album}</option><!--{/if}-->
					</select>
				</div>
				<!--{/if}-->
			</div>
						<div class="xlmmmets plr15 mt20" style="padding-top:10px; padding-bottom:10px;">{lang delete_pic_notice}</div>
		<input type="hidden" name="page" value="$page" />
		<input type="hidden" name="editpicsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		</form>
		<!--{if $multi}--><div class="pgs cl">$multi</div><!--{/if}-->
<script>
function ischeck(id, prefix) {
form = document.getElementById(id);
for(var i = 0; i < form.elements.length; i++) {
var e = form.elements[i];
if(e.name.match(prefix) && e.checked) {
if(confirm("您确定要执行本操作吗？")) {
return true;
} else {
return false;
}
}
}
alert('请选择要操作的对象');
return false;
}
function checkAll(form, name) {
setTimeout(function(){
for(var i = 0; i < form.elements.length; i++) {
var e = form.elements[i];
if(e.name.match(name)) {
e.checked = form.elements['chkall'].checked;
}
}
xl_input_style();
}, 50);
}
</script>

	<!--{else}-->
			<p class="emp">{lang no_pics}</p>
	<!--{/if}-->
<!--{elseif $_GET['op'] == 'delete'}-->
	<div class="tip">
	<form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=delete&albumid=$albumid&uid=$_GET[uid]">
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="deletesubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
		<dt>
			<p>{lang delete_album_message}</p>
			<p>
				{lang the_album_pic}:
				<select name="moveto" class="ps">
					<option value="-1">{lang completely_remove}</option>
					<option value="0">{lang move_to_default_album}</option>
					<!--{loop $albums $value}-->
					<option value="$value[albumid]">{lang move_to} $value[albumname]</option>
					<!--{/loop}-->
				</select>
			</p>
		</dt>
		<dd>
			<button type="submit" name="submit" class="formdialog button2" value="true">{lang determine}</button>
			<a href="javascript:;" onclick="popup.close();">取消</a>
		</dd>
	</form>
	</div>
<!--{elseif $_GET['op'] == 'edittitle'}-->
	<div class="edittitle cl">
	<form class="edittitlex" id="titleform" name="titleform" action="home.php?mod=spacecp&ac=album&op=editpic&subop=update&albumid=$pic[albumid]" method="post" autocomplete="off" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="editpicsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<style type="text/css">
			.edittitlex .pt {width: 93%;padding: 3%;}
		</style>
		<textarea name="title[{$pic[picid]}]" cols="50" rows="7" class="pt">$pic[title]</textarea>
		<p class="o pns">
			<button type="submit" name="editpicsubmit_btn" class="pn pnc " value="true">{lang update}</button>
		</p>
	</form>
	</div>


<!--{/if}-->
</div>

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->











