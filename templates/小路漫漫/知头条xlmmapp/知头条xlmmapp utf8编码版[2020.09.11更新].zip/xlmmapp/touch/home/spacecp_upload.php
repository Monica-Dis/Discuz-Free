<?PHP exit('Access 上传相册，xlmm2020');?>
<!--{template common/header}-->
<style>
.red { color:red;;}
.xlmmxcxz {padding-right:8px;vertical-align:top;}
.xlmmxcms {-webkit-appearance:none;width:100%;min-height:96px;line-height:24px;border:none !important;font-size:15px;vertical-align:middle;background-color:transparent;}
.xlmmxcpn {-webkit-appearance:none;width:100%;min-height:48px;line-height:24px;border:none !important;font-size:14px;vertical-align:middle;background-color:transparent;}
.xlmmxcfles {display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-align:center;-webkit-align-items:center;-ms-flex-align:center;align-items:center;}
.flex {-webkit-box-flex:1;-webkit-flex:1;-ms-flex:1;flex:1;}
.xlmmxcipt {-webkit-appearance:none;width:100%;height:1.4em;line-height:1.4;font-size:inherit;border:none;outline:none;background-color:transparent;}
.xlmmxcpl {background:#fff;font-size:15px; min-height:50px; border:1px solid #efefef;}
.xlmmxcpl select{ width: 100%;background: #fff url(template/xlmmapp/touch/forum/post/ztfl_xxsx.png) no-repeat; background-position: right;background-size: 15px auto; border: 0;border-radius: 0;color: #000;font-size: 15px; outline: none;-webkit-appearance: none;}

.xlmmxcpltit {padding:12px 12px 5px;height:24px;line-height:24px;font-size:13px;}
.xlmmxcbtn { color:#fff;-webkit-appearance:none;display:block;margin:0 auto;width:100%;height:44px;line-height:44px;font-size:16px;border:none;outline:none;text-align:center;text-decoration:none;overflow:hidden;border-radius:2px; background-color: #0285f7}

.xlmmxcimg {margin:12px;overflow:hidden;}
.xlmmxcimg li {padding:12px 0;overflow:hidden;}
.xlmmxcimg li.xlmmxcup {position:relative;}
.xlmmxcimg li.xlmmxcup a {display:inline-block;width: 50px;height: 50px; background: url(template/xlmmapp/touch/forum/post/tpsc_tpxz.png) no-repeat;background-position: 0;background-size: 50px auto;}
.xlmmxcimg li.xlmmxcup a input {position:absolute;top:12px;left:0px;height:50px;width:50px;z-index:10;opacity:0;}
.xlmmxcimg .editpic_l {width:16px;overflow:hidden;}
.xlmmxcimg .editpic_img {width:100px;height:78px;margin:0 10px;background:#000;overflow:hidden;position:relative;border-radius:2px;}
.xlmmxcimg .editpic_imgbox {width:100px;height:78px;overflow:hidden;}
.xlmmxcimg .editpic_imgbox img {width:100%;}
.xlmmxcimg .editpic_imgbox a {display:block;height:78px;overflow:hidden;}
.xlmmxcimg .editpic_imgbox p {position:absolute;left:0;bottom:0;display:block;background-color:rgba(0, 0, 0, 0.7);width:100%;height:24px;line-height:24px;font-size:12px;text-align:center;overflow:hidden;}
.xlmmxcimg .editpic_textarea {padding:5px 7px;height:66px;font-size:14px;line-height:22px;overflow:hidden;border-radius:2px; border:1px solid #efefef;}
.xlmmxcimg .editpic_textarea textarea {width:100%;height:100%;border:none !important;overflow:hidden;}


	
</style>	



	<form method="post" autocomplete="off" id="albumform" action="home.php?mod=spacecp&ac=upload">
	<input type="hidden" name="albumsubmit" id="albumsubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
<div class="mt20 cl">
<ul>	
	<li class="xlmmxcpl xlmmxcfles plr15">
<div class="xlmmxcxz">上传到</div>
<div class="flex">
<select id="albumop" name="albumop" onchange="album_op(this.value);">
<option value="selectalbum" selected="selected">现有相册</option>
<option value="creatalbum">创建新相册</option>
</select>
</div>
</li>
<div id="selectalbum">
<li class="xlmmxcpl xlmmxcfles plr15">
<div class="xlmmxcxz f_c">选相册</div>
<div class="flex">
<select id="albumid" name="albumid">
						<!--{loop $albums $value}-->
							<!--{if $value['albumid'] == $_GET['albumid']}-->
								<option value="$value[albumid]" selected="selected">$value[albumname]</option>
							<!--{else}-->
								<option value="$value[albumid]">$value[albumname]</option>
							<!--{/if}-->
						<!--{/loop}-->
</select>
</div>
</li>
</div>
<div id="creatalbum" style="display:none;">
<li class="mt20"></li>
<li class="xlmmxcpl xlmmxcfles plr15">
<div class="xlmmxcxz">{lang album_name}</div>
<div class="flex"><input type="text" name="albumname" id="albumname" class="xlmmxcipt" value="" placeholder="必填项，如（{lang my_album}）" /></div>
</li>					
<li class="xlmmxcpl  plr15">
<textarea name="depict" placeholder="{lang album_depict}" class="xlmmxcms"></textarea>
</li>
							<!--{if $_G['setting']['albumcategorystat'] && $categoryselect}-->
<li class="xlmmxcpl xlmmxcfles plr15">
<div class="xlmmxcxz f_c">{lang site_categories}</div>
<div class="flex">
$categoryselect
</div>
</li>

	<li class="xlmmxcpltit plr15 cl">{lang select_site_album_categories}</li>		
					<!--{/if}-->
<li class="xlmmxcpl xlmmxcfles plr15 cl">
<div class="xlmmxcxz f_c">隐私设置</div>
<div class="flex">
<select id="friend" name="friend" onchange="passwordShow(this.value);">
										<option value="0">{lang friendname_0}</option>
										<option value="1">{lang friendname_1}</option>
										<option value="2">{lang friendname_2}</option>
										<option value="3">{lang friendname_3}</option>
										<option value="4">{lang friendname_4}</option>
</select>
</div>
</li>		
<li class="xlmmxcpl plr15 cl" id="span_password" style="display:none;">
<input type="text" name="password" value="" class="xlmmxcipt" placeholder="密码(必填)" />
</li>		
<div id="tb_selectgroup" style="display:none;">
<li class="xlmmxcpl xlmmxcfles plr15 cl">
<select name="selectgroup" id="selectgroup">
											<option value="">{lang from_friends_group}</option>
											<!--{loop $groups $key $value}-->
											<option value="$key">$value</option>
											<!--{/loop}-->
										</select>
</li>	
<li class="xlmmxcpltit plr15 cl">{lang friend_name_space}</li>		
<li class="xlmmxcpl plr15 cl">
<textarea name="target_names" id="target_names" class="xlmmxcpn"></textarea>
</li>
</div>

</div>
<li class="xlmmxcpltit plr15">请选择您要上传的图片</li>
<li class="xlmmxcpl plr15 cl">		
<div class="xlmmxcimg cl" style="margin:0 0 3px 0;">
<ul id="imglist">
<li class="xlmmxcup xlmmxcfles white">
<a href="javascript:;"><input type="file" name="Filedata" id="filedata" multiple accept="image/*" /></a>
<div class="flex " style="text-align:right;">添加后可以继续添加图片</div>
</li>				
</ul>
</div>
</li>

<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="{STATICURL}js/mobile/buildfileupload.js?{VERHASH}"></script>
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
	var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
$(document).on('change', '#filedata', function(){
var xlmm_file = new Array(); 
var xlmm_fileon = 0;
var xlmm_filelength = this.files.length;
if(xlmm_filelength == 0){
return;
}
			popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
uploadsuccess = function(data) {
xlmm_fileon++;
var err = xlmm_upload_success(data);
if(err == false){
return false;
}
if(xlmm_fileon == xlmm_filelength){
popup.close();
popup.open('上传完成!', 'alert');
}		
};
uploaderror = function() {
xlmm_fileon++;
popup.open('上传失败，请稍后再试', 'alert');
};
if(!(this.files[0].type == 'image/gif' && xlmm_filelength == 1) && typeof FileReader != 'undefined' && this.files[0]) {
for (var i = 0; i < this.files.length; i++){
xlmm_file[0] = this.files[i];
$.buildfileupload({
uploadurl:'misc.php?mod=swfupload&action=swfupload&operation=album&type=image',
files:xlmm_file,
uploadformdata:{uid:"$_G[uid]", hash:"$swfconfig[hash]"},
uploadinputname:'Filedata',
maxfilesize:"2097152",
success:uploadsuccess,
error:uploaderror
});
}
} else {
$.ajaxfileupload({
url:'misc.php?mod=swfupload&action=swfupload&operation=album&type=image',
data:{uid:"$_G[uid]", hash:"$swfconfig[hash]"},
dataType:'text',
fileElementId:'filedata',
success:uploadsuccess,
error:uploaderror
});
}
});
</script>
<script type="text/javascript">
function xlmm_upload_success(a){
if(a == '') {
popup.open('上传失败，请稍后再试', 'alert');
}else{
var dataarr = eval('('+a+')');
if(dataarr['picid'] == '0'){
popup.open('上传失败，请稍后再试', 'alert');
}else{
$('#imglist').append('<li class="xlmmxcfles b_t"><div class="editpic_l del" aid="'+dataarr['picid']+'"><i class="iconfont red">&#xe701;</i></div><div class="editpic_img"><div class="editpic_imgbox"><'+'img id="aimg_'+dataarr['picid']+'" src="'+dataarr['bigimg']+'" /></div></div><div class="editpic_textarea b_ok flex"><textarea name="title['+dataarr['picid']+']" placeholder="图片描述"></textarea></div></li>');
}
}
}
			<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
			geo.getcurrentposition();
			<!--{/if}-->
$(document).on('click', '.del', function() {
var obj = $(this);
$.ajax({
type:'GET',
url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
})
.success(function(s) {
obj.parent().remove();
})
.error(function() {
popup.open('网络出现问题，请稍后再试', 'alert');
});
return false;
});
</script>				
</ul>
</div>
<div class="plr15 mt20 cl">
<button type="submit" name="albumsubmit_btn" id="albumsubmit_btn" value="true" class="formdialog xlmmxcbtn bcolour">发布相册</button>
</div>	
</form>			
<script>
function passwordShow(value) {
	if(value==4) {
		$('#span_password').css('display','');
		$('#tb_selectgroup').css('display','none');
	} else if(value==2) {
		$('#span_password').css('display','none');
		$('#tb_selectgroup').css('display','');
	} else {
		$('#span_password,#tb_selectgroup').css('display','none');
	}
}
function album_op(id) {
	$('#selectalbum,#creatalbum').css('display','none');
	$('#'+id).css('display','block');
}
</script>


<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->












