<?php
/**xlmm 2020**/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_xlmmappgl {
       function global_header() {
            global $_G;
            $_G['xlmmappgl'] = array();
            $_G['xlmmappgl'] = $_G['cache']['plugin']['xlmmappgl'];  
   }
	
}