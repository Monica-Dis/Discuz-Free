<?php
/**xlmm 2020**/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_xlmmappgl{
 
 public function global_header_mobile(){
			global $_G,$show_message;
	$_G['xlmmappglmb'] = $_G['cache']['plugin']['xlmmappgl'];
 function xlmmappglbls(){
			global $_G,$show_message;
	$xlmmappglbls = $_G['xlmmappglmb'];
	return $xlmmappglbls;
}

function xlmmappglbls_block($blocks){
			global $_G,$show_message;
	$blocks = str_replace(array('<!--{block/','}-->'),'',$blocks);
	$blocks = explode(PHP_EOL,$blocks);
	foreach($blocks as $bid){
		$data .= xlmmappglbls_blocktags($bid);
	}
	return $data;
}
function xlmmappglbls_blocktags($parameter) {
			global $_G,$show_message;
	include_once libfile('function/block');
	loadcache('blockclass');
	$bid = dintval(trim($parameter));
	block_get_batch($bid);
	$data = block_fetch_content($bid, true);
	return $data;
}
  }

}