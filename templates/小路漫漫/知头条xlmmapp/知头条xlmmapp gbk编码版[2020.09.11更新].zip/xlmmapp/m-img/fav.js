function succeedhandle_forum_fav(a, b, c){
	if(b.indexOf("�ղسɹ�") >= 0){
		b = '����ע�ɹ�';
	var numObj = $('.xlmm_forum_fav_'+ c['id']);
	numObj.attr('href', 'home.php?mod=spacecp&ac=favorite&op=delete&type=forum&formhash='+formhash+'&favid=' + c['favid'] + '&handlekey=forum_fav').text('�ѹ�ע').removeClass('xlmmfwgz').addClass("xlmmfygz");
var numObj = $('.xlmm_forum_favs_'+ c['id']);
var memberNum = parseInt(numObj.html());
numObj.html(memberNum+1);
	}
	popup.open(b, 'alert');
}
function errorhandle_forum_fav(a, b){
	if(a.indexOf("�ظ��ղ�") >= 0){
		a = '����ѹ�ע';
	}else if(a.indexOf("������") >= 0){
		a = '����û�й�ע�˰��';
	}
	popup.open(a, 'alert');
}
function succeedhandle_favorite_del(a, b, c){
	if(b.indexOf("�ɹ�") >= 0){
		b = '��ȡ����ע�˰��';
		var numObj = $('.xlmm_forum_fav_'+ c['id']);
numObj.attr('href', 'home.php?mod=spacecp&ac=favorite&type=forum&id=' + c['id'] + '&formhash='+formhash+'&handlekey=forum_fav').text('+ ��ע').removeClass('xlmmfygz').addClass("xlmmfwgz");
var numObj = $('.xlmm_forum_favs_'+ c['id']);
var memberNum = parseInt(numObj.html());
numObj.html(memberNum-1);
	}
	popup.open(b, 'alert');
}
function errorhandle_favorite_del(a, b){
	if(a.indexOf("������") >= 0){
		a = '����û�й�ע�˰��';
	}
	popup.open(a, 'alert');
}




