<?php exit;?>
<!--{template common/header}-->
            
<div class="sxup" id="sxup">
{eval include_once TPLDIR.'/php/forum_guide.php'; }
    <script src="template/xlmmapp/m-img/dp.js?{VERHASH}" charset="{CHARSET}"></script>
	<div id="s2" class="swiper-container">
	<style>
.swiper-container-autoheight .swiper-wrapper { align-items: flex-start; transition-property: transform,height;}
.swiper-slide {height: auto !important;}
.xlmmlbg {background:url(template/xlmmapp/m-img/lo.gif) no-repeat center 20px;}
.loading{ text-align:center; }
.loading img{ margin: 10px auto;width:40px; height:40px}
</style>
	<div class="swiper-wrapper" id="containerss">

		<div id="0" class="swiper-slide" data-history="portal.php?mod=portal&view=follow"><!--{if $_GET['view'] == 'follow'}--><!--{template common/list}--><!--{/if}--></div>
		<div id="1" class="swiper-slide" data-history="./"><div></div><!--{if !$_GET['view'] == 'follow' ||  !$_GET['view'] == 'hot'}--><!--{template common/list}--><!--{/if}--></div>
		<div id="2" class="swiper-slide" data-history="portal.php?mod=portal&view=hot"><!--{if $_GET['view'] == 'hot'}--><!--{template common/list}--><!--{/if}--></div>

</div>
</div>

  <script>
     var swhotabsIndex = $('.swhotabs li.a').index();
var idx = swhotabsIndex;
idxChange(idx)
  barwidth = 36 //������ɫ���ĳ���px
  tSpeed = 300 //�л��ٶ�300ms
 if($(".swhotabs li.a").length > 0) {
var xlmminx = $(".swhotabs li.a").offset().left + $(".swhotabs li.a").width() >= $(window).width() ? $(".swhotabs li.a").index() : 0;
}else{
var xlmminx = 0;
}	
 var my1 = new Swiper('#s1.swhotabs', {
        slidesPerView: 'auto',
  	freeMode: true,
    	resistanceRatio: 0,
	 initialSlide : xlmminx,
passiveListeners: false,
slideActiveClass : 'x-l-m-m-active',
on: {
  		init: function() {
  			navSlideWidth = this.slides.eq(0).css('width') ; //����������Ҫͳһ,ÿ����������һ��
			bar = this.xlmmels.find('.bar')
  			bar.css('width', navSlideWidth)
  			bar.transition(tSpeed)
	navSum = this.slides[this.slides.length - 1].offsetLeft //���һ��slide��λ��

  			clientWidth = parseInt(this.xlmmwrEl.css('width')) //Nav�Ŀ��ӿ���
	navWidth = 0
  			for (i = 0; i < this.slides.length; i++) {
  				navWidth += parseInt(this.slides.eq(i).css('width'))
  			}

  		},

  	},
  });

  var my2 = new Swiper('#s2', {
  	watchSlidesProgress: true,
  	resistanceRatio: 0.1,
  initialSlide: swhotabsIndex,
	    history: {
        key: '',
   // replaceState: true,
 },
passiveListeners : false,
slideActiveClass : 'sxlmm-active',
	on: {
  		touchMove: function() {
	progress = this.progress
  			bar.transition(0)
  			bar.transform('translateX(' + navSum * progress + 'px)')

  			for (i = 0; i < this.slides.length; i++) {
  				slideProgress = this.slides[i].progress
  				if (Math.abs(slideProgress) < 1) {
  					r = Math.floor((000 - 51) * (1 - Math.pow(Math.abs(slideProgress), 2)) + 51)
  					g = Math.floor((11 - 51) * (1 - Math.pow(Math.abs(slideProgress), 2)) + 51)
  					b = Math.floor((11 - 51) * (1 - Math.pow(Math.abs(slideProgress), 2)) + 51)
    			    d = Math.floor((102 - 51) * (1 - Math.pow(Math.abs(slideProgress), 2)) + 51)
					my1.slides.eq(i).find('.xlmmtsnav').css('color', 'rgba(' + r + ',' + g + ',' + b + ',1)')
 					//my1.slides.eq(i).find('#xlmmtsnav').attr('class', 'axlmmm' + d + '')
	}
  			}
 		},
  		transitionStart: function() {
	activeIndex = this.activeIndex
  			activeSlidePosition = my1.slides[activeIndex].offsetLeft
  			//�ͷ�ʱ������ɫ���ƶ�����
  			bar.transition(tSpeed)
  			bar.transform('translateX(' + activeSlidePosition + 'px)')
	//�ͷ�ʱ���ֱ�ɫ����
  			my1.slides.eq(activeIndex).find('.xlmmtsnav').transition(tSpeed)
  			my1.slides.eq(activeIndex).find('.xlmmtsnav').css('color', '#000')
    			//my1.slides.eq(activeIndex).find('#xlmmtsnav').attr('class', 'axlmmm102')
	if (activeIndex > 0) {
  				my1.slides.eq(activeIndex - 1).find('.xlmmtsnav').transition(tSpeed)
  				my1.slides.eq(activeIndex - 1).find('.xlmmtsnav').css('color', '#666')
  		  			//	my1.slides.eq(activeIndex - 1).find('#xlmmtsnav').attr('class', '666')
	}
  			if (activeIndex < this.slides.length) {
  				my1.slides.eq(activeIndex + 1).find('.xlmmtsnav').transition(tSpeed)
  				my1.slides.eq(activeIndex + 1).find('.xlmmtsnav').css('color', '#666')
  	  				//my1.slides.eq(activeIndex + 1).find('#xlmmtsnav').attr('class', '666')
	}
  			//��������
  			navActiveSlideLeft = my1.slides[activeIndex].offsetLeft //activeSlide����ߵľ���

  			my1.setTransition(tSpeed)
  			if (navActiveSlideLeft < (clientWidth - parseInt(navSlideWidth)) / 2) {
  				my1.setTranslate(0)
  			} else if (navActiveSlideLeft > navWidth - (parseInt(navSlideWidth) + clientWidth) / 2) {
  				my1.setTranslate(clientWidth - navWidth)
  			} else {
  				my1.setTranslate((clientWidth - parseInt(navSlideWidth)) / 2 - navActiveSlideLeft)
  			}

  		},
  		transitionEnd: function() {
setTimeout(function(){ var t = jQuery(window).scrollTop();
jQuery('body,html').animate({'scrollTop':t-1},0) },0) 
  		},
  init: function(){
            $("#xlmmbars").show(); 
    },
	},
    autoHeight:true,
 });

  my1.xlmmels.on('touchstart', function(e) {
  	e.preventDefault() //ȥ����ѹ��Ӱ
  })

   my1.on('tap', function(e) {

  	clickIndex = this.clickedIndex
  	clickSlide = this.slides.eq(clickIndex)
  	my2.slideTo(clickIndex, 0);
  	this.slides.find('.xlmmtsnav').css('color', '#666');
  	clickSlide.find('.xlmmtsnav').css('color', '#000');
   	//this.slides.find('#xlmmtsnav').attr('class', '666');
  //	clickSlide.find('#xlmmtsnav').attr('class', 'axlmmm102');


})

  my1.on('tap', function (e) {
        console.log(this.clickedIndex);
        idx = this.slides.eq(clickIndex)
        idxChange(idx)
    })

    my2.on('slideChange', function (e) {
        console.log(this.activeIndex);
        idx = this.activeIndex;
        idxChange(idx);
   });

function idxChange(idx) {
    var obj = $('#s1 .swiper-slide');
 obj.removeClass('active');
   obj.eq(idx).addClass('active');
   	var ididx = '#'+idx;
 	var curCon = ididx+' .xlmmdp-containers';
  	var curConif = $(""+curCon);
  	var curCons = $("#"+idx).attr("data-history");
  	var bdheight = $(document.body).height();
if(curConif.length>0) {
} else {
	$.ajax({
						url: curCons,
						cache: false,
	        beforeSend:function(){
            $("#s2").addClass('xlmmlbg'); 
  },
		success: function(datas){
	   	if(datas.indexOf('<xlmmajax></xlmmajax>')>=0){
  var newdata = datas.match(/<xlmmajax><\/xlmmajax>([\s\S]+?)<xmle><\/xmle>/);
	$("#"+idx).html(newdata[1]);
setTimeout(function(){$("#containerss").css('height',$("#"+idx).height())},500) 
            $("#s2").removeClass('xlmmlbg'); 
}else{
			  location.replace(curCons);
					 	}
											},error: function() {
     $("#"+idx).html("<div id=\"errora\" style=\"text-align: center;color: #999;margin-top:20px;\">���ݻ�ȡʧ��</div>");
		}
						});			
							}
}
window.addEventListener("popstate", function(e) { 
var xlmmdata = window.location.href;
     javaScript:history.go(xlmmdata);
    });

 $(function(){
    $(".sxup").dropload({
        scrollArea : window,
        
        domUp : {
            domClass   : 'dropload-up',
            domRefresh : '',
            domUpdate  : '<div class="dropload-update loading"><img src="template/xlmmapp/m-img/lo.png"></div>',
            domLoad    : '<div style=\"text-align: center;color: #999;line-height:80px;font-size:16px;\">loading...</div>'
        },
        loadUpFn : function(me){
location.reload();
        },

    });

});
     $(window).scroll(function() {
	var xlmmscids = $('.getMorexlajp'+my2.activeIndex);
if ($(document).scrollTop() <= 0) { }

var srollPos = $(window).scrollTop();  
totalheight = parseFloat($(window).height()) + parseFloat(srollPos);  
            if(($(document).height()) <= totalheight) {

xlmmscids.click();

        }

})
 </script>
</div>

<!--{template common/footer}-->


