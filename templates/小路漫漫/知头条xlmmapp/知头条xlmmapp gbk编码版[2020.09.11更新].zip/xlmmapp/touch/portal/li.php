<?php exit;?>
	{if $portal_type['catid'] == $_G['catid']}
   	<xlmmajax></xlmmajax>
<div class="xlmmdp-containers $xlaj">
<div class="p20 white mt10" style="padding-top:4px !important">
<ul id="xlmmjps$xlaj">
		<start$xlaj></start$xlaj>
					<!--{if !$list['list']}-->
<div class="mt10" style="text-align:center; background:#FFFFFF; padding:40px 0 80px 0; height:726px"><svg width="150" height="120" viewBox="0 0 150 120" class="Topstory-newUserFollowCountPanelIcon" fill="currentColor"><g fill="none" fill-rule="evenodd"><path fill="#EBEEF5" d="M44 31.005v55.99A3.003 3.003 0 0 0 47.003 90h53.994A3.005 3.005 0 0 0 104 86.995v-55.99A3.003 3.003 0 0 0 100.997 28H47.003A3.005 3.005 0 0 0 44 31.005zm-3 0A6.005 6.005 0 0 1 47.003 25h53.994A6.003 6.003 0 0 1 107 31.005v55.99A6.005 6.005 0 0 1 100.997 93H47.003A6.003 6.003 0 0 1 41 86.995v-55.99z" fill-rule="nonzero"></path><path fill="#F7F8FA" d="M59 50a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 40.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5zM59 73a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 63.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5z"></path></g></svg><div style="font-size: 15px;color: grey;">��û���κ�����Ŷ<style>.getMore{ display:none !important;}</style>
</div></div>	
 			<!--{/if}-->
	<!--{loop $list['list'] $key $value}-->
				<!--{eval $highlight = article_title_style($value);}-->
				<!--{eval $article_url = fetch_article_url($value);}-->
	{eval include TPLDIR.'/php/portal_list.php';}
	<li>
<a href="$article_url" class="HotQuestionsItem<!--{if $xlmmal ==0 }--> HotQuestionsItem-mul<!--{elseif $xlmmal <= 2}--><!--{elseif $xlmmal >2}--> HotQuestionsItem-mul<!--{/if}-->">
<div class="HotQuestionsItem-contain">
	<h3 class="HotQuestionsItem-title">$value[title]</h3>
<!--{if $xlmmal >2}-->
<div class="HotQuestionsItem-mulImgList" style="margin-top:6px">
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==3) break;}-->
	<div class="HotQuestionsItem-mulImgWrapper">
		<img class="HotQuestionsItem-mulImg" src="<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->">
	</div>
<!--{/loop}-->
</div>
<!--{/if}-->
	<div class="HotQuestionsItem-description">
		<!--{if $value[viewnum] > 0}-->$value[viewnum]<!--{else}-->0<!--{/if}--> �ε�� �� $value[commentnum] ����
	</div>
</div>
<!--{if $xlmmal ==0 }-->
<!--{elseif $xlmmal <= 2}-->
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==1) break;}-->
<img class="HotQuestionsItem-img" src="<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->">
<!--{/loop}-->
<!--{/if}-->
</a>
	</li>
			<!--{/loop}-->
</ul>
 <end$xlaj></end$xlaj>
	<div id="titless$xlaj" style="display:none"><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname']<!--{/if}--></div><div id="allpgs$xlaj" style="display:none">{echo $thispage = ceil($list[count] / $perpage);}</div><div id="oallpgs$xlaj" style="display:none">$_G['page']</div>
     <a href="javascript:;" id="xlmmsdj" class="getMore$xlaj"><div style="text-align: center;line-height:40px;color: #999;">������ظ���</div></a>
</div>
	 </div>
<script type="text/javascript">
  xlmmurl$xlaj= "$cat['caturl']";
 var allnum$xlaj= $("#allpgs$xlaj").text();
 var num$xlaj = $("#oallpgs$xlaj").text();
    var nomore$xlaj= "<div style=\"text-align: center;line-height:40px;color: #999;\">��Ҳ���е��ߵ�Ŷ</div>";
       if(num$xlaj >= allnum$xlaj) { 
 $('.getMore$xlaj').html(nomore$xlaj);;
}
  	$('.getMore$xlaj').click(function(e){
       if(num$xlaj >= allnum$xlaj) { 
}
else {
      num$xlaj++;  
 $.ajax({
             url:xlmmurl$xlaj+'?&page='+num$xlaj+'' ,
        type:'get',
        dataType: 'html',
        beforeSend:function(){
            $('.getMore$xlaj').html("<div style=\"text-align: center;line-height:40px;color: #999;\"><img src=\"static/image/common/loading.gif\" width=\"16\" height=\"16\" class=\"vm\" /> ������...</div>"); 
 },
        success:function (data$xlaj){
	     var newdatas$xlaj = data$xlaj.match(/<start$xlaj><\/start$xlaj>([\s\S]+?)<end$xlaj><\/end$xlaj>/);
		     var newdatas1 = newdatas$xlaj;
$('#xlmmjps$xlaj').append(newdatas1[1]);    
                  $('.getMore$xlaj').html("<div style=\"text-align: center;line-height:40px;color: #999;\">������ظ���</div>"); 
          if(num$xlaj >= allnum$xlaj) { 
 $('.getMore$xlaj').html(nomore$xlaj);;
}
 $("#containerss").css('height',$("#s2 .swiper-slide.sxlmm-active").height())
     },error: function() {
            $('.getMore$xlaj').html("<div style=\"text-align: center;line-height:40px;color: #999;\">���ݻ�ȡʧ��</div>");
        }
  })
	        }
});

</script>
  <xmle></xmle>
{/if}


