<?php exit;?>
<!--{template common/header}-->
<!--{if $tagname}-->
<script src="template/xlmmapp/touch/forum/post/sw.js?FBM" type="text/javascript" ></script>

	<style>
.talk-lists .peo-talk {font-size: 0px; padding-top: 0.3rem;padding-left: 0.3rem;padding-bottom: 0.03rem; cursor: pointer;}
.info-icon img {border-radius: 50rem;-webkit-border-radius: 50rem;-o-border-radius: 50rem;-moz-border-radius: 50rem;-ms-border-radius: 50rem;}
.talk-lists .peo-talk .peo-info .info-txt {position: relative;margin-left: 0.92rem;}
.talk-lists {border-top: 1px solid #e6e6e6;border-bottom: 1px solid #d8d8d8;box-sizing: border-box;box-shadow: 0 1px .1875rem -.125rem rgba(0,0,0,.2);}
.talk-lists .peo-talk .peo-info {position: relative;height: 0.8rem;}
.talk-lists .peo-talk .peo-info .info-icon {width: 0.8rem;height: 0.8rem;display: inline-block;vertical-align: middle;position: absolute;left: 0px;top: 0px;}
.talk-lists .peo-talk .peo-info .info-icon img {display: inline-block;vertical-align: middle;width: 0.78rem;height: 0.78rem;border: 0.01rem solid #aeaeae;overflow: hidden;}
.talk-lists .peo-talk .peo-info .info-txt .txt-name {color: #000000;font-size: 0rem;line-height: 0.48rem;}
.talk-lists .peo-talk .peo-info .info-txt .peo-name {display: inline-block;vertical-align: middle;color: #000000;font-size: 0.28rem;}
.talk-lists .peo-talk .peo-info .info-txt .txt-name .pink {border-color: #fc8bc4;}
.talk-lists .peo-talk .peo-info .info-txt .txt-name .peo-level font {font-size: 10px;-webkit-text-size-adjust: none;color: #fff;border-radius: 2px;-webkit-border-radius: 2px;-o-border-radius: 2px;-moz-border-radius: 2px;-ms-border-radius: 2px;display: inline-block;margin-left: 0.1rem;zoom: 1;vertical-align: middle;line-height: .25rem;padding: 0 0.05rem;text-align: center;border-color: #fc8bc4;background: #ffcaed;}
.talk-lists .peo-talk .peo-info .info-txt .txt-name .pink .font2 {color: #fc8bc4;}
.talk-lists .peo-talk .peo-speak {margin-top: -0.34rem;margin-left: 0.92rem;margin-right: 0.3rem;}
.talk-lists .peo-talk .peo-speak .speak-txt {color: #222222;font-size: 0.32rem;line-height: 0.55rem;display: block;margin-bottom: 0.16rem;}
.talk-lists .peo-talk .peo-speak .speak-imgs {margin-top: 0.16rem;position: relative;margin-left: -0.14rem;margin-top: -0.14rem;font-size: 0px;margin-bottom:.22rem;}

.tupyas img{width: 1.9rem;height: 1.9rem;margin-left: 0.14rem;}
.xuan3 {background: #fff url(template/xlmmapp/m-img/xuan.png) right center no-repeat;background-size: 0.14rem 0.24rem;}
.talk-lists .peo-talk .peo-speak .speak-info {margin-bottom:.1rem;}
.sclear::before, .sclear::after {content: "";clear: both;height: 0px;visibility: hidden;display: block;}
.talk-lists .peo-talk .peo-speak .speak-time {color: #999999;font-size: 0.26rem;display: inline-block;vertical-align: middle;}
.talk-lists .peo-talk .peo-speak .speak-zan {cursor: pointer;text-align: center;color: #999999;line-height: 0.3rem;display: inline-block;vertical-align: middle;position: relative;padding: .1rem;margin-right: -.1rem;}
.talk-lists .peo-talk .peo-speak .speak-zan i {margin-right: 0.05rem;width: 0.3rem;height: 0.3rem;display: inline-block;vertical-align: middle;background: url(template/xlmmapp/m-img/zans.png) no-repeat;background-size: auto 0.3rem;background-position: 0rem 0rem;}
.talk-lists .peo-talk .peo-speak .speak-zan i.views{background: url(template/xlmmapp/m-img/fview.png) no-repeat;background-size: auto 0.3rem;background-position: 0rem 0rem;}
.talk-lists .peo-talk .peo-speak .speak-zan i.replies{background: url(template/xlmmapp/m-img/fposts.png) no-repeat;background-size: auto 0.3rem;background-position: 0rem 0rem;}
.talk-lists .peo-talk .peo-speak .speak-zan .zan_txt {display: inline-block;vertical-align: middle;height: .3rem;font-size: 0.26rem;}
	</style>

   <!--{eval $xlmmtag = DB::fetch_all("SELECT * FROM ".DB::table('common_tag')." WHERE `status`= 0 ORDER BY `tagid` DESC LIMIT 0, 10");}-->
   <div class="adtopic mt20 white plr15 "> <a href="misc.php?mod=tag" class="adtopic-name xuan3 localloop-title">�Ƽ���ǩ</a>
      <div class="swiper-container swiper-container2 swiper-container-horizontal">
        <div class="swiper-wrapper">
                  <div class="swiper-slide adtopic-list swiper-slide-active">
            <ul class="cl">
     <!--{loop $xlmmtag $xl_tag}-->
                               <li><a href="misc.php?mod=tag&id=$xl_tag[tagid]"  class="swiper-slide"> <span>$xl_tag[tagname] </span></a></li>
<!--{/loop}-->
                            </ul>
          </div>
                        </div>
                </div>
    </div>
 <script type="text/javascript">
   var xlmmswt = new Swiper('.swiper-container2',{
 loop: false,
        autoplayDisableOnInteraction : false    });
    </script>
 <!--{if empty($showtype) || $showtype == 'thread'}-->
				<!--{if $threadlist}-->
	<content class="feed-list-container " id="junmi360">
					<!--{loop $threadlist $thread}-->
												<!--{eval include TPLDIR.'/php/img.php';
                                                        $getgid=getuserbyuid($thread[authorid]);
        $xlmmdj = DB::result_first("SELECT stars FROM %t WHERE groupid=%d", array("common_usergroup", $getgid['groupid']));
}-->
 <section class="talk-lists white mt20">
    
    <div class="peo-talk white ">
                <div class="peo-info">
                  <a href="home.php?mod=space&uid=$thread[authorid]" class="info-icon" >
             {avatar($thread[authorid],small)}                 </a>
                  <div class="info-txt">
                    <p class="txt-name">
                        <a href="home.php?mod=space&uid=$thread[authorid]" class="peo-name">$thread[author]</a>
                        <span class="peo-level pink">
                            <font class="font">LV.$xlmmdj</font>
                        </span>
                                            </p>
                  </div>
                </div>
                <div class="peo-speak">
                    <div class="speak-txt">
                        <a href="forum.php?mod=forumdisplay&fid=$thread[fid]" style="color:#607fa6;">#$thread['forumname']#</a> <a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"><!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
										$thread[typehtml] $thread[sorthtml]
										$thread[subject]</a>
                                                </div>
 <!--{if $xlmmattach}-->                                                                    
                  <div class="speak-imgs speak-img  cl my-gallery">
          {if  $xlmmal >= 1}
                      <div class=" speak-img1<!--{if $xlmmal ==1}--><!--{else}--> tupyas<!--{/if}-->"<!--{if $xlmmal ==1}--> style="margin-left: 0.14rem;"<!--{/if}-->>
                   <!--{eval $xlmmi=0;}-->
 <!--{loop $xlmmattach $key $attach}-->  <span style="margin-top:0.14rem; display:inline-block;"><img src="<!--{if $attach['aid']}-->{eval echo(getforumimg($attach['aid'],0,230,230))}<!--{else}-->$attach['attachment']<!--{/if}-->"></span>
          <!--{eval $xlmmi++}-->
<!--{/loop}--> 
                   </div>
   	   {/if}
                         </div>
										<!--{/if}-->

     <div class="speak-info sclear">
                                            <span class="speak-time">$thread[dateline]</span>
                      <span class="speak-zan fr speak-zan-button" data-id="839111"><i class="replies"></i><span class="zan_txt" style="margin-right: .2rem;">�ظ� $thread[replies]</span><i class=""></i><span class="zan_txt"> �� $thread[recommend_add]</span></span>
                  </div>
                  
                  
                  
                             </div>
 
 
    </div>

                              </section>
           						<!--{/loop}-->
				</content>
						<!--{if empty($showtype)}-->
						<div style="text-align:center; margin-top:10px;">
							<a style="color:#607fa6;" href="misc.php?mod=tag&id=$id&type=thread">{lang more}...</a>
						</div>
					<!--{else}-->
						<!--{if $multipage}--><div class="pgs mtm cl">$multipage</div><!--{/if}-->
					<!--{/if}-->
				<!--{else}-->
					<p class="emp">{lang no_content}</p>
				<!--{/if}-->
			<!--{/if}-->

<!--{/if}-->
	<div class="clearfix"></div>
<!--{template common/footer}-->












