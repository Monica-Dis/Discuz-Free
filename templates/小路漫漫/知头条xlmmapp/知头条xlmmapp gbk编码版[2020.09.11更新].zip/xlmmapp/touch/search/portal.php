<?php echo '';exit;?>
<!--{template common/header}-->

<div class="xlmm_tbxj"></div>
<style type="text/css">
.bg {background: #fff;}
</style>

<form class="searchform xlmm_ssymsr" method="post" autocomplete="off" action="search.php?mod=portal&mobile=2" onsubmit="if($('scform_srchtxt')) searchFocus($('scform_srchtxt'));">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<!--{subtemplate search/pubsearch}-->
</form>
<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
<!--{subtemplate search/portal_list}-->
<!--{/if}-->

<!--{eval $nofooter = true;}-->
<!--{subtemplate common/footer}-->












