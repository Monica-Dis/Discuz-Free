<?php exit;?>
{if $_G['basescript'] == 'forum' && CURMODULE == 'guide' || $_G['basescript'] == 'forum' && CURMODULE == 'index' || $_G['basescript'] == 'portal' && CURMODULE == 'index' || $_G['basescript'] == 'group' && CURMODULE == 'index' || $_G['basescript'] == 'portal' && CURMODULE == 'list' }
  <style>
#s1 .bar {width: 30px; height: 3px;position: absolute;bottom: 0px; }
#s1 .bar .color {width: 36px;margin: 0 auto;height: 3px; background: #222;}
.fiexd .iconfont.xlmmtpls { color:#666;}
.xlmmhttb-nav-item {
    height: 40px;
    width: 73px !important;
}
 .xlmmhttb-nav-item.active a {font-size: 0.38rem; 
}
</style>

<div class="fiexd">
<div class="xlmmappht-inner">
	<a class="xlmmappht-logo c666" href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->"><!--{if $_G[uid]}--><img src="uc_server/avatar.php?uid=$_G[uid]&amp;size=middle" style="display: inline;visibility: visible; height:25px; width:25px; border-radius:50%"><!--{else}--><i class="iconfont xlmmtpls" style="height: 25px;  font-size: 20px;width: 22px; margin-bottom:0;line-height: 25px; font-weight:bold;">&#xe903;</i><!--{/if}--></a>
	<form id="searchform" method="post" autocomplete="off" action="search.php?mod=forum" class="xlmmappht-actions">
	<label class="xlmmappht-searchBox Input-wrapper"><svg class="Zi Zi--Search c666" viewbox="0 0 24 24" width="18" height="18"><path d="M17.068 15.58a8.377 8.377 0 0 0 1.774-5.159 8.421 8.421 0 1 0-8.42 8.421 8.38 8.38 0 0 0 5.158-1.774l3.879 3.88c.957.573 2.131-.464 1.488-1.49l-3.879-3.878zm-6.647 1.157a6.323 6.323 0 0 1-6.316-6.316 6.323 6.323 0 0 1 6.316-6.316 6.323 6.323 0 0 1 6.316 6.316 6.323 6.323 0 0 1-6.316 6.316z" fill-rule="evenodd"></path></svg>
  		<input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="srchtype" value="title" />
        <input type="hidden" name="srhfid" value="" />
        <input type="hidden" name="srhlocality" value="forum::mypage" />
              <input type="hidden" name="searchsubmit" value="yes"/>
<input value="" autocomplete="off" name="srchtxt" id="scform_srchtxt" placeholder="��������Ҫ����������" class="Input"></label>
     <button type="submit" href="javascript:;"  class="xlmmappht-sbt" style="display:none">����</button>
	</form>
	<script type="text/javascript">
 (function($){ 
  $('#searchform').on("click", function () {
    $(this).find('.xlmmappht-sbt').show();
  })
  })(jQuery)

</script> 
	<div class="xlmmappht-navItem xlmmappht-moreIconWrapper menu-button">
			<svg class="Zi Zi--More c666" fill="currentColor" viewbox="0 0 24 24" width="25" height="25"><path d="M3.5 5h16a1.5 1.5 0 0 1 0 3h-16a1.5 1.5 0 0 1 0-3zm0 6h16a1.5 1.5 0 0 1 0 3h-16a1.5 1.5 0 0 1 0-3zm0 6h16a1.5 1.5 0 0 1 0 3h-16a1.5 1.5 0 0 1 0-3z" fill-rule="evenodd"></path></svg>	{if $_G[member][newprompt] || $_G[member][newpm]}{eval $newxx = $_G[member][newpm] + $_G[member][newprompt];}<span class="top_message_count">$newxx</span>{/if}		
		</div>
</div>
{if  $_G['basescript'] == 'portal' && CURMODULE == 'index' }
<div id="s1" class="swhotabs">
<ul class="swiper-wrapper xlmmhttb-nav b-line">
                        <li id="xlmmflsl" class="swiper-slide xlmmhttb-nav-item{if $_GET['view'] == 'follow'} a tab-active{/if}">
                            <a href="portal.php?mod=portal&view=follow"  class="xlmmtsnav">
                                <span id="xlmmtsnav">��ע</span>
                            </a>
                        </li>
                        <li id="xlmmflsl" class="swiper-slide xlmmhttb-nav-item{if $_GET['view'] == 'follow' ||  $_GET['view'] == 'hot'}{else} a tab-active{/if}">
                            <a href="./"  class="xlmmtsnav">
                                <span id="xlmmtsnav">�Ƽ�</span>
                            </a>
                        </li>
                        <li id="xlmmflsl" class="swiper-slide xlmmhttb-nav-item{if $_GET['view'] == 'hot'} a tab-active{/if}">
                            <a href="portal.php?mod=portal&view=hot"  class="xlmmtsnav">
                                <span id="xlmmtsnav">�Ȱ�</span>
                            </a>
                        </li>
              <div class="bar" id="xlmmbars" style="display:none">
        <!--<div class="color"></div>-->
      </div>
        </ul>
</div>
{elseif  $_G['basescript'] == 'forum' && CURMODULE == 'index' && empty($gid) && !empty($_G['setting']['grid']['showgrid']) }
<style>.xlmmftp .xlmmhttb-nav-item {width: 50% !important;}.xlmmftp .xlmmhttb-nav-item.active a {color: #0285f7;} .xlmmftp .xlmmhttb-nav-item.active em {
  position: absolute;bottom: 0px;left: 50%;margin-left: -15px;width: 30px;height: 3px; border-radius: 6px;background: #0285f7;}</style>
<div id="s1" class="swhotabs xlmmftp">
<ul class="swiper-wrapper xlmmhttb-nav b-line">
                        <li id="xlmmflsl" class="swiper-slide xlmmhttb-nav-item a tab-active">
                            <a href="javascript:;"  class="xlmmtsnav">
                                <span id="xlmmtsnav">������ҳ<em></em></span>
                            </a>
                        </li>
                        <li id="xlmmflsl" class="swiper-slide xlmmhttb-nav-item tab-active">
                            <a href="javascript:;"  class="xlmmtsnav">
                                <span id="xlmmtsnav">��鵼��<em></em></span>
                            </a>
                        </li>
        </ul>
</div>
{elseif  $_G['basescript'] == 'portal' && CURMODULE == 'list' }
<div style="padding-right:45px;position:relative;">
<div id="s1" class="xlmm-mulisr swhotabs">
<ul class="swiper-wrapper">
<!--{eval $query = DB::query("SELECT catid,upid,catname,url FROM ".DB::table('portal_category')."  where `closed`=0 ORDER BY displayorder ");while($data = DB::fetch($query)) $temp[]=$data;}-->
 <!--{loop $temp $portal_type}-->
 <!--{if $portal_type['upid']=="0"}-->
<li class="swiper-slide {if $portal_type['catid'] == $_G['catid']}a {/if}"><a href="portal.php?mod=list&catid={$portal_type['catid']}"  class="xlmmtsnav">{$portal_type['catname']}</a></li>
 <!--{/if}-->
 <!--{/loop}-->
 <!--{loop $temp $portal_type}-->
 <!--{if !$portal_type['upid']=="0"}-->
<li class="swiper-slide {if $portal_type['catid'] == $_G['catid']}a {/if}"><a href="portal.php?mod=list&catid={$portal_type['catid']}"  class="xlmmtsnav">{$portal_type['catname']}</a></li>
 <!--{/if}-->
 <!--{/loop}-->
</ul>
</div>
<div class="channel-mgr-wrapper"><span class="mgr-mask"></span><a href="forum.php?forumlist=2" id="channel_mgr"></a></div>
</div>

	{else}
  <style>
.xlmmh80{ height:48px !important;}
.fiexd{border-bottom: 1px solid rgba(26,26,26,.06);-webkit-box-shadow: 0 1px 3px 0 rgba(23,81,153,.05); box-shadow: 0 1px 3px 0 rgba(23,81,153,.05);}
  </style>
  {/if}
</div>
<div class="xlmmh80" style="height:88px"></div>
{elseif $_G['basescript'] == 'forum' && CURMODULE == 'announcement' }

<div class="fiexd xlmmtnbg">

<div class="xlmmappht-inner">
	<a class="xlmmappht-logo c666"  onClick="window.location.href='javascript:history.back();';"><i class="iconfont xlmmtpls" >&#xe608;</i></a>
	<div class="xlmmappht-actions c666">
	����
</div>
	<div class="xlmmappht-navItem xlmmappht-moreIconWrapper menu-button c666">
<svg class="Zi Zi--More" fill="currentColor" viewbox="0 0 24 24" width="25" height="25"><path d="M3.5 5h16a1.5 1.5 0 0 1 0 3h-16a1.5 1.5 0 0 1 0-3zm0 6h16a1.5 1.5 0 0 1 0 3h-16a1.5 1.5 0 0 1 0-3zm0 6h16a1.5 1.5 0 0 1 0 3h-16a1.5 1.5 0 0 1 0-3z" fill-rule="evenodd"></path></svg>
	</div>
</div>
{if  $_G['basescript'] == 'forum' && CURMODULE == 'announcement' }
<div id="ss" class="xlmm-mulisr swhotabs">
<ul class="swiper-wrapper">
				<li class="swiper-slide cl{if empty($_GET[m])} a{/if}"><a href="forum.php?mod=announcement"  class="xlmmtsnav">{lang all}</a></li>
			<!--{loop $months $month}-->
				<li class="swiper-slide cl{if $_GET[m] == $month[0].$month[1]} a{/if}"><a href="forum.php?mod=announcement&m=$month[0].$month[1]"  class="xlmmtsnav">$month[0] �� $month[1] ��</a></li>
			<!--{/loop}-->
			</ul>
</div>

<script>
if($(".swhotabs li.a").length > 0) {
var xlmminx = $(".swhotabs li.a").offset().left + $(".swhotabs li.a").width() >= $(window).width() ? $(".swhotabs li.a").index() : 0;
}else{
var xlmminx = 0;
}	
  var xlmmsw3nav = new Swiper('#ss', {
        freeMode: true,
        slidesPerView: 'auto',
 initialSlide : xlmminx,
   });

</script>
	{else}
<div class="xlmmh0"></div>
 {/if}
</div>
<div class="xlmmh80" style="height:88px"></div>
	{else}
<div class="xlmmsf-header">
<div class="sf-header cl">
<span onClick="window.location.href='javascript:history.back();';" class="sf-goback"><i class="iconfont head-icon c666"></i></span>
<span class="sf-title">
      {if $ac=='credit'}
<div class="xlmmmks-ctit-ul cl p0 bl_none">
<ul>
				<li $opactives[base]><a href="home.php?mod=spacecp&ac=credit&op=base">����</a></li>
			<!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->	<li $opactives[transfer]><a href="home.php?mod=spacecp&ac=credit&op=transfer">ת��</a></li><!--{/if}-->
				<!--{if $_G[setting][exchangestatus]}--><li $opactives[exchange]><a href="home.php?mod=spacecp&ac=credit&op=exchange">�һ�</a></li><!--{/if}-->
</ul>
</div>
 {elseif $do=='album'}
<!--{if $value[uid]==$_G[uid]}-->
                      {if $_G['uid']}
<div class="xlmmmks-ctit-ul cl p0 bl_none">
<ul>
						<li$actives[we]><a href="home.php?mod=space&do=album&view=we">����</a></li>
						<li$actives[me]><a href="home.php?mod=space&do=album&view=me">�ҵ�</a></li>
						<li$actives[all]><a href="home.php?mod=space&do=album&view=all">ȫ��</a></li>
</ul>
</div>
  {/if}
 <!--{else}-->
<a><span class="m0">���</span></a>
<!--{/if}-->
 {elseif $ac=='album'}
<!--{if $_GET['op']=='edit' || $_GET['op']=='editpic'}-->
<div class="xlmmmks-ctit-ul cl p0 bl_none">
<ul>
					<!--{eval $aid = $albumid ? $albumid : -1;}-->
			<li{if $_GET['op']=='edit'} class="a"{/if}><a href="home.php?mod=spacecp&ac=album&op=edit&albumid=$albumid">��Ϣ</a></li>
				<li{if $_GET['op']=='editpic'} class="a"{/if}><a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$albumid">ͼƬ</a></li>
</ul>
</div>
<!--{/if}-->
 {elseif $ac=='upload'}
<a><span class="m0">�ϴ����</span></a>
 {elseif $_G['basescript'] == 'forum' && CURMODULE == 'guide'}
<div class="xlmmmks-ctit-ul cl p0 ">
<ul>
				<li $currentview['new']><a href="forum.php?mod=guide&view=new">����</a></li>
				<li $currentview['hot']><a href="forum.php?mod=guide&view=hot">����</a></li>
				<li $currentview['digest']><a href="forum.php?mod=guide&view=digest">�</a></li>
</ul>
</div>
          {elseif $_G['basescript'] == 'member' && CURMODULE == 'logging'}
<a class="c666"><span class="m0">�˺ŵ�¼</span></a>
                 {elseif $_G['basescript'] == 'member' && CURMODULE == $_G[setting][regname]}
<a class="c666"><span class="m0">�˺�ע��</span></a>
    		{elseif  $_G['basescript'] == 'forum' && CURMODULE == 'forumdisplay' }
<a class="c666"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></span></a>
            {elseif $_G['basescript'] == 'portal' && CURMODULE == 'view'}
<a class="c666"><span class="m0">����</span></a>
                {elseif $_G['basescript'] == 'forum' && CURMODULE == 'viewthread'}
<a class="c666"><span class="m0">����</span></a>
                  {elseif $_G['basescript'] == 'search'}
<a class="c666"><span class="m0">����</span></a>
                       {elseif $_GET['action'] == 'nav'}
<a class="c666"><span class="m0">���ѡ��</span></a>
                     {elseif $_GET['action'] == 'newthread'}
<a class="c666"><span class="m0">���ⷢ��</span></a>
                   {elseif $_GET['action'] == 'reply'}
<a class="c666"><span class="m0">����/�ظ�����</span></a>
        {elseif $_G['basescript'] == 'misc' && CURMODULE == 'tag'}
            <a class="c666"><span class="m0"> ��ǩ:{echo cutstr($tagname, 14)}</span></a>
 {/if}
                     </span>
                     {if  $_G['basescript'] == 'forum' && CURMODULE == 'forumdisplay' }
                   <span class="sf-tools" style="margin-top:0; height:46px; line-height:46px">		
<i onclick="window.open('forum.php?mod=post&action=newthread&fid=$_G[fid]','_self')" class="iconfont xlmmtplsss c666">&#xe613;</i>
	</span>
			                     <span class="sf-tools " style="margin-top:2px;margin-right:12px;height:45px; line-height:45px; position:relative;">		
	<i onclick="window.open('home.php?mod=space&do=notice','_self')" class="iconfont xlmmtpls c666">&#xe60f;</i>{if $_G[member][newprompt] || $_G[member][newpm]}{eval $newxx = $_G[member][newpm] + $_G[member][newprompt];}<span class="top_message_count" style="left:12px; top:8px">$newxx</span>{/if}
	  </span>
			                     <span class="sf-tools " style="margin-top:0.3px;margin-right:12px">		
	<i onclick="window.open('search.php?mod=forum','_self')" class="iconfont xlmmtplss c666">&#xe702;</i>
	  </span>
	{else}
                     <span class="sf-tools back-menu" style="position:relative">		
<i class="iconfont head-icon c666"></i></span>
   {/if}
       <script>
          (function($){
     $(function(){$(".back-menu").click(function(){var top =$(".sf-header").offset().top;$(".back-menu-con").toggle();})
                $(".back-menu").click(function(event){var e=window.event || event;if(e.stopPropagation){e.stopPropagation();}else{e.cancelBubble = true;}
                });$(document).click(function(){$(".back-menu-con").hide();})
  $(window).bind("scroll resize",function(){if($(window).scrollTop()>0){$(".back-menu-con").hide();}
                })
            })
})(jQuery)
 </script>
   <div class="back-menu-con" style="display:none;">
          <a href="./" title="����_��ҳ">վ����ҳ</a>
            <a href=" $_G['cache']['plugin']['xlmmappgl']['xlmmappglrtt']" title="����_��Ѷ">ͷ����Ѷ</a>
            <a href="forum.php?forumlist=1&amp;mobile=2" title="����_����">������̳</a>
            <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" title="������_�Ҽҡ�">��������</a>
             {if $_G['uid']}{if $_G[member][newprompt] || $_G[member][newpm]}{eval $newxx = $_G[member][newpm] + $_G[member][newprompt];}{/if}<a href="home.php?mod=space&do=pm" title="����_��Ϣ">��Ϣ����<em style="color:red">$newxx</em></a>{else}{/if}
                       {if $_G['basescript'] == 'forum' && CURMODULE == 'viewthread'}
   <a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">��������</a>
 <a href="forum.php?mod=forumdisplay&fid=$_G[fid]" title="������_�����б���">�����б�</a>
   {/if}
</div>
        
        </div>
</div>
  <div class="sf-headercolor xlmmftpcl"></div>
                     {if  $_G['basescript'] == 'forum' && CURMODULE == 'forumdisplay' }
 {else}
<div class="xlmmh48" style="height:48px"></div>
 {/if}

{/if}



