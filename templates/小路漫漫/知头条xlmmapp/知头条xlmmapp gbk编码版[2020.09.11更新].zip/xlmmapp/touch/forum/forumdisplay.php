<?php exit;?>
<!--{template common/header}-->
  <script src="template/xlmmapp/m-img/jquery.ias.min.js" type="text/javascript"></script>
 <script src="template/xlmmapp/m-img/mb.js?{VERHASH}" charset="{CHARSET}"></script>
<script>var formhash = '{FORMHASH}', allowrecommend = '1';</script>
<script src="template/xlmmapp/m-img/fav.js?{VERHASH}" charset="{CHARSET}"></script>


 <style>
/* �б� */
.xlmmftpcl{background: #fff !important;}
.sf-header{ background:none; color:#FFF}
.sf-header .c666 {color: #fff !important; fill:#fff !important;}
.iconfont.xlmmtpls { font-size: 23px;width: 22px;  font-weight: bolder }
.iconfont.xlmmtplss { font-size: 28px;width: 22px;  font-weight:600 }
.iconfont.xlmmtplsss { font-size: 21px;width: 22px;  font-weight:600; display:inline-block;  }
/* forum list-icn */
.xlmmlcollect {position: relative;width:100%; }
.xlmmlcollects {position: absolute; top:60px; width:100%; height:100%; z-index:1;}
.light_forum_top_area {padding: 15px 15px 0 20px; }
.forum_portrait {float: left;margin-right: 12px;width: 60px;height: 60px;background-repeat: no-repeat;background-size: contain;}
.forum-name {color: #ffffff;font-size: 18px;line-height: 18px;margin-top: 3px;}
.forum-name-txt {vertical-align: middle;}
.function-area {margin: 0 1px 0 0;display: -webkit-box;}
.info_paragraph {margin: 12px 0 0;line-height: 16px;font-size: 16px;height: 16px;overflow: hidden;word-break: break-all;}
.info_label {color: #fff;margin: 0 4px 0 12px;}
.info_label:first-child {margin-left: 0;}
.info_value {color: #fff;}
.scale-1px {position: relative;margin-bottom: 20px;border: 0;}
a.operation_right_btn {position: absolute;top: 30px;right: 17px;margin-left: -60px;color: #fff;font-size: 13px;outline: 0;padding: 8px 16px;-webkit-tap-highlight-color: transparent;border-radius: 20px;background: #ff594a; text-decoration:none}
a.operation_right_btn i{margin-right:5px;}

  .xlmmlcollectbg{font-size:0;position:relative;overflow:hidden;height:234px;width:100%;border-bottom:1px solid rgba(0,0,0,.1)}
.xlmmlcollectnd:after{content:"";position:absolute;top:0;left:0;z-index:1;opacity:.4;background-color:#000;width:100%;height:100%;pointer-events:none}
.xlmmlcollectimg{width:100%;height:100%;position:absolute;-webkit-transform:scale(3);transform:scale(3);-webkit-filter:blur(4.62963vw);-moz-filter:blur(4.62963vw);-ms-filter:blur(4.62963vw);filter:blur(4.62963vw)}

.xlmmlcollectsbz {padding:30px 0 0 0; color:#fff; height:22px; line-height:22px; font-size:16px;}
.xlmmlcollectsbz span, .xlmmlcollectsbz a { float:left; margin-right:10px;display:block;}
.xlmmlcollectsbzs {width:22px; height:22px; }
.xlmmlcollectsbzs img{width:100%; height:100%;border-radius:30px;}


.xlmmforuml{margin-top: -25px;position: relative;z-index: 2;background-color: #fff; border-radius: 18px 18px 0 0;padding-top: 15px;}
.xlmmforuml-nav { position:relative;width: 100%;height: 36px; line-height:36px;text-align: left;opacity: 1;background-color: #fff;-webkit-backface-visibility: hidden;-webkit-tap-highlight-color: transparent;-webkit-transform-style: preserve-3d;}
.xlmmforuml-nav .swiper-slide {width: auto;}
.xlmmforuml-nav .swiper-slide .xlmmtsnav{display: inline-block;font-size: 16px;color: #888;margin:0 0 0 20px; position:relative}
.xlmmforuml-nav .swiper-slide.active .xlmmtsnav {color: #222;margin-top:-2px; font-size:20px}
.xlmmforuml-nav .swiper-slide.active .xlmmtsnav em {position: absolute;bottom:-2px;left: 50%;margin-left: -10px;width: 20px; height: 3px; border-radius: 6px;background: #237ffd;}

.xlmmpxr{display:flex;align-items:center;background:rgba(0,0,0,.04);border-radius:30px;padding:4px}
.xlmmpxr .xlmmpxr1{font-weight:400;font-size:13px;line-height:14px;color:#828080;padding:5px 9px}
.xlmmpxr .xlmmpxr1.pxactive{color:#ff594a;font-weight:600;background:#fff;border-radius:30px}

.sf-header {background-color:none !important;}
.sf-headercolor {width:0px;height:0px;overflow:hidden; color:#666;}
/* �ö� */
.xlmmzdzt .xlmmhd1tit{ padding:10px 0;}
.xlmmzdzt li a {coverflow: hidden; text-overflow: ellipsis;white-space: nowrap;}
</style>


<div class="xlmmappht-innercolor xlmmftpcl"></div>
<div class="xlmmlcollect">
	<div class="xlmmlcollectbg" >
		<div class="xlmmlcollectnd">
			<img class="xlmmlcollectimg" src="<!--{if $_G[forum][icon]}-->data/attachment/common/$_G['forum']['icon']<!--{else}-->static/image/common/forum.gif<!--{/if}-->">
			</div>
		</div>
<div class="xlmmlcollects">
<div class="light_forum_top_area cl">
<div class="forum_portrait" style="background-image:url(<!--{if $_G[forum][icon]}-->data/attachment/common/$_G['forum']['icon']<!--{else}-->static/image/common/forum.gif<!--{/if}-->); border-radius:10px;    box-shadow: 0 0 0 0.55556vw #fff;">
</div>
<p class="forum-name">
<span class="forum-name-txt">{$_G['forum']['name']}</span>
</p>
<div class="function-area">
<p class="info_paragraph">
<span class="info_label">����</span><span class="info_value">$_G[forum][threads]</span><span class="info_label">����</span>
<span class="info_value">$_G[forum][posts]</span>
</p>
  </div>
         	           <!--{eval $xlmmlk=DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$_G[forum]['fid']."");}--> 
<!--{if $xlmmlk[id]}--><a href="home.php?mod=spacecp&amp;ac=favorite&amp;op=delete&amp;type=forum&amp;formhash={FORMHASH}&amp;favid=$xlmmlk[favid]&amp;handlekey=forum_fav" class="dialog xlmmfygz xlmm_forum_fav_$_G[forum]['fid'] scale-1px operation_right_btn collect-button circle40" xlmm="handle">�ѹ�ע</a><!--{else}--><a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[forum]['fid']&formhash={FORMHASH}&handlekey=forum_fav" class="dialog xlmmfwgz xlmm_forum_fav_$_G[forum]['fid'] scale-1px operation_right_btn collect-button circle40" xlmm="handle">+ ��ע</a><!--{/if}-->
	<!--{eval $xlmmbz = DB::fetch_all("SELECT a.uid,b.username FROM ".DB::table('forum_moderator')." a LEFT JOIN ".DB::table("common_member")." b on a.uid=b.uid WHERE `fid`= $_G[fid]");}-->
    <div class="xlmmlcollectsbz cl">
<span>�������:</span> 
<!--{if $xlmmbz}-->
 <!--{loop $xlmmbz $xlmmbzs}--><a href="home.php?mod=space&uid=$banzhu[uid]" class="xlmmlcollectsbzs"><img src="uc_server/avatar.php?uid=$xlmmbzs[uid]&size=small"></a> <!--{/loop}--><!--{else}--><span onClick="window.open('$_G['cache']['plugin']['xlmmappgl']['xlmmappglrbzsq']','_self')">�������>></span><!--{/if}-->               

</div>


</div>
</div>
</div>
<div class="xlmmforuml">
<!--{hook/forumdisplay_top_mobile}-->
<div id="fss"></div>
<div class="xlmmlipr15" style="height:28px">
<div id="s1" class="xlmmforuml-nav swhotabs">
<ul class="swiper-wrapper">      
<li class="swiper-slide{if $_GET['filter'] == 'lastpost' || $_GET['filter'] == 'heat' || $_GET['filter'] == 'hot' || $_GET['filter'] == 'digest'}{else} active swiper-slide-active{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xlmmtsnav">ȫ��<em></em></a></li>
<li class="swiper-slide{if $_GET['filter'] == 'lastpost'} active swiper-slide-active{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xlmmtsnav">{lang latest}<em></em></a></li>
      <li class="swiper-slide{if $_GET['filter'] == 'heat'} active swiper-slide-active{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xlmmtsnav">{lang order_heats}<em></em></a></li>
 						     <li class="swiper-slide{if $_GET['filter'] == 'hot'} active swiper-slide-active{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=hot" class="xlmmtsnav">{lang hot_thread}<em></em></a></li>
 						     <li class="swiper-slide{if $_GET['filter'] == 'digest'} active swiper-slide-active{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xlmmtsnav">{lang digest_posts}<em></em></a></li>
 						   </ul>
</div>

</div>
</div>
<div class="white p020 cl" style="line-height:40px; font-size:14px;color: rgba(0,0,0,.8); padding-top:15px">
<div class="z">
��������
</div>
<div class="xlmmpxr y">
<a class="xlmmpxr1 " href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang list_post_time}</a>
<a class="xlmmpxr1 " href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang replies}</a>
<a class="xlmmpxr1" href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang views}</a>
</div>
</div>
 <div class="xlmmzdzt white  p020">
				<!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
<a <!--{if empty($announcement['type'])}--> href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]" <!--{else}--> href="$announcement[message]"<!--{/if}--> class="xlmmhd1tit m0 cl block bbf3">
  <span class="xlmmtithd1">����</span>
<ul class="xlmmggbs">
    <li><span class="xlmmhd1tita">$announcement[subject]</span></li>
</ul>
</a>
				<!--{/if}-->
				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
               	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
			<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
										<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
 <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] class="xlmmhd1tit bbf3 m0 cl block">
  <span class="xlmmtithd1">�ö�</span>
<ul class="xlmmggbs">
    <li><span class="xlmmhd1tita">{$thread[subject]}</span></li>
</ul>
</a>
					<!--{/if}-->
<!--{/loop}--> 
</div>
               <!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
	<!-- ������� start -->
      <style> 
.xlmmflnavs {}
.xlmmflnavs-list ul li {float: left;margin-right: 10px;margin-top:5px;font-size: 14px;}
.xlmmflnavs-list ul {}
.xlmmflnavs-list ul li a {display: inline-block;color: #222222;background-color: #f5f5f5; padding:5px 10px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;}
.xlmmflnavs-list ul li.a a {color: #0f88eb;}
.xlmmflnavs-list ul li span { color:red; margin-left:2px; display:none;}

		      </style> 
<div class="xlmmflnavs cl white p020 mt20" style="padding-top:5px; "> 
                  <div class="xlmmflnavs-list" >
            <ul>
                                    <li {if !$_GET['typeid'] && !$_GET['sortid']}class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">ȫ��</a></li>
           						<!--{if $_G['forum']['threadtypes']}-->
							<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
												<!--{if $_GET['typeid'] == $id}-->
				<li class="a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[typeid][$id]}--><span>($showthreadclasscount[typeid][$id])</span><!--{/if}--></a></li>
                								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[typeid][$id]}--><span>$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
						<!--{/if}-->
        							<!--{/loop}-->
						<!--{/if}-->
						<!--{if $_G['forum']['threadsorts']}-->
    							<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
														<!--{if $_GET['sortid'] == $id}-->
		<li class="a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[sortid][$id]}--><span>($showthreadclasscount[sortid][$id])</span><!--{/if}--></a></li>								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[sortid][$id]}--><span>$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
								<!--{/if}-->

							<!--{/loop}-->
						<!--{/if}-->
 </ul>
          </div>
                        </div>
 	<!-- ������� end -->
   <!--{/if}-->

	<!--{if $subexists && $_G['page'] == 1}-->
      <style>
.boards-block {overflow: hidden;}
.boards-title {padding:15px 0 10px 0;}
.boards-title-text {font-size: 16px;font-weight: 500;color: #333;}
.boards-container {display: flex;flex-wrap: wrap; padding-bottom:7px}
.boards-container .f-link {display: block;width: 50%;margin-bottom: 8px;}
.li-board {margin: 5px;background: #fff;display: flex;align-items: center;margin:0 4px;height: 88px;/*box-shadow: rgb(239, 239, 239) 0px 2px 9px 0px;border-top-left-radius: 4px;border-top-right-radius: 4px;border-bottom-right-radius: 4px;border-bottom-left-radius: 4px;*/ border:1px solid #f3f3f3}
.f-flex-img {display: flex;justify-content: center;align-items: center;overflow: hidden;background: #f2f4fa;}
.flex-none {flex: none;}
.li-board-icon {width: 44px;height: 44px;border-radius: 50%;background-color: #ebebeb;margin: 0 10px;}
.li-board-icon img{ height:100%;}
.li-board-left {position: relative;height: 100%;flex: auto;margin-right: 10px;}
.li-board-left-layer {position: absolute;top: 0;left: 0;width: 100%;height: 100%;display: flex;flex-direction: column;justify-content: center;}
.ellipsis-line-1 {overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}
.li-board-title{height: 20px;font-size: 14px;line-height: 20px;font-weight: 400;color: #666;}
.li-board-num {height: 18px;font-size: 13px;line-height: 18px;font-weight: 400;color: #aeaeae;display: inline-flex;align-items: center;}
.li-board-num img {width: 13px;margin-right: 4.5px;}
</style>
  <div class="boards-block white p020">
   <div class="boards-title">
    <span class="boards-title-text skeleton-blk">�Ӱ��</span>
   </div> 
   <div class="boards-container">
  			<!--{loop $sublist $sub}-->
			<!--{eval $forumurl = !empty($sub['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$sub['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$sub['fid'];}-->
  <div class="f-link " >
     <div class="li-board">
      <div class="f-flex-img li-board-icon flex-none ">
<!--{if $sub[icon]}-->
						$sub[icon]
					<!--{else}-->
						<a href="$forumurl"><img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" alt="$sub[name]" /></a>
					<!--{/if}-->
      </div> 
      <div class="li-board-left">
       <a href="$forumurl" class="li-board-left-layer">
        <div class="li-board-title ellipsis-line-1 skeleton-blk">
        $sub[name]
        </div> 
        <div class="li-board-num skeleton-blk">
         <img src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4NCjxzdmcgd2lkdGg9IjEycHgiIGhlaWdodD0iMTJweCIgdmlld0JveD0iMCAwIDEyIDEyIiB2ZXJzaW9uPSIxLjEiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPg0KICAgIDwhLS0gR2VuZXJhdG9yOiBTa2V0Y2ggNTAuMiAoNTUwNDcpIC0gaHR0cDovL3d3dy5ib2hlbWlhbmNvZGluZy5jb20vc2tldGNoIC0tPg0KICAgIDx0aXRsZT7lr7nor508L3RpdGxlPg0KICAgIDxkZXNjPkNyZWF0ZWQgd2l0aCBTa2V0Y2guPC9kZXNjPg0KICAgIDxkZWZzPjwvZGVmcz4NCiAgICA8ZyBpZD0iUGFnZS0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4NCiAgICAgICAgPGcgaWQ9Iuadv+Wdl+mmlumhtS3kuIvmi4nlvLnlh7ot5oiR55qE5YWz5rOo5p2/5Z2XLWNvcHktMiIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoLTI1NC4wMDAwMDAsIC0zMzEuMDAwMDAwKSIgZmlsbC1ydWxlPSJub256ZXJvIj4NCiAgICAgICAgICAgIDxnIGlkPSJHcm91cC00IiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtODQuMDAwMDAwLCAtMTE0LjAwMDAwMCkiPg0KICAgICAgICAgICAgICAgIDxnIGlkPSLlr7nor50iIHRyYW5zZm9ybT0idHJhbnNsYXRlKDMzOC4wMDAwMDAsIDQ0NC4wMDAwMDApIj4NCiAgICAgICAgICAgICAgICAgICAgPHJlY3QgaWQ9IlJlY3RhbmdsZS1wYXRoIiBmaWxsPSIjMDAwMDAwIiBvcGFjaXR5PSIwIiB4PSIwIiB5PSIwIiB3aWR0aD0iMTIiIGhlaWdodD0iMTIiPjwvcmVjdD4NCiAgICAgICAgICAgICAgICAgICAgPHBhdGggZD0iTTUuOTgyMzQyODYsMS41MDAzNDI4NiBDNi43MTAzNDI4NiwxLjQ5MjM0Mjg2IDcuMzk0MzQyODYsMS42MjQzNDI4NiA4LjAzNDM0Mjg2LDEuODk2MzQyODYgQzguNjc0MzQyODYsMi4xNjgzNDI4NiA5LjIzNjM0Mjg2LDIuNTM4MzQyODYgOS43MjAzNDI4NiwzLjAwNjM0Mjg2IEMxMC4yMDQzNDI5LDMuNDc0MzQyODYgMTAuNTg2MzQyOSw0LjAyNjM0Mjg2IDEwLjg2NjM0MjksNC42NjIzNDI4NiBDMTEuMTQ2MzQyOSw1LjI5ODM0Mjg2IDExLjI5MDM0MjksNS45ODAzNDI4NiAxMS4yOTgzNDI5LDYuNzA4MzQyODYgQzExLjMwNjM0MjksNy4zOTYzNDI4NiAxMS4xODgzNDI5LDguMDQ0MzQyODYgMTAuOTQ0MzQyOSw4LjY1MjM0Mjg2IEMxMC43MDAzNDI5LDkuMjYwMzQyODYgMTAuMzYwMzQyOSw5Ljc5ODM0Mjg2IDkuOTI0MzQyODYsMTAuMjY2MzQyOSBDOS40ODgzNDI4NiwxMC43MzQzNDI5IDguOTc2MzQyODYsMTEuMTIwMzQyOSA4LjM4ODM0Mjg2LDExLjQyNDM0MjkgQzcuODAwMzQyODYsMTEuNzI4MzQyOSA3LjE2NjM0Mjg2LDExLjkxNjM0MjkgNi40ODYzNDI4NiwxMS45ODgzNDI5IEM2LjMxMDM0Mjg2LDEyLjAxMjM0MjkgNi4xMjIzNDI4NiwxMi4wMzIzNDI5IDUuOTIyMzQyODYsMTIuMDQ4MzQyOSBDNS43MjIzNDI4NiwxMi4wNjQzNDI5IDUuNTAwMzQyODYsMTIuMDc2MzQyOSA1LjI1NjM0Mjg2LDEyLjA4NDM0MjkgQzUuMDEyMzQyODYsMTIuMDkyMzQyOSA0Ljc0MDM0Mjg2LDEyLjA5MjM0MjkgNC40NDAzNDI4NiwxMi4wODQzNDI5IEM0LjE0MDM0Mjg2LDEyLjA3NjM0MjkgMy44MDIzNDI4NiwxMi4wNTIzNDI5IDMuNDI2MzQyODYsMTIuMDEyMzQyOSBDMi41OTQzNDI4NiwxMS45MzIzNDI5IDEuOTc2MzQyODYsMTEuODI4MzQyOSAxLjU3MjM0Mjg2LDExLjcwMDM0MjkgQzEuMTY4MzQyODYsMTEuNTcyMzQyOSAxLjAwNjM0Mjg2LDExLjUwMDM0MjkgMS4wODYzNDI4NiwxMS40ODQzNDI5IEMxLjUxMDM0Mjg2LDExLjQxMjM0MjkgMS44NzQzNDI4NiwxMS4yOTYzNDI5IDIuMTc4MzQyODYsMTEuMTM2MzQyOSBDMi4zMzgzNDI4NiwxMS4wNDgzNDI5IDIuNDA0MzQyODYsMTAuOTIyMzQyOSAyLjM3NjM0Mjg2LDEwLjc1ODM0MjkgQzIuMzQ4MzQyODYsMTAuNTk0MzQyOSAyLjI3MDM0Mjg2LDEwLjQ0MDM0MjkgMi4xNDIzNDI4NiwxMC4yOTYzNDI5IEMxLjczNDM0Mjg2LDkuODQ4MzQyODYgMS40MDQzNDI4Niw5LjMyNjM0Mjg2IDEuMTUyMzQyODYsOC43MzAzNDI4NiBDMC45MDAzNDI4NTcsOC4xMzQzNDI4NiAwLjc2NjM0Mjg1Nyw3LjQ5MjM0Mjg2IDAuNzUwMzQyODU3LDYuODA0MzQyODYgQzAuNzQyMzQyODU3LDYuMDc2MzQyODYgMC44NzQzNDI4NTcsNS4zOTIzNDI4NiAxLjE0NjM0Mjg2LDQuNzUyMzQyODYgQzEuNDE4MzQyODYsNC4xMTIzNDI4NiAxLjc5MDM0Mjg2LDMuNTUyMzQyODYgMi4yNjIzNDI4NiwzLjA3MjM0Mjg2IEMyLjczNDM0Mjg2LDIuNTkyMzQyODYgMy4yOTAzNDI4NiwyLjIxMjM0Mjg2IDMuOTMwMzQyODYsMS45MzIzNDI4NiBDNC41NzAzNDI4NiwxLjY1MjM0Mjg2IDUuMjU0MzQyODYsMS41MDgzNDI4NiA1Ljk4MjM0Mjg2LDEuNTAwMzQyODYgWiBNOC4zMjIzNDI4Niw2Ljc4MDM0Mjg2IEM4LjMyMjM0Mjg2LDYuOTg4MzQyODYgOC4zOTQzNDI4Niw3LjE2NjM0Mjg2IDguNTM4MzQyODYsNy4zMTQzNDI4NiBDOC42ODIzNDI4Niw3LjQ2MjM0Mjg2IDguODU4MzQyODYsNy41MzYzNDI4NiA5LjA2NjM0Mjg2LDcuNTM2MzQyODYgQzkuMjc0MzQyODYsNy41MzYzNDI4NiA5LjQ1MjM0Mjg2LDcuNDYyMzQyODYgOS42MDAzNDI4Niw3LjMxNDM0Mjg2IEM5Ljc0ODM0Mjg2LDcuMTY2MzQyODYgOS44MjIzNDI4Niw2Ljk4ODM0Mjg2IDkuODIyMzQyODYsNi43ODAzNDI4NiBDOS44MjIzNDI4Niw2LjU3MjM0Mjg2IDkuNzQ4MzQyODYsNi4zOTYzNDI4NiA5LjYwMDM0Mjg2LDYuMjUyMzQyODYgQzkuNDUyMzQyODYsNi4xMDgzNDI4NiA5LjI3NDM0Mjg2LDYuMDM2MzQyODYgOS4wNjYzNDI4Niw2LjAzNjM0Mjg2IEM4Ljg1ODM0Mjg2LDYuMDM2MzQyODYgOC42ODIzNDI4Niw2LjEwODM0Mjg2IDguNTM4MzQyODYsNi4yNTIzNDI4NiBDOC4zOTQzNDI4Niw2LjM5NjM0Mjg2IDguMzIyMzQyODYsNi41NzIzNDI4NiA4LjMyMjM0Mjg2LDYuNzgwMzQyODYgWiBNNS4zMTAzNDI4Niw2Ljc4MDM0Mjg2IEM1LjMxMDM0Mjg2LDYuOTg4MzQyODYgNS4zODYzNDI4Niw3LjE2ODM0Mjg2IDUuNTM4MzQyODYsNy4zMjAzNDI4NiBDNS42OTAzNDI4Niw3LjQ3MjM0Mjg2IDUuODcwMzQyODYsNy41NDgzNDI4NiA2LjA3ODM0Mjg2LDcuNTQ4MzQyODYgQzYuMjk0MzQyODYsNy41NDgzNDI4NiA2LjQ3NjM0Mjg2LDcuNDcyMzQyODYgNi42MjQzNDI4Niw3LjMyMDM0Mjg2IEM2Ljc3MjM0Mjg2LDcuMTY4MzQyODYgNi44NDYzNDI4Niw2Ljk4ODM0Mjg2IDYuODQ2MzQyODYsNi43ODAzNDI4NiBDNi44NDYzNDI4Niw2LjU2NDM0Mjg2IDYuNzcyMzQyODYsNi4zODIzNDI4NiA2LjYyNDM0Mjg2LDYuMjM0MzQyODYgQzYuNDc2MzQyODYsNi4wODYzNDI4NiA2LjI5NDM0Mjg2LDYuMDEyMzQyODYgNi4wNzgzNDI4Niw2LjAxMjM0Mjg2IEM1Ljg3MDM0Mjg2LDYuMDEyMzQyODYgNS42OTAzNDI4Niw2LjA4NjM0Mjg2IDUuNTM4MzQyODYsNi4yMzQzNDI4NiBDNS4zODYzNDI4Niw2LjM4MjM0Mjg2IDUuMzEwMzQyODYsNi41NjQzNDI4NiA1LjMxMDM0Mjg2LDYuNzgwMzQyODYgWiBNMi4zMzQzNDI4Niw2Ljc2ODM0Mjg2IEMyLjMzNDM0Mjg2LDYuOTc2MzQyODYgMi40MDgzNDI4Niw3LjE1NjM0Mjg2IDIuNTU2MzQyODYsNy4zMDgzNDI4NiBDMi43MDQzNDI4Niw3LjQ2MDM0Mjg2IDIuODgyMzQyODYsNy41MzYzNDI4NiAzLjA5MDM0Mjg2LDcuNTM2MzQyODYgQzMuMzA2MzQyODYsNy41MzYzNDI4NiAzLjQ4ODM0Mjg2LDcuNDYwMzQyODYgMy42MzYzNDI4Niw3LjMwODM0Mjg2IEMzLjc4NDM0Mjg2LDcuMTU2MzQyODYgMy44NTgzNDI4Niw2Ljk3NjM0Mjg2IDMuODU4MzQyODYsNi43NjgzNDI4NiBDMy44NTgzNDI4Niw2LjU2MDM0Mjg2IDMuNzg0MzQyODYsNi4zODIzNDI4NiAzLjYzNjM0Mjg2LDYuMjM0MzQyODYgQzMuNDg4MzQyODYsNi4wODYzNDI4NiAzLjMwNjM0Mjg2LDYuMDEyMzQyODYgMy4wOTAzNDI4Niw2LjAxMjM0Mjg2IEMyLjg4MjM0Mjg2LDYuMDEyMzQyODYgMi43MDQzNDI4Niw2LjA4NjM0Mjg2IDIuNTU2MzQyODYsNi4yMzQzNDI4NiBDMi40MDgzNDI4Niw2LjM4MjM0Mjg2IDIuMzM0MzQyODYsNi41NjAzNDI4NiAyLjMzNDM0Mjg2LDYuNzY4MzQyODYgWiIgaWQ9IlNoYXBlIiBmaWxsPSIjQUVBRUFFIj48L3BhdGg+DQogICAgICAgICAgICAgICAgPC9nPg0KICAgICAgICAgICAgICAgIDxyZWN0IGlkPSJSZWN0YW5nbGUtMjUtQ29weSIgc3Ryb2tlPSIjRkYwMDAwIiBzdHJva2Utd2lkdGg9IjQiIHRyYW5zZm9ybT0idHJhbnNsYXRlKDEyNjIuMDAwMDAwLCA0NDcuNTAwMDAwKSBzY2FsZSgxLCAtMSkgdHJhbnNsYXRlKC0xMjYyLjAwMDAwMCwgLTQ0Ny41MDAwMDApICIgeD0iMiIgeT0iMiIgd2lkdGg9IjI1MjAiIGhlaWdodD0iODkxIj48L3JlY3Q+DQogICAgICAgICAgICA8L2c+DQogICAgICAgIDwvZz4NCiAgICA8L2c+DQo8L3N2Zz4=" /> {echo dnumber($sub[threads])}
        </div>
       </a>
      </div>
     </div></div>
			<!--{/loop}-->
   </div>
  </div>
  					<!--{/if}-->
 		<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->

		<!--{if $_G['forum_threadcount']}-->
<ul class="xlmmbw cl" id="alist">
				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
               	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
			<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
										<!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
			{eval include TPLDIR.'/php/img.php';}
					<!--{hook/forumdisplay_thread_mobile $key}-->
<li class="alist note-flow p020{if $xlmmal >0} have-img{/if} border0 m0 white">
         <div class="forumalist p150 bbf3">
           <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" >
<h6 class="title" $thread[highlight]>
   $thread[subject]
	</h6>
<span class="xlmmcont">
{if $xlmmal >0}
     <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
     					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment'] ; }
		<!--{/if}-->
<span class="wrap-img inline-3MDdF_0" style="width: 85px; height: 65px;"><img src="$xlmmimg"></span>
          	 <!--{eval $i++}-->
<!--{eval if($i==1) break;}-->
<!--{/loop}--> 
{/if}
<div class="summary">
	<div class="author" style="padding-right:0">
     		<div class="avatar">
   <img src="uc_server/avatar.php?uid=$thread[authorid]&amp;size=middle">
	</div>
    <div class="name">
        $thread[author]
	</div>
	</div>
<p class="abstract">
 $xiaolu['fmessage']
	</p>
</div>
</span>
</a>
<div class="meta oneline">
<span>$thread[views] �����</span>&nbsp;&nbsp;<span style="font-size:18px; ">��</span>&nbsp;&nbsp;<span class="name">$thread[replies] ������</span>{if $xlmmal >0}{else}&nbsp;&nbsp;<span style="font-size:18px; ">��</span>&nbsp;&nbsp;<span class="name">$thread[dateline]</span>{/if}
</div>
</div>
</li>
			<!--{/if}-->
<!--{/loop}--> 
    </ul>
  <div id="xlmmpg" class="none xlmmpg">$multipage</div>
       <div class="ias-spinners xlmmdjjz" style="text-align: center;line-height:40px;color: #999; display:none">������ظ���</div>
<div class="ias-spinners xlmmzdjz" style="text-align: center;line-height:40px;color: #999; display:none">������...</div>
<div class="ias-spinnerns xlmmjzwc" style=" text-align:center; line-height:40px;color: #999; display:none">������</div>
    <!--{else}-->
	<div style="text-align:center; background:#FFFFFF; padding-bottom:20px;"><svg width="150" height="120" viewBox="0 0 150 120" class="Topstory-newUserFollowCountPanelIcon" fill="currentColor"><g fill="none" fill-rule="evenodd"><path fill="#EBEEF5" d="M44 31.005v55.99A3.003 3.003 0 0 0 47.003 90h53.994A3.005 3.005 0 0 0 104 86.995v-55.99A3.003 3.003 0 0 0 100.997 28H47.003A3.005 3.005 0 0 0 44 31.005zm-3 0A6.005 6.005 0 0 1 47.003 25h53.994A6.003 6.003 0 0 1 107 31.005v55.99A6.005 6.005 0 0 1 100.997 93H47.003A6.003 6.003 0 0 1 41 86.995v-55.99z" fill-rule="nonzero"></path><path fill="#F7F8FA" d="M59 50a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 40.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5zM59 73a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 63.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5z"></path></g></svg><div style="font-size: 15px;color: grey;">��û���κ�����Ŷ</div></div>	
		<!--{/if}-->
        <!--{else}-->

<style>
.xlmmpbls{position:relative;  margin:0 14px }
.xlmmpbls > .xlmmpblsit{width:50%; float:left; min-height:80px}
.xlmmpblsit-wraper {    margin: 5px 6px 0; border-radius: 3px;
    box-sizing: border-box;border: 1px solid #efefef}
.xlmmpblsit-wraper > img{width: 100%;}
.xlmmpblsit-wraper h2 { padding: 6px 8px;line-height: 24px;height:22px; font-size: 16px; overflow:hidden;display: -moz-box;display: -webkit-box; -moz-box-orient: vertical;  -webkit-box-orient: vertical;-webkit-line-clamp: 1; }
.xlmmpblsit-wraper p {padding: 0 8px 9px;height: 18px;line-height: 18px;font-size: 12px;}
.xlmmpblsit-wraper p a {float: left;font-size: 12px;}
.xlmmpblsit-wraper p a img { float: left;width: 18px;height: 18px;margin-right: 5px;border-radius: 50%;}
</style>


<div class="white">


        <ul id="alist" class="xlmmpbls cl">
      							<!--{loop $_G['forum_threadlist'] $key $thread}-->
							<!--{if $_G['hiddenexists'] && $thread['hidden']}-->
								<!--{eval continue;}-->
							<!--{/if}-->
							<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
								<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
							<!--{/if}-->
     <li class="alist xlmmpblsit">
                <div class="xlmmpblsit-wraper">
              										<!--{if $thread['cover']}-->
  <span class="nimgd" style=" vertical-align: middle; font-size: 0px;width: 100%;position: relative; padding-top: 90%;background-size: cover;background-color: #ededed;background-repeat: no-repeat; background-size: cover; display: inline-block; background-image: url(&quot;$thread[coverpath]&quot;);">  </span>
    										<!--{else}-->
  <span class="nimgd" style=" vertical-align: middle; font-size: 0px;width: 100%;position: relative; padding-top: 90%;background-size: cover;background-color: #ededed;background-repeat: no-repeat; background-size: cover; display: inline-block; background-image: url(&quot;template/xlmmapp/m-img/nopic.gif&quot;);">  </span>
										<!--{/if}-->
      <h2> <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] >{$thread[subject]}</a></h2>
<p>
<span class="y">��� $thread[views]</span>
<a href="home.php?mod=space&uid=$thread[authorid]">{avatar($thread[authorid],small)}$thread[author]</a>
</p>
     </div>
            </li>
						<!--{/loop}-->


        </ul>
  <div id="xlmmpg" class="none xlmmpg">$multipage</div>
<div class="ias-spinners xlmmdjjz" style="text-align: center;line-height:40px;color: #999; display:none">������ظ���</div>
<div class="ias-spinners xlmmzdjz" style="text-align: center;line-height:40px;color: #999; display:none; margin-top:6px"><img src="data:image/gif;base64,R0lGODlhKAAoAMQcAPT09Nvb29zc3N3d3d7e3vPz8+vr69/f3+np6erq6vHx8e3t7ejo6ODg4Ozs7O/v7+Tk5O7u7uPj4/Dw8OLi4uXl5fLy8ufn5+Hh4ebm5tra2vX19f///wAAAAAAAAAAACH/C05FVFNDQVBFMi4wAwEAAAAh/wtYTVAgRGF0YVhNUDw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMDY3IDc5LjE1Nzc0NywgMjAxNS8wMy8zMC0yMzo0MDo0MiAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpjMmRjMTYzOS1kZWNiLTQ1MTUtOWU4Mi1lOTM0ZjkxMzMyZTUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6ODlBOEJCOUI2ODQ5MTFFN0IwRTU5OEVBOEM4NTdGNTMiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6ODlBOEJCOUE2ODQ5MTFFN0IwRTU5OEVBOEM4NTdGNTMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIDIwMTUgKE1hY2ludG9zaCkiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo5ODQwNzNiZS04N2RjLTQ0OGUtODJkOS0wOTNiYjljNTA1ZDciIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6YzJkYzE2MzktZGVjYi00NTE1LTllODItZTkzNGY5MTMzMmU1Ii8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+Af/+/fz7+vn49/b19PPy8fDv7u3s6+rp6Ofm5eTj4uHg397d3Nva2djX1tXU09LR0M/OzczLysnIx8bFxMPCwcC/vr28u7q5uLe2tbSzsrGwr66trKuqqainpqWko6KhoJ+enZybmpmYl5aVlJOSkZCPjo2Mi4qJiIeGhYSDgoGAf359fHt6eXh3dnV0c3JxcG9ubWxramloZ2ZlZGNiYWBfXl1cW1pZWFdWVVRTUlFQT05NTEtKSUhHRkVEQ0JBQD8+PTw7Ojk4NzY1NDMyMTAvLi0sKyopKCcmJSQjIiEgHx4dHBsaGRgXFhUUExIREA8ODQwLCgkIBwYFBAMCAQAAIfkEBQMAHAAsAAAAACgAKAAABf/gJo5kaZ5omlpJ1QyCQDSVYak4CRiN5v9AX8MAyKUMA19AgogoCgVFBCEJ+AYJY8mC8R2Iqt1BeNNGBJqBQStCagQR48JKKbBHBYom4MBFrBl3Jhl7cSgWaIGCg29lJj0Uiyh6DScJaXaSJgVJWTpJfZonDm9FI5eVoig9CCRjoaompAcjCqWxJwBoCiIIGhC4KBAarRsSGp7BJQYaEiJjD8o4aJnSKD6m1ifY2ijU3SdjE+Amx2vgzM4bvsDgFcQiE2nkSeMiBBoL3RHzIwwaGLp1YUCiABpDyvgFqCbiH4FssQDgI1gCwJgKyt49PDHBCkVVvgLYO8EMnihfGs5RpbikoQJELQDeITNiwMqBaGwejAmgT8sEfBooIEwRQY8GAiNhXrByNIMDXrUcZAAagMFLNgUuJAESgOmPARcYinrAgMLWPQQwXMAJrsBVIyEAACH5BAUDABwALAEAAQAmACcAAAX4ICeO5KhwECcEgYAmZynPZXLQ5IHgPJe4KojhYQEALI8EBAjslRqihsPpgIpizoBo4SRxOYEvbsqRALoyCXqNu2x5bvbMHcCW1HKa+pZnnzk7I019NGIiO3yENBiKbFwEjV0bAxwTkZeYmV0TGomaJQUaKxwbnyQAGhpapaYiqBqtoKIiD7GVnSIJtrs8An+8thsWcTtWnxvIrm+ayMmHps2sIqwpmNElMXGNDBgT0l4i2n0MyzMGItV51ec8XwOGThGUHGQ9CnwN8DMLjByeXQiADKhgYEIBEQUmGKgwD1AfAAggkUhVggC5SBMQSCAwiEKgVs7YhAAAIfkEBQMAHAAsAQABACYAJgAABbMgJ44kiXAHmZ5l675wLMcJV4i3UbKzqGC90WKU6g1FjuCIIIrMNDjlCADhQGEL6EUKc7YU3JkgHK7CAOQXszTgHNOwG6fWgEvf9tkmL6vxYRUcDGZ/hXAEbYYyaIoje1ONjiKJkSQBlS0EVTqYnS0MnqFCGmudGBo8lREaAoyYB6gldYoRsyVjfxu6LxGXebq7lcDBM6VBCwcOxDETI0BSDa5cuDJjj2FFomAjl2MSDM0zIQAh+QQFAwAcACwBAAEAJgAmAAAFmCAnjiSZlKKErmzrvnBpTNy2iWfcNuIRO7rgayBaCI8pkQGWQaI0RucxIBWqqsECsSTAer8rIPgFGLMQ5hbimkZB2q0ufE6v29Oq3H2vsMv3ezwMgAUlA4VgAFslPmxeEBoHZSVUg14MGgE0KAsaX5gaYnQUGksxizo2GwqiLn0iPDCqqkE3I6goBBa0UgQwFTZemxwBnkghACH5BAUDABwALAEAAQAmACYAAAWjICeOJImU5ISu7Hi2cBw/IsBNhgxbY6PnIp8uIhAtdCMHUhSoLUeFYfPyRGV0leqKEaNoWZCWIPpFAQgsZRlm47zW8Li8nJjLwkA7SqKHHfqAgXpFgk6EhSN/HHmIjSIIKhwbggOJjo4Yly0EbXNoYJqACjBcay9HggAQGk+fSw4EGk1VmToZGhoHkXMAG76+CAIInUtkKxC/vgXGcQeEB8k6IQAh+QQFAwAcACwBAAEAJgAmAAAFsSAnjmRpclCinGybtCQBz6X0WoD40PPKj4vR4UdyEDkL2ZFSOIoAEGLGWWLALKIpdctl5UqD7i8s5r3KsDN6zRZJ2icrRw3nGCmNemlFCGP1IwECgIQ/f4WIHHxRdHB3iSIMPl+AOyJGdREcZI1tFJAiASQvZHByI3lvbUolgxdtEzCvXXIGhRUinWyaiBEYInllGxsixA4VAxoaosROlCIFw8McAsoEp2gA0sQQDLE0IQAh+QQFAwAcACwBAAEAJgAmAAAFiyAnjiSZiEOJlGzrvuQBz1wqQmJh0jMmHobZxsErLUSCYHFZkjCf0BnxdYm6Jiyf08rtjhheWiQX5q3K6DQuzW57sW4WgCMIxO/4oi4vgvOVfIGCgy42bgJzhHEVL3aKXWczjnxjNVN4DTcbTDJQFxugm4kACoB0YFEWoaAXGq6uJIlcqxiuAQQUSyEAIfkEBQMAHAAsAQABACcAJgAABcAgJ45kyTVkI5ls675wzBmkhHDWONGya6EnBwyw6JUiooHQyBkYixwKc0qqUEkXEdRlvRpRUm+PJhBPeWZTwHRIuxgjoNuEHOXW89Zjxlnl/2eALwolhIIka2UFhyNrAIqMIo5OkRwAHGtyjISUlRxLHAl9kRkleJ6oqSIYHFkjZaBzewGLJrWqqmWqEWulqEIHGxtmNzALEcLDV2gwycJTBFTJAAcVBhO1BROmllfCCBrh4SxOt2ITCBIHuiR7MiEAIfkEBQMAHAAsAQABACYAJgAABaAgJ45kWR3jcEBl676wW8Q0mZRPXWMiSm8cHqcx0eV0LgJyyWwdM80SQ+SIWl/C60vZGmi/4PCS0jKIXd5z7aamIdqk6igCLw249bw+it/P/YCBLRZ+eA2CPXVkUyJpiABqPmVAkS0AG5hhbzCYmWFyLp1hbJwbDwcLTT6gNBQaGg2pNWQckkgJAq8CLCSQrAJXAAi2WxyQXwoieMAiRTUhACH5BAUDABwALAEAAQAmACYAAAWlICeOZCkKJydxk+m+MJwAsTwGbmvSNdmIvx7pIBQNOKiiyaFsuhKwiKjifBmq2KzWlNzGNt4iM+zCkM9ozjhNykzZpesK7jrS7/iqIq8RPfIcVICDIhcnYHB2HBkKiHgbkHeGHJCReZWOd5ZkbgQmGxYSk1tQUQEao1tXLw4aGhIFWwg1CwIaikqeHKs1CmZNv7pYuCKxvBw4WsIwR7FbOsgmfz0hACH5BAUDABwALAEAAQAmACYAAAWiICeOJIlAzVCubOu+BPK+xihw8qg87Db/QJECGLmpgsgVJsmqzTLM1uIFjVqvJQnnwDpiZ4AvMiF2UcrWG9rlXLsgbpaDc463CCKLfc/HNiAFfYEBG4V9I4U+fE6JfRUcDI2HIoaTHAAJVYcAAxptaBErCRoDgWt4Kw0aWmiPLAoCGmgMlkgBImFRcES3UVMic0ANTHVROSKuubUsqGsHalEhACH5BAUDABwALAEAAQAmACYAAAWuICeOJJmMgjA0EKeUcAwbjUwedi4nEVcUFs5pNDDoYBjRwZgDcGpHGTNaWlAp1Kx268hVtuCwrSUTiM9o2zSNZIcD7jj6K7cBCs56abDp60safRt/JYKEJIaEThqHMBUCQ39WQhoShxkiChoCeXoEIwcaXXoPJhpQjRxmo3GlqUocF6mYr5ExC4xxrDGMZGB0R5OfWg84HGs5xklbrlQGA3YKu68iCG4MFMMccFohACH5BAUDABwALAEAAQAmACYAAAWyICeO5GhxFUeUSem+cMzK9BhQyEMjdUn1I8eoAdSJhMCkUiapGZeui2ghy0Cj16xoowUOYK1uiSoAiAqXptj1G23ea9jqDY+/JnS7C7Kt60cGHBJ5fyUEEhdmhWccAQIaBYsjGhyPkZIjBBonmCINGk+YEBo8kkgibZgXnJ1DmBGtsTCssiMYf3yxpaEjEQFrYYExv6lLVj2wYqc0RFcHSwgCLpeRwiNSnQMMdmoi0t01IQAh+QQFAwAcACwBAAEAJwAnAAAF2CAnjiRpcNhIlGzrvm4Dz5xDSlykiEqESAGRIEFjpTir4qHoEpyYtQF0hLFMRQVRwEarXK+bxwHyZTF4rY26DAOU1Gs2a4UgwTfyVgQ7gudjHHUiCFl/LQskFhpShi0CHA8cBho4jSxeIhUagpYsFBwNGnudLgMaVqQjbqkvQXispRw7sFq0MES2N7lou6NLsJEknLsjiKyFxCy/lhkwQY24LwsayZLUZLvGA6NfT0oiFNwvwUhXbs8cGQ4Kq24LzYYFDIwjAegjF42Rn9QcixgXxJECsOpKCAAh+QQFAwAcACwBAAEAJwAmAAAFoyAnjmTJNSZnpWzrvnBpuGvCCeIQl5skHjvUbrTZOHRDkiACKxYBSRGUo5m1nJuo1qk1XUSTlITZTRo0yDKLUSJU1bszEJ7CcNgizJtuYqY5AVN8JX+DhnAOHD6HLmkKjJBRgpEmBCqUKWSYmyQLnCwrnw8iQp8cNqapKZOYpaY4qREBqomqIwSenGF5O4tdDLAcFS2Wg8UwoXBhPrMjFByjMSEAIfkEBQMAHAAsAQABACYAJgAABaQgJ45kWQ6jYq6suG1MSxqy/G6WYKpI7d8338FXiiiCxFJgUVsEMJxNklQgPgKaynQrymW5MlUJo8EAwCtJS2BBs1A9EQDlbjHr2wZJj7f3wQl/RBCCLTQUhUltiYyNjGKOIhoiD5EkWpYcDhxQHISZHJCgHEOjI6Wmm6YcVaumAasLkzF1cYEsNK4jEVwEIrdbdzWIHHRTcSO5I4u6hZXEJbQ+IQAh+QQFAwAcACwBAAEAJgAmAAAFpiAnjuS4nRslEmXrvhxQoGflHgmsc8bA0BuAyPLIjQS7lgWj0UCSogaU9BBoBMapdqTBFLYiIXhMLo8YO8rGTHrCvmwSKw6N0KeY+3Su3xk4Kn0uNoIlDoU6fIiLjGMDjSMBkG2TgCISlZV2mSNShZgtf32bLmJ3iiVudIQwaHGuOxlsRqI6oGOsUwMLYAcitToKJIdJoKhjxCMKyZwccIKSGBekOiEAIfkEBQMAHAAsAQABACcAJwAABZwgJ47kaCUQt61r6b6waDRarbJbrL8OVwcSxI21K4ooooMBYGySIqKBwUktIatUKHbLfV264NcgTOYuylQhqYduYyecBEfihqXkdVkeBhcR9oA7GiqBI4M5HBaFiyR/jCNCKXsVHAyMYw+LWiNTe0iWJWdtmS5qbgcwqI9ueEWgXKZGkosCHASbj7gwEVdbr6tjJIOrPhxIpHmIWCEAIfkEBQMAHAAsAQABACYAJwAABYEgJ45kyTWEIGDc5ppwLG6lZmtV626F7HMGU8RSKOpciJ9S6cpxMJblQyRwLEfBq3ZrmnK/YBkj/JWQzy30D6D+ZtswBXyuTtJH1nucJNePBH6Bglo9g4aHMBmIiyR2gReMJASHDXSKB4gTggmHilcBmZElbyUDfqCCZiOoY4E0XCEAIfkEBQMAHAAsAQABACYAJgAABb4gJ45kKQ5nAyWK6b4ikLxaXTPbBu9vyykRhGRgyel4JQyyZMwtI0uXcQLdOaKvHCZwfVUzWBc4UA2bL7CGedk4imbrXQFFAgg43fgSrt+pRwd4fYOEMXeFSBAcCG+ILgYcEiIPjiYTHAd3FpUlBSIBHACcLqCioyWHpyQCgaoil5Gusi4VryJurgQcC7mzIwyzZSV0jrrAJK2OtbqyjL7Os7UcfC9dxGt5srBRCKAj2SKQJMeINSbkhBQlzFEhACH5BAUDABwALAEAAQAmACYAAAWOICeOZFlxhJieZeu6xlseCSDfbcJZovXoAo1moMPJHDiAoyHEGEuDJ8lBWGw20qzritV6OdzuNxseazcL8/nQiqrfcJEz/hXQW2IR5N46Mfg3FIAyBG6Dh4hqhog2iS57MY6SJQoijY5sjouTnC0pkw2dgH+iaaIypp9ZEadeGwx2N0gjsa1qEhy1HLhSIQAh+QQFAwAcACwBAAEAJgAmAAAFoCAnjiRplAMHlWzrJm4szyPCKaIS2YEonDRSYwScHUa4oK+oHGgCi1lU2SpINBqmq0JtXbDTrviCmYjPos2mJUDH1Gu3Eh6X0+Amu2tjuYx6ei4pIxKBMjYciIYuR4sybY6RkpOUIgUcgJU3IoUwmp+gMw6VBKGJpgCmJUeFpn56iqFalLEto2gPpWgUShhoAAiZHAZmMQGvaLqqvMK8SiEAIfkEBQMAHAAsAQABACYAJAAABZMgJ47kqCQQN5Rs675wLMPWgwpjMpPYPjYioE/lGBqPJIAoMMsgjc7niKEJKKQ7iOZQMqiwJQBBgwDLFhqB0gyrMApBTpFd2mxGOHrdLkrpSXZ3HDp/I4FChYZ2K4kjABkNeY2TlDJrlSxemJVREyKCm5OMmAyVDyJwlFwufpulobBshC8LUqs7V0YUUpIpuS+vLSEAOw=="></div>
<div class="ias-spinnerns xlmmjzwc" style=" text-align:center; line-height:40px;color: #999; display:none">������</div>
</div>

        <!--{/if}-->

<!--{hook/forumdisplay_bottom_mobile}-->
<script>
 var xlmmapphtinnerer_bg = $(".sf-header").css("backgroundImage");
if(xlmmapphtinnerer_bg != 'none'){
$('.sf-header').css("cssText",'background:none !important');
$('.c666').css("cssText",'color:#fff !important');
}
var xlmmapphtinnerer_rgb = $(".sf-headercolor").css('background-color');
var xlmmapphtinnerer_rgbs = $(".sf-headercolor").css('color');
xlmmapphtinnerer_rgbs = xlmmapphtinnerer_rgbs.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
xlmmapphtinnerer_rgb = xlmmapphtinnerer_rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
$(window).scroll(function() {
 if($(window).scrollTop() > 100){
if(xlmmapphtinnerer_bg == 'none'){
$('.sf-header').attr('style', 'background-color:rgba('+xlmmapphtinnerer_rgb[1]+','+xlmmapphtinnerer_rgb[2]+','+xlmmapphtinnerer_rgb[3]+',1) !important');
$('.c666').attr('style', 'color:rgba('+xlmmapphtinnerer_rgbs[1]+','+xlmmapphtinnerer_rgbs[2]+','+xlmmapphtinnerer_rgbs[3]+',1) !important');
}
}else{
var i = $(window).scrollTop() / 100;
if(xlmmapphtinnerer_bg == 'none'){
$('.c666').attr('style', 'color:rgba('+xlmmapphtinnerer_rgbs[1]+','+xlmmapphtinnerer_rgbs[2]+','+xlmmapphtinnerer_rgbs[3]+',1) !important');
$('.sf-header').attr('style', 'background-color:rgba('+xlmmapphtinnerer_rgb[1]+','+xlmmapphtinnerer_rgb[2]+','+xlmmapphtinnerer_rgb[3]+','+i+') !important');
}
}
if($(window).scrollTop() < 20){
$('.c666').attr('style', 'color:#fff !important');
}
});

    var bartop = $('#fss').offset().top - 48;
    function changeBar(){
        var st = $(window).scrollTop();
        if( st > bartop){
            $('#fss').html('<style>.xlmmforuml-nav {position: fixed;top:40px;}</style>');
        }else{
            $('#fss').html('<style>.xlmmforuml-nav {position: relative;top:0;}</style>');
        }
    }
    $(window).scroll( function(){
        changeBar();
    })
var ias = $.ias({
   container: "#alist", 
        item: ".alist", 
        pagination: ".xlmmpg", 
        next: "a.nxt", 
   		delay: 1000,
 });
    ias.extension(new IASTriggerExtension({
        html: '<style>.xlmmdjjz{ display:block !important }</style>', 
        //htmlPrev: '<div class="ias-trigger ias-trigger-prev" class="ias-spinner" style="text-align: center;line-height:40px;color: #999;"><a>���������һҳ</a></div>',
        offset: false, 
    }));
    ias.extension(new IASSpinnerExtension({
	html: '<style>.xlmmzdjz{ display:block !important }</style>',
}));
    ias.extension(new IASNoneLeftExtension({
        html: '<style>.xlmmjzwc{ display:block !important }</style>', 
    }));
    //ias.extension(new IASPagingExtension());
    //ias.extension(new IASHistoryExtension());

</script>
<!--{template common/footer}-->


