/**
 * xlmm qqdism.taobao.com
 */
(function($) {
    var em = [
                {'id':1,'phrase':'{:4_86:}','url':'1.gif'},
				{'id':2,'phrase':'{:4_87:}','url':'10.gif'},
				{'id':3,'phrase':'{:4_88:}','url':'11.gif'},
				{'id':4,'phrase':'{:4_89:}','url':'12.gif'},
				{'id':5,'phrase':'{:4_90:}','url':'13.gif'},
				{'id':6,'phrase':'{:4_91:}','url':'14.gif'},
				{'id':7,'phrase':'{:4_92:}','url':'15.gif'},
				{'id':8,'phrase':'{:4_93:}','url':'16.gif'},
				{'id':9,'phrase':'{:4_94:}','url':'17.gif'},
				{'id':10,'phrase':'{:4_95:}','url':'18.gif'},
				{'id':11,'phrase':'{:4_96:}','url':'19.gif'},
				{'id':12,'phrase':'{:4_97:}','url':'2.gif'},
				{'id':13,'phrase':'{:4_98:}','url':'20.gif'},
				{'id':14,'phrase':'{:4_99:}','url':'21.gif'},
				{'id':15,'phrase':'{:4_100:}','url':'22.gif'},
				{'id':16,'phrase':'{:4_101:}','url':'23.gif'},
				{'id':17,'phrase':'{:4_102:}','url':'24.gif'},
				{'id':18,'phrase':'{:4_103:}','url':'25.gif'},
				{'id':19,'phrase':'{:4_104:}','url':'26.gif'},
				{'id':20,'phrase':'{:4_105:}','url':'27.gif'},
				{'id':21,'phrase':'{:4_106:}','url':'28.gif'},
				{'id':22,'phrase':'{:4_107:}','url':'29.gif'},
				{'id':23,'phrase':'{:4_108:}','url':'3.gif'},
				{'id':24,'phrase':'{:4_109:}','url':'30.gif'},
				{'id':25,'phrase':'{:4_110:}','url':'4.gif'},
				{'id':26,'phrase':'{:4_111:}','url':'5.gif'},
				{'id':27,'phrase':'{:4_112:}','url':'6.gif'},
				{'id':28,'phrase':'{:4_113:}','url':'7.gif'},
				{'id':29,'phrase':'{:4_114:}','url':'8.gif'},
				{'id':30,'phrase':'{:4_115:}','url':'9.gif'},

            ];
    //textarea���ù��λ��
    function setCursorPosition(ctrl, pos) {
        if(ctrl.setSelectionRange) {
            ctrl.focus();
            ctrl.setSelectionRange(pos, pos);
        } else if(ctrl.createTextRange) {// IE Support
            var range = ctrl.createTextRange();
            range.collapse(true);
            range.moveEnd('character', pos);
            range.moveStart('character', pos);
            range.select();
        }
    }

    //��ȡ�����ı�����λ��
    function getPositionForTextArea(obj)
    {
        var Sel = document.selection.createRange();
        var Sel2 = Sel.duplicate();
        Sel2.moveToElementText(obj);
        var CaretPos = -1;
        while(Sel2.inRange(Sel)) {
            Sel2.moveStart('character');
            CaretPos++;
        }
       return CaretPos ;

    }

    $.fn.extend({
        jqfaceedit : function(options) {
            var defaults = {
                txtAreaObj : '', //TextArea����
                containerObj : '', //����򸸶���
                textareaid: 'needmessage',//textareaԪ�ص�id
                popName : '', //iframe����������,containerObjΪ������ʱʹ��
                emotions : em, //������Ϣjson��ʽ��id��������� phrase����ʹ�õ��������url�����ļ���
                top : 0, //���ƫ��
                left : 0 //���ƫ��
            };
            
            var options = $.extend(defaults, options);
            var cpos=0;//���λ�ã�֧�ִӹ�괦��������
            var textareaid = options.textareaid;
            
            return this.each(function() {
                var Obj = $(this);
                var container = options.containerObj;
                if ( document.selection ) {//ie
                    options.txtAreaObj.bind("click keyup",function(e){//�������̶���ʱ���ù��ֵ
                        e.stopPropagation();
                        cpos = getPositionForTextArea(document.getElementById(textareaid)?document.getElementById(textareaid):window.frames[options.popName].document.getElementById(textareaid));
                    });
                }
                $(Obj).bind("click", function(e) {
                    e.stopPropagation();
                    var faceHtml = '<div id="face">';
                    faceHtml += '<div id="facebox">';
                    faceHtml += '<div id="face_detail" class="facebox cl"><ul>';

                    for( i = 0; i < options.emotions.length; i++) {
                        faceHtml += '<li text=' + options.emotions[i].phrase + ' type=' + i + '><img title=' + options.emotions[i].phrase + ' src="static/image/smiley/comcom/'+ options.emotions[i].url + '"  style="cursor:pointer; position:relative;"   /></li>';
                    }
                    faceHtml += '</ul></div>';
                    faceHtml += '</div><div class="arrow arrow_t"></div></div>';

                    container.find('#face').remove();
                    container.append(faceHtml);
                    
                    container.find("#face_detail ul >li").bind("click", function(e) {
                        var txt = $(this).attr("text");
                        var faceText = txt;

                        //options.txtAreaObj.val(options.txtAreaObj.val() + faceText);
                        var tclen = options.txtAreaObj.val().length;
                        
                        var tc = document.getElementById(textareaid);
                        if ( options.popName ) {
                            tc = window.frames[options.popName].document.getElementById(textareaid);
                        }
                        var pos = 0;
                        if( typeof document.selection != "undefined") {//IE
                            options.txtAreaObj.focus();
                            setCursorPosition(tc, cpos);//���ý���
                            document.selection.createRange().text = faceText;
                            //������λ��
                            pos = getPositionForTextArea(tc); 
                        } else {//���
                            //������λ��
                            pos = tc.selectionStart + faceText.length;
                            options.txtAreaObj.val(options.txtAreaObj.val().substr(0, tc.selectionStart) + faceText + options.txtAreaObj.val().substring(tc.selectionStart, tclen));
                        }
                        cpos = pos;
                        setCursorPosition(tc, pos);//���ý���
                        container.find("#face").remove();

                    });
                    //����js�¼�ð������
                    $('body').bind("click", function(e) {
                        e.stopPropagation();
                        container.find('#face').remove();
                        $(this).unbind('click');
                    });
                    if(options.popName != '') {
                        $(window.frames[options.popName].document).find('body').bind("click", function(e) {
                            e.stopPropagation();
                            container.find('#face').remove();
                        });
                    }
                    container.find('#face').bind("click", function(e) {
                        e.stopPropagation();
                    });
                    var offset = $(e.target).offset();
                    offset.top += options.top;
                    offset.left += options.left;
                    container.find("#face").css(offset).show();
                });
            });
        },
    })
})(jQuery);













