<?php exit;?>
<!--{template common/header}-->
<style>
.xlmmggslist {background:#FFF;}
.xlmmggslistdv {display: none;}
.xlmmggslist_li {padding: 10px 12px 12px;overflow: hidden;position: relative;border-bottom:1px solid #efefef}
.xlmmggslist_li h2 {font-size: 16px;line-height: 24px;height: 24px;overflow: hidden;}
.xlmmggslist_li h2 a {display: block;line-height: 24px;height: 24px;overflow: hidden;color:#222;}
.xlmmggslist_li h3 {margin-top:5px;font-size:13px;}
.xlmmggslistdv {line-height: 22px;font-size: 14px;margin-top: 5px;padding: 8px 10px;border-width: 1px 1px 1px 1px;border-style: dashed;border-color: #e7e1cd ;background:#fffeef;}
.xlmmggsm i{float: right;background:  url(static/image/common/arrow.gif) no-repeat right -36px;width:24px;height:24px;}
 .xlmmggsm i.xlmmxxss{background:  url(static/image/common/arrow.gif) no-repeat right -36px !important;}
.xlmmggsm i.xlmmxxs{background:  url(static/image/common/arrow.gif) no-repeat right 6px !important;}
.xlmm-mulisr .swiper-slide.a a{color: #0285f7;}
<!--{if !empty($annid)}-->
#xlmmggs_{$annid}dv {display: block;}
#xlmmggs_{$annid} i{background:  url(static/image/common/arrow.gif) no-repeat right 6px;}
<!--{/if}-->
</style>
<div class="xlmmggslist cl mt10">
<ul>
<!--{loop $announcelist $ann}-->
<li class="xlmmggslist_li cl">
<h2><a href="javascript:;" class="xlmmggsm" id="xlmmggs_$ann[id]"><i></i>$ann[subject]</a></h2>
<h3><span class="y" style="color:#bbb">$ann[starttime]</span><span style="color:#999">{lang author}:</span> <a href="home.php?mod=space&username=$ann[authorenc]" style="color:#507daf">$ann[author]</a></h3>
<div class="xlmmggslistdv" id="xlmmggs_$ann[id]dv">				
$ann[message]
</div>
</li>
<!--{/loop}-->
</ul>	
</div>
<script>
$('title').html('վ�㹫�� - <!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle}')
$('.xlmmggsm').on('click', function() {var obj = $(this);var objs = $('#' + obj.attr('id') + 'dv');if(objs.css('display') == 'none') {objs.css('display', 'block');obj.find('i').addClass('xlmmxxs');obj.find('i').removeClass('xlmmxxss');} else {objs.css('display', 'none');obj.find('i').addClass('xlmmxxss');obj.find('i').removeClass('xlmmxxs');}
});</script>
<!--{template common/footer}-->

