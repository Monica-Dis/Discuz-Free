<?php exit;?>
		<style type="text/css">
/* ͶƱ������ʽ */
.xlmm-poll {margin-top:15px;padding-top:15px;border-top: 1px solid #ECECEC;}
.xlmm-poll .tpzt_btys {margin-bottom:15px;}
.xlmm-poll .tpbt_dbt {font-size: 18px;color: #1296db;}
.xlmm-poll .tpbt_dbt i {margin-left:10px;font-size: 14px;color: #fcad30;}
.xlmm-poll .tpbt_dbt em:before { content: "\E902"; margin-left:2px; margin-right:5px;color: #333; }
.xlmm-poll .tpbt_xbt {margin-top:3px;font-size: 12px;color: #999;}
.xlmm-poll .tpbt_xbt i {margin-right:10px;}
.xlmm-poll .tpzt_tpsj .tpsj_tpxh {float: left;width: 100%;margin-bottom: 3%;}
.xlmm-poll .tpzt_tpsj .tpsj_tpxh .tpsj_tptp {}
.xlmm-poll .tpzt_tpsj .tpsj_tpxh .tpsj_tptp img {width: 100%;}
.xlmm-poll .tpzt_tpsj .tpsj_tpxh .tpsj_tpxz {margin-bottom:7px;font-size: 14px;color: #555;}
.xlmm-poll .tpzt_tpsj .tpsj_tpxh .tpsj_tpjd {position: relative;height: 24px;background: #d3d3d3;border-radius: 0 10px 10px 0;}
.xlmm-poll .tpzt_tpsj .tpsj_tpxh .tpsj_tpjd .tpjd_jdxs {display: block;width: 5px;height: 24px;background: #f2a61f;border-radius: 0 10px 10px 0;}
.xlmm-poll .tpzt_tpsj .tpsj_tpxh .tpsj_tpjd .tpjd_tpsj {position: absolute;left: 0;top: 0;padding: 0 5%;width: 90%;line-height: 24px;font-size: 14px;color: #fff;}
.xlmm-poll .tpzt_ants {margin-top:10px;}
.xlmm-poll .tpzt_ants .pn {display: block;width: 100%;height: 40px;line-height: 42px;text-align: center;background: #53baf4;border: 0;color: #fff;font-size: 14px;border-radius: 3px;-webkit-appearance: none;}
_::-webkit-full-page-media, _:future, :root .xlmm-poll .tpzt_ants .pn {line-height: 40px;}

.xlmmtsztts {background: #fefced ;border: 1px dashed #ECECEC;padding:0;margin:10px 0;font-size: 15px;color: #ffaf00; text-align:center;}
.xlmmtsztts a,.locked a {color: #888;padding:0 5px;}

</style>
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>
<div class="xlmm-poll cl">
<form id="poll" name="poll" method="post" autocomplete="off" action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes&mobile=2" >
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="tpzt_btys cl">
		<div class="tpbt_dbt"><em class="iconfont"></em><!--{if $multiple}-->{lang poll_multiple}{lang thread_poll}<!--{if $maxchoices}--><i>{lang poll_more_than}</i><!--{/if}--><!--{else}-->{lang poll_single}{lang thread_poll}<!--{/if}--></div>
		<div class="tpbt_xbt">
			<!--{if $visiblepoll && $_G['group']['allowvote']}--><i>{lang poll_after_result}</i><!--{/if}-->
			<i>{lang poll_voterscount}</i>
			<!--{if $_G[forum_thread][remaintime]}--><p><i>{lang poll_count_down}<!--{if $_G[forum_thread][remaintime][0]}-->$_G[forum_thread][remaintime][0] {lang days}<!--{/if}--><!--{if $_G[forum_thread][remaintime][1]}-->$_G[forum_thread][remaintime][1] {lang poll_hour}<!--{/if}-->$_G[forum_thread][remaintime][2] {lang poll_minute}</i><p>
			<!--{elseif $expiration && $expirations < TIMESTAMP}--><p><i>{lang poll_end}</i><p><!--{/if}-->
		</div>
	</div>
	<div class="tpzt_tpsj cl">
		<!--{loop $polloptions $key $option}-->
		<!--{eval $i++;}-->
		<!--{eval $imginfo=$option['imginfo'];}-->
		<div class="tpsj_tpxh cl">
			<!--{if $imginfo}-->
				<div class="tpsj_tptp cl"><img id="aimg_$imginfo[aid]" aid="$imginfo[aid]" src="$imginfo[small]" onclick="zoom(this, this.getAttribute('zoomfile'), 0, 0, '{$_G[setting][showexif]}')" zoomfile="$imginfo[big]" alt="$imginfo[filename]" title="$imginfo[filename]" w="$imginfo[width]" /></div>
			<!--{/if}-->
			<div class="tpsj_tpxz cl">
			<!--{if $_G['group']['allowvote']}-->
				<input type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if}  />
			<!--{/if}-->
				<label for="option_$key">$key.$option[polloption]</label>
			</div>
			<div class="tpsj_tpjd cl">
				<span class="tpjd_jdxs cl" style="width: $option[percent]%; background-color:#$option[color]">&nbsp;</span>
				<p class="tpjd_tpsj cl">
					<span class="z">$option[votes]Ʊ</span>
					<span class="y">$option[percent]%</span>
				</p>
			</div>
		</div>
		<!--{/loop}-->
	</div>
	<div class="tpzt_ants cl">	
        <!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
            <input type="submit" name="pollsubmit" id="pollsubmit" value="{lang submit}" class="pn" />
            <!--{if $overt}-->
                <div class="xlmmtsztts cl"><i></i>{lang poll_msg_overt}</div>
            <!--{/if}-->
        <!--{elseif !$allwvoteusergroup}-->
            <!--{if !$_G['uid']}-->
            <div class="xlmmtsztts cl"><i class="iconfont"></i>{lang poll_msg_allwvote_user}</div>
            <!--{else}-->
            <div class="xlmmtsztts cl"><i class="iconfont"></i>{lang poll_msg_allwvoteusergroup}</div>
            <!--{/if}-->
        <!--{elseif !$allowvotepolled}-->
           <div class="xlmmtsztts cl"><i class="iconfont"></i>{lang poll_msg_allowvotepolled}</div>
        <!--{elseif !$allowvotethread}-->
            <div class="xlmmtsztts cl"><i class="iconfont"></i>{lang poll_msg_allowvotethread}</div>
        <!--{/if}-->
	</div>
</form>
</div>


