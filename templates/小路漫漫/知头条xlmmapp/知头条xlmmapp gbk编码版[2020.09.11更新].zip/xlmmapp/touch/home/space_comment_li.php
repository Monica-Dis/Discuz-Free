<?PHP exit('Access ��������б���xlmm2018');?>
<style>

 .xlmmxcplli {margin-bottom:15px;background: #fff;position: relative;}
 .xlmmxcplli .plxm_hytx {position: absolute;left: 0;top:0;}
 .xlmmxcplli .plxm_hytx img {width: 45px;height: 45px;-webkit-border-radius: 5rem;border-radius: 5rem;vertical-align: top;}
.plxm_plnr {margin-left:55px;padding-bottom:15px;border-bottom: 1px solid #f4f4f4;}
.plxm_plnr .plnr_rzcz {margin-bottom:5px;}

.plxm_plnr .plnr_rzcz .rzcz_hysj a {color: #3679A5;font-size: 16px;}
.plxm_plnr .plnr_rzcz .rzcz_hysj span {margin-left:5px;color: #999;font-size: 14px;}
 .plnr_rzhf {font-size: 16px;color: #000;}
 .plnr_rzhf .quote {margin: 10px 0 25px 0;}
 .plnr_rzhf .quote blockquote {background: #f8f8f8;border: 1px dashed #e6e6e6;color: #999;padding: 10px;font-size: 12px;margin-bottom: -15px;line-height: 20px;}



</style>

<a name="comment_anchor_$value[cid]"></a>
<!--{if empty($ajax_edit)}--><div id="comment_$value[cid]_li" class="xlmmxcplli cl"><!--{/if}-->
<div class="plxm_hytx cl ">
	<!--{if $value[author]}-->
		<a href="home.php?mod=space&uid=$value[authorid]&do=profile" c="1"><!--{avatar($value[authorid],middle)}--></a>
	<!--{else}-->
	<dd class="m avt"><img src="{STATICURL}image/magic/hidden.gif" alt="hidden" /></dd>
	<!--{/if}-->
</div>
<div class="plxm_plnr cl">
	<div class="plnr_rzcz cl">
		<div class="xpqt_tqgl y cl">
		<!--{if $_G[uid]}-->
			<!--{if $value[authorid]==$_G[uid]}-->
				<a href="home.php?mod=spacecp&ac=comment&op=edit&cid=$value[cid]&handlekey=editcommenthk_{$value[cid]}" class="tqgl_bjtp {if $_G['uid']}dialog{/if} iconfont">&#xe613;</a>
			<!--{/if}-->
			<!--{if $value[authorid]==$_G[uid] || $value[uid]==$_G[uid] || checkperm('managecomment')}-->
				<a href="home.php?mod=spacecp&ac=comment&op=delete&cid=$value[cid]&handlekey=delcommenthk_{$value[cid]}" class="tqgl_bjtp {if $_G['uid']}dialog{/if} iconfont">&#xe906;</a>
			<!--{/if}-->
		<!--{/if}-->
		</div>
		<div class="rzcz_hysj z cl">
			<!--{if $value[author]}-->
				<a href="home.php?mod=space&uid=$value[authorid]&do=profile" id="author_$value[cid]">{$value[author]}</a>
			<!--{else}-->
				<a href="javascript:void(0)">$_G[setting][anonymoustext]</a>
			<!--{/if}-->
			<span><!--{date($value[dateline])}--></span>
		</div>
	</div>
	<div id="comment_$value[cid]" class="plnr_rzhf"><!--{if $value[status] == 0 || $value[authorid] == $_G[uid] || $_G[adminid] == 1}-->$value[message]<!--{else}--> {lang moderate_not_validate} <!--{/if}--></div>
</div>
<!--{if empty($ajax_edit)}--></div><!--{/if}-->












