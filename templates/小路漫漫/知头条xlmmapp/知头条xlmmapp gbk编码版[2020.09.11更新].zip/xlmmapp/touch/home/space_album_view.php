<?PHP exit('Access ���鿴��xlmm2018');?>
<!--{eval $_G['home_tpl_titles'] = array($album['albumname'], '{lang album}');}-->
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->

	<!--{subtemplate common/header}-->

<style>
.emp, .mbw {height: 1.25rem;line-height: 1.25rem;text-align: center;font-size: 0.3rem;color: #BBB;}
.xlmmmets {background: #fffdef;border: 1px dashed #e7e1cd;font-size: 13px;color: #999;margin-bottom:10px;}
 .xlmmxctit {padding: 8px 0 5px;overflow: hidden;}
.xlmmxctit h2 {height: 34px;line-height: 34px;font-size: 20px;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;}
.xlmmxctit h2 i {float: right;padding-left: 4px;}
.xlmmxctit h2 i a{ padding:3px 4px;  font-size: 12px;  border: 1px solid #e9e9e9;margin-left: 3px;border-radius: 3px;color:#bbb;}
.xlmmxctit p {color:#bbb;}

.xlmmxcview{margin: 10px 10px 0 0;}
.xlmmxcview.xctop li {height:140px;overflow:hidden;}
.xlmmxcview.xctop li img {min-height:140px;}
.xlmmxcview li {display: block;position: relative;width: 50%;float: left;padding-left: 10px;box-sizing: border-box;margin-bottom:10px;}
.xlmmxcview li img {display: block;width: 100%;}
.xlmmxcview li p a{text-align:center;font-size:14px;position:absolute;bottom: 0;left:10px;right:0;color: #fff;font-size: 16px;background-color: #000;background-color: rgba(0,0,0,0.5);height:26px;line-height:26px}
.xlmmxcview li .xlmmxcnum {top:10px;padding: 1px 5px;color: #fff;position: absolute;right:10px;}

.xlmmxcqt h2 {height: 38px;line-height: 38px;font-size: 16px;overflow: hidden;}
</style>
		<div class="tbmu cl mt20 plr15 white">
<div class="xlmmxctit">
<h2><i>			<!--{if $album[albumid]>0}-->
			<a href="home.php?mod=spacecp&ac=favorite&type=album&id=$album[albumid]&spaceuid=$space[uid]&handlekey=sharealbumhk_{$album[albumid]}" class="dialog">{lang favorite}</a>
			<!--{/if}-->
				<!--{if $space[self]}--><a href="{if $album[albumid] > 0}home.php?mod=spacecp&ac=album&op=edit&albumid=$album[albumid]{else}home.php?mod=spacecp&ac=album&op=editpic&albumid=0{/if}">{lang edit}</a><!--{/if}-->
				<!--{if ($_G[uid] == $album[uid] || checkperm('managealbum')) && $album[albumid] > 0}-->
					<a href="home.php?mod=spacecp&ac=album&op=delete&albumid=$album[albumid]&uid=$album[uid]&handlekey=delalbumhk_{$album[albumid]}" class="dialog">{lang delete}</a>
				<!--{/if}-->
</i>
<!--{if $album[albumname]}-->$album[albumname]<!--{else}-->{lang default_album}<!--{/if}--></h2>
	<!--{if $album[picnum]}--><p>{lang total} $album[picnum] {lang album_pics}  /  {lang update} <!--{date($album[updatetime], 'n-j H:i')}--></p><!--{/if}-->
</div>
		</div>
		
		<!--{if $list}-->
	<!--{if $album[depict]}--><p class="xlmmmets plr15 mt20" style="padding-top:10px; padding-bottom:10px;">$album[depict]</p><!--{/if}-->
			<ul class="xlmmxcview xctop cl">
			<!--{loop $list $key $value}-->
				<li>
				<a href="home.php?mod=space&uid=$value[uid]&do=$do&picid=$value[picid]"><!--{if $value[pic]}--><img src="$value[pic]" alt="" /><!--{/if}--></a><!--{if $value[status] == 1}--><b>({lang moderate_need})</b><!--{/if}-->
				</li>
			<!--{/loop}-->
			</ul>
			<!--{if $pricount}--><p>{lang hide_pic}</p><!--{/if}-->
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
		<!--{else}-->
			<!--{if !$pricount}--><p class="emp">{lang no_pics}</p><!--{/if}-->
			<!--{if $pricount}--><p class="emp">{lang hide_pic}</p><!--{/if}-->
		<!--{/if}-->
		
		<!--{if $albumlist}-->
		<div class="xlmmxcqt plr15 white">
				<h2>{lang switch_pics}</h2>
			</div>
			<div class="">
				<div id="pnv" class="bn pns cl">
					<!--{if $albumlist}-->	
					<!--{loop $albumlist $key $albums}-->
					<ul class="xlmmxcview">
						<!--{loop $albums $akey $value}-->
						<!--{eval $pwdkey = 'view_pwd_album_'.$value['albumid'];}-->
						<li>
							<div class="c">
								<a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" title="$value[albumname]"><!--{if $value[pic]}--><img src="$value[pic]" alt="$value[albumname]"/><!--{/if}--></a>
								<p><a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" title="$value[albumname]" >$value[albumname]</a></p>
						             <!--{if $value[picnum]}--> <i class="xlmmxcnum bcolour">$value[picnum] P</i><!--{/if}-->
	</div>
						</li>
						<!--{/loop}-->
					</ul>
					<!--{/loop}-->

					<!--{/if}-->
				</div>
			</div>
		</div>
		<!--{/if}-->
		


					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="sd">
			<!--{/if}-->
		</div>
	</div>

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->












