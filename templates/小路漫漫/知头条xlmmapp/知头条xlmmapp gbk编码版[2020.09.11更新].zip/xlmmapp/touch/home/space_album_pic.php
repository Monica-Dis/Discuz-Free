<?PHP exit('Access �����ҳ��xlmm2020');?>
<!--{eval $_G['home_tpl_titles'] = array(getstr($pic['title'], 60, 0, 0, 0, -1), $album['albumname'], '{lang album}');}-->
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->

	<!--{subtemplate common/header}-->
<style>
#photo_pic  { position:relative;}
#photo_pic img {width: 100%;vertical-align: top;}
 .albim_pic_title {line-height: 1.6;font-size: 0.34rem;}
.xctpxx h3, #pic_comment h3 {padding: 10px 0;margin-bottom: 10px;background-position: 10px;background-size: 20px auto;font-size: 15px;font-weight: 400;border-bottom: 1px solid #f5f5f5;}
#pic_block h2 { height:35px; line-height:35px; font-size:15px; text-align:center;}
.xlmmxcnp a {background: rgba(0, 0, 0, 0.3);font-size: 14px;color: #fff;}
.xlmmxcnp .z {padding:8px 15px 8px 8px;border-radius: 0 5rem 5rem 0;position: absolute;top: 50%;}
.xlmmxcnp .y {padding:8px 8px 8px 15px;border-radius: 5rem 0 0 5rem; position: absolute;top: 50%; right:15px;}
/* ��̬? */
.atd {margin: 0 auto;background:#fff;}
.atd img {width: 25px;}
.atd a {display: block;color: #999;}
.atd td {padding: 10px 10px 0 10px;text-align: center;vertical-align: bottom;}
.atd .atdc {position: relative;margin: 0 auto 10px;width: 10px;height: 30px;}
.atdc div {position: absolute;left: 0;bottom: 0;width: 10px;text-align: left;}
.atd .ac1 {background: #C30;}
.atd .ac2 {background: #0C0;}
.atd .ac3 {background: #F90;}
.atd .ac4 {background: #06F;}

.xpqt_tqgl a {float: left;width: 22px;height: 22px;border: 1px solid #e9e9e9;margin-left: 10px;border-radius: 3px;text-align: center;line-height:22px;color:#999;}
 .tqgl_bjtp {background: #f8f8f8}
.xctpxx p {font-size: 14px;color: #333;}
.xctpxx p i {color: #999;}

form {background: #FFFFFF;margin: 15px;padding:15px 0;}
.c {background: #FFFFFF;margin:15px;margin-top:0;padding: 0;text-align: left;}
.c p label{font-size:13px}
.pns button {width: 50px;height: 32px;line-height: 32px;border: 0;margin-left: 15px;text-align: center;color: #FFF;background: #2498D8;}
.c .cur1 {display:none;}
.c .pt, .xcplk .pt {background: #fff;border:1px solid #f8f8f8 !important;width: 96%;height: 120px;border: 0;color: #999;padding: 2%;font-size: 14px;}
.sec_code {padding: 0;}

</style>

				<div class="tbmu" id="pic_block">
								<div class="white">

									<div id="photo_pic" class="pl15 pr15 mt20" style="padding-top:10px;" >
<img src="$pic[pic]" id="pic" alt="" />
<!--{if $album[picnum]}--><h2 class="white mt20">{lang current_pic} (<a href="$pic[pic]">{lang look_pic}</a>)
</h2><!--{/if}-->
					<div class="xlmmxcnp cl">
		<a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$upid&goto=up#pic_block" class="z">{lang previous_pic}</a>
		<a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid&goto=down#pic_block" class="y">{lang next_pic}</a>
	</div>
					</div>



								</div>

								<!--{if $album[friend] != 3}-->
								<div id="click_div" class="white" style="padding:10px; padding-top:5px;">
									<!--{template home/space_click}-->
								</div>
								<!--{/if}-->
	<div class="xctpxx white mt20 plr15 cl">
	<div style="padding: 8px 0;">
<h3 class="colour" style="padding-top:0;">
				<!--{if $_G[uid] == $pic[uid] || checkperm('managealbum')}-->
		<span class="y xpqt_tqgl cl">
				<a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$pic[albumid]&picid=$pic[picid]" class="tqgl_bjtp iconfont">&#xe914;</a>
				<a href="home.php?mod=spacecp&ac=album&op=edittitle&albumid=$pic[albumid]&picid=$pic[picid]&handlekey=edittitlehk_{$pic[picid]}" class="tqgl_bjtp {if $_G['uid']}dialog{/if} iconfont">&#xe635;</a>
			</span>
												<!--{/if}-->
ͼƬ˵��
		</h3>
		<p><!--{if $pic[title]}-->$pic[title]<!--{else}--><!--{eval echo substr($pic['filename'], 0, strrpos($pic['filename'], '.'));}--><!--{/if}--></p>
		<p>{lang upload_at} <!--{date($pic[dateline])}--> ($pic[size])<!--{if $pic[hot]}--><i style="margin-left:5px;">{lang hot}$pic[hot]</i><!--{/if}--></p>
		
	</div>
	</div>

								<div id="pic_comment" class="plr15 white mt20">
									<h3 class="colour">
										ȫ��{lang comment}
									</h3>
									<div id="comment">
										<!--{if $cid}-->
										<div class="i">
											{lang current_comment}
										</div>
										<!--{/if}-->

										<div id="comment_ul" class="xld">
										<!--{loop $list $k $value}-->
											<!--{template home/space_comment_li}-->
										<!--{/loop}-->
										</div>
									</div>
									<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
								</div>
								<!--{if helper_access::check_module('album')}-->
								<form id="quickcommentform_{$picid}" name="quickcommentform_{$picid}" action="home.php?mod=spacecp&ac=comment&handlekey=qcpic_{$picid}" method="post" autocomplete="off" onsubmit="ajaxpost('quickcommentform_{$picid}', 'return_qcpic_{$picid}');doane(event);" class="white pl15 pr15 xcplk" style="padding-bottom:10px; padding-top:10px; margin:0;">

									<div class="tedt mtn mbn">
										<div class="area">
											<!--{if $_G['uid'] || $_G['group']['allowcomment']}-->
												<textarea id="comment_message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');" name="message" rows="3" class="pt"></textarea>
											<!--{else}-->
												<div class="pt hm">{lang login_to_comment} <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)" class="xi2">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}" class="xi2">$_G['setting']['reglinkname']</a></div>
											<!--{/if}-->
										</div>

									</div>
									<!--{if $secqaacheck || $seccodecheck}-->
										<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
										<div class="mtm mbm sec"><!--{subtemplate common/seccheck}--></div>
									<!--{/if}-->
									<p class="pns">
										<input type="hidden" name="refer" value="$theurl" />
										<input type="hidden" name="id" value="$picid" />
										<input type="hidden" name="idtype" value="picid" />
										<input type="hidden" name="commentsubmit" value="true" />
										<input type="hidden" name="quickcomment" value="true" />
										<button type="submit" name="commentsubmit_btn" value="true" id="commentsubmit_btn" class="pn" style="margin:0;"><strong>{lang comment}</strong></button>
										<span id="__quickcommentform_{$picid}"></span>
										<span id="return_qcpic_{$picid}"></span>
										<input type="hidden" name="formhash" value="{FORMHASH}" />
									</p>
								</form>
								<!--{/if}-->
						</div>


						<script type="text/javascript">
							function succeedhandle_qcpic_{$picid}(url, msg, values) {
								if(values['cid']) {
									comment_add(values['cid']);
								} else {
									$('return_qcpic_{$picid}').innerHTML = msg;
								}
								<!--{if $sechash}-->
									<!--{if $secqaacheck}-->
									updatesecqaa('$sechash');
									<!--{/if}-->
									<!--{if $seccodecheck}-->
									updateseccode('$sechash');
									<!--{/if}-->
								<!--{/if}-->
							}
						</script>

						<script type="text/javascript">
							var interval = 5000;
							var timerId = -1;
							var derId = -1;
							var replay = false;
							var num = 0;
							var endPlay = false;
							function forward() {
								window.location.href = 'home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid&goto=down&play=1#pic_block';
							}
							function derivativeNum() {
								num++;
								$('displayNum').innerHTML = '[' + (interval/1000 - num) + ']';
							}
							function playNextPic(stat) {
								if(stat || replay) {
									derId = window.setInterval('derivativeNum();', 1000);
									$('displayNum').innerHTML = '[' + (interval/1000 - num) + ']';
									$('playid').onclick = function (){replay = false;playNextPic(false);};
									$('playid').innerHTML = '{lang stop_playing}';
									timerId = window.setInterval('forward();', interval);
								} else {
									replay = true;
									num = 0;
									if(endPlay) {
										$('playid').innerHTML = '{lang restart}';
									} else {
										$('playid').innerHTML = '{lang start_playing}';
									}
									$('playid').onclick = function (){playNextPic(true);};
									$('displayNum').innerHTML = '';
									window.clearInterval(timerId);
									window.clearInterval(derId);
								}
							}
							<!--{if $_GET['play']}-->
							<!--{if $sequence && $album['picnum']}-->
							if($sequence == $album[picnum]) {
								endPlay = true;
								playNextPic(false);
							} else {
								playNextPic(true);
							}
							<!--{else}-->
							playNextPic(true);
							<!--{/if}-->
							<!--{/if}-->

							function update_title() {
								$('title_form').style.display='';
							}

							var elems = selector('dd[class~=magicflicker]');
							for(var i=0; i<elems.length; i++){
								magicColor(elems[i]);
							}
						</script>

						<!--end bm-->

				</div>
			</div>

	</div>
</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->












