<?PHP exit('Access xlmm��xlmm2020');?>

<style>
.xlmmftpcl{background: #fff !important;}
.sf-header{ background:none; color:#FFF}
.sf-header .c666 {color: #fff !important; fill:#fff !important;}
.iconfont.xlmmtplss { font-size: 28px;width: 22px;  font-weight:600 }
.iconfont.xlmmtplsss { font-size: 21px;width: 22px;  font-weight:600; display:inline-block;  }
.sf-header {background-color:none !important;}
.sf-headercolor {width:0px;height:0px;overflow:hidden; color:#666;}
.xlmmh48 { display:none;}

.personal_header{overflow:hidden;width: 100%;height: 4.4rem;background: url("template/xlmmapp/m-img/home.png") no-repeat 0 0;background-size: cover;text-align: center;}
.boy{background-color: #27b7ff!important;}
.girl{background-color: hotpink!important;}
.personal_header .user_info i{border-radius: 0.06rem;width: .36rem !important;height: .36rem !important;margin: 0 !important;background-size: 6rem;display: inline-block;font-size: .26rem;}
.personal_header .user_img{margin: 0 auto;margin-top: 0.96rem;width: 1.3rem;height: 1.3rem;border-radius: 1.3rem;}
.personal_header .user_img img{display: block;width: 1.3rem;height: 1.3rem;border-radius: 1.3rem;border: 2px solid #8e8b98;}
.personal_header .user_info{text-align: center;color: #ffffff;position: relative;margin: 0 auto;margin-top: 0.2rem;font-size: 0;height: 0.5rem;line-height: 0.5rem;}
.personal_header .notice{font-size: 0.26rem;color: #ffffff;margin-top: 0.18rem;}
.personal_header .user_info p{font-size: 0.36rem;display: inline-block;}
.personal_header .user_info i{display: inline-block;margin-left: 0.15rem!important;position: relative;top:0.07rem;/*position: absolute;*//*right: -0.5rem;*/ /*top:0;*/}
.personal_header .user_zhishu{text-align: center;font-size: 0;}
.personal_header .user_zhishu li{display: inline-block;font-size: 0.26rem;color: #ffffff;padding: 0 0.34rem;border-right: 1px solid #ffffff;height: 0.3rem;line-height: 0.3rem;margin-top: 0.2rem;}
.personal_header .user_zhishu li:last-child{border-right: none;}

.nav_bar{height: 0.92rem;background: #f9f8f8;box-shadow: 0 5px 5px #e5e5e5; overflow:hidden;}
.nav_bar .inside{width: 5.6rem;height: 0.9rem;line-height: 0.9rem;margin: 0 auto;}
.nav_bar .inside li{width: 0.9rem;float: left;height: 0.9rem;margin: 0 0.25rem;font-size: 0.3rem;color: #999;text-align: center;}
.nav_bar .inside li a{color: #999;}
</style>
<div class="personal_header">
    <div class="user_img">
        <img src="{avatar($space[uid], middle, true)}">
    </div>
    <div class="user_info">
        <p class="username">$space[username]</p>
             <span class="new_level xlmmlvh$xlmmhdj " style="vertical-align: super;">LV$xlmmhdj</span>
                    </div>
    <p class="notice"><!--{if $sightml = strip_tags($space['sightml'])}--><!--{echo cutstr({$sightml},26)}--><!--{else}-->��һ������û�и���ǩ����<!--{/if}--></p>
           		    	<!--{eval  $xlmmuidfav=DB::result_first("select followuid from ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$space[uid]");
                  $xlmmuidfavs=DB::fetch_all("select fusername from ".DB::table("home_follow")." WHERE`followuid`=$space[uid]");$xlmmfsall = count($xlmmuidfavs);
}-->
  <ul class="clearfix user_zhishu">
        <li>����&nbsp;&nbsp;$space[credits]</li>
        <li>��˿&nbsp;&nbsp;$xlmmfsall</li>
    </ul>
</div>
<div class="nav_bar">
    <ul class="inside ">
        <li<!--{if $_GET['grzl'] || $_GET['wz']}--><!--{else}-->  class="cur"<!--{/if}-->>
            <a href="home.php?mod=space&uid=$space[uid]&do=profile">����</a>
        </li>
        <li<!--{if $_GET['wz']}--> class="cur"<!--{/if}-->>
            <a href="home.php?mod=space&uid=$space[uid]&do=profile&wz=$space[uid]">����</a>
        </li>
           <li<!--{if $_GET['grzl']}--> class="cur"<!--{/if}-->>
            <a href="home.php?mod=space&uid=$space[uid]&do=profile&grzl=$space[uid]">����</a>
        </li>
     <li<!--{if $do="album"}--> class="curs"<!--{/if}-->>
            <a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space">���</a>
        </li>
    </ul>
</div>




<script>
 var xlmmapphtinnerer_bg = $(".sf-header").css("backgroundImage");
if(xlmmapphtinnerer_bg != 'none'){
$('.sf-header').css("cssText",'background:none !important');
$('.c666').css("cssText",'color:#fff !important');
}
var xlmmapphtinnerer_rgb = $(".sf-headercolor").css('background-color');
var xlmmapphtinnerer_rgbs = $(".sf-headercolor").css('color');
xlmmapphtinnerer_rgbs = xlmmapphtinnerer_rgbs.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
xlmmapphtinnerer_rgb = xlmmapphtinnerer_rgb.match(/^rgb\((\d+),\s*(\d+),\s*(\d+)\)$/);
$(window).scroll(function() {
 if($(window).scrollTop() > 100){
if(xlmmapphtinnerer_bg == 'none'){
$('.sf-header').attr('style', 'background-color:rgba('+xlmmapphtinnerer_rgb[1]+','+xlmmapphtinnerer_rgb[2]+','+xlmmapphtinnerer_rgb[3]+',1) !important');
$('.c666').attr('style', 'color:rgba('+xlmmapphtinnerer_rgbs[1]+','+xlmmapphtinnerer_rgbs[2]+','+xlmmapphtinnerer_rgbs[3]+',1) !important');
}
}else{
var i = $(window).scrollTop() / 100;
if(xlmmapphtinnerer_bg == 'none'){
$('.c666').attr('style', 'color:rgba('+xlmmapphtinnerer_rgbs[1]+','+xlmmapphtinnerer_rgbs[2]+','+xlmmapphtinnerer_rgbs[3]+',1) !important');
$('.sf-header').attr('style', 'background-color:rgba('+xlmmapphtinnerer_rgb[1]+','+xlmmapphtinnerer_rgb[2]+','+xlmmapphtinnerer_rgb[3]+','+i+') !important');
}
}
if($(window).scrollTop() < 20){
$('.c666').attr('style', 'color:#fff !important');
}
});

    var bartop = $('#fss').offset().top - 48;
    function changeBar(){
        var st = $(window).scrollTop();
        if( st > bartop){
            $('#fss').html('<style>.xlmmforuml-nav {position: fixed;top:40px;}</style>');
        }else{
            $('#fss').html('<style>.xlmmforuml-nav {position: relative;top:0;}</style>');
        }
    }
    $(window).scroll( function(){
        changeBar();
    })

</script>










