<?PHP exit('Access ����б���xlmm2020');?>
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->

	<!--{template common/header}-->
<!--{if $value[uid]==$space[uid]}-->
<!--{if $value[uid]==$_G[uid]}-->
  <!--{else}-->
     				{eval         $getgid=getuserbyuid($space[uid]);
        $xlmmhdj = DB::result_first("SELECT stars FROM %t WHERE groupid=%d", array("common_usergroup", $getgid['groupid']));
}
<!--{template home/sheader}-->
<!--{/if}-->
	<!--{/if}-->
<style type="text/css">
.nav_bar .inside li.curs{border-bottom: 1px solid #15bfff;}
.nav_bar .inside li.curs a{color: #15bfff;}

.xlmmft { display:none;}
.download_btn {position: fixed;bottom: 0px;width: 100%; max-width: 750px; background: #fff;border-top: 1px solid #ddd;  text-align: center; font-size: 0; display:block; z-index:9;}
.download_btnnew {margin: 0.1rem 0.28rem;border-radius: 5px;    background-color: #0285f7}
.download_btn span {display: inline-block;  height: 0.8rem; line-height: 0.8rem;font-size: 0.28rem;color: #ffffff;}
.xlmmmets {background: #fffdef;border: 1px dashed #e7e1cd;font-size: 13px;color: #999; margin-bottom:10px;}
.xlmmmets a.a{color: #15bfff;}
.xlmmmets .pipe{ margin:0 8px;}
.xlmmxclist li{ float:left;}

.xlmmxcfsx {margin-bottom:15px;font-size: 15px;background: #fff;}
.xlmmxcfsx .xcsxl {width: 28%;color: #999;}
.xlmmxcfsx .xcsxr {width: 72%;}
.xlmmxcfsx .xcsxr .ps {float: right;width: 100%;background: #fff url(template/xlmmapp/touch/forum/post/ztfl_xxsx.png) no-repeat;background-position:right;background-size: 15px auto;border: 0;border-radius: 0;color: #000;font-size: 15px;outline: none;-webkit-appearance: none;}

.xlmmxcpic {background: #f5f5f5;padding: 0px 0 0 5px;position: relative;overflow: hidden;}
.xlmmxcpic-item {position: relative;float: left;width: 45.333333%;box-sizing: border-box;text-align: center;margin: 0 2% 4% 2%;background: #ffffff;border-radius: 4px;box-shadow: 0 -1px 8px rgba(0,0,0,0.3);}
.xlmmxcpic-item-img {position: relative;padding:10px 10px 0;}
.xlmmxcpic-item-img .xlmmxcnum {top:10px;padding: 1px 5px;color: #fff;position: absolute;right:10px;}
.xlmmxcpic-item-img span {position: absolute;left: 10px;right:10px;bottom: 0;color: #fff;font-size: 16px;background-color: #000;background-color: rgba(0,0,0,0.5); height:26px; line-height:26px;}
.xlmmxcpic-item-img img {width: 100%;height: 100%;display: block;border: none;border-radius: 4px 4px 0 0;}
.xlmmxcpic-cell {padding: 10px 8px;position: relative;display: -webkit-box;display: -webkit-flex;display: flex;-webkit-box-align: center;-webkit-align-items: center;align-items: center;color: #000000;-webkit-tap-highlight-color: rgba(0, 0, 0, 0);}
.xlmmxcpic-cell-hd {margin-right: 5px;width: 35px;height: 35px;line-height: 35px;text-align: center;position: relative;}
.xlmmxcpic-cell-hd img {width: 100%;max-height: 100%;vertical-align: top;border: 1px solid #00bcd4;border-radius: 100%;}
.xlmmxcpic-cell-bd {-webkit-box-flex: 1;-webkit-flex: 1;flex: 1;min-width: 0;text-align: left;}
.xlmmxcpic-cell-bd h4 {font-weight: 400;font-size: 13px;width: auto;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;word-wrap: normal;word-wrap: break-word;word-break: break-all;padding-bottom: 4px;}
.xlmmxcpic-cell-bd p {color: #808080;font-size: 12px;line-height: 1.2;overflow: hidden;text-overflow: ellipsis;display: -webkit-box;-webkit-box-orient: vertical;-webkit-line-clamp: 1;padding: 0;margin: 0;}
.xlmmxcpic-cell-fr {float: right;text-align: right;color: #999;font-size: 12px;}
.xlmmxcpic-cell-fr a{display:block;color: #999;font-size: 12px;}
.xlmmxcpic-cell-fr-img {width: 14px;height: 14px;margin-bottom: 4px;}
.xlmmxcpic-cell-fr-img img {width: 100%;max-height: 100%;vertical-align: top;}
.emp, .mbw {height: 1.25rem;line-height: 1.25rem;text-align: center;font-size: 0.3rem;color: #BBB;}

	</style>
    
    
<a href="home.php?mod=spacecp&ac=upload" class="download_btn deepshare">
            <div class="download_btnnew bcolour"><span>�ϴ�һ�������Լ������</span></div>
        </a>

	<div id="ct" class="mt15 cl">

		<div class="tbmu cl">

			<!--{if $space[self] && $_GET['view']=='me'}-->
<!--{if $value[uid]==$_G[uid]}--><div class="xlmmmets plr15" style="padding-top:10px; padding-bottom:10px;">{lang explain_album}</div><!--{/if}-->
			<!--{/if}-->

			<!--{if $_GET[view] == 'all'}-->
			<div class="xlmmmets plr15" style="padding-top:10px; padding-bottom:10px;">	<a href="home.php?mod=space&do=album&view=all" {if !$_GET[catid]}$orderactives[dateline]{/if}>{lang newest_update_album}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=album&view=all&order=hot" $orderactives[hot]>{lang hot_pic_recommend}</a></div>

			<!--{/if}-->


<!--{if ($_GET['view'] == 'we') && $userlist}-->
<div class="xlmmxcfsx pl15 pr15 cl" style="padding-top:10px; padding-bottom:10px;">
	<div class="xcsxl z">{lang filter_by_friend}</div>
	<div class="xcsxr z">			
		<select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
			<option value="">{lang all_friends}</option>
			<!--{loop $userlist $value}-->
				<option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
			<!--{/loop}-->
		</select>
	</div>
</div>
<!--{/if}-->
		</div>

                    				<!--{if $picmode}-->

						<!--{if $pricount}-->
						<p class="mbw">{lang hide_pic}</p>
						<!--{/if}-->
						<!--{if $count}-->
				<div class="xlmmxcpic">
							<!--{loop $list $key $value}-->
<div onclick="window.location='home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]'" class="xlmmxcpic-item">
                        <div class="xlmmxcpic-item-img">
                     <!--{if $value[pic]}-->       <img src="$value[pic]" alt=""><!--{/if}-->
             <!--{if $value[picnum]}--> <i class="xlmmxcnum bcolour">$value[picnum] P</i><!--{/if}-->
              <span>
                                $value[albumname]
                            </span>
                        </div>
                        <p class="none"></p>
                        <div class="xlmmxcpic-cell">
                            <div class="xlmmxcpic-cell-hd">
                                <img src="{avatar($value[uid], small, true)}">
                            </div>
                            <div class="xlmmxcpic-cell-bd">
                                <h4>$value[username]</h4>
                                <p>{lang update} <!--{date($value[updatetime], 'n-j H:i')}--></p>
                            </div>
                     								<!--{if $value[uid]==$_G[uid]}-->
       <span class="xlmmxcpic-cell-fr" style="padding-top:3px; position:relative; z-index:7;">
                                <a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$value[albumid]">�༭</a>
                                <a href="home.php?mod=spacecp&ac=upload&albumid=$value[albumid]">��ͼ</a>
                            </span>
                								<!--{/if}-->
                        </div>
    </div>
       							<!--{/loop}-->
                     </div>
       						<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
						<!--{else}-->
						<div class="emp">{lang no_album}</div>
						<!--{/if}-->
		
					<!--{else}-->
		
						<!--{if $searchkey}-->
						<p class="mbw">{lang follow_search_album} <span style="color: red; font-weight: 700;">$searchkey</span> {lang doing_record_list}</p>
						<!--{/if}-->
		
						<!--{if $pricount}-->
						<p class="mbw">{lang hide_album}</p>
						<!--{/if}-->
		
						<!--{if $count}-->
				<div class="xlmmxcpic">
							<!--{loop $list $key $value}-->
							<!--{eval $pwdkey = 'view_pwd_album_'.$value['albumid'];}-->
<div onclick="window.location='home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]'" class="xlmmxcpic-item">
                        <div class="xlmmxcpic-item-img">
                     <!--{if $value[pic]}-->       <img src="$value[pic]" alt=""><!--{/if}-->
                        <!--{if $value[picnum]}--> <i class="xlmmxcnum bcolour">$value[picnum] P</i><!--{/if}-->
                 <span>
                                $value[albumname]
                            </span>
                        </div>
                        <p class="none"></p>
                        <div class="xlmmxcpic-cell">
                            <div class="xlmmxcpic-cell-hd">
                                <img src="{avatar($value[uid], small, true)}">
                            </div>
                            <div class="xlmmxcpic-cell-bd">
                                <h4>$value[username]</h4>
                                <p>{lang update} <!--{date($value[updatetime], 'n-j H:i')}--></p>
                            </div>
                     								<!--{if $value[uid]==$_G[uid]}-->
       <span class="xlmmxcpic-cell-fr" style="padding-top:3px; position:relative; z-index:7;">
                                <a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$value[albumid]">�༭</a>
                                <a href="home.php?mod=spacecp&ac=upload&albumid=$value[albumid]">��ͼ</a>
                            </span>
                								<!--{/if}-->
                        </div>
    </div>
       							<!--{/loop}-->
  							<!--{if $space[self] && $_GET['view']=='me'}-->
<a href="home.php?mod=space&uid=$value[uid]&do=album&id=-1" class="xlmmxcpic-item">
                        <div class="xlmmxcpic-item-img">
<img src="{IMGDIR}/nophoto.gif" alt="{lang default_album}" />
                            <span>
{lang default_album}
                            </span>
                        </div>
                        <p class="none"></p>
                        <div class="xlmmxcpic-cell">
                            <div class="xlmmxcpic-cell-hd">
                                <img src="{avatar($value[uid], small, true)}">
                            </div>
                            <div class="xlmmxcpic-cell-bd">
                                <h4>$value[username]</h4>
                                <p>{lang update} <!--{date($value[updatetime], 'n-j H:i')}--></p>
                            </div>
  
                          </div>
</a>
							<!--{/if}-->
                     </div>
						<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
						<!--{else}-->
							<!--{if $space[self] && $_GET['view']=='me'}-->
				<div class="xlmmxcpic">
<a href="home.php?mod=space&uid=$value[uid]&do=album&id=-1" class="xlmmxcpic-item">
                        <div class="xlmmxcpic-item-img">
<img src="{IMGDIR}/nophoto.gif" alt="{lang default_album}" />
                            <span>
{lang default_album}
                            </span>
                        </div>
                        <p class="none"></p>
                        <div class="xlmmxcpic-cell">
                            <div class="xlmmxcpic-cell-hd">
                                <img src="{avatar($value[uid], small, true)}">
                            </div>
                            <div class="xlmmxcpic-cell-bd">
                                <h4>$value[username]</h4>
                                <p>{lang update} <!--{date($value[updatetime], 'n-j H:i')}--></p>
                            </div>
  
                          </div>
</a>
	                     </div>
						<!--{else}-->
								<div class="emp">{lang no_album}</div>
							<!--{/if}-->
						<!--{/if}-->
		
					<!--{/if}-->
					</div>
		
		

		<!--{if $diymode}-->
					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="sd">
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>

<script type="text/javascript">
function fuidgoto(fuid) {
	var parameter = fuid != '' ? '&fuid='+fuid : '';
	window.location.href = 'home.php?mod=space&do=album&view=we'+parameter;
}
</script>
            <div style="height:1.1rem;"></div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->












