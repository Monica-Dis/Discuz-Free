window._bd_share_main.F.module("share/combine_api",function(e,t,n){var r=e("base/tangram").T,i=e("base/class").Class,s=e("share/api_base");t.CombineApi=i.create(function(e){var t=this,n=null,r=null;t.setApi=function(e,t){n=e,r=t},t._init=function(){n&&r&&n.on("sharecompleted",function(e){})}},s.ApiBase)});


