window._bd_share_main.F.module("trans/trans_bdysc",function(e,t){var n=function(e){var t={url:e.url,title:e.title};if(window.baiduSC_yaq4d3elabjnvmijccc1zuo3o4yeizck)window.baiduSC_yaq4d3elabjnvmijccc1zuo3o4yeizck.go(t);else{window.baiduSC_yaq4d3elabjnvmijccc1zuo3o4yeizck={callback:function(){this.go(t)}};var n=document.createElement("script"),r="http://s.wenzhang.baidu.com/js/pjt/content_ex/page/";r+="bookmark.js?s=baidu_fenxiang&_t="+Math.random(),n.src=r,document.getElementsByTagName("body")[0].appendChild(n)}};t.run=n});


