
var POPMENU = new Object;
var popup = {

	open : function(pop, type, url) {
		if(typeof pop == 'string' && pop.indexOf("messagetext") >= 0){
			var output = jQuery(pop).find('#messagetext p').html();
			var output_no = output.indexOf("if(typeof");
			pop = (output_no > 0 ? output.substring(0, output_no) : output);
			converter = null;
			type = 'alert';
		}
		if(type == 'alert') {
			var xlmm_rec_indexOf = pop.indexOf("if(jQuery(");
			if(xlmm_rec_indexOf >= 0){
				pop = pop.substr(0, xlmm_rec_indexOf);
			}

			jQuery('#xlmm_rec_alert').off().css({'display' : 'none', 'left' : '0'}).attr('class', '').text(jQuery('<div>'+pop+'</div>').text()).css({'display' : 'block', 'left' : ((jQuery(window).width() - jQuery('#xlmm_rec_alert').outerWidth()) / 2)})
			setTimeout(function() {
				jQuery('#xlmm_rec_alert').addClass("xlmm_rec_alert_show").on('webkitTransitionEnd transitionend', function() {
					jQuery(this).off();
					setTimeout(function() {
						jQuery('#xlmm_rec_alert').removeClass('xlmm_rec_alert_show').addClass("xlmm_rec_alert_hide").on('webkitTransitionEnd transitionend', function() {
							jQuery(this).off().removeClass('xlmm_rec_alert_hide').text('').css({'display' : 'none', 'left' : '0'});
						});		
					}, '20');
				});
			}, '20');
			return false;
		}

	},
};


function xlmm_rec_menu_hide() {
	if(xlmm_rec_MENU_on == 1){
		if(jQuery('.wxlist_bottom_box').length > 0) {
			jQuery('.wxlist_bottom_box').css('width', '0');
		}
		return false;
	}
}


var xlmm_rec_recommend_key = 0;
function xlmm_rec_recommend_addkey(){
	if(jQuery('.xlmm_rec_recommend_addkey').length > 0) {
		jQuery('.xlmm_rec_recommend_addkey').off('click').on('click', function() {
		if(xlmm_rec_recommend_key == 0){
			xlmm_rec_recommend_key = 1;
			var xlmm_rec_zhankeys = jQuery('.wxlist_bottom_box').length;
			var re_tids = jQuery(this).attr('tid');
			var re_tid = jQuery('.num-all_'+ re_tids);
			var xlmm_rec_retidbox = jQuery(this);
			jQuery.ajax({
				type : 'GET',
				url : jQuery(this).attr('href') + '&inajax=1',
				dataType : 'xml',
			})
			.success(function(s) {
				var s = s.lastChild.firstChild.nodeValue;
				if(s.indexOf("�������۹�������") >= 0){
				jQuery.ajax({
					type : 'GET',
					url : 'forum.php?mod=misc&action=recommend&handlekey=recommend_add&do=add&tid='+re_tids+'&inajax=1',
					dataType : 'xml',
				}).success(function(v) {
					popup.open('�������۹�������', 'alert');
				});
				}else if(s.indexOf("�����������Լ�������") >= 0){
					popup.open('�����������Լ�������', 'alert');
				}else if(s.indexOf("�������ۻ���������") >= 0){
					popup.open('�������ۻ���������', 'alert');
				}else if(s.indexOf("'recommendv':'+" + allowrecommend + "'") >= 0){
					var b = [], r;
					r = s.match(/\'recommendc\':\'(.*?)\'/);
					if(r != null){
						b['recommendc'] = r[1];
					}else{
						b['recommendc'] = 0;
					}
					r = s.match(/\'daycount\':\'(.*?)\'/);
					if(r != null){
						b['daycount'] = r[1];
					}else{
						b['daycount'] = 0;
					}
					if(xlmm_rec_zhankeys){
						upzhanlist(re_tids);
					}else if(Number(re_tid.text()) == Number(b['recommendc'])){
						re_tid.text((Number(b['recommendc']) + Number(allowrecommend)));
					}
					xlmm_rec_retidbox.addClass('f_wb');
					popup.open('�������۳ɹ�' + (b['daycount'] ? ', �����컹������ ' + (b['daycount'] - 1) + ' ��' : ''), 'alert');					
				}else if(s.indexOf("window.location.href = 'member.php?mod=logging&action=login'") >= 0){
					window.location.href = 'member.php?mod=logging&action=login';
				}else{
					popup.open('û������Ȩ�޻����Ӳ�����', 'alert');
				}
				setTimeout(function() {
					xlmm_rec_recommend_key = 0;
				}, 500);
			});
			}
			return false;
		});
	}
}





