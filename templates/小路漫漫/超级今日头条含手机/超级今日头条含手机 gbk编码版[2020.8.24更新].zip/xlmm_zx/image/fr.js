
jQuery.noConflict();
jQuery(window).load(function(){
	setTimeout(function(){
		if($('rlboxs') && !($('samplepanel') && $('controlpanel')) && !(BROWSER.ie && BROWSER.iemode < 7)){
			var xlmm_rollid = jQuery('#rlboxs'), xlmm_rollendid = jQuery('.pablbox'), xlmm_rbox = jQuery('.allboxs');
			if(xlmm_rbox.height() < xlmm_rollendid.height()){
				var startbottom = xlmm_rollid.offset().top + xlmm_rollid.height();
				xlmm_rbox.height(xlmm_rollendid.height());
				function rlboxs(){
					var scrollbottom = jQuery(window).scrollTop() + jQuery(window).height();
					if (scrollbottom > startbottom && jQuery(window).scrollTop() > 30) {
						var endbottom = xlmm_rollendid.offset().top + xlmm_rollendid.height();
						if (scrollbottom < endbottom) {
							xlmm_rollid.removeClass('pabro').addClass('pabrl');
						} else {
							xlmm_rollid.removeClass('pabrl').addClass('pabro');
						}
					} else {
						xlmm_rollid.removeClass('pabrl pabro');
					}
				}
				jQuery(window).scroll(function() {
					rlboxs();
				});
				rlboxs();
			}
		}
	}, 500);
});




