<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
{if  $_GET['from']}
<!--{if $_G[setting][homepagestyle]}-->
	<!--{subtemplate home/space_header}-->
	<div id="ct" class="ct2 wp cl">
		<div class="mn">
			<div class="bm">
				<div class="bm_h">
					<h1 class="mt">{lang memcp_profile}</h1>
				</div>
			<div class="bm_c">
<!--{else}-->
	<!--{template common/header}-->
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<!--{template home/space_menu}-->
	<div id="ct" class="ct1 wp cl">
		<div class="mn">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<div class="bm_c">
<!--{/if}-->

				<!--{subtemplate home/space_profile_body}-->
		
				<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->
				</div>
			</div>
			<!--{if $_G[setting][homepagestyle]}-->
		</div>
		<div class="sd">
			<!--{subtemplate home/space_userabout}-->
		<!--{/if}-->
	</div>
</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->
<!--{template common/footer}-->
{else}
<script language="JavaScript">
    self.location='home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread&wz=1';
</script>
{/if}

