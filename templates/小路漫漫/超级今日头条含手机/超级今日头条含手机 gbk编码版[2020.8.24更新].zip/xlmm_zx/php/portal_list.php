<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: forum_guide.php 34066 2013-09-27 08:36:09Z nemohou $
 *      QQ dism.taobao.com ����޸� 2018.11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$article_count = C::t('portal_article_count')->fetch($value['aid']); if($article_count) $value = array_merge($article_count, $value); 
		if( $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2 ) {
$xlmm_all=DB::result_first("select content from ".DB::table("portal_article_content")." where aid='$value[aid]'");
preg_match_all("/<img.*?src=[\'|\"](.*?(?:[\.gif.*?[\/]?|\.jpg.*?[\/]?|\.jpeg.*?[\/]?|\.png.*?[\/]?|\.GIF.*?[\/]?|\.JPG.*?[\/]?|\.JPEG.*?[\/]?|\.PNG.*?[\/]?]))[\'|\"].*?[\/]?>/", $xlmm_all, $xlmmout);
       $xlmmoutimg = $xlmmout[1];
	} else {
  $xlmmoutimg = DB::fetch_all("SELECT attachid,attachment,aid,isimage FROM ".DB::table('portal_attachment')." WHERE aid='$value[aid]' AND isimage=1 ORDER BY attachid");
                  } 
           $xlmmal = count($xlmmoutimg);
 ?>



