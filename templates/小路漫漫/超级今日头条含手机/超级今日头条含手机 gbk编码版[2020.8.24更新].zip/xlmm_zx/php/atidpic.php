<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: forum_guide.php 34066 2013-09-27 08:36:09Z nemohou $
 *      QQ dism.taobao.com ����޸� 2019.01
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

 $xlmmfxlh=unserialize($thread['fields']);$xlmmfxlh['dateline'] = date("$shownums[dateformat]",$xlmmfxlh['dateline']) ;	
 	if( $thread[idtype] == 'tid' ) {
 include_once libfile('function/post');

$post = C::t('forum_post')->fetch_all_by_tid_position($thread['posttableid'],$thread['id'],1);
$post = array_shift($post);
$xiaolu['fmessage'] = messagecutstr($post['message'], 200);
   $xlmmtutab='forum_attachment_'.substr($thread['id'], -1);
   $xlmmattach = DB::fetch_all("SELECT a.attachment,a.aid,a.remote,b.pid FROM ".DB::table($xlmmtutab)." a left join ".DB::table("forum_post")." b on b.pid=a.pid WHERE a.tid='$thread[id]' AND a.isimage!='0' AND b.first=1");
                     $xlmmal =  C::t('forum_attachment_n')->count_image_by_id('tid:'.$post['tid'], 'pid', $post['pid']);
                            preg_match_all('/(\\[img\\]|\\[img=\\d{1,4}[x|\\,]\\d{1,4}\\]|<img.*?src=")\\s*([^\\[\\<\\r\\n]+?)\\s*(\\[\\/img\\]|".*>)/is', $post['message'], $xlmmpic, PREG_SET_ORDER);
                        foreach ($xlmmpic as $img) {
                            $xlmmattach[] = array('attachment' => $img[2]);
                            $xlmmal++;
                            if ($xlmmal >= 4) {
                                break;
                            }
                        }

$attachment = $attach['attachment'];
	} elseif($thread[idtype] == 'aid'){ 
$xlmmfxlh[author] = $xlmmfxlh[username];
$xlmmfxlh[authorid] = $xlmmfxlh[uid];
$xlmmfxlh[views] = $xlmmfxlh[viewnum];
$xlmmfxlh[replies] = $xlmmfxlh[commentnum];
 $xlmmfxlh[forumname] = $xlmmfxlh[catname];
 $xlmmfxlh[forumurl] = $xlmmfxlh[caturl];
 $xlmmoutimg = DB::fetch_all("SELECT attachid,attachment,aid,isimage FROM ".DB::table('portal_attachment')." WHERE aid=$thread[id] AND isimage=1 ORDER BY attachid");
           $xlmmal = count($xlmmoutimg);
                        }



