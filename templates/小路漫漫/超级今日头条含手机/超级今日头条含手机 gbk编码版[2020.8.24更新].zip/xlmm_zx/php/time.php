<?php  
function xlmmtime($date)
{  
    $str = '';  
    $timer = strtotime($date);  
    $diff = $_SERVER['REQUEST_TIME'] - $timer;  
    $day = floor($diff / 86400);  
	  $free = $diff % 86400;  
    $year = floor($diff / 60 / 60 / 24 / 365);    
      $m = floor($diff / 2592000);  
  if($year){ 
        return $year.'��ǰ'; 
    }    
 elseif($m>=1 && $m < 12){        
        return $m.'����ǰ'; 
    } 
		  elseif($day > 0) 
    {  
        return $day."��ǰ";  
    }
    else
    {  
        if($free>0)
        {  
            $hour = floor($free / 3600);  
            $free = $free % 3600;  
                if($hour>0)
                {  
                    return $hour."Сʱǰ";  
                }
                else
                {  
                    if($free>0)
                    {  
                        $min = floor($free / 60);  
                        $free = $free % 60;  
                        if($min>0)
                        {  
                            return $min."����ǰ";  
                        }
                        else
                        {  
                            if($free>0)
                            {  
                                return $free."��ǰ";  
                            }
                            else
                            {  
                                return '�ո�';  
                            }  
                       }  
                    }
                    else
                    {  
                        return '�ո�';  
                    }  
               }  
       }
       else
       {  
           return '�ո�';  
       }  
    }  
}  
?>



