<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: portal_comment.php 33660 2013-07-29 07:51:05Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$perpage = $_G['cache']['plugin']['xlmm_tt']['tiaoshu'] ;
$page = intval($_GET['page']);
if($page<1) $page = 1;
$start = ($page-1)*$perpage;
	$pricount = 0;

$multi = '';
$xlfid = $_G['cache']['plugin']['xlmm_tt']['xlmmfid'] ;
	$xlmmfids=$xlfid ;
	$xlmmtid= $_G['cache']['plugin']['xlmm_tt']['xlmmtid'] ;
	if($_GET['order']=='dateline' || $_GET['order']=='views' || $_GET['order']=='replies' || $_GET['order']=='digest'){
        $order= $_GET['order'];
}else{
     	if($_G['cache']['plugin']['xlmm_tt']['xlmmtzpx']== 1) {
   $order= 'lastpost';
}
     	if($_G['cache']['plugin']['xlmm_tt']['xlmmtzpx']== 2) {
   $order= 'dateline';
}
     	if($_G['cache']['plugin']['xlmm_tt']['xlmmtzpx']== 3) {
   $order= 'views';
}
     	if($_G['cache']['plugin']['xlmm_tt']['xlmmtzpx']== 4) {
   $order= 'replies';
}
     	if($_G['cache']['plugin']['xlmm_tt']['xlmmtzpx']== 5) {
   $order= 'digest';
}
}
     	if($_G['cache']['plugin']['xlmm_tt']['xlmmwtp']== 1) {
$xlmmwt = 'and attachment=2' ;
}

$count = DB::result_first("select count(*)  FROM ".DB::table("forum_thread")." WHERE fid NOT IN(" . $xlmmfids . ") and tid NOT IN(" . $xlmmtid . ")  and displayorder>=0 $xlmmwt");
	if($count) {
				$grids['newthread'] = DB::fetch_all("SELECT subject,fid,tid,readperm,price,special,authorid,author,views,replies,dateline,digest FROM ".DB::table('forum_thread')." WHERE fid NOT IN(" . $xlmmfids . ") and tid NOT IN(" . $xlmmtid . ")  and displayorder>=0 $xlmmwt  ORDER BY `$order` DESC LIMIT $start , $perpage");
	$_G['forum_colorarray'] = array('', '#EE1B2E', '#EE5023', '#996600', '#3C9D40', '#2897C5', '#2B65B7', '#8F2A90', '#EC1282');
	foreach($grids as $type => $gridthreads) {
			foreach($gridthreads as $key => $gridthread) {
				$gridthread['dateline'] = str_replace('"', '\'', dgmdate($gridthread['dateline'], 'u', '9999', getglobal('setting/dateformat')));
				$gridthread['lastpost'] = str_replace('"', '\'', dgmdate($gridthread['lastpost'], 'u', '9999', getglobal('setting/dateformat')));
				if($gridthread['highlight'] && $_G['setting']['grid']['highlight']) {
					$string = sprintf('%02d', $gridthread['highlight']);
					$stylestr = sprintf('%03b', $string[0]);

					$gridthread['highlight'] = ' style="';
					$gridthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
					$gridthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
					$gridthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
					$gridthread['highlight'] .= $string[1] ? 'color: '.$_G['forum_colorarray'][$string[1]] : '';
					$gridthread['highlight'] .= '"';
				} else {
					$gridthread['highlight'] = '';
				}
				if($_G['setting']['grid']['textleng']) {
					$gridthread['oldsubject'] = dhtmlspecialchars($gridthread['subject']);
				}

				$grids[$type][$key] = $gridthread;
			}
}
}

$multi = multi($count, $perpage, $page, "portal.php?mod=portal");



?>



