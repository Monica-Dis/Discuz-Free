<?php
/*xlmm*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$xlmmattach= $xlmmimg;

$dst_w = 230; 
$dst_h = 230; 

list($src_w,$src_h)=getimagesize($xlmmattach);  // ��ȡԭͼ�ߴ�
 
$dst_scale = $dst_h/$dst_w; //Ŀ��ͼ�񳤿���
$src_scale = $src_h/$src_w; // ԭͼ������
 
if ($src_scale>=$dst_scale){  // ����
    $w = intval($src_w);
    $h = intval($dst_scale*$w);
 
    $x = 0;
    $y = ($src_h - $h)/3;
} else { // ����
    $h = intval($src_h);
    $w = intval($h/$dst_scale);
 
    $x = ($src_w - $w)/2;
    $y = 0;
}
 
// ����
    $source_info   = getimagesize($xlmmattach);
    $source_mime   = $source_info['mime'];

    switch ($source_mime)
    {
        case 'image/gif':
            $source_image = imagecreatefromgif($xlmmattach);
            break;

        case 'image/jpeg':
            $source_image = imagecreatefromjpeg($xlmmattach);
            break;

        case 'image/png':
            $source_image = imagecreatefrompng($xlmmattach);
            break;

        default:
            return false;
            break;
    }





$source=imagecreatefromjpeg($xlmmattach);
$croped=imagecreatetruecolor($w, $h);
imagecopy($croped, $source_image,0, 0, $x, $y, $src_w, $src_h);
 
// ����
$scale = $dst_w / $w;
$target = imagecreatetruecolor($dst_w, $dst_h);
$final_w = intval($w * $scale);
$final_h = intval($h * $scale);
imagecopyresampled($target, $croped, 0, 0, 0, 0, $final_w,$final_h, $w, $h);
 
// ����
 $xlmmimgurl='template/xlmm_zx/attachment/'.basename($xlmmimg); 
 imagejpeg($target, "$xlmmimgurl.jpg");
imagedestroy($target);

?>



