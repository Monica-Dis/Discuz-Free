<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{subtemplate common/header_common}-->
	<!--{if in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
	<meta name="application-name" content="$_G['setting']['bbname']" />
	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
	<!--{/if}-->
	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
<link rel="stylesheet" href="template/xlmm_zx/portal/list/header.css" />
	{if $_G['basescript'] == 'portal' && CURMODULE == 'index' || $_G['basescript'] == 'portal' && CURMODULE == 'list' || $_G['basescript'] == 'group' || in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}
 	<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmtthstyle']}-->
<style>.wtopbar .tb-item {border-left: 1px solid #3a3a3a !important ;}.wtopbar{ background-color: #222 !important}</style>
<!--{/if}-->
<link rel="stylesheet" href="template/xlmm_zx/portal/list/xlmm-ttlist.css" />
{/if}
	{if $_G['basescript'] == 'portal' && CURMODULE == 'view'}
<link rel="stylesheet" href="template/xlmm_zx/portal/list/xlmm-ttview.css" />
{/if}
<script src="template/xlmm_zx/image/jquery-1.8.3.min.js?{VERHASH}"></script>
     <script type="text/javascript">
     var jQ = jQuery.noConflict();</script>
<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'portal'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<link rel="stylesheet" type="text/css" id="diy_common" href="{$_G['setting']['csspath']}{STYLEID}_css_diy.css?{VERHASH}" />
	<!--{/if}-->
</head>

<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if}" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<!--{template common/header_diy}-->
	<!--{/if}-->
	<!--{if check_diy_perm($topic)}-->
		<!--{template common/header_diynav}-->
	<!--{/if}-->
	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
		$diynav
	<!--{/if}-->
	<!--{if empty($topic) || $topic['useheader']}-->
		<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
			<div class="xi1 bm bm_c">
			    {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a>
			</div>
		<!--{/if}-->
		<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
			<div id="shortcut">
				<span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span>
				{lang shortcut_notice}
				<a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a>

			</div>
			<script type="text/javascript">setTimeout(setShortcut, 2000);</script>
		<!--{/if}-->
 <!--{if check_diy_perm($topic)}-->
						$diynav
					<!--{/if}-->



 					<!--{eval $mnid = getcurrentnav();}-->
		<!--{ad/headerbanner/wp a_h}-->
 <div class="y-wrap">
			<!--{hook/global_cpnav_top}-->
<!-- ����ͷ�� -->
<div id="header">
  <div style="height: 34px; background:#505050;">
  <div class="y-box wtopbar"> 
  <ul class="y-left"> 
					<!--{loop $_G['setting']['topnavs'][0] $nav}-->
						<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li class="tb-item">$nav[code] </li><!--{/if}-->
					<!--{/loop}-->
			   				{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}{else}<li class="tb-item"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" title="ͼƬģʽ" style="color:red">ͼƬģʽ</a></li>{/if}
		<li class="tb-item" style=" background:#FFFFFF; margin-top:5px; margin-left:10px"><!--{hook/global_cpnav_extra1}--> </li>
 	<style>
.xlmmtqyb li { padding-top:0px !important;margin-top:0px !important;  }
.xlmmtqyb li iframe{ padding-top:6px; width:144px !important;}
</style>
<em class="xlmmtqyb z"> $_G['cache']['plugin']['xlmm_tt']['xlmmtq'] </em>
      	<!--{if $_G['basescript'] == 'portal' && CURMODULE == 'list' || $_G['basescript'] == 'portal' && CURMODULE == 'view'  }-->
    				<!--{if ($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])}-->
				<li class="tb-item"><a href="portal.php?mod=portalcp&ac=article&catid=$cat[catid]">���������¡�</a></li>
				<!--{/if}-->
				<!--{/if}-->
   
   </ul>  
   <ul class="y-right"> 
                        {if $_G['uid']}
 <li class="xlmmbd tb-item " style="margin-top:0" >
		<!--{hook/global_usernav_extra1}--><!--{hook/global_usernav_extra4}--><!--{hook/global_usernav_extra2}--><!--{hook/global_usernav_extra3}--><span></span>
     </li>
  <li class="tb-item userbox">
  <div class="y-box wuserbox" style="padding-right:8px">  
  <div class="y-right username"> 
  <a rel="nofollow" href="home.php?mod=space&uid=$_G[uid]" class="user-head" style="padding:0 8px 0 0;"> <div class="user-image">{avatar($_G[uid],small)}</div> <span>{$_G[member][username]}{if $_G[member][newprompt] || $_G[member][newpm]}
{eval $newxx = $_G[member][newpm] + $_G[member][newprompt];}<i style="color:red;text-align:center;font-size:14px;line-height:1; margin-left:5px;padding:2px;border-radius:2px">$newxx</i>{/if}</span> </a> 
  <div class="user-layer"> 
  <ul> 
                          <li><a target="_blank" href="home.php?mod=space&do=notice" rel="nofollow"><span>�鿴��Ϣ</span></a></li>
                      <li><a target="_blank" href="home.php?mod=space&do=favorite&view=me" rel="nofollow"><span>�ҵ��ղ�</span></a></li>
                        <li><a target="_blank" href="home.php?mod=space&uid=$_G[uid]&do=thread&view=me&from=space" rel="nofollow"><span>�ҵ�����</span></a></li>
                        <li><a target="_blank" href="home.php?mod=spacecp"><span>�˺�����</span></a></li>
 								<!--{hook/global_usernav_extra3}-->
								<!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
									<li><a href="portal.php?mod=portalcp"><span><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></span></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
									<li><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank"><span>{lang forum_manager}</span></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']}-->
									<li><a href="admin.php?frames=yes&action=cloud&operation=applist" target="_blank"><span>{lang cloudcp}</span></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
									<li><a href="admin.php" target="_blank"><span>{lang admincp}</span></a></li>
								<!--{/if}-->
<!--{hook/global_myitem_extra}-->
								<!--{hook/global_usernav_extra4}-->
                       <li id="tx_b_l4" class="tuichu"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" rel="nofollow"><span>�˳���¼</span></a></li>
  </ul> </div> </div>  </div>
   </li>              
    {else}
 <li class="logincj z">
 <!--{hook/global_login_extra}-->
      </li>
 <li class="tb-item userbox"><div class="y-box wuserbox">   <div class="nav-login"> <a href="member.php?mod=logging&amp;action=login" onClick="showWindow('login', this.href)"> <span>��¼</span> </a></div></div> </li> 
   <li class="tb-item"> <a href="member.php?mod={$_G[setting][regname]}" target="_blank">ע��</a> </li>
                   {/if}
					<li class="tb-item"><!--{hook/global_cpnav_extra2}--></li>
						<!--{loop $_G['setting']['topnavs'][1] $nav}-->
						<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li class="tb-item more">$nav[code]</li><!--{/if}-->
					<!--{/loop}-->
   <li class="tb-item more"> <a href="javascript:;">����</a> 
   <div class="layer"> 
   <ul> 
						<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}{/if}$nav[nav]></li><!--{/if}-->
						<!--{/loop}-->
</ul> </div> </li> 
   <!--{if !empty($_G['style']['extstyle'])}-->  <li class="y">
   <a href="javascript:;" class="xlmmfqh"> <img src="template/xlmm_zx/image/fgicon.png" width="34" height="34">  </a>
</li><!--{/if}-->
 </ul> 
   
   
   </div>
   
   
   
   
   </div>
  
</div>
    <div class="clearfix"></div>


	{if $_G['basescript'] == 'forum' && CURMODULE == 'viewthread'}
<style>
#diy-tg { z-index:99}
#header {margin-bottom: 0;}
.middlebar {position: relative;height: 58px;background: #fff;box-shadow: 0 1px 4px 0 rgba(0,0,0,.12); overflow:hidden;}
.wp, .middlebar-inner {width: 1170px !important;margin: 0 auto;}
.middlebar .middlebar-inner .logo-box {}
.logo-link {line-height: 58px;height:58px;padding-top:15px;}
.logo-link img {width: 108px;height: 27px;}

.middlebar .middlebar-inner .chinese-tag {font-size: 16px;margin-left: 20px;line-height: 58px;}
.middlebar .middlebar-inner .chinese-tag a {color: #444;}
.middlebar .middlebar-inner .chinese-tag span {color: #999;}

.tt-input {position: relative;font-size: 14px;display: inline-block;width: 100%;}
.tt-input-group {line-height: normal;display: inline-table;width: 100%;border-collapse: separate;}
.search-wrap .tt-input__inner {height: 44px;}
.tt-input-group--append .tt-input__inner, .tt-input-group__prepend {border-top-right-radius: 0;border-bottom-right-radius: 0;}
.tt-input-group > .tt-input__inner {vertical-align: middle;display: table-cell;}
.tt-input__inner, .tt-select-dropdown, .tt-select-dropdown__item, .tt-select .tt-tag, .tt-tag, .tt-textarea__inner {box-sizing: border-box;}
.tt-input__inner {-webkit-appearance: none;-moz-appearance: none;appearance: none;background-color: #f5f6f7;border-radius: 4px;border-top-right-radius: 4px;border-bottom-right-radius: 4px;border: 1px solid #e8e8e8;color: #1f2d3d;display: block;font-size: inherit;height: 40px;outline: 0;padding: 3px 10px;transition: border-color .2s cubic-bezier(.645,.045,.355,1);width: 100%;}
.tt-input__inner, .tt-textarea__inner {background-image: none;box-sizing: border-box;}
button, input, select, textarea {font-family: inherit;font-size: inherit;line-height: inherit;}

.tt-input-group__append .tt-button, .tt-input-group__append .tt-input, .tt-input-group__prepend .tt-button, .tt-input-group__prepend .tt-input {font-size: inherit;}
.tt-input-group__append .tt-button, .tt-input-group__append .tt-select .tt-input__inner, .tt-input-group__append .tt-select:hover .tt-input__inner, .tt-input-group__prepend .tt-button, .tt-input-group__prepend .tt-select .tt-input__inner, .tt-input-group__prepend .tt-select:hover .tt-input__inner {border-color: transparent;border-top-color: transparent;border-bottom-color: transparent;background-color: transparent;color: inherit;border-top: 0;border-bottom: 0;}
.tt-input-group__append .tt-button, .tt-input-group__append .tt-select, .tt-input-group__prepend .tt-button, .tt-input-group__prepend .tt-select {display: block;margin: -10px;}
[type="reset"], [type="submit"], button, html [type="button"] {-webkit-appearance: button;}
.tt-button, .tt-button-group, .tt-dropdown {display: inline-block;}
.tt-button {display: inline-block;line-height: 1;white-space: nowrap;cursor: pointer;background: #fff;background-color: rgb(255, 255, 255);border: 1px solid #bfcbd9;border-top-width: 1px;border-bottom-width: 1px;border-top-style: solid;border-bottom-style: solid;border-top-color: rgb(191, 203, 217);border-right-color: rgb(191, 203, 217);border-bottom-color: rgb(191, 203, 217);border-left-color: rgb(191, 203, 217);color: #1f2d3d;-webkit-appearance: none;text-align: center;box-sizing: border-box;outline: 0;margin: 0;-moz-user-select: none;-webkit-user-select: none;-ms-user-select: none;padding: 10px 15px;font-size: 14px;border-radius: 4px;}
.tt-autocomplete .tt-input-group__append {border: 1px solid #208eda;background-color: #208eda;color: #fff;position: relative;left: -1px;padding: 0 18px;}
.tt-input-group__append {border-left: 0;}
.tt-input-group--prepend .tt-input__inner, .tt-input-group__append {border-top-left-radius: 0;border-bottom-left-radius: 0;}
.tt-input-group__append, .tt-input-group__prepend {color: #97a8be;vertical-align: middle;display: table-cell;position: relative;border: 1px solid #e8e8e8;border-radius: 4px;border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding: 0 10px;width: 1%;white-space: nowrap;}

</style>

<div class="middlebar">
  <div class="y-box middlebar-inner">
      <a class="logo-link y-left" href="/"><img class="logo" src="template/xlmm_zx/portal/list/logo.png">
      </a>  
      <div class="z chinese-tag">
			<a href="./">��ҳ</a>
                            /
			<a href="forum.php?mod=forumdisplay&fid=$_G[fid]">$_G['forum'][name]</a>
                /
        <span class="text">����</span>
      </div>
    <div class="y">
   <div class="tt-autocomplete" style="margin-top:9px; width:340px;">
	      <form id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" onSubmit="searchFocus($('scbar_txt'))" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
	<div class="tt-input tt-input-group tt-input-group--append">
 			        <input type="hidden" name="mod" id="scbar_mod" value="{if $_G['basescript'] == 'portal'}portal{elseif $_G['basescript'] == 'group'}group{else}forum{/if}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="srchtype" value="title" />
        <input type="hidden" name="srhfid" value="" />
        <input type="hidden" name="srhlocality" value="forum::mypage" />
              <input type="hidden" name="searchsubmit" value="yes"/>
<input name="srchtxt" value="" placeholder="������Ҫ����������" autocomplete="off" class="tt-input__inner" type="text"><!---->
		<div class="tt-input-group__append">
			<button  type="submit" href="javascript:;" class="tt-button tt-button--default"><span>����</span></button>
		</div>
	</div> </form> 
</div>

    </div>
  </div>
</div>
    <div class="clearfix"></div>
{/if}


		<!--{hook/global_header}-->
	<!--{/if}-->
	<div id="wp" class="wp">
				<!--{ad/subnavbanner/a_mu}-->
  	<!--{else}-->
 
    
    <meta name="application-name" content="$_G['setting']['bbname']" />
	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
			<!--{if $_G['basescript'] == 'group' && $action == 'index' && $status != 2 && $status != 3}-->
				<!--{subtemplate group/group_index}-->
  <!--{else}-->
	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
	<!--{/if}-->
	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
{if $_GET['mod'] == 'viewthread'}{else}<link rel="stylesheet" id="css_widthauto" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_widthauto.css?{VERHASH}' />{/if}
	{if $_G['basescript'] == 'portal' && CURMODULE == 'index' || $_G['basescript'] == 'group' && CURMODULE == 'index'}
<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmmh'] == 1}-->
<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmmh'] == 2}-->
<link rel="stylesheet" href="template/xlmm_zx/portal.css" />
	<!--{/if}-->
	{/if}
<script src="template/xlmm_zx/image/jquery-1.8.3.min.js?{VERHASH}"></script>
     <script type="text/javascript">
     var jQ = jQuery.noConflict();</script>
 <script src="$_G['style']['styleimgdir']/xlmm.js" type="text/javascript"></script>
<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'portal'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
		<style type="text/css">
.livethreadtitle .xst , .xst {
height: 18px;
font: normal 18px/18px "microsoft yahei",tahoma,arial,"Hiragino Sans GB","\5b8b\4f53";
}


	</style>
<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<link rel="stylesheet" type="text/css" id="diy_common" href="{$_G['setting']['csspath']}{STYLEID}_css_diy.css?{VERHASH}" />
	<style type="text/css">
#controlpanel {z-index:600}
#fwin_showblock{z-index:601 !important;}
#button_more_menu{z-index:602 !important;}
	</style>
	<!--{/if}-->
	{if $_G['basescript'] == 'home' }
	<style type="text/css">
.ct2_a{background:#FFFFFF  url("template/xlmm_zx/image/vlineb.png") repeat-y 0 0;}
.mn{background:#FFFFFF ;}
#uhd {padding-top: 10px;border: 0px solid #CCC;border-bottom: none;background: #fff;}
	.ct1 {border: 0px solid #CCC;border-top: none;}	
#uhd .tb {background: #EFEFEF;border-bottom: 1px solid #E9E9E9;margin:18px 10px 0 10px;}
#uhd .tb .a a {border-color: #EFEFEF transparent #FFF;background: #FFF;border-top-width: 2px;font-weight: normal;}
#uhd .tb a {background: transparent;border-color: transparent;font-size: 14px;}
#uhd .avt { margin-right:15px}
.avt img {
	padding: 8px;
	width: 60px;
	height: 60px; border-radius:50px}
</style>
{/if}
	{if $_G['basescript'] == 'forum' && CURMODULE == 'index'}
{/if}
	{if $_G['basescript'] == 'forum' && CURMODULE == 'forumdisplay'}
<script type="text/javascript" src="template/xlmm_zx/qrcode.js"></script>
{/if}
</head>

<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if}" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<!--{template common/header_diy}-->
	<!--{/if}-->
	<!--{if check_diy_perm($topic)}-->
		<!--{template common/header_diynav}-->
	<!--{/if}-->
	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
		$diynav
	<!--{/if}-->
	<!--{if empty($topic) || $topic['useheader']}-->
		<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
			<div class="xi1 bm bm_c">
			    {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a>
			</div>
		<!--{/if}-->
		<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
			<div id="shortcut">
				<span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span>
				{lang shortcut_notice}
				<a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a>

			</div>
			<script type="text/javascript">setTimeout(setShortcut, 2000);</script>
		<!--{/if}-->
	
					<!--{eval $mnid = getcurrentnav();}-->
                 {if $_G['basescript'] == 'member' && CURMODULE == 'logging'}
                 {else}
<div id="hjpassport">
    <div id="pass_c" class="cf">
			<!--{hook/global_cpnav_top}-->
         <ul id="pass_c_l" class="cf">
      					<!--{loop $_G['setting']['topnavs'][0] $nav}-->
						<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li class="common">$nav[code] </li><!--{/if}-->
					<!--{/loop}-->
					<li class="common" style="margin-top:6px;background:#FFFFFF; height:26px; margin-left: 10px; overflow:hidden"><!--{hook/global_cpnav_extra1}--> </li>
      	<!--{if $_G['basescript'] == 'portal' && CURMODULE == 'list' || $_G['basescript'] == 'portal' && CURMODULE == 'view'  }-->
    				<!--{if ($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])}-->
				<li class="common"><a href="portal.php?mod=portalcp&ac=article&catid=$cat[catid]">���������¡�</a></li>
				<!--{/if}-->
				<!--{/if}-->
  </ul>
      <ul id="passport_userinfo"{if $_G['uid']} class="user_logout_block"{/if}>
         				<li class="pass_log cf">	<!--{hook/global_cpnav_extra2}-->
					<!--{loop $_G['setting']['topnavs'][1] $nav}-->
						<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
					<!--{/loop}--></li>
            {if $_G['uid']}
                     <li class="tx pass_x">
                    <div class="tx_t pass_x_t" id="username" onMouseOver="showMenu({'ctrlid':this.id,'ctrlclass':'hover','pos':'34!'})">
                        <a href="home.php?mod=space&uid=$_G[uid]" target="_blank">{avatar($_G[uid],small)}<i class="navatar">{$_G[member][username]}</i></a>
                        <b class="icb2"></b>
                    </div>
                </li>

                <li class="xx pass_x">
                    <div class="xx_t pass_x_t" id="xlmmpm" onMouseOver="showMenu({'ctrlid':this.id,'ctrlclass':'hover','pos':'34!'})">
                        <a href="home.php?mod=space&do=notice" target="_blank" class="icon_pass_xx">&nbsp;<!--{if $_G[member][newprompt] || $_G[member][newpm]}-->
<!--{eval $newxx = $_G[member][newpm] + $_G[member][newprompt];}--><i style="color:#fff;background:red;text-align:center;font-size:12px;line-height:1;position:absolute;top:2px;right:15px;padding:2px;border-radius:2px">$newxx</i><!--{/if}--></a>
	 <b class="icb2"></b>
                    </div>
                </li>
                
               {elseif $_G['basescript'] == 'member' && CURMODULE == 'register' || $_G['basescript'] == 'member' && CURMODULE == 'logging'}
                {else}
         <li class="pass_log cf">
                    <a href="member.php?mod=logging&amp;action=login" onClick="showWindow('login', this.href)"><span>��¼</span></a>
                    <a href="member.php?mod={$_G[setting][regname]}" target="_blank"><span>���ע��</span></a>
                    <i class="split_border"></i>
                </li>
                   {/if}
            
            <li class="wx pass_x">
                <div class="wx_t pass_x_t">
					<a href="javascript:;" id="qmenu" onMouseOver="delayShow(this, function () {showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2});showForummenu($_G[fid]);})"></a>
                </div>
            </li>
     <!--{if !empty($_G['style']['extstyle'])}--> <li class="y" style="margin-right:10px">
   <a href="javascript:;" class="xlmmfqh"> <img src="template/xlmm_zx/image/fgicon.png" width="32" height="32">  </a>
</li><!--{/if}-->
    </ul>
                      {if $_G['uid']}
 <div class="xlmmbd y">
		<!--{hook/global_usernav_extra1}--><!--{hook/global_usernav_extra4}--><!--{hook/global_usernav_extra2}--><!--{hook/global_usernav_extra3}--><i style="line-height: 32px;
margin: 0 5px;">&nbsp;</i>
     </div>
               {elseif $_G['basescript'] == 'member' && CURMODULE == 'register' || $_G['basescript'] == 'member' && CURMODULE == 'logging'}
                 {else}
 <!--{hook/global_login_extra}-->
                    {/if}
   </div>
</div>
                     {if $_G['uid']}
                    <ul class="tx_b pass_x_b" id="username_menu" style="display:none;margin-top:-1px;">
                        <li id="tx_b_l5"><a target="_blank" href="home.php?mod=space&do=favorite&view=me" rel="nofollow"><span>�ҵ��ղ�</span></a></li>
                        <li id="tx_b_l6"><a target="_blank" href="home.php?mod=space&uid=$_G[uid]&do=thread&view=me&from=space" rel="nofollow"><span>�ҵ�����</span></a></li>
                        <li id="tx_b_l2"><a target="_blank" href="home.php?mod=spacecp"><span>�˺�����</span></a></li>
 								<!--{hook/global_usernav_extra3}-->
								<!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
									<li id="tx_b_l2"><a href="portal.php?mod=portalcp"><span><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></span></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
									<li id="tx_b_l2"><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank"><span>{lang forum_manager}</span></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']}-->
									<li id="tx_b_l2"><a href="admin.php?frames=yes&action=cloud&operation=applist" target="_blank"><span>{lang cloudcp}</span></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
									<li id="tx_b_l2"><a href="admin.php" target="_blank"><span>{lang admincp}</span></a></li>
								<!--{/if}-->
<!--{hook/global_myitem_extra}-->
								<!--{hook/global_usernav_extra4}-->
                       <li id="tx_b_l4" class="tuichu"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" rel="nofollow"><span>�˳���¼</span></a></li>
                    </ul>
                    {/if}
 <!--{if check_diy_perm($topic)}-->
						$diynav
					<!--{/if}-->

<div class="header_wrap">
		<!--{ad/headerbanner/wp a_h}-->
    <div class="header clearfix">
        
        <h1><!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}--></h1>
        
        
        <ul class="main_nav" id="hideSearchBox">
													<!--{eval $k = 0;}-->
		<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li class="navspan xlmmnv$k{if $mnid == $nav[navid]} hover{/if}"$nav[nav]></li><!--{/if}-->
			<!--{eval $k++}-->
<!--{eval if($k==5) break;}-->
			<!--{/loop}-->
            <li class="icons more_functions " id="xlmmhm" onMouseOver="showMenu({'ctrlid':this.id,'ctrlclass':'hover','duration':2})"><a href="javascript:;">����<span>����</span></a>      			
 </li>
      <li class="search_league">
                <div class="search_box">
             <form class="xlmm-hd-search" id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" onSubmit="searchFocus($('scbar_txt'))" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
			        <input type="hidden" name="mod" id="scbar_mod" value="{if $_G['basescript'] == 'portal'}portal{elseif $_G['basescript'] == 'group'}group{else}forum{/if}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="srchtype" value="title" />
        <input type="hidden" name="srhfid" value="" />
        <input type="hidden" name="srhlocality" value="forum::mypage" />
              <input type="hidden" name="searchsubmit" value="yes"/>
                   <input type="text" class="search_key_input" name="srchtxt" value="" placeholder="������Ҫ����������" autocomplete="off" id="topTxtKeyWord" value="">
                    <a href="javascript:;"><input type="submit" name="submit" value="" class="search_submit_t" id="topsearch_submit" /></a>
          </form>
                </div>
                    
            </li>
        </ul>
					<!--{hook/global_nav_extra}-->

    </div>
</div>
		<!--{if !IS_ROBOT}-->
			<!--{if $_G['uid']}-->
		 <div class="xxxlmm">	<ul id="xlmmpm_menu" class="p_pop" style="display: none;margin-top:-1px;">
				<li><a href="home.php?mod=space&do=pm" id="pm_ntc" style="background-repeat: no-repeat;background-position: 0 50%;"><em class="prompt_news{if empty($_G[member][newpm])}_0{/if}"></em>{lang pm_center}{if $_G[member][newpm]}({$_G[member][newpm]}){/if}</a></li>
				<li><a href="home.php?mod=follow&do=follower"><em class="prompt_follower{if empty($_G[member][newprompt_num][follower])}_0{/if}"></em><!--{lang notice_interactive_follower}-->{if $_G[member][newprompt_num][follower]}($_G[member][newprompt_num][follower]){/if}</a></li>
				<!--{if $_G[member][newprompt] && $_G[member][newprompt_num][follow]}-->
					<li><a href="home.php?mod=follow"><em class="prompt_concern"></em><!--{lang notice_interactive_follow}-->($_G[member][newprompt_num][follow])</a></li>
				<!--{/if}-->
				<!--{if $_G[member][newprompt]}-->
					<!--{loop $_G['member']['category_num'] $key $val}-->
						<li><a href="home.php?mod=space&do=notice&view=$key"><em class="notice_$key"></em><!--{echo lang('template', 'notice_'.$key)}-->(<span class="rq">$val</span>)</a></li>
					<!--{/loop}-->
				<!--{/if}-->
			</ul>
	 </div>		<!--{/if}-->
			<!--{subtemplate common/header_qmenu}-->
		<!--{/if}-->

			<div class="wp">
					<div class="wuserbox">
					<ul class="user-layer block" id="xlmmhm_menu" style="display: none; margin-left:-86px; width:260px;">
		<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li class="navmspan"$nav[nav]></li><!--{/if}-->
			<!--{/loop}-->
					</ul>
				</div>

	<!--{ad/subnavbanner/a_mu}-->
			</div>
{/if}

		<!--{hook/global_header}-->
	<!--{/if}-->

	<div id="wp" class="wp">
	<!--{/if}-->

	<!--{/if}-->
<!--{subtemplate style/style}-->




