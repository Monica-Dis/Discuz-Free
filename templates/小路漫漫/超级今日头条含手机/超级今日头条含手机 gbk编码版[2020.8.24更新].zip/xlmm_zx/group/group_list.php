<?PHP exit('Access Deniedxl');?>
	<style>
.xg1g, .xg1g a {
	color: #999 !important;
}
	</style>
<!--{if $_G['forum']['ismoderator']}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->
	<!--{if $page == 1}--><span id="clearstickthread" style="display: none;">
							<a href="javascript:;" onclick="clearStickThread()" title="{lang showdisplayorder}"><img src="$_G['style']['styleimgdir']/topshow.png" class="icon_top_folder"/></a>
	<!--{hook/forumdisplay_postbutton_top}-->
						</span>
	<!--{/if}-->
<!--{if $_G['forum']['threadtypes']}-->
	<ul class="ttp bm cl">
		<li id="ttp_all"{if !$_GET['typeid']} class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang forum_viewall}</a></li>
		<!--{if $_G['forum']['threadtypes']}-->
			<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
				<li{if $_GET['typeid'] == $id} class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}">$name</a>
			<!--{/loop}-->
		<!--{/if}-->
		<!--{hook/forumdisplay_filter_extra}-->
	</ul>
<!--{/if}-->
<div id="threadlist" class="tl bm" style="position: relative;">
	<div class="bm_c">
		<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="listextra" value="$extra" />
			<table cellpadding="0" cellspacing="0" border="0">
				<!--{if $_G['forum_threadcount']}-->
					<!--{loop $_G['forum_threadlist'] $key $thread}-->
														<script type="text/javascript">hideStickThread();</script>
		<!--{ad/threadlist}-->
						<tbody id="$thread[id]" class=" wow fadeInUpBig" data-wow-delay="0.3s">
							<tr>
									<td class="tdbg">&nbsp;</td><td class="icn">
                                        <p>					<!--{if $thread['authorid'] && $thread['author']}-->
						<a href="home.php?mod=space&uid=$thread[authorid]" c="1"><!--{avatar($thread[authorid],small)}--></a>
					<!--{else}-->
						<img src="$_G['style']['styleimgdir']/hidden.gif" title="$_G[setting][anonymoustext]" alt="$_G[setting][anonymoustext]" />
					<!--{/if}-->
</p>
									</td>
									<th class="$thread[folder]">
									<!--{if $thread[folder] == 'lock'}-->
											<img src="$_G['style']['styleimgdir']/folder_lock.gif" align="absmiddle" style="margin-right:5px; margin-top:-8px" />
										<!--{elseif $thread['special'] == 1}-->
											<img src="$_G['style']['styleimgdir']/pollsmall.gif" align="absmiddle" alt="{lang thread_poll}" style="margin-right:5px; margin-top:-8px" />
										<!--{elseif $thread['special'] == 2}-->
											<img src="$_G['style']['styleimgdir']/tradesmall.gif" align="absmiddle" alt="{lang thread_trade}" style="margin-right:5px; margin-top:-8px" />
										<!--{elseif $thread['special'] == 3}-->
											<img src="$_G['style']['styleimgdir']/rewardsmall.gif" align="absmiddle" alt="{lang thread_reward}" style="margin-right:5px; margin-top:-8px" />
										<!--{elseif $thread['special'] == 5}-->
											<img src="$_G['style']['styleimgdir']/debatesmall.gif" alt="{lang thread_debate}" style="margin-right:5px; margin-top:-8px" />
										<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
<img src="$_G['style']['styleimgdir']/pin.gif" align="absmiddle" title="$_G[setting][threadsticky][3-$thread[displayorder]]" style="margin-right:5px; margin-top:-8px"  />
										<!--{/if}-->
																				<!--{if $thread['digest']}-->
											<img src="$_G['style']['styleimgdir']/digest.gif" align="absmiddle" title="{lang thread_digest} $thread[digest]" style="margin-right:5px; margin-top:-8px"  />
										<!--{/if}-->
<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
			<a href="javascript:;" id="content_$thread[tid]" class="showcontent y" title="{lang content_actions}" onclick="CONTENT_TID='$thread[tid]';CONTENT_ID='$thread[id]';showMenu({'ctrlid':this.id,'menuid':'content_menu'})"></a>
										<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
											<a href="javascript:void(0);" onclick="hideStickThread('$thread[tid]')" class="showhide y" title="{lang hidedisplayorder}">{lang hidedisplayorder}</a></em>
										<!--{/if}-->
									<!--{hook/forumdisplay_thread $key}-->
									<!--{if $thread['moved']}-->
										<!--{if $_G['forum']['ismoderator']}-->
											<a href="forum.php?mod=topicadmin&action=moderate&optgroup=3&operation=delete&tid=$thread[moved]" onclick="showWindow('mods', this.href);return false">{lang thread_moved}:</a>
										<!--{else}-->
											{lang thread_moved}:
										<!--{/if}-->
									<!--{/if}-->
									$thread[typehtml]
									<span id="thread_$thread[tid]"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"$thread[highlight] class="xst">$thread[subject]</a></span>
									<!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->
									<!--{if $thread['price'] > 0}-->
										<!--{if $thread['special'] == '3'}-->
										- <span style="color: #C60">[{lang thread_reward}<span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span>
										<!--{else}-->
										- [{lang price} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
										<!--{/if}-->
									<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
										- <span style="color: #269F11">[{lang reward_solved}]</span>
									<!--{/if}-->
									<!--{if $thread[multipage]}-->
										<span class="tps">$thread[multipage]</span>
									<!--{/if}-->
												<!--{if $_G['forum']['ismoderator']}-->
									<!--{if $thread['fid'] == $_G[fid]}-->
										<!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
											<input onclick="tmodclick(this)" type="checkbox" name="moderate[]" class="pc" value="$thread[tid]" />
										<!--{else}-->
											<input type="checkbox" disabled="disabled" />
										<!--{/if}-->
									<!--{else}-->
										<input type="checkbox" disabled="disabled" />
									<!--{/if}-->
								<!--{/if}-->
 							<p class="mtn xg1g" style="margin-left:-7px; margin-top:8px">
							{echo ' &nbsp; ������'}: <span style="color:#999;">$thread[dateline]</span>
							{echo ' &nbsp; �鿴'}: $thread[views]
							{echo ' &nbsp; �ظ�'}: <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">$thread[replies]</a>
						</p>
  										<!--{if !$_G['setting']['forumdisplaythreadpreview'] && !($thread['readperm'] && $thread['readperm'] > $_G['group']['readaccess'] && !$_G['forum']['ismoderator'] && $thread['authorid'] != $_G['uid'])}-->
                                 <!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
 		{eval include_once libfile('function/post');
include_once libfile('function/attachment');
$thread['post'] = C::t('forum_post')->fetch_all_by_tid_position($thread['posttableid'],$thread['tid'],1);
$thread['post'] = array_shift($thread['post']);
$xiaolu['fmessage'] = messagecutstr($thread['post']['message'], 130);
$fpic = C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid']);
$xl_num = C::t('forum_attachment_n')->count_image_by_id('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid']);
}
		<p class="thsum">$xiaolu['fmessage']</p>
<!--{if $fpic}-->
<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" target="_blank">
    <div class="xlmm_pic">
          <div id="xlmm_pic_$thread[tid]">
          <ul style="height: auto; overflow: hidden;" id="xlmm_pic_ul_$thread[tid]" class="xlmm_pic_ul">
  <!--{eval $i=0;}-->
<!--{loop $fpic $key $url}-->
  	  {if !$url[isimage] == 0}                                          
            <li style="height: 90px; overflow: hidden; max-width:300px" class="xlmm_pic_img"><img src="{if $url[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}/forum/$url['attachment']" style="vertical-align:top;"/></li>
 <!--{eval $i++}-->
<!--{eval if($i==3) break;}-->
	{/if}
<!--{/loop}--> 
           </ul>
            </div></a>
        </div>
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
				</th>
									<td class="by">
										<!--{hook/forumdisplay_author $key}-->
										<cite>
										<!--{if $thread['authorid'] && $thread['author']}-->
											<a href="home.php?mod=space&uid=$thread[authorid]" c="1"{if $groupcolor[$thread[authorid]]} style="color: $groupcolor[$thread[authorid]];"{/if}>$thread[author]</a><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->
										<!--{else}-->
											$_G[setting][anonymoustext]
										<!--{/if}-->
										</cite>
                                        <!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
										<em><!--{if $thread['lastposter']}--><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}">$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></em>
                                        <!--{/if}-->
									</td>
	             {eval $timets=time();$curdate=getdate($timets);$nowtime=mktime(0,0,0,$curdate['mon'],$curdate['mday'],$curdate['year']);if ($thread['dblastpost']>=$nowtime) $thread['lastpost']=date('H:i',$thread['dblastpost']);else $thread['lastpost']=date('m-d',$thread['dblastpost']);}
								<td class="num" >
                                        <!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                                            <p>$thread[lastpost]</p>
                                        <!--{/if}-->
                                    </td>
									<td class="tdbg">&nbsp;</td>
								</tr>
							</tbody>
					<!--{/loop}-->
				<!--{else}-->
					<tbody><tr><th colspan="6"><p class="emp">{lang forum_nothreads}</p></th></tr></tbody>
				<!--{/if}-->
			</table>
			<!--{if $_G['forum']['ismoderator'] && $_G['forum_threadcount']}-->
				<!--{template forum/topicadmin_modlayer}-->
			<!--{/if}-->
		</form>
	<div style="margin-top:20px; margin-left:18px; margin-right:18px;">
<div class="bm bw0 pgs cl">
	<span id="fd_page_bottom">$multipage</span>
	<!--{hook/forumdisplay_postbutton_bottom}-->
</div>
	</div>
	</div>
</div>




