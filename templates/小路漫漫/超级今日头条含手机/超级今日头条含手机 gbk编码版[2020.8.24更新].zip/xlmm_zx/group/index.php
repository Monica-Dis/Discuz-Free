<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/tt_header}-->
	<!--{hook/index_header}-->
		<!--{hook/index_top}-->
		<style id="diy_style" type="text/css"></style>
	<!--[diy=xlmm-t]--><div id="xlmm-t" class="area"></div><!--[/diy]-->
<style>
 .msgAlert { margin-bottom:10px;height: 33px;	line-height: 32px;	font-size: 14px;	color: #fff;	text-align: center;	background-color: #60a3f5;	background-color: rgba(96,163,245,.85);	z-index: 20;	-webkit-transition-property: height;	transition-property: height;	-webkit-transition-delay: 0;	transition-delay: 0;	-webkit-transition-duration: .5s;	transition-duration: .5s;}
 .list-refresh-msg { margin-bottom:10px;text-align: center;	font-size: 14px; display:block;color: #2A90D7;	height: 32px;	line-height: 32px;	background: #2A90D7;	background: rgba(41,144,215,.08);	border: 1px solid #2A90D7;	border: 1px solid rgba(41,144,215,.5);	border-radius: 4px;	cursor: pointer;}
</style>

<div class="y-box container">
  <div class="y-left index-channel">
    <div class="wchannel " id="fthread"> 
    <a class="logo" href="news"> <img src="template/xlmm_zx/portal/list/logo.png"> </a> 
    <ul> 
    <li> <a class="wchannel-item active" href="group.php"> <span>ȫ��</span> </a> </li>
									<!--{eval $k = 1;}-->
                      					<!--{loop $first $groupid $group}-->
 <li id="p-more$k "  onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'active','pos':'34!'})"> <a href="group.php?gid=$groupid" target="_blank" class="wchannel-item"> <span>$group[name]</span> </a> </li>
									<!--{eval $k ++;}-->
<!--{/loop}-->
    <li> <a class="wchannel-item" href="forum.php?mod=group&amp;action=create&amp;fupid=3&amp;groupid=0"> <span>+����</span> </a> </li>
 </ul> 
 </div>
 </div>
 									<!--{eval $k = 1;}-->
                      					<!--{loop $first $groupid $group}-->
   <div id="p-more$k _menu" class="wchannel" style="display:none"> 
       <div class="wchannel-more-layer"> 
<ul>
<!--{loop $group['secondlist'] $fid}--><li> <a href="group.php?sgid=$fid" target="_blank" class="y-left wchannel-item "> <span>$second[$fid][name]</span> </a> </li><!--{/loop}-->
 </ul> </div> </div> 
									<!--{eval $k ++;}-->
<!--{/loop}-->


  
    <div class="y-left index-content">
	<!--[diy=xlmm-hd]--><div id="xlmm-hd" class="area"></div><!--[/diy]-->
 </div>


  <div class="y-right index-modules">
    <div class="module-inner" id="module-inner">
      <div style="margin-bottom: 16px;">
      <div name="searchBox" class="wsearch"> 
      <form id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" onSubmit="searchFocus($('scbar_txt'))" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
 			        <input type="hidden" name="mod" id="scbar_mod" value="{if $_G['basescript'] == 'portal'}portal{elseif $_G['basescript'] == 'group'}group{else}forum{/if}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="srchtype" value="title" />
        <input type="hidden" name="srhfid" value="" />
        <input type="hidden" name="srhlocality" value="forum::mypage" />
              <input type="hidden" name="searchsubmit" value="yes"/>
     <div class="y-box input-group"> 
      <input class="y-left input-text" name="srchtxt" value="" placeholder="������Ҫ����������" autocomplete="off" value="" type="text"> 
      <div class="y-right btn-submit"> 
      <button type="submit" href="javascript:;"> <i class="y-icon icon-search"></i> </button> </div> </div> </form> 
      
      </div></div>
<!--{hook/index_side_top}-->
<!--[diy=xlmm-r]--><div id="xlmm-r" class="area"></div><!--[/diy]-->
      <div class="company">
  <p> &copy; 2020-2021 $_G['setting']['sitename'] $_G['setting']['siteurl']</p>

  <a href="javascript:;" >�й��������ٱ����� </a>

  <div class="">
<!--{if $_G['setting']['icp']}--><span>������Ϣ��<a href="http://www.miibeian.gov.cn/" target="_blank">$_G['setting']['icp']</a></span> <!--{/if}-->
  </div>
  <p>�Ǿ�Ӫ����վ-2020-2021</p>

  <span>Υ���Ͳ�����Ϣ�ٱ���010-12321</span><span>�������ͷ�QQ��$_G['setting']['site_qq']</span>
  <a href="javascript:;"><img src="$_G['style']['styleimgdir']/gon.png">����������Ϣ����</a>
<span>Powered by&nbsp;<a href="http://t.cn/Aiux1eta" target="_blank">DisM.Taobao.Com!</a>$_G['setting']['version']&nbsp;&nbsp;<a href="http://t.cn/Aiux1Jx1" target="_blank">DISM.TAOBAO.COM.</a></span></div>
	<!--[diy=xlmm-rf]--><div id="xlmm-rf" class="area"></div><!--[/diy]-->
        </div>
  </div>
</div>
	<!--{hook/index_side_bottom}-->
	<!--[diy=xlmm-f]--><div id="xlmm-f" class="area"></div><!--[/diy]-->
	<!--{hook/index_bottom}-->
    </div>

<script type="text/javascript" reload="1">
(function($){$(function () {

    var bartop = $('#fthread').offset().top,
        h2_con=$('#fthread').find("h2 a").text();
    function changeBar(){
        var st = $(window).scrollTop();
        if( st > bartop){
            $('#fthread').addClass('thread_fixed');
        }else{
            $('#fthread').removeClass('thread_fixed');
        }
    }
    $(window).scroll( function(){
        changeBar();
    })

$(document).ready(function(e) {			
	t = $('#fixed').offset().top;
	fh = $('#fixed').height();
	$(window).scroll(function(e){
		s = $(document).scrollTop();	
		if(s > t - 10){
            $('#fixed').addClass('fixed');
			if(s + fh > mh){
				$('#fixed').css('top',mh-s-fh+'px');	
			}				
		}else{
            $('#fixed').removeClass('fixed');
		}
	})
});

})
})(jQuery)

</script>
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
	<style type="text/css">
.hides, .fixed .hidex { display: block}
	</style>
	<!--{/if}-->

<!--{template common/tt_footer}-->




