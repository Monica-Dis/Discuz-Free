<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{hook/viewthread_beginline}-->
<style>
#hjpassport, #roll, #pass_c { z-index:9}
.theater-aside .theater-aside-post .aside-post-head p {margin: 10px 0 0;font-size: 12px;color: #85888a;}
.theater-aside .theater-aside-post .aside-post-head .aside-site-follow {position: absolute;right: 15px;top: 50%;-webkit-transform: translateY(-50%);-moz-transform: translateY(-50%);-ms-transform: translateY(-50%);transform: translateY(-50%);color: #c99a05;}
.theater-aside .theater-aside-post .aside-post-content .aside-post-desc {margin: 9px 0 0;font-size: 13px;line-height: 24px;}
#seccheck_fastpost .p_pop, .p_pof, .sllt {padding: 4px;border: 0px solid;min-width: 60px;border-color: #DDD;background: none;box-shadow: 1px 2px 2px rgba(0,0,0,0.3);left:10px!important;top:14px !important
}
.messagenum .zoom {display: none}
.theater-aside .grey a {color: #333;}
.inline-comment .comments-list li {padding: 3px 0 4px 36px;position:relative;font-size: 13px;color: #b0b5b8;}
.inline-comment .comments-list li .site-icon {width: 26px;height: 26px;}
.comment-wrapper .comments-list li .site-icon img {display: block;width: 100%;height: 100%;-webkit-border-radius: 50%;-moz-border-radius: 50%;border-radius: 50%;}
.inline-comment .comments-list li .site-link, .inline-comment .comments-list li .site-name {color: #fff;}
.comment-wrapper .comments-list li .site-icon {position: absolute;left: 0;top: 0;}
</style>
<script type="text/javascript">var fid = parseInt('$_G[fid]'), tid = parseInt('$_G[tid]');</script>
<!--{if $_G['forum']['ismoderator']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->

<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';var aimgcount = new Array();</script>

<style id="diy_style" type="text/css">
</style>
<link rel="stylesheet" href="$_G[style][styleimgdir]/num/css.css"/>
<link rel="stylesheet" href="$_G[style][styleimgdir]/num/lightgallery.min.css"/>


	<!--{eval $curaidkey = 0;
	$favorite = $_G[forum_thread][authorid];
	$xlmmmyfav=DB::result_first("select followuid from ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$favorite");}-->
	<!--{eval $count = count($imglist['aid']);}-->

<div class="widget-theater" style="height: 100%; display: block; width: 100%; z-index:99">
    <div class="theater-main">
        <div class="theater-handler">
            <a href="forum.php?mod=viewthread&tid=$_G[tid]" title="{lang thread_mod}" class="theater-close icon-close" style="z-index:999" ></a>
        </div>
		
        <div id="" class="theater-swiper">
            <div class="theater-scene">

                <ul id="lightGallery" class="img_ul">
	  <!--{eval $i=1;}-->
		<!--{loop $imglist[url] $key $imgurl}-->
			<li data-src="$imgurl"  class="scene-item" style="display:block;"><div style="font-size:16px; position: absolute; line-height: 22px;letter-spacing: 8px;text-indent: 8px;color: #fff;text-align:center;opacity: .6; cursor: auto; top:-48px; left:90px; right:90px;">$i/$count</div> 
    <a class="img_a"><img src="$imgurl">        </a>   <a  href="javascript:;" class="theater-fullscreen icon-fullscreen" style=" display:block; position:absolute;top:-50px; left:34px; z-index:9999; width:32px; height:32px; color:#fff;opacity: .6; " title="�߼���ͼģʽ��֧��ȫ����ͼ�Ȳ���"></a>   

</li>
 <!--{eval $i++}-->
<!--{/loop}--> 
</ul>
                <a class="icon-arrow switch-prev prev_a change_a" title="��һ��"></a>
                <a class="icon-arrow switch-next next_a change_a" title="��һ��"></a>
                <a class="theater-scene-mask"></a>
      </div>
            <div class="theater-thumb img_hd">
											<ul id="imagelistthumb" class="clearfix" style="height:70px; overflow:hidden;" ></ul>
                <a class="icon-2arrow switch-prev bottom_a prev_a" title=""></a>
                <a class="icon-2arrow switch-next bottom_a next_a" title=""></a>
            </div>
    </div>
    </div>
<div class="theater-aside">
        <div class="theater-aside-actions"><!--{if !empty($_G['setting']['recommendthread']['addtext'])}-->
						<a id="recommend_add" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" {if $_G['uid']}onclick="ajaxmenu(this, 3000, 1, 0, '43', 'recommendupdate({$_G['group']['allowrecommend']})');return false;"{else} onclick="showWindow('login', this.href)"{/if} onmouseover="this.title = $('recommendv_add').innerHTML + ' {lang activity_member_unit}$_G[setting][recommendthread][addtext]'" title="{lang maketoponce}" class="icon-like"><i><span id="recommendv_add"{if !$_G['forum_thread']['recommend_add']} style="display:none"{/if}>$_G[forum_thread][recommend_add]</span></i></a>
						<!--{/if}-->
<a class="icon-comment" title="{lang comment_num}:">$_G[forum_thread][replies]</a>
<em class="icon-more">
    <ul class="more-choices">
        <li class="add-to-site"><a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" id="k_favorite" onClick="showWindow(this.id, this.href, 'get', 0);" onMouseOver="this.title = $('favoritenumber').innerHTML + ' {lang activity_member_unit}{lang thread_favorite}'">{lang thread_favorite} <span id="favoritenumber" class="xi1">{$_G['forum_thread']['favtimes']}</span></a></li>
        
        
    </ul>
</em></div>
        <div class="theater-aside-post"><div class="aside-post-head">
    <a href="home.php?mod=space&uid=$post[authorid]" class="site-icon popover-action" target="_blank"><img src="$_G[setting][ucenterurl]/avatar.php?uid=$post[authorid]&size=small" />
								<!--{if $_G[forum_thread][author] && $_G[forum_thread][authorid]}-->
									<a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" class="site-link popover-action" target="_blank">$_G[forum_thread][author]</a>
									<!--{else}-->
										<!--{if $_G['forum']['ismoderator']}-->
											<a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" class="site-link popover-action" target="_blank">{lang anonymous}</a>
										<!--{else}-->
											{lang anonymous}
										<!--{/if}-->
									<!--{/if}-->
    <p>
        <time> <!--{date($_G[forum_thread][dateline])}--></time>
        
        <span>�Ķ�$_G[forum_thread][views]</span>
        
    </p>
    
<!--{if !$xlmmmyfav}-->
<a id="followmod" onClick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$_G[forum_thread][authorid]" class="aside-site-follow">��ע</a>
<!--{else}-->
<a id="followmod" onClick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$_G[forum_thread][authorid]" class="aside-site-follow">ȡ����ע</a>
<!--{/if}-->
</div>
<div class="aside-post-content">
    
    
    <p class="aside-post-desc">$post['message']</p>
    
                					<!--{if $post[tags]}-->
  <div class="aside-post-tags">
						<!--{loop $post[tags] $var}-->
      <a href="misc.php?mod=tag&id=$var[0]" class="common-tag popover-action" target="_blank">$var[1]</a>
			  <!--{/loop}-->

    </div>
					<!--{/if}-->
  		<script src="template/xlmm_zx/qrcode.js" type="text/javascript"></script>
  <div class="aside-post-share">
        <i class="icon-wechat">
            <div class="wechat-qrcode">
                <span id="qrcode"> </span>
				 <p>΢�š�ɨһɨ�����ɽ���ҳ���ֻ�����</p>
            </div>
        </i>
 	<script type="text/javascript">new QRCode(document.getElementById("qrcode"), "{$_G['siteurl']}forum.php?mod=viewthread&tid=$_G[tid]");</script>
       <i><script type="text/javascript">document.write('<a href="http://v.t.sina.com.cn/share/share.php?url=' + encodeURIComponent('{$_G['siteurl']}forum.php?mod=viewthread&tid=$_G[tid]&from=album') + '&title=' + encodeURIComponent('$thread[subject]') + '" title="����������΢��" target="_blank" class="icon-weibo"></a>');</script></i>
    </div>
</div></div>

        <div class="theater-aside-comment"><div class="comment-wrapper inline-comment">
    
  <form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes" class="comment-form">
 <a href="" class="site-icon" target="_blank">{echo avatar($_G['uid'])}</a>
   	  <input type="hidden" name="formhash" value="{FORMHASH}" />
      <!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->
        <div class="inbox">
        <select id="stand" name="stand" >
            <option value="">{lang debate_viewpoint}</option>
            <option value="0">{lang debate_neutral}</option>
            <option value="1">{lang debate_square}</option>
            <option value="2">{lang debate_opponent}</option>
        </select>
      </div>
      <!--{/if}-->
      <div class="inbox"><textarea name="message" id="fastpostmessage" rows="3" class="txt" style="width:230px;height: 64px;
padding: 7px 40px 9px 8px;
font-size: 13px;
border: 0;
color: #fff;
background-color: #1c1d1e;" placeholder="ϲ���������ҵ�����˵���䡭"></textarea></div>
	<div id="seccheck_fastpost" style="position:relative">
		<!--{if $allowpostreply && ($secqaacheck || $seccodecheck)}-->
			<!--{subtemplate forum/seccheck_post}-->
		<!--{/if}-->
	</div>
      <div class="inbox" style="margin-top:14px;"> <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]{if $_GET[from]}&from=$_GET[from]{/if}" onclick="return switchAdvanceMode(this.href)" class="z" >�߼�����ģʽ</a><input type="submit" name="replysubmit" id="fastpostsubmit" value="{lang reply}" class="y"  style="margin-right:10px;"/><div class="cl"></div></div>
    </form>
  
  <ul class="comments-list">

	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
				            <!--{if $post['first']}-->
                        <!--{else}-->
<li data-note-id="6455373">
    
    <a class="site-icon popover-action" href="home.php?mod=space&uid=$post[authorid]" target="_blank"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->"></a>
    					<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
						<a class="site-link popover-action" href="home.php?mod=space&uid=$post[authorid]" >$post[author]</a>

					<!--{else}-->
						<!--{if !$post['authorid']}-->
						<a class="site-link popover-action" href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
						<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
						<!--{if $_G['forum']['ismoderator']}--><a class="site-link popover-action" href="home.php?mod=space&uid=$post[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
						<!--{else}-->
						$post[author] <em>{lang member_deleted}</em>
						<!--{/if}-->
					<!--{/if}-->

	<div class="messagenum">
                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
					<!--{else}-->
			            <!--{if $post['first']}-->
                        <!--{else}-->
                            $post[message]
                        <!--{/if}-->

					<!--{/if}-->
      </div>
  <div class="comment-foot">
        <time>{$post[dateline]}</time>
        
        
        
        <span class="like-count"></span>
    </div>
</li>
 					<!--{/if}-->
   <!--{eval $postcount++;}-->
  <!--{/loop}-->
</ul>

    
   {if $_G['page_next'] >1} <a href="forum.php?mod=viewthread&tid=$_G[tid]"  class="more-comments">�鿴��������</a>{/if}
    

</div></div>
    </div>
	
	</div>
							<!--{if !empty($imglist)}-->
							<script type="text/javascript" reload="1">
								<!--{eval $imagelistkey = dsign($_G[tid].'|100|100')}-->
								var imagelistkey = '$imagelistkey';
								var imglist = new Array();
								var imagelist_html = '';
								imglist['aid'] = [<!--{echo dimplode($imglist[aid]);}-->];
								imglist['url'] = [<!--{echo dimplode($imglist[url]);}-->];
								var count = imglist['aid'].length;
								for(i = 0; i < count; i++) {
									imagelist_html += '<li><a class="thumb-item current-thumb img_a">' +'<img src="forum.php?mod=image&aid=' + imglist['aid'][i] + '&size=100x100&key=' + imagelistkey + '&atid={$post[tid]}" width="100" height="100"/></a></li>';
								}
								$('imagelistthumb').innerHTML = imagelist_html;


							</script>
							<!--{/if}-->
<script type="text/javascript">
function succeedhandle_followmod(url, msg, values) {
var fObj = $('followmod');
if(values['type'] == 'add') {
fObj.innerHTML = 'ȡ����ע';
fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
} else if(values['type'] == 'del') {
fObj.innerHTML = '��ע';
fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
}
}
</script>

<script type="text/javascript">
(function($){

var i=0; //ͼƬ��ʶ
var img_num=$(".img_ul").children("li").length; //ͼƬ����
$(".img_ul li").hide(); //��ʼ��ͼƬ	
play();
$(function(){
	$(".img_hd ul").css("width",($(".img_hd ul li").outerWidth(true))*img_num); //����ul�ĳ���

	$(".bottom_a").css("opacity",0.7);	//��ʼ���ײ�a͸����
	//$("#play").css("height",$("#play .img_ul").height());
	if (!window.XMLHttpRequest) {//��ie6����a��λ��
		$(".change_a").css("height",$(".change_a").parent().height());
	}
	
	$(".change_a").focus(function(){
		this.blur();
	});
	$(".bottom_a").hover(function(){//�ײ�a�����¼�
		$(this).css("opacity",1);	
	},function(){
		$(this).css("opacity",0.7);	 
	});

	$(".change_a").hover(function(){//��ͷ��ʾ�¼�
		$(this).children("span").show();
	},function(){
		$(this).children("span").hide();
	});
	
	$(".img_hd ul li").click(function(){
		i=$(this).index();
		play();
	});

	$(".prev_a").click(function(){
		//i+=img_num;
		i--;
		//i=i%img_num;
		i=(i<0?0:i);
		play();
	}); 
	$(".next_a").click(function(){
		i++;
		//i=i%img_num;
		i=(i>(img_num-1)?(img_num-1):i);
		play();
	}); 
}); 

function play(){//�����ƶ�	
	var img=new Image(); //ͼƬԤ����
	img.onload=function(){
		img_load(img,$(".img_ul").children("li").eq(i).find("img"))
	};
	img.src=$(".img_ul").children("li").eq(i).find("img").attr("src");
	//$(".img_ul").children("li").eq(i).find("img").(img_load($(".img_ul").children("li").eq(i).find("img")));
	$(".img_hd ul").children("li").eq(i).addClass("on").siblings().removeClass("on");
	if(img_num>7){//����7����ʱ������ƶ�
		if(i<img_num-3){ //ǰ3��
			$(".img_hd ul").animate({"marginLeft":(-($(".img_hd ul li").outerWidth()+4)*(i-3<0?0:(i-3)))});
		}else if(i>=img_num-3){//��3��
			$(".img_hd ul").animate({"marginLeft":(-($(".img_hd ul li").outerWidth()+4)*(img_num-7))});
		}
	}
	if(!window.XMLHttpRequest){//��ie6����a��λ��
		$(".change_a").css("height",$(".change_a").parent().height());
	}
}

function img_load(img_id,now_imgid){//��ͼƬ�������� ��img_id �½���img,now_imgid��ǰͼƬ��
	if(img_id.width/img_id.height>1){
		if(img_id.width >=$("#numplay").width())
		$(now_imgid).width($("#numplay").width());
	}else{
		if(img_id.height>=500) $(now_imgid).height(500);
	}
	$(".img_ul").children("li").eq(i).show().siblings("li").hide(); //��Сȷ���������ʾ
}


})(jQuery)
</script>
<!--{hook/viewthread_useraction_prefix}-->	<!--{hook/viewthread_useraction}-->
<!--{hook/viewthread_bottom}-->


<div class="wp mtn">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>

<script type="text/javascript" src="$_G[style][styleimgdir]/num/lightgallery.js"></script>
<script type="text/javascript" src="$_G[style][styleimgdir]/num/lg-fullscreen.js"></script>
<script type="text/javascript" src="$_G[style][styleimgdir]/num/lg-thumbnail.js"></script>
<script type="text/javascript" src="$_G[style][styleimgdir]/num/lg-autoplay.js"></script>
<script type="text/javascript" src="$_G[style][styleimgdir]/num/lg-hash.js"></script>
<script type="text/javascript" src="$_G[style][styleimgdir]/num/lg-zoom.min.js"></script>
<script type="text/javascript"> 
function initLoad() { var lg = document.getElementById('lightGallery'); lightGallery(lg, { mode: 'lg-slide', cssEasing: 'ease', speed: 500, download: false, }); } </script>
<!--{template common/footer}-->




