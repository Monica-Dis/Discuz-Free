<?php echo 'С·���� ';exit;?>
<!--{template common/header}-->
<!-- main threadlist start -->
<style>
.src {color: #999!important;}
body{background-color:#fff !important;}
.swiper-container a div{ background:url(template/xlmm_zx/m-img/none.png); height:0; line-height:0;}
.swiper-pagination {bottom: 15px;}
/*banner*/
   html {font-size: 312.5%;}
#guide_banner{overflow:hidden;background-color:#fff; margin:-10px 0 0 -20px 0;;}           
.guide_banner_item{width:25%;float:left;text-align:center;margin:10px 0.6rem 10px 0 .6rem; margin-top:10px;}           
.guide_banner_item img{display:block;margin:0 auto;width:50%}           
.guide_banner_item em{color:#92979a;font-size:12px;line-height:2.6; display:block}           
			
	.hm { display:block;line-height:40px;color: #999 !important;}
content.feed-list-container .list_image .list_img_holder:first-child {margin-left: 0;}


</style>
<script src="template/xlmm_zx/jquery.ias.min.js" type="text/javascript"></script>
<script src="template/xlmm_zx/m-img/loadm.js" type="text/javascript"></script>
<script src="template/xlmm_zx/load.js?EGs" type="text/javascript"></script>
<!--{$_G['cache']['plugin']['xlmm_tt']['slides']}-->
<!--{$_G['cache']['plugin']['xlmm_tt']['xlmmnav']}-->
{eval $page=$_G['page'];}
<!--{if $_G['cache']['plugin']['xlmm_tt']['diaoyont'] == 1 || $_G['cache']['plugin']['xlmm_tt']['diaoyont'] == 2}-->
<content class="feed-list-container" id="threadlist" style="position:relative; padding-top:0;">
	<div id="waterfall" class="list_content">
<!--{if $_G['cache']['plugin']['xlmm_tt']['diaoyont'] == 1}-->
{eval include TPLDIR.'/php/forum_guide.php';}
									        	<!--{loop $grids['newthread'] $key $thread}-->
  											<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
	 <!--{if $_G['page'] ==1 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad1']}-->                                                                    
 <!--{elseif $_G['page'] ==2 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad2']}-->                                                                    
 <!--{elseif $_G['page'] ==3 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad3']}-->                                                                    
 <!--{elseif $_G['page'] ==4 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad4']}-->                                                                    
 <!--{elseif $_G['page'] ==5 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad5']}-->                                                                    
 <!--{elseif $_G['page'] ==6 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad6']}-->                                                                    
										<!--{/if}-->
	
			{eval include TPLDIR.'/php/forum_forumdisplay.php';}
<!--{if $xlmmal <1}-->
<section class="has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail">										<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
<h3 class="dotdot line3">										
										$thread[subject]
</h3><div class="item_info"><div><span class="src space">$thread[author]</span><span class="cmt space">���� <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span><span class="time">$thread[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal >$_G['cache']['plugin']['xlmm_tt']['xlmmmduotu']}-->
<section class="has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail"><h3 class="dotdot line3">
										$thread[subject]</h3>
<div class="list_image" style="margin-top:5px;">
<div class="clearfix">
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
<div class="list_img_holder"><img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="$xlmmimg" class="xlmmlazy"></div>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==3) break;}-->
<!--{/loop}-->
</div>
</div>
<div class="item_info"><div><span class="src space">$thread[author]</span><span class="cmt space">���� <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span><span class="time">$thread[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal <=$_G['cache']['plugin']['xlmm_tt']['xlmmmduotu']}-->
<section class="middle_mode has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail desc"><!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
                                        <h3 class="dotdot line3 image-margin-right">
										$thread[subject]</h3><div class="item_info"><div><span class="src space">$thread[author]</span><span class="cmt space">���� <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span><span class="time">$thread[dateline]</span><span class="dislike-news fr mid-space"></span></div></div></div>
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
 <div class="list_img_holders"><img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="$xlmmimg" class="xlmmlazy"></div>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==1) break;}-->
<!--{/loop}-->
</a></section>
<!--{/if}-->
				<!--{/loop}-->
<!--{elseif $_G['cache']['plugin']['xlmm_tt']['diaoyont'] == 2}-->


		{eval include TPLDIR.'/php/list.php';}
	<!--{loop $list $key $value}-->
				<!--{eval $article_url = fetch_article_url($value);
}-->
	 <!--{if $_G['page'] ==1 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad1']}-->                                                                    
 <!--{elseif $_G['page'] ==2 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad2']}-->                                                                    
 <!--{elseif $_G['page'] ==3 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad3']}-->                                                                    
 <!--{elseif $_G['page'] ==4 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad4']}-->                                                                    
 <!--{elseif $_G['page'] ==5 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad5']}-->                                                                    
 <!--{elseif $_G['page'] ==6 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad6']}-->                                                                    
										<!--{/if}-->
	
		{eval include TPLDIR.'/php/portal_list.php';}
<!--{if $xlmmal ==0}-->
<section class="has_action"><a href="$article_url" class="article_link clearfix "><div class="item_detail">										
<h3 class="dotdot line3">$value[title]</h3><div class="item_info"><div><span class="src space">$value[username]</span><span class="cmt space">�ظ� $value[commentnum]</span><span class="time">$value[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>

<!--{elseif $xlmmal >$_G['cache']['plugin']['xlmm_tt']['xlmmmduotu']}-->
<section class="has_action"><a href="$article_url" class="article_link clearfix "><div class="item_detail"><h3 class="dotdot line3">$value[title]</h3>
 <div class="list_image" style="margin-top:5px;">
<div class="clearfix">
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==3) break;}-->
<div class="list_img_holder">
<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->
<img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1}-->$xlmmimg<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->template/xlmm_zx/php/small.php?filename=<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->&width=230&height=230<!--{/if}-->" class="xlmmlazy">
						<!--{else}-->
<img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment']<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 4}-->.thumb.jpg<!--{/if}-->" class="xlmmlazy">
<!--{/if}-->
</div>
<!--{/loop}-->
    </div>
</div>
<div class="item_info"><div><span class="src space">$value[username]</span><span class="cmt space">�ظ� $value[commentnum]</span><span class="time">$value[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal <=$_G['cache']['plugin']['xlmm_tt']['xlmmmduotu']}-->
<section class="middle_mode has_action"><a href="$article_url" class="article_link clearfix "><div class="item_detail desc">                                        <h3 class="dotdot line3 image-margin-right">$value[title]</h3><div class="item_info"><div><span class="src space">$value[username]</span><span class="cmt space">�ظ� $value[commentnum]</span><span class="time">$value[dateline]</span><span class="dislike-news fr mid-space"></span></div></div></div>
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==1) break;}-->

 <div class="list_img_holders"> <!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->
<img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1}-->$xlmmimg<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->template/xlmm_zx/php/small.php?filename=<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->&width=230&height=230<!--{/if}-->" class="xlmmlazy">
						<!--{else}-->
<img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment']<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 4}-->.thumb.jpg<!--{/if}-->" class="xlmmlazy">
<!--{/if}-->
</div>
  <!--{/loop}-->
  </a></section>

 <!--{/if}-->
			<!--{/loop}-->

 <!--{/if}-->
</div>


</content>
<!--{elseif $_G['cache']['plugin']['xlmm_tt']['diaoyont'] == 3}-->
    {eval include_once TPLDIR.'/php/bid.php';}
<content class="news-ul white" id="waterfall">
	<!--{loop $xlmmlistbid $key $thread}-->
 	 <!--{if $_G['page'] ==1 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad1']}-->                                                                    
 <!--{elseif $_G['page'] ==2 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad2']}-->                                                                    
 <!--{elseif $_G['page'] ==3 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad3']}-->                                                                    
 <!--{elseif $_G['page'] ==4 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad4']}-->                                                                    
 <!--{elseif $_G['page'] ==5 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad5']}-->                                                                    
 <!--{elseif $_G['page'] ==6 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad6']}-->                                                                    
										<!--{/if}-->
  {eval include  TPLDIR.'/php/atidpic.php';}
<section class="lnews-item cl">
    <a href="$thread[url]" class="news-link{if $xlmmal ==0 || $xlmmal >2}{elseif $xlmmal <=2} flex{/if} cl">
    <span class="{if $xlmmal ==0 || $xlmmal >2}100{elseif $xlmmal <=2}left{/if}">
	<div class="mr8">
		<span class="news-title">$thread[title]</span>
     	<!--{if $xlmmal >2}-->                
     <div class="news-tit-img1 pic3">
    				<!--{if $thread[idtype] == 'tid'}-->			
  <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment']; }
		<!--{/if}-->
                                                                                   <span class="nimg xlmmlazy" style="background-repeat: no-repeat; background-size: cover; display: inline-block;" xlmmlazy="$xlmmimg">  </span>
 <!--{eval $i++}-->
<!--{eval if($i==3) break;}-->
<!--{/loop}--> 
		<!--{/if}-->
   					<!--{if $thread[idtype] == 'aid'}-->			
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==3) break;}-->
                                                                                                        <span class="nimg xlmmlazy" style="background-repeat: no-repeat; background-size: cover; display: inline-block;" xlmmlazy="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment'].thumb.jpg">  </span>
<!--{/loop}-->
		<!--{/if}-->
 </div>
		<!--{/if}-->
 <span class="shadow-info"><span class="shadow-icon"><img src="$xlmmfxlh[avatar_middle]" class="icon-15"></span><span class="shadow-word shadow-name">$xlmmfxlh[author]</span><span class="shadow-word">$xlmmfxlh[dateline]</span><span class="shadow-word"><span class="shadow-eye"></span>$xlmmfxlh[views]</span></span>
	</div>
	</span>
        	<!--{if $xlmmal ==0 || $xlmmal >2}-->                
                                 <!--{elseif $xlmmal <=2}-->                
    				<!--{if $thread[idtype] == 'tid'}-->			
  <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment']; }
		<!--{/if}-->
 <span class="news-img xlmmlazy" style=" background-repeat: no-repeat; background-size: cover; display: inline-block;position:relative;padding-top:25%;" xlmmlazy="$xlmmimg"></span>
	 <!--{eval $i++}-->
<!--{eval if($i==1) break;}-->
<!--{/loop}--> 
		<!--{/if}-->
   					<!--{if $thread[idtype] == 'aid'}-->			
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==1) break;}-->
                                                                                                        <span class="news-img xlmmlazy" style=" background-repeat: no-repeat; background-size: cover; display: inline-block;position:relative;padding-top:25%;" xlmmlazy="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment'].thumb.jpg">  </span>
<!--{/loop}-->
		<!--{/if}-->

	<!--{/if}-->
</a>
    </section>
      <!--{/loop}--> 
</content>
<!--{/if}-->
<div id="xlmmpg" style="display:none;">$multi</div>
<script>
 var ias = jQuery.ias({
   container: "#waterfall", 
        item: "section", 
        pagination: ".pg", 
        next: ".pg a.nxt", 
    });
    ias.extension(new IASTriggerExtension({
        text: '<div class="ias-spinner" style="text-align: center;line-height:40px;color: #999;">������ظ���</div>', 
        offset: false, 
    }));
    ias.extension(new IASSpinnerExtension({
	html: '<div class="ias-spinner" style="text-align: center;line-height:40px;color: #999;"><img src="static/image/common/loading.gif" width="16" height="16" class="vm" /> ������...</div>',
}));
    ias.extension(new IASNoneLeftExtension({
        text: '<div style=" text-align:center; line-height:40px;color: #999;">������</div>', 
    }));
jQuery(".xlmmlazy").lazyload({
   effect: 'fadeIn',
	        });

ias.on('rendered', function(items) {	
jQuery(".xlmmlazy").lazyload({
   effect: 'fadeIn',
	        });
      })
</script>

<!-- main threadlist end -->

<div class="pullrefresh" style="display:none;"></div>


<!--{template common/footer}-->















