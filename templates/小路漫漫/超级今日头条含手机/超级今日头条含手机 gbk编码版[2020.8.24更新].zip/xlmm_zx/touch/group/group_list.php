<?PHP exit('Access Deniedxiaoluanman');?>
{if ! $_GET['forumlist'] != 1}
  <!--��ͼ-->
		<script src="template/xlmm_wsq/mobile_img/xlmm-pbl.js" type="text/javascript"></script> 
  <div class="wf_wrap">
    <div id="waterfall" class="cl">
    <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if $thread[attachment]==2}-->            
		{eval include TPLDIR.'/php/forumdisplay.php';}
     <div class="wf_item">
            <div class="wf_main">
                <div class="wf_pic">      <!--{eval $xlmm=0;}-->
<!--{loop $fpic $key $url}-->
  	  {if !$url[isimage] == 0}                                                                   
	   <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
<img src="{if $url[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}/forum/$url['attachment']" width="150" />
</a> <!--{eval $xlmm++}-->
<!--{eval if($xlmm==1) break;}-->
	{/if}
<!--{/loop}-->
</div>
                <div class="wf_title"><a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight]>{$thread[subject]}</a></div>
            </div>
        </div>

        <!--{/if}-->
        <!--{/loop}-->
    <!--{/if}-->
   </div>
 </div>
  {if $multipage}<div id="ajnt"><!--{if $_G['page'] > 1}-->
  <!--{eval $nxtpage = $page - 1;}-->
<a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}&page=$nxtpage&forumlist=1" hidefocus="true" style="margin-left:18px; margin-right:10px">��һҳ</a><!--{/if}--><a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}&page=$nextpage&forumlist=1" hidefocus="true">��һҳ</a>
</div>
{/if}
<script type="text/javascript">
jQuery(function(){
var jQuerycontainer = jQuery('#waterfall');
jQuerycontainer.imagesLoaded(function(){
jQuerycontainer.masonry({
itemSelector: '.wf_item',
columnWidth: 150,
gutterWidth: 16,
isAnimated: '!Modernizr.csstransitions',
cornerStampSelector: '.category',
isFitWidth: true
});
});
});
</script> 
  
  {else}
  
<!--{if !$subforumonly}-->
<div class="top">  
<div class="top-list-wrap">   
	<!--{if $livethread}-->
<div class="top-list"><div class="top-list-item"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="link "><label class="rec">ֱ��</label> <label class="rec">�ظ�$livethread[replies]</label>  <span class="name">{$thread[subject]}</span>  </a> </div></div>
	<!--{/if}-->
 <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
            <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
                {eval continue;}
            <!--{/if}-->
            <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                {eval $displayorder_thread = 1;}
            <!--{/if}-->
            <!--{if $thread['moved']}-->
                <!--{eval $thread[tid]=$thread[closed];}-->
            <!--{/if}-->
		<div class="top-list"><div class="top-list-item"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="link "><!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><label class="rec">��</label> <!--{/if}--><!--{if $thread['digest'] > 0}--><label class="rec">��</label> <!--{/if}--><!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
 <label class="rec">ͼ </label><!--{/if}--><span class="name">{$thread[subject]}</span>  </a> </div></div>
         <!--{/if}--> 
        <!--{/loop}-->
    <!--{/if}-->
 
   </div>
</div>
<!--{/if}-->
<!--{if !$subforumonly}-->
<ul class="item list" id="alist">   
     <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
		    <!--{if $thread['moved']}--><!--{eval $thread[tid]=$thread[closed];}--><!--{/if}-->
		{eval include TPLDIR.'/php/forumdisplay.php';}
<li class="ui-ignore-space section-1px new-feed"> 
<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"> <div class="user-wrap">
 <div class="user-avatar"> {avatar($thread[authorid],small)} </div>
 <div class="name-wrap"> <div class="name-section1"> <span class="author nick "> $thread[author] </span></div>
 <span class="post-datetime">$thread[dateline]</span> </div>
 <div class="read-icon-v3"> <i class="read-icon"></i> <div class="readnum">$thread[views]</div>
 </div>
 </div>
  <div class="go-detail"> <div class="report-content"> <p class="grouptitle feed-two-line">
  <!--{if $thread[folder] == 'lock'}-->
  <label class="best">����</label>  <!--{elseif $thread['special'] == 1}-->
  <label class="best">ͶƱ</label>  <!--{elseif $thread['special'] == 2}-->
  <label class="best">��Ʒ</label>  <!--{elseif $thread['special'] == 3}-->
  <label class="best">��</label>    <!--{elseif $thread['special'] == 4}-->
  <label class="best">�</label>  <!--{elseif $thread['special'] == 5}-->
  <label class="best">����</label>  <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
  <label class="best">��</label>   	<!--{elseif $thread['digest'] > 0}-->
  <label class="best">��</label>   <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}--><!--{/if}-->{$thread[subject]}</p> {if $xiaolu['fmessage']}<p class="groupbrief feed-two-line">$xiaolu['fmessage']</p> {/if}</div>
   <div class="xlmmimg{if $xl_num ==1} style1{elseif $xl_num ==2} style2{else} style3{/if} clearfix">  
   <!--{eval $xlmm=0;}-->
<!--{loop $fpic $key $url}-->
  	  {if !$url[isimage] == 0}               
	{if $xl_num ==1}
	   <div class="img_wrapper"> <img src="{if $url[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}/forum/$url['attachment']">   </div>
		{elseif $xl_num ==2}
				<!--{if $xlmm == '0'}-->
	   <div class="img_wrapper"> <img src="{if $url[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}/forum/$url['attachment']">   </div>
					<!--{elseif $xlmm == '1'}-->
	   <div class="img_wrapper"> <img src="{if $url[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}/forum/$url['attachment']">   </div>
		      <!--{/if}-->
{else}
			<!--{if $xlmm == '0'}-->
	   <div class="img_wrapper"> <img src="{if $url[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}/forum/$url['attachment']">   </div>
					<!--{elseif $xlmm == '1'}-->
	   <div class="img_wrapper"> <img src="{if $url[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}/forum/$url['attachment']">   </div>
					<!--{elseif $xlmm == '2'}-->
	   <div class="img_wrapper"> <img src="{if $url[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}/forum/$url['attachment']">{if $xl_num >=3}<span class="total-img"><span class="total-img-text">{eval echo $xl_num}</span></span>{/if}   
</div>
  	{/if}
      <!--{/if}-->
   <!--{eval $xlmm++}-->
<!--{eval if($xlmm==3) break;}-->
	{/if}
<!--{/loop}-->
</div>
 </a>  
  <div class="clearfix post-bottom-v3"> <div class="reply-btn-v3 post-btn-v3 clearfix">$thread[replies]</div>
<a href="forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&hash={FORMHASH}" class="like-btn-v3 post-btn-v3 clearfix recbtn" style="display:block">$thread[recommend_add]</a>
<a href="forum.php?mod=viewthread&tid=$thread[tid]&mobile=2#fpost" style="display:block" class="more-btn-v3 post-btn-v3 clearfix"></a>
 </div>
 </div>
</li>    
        <!--{/if}-->
        <!--{/loop}-->
         <!--{if $_G['forum_threadcount'] > $_G['tpp']}-->
        <div id="ajaxshow"></div>
        <div id="a_pg">
            <div id="ajaxld"></div>
            <a id="ajnt" href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}" onclick="return ajaxpage(this.href);">���������һҳ</a>
        </div>
		<script src="template/xlmm_wsq/mobile_img/xlmm-ajax.js" type="text/javascript"></script> 
		<script type="text/javascript">
		var pages=$_G['page'];
		var allpage={echo $thispage = ceil($_G['forum_threadcount'] / $_G['tpp']);};
		function ajaxpage(url){
						jq("ajaxld").style.display='block';
						jq("ajnt").style.display='none';
						var x = new Ajax("HTML");
						pages++;
						url=url+'&page='+pages;
						x.get(url, function (s) {
							s = s.replace(/\\n|\\r/g, "");//alert(s);
							s = s.substring(s.indexOf("<ul class=\"item list\" id=\"alist\""), s.indexOf("<div id=\"ajaxshow\"></div>"));//alert(s);
							jq('ajaxshow').innerHTML+=s;
							jq("ajaxld").style.display='none';
						if(pages==allpage){							
							jq("a_pg").style.display='none';
						}else{
							jq("ajnt").style.display='block';
						}
						});
						return false;
		}
		</script> 
		<!--{/if}-->
   <!--{else}-->
		<li class="mforum_no">{lang forum_nothreads}</li>
	<!--{/if}-->
</ul>
{/if}	<!--{/if}-->

<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]"><div class="publish-btn"></div></a>
<script type="text/javascript">
	$('.recbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=recbtn&inajax=1',
			data:{'recommendsubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>




