function _widthauto(obj) {
	var strs = ['<style>.xlmmappdjs {display:none;}</style>', '<style>.xlmmappdjs {display: none}</style>'];
	if($('css_widthauto')) {
		CSSLOADED['widthauto'] = 1;
	}
	if(!CSSLOADED['widthauto'] || $('css_widthauto').disabled) {
		if(!CSSLOADED['widthauto']) {
			loadcss('widthauto');
		} else {
			$('css_widthauto').disabled = false;
		}
		HTMLNODE.className += ' widthauto';
		setcookie('widthauto', 1, 86400 * 30);
		obj.innerHTML = strs[1];
	} else {
		$('css_widthauto').disabled = true;
		HTMLNODE.className = HTMLNODE.className.replace(' widthauto', '');
		setcookie('widthauto', -1, 86400 * 30);
		obj.innerHTML = strs[0];
	}
}





