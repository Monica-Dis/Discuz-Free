<?PHP exit('Access Deniedxiaoluanman');?>
<!--{template common/header}-->
<!-- main threadlist start -->
<style>
body{background-color:#fff !important;}
.swiper-container a div{ background:url(template/xlmm_zx/m-img/none.png); height:0; line-height:0;}
.swiper-pagination {bottom: 15px;}
/*banner*/
   html {font-size: 312.5%;}
#guide_banner{overflow:hidden;background-color:#fff; margin:-10px 0 0 -20px 0;;}           
.guide_banner_item{width:25%;float:left;text-align:center;margin:10px 0.6rem 10px 0 .6rem; margin-top:10px;}           
.guide_banner_item img{display:block;margin:0 auto;width:50%}           
.guide_banner_item em{color:#92979a;font-size:12px;line-height:2.6; display:block}           
</style>
<style>
	.hm { display:block;line-height:40px;color: #999 !important;}
content.feed-list-container .list_image .list_img_holder:first-child {margin-left: 0;}
</style>
<script src="template/xlmm_zx/m-img/loadm.js" type="text/javascript"></script>
<!--{loop $data $key $list}-->


				<!--{if $list['threadcount']}-->
{eval $page=$_G['page'];}
<content class="feed-list-container cl" id="threadlist" style="padding-top:0; margin-top:10px; background:#fff;" >
	<div id="waterfall">
						<!--{loop $list['threadlist'] $key $thread}-->
					<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
                                        	{eval include TPLDIR.'/php/forum_forumdisplay.php';}
<!--{if $xlmmal <1}-->
<section class="has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail">								
<h3 class="dotdot line3">										$thread[typehtml] $thread[sorthtml]
										$thread[subject]
</h3><div class="item_info"><div><span class="src space">$thread[author]</span><span class="cmt space">{lang reply} <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span><span class="time">$thread[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal >2}-->
<section class="has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail"><h3 class="dotdot line3">$thread[typehtml] $thread[sorthtml]
										$thread[subject]</h3>
<div class="list_image" style="margin-top:5px;">
<div class="clearfix">
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
<div class="list_img_holder"><img src="$xlmmimg"></div>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==3) break;}-->
<!--{/loop}-->
</div>
</div>
<div class="item_info"><div><span class="src space">$thread[author]</span><span class="cmt space">{lang reply} <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span><span class="time">$thread[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal <=2}-->
<section class="middle_mode has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail desc">
                                        <h3 class="dotdot line3 image-margin-right">$thread[typehtml] $thread[sorthtml]
										$thread[subject]</h3><div class="item_info"><div><span class="src space">$thread[author]</span><span class="cmt space">{lang reply} <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span><span class="time">$thread[dateline]</span><span class="dislike-news fr mid-space"></span></div></div></div>
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
 <div class="list_img_holders"><img src="$xlmmimg"></div>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==1) break;}-->
<!--{/loop}-->
</a></section>
<!--{/if}-->
						<!--{/loop}-->
</div>
						<div id="tmppic" style="display: none;"></div>


</content>
	{if $_G['page_next'] >1}
 		<div id="pgbtn" class="pgbtn"><span></span></div>

<script src="template/xlmm_zx/redef.js?EGs" type="text/javascript"></script>
<script type="text/javascript" reload="1">
var wf = {};

_attachEvent(window, "load", function () {
if($("waterfall")) {
wf = waterfall();
}

								var page = $page + 1,
maxpage = Math.min($page + 100,{echo $thispage = ceil($_G['forum_threadcount'] / 50);} + 1),
stopload = 0,
scrolltimer = null,
tmpelems = [],
tmpimgs = [],
markloaded = [],
imgsloaded = 0,
loadready = 0,
showready = 1,
wfloading = "<a class=\"hm\"><img src=\"static/image/common/loading.gif\" alt=\"\" width=\"16\" height=\"16\" class=\"vm\" /> ������...</a>",
pgbtn = $("pgbtn").getElementsByTagName("span")[0];

function loadmore() {
var url = 'forum.php?mod=guide&view={if $view == 'hot'}hot{elseif $view == 'newthread'}newthread{elseif $view == 'new'}new{elseif $view == 'digest'}digest{elseif $view == 'sofa'}sofa{elseif $view == 'my'}my{/if}&page=' + page + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
var x = new Ajax("HTML");
x.get(url, function (s) {
s = s.replace(/\n|\r/g, "");
if(s.indexOf("id=\"pgbtn\"") == -1) {
$("pgbtn").style.display = "none";
stopload++;
window.onscroll = null;
}

s = s.substring(s.indexOf("<div id=\"waterfall\""), s.indexOf("<div id=\"tmppic\""));
s = s.replace("id=\"waterfall\"", "");
$("tmppic").innerHTML = s;
loadready = 1;
});
}

window.onscroll = function () {
if(scrolltimer == null) {
scrolltimer = setTimeout(function () {
try {
if(page < maxpage && stopload < 2 && showready && ((document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.clientHeight + 500) >= document.documentElement.scrollHeight) {
pgbtn.innerHTML = wfloading;
loadready = 0;
showready = 0;
loadmore();
tmpelems = $("tmppic").getElementsByTagName("section");
var waitingtimer = setInterval(function () {
stopload >= 2 && clearInterval(waitingtimer);
if(loadready && stopload < 2) {
if(!tmpelems.length) {
page++;
	var xlmm = ['<a href="./" hidefocus="true" class=\"hm\">�鿴���� &raquo;</a>'];
pgbtn.innerHTML = xlmm;
showready = 1;
clearInterval(waitingtimer);
}
for(var i = 0, j = tmpelems.length; i < j; i++) {
if(tmpelems[i]) {
tmpimgs = tmpelems[i].getElementsByTagName("img");
imgsloaded = 0;
for(var m = 0, n = tmpimgs.length; m < n; m++) {
tmpimgs[m].onerror = function () {
this.style.display = "none";
};
markloaded[m] = tmpimgs[m].complete ? 1 : 0;
imgsloaded += markloaded[m];
}
if(imgsloaded == tmpimgs.length) {
$("waterfall").appendChild(tmpelems[i]);
wf = waterfall({
"index": wf.index,
"totalwidth": wf.totalwidth,
"totalheight": wf.totalheight,
"columnsheight": wf.columnsheight
});
}
}
}
}
}, 40);
}
} catch(e) {}
scrolltimer = null;
}, 320);
}
};

});
</script>
 {/if}    
				<!--{else}-->
					<p>{lang guide_nothreads}</p>
				<!--{/if}-->


	<!--{/loop}-->
<!-- main threadlist end -->

<div class="pullrefresh" style="display:none;"></div>
<!--{template common/footer}-->




