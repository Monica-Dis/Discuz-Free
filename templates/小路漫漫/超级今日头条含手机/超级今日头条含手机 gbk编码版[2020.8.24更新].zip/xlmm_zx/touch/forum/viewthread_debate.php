<?php exit;?>
<style>
/* ���� */
.xlmmbls1 {margin-top:20px;}
.xlmmbls1 .xlmmbls2 {}
.xlmmbls1 .xlmmbls2 .z,.xlmmbls1 .xlmmbls2 .y {height: 40px;line-height: 40px;font-size: 18px;}
.xlmmbls1 .xlmmbls2 .z {color: #fcad30;}
.xlmmbls1 .xlmmbls2 .y {color: #41c2fc;}
.xlmmbls1 .blbf_zfjd {width: 100%;height: 15px;margin-bottom: 10px;}
.xlmmbls1 .blbf_zfjd .z {width: 42%;height: 15px;background: #ECECEC;border-radius: 15px;}
.xlmmbls1 .blbf_zfjd .y {width: 42%;height: 15px;background: #ECECEC;border-radius: 15px;}
.xlmmbls3 {margin-bottom:10px;}
.xlmmbls3 .blgd_sfgd {width: 42%;border: 1px solid #ECECEC;border-radius: 3px;}
.xlmmbls3 .blgd_sfgd .sfgd_gdys {height: 30px;line-height: 30px;background: #ECECEC;font-size: 14px;padding: 0 10px;color: #777;}
.xlmmbls3 .blgd_sfgd .sfgd_gdys i {margin-left:5px;font-size: 12px;color: #888;}
.xlmmbls3 .blgd_sfgd .sfgd_gdnr {line-height: 25px;color: #333;font-size: 14px;padding: 10px;}
.xlmmbl_blzc {margin-bottom:15px;background: url(template/xlmm_zx/m-img/vs.png) no-repeat;background-position: center;background-size: 40px auto;}
.xlmmbl_blzc a {width: 42%;height: 35px;line-height: 37px;text-align: center;font-size: 14px;color: #fff;border-radius: 3px;display: block;}
_::-webkit-full-page-media, _:future, :root .xlmmbl_blzc a {line-height: 35px;}
.xlmmbl_blzc .z {background: #fcad30;}
.xlmmbl_blzc .y {background: #41c2fc;}
.xlmmbl_bljs {margin-bottom:30px;text-align: center;font-size: 14px;color: #555;}
.xlmmbl_bljs a {color:#ff6b6e;}
.xlmmbl_jsbl {width: 250px;position: relative;background: #fff;border: 1px solid #f3f3f3;padding:15px;border-radius: 3px;}
.xlmmbl_jsbl .ztds_gbck {display: block;position: absolute;top: -1px;right: -1px;width:25px;height:25px;background: url(template/xlmm_zx/m-img/blgb.png) no-repeat;background-position: 0;background-size: 25px auto;}
.xlmmbl_jsbl .jsbl_hsfd {margin:10px 0;}
.xlmmbl_jsbl .jsbl_hsfd .hsfd_btys {margin-bottom:3px;font-size: 16px;color: #000;}
.xlmmbl_jsbl .jsbl_hsfd .lb {display: block;float: left;width: 33%;font-size: 14px;color: #666;}
.jsbl_zjbs {border-top: 1px solid #f3f3f3;border-bottom: 1px solid #f3f3f3;margin-bottom:10px;padding:10px 0;}
.jsbl_zjbs .zjbs_btys {margin-bottom:3px;font-size: 16px;color: #000;}
.jsbl_zjbs .ps {width: 100%;height: 30px;padding: 0 2%;margin-bottom:5px;border: 1px solid #DDDADA;background: #fff;color: #999;border-radius: 3px;-webkit-appearance:none;}
.jsbl_zjbs .px {width: 95%;height: 28px;padding: 0 2%;border:0;border: 1px solid #DDDADA;border-radius: 3px;-webkit-appearance:none;}
.jsbl_zjbs .d {font-size: 12px;color: #999;}
.jsbl_cpgd {margin-top:10px;}
.jsbl_cpgd .cpgd_btys {margin-bottom:3px;font-size: 16px;color: #000;}
.jsbl_cpgd .pt {width: 100%;height: 50px;border: 1px solid #DDDADA;background: #fff;border-radius: 3px;}
.jsbl_jsan {margin:15px 0;}
.jsbl_jsan .pn {width: 100%;height: 35px;background: #99db5f;color: #fff;font-size: 14px;border: 0;border-radius: 3px;}
.xlmmbl_blhs {background: #fefced url(template/xlmm_zx/m-img/bljb.png) no-repeat;background-position: 8px;background-size: 40px auto;}
.xlmmbl_blhs .blhs_hsfd {font-size: 20px;}

</style>
<!--{if $debate[umpire]}-->
<!--{if $debate['umpirepoint']}-->
	<div class="xlmmbl_ztts xlmmbl_blhs cl">
		<p class="blhs_hsfd">
			<!--{if $debate[winner]}-->
			<!--{if $debate[winner] == 1}-->
			<label><strong>{lang debate_square}{lang debate_winner}</strong></label>
			<!--{elseif $debate[winner] == 2}-->
			<label><strong>{lang debate_opponent}{lang debate_winner}</strong></label>
			<!--{else}-->
			<label><strong>{lang debate_draw}</strong></label>
			<!--{/if}-->
			<!--{/if}-->
		</p>
		<p><strong>{lang debate_comment_dateline}</strong>: $debate[endtime]</p>
		<!--{if $debate[umpirepoint]}--><p><strong>{lang debate_umpirepoint}</strong>: $debate[umpirepoint]</p><!--{/if}-->
		<!--{if $debate[bestdebater]}--><p><strong>{lang debate_bestdebater}</strong>: $debate[bestdebater]</p><!--{/if}-->
	</div>
<!--{/if}-->
<!--{/if}-->
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>
<div class="xlmmbls1 cl">
	<div class="xlmmbls2 cl">
		<div class="z cl">���� {echo $debate[affirmvoteswidth]}%</div>
		<div class="y cl">{echo $debate[negavoteswidth]}% ����</div>
	</div>
	<div class="blbf_zfjd cl">
		<div class="z cl"><div style="height: 15px;width: {echo $debate[affirmvoteswidth]}%;background:#fcad30;border-radius: 15px;">&nbsp;</div></div>
		<div class="y cl"><div style="height: 15px;width: {echo $debate[negavoteswidth]}%;background:#41c2fc;border-radius: 15px;">&nbsp;</div></div>
	</div>
	<div class="xlmmbls3 cl">
		<div class="blgd_sfgd z cl"><div class="sfgd_gdys">{lang debate_square_point}<i>{lang debater}:$debate[affirmdebaters]</i></div><div class="sfgd_gdnr">$debate[affirmpoint]</div></div>
		<div class="blgd_sfgd y cl"><div class="sfgd_gdys">{lang debate_opponent_point}<i>{lang debater}:$debate[negadebaters]</i></div><div class="sfgd_gdnr">$debate[negapoint]</div></div>
	</div>
	<div class="xlmmbl_blzc cl">
		<!--{if !$_G['forum_thread']['is_archived']}--><a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" id="affirmbutton" class="z {if $_G['uid']}dialog{/if} cl" >{lang debate_support}���� $debate[affirmvotes]</a><!--{/if}-->
		<a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" id="negabutton" class="y {if $_G['uid']}dialog{/if} cl">{lang debate_support}���� $debate[negavotes]</a>
	</div>
	<div class="xlmmbl_bljs cl">
		<!--{if $debate[endtime]}--><p>{lang endtime}: $debate[endtime] <!--{if $debate[umpire]}-->{lang debate_umpire}: $debate[umpire]<!--{/if}--></p><!--{/if}-->
		<!--{if $debate[umpire] && $_G['username'] && $debate[umpire] == $_G['member']['username']}-->
		<!--{if $debate[remaintime] && !$debate[umpirepoint]}-->
			<a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" class="{if $_G['uid']}dialog{/if}" >{lang debate_umpire_end}</a>
		<!--{elseif TIMESTAMP - $debate['dbendtime'] < 3600}-->
			<a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" class="{if $_G['uid']}dialog{/if}" >{lang debate_umpirepoint_edit}</a>
		<!--{/if}-->
		<!--{/if}-->
	</div>
</div>

