<?PHP exit('Access Deniedxiaoluanman');?>
<!--{template common/header}-->
<style>
	.hm { display:block;line-height:40px;color: #999 !important;}
content.feed-list-container .list_image .list_img_holder:first-child {margin-left: 0;}
</style>

<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->
	<!--{if in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmsplb']))}-->
<style>

content.feed-list-container {position: relative;display: block; background:#fff; padding-top:0;}
content.feed-list-container .list_content {-webkit-margin-after-collapse: separate;-webkit-margin-before-collapse: discard;-webkit-user-select: none;}
content.feed-list-container section {position: relative;-webkit-transition: all 1s ease-in-out;margin: 0px 6px;border-bottom: 1px solid rgba(221, 221, 221, 0.6);}
[data-dpr="2"] content.feed-list-container section {margin: 0px 30px;}
[data-dpr="3"] content.feed-list-container section {margin: 0px 45px;}
content.feed-list-container .article_link {display: block;position: relative;padding: 10px 0px;min-height: 42px;font-size: 0px;text-decoration: none;-webkit-tap-highlight-color: rgba(0, 0, 0, 0.1);-webkit-touch-callout: none;}
[data-dpr="2"] content.feed-list-container .article_link {padding: 32px 0px;}
[data-dpr="3"] content.feed-list-container .article_link {padding: 48px 0px;}
[data-dpr="2"] content.feed-list-container .article_link {min-height: 84px;}
[data-dpr="3"] content.feed-list-container .article_link {min-height: 126px;}
content.feed-list-container .article_link:visited h3 {color: #aaa;}
content.feed-list-container .article_link.channel__video .dotdot {position: absolute;top: 0;color: #fff;margin: 5px 10px;font-size: 14px;display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;overflow: hidden;text-overflow: ellipsis;}
[data-dpr="2"] content.feed-list-container .article_link.channel__video .dotdot {margin: 10px 20px;}
[data-dpr="3"] content.feed-list-container .article_link.channel__video .dotdot {margin: 15px 30px;}
[data-dpr="2"] content.feed-list-container .article_link.channel__video .dotdot {font-size: 28px;}
[data-dpr="3"] content.feed-list-container .article_link.channel__video .dotdot {font-size: 42px;}
content.feed-list-container .article_link.channel__video .video_mask {position: absolute;top: 0;left: 0;width: 100%;height: 40%;background: -webkit-gradient(linear, left top, left bottom, from(rgba(0, 0, 0, 0.8)), to(rgba(0, 0, 0, 0)));background: linear-gradient(to bottom, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0));}
content.feed-list-container .desc {display: inline-block;width: 67%;vertical-align: middle;}
content.feed-list-container h3 {color: #222;font-size: 17px;line-height: 21px;font-weight: normal;overflow: hidden;}
[data-dpr="2"] content.feed-list-container h3 {font-size: 34px;}
[data-dpr="3"] content.feed-list-container h3 {font-size: 51px;}
[data-dpr="2"] content.feed-list-container h3 {line-height: 42px;}
[data-dpr="3"] content.feed-list-container h3 {line-height: 63px;}
content.feed-list-container .dotdot {overflow: hidden;text-overflow: ellipsis;display: -webkit-box;display: box;-webkit-box-orient: vertical;}
content.feed-list-container .image-margin-right {margin-right: 12px;}
[data-dpr="2"] content.feed-list-container .image-margin-right {margin-right: 24px;}
[data-dpr="3"] content.feed-list-container .image-margin-right {margin-right: 36px;}
content.feed-list-container .list_image,
content.feed-list-container .list_img_holder_large {margin-top: 6px;}
[data-dpr="2"] content.feed-list-container .list_image,
[data-dpr="2"] content.feed-list-container .list_img_holder_large {margin-top: 12px;}
[data-dpr="3"] content.feed-list-container .list_image,
[data-dpr="3"] content.feed-list-container .list_img_holder_large {margin-top: 18px;}
content.feed-list-container .list_image ul {display: block;margin: 0;padding: 0;list-style-type: none;font-size: 0;text-align: center;}
content.feed-list-container .list_image ul li {display: inline-block;overflow: hidden;width: 33.3%;-webkit-box-sizing: border-box;box-sizing: border-box;}
content.feed-list-container .list_image ul li:first-child {float: left;padding-right: 2px;}
[data-dpr="2"] content.feed-list-container .list_image ul li:first-child {padding-right: 4px;}
[data-dpr="3"] content.feed-list-container .list_image ul li:first-child {padding-right: 6px;}
content.feed-list-container .list_image ul li:last-child {float: right;padding-left: 2px;}
[data-dpr="2"] content.feed-list-container .list_image ul li:last-child {padding-left: 4px;}
[data-dpr="3"] content.feed-list-container .list_image ul li:last-child {padding-left: 6px;}
content.feed-list-container .list_img_holder {height: 1.96875rem;position: relative;background: url(template/xlmm_zx/image/xlmmload.gif) #efefef no-repeat center center;background-size: 50%;}
content.feed-list-container .middle_mode .list_img_holder {overflow: hidden;width: 33%;display: inline-block;vertical-align: middle;}
content.feed-list-container .list_img_holder img {border: none;display: block;width: 100%;-webkit-transition: opacity 300ms ease;-moz-transition: opacity ease .3s;pointer-events: none;-webkit-tap-highlight-color: rgba(0, 0, 0, 0);-webkit-user-select: none;text-decoration: none;}
content.feed-list-container .list_img_holder_large {background: url(data:image/gif;base64,R0lGODlh7AA5AIAAAOHh4f///yH5BAEAAAEALAAAAADsADkAAAL/jI+py+0Po5y02ouz3hv4D4YhR2YiWAbnmJrry3bwTNdeRFNwWbeYPeMAh0SAJHd8kYpMZbIZ+0GnUUcP59RQt8/tzeWdTq6PnTYMxaK/l3V6HISYpe6iHKjCt+t2XdyaZcHHVKZnYOg3iNi1Uti4pzgESIYgmXjS8genqTBXQQmJtLBYSTqJmcLJ+DgauOkZKlpq4wh6KpIJ+8ra6aqme2mbR3tHXIzKA7yK28rrE6t6aMpgWcuc7BuMPLstaHwryx1+PN7rLJP9LF7l/Z1A1FCtrXxAD82uvo4iRCpvLjyMzbtp0s6dSZcv4DV+xOCBS2fQn74PuRBO3LeMYio+/wkLdsP28aDBfyOpWaTjpaPHkAxZonQ50F5MmCLfdARYEx+YkiRp1juJro9KhTxf6jR6tBlQohjz2bxZLujClj4vNjVZNCchqNGkJm2XdeZJmUjFOI2qVSPIqmJpkv006OxbuJFwPkw695eiZ1291g2rtGTeu3Ga+Fh67+/UeToHB3bHFHLOhIrRkouI+LHdp0OXVHbcdnFkgbskY3XYmernr3wzewacmutq0bJpy2UbbzZQ0IRJD+W903ZG3UassWastnNfdcB/Ehe+8njpo885Vb9O0Dluvbaxf/QOfrfry9TDJ49uHjz5836vWiWuGXtsu+jZp7Vfv3r86/Mt5+wvvlZ35p2mnnKmWVURbIll9x98vx2I4Ebj0SUUZRP251+EAUq3IH29hZZcc2VtJ2JPHFJoGFjdeLLcYRDuB+BrCk63FXIx/gcifi5mCGOC2w03Ao/vmcheiev9qB10KCq5JCtC4kikby3exySBJx7pG5VNeQhllDc2yNyLxunmoy9CKoPmhb1dCaNiY3LR5pdeWtmYkUnayd+bZsUpp4ajCahmjlViGQmQNdKJlyselshgk3/RmKKeOsLC45S5cWljXJBWuGaWugxmqZdsEuqGipxJ6qmZM/5paqCdohFbrMAgGWuttt6Ka2wFAAA7) #efefef no-repeat center center;background-size: 54px;overflow: hidden;width: 100%;position: relative;min-height: 3.75rem;max-height: 20rem; overflow:hidden;}
[data-dpr="2"] content.feed-list-container .list_img_holder_large {background-size: 108px;}
[data-dpr="3"] content.feed-list-container .list_img_holder_large {background-size: 162px;}
content.feed-list-container .list_img_holder_large img {border: none;display: block;width: 100%;pointer-events: none;}
content.feed-list-container .list_img_holder_large_fix {height: 4.6875rem;}
content.feed-list-container .item_info {color: #999;overflow: hidden;font-size: 0;margin-top: 6px;}
[data-dpr="2"] content.feed-list-container .item_info {margin-top: 12px;}
[data-dpr="3"] content.feed-list-container .item_info {margin-top: 18px;}
content.feed-list-container .item_info .space {margin-right: 5px;}
[data-dpr="2"] content.feed-list-container .item_info .space {margin-right: 10px;}
[data-dpr="3"] content.feed-list-container .item_info .space {margin-right: 15px;}
content.feed-list-container .item_info .mid-space {margin-right: 8px;}
[data-dpr="2"] content.feed-list-container .item_info .mid-space {margin-right: 16px;}
[data-dpr="3"] content.feed-list-container .item_info .mid-space {margin-right: 24px;}
content.feed-list-container .item_info span {display: inline-block;font-size: 10px;line-height: 12px;vertical-align: middle;}
[data-dpr="2"] content.feed-list-container .item_info span {font-size: 20px;}
[data-dpr="3"] content.feed-list-container .item_info span {font-size: 30px;}
[data-dpr="2"] content.feed-list-container .item_info span {line-height: 24px;}
[data-dpr="3"] content.feed-list-container .item_info span {line-height: 36px;}
content.feed-list-container .video-btnxl {display: block; position: absolute; left: 0;top: 0;   bottom: 0;  right: 0; background: url(template/xlmm_zx/m-img/video.png) no-repeat center center;background-size: 50px;}
[data-dpr="3"] content.feed-list-container .list_img_holder_large .video-btnxl {  background-size: 150px;}
</style>


<content class="feed-list-container">
<div class="list_content">
   <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
		    <!--{if $thread['moved']}--><!--{eval $thread[tid]=$thread[closed];}--><!--{/if}-->
				{eval include TPLDIR.'/php/forum_forumdisplay.php';}
  <!--{hook/forumdisplay_thread_mobile $key}-->  



{if $xlmmout || $_G['optionvaluelist'][$thread['sortid']][$thread['tid']]['xlmmvimage'][value]}
    	<section class="has_action">
    <a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link cl channel__video">
	<div class="item_detail">
		<div class="list_img_holder_large">
			<div class="video_mask">
			</div>
			<h3 class="dotdot line3">$thread[subject]</h3>
		{if $xlmmout}
<img src="$xlmmout">{else}{$_G['optionvaluelist'][$thread['sortid']][$thread['tid']]['xlmmvimage'][value]}{/if}
<span class="video-btnxl"></span>
</div>
		<div class="item_info">
			<div>
		<span class="src space">$thread[author]</span><span class="cmt space">��� $thread[views]</span><span class="time">������ $thread[dateline]</span><span class="dislike-news fr"></span>
			</div>
		</div>
	</div>
	</a>
    </section>
		 {elseif $xlmmouts[0][7] || $xlmmvideo[0][3] }
    <section class="has_action">
	<i class="icon_ad">
	<spa>
	</span>
	</i>
	<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link cl ">
	<h3 class="dotdot line3 ">
      $thread[subject]
	</h3>
	<div class="list_img_holder_large ">
{if $xlmmouts[0][7]} <video controls style="width:100%; height:200px; background:#000;"><source src=$xlmmouts[0][7] type="video/mp4"></video>
{elseif $xlmmvideo[0][3] }                                                                             
                 {if preg_match('/youtube.com\/watch(.*)v=(.*)/',$xlmmvideo[0][3],$reg)}
   <embed src="https://www.youtube.com/v/{$reg[2]}" width="100%" height="268"  wmode="transparent">
                           {elseif preg_match('/tencentvideo(.*)\/TPout.swf?(.*)/',$xlmmvideo[0][3],$reg)}
              <iframe src="http://v.qq.com/iframe/player.html{$reg[2]}" frameborder=0 allowfullscreen style="width:100%;;height:268px;"></iframe>
                            {elseif preg_match('/(.*).qq.com\/(.*)\/(.*)vid=(.*)/',$xlmmvideo[0][3],$reg)}
              <iframe src="https://v.qq.com/txp/iframe/player.html?vid={$reg[4]}" frameborder=0 allowfullscreen style="width:100%;;height:268px;"></iframe>
                            {elseif preg_match('/(.*).qq.com\/(.*)\/(.*)\/(.*)\/(.*).html(.*)/',$xlmmvideo[0][3],$reg)}
              <iframe src="https://v.qq.com/txp/iframe/player.html?vid={$reg[5]}" frameborder=0 allowfullscreen style="width:100%;;height:268px;"></iframe>
                                        {elseif preg_match('/sid\/(.*)\//',$xlmmvideo[0][3],$reg)}
              <iframe src="http://player.youku.com/embed/{$reg[1]}==" frameborder=0 allowfullscreen style="width:100%;;height:268px;"></iframe>
                                         {elseif preg_match('/(.*).youku.com\/(.*)\/id_(.*).html(.*)/',$xlmmvideo[0][3],$reg)}
              <iframe src="http://player.youku.com/embed/{$reg[3]}==" frameborder=0 allowfullscreen style="width:100%;;height:268px;"></iframe>
                                                    {elseif preg_match('/(.*).qiyi.com\/(.*)\/(.*)\/(.*)\/(.*).swf-albumId(.*)-(.*)-(.*)-(.*)/',$xlmmvideo[0][3],$reg)}
            <iframe src="http://open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid={$reg[2]}&amp;{$reg[7]}" frameborder="0" allowfullscreen="true" style="width:100%;;height:268px;"></iframe>
                                               {elseif preg_match('/player.ku6.com\/(.*)\/(.*)\//',$xlmmvideo[0][3],$reg)}
           <script data-vid="{$reg[2]}" src="http://js.ku6cdn.com/player/out/2.1.0.js" data-width="100%" data-height="100%"></script>
 {/if}
 
{/if}
</div>
	<div class="item_info">
		<span class="src space">$thread[author]</span><span class="cmt space">��� $thread[views]</span><span class="time">������ $thread[dateline]</span><span class="dislike-news fr"></span>
	</div>
	</a>
	</section>
{else}
    	<section class="has_action">
    <a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link cl channel__video">
	<div class="item_detail">
		<div class="list_img_holder_large">
			<div class="video_mask">
			</div>
			<h3 class="dotdot line3">$thread[subject]</h3>
<img src="template/xlmm_zx/m-img/timg.jpg">
<span class="video-btnxl"></span>
</div>
		<div class="item_info">
			<div>
		<span class="src space">$thread[author]</span><span class="cmt space">��� $thread[views]</span><span class="time">������ $thread[dateline]</span><span class="dislike-news fr"></span>
			</div>
		</div>
	</div>
	</a>
    </section>
 {/if}
 	        <!--{/if}-->
			<!--{/loop}-->
  	        <!--{/if}-->
  
</div>
$multipage
</content>
	<!--{elseif in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
<script src="template/xlmm_zx/m-img/loadm.js" type="text/javascript"></script>
  <script src="template/xlmm_zx/load.js?EGs" type="text/javascript"></script>
  <script src="template/xlmm_zx/m-img/mb.js?{VERHASH}" charset="{CHARSET}"></script>
<script>var formhash = '{FORMHASH}', allowrecommend = '1';</script>
<script src="template/xlmm_zx/m-img/fav.js?{VERHASH}" charset="{CHARSET}"></script>
   <style> 
body{background-color:#efeff4;}

.tl_top {background-color: #fff;padding: 0 15px;}
.tl_top .ti_item {height: 40px;line-height: 40px;}
.tl_top .ti_title {font-size: 0;margin: 0; color: #000;height: 40px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;padding: 0;line-height: 40px;word-break: break-all;}
.ti_title_icon {position: relative;display: inline-block;line-height: 24px;height: 24px;margin-right: 9px;color: #d43d3d;}
.tl_top .ti_title span {font-size: 13px;}
.scale-1px-bottom { border-bottom:1px solid #F0F0F0}
/* forum list-icn */
.light_forum_top_area {min-height: 54px;position: relative;background-color: #fff;padding: 17px 15px;}
.forum_portrait {float: left;margin-right: 12px;width: 54px;height: 54px;background-repeat: no-repeat;background-size: contain;}
.forum-name {color: #000;font-size: 16px;line-height: 18px;margin-top: 3px;}
.forum-name-txt {vertical-align: middle;}
.function-area {margin: 0 1px 0 0;display: -webkit-box;}
.info_paragraph {margin: 7px 0 0;line-height: 13px;font-size: 13px;height: 13px;overflow: hidden;word-break: break-all;}
.info_label {color: #666;margin: 0 4px 0 12px;}
.info_label:first-child {margin-left: 0;}
.info_value {color: #666;}
.scale-1px {position: relative;margin-bottom: 20px;border: 0;}
a.operation_right_btn {position: absolute;top: 30px;right: 17px;margin-left: -60px;color: #d43d3d;font-size: 12px;outline: 0;padding: 5px 10px;-webkit-tap-highlight-color: transparent;border-radius: 4px;}
a.operation_right_btn i{margin-right:5px;}
.scale-1px:after {content: " ";position: absolute;top: 0;left: 0;border: 1px solid #d43d3d;-webkit-box-sizing: border-box;box-sizing: border-box;width: 200%;height: 200%;-webkit-transform: scale(0.5);transform: scale(0.5);-webkit-transform-origin: left top;transform-origin: left top;}
.operation_right_btn::after {border: 1px solid #d43d3d;border-radius: 4px;}
		      </style> 
<div class="light_forum_top_area cl">
	<div class="forum_portrait" style="background-image:url(<!--{if $_G[forum][icon]}-->data/attachment/common/$_G['forum']['icon']<!--{else}-->template/xlmm_zx/m-img/icon.png<!--{/if}-->);">
	</div>
	<p class="forum-name">
		<span class="forum-name-txt">{$_G['forum']['name']}</span>
	</p>
	<div class="function-area">
		<p class="info_paragraph">
			<span class="info_label">����</span><span class="info_value">$_G[forum][threads]</span><span class="info_label">����</span><span class="info_value">$_G[forum][posts]</span>
		</p>
	           <!--{eval $xlmmlk=DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$_G[forum]['fid']."");}--> 
<!--{if $xlmmlk[id]}--><a href="home.php?mod=spacecp&amp;ac=favorite&amp;op=delete&amp;type=forum&amp;formhash={FORMHASH}&amp;favid=$xlmmlk[favid]&amp;handlekey=forum_fav" class="dialog xlmmfygz xlmm_forum_fav_$_G[forum]['fid'] scale-1px operation_right_btn" xlmm="handle">�ѹ�ע</a><!--{else}--><a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[forum]['fid']&formhash={FORMHASH}&handlekey=forum_fav" class="dialog xlmmfwgz xlmm_forum_fav_$_G[forum]['fid'] scale-1px operation_right_btn" xlmm="handle"><i>+</i>��ע</a><!--{/if}-->
	</div>
	</div>

        <!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
	<!-- ������� start -->
      <style> 
.threadlist { background:#fff; margin-top:10px;}
.adtopic { padding:10px;background: #fff; margin-top:10px;}
.adtopic-list ul li {float: left;margin-right: 10px;margin-top:5px;font-size: 14px;}
.adtopic-list ul {}
.adtopic-list ul li a {display: inline-block;color: #222222;background-color: #f5f5f5; padding:5px 10px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;}
.adtopic-list ul li.a a {color: #d43d3d;}
.adtopic-list ul li span { color:red; margin-left:2px; display:none;}

		      </style> 
<div class="adtopic cl"> 
                  <div class="adtopic-list" >
            <ul>
                                    <li {if !$_GET['typeid'] && !$_GET['sortid']}class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">ȫ������</a></li>
           						<!--{if $_G['forum']['threadtypes']}-->
							<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
												<!--{if $_GET['typeid'] == $id}-->
				<li class="a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[typeid][$id]}--><span>($showthreadclasscount[typeid][$id])</span><!--{/if}--></a></li>
                								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[typeid][$id]}--><span>$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
						<!--{/if}-->
        							<!--{/loop}-->
						<!--{/if}-->
						<!--{if $_G['forum']['threadsorts']}-->
    							<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
														<!--{if $_GET['sortid'] == $id}-->
		<li class="a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[sortid][$id]}--><span>($showthreadclasscount[sortid][$id])</span><!--{/if}--></a></li>								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[sortid][$id]}--><span>$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
								<!--{/if}-->

							<!--{/loop}-->
						<!--{/if}-->
 </ul>
          </div>
                        </div>
 	<!-- ������� end -->
    <!--{/if}-->
			<!--{if $subexists && $_G['page'] == 1}--><!--{template forum/forumdisplay_subforum}--><!--{/if}-->
	<!--{if empty($_G['forum']['sortmode'])}-->
<!--{if !$subforumonly}-->
   <ul class="mtm">   
 <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
            <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
                {eval continue;}
            <!--{/if}-->
            <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                {eval $displayorder_thread = 1;}
            <!--{/if}-->
            <!--{if $thread['moved']}-->
                <!--{eval $thread[tid]=$thread[closed];}-->
            <!--{/if}-->
	<li class="tl_top scale-1px-bottom"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class=" ti_item"><div class="ti_title"><!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><span class="ti_title_icon">�ö�</span> <!--{/if}--><!--{if $thread['digest'] > 0}--><span class="ti_title_icon">����</span> <!--{/if}--><span>{$thread[subject]}</span></div></a></li>
         <!--{/if}--> 
        <!--{/loop}-->
    <!--{/if}-->
  </ul> 
<!--{/if}-->

<content class="feed-list-container cl" id="threadlist" style="padding-top:0; margin-top:10px; background:#fff;" >
	<div id="waterfall">
   <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
		    <!--{if $thread['moved']}--><!--{eval $thread[tid]=$thread[closed];}--><!--{/if}-->
				{eval include TPLDIR.'/php/forum_forumdisplay.php';}
  <!--{hook/forumdisplay_thread_mobile $key}-->  
<!--{if $xlmmal <1}-->
<section class="has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail">										<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
<h3 class="dotdot line3">										
										$thread[subject]
</h3><div class="item_info"><div><span class=" space">$thread[author]</span><span class="cmt space">���� <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span><span class="time">$thread[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal >$_G['cache']['plugin']['xlmm_tt']['xlmmmduotu']}-->
<section class="has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail"><h3 class="dotdot line3">
										$thread[subject]</h3>
<div class="list_image" style="margin-top:5px;">
<div class="clearfix">
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
<div class="list_img_holder"><img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="$xlmmimg" class="xlmmlazy"></div>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==3) break;}-->
<!--{/loop}-->
</div>
</div>
<div class="item_info"><div><span class=" space">$thread[author]</span><span class="cmt space">���� <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span><span class="time">$thread[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal <=$_G['cache']['plugin']['xlmm_tt']['xlmmmduotu']}-->
<section class="middle_mode has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail desc"><!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
                                        <h3 class="dotdot line3 image-margin-right">
										$thread[subject]</h3><div class="item_info"><div><span class=" space">$thread[author]</span><span class="cmt space">���� <!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}--></span><span class="time">$thread[dateline]</span><span class="dislike-news fr mid-space"></span></div></div></div>
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
 <div class="list_img_holders"><img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="$xlmmimg" class="xlmmlazy"></div>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==1) break;}-->
<!--{/loop}-->
</a></section>
<!--{/if}-->
	        <!--{/if}-->
			<!--{/loop}-->
<script type="text/javascript">
jQuery(document).ready(function() {
jQuery("img.xlmmlazy").lazyload();
});
</script>
   <!--{else}-->
		<div class="mforum_no" style="text-align:center; padding:15px 0;">{lang forum_nothreads}</div>
	<!--{/if}-->

</div>
						<div id="tmppic" style="display: none;"></div>


</content>
	{if $_G['forum_threadcount'] > $_G['tpp']}
 		<div id="pgbtn" class="pgbtn"><span></span></div>
{/if}

<script src="template/xlmm_zx/redef.js?EGs" type="text/javascript"></script>
<script type="text/javascript" reload="1">
	{if $_G['forum_threadcount'] > $_G['tpp']}
var wf = {};

_attachEvent(window, "load", function () {
if($("waterfall")) {
wf = waterfall();
}

								var page = $page + 1,
maxpage = Math.min($page + 100,{echo $thispage = ceil($_G['forum_threadcount'] / $_G['tpp']);} + 1),
stopload = 0,
scrolltimer = null,
tmpelems = [],
tmpimgs = [],
markloaded = [],
imgsloaded = 0,
loadready = 0,
showready = 1,
wfloading = "<a class=\"hm\"><img src=\"static/image/common/loading.gif\" alt=\"\" width=\"16\" height=\"16\" class=\"vm\" /> ������...</a>",
pgbtn = $("pgbtn").getElementsByTagName("span")[0];

function loadmore() {
var url = 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}&page=' + page + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
var x = new Ajax("HTML");
x.get(url, function (s) {
s = s.replace(/\n|\r/g, "");
if(s.indexOf("id=\"pgbtn\"") == -1) {
$("pgbtn").style.display = "none";
stopload++;
window.onscroll = null;
}

s = s.substring(s.indexOf("<div id=\"waterfall\""), s.indexOf("<div id=\"tmppic\""));
s = s.replace("id=\"waterfall\"", "");
$("tmppic").innerHTML = s;
loadready = 1;
});
}

window.onscroll = function () {
if(scrolltimer == null) {
scrolltimer = setTimeout(function () {
try {
if(page < maxpage && stopload < 2 && showready && ((document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.clientHeight + 500) >= document.documentElement.scrollHeight) {
pgbtn.innerHTML = wfloading;
loadready = 0;
showready = 0;
loadmore();
tmpelems = $("tmppic").getElementsByTagName("section");
var waitingtimer = setInterval(function () {
stopload >= 2 && clearInterval(waitingtimer);
if(loadready && stopload < 2) {
if(!tmpelems.length) {
page++;
	var xlmm = ['<a href="./" hidefocus="true" class=\"hm\">�鿴���� &raquo;</a>'];
pgbtn.innerHTML = xlmm;
showready = 1;
clearInterval(waitingtimer);
}
for(var i = 0, j = tmpelems.length; i < j; i++) {
if(tmpelems[i]) {
tmpimgs = tmpelems[i].getElementsByTagName("img");
imgsloaded = 0;
for(var m = 0, n = tmpimgs.length; m < n; m++) {
tmpimgs[m].onerror = function () {
this.style.display = "none";
};
markloaded[m] = tmpimgs[m].complete ? 1 : 0;
imgsloaded += markloaded[m];
}
if(imgsloaded == tmpimgs.length) {
$("waterfall").appendChild(tmpelems[i]);
wf = waterfall({
"index": wf.index,
"totalwidth": wf.totalwidth,
"totalheight": wf.totalheight,
"columnsheight": wf.columnsheight
});
}
}
}
}
}, 40);
}
} catch(e) {}
scrolltimer = null;
}, 320);
}
};

});
{/if}
</script>

				<!--{else}-->
 	<!--������Ϣ��ʼ-->
	<!--{if $quicksearchlist && !$_GET['archiveid']}-->
	 	<!--������Ϣɸѡ-->
      <style> 

.xlmmfhidden{position: relative;overflow: hidden;background: #fff; margin:10px 0 0 0;}
#gradient{width: 100%;height:40px;position: absolute;bottom: 0;left: 0;background: -moz-linear-gradient(bottom,rgba(255,255,255,.1),rgba(255,255,255,0));background: -webkit-gradient(linear,0 top,0 bottom,from(rgba(255,255,255,0)),to(#fff));background: -o-linear-gradient(bottom,rgba(255,255,255,.1),rgba(255,255,255,0));}
#read-more a{text-decoration: none; display:block; width:100%;background: #fff;color: {$_G['cache']['plugin']['xlmm_tt']['xlmmcol']}!important; margin-bottom:10px; padding-top:10px; padding-bottom:10px; }
#read-more a i{ }
#read-more a em{}
.text-center{text-align:center;}
.xlmmf-mlsc {}
.xlmmf-mlsc .xlmmf-mlscs {margin-bottom:10px;}
.xlmmf-mlsc .xlmmf-mlscs .tsm {width: 100%}
.xlmmf-mlsc .xlmmf-mlscs th {padding: 10px;background: #fff;border-bottom: 1px solid #f5f5f5;font-size: 14px;color: #666;text-align: center;}
.xlmmf-mlsc .xlmmf-mlscs td {padding: 10px;border: 1px solid #f5f5f5;}
.xlmmf-mlsc .xlmmf-mlscs td li {float: left;height: 28px;line-height: 30px;padding: 0 8px;text-align: center;}
.xlmmf-mlsc .xlmmf-mlscs td li a {font-size: 14px;color: #333;}
.xlmmf-mlsc .xlmmf-mlscs td li.a {border-radius: 2px;background: {$_G['cache']['plugin']['xlmm_tt']['xlmmcol']}!important;}
.xlmmf-mlsc .xlmmf-mlscs td li.a a {color: #fff;}
.xlmmf-mlsc .xlmmf-mlscs .subtsm {margin-top:10px;padding:10px;background: #f9f9f9;border: 1px solid #f4f4f4;border-radius: 2px;}
.xlmmf-mlsc .xlmmf-mlscs .subtsm li {height: 24px;line-height: 25px;padding: 0 6px;}
.xlmmf-mlsc .xlmmf-mlscs .subtsm li a {font-size: 13px;color: #666;}
.xlmmf-mlsc .flsx_zdss {width: 100%;}
.xlmmf-mlsc .flsx_zdss .zdss_ssli {height: 45px;}
.xlmmf-mlsc .flsx_zdss .zdss_ssli i {float: left;width:25%;line-height: 35px;font-size: 14px;color: #333;text-align: center;display: block;}
.xlmmf-mlsc .flsx_zdss .zdss_ssli .zdss_srks {line-height: 30px;border: 1px solid #E2E2E2;background: #F8F8F8;font-size: 14px;padding: 3px 5px;border-radius: 4px;}
.xlmmf-mlsc .flsx_zdss .zdss_qdys {margin:8px 10px 15px 10px;}
.xlmmf-mlsc .flsx_zdss .zdss_qdys .fm-scbt {width: 100%;height: 45px;line-height: 47px;border-radius: 5px;background: {$_G['cache']['plugin']['xlmm_tt']['xlmmcol']}!important;font-size: 14px;color: #fff;border: 0;display: block;text-align: center;}

</style>
    
<div class="xlmmfhidden">
	<div class="xlmmf-mlsc cl">
<script type="text/javascript">
	var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
</script>
<script type="text/javascript" src="{$_G['setting']['jspath']}threadsort.js?{VERHASH}"></script>

<!--{loop $quicksearchlist $optionid $option}-->
		<!--{eval $formsearch = '';}-->
        <!--{if getstatus($option['search'], 1)}-->
        	<!--{block formsearch}-->
	            <div class="zdss_ssli cl">
	                <i>$option[title]</i>
	                <!--{if in_array($option['type'], array('radio', 'checkbox', 'select', 'range'))}-->
	                    <span id="select_$option[identifier]">
	                    <!--{if $option[type] == 'select'}-->
	                        <!--{if $_GET[searchoption][$optionid][value]}-->
	                            <script type="text/javascript">
	                                changeselectthreadsort('$_GET[searchoption][$optionid][value]', $optionid, 'search');
	                            </script>
	                        <!--{else}-->
	                            <select name="searchoption[$optionid][value]" id="$option[identifier]" onchange="changeselectthreadsort(this.value, '$optionid', 'search');" class="zdss_srks zdss_xzks">
	                                <option value="0">{lang please_select}</option>
	                            <!--{loop $option['choices'] $id $value}-->
	                                <!--{if !$value[foptionid]}-->
	                                <option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
	                                <!--{/if}-->
	                            <!--{/loop}-->
	                            </select>
								<input type="hidden" name="searchoption[$optionid][type]" value="$option[type]">
	                        <!--{/if}-->
	                    <!--{elseif $option[type] != 'checkbox'}-->
	                        <select name="searchoption[$optionid][value]" id="$option[identifier]" class="zdss_srks zdss_xzks">
	                            <option value="0">{lang please_select}</option>
	                        <!--{loop $option['choices'] $id $value}-->
	                            <option value="$id" {if $_GET[searchoption][$optionid][value] == $id}selected="selected"{/if}>$value</option>
	                        <!--{/loop}-->
	                        </select>
	                        <input type="hidden" name="searchoption[$optionid][type]" value="$option[type]">
	                    <!--{else}-->
	                        <!--{loop $option['choices'] $id $value}-->
	                            <label><input type="checkbox" class="pc" name="searchoption[$optionid][value][$id]" value="$id" {if is_array($_GET[searchoption][$optionid]) && $_GET[searchoption][$optionid][value][$id]}checked="checked"{/if}>$value</label>
	                        <!--{/loop}-->
	                        <input type="hidden" name="searchoption[$optionid][type]" value="checkbox">
	                    <!--{/if}-->
	                    </span>
	                <!--{else}-->
	                    <!--{if $option['type'] == 'calendar'}-->
	                        <script type="text/javascript" src="{$_G[setting][jspath]}calendar.js?{VERHASH}"></script>
	                        <input type="text" name="searchoption[$optionid][value]" size="15" class="zdss_srks" value="{if is_array($_GET[searchoption][$optionid])}$_GET[searchoption][$optionid][value]{/if}" onclick="showcalendar(event, this, false)" />
	                    <!--{else}-->
	                        <input type="text" name="searchoption[$optionid][value]" size="15" class="zdss_srks" value="{if is_array($_GET[searchoption][$optionid])}$_GET[searchoption][$optionid][value]{/if}" />
	                    <!--{/if}-->
	                <!--{/if}-->
	            </div>
	            <!--{/block}-->
		<!--{/if}-->
    <!--{eval $formsearch_html .= $formsearch;}-->

	<!--{eval $fontsearch = '';$showoption = array();$tmpcount = 0;}-->
	<!--{if getstatus($option['search'], 2)}-->
    	<!--{block fontsearch}-->
			<tr>
				<th width="25%">$option[title]</th>
	            <td>
	                <ul class="cl">
	                    <li{if $_GET[''.$option[identifier]] == 'all'} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET['sortid']&searchsort=1$filterurladd&$option[identifier]=all$sorturladdarray[$option[identifier]]" class="xi2">{lang unlimited}</a></li>
						<!--{if $option[type] == 'select'}-->
							<!--{loop $option['choices'] $id $value}-->
								<!--{if $value[foptionid] == 0}-->
								<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]" class="xi2">$value[content]</a></li>
								<!--{/if}-->
							<!--{/loop}-->
							<!--{if !($_GET[''.$option[identifier]] == 'all' || !isset($_GET[''.$option[identifier]]))}-->
								<!--{loop $option['choices'] $id $value}-->
									<!--{if (preg_match('/^'.$value[foptionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[foptionid].'$/i', $_GET[''.$option[identifier]])) && ($showoption[$value[count]][$id] = $value)}-->
									<!--{/if}-->
								<!--{/loop}-->
								<!--{if ksort($showoption)}--><!--{/if}-->
								<!--{loop $showoption $optioncount $values}-->
									<!--{if $tmpcount != $optioncount && ($tmpcount = $optioncount)}-->
									</ul><ul class="subtsm cl">
										<!--{loop $values $id $value}-->
											<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]" class="xi2">$value[content]</a></li>
										<!--{/loop}-->
									</ul><ul>
									<!--{/if}-->
								<!--{/loop}-->
							<!--{/if}-->
						<!--{else}-->
							<!--{loop $option['choices'] $id $value}-->
								<li{if $_GET[''.$option[identifier]] && !strcmp($id, $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]" class="xi2">$value</a></li>
							<!--{/loop}-->
						<!--{/if}-->
	                </ul>
	            </td>
			</tr>
		<!--{/block}-->
     <!--{/if}-->
     <!--{eval $fontsearch_html .= $fontsearch;}-->
<!--{/loop}-->

<!--{if $formsearch_html || $fontsearch_html}-->
<div>
	<!--{if $fontsearch_html}-->
	    <div class="xlmmf-mlscs cl">
		    <table id="fontsearch" class="tsm cl">
		         $fontsearch_html
		    </table>
	    </div>
	<!--{/if}-->
	<!--{if $formsearch_html}-->
	    <form method="post" autocomplete="off" name="searhsort" id="searhsort" class="flsx_zdss" action="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]">
	        <input type="hidden" name="formhash" value="{FORMHASH}" />
	        $formsearch_html
	        <div class="zdss_qdys cl"><button type="submit" class="fm-scbt" name="searchsortsubmit">{lang search}</button></div>
	    </form>
	<!--{/if}-->
</div>
<!--{/if}-->
	 	    </div>
<div id="gradient"></div>
</div>
<div id="read-more" class="text-center"></div>


<script type="text/javascript">
$(function(){
 var slideHeight = 90; 
 var defHeight = $('.xlmmfhidden').height();
 if(defHeight >= slideHeight){  
  $('.xlmmfhidden').css('height' , slideHeight + 'px');
  $('#read-more').append('<a href="#">չ��ȫ��ɸѡ<em></em></a>');
  $('#read-more a').click(function(){
   var curHeight = $('.xlmmfhidden').height();
   if(curHeight == slideHeight){
   $('.xlmmfhidden').animate({
     height: defHeight
    }, "normal");
    $('#read-more a').html('����<i></i>');
    $('#gradient').fadeOut();
   }else{
    $('.xlmmfhidden').animate({
     height: slideHeight
    }, "normal");
    $('#read-more a').html('չ��ȫ��<em></em>');
    $('#gradient').fadeIn();
   }
   return false;
  });  
 }
});
</script>
	<!--������Ϣɸѡ����-->
	<!--{/if}-->
   $sorttemplate['body']
				$multipage
	 	<!--������Ϣ����-->
		<!--{/if}-->



    
	<!--{else}-->
 <link rel="stylesheet" type="text/css" href="template/xlmm_zx/m-img/forumdisplay.css"/>
    <div class="forumlist">
<div class="xlmm-fh-cover">
 <div class="xlmm-fh"> 
 <div class="cover mask-gray"></div>
 <div class="info"> <div class="logo-container"> <img class="logo" src="<!--{if $_G[forum][icon]}-->data/attachment/common/$_G['forum']['icon']<!--{else}-->template/xlmm_zx/m-img/icon.png<!--{/if}-->"> </div>
   <div class="logo-rank"> <span><!--{eval echo cutstr($_G['cache']['forums'][$_G['forum']['fup']]['name'], 10, '')}--></span> </div>
   <div class="name-info"> <div class="labels"> <span class="name">{$_G['forum']['name']}</span>  </div>
 <div class="info-num">  <label>���� </label><span>$_G[forum][threads]</span>  <label>���� </label><span>$_G[forum][posts]</span>   </div>
  <div class="bar-info-text">$_G['forum'][description]</div>
  </div>
 <div class="sign" id="signArea"> </div>
  <div class="op" id="opArea" style="display: block;">  <!--{eval $xlmmlk=DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$_G[fid]."");}-->{if $xlmmlk[id]}<a class="vote-btn btn" href="home.php?mod=space&do=favorite&type=forum"> ���ղ� </a>{else}<a class="vote-btn btn favbtn" href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}"> <i class="vote-btn-icon"></i> �ղ� </a> {/if}</div>
 </div>
 </div>
 </div>
<div id="uiTestNavWrap" class="ui-test-nav-wrap" style="display: block;">
<div id="uiTestNav" class="ui-test-nav nohighlight">
<div class="new-tab-list" style="width: 100%; transition: 0ms cubic-bezier(0.1, 0.57, 0.1, 1); -webkit-transition: 0ms cubic-bezier(0.1, 0.57, 0.1, 1); transform: translate(0px, 0px) translateZ(0px);">  
<div{if $filter==digest || $_GET[specialtype]==poll || $_GET[specialtype]==activity || $_GET[specialtype]==reward || $_GET[specialtype]==trade || $_GET[specialtype]==poll || $_GET[specialtype]==debate || $_GET[orderby]==heats ||  ! $_GET['forumlist'] != 1}{else}  style="background:#ededed"{/if}><a id="tab_all" href="forum.php?mod=forumdisplay&fid=$_G[fid]">ȫ��</a></div>
<div{if $filter==digest} style="background:#ededed"{/if}><a id="tab_best" href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1">����</a></div>
    <div{if $_GET['filter'] == 'heat'} style="background:#ededed"{/if}><a id="tab_qun" class="tab_qun" href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]">������</a></div>
         <div{if ! $_GET['forumlist'] != 1} style="background:#ededed"{/if}><a id="tab_album" href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumlist=1" class="">��ͼ</a></div>
    </div>
</div>
</div>

        <!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
	<!-- ������� start -->
      <style> 
.threadlist { background:#fff; margin-top:10px;}
.adtopic { padding:10px;background: #fff; margin-top:10px;}
.adtopic-list ul li {float: left;margin-right: 10px;margin-top:5px;font-size: 14px;}
.adtopic-list ul {}
.adtopic-list ul li a {display: inline-block;color: #222222;background-color: #f5f5f5; padding:5px 10px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;}
.adtopic-list ul li.a a {color: #d43d3d;}
.adtopic-list ul li span { color:red; margin-left:2px; display:none;}

		      </style> 
<div class="adtopic cl"> 
                  <div class="adtopic-list" >
            <ul>
                                    <li {if !$_GET['typeid'] && !$_GET['sortid']}class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">ȫ������</a></li>
           						<!--{if $_G['forum']['threadtypes']}-->
							<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
												<!--{if $_GET['typeid'] == $id}-->
				<li class="a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[typeid][$id]}--><span>($showthreadclasscount[typeid][$id])</span><!--{/if}--></a></li>
                								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[typeid][$id]}--><span>$showthreadclasscount[typeid][$id]</span><!--{/if}--></a></li>
						<!--{/if}-->
        							<!--{/loop}-->
						<!--{/if}-->
						<!--{if $_G['forum']['threadsorts']}-->
    							<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
														<!--{if $_GET['sortid'] == $id}-->
		<li class="a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[sortid][$id]}--><span>($showthreadclasscount[sortid][$id])</span><!--{/if}--></a></li>								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="circle">$name<!--{if $showthreadclasscount[sortid][$id]}--><span>$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
								<!--{/if}-->

							<!--{/loop}-->
						<!--{/if}-->
 </ul>
          </div>
                        </div>
 	<!-- ������� end -->
    <!--{/if}-->
			<!--{if $subexists && $_G['page'] == 1}--><!--{template forum/forumdisplay_subforum}--><!--{/if}-->

{if ! $_GET['forumlist'] != 1}
  <!--��ͼ-->
		<script src="template/xlmm_zx/m-img/xlmm-pbl.js" type="text/javascript"></script> 
  <div class="wf_wrap">
    <div id="waterfall" class="cl">
    <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
 				{eval include TPLDIR.'/php/forum_forumdisplay.php';}
       <!--{if $xlmmal >0 }-->            
     <div class="wf_item">
            <div class="wf_main">
                <div class="wf_pic">      <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
	   <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
<img src="$xlmmimg" width="150" />
</a> <!--{eval $xlmm++}-->
<!--{eval if($xlmm==1) break;}-->
<!--{/loop}-->
</div>
                <div class="wf_title"><a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight]>{$thread[subject]}</a></div>
            </div>
        </div>

        <!--{/if}-->
        <!--{/loop}-->
    <!--{/if}-->
   </div>
 </div>
  {if $multipage}<style>
/*��һҳ*/	
#ajnt {display: block;height: 40px;background: #f0f2f5 -webkit-gradient(linear,0 0,0 100%,from(#f5f7fa),to(#f0f2f5));box-shadow: 0 1px 1px rgba(0,0,0,.1);border-radius: 5px;border: 1px solid #e1e3e5;line-height: 40px;text-align: center;font-size: 16px;color: #323233;margin: 10px 35px;}
</style>
<div id="ajnt"><!--{if $_G['page'] > 1}-->
  <!--{eval $nxtpage = $page - 1;}-->
<a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}&page=$nxtpage&forumlist=1" hidefocus="true" style="margin-left:18px; margin-right:10px">��һҳ</a><!--{/if}--><a href="forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}&page=$nextpage&forumlist=1" hidefocus="true">��һҳ</a>
</div>
{/if}
<script type="text/javascript">
jQuery(function(){
var jQuerycontainer = jQuery('#waterfall');
jQuerycontainer.imagesLoaded(function(){
jQuerycontainer.masonry({
itemSelector: '.wf_item',
columnWidth: 150,
gutterWidth: 16,
isAnimated: '!Modernizr.csstransitions',
cornerStampSelector: '.category',
isFitWidth: true
});
});
});
</script> 
  
  {else}
	<!--{if empty($_G['forum']['sortmode'])}-->
  
<!--{if !$subforumonly}-->
<div class="top">  
<div class="top-list-wrap">   
	<!--{if $livethread}-->
<div class="top-list"><div class="top-list-item"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="link "><label class="rec">ֱ��</label> <label class="rec">�ظ�$livethread[replies]</label>  <span class="name">{$thread[subject]}</span>  </a> </div></div>
	<!--{/if}-->
 <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
            <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
                {eval continue;}
            <!--{/if}-->
            <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                {eval $displayorder_thread = 1;}
            <!--{/if}-->
            <!--{if $thread['moved']}-->
                <!--{eval $thread[tid]=$thread[closed];}-->
            <!--{/if}-->
		<div class="top-list"><div class="top-list-item"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="link "><!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}--><label class="rec">��</label> <!--{/if}--><!--{if $thread['digest'] > 0}--><label class="rec">��</label> <!--{/if}--><!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
 <label class="rec">ͼ</label> <!--{/if}--><span class="name">{$thread[subject]}</span>  </a> </div></div>
         <!--{/if}--> 
        <!--{/loop}-->
    <!--{/if}-->
 
   </div>
</div>
<!--{/if}-->
<!--{if !$subforumonly}-->
{eval $page=$_G['page'];}
<ul id="alist">   
	<div class="item list" style="margin-top:10px">   
   <!--{if $_G['forum_threadcount']}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
		    <!--{if $thread['moved']}--><!--{eval $thread[tid]=$thread[closed];}--><!--{/if}-->
				{eval include TPLDIR.'/php/forum_forumdisplay.php';}
  <!--{hook/forumdisplay_thread_mobile $key}-->  
<li class="ui-ignore-space section-1px new-feed"> 
<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"> <div class="user-wrap">
 <div class="user-avatar"> {avatar($thread[authorid],small)} </div>
 <div class="name-wrap"> <div class="name-section1"> <span class="author nick "> $thread[author] </span><span class="xlmmlvf" style="font-size: 10px;height: 14px;line-height: 14px;-moz-border-radius: 10px;margin-top: 0;-webkit-border-radius: 10px;border-radius: 10px;padding: 0 8px;margin-left: 3px; color:#FFFFFF;background: #FC4527;">LV.$xlmmdj</span></div>
 <span class="post-datetime">������:$thread[dateline]</span> </div>
 <div class="read-icon-v3"> <i class="read-icon"></i> <div class="readnum">$thread[views]</div>
 </div>
 </div>
  <div class="go-detail"> <div class="report-content"> <p class="grouptitle feed-two-line">
  <!--{if $thread[folder] == 'lock'}-->
  <label class="best">����</label>  <!--{elseif $thread['special'] == 1}-->
  <label class="best">ͶƱ</label>  <!--{elseif $thread['special'] == 2}-->
  <label class="best">��Ʒ</label>  <!--{elseif $thread['special'] == 3}-->
  <label class="best">��</label>    <!--{elseif $thread['special'] == 4}-->
  <label class="best">�</label>  <!--{elseif $thread['special'] == 5}-->
  <label class="best">����</label>  <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
  <label class="best">��</label>   	<!--{elseif $thread['digest'] > 0}-->
  <label class="best">��</label>   <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}--><!--{/if}-->{$thread[subject]}</p> {if $xiaolu['fmessage']}{if $_G['cache']['plugin']['xlmm_tt']['xlmmlby'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmlby'] == 2}
<p class="groupbrief feed-two-line">$xiaolu['fmessage']</p> {/if}  	{/if}
</div>
   <div class="xlmmimg style3 clearfix">  
{if $_G['cache']['plugin']['xlmm_tt']['xlmmlby'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmlby'] == 3}
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
	{if $xlmmal ==1}
	   <div class="img_wrapper" style="padding-top:0;"> <img src="$xlmmimg" style="position:relative;">   </div>
		{elseif $xlmmal ==2}
				<!--{if $xlmm == '0'}-->
	   <div class="img_wrapper"> <img src="$xlmmimg">   </div>
					<!--{elseif $xlmm == '1'}-->
	   <div class="img_wrapper"> <img src="$xlmmimg">   </div>
		      <!--{/if}-->
{else}
			<!--{if $xlmm == '0'}-->
	   <div class="img_wrapper"> <img src="$xlmmimg">   </div>
					<!--{elseif $xlmm == '1'}-->
	   <div class="img_wrapper"> <img src="$xlmmimg">   </div>
					<!--{elseif $xlmm == '2'}-->
	   <div class="img_wrapper"> <img src="$xlmmimg">{if $xlmmal >=3}<span class="total-img"><span class="total-img-text">{eval echo $xlmmal}</span></span>{/if}   
</div>
  	{/if}
      <!--{/if}-->
   <!--{eval $xlmm++}-->
<!--{eval if($xlmm==3) break;}-->
<!--{/loop}-->
	{/if}
</div>
 </a>  
  <div class="clearfix post-bottom-v3"> <div class="reply-btn-v3 post-btn-v3 clearfix">$thread[replies]</div>
<a href="forum.php?mod=misc&action=recommend&do=add&tid=$thread[tid]&hash={FORMHASH}" class="like-btn-v3 post-btn-v3 clearfix recbtn" style="display:block">$thread[recommend_add]</a>
<a href="forum.php?mod=viewthread&tid=$thread[tid]&mobile=2#fpost" style="display:block" class="more-btn-v3 post-btn-v3 clearfix"></a>
 </div>
 </div>
</li>    
        <!--{/if}-->
        <!--{/loop}-->
</div>
</ul>
	{if $_G['forum_threadcount'] > $_G['tpp']}
$multipage {/if}    

   <!--{else}-->
		<li class="mforum_no">{lang forum_nothreads}</li>
	<!--{/if}-->
{/if}
 				<!--{else}-->
	<!--������Ϣ��ʼ-->
	<!--{if $quicksearchlist && !$_GET['archiveid']}-->
	 	<!--������Ϣɸѡ-->
      <style> 

.xlmmfhidden{position: relative;overflow: hidden;background: #fff; margin:10px 0 0 0;}
#gradient{width: 100%;height:40px;position: absolute;bottom: 0;left: 0;background: -moz-linear-gradient(bottom,rgba(255,255,255,.1),rgba(255,255,255,0));background: -webkit-gradient(linear,0 top,0 bottom,from(rgba(255,255,255,0)),to(#fff));background: -o-linear-gradient(bottom,rgba(255,255,255,.1),rgba(255,255,255,0));}
#read-more a{text-decoration: none; display:block; width:100%;background: #fff;color: {$_G['cache']['plugin']['xlmm_tt']['xlmmcol']}!important; margin-bottom:10px; padding-top:10px; padding-bottom:10px; }
#read-more a i{ }
#read-more a em{}
.text-center{text-align:center;}
.xlmmf-mlsc {}
.xlmmf-mlsc .xlmmf-mlscs {margin-bottom:10px;}
.xlmmf-mlsc .xlmmf-mlscs .tsm {width: 100%}
.xlmmf-mlsc .xlmmf-mlscs th {padding: 10px;background: #fff;border-bottom: 1px solid #f5f5f5;font-size: 14px;color: #666;text-align: center;}
.xlmmf-mlsc .xlmmf-mlscs td {padding: 10px;border: 1px solid #f5f5f5;}
.xlmmf-mlsc .xlmmf-mlscs td li {float: left;height: 28px;line-height: 30px;padding: 0 8px;text-align: center;}
.xlmmf-mlsc .xlmmf-mlscs td li a {font-size: 14px;color: #333;}
.xlmmf-mlsc .xlmmf-mlscs td li.a {border-radius: 2px;background: {$_G['cache']['plugin']['xlmm_tt']['xlmmcol']}!important;}
.xlmmf-mlsc .xlmmf-mlscs td li.a a {color: #fff;}
.xlmmf-mlsc .xlmmf-mlscs .subtsm {margin-top:10px;padding:10px;background: #f9f9f9;border: 1px solid #f4f4f4;border-radius: 2px;}
.xlmmf-mlsc .xlmmf-mlscs .subtsm li {height: 24px;line-height: 25px;padding: 0 6px;}
.xlmmf-mlsc .xlmmf-mlscs .subtsm li a {font-size: 13px;color: #666;}
.xlmmf-mlsc .flsx_zdss {width: 100%;}
.xlmmf-mlsc .flsx_zdss .zdss_ssli {height: 45px;}
.xlmmf-mlsc .flsx_zdss .zdss_ssli i {float: left;width:25%;line-height: 35px;font-size: 14px;color: #333;text-align: center;display: block;}
.xlmmf-mlsc .flsx_zdss .zdss_ssli .zdss_srks {line-height: 30px;border: 1px solid #E2E2E2;background: #F8F8F8;font-size: 14px;padding: 3px 5px;border-radius: 4px;}
.xlmmf-mlsc .flsx_zdss .zdss_qdys {margin:8px 10px 15px 10px;}
.xlmmf-mlsc .flsx_zdss .zdss_qdys .fm-scbt {width: 100%;height: 45px;line-height: 47px;border-radius: 5px;background: {$_G['cache']['plugin']['xlmm_tt']['xlmmcol']}!important;font-size: 14px;color: #fff;border: 0;display: block;text-align: center;}

</style>
    
<div class="xlmmfhidden">
	<div class="xlmmf-mlsc cl">
<script type="text/javascript">
	var forum_optionlist = <!--{if $forum_optionlist}-->'$forum_optionlist'<!--{else}-->''<!--{/if}-->;
</script>
<script type="text/javascript" src="{$_G['setting']['jspath']}threadsort.js?{VERHASH}"></script>

<!--{loop $quicksearchlist $optionid $option}-->
		<!--{eval $formsearch = '';}-->
        <!--{if getstatus($option['search'], 1)}-->
        	<!--{block formsearch}-->
	            <div class="zdss_ssli cl">
	                <i>$option[title]</i>
	                <!--{if in_array($option['type'], array('radio', 'checkbox', 'select', 'range'))}-->
	                    <span id="select_$option[identifier]">
	                    <!--{if $option[type] == 'select'}-->
	                        <!--{if $_GET[searchoption][$optionid][value]}-->
	                            <script type="text/javascript">
	                                changeselectthreadsort('$_GET[searchoption][$optionid][value]', $optionid, 'search');
	                            </script>
	                        <!--{else}-->
	                            <select name="searchoption[$optionid][value]" id="$option[identifier]" onchange="changeselectthreadsort(this.value, '$optionid', 'search');" class="zdss_srks zdss_xzks">
	                                <option value="0">{lang please_select}</option>
	                            <!--{loop $option['choices'] $id $value}-->
	                                <!--{if !$value[foptionid]}-->
	                                <option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
	                                <!--{/if}-->
	                            <!--{/loop}-->
	                            </select>
								<input type="hidden" name="searchoption[$optionid][type]" value="$option[type]">
	                        <!--{/if}-->
	                    <!--{elseif $option[type] != 'checkbox'}-->
	                        <select name="searchoption[$optionid][value]" id="$option[identifier]" class="zdss_srks zdss_xzks">
	                            <option value="0">{lang please_select}</option>
	                        <!--{loop $option['choices'] $id $value}-->
	                            <option value="$id" {if $_GET[searchoption][$optionid][value] == $id}selected="selected"{/if}>$value</option>
	                        <!--{/loop}-->
	                        </select>
	                        <input type="hidden" name="searchoption[$optionid][type]" value="$option[type]">
	                    <!--{else}-->
	                        <!--{loop $option['choices'] $id $value}-->
	                            <label><input type="checkbox" class="pc" name="searchoption[$optionid][value][$id]" value="$id" {if is_array($_GET[searchoption][$optionid]) && $_GET[searchoption][$optionid][value][$id]}checked="checked"{/if}>$value</label>
	                        <!--{/loop}-->
	                        <input type="hidden" name="searchoption[$optionid][type]" value="checkbox">
	                    <!--{/if}-->
	                    </span>
	                <!--{else}-->
	                    <!--{if $option['type'] == 'calendar'}-->
	                        <script type="text/javascript" src="{$_G[setting][jspath]}calendar.js?{VERHASH}"></script>
	                        <input type="text" name="searchoption[$optionid][value]" size="15" class="zdss_srks" value="{if is_array($_GET[searchoption][$optionid])}$_GET[searchoption][$optionid][value]{/if}" onclick="showcalendar(event, this, false)" />
	                    <!--{else}-->
	                        <input type="text" name="searchoption[$optionid][value]" size="15" class="zdss_srks" value="{if is_array($_GET[searchoption][$optionid])}$_GET[searchoption][$optionid][value]{/if}" />
	                    <!--{/if}-->
	                <!--{/if}-->
	            </div>
	            <!--{/block}-->
		<!--{/if}-->
    <!--{eval $formsearch_html .= $formsearch;}-->

	<!--{eval $fontsearch = '';$showoption = array();$tmpcount = 0;}-->
	<!--{if getstatus($option['search'], 2)}-->
    	<!--{block fontsearch}-->
			<tr>
				<th width="25%">$option[title]</th>
	            <td>
	                <ul class="cl">
	                    <li{if $_GET[''.$option[identifier]] == 'all'} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET['sortid']&searchsort=1$filterurladd&$option[identifier]=all$sorturladdarray[$option[identifier]]" class="xi2">{lang unlimited}</a></li>
						<!--{if $option[type] == 'select'}-->
							<!--{loop $option['choices'] $id $value}-->
								<!--{if $value[foptionid] == 0}-->
								<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]" class="xi2">$value[content]</a></li>
								<!--{/if}-->
							<!--{/loop}-->
							<!--{if !($_GET[''.$option[identifier]] == 'all' || !isset($_GET[''.$option[identifier]]))}-->
								<!--{loop $option['choices'] $id $value}-->
									<!--{if (preg_match('/^'.$value[foptionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[foptionid].'$/i', $_GET[''.$option[identifier]])) && ($showoption[$value[count]][$id] = $value)}-->
									<!--{/if}-->
								<!--{/loop}-->
								<!--{if ksort($showoption)}--><!--{/if}-->
								<!--{loop $showoption $optioncount $values}-->
									<!--{if $tmpcount != $optioncount && ($tmpcount = $optioncount)}-->
									</ul><ul class="subtsm cl">
										<!--{loop $values $id $value}-->
											<li{if preg_match('/^'.$value[optionid].'\./i', $_GET[''.$option[identifier]]) || preg_match('/^'.$value[optionid].'$/i', $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]" class="xi2">$value[content]</a></li>
										<!--{/loop}-->
									</ul><ul>
									<!--{/if}-->
								<!--{/loop}-->
							<!--{/if}-->
						<!--{else}-->
							<!--{loop $option['choices'] $id $value}-->
								<li{if $_GET[''.$option[identifier]] && !strcmp($id, $_GET[''.$option[identifier]])} class="a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]&searchsort=1&$option[identifier]=$id$sorturladdarray[$option[identifier]]" class="xi2">$value</a></li>
							<!--{/loop}-->
						<!--{/if}-->
	                </ul>
	            </td>
			</tr>
		<!--{/block}-->
     <!--{/if}-->
     <!--{eval $fontsearch_html .= $fontsearch;}-->
<!--{/loop}-->

<!--{if $formsearch_html || $fontsearch_html}-->
<div>
	<!--{if $fontsearch_html}-->
	    <div class="xlmmf-mlscs cl">
		    <table id="fontsearch" class="tsm cl">
		         $fontsearch_html
		    </table>
	    </div>
	<!--{/if}-->
	<!--{if $formsearch_html}-->
	    <form method="post" autocomplete="off" name="searhsort" id="searhsort" class="flsx_zdss" action="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_GET[sortid]">
	        <input type="hidden" name="formhash" value="{FORMHASH}" />
	        $formsearch_html
	        <div class="zdss_qdys cl"><button type="submit" class="fm-scbt" name="searchsortsubmit">{lang search}</button></div>
	    </form>
	<!--{/if}-->
</div>
<!--{/if}-->
	 	    </div>
<div id="gradient"></div>
</div>
<div id="read-more" class="text-center"></div>


<script type="text/javascript">
$(function(){
 var slideHeight = 90; 
 var defHeight = $('.xlmmfhidden').height();
 if(defHeight >= slideHeight){  
  $('.xlmmfhidden').css('height' , slideHeight + 'px');
  $('#read-more').append('<a href="#">չ��ȫ��ɸѡ<em></em></a>');
  $('#read-more a').click(function(){
   var curHeight = $('.xlmmfhidden').height();
   if(curHeight == slideHeight){
   $('.xlmmfhidden').animate({
     height: defHeight
    }, "normal");
    $('#read-more a').html('����<i></i>');
    $('#gradient').fadeOut();
   }else{
    $('.xlmmfhidden').animate({
     height: slideHeight
    }, "normal");
    $('#read-more a').html('չ��ȫ��<em></em>');
    $('#gradient').fadeIn();
   }
   return false;
  });  
 }
});
</script>
	<!--������Ϣɸѡ����-->
	<!--{/if}-->
   $sorttemplate['body']
				$multipage
	 	<!--������Ϣ����-->
		<!--{/if}-->

	<!--{/if}-->

<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]"><div class="publish-btn"></div></a>
<!--{hook/forumdisplay_bottom_mobile}-->
<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>
<script type="text/javascript">
	$('.recbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=recbtn&inajax=1',
			data:{'recommendsubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
</script>
	<!--{/if}-->
<!--{template common/footer}-->



