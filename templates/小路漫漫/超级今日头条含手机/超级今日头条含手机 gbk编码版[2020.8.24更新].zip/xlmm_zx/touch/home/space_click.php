<?php exit;?>
<style>

.zanBox { text-align:center; margin-top:28px; margin-bottom:25px;}
.zanBox .num,  .zanBox .zan {
    width: 76px;
    height: 76px;
    line-height: 78px;
    text-align: center;
    font-size: 24px;
    background-color: #ff8070;
    border-radius: 50%;
    color: #fff;
display: inline-block;border: 2px solid #fcd5d0;
}
.zanp {
    text-align: center;
    font-size: 20px;
    color: #2b3032;
    line-height: 20px; margin-bottom:38px;
}
.zanp em {
    color: #ff8070;
}

.reveal-modal-bg{position:fixed;height:100%;width:100%;background:#000;background:rgba(0,0,0,.8);z-index:100;display:none;top:0;left:0}
.reveal-modal{ display:none;visibility:hidden;top:200px !important;left:50%;margin-left:-170px;width:300px;background:#eee ;position: fixed;z-index:101;padding:30px 20px 20px;-moz-border-radius:5px;-webkit-border-radius:5px;border-radius:5px;-moz-box-shadow:0 0 10px rgba(0,0,0,.4);-webkit-box-shadow:0 0 10px rgba(0,0,0,.4);-box-shadow:0 0 10px rgba(0,0,0,.4)}
.reveal-modal.small{width:200px;margin-left:-140px}
.reveal-modal.medium{width:400px;margin-left:-240px}
.reveal-modal.large{width:600px;margin-left:-340px}
.reveal-modal.xlarge{width:800px;margin-left:-440px}
.reveal-modal .xlmm-tcccl.close-reveal-modal{font-size:22px;line-height:.5;position:absolute;top:8px;right:11px;color:red;text-shadow:0 -1px 1px rbga(0,0,0,.6);font-weight:700;cursor:pointer}
.enjoyhint_next_btn {
    box-sizing: content-box;
    width: 100px;
    height: 28px; line-height:28px;
    cursor: pointer;
    margin: 0 auto;
    border: 2px solid #ff8070;
    color: #ff8070;
    text-align: center;
}
</style>
<div id="xlmm-tcc" class="reveal-modal">
<table cellpadding="0" cellspacing="0" class="atd">
	<tr>
	<!--{eval $clicknum = 0;}-->
	<!--{loop $clicks $key $value}-->
	<!--{eval $clicknum = $clicknum + $value['clicknum'];}-->
	<!--{eval $value['height'] = $maxclicknum?intval($value['clicknum']*50/$maxclicknum):0;}-->
		<td>
			<a href="home.php?mod=spacecp&ac=click&op=add&clickid=$key&idtype=$idtype&id=$id&hash=$hash&handlekey=clickhandle" id="click_{$idtype}_{$id}_{$key}" class="{if $_G['uid']}dialog{else}{/if}" onclick="{if $_G[uid]}ajaxmenu(this);{else}showWindow(this.id, this.href);{/if}doane(event);">
				<!--{if $value[clicknum]}-->
				<div class="atdc">
					<div class="ac{$value[classid]}" style="height:{$value[height]}px;"></div>
				</div>
				<!--{/if}-->
				<img src="{STATICURL}image/click/$value[icon]" alt="" /><br />$value[name]
			</a>
		</td>
	<!--{/loop}-->
	</tr>
</table>
<div class="enjoyhint_next_btn close-reveal-modal">�ر�</div><a class="xlmm-tcccl close-reveal-modal">&#215;</a>
</div>
<div class="zanBox">
        <a href="javascript:void(0);"  data-reveal-id="xlmm-tcc" data-animation="none" class="zan" >����</a></div>
	<p class="zanp"><em class="reword_num">$clicknum</em>���Ѵ���</p>	
<script type="text/javascript">
	function errorhandle_clickhandle(message, values) {
		if(values['id']) {
			showCreditPrompt();
			show_click(values['idtype'], values['id'], values['clickid']);
		}
	}
(function($){$('a[data-reveal-id]').live('click',function(e){e.preventDefault();var modalLocation=$(this).attr('data-reveal-id');$('#'+modalLocation).reveal($(this).data());});$.fn.reveal=function(options){var defaults={animation:'fadeAndPop',animationspeed:300,closeonbackgroundclick:true,dismissmodalclass:'close-reveal-modal'};var options=$.extend({},defaults,options);return this.each(function(){var modal=$(this),topMeasure=parseInt(modal.css('top')),topOffset=modal.height()+topMeasure,locked=false,modalBG=$('.reveal-modal-bg');if(modalBG.length==0){modalBG=$('<div class="reveal-modal-bg" />').insertAfter(modal);}
modal.bind('reveal:open',function(){modalBG.unbind('click.modalEvent');$('.'+options.dismissmodalclass).unbind('click.modalEvent');if(!locked){lockModal();if(options.animation=="fadeAndPop"){modal.css({'top':$(document).scrollTop()-topOffset,'opacity':0,'visibility':'visible'});modalBG.fadeIn(options.animationspeed/2);modal.delay(options.animationspeed/2).animate({"top":$(document).scrollTop()+topMeasure+'px',"opacity":1},options.animationspeed,unlockModal());}
if(options.animation=="fade"){modal.css({'opacity':0,'visibility':'visible','top':$(document).scrollTop()+topMeasure});modalBG.fadeIn(options.animationspeed/2);modal.delay(options.animationspeed/2).animate({"opacity":1},options.animationspeed,unlockModal());}
if(options.animation=="none"){modal.css({'display':'block','visibility':'visible','top':$(document).scrollTop()+topMeasure});modalBG.css({"display":"block"});unlockModal()}}
modal.unbind('reveal:open');});modal.bind('reveal:close',function(){if(!locked){lockModal();if(options.animation=="fadeAndPop"){modalBG.delay(options.animationspeed).fadeOut(options.animationspeed);modal.animate({"top":$(document).scrollTop()-topOffset+'px',"opacity":0},options.animationspeed/2,function(){modal.css({'top':topMeasure,'opacity':1,'visibility':'hidden'});unlockModal();});}
if(options.animation=="fade"){modalBG.delay(options.animationspeed).fadeOut(options.animationspeed);modal.animate({"opacity":0},options.animationspeed,function(){modal.css({'opacity':1,'visibility':'hidden','top':topMeasure});unlockModal();});}
if(options.animation=="none"){modal.css({'display':'none','visibility':'hidden','top':topMeasure});modalBG.css({'display':'none'});}}
modal.unbind('reveal:close');});modal.trigger('reveal:open')
var closeButton=$('.'+options.dismissmodalclass).bind('click.modalEvent',function(){modal.trigger('reveal:close')});if(options.closeonbackgroundclick){modalBG.css({"cursor":"pointer"})
modalBG.bind('click.modalEvent',function(){modal.trigger('reveal:close')});}
$('body').keyup(function(e){if(e.which===27){modal.trigger('reveal:close');}});function unlockModal(){locked=false;}
function lockModal(){locked=true;}});}})(jQuery);
</script>
<!--{if $click_multi}--><div class="pgs cl mtm">$click_multi</div><!--{/if}-->



