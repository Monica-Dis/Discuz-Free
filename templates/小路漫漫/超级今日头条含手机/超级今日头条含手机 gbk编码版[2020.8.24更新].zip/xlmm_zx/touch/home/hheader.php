<?PHP exit('Access Deniedxiaoluanman');?>
<style>


.header {position: relative;height: 200px;background-color: #3c3c3c;background-size: cover;background-repeat: no-repeat;background-position: center top; display:block;color: #fff;}
.header .user{position:relative;padding:70px 16px 20px 20px;display:-webkit-box;display:-webkit-flex;display:flex}
.header .user .u-img{width:66px;height:66px;margin-right:15px;overflow:hidden;border-radius:50%}
.header .user .u-img img{width:100%;height:100%;background:#e8e8e8;border-radius:50%}
.header .user .u-img{position:relative}
.header .user .u-img::after{pointer-events:none;position:absolute;top:0;left:0;overflow:hidden;content:"\0020";box-sizing:border-box;border-color:#fff;border-style:solid;border-width:1px;-webkit-transform-origin:left top;transform-origin:left top}

.header .user .u-info .u-title{white-space:nowrap;overflow:hidden}
.header .user .u-info .u-title .u-name{display:inline-block;max-width:200px;text-overflow:ellipsis;white-space:nowrap;overflow:hidden;font-size:18px;color:#fff;line-height:1.4;vertical-align:middle}
@media only screen and (min-device-width:320px) and (max-device-width:359px){.header .user .u-info .u-title .u-name{max-width:144px}
}
@media only screen and (min-device-width:360px) and (max-device-width:374px){.header .user .u-info .u-title .u-name{max-width:184px}
}
.header .user .u-info .u-follow{margin-top:12px;display:-webkit-box;display:-webkit-flex;display:flex}
.header .user .u-info .u-follow .u-finfo{min-width:40px}
.header .user .u-info .u-follow .u-finfo:first-child{margin-right:12px}
.header .user .u-info .u-follow .u-finfo:first-child .text-num{margin-left:1px}
.header .user .u-info .u-follow .u-finfo .text-num{font-size:12px;line-height:1}
.header .user .u-info .u-follow .u-finfo .text-type{margin-top:4px;font-size:12px;line-height:1}
.header .user .u-btns{position:absolute;bottom:20px;right:16px}
.header .user .u-btns #xlmmfllow{display:inline-block;width:57px;padding:0;margin:0;margin-right:4px;color:#fff;font-size:14px;line-height:28px;border-radius:6px;background:0 0;border:0;vertical-align:middle; text-align:center; border:1px solid #fff;;}
.xlmm_rec_alert { padding: 10px 16px;color: #fff; background: rgba(0,0,0,0.65);border-radius: 3px; font-size: 14px;font-weight: 100;}



.nav_bar { height: 45px; background: #fff;box-shadow: 0 5px 5px #e5e5e5;}
.nav_bar .inside {width: 220px; height: 45px;  line-height: 45px;margin: 0 auto;}
.nav_bar .inside li { width: 50px;float: left;height: 45px; margin: 0 10px;font-size: 15px;color: #999;text-align: center;}
.nav_bar .inside li.cur { border-bottom: 1px solid #d43d3d;}
.nav_bar .inside li.cur a { color: #d43d3d;}

body, #mcontent { background:#fff;}
.xlmm-bj .mv_post_nav { background:none; margin:10px 0 0 0;} 
.xlmm-bj .mv_post_nav a { padding:0 5px;}
.xlmm-bj_h { position: relative; }
.xlmm-bj_h .s1 { display:block; padding:0px; margin:0px; overflow:hidden; background:#FFF;height:130px; overflow:hidden;}
.xlmm-bj_h .s1 img { display:block; background:#000; filter: url(blur.svg#blur); /* FireFox, Chrome, Opera */ -webkit-filter: blur(15px); /* Chrome, Opera */ -moz-filter: blur(15px);-ms-filter: blur(15px);filter: blur(15px);filter: progid:DXImageTransform.Microsoft.Blur(PixelRadius=15, MakeShadow=false); /* IE6~IE9 */ width:100%}
.xlmm-bj_h .s2 { display:block; height:40px; background:#FFF; border-bottom:1px solid #F8F8F8; box-shadow: 0 3px 5px rgba(0, 0, 0, 0.2)}
.xlmm-bj_h .s3 { position:absolute; left:10px; bottom:10px;}
.xlmm-bj_h .s3  img { width:80px; height:80px; border-radius:40px; padding:2px; background:#FFF; box-shadow: 0 2px 2px rgba(0, 0, 0, 0)}
.xlmm-bj_h .s4 { position:absolute; left:110px; bottom:60px; color:#FFF; font-size:16px; text-shadow:0 3px 3px #000;}
.xlmm-bj_h .s5 { position: absolute; left:110px; bottom:9px; width:72px; height:30px; line-height:30px; font-size:14px;}
    .xlmm-bj_h .s5 a { color:#4E627C;}
.xlmm-zl { margin:10px 0 0 0; padding:0 15px !important;}
.xlmm-zl li { padding: 3px 30px 3px 90px; }
	.xlmm-zl li em { position: absolute; margin-left: -90px; width: 80px; color: #999; }
.mbutton {width: 50px; height: 32px;line-height: 32px; border: 0;text-align: center;color: #FFF; background: #2AA2E2}
</style>
<div class="header" style="background-image: url(template/xlmm_zx/m-img/home.jpg);">

<div class="user">
        
        <div class="u-img"><img  src="{avatar($space[uid], middle, true)}" style="width: 66px; height: 66px; margin-left: 0px; margin-top: 0px;"></div><div class="u-info"><div class="u-title"><span class="u-name">$space[username]</span>
            </div>
         		    	<!--{eval  $xlmmuidfav=DB::result_first("select followuid from ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$space[uid]");
                  $xlmmuidfavs=DB::fetch_all("select fusername from ".DB::table("home_follow")." WHERE`followuid`=$space[uid]");$xlmmfsall = count($xlmmuidfavs);
}-->
   <div class="u-follow">
            <div class="u-finfo" ><p class="text-num" id="membernumgz">$xlmmfsall</p><p class="text-type" >��˿</p></div>
            <div class="u-finfo"><p class="text-num">$space[credits]</p><p class="text-type">{lang credits}</p></div>
            </div>
            </div>
            
            <div class="u-btns">
               <!--{if !$xlmmuidfav}-->
					<a id="xlmmfllow" class="gz_$space[uid] {if $_G['uid']}{else}dialog{/if} hbtn-b" onclick="xlmmfollows('xlmmfllow','gz_$space[uid]','$space[uid]')"{if $_G['uid']}  href="javascript:;"{else}href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"{/if}>  <span class="favor-btn xlmmjgz">��ע</span></a>
				<!--{else}-->
					<a id="xlmmfllow" class="gz_$space[uid] hbtn-b" onclick="xlmmfollows('xlmmfllow','gz_$space[uid]','$space[uid]')" href="javascript:;">  <span class="favor-btn">ȡ��</span></a>
				<!--{/if}-->     
               </div>
                         </div>
                  


</div>
<div class="nav_bar cl">
    <ul class="inside cl">
        <li<!--{if $_GET['grzl'] || $_GET['wz']}--><!--{else}-->  class="cur"<!--{/if}-->>
            <a href="home.php?mod=space&uid=$space[uid]&do=profile">����</a>
        </li>
        <li<!--{if $_GET['wz']}--> class="cur"<!--{/if}-->>
            <a href="home.php?mod=space&uid=$space[uid]&do=profile&wz=$space[uid]">����</a>
        </li>
        <li<!--{if $_GET['grzl']}--> class="cur"<!--{/if}-->>
            <a href="home.php?mod=space&uid=$space[uid]&do=profile&grzl=$space[uid]">����</a>
        </li>
    </ul>
</div>


</div>
</div>


{if $_G['uid']} 
<script type="text/javascript">
        function xlmmfollows(val,clsa,aid){
            popup.close();
if(document.getElementById(val).innerHTML.indexOf("xlmmjgz") >= 0){
var xlmmhref = 'home.php?mod=spacecp&ac=follow&op=add&fuid='+aid+'&hash={FORMHASH}';
}else{
var xlmmhref = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+aid;
}
            popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
            $.ajax({
                type:'GET',
                url:xlmmhref + '&inajax=1',
                dataType:'xml',
            })
            .success(function(s) {	
                if(s.lastChild.firstChild.nodeValue.indexOf("���ܹ�ע�Լ�") >= 0){
popup.open('<div class="xlmm_rec_alert">���ܹ�ע�Լ�Ŷ</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("�ɹ�����") >= 0){
$("."+clsa).html('<em class="favor-btn">ȡ��</em>');
var numObj = $('#membernumgz');
var memberNum = parseInt(numObj.html());
numObj.html(memberNum+1);
popup.open('<div class="xlmm_rec_alert">��ע�ɹ�</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("ȡ���ɹ�") >= 0){
$("."+clsa).html('<em class="favor-btn xlmmjgz">��ע</em>');
var numObj = $('#membernumgz');
var memberNum = parseInt(numObj.html());
numObj.html(memberNum-1);
popup.open('<div class="xlmm_rec_alert">��ȡ����ע</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("���Ѿ�������") >= 0){
			popup.open('<div class="xlmm_rec_alert">���Ѿ���ע����</div>');
}

         var xlmmclose = setTimeout(popup.close,1500);
       })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        };

    </script>
{/if} 





