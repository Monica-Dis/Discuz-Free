<?PHP exit('Access Deniedxiaoluanman');?>
<!--{template common/header}-->
<style>
.bg {background:#fff !important;}
.sf-header {border:0;}
.loginbox {padding: 10px 10%;padding-top:25px;padding-bottom:138px;}
.login_pop {padding: 0 14px 20px !important;}
.login_xlmm li {height: 44px;margin: 0 0 10px;padding: 0 15px;position: relative;overflow: hidden;background:#fff;}
.sec_code {margin: 0 0 10px;padding: 0 15px;position: relative;background:#fff;}
.sec_code:after, .login_xlmm li:after {height: 87px;border: 1px solid #e9e9e9;top: 0;border-radius: 44px;pointer-events: none;width: 199.9%;}
.sec_code:after, .login_xlmm li:after {content: '';position: absolute;left: 0;-ms-transform-origin: 0 0;transform-origin: 0 0;-ms-transform: scale(.5);transform: scale(.5);-wekbit-box-sizing: border-box;box-sizing: border-box;}
.login_xlmm .p_fre {border: 0;width:100% !important;padding: 11px 0;line-height: 17px;font-size: 15px;box-shadow: 0 0 0 1000px #fff inset;}
.sec_code .px {border: 0;padding: 11px 0;line-height: 17px;font-size: 15px;box-shadow: 0 0 0 1000px #fff inset;}
.px:focus {outline: -webkit-focus-ring-color auto 0px;}
.login-btn-text {margin-top:11px}

.btn_login .pn, .btn_register .pn {display: inline-block;width: 100%;border-radius: 44px;line-height: 100%;background: #d43d3d ;text-align: center;font-size: 15px;color: #fff;}
.btn_zhdl a {display: block;width: 100%;height: 44px;line-height: 44px;position: relative;overflow: hidden;text-align: center;font-size: 15px!important;color: #d43d3d;}
.btn_zhdl a:after {content: '';width: 199.9%;height: 87px;border: 1px solid #d43d3d;position: absolute;left: 0;top: 0;-wekbit-box-sizing: border-box;box-sizing: border-box;border-radius: 44px;pointer-events: none;-ms-transform-origin: 0 0;transform-origin: 0 0;-ms-transform: scale(.5);transform: scale(.5);}
.login_xlmm li #xlmmshpw {position: absolute;right: 15px;top: 12px;color: #666;}

.login_pop .xl-loginFrame-foot{ display:none;}
.login_pop .xlmmzhdl-list{ margin-bottom:0px;}
.login_pop .xl-footer{ height:20px;}
.xl-loginFrame-foot {width: 100%;position: fixed;left:0;bottom: 0; background:#fff; padding:16px 0 0;}
.xlmmzhdl-list {padding: 0 7%;margin-bottom: 16px;text-align: center;}
.xlmmzhdl-list span{ width:20%; display:inline-block;}
.xlmmzhdl-list span img{ width:38px; height:38px;}
.xl-footer {height: 50px;padding: 0 10%;text-align: center;font-size: 15px;color: #666;}
.xl-footer em {font-weight: 400;color: #c5c9d2;}
.xlmmft .sub-nav { display:none;}


.xlmmzhpwd {bottom: 0;left: 0;position: fixed;-webkit-transform: translateY(100%);-ms-transform: translateY(100%);transform: translateY(100%);-webkit-transition: -webkit-transform 0ms;transition: transform 0ms ;width: 100%;height: 100%;z-index: 9;background:#fff !important;}
.am-modal-active {transform: translateY(0px);-webkit-transform: translateY(0);-ms-transform: translateY(0);transform: translateY(0) }

.login-btn-text{ color:#888;}

</style>

<!--{if !$_GET['infloat']}-->

<!--{/if}-->

{eval $loginhash = 'L'.random(4);}

<!-- userinfo start -->
<div class="loginbox <!--{if $_GET[infloat]}-->login_pop<!--{/if}-->">
	<!--{if $_GET[infloat]}-->
		<h2 class="log_tit"><a href="javascript:;" onclick="popup.close();"><span class="icon_close y">&nbsp;</span></a>{lang login}</h2>
	<!--{/if}-->
		<form id="loginform" method="post" name="forms" action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
		<input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
		<input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
		<input type="hidden" name="fastloginfield" value="username">
		<input type="hidden" name="cookietime" value="2592000">
		<!--{if $auth}-->
			<input type="hidden" name="auth" value="$auth" />
		<!--{/if}-->
	<div class="login_xlmm">
		<ul>
			<li><input type="text" value="" tabindex="1" class="px p_fre" size="30" autocomplete="off" value="" name="username" placeholder="�����������û���" fwin="login"></li>
			<li><span id="xlmmspw"><input type="password" tabindex="2" class="px p_fre" size="30" value="" name="password" placeholder="��������������" fwin="login"></span><!--{if $_GET[infloat]}--><!--{else}--><span id="xlmmshpw"><a href="javascript:ps()">��ʾ����</a></span><!--{/if}--></li>
			<li class="questionli">
				<div class="login_select">
				<span class="login-btn-inner">
					<span class="login-btn-text">
						<span class="span_question">{lang security_question}</span>
					</span>
					<span class="icon-arrow">&nbsp;</span>
				</span>
				<select id="questionid_{$loginhash}" name="questionid" class="sel_list" >
					<option value="0" selected="selected">{lang security_question}</option>
					<option value="1">{lang security_question_1}</option>
					<option value="2">{lang security_question_2}</option>
					<option value="3">{lang security_question_3}</option>
					<option value="4">{lang security_question_4}</option>
					<option value="5">{lang security_question_5}</option>
					<option value="6">{lang security_question_6}</option>
					<option value="7">{lang security_question_7}</option>
				</select>
				</div>
			</li>
			<li class="bl_none answerli" style="display:none;"><input type="text" name="answer" id="answer_{$loginhash}" class="px p_fre" size="30" placeholder="{lang security_a}"></li>
		</ul>
		<!--{if $seccodecheck}-->
		<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
	</div>
	<div class="btn_login"><button tabindex="3" value="true" name="submit" type="submit" class="formdialog pn pnc"><span>{lang login}</span></button></div>
	</form>
	<!--{if $_G['setting']['regstatus']}-->
	<p style="text-align:center; margin:8px 0;">��</p>
	<div class="btn_zhdl"><a href="member.php?mod={$_G[setting][regname]}">ע��һ���˺�</a></div>
	<!--{/if}-->
	<!--{hook/logging_bottom_mobile}-->



<div class="xl-loginFrame-foot">
<div class="xlmmzhdl-list">
	<!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}--><span class="for-qq"><a href="$_G[connect][login_url]&statfrom=login_simple"><img src="template/xlmm_zx/m-img/qqload.png"></a></span><!--{/if}-->
</div>

<div class="xl-footer"><em>���������ˣ�</em><a onClick="xlmmpowdh()">�����һ�</a></div>
</div>

		<script type="text/javascript">
			function xlmmpowdh(){
				$(".xlmmzhpwd").addClass("am-modal-active block");	
						$(".xlmmsf-header").addClass("none");

				$(".xlmmpwdzhcl").click(function(){
						$(".xlmmsf-header").removeClass("none");
				$(".xlmmzhpwd").removeClass("am-modal-active block");	
				})
			}	
		</script>

<div class="xlmmzhpwd none">
	<div class="login_xlmm cl" style="margin-top:80px; padding:0 10%">
		<form method="post" autocomplete="off" id="lostpwform_$loginhash" class="cl" action="member.php?mod=lostpasswd&lostpwsubmit=yes&infloat=yes">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="handlekey" value="lostpwform" />
			<ul >
				<li><input type="text" name="email" id="lostpw_email" size="30" value=""  tabindex="1" class="px p_fre" placeholder="�����ַ" /></li>
			<li><input type="text" name="username" id="lostpw_username" size="30" value=""  tabindex="1" class="px p_fre" placeholder="{lang inputyourname}" /></li>
			</ul>
	<div class="btn_login"><button class="formdialog pn pnc" type="submit" name="lostpwsubmit" value="true" tabindex="100">{lang submit}</button></div>
		</form>
</div>
<div class="sf-goback xlmmpwdzhcl iconfont" style="text-align:center; margin-top:80px; font-size:40px;">&#xe701;</dv>
</div>



</div>
<!-- userinfo end -->
<script language="JavaScript">
function ps(){
if (this.forms.password.type="password")
xlmmspw.innerHTML="<input type=\"html\" tabindex=\"2\" class=\"px p_fre\" size=\"30\" name=\"password\" placeholder=\"����û������{lang login_password}\" fwin=\"login\" value="+this.forms.password.value+">";
xlmmshpw.innerHTML="<a href=\"javascript:txt()\">��������</a>"}
function txt(){
if (this.forms.password.type="text")
xlmmspw.innerHTML="<input type=\"password\" tabindex=\"2\" class=\"px p_fre\" size=\"30\" name=\"password\" placeholder=\"��û������{lang login_password}Ŷ\" fwin=\"login\" value="+this.forms.password.value+">";
xlmmshpw.innerHTML="<a href=\"javascript:ps()\" >��ʾ����</a>"}
</script>

<!--{if $_G['setting']['pwdsafety']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<!--{/if}-->
<!--{eval updatesession();}-->

<script type="text/javascript">
	(function() {
		$(document).on('change', '.sel_list', function() {
			var obj = $(this);
			$('.span_question').text(obj.find('option:selected').text());
			if(obj.val() == 0) {
				$('.answerli').css('display', 'none');
				$('.questionli').addClass('bl_none');
			} else {
				$('.answerli').css('display', 'block');
				$('.questionli').removeClass('bl_none');
			}
		});
	 })();
</script>

<!--{eval $nofooter = true;}-->

<!--{template common/footer}-->




