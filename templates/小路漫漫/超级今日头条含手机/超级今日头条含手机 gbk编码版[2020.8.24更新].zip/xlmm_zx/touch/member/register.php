<?PHP exit('Access Deniedxiaoluanman');?>
<!--{template common/header}-->
<style>
.bg {background:#fff !important;}
.sf-header {border:0;}
.loginbox {padding: 10px 10%;padding-top:25px;padding-bottom:30px;}
.login_xlmm li {height: 44px;margin: 0 0 10px;padding: 0 15px;position: relative;overflow: hidden;background:#fff;}
.sec_code {margin: 0 0 10px;padding: 0 15px;position: relative;background:#fff;}
.sec_code:after, .login_xlmm li:after {height: 87px;border: 1px solid #e9e9e9;top: 0;border-radius: 44px;pointer-events: none;width: 199.9%;}
.sec_code:after, .login_xlmm li:after {content: '';position: absolute;left: 0;-ms-transform-origin: 0 0;transform-origin: 0 0;-ms-transform: scale(.5);transform: scale(.5);-wekbit-box-sizing: border-box;box-sizing: border-box;}
.login_xlmm .p_fre {border: 0;width:100% !important;padding: 11px 0;line-height: 17px;font-size: 15px;box-shadow: 0 0 0 1000px #fff inset;}
.sec_code .px {border: 0;padding: 11px 0;line-height: 17px;font-size: 15px;box-shadow: 0 0 0 1000px #fff inset;}
.px:focus {outline: -webkit-focus-ring-color auto 0px;}
.login-btn-text {margin-top:11px}

.btn_login .pn, .btn_register .pn {display: inline-block;width: 100%;border-radius: 44px;line-height: 100%;background: #d43d3d ;text-align: center;font-size: 15px;color: #fff;}
.btn_zhdl a {display: block;width: 100%;height: 44px;line-height: 44px;position: relative;overflow: hidden;text-align: center;font-size: 15px!important;color: #d43d3d;}
.btn_zhdl a:after {content: '';width: 199.9%;height: 87px;border: 1px solid #d43d3d;position: absolute;left: 0;top: 0;-wekbit-box-sizing: border-box;box-sizing: border-box;border-radius: 44px;pointer-events: none;-ms-transform-origin: 0 0;transform-origin: 0 0;-ms-transform: scale(.5);transform: scale(.5);}
.xlmmft .sub-nav { display:none;}
</style>
<!-- registerbox start -->
<div class="loginbox registerbox">
	<div class="login_xlmm">
		<form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}&mobile=2">
		<input type="hidden" name="regsubmit" value="yes" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
		<input type="hidden" name="referer" value="$dreferer" />
		<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
		<input type="hidden" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
		<ul>
			<li><input type="text" tabindex="1" class="px p_fre" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip}" fwin="login"></li>
			<li><input type="password" tabindex="2" class="px p_fre" size="30" value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password}" fwin="login"></li>
			<li><input type="password" tabindex="3" class="px p_fre" size="30" value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2}" fwin="login"></li>
			<li class="bl_none"><input type="email" tabindex="4" class="px p_fre" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login"></li>
			<!--{if empty($invite) && ($_G['setting']['regstatus'] == 2 || $_G['setting']['regstatus'] == 3)}-->
				<li><input type="text" name="invitecode" autocomplete="off" tabindex="5" class="px p_fre" size="30" placeholder="{lang invite_code}" fwin="login"></li>
			<!--{/if}-->
			<!--{if $_G['setting']['regverify'] == 2}-->
				<li><input type="text" name="regmessage" autocomplete="off" tabindex="6" class="px p_fre" size="30" placeholder="{lang register_message}" fwin="login"></li>
			<!--{/if}-->
		</ul>
		<!--{if $secqaacheck || $seccodecheck}-->
			<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
	</div>
	<div class="btn_register"><button tabindex="7" value="true" name="regsubmit" type="submit" class="formdialog pn pnc"><span>{lang quickregister}</span></button></div>
	</form>

	<p style="text-align:center; margin:8px 0;">��</p>
	<div class="btn_zhdl"><a href="member.php?mod=logging&action=login">�˺ŵ�¼</a></div>


</div>
<!-- registerbox end -->

<!--{eval updatesession();}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->




