<?PHP exit('Access xlmm QQdism.taobao.com');?>
<!--{template common/header}-->
		<style>
/* tag,guide�� */
.swiper-container {
    max-height: 100%;
}
.adtopic {padding-top: 12px; padding:0 10px;}
.localloop-title {color: #222222;font-size: 13px;padding-left: 10px;display: block;}
.adtopic-list ul li {float: left;margin-right: 10px;margin-top: 10px;font-size: 13px;}
.adtopic-list ul li a span{display: inline-block;color: #222222;background-color: #f5f5f5;height: 30px;line-height: 30px;padding-left: 10px;padding-right: 10px; max-width: 130px;min-width: 24px;white-space: nowrap;overflow: hidden;text-overflow: ellipsis;border-radius: 25x;-wwebkit-border-radius: 25x;-o-border-radius: 25x;-moz-border-radius: 25x;-ms-border-radius: 25x;}
		</style>
<!--{if $tagname}-->
 <!--{if empty($showtype) || $showtype == 'thread'}-->
				<!--{if $threadlist}-->
	<content class="feed-list-container " id="junmi360" style="padding-top:0" >
					<!--{loop $threadlist $thread}-->
					<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
                                        	{eval include TPLDIR.'/php/forum_forumdisplay.php';}
<!--{if $xlmmal <1}-->
<section class="has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail">								
<h3 class="dotdot line3">										$thread[typehtml] $thread[sorthtml]
										$thread[subject]
</h3><div class="item_info"><div><span class="src space">$thread[author]</span><span class="cmt space">�ظ� $thread[replies]</span><span class="time">$thread[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal >2}-->
<section class="has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail"><h3 class="dotdot line3">$thread[typehtml] $thread[sorthtml]
										$thread[subject]</h3>
<div class="list_image" style="margin-top:5px;">
<ul class="clearfix">
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
<li class="list_img_holder"><img src="$xlmmimg"></li>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==3) break;}-->
<!--{/loop}-->
</ul>
</div>
<div class="item_info"><div><span class="src space">$thread[author]</span><span class="cmt space">�ظ� $thread[replies]</span><span class="time">$thread[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal <=2}-->
<section class="middle_mode has_action"><a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="article_link clearfix "><div class="item_detail desc">
                                        <h3 class="dotdot line3 image-margin-right">$thread[typehtml] $thread[sorthtml]
										$thread[subject]</h3><div class="item_info"><div><span class="src space">$thread[author]</span><span class="cmt space">�ظ� $thread[replies]</span><span class="time">$thread[dateline]</span><span class="dislike-news fr mid-space"></span></div></div></div>
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = 'template/xlmm_zx/php/small.php?filename=' . $attach['attachment'] . '&width=230&height=230'; }
		<!--{/if}-->
 <div class="list_img_holders"><img src="$xlmmimg"></div>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==1) break;}-->
<!--{/loop}-->
</a></section>
<!--{/if}-->
           						<!--{/loop}-->
				</content>
						<!--{if empty($showtype)}-->
						<div style="text-align:center; margin-top:10px;">
							<a style="color:#607fa6;" href="misc.php?mod=tag&id=$id&type=thread">{lang more}...</a>
						</div>
					<!--{else}-->
						<!--{if $multipage}--><div class="pgs mtm cl">$multipage</div><!--{/if}-->
					<!--{/if}-->
				<!--{else}-->
					<p class="emp">{lang no_content}</p>
				<!--{/if}-->
			<!--{/if}-->

<!--{/if}-->
	<div class="clearfix"></div>
<!--{template common/footer}-->





