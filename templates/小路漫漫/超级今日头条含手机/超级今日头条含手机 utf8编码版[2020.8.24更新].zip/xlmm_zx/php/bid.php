<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: forum_guide.php 34066 2013-09-27 08:36:09Z nemohou $
 *      QQ dism.taobao.com 最后修改 2019.01
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$xlmmttbid =$_G['cache']['plugin']['xlmm_tt']['ttbid'];

$perpage =$_G['cache']['plugin']['xlmm_tt']['tiaoshu'] ;
$page = intval($_GET['page']);
if($page<1) $page = 1;
$start = ($page-1)*$perpage;
	$pricount = 0;

$multi = '';
$xlmmhmbid =  $xlmmtoutiao['xlmmfyid'];
$shownum = DB::fetch_all("SELECT shownum,dateformat FROM ".DB::table('common_block')." WHERE bid = $xlmmttbid ");
foreach($shownum as $key=>$shownums){}
           $count = DB::result_first("select count(*)  FROM ".DB::table("common_block_item")." where bid=$xlmmttbid ORDER BY displayorder ASC ");
	if($count) {
$xlmmlistbid = DB::fetch_all("SELECT * FROM ".DB::table("common_block_item")." where bid=$xlmmttbid ORDER BY displayorder ASC LIMIT $start , $perpage ");
	}

$multi = multi($count, $perpage, $page, "portal.php?mod=portal");


