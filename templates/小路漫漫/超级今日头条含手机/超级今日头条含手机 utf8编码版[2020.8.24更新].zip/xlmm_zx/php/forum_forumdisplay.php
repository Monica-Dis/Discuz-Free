<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: forum_guide.php 34066 2013-09-27 08:36:09Z nemohou $
 *      QQ dism.taobao.com 最后修改 2018.10
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

 include_once libfile('function/post');
include_once libfile('function/attachment');

$post = C::t('forum_post')->fetch_all_by_tid_position($thread['posttableid'],$thread['tid'],1);
$post = array_shift($post);
$xiaolu['fmessage'] = messagecutstr($post['message'], 200);
   $xlmmtutab='forum_attachment_'.substr($thread['tid'], -1);
   $xlmmattach = DB::fetch_all("SELECT a.attachment,a.aid,a.remote,b.pid FROM ".DB::table($xlmmtutab)." a left join ".DB::table("forum_post")." b on b.pid=a.pid WHERE a.tid='$thread[tid]' AND a.isimage!='0' AND b.first=1");

                            preg_match_all('/(\\[img\\]|\\[img=\\d{1,4}[x|\\,]\\d{1,4}\\]|<img.*?src=")\\s*([^\\[\\<\\r\\n]+?)\\s*(\\[\\/img\\]|".*>)/is', $post['message'], $xlmmpic, PREG_SET_ORDER);
                        foreach ($xlmmpic as $img) {
                            $xlmmattach[] = array('attachment' => $img[2]);
                            $xlmmal++;
                            if ($xlmmal >= 4) {
                                break;
                            }
                        }

$attachment = $attach['attachment'];
                     $xlmmal =  count($xlmmattach);
        $getgid=getuserbyuid($thread[authorid]);
        $xlmmdj = DB::result_first("SELECT stars FROM %t WHERE groupid=%d", array("common_usergroup", $getgid['groupid']));

?>


