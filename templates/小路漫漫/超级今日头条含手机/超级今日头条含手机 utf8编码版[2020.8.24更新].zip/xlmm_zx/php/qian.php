<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: forum_guide.php 34066 2013-09-27 08:36:09Z nemohou $
 *      QQ dism.taobao.com 最后修改 2016.12
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

 $time = DB::fetch_all("SELECT value as time FROM ".DB::table('common_pluginvar')." WHERE `variable`='timeopen' or `variable`='stime' or `variable`='ftime'");$open = $time[1][time];$a = date('Y-m-d ',time());$b ="0:0";$stime = strtotime($a.$time[0][time].":".$b);$ftime = strtotime($a.$time[2][time].":".$b);$time = strtotime(date('Y-m-d',time()));
 
  $xlmmtotal = DB::fetch_all("SELECT * FROM ".DB::table('dsu_paulsignset')." WHERE `id` >= 1");
 $countxlmm = DB::fetch_all("SELECT COUNT(*) as dd FROM ".DB::table('dsu_paulsign')." WHERE time >= $time AND `uid` =".$_G[uid]."");$countxlmm[0][dd]

 ?>


