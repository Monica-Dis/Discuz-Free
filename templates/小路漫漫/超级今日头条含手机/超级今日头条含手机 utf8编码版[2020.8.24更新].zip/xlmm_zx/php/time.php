<?php  
function xlmmtime($date)
{  
    $str = '';  
    $timer = strtotime($date);  
    $diff = $_SERVER['REQUEST_TIME'] - $timer;  
    $day = floor($diff / 86400);  
	  $free = $diff % 86400;  
    $year = floor($diff / 60 / 60 / 24 / 365);    
      $m = floor($diff / 2592000);  
  if($year){ 
        return $year.'年前'; 
    }    
 elseif($m>=1 && $m < 12){        
        return $m.'个月前'; 
    } 
		  elseif($day > 0) 
    {  
        return $day."天前";  
    }
    else
    {  
        if($free>0)
        {  
            $hour = floor($free / 3600);  
            $free = $free % 3600;  
                if($hour>0)
                {  
                    return $hour."小时前";  
                }
                else
                {  
                    if($free>0)
                    {  
                        $min = floor($free / 60);  
                        $free = $free % 60;  
                        if($min>0)
                        {  
                            return $min."分钟前";  
                        }
                        else
                        {  
                            if($free>0)
                            {  
                                return $free."秒前";  
                            }
                            else
                            {  
                                return '刚刚';  
                            }  
                       }  
                    }
                    else
                    {  
                        return '刚刚';  
                    }  
               }  
       }
       else
       {  
           return '刚刚';  
       }  
    }  
}  
?>


