<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/tt_header}-->
<script src="template/xlmm_zx/jquery.ias.min.js?{VERHASH}"></script>
 <script src="$_G['style']['styleimgdir']/xlmm.js?{VERHASH}"></script>
<style id="diy_style" type="text/css"></style>
	<!--[diy=xlmm-t]--><div id="xlmm-t" class="area"></div><!--[/diy]-->
<style>
#fixed { margin-top:16px}#fixed .hide, #fixed .hides{ display: block ;}

 .msgAlert { margin-bottom:10px;height: 33px;	line-height: 32px;	font-size: 14px;	color: #fff;	text-align: center;	background-color: #60a3f5;	background-color: rgba(96,163,245,.85);	z-index: 20;	-webkit-transition-property: height;	transition-property: height;	-webkit-transition-delay: 0;	transition-delay: 0;	-webkit-transition-duration: .5s;	transition-duration: .5s;}
 .list-refresh-msg { margin-bottom:10px;text-align: center;	font-size: 14px; display:block;color: #2A90D7;	height: 32px;	line-height: 32px;	background: #2A90D7;	background: rgba(41,144,215,.08);	border: 1px solid #2A90D7;	border: 1px solid rgba(41,144,215,.5);	border-radius: 4px;	cursor: pointer;}
 #ft {
	padding:0; line-height:0; border:0;
}

.tt-input {position: relative;font-size: 14px;display: inline-block;width: 100%;}
.tt-input-group {line-height: normal;display: inline-table;width: 100%;border-collapse: separate;}
.search-wrap .tt-input__inner {height: 44px;}
.tt-input-group--append .tt-input__inner, .tt-input-group__prepend {border-top-right-radius: 0;border-bottom-right-radius: 0;}
.tt-input-group > .tt-input__inner {vertical-align: middle;display: table-cell;}
.tt-input__inner, .tt-select-dropdown, .tt-select-dropdown__item, .tt-select .tt-tag, .tt-tag, .tt-textarea__inner {box-sizing: border-box;}
.tt-input__inner {-webkit-appearance: none;-moz-appearance: none;appearance: none;background-color: #f5f6f7;border-radius: 4px;border-top-right-radius: 4px;border-bottom-right-radius: 4px;border: 1px solid #e8e8e8;color: #1f2d3d;display: block;font-size: inherit;height: 40px;outline: 0;padding: 3px 10px;transition: border-color .2s cubic-bezier(.645,.045,.355,1);width: 100%;}
.tt-input__inner, .tt-textarea__inner {background-image: none;box-sizing: border-box;}
button, input, select, textarea {font-family: inherit;font-size: inherit;line-height: inherit;}

.tt-input-group__append .tt-button, .tt-input-group__append .tt-input, .tt-input-group__prepend .tt-button, .tt-input-group__prepend .tt-input {font-size: inherit;}
.tt-input-group__append .tt-button, .tt-input-group__append .tt-select .tt-input__inner, .tt-input-group__append .tt-select:hover .tt-input__inner, .tt-input-group__prepend .tt-button, .tt-input-group__prepend .tt-select .tt-input__inner, .tt-input-group__prepend .tt-select:hover .tt-input__inner {border-color: transparent;border-top-color: transparent;border-bottom-color: transparent;background-color: transparent;color: inherit;border-top: 0;border-bottom: 0;}
.tt-input-group__append .tt-button, .tt-input-group__append .tt-select, .tt-input-group__prepend .tt-button, .tt-input-group__prepend .tt-select {display: block;margin: -10px;}
[type="reset"], [type="submit"], button, html [type="button"] {-webkit-appearance: button;}
.tt-button, .tt-button-group, .tt-dropdown {display: inline-block;}
.tt-button {display: inline-block;line-height: 1;white-space: nowrap;cursor: pointer;background: #fff;background-color: rgb(255, 255, 255);border: 1px solid #bfcbd9;border-top-width: 1px;border-bottom-width: 1px;border-top-style: solid;border-bottom-style: solid;border-top-color: rgb(191, 203, 217);border-right-color: rgb(191, 203, 217);border-bottom-color: rgb(191, 203, 217);border-left-color: rgb(191, 203, 217);color: #1f2d3d;-webkit-appearance: none;text-align: center;box-sizing: border-box;outline: 0;margin: 0;-moz-user-select: none;-webkit-user-select: none;-ms-user-select: none;padding: 10px 15px;font-size: 14px;border-radius: 4px;}
.tt-autocomplete .tt-input-group__append {border: 1px solid #208eda;background-color: #208eda;color: #fff;position: relative;left: -1px;padding: 0 18px;}
.tt-input-group__append {border-left: 0;}
.tt-input-group--prepend .tt-input__inner, .tt-input-group__append {border-top-left-radius: 0;border-bottom-left-radius: 0;}
.tt-input-group__append, .tt-input-group__prepend {color: #97a8be;vertical-align: middle;display: table-cell;position: relative;border: 1px solid #e8e8e8;border-radius: 4px;border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding: 0 10px;width: 1%;white-space: nowrap;}

.outer {width:300px;margin:16px 0;padding:20px;background:#f4f5f6}
.outer .inner {text-align:center;background:#fff;border:1px solid #e8e8e8;letter-spacing:0}

                        {if $_G['uid']}
.logged {padding:8px 8px 10px 6px}
.logged .top {font-size:0}
.logged .top .logout {font-size:12px;line-height:17px;text-align:right}
.logged .top .logout span {color:#999}
.logged .top .logout span:hover {color:#406599}
.logged .top .head img{width:56px;height:56px;margin-top:-5px;border-radius:50%;border:1px solid #fff}
.logged .top .name {margin-top:7px;font-size:16px;line-height:22px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.logged .top .name span {color:#222}
.logged .top .name span:hover {color:#406599}
.logged .top .history-collect {margin:8px 0 10px;line-height:20px;height:20px}
.logged .top .history-collect span {font-size:14px;color:#777}
.logged .top .history-collect img {width:16px;height:16px;margin-right:4px;transform:translateY(3px)}
.logged .top .history-collect .icon {margin-right:4px;font-size:16px;color:#cacaca}
.logged .bottom {padding-top:10px;font-size:0;position:relative}
.logged .bottom li {display:inline-block;width:50%}
.logged .bottom .line {position:absolute;top:0;width:1px;height:64px;transform:scale(.5);background:#e8e8e8}
.logged .bottom a:hover p {color:#406599}
.logged .bottom p {display:inline-block;font-size:14px;line-height:20px}
.logged .bottom .num {width:auto;margin-bottom:2px;font-size:20px;font-weight:600;line-height:28px;color:#222}
.logged .bottom .word {color:#777!important;}
                        {else}
.login {height:166px;padding:20px 28px 15px}
.login .login-msg {font-size:12px;line-height:17px;color:#777}
.login .login-button {width:240px;height:40px;margin:16px 0 14px;font-size:14px;line-height:20px;color:#fff;background:#ed4040;border:none;border-radius:4px;cursor:pointer}
.login .login-button:hover {opacity:.9}
.login .third-login .sns {display:inline-block;position:relative;width:36px;height:58px;cursor:pointer;background-repeat:no-repeat;background-size:100% 36px}
.login .third-login .sns:hover {opacity:.8}
.login .third-login .sns:not(:last-child) {margin-right:24px}
.login .third-login .sns span {position:absolute;left:6px;top:41px;width:24px;font-size:12px;line-height:17px;color:#777}
.login .third-login .weibo {background-image:url(template/xlmm_zx/image/wb.png);}
.login .third-login .qq {background-image:url(template/xlmm_zx/image/qq.png);}
.login .third-login .weixin {background-image:url(template/xlmm_zx/image/wx.png);}
                        {/if}
.hot-words-pane {padding-bottom: 14px;padding-top: 20px;}
.hot-words-title {padding:0 20px 5px;overflow: auto;}
.hot-words-title img {height: 17px;width: 66px;}
.hot-words-title .more-hot-words {float: right;line-height: 20px;font-size: 14px;}
.hot-words-title .more-hot-words .icon_more {height: 10px;width: 6px;}
.hot-search {padding:0 20px;}
.hot-search li {padding: 12px 0;border-bottom: 1px solid #e8e8e8;line-height: 20px;position: relative;}
.hot-search li a i {padding: 0 5px 0 0;}
.hot-search li .search-text {width: 98px;height: 20px;font-family: PingFangSC;}
.search-no{    padding: 0 5px 0 0;color: #999;font-style: italic;width: 25px; display: inline-block;vertical-align: middle;text-indent: 0px;font-size: 14px;text-align: left;}
.search-no-1, .search-no-2, .search-no-3 {color: #f85959;}

</style>

<div class="y-box container">
  <div class="y-left index-channel">
 <!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttnav'] == 1}-->
	<style>
.wchannel-item a {
    display: inline-block;
    font-size: 16px; color:#444 !important;
}
.wchannel-item.active a{
	color: #fff !important;
}
.wchannel-item span{ display:none;}
.wchannel-item:hover a{
	color: #fff !important;
}

</style>

<div class="wchannel " id="fthread"> 
    <a class="logo" href="./"> <img src="template/xlmm_zx/portal/list/logo.png"> </a> 
    <ul> 
					<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="wchannel-item active" {else}class="wchannel-item" {/if}$nav[nav]></li><!--{/if}-->
						<!--{/loop}-->
 </ul> 
 
 </div>
 <div class="none"> 
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
	<!--[diy=xlmm-l]--><div id="xlmm-l" class="area"></div><!--[/diy]-->
					<!--{/if}-->
 </div>
 <!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttnav'] == 2}-->
	<!--[diy=xlmm-l]--><div id="xlmm-l" class="area"></div><!--[/diy]-->
  <!--{/if}-->

 </div>

  
    <div class="y-left index-content">
		<!--{ad/articlelist/mbm hm/1}--><!--{ad/articlelist/mbm hm/2}-->
	<!--[diy=xlmm-hd]--><div id="xlmm-hd" class="area"></div><!--[/diy]-->
 <!--{if $_G['cache']['plugin']['xlmm_tt']['diaoyont'] == 3}-->
   {eval include_once TPLDIR.'/php/bid.php';}
<div class="msgAlert msgAlert-hidden">为您推荐了 $count 条内容<!--{if check_diy_perm($topic)}--><a href="plugin.php?id=xlmm_tt:ttdiy&diy=yes" style="color:red; margin-left:25px">数据管理</a>
					<!--{/if}--></div>
 										<!--{/if}-->
      <div class="feedBox">  
    <div class="wcommonFeed">
    
<div id="threadlist">
						<ul id="alist" class="xlmm-sx">
     <!--{eval $page=$_G['page'];}-->
<!--{if $_G['cache']['plugin']['xlmm_tt']['diaoyont'] == 1}-->
{eval include_once TPLDIR.'/php/forum_guide.php';}
									        	<!--{loop $grids['newthread'] $key $thread}-->
  											<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
 <!--{if $_G['page'] ==1 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad1']}-->                                                                    
 <!--{elseif $_G['page'] ==2 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad2']}-->                                                                    
 <!--{elseif $_G['page'] ==3 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad3']}-->                                                                    
 <!--{elseif $_G['page'] ==4 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad4']}-->                                                                    
 <!--{elseif $_G['page'] ==5 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad5']}-->                                                                    
 <!--{elseif $_G['page'] ==6 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad6']}-->                                                                    
										<!--{/if}-->
	
			{eval include TPLDIR.'/php/forum_forumdisplay.php';
                $xlmmbio = DB::fetch_all("SELECT name FROM  ".DB::table('forum_forum')." WHERE `fid` = $thread[fid]");}
<!--{if $xlmmal >$_G['cache']['plugin']['xlmm_tt']['xlmmduotu']}-->

<li class="item">
 <div class="item-inner y-box">
  <div class="normal  "> 
  <div class="rbox-inner"> 
  <div class="title-box"> 
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" target="_blank" class="link">$thread[typehtml] $thread[sorthtml] $thread[subject]</a> 					<!--{if $stemplate && $sortid}-->$stemplate[$sortid][$thread[tid]]<!--{/if}-->
					<!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->
					<!--{if $thread['price'] > 0}-->
						<!--{if $thread['special'] == '3'}-->
						- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1" title="{lang show_rewarding_only}"><span class="xi1">[{lang thread_reward} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span></a>
						<!--{else}-->
						- [售价 <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
						<!--{/if}-->
					<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
						- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2" title="{lang show_rewarded_only}">[{lang reward_solved}]</a>
					<!--{/if}-->

  </div> 
  <div class="img-list y-box"> 
   <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment'] ; }
		<!--{/if}-->
    <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="img-wrap" target="_blank"> <img src="$xlmmimg" class="xlmmlazy"> </a>
 <!--{eval $i++}-->
<!--{eval if($i==4) break;}-->
<!--{/loop}--> 
<!--{if $xlmmal >3}--><span class="img-num">{eval echo $xlmmal}图</span><!--{/if}--> 
    </div> 
    <div class="y-box footer"> <div class="y-left"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank" class="lbtn tag tag-bg-other">{loop $xlmmbio $key $xlmmbio} $xlmmbio[name] {/loop}</a>
<div class="y-left"> <a href="home.php?mod=space&uid=$thread[authorid]" class="lbtn media-avatar" target="_blank">{avatar($thread[authorid],small)}</a> 
       <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank" class="lbtn">&nbsp;$thread[author]&nbsp;</a> <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="lbtn" target="_blank">&nbsp;$thread[views]次点击&nbsp;$thread[replies]评论&nbsp;</a></div> <span class="lbtn">&nbsp;$thread[dateline]</span>    
            {if $thread[replies] > 4}<span class="lbtn tag-hot">热</span> {/if} 
    {if $thread['digest']}<span class="lbtn recommend" style="margin-left:10px;">精华</span> {/if} 
</div> <div class="y-right">	
</div> </div> </div> </div>  </div>  </li>
<!--{elseif $xlmmal ==0}-->

<li class="item">
 <div class="item-inner y-box">
  <div class="normal  "> 
  <div class="rbox-inner"> 
  <div class="title-box"> 
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" target="_blank" class="link">$thread[typehtml] $thread[sorthtml] $thread[subject]</a> 					<!--{if $stemplate && $sortid}-->$stemplate[$sortid][$thread[tid]]<!--{/if}-->
					<!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->
					<!--{if $thread['price'] > 0}-->
						<!--{if $thread['special'] == '3'}-->
						- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1" title="{lang show_rewarding_only}"><span class="xi1">[{lang thread_reward} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span></a>
						<!--{else}-->
						- [售价 <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
						<!--{/if}-->
					<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
						- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2" title="{lang show_rewarded_only}">[{lang reward_solved}]</a>
					<!--{/if}-->

  </div> 

    <div class="y-box footer"> <div class="y-left"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank" class="lbtn tag tag-bg-other">{loop $xlmmbio $key $xlmmbio} $xlmmbio[name] {/loop}</a>
<div class="y-left"> <a href="home.php?mod=space&uid=$thread[authorid]" class="lbtn media-avatar" target="_blank">{avatar($thread[authorid],small)}</a> 
       <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank" class="lbtn">&nbsp;$thread[author]&nbsp;</a> <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="lbtn" target="_blank">&nbsp;$thread[views]次点击&nbsp;$thread[replies]评论&nbsp;</a></div> <span class="lbtn">&nbsp;$thread[dateline]</span>    
            {if $thread[replies] > 4}<span class="lbtn tag-hot">热</span> {/if} 
    {if $thread['digest']}<span class="lbtn recommend" style="margin-left:10px;">精华</span> {/if} 
</div> <div class="y-right">	
</div> </div> </div> </div>  </div>  </li>

<!--{elseif $xlmmal <=$_G['cache']['plugin']['xlmm_tt']['xlmmduotu']}-->
<li class="item"> <span id="ad_extra" style="display:none;"></span> <div class="item-inner y-box"> <div class="normal rbox "> <div class="rbox-inner"> <div class="title-box" ga_event="article_title_click">           <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" target="_blank" class="link">$thread[typehtml] $thread[sorthtml] $thread[subject]</a> 					<!--{if $stemplate && $sortid}-->$stemplate[$sortid][$thread[tid]]<!--{/if}-->
					<!--{if $thread['readperm']}--> - [{lang readperm} <span class="xw1">$thread[readperm]</span>]<!--{/if}-->
					<!--{if $thread['price'] > 0}-->
						<!--{if $thread['special'] == '3'}-->
						- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1" title="{lang show_rewarding_only}"><span class="xi1">[{lang thread_reward} <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]</span></a>
						<!--{else}-->
						- [售价 <span class="xw1">$thread[price]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}]
						<!--{/if}-->
					<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
						- <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2" title="{lang show_rewarded_only}">[{lang reward_solved}]</a>
					<!--{/if}-->


</div>  <div class="y-box footer"> <div class="y-left"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank" class="lbtn tag tag-bg-other">{loop $xlmmbio $key $xlmmbio} $xlmmbio[name] {/loop}</a>
<div class="y-left"> <a href="home.php?mod=space&uid=$thread[authorid]" class="lbtn media-avatar" target="_blank">{avatar($thread[authorid],small)}</a> 
       <a href="home.php?mod=space&uid=$thread[authorid]" target="_blank" class="lbtn">&nbsp;$thread[author]&nbsp;</a> <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="lbtn" target="_blank">&nbsp;$thread[views]次点击&nbsp;$thread[replies]评论&nbsp;</a></div> <span class="lbtn">&nbsp;$thread[dateline]</span>    
            {if $thread[replies] > 4}<span class="lbtn tag-hot">热</span> {/if} 
    {if $thread['digest']}<span class="lbtn recommend" style="margin-left:10px;">精华</span> {/if} 
 </div> <div class="y-right">	
</div> </div> </div> </div> <div class="lbox"> 
   <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment'] ; }
		<!--{/if}-->
       <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="img-wrap" target="_blank"> <img alt="$thread[typehtml] $thread[sorthtml] $thread[subject]"  src="$xlmmimg" class="xlmmlazy"> </a>
 <!--{eval $i++}-->
<!--{eval if($i==1) break;}-->
<!--{/loop}--> 
</div> </div>  </li>    
 <!--{/if}-->
    
 			<!--{/loop}-->
<!--{elseif $_G['cache']['plugin']['xlmm_tt']['diaoyont'] == 2}-->
	{eval include_once TPLDIR.'/php/list.php';}
		{eval include TPLDIR.'/php/time.php';}
	<!--{loop $list $key $value}-->
				<!--{eval $article_url = fetch_article_url($value);
}-->
 <!--{if $_G['page'] ==1 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad1']}-->                                                                    
 <!--{elseif $_G['page'] ==2 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad2']}-->                                                                    
 <!--{elseif $_G['page'] ==3 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad3']}-->                                                                    
 <!--{elseif $_G['page'] ==4 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad4']}-->                                                                    
 <!--{elseif $_G['page'] ==5 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad5']}-->                                                                    
 <!--{elseif $_G['page'] ==6 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad6']}-->                                                                    
										<!--{/if}-->
	
	{eval include TPLDIR.'/php/portal_list.php';}
<!--{if $xlmmal ==0}-->
    
<li class="item ">
 <div class="item-inner y-box">
  <div class="normal  no-image"> 
  <div class="rbox-inner"> 
  <div class="title-box"> 
<a href="$article_url" target="_blank" class="link">$value[title]</a> </div>  
  <div class="y-box footer"> 
  <div class="y-left"> 
<a href="portal.php?mod=list&catid=$value[catid]" target="_blank" class="lbtn tag tag-bg-other">$value['catname']</a>
 <div class="y-left"><a href="home.php?mod=space&uid=$value[uid]" target="_blank" class="lbtn media-avatar">
    <img src="{avatar($value[uid], small, true)}"> </a> 
  <a href="home.php?mod=space&uid=$value[uid]" class="lbtn source" target="_blank">&nbsp;$value[username]&nbsp;</a><a href="portal.php?mod=comment&id=$value[aid]&idtype=aid" class="lbtn comment" target="_blank">&nbsp;$value[viewnum]次点击&nbsp;$value[commentnum]评论&nbsp;</a>
    </div> 
    <span class="lbtn">&nbsp;{eval echo xlmmtime("$value[dateline]"); }</span>    
    {if $value[viewnum] > 180}<span class="lbtn tag-hot">热</span>{/if} </div> 
    <div class="y-right">						<!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $value['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $value['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
						<span class="xg1">
							<span class="pipe">|</span>
							<label><a href="portal.php?mod=portalcp&ac=article&op=edit&aid=$value[aid]">{lang edit}</a></label>
							<span class="pipe">|</span>
							<label><a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$value[aid]" id="article_delete_$value[aid]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang delete}</a></label>
						</span>
						<!--{/if}-->
</div>
     </div> </div>  </div>  </li>    
<!--{elseif $xlmmal >$_G['cache']['plugin']['xlmm_tt']['xlmmduotu']}-->

<li class="item">
 <div class="item-inner y-box">
  <div class="normal  "> 
  <div class="rbox-inner"> 
  <div class="title-box"> 
  <a href="$article_url" target="_blank" class="link">$value[title]</a> 
  </div> 
  <div class="img-list y-box"> 
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==4) break;}-->
<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->
<a href="$article_url" target="_blank" class="img-wrap"> <img src=" <!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1}-->$xlmmimg<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->template/xlmm_zx/php/small.php?filename=<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->&width=230&height=230<!--{/if}-->" class="xlmmlazy"> </a>
						<!--{else}-->
	<a href="$article_url" target="_blank" class="img-wrap"> <img src="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment']<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 4}-->.thumb.jpg<!--{/if}-->" class="xlmmlazy"> </a>
					<!--{/if}-->
<!--{/loop}-->
<!--{if $xlmmal >3}--><span class="img-num">{eval echo $xlmmal}图</span><!--{/if}--> 
    </div> 
    <div class="y-box footer"> <div class="y-left"><a href="portal.php?mod=list&catid=$value[catid]" target="_blank" class="lbtn tag tag-bg-other">$value['catname']</a>
<div class="y-left"> <a href="home.php?mod=space&uid=$value[uid]" class="lbtn media-avatar" target="_blank"> <img src="{avatar($value[uid], small, true)}"> </a> <a href="home.php?mod=space&uid=$value[uid]" class="lbtn source" target="_blank">&nbsp;$value[username]&nbsp;</a><a href="portal.php?mod=comment&id=$value[aid]&idtype=aid" class="lbtn comment" target="_blank">&nbsp;$value[viewnum]次点击&nbsp;$value[commentnum]评论&nbsp;</a></div> <span class="lbtn">&nbsp;{eval echo xlmmtime("$value[dateline]"); }</span>    
    {if $value[viewnum] > 180}<span class="lbtn tag-hot">热</span>{/if}</div> <div class="y-right">						<!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $value['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $value['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
						<span class="xg1">
							<span class="pipe">|</span>
							<label><a href="portal.php?mod=portalcp&ac=article&op=edit&aid=$value[aid]">{lang edit}</a></label>
							<span class="pipe">|</span>
							<label><a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$value[aid]" id="article_delete_$value[aid]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang delete}</a></label>
						</span>
						<!--{/if}-->
</div> </div> </div> </div>  </div>  </li>

<!--{elseif $xlmmal <=$_G['cache']['plugin']['xlmm_tt']['xlmmduotu']}-->
<li class="item"> <span id="ad_extra" style="display:none;"></span> <div class="item-inner y-box"> <div class="normal rbox "> <div class="rbox-inner"> <div class="title-box" ga_event="article_title_click">   <a href="$article_url" target="_blank" class="link">$value[title]</a> 
</div>  <div class="y-box footer"> <div class="y-left"><a href="portal.php?mod=list&catid=$value[catid]" target="_blank" class="lbtn tag tag-bg-other">$value['catname']</a>
<div class="y-left"> <a href="home.php?mod=space&uid=$value[uid]" class="lbtn media-avatar" target="_blank"> <img src="{avatar($value[uid], small, true)}"> </a> <a href="home.php?mod=space&uid=$value[uid]" class="lbtn source" target="_blank">&nbsp;$value[username]&nbsp;</a><a href="portal.php?mod=comment&id=$value[aid]&idtype=aid" class="lbtn comment" target="_blank">&nbsp;$value[viewnum]次点击&nbsp;$value[commentnum]评论&nbsp;</a></div> <span class="lbtn">&nbsp;{eval echo xlmmtime("$value[dateline]"); }</span>    
    {if $value[viewnum] > 180}<span class="lbtn tag-hot">热</span>{/if} </div> <div class="y-right">						<!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $value['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $value['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
						<span class="xg1">
							<span class="pipe">|</span>
							<label><a href="portal.php?mod=portalcp&ac=article&op=edit&aid=$value[aid]">{lang edit}</a></label>
							<span class="pipe">|</span>
							<label><a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$value[aid]" id="article_delete_$value[aid]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang delete}</a></label>
						</span>
						<!--{/if}-->
</div> </div> </div> </div> <div class="lbox"> <a href="$article_url" target="_blank" class="img-wrap">
 <!--{loop $xlmmoutimg $key $xlmmimg}-->
						<!--{eval if($key==1) break;}-->
<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->
<img src="<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1}-->$xlmmimg<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->template/xlmm_zx/php/small.php?filename=<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->&width=230&height=230<!--{/if}-->" class="xlmmlazy"> 			
						<!--{else}-->
 <img src="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment']<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 4}-->.thumb.jpg<!--{/if}-->" class="xlmmlazy"> 			
<!--{/if}-->
<!--{/loop}-->
  </a> </div> </div>  </li>    
 <!--{/if}-->
    
 			<!--{/loop}-->
<!--{elseif $_G['cache']['plugin']['xlmm_tt']['diaoyont'] == 3}-->
<!--{loop $xlmmlistbid $key $thread}-->
    <!--{if $_G['page'] ==1 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad1']}-->                                                                    
 <!--{elseif $_G['page'] ==2 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad2']}-->                                                                    
 <!--{elseif $_G['page'] ==3 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad3']}-->                                                                    
 <!--{elseif $_G['page'] ==4 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad4']}-->                                                                    
 <!--{elseif $_G['page'] ==5 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad5']}-->                                                                    
 <!--{elseif $_G['page'] ==6 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmpcad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmpcad6']}-->                                                                    
										<!--{/if}-->
	
   {eval include  TPLDIR.'/php/atidpic.php';}
<li class="item">
<div class="item-inner y-box">
	<div class="normal{if $xlmmal ==0 || $xlmmal >$_G['cache']['plugin']['xlmm_tt']['xlmmduotu']}{elseif $xlmmal <=$_G['cache']['plugin']['xlmm_tt']['xlmmduotu']} rbox{/if}">
		<div class="rbox-inner">
			<div class="title-box">
				<a href="$thread[url]" class="link">$thread[title]</a>
			</div>
	{if $xlmmal >$_G['cache']['plugin']['xlmm_tt']['xlmmduotu']}<div class="img-list y-box">     				<!--{if $thread[idtype] == 'tid'}-->			
  <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment']; }
		<!--{/if}-->
 <a href="$thread[url]" class="img-wrap"> <img src="$xlmmimg" class="xlmmlazy"> </a>
 	 <!--{eval $i++}-->
<!--{eval if($i==4) break;}-->
<!--{/loop}--> 
	<!--{/if}-->
   					<!--{if $thread[idtype] == 'aid'}-->			
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==4) break;}-->
 <a href="$thread[url]" class="img-wrap"> <img src="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment'].thumb.jpg" class="xlmmlazy"> </a>
<!--{/loop}--> 
	<!--{/if}-->
<span class="img-num">$xlmmal 图</span>     </div>{/if}
    		<div class="y-box footer">
				<div class="y-left">
					<a href="$xlmmfxlh[forumurl]" class="lbtn tag tag-bg-other">$xlmmfxlh[forumname]</a>
					<div class="y-left">
						<a href="home.php?mod=space&amp;uid=$xlmmfxlh[authorid]" class="lbtn media-avatar" target="_blank"><img src="$xlmmfxlh[avatar_middle]"></a>
						<a href="home.php?mod=space&amp;uid=$xlmmfxlh[authorid]" class="lbtn source" target="_blank">&nbsp;$xlmmfxlh[author]&nbsp;&#x22C5;</a><span class="lbtn">&nbsp;$xlmmfxlh[views]次点击&nbsp;&#x22C5;&nbsp;$xlmmfxlh[replies]评论&nbsp;&#x22C5;</span>
					</div>
					<span class="lbtn">&nbsp;$xlmmfxlh[dateline]</span>
					 <!--{if $xlmmfxlh['views'] > 1000}--><span class="lbtn tag-hot">热</span><!--{/if}-->
				</div>
	   					<!--{if $thread[idtype] == 'aid'}-->			
			<div class="y-right">
					<span class="xg1">
					<span class="pipe">|</span>
					<label><a href="portal.php?mod=portalcp&amp;ac=article&amp;op=edit&amp;aid=$thread[id]">{lang edit}</a></label>
					<span class="pipe">|</span>
					<label><a href="portal.php?mod=portalcp&amp;ac=article&amp;op=delete&amp;aid=$thread[id]" id="article_delete_$thread[id]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang delete}</a></label>
					</span>
				</div>
			<!--{/if}-->
		</div>
		</div>
	</div>
{if $xlmmal ==0 || $xlmmal >$_G['cache']['plugin']['xlmm_tt']['xlmmduotu']}
{elseif $xlmmal <=$_G['cache']['plugin']['xlmm_tt']['xlmmduotu']}	
    				<!--{if $thread[idtype] == 'tid'}-->			
  <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment']; }
		<!--{/if}-->
<div class="lbox">
		<a href="$thread[url]" class="img-wrap">
		<img src="$xlmmimg" class="xlmmlazy">
		</a>
	</div>
	 <!--{eval $i++}-->
<!--{eval if($i==1) break;}-->
<!--{/loop}--> 
	<!--{/if}-->
   					<!--{if $thread[idtype] == 'aid'}-->			
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==1) break;}-->
<div class="lbox">
		<a href="$thread[url]" class="img-wrap">
		<img src="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment'].thumb.jpg" class="xlmmlazy">
		</a>
	</div>
<!--{/loop}--> 
	<!--{/if}-->
{/if}
    
</div>
</li>
      <!--{/loop}--> 

 <!--{/if}-->

</ul>
<div id="xlmmpg" style="display:none">$multi</div>
 </div>
</div> 
  </div>
 		<!--{ad/articlelist/mbm hm/3}--><!--{ad/articlelist/mbm hm/4}-->
 </div>


  <div class="y-right index-modules">
    <div class="module-inner" id="module-inner">
  <div class="tt-autocomplete" style="margin-bottom:16px;">
	      <form id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" onSubmit="searchFocus($('scbar_txt'))" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
	<div class="tt-input tt-input-group tt-input-group--append">
 			        <input type="hidden" name="mod" id="scbar_mod" value="{if $_G['basescript'] == 'portal'}<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmsctype']==1 }-->portal<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmsctype']==2 }-->forum<!--{/if}-->{elseif $_G['basescript'] == 'group'}group{else}forum{/if}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="srchtype" value="title" />
        <input type="hidden" name="srhfid" value="" />
        <input type="hidden" name="srhlocality" value="forum::mypage" />
              <input type="hidden" name="searchsubmit" value="yes"/>
<input name="srchtxt" value="" placeholder="输入您要搜索的内容" autocomplete="off" class="tt-input__inner" type="text"><!---->
		<div class="tt-input-group__append">
			<button  type="submit" href="javascript:;" class="tt-button tt-button--default"><span>搜索</span></button>
		</div>
	</div> </form> 
</div>
<div>
	<div class="outer">
                        {if $_G['uid']}
	   <div class="logged inner">
	<div class="top">
		<p class="logout">
			<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}"><span>退出登录</span></a>
		</p>
		<div>
			<a href="home.php?mod=space&uid=$_G[uid]" class="head" target="_blank">{avatar($_G[uid],small)}</a>
			<p class="name">
				<a href="home.php?mod=space&uid=$_G[uid]" target="_blank"><span>{$_G[member][username]}</span></a>
			</p>
		</div>
	</div>
	<ul class="bottom">
		<li><a href="home.php?mod=spacecp&ac=credit" target="_blank">
		<p class="num">$_G[member][credits]</p>
		<br>
		<p class="word">积分</p>
		</a></li>
		<li class="line"></li>
	{eval	
$xlmmposts = getuserprofile('posts');
}	<li><a href="home.php?mod=spacecp&ac=credit" target="_blank">
		<p class="num"><!--{echo dnumber($_G['member']['extcredits2'])}--></p>
		<br>
		<p class="word">金币</p>
		</a></li>
	</ul>
</div>
                     {else}
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmsydl']}-->
                        {/if}
	</div>
</div>
 						<!--{if $_G['setting']['srchhotkeywords']}-->
<div class="module hot-words-pane">
<div class="hot-words-title"><img src="template/xlmm_zx/image/hotsc.png"> <div class="more-hot-words"><a target="_blank" href="search.php">更多<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAeCAYAAAAhDE4sAAAAAXNSR0IArs4c6QAAAVBJREFUSA3N1T1rg0AYB3A1FWkn6Vpa0EEHv0Rp5y4Fty75gl0K3RoCnaWTg4tCuncV61uf/+EVL55J7lzygNxL7vlx8R7VMM424jhe4dLdoInEIAj8tm236Pd9v87z/AN9lbCwuOu6BwJucdHwzff9RxUEaxnkOM4r9XdD8iW1yhiD0jT9sW37fgnG7tGwEyMMQ6+u6y2N74a5ktqnU+6ZACFZF5tAupgU0sFmIVXsIKSCseNHwlxkWVbsl4Zpmu+e572Mc47uiC/GaTZN80nVf4M5whrXda+SJKkxProjLOJBCO9O2pOgUW2x3ZDyS8/nmu8G6sWE3psYIUK1F0UhvCEO3qM5RPbIzEIqCP6EFFJFpJAOMoF0EQFagvxDURRdl2X5RRPCEctOB0myYAVZVdUz/aiNAGYFaVnWhsr/GxPUan2OkMti6QeSO+fT/gGK1tWL9Et9kQAAAABJRU5ErkJggg==" alt="" class="icon_more"></a></div></div> 
<ul class="module-content hot-search">
				  <!--{eval $xlmmsk=1;}-->
			<!--{loop $_G['setting']['srchhotkeywords'] $val}-->
								<!--{if $val=trim($val)}-->
									<!--{eval $valenc=rawurlencode($val);}-->
									<!--{block srchhotkeywords[]}-->
										<!--{if !empty($searchparams[url])}-->
											<li><a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}" target="_blank" sc="1"><i class="search-no search-no-$xlmmsk">$xlmmsk</i><span class="search-text">$val</span></a></li>
										<!--{else}-->
											<li><a href="search.php?mod=<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmsctype']==1 }-->portal<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmsctype']==2 }-->forum<!--{/if}-->&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch" target="_blank" sc="1"><i class="search-no search-no-$xlmmsk">$xlmmsk</i><span class="search-text">$val</span></a></li>
										<!--{/if}-->
									<!--{/block}-->
								<!--{/if}-->
				 <!--{eval $xlmmsk++}-->
			<!--{/loop}-->
							<!--{echo implode('', $srchhotkeywords);}-->
</ul></div>
								<!--{/if}-->

	<!--[diy=xlmm-r]--><div id="xlmm-r" class="area"></div><!--[/diy]-->
      <div class="company">
  <p> &copy; 2019 $_G['setting']['sitename'] $_G['setting']['siteurl']</p>

  <a href="javascript:;" >中国互联网举报中心 </a>
<!--{hook/global_footer}--><!--{hook/global_footerlink}--><!--{if $_G['setting']['statcode']}-->$_G['setting']['statcode']<!--{/if}-->
  <div class="">
<!--{if $_G['setting']['icp']}--><span>备案信息：<a href="http://www.miibeian.gov.cn/" target="_blank">$_G['setting']['icp']</a></span> <!--{/if}-->
  </div>
  <p>非经营性网站-2019</p>

  <span>违法和不良信息举报：010-12321</span><span>广告合作客服QQ：$_G['setting']['site_qq']</span>
  <a href="javascript:;"><img src="$_G['style']['styleimgdir']/gon.png">公安网备信息中心</a>
<span>Powered by&nbsp;<a href="http://t.cn/Aiux1eta" target="_blank">DisM.Taobao.Com!</a>$_G['setting']['version']&nbsp;&nbsp;<a href="http://t.cn/Aiux1Jx1" target="_blank">DISM.TAOBAO.COM.</a></span></div>
	<!--[diy=xlmm-rf]--><div id="xlmm-rf" class="area"></div><!--[/diy]-->
               <div id="fixeds"></div>
 </div>
  </div>
</div>


	<!--[diy=xlmm-f]--><div id="xlmm-f" class="area"></div><!--[/diy]-->

    </div>


<script type="text/javascript" reload="1">

var ias = jQuery.ias({
   container: "#alist", 
        item: ".item", 
        pagination: ".pg", 
        next: ".pg a.nxt", 
    });
    ias.extension(new IASTriggerExtension({
        text: '<div class="ias-spinner" style="text-align: center;line-height:40px;color: #999;">点击加载更多</div>', 
        offset: false, 
    }));
    ias.extension(new IASSpinnerExtension({
	html: '<div class="ias-spinner" style="text-align: center;line-height:40px;color: #999;"><img src="static/image/common/loading.gif" width="16" height="16" class="vm" /> 载入中...</div>',
}));
    ias.extension(new IASNoneLeftExtension({
        text: '<div style=" text-align:center; line-height:40px;color: #999;">没有更多了</div>', 
    }));


var navs = $('fthread');
var navsoffset = parseInt(fetchOffset(navs)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop >= navsoffset){
	if (BROWSER.ie && BROWSER.ie < 7) {
		navs.style.position = 'absolute';
		navs.style.top = xlmmm_scrollTop + 'px';
	}else{
		navs.style.position = 'fixed';
		navs.style.top = '10px';
	}
}else{
	navs.style.position = 'static';
		navs.style.top = xlmmm_scrollTop + 'px';
}
});


var userfix = $('fixeds');
var userfixoffset = parseInt(fetchOffset(userfix)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop + 50 >= userfixoffset){
if (BROWSER.ie && BROWSER.ie < 7) {
userfix.style.position = 'absolute';
userfix.style.top = xlmmm_scrollTop + 'px';
}else{
userfix.innerHTML  = '<style>.hotNews{ position:fixed; top:0px; width:340px;z-index:99;}</style>';
}
}else{
userfix.innerHTML  = '<style>.hotNews{ position:static;}</style>';
}
});


jQuery(document).ready(function() {
jQuery("img.xlmmlazy").lazyload();
});

</script>
<!--{template common/tt_footer}-->



