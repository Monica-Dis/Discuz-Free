<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
					<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
<!--{template common/header}-->
    <!--{if in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
<style>
body {background: #fff !important;}
 .wp { width:1170px !important;}
.feedBox .wcommonFeed .item-inner {
	padding: 10px 0 !important;
	border-bottom: 1px solid #e8e8e8 !important;
}
.pg strong {
	background-color: #ed4040;
}
#fixed { margin-top:16px}#fixed .hide, #fixed .hides{ display: block ;}
.msgAlert { margin-bottom:10px;height: 33px;	line-height: 32px;	font-size: 14px;	color: #fff;	text-align: center;	background-color: #60a3f5;	background-color: rgba(96,163,245,.85);	z-index: 20;	-webkit-transition-property: height;	transition-property: height;	-webkit-transition-delay: 0;	transition-delay: 0;	-webkit-transition-duration: .5s;	transition-duration: .5s;}
 .list-refresh-msg { margin-bottom:10px;text-align: center;	font-size: 14px; display:block;color: #2A90D7;	height: 32px;	line-height: 32px;	background: #2A90D7;	background: rgba(41,144,215,.08);	border: 1px solid #2A90D7;	border: 1px solid rgba(41,144,215,.5);	border-radius: 4px;	cursor: pointer;}

.tt-input {position: relative;font-size: 14px;display: inline-block;width: 100%;}
.tt-input-group {line-height: normal;display: inline-table;width: 100%;border-collapse: separate;}
.search-wrap .tt-input__inner {height: 44px;}
.tt-input-group--append .tt-input__inner, .tt-input-group__prepend {border-top-right-radius: 0;border-bottom-right-radius: 0;}
.tt-input-group > .tt-input__inner {vertical-align: middle;display: table-cell;}
.tt-input__inner, .tt-select-dropdown, .tt-select-dropdown__item, .tt-select .tt-tag, .tt-tag, .tt-textarea__inner {box-sizing: border-box;}
.tt-input__inner {-webkit-appearance: none;-moz-appearance: none;appearance: none;background-color: #f5f6f7;border-radius: 4px;border-top-right-radius: 4px;border-bottom-right-radius: 4px;border: 1px solid #e8e8e8;color: #1f2d3d;display: block;font-size: inherit;height: 40px;outline: 0;padding: 3px 10px;transition: border-color .2s cubic-bezier(.645,.045,.355,1);width: 100%;}
.tt-input__inner, .tt-textarea__inner {background-image: none;box-sizing: border-box;}
button, input, select, textarea {font-family: inherit;font-size: inherit;line-height: inherit;}

.tt-input-group__append .tt-button, .tt-input-group__append .tt-input, .tt-input-group__prepend .tt-button, .tt-input-group__prepend .tt-input {font-size: inherit;}
.tt-input-group__append .tt-button, .tt-input-group__append .tt-select .tt-input__inner, .tt-input-group__append .tt-select:hover .tt-input__inner, .tt-input-group__prepend .tt-button, .tt-input-group__prepend .tt-select .tt-input__inner, .tt-input-group__prepend .tt-select:hover .tt-input__inner {border-color: transparent;border-top-color: transparent;border-bottom-color: transparent;background-color: transparent;color: inherit;border-top: 0;border-bottom: 0;}
.tt-input-group__append .tt-button, .tt-input-group__append .tt-select, .tt-input-group__prepend .tt-button, .tt-input-group__prepend .tt-select {display: block;margin: -10px;}
[type="reset"], [type="submit"], button, html [type="button"] {-webkit-appearance: button;}
.tt-button, .tt-button-group, .tt-dropdown {display: inline-block;}
.tt-button {display: inline-block;line-height: 1;white-space: nowrap;cursor: pointer;background: #fff;background-color: rgb(255, 255, 255);border: 1px solid #bfcbd9;border-top-width: 1px;border-bottom-width: 1px;border-top-style: solid;border-bottom-style: solid;border-top-color: rgb(191, 203, 217);border-right-color: rgb(191, 203, 217);border-bottom-color: rgb(191, 203, 217);border-left-color: rgb(191, 203, 217);color: #1f2d3d;-webkit-appearance: none;text-align: center;box-sizing: border-box;outline: 0;margin: 0;-moz-user-select: none;-webkit-user-select: none;-ms-user-select: none;padding: 10px 15px;font-size: 14px;border-radius: 4px;}
.tt-autocomplete .tt-input-group__append {border: 1px solid #208eda;background-color: #208eda;color: #fff;position: relative;left: -1px;padding: 0 18px;}
.tt-input-group__append {border-left: 0;}
.tt-input-group--prepend .tt-input__inner, .tt-input-group__append {border-top-left-radius: 0;border-bottom-left-radius: 0;}
.tt-input-group__append, .tt-input-group__prepend {color: #97a8be;vertical-align: middle;display: table-cell;position: relative;border: 1px solid #e8e8e8;border-radius: 4px;border-top-left-radius: 4px;border-bottom-left-radius: 4px;padding: 0 10px;width: 1%;white-space: nowrap;}

</style>
 <script src="$_G['style']['styleimgdir']/xlmm.js" type="text/javascript"></script>
<!--{else}-->
<!--{/if}-->
<link rel="stylesheet" href="template/xlmm_zx/image/forumdisplay.css" />
<!--{if $_G['forum']['ismoderator']}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->
<!--{ad/text/wp a_t}-->
</div>
<style id="diy_style" type="text/css"></style>
<div class="wp">
<!--[diy=bg]--><div id="bg" class="area"></div><!--[/diy]-->
</div>

    <!--{if !in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
<div class="head">
<div class="head-banner">
    <div class="baner-bg">
        <img id="header_banner_bg"{if $_G[forum][banner] && !$subforumonly}$_G[forum][banner] style=" filter: url(blur.svg#blur); /* FireFox, Chrome, Opera */ -webkit-filter: blur({$_G['style']['电脑版版块顶部图片模糊度，默认为3，数值越大越模糊。']}px); /* Chrome, Opera */ -moz-filter: blur({$_G['style']['电脑版版块顶部图片模糊度，默认为3，数值越大越模糊。']}px);-ms-filter: blur({$_G['style']['电脑版版块顶部图片模糊度，默认为3，数值越大越模糊。']}px);filter: blur({$_G['style']['电脑版版块顶部图片模糊度，默认为3，数值越大越模糊。']}px);filter: progid:DXImageTransform.Microsoft.Blur(PixelRadius={$_G['style']['电脑版电脑版版块顶部图片模糊度，默认为3，数值越大越模糊。']}, MakeShadow=false); width:100% /* IE6~IE9 */"{else} style="width:100%"{/if} src="{if $_G[forum][banner] && !$subforumonly}$_G[forum][banner]{else}template/xlmm_zx/image/banner.jpg{/if}" height="220">
    </div>
    <div class="overlay"></div>
    <div class="head-banner-container">
    
    <div class="container">
        
        <div class="row">
            <div class="col-2">
                <div class="pic">
                    <a class="st_qrcode" id="qr-cs"  onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'','pos':'!'})" href="javascript:;"></a>
                     <div id="qr-cs_menu" style="display: none;background:#fff; width:160px;">
                   <div class="hjqrcode " style="padding:0 8px 8px 8px;">
                        <div class="qrcode_name">手机逛社区</div>
                        <div class="qrcode" id="qrcode"></div>
                        <img class="qrcode_icon" src="{$_G['style']['版块图标右下角弹出二维码中间的小图标']}">
                    </div>
                    </div>
                  
                    <a href="forum.php?mod=forumdisplay&fid=$_G[fid]" title="$_G['forum'][name]">
                        <img src="{if $_G[forum][icon]}data/attachment/common/$_G['forum']['icon']{else}template/xlmm_zx/image/icon.png{/if}" alt="$_G['forum'][name]">
                    </a>
                </div>
            </div>
            <div class="col-8">
                <div class="ftitle">
                    <a href="forum.php?mod=forumdisplay&fid=$_G[fid]"><span id="headLeagueName" class="title_text">$_G['forum'][name]</span></a>
                    <span class="z"><a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" id="a_favorite" class="fa_fav" onclick="showWindow(this.id, this.href, 'get', 0);">{lang forum_favorite} <i id="number_favorite" {if !$_G[forum][favtimes]} style="display:none;"{/if}>(<span id="number_favorite_num">$_G[forum][favtimes]</span>)</i></a> | &nbsp;总贴量 （$_G[forum][threads]）</span>

                </div>
                <div class="info cf">
                    <div class="user_info_box z">

                        <p>位置：<a href="./" title="{lang homepage}">首页</a><em>&rsaquo;</em><a href="forum.php">{$_G[setting][navs][2][navname]}</a>$navigation
                     					&nbsp;&nbsp;<span>
						<!--{if !empty($forumarchive)}-->
							<a id="forumarchive" href="javascript:;" class="fa_achv" onmouseover="showMenu(this.id)"><!--{if $_GET['archiveid']}-->$forumarchive[$_GET['archiveid']]['displayname']<!--{else}-->{lang forum_archive}<!--{/if}--></a>
						<!--{/if}-->
						<!--{hook/forumdisplay_forumaction}-->

						<!--{if $_G['forum']['ismoderator']}-->
						<!--{if $_G['forum']['recyclebin']}-->
							<span class="pipe">|</span><a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" class="fa_bin" target="_blank">{lang forum_recyclebin}</a>
						<!--{/if}-->
						<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->
							<span class="pipe">|</span><strong>
							<!--{if $_G['forum']['status'] != 3}-->
								<a href="forum.php?mod=modcp&fid=$_G[fid]">{lang modcp}</a>
							<!--{else}-->
								<a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang modcp}</a>
							<!--{/if}-->
							</strong>
						<!--{/if}-->
						<!--{hook/forumdisplay_modlink}-->
						<!--{/if}-->
					</span>
   </p>
                        <p>版主：{if $moderatedby}$moderatedby{else}<a href="{$_G['style']['申请版主链接']}" target="_blank">暂时还没有版主哦</a>{/if} </p>
                           <div class="summary"{if $xlmmdsu} style="width:615px; overflow:hidden"{/if}>{if $_G['forum']['description']}$_G['forum']['description']{else}本版暂无版块简介{/if}</div>
                    </div>
                    
                    
{if $_G['cache']['plugin']['dsu_paulsign']['ifopen']}
                    <div class="y">
                        
<!--{template common/qiandao}-->
                    </div>
{/if}
                    

                </div>

            </div>
        </div>
        
    </div>
        </div>
</div>
</div>
<!--{/if}-->


	     <div class="wp">
					<!--{hook/forumdisplay_postbutton_top}-->
<div class="boardnav boardnavs">
	<div id="ct" class="wp cl ct2 container">
	    <!--{if in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
					<div id="sd_bdl" class="z index-channel">
 <!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttnav'] == 1}-->
	<style>
.wchannel-item a {
    display: inline-block;
    font-size: 16px; color:#444 !important;
}
.wchannel-item.active a{
	color: #fff !important;
}
.wchannel-item span{ display:none;}
.wchannel-item:hover a{
	color: #fff !important;
}

</style>

<div class="wchannel " id="fthread"> 
    <a class="logo" href="./"> <img src="template/xlmm_zx/portal/list/logo.png"> </a> 
    <ul> 
					<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="wchannel-item active" {else}class="wchannel-item" {/if}$nav[nav]></li><!--{/if}-->
						<!--{/loop}-->
 </ul> 
 
 </div>
  <div class="none"> 
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
	<!--[diy=xlmm-l]--><div id="xlmm-l" class="area"></div><!--[/diy]-->
					<!--{/if}-->
 </div>
 <!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttnav'] == 2}-->
	<!--[diy=xlmm-l]--><div id="xlmm-l" class="area"></div><!--[/diy]-->
  <!--{/if}-->
  				</div>
      <!--{else}-->
	<!--{if $leftside}-->
			<div id="sd_bdl" class="bdl" onmouseover="showMenu({'ctrlid':this.id, 'pos':'dz'});" style="width:{$_G['setting']['leftsidewidth']}px;margin-left:-{$_G['leftsidewidth_mwidth']}px">
				<!--{hook/forumdisplay_leftside_top}-->
				<!--[diy=diyleftsidetop]--><div id="diyleftsidetop" class="area"></div><!--[/diy]-->

				<div class="tbn" id="forumleftside">
					<!--{subtemplate forum/forumdisplay_leftside}-->
				</div>

				<!--[diy=diyleftsidebottom]--><div id="diyleftsidebottom" class="area"></div><!--[/diy]-->
				<!--{hook/forumdisplay_leftside_bottom}-->
			</div>
		<!--{/if}-->
		<!--{/if}-->
		<div class="mn" style="background:#FFFFFF; width:<!--{if in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->660px;<!--{else}-->908px<!--{/if}-->">
		    <!--{if in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
    <!--{else}-->
	   <!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
		   	<!--{if !empty($_G['forum']['recommendlist'])}-->
<h3 class="modname">推荐阅读</h3>
<!--{if $_G['forum']['recommendlist']['images'] && $_G['forum']['modrecommend']['imagenum']}-->
<div class="xlmm-recommend" style=" margin-left:25px">
<ul>
		<!--{loop $_G['forum']['recommendlist']['images'] $k $imginfo}-->
<li><a href="forum.php?mod=viewthread&tid=$imginfo[tid]"  target="_blank" title="$imginfo[subject]"><img src="$imginfo[filename]" alt="$imginfo[subject]" height="100" width="219"></a></li>
		<!--{/loop}-->

</ul>
</div>
<!--{/if}-->

	<!--{eval unset($_G['forum']['recommendlist']['images']);}-->
<div class="recommend_xlmm">
<ul>
	<!--{loop $_G['forum']['recommendlist'] $rtid $recommend}-->
<li><a href="forum.php?mod=viewthread&tid=$rtid" $recommend[subjectstyles] target="_blank"><em>●</em>$recommend[subject]</a></li>
		<!--{/loop}-->
</ul>
</div>
	<style>
.modname {font-weight: 700;line-height: 53px;overflow: hidden;color: #3f3f3f;font-size: 16px;height: 50px; margin-left:25px}
.xlmm-recommend::before, .recommend_xlmm::before{display: table;content: "";line-height: 0;}
.xlmm-recommend ul {margin-right: -18px;}
.xlmm-recommend li {float:left;margin-right:18px;padding-bottom:20px}
.xlmm-recommend img{display: block;border-radius: 2px;}
.xlmm-recommend::after, .recommend_xlmm::after{clear: both;display: table;content: "";line-height: 0;}
.recommend_xlmm {margin:0 25px;padding:0 0 20px}
.recommend_xlmm ul {margin-right:-40px}
.recommend_xlmm li {float:left;width:300px;margin-right:40px;line-height:30px;white-space: nowrap;}
.recommend_xlmm em {margin-right:8px}
.recommend_xlmm span {margin-right:5px}
</style>
		<!--{/if}-->

<div class="star_nav_wrap star_nav_wrap_platform ">
<ul class="star_class_nav clearfix">
<li class="star_nav_tab{if $filter==digest || $_GET[specialtype]==poll || $_GET[specialtype]==activity || $_GET[specialtype]==reward || $_GET[specialtype]==trade || $_GET[specialtype]==poll || $_GET[specialtype]==debate || $_GET[orderby]==heats}{else} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="star_nav_ico kantie"><i class="icon"></i>看贴</a></div></div></li>
<li class="star_nav_tab{if $filter==digest} newfocus{/if} "><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1" class="star_nav_ico jingpin" target="_blank"><i class="icon"></i>精品</a></div></div></li>
<!--{if $showactivity}--><li class="star_nav_tab{if $_GET[specialtype]==activity} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity" class="star_nav_ico huodon" target="_blank"><i class="icon"></i>活动</a></div></div></li><!--{/if}-->
<!--{if $showreward}--><li class="star_nav_tab{if $_GET[specialtype]==reward} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward" class="star_nav_ico xuanshang" target="_blank"><i class="icon"></i>悬赏</a></div></div></li><!--{/if}-->
<!--{if $showtrade}--><li class="star_nav_tab{if $_GET[specialtype]==trade} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade" class="star_nav_ico shangpin" target="_blank"><i class="icon"></i>商品</a></div></div></li><!--{/if}-->
<!--{if $showpoll}--><li class="star_nav_tab{if $_GET[specialtype]==poll} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll" class="star_nav_ico toupiao" target="_blank"><i class="icon"></i>投票</a></div></div></li><!--{/if}-->
<!--{if $showdebate}--><li class="star_nav_tab{if $_GET[specialtype]==debate} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate" class="star_nav_ico bianlun" target="_blank"><i class="icon"></i>辩论</a></div></div></li><!--{/if}-->
                        </ul>         
</div>
<div class="clearfix"></div>
   <!--{/if}-->
   <div class="oneway_text graybottomborder">
<div style="margin-top:16px" id="atarget" {if $_G['cookie']['atarget'] > 0}onclick="setatarget(-1)" class="atarget_1"{else}onclick="setatarget(1)" {/if} title="{lang new_window_thread}" ><i></i>新窗</div> 
{if empty($_G['forum']['picstyle'])} {else}<div style="float:right; margin-top:16px; margin-right:13px" ><a{if empty($_G['cookie']['forumdefstyle'])} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="chked"{else} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="unchk"{/if} title="{lang view_thread_imagemode}{lang view_thread}">瀑布流</a>
</div> {/if}
<ul style="padding-top:15px\9">
<li ><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xi2{if $_GET['filter'] == 'lastpost'} xw1{/if}"><i class="newthead"></i>最新</a></li>
<li ><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xi2{if $_GET['filter'] == 'heat'} xw1{/if}"><i class="lastthead"></i>热门</a></li>
<li ><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=hot" class="xi2{if $_GET['filter'] == 'hot'} xw1{/if}"><i class="hotthead"></i>热帖</a></li>
<li ><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="xi2{if $_GET['filter'] == 'digest'} xw1{/if}"><i class="verythead"></i>精华</a></li>
<li ><a id="filter_dateline" href="javascript:;" class="showmenu xi2{if $_GET['dateline']} xw1{/if}" onclick="showMenu(this.id)">更多</a></li>
</ul>
</div>
<div class="clearfix"></div>
<style>
.oneway_text {margin:0 25px;border-bottom: 1px solid #f1f1f1;color: #9f9f9f;line-height: 50px;height: 50px;}
#atarget, #threadthumb {cursor: pointer;float: right;color: #afafaf;}
.oneway_text li {float:left;margin-right:23px}
.oneway_text li a{ color: #9f9f9f;font: 14px/1.5 "Helvetica Neue", Arial,"Hiragino Sans GB", "STHeiti", "Microsoft Yahei","SimSun", "WenQuanYi Micro Hei",sans-serif;}
.oneway_text li a.xw1{color: #666;font: 14px/1.5 "Helvetica Neue", Arial,"Hiragino Sans GB", "STHeiti", "Microsoft Yahei","SimSun", "WenQuanYi Micro Hei",sans-serif;}
</style>
				<!--{/if}-->
			<!--{hook/forumdisplay_top}-->


		    <!--{if in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
	<div class="drag">
	<!--[diy=xlmm-hd]--><div id="xlmm-hd" class="area"></div><!--[/diy]-->
			</div>
				<!--{/if}-->

			<!--{hook/forumdisplay_middle}-->

			<!--{if !$subforumonly}-->
    <!--{if !in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
				<!--{if $recommendgroups && !$_G['forum']['allowside']}-->
				<div class="bm bmw fl{if $_G['forum']['forumcolumns']} flg{/if}">
					<div class="bm_h cl">
						<span class="o"><img id="recommendgroups_{$_G[forum][fid]}_img" src="{IMGDIR}/$collapseimg[recommendgroups]" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('recommendgroups_{$_G[forum][fid]}');" /></span>
						<h2>{lang recommended_groups}</h2>
					</div>
					<div class="bm_c" id="recommendgroups_{$_G[forum][fid]}" style="$collapse[recommendgroups]">
						<table cellspacing="0" cellpadding="0" class="fl_tb">
							<!--{loop $recommendgroups $key $group}-->
							<!--{if $_G['forum']['forumcolumns']}-->
								<!--{if $key && ($key % $_G['forum']['forumcolumns'] == 0)}-->
									</tr>
									<!--{if $key < $_G['forum']['forumcolumns']}-->
										<tr class="fl_row">
									<!--{/if}-->
								<!--{/if}-->
								<td class="fl_g">
									<div class="fl_icn_g">
										<a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]" target="_blank"><img src="$group[icon]" alt="$group[name]" width="32" /></a>
									</div>
									<dl>
										<dt><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><span class="xg1 xw0"> ($group[membernum] {lang activity_member_unit})</span>
										<dd><em>{lang forum_threads}: $group[threads]</em></dd>
										<dd>
											<!--{if is_array($group['lastpost'])}-->
												<!--{if $_G['forum']['forumcolumns'] < 3}-->
												<a href="forum.php?mod=redirect&tid=$group[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($group[lastpost][subject], 30)}--></a> <cite>$group[lastpost][dateline] <!--{if $group['lastpost']['author']}--><a href="home.php?mod=space&username={$group[lastpost][encode_author]}">{$group[lastpost][author]}</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>
												<!--{else}-->
													<a href="forum.php?mod=redirect&tid=$group[lastpost][tid]&goto=lastpost#lastpost" class="xi2">$group[lastpost][dateline]</a>
												<!--{/if}-->				<!--{else}-->
											{lang never}
											<!--{/if}-->
										</dd>
									</dl>
								</td>
							<!--{else}-->
								<tr {if $key != 0}class="fl_row"{/if}>
									<td class="fl_icn">
										<a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]" target="_blank"><img src="$group[icon]" alt="$group[name]" width="32" /></a>
									</td>
									<td>
										<h2><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><span class="xg1 xw0"> ($group[membernum] {lang activity_member_unit})</span></h2>
										<p><!--{echo cutstr($group[description], 100)}--></p>
									</td>
									<td class="fl_i">
										<span class="xi2">$group[threads] {lang index_threads}</span>
									</td>
									<td class="fl_by">
										<div>
											<!--{if is_array($group['lastpost'])}-->
											<a href="forum.php?mod=redirect&tid=$group[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($group[lastpost][subject], 30)}--></a> <cite>$group[lastpost][dateline] <!--{if $group['lastpost']['author']}--><a href="home.php?mod=space&username={$group[lastpost][encode_author]}">{$group[lastpost][author]}</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>
											<!--{else}-->
											{lang never}
											<!--{/if}-->
										</div>
									</td>
								</tr>
							<!--{/if}-->
							<!--{/loop}-->
						</table>
					</div>
				</div>
				<!--{/if}-->

				<!--{if $threadmodcount}--><div class="bm"><div class="ntc_l hm xi2"><strong>{lang forum_moderate_unhandled}</strong></div></div><!--{/if}-->
	<style type="text/css">
.listUser a {
    padding-left: 20px; margin-right:10px;
    background: url(template/xlmm_zx/image/icon_author.png) 0 0 no-repeat;
    color: #999;
}
</style>
			            <!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}--><!--{if $livethread}-->
					<div id="livethread" class="tl bm bmw cl" style="padding:10px 10px 10px 80px; position:relative; background:#FFFFFF">
                        <div class="live_reply">					<!--{if $livethread['authorid'] && $livethread['author']}-->
						<a href="home.php?mod=space&uid=$livethread[authorid]"><!--{avatar($livethread[authorid],small)}--></a>
					<!--{else}-->
						<img src="$_G['style']['styleimgdir']/hidden.gif" title="$_G[setting][anonymoustext]" alt="$_G[setting][anonymoustext]" />
					<!--{/if}-->
</div>
                        
						<div class="livethreadtitle vm">
							<span class="replynumber xg1">{lang reply} <span id="livereplies" class="xi1">$livethread[replies]</span></span>
				 <img src="$_G['style']['styleimgdir']/live.gif" style="margin-right:8px;" /><a href="forum.php?mod=viewthread&tid=$livethread[tid]" target="_blank" class="xst">$livethread[subject]</a>
		<span class="listUser y">
				<a href="home.php?mod=space&uid=$livethread[authorid]" c="1" target="_blank" style="color:#1D53BF;font-size:14px; color:#999999">$livethread[author]</a>
				                    </span>
						</div>
						<div class="livethreadcon">$livemessage</div>
						<div id="livereplycontentout">
							<div id="livereplycontent">
							</div>
						</div>
						<div id="liverefresh">{lang forum_live_newreply_refresh}</div>
						<div id="livefastreply">
							<form id="livereplypostform" method="post" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$livethread[tid]&replysubmit=yes&infloat=yes&handlekey=livereplypost&inajax=1" onsubmit="return livereplypostvalidate(this)">
								<div id="livefastcomment">
									<textarea id="livereplymessage" name="message" style="color:gray;<!--{if !$liveallowpostreply}-->display:none;<!--{/if}-->">{lang forum_live_fastreply_notice}</textarea>
									<!--{if !$liveallowpostreply}-->
										<div>
											<!--{if !$_G[uid]}-->
												{lang login_to_reply} <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)" class="xi2">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}" class="xi2">$_G['setting']['reglinkname']</a>
											<!--{else}-->
												{lang no_permission_to_post}<a href="javascript:;" onclick="ajaxpost('livereplypostform', 'livereplypostreturn', 'livereplypostreturn', 'onerror', $('livereplysubmit'));" class="xi2">{lang click_to_show_reason}</a>
											<!--{/if}-->
										</div>
									<!--{/if}-->
								</div>
								<div id="livepostsubmit" style="display:none;">
								<!--{if $secqaacheck || $seccodecheck}-->
									<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id)"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
									<div class="mtm sec" style="text-align:right;"><!--{subtemplate common/seccheck}--></div>
								<!--{/if}-->
								<p class="ptm pnpost" style="margin-bottom:10px;">
								<button type="submit" name="replysubmit" class="pn pnc vm" style="float:right;" value="replysubmit" id="livereplysubmit">
									<strong>{lang forum_live_post}</strong>
								</button>
								</p>
								</div>
								<input type="hidden" name="formhash" value="{FORMHASH}">
								<input type="hidden" name="subject" value="  ">
							</form>
						</div>
						<span id="livereplypostreturn"></span>
					</div>
					<script type="text/javascript">
						var postminchars = parseInt('$_G['setting']['minpostsize']');
						var postmaxchars = parseInt('$_G['setting']['maxpostsize']');
						var disablepostctrl = parseInt('{$_G['group']['disablepostctrl']}');
						var replycontentlist = new Array();
						var addreplylist = new Array();
						var timeoutid = timeid = movescrollid = waitescrollid = null;
						var replycontentnum = 0;
						getnewlivepostlist(1);
						timeid = setInterval(getnewlivepostlist, 5000);
						$('livereplycontent').style.position = 'absolute';
						$('livereplycontent').style.width = ($('livereplycontentout').clientWidth - 50) + 'px';
						$('livereplymessage').onfocus = function() {
							if(this.style.color == 'gray') {
								this.value = '';
								this.style.color = 'black';
								$('livepostsubmit').style.display = 'block';
								this.style.height = '56px';
								$('livefastcomment').style.height = '57px';
							}
						};
						$('livereplymessage').onblur = function() {
							if(this.value == '') {
								this.style.color = 'gray';
								this.value = '{lang forum_live_fastreply_notice}';
							}
						};

						$('liverefresh').onclick = function() {
							$('livereplycontent').style.position = 'absolute';
							getnewlivepostlist();
							this.style.display = 'none';
						};

						$('livereplycontentout').onmouseover = function(e) {

							if($('livereplycontent').style.position == 'absolute' && $('livereplycontent').clientHeight > 215) {
								$('livereplycontent').style.position = 'static';
								this.scrollTop = this.scrollHeight;
							}

							if(this.scrollTop + this.clientHeight != this.scrollHeight) {
								clearInterval(timeid);
								clearTimeout(timeoutid);
								clearInterval(movescrollid);
								timeid = timeoutid = movescrollid = null;

								if(waitescrollid == null) {
									waitescrollid = setTimeout(function() {
										$('liverefresh').style.display = 'block';
									}, 60000 * 10);
								}
							} else {
								clearTimeout(waitescrollid);
								waitescrollid = null;
							}
						};

						$('livereplycontentout').onmouseout = function(e) {
							if(this.scrollTop + this.clientHeight == this.scrollHeight) {
								$('livereplycontent').style.position = 'absolute';
								clearInterval(timeid);
								timeid = setInterval(getnewlivepostlist, 10000);
							}
						};

						function getnewlivepostlist(first) {
							var x = new Ajax('JSON');
							x.getJSON('forum.php?mod=misc&action=livelastpost&fid=$livethread[fid]', function(s, x) {
								var count = s.data.count;
								$('livereplies').innerHTML = count;
								var newpostlist = s.data.list;
								for(i in newpostlist) {
									var postid = i;
									var postcontent = '';
									postcontent += newpostlist[i].authorid ? '<dt><a href="home.php?mod=space&uid=' + newpostlist[i].authorid + '" target="_blank">' + newpostlist[i].avatar + '</a></dt>' : '<dt></dt>';
									postcontent += newpostlist[i].authorid ? '<dd><a href="home.php?mod=space&uid=' + newpostlist[i].authorid + '" target="_blank">' + newpostlist[i].author + '</a></dd>' : '<dd>' + newpostlist[i].author + '</dd>';
									postcontent += '<dd>' + htmlspecialchars(newpostlist[i].message) + '</dd>';
									postcontent += '<dd class="dateline">' + newpostlist[i].dateline + '</dd>';
									if(replycontentlist[postid]) {
										$('livereply_' + postid).innerHTML = postcontent;
										continue;
									}
									addreplylist[postid] = '<dl id="livereply_' + postid + '">' + postcontent + '</dl>';
								}
								if(first) {
									for(i in addreplylist) {
										replycontentlist[i] = addreplylist[i];
										replycontentnum++;
										var div = document.createElement('div');
										div.innerHTML = addreplylist[i];
										$('livereplycontent').appendChild(div);
										delete addreplylist[i];
									}
								} else {
									livecontentfacemove();
								}
							});
						}

						function livecontentfacemove() {
							//note 从队列中取出数据
							var reply = '';
							for(i in addreplylist) {
								reply = replycontentlist[i] = addreplylist[i];
								replycontentnum++;
								delete addreplylist[i];
								break;
							}
							if(reply) {
								var div = document.createElement('div');
								div.innerHTML = reply;
								var oldclientHeight = $('livereplycontent').clientHeight;
								$('livereplycontent').appendChild(div);
								$('livereplycontentout').style.overflowY = 'hidden';
								$('livereplycontent').style.bottom = oldclientHeight - $('livereplycontent').clientHeight + 'px';

								if(replycontentnum > 20) {
									$('livereplycontent').removeChild($('livereplycontent').firstChild);
									for(i in replycontentlist) {
										delete replycontentlist[i];
										break;
									}
									replycontentnum--;
								}

								if(!movescrollid) {
									movescrollid = setInterval(function() {
										if(parseInt($('livereplycontent').style.bottom) < 0) {
											$('livereplycontent').style.bottom =
												((parseInt($('livereplycontent').style.bottom) + 5) > 0 ? 0 : (parseInt($('livereplycontent').style.bottom) + 5)) + 'px';
										} else {
											$('livereplycontentout').style.overflowY = 'auto';
											clearInterval(movescrollid);
											movescrollid = null;
											timeoutid = setTimeout(livecontentfacemove, 1000);
										}
									}, 100);
								}
							}
						}

						function livereplypostvalidate(theform) {
							var s;
							if(theform.message.value == '' || $('livereplymessage').style.color == 'gray') {
								s = '{lang forum_live_nocontent_error}';
							}
							if(!disablepostctrl && ((postminchars != 0 && mb_strlen(theform.message.value) < postminchars) || (postmaxchars != 0 && mb_strlen(theform.message.value) > postmaxchars))) {
								s = {lang forum_live_nolength_error};
							}
							if(s) {
								showError(s);
								doane();
								$('livereplysubmit').disabled = false;
								return false;
							}
							$('livereplysubmit').disabled = true;
							theform.message.value = theform.message.value.replace(/([^>=\]"'\/]|^)((((https?|ftp):\/\/)|www\.)([\w\-]+\.)*[\w\-\u4e00-\u9fa5]+\.([\.a-zA-Z0-9]+|\u4E2D\u56FD|\u7F51\u7EDC|\u516C\u53F8)((\?|\/|:)+[\w\.\/=\?%\-&~`@':+!]*)+\.(jpg|gif|png|bmp))/ig, '$1[img]$2[/img]');
							theform.message.value = parseurl(theform.message.value);
							ajaxpost('livereplypostform', 'livereplypostreturn', 'livereplypostreturn', 'onerror', $('livereplysubmit'));
							return false;
						}

						function succeedhandle_livereplypost(url, msg, param) {
							$('livereplymessage').value = '';
							$('livereplycontent').style.position = 'absolute';
							if(param['sechash']) {
								updatesecqaa(param['sechash']);
								updateseccode(param['sechash']);
							}
							getnewlivepostlist();
						}
					</script>
				<!--{/if}-->
			<!--{/if}-->

				<!--{/if}-->
				<!--{hook/forumdisplay_threadtype_extra}-->
				<!--{if empty($_G['forum']['sortmode'])}-->
					<!--{subtemplate forum/forumdisplay_list}-->
				<!--{else}-->
					<!--{subtemplate forum/forumdisplay_sort}-->
				<!--{/if}-->
			<!--{/if}-->
			<!--[diy=diyfastposttop]--><div id="diyfastposttop" class="area"></div><!--[/diy]-->
	    <!--{if !in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
		<!--{if $fastpost}-->
				<!--{template forum/forumdisplay_fastpost}-->
			<!--{/if}-->
			<!--{/if}-->
			<!--{hook/forumdisplay_bottom}-->
			<!--[diy=diyforumdisplaybottom]--><div id="diyforumdisplaybottom" class="area"></div><!--[/diy]-->
		</div>

		<div id="side" class="side index-modules">
<!--{hook/forumdisplay_side_top}-->
    <!--{if in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->

    <div class="module-inner" id="module-inner">
  <div class="tt-autocomplete" style="margin-bottom:16px;">
	      <form id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" onSubmit="searchFocus($('scbar_txt'))" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
	<div class="tt-input tt-input-group tt-input-group--append">
 			        <input type="hidden" name="mod" id="scbar_mod" value="{if $_G['basescript'] == 'portal'}portal{elseif $_G['basescript'] == 'group'}group{else}forum{/if}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="srchtype" value="title" />
        <input type="hidden" name="srhfid" value="" />
        <input type="hidden" name="srhlocality" value="forum::mypage" />
              <input type="hidden" name="searchsubmit" value="yes"/>
<input name="srchtxt" value="" placeholder="输入您要搜索的内容" autocomplete="off" class="tt-input__inner" type="text"><!---->
		<div class="tt-input-group__append">
			<button  type="submit" href="javascript:;" class="tt-button tt-button--default"><span>搜索</span></button>
		</div>
	</div> </form> 
</div>

<style type="text/css">
.container .index-modules .module-inner .report {display: block;padding: 12px 22px;background-color: #F4F5F6;margin-bottom: 16px;}
.container .index-modules .module-inner .report .img-holder {width: 57px;height: 50px; display:block;}
.container .index-modules .module-inner .report .img-holder > img {width: 100%;height: 100%;}
.container .index-modules .module-inner .report .info {margin-top: 4px;margin-left: 15px;}
.container .index-modules .module-inner .report .info .titlexlmm {font-size: 18px;color: #222;margin-bottom: 8px;}
.container .index-modules .module-inner .report .info .tel {font-size: 14px;color: #777;}
	#roll #ipostnew em{background-position:0px 0px;transition: all 0.2s ease-in-out;}
.news-list img{ width:60px; height:60px; margin-right:12px;}
</style>
<span class="y-box report">
  <a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="y-left img-holder">
    <img src="{if $_G[forum][icon]}data/attachment/common/$_G['forum']['icon']{else}template/xlmm_zx/image/icon.png{/if}">
  </a>
  <div class="y-left info">
    <p class="titlexlmm"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" style="color:#222">{echo cutstr($_G['forum'][name], 10)}</a><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" style="color:#222">【发新帖】</a></p>
    <p class="tel">主题数：$_G[forum][threads]&nbsp; &nbsp;总贴数：$_G[forum][posts]</p>
  </div>
</span>
						<!--{if $_G['forum']['ismoderator']}-->
				<span class="y-box report">
		<!--{if $_G['forum']['recyclebin']}-->
	<a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" class="fa_bin" target="_blank">{lang forum_recyclebin}</a>
						<!--{/if}-->
						<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->
							<span class="pipe">|</span><strong>
							<!--{if $_G['forum']['status'] != 3}-->
								<a href="forum.php?mod=modcp&fid=$_G[fid]">{lang modcp}</a>
							<!--{else}-->
								<a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang modcp}</a>
							<!--{/if}-->
							</strong>
						<!--{/if}-->
					</span>
	<!--{/if}-->
			<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
<style>
	.more-items-content {overflow: hidden;margin-left: 20px;margin-bottom: -20px;}
	.more-items-content .item {float: left;margin: 0 20px 20px 0;}
.more-items-content .item a {color: #222;line-height: 1.4;font-size: 14px;}
	</style>

    <div class="whotxlmmbbs module">
      <div class="module-head xlmmbbs-head">{lang forum_viewall}分类 </div> 
      	<ul class="more-items-content">
							<!--{if $_G['forum']['threadtypes']}-->
							<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
								<!--{if $_GET['typeid'] == $id}-->
<li class="item"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="a">$name</a></li>
									<!--{else}-->
					<li class="item"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
			<!--{/if}-->
							<!--{/loop}-->
						<!--{/if}-->
						<!--{if $_G['forum']['threadsorts']}-->
                            <!--{hook/forumdisplay_threadtype_inner}-->
							<!--{if $_G['forum']['threadtypes']}-->
                            <!--{hook/forumdisplay_threadtype_inner}--><!--{/if}-->
							<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
								<!--{if $_GET['sortid'] == $id}-->
						<li class="item"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="a">$name</a></li>
								<!--{else}-->
							<li class="item"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
								<!--{/if}-->
							<!--{/loop}-->
						<!--{hook/forumdisplay_filter_extra}-->
						<!--{/if}-->
</ul>
</div>
				        <div class="clearfix"> </div>
				        <div style="height:16px"> </div>
<!--{/if}-->

			<!--{if $subexists }-->
                 <div class="hotNews module">
          <div class="module-head news-head"> 子版块 </div> 
          <ul class="news-content">
          			<!--{loop $sublist $sub}-->
			<!--{eval $forumurl = !empty($sub['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$sub['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$sub['fid'];}-->
<li class="news-list"><!--{if $sub[icon]}-->
						 <div>$sub[icon] <a href="$forumurl" target="_blank"  class="news-inner"> <p class="module-title">$sub[name]<p style="color:#999; margin-top:3px;"><em>主题：<!--{echo dnumber($sub[threads])}-->&nbsp;&nbsp;&nbsp;</em><em class="number" >帖子：<!--{echo dnumber($sub[threads])}-->&nbsp;</em></p></p> </a> </div>
					<!--{else}--><a href="$forumurl" target="_blank" class="news-link"> <div class="module-pic news-pic"><img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" width="63" height="63" /></div> <div class="news-inner"> <p class="module-title">$sub[name]<p style="color:#999; margin-top:3px;"><em>主题：<!--{echo dnumber($sub[threads])}-->&nbsp;&nbsp;&nbsp;</em><em class="number" >帖子：<!--{echo dnumber($sub[threads])}-->&nbsp;</em></p></p> </div> </a><!--{/if}--> </li>
			<!--{/loop}-->
          </ul>
      </div>
					<!--{/if}-->
	<!--[diy=xlmm-r]--><div id="xlmm-r" class="area"></div><!--[/diy]-->
               <div id="fixeds"></div>
  </div>
		<div class="none">
				<!--[diy=r1]--><div id="r1" class="area"></div><!--[/diy]-->
				<!--[diy=r2]--><div id="r2" class="area"></div><!--[/diy]-->
				<!--[diy=r4]--><div id="r4" class="area"></div><!--[/diy]-->
				<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
	</div>

							<!--{else}-->
<div id="celebrity" class="region_bright celebrity"><div class="region_header"><div class="region_op j_op"> </div>
<div class="region_title region_icon j_title"></div></div>
<div class="region_cnt"><div class="intro"><div class="col2-left"><a class="gift-wrapper" href="javascript:"><span class="gift"><img src="template/xlmm_zx/image/huiyuan.png"></span>会员身份</a></div>
<div class="col2-right"><ul class="privilege-list">
<li><i class="icon icon-red-thread-title"></i>发布信息免费</li>
<li><i class="icon icon-red-name"></i>发贴彩色标题</li>
<li><i class="icon icon-sign-exp"></i>签到额外经验值</li>
</ul></div></div>
<div class="more-privilege-container"><div class="first-show-container"><a title="发表新贴" href="javascript:;" id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} ><button class="purchase-member-btn">马上发表帖子</button></a></div></div>
<p class="gray-text">如何快速提升等级，查看<a href="home.php?mod=spacecp&ac=credit&op=rule" class="celebrity-purchase-exp" target="_blank">[积分规则]</a></p> </div>
<div class="region_footer"></div></div>  

			<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
<div class="region_bright related_forums" style="margin-top:0"><div class="region_header">
<div class="region_title region_icon j_title">分类浏览</div></div>
<div class="region_cnt">
<div class="star_related">
		<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a>	
						<!--{if $_G['forum']['threadtypes']}-->
							<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
								<!--{if $_GET['typeid'] == $id}-->
<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="a">$name</a>
									<!--{else}-->
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a>
			<!--{/if}-->
							<!--{/loop}-->
						<!--{/if}-->
						<!--{if $_G['forum']['threadsorts']}-->
                            <!--{hook/forumdisplay_threadtype_inner}-->
							<!--{if $_G['forum']['threadtypes']}-->
                            <!--{hook/forumdisplay_threadtype_inner}--><!--{/if}-->
							<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
								<!--{if $_GET['sortid'] == $id}-->
						<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="a">$name</a>
								<!--{else}-->
							<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a>
								<!--{/if}-->
							<!--{/loop}-->
						<!--{hook/forumdisplay_filter_extra}-->
						<!--{/if}-->
</div> </div>
<div class="region_footer"></div></div>
						<!--{/if}-->


 <!--{if !empty($_G['uid'])}-->
             {eval getuserprofile('posts');}
 <div class="region_bright balv_mod">
 <div class="region_header"><div class="region_op j_op"> </div>
<div class="region_title region_icon j_title">我在线上</div></div>
<div class="region_cnt">                
<div class="media_horizontal clearfix "><a class="media_left" href="home.php?mod=space&uid=$_G[uid]" target="_blank"><i class="head_img"><!--{avatar($_G[uid],middle)}--></i></a>
<div class="media_right"> 
  <div class="text_overflow">
<a href="home.php?mod=space&uid=$_G[uid]" target="_blank" style=" display:block">{echo cutstr($_G[member][username],10)}</a>
</div>            
<i class="icon_money" title="金币"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a" title="金币"><!--{echo dnumber($_G['member']['extcredits2'])}--></a>
<p class="orange_text" title="积分"><i class="icon_credits"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a">$_G[member][credits]</a></p>
<p><a href="home.php?mod=spacecp&ac=usergroup">[会员等级{$_G[group][stars]}]</a></p>
</div></div></div>
<div class="region_footer"></div></div>
<!--{/if}-->
			<!--{if $subexists && $_G['page'] == 1}--><!--{template forum/forumdisplay_subforum}--><!--{/if}-->

<div class="offical_schedule_wrap region_bright star_platform_aside_module">
<div class="trip_title"><h1 class="titles">活动中心</h1></div>
				<!--[diy=r1]--><div id="r1" class="area"></div><!--[/diy]-->
</div>


<div id="encourage_entry" class="my_app encourage_entry region_bright " style="padding: 12px 10px 0 20px;">
<div class="my_app_title"><span class="region_title">最新热版</span><i class="encourage_entry_icon_new"></i></div>
				<!--[diy=r2]--><div id="r2" class="area"></div><!--[/diy]-->
</div>


<div class="region_bright related_forums"><div class="region_header">
<div class="region_title region_icon j_title">与他相关的版块</div></div>
<div class="region_cnt">
<div class="star_related">
						<!--{loop $_G['cache']['forums'] $bforum}-->
							<!--{if $bforum['fup'] == $_G['forum']['fup'] && $bforum['status']}-->
<a href="forum.php?mod=forumdisplay&fid=$bforum[fid]" target="_blank">$bforum['name']</a>
							<!--{/if}-->
						<!--{/loop}-->
</div> </div>
<div class="region_footer"></div></div>

<div class="region_bright related_forums"><div class="region_header"><div class="region_op j_op"><a target="_blank" href="{$_G['style']['申请版主链接']}">申请版主&gt;&gt;</a></div>
<div class="region_title region_icon j_title">本版版主</div></div>
<div class="region_cnt">
<div class="star_related">
<!--{if $moderatedby}-->$moderatedby<!--{else}--><a href="{$_G['style']['申请版主链接']}" target="_blank">暂时还没有版主哦</a><!--{/if}-->
</div> </div>
<div class="region_footer"></div></div>
 <div id="zyq" class="zyq_bright">
 <div class="mod"><div class="tl"><div class="mod_edit_wrap"></div><span class="zyq_mod_title">会员排行</span></div>
				<!--[diy=r4]--><div id="r4" class="area"></div><!--[/diy]-->
 </div></div>
		<div class="drag">
				<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
			</div>
			<div class="none">
		<!--[diy=xlmm-l]--><div id="xlmm-l" class="area"></div><!--[/diy]-->
	<!--[diy=xlmm-hd]--><div id="xlmm-hd" class="area"></div><!--[/diy]-->
<!--[diy=xlmm-r]--><div id="xlmm-r" class="area"></div><!--[/diy]-->
	</div>
 
								<!--{/if}-->
		<!--{hook/forumdisplay_side_bottom}-->
		</div>
	</div>
</div>
<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
	<ul class="p_pop" id="newspecial_menu" style="display: none">
		<!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
			<!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
				<!--{if $_G['forum']['threadsorts']['show'][$id]}-->
					<li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id">$threadsorts</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
			<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
	<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
		<!--{if $_G['setting']['threadplugins']}-->
			<!--{loop $_G['forum']['threadplugin'] $tpid}-->
				<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
					<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url(source/plugin/$tpid/$_G[setting][threadplugins][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>
<!--{/if}-->

<!--{if $_G['setting']['threadmaxpages'] > 1 && $page && !$subforumonly}-->
	<script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}', $page);}</script>
<!--{/if}-->

<!--{if empty($_G['forum']['picstyle']) && $_GET['orderby'] == 'lastpost' && empty($_GET['filter']) }-->
	<script type="text/javascript">checkForumnew_handle = setTimeout(function () {checkForumnew($_G[fid], lasttime);}, checkForumtimeout);</script>
<!--{/if}-->
<div class="wp mtn">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
			<!--{if $fastpost}--><!--{else}-->
</div>
<!--{/if}-->

	</div>
	<script type="text/javascript">new QRCode(document.getElementById("qrcode"), "{$_G['siteurl']}forum.php?mod=forumdisplay&fid=$_G[fid]");</script>
    <!--{if in_array($_G['fid'], unserialize($_G['cache']['plugin']['xlmm_tt']['xlmmttlb']))}-->
	<script type="text/javascript">
	var navs = $('fthread');
var navsoffset = parseInt(fetchOffset(navs)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop >= navsoffset){
	if (BROWSER.ie && BROWSER.ie < 7) {
		navs.style.position = 'absolute';
		navs.style.top = xlmmm_scrollTop + 'px';
	}else{
		navs.style.position = 'fixed';
		navs.style.top = '10px';
	}
}else{
	navs.style.position = 'static';
		navs.style.top = xlmmm_scrollTop + 'px';
}
});


var userfix = $('fixeds');
var userfixoffset = parseInt(fetchOffset(userfix)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop + 50 >= userfixoffset){
if (BROWSER.ie && BROWSER.ie < 7) {
userfix.style.position = 'absolute';
userfix.style.top = xlmmm_scrollTop + 'px';
}else{
userfix.innerHTML  = '<style>.hotNews{ position:fixed; top:0px; width:340px;}</style>';
}
}else{
userfix.innerHTML  = '<style>.hotNews{ position:static;}</style>';
}
});


    </script>
<!--{/if}-->


<!--{else}-->
<!--{template common/pb_header}-->

<div class="pbheader">
<nav class="nav-wide wp">
        <div class="nav-left">
            <a href="./">
                <i class="nav-logo"></i>
            </a>
            <ul class="supnav-list">
       <!--{eval $is=0;}-->
		<!--{loop $_G['setting']['navs'] $key $nav}-->
					<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li class="supnav-item"$nav[nav]></li><!--{/if}-->
	 <!--{eval $is++ ;}-->
<!--{eval if($is==6) break;}-->
		<!--{/loop}-->
            </ul>
        </div>
        <div class="nav-right">
            <div class="nav-search">
                <form id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" onSubmit="searchFocus($('scbar_txt'))" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
  			        <input type="hidden" name="mod" id="scbar_mod" value="{if $_G['basescript'] == 'portal'}portal{elseif $_G['basescript'] == 'group'}group{else}forum{/if}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="srchtype" value="title" />
        <input type="hidden" name="srhfid" value="" />
        <input type="hidden" name="srhlocality" value="forum::mypage" />
              <input type="hidden" name="searchsubmit" value="yes"/>
              <a href="javascript:;" ><input type="submit" name="submit" value="" class="icon-search" id="topsearch_submit" /></a> 
                    <input class="search-input" name="srchtxt" placeholder="搜索" autocomplete="off" type="text">
                </form>
            </div>
                          <!-- 登录状态 -->
                           {if $_G['uid']}
   <ul class="supnav-list">
                <li class="supnav-item nav-user subnav-trigger">
                    <a href="home.php?mod=space&uid=$_G[uid]" class="user-info">
{avatar($_G[uid],small)}{$_G[member][username]}
                                                                    </a>
                    
                    <ul class="subnav-list">
                      <li><a target="_blank" href="home.php?mod=space&do=favorite&view=me" rel="nofollow"><span>我的收藏</span></a></li>
                        <li><a target="_blank" href="home.php?mod=space&uid=$_G[uid]&do=thread&view=me&from=space" rel="nofollow"><span>我的帖子</span></a></li>
                        <li><a target="_blank" href="home.php?mod=spacecp"><span>账号设置</span></a></li>
 								<!--{hook/global_usernav_extra3}-->
								<!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
									<li><a href="portal.php?mod=portalcp"><span><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></span></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
									<li><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank"><span>{lang forum_manager}</span></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']}-->
									<li><a href="admin.php?frames=yes&action=cloud&operation=applist" target="_blank"><span>{lang cloudcp}</span></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
									<li><a href="admin.php" target="_blank"><span>{lang admincp}</span></a></li>
								<!--{/if}-->
<!--{hook/global_myitem_extra}-->
								<!--{hook/global_usernav_extra4}-->
                       <li id="tx_b_l4"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" rel="nofollow"><span>退出登录</span></a></li>
                    </ul>
                </li>
                <li class="supnav-item nav-messages subnav-trigger"<!--{if $_G[member][newprompt] || $_G[member][newpm]}-->
<!--{eval $newxx = $_G[member][newpm] + $_G[member][newprompt];}--> data-count="$newxx"<!--{/if}-->>
                    <a href="home.php?mod=space&do=notice" class="icon-message">消息</a>
                    <ul class="subnav-list">
				<li><a href="home.php?mod=space&do=pm" id="pm_ntc" style="background-repeat: no-repeat;background-position: 0 50%;">{lang pm_center}{if $_G[member][newpm]}({$_G[member][newpm]}){/if}</a></li>
				<li><a href="home.php?mod=follow&do=follower"><!--{lang notice_interactive_follower}-->{if $_G[member][newprompt_num][follower]}($_G[member][newprompt_num][follower]){/if}</a></li>
				<!--{if $_G[member][newprompt] && $_G[member][newprompt_num][follow]}-->
					<li><a href="home.php?mod=follow"><!--{lang notice_interactive_follow}-->($_G[member][newprompt_num][follow])</a></li>
				<!--{/if}-->
				<!--{if $_G[member][newprompt]}-->
					<!--{loop $_G['member']['category_num'] $key $val}-->
						<li><a href="home.php?mod=space&do=notice&view=$key"><!--{echo lang('template', 'notice_'.$key)}-->(<span class="rq">$val</span>)</a></li>
					<!--{/loop}-->
				<!--{/if}-->

</ul>
                </li>
                <li class="supnav-item subnav-trigger nav-publish">
                    <a href="javascript:;" id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} title="{lang send_posts}" class="publish-btn btn btn-yellow">发布</a>
                    <ul class="subnav-list">
		<!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang post_newthread}</a></li><!--{/if}-->
		<!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
			<!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
				<!--{if $_G['forum']['threadsorts']['show'][$id]}-->
					<li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id">$threadsorts</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
		<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
		<!--{if $_G['setting']['threadplugins']}-->
			<!--{loop $_G['forum']['threadplugin'] $tpid}-->
				<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
					<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url(source/plugin/$tpid/$_G[setting][threadplugins][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
                    </ul>
                </li>
            </ul>
                         <!-- 非登录状态 -->
                          {else}
          <a href="member.php?mod=logging&amp;action=login" onClick="showWindow('login', this.href)" class="nav-login login-trigger">登录</a>
            <a href="member.php?mod={$_G[setting][regname]}" class="nav-register register-trigger">注册</a>
                              {/if}
          </div>
    </nav>
                    </div>
 {if $_G['uid']}<script>var formhash = '{FORMHASH}', allowrecommend = '1';</script>
 <script src="template/xlmm_zx/image/rec.js?{VERHASH}" charset="{CHARSET}"></script> {/if}


<div class="personal-integer">
    <div class="personal-banner" style="background-image: url({if $_G[forum][banner] && !$subforumonly}$_G[forum][banner]{else}template/xlmm_zx/image/picbg.jpg{/if})">
        <div class="posRelative personal-banner-info wp">
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="personal-logo-link">
                <img src="{if $_G[forum][icon]}data/attachment/common/$_G['forum']['icon']{else}template/xlmm_zx/image/icon.png{/if}">
                                            </a>
            
            <div class="personal-info" style="position:relative; z-index:3;">
                <div>
                    <a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="info-name"> $_G['forum']['name'] </a><a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" class="follow-btn btn" >+ 收藏</a>
                                    </div>

                <ul class="slash-list">
                    <li class="slash-item"> 
<a>{lang forum_favorite} <i id="number_favorite" {if !$_G[forum][favtimes]} style="display:none;"{/if}><span id="number_favorite_num">$_G[forum][favtimes]</span></i></a>                    </li>
                            <li class="slash-item"> {lang index_today} $_G[forum][todayposts] </li>
                    <li class="slash-item"> 
                        <a href="javascript:;"> 帖子 $_G[forum][threads] </a> 
                    </li>
						<!--{if !empty($forumarchive)}-->
							<a id="forumarchive" href="javascript:;" class="fa_achv" onmouseover="showMenu(this.id)"><!--{if $_GET['archiveid']}-->$forumarchive[$_GET['archiveid']]['displayname']<!--{else}-->{lang forum_archive}<!--{/if}--></a>
						<!--{/if}-->
						<!--{hook/forumdisplay_forumaction}-->

						<!--{if $_G['forum']['ismoderator']}-->
				 <li class="slash-item"> 
                 		<!--{if $_G['forum']['recyclebin']}-->
							<a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" class="fa_bin" target="_blank">{lang forum_recyclebin}</a>
						<!--{/if}-->
						<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->
							<span class="pipe">|</span><strong>
							<!--{if $_G['forum']['status'] != 3}-->
								<a href="forum.php?mod=modcp&fid=$_G[fid]">{lang modcp}</a>
							<!--{else}-->
								<a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang modcp}</a>
							<!--{/if}-->
							</strong>
						<!--{/if}-->
						<!--{hook/forumdisplay_modlink}-->
					                    </li>
	<!--{/if}-->
        </ul>

                                <p class="info-desc">{if $_G['forum']['description']}$_G['forum']['description']{else}本版暂无版块简介{/if} </p>
                            </div>


        </div>
    </div>



</div>








<nav class="secondary-nav">
  <div class="wp">
  <ul class="nav-list wp cl">
    <li class="{if !$_GET['typeid']} active{/if}"><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">全部</a></li>
			<!--{if $_G['forum']['threadtypes']}-->
		<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
				<li class="{if $_GET['typeid'] == $id} active{/if}"><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}">$name</a>
			<!--{/loop}-->
		<!--{/if}-->
        </ul>
                            <div class="time-line y">
<a style="margin-right:10px;" id="atarget" {if $_G['cookie']['atarget'] > 0}onclick="setatarget(-1)" class=" atarget_1"{else}onclick="setatarget(1)" class=""{/if} title="{lang new_window_thread}">{lang new_window}</a>
   					<a{if empty($_G['cookie']['forumdefstyle'])} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="chked"{else} href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="unchk"{/if} title="{lang view_thread_imagemode}{lang view_thread}">{lang view_thread_imagemode}</a>
   
      </div>
            </div>

        
    </nav>
    
    
    
    
    
    
    
    
    
    
				<!--{if $_G['forum_threadcount']}-->
<div id="threadlist" class="wp" style=" width:1250px;padding:40px 0;">
						<ul id="waterfall" class="cl" style="margin-top:0; margin-left:25px; padding-bottom:40px; position:relative; ">
						<!--{loop $_G['forum_threadlist'] $key $thread}-->
							<!--{if $_G['hiddenexists'] && $thread['hidden']}-->
								<!--{eval continue;}-->
							<!--{/if}-->
							<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
								<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
							<!--{/if}-->
							<!--{eval $waterfallwidth = $_G[setting][forumpicstyle][thumbwidth]-10; }-->
								<li class="pagelist-wrapper" style="width:{$_G[setting][forumpicstyle][thumbwidth]}px">
			<div class="post-photo" style="width:{$waterfallwidth}px">
										<!--{if $thread['cover']}-->
											<img src="$thread[coverpath]" alt="$thread[subject]" width="$waterfallwidth" />
										<!--{else}-->
											<img src="template/xlmm_zx/image/icon.png" alt="$thread[subject]" width="$waterfallwidth" />
										<!--{/if}-->
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra{if $thread['cover'] > 1 }&from=album{/if}"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} title="$thread[subject]" class="post-info">
            
                <p>
                    <span class="post-title">									<!--{hook/forumdisplay_thread $key}-->
								$thread[subject]
 </span>
                </p>
                
                <p>
                    by 									<!--{hook/forumdisplay_author $key}-->
									<!--{if $thread['authorid'] && $thread['author']}-->
										<span onclick="window.location='forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra';">$thread[author]</span><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->
									<!--{else}-->
										$_G[setting][anonymoustext]
									<!--{/if}-->

                </p>
                
            

            <p class="post-action">
                <span>$thread[replies]评论 /</span>
                <span>$thread[views]浏览</span>

                
            </p>
        </a>
          <!--{if $thread['cover'] > 1}--> <span class="post-image-count">组图(共$thread[cover]张)</span><!--{/if}-->
    </div>
	    
    <div class="gallery-foot">
        
        <div class="post-foot has-source">
            <a href="home.php?mod=space&uid=$thread[authorid]" class="site-icon" target="_blank">{avatar($thread[authorid],small)}</a>
            <a href="home.php?mod=space&uid=$thread[authorid]" class="site-link" target="_blank"><!--{if $thread['authorid'] && $thread['author']}-->$thread[author]<!--{else}-->
											$_G[setting][anonymoustext]
										<!--{/if}--></a>
     	             {eval $timets=time();$curdate=getdate($timets);$nowtime=mktime(0,0,0,$curdate['mon'],$curdate['mday'],$curdate['year']);if ($thread['dbdateline']>=$nowtime) $thread['dateline']=date('H:i',$thread['dbdateline']);else $thread['dateline']=date('m-d',$thread['dbdateline']);}
       <time>$thread[dateline]</time>
            
            <p class="post-source">
                
                <span class="recommend-type">$thread[views]次浏览</span>
                
            </p>
            
        </div>
        <div class="post-ops">
            <a href="forum.php?mod=misc&action=recommend&handlekey=recommend_add&do=add&tid=$thread[tid]&hash={FORMHASH}" {if $_G['uid']} tid="$thread[tid]"{else} onclick="showWindow('login', this.href)"{/if} class="{if C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $thread[tid])}f_wb {/if}xlmm_rec_recommend_addkey icon-like" title="喜欢"><i>&#x2764;</i><span class="num-all_$thread[tid]">$thread[recommend_add]</span></a>
            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" title="$thread[replies] {lang reply}" class="icon-comment"><i style="margin-top:-2px">&#x2584;</i>$thread[replies]</a>
        </div>
    </div>
    
					</li>
							<!--{/loop}-->
						</ul>
						<div id="tmppic" style="display: none;"></div>
						<script type="text/javascript" src="{$_G[setting][jspath]}redef.js?{VERHASH}"></script>
						<script type="text/javascript" reload="1">
						var wf = {};
 {if $_G['uid']}xlmm_rec_recommend_addkey();{/if}
						_attachEvent(window, "load", function () {
							if($("waterfall")) {
								wf = waterfall();
							}

							<!--{if $page < $_G['page_next'] && !$subforumonly}-->
								var page = $page + 1,
									maxpage = Math.min($page + 10,$maxpage + 1),
					stopload = 0,
									scrolltimer = null,
									tmpelems = [],
									tmpimgs = [],
									markloaded = [],
									imgsloaded = 0,
									loadready = 0,
									showready = 1,
									nxtpgurl = 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&page=',
wfloading = "<a class=\"loading\" /> </a>",
pgbtn = $("pgbtn").getElementsByTagName("span")[0];
 {if $_G['uid']}xlmm_rec_recommend_addkey();{/if}
								function loadmore() {
									var url = nxtpgurl + page + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
									var x = new Ajax("HTML");
									x.get(url, function (s) {
										s = s.replace(/\n|\r/g, "");
										if(s.indexOf("id=\"pgbtn\"") == -1) {
											$("pgbtn").style.display = "none";
											stopload++;
											window.onscroll = null;
										}

										s = s.substring(s.indexOf("<ul id=\"waterfall\""), s.indexOf("<div id=\"tmppic\""));
										s = s.replace("id=\"waterfall\"", "");
										$("tmppic").innerHTML = s;
										loadready = 1;
	 {if $_G['uid']}xlmm_rec_recommend_addkey();{/if}
								});
								}

								window.onscroll = function () {
									if(scrolltimer == null) {
										scrolltimer = setTimeout(function () {
											try {
												if(page < maxpage && stopload < 2 && showready && ((document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.clientHeight + 500) >= document.documentElement.scrollHeight) {
													pgbtn.innerHTML = wfloading;
													loadready = 0;
													showready = 0;
													loadmore();
													tmpelems = $("tmppic").getElementsByTagName("li");
													var waitingtimer = setInterval(function () {
														stopload >= 2 && clearInterval(waitingtimer);
														if(loadready && stopload < 2) {
															if(!tmpelems.length) {
																page++;
																pgbtn.href = nxtpgurl + Math.min(page, $maxpage);
	var xlmm = ['<a hidefocus="true" class="cloadmore">已没有更多了</a>'];
pgbtn.innerHTML = xlmm;
																showready = 1;
																clearInterval(waitingtimer);
				}
							for(var i = 0, j = tmpelems.length; i < j; i++) {
																if(tmpelems[i]) {
																	tmpimgs = tmpelems[i].getElementsByTagName("img");
																	imgsloaded = 0;
																	for(var m = 0, n = tmpimgs.length; m < n; m++) {
																		tmpimgs[m].onerror = function () {
																			this.style.display = "none";
																		};
																		markloaded[m] = tmpimgs[m].complete ? 1 : 0;
																		imgsloaded += markloaded[m];
																	}
																	if(imgsloaded == tmpimgs.length) {
																		$("waterfall").appendChild(tmpelems[i]);
																		wf = waterfall({
																			"index": wf.index,
																			"totalwidth": wf.totalwidth,
																			"totalheight": wf.totalheight,
																			"columnsheight": wf.columnsheight
																		});
																	}
																}
															}
														}
													}, 40);
												}
											} catch(e) {}
											scrolltimer = null;
										}, 320);
									}
								};
							<!--{/if}-->

						});

						</script>
	{if $_G['page_next'] >1}
 		<div id="pgbtn"><span></span></div>
{/if}
</div>
				<!--{else}-->
<div class="wp">
<p style="text-align:center;background-color: #fff; padding:40px; margin:40px 0;color: #777;font-size: 14px;">{lang forum_nothreads}</p>
		</div>
		<!--{/if}-->

<div id="xlmm_rec_alert" style="display:none;"></div>
<!--{/if}-->
<!--{template common/footer}-->



