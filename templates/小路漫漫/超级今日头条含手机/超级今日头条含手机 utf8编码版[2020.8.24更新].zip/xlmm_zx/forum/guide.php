<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<style type="text/css">
	body{background:#eaeaea  }
.xl2 { background: url({IMGDIR}/vline.png) repeat-y 50% 0; }
		.xl2 li { width: 49.9%; }
			.xl2 li em { padding-right: 10px; }
				.xl2 .xl2_r em { padding-right: 0; }
			.xl2 .xl2_r i { padding-left: 10px; }
.ct2 .mn { width:738px;}
.ct2 { margin-right:0;}
.bmw {border: 0}
.tl .avt { border:0}
.tl .tdbg { vertical-align:top; width: 25px; border-bottom:0px}
.tl .by {padding-right: 0}
.xs2 a, .xs2 em { margin-right:5px}

.sidebarplate{border:1px solid #e6e6e6;overflow:hidden;font-size:14px}
.sidebarplate .sidebarplate_tab{height:40px;line-height:40px;background:#fafafa;font-weight:bold}
.sidebarplate .sidebarplate_tab .tab{width:252px;margin-left:-1px;color:#333}
.sidebarplate .sidebarplate_tab .tab li{cursor:pointer;float:left;width:125px;border-left:1px solid #e8e8e8;text-align:center}
.sidebarplate .sidebarplate_tab .tab li.on{height:36px;line-height:32px;border-top:4px solid #ccd1d9;background:#fff}
.xlmm_guide ul{width:252px;margin-right:-1px; height:295px; overflow:hidden;}
.xlmm_guide ul li{float:left;width:125px;height:36px;line-height:36px;border-right:1px solid #e5e5e5;border-top:1px solid #e5e5e5;text-align:center}
.xlmm_guide ul li a{color:#333;display:block}
.xlmm_guide ul li a:hover{color:#ff8b3d}
.xlmm_guide ul li.more{width:251px}
.xlmm_guide ul.on{display:block}

.left_wrap{background:#fff;margin-bottom:15px}
.con{border:1px solid #e6e6e6;padding:0 19px 25px 29px}
.hotspot h3,.hotspot h4{font-size:14px;line-height:26px;padding-bottom:4px;margin:16px 0 0 0}
.hotspot h3{border-bottom:1px solid #e6e6e6;margin-bottom:20px}
</style>
<div class="boardnav" style="margin-top:15px">
	<div id="ct" class="ct2">
		<div class="mn">
			<div class="bm bml pbn" style="border: 1px solid #e6e6e6; padding:5px 15px 0 15px">
				<div class="bm_h cl">
					<!--{if $view != 'index' && $view != 'my'}-->
					<span class="y">
						<a href="forum.php?mod=guide&view=$view&rss=1" class="fa_rss" target="_blank" title="RSS">{lang rss_subscribe_this}</a>
					</span>
					<!--{/if}-->
					<h1 class="xs2">
		<a href="javascript:">当前位置</a><!--{if helper_access::check_module('guide')}--><em>&raquo;</em><a href="forum.php?mod=guide&view=index">{lang guide}</a><!--{/if}-->$navigation
					</h1>
				</div>
				<!--{if $view != 'my'}-->
				<div class="bm_c cl pbn">
					<div style=";" id="forum_rules_1163">
						<div class="ptn xg2">$lang['guide_'.$view.'_description']</div>
					</div>
				</div>
				<!--{/if}-->
			</div>
			<ul id="thread_types" class="ttp bm cl" style="border-top:1px">
				<li $currentview['hot']><a href="forum.php?mod=guide&view=hot">{lang guide_hot}</a></li>
				<li $currentview['digest']><a href="forum.php?mod=guide&view=digest">{lang guide_digest}</a></li>
				<li $currentview['new']><a href="forum.php?mod=guide&view=new">{lang guide_new}</a></li>
				<li $currentview['newthread']><a href="forum.php?mod=guide&view=newthread">{lang guide_newthread}</a></li>
				<li $currentview['sofa']><a href="forum.php?mod=guide&view=sofa">{lang guide_sofa}</a></li>
				<li $currentview['my']><a id="filter_special" href="forum.php?mod=guide&view=my" onmouseover="showMenu(this.id)">{lang guide_my}</a></li>
				<!--{hook/guide_nav_extra}-->
			</ul>
			<!--{hook/guide_top}-->
			<!--{if $view == 'index'}-->
				<!--{loop $data $key $list}-->
				<div class="bm bmw">
					<div class="bm_h">
						<a href="forum.php?mod=guide&view=$key" class="y xi2">{lang more} &raquo;</a>
						<h2>
							<!--{if $key == 'hot'}-->{lang guide_hot}<!--{elseif $key == 'digest'}-->{lang guide_digest}<!--{elseif $key == 'newthread'}-->{lang guide_newthread}<!--{elseif $key == 'new'}-->{lang guide_new}<!--{elseif $key == 'my'}-->{lang guide_my}<!--{/if}-->
						</h2>
					</div>
					 <div class="bm_c">
					 	<div class="xl xl2 cl">
					 		<!--{if $list['threadcount']}-->
					 			<!--{eval $i=0;}-->
					 			<!--{loop $list['threadlist'] $thread}-->
					 			<!--{eval $i++;$newtd=$i%2;}-->
					 			<li{if !$newtd} class="xl2_r"{/if}>
						 			<em>
							 			<!--{if $key == 'hot'}--><span class="xi1">$thread['heats']{lang guide_attend}</span><!--{/if}-->
							 			<!--{if $key == 'new'}-->$thread['lastpost']<!--{/if}-->
						 			</em>
						 			
						 			<i>&middot; <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight] target="_blank">$thread[subject]</a></i>&nbsp;<span class="xg1"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">$list['forumnames'][$thread[fid]]['name']</a></span>
					 			</li>
					 			<!--{/loop}-->
					 		<!--{else}-->
					 				<p class="emp">{lang guide_nothreads}</p>
					 		<!--{/if}-->
					 	</div>
					</div>
				</div>
				<!--{/loop}-->
			<!--{else}-->
				<!--{loop $data $key $list}-->
				<div id="threadlist" class="tl bm bmw"{if $_G['uid']} style="position: relative;"{/if}>
					<div class="bm_c">
						<div id="forumnew" style="display:none"></div>
							<table cellspacing="0" cellpadding="0">
							<!--{subtemplate forum/guide_list_row}-->
							</table>
					</div>
				</div>
				<!--{/loop}-->
				<div class="bm bw0 pgs cl">
					$multipage
					<span class="pgb y"><a href="forum.php?mod=guide">{lang guide_index}</a></span>
				</div>
			<!--{/if}-->
			<!--{hook/guide_bottom}-->
		</div>

		<div id="side" class="side">
	{eval include TPLDIR.'/php/forum_index.php';}
  <div class="left_wrap">      
					<div class="sidebarplate slideTxtBox">

						<div class="sidebarplate_tab">
							<ul class="tab hd">
								<li class="on">版块推荐</li>
								<li>百宝箱</li>
							</ul>
						</div>
						<div class="bd xlmm_guide">
							<ul class='on'>
<!--{eval $gidiconnum = 0;}-->
<!--{loop $catlist $key $cat}-->
<!--{eval $caturl = !empty($cat['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$cat['domain'].'.'.$_G['setting']['domain']['root']['forum'] : '';}-->
<!--{eval $gidiconnum ++;}-->  
<!--{eval $i++;}-->
  <!--{eval $fidnum = 0;}-->
	<!--{loop $cat[forums] $forumid}-->
<!--{eval $forum=$forumlist[$forumid];}-->
<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
<!--{eval $fidnum ++;}-->
								<li><a href="$forumurl" target="_blank"{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a></li>
<!--{/loop}-->
<!--{/loop}-->
								
							</ul>


							<ul >
								
								<li><a href="home.php?mod=task" target="_blank">论坛任务</a></li>
								<li><a href="home.php?mod=space&do=notice" target="_blank">我的消息</a></li>
								<li><a href="home.php?mod=magic" target="_blank">道具中心</a></li>
								<li><a href="home.php?mod=medal" target="_blank">勋章中心</a></li>
								<li><a href="http://wpa.qq.com/msgrd?v=3&uin=$_G['setting']['site_qq']&site=$_G['setting']['bbname']&menu=yes" target="_blank" title="QQ">客服QQ</a></li>
								<li><a href="home.php?mod=spacecp&amp;ac=credit" target="_blank">积分攻略</a></li>
								<li><a href="home.php?mod=spacecp&ac=profile&op=verify" target="_blank">实名认证</a></li>
								<li><a href="home.php?mod=spacecp&ac=usergroup&do=forum" target="_blank">我的权限</a></li>
<li><a href="search.php?mod=forum" target="_blank">搜索帖子</a></li>
								<li><a href="search.php?mod=portal" target="_blank">搜索文章</a></li>
								<li><a href="search.php?mod=group" target="_blank">搜索圈子</a></li>
                                                                <li><a href="home.php?mod=spacecp&ac=search" target="_blank">搜索用户</a></li>
								<li><a href="{$_G['style']['申请版主链接']}" target="_blank">申请版主</a></li>
								<li><a href="forum.php?mod=misc&action=nav" target="_blank">免费发布</a></li>
								<li><a href="{$_G['siteurl']}" target="_blank">网站首页</a></li>
								<li><a href="javascript:;"  onclick="showWindow('miscreport', 'misc.php?mod=report&url='+REPORTURL);return false;">违规信息举报</a></li>
							
							</ul>
					</div>
						</div>	
					</div>
  
  <div class="left_wrap" id="fthread">      
  <div class="con">           
   <div class="hotspot">              
  <h3>拿出手机扫一扫</h3>                
  <a href="./" target="_blank"><img src="template/xlmm_zx/image/sjb.png" style="width:190px" height="190px"></div>
						</div>	
					</div>





</div>

	</div>
</div>
<!--{if !IS_ROBOT}-->
	<div id="filter_special_menu" class="p_pop" style="display:none">
		<ul>
			<li><a href="home.php?mod=space&do=poll&view=me" target="_blank">{lang thread_poll}</a></li>
			<li><a href="home.php?mod=space&do=trade&view=me" target="_blank">{lang thread_trade}</a></li>
			<li><a href="home.php?mod=space&do=reward&view=me" target="_blank">{lang thread_reward}</a></li>
			<li><a href="home.php?mod=space&do=activity&view=me" target="_blank">{lang thread_activity}</a></li>
		</ul>
	</div>
<!--{/if}-->
  <div class="clearfix"></div>
		<script type="text/javascript">
jQuery(".slideTxtBox").slide();
(function($){$(function () {

    var bartop = $('#fthread').offset().top,
        h2_con=$('#fthread').find("h2 a").text();
    function changeBar(){
        var st = $(window).scrollTop();
        if( st > bartop){
            $('#fthread').addClass('thread_fixed');
        }else{
            $('#fthread').removeClass('thread_fixed');
        }
    }
    $(window).scroll( function(){
        changeBar();
    })

})
})(jQuery)
</script>
<!--{template common/footer}-->


