<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->
	<style id="diy_style" type="text/css"></style>
	<div class="z"><!--{hook/index_status_extra}--><!--{hook/index_nav_extra}--></div>
	<div class="clearfix"></div>

<!--{if empty($gid)}-->
	<!--{ad/text/wp a_t}-->
<!--{/if}-->

		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->

		<!--{if !empty($_G['setting']['grid']['showgrid'])}-->
		<!-- index four grid -->
		<div class="fl bm" style="margin-top:20px; margin-bottom:0; border:0;">
			<div class="bm bmw cl">
				<div id="category_grid" class="bm_c" style="border:0;" >
					<table cellspacing="0" cellpadding="0"><tr>
					<!--{if !$_G['setting']['grid']['gridtype']}-->
						<td valign="top" class="category_l1">
							<div class="newimgbox">
								<h4><span class="tit_newimg"></span>{lang latest_images}</h4>
								<div class="module cl slidebox_grid" style="width:218px">
									<script type="text/javascript">
									var slideSpeed = 5000;
									var slideImgsize = [218,200];
									var slideBorderColor = '{$_G['style']['specialborder']}';
									var slideBgColor = '{$_G['style']['commonbg']}';
									var slideImgs = new Array();
									var slideImgLinks = new Array();
									var slideImgTexts = new Array();
									var slideSwitchColor = '{$_G['style']['tabletext']}';
									var slideSwitchbgColor = '{$_G['style']['commonbg']}';
									var slideSwitchHiColor = '{$_G['style']['specialborder']}';
									{eval $k = 1;}
									<!--{loop $grids['slide'] $stid $svalue}-->
										slideImgs[<!--{echo $k}-->] = '$svalue[image]';
										slideImgLinks[<!--{echo $k}-->] = '{$svalue[url]}';
										slideImgTexts[<!--{echo $k}-->] = '$svalue[subject]';
										{eval $k++;}
									<!--{/loop}-->
									</script>
									<script language="javascript" type="text/javascript" src="{$_G[setting][jspath]}forum_slide.js?{VERHASH}"></script>
								</div>
							</div>
						</td>
					<!--{/if}-->
					<td valign="top" class="category_l2">
						<div class="subjectbox">
							<h4><span class="tit_subject"></span>{lang collection_lastthread}</h4>
					        <ul class="category_newlist">
					        	<!--{loop $grids['newthread'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
								<li><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['showtips']} tip="{lang title}: <strong>$thread[oldsubject]</strong><br/>{lang author}: $thread[author] ($thread[dateline])<br/>{lang show}/{lang reply}: $thread[views]/$thread[replies]" onmouseover="showTip(this)"{else} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}>$thread[subject]</a></li>
								<!--{/loop}-->
					         </ul>
				         </div>
					</td>
					<td valign="top" class="category_l3">
						<div class="replaybox">
							<h4><span class="tit_replay"></span>{lang show_newthreads}</h4>
					        <ul class="category_newlist">
					        	<!--{loop $grids['newreply'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
								<li><a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['showtips']}tip="{lang title}: <strong>$thread[oldsubject]</strong><br/>{lang author}: $thread[author] ($thread[dateline])<br/>{lang show}/{lang reply}: $thread[views]/$thread[replies]" onmouseover="showTip(this)"{else} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}>$thread[subject]</a></li>
								<!--{/loop}-->
					         </ul>
				         </div>
					</td>
					<td valign="top" class="category_l3">
						<div class="hottiebox">
							<h4><span class="tit_hottie"></span>{lang hot_thread}</h4>
					        <ul class="category_newlist">
					        	<!--{loop $grids['hot'] $thread}-->
					        	<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
								<li><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['showtips']} tip="{lang title}: <strong>$thread[oldsubject]</strong><br/>{lang author}: $thread[author] ($thread[dateline])<br/>{lang show}/{lang reply}: $thread[views]/$thread[replies]" onmouseover="showTip(this)"{else} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}>$thread[subject]</a></li>
								<!--{/loop}-->
					         </ul>
				         </div>
					</td>
					<!--{if $_G['setting']['grid']['gridtype']}-->
						<td valign="top" class="category_l4">
							<div class="goodtiebox">
								<h4><span class="tit_goodtie"></span>{lang post_digest_thread}</h4>
								<ul class="category_newlist">
									<!--{loop $grids['digest'] $thread}-->
										<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
											<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
										<li><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if $_G['setting']['grid']['showtips']} tip="{lang title}: <strong>$thread[oldsubject]</strong><br/>{lang author}: $thread[author] ($thread[dateline])<br/>{lang show}/{lang reply}: $thread[views]/$thread[replies]" onmouseover="showTip(this)"{else} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}>$thread[subject]</a></li>
									<!--{/loop}-->
								 </ul>
						 	</div>
						</td>
					<!--{/if}-->
					</table>
				</div>
			</div>
		</div>
		<!-- index four grid end -->
		<!--{/if}-->
		<!--{hook/index_top}-->
		<!--{hook/index_catlist_top}-->
									<!--{hook/index_followcollection_extra $colletion[ctid]}-->
<style>
.indexlistwrapper {height: 231px;background: #f6f6f6;overflow: hidden; width:100%;border: 1px solid #e4e4e4 ;}

.panel {width: 70%;overflow: hidden; }
.panel_tt {height: 30px;background-color: #f6f6f6;border-bottom: #dbdbdb 1px solid;}
.panel_tt b {position: absolute;display: inline-block;padding: 10px 0 0 10px;color: #717171;}
.panel_tt ul {width: 280px;margin: 0 auto;padding-top: 3px;}
.panel_tt ul li {float: left;margin-left: -1px;}
.panel_tt ul li a {display: inline-block;margin: 0;padding: 0 15px;background-color: #f5f5f5;border: #e4e4e4 1px solid;border-bottom: none;line-height: 26px;color: #888;}
.panel .xlmmcons { margin-right:0px;height: 205px;overflow: hidden; background:#fff;}
.panel .xlmmcons li {height: 24px;padding: 0 0 0 5px;font-size: 12px;line-height: 24px;background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABcAAABkCAYAAABtnKvPAAANOklEQVRoge2Ua0yk53mG7zkyDIdhYAaWPTje2k6ixHaOrZwotdpGSqrEqdoqiqJU6SFqpdRJHCWtXLdVKrdpItWRHccwMCywXnvNLswBlvWu1hvHXjvYXmBOHMKu8fAtLAxzAIbDDGfwXv0xbvov/ePKVcUlPXp/vN93P897P8/7Sgcc8H+H5Ycf/eZU/cev5nWbsapGY1aNhmG//XrK6pn8TTGleuOm6o28GoxtHTUWdcSYqP/Y1dQP/u0vJUl84Su+mYqq0Wm5ydsPMSMXC+ajLMrJTZOZgvkICypnRQ6yqmPS6mSrzElObqbNbtLmOvKqI6dK8vIwY6nlRv2xq/zZ13+ojeMffTEpK9NykVYNs3KT1WGWVMmS04shF1OmBmZUx7znk8x+8HfIqYyU6pkz15KSi2WTl7zcLMnDjNnNiKmC9PvuuqJZszc5Kzs51TOvKtImLykdIicneVVy3XQXS00/odjfxfrNt1j9RT8ztkYWdJis1cusqlg0e1lQLRm5yVq9TKmKN1VpaFY1xpK5goL1KDnVkLU0kFIjKTm4pTqmnR9i+6UgXH2Vzfwyqy9cJmc6wnWzhwWTh5SqWbB4ScvNnKpZsjWwZKlnUR5DKbmNrOzkVc+C3GTM9WRsx0jJQcxuoqDDvGU/yozuhLksC/EBZlQOpnqyqiGtGtLmOlKmWuZNtWRVS1YuluU2lDM1JDOyk5GbJdUxLw9Za0l8RmLB5GHC4SKrY+zNTZN/4TxLcpN7Z2/B5GFWLmblImv1klEtc6oiqxpDKXN9MmOtIKNaluQhZfKQUiMZOUnJQsruJWeuZEteyKbYO3eRRfth8qYqFq31LFrrmVcNKblIm+tIWzykLR7mbZ5JTajKSNmczMlNTnWkTB5m5CVvqWbFXMu4xU3OVM2qaikWM+xe+AWGtZGsqrmpanJmD0uW+tK/cjFrcnPTWsdbpuqkJk0fTmZVwbTDRs5SQ9LsZUm1TLqqWLe6mLLXsqjbmLXeA7lr8HyIseo7WdIxsqpj2lxH0uYibammoEpW5MSwV/OaqzqhKd1lbKiGRXs5s6pkWkco6hBpudmQjWk5mL3304x/6StszkfYeTFE8gtfInf4blZ0DEPVvGWtYa6qgYzdw6JcrMrNpryGZnWHsaVqtiwuUnJhVP4WqzrGgqmBpO7iRsP9MDAGO7sU2GNjbw321+DFK0w7byOlBjbNR1iTm4wcLMpDTh6W1Who9PZPvzSjSnIqZ85UxZuVDcyqiqwqWSirISUH8x/9FBO/9zkWP/un5P7gAea/9ACzt32QBXmYVzWLcnNTTmasNdyobCBqdfGrumMR5b71j9+f836IjKrIq4qblmoW5GTN5GTKWU7eVMW6qTRiOzpCRjXk5GJTLnLWRqbkImX3smrxsqV6ZlXFpPcOePChh0U06lz95j88fPPwJwamdcSYktdIy2usyGvMmeuSM6o2tnTIWLIen7ypBmPY5p2csTdev2nyJtO63ZjW+4wZ3WbcVKOR0XHjzcZPDMx89++/zaOPmt/Tp/6AAw74n+DRR81c/toP86dqh9Y7aiP5Nvv1rSYZ2x0y8i0y0i0yiicd48tN9omtFhn8xz39+48rufqcjC2fjK0WU7LQZJ3c8MnYarNdz3cef3F34HsPUoh6xJUffXX11B1kW8so+C2sdor9VhMbbWLZX8XeM2a228VOi5W1VrHTXsb6UxXkW0SxTRTbbay1WSn4xbpf5JotZE5/kt2B7z2opTN39+V8Ys3vZM0v1k6Kfb+dNb9YbTFRaBErbXZWuz/F9Jnf5ea5jzDf8WH2TomVdrHaYWOp3UqhXWyfFCutpQT5zuMvauGkjM0TYr+9kWKLWOkUOy1lFE842G4XS74y+OUrkLsBG0XYyrMba2HpaRMFf6nyZb+N5Tax+XQpwbpfbLXZrivnl7HnF3vNt7HhEysdYr3ZTKGjnO2nyll/9ghc6yI9/HVyl7/I3CuPwUqWt994nG2f2G21sdFcxnKzmeU2UWgXBb/Y8MnQcpuMvRax+dNDbLeK4skyNprESpuV9Vax1CJmz9Qw31bG7hPievtx2Jhl7sqP2GoS+y029n3OUgJ/yaK1NiuFJuuk8h3myd0WsdFczt4JUWxzsekTq37xdusH2W+yk/WLXZ8bfiKWzn4NVlfY/cW/stwiNnxm9lts7LbaKLbbWO0orVstpqTSfhnrPrHeKrb9Iv9UNTutYqPDzNaTgmaxcrKMxRMVbLYLpl5hO32BfKuZdIeN5Rax1SS2fSU7VtpLU7Tlk6Giz5SkSaQ6xE672GsuY+mkoNXJ3mNi4cz7WPKJ4qla9uausjf5CusnHOw1i/UOUewQax2W0kS1llHwW9luF1ttMrTcLuNWq5h/xsx6h1jxlWOcFksnxW6bKD4l8l1emOzn1o1nmA1Vk29xkD8l9lotrP9MFJ80semzs+e3s9sqdlvFTqsMpTvt17d/JgptFfCEh70ff4AVXzl7zWXQLPZ8glgEjBvshP+C9Wf+hNSZeyg+dYxln4W1NgtrnaLwdClWO8Rym4O8vyaizNPHrmw+KfZPCJod8ISH9XcsSpyqZO2N51hmlwWAlTTsFmEfVqP/wkaz2D9hYtdfOmHBJ4onxHq7idV257gWu+/ryvvEZnspQaGtgvlnzKQ6xGazoK2K9a67mXvhXhYCfwgn/wq6PsNqs5eiT2z5atj66VG2nzzGjt9Loa2MhRMW8qcqE1p6/TsPpU9Xk/eJzSfF9s/ErVZBU6mpqz8R+MWuT6ROlG4hTwhaxHaH2GkV281iv01snhCZp8RK5z3w8wcf1trcG7VLr3/nocXu+7oyTx+7ku60X19ul1H0mZKrjyuZP11/da3Zfp0nK8aXfTKmO2XsdrlihcdlZPyO8cW2itFFn5KLbTLyp2QsdN15mSv/9Neko873+sU/4IAD3jsW1q8cGpn9u2+eH77vdGjo6KuBYdv17mEZoYSM4HBlon+0MhGIyAhElQzHHOOhmJL9vzJP9sXLJkIJGaGYjO7h0tqXqExciH8knJj93oMFLr5fsZnvfvtC/G5Ov1pGz7DoTdgJx02Eoy66IyI0UoruYSvhaAO9Iw7OxkTXkOgdEf3jZkIJEYiLQEx0vWbl+ejHGUv/7fd1MfHxnlC0nEBU9I6J3oSZYEx0vWbn0ptenh0wE47Wcz5+Nxfj93MxcR/dbxyif8xN96CNvribcKSOUKSK/tFKAkPlnBlwcT76gYsKDLpioXipimBcBAarOTfq4PzIYZ6Lie5hD1MrLWzeSrN5K0fx7beIzPwzXRHRExPhhOgetPHcgIVgxErfiI1w3EZfojKh7qtK9o6IUMxKICbOvF7GmeF3EkW9hEdqeSX5x7x8/av8fOILpAoXyG/HOZ/4FMGIg95oLeFIHcFhJ6F46fShURFMyFAwKiMct3D29Qr6Eg76okcJxsW5MROBuIOzCXF20EsgWsezg2I09RibzNAf/yQ9URGMinOjDs6N2gnGRCAiwtFqeiONAwoNH341+E7V3cNWwiNWzg6WEYyLrkERilXTPVjFSxNfZGDi+2RWBpldfJnQmOgdtXBmSJwdMhGMldEzXEYg4iCcKCcYL5tQYLB2KBAzERoRgaid8IiVQMRJeMRK/3gFoXHx8uRn2GebW7cgX5xkKhPk9ICdUMJCT8RMKG6jb7ScQNRKT8RCMGalJ2JK6uzVitGemOgbF4GolVDCQihWXUoStdOdEKFYJS9fe4BfTn2e8bnH2Lw1yUvXPvdrob5RB72jNnqiKlkVF4GoDHUPOce7o6L/mghELXRHRDBaRSBq4ezrhzgzJJ4fO8pzr5XxzFUxcO1bvM0WiZl/pydiIxC1Eoyb6YmK7mhp3sMjIpSQocBQZeLMcKnynsh/iVcQiJnoS9TSnzjOWOYhnk98hN5EJfFkE8XNRYZvfJdgtGRFd+S/hYPvXKaeiCmp3ljjwJkhEUyUPA/ETPQmqgklTHTFxKWx32brlsHaVpLi2xHWN4tML/QSjtUQijkJxkp2BBOib8xMMGbl7KCN7sGKUV2+dndfIOKgJ6rSx3ERjlcQGhHnf1XJs2+In4//Pq+9+TcMGQ9xKfZHBIar6B6yE4o7Ss2LlqzoHbXQPWQnMOzmhYn3X9LrM/d39iVq6YmYCcerCMRKJ+iJibOD5fSOOOmNu3luuNSs0PBRQmPibFSE4o5f9ykQU6nqq07Oj9zOUOb+TqXTUedo6gd/fjFxT19g2DoZiMjoGTJPhqOuWE/EPPmbIhx1xXoGyyZ6hsyToaiMniHHeH/kY8GxuUe/VuCK571+8Q844IAD/nf48ejOl+/vm+u8v2+u88ejO19+14QfH8k+cOfp9KXy56H8ebjzdPrS4yPZB94V8TsuZC41ngd3eBt3eJvG83DHhcyld0X83pfSYWdgnYaLpXAG1rn3pXT4XRF/ZHzhG8cvr16uPbdD7bkdjl9evfzI+MI33hVxSXpkYuMbnw9kmz4fyDY9MrHx7gkfcMD/A/4T3vIlrgH/9lkAAAAASUVORK5CYII=) no-repeat 0px -77px; border-bottom: #e4e4e4 1px dashed;vertical-align: middle;color: #717171; overflow:hidden;}
.panel .xlmmcons li a {color: #717171;float: left;line-height: 24px;height: 24px; padding-left:30px;}
.panel .xlmmcons li.titbg1 {background-position: 0 -2px;}
.panel .xlmmcons li.titbg2 {background-position: 0 -28px;}
.panel .xlmmcons li.titbg3 {background-position: 0 -54px;}
.panel_tt ul li a.active {position: relative;height: 27px;_height: 26px;background-color: #fff;border: #dbdbdb 1px solid;border-bottom: none;font-weight: bold;}
.panel .xlmmcons ul {width: 50%;float: left;overflow: hidden;height: auto;}
.panel .xlmmcons li {height: 24px;padding: 0 0 0 5px;font-size: 12px;line-height: 24px;border-bottom: #e4e4e4 1px dashed;vertical-align: middle;color: #717171; margin:0 5px;}
.panel2 {width: 30%;overflow: hidden;}
.panel2 .xlmmcons {width: 100%;height: 205px;overflow: hidden;background: #fff;}
.panel2 .xlmmcons ul { width: 100%;float: left;overflow: hidden;height: auto;}
.panel2 .xlmmcons li {height: 24px;margin: 0 5px;font-size: 12px;line-height: 24px;border-bottom: #e4e4e4 1px dashed;vertical-align: middle;color: #717171;}
.panel2 .xlmmcons .imgs {width: 25px;margin:0 5px;}
.panel2 .xlmmcons .imgs img {height: 20px;width: 20px;border-radius: 50%;border: none !important;margin: 2px 0 0 0px;padding: 0 !important;}
.panel2 .xlmmcons li span {display: block;height: 24px;float: left;overflow: hidden;text-align: left;}
.panel2 .xlmmcons .f4top {width: 41%;}
.panel2 .xlmmcons .f4top a{ margin-left:5px;}
.panel2 .xlmmcons .guanzhu {width: 18%;margin-top: 3px;height: 21px;}
.panel2 .xlmmcons .tit {width: 41%;}
</style>


<div style="margin-bottom:-5px; margin-top:20px;">

<div class="indexlistwrapper cl">
<div class="z panel">
<div class="z" style="width:280px;">
<div style="background:#fff; padding:5px; width:260px;">
<div style="width:260px; height:220px;">
		<!--[diy=hd1]--><div id="hd1" class="area"></div><!--[/diy]-->
</div>
</div>
</div>
<div style="margin-left:280px;">
<div class="panel_tt">
<b>帖子</b>
<ul>
<li><a id="4tab_1" onmouseover="switchTab('4tab',1,3,'active');" class="active">24小时热帖</a></li>
<li><a id="4tab_2" onmouseover="switchTab('4tab',2,3,'active');">看最新贴</a></li>
<li><a id="4tab_3" onmouseover="switchTab('4tab',3,3,'active');">最新回复</a></li>
</ul>
</div>

<div id="4tab_c_1" class="xlmmcons" style="display: block;">
<div class="view-hover">
		<!--[diy=ng24]--><div id="ng24" class="area"></div><!--[/diy]-->

</div>
</div>
<div id="4tab_c_2" class="xlmmcons" style="display:none">
<div class="view-hover">
		<!--[diy=ngxt]--><div id="ngxt" class="area"></div><!--[/diy]-->

</div>
</div>

<div id="4tab_c_3" class="xlmmcons" style="display:none">
<div class="view-hover">
		<!--[diy=nghf]--><div id="nghf" class="area"></div><!--[/diy]-->

</div>
</div>

</div>
</div>
<div class="y panel2" id="gzskkkk">
<div class="panel_tt">
<b>会员</b>
<ul style="width:200px;">
<li><a id="4tabhy_1" onmouseover="switchTab('4tabhy',1,2,'active');" class="active">积分排行榜</a></li>
<li><a id="4tabhy_2" onmouseover="switchTab('4tabhy',2,2,'active');" class="">发帖排行榜</a></li>
</ul>
</div>
<div id="4tabhy_c_1" class="xlmmcons" style="display: block;">
		<!--[diy=ngjfb]--><div id="ngjfb" class="area"></div><!--[/diy]-->
</div>
<div id="4tabhy_c_2" class="xlmmcons" style="display: none;">
		<!--[diy=ngftb]--><div id="ngftb" class="area"></div><!--[/diy]-->
</div>

   
</div>
 </div>

       <script>
                document.getElementById("gzskkkk").innerHTML = document.getElementById("gzskkkk").innerHTML.replace(/xlmmnggzs/g, "{FORMHASH}");
        </script>


</div>


<div class="xlmmforum">
<div class="xlmm-content pablbox">
<div class="main-content">
<div id="infobox" class="section-info">

	<span class="info1">
		今日 $todayposts
	</span>
	<span class="info2">
		昨日 <i>$postdata[0]</i>
	</span>

	<span class="info3">
		帖子 <i>$posts</i>
	</span>
	<span class="info4">
		会员 <i>$_G['cache']['userstats']['totalmembers']</i>
	</span>
	{if $_G['cache']['userstats']['newsetuser']}<span class="info5">
		新会员 <a href="home.php?mod=space&username={echo rawurlencode($_G['cache']['userstats']['newsetuser'])}" target="_blank" class="xi2">$_G['cache']['userstats']['newsetuser']</a>
	</span>{/if}
</div>
			<!--{if empty($gid) && !empty($forum_favlist)}-->
			<!--{eval $forumscount = count($forum_favlist);}-->
<!-- 收藏的版块 -->
<ul class="section-list">  
<li>
<h4 class="section-title">
<span class="st-cate-name">我收藏的版块</span></h4>
<div class="section-bd clearfix">
  						<!--{eval $favorderid = 0;}-->
						<!--{loop $forum_favlist $key $favorite}-->
						<!--{if $favforumlist[$favorite[id]]}-->
						<!--{eval $forum=$favforumlist[$favorite[id]];}-->
						<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
<div class="sec-item">
		<em>								<!--{if $forum[icon]}-->
									$forum[icon]
								<!--{else}-->
									<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="template/xlmm_zx/image/noicn.png" alt="$forum[name]" style="width:100px; height:75px; margin-left:0" /></a>
								<!--{/if}-->
</em>
		<div class="sec-info">
<h3>
	<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a>
					<!--{if $forum[todayposts]}--><span>$forum[todayposts]</span><!--{/if}-->
</h3>
<p class="sec-desc" style="max-height:45px; overflow:hidden;">{if $forum[description]}$forum[description]{else}本版暂无简介。{/if}</p>
<p class="sec-today">
	<span>主题 {echo dnumber($forum[threads])}</span>
	<span>帖子 {echo dnumber($forum[posts])}</span>
</p>
</div>
</div>
									<!--{hook/index_favforum_extra $forum[fid]}-->
										<!--{hook/index_favforum_extra $forum[fid]}-->
						<!--{/if}-->
						<!--{/loop}-->
</div>
</li>
</ul>
			<!--{ad/intercat/bm a_c/-1}-->
		<!--{/if}-->


<!-- 板块页主体部分 -->
<ul class="section-list">
<!--{eval $gidiconnum = 0;}-->
<!--{loop $catlist $key $cat}-->
			<!--{hook/index_catlist $cat[fid]}-->
<!--{eval $gidiconnum ++;}-->  
<li>
<h4 class="section-title">
<span class="st-cate-name">$cat[name]</span>
	{if $cat['moderators']}<span class="fadmin y mr10">分区版主:&nbsp;&nbsp;$cat[moderators]</span>{/if}
</h4>
<div class="section-bd clearfix">
<!--{eval $i++;}-->
  <!--{eval $fidnum = 0;}-->
									<!--{eval $kf = 1;}-->
	<!--{loop $cat[forums] $forumid}-->
<!--{eval $forum=$forumlist[$forumid];}-->
<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
<!--{eval $forumfid = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : ''.$forum['fid'];}-->
<!--{eval $fidnum ++;}-->
	<div class="sec-item">
		<em>								<!--{if $forum[icon]}-->
									$forum[icon]
								<!--{else}-->
									<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="template/xlmm_zx/image/noicn.png" alt="$forum[name]" style="width:100px; height:75px; margin-left:0" /></a>
								<!--{/if}-->
</em>
		<div class="sec-info">
<h3>
	<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a>
					<!--{if $forum[todayposts]}--><span>$forum[todayposts]</span><!--{/if}-->
</h3>
<p class="sec-desc" style="max-height:45px; overflow:hidden;">{if $forum[description]}$forum[description]{else}本版暂无简介。{/if}</p>
<p class="sec-today">
	<span>主题 {echo dnumber($forum[threads])}</span>
	<span>帖子 {echo dnumber($forum[posts])}</span>
</p>
		</div>
	</div>
								<!--{hook/index_forum_extra $forum[fid]}-->
								<!--{hook/index_forum_extra $forum[fid]}-->
									<!--{hook/index_datacollection_extra $colletion[ctid]}-->
	<!--{/loop}-->
	</div>
</li>
<!--{/loop}-->
</ul>
</div>
		<!--{hook/index_middle}-->
<style type="text/css">
.bm {border: 0px;}
.bm_c {padding: 0 15px 10px 15px;}
</style>
  <!--友情链接-->
<div style="margin-top:15px; background:#fff; padding-bottom:10px;">
<h3 class="modname">友情链接</h3> 		
<div class="bm lk">
			<div id="category_lk" class="bm_c">
				<!--{if $_G['cache']['forumlinks'][0]}-->
					<ul class="m mbn cl">$_G['cache']['forumlinks'][0]</ul>
				<!--{/if}-->
				<!--{if $_G['cache']['forumlinks'][1]}-->
					<div class="mbn cl">
						$_G['cache']['forumlinks'][1]
					</div>
				<!--{/if}-->
				<!--{if $_G['cache']['forumlinks'][2]}-->
					<ul class="x mbm cl">
						$_G['cache']['forumlinks'][2]
					</ul>
				<!--{/if}-->
			</div>
		</div>
</div>
		<!--{hook/index_bottom}-->
</div>



<div style="position: relative; width:340px; overflow:hidden;" class="y allboxs">
 <div id="rlboxs">
<!--{hook/index_side_top}-->
{if $_G['cache']['plugin']['dsu_paulsign']['ifopen']}
<style>
.xlmmbtn_sign {width:340px;height:55px;line-height:55px;margin-bottom:10px;overflow:hidden;clear:both;}
.xlmmbtn_sign_left {width:50%;height:55px;float:left;background:#68c04a}
.xlmmbtn_sign_right {width:50%;height:55px;float:left;background:#ffa64f}
.xlmmbtn_sign:hover .xlmmbtn_sign_left {background: #55BD64; color:#FFFFFF;}
.xlmmbtn_sign:hover .xlmmbtn_sign_right {background:#f99d43; color:#FFFFFF;}
.xlmmbtn_signed .xlmmbtn_sign_left {background:#43b56b}
.xlmmbtn_signed .xlmmbtn_sign_right {background:#6acb8c}
.xlmmbtn_signed:hover .xlmmbtn_sign_left {background:#3baa62}
.xlmmbtn_signed:hover .xlmmbtn_sign_right {background:#5dc080}
.xlmmbtn_sign .icon_sign {float:left;margin-left:23px;_margin-left:10px;margin-top:14px;margin-right:14px;}
.xlmmbtn_signed .icon_sign {background-position:0 -28px;margin-right:5px}
.xlmmbtn_sign_left p {float:left;width:70px;height:55px;line-height:55px;text-align:left;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.xlmmbtn_sign_right .lineTop {width:100%;height:27px;line-height:37px;_line-height:27px;font-size:14px;margin-bottom:1px;text-align:center;vertical-align:bottom}
.xlmmbtn_sign_right .lineBtm {width:100%;height:27px;line-height:16px;font-size:14px;text-align:center;vertical-align:top;}
.xlmmbtn {display: block;cursor: pointer;border-radius: 2px;color: #fff;font-size: 20px;}
 .xlmmbtn_sign .icon_sign {float: left;margin-left: 23px;_margin-left: 10px;margin-top: 14px;margin-right: 14px;}
.icon_sign {width: 28px;height: 28px;background: url("$_G['style']['styleimgdir']/sideSprite.png") no-repeat 0 0;_background-image: url("$_G['style']['styleimgdir']/sidebar/sideSprite.gif");}
</style>

	{eval include TPLDIR.'/php/qian.php';}
        <a {if $countxlmm[0][dd] ==0} onclick="showWindow('dsu_paulsign', 'plugin.php?id=dsu_paulsign:sign')" href="javascript:" {else} href="plugin.php?id=dsu_paulsign:sign" target="_blank"{/if} class="xlmmbtn xlmmbtn_sign">
            
            <div class="xlmmbtn_sign_left"><i class="icon icon_sign"></i><p> {if $countxlmm[0][dd] ==0}签到{else}已签{/if}</p></div>
            <div class="xlmmbtn_sign_right"><p class="lineTop">今日签到</p><p class="lineBtm"><span id="today_count_sign">{loop $xlmmtotal $key $xlmmtotal} $xlmmtotal[todayq] {/loop}</span>人</p></div>
        </a>
{/if}
		<!--[diy=rt]--><div id="rt" class="area"></div><!--[/diy]-->
<!--{hook/index_side_bottom}-->
</div>
</div>
<div class="clearfix"></div>
</div>
<script type="text/javascript">
jQuery("#act_A").slide({mainCell:".xlmmano",effect:"topLoop",autoPlay:true,vis:10,scroll:1,trigger:"click",interTime:5000});
</script>
<style>
body {
	background: #eaeaea;
}</style>

<!--{template common/footer}-->



