<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
{eval
	$filter = array( 'common' => '{lang have_posted}', 'save' => '{lang draft}', 'close' => '{lang closed}', 'aduit' => '{lang pending}', 'ignored' => '{lang ignored}', 'recyclebin' => '{lang recyclebin}');
	$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=thread&view=me\">{lang they_thread}</a>";
}

<!--{if $diymode}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
		<div id="ct" class="ct2 wp cl">
			<div class="mn">
				<div class="bm">
					<div class="bm_h">
						<!--{if $space[self]}--><span class="xi2 y"><a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="addnew">{lang posted}</a></span><!--{/if}-->
						<h1 class="mt">
							<!--{if $_GET[type] == 'reply'}-->
							<span class="xs1 xw0"><a href="home.php?mod=space&do=thread&view=me&type=thread&uid=$space[uid]&from=space">{lang topic}</a><span class="pipe">|</span></span>{lang reply}
							<!--{else}-->
							{lang topic}<span class="xs1 xw0"><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=reply&uid=$space[uid]&from=space">{lang reply}</a></span>
							<!--{/if}-->
						</h1>
					</div>
				<div class="bm_c">
	<!--{else}-->
		<!--{template common/header}-->
		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="ct1 wp cl">
			<div class="mn z" style="width:685px; ">
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<div class="bm bw0">
					<div class="bm_c">
	<!--{/if}-->
<!--{else}-->
	<!--{template common/header}-->
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ct" class="ct2_a wp cl">
	<!--{if $_G[setting][homestyle]}-->
		<div class="appl">
			<!--{subtemplate common/userabout}-->
		</div>
		<div class="mn pbw">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<ul class="tb cl">
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
	<!--{else}-->
		<div class="appl">
			<div class="tbn">
				<h2 class="mt bbda">{lang thread}</h2>
				<ul>
					<li$actives[we]><a href="home.php?mod=space&do=thread&view=we">{lang friend_post}</a></li>
					<li$actives[me]><a href="home.php?mod=space&do=thread&view=me">{lang my_post}</a></li>
				</ul>
			</div>
		</div>
		<div class="mn pbw">
		<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
	<!--{/if}-->
<!--{/if}-->
		
		<!--{if !$diymode && $space[self]}-->
			<!--{if $_GET['view'] == 'me'}-->
			<p class="tbmu bw0">
				<!--{if $viewtype != 'postcomment'}-->
					<span class="y">
					<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=" {if !$_GET[filter]}class="a"{/if}>{lang all}</a>
					<!--{loop $filter $key $name}--><span class="pipe">|</span><a href="home.php?mod=space&do=thread&view=me&type=$viewtype&from=$_GET[from]&filter=$key" {if $key == $_GET[filter]}class="a"{/if}>$name</a><!--{/loop}--> &nbsp;
						<select name="forumlist" id="forumlist" class="ps vm" onchange="viewforumthread(this.value);" style="width: 120px; word-wrap: normal;">
							<option value="0">{lang follow_select_forum}</option>
							$forumlist
						</select>
					</span>
				<!--{/if}-->
				<a href="home.php?mod=space&do=thread&view=me&type=thread" $orderactives[thread]>{lang topic}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=reply" $orderactives[reply]>{lang reply}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=me&type=postcomment" $orderactives[postcomment]>{lang post_comment}</a>
				<!--{if $viewtype != 'reply' && $viewtype != 'postcomment'}-->&nbsp; <input type="text" id="searchmypost" class="px vm" size="15" /> <button class="pn vm" onclick="searchpostbyusername($('searchmypost').value, '$_G[username]');"><em>{lang search}</em></button><!--{/if}-->
			</p>
			<!--{elseif $_GET['view'] == 'all'}-->
			<p class="tbmu bw0">
				<a href="home.php?mod=space&do=thread&view=all&order=dateline" $orderactives[dateline]>{lang newest_thread}</a><span class="pipe">|</span>
				<a href="home.php?mod=space&do=thread&view=all&order=hot" $orderactives[hot]>{lang top_thread}</a>
			</p>
			<!--{/if}-->
		<!--{/if}-->
		
		<!--{if $diymode && !$_G[setting][homepagestyle] }-->
	<div id="uhd">
<ul class="tb cl" style="padding:0">
		<li{if $_GET['wz']} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread&wz=1" >文章</a></li>
		<li><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread"{if $_GET['wz']}{else} $orderactives[thread]{/if}>{lang topic}</a></li>
			<li><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=reply" $orderactives[reply]>{lang reply}</a></li>
		<li{if $do==profile} class="a"{/if}><a href="home.php?mod=space&uid=$space[uid]&do=profile&from=space">{lang memcp_profile}</a></li>
</ul>
	</div>
	<!--{/if}-->
		
<!--{if $_GET['grzl'] || $_GET['wz']}-->
<style type="text/css">
/*内容列表*/
#uhd .xlmmhht {    margin-bottom: 15px;}
.bm_c {padding: 0px;}
.Card {margin-bottom: 15px;background: #fff;}
	.tjcard {margin-bottom: 0;box-shadow: none;border-bottom: 1px solid #F0F2F7;background: #FFFFFF;overflow: hidden;border-radius: 2px;box-sizing: border-box;}	 
	.tjcard li{display: inline-block;padding: 0 20px;}	 
.tjcard li a {position: relative;display: inline-block;padding: 18px 0;font-size: 16px;line-height: 22px;color: #1A1A1A;text-align: center;}
.tjcard li.a a, {font-weight: 600;font-synthesis: style;}
.tjcard li.a a::after{position: absolute;right: 0;bottom: -1px;left: 0;height: 3px;background: #0084FF;content: '';}
.xlmm-sx {width:660px !important;}

.relatedFeed {position: relative;}
.relatedFeed .item {position: relative;}
.relatedFeed .item-inner {position: relative;padding: 10px 15px;border-bottom: 1px solid #e8e8e8;}
.relatedFeed .normal.rbox {float: right;height: 102px;width: 482px;}
.relatedFeed .normal {position: relative;font-size: 0;overflow: hidden;}
.relatedFeed .normal::before {content: '';width: 0;font-size: 0;height: 100%;visibility: hidden;display: inline-block;vertical-align: middle;}
.relatedFeed .normal .rbox-inner {display: inline-block;width: 100%;vertical-align: middle;}
.relatedFeed .title-box {display: block;font-size: 20px;color: #000042;line-height: 1.3;margin-bottom: 4px;font-weight: 700;}
.relatedFeed .title-box a {color: #222;}
.relatedFeed .link.xlmmtit:hover {color: #eb7350;}
.relatedFeed .footer {font-size: 12px;color: #999;height: 18px;line-height: 18px;margin-top: 10px;}
.relatedFeed .lbtn {float: left;display: inline-block;color: #777;font-size: 14px;}
.relatedFeed .lbtn.media-avatar {position: relative;color: #fff;margin-right: 2px;width: 18px;height: 18px;line-height: 17px;text-align: center;font-size: 12px;border-radius: 50%;background-color: #eee;overflow: hidden;}
.relatedFeed .lbtn.media-avatar::before {content: '';position: absolute;top: 0;left: 0;width: 18px;height: 18px;border-radius: 50%;background-color: rgba(0,0,0,.08);}
.relatedFeed .lbtn.media-avatar > img {width: 100%;height: 100%;}
.relatedFeed .lbtn {float: left;display: inline-block;color: #777;font-size: 14px;}
.relatedFeed .lbtn.source:hover, .relatedFeed .lbtn.comment:hover {color: #406599;}
.relatedFeed .lbtn.recommend {font-size: 12px;color: #2a90d7;height: 14px;line-height: 14px;border: 1px solid #2a90d7;padding: 0 2px;margin-top: 1px;margin-left: 8px;}
.relatedFeed .lbox .img-wrap {display: block;width: 156px;height: 100px;border: 1px solid #e8e8e8;background: #e8e8e8;overflow: hidden;}
.relatedFeed .img-wrap img {width: 100%;height: 100%;-webkit-transition: all .5s ease-out .1s;transition: all .5s ease-out .1s;}
.relatedFeed .img-wrap:hover img {-webkit-transform: matrix(1.04,0,0,1.04,0,0);-ms-transform: matrix(1.04,0,0,1.04,0,0);transform: matrix(1.04,0,0,1.04,0,0);-webkit-backface-visibility: hidden;backface-visibility: hidden;}

.pgbtn a {display: block;height: 40px;line-height: 40px;letter-spacing: 5px;text-align: center;border: 0;font-size: 12px;outline: none;border-radius: 5px;box-shadow: 0 0 0 #fff;}
.pg {float:none;display:inline-block;}
.pg strong {background-color: #3297fc;color: #fff;}
.pg a, .pg strong, .pgb a, .pg label {border: 0;}


.tns th, .tns td {font-size: 14px;color: #777;text-align: center;line-height: 1.6;}
.tns th {border-right: 1px solid #e1e1e1;}
.tns th.cb0 {border-right: 0;}
.tns th p, .tns td p {font-size: 18px;color: #1a1a1a;font-weight: 600;font-synthesis: style;text-align: center;line-height: 1.6;}



.tl .th th {height: 52px;line-height:52px;background:none!important;padding:0}
.tl .xlmmtf.tf {-webkit-box-shadow: 0 1px 3px rgba(26,26,26,.1);box-shadow: 0 1px 3px rgba(26,26,26,.1);border-bottom: 1px solid #ebebeb;padding:0}
.tl .xlmmtf.tf .xlmmtfs a{padding: 14px 20px;font-size: 16px;line-height: 22px;color: #1a1a1a;text-align: center;}
.tfssx{padding:16px 10px;}
.tfssx a, .tfssx span{font-size: 14px;color: #8590a6!important;}

.module { width: 300px;border-top: 2px solid #ed4040;background-color: #fff;margin-bottom: 16px;}
.module-head { color: #222;padding-top: 15px;padding-left: 20px; font-size: 18px; font-weight: 700;}
.news-content {padding-left: 20px;padding-right: 20px;}

.news-head{margin-bottom:6px}
.news-content{padding-left:20px;padding-right:20px}
.news-list{padding:8px 0;}
.news-list:last-child{border-bottom:0}
.news-link{display:block;overflow:hidden}
.news-pic{width:80px;height:60px;margin-right:12px;float:left}
.news-pic img{width:100%;height:100%}
.news-inner{height:60px;display:table-cell;vertical-align:middle}
.news-inner p{vertical-align:middle;font-size:14px;line-height:20px;max-height:40px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}

.xlmmntss { text-align: center;padding: 200px 50px;color: #777;}
.xlmmntss:before {  content: " ";display: block;height: 110px;background: none,url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEQAAABmCAYAAABydzePAAAHTElEQVR4nO2ca27bOBDHcwQfIUfIDZIbbG+Q3KC9QXKD5gbJCTbZbbeL3S6QdBEU6QtJ04o0KU5Gjp/1S7JeXqBAvR8kyoojyS/ZllP9AX6xLIr6aUjOkCNtbMwpRCwQBqhwuJq3rkchquIO4TAgHAarbksmlAMZ0U8JBBELVIV9RCyMHvspgSgMDgiHgcLhahSKwnHrpwOCiAWFwXUcFKLCM8LEk1W1byUaB+WnVBgK5WJv1e3JhHwoB/NaCEXcpIibKTVrvUQRNwmHp4SJEzkAPyhMnFAmdjMJyZtmcTtcFI5b09ZDETcVDkfRAEAjHIyoYwqHo0yBIQww8iZUeDZxHRye37tJJk4pF3tRXQ0RC5SLPYWJ0/A5VIX9dO9sRsmBM8Ksx06tiFggXJwNzxPH0zxtr3uJ47C1rO2MhogFhcOVfzPGLN1MijDxRHaptZ3m5aCpMLhOYwxQOG75Y81A4XCUQhOXJ+nez2sZD+r1QgPDB32QVr0LlT+b6N5AiDtp1+93n4HCQV+LriMHQYWJ0wVe49y3wMNFXSMVebOKP02Gxg1ELMQ9zaRjcZLLDAoHfc4mL1aUiz05kIZ/VzjohAFGnZN0LEmBO5DlyDpwpkactqQ1klnXTwiHQ+nbzNjcxUv27dHBdBFAhqtz4ny21i5BUeNH+Pekc6a9Vmgcye6WR9zN+eYdOSMkHZv1epnRshuYeSDBCtoCHLIoxXXRzChuUH0s15taQy91OXFG5oEEezYRQKJW3qiK2/PEI4ELn1XnjKjwLC6OkQFfxPLh1F5qcD3fOcts5JvkLHmNF+cPy+wBWpJFZkLLDrpC6y7ZjXqX6RvItZG1dN8XobWIZ5bpnK0FkMA3WMJ+r78LmG33ffnOWcaBLHvkzzwQuYy4rH6dfSAJAx3lYo8wQC+XNZ39mswDicszCyfkzeuyh5V5IBsbw0aGAze56U1V3AlinhSsZF2AGGFfZGg13gp5MF0mpFRQFfYJF2eEiZMkn2ZNgNwPy4Mtg1CYnjQTDQfmUH5IjF+zJkCCPZMzPy1CJwy0+//xot3I872BVwt1LyMOij8eaQ9ryZD8LmEkPWGFidOoqFh2r/D/w7v+4d+D6HqCfWQvPUOcEQ5PV7IGG9wEAy1qrJAOXMQezmHk70Fk66VXUcTNwAmcIL3rQSaUlyr2nKq4Pe+9piL5dMNPXHav0b1hqXAmUagYky5DeueL49E6FA66wuGIMrG70hQLwsFQOOhUxR0/r+Rq7OwzzDszCANt1qk7KrFvaD3iZPa7mkOhuOdeiuYyn9Iw6zHUpVY5SCsMDggDjTDQFCZOV2myMgU16MaEiRPPbMUZVWGfMrE771bBuijwfcLWIbP8ooq3jSDOFA5HVIV9RcVf0kyoW7UeWMfGxpASvy31eo5b0k3rS7OjX5Rr9SJguV4UGJObDiitinB4SlXczux+a4QirUNKWklXNy9stz8YKT8sx20YpnXT7hpvK/Vv7LZUrjOIAeV7q1484llVZub9kCKtQ0rSUqFUtt3+9wgo0cVx26bl3LR043210fyMdzXBbrVYULILes4R7K/KqhKtQ2qMlUxVLKdv9GyHtLrGp1qj/QUrtRsO8aB8WEvLVE60DqmZrWS64pi2Xezoxud6q/WpVK5/VW9LY6PbNDWRdUilaSXTlK5uXqS5ojbmHsdbh9SSrCSqfOdQqizaSqayDqnHbCVTWYdUkJnMQQe8u6xUm7+3Op3XhmX/ZTrOje327XW0kpmsQyppNiAcBipqb0vVxt/fWt0/9Z79wnTcD5bjdrJkJYhY8Hwgb502eFtjFtjyxi3bLRqmfdlsd8/vKvV3QiuzJFAMtK9apXpRb3b+6PTMV6btvrcdt7EMK6EqbhP55mfcO4OzrsPKk+MaPj0ovCndVd80Wq3fuj3rtGfa72y3r9lu/8csVqJw3KJM7BIOz0OvtI1YcdmsNprXes/6aDn92kKBpAWqKFDDUvVjo9n+taP3XvYs58Jy+1TFoZVQxM0o0w8XqsLgtlSu15utT4ZpXZu20xtt20qApAVqXCkKHGjl2m2zrX8wLJvYbv+/cW3IFJB5QTHAwV2tTlq6/sG0XIjqao8CSFwxTPtStsG0HS2NOtcaSPgG0q4vB5IDyYHkQHIgOZAcSA4kB5IDyYHkQHIgOZAcSA4kB5IDyYHkQHIgOZAcSA4khTZYjnvX1nsvoFT5JxUgUCoXy5XGZbOtnxm2fWnaLss6EMtxW13TfFUqV9/IOmSJe+NirGK/uLtEUFMCsXXTenNXa7yO2Aw3CBfHc3+Rxvu4q3iiMDhQmDgdByltUBMA+d6z7H8r35qvqHo7mp6eDoRJRBE3qYo73mse4jj0Wc9UQcUA+WE67vtmq/2iKLC0MgiTKAZU5GfKx4EybTfIArAcV7Vst9jsdF9y0L7eq8NLEDzM7BerouR/qUq+aXk4CajE4kN4TG9lBKIq7vhvNh0QLs5jX1V5zBCyrv8BZlPN6oJYPrMAAAAASUVORK5CYII=) center center no-repeat;}

</style>
{eval include TPLDIR.'/php/uview.php';$multis = multi($count, $perpage, $page, "home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread&wz=1");
}
		<div class="relatedFeed"> 
		<ul class="xlmmjz cl" pagesize="5">
		<!--{loop $lists $value}-->
			{eval include TPLDIR.'/php/portal_list.php';}
 <li class="item">
		  <div class="item-inner y-box"> 
		  <div class="normal rbox "> 
		  <div class="rbox-inner"> 
		  <div class="title-box"> <a href="portal.php?mod=view&aid=$value[aid]" class="link xlmmtit">$value[title]</a></div>  
		  <div class="y-box footer"> 
		  <div class="y-left">  
		 <span class="lbtn">$value[viewnum]阅读&nbsp;&nbsp;</span><a class="lbtn comment">$value[commentnum]评论&nbsp;&nbsp;</a><span class="lbtn">$value[dateline]</span>   
		  </div> 
		  <div class="y-right"></div> 
		  </div> </div> </div> 
 <div class="lbox"> <a href="portal.php?mod=view&aid=$value[aid]" class="img-wrap"><img src="{if $value[pic]}$value[pic]{else}template/xlmm_zx/image/nopic.gif{/if}" /> </a> </div> 
  </div> </li>
			<!--{/loop}-->
		 
		 </ul> 

</div>
<div class="pgs cl mtm">$multis</div>
<!--{else}--> 
		<!--{if $userlist}-->
			<p class="tbmu bw0">
				{lang view_by_friend}
				<select name="fuidsel" onchange="fuidgoto(this.value);" class="ps">
					<option value="">{lang all_friends}</option>
					<!--{loop $userlist $value}-->
					<option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
					<!--{/loop}-->
				</select>
			</p>
		<!--{/if}-->
		<div class="tl">
			<form method="post" autocomplete="off" name="delform" id="delform" action="home.php?mod=space&do=thread&view=all&order=dateline" onsubmit="showDialog('{lang del_select_thread_confirm}', 'confirm', '', '$(\'delform\').submit();'); return false;">
					<input type="hidden" name="formhash" value="{FORMHASH}" />
					<input type="hidden" name="delthread" value="true" />
<style type="text/css">
/*内容列表*/
#uhd .xlmmhht {    margin-bottom: 15px;}
.bm_c {padding: 0px;}
.Card {margin-bottom: 15px;background: #fff;}
	.tjcard {margin-bottom: 0;box-shadow: none;border-bottom: 1px solid #F0F2F7;background: #FFFFFF;overflow: hidden;border-radius: 2px;box-sizing: border-box;}	 
	.tjcard li{display: inline-block;padding: 0 20px;}	 
.tjcard li a {position: relative;display: inline-block;padding: 18px 0;font-size: 16px;line-height: 22px;color: #1A1A1A;text-align: center;}
.tjcard li.a a, {font-weight: 600;font-synthesis: style;}
.tjcard li.a a::after{position: absolute;right: 0;bottom: -1px;left: 0;height: 3px;background: #0084FF;content: '';}
 .ContentItem-meta {margin-top: 6px;font-size: 15px;color: #646464;}
.AuthorInfo {margin-top: 10px;}
.Avatar img {background: #FFFFFF;border-radius: 2px;vertical-align: top;width: 24px;height: 24px;}
.AuthorInfo-head {font-size: 15px;font-weight: 600;color: #444444;font-synthesis: style;margin-left: 10px;}
.AuthorInfo-detail {overflow: hidden;margin-left:15px;color: #646464;margin-top: 1px;font-size: 14px;}

.TopstoryItem {border-radius: 0;overflow: visible;overflow: initial;position: relative;padding: 20px;}
.ContentItem-title {font-size: 18px;font-weight: 600;font-synthesis: style;line-height: 1.6;color: #1A1A1A;margin-top: -4px;margin-bottom: -4px;}
.RichContent {line-height: 1.67;}
.RichContent.is-collapsed {transition: color 140ms ease-out;}
.RichContent-cover {position: relative;width: 190px;height: 105px;margin-top: -2px;margin-right: 18px;margin-bottom: 4px;float: left;overflow: hidden;background-position: center;background-size: cover;border-radius: 4px;-webkit-transform: translate3d( 0, 0, 0 );transform: translate3d( 0, 0, 0 );}
.RichContent-cover-inner {position: absolute;top: 50%;left: 0;height: 100%;width: 100%;-webkit-transform: translateY(-50%);transform: translateY(-50%);overflow: hidden;}
.RichContent-cover-inner img {position: absolute;top: 50%;left: 50%;width: 100%;-webkit-transform: translate3d(-50%, -50%, 0);transform: translate3d(-50%, -50%, 0);}
.RichContent-cover::after {position: absolute;z-index: 1;display: block;width: 100%;height: 100%;background: rgba(26, 26, 26, 0.02);content: '';}
.RichContent-cover + .RichContent-inner {margin-top: 16px;}
.ztext {word-break: break-word;line-height: 1.6;font-size: 15px;color: #1A1A1A;}
.ContentItem-more {padding: 0;margin-left: 4px;color: #175199;font-size: 14px;}
.ContentItem-actions {display: flex;align-items: center;padding: 10px 20px;margin: 0 -20px -10px;color: #646464;background: #FFFFFF;clear: both;}
.VoteButton {line-height: 30px;padding: 0 12px;color: #0084FF;background: rgba(0, 132, 255, 0.1);border-color: transparent;display:inline-block;font-size: 14px;border-radius: 3px;}
.Buttons {display: inline-block;margin-left: 24px;font-size: 14px;line-height: 32px;color: #8590A6;text-align: center;}

.ct2 .mn {width:685px;}
.tl .th, .tl td {margin-top: 0;padding: 0;border-bottom: 0;background: none;}
.xlmmpages {*zoom: 1;font-size: 14px;background: #fff;padding: 6px 10px;margin-bottom: 10px;border-radius: 2px;-webkit-box-shadow: 0 1px 3px rgba(26,26,26,.1);box-shadow: 0 1px 3px rgba(26,26,26,.1);-webkit-box-sizing: border-box;box-sizing: border-box;text-align: center;}
.pg {float:none;display:inline-block;}
.pg strong {background-color: #3297fc;color: #fff;}
.pg a, .pg strong, .pgb a, .pg label {border: 0;}


.tns th, .tns td {font-size: 14px;color: #777;text-align: center;line-height: 1.6;}
.tns th {border-right: 1px solid #e1e1e1;}
.tns th.cb0 {border-right: 0;}
.tns th p, .tns td p {font-size: 18px;color: #1a1a1a;font-weight: 600;font-synthesis: style;text-align: center;line-height: 1.6;}



.tl .th th {height: 52px;line-height:52px;background:none!important;padding:0}
.tl .xlmmtf.tf {-webkit-box-shadow: 0 1px 3px rgba(26,26,26,.1);box-shadow: 0 1px 3px rgba(26,26,26,.1);border-bottom: 1px solid #ebebeb;padding:0}
.tl .xlmmtf.tf .xlmmtfs a{padding: 14px 20px;font-size: 16px;line-height: 22px;color: #1a1a1a;text-align: center;}
.tfssx{padding:16px 10px;}
.tfssx a, .tfssx span{font-size: 14px;color: #8590a6!important;}

.module { width: 300px;border-top: 2px solid #ed4040;background-color: #fff;margin-bottom: 16px;}
.module-head { color: #222;padding-top: 15px;padding-left: 20px; font-size: 18px; font-weight: 700;}
.news-content {padding-left: 20px;padding-right: 20px;}

.news-head{margin-bottom:6px}
.news-content{padding-left:20px;padding-right:20px}
.news-list{padding:8px 0;}
.news-list:last-child{border-bottom:0}
.news-link{display:block;overflow:hidden}
.news-pic{width:80px;height:60px;margin-right:12px;float:left}
.news-pic img{width:100%;height:100%}
.news-inner{height:60px;display:table-cell;vertical-align:middle}
.news-inner p{vertical-align:middle;font-size:14px;line-height:20px;max-height:40px;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}

.xlmmntss { text-align: center;padding: 200px 50px;color: #777;}
.xlmmntss:before {  content: " ";display: block;height: 110px;background: none,url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEQAAABmCAYAAABydzePAAAHTElEQVR4nO2ca27bOBDHcwQfIUfIDZIbbG+Q3KC9QXKD5gbJCTbZbbeL3S6QdBEU6QtJ04o0KU5Gjp/1S7JeXqBAvR8kyoojyS/ZllP9AX6xLIr6aUjOkCNtbMwpRCwQBqhwuJq3rkchquIO4TAgHAarbksmlAMZ0U8JBBELVIV9RCyMHvspgSgMDgiHgcLhahSKwnHrpwOCiAWFwXUcFKLCM8LEk1W1byUaB+WnVBgK5WJv1e3JhHwoB/NaCEXcpIibKTVrvUQRNwmHp4SJEzkAPyhMnFAmdjMJyZtmcTtcFI5b09ZDETcVDkfRAEAjHIyoYwqHo0yBIQww8iZUeDZxHRye37tJJk4pF3tRXQ0RC5SLPYWJ0/A5VIX9dO9sRsmBM8Ksx06tiFggXJwNzxPH0zxtr3uJ47C1rO2MhogFhcOVfzPGLN1MijDxRHaptZ3m5aCpMLhOYwxQOG75Y81A4XCUQhOXJ+nez2sZD+r1QgPDB32QVr0LlT+b6N5AiDtp1+93n4HCQV+LriMHQYWJ0wVe49y3wMNFXSMVebOKP02Gxg1ELMQ9zaRjcZLLDAoHfc4mL1aUiz05kIZ/VzjohAFGnZN0LEmBO5DlyDpwpkactqQ1klnXTwiHQ+nbzNjcxUv27dHBdBFAhqtz4ny21i5BUeNH+Pekc6a9Vmgcye6WR9zN+eYdOSMkHZv1epnRshuYeSDBCtoCHLIoxXXRzChuUH0s15taQy91OXFG5oEEezYRQKJW3qiK2/PEI4ELn1XnjKjwLC6OkQFfxPLh1F5qcD3fOcts5JvkLHmNF+cPy+wBWpJFZkLLDrpC6y7ZjXqX6RvItZG1dN8XobWIZ5bpnK0FkMA3WMJ+r78LmG33ffnOWcaBLHvkzzwQuYy4rH6dfSAJAx3lYo8wQC+XNZ39mswDicszCyfkzeuyh5V5IBsbw0aGAze56U1V3AlinhSsZF2AGGFfZGg13gp5MF0mpFRQFfYJF2eEiZMkn2ZNgNwPy4Mtg1CYnjQTDQfmUH5IjF+zJkCCPZMzPy1CJwy0+//xot3I872BVwt1LyMOij8eaQ9ryZD8LmEkPWGFidOoqFh2r/D/w7v+4d+D6HqCfWQvPUOcEQ5PV7IGG9wEAy1qrJAOXMQezmHk70Fk66VXUcTNwAmcIL3rQSaUlyr2nKq4Pe+9piL5dMNPXHav0b1hqXAmUagYky5DeueL49E6FA66wuGIMrG70hQLwsFQOOhUxR0/r+Rq7OwzzDszCANt1qk7KrFvaD3iZPa7mkOhuOdeiuYyn9Iw6zHUpVY5SCsMDggDjTDQFCZOV2myMgU16MaEiRPPbMUZVWGfMrE771bBuijwfcLWIbP8ooq3jSDOFA5HVIV9RcVf0kyoW7UeWMfGxpASvy31eo5b0k3rS7OjX5Rr9SJguV4UGJObDiitinB4SlXczux+a4QirUNKWklXNy9stz8YKT8sx20YpnXT7hpvK/Vv7LZUrjOIAeV7q1484llVZub9kCKtQ0rSUqFUtt3+9wgo0cVx26bl3LR043210fyMdzXBbrVYULILes4R7K/KqhKtQ2qMlUxVLKdv9GyHtLrGp1qj/QUrtRsO8aB8WEvLVE60DqmZrWS64pi2Xezoxud6q/WpVK5/VW9LY6PbNDWRdUilaSXTlK5uXqS5ojbmHsdbh9SSrCSqfOdQqizaSqayDqnHbCVTWYdUkJnMQQe8u6xUm7+3Op3XhmX/ZTrOje327XW0kpmsQyppNiAcBipqb0vVxt/fWt0/9Z79wnTcD5bjdrJkJYhY8Hwgb502eFtjFtjyxi3bLRqmfdlsd8/vKvV3QiuzJFAMtK9apXpRb3b+6PTMV6btvrcdt7EMK6EqbhP55mfcO4OzrsPKk+MaPj0ovCndVd80Wq3fuj3rtGfa72y3r9lu/8csVqJw3KJM7BIOz0OvtI1YcdmsNprXes/6aDn92kKBpAWqKFDDUvVjo9n+taP3XvYs58Jy+1TFoZVQxM0o0w8XqsLgtlSu15utT4ZpXZu20xtt20qApAVqXCkKHGjl2m2zrX8wLJvYbv+/cW3IFJB5QTHAwV2tTlq6/sG0XIjqao8CSFwxTPtStsG0HS2NOtcaSPgG0q4vB5IDyYHkQHIgOZAcSA4kB5IDyYHkQHIgOZAcSA4kB5IDyYHkQHIgOZAcSA4khTZYjnvX1nsvoFT5JxUgUCoXy5XGZbOtnxm2fWnaLss6EMtxW13TfFUqV9/IOmSJe+NirGK/uLtEUFMCsXXTenNXa7yO2Aw3CBfHc3+Rxvu4q3iiMDhQmDgdByltUBMA+d6z7H8r35qvqHo7mp6eDoRJRBE3qYo73mse4jj0Wc9UQcUA+WE67vtmq/2iKLC0MgiTKAZU5GfKx4EybTfIArAcV7Vst9jsdF9y0L7eq8NLEDzM7BerouR/qUq+aXk4CajE4kN4TG9lBKIq7vhvNh0QLs5jX1V5zBCyrv8BZlPN6oJYPrMAAAAASUVORK5CYII=) center center no-repeat;}

</style>

					<table cellspacing="0" cellpadding="0">

					<!--{if $list}-->
						<!--{loop $list $stid $thread}-->
						<tr{if $actives[me] && $viewtype=='reply' || $viewtype=='postcomment'} class="bw0_all"{/if}>
									<td>
			{eval include TPLDIR.'/php/forum_forumdisplay.php';
                $xlmmdzo = C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $thread[tid]);}
<div class="tjcard TopstoryItem">
    
	<div class="Feed">
        <div class="ContentItem AnswerItem">
            <h2 class="ContentItem-title">
    										<a href="forum.php?mod=viewthread&tid=$thread[icontid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" title="{if $thread['displayorder'] == 1}{lang thread_type1} - {/if}
											{if $thread['displayorder'] == 2}{lang thread_type2} - {/if}
											{if $thread['displayorder'] == 3}{lang thread_type3} - {/if}
											{if $thread['displayorder'] == 4}{lang thread_type4} - {/if}
											{if $thread[folder] == 'lock'}{lang closed_thread} - {/if}
											{if $thread['special'] == 1}{lang thread_poll} - {/if}
											{if $thread['special'] == 2}{lang thread_trade} - {/if}
											{if $thread['special'] == 3}{lang thread_reward} - {/if}
											{if $thread['special'] == 4}{lang thread_activity} - {/if}
											{if $thread['special'] == 5}{lang thread_debate} - {/if}
											{if $thread[folder] == "new"}{lang have_newreplies} - {/if}
											{lang target_blank}" target="_blank" style=" vertical-align:middle">
										<!--{if $thread[folder] == 'lock'}-->
											<img src="{IMGDIR}/folder_lock.gif" />
										<!--{elseif $thread['special'] == 1}-->
											<img src="{IMGDIR}/pollsmall.gif" alt="{lang thread_poll}" />
										<!--{elseif $thread['special'] == 2}-->
											<img src="{IMGDIR}/tradesmall.gif" alt="{lang thread_trade}" />
										<!--{elseif $thread['special'] == 3}-->
											<img src="{IMGDIR}/rewardsmall.gif" alt="{lang thread_reward}" />
										<!--{elseif $thread['special'] == 4}-->
											<img src="{IMGDIR}/activitysmall.gif" alt="{lang thread_activity}" />
										<!--{elseif $thread['special'] == 5}-->
											<img src="{IMGDIR}/debatesmall.gif" alt="{lang thread_debate}" />
										<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
											<img src="{IMGDIR}/pin_$thread[displayorder].gif" alt="$_G[setting][threadsticky][3-$thread[displayorder]]" />
										<!--{else}-->
										<!--{/if}-->
										</a>
    										$thread[typehtml] $thread[sorthtml]
										<!--{if $thread['moved']}-->
											{lang thread_moved}:<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
										<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if}>$thread[subject]</a><!--{if $_G['setting']['threadhidethreshold'] && $thread['hidden'] >= $_G['setting']['threadhidethreshold']}-->&nbsp;<span class="xg1">{lang hidden}</span>&nbsp;<!--{/if}--><!--{if $view == 'hot'}-->&nbsp;<span class="xi1">$thread['heats']{lang guide_attend}</span>&nbsp;<!--{/if}-->
										<!--{if $thread[icon] >= 0}-->
											<img src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" style="margin-left:5px" />
										<!--{/if}-->
										<!--{if $thread['rushreply']}-->
											<img src="{IMGDIR}/rushreply_s.png" alt="{lang rushreply}" align="absmiddle" style="margin-left:5px" />
										<!--{/if}-->
										<!--{if $thread['attachment'] == 2}-->
											<img src="{STATICURL}image/filetype/image_s.gif" alt="attach_img" title="{lang attach_img}" align="absmiddle" style="margin-left:5px" />
										<!--{elseif $thread['attachment'] == 1}-->
											<img src="{STATICURL}image/filetype/common.gif" alt="attachment" title="{lang attachment}" align="absmiddle" style="margin-left:5px" />
										<!--{/if}-->
										<!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
											<img src="{IMGDIR}/digest_$thread[digest].gif" align="absmiddle" alt="digest" title="{lang thread_digest} $thread[digest]" style="margin-left:5px" />
										<!--{/if}-->
										<!--{if $thread['displayorder'] == 0}-->
											<!--{if $thread[recommendicon] && $filter != 'recommend'}-->
												<img src="{IMGDIR}/recommend_$thread[recommendicon].gif" align="absmiddle" alt="recommend" title="{lang thread_recommend} $thread[recommends]" style="margin-left:5px" />
											<!--{/if}-->
											<!--{if $thread[heatlevel]}-->
												<img src="{IMGDIR}/hot_$thread[heatlevel].gif" align="absmiddle" alt="heatlevel" title="$thread[heatlevel] {lang heats}" style="margin-left:5px" />
											<!--{/if}-->
											<!--{if $thread['rate'] > 0}-->
												<img src="{IMGDIR}/agree.gif" align="absmiddle" alt="agree" title="{lang rate_credit_add}" style="margin-left:5px" />
											<!--{elseif $thread['rate'] < 0}-->
												<img src="{IMGDIR}/disagree.gif" align="absmiddle" alt="disagree" title="{lang posts_deducted}" style="margin-left:5px" />
											<!--{/if}-->
										<!--{/if}-->
										<!--{if $thread['replycredit'] > 0}-->
											- <span class="xi1">[{lang replycredit} <strong> $thread['replycredit']</strong> ]</span>
										<!--{/if}-->
										<!--{if $thread[multipage]}-->
											<span class="tps">$thread[multipage]</span>
										<!--{/if}-->
										<!--{if $thread['weeknew']}-->
											<a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost" class="xi1">New</a>
										<!--{/if}-->
										<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
											<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
											<!--{/if}-->
										<!--{/if}-->
         <!--{if !$_GET['archiveid'] && $_G['forum']['ismoderator']}-->
								<em>		<!--{if $thread['fid'] == $_G[fid]}-->
											<!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
												<input onclick="tmodclick(this)" type="checkbox" name="moderate[]" value="$thread[tid]" />
											<!--{else}-->
												<input type="checkbox" disabled="disabled" />
											<!--{/if}-->
										<!--{else}-->
											<input type="checkbox" disabled="disabled" />
										<!--{/if}-->
								</em>	<!--{/if}-->   </h2>
<div class="ContentItem-meta">
    <div class="AuthorInfo cl">
                   <a href="home.php?mod=space&username=$thread[lastposterenc]">
    	<!--{eval  $xlmmuiduid=DB::result_first("select uid from ".DB::table("common_member")." WHERE `username` = '$thread[lastposter]'");}-->
   <div class="z Avatar">
{avatar($xlmmuiduid,middle)}
            </div>
            <div class="AuthorInfo-head z">
                    $thread[lastposter]
            </div>
                                   </a>
     <a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost" target="_blank" class="AuthorInfo-detail z">
 最后回复于 $thread[lastpost]
            </a>

    </div>
</div>
	        <div class="RichContent is-collapsed">
                 <!--{if $xlmmal >0}-->
     <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
     					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,230,230));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment'] ; }
		<!--{/if}-->
 <div class="RichContent-cover">
                    <div class="RichContent-cover-inner">
                        <img src="$xlmmimg">
                    </div>
                </div>
          	 <!--{eval $i++}-->
<!--{eval if($i==1) break;}-->
<!--{/loop}--> 
	<!--{/if}-->
      <div class="RichContent-inner"{if $xlmmal ==0} style="margin-top:10px"{/if}>
                    <span class="ztext">
                        $xiaolu['fmessage']
                    </span>
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="ContentItem-more">阅读全文&nbsp;>>  </a>
                </div>
                <div class="ContentItem-actions">
                    <span class="Buttons" style="margin-left:0">
                        <span style="display: inline-flex; align-items: center;">
                         &#8203;     <svg class="Zi Zi--Comment Button-zi" fill="currentColor" viewBox="0 0 24 24"
                            width="1.2em" height="1.2em">
                                <path d="M10.241 19.313a.97.97 0 0 0-.77.2 7.908 7.908 0 0 1-3.772 1.482.409.409 0 0 1-.38-.637 5.825 5.825 0 0 0 1.11-2.237.605.605 0 0 0-.227-.59A7.935 7.935 0 0 1 3 11.25C3 6.7 7.03 3 12 3s9 3.7 9 8.25-4.373 9.108-10.759 8.063z"
                                fill-rule="evenodd">
                                </path>
                            </svg>
                        </span>
                        $thread[replies] 条评论
                    </span>
                    <span class="Buttons">
                        <span style="display: inline-flex; align-items: center;">
                          &#8203; 
                            <svg class="Zi Zi--Heart Button-zi" fill="currentColor" viewBox="0 0 24 24"
                            width="1.2em" height="1.2em">
<path d="M16 17.649V2.931a.921.921 0 0 0-.045-.283.943.943 0 0 0-1.182-.604L4.655 5.235A.932.932 0 0 0 4 6.122v14.947c0 .514.421.931.941.931H19.06c.52 0 .941-.417.941-.93V7.292a.936.936 0 0 0-.941-.931h-.773v12.834a.934.934 0 0 1-.83.924L6.464 21.416c-.02.002 2.94-.958 8.883-2.881a.932.932 0 0 0 .653-.886z" fill-rule="evenodd"></path>
                            </svg>
                        </span>
                        $thread[views] 次浏览
                    </span>
                </div>
     <span class="from y" style="margin-top:-30px;"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank" class="Buttons" style="margin-left:0">$forums[$thread[fid]]</a></span>

       </div>
        </div>
    </div>

</div>
									</td>
						<!--{/loop}-->
					<!--{else}-->
						<tr>
							<td colspan="{if $viewtype != 'postcomment'}{if ($_GET['view'] == 'all' && $pruneperm && !$_GET['archiveid'])}6{else}5{/if}{else}3{/if}"><p class="xlmmntss">{lang no_related_posts}</p></td>
						</tr>
					<!--{/if}-->
					</table>

					<!--{if $_GET['view'] == 'all' && $pruneperm && !$_GET['archiveid'] && $list}-->
						<p class="mtm pns">
							<label for="chkall" onclick="checkall(this.form, 'moderate')"><input type="checkbox" name="chkall" id="chkall" class="pc vm" />{lang select_all}</label>
							<button type="submit" name="delsubmit" value="true" class="pn vm"><em>{lang del_select_thread}</em></button>
						</p>
					<!--{/if}-->
				</form>

				<!--{if $hiddennum}-->
					<p class="mtm">{lang hide_thread}</p>
				<!--{/if}-->
			</div>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->		
		
		<script type="text/javascript">
		function fuidgoto(fuid) {
			window.location.href = 'home.php?mod=space&do=thread&view=we&fuid='+fuid;
		}
		function viewforumthread(fid) {
			window.location.href = '{$forumurl}&fid='+fid;
		}
		</script>
			<!--{/if}-->
		
		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="sd">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
<!--{if !$_G[setting][homepagestyle]}-->
				<div class="sd y" style="width:300px;">
<div class="Card tns">
  	<!--{eval  $xlmmuidfav=DB::result_first("select followuid from ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$space[uid]");
                  $xlmmuidfavs=DB::fetch_all("select fusername from ".DB::table("home_follow")." WHERE`followuid`=$space[uid]");$xlmmfsall = count($xlmmuidfavs);
}-->
<table cellpadding="4" cellspacing="0" border="0">
<tbody><tr>
<th>粉丝<p>{$xlmmfsall}</p></th>
<th class="cb0">积分<p>{$space[credits]}</p></th>
</tr>
</tbody></table>
</div>

			<!--[diy=xlmmrt]--><div id="xlmmrt" class="area"></div><!--[/diy]-->
               <div id="fixeds"></div>

</div>

<script>
var userfix = $('fixeds');
var userfixoffset = parseInt(fetchOffset(userfix)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop + 50 >= userfixoffset){
if (BROWSER.ie && BROWSER.ie < 7) {
userfix.style.position = 'absolute';
userfix.style.top = xlmmm_scrollTop + 'px';
}else{
userfix.innerHTML  = '<style>.hotNews{ position:fixed; top:0px; width:300px;z-index:99;}</style>';
}
}else{
userfix.innerHTML  = '<style>.hotNews{ position:static;}</style>';
}
});
</script>
<!--{/if}-->

</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->

<!--{template common/footer}-->
