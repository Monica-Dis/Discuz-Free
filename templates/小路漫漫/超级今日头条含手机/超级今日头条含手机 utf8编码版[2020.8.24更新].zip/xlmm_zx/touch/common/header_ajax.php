<?PHP exit('Access xlmm发帖相关 QQdism.taobao.com 修改于2017.06');?>
{eval 
ob_end_clean();
ob_start();
@header("Expires: -1");
@header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
@header("Pragma: no-cache");
@header("Content-type: text/xml; charset=".CHARSET);
echo '<?xml version="1.0" encoding="utf-8"?>'."\r\n";
}
<root><![CDATA[


