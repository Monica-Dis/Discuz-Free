<?php exit;?>
    <!--悬赏主题-->
<style type="text/css">
.xlmmxsli, .xlmmxszt {background: #fefced url(template/xlmm_zx/m-img/xs.png) no-repeat;background-position: 8px;background-size: 40px auto;line-height: 35px;border: 1px dashed #ECECEC; padding: 15px 10px 15px 60px; margin: 10px 0;font-size: 14px;color: #ffaf00;}
.xlmmxsbt {float: right;width: 80px;height: 35px;line-height: 37px;text-align: center;font-size: 14px;color: #fff;border-radius: 3px;display: block;background: #99db8f;}
_:future, :root .xlmmxsbt {line-height: 35px;}
.rwdbst {background: #FCFCFC;margin-top: 20px;position: relative;}
.rwdbst .psth {height: 40px;line-height: 40px;padding: 0 10px;background: #ececec;color: #999;font-size: 14px;}
.rwdbst .pstl {background: #F8F8F8;margin-bottom: 15px;padding: 10px;border: 1px solid #ECECEC;}
.rwdbst .psta {position: absolute;left: 10px;top: 55px;display: inline;}
.rwdbst .psta img {width: 40px;height: 40px;-webkit-border-radius: 5rem;border-radius: 5rem;vertical-align: top;}
.rwdbst .psti {margin: 5px 0 10px 50px;}
.rwdbst .psti .xi2 {font-size: 14px;line-height: 20px;}
.rwdbst .psti .xi2 a {margin-right:10px;color: #324b82;}
.rwdbst .psti .mtn {color: #333;}
.xlmmmyda {height: 25px;padding: 0 10px;margin-top: 5px;margin-bottom: 2px;background: #99db5f;color: #fff;font-size: 12px;border: 0;border-radius: 3px;}
</style>
	
<div class="xlmmxszt cl">{lang thread_reward}<strong> <span class="xi1 xs3">$rewardprice</span> </strong>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
{if $_G['forum_thread']['price'] > 0}<span class="xi1">{lang unresolved}</span>{elseif $_G['forum_thread']['price'] < 0}<span class="xg1">{lang resolved}</span>{/if}
<!--{if $bestpost}--><!--{else}--><a onClick="nryhf()" class="xlmmxsbt">我来回答</a><!--{/if}-->
</div>
	<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>
<!--{if $post['attachment']}-->
	<div class="xlmmxsli cl">{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em></div>
<!--{elseif $post['imagelist'] || $post['attachlist']}-->
    <!--{if $post['imagelist']}-->
         {echo showattach($post, 1)}
    <!--{/if}-->
    <!--{if $post['attachlist']}-->
         {echo showattach($post)}
    <!--{/if}-->
<!--{/if}-->
<!--{eval $post['attachment'] = $post['imagelist'] = $post['attachlist'] = '';}-->
<!--{if $bestpost}-->
	<div class="rwdbst">
		<h3 class="psth">{lang reward_bestanswer}</h3>
		<div class="pstl">
			<div class="psta">$bestpost[avatar]</div>
			<div class="psti">
				<p class="xi2"><a href="home.php?mod=space&uid=$bestpost[authorid]" class="xw1">$bestpost[author]</a> <a href="javascript:;" onclick="window.open('forum.php?mod=redirect&goto=findpost&ptid=$bestpost[tid]&pid=$bestpost[pid]')">{lang view_full_content}</a></p>
				<div class="mtn">$bestpost[message]</div>
			</div>
		</div>
	</div>
<!--{/if}-->

