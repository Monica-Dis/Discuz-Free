

(function($){
	$.fn.extend({
		xlmmfcrbq_insert: function(a){
			var $xlmmfcrbq=$(this)[0];
			if ($xlmmfcrbq.selectionStart || $xlmmfcrbq.selectionStart == '0') {
				var startPos = $xlmmfcrbq.selectionStart;
				var endPos = $xlmmfcrbq.selectionEnd;
				$xlmmfcrbq.value = $xlmmfcrbq.value.substring(0, startPos) + a + $xlmmfcrbq.value.substring(endPos, $xlmmfcrbq.value.length);
				$xlmmfcrbq.selectionStart = $xlmmfcrbq.selectionEnd = startPos + a.length;
			}else {
				this.value += a;
			}
			$xlmmfcrbq.focus();
		},
		xlmmfcrbq_delete: function(){
			var $xlmmfcrbq=$(this)[0];
			var is_smilies = -1;
			if ($xlmmfcrbq.selectionStart && ($xlmmfcrbq.selectionStart == $xlmmfcrbq.selectionEnd)) {
				var startPos = $xlmmfcrbq.selectionStart;
				var startText = $xlmmfcrbq.value.substring(0, startPos);
				var endText = $xlmmfcrbq.value.substring(startPos, $xlmmfcrbq.value.length);
				var xlmmfcrbq_smilies_len = 0, delStart = 0, xlmmfcrbq_startText_lendata = '';
				for(i in xlmmfcrbq_smilies_array) {
					xlmmfcrbq_smilies_len = xlmmfcrbq_smilies_array[i][0].length;
					xlmmfcrbq_startText_lendata = startText.substring(startText.length - xlmmfcrbq_smilies_len, startText.length);
					if(in_array(xlmmfcrbq_startText_lendata, xlmmfcrbq_smilies_array[i])){
						delStart = startText.length - xlmmfcrbq_smilies_len;
						$xlmmfcrbq.value = startText.substring(0, delStart)  + endText;
						$xlmmfcrbq.selectionStart = $xlmmfcrbq.selectionEnd = delStart;
						is_smilies = 1;
						break;
					}
				}
				if(is_smilies == 1){
					return false;
				}else{
					var xlmmfcrbq_sall_Text = xlmmfcrbq_sleft_Text = xlmmfcrbq_sright_Text = '';
					var xlmmfcrbq_smilies_len = xlmmfcrbq_sleft_length = 0;
					for(o in xlmmfcrbq_smilies_array) {
						xlmmfcrbq_smilies_len = xlmmfcrbq_smilies_array[o][0].length;
						xlmmfcrbq_sleft_Text = $xlmmfcrbq.value.substring(startPos - xlmmfcrbq_smilies_len + 1, startPos);
						xlmmfcrbq_sright_Text = $xlmmfcrbq.value.substring(startPos, startPos + xlmmfcrbq_smilies_len - 1);
						xlmmfcrbq_sleft_length = xlmmfcrbq_sleft_Text.length;
						xlmmfcrbq_sall_Text = xlmmfcrbq_sleft_Text + xlmmfcrbq_sright_Text;
						for(p in xlmmfcrbq_smilies_array[o]) {
							is_smilies = xlmmfcrbq_sall_Text.indexOf(xlmmfcrbq_smilies_array[o][p]);
							if(is_smilies >= 0){
								var startText = $xlmmfcrbq.value.substring(0, startPos - xlmmfcrbq_sleft_length + is_smilies);
								var endText = $xlmmfcrbq.value.substring(startPos - xlmmfcrbq_sleft_length + is_smilies + xlmmfcrbq_smilies_len, $xlmmfcrbq.value.length);
								$xlmmfcrbq.value = startText + endText;
								$xlmmfcrbq.selectionStart = $xlmmfcrbq.selectionEnd = startText.length;	
								return false;
							}
						}
					}
				}
			}
		}
	})
})(jQuery);
function xlmmfcrbq_smilies_tab(a){
	if(typeof smilies_array[a] == 'object') {
		var xlmmfcrbq_smilies_list = '<div class="swiper-slide"><ul class="swiper-slide">';
		var o = 0, xlmmfcrbq_smilies_text = '';
		
		for(ii in smilies_array[a]) {
			for(i in smilies_array[a][ii]) {
				o++;
				if(o > 24){
					o = 1;
					xlmmfcrbq_smilies_list += '</ul></div><div class="swiper-slide"><ul class="swiper-slide">';
				}
				xlmmfcrbq_smilies_text = smilies_array[a][ii][i][1].replace(/\'/, '\\\'');
				xlmmfcrbq_smilies_list += '<li><a href="javascript:;" onclick="xlmmfcrbq_addsmilies(\'' + xlmmfcrbq_smilies_text + '\');"><img src="' + STATICURL + 'image/smiley/' + smilies_type['_' + a][1] + '/' + smilies_array[a][ii][i][2] + '" class="vm"></a></li>';
			}
		}
		xlmmfcrbq_smilies_list += '</ul></div>';
		$('.bqbox_c').html(xlmmfcrbq_smilies_list);
		mySwiper.update();
		mySwiper.slideTo(0, 0, false);
		$('#xlmmfcrbq_smilies_key>li>a').removeClass('bg_f b_l b_r');
		$('#xlmmfcrbq_smilies_tab' + a).addClass("bg_f b_l b_r");
	}else{
		popup.open('This smilies is closed or does not exist !', 'alert');
	}
}
function xlmmfcrbq_addsmilies(a){
	$('#needmessage').xlmmfcrbq_insert(a);
}
var mySwiper, xlmmfcrbq_smilies_array = [];
$(document).ready(function() {
	$('#needmessage').on('keydown', function(event){
		if(event.keyCode == "8") {
			return $('#needmessage').xlmmfcrbq_delete();
		}
	});
	mySwiper = new Swiper('.xlmmfcrbq_smiley_box',{
		pagination: '.bqbox_b',
		onTouchMove: function(swiper){
			xlmmfcrbq_Touch_on = 0;
		},
		onTouchEnd: function(swiper){
			xlmmfcrbq_Touch_on = 1;
		},
	});
	var xlmmfcrbq_tab_index = 99;
	var smilies_show_id = 0;
	
	$(document).on('click', '.xlmmfcrbq_post_ico>a', function(e) {
		if(xlmmfcrbq_tab_index != $(this).index()){
			$('.xlmmfcrbq_post_ico a i').removeClass('f_0');
			$(this).find('i').addClass("f_0");
			xlmmfcrbq_tab_index = $(this).index();
			$("#xlmmfcrbq_post_tab>div").hide().eq(xlmmfcrbq_tab_index).fadeIn();
			if(smilies_show_id == 0 && xlmmfcrbq_tab_index == 0){
				var smilies_type_box = '';
				if(typeof smilies_type == 'object') {
					for(i in smilies_type) {
						key = i.substring(1);
						smilies_type_box += '<li><a href="javascript:;" onclick="xlmmfcrbq_smilies_tab(\''+ key+ '\')" id="xlmmfcrbq_smilies_tab'+ key+ '"' + (smilies_show_id == 0 ? ' class="bg_f"' : '') + '><img src="' + STATICURL + 'image/smiley/' + smilies_type['_' + key][1] + '/' + smilies_array[key][1][0][2] + '" class="vm"></a></li>';
						if(smilies_show_id == 0){
							smilies_show_id = key;
						}
					}
					$('#xlmmfcrbq_smilies_key').html(smilies_type_box);
					xlmmfcrbq_smilies_tab(smilies_show_id)
				}
			}
		}else{
			if($(this).find('i').hasClass("f_0")){
				$('.xlmmfcrbq_post_ico a i').removeClass('f_0');
				$("#xlmmfcrbq_post_tab>div").eq(xlmmfcrbq_tab_index).hide();
			}else{
				$(this).find('i').addClass("f_0");
				$("#xlmmfcrbq_post_tab>div").eq(xlmmfcrbq_tab_index).fadeIn();
			}
		}
	});

	for(i in smilies_array) {
		for(o in smilies_array[i][1]) {
			if (typeof xlmmfcrbq_smilies_array[smilies_array[i][1][o][1].length] != 'object') {
				xlmmfcrbq_smilies_array[smilies_array[i][1][o][1].length] = new Array();
			}
			xlmmfcrbq_smilies_array[smilies_array[i][1][o][1].length].push(smilies_array[i][1][o][1]);
		}
	}
	xlmmfcrbq_smilies_array.reverse();
	xlmmfcrbq_picnum();
});


