<?PHP exit('Access Deniedxiaoluanman');?>
<!--{template common/header}-->
<style>
.post-xl_dp textarea { border:1px solid #EEE; background:#F8F8F8; padding:5px; color:#999; height:80px; border-radius:0px; width:230px;}
.post-xl_dp .sec_code { padding-left:0px!important;}
.post-xl_dp .sec_code input { border:1px solid #EEE;}
    .post-xl_dp h2  { position:relative; height:30px; line-height:30px; color:#262626; margin:0 0 10px 0; padding:0 10px; border-bottom:1px solid #DFE1E3; background:#fff; font-weight:normal;}

.post-xl_dp { background: #FFFFFF; border: 1px solid #DFE1E3; margin: 15px; padding:0; text-align: left; box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.1);}
.post-xl_c { padding:10px;}
.mbutton { width:50px; height:32px; line-height:32px; border:0; text-align:center; color:#FFF; background: #2498D8;}
.mbutton25 { width:50px; height:25px; line-height:25px; border:0; text-align:center; color:#FFF; background: #2498D8}
.minput { border:1px solid #EEE; background:#F8F8F8; padding:3px 5px; color:#999;}

</style>

<form method="post" autocomplete="off" id="commentform" action="forum.php?mod=post&action=reply&comment=yes&tid=$post[tid]&pid=$_GET[pid]&extra=$extra{if !empty($_GET[page])}&page=$_GET[page]{/if}&commentsubmit=yes&infloat=yes" onsubmit="{if !empty($_GET['infloat'])}ajaxpost('commentform', 'return_$_GET['handlekey']', 'return_$_GET['handlekey']', 'onerror');return false;{/if}">
<div class="post-xl_dp">
    <h2>点评</h2>
    <div class="post-xl_c">
    <input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
    <input type="hidden" name="handlekey" value="$_GET['handlekey']" />
    <textarea name="message" id="commentmessage" onKeyUp="strLenCalc(this, 'checklen')" onKeyDown="seditor_ctlent(event, '$(\'commentsubmit\').click();')" tabindex="2" style="overflow: auto"></textarea>
    <div id="seccheck_comment">
    <!--{if $secqaacheck || $seccodecheck}-->
    <!--{subtemplate common/seccheck}-->
    <!--{/if}-->
    </div>
    <button type="submit" id="commentsubmit" class="mbutton" style="margin-top:5px;" value="true" name="commentsubmit" tabindex="3"{if !$seccodecheck} onmouseover="checkpostrule('seccheck_comment', 'ac=reply&infloat=yes&handlekey=$_GET[handlekey]');this.onmouseover=null"{/if}><span>点评</span></button>
    </div>
</div>
</form>
<!--{template common/footer}-->


