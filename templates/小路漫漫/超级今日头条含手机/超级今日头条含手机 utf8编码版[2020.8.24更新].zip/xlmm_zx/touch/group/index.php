<?PHP exit('Access Deniedxl');?>
<!--{template common/header}-->
<style>
.catalog {display:block;background-color:#fafbfc}
.xlmm_gi {}
.xlmm_gi .catalog_item {list-style:none;display:box;display:-webkit-box;width:100%;height:64px;border-bottom:1px solid #f0f1f2}
.xlmm_gi .catalog_item .icon {display:inline-block;width:50px;height:50px;border-radius:2px;margin:7px 10px;background-repeat:no-repeat;background-size:100% 100%}
.xlmm_gi .catalog_item .text {margin:7px 10px 7px 0;font-family:arial;box-flex:2;-webkit-box-flex:2;overflow:hidden}
.xlmm_gi .catalog_item .title {color:#262626;font-size:16px;height:25px;line-height:28px}
.xlmm_gi .catalog_item .desc {height:25px;line-height:25px;margin-right:30px}
.xlmm_gi .catalog_item .subclass {display:inline-block;color:#b2b6ba;font-size:12px;margin-right:5px}
.xlmm_gi .catalog_item {position:relative}
.xlmm_gi .catalog_item:after {border-color:#bbc4d3;left:auto;right:10px}
.arrow_line.arrow_right::after {-webkit-transform: rotate(135deg);transform: rotate(135deg);}
.arrow_line::after {border: 2px solid #CCD0D6;border-width: 1px 0 0 1px;  width: 9px; height: 9px;-webkit-box-sizing: border-box;box-sizing: border-box;  margin: -3px 0 0 -3px;-webkit-transform-origin: 33.3% 33.3%; transform-origin: 33.3% 33.3%;}
.arrow::after { content: '';position: absolute;top: 50%;left: 50%;}
</style>
<div class="catalog xlmm_gi">
         									<!--{eval $xlmm = 1;}-->
             					<!--{loop $first $groupid $group}-->
<a class="catalog_item first_item arrow arrow_line arrow_right" href="group.php?gid=$groupid"><div class="icon" style="background-image:url(template/xlmm_zx/m-img/gicon/$xlmm.png);border-radius: 5rem"></div>
<div class="text">
<div class="title">$group[name]</div>
<div class="desc">
<!--{loop $group['secondlist'] $fid}--><span class="subclass">$second[$fid][name]</span>
									<!--{/loop}-->
</div></div></a>										<!--{eval $xlmm ++;}-->
								<!--{/loop}-->














</div>
<!--{template common/footer}-->


