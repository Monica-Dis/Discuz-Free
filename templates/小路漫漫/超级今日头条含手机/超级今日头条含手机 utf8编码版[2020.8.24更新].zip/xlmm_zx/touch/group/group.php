<?PHP exit('Access Deniedxiaoluanman');?>
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="template/xlmm_zx/m-img/forumdisplay.css"/>
  <div class="forumlist">
<!--{if $action == 'list'}-->

    <div class="forumlist">
<div class="xlmm-fh-cover">
 <div class="xlmm-fh"> 
 <div class="cover mask-gray"></div>
 <div class="info"> <div class="logo-container"> <img class="logo" src="<!--{if $_G[forum][icon]}-->$_G['forum']['icon']<!--{else}-->template/xlmm_zx/m-img/icon.png<!--{/if}-->"> </div>
   <div class="name-info"> <div class="labels"> <span class="name">{$_G['forum']['name']}</span><!--{if $_G['forum']['ismoderator']}--> <a href="forum.php?mod=group&action=manage&fid=$_G[fid]" style="color:#FF0000; margin-left:6px">管理</a> <!--{/if}--></div>
 <div class="info-num">  <label>话题 </label><span>$_G[forum][threads]</span>  <label>帖子 </label><span>$_G[forum][posts]</span>   </div>
  <div class="bar-info-text">$_G['forum'][description]</div>
  </div>
 <div class="sign" id="signArea"> </div>
  <div class="op" id="opArea" style="display: block;">
 <!--{if $status != 2 && $status != 3 && $status != 5}--><!--{if helper_access::check_module('group') && $status != 'isgroupuser'}--><a class="vote-btn btn favbtn" href="forum.php?mod=group&action=join&fid=$_G[fid]&hash={FORMHASH}"> <i class="vote-btn-icon"></i>关注</a><!--{/if}--><!--{/if}--><!--{if $status == 'isgroupuser'}--><a href="forum.php?mod=group&action=out&fid=$_G[fid]&hash={FORMHASH}" class="vote-btn btn nfavbtn">退出</a><!--{/if}-->
 </div></div>
 </div>
 </div>
<div id="uiTestNavWrap" class="ui-test-nav-wrap" style="display: block;">
<div id="uiTestNav" class="ui-test-nav nohighlight">
<div class="new-tab-list" style="width: 100%; transition: 0ms cubic-bezier(0.1, 0.57, 0.1, 1); -webkit-transition: 0ms cubic-bezier(0.1, 0.57, 0.1, 1); transform: translate(0px, 0px) translateZ(0px);">  
<div{if $filter==digest || $_GET[specialtype]==poll || $_GET[specialtype]==activity || $_GET[specialtype]==reward || $_GET[specialtype]==trade || $_GET[specialtype]==poll || $_GET[specialtype]==debate || $_GET[orderby]==heats ||  ! $_GET['forumlist'] != 1}{else}  style="background:#ededed"{/if}><a id="tab_all" href="forum.php?mod=forumdisplay&fid=$_G[fid]">全部</a></div>
<div{if $filter==digest} style="background:#ededed"{/if}><a id="tab_best" href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1">精华</a></div>
    <div{if $_GET['filter'] == 'heat'} style="background:#ededed"{/if}><a id="tab_qun" class="tab_qun" href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]">热门帖</a></div>
         <div{if ! $_GET['forumlist'] != 1} style="background:#ededed"{/if}><a id="tab_album" href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumlist=1" class="">看图</a></div>
    </div>
</div>
</div>
{/if}
<!--{if $action == 'index' && $status != 2 && $status != 3}-->
    <script language="JavaScript">self.location='forum.php?mod=forumdisplay&action=list&fid=$_G[fid]';</script>
<!--{elseif $action == 'list'}-->
    <!--{subtemplate group/group_list}-->
			<!--{elseif $action == 'create'}-->
				<!--{subtemplate group/group_create}-->
<!--{elseif $action == 'manage'}-->
    <!--{subtemplate group/group_manage}-->
<!--{/if}-->
 </div>
<script type="text/javascript">
	$('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'joinsubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
	
		$('.nfavbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=nfavbtn&inajax=1',
			data:{'outsubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

</script>
<!--{template common/footer}-->


