<?PHP exit('Access Deniedxiaoluanman');?>
<div class="swiper-slide">
	{if $portal_type['catid'] == $_G['catid']}
<content class="feed-list-container" id="threadlist" style="position:relative;">
	<div id="xlmmjps" class="list_content">
			<start></start>
						<!--{if !$list['list']}-->
<div class="mt10" style="text-align:center; background:#FFFFFF; padding:40px 0 80px 0; height:736px"><svg width="150" height="120" viewBox="0 0 150 120" class="Topstory-newUserFollowCountPanelIcon" fill="currentColor"><g fill="none" fill-rule="evenodd"><path fill="#EBEEF5" d="M44 31.005v55.99A3.003 3.003 0 0 0 47.003 90h53.994A3.005 3.005 0 0 0 104 86.995v-55.99A3.003 3.003 0 0 0 100.997 28H47.003A3.005 3.005 0 0 0 44 31.005zm-3 0A6.005 6.005 0 0 1 47.003 25h53.994A6.003 6.003 0 0 1 107 31.005v55.99A6.005 6.005 0 0 1 100.997 93H47.003A6.003 6.003 0 0 1 41 86.995v-55.99z" fill-rule="nonzero"></path><path fill="#F7F8FA" d="M59 50a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 40.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5zM59 73a6 6 0 1 1 0-12 6 6 0 0 1 0 12zm12-9.5c0-.828.68-1.5 1.496-1.5h9.008c.826 0 1.496.666 1.496 1.5 0 .828-.68 1.5-1.496 1.5h-9.008A1.495 1.495 0 0 1 71 63.5zm0 7c0-.828.667-1.5 1.5-1.5h21c.828 0 1.5.666 1.5 1.5 0 .828-.667 1.5-1.5 1.5h-21c-.828 0-1.5-.666-1.5-1.5z"></path></g></svg><div style="font-size: 15px;color: grey;">还没有任何内容哦<style>.getMore{ display:none !important;}</style>
</div></div>	
 			<!--{/if}-->
	<!--{loop $list['list'] $key $value}-->
				<!--{eval $highlight = article_title_style($value);}-->
				<!--{eval $article_url = fetch_article_url($value);}-->
		 <!--{if $_G['page'] ==1 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad1']}-->                                                                    
 <!--{elseif $_G['page'] ==2 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad2']}-->                                                                    
 <!--{elseif $_G['page'] ==3 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad3']}-->                                                                    
 <!--{elseif $_G['page'] ==4 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad4']}-->                                                                    
 <!--{elseif $_G['page'] ==5 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad5']}-->                                                                    
 <!--{elseif $_G['page'] ==6 && $key==$_G['cache']['plugin']['xlmm_tt']['xlmmmoad']}-->                                                                    
 <!--{$_G['cache']['plugin']['xlmm_tt']['xlmmmoad6']}-->                                                                    
										<!--{/if}-->
		{eval include TPLDIR.'/php/portal_list.php';}
<!--{if $xlmmal ==0}-->
<section class="has_action"><a href="$article_url" class="article_link clearfix "><div class="item_detail">										
<h3 class="dotdot line3">$value[title]</h3><div class="item_info"><div><span class="src space">$value[username]</span><span class="cmt space">回复 $value[commentnum]</span><span class="time">$value[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>

<!--{elseif $xlmmal >$_G['cache']['plugin']['xlmm_tt']['xlmmmduotu']}-->
<section class="has_action"><a href="$article_url" class="article_link clearfix "><div class="item_detail"><h3 class="dotdot line3">$value[title]</h3>
 <div class="list_image" style="margin-top:5px;">
<div class="clearfix">
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==3) break;}-->
<div class="list_img_holder"><!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->
<img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1}-->$xlmmimg<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->template/xlmm_zx/php/small.php?filename=<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->&width=230&height=230<!--{/if}-->" class="xlmmlazy">
						<!--{else}-->
<img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment']<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 4}-->.thumb.jpg<!--{/if}-->" class="xlmmlazy">
<!--{/if}-->
</div>
<!--{/loop}-->
    </div>
</div>
<div class="item_info"><div><span class="src space">$value[username]</span><span class="cmt space">回复 $value[commentnum]</span><span class="time">$value[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal <=$_G['cache']['plugin']['xlmm_tt']['xlmmmduotu']}-->
<section class="middle_mode has_action"><a href="$article_url" class="article_link clearfix "><div class="item_detail desc">                                        <h3 class="dotdot line3 image-margin-right">$value[title]</h3><div class="item_info"><div><span class="src space">$value[username]</span><span class="cmt space">回复 $value[commentnum]</span><span class="time">$value[dateline]</span><span class="dislike-news fr mid-space"></span></div></div></div>
<!--{loop $xlmmoutimg $key $xlmmimg}-->
								<!--{eval if($key==1) break;}-->

 <div class="list_img_holders"><!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->
<img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1}-->$xlmmimg<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->template/xlmm_zx/php/small.php?filename=<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->&width=230&height=230<!--{/if}-->" class="xlmmlazy">
						<!--{else}-->
<img src="template/xlmm_zx/image/xlmmload.gif" xlmmlazy="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment']<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 4}-->.thumb.jpg<!--{/if}-->" class="xlmmlazy">
<!--{/if}-->
</div>
  <!--{/loop}-->
  </a></section>

 <!--{/if}-->
			<!--{/loop}-->

</div>
		 <end></end>
	<div id="allpgs" style="display:none">{echo $thispage = ceil($list[count] / $perpage);}</div><div id="oallpgs" style="display:none">$_G['page']</div><div id="oallurl" style="display:none">$cat['caturl']</div>
     <a href="javascript:;" id="xlmmsdj" class="getMore"><div style="text-align: center;line-height:40px;color: #999;">点击加载更多</div></a>
<script type="text/javascript">

  xlmmurl= $("#oallurl").text();
  allnum= $("#allpgs").text();
 var num = $("#oallpgs").text();
     nomore= "<div style=\"text-align: center;line-height:40px;color: #999;\">我也是有底线的哦</div>";
       if(num >= allnum) { 
 $('.getMore').html(nomore);;
}
  	$('.getMore').click(function(e){
       if(num >= allnum) { 
}
else {
      num++;  
 $.ajax({
             url:xlmmurl+'?&page='+num+'' ,
        type:'get',
        dataType: 'html',
        beforeSend:function(){
            $('.getMore').html("<div style=\"text-align: center;line-height:40px;color: #999;\"><img src=\"static/image/common/loading.gif\" width=\"16\" height=\"16\" class=\"vm\" /> 载入中...</div>"); 
        },
        success:function (data){
			     var newdatas = data.match(/<start><\/start>([\s\S]+?)<end><\/end>/);
 $('#xlmmjps').append(newdatas[1]);    
                  $('.getMore').html("<div style=\"text-align: center;line-height:40px;color: #999;\">点击加载更多</div>"); 
          if(num >= allnum) { 
 $('.getMore').html(nomore);;
}
      },error: function() {
            $('.getMore').html("<div style=\"text-align: center;line-height:40px;color: #999;\">数据获取失败</div>");
        }
  })
	        }
});
</script>
</content>
{/if}

</div>

