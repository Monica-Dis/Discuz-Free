<?PHP exit('Access Deniedxiaoluanman');?>
<!--{template common/header}-->
<!--[name]{lang portalcategory_listtplname}[/name]-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->
<script src="template/xlmm_zx/load.js?EGs" type="text/javascript"></script>
{eval $page=$_G['page'];	
$perpage = empty($perpage) ? $cat['perpage'] : $perpage;
}
<style>
	.hm { display:block;line-height:40px;color: #999 !important;}
content.feed-list-container .list_image .list_img_holder:first-child {margin-left: 0;}
.loadxlmms{ text-align: center;line-height:40px;color: #999; display:none}
</style>
	<div id="s2" class="swiper-container ">
<div class="loadxlmms"><img src="static/image/common/loading.gif" width="16" height="16" class="vm" />&nbsp;正在加载</div>	
<div class="swiper-wrapper" id="containerss">
    		<!--listst-->
 <!--{loop $temp $portal_type}-->
 <!--{if $portal_type['upid']=="0"}-->
 <!--{template portal/lists}-->
 <!--{/if}-->
	 <!--{/loop}-->
    <!--{loop $temp $portal_type}-->
 <!--{if !$portal_type['upid']=="0"}-->
 <!--{template portal/lists}-->
<!--{/if}-->

	 <!--{/loop}-->
		<!--listend-->
 
</div>
</div>
{if $_G['page_next'] >1}
 		<div id="pgbtn" class="pgbtn"><span></span></div>
{/if}

<script type="text/ecmascript">
 (function($){
    $(window).scroll(function() {
if ($(document).scrollTop() <= 0) { }

var srollPos = $(window).scrollTop();  
totalheight = parseFloat($(window).height()) + parseFloat(srollPos);  
            if(($(document).height()) <= totalheight) {

document.getElementById("xlmmsdj").click()

        }

})

    var swhotabsIndex = $('.swhotabs li.a').index();
var idx = swhotabsIndex;
idxChange(idx)
if($(".swhotabs li.a").length > 0) {
var xlmminx = $(".swhotabs li.a").offset().left + $(".swhotabs li.a").width() >= $(window).width() ? $(".swhotabs li.a").index() : 0;
}else{
var xlmminx = 0;
}	
     var my1 = new Swiper('#s1.swhotabs', {
        freeMode: true,
        slidesPerView: 'auto',
 initialSlide : xlmminx,
      	resistanceRatio: 0,
  });

	   var my2 = new Swiper('#s2', {
initialSlide: swhotabsIndex,
	    	resistanceRatio: 0,
  })

    my1.on('tap', function (event) {
        console.log(this.clickedIndex);
        idx = this.clickedIndex;
        idxChange(idx)
        this.slideTo(this.clickedIndex);
        my2.slideTo(this.clickedIndex);
    })

    my2.on('slideChange', function (event) {
        console.log(this.activeIndex);
        idx = this.activeIndex;
        idxChange(idx);
        my1.slideTo(this.activeIndex);
    });

function idxChange(idx) {
   var obj = $('#s1 .swiper-slide');
 obj.removeClass('active');
 obj.eq(idx).addClass('active');
					if (obj.hasClass("active")){
$('#s1 .swiper-slide.active .xlmmtsnav').click();


      }
}
kkkkb=my2.activeIndex
})(jQuery);
</script>
	<script src="template/xlmm_zx/m-img/jquery.pjax.js?{VERHASH}"></script>
<script>
 $.pjax.defaults.timeout = 5000;
$.pjax.defaults.maxCacheLength = 0;
       $.pjax.push= false,
 $.pjax.replace= true,
$(document).pjax('a[class=xlmmtsnav]',  '#containerss', { fragment: '#containerss' });
$(document).on('pjax:send', function() { 
    $(".loadxlmms").css("display", "block");
});
$(document).on('pjax:complete', function() { 
    $(".loadxlmms").css("display", "none");


  xlmmurl= $("#oallurl").text();
  allnum= $("#allpgs").text();
 var num = $("#oallpgs").text();
     nomore= "<div style=\"text-align: center;line-height:40px;color: #999;\">我也是有底线的哦</div>";
       if(num >= allnum) { 
 $('.getMore').html(nomore);;
}
  	$('.getMore').click(function(e){
       if(num >= allnum) { 
}
else {
      num++;  
 $.ajax({
             url:xlmmurl+'?&page='+num+'' ,
        type:'get',
        dataType: 'html',
        beforeSend:function(){
            $('.getMore').html("<div style=\"text-align: center;line-height:40px;color: #999;\"><img src=\"static/image/common/loading.gif\" width=\"16\" height=\"16\" class=\"vm\" /> 载入中...</div>"); 
        },
        success:function (data){
			     var newdatas = data.match(/<start><\/start>([\s\S]+?)<end><\/end>/);
 $('#xlmmjps').append(newdatas[1]);    
                  $('.getMore').html("<div style=\"text-align: center;line-height:40px;color: #999;\">点击加载更多</div>"); 
          if(num >= allnum) { 
 $('.getMore').html(nomore);;
}
      },error: function() {
            $('.getMore').html("<div style=\"text-align: center;line-height:40px;color: #999;\">数据获取失败</div>");
        }
  })
	        }
});


});






</script>





<script>
jQuery(document).ready(function() {
jQuery("img.xlmmlazy").lazyload();
});
</script>


<!--{template common/footer}-->


