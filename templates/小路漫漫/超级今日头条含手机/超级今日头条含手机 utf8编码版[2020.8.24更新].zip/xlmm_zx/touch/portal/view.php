<?PHP exit('Access Deniedxiaoluanman');?>
<!--{template common/header}-->
<!--[name]{lang portalcategory_viewtplname}[/name]-->
<style type="text/css">

html {height:100%; background-color:#fff}
body{-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box; position:relative; z-index:0;width:100%;max-width:640px;min-width:300px;min-height:100%;margin:0 auto;box-shadow:0 0 10px rgba(0,0,0,0.3)}
body{overflow-x:hidden;line-height:1.5;background-color:#fff;}
body,input,button,select,textarea{font:12px/1.5 "microsoft yahei";color:rgb(105,105,105);}
article,aside,details,figcaption,figure,footer,header,hgroup,menu,nav,section{display:block;margin:0;padding:0}
a{text-decoration:none!important;-webkit-transition:0.25s;transition:0.25s;}
a:hover,a:focus{text-decoration:none;}
.xlmm_rec_alert { padding: 10px 16px;color: #fff; background: rgba(0,0,0,0.65);border-radius: 3px; font-size: 14px;font-weight: 100;}

.xlmm-view{background-color:#fff; width:96%; padding:0 2%;}
.xlmm-view .titss h1{font-size: 20px !important;padding-top: 16px;line-height: 28px;font-weight: bolder;color: #3A3A3A;}
.article-header {position: relative;}
.clearfix::after {visibility: hidden;display: block;font-size: 0;content: " ";clear: both;height: 0;}
.xlmm-view .mess p.ycbr { height:2px;}
.pgc-bar-top {margin-top: 12px;}
.pgc-bar-top a.avatar-link {display: block;float: left;}
.avatar {height: 32px;width: 32px;border: 0;border-radius: 32px;}
.pgc-bar-top .subtitle {padding: 1px 0 0 8px;font-size: 0;float: left;}
.pgc-bar-top .name {line-height: 16px;font-size: 12px;}
.pgc-bar-top .name a {color: #406599;}
.pgc-bar-top .subtitle a {color: #333;}
.pgc-bar-top .time {font-size: 0;}
.pgc-bar-top .time span {font-size: 11px;display: inline-block;vertical-align: middle;color: #999;}
.article-header .favor-wrapper {position: absolute;top: 50%;right: 0;-webkit-transform: translateY(-50%);}
.article-header .favor-wrapper .favor-btn {background: #2a90d7;display: block;text-align: center;color: #fff;box-sizing: border-box;width: 72px;height: 28px;line-height: 28px;font-size: 12px;border-radius: 6px;}

.xlmm-view .titss .summary{font-size:11pt;padding:10px 0px;color:#999;margin:10px 0;border-bottom:1px solid #ddd;border-top:1px solid #ddd;}
.xlmm-view .titss .summary strong{color:#FB6156}
.xlmm-view .mess{line-height:30px;font-size:18px;}
.xlmm-view .mess img{max-width:100%; margin-top:2px;}
.xlmm-view .mess iframe{max-width:100%!important; height:300px!important;}
.xlmm-view .xlmm_share{width:90%;padding:5px 10px;border-radius:5px;margin:10px 0;float:left;background-color:#eee;}
.xlmm-view .xlmm_share h3,.xlmm-view .xlmm_share .bdsharebuttonbox{line-height:32px;padding-right:10px;float:left}
.xlmm-view .xlmm_share .bdsharebuttonbox{width:190px;}
.xlmm-view .sxtit em{width:100%;line-height:25px;float:left;white-space:nowrap;text-overflow:ellipsis;overflow:hidden;font-size:11pt;}

.xlmm-view .related{float:left;padding:5px 0;border-bottom:1px solid #ddd;border-top:1px solid #ddd;}
.xlmm-view .related li{list-style:noen;line-height:25px;width:100%;float:left;}
.xlmm-view .related li a{font-size:11pt}
.xlmm-view .xlmm-comment{list-style:noen;line-height:25px;width:100%;float:left;}
.xlmm-view .xlmm-comment textarea{height:56px; margin-bottom:15px;text-indent:7px;width:100%}
.xlmm-view .xlmm-comment .btn{margin:0 0 20px 0;background-color:#FB6156;border-color:#FB6156;border:0px outset buttonface!important;text-align:center;height:30px;width:100%;line-height:30px;color: #FFFFFF;}
.xlmm-view .xlmm-comment .pinlun{position:relative;width:100%;color:#999;padding:16px 0;border-bottom:1px solid #ddd;}
.xlmm-view .xlmm-comment .pinlun .avatar{position:absolute;left:0px;top:16px;}
.xlmm-view .xlmm-comment .pinlun .avatar img{width:32px;height:32px;border-radius:50%;}
.xlmm-view .xlmm-comment .vuser,.xlmm-view .xlmm-comment .vtrim{font-size:11pt}
.xlmm-view .xlmm-comment .viewall a{display:block;text-align:center;font-size:15px;height:34px;line-height:34px;margin:10px;border-radius:2px;border:1px solid #e0e0e0;background-color:#f5f5f5;}
.xlmm-view .mb10{margin-bottom:10px}
.mt20{margin-top:20px}
.xlmm-view .plh3{font-size: 16px;display: inline-block;color: #505050;padding-bottom: 10px;font-weight: 400;border-bottom: 1px solid #f85959;}
/* 表态? */
.atd { margin: 15px auto; }
.atd img {width: 25px;}
.atd a { display: block; color: #999;}
.atd td { padding: 10px 10px 0 10px; text-align: center; vertical-align: bottom; }
.atd .atdc { position: relative; margin: 0 auto 10px; width: 10px; height: 30px; }
.atdc div { position: absolute; left: 0; bottom: 0; width: 10px; text-align: left; }
.atd .ac1 { background: #C30; }
.atd .ac2 { background: #0C0; }
.atd .ac3 { background: #F90; }
.atd .ac4 { background: #06F; }

</style>

<div class="xlmm-view">

			<div class="titss"> 
				<h1>$article[title] <!--{if $article['status'] == 1}--><span>({lang moderate_need})</span><!--{elseif $article['status'] == 2}--><span>({lang ignored})</span><!--{/if}--></h1> 

<div class="article-header">
        
            <div class="pgc-bar-top clearfix" >
                <a href="home.php?mod=space&uid=$article[uid]" class="avatar-link">
                    <div class="avatar">
                        <img src="{avatar($article[uid], small, true)}" alt="$article[username]" class="avatar">
                    </div>
                </a>
                <div class="subtitle">
                    <p class="name"><a href="home.php?mod=space&uid=$article[uid]" class="screen-name vwo-media-profile"><span style="transform-origin: 0px 0px 0px;opacity: 1;transform: scale(1, 1);">$article[username]</span>
</a></p>
                     <a href="javascript:;" class="time">
                        <span>$article[dateline]</span>
                     </a>
                </div>
            </div>
        
            <div class="favor-wrapper">
<!--{if !ckfollow($article['uid'])}-->
					<a id="xlmmfllow" class="gz_$article[uid] {if $_G['uid']}{else}dialog{/if}" onclick="xlmmfollows('xlmmfllow','gz_$article[uid]','$article[uid]')"{if $_G['uid']}  href="javascript:;"{else}href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$article[uid]"{/if}>  <span class="favor-btn xlmmjgz">立即关注</span></a>
				<!--{else}-->
					<a id="xlmmfllow" class="gz_$article[uid]" onclick="xlmmfollows('xlmmfllow','gz_$article[uid]','$article[uid]')" href="javascript:;">  <span class="favor-btn">取消关注</span></a>
				<!--{/if}-->     
            </div>
        </div>

			<!--{if $article[summary] && empty($cat[notshowarticlesummay])}--><div class="summary"><div><strong>{lang article_description}</strong> : $article[summary]</div><!--{hook/view_article_summary}--></div><!--{/if}-->
			</div>
$_G['cache']['plugin']['xlmm_tt']['xlmmadview']
			<div class="mess" id="ycbr">
			<p>$content[content]</p>                
			<!--{if $multi}--><div class="pgbox">$multi</div><!--{/if}-->      
			</div>    
	
	<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<div id="click_div">
		<!--{template home/space_click}-->
	</div>

		                                    

			<div class="sxtit w100">
				<!--{if $article['prearticle']}--><em>{lang pre_article}<a href="{$article['prearticle']['url']}">{$article['prearticle']['title']}</a></em><!--{/if}-->
				<!--{if $article['nextarticle']}--><em>{lang next_article}<a href="{$article['nextarticle']['url']}">{$article['nextarticle']['title']}</a></em><!--{/if}-->
			</div>

           
		    <!--{if $article['related']}-->
		    <div class="related mt20 w100">
				<h3 class="plh3">{lang view_related}</h3>
			<ul>
            <!--{if $_G['setting']['version'] == 'X2.5'}-->
			<!--{loop $article['related'] $raid $rtitle}-->				
			<li><a href="portal.php?mod=view&aid=$raid">{echo cutstr($rtitle,36)}</a></li>
			<!--{/loop}-->
            <!--{else}-->
			<!--{loop $article['related'] $value}-->
			<li><a href="portal.php?mod=view&aid=$value[aid]">{echo cutstr($value[title],36)}</a></li>
			<!--{/loop}-->
            <!--{/if}-->
			</ul>			
		    </div>
				<div class="clearfix">			</div>

	    <!--{/if}-->
           
           <!--{$m_share}-->

		<!--{if $article['allowcomment']==1}-->
        <!--{eval $data = &$article}-->			
            <!--{subtemplate portal/portal_comment}-->
		<!--{/if}-->
{if $_G['uid']} 
<script type="text/javascript">
        function xlmmfollows(val,clsa,aid){
            popup.close();
if(document.getElementById(val).innerHTML.indexOf("xlmmjgz") >= 0){
var xlmmhref = 'home.php?mod=spacecp&ac=follow&op=add&fuid='+aid+'&hash={FORMHASH}';
}else{
var xlmmhref = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+aid;
}
            popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
            $.ajax({
                type:'GET',
                url:xlmmhref + '&inajax=1',
                dataType:'xml',
            })
            .success(function(s) {	
                if(s.lastChild.firstChild.nodeValue.indexOf("不能关注自己") >= 0){
popup.open('<div class="xlmm_rec_alert">不能关注自己</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("成功收听") >= 0){
$("."+clsa).html('<em class="favor-btn">取消关注</em>');
popup.open('<div class="xlmm_rec_alert">关注成功</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("取消成功") >= 0){
$("."+clsa).html('<em class="favor-btn xlmmjgz">立即关注</em>');
popup.open('<div class="xlmm_rec_alert">已取消关注</div>');
}else if(s.lastChild.firstChild.nodeValue.indexOf("您已经收听了") >= 0){
			popup.open('<div class="xlmm_rec_alert">您已经关注过了</div>');
}

         var xlmmclose = setTimeout(popup.close,1500);
       })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
            return false;
        };

    </script>
{/if} 
</div>
				<div class="clearfix">			</div>
				
<style type="text/css">
.list_pt10 {
background: #f4f5f6;
padding-top: 10px;}
.container__header {  width: 100%;font-size: 15px;line-height: 15px;padding: 14px 0 11px 15px;display: inline-block;font-weight: 400; color: #222;background-color: #fff;-ms-box-sizing: border-box;box-sizing: border-box;border-bottom: .5px solid #e8e8e8;}


</style>
<div class="list_pt10">
<h2 class="container__header">最新推荐</h2>
</div>
<content class="feed-list-container" id="junmi360" style="padding-top:0" >
<div class="list_content">

		{eval include TPLDIR.'/php/list.php';}
	<!--{loop $list $value}-->
				<!--{eval $article_url = fetch_article_url($value);
}-->
			{eval include TPLDIR.'/php/portal_list.php';}
<!--{if $xlmmal ==0}-->
<section class="has_action"><a href="{if $_G['cache']['plugin']['xlmm_tt']['xlmmtapp']}{$_G['cache']['plugin']['xlmm_tt']['xlmmappurl']}{else}$article_url{/if}" class="article_link clearfix "><div class="item_detail">										
<h3 class="dotdot line3">$value[title]</h3><div class="item_info"><div>{if $_G['cache']['plugin']['xlmm_tt']['xlmmtapp']}<span class="src space" style="color:red">打开APP</span>{else}<span class="src space">$value[username]</span>{/if}<span class="cmt space">回复 $value[commentnum]</span><span class="time">$value[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>

<!--{elseif $xlmmal >2}-->
<section class="has_action"><a href="{if $_G['cache']['plugin']['xlmm_tt']['xlmmtapp']}{$_G['cache']['plugin']['xlmm_tt']['xlmmappurl']}{else}$article_url{/if}" class="article_link clearfix "><div class="item_detail"><h3 class="dotdot line3">$value[title]</h3>
 <div class="list_image" style="margin-top:5px;">
<ul class="clearfix">
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmoutimg $key $xlmmimg}-->
<li class="list_img_holder"><!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->
<img src="<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1}-->$xlmmimg<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->template/xlmm_zx/php/small.php?filename=<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->&width=230&height=230<!--{/if}-->" class="xlmmlazy">
						<!--{else}-->
<img src="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment']<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 4}-->.thumb.jpg<!--{/if}-->" class="xlmmlazy">
<!--{/if}-->
</li>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==3) break;}-->
<!--{/loop}-->
    </ul>
</div>
<div class="item_info"><div>{if $_G['cache']['plugin']['xlmm_tt']['xlmmtapp']}<span class="src space" style="color:red">打开APP</span>{else}<span class="src space">$value[username]</span>{/if}<span class="cmt space">回复 $value[commentnum]</span><span class="time">$value[dateline]</span><span class="dislike-news fr"></span></div></div></div></a></section>
<!--{elseif $xlmmal <=2}-->
<section class="middle_mode has_action"><a href="{if $_G['cache']['plugin']['xlmm_tt']['xlmmtapp']}{$_G['cache']['plugin']['xlmm_tt']['xlmmappurl']}{else}$article_url{/if}" class="article_link clearfix "><div class="item_detail desc">                                        <h3 class="dotdot line3 image-margin-right">$value[title]</h3><div class="item_info"><div>{if $_G['cache']['plugin']['xlmm_tt']['xlmmtapp']}<span class="src space" style="color:red">打开APP</span>{else}<span class="src space">$value[username]</span>{/if}<span class="cmt space">回复 $value[commentnum]</span><span class="time">$value[dateline]</span><span class="dislike-news fr mid-space"></span></div></div></div>
   <!--{eval $xlmm=0;}-->
<!--{loop $xlmmoutimg $key $xlmmimg}-->

 <div class="list_img_holders"> <!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1 || $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->
<img src="<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 1}-->$xlmmimg<!--{elseif $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 2}-->template/xlmm_zx/php/small.php?filename=<!--{if strpos($xlmmimg,"http")!== false  }-->$xlmmimg<!--{else}-->$_G['siteurl']$xlmmimg<!--{/if}-->&width=230&height=230<!--{/if}-->" class="xlmmlazy">
						<!--{else}-->
<img src="{if $xlmmimg[remote] == 1}$_G['setting']['ftp']['attachurl']{else}$_G['setting']['attachurl']{/if}portal/$xlmmimg['attachment']<!--{if $_G['cache']['plugin']['xlmm_tt']['xlmmttslt'] == 4}-->.thumb.jpg<!--{/if}-->" class="xlmmlazy">
<!--{/if}-->
</div>
    <!--{eval $xlmm++}-->
<!--{eval if($xlmm==1) break;}-->
<!--{/loop}-->
    </a></section>

 <!--{/if}-->
			<!--{/loop}-->

</div></content>
            <div>
    <div id="ajaxlast" style="text-align: center;position: relative;padding: 12px 0; padding-bottom:6px;"><a href="./" style="cursor: pointer;font-size: 14px;line-height: 22px;border-radius: 29px;color: #406599;">查看更多</a></div>
</div>
		<!--{if $article['allowcomment']==1}-->
                   <!--{eval $xlmmplk=DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='aid' and id=".$article[aid]."");}--> 
                   <!--{eval $xlmmplks= DB::result_first("select count(*)  FROM ".DB::table("home_favorite")." WHERE `idtype`='aid' and id=".$article[aid]."");}--> 
<div class="xlmmthftc cl">
	<a {if $_G['uid']} onClick="nryhf()" {else}href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}"{/if}class="nrdb_hf {if $_G['uid']}{else}dialog{/if}">说点什么吧...</a>
	<a onClick="nrywfx()" style="margin-top:10px;"><i class="iconfont iconfx"></i></a>
	<a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" class="dialog"><i {if $xlmmplk[id]}style="color:#f15450" {/if}class="iconfont iconsc"></i><em id="favoritenumber"{if $xlmmplks<1} style="display:none"{/if}>$xlmmplks</em></a>
	<a onclick="javascript:document.getElementById('xlmmgpl').scrollIntoView()"><i class="iconfont iconhf"></i><em id="recommendv_add">$data[commentnum]</em></a>
</div>
	<script>window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"$article[title] - $_G['setting'][sitename]","bdMini":"2","bdStyle":"0","bdSize":"16"},"share":{},"image":{"viewList":["qzone","tsina","tqq","renren","weixin"],"viewText":"","viewSize":"16"},"selectShare":{"bdContainerClass":null,"bdSelectMiniList":["qzone","tsina","tqq","renren","weixin"]}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='{if $_G['cache']['plugin']['xlmm_tt']['xlmmshttps']}{else}http://bdimg.share.baidu.com{/if}/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];</script>
 <!--{/if}-->
<script>
var div=document.getElementById("ycbr");
div.innerHTML=div.innerHTML.replace(/<br>/g,"<p class=\"ycbr\"></p>");
</script>

<!--{template common/footer}-->


