<?php echo '';exit;?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<div class="xlmm_sc cl">
    <div class="srk cl">
        <input value="$keyword" autocomplete="off" class="srky" name="srchtxt" id="scform_srchtxt" value="">
	</div>
    <div class="san cl">
	    <input type="hidden" name="searchsubmit" value="yes"><input type="submit" value="{lang search}" class="sany" id="scform_submit">
	</div>
</div>



