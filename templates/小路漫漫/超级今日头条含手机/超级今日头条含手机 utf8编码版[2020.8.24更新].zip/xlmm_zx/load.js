var lazyload_height = 0;
(function(jQuery, window, document, undefined) {
    var jQuerywindow = jQuery(window);
    jQuery.fn.lazyload = function(options) {
        var elements = this;
		var update_time;
        var jQuerycontainer;
        var settings = {
            threshold       : 200,
            failure_limit   : 50,
            event           : "scroll",
            effect          : "show",
            container       : window,
            data_attribute  : "xlmmlazy",
            skip_invisible  : false,
            appear          : null,
            load            : null,
            placeholder     : "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"
        };
		function s_update() {
			var counter = 0;
			if(lazyload_height < jQuery(document).height()){
				lazyload_height = jQuery(document).height();
				jQuery("img.xlmmlazy").lazyload();
			}
			elements.each(function() {
				var jQuerythis = jQuery(this);
				if (settings.skip_invisible && !jQuerythis.is(":visible")) {
					return;
				}
				if (jQuery.abovethetop(this, settings) ||
					jQuery.leftofbegin(this, settings)) {
				} else if (!jQuery.belowthefold(this, settings) &&
					!jQuery.rightoffold(this, settings)) {
						jQuerythis.trigger("appear");
						counter = 0;
				} else {
					if (++counter > settings.failure_limit) {
						return false;
					}
				}
			});
		
		}
        function update() {
			clearTimeout(update_time);
			update_time = setTimeout(function(){
				s_update();
			}, 60);
        }
        if(options) {
            if (undefined !== options.failurelimit) {
                options.failure_limit = options.failurelimit;
                delete options.failurelimit;
            }
            if (undefined !== options.effectspeed) {
                options.effect_speed = options.effectspeed;
                delete options.effectspeed;
            }

            jQuery.extend(settings, options);
        }
        jQuerycontainer = (settings.container === undefined ||
                      settings.container === window) ? jQuerywindow : jQuery(settings.container);
        if (0 === settings.event.indexOf("scroll")) {
            jQuerycontainer.bind(settings.event, function() {
                return update();
            });
        }
        this.each(function() {
            var self = this;
            var jQueryself = jQuery(self);
            self.loaded = false;
            if (jQueryself.attr("src") === undefined || jQueryself.attr("src") === false) {
                if (jQueryself.is("img")) {
                    jQueryself.attr("src", settings.placeholder);
                }
            }
            jQueryself.one("appear", function() {
                if (!this.loaded) {
                    if (settings.appear) {
                        var elements_left = elements.length;
                        settings.appear.call(self, elements_left, settings);
                    }
                    jQuery("<img />")
                        .bind("load", function() {
							jQueryself.removeClass("xlmmlazy");
                            var original = jQueryself.attr("" + settings.data_attribute);
                            jQueryself.hide();
                            if (jQueryself.is("img")) {
                                jQueryself.attr("src", original);
                            } else {
                                jQueryself.css("background-image", "url('" + original + "')");
                            }
                            jQueryself[settings.effect](settings.effect_speed);

                            self.loaded = true;

                            /* Remove image from array so it is not looped next time. */
                            var temp = jQuery.grep(elements, function(element) {
                                return !element.loaded;
                            });
                            elements = jQuery(temp);

                            if (settings.load) {
                                var elements_left = elements.length;
                                settings.load.call(self, elements_left, settings);
                            }
                        })
                        .attr("src", jQueryself.attr("" + settings.data_attribute));
                }
            });
            if (0 !== settings.event.indexOf("scroll")) {
                jQueryself.bind(settings.event, function() {
                    if (!self.loaded) {
                        jQueryself.trigger("appear");
                    }
                });
            }
        });
        jQuerywindow.bind("resize", function() {
            update();
        });
        if ((/(?:iphone|ipod|ipad).*os 5/gi).test(navigator.appVersion)) {
            jQuerywindow.bind("pageshow", function(event) {
                if (event.originalEvent && event.originalEvent.persisted) {
                    elements.each(function() {
                        jQuery(this).trigger("appear");
                    });
                }
            });
        }
        jQuery(document).ready(function() {
			setTimeout(function(){
				update();
			}, 100);
        });

        return this;
    };
    jQuery.belowthefold = function(element, settings) {
        var fold;

        if (settings.container === undefined || settings.container === window) {
            fold = (window.innerHeight ? window.innerHeight : jQuerywindow.height()) + jQuerywindow.scrollTop();
        } else {
            fold = jQuery(settings.container).offset().top + jQuery(settings.container).height();
        }

        return fold <= jQuery(element).offset().top - settings.threshold;
    };

    jQuery.rightoffold = function(element, settings) {
		return 0;
        var fold;

        if (settings.container === undefined || settings.container === window) {
            fold = jQuerywindow.width() + jQuerywindow.scrollLeft();
        } else {
            fold = jQuery(settings.container).offset().left + jQuery(settings.container).width();
        }
	
        return fold <= jQuery(element).offset().left - settings.threshold;
    };

    jQuery.abovethetop = function(element, settings) {
        var fold;

        if (settings.container === undefined || settings.container === window) {
            fold = jQuerywindow.scrollTop();
        } else {
            fold = jQuery(settings.container).offset().top;
        }

        return fold >= jQuery(element).offset().top + settings.threshold  + jQuery(element).height();
    };

    jQuery.leftofbegin = function(element, settings) {
		return 0;
        var fold;

        if (settings.container === undefined || settings.container === window) {
            fold = jQuerywindow.scrollLeft();
        } else {
            fold = jQuery(settings.container).offset().left;
        }

        return fold >= jQuery(element).offset().left + settings.threshold + jQuery(element).width();
    };

    jQuery.inviewport = function(element, settings) {
         return !jQuery.rightoffold(element, settings) && !jQuery.leftofbegin(element, settings) &&
                !jQuery.belowthefold(element, settings) && !jQuery.abovethetop(element, settings);
     };
    jQuery.extend(jQuery.expr[":"], {
        "below-the-fold" : function(a) { return jQuery.belowthefold(a, {threshold : 0}); },
        "above-the-top"  : function(a) { return !jQuery.belowthefold(a, {threshold : 0}); },
        "right-of-screen": function(a) { return jQuery.rightoffold(a, {threshold : 0}); },
        "left-of-screen" : function(a) { return !jQuery.rightoffold(a, {threshold : 0}); },
        "in-viewport"    : function(a) { return jQuery.inviewport(a, {threshold : 0}); },
        "above-the-fold" : function(a) { return !jQuery.belowthefold(a, {threshold : 0}); },
        "right-of-fold"  : function(a) { return jQuery.rightoffold(a, {threshold : 0}); },
        "left-of-fold"   : function(a) { return !jQuery.rightoffold(a, {threshold : 0}); }
    });
	jQuery.fn.extend({
		append: function(a, b) {
			return this.domManip(arguments, !0,function(e){(this.nodeType === 1 || this.nodeType === 11) && this.appendChild(e)}) && jQuery("img.xlmmlazy").lazyload() ;
		}
	});
})(jQuery, window, document);


