function succeedhandle_forum_fav(a, b, c){
	if(b.indexOf("收藏成功") >= 0){
		b = '版块关注成功';
	var numObj = $('.xlmm_forum_fav_'+ c['id']);
	numObj.attr('href', 'home.php?mod=spacecp&ac=favorite&op=delete&type=forum&formhash='+formhash+'&favid=' + c['favid'] + '&handlekey=forum_fav').text('已关注').removeClass('xlmmfwgz').addClass("xlmmfygz");
var numObj = $('.xlmm_forum_favs_'+ c['id']);
var memberNum = parseInt(numObj.html());
numObj.html(memberNum+1);
	}
	popup.open(b, 'alert');
}
function errorhandle_forum_fav(a, b){
	if(a.indexOf("重复收藏") >= 0){
		a = '版块已关注';
	}else if(a.indexOf("不存在") >= 0){
		a = '您还没有关注此版块';
	}
	popup.open(a, 'alert');
}
function succeedhandle_favorite_del(a, b, c){
	if(b.indexOf("成功") >= 0){
		b = '已取消关注此版块';
		var numObj = $('.xlmm_forum_fav_'+ c['id']);
numObj.attr('href', 'home.php?mod=spacecp&ac=favorite&type=forum&id=' + c['id'] + '&formhash='+formhash+'&handlekey=forum_fav').text('+ 关注').removeClass('xlmmfygz').addClass("xlmmfwgz");
var numObj = $('.xlmm_forum_favs_'+ c['id']);
var memberNum = parseInt(numObj.html());
numObj.html(memberNum-1);
	}
	popup.open(b, 'alert');
}
function errorhandle_favorite_del(a, b){
	if(a.indexOf("不存在") >= 0){
		a = '您还没有关注此版块';
	}
	popup.open(a, 'alert');
}



