var dialog = {
	init : function() {
		$(document).on('click', '.dialog', function() {
			var obj = $(this);
			if(!obj.attr('xlmm')){
				popup.open('<img src="' + IMGDIR + '/imageloading.gif" class="xlmm_loading">');
			}else{
				popup.close();
			}
			$.ajax({
				type : 'GET',
				url : obj.attr('href') + '&inajax=1',
				dataType : 'xml'
			})
			.success(function(s) {
				if(obj.attr('xlmm') == 'handle'){
					if(xlmm_ishandle(s.lastChild.firstChild.nodeValue)){
						return false;
					}
				}
				popup.open(s.lastChild.firstChild.nodeValue);
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});
	},
};

function xlmm_ishandle(s) {
	if(s.indexOf("typeof succeedhandle_") > 0 || s.indexOf("typeof errorhandle_") > 0){
		var r = s.match(/<script.*>if(.*?)<\/script>/);
		if(r != null){
			appendscript('', 'if'+r[1], true);
			return true;
		}
	}
	return false;
}

var formdialog = {
	init : function() {
		$(document).on('click', '.formdialog', function() {
			var obj = $(this);
			if(obj.attr('onsubmit')){
				eval('var $return_data=' + obj.attr('onsubmit') + ';');
				if($return_data == 1){
					return false;
				}
			}
			if(!obj.attr('xlmm')){
				popup.open('<img src="' + IMGDIR + '/imageloading.gif" class="xlmm_loading">');
			}else{
				popup.close();
			}
			var formobj = $(this.form);
			$.ajax({
				type:'POST',
				url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
				data:formobj.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				if(obj.attr('xlmm') == 'handle'){
					if(xlmm_ishandle(s.lastChild.firstChild.nodeValue)){
						return false;
					}
				}
				if(obj.attr('xlmm') == 'xlmmpay'){
					if(s.lastChild.firstChild.nodeValue){
						s.lastChild.firstChild.nodeValue = s.lastChild.firstChild.nodeValue.replace('$(\'payform\')','$(\'#payform\')');
					}
				}	
				popup.open(s.lastChild.firstChild.nodeValue);
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				popup.open('Ajax 出错!', 'alert');
				popup.close();
			});
			return false;
		});
	}
};



