<?PHP exit('Access Deniedxl');?>
<!--{subtemplate common/header}-->
	<style id="diy_style" type="text/css"></style>
	<style type="text/css">
	
.main-portal-inner.sticky {position: fixed;top: 0px; z-index:1}
.main-portal {min-height: 30px;}
.absolute { position: absolute; z-index:1}
	</style>
	<!--{if empty($gid)}-->
			{eval include TPLDIR.'/php/forum_guide.php';}
			{eval include TPLDIR.'/php/video.php';}
<link rel="stylesheet" href="$_G['style']['styleimgdir']/tb1.css" />
	 <script src="template/mmtieba/image/js/fu.js" type="text/javascript"></script>
<script src="template/mmtieba/jquery.ias.min.js" type="text/javascript"></script>
	<div class="z"><!--{hook/index_status_extra}--><!--{hook/index_nav_extra}--></div>
<div class="wp">
  		<!--[diy=xlmmad1]--><div id="xlmmad1" class="area"></div><!--[/diy]-->
           <!--pa-->  
<!--{hook/index_top}-->
		<!--{hook/index_catlist_top}-->
									<!--{hook/index_followcollection_extra $colletion[ctid]}-->
<div class="top-sec clearfix">
<div class="pal">
<div class="slideshow_container">
           <div class="sdsh">
 		<!--[diy=xlmms1]--><div id="xlmms1" class="area"></div><!--[/diy]-->
   </div>
    <div class="top_progress_bar cl">
        <span class="prev"></span>
        <ul>
        <li class="on"></li></ul>
        <span class="next"></span>
    </div></div>
</div>

<div class="par rec_login">
<div class="num_list"> <i class="nl">����</i> <span class="numbertz" ></span> <i class="nr">����</i>
</div>
 <!--{if !$_G['uid']}--><a href="member.php?mod=logging&action=login" class="btn_login"></a><!--{/if}-->
</div>
<div class="clear"></div>
  		<!--[diy=xlmmad2]--><div id="xlmmad2" class="area"></div><!--[/diy]-->
           <!--pb-->  
<div class="mt10"></div>
<div class="xlmmc">
   <div id="xlmmheaders"></div>
<div class="main-portal pabl xlmmb" id="pid0">
 	<div class="main-portal-inner" data-sticky="0" data-header="#xlmmheaders" data-bottom=".xlmmfooterh" data-delegate=".main-portal">
				<!--{if $_G['uid']}-->
  <div class="region_bright my_tieba_mod">
   <h4 class="region_header clearfix"> 
          ��������<span class="pull_right"> 
          </span></h4>
          <div class="region_cnt clearfix">
             {eval	
$postss = getuserprofile('posts');
}
                      <div class="media_horizontal clearfix ">
                          <a class="media_left" href="home.php?mod=space&uid=$_G[uid]" target="_blank"><em class="head_img"><!--{avatar($_G[uid],middle)}--></em></a>
<div class="media_right"> 
  <div class="text_overflow">
<a href="home.php?mod=space&uid=$_G[uid]" target="_blank" style=" display:block">{echo cutstr($_G[member][username],10)}</a>
</div>            
<i class="icon_money"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a"><!--{echo dnumber($_G['member']['extcredits2'])}--></a>
<p class="orange_text"><i class="icon_credits"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a">$_G[member][credits]</a></p>
<p><a href="home.php?mod=spacecp&ac=credit&op=rule">[���ֹ���]</a></p>
</div> </div>  </div>  </div>   
      <div class="clear"></div>
     <div class="u-f-t">
     <div class="titles">����İ�</div>
                     <a href="home.php?mod=space&do=favorite&type=forum" target="_blank"><div class="edit color2"></div></a>
 <!--{if $_G['setting']['disfixednv_forumindex'] }-->
{if $_G['cache']['plugin']['dsu_paulsign']['ifopen']}
{eval  $time = DB::fetch_all("SELECT value as time FROM ".DB::table('common_pluginvar')." WHERE `variable`='timeopen' or `variable`='stime' or `variable`='ftime'");$open = $time[1][time];$a = date('Y-m-d ',time());$b ="0:0";$stime = strtotime($a.$time[0][time].":".$b);$ftime = strtotime($a.$time[2][time].":".$b);$time = strtotime(date('Y-m-d',time()));
$count = DB::fetch_all("SELECT COUNT(*) as dd FROM ".DB::table('dsu_paulsign')." WHERE time >= $time AND `uid` =".$_G[uid]."");$count[0][dd]}
<a  {if $count[0][dd] ==0}onclick="showWindow('dsu_paulsign', 'plugin.php?id=dsu_paulsign:sign')" href="javascript:" {else}href="plugin.php?id=dsu_paulsign:sign" target="_blank"{/if}  class="onekey_btn y"></a>{/if}<!--{/if}-->
</div>
<div class="u-f-w">
<div id="likeforumwraper" class="clearfix">
                                        <!--{eval $favorite=DB::fetch_all("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid'");}--> 
                                        <!--{loop $favorite $key $favorite}-->
										<!--{hook/index_favforum_extra $forum[fid]}-->
<a href="forum.php?mod=forumdisplay&fid={$favorite[id]}"  class="u-f-item unsign" target="_blank"><i><!--{echo cutstr($favorite[title], 10)}--></i><span class="forum_level"></span></a>
                                        <!--{/loop}-->
</div>
<div class="more-wraper" style="display:block"><a href="#" class="more"><span class="more-txt">�鿴����</span><span class="more-triangle"></span></a>
</div>
</div>
<!--{/if}-->
<div class="u-f-t ufw-gap">
<div class="titles">���ɷ���</div>
<div class="gap y" style="width:120px; margin-top:10px;"></div>
</div>
<div class="f-d-w">
<style type="text/css">
.active{opacity:0.8;}
.pdnav{}
.pdnav li{width:195px;float:left;overflow: hidden;*zoom:1;margin:5px 0 0 10px;}
.pdnav li .pd-l{width:75px;float: left;}
.pdnav li .pd-l img{width:64px; height:64px}
.pdnav li .pd-r{width:120px;float:left; }
.pdname{font:normal 14px/2  "΢���ź�";color:#666;text-align: left;width:195px;overflow: hidden;display: block; height:20px;}
.pdnum{line-height: 18px;margin-left:10px; margin-top:3px;}
.on .pdnum a{color:#999999;}
.on .pdnum a:hover{text-decoration: underline;}
#favatar0{ position:relative\0 !important;}
</style>

									<!--{eval $k = 1;}-->
<!--{eval $gidiconnum = 0;}-->
<!--{loop $catlist $key $cat}-->
			<!--{hook/index_catlist $cat[fid]}-->
<!--{eval $caturl = !empty($cat['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$cat['domain'].'.'.$_G['setting']['domain']['root']['forum'] : '';}-->
<!--{eval $gidiconnum ++;}-->  

<div class="f-d-item fb{$k} mainCate"><div class="f-d-item-content">
<div class="titles"><span class="typeicon forum{$k}"></span><a href="{if !empty($caturl)}$caturl{else}forum.php?gid=$cat[fid]{/if}" style="{if $cat[extra][namecolor]}color: {$cat[extra][namecolor]};{/if}">$cat[name]</a>
</div>
<!--{eval $i++;}-->
  <!--{eval $fidnum = 0;}-->
<div style="width:190px"<!--{if $_G['cache']['plugin']['xlmmtb']['xlmmtbbkyc'] }--> class="directory-wraper" <!--{/if}-->>
	<!--{loop $cat[forums] $forumid}-->
<!--{eval $forum=$forumlist[$forumid];}-->
<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
<!--{eval $fidnum ++;}-->
<a href="$forumurl" target="_blank"{if $forum[extra][namecolor]} style="color:{$forum[extra][namecolor]};"{/if}>$forum[name]</a>
<!--{/loop}-->
</div></div>
<!--{if $_G['cache']['plugin']['xlmmtb']['xlmmtbbkyc'] }-->
	<div class="subCate " style=" margin-left:200px; margin-top:-100px; position:absolute; width:666px; height:auto;">
<div class="pop-up-container"><div class="directory-pop-frame"><div class="d-title "><a href="{if !empty($caturl)}$caturl{else}forum.php?gid=$cat[fid]{/if}" title="$cat[name]" >$cat[name]</a></div>
	<ul class="pdnav cc">
									<!--{eval $kb = 1;}-->
	<!--{loop $cat[forums] $forumid}-->
<!--{eval $forum=$forumlist[$forumid];}-->
<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
<!--{eval $fidnum ++;}-->
		<li> <p><a href="$forumurl" target="_blank"{if $forum[extra][namecolor]} style="color:{$forum[extra][namecolor]};"{/if} title="$forum[name]" class="pdname">$forum[name]</a></p>
   <div class="pd-l">
  <!--{if $forum[icon]}-->$forum[icon]<!--{else}--><a href="$forumurl" target="_blank"><img src="$_G['style']['styleimgdir']/0{$kb}.png" alt="$forum[name]" /></a><!--{/if}--> </div>
 <div class="pd-r"> <p class="pdnum">{lang forum_threads}: (<!--{echo dnumber($forum[threads])}-->)</p><p class="pdnum">{lang forum_posts}: (<!--{echo dnumber($forum[posts])}-->)</p>  <p class="pdnum"><!--{if $forum['lastpost']['author']}--><a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost"><!--{echo cutstr($forum[lastpost][subject], 10)}--></a>	<!--{hook/index_forum_extra $forum[fid]}-->
 <!--{else}-->��������<!--{/if}--></p> </div></li>
									<!--{eval $kb >= 9 ? $kb = 1 : $kb++;}-->
<!--{/loop}-->

                </ul>
<div class="clear"></div>
<div class="rec-forum">
<div class="rec-icon">��������</div>
	<!--{if $cat['moderators']}-->$cat[moderators]<!--{else}--><a href="<!--{$_G['cache']['plugin']['xlmmtb']['xlmmtbsqbz']}-->" target="_blank" >��������û�а�����������롣</a><!--{/if}-->
	</div></div></div></div>	
   <!--{/if}--> 
    					</div>

									<!--{eval $k ++;}-->
<!--{/loop}-->

<div class="all-wraper"><a target="_blank" href="$_G['cache']['plugin']['xlmmtb']['xlmmtbckqb']" class="all"><span class="more-txt">�鿴ȫ��</span></a>
</div>
<div class="clear"></div>
</div>
</div>
</div>
<div class="pabr">
<div class="">
  		<!--[diy=xlmmq]--><div id="xlmmq" class="area"></div><!--[/diy]-->
  </div>

<div class="clear" style="margin-top:20px;"></div>
<div class="r-left-sec pablbox">
<div class="spage_liveshow_slide clearfix">
<div class="slide_outer_wrap game_slide_wrap">
<a class="titlesss j_slide_title_yy" href="/" target="_blank">���ֶһ�</a>
 		<!--[diy=xlmmsx]--><div id="xlmmsx" class="area"></div><!--[/diy]-->
</div>
<div class="slide_outer_wrap">
<a class="titlesss" href="/" target="_blank">�����Ƽ�</a>
 		<!--[diy=xlmms4]--><div id="xlmms4" class="area"></div><!--[/diy]-->
</div></div>
<div class="clear"></div>

<div class="platact_bigouter">
<div class="hdshow">
 		<!--[diy=xlmms5]--><div id="xlmms5" class="area"></div><!--[/diy]-->
			  </div>
	 </div>

       <div class="forum_sub slideTxtBox">
                              
							  <div class="tag_nav_more"><a href="forum.php?mod=guide" target="_blank">�������>></a></div>
<div class="tag_nav cl">
					<ul class="hd">
<li class="on"><span><a href="forum.php?mod=guide&view=new" target="_blank">���»ظ�</a></span></li>
<li><span><a href="forum.php?mod=guide&view=newthread" target="_blank">���·���</a></span></li>
<li><span><a href="forum.php?mod=guide&view=hot" target="_blank">��������</a></span></li>
</ul>
                             </div>
     <script type="text/javascript">zoomstatus = parseInt(1);var imagemaxwidth = '600';var aimgcount = new Array();</script>
			<style>
.zoominner p {padding: 8px 0; color:#fff;}	
.zoominner p a.imgclose:hover {background-position: -80px -39px;}
.zoominner p a.imgadjust {background-position: -40px 0; display:none;}
.zoominner p a.imgclose {background-position: -80px 0;}
.zoominner p a:hover {background-position: 0 -39px;}
.zoominner p a {float: left;margin-left: 10px;width: 17px;height: 17px;background: url(static/image/common/imgzoom_tb.gif) no-repeat 0 0;line-height: 100px;overflow: hidden;}
.zoominner {padding: 5px 10px 10px;background: #FFF;text-align: left;}	

.tagbg {height: 16px;line-height: 16px;*line-height: 18px;display: inline-block;padding: 0 0 0 5px;margin-right: 5px;*display: inline;float: left;margin-top: 1px;}
.tag-img {background: #f2934a;}
.tag-video {background: #cc6ee3;}
.tag-audio {background: #74c587;}
.tag_nav_1 .fn a.tag-name {display: inline-block;text-decoration: none;color: #fff;margin-right: 2px;line-height: 16px; font-size:12px;font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;}
.triangle {display: inline-block;width: 0; height: 0;overflow: hidden;line-height: 0;  font-size: 0;border-width: 4px 4px 4px 0;border-color: transparent #fff transparent transparent; border-style: dashed solid dashed none;_margin-top: 4px;}
.tag_nav_1 .thtit a .xlmmxhx:hover { text-decoration:underline;}
	</style>
		<div class="tag_nav_1 bd">

    <!--{eval $page=$_G['page'];}-->
	        	                        <ul id="alist">
									        	<!--{loop $grids['newthread'] $thread}-->
  											<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
		{eval include TPLDIR.'/php/forum.php';}
{eval $xlmmmedia=xlmmthread('media',$thread[message],1);$xlmmflash=xlmmthread('flash',$thread[message],1); $xlmmaudio=xlmmthread('audio',$thread[message],1);
                $xlmmbio = DB::fetch_all("SELECT name FROM  ".DB::table('forum_forum')." WHERE `fid` = $thread[fid]");}

				<li class="xlmmlists">
<p class="fn">	
{if $xlmmaudio}<span class="tagbg tag-audio"><a href="javascript:;" class="tag-name">������</a><a href="javascript:;" class="triangle"></a></span>{elseif $xlmmflash || $xlmmmedia}<span class="tagbg tag-video"><a href="javascript:;" class="tag-name">��Ƶ��</a><a href="javascript:;" class="triangle"></a></span>{elseif $xlmmattach}<span class="tagbg tag-img"><a href="javascript:;" class="tag-name">ͼƬ��</a><a href="javascript:;" class="triangle"></a></span>{/if}
<a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">{loop $xlmmbio $key $xlmmbio} $xlmmbio[name] {/loop}</a></p>
<p class="thtit">
<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" target="_blank" style="text-decoration:none;"><!--{if $thread[folder] == 'lock'}-->
											<img src="$_G['style']['styleimgdir']/folder_lock.gif" align="absmiddle" style="margin-right:5px;" />
										<!--{elseif $thread['special'] == 1}-->
											<img src="$_G['style']['styleimgdir']/pollsmall.gif" align="absmiddle" alt="{lang thread_poll}" style="margin-right:5px;" />
										<!--{elseif $thread['special'] == 2}-->
											<img src="$_G['style']['styleimgdir']/tradesmall.gif" align="absmiddle" alt="{lang thread_trade}" style="margin-right:5px;" />
										<!--{elseif $thread['special'] == 3}-->
											<img src="$_G['style']['styleimgdir']/rewardsmall.gif" align="absmiddle" alt="{lang thread_reward}" style="margin-right:5px;" />
										<!--{elseif $thread['special'] == 5}-->
											<img src="$_G['style']['styleimgdir']/debatesmall.gif" alt="{lang thread_debate}" style="margin-right:5px;" />
										<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
<img src="$_G['style']['styleimgdir']/pin.gif" align="absmiddle" title="$_G[setting][threadsticky][3-$thread[displayorder]]" style="margin-right:5px;"  />
										<!--{/if}-->
																				<!--{if $thread['digest']}-->
											<img src="$_G['style']['styleimgdir']/digest.gif" align="absmiddle" title="{lang thread_digest} $thread[digest]" style="margin-right:5px;"  />
										<!--{/if}--><em class="xlmmxhx">$thread[subject]</em></a>
<span class="list-post-num"><em>$thread[views]</em><span class="list-triangle-border"></span><span class="list-triangle-body"></span></span>
</p>
		<p class="thsum">$xiaolu['fmessage']</p>
<!--{if $xlmmflash || $xlmmmedia || $xlmmaudio}-->                                                                    
          <ul style="height: auto; overflow: hidden;">
{if $xlmmaudio}
                {loop $xlmmaudio $audio}
                      <li style="height: 135px; width:250px; overflow: hidden;background:#000000"><embed src="$audio" width="250" height="135"  wmode="transparent"/></li>
                 {/loop}

{elseif $xlmmmedia}
                {loop $xlmmmedia $media}
                      <li style="height: 135px; width:240px; overflow: hidden;background:#000000"><embed src="$media" width="240" height="135"  wmode="transparent"/></li>
                 {/loop}
                 {elseif $xlmmflash}
                      {loop $xlmmflash $flash}
                      <li style="height: 135px; width:240px; overflow: hidden;background:#000000"><embed src="{$flash}" width="240" height="135"  wmode="transparent"></li>
                      {/loop}
                  {/if}
              </ul>
<!--{elseif $xlmmattach}-->
                  <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" target="_blank">  <p class="n_img">  
   <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,150,150));}
														<!--{else}-->
								{eval $xlmmimg = $attach['attachment']; }
		<!--{/if}-->
<div style=" width:150px;height: 105px; overflow: hidden; float:left;margin-right: 11px;
_margin-right: 7px;"><img src="$xlmmimg" width="150" height="105"></div>
 <!--{eval $i++}-->
<!--{eval if($i==3) break;}-->
<!--{/loop}--> 
</p></a> 
<div class="clear"></div>
										<!--{/if}-->
<p class="thutss"><span class="s1"><i>��󷢱���</i><a href="{if $thread[digest] != -2 && !$thread[ordertype]}forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost$highlight#lastpost{else}forum.php?mod=viewthread&tid=$thread[tid]{if !$thread[ordertype]}&page={echo max(1, $thread[pages]);}{/if}{/if}" target="_blank">$thread[lastposter]</a></span><span class="s2"><i>�����ڣ�</i>$thread[lastpost]</span></p>
</li>
							<!--{/loop}-->
</ul>
<div id="xlmmpg" style="display:none">$multi</div>


                     </div>

                            </div>
                      </div>
              
<div class="r-right-sec allboxs">
<div id="rlboxs">
<div class="right_wrap">
<!--{hook/index_side_top}-->
<div class="media_item">
 <div class="member_rank_title">
 <span class="titles">��������</span>
            <a class="verify_link" target="_blank" href="/">�鿴����</a>
 </div>
		   <div class="slide_scroll">
 		<!--[diy=xlmms6]--><div id="xlmms6" class="area"></div><!--[/diy]-->
</div></div>
<div> 

<div class="hyshow">
 <div class="member_rank_title">
 <div class="rank_progress_bar">
 <span class="turn_pre"></span>
 <ul class="page_turn">
 <li class="turn_icon_on"></li><li></li></ul>
 <span class="turn_next"></span></div>
 <span class="titles">���Ѿ��ֲ�</span>
 </div>
 <div class="member_rank_group">
 		<!--[diy=xlmms7]--><div id="xlmms7" class="area"></div><!--[/diy]-->
</div></div>
</div>
  </div>

<div class="item media_item">
  <div class="member_rank_title">
            <span class="titles">ý��ר��</span>
            <a class="verify_link" target="_blank" href="/">������פ</a>

  </div>
 		<!--[diy=xlmmmt]--><div id="xlmmmt" class="area"></div><!--[/diy]-->
</div> 

<div class="item notices_item">
   <div class="member_rank_title">
     	<span class="titles">�����</span>
  </div>
 		<!--[diy=xlmmgg]--><div id="xlmmgg" class="area"></div><!--[/diy]-->
</div>

			<style>
.ssfires{position:fixed;top:-20px;_position:absolute!important;_top:expression(eval(document.documentElement.scrollTop)); overflow:hidden;  }

.topic_list {padding: 0 16px 10px;}
.topic_list .topic_item {padding: 5px 0;color: #666;cursor: pointer;}
.topic_list .topic_item .topic_flag_hot {background: #FF7F42;color: #FFF;padding: 1px 4px;margin-right: 7px;}
.topic_list .topic_item .topic_name {white-space: nowrap;text-overflow: ellipsis;-o-text-overflow: ellipsis;overflow: hidden;display: inline-block;width: 60%;vertical-align: middle;color: #666;}
.topic_list .topic_item .topic_num {color: #999;float: right;}
.topic_list .topic_item .topic_flag {display: inline-block;text-align: right;width: 14px;padding: 1px 4px;position: relative;right: 7px;}
	</style>
<div class="item platform_item" id="fss">
<div class="member_rank_title"><span class="titles">Ʒ�ƽ�פ</span><a href="/" target="_blank" class="verify_link">��ҵ��פ</a></div>
 		<!--[diy=xlmmpp]--><div id="xlmmpp" class="area"></div><!--[/diy]-->
</div>
<!--{hook/index_side_bottom}-->
</div></div></div></div><div class="bottom-bg">&nbsp; </div></div></div>

</div>
   			<div class="xlmmfooterh">
	<div class="wp">
	 		<!--{hook/index_middle}-->
		<!--{hook/index_bottom}-->
<!--[diy=xlmmyq]--><div id="xlmmyq" class="area"></div><!--[/diy]-->
	</div>
<div>
	<script src="template/mmtieba/image/js/forum.js" type="text/javascript"></script>
		<script type="text/javascript">
jQuery(".slideshow_container").slide({titCell:".top_progress_bar ul",mainCell:".ulists ul",autoPage:true,effect:"left",autoPlay:true,scroll:1,vis:1,easing:"easeOutCirc",delayTime:1000,autoPage:"<li><a></a></li>",interTime:5000,trigger:"click"});	

	<!--{if $_G['cache']['plugin']['xlmmtb']['xlmmtbbkyc'] }-->
		jQuery(".f-d-w").slide({ 
				type:"menu", //Ч������
				titCell:".mainCate", // ��괥������
				targetCell:".subCate", // Ч�����󣬱��뱻titCell����
				delayTime:0, // Ч��ʱ��
				triggerTime:0, //����ӳٴ���ʱ��
				defaultPlay:false,//Ĭ��ִ��
				returnDefault:true//����Ĭ��
			});
   <!--{/if}--> 
(function($) {$(function(){
  var numRun = $(".numbertz").numberAnimate({num:'$posts', speed:1500});
});
})(jQuery);
jQuery(".good_forum_list").slide({ mainCell:".gr_f_list", effect:"leftLoop",vis:4, autoPlay:true, interTime:3000,prevCell: ".good_rcmd_left", nextCell: ".good_rcmd_right" });

jQuery(".slide_inner_wrap").slide({titCell:"ul.game_nav",mainCell:".liveshow ul",autoPage:true,effect:"left",autoPlay:true,easing:"easeOutCirc",delayTime:1000,autoPage:"<li><a></a></li>",interTime:5000,titOnClassName:"turn_icon_cur",trigger:"click"});			

jQuery(".hdshow").slide({titCell:".rank_progress_bar ul",mainCell:".platact_outer ul",autoPage:true,effect:"fold",autoPlay:true,scroll:1,vis:1,easing:"easeOutCirc",delayTime:1000,prevCell: ".turn_pre", nextCell: ".turn_next" ,autoPage:"<li><a></a></li>",interTime:7000,titOnClassName:"turn_icon_on",trigger:"click"});			

								
jQuery(".hyshow").slide({titCell:".rank_progress_bar ul",mainCell:".member_rank_group ul",autoPage:true,effect:"fold",autoPlay:false,scroll:1,vis:1,easing:"easeOutCirc",delayTime:1000,prevCell: ".turn_pre", nextCell: ".turn_next" ,autoPage:"<li><a></a></li>",titOnClassName:"turn_icon_on",trigger:"click"});			
				
(function($){$(function () {

    var bartop = $('#fss').offset().top,
        h2_con=$('#fss').find("h2 a").text();
    function changeBar(){
        var st = $(window).scrollTop();
        if( st > bartop){
            $('#fss').addClass('ssfires');
        }else{
            $('#fss').removeClass('ssfires');
        }
    }
    $(window).scroll( function(){
        changeBar();
    })

})
})(jQuery)
</script>
	{if $_G['page_next'] >1}
<script type="text/javascript">

var ias = jQuery.ias({
   container: "#alist", 
        item: ".xlmmlists", 
        pagination: ".pg", 
        next: ".pg a.nxt", 
    });
    ias.extension(new IASTriggerExtension({
        text: '<div class="ias-spinner" style="text-align: center;line-height:40px;color: #999;">������ظ���</div>', 
        offset: false, 
    }));
    ias.extension(new IASSpinnerExtension({
	html: '<div class="ias-spinner" style="text-align: center;line-height:40px;color: #999;"><img src="static/image/common/loading.gif" width="16" height="16" class="vm" /> ������...</div>',
}));
    ias.extension(new IASNoneLeftExtension({
        text: '<div style=" text-align:center; line-height:40px;color: #999;">û�и�����</div>', 
    }));
</script>
 {/if}    
											<!--{else}-->
	 <script src="template/mmtieba/image/js/superslide.js" type="text/javascript"></script>
<link rel="stylesheet" href="$_G['style']['styleimgdir']/tb2.css" />
<div class="xlmmc clearfix"><div class="left-sec xlmmb"><div class="f_class_title">ȫ�����ɷ���</div>
<div class="f_class_list_wrap fgid">
<div class="f_class_list">
<ul class="f_class_menu">
										<!--{hook/index_favforum_extra $forum[fid]}-->
									<!--{eval $k = 1;}-->
	  <!--{eval $temp = $dpost = array();$on=0;$query = DB::query("SELECT fid,fup,type,name,todayposts,domain FROM ".DB::table('forum_forum')." WHERE status='1' ORDER BY displayorder;");while($data = DB::fetch($query)) $temp[]=$data;}-->
				  <!--{loop $temp $xlmm_gid}-->
				  <!--{if $xlmm_gid['type']=="group"}-->
				  <!--{eval $on++;}-->
						  <!--{eval $forumurl = !empty($xlmm_gid['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$xlmm_gid['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?gid='.$xlmm_gid['fid'];}-->
<div class="mainCate">
<li class="f_class_li first_li"><a href="{$forumurl}" target="_blank" class="fic$k">{$xlmm_gid['name']}</a></li> 
	<div class="subCate " style=" margin-left:208px; margin-top:-41px; position:absolute; width:666px; height:auto;">
<div class="directory-pop-frame"><div class="d-title "><a href="{$forumurl}" target="_blank" title="{$xlmm_gid['name']}" >{$xlmm_gid['name']}</a></div>
<div class="item-wraper">
						  <!--{loop $temp $xlmm_fnav}-->
						  <!--{if $xlmm_fnav['fup']==$xlmm_gid['fid'] and $xlmm_fnav['type']=="forum"}-->
						  <!--{eval $forumurl = !empty($xlmm_fnav['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$xlmm_fnav['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$xlmm_fnav['fid'];}-->
<a href="{$forumurl}" target="_blank" class="d-item">{$xlmm_fnav['name']}</a><span class="d-gap"></span>
						  <!--{/if}-->
						  <!--{/loop}-->

                </div>
<div class="clear"></div>
<div class="rec-forum">
<div class="rec-icon">ȫ�����</div>
				  <!--{loop $temp $xlmm_gid}-->
				  <!--{if $xlmm_gid['type']=="group"}-->
				  <!--{eval $on++;}-->
						  <!--{loop $temp $xlmm_fnav}-->
						  <!--{if $xlmm_fnav['fup']==$xlmm_gid['fid'] and $xlmm_fnav['type']=="forum"}-->
<a href="{$forumurl}" target="_blank" class="notabs">{$xlmm_fnav['name']}</a>
						  <!--{/if}-->
						  <!--{/loop}-->
 <!--{/if}--><!--{/loop}-->

</div></div></div>						</div>

									<!--{eval $k ++;}-->
						  <!--{/if}-->
						  <!--{/loop}-->
 </ul>
 <a href="$_G['cache']['plugin']['xlmmtb']['xlmmtbckqb']" class="see_all_class" target="_blank">�鿴ȫ������</a>
 </div></div></div>

<div class="right-sec">
<div class="ba_class_title"><a href="./" title="{lang homepage}">��ҳ</a>&rsaquo;<a href="forum.php">{$_G[setting][navs][2][navname]}</a>$navigation</div>
	 <div class="ba_list clearfix" style="margin-left:-14px;*margin-left:-28px; margin-top:-20px; margin-bottom:10px">        
<!--{eval $gidiconnum = 0;}-->
<!--{loop $catlist $key $cat}-->
<!--{eval $gidiconnum ++;}-->  
<!--{eval $i++;}-->
  <!--{eval $fidnum = 0;}-->
									<!--{eval $kb = 1;}-->
	<!--{loop $cat[forums] $forumid}-->
<!--{eval $forum=$forumlist[$forumid];}-->
<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
<!--{eval $forumfid = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : ''.$forum['fid'];}-->
<!--{eval $fidnum ++;}-->
 <div class="ba_info" style="margin-left:14px"><em class="ba_href clearfix"> <!--{if $forum[icon]}-->$forum[icon]<!--{else}--><a href="$forumurl" target="_blank"><img src="$_G['style']['styleimgdir']/0{$kb}.png" alt="$forum[name]" /></a><!--{/if}--><div class="ba_content"><p class="ba_name"><a href="$forumurl" target="_blank"{if $forum[extra][namecolor]} style="color:{$forum[extra][namecolor]};"{/if} title="$forum[name]">$forum[name]</a></p><p class="ba_num clearfix"><span class="ba_m_num" title="{lang forum_threads}"><!--{echo dnumber($forum[threads])}--></span><span class="ba_p_num" title="{lang forum_posts}"><!--{echo dnumber($forum[posts])}--></span></p><p class="ba_desc"><!--{if $forum[description]}-->�����飺$forum[description]<!--{else}-->��û�����Ӱ����Ŷ��<!--{/if}--></p></div></em>
	 <div class="ba_post "><!--{if $forum['lastpost']['author']}-->
<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" title="<!--{echo cutstr($forum[lastpost][subject],60)}-->" target="_blank" ><!--{echo cutstr($forum[lastpost][subject], 40)}--></a><a style="text-decoration:none;">������ۣ�$forum[lastpost][dateline] $forum['lastpost']['author']</a>									<!--{hook/index_forum_extra $forum[fid]}-->
<!--{else}--><a href="forum.php?mod=post&action=newthread&fid=$forumfid" target="_blank">��������,���ȷ�����</a><!--{/if}--></div>            
	<!--{eval $like=DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$forumfid."");}--> 
	{if $like[id]}<a href="home.php?mod=space&do=favorite&type=forum" class="ba_like is_like" target="_blank" title="���ղ�"></a>{else}<a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$forumfid&handlekey=favoriteforum&formhash={FORMHASH}" class="ba_like" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" title="���ղ�"></a>{/if}           
	 <p class="ba_tag"></p></div>    
									<!--{eval $kb >= 9 ? $kb = 1 : $kb++;}-->
									<!--{hook/index_datacollection_extra $colletion[ctid]}-->
	<!--{/loop}-->
<!--{/loop}-->
</div>    
</div>    
</div>    
<div class="bottom-bg">&nbsp; </div>
</div>    
<div style="margin-bottom:10px"></div>
		<script type="text/javascript">
		jQuery(".fgid").slide({ 
				type:"menu", //Ч������
				titCell:".mainCate", // ��괥������
				targetCell:".subCate", // Ч�����󣬱��뱻titCell����
				delayTime:0, // Ч��ʱ��
				triggerTime:0, //����ӳٴ���ʱ��
				defaultPlay:false,//Ĭ��ִ��
				returnDefault:true//����Ĭ��
			});
</script>
			<style>
.xlmm_fixed {position: relative !important;
}	</style>
	<!--{/if}-->

<!--{subtemplate common/footer}-->

