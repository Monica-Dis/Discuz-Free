<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $_G['forum']['ismoderator']}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->
<style id="diy_style" type="text/css"></style>
<!--{ad/text/wp a_t}-->
</div>
<div id="xlmmbg">
<div class="wp">
<!--[diy=bg]--><div id="bg" class="area"></div><!--[/diy]-->
<div class="contents" style="border:0"><div class="forum_header">    
<div class="plat_head plat_head_theme1">    
<div class="plat_banner j_platform_banner"><img class="plat_head_bg" src="<!--{if $_G[forum][banner] && !$subforumonly}-->$_G[forum][banner]<!--{else}-->template/mmtieba/image/banner.jpg<!--{/if}-->" alt="$_G['forum'][name]" width="998" style=" min-height:180px;"></div>
<div class="plat_header clearfix">           
<div class="z"><div class="plat_card_top"><a class="j_plat_picbox plat_picbox z" href="forum.php?mod=forumdisplay&fid=$_G[fid]" target="_self" alt="$_G['forum'][name]"><img src="<!--{if $_G[forum][icon]}-->data/attachment/common/$_G['forum']['icon']<!--{else}-->template/mmtieba/image/bimg.png<!--{/if}-->" height="150" width="150" alt="$_G['forum'][name]"></a><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="plat_title_h3 z" target="_self">$_G['forum'][name]</a><!--{hook/forumdisplay_postbutton_top}-->
<!--{if rssforumperm($_G['forum']) && $_G[setting][rssstatus] && !$_GET['archiveid'] && !$subforumonly}--><a class="plat_info_iconblue z"  href="forum.php?mod=rss&fid=$_G[fid]&auth=$rssauth" target="_blank" alt="����"><img src="static/image/common/feed.gif" title="����" width="18" height="18"></a><!--{/if}-->
                <!--{eval $xlmmlk=DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$_G[fid]."");}--> 
<!--{if $xlmmlk[id]}--><a href="home.php?mod=space&do=favorite&type=forum" class="newfocus_btn cancel_newfocus z"></a><!--{else}--><a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" class="newfocus_btn islike_newfocus z" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);"></a><!--{/if}-->                
<div class="plat_use_total">                
<span class="post_title" style="margin-left:20px;">��ע��</span><span class="j_post_num plat_post_num">{$_G['forum']['favtimes']}</span><span class="post_title">���ӣ�</span><span class="j_post_num plat_post_num">$_G[forum][threads]</span>
<!--{if !$subforumonly}--><span class="post_title"><!--{if $_G[forum][rank]}-->{lang rank}: <strong class="xi1" title="{lang previous_rank}:$_G[forum][oldrank]">$_G[forum][rank]</strong><!--{if $_G[forum][rank] <= $_G[forum][oldrank]}--><b class="ico_increase">&nbsp;</b><!--{else}--><b class="ico_fall">&nbsp;</b><!--{/if}--><!--{/if}--></span></div></div><!--{/if}-->
<div class="clear"></div>
<ul class="xlmmml"><li><!--{if $_G['forum']['description']}--><div style="font-size:14px; margin-right:20px;color: #4c4c4c;height:18px; max-width:310px; overflow:hidden; float:left">$_G['forum'][description]</div><!--{/if}--><span style="font-size:14px;color: #AAA;">Ŀ¼��<a href="forum.php?{if !$subforumonly}mod=forumdisplay&fid{else}gid{/if}=$_G['cache']['forums'][$_G['forum']['fup']]['fid']" target="_blank" style="font-size:14px; color:#2d64b3;"><!--{eval echo cutstr($_G['cache']['forums'][$_G['forum']['fup']]['name'], 18, '')}--></a></span>
						<!--{hook/forumdisplay_forumaction}-->
<!--{if $_G['forum']['ismoderator']}-->
						<!--{if $_G['forum']['recyclebin']}-->
							<span class="pipe">|</span><a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" class="fa_bin" target="_blank">{lang forum_recyclebin}</a>
						<!--{/if}-->
						<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->
							<span class="pipe">|</span><strong>
							<!--{if $_G['forum']['status'] != 3}-->
								<a href="forum.php?mod=modcp&fid=$_G[fid]">{lang modcp}</a>
							<!--{else}-->
								<a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang modcp}</a>
							<!--{/if}-->
							</strong>
						<!--{/if}-->
						<!--{hook/forumdisplay_modlink}-->
						<!--{/if}-->	</li></ul></div>
<!--{if $_G['setting']['disfixednv_forumdisplay'] }-->
{if $_G['cache']['plugin']['dsu_paulsign']['ifopen']}
<!--{template common/qiandao}-->
{/if}
<!--{/if}-->      
 </div></div>    </div></div>    
		<!--[diy=vi1]--><div id="vi1" class="area"></div><!--[/diy]-->
<div class="star_nav_wrap star_nav_wrap_platform ">
<ul class="star_class_nav clearfix">
<!--{if !empty($_G['forum']['picstyle'])}-->
<li id="" class="star_nav_tab{if !empty($_G['cookie']['forumdefstyle'])}  newfocus{/if}"{if $filter==digest || $_GET[specialtype]==poll || $_GET[specialtype]==activity || $_GET[specialtype]==reward || $_GET[specialtype]==trade || $_GET[specialtype]==poll || $_GET[specialtype]==debate || $_GET[orderby]==heats}  style=" background:none;"{/if}><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="star_nav_ico kantie" hidefocus="true"><i class="icon"></i>����</a></div></div></li>
<li class="star_nav_tab{if empty($_G['cookie']['forumdefstyle'])} newfocus{/if}"{if $filter==digest || $_GET[specialtype]==poll || $_GET[specialtype]==activity || $_GET[specialtype]==reward || $_GET[specialtype]==trade || $_GET[specialtype]==poll || $_GET[specialtype]==debate || $_GET[orderby]==heats}  style=" background:none;"{/if}><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="star_nav_ico tupian" target="_blank" hidefocus="true"><i class="icon"></i>ͼƬ</a></div></div></li>
<!--{else}--><li id="filter_special" class="star_nav_tab{if $filter==digest || $_GET[specialtype]==poll || $_GET[specialtype]==activity || $_GET[specialtype]==reward || $_GET[specialtype]==trade || $_GET[specialtype]==poll || $_GET[specialtype]==debate || $_GET[orderby]==heats}{else} newfocus{/if}" onmouseover="showMenu(this.id)"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="star_nav_ico kantie"><i class="icon"></i>����</a></div></div></li><!--{/if}-->
<li class="star_nav_tab{if $filter==digest} newfocus{/if} "><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1" class="star_nav_ico jingpin" target="_blank"><i class="icon"></i>��Ʒ</a></div></div></li>
<!--{if $showactivity}--><li class="star_nav_tab{if $_GET[specialtype]==activity} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity" class="star_nav_ico huodon" target="_blank"><i class="icon"></i>�</a></div></div></li><!--{/if}-->
<!--{if $showreward}--><li class="star_nav_tab{if $_GET[specialtype]==reward} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward" class="star_nav_ico xuanshang" target="_blank"><i class="icon"></i>����</a></div></div></li><!--{/if}-->
<!--{if $showtrade}--><li class="star_nav_tab{if $_GET[specialtype]==trade} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade" class="star_nav_ico shangpin" target="_blank"><i class="icon"></i>��Ʒ</a></div></div></li><!--{/if}-->
<!--{if $showpoll}--><li class="star_nav_tab{if $_GET[specialtype]==poll} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll" class="star_nav_ico toupiao" target="_blank"><i class="icon"></i>ͶƱ</a></div></div></li><!--{/if}-->
<!--{if $showdebate}--><li class="star_nav_tab{if $_GET[specialtype]==debate} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate" class="star_nav_ico bianlun" target="_blank"><i class="icon"></i>����</a></div></div></li><!--{/if}-->
                        </ul>         
						<div class="search_internal_wrap"><form id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
												<input type="hidden" name="mod" id="mod" value="curforum" />
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="hidden" name="srchtype" value="title" />
						<input type="hidden" name="srhfid" value="$_G[fid]" />
						<input type="hidden" name="srhlocality" value="$_G['basescript']::{CURMODULE}" />
<input name="srchtxt" type="text" id="keyword" class="search_internal_input"   placeholder="��������"><input class="search_internal_btn" type="submit"></form></div>                        
						</div></div>

		<!--{if $leftside}-->
		<div class="wp" style="position:relative;">
			<div id="sd_bdl" class="bdl" onmouseover="showMenu({'ctrlid':this.id, 'pos':'dz'});" style="position: absolute;width:{$_G['setting']['leftsidewidth']}px;margin-left:-{$_G['leftsidewidth_mwidth']}px">
				<!--{hook/forumdisplay_leftside_top}-->
				<!--[diy=diyleftsidetop]--><div id="diyleftsidetop" class="area"></div><!--[/diy]-->

				<div class="tbn" id="forumleftside" style="width:{$_G['setting']['leftsidewidth']}px;">
					<!--{subtemplate forum/forumdisplay_leftside}-->
				</div>

				<!--[diy=diyleftsidebottom]--><div id="diyleftsidebottom" class="area"></div><!--[/diy]-->
				<!--{hook/forumdisplay_leftside_bottom}-->
			</div>
</div>
		<!--{/if}-->

	     <div class="wp">
<div class="boardnav boardnavs">
	<div id="ct" class="wp cl ct2">
		<div class="mn">

			<!--{hook/forumdisplay_top}-->
<!--{if !IS_ROBOT}-->
	<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
		<style>
		.ztflp_pop{
	font: 12px/18px Arial;
	background: #F5F7FA;
	border-bottom: 1px solid #e4e6eb;
	padding: 0 0 0 10px; margin-bottom:5px;
}
.ttp a, .ttp strong {
	border: none;
	background: none;
}
.ttp .a a {
	border-color: none;
	background: none;
	color: #000;
}

		</style>
	<div  class="ztflp_pop" change="location.href='forum.php?mod=forumdisplay&fid=$_G[fid]&filter='+$('filter_special').value">
					<ul id="thread_types" class="ttp bm cl" style="width:990px;">
						<!--{hook/forumdisplay_threadtype_inner}-->
										<li id="ttp_all" {if !$_GET['typeid'] && !$_GET['sortid']}class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a></li>
		<!--{if $_G['forum']['threadtypes']}-->
							<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
								<!--{if $_GET['typeid'] == $id}-->
								<li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><!--{/if}--></a></li>
								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"><!--{if $_G[forum][threadtypes][icons][$id] && $_G['forum']['threadtypes']['prefix'] == 2}--><img class="vm" src="$_G[forum][threadtypes][icons][$id]" alt="" /> <!--{/if}-->$name<!--{if $showthreadclasscount[typeid][$id]}--><!--{/if}--></a></li>
								<!--{/if}-->
							<!--{/loop}-->
						<!--{/if}-->

						<!--{if $_G['forum']['threadsorts']}-->
							<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
								<!--{if $_GET['sortid'] == $id}-->
								<li class="xw1 a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><span class="xg1 num">$showthreadclasscount[sortid][$id]</span><!--{/if}--></a></li>
								<!--{else}-->
								<li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[sortid][$id]}--><!--{/if}--></a></li>
								<!--{/if}-->
							<!--{/loop}-->
						<!--{/if}-->
						<!--{hook/forumdisplay_filter_extra}-->
					</ul>
					<script type="text/javascript">showTypes('thread_types');</script>
	</div>
				<!--{/if}-->

<!--{/if}-->

			<div class="drag">
				<!--[diy=diy4]--><div id="diy4" class="area"></div><!--[/diy]-->
			</div>

			<!--{if !empty($_G['forum']['recommendlist'])}-->
				<div class="bm bmw">
					<div class="bm_h cl">
						<h2>{lang forum_recommend}</h2>
					</div>
					<div class="bm_c cl">
						<!--{subtemplate forum/recommend}-->
					</div>
				</div>
			<!--{/if}-->

			<!--{hook/forumdisplay_middle}-->

			<!--{if !$subforumonly}-->

				<!--{if $recommendgroups && !$_G['forum']['allowside']}-->
				<div class="bm bmw fl{if $_G['forum']['forumcolumns']} flg{/if}">
					<div class="bm_h cl">
						<span class="o"><img id="recommendgroups_{$_G[forum][fid]}_img" src="{IMGDIR}/$collapseimg[recommendgroups]" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('recommendgroups_{$_G[forum][fid]}');" /></span>
						<h2>{lang recommended_groups}</h2>
					</div>
					<div class="bm_c" id="recommendgroups_{$_G[forum][fid]}" style="$collapse[recommendgroups]">
						<table cellspacing="0" cellpadding="0" class="fl_tb">
							<!--{loop $recommendgroups $key $group}-->
							<!--{if $_G['forum']['forumcolumns']}-->
								<!--{if $key && ($key % $_G['forum']['forumcolumns'] == 0)}-->
									</tr>
									<!--{if $key < $_G['forum']['forumcolumns']}-->
										<tr class="fl_row">
									<!--{/if}-->
								<!--{/if}-->
								<td class="fl_g">
									<div class="fl_icn_g">
										<a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]" target="_blank"><img src="$group[icon]" alt="$group[name]" width="32" /></a>
									</div>
									<dl>
										<dt><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><span class="xg1 xw0"> ($group[membernum] {lang activity_member_unit})</span>
										<dd><em>{lang forum_threads}: $group[threads]</em></dd>
										<dd>
											<!--{if is_array($group['lastpost'])}-->
												<!--{if $_G['forum']['forumcolumns'] < 3}-->
												<a href="forum.php?mod=redirect&tid=$group[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($group[lastpost][subject], 30)}--></a> <cite>$group[lastpost][dateline] <!--{if $group['lastpost']['author']}--><a href="home.php?mod=space&username={$group[lastpost][encode_author]}">{$group[lastpost][author]}</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>
												<!--{else}-->
													<a href="forum.php?mod=redirect&tid=$group[lastpost][tid]&goto=lastpost#lastpost" class="xi2">$group[lastpost][dateline]</a>
												<!--{/if}-->				<!--{else}-->
											{lang never}
											<!--{/if}-->
										</dd>
									</dl>
								</td>
							<!--{else}-->
								<tr {if $key != 0}class="fl_row"{/if}>
									<td class="fl_icn">
										<a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]" target="_blank"><img src="$group[icon]" alt="$group[name]" width="32" /></a>
									</td>
									<td>
										<h2><a href="forum.php?mod=group&fid=$group[fid]" target="_blank">$group[name]</a><span class="xg1 xw0"> ($group[membernum] {lang activity_member_unit})</span></h2>
										<p><!--{echo cutstr($group[description], 100)}--></p>
									</td>
									<td class="fl_i">
										<span class="xi2">$group[threads] {lang index_threads}</span>
									</td>
									<td class="fl_by">
										<div>
											<!--{if is_array($group['lastpost'])}-->
											<a href="forum.php?mod=redirect&tid=$group[lastpost][tid]&goto=lastpost#lastpost" class="xi2"><!--{echo cutstr($group[lastpost][subject], 30)}--></a> <cite>$group[lastpost][dateline] <!--{if $group['lastpost']['author']}--><a href="home.php?mod=space&username={$group[lastpost][encode_author]}">{$group[lastpost][author]}</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}--></cite>
											<!--{else}-->
											{lang never}
											<!--{/if}-->
										</div>
									</td>
								</tr>
							<!--{/if}-->
							<!--{/loop}-->
						</table>
					</div>
				</div>
				<!--{/if}-->

				<!--{if $threadmodcount}--><div class="bm"><div class="ntc_l hm xi2"><strong>{lang forum_moderate_unhandled}</strong></div></div><!--{/if}-->
	<style type="text/css">
.listUser a {
    padding-left: 20px; margin-right:10px;
    background: url(template/mmtieba/image/icon_author.png) 0 0 no-repeat;
    color: #999;
}
</style>
			            <!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}--><!--{if $livethread}-->
					<div id="livethread" class="tl bm bmw cl" style="padding:10px 10px 10px 75px; position:relative; background:#FFFFFF">
                        <div class="live_reply">$livethread[replies]</div>
                        
						<div class="livethreadtitle vm">
							<span class="replynumber xg1" style="display:none;">{lang reply} <span id="livereplies" class="xi1">$livethread[replies]</span></span>
				 <img src="$_G['style']['styleimgdir']/live.gif" style="margin-right:8px;" /><a href="forum.php?mod=viewthread&tid=$livethread[tid]" target="_blank">$livethread[subject]</a>
		<span class="listUser y">
				<a href="home.php?mod=space&uid=$livethread[authorid]" c="1" target="_blank">$livethread[author]</a>
				                    </span>
						</div>
						<div class="livethreadcon">$livemessage</div>
						<div id="livereplycontentout">
							<div id="livereplycontent">
							</div>
						</div>
						<div id="liverefresh">{lang forum_live_newreply_refresh}</div>
						<div id="livefastreply">
							<form id="livereplypostform" method="post" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$livethread[tid]&replysubmit=yes&infloat=yes&handlekey=livereplypost&inajax=1" onsubmit="return livereplypostvalidate(this)">
								<div id="livefastcomment">
									<textarea id="livereplymessage" name="message" style="color:gray;<!--{if !$liveallowpostreply}-->display:none;<!--{/if}-->">{lang forum_live_fastreply_notice}</textarea>
									<!--{if !$liveallowpostreply}-->
										<div>
											<!--{if !$_G[uid]}-->
												{lang login_to_reply} <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)" class="xi2">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}" class="xi2">$_G['setting']['reglinkname']</a>
											<!--{else}-->
												{lang no_permission_to_post}<a href="javascript:;" onclick="ajaxpost('livereplypostform', 'livereplypostreturn', 'livereplypostreturn', 'onerror', $('livereplysubmit'));" class="xi2">{lang click_to_show_reason}</a>
											<!--{/if}-->
										</div>
									<!--{/if}-->
								</div>
								<div id="livepostsubmit" style="display:none;">
								<!--{if $secqaacheck || $seccodecheck}-->
									<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id)"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
									<div class="mtm sec" style="text-align:right;"><!--{subtemplate common/seccheck}--></div>
								<!--{/if}-->
								<p class="ptm pnpost" style="margin-bottom:10px;">
								<button type="submit" name="replysubmit" class="pn pnc vm" style="float:right;" value="replysubmit" id="livereplysubmit">
									<strong>{lang forum_live_post}</strong>
								</button>
								</p>
								</div>
								<input type="hidden" name="formhash" value="{FORMHASH}">
								<input type="hidden" name="subject" value="  ">
							</form>
						</div>
						<span id="livereplypostreturn"></span>
					</div>
					<script type="text/javascript">
						var postminchars = parseInt('$_G['setting']['minpostsize']');
						var postmaxchars = parseInt('$_G['setting']['maxpostsize']');
						var disablepostctrl = parseInt('{$_G['group']['disablepostctrl']}');
						var replycontentlist = new Array();
						var addreplylist = new Array();
						var timeoutid = timeid = movescrollid = waitescrollid = null;
						var replycontentnum = 0;
						getnewlivepostlist(1);
						timeid = setInterval(getnewlivepostlist, 5000);
						$('livereplycontent').style.position = 'absolute';
						$('livereplycontent').style.width = ($('livereplycontentout').clientWidth - 50) + 'px';
						$('livereplymessage').onfocus = function() {
							if(this.style.color == 'gray') {
								this.value = '';
								this.style.color = 'black';
								$('livepostsubmit').style.display = 'block';
								this.style.height = '56px';
								$('livefastcomment').style.height = '57px';
							}
						};
						$('livereplymessage').onblur = function() {
							if(this.value == '') {
								this.style.color = 'gray';
								this.value = '{lang forum_live_fastreply_notice}';
							}
						};

						$('liverefresh').onclick = function() {
							$('livereplycontent').style.position = 'absolute';
							getnewlivepostlist();
							this.style.display = 'none';
						};

						$('livereplycontentout').onmouseover = function(e) {

							if($('livereplycontent').style.position == 'absolute' && $('livereplycontent').clientHeight > 215) {
								$('livereplycontent').style.position = 'static';
								this.scrollTop = this.scrollHeight;
							}

							if(this.scrollTop + this.clientHeight != this.scrollHeight) {
								clearInterval(timeid);
								clearTimeout(timeoutid);
								clearInterval(movescrollid);
								timeid = timeoutid = movescrollid = null;

								if(waitescrollid == null) {
									waitescrollid = setTimeout(function() {
										$('liverefresh').style.display = 'block';
									}, 60000 * 10);
								}
							} else {
								clearTimeout(waitescrollid);
								waitescrollid = null;
							}
						};

						$('livereplycontentout').onmouseout = function(e) {
							if(this.scrollTop + this.clientHeight == this.scrollHeight) {
								$('livereplycontent').style.position = 'absolute';
								clearInterval(timeid);
								timeid = setInterval(getnewlivepostlist, 10000);
							}
						};

						function getnewlivepostlist(first) {
							var x = new Ajax('JSON');
							x.getJSON('forum.php?mod=misc&action=livelastpost&fid=$livethread[fid]', function(s, x) {
								var count = s.data.count;
								$('livereplies').innerHTML = count;
								var newpostlist = s.data.list;
								for(i in newpostlist) {
									var postid = i;
									var postcontent = '';
									postcontent += newpostlist[i].authorid ? '<dt><a href="home.php?mod=space&uid=' + newpostlist[i].authorid + '" target="_blank">' + newpostlist[i].avatar + '</a></dt>' : '<dt></dt>';
									postcontent += newpostlist[i].authorid ? '<dd><a href="home.php?mod=space&uid=' + newpostlist[i].authorid + '" target="_blank">' + newpostlist[i].author + '</a></dd>' : '<dd>' + newpostlist[i].author + '</dd>';
									postcontent += '<dd>' + htmlspecialchars(newpostlist[i].message) + '</dd>';
									postcontent += '<dd class="dateline">' + newpostlist[i].dateline + '</dd>';
									if(replycontentlist[postid]) {
										$('livereply_' + postid).innerHTML = postcontent;
										continue;
									}
									addreplylist[postid] = '<dl id="livereply_' + postid + '">' + postcontent + '</dl>';
								}
								if(first) {
									for(i in addreplylist) {
										replycontentlist[i] = addreplylist[i];
										replycontentnum++;
										var div = document.createElement('div');
										div.innerHTML = addreplylist[i];
										$('livereplycontent').appendChild(div);
										delete addreplylist[i];
									}
								} else {
									livecontentfacemove();
								}
							});
						}

						function livecontentfacemove() {
							//note �Ӷ�����ȡ������
							var reply = '';
							for(i in addreplylist) {
								reply = replycontentlist[i] = addreplylist[i];
								replycontentnum++;
								delete addreplylist[i];
								break;
							}
							if(reply) {
								var div = document.createElement('div');
								div.innerHTML = reply;
								var oldclientHeight = $('livereplycontent').clientHeight;
								$('livereplycontent').appendChild(div);
								$('livereplycontentout').style.overflowY = 'hidden';
								$('livereplycontent').style.bottom = oldclientHeight - $('livereplycontent').clientHeight + 'px';

								if(replycontentnum > 20) {
									$('livereplycontent').removeChild($('livereplycontent').firstChild);
									for(i in replycontentlist) {
										delete replycontentlist[i];
										break;
									}
									replycontentnum--;
								}

								if(!movescrollid) {
									movescrollid = setInterval(function() {
										if(parseInt($('livereplycontent').style.bottom) < 0) {
											$('livereplycontent').style.bottom =
												((parseInt($('livereplycontent').style.bottom) + 5) > 0 ? 0 : (parseInt($('livereplycontent').style.bottom) + 5)) + 'px';
										} else {
											$('livereplycontentout').style.overflowY = 'auto';
											clearInterval(movescrollid);
											movescrollid = null;
											timeoutid = setTimeout(livecontentfacemove, 1000);
										}
									}, 100);
								}
							}
						}

						function livereplypostvalidate(theform) {
							var s;
							if(theform.message.value == '' || $('livereplymessage').style.color == 'gray') {
								s = '{lang forum_live_nocontent_error}';
							}
							if(!disablepostctrl && ((postminchars != 0 && mb_strlen(theform.message.value) < postminchars) || (postmaxchars != 0 && mb_strlen(theform.message.value) > postmaxchars))) {
								s = {lang forum_live_nolength_error};
							}
							if(s) {
								showError(s);
								doane();
								$('livereplysubmit').disabled = false;
								return false;
							}
							$('livereplysubmit').disabled = true;
							theform.message.value = theform.message.value.replace(/([^>=\]"'\/]|^)((((https?|ftp):\/\/)|www\.)([\w\-]+\.)*[\w\-\u4e00-\u9fa5]+\.([\.a-zA-Z0-9]+|\u4E2D\u56FD|\u7F51\u7EDC|\u516C\u53F8)((\?|\/|:)+[\w\.\/=\?%\-&~`@':+!]*)+\.(jpg|gif|png|bmp))/ig, '$1[img]$2[/img]');
							theform.message.value = parseurl(theform.message.value);
							ajaxpost('livereplypostform', 'livereplypostreturn', 'livereplypostreturn', 'onerror', $('livereplysubmit'));
							return false;
						}

						function succeedhandle_livereplypost(url, msg, param) {
							$('livereplymessage').value = '';
							$('livereplycontent').style.position = 'absolute';
							if(param['sechash']) {
								updatesecqaa(param['sechash']);
								updateseccode(param['sechash']);
							}
							getnewlivepostlist();
						}
					</script>
				<!--{/if}-->
			<!--{/if}-->

				<!--{hook/forumdisplay_threadtype_extra}-->
				<!--{if empty($_G['forum']['sortmode'])}-->
					<!--{subtemplate forum/forumdisplay_list}-->
				<!--{else}-->
					<!--{subtemplate forum/forumdisplay_sort}-->
				<!--{/if}-->
			<!--{/if}-->
			<!--[diy=diyfastposttop]--><div id="diyfastposttop" class="area"></div><!--[/diy]-->

			<!--{hook/forumdisplay_bottom}-->
			<!--[diy=diyforumdisplaybottom]--><div id="diyforumdisplaybottom" class="area"></div><!--[/diy]-->
		</div>

		<div id="side" class="side">
<!--{hook/forumdisplay_side_top}-->
<div id="celebrity" class="region_bright celebrity"><div class="region_header"><div class="region_op j_op"> </div>
<div class="region_title region_icon j_title"></div></div>
<div class="region_cnt"><div class="intro"><div class="col2-left"><a class="gift-wrapper" href="javascript:"><span class="gift"><img src="template/mmtieba/image/huiyuan.png"></span>��Ա����</a></div>
<div class="col2-right"><ul class="privilege-list">
<li><i class="icon icon-red-thread-title"></i>������Ϣ���</li>
<li><i class="icon icon-red-name"></i>������ɫ����</li>
<li><i class="icon icon-sign-exp"></i>ǩ�����⾭��ֵ</li>
</ul></div></div>
<div class="more-privilege-container"><div class="first-show-container"><a title="��������" href="javascript:;" id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} ><button class="purchase-member-btn">���Ϸ�������</button></a></div></div>
<p class="gray-text">��ο��������ȼ����鿴<a href="home.php?mod=spacecp&ac=credit&op=rule" class="celebrity-purchase-exp" target="_blank">[���ֹ���]</a></p> </div>
<div class="region_footer"></div></div>  

 <!--{if !empty($_G['uid'])}-->
             {eval getuserprofile('posts');}
 <div class="region_bright balv_mod">
 <div class="region_header"><div class="region_op j_op"> </div>
<div class="region_title region_icon j_title">��������</div></div>
<div class="region_cnt">                
<div class="media_horizontal clearfix "><a class="media_left" href="home.php?mod=space&uid=$_G[uid]" target="_blank"><i class="head_img"><!--{avatar($_G[uid],middle)}--></i></a>
<div class="media_right"> 
  <div class="text_overflow">
<a href="home.php?mod=space&uid=$_G[uid]" target="_blank" style=" display:block">{echo cutstr($_G[member][username],10)}</a>
</div>            
<i class="icon_money" title="���"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a" title="���"><!--{echo dnumber($_G['member']['extcredits2'])}--></a>
<p class="orange_text" title="����"><i class="icon_credits"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a">$_G[member][credits]</a></p>
<p><a href="home.php?mod=spacecp&ac=usergroup">[��Ա�ȼ�{$_G[group][stars]}]</a></p>
</div></div></div>
<div class="region_footer"></div></div>
<!--{/if}-->

<div class="offical_schedule_wrap region_bright star_platform_aside_module">
<div class="trip_title"><h1 class="titles">�����</h1><span class="all_trip_link"><a href="/" target="_blank" class="j_all_trip_link">�鿴����&gt;&gt;</a></span></div>
				<!--[diy=r1]--><div id="r1" class="area"></div><!--[/diy]-->
</div>


<div id="encourage_entry" class="my_app encourage_entry region_bright " style="padding: 12px 10px 0 20px;">
<div class="my_app_title"><span class="region_title">�����Ȱ�</span><i class="encourage_entry_icon_new"></i></div>
				<!--[diy=r2]--><div id="r2" class="area"></div><!--[/diy]-->
</div>


<div class="region_bright related_forums"><div class="region_header">
<div class="region_title region_icon j_title">������صİ��</div></div>
<div class="region_cnt">
<div class="star_related">
						<!--{loop $_G['cache']['forums'] $bforum}-->
							<!--{if $bforum['fup'] == $_G['forum']['fup'] && $bforum['status']}-->
<a href="forum.php?mod=forumdisplay&fid=$bforum[fid]" target="_blank">$bforum['name']</a>
							<!--{/if}-->
						<!--{/loop}-->
</div> </div>
<div class="region_footer"></div></div>

<div class="region_bright related_forums"><div class="region_header"><div class="region_op j_op"><a target="_blank" href="<!--{$_G['cache']['plugin']['xlmmtb']['xlmmtbsqbz']}-->">�������&gt;&gt;</a></div>
<div class="region_title region_icon j_title">�������</div></div>
<div class="region_cnt">
<div class="star_related">
<!--{if $moderatedby}-->$moderatedby<!--{else}--><a href="<!--{$_G['cache']['plugin']['xlmmtb']['xlmmtbsqbz']}-->" target="_blank">��ʱ��û�а���Ŷ</a><!--{/if}-->
</div> </div>
<div class="region_footer"></div></div>
 <div id="zyq" class="zyq_bright"><div class="mod"><div class="tl"><div class="mod_edit_wrap"></div>
 <div class="zyq_mod_icon zyq_mod_title"><span class="j_mod_tit">��Ҫ����</span></div></div>
 <div class="cnt">
				<!--[diy=r3]--><div id="r3" class="area"></div><!--[/diy]-->
 </div>
 </div>


 <div class="mod"><div class="tl"><div class="mod_edit_wrap"></div><span class="zyq_mod_title">��Ա����</span></div>
				<!--[diy=r4]--><div id="r4" class="area"></div><!--[/diy]-->
 </div></div>
 
			<!--{if $subexists && $_G['page'] == 1}--><!--{template forum/forumdisplay_subforum}--><!--{/if}-->
			<div class="drag">
				<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
			</div>
			<!--{hook/forumdisplay_side_bottom}-->
	               <div id="fixeds"></div>
	</div>
	</div>
</div>
<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
	<ul class="p_pop" id="newspecial_menu" style="display: none">
		<!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
			<!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
				<!--{if $_G['forum']['threadsorts']['show'][$id]}-->
					<li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id">$threadsorts</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
			<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
	<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
		<!--{if $_G['setting']['threadplugins']}-->
			<!--{loop $_G['forum']['threadplugin'] $tpid}-->
				<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
					<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url(source/plugin/$tpid/$_G[setting][threadplugins][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>
<!--{/if}-->

<!--{if $_G['setting']['threadmaxpages'] > 1 && $page && !$subforumonly}-->
	<script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&{$multipage_archive}', $page);}</script>
<!--{/if}-->

<!--{if empty($_G['forum']['picstyle']) && $_GET['orderby'] == 'lastpost' && empty($_GET['filter']) }-->
	<script type="text/javascript">checkForumnew_handle = setTimeout(function () {checkForumnew($_G[fid], lasttime);}, checkForumtimeout);</script>
<!--{/if}-->
<div class="wp fastbg">
				<!--{template forum/forumdisplay_fastpost}-->
<div class="wp mtn">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
			<!--{if $fastpost}--><!--{else}-->
<!--{/if}-->
	<script type="text/javascript">var userfix = $('fixeds');
var userfixoffset = parseInt(fetchOffset(userfix)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop + 0 >= userfixoffset){
if (BROWSER.ie && BROWSER.ie < 7) {
userfix.style.position = 'absolute';
userfix.style.top = xlmmm_scrollTop + 'px';
}else{
userfix.innerHTML  = '<style>.topic_list_box{ position:fixed; top:0px; width:230px;z-index:1;background: #fff;}</style>';
}
}else{
userfix.innerHTML  = '<style>.topic_list_box{ position:static;}</style>';
}
});</script>
<!--{template common/footer}-->


