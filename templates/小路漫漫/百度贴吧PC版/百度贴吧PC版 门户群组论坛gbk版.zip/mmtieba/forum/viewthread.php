<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<script type="text/javascript">var fid = parseInt('$_G[fid]'), tid = parseInt('$_G[tid]');</script>
<!--{if $modmenu['thread'] || $modmenu['post']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->

<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';var aimgcount = new Array();</script>

<style id="diy_style" type="text/css"></style>
</div>
<div id="xlmmbg">
<div class="wp">
<!--[diy=bg]--><div id="bg" class="area"></div><!--[/diy]-->
<div class="forum_header">    
<div class="plat_header clearfix">           
<div class="z"><div class="plat_card_top"><a class="j_plat_picbox plat_picbox z" href="forum.php?mod=forumdisplay&fid=$_G[fid]" target="_self" alt="$_G['forum'][name]"><img src="<!--{if $_G[forum][icon]}-->data/attachment/{if $_G['basescript'] == 'group'}group{else}common{/if}/$_G['forum']['icon']<!--{else}-->{if $_G['basescript'] == 'forum'}template/mmtieba/image/bimg.png{else}static/image/common/groupicon.gif{/if}<!--{/if}-->" height="48" width="48" alt="$_G['forum'][name]"></a><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="plat_title_h3 z" target="_self">$_G['forum'][name]</a>
<!--{if rssforumperm($_G['forum']) && $_G[setting][rssstatus] && !$_GET['archiveid'] && !$subforumonly}--><a class="plat_info_iconblue z"  href="forum.php?mod=rss&fid=$_G[fid]&auth=$rssauth" target="_blank" alt="����"><img src="static/image/common/feed.gif" title="����" width="18" height="18"></a><!--{/if}-->
           	<!--{if $_G['basescript'] == 'forum' && CURMODULE == 'viewthread'  }--><!--{eval $xlmmlk=DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$_G[fid]."");}--> 
<!--{if $xlmmlk[id]}--><a href="home.php?mod=space&do=favorite&type=forum" class="newfocus_btn cancel_newfocus z"></a><!--{else}--><a href="home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}" class="newfocus_btn islike_newfocus z" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);"></a><!--{/if}-->
<!--{else}-->
<!--{eval $xlmmjia =DB::fetch_all("SELECT uid FROM ".DB::table('forum_groupuser')." WHERE fid=$_G[fid] AND uid=$_G[uid]");}-->
{if $xlmmjia[0] }<a onclick="showDialog('��ȷ��Ҫ�˳���Ⱥ����', 'confirm', '', function(){location.href='forum.php?mod=group&action=out&fid=$_G[fid]'})"  class="newfocus_btn cancel_newfocus z"></a>{else}<a href="javascript:;"href="forum.php?mod=group&amp;action=join&amp;fid=$_G[fid]" class="newfocus_btn islike_newfocus z"></a>{/if}
	<!--{/if}-->
<div class="plat_use_total">                
<span class="post_title" style="margin-left:20px;">��ע��</span><span class="j_post_num plat_post_num"> <!--{if $_G['basescript'] == 'forum' && CURMODULE == 'viewthread'  }-->{$_G['forum']['favtimes']}<!--{else}-->$_G[forum][membernum]<!--{/if}--></span><span class="post_title">���ӣ�</span><span class="j_post_num plat_post_num">$_G[forum][threads]</span>
<!--{if !$subforumonly}--><span class="post_title"><!--{if $_G[forum][rank]}-->{lang rank}: <strong class="xi1" title="{lang previous_rank}:$_G[forum][oldrank]">$_G[forum][rank]</strong><!--{if $_G[forum][rank] <= $_G[forum][oldrank]}--><b class="ico_increase">&nbsp;</b><!--{else}--><b class="ico_fall">&nbsp;</b><!--{/if}--><!--{/if}--></span></div></div><!--{/if}-->
</div>

<!--{if $_G['setting']['disfixednv_viewthread'] }-->
{if $_G['cache']['plugin']['dsu_paulsign']['ifopen']}
<!--{template common/qiandao}-->
{/if}
 <!--{/if}-->      
        </div></div>

<div class="star_nav_wrap star_nav_wrap_platform ">
<ul class="star_class_nav clearfix">
<li id="filter_special" class="star_nav_tab"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">����</a></div></div></li>
<li class="star_nav_tab"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1" target="_blank">��Ʒ</a></div></div></li>
                        </ul>         
						<div class="search_internal_wrap"><form id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
												<input type="hidden" name="mod" id="mod" value="forum" />
						<input type="hidden" name="formhash" value="{FORMHASH}" />
						<input type="hidden" name="srchtype" value="title" />
						<input type="hidden" name="srhfid" value="$_G[fid]" />
						<input type="hidden" name="srhlocality" value="$_G['basescript']::{CURMODULE}" />
<input name="srchtxt" type="text" id="keyword" class="search_internal_input"   placeholder="��������������"><input class="search_internal_btn" type="submit"></form></div>                        
						</div></div>

<!--{hook/viewthread_top}-->
<!--{ad/text/wp a_t}-->

<style type="text/css">
.xlmmlz { position:relative;}
.xlmmlz em { display:block; position:absolute; top:-10px; right:0px; width:36px; height:36px; text-indent:-9999px; overflow:hidden; background:url(template/mmtieba/image/lz.png) 0 0 no-repeat;}

</style>
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>

<div id="ct" class="wp cl">
	<div id="pgt" class="pgs cl pgstop" style="position:relative; z-index:9">
	<div class="z">$multipage<span class="z" style="margin-top:3px; margin-left:20px"><i style="color:#F60;">$_G[forum_thread][allreplies]</i>&nbsp;�ظ�����<i style="color:#F60;">$_G[forum_thread][views]</i>&nbsp;�β鿴</span></div>
<!--{if $modmenu['thread']}--><span class="y pgb" id="modmenu" onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'','pos':'34!'})"><a href="javascript:;">[�������]</a></span><!--{/if}-->
	<span class="y pgb"{if $_G['setting']['visitedforums']} id="visitedforums" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id,'pos':'34'})"{/if}><a href="$upnavlink"><{lang return_forumdisplay}</a></span>
		<!--{if $_G['forum']['threadsorts'] && $_G['forum']['threadsorts']['templatelist']}-->
			<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
				<button id="newspecial" class="pn pnc" onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]&extra=$extra&sortid=$id'"><strong>{lang i_want}$name</strong></button>
			<!--{/loop}-->
		<!--{else}-->
		<!--{/if}-->
		<!--{hook/viewthread_postbutton_top}-->
	</div>

<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
	<ul class="p_pop" id="newspecial_menu" style="display: none">
		<!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang post_newthread}</a></li><!--{/if}-->
		<!--{if $_G['forum']['threadsorts'] && !$_G['forum']['allowspecialonly']}-->
			<!--{loop $_G['forum']['threadsorts']['types'] $id $threadsorts}-->
				<!--{if $_G['forum']['threadsorts']['show'][$id]}-->
					<li class="popupmenu_option"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&sortid=$id">$threadsorts</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
		<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
		<!--{if $_G['setting']['threadplugins']}-->
			<!--{loop $_G['forum']['threadplugin'] $tpid}-->
				<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
					<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url(source/plugin/$tpid/$_G['setting']['threadplugins'][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G['setting']['threadplugins'][$tpid][name]}</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>
<!--{/if}-->

<!--{if $modmenu['post']}-->
	<div id="mdly" class="fwinmask" style="display:none;z-index:350;">
		<table cellspacing="0" cellpadding="0" class="fwin">
			<tr>
				<td class="t_l"></td>
				<td class="t_c"></td>
				<td class="t_r"></td>
			</tr>
			<tr>
				<td class="m_l">&nbsp;&nbsp;</td>
				<td class="m_c">
					<div class="f_c">
						<div class="c">
							<h3>{lang admin_select}&nbsp;<strong id="mdct" class="xi1"></strong>&nbsp;{lang piece}: </h3>
							<!--{if $_G['forum']['ismoderator']}-->
								<!--{if $_G['group']['allowwarnpost']}--><a href="javascript:;" onclick="modaction('warn')">{lang modmenu_warn}</a><span class="pipe">|</span><!--{/if}-->
								<!--{if $_G['group']['allowbanpost']}--><a href="javascript:;" onclick="modaction('banpost')">{lang modmenu_banpost}</a><span class="pipe">|</span><!--{/if}-->
								<!--{if $_G['group']['allowdelpost'] && !$rushreply}--><a href="javascript:;" onclick="modaction('delpost')">{lang modmenu_deletepost}</a><span class="pipe">|</span><!--{/if}-->
							<!--{/if}-->
							<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowstickreply'] || $_G['forum_thread']['authorid'] == $_G['uid']}--><a href="javascript:;" onclick="modaction('stickreply')">{lang modmenu_stickpost}</a><span class="pipe">|</span><!--{/if}-->
							<!--{if $_G['forum_thread']['pushedaid'] && $allowpostarticle}--><a href="javascript:;" onclick="modaction('pushplus', '', 'aid=$_G[forum_thread][pushedaid]', 'portal.php?mod=portalcp&ac=article&op=pushplus')">{lang modmenu_pushplus}</a><span class="pipe">|</span><!--{/if}-->
						</div>
					</div>
				</td>
				<td class="m_r"></td>
			</tr>
			<tr>
				<td class="b_l"></td>
				<td class="b_c"></td>
				<td class="b_r"></td>
			</tr>
		</table>
	</div>
<!--{/if}-->

<!--{if $modmenu['thread']}-->
	<div id="modmenu_menu"  class="t-more_menu p_pop" style="display:none; width:200px;">
		<!--{eval $modopt=0;}-->
		<!--{if $_G['forum']['ismoderator']}-->
			<!--{if $_G['group']['allowdelpost']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(3, 'delete')">{lang modmenu_deletethread}</a><!--{/if}-->
			<!--{if $_G['group']['allowbumpthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(3, 'bump')">{lang modmenu_updown}</a><!--{/if}-->
			<!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(1, 'stick')">{lang modmenu_stickthread}</a><!--{/if}-->
			<!--{if $_G['group']['allowlivethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('live')">{lang modmenu_live}</a><!--{/if}-->
			<!--{if $_G['group']['allowhighlightthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(1, 'highlight')">{lang modmenu_highlight}</a><!--{/if}-->
			<!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(1, 'digest')">{lang modmenu_digestpost}</a><!--{/if}-->
			<!--{if $_G['group']['allowrecommendthread'] && !empty($_G['forum']['modrecommend']['open']) && $_G['forum']['modrecommend']['sort'] != 1 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(1, 'recommend')">{lang modmenu_recommend}</a><!--{/if}-->
			<!--{if $_G['group']['allowstampthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('stamp')">{lang modmenu_stamp}</a><!--{/if}-->
			<!--{if $_G['group']['allowstamplist'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('stamplist')">{lang modmenu_icon}</a><!--{/if}-->
			<!--{if $_G['group']['allowclosethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(4)"><!--{if !$_G['forum_thread']['closed']}-->{lang modmenu_switch_off}<!--{else}-->{lang modmenu_switch_on}<!--{/if}--></a><!--{/if}-->
			<!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(2, 'move')">{lang modmenu_move}</a><!--{/if}-->
			<!--{if $_G['group']['allowedittypethread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modthreads(2, 'type')">{lang modmenu_type}</a><!--{/if}-->
			<!--{if !$_G['forum_thread']['special'] && !$_G['forum_thread']['is_archived']}-->
				<!--{if $_G['group']['allowcopythread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('copy')">{lang modmenu_copy}</a><!--{/if}-->
				<!--{if $_G['group']['allowmergethread'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('merge')">{lang modmenu_merge}</a><!--{/if}-->
				<!--{if $_G['group']['allowrefund'] && $_G['forum_thread']['price'] > 0}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('refund')">{lang modmenu_restore}</a><!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowsplitthread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('split')">{lang modmenu_split}</a><!--{/if}-->
			<!--{if $_G['group']['allowrepairthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('repair')">{lang modmenu_repair}</a><!--{/if}-->
			<!--{if $_G['forum_thread']['is_archived'] && $_G['adminid'] == 1}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('restore', '', 'archiveid={$_G[forum_thread][archiveid]}')">{lang modmenu_archive}</a><!--{/if}-->
			<!--{if $_G['forum_firstpid']}-->
				<!--{if $_G['group']['allowwarnpost']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('warn', '$_G[forum_firstpid]')">{lang modmenu_warn}</a><!--{/if}-->
				<!--{if $_G['group']['allowbanpost']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('banpost', '$_G[forum_firstpid]')">{lang modmenu_banthread}</a><!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowremovereward'] && $_G['forum_thread']['special'] == 3 && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}--><a href="javascript:;" onclick="modaction('removereward')">{lang modmenu_removereward}</a><!--{/if}-->
			<!--{if $_G['forum']['status'] == 3 && in_array($_G['adminid'], array('1','2')) && $_G['forum_thread']['closed'] < 1}--><a href="javascript:;" onclick="modthreads(5, 'recommend_group');return false;">{lang modmenu_grouprecommend}</a><!--{/if}-->
			<!--{if $_G['group']['allowmanagetag']}--><a href="javascript:;" onclick="showWindow('mods', 'forum.php?mod=tag&op=manage&tid=$_G[tid]', 'get', 0)">{lang post_tag}</a><!--{/if}-->
			<!--{if $_G['group']['alloweditusertag']}--><a href="javascript:;" onclick="showWindow('usertag', 'forum.php?mod=misc&action=usertag&tid=$_G[tid]', 'get', 0)">{lang usertag}</a><!--{/if}-->
		<!--{/if}-->
		<!--{if $allowpusharticle && $allowpostarticle}--><!--{eval $modopt++}--><a href="portal.php?mod=portalcp&ac=article&from_idtype=tid&from_id=$_G['tid']">{lang modmenu_pusharticle}</a><!--{/if}-->
		<!--{hook/viewthread_modoption}-->
	</div>
<!--{/if}-->

<!--{hook/viewthread_beginline}-->
<div class="boardnavs wp clearfix" style="overflow:inherit">
<div class="thread_left">
<div id="postlist" class="pl bm">
	<table cellspacing="0" cellpadding="0">
		<tr>
			<td class="plc vwthd coretit" id="fthread">
				<!--{if !IS_ROBOT}-->
					<div class="y">
			<span class="core_title_btns">        
					    <!--{if $post['invisible'] == 0}-->
					<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
                    	<!--{if $ordertype != 1}-->
                            <a href="forum.php?mod=viewthread&tid=$post[tid]&page=$page&authorid=$_G[forum_thread][authorid]"  class="btn-sub btn-small">ֻ��¥��</a>
						<!--{/if}-->
					<!--{elseif !$_G['forum_thread']['archiveid']}-->
						<a href="forum.php?mod=viewthread&tid=$post[tid]&page=$page"  class="btn-sub btn-small">ȡ��ֻ��¥��</a>
			    <!--{/if}-->
                <!--{/if}-->
			<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}" id="k_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" onmouseover="this.title = $('favoritenumber').innerHTML + ' {lang activity_member_unit}{lang thread_favorite}'" title="{lang fav_thread}" class="btn-sub btn-small">{lang thread_favorite}<span id="favoritenumber"{if !$_G['forum_thread']['favtimes']} style="display:none"{/if}>{$_G['forum_thread']['favtimes']}</span></a>
<a href="javascript:" {if !empty($_G['uid'])}onclick="location.href=location.href.replace(/(\#.*)/, '')+'#tieArea';$('fastpostmessage').focus();return false;"{else}onclick="showWindow('reply', 'forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]')"{/if}  class="btn-small btn-sub">�ظ�</a>    
			</span>	
					</div>
				<!--{/if}-->
				<!--{if $_G['setting']['close_leftinfo_userctrl']}-->
					<span class="z" style=" margin-left:-20px; margin-top:10px;">
					<!--{if !$close_leftinfo}-->
						<a onclick="setcookie('close_leftinfo', 1);location.reload();" title="{lang collapse_the_left}" class="btn_s_close" href="javascript:;"><img src="{IMGDIR}/control_l.png" alt="{lang collapse_the_left}" class="vm" /></a>
					<!--{else}-->
						<a onclick="setcookie('close_leftinfo', 2);location.reload();" title="{lang open_the_left}" class="btn_s_open" href="javascript:;"><img src="{IMGDIR}/control_r.png" alt="{lang open_the_left}" class="vm" /></a>
					<!--{/if}-->
					</span>
				<!--{/if}-->
			<h1 class="ts">
					<!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
						<!--{if !IS_ROBOT && ($_G['forum']['threadtypes']['listable'] || $_G['forum']['status'] == 3)}-->
							<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$_G[forum_thread][typeid]" style="color:#333;">[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]</a>
						<!--{else}-->
							[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
						<!--{/if}-->
					<!--{/if}-->
					<!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
						<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_G[forum_thread][sortid]" style="color:#333;">[{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]</a>
					<!--{/if}-->
					<span id="thread_subject">$_G[forum_thread][subject]</span>
				</h1>
				<!--{hook/viewthread_title_extra}-->
	</td>
		</tr>
	</table>
	<!--{if $_G['forum_thread']['replycredit'] > 0 || $rushreply}-->
	<div id="pl_top">
		<table cellspacing="0" cellpadding="0">
			<tr class="ad">
				<td class="pls"></td>
				<td class="plc"></td>
			</tr>
			<!--{if $_G['forum_thread']['replycredit'] > 0 }-->
				<tr>
					<!--{if !$close_leftinfo}-->
					<td class="pls vm ptm">
					<!--{else}-->
					<td class="pls ptm pbm xi1" colspan="2">
					<!--{/if}-->
						<img src="{IMGDIR}/thread_prize_s.png" class="hm" alt="{lang replycredit}" />
							<strong>{$_G['forum_thread']['replycredit']} {$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][unit]}{$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][title]}</strong>
					<!--{if !$close_leftinfo}-->
					</td>
					<td class="plc ptm pbm xi1">
					<!--{else}-->
					&nbsp;&nbsp;&nbsp;&nbsp;
					<!--{/if}-->
						{lang thread_replycredit_tips1} {lang thread_replycredit_tips2}<!--{if $_G['forum_thread']['replycredit_rule'][random] > 0}--><span class="xg1">{lang thread_replycredit_tips3}</span><!--{/if}-->
					</td>
				</tr>
				<!--{if $rushreply}-->
				<tr class="ad">
					<td class="pls"></td>
					<td class="plc"></td>
				</tr>
				<!--{/if}-->
		<!--{/if}-->

		<!--{if $rushreply}-->
			<tr>
				<!--{if !$close_leftinfo}-->
				<td class="pls vm ptm">
					<img src="{IMGDIR}/rushreply_s.png" class="vm" alt="{lang rushreply}" />
					<strong>{lang rushreply}</strong>
				</td>
				<td class="plc ptm pbm xi1">
				<!--{else}-->
				<td class="plc ptm pbm xi1" colspan="2">
					<img src="{IMGDIR}/rushreply_s.png" class="vm" alt="{lang rushreply}" />
				<!--{/if}-->
					<!--{if $rushresult[rewardfloor]}-->
						<span class="y">
						<!--{if $_G['uid'] == $_G['thread']['authorid'] || $_G['forum']['ismoderator']}--><a href="javascript:;" onclick="showWindow('membernum', 'forum.php?mod=ajax&action=get_rushreply_membernum&tid=$_G[tid]')" class="y pn xi2"><span>{lang thread_rushreply_statnum}</span></a><!--{/if}-->
						<!--{if !$_GET['checkrush']}-->
								<a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" class="y pn xi2"><span>{lang rushreply_view}</span></a>
						<!--{/if}-->
						</span>
					<!--{/if}-->
					<!--{if $rushresult[creditlimit] == ''}-->
						{lang thread_rushreply}&nbsp;
					<!--{else}-->
						{lang thread_rushreply_limit} &nbsp;
					<!--{/if}-->
					<!--{if $rushresult['timer']}-->
					<span id="rushtimer_$thread[tid]"> {lang havemore_special} <span id="rushtimer_body_$thread[tid]"></span> <script language="javascript">settimer($rushresult['timer'], 'rushtimer_body_$thread[tid]');</script>{if $rushresult['timertype'] == 'start'} {lang header_start} {else} {lang over} {/if} {lang right_special}</span>
					<!--{/if}-->
					<!--{if $rushresult[stopfloor]}-->
						{lang thread_rushreply_end}$rushresult[stopfloor]&nbsp;
					<!--{/if}-->
					<!--{if $rushresult[rewardfloor]}-->
						{lang thread_rushreply_floor}: $rushresult[rewardfloor]&nbsp;
					<!--{/if}-->
					<!--{if $rushresult[rewardfloor] && $_GET['checkrush']}-->
						<p class="ptn">
							<!--{if $countrushpost}-->[<strong>$countrushpost</strong>]{lang thread_rushreply_rewardnum}<!--{else}--> {lang thread_rushreply_noreward} <!--{/if}-->&nbsp;&nbsp;
							<a href="forum.php?mod=viewthread&tid=$_G[tid]" class="xi2">{lang thread_rushreply_check_back}</a>
						</p>
					<!--{/if}-->
				</td>
			</tr>
		<!--{/if}-->
		</table>
	</div>
	<!--{/if}-->

	<!--{hook/viewthread_title_row}-->

	<table cellspacing="0" cellpadding="0" class="ad">
		<tr>
			<td class="pls">
			<!--{if !$close_leftinfo}-->
			</td>
			<td class="plc">
			<!--{/if}-->
			</td>
		</tr>
	</table>
	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
		<!--{if $rushreply && $_GET['checkrush'] && $post['rewardfloor'] != 1}-->
			<!--{eval continue;}-->
		<!--{/if}-->
		<div id="post_$post[pid]" {if $_G['blockedpids'] && $post['inblacklist']}style="display:none;"{/if}>
			<!--{subtemplate forum/viewthread_node}-->
		</div>
		<!--{eval $postcount++;}-->
	<!--{/loop}-->
	<div id="postlistreply" class="pl"><div id="post_new" class="viewthread_table" style="display: none"></div></div>
	<!--{if $_G['blockedpids']}-->
		<div id='hiddenpoststip'><a href='javascript:display_blocked_post();'>{lang other_reply_hide}</a></div>
		<div id="hiddenposts"></div>
	<!--{/if}-->
</div>


<form method="post" autocomplete="off" name="modactions" id="modactions">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="optgroup" />
	<input type="hidden" name="operation" />
	<input type="hidden" name="listextra" value="$_GET[extra]" />
	<input type="hidden" name="page" value="$page" />
</form>

$_G['forum_tagscript']


<!--[diy=diyfastposttop]--><div id="diyfastposttop" class="area"></div><!--[/diy]-->
</div>
		<div id="side" class="side">
<div id="celebrity" class="region_bright celebrity"><div class="region_header"><div class="region_op j_op"> </div>
<div class="region_title region_icon j_title"></div></div>
<div class="region_cnt"><div class="intro"><div class="col2-left"><a class="gift-wrapper" href="javascript:;"><span class="gift"><img src="template/mmtieba/image/huiyuan.png"></span>��Ա����</a></div>
<div class="col2-right"><ul class="privilege-list">
<li><i class="icon icon-red-thread-title"></i>������Ϣ���</li>
<li><i class="icon icon-red-name"></i>������ɫ����</li>
<li><i class="icon icon-sign-exp"></i>ǩ�����⾭��ֵ</li>
</ul></div></div>
<div class="more-privilege-container"><div class="first-show-container"><a title="��������" href="javascript:" id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} ><button class="purchase-member-btn">���Ϸ�������</button></a></div></div>
<p class="gray-text">��ο��������ȼ����鿴<a href="home.php?mod=spacecp&ac=credit&op=rule" class="celebrity-purchase-exp" target="_blank">[���ֹ���]</a></p> </div>
<div class="region_footer"></div></div>  

 <!--{if !empty($_G['uid'])}-->
             {eval getuserprofile('posts');}
 <div class="region_bright balv_mod">
 <div class="region_header"><div class="region_op j_op"> </div>
<div class="region_title region_icon j_title">��������</div></div>
<div class="region_cnt">                
<div class="media_horizontal clearfix "><a class="media_left" href="home.php?mod=space&uid=$_G[uid]" target="_blank"><i class="head_img"><!--{avatar($_G[uid],middle)}--></i></a>
<div class="media_right"> 
  <div class="text_overflow">
<a href="home.php?mod=space&uid=$_G[uid]" target="_blank" style=" display:block">{echo cutstr($_G[member][username],10)}</a>
</div>            
<i class="icon_money" title="���"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a" title="���"><!--{echo dnumber($_G['member']['extcredits2'])}--></a>
<p class="orange_text" title="����"><i class="icon_credits"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a">$_G[member][credits]</a></p>
<p><a href="home.php?mod=spacecp&ac=usergroup">[��Ա�ȼ�{$_G[group][stars]}]</a></p>
</div></div></div>
<div class="region_footer"></div></div>
<!--{/if}-->

<div class="offical_schedule_wrap region_bright star_platform_aside_module">
<div class="trip_title"><h1 class="titles">�����</h1><span class="all_trip_link"><a href="/" target="_blank" class="j_all_trip_link">�鿴����&gt;&gt;</a></span></div>
				<!--[diy=r1]--><div id="r1" class="area"></div><!--[/diy]-->
</div>


<div id="encourage_entry" class="my_app encourage_entry region_bright " style="padding: 12px 10px 0 20px;">
<div class="my_app_title"><span class="region_title">�����Ȱ�</span><i class="encourage_entry_icon_new"></i></div>
				<!--[diy=r2]--><div id="r2" class="area"></div><!--[/diy]-->
</div>

{if $_G['basescript'] == 'forum'}
<div class="region_bright related_forums"><div class="region_header">
<div class="region_title region_icon j_title">��ذ��</div></div>
<div class="region_cnt">
<div class="star_related">
						<!--{loop $_G['cache']['forums'] $bforum}-->
							<!--{if $bforum['fup'] == $_G['forum']['fup'] && $bforum['status']}-->
<a href="forum.php?mod=forumdisplay&fid=$bforum[fid]" target="_blank">$bforum['name']</a>
							<!--{/if}-->
						<!--{/loop}-->
</div> </div>
<div class="region_footer"></div></div>
{/if}
 <div id="zyq" class="zyq_bright"><div class="mod"><div class="tl"><div class="mod_edit_wrap"></div>
 <div class="zyq_mod_icon zyq_mod_title"><span class="j_mod_tit">��Ҫ����</span></div></div>
 <div class="cnt">
				<!--[diy=r3]--><div id="r3" class="area"></div><!--[/diy]-->
 </div>
 </div>


 <div class="mod"><div class="tl"><div class="mod_edit_wrap"></div><span class="zyq_mod_title">��Ա����</span></div>
				<!--[diy=r4]--><div id="r4" class="area"></div><!--[/diy]-->
 </div></div>
 
 
			<div class="drag">
				<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
			</div>
			<!--{hook/forumdisplay_side_bottom}-->
	               <div id="fixeds"></div>
	</div>
	</div>
</div>
 <div class="clear"></div>
<div class="wp"><div class="pgs cl pgsbg">
	<div class="z">$multipage<span class="z" style="margin-top:5px; margin-left:20px"><i style="color:#F60;">$_G[forum_thread][allreplies]</i>&nbsp;�ظ�����<i style="color:#F60;">$_G[forum_thread][views]</i>&nbsp;�β鿴</span></div>
	<span class="pgb y"{if $_G['setting']['visitedforums']} id="visitedforumstmp" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id,'pos':'21'})"{/if}><a href="$upnavlink">{lang return_forumdisplay}</a></span>
</div>
</div>

<!--{hook/viewthread_middle}-->
 <!--{if $_G['basescript'] == 'forum' }-->
 <!--{if $fastpost}-->

<div class="wp fastbg">
<div><div class="wp">
	<!--{subtemplate forum/viewthread_fastpost}-->
<!--{/if}-->
 <!--{elseif $_G['basescript'] == 'group'  }-->
<div class="wp fastbg" style="position:relative; z-index:99;">
<div><div class="wp">
	<!--{subtemplate forum/viewthread_fastpost}-->
 <!--{/if}-->

<!--{hook/viewthread_bottom}-->

<!--{if ($_G['setting']['visitedforums']) && $_G['forum']['status'] != 3}-->
	<div id="visitedforums_menu" class="p_pop blk cl" style="display: none;">
		<table cellspacing="0" cellpadding="0">
			<tr>
				<td id="v_forums">
					<h3 class="mbn pbn bbda xg1">{lang viewed_forums}</h3>
					<ul class="xl xl1">
						$_G['setting']['visitedforums']
					</ul>
				</td>
			</tr>
		</table>
	</div>
<!--{/if}-->
<!--{if $_G['medal_list']}-->
<!--{loop $_G['medal_list'] $medalid $medal}-->
	<div id="md_{$medalid}_menu" class="tip tip_4" style="display: none;">
		<div class="tip_horn"></div>
		<div class="tip_c">
			<h4>$medal[name]</h4>
			<p>$medal[description]</p>
		</div>
	</div>
<!--{/loop}-->
<!--{/if}-->

<!--{if !IS_ROBOT && !empty($_G[setting][lazyload])}-->
	<script type="text/javascript">
	new lazyload();
	</script>
<!--{/if}-->

<!--{if !IS_ROBOT && $_G['setting']['threadmaxpages'] > 1}-->
	<script type="text/javascript">document.onkeyup = function(e){keyPageScroll(e, <!--{if $page > 1}-->1<!--{else}-->0<!--{/if}-->, <!--{if $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next']}-->1<!--{else}-->0<!--{/if}-->, 'forum.php?mod=viewthread&tid=$_G[tid]<!--{if $_GET[authorid]}-->&authorid=$_GET[authorid]<!--{/if}-->', $page);}</script>
<!--{/if}-->
</div>

<div class="wp mtn">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>
<!--{if $_G['relatedlinks'] || $_GET['highlight']}-->
	<script type="text/javascript">
		var relatedlink = [];
		<!--{loop $_G['relatedlinks'] $key $link}-->
		relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
		<!--{/loop}-->
		{eval $highlights = explode(' ', str_replace(array('\'', chr(125)), array('&#039;', '&#125;'), dhtmlspecialchars($_GET['highlight'])));}
		<!--{loop $highlights $word}-->
		{eval $key++;}
		relatedlink[$key] = {'sname':'$word', 'surl':''};
		<!--{/loop}-->
		relatedlinks('postmessage_$_G[forum_firstpid]');
	</script>
<!--{/if}-->

<!--{if !empty($_G['cookie']['clearUserdata']) && $_G['cookie']['clearUserdata'] == 'forum'}-->
	<script type="text/javascript">saveUserdata('forum_'+discuz_uid, '')</script>
<!--{/if}-->

<script type="text/javascript">
<!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || $_G['uid'] == $_G['thread']['authorid'])}-->
function showsetcover(obj) {
	if(obj.parentNode.id == 'postmessage_$_G[forum_firstpid]') {
		var defheight = $_G['setting']['forumpicstyle']['thumbheight'];
		var defwidth = $_G['setting']['forumpicstyle']['thumbwidth'];
		var newimgid = 'showcoverimg';
		var imgsrc = obj.src ? obj.src : obj.file;
		if(!imgsrc) return;

		var tempimg=new Image();
		tempimg.src=imgsrc;
		if(tempimg.complete) {
			if(tempimg.width < defwidth || tempimg.height < defheight) return;
		} else {
			return;
		}
		if($(newimgid) && obj.id != newimgid) {
			$(newimgid).id = 'img'+Math.random();
		}
		if($(newimgid+'_menu')) {
			var menudiv = $(newimgid+'_menu');
		} else {
			var menudiv = document.createElement('div');
			menudiv.className = 'tip tip_4 aimg_tip';
			menudiv.id = newimgid+'_menu';
			menudiv.style.position = 'absolute';
			menudiv.style.display = 'none';
			obj.parentNode.appendChild(menudiv);
		}
		menudiv.innerHTML = '<div class="tip_c xs0"><a onclick="showWindow(\'setcover_'+newimgid+'\', this.href)" href="forum.php?mod=ajax&amp;action=setthreadcover&amp;tid=$_G[tid]&amp;pid=$_G[forum_firstpid]&amp;fid=$_G[fid]&imgurl='+imgsrc+'">{lang set_cover}</a></div>';
		obj.id = newimgid;
		showMenu({'ctrlid':newimgid,'pos':'12'});
	}
	return;
}
<!--{/if}-->
function succeedhandle_followmod(url, msg, values) {
	var fObj = $('followmod_'+values['fuid']);
	if(values['type'] == 'add') {
		fObj.innerHTML = '{lang nofollow}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
	} else if(values['type'] == 'del') {
		fObj.innerHTML = '{lang follow}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
	}
}
<!--{if $_G['blockedpids']}-->
var blockedPIDs = [<!--{echo implode(',', $_G['blockedpids'])}-->];
<!--{/if}-->
<!--{if $postlist && empty($_G['setting']['disfixedavatar'])}-->
fixed_avatar([<!--{echo implode(',', array_keys($postlist))}-->], {if empty($_G['setting']['disfixednv_viewthread']) }1{else}0{/if});
<!--{else}-->
(function($){$(function () {

    var bartop = $('#fthread').offset().top,
        h2_con=$('#fthread').find("h2 a").text();
    function changeBar(){
        var st = $(window).scrollTop();
        if( st > bartop){
            $('#fthread').addClass('thread_fixed');
        }else{
            $('#fthread').removeClass('thread_fixed');
        }
    }
    $(window).scroll( function(){
        changeBar();
    })

})
})(jQuery)
<!--{/if}-->
</script>
	<script type="text/javascript">var userfix = $('fixeds');
var userfixoffset = parseInt(fetchOffset(userfix)['top']);
_attachEvent(window, 'scroll', function () {
var xlmmm_scrollTop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
if(xlmmm_scrollTop + 0 >= userfixoffset){
if (BROWSER.ie && BROWSER.ie < 7) {
userfix.style.position = 'absolute';
userfix.style.top = xlmmm_scrollTop + 'px';
}else{
userfix.innerHTML  = '<style>.topic_list_box{ position:fixed; top:0px; width:230px;z-index:1;background: #fff;}</style>';
}
}else{
userfix.innerHTML  = '<style>.topic_list_box{ position:static;}</style>';
}
});</script>
<!--{template common/footer}-->


