<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{subtemplate common/header_common}-->
	<meta name="application-name" content="$_G['setting']['bbname']" />
	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
			<!--{if $_G['basescript'] == 'group' && $action == 'index' && $status != 2 && $status != 3}-->
				<!--{subtemplate group/group_index}-->
  <!--{else}-->
	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
	<!--{/if}-->
	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
<SCRIPT language=javascript> 
<!-- 
window.onerror=function(){return true;} 
// --> 
</SCRIPT>
			  <SCRIPT type=text/javascript language=JavaScript src="$_G['style']['styleimgdir']/js/jquery.js"></SCRIPT>
     <script type="text/javascript">
     var jQ = jQuery.noConflict();
     </script>
 <script src="template/mmtieba/image/js/superslide.js" type="text/javascript"></script>
	    	<!--{if $_G['basescript'] == 'forum' }-->
	<!--{else}-->
		<link rel="stylesheet" id="css_widthauto" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_widthauto.css?{VERHASH}' />
		<!--{/if}-->
<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'portal'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<link rel="stylesheet" type="text/css" id="diy_common" href="{$_G['setting']['csspath']}{STYLEID}_css_diy.css?{VERHASH}" />
	<!--{/if}-->
</head>

<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if}" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<!--{template common/header_diy}-->
	<!--{/if}-->
	<!--{if check_diy_perm($topic)}-->
		<!--{template common/header_diynav}-->
	<!--{/if}-->
	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
		$diynav
	<!--{/if}-->
	<!--{if empty($topic) || $topic['useheader']}-->
		<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
			<div class="xi1 bm bm_c">
			    {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a>
			</div>
		<!--{/if}-->
		<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
			<div id="shortcut">
				<span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span>
				{lang shortcut_notice}
				<a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a>

			</div>
			<script type="text/javascript">setTimeout(setShortcut, 2000);</script>
		<!--{/if}-->

{if $_G['cache']['plugin']['xlmmtb']['xlmmtbtbys']==1} 
	<style>
.userbar{position:absolute;top:2px;right:10px; z-index:1}
.userbar ul li{float:left}
.u_username,.u_setting,.u_news{position:relative}
.u_username{margin-top:-4px}
.u_menu_item{padding:7px 6px 0;line-height:18px}
.u_menu_username{padding-right:0}
.u_username_avatar img{width:20px;height:20px;border-radius:2px;margin:0 5px -4px 0}
.u_username_title{font-weight:700;line-height:14px;padding:6px 4px 4px;}
.u_username .u_username_wrap{text-decoration:none}
.u_menu_wrap{background:url(template/mmtieba/image/user.png) no-repeat 0 0;display:block}
.u_username_wrap{background:0 0}
.u_setting_wrap,.u_wallet_wrap,.u_news_wrap,.u_tbmall_wrap,.u_app_wrap{width:14px;height:14px}
.u_setting_wrap{margin-top:1px;background-position:0 -25px}
.u_wallet_wrap{background-position:-49px -25px}
.u_news_wrap{margin-top:1px;position:relative;background-position:-23px -26px}
.u_news_wrap span{color:#fff;background:red;text-align:center;font-size:12px;line-height:1;position:absolute;top:-8px;left:12px;padding:2px;border-radius:2px}
.u_tbmall_wrap{background-position:-24px -64px}
.u_app_wrap{background-position:0 -82px}
.u_appcenterEntrance_wrap{background-position:-74px -3px;padding-left:20px}
.u_joinvip_wrap{background:url(template/mmtieba/image/uservip.gif) no-repeat 0 -4px;padding:4px 0 4px 26px}
.vip_red {color: red;}
.u_split {background: #999;width: 1px;height: 12px;margin: 8px 6px 0;}
.t-more_menu {position:relative;margin-top:10px;padding:10px;border:1px solid #b2afa9;border-radius:5px;background:#fff;box-shadow:none;}
.t-more_menu:after {content:"";position:absolute;right:3px;top:-4px;height:0;width:0;border-color:transparent transparent #fff transparent;border-style:dashed dashed solid dashed;border-width:0 4px 4px;}
.t-more_menu:before {content:"";position:absolute;right:2px;top:-5px;height:0;width:0;border-color:transparent transparent #000 transparent;border-style:dashed dashed solid dashed;border-width:0 5px 5px;}
.p_pop a { color:#333;}

#head{background:#fff}
.xl_search{margin:0 auto}
.senior-search-link{display:inline-block;margin-left:20px;color:#537cc4;margin-top:5px;text-decoration:none}
.senior-search-link:hover{text-decoration:none}
.xl_search_index .head_inner{width:1000px;margin:0 auto}
.xl_search_index .search_main .search_form{width:847px}
.xl_search_index .head_inner .search_logo{width:137px;height:46px;margin:38px 12px 0 0}
.xl_search_index .head_inner .head_right_region{width:760px;float:left;_overflow:hidden}
.xl_search_index .search_ipt{width:433px}
.xl_search_index .search_top{width:847px}
.xl_search_index .search_nav{padding-top:30px}
.xl_search.xl_search_index .search_main_wrap{height:52px}
.xl_search .search_ipt,.xl_search .search_btn_wrap,.xl_search .search_btn,.xl_search .search_btn_enter_ba{background:url(template/mmtieba/image/s.png) no-repeat;text-decoration:none}
.search_top{width:1000px;margin:0 auto;padding-bottom:2px}
.search_logo {width:117px;height:38px;display:inline;float:left;margin:8px 20px 0 0}

.search_nav li{float:left;height:20px;font-size:14px;}
.search_nav li span{ display:none;}
.search_nav li a{ float:left;margin-right:11px}
.search_nav li a:link,.search_nav li a:hover,.search_nav li a:visited{font-family:Arial,SimSun;color:#2d64b3;text-decoration:underline}
.search_nav li.a a {color:#3c3c3c; text-decoration:none;}

.search_main{display:block;width:100%;padding-bottom:10px}
.search_form{width:1000px;margin:0 auto}
.search_form form{position:relative}
.xl_search .search_ipt{font-family:Arial SimSun;width:538px;height:22px;padding:4px 10px;padding:8px 10px 0\9;line-height:normal;overflow:hidden;border:0;color:#53545e;font-size:15px;background-position:0 0;float:left;display:inline}
.xl_search .search_inp_border{border:1px solid #cdcdcd;border-color:#9a9a9a #cdcdcd #cdcdcd #9a9a9a}
.xl_search .search_btn_wrap{float:left;background-position:-202px -33px;width:97px;height:34px;display:inline-block;margin:0 0 0 3px;_margin-top:1px}
.xl_search .search_btn_enter_ba_wrap{margin-left:5px}
.xl_search .search_btn{height:32px;line-height:32px;*line-height:33px;overflow:hidden;padding:0;border:0;color:#363535;font-size:14px;float:left;display:inline;width:95px;text-align:center;background-position:0 -35px;margin-left:0;cursor:pointer}
.xl_search .search_btn:hover{background-position:0 -35px}
.xl_search .search_btn:visited{color:#363535}
.xl_search .search_btn_enter_ba{background-position:0 -72px;color:#fff}
.xl_search .search_btn_enter_ba:visited{color:#fff}
.xl_search .search_btn_enter_ba:hover{background-position:-100px -72px}
.xlmm_fixed{position:fixed;top:0;padding-bottom:0; width:100%;border-bottom:1px solid #DBDBDB;-o-box-shadow:0 0 2px #CCC;-webkit-box-shadow:0 0 2px #CCC;-moz-box-shadow:0 0 2px #CCC;box-shadow:0 0 2px #CCC;background-color:#FAFAFA;z-index:10; height:36px; padding-top:8px;_position:absolute!important;_top:expression(eval(document.documentElement.scrollTop)); overflow:hidden;}
</style>
	
<div class="userbar ">
<ul>
<!--{if $_G['uid']}-->
   <div class="y" style="margin-top:5px" >
<!--{hook/global_usernav_extra1}-->
</div>
<li class="u_username">
<div class="u_menu_item u_menu_username">
<a id="u-more"  onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'','pos':'34!'})" href="home.php?mod=space&uid=$_G[uid]" title="�������������" class="u_menu_wrap u_username_wrap"><en class="u_username_avatar"><!--{avatar($_G[uid],small)}--></em><span class="u_username_title">{$_G[member][username]}</span></a></div></li>
<!--{else}-->
<li class="u_login"><div class="u_menu_item"><a href="member.php?mod=logging&amp;action=login" onClick="showWindow('login', this.href)">��¼</a></div></li><li class="u_reg"><div class="u_menu_item"><a href="member.php?mod=register">ע��</a></div></li><!--{/if}-->
<!--{if $_G['uid']}--><li class="u_setting">
<div class="u_menu_item u_menu_setting">
<a id="s-more"  onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'','pos':'34!'})" class="u_menu_wrap u_setting_wrap" href="home.php?mod=spacecp" target="_blank"></a>
</div></li><!--{/if}-->
<li class="u_wallet"><div class="u_menu_item u_menu_wallet"><a class="u_menu_wrap u_wallet_wrap" title="����鿴���а�" href="misc.php?mod=ranklist" target="_blank"></a></div></li>
<!--{if $_G['uid']}-->
<li class="u_news"><div class="u_menu_item u_menu_news"><a id="p-more"  onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'','pos':'34!'})" href="home.php?mod=space&do=pm" class="u_menu_wrap u_news_wrap j_news" target="_blank"><!--{if $_G[member][newprompt] || $_G[member][newpm]}-->
<!--{eval $newxx = $_G[member][newpm] + $_G[member][newprompt];}--><span style="display: block;">$newxx</span><!--{/if}--></a></div></li><!--{/if}-->
   <li class="u_tbmall"><div class="u_menu_item u_menu_tbmall"><a class="u_menu_wrap u_tbmall_wrap" title="�鿴�û���" href="home.php?mod=spacecp&ac=usergroup" target="_blank"></a></div></li> 
  <li class="u_app"><div class="u_menu_item u_menu_app"><a class="u_menu_wrap u_app_wrap" title="�ֻ��ͻ���" href="misc.php?mod=mobile" target="_blank"></a></div></li>
<li class="u_split"></li><li class="u_appcenterEntrance"><div class="u_menu_item u_menu_appcenterEntrance"><a class="u_menu_wrap u_appcenterEntrance_wrap" href="/" title="�����̳�" target="_blank">�����̳�</a></div></li>
   <li class="u_joinvip"><div class="u_menu_item u_menu_joinvip"><a class="u_joinvip_wrap vip_red" href="misc.php?mod=ranklist" target="_blank">��Ա���а�</a></div></li>
   <li class="u_bdhome"><div class="u_menu_item u_menu_bdhome"><a href="/" target="_blank">��վ��ҳ</a></div></li>
   </ul>
        </div>
<div id="u-more_menu" class="t-more_menu" style="display:none;">
<div class="p_pop nav_pop" style="border:0; box-shadow: 0px 0px 0px">
							<ul>
			  <li><a href="home.php?mod=space&uid=$_G[uid]&do=thread&view=me&from=space">�ҵ�����</a></li>
  <li><a href="home.php?mod=space&do=favorite&view=me">�ҵ��ղ�</a></li>
  <li><a href="home.php?mod=medal&action=log">�ҵ�ѫ��</a></li>
								<!--{hook/global_usernav_extra3}-->
								<!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
									<li><a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
									<li><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']}-->
									<li><a href="admin.php?frames=yes&action=cloud&operation=applist" target="_blank">{lang cloudcp}</a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
									<li><a href="admin.php" target="_blank">{lang admincp}</a></li>
								<!--{/if}-->
								<!--{hook/global_usernav_extra4}-->
							</ul>
</div>
</div>
<div id="s-more_menu" class="t-more_menu" style="display:none;">
<div class="p_pop nav_pop" style="border:0; box-shadow: 0px 0px 0px">
							<ul>
  <li><a href="home.php?mod=spacecp">�˺�����</a></li>
  <li><a href="home.php?mod=spacecp&ac=avatar">ͷ������</a></li>
<li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
							</ul>
</div>
</div>
<div id="p-more_menu" class="t-more_menu" style="display:none;">
<div class="p_pop nav_pop" style="border:0; box-shadow: 0px 0px 0px">
							<ul>
  <li><a href="home.php?mod=space&do=notice&view=mypost">�鿴�ظ�</a></li>
  <li><a href="home.php?mod=space&do=pm">�鿴��Ϣ<!--{if $_G[member][newprompt]}--><em style="color:red; margin-left:10px;">($_G[member][newprompt])</em><!--{/if}--></a></li>
  <li><a href="home.php?mod=space&do=notice&type=at">�鿴@�ᵽ��</a></li>
  <li><a href="home.php?mod=space&do=notice&type=friends">�鿴��˿</a></li>
  <li><a href="home.php?mod=space&do=notice&type=other&isread=1">�ҵ�֪ͨ<!--{if $_G[member][newpm]}--><em style="color:red; margin-left:10px;">({$_G[member][newpm]})</em><!--{/if}--></a></li>
							</ul>
</div>
</div>
								<!--{if check_diy_perm($topic)}-->
						$diynav
					<!--{/if}-->

		<!--{ad/headerbanner/wp a_h}-->
    	<!--{if $_G['basescript'] == 'portal' || $_G['basescript'] == 'forum' && CURMODULE == 'index' || $_G['basescript'] == 'group' && CURMODULE == 'index'   }-->
<div id="fsss" class="xl_search_index xl_search clearfix">
					<!--{eval $mnid = getcurrentnav();}-->
<div class="head_inner wp">
<em class="search_logo" ><!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}--></em>

<div class="head_right_region">    
<div class="search_top clearfix" >
<div class="search_nav">
					<ul>
						<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
						<!--{/loop}-->
				</ul>
					<!--{hook/global_nav_extra}-->
</div></div>

<div class="search_main_wrap">
<div class="search_main clearfix">
<div class="search_form">
<form class="clearfix" id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
						<input type="hidden" name="mod" id="mod" value="{if $_G['basescript'] == 'portal'}portal{elseif $_G['basescript'] == 'group'}group{else}forum{/if}" />
<input class="search_ipt search_inp_border" name="srchtxt" type="text" id="keyword"   placeholder=""/>
<!--{if $_G['basescript'] == 'portal'}-->
<span class="search_btn_wrap"><a href="javascript:;" onClick="$('scbar_form').submit();" id="submitBtn"  class="search_btn">����һ��</a></span>
<!--{else}--><span class="search_btn_wrap search_btn_enter_ba_wrap"><a href="javascript:;" onClick="$('scbar_form').submit();" id="submitBtn"  class="search_btn search_btn_enter_ba">{if $_G['basescript'] == 'group'}��������{else}��������{/if}</a></span>
<span class="search_btn_wrap"><a class="search_btn" href="search.php?mod=forum" target="_blank">ȫ������</a></span>
<!--{/if}-->
<a class="senior-search-link" href="search.php?mod=forum&adv=yes" target="_blank">�߼�����</a>
      	<!--{if $_G['basescript'] == 'portal' && CURMODULE == 'list' || $_G['basescript'] == 'portal' && CURMODULE == 'view'  }-->
    				<!--{if ($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])}-->
				<a href="portal.php?mod=portalcp&ac=article&catid=$cat[catid]" class="senior-search-link" style="color:red">���������¡�</a>
				<!--{/if}-->
				<!--{/if}-->
              </form>
					</div></div> </div></div></div></div></div></div>   
    	<!--{if $_G['basescript'] == 'portal' }-->
<style>
.mod-navbar{width:100%;height:40px;background-color:#01204f}
.channel-shanghai,.channel-all{position:relative;width:1000px;margin:0 auto}
.mod-navbar li{float:left}
.mod-navbar .menu-list{float:left;width:1000px}
.mod-navbar .menu-list a{display:block;_display:inline;_zoom:1;height:100%;font-size:14px;line-height:40px;font-weight:700;padding:0 10px;*padding:0 9px;_padding:0 9px;color:#fff;margin-right:2px}
.mod-navbar a:link,.mod-navbar a:visited,.mod-navbar a:hover{color:#fff;text-decoration:none}
.mod-navbar .menu-list .current a, .mod-navbar .menu-list a:hover{background-color:#c00}
.mod-navbar .menu-list .navitem-index a{padding-left:30px;*padding-left:28px;background-image:url(template/mmtieba/image/xlmm-index.png);background-repeat:no-repeat;background-position:6px 7px}
</style>
</div>
<div class="mod-navbar">
<div class="channel-all clearfix">
<div class="menu-list">
<ul class="clearfix">
<li class="navitem-index{if $_G['basescript'] == 'portal' && CURMODULE == 'index'} current{/if}"><a href="portal.php">��ҳ</a></li>
 <!--{eval $query = DB::query("SELECT catid,upid,catname FROM ".DB::table('portal_category')."  ORDER BY catid;");while($data = DB::fetch($query)) $temp[]=$data;}-->
 <!--{loop $temp $portal_type}-->
 <!--{if $portal_type['upid']=="0"}-->
<li class="{if $portal_type['catid'] == $_G['catid']}current {/if}"><a href="portal.php?mod=list&catid={$portal_type['catid']}" target="_blank">{$portal_type['catname']}</a></li>
 <!--{/if}-->
 <!--{/loop}-->
</ul>
</div>
</div>
</div>
 <!--{/if}-->      

	<!--{else}-->
			<style>
.search_logos img{ display:none}
.xlmm_fixed .search_logos img{ display:block; width:100px;height:28px;display:inline;float:left; margin-right:10px; position:relative; z-index:99}
.xlmm_fixed .search_btn_wrap{width:71px;height:28px;}
.xlmm_fixed  .search_ipt{    width: 462px;height: 20px;padding: 4px 10px;border: 0;font-size: 14px; line-height: 20px;}
.xlmm_fixed  .search_ipt, .xlmm_fixed .search_btn_wrap, .xlmm_fixed .search_btn, .xlmm_fixed .search_btn_enter_ba{background: url(template/mmtieba/image/sd.png) no-repeat;text-decoration:none}
.xlmm_fixed   .search_btn{height: 28px;line-height: 28px;*line-height: 29px;font-size: 12px;width: 71px;background-position: 0 -33px;}
.xlmm_fixed .search_btn_enter_ba {background-position: 0 -99px;color: #fff;}
.xlmm_fixed .search_btn_enter_ba:hover{background-position:0 -132px}
</style>
<div id="head" class="xl_search clearfix">
  					<!--{eval $mnid = getcurrentnav();}-->
  <div class="search_top clearfix">
<em class="search_logo" style=" padding-bottom:9px; padding-right:12px; float:left; padding-left:0" ><!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}--></em>
        <div class="search_nav" style="padding-top:32px">
					<ul>
						<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
						<!--{/loop}-->
					</ul>
					<!--{hook/global_nav_extra}-->
        </div>
    </div>
    <div class="search_main_wrap">
        <div class="search_main clearfix" id="fsss">
            <div class="search_form">
<em class="search_logos" ><!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}--></em>
<form class="clearfix" id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
						<input type="hidden" name="mod" id="mod" value="{if $_G['basescript'] == 'group'}group{else}forum{/if}" />
<input class="search_ipt search_inp_border" name="srchtxt" type="text" id="keyword"   placeholder=""/>
<span class="search_btn_wrap search_btn_enter_ba_wrap"><a href="javascript:;" onClick="$('scbar_form').submit();" id="submitBtn"  class="search_btn search_btn_enter_ba">{if $_G['basescript'] == 'group'}��������{else}��������{/if}</a>
</span>
<span class="search_btn_wrap"><a class="search_btn" href="search.php?mod=forum" target="_blank">ȫ������</a>
</span>
<a class="senior-search-link" href="search.php?mod=forum&adv=yes" target="_blank">�߼�����</a>
                    </form>
        </div>
    </div>
</div>
					   </div></div>
	
	<!--{/if}-->
				<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
					<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
					<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
						 <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
						 <li>$module[url]</li>
						 <!--{/if}-->
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
				$_G[setting][menunavs]
      	<!--{if $_G['basescript'] == 'forum' && CURMODULE == 'guide'  }-->
					<div class="wp" >
					<div id="nv">
			<!--{if $view != 'index'}-->
				<ul>
					<!--{if helper_access::check_module('guide')}-->
					<li $currentview['index']><a href="forum.php?mod=guide&view=index">{lang guide_index}</a></li>
					<!--{/if}-->
					<li $currentview['hot']><a href="forum.php?mod=guide&view=hot">{lang guide_hot}</a></li>
					<li $currentview['digest']><a href="forum.php?mod=guide&view=digest">{lang guide_digest}</a></li>
					<li $currentview['new']><a href="forum.php?mod=guide&view=new">{lang guide_new}</a></li>
					<li $currentview['my']><a href="forum.php?mod=guide&view=my">{lang guide_my}</a></li>
					<!--{hook/guide_nav_extra}-->
				</ul>
			<!--{/if}-->
				</div>
				</div>
			<!--{/if}-->
{else} 
	<style>

.userbar{ float:right;}
.userbar a{ color:#333;text-decoration: underline;
font-family: Arial; font-size:13px;}
.search_nav li, .userbar ul li{float:left; margin-top:8px;}
.u_menu_item{padding: 0 11px;}

.u_joinvip_wrap{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAABVUlEQVQ4jZWRsUoDQRCGpwoWwSKklbOxsVSLYOEzCBGxUIs0hoD9QfZ2Z3eDKKQSUwQk6SIhjyARUaOIeFgJYqOgBixyrQlZx0IuHpELdwsDy8+33w4zACGnqW3Hk5bxpGWa2nbCuFDQk5ZpKKfQUE7Bk5YJ5cPAUa7Zridn/uc+7wcnqpj3BUfFsvXBFwYkgUgC9ficqeHefFAw4on/QiSBiAMd4/7KnVh/veTbj/6vZ2Ln5oGvftbxIDPOAzEgHzzF/EWfpcgV2W4Vy2k/ryAmb/nGS5+l6JznXD8nNiaIu4WJgrDhRhaQ+suD99gdBLcTS9DStvCkZXpqdtjStpgoCE486qliOU0MCK7E1tO9WHtHxETUx4iYcEW2ey02n6GCmHzjS31iQHGq6ywODhGnAQBgqIBqpdJy1A7qWMp8qanvUdDWuc5QAVHEMgqorXMdAIAfvK9DwU6Em8YAAAAASUVORK5CYII=) no-repeat 0 4px;padding:4px 0 4px 26px}
.vip_red {color: red;}
.u_split {background: #999;width: 1px;height: 12px;margin: 8px 6px 0;}
.t-more_menu {position:relative;margin-top:10px;padding:10px;border:1px solid #b2afa9;border-radius:5px;background:#fff;box-shadow:none;}
.t-more_menu:after {content:"";position:absolute;right:3px;top:-4px;height:0;width:0;border-color:transparent transparent #fff transparent;border-style:dashed dashed solid dashed;border-width:0 4px 4px;}
.t-more_menu:before {content:"";position:absolute;right:2px;top:-5px;height:0;width:0;border-color:transparent transparent #000 transparent;border-style:dashed dashed solid dashed;border-width:0 5px 5px;}
.p_pop a { color:#333;}
#qmenu{background: url({STYLEIMGDIR}/none.png); margin:0;padding-right: 0; height:18px; line-height:18px; width:63px; font-weight:normal;color: #333;}
.xlmm-dl { float:right; margin-top:5px;}
.xlmm-dl .hm { display:none;}
.xlmm-dl .fastlg_fm {border-right:0;}
.u_menu_item .i-arrow-down {display: inline-block;width: 7px;height: 16px;vertical-align: bottom;margin-left: 4px;background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAcAAAAECAYAAABCxiV9AAAAHUlEQVQImWNobW39jwszMDAwMOCUgAGcEsgKkPkAHVQo4ZFRKoUAAAAASUVORK5CYII=) no-repeat 0 6px;}
#head{background:#fff; position:relative; z-index:10;}
.xl_search{margin:0 auto; padding-bottom:20px;}
.senior-search-link{display:inline-block;margin-left:18px;color:#333;margin-top:10px;text-decoration:none}
.senior-search-link:hover{text-decoration:none}
.xl_search_index .head_inner{width:1000px;margin:0 auto;}
.xl_search_index .head_inner .search_logo{width:137px;height:46px;margin:0 12px 0 0}
.xl_search_index .head_inner .head_right_region{width:760px;float:left;_overflow:hidden}
.xl_search_index .search_ipt{width:433px}
.xl_search_index .search_top{width:847px}
.search_nav{ float: right; margin-right:50px;}
.xl_search.xl_search_index .search_main_wrap{height:52px}
.search_top{width:1000px;margin:0 auto;padding-bottom:2px}
.search_logo {width:117px;height:38px;display:inline;float:left;margin:8px 20px 0 0}

.search_nav li{float:left;height:28px;}
.search_nav li span{ display:none;}
.search_nav li a{ float:left;margin-right:21px;font-size:13px;font-weight: 700;}
.search_nav li a:link,.search_nav li a:hover,.search_nav li a:visited{font-family: Arial,SimSun;
color: #333;
text-decoration: underline;}
.search_nav li.a a { text-decoration:none;color: #666;}

.search_main{display:block;width:100%;padding-bottom:10px}
.search_form form{position:relative}
.xl_search .search_ipt{font-family:Arial SimSun;width:538px;height:30px;padding:4px 10px;padding:8px 10px 0\9;line-height:normal;overflow:hidden;border:0;color:#53545e;font-size:15px;background-position:0 0;float:left;display:inline}
.xl_search .search_inp_border{border: 1px solid #b8b8b8;}
.xl_search .search_btn_wrap{float:left;display:inline-block;margin:0 0 0 4px;_margin-top:1px;}
.xl_search .search_btn_enter_ba_wrap{margin-left:-5px}
.xl_search .search_btn{height:38px;line-height:38px;*line-height:39px;overflow:hidden;padding:0;border:0;color: #38f;font-size:14px;float:left;display:inline;width:105px;text-align:center;margin-left:0;cursor:pointer;border: 1px solid #38f;}
.xl_search .search_btn:hover{box-shadow: 1px 1px 2px #c7c7c7;text-decoration: none !important;}
.xl_search .search_btn:visited{color: #38f;}
.xl_search .search_btn_enter_ba{background: #38f;color:#fff}
.xl_search .search_btn_enter_ba:visited{color:#fff}
.xl_search .search_btn_enter_ba:hover{background: #2977ef;
box-shadow: 1px 1px 2px #c7c7c7;text-decoration: none }
    	<!--{if $_G['basescript'] == 'forum' && CURMODULE == 'index' || $_G['basescript'] == 'group' && CURMODULE == 'index'   }-->
 .xl_search .search_ipt{width:422px;}
 .xl_search { width:880px;margin: 0 auto;}
<!--{else}-->      
 .search_form{width:847px;}
<!--{/if}-->      


.xlmm_fixed{position:fixed;top:0;padding-bottom:0; width:100%;border-bottom:1px solid #DBDBDB;-o-box-shadow:0 0 2px #CCC;-webkit-box-shadow:0 0 2px #CCC;-moz-box-shadow:0 0 2px #CCC;box-shadow:0 0 2px #CCC;background-color:#FAFAFA;z-index:10; height:44px; padding-top:11px;_position:absolute!important;_top:expression(eval(document.documentElement.scrollTop)); overflow:hidden;}
.xlmm_fixed .search_btn_enter_ba_wraps { margin-left:0 !important;}

/* sc */
.xlmm_fixed .search_form{width:847px;}
.xlmm_fixed .head_inner .search_logo{width:100px;height:28px;margin:0 12px 0 0}
.xlmm_fixed  .search_logo img{width:100px;height:33px}
.xlmm_fixed .search_btn_wrap{height:32px;margin-left:5px;}
.xlmm_fixed  .search_ipt{ margin-left:5px;width: 521px;height: 24px;padding: 4px 10px;font-size: 14px; line-height: 24px;}
.xlmm_fixed   .search_btn{height: 32px;line-height: 32px;*line-height: 33px;font-size: 12px;width:98px;}
.xlmm_fixed .senior-search-link{display:inline-block;margin-left:12px;margin-top:7px;text-decoration: underline;}
/* end */

</style>
		<!--{eval $mnid = getcurrentnav();}-->
<div id="head">
<div class="xlmms_top clearfix">
<div class="userbar ">
			<!--{hook/global_cpnav_top}-->
<ul>
   <div class="y" style="margin-top:5px" >
					<!--{hook/global_cpnav_extra1}--><!--{hook/global_cpnav_extra2}-->
</div>
<!--{if $_G['uid']}-->
   <div class="y" style="margin-top:5px" >
<!--{hook/global_usernav_extra1}-->
</div>
<li>
<div class="u_menu_item">
<a id="u-more"  onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'','pos':'34!'})" href="home.php?mod=space&uid=$_G[uid]" title="�������������">{$_G[member][username]}<i class="i-arrow-down"></i></a></div></li>
<!--{else}-->
{if $_G['basescript'] == 'member' && CURMODULE == 'register' || $_G['basescript'] == 'member' && CURMODULE == 'logging'}{else}<li class="u_login"><div class="u_menu_item"><a href="member.php?mod=logging&amp;action=login" onClick="showWindow('login', this.href)">��¼</a></div></li><li class="u_reg"><div class="u_menu_item"><a href="member.php?mod={$_G[setting][regname]}">ע��</a></div></li>{/if}
   <div class="xlmm-dl" >
		<!--{hook/global_login_extra}-->
</div>
<!--{/if}-->
<!--{if $_G['uid']}-->
<li><div class="u_menu_item"><a id="p-more"  onmouseover="showMenu({'ctrlid':this.id,'ctrlclass':'','pos':'34!'})" href="home.php?mod=space&do=pm" target="_blank">��Ϣ<!--{if $_G[member][newprompt] || $_G[member][newpm]}-->
<!--{eval $newxx = $_G[member][newpm] + $_G[member][newprompt];}--><span>$newxx</span><!--{/if}--><i class="i-arrow-down"></i></a></div></li><!--{/if}-->
   <li><div class="u_menu_item"><a class="u_joinvip_wrap vip_red" href="misc.php?mod=ranklist" target="_blank">��Ա����</a></div></li>
   <li><div class="u_menu_item"><a href="javascript:;" id="qmenu" onMouseOver="delayShow(this, function () {showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2});showForummenu($_G[fid]);})">{lang my_nav}<i class="i-arrow-down"></i></a></div></li>
   </ul>
        </div>
<div class="search_nav">
					<ul>
						<!--{loop $_G['setting']['navs'] $nav}-->
							<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
						<!--{/loop}-->
					</ul>
					<!--{hook/global_nav_extra}-->
</div>
	</div>
<div id="u-more_menu" class="t-more_menu" style="display:none;">
<div class="p_pop nav_pop" style="border:0; box-shadow: 0px 0px 0px">
							<ul>
					<li><a href="forum.php?mod=guide&view=my">�ҵ�{lang mypost}</a></li>
					<li><a href="home.php?mod=space&do=favorite&view=me">�ҵ�{lang favorite}</a></li>
					<li><a href="home.php?mod=space&do=friend">�ҵ�{lang friends}</a></li>
  <li><a href="home.php?mod=medal&action=log">�ҵ�ѫ��</a></li>
					<!--{hook/global_myitem_extra}-->
								<!--{hook/global_usernav_extra3}-->
								<!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
									<li><a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
									<li><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>
								<!--{/if}-->
								<!--{if $_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']}-->
									<li><a href="admin.php?frames=yes&action=cloud&operation=applist" target="_blank">{lang cloudcp}</a></li>
								<!--{/if}-->
		<!--{hook/global_usernav_extra2}-->
								<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
									<li><a href="admin.php" target="_blank">{lang admincp}</a></li>
								<!--{/if}-->
  <li><a href="home.php?mod=spacecp">�˺�����</a></li>
  <li><a href="home.php?mod=spacecp&ac=avatar">ͷ������</a></li>
<li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a></li>
								<!--{hook/global_usernav_extra4}-->
							</ul>
</div>
</div>
<div id="p-more_menu" class="t-more_menu" style="display:none;">
<div class="p_pop nav_pop" style="border:0; box-shadow: 0px 0px 0px">
							<ul>
  <li><a href="home.php?mod=space&do=notice&view=mypost">�鿴�ظ�</a></li>
  <li><a href="home.php?mod=space&do=pm">�鿴��Ϣ<!--{if $_G[member][newprompt]}--><em style="color:red; margin-left:10px;">($_G[member][newprompt])</em><!--{/if}--></a></li>
  <li><a href="home.php?mod=space&do=notice&type=at">�鿴@�ᵽ��</a></li>
  <li><a href="home.php?mod=space&do=notice&type=friends">�鿴��˿</a></li>
  <li><a href="home.php?mod=space&do=notice&type=other&isread=1">�ҵ�֪ͨ<!--{if $_G[member][newpm]}--><em style="color:red; margin-left:10px;">({$_G[member][newpm]})</em><!--{/if}--></a></li>
							</ul>
</div>
</div>
							<!--{if check_diy_perm($topic)}-->
						$diynav
					<!--{/if}-->
		<!--{if !IS_ROBOT}-->
			<!--{subtemplate common/header_qmenu}-->
		<!--{/if}-->
		<!--{ad/headerbanner/wp a_h}-->
<div id="fsss" class="xl_search_index xl_search clearfix">
<div class="head_inner wp">
<em class="search_logo" ><!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}--></em>

<div class="head_right_region">    

<div class="search_main_wrap">
<div class="search_main clearfix">
<div class="search_form">
<form class="clearfix" id="scbar_form" method="{if $_G[fid] && !empty($searchparams[url])}get{else}post{/if}" autocomplete="off" action="{if $_G[fid] && !empty($searchparams[url])}$searchparams[url]{else}search.php?searchsubmit=yes{/if}" target="_blank">
						<input type="hidden" name="mod" id="mod" value="{if $_G['basescript'] == 'portal'}portal{elseif $_G['basescript'] == 'group'}group{else}forum{/if}" />
<input class="search_ipt search_inp_border" name="srchtxt" type="text" id="keyword"   placeholder=""/>
<!--{if $_G['basescript'] == 'portal'}-->
<span class="search_btn_wrap"><a href="javascript:;" onClick="$('scbar_form').submit();" id="submitBtn"  class="search_btn">����һ��</a></span>
<!--{else}--><span class="search_btn_wrap search_btn_enter_ba_wrap search_btn_enter_ba_wraps"><a href="javascript:;" onClick="$('scbar_form').submit();" id="submitBtn"  class="search_btn search_btn_enter_ba">{if $_G['basescript'] == 'group'}��������{else}��������{/if}</a></span>
<span class="search_btn_wrap"><a class="search_btn" href="search.php?mod=forum" target="_blank">ȫ������</a></span>
<!--{/if}-->
<a class="senior-search-link" href="search.php?mod=forum&adv=yes" target="_blank">�߼�����</a>
      	<!--{if $_G['basescript'] == 'portal' && CURMODULE == 'list' || $_G['basescript'] == 'portal' && CURMODULE == 'view'  }-->
    				<!--{if ($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])}-->
				<a href="portal.php?mod=portalcp&ac=article&catid=$cat[catid]" class="senior-search-link" style="color:red">���������¡�</a>
				<!--{/if}-->
				<!--{/if}-->
              </form>
					</div></div> </div></div></div></div></div></div>   
</div>
    	<!--{if $_G['basescript'] == 'portal' }-->
<style>
.mod-navbar{width:100%;height:40px;background-color:#01204f}
.channel-shanghai,.channel-all{position:relative;width:1000px;margin:0 auto}
.mod-navbar li{float:left}
.mod-navbar .menu-list{float:left;width:1000px; height:40px; overflow:hidden;}
.mod-navbar .menu-list a{display:block;_display:inline;_zoom:1;height:100%;font-size:14px;line-height:40px;font-weight:700;padding:0 10px;*padding:0 9px;_padding:0 9px;color:#fff;margin-right:2px}
.mod-navbar a:link,.mod-navbar a:visited,.mod-navbar a:hover{color:#fff;text-decoration:none}
.mod-navbar .menu-list .current a, .mod-navbar .menu-list a:hover{background-color:#c00}
.mod-navbar .menu-list .navitem-index a{padding-left:30px;*padding-left:28px;background-image:url(template/mmtieba/image/xlmm-index.png);background-repeat:no-repeat;background-position:6px 7px}
</style>
</div>
<div class="mod-navbar">
<div class="channel-all clearfix">
<div class="menu-list">
<ul class="clearfix">
<li class="navitem-index{if $_G['basescript'] == 'portal' && CURMODULE == 'index'} current{/if}"><a href="portal.php">��ҳ</a></li>
 <!--{eval $query = DB::query("SELECT catid,upid,catname FROM ".DB::table('portal_category')."  ORDER BY catid;");while($data = DB::fetch($query)) $temp[]=$data;}-->
 <!--{loop $temp $portal_type}-->
 <!--{if $portal_type['upid']=="0"}-->
<li class="{if $portal_type['catid'] == $_G['catid']}current {/if}"><a href="portal.php?mod=list&catid={$portal_type['catid']}" target="_blank">{$portal_type['catname']}</a></li>
 <!--{/if}-->
 <!--{/loop}-->
</ul>
</div>
</div>
</div>
 <!--{/if}-->      


				<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
					<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
					<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
						 <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
						 <li>$module[url]</li>
						 <!--{/if}-->
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
				$_G[setting][menunavs]
			{/if}
	<!--{ad/subnavbanner/a_mu}-->
	<!--{hook/global_header}-->
	<!--{/if}-->
	<div id="wp" class="wp">
 <!--{/if}-->      
<!--{eval 	global $_G;
	loadcache('plugin');
}-->


