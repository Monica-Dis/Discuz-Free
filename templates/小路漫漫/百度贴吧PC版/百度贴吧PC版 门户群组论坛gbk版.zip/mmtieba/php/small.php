<?php
$filename= $_GET['filename'];
$width = $_GET['width'];
$height = $_GET['height'];

header('Content-type: image/jpeg');

list($width_orig, $height_orig) = getimagesize($filename);
  
$dst_scale = $height/$width; //Ŀ��ͼ�񳤿���
$src_scale = $height_orig/$width_orig; // ԭͼ������
  
if ($src_scale>=$dst_scale){  // ����
    $w = intval($width_orig);
    $h = intval($dst_scale*$w);
  
    $x = 0;
    $y = ($height_orig - $h)/2;
} else { // ����
    $h = intval($height_orig);
    $w = intval($h/$dst_scale);
  
    $x = ($width_orig - $w)/2;
    $y = 0;
}
 
    $xlmmattach_info   = getimagesize($filename);
    $xlmmattach_mime   = $xlmmattach_info['mime'];

    switch ($xlmmattach_mime)
    {
        case 'image/gif':
            $xlmmattach = imagecreatefromgif($filename);
            break;

        case 'image/jpeg':
            $xlmmattach = imagecreatefromjpeg($filename);
            break;

        case 'image/png':
            $xlmmattach = imagecreatefrompng($filename);
            break;

        default:
            return false;
            break;
    }


// ����
$croped=imagecreatetruecolor($w, $h);
imagecopy($croped, $xlmmattach, 0, 0, $x, $y, $width_orig, $height_orig);
  
// ����
$scale = $width / $w;
$image_p = imagecreatetruecolor($width, $height);
$final_w = intval($w * $scale);
$final_h = intval($h * $scale);
imagecopyresampled($image_p, $croped, 0, 0, 0, 0, $final_w,$final_h, $w, $h);
 
imagejpeg($image_p, null, 100);
imagedestroy ($image_p);
?>
 

