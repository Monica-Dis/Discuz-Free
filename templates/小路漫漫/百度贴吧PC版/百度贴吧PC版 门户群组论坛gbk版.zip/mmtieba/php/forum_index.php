<?php

/**
 *      Ӧ�ø���֧�֣�https://dism.taobao.com
 *      ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 *      $Id: forum_index.php 34291 2013-12-17 03:47:28Z hypowang $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/forumlist');

$grids = array();

		$grids['hot'] = C::t('forum_thread')->fetch_all_for_guide('hot', 0, array(), 3, 0, 0, 20);

		$_G['forum_colorarray'] = array('', '#EE1B2E', '#EE5023', '#996600', '#3C9D40', '#2897C5', '#2B65B7', '#8F2A90', '#EC1282');
		foreach($grids as $type => $gridthreads) {
			foreach($gridthreads as $key => $gridthread) {
				$gridthread['dateline'] = str_replace('"', '\'', dgmdate($gridthread['dateline'], 'u', '9999', getglobal('setting/dateformat')));
				$gridthread['lastpost'] = str_replace('"', '\'', dgmdate($gridthread['lastpost'], 'u', '9999', getglobal('setting/dateformat')));
				if($gridthread['highlight'] && $_G['setting']['grid']['highlight']) {
					$string = sprintf('%02d', $gridthread['highlight']);
					$stylestr = sprintf('%03b', $string[0]);

					$gridthread['highlight'] = ' style="';
					$gridthread['highlight'] .= $stylestr[0] ? 'font-weight: bold;' : '';
					$gridthread['highlight'] .= $stylestr[1] ? 'font-style: italic;' : '';
					$gridthread['highlight'] .= $stylestr[2] ? 'text-decoration: underline;' : '';
					$gridthread['highlight'] .= $string[1] ? 'color: '.$_G['forum_colorarray'][$string[1]] : '';
					$gridthread['highlight'] .= '"';
				} else {
					$gridthread['highlight'] = '';
				}
				if($_G['setting']['grid']['textleng']) {
					$gridthread['oldsubject'] = dhtmlspecialchars($gridthread['subject']);
					$gridthread['subject'] = cutstr($gridthread['subject'], $_G['setting']['grid']['textleng']);
				}

				$grids[$type][$key] = $gridthread;
			}
}

if(!$gid && (!defined('FORUM_INDEX_PAGE_MEMORY') || !FORUM_INDEX_PAGE_MEMORY)) {
	$announcements = get_index_announcements();


	$forums = C::t('forum_forum')->fetch_all_by_status(1);
	$fids = array();
	foreach($forums as $forum) {
		$fids[$forum['fid']] = $forum['fid'];
	}





}



function get_index_announcements() {

}




function categorycollapse() {
}
//From: Dism_taobao-com
?>

