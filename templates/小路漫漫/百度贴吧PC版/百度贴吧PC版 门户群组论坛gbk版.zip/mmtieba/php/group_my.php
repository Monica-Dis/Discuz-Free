<?php

/**
 *      Ӧ�ø���֧�֣�https://dism.taobao.com
 *      ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *
 *      $Id: group_my.php 30630 2012-06-07 07:16:14Z zhengqingpeng $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$view = $_GET['view'] && in_array($_GET['view'], array('manager', 'join', 'groupthread', 'mythread')) ? $_GET['view'] : 'groupthread';

$perpage = 15;
$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
$start = ($page - 1) * $perpage;
if($view == 'groupthread' || $view == 'mythread') {
	$typeid = intval($_GET['typeid']);
	$attentiongroups = $usergroups = array();
	$usergroups = update_usergroups($_G['uid']);
	if($view == 'groupthread' && empty($typeid) && !empty($usergroups['grouptype'])) {
		$attentiongroup = $_G['member']['attentiongroup'];
		if(empty($attentiongroup)) {
			$attentiongroups = array_slice(array_keys($usergroups['groups']), 0, 1);
		} else {
			$attentiongroups = explode(',', $attentiongroup);
		}
		$attentionthread = $attentiongroup_icon = array();
		$attentiongroupfid = '';
		$query = C::t('forum_forum')->fetch_all_info_by_fids($attentiongroups);
		foreach($attentiongroups as $groupid) {
			$attentiongroupfid .= $attentiongroupfid ? ','.$groupid : $groupid;
			if($page == 1) {
				foreach(C::t('forum_thread')->fetch_all_by_fid_displayorder($groupid, 0, null, null, 0, 5, 'lastpost', 'DESC', '=') as $thread) {
					$attentionthread[$groupid][$thread['tid']]['author'] = $thread['author'];
					$attentionthread[$groupid][$thread['tid']]['fid'] = $thread['fid'];
					$attentionthread[$groupid][$thread['tid']]['subject'] = $thread['subject'];
					$attentionthread[$groupid][$thread['tid']]['groupname'] = $usergroups['groups'][$thread['fid']];
					$attentionthread[$groupid][$thread['tid']]['views'] =  $thread['views'];
					$attentionthread[$groupid][$thread['tid']]['replies'] =  $thread['replies'];
					$attentionthread[$groupid][$thread['tid']]['lastposter'] =  $thread['lastposter'];
					$attentionthread[$groupid][$thread['tid']]['lastpost'] = dgmdate($thread['lastpost'], 'u');
					$attentionthread[$groupid][$thread['tid']]['folder'] = 'common';
					if(empty($_G['cookie']['oldtopics']) || strpos($_G['cookie']['oldtopics'], 'D'.$thread['tid'].'D') === FALSE) {
						$attentionthread[$groupid][$thread['tid']]['folder'] = 'new';
					}
				}
			}
		}
	}

	$mygrouplist = mygrouplist($_G['uid'], 'lastupdate', array('f.name', 'ff.icon'), 50);
	if($mygrouplist) {

		$mygroupfid = array_keys($mygrouplist);
		if($typeid && !empty($usergroups['grouptype'][$typeid]['groups'])) {
			$mygroupfid = explode(',', $usergroups['grouptype'][$typeid]['groups']);
			$typeurl = '&typeid='.$typeid;
		} else {
			$typeid = 0;
		}
		if(!empty($attentiongroupfid) && !empty($mygroupfid)) {
			$mygroupfid = array_diff($mygroupfid, explode(',', $attentiongroupfid));
		}
		if($mygroupfid) {
			$lastpost = 0;
			$displayorder = null;
			if($view != 'mythread') {
				$displayorder = 0;
				$lastpost = TIMESTAMP - 86400*30;
			}
			foreach(C::t('forum_thread')->fetch_all_by_fid_authorid_displayorder($mygroupfid, $authorid, $displayorder, $lastpost, $start, $perpage) as $thread) {
				$groupthreadlist[$thread['tid']]['fid'] = $thread['fid'];
				$groupthreadlist[$thread['tid']]['subject'] = $thread['subject'];
				$groupthreadlist[$thread['tid']]['groupname'] = $mygrouplist[$thread['fid']]['name'];
				$groupthreadlist[$thread['tid']]['views'] =  $thread['views'];
				$groupthreadlist[$thread['tid']]['replies'] =  $thread['replies'];
				$groupthreadlist[$thread['tid']]['lastposter'] =  $thread['lastposter'];
				$groupthreadlist[$thread['tid']]['lastpost'] = dgmdate($thread['lastpost'], 'u');
				$groupthreadlist[$thread['tid']]['folder'] = 'common';
				if(empty($_G['cookie']['oldtopics']) || strpos($_G['cookie']['oldtopics'], 'D'.$thread['tid'].'D') === FALSE) {
					$groupthreadlist[$thread['tid']]['folder'] = 'new';
				}
			}
		}
	}
} 

?>

