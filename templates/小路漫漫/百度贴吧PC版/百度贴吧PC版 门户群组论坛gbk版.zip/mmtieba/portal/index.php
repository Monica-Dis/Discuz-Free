<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{subtemplate common/header}-->
<link href="$_G['style']['styleimgdir']/fn.css" rel="stylesheet" />
<style id="diy_style" type="text/css"></style>
<style>
.pzlist {overflow: hidden;margin-left: 12px; height:105px; }
.pzlist li {float: left;}
.pzlist li a {width: 69px;color: #666;font-size: 12px;height: 30px;line-height: 30px;display: inline-block; overflow:hidden;}

.box-hot {}
.box-hot .tab-bd {overflow: visible;}
.box-hot .tab-box {position: relative;}
.list li { overflow: hidden;position: relative;height: 15px;line-height: 14px; overflow: hidden;padding: 8px 0 9px;*padding: 7px 0; border-bottom: 1px dotted #DBDBDB;margin: 0; }
#hot-list {position: relative; z-index: 2; }
#hot-list li { padding: 8px 0 9px;  *padding: 7px 0;}
.num-top {  width: 12px;height: 11px;color: #fff; text-align: center;display: inline;float: left; font-size: 10px;line-height: 10px;background: #F23D7C; border: 1px solid #DD2464;}
.list .num-top, .list .num-normal {margin-right: 20px;}
.box-hot .num-top {background: #ED4138;border: 1px solid #db2b28;}
#hot-list .icon-rise, #hot-list .icon-fall, #hot-list .icon-fair {padding-right: 0;width: 60px;text-align:center}
.list .icon-search {margin-right: 10px;}
.list .num-top, .list .num-normal {margin-right: 20px;}
.num-normal {width: 12px;height: 11px; color: #fff;text-align: center;display: inline;float: left; font-size: 10px;line-height: 10px;background: #C0C1C3; border: 1px solid #ACAEB2;}
</style>
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>
	    <div class="wp sn-wrap">
          <div class="w-sider h420">
            <div class="sn-pad sn-pad-gdzy" id="lm03">
              <div class="tops">
                <h3 class="title"><a>���Ű��</a></h3>
                <div class="more"><a href="nav" title="ȫ�����" target="_blank">����>></a></div>
              </div>
              <div class="body" id="pub_col_1">
 		<!--[diy=xlmmbk]--><div id="xlmmbk" class="area"></div><!--[/diy]-->

             </div>
             </div>
            </div>
          </div>
  <div class="w-main h420">
	        <div class="w-main-half">
 		<!--[diy=xlmmc]--><div id="xlmmc" class="area"></div><!--[/diy]-->
   </div>
            <div class="w-main-r">
 <div class="pricebox">
<div class="tabright">
<ul class="hd">
<li class="on"><a>�ȵ���Ѷ</a></li>
<li><a href="forum.php?mod=guide&view=newthread" target="_blank">��������</a></li>
<li><a href="forum.php?mod=guide&view=new" target="_blank">���»ظ�</a></li>
</ul>
</div>
					<div class="bd">
					<div class="mglr">
		<!--[diy=xlmmr]--><div id="xlmmr" class="area"></div><!--[/diy]-->
</div>

</div>
</div>

    </div>
          </div>
  </div>
	    <div class="wp">
		<!--[diy=xlmmad1]--><div id="xlmmad1" class="area"></div><!--[/diy]-->
	<!--���Ի�ͨ�� ��ʼ-->
	<div class="contentLayout">
		<div class="gxhtl gxhtlBig sn-wrap">
		<!--[diy=xlmmkj1]--><div id="xlmmkj1" class="area"></div><!--[/diy]-->
<div class="contentLeft">
			<!--[diy=xlmmkj1tu]--><div id="xlmmkj1tu" class="area"></div><!--[/diy]-->
				</div>
<div class="contentLeft" style=" float:right">
			<!--[diy=xlmmkj2tu]--><div id="xlmmkj2tu" class="area"></div><!--[/diy]-->
				</div>
		</div>
		<div class="gxhtl sn-wrap" style="margin-right:0">
			<!--[diy=xlmmkj3tit]--><div id="xlmmkj3tit" class="area"></div><!--[/diy]-->
		<div class="contentLeft">
			<!--[diy=xlmmkj3tu]--><div id="xlmmkj3tu" class="area"></div><!--[/diy]-->
				</div>
			</div>
		</div>
			<!--[diy=xlmmad2]--><div id="xlmmad2" class="area"></div><!--[/diy]-->
	<div class="contentLayout">
		<div class="gxhtl">
			<!--[diy=xlmmkj4tit]--><div id="xlmmkj4tit" class="area"></div><!--[/diy]-->
				<div class="contentLeft">
			<!--[diy=xlmmkj4tu]--><div id="xlmmkj4tu" class="area"></div><!--[/diy]-->
			</div>
		</div>
		<div class="gxhtl">
			<!--[diy=xlmmkj5tit]--><div id="xlmmkj5tit" class="area"></div><!--[/diy]-->
				<div class="contentLeft">
			<!--[diy=xlmmkj5tu]--><div id="xlmmkj5tu" class="area"></div><!--[/diy]-->
			</div>
		</div>
		<div class="gxhtl" style="margin-right:0;">
			<!--[diy=xlmmkj6tit]--><div id="xlmmkj6tit" class="area"></div><!--[/diy]-->
<div class="apc">
<ul class="lis">
			<!--[diy=xlmmkj6tu]--><div id="xlmmkj6tu" class="area"></div><!--[/diy]-->
</ul>
</div>
		</div>
	</div>
	<!--Ƶ��ͨ��1 ����-->
	<!--[diy=xlmmyq]--><div id="xlmmyq" class="area"></div><!--[/diy]-->

</div>
		<script type="text/javascript">
					jQuery(".focusBox").slide({ titCell:".num li", mainCell:".pic",effect:"fold", autoPlay:true, interTime: 5000, delayTime: 1300,
						startFun:function(i){
							 jQuery(".focusBox .txt li").eq(i).animate({"bottom":0}).siblings().animate({"bottom":-36});
						}
					});
			</script>
	<!--[diy=xlmms1]--><div id="xlmms1" class="area"></div><!--[/diy]-->
<!--{subtemplate common/footer}-->

