<?PHP exit('Access Deniedxl');?>
<!--{template common/header}-->

	<style id="diy_style" type="text/css"></style>
<div id="xlmmbg">
<div class="wp">
<!--[diy=bg]--><div id="bg" class="area"></div><!--[/diy]-->
    <!--{if $action == 'create' || $action == 'manage' || $action == 'memberlist' || $action == 'invite'}-->
  	<div id="pt" class="bm cl">
		<div class="z">
			<a href="./" class="nvhm" title="{lang home}">$_G[setting][bbname]</a><em>&rsaquo;</em><a href="group.php">$_G[setting][navs][3][navname]</a><!--{if $groupnav}-->$groupnav<!--{elseif $action == 'create'}--><em>&rsaquo;</em>{lang group_create}<!--{/if}-->									<!--{if CURMODULE == 'group'}--><!--{hook/group_navlink}--><!--{else}--><!--{hook/forumdisplay_navlink}--><!--{/if}--><!--{if CURMODULE == 'group'}--><!--{hook/group_navlink}--><!--{else}--><!--{hook/forumdisplay_navlink}--><!--{/if}-->

		</div>
	</div>
  <!--{elseif $action == 'index' && $status != 2 && $status != 3}-->
  <!--{else}-->
<div class="contents" style="border:0"><div class="forum_header">    
<div class="plat_head plat_head_theme1">    
<div class="plat_banner j_platform_banner"><img class="plat_head_bg" src="<!--{if $_G[forum][banner] && !$subforumonly}-->$_G[forum][banner]<!--{else}-->template/mmtieba/image/banner.jpg<!--{/if}-->" alt="$_G['forum'][name]" width="998" style=" min-height:180px;"></div>
<div class="plat_header clearfix">           
<div class="z"><div class="plat_card_top"><a class="j_plat_picbox plat_picbox z" href="forum.php?mod=forumdisplay&fid=$_G[fid]" target="_self" alt="$_G['forum'][name]"><img src="<!--{if $_G[forum][icon]}-->$_G['forum']['icon']<!--{else}-->template/mmtieba/image/bimg.png<!--{/if}-->" height="150" width="150" alt="$_G['forum'][name]"></a><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="plat_title_h3 z" target="_self">$_G['forum'][name]</a>
<!--{if rssforumperm($_G['forum']) && $_G[setting][rssstatus] && !$_GET['archiveid'] && !$subforumonly}--><a class="plat_info_iconblue z"  href="forum.php?mod=rss&fid=$_G[fid]&auth=$rssauth" target="_blank" alt="����"><img src="static/image/common/feed.gif" title="����" width="18" height="18"></a><!--{/if}-->
 <!--{if $status != 2 && $status != 3 && $status != 5}--><!--{if helper_access::check_module('group') && $status != 'isgroupuser'}--><a class="newfocus_btn islike_newfocus z" href="forum.php?mod=group&action=join&fid=$_G[fid]"></a><!--{/if}--><!--{/if}--><!--{if $status == 'isgroupuser'}--><a onclick="showDialog('{lang group_exit_confirm}', 'confirm', '', function(){location.href='forum.php?mod=group&action=out&fid=$_G[fid]'})" href="javascript:;" class="newfocus_btn cancel_newfocus z"></a><!--{/if}-->
                <div class="plat_use_total">                
<span class="post_title" style="margin-left:20px;">��ע��</span><span class="j_post_num plat_post_num">$_G[forum][membernum]</span><span class="post_title">���ӣ�</span><span class="j_post_num plat_post_num">$_G[forum][threads]</span>
<!--{if !$subforumonly}--><span class="post_title"><!--{if $_G[forum][rank]}-->{lang rank}: <strong class="xi1" title="{lang previous_rank}:$_G[forum][oldrank]">$_G[forum][rank]</strong><!--{if $_G[forum][rank] <= $_G[forum][oldrank]}--><b class="ico_increase">&nbsp;</b><!--{else}--><b class="ico_fall">&nbsp;</b><!--{/if}--><!--{/if}--></span></div></div><!--{/if}-->
<div class="clear"></div>
<ul class="xlmmml"><li><!--{if $_G['forum']['description']}--><div style="font-size:14px; margin-right:20px;color: #4c4c4c;height:18px; max-width:220px; overflow:hidden; float:left">$_G['forum'][description]</div><!--{/if}--><span style="font-size:14px;color: #AAA;">λ��<!--{if $groupnav}-->$groupnav<!--{elseif $action == 'create'}--><em>&rsaquo;</em>{lang group_create}<!--{/if}-->
</span><!--{if $_G['forum']['ismoderator']}-->
						<!--{if $_G['forum']['recyclebin']}-->
							<span class="pipe">|</span><a href="{if $_G['adminid'] == 1}admin.php?mod=forum&action=recyclebin&frames=yes{elseif $_G['forum']['ismoderator']}forum.php?mod=modcp&action=recyclebin&fid=$_G[fid]{/if}" class="fa_bin" target="_blank">����վ</a>
						<!--{/if}-->
						<!--{if $_G['forum']['ismoderator'] && !$_GET['archiveid']}-->
							<span class="pipe">|</span><strong>
							<!--{if $_G['forum']['status'] != 3}-->
								<a href="forum.php?mod=modcp&fid=$_G[fid]">����</a>
							<!--{else}-->
								<a href="forum.php?mod=group&action=manage&fid=$_G[fid]">����</a>
							<!--{/if}-->
							</strong>
						<!--{/if}-->
						<!--{/if}-->	</li></ul></div>
<!--{if $_G['setting']['disfixednv_forumdisplay'] }-->
<!--{template common/qiandao}-->
 <!--{/if}-->      
 </div></div>    </div></div>    
		<!--[diy=vi1]--><div id="vi1" class="area"></div><!--[/diy]-->
<div class="star_nav_wrap star_nav_wrap_platform ">
<ul class="star_class_nav clearfix">
<!--{if !empty($_G['forum']['picstyle'])}-->
<li id="filter_special" class="star_nav_tab{if !empty($_G['cookie']['forumdefstyle'])}  newfocus{/if}"{if $filter==digest || $_GET[specialtype]==poll || $_GET[specialtype]==activity || $_GET[specialtype]==reward || $_GET[specialtype]==trade || $_GET[specialtype]==poll || $_GET[specialtype]==debate || $_GET[orderby]==heats}  style=" background:none;"{/if} onmouseover="showMenu(this.id)"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=yes" class="star_nav_ico kantie" hidefocus="true"><i class="icon"></i>����</a></div></div></li>
<li class="star_nav_tab{if empty($_G['cookie']['forumdefstyle'])} newfocus{/if}"{if $filter==digest || $_GET[specialtype]==poll || $_GET[specialtype]==activity || $_GET[specialtype]==reward || $_GET[specialtype]==trade || $_GET[specialtype]==poll || $_GET[specialtype]==debate || $_GET[orderby]==heats}  style=" background:none;"{/if}><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&forumdefstyle=no" class="star_nav_ico tupian" target="_blank" hidefocus="true"><i class="icon"></i>ͼƬ</a></div></div></li>
<!--{else}--><li id="filter_special" class="star_nav_tab{if $filter==digest || $_GET[specialtype]==poll || $_GET[specialtype]==activity || $_GET[specialtype]==reward || $_GET[specialtype]==trade || $_GET[specialtype]==poll || $_GET[specialtype]==debate || $_GET[orderby]==heats}{else} newfocus{/if}" onmouseover="showMenu(this.id)"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="star_nav_ico kantie"><i class="icon"></i>����</a></div></div></li><!--{/if}-->
<li class="star_nav_tab{if $filter==digest} newfocus{/if} "><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1" class="star_nav_ico jingpin" target="_blank"><i class="icon"></i>��Ʒ</a></div></div></li>
<!--{if $showactivity}--><li class="star_nav_tab{if $_GET[specialtype]==activity} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity" class="star_nav_ico huodon" target="_blank"><i class="icon"></i>�</a></div></div></li><!--{/if}-->
<!--{if $showreward}--><li class="star_nav_tab{if $_GET[specialtype]==reward} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward" class="star_nav_ico xuanshang" target="_blank"><i class="icon"></i>����</a></div></div></li><!--{/if}-->
<!--{if $showtrade}--><li class="star_nav_tab{if $_GET[specialtype]==trade} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade" class="star_nav_ico shangpin" target="_blank"><i class="icon"></i>��Ʒ</a></div></div></li><!--{/if}-->
<!--{if $showpoll}--><li class="star_nav_tab{if $_GET[specialtype]==poll} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll" class="star_nav_ico toupiao" target="_blank"><i class="icon"></i>ͶƱ</a></div></div></li><!--{/if}-->
<!--{if $showdebate}--><li class="star_nav_tab{if $_GET[specialtype]==debate} newfocus{/if}"><div class="star_nav_tab_inner"><div class="space"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate" class="star_nav_ico bianlun" target="_blank"><i class="icon"></i>����</a></div></div></li><!--{/if}-->
                        </ul>         
			        <!--{if $action != 'index' && ($status != 2 || $status != 3)}-->
				<div class="search_internal_wrap"><form method="post" action="search.php?mod=group&srchfid=$_G[fid]&searchsubmit=1" target="_blank">
<input name="srchtxt" type="text" id="keyword" class="search_internal_input"   placeholder="��������"><input class="search_internal_btn" type="submit"></form></div>      <!--{/if}-->                  
						</div></div>

 <!--{/if}-->      

	<!--{ad/text/wp a_t}-->

<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>

	     <div class="wp">
<div class="boardnav boardnavs">
	<div id="ct" class="wp cl ct2" style="width:759px; margin-left:0">
		<div class="mn">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<!--{if CURMODULE == 'group'}--><!--{hook/group_top}--><!--{else}--><!--{hook/forumdisplay_top}--><!--{/if}-->
						<!--{if CURMODULE == 'group'}--><!--{hook/group_nav_extra}--><!--{else}--><!--{hook/forumdisplay_nav_extra}--><!--{/if}-->
	<!--{if $livethread}-->
	<style type="text/css">
.listUser a {
    padding-left: 20px; margin-right:10px;
    background: url(template/mmtieba/image/icon_author.png) 0 0 no-repeat;
    color: #999;
}
</style>
	<div id="livethread" class="tl bm bmw cl" style="padding:10px 10px 10px 75px; position:relative;">
			<div class="livethreadtitle vm">
                <div class="live_reply">$livethread[replies]</div>
            
				<span class="replynumber xg1" style="display:none;">{lang reply} <span id="livereplies" class="xi1">$livethread[replies]</span></span>
				 <img src="$_G['style']['styleimgdir']/live.gif" style="margin-right:8px;" /><a href="forum.php?mod=viewthread&tid=$livethread[tid]" target="_blank">$livethread[subject]</a>
		<span class="listUser y">
				<a href="home.php?mod=space&uid=$livethread[authorid]" c="1" target="_blank">$livethread[author]</a>
				                    </span>
		</div>
			<div class="livethreadcon">$livemessage</div>
			<div id="livereplycontentout">
				<div id="livereplycontent">
				</div>
			</div>
			<div id="liverefresh">{lang group_live_newreply_refresh}</div>
			<div id="livefastreply">
				<form id="livereplypostform" method="post" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$livethread[tid]&replysubmit=yes&infloat=yes&handlekey=livereplypost&inajax=1" onsubmit="return livereplypostvalidate(this)">
					<div id="livefastcomment">
                        <textarea id="livereplymessage" name="message" style="color:gray; font-size:14px;<!--{if !$liveallowpostreply}-->display:none;<!--{/if}-->">��Ҳ˵һ��</textarea>
						<!--{if !$liveallowpostreply}-->
							<div style="margin:2px 0 0 10px;">
								<!--{if !$_G[uid]}-->
									���뱾�����ۣ����� <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)" class="xi2">��¼</a> | <a href="member.php?mod={$_G[setting][regname]}" class="xi2">ע��</a>
								<!--{else}-->
									{lang no_permission_to_post}<a href="javascript:;" onclick="ajaxpost('livereplypostform', 'livereplypostreturn', 'livereplypostreturn', 'onerror', $('livereplysubmit'));" class="xi2">{lang click_to_show_reason}</a>
								<!--{/if}-->
							</div>
						<!--{/if}-->
					</div>
					<div id="livepostsubmit" style="display:none;">
					<!--{if checkperm('seccode') && ($secqaacheck || $seccodecheck)}-->
						<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id)"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
						<div class="mtm sec" style="text-align:right;"><!--{subtemplate common/seccheck}--></div>
					<!--{/if}-->
					<p class="ptm pnpost" style="margin-bottom:10px;">
					<button type="submit" name="replysubmit" class="pn pnc vm" style="float:right;" value="replysubmit" id="livereplysubmit">
						<strong>{lang group_live_post}</strong>
					</button>
					</p>
					</div>
					<input type="hidden" name="formhash" value="{FORMHASH}">
					<input type="hidden" name="subject" value="  ">
				</form>
			</div>
			<span id="livereplypostreturn"></span>
		</div>
		<script type="text/javascript" src="{$_G['setting']['jspath']}seditor.js?{VERHASH}"></script>
		<script type="text/javascript">
			var postminchars = parseInt('$_G['setting']['minpostsize']');
			var postmaxchars = parseInt('$_G['setting']['maxpostsize']');
			var disablepostctrl = parseInt('{$_G['group']['disablepostctrl']}');
			var replycontentlist = new Array();
			var addreplylist = new Array();
			var timeoutid = timeid = movescrollid = waitescrollid = null;
			var replycontentnum = 0;
			getnewlivepostlist(1);
			timeid = setInterval(getnewlivepostlist, 5000);
			$('livereplycontent').style.width = ($('livereplycontentout').clientWidth - 50) + 'px';
			$('livereplymessage').onfocus = function() {
				if(this.style.color == 'gray') {
					this.value = '';
					this.style.color = 'black';
					$('livepostsubmit').style.display = 'block';
					this.style.height = '56px';
					$('livefastcomment').style.height = '57px';
				}
			};
			$('livereplymessage').onblur = function() {
				if(this.value == '') {
					this.style.color = 'gray';
					this.value = '��Ҳ˵һ��';
				}
			};

			$('liverefresh').onclick = function() {
				$('livereplycontent').style.position = 'absolute';
				getnewlivepostlist();
				this.style.display = 'none';
			};

			$('livereplycontentout').onmouseover = function(e) {

				if($('livereplycontent').style.position == 'absolute' && $('livereplycontent').clientHeight > 215) {
					$('livereplycontent').style.position = 'static';
					this.scrollTop = this.scrollHeight;
				}

				if(this.scrollTop + this.clientHeight != this.scrollHeight) {
					clearInterval(timeid);
					clearTimeout(timeoutid);
					clearInterval(movescrollid);
					timeid = timeoutid = movescrollid = null;

					if(waitescrollid == null) {
						waitescrollid = setTimeout(function() {
							$('liverefresh').style.display = 'block';
						}, 60000 * 10);
					}
				} else {
					clearTimeout(waitescrollid);
					waitescrollid = null;
				}
			};

			$('livereplycontentout').onmouseout = function(e) {

				if(this.scrollTop + this.clientHeight == this.scrollHeight) {
					$('livereplycontent').style.position = 'absolute';
					clearInterval(timeid);
					timeid = setInterval(getnewlivepostlist, 10000);
				}
			};

			function getnewlivepostlist(first) {
				var x = new Ajax('JSON');
				x.getJSON('forum.php?mod=misc&action=livelastpost&fid=$livethread[fid]', function(s, x) {
					var count = s.data.count;
					$('livereplies').innerHTML = count;
					var newpostlist = s.data.list;
					for(i in newpostlist) {
						var postid = i;
						var postcontent = '';
						postcontent += '<dt><a href="home.php?mod=space&uid=' + newpostlist[i].authorid + '" target="_blank">' + newpostlist[i].avatar + '</a></dt>';
						postcontent += '<dd><a href="home.php?mod=space&uid=' + newpostlist[i].authorid + '" target="_blank">' + newpostlist[i].author + '</a></dd>';
						postcontent += '<dd>' + newpostlist[i].message + '</dd>';
						postcontent += '<dd class="dateline">' + newpostlist[i].dateline + '</dd>';
						if(replycontentlist[postid]) {
							$('livereply_' + postid).innerHTML = postcontent;
							continue;
						}
						addreplylist[postid] = '<dl id="livereply_' + postid + '">' + postcontent + '</dl>';
					}
					if(first) {
						for(i in addreplylist) {
							replycontentlist[i] = addreplylist[i];
							replycontentnum++;
							var div = document.createElement('div');
							div.innerHTML = addreplylist[i];
							$('livereplycontent').appendChild(div);
							delete addreplylist[i];
						}
					} else {
						livecontentfacemove();
					}
				});
			}

			function livecontentfacemove() {
				//note �Ӷ�����ȡ������
				var reply = '';
				for(i in addreplylist) {
					reply = replycontentlist[i] = addreplylist[i];
					replycontentnum++;
					delete addreplylist[i];
					break;
				}
				if(reply) {
					var div = document.createElement('div');
					div.innerHTML = reply;
					var oldclientHeight = $('livereplycontent').clientHeight;
					$('livereplycontent').appendChild(div);
					$('livereplycontentout').style.overflowY = 'hidden';
					$('livereplycontent').style.bottom = oldclientHeight - $('livereplycontent').clientHeight + 'px';

					if(replycontentnum > 20) {
						$('livereplycontent').removeChild($('livereplycontent').firstChild);
						for(i in replycontentlist) {
							delete replycontentlist[i];
							break;
						}
						replycontentnum--;
					}

					if(!movescrollid) {
						movescrollid = setInterval(function() {
							if(parseInt($('livereplycontent').style.bottom) < 0) {
								$('livereplycontent').style.bottom =
									((parseInt($('livereplycontent').style.bottom) + 5) > 0 ? 0 : (parseInt($('livereplycontent').style.bottom) + 5)) + 'px';
							} else {
								$('livereplycontentout').style.overflowY = 'auto';
								clearInterval(movescrollid);
								movescrollid = null;
								timeoutid = setTimeout(livecontentfacemove, 1000);
							}
						}, 100);
					}
				}
			}

			function livereplypostvalidate(theform) {
				var s;
				if(theform.message.value == '' || $('livereplymessage').style.color == 'gray') {
					s = '{lang group_live_nocontent_error}';
				}
				if(s) {
					showError(s);
					doane();
					$('livereplysubmit').disabled = false;
					return false;
				}
				$('livereplysubmit').disabled = true;
				//theform.message.value = theform.message.value.replace(/([^>=\]"'\/]|^)((((https?|ftp):\/\/)|www\.)([\w\-]+\.)*[\w\-\u4e00-\u9fa5]+\.([\.a-zA-Z0-9]+|\u4E2D\u56FD|\u7F51\u7EDC|\u516C\u53F8)((\?|\/|:)+[\w\.\/=\?%\-&~`@':+!]*)+\.(jpg|gif|png|bmp))/ig, '$1[img]$2[/img]');
				theform.message.value = parseurl(theform.message.value);
				ajaxpost('livereplypostform', 'livereplypostreturn', 'livereplypostreturn', 'onerror', $('livereplysubmit'));
				return false;
			}

			function succeedhandle_livereplypost(url, msg, param) {
				$('livereplymessage').value = '';
				$('livereplycontent').style.position = 'absolute';
				if(param['sechash']) {
					updatesecqaa(param['sechash']);
					updateseccode(param['sechash']);
				}
				getnewlivepostlist();
			}
		</script>
	<!--{/if}--> 
			<!--{if $action == 'list'}-->
				<!--{subtemplate group/group_list}-->
			<!--{elseif $action == 'memberlist'}-->
				<!--{subtemplate group/group_memberlist}-->
			<!--{elseif $action == 'create'}-->
				<!--{subtemplate group/group_create}-->
			<!--{elseif $action == 'invite'}-->
				<!--{subtemplate group/group_invite}-->
			<!--{elseif $action == 'manage'}-->
				<!--{subtemplate group/group_manage}-->
			<!--{/if}-->
			<!--{if CURMODULE == 'group'}--><!--{hook/group_bottom}--><!--{else}--><!--{hook/forumdisplay_bottom}--><!--{/if}-->
			<!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->
		</div>
		<div class="sd">
 			<div class="drag">
				<!--[diy=diysidetop]--><div id="diysidetop" class="area"></div><!--[/diy]-->
			</div>
	    <!--{if $action == 'create' || $action == 'manage' || $action == 'memberlist' || $action == 'invite'}-->
			<!--{subtemplate group/group_right}-->


		</div>
	</div>
  <!--{elseif $action == 'index' && $status != 2 && $status != 3}-->
  <!--{else}-->
	<div id="side" class="side">
<div id="celebrity" class="region_bright celebrity"><div class="region_header"><div class="region_op j_op"> </div>
<div class="region_title region_icon j_title"></div></div>
<div class="region_cnt"><div class="intro"><div class="col2-left"><a class="gift-wrapper" href="javascript:"><span class="gift"><img src="template/mmtieba/image/huiyuan.png"></span>��Ա����</a></div>
<div class="col2-right"><ul class="privilege-list">
<li><i class="icon icon-red-thread-title"></i>������Ϣ���</li>
<li><i class="icon icon-red-name"></i>������ɫ����</li>
<li><i class="icon icon-sign-exp"></i>ǩ�����⾭��ֵ</li>
</ul></div></div>
<div class="more-privilege-container"><div class="first-show-container"><a href="{if $_G['uid']}javascript:;" onclick="showWindow('invite','misc.php?mod=invite&amp;action=group&amp;id=36'){else}member.php?mod=logging&amp;action=login" onclick="showWindow('login', this.href){/if}"><button class="purchase-member-btn">{if $_G['uid']}������Ѽ���{else}��¼�������{/if}</button></a></div></div>
<p class="gray-text">��ο��������ȼ����鿴<a href="home.php?mod=spacecp&ac=credit&op=rule" class="celebrity-purchase-exp" target="_blank">[���ֹ���]</a></p> </div>
<div class="region_footer"></div></div> 

 <!--{if !empty($_G['uid'])}-->
             {eval getuserprofile('posts');}
 <div class="region_bright balv_mod">
 <div class="region_header"><div class="region_op j_op"> </div>
<div class="region_title region_icon j_title">��������</div></div>
<div class="region_cnt">                
<div class="media_horizontal clearfix "><a class="media_left" href="home.php?mod=space&uid=$_G[uid]" target="_blank"><i class="head_img"><!--{avatar($_G[uid],middle)}--></i></a>
<div class="media_right"> 
  <div class="text_overflow">
<a href="home.php?mod=space&uid=$_G[uid]" target="_blank" style=" display:block">{echo cutstr($_G[member][username],10)}</a>
</div>            
<i class="icon_money" title="���"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a" title="���"><!--{echo dnumber($_G['member']['extcredits2'])}--></a>
<p class="orange_text" title="����"><i class="icon_credits"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a">$_G[member][credits]</a></p>
<p><a href="home.php?mod=spacecp&ac=usergroup">[��Ա�ȼ�{$_G[group][stars]}]</a></p>
</div></div></div>
<div class="region_footer"></div></div>
<!--{/if}-->

<div class="offical_schedule_wrap region_bright star_platform_aside_module">
<div class="trip_title"><h1 class="titles">�����</h1><span class="all_trip_link"><a href="/" target="_blank" class="j_all_trip_link">�鿴����&gt;&gt;</a></span></div>
				<!--[diy=r1]--><div id="r1" class="area"></div><!--[/diy]-->
</div>


<div id="encourage_entry" class="my_app encourage_entry region_bright " style="padding: 12px 10px 0 20px;">
<div class="my_app_title"><span class="region_title">�����Ȱ�</span><i class="encourage_entry_icon_new"></i></div>
				<!--[diy=r2]--><div id="r2" class="area"></div><!--[/diy]-->
</div>


<div class="region_bright related_forums"><div class="region_header"><div class="region_op j_op"><a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]#groupnav" target="_blank" >�鿴����&gt;&gt;</a></div>
<div class="region_title region_icon j_title">�������</div></div>
<div class="region_cnt">
<div class="star_related">
                            <!--{eval $i = 1;}--><!--{loop $groupmanagers $manage}--><!--{if $i <= 0}--><!--{/if}--><!--{eval $i--;}--><a href="home.php?mod=space&uid=$manage[uid]" target="_blank">$manage[username]</a><!--{/loop}-->
</div> </div>
<div class="region_footer"></div></div>
 <div id="zyq" class="zyq_bright"><div class="mod"><div class="tl"><div class="mod_edit_wrap"></div>
 <div class="zyq_mod_icon zyq_mod_title"><span class="j_mod_tit">��Ҫ����</span></div></div>
 <div class="cnt">
				<!--[diy=r3]--><div id="r3" class="area"></div><!--[/diy]-->
 </div>
 </div>


 <div class="mod"><div class="tl"><div class="mod_edit_wrap"></div><span class="zyq_mod_title">��Ա����</span></div>
				<!--[diy=r4]--><div id="r4" class="area"></div><!--[/diy]-->
 </div></div>
 
			<div class="drag">
				<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
			</div>
		</div>
	</div>
</div>
			<!--{if CURMODULE == 'group'}--><!--{hook/group_side_bottom}--><!--{else}--><!--{hook/forumdisplay_side_bottom}--><!--{/if}-->
			<!--{/if}-->
	</div>
    <!--{if $action == 'create' || $action == 'manage' || $action == 'memberlist' || $action == 'invite'}-->
			<!--{else}-->
<div class="wp fastbg">
				<!--{template forum/forumdisplay_fastpost}-->
			<!--{/if}-->
<div class="wp mtn">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->

<!--{template common/footer}-->

