<?PHP exit('Access Deniedxl');?>
<!--{subtemplate common/header}-->
					{eval include TPLDIR.'/php/forum_guide.php';}
			{eval include TPLDIR.'/php/video.php';}
			<!--{hook/index_header}-->
			<!--{hook/index_top}-->

	<style id="diy_style" type="text/css"></style>
<link rel="stylesheet" href="$_G['style']['styleimgdir']/tb1.css" />
	 <script src="template/mmtieba/image/js/fu.js" type="text/javascript"></script>
<script src="template/mmtieba/jquery.ias.min.js" type="text/javascript"></script>
<div class="wp">
    		<!--[diy=xlmmad1]--><div id="xlmmad1" class="area"></div><!--[/diy]-->
          <!--pa-->  
<div class="top-sec clearfix">
<div class="pal">
<div class="slideshow_container">
           <div class="sdsh">
 		<!--[diy=xlmms1]--><div id="xlmms1" class="area"></div><!--[/diy]-->
   </div>
    <div class="top_progress_bar cl">
        <span class="prev"></span>
        <ul>
        <li class="on"></li></ul>
        <span class="next"></span>
    </div></div>
</div>
<div class="par rec_login">
<div class="num_list"> <i class="nl">����</i> <span class="numbertz" ></span> <i class="nr">����</i>
</div>
 <!--{if !$_G['uid']}--><a href="member.php?mod=logging&action=login" class="btn_login"></a><!--{/if}-->
</div>
<div class="clear"></div>
          <!--pb-->  
<div class="mt10"></div>
    		<!--[diy=xlmmad2]--><div id="xlmmad2" class="area"></div><!--[/diy]-->
<div class="xlmmc"><div class="pabl xlmmb" id="pid0">
 	<div id="favatar0" >				<!--{if $_G['uid']}-->
  <div class="region_bright my_tieba_mod">
   <h4 class="region_header clearfix"> 
          ��������<span class="pull_right"> 
          </span></h4>
          <div class="region_cnt clearfix">
             {eval	
$postss = getuserprofile('posts');
}
                      <div class="media_horizontal clearfix ">
                          <a class="media_left" href="home.php?mod=space&uid=$_G[uid]" target="_blank"><em class="head_img"><!--{avatar($_G[uid],middle)}--></em></a>
<div class="media_right"> 
  <div class="text_overflow">
<a href="home.php?mod=space&uid=$_G[uid]" target="_blank" style=" display:block">{echo cutstr($_G[member][username],10)}</a>
</div>            
<i class="icon_money"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a"><!--{echo dnumber($_G['member']['extcredits2'])}--></a>
<p class="orange_text"><i class="icon_credits"></i><a href="home.php?mod=spacecp&ac=credit" target="_blank" style="color:#f8984a">$_G[member][credits]</a></p>
<p><a href="home.php?mod=spacecp&ac=credit&op=rule">[���ֹ���]</a></p>
</div> </div>  </div>  </div>   
      <div class="clear"></div>
     <div class="u-f-t">
     <div class="titles">����İ�</div>
                     <a href="home.php?mod=space&do=favorite&type=forum" target="_blank"><div class="edit color2"></div></a>
 <!--{if $_G['setting']['disfixednv_forumindex'] }-->
{if $_G['cache']['plugin']['dsu_paulsign']['ifopen']}
{eval  $time = DB::fetch_all("SELECT value as time FROM ".DB::table('common_pluginvar')." WHERE `variable`='timeopen' or `variable`='stime' or `variable`='ftime'");$open = $time[1][time];$a = date('Y-m-d ',time());$b ="0:0";$stime = strtotime($a.$time[0][time].":".$b);$ftime = strtotime($a.$time[2][time].":".$b);$time = strtotime(date('Y-m-d',time()));
$count = DB::fetch_all("SELECT COUNT(*) as dd FROM ".DB::table('dsu_paulsign')." WHERE time >= $time AND `uid` =".$_G[uid]."");$count[0][dd]}
<a  {if $count[0][dd] ==0}onclick="showWindow('dsu_paulsign', 'plugin.php?id=dsu_paulsign:sign')" href="javascript:" {else}href="plugin.php?id=dsu_paulsign:sign" target="_blank"{/if}  class="onekey_btn y"></a>{/if}<!--{/if}-->
</div>
<div class="u-f-w">
<div id="likeforumwraper" class="clearfix">
                                        <!--{eval $myjoin=DB::fetch_all("SELECT * FROM  ".DB::table('forum_groupuser')." p left join ".DB::table("forum_forum")." f on f.fid=p.fid WHERE  p.`uid`=".$_G[uid]." and f.`type`='sub' ");}--> 
           <!--{eval $li=0;}-->
                               <!--{loop $myjoin $key $xlmm}-->
<a href="forum.php?mod=forumdisplay&fid={$xlmm[fid]}"   class="u-f-item unsign" target="_blank"><i>{$xlmm[name]}</i><span class="forum_level"></span></a>
         <!--{eval $li++}-->
<!--{eval if($li==8) break;}-->                               <!--{/loop}-->
</div>
<div class="more-wraper" style="display:block"><a href="group.php?mod=my&view=manager" class="more"><span class="more-txt">�鿴����</span><span class="more-triangle"></span></a>
</div>
</div>
<!--{/if}-->
<div class="u-f-t ufw-gap">
<div class="titles">���ɷ���</div>
<div class="gap y" style="width:120px; margin-top:10px;"></div>
</div>
<div class="f-d-w">

									<!--{eval $k = 1;}-->
                      					<!--{loop $first $groupid $group}-->

<div class="f-d-item fb{$k} mainCate"><div class="f-d-item-content">
<div class="titles"><span class="typeicon forum{$k}"></span><a href="group.php?gid=$groupid">$group[name]</a>
</div>

<div class="directory-wraper">
<!--{loop $group['secondlist'] $fid}--><a href="group.php?sgid=$fid" target="_blank">$second[$fid][name]</a> 
<!--{/loop}-->
</div></div>
	<div class="subCate " style=" margin-left:200px; margin-top:-79px; position:absolute; width:666px; height:auto;">
<div class="pop-up-container"><div class="directory-pop-frame"><div class="d-title "><a href="group.php?gid=$groupid" target="_blank">$group[name]</a></div>
<div>
<!--{loop $group['secondlist'] $fid}--><a href="group.php?sgid=$fid" target="_blank" class="notabs" style="border:0; font-size:14px;">$second[$fid][name]</a> 
<!--{/loop}--></div>
<div class="rec-forum">
<div class="rec-icon">�Ƽ���</div>
	           <!--{loop $lastupdategroup[$groupid] $val}-->      
										   <a href="forum.php?mod=group&fid=$val[fid]" target="_blank"  class="notabs">$val[name]</a>
									<!--{/loop}-->
	</div></div></div></div>						</div>

									<!--{eval $k ++;}-->
<!--{/loop}-->

<div class="all-wraper"><a href="forum.php?mod=group&amp;action=create&amp;fupid=3&amp;groupid=0" target="_blank" class="all"><span class="more-txt">��������</span></a>
</div>
<div class="clear"></div>
</div>
</div>
</div>
<div class="pabr">
<div class="">
  		<!--[diy=xlmmq]--><div id="xlmmq" class="area"></div><!--[/diy]-->
</div>

<div class="clear" style="margin-top:20px;"></div>
<div class="r-left-sec pablbox">
<div class="spage_liveshow_slide clearfix">
<div class="slide_outer_wrap game_slide_wrap">
<a class="titlesss j_slide_title_yy" href="/" target="_blank">���ֶһ�</a>
 		<!--[diy=xlmmsx]--><div id="xlmmsx" class="area"></div><!--[/diy]-->
</div>
<div class="slide_outer_wrap">
<a class="titlesss" href="/" target="_blank">�����Ƽ�</a>
 		<!--[diy=xlmms4]--><div id="xlmms4" class="area"></div><!--[/diy]-->
</div></div>
<div class="clear"></div>

<div class="platact_bigouter">
<div class="hdshow">
 		<!--[diy=xlmms5]--><div id="xlmms5" class="area"></div><!--[/diy]-->
			  </div>
	 </div>


       <div class="forum_sub slideTxtBox">
                              
							  <div class="tag_nav_more"><a href="forum.php?mod=guide" target="_blank">�������>></a></div>
<div class="tag_nav cl">
					<ul class="hd">
<li class="on"><span><a>���ɶ�̬</a></span></li>
</ul>
                             </div>
     <script type="text/javascript">zoomstatus = parseInt(1);var imagemaxwidth = '600';var aimgcount = new Array();</script>
			<style>
.zoominner p {padding: 8px 0; color:#fff;}	
.zoominner p a.imgclose:hover {background-position: -80px -39px;}
.zoominner p a.imgadjust {background-position: -40px 0; display:none;}
.zoominner p a.imgclose {background-position: -80px 0;}
.zoominner p a:hover {background-position: 0 -39px;}
.zoominner p a {float: left;margin-left: 10px;width: 17px;height: 17px;background: url(static/image/common/imgzoom_tb.gif) no-repeat 0 0;line-height: 100px;overflow: hidden;}
.zoominner {padding: 5px 10px 10px;background: #FFF;text-align: left;}	

.tagbg {height: 16px;line-height: 16px;*line-height: 18px;display: inline-block;padding: 0 0 0 5px;margin-right: 5px;*display: inline;float: left;margin-top: 1px;}
.tag-img {background: #f2934a;}
.tag-video {background: #cc6ee3;}
.tag-audio {background: #74c587;}
.tag_nav_1 .fn a.tag-name {display: inline-block;text-decoration: none;color: #fff;margin-right: 2px;line-height: 16px; font-size:12px;font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;}
.triangle {display: inline-block;width: 0; height: 0;overflow: hidden;line-height: 0;  font-size: 0;border-width: 4px 4px 4px 0;border-color: transparent #fff transparent transparent; border-style: dashed solid dashed none;_margin-top: 4px;}
.tag_nav_1 .thtit a .xlmmxhx:hover { text-decoration:underline;}
	</style>
		<div class="tag_nav_1 bd">

    <!--{eval $page=$_G['page'];}-->
	        	                        <ul id="alist">
									        	<!--{loop $grids['newthread'] $thread}-->
  											<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
												<!--{eval $thread[tid]=$thread[closed];}-->
										<!--{/if}-->
		{eval include TPLDIR.'/php/forum.php';}
{eval $xlmmmedia=xlmmthread('media',$thread[message],1);$xlmmflash=xlmmthread('flash',$thread[message],1); $xlmmaudio=xlmmthread('audio',$thread[message],1);
                $xlmmbio = DB::fetch_all("SELECT name FROM  ".DB::table('forum_forum')." WHERE `fid` = $thread[fid]");}

				<li class="xlmmlists">
<p class="fn">	
{if $xlmmaudio}<span class="tagbg tag-audio"><a href="javascript:;" class="tag-name">������</a><a href="javascript:;" class="triangle"></a></span>{elseif $xlmmflash || $xlmmmedia}<span class="tagbg tag-video"><a href="javascript:;" class="tag-name">��Ƶ��</a><a href="javascript:;" class="triangle"></a></span>{elseif $fpic}<span class="tagbg tag-img"><a href="javascript:;" class="tag-name">ͼƬ��</a><a href="javascript:;" class="triangle"></a></span>{/if}
<a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank">{loop $xlmmbio $key $xlmmbio} $xlmmbio[name] {/loop}</a></p>
<p class="thtit">
<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" target="_blank" style="text-decoration:none;"><!--{if $thread[folder] == 'lock'}-->
											<img src="$_G['style']['styleimgdir']/folder_lock.gif" align="absmiddle" style="margin-right:5px;" />
										<!--{elseif $thread['special'] == 1}-->
											<img src="$_G['style']['styleimgdir']/pollsmall.gif" align="absmiddle" alt="{lang thread_poll}" style="margin-right:5px;" />
										<!--{elseif $thread['special'] == 2}-->
											<img src="$_G['style']['styleimgdir']/tradesmall.gif" align="absmiddle" alt="{lang thread_trade}" style="margin-right:5px;" />
										<!--{elseif $thread['special'] == 3}-->
											<img src="$_G['style']['styleimgdir']/rewardsmall.gif" align="absmiddle" alt="{lang thread_reward}" style="margin-right:5px;" />
										<!--{elseif $thread['special'] == 5}-->
											<img src="$_G['style']['styleimgdir']/debatesmall.gif" alt="{lang thread_debate}" style="margin-right:5px;" />
										<!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
<img src="$_G['style']['styleimgdir']/pin.gif" align="absmiddle" title="$_G[setting][threadsticky][3-$thread[displayorder]]" style="margin-right:5px;"  />
										<!--{/if}-->
																				<!--{if $thread['digest']}-->
											<img src="$_G['style']['styleimgdir']/digest.gif" align="absmiddle" title="{lang thread_digest} $thread[digest]" style="margin-right:5px;"  />
										<!--{/if}--><em class="xlmmxhx">$thread[subject]</em></a>
<span class="list-post-num"><em>$thread[views]</em><span class="list-triangle-border"></span><span class="list-triangle-body"></span></span>
</p>
		<p class="thsum">$xiaolu['fmessage']</p>
<!--{if $xlmmflash || $xlmmmedia || $xlmmaudio}-->                                                                    
          <ul style="height: auto; overflow: hidden;">
{if $xlmmaudio}
                {loop $xlmmaudio $audio}
                      <li style="height: 135px; width:250px; overflow: hidden;background:#000000"><embed src="$audio" width="250" height="135"  wmode="transparent"/></li>
                 {/loop}

{elseif $xlmmmedia}
                {loop $xlmmmedia $media}
                      <li style="height: 135px; width:240px; overflow: hidden;background:#000000"><embed src="$media" width="240" height="135"  wmode="transparent"/></li>
                 {/loop}
                 {elseif $xlmmflash}
                      {loop $xlmmflash $flash}
                      <li style="height: 135px; width:240px; overflow: hidden;background:#000000"><embed src="{$flash}" width="240" height="135"  wmode="transparent"></li>
                      {/loop}
                  {/if}
              </ul>
<!--{elseif $xlmmattach}-->
                  <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" target="_blank">  <p class="n_img">  
   <!--{eval $i=0;}-->
<!--{loop $xlmmattach $attach}-->
   					<!--{if $attach['aid']}-->			
					{eval $xlmmimg = (getforumimg($attach['aid'],0,150,150));}
														<!--{else}-->
								{eval $xlmmimg = 'template/mmtieba/php/small.php?filename=' . $attach['attachment'] . '&width=150&height=150'; }
		<!--{/if}-->
<div style=" width:150px;height: 105px; overflow: hidden; float:left;margin-right: 11px;
_margin-right: 7px;"><img src="$xlmmimg"></div>
 <!--{eval $i++}-->
<!--{eval if($i==3) break;}-->
<!--{/loop}--> 
</p></a> 
<div class="clear"></div>
										<!--{/if}-->
<p class="thutss"><span class="s1"><i>��󷢱���</i><a href="{if $thread[digest] != -2 && !$thread[ordertype]}forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost$highlight#lastpost{else}forum.php?mod=viewthread&tid=$thread[tid]{if !$thread[ordertype]}&page={echo max(1, $thread[pages]);}{/if}{/if}" target="_blank">$thread[lastposter]</a></span><span class="s2"><i>�����ڣ�</i>$thread[lastpost]</span></p>
</li>
							<!--{/loop}-->
</ul>
<div id="xlmmpg" style="display:none">$multi</div>


                     </div>

                            </div>
                      </div>
              
              
<div class="r-right-sec allboxs">
<div id="rlboxs">
<!--{hook/index_side_top}-->
<!--{hook/index_side_bottom}-->
<div class="right_wrap">
<div class="media_item">
 <div class="member_rank_title">
 <span class="titles">��������</span>
            <a class="verify_link" target="_blank" href="/">�鿴����</a>
 </div>
		   <div class="slide_scroll">
 		<!--[diy=xlmms6]--><div id="xlmms6" class="area"></div><!--[/diy]-->
</div></div>
<div> 

<div class="hyshow">
 <div class="member_rank_title">
 <div class="rank_progress_bar">
 <span class="turn_pre"></span>
 <ul class="page_turn">
 <li class="turn_icon_on"></li><li></li></ul>
 <span class="turn_next"></span></div>
 <span class="titles">���Ѿ��ֲ�</span>
 </div>
 <div class="member_rank_group">
 		<!--[diy=xlmms7]--><div id="xlmms7" class="area"></div><!--[/diy]-->
</div></div>
</div>
  </div>

<div class="item media_item">
  <div class="member_rank_title">
            <span class="titles">ý��ר��</span>
            <a class="verify_link" target="_blank" href="/">������פ</a>

  </div>
 		<!--[diy=xlmmmt]--><div id="xlmmmt" class="area"></div><!--[/diy]-->
</div> 

<div class="item notices_item">
   <div class="member_rank_title">
     	<span class="titles">�����</span>
  </div>
 		<!--[diy=xlmmgg]--><div id="xlmmgg" class="area"></div><!--[/diy]-->
</div>

			<style>
.ssfires{position:fixed;top:-20px;_position:absolute!important;_top:expression(eval(document.documentElement.scrollTop)); overflow:hidden;  }

.topic_list {padding: 0 16px 10px;}
.topic_list .topic_item {padding: 5px 0;color: #666;cursor: pointer;}
.topic_list .topic_item .topic_flag_hot {background: #FF7F42;color: #FFF;padding: 1px 4px;margin-right: 7px;}
.topic_list .topic_item .topic_name {white-space: nowrap;text-overflow: ellipsis;-o-text-overflow: ellipsis;overflow: hidden;display: inline-block;width: 60%;vertical-align: middle;color: #666;}
.topic_list .topic_item .topic_num {color: #999;float: right;}
.topic_list .topic_item .topic_flag {display: inline-block;text-align: right;width: 14px;padding: 1px 4px;position: relative;right: 7px;}
	</style>
<div class="item platform_item" id="fss">
<div class="member_rank_title"><span class="titles">Ʒ�ƽ�פ</span><a href="/" target="_blank" class="verify_link">��ҵ��פ</a></div>
 		<!--[diy=xlmmpp]--><div id="xlmmpp" class="area"></div><!--[/diy]-->
</div>
</div></div></div></div><div class="bottom-bg">&nbsp; </div></div></div>
   				<div id="_postposition0"></div>
 		<!--[diy=xlmmyq]--><div id="xlmmyq" class="area"></div><!--[/diy]-->
			<!--{hook/index_bottom}-->
</div>
<script src="template/mmtieba/image/js/forum.js" type="text/javascript"></script>
<script type="text/javascript">

var ias = jQuery.ias({
   container: "#alist", 
        item: ".xlmmlists", 
        pagination: ".pg", 
        next: ".pg a.nxt", 
    });
    ias.extension(new IASTriggerExtension({
        text: '<div class="ias-spinner" style="text-align: center;line-height:40px;color: #999;">������ظ���</div>', 
        offset: false, 
    }));
    ias.extension(new IASSpinnerExtension({
	html: '<div class="ias-spinner" style="text-align: center;line-height:40px;color: #999;"><img src="static/image/common/loading.gif" width="16" height="16" class="vm" /> ������...</div>',
}));
    ias.extension(new IASNoneLeftExtension({
        text: '<div style=" text-align:center; line-height:40px;color: #999;">û�и�����</div>', 
    }));
</script>
		<script type="text/javascript">
(function($) {$(function(){
  var numRun = $(".numbertz").numberAnimate({num:'$groupnum', speed:1500});
});
})(jQuery);
jQuery(".slideshow_container").slide({titCell:".top_progress_bar ul",mainCell:".ulists ul",autoPage:true,effect:"left",autoPlay:true,scroll:1,vis:1,easing:"easeOutCirc",delayTime:1000,autoPage:"<li><a></a></li>",interTime:5000,trigger:"click"});	

		jQuery(".f-d-w").slide({ 
				type:"menu", //Ч������
				titCell:".mainCate", // ��괥������
				targetCell:".subCate", // Ч�����󣬱��뱻titCell����
				delayTime:0, // Ч��ʱ��
				triggerTime:0, //����ӳٴ���ʱ��
				defaultPlay:false,//Ĭ��ִ��
				returnDefault:true//����Ĭ��
			});
fixed_avatar([0]);
jQuery(".good_forum_list").slide({ mainCell:".gr_f_list", effect:"leftLoop",vis:4, autoPlay:true, interTime:3000,prevCell: ".good_rcmd_left", nextCell: ".good_rcmd_right" });

jQuery(".slide_inner_wrap").slide({titCell:"ul.game_nav",mainCell:".liveshow ul",autoPage:true,effect:"left",autoPlay:true,easing:"easeOutCirc",delayTime:1000,autoPage:"<li><a></a></li>",interTime:5000,titOnClassName:"turn_icon_cur",trigger:"click"});			

jQuery(".hdshow").slide({titCell:".rank_progress_bar ul",mainCell:".platact_outer ul",autoPage:true,effect:"fold",autoPlay:true,scroll:1,vis:1,easing:"easeOutCirc",delayTime:1000,prevCell: ".turn_pre", nextCell: ".turn_next" ,autoPage:"<li><a></a></li>",interTime:7000,titOnClassName:"turn_icon_on",trigger:"click"});			

jQuery(".slideTxtBox").slide({trigger:"click",easing:"easeInQuint"});
				
				
jQuery(".hyshow").slide({titCell:".rank_progress_bar ul",mainCell:".member_rank_group ul",autoPage:true,effect:"fold",autoPlay:false,scroll:1,vis:1,easing:"easeOutCirc",delayTime:1000,prevCell: ".turn_pre", nextCell: ".turn_next" ,autoPage:"<li><a></a></li>",titOnClassName:"turn_icon_on",trigger:"click"});			
				
(function($){$(function () {

    var bartop = $('#fss').offset().top,
        h2_con=$('#fss').find("h2 a").text();
    function changeBar(){
        var st = $(window).scrollTop();
        if( st > bartop){
            $('#fss').addClass('ssfires');
        }else{
            $('#fss').removeClass('ssfires');
        }
    }
    $(window).scroll( function(){
        changeBar();
    })

})
})(jQuery)
</script>
			<!--{if $topgrouplist}-->
<div id="ghot-more_menu" class="t-more_menu" style="display:none;">
<div class="p_pop nav_pop" style="border:0; box-shadow: 0px 0px 0px">
							<ul>
							<!--{loop $topgrouplist $fid $group}-->
							<li><a href="forum.php?mod=group&fid=$group[fid]" title="$group[name]">$group[name]</a></li>
							<!--{/loop}-->
							</ul>
</div>
</div>
			<!--{/if}-->

<!--{subtemplate common/footer}-->

