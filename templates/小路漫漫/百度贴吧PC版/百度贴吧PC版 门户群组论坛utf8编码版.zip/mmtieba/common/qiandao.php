<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
	{eval include TPLDIR.'/php/qian.php';}
{eval $count = DB::fetch_all("SELECT COUNT(*) as dd FROM ".DB::table('dsu_paulsign')." WHERE time >= $time AND `uid` =".$_G[uid]."");$count[0][dd]}<div class="y card_top_right"><a {if $count[0][dd] ==0}onclick="showWindow('dsu_paulsign', 'plugin.php?id=dsu_paulsign:sign')" {/if}title="{if $open ==0}
{if $count[0][dd] ==0}签到{else}签到完成{/if}{else}
{eval $count = DB::fetch_all("SELECT COUNT(*) as dd FROM ".DB::table('dsu_paulsign')." WHERE `uid` =".$_G[uid]." AND time < $ftime AND time > $stime")}
{eval $count[0][dd]}
{if $count[0][dd] ==0}签到{else}签到完成了{/if}
{/if}
" class="sign_box_bright {if $open ==0}{eval $count = DB::fetch_all("SELECT COUNT(*) as dd FROM ".DB::table('dsu_paulsign')." WHERE time >= $time AND `uid` =".$_G[uid]."");$count[0][dd]}
{if $count[0][dd] ==0}{else}sign_box_bright_signed{/if}{else}
{eval $count = DB::fetch_all("SELECT COUNT(*) as dd FROM ".DB::table('dsu_paulsign')." WHERE `uid` =".$_G[uid]." AND time < $ftime AND time > $stime")}
{eval $count[0][dd]}
{if $count[0][dd] ==0}{else}sign_box_bright_signed{/if}
{/if}" {if $count[0][dd] ==0}href="javascript:"{else}href="plugin.php?id=dsu_paulsign:sign" target="_blank"{/if} ><span class="sign_today_date"><script>
var enabled = 0; today = new Date();
date = + (today.getMonth() + 1 ) + "月" + today.getDate() + "日" ;
document.write(date);
</script></span><span class="sign_month_lack_days">已签<span class="">{loop $total $key $total} $total[todayq] {/loop}</span>人</span>{if $count[0][dd] ==0}{else}<span class="sign_keep_span">连续{loop $qiandao $key $qiandao} $qiandao[lasted] {/loop}天</span>{/if}</a></div>





