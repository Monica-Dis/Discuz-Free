
/* xlmm QQ2374198406 */




 jQuery(function(e) {

	function t(t) {
		return this.each(function() {
			var i = e(this),
				o = i.data("bz.sticky"),
				r = "object" == typeof t && t;
			o || i.data("bz.sticky", o = new n(this, r)), "string" == typeof t && o[t] && o[t]()
		})
	}
	var n = function(t, i) {
			this.options = e.extend({}, n.DEFAULT, i), this.jQueryelem = e(t), this.jQuerywindow = e(window), this.jQuerydoc = e(document), this.isSticked = this.bottomSticked = !1, this.init()
		};
	n.prototype.init = function() {
		var t = this.options.header,
			n = this.options.bottom;
		n && (this.bottomHeight = this.getHeight(e(n)), this.hasBottomLimit = !0, this.headerHeight = t ? this.getHeight(e(t)) : 0), this.jQuerywindow.on("scroll.bz.sticky", e.proxy(this.checkPosition, this)), this.checkPosition()
	},
	n.prototype.getHeight = function(e) {
		return e.outerHeight() + parseInt(e.css("margin-top"), 10) + parseInt(e.css("margin-bottom"), 10)
	},
	n.prototype.checkPosition = function() {
		this.elemHeight = this.jQueryelem.outerHeight() + this.options.addition;
		var t = this.jQuerywindow.scrollTop(),
			n = e(document).height(),
			i = this.options.offset.top,
			o = this.options.delegate;
		if (o && (i = e(o).offset().top), (!this.hasBottomLimit || !this.isTouchingBottom(i, n)) && (i - this.options.addition >= t ? this.isSticked && this.unstick() : this.isSticked || this.bottomSticked || this.stick(), this.hasBottomLimit)) {
			var r = n - t - this.bottomHeight;
			if (this.bottomSticked)!this.isSticked && r >= this.elemHeight && (this.stick(), this.bottomSticked = !1, this.jQueryelem.removeClass("absolute").removeAttr("style"));
			else if (this.isSticked && r <= this.elemHeight) {
				this.unstick();
				var s = n - this.bottomHeight - this.elemHeight;
				this.bottomSticked = !0, this.jQueryelem.addClass("absolute").css("top", s - this.headerHeight + this.options.addition)
			}
		}
	},
	n.prototype.isTouchingBottom = function(e, t) {
		return this.elemHeight + e + this.bottomHeight >= t
	},
	n.prototype.stick = function() {
		var t = e.Event("sticked.bz.sticky");
		this.jQueryelem.addClass("sticky"), this.isSticked = !0, this.jQueryelem.trigger(t)
	},
	n.prototype.unstick = function() {
		var t = e.Event("stick.bz.sticky");
		this.jQueryelem.removeClass("sticky"), this.isSticked = !1, this.jQueryelem.trigger(t)
	},
	n.DEFAULT = {
		bottom: null,
		header: null,
		delegate: null,
		addition: 0,
		offset: {
			top: 0
		},
		version: "beta"
	},
	e.fn.sticky = t, e(window).on("load", function() {
		e("[data-sticky]").each(function() {
			var n = e(this),
				i = Number(n.data("sticky") || 0),
				o = n.data("delegate"),
				r = n.offset().top,
				s = n.data("header"),
				a = n.data("bottom");
			t.call(n, {
				bottom: a,
				header: s,
				delegate: o,
				addition: i,
				offset: {
					top: r
				}
			})
		})
		
	})
		})


