var xlmm_pic_setting={};
xlmm_pic_setting.pich='2000';
xlmm_pic_setting.picw='500';
xlmm_pic_setting.picph='90';
xlmm_pic_setting.picsw='200';

if(typeof xlmm_pic_setting != 'object'){
	xlmm_pic_setting = xlmm_pic_setting_def;
}
for(var xlmm_pic_setting_i in xlmm_pic_setting){
	xlmm_pic_setting[xlmm_pic_setting_i] = parseInt(xlmm_pic_setting[xlmm_pic_setting_i], 10);
	if(isNaN(xlmm_pic_setting[xlmm_pic_setting_i])){
		xlmm_pic_setting[xlmm_pic_setting_i] = xlmm_pic_setting_def[xlmm_pic_setting_i];
	}
}


(function($) {
    $(document).ready(function($) {
        $('body').on('click', '.toPrev', function(e) {
            e.preventDefault();
            //判断toPrev所在区域是图片而非音频等其他内容
            if ($(this).parent().find('img').length > 0) {
                //读取当前图片的src值和id值
                console.log($(this));
                var $currentImg = $(this).parent().find('img');
                var currentImgSrc = $currentImg.prop('src');
                var currentImgId = $currentImg.prop('id');
                console.log(currentImgId);
                //通过currentImgId值追溯出对应的id值类似xlmm_pic_ul_32这样的ul列表
                var targetUlId = currentImgId.replace('content_img', 'ul');
                console.log(targetUlId);
                //通过currentImgSrc找到当前图片在targetUlId元素下对应的位置
                var indexOfCurrentImg;
                $('#' + targetUlId).find('li.xlmm_pic_img').each(function(index) {
                    if ($(this).find('img').prop('src') == $('#' + currentImgId).prop('src')) {
                        indexOfCurrentImg = index;
                    }
                });
                console.log(indexOfCurrentImg);
                //读取targetUlId列表下的图片总数
                var numOfImgs = $('#' + targetUlId).find('li.xlmm_pic_img').length;
                console.log(numOfImgs);
                //如果点击前显示的是第一张图片，则提示用户当前是第一张图片了
                if (indexOfCurrentImg == 0) {
                    //alert('哦哦，这已经是第一张图片了:)');
                } else {
                    //显示上一张图片
                    $('#' + targetUlId).find('li.xlmm_pic_img').eq(indexOfCurrentImg - 1).find('img').trigger('click');
                }
            }
        });

        $('body').on('click', '.toNext', function(e) {
            e.preventDefault();
            //判断toPrev所在区域是图片而非音频等其他内容
            if ($(this).parent().find('img').length > 0) {
                //读取当前图片的src值和id值
                console.log($(this));
                var $currentImg = $(this).parent().find('img');
                var currentImgSrc = $currentImg.prop('src');
                var currentImgId = $currentImg.prop('id');
                console.log(currentImgId);
                //通过currentImgId值追溯出对应的id值类似xlmm_pic_ul_32这样的ul列表
                var targetUlId = currentImgId.replace('content_img', 'ul');
                console.log(targetUlId);
                //通过currentImgSrc找到当前图片在targetUlId元素下对应的位置
                var indexOfCurrentImg;
                $('#' + targetUlId).find('li.xlmm_pic_img').each(function(index) {
                    if ($(this).find('img').prop('src') == $('#' + currentImgId).prop('src')) {
                        indexOfCurrentImg = index;
                    }
                });
                console.log(indexOfCurrentImg);
                //读取targetUlId列表下的图片总数
                var numOfImgs = $('#' + targetUlId).find('li.xlmm_pic_img').length;
                console.log(numOfImgs);
                //如果点击前显示的是最后一张图片，则提示用户当前是最后一张图片了
                if (indexOfCurrentImg == numOfImgs - 1) {
                    //alert('哦哦，这已经是最后一张图片了:)');
                } else {
                    //显示下一张图片
                    $('#' + targetUlId).find('li.xlmm_pic_img').eq(indexOfCurrentImg + 1).find('img').trigger('click');
                }
            }
        });
    });
})(jQuery);


function xlmm_pic_show(pid, type, src){
	$('xlmm_pic_ul_' + pid).style.display = 'none';
    console.log($('xlmm_pic_ul_' + pid));
	$('xlmm_pic_show_' + pid).style.display = 'block';
	$('xlmm_pic_bar_' + pid + '_' + type).style.display = 'block';

	if(type == 'img'){
		$('xlmm_pic_content_'+pid).innerHTML = '<img class="xlmm_pic_content_img" id="xlmm_pic_content_img_' + pid + '" src="' + src + '" onload="xlmm_pic_show_size(this)" onclick="xlmm_pic_hide(' + pid + ')" /><div class="toPrev"></div><div class="toNext"></div>';
        //获取当前列表所含图片总数
//        var numAllImgs = jQuery('#xlmm_pic_ul_' + pid).find('li').length;
        //获取第一张、最后一张图片的路径名
        var firstImg = jQuery('#xlmm_pic_ul_' + pid).find('li:first img').prop('src');
        var lastImg = jQuery('#xlmm_pic_ul_' + pid).find('li:last img').prop('src');

        //若即将显示的是第一张图片，则不显示上一张的箭头
//        var currentIndex = src.split('/')[1].split('.')[0];
//        console.log(currentIndex);
		if (jQuery('#xlmm_pic_ul_' + pid).find('li img').length == 1) {
			jQuery('.toPrev').css({
				display: 'none'
			});
			jQuery('.toNext').css({
				display: 'none'
			});
		} else if (firstImg.indexOf(src) > 0) {
			jQuery('.toPrev').css({
				display: 'none'
			});
			jQuery('.toNext').css({
				display: 'block'
			});
		} else if (lastImg.indexOf(src) > 0) {
			jQuery('.toPrev').css({
				display: 'block'
			});
			jQuery('.toNext').css({
				display: 'none'
			});
		} else {
			jQuery('.toPrev').css({
				display: 'block'
			});
			jQuery('.toNext').css({
				display: 'block'
			});
		}
	}else if(type == 'mp3'){
		$('xlmm_pic_content_'+pid).innerHTML = ACM_FL_RunContent('width', 402, 'height', 90, 'allowNetworking', 'internal', 'allowScriptAccess', 'never', 'src', src, 'quality', 'high', 'bgcolor', '#ffffff', 'wmode', 'transparent', 'allowfullscreen', 'true', 'play', 'true', 'loop', 'false', 'menu', 'false', 'scale', 'noborder');

	}else{
		$('xlmm_pic_content_'+pid).innerHTML = AC_FL_RunContent('width', xlmm_pic_setting.picw, 'height', xlmm_pic_setting.picw * 0.90, 'allowNetworking', 'internal', 'allowScriptAccess', 'never', 'src', src, 'quality', 'high', 'bgcolor', '#ffffff', 'wmode', 'transparent', 'allowfullscreen', 'true');

	}
}

function xlmm_pic_hide(pid){
	$('xlmm_pic_bar_' + pid + '_img').style.display = 'none';
	$('xlmm_pic_show_' + pid).style.display = 'none';
	$('xlmm_pic_ul_' + pid).style.display = 'block';
}


function xlmm_pic_img_blank(pid){
	var img = $('xlmm_pic_content_img_'+pid);
	if(img){
		window.open(img.src);
	}
}

function xlmm_pic_img_rotate_init(img, fx){
	var rotate = img.rotate ? (img.rotate) * 1 : 0;
	rotate = rotate + fx * 90;
	img.rotate = rotate;
	var wBh = 1;
	if(Math.abs(rotate) % 180 != 0 && img.offsetHeight > img.offsetWidth){
		wBh = img.offsetWidth / img.offsetHeight;
	}
	xlmm_pic_img_rotate_rotation(img, rotate, wBh);
}

function xlmm_pic_img_rotate_rotation(img, rotate, wBh){
	if(xlmm_pic_img_rotate_checkCSS3("transform")){
		xlmm_pic_img_rotate_rotationForCSS3(img, rotate, wBh);
	}else{
		xlmm_pic_img_rotate_rotationForIE(img, rotate, wBh);
	}
}

function xlmm_pic_img_rotate_rotationForCSS3(img, rotate, wBh){
	var c = ( rotate % 180 == 0) ? 0 : (-(img.offsetHeight - img.offsetWidth * wBh) / 2);
	var b = img.parentNode;
	xlmm_pic_img_rotate_css3(img, "transform", "translate(0px, " + c + "px) rotate(" + rotate + "deg) scale(" + wBh + ", " + wBh + ")");
	if(rotate % 180 != 0){
		b.style.height = (img.offsetWidth * wBh) + "px"
	}else{
		b.style.height = (img.offsetHeight * wBh) + "px"
	}
}

function xlmm_pic_img_rotate_css3(d, a, c){
	if(!d || !a || a == ""){
		return false;
	}
	var b = xlmm_pic_img_rotate_checkCSS3(a);
	if(!b){
		return false;
	}
	if(c){
		d.style[b] = c;
	}else{
		return d.style[b];
	}
}

function xlmm_pic_img_rotate_rotationForIE(img, rotate, wBh){
	if(BROWSER.ie && BROWSER.ie < 8){
		var a = xlmm_pic_img_rotate_getMatrix(rotate * Math.PI / 180, wBh);
		img.style.filter = "progid:DXImageTransform.Microsoft.Matrix(SizingMethod='auto expand')";
		xlmm_pic_img_rotate_filters_extend(img.filters.item("DXImageTransform.Microsoft.Matrix"), a);
	}
	if(BROWSER.ie && BROWSER.ie >= 8){
		var d = img.parentNode,
		a = xlmm_pic_img_rotate_getMatrix(rotate * Math.PI / 180, wBh);
		img.style.filter = "progid:DXImageTransform.Microsoft.Matrix(SizingMethod='auto expand')";
		if(rotate % 180 != 0){
			var e = img.offsetWidth * wBh, c = img.offsetHeight * wBh;
			img.style.visibility = "hidden";
			xlmm_pic_img_rotate_filters_extend(img.filters.item("DXImageTransform.Microsoft.Matrix"), a);
			d.style.height = e + "px";
			d.style.position = "relative";
			img.style.visibility = "";
			img.style.display = "block";
			img.style.position = "absolute";
			img.style.left = ((d.offsetWidth - img.offsetHeight*wBh) / 2) + "px";
		}else{
			xlmm_pic_img_rotate_filters_extend(img.filters.item("DXImageTransform.Microsoft.Matrix"), a);
			d.style.height = (img.offsetHeight * wBh)  + "px";
			d.style.position = "";
			img.style.display = "";
			img.style.position = "";
			img.style.left = "0px";
		}
	}
}

function xlmm_pic_img_rotate_filters_extend(a, b){
	for(var i in b){
		a[i] = b[i];
	}
	return a;
}

function xlmm_pic_img_rotate_getMatrix(d, c){
	var a = Math.cos(d), b = Math.sin(d);
	return {M11 : a * c, M12 : -b * c, M21 : b * c, M22 : a * c};
}
		
function xlmm_pic_img_rotate_checkCSS3(c){
	var g = document.body.style;
	var d = c.replace(/^\w/, function(h){
		return h.toUpperCase();
	});
	var f, b=[c,"Moz" + d, "webkit" + d, "O" + d, "ms" + d];
	for(var e = 0, a = b.length; e < a; e++){
		if(b[e] in g){
			f = b[e];
			break;
		}
	}
	if(!f){
		return false;
	}
	return f;
}


function xlmm_pic_img_rotate(pid, fx){
	var img = $('xlmm_pic_content_img_'+pid);
	if(img && img.offsetWidth && img.offsetHeight){
		xlmm_pic_img_rotate_init(img, fx);
	}
}

function xlmm_pic_show_size(img){
	if(img){
		setTimeout(function(){
			if(img.offsetWidth && img.offsetHeight){
				if(img.offsetWidth > xlmm_pic_setting.picw){
					img.style.width = xlmm_pic_setting.picw + 'px';
				}
				if(img.offsetHeight > xlmm_pic_setting.pich){
					img.parentNode.style.height = xlmm_pic_setting.pich + 'px';
					img.parentNode.style.overflow = 'hidden';
				}
			}
		}, 20);
	}
}

function xlmm_pic_list(img){
	if(img){
		setTimeout(function(){
			if(!img.offsetWidth || !img.offsetHeight || img.offsetHeight < xlmm_pic_setting.picph){
				xlmm_pic_list_hide(img);
			}else if(img.offsetHeight > xlmm_pic_setting.picph){
				img.style.height = xlmm_pic_setting.picph + 'px';
			}
			if(img.offsetWidth > xlmm_pic_setting.picsw){
				img.parentNode.style.width = xlmm_pic_setting.picsw + 'px';
				img.parentNode.style.overflow = 'hidden';
			}	
		}, 20);			
	}	
}

function xlmm_pic_list_error(img){
	if(img){
		setTimeout(function(){
			xlmm_pic_list_hide(img);
		}, 20)
	}
}
function xlmm_pic_list_hide(img){
	if(img){
		img.parentNode.style.display = 'none';
		try{
			var cl = img.parentNode.parentNode.childNodes;
			var show = false;
			for(var i = 0; i < cl.length; i++){
				var c = cl[i];
				if(c && c.style && c.style.display && c.style.display == 'none'){
					//
				}else{
					show = true;
					break;
				}
			}
			if(!show){
				img.parentNode.parentNode.parentNode.style.display = 'none';
			}
		}catch(e){}
	}	
}




