<?php exit; ?>
<!--{template common/header}-->

<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
			</li>

			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>
<div class="forumpw-box">
	<h3 class="fpb-title">{lang forum_password_require}</h3>
	<div class="fpb-form">
		<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=pwverify">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="password" placeholder="访问密码"  name="pw" class="px ap_n" size="25" />
			&nbsp;<button class="pn" type="submit" name="loginsubmit" value="true">{lang submit}</button>
		</form>
	</div>
</div>
<!--{template common/footer}-->