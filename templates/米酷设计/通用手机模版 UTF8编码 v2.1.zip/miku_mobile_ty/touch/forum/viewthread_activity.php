<?php exit; ?>
<div class="activity-thread">
	<div class="act-img">
	<!--{if $activity['thumb']}-->
		<img src="$activity['thumb']"/>
	<!--{else}-->
		<!-- <img src="{IMGDIR}/nophoto.gif"/> -->
	<!--{/if}-->
	</div>

	<ul class="act-info cl">
		<li class="item">
			<div class="ai-name">{lang activity_type}</div>
			<div class="ai-value"><strong>$activity[class]</strong></div>
		</li>
		<li class="item">
			<div class="ai-name">{lang activity_starttime}</div>
			<div class="ai-value">
				<!--{if $activity['starttimeto']}-->
					{lang activity_start_between}
				<!--{else}-->
					$activity[starttimefrom]
				<!--{/if}-->
			</div>
		</li>
		<li class="item">
			<div class="ai-name">{lang activity_space}</div>
			<div class="ai-value">$activity[place]</div>
		</li>
		<li class="item">
			<div class="ai-name">{lang gender}</div>
			<div class="ai-value">
				<!--{if $activity['gender'] == 1}-->
					{lang male}
				<!--{elseif $activity['gender'] == 2}-->
					{lang female}
				<!--{else}-->
					 {lang unlimited}
				<!--{/if}-->
			</div>
		</li>

		<!--{if $activity['cost']}-->
		<li class="item">
			<div class="ai-name">{lang activity_payment}</div>
			<div class="ai-value">$activity[cost] {lang payment_unit}</div>
		</li>
		<!--{/if}-->

		<!--{if !$_G['forum_thread']['is_archived']}-->
			<li class="item">
				<div class="ai-name">{lang activity_already}</div>
				<div class="ai-value">
					<em>$allapplynum</em> {lang activity_member_unit}
					<!--{if $post['invisible'] == 0 && ($_G['forum_thread']['authorid'] == $_G['uid'] || (in_array($_G['group']['radminid'], array(1, 2)) && $_G['group']['alloweditactivity']) || ( $_G['group']['radminid'] == 3 && $_G['forum']['ismoderator'] && $_G['group']['alloweditactivity']))}-->
						<span class="xi1">{lang activity_mod}</span>
					<!--{/if}-->
				</div>
			</li>
			
			<!--{if $activity['number']}-->
			<li class="item">
				<div class="ai-name">{lang activity_about_member}</div>
				<div class="ai-value">$aboutmembers {lang activity_member_unit}</div>
			</li>
			<!--{/if}-->

			<!--{if $activity['expiration']}-->
			<li class="item">
				<div class="ai-name">{lang post_closing}</div>
				<div class="ai-value">$activity[expiration]</div>
			</li>
			<!--{/if}-->

			<!--{if $post['invisible'] == 0}-->
				<!--{if $applied && $isverified < 2}-->
				<li class="item">
					<p class="ai-status">
						<!--{if !$isverified}-->{lang activity_wait}<!--{else}-->{lang activity_join_audit}<!--{/if}-->
					</p>
					<!--{if !$activityclose}-->
	                <!--{/if}-->
				</li>
				<!--{elseif !$activityclose}-->
	                <!--{if $isverified != 2}-->
	                <!--{else}-->
					<li class="item">
	                	<p class="pns mtn"><input value="{lang complete_data}" name="ijoin" id="ijoin" /></p>
					</li>
	                <!--{/if}-->
				<!--{/if}-->
			<!--{/if}-->
		<!--{/if}-->
	</ul>
</div>

<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>


<!--{if $_G['uid'] && !$activityclose && (!$applied || $isverified == 2)}-->
	<div id="activityjoin" class="activity-join">
    	<div class="bm_c pd5">
        <div class="aj-title">{lang activity_join}</div>
	<!--{if $_G['forum']['status'] == 3 && helper_access::check_module('group') && $isgroupuser != 'isgroupuser'}-->
		<div class="aj-warn">
        	<p>{lang activity_no_member}</p>
        	<p><a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="xi2">{lang activity_join_group}</a></p>
		</div>
	<!--{else}-->
		<form name="activity" id="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}&mobile=2" >
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<ul>
				
				<!--{if $_G['setting']['activitycredit'] && $activity['credit'] && !$applied}-->
				<li class="item-tips">
					{lang activity_need_credit} $activity[credit] {$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}
				</li>
				<!--{/if}-->

                <!--{if $activity['cost']}-->
               <li class="item">
                    <div class="aj-name">
               			{lang activity_paytype}
                    </div>
                    <div class="aj-input">
                    	<p>
	               			<label><input class="pr" type="radio" value="0" name="payment" id="payment_0" checked="checked" />{lang activity_pay_myself}</label> 
                    	</p>
                    	<p>
		               		<label><input class="pr" type="radio" value="1" name="payment" id="payment_1" />{lang activity_would_payment} </label> 
		               		<input name="payvalue" size="3" class="txt" /> {lang payment_unit}
                    	</p>
                    </div>
               	</li>
                <!--{/if}-->

                <!--{if !empty($activity['ufield']['userfield'])}-->
                    <!--{loop $activity['ufield']['userfield'] $fieldid}-->
                    <!--{if $settings[$fieldid][available]}-->
                    <li class="item">
                        <div class="aj-name">
                        	$settings[$fieldid][title]<span class="xi1"> *</span>
                        </div>
                        <div class="aj-input">$htmls[$fieldid]</div>
                    </li>
                    <!--{/if}-->
                    <!--{/loop}-->
                <!--{/if}-->

                <!--{if !empty($activity['ufield']['extfield'])}-->
                    <!--{loop $activity['ufield']['extfield'] $extname}-->
                    <li class="item">
                        <div class="aj-name">
                        	$extname
                        </div>
                        <div class="aj-input">
                        	<input type="text" name="$extname" class="px" value="{if !empty($ufielddata)}$ufielddata[extfield][$extname]{/if}" />
                        </div>
                    </li>
                    <!--{/loop}-->
                <!--{/if}-->

				<li class="item">
                    <div class="aj-name">
	            	{lang leaveword}
                    </div>
                    <div class="aj-input">
	            		<textarea name="message" cols="28" rows="2" class="txt-big">$applyinfo[message]</textarea>
                    </div>
				</li>
				<li class="item-btn">
					<!--{if $_G['setting']['activitycredit'] && $activity['credit'] && checklowerlimit(array('extcredits'.$_G['setting']['activitycredit'] => '-'.$activity['credit']), $_G['uid'], 1, 0, 1) !== true}-->
						<p class="aj-tips">
							<span>{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]} {lang not_enough}$activity['credit']</span>
						</p>
					<!--{else}-->
						<div>
							<input type="hidden" name="activitysubmit" value="true">
							<em class="xi1" id="return_activityapplies"></em>
							<button type="submit" ><span>{lang submit}</span></button>
						</div>
					<!--{/if}-->
				</li>
			</ul>
		</form>

		<script type="text/javascript">
			function succeedhandle_activityapplies(locationhref, message) {
				showDialog(message, 'notice', '', 'location.href="' + locationhref + '"');
			}
		</script>
	<!--{/if}-->
    	</div>
	</div>

<!--{elseif $_G['uid'] && !$activityclose && $applied}-->
<div id="activityjoincancel" class="activity-join-cancel">
    <div class="ajc-title">
        	{lang activity_join_cancel}
    </div>
    <form name="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}">
	    <input type="hidden" name="formhash" value="{FORMHASH}" />
		<ul>
		    <li class="item">
		        <div class="ajc-name">{lang leaveword}</div>
		        <div class="ajc-input">
		        	<input type="text" name="message" maxlength="200" class="px" value="" placeholder="输入退出原因" />
		        </div>
		    </li>
		    <li class="item-btn">
		    	<button type="submit" name="activitycancel"  value="true"><span>{lang submit}</span></button>
		    </li>
		</ul>
    </form>
</div>
<!--{/if}-->

<!--{if $applylist}-->
<div class="activity-applylist">
    
    <table class="dt" cellpadding="5" cellspacing="5">
    	<caption>
    		<p class="apl-title">{lang activity_new_join} ($applynumbers {lang activity_member_unit})</p>
    	</caption>
        <tr>
            <th >&nbsp;</th>
            <!--{if $activity['cost']}-->
            <th >{lang activity_payment}</th>
            <!--{/if}-->
            <th>{lang activity_jointime}</th>
        </tr>
        <!--{loop $applylist $apply}-->
            <tr>
                <td>
                    <a href="home.php?mod=space&uid=$apply[uid]">$apply[username]</a>
                </td>
                <!--{if $activity['cost']}-->
                <td><!--{if $apply[payment] >= 0}-->$apply[payment] {lang payment_unit}<!--{else}-->{lang activity_self}<!--{/if}--></td>
                <!--{/if}-->
                <td>$apply[dateline]</td>
            </tr>
        <!--{/loop}-->
    </table>
</div>
<!--{/if}-->
