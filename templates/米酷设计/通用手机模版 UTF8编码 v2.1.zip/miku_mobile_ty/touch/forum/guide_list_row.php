<?php exit; ?>

				<div class="item">
					<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra">
						<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
						<!--{/if}-->
						<div class="content">
							<div class="subject">
								<!--{if $thread['digest'] > 0}-->
									<span class="icon-digest">精</span>
								<!--{/if}-->
								$thread[subject]
							</div>
							
							<!--{if $thread['attachment'] == 2}-->
							<div class="img-list cl">
								<!--{eval $piclist = $miku_get_thread->getpic($thread[tid]);}-->
								<!--{if count($piclist)==3}-->
									<!--{loop $piclist $pic}-->
										<!--{eval $url = getforumimg($pic['aid'], 0, 250, 200, 'fixwr');}-->
									<div style="float:left;width: 33.3%;overflow: hidden;">
										<div style="background:#f9f9f9;margin-right:3px;overflow: hidden;" class="mkimg-list-3">
											<img class="mktylazy" src="template/miku_mobile_ty/static/image/imgnone_a.gif" data-original="{$url}" width="100%" height="100%">
										</div>
									</div>
									<!--{/loop}-->
								<!--{elseif count($piclist)>=1}-->
									<!--{loop $piclist $pic}-->
										<!--{eval $url = getforumimg($pic['aid'], 0, 280, 165, 'fixwr');}-->
									<div style="float:left;width: 50%;overflow: hidden;">
										<div style="background:#f9f9f9;margin-right:3px;overflow: hidden;" class="mkimg-list-2">
										<img class="mktylazy" src="template/miku_mobile_ty/static/image/imgnone_b.gif" data-original="{$url}" width="100%" height="100%">
										</div>
									</div>
									<!--{/loop}-->
								<!--{/if}-->

							</div>
							<!--{else}-->
							<div class="comment">
								<!--{if !($thread['price'] > 0 && $thread['special'] != '3')}-->
									{$summary[$thread[tid]]}
								<!--{/if}-->
							</div>
							<!--{/if}-->
						</div>
					</a>
						
					<div class="info cl">
						<span class="by cl">
							<a href="home.php?mod=space&do=profile&uid=$thread[authorid]">
								<img class="uifavatar" src="{avatar($thread['authorid'], small,true)}"/>
								<span class="uname">$thread[author]</span>
							</a>
						</span>
						<span class="num">
							<span>
								<i class="mktyiconfont icon-chakan1"></i>
								<!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->
							</span>&nbsp;&nbsp;
							<span>
								<i class="mktyiconfont icon-31xiaoxi"></i>
								<!--{if $thread['isgroup'] != 1}-->$thread[replies]<!--{else}-->{$groupnames[$thread[tid]][replies]}<!--{/if}-->
							</span>
						</span>
					</div>
				</div>


