<?php exit; ?>
<!--{template common/header}-->


<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				<!--{if $_GET[action] == 'edit'}-->
				{lang edit}
				<!--{elseif $_GET[action] == 'reply'}-->
				回复
				<!--{else}-->
				{lang send_threads}
				<!--{/if}-->
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>
<div id="mkty-crumb-body" style="display: none;">
	<div class="mkty-crumb-body">
		<div class="cmbn-list">
			<a href="forum.php?mod=guide&view=new"><i class="mktyiconfont icon-shouye3"></i></a><em>&rsaquo;</em><a href="forum.php?forumlist=1">社区</a>$navigation
			<!--{if $_GET[action] == 'edit'}-->
				<em>&rsaquo;</em><a href="forum.php?mod=viewthread&tid=$_G[tid]">$thread['subject']</a>
			<!--{elseif $_GET[action] == 'reply'}-->
				<em>&rsaquo;</em><a href="forum.php?mod=viewthread&tid=$_G[tid]">$thread['subject']</a>
			<!--{else}-->
				<em>&rsaquo;</em>{lang send_threads}
			<!--{/if}-->
		</div>
	</div>
</div>

<!--{if $_GET[action] == 'newthread'}-->
<div id="mikuty-post-navtab" class="mycenter-navtab col-4 cl">
	<ul>
		<!--{eval $miku_thread_type_num = 0}-->
		<!--{if !$_G['forum']['threadsorts']['required'] && !$_G['forum']['allowspecialonly']}-->
		<li class="item">
			<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" {$postspecialcheck[0]}>帖子</a>
		</li>
		<!--{eval $miku_thread_type_num++}-->
		<!--{/if}-->
		<!--{if $_G['group']['allowpostpoll']}-->
		<li class="item">
			<a href="forum.php?mod=post&action=newthread&special=1&fid=$_G[fid]&forcemobile=1"  $postspecialcheck[1]>投票</a>
		</li>
		<!--{eval $miku_thread_type_num++}-->
		<!--{/if}-->
		<!--{if $_G['group']['allowpostreward']}-->
		<li class="item">
			<a href="forum.php?mod=post&action=newthread&special=3&fid=$_G[fid]&forcemobile=1"  $postspecialcheck[3]>悬赏</a>
		</li>
		<!--{eval $miku_thread_type_num++}-->
		<!--{/if}-->
		<!--{if $_G['group']['allowpostdebate']}-->
		<li class="item">
		<a href="forum.php?mod=post&action=newthread&special=5&fid=$_G[fid]&forcemobile=1" $postspecialcheck[5]>辩论</a>
		</li>
		<!--{eval $miku_thread_type_num++}-->
		<!--{/if}-->
	</ul>
</div>
<script>
	$('#mikuty-post-navtab').removeClass('col-4').addClass('col-{$miku_thread_type_num}');
</script>
<!--{/if}-->


<!--{if ($special != 2 && $special != 4 && !($isfirstpost && $sortid)) || $_GET[action] == 'reply'}-->
<!--{eval $adveditor = $isfirstpost && $special && ($_GET['action'] == 'newthread' || $_GET['action'] == 'reply' && !empty($_GET['addtrade']) || $_GET['action'] == 'edit' );}-->

<form method="post" id="postform"
			{if $_GET[action] == 'newthread'}action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes&mobile=2"
			{elseif $_GET[action] == 'reply'}action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes&mobile=2"
			{elseif $_GET[action] == 'edit'}action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes&mobile=2" $enctype
			{/if}>
<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
<input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}" />
<!--{if !empty($_GET['modthreadkey'])}--><input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" /><!--{/if}-->
<!--{if $_GET[action] == 'reply'}-->
	<input type="hidden" name="noticeauthor" value="$noticeauthor" />
	<input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
	<input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
	<!--{if $reppid}-->
		<input type="hidden" name="reppid" value="$reppid" />
	<!--{/if}-->
	<!--{if $_GET[reppost]}-->
		<input type="hidden" name="reppost" value="$_GET[reppost]" />
	<!--{elseif $_GET[repquote]}-->
		<input type="hidden" name="reppost" value="$_GET[repquote]" />
	<!--{/if}-->
<!--{/if}-->
<!--{if $_GET[action] == 'edit'}-->
	<input type="hidden" name="fid" id="fid" value="$_G[fid]" />
	<input type="hidden" name="tid" value="$_G[tid]" />
	<input type="hidden" name="pid" value="$pid" />
	<input type="hidden" name="page" value="$_GET[page]" />
<!--{/if}-->

<!--{if $special}-->
	<input type="hidden" name="special" value="$special" />
<!--{/if}-->
<!--{if $specialextra}-->
	<input type="hidden" name="specialextra" value="$specialextra" />
<!--{/if}-->
<div class="post-box">
	<div class="post_from">
		<ul class="cl">
			<li class="item title">
				<!--{if $_GET['action'] != 'reply'}-->
				<input type="text" tabindex="1" id="needsubject" size="30" autocomplete="off" value="$postinfo[subject]" name="subject" placeholder="{lang thread_subject}" fwin="login">
				<!--{else}-->
					RE: $thread['subject']
					<!--{if $quotemessage}-->$quotemessage<!--{/if}-->
				<!--{/if}-->
			</li>
			<!--{if $isfirstpost && !empty($_G['forum'][threadtypes][types])}-->
			<li class="item post-type">
				<select id="typeid" name="typeid">
					<option value="0" selected="selected">{lang select_thread_catgory}</option>
					<!--{loop $_G['forum'][threadtypes][types] $typeid $name}-->
					<!--{if empty($_G['forum']['threadtypes']['moderators'][$typeid]) || $_G['forum']['ismoderator']}-->
					<option value="$typeid"{if $thread['typeid'] == $typeid || $_GET['typeid'] == $typeid} selected="selected"{/if}><!--{echo strip_tags($name);}--></option>
					<!--{/if}-->
					<!--{/loop}-->
				</select>
			</li>
			<!--{/if}-->

			<!--{if $_GET[action] == 'edit' && $isorigauthor && ($isfirstpost && $thread['replies'] < 1 || !$isfirstpost) && !$rushreply && $_G['setting']['editperdel']}-->
			<li class="item delete-btn">
				<input type="checkbox" name="delete" id="delete" class="pc" value="1" title="{lang post_delpost}{if $thread[special] == 3}{lang reward_price_back}{/if}"> {lang delete_check}
			</li>
			<!--{/if}-->
			<!--{if !$isfirstpost && $thread[special] == 5 && empty($firststand) && $_GET[action] != 'edit'}-->
				<li class="item post-type">
					<select name="stand" id="stand">
						<option value="">{lang debate_viewpoint}</option>
						<option value="0">{lang debate_neutral}</option>
						<option value="1"{if $stand == 1} selected="selected"{/if}>{lang debate_square}</option>
						<option value="2"{if $stand == 2} selected="selected"{/if}>{lang debate_opponent}</option>
					</select>
				</li>
			<!--{/if}-->
			<!--{if $adveditor}-->
			<li class="post-speacil-form">
				<!--{if $special == 1}--><!--{template forum/post_poll}-->
				<!--{elseif $special == 2 && ($_GET[action] != 'edit' || ($_GET[action] == 'edit' && ($thread['authorid'] == $_G['uid'] && $_G['group']['allowposttrade'] || $_G['group']['allowedittrade'])))}--><p class="xg1">{lang post_message1}</p><!--{template forum/post_trade}-->
				<!--{elseif $special == 3}--><!--{template forum/post_reward}-->
				<!--{elseif $special == 4}--><!--{template forum/post_activity}-->
				<!--{elseif $special == 5}--><!--{template forum/post_debate}-->
				<!--{/if}-->
			</li>
			<!--{/if}-->

			<li class="item post-cotent">
				<textarea class="pt" id="needmessage" tabindex="3" autocomplete="off" name="$editor[textarea]" cols="80" rows="4"  placeholder="{lang thread_content}" fwin="reply">$postinfo[message]</textarea>
			</li>

			<li class="item item-postbtn">
				<div class="post-btn-list cl" style="padding:0px;">
					<a href="javascript:;" class="pbl-upload-btn y">
						<i class="mktyiconfont icon-camera" id="filedate-btn"></i>
						<input class="pbl-fileinput" type="file" name="Filedata" id="filedata" style="width:30px;height:30px;font-size:30px;opacity:0;"/>
					</a>
					<a href="javascript:;" id="pbl-smile-btn" class="pbl-smile-btn y">
						<i class="mktyiconfont icon-emoji"></i>
					</a>
				<div>
			</li>
			<li id="pbl-smile-body" class="item item-smilelist" style="display: none;overflow: hidden;">
				<div id="mktysmilies" class="pbl-smilelist">
				</div>
			</li>
			<li class="item">
				<ul id="imglist" class="post_imglist cl">
				</ul>
			</li>
			<!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
			<li class="item cl">
				<!--{subtemplate common/seccheck}-->
			</li>
			<!--{/if}-->
		</ul>

		<div id="append_parent"></div>
		<script type="text/javascript" src="template/miku_mobile_ty/static/js/smilies.js?{VERHASH}"></script>
		<script type="text/javascript">
			smilies_show('mktysmilies', 8);
			$('#pbl-smile-btn').on('tap',function(){
				$("#pbl-smile-body").slideToggle('fast');
				$("#pbl-smile-btn").toggleClass('pbl-active');
                document.activeElement.blur();
			});
		</script>

		<div class="submit-btn">
			<button id="postsubmit" class="btn_pn <!--{if $_GET[action] == 'edit'}-->btn_pn_blue" disable="false"<!--{else}-->btn_pn_grey" disable="true"<!--{/if}-->><span><!--{if $_GET[action] == 'newthread'}-->{lang send_thread}<!--{elseif $_GET[action] == 'reply'}-->{lang join_thread}<!--{elseif $_GET[action] == 'edit'}-->{lang edit_save}<!--{/if}--></span></button>

			<input type="hidden" name="{if $_GET[action] == 'newthread'}topicsubmit{elseif $_GET[action] == 'reply'}replysubmit{elseif $_GET[action] == 'edit'}editsubmit{/if}" value="yes">
		</div>


		<!--{hook/post_bottom_mobile}-->
	</div>
</div>
</form>


<!--{else}-->
	<div class="post-error-tips mkty-emp">
	<!--{if $special == '2'}-->
	{lang send_special_trade_error}
    <!--{elseif $special == '4'}-->
	{lang send_special_activity_error}
	<!--{elseif $isfirstpost && $sortid}-->
	{lang threadsort_error}
    <!--{/if}-->
    </div>
<!--{/if}-->

<script type="text/javascript">
	(function() {
		var needsubject = needmessage = false;

		<!--{if $_GET[action] == 'reply'}-->
			needsubject = true;
		<!--{elseif $_GET[action] == 'edit'}-->
			needsubject = needmessage = true;
		<!--{/if}-->

		<!--{if $_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost)}-->
		$('#needsubject').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				needsubject = true;
				if(needmessage == true) {
					$('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
					$('.btn_pn').attr('disable', 'false');
				}
			} else {
				needsubject = false;
				$('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
				$('.btn_pn').attr('disable', 'true');
			}
		});
		<!--{/if}-->
		$('#needmessage').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				needmessage = true;
				if(needsubject == true) {
					$('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
					$('.btn_pn').attr('disable', 'false');
				}
			} else {
				needmessage = false;
				$('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
				$('.btn_pn').attr('disable', 'true');
			}
		});

		$('#pbl-smile-body').on('click', function(){
			var obj = $('#needmessage');
			if(obj.val()) {
				needmessage = true;
				if(needsubject == true) {
					$('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
					$('.btn_pn').attr('disable', 'false');
				}
			} else {
				needmessage = false;
				$('.btn_pn').removeClass('btn_pn_blue').addClass('btn_pn_grey');
				$('.btn_pn').attr('disable', 'true');
			}
		});

		$('#needmessage').on('scroll', function() {
			var obj = $(this);
			if(obj.scrollTop() > 0) {
				obj.attr('rows', parseInt(obj.attr('rows'))+2);
			}
		}).scrollTop($(document).height());

	 })();
</script>
<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="{STATICURL}js/mobile/buildfileupload.js?{VERHASH}"></script>
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
	var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	var form = $('#postform');
	$(document).on('change', '#filedata', function() {
			popup.open('<div style="background-color:rgba(0,0,0,.7);opacity:.6; position:fixed; top:50%;left:50%;height:50px;width:80px;padding:15px 0;margin-left:-40px;margin-top:-50px;border-radius:3px;"><img src="template/miku_mobile_ty/static/image/imageloading.gif" style="width:50px;height:50px;"></div>');
			uploadsuccess = function(data) {
				if(data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
				var dataarr = data.split('|');
				if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
					popup.close();
					$('#imglist').append('<li><span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;"><img style="height:54px;width:54px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
				} else {
					var sizelimit = '';
					if(dataarr[7] == 'ban') {
						sizelimit = '{lang uploadpicatttypeban}';
					} else if(dataarr[7] == 'perday') {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
					} else if(dataarr[7] > 0) {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
					}
					popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
				}
			};

			if(typeof FileReader != 'undefined' && this.files[0]) {//note 支持html5上传新特性

				$.buildfileupload({
					uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
					files:this.files,
					uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
					uploadinputname:'Filedata',
					maxfilesize:"$swfconfig[max]",
					success:uploadsuccess,
					error:function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			} else {

				$.ajaxfileupload({
					url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
					data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
					dataType:'text',
					fileElementId:'filedata',
					success:uploadsuccess,
					error: function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			}
	});

	<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
	geo.getcurrentposition();
	<!--{/if}-->
	$('#postsubmit').on('click', function() {
		var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}

		obj.attr('disable', 'true').removeClass('btn_pn_blue').addClass('btn_pn_grey');
		popup.open('<div style="background-color:rgba(0,0,0,.7);opacity:.6; position:fixed; top:50%;left:50%;height:50px;width:80px;padding:15px 0;margin-left:-40px;margin-top:-50px;border-radius:3px;"><img src="template/miku_mobile_ty/static/image/imageloading.gif" style="width:50px;height:50px;"></div>');

		var postlocation = '';
		if(geo.errmsg === '' && geo.loc) {
			postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
		}

		$.ajax({
			type:'POST',
			url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			// 验证码输入错误
			var s = $("#needsubject").length ? $("#needsubject").val() : true;
			var m = $("#needmessage").length ? $("#needmessage").val() : true;
			if( s && m){
				$('.btn_pn').removeClass('btn_pn_grey').addClass('btn_pn_blue');
				$('.btn_pn').attr('disable', 'false');
			}
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');

		});
		return false;
	});

	$(document).on('click', '.del', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

</script>


<!--{template common/footer}-->
