<?php exit; ?>
<!--{template common/header}-->
<!--{if empty($_GET['infloat'])}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				{lang debate_umpirecomment}
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>
<!--{/if}-->
<div class="debate-umpire-box">
	<form method="post" autocomplete="off" id="postform" action="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&umpiresubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}"{if !empty($_GET['infloat'])} onsubmit="ajaxpost('postform', 'return_$_GET['handlekey']', 'return_$_GET['handlekey']', 'onerror');return false;"{/if}>
		<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
		<!--{if !empty($_GET['infloat'])}-->
			<input type="hidden" name="handlekey" value="$_GET['handlekey']" />
		<!--{/if}-->
		<ul>
			<!--{if !empty($_GET['infloat'])}-->
			<li class="item">
				<h3 class="dub-title">
					<em id="return_$_GET['handlekey']">{lang debate_umpirecomment}</em>
				</h3>
			</li>
			<!--{/if}-->
			<li class="item cl">
				<div class="dub-name">{lang debate_winner}</div>
				<div class="dub-input">
					<label><input type="radio" name="winner" value="1" class="pr" $winnerchecked[1] id="winner1" />{lang debate_square}</label>
					<label><input type="radio" name="winner" value="2" class="pr" $winnerchecked[2] id="winner2" />{lang debate_opponent}</label>
					<label><input type="radio" name="winner" value="3" class="pr" $winnerchecked[3] id="winner3" />{lang debate_draw}</label>
				</div>
			</li>
			<li class="item cl">
				<div class="dub-name">
					<label for="bestdebater">
						{lang debate_bestdebater}
					</label>
				</div>

				<div class="dub-input">
					<p>
					<select onchange="$('#bestdebater')[0].value=this.options[this.options.selectedIndex].value" class="ps">
						<option value="">{lang debate_recommend_list}</option>
						<option value="">------------------------------</option>
						<!--{loop $candidates $candidate}-->
							<option value="$candidate[username]"{if $candidate[username] == $debate[bestdebater]} selected="selected"{/if}>$candidate[username] ( $candidate[voters] {lang debate_poll}, <!--{if $candidate[stand] == 1}-->{lang debate_square}<!--{elseif $candidate[stand] == 2}-->{lang debate_opponent}<!--{/if}-->)</option>
						<!--{/loop}-->
					</select>
					</p>
					<p class="mtn">
						<input type="text" name="bestdebater" id="bestdebater" class="px" value="$debate[bestdebater]" placeholder="最佳辩手" size="20" />
					</p>
					<p class="dub-tips">{lang debate_list_nonexistence}</p>
				</div>
			</li>

			<li class="item cl">
				<div class="dub-name"><label for="umpirepoint">{lang debate_umpirepoint}</label>
				</div>
				<div class="dub-input">
					<textarea id="umpirepoint" name="umpirepoint" class="pt" style="height: 100px;">$debate[umpirepoint]</textarea>
				</div>
			</li>
		</ul>
		<div class="dub-btn">
			<button class="pn pnc" type="submit" name="umpiresubmit" value="true" class="submit"><span>{lang submit}</span></button>
		</div>
	</form>
</div>
<!--{if !empty($_GET['infloat'])}-->
<script type="text/javascript" reload="1">
</script>
<!--{/if}-->
<!--{template common/footer}-->