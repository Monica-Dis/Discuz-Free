<?php exit; ?>
<!--{if !$post['message'] && (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid']))}-->
<div class="trade-tips">
    <a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]&page=$page">
    <span class="tips-btn">{lang post_add_aboutcounter}</span>
    </a>
</div>
<!--{else}-->
 <div class="postmessage">
 $post[message]
 </div>
<!--{/if}-->


<!--{if count($trades) > 1 || ($_G['uid'] == $_G['forum_thread']['authorid'] || $_G['group']['allowedittrade'])}-->
	<div class="trade-header">
		<em>{lang post_trade_totalnumber}: $tradenum</em>
		<!--{if !$_G['forum_thread']['is_archived'] && ($_G['uid'] == $_G['forum_thread']['authorid'] || $_G['group']['allowedittrade'])}-->
			<span class="xi1">{lang trade_mod}</span>
		<!--{/if}-->
	</div>
<!--{/if}-->

<div class="trade-goods">
    <!--{if $tradenum}-->
    	<!--{if $trades}-->
            <!--{loop $trades $key $trade}-->
                <div id="trade$trade[pid]" class="goods-box">
                    <div class="goods-img">
                        <!--{if $trade['displayorder'] > 0}--><em class="g-hot">{lang post_trade_sticklist}</em><!--{/if}-->
                        <!--{if $trade['thumb']}-->
                            <img src="$trade[thumb]" alt="$trade[subject]" />
                        <!--{else}-->
                            <img src="{IMGDIR}/nophotosmall.gif" width="100%" alt="$trade[subject]" />
                        <!--{/if}-->
                    </div>

                    <ul class="goods-info">
                        <li class="item">
                            <div class="goods-name">$trade[subject]</div>
                        </li>
                        <li class="item">
                            <div class="g-name">{lang trade_type_viewthread}</div>
                            <div class="g-value">
                                <!--{if $trade['quality'] == 1}-->{lang trade_new}<!--{/if}--><!--{if $trade['quality'] == 2}-->{lang trade_old}<!--{/if}-->{lang trade_type_buy}
                            </div>
                        </li>
                        <li class="item">
                            <div class="g-name">{lang trade_remaindays}</div>
                            <div class="g-value">
                            <!--{if $trade[closed]}-->
                                <em class="g-over">{lang trade_timeout}</em>
                            <!--{elseif $trade[expiration] > 0}-->
                                {$trade[expiration]}{lang days}{$trade[expirationhour]}{lang trade_hour}
                            <!--{elseif $trade[expiration] == -1}-->
                                <em class="g-over">{lang trade_timeout}</em>
                            <!--{else}-->
                                &nbsp;
                            <!--{/if}-->
                            </div>
                        </li>
                        <li class="item">
                            <div class="g-name">现价</div>
                            <div class="g-value">
                                <!--{if $trade[price] > 0}-->
                                    <span class="g-rmb">
                                        $trade[price]&nbsp;{lang payment_unit}&nbsp;&nbsp;
                                    </span>
                                <!--{/if}-->

                                <!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
                                    <span class="g-credit {if $trade['price'] > 0}g-small{/if}">
                                        <!--{if $trade['price'] > 0}-->{lang trade_additional} <!--{/if}-->$trade[credit]&nbsp;{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}
                                    </span>
                                <!--{/if}-->
                            </div>
                            
                        </li>

                        <!--{if $trade['costprice'] > 0 || $trade['costcredit'] > 0}-->
                        <li class="item">
                            <div class="g-name">原价</div>
                            <div class="g-value xg1">
                                <!--{if $trade['costprice'] > 0}-->
                                    <del>$trade[costprice] {lang payment_unit}&nbsp;&nbsp;</del>
                                <!--{/if}-->
                                <!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade['costcredit'] > 0}-->
                                    <del {if $trade['price'] > 0}class="g-small"{/if}><!--{if $trade['costprice'] > 0}-->{lang trade_additional} <!--{/if}-->$trade[costcredit] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}</del>
                                <!--{/if}-->
                            </div>
                        </li>
                        <!--{/if}-->
                    </ul>

                </div>
            <!--{/loop}-->
    	<!--{/if}-->
    <div id="postmessage_$post[pid]">$post[counterdesc]</div>
    <!--{else}-->
    	<div class="locked">{lang trade_nogoods}</div>
    <!--{/if}-->
</div>