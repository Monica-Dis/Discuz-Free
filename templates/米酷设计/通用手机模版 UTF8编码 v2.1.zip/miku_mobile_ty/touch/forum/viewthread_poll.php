<?php exit; ?>
<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>

<div class="poll-thread">
<form id="poll" name="poll" method="post" autocomplete="off" action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes&mobile=2" >
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="poll-title">
		<!--{if $multiple}-->
            <strong>{lang poll_multiple}{lang thread_poll}</strong>
            <!--{if $maxchoices}-->: ( {lang poll_more_than} )<!--{/if}-->
        <!--{else}-->
            <strong>{lang poll_single}{lang thread_poll}</strong>
        <!--{/if}-->
        <div class="poll-title-tips">
             {lang poll_voterscount}
            <!--{if $visiblepoll && $_G['group']['allowvote']}--> , {lang poll_after_result}<!--{/if}-->
        </div>
	</div>

	<!--{if $_G[forum_thread][remaintime]}-->
	<p class="poll-info">
		{lang poll_count_down}:
		<span class="xg1">
		<!--{if $_G[forum_thread][remaintime][0]}-->$_G[forum_thread][remaintime][0] {lang days}<!--{/if}-->
		<!--{if $_G[forum_thread][remaintime][1]}-->$_G[forum_thread][remaintime][1] {lang poll_hour}<!--{/if}-->
		$_G[forum_thread][remaintime][2] {lang poll_minute}
		</span>
	</p>
	<!--{elseif $expiration && $expirations < TIMESTAMP}-->
	<p class="poll-info">
        <strong>{lang poll_end}</strong>
    </p>
	<!--{/if}-->

	<ul class="poll-list">
        <!--{loop $polloptions $key $option}-->
            <li class="item">
                <!--{if $_G['group']['allowvote']}-->
                    <input type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]" {if $_G['forum_thread']['is_archived']}disabled="disabled"{/if}  />
                <!--{/if}-->
                <label class="p-label" for="option_$key">$key. $option[polloption]</label>
                <!--{if !$visiblepoll}-->
                    <div class="p-num cl"> 
                        <div class="p-wrap">
                           <div class="p-inner" style="width:{$option[percent]}%; background-color: #{$option[color]}; "></div>
                        </div> 
                        <div class="p-text"  style="color:#$option[color]">$option[percent]% ($option[votes]) </div>
                    </div>
                <!--{/if}-->
            </li>
        <!--{/loop}-->
    </ul>
    <div class="poll-btn">
        <!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
            <p class="poll-submit">
                <input type="submit" name="pollsubmit" class="ap_n" id="pollsubmit" value="提交投票" />
            </p>
            <!--{if $overt}-->
                <p class="poll-tips">({lang poll_msg_overt})</p>
            <!--{/if}-->
        <!--{elseif !$allwvoteusergroup}-->
            <!--{if !$_G['uid']}-->
            <p class="poll-warn">{lang poll_msg_allwvote_user}</p>
            <!--{else}-->
            <p class="poll-warn">{lang poll_msg_allwvoteusergroup}</p>
            <!--{/if}-->
        <!--{elseif !$allowvotepolled}-->
            <p class="poll-warn">{lang poll_msg_allowvotepolled}</p>
        <!--{elseif !$allowvotethread}-->
            <p class="poll-warn">{lang poll_msg_allowvotethread}</p>
        <!--{/if}-->
    </div>
</form>
</div>
