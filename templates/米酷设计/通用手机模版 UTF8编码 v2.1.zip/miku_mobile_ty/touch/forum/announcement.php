<?php exit; ?>
<!--{template common/header}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				站点公告
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>


<div id="ct" class="ann-box">
	<div class="mn">
		<!--{loop $announcelist $ann}-->
		<div class="annb-item">
			<div id="announce$ann[id]_c" class="annb-title">
				<h3 onclick="toggle_collapse('announce$ann[id]');">
				<span class="annb-icon">公告</span>$ann[subject]
				</h3>
			</div>
			<div id="announce$ann[id]" class="annb-body {if $annid == $ann[id]}annb-show{/if}" style="display: none;">
				<div class="annb-info cl">
					<div class="annbi-auth">
						{lang author}: <a href="home.php?mod=space&username=$ann[authorenc]" class="xi2">$ann[author]</a>
					</div>
					<div class="annbi-time">
						$ann[starttime]
					</div>
				</div>
				<div class="annb-content">
					$ann[message]
				</div>
			</div>
		</div>
		<!--{/loop}-->
	</div>
</div>
<script type="text/javascript">
	function toggle_collapse(annID){
		$('#'+annID).toggleClass('annb-show');
	}
</script>
<!--{template common/footer}-->