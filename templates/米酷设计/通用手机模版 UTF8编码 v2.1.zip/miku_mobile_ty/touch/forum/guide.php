<?php exit; ?>

<!--{eval $navtitle="首页";}-->
<!--{template common/header}-->


<!-- header start -->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a class="avatar" href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->"><img class="avatar-sm" src="{avatar($_G[uid],small,true)}"/></a>
			</li>
			<li class="title">
				{$mikuty_c_sitename}
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i>
				</a>
				<!--{if $_G[member][newpm]}--><span class="icon_msg"></span><!--{/if}-->
			</li>
		</ul>
	</div>
</header>
<!-- header end -->


<!--{if empty($_GET['inajax'])}-->
<!--{subtemplate common/config_diy}-->
<script type="text/javascript"src="template/miku_mobile_ty/static/js/guide_diy.js?{VERHASH}"></script>
<!--{/if}-->


<div class="home-threadlist">
	<h2><span>最新帖子</span><a href="forum.php?forumlist=1"><i class="mktyiconfont icon-gengduo"></i></a></h2>

	<!--{loop $data $key $list}-->
		<!--{if $list['threadcount']}-->
			<!--{eval require_once(DISCUZ_ROOT."/template/miku_mobile_ty/php/core.php");}-->
			<!--{eval $summary = $miku_get_thread->getsummary($list['threadlist'], 90);}-->
			<!--{eval $mktyi = 0;}-->
			<!--{eval $mktycount = count($list['threadlist']);}-->
			<ul class="home-threadlist-c">
			<!--{loop $list['threadlist'] $key $thread}-->
				<!--{eval $mktyi++;}-->
				<!--{if $mktyi <= 25}-->
					<li class="hometl-block-show"><!--{subtemplate forum/guide_list_row}--></li>
				<!--{else}-->
					<li class="hometl-block-hide"><!--{subtemplate forum/guide_list_row}--></li>
				<!--{/if}-->
			<!--{/loop}-->
			</ul>
		<!--{else}-->
				<div class="mkty-emp">{lang guide_nothreads}</div>
		<!--{/if}-->
	<!--{/loop}-->
</div>



<!--{eval $page = intval($_GET['page'])}-->
<!--{eval $page = $page>0 ? $page : 1;}-->
<!--{eval $mktyPerpage = 25;}-->
<!--{eval $mktyThreadCount = $data[$_GET[view]]['threadcount'];}-->
<!--{eval $mktyTotalPage = @ceil($mktyThreadCount/$mktyPerpage);}-->
<!--{if $mktyTotalPage && $mktyTotalPage > 1}-->
	<div id="mikuty-getnextpage">查看更多...</div>
	<script src="template/miku_mobile_ty/static/js/getnextpage.js?{VERHASH}" charset="{CHARSET}"></script>
	<script type="text/javascript">
		if($('#mikuty-getnextpage').length > 0){
			var mkty_totalpage = {$mktyTotalPage};
			var mkty_nxt_isloading = false;
			var mkty_page = $page + 1;
			var mkty_curpage = $page + 1;
			var mkty_maxpage = mkty_totalpage > 4 ? 4 : mkty_totalpage;
			var mkty_nxtpgurl = 'forum.php?mod=guide&view={$view}&page=';
			mikuty_guide_getnextpage(mkty_nxtpgurl);
			
		}
	</script>
<!--{elseif $list['threadcount']}-->
	<div class="mikuty-nomore">已经到底了</div>
<!--{/if}-->




<div id="mikuty-scroll-menu">
	<a href="javascript:;" title="{lang scrolltop}" class="scrolltop">
		<span class="mkscm-down"><i class="mktyiconfont icon-zhankai6"></i></span>
		<span class="mkscm-up"><i class="mktyiconfont icon-shouqi2"></i></span>
	</a>
	<a href="javascript:;" title="{lang scrolltop}" id="mkty-scrollmenu" class="mkty-scrollmenu">
		<i class="mktyiconfont icon-wuxuliebiao"></i>
	</a>
</div>
<script>
	$("#mkty-scrollmenu").on('click', function(){
		$("#miku-ty-top-menu-body").css({'display':'block', 'top':'0'});
	});
</script>

<!--{eval $mktyfooter_menu = array('shouye'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->
