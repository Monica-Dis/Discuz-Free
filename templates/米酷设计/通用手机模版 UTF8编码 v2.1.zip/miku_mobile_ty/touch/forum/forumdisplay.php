<?php exit; ?>
<!--{template common/header}-->

<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>

<div id="mkty-crumb-body" style="display: none;">
	<div class="cmbn-list-wrap">
		<div class="cmbn-list">
			<a href="forum.php?mod=guide&view=new"><i class="mktyiconfont icon-shouye3"></i></a><em>&rsaquo;</em><a href="forum.php?forumlist=1">社区</a>$navigation
		</div>
	</div>
</div>

<!--{hook/forumdisplay_top_mobile}-->
<div class="forum-intro">
	<div class="intro-c">
		<div class="forum-icon">
			<!--{if $_G[forum][icon]}-->
				<img src="data/attachment/common/{$_G[forum][icon]}" alt="{$_G[forum][name]}" />
			<!--{else}-->
				<img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="{$_G[forum][name]}" />
			<!--{/if}-->
		</div>
		<div class="forum-info">
			<div class="info-right">
				<a class="post-btn" href="{if $_G[uid]}forum.php?mod=post&action=newthread&fid={$_G[fid]}{else}javascript:mktygotologin();{/if}" title="{lang send_threads}"><span>{lang send_threads}</span></a>
				<a class="forum-fav" href="javascript:;" onclick="{if $_G['uid']}favorite(this, 'home.php?mod=spacecp&ac=favorite&type=forum&id=$_G[fid]&handlekey=favoriteforum&formhash={FORMHASH}&inajax=1&check=1');{else}mktygotologin();{/if}">+ 订阅</a>
			</div>
			<div class="info-left">
				<span class="forum-name">
					{$_G[forum][name]}
				</span>
				<span class="chart cl">
					<!--{if !$subforumonly}-->
						<span>{lang index_threads}: {$_G[forum][threads]}</span>
						<span>{lang index_today}: {$_G[forum][todayposts]}</span>
					<!--{/if}-->
				</span>
			</div>
		</div>
	</div>
</div>
<script>
	function favorite(obj, url) {
	    $.ajax({
	        'type': 'GET',
	        'url': url,
	        'dataType': 'xml',
	    }).success(function(s) {
	    	var str = s.lastChild.firstChild.nodeValue;
	    	// var match = str.match(/errorhandle_favoriteforum/i);
	    	var match = str.match(/succeedhandle_favoriteforum/i);
	        if (match) {
	        	$(obj).text('已订阅');
	            popup.close();
	        } else {
	            popup.open(s.lastChild.firstChild.nodeValue, 'html');
	        }
	    }).error(function() {
	        popup.open('请求服务器失败', 'alert');
	    });
	    return false;
	}
</script>

<!--{if $subexists && $_G['page'] == 1}-->
<div class="forum-sublist">
	<div class="sublist-h"><span>子版块</span></div>
	<div class="sublist-c">
		<ul class="cl">
			<!--{loop $sublist $sub}-->
			<li class="item">
				<div class="img-icon">
					<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
					<!--{if $sub[icon]}-->
						$sub[icon]
					<!--{else}-->
						<img src="{IMGDIR}/forum{if $sub[folder]}_new{/if}.gif" alt="$sub[name]" />
					<!--{/if}-->
					</a>
				</div>
				<div class="forum-info">
					<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
						<span class="forum-name">{$sub['name']}</span>

						<!--{if $sub['redirect']}-->
							<span class="forum-num">{lang url_link}</span>
						<!--{else}-->
							<!--{if $sub[todayposts] && !$sub['redirect']}-->
								<span class="forum-num-today">{lang forum_todayposts}:($sub[todayposts])
							<!--{else}-->
								<span class="forum-num">
									帖子: <!--{echo dnumber($sub[posts])}-->
								</span>
							<!--{/if}-->
						<!--{/if}-->
					</a>
				</div>
				
				
			</li>
			<!--{/loop}-->
		</ul>
	</div>
</div>
<!--{/if}-->


<!--{if !$subforumonly}-->

	<div class="forum-tab-nav">
		<ul class="nav-c cl">
			<li class="item {if empty($_GET['filter'])}on{/if}">
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all}</a>
			</li>
			<li class="item {if $_GET['filter'] == 'lastpost'}on{/if}">
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"">{lang latest}</a>
			</li>
			<li class="item {if $_GET['filter'] == 'heat'}on{/if}">
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang order_heats}</a>
			</li>
			<li class="item {if $_GET['filter'] == 'digest'}on{/if}">
				<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang digest_posts}</a>
			</li>
		</ul>
	</div>
	<!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
		<div class="forum-threadtype"><div class="swiper-wrapper">
		
			<ul class="swiper-slide ftt-wrap">
				<li class="ftt-item {if !$_GET['typeid'] && !$_GET['sortid']}active{/if}">
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a>
				</li>
				<!--{if $_G['forum']['threadtypes']}-->
					<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
					<!--{if $_GET['typeid'] == $id}-->
						<li class="ftt-item active">
							<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="ftt-num">($showthreadclasscount[typeid][$id])</span><!--{/if}--></a>
						</li>
					<!--{else}-->
						<li class="ftt-item">
							<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name<!--{if $showthreadclasscount[typeid][$id]}--><span class="ftt-num">($showthreadclasscount[typeid][$id])</span><!--{/if}--></a>
						</li>
					<!--{/if}-->

					<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</div></div>
	<!--{/if}-->


	<div class="forum-threadlist">
			<div class="threadlist-c">
			<!--{if $_G['forum_threadcount']}-->
				<!--{eval require_once(DISCUZ_ROOT."/template/miku_mobile_ty/php/core.php");}-->
				<!--{eval $mktysummary = $miku_get_thread->getsummary($_G['forum_threadlist'], 96);}-->
				<!--{eval $mktyuserlv = $miku_get_thread->getlv($_G['forum_threadlist']);}-->
				

				<ul class="threadlist-c-top">

				<!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement)}-->
					<li class="item-top">
						<span class="icon-gonggao">公告</span>
						<!--{if empty($announcement['type'])}--><a href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]">$announcement[subject]</a><!--{else}--><a href="$announcement[message]">$announcement[subject]</a><!--{/if}-->
					</li>
				<!--{/if}-->

				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
                	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<!--{hook/forumdisplay_thread_mobile $key}-->

                	<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					<li class="item-top">
						<span class="icon-top">置顶</span>
						<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight] >
						{$thread[subject]}
						</a>
					</li>
					<!--{/if}-->
				<!--{/loop}-->
				</ul>

				<ul class="threadlist-c-normal">
				<!--{loop $_G['forum_threadlist'] $key $thread}-->
					<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
						{eval continue;}
					<!--{/if}-->
                	<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
                		{eval $displayorder_thread = 1;}
                    <!--{/if}-->
					<!--{if $thread['moved']}-->
						<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
					<!--{hook/forumdisplay_thread_mobile $key}-->

                	<!--{if !in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					<li class="item">
						<div class="author cl">
								<div class="avatar">
									<a href="home.php?mod=space&do=profile&uid=$thread[authorid]">
									<img src="{avatar($thread['authorid'], middle,true)}"/>
									</a>
								</div>
								<div class="author-info">
									<div class="ai-name cl">
									<!--{if $thread['authorid'] && $thread['author']}-->
										<a class="ai-uname" href="home.php?mod=space&do=profile&uid=$thread[authorid]">
											$thread[author]
										</a>
										<!--{if in_array($mktyuserlv[$thread[authorid]]['radminid'], array(1, 2, 3))}-->
											<span class="mkty-userlv-icon mkty-userlv-manager ai-ulv">
												$mktyuserlv[$thread[authorid]]['grouptitle']
											</span>
										<!--{else}-->
											<span class="mkty-userlv-icon mkty-userlv{$mktyuserlv[$thread[authorid]]['stars']} ai-ulv">
												Lv.{$mktyuserlv[$thread[authorid]]['stars']}
											</span>
										<!--{/if}-->
										<!--{if !empty($verify[$thread['authorid']])}--> 
											<span class="ai-verify">$verify[$thread[authorid]]</span>
										<!--{/if}-->
									<!--{else}-->
										<span class="ai-uname">$_G[setting][anonymoustext]</span>
									<!--{/if}-->
									</div>
									<div class="ai-time">$thread[dateline]</div>
								</div>
						</div>
						<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
							<div class="title">
								{if $thread[typename]}<span class="fttt-typename">[{$thread[typename]}]</span>{/if} 

								<!--{if $thread['special'] == 1}-->
								<span class="icon-special">投票</span>
								<!--{elseif $thread['special'] == 2}-->
								<span class="icon-special">商品</span>
								<!--{elseif $thread['special'] == 3}-->
								<span class="icon-special">悬赏</span>
								<!--{elseif $thread['special'] == 4}-->
								<span class="icon-special">活动</span>
								<!--{elseif $thread['special'] == 5}-->
								<span class="icon-special">辩论</span>
								<!--{/if}-->
								<!--{if $thread['price'] > 0}-->
									<!--{if $thread['special'] == '3'}-->
									<span class="icon-money"> <strong>$thread[price]</strong> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}</span>
									<!--{/if}-->
								<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
									<span class="icon-ok">{lang reward_solved}</span>
								<!--{/if}-->
								
								<!--{if $thread['digest'] > 0}--><span class="icon-digest">精</span><!--{/if}-->
								<span class="fttt-title" $thread[highlight]>{$thread[subject]}</span>
							</div>
							<div class="summary">
								<!--{if !($thread['price'] > 0 && $thread['special'] != '3')}-->
								{$mktysummary[$thread[tid]]}
								<!--{/if}-->
							</div>

							<!--{if $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
							<div class="img-list cl">						
								<!--{eval $piclist = $miku_get_thread->getpic($thread[tid]);}-->
								<!--{if count($piclist)==3}-->
									<!--{loop $piclist $pic}-->
										<!--{eval $url = getforumimg($pic['aid'], 0, 250, 200, 'fixwr');}-->
									<div style="float:left;width: 33.3%;overflow: hidden;">
										<div style="background:#f9f9f9;margin-right:3px;overflow: hidden;" class="mkimg-list-3">
											<img class="mktylazy" src="template/miku_mobile_ty/static/image/imgnone_a.gif" data-original="{$url}" width="100%" height="100%">
										</div>
									</div>
									<!--{/loop}-->
								<!--{elseif count($piclist)>=1}-->
									<!--{loop $piclist $pic}-->
										<!--{eval $url = getforumimg($pic['aid'], 0, 280, 165, 'fixwr');}-->
									<div style="float:left;width: 50%;overflow: hidden;">
										<div style="background:#f9f9f9;margin-right:3px;overflow: hidden;" class="mkimg-list-2">
										<img class="mktylazy" src="template/miku_mobile_ty/static/image/imgnone_b.gif" data-original="{$url}" width="100%" height="100%">
										</div>
									</div>
									<!--{/loop}-->
								<!--{/if}-->

							</div>
							<!--{/if}-->
						</a>
						<div class="info cl">
							<span class="views-num"><i class="mktyiconfont icon-chakan1"></i> {$thread[views]}</span>
							<span class="reply-num"><i class="mktyiconfont icon-31xiaoxi"></i> {$thread[replies]}</span>
							<span class="recommend-num"><i class="mktyiconfont icon-dianzan"></i> {$thread[recommend_add]}</span>
						</div>
					</li>
					<!--{/if}-->
                <!--{/loop}-->
            	</ul>
            <!--{else}-->
				<li class="mkty-emp">{lang forum_nothreads}</li>
			<!--{/if}-->
		</div>
	</div>

	<!--{eval $page = intval($_GET['page'])}-->
	<!--{eval $page = $page > 0 ? $page : 1;}-->
	<!--{eval $mktyTotalPage = @ceil($_G['forum_threadcount'] / $_G['tpp']);}-->
	<!--{if $page < $_G['page_next'] && !$subforumonly}-->
		<div id="mikuty-getnextpage">查看更多...</div>
		<script src="template/miku_mobile_ty/static/js/getnextpage.js?{VERHASH}" charset="{CHARSET}"></script>
		<script type="text/javascript">
			if($('#mikuty-getnextpage').length > 0){
				var mkty_nxt_isloading = false;
				var mkty_page = $page + 1;
				var mkty_maxpage = {$mktyTotalPage};
				var mkty_nxtpgurl = 'forum.php?mod=forumdisplay&fid={$_G[fid]}&filter={$filter}&orderby={$_GET[orderby]}{$forumdisplayadd[page]}&page=';
				mikuty_threadlist_getnextpage(mkty_nxtpgurl);
			}
		</script>
	<!--{elseif $_G['forum_threadcount']}-->
		<div class="mikuty-nomore">已经到底了</div>
	<!--{/if}-->

<!--{/if}-->
<!--{hook/forumdisplay_bottom_mobile}-->


<div id="mikuty-scroll-menu" style="height:140px;">
	<a href="javascript:;" title="{lang scrolltop}" class="scrolltop">
		<span class="mkscm-down"><i class="mktyiconfont icon-zhankai6"></i></span>
		<span class="mkscm-up"><i class="mktyiconfont icon-shouqi2"></i></span>
	</a>
	<a href="{if $_G[uid]}forum.php?mod=post&action=newthread&fid={$_G[fid]}{else}javascript:mktygotologin();{/if}" class="mkty-scrollpost" style="bottom: 0px;">
		<i class="mktyiconfont icon-yduibianxie"></i>
	</a>
	<a href="javascript:;" title="{lang scrolltop}" id="mkty-scrollmenu" class="mkty-scrollmenu" style="bottom: 48px;">
		<i class="mktyiconfont icon-wuxuliebiao"></i>
	</a>
</div>
<script>
	$("#mkty-scrollmenu").on('click', function(){
		$("#miku-ty-top-menu-body").css({'display':'block', 'top':'0'});
	});
</script>

<!--{eval $mktyfooter_menu = array('shequ'=>true);}-->
<!--{subtemplate common/footer_menu}-->


<!--{template common/footer}-->
