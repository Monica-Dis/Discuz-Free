<?php exit; ?>
<div class="post-reward-form">
	<!--{if $_GET[action] == 'newthread'}-->
		<div class="prf-box cl">
			<div class="prf-name">
				<label for="rewardprice">{lang reward_price}</label>
			</div>
			<div class="prf-input">
				<p>
					<input type="text" name="rewardprice" id="rewardprice" class="px" size="6" onkeyup="getrealprice(this.value)" value="{$_G['group']['minrewardprice']}" tabindex="1" /> 
					{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
					 , {lang reward_tax_after} <strong id="realprice">0</strong> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
				</p>
				<div class="prf-tips">
					{lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
					<!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
					, {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
				</div
			</div>
		</div>

	<!--{elseif $_GET[action] == 'edit'}-->
		<!--{if $isorigauthor}-->
			<!--{if $thread['price'] > 0}-->
			<div class="prf-box cl">
				<div class="prf-name">
					<label for="rewardprice">{lang reward_price}:</label>
				</div>
				<div class="prf-input">
					<p>
						<input type="text" name="rewardprice" id="rewardprice" class="px" onkeyup="getrealprice(this.value)" size="6" value="$rewardprice" tabindex="1" />
						{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
						, {lang reward_tax_add} <strong id="realprice">0</strong> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
					</p>
					<p class="prf-tips">
						{lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
						<!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
						, {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
					</p>
				</div>
			</div>
			<!--{else}-->
				<p class="prf-over">
					{lang post_reward_resolved}
					<input type="hidden" name="rewardprice" value="$rewardprice" tabindex="1" />
				</p>
			<!--{/if}-->
		<!--{else}-->
			<!--{if $thread['price'] > 0}-->
			<div class="prf-box cl">
				<div class="prf-name">{lang reward_price}</div>
				<div class="prf-input">
					<p>$rewardprice {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</p>
					<div class="prf-tips"></div>
				</div>

			</div>
			<!--{else}-->
				<p class="prf-over">{lang post_reward_resolved}</p>
			<!--{/if}-->
		<!--{/if}-->
	<!--{/if}-->

	<!--{if $_G['setting']['rewardexpiration'] > 0}-->
		<p class="prf-warn">$_G['setting']['rewardexpiration'] {lang post_reward_message}</p>
	<!--{/if}-->

</div>
<script type="text/javascript" reload="1">
function getrealprice(price){
	var realprice = $('#realprice')[0];

	if(!price.search(/^\d+$/) ) {
		n = Math.ceil(parseInt(price) + price * $_G['setting']['creditstax']);
		if(price > 32767) {
			realprice.innerHTML = '<b>{lang reward_price_overflow}</b>';
		}<!--{if $_GET[action] == 'edit'}-->	else if(price < $rewardprice) {
			realprice.innerHTML = '<b>{lang reward_cant_fall}</b>';
		}<!--{/if}--> else if(price < $_G['group']['minrewardprice'] || ($_G['group']['maxrewardprice'] > 0 && price > $_G['group']['maxrewardprice'])) {
			realprice.innerHTML = '<b>{lang reward_price_bound}</b>';
		} else {
			realprice.innerHTML = n;
		}
	}else{
		realprice.innerHTML = '<b>{lang input_invalid}</b>';
	}
}
if($('#rewardprice')[0]) {
	getrealprice($('#rewardprice')[0].value)
}
</script>