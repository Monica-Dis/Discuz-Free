<?php exit; ?>
<div class="reward-thread cl">
	<div class="reward-info{if $_G['forum_thread']['price'] < 0} rwd-ok{/if}">
		<!--{if $_G['forum_thread']['price'] > 0}-->
			<!--{if $_G['forum_thread']['price'] > 0 && !$_G['forum_thread']['is_archived']}-->
		 	<span class="rwd-btn">	
				<a name="answer" href='forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]{if $_GET[from]}&from=$_GET[from]{/if}')">{lang reward_answer}</a>
			</span>
			<!--{/if}-->
		<!--{/if}-->
		<div class="r-price">
			{lang thread_reward} 
			<strong> $rewardprice </strong>
			{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]} , 
			<!--{if $_G['forum_thread']['price'] > 0}-->
			 {lang unresolved}
			<!--{elseif $_G['forum_thread']['price'] < 0}-->
			 {lang resolved}
			<!--{/if}-->
		</div>
	</div>
	<div id="postmessage_$post[pid]" class="postmessage">
		$post[message]
	</div>
</div>


<!--{if $post['attachment']}-->
	<div class="warning">{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em></div>
<!--{elseif $post['imagelist'] || $post['attachlist']}-->
    <!--{if $post['imagelist']}-->
         {echo showattach($post, 1)}
    <!--{/if}-->
    <!--{if $post['attachlist']}-->
         {echo showattach($post)}
    <!--{/if}-->
<!--{/if}-->
<!--{eval $post['attachment'] = $post['imagelist'] = $post['attachlist'] = '';}-->

<!--{if $bestpost}-->
	<div class="reward-bst">
		<h3 class="rh3">{lang reward_bestanswer}</h3>
		<div class="r-post">
			<div class="r-psta">$bestpost[avatar]</div>
			<div class="r-psti">
				<p class="xi2"><a href="home.php?mod=space&uid=$bestpost[authorid]" class="xw1">$bestpost[author]</a> <a href="javascript:;" onclick="window.open('forum.php?mod=redirect&goto=findpost&ptid=$bestpost[tid]&pid=$bestpost[pid]')">{lang view_full_content}</a></p>
				<div class="mtn">$bestpost[message]</div>
			</div>
		</div>
	</div>
<!--{/if}-->