<?php exit; ?>
{eval
function tpl_hide_credits_hidden($creditsrequire) {
global $_G;
}
<!--{block return}--><div class="locked"><!--{if $_G[uid]}-->{$_G[username]}<!--{else}-->{lang guest}<!--{/if}-->{lang post_hide_credits_hidden}</div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_hide_credits($creditsrequire, $message) {
}
<!--{block return}--><div class="locked">{lang post_hide_credits}</div>
$message<br /><br />
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_codedisp($code) {
}
<!--{block return}--><div class="blockcode"><div><ol><li>$code</ol></div></div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_quote() {
}
<!--{block return}--><div class="grey quote"><blockquote>{lang e_quote}: \\1</blockquote></div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_free() {
}
<!--{block return}--><div class="grey quote q-free"><blockquote>\\1</blockquote></div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_hide_reply() {
global $_G;
}
<!--{block return}--><div class="showhide"><h4>{lang post_hide}</h4>\\1</div>
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_hide_reply_hidden() {
global $_G;
}
<!--{block return}--><div class="locked"><!--{if $_G[uid]}-->{$_G[username]}<!--{else}-->{lang guest}<!--{/if}-->{lang post_hide_reply_hidden}</div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function attachlist($attach) {
global $_G;
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G[forum_thread][archiveid] : '';
}
<!--{block return}-->

<div class="box box_ex2 attach-mbn">
	<dd>
		<p class="attnm">
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
				$attach[attachicon]
			<!--{/if}-->
			<!--{if !$attach['price'] || $attach['payed']}-->
				<a href="forum.php?mod=attachment{$is_archive}&aid=$aidencode" id="aid$attach[aid]" >$attach[filename]</a>
			<!--{else}-->
				<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]">$attach[filename]</a>
			<!--{/if}-->
			<span class="xg1">($attach[dateline] {lang upload})</span>
		</p>
		<p class="xg1">$attach[attachsize]<!--{if $attach['readperm']}-->, {lang readperm}: <strong>$attach[readperm]</strong><!--{/if}-->, {lang downloads}: $attach[downloads]<!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->, {lang attachcredits}: $_G[getattachcredits]<!--{/if}--></p>
		<!--{if $attach['description']}--><p class="xg2">{$attach[description]}</p><!--{/if}-->
		<p>
			<!--{if $attach['price']}-->
				{lang price}: <strong>$attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</strong> &nbsp;
				<!--{if !$attach['payed']}-->
					&nbsp;[<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" >{lang attachment_buy}</a>]
				<!--{/if}-->
			<!--{/if}-->
		</p>
	</dd>
</div>
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function imagelist($attach) {
global $_G, $post;
$fix = count($post[imagelist]) == 1 ? 750 : 750;
$fixtype = count($post[imagelist]) == 1 ? 'fixnone' : 'fixwr';
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$mobilethumburl = $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) ? getforumimg($attach['aid'], 0, 750, 1334, 'fixnone') : '' ;
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G[forum_thread][archiveid] : '';
$guestviewthumb = !empty($_G['setting']['guestviewthumb']['flag']) && !$_G['uid'];
}
<!--{block return}-->
	<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && (($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) || ($guestviewthumb))}-->
		<!--{if !$guestviewthumb}-->
			<!--{if !$attach['price'] || $attach['payed']}-->
				<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
				<li><a href="forum.php?mod=viewthread&tid=$attach[tid]&aid=$attach[aid]&from=album&page=$_G[page]" class="img-box"><img id="aimg_$attach[aid]" class="mktylazy-post" src="template/miku_mobile_ty/static/image/load-post.gif" data-original="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" /></a>
				</li>
				<!--{/if}-->
			<!--{/if}-->
		<!--{/if}-->

		<!--{if $guestviewthumb}-->
			<!--{eval}-->
			<!--
				$thumbpath = helper_attach::attachpreurl().'image/'.helper_attach::makethumbpath($attach['aid'], 250, 250);
				$makefile = 'forum.php?mod=image&aid='.$attach['aid'].'&size=250x250&key='.dsign($attach['aid'].'|250|250').'&type=1';
			-->
			<!--{/eval}-->
			<style type="text/css">
				.guestviewthumb {margin:10px auto; text-align:center;}.guestviewthumb a {font-size:13px;color: #44718a; text-decoration:underline;}.guestviewthumb_cur { max-width:150px!important;;}.ie6 .guestviewthumb_cur { width:150px!important;}
			</style>
			<div class="guestviewthumb">
				<img id="aimg_$attach[aid]" class="guestviewthumb_cur" aid="$attach[aid]" src="$thumbpath" onclick="mktygotologin()" onerror="javascript:if(this.getAttribute('makefile')){this.src=this.getAttribute('makefile'); this.removeAttribute('makefile');}" file="$thumbpath" makefile="$makefile" alt="$attach[imgalt]" title="$attach[imgalt]"/><br><a href="javascript:;" onclick="mktygotologin();">{lang guestviewthumb}</a>
			</div>
		<!--{/if}-->

	<!--{/if}-->
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function attachinpost($attach) {
global $_G;
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$mobilethumburl = $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) ? getforumimg($attach['aid'], 0, 750, 1334, 'fixnone') : '' ;
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? '&fid='.$_G['fid'].'&archiveid='.$_G[forum_thread][archiveid] : '';
$guestviewthumb = !empty($_G['setting']['guestviewthumb']['flag']) && !$_G['uid'];
}
<!--{block return}-->
	<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && (($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) || ($guestviewthumb))}-->
		<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0 && !$guestviewthumb}-->
		<a href="forum.php?mod=viewthread&tid=$attach[tid]&aid=$attach[aid]&from=album&page=$_G[page]" class="img-box"><img id="aimg_$attach[aid]" src="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" /></a>
		<!--{/if}-->
		
		<!--{if $guestviewthumb}-->
			<!--{eval}-->
			<!--
				$thumbpath = helper_attach::attachpreurl().'image/'.helper_attach::makethumbpath($attach['aid'], 250, 250);
				$makefile = 'forum.php?mod=image&aid='.$attach['aid'].'&size=250x250&key='.dsign($attach['aid'].'|250|250').'&type=1';
			-->
			<!--{/eval}-->
			<style type="text/css">
				.guestviewthumb {margin:10px auto; text-align:center;}.guestviewthumb a {font-size:13px; color: #44718a; text-decoration:underline;}.guestviewthumb_cur{ max-width:150px!important;;}.ie6 .guestviewthumb_cur { width:150px!important;}
			</style>
			<div class="guestviewthumb">
				<div style="margin: 0 auto;">
					<img id="aimg_$attach[aid]" class="guestviewthumb_cur" aid="$attach[aid]" src="$thumbpath" onclick="mktygotologin()" onerror="javascript:if(this.getAttribute('makefile')){this.src=this.getAttribute('makefile'); this.removeAttribute('makefile');}" file="$thumbpath" makefile="$makefile" inpost="1" alt="$attach[imgalt]" title="$attach[imgalt]"/><br><a href="javascript:;" onclick="mktygotologin();">{lang guestviewthumb}</a>
				</div>
			</div>
		<!--{/if}-->

	<!--{else}-->
		<div id="attach_$attach[aid]" class="attach-mbn" >
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
			$attach[attachicon]
			<!--{/if}-->
			<!--{if !$attach['price'] || $attach['payed']}-->
				<a href="forum.php?mod=attachment{$is_archive}&aid=$aidencode" >$attach[filename]</a>
			<!--{else}-->
				<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]">$attach[filename]</a>
			<!--{/if}-->
			<em class="xg1">($attach[attachsize])</em>
			<em class="xg1"><br />({lang downloads}: $attach[downloads], $attach[dateline] {lang upload})
			</em>
			<!--{if !$attach['attachimg'] && $_G['getattachcredits']}--><p>{lang attachcredits}: $_G[getattachcredits]</p><!--{/if}-->
			<p>
				<!--{if $attach['price']}-->
					{lang price}: <strong>$attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</strong> &nbsp;
					<!--{if !$attach['payed']}-->
						&nbsp;[<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]">{lang attachment_buy}</a>]
					<!--{/if}-->
				<!--{/if}-->
			</p>
		</div>
	<!--{/if}-->
<!--{/block}-->
<!--{eval return $return;}-->
<!--{eval
}

}-->
