<?php exit; ?>
<!--{if $_G['setting']['mobile']['mobilehotthread'] && $_GET['forumlist'] != 1}-->
	<!--{eval dheader('Location:forum.php?mod=guide&view=new');exit;}-->
<!--{/if}-->
<!--{template common/header}-->

<script type="text/javascript">
	function getvisitclienthref() {
		var visitclienthref = '';
		if(ios) {
			visitclienthref = 'https://itunes.apple.com/cn/app/zhang-shang-lun-tan/id489399408?mt=8';
		} else if(andriod) {
			visitclienthref = 'http://www.discuz.net/mobile.php?platform=android';
		}
		return visitclienthref;
	}
</script>

<!--{if $_GET['visitclient']}-->

<header class="header">
    <div class="nav">
		<span>{lang warmtip}</span>
    </div>
</header>
<div class="cl">
	<div class="clew_con">
		<h2 class="tit">{lang zsltmobileclient}</h2>
		<p>{lang visitbbsanytime}<input class="redirect button" id="visitclientid" type="button" value="{lang clicktodownload}" href="" /></p>
		<h2 class="tit">{lang iphoneandriodmobile}</h2>
		<p>{lang visitwapmobile}<input class="redirect button" type="button" value="{lang clicktovisitwapmobile}" href="$_GET[visitclient]" /></p>
	</div>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
	} else {
		window.location.href = '$_GET[visitclient]';
	}
</script>

<!--{else}-->

<!-- header start -->
<!--{if $showvisitclient}-->

<div class="visitclienttip vm" style="display:block;">
	<a href="javascript:;" id="visitclientid" class="btn_download">{lang downloadnow}</a>	
	<p>
		{lang downloadzslttoshareview}
	</p>
</div>
<script type="text/javascript">
	var visitclienthref = getvisitclienthref();
	if(visitclienthref) {
		$('#visitclientid').attr('href', visitclienthref);
		$('.visitclienttip').css('display', 'block');
	}
</script>

<!--{/if}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				{$mikuty_c_sitename}
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>



<div class="forum-ad-1">
	{$mikuty_c_forumad}
</div>
<div class="forum-chart cl">
	<ul>
		<li class="item">
			<span>今日发帖</span>
			<em>$todayposts</em>
		</li>
		<li  class="item">
			<span>全部帖子</span>
			<em>$posts</em>
		</li>
		<li  class="item">
			<span>会员</span>
			<em>$_G['cache']['userstats']['totalmembers']</em>
		</li>
	</ul>
</div>
<!--{if empty($gid) && $announcements}-->
	<div id="forum-an">
		<div class="title"><span>公告</span></div>
		<div class="forum-an-list">
			<ul class="swiper-wrapper">
			<!--{loop $_G['cache']['announcements']  $announcement}-->
				<!--{if !$announcement['endtime'] || $announcement['endtime'] > TIMESTAMP && (empty($announcement['groups']) || in_array($_G['member']['groupid'], $announcement['groups']))}-->
					<!--{if empty($announcement['type'])}-->
						<li class="swiper-slide">
							<a href="forum.php?mod=announcement&id={$announcement['id']}" target="_self">
								{$announcement['subject']}
							</a>
						</li>
					<!--{elseif $announcement['type'] == 1}-->
						<li class="swiper-slide">
							<a href="{$announcement['message']}" target="_self" >{$announcement['subject']}</a>
						</li>
					<!--{/if}-->
				<!--{/if}-->
			<!--{/loop}-->
			</ul>
		</div>
	</div>
	<script>
		var miku_homeSwiper = new Swiper('.forum-an-list', {
			direction: 'vertical',
	        loop: true,
	        speed: 1000,
	        autoplay: 4000,
		})
	</script>
<!--{/if}-->


<!--{hook/index_top_mobile}-->
<div class="forum-catlist" id="wp">
	<!--{loop $catlist $key $cat}-->
	<div class="fcl-item">
		<div class="subforumshow cat-header cl" href="#sub_forum_$cat[fid]">
			<span class="right-btn">
			<!--{if !$_G[setting][mobile][mobileforumview]}-->
				<i class="mktyiconfont icon-liebiaozhankai"></i>
			<!--{else}-->
				<i class="mktyiconfont icon-liebiaoshouqi"></i>
			<!--{/if}-->
			</span>
			<h2><span>$cat[name]</span></h2>
		</div>
		<div id="sub_forum_$cat[fid]" class="sub_forum cat-content">
			<ul class="cl">
				<!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->

				<!--{if $cat['forumcolumns']}-->
					<li class="fcls-two cl">
						<div class="fcls-wrap">
							<div class="cat-icon">
								<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
									<!--{if $forum[icon]}-->
										$forum[icon]
									<!--{else}-->
										<img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]"/>
									<!--{/if}-->
								</a>
							</div>
							<div class="cat-info">
								<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
									<span class="cat-name">
										{$forum[name]}
									</span>
									<span class="cat-comment">	
										<!--{if $forum[todayposts] > 0}-->
											<span style="color:#f68535">今日:  {$forum[todayposts]}</span>
										<!--{else}-->
											帖数: <!--{echo dnumber($forum[posts])}-->
										<!--{/if}-->
									</span>
								</a>
							</div>
						</div>
					</li>
				<!--{else}-->
					<li class="fcls-one cl">
						<div class="cat-icon">
							<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
								<!--{if $forum[icon]}-->
									$forum[icon]
								<!--{else}-->
									<img src="{IMGDIR}/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]"/>
								<!--{/if}-->
							</a>
						</div>
						<div class="cat-info">
							<div class="right-info">
								<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
									<!--{if $forum[todayposts] > 0}-->
										<span class="cat-time">
											<!--{if is_array($forum['lastpost'])}-->
												<!--{eval $catTime = preg_replace('/(\d\d\d\d-\d\d?-\d\d?) \d\d?:\d\d?/', '\1', $forum[lastpost][dateline]);}-->
												{$catTime}
											<!--{/if}-->
										</span>
										<span class="cat-num">
											<span class="today-num">$forum[todayposts]</span>
										</span>
									<!--{else}-->
										<span class="cat-time">
											
										</span>
										<span class="cat-num">
											<!--{if is_array($forum['lastpost'])}-->
												<!--{eval $catTime = preg_replace('/(\d\d\d\d-\d\d?-\d\d?) \d\d?:\d\d?/', '\1', $forum[lastpost][dateline]);}-->
												{$catTime}
											<!--{/if}-->
										</span>
									<!--{/if}-->
									</span>
								</a>
							</div>
							<div class="left-info">
								<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
									<span class="cat-name">
										{$forum[name]}
									</span>
									<span class="cat-comment">	
										<!--{if is_array($forum['lastpost'])}-->
											 <i class="mktyiconfont icon-31xiaoxi"></i><!--{echo cutstr($forum[lastpost][subject], 30)}--> 
										<!--{else}-->
											主题： <!--{echo dnumber($forum[threads])}--> / <!--{echo dnumber($forum[posts])}-->
										<!--{/if}-->
									</span>
								</a>
							</div>
						</div>
					</li>
				<!--{/if}-->
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{/loop}-->
</div>

<!--{hook/index_middle_mobile}-->
<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
			$('.sub_forum').css('display', 'block');
		<!--{else}-->
			$('.sub_forum').css('display', 'none');
		<!--{/if}-->
		$('.subforumshow').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');

				obj.find('.right-btn').html('<i class="mktyiconfont icon-liebiaozhankai"></i>');
			} else {
				subobj.css('display', 'none');
				obj.find('.right-btn').html('<i class="mktyiconfont icon-liebiaoshouqi"></i>');
			}
		});
	 })();
</script>

<!--{/if}-->

<div id="mikuty-scroll-menu">
	<a href="javascript:;" title="{lang scrolltop}" class="scrolltop">
		<span class="mkscm-down"><i class="mktyiconfont icon-zhankai6"></i></span>
		<span class="mkscm-up"><i class="mktyiconfont icon-shouqi2"></i></span>
	</a>
	<a href="javascript:;" title="{lang scrolltop}" id="mkty-scrollmenu" class="mkty-scrollmenu">
		<i class="mktyiconfont icon-wuxuliebiao"></i>
	</a>
</div>
<script>
	$("#mkty-scrollmenu").on('click', function(){
		$("#miku-ty-top-menu-body").css({'display':'block', 'top':'0'});
	});
</script>
<!--{eval $mktyfooter_menu = array('shequ'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->
