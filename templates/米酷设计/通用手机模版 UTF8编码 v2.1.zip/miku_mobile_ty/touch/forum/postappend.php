<?php exit; ?>
<!--{template common/header}-->

<div class="postappend-box">
	<form method="post" autocomplete="off" id="postappendform" action="forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$_GET[pid]&extra=$extra{if !empty($_GET[page])}&page=$_GET[page]{/if}&postappendsubmit=yes&infloat=yes" onsubmit="mktypostappend_post(this);return false;">
		<div class="f_c">

			<!-- 3.1、标题区域 -->
			<h3 class="pab-title">
				<!-- 补充 -->
				<em id="return_$_GET['handlekey']">帖子补充内容</em>
			</h3>
			<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
			<input type="hidden" name="handlekey" value="$_GET['handlekey']" />
			
			<!-- 3.2、主体区域 -->
			<div class="pab-body">
				<!-- 简单型编辑器区域 -->
				<div class="tedt">
					<!-- 编辑器的内容输入区域 -->
					<div class="area">
						<textarea rows="2" name="postappendmessage" id="postappendmessage" tabindex="2" class="pab-txt" style="overflow: auto" placeholder="请输入补充内容（200字符内）"></textarea>
					</div>
				</div>

				<!-- 验证码区域 -->
				<!--{if $secqaacheck || $seccodecheck}-->
					<!--{block sectpl}--><sec>: <span id="sec<hash>" onclick="showMenu({'ctrlid':this.id,'win':'{$_GET[handlekey]}'})"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
					<div class="mtm"><!--{subtemplate common/seccheck}--></div>
				<!--{/if}-->
			</div>

			<!-- 3.3、提交按钮区域 -->
			<div class="pab-footer">
				<!-- 发布按钮 -->
				<button type="submit" id="postappendsubmit" class="pab-ok ap_n" value="true" name="postappendsubmit">{lang publish}</button>
				<input type="buttom" onclick="popup.close();return false;" class="pab-close ap_n" value="取消"/>
			</div>
		</div>
	</form>
</div>




<!--{template common/footer}-->