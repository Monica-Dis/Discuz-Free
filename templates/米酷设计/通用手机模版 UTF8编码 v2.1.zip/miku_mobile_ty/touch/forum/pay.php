<?php exit; ?>
<!--{template common/header}-->


<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				购买主题
			</li>

			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>
<div class="thread-pay-box">
	<form id="payform" method="post" autocomplete="off" action="forum.php?mod=misc&action=pay&paysubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}">
		<div class="f_c">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="tid" value="$_G[tid]" />
			<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
			<ul>
				<li class="tpb-item">
					<div class="tpb-name">{lang author}</div>
					<div class="tpb-value">
						<a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">$thread[author]</a>
					</div>
				</li>
				<li class="tpb-item">
					<div class="tpb-name">
						{lang price}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})
					</div>
					<div class="tpb-value">
						$thread[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}
					</div>
				</li>
				<li class="tpb-item">
					<div class="tpb-name">
						{lang pay_author_income}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})
					</div>
					<div class="tpb-value">
						$thread[netprice] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}
					</div>
				</li>
				<li class="tpb-item">
					<div class="tpb-name">
						{lang pay_balance}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})
					</div>
					<div class="tpb-value">
						$balance {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}
					</div>
				</li>
			</ul>
		</div>
		<div class="tpb-btn">
			<button type="submit" name="paysubmit" class="pn pnc" value="true"><span>确认购买</span></button>
		</div>
	</form>
</div>
<!--{template common/footer}-->