<?php exit; ?>
<!--{eval $_G[forum_thread][special] = 0;}-->
<!-- main postlist start -->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
     <div class="postlist-c cl" id="pid$post[pid]">
        <div class="author cl{if $post['first']} first-post{/if}">
            <div class="avatar"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, middle, true)}--><!--{else}--><!--{avatar($post[authorid], middle, true)}--><!--{/if}-->"/></div>
            <div class="info">
                    <!--{if $post[first]}-->
                        <div class="right-links">
                            <!--{if $_G['forum']['ismoderator']}-->
                                <span><a href="javascript:;" onclick="mktyShowUserManager('#moption_$post[pid]');"class="opl-mng"><i class="mktyiconfont icon-shezhi"></i></a></span>
                                <div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
                                    <!--{if !$_G['forum_thread']['special']}-->
                                    <input type="button" value="{lang edit}" class="redirect button ap_n" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
                                    <!--{/if}-->
                                    <input type="button" value="{lang delete}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
                                    <input type="button" value="{lang close}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
                                    <input type="button" value="{lang admin_banpost}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
                                    <input type="button" value="{lang topicadmin_warn_add}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
                                </div>
                            <!--{else}-->
                                
                                <!--{if !$_G['forum_thread']['archiveid'] && $_G['uid']}-->
                                    <span class="user-manager">
                                        <a href="javascript:;" onclick="mktyShowUserManager('#moptionuser_$post[pid]');"><i class="mktyiconfont icon-gengduo"></i></a>
                                    </span>
                                    <div id="moptionuser_$post[pid]" class="user-manager-body-wrap" style="display:none;">
                                        <div class="user-manager-body">
                                            <!-- 回复 -->
                                            <!--{if $post[first]}-->
                                                <span>
                                                    <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&extra=$_GET[extra]&page=$page">回复</a>
                                                </span>
                                            <!--{/if}-->
                                            <!-- “添加柜台介绍” or “编辑”按钮” -->
                                            <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
                                                <a class="editp" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}</a><!--{/if}-->
                                            <!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
                                                <!-- “补充”按钮 -->
                                                <a class="appendp" href="javascript:mktypostappend('forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page');">{lang postappend}</a>
                                            <!--{/if}-->
                                            <!--{if $post['invisible'] == 0}-->
                                                <!-- “举报”按钮 -->
                                                <!--{if $post['authorid'] != $_G['uid']}-->
                                                    <a href="javascript:;" onclick="mktyreport('miscreport$post[pid]', 'misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]');return false;">{lang report}</a>
                                                <!--{/if}-->
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                <!--{else}-->
                                    <span class="fpif y">楼主</span>
                                <!--{/if}-->
                            <!--{/if}-->

                        </div>
                    <!--{else}-->
                        <div class="right-tag">
                            <!--{if isset($post[isstick])}-->
                                <img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> {lang from} {$post[number]}{$postnostick}
                            <!--{elseif $post[number] == -1}-->
                                {lang recommend_post}
                            <!--{else}-->
                                <!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}-->
                            <!--{/if}-->
                        </div>
                    <!--{/if}-->
                    <!--{block authorverifys}-->
                        <!--{loop $post['verifyicon'] $vid}-->
                            <a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $_G['setting']['verify'][$vid]['icon']}--><img src="$_G['setting']['verify'][$vid]['icon']" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /><!--{else}-->$_G['setting']['verify'][$vid]['title']<!--{/if}--></a>
                        <!--{/loop}-->
                    <!--{/block}-->
                    
                    <div class="name cl">
                        <div class="plsn-top cl">
                            <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                                <a class="pls-uname" href="home.php?mod=space&do=profile&uid=$post[authorid]">$post[author]</a>
                                    <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
                                    <!--{if $_self}-->
                                        <span class="pls-lz-icon">楼主</span>
                                    <!--{/if}-->
                                    <!--{if in_array($post['adminid'], array(1, 2, 3))}-->
                                        <span class="mkty-userlv-icon mkty-userlv-manager pls-ulv">
                                            {$post['authortitle']}
                                        </span>
                                    <!--{else}-->
                                        <span class="mkty-userlv-icon mkty-userlv{$post['stars']} pls-ulv">
                                            Lv.{$post['stars']}
                                        </span>
                                    <!--{/if}-->
                                    <span class="pls-verify">{$authorverifys}</span>
                                    
                            <!--{else}-->

                                <!--{if !$post['authorid']}-->
                                <a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
                                <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                                <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&do=profile&uid=$post[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
                                <!--{else}-->
                                $post[author] <em>{lang member_deleted}</em>
                                <!--{/if}-->
                            <!--{/if}-->
                        </div>
                        <div class="plsn-bottom cl">
                            <span class="time">$post[dateline]</span>
                        </div>
                    </div>
                    
            </div>      
        </div>
        


        <div class="display pi" href="#replybtn_$post[pid]">
            <div class="message{if $post['first']} first-post{/if}">
                <!--{if $post['warned']}-->
                    <span class="warning-quote">{lang warn_get}</span>
                <!--{/if}-->
                <!--{if !$post['first'] && !empty($post[subject])}-->
                    <h2><strong>$post[subject]</strong></h2>
                <!--{/if}-->
                <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                    <div class="warning-quote">{lang message_banned}</div>
                <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                    <div class="warning-quote">{lang message_single_banned}</div>
                <!--{elseif $needhiddenreply}-->
                    <div class="warning-quote">{lang message_ishidden_hiddenreplies}</div>
                <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
                    <!--{template forum/viewthread_pay}-->
                <!--{elseif $_G['forum_discuzcode']['passwordlock'][$post[pid]]}-->
                    <script type="text/javascript"  src="static/js/md5.js?{VERHASH}"></script>
                    <script type="text/javascript"  src="template/miku_mobile_ty/static/js/viewthread.js?{VERHASH}"></script>
                    <div class="locked">
                        {lang message_password_exists} {lang pleaseinputpw}
                        <p>
                            <input type="text" id="postpw_$post[pid]" class="lpw-px ap_n" />&nbsp;
                            <button class="lpw-pn" type="button" onclick="submitpostpw($post[pid]{if $_GET['from'] == 'preview'},{$post[tid]}{else}{/if})">{lang submit}</button>
                        </p>
                    </div>
                <!--{else}-->

                    <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                        <div class="warning-quote">{lang admin_message_banned}</div>
                    <!--{elseif $post['status'] & 1}-->
                        <div class="warning-quote">{lang admin_message_single_banned}</div>
                    <!--{/if}-->

                    <!--{if $_G['forum_discuzcode']['passwordauthor'][$post[pid]]}-->
                        <div class="locked">{lang message_password_exists}</div>
                    <!--{/if}-->
                    <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                        <div class="locked">
                         {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <em class="y">已购买</em>
                        </div>
                    <!--{/if}-->
                    
                
                    <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                        <!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                            <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                {lang has_expired}
                            <!--{else}-->
                                <div class="box_ex2 viewsort">
                                    <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                                <!--{loop $threadsortshow['optionlist'] $option}-->
                                    <!--{if $option['type'] != 'info'}-->
                                        $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                                    <!--{/if}-->
                                <!--{/loop}-->
                                </div>
                            <!--{/if}-->
                        <!--{/if}-->
                    <!--{/if}-->
                    <!--{if $post['first']}-->
                        <!--{if !$_G[forum_thread][special]}-->
                            $post[message]
                        <!--{elseif $_G[forum_thread][special] == 1}-->
                            <!--{template forum/viewthread_poll}-->
                        <!--{elseif $_G[forum_thread][special] == 2}-->
                            <!--{template forum/viewthread_trade}-->
                        <!--{elseif $_G[forum_thread][special] == 3}-->
                            <!--{template forum/viewthread_reward}-->
                        <!--{elseif $_G[forum_thread][special] == 4}-->
                            <!--{template forum/viewthread_activity}-->
                        <!--{elseif $_G[forum_thread][special] == 5}-->
                            <!--{template forum/viewthread_debate}-->
                        <!--{elseif $threadplughtml}-->
                            $threadplughtml
                            $post[message]
                        <!--{else}-->
                            $post[message]
                        <!--{/if}-->
                    <!--{else}-->
                        $post[message]
                    <!--{/if}-->

                    <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                        <!--{if $post['attachment']}-->
                           <div class="postlist-tips">
                           {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
                           </div>
                        <!--{elseif $post['imagelist'] || $post['attachlist']}-->
                           <!--{if $post['imagelist']}-->
                            <!--{if count($post['imagelist']) == 1}-->
                            <ul class="postlist-vm-imglist img_one">{echo showattach($post, 1)}</ul>
                            <!--{else}-->
                            <ul class="postlist-vm-imglist img_list cl vm">{echo showattach($post, 1)}</ul>
                            <!--{/if}-->
                            <!--{/if}-->
                            <!--{if $post['attachlist']}-->
                            <ul class="postlist-vm-attach-list">{echo showattach($post)}</ul>
                            <!--{/if}-->
                        <!--{/if}-->
                    <!--{/if}-->
                <!--{/if}-->




            </div>
            
        </div>
        <!--{if $post[first]}-->
        <div class="thread-tail">
            <div class="thread-copyright">
                著作权归原作者所有，未经许可不得转载
            </div>

            <!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
            <div class="zan">
                <a href="javascript:;" {if $_G[uid]}onclick="recommend(this, 'forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}&inajax=1&check=1');"{else}onclick="mktygotologin()"{/if}>
                    <i class="mktyiconfont icon-shangpintuijian"></i>
                </a>
                <span class="num">
                    <span class="zan-num">{if $_G['forum_thread']['recommend_add']}{$_G['forum_thread']['recommend_add']}{/if}</span>
                    赞
                </span>
            </div>
            <!--{/if}-->
        </div>
        <!--{/if}-->
        <!--{if !$post[first]}-->
       <div class="post-info">
            <!-- <span class="time">$post[dateline]</span> -->
            
            <div class="op-links">
                <!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
                    <a class="tag1" href="javascript:;" onclick="setanswer($post['pid'], '$_GET[from]')">
                        最佳答案
                    </a>
                <!--{/if}-->

                <!--{if $_G['forum']['ismoderator']}-->
                    <span class="opl-manager">
                        <a href="javascript:;" onclick="mktyShowUserManager('#moption_$post[pid]');"><i class="mktyiconfont icon-shezhi-copy"></i></a>
                    </span>
                    <div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
                        <input type="button" value="{lang edit}" class="redirect button ap_n" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
                        <!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
                        <!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
                        <!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
                    </div>
                <!--{elseif !$_G['forum_thread']['archiveid'] && $_G['uid']}-->
                    <span class="user-manager">
                        <a href="javascript:;" onclick="mktyShowUserManager('#moptionuser_$post[pid]');"><i class="mktyiconfont icon-gengduo"></i></a>
                    </span>
                    <div id="moptionuser_$post[pid]" class="user-manager-body-wrap" style="display:none;">
                        <div class="user-manager-body">
                            <!-- 回复 -->
                            <!--{if $_G[uid] && $allowpostreply && !$post[first]}-->
                                <span>
                                    <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page">回复</a>
                                </span>
                            <!--{/if}-->
                            <!-- “添加柜台介绍” or “编辑”按钮” -->
                            <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
                                <a class="editp" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}</a><!--{/if}-->
                            <!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
                                <!-- “补充”按钮 -->
                                <a class="appendp" href="javascript:mktypostappend('forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page');" >{lang postappend}</a>
                            <!--{/if}-->
                            <!--{if $post['invisible'] == 0}-->
                                <!-- “举报”按钮 -->
                                <!--{if $post['authorid'] != $_G['uid']}-->
                                    <a href="javascript:;" onclick="mktyreport('miscreport$post[pid]', 'misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]');return false;">{lang report}</a>
                                <!--{/if}-->
                            <!--{/if}-->
                            <!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
                                <a href="javascript:;" onclick="setanswer($post['pid'], '$_GET[from]')">
                                    选为最佳答案？
                                </a>
                            <!--{/if}-->
                        </div>
                    </div>
                <!--{/if}-->
                <!--{if $_G[uid] && $allowpostreply && !$post[first]}-->
                    <span class="reply">
                        <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page"><i class="mktyiconfont icon-huifu5-copy"></i></a>
                    </span>
                <!--{/if}-->

                
            </div>
        </div>
        <!--{/if}-->
        
   </div>
<!-- main postlist end -->
