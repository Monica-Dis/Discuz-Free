<?php exit; ?>
<!--{template common/header}-->

<!-- header start -->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				购买附件
			</li>

			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>
<!-- header end -->


<div class="attach-pay-box">
	

		<form id="attachpayform" method="post" autocomplete="off" action="forum.php?mod=misc&action=attachpay&tid={$_G[tid]}">
		<div class="f_c">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="aid" value="$aid" />
			<ul>
				<li class="atb-item">
					<div class="atb-name">{lang author}</div>
					<div class="atb-value"><a href="home.php?mod=space&uid=$attach[uid]">$attach[author]</a></div>
				</li>
				<li class="atb-item">
					<div class="atb-name">{lang attachment}</div>
					<div class="atb-value"><div style="overflow:hidden">$attach[filename] <!--{if $attach['description']}-->($attach[description])<!--{/if}--></div></div>
				</li>
				<li class="atb-item">
					<div class="atb-name">{lang price}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</div>
					<div class="atb-value">$attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</div>
				</li>
				<!--{if $status != 1}-->
					<li class="atb-item">
						<div class="atb-name">{lang pay_author_income}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</div>
						<div class="atb-value">$attach[netprice] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</div>
					</li>
					<li class="atb-item">
						<div class="atb-name">{lang pay_balance}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</div>
						<div class="atb-value">$balance {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</div>
					</li>
				<!--{/if}-->
				<!--{if $status == 1}-->
				<li class="atb-item">
					<div class="atb-tips">{lang status_insufficient}</div>
				</li>
				<!--{elseif $status == 2}-->
				<li class="atb-item">
					<div class="atb-tips">{lang status_download}, <a href="forum.php?mod=attachment&aid=$aidencode" target="_blank">{lang download}</a></div>
				</li>
				<!--{/if}-->
			</ul>
			<div class="atb-tail">
				<!--{if $status != 1}-->
					<label style="display:none;"><input name="buyall" type="checkbox" class="pc" value="yes" />{lang buy_all_attch}</label>
					<p class="atb-btn">
						<button class="pn" type="submit" name="paysubmit" value="true"><span><!--{if $status == 0}-->{lang pay_attachment}<!--{else}-->{lang free_buy}<!--{/if}--></span></button>
					</p>
				<!--{/if}-->
			</div>
		</div>
	</form>
</div>
<!--{template common/footer}-->