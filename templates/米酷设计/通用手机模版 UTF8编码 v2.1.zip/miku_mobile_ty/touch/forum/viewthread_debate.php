<?php exit; ?>
<!--{if $debate[umpire]}-->
	<!--{if $debate['umpirepoint']}-->
	<div class="debate-result">
		<div class="dr-row">
			<div class="dr-name">辩论结果</div>
			<div class="dr-value">
			<!--{if $debate[winner]}-->
				<!--{if $debate[winner] == 1}-->
				<label><strong>{lang debate_square}</strong>{lang debate_winner}</label>
				<!--{elseif $debate[winner] == 2}-->
				<label><strong>{lang debate_opponent}</strong>{lang debate_winner}</label>
				<!--{else}-->
				<label><strong>{lang debate_draw}</strong></label>
				<!--{/if}-->
			<!--{/if}-->
			</div>
		</div>
		<div class="dr-row">
			<div class="dr-name">{lang debate_comment_dateline}</div>
			<div class="dr-value">
				$debate[endtime]
			</div>
		</div>
		<!--{if $debate[umpirepoint]}-->
			<div class="dr-row">
				<div class="dr-name">{lang debate_umpirepoint}</div>
				<div class="dr-value">$debate[umpirepoint]</div>
			</div>
		<!--{/if}-->
		<!--{if $debate[bestdebater]}-->
			<div class="dr-row">
				<div class="dr-name">{lang debate_bestdebater}</div>
				<div class="dr-value">$debate[bestdebater]</div>
			</div>
		<!--{/if}-->
	</div>
	<!--{/if}-->
<!--{/if}-->

<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>

<!--{if $debate[affirmvotes] > 0 || $debate[negavotes] > 0}-->
	{eval $miku_ty_square = round(($debate[affirmvotes]/($debate[affirmvotes] + $debate[negavotes]))*100, 2)}
	{eval $miku_ty_opponent = 100 - $miku_ty_square}
<!--{else}-->
	{eval $miku_ty_square = 0}
	{eval $miku_ty_opponent = 0}
<!--{/if}-->
<div class="debate-chart">
	<div class="dc-square">
		正方 {$miku_ty_square}%
	</div>
	<div class="dc-opponent">
		反方 {$miku_ty_opponent}%
	</div>
	<div class="dc-wrap">
		<div style="width:{$miku_ty_square}%;" class="dc-inner-q"></div>
		<div style="width:{$miku_ty_opponent}%;" class="dc-inner-o"></div>
	</div>
</div>

<div class="debate-box cl">
    <div class="db-square">
    	<div class="db-body">
	        <p class="db-btn">
	        	<!--{if !$_G['forum_thread']['is_archived']}-->
				<a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" class="affirmbutton">支持正方</a><!--{/if}-->
			</p>
	        <p class="db-title">{lang debate_square_point} ($debate[affirmvotes]) </p>
			<p class="db-num">({lang debater}: $debate[affirmdebaters]) </p>
			<p class="db-content">$debate[affirmpoint]</p>
		</div>
    </div>
    <div class="db-opponent">
    	<div class="db-body">
	        <p class="db-btn"><a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" class="negabutton">支持反方</a></p>
	        <p class="db-title">{lang debate_opponent_point} ($debate[negavotes])</p>
	        <p class="db-num">({lang debater}: $debate[negadebaters])</p>
	        <p class="db-content">$debate[negapoint]</p>
		</div>
    </div>
</div>


<div class="debate-tail">
<!--{if $debate[endtime]}-->
	<p class="dt-tips">{lang endtime}: $debate[endtime] <!--{if $debate[umpire]}-->{lang debate_umpire}: $debate[umpire]<!--{/if}--></p>
<!--{/if}-->

<!--{if $debate[umpire] && $_G['username'] && $debate[umpire] == $_G['member']['username']}-->
	<p class="dt-btn">
		<!--{if $debate[remaintime] && !$debate[umpirepoint]}-->
		 <a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" >{lang debate_umpire_end}</a>
		<!--{elseif TIMESTAMP - $debate['dbendtime'] < 3600}-->
		 <a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" >{lang debate_umpirepoint_edit}</a>
		<!--{/if}-->
	</p>
<!--{/if}-->
</div>