<?php exit; ?>
<input type="hidden" name="polls" value="yes" />
<div class="post-poll-form cl">
	<div class="ppf-option-box">
		<input type="hidden" name="fid" value="$_G[fid]" />
		<!--{if $_GET[action] == 'newthread'}-->
			<input type="hidden" name="tpolloption" value="1" />
			<div class="cl">
				<h4 class="ppf-title">
					<em>{lang post_poll_options}: </em>
					{lang post_poll_comment} &nbsp;
					<span style="display: none;" class="xw0" >
						<input id="pollchecked" type="checkbox" class="pc"/><label for="pollchecked">{lang post_single_frame_mode}</label>
					</span>
				</h4>
			</div>
			<div id="pollm_c_1" class="mbm">
				<span id="polloption_new"></span>
				<div id="polloption_hidden" style="display: none">
					<a href="javascript:;" class="ppf-del" onclick="delpolloption(this)"><i class="mktyiconfont icon-shanchu4"></i></a>
					<input type="text" name="polloption[]" class="ppf-px ap_n" autocomplete="off" style="width:90%;" tabindex="1" />
					<span id="pollUploadProgress" class="vm" style="display: none;"></span>
					<span id="newpoll" class="vm"></span>
				</div>
				<p class="ppf-addbtn"><a href="javascript:;" onclick="addpolloption()">+{lang post_poll_add}</a></p>
			</div>
			<div style="display:none" id="pollm_c_2" class="mbm">
				<textarea name="polloptions" class="pt" style="width:340px;" tabindex="1" rows="6" onchange="switchpollm(0)" /></textarea>
				<p class="cl">{lang post_poll_comment_s}</p>
			</div>


		<!--{else}-->
			<!--{loop $poll['polloption'] $key $option}-->
				<!--{eval $ppid = $poll['polloptionid'][$key];}-->
				<p class="ppf-opt1">
					<input type="hidden" name="polloptionid[{$poll[polloptionid][$key]}]" value="$poll[polloptionid][$key]" />
					<input type="text" name="displayorder[{$poll[polloptionid][$key]}]" class="ppf-px ap_n" autocomplete="off" tabindex="1" style="width:10%;"value="$poll[displayorder][$key]" />
					<input type="text" name="polloption[{$poll[polloptionid][$key]}]" class="ppf-px ap_n" autocomplete="off" style="width:80%;" tabindex="1" value="$option"{if !$_G['group']['alloweditpoll']} readonly="readonly"{/if} />
					<!--img src="$poll[imginfo][$ppid][small]" class="cur1" /-->
					<span id="newpoll_{$key}" class="vm"></span>
					<span id="pollUploadProgress_{$key}" class="vm" style="display: none;">
						<!--{if $poll[isimage]}-->
						<img src="{IMGDIR}/attachimg_2.png" class="cur1" onmouseover="showMenu({'menuid':'poll_img_preview_{$poll[imginfo][$ppid][aid]}_menu','ctrlclass':'a','duration':2,'timeout':0,'pos':'34'});" onmouseout="hideMenu('poll_img_preview_{$poll[imginfo][$ppid][aid]}_menu');" />
						<!--{/if}-->
						<input type="hidden" name="pollimage[{$poll[polloptionid][$key]}]" id="pollUploadProgress_{$key}_aid" value="$poll[imginfo][$ppid][aid]" />
						<span id="poll_img_preview_{$poll[imginfo][$ppid][aid]}_menu" style="display: none">
							<img src="$poll[imginfo][$ppid][small]" />
						</span>
					</span>
				</p>
			<!--{/loop}-->
			<span id="polloption_new"></span>
			<p id="polloption_hidden" style="display: none">
				<a href="javascript:;" class="ppf-del" onclick="delpolloption(this)"><i class="mktyiconfont icon-shanchu4"></i></a>
				<input type="text" name="displayorder[]" class="ppf-px ap_n" autocomplete="off" style="width:10%;" tabindex="1" />
				<input type="text" name="polloption[]" class="ppf-px ap_n" autocomplete="off" style="width:80%;" tabindex="1" />
				<span id="newpoll" class="vm"></span>
				<span id="pollUploadProgress" class="vm" style="display: none;"></span>
			</p>
			<p class="ppf-addbtn"><a href="javascript:;" onclick="addpolloption()">+{lang post_poll_add}</a></p>
		<!--{/if}-->
	</div>
	<div class="ppf-ext-box">
		<ul>
			<li class="e-item">
				<div class="ppf-name">
					<label for="maxchoices">{lang post_poll_allowmultiple}</label>
				</div>
				<div class="ppf-input">
					<input type="text" name="maxchoices" id="maxchoices" class="ppf-px ap_n" value="{if $_GET[action] == 'edit' && $poll[maxchoices]}$poll[maxchoices]{else}1{/if}" tabindex="1" />  {lang post_option}
				</div>
			</li>
			<li class="e-item">
				<div class="ppf-name">
					<label for="polldatas">{lang post_poll_expiration}</label>
				</div>
				<div class="ppf-input">
					<input type="text" name="expiration" id="polldatas" class="ppf-px ap_n" value="{if $_GET[action] == 'edit'}{if !$poll[expiration]}0{elseif $poll[expiration] < 0}{lang poll_close}{elseif $poll[expiration] < TIMESTAMP}{lang poll_finish}{else}{echo (round(($poll[expiration] - TIMESTAMP) / 86400))}{/if}{/if}" tabindex="1" /> {lang days}
				</div>
				
			</li>
			<li class="e-item">
				<div class="ppf-name">&nbsp;</div>
				<div class="ppf-input">
					<input type="checkbox" name="visibilitypoll" id="visibilitypoll" class="pc" value="1"{if $_GET[action] == 'edit' && !$poll[visible]} checked{/if} tabindex="1" /><label for="visibilitypoll">{lang poll_after_result}</label>
				</div>				
			</li>
			<li class="e-item">				
				<div class="ppf-name">&nbsp;</div>
				<div class="ppf-input">
					<input type="checkbox" name="overt" id="overt" class="pc" value="1"{if $_GET[action] == 'edit' && $poll[overt]} checked{/if} tabindex="1" /><label for="overt">{lang post_poll_overt}</label>
				</div>
			</li>
		</ul>
	</div>
</div>

<script type="text/javascript" reload="1">
var maxoptions = parseInt('$_G[setting][maxpolloptions]');
<!--{if $_GET[action] == 'newthread'}-->
	var curoptions = 0;
	var curnumber = 1;
	addpolloption();
	addpolloption();
	addpolloption();
<!--{else}-->
	var curnumber = curoptions = <!--{echo count($poll['polloption'])}-->;
<!--{/if}-->

function addpolloption() {
	if(curoptions < maxoptions) {
		var imgid = 'newpoll_'+curnumber;
		var proid = 'pollUploadProgress_'+curnumber;
		var pollstr = $('#polloption_hidden')[0].innerHTML.replace('newpoll', imgid);
		pollstr = pollstr.replace('pollUploadProgress', proid);
		$('#polloption_new')[0].outerHTML = '<p class="ppf-opt1">' + pollstr + '</p>' + $('#polloption_new')[0].outerHTML;
		curoptions++;
		curnumber++;
	} else {
		$('#polloption_new')[0].outerHTML = '<span>已达到最大投票数'+maxoptions+'</span>';
	}
}

function delpolloption(obj) {
	obj.parentNode.parentNode.removeChild(obj.parentNode);
	curoptions--;
}


</script>
