<?php exit; ?>
<div class="post-debate-form cl">
	<div class="pdf-box">
		<dl>
			<dt><label for="affirmpoint">{lang debate_square_point}</label><span class="rq">*</span></dt>
			<dd><textarea name="affirmpoint" id="affirmpoint" class="pt" tabindex="1" placeholder="观点内容">$debate[affirmpoint]</textarea></dd>
		</dl>
		<dl>
			<dt><label for="negapoint">{lang debate_opponent_point}</label><span class="rq">*</span></dt>
			<dd><textarea name="negapoint" id="negapoint" class="pt" tabindex="1" placeholder="观点内容">$debate[negapoint]</textarea></dd>
		</dl>
		<dl>
			<dt><label for="endtime">{lang endtime}</label></dt>
			<dd class="pdf-time-sel cl">
				<input type="text" name="endtime" id="endtime" class="px ap_n" autocomplete="off" value="$debate[endtime]" tabindex="1" />
				<a href="javascript:;" class="pdf-time-sel-btn" onclick="mktyshowMenu();">
					<i class="mktyiconfont icon-chakantiezishijian"></i>
				</a>
				<div id="miku_ty_calendarexp" style="display: none;"></div>
			</dd>
		</dl>
		<dl>
			<dt><label for="umpire">{lang debate_umpire}</label></dt>
			<dd>
				<p><input type="text" name="umpire" id="umpire" class="px ap_n" onblur="checkuserexists(this.value, 'checkuserinfo')" value="$debate[umpire]" tabindex="1" placeholder="裁判的用户名" /><span id="checkuserinfo"></span></p>
			</dd>
			<!--{hook/post_debate_extra}-->
		</dl>
	</div>
</div>

<script>
function showselect(id, inpid) {
	var today = new Date();
	var showselect_row = function (s, v, notime) {
		var notime = !notime ? 0 : 1;
		var t = today.getTime();
		t += 86400000 * v;
		var d = new Date();
		d.setTime(t);
		var month = d.getMonth() + 1;
		month = month < 10 ? '0' + month : month;
		var day = d.getDate();
		day = day < 10 ? '0' + day : day;
		var hour = d.getHours();
		hour = hour < 10 ? '0' + hour : hour;
		var minute = d.getMinutes();
		minute = minute < 10 ? '0' + minute : minute;
		return '<a href="javascript:;" onclick="$(\'' + inpid + '\')[0].value = \'' + d.getFullYear() + '-' + month + '-' + day + (notime ? ' ' + hour + ':' + minute: '') + '\';popup.close();">' + s + '</a>';
	};

	s = '';
	s += '<div class="miku_ty_calendarexp_box">';
	s += showselect_row('7 天', 7, 1);
	s += showselect_row('14 天', 14, 1);
	s += showselect_row('一个月', 30, 1);
	s += showselect_row('三个月', 90, 1);
	s += showselect_row('半年', 182, 1);
	s += showselect_row('一年', 365, 1);
	s += '</div>';
	$(id).html(s);
}
showselect('#miku_ty_calendarexp', '#endtime');
function mktyshowMenu(){
	var s = $('#miku_ty_calendarexp').html();
	popup.open(s);
}
</script>