<?php exit; ?>

<div class="fast-post-box" style="display: none;">
	<div class="fpb-c cl">
		<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes&mobile=2">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
			<ul class="fastpost">
				<!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->
				<li class="fpc-debate">
					<select id="stand" name="stand" class="ap_n">
						<option value="">{lang debate_viewpoint}</option>
						<option value="0">{lang debate_neutral}</option>
						<option value="1">{lang debate_square}</option>
						<option value="2">{lang debate_opponent}</option>
					</select>
					 <span class="fpcd-tips">（请选择您的立场）</span>
				</li>
				<!--{/if}-->

				<li class="fpc-input">
					<textarea name="message" id="needmessage" rows="2"  placeholder="请输入评论内容..." class="fpc-txt input grey ap_n" color="gray"></textarea>
				</li>
				
				<li id="fpc-smile-body" class="item item-smilelist" style="display: none;overflow: hidden;">
					<div id="mktysmilies" class="pbl-smilelist">
					</div>
				</li>
				
				<!--{if $secqaacheck || $seccodecheck}-->
				<li class="fpc-sec">
					<!--{subtemplate common/seccheck}-->
				</li>
				<!--{/if}-->

				<li id="fastpostsubmitline" class="fpc-footer">

					<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" class="fpc-adv-btn">高级模式</a>
					<a href="javascript:;" id="fpc-smile-btn" class="fpc-smile-btn">
						<i class="mktyiconfont icon-emoji"></i>
					</a>
					<input type="button" value="{lang reply}" class="button2 ap_n" name="replysubmit" id="fastpostsubmit">
					<!--{hook/viewthread_fastpost_button_mobile}-->
				</li>
			</ul>

			<div id="append_parent"></div>
			<script type="text/javascript" src="template/miku_mobile_ty/static/js/smilies.js?{VERHASH}"></script>
			<script type="text/javascript">
				smilies_show('mktysmilies', 12);
				$('#fpc-smile-btn').on('tap',function(){
					$("#fpc-smile-body").slideToggle('fast');
					$("#fpc-smile-btn").toggleClass('fpc-active');
	                document.activeElement.blur();
				});
			</script>
		</div>
	    </form>
	</div>
</div>
<script type="text/javascript">
	(function() {
		var form = $('#fastpostform');
		<!--{if !$_G[uid] || $_G[uid] && !$allowpostreply}-->
		$('#needmessage').on('focus', function() {
			<!--{if !$_G[uid]}-->
				popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
			<!--{else}-->
				popup.open('{lang nopostreply}', 'alert');
			<!--{/if}-->
			this.blur();
		});
		<!--{else}-->
		$('#needmessage').on('focus', function() {
			var obj = $(this);
			if(obj.attr('color') == 'gray') {
				obj.attr('value', '');
				obj.removeClass('grey');
				obj.attr('color', 'black');
				$('#fastpostsubmitline').css('display', 'block');
			}
		})
		.on('blur', function() {
			var obj = $(this);
			if(obj.attr('value') == '') {
				obj.addClass('grey');
				obj.attr('value', '请输入评论内容...');
				obj.attr('color', 'gray');
			}
		});
		<!--{/if}-->
		$('#fastpostsubmit').on('click', function() {
			var msgobj = $('#needmessage');
			$('#fastpostsubmit').attr('disabled','disabled');
			$('#fastpostsubmit').addClass('button2-grey');
			setTimeout(function(){
				$('#fastpostsubmit').removeClass('button2-grey');
				$('#fastpostsubmit').removeAttr('disabled');
			}, 2000);
			if(msgobj.val() == '请输入评论内容...') {
				msgobj.attr('value', '');
			}
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey=fastpost&loc=1&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});

		$('#replyid').on('click', function() {
			$(document).scrollTop($(document).height());
			$('#needmessage')[0].focus();
		});

	})();

	function succeedhandle_fastpost(locationhref, message, param) {
		var pid = param['pid'];
		var tid = param['tid'];
		if(pid) {
			$.ajax({
				type:'POST',
				url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid + '&mobile=2',
				dataType:'xml'
			})
			.success(function(s) {
				// $('#post_new').append(s.lastChild.firstChild.nodeValue);
				$('.postlist').append(s.lastChild.firstChild.nodeValue);

				$("#mkty-fastreplay-body .fast-post-box").slideUp('fast', function(){
					$('#mkty-fastreplay-body').css('display', 'none');
				});
				$(document).scrollTop($(document).height());
			})
			.error(function() {
				window.location.href = 'forum.php?mod=viewthread&tid=' + tid;
				popup.close();
			});
		} else {
			if(!message) {
				message = '{lang postreplyneedmod}';
			}
			popup.open(message, 'alert');
		}
		$('#needmessage').attr('value', '');
		if(param['sechash']) {
			$('.seccodeimg').click();
		}
	}

	function errorhandle_fastpost(message, param) {
		popup.open(message, 'alert');
	}

	
	$("#mkty-fastreplay-body").on('click', function(evt){
		if(evt.target == this){
			$("#mkty-fastreplay-body .fast-post-box").slideUp('fast', function(){
				$('#mkty-fastreplay-body').css('display', 'none');
			});
		}
	});
	$("#mkty-fastreplay-btn").on('click', function(evt){
		$('#mkty-fastreplay-body').css('display', 'block');
		$("#mkty-fastreplay-body .fast-post-box").slideDown('fast');
	});
</script>
