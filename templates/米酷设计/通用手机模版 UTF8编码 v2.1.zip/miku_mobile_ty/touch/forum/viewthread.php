<?php exit; ?>
<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				帖子详情
			</li>

			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>

<div id="mkty-crumb-body" style="display: none;">
	<div class="mkty-crumb-body">
		<div class="cmbn-list">
			<a href="forum.php?mod=guide&view=new"><i class="mktyiconfont icon-shouye3"></i></a><em>&rsaquo;</em><a href="forum.php?forumlist=1">社区</a>$navigation<em>&rsaquo;</em> <a href="forum.php?mod=viewthread&tid=$_G[tid]">$_G[forum_thread][short_subject]</a>
		</div>
	</div>
</div>

<!--{hook/viewthread_top_mobile}-->
<div class="postlist">
	<div class="pl-header">
		<h2 class="pl-title">
			<span>
	        	<!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
					[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
	            <!--{/if}-->
	            <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
	                [{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]
				<!--{/if}-->
			</span>
			<a href="forum.php?mod=viewthread&tid=$_G[tid]">$_G[forum_thread][subject]</a>
            <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
            <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
            <!--{/if}-->
		</h2>
            <div class="thread-info">
				<span class="thif-block cl">
					<a class="name" href="forum.php?mod=forumdisplay&fid=$_G[fid]"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></a> <i class="mktyiconfont icon-enter"></i>
				</span>
				<span class="views">

					<span><i class="mktyiconfont icon-chakan1"></i> $_G['forum_thread']['views']</span>&nbsp;&nbsp;
					<span><i class="mktyiconfont icon-31xiaoxi"></i> 
						{if $_G['forum_thread']['replies'] > 0}{$_G['forum_thread']['replies']}{else}0{/if}
					</span>
				</span>
	
			</div>
	</div>

	<mikuty-vt-ajaxtag>
	<script>replyreload = 0</script>
	<!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
	<!--{hook/viewthread_posttop_mobile $postcount}-->
	
   <div class="postlist-c cl" id="pid$post[pid]">
		<div class="author cl{if $post['first']} first-post{/if}">
			<div class="avatar"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, middle, true)}--><!--{else}--><!--{avatar($post[authorid], middle, true)}--><!--{/if}-->"/></div>
	       	<div class="info">
	       			<!--{if $post[first]}-->
	       				<div class="right-links">
							<!--{if $_G['forum']['ismoderator']}-->
								<span><a href="javascript:;" onclick="mktyShowUserManager('#moption_$post[pid]');"class="opl-mng"><i class="mktyiconfont icon-shezhi"></i></a></span>
								<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
									<div class="banzhu-manager-body">
										<!--{if !$_G['forum_thread']['special']}-->
										<input type="button" value="{lang edit}" class="redirect button ap_n" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
										<!--{/if}-->
										<input type="button" value="{lang delete}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">
										<input type="button" value="{lang close}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">
										<input type="button" value="{lang admin_banpost}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
										<input type="button" value="{lang topicadmin_warn_add}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">
									</div>
								</div>
							<!--{else}-->
								
								<!--{if !$_G['forum_thread']['archiveid'] && $_G['uid']}-->
									<span class="user-manager">
										<a href="javascript:;" onclick="mktyShowUserManager('#moptionuser_$post[pid]');"><i class="mktyiconfont icon-gengduo"></i></a>
									</span>
									<div id="moptionuser_$post[pid]" class="user-manager-body-wrap" style="display:none;">
										<div class="user-manager-body">
											<!-- 回复 -->
											<!--{if $post[first]}-->
												<span>
													<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&extra=$_GET[extra]&page=$page">回复</a>
												</span>
											<!--{/if}-->
											<!-- “添加柜台介绍” or “编辑”按钮” -->
											<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
												<a class="editp" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}</a><!--{/if}-->
											<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
												<!-- “补充”按钮 -->
												<a class="appendp" href="javascript:mktypostappend('forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page');">{lang postappend}</a>
											<!--{/if}-->
											<!--{if $post['invisible'] == 0}-->
												<!-- “举报”按钮 -->
												<!--{if $post['authorid'] != $_G['uid']}-->
													<a href="javascript:;" onclick="mktyreport('miscreport$post[pid]', 'misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]');return false;">{lang report}</a>
												<!--{/if}-->
											<!--{/if}-->
										</div>
									</div>
								<!--{else}-->
									<span class="fpif y">楼主</span>
								<!--{/if}-->
							<!--{/if}-->

						</div>
	       			<!--{else}-->
						<div class="right-tag">
							<!--{if isset($post[isstick])}-->
								<img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> {lang from} {$post[number]}{$postnostick}
							<!--{elseif $post[number] == -1}-->
								{lang recommend_post}
							<!--{else}-->
								<!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}-->
							<!--{/if}-->
						</div>
					<!--{/if}-->
					<!--{block authorverifys}-->
						<!--{loop $post['verifyicon'] $vid}-->
							<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $_G['setting']['verify'][$vid]['icon']}--><img src="$_G['setting']['verify'][$vid]['icon']" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /><!--{else}-->$_G['setting']['verify'][$vid]['title']<!--{/if}--></a>
						<!--{/loop}-->
					<!--{/block}-->
					
					<div class="name cl">
						<div class="plsn-top cl">
							<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
								<a class="pls-uname" href="home.php?mod=space&do=profile&uid=$post[authorid]">$post[author]</a>
									<!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
									<!--{if $_self}-->
										<span class="pls-lz-icon">楼主</span>
									<!--{/if}-->
									<!--{if in_array($post['adminid'], array(1, 2, 3))}-->
										<span class="mkty-userlv-icon mkty-userlv-manager pls-ulv">
											{$post['authortitle']}
										</span>
									<!--{else}-->
										<span class="mkty-userlv-icon mkty-userlv{$post['stars']} pls-ulv">
											Lv.{$post['stars']}
										</span>
									<!--{/if}-->
									<span class="pls-verify">{$authorverifys}</span>
									
							<!--{else}-->

								<!--{if !$post['authorid']}-->
								<a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
								<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
								<!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&do=profile&uid=$post[authorid]" target="_blank">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
								<!--{else}-->
								$post[author] <em>{lang member_deleted}</em>
								<!--{/if}-->
							<!--{/if}-->
						</div>
						<div class="plsn-bottom cl">
							<span class="time">$post[dateline]</span>
						</div>
					</div>
					
			</div>		
		</div>
	  	


        <div class="display pi" href="#replybtn_$post[pid]">
			<div class="message{if $post['first']} first-post{/if}">
            	<!--{if $post['warned']}-->
                    <span class="warning-quote">{lang warn_get}</span>
                <!--{/if}-->
                <!--{if !$post['first'] && !empty($post[subject])}-->
                    <h2><strong>$post[subject]</strong></h2>
                <!--{/if}-->
                <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                    <div class="warning-quote">{lang message_banned}</div>
                <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                    <div class="warning-quote">{lang message_single_banned}</div>
                <!--{elseif $needhiddenreply}-->
                    <div class="warning-quote">{lang message_ishidden_hiddenreplies}</div>
                <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
					<!--{template forum/viewthread_pay}-->
				<!--{elseif $_G['forum_discuzcode']['passwordlock'][$post[pid]]}-->
					<script type="text/javascript"  src="static/js/md5.js?{VERHASH}"></script>
					<script type="text/javascript"  src="template/miku_mobile_ty/static/js/viewthread.js?{VERHASH}"></script>
					<div class="locked">
						{lang message_password_exists} {lang pleaseinputpw}
						<p>
							<input type="text" id="postpw_$post[pid]" class="lpw-px ap_n" />&nbsp;
							<button class="lpw-pn" type="button" onclick="submitpostpw($post[pid]{if $_GET['from'] == 'preview'},{$post[tid]}{else}{/if})">{lang submit}</button>
						</p>
					</div>
				<!--{else}-->

                	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                        <div class="warning-quote">{lang admin_message_banned}</div>
                    <!--{elseif $post['status'] & 1}-->
                        <div class="warning-quote">{lang admin_message_single_banned}</div>
                    <!--{/if}-->

					<!--{if $_G['forum_discuzcode']['passwordauthor'][$post[pid]]}-->
						<div class="locked">{lang message_password_exists}</div>
					<!--{/if}-->
                    <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                    	<div class="locked">
                       	 {lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <em class="y">已购买</em>
                    	</div>
                    <!--{/if}-->
					
				
                    <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                    	<!--{if $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                            <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                                {lang has_expired}
                            <!--{else}-->
                                <div class="box_ex2 viewsort">
                                    <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                                <!--{loop $threadsortshow['optionlist'] $option}-->
                                    <!--{if $option['type'] != 'info'}-->
                                        $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="grey">--</span><!--{/if}--><br />
                                    <!--{/if}-->
                                <!--{/loop}-->
                                </div>
                            <!--{/if}-->
                        <!--{/if}-->
                    <!--{/if}-->
                    <!--{if $post['first']}-->
                        <!--{if !$_G[forum_thread][special]}-->
                            $post[message]
                        <!--{elseif $_G[forum_thread][special] == 1}-->
                            <!--{template forum/viewthread_poll}-->
                        <!--{elseif $_G[forum_thread][special] == 2}-->
                            <!--{template forum/viewthread_trade}-->
                        <!--{elseif $_G[forum_thread][special] == 3}-->
                            <!--{template forum/viewthread_reward}-->
                        <!--{elseif $_G[forum_thread][special] == 4}-->
                            <!--{template forum/viewthread_activity}-->
                        <!--{elseif $_G[forum_thread][special] == 5}-->
                            <!--{template forum/viewthread_debate}-->
                        <!--{elseif $threadplughtml}-->
                            $threadplughtml
                            $post[message]
                        <!--{else}-->
                        	$post[message]
                        <!--{/if}-->
                    <!--{else}-->
                        $post[message]
                    <!--{/if}-->

					<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
						<!--{if $post['attachment']}-->
			               <div class="postlist-tips">
			               {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
			               </div>
			            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
			               <!--{if $post['imagelist']}-->
							<!--{if count($post['imagelist']) == 1}-->
							<ul class="postlist-vm-imglist img_one">{echo showattach($post, 1)}</ul>
							<!--{else}-->
							<ul class="postlist-vm-imglist img_list cl vm">{echo showattach($post, 1)}</ul>
							<!--{/if}-->
							<!--{/if}-->
			                <!--{if $post['attachlist']}-->
							<ul class="postlist-vm-attach-list">{echo showattach($post)}</ul>
							<!--{/if}-->
						<!--{/if}-->
					<!--{/if}-->
				<!--{/if}-->




			</div>
			
        </div>
        <!--{if $post[first]}-->
        <div class="thread-tail">
        	<div class="thread-copyright">
        		著作权归原作者所有，未经许可不得转载
        	</div>

			<!--{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}-->
        	<div class="zan">
    			<a href="javascript:;" {if $_G[uid]}onclick="recommend(this, 'forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}&inajax=1&check=1');"{else}onclick="mktygotologin()"{/if}>
					<i class="mktyiconfont icon-shangpintuijian"></i>
				</a>
        		<span class="num">
        			<span class="zan-num">{if $_G['forum_thread']['recommend_add']}{$_G['forum_thread']['recommend_add']}{/if}</span>
        			赞
        		</span>
        	</div>
        	<!--{/if}-->
        </div>
        <!--{/if}-->
		<!--{if !$post[first]}-->
       <div class="post-info">
			<!-- <span class="time">$post[dateline]</span> -->
			
			<div class="op-links">
				<!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
					<a class="tag1" href="javascript:;" onclick="setanswer($post['pid'], '$_GET[from]')">
						最佳答案
					</a>
				<!--{/if}-->

				<!--{if $_G['forum']['ismoderator']}-->
					<span class="opl-manager">
						<a href="javascript:;" onclick="mktyShowUserManager('#moption_$post[pid]');"><i class="mktyiconfont icon-shezhi-copy"></i></a>
					</span>
					<div id="moption_$post[pid]" popup="true" class="manage" style="display:none;">
						<div class="banzhu-manager-body">
							<input type="button" value="{lang edit}" class="redirect button ap_n" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">
							<!--{if $_G['group']['allowdelpost']}--><input type="button" value="{lang modmenu_deletepost}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
							<!--{if $_G['group']['allowbanpost']}--><input type="button" value="{lang modmenu_banpost}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
							<!--{if $_G['group']['allowwarnpost']}--><input type="button" value="{lang modmenu_warn}" class="dialog button ap_n" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"><!--{/if}-->
						</div>
					</div>
				<!--{elseif !$_G['forum_thread']['archiveid'] && $_G['uid']}-->
					<span class="user-manager">
						<a href="javascript:;" onclick="mktyShowUserManager('#moptionuser_$post[pid]');"><i class="mktyiconfont icon-gengduo"></i></a>
					</span>
					<div id="moptionuser_$post[pid]" class="user-manager-body-wrap" style="display:none;">
						<div class="user-manager-body">
							<!-- 回复 -->
							<!--{if $_G[uid] && $allowpostreply && !$post[first]}-->
								<span>
									<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page">回复</a>
								</span>
							<!--{/if}-->
							<!-- “添加柜台介绍” or “编辑”按钮” -->
							<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
								<a class="editp" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><!--{if $_G['forum_thread']['special'] == 2 && !$post['message']}-->{lang post_add_aboutcounter}<!--{else}-->{lang edit}</a><!--{/if}-->
							<!--{elseif $_G['uid'] && $post['authorid'] == $_G['uid'] && $_G['setting']['postappend']}-->
								<!-- “补充”按钮 -->
								<a class="appendp" href="javascript:mktypostappend('forum.php?mod=misc&action=postappend&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page');" >{lang postappend}</a>
							<!--{/if}-->
							<!--{if $post['invisible'] == 0}-->
								<!-- “举报”按钮 -->
								<!--{if $post['authorid'] != $_G['uid']}-->
									<a href="javascript:;" onclick="mktyreport('miscreport$post[pid]', 'misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]');return false;">{lang report}</a>
								<!--{/if}-->
							<!--{/if}-->
							<!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
								<a href="javascript:;" onclick="setanswer($post['pid'], '$_GET[from]')">
									选为最佳答案？
								</a>
							<!--{/if}-->
						</div>
					</div>
				<!--{/if}-->
				<!--{if $_G[uid] && $allowpostreply && !$post[first]}-->
					<span class="reply">
						<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page"><i class="mktyiconfont icon-huifu5-copy"></i></a>
					</span>
				<!--{/if}-->

				
			</div>
		</div>
		<!--{/if}-->
		
   </div>
   <!--{if $post[first]}-->
		<!--{if $post['relateitem']}-->
		<div class="postlist-xianggan-tiezi">
				<h3 class="plxgtz-title">相关帖子</h3>
				<ul class="plxgtz-list">
					<!--{loop $post['relateitem'] $var}-->
					<li class="plxgtz-item">&#8226; <a href="forum.php?mod=viewthread&tid=$var[tid]" title="$var[subject]" target="_blank">$var[subject]</a></li>
					<!--{/loop}-->
				</ul>
		</div>
		<!--{/if}-->

		<div class="postlist-nav cl">
				<div class="plsn-title">
					评论列表
					<span class="plsn-num">({if $_G['forum_thread']['replies'] > 0}{$_G['forum_thread']['replies']}{else}0{/if})</span>
				</div>
				<div class="plsn-right">
					<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
						<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&authorid=$_G[forum_thread][authorid]" rel="nofollow">
							<i class="mktyiconfont icon-shuoming"></i> 只看楼主</a>
					<!--{elseif !$_G['forum_thread']['archiveid']}-->
						<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page" rel="nofollow"><i class="mktyiconfont icon-shuoming"></i> 全部评论</a>
					<!--{/if}-->

					<!-- 如果：不是抢楼帖？？？ -->
					<!--{if !$rushreply}-->
						<!-- 如果：不是“倒序浏览”模式 -->
						<!--{if $ordertype != 1}-->
							<!-- 倒序浏览 -->
							<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1">&nbsp;<i class="mktyiconfont icon-paixu"style="font-size: 15px;"></i>{lang post_descview}</a>
						<!--{else}-->
							<!-- 正序浏览 -->
							<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2">&nbsp;<i class="mktyiconfont icon-paixu" style="font-size: 15px;"></i>{lang post_ascview}</a>
						<!--{/if}-->
					<!--{/if}-->
				</div>
		</div>
		<!--{if $_G['forum_thread']['replies'] <= 0}-->
		<div class="plsn-empty">
			<div class="plsn-empty-icon"><i class="mktyiconfont icon-shafa1"></i></div>
			<p>暂无评论，快来抢沙发吧~</p>
		</div>	
		<!--{/if}-->
   <!--{/if}-->

   <!--{hook/viewthread_postbottom_mobile $postcount}-->
   <!--{eval $postcount++;}-->
   <!--{/loop}-->
	</mikuty-vt-ajaxtag>

</div>

<!--{eval $page = intval($_GET['page'])}-->
<!--{eval $page = $page>0 ? $page : 1;}-->
<!--{eval $mktyTotalPage = @ceil(($_G['forum_thread']['replies'] + 1) / $_G['ppp']);}-->
<!--{if $multipage && $page < $_G['setting']['threadmaxpages'] && $page < $_G['page_next'] && $page==1}-->
	<div id="mikuty-getnextpage">查看更多...</div>
	<script src="template/miku_mobile_ty/static/js/getnextpage.js?{VERHASH}" charset="{CHARSET}"></script>
	<script type="text/javascript">
		if($('#mikuty-getnextpage').length > 0){
			var mkty_nxt_isloading = false;
			var mkty_page = $page + 1;
			var mkty_maxpage = {$mktyTotalPage};
			var mkty_nxtpgurl = 'forum.php?mod=viewthread&tid=$_G[tid]{if $_GET[authorid]}&authorid=$_GET[authorid]{/if}{if $ordertype != 1}&ordertype=2{else}&ordertype=1{/if}&page=';
			mikuty_viewthread_getnextpage(mkty_nxtpgurl);
		}
	</script>
<!--{elseif $page==1 && count($postlist) > 1 }-->
	<div class="mikuty-nomore">已经到底了</div>
<!--{elseif $multipage && $page > 1}-->
	$multipage
<!--{/if}-->

<div class="thread-reply-menu">
	<ul>
		<li class="right-links">
			<a href="javascript:;" {if $_G[uid]}onclick="mktyfavbtn('home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]');"{else}onclick="mktygotologin();"{/if} class="favbtn"><i class="mktyiconfont icon-shoucang1"></i><span class="fav-num" {if !$_G[forum_thread][favtimes]}style="display:none;"{/if}>{$_G[forum_thread][favtimes]}</span></a>
			<a href="javascript:;" id="mytyshareBtn" class="sharebtn"><i class="mktyiconfont icon-share1"></i></a>
		</li>
		<li class="reply-btn">
			<a id="mkty-fastreplay-btn" href="{if $_G[uid]}forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page{else}javascript:mktygotologin();{/if}">
				<i class="mktyiconfont icon-brush"></i> 我也说一句...
			</a>
		</li>
	</ul>
</div>

<!--{if $_G[uid]}-->
<div id="mkty-fastreplay-body" style="display: none;">
</div>
<!--{/if}-->


<script type="text/javascript" src="template/miku_mobile_ty/static/js/jquery.copy.js?{VERHASH}" charset="{CHARSET}"></script>
<div id="mkty-share-box" class="mkty-share-box" style="display: none;">
	<div class="msbx-c">
		<div class="msbx-url cl">
			<div class="msbx-z">感觉帖子不错，那就分享链接给好友吧！</div>
			<div class="msbx-y"><input id="mkty-shareurl" class="ap_n" type="text" onclick="this.select();" oninput="return false;" value="{$_G['siteurl']}forum.php?mod=viewthread&tid=$_G[tid]$fromuid"/></div>
		</div>
		<div id="msbx-error-tips" class="msbx-error-tips" style="display: none;">
			当前浏览器不支持自动复制，请手工复制上面链接。
		</div>
		<div class="msbx-btn cl">
			<button id="msbx-btn-cancel" class="msbx-close ap_n">关闭</button>
			<button id="msbx-btn-copy" class="msbx-copy ap_n">复制链接</button>
		</div>
		<!--{if $_G[uid]}-->
		<div class="msbx-tips">注：您的朋友访问此链接后，您将获得相应的积分奖励。</div>
		<!--{/if}-->
	</div>
</div>
<script type="text/javascript">
	if($.mktyIsSupportedCopy()){
		$.mktyCopy({
		    imgUrl:"template/miku_mobile_ty/static/image/success-tips.png", 
		    text:"复制链接成功",
		    copyUrl:"{$_G['siteurl']}forum.php?mod=viewthread&tid=$_G[tid]$fromuid", 
		    tipTime:2000, 
		    copyId:"#msbx-btn-copy"
		});
	}else{
		$("#msbx-error-tips").css({'display':'block'});
		$("#msbx-btn-copy").attr('disabled','disabled').css({'background-color':'#ccc','border-color':'#c0c0c0'});
	}

	$('#mytyshareBtn').on('tap',function(){
		$('#mkty-share-box').css({'display':'block'});
	});
	$('#msbx-btn-cancel').on('tap',function(){
		$('#mkty-share-box').css({'display':'none'});
	});
	$('#mkty-share-box').on('click', function(e){
		if(e.target == $('#mkty-share-box')[0]){
			$('#mkty-share-box').css({'display':'none'});
		}
	});
	$('#mkty-shareurl').on('click',function(){
		var u = navigator.userAgent; 
		if(!!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/)){
			this.focus();
			this.selectionStart = 0;
			this.selectionEnd = this.value.length;
		}else{
			$('#mkty-shareurl').select();		
		}
	});
	var mktyShareurltext = $('#mkty-shareurl').val();
	$('#mkty-shareurl').on('input',function(){
		$('#mkty-shareurl').val(mktyShareurltext);
	});

</script>

<!--{hook/viewthread_bottom_mobile}-->

<form method="post" autocomplete="off" name="modactions" id="modactions">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="optgroup" />
	<input type="hidden" name="operation" />
	<input type="hidden" name="listextra" value="$_GET[extra]" />
	<input type="hidden" name="page" value="$page" />
</form>
<script type="text/javascript">
	function setanswer(pid, from){
		$('#modactions')[0].action='forum.php?mod=misc&action=bestanswer&tid=' + {$_G[tid]} + '&pid=' + pid + '&from=' + from + '&bestanswersubmit=yes';
		popup.open('您确认要把该回复选为“最佳答案”吗？', 'confirm', "javascript:$('#modactions')[0].submit()");
	}
</script>
<script type="text/javascript">
	function mktyfavbtn(href) {
		$.ajax({
			type:'POST',
			url:(href + '&handlekey=favbtn&inajax=1'),
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			popup.open('请求服务器失败，请检查网络？', 'alert');
			popup.close();
		});
		return false;
	}

	// 点赞按钮
	function recommend(obj, url) {
	    $.ajax({
	        'type': 'GET',
	        'url': url,
	        'dataType': 'xml',
	    }).success(function(s) {
	    	var str = s.lastChild.firstChild.nodeValue;
	        popup.open(s.lastChild.firstChild.nodeValue, 'html');

	    	if(str.match(/\+1/i)){
	    		var cur= parseInt(obj.parentNode.parentNode.querySelector('.zan-num').innerHTML);
	    		cur = cur ? cur : 0;
	        	obj.parentNode.parentNode.querySelector('.zan-num').innerHTML = cur+1;

	    	}else if(str.match(/投票成功/i)){
	    		var cur= parseInt(obj.parentNode.querySelector('.zan-num').innerHTML);
	    		cur = cur ? cur : 0;
				obj.parentNode.querySelector('.zan-num').innerHTML = cur + 1
	    	}

	    }).error(function() {
	        popup.open('请求服务器失败', 'alert');
	    });
	    return false;
	}

	function mktygotologin(){
		popup.open('您还未登录，立即登录？','confirm', 'member.php?mod=logging&action=login');
	}
</script>

<div id="mikuty-scroll-menu">
	<a href="javascript:;" title="{lang scrolltop}" class="scrolltop">
		<span class="mkscm-down"><i class="mktyiconfont icon-zhankai6"></i></span>
		<span class="mkscm-up"><i class="mktyiconfont icon-shouqi2"></i></span>
	</a>
	<a href="javascript:;" title="{lang scrolltop}" id="mkty-scrollmenu" class="mkty-scrollmenu">
		<i class="mktyiconfont icon-wuxuliebiao"></i>
	</a>
</div>
<script>
	$("#mkty-scrollmenu").on('click', function(){
		$("#miku-ty-top-menu-body").css({'display':'block', 'top':'0'});
	});
</script>
<!--{template common/footer}-->
