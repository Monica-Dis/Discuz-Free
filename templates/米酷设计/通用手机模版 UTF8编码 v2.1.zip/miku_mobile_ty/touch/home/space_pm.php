<?php exit; ?>
<!--{eval $_G['home_tpl_titles'] = array('{lang pm}');}-->
<!--{template common/header}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				站内消息
			</li>
			<li class="right-btn">
				<a href="home.php?mod=spacecp&ac=pm" class="btn-left"><i class="mktyiconfont icon-edit"></i></a>
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>
<div class="mycenter-navtab cl">
	<ul>
		<li class="item" {$actives[newpm]}>
			<a href="home.php?mod=space&do=pm&filter=privatepm" {$actives[privatepm]}>{lang private_pm}</a>
		</li>
		<li class="item">
			<a href="home.php?mod=space&do=pm&filter=announcepm" {$actives[announcepm]}>{lang announce_pm}</a>
		</li>
	</ul>
</div>
<!--{if in_array($filter, array('privatepm', 'announcepm'))}-->

	<!--{if $count || $grouppms}-->
		<div class="mycenter-pmbox">
			<ul>
				<!--{if $grouppms}-->
					<!--{loop $grouppms $grouppm}-->
						<li class="item">
							<a href="home.php?mod=space&do=pm&subop=viewg&pmid=$grouppm[id]" class="pm-links">
								<div class="avatar_img">
									<!--{if $grouppm[author]}-->
										<img src="{IMGDIR}/annpm.png" alt="" />
									<!--{else}-->
										<img src="{IMGDIR}/systempm.png" alt="" />
									<!--{/if}-->
								</div>
								<div class="msg-info">
									<div class="title">
										<!--{if !$gpmstatus[$grouppm[id]]}--><span class="num">new</span><!--{/if}-->
										<!--{if $grouppm[author]}-->
											<span class="name">$grouppm[author]</span>
										<!--{else}-->
											<span class="name">系统通知</span>
										<!--{/if}-->
										
									</div>
									<div class="info cl">
										<span class="time"><!--{date($grouppm[dateline], 'u')}--></span>
										<div class="last-msg">
											$grouppm[message]
										</div>
									</div>
								</div>
							</a>
						</li>
					<!--{/loop}-->
				<!--{/if}-->
				<!--{loop $list $key $value}-->
				<li class="item">
						<a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}" class="pm-links">
						<div class="avatar_img">
							<img src="<!--{if $value[pmtype] == 2}-->{STATICURL}image/common/grouppm.png<!--{else}--><!--{avatar($value[touid] ? $value[touid] : ($value[lastauthorid] ? $value[lastauthorid] : $value[authorid]), small, true)}--><!--{/if}-->" />
						</div>
						<div class="msg-info">
							<div class="title">
								<!--{if $value[new]}--><span class="num">$value[pmnum]</span><!--{/if}-->

								<!--{if $value[touid]}-->
									<span class="name">{$value[tousername]}</span>
								<!--{elseif $value['pmtype'] == 2}-->
									<span class="name">
										[{lang chatpm}] 
										<!--{if !empty($value[subject])}-->
											$value[subject]
										<!--{else}-->
											{lang chatpm_author}: $value['firstauthor']
										<!--{/if}-->
									</span>
								<!--{/if}-->
							</div>
							<div class="info cl">
								<span class="time"><!--{date($value[dateline], 'u')}--></span>
								<div class="last-msg" "> 
									<!--{if $value['pmtype'] == 2 && $value['lastauthor']}-->
										$value['lastauthor'] : $value[message]
									<!--{else}-->
										$value[message]
									<!--{/if}-->
								</div>
							</div>
						</div>
					</a>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
		<!--{if $multi}-->$multi<!--{/if}-->

	<!--{else}-->
		<div class="mkty-emp">目前没有收到任何消息。</div>
	<!--{/if}-->
<!--{elseif in_array($_GET[subop], array('view'))}-->
	<div class="wp">
		<div class="msgbox">
			<!--{if !$list}-->
				<div class="mkty-emp">{lang no_corresponding_pm}</div>
			<!--{else}-->
				<!--{if $touid}-->
				<div class="msgbox-tips">
					共有 <span id="membernum" class="xi1">$count</span> 条与 <a href="home.php?mod=space&uid=$touid">$tousername</a> 的交谈记录
				</div>
				<!--{/if}-->
				<!--{loop $list $key $value}-->
					<!--{subtemplate home/space_pm_node}-->
				<!--{/loop}-->
				$multi
			<!--{/if}-->
		</div>
		<!--{if $list}-->
            <form id="pmform" class="pm-form-box" name="pmform" method="post" action="home.php?mod=spacecp&ac=pm&op=send&pmid=$pmid&daterange=$daterange&pmsubmit=yes" >
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<!--{if !$touid}-->
			<input type="hidden" name="plid" value="$plid" />
			<!--{else}-->
			<input type="hidden" name="touid" value="$touid" />
			<!--{/if}-->
			<div class="pmfb-reply cl">
				<input type="text" value="" class="px ap_n" autocomplete="off" id="replymessage" name="message">
				<input type="button" name="pmsubmit" id="pmsubmit" class="pn ap_n formdialog button2" value="{lang reply}" /></div>
            </form>
		<!--{/if}-->
	</div>
<!--{elseif in_array($_GET[subop], array('viewg'))}-->
	
	<!--{if $grouppm}-->
		<div class="grouppm-view">
			<div class="title">
				<div class="avt">
					<!--{if $grouppm[author]}-->
						<img src="{IMGDIR}/annpm.png" alt="" />
					<!--{else}-->
						<img src="{IMGDIR}/systempm.png" alt="" />
					<!--{/if}-->
				</div>
				<div class="info">
					<div class="author">
					<!--{if $grouppm['author']}-->{lang sendmultipmwho}<!--{else}-->{lang sendmultipmsystem}<!--{/if}-->&nbsp;
					</div>
					<div class="time"><!--{date($grouppm[dateline], 'u')}--></div>
				</div>
			</div>
			<div class="content">
				<p class="pm_smry">$grouppm[message]</p>
			</div>
		</div>
	<!--{else}-->
		<div class="emp">
			{lang no_corresponding_pm}
		</div>
	<!--{/if}-->


<!--{else}-->
	<div class="bm_c">
		{lang user_mobile_pm_error}
	</div>
<!--{/if}-->


<div id="mikuty-scroll-menu">
	<a href="javascript:;" title="{lang scrolltop}" class="scrolltop">
		<span class="mkscm-down"><i class="mktyiconfont icon-zhankai6"></i></span>
		<span class="mkscm-up"><i class="mktyiconfont icon-shouqi2"></i></span>
	</a>
	<a href="javascript:;" title="{lang scrolltop}" id="mkty-scrollmenu" class="mkty-scrollmenu">
		<i class="mktyiconfont icon-wuxuliebiao"></i>
	</a>
</div>
<script>
	$("#mkty-scrollmenu").on('click', function(){
		$("#miku-ty-top-menu-body").css({'display':'block', 'top':'0'});
	});
</script>
<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->
