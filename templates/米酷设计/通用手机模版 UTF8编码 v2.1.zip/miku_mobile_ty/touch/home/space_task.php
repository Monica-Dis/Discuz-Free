<?php exit; ?>
<!--{template common/header}-->

<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				我的任务
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>

<div class="mycenter-navtab col-4 cl">
	<ul>
		<li class="item">
			<a href="home.php?mod=task&item=new" $actives[new]>新任务</a>
		</li>
		<li class="item">
			<a href="home.php?mod=task&item=doing" $actives[doing]>进行中</a>
		</li>
		<li class="item">
			<a href="home.php?mod=task&item=done" $actives[done]>已完成</a>
		</li>
		<li class="item">
			<a href="home.php?mod=task&item=failed" $actives[failed]>失败的</a>
		</li>
	</ul>
</div>

<div class="task-main">
	<div class="task-main-body">
	<!--{if empty($do)}-->
		<!--{subtemplate home/space_task_list}-->
	<!--{elseif $do == 'view'}-->
		<!--{subtemplate home/space_task_detail}-->
	<!--{/if}-->
	</div>
</div>

<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->
