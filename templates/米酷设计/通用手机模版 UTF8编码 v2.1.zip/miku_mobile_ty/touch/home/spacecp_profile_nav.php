<?php exit; ?>
<div class="mycenter-navtab col-5 cl">
	<ul>
	<!--{if $operation != 'verify'}-->
		<!--{loop $profilegroup $key $value}-->
			<!--{if $value[available]}-->
			<li  class="item" >
				<a href="home.php?mod=spacecp&ac=profile&op=$key" $opactives[$key]>$value[title]</a>
			</li>
			<!--{/if}-->
		<!--{/loop}-->
	<!--{else}-->
		<!--{if $_G[setting][verify]}-->
			<!--{loop $_G['setting']['verify'] $vid $verify}-->
				<!--{if $verify['available'] && (empty($verify['groupid']) || in_array($_G['groupid'], $verify['groupid']))}-->
					<!--{if $vid != 7}-->
					<li class="item">
						<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" $opactives['verify'.$vid]>$verify['title']</a>
					</li>
					<!--{elseif $_G['setting']['my_app_status'] && $vid == 7}-->
					<li class="item">
						<a href="home.php?mod=spacecp&ac=videophoto" $opactives[videophoto]>{lang video_certification}</a>
					</li>
					<!--{/if}-->
				<!--{/if}-->
			<!--{/loop}-->
		<!--{else}-->
			<div class="mkty-emp">
				站点没有开启此功能
			</div>
		<!--{/if}-->
	<!--{/if}-->
	</ul>
</div>
