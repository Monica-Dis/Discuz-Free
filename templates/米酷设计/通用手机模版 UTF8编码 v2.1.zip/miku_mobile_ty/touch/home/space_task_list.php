<?php exit; ?>
	<!--{if $tasklist}-->
		<ul class="task-list">
			<!--{loop $tasklist $task}-->
				<li class="item cl">
					<div class="task-icon"><img src="$task[icon]" alt="$task[name]" /></div>

					<div class="task-body">
						<div class="task-btn">
							<a href="home.php?mod=task&do=view&id=$task[taskid]">
								<i class="mktyiconfont icon-gerenzhongxinjinru"></i>
							</a>
						</div>
						<div class="task-intro">
							<h3 class="title">
								<a href="home.php?mod=task&do=view&id=$task[taskid]">
									$task[name]
									<!-- <span class="num">（{lang task_applies}: $task[applicants]） </span> -->
								</a>

							</h3>
							<!-- <p class="xg2">$task[description]</p> -->
							<div class="rewards">
								奖励:
								<!--{if $task['reward'] == 'credit'}-->
									{lang credits} $_G['setting']['extcredits'][$task[prize]][title] $task[bonus] $_G['setting']['extcredits'][$task[prize]][unit]
								<!--{elseif $task['reward'] == 'magic'}-->
									{lang magics_title} $listdata[$task[prize]] $task[bonus] {lang magics_unit}
								<!--{elseif $task['reward'] == 'medal'}-->
									{lang medals} $listdata[$task[prize]] <!--{if $task['bonus']}-->{lang expire} $task[bonus] {lang days} <!--{/if}-->
								<!--{elseif $task['reward'] == 'invite'}-->
									{lang invite_code} $task[prize] {lang expire} $task[bonus] {lang days}
								<!--{elseif $task['reward'] == 'group'}-->
									{lang usergroup} $listdata[$task[prize]] <!--{if $task['bonus']}--> $task[bonus] {lang days} <!--{/if}-->
								<!--{/if}-->
							</div>
							<!--{if $_GET['item'] == 'doing'}-->
							<div class="isdoing">
								<div class="pbr" style="width: {if $task[csc]}$task[csc]%{else}8px{/if};"></div>
								<div class="xs0">{lang task_complete} <span id="csc_$task[taskid]">$task[csc]</span>%</div>
							</div>
							<!--{/if}-->
						</div>

					</div>
				</li>
			<!--{/loop}-->
		</ul>
	<!--{else}-->
		<p class="task-list-emp"><!--{if $_GET['item'] == 'new'}-->{lang task_nonew}<!--{elseif $_GET['item'] == 'doing'}-->{lang task_nodoing}<!--{else}-->{lang data_nonexistence}<!--{/if}--></p>

	<!--{/if}-->