<?php exit; ?>
<!--{template common/header}-->

<!--{if $_GET['from'] == 'space'}-->
	<!--{subtemplate home/space_profile_menu}-->
<!--{else}-->
	<header class="header">
		<div id="miku-ty-header" class="hdc cl">
			<ul>
				<li class="left-btn">
					<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
				</li>
				<li class="title">
					我的帖子
				</li>
				<li class="right-btn">
					<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
				</li>
			</ul>
		</div>
	</header>
	<div class="mycenter-navtab cl">
		<ul>
			<li class="item">
				<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=thread" {$orderactives[thread]}>主题</a>
			</li>
			<li class="item">
				<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&type=reply" {$orderactives[reply]}>回复</a>
			</li>
		</ul>
	</div>
<!--{/if}-->
<div class="mycenter-threadlist">
	<ul>
	<!--{if $list}-->
		<!--{loop $list $stid $thread}-->
			<li class="item">
				<div class="subject">
					<!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
					<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]">
						<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
							<span class="mctl_top_icon">置顶</span>
						<!--{elseif $thread['attachment'] == 2}-->
							<span class="mctl_tu_icon">图</span>
						<!--{/if}-->
						$thread[subject]
					</a>
					<!--{else}-->
						<a href="forum.php?mod=viewthread&tid=$thread[tid]" {if $thread['displayorder'] == -1}class="grey"{/if}>
							<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
								<span class="mctl_top_icon">置顶</span>
							<!--{elseif $thread['attachment'] == 2}-->
								<span class="mctl_tu_icon">图</span>
							<!--{/if}-->
							$thread[subject]
							{if $thread['displayorder'] == -1}
								<span class="mctl_del_icon">已删除</span>
							{/if}
						</a>
					<!--{/if}-->
				</div>
				<!--{if $actives[me] && $viewtype=='reply'}-->
				<ul class="reply-list">
					<!--{loop $tids[$stid] $pid}-->
					<!--{eval $post = $posts[$pid];}-->
					<li>
						<img src="{IMGDIR}/icon_quote_m_s.gif" style="vertical-align:middle;" />
						<a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid">
							<!--{if $post[message]}-->{$post[message]}<!--{else}-->......<!--{/if}-->
						</a>
						<img src="{IMGDIR}/icon_quote_m_e.gif" style="vertical-align:middle;" />
					</li>
					<!--{/loop}-->
				</ul>
				<!--{/if}-->

				<div class="thread-info">
					<!-- <a class="from" href="forum.php?mod=forumdisplay&fid=$thread[fid]">#$forums[$thread[fid]]</a> -->
					<span class="num"><i class="mktyiconfont icon-31xiaoxi"></i> {$thread[replies]}</span>
					<span class="num"><i class="mktyiconfont icon-chakan1"></i> {$thread[views]}&nbsp;&nbsp;</span>
					<span class="time">{$thread[dateline]}</span>
				</div>

			</li>
		<!--{/loop}-->
	<!--{else}-->
		<li class="mkty-emp">{lang no_related_posts}</li>
	<!--{/if}-->
	</ul>
	$multi
</div>

<div id="mikuty-scroll-menu">
	<a href="javascript:;" title="{lang scrolltop}" class="scrolltop">
		<span class="mkscm-down"><i class="mktyiconfont icon-zhankai6"></i></span>
		<span class="mkscm-up"><i class="mktyiconfont icon-shouqi2"></i></span>
	</a>
	<a href="javascript:;" title="{lang scrolltop}" id="mkty-scrollmenu" class="mkty-scrollmenu">
		<i class="mktyiconfont icon-wuxuliebiao"></i>
	</a>
</div>
<script>
	$("#mkty-scrollmenu").on('click', function(){
		$("#miku-ty-top-menu-body").css({'display':'block', 'top':'0'});
	});
</script>
<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->
