<?php exit; ?>
<!--{template common/header}-->

<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				<!-- <img src="{STATICURL}image/mobile/images/logo.png" /> -->
				互动提醒
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>

<div class="mycenter-navtab col-4 cl" id="mikuty-notice-navtab">
	<ul>
	<!--{eval $miku_notice_type_num = 0}-->
	<!--{loop $_G['notice_structure'] $key $type}-->
		<!--{if $key!='app'}-->
			<li class="item" >
				<em class="notice_$key"></em>
				<a href="home.php?mod=space&do=notice&view=$key" $opactives[$key]>
					<span style="display:inline-block;position: relative;white-space: nowrap;">
						<!--{eval echo lang('template', 'notice_'.$key)}-->
						<!--{if $_G['member']['category_num'][$key]}-->
							<span class="notice-nav-num">$_G['member']['category_num'][$key]</span>
						<!--{/if}-->
					</span>
				</a>
			</li>
			<!--{eval $miku_notice_type_num++}-->
		<!--{/if}-->
	<!--{/loop}-->
	</ul>
</div>
<script type="text/javascript">
	$('#mikuty-notice-navtab').removeClass('col-4').addClass('col-{$miku_notice_type_num}');
</script>
<div class="mycenter-subnav col-auto cl">
	<ul>
		<!-- <li class="y"><a href="home.php?mod=spacecp&ac=privacy&op=filter" target="_blank" class="xi2">{lang filter_settings}</a></li> -->
		<!--{if $_G['notice_structure'][$view] && ($view == 'mypost' || $view == 'interactive')}-->

			<!--{loop $_G['notice_structure'][$view] $subtype}-->
				<li class="item">
					<a $readtag[$subtype] href="home.php?mod=space&do=notice&view=$view&type=$subtype">
						<!--{eval echo lang('template', 'notice_'.$view.'_'.$subtype)}-->
						<!--{if $_G['member']['newprompt_num'][$subtype]}-->
							($_G['member']['newprompt_num'][$subtype])
						<!--{/if}-->
					</a>
				</li>
			<!--{/loop}-->
		
		<!--{else}-->
			<!-- <li class="a"><a href="home.php?mod=space&do=notice&view=$view"><!--{eval echo lang('template', 'notice_'.$view)}--></a></li> -->
		<!--{/if}-->
	</ul>
</div>
<div class="notice-box">
	<!--{if $view=='userapp'}-->
		<div class="notice-list-emp">
			手机版不支持漫游应用的相关操作！
		</div>
	<!--{else}-->
		<!--{if empty($list)}-->
		<div class="notice-list-emp">
			<!--{if $new == 1}-->
				{lang no_new_notice}<a href="home.php?mod=space&do=notice&isread=1">{lang view_old_notice}</a>
			<!--{else}-->
				{lang no_notice}
			<!--{/if}-->
		</div>
		<!--{/if}-->
		<!--{if $list}-->
			<div class="notice-list">
				<ul>
					<!--{loop $list $key $value}-->
						<li class="item cl {if $key==1}bw0{/if}" $value[rowid] notice="$value[id]">
							<div class="left-icon">
								<!--{if $value[authorid]}-->
								<a href="home.php?mod=space&uid=$value[authorid]"><!--{avatar($value[authorid],middle)}--></a>
								<!--{else}-->
								<img src="{IMGDIR}/systempm.png" alt="systempm" />
								<!--{/if}-->
							</div>
							<div class="right-body">
								<div class="time"><!--{date($value[dateline], 'u')}--></div>
								<div class="content" style="$value[style]">
									$value[note]
								</div>
								<!--{if $value[from_num]}-->
								<div class="tips">{lang ignore_same_notice_message}</div>
								<!--{/if}-->
							</div>
							
						</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{if $view!='userapp' && $space[notifications]}-->
				<!-- 还有 $value[from_num] 个相同通知被忽略 -->
				<div class="mtm mbm"><a href="home.php?mod=space&do=notice&ignore=all">{lang ignore_same_notice_message} <em>&rsaquo;</em></a></div>
			<!--{/if}-->
			<!--{if $multi}--><div class="cl">$multi</div><!--{/if}-->
		<!--{/if}-->

	<!--{/if}-->
</div>

<div id="mikuty-scroll-menu">
	<a href="javascript:;" title="{lang scrolltop}" class="scrolltop">
		<span class="mkscm-down"><i class="mktyiconfont icon-zhankai6"></i></span>
		<span class="mkscm-up"><i class="mktyiconfont icon-shouqi2"></i></span>
	</a>
	<a href="javascript:;" title="{lang scrolltop}" id="mkty-scrollmenu" class="mkty-scrollmenu">
		<i class="mktyiconfont icon-wuxuliebiao"></i>
	</a>
</div>
<script>
	$("#mkty-scrollmenu").on('click', function(){
		$("#miku-ty-top-menu-body").css({'display':'block', 'top':'0'});
	});
</script>
<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->