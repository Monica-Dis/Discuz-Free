<?php exit; ?>
<div id="miku-ty-header-bg">
	<header class="header">
		<div id="miku-ty-header" class="hdc cl">
			<ul>
				<li class="left-btn">
					<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
				</li>
				<li class="title">
					<!--{if $_G['uid'] == $space['uid']}-->{lang myprofile}<!--{else}-->$space[username]{lang otherprofile}<!--{/if}-->
				</li>
				<li class="right-btn">
					<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
				</li>
			</ul>
		</div>
	</header>
	<!--{if isset($space['sightml'])}-->
		<!--{eval $sightml = strip_tags($space['sightml']);}-->
		<!--{eval $maxsigsize = $space[group][maxsigsize];}-->
	<!--{else}-->
		<!--{eval require_once(DISCUZ_ROOT."/template/miku_mobile_ty/php/core.php");}-->
		<!--{eval $sightml = $miku_get_thread->getsign($space['uid']);}-->
		<!--{eval $maxsigsize = $_G['cache']['usergroups'][$space['groupid']]['maxsigsize'];}-->
	<!--{/if}-->
			
	<div class="space-userinfo">
		<div class="avatar"><span><img src="<!--{avatar($space[uid], middle, true)}-->" /></span></div>
		<div class="name">$space[username]</div>
		<!--{if maxsigsize && $sightml}-->
			<div class="sign">
				个性签名: {$sightml}
			</div>
		<!--{else}-->
			<div class="sign">该用户很懒什么也没留下</div>
		<!--{/if}-->
		<div class="mktywaves"><div class="mktywaves2"></div></div>
	</div>
</div>

<div class="mycenter-navtab col-3 cl">
	<ul>
		<li class="item">
			<a href="home.php?mod=space&uid=$space[uid]&do=profile&from=space" {if $do==profile} class="a"{/if}>个人资料</a>
		</li>
		<li class="item">
			<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=thread" {$orderactives[thread]}>主题</a>
		</li>
		<li class="item">
			<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space&type=reply&" {$orderactives[reply]}>回复</a>
		</li>
	</ul>
</div>