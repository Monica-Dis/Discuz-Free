<?php exit; ?>

<!--{if $task['endtime']}-->
	<div class="task-detail-tips">
		<div class="tips-border">{lang task_endtime}</div>
	</div>
<!--{/if}-->
<div class="task-detail">
		<div class="task-header cl">
			<div class="task-icon"><img src="$task[icon]" alt="Icon" width="50" height="50" /></div>
			<div class="task-title">
				<h1 class="h-title">$task[name]</h1>
				<!--{if $task[period]}-->
					<div class="h-time">
					<!--{if $task[periodtype] == 0}-->
						( {lang task_period_hour} )

					<!--{elseif $task[periodtype] == 1}-->
						( {lang task_period_day} )

					<!--{elseif $task[periodtype] == 2}-->
						<!--{eval $periodweek = $_G['lang']['core']['weeks'][$task[period]];}-->
						( {lang task_period_week} )

					<!--{elseif $task[periodtype] == 3}-->
						( {lang task_period_month} )
					<!--{/if}-->
					</div>
				<!--{/if}-->
				<div class="h-intro">$task[description]</div>
			</div>
		</div>
		<div class="task-intro">
			<ul class="intro-list">
				<li class="item">
					<div class="i-name">奖励</div>
					<div class="i-value tast-rewards">
						<!--{if $task['reward'] == 'credit'}-->
							{lang credits} $_G['setting']['extcredits'][$task[prize]][title] $task[bonus] $_G['setting']['extcredits'][$task[prize]][unit]
						<!--{elseif $task['reward'] == 'magic'}-->
							{lang magics_title} $task[rewardtext] $task[bonus] {lang magics_unit}
						<!--{elseif $task['reward'] == 'medal'}-->
							{lang medals} $task[rewardtext] <!--{if $task['bonus']}-->{lang expire} $task[bonus] {lang days} <!--{/if}-->
						<!--{elseif $task['reward'] == 'invite'}-->
							{lang invite_code} $task[prize] {lang expire} $task[bonus] {lang days}
						<!--{elseif $task['reward'] == 'group'}-->
							{lang usergroup} $task[rewardtext] <!--{if $task['bonus']}--> $task[bonus] {lang days} <!--{/if}-->
						<!--{else}-->
							{lang nothing}
						<!--{/if}-->
					</div>
				</li>
				<!--{if $task['viewmessage']}-->
				<li class="item">
					<div class="i-name">完成此任务所需条件</div>
					<div class="i-value">$task[viewmessage]</div>
				</li>
				<!--{else}-->
				<li class="item">
					<div class="i-name">{lang task_complete_condition}</div>
					<div class="i-value">

					<!--{if $taskvars['complete']}-->
						<ul>
							<!--{loop $taskvars['complete'] $taskvar}-->
								<li>$taskvar[name] : $taskvar[value]</li>
							<!--{/loop}-->
						</ul>

					<!--{else}-->
						<p>{lang unlimited}</p>
					<!--{/if}-->
					</div>
				</li>
				<!--{/if}-->
				<li class="item">
					<div class="i-name">{lang task_apply_condition}</div>
					<div class="i-value">
						<!--{if $task[applyperm] || $task[relatedtaskid] || $task[tasklimits] || $taskvars['apply']}-->
							<ul>
								<li><!--{if $task[grouprequired]}-->{lang usergroup}: $task[grouprequired] <!--{elseif $task['applyperm'] == 'member'}-->{lang task_general_users}<!--{elseif $task['applyperm'] == 'admin'}-->{lang task_admins}<!--{/if}--></li>
								<!--{if $task[relatedtaskid]}--><li>{lang task_relatedtask}: <a href="home.php?mod=task&do=view&id=$task[relatedtaskid]">$_G['taskrequired']</a></li><!--{/if}-->
								<!--{if $task[tasklimits]}--><li>{lang task_numlimit}: $task[tasklimits]</li><!--{/if}-->
								<!--{if $taskvars['apply']}-->
									<!--{loop $taskvars['apply'] $taskvar}-->
										<li>$taskvar[name]: $taskvar[value]</li>
									<!--{/loop}-->
								<!--{/if}-->
							</ul>

						<!--{else}-->
							<p>{lang unlimited}</p>
						<!--{/if}-->
					</div>
				</li>
			</ul>
		</div>
		<div class="task-btn">
			<!--{if $allowapply == '-1'}-->
				<div class="isdoing">
					<div class="pbr" style="width: {if $task[csc]}$task[csc]%{else}8px{/if};"></div>
					<div class="xs0">{lang task_complete} <span id="csc_$task[taskid]">$task[csc]</span>%</div>
				</div>

				<div class="btn-box">
					<a href="home.php?mod=task&do=draw&id=$task[taskid]"><img src="{STATICURL}image/task/{if $task[csc] >=100}reward.gif{else}rewardless.gif{/if}" /></a>
					<!--{if $task[csc] < 100}--><a href="home.php?mod=task&do=delete&id=$task[taskid]"><img src="{STATICURL}image/task/cancel.gif" alt="{lang task_quit}" /></a><!--{/if}-->
				</div>
			<!--{elseif $allowapply == '-2'}-->
				<p class="xg2 mbn">{lang task_group_nopermission}</p>
				<a href="javascript:;" onclick="doane(event);showDialog('{lang task_group_nopermission}')"><img src="{STATICURL}image/task/disallow.gif" title="{lang task_group_nopermission}" alt="{lang task_group_nopermission}" /></a>
			<!--{elseif $allowapply == '-3'}-->
				<p class="xg2 mbn">{lang task_applies_full}</p>
				<a href="javascript:;" onclick="doane(event);showDialog('{lang task_applies_full}')"><img src="{STATICURL}image/task/disallow.gif" title="{lang task_applies_full}" alt="{lang task_applies_full}" /></a>
			<!--{elseif $allowapply == '-4'}-->
				<p class="xg2 mbn">{lang task_lose_on}$task[dateline]</p>
			<!--{elseif $allowapply == '-5'}-->
				<p class="xg2 mbn">{lang task_complete_on}$task[dateline]</p>
			<!--{elseif $allowapply == '-6'}-->
				<p class="xg2 mbn">{lang task_complete_on}$task[dateline] &nbsp; {$task[t]}{lang task_applyagain}</p>
				<a href="javascript:;" onclick="doane(event);showDialog('{$task[t]}{lang task_applyagain}')"><img src="{STATICURL}image/task/disallow.gif" title="{$task[t]}{lang task_applyagain}" alt="{lang task_applies_full}" /></a>
			<!--{elseif $allowapply == '-7'}-->
				<p class="xg2 mbn">{lang task_lose_on}$task[dateline] &nbsp; {$task[t]}{lang task_reapply}</p>
				<a href="javascript:;" onclick="doane(event);showDialog('{$task[t]}{lang task_reapply}')"><img src="{STATICURL}image/task/disallow.gif" title="{$task[t]}{lang task_reapply}" alt="{lang task_applies_full}" /></a>
			<!--{elseif $allowapply == '2'}-->
				<p class="xg2 mbn">{lang task_complete_on}$task[dateline] &nbsp; {lang task_applyagain_now}</p>
			<!--{elseif $allowapply == '3'}-->
				<p class="xg2 mbn">{lang task_lose_on}$task[dateline] &nbsp; {lang task_reapply_now}</p>
			<!--{/if}-->
			<!--{if $allowapply > '0'}-->
				<a href="home.php?mod=task&do=apply&id=$task[taskid]"><img src="{STATICURL}image/task/apply.gif" alt="{lang task_newbie_apply}" /></a>
			<!--{/if}-->
		</div>
		<!--{if $task[applicants]}-->
		<div class="task-applicants">
			<a name="parter"></a>
			<div>
				<div>{lang task_applicants}</div>
				<div id="ajaxparter"></div>
			</div>
			<script type="text/javascript">
				$.ajax({
					'url':'home.php?mod=task&do=parter&id=$task[taskid]&inajax=1',
			        'dataType':'xml',
			        'type':'get',
			        'success':function(msg){
			        	$("#ajaxparter").html(msg.firstChild.firstChild.nodeValue);
			        }
				});
			</script>
		</div>
		<!--{/if}-->
</div>