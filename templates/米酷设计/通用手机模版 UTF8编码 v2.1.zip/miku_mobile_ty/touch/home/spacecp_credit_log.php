<?php exit; ?>
<!--{template common/header}-->

<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				我的积分
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>

<div class="mycenter-navtab cl">
	<ul>
		<li class="item">
			<a href="home.php?mod=spacecp&ac=credit&op=base" {$opactives[base]}>我的积分</a>
		</li>
		<li class="item">
			<a href="home.php?mod=spacecp&ac=credit&op=log" {$opactives[log]}>积分记录</a>
		</li>
	</ul>
</div>
<ul class="mycenter-subnav cl">
	<li class="item">
		<a{if $_GET[suboperation] != 'creditrulelog'} class="a"{/if} href="home.php?mod=spacecp&ac=credit&op=log" hidefocus="true">{lang credit_log}</a>
	</li>
	<li class="item">
		<a{if $_GET[suboperation] == 'creditrulelog'} class="a"{/if} href="home.php?mod=spacecp&ac=credit&op=log&suboperation=creditrulelog" hidefocus="true">{lang credit_log_sys}</a>
	</li>
</ul>

<div class="credit-log-list">
<!--{if $_GET[suboperation] != 'creditrulelog'}-->
	<!--{if !empty($loglist)}-->
	<table summary="{lang memcp_credits_log_payment}" cellspacing="0" cellpadding="0" class="dt">
		<!--{loop $loglist $value}-->
		<!--{eval $value = makecreditlog($value, $otherinfo);}-->
		<tr>
			<td class="first-grid">
				<div class="title">
					<!--{if $value['operation']}-->
						<a href="home.php?mod=spacecp&ac=credit&op=log&optype=$value['operation']">$value['optype']</a>
					<!--{else}-->
						$value['title']
					<!--{/if}-->
				</div>
				<div class="detail">
					<!--{if $value['operation']}-->$value['opinfo']<!--{else}-->$value['text']<!--{/if}-->
				</div>
			</td>
			<td class="last-grid">
				<div class="num">
					$value['credit']
				</div>
				<div class="time">$value['dateline']</div>
			</td>
		</tr>
		<!--{/loop}-->
	</table>
	<!--{else}-->
		<div class="mkty-emp">没有记录</div>
	<!--{/if}-->
<!--{elseif $_GET[suboperation] == 'creditrulelog'}-->
	<!--{if !empty($list)}-->
	<table summary="{lang get_credit_histroy}" cellspacing="0" cellpadding="0" >
		<tr>
			<th>{lang action_name}</th>
			<th >总奖励次数/最后奖励时间</th>
			<th>每次奖励</th>
		</tr>
		<!--{eval $i = 0;}-->
		<!--{loop $list $key $log}-->
		<!--{eval $i++;}-->
		<tr{if $i % 2 == 0} class="alt"{/if}>
			<td class="sys-action">
				<a href="home.php?mod=spacecp&ac=credit&op=rule&rid=$log[rid]">$log[rulename]</a>
			</td>
			<td class="sys-times">
				<div>$log[total]次</div>
				<div class="time">
					<!--{date($log[dateline], 'Y-m-d H:i')}-->
				</div>
			
			</td>
			<td class="sys-num">
				<!--{loop $_G['setting']['extcredits'] $key $value}-->
				<!--{eval $creditkey = 'extcredits'.$key;}-->
					{if $log[$creditkey]}
						<div>
							{$value[title]} {if substr($log[$creditkey], 0, 1) != '-'}+{/if}{$log[$creditkey]}
						</div>
					{/if}
				<!--{/loop}-->
			</td>
		</tr>
		<!--{/loop}-->
	</table>
	<!--{else}-->
		<div class="mkty-emp">没有记录</div>
	<!--{/if}-->
<!--{/if}-->
</div>
<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->


<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->