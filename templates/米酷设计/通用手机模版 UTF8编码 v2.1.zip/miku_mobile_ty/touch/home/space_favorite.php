<?php exit; ?>
<!--{template common/header}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				<!-- <img src="{STATICURL}image/mobile/images/logo.png" /> -->
				我的收藏
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>

<div class="mycenter-navtab cl">
	<ul>
		<li class="item">
			<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread" {$actives[thread]}>帖子</a>
		</li>
		<li class="item">
			<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=forum" {$actives[forum]}>板块</a>
		</li>
	</ul>
</div>
<!--{if $_GET['type'] == 'forum'}-->
<div class="fav-forumlist">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
			<li class="item"><a href="$value[url]">$value[title]</a></li>
			<!--{/loop}-->
		<!--{else}-->
		<li class="mkty-emp">{lang no_favorite_yet}</li>
		<!--{/if}-->

	</ul>
</div>
<!--{else}-->
<div class="fav-threadlist">
	<ul>
		<!--{if $list}-->
			<!--{loop $list $k $value}-->
				<li class="item">
					<a class="ftl-del" href="javascript:;" onclick="mktyfavdelbtn('home.php?mod=spacecp&ac=favorite&op=delete&favid={$k}');"><i class="mktyiconfont icon-shanchu4"></i></a>
					<a class="ftl-title" href="$value[url]">$value[title]</a>
				</li>
			<!--{/loop}-->
		<!--{else}-->
		<li class="mkty-emp">{lang no_favorite_yet}</li>
		<!--{/if}-->
	</ul>
</div>
<script>
	function mktyfavdelbtn(href) {
		$.ajax({
			'type': 'get',
			'url': (href + '&handlekey=favbtn&inajax=1'),
			'data':{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			'dataType':'xml',
			'success': function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
			},
			'error':function() {
				popup.open('请求服务器失败，请检查网络？', 'alert');
				popup.close();
			}
		})
		return false;
	}
</script>
<!--{/if}-->
$multi


<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->
