<?php exit; ?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !$_GET['mycenter']}-->
<!--{subtemplate home/space_profile_menu}-->
<div class="space-userbox">
	<ul>
		<li class="item">
			<span class="attr-name">用户组</span><span class="attr-value">
				{$space[group][grouptitle]}
			</span>
		</li>
		<li class="item cl">
			<span class="attr-name">成就</span>
			<span class="attr-value font-14">
				帖子 {$space[posts]}<span class="attr-line">|</span>主题 {$space[threads]}<span class="attr-line">|</span>积分 $space[credits]
			</span>
		</li>
		<li class="item">
			<span class="attr-name">性别</span><span class="attr-value">{$profiles[gender][value]} </span>
		</li>
		<li class="item">
			<span class="attr-name">生日</span><span class="attr-value">{$profiles[birthday][value]} </span>
		</li>
		<li class="item">
			<span class="attr-name">个人主页</span><span class="attr-value font-14">{$profiles[site][value]}</span>
		</li>
		<li class="item">
			<span class="attr-name">在线时间</span><span class="attr-value">$space[oltime] 小时</span>
		</li>
		<li class="item">
			<span class="attr-name">注册时间</span><span class="attr-value">$space[regdate]</span>
		</li>
		<li class="item">
			<span class="attr-name">最后访问</span><span class="attr-value">$space[lastvisit]</span>
		</li>
		<li class="sign-full">
			<span class="attr-name">个性签名</span>
			<span class="attr-value">
			<!--{if maxsigsize && $sightml}-->
				{$sightml}
			<!--{else}-->
				<p style="text-align: right;">
					该用户很懒什么也没留下
				</p>
			<!--{/if}-->
			</span>
		</li>

		<!--{if $_G[uid] && $_G[uid] != $space[uid]}-->
			<li class="space-send-pm">
				<a class="send-pm-btn" href="home.php?mod=spacecp&ac=pm&touid=$space[uid]" id="a_sendpm_$space[uid]" title="{lang send_pm}">发消息给TA</a>
			</li>
		<!--{/if}-->
	</ul>
</div>

<!--{eval $mikutyfooter = true;}-->



<!--{else}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				{if $_GET['mktycstyle'] == 'yes'}主题风格设置{else}我的个人中心{/if}
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>

	<!--{if $_GET['mktycstyle'] == 'yes'}-->

		<style type="text/css">
		.mkty-changestyle-body{padding: 25px 8px;}
		.mkty-changestyle-body .cstb-item{float: left;width: 33.3%;margin-bottom: 15px;text-align: center;}
		.mkty-changestyle-body .cstb-item .cstb-color{display: block;padding: 0 10px;height:65px;}
		.mkty-changestyle-body .cstb-item .cstb-color i{display: block;width: 100%;height:65px;line-height:60px;color:rgba(255,255,255,.85);text-shadow: 1px 1px 4px rgba(0,0,0,0.3);font-size: 0px;border-radius: 2px;}
		.mkty-changestyle-body .cstb-item.active .cstb-color i{font-size: 26px;}
		.mkty-changestyle-body .cstb-item .cstb-name{display: block;line-height: 28px;font-size: 14px;}
		</style>
		<div id="mkty-changestyle-body" class="mkty-changestyle-body">
			<!--{if !empty($_G['style']['extstyle'])}-->
				<ul class="cl">
					{eval $mktyCurentSytle = !empty($_G['cookie']['extstyle']) ? $_G['cookie']['extstyle']: $_G[style][defaultextstyle];}
					<li class="cstb-item{if empty($mktyCurentSytle) || $_G['cookie']['extstyle'] == 'default'} active{/if}">
						<span class="cstb-color" onclick="extstyle('')" title="{lang default}">
							<i class="mktyiconfont icon-duigou1" style='background:#45aaf2;'></i>
						</span>
						<span class="cstb-name">蓝色</span>
					</li>
					<!--{loop $_G['style']['extstyle'] $extstyle}-->
					<li class="cstb-item{if !empty($mktyCurentSytle) && $mktyCurentSytle == $extstyle[0]} active{/if}">
						<span class="cstb-color" onclick="extstyle('$extstyle[0]')" title="$extstyle[1]">
							<i class="mktyiconfont icon-duigou1" style='background:$extstyle[2]'></i>
						</span>
						<span class="cstb-name">{$extstyle[1]}</span>
					</li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->
		</div>
		<script type="text/javascript">
		var CSSLOADED = [];
		function extstyle(css) {
			if(!document.getElementById('css_extstyle')) {
				loadcss('extstyle');
			}
			document.getElementById('css_extstyle').href = css ? css + '/style.css' : 'template/miku_mobile_ty/static/image/style_none.css';
			css = css ? css : 'default';
			setcookie('extstyle', css, 86400 * 30);
		}
		function loadcss(cssname) {
			if(!CSSLOADED[cssname]) {
				var csspath = (typeof CSSPATH == 'undefined' ? 'data/cache/style_' : CSSPATH);
				if(!document.getElementById('css_' + cssname)) {
					css = document.createElement('link');
					css.id = 'css_' + cssname,
					css.type = 'text/css';
					css.rel = 'stylesheet';
					css.href = csspath + STYLEID + '_' + cssname + '.css?' + VERHASH;
					var headNode = document.getElementsByTagName("head")[0];
					headNode.appendChild(css);
				} else {
					document.getElementById('css_' + cssname).href = csspath + STYLEID + '_' + cssname + '&' + VERHASH;
				}
				CSSLOADED[cssname] = 1;
			}
		}
		$('#mkty-changestyle-body .cstb-item').on('click',function(){
			$('#mkty-changestyle-body .cstb-item').removeClass('active');
			$(this).addClass('active');
		});
		</script>
	<!--{else}-->
		<div class="userinfo-top cl">
			<div class="left">
				<img src="<!--{avatar($_G[uid], middle, true)}-->" />
			</div>
			<div class="right">
				<div class="right-btn">
					<a href="home.php?mod=spacecp&ac=profile&op=base"><i class="mktyiconfont icon-gerenzhongxinjinru"></i></a>
				</div>
				<div class="left-info">
					<div class="name">{$_G[username]}</div>
					
					<div class="sign">
						<!--{if $space[group][maxsigsize] && $space[sightml]}-->
							<a href="home.php?mod=spacecp&ac=profile&op=info"><span class="qian-icon">编辑</span>{eval echo strip_tags($space[sightml]);}</a>
						<!--{else}-->
							<a href="home.php?mod=spacecp&ac=profile&op=info">点击编辑你的个性签名</a>
						<!--{/if}-->
					</div>
				</div>
			</div>
		</div>
		<div class="userinfo-nav cl">
			<ul class="nav-body">
				<li class="item">
					<a href="home.php?mod=space&uid={$_G[uid]}&do=thread&view=me">
						<i class="mktyiconfont icon-ziliao1 color-blue"></i>
						<p>帖子</p>
					</a>
				</li>
				<li class="item">
					<a href="home.php?mod=space&do=pm">
						<i class="uin-pmt mktyiconfont icon-xiaoxi2 color-green">{if $_G[member][newpm]}<span class="uin-pmt-dot">...</span>{/if}</i>
						<p>消息</p>
					</a>
				</li>
				<li class="item">
					<a href="home.php?mod=spacecp&ac=credit">
						<i class="mktyiconfont icon-qian color-orange"></i>
						<p>积分</p>
					</a>
				</li>
				<li class="item">
					<a href="home.php?mod=space&uid={$_G[uid]}&do=favorite&view=me&type=thread">
						<i class="mktyiconfont icon-favorite color-tong"></i>
						<p>收藏</p>
					</a>
				</li>
			</ul>
		</div>
		<div class="userinfo-menu">
			<ul>
				<li class="item">
					<a href="home.php?mod=space&do=notice">
						<i class="mktyiconfont icon-xiaoxi3"></i>
						<span class="uim-pmt">互动提醒{if $_G[member][newprompt]}<span class="uim-pmt-dot">...</span>{/if}</span>
						<i class="mktyiconfont icon-gerenzhongxinjinru left-btn"></i>
					</a>
				</li>
				<li class="item">
					<a href="home.php?mod=spacecp&ac=profile&op=password">
						<i class="mktyiconfont icon-anquan3"></i>
						<span>密码安全</span>
						<i class="mktyiconfont icon-gerenzhongxinjinru left-btn"></i>
					</a>
				</li>
				<li class="item">
					<a href="home.php?mod=spacecp&ac=profile">
						<!-- <i class="mktyiconfont icon-icon_xie"></i> -->
						<i class="mktyiconfont icon-edit1"></i>
						<span>个人资料</span>
						<i class="mktyiconfont icon-gerenzhongxinjinru left-btn"></i>
						<!--{if $space[profileprogress] <100}--><span class="uim-comment">已完成 {$space[profileprogress]}%</span><!--{/if}-->
					</a>
				</li>
				<li class="item">
					<a href="home.php?mod=spacecp&ac=profile&op=verify">
						<i class="mktyiconfont icon-zhuceshenpi"></i>
						<span>用户认证</span>
						<i class="mktyiconfont icon-gerenzhongxinjinru left-btn"></i>
					</a>
				</li>
				<li class="item">
					<a href="home.php?mod=task">
						<i class="mktyiconfont icon-renwu1"></i>
						<span>我的任务</span>
						<i class="mktyiconfont icon-gerenzhongxinjinru left-btn"></i>
					</a>
				</li>
				<li class="item">
					<a href="home.php?mod=spacecp&ac=promotion">
						<i class="mktyiconfont icon-fen_xiang"></i>
						<span>访问推广</span>
						<i class="mktyiconfont icon-gerenzhongxinjinru left-btn"></i>
						<span class="uim-comment" style="color:#ff8040;">分享赚积分</span>
					</a>
				</li>
				<li class="item">
					<a href="home.php?mod=space&do=profile&uid={$_G[uid]}">
						<i class="mktyiconfont icon-ziliao"></i>
						<span>我的主页</span>
						<i class="mktyiconfont icon-gerenzhongxinjinru left-btn"></i>
					</a>
				</li>
				<!--{if !empty($_G['style']['extstyle'])}-->
				<li class="item">
					<a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1&mktycstyle=yes">
						<i class="mktyiconfont icon-discover uim-c6"></i>
						<span>主题风格</span>
						<i class="mktyiconfont icon-gerenzhongxinjinru left-btn"></i>
						<span class="uim-styledemo cl">
							<i class="uims-c1"></i><i class="uims-c2"></i><i class="uims-c3"></i>
						</span>
					</a>
				</li>
				<!--{/if}-->
			</ul>
		</div>

		<div class="logout-btn">
			<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">退出登录</a>
		</div>
	<!--{/if}-->
<!--{/if}-->



<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->
<!--{template common/footer}-->
