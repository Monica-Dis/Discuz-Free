<?php exit; ?>

<!--{template common/header}-->

<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				访问推广
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>


<!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}-->
	
	<div class="spc-promotion-tips">
		<!--{if $_G['setting']['creditspolicy']['promotion_visit']}--><p>
			{lang post_promotion_url}
		</p><!--{/if}-->

		<!--{if $_G['setting']['creditspolicy']['promotion_register']}-->
		<p>
		<!--{if $_G['setting']['creditspolicy']['promotion_visit']}-->
			{lang post_promotion_reg}
		<!--{else}-->
			{lang post_promotion}
		<!--{/if}-->
		</p>
		<!--{/if}-->
	</div>

	<div class="spc-promotion">
		<ul>
			<li class="spcpt-item-title">
				<div>{lang mode_one}</div>
			</li>
			<li class="spcpt-item">
				<div>{lang post_promotion_url1}</div>
				<div>
					<input type="text" class="px ap_n" readonly="true" onclick="this.select();" value="$_G[siteurl]?fromuid=$_G[uid]" size="50" />
					<!-- <button type="submit" class="pn ap_n" onclick=""><em>{lang copy}</em></button> -->
				</div>
			</li>
			<li class="spcpt-item">
				<div>{lang post_promotion_url2}</div>
				<div>
					<input type="text" class="px ap_n" readonly="true" onclick="this.select();" value="$_G[siteurl]?fromuser={echo rawurlencode($_G[username])}" size="50" />
					<!-- <button type="submit" class="pn ap_n" onclick=""><em>{lang copy}</em></button> -->
				</div>
			</li>


			<li class="spcpt-item-title">
				<div>{lang mode_two}</div>
			</li>
			<li class="spcpt-item">
				<div><div>通过点击帖子下方的 <i class="mktyiconfont icon-share1"></i> 按钮来“复制链接”，推广成功后也可以获得积分奖励 &nbsp; <a href="forum.php?forumlist=1" class="xi2">去推广帖子»</a></div></div>
			</li>
		</ul>
	</div>
<!--{/if}-->



<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->
<!--{template common/footer}-->