<?php exit; ?>
<!--{eval 
	$_G[home_tpl_titles] = array('{lang task}');
}-->
<!--{template common/header}-->
<ul class="task-parter">
	<!--{loop $parterlist $parter}-->
		<li class="item">
			<a href="home.php?mod=space&do=profile&uid=$parter[uid]" title="{if $parter[status] == 1}{lang task_complete}{elseif $parter[status] == -1}{lang task_failed}{elseif $parter[status] == 0}{lang task_complete} $parter[csc]%{/if}" class="avt">$parter[avatar]</a>
			<p>
				<a class="username" href="home.php?mod=space&do=profile&uid=$parter[uid]" title="{lang member_viewpro}">$parter[username]</a>
			</p>
		</li>
	<!--{/loop}-->
</ul>
<!--{template common/footer}