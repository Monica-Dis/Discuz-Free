<?php exit; ?>
<!--{template common/header}-->


<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				{if $operation == 'verify'}认证{elseif $operation == 'password'}密码安全{else}个人资料修改{/if}
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>


<!--{if $validate}-->
	
	<p>手机页面不支持更复杂的操作！</p>

<!--{elseif $operation == 'password'}-->
		<div class="profile-passwd-tips">
			<!--{if !$_G['member']['freeze']}-->
				<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->{lang old_password_comment}<!--{elseif $wechatuser}-->{lang wechat_config_newpassword_comment}<!--{else}-->{lang connect_config_newpassword_comment}<!--{/if}-->

			<!--{elseif $_G['member']['freeze'] == 1}-->
				<strong>{lang freeze_pw_tips}</strong>

			<!--{elseif $_G['member']['freeze'] == 2}-->
				<strong>{lang freeze_email_tips}</strong>
			<!--{/if}-->
		</div>

		<form action="home.php?mod=spacecp&ac=profile" method="post" autocomplete="off">
			<input type="hidden" value="{FORMHASH}" name="formhash" />
			<ul class="profile-passwd">
				<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->
					<li class="item">
						<div class="v-name">{lang old_password}</div>
						<div class="v-input">
							<input type="password" name="oldpassword" id="oldpassword" class="px" placeholder="必填" />
						</div>
					</li>
				<!--{/if}-->
				<li class="item">
					<div class="v-name">{lang new_password}</div>
					<div class="v-input">
						<input type="password" name="newpassword" id="newpassword" class="px" />
						<p class="d" id="chk_newpassword">{lang memcp_profile_passwd_comment}</p>
					</div>
				</li>
				<li class="item">
					<div class="v-name">{lang new_password_confirm}</div>
					<div class="v-input">
						<input type="password" name="newpassword2" id="newpassword2"class="px" />
						<p class="d" id="chk_newpassword2">{lang memcp_profile_passwd_comment}</p>
					</div>
				</li>
				<li class="item" id="contact"{if $_GET[from] == 'contact'} style="background-color: {$_G['style']['specialbg']};"{/if}>
					<div class="v-name">{lang email}</div>
					<div class="v-input">
						<input type="text" name="emailnew" id="emailnew" value="$space[email]" class="px" />
						<p class="d">
							<!--{if empty($space['newemail'])}-->
								{lang email_been_active}
							<!--{else}-->
								$acitvemessage
							<!--{/if}-->
						</p>
						<!--{if $_G['setting']['regverify'] == 1 && (($_G['group']['grouptype'] == 'member' && $_G['adminid'] == 0) || $_G['groupid'] == 8) || $_G['member']['freeze']}--><p class="d">{lang memcp_profile_email_comment}</p><!--{/if}-->
					</div>
				</li>
				<!--{if $_G['member']['freeze'] == 2}-->
				<li class="item">
					<div class="v-name">{lang freeze_reason}</div>
					<div class="v-input">
						<textarea rows="3" cols="80" name="freezereson" class="pt">$space[freezereson]</textarea>
						<p class="d" id="chk_newpassword2">{lang freeze_reason_comment}</p>
					</div>
				</li>
				<!--{/if}-->
				<li class="item">
					<div class="v-name">{lang security_question}</div>
					<div class="v-input">
						<select name="questionidnew" id="questionidnew">
							<option value="" selected>{lang memcp_profile_security_keep}</option>
							<option value="0">{lang security_question_0}</option>
							<option value="1">{lang security_question_1}</option>
							<option value="2">{lang security_question_2}</option>
							<option value="3">{lang security_question_3}</option>
							<option value="4">{lang security_question_4}</option>
							<option value="5">{lang security_question_5}</option>
							<option value="6">{lang security_question_6}</option>
							<option value="7">{lang security_question_7}</option>
						</select>
						<p class="d">{lang memcp_profile_security_comment}</p>
					</div>
				</li>
				<li class="item">
					<div class="v-name">{lang security_answer}</div>
					<div class="v-input">
						<input type="text" name="answernew" id="answernew" class="px" />
						<p class="d">{lang memcp_profile_security_answer_comment}</p>
					</div>
				</li>

			</ul>
			<!--{if $secqaacheck || $seccodecheck}-->
			<div class="profile-passwd-sec">
				<!--{eval $sectpl = '<table cellspacing="0" cellpadding="0" class="tfm"><tr><th><sec></th><td><sec><p class="d"><sec></p></td></tr></table>';}-->
				<!--{subtemplate common/seccheck}-->
			</div>
			<!--{/if}-->
			<div class="profile-passwd-btn">
				<button type="submit" name="pwdsubmit" value="true" class="pn pnc" />{lang save}</button>
			</div>
			<input type="hidden" name="passwordsubmit" value="true" />
		</form>
		<script type="text/javascript">
			var strongpw = new Array();
			<!--{if $_G['setting']['strongpw']}-->
				<!--{loop $_G['setting']['strongpw'] $key $val}-->
				strongpw[$key] = $val;
				<!--{/loop}-->
			<!--{/if}-->
			var pwlength = <!--{if $_G['setting']['pwlength']}-->$_G['setting']['pwlength']<!--{else}-->0<!--{/if}-->;
			checkPwdComplexity($('newpassword'), $('newpassword2'), true);
		</script>


<!--{else}-->
	<!--{subtemplate home/spacecp_profile_nav}-->
		<!--{if $vid}-->
		<div class="profile-tips">
			<p class="tips-content {if !$showbtn}tips-green{/if}"><!--{if $showbtn}-->{lang spacecp_profile_message1}<!--{else}-->{lang spacecp_profile_message2}<!--{/if}--></p>
		</div>
		<!--{/if}-->
	<iframe id="frame_profile" name="frame_profile" style="display: none"></iframe>
	<div class="profile-box">
		<form action="{if $operation != 'plugin'}home.php?mod=spacecp&ac=profile&op=$operation{else}home.php?mod=spacecp&ac=plugin&op=profile&id=$_GET[id]{/if}" method="post" enctype="multipart/form-data" autocomplete="off"{if $operation != 'plugin'} target="frame_profile"{/if} onsubmit="clearErrorInfo();">
			<input type="hidden" value="{FORMHASH}" name="formhash" />
			<!--{if $_GET[vid]}-->
			<input type="hidden" value="$_GET[vid]" name="vid" />
			<!--{/if}-->
			
		<ul class="profile-list">
				<li class="item cl">
					<div class="pf-name">{lang username}</div>
					<div class="pf-value">$_G[member][username]</div>
				</li>
			<!--{loop $settings $key $value}-->
			<!--{if $value[available]}-->
				<li class="item cl" id="tr_$key">
					<div id="th_$key" class="pf-name">
						<!--{if $value[required]}--><span class="rq" title="{lang required}">*</span><!--{/if}-->$value[title]
					</div>
					<div class="pf-value" id="td_$key">
						<div class="v-right {if $operation == 'verify'}v-no-right{/if}">
							<!--{if $vid}-->
							<input type="hidden" name="privacy[$key]" value="3" />
							<!--{else}-->
							<select name="privacy[$key]">
								<option value="0"{if $privacy[$key] == "0"} selected="selected"{/if}>{lang open_privacy}</option>
								<option value="1"{if $privacy[$key] == "1"} selected="selected"{/if}>{lang friend_privacy}</option>
								<option value="3"{if $privacy[$key] == "3"} selected="selected"{/if}>{lang secrecy}</option>
							</select>
							<!--{/if}-->
						</div>
						<div class="v-left {if $operation == 'verify'}v-no-right{/if}">
							$htmls[$key]
						</div>
					</div>
				</li>
			<!--{/if}-->
			<!--{/loop}-->
			<!--{if $allowcstatus && in_array('customstatus', $allowitems)}-->
			<li class="item cl">
				<div class="pf-name" id="th_customstatus">{lang permission_basic_status}</div>
				<div class="pf-value" id="td_customstatus">
					<div class="v-100">
						<input type="text"  class="ap_n" value="$space[customstatus]" name="customstatus" id="customstatus" />
					</div>
					<div class="rq mtn" id="showerror_customstatus"></div>
				</div>
			</li>
			<!--{/if}-->
			<!--{if $_G['group']['maxsigsize'] && in_array('sightml', $allowitems)}-->
			<li class="item cl">
				<div class="pf-name" id="th_sightml">{lang personal_signature}</div>
				<div class="pf-value" id="td_sightml">
					<div class="v-100">
						<textarea rows="3" name="sightml" id="sightmlmessage" class="pt ap_n" onkeydown="ctrlEnter(event, 'profilesubmitbtn');">$space[sightml]</textarea>
					</div>
					<div id="showerror_sightml" class="rq mtn"></div>
				</div>
			</li>
			<!--{/if}-->
			<!--{if in_array('timeoffset', $allowitems)}-->
			<li class="item cl" style="display: none">
				<div class="pf-name" id="th_timeoffset">{lang time_zone}</div>
				<div class="pf-value" id="td_timeoffset">
					<!--{eval $timeoffset = array({lang timezone});}-->
					<select name="timeoffset">
						<!--{loop $timeoffset $key $desc}-->
						<option value="$key"{if $key==$space[timeoffset]} selected="selected"{/if}>$desc</option>
						<!--{/loop}-->
					</select>
					<p class="mtn">{lang current_time} : <!--{date($_G[timestamp])}--></p>
					<p class="d">{lang time_zone_message}</p>
				</div>
			</li>
			<!--{/if}-->
			<!--{if $operation == 'contact'}-->
			<li class="item cl">
				<div class="pf-name" id="th_sightml">Email</div>
				<div class="pf-value" id="td_sightml">
					<div class="v-100">
						$space[email]&nbsp;(<a href="home.php?mod=spacecp&ac=profile&op=password&from=contact#contact">{lang modify}</a>)
					</div>
				</div>
			</li>
			<!--{/if}-->
			<!--{if $showbtn}-->
			<li class="item-btn">
				<div class="pf-name">&nbsp;</div>
				<div class="pf-value">
					<input type="hidden" name="profilesubmit" value="true" />
					<button type="submit" name="profilesubmitbtn" id="profilesubmitbtn" value="true" class="pn pnc" /><strong>{lang save}</strong></button>
					<span id="submit_result" class="rq"></span>
				</div>
			</li>
			<!--{/if}-->
		</ul>
		</form>
	</div>

	<style type="text/css">
		.tfm th .rq { float: right; font-size: 14px; color:red;}
	</style>
	<script type="text/javascript">
		function show_error(fieldid, extrainfo) {
			var elem = $('#th_'+fieldid);
			if(elem[0]) {
				elem.addClass('rq');
				fieldname = elem.html();
				extrainfo = (typeof extrainfo == "string") ? extrainfo : "";
				$('#showerror_'+fieldid).html("{lang check_date_item} " + extrainfo);
				$('#'+fieldid).focus();
			}
		}
		function show_success(message) {
			message = message == '' ? '{lang update_date_success}' : message;
			popup.open(message, 'alert');
			setTimeout(function(){
				top.window.location.href = top.window.location.href;
			},3000);
		}
		function clearErrorInfo() {
			$("#profile-list div").each(function(i, obj){
				if(typeof obj.id != "undefined" && obj.id.indexOf("_")){
					var ids = string.split('_');
					if(ids[0] == "showerror") {
						obj.innerHTML = '';
						$('#th_' + ids[1]).removeClass();
					}
				}
			});
		}

		//修改生日表单的3级联动js代码
		function showbirthday(){
			var el = $('#birthday')[0];
			var birthday = el.value;
			el.length=0;
			el.options.add(new Option('日', ''));
			for(var i=0;i<28;i++){
				el.options.add(new Option(i+1, i+1));
			}
			if($('#birthmonth')[0].value!="2"){
				el.options.add(new Option(29, 29));
				el.options.add(new Option(30, 30));
				switch($('#birthmonth')[0].value){
					case "1":
					case "3":
					case "5":
					case "7":
					case "8":
					case "10":
					case "12":{
						el.options.add(new Option(31, 31));
					}
				}
			} else if($('#birthyear')[0].value!="") {
				var nbirthyear=$('#birthyear')[0].value;
				if(nbirthyear%400==0 || (nbirthyear%4==0 && nbirthyear%100!=0)) el.options.add(new Option(29, 29));
			}
			el.value = birthday;
		}

		//修改住址的4级联动js代码
		function showdistrict(container, elems, totallevel, changelevel, containertype) {
			var getdid = function(elem) {
				var op = elem.options[elem.selectedIndex];
				return op['did'] || op.getAttribute('did') || '0';
			};
			var pid = changelevel >= 1 && elems[0] && $(elems[0]) ? getdid($('#' + elems[0])[0]) : 0;
			var cid = changelevel >= 2 && elems[1] && $(elems[1]) ? getdid($('#' + elems[1])[0]) : 0;
			var did = changelevel >= 3 && elems[2] && $(elems[2]) ? getdid($('#' + elems[2])[0]) : 0;
			var coid = changelevel >= 4 && elems[3] && $(elems[3]) ? getdid($('#' + elems[3])[0]) : 0;
			var url = 'home.php?mod=misc&ac=ajax&op=district&container='+container+'&containertype='+containertype
				+'&province='+elems[0]+'&city='+elems[1]+'&district='+elems[2]+'&community='+elems[3]
				+'&pid='+pid + '&cid='+cid+'&did='+did+'&coid='+coid+'&level='+totallevel+'&handlekey='+container+'&inajax=1'+(!changelevel ? '&showdefault=1' : '');
			$.ajax({
				'url':url,
			    'dataType':'xml',
			    'type':'get',
			    'success':function(data, s){
			    	$('#'+container).html(data.firstChild.firstChild.nodeValue);
			    }
			})
		}
	function display(id) {
		var obj = $('#'+id)[0];
		if(obj.style.visibility) {
			obj.style.visibility = obj.style.visibility == 'visible' ? 'hidden' : 'visible';
		} else {
			obj.style.display = obj.style.display == '' ? 'none' : '';
		}
	}
	</script>
<!--{/if}-->



<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->
