<?php exit; ?>
<!--{template common/header}-->

<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				我的积分
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>

<div class="mycenter-navtab cl">
	<ul>
		<li class="item" {$actives[newpm]}>
			<a href="home.php?mod=spacecp&ac=credit&op=base" {$opactives[base]}>我的积分</a>
		</li>
		<li class="item">
			<a href="home.php?mod=spacecp&ac=credit&op=log" {$opactives[log]}>积分记录</a>
		</li>
	</ul>
</div>
<!--{if in_array($_GET['op'], array('base'))}-->
	<ul class="credit-list">
	<!--{eval $creditid=0;}-->
	<!--{if $_GET['op'] == 'base' && $_G['setting']['creditstrans']}-->
		<!--{eval $creditid=$_G['setting']['creditstrans'];}-->
		<!--{if $_G['setting']['extcredits'][$creditid]}-->
			<!--{eval $credit=$_G['setting']['extcredits'][$creditid]; }-->
			<li class="item credit-main">
				<div class="title">我的账户余额:</div>
				<div class="num">
					<!--{echo getuserprofile('extcredits'.$creditid);}--> {$credit[unit]}
					<span class="unit">{$credit[title]}</span>
				</div>
			</li>
		<!--{/if}-->
	<!--{/if}-->
	<!--{loop $_G['setting']['extcredits'] $id $credit}-->
		<!--{if $id!=$creditid}-->
		<li class="item">
			<em>{$credit[title]}: </em><!--{echo getuserprofile('extcredits'.$id);}--> {$credit[unit]}
		</li>
		<!--{/if}-->
	<!--{/loop}-->
	<!--{if  $_GET['op'] == 'base'}-->
		<li class="item">
			<em>总积分: </em>{$_G['member']['credits']}
		</li>
		<li class="item  credit-rule">{$creditsformulaexp}</li>
	<!--{/if}-->
	</ul>

<!--{else}-->
	<ul><li>手机页面不支持更复杂的操作！</li></ul>
<!--{/if}-->



<!--{eval $mktyfooter_menu = array('wode'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->