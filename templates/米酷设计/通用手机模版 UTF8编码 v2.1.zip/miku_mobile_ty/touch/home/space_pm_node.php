<?php exit; ?>
<!--{if $value[msgfromid] != $_G['uid']}-->
<div class="friend_msg cl">
	<div class="avat z"><img src="<!--{avatar($value[msgfromid], small, true)}-->" /></div>
	<div class="dialog_white z">
		<div class="dialog_c">
			<div class="dialog_t">$value[message]</div>
			<div class="dialog_arrow"></div>
		</div>
		<div class="date"><!--{date($value[dateline], 'u')}--></div>
	</div>
</div>
<!--{else}-->
<div class="self_msg cl">
	<div class="avat y"><img src="<!--{avatar($value[msgfromid], small, true)}-->" /></div>
	<div class="dialog_green y">			
		<div class="dialog_c">
			<div class="dialog_t">$value[message]</div>
			<div class="dialog_arrow"></div>
		</div>
		<div class="date"><!--{date($value[dateline], 'u')}--></div>
	</div>
</div>
<!--{/if}-->
