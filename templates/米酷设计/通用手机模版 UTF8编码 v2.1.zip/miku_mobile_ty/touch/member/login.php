<?php exit; ?>
<!--{eval $mktyBodyIsWhite = true;}-->
<!--{template common/header}-->
<!--{if !$_GET['infloat']}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				{if $_GET['viewlostpw']==1}找回密码{else}登录{/if}
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>
<!--{else}-->
<div class="login-box-infloat">
	<div class="lbif-close" onclick="popup.close();"><i class="mktyiconfont icon-guanbi"></i></div>
	<div class="lbif-body">
		<div class="lbif-title">立即登录</div>
		<!--{subtemplate common/config_global}-->
<!--{/if}-->



<!--{if empty($_GET['viewlostpw'])}-->
	{eval $loginhash = 'L'.random(4);}
	<div class="loginbox <!--{if $_GET[infloat]}-->login_pop<!--{/if}-->">
		<!--{if $_GET[infloat]}-->
			<h2 class="log_tit"><a href="javascript:;" onclick="popup.close();"><span class="icon_close y">&nbsp;</span></a>{lang login}</h2>
		<!--{/if}-->
			<form id="loginform" method="post" action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
			<input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
			<input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
			<input type="hidden" name="fastloginfield" value="username">
			<input type="hidden" name="cookietime" value="2592000">
			<!--{if $auth}-->
				<input type="hidden" name="auth" value="$auth" />
			<!--{/if}-->
		<div class="login-from-list">
			<ul>
				<li class="item">
					<input type="text" value="" tabindex="1" class="login-input" size="30" autocomplete="off" value="" name="username" placeholder="{lang inputyourname}" fwin="login">
				</li>
				<li class="item">
					<input type="password" tabindex="2" class="login-input" size="30" value="" name="password" placeholder="{lang login_password}" fwin="login">
				</li>
				<li class="item questionli">
					<div class="login_select">
			<!-- 			<span class="login-btn-inner">
							<span class="login-btn-text">
								<span class="span_question">{lang security_question}</span>
							</span>
							<span class="icon-arrow">&nbsp;</span>
						</span> -->
						<select id="questionid_{$loginhash}" name="questionid" class="sel_list">
							<option value="0" selected="selected">{lang security_question}</option>
							<option value="1">{lang security_question_1}</option>
							<option value="2">{lang security_question_2}</option>
							<option value="3">{lang security_question_3}</option>
							<option value="4">{lang security_question_4}</option>
							<option value="5">{lang security_question_5}</option>
							<option value="6">{lang security_question_6}</option>
							<option value="7">{lang security_question_7}</option>
						</select>
					</div>
				</li>
				<li class="item bl_none answerli" style="display:none;">
					<input type="text" name="answer" id="answer_{$loginhash}" class="login-input" size="30" placeholder="{lang security_a}">
				</li>
				<!--{if $seccodecheck}-->
				<li class="item">
					<!--{subtemplate common/seccheck}-->
				</li>
				<!--{/if}-->
			</ul>
			<div class="btn_login">
				<button tabindex="3" value="true" name="submit" type="submit" class="formdialog pn pnc">
					<span>{lang login}</span>
				</button>
			</div>
		</div>
		</form>
		<div class="register-links cl">
			<p class="left-links">
				<!--{if $_G['setting']['regstatus']}-->
					<a href="member.php?mod={$_G[setting][regname]}">新用户注册</a>
				<!--{else}-->
					<span style="color:#c0c0c0;">手机版不能注册账号</span>
				<!--{/if}-->
			</p>
			<p class="right-links"><a href="member.php?mod=logging&action=login&viewlostpw=1">忘记密码</a></p>
		</div>
		<div class="other-login">
			<div class="other-login-tips">
				<div class="tips-content">第三方账号登录</div>
			</div>
			<ul class="login-method-list">
				<!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
					<li class="item"><a href="$_G[connect][login_url]&statfrom=login_simple">
						<div class="qqlogin"></div>
						<p>QQ登录</p></a>
					</li>
				<!--{/if}-->
				
				{$mikuty_c_fastlogin}					
			</ul>
		</div>


		<!--{hook/logging_bottom_mobile}-->
	</div>

	<!--{if $_G['setting']['pwdsafety']}-->
		<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
	<!--{/if}-->
	<!--{eval updatesession();}-->

	<script type="text/javascript">
		(function() {
			$(document).on('change', '.sel_list', function() {
				var obj = $(this);
				// $('.span_question').text(obj.find('option:selected').text());
				if(obj.val() == 0) {
					$('.answerli').css('display', 'none');
					$('.questionli').addClass('bl_none');
				} else {
					$('.answerli').css('display', 'block');
					$('.questionli').removeClass('bl_none');
				}
			});
		 })();
	</script>


<!--{elseif $_GET['viewlostpw']==1}-->
	<div class="lostpw-form">
		<form method="post" autocomplete="off" id="lostpwform_$loginhash" action="member.php?mod=lostpasswd&lostpwsubmit=yes">
			<ul class="c cl">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="handlekey" value="lostpwform" />
				<li class="item">
					<input type="text" class="lostpw-input" name="email"  size="30" value="" placeholder="Email地址" />
				</li>
				<li class="item">
					<input type="text" class="lostpw-input" name="username" size="30" value=""  placeholder="用户名"/>
				</li>
				<li class="item-btn">
					<button class="submit-btn" type="submit" name="lostpwsubmit" value="true"><span>提交</span></button>
				</li>
			</ul>
		</form>
		<div class="back-to-login">
			<a href="member.php?mod=logging&action=login">
				返回登录页面
			</a>
		</div>
	</div>
	
<!--{/if}-->

<!--{if !$_GET['infloat']}-->
	</div>
</div>
<!--{/if}-->

<!--{eval $mikutyfooter = true;}-->
<!--{template common/footer}-->
