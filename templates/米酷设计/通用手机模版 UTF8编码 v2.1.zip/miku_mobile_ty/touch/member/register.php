<?php exit; ?>
<!--{eval $mktyBodyIsWhite = true;}-->
<!--{template common/header}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				注册账号
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>


<div class="register-box">
	<div class="login_from">
		<form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}&mobile=2">
		<input type="hidden" name="regsubmit" value="yes" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
		<input type="hidden" name="referer" value="$dreferer" />
		<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
		<input type="hidden" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
		<ul>
			<li class="item">
				<input type="text" tabindex="1" class="px p_fre"  autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip}" fwin="login">
			</li>
			<li class="item">
				<input type="password" tabindex="2" class="px p_fre"  value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password}" fwin="login">
			</li>
			<li class="item">
				<input type="password" tabindex="3" class="px p_fre"  value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2}" fwin="login">
			</li>
			<li class="item bl_none">
				<input type="email" tabindex="4" class="px p_fre" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login">
			</li>

			<!--{if empty($invite) && ($_G['setting']['regstatus'] == 2 || $_G['setting']['regstatus'] == 3)}-->
				<li class="item">
					<input type="text" name="invitecode" autocomplete="off" tabindex="5" class="px p_fre" value="" placeholder="{lang invite_code}" fwin="login">
				</li>
			<!--{/if}-->

			<!--{if $_G['setting']['regverify'] == 2}-->
				<li class="item">
					<input type="text" name="regmessage" autocomplete="off" tabindex="6" class="px p_fre"  value="" placeholder="{lang register_message}" fwin="login">
				</li>
			<!--{/if}-->
			<!--{if $secqaacheck || $seccodecheck}-->
				<li class="item">
				<!--{subtemplate common/seccheck}-->
				</li>
			<!--{/if}-->
		</ul>
		<div class="btn_register"><button tabindex="7" value="true" name="regsubmit" type="submit" class="formdialog pn pnc"><span>{lang quickregister}</span></button></div>
		<div class="login-links">
			<a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" >{lang login_now}</a>
		</div>
	</div>
	
	</form>
</div>

<!--{eval updatesession();}-->
<!--{eval $mikutyfooter = true;}-->
<!--{template common/footer}-->
