<?php exit; ?>
<!--{eval $mktyBodyIsWhite = true;}-->
<!--{template common/header}-->

<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				设置新密码
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>
<div class="getpasswd-box">
	<form id="getpasswd-form" method="post" autocomplete="off" action="member.php?mod=getpasswd&uid=$uid&id=$hashid&sign=$_GET[sign]">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<ul class="cl">
			<li class="item" style="text-indent: 5px;">
				<em class="tips">{lang username}：</em><strong>$member[username]</strong>
			</li>

			<li class="item">
				<input type="password" id="newpasswd1" name="newpasswd1" size="25" class="px" placeholder="{lang new_password}" />
			</li>
	
			<li class="item">
				<input type="password" id="newpasswd2" name="newpasswd2" size="25" class="px" placeholder="{lang new_password_confirm}" />
			</li>
			<li class="item">
				<i id="newpasswd-tips" class="submit-tips">
					{lang register_password_tips}<!--{if $_G['setting']['pwlength']}-->, {lang register_password_length_tips1} $_G['setting']['pwlength'] {lang register_password_length_tips2}<!--{/if}-->
				</i>
			</li>

		</ul>
		<div class="btn-box">
			<button id="newpasswd-submit" class="disabled" type="submit" disabled="disabled" name="getpwsubmit" value="true"><span>{lang submit}</span></button>
		</div>
	</form>
	<script type="text/javascript">
		//检验密码的健壮性
		var strongpw = new Array();
		<!--{if $_G['setting']['strongpw']}-->
			<!--{loop $_G['setting']['strongpw'] $key $val}-->
			strongpw[$key] = $val;
			<!--{/loop}-->
		<!--{/if}-->

		// 检验密码的复杂度
		var pwlength = <!--{if $_G['setting']['pwlength']}-->$_G['setting']['pwlength']<!--{else}-->0<!--{/if}-->;
		checkPwdComplexity($('#newpasswd1')[0], $('#newpasswd2')[0]);

		function checkPwdComplexity(firstObj, secondObj) {
			firstObj.onblur = function () {
				if(firstObj.value == '') {
					var pwmsg = '请填写密码';
					if(pwlength > 0) {
						pwmsg += ', 最小长度为 '+pwlength+' 个字符';
					}
					errormessage(pwmsg);
				}else{
					checkpassword(firstObj, secondObj);
				}
			};
			firstObj.oninput = function () {
				if(pwlength == 0 || firstObj.value.length >= pwlength) {
					var passlevels = new Array('','弱','中','强');
					var passlevel = checkstrongpw(firstObj);
					errormessage('<span class="passlevel-'+passlevel+'">密码强度:'+passlevels[passlevel]+'</span>');
				}
				if(firstObj.value != '') {
					checkpassword(firstObj, secondObj);
				}
			};
			secondObj.onblur = function () {
				if(secondObj.value == '') {
					errormessage('请再次输入密码');
				}
				checkpassword(firstObj, secondObj);
			};
			secondObj.oninput = function(){
				if(secondObj.value != '') {
					checkpassword(firstObj, secondObj);
				}
			}

			$('#getpasswd-form').on('submit', function(){
				return checkpassword(firstObj, secondObj);
			});
		}
		function checkstrongpw(id) {
			var passlevel = 0;
			if(id.value.match(/\d+/g)) {
				passlevel ++;
			}
			if(id.value.match(/[a-z]+/ig)) {
				passlevel ++;
			}
			if(id.value.match(/[^a-z0-9]+/ig)) {
				passlevel ++;
			}
			return passlevel;
		}
		function errormessage(msg) {
			if (msg == 'ok'){
				$("#newpasswd-tips").html('').css('display','block');
				$("#newpasswd-submit").removeAttr('disabled');
				$("#newpasswd-submit").removeClass('disabled');
			}else{
				$("#newpasswd-tips").html(msg).css('display','block');
				$("#newpasswd-submit").attr('disabled','disabled');
				$("#newpasswd-submit").addClass('disabled');
			}
		}

		function checkpassword(id1, id2) {
			if(!id1.value && !id2.value) {
				errormessage('请填写密码');
				return false;
			}
			if(pwlength > 0) {
				if(id1.value.length < pwlength) {
					errormessage('密码太短，不得少于 '+pwlength+' 个字符');
					return false;
				}
			}
			if(strongpw) {
				var strongpw_error = false, j = 0;
				var strongpw_str = new Array();
				for(var i in strongpw) {
					if(strongpw[i] === 1 && !id1.value.match(/\d+/g)) {
						strongpw_error = true;
						strongpw_str[j] = '数字';
						j++;
					}
					if(strongpw[i] === 2 && !id1.value.match(/[a-z]+/g)) {
						strongpw_error = true;
						strongpw_str[j] = '小写字母';
						j++;
					}
					if(strongpw[i] === 3 && !id1.value.match(/[A-Z]+/g)) {
						strongpw_error = true;
						strongpw_str[j] = '大写字母';
						j++;
					}
					if(strongpw[i] === 4 && !id1.value.match(/[^A-Za-z0-9]+/g)) {
						strongpw_error = true;
						strongpw_str[j] = '特殊符号';
						j++;
					}
				}
				if(strongpw_error) {
					errormessage('密码太弱，密码中必须包含 '+strongpw_str.join('，'));
					return false;
				}
			}
			if(id1.value != id2.value) {
				errormessage('两次输入的密码不一致');
				return false;
			} else {
				errormessage('ok');
				return true;
			}
			return false;
		}
	</script>
</div>
<!--{template common/footer}-->