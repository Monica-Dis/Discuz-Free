<?php exit; ?>

<!--{template common/header}-->
<div class="report-box">

	<form method="post" autocomplete="off" id="form_$_GET[handlekey]" name="form_$_GET[handlekey]" action="misc.php?mod=report" {if $_G['inajax']}onsubmit="mktyreport_post(this);return false;"{/if}>
		<h3 class="rpb-title">
			<em>请选择举报理由</em>
		</h3>
		<div class="rpb-body" id="return_$_GET[handlekey]">
			<p class="cl" id="report_reasons"></p>

			<div class="report_other_$_GET[handlekey]" style="display:none">
				<textarea class="rpb-msg ap_n" name="message" class="" placeholder="必填！请填写举报内容（200个字符内）">
				</textarea>
			</div>
		</div>
		<div class="rpb-pns">
			<button type="submit" class="rpb-ok ap_n">{lang confirms}</button>
			<input type="buttom" onclick="popup.close();return false;" class="rpb-close ap_n" value="取消"/>
		</div>

		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="reportsubmit" value="true" />
		<input type="hidden" name="rtype" value="$_GET[rtype]" />
		<input type="hidden" name="rid" value="$_GET[rid]" />

		<!--{if $_GET['fid']}-->
		<input type="hidden" name="fid" value="$_GET[fid]" />
		<!--{/if}-->

		<!--{if $_GET['uid']}-->
		<input type="hidden" name="uid" value="$_GET[uid]" />
		<!--{/if}-->
		<input type="hidden" name="url" value="$_GET[url]" />
		<input type="hidden" name="inajax" value="$_G[inajax]" />

		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />


	</form>
</div>

<script type="text/javascript" reload="1">
var reasons = {lang report_reason_message};
var reasonstring = '';
for (i=0; i<reasons.length; i++) {
	reasonstring += '<label class="rpb-lb"><input type="radio" name="report_select" onclick="mktyreportmenu_switch(this, \'.report_other_{$_GET[handlekey]}\', \'' + (i < reasons.length -1 ? 'hide' : 'show') +'\');" value="' + reasons[i] + '"> ' + reasons[i] + '</label>';
}
document.getElementById('report_reasons').innerHTML = reasonstring;

</script>

<!--{template common/footer}-->