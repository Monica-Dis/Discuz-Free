<?php exit; ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset={CHARSET}">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="format-detection" content="telephone=no" />
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<title><!--{if !empty($navtitle)}-->$navtitle - <!--{/if}--><!--{if empty($nobbname)}--> $_G['setting']['bbname'] - <!--{/if}--> {lang waptitle} - Powered by Discuz!</title>

<link rel="stylesheet" href="template/miku_mobile_ty/static/image/style.css?{VERHASH}" type="text/css" media="all">
<link rel="stylesheet" href="template/miku_mobile_ty/static/image/iconfont/iconfont.css?{VERHASH}" type="text/css" media="all">
<link rel="stylesheet" href="template/miku_mobile_ty/static/js/swiper.min.css?{VERHASH}" type="text/css" media="all">


<!--{if !empty($_G['cookie']['extstyle'])}-->
<!--{if $_G['cookie']['extstyle'] != 'default'}-->
<link id="css_extstyle" rel="stylesheet" href="{$_G['cookie']['extstyle']}/style.css?{VERHASH}" type="text/css" media="all">
<!--{/if}-->
<!--{elseif !empty($_G['style'][defaultextstyle])}-->
<link id="css_extstyle" rel="stylesheet" href="{$_G['style'][defaultextstyle]}/style.css?{VERHASH}" type="text/css" media="all">
<!--{/if}-->

<script src="template/miku_mobile_ty/static/js/jquery.min.js?{VERHASH}"></script>
<script src="template/miku_mobile_ty/static/js/swiper.jquery.js?{VERHASH}"></script>
<!-- <script src="template/miku_mobile_ty/static/js/jquery.lazyload.min.js?{VERHASH}"></script> -->
<script src="template/miku_mobile_ty/static/js/jquery.lazyload.js?{VERHASH}"></script>

<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>

<script src="template/miku_mobile_ty/static/js/common.js?{VERHASH}" charset="{CHARSET}"></script>

<!--{if $mktyBodyIsWhite}-->
<style type="text/css">
	html, body{background-color: #fff;}
	.bg{background-color: #fff;}
</style>
<!--{/if}-->
</head>
<body class="bg">

<!--{if !empty($_SERVER['HTTP_REFERER']) && stripos($_SERVER['HTTP_REFERER'], $_SERVER['HTTP_HOST']) !== false}-->
	{eval $miku_goBackUrl = "javascript:history.go(-1);";}
<!--{else}-->
	{eval $miku_goBackUrl = "forum.php";}
<!--{/if}-->



<!--{hook/global_header_mobile}-->

<!--{subtemplate common/config_global}-->