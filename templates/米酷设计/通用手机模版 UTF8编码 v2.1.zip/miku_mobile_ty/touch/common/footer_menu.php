<?php exit; ?>

<div id="miku-ty-bottom-menu" class="mkty-bottom-menu">
	<ul class="cl">
		<li class="btmm-item{if $mktyfooter_menu[shouye]} active{/if}"><a href="forum.php?mod=guide&view=new">
			<span class="btmm-icon"><i class="mktyiconfont {if $mktyfooter_menu[shouye]}icon-shouyefill{else}icon-shouye4{/if}"></i></span>
			<span class="btmm-txt">首页</span></a>
		</li>
		<li class="btmm-item{if $mktyfooter_menu[shequ]} active{/if}"><a href="forum.php?forumlist=1">
			<span class="btmm-icon"><i class="mktyiconfont {if $mktyfooter_menu[shequ]}icon-liuyanfill{else}icon-liuyan1{/if}"></i></span>
			<span class="btmm-txt">社区</span></a>
		</li>
		<li class="btmm-item{if $mktyfooter_menu[sousuo]} active{/if}" id="miku-ty-findnav"><a href="javascript:;">
			<span class="btmm-icon"><i class="mktyiconfont {if $mktyfooter_menu[sousuo]}icon-caidaniconfaxianhui{else}icon-caidaniconfaxianhui{/if}"></i></span>
			<span class="btmm-txt">发现</span></a>
		</li>
		<li class="btmm-item{if $mktyfooter_menu[fatie]} active{/if}"><a href="forum.php?mod=misc&action=nav">
			<span class="btmm-icon"><i class="mktyiconfont {if $mktyfooter_menu[fatie]}icon-post1{else}icon-post1{/if}"></i></span>
			<span class="btmm-txt">发帖</span></a>
		</li>
		<li class="btmm-item{if $mktyfooter_menu[wode]} active{/if}"><a href="{if $_G[uid]}home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1{else}javascript:mktygotologin();{/if}">
			<span class="btmm-icon"><i class="mktybm-pmt mktyiconfont {if $mktyfooter_menu[wode]}icon-yonghufill{else}icon-yonghu1{/if}">{if $_G[member][newpm] || $_G[member][newprompt]}<span class="mktybm-pmt-dot"></span>{/if}</i></span>
			<span class="btmm-txt">我的</span></a>
		</li>
	</ul>
</div>


