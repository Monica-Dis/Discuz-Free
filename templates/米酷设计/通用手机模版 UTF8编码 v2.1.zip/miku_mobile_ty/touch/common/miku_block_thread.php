<?php exit; ?>
<!--{block return}-->
	<!--{if !empty($message)}-->
		{$message}{if dstrlen($message) > 86} ...{/if}
	<!--{/if}-->
<!--{/block}-->