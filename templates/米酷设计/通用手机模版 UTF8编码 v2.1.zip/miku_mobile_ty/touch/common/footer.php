<?php exit; ?>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->



<div id="mask" style="display:none;"></div>

<!--{if !$nofooter}-->
<div class="footer"{if $mikutyfooter} style="background-color: #fff;"{/if}>
	<p >&copy; Comsenz Inc.</p>
</div>
<!--{/if}-->
<!--{if $mktyfooter_menu}-->
<div style="padding:15px;"></div>
<!--{/if}-->



<div id="miku-ty-top-menu-body" class="mask-menu" style="display: none; top:-100%;">

	<div class="top-nav cl">
		<ul class="cl">
			<li class="left-btn">
				<!-- <a href="forum.php?mod=guide&view=new"><i class="mktyiconfont icon-caidaniconshouyehui"></i></a> -->
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="logo">
				{$mikuty_c_sitelogo}
			</li>
			<li class="right-btn">
				<a id="miku-ty-top-menu-close" href="javascript:;" class="btn"><i class="mktyiconfont icon-weibiaoti-"></i></a>
			</li>
		</ul>
	</div>
	
	<div class="menu-body">
		<div class="mkty-crumb-nav" id="mkty-crumb">
			<div class="cmbn-list">
				<a href="forum.php?mod=guide&view=new"><i class="mktyiconfont icon-caidaniconshouyehui"></i></a>
				<a href="#"><i class="mktyiconfont icon-zhankai5 mkty-qianjin"></i>论坛</a>
			</div>
		</div>
		<div class="menu-search">
			<form class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="form-body">
					<table width="100%" cellspacing="0" cellpadding="0">
						<tbody>
						<tr>
							<td class="search-input-td">
								<input value="" autocomplete="off"  name="srchtxt" id="scform_srchtxt" value="" placeholder="搜索帖子">
							</td>
							<td width="56" align="center" class="submit-btn-td">
								<div>
									<input type="hidden" name="searchsubmit" value="yes">
									<button type="submit" class="submit-btn">
										<i class="mktyiconfont icon-sousuo1"></i>
									</button>
								</div>
							</td>
						</tr>
						</tbody>
					</table>
				</div>
			</form>
		</div>


		<div class="menu-userinfo cl">
			<div class="links">
				<a href="home.php?mod=space&do=pm" class="mui-pm{if $_G[member][newpm]} new{/if}">我的消息<span class="pm-new"></span></a>
				<a href="home.php?mod=space&do=notice" class="mui-pmt{if $_G[member][newprompt]} new{/if}">提醒<span class="pmt-new"></span></a>
			</div>
			<a class="info" href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->">
				<span class="avatar" ><img src="{avatar($_G[uid],small,true)}" alt=""> </span>
				<!--{if $_G[uid]}-->
				<span class="uname">$_G[username]</span>
				<!--{else}-->
				<span class="uname">立即登录</span>
				<!--{/if}-->
			</a>
		</div>
		<div class="menu-navlist cl">
			<ul>
				{$mikuty_c_popupnav}
			</ul>
		</div>
	</div>
</div>

<script type="text/javascript">
	$("#miku-ty-top-menu").on('click', function(){
		$("#miku-ty-top-menu-body").css({'display':'block', 'top':'0'});
		$("#miku-ty-top-menu-body").css({'top':'0'});
	});

	$("#miku-ty-top-menu-body").on('click', function(evt){
		if(evt.target == this){
			$("#miku-ty-top-menu-body").css({'top':'-100%'});
			setTimeout(function(){
				$(this).css('display', 'none');
			}, 200);
		}
	});

	$("#miku-ty-top-menu-close").on('click', function(evt){
		$("#miku-ty-top-menu-body").css({'top':'-100%'});
		setTimeout(function(){
			$(this).css('display', 'none');
		}, 200);
	});

	$("#miku-ty-top-menu-body").on('touchmove', function(evt){
		evt.preventDefault();
	});

	if($("#mkty-crumb-body").length > 0){
		var mkty_tmp = $("#mkty-crumb-body").html();
		mkty_tmp = mkty_tmp.replace(/<em>.*?<\/em>/ig, '<em><i class="mktyiconfont icon-enter mkty-qianjin"></i></em>');
		mkty_tmp = mkty_tmp.replace(/<a href="forum\.php\?gid=.*?<\/em>/i, '');
		mkty_tmp = mkty_tmp.replace(/<a href="forum\.php\?(mobile=2)?".*?<\/em>/i, '');
		$("#mkty-crumb").html(mkty_tmp);
	}else{
		$("#mkty-crumb").css({'display':'none'});
	}
</script>



<div id="miku-ty-findnav-body" class="mktyfind-box" style="display: none; top:100%;">
	<div class="fdb-top">
		<div class="cl">
			<div id="miku-ty-fnb-date">
			</div>
		</div>
	</div>
	<div class="fdb-middle">
		<div class="fddm-bigimg">
			{$mikuty_c_findadimg}
		</div>
	</div>
	<div class="fdb-bottom">
		<div class="fdbb-title">
			亲，你想做点什么呢...
		</div>
		<ul class="cl">
			{$mikuty_c_findnavlist}
		</ul>
		<div class="fdbb-btn">
			<div class="fdbb-close"><i id="miku-ty-findnav-close" class="mktyiconfont icon-guanbi"></i></div>
		</div>
	</div>
	<div class="fdbb-close2"><i id="miku-ty-findnav-close2" class="mktyiconfont icon-importedlayers"></i></div>
</div>

<script src="template/miku_mobile_ty/static/js/common_nav.js?{VERHASH}" charset="{CHARSET}"></script>
<script type="text/javascript">
	mktygetDate();
	$("#miku-ty-findnav").on('tap',function(){
		// $("#miku-ty-findnav-body").css({'display':'block'});
		mktyFindnavShow();
	});
	$("#miku-ty-findnav-close").on('tap',function(){
		// $("#miku-ty-findnav-body").css({'display':'none'});
		mktyFindnavHide();
	});
	$("#miku-ty-findnav-close2").on('tap',function(){
		// $("#miku-ty-findnav-body").css({'display':'none'});
		mktyFindnavHide();
	});
	$('#miku-ty-findnav-body').on('touchmove', function(evt){
		evt.preventDefault();
	});
	function mktyFindnavShow(){
		$("#miku-ty-findnav-body").css({'display':'block'});
		setTimeout(function(){
			$("#miku-ty-findnav-body").css({'top':'0'});
		},10);
	}
	function mktyFindnavHide(){
		$("#miku-ty-findnav-body").css({'top':'100%'});
		setTimeout(function(){
			$("#miku-ty-findnav-body").css({'display':'none'});
		},200);

	}
</script>

</body>
</html>
<!--{eval updatesession();}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->


