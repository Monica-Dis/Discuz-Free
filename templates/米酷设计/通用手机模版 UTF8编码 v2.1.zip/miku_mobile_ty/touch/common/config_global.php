<?php exit; ?>

<!--1、首页、论坛页面的网站名称修改-->
<!--{block mikuty_c_sitename}-->
	米酷设计
<!--{/block}-->



<!--2、顶部全局菜单弹出窗口---顶部的网站logo修改-->
<!--{block mikuty_c_sitelogo}-->
	<img src="template/miku_mobile_ty/static/image/logo.png" alt="米酷设计">
<!--{/block}-->



<!--3、顶部全局菜单弹出窗口---导航菜单区域修改-->
<!--{block mikuty_c_popupnav}-->
	<li><a href="forum.php?mod=guide&view=new">首页</a></li>
	<li><a href="forum.php?forumlist=1">社区</a></li>
	<li><a href="search.php?mod=forum">搜索</a></li>
	<li><a href="#">自定义1</a></li>
	<li><a href="#">自定义2</a></li>
	<li><a href="#">自定义3</a></li>
<!--{/block}-->


           

<!--4、板块列表页顶部广告图片链接修改-->
<!--{block mikuty_c_forumad}-->
	<a href="#"><img src="template/miku_mobile_ty/static/image/2.jpg" alt="adimg"></a>
	<span class="comment">推广</span>
<!--{/block}-->



<!--5、登录页面的第3方登录链接修改-->
<!--{block mikuty_c_fastlogin}-->
	<li class="item"><a href="#">
			<div class="wxlogin"></div>
			<p>微信登录</p></a>
	</li>
	<li class="item"><a href="#">
			<div class="wblogin"></div>
			<p>微博登录</p></a>
	</li>
<!--{/block}-->



<!--6、发现页面的广告图片-->
<!--{block mikuty_c_findadimg}-->
	<a href="#"><img src="template/miku_mobile_ty/static/image/2.jpg" alt="img"></a>
<!--{/block}-->


<!--7、发现页面的导航设置-->
<!--{block mikuty_c_findnavlist}-->
	<li class="fdbb-item"><a href="forum.php?mod=misc&action=nav">
		<div class="fdbb-icon fdbb-bgc1"><img src="template/miku_mobile_ty/static/image/cat/k11.png" alt="icon"></div>
		<div class="fdbb-txt">发帖子</div></a>
	</li>
	<li class="fdbb-item"><a href="home.php?mod=task">
		<div class="fdbb-icon fdbb-bgc2"><img src="template/miku_mobile_ty/static/image/cat/k5.png" alt="icon"></div>
		<div class="fdbb-txt">做任务</div></a>
	</li>
	<li class="fdbb-item"><a href="home.php?mod=spacecp&ac=promotion">
		<div class="fdbb-icon fdbb-bgc3"><img src="template/miku_mobile_ty/static/image/cat/k7.png" alt="icon"></div>
		<div class="fdbb-txt">赚积分</div></a>
	</li>
	<li class="fdbb-item"><a href="search.php?mod=forum">
		<div class="fdbb-icon fdbb-bgc4"><img src="template/miku_mobile_ty/static/image/cat/k2.png" alt="icon"></div>
		<div class="fdbb-txt">搜索</div>	</a>
	</li>
	<li class="fdbb-item"><a href="#">
		<div class="fdbb-icon fdbb-bgc6"><img src="template/miku_mobile_ty/static/image/cat/k4.png" alt="icon"></div>
		<div class="fdbb-txt">签到</div>	</a>
	</li>
	<li class="fdbb-item"><a href="#">
		<div class="fdbb-icon fdbb-bgc5"><img src="template/miku_mobile_ty/static/image/cat/k9.png" alt="icon"></div>
		<div class="fdbb-txt">自定义</div></a>
	</li>
	<li class="fdbb-item"><a href="#">
		<div class="fdbb-icon fdbb-bgc4"><img src="template/miku_mobile_ty/static/image/cat/k3.png" alt="icon"></div>
		<div class="fdbb-txt">自定义</div></a>
	</li>
	<li class="fdbb-item"><a href="#">
		<div class="fdbb-icon fdbb-bgc1"><img src="template/miku_mobile_ty/static/image/cat/k22.png" alt="icon"></div>
		<div class="fdbb-txt">自定义</div></a>
	</li>
<!--{/block}-->
