<?php exit; ?>
<!--{echo output_ajax()}-->]]></root><!--{eval exit;}-->