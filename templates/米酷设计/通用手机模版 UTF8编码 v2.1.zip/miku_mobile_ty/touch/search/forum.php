<?php exit; ?>
<!--{template common/header}-->
<header class="header">
	<div id="miku-ty-header" class="hdc cl">
		<ul>
			<li class="left-btn">
				<a href="{$miku_goBackUrl}"><i class="mktyiconfont icon-return1"></i></a>
			</li>
			<li class="title">
				搜索
			</li>

			<li class="right-btn">
				<a id="miku-ty-top-menu" href="javascript:;" class="btn"><i class="mktyiconfont icon-chakan"></i></a>
			</li>
		</ul>
	</div>
</header>


<form id="searchform" class="searchform" method="post" autocomplete="off" action="search.php?mod=forum&mobile=2">
			<input type="hidden" name="formhash" value="{FORMHASH}" />

			<!--{subtemplate search/pubsearch}-->

			<!--{eval $policymsgs = $p = '';}-->
			<!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
			<!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
			<!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
			<!--{/loop}-->
			<!--{if $policymsgs}--><p>{lang search_credit_msg}</p><!--{/if}-->
</form>

<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
	<!--{subtemplate search/thread_list}-->
<!--{/if}-->

<div id="mikuty-scroll-menu">
	<a href="javascript:;" title="{lang scrolltop}" class="scrolltop">
		<span class="mkscm-down"><i class="mktyiconfont icon-zhankai6"></i></span>
		<span class="mkscm-up"><i class="mktyiconfont icon-shouqi2"></i></span>
	</a>
	<a href="javascript:;" title="{lang scrolltop}" id="mkty-scrollmenu" class="mkty-scrollmenu">
		<i class="mktyiconfont icon-wuxuliebiao"></i>
	</a>
</div>
<script>
	$("#mkty-scrollmenu").on('click', function(){
		$("#miku-ty-top-menu-body").css({'display':'block', 'top':'0'});
	});
</script>
<!--{eval $mktyfooter_menu = array('sousuo'=>true);}-->
<!--{subtemplate common/footer_menu}-->

<!--{template common/footer}-->
