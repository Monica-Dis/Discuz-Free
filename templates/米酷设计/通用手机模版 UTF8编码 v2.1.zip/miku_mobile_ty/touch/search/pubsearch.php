<?php exit; ?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<div class="search">
	<div class="form-body">
		<table width="100%" cellspacing="0" cellpadding="0">
		<tbody>
			<tr>
				<td class="search-input-td">
					<input value="$keyword" autocomplete="off"  name="srchtxt" id="scform_srchtxt" value="" placeholder="搜索帖子">
				</td>
				<td width="56" align="center" class="submit-btn-td">
					<div>
						<input type="hidden" name="searchsubmit" value="yes">
						<!-- <input type="submit" value="{lang search}" class="submit-btn"> -->
						<button type="submit" class="submit-btn">
							<i class="mktyiconfont icon-sousuo1"></i>
						</button>
					</div>
				</td>
			</tr>
		</tbody>
		</table>
	</div>


	<!--{if empty($keyword)}-->
	<div class="hot-search cl">
		<div class="title">搜索热词</div>
		<!--{if $_G['setting']['srchhotkeywords']}-->
			<!--{loop $_G['setting']['srchhotkeywords'] $val}-->
				<!--{if $val=trim($val)}-->
					<!--{eval $valenc=rawurlencode($val);}-->
					<!--{block srchhotkeywords[]}-->
						<!--{if !empty($searchparams[url])}-->
							<a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}" sc="1">$val</a>
						<!--{else}-->
							<a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch" sc="1">$val</a>
						<!--{/if}-->
					<!--{/block}-->
				<!--{/if}-->
			<!--{/loop}-->
		<!--{echo implode('', $srchhotkeywords);}-->
		<!--{/if}-->
	</div>
	<!--{/if}-->
</div>
