<?php exit; ?>
<div class="threadlist">
	<h2 class="thread_tit">
		<!--{if $keyword}-->{lang search_result_keyword} <!--{if $modfid}--><a href="forum.php?mod=modcp&action=thread&fid=$modfid&keywords=$modkeyword&submit=true&do=search&page=$page" target="_blank">{lang goto_memcp}</a><!--{/if}--><!--{else}-->{lang search_result}<!--{/if}-->
	</h2>
	<!--{if empty($threadlist)}-->
		<ul><li class="item mkty-emp"><a href="javascript:;">{lang search_nomatch}</a></li></ul>
	<!--{else}-->
			<ul>
				<!--{eval require_once(DISCUZ_ROOT."/template/miku_mobile_ty/php/core.php");}-->

				<!--{loop $threadlist $thread}-->
				<li class="item">

					<a style="display: block;" href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]">	
						<div class="subject"  $thread[highlight]>
							$thread[subject]
						</div>
						<div class="summary">
							<!--{if !$thread['price'] && !$thread['readperm']}-->
								$thread[message]
							<!--{else}-->
								{lang thread_list_message1}
							<!--{/if}-->
						</div>

						<!--{if $thread['attachment'] == 2}-->
							<div class="img-list cl">						
								<!--{eval $piclist = $miku_get_thread->getpic($thread[tid]);}-->
								<!--{if count($piclist)==3}-->
									<!--{loop $piclist $pic}-->
										<!--{eval $url = getforumimg($pic['aid'], 0, 250, 200, 'fixwr');}-->
									<div style="float:left;width: 33.3%;overflow: hidden;">
										<div style="background:#f9f9f9;margin-right:3px;overflow: hidden;" class="mkimg-list-3">
											<img class="mktylazy" src="template/miku_mobile_ty/static/image/imgnone_a.gif" data-original="{$url}" width="100%" height="100%">
										</div>
									</div>
									<!--{/loop}-->
								<!--{elseif count($piclist)>=1}-->
									<!--{loop $piclist $pic}-->
										<!--{eval $url = getforumimg($pic['aid'], 0, 280, 165, 'fixwr');}-->
									<div style="float:left;width: 50%;overflow: hidden;">
										<div style="background:#f9f9f9;margin-right:3px;overflow: hidden;" class="mkimg-list-2">
										<img class="mktylazy" src="template/miku_mobile_ty/static/image/imgnone_b.gif" data-original="{$url}" width="100%" height="100%">
										</div>
									</div>
									<!--{/loop}-->
								<!--{/if}-->

							</div>
						<!--{/if}-->
					</a>

					<div class="thread-info cl">
						<dl class="left">
							<!--{if $thread['authorid'] && $thread['author']}-->
								<a href="home.php?mod=space&do=profile&uid=$thread[authorid]">
									<dt><img class="avatar" src="{avatar($thread[authorid],small,true)}" alt=""></dt>
									<dd>$thread[author]</dd>
								</a>
							<!--{else}-->
								<!--{if $_G['forum']['ismoderator']}-->
									<a href="home.php?mod=space&uid=$thread[authorid]" target="_blank">
										<dt><img class="avatar" src="{avatar($thread[authorid],small,true)}" alt=""> </dt>
										<dd>{lang anonymous}</dd>
									</a>
									<!--{else}-->
									<a href="javascript:;">
										<dt><img class="avatar" src="{avatar($thread[authorid],small,true)}" alt=""></dt>
										<dd>{lang anonymous}</dd>
									</a>
								<!--{/if}-->
							<!--{/if}-->
						</dl>
						<div class="right">
							<span><i class="mktyiconfont icon-chakan1"></i> $thread[views]&nbsp;&nbsp;</span>
							<span><i class="mktyiconfont icon-31xiaoxi"></i> $thread[replies]</span>
						</div>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
	<!--{/if}-->
	$multipage
</div>
