<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class miku_get_thread{
	function getsummary($threadlist, $messagelength = 80, $nospecial = false) {
		$tidarray= $messagearr = $returnarr = array();

		foreach($threadlist as $key=>$thread) {
			$tidarray[$thread['posttableid']][] = $thread['tid'];
		}

		foreach($tidarray as $key => $var) {
			if($key == 0) {
				$posttable = 'forum_post';
			} else {
				$posttable = "forum_post_{$key}";
			}
			$query = DB::query("SELECT tid, message FROM ".DB::table($posttable)." WHERE tid IN  (".dimplode($var).") AND first=1");
			while($result = DB::fetch($query)) {
				$messagearr[$result['tid']] = $result['message'];
			}
		}

		if($messagearr) {
			foreach($messagearr as $tid => $var) {
				$thread = $threadlist[$tid];
				if($nospecial) {
					$thread['special'] = 0;
				}

				if($thread['special'] == 1) {
					$polloptions = array();
					$multiple = DB::result_first("SELECT multiple FROM ".DB::table('forum_poll')." WHERE tid='$tid'");
					$optiontype = $multiple ? 'checkbox' : 'radio';
					$query = DB::query("SELECT polloptionid, polloption FROM ".DB::table('forum_polloption')." WHERE tid='$tid' ORDER BY displayorder");
					while($polloption = DB::fetch($query)) {
						$polloption['polloption'] = preg_replace("/\[url=(https?){1}:\/\/([^\[\"']+?)\](.+?)\[\/url\]/i",
							"<a href=\"\\1://\\2\" target=\"_blank\">\\3</a>", $polloption['polloption']);
						$polloptions[] = $polloption;
					}

				} elseif($thread['special'] == 2) {
					$trade = C::t('forum_trade')->fetch_first_goods($tid);
					$trade['aid'] = $trade['aid'] ? getforumimg($trade['aid']) : '';
					$trades[$tid][] = $trade;


				} elseif($thread['special'] == 3) {
					$extcredits = $_G['settings']['extcredits'];
					$creditstransextra = $_G['settings']['creditstransextra'];
					$rewardend = $thread['price'] < 0;
					$rewardprice = abs($thread['price']);
					$message = $this->messagecutstr($var, $messagelength, '');


				} elseif($thread['special'] == 4) {
					$message = $this->messagecutstr($var, $messagelength, '');
					$activity = DB::fetch_first("SELECT aid, number, applynumber FROM ".DB::table('forum_activity')." WHERE tid='$tid'");
					$activity['aid'] = $activity['aid'] ? getforumimg($activity['aid']) : '';
					$activity['aboutmember'] = $activity['number'] - $activity['applynumber'];

				} elseif($thread['special'] == 5) {
					$message = $this->messagecutstr($var, $messagelength, '');
					$debate = C::t('forum_debate')->fetch($tid);
					$debate['affirmvoteswidth'] = $debate['affirmvotes']  ? intval(80 * (($debate['affirmvotes'] + 1) / ($debate['affirmvotes'] + $debate['negavotes'] + 1))) : 1;
					$debate['negavoteswidth'] = $debate['negavotes']  ? intval(80 * (($debate['negavotes'] + 1) / ($debate['affirmvotes'] + $debate['negavotes'] + 1))) : 1;
					require_once libfile('function/discuzcode');
					$debate['affirmpoint'] = discuzcode($debate['affirmpoint'], 0, 0, 0, 1, 1, 0, 0, 0, 0, 0);
					$debate['negapoint'] = discuzcode($debate['negapoint'], 0, 0, 0, 1, 1, 0, 0, 0, 0, 0);

				} else {
					$message = $this->messagecutstr($var, $messagelength, '');
				}

				include template('common/miku_block_thread');
				$returnarr[$tid] = $return;
			}
		}

		return $returnarr;
	}

	function messagesafeclear($message) { //来自：function_post.php
		if(strpos($message, '[/password]') !== FALSE) {
			$message = '';
		}

		if(strpos($message, '[/postbg]') !== FALSE) {
			$message = preg_replace("/\s?\[postbg\]\s*([^\[\<\r\n;'\"\?\(\)]+?)\s*\[\/postbg\]\s?/is", '', $message);
		}

		if(strpos($message, '[/begin]') !== FALSE) {
			$message = preg_replace("/\[begin(=\s*([^\[\<\r\n]*?)\s*,(\d*),(\d*),(\d*),(\d*))?\]\s*([^\[\<\r\n]+?)\s*\[\/begin\]/is", '', $message);
		}

		if(strpos($message, '[page]') !== FALSE) {
			$message = preg_replace("/\s?\[page\]\s?/is", '', $message);
		}

		if(strpos($message, '[/index]') !== FALSE) {
			$message = preg_replace("/\s?\[index\](.+?)\[\/index\]\s?/is", '', $message);
		}

		if(strpos($message, '[/begin]') !== FALSE) {
			$message = preg_replace("/\[begin(=\s*([^\[\<\r\n]*?)\s*,(\d*),(\d*),(\d*),(\d*))?\]\s*([^\[\<\r\n]+?)\s*\[\/begin\]/is", '', $message);
		}

		if(strpos($message, '[/groupid]') !== FALSE) {
			$message = preg_replace("/\[groupid=\d+\].*\[\/groupid\]/i", '', $message);
		}

		$language = lang('forum/misc');

		$message = preg_replace(array($language['post_edithtml_regexp'],$language['post_editnobbcode_regexp'],$language['post_edit_regexp']), '', $message);
		return $message;
	}

	function messagecutstr($str, $length = 0, $dot = ' ...') { //来自：function_post.php
		global $_G;
		$str = $this->messagesafeclear($str);
		$sppos = strpos($str, chr(0).chr(0).chr(0));
		if($sppos !== false) {
			$str = substr($str, 0, $sppos);
		}
		$language = lang('forum/misc');

		loadcache(array('bbcodes_display', 'bbcodes', 'smileycodes', 'smilies', 'smileytypes', 'domainwhitelist'));

		$bbcodes = 'b|i|u|p|color|size|font|align|list|indent|float';
		$bbcodesclear = 'email|code|free|table|tr|td|img|swf|flash|attach|media|audio|groupid|payto'.($_G['cache']['bbcodes_display'][$_G['groupid']] ? '|'.implode('|', array_keys($_G['cache']['bbcodes_display'][$_G['groupid']])) : '');

		$str = strip_tags(preg_replace(array(
				"/\[hide=?\d*\](.*?)\[\/hide\]/is",
				"/\[quote](.*?)\[\/quote]/si",
				$language['post_edit_regexp'],
				"/\[url=?.*?\](.+?)\[\/url\]/si",
				"/\[($bbcodesclear)=?.*?\].+?\[\/\\1\]/si",
				"/\[($bbcodes)=?.*?\]/i",
				"/\[\/($bbcodes)\]/i",
				"/\\\\u/i"
			), array(
				"[b]$language[post_hidden][/b]",
				'',
				'',
				'\\1',
				'',
				'',
				'',
			    '%u'
			), $str));

		if($length) {
			$str = cutstr($str, $length, $dot);
		}

		$str = preg_replace($_G['cache']['smilies']['searcharray'], '', $str);

		if($_G['setting']['plugins']['func'][HOOKTYPE]['discuzcode']) {
			$_G['discuzcodemessage'] = & $str;
			$param = func_get_args();
			hookscript('discuzcode', 'global', 'funcs', array('param' => $param, 'caller' => 'messagecutstr'), 'discuzcode');
		}
		return trim($str);
	}

	function getpic($tid) {
		global $_G;
		if(!$tid) {
			return '';
		}
		$pic = DB::fetch_all("SELECT aid, attachment, remote FROM ".DB::table(getattachtablebytid($tid))." WHERE tid='$tid' AND isimage IN (1, -1) ORDER BY dateline ASC LIMIT 0,3");
		return $pic;
	}

	function getpics($tids) {
		$data = array();
		$tids = !empty($tids) && is_array($tids) ? $tids : array($tids);
		$tids = array_map('intval', $tids);
		$tids = array_filter($tids);
		if(!empty($tids)) {
			$query = DB::query('SELECT * FROM '.DB::table('forum_threadimage').' WHERE tid IN ('.dimplode($tids).')');
			while($value = DB::fetch($query)) {
				$data[$value['tid']] = $value;
			}
		}
		return $data;
	}

	function getlv($threadlist, $type = 'threadlist' ){
		$uidarr = $userarr = $usergroup_arr = array();

		foreach($threadlist as $thread) {
			$uidarr[$thread['authorid']] = $thread['authorid'];
		}

		$result = DB::fetch_all('SELECT groupid,radminid,grouptitle,stars FROM '.DB::table('common_usergroup'));
		foreach ($result as $group) {
			$usergroup_arr[$group['groupid']] = $group;
		}
		//没有获取到common_member_archive表的用户数据
		// $result= DB::fetch_all('SELECT uid,groupid FROM '.DB::table('common_member').' WHERE uid IN ('.dimplode($uidarr).')');
		// foreach ($result as $user) {
		// 	$userarr[$user['uid']] = $usergroup_arr[$user['groupid']];
		// }
		//解决方法，用官方的操作数据表的模型里面能获取到archive表的用户。
		$result = C::t('common_member')->fetch_all($uidarr);
		foreach ($result as $user) {
			$userarr[$user['uid']] = $usergroup_arr[$user['groupid']];
		}
		return $userarr;
	}

	function getsign($uid){
		global $_G;
		$memberfieldforum = C::t('common_member_field_forum')->fetch($uid);
		return  strip_tags($memberfieldforum['sightml']);
	}

}

$miku_get_thread = new miku_get_thread();