function mikuty_viewthread_getnextpage(mkty_nxtpgurl){
	$('#mikuty-getnextpage').on('tap', function(){
		if(mkty_nxt_isloading == true){
			return;
		}
		mkty_nxt_isloading = true;
		if (mkty_page > mkty_maxpage){
			$('#mikuty-getnextpage').html('已经到底了:)').css({'background':'transparent','color':'#bbb'});
			return;
		}
		$('#mikuty-getnextpage').html('请稍等...');
		var url =mkty_nxtpgurl + mkty_page + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
		url = url + '&ajaxdata=html';
		$.ajax({
			'url':url,
	      	'dataType':'html',
	      	'type':'post',
	      	'success':function(msg){
	      		s = msg.replace(/[\r\n]*/g, '');
	      		x = s.match(/<mikuty-vt-ajaxtag>.*?<\/mikuty-vt-ajaxtag>/ig);
	      		// console.log(x[0]);
	      		// var tmp = $('.postlist').html();
	      		var domid='mktyajax-load'+mkty_page;
	      		// $('.postlist').html(tmp + '<div id="'+domid+'">'+x[0]+'</div>');
	      		$('.postlist').append('<div id="'+domid+'">'+x[0]+'</div>');
				mikuty_lazyload(domid);
	      		mkty_page++;
	      		if (mkty_page > mkty_maxpage){
					$('#mikuty-getnextpage').html('已经到底了:)').css({'background':'transparent','color':'#bbb'});
				}else{
					$('#mikuty-getnextpage').html('查看更多...');
				}
				mkty_nxt_isloading = false;
				setimglistsize();
	      	},
	      	'error':function(msg){
	      		popup.open('请求服务器失败，请检查网络！', 'alert');
				mkty_nxt_isloading = false;
	      	}
		});			
	});
}


function mikuty_guide_getnextpage(mkty_nxtpgurl){
	$('#mikuty-getnextpage').on('tap', function(){
		if(mkty_nxt_isloading == true){
			return;
		}
		mkty_nxt_isloading = true;
		if (mkty_page > mkty_maxpage){
			$('#mikuty-getnextpage').html('已经到底了:)').css({'background':'transparent','color':'#bbb'});
			return;
		}

		if($('.hometl-block-hide').length > 0){
			$('#mikuty-getnextpage').html('请稍等...');
			setTimeout(function(){
				$('.hometl-block-hide').removeClass('hometl-block-hide').addClass('hometl-block-show');
				mkty_nxt_isloading = false;
				mkty_page++;
	      		if (mkty_page > mkty_maxpage){
					$('#mikuty-getnextpage').html('已经到底了:)').css({'background':'transparent','color':'#bbb'});
				}else{
					$('#mikuty-getnextpage').html('查看更多...');
				}
				setTimeout(function(){
					var scrollTop = window.pageYOffset || document.documentElement.scrollTop|| document.body.scrollTop || 0;
					window.scrollTo(0,scrollTop+1);
				},10);
			},500);
		}else{
			$('#mikuty-getnextpage').html('请稍等...');
			var url =mkty_nxtpgurl + mkty_curpage + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
			url = url + '&ajaxdata=html&inajax=1';
			$.ajax({
				'url':url,
		      	'dataType':'html',
		      	'type':'post',
		      	'success':function(msg){
		      		s = msg.replace(/[\r\n]*/g, '');
		      		x = s.match(/<ul class="home-threadlist-c">.*?<\/ul>/ig);
		      		var domid='mktyajax-load'+mkty_curpage;
		      		$('.home-threadlist').append('<div id="'+domid+'">'+x[0]+'</div>');
					mikuty_lazyload(domid);
		      		mkty_page++;
		      		mkty_curpage++;
		      		if (mkty_page > mkty_maxpage){
						$('#mikuty-getnextpage').html('已经到底了:)').css({'background':'transparent','color':'#bbb'});
					}else{
						$('#mikuty-getnextpage').html('查看更多...');
					}
					mkty_nxt_isloading = false;
					setimglistsize();
		      	},
		      	'error':function(msg){
		      		popup.open('请求服务器失败，请检查网络！', 'alert');
					mkty_nxt_isloading = false;
		      	}
			});			
		}

	});
}



function mikuty_threadlist_getnextpage(mkty_nxtpgurl){
	$('#mikuty-getnextpage').on('tap', function(){
		if(mkty_nxt_isloading == true){
			return;
		}
		mkty_nxt_isloading = true;
		if (mkty_page > mkty_maxpage){
			$('#mikuty-getnextpage').html('已经到底了:)').css({'background':'transparent','color':'#bbb'});
			return;
		}
		$('#mikuty-getnextpage').html('请稍等...');
		var url =mkty_nxtpgurl + mkty_page + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
		url = url + '&ajaxdata=html';
		$.ajax({
			'url':url,
	      	'dataType':'html',
	      	'type':'post',
	      	'success':function(msg){
	      		s = msg.replace(/[\r\n]*/g, '');
	      		x = s.match(/<ul class="threadlist-c-normal">.*?<\/ul>/ig);
	      		// console.log(x[0]);
	      		// var tmp = $('.threadlist-c-normal').html();
	      		var domid='mktyajax-load'+mkty_page;
	      		// $('.threadlist-c-normal').html(tmp + '<div id="'+domid+'">'+x[0]+'</div>');
	      		$('.threadlist-c').append('<div id="'+domid+'">'+x[0]+'</div>');
				mikuty_lazyload(domid);
	      		mkty_page++;
	      		if (mkty_page > mkty_maxpage){
					$('#mikuty-getnextpage').html('已经到底了:)').css({'background':'transparent','color':'#bbb'});
				}else{
					$('#mikuty-getnextpage').html('查看更多...');
				}
				mkty_nxt_isloading = false;
				setimglistsize();
	      	},
	      	'error':function(msg){
	      		popup.open('请求服务器失败，请检查网络！', 'alert');
				mkty_nxt_isloading = false;
	      	}
		});			
	});
}

function mikuty_lazyload(id){
	setTimeout(function(){
		$("#"+id+" img.mktylazy").lazyload({
			effect: "show",
		  	threshold: 300, // 提前开始加载
		});
		$("#"+id+" img.mktylazy-post").lazyload({
			effect: "show",
		  	threshold: 300, // 提前开始加载
		});

	},100);

}