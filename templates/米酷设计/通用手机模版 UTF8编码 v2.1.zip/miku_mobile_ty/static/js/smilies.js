/*
	[DisM!] (C)2001-2099 DisM Inc.
	应用更新支持：https://dism.taobao.com

	$Id: smilies.js 29684 2012-04-25 04:00:58Z zhangguosheng $
*/

function smilies_show(id, smcols, seditorkey) {
	if(seditorkey && !document.getElementById(seditorkey + 'sml_menu')) {
		var div = document.createElement("div");
		div.id = seditorkey + 'sml_menu';
		div.style.display = 'none';
		div.className = 'sllt';
		document.getElementById('append_parent').appendChild(div);
		var div = document.createElement("div");
		div.id = id;
		div.style.overflow = 'hidden';
		document.getElementById(seditorkey + 'sml_menu').appendChild(div);
	}
	if(typeof smilies_type == 'undefined') {
		var scriptNode = document.createElement("script");
		scriptNode.type = "text/javascript";
		scriptNode.charset = charset ? charset :  document.charset;
		scriptNode.src = 'data/cache/common_smilies_var.js?' + VERHASH;
		document.getElementById('append_parent').appendChild(scriptNode);
		scriptNode.onload = function() {
			smilies_onload(id, smcols, seditorkey);
		};
} else {
		smilies_onload(id, smcols, seditorkey);
	}
}

function smilies_onload(id, smcols, seditorkey) {
	seditorkey = !seditorkey ? '' : seditorkey;
	smile = getcookie('smile').split('D');
	if(typeof smilies_type == 'object') {
		// if(smile[0] && smilies_array[smile[0]]) {
		// 	CURRENTSTYPE = smile[0];
		// } else {
			for(i in smilies_array) {
				CURRENTSTYPE = i;break;
			}
		// }
		smiliestype = '<div id="'+id+'_tb" class="tb tb_s cl" style="display:none;"><ul>';
		for(i in smilies_type) {
			key = i.substring(1);
			if(smilies_type[i][0]) {
				smiliestype += '<li ' + (CURRENTSTYPE == key ? 'class="current"' : '') + ' id="'+seditorkey+'stype_'+key+'" onclick="smilies_switch(\'' + id + '\', \'' + smcols + '\', '+key+', 1, \'' + seditorkey + '\');if(CURRENTSTYPE) {document.getElementById(\''+seditorkey+'stype_\'+CURRENTSTYPE).className=\'\';}this.className=\'current\';CURRENTSTYPE='+key+';"><a href="javascript:;" hidefocus="true">'+smilies_type[i][0]+'</a></li>';
			}
		}
		smiliestype += '</ul></div>';
		document.getElementById(id).innerHTML = smiliestype + '<div id="' + id + '_data"></div><div class="sllt_p" id="' + id + '_page"></div>';
		// smilies_switch(id, smcols, CURRENTSTYPE, smile[1], seditorkey);
		smilies_switch(id, smcols, 1, smile[1], seditorkey);
	}
}

function smilies_switch(id, smcols, type, page, seditorkey) {
	page = page ? page : 1;
	if(!smilies_array[type] || !smilies_array[type][page]) return;
	setcookie('smile', type + 'D' + page, 31536000);
	smiliesdata = '<table id="' + id + '_table" cellpadding="0" cellspacing="0"><tr>';
	j = k = 0;
	img = [];
	for(var i = 0; i < smilies_array[type][page].length; i++) {
		if(j >= smcols) {
			smiliesdata += '<tr>';
			j = 0;
		}
		s = smilies_array[type][page][i];
		smilieimg = STATICURL + 'image/smiley/' + smilies_type['_' + type][1] + '/' + s[2];
		img[k] = new Image();
		img[k].src = smilieimg;
		smiliesdata += s && s[0] ? '<td onclick="seditor_insertunit(\'' + seditorkey + '\', \'' + s[1].replace(/'/, '\\\'') + ' \')' +
			'" id="' + seditorkey + 'smilie_' + s[0] + '_td"><img id="smilie_' + s[0] + '" width="' + s[3] +'" height="' + s[4] +'" src="' + smilieimg + '" alt="' + s[1] + '" />' : '<td>';
		j++;k++;
	}
	smiliesdata += '</table>';
	smiliespage = '';
	if(smilies_array[type].length > 2) {
		prevpage = ((prevpage = parseInt(page) - 1) < 1) ? smilies_array[type].length - 1 : prevpage;
		nextpage = ((nextpage = parseInt(page) + 1) == smilies_array[type].length) ? 1 : nextpage;
		smiliespage = '<div class="z"><a href="javascript:;" onclick="smilies_switch(\'' + id + '\', \'' + smcols + '\', ' + type + ', ' + prevpage + ', \'' + seditorkey + '\');doane(event);">上页</a>' +
			'<a href="javascript:;" onclick="smilies_switch(\'' + id + '\', \'' + smcols + '\', ' + type + ', ' + nextpage + ', \'' + seditorkey + '\');doane(event);">下页</a></div>' +
			page + '/' + (smilies_array[type].length - 1);
	}
	document.getElementById(id + '_data').innerHTML = smiliesdata;
	document.getElementById(id + '_page').innerHTML = smiliespage;
	document.getElementById(id + '_tb').style.width = smcols*(16+parseInt(s[3])) + 'px';
}


function seditor_insertunit(key, text, textend, moveend, selappend) {
	if(document.getElementById(key + 'needmessage')) {
		document.getElementById(key + 'needmessage').focus();
	}
	var textareaDom = document.getElementById(key + 'needmessage')
	textend = isUndefined(textend) ? '' : textend;
	moveend = isUndefined(textend) ? 0 : moveend;
	selappend = isUndefined(selappend) ? 1 : selappend;
	startlen = text.length;
	endlen = textend.length;
	if(!isUndefined(textareaDom.selectionStart)) {
		if(selappend) {
			var opn = textareaDom.selectionStart + 0;
			if(textend != '') {
				text = text + textareaDom.value.substring(textareaDom.selectionStart, textareaDom.selectionEnd) + textend;
			}
			textareaDom.value = textareaDom.value.substr(0, textareaDom.selectionStart) + text + textareaDom.value.substr(textareaDom.selectionEnd);
			if(!moveend) {
				textareaDom.selectionStart = opn + startlen - endlen;
				textareaDom.selectionEnd = opn + startlen - endlen;
			}
		} else {
			text = text + textend;
			textareaDom.value = textareaDom.value.substr(0, textareaDom.selectionStart) + text + textareaDom.value.substr(textareaDom.selectionEnd);
		}
	} else {
		textareaDom.value += text;
	}
	document.activeElement.blur();
}