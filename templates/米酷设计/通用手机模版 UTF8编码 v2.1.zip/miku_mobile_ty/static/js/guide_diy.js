var miku_shouye_dohang = new Swiper('.shouye-dohang',{
    slidesPerView: 'auto',
    freeMode: true,
    centeredSlides: false,
    spaceBetween: 0,
    roundLengths : true,
});

var miku_shouye_huandeng = new Swiper('.shouye-huandeng', {
	direction: 'horizontal',
    loop: true,
    speed: 300,
    autoplay: 4000,
    pagination : '.swiper-pagination',
    paginationType:'fraction'
});

//图文导航
var miku_shouye_tuwendohang = new Swiper('.nav-tuijian',{
    slidesPerView: 'auto',
    freeMode: true,
    centeredSlides: false,
    spaceBetween: 0,
    roundLengths : true, //防止文字模糊
});

//头条
var miku_zuixinredian = new Swiper('.zxrd-box', {
	direction: 'vertical',
    loop: true,
    speed: 500,
    autoplay: 3000,
});



