<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function rtj1009_imgurl($imgurl)
{
	if (strstr($imgurl, '[/img]')) {
		if (strstr($imgurl, '[img=')) {
			$parrent = "/\\[img=(\\d{1,4})[x|\\,](\\d{1,4})\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/img\\]/is";
			preg_match_all($parrent, $imgurl, $match);
			$imgurlx = $match[3][0];
		} elseif (strstr($imgurl, '[img]')) {
			$parrent = "/\\[img\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/img\\]/is";
			preg_match_all($parrent, $imgurl, $match);
			$imgurlx = $match[1][0];
		}
	}
	if ($imgurlx) {
		$attachid .= '<span class="imgurlx"><img src="' . $imgurlx . '" /></span>';
		return $attachid;
	}
}
