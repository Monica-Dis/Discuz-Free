<?PHP exit('Access Denied');?>
<!--{if $diymode}-->
	<!--{if $_G[setting][homepagestyle]}-->
		<!--{subtemplate home/space_header}-->
		<div id="ren_ct" class="rtj1009_lai_ct cl">
            <div class="ren_lai_mn z">
                <div class="bm ren_ly_bm">
					<div class="ren_bm_c ren_ly_c">
	<!--{else}-->
		<!--{template common/header}-->
		
		<style id="diy_style" type="text/css"></style>
		<div class="wp">
			<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
		</div>
		<!--{template home/space_menu}-->
		<div id="ct" class="rtj1009_ct cl">
		<div class="ren_g_mn">
				<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
				<div class="ren_ly_bm">
					<div class="ren_ly_c">
	<!--{/if}-->
	<!--{if helper_access::check_module('share') && $space[self]}-->
	<!--{template home/space_share_form}-->
	<!--{/if}-->
<!--{else}-->
	<!--{template common/header}-->
    
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ct" class="rtj1009_ct2 cl">
			<div class="rtj1009_zcd">
				<ul class="ren_tbn">
                    <li$actives[we]><a href="home.php?mod=space&do=share&view=we">{lang friend_share}</a></li>
                    <li$actives[me]><a href="home.php?mod=space&do=share&view=me">{lang my_share}</a></li>
                    <li$actives[all]><a href="home.php?mod=space&do=share&view=all">{lang view_all}</a></li>
                </ul>
			</div>
            
       <div class="rtj1009_sz_mn">
		<div class="ren_sz_bm">
            <div class="ren_sz_z">
			<div class="mn pbm">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<!--{if helper_access::check_module('share') && $space[self]}-->
			<!--{template home/space_share_form}-->
			<!--{/if}-->
<!--{/if}-->
		<p class="tbmu">
			{lang order_by_type}：
			<a href="$navtheurl&type=all"$sub_actives[type_all]>{lang share_all}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=link"$sub_actives[type_link]>{lang share_link}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=video"$sub_actives[type_video]>{lang share_video}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=music"$sub_actives[type_music]>{lang share_music}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=flash"$sub_actives[type_flash]>{lang share_flash}</a><span class="pipe">|</span>
			<!--{if helper_access::check_module('blog')}-->
			<a href="$navtheurl&type=blog"$sub_actives[type_blog]>{lang share_blog}</a><span class="pipe">|</span>
			<!--{/if}-->
			<!--{if helper_access::check_module('album')}-->
			<a href="$navtheurl&type=album"$sub_actives[type_album]>{lang share_album}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=pic"$sub_actives[type_pic]>{lang share_pic}</a><span class="pipe">|</span>
			<!--{/if}-->
			<a href="$navtheurl&type=poll"$sub_actives[type_poll]>{lang share_poll}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=space"$sub_actives[type_space]>{lang share_space}</a><span class="pipe">|</span>
			<a href="$navtheurl&type=thread"$sub_actives[type_thread]>{lang share_thread}</a>
			<!--{if helper_access::check_module('portal')}-->
			<span class="pipe">|</span>
			<a href="$navtheurl&type=article"$sub_actives[type_article]>{lang share_article}</a>
			<!--{/if}-->
		</p>
		<!--{if $list}-->
			<ul id="share_ul" class="el sl">
				<!--{loop $list $k $value}-->
					<!--{template home/space_share_li}-->
				<!--{/loop}-->
			</ul>
			<!--{if $pricount}-->
				<p class="mtm">{lang hide_share}</p>
			<!--{/if}-->
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
		<!--{else}-->
			<ul id="share_ul" class="el sl"></ul>
			<p class="emp">{lang not_share_yet}</p>
		<!--{/if}-->
		
		<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->

		<!--{if $diymode}-->
					</div>
				</div>
			<!--{if $_G[setting][homepagestyle]}-->
			</div>
			<div class="rtj1009_home_sd y">
				<!--{subtemplate home/space_userabout}-->
			<!--{/if}-->
		<!--{/if}-->
		</div>
	</div>
</div>
</div>
</div>
<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->


<script type="text/javascript">
	function succeedhandle_shareadd(url, msg, values) {
		share_add(values['sid']);
	}
</script>
<!--{template common/footer}-->
