<?PHP exit('Access Denied');?>
<!--{template common/header}-->



<div id="ct" class="rtj1009_ct2 cl">
	<div class="rtj1009_sz_mn">
		<div class="ren_sz_bm">
		<!--{if empty($do)}-->
			<!--{subtemplate home/space_task_list}-->
		<!--{elseif $do == 'view'}-->
			<!--{subtemplate home/space_task_detail}-->
		<!--{/if}-->
		</div>
	</div>
	<div class="rtj1009_zcd">
		<div class="ren_tbn">
			<ul>
				<li$actives[new]><a href="home.php?mod=task&item=new">{lang task_new}</a><span>></span></li>
				<li$actives[doing]><a href="home.php?mod=task&item=doing">{lang task_doing}</a><span>></span></li>
				<li$actives[done]><a href="home.php?mod=task&item=done">{lang task_done}</a><span>></span></li>
				<li$actives[failed]><a href="home.php?mod=task&item=failed">{lang task_failed}</a><span>></span></li>
			</ul>
		</div>
	</div>
</div>
<!--{template common/footer}-->
