<?PHP exit('Access Denied');?>
<!--{template common/header}-->

<!--{if $_GET['op'] == 'show'}-->
	<!--{template home/space_click}-->
<!--{/if}-->

<!--{template common/footer}-->
