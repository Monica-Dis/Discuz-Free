<?PHP exit('Access Denied');?>
<div class="rtj1009_zcd">
    <ul class="ren_tbn">
		<li$actives[me]><a href="home.php?mod=space&do=friend">{lang friend_list}</a><span>></span></li>
		<li$actives[search]><a href="home.php?mod=spacecp&ac=search">{lang search_friend}</a><span>></span></li>
		<li$actives[find]><a href="home.php?mod=spacecp&ac=friend&op=find">可能认识</a><span>></span></li>
		<!--{if $_G['setting']['regstatus'] > 1}-->
			<li$actives[invite]><a href="home.php?mod=spacecp&ac=invite">{lang invite_friend}</a><span>></span></li>
		<!--{/if}-->
		<li$actives[request]><a href="home.php?mod=spacecp&ac=friend&op=request">{lang friend_request}</a><span>></span></li>	
		<li$actives[group]><a href="home.php?mod=spacecp&ac=friend&op=group">{lang set_friend_group}</a><span>></span></li>
	</ul>
</div>
