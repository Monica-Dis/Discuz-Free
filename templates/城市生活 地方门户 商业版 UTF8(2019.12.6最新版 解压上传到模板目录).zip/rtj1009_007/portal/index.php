<?PHP exit('Access Denied');?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<div class="ren_zong">
	<!--{if $config['ren_ad_yi']}--><!--[diy=rtj1009_iho0]--><div id="rtj1009_iho0" class="area"></div><!--[/diy]--><!--{/if}-->
	<!--{if $config['ren_ad_e']}--><!--[diy=rtj1009_iho1]--><div id="rtj1009_iho1" class="area"></div><!--[/diy]--><!--{/if}-->
    <!--{if $config['ren_ad_san']}--><!--[diy=rtj1009_iho2]--><div id="rtj1009_iho2" class="area"></div><!--[/diy]--><!--{/if}-->
    <!--{if $config['ren_ad_si']}--><!--[diy=rtj1009_iho3]--><div id="rtj1009_iho3" class="area"></div><!--[/diy]--><!--{/if}-->
	<div class="rtj1009_yiban cl">
    	<div class="rtj1009_yi cl">
        	<div class="z ren_yiz cl">
                <div class="ren_yizs cl">
                    <ul class="cl">
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx1"></span>
                            <p>房产</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx2"></span>
                            <p>租房</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx3"></span>
                            <p>装修</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx4"></span>
                            <p>招聘</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx5"></span>
                            <p>求职</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx6"></span>
                            <p>二手</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx7"></span>
                            <p>婚嫁</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx8"></span>
                            <p>亲子</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx9"></span>
                            <p>交友</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx10"></span>
                            <p>旅游</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx11"></span>
                            <p>汽车</p>
                        </a></li>
                        <li><a href="#" target="_blank"><span class="ren_yizs_xx12"></span>
                            <p>美食</p>
                        </a></li>
                    </ul>
                </div>

                <div class="ren_yizz cl">
                    <ul class="cl">
                        <li class="ren_yizz_xx ren_yizz_xx1"><a href="#" target="_blank"><span></span>
                            <p>我要爆料</p>
                        </a></li>
                        <li class="ren_yizz_xx ren_yizz_xx2"><a href="#" target="_blank"><span></span>
                            <p>活动看台</p>
                        </a></li>
                    </ul>
                </div>

            </div>
            
        	<div class="z rtj1009_lunbo cl">
                <div class="bbs_lunbo cl">
                     <!--[diy=rtj1009_diy2]--><div id="rtj1009_diy2" class="area"></div><!--[/diy]-->
                </div>
            </div>
            
            <div class="ren_yiy y cl">
            	<div class="ren_yiy_s cl">
                    <div class="ren_yiys_user cl">
                        <!--{if !$_G[uid] && !$_G['connectguest']}-->
                        <div class="ren_userinfo cl">
                            <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="ren_us_avatar"><img src="<!--{avatar($_G[uid], middle, true)}-->" /></a>
                            <h3 class="ren_us_name">Hi 游客 您好</h3>
                            <span class="ren_us_hy">欢迎您来到{$_G['setting']['bbname']}！</span>
                        </div>
                        <!--{else}-->
                        <div class="ren_userinfo cl">
                            <a class="ren_us_avatar" href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->"><img src="<!--{avatar($_G[uid], middle, true)}-->" /></a>
                            <h3 class="ren_us_name">Hi $_G[username] 您好</h3>
                            <span class="ren_us_hy">欢迎您来到{$_G['setting']['bbname']}！</span>
                        </div>
                        <!--{/if}-->
                    </div>
                	<ul class="cl">
                        <li class="ren_yiy_sliz">
                        	<!--{if $_G['uid']}-->
                            <a href="home.php?mod=space&do=pm" target="_blank" class="ren_yiy_sxx">我的消息</a><!--{else}-->
                            <a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" class="ren_yiy_sdl">登录</a><!--{/if}-->
                        </li>
                        <li class="ren_yiy_sliz">
                        	<!--{if $_G['uid']}-->
                            <a href="home.php?mod=space&uid=$_G[uid]&do=profile" target="_blank" class="ren_yiy_swd">我的主页</a><!--{else}-->
                            <a href="member.php?mod={$_G[setting][regname]}" class="ren_yiy_szc">注册</a><!--{/if}-->
                        </li>
                        <li class="ren_yiy_sliy">
                        	<!--{if $_G['uid']}-->
                            <a href="forum.php?mod=misc&amp;action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="ren_yiy_sfb">发布帖子</a><!--{else}-->
                            <a href="forum.php?mod=misc&amp;action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="ren_yiy_sft">发帖</a><!--{/if}-->
                        </li>
                    </ul>
                </div>
                
                <div class="ren_yiy_x cl">
                    <div class="ren_yiy_lunbo cl">
                         <!--[diy=rtj1009_diy102]--><div id="rtj1009_diy102" class="area"></div><!--[/diy]-->
                    </div>
                </div>
            </div>
        </div>
    </div>
     
    
    <div class="rtj1009_eban cl">
    	<div class="rtj1009_e cl">
        	<div class="z ren_e_z cl">
                <div class="ren_e_zs">
                	<div class="ren_ezs_tie">
                        <div class="ren_ez_tw z">
                            <!--[diy=rtj1009_diy203]--><div id="rtj1009_diy203" class="area"></div><!--[/diy]-->
                        </div>
                        <ul class="ren_ezs_tiexx">
                            <!--[diy=rtj1009_diy213]--><div id="rtj1009_diy213" class="area"></div><!--[/diy]-->
                        </ul>
                    </div>
                    <div class="ren_ez_tie y">
						<!--[diy=rtj1009_diy204]--><div id="rtj1009_diy204" class="area"></div><!--[/diy]-->
                        <ul class="ren_ez_xx cl">
                        <!--[diy=rtj1009_diy205]--><div id="rtj1009_diy205" class="area"></div><!--[/diy]-->
                        </ul>
                    </div>
                </div>
                <div class="ren_e_zx">
                	<div class="ren_ezx_tw">
                    	<ul>
                        	<!--[diy=rtj1009_diy206]--><div id="rtj1009_diy206" class="area"></div><!--[/diy]-->
                        </ul>
                    </div>
                </div>
            </div>
		<script type="text/javascript">
		jq(document).ready(function(){
				jq("#scrollDiv").Scroll({line:1,speed:600,timer:5000,up:"but_up",down:"but_down"});
		});
		</script>
            <div class="y ren_e_y cl">
            	<!--[diy=rtj1009_diy207]--><div id="rtj1009_diy207" class="area"></div><!--[/diy]-->
            </div>
        </div>
    </div>
    
    <div class="ren_ihe cl">
		<!--{if $config['ren_ad_wu']}-->
    	<div class="ren_ihexx">
        	<div class="ren_ihho1 cl"><!--[diy=rtj1009_ihho1]--><div id="rtj1009_ihho1" class="area"></div><!--[/diy]--></div>
            <div class="ren_ihho2 cl"><!--[diy=rtj1009_ihho2]--><div id="rtj1009_ihho2" class="area"></div><!--[/diy]--></div>
        </div>
		<!--{/if}-->
		<!--{if $config['ren_ad_liu']}-->
    	<div class="ren_ihexx">
        	<div class="ren_ihho3 cl"><!--[diy=rtj1009_ihho3]--><div id="rtj1009_ihho3" class="area"></div><!--[/diy]--></div>
            <div class="ren_ihho4 cl"><!--[diy=rtj1009_ihho4]--><div id="rtj1009_ihho4" class="area"></div><!--[/diy]--></div>
        </div>
		<!--{/if}-->
    </div>
	
    <!--{if $config['ren_portal_ms']}-->
    <div class="rtj1009_sanban cl">
    	<div class="rtj1009_e cl">
        	<div class="rtj1009_yixy_bt cl">
                <h3 class="rtj1009_bt z"><a href="#" target="_blank">美食吃货</a></h3>
                <a class="ren_e_jrpd y" href="#" target="_blank">进入频道>></a>
                <div class="ren_e_pdfl y">
                    <a class="ren_e_btxx" href="#" target="_blank">吃货探店</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">商家折扣</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">寻找美食</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">家常菜谱</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">饮食养生</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">线下活动</a>
                </div>
            </div>
        	<div class="z ren_e_z cl">
                <div class="ren_e_zs z">
					<div class="ren_e_zsxx cl">
                        <div class="z rtj1009_lunbo cl">
                            <div class="ren_lunbo cl">
                                 <!--[diy=rtj1009_diy310]--><div id="rtj1009_diy310" class="area"></div><!--[/diy]-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ren_santab_xx y cl">
                    <div class="ren_santab_nr">
                        <div class="ren_ez_tie y">
                            <!--[diy=rtj1009_diy311]--><div id="rtj1009_diy311" class="area"></div><!--[/diy]-->
                            <ul class="ren_ez_xx cl">
                            <!--[diy=rtj1009_diy312]--><div id="rtj1009_diy312" class="area"></div><!--[/diy]-->
                            </ul>
                        </div>
                        
                        <div class="ren_ezx_tw">
                            <!--[diy=rtj1009_diy330]--><div id="rtj1009_diy330" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
            </div>
            <div class="y ren_e_y cl">
                <div class="ren_yx_xx y cl">
                	<div class="ren_bt">吃货推荐</div>
                    <ul class="ren_ys_ul cl">
                    	<!--[diy=rtj1009_diy357]--><div id="rtj1009_diy357" class="area"></div><!--[/diy]-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--{/if}-->
    
	<!--{if $config['ren_portal_fc']}-->
    <div class="rtj1009_siban cl">
    	<div class="rtj1009_e cl">
        	<div class="rtj1009_yixy_bt cl">
                <h3 class="rtj1009_bt z"><a href="#" target="_blank">房产楼市</a></h3>
                <a class="ren_e_jrpd y" href="#" target="_blank">进入频道>></a>
                <div class="ren_e_pdfl y">
                    <a class="ren_e_btxx" href="#" target="_blank">新房楼盘</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">房产资讯</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">业主论坛</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">二手房</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">租房</a>
                </div>
            </div>
        	<div class="z ren_e_z cl">
                <div class="ren_e_zs z">
					<div class="ren_e_zsxx cl">
                        <div class="z rtj1009_lunbo cl">
                            <div class="ren_lunbo cl">
                                 <!--[diy=rtj1009_diy410]--><div id="rtj1009_diy410" class="area"></div><!--[/diy]-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ren_santab_xx y cl">
                    <div class="ren_santab_nr">
                        <div class="ren_ez_tie y">
                            <!--[diy=rtj1009_diy411]--><div id="rtj1009_diy411" class="area"></div><!--[/diy]-->
                            <ul class="ren_ez_xx cl">
                            <!--[diy=rtj1009_diy412]--><div id="rtj1009_diy412" class="area"></div><!--[/diy]-->
                            </ul>
                        </div>
                        
                        <div class="ren_ezx_tw">
                            <!--[diy=rtj1009_diy430]--><div id="rtj1009_diy430" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
            </div>
            <div class="y ren_e_y cl">
                <div class="ren_yx_xx y cl">
                	<div class="ren_bt">推荐楼盘</div>
                    <ul class="ren_ys_ul cl">
                    	<!--[diy=rtj1009_diy457]--><div id="rtj1009_diy457" class="area"></div><!--[/diy]-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--{/if}-->
    
	<!--{if $config['ren_portal_zx']}-->
    <div class="rtj1009_liuban cl">
    	<div class="rtj1009_e cl">
        	<div class="rtj1009_yixy_bt cl">
                <h3 class="rtj1009_bt z"><a href="#" target="_blank">装修装饰</a></h3>
                <a class="ren_e_jrpd y" href="#" target="_blank">进入频道>></a>
                <div class="ren_e_pdfl y">
                    <a class="ren_e_btxx" href="#" target="_blank">装修讨论</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">家装日记</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">案例图库</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">设计公司</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">建材品牌</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">优惠活动</a>
                </div>
            </div>
        	<div class="z ren_e_z cl">
                <div class="ren_e_zs z">
					<div class="ren_e_zsxx cl">
                        <div class="z rtj1009_lunbo cl">
                            <div class="ren_lunbo cl">
                                 <!--[diy=rtj1009_diy610]--><div id="rtj1009_diy610" class="area"></div><!--[/diy]-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ren_santab_xx y cl">
                    <div class="ren_santab_nr">
                        <div class="ren_ez_tie y">
                            <!--[diy=rtj1009_diy611]--><div id="rtj1009_diy611" class="area"></div><!--[/diy]-->
                            <ul class="ren_ez_xx cl">
                            <!--[diy=rtj1009_diy612]--><div id="rtj1009_diy612" class="area"></div><!--[/diy]-->
                            </ul>
                        </div>
                        
                        <div class="ren_ezx_tw">
                            <!--[diy=rtj1009_diy630]--><div id="rtj1009_diy630" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
            </div>
            <div class="y ren_e_y cl">
                <div class="ren_yx_xx y cl">
                	<div class="ren_bt">认证商家</div>
                    <ul class="ren_ys_ul cl">
                    	<!--[diy=rtj1009_diy657]--><div id="rtj1009_diy657" class="area"></div><!--[/diy]-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--{/if}-->
	
	<!--{if $config['ren_portal_qc']}-->
    <div class="rtj1009_qiban cl">
    	<div class="rtj1009_e cl">
        	<div class="rtj1009_yixy_bt cl">
                <h3 class="rtj1009_bt z"><a href="#" target="_blank">汽车天地</a></h3>
                <a class="ren_e_jrpd y" href="#" target="_blank">进入频道>></a>
                <div class="ren_e_pdfl y">
                    <a class="ren_e_btxx" href="#" target="_blank">新车</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">二手车</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">购车优惠</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">实拍评测</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">网上4S店</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">养车心得</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">友车会</a>
                </div>
            </div>
        	<div class="z ren_e_z cl">
                <div class="ren_e_zs z">
					<div class="ren_e_zsxx cl">
                        <div class="z rtj1009_lunbo cl">
                            <div class="ren_lunbo cl">
                                 <!--[diy=rtj1009_diy710]--><div id="rtj1009_diy710" class="area"></div><!--[/diy]-->
                            </div>
                        </div>
                    </div>
                </div>
                <div class="ren_santab_xx y cl">
                    <div class="ren_santab_nr">
                        <div class="ren_ez_tie y">
                            <!--[diy=rtj1009_diy711]--><div id="rtj1009_diy711" class="area"></div><!--[/diy]-->
                            <ul class="ren_ez_xx cl">
                            <!--[diy=rtj1009_diy712]--><div id="rtj1009_diy712" class="area"></div><!--[/diy]-->
                            </ul>
                        </div>
                        
                        <div class="ren_ezx_tw">
                            <!--[diy=rtj1009_diy730]--><div id="rtj1009_diy730" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
            </div>
            <div class="y ren_e_y cl">
                <div class="ren_yx_xx y cl">
                	<div class="ren_bt">网上4S店</div>
                    <ul class="ren_ys_ul cl">
                    	<!--[diy=rtj1009_diy757]--><div id="rtj1009_diy757" class="area"></div><!--[/diy]-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
	<!--{/if}-->
	
    <!--{if $config['ren_ad_qi']}-->
    <div class="ren_ime cl">
		<!--[diy=rtj1009_ren_imme1]--><div id="rtj1009_ren_imme1" class="area"></div><!--[/diy]-->
    </div>
	<!--{/if}-->
    
	<!--{if $config['ren_portal_bm']}-->
    <div class="rtj1009_jiuban cl">
    	<div class="rtj1009_e cl">
        	<div class="rtj1009_yixy_bt cl">
                <h3 class="rtj1009_bt z"><a href="#" target="_blank">便民信息</a></h3>
                <div class="ren_jiutab_hover y">
                    <ul class="ren_jiutab_bt">
                        <li>
                            <a href="javascript:;" class="xxk" onmouseover="switchTab('ren_jiutab',1,6,'xxk');" id="ren_jiutab_1">租房</a><em></em>
                            <a href="javascript:;" onmouseover="switchTab('ren_jiutab',2,6,'xxk');" id="ren_jiutab_2">求职</a><em></em>
                            <a href="javascript:;" onmouseover="switchTab('ren_jiutab',3,6,'xxk');" id="ren_jiutab_3">招聘</a><em></em>
                            <a href="javascript:;" onmouseover="switchTab('ren_jiutab',4,6,'xxk');" id="ren_jiutab_4">二手车</a><em></em>
                            <a href="javascript:;" onmouseover="switchTab('ren_jiutab',5,6,'xxk');" id="ren_jiutab_5">二手房</a><em></em>
                            <a href="javascript:;" onmouseover="switchTab('ren_jiutab',6,6,'xxk');" id="ren_jiutab_6">跳蚤市场</a>
                        </li>
                    </ul>
                </div>
            </div>
        	<div class="z ren_e_z cl">
                <div class="ren_jiutab_xx cl">
                    <div class="ren_wutw cl z">
                        <div class="ren_wutw_xx1 z">
                            <!--[diy=rtj1009_diy901]--><div id="rtj1009_diy901" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="ren_wutw_xx ren_wutw_xx2 z">
                            <!--[diy=rtj1009_diy902]--><div id="rtj1009_diy902" class="area"></div><!--[/diy]-->
                        </div>
                        <div class="ren_wutw_xx ren_wutw_xx3 z">
                            <!--[diy=rtj1009_diy903]--><div id="rtj1009_diy903" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                    <div class="ren_jiutab_nr z cl">
                        <div class="ren_jiutab_xx_hover_body cl">
                            <div id="ren_jiutab_c_1" class="cl">
                                <div class="ren_ez_tie cl">
                                    <ul class="ren_ez_xx ren_ez_xx1 cl">
                                    	<!--[diy=rtj1009_diy904]--><div id="rtj1009_diy904" class="area"></div><!--[/diy]-->
                                    </ul>
                                    <ul class="ren_ez_xx cl">
                                    	<!--[diy=rtj1009_diy905]--><div id="rtj1009_diy905" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_2" class="cl" style="display: none;">
                                <div class="ren_ez_tie cl">
                                    <ul class="ren_ez_xx ren_ez_xx1 cl">
                                    	<!--[diy=rtj1009_diy906]--><div id="rtj1009_diy906" class="area"></div><!--[/diy]-->
                                    </ul>
                                    <ul class="ren_ez_xx cl">
                                    	<!--[diy=rtj1009_diy907]--><div id="rtj1009_diy907" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_3" class="cl" style="display: none;">
                                <div class="ren_ez_tie cl">
                                    <ul class="ren_ez_xx ren_ez_xx1 cl">
                                    	<!--[diy=rtj1009_diy908]--><div id="rtj1009_diy908" class="area"></div><!--[/diy]-->
                                    </ul>
                                    <ul class="ren_ez_xx cl">
                                    	<!--[diy=rtj1009_diy909]--><div id="rtj1009_diy909" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_4" class="cl" style="display: none;">
                                <div class="ren_ez_tie cl">
                                    <ul class="ren_ez_xx ren_ez_xx1 cl">
                                    	<!--[diy=rtj1009_diy910]--><div id="rtj1009_diy910" class="area"></div><!--[/diy]-->
                                    </ul>
                                    <ul class="ren_ez_xx cl">
                                    	<!--[diy=rtj1009_diy911]--><div id="rtj1009_diy911" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_5" class="cl" style="display: none;">
                                <div class="ren_ez_tie cl">
                                    <ul class="ren_ez_xx ren_ez_xx1 cl">
                                    	<!--[diy=rtj1009_diy912]--><div id="rtj1009_diy912" class="area"></div><!--[/diy]-->
                                    </ul>
                                    <ul class="ren_ez_xx cl">
                                    	<!--[diy=rtj1009_diy913]--><div id="rtj1009_diy913" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                            <div id="ren_jiutab_c_6" class="cl" style="display: none;">
                                <div class="ren_ez_tie cl">
                                    <ul class="ren_ez_xx ren_ez_xx1 cl">
                                    	<!--[diy=rtj1009_diy914]--><div id="rtj1009_diy914" class="area"></div><!--[/diy]-->
                                    </ul>
                                    <ul class="ren_ez_xx cl">
                                    	<!--[diy=rtj1009_diy915]--><div id="rtj1009_diy915" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
	<!--{/if}-->
    
	<!--{if $config['ren_portal_sh']}-->
    <div class="rtj1009_wuban cl">
    	<div class="rtj1009_e cl">
        	<div class="rtj1009_yixy_bt cl">
                <h3 class="rtj1009_bt z"><a href="#" target="_blank">精彩生活</a></h3>
                <div class="ren_e_pdfl y">
                    <a class="ren_e_btxx" href="#" target="_blank">兴趣爱好</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">情感交流</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">单身交友</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">旅行游记</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">时尚购物</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">谈天说地</a>
                </div>
            </div>
        	<div class="z ren_e_z cl">
                <div class="ren_e_zs z">
                	<div class="ren_e_zsxx cl">
                        <div class="ren_bt">达人秀场</div>
                        <div class="z rtj1009_lunbo cl">
                            <div class="ren_lunbo cl">
                                 <!--[diy=rtj1009_diy510]--><div id="rtj1009_diy510" class="area"></div><!--[/diy]-->
                            </div>
                        </div>
                    </div>
                    <div class="ren_e_zxxx cl">
                        <div class="ren_bt">交友推荐</div>
                        <div class="ren_z_dr z">
                            <!--[diy=rtj1009_diy566]--><div id="rtj1009_diy566" class="area"></div><!--[/diy]-->
                        </div>
                    </div>
                </div>
                <div class="ren_sitab_xx y cl">
                    <div class="ren_sitab_nr">
                        <div class="ren_ez_tie y">
                            <div class="ren_ezx_tw">
                            	<div class="ren_bt">精选</div>
                                <ul>
                       			     <!--[diy=rtj1009_diy511]--><div id="rtj1009_diy511" class="area"></div><!--[/diy]-->
                                </ul>
                            </div>
                            <ul class="ren_ez_xx cl">
                            	<!--[diy=rtj1009_diy512]--><div id="rtj1009_diy512" class="area"></div><!--[/diy]-->
                            </ul>
                        </div>
                        <div class="ren_ez_tie ren_ptop20 y">
                            <div class="ren_ezx_tw">
                            	<div class="ren_bt">热帖</div>
                                <ul>
                       			     <!--[diy=rtj1009_diy513]--><div id="rtj1009_diy513" class="area"></div><!--[/diy]-->
                                </ul>
                            </div>
                            <ul class="ren_ez_xx cl">
                            	<!--[diy=rtj1009_diy514]--><div id="rtj1009_diy514" class="area"></div><!--[/diy]-->
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="y ren_e_y cl">
                <div class="ren_bt">秀生活</div>
                <div class="ren_wuytab_xx y cl">
                    <div class="ren_wuytab_hover cl">
                        <ul class="ren_wuytab_bt cl">
                            <li><a href="javascript:;" class="xxk" onmouseover="switchTab('ren_wuytab',1,4,'xxk');" id="ren_wuytab_1">旅行日记<span>></span></a></li>
                            <li><a href="javascript:;" onmouseover="switchTab('ren_wuytab',2,4,'xxk');" id="ren_wuytab_2">美食厨房<span>></span></a></li>
                            <li><a href="javascript:;" onmouseover="switchTab('ren_wuytab',3,4,'xxk');" id="ren_wuytab_3">时尚搭配<span>></span></a></li>
                            <li><a href="javascript:;" onmouseover="switchTab('ren_wuytab',4,4,'xxk');" id="ren_wuytab_4">情感美文<span>></span></a></li>
                        </ul>
                    </div>
                    <div class="ren_wuytab_nr">
                        <div class="ren_wuytab_xx_hover_body cl">
                        
                            <div id="ren_wuytab_c_1" class="cl">
                                <div class="ren_wuz_tie">
                                    <ul class="ren_ez_xx cl">
                                    <!--[diy=rtj1009_diy557]--><div id="rtj1009_diy557" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            <div id="ren_wuytab_c_2" class="cl" style="display: none;">
                                <div class="ren_wuz_tie">
                                    <ul class="ren_ez_xx cl">
                                    <!--[diy=rtj1009_diy558]--><div id="rtj1009_diy558" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            <div id="ren_wuytab_c_3" class="cl" style="display: none;">
                                <div class="ren_wuz_tie">
                                    <ul class="ren_ez_xx cl">
                                    <!--[diy=rtj1009_diy559]--><div id="rtj1009_diy559" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            <div id="ren_wuytab_c_4" class="cl" style="display: none;">
                                <div class="ren_wuz_tie">
                                    <ul class="ren_ez_xx cl">
                                    <!--[diy=rtj1009_diy560]--><div id="rtj1009_diy560" class="area"></div><!--[/diy]-->
                                    </ul>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
                
                <div class="ren_yx_sd cl">
                    <!--[diy=rtj1009_diy586]--><div id="rtj1009_diy586" class="area"></div><!--[/diy]-->
                </div>
                <div class="ren_yx_xx y cl">
                	<div class="ren_bt">轻松一刻</div>
                    <ul class="ren_ys_ul cl">
                    	<!--[diy=rtj1009_diy585]--><div id="rtj1009_diy585" class="area"></div><!--[/diy]-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--{/if}-->
    
	<!--{if $config['ren_portal_tu']}-->
    <div class="rtj1009_baban cl">
    	<div class="rtj1009_ba cl">
        	<div class="rtj1009_yixy_bt cl">
                <h3 class="rtj1009_bt z"><a href="#" target="_blank">社区热图</a></h3>
                <div class="ren_e_pdfl y">
                    <a class="ren_e_btxx" href="#" target="_blank">精彩美图</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">摄影大片</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">旅行游记</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">时尚丽人</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">宝宝秀</a><span>/</span>
                    <a class="ren_e_btxx" href="#" target="_blank">晒婚照</a>
                </div>
            </div>
        	<div class="rtj1009_ba_tw cl">
                <div class="ren_stw cl">
                    <div class="ren_stwxx z zbxxk1">
                        <!--[diy=rtj1009_diy849]--><div id="rtj1009_diy849" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk2">
                        <!--[diy=rtj1009_diy850]--><div id="rtj1009_diy850" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk3">
                        <!--[diy=rtj1009_diy851]--><div id="rtj1009_diy851" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk4">
                        <!--[diy=rtj1009_diy852]--><div id="rtj1009_diy852" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk5">
                        <!--[diy=rtj1009_diy853]--><div id="rtj1009_diy853" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk6">
                        <!--[diy=rtj1009_diy854]--><div id="rtj1009_diy854" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk7">
                        <!--[diy=rtj1009_diy855]--><div id="rtj1009_diy855" class="area"></div><!--[/diy]-->
                    </div>
                    <div class="ren_stwxx z zbxxk8">
                        <!--[diy=rtj1009_diy856]--><div id="rtj1009_diy856" class="area"></div><!--[/diy]-->
                    </div>
                </div>
          	</div>
        </div>
    </div>
     <!--{/if}-->

    <!--{if $config['ren_portal_yl']}-->
    <div class="rtj1009_shiban cl">
    	<p>
        	<span>友情链接</span>
        </p>
        <ul>
        	<!--[diy=rtj1009_diy1]--><div id="rtj1009_diy1" class="area"></div><!--[/diy]-->
        </ul>
    </div>
	<!--{/if}-->
</div>


<script type="text/javascript">
function fixed_top_nv(eleid, disbind) {
	this.nv = eleid && $(eleid) || $('nv');
	this.openflag = this.nv && BROWSER.ie != 6;
	this.nvdata = {};
	this.init = function (disattachevent) {
		if(this.openflag) {
			if(!disattachevent) {
				var obj = this;
				_attachEvent(window, 'resize', function(){obj.reset();obj.init(1);obj.run();});
				var switchwidth = $('switchwidth');
				if(switchwidth) {
					_attachEvent(switchwidth, 'click', function(){obj.reset();obj.openflag=false;});
				}
			}

			var next = this.nv;
			try {
				while((next = next.nextSibling).nodeType != 1 || next.style.display === 'none') {}
				this.nvdata.next = next;
				this.nvdata.height = parseInt(this.nv.offsetHeight, 10);
				this.nvdata.width = parseInt(this.nv.offsetWidth, 10);
				this.nvdata.left = this.nv.getBoundingClientRect().left - document.documentElement.clientLeft;
				this.nvdata.position = this.nv.style.position;
				this.nvdata.opacity = this.nv.style.opacity;
			} catch (e) {
				this.nvdata.next = null;
			}
		}
	};

	this.run = function () {
		var fixedheight = 0;
		if(this.openflag && this.nvdata.next){
			var nvnexttop = document.body.scrollTop || document.documentElement.scrollTop;
			var dofixed = nvnexttop !== 0 && document.documentElement.clientHeight >= 15 && this.nvdata.next.getBoundingClientRect().top - this.nvdata.height < 0;
			if(dofixed) {
				if(this.nv.style.position != 'fixed') {
					this.nv.style.borderLeftWidth = '0';
					this.nv.style.borderRightWidth = '0';
					this.nv.style.height = this.nvdata.height + 'px';
					this.nv.style.width = this.nvdata.width + 'px';
					this.nv.style.top = '0';
					this.nv.style.left = this.nvdata.left + 'px';
					this.nv.style.position = 'fixed';
					this.nv.style.zIndex = '199';
					this.nv.style.opacity = 0.85;
				}
			} else {
				if(this.nv.style.position != this.nvdata.position) {
					this.reset();
				}
			}
			if(this.nv.style.position == 'fixed') {
				fixedheight = this.nvdata.height;
			}
		}
		return fixedheight;
	};
	this.reset = function () {
		if(this.nv) {
			this.nv.style.position = this.nvdata.position;
			this.nv.style.borderLeftWidth = '';
			this.nv.style.borderRightWidth = '';
			this.nv.style.height = '';
			this.nv.style.width = '';
			this.nv.style.opacity = this.nvdata.opacity;
		}
	};
	if(!disbind && this.openflag) {
		this.init();
		_attachEvent(window, 'scroll', this.run);
	}
}
</script>
<!--{if empty($_G['setting']['disfixednv_forumindex']) }--><script>fixed_top_nv();</script><!--{/if}-->

<!--{template common/footer}-->
