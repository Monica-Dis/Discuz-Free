<?PHP exit('Access Denied');?>
<!--{if $_G['forum']['ismoderator']}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}forum_moderate.js?{VERHASH}"></script>
<!--{/if}-->
<div id="pgt" class="bm bw0 pgs cl">
	$multipage
	<!--{if helper_access::check_module('group')}-->
	<span {if $_G[setting][visitedforums]}id="visitedforums" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id})"{/if} class="pgb y"><a href="forum.php?mod=group&fid=$_G[fid]">{lang return_index}</a></span>
	
	<a href="javascript:;" id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})" onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')" title="{lang send_posts}">发帖</a>
	<!--{/if}-->
	<!--{hook/forumdisplay_postbutton_top}-->
</div>
<!--{if $_G['forum']['threadtypes']}-->
	<ul class="ttp bm cl">
		<li id="ttp_all"{if !$_GET['typeid']} class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang forum_viewall}</a></li>
		<!--{if $_G['forum']['threadtypes']}-->
			<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
				<li{if $_GET['typeid'] == $id} class="xw1 a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}">$name</a>
			<!--{/loop}-->
		<!--{/if}-->
		<!--{hook/forumdisplay_filter_extra}-->
	</ul>
<!--{/if}-->
<div id="threadlist" class="tl bm" style="position: relative;">
	
	<div class="bm_c rtj1009_tielist cl">
		<form method="post" autocomplete="off" name="moderate" id="moderate" action="forum.php?mod=topicadmin&action=moderate&fid=$_G[fid]&infloat=yes&nopost=yes">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="listextra" value="$extra" />
			<table cellpadding="0" cellspacing="0" border="0">
				<!--{if $_G['forum_threadcount']}-->
					
					<!--{loop $_G['forum_threadlist'] $key $thread}-->
						<!--{ad/threadlist}-->
						<tbody id="$thread[id]">
							<tr>
								<td class="icn">
									<div class="ren_tielist_zztx">
                                        <a href="home.php?mod=space&uid=$thread[authorid]" class="ren_zz_tx" target="_blank"><!--{avatar($thread[authorid],small)}--></a>
                                    </div>
								</td>
								<!--{if $_G['forum']['ismoderator']}-->
								<td class="o">
									<!--{if $thread['fid'] == $_G[fid]}-->
										<!--{if $thread['displayorder'] <= 3 || $_G['adminid'] == 1}-->
											<input onclick="tmodclick(this)" type="checkbox" name="moderate[]" class="pc" value="$thread[tid]" />
										<!--{else}-->
											<input type="checkbox" disabled="disabled" />
										<!--{/if}-->
									<!--{else}-->
										<input type="checkbox" disabled="disabled" />
									<!--{/if}-->
								</td>
								<!--{/if}-->
                                <!--{hook/forumdisplay_thread $key}-->
								<th class="common ren_tzlb_twlb">
                                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"$thread[highlight] class="xst">$thread[subject]</a>
                                    <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                                    <span class="ren_zhiding">置顶</span>

                                    <!--{/if}-->
                                    <!--{if $thread['attachment'] == 2}-->
                                    <img src="template/rtj1009_007/image/image_s.png" alt="attach_img" title="{lang attach_img}" align="absmiddle" />
                                    <!--{elseif $thread['attachment'] == 1}-->
                                    <img src="{STATICURL}image/filetype/common.gif" alt="attachment" title="{lang attachment}" align="absmiddle" />
                                    <!--{/if}-->
                                    <!--{if $thread['mobile']}-->
                                    <img src="{IMGDIR}/mobile-attach-$thread['mobile'].png" alt="{lang post_mobile}" align="absmiddle" />
                                    <!--{/if}-->
                                    <!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
                                    <img src="{IMGDIR}/digest_$thread[digest].gif" align="absmiddle" alt="digest" title="{lang thread_digest} $thread[digest]" />
                                    <!--{/if}-->
                                    <!--{if $thread['displayorder'] == 0}-->
                                    <!--{if $thread[recommendicon] && $filter != 'recommend'}-->
                                    <img src="{IMGDIR}/recommend_$thread[recommendicon].gif" align="absmiddle" alt="recommend" title="{lang thread_recommend} $thread[recommends]" />
                                    <!--{/if}-->
                                    <!--{if $thread[heatlevel]}-->
                                    <img src="{IMGDIR}/hot_$thread[heatlevel].gif" align="absmiddle" alt="heatlevel" title="{lang heats}: {$thread[heats]}" />
                                    <!--{/if}-->
                                    <!--{if $thread['rate'] > 0}-->
                                    <img src="{IMGDIR}/agree.gif" align="absmiddle" alt="agree" title="{lang rate_credit_add}" />
                                    <!--{elseif $thread['rate'] < 0}-->
                                    <img src="{IMGDIR}/disagree.gif" align="absmiddle" alt="disagree" title="{lang posts_deducted}" />
                                    <!--{/if}-->
                                    <!--{/if}-->
                                    <!--{if $thread['replycredit'] > 0}-->
                                    - <span class="xi1">[{lang replycredit} <strong> $thread['replycredit']</strong> ]</span>
                                    <!--{/if}-->
                                    <!--{if $thread[multipage]}-->
                                    <span class="tps">$thread[multipage]</span>
                                    <!--{/if}-->
                                <!--{eval  $threadlistimg =  DB::fetch_all('SELECT * FROM '.DB::table('forum_attachment').' WHERE tid = '. $thread['tid'].' LIMIT  0 ,'. 5);}--> 
                                <!--{if $threadlistimg}-->
                                <div class="ren_threadimg">
                                      <a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra"$thread[highlight]{if $thread['isgroup'] == 1 || $thread['forumstick']} target="_blank"{else} onclick="atarget(this)"{/if} target="_blank">
                                          <!--{loop $threadlistimg $values}-->
                                          <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 180, 120); }-->
                                              <span><img src="$renlistimgkey" class="ren_thread_img" alt="$thread[subject]"/></span>
                                          <!--{/loop}-->
                                      </a>
                                </div>
                                <!--{/if}-->
                                <div class="ren_tie_x cl">
                                    <div class="z ren_tie_xz">
                                        <div class="z ren_tie_zhhf">
                                            <div class="z ren_tie_huifu">
                                                <span>最后发表：</span>
                                                <!--{if $thread['lastposter']}--><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}" c="1">$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}-->
                                                <span>$thread[lastpost]</span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="y ren_tie_xy cl">
                                        <div class="ren_tie_hfck cl">
                                            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" title="$thread[replies] {lang reply}"><em class="ren_zz_hf y">$thread[replies]</em></a>
                                            <div class="ren_zz_ck y">
                                                <!--{if $thread[views]}-->$thread[views]<!--{else}-->0<!--{/if}-->
                                            </div>
                                        </div>
                                    </div>
                                </div>
								</th>
							</tr>
						</tbody>
					<!--{/loop}-->
				<!--{else}-->
					<tbody><tr><th colspan="6"><p class="emp">{lang forum_nothreads}</p></th></tr></tbody>
				<!--{/if}-->
			</table>
			<!--{if $_G['forum']['ismoderator'] && $_G['forum_threadcount']}-->
				<!--{template forum/topicadmin_modlayer}-->
			<!--{/if}-->
		</form>
	</div>
</div>
<!--{if helper_access::check_module('group')}-->
<div class="bm bw0 pgs cl">
	$multipage
	<span {if $_G[setting][visitedforums]}id="visitedforums" onmouseover="$('visitedforums').id = 'visitedforumstmp';this.id = 'visitedforums';showMenu({'ctrlid':this.id})"{/if} class="pgb y"><a href="forum.php?mod=group&fid=$_G[fid]">{lang return_index}</a></span>
	<a href="javascript:;" id="newspecialtmp" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})" onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')" title="{lang send_posts}">发帖</a>
	<!--{hook/forumdisplay_postbutton_bottom}-->
</div>

<!--{if $_G['setting']['fastpost']}-->
	<!--{template forum/forumdisplay_fastpost}-->
<!--{/if}-->

<!--{if $_G['group']['allowpost'] && ($_G['group']['allowposttrade'] || $_G['group']['allowpostpoll'] || $_G['group']['allowpostreward'] || $_G['group']['allowpostactivity'] || $_G['group']['allowpostdebate'] || $_G['setting']['threadplugins'] || $_G['forum']['threadsorts'])}-->
	<ul class="p_pop" id="newspecial_menu" style="display: none">
		<!--{if !$_G['forum']['allowspecialonly']}--><li><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" onclick="showWindow('newthread', this.href);doane(event)">{lang post_newthread}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostpoll']}--><li class="poll"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostreward']}--><li class="reward"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostdebate']}--><li class="debate"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowpostactivity']}--><li class="activity"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
		<!--{if $_G['group']['allowposttrade']}--><li class="trade"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
		<!--{if $_G['setting']['threadplugins']}-->
			<!--{loop $_G['forum']['threadplugin'] $tpid}-->
				<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
					<li class="popupmenu_option"{if $_G['setting']['threadplugins'][$tpid][icon]} style="background-image:url($_G[setting][threadplugins][$tpid][icon])"{/if}><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>
				<!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>
<!--{/if}-->
<!--{/if}-->
