<?php echo '';exit;?>
<!--{template common/header}-->

<!--{if $_G['setting']['forumallowside']}-->
	<!--{eval require DISCUZ_ROOT.'./template/the_c_style/php/c_sdmk.php';}-->
<!--{/if}-->

<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.SuperSlide.2.1.2.js?{VERHASH}"></script>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/fs_forse.js?{VERHASH}"></script>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.nanoscroller.min.js?{VERHASH}"></script>
<script type="text/javascript" src="$_G['style'][styleimgdir]/js/jquery.lazyload.min.js?{VERHASH}"></script>
<script type="text/javascript">
	jq(function() { jq("img.clazy").show().lazyload({ effectspeed : 100, effect : "fadeIn", failurelimit : 100 }); });
</script>

<!--{if empty($gid)}-->
	<!--{ad/text/wp a_t}-->
<!--{/if}-->

<style id="diy_style" type="text/css"></style>


<!--{if empty($gid)}-->
	<div id="chart">
		<div class="wp cl{if $_G['setting']['forumallowside']} ct2{/if}">
			<div class="chart_tj z cl">
				<p class="tj_today"><span class="bd cshake"><b></b></span>
					<em><i class="fa fa-fw fa-calendar-o"></i> {$clang[index_today]}: $todayposts</em>
				</p>
				<p class="tj_yesterday"><span class="bd cshake"><b></b></span>
					<em><i class="fa fa-fw fa-calendar"></i> {$clang[index_yesterday]}: $postdata[0]</em>
				</p>
				<p class="tj_posts" title="{$clang[index_threads]}: {$threads}&#10;{$clang[index_replies]}: {echo $posts-$threads}"><span class="bd cshake"><b></b></span>
					<em><i class="fa fa-fw fa-bar-chart"></i> {$clang[index_posts]}: $posts</em>
				</p>
				<p class="tj_members"{if $_G['setting']['whosonlinestatus']} title="{$onlinenum} {$clang[onlines]}&#10;{$membercount} {$clang[index_members]} ({$invisiblecount} {$clang[index_invisibles]})&#10;{$guestcount} {$clang[index_guests]}&#10;{$clang[index_mostonlines]} {$onlineinfo[0]} {$clang[on]} {$onlineinfo[1]}{/if}"><span class="bd cshake"><b></b></span>
					<em><i class="fa fa-fw fa-users"></i> {$clang[index_members]}: $_G['cache']['userstats']['totalmembers']</em>
				</p>
				<p class="new_member"{if $_G['cache']['userstats']['newsetuser']} title="{$clang[welcome_new_members]}"{/if}>
					<span class="bd cshake"><b></b></span>
					<!--{if $_G['cache']['userstats']['newsetuser']}-->
						<em><a href="home.php?mod=space&username={$_G['cache']['userstats']['newsetuser']}" target="_blank" class="xi2">
							<i class="fa fa-fw fa-leaf"></i> $_G['cache']['userstats']['newsetuser']</a>
						</em>
					<!--{else}-->
						<em><i class="fa fa-fw fa-anchor"></i> {$clang[new_member_none]}</em>
					<!--{/if}-->
				</p>
			</div>
			<div class="chart_sd y">
				{eval}
					$weekarray_cnli=explode(',',$clang['week_cnli']);
					$weekarray_jp=explode(',',$clang['week_jp']);
					$weekarray_en=explode(',',$clang['week_en']);
				{/eval}
				<div id="clock_c">{echo date('H:i:s');}</div>
				<div class="cweek"><strong><span>{echo $weekarray_jp[date("w")];}</span></strong><i>({echo $weekarray_cnli[date("w")];})</i><em>{echo $weekarray_en[date("w")];}</em></div>
				<div id="date_c">{echo date('Y-m-d');}</div>
				<script type="text/javascript">
					function Appendzero(obj) {
						if(obj<10) return "0" +""+ obj;
						else return obj;
					}
					function changeClock() {
						var d = new Date();
						document.getElementById("date_c").innerHTML = Appendzero(d.getFullYear()) + "-" + Appendzero((d.getMonth() + 1)) + "-" + Appendzero(d.getDate());
						document.getElementById("clock_c").innerHTML = Appendzero(d.getHours()) + ":" + Appendzero(d.getMinutes()) + ":" + Appendzero(d.getSeconds());
					}
					window.setInterval(changeClock, 1000);
				</script>
			</div>
		</div>
	</div>
<!--{/if}-->
<!--{if empty($gid)}-->
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->



<div id="cpt" class="bm cbm_box cl">
	<!--{if empty($gid) && $announcements}-->
	<div class="z">
		<div id="an">
			<dl class="cl">
				<dt class="z xw1 shan">{lang announcements}:&nbsp;</dt>
				<dd>
					<div id="anc"><ul id="ancl">$announcements</ul></div>
				</dd>
			</dl>
		</div>
		<script type="text/javascript">announcement();</script>
	</div>
	<!--{/if}-->
	<div class="ylink y">
		<!--{hook/index_nav_extra}-->
		<!--{if $_G['uid']}--><a href="forum.php?mod=guide&view=my" title="{lang my_posts}" class="xi2">{lang my_posts}</a><!--{/if}--><!--{if !empty($_G['setting']['search']['forum']['status'])}--><!--{if $_G['uid']}--><!--{/if}--><a href="forum.php?mod=guide&view=new" title="{lang show_newthreads}" class="xi2">{lang show_newthreads}</a><!--{/if}-->
	</div>
	<div class="ylink"><!--{hook/index_status_extra}--></div>
</div>


<!--{if !empty($_G['setting']['grid']['showgrid'])}-->
	<!-- index four grid -->
		<div class="bm cbm_box cl">
			<div id="category_grid">
				<!--{if !$_G['setting']['grid']['gridtype']}-->
					<div id="cimgshow" class="cimgshow ex z">
						<div class="bd cl">
							<ul>
								<!--{eval $cslidenum=1;}-->
								<!--{loop $grids['slide'] $stid $svalue}-->
									<li>
										<a href="{$svalue[url]}" style="background-image:url({$svalue[image]});filter:progid:DXImageTransform.Microsoft.AlphaImageLoader(src='{$svalue[image]}',sizingMethod='scale');">
											<p class="tit txt_s">$svalue[subject]</p>
										</a>
									</li>
									<!--{eval $cslidenum++;}-->
								<!--{/loop}-->
							</ul>
						</div>
						<div class="hd">
							<ul>
								<!--{eval}-->
									for ($csdx=1; $csdx<=$cslidenum; $csdx++) { echo "<li>$csdx</li>"; }
								<!--{/eval}-->
							</ul>
						</div>
						<a class="prev" href="javascript:void(0)"></a>
						<a class="next" href="javascript:void(0)"></a>
					</div>
					<script type="text/javascript">
						jq("#cimgshow").slide({titCell:".hd ul",mainCell:".bd ul",autoPage:true,effect:"fold",autoPlay:true,trigger:"click",interTime:30000,delayTime:700});
					</script>
				<!--{/if}-->
				<!--{eval}-->
					if($_G['setting']['grid']['gridtype']){$lks=$cset['lks'];}
					else{$lks=7;}
				<!--{/eval}-->
				<div class="c_newlistbd{if $_G['setting']['grid']['gridtype']} ex{/if} cl">
					<ul class="c_newlist ex z">
						<div class="bm_h cl">
							<h2>{lang collection_lastthread}</h2>
						</div>
						<!--{eval $lk=1;}-->
						<!--{loop $grids['newthread'] $thread}-->
							<!--{if $lk>$lks}--><!--{eval break;}--><!--{/if}-->
							<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
							<!--{/if}-->
							<li class="lk_{$lk}">
								<div class="titbd">
									<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if !$_G['setting']['grid']['showtips']} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}><i>{$lk}</i>$thread[subject]</a>
									<!--{if $_G['setting']['grid']['showtips']}-->
										<div class="sub">
											<span class="cur"></span>
												{lang title}: $thread[oldsubject]<br/>
												{lang author}: $thread[author]<br/>
												{lang show}: $thread[views]<br/>
												{lang reply}: $thread[replies]<br/>
												{$clang[post_at]}: $thread[dateline]
										</div>
									<!--{/if}-->
								</div>
							</li>
							<!--{eval $lk++;}-->
						<!--{/loop}-->
					</ul>
					<ul class="c_newlist ex z">
						<div class="bm_h cl">
							<h2>{lang show_newthreads}</h2>
						</div>
						<!--{eval $lk=1;}-->
						<!--{loop $grids['newreply'] $thread}-->
							<!--{if $lk>$lks}--><!--{eval break;}--><!--{/if}-->
							<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
							<!--{/if}-->
							<li class="lk_{$lk}">
								<div class="titbd">
									<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if !$_G['setting']['grid']['showtips']} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}><i>{$lk}</i>$thread[subject]</a>
									<!--{if $_G['setting']['grid']['showtips']}-->
										<div class="sub">
											<span class="cur"></span>
												{lang title}: $thread[oldsubject]<br/>
												{lang author}: $thread[author]<br/>
												{lang show}: $thread[views]<br/>
												{lang reply}: $thread[replies]<br/>
												{$clang[post_at]}: $thread[dateline]
									<!--{/if}-->
								</div>
							</li>
							<!--{eval $lk++;}-->
						<!--{/loop}-->
					</ul>
					<ul class="c_newlist ex z">
						<div class="bm_h cl">
							<h2>{lang hot_thread}</h2>
						</div>
						<!--{eval $lk=1;}-->
						<!--{loop $grids['hot'] $thread}-->
							<!--{if $lk>$lks}--><!--{eval break;}--><!--{/if}-->
							<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
							<!--{/if}-->
							<li class="lk_{$lk}">
								<div class="titbd">
									<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if !$_G['setting']['grid']['showtips']} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}><i>{$lk}</i>$thread[subject]</a>
									<!--{if $_G['setting']['grid']['showtips']}-->
										<div class="sub">
											<span class="cur"></span>
												{lang title}: $thread[oldsubject]<br/>
												{lang author}: $thread[author]<br/>
												{lang show}: $thread[views]<br/>
												{lang reply}: $thread[replies]<br/>
												{$clang[post_at]}: $thread[dateline]
										</div>
									<!--{/if}-->
								</div>
							</li>
							<!--{eval $lk++;}-->
						<!--{/loop}-->
					</ul>
					<!--{if $_G['setting']['grid']['gridtype']}-->
						<ul class="c_newlist ex z">
							<div class="bm_h cl">
								<h2>{lang post_digest_thread}</h2>
							</div>
							<!--{eval $lk=1;}-->
							<!--{loop $grids['digest'] $thread}-->
								<!--{if $lk>$lks}--><!--{eval break;}--><!--{/if}-->
								<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
									<!--{eval $thread[tid]=$thread[closed];}-->
								<!--{/if}-->
								<li class="lk_{$lk}">
									<div class="titbd">
										<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"{if $thread['highlight']} $thread['highlight']{/if}{if !$_G['setting']['grid']['showtips']} title="$thread[oldsubject]"{/if}{if $_G['setting']['grid']['targetblank']} target="_blank"{/if}><i>{$lk}</i>$thread[subject]</a>
										<!--{if $_G['setting']['grid']['showtips']}-->
											<div class="sub">
												<span class="cur"></span>
													{lang title}: $thread[oldsubject]<br/>
													{lang author}: $thread[author]<br/>
													{lang show}: $thread[views]<br/>
													{lang reply}: $thread[replies]<br/>
													{$clang[post_at]}: $thread[dateline]
											</div>
										<!--{/if}-->
									</div>
								</li>
								<!--{eval $lk++;}-->
							<!--{/loop}-->
						</ul>
					<!--{/if}-->
				</div>
			</div>
		</div>
	<!-- index four grid end -->
<!--{/if}-->


<div id="ct" class="wp cl{if $_G['setting']['forumallowside']} ct2{/if} ctct">

	<!--[diy=diy_chart]--><div id="diy_chart" class="area"></div><!--[/diy]-->
	<div class="mn"{if $_GET['c'] == 'news'} style="position:relative;margin-bottom:0;"{/if}>
		<div class="bmbtnbd">
			<!--{if $_GET['c'] == 'news'}-->
				<!--{eval}-->
					if ($_G['cookie']['c_picstyle'] > 0){
						$cset[pic_style]=1;
					}else{
						$cset[pic_style]=0;
					}
					$ctop=0;
				<!--{/eval}-->
				<a href="forum.php" class="bmbtn ctm20"><i class="fa fa-bars"></i></a>
				<!--{if $cset[pic_style] == 1}-->
					<a href="javascript:;" class="picstyle pic_1 ctm20" c_title="{$clang[pic_style_-1]}"></a>
				<!--{else}-->
					<a href="javascript:;" class="picstyle pic_-1 ctm20" c_title="{$clang[pic_style_1]}"></a>
				<!--{/if}-->
			<!--{else}-->
				<a href="forum.php?c=news" class="bmbtn ex1 ctm20"><i class="fa fa-send"></i></a>
				<!--{eval $ctop=1;}-->
			<!--{/if}-->
		</div>
		<div class="mnmn">
			<!--//if empty($_G['setting']['grid']['showgrid']) && $cset['show_forum_ng']//-->
			<!--{if $cset['show_forum_ng']}-->
				<div class="bm cbm_box{if $_G['basescript'] == 'forum' && $_GET['c'] == 'news' && !$cset['show_news_ng']} c_none{/if} cl">
					<div id="diy_cimgshow" class="cimgshow z">
						<!--[diy=diy_cimgshow_1]--><div id="diy_cimgshow_1" class="area"></div><!--[/diy]-->
					</div>
					<div id="diy_csubjectbox" class="csubjectbox">
						<div class="hd">
							<ul>
								<li><i class="fa fa-fw fa-cube"></i> $clang[tz_new]</li>
								<li><i class="fa fa-fw fa-comments-o"></i> $clang[tz_reply]</li>
								<li><i class="fa fa-fw  fa-cubes"></i> $clang[tz_hot]</li>
								<li><i class="fa fa-fw fa-thumbs-o-up"></i> $clang[tz_digest]</li>
							</ul>
						</div>
						<div class="bd">
							<ul class="c_newlist">
								<!--[diy=diy_newlist_1]--><div id="diy_newlist_1" class="area"></div><!--[/diy]-->
							</ul>
							<ul class="c_newlist">
								<!--[diy=diy_newlist_2]--><div id="diy_newlist_2" class="area"></div><!--[/diy]-->
							</ul>
							<ul class="c_newlist">
								<!--[diy=diy_newlist_3]--><div id="diy_newlist_3" class="area"></div><!--[/diy]-->
							</ul>
							<ul class="c_newlist">
								<!--[diy=diy_newlist_4]--><div id="diy_newlist_4" class="area"></div><!--[/diy]-->
							</ul>
						</div>
					</div>
					<script type="text/javascript">
						jq("#diy_cimgshow").slide({titCell:".hd ul",mainCell:".bd ul",autoPage:true,effect:"leftLoop",autoPlay:true,trigger:"click",interTime:5000,delayTime:500});
						jq("#diy_csubjectbox").slide({autoPlay:false,trigger:"click",easing:"easeOutCirc",delayTime:500});
					</script>
				</div>
			<!--{/if}-->

			<!--{if $_G['basescript'] == 'forum' && $_GET['c'] == 'news'}-->
				<div class="news_bm{if $cset[pic_style] == 0} no_pic{/if}">
					<!--{eval $news_count=0;}-->
					<!--{loop $threadlists $thread}-->
						<!--{eval $news_count++;}-->
						<div id="news_$news_count" class="news_thread"{if $news_count ==1} style="border-top:0;"{/if}>
							<a href="home.php?mod=space&uid=$thread[authorid]" target="_blank" class="avr"><!--{avatar($thread[authorid],small)}--></a>
							<div class="tit_box cl">
								<!--{eval}-->
									if ($thread[views] > 9999){
										$views_w = $thread[views]/10000;
										$views_w = number_format($views_w, 1, '.', '');
									}
									if ($thread[replies] > 9999){
										$replies_w = $thread[replies]/10000;
										$replies_w = number_format($replies_w, 1, '.', '');
									}
								<!--{/eval}-->
								<div class="tj y">
									<em class="vie" title="{echo number_format({$thread[views]})}"><i class="fa fa-fw fa-eye"></i> {if $thread[views] > 9999}{$views_w}w{else}$thread[views]{/if}</em>
									<em class="rep" title="{echo number_format({$thread[replies]})}"><i class="fa fa-fw fa-comments-o"></i> {if $thread[replies] > 9999}{$replies_w}w{else}$thread[replies]{/if}</em>
								</div>
								<div class="tit">
									<a href="forum.php?mod=viewthread&tid=$thread[tid]" target="_blank">$thread[subject]</a>
									<!--{if $thread['readperm']}-->
										<em class="cs" title="{lang readperm} $thread['readperm']"><i class="fa fa-fw fa-info-circle"></i>$thread['readperm']</em>
									<!--{/if}-->
									<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
										<em class="top t{$thread[displayorder]}" title="{$clang[tz_icon_zdes]}({$_G[setting][threadsticky][3-$thread[displayorder]]})"><i class="fa fa-fw  fa-thumb-tack"></i></em>
									<!--{/if}-->
									<!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
										<em class="digest d{$thread[digest]}" title="{$clang[tz_icon_jhes]}{$thread[digest]}"><i class="fa fa-fw fa-trophy"></i></em>
									<!--{/if}-->
									<!--{if $thread['attachment'] == 2}-->
										<em class="pici" title="{$clang[tz_icon_tpes]}"><i class="fa fa-fw fa-photo"></i> </em>
									<!--{elseif $thread['attachment'] == 1}-->
										<em class="file" title="{$clang[tz_icon_fjes]}"><i class="fa fa-fw fa-paperclip"></i></em>
									<!--{/if}-->
									<!--{if $thread['price']}-->
										<em class="price" title="{$clang[tz_icon_pricees]}: {$thread['price']}">{$clang['tz_icon_price']}$thread['price']</em>
									<!--{/if}-->
									<!--{if $thread['replycredit'] > 0}-->
										<em title="{lang replycredit} $thread['replycredit']">{$clang['tz_icon_jl']}{$thread['replycredit']}</em>
									<!--{/if}-->
									
									<!--{if $thread['mobile'] ==1}-->
										<em class="mobile"><i class="fa fa-fw fa-mobile"></i></em>
									<!--{elseif $thread['mobile'] ==2}-->
										<em class="mobile"><i class="fa fa-fw fa-map-marker"></i></em>
									<!--{elseif $thread['mobile'] ==3}-->
										<em class="mobile"><i class="fa fa-fw fa-camera-retro"></i></em>
									<!--{elseif $thread['mobile'] ==4}-->
										<em class="mobile"><i class="fa fa-fw fa-microphone"></i></em>
									<!--{/if}-->
								</div>
							</div>
							<!--{if $thread['message']}-->
									<div class="smy">$thread['message']</div>
							<!--{/if}-->
							<!--{if $thread['attachment'] == 2}-->
									<div class="pic cl" id="gallery_$thread[tid]" style="max-height:{echo $cset[pic_h]}px;">
										<div class="pic_item">
											<!--{eval $i=$sii=0;}-->
											<!--{loop $thread['picsub'] $v}-->
												<!--{if !in_array($v['aid'],$thread['priceaids']) && !in_array($v['aid'],$thread['hideaids'])}-->
													<!--{if $i<$cset[pic_num]}-->
														<!--{eval}-->
															if ($v['remote']) { $cover = $_G['setting']['ftp']['attachurl']."forum/$v[attachment]"; }
															else { $cover = $_G['setting']['attachurl']."forum/$v[attachment]";}
															if (!in_array($user_info['adminid'], array('1','2','3'))){
																if ($user_readaccess < $v['readperm']) {
																	$cover = $_G['style'][styleimgdir]."/cant_view_re.jpg";;
																} elseif ($v['price']) {
																	$cover = $_G['style'][styleimgdir]."/cant_view_pay.jpg";;
																}
															}
														<!--{/eval}-->
														<a id="aimg_$v['aid']" aid="$v['aid']" href="$cover" target="_blank" style="width:{$cset[pic_w]}px;height:{$cset[pic_h]}px;{if $i==0}margin-left:0;{/if}" {if $v['description']}title="{$v['description']}"{/if}>
															<img {if $cset[pic_style]==1}data-original{else}original{/if}="{echo getforumimg($v['aid'], 0, $cset[pic_w], $cset[pic_h]);}" alt="$v['filename']" class="clazy" width="$cset[pic_w]" height="$cset[pic_h]"/>
															<noscript><img src="{echo getforumimg($v['aid'], 0, $cset[pic_w], $cset[pic_h]);}" alt="$v['filename']" width="$cset[pic_w]" height="$cset[pic_h]"/></noscript>
														</a>
														<!--{eval $sii++}-->
													<!--{/if}-->
												<!--{/if}-->
												<!--{eval $i++}-->
											<!--{/loop}-->
										</div>
										<!--{if $sii}-->
											<script language="javascript">
												jq(document).ready(function() {
													jq("#gallery_$thread['tid'] img").fsgallery()
												})
											</script>
										<!--{/if}-->
									</div>
							<!--{/if}-->
							<div class="sub">
								<em class="lastreply y">
									<!--{if $thread['lastpost'] == $thread['dateline']}-->
									<i class="fa fa-fw fa-comment-o"></i> {$clang[no_reply]}
									<!--{else}-->
										<a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost" target="_blank"><span title="{lang forum_lastpost}"><i class="fa fa-fw fa-comment"></i> $thread[lastposter] @ </span><!--{echo dgmdate($thread['lastpost'], 'u', '9999', getglobal('setting/dateformat'))}-->
										</a>
									<!--{/if}-->
								</em>
								<em class="aor"><a href="home.php?mod=space&uid=$thread[authorid]" c="1" target="_blank"><i class="fa fa-fw fa-coffee"></i> $thread[author]</a></em>
								<em class="date"><i class="fa fa-fw fa-clock-o"></i> <!--{echo dgmdate($thread['dateline'], 'u', '9999', getglobal('setting/dateformat'))}--></em>
								<em class="cat"><a href="forum.php?mod=forumdisplay&fid=$thread[fid]" target="_blank"><i class="fa fa-fw fa-folder-open"></i> $thread[name]</a></em>
								<!--{if $thread['tags']}-->
									<em class="tag"><i class="fa fa-fw fa-tags"></i> 
										<!--{eval $count=0;}--> 
										<!--{loop $thread['tags'] $v}-->
											<!--{eval $tag = explode(",", $v);}-->
											<!--{if $count > 0}-->,&nbsp;<!--{/if}-->
											<a href="misc.php?mod=tag&id=$tag[0]" target="_blank">$tag[1]</a>
											<!--{eval $count++;}-->
										<!--{/loop}-->
									</em>
								<!--{/if}-->
							</div>
						</div>
					<!--{/loop}-->
					<!--{if $news_count >= $cset['lines']}-->
						<div class="viewmore"><a href="forum.php?mod=guide&view=newthread">$clang['viewmore']</a></div>
					<!--{/if}-->
				</div>
			<!--{else}-->
				<!--{hook/index_top}-->
				<!--{if !empty($_G['cache']['heats']['message'])}-->
					<div class="bm">
						<div class="bm_h cl">
							<h2>{lang hotthreads_forum}</h2>
						</div>
						<div class="bm_c cl">
							<div class="heat z">
								<!--{loop $_G['cache']['heats']['message'] $data}-->
									<dl class="xld">
										<dt><!--{if $_G['adminid'] == 1}--><a class="d" href="forum.php?mod=misc&action=removeindexheats&tid=$data[tid]" onclick="return removeindexheats()">delete</a><!--{/if}-->
										<a href="forum.php?mod=viewthread&tid=$data[tid]" target="_blank" class="cxi2">$data[subject]</a></dt>
										<dd>$data[message]</dd>
									</dl>
								<!--{/loop}-->
							</div>
							<ul class="xl xl1 heatl">
							<!--{loop $_G['cache']['heats']['subject'] $data}-->
								<li><!--{if $_G['adminid'] == 1}--><a class="d" href="forum.php?mod=misc&action=removeindexheats&tid=$data[tid]" onclick="return removeindexheats()">delete</a><!--{/if}-->&middot; <a href="forum.php?mod=viewthread&tid=$data[tid]" target="_blank" class="cxi2">$data[subject]</a></li>
							<!--{/loop}-->
							</ul>
						</div>
					</div>
				<!--{/if}-->

				<!--{hook/index_catlist_top}-->
				<div class="fl bm">
					<!--{if !empty($collectiondata['follows'])}-->

					<!--{eval $forumscount = count($collectiondata['follows']);}-->
					<!--{eval $forumcolumns = 4;}-->

					<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->

					<div class="bm cbm_box {if $forumcolumns} flg{/if} cl">
						<div class="bm_h cl">
							<span class="o">
								<img id="category_-1_img" src="$_G['style'][styleimgdir]/common//$collapse['collapseimg_-1']" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_-1');" />
							</span>
							<h2><a href="forum.php?mod=collection&op=my">{lang my_order_collection}</a></h2>
						</div>
						<div id="category_-1" class="bm_c" style="{echo $collapse['category_-1']}">
							<table cellspacing="0" cellpadding="0" class="fl_tb">
								<tr>
								<!--{eval $ctorderid = 0;}-->
								<!--{loop $collectiondata['follows'] $key $colletion}-->
									<!--{if $ctorderid && ($ctorderid % $forumcolumns == 0)}-->
										</tr>
										<!--{if $ctorderid < $forumscount}-->
											<tr class="fl_row">
										<!--{/if}-->
									<!--{/if}-->
									<td class="fl_g"{if $forumcolwidth} width="$forumcolwidth"{/if}>
										<div class="fl_icn_g">
											<!--<a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}" target="_blank"><img src="$_G['style'][styleimgdir]/forum{if $followcollections[$key]['lastvisit'] < $colletion['lastupdate']}_new{/if}.gif" alt="$colletion[name]" /></a>-->
											<a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}" target="_blank"><div class="fl_icn_t{if $followcollections[$key]['lastvisit'] < $colletion['lastupdate']} new{/if}">{echo cutstr($colletion[name],2,'')}</div></a>
										</div>
										<dl>
											<dt><a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}">$colletion[name]</a></dt>
											<dd><em>{lang forum_threads}: <!--{echo dnumber($colletion[threadnum])}--></em>, <em>{lang collection_commentnum}: <!--{echo dnumber($colletion[commentnum])}--></em></dd>
											<dd>
											<!--{if $colletion['lastpost']}-->
												<!--{if $forumcolumns < 3}-->
													<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost" class="cxi2"><!--{echo cutstr($colletion[lastsubject], 30)}--></a>
												<!--{else}-->
													<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost" class="cxi2"><!--{echo cutstr($colletion[lastsubject], 26)}--></a>
												<!--{/if}-->
												<br/>
												<cite><!--{if $colletion['lastposter']}-->$colletion['lastposter']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--> <!--{date($colletion[lastposttime])}--></cite>
											<!--{else}-->
												{lang never}
											<!--{/if}-->
											</dd>
											<!--{hook/index_followcollection_extra $colletion[ctid]}-->
										</dl>
									</td>
									<!--{eval $ctorderid++;}-->

								<!--{/loop}-->
								<!--{if ($columnspad = $ctorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->
								</tr>
							</table>

						</div>
					</div>

					<!--{/if}-->
					<!--{if empty($gid) && !empty($forum_favlist)}-->
					<!--{eval $forumscount = count($forum_favlist);}-->
					<!--{eval $forumcolumns = $forumscount > 3 ? ($forumscount == 4 ? 4 : 5) : 1;}-->
					<!--{if $forumcolumns >4}-->
						<!--{eval $forumcolumns = 4}-->
					<!--{/if}-->

					<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->

					<div class="bm cbm_box {if $forumcolumns} flg{/if} cl">
						<div class="bm_h cl">
							<span class="o">
								<img id="category_0_img" src="$_G['style'][styleimgdir]/common//$collapse['collapseimg_0']" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_0');" />
							</span>
							<h2><a href="home.php?mod=space&do=favorite&type=forum">{lang forum_myfav}</a></h2>
						</div>
						<div id="category_0" class="bm_c" style="{echo $collapse['category_0']}">
							<table cellspacing="0" cellpadding="0" class="fl_tb">
								<tr>
								<!--{eval $favorderid = 0;}-->
								<!--{loop $forum_favlist $key $favorite}-->
								<!--{if $favforumlist[$favorite[id]]}-->
								<!--{eval $forum=$favforumlist[$favorite[id]];}-->
								<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
									<!--{if $forumcolumns>1}-->
										<!--{if $favorderid && ($favorderid % $forumcolumns == 0)}-->
											</tr>
											<!--{if $favorderid < $forumscount}-->
												<tr class="fl_row">
											<!--{/if}-->
										<!--{/if}-->
										<!--{if !empty($forum[description])}-->
											<div id="c_description_0_{$forum[fid]}_c" class="cdes_in p_pop" style=" display: none;">
												<!--{echo dnumber($forum[description])}-->
											</div>
										<!--{/if}-->
										<td class="fl_g"{if $forumcolwidth} width="$forumcolwidth"{/if}>
											<div class="fl_icn_gc"{if !empty($forum[extra][iconwidth]) && !empty($forum[icon])} style="width: $forum[extra][iconwidth]px;"{/if}>
												<span class="cdes"{if !empty($forum[description])} id="c_description_0_{$forum[fid]}" onmouseover="showMenu({'ctrlid':this.id,'menuid':'c_description_0_{$forum[fid]}_c','pos':'43','duration':2});"{/if}>
													<!--{if $forum[todayposts] && !$forum['redirect']}--><em class="ctodayposts" title="{lang forum_todayposts}">$forum[todayposts]</em><!--{/if}-->
													<!--{if $forum[icon]}-->
														$forum[icon]
													<!--{else}-->
														<!--<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="$_G['style'][styleimgdir]/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>-->
														<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><div class="fl_icn_t{if $forum[folder]} new{/if}">{echo cutstr($forum[name],2,'')}</div></a>
													<!--{/if}-->
												</span>
											</div>
											<dl style="margin-left: 0px;">
												<dt><a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a></dt>
												<!--{if empty($forum[redirect])}--><dd><em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em>, <em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em></dd><!--{/if}-->
												<dd>
												<!--{if $forum['permission'] == 1}-->
													{lang private_forum}
												<!--{else}-->
													<!--{if $forum['redirect']}-->
														<a href="$forumurl" class="cxi2">{lang url_link}</a>
													<!--{elseif is_array($forum['lastpost'])}-->
														<!--{if $forumcolumns < 3}-->
															<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="cxi2" title="{$forum[lastpost][subject]}"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a>
														<!--{else}-->
															<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" title="{$forum[lastpost][subject]}"><!--{echo cutstr($forum[lastpost][subject], 26)}--></a>
														<!--{/if}-->
														<br/>
														<cite><!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--> $forum[lastpost][dateline]</cite>
													<!--{else}-->
														{lang never}
													<!--{/if}-->
												<!--{/if}-->
												</dd>
												<!--{hook/index_favforum_extra $forum[fid]}-->
											</dl>
										</td>
										<!--{eval $favorderid++;}-->
									<!--{else}-->
										<!--{if !empty($forum[description])}-->
											<div id="c_description_0_{$forum[fid]}_c" class="cdes_in p_pop" style=" display: none;">
												<!--{echo dnumber($forum[description])}-->
											</div>
										<!--{/if}-->
										<td class="fl_icn" {if !empty($forum[extra][iconwidth]) && !empty($forum[icon])} style="width: $forum[extra][iconwidth]px;"{/if}>
											<span class="cdes"{if !empty($forum[description])} id="c_description_0_{$forum[fid]}" onmouseover="showMenu({'ctrlid':this.id,'menuid':'c_description_0_{$forum[fid]}_c','pos':'43','duration':2});"{/if}>
												<!--{if $forum[todayposts] && !$forum['redirect']}--><em class="ctodayposts" title="{lang forum_todayposts}">$forum[todayposts]</em><!--{/if}-->
												<!--{if $forum[icon]}-->
													$forum[icon]
												<!--{else}-->
													<!--<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="$_G['style'][styleimgdir]/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>-->
													<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><div class="fl_icn_t{if $forum[folder]} new{/if}">{echo cutstr($forum[name],2,'')}</div></a>
												<!--{/if}-->
											</span>
										</td>
										<td>
											<h2><a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a></h2>
											<!--{if $forum['subforums']}--><p>{lang forum_subforums}: $forum['subforums']</p><!--{/if}-->
											<!--{if $forum['moderators']}--><p>{lang forum_moderators}: <span class="cxi2">$forum[moderators]</span></p><!--{/if}-->
											<!--{hook/index_favforum_extra $forum[fid]}-->
										</td>
										<td class="fl_i">
											<!--{if empty($forum[redirect])}--><span class="cxi2"><!--{echo dnumber($forum[threads])}--></span><span class="xg1"> / <!--{echo dnumber($forum[posts])}--></span><!--{/if}-->
										</td>
										<td class="fl_by">
											<div>
											<!--{if $forum['permission'] == 1}-->
												{lang private_forum}
											<!--{else}-->
												<!--{if $forum['redirect']}-->
													<a href="$forumurl" class="cxi2">{lang url_link}</a>
												<!--{elseif is_array($forum['lastpost'])}-->
													<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="cxi2"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a>
													<br/><cite><!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--> $forum[lastpost][dateline]</cite>
												<!--{else}-->
													{lang never}
												<!--{/if}-->
											<!--{/if}-->
											</div>
										</td>
									</tr>
									<tr class="fl_row">

									<!--{/if}-->
								<!--{/if}-->
								<!--{/loop}-->
								<!--{if ($columnspad = $favorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->
								</tr>
							</table>

						</div>
					</div>
					<!--{ad/intercat/bm a_c/-1}-->
				<!--{/if}-->
				<!--{loop $catlist $key $cat}-->
					<!--{hook/index_catlist $cat[fid]}-->
					<div class="bm cbm_box {if $cat['forumcolumns']} flg{/if} cl">
						<div class="bm_h cl">
							<span class="o">
								<img id="category_$cat[fid]_img" src="$_G['style'][styleimgdir]/common//$cat[collapseimg]" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_$cat[fid]');" />
							</span>
							<!--{if $cat['moderators']}--><span class="y">{lang forum_category_modedby}: $cat[moderators]</span><!--{/if}-->
							<!--{eval $caturl = !empty($cat['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$cat['domain'].'.'.$_G['setting']['domain']['root']['forum'] : '';}-->
							<h2><a href="{if !empty($caturl)}$caturl{else}forum.php?gid=$cat[fid]{/if}" style="{if $cat[extra][namecolor]}color: {$cat[extra][namecolor]};{/if}">$cat[name]</a></h2>
						</div>
						<div id="category_$cat[fid]" class="bm_c" style="{echo $collapse['category_'.$cat[fid]]}">
							<table cellspacing="0" cellpadding="0" class="fl_tb">
								<tr>
								<!--{loop $cat[forums] $forumid}-->
								<!--{eval $forum=$forumlist[$forumid];}-->
								<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
								<!--{if $cat['forumcolumns'] > 4}--><!--{eval $cat['forumcolumns'] = 4}--><!--{/if}-->
								<!--{if $cat['forumcolumns']}-->
									<!--{if $forum['orderid'] && ($forum['orderid'] % $cat['forumcolumns'] == 0)}-->
										</tr>
										<!--{if $forum['orderid'] < $cat['forumscount']}-->
											<tr class="fl_row">
										<!--{/if}-->
									<!--{/if}-->
									<td class="fl_g" width="$cat[forumcolwidth]">
										<!--{if $cat['forumcolumns'] > 2}-->
											<!--{if !empty($forum[description])}-->
												<div id="c_description_{$cat[fid]}_{$forum[fid]}_c" class="cdes_in p_pop" style=" display: none;">
													<!--{echo dnumber($forum[description])}-->
												</div>
											<!--{/if}-->
											<div class="fl_icn_gc">
												<span class="cdes"{if !empty($forum[description])} id="c_description_{$cat[fid]}_{$forum[fid]}" onmouseover="showMenu({'ctrlid':this.id,'menuid':'c_description_{$cat[fid]}_{$forum[fid]}_c','pos':'43','duration':2});"{/if}>
													<!--{if $forum[todayposts] && !$forum['redirect']}--><em class="ctodayposts" title="{lang forum_todayposts}">$forum[todayposts]</em><!--{/if}-->
													<!--{if $forum[icon]}-->
														$forum[icon]
													<!--{else}-->
														<!--<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="$_G['style'][styleimgdir]/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>-->
														<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><div class="fl_icn_t{if $forum[folder]} new{/if}">{echo cutstr($forum[name],2,'')}</div></a>
													<!--{/if}-->
												</span>
											</div>
											<dl style="margin-left: 0px;">
												<dt><a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a></dt>
												<!--{if empty($forum[redirect])}--><dd><em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em>, <em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em></dd><!--{/if}-->
												<dd>
												<!--{if $forum['permission'] == 1}-->
													{lang private_forum}
												<!--{else}-->
													<!--{if $forum['redirect']}-->
														<a href="$forumurl" class="cxi2">{lang url_link}</a>
													<!--{elseif is_array($forum['lastpost'])}-->
														<!--{if $cat['forumcolumns'] < 3}-->
															<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="cxi2" title="{$forum[lastpost][subject]}"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a>
														<!--{else}-->
															<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" title="{$forum[lastpost][subject]}"><!--{echo cutstr($forum[lastpost][subject], 26)}--></a>
														<!--{/if}-->
														<br/>
														<cite><!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--> $forum[lastpost][dateline]</cite>
													<!--{else}-->
														{lang never}
													<!--{/if}-->
												<!--{/if}-->
												</dd>
												<!--{hook/index_forum_extra $forum[fid]}-->
											</dl>
										<!--{else}-->
											<!--{if !empty($forum[description])}-->
												<div id="c_description_{$cat[fid]}_{$forum[fid]}_c" class="cdes_in p_pop" style=" display: none;">
													<!--{echo dnumber($forum[description])}-->
												</div>
											<!--{/if}-->
											<div class="fl_icn_g"{if !empty($forum[extra][iconwidth]) && !empty($forum[icon])} style="width: $forum[extra][iconwidth]px;"{/if}>
												<span class="cdes"{if !empty($forum[description])} id="c_description_{$cat[fid]}_{$forum[fid]}" onmouseover="showMenu({'ctrlid':this.id,'menuid':'c_description_{$cat[fid]}_{$forum[fid]}_c','pos':'43','duration':2});"{/if}>
													<!--{if $forum[todayposts] && !$forum['redirect']}--><em class="ctodayposts" title="{lang forum_todayposts}">$forum[todayposts]</em><!--{/if}-->
													<!--{if $forum[icon]}-->
														$forum[icon]
													<!--{else}-->
														<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><div class="fl_icn_t{if $forum[folder]} new{/if}">{echo cutstr($forum[name],2,'')}</div></a>
														<!--<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="$_G['style'][styleimgdir]/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>-->
													<!--{/if}-->
												</span>
											</div>
											<dl{if !empty($forum[extra][iconwidth]) && !empty($forum[icon])} style="margin-top: -7px; margin-left: {echo $forum[extra][iconwidth]+10}px;"{/if}>
												<dt><a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a></dt>
												<!--{if empty($forum[redirect])}--><dd><em>{lang forum_threads}: <!--{echo dnumber($forum[threads])}--></em>, <em>{lang forum_posts}: <!--{echo dnumber($forum[posts])}--></em></dd><!--{/if}-->
												<dd>
												<!--{if $forum['permission'] == 1}-->
													{lang private_forum}
												<!--{else}-->
													<!--{if $forum['redirect']}-->
														<a href="$forumurl" class="cxi2">{lang url_link}</a>
													<!--{elseif is_array($forum['lastpost'])}-->
														<!--{if $cat['forumcolumns'] < 3}-->
															<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="cxi2" title="{$forum[lastpost][subject]}"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a>
														<!--{else}-->
															<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" title="{$forum[lastpost][subject]}"><!--{echo cutstr($forum[lastpost][subject], 26)}--></a>
														<!--{/if}-->
														<br/>
														<cite><!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--> $forum[lastpost][dateline]</cite>
													<!--{else}-->
														{lang never}
													<!--{/if}-->
												<!--{/if}-->
												</dd>
												<!--{hook/index_forum_extra $forum[fid]}-->
											</dl>
										<!--{/if}-->
									</td>
								<!--{else}-->
									<!--{if !empty($forum[description])}-->
										<div id="c_description_{$cat[fid]}_{$forum[fid]}_c" class="cdes_in p_pop" style=" display: none;">
											<!--{echo dnumber($forum[description])}-->
										</div>
									<!--{/if}-->
									<td class="fl_icn" {if !empty($forum[extra][iconwidth]) && !empty($forum[icon])} style="width: $forum[extra][iconwidth]px;"{/if}>
										<span class="cdes"{if !empty($forum[description])} id="c_description_{$cat[fid]}_{$forum[fid]}" onmouseover="showMenu({'ctrlid':this.id,'menuid':'c_description_{$cat[fid]}_{$forum[fid]}_c','pos':'43','duration':2});"{/if}>
											<!--{if $forum[todayposts] && !$forum['redirect']}--><em class="ctodayposts" title="{lang forum_todayposts}">$forum[todayposts]</em><!--{/if}-->
											<!--{if $forum[icon]}-->
												$forum[icon]
											<!--{else}-->
												<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><div class="fl_icn_t{if $forum[folder]} new{/if}">{echo cutstr($forum[name],2,'')}</div></a>
												<!--<a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}><img src="$_G['style'][styleimgdir]/forum{if $forum[folder]}_new{/if}.gif" alt="$forum[name]" /></a>-->
											<!--{/if}-->
										</span>
									</td>
									<td>
										<h2><a href="$forumurl"{if $forum[redirect]} target="_blank"{/if}{if $forum[extra][namecolor]} style="color: {$forum[extra][namecolor]};"{/if}>$forum[name]</a></h2>

										<!--{if $forum['subforums']}--><p>{lang forum_subforums}: $forum['subforums']</p><!--{/if}-->
										<!--{if $forum['moderators']}--><p>{lang forum_moderators}: <span class="cxi2">$forum[moderators]</span></p><!--{/if}-->
										<!--{hook/index_forum_extra $forum[fid]}-->
									</td>
									<td class="fl_i">
										<!--{if empty($forum[redirect])}--><span class="cxi2"><!--{echo dnumber($forum[threads])}--></span><span class="xg1"> / <!--{echo dnumber($forum[posts])}--></span><!--{/if}-->
									</td>
									<td class="fl_by">
										<div>
										<!--{if $forum['permission'] == 1}-->
											{lang private_forum}
										<!--{else}-->
											<!--{if $forum['redirect']}-->
												<a href="$forumurl" class="cxi2">{lang url_link}</a>
											<!--{elseif is_array($forum['lastpost'])}-->
												<a href="forum.php?mod=redirect&tid=$forum[lastpost][tid]&goto=lastpost#lastpost" class="cxi2"><!--{echo cutstr($forum[lastpost][subject], 30)}--></a><br/>
												<cite><!--{if $forum['lastpost']['author']}-->$forum['lastpost']['author']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--> $forum[lastpost][dateline]</cite>
											<!--{else}-->
												{lang never}
											<!--{/if}-->
										<!--{/if}-->
										</div>
									</td>
								</tr>
								<tr class="fl_row">
								<!--{/if}-->
								<!--{/loop}-->
								$cat['endrows']
								</tr>
							</table>
						</div>
					</div>
					<!--{ad/intercat/bm a_c/$cat[fid]}-->
				<!--{/loop}-->
					<!--{if !empty($collectiondata['data'])}-->

					<!--{eval $forumscount = count($collectiondata['data']);}-->
					<!--{eval $forumcolumns = 4;}-->

					<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->

					<div class="bm cbm_box {if $forumcolumns} flg{/if} cl">
						<div class="bm_h cl">
							<span class="o">
								<img id="category_-2_img" src="$_G['style'][styleimgdir]/common//$collapse['collapseimg_-2']" title="{lang spread}" alt="{lang spread}" onclick="toggle_collapse('category_-2');" />
							</span>
							<h2><a href="forum.php?mod=collection">{lang recommend_collection}</a></h2>
						</div>
						<div id="category_-2" class="bm_c" style="{echo $collapse['category_-2']}">
							<table cellspacing="0" cellpadding="0" class="fl_tb">
								<tr>
								<!--{eval $ctorderid = 0;}-->
								<!--{loop $collectiondata['data'] $key $colletion}-->
									<!--{if $ctorderid && ($ctorderid % $forumcolumns == 0)}-->
										</tr>
										<!--{if $ctorderid < $forumscount}-->
											<tr class="fl_row">
										<!--{/if}-->
									<!--{/if}-->
									<td class="fl_g"{if $forumcolwidth} width="$forumcolwidth"{/if}>
										<div class="fl_icn_g">
											<a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}" target="_blank"><div class="fl_icn_t">{echo cutstr($colletion[name],2,'')}</div></a>
											<!--<a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}" target="_blank"><img src="$_G['style'][styleimgdir]/forum.gif" alt="$colletion[name]" /></a>-->
										</div>
										<dl>
											<dt><a href="forum.php?mod=collection&action=view&ctid={$colletion[ctid]}">$colletion[name]</a></dt>
											<dd><em>{lang forum_threads}: <!--{echo dnumber($colletion[threadnum])}--></em>, <em>{lang collection_commentnum}: <!--{echo dnumber($colletion[commentnum])}--></em></dd>
											<dd>
											<!--{if $colletion['lastpost']}-->
												<!--{if $forumcolumns < 3}-->
													<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost" class="cxi2"><!--{echo cutstr($colletion[lastsubject], 30)}--></a>
												<!--{else}-->
													<a href="forum.php?mod=redirect&tid=$colletion[lastpost]&goto=lastpost#lastpost" class="cxi2"><!--{echo cutstr($colletion[lastsubject], 26)}--></a>
												<!--{/if}-->
												<br/>
												<cite><!--{if $colletion['lastposter']}-->$colletion['lastposter']<!--{else}-->$_G[setting][anonymoustext]<!--{/if}--> <!--{date($colletion[lastposttime])}--></cite>
											<!--{else}-->
												{lang never}
											<!--{/if}-->
											</dd>
											<!--{hook/index_datacollection_extra $colletion[ctid]}-->
										</dl>
									</td>
									<!--{eval $ctorderid++;}-->

								<!--{/loop}-->
								<!--{if ($columnspad = $ctorderid % $forumcolumns) > 0}--><!--{echo str_repeat('<td class="fl_g"'.($forumcolwidth ? " width=\"$forumcolwidth\"" : '').'></td>', $forumcolumns - $columnspad);}--><!--{/if}-->
								</tr>
							</table>

						</div>
					</div>

					<!--{/if}-->

				</div>

				<!--{hook/index_middle}-->
				<div class="wp mtn">
					<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
				</div>

				<!--{if empty($gid) && $_G['setting']['whosonlinestatus']}-->
					<div id="online" class="bm cbm_box oll">
						<div class="bm_h">
						<!--{if $detailstatus}-->
							<span class="o"><a href="forum.php?showoldetails=no#online" title="{lang spread}"><img src="$_G['style'][styleimgdir]/common//collapsed_no.gif" alt="{lang spread}" /></a></span>
							<h3>
								<strong><a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a></strong>
								<span class="xs1">- <strong>$onlinenum</strong> {lang onlines}
								- <strong>$membercount</strong> {lang index_members}(<strong>$invisiblecount</strong> {lang index_invisibles}),
								<strong>$guestcount</strong> {lang index_guests}
								- {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>
							</h3>
						<!--{else}-->
							<!--{if empty($_G['setting']['sessionclose'])}-->
								<span class="o"><a href="forum.php?showoldetails=yes#online" title="{lang spread}"><img src="$_G['style'][styleimgdir]/common//collapsed_yes.gif" alt="{lang spread}" /></a></span>
							<!--{/if}-->
							<h3>
								<strong>
									<!--{if !empty($_G['setting']['whosonlinestatus'])}-->
										{lang onlinemember}
									<!--{else}-->
										<a href="home.php?mod=space&do=friend&view=online&type=member">{lang onlinemember}</a>
									<!--{/if}-->
								</strong>
								<span class="xs1">- {lang total} <strong>$onlinenum</strong> {lang onlines}
								<!--{if $membercount}-->- <strong>$membercount</strong> {lang index_members},<strong>$guestcount</strong> {lang index_guests}<!--{/if}-->
								- {lang index_mostonlines} <strong>$onlineinfo[0]</strong> {lang on} <strong>$onlineinfo[1]</strong>.</span>
							</h3>
						<!--{/if}-->
						</div>
					<!--{if $_G['setting']['whosonlinestatus'] && $detailstatus}-->
						<dl id="onlinelist" class="bm_c">
							<dt class="ptm pbm bbda">$_G[cache][onlinelist][legend]</dt>
							<!--{if $detailstatus}-->
								<dd class="ptm pbm">
								<ul class="cl">
								<!--{if $whosonline}-->
									<!--{loop $whosonline $key $online}-->
										<li title="{lang time}: $online[lastactivity]">
										<img src="{STATICURL}image/common/$online[icon]" alt="icon" />
										<!--{if $online['uid']}-->
											<a href="home.php?mod=space&uid=$online[uid]">$online[username]</a>
										<!--{else}-->
											$online[username]
										<!--{/if}-->
										</li>
									<!--{/loop}-->
								<!--{else}-->
									<li style="width: auto">{lang online_only_guests}</li>
								<!--{/if}-->
								</ul>
							</dd>
							<!--{/if}-->
						</dl>
					<!--{/if}-->
					</div>
				<!--{/if}-->

				<!--{if empty($gid) && ($_G['cache']['forumlinks'][0] || $_G['cache']['forumlinks'][1] || $_G['cache']['forumlinks'][2])}-->
					<div class="bm cbm_box ptm pbm lk">
						<div id="category_lk" class="bm_c ptm">
							<!--{if $_G['cache']['forumlinks'][0]}-->
								<ul class="m mbn cl">$_G['cache']['forumlinks'][0]</ul>
							<!--{/if}-->
							<!--{if $_G['cache']['forumlinks'][1]}-->
								<div class="mbn cl">
									$_G['cache']['forumlinks'][1]
								</div>
							<!--{/if}-->
							<!--{if $_G['cache']['forumlinks'][2]}-->
								<ul class="x mbm cl">
									$_G['cache']['forumlinks'][2]
								</ul>
							<!--{/if}-->
						</div>
					</div>
				<!--{/if}-->

				<!--{hook/index_bottom}-->
			<!--{/if}-->
		</div><!-- div.mnmn end -->
	</div><!-- div.mn end -->





		<!--{if $_G['setting']['forumallowside']}-->
			<div id="sd" class="sd" style="position:relative;">
				<div class="sdsd">
					<!--{hook/index_side_top}-->
					<div class="sd_mk cl">
						<a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="sd_post z"><i class="fa fa-pencil-square-o"></i> $clang['post']</a>
						<a href="javascript:;" id="qmenu" class="sd_qmenu" onclick="delayShow(this, function () {showMenu({'ctrlid':'qmenu','pos':'34!','ctrlclass':'a','duration':2});showForummenu($_G[fid]);})"><i class="fa fa-navicon"></i> $clang['qmenu']</a>
					</div>
					<!--{eval require DISCUZ_ROOT.'./template/the_c_style/php/c_sdad.php';}-->
					<div class="sd_mkes sd_recpic"><!--sd_recpic-->
						<div class="sd_title"><h2><i class="fa fa-hand-o-right"></i> $clang[hot_rec]</h2></div>
						<ul>
							<li class="num1">
								<a href="$gdad1[0]" title="$gdad1[2]">
									<img data-original="$gdad1[1]" class="clazy" alt="$gdad1[2]" />
									<noscript><img src="$gdad1[1]" alt="$gdad1[2]" /></noscript>
								</a>
							</li>
							<li><a href="$sjad1[0]" title="$sjad1[2]"><img data-original="$sjad1[1]" class="clazy" alt="$sjad1[2]" /><noscript><img src="$sjad1[1]"/></noscript></a></li>
							<li><a href="$sjad2[0]" title="$sjad2[2]"><img data-original="$sjad2[1]" class="clazy" alt="$sjad2[2]" /><noscript><img src="$sjad2[1]" alt="$sjad2[2]" /></noscript></a></li>
						</ul>
					</div>

					<div class="sd_mkes sd_tag">
						<div class="sd_title"><h2><i class="fa fa-tags"></i> $clang['tag']</h2></div>
						<div class="item cl">
							<!--{eval shuffle($tag_query);}-->
							<!--{if $tag_query}-->
								<!--{eval $i=0;}-->
								<!--{loop $tag_query $tagarray}-->
									<!--{eval}-->
										$CR = rand($cset['tagcolor_a'],$cset['tagcolor_b']); $CG = rand($cset['tagcolor_a'],$cset['tagcolor_b']); $CB = rand($cset['tagcolor_a'],$cset['tagcolor_b']); $CT = rand(0.1,1.0);
									<!--{/eval}-->
									<!--{if $i < $cset[tagnum]}-->
										<a href="misc.php?mod=tag&id=$tagarray['tagid']" target="_blank" title="$tagarray['count']{$clang['tagcount']}" style="color:rgb($CR,$CG,$CB);">{$tagarray['tagname']}</a>
									<!--{/if}-->
									<!--{eval $i++;}-->
								<!--{/loop}-->
							<!--{else}-->
								<a href="javascript:;" class="notag">{$clang['notag']}</a>
							<!--{/if}-->
						</div>
					</div>

					<div class="sd_mkes sd_rank">
						<div class="sd_title"><h2><i class="fa fa-line-chart"></i> $clang[rank]</h2></div>
						<div id="sd_rank">
							<div class="hd">
								<ul>
									<li style="margin-left:0;">{$clang[day_rank]}</li><li>{$clang[week_rank]}</li><li>{$clang[month_rank]}</li>
								</ul>
							</div>
							<div class="bd">
								<ul>
									<!--[diy=diy_day_rank]--><div id="diy_day_rank" class="area"></div><!--[/diy]-->
								</ul>
								<ul>
									<!--[diy=diy_week_rank]--><div id="diy_week_rank" class="area"></div><!--[/diy]-->
								</ul>
								<ul>
									<!--[diy=diy_month_rank]--><div id="diy_month_rank" class="area"></div><!--[/diy]-->
								</ul>
							</div>
						</div>
					</div>

					<script type="text/javascript">
						jq("#sd_rank").slide({autoPlay:false,effect:"fade",trigger:"click",easing:"easeOutCirc",delayTime:500});
					</script>

					<div class="sd_mkes sd_reply last_btm">
						<div class="sd_title"><h2><i class="fa fa-comments-o"></i> $clang['lastreplies']</h2></div>
						<div id="nano_main" style="height:400px;">
							<div class="nano">
								<i class="line-y"></i>
								<ul class="overthrow nano-content description">
									<!--{eval $r_num=1;}--> 
									<!--{loop $r_posts $r_post}-->
										<li class="num{$r_num}">
											<a href="home.php?mod=space&uid=$r_post['authorid']" target="_blank" class="avr"><!--{avatar($r_post['authorid'],small)}--></a>
											<a href="forum.php?mod=redirect&goto=findpost&tid=$r_post['tid']&pid={$r_post['pid']}" title="$clang['reply']: $r_post['message']&#10;$clang['from']: $r_post['subject']"><p class="txt_s">$r_post['message']</p></a>
											<p>
												<em class="date"><!--{echo dgmdate($r_post['dateline'], 'u', '9999', getglobal('setting/dateformat'))}--></em>
												<a href="home.php?mod=space&uid=$r_post['authorid']" {target} class="aor" title="{$clang[tz_poster]}">$r_post['author']</a>
											</p>
										</li>
										<!--{eval $r_num++;}-->
									<!--{/loop}-->
								</ul>
							</div>
						</div>
					</div>
					<div class="drag">
						<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
					</div>
					<!--{hook/index_side_bottom}-->
				</div>
			</div>
		<!--{/if}-->

		<script type="text/javascript">
			eval(function(p,a,c,k,e,d){e=function(c){return(c<a?"":e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)d[e(c)]=k[c]||e(c);k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1;};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p;}('7(g(\'9\')>0){a 4=0}o{a 4=1};6 5(s,t){7(s<0){p(\'9\',-1,8*8*l*m);2(\'.b\').e(\'n\');2(\'.5\').e(\'f-1\').d(\'k\')}o{p(\'9\',1,8*8*l*m);2(\'.b\').d(\'n\');2(\'.5\').e(\'k\').d(\'f-1\');2(\'.b\').q(\'i\').x(6(){a 3=2(j).h(\'3\');7(3){2(j).h(\'y-3\',3).z(\'3\')}});7(t==1){2(6(){2("i.4").r({w:"v"})});4=0}}}2(\'.5\').u(6(){a c=g(\'9\');5(0-c,4)})',36,36,'||jq|original|clazy|picstyle|function|if|60|c_picstyle|var|news_bm||removeClass|addClass|pic_|getcookie|attr|img|this|pic_1|24|365|no_pic|else|setcookie|find|lazyload|||click|fadeIn|effect|each|data|removeAttr'.split('|'),0,{}))

			<!--{if $_GET['diy'] != 'yes'}-->
				jq(window).scroll(function() {
					ttbb(0,$ctop,$cnvheight);
				})
				ttbb(0,$ctop,$cnvheight);
			<!--{/if}-->
			jq(function(){
				jq('.nano').nanoScroller({
					preventPageScrolling: true
				});
			});
		</script>

</div>
<!--{if $_G['group']['radminid'] == 1}-->
	<!--{eval helper_manyou::checkupdate();}-->
<!--{/if}-->
<!--{template common/footer}-->
