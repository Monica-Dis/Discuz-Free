<?php echo ' ';exit;?>
<!--{if $list['threadcount']}-->
	<!--{loop $list['threadlist'] $key $thread}-->
		<tbody id="$thread[id]">
			<tr>
				
				<td class="avr">
					<!--{if $thread['authorid'] && $thread['author']}-->
						<a href="home.php?mod=space&uid=$thread[authorid]"><!--{avatar($thread['authorid'],small)}--></a>
					<!--{else}-->
						<!--{avatar(0,small)}-->
					<!--{/if}-->
				</td>
				<th class="main $thread[folder]">
					<div class="titbox">
						<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
						<!--{/if}-->
						$thread[typehtml] $thread[sorthtml]
						<!--{if $thread['moved']}-->
							{lang thread_moved}:<!--{eval $thread[tid]=$thread[closed];}-->
						<!--{/if}-->
						<a href="forum.php?mod=viewthread&tid=$thread[tid]&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" target="_blank" class="tit xst" >$thread[subject]</a><!--{if $_G['setting']['threadhidethreshold'] && $thread['hidden'] >= $_G['setting']['threadhidethreshold']}-->&nbsp;<span class="xg1">{lang hidden}</span>&nbsp;<!--{/if}--><!--{if $view == 'hot'}-->&nbsp;<span class="xi1">$thread['heats']{lang guide_attend}</span>&nbsp;<!--{/if}-->
						<!--{if $stemplate && $sortid}-->$stemplate[$sortid][$thread[tid]]<!--{/if}-->
						<!--{if $thread['readperm']}-->
							<em class="cs" title="{lang readperm} $thread['readperm']"><i class="fa fa-fw fa-info-circle"></i>$thread['readperm']</em>
						<!--{/if}-->
						<!--{if $thread['price'] > 0}-->
							<!--{if $thread['special'] == '3'}-->
								<em class="price" title="{lang thread_reward} $thread['price'] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}]"><i class="fa fa-fw fa-rmb"></i>$thread['price']</em>
							<!--{else}-->
								<em class="price" title="{lang price} $thread['price'] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}">{$clang['tz_icon_price']}$thread['price']</em>
							<!--{/if}-->
						<!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
								<em class="price">{lang reward_solved}</em>
						<!--{/if}-->
						<!--{if $thread['replycredit'] > 0}-->
							<em title="{lang replycredit} $thread['replycredit']">{$clang['tz_icon_jl']}{$thread['replycredit']}</em>
						<!--{/if}-->
						<!--{if $thread['rushreply']}-->
							<em title="{$clang['tz_icon_qles']}">$clang['tz_icon_ql']</em>
						<!--{/if}-->
						<!--{if $thread['attachment'] == 2}-->
							<em class="pici" title="{$clang['tz_icon_tpes']}"><i class="fa fa-fw fa-photo"></i></em>
						<!--{elseif $thread['attachment'] == 1}-->
							<em class="file" title="{$clang['tz_icon_fjes']}">{$clang[tz_icon_fj]}</em>
						<!--{/if}-->
						<!--{if $thread['digest'] > 0 && $filter != 'digest'}-->
							<em class="digest d{$thread[digest]}" title="{$clang[tz_icon_jhes]}{$thread[digest]}">{$clang[tz_icon_jh]} {$thread[digest]}</em>
						<!--{/if}-->
						<!--{if $thread['displayorder'] == 0}-->
							<!--{if $thread[recommendicon] && $filter != 'recommend'}-->
								<em class="rec" title="$clang[tz_icon_tjes] $thread[recommends]">{$clang[tz_icon_tj]} {$thread[recommendicon]}</em>
							<!--{/if}-->
							<!--{if $thread[heatlevel]}-->
								<em class="hot" title="$clang[tz_icon_hotes]">{$clang[tz_icon_hot]} {$thread[heatlevel]}</em>
							<!--{/if}-->
							<!--{if $thread['rate'] > 0}-->
								<em class="jf" title="$clang[tz_icon_jfes]">{$clang[tz_icon_jf]}</em>
							<!--{elseif $thread['rate'] < 0}-->
								<em class="jfd" title="$clang[tz_icon_jfdes]">{$clang[tz_icon_jfd]}</em>
							<!--{/if}-->
						<!--{/if}-->
						<!--{if $thread[icon] >= 0}-->
							&nbsp;<img class="chide" src="{STATICURL}image/stamp/{$_G[cache][stamps][$thread[icon]][url]}" alt="{$_G[cache][stamps][$thread[icon]][text]}" align="absmiddle" />
							<em>{$_G[cache][stamps][$thread[icon]][text]}</em>
						<!--{/if}-->
						<!--{if $thread[multipage]}-->
							<span class="tps">$thread[multipage]</span>
						<!--{/if}-->
						<!--{if $thread['weeknew']}-->
							<a href="forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost#lastpost"><em class="cs">New</em></a>
						<!--{/if}-->
						<!--{if !$thread['forumstick'] && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
							<!--{if $thread['related_group'] == 0 && $thread['closed'] > 1}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
							<!--{/if}-->
						<!--{/if}-->
					</div>
					<div class="sub">
						<em class="aor">
							<!--{if $thread['authorid'] && $thread['author']}-->
								<a href="home.php?mod=space&uid=$thread[authorid]" c="1">$thread[author]</a><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}-->
							<!--{else}-->
								$_G[setting][anonymoustext]
							<!--{/if}-->
						</em>

						<em class="dte{if $thread['istoday']} xi1{/if}">$thread[dateline]</em>
						<em class="vie"><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}--></em>
						<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="xi2"><em class="rey">
							$thread[replies]
						</em></a>
						<cite class="y">
							<!--{if $thread['lastposter']}--><a href="{if $thread[digest] != -2}home.php?mod=space&username=$thread[lastposterenc]{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}" c="1">$thread[lastposter]</a><!--{else}-->$_G[setting][anonymoustext]<!--{/if}-->
							&nbsp;@&nbsp;
							<a href="{if $thread[digest] != -2}forum.php?mod=redirect&tid=$thread[tid]&goto=lastpost$highlight#lastpost{else}forum.php?mod=viewthread&tid=$thread[tid]&page={echo max(1, $thread[pages]);}{/if}">$thread[lastpost]</a>
						</cite>
					</div>
				</th>
			</tr>
		</tbody>
		<!--{if $view == 'my' && $viewtype=='reply' && !empty($tids[$thread[tid]])}-->
			<tbody class="bw0_all">
				<tr>
					<td class="icn">&nbsp;</td>
					<td colspan="5">
						<!--{loop $tids[$thread[tid]] $pid}-->
						<!--{eval $post = $posts[$pid];}-->
						<div class="tl_reply pbm xg1"><a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid" target="_blank"><!--{if $post[message]}-->{$post[message]}<!--{else}-->...<!--{/if}--></a></div>
						<!--{/loop}-->
					</td>
				</tr>
			</tbody>
			<tr><td colspan="6"></td></tr>
		<!--{/if}-->
		<!--{if $view == 'my' && $viewtype=='postcomment'}-->
			<tr>
				<td class="icn">&nbsp;</td>
				<td colspan="5" class="xg1">$thread[comment]</td>
			</tr>
		<!--{/if}-->
	<!--{/loop}-->
<!--{else}-->
	<tbody class="bw0_all"><tr><th colspan="5"><p class="emp">{lang guide_nothreads}</p></th></tr></tbody>
<!--{/if}-->