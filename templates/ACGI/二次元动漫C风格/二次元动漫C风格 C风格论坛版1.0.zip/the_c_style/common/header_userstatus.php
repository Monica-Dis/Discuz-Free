<?php echo ' ';exit;?>
<!--{if $_G['uid']}-->
	<div class="cnotice c_cp_icon y">
		<a href="home.php?mod=space&do=notice" id="myprompt" onmouseover="showMenu({'ctrlid':'myprompt'});">
			<i class="fa fa-bell-o"></i>
			<!--{if $_G['member']['newprompt']}--><em class="shan">$_G['member']['newprompt']</em><!--{/if}-->
		</a>
		<span id="myprompt_check"></span>
	</div>
	<div class="cmsg c_cp_icon y">
		<a href="home.php?mod=space&do=pm" id="pm_ntc" style="background-repeat: no-repeat; background-position: 0 50%;">
			<i class="fa fa-envelope-o"></i>
			<!--{if $_G['member']['newpm']}-->{eval loaducenter(); $newpmarr = uc_pm_checknew($_G['uid'], 1);}<em class="shan">$newpmarr['newpm']</em><!--{/if}-->
		</a>
	</div>
	<div class="cmy y">
		<a href="home.php?mod=space&uid=$_G[uid]" target="_blank" class="avr"><!--{avatar($_G[uid],big)}--></a>
		<div class="cmy_main">
			<div class="my_main cl">
				<p class="name">
					<a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}"><i class="fa fa-fw  fa-paw"></i><strong>{$_G[member][username]}</strong><a href="home.php?mod=spacecp&ac=usergroup" title="{$clang[group]}"> ($_G[group][grouptitle])</a>
				</p>
				<p class="sub z">
					<!--{eval}-->
						$i_ext = $_G[member][credits];
						$i_moy = DB::result(DB::query("SELECT extcredits2 FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]'"));
						if ($i_ext > 9999){
							$i_ext_w = $i_ext/10000;
							$i_ext_w = number_format($i_ext_w, 1, '.', '');
						}
						if ($i_moy > 9999){
							$i_moy_w = $i_moy/10000;
							$i_moy_w = number_format($i_moy_w, 1, '.', '');
						}
					<!--{/eval}-->
					<a href="home.php?mod=spacecp&ac=credit&showcredit=1" class="i_ext" title="{echo number_format({$i_ext})} {lang credits}">{if $i_ext > 9999}{$i_ext_w}w{else}{$i_ext}{/if}</a>
					<a href="home.php?mod=spacecp&ac=credit&showcredit=1" class="i_moy" title="{echo number_format({$i_moy})} {$_G[setting][extcredits][2][title]}">{if $i_moy > 9999}{$i_moy_w}w{else}{$i_moy}{/if}</a>
				</p>
				<p class="bind y">
					<a href="connect.php?mod=config" {if $_G['setting']['connect']['allow'] && $_G[member][conisbind]}class="bind_qq_1" title="{$clang[bindqq_1]}"{else}class="bind_qq_0" title="{$clang[bindqq_0]}"{/if}></a>
					<a href="home.php?mod=spacecp&ac=profile&op=password" class="bind_email_{$_G['member'][emailstatus]}" title="{if $_G['member'][emailstatus]}{$clang[email_1]}{else}{$clang[email_0]}{/if}"></a>
				</p>
			</div>
			<!--{if $_G['uid'] && $_G['group']['grouptype'] == 'member' && $_G['group']['groupcreditslower'] != '999999999'}-->
				<!--{eval}-->
						$upgradecredit=$_G['group']['groupcreditslower']-$_G['member']['credits'];
						$upgradeprogress=100-ceil($upgradecredit/($_G['group']['groupcreditslower']-$_G['group']['groupcreditshigher'])*100);
						$upgradeprogress=max($upgradeprogress,2);
						if ($upgradeprogress>90){$lv_ups=$clang['user_lv_uping_9'];}
						elseif ($upgradeprogress>70){$lv_ups=$clang['user_lv_uping_7'];}
						elseif ($upgradeprogress>50){$lv_ups=$clang['user_lv_uping_5'];}
						elseif ($upgradeprogress>30){$lv_ups=$clang['user_lv_uping_3'];}
						elseif ($upgradeprogress>10){$lv_ups=$clang['user_lv_uping_1'];}
						elseif ($upgradeprogress>0){$lv_ups=$clang['user_lv_uping_0'];}
						$lv_up=explode('||',$lv_ups);
						$lv_uping=$lv_up[(rand(0,count($lv_up)-1))];
				<!--{/eval}-->
				<div class="my_lv cl">
					<div class="lvs z">
						Lv{$_G['group']['stars']}
					</div>
					<div class="jdt y" title="{$lv_uping} {$clang[current]}: {$upgradeprogress}%">
						<p style="width:{$upgradeprogress}%;"></p>
					</div>
					<i class=" cl"></i>
					<div class="jfb">{$_G['member']['credits']}/{$_G['group']['groupcreditslower']}</div>
				</div>
			<!--{/if}-->
			<div class="line_x"></div>
			<div class="my_cp cl">
				<a href="forum.php?mod=guide&view=my" target="_blank" class="mypost"><i class="fa fa-fw fa-file-text-o"></i> {$clang[mypost]}</a>
				<a href="home.php?mod=space&do=favorite&view=me" target="_blank" class="myfavorite"><i class="fa fa-fw fa-heart"></i> {$clang[myfavorite]}</a>
				<a href="home.php?mod=space&do=friend" target="_blank" class="my_friends"><i class="fa fa-fw fa-users"></i> {$clang[my_friends]}</a>
				<a href="home.php?mod=spacecp&ac=avatar" target="_blank" class="upload_avatar"><i class="fa fa-fw fa-magic"></i> {$clang[modify_avatar]}</a>
				<!--{if $_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])}-->
					<a href="home.php?mod=task&item=doing" target="_blank" id="task_ntc" class="task_doing"><i class="fa fa-fw fa-exclamation-circle"></i> {lang task_doing}</a>
				<!--{/if}-->
				<!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
					<a href="portal.php?mod=portalcp" target="_blank" class="portal_manage"><i class="fa fa-fw fa-pie-chart"></i> <!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a>
				<!--{/if}-->
				<!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
					<a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank" class="forum_manager"><i class="fa fa-fw fa-puzzle-piece"></i> {lang forum_manager}</a>
				<!--{/if}-->
				<!--{if $_G['uid'] && $_G['adminid'] == 1 && $_G['setting']['cloud_status']}-->
					<a href="admin.php?frames=yes&action=cloud&operation=applist" target="_blank" class="cloudcp"><i class="fa fa-fw fa-cloud"></i> {lang cloudcp}</a>
				<!--{/if}-->
				<!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
					<a href="admin.php" target="_blank" class="admincp"><i class="fa fa-fw fa-th-large"></i> {lang admincp}</a>
				<!--{/if}-->
				<!--{if check_diy_perm($topic)}-->
					<a href="javascript:saveUserdata('diy_advance_mode', '1');openDiy();"><i class="fa fa-fw fa-wrench"></i> $clang['diynav']</a>
				<!--{/if}-->
				<!--{hook/global_usernav_extra1}-->
				<!--{hook/global_usernav_extra2}-->
				<!--{hook/global_usernav_extra4}-->
				<!--{hook/global_usernav_extra3}-->
			</div>
			<div class="cmy_main_btm cl">
				<a href="home.php?mod=spacecp" class="modify_data">{$clang[modify_data]}</a>
				<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="logout">{$clang[logout]}</a>
			</div>
		</div>
	</div>




<!--{elseif !empty($_G['cookie']['loginuser'])}-->
        <a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a>
        <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
        <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
<!--{elseif !$_G[connectguest]}-->
	<div class="c_cp_icon y cl">
		<a href="member.php?mod=logging&action=login" class="cbtn_lg" title="{lang login}"><i class="fa fa-unlock-alt"></i></a>
		<a href="member.php?mod={$_G[setting][regname]}" class="cbtn_sg" title="{$clang[register]}"><i class="fa fa-plus"></i></a>
		<a href="connect.php?mod=login&op=init&referer=index.php&statfrom=login_simple" target="_blank" class="cbtn_qq" title="{$clang[qqlogin]}"><i class="fa fa-qq"></i></a>
		<a href="plugin.php?id=wechat:login" target="_blank" class="cbtn_wx" title="{$clang[wxlogin]}"><i class="fa fa-weixin"></i></a>
	</div>
<!--{else}-->
		<!--{hook/global_usernav_extra1}-->
		<a class="vwmy qq">{$_G[member][username]}</a>
		<a>$_G[group][grouptitle]</a>
		<a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a>
		<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
<!--{/if}-->