<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$clang = array (
	'tz_author' => '�ӥD',
	'tz_lastreply' => '�̦Z�o��',
);


?>