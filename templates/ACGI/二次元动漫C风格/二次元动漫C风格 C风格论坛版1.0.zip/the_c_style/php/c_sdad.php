<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



$ad_gd=array(//广告1
	"portal.php||template/the_c_style/images/ext/hd1.jpg||（标题）固定广告测试1",
	"portal.php||template/the_c_style/images/ext/hd2.jpg||（标题）固定广告测试2",
	"portal.php||template/the_c_style/images/ext/hd3.jpg||（标题）固定广告测试3",
	"portal.php||template/the_c_style/images/ext/hd4.jpg||（标题）固定广告测试4"
);
$ad_sj1=array(
	"portal.php||template/the_c_style/images/ext/sj11.jpg||（标题）随机广告测试sj11",
	"portal.php||template/the_c_style/images/ext/sj12.jpg||（标题）随机广告测试sj11",
	"portal.php||template/the_c_style/images/ext/sj13.jpg||（标题）随机广告测试sj11",
	"portal.php||template/the_c_style/images/ext/sj14.jpg||（标题）随机广告测试sj11"
);
$ad_sj2=array(
	"portal.php||template/the_c_style/images/ext/sj21.jpg||（标题）随机广告测试sj21",
	"portal.php||template/the_c_style/images/ext/sj22.jpg||（标题）随机广告测试sj22",
	"portal.php||template/the_c_style/images/ext/sj23.jpg||（标题）随机广告测试sj23",
	"portal.php||template/the_c_style/images/ext/sj24.jpg||（标题）随机广告测试sj24"
);
$ad_sj3=array(
	"portal.php||template/the_c_style/images/ext/hd1.jpg||（标题）随机广告测试sj31",
	"portal.php||template/the_c_style/images/ext/hd2.jpg||（标题）随机广告测试sj32",
	"portal.php||template/the_c_style/images/ext/hd3.jpg||（标题）随机广告测试sj33",
	"portal.php||template/the_c_style/images/ext/hd4.jpg||（标题）随机广告测试sj34"
);
$ad_sj4=array(
	"portal.php||template/the_c_style/images/ext/hd1.jpg||（标题）随机广告测试sj41",
	"portal.php||template/the_c_style/images/ext/hd2.jpg||（标题）随机广告测试sj42",
	"portal.php||template/the_c_style/images/ext/hd3.jpg||（标题）随机广告测试sj43",
	"portal.php||template/the_c_style/images/ext/hd4.jpg||（标题）随机广告测试sj44"
);
$ad_sj5=array(
	"portal.php||template/the_c_style/images/ext/hd1.jpg||（标题）随机广告测试sj51",
	"portal.php||template/the_c_style/images/ext/hd2.jpg||（标题）随机广告测试sj52",
	"portal.php||template/the_c_style/images/ext/hd3.jpg||（标题）随机广告测试sj53",
	"portal.php||template/the_c_style/images/ext/hd4.jpg||（标题）随机广告测试sj54"
);

$gdad1=explode('||', $ad_gd[0]);
$gdad2=explode('||', $ad_gd[1]);
$gdad3=explode('||', $ad_gd[2]);
$gdad4=explode('||', $ad_gd[3]);

$sjad1=explode('||', $ad_sj1[(rand(0,count($ad_sj1)-1))]);
$sjad2=explode('||', $ad_sj2[(rand(0,count($ad_sj2)-1))]);
$sjad3=explode('||', $ad_sj3[(rand(0,count($ad_sj3)-1))]);
$sjad4=explode('||', $ad_sj4[( rand(0,count($ad_sj4)-1))]);
$sjad5=explode('||', $ad_sj5[(rand(0,count($ad_sj5)-1))]);


?>