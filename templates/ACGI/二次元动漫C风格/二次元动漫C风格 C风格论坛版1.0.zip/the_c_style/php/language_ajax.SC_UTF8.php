<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$clang = array (
	'tz_author' => '楼主',
	'tz_lastreply' => '最后发表',
);

?>