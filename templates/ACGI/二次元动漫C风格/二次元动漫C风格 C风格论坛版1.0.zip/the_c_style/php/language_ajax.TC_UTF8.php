<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: 应用更新支持：https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$clang = array (
	'tz_author' => '樓主',
	'tz_lastreply' => '最后發表',
);


?>