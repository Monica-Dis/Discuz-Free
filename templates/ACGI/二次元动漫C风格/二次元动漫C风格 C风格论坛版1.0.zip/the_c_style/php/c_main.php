<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: Ӧ�ø���֧�֣�https://dism.taobao.com.
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


if ($_G['basescript'] == 'forum' && $_GET['c'] == 'news') {

	if ($cset['lines']>60) {$cset['lines']=60;}
	else if($cset['lines']<1) {$cset['lines']=1;}

	$threadlists=array();
	if ($_G['uid']) {
		$user_info = getuserbyuid($_G['uid']);
		$user_readaccess = DB::result_first("SELECT `readaccess` FROM ".DB::table('common_usergroup_field')." WHERE groupid=$user_info[groupid]");
	}else{
		$user_info['adminid'] = 0;
		$user_readaccess = 0;
	}
	//ca begin
		require_once libfile('function/post');
		$cthreads=DB::fetch_all("SELECT t.tid, t.fid, t.readperm, t.price, t.author, t.authorid, t.subject, t.dateline, t.lastpost, t.lastposter, t.views, t.replies, t.displayorder, t.digest, t.attachment, t.replycredit, p.pid, p.message, p.tags, f.name FROM ".DB::table("forum_thread")." t LEFT JOIN ".DB::table("forum_post")." p on p.tid=t.tid LEFT JOIN ".DB::table("forum_forum")." f on f.fid=t.fid WHERE t.fid NOT in ($cset[fids]) and t.displayorder>=0 and p.first=1 group by t.tid ORDER BY t.dateline DESC LIMIT 0 , $cset[lines]");

		foreach ($cthreads as $key => $value) {
			$priceaids=$hideaids=$picsub=array();
			if ($value['price'] > 0) {
				$pricein = preg_replace("/\[free[^\]]*\](.*)\[\/free]/isU",'',$value['message']);
				preg_match("/\[free[^\]]*\](.*)\[\/free]/isU",$value['message'],$cfree);
				$value['message']=$cfree[1];
				preg_match_all('/\[attach\](\d{1,})\[\/attach\]/', $pricein , $priceaids);
			};
			preg_match("/\[hide[^\]]*\](.*)\[\/hide]/isU",$value['message'],$chide);
			preg_match_all('/\[attach\](\d{1,})\[\/attach\]/', $chide[1] , $hideaids);
			$value['message']=dhtmlspecialchars($value['message']);
			$value['message']=cutstr($value['message'],$cset['mn_smylength'],'');
			$value['priceaids']=$priceaids[1];
			$value['hideaids']=$hideaids[1];
			if ($value['attachment'] == 2){
				$picsub = DB::fetch_all("SELECT `aid`,`tid`,`description`,`filename`,`remote`,`attachment`,`readperm`,`price` FROM ".DB::table('forum_attachment_'.substr($value['tid'], -1))." WHERE tid='$value[tid]' AND width >= 150 ORDER BY `dateline` ASC LIMIT 0,8");
				$value['picsub']=$picsub;
				$value['pic_count']=count($picsub);
			};
			$value['tags'] = array_filter(explode("	", $value['tags']));
			$threadlists[$key]=$value;
		}
	//ca end

} elseif ($_G['basescript'] == 'forum' && CURMODULE == 'viewthread' || $_G['basescript'] == 'group' && CURMODULE == 'viewthread') {
	$navigation = str_replace("&rsaquo;","&gt;",$navigation);
	$avatar_css='';
	if (!$close_leftinfo) {
		if ($cset['avatar_w']>120){
			if ($cset['avatar_w']>200){
				$cset['avatar_w']=200;
			}
			$pls_w=$cset['avatar_w']+40;
			$bui_w=430+($cset['avatar_w']-120);
			$piaor_w=$cset[avatar_w]-30;
			$avatar_css='<style>.pls{width:'.$pls_w.'px;}.pls .avatar img{width:'.$cset[avatar_w].'px;}.bui{width:'.$bui_w.'px !important;}.bui .m img{width:'.$cset[avatar_w].'px;}.piaor{max-width:'.$piaor_w.'px;}</style>';
		}
	}
}







?>