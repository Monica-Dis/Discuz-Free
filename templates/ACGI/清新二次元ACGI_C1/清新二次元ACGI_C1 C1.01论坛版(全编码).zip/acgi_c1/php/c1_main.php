<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$i_ext = $_G[member][credits];
$i_moy = DB::result(DB::query("SELECT extcredits2 FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]'"));
if ($i_ext > 9999){
	$i_ext_w = $i_ext/10000;
	$i_ext_w = number_format($i_ext_w, 1, '.', '');
}
if ($i_moy > 9999){
	$i_moy_w = $i_moy/10000;
	$i_moy_w = number_format($i_moy_w, 1, '.', '');
}

$tagallnum=80;
$tagnum=40;
$tagCbegin=60;
$tagCend=200;
$tag_query=C::t('common_tag')->fetch_all_by_status($_GET[status], '', $tagallnum, 0, 0, 'DESC');
shuffle($tag_query);

$r_postsnum=20;
$r_posts=DB::fetch_all("select * FROM ".DB::table('forum_post')."   WHERE `subject`=  '' ORDER BY `dateline` DESC LIMIT 0,$r_postsnum");



if ($_G['basescript'] == 'forum' && CURMODULE == 'index'){
	$fids='0,1';
	$lines=10;
	$begin=($_G['page']-1)*$lines;$threadlists=array();require_once libfile('function/post');$c1threads=DB::query("SELECT t.*,p.message,p.pid,f.name FROM ".DB::table("forum_thread")." t LEFT JOIN ".DB::table("forum_post")." p on p.tid=t.tid LEFT JOIN ".DB::table("forum_forum")." f on f.fid=t.fid WHERE t.fid NOT in ($fids) and t.displayorder>=0 and p.first=1 group by t.tid ORDER BY t.dateline DESC LIMIT $begin , $lines");
	while ($smy=DB::fetch($c1threads)) {$threadlists[]=$smy;}
	$alllines=DB::result_first("select count(*) from ".DB::table("forum_thread")." where fid NOT in ($fids) and displayorder>=0");
	$pagenav=multi($alllines,$lines,$_G['page'],"forum.php#mn_news");
}elseif ($_G['basescript'] == 'forum' && CURMODULE == 'viewthread'){
	$avatar_css='';
	if ($c1set[avatar_w]>120){
		if ($c1set[avatar_w]>200){
			$c1set[avatar_w]=200;
		}
		$pls_w=$c1set[avatar_w]+40;
		$bui_w=430+($c1set[avatar_w]-120);
		$avatar_css='<style>.pls{width:'.$pls_w.'px;}.pls .avatar img{width:'.$c1set[avatar_w].'px;}.bui{width:'.$bui_w.'px !important;}.bui .m img{width:'.$c1set[avatar_w].'px;}</style>';
	}

}



$servername = str_replace('www.','',trim($_SERVER['SERVER_NAME']));

$c_verify_key = 'c_verifykey_'.str_replace('.','_',$servername);


if (!empty($_COOKIE[$c_verify_key])){
	$c_verify=$_COOKIE[$c_verify_key];
	//echo $c_verify;
}else{
	$opts = array(
		'http'=>array(
			'method'=>"GET",
			'timeout'=>2,
		)
	);
	$c_server_url = 'http://activation.acgc.vip/cb_c1.php?domain=[c1]luhan.info||'.$servername;
	$c_verify = file_get_contents($c_server_url, false, stream_context_create($opts));

	if(!empty($c_verify)){
		if($c_verify==1){
			//echo $c_verify;
			setcookie($c_verify_key,"1",time()+1*24*3600);//1*24*3600
		}else{
			echo $c_verify;
			die();
		}
	}else{
		setcookie($c_verify_key,"1",time()+1*3600);//12*3600
		//echo '2';
	}
}



?>