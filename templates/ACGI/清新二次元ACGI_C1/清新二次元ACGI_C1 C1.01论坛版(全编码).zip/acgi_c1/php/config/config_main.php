<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$c1set = array (
	// c1scrolltop //
	'show_app' => 1,
	'show_wx' => 1,
	'show_kf' => 1,
	'avatar_w' => 120, //120~200
);

?>
