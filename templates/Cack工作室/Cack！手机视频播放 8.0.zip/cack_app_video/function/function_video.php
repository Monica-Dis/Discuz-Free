<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function threadvideo($url) {
	global $_G;
	$cack = $_G['cache']['plugin']['cack_app_video'];
	$height = $cack['pcheight'];
	$width = $cack['pcwidth']?$cack['pcwidth']:'100%';
	$url=$url[2];
	//$ifurl = strtolower($url);
	$ifurl = $url;
	if (strpos($ifurl, 'v.youku.com/v_show/') !== FALSE) {
		if (preg_match("/[https|http]:\/\/v.youku.com\/v_show\/id_([^\/]+)(.html?)/i", $url, $arr)) {
			$src = 'https://player.youku.com/embed/'.$arr[1].'==';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" frameborder="0" allowfullscreen></iframe>';
		}
	}
	if (strpos($ifurl, 'www.youtube.com/watch') !== FALSE) {
		if (preg_match("/https:\/\/www.youtube.com\/watch\?v=([^\/]+)/i", $url, $arr)) {
			$src = 'https://www.youtube.com/embed/'.$arr[1];
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	if (strpos($ifurl, 'v.qq.com/x/') !== FALSE) {
		if (preg_match("/https:\/\/v.qq.com\/x\/page\/([^\/]+)(.html?)/i", $url, $arr)) {
			$src = 'https://v.qq.com/iframe/player.html?vid='.$arr[1].'&tiny=0&auto=0';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	if (strpos($ifurl, 'www.bilibili.com/video/') !== FALSE) {
		if (preg_match("/https:\/\/www.bilibili.com\/video\/av([^(\/|\?)]+)/i", $url, $arr)) {
			$src = 'https://player.bilibili.com/player.html?aid='.$arr[1].'';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
		if (preg_match("/https:\/\/www.bilibili.com\/video\/BV([^(\/|\?)]+)/i", $url, $arr)) {
			$src = 'https://player.bilibili.com/player.html?bvid=BV'.$arr[1].'';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	if (strpos($ifurl, '.mp4') !== FALSE) {
		return '<video controls="" autoplay="" name="media" style="max-width: 100%;"><source src="'.$ifurl.'" type="video/mp4"></video>';
	}
	if (strpos($ifurl, '.mp3') !== FALSE) {
		return '<audio controls="controls" src="'.$ifurl.'"></audio>';
	}
	if (!$return) {
		if($cack['spms']){
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$ifurl.'" allowfullscreen frameborder="0"></iframe>';
		}else{
			return '<a href="'.$ifurl.'">'.$ifurl.'</a>';
		}
	}
}
//From: Dism_taobao_com
?>