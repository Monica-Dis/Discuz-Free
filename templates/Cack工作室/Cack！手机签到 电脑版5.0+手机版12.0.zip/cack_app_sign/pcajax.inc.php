<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G[uid]){
	header("Location: member.php?mod=logging&action=login");
}
include_once libfile('function/member');
include 'source/plugin/cack_app_sign/lang/'.currentlang().'.php';
$cacksign = $_G['cache']['plugin']['cack_app_sign'];
$navtitle = $cacksign['navtitle'];
$xsqdsl = intval($cacksign['xsqdsl']);

$xinqingquery = DB::query("SELECT * FROM ".DB::table('cack_app_sign_xinqing')." order by displayorder asc");
while($cack = DB::fetch($xinqingquery)) {
	$xinqingquerysc[] = $cack;
	$xinqing[$cack[xid]][pic] = $cack[pic];
}

$qdlogquery = DB::query("SELECT * FROM ".DB::table('cack_app_sign_log')." where signtime>".strtotime(date('Ymd',time()))." order by signtime asc");
while($cack = DB::fetch($qdlogquery)) {
	$yhyji = $yhyji+1;
	$jrqdlogsc[] = $cack;
	if($cack[uid] == $_G[uid]){
		$yhyjqd = '1';
		$yhyjqdsx = $yhyji;
	}
}
include template('cack_app_sign:ajax_sign');
?>