<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if(!$_G[uid]){
	header("Location: member.php?mod=logging&action=login");
}
include_once libfile('function/member');
include 'source/plugin/cack_app_sign/lang/'.currentlang().'.php';
$cacksign = $_G['cache']['plugin']['cack_app_sign'];
$navtitle = $cacksign['navtitle'];
$xsqdsl = intval($cacksign['xsqdsl']);
$jftype = $cacksign['jfsz'];
$jftypes = $_G['setting']['extcredits'][$jftype]['title'];


$xinqingquery = DB::query("SELECT * FROM ".DB::table('cack_app_sign_xinqing')." order by displayorder asc");
while($cack = DB::fetch($xinqingquery)) {
	$xinqingquerysc[] = $cack;
	$xinqing[$cack[xid]][pic] = $cack[pic];
}

$qdlogquery = DB::query("SELECT * FROM ".DB::table('cack_app_sign_log')." where signtime>".strtotime(date('Ymd',time()))." order by signtime asc");
while($cack = DB::fetch($qdlogquery)) {
	$yhyji = $yhyji+1;
	$jrqdlogsc[] = $cack;
	if($cack[uid] == $_G[uid]){
		$yhyjqd = '1';
		$yhyjqdsx = $yhyji;
	}
}
if($_GET[cmod] == 'lxqd'){
	$lxqdlogsquery = DB::query("SELECT * FROM ".DB::table('cack_app_sign_logs')." where id>0 order by lianxu desc LIMIT 0,".$xsqdsl);
	while($cack = DB::fetch($lxqdlogsquery)) {
		$lxqduidarr[] = $cack;
	}
}

if($_GET[cmod] == 'lsqd'){
	$ljqdlogsquery = DB::query("SELECT * FROM ".DB::table('cack_app_sign_logs')." where id>0 order by leiji desc LIMIT 0,".$xsqdsl);
	while($cack = DB::fetch($ljqdlogsquery)) {
		$ljqduidarr[] = $cack;
	}
}
if($_GET[cmod] == 'home'){
	$wdqdlogsquery = DB::query("SELECT * FROM ".DB::table('cack_app_sign_log')." where uid=".$_G[uid]." order by signtime desc LIMIT 0,".$xsqdsl);
	while($cack = DB::fetch($wdqdlogsquery)) {
		$wdqduidarr[] = $cack;
	}
}
	
include template('cack_app_sign:sign');
?>