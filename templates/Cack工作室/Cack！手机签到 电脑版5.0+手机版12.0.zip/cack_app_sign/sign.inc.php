<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include 'source/plugin/cack_app_sign/lang/'.currentlang().'.php';
$cacksign = $_G['cache']['plugin']['cack_app_sign'];
$ewqdjf = explode ("\n", str_replace ("\r", "", $cacksign['ewqdjf']));
$signjifen = mt_rand($cacksign['zsjljf'],$cacksign['zdjljf']);
$signlog = DB::fetch_all("SELECT * FROM %t where signtime>".strtotime(date('Ymd',time()))." ORDER BY signtime LIMIT 30", array("cack_app_sign_log"));
		foreach($ewqdjf as $key=>$value){
			$ewqdjfarr=explode('=',$value);
			if($ewqdjfarr[0] == count($signlog) + '1'){
				$ewqdjfz=$ewqdjfarr[1];
			}
		}
$signjifen = $ewqdjfz + $signjifen;


if($_G[uid]){
	$qdlogquery = DB::query("SELECT * FROM ".DB::table('cack_app_sign_log')." where uid=".$_G[uid]." order by signtime desc LIMIT 1");
	while($cack = DB::fetch($qdlogquery)) {
		$qdlogsc[] = $cack;
	}
    if ($_GET['signxid'] && $_GET[formhash] == FORMHASH && date('Ymd',$qdlogsc[0][signtime]) !=  date('Ymd',time())) {
            $qdlogsquery = DB::fetch_all("SELECT * FROM ".DB::table('cack_app_sign_logs')." where uid=".$_G[uid]." order by id desc LIMIT 1");
			DB::insert('cack_app_sign_log', array('uid' => $_G[uid], 'username' => $_G[member][username], 'signtime' =>time(), 'xid' => intval($_GET['signxid']), 'extcredits' => $cacksign['jfsz'], 'jifen' => $signjifen, 'content' => dhtmlspecialchars(substr($_GET['content'],'0','160'))));
			if(!$qdlogsquery){
				DB::insert('cack_app_sign_logs', array('uid' => $_G[uid], 'leiji' => '1', 'lianxu' => '1', 'signtime' =>time(), 'xid' => intval($_GET['signxid']), 'username' => $_G[member][username]));
			}else{
				if(date('Ymd',$qdlogsc[0][signtime]+'86400') ==  date('Ymd',time())){
					DB::update('cack_app_sign_logs', array('lianxu' => $qdlogsquery['0']['lianxu']+'1', 'leiji' => $qdlogsquery['0']['leiji']+'1', 'username' => $_G[member][username], 'signtime' =>time(), 'xid' => intval($_GET['signxid'])), array('uid'=>$_G[uid]));
				}else{
					DB::update('cack_app_sign_logs', array('lianxu' => '1', 'leiji' => $qdlogsquery['0']['leiji']+'1', 'username' => $_G[member][username], 'signtime' =>time(), 'xid' => intval($_GET['signxid'])), array('uid'=>$_G[uid]));
				}
			}
			updatemembercount($_G['uid'], array($cacksign['jfsz'] => $signjifen),true,'','',$signlang['4'].$signcplang['5'],$signlang['4'].$signcplang['5'],$signlang['4'].$signcplang['5']);
		if ($_GET['pcsign']) {
			showmessage($signlang[1], 'index.php');
		}else{
			header("Location: plugin.php?id=cack_app_sign");
		}
	}else{
		showmessage($signlang[2], 'plugin.php?id=cack_app_sign');	
    }
}else{
	header("Location: member.php?mod=logging&action=login");
}
//From: Dism��taobao��com
?>