<?php
//Cack工作室技术支持
//20190715
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



if($_GET['c_ac'] == 'kaifa'){
	echo "<iframe src='https://dism.taobao.com?ac=kaifa' width='1100' height='600' style='border: 0px;'  frameborder='1/0'  scrolling='yes/no/auto'></iframe>";
}elseif($_GET['c_ac'] == 'zhichi'){
	echo "<iframe src='https://dism.taobao.com/?addon/fuwu.html' width='1100' height='800' style='border: 0px;'  frameborder='1/0'  scrolling='yes/no/auto'></iframe>";
}elseif($_GET['c_ac'] == 'bug'){
	echo "<iframe src='https://dism.taobao.com?ac=bug&host=".$_SERVER['HTTP_HOST']."&version=".$plugin['version']."&identifier=".$plugin['identifier']."' width='1100' height='800' style='border: 0px;'  frameborder='1/0'  scrolling='yes/no/auto'></iframe>";
}elseif($_GET['c_ac'] == 'addons'){
	echo "<div style='position: relative;'><iframe src='https://dism.taobao.com?ac=addons' width='1100' height='860' style='border: 0px;position: absolute;top: -60px;'  frameborder='1/0'  scrolling='yes/no/auto'></iframe></div>";
}elseif($_GET['c_ac'] == 'xinyue'){
	$website_url = 'https://dism.taobao.com/?';
	$gethtmlurl = $website_url.'addon.php?siteid='.$_G['setting']['siteuniqueid'];
	$gethtml = dfsockopen($gethtmlurl,0,'','',false,'',60);
	echo $gethtml;
}




?>