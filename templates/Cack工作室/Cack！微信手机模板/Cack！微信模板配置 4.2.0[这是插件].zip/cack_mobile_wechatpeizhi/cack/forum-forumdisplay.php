<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/post');
function threadvideo($url) {
	global $_G;
	$cack = $_G['cache']['plugin']['cack_guide_n2'];
	$height = $cack['height'];
	$width = $cack['width']?$cack['width']:'100%';
	$url=$url[2];
	$ifurl = strtolower($url);
	if (strpos($ifurl, 'v.qq.com/x/') !== FALSE) {
		if (preg_match("/https:\/\/v.qq.com\/x\/page\/([^\/]+)(.html?)/i", $url, $arr)) {
			$src = 'https://v.qq.com/iframe/player.html?vid='.$arr[1].'&auto=0';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	if (strpos($ifurl, 'www.bilibili.com/video/') !== FALSE) {
		if (preg_match("/https:\/\/www.bilibili.com\/video\/av([^\/]+)\//i", $url, $arr)) {
			$src = 'https://player.bilibili.com/player.html?aid='.$arr[1].'&page=1';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	if (strpos($ifurl, '.mp3') !== FALSE) {
		return '<audio controls="controls" src="'.$ifurl.'"></audio>';
	}
	if (!$return) {
		if($cack['spms'] && !strpos($ifurl, '.swf')){
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$ifurl.'" allowfullscreen frameborder="0"></iframe>';
		}else{
			return '<a href="'.$ifurl.'">'.$ifurl.'</a>';
		}
	}
}
	function cackisimage($tid,$aid){
		$table='forum_attachment_'.substr($tid, -1);
		$query = DB::fetch_all("SELECT * FROM ".DB::table($table)." WHERE aid = $aid AND isimage!=0 ORDER BY `dateline` ASC");
		while($thread = DB::fetch($query_forum_attachment)){
			$post_pic_aidarr[] = $thread[aid];
		}
		if($query){
			$query = '1';
		}else{
			$query = '0';
		}
		return $query;
	}
if($_G['forum_threadlist']){
	foreach($_G['forum_threadlist'] as $a){
		$tidarr[]=$a['tid'];
	}
$tids=implode(',',$tidarr);
$authorids=implode(',',$authoridarr);
$query_forum_attachment=DB::query("SELECT * FROM ".DB::table('forum_attachment')." WHERE tid IN($tids) ORDER BY aid desc ") ; 
	while($thread = DB::fetch($query_forum_attachment)){
			if(cackisimage($thread[tid],$thread[aid]) == '1'){
				$post_pic[$thread[tid]][] = $thread;
			}
	}
$postsql =  DB::fetch_all('SELECT * FROM '.DB::table('forum_post').' WHERE first= 1 and  tid IN('.$tids.')  order by tid desc ' );
foreach($postsql as $post){
	if (preg_match("/\[media(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", $post['message'], $arr)) {
		if(!$post_video[$post[tid]]){
			$post_video[$post[tid]] = threadvideo($arr);
		}
	}
}
}
//From: Dism_taobao-com
?>