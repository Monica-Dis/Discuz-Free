<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/post');
	function cackisimage($tid,$aid){
		$table='forum_attachment_'.substr($tid, -1);
		$query = DB::fetch_all("SELECT * FROM ".DB::table($table)." WHERE aid = $aid AND isimage!=0 ORDER BY `dateline` ASC");
		while($thread = DB::fetch($query_forum_attachment)){
			$post_pic_aidarr[] = $thread[aid];
		}
		if($query){
			$query = '1';
		}else{
			$query = '0';
		}
		return $query;
	}
function threadvideowechat($url) {
	global $_G;
	$cack = $_G['cache']['plugin']['cack_mobile_wechatpeizhi'];
	$height = $cack['pyqlbspgd'];
	$width = $cack['pyqlbspkd']?$cack['pyqlbspkd']:'100%';
	$url=$url[2];
	$ifurl = strtolower($url);
	if (strpos($ifurl, 'v.youku.com/v_show/') !== FALSE) {
		if (preg_match("/[https|http]:\/\/v.youku.com\/v_show\/id_([^\/]+)(.html?)/i", $url, $arr)) {
			$src = 'https://player.youku.com/embed/'.$arr[1];
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" frameborder="0" allowfullscreen></iframe>';
		}
	}
	if (strpos($ifurl, 'www.youtube.com/watch') !== FALSE) {
		if (preg_match("/https:\/\/www.youtube.com\/watch\?v=([^\/]+)/i", $url, $arr)) {
			$src = 'https://www.youtube.com/embed/'.$arr[1];
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	if (strpos($ifurl, 'v.qq.com/x/') !== FALSE) {
		if (preg_match("/https:\/\/v.qq.com\/x\/page\/([^\/]+)(.html?)/i", $url, $arr)) {
			$src = 'https://v.qq.com/iframe/player.html?vid='.$arr[1].'&auto=0';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	if (strpos($ifurl, 'www.bilibili.com/video/') !== FALSE) {
		if (preg_match("/https:\/\/www.bilibili.com\/video\/av([^\/]+)/i", $url, $arr)) {
			$src = 'https://player.bilibili.com/player.html?aid='.$arr[1].'&page=1';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	if (strpos($ifurl, '.mp4') !== FALSE) {
		return '<video controls="" autoplay="" name="media" style="max-width: 100%;"><source src="'.$ifurl.'" type="video/mp4"></video>';
	}
	if (strpos($ifurl, '.mp3') !== FALSE) {
		return '<audio controls="controls" src="'.$ifurl.'"></audio>';
	}
	if (!$return) {
		if($cack['spms'] && !strpos($ifurl, '.swf')){
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$ifurl.'" allowfullscreen frameborder="0"></iframe>';
		}else{
			return '<a href="'.$ifurl.'">'.$ifurl.'</a>';
		}
	}
}

if($pyqbdbksc){
	foreach($pyqbdbksc as $a){
		$tidarr[]=$a['tid'];
		$authoridarr[]=$a['authorid'];
	}
$tids=implode(',',$tidarr);
$authorids=implode(',',$authoridarr);
$query_forum_attachment=DB::query("SELECT * FROM ".DB::table('forum_attachment')." WHERE tid IN($tids) ORDER BY aid desc ") ; 
	while($thread = DB::fetch($query_forum_attachment)){
			if(cackisimage($thread[tid],$thread[aid]) == '1'){
				$post_pic[$thread[tid]][] = $thread;
			}
	}
$query_member_profile=DB::query("SELECT * FROM ".DB::table('common_member_profile')." WHERE uid IN($authorids) ORDER BY uid desc ") ; 
	while($cack = DB::fetch($query_member_profile)){
		$post_profile[$cack[uid]] = $cack;
	}
$query_forum_post=DB::query("SELECT * FROM ".DB::table('forum_post')." WHERE tid IN($tids) order by pid desc") ; 
	while($cack = DB::fetch($query_forum_post)){
		if($cack['first'] == '1' && $cack['invisible'] == '0'){
		$post_count[$cack[tid]]=$cack;
		}
		if($cack['first'] == '0' && $cack['invisible'] == '0'){
		$post_liforum[$cack[tid]][] = $cack;
		}
		if (preg_match("/\[media(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", $cack['message'], $arr) && $_G['cache']['plugin']['cack_mobile_wechatpeizhi']['pyqlbspjx']) {
			if(!$post_video[$cack[tid]]){
				$post_video[$cack[tid]] = threadvideowechat($arr);
			}
		}
	}
$query_recommendli=DB::query("SELECT * FROM ".DB::table('forum_memberrecommend')." WHERE tid IN($tids) order by dateline desc") ; 
	while($cack = DB::fetch($query_recommendli)){
		$post_recommendli[$cack[tid]][] = $cack;
	}

}
//From: Dism_taobao-com
?>