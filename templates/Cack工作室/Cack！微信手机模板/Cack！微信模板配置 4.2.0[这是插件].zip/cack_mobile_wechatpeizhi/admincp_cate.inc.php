<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include 'source/plugin/cack_mobile_wechatpeizhi/lang/'.currentlang().'.php';
$operation = $_GET['operation'];
if($operation == 'del') {
  if ($_GET['formhash'] == FORMHASH) {
	$lid = intval($_GET['lid']);
	if($lid) {
		$upcid = DB::result_first("SELECT upid FROM ".DB::table('cack_mobile_wechatpeizhi_cate')." WHERE id='$lid'");
		if($upcid) {
			$subid = DB::result_first("SELECT subid FROM ".DB::table('cack_mobile_wechatpeizhi_cate')." WHERE id='$upcid'");
			$subarr = explode(",", $subid);
			foreach($subarr as $key=>$value) {
				if($value == $lid) {
					unset($subarr[$key]);
					break;
				}
			}
			DB::query("UPDATE ".DB::table('cack_mobile_wechatpeizhi_cate')." SET subid='".implode(",", $subarr)."' WHERE id='$upcid'");
		}
		DB::query("DELETE FROM ".DB::table('cack_mobile_wechatpeizhi_cate')." WHERE id='$lid'");
	}
	cack_mobile_wechatpeizhi_updatacache();
	cpmsg($admincplang[8], 'action=plugins&operation=config&identifier=cack_mobile_wechatpeizhi&pmod=admincp_cate', 'succeed');	
  }
}
if(!submitcheck('editsubmit')) {
?>
<script type="text/JavaScript">
var rowtypedata = [
	[[1,'<input type="text" class="txt" name="newlocalorder[]" value="0" />', 'td25'], [2, '<input name="newlocal[]" value="" size="20" type="text" class="txt" />']],
	[[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div class="board"><input name="newsublocal[{1}][]" value="" size="20" type="text" class="txt"  placeholder="&#26631;&#39064;"/><input name="newpic[{1}][]" value="" size="20" type="text" class="txt" placeholder="&#22270;&#29255;&#22320;&#22336;" /><input name="newurl[{1}][]" value="" size="20" type="text" class="txt" placeholder="&#38142;&#25509;"/></div>']],
	];
</script>
<?php
	showformheader('plugins&operation=config&identifier=cack_mobile_wechatpeizhi&pmod=admincp_cate');
	showtableheader('');
	showsubtitle(array('display_order',$admincplang[2],$admincplang[18]));
	$cack_mobile_wechatpeizhi_cate = array();
	$query = DB::query("SELECT * FROM ".DB::table('cack_mobile_wechatpeizhi_cate')." WHERE upid='0' ORDER BY displayorder DESC");
	while($row = DB::fetch($query)) {
		$cack_mobile_wechatpeizhi_cate[$row['id']] = $row;
		$squery = DB::query("SELECT * FROM ".DB::table('cack_mobile_wechatpeizhi_cate')." WHERE upid='$row[id]' ORDER BY displayorder DESC");
		while($srow = DB::fetch($squery)) {
			$cack_mobile_wechatpeizhi_cate[$row['id']]['sublocal'][$srow['id']] = $srow;
		}
	}
	if($cack_mobile_wechatpeizhi_cate) {
		foreach($cack_mobile_wechatpeizhi_cate as $id=>$local) {
			$show = '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$id.']" value="'.$local['displayorder'].'" /></td><td><div class="parentboard"><input type="text" class="txt" name="name['.$id.']" value="'.$local['subject'].'"></div></td>';
			if(!$local['subid']) {
				$show .= '<td><a onclick="del('.$id.')" href="?action=plugins&operation=config&identifier=cack_mobile_wechatpeizhi&pmod=admincp_cate&operation=del&formhash='.FORMHASH.'&lid='.$id.'">'.$admincplang[5].'</td></tr>';
			} else {
				$show .= '<td>&nbsp;</td></tr>';
			}
			echo $show;
			if($local['sublocal']) {
				foreach($local['sublocal'] as $subid=>$slocal) {
					echo '<tr class="hover"><td class="td25"><input type="text" class="txt" name="order['.$subid.']" value="'.$slocal['displayorder'].'" /></td><td><div class="board"><input type="text" class="txt" name="name['.$subid.']" value="'.$slocal['subject'].'"  placeholder="&#26631;&#39064;"><input type="text" class="txt" name="pic['.$subid.']" value="'.$slocal['pic'].'" placeholder="&#22270;&#29255;&#22320;&#22336;"><input type="text" class="txt" name="url['.$subid.']" value="'.$slocal['url'].'" placeholder="&#38142;&#25509;"></div></td><td><a  onclick="del('.$subid.')" href="?action=plugins&operation=config&identifier=cack_mobile_wechatpeizhi&pmod=admincp_cate&operation=del&formhash='.FORMHASH.'&lid='.$slocal['id'].'">'.$admincplang[5].'</td></tr>';
				}
			}
			echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div class="lastboard"><a href="###" onclick="addrow(this, 1,'.$id.' )" class="addtr">'.$admincplang[14].'</a></div></td></tr>';
		}	
	}
	echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.$admincplang[17].'</a></div></td></tr>';
	showsubmit('editsubmit');
	showtablefooter();/*Dism_taobao-com*/
	showformfooter();
} else {
	$order = $_GET['order'];
	$name = $_GET['name'];
	$url = $_GET['url'];
	$pic = $_GET['pic'];
	$newsublocal = $_GET['newsublocal'];
	$newlocal = $_GET['newlocal'];
	$newsuborder = $_GET['newsuborder'];
	$newlocalorder = $_GET['newlocalorder'];
	$newurl = $_GET['newurl'];
	$newpic = $_GET['newpic'];
	if(is_array($order)) {
		foreach($order as $id=>$value) {
			DB::update('cack_mobile_wechatpeizhi_cate', array('displayorder' => intval($order[$id]), 'subject' => daddslashes($name[$id]), 'pic' => daddslashes($pic[$id]), 'url' => daddslashes($url[$id])), "id='$id'");
		}
	}
	if(is_array($newlocal)) {
		foreach($newlocal as $key=>$name) {
			if(empty($name)) {
				continue;
			}
			$cid = DB::insert('cack_mobile_wechatpeizhi_cate', array('upid' => '0', 'subject' => daddslashes($name), 'displayorder' => intval($newlocalorder[$key]), 'pic' => daddslashes($newpic[$key]), 'url' => daddslashes($newurl[$key])), 1);
		}
	}
	if(is_array($newsublocal)) {
		foreach($newsublocal as $cid=>$sublocal) {
			$subtype = DB::result_first("SELECT subid FROM ".DB::table('cack_mobile_wechatpeizhi_cate')." WHERE id='$cid'");
			foreach($sublocal as $key=>$name) {
				$subid = DB::insert('cack_mobile_wechatpeizhi_cate', array('upid' => $cid, 'subject' => daddslashes($name), 'displayorder' => intval($newsuborder[$cid][$key]), 'pic' => daddslashes($newpic[$cid][$key]), 'url' => daddslashes($newurl[$cid][$key])), 1);
				$subtype .= $subtype ? ','.$subid : $subid;
			}
			DB::query("UPDATE ".DB::table('cack_mobile_wechatpeizhi_cate')." SET subid='$subtype' WHERE id='$cid'");
		}
	}
	cack_mobile_wechatpeizhi_updatacache();
	cpmsg($admincplang[7], 'action=plugins&operation=config&identifier=cack_mobile_wechatpeizhi&pmod=admincp_cate', 'succeed');	
}
function  cack_mobile_wechatpeizhi_updatacache(){
	require_once libfile('function/cache');
    $typecatequery = DB::query("SELECT * FROM " . DB::table('cack_mobile_wechatpeizhi_cate') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
    $typecatedata = array();
    $upidcatedata = array();
    while ($typecate = DB::fetch($typecatequery)) {
        $typecatedata[$typecate['id']] = $typecate;
        $upidcatequery = DB::query("SELECT * FROM " . DB::table('cack_mobile_wechatpeizhi_cate') . " where upid = " . $typecate['id'] . "  ORDER BY id ASC");
        while ($upidcate = DB::fetch($upidcatequery)) {
            $upidcatedata[$typecate['id']][$upidcate['id']] = $upidcate;
        }
    }
	writetocache('admincp_catecachedata', getcachevars(array('typecatedata' => $typecatedata,  'upidcatedata' => $upidcatedata)));
}
//From: Dism_taobao-com
?>