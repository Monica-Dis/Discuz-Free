<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/post');
loadcache('usergroups');
$_C = $_G['cache']['plugin']['cack_mobile_wechatpeizhi'];
$pyqbdbkid=intval($_C[pyqbdbkid]);
$cmod = $_GET['cmod'];
	if($_GET['pageajx']){
		$page = $_GET['pageajx'];
	}else{
		$page = $_GET['page'];
	}
		$perpage = 20;
		$curpage = empty ($page) ? 1 : intval ($page);
		$pages = ($curpage-1)*$perpage;


if($_GET[typeid]){
	$typeid=$_GET[typeid];
	$typeid=intval($typeid);
	if($typeid){
	$mytype = 'AND typeid = '.$typeid.'';
	}
}
$query_forum_post=DB::query("SELECT * FROM ".DB::table('forum_thread')." WHERE displayorder = 0 AND fid = ".$pyqbdbkid." $mytype order by tid desc LIMIT ".$pages.",20") ;
while($cack = DB::fetch($query_forum_post)){
	$pyqbdbksc[] = $cack;
	if($cack[attachment] == '2' && $cack[heats] > '0'){
		$pyqbdbkheatssc[] = $cack;
	}
}
$threadclass = DB::fetch_all('SELECT * FROM '.DB::table('forum_threadclass').' WHERE displayorder > -1 AND fid='.$pyqbdbkid.' order by displayorder asc  LIMIT  0,20');

$threadclassa=shuffle($threadclass);
if($cmod == 'typelist'){
	function threadclasscount($fid, $id = 0, $idtype = '', $count = 0) {
		if(!$fid) {
			return false;
		}
		$typeflag = ($id && $idtype && in_array($idtype, array('typeid', 'sortid')));
		$threadclasscount = C::t('common_cache')->fetch('threadclasscount_'.$fid);
		$threadclasscount = dunserialize($threadclasscount['cachevalue']);
		if($count) {
			if($typeflag) {
				$threadclasscount[$idtype][$id] = $count;
				C::t('common_cache')->insert(array(
					'cachekey' => 'threadclasscount_'.$fid,
					'cachevalue' => serialize($threadclasscount),
				), false, true);
				return true;
			} else {
				return false;
			}
		} else {
			if($typeflag) {
				return $threadclasscount[$idtype][$id];
			} else {
				return $threadclasscount;
			}
		}

	}
	
	
		$navtitle = $_C[pyqname];
		$showthreadclasscount = array();
			$showthreadclasscount = threadclasscount($pyqbdbkid);
		
		include template('cack_mobile_wechatpeizhi:typelist');
	}elseif($cmod == 'heatslist'){
		$navtitle = $_C[pyqname];
		include template('cack_mobile_wechatpeizhi:heatslist');
	}else{
		$navtitle = $_C[pyqname];
		if ($_GET[pageajx]){
		include template('cack_mobile_wechatpeizhi:indexajax');
		}else{

		$askcount = DB::result(DB::query("SELECT COUNT(*) FROM ".DB::table('forum_thread')."  WHERE displayorder = 0 AND fid = ".$pyqbdbkid." $mytype order by tid desc "));

		$multi = multi($askcount, $perpage, $curpage, "plugin.php?id=cack_mobile_wechatpeizhi&cmod=index");
		include template('cack_mobile_wechatpeizhi:index');
		}
}
//From: Dism_taobao-com
?>