/*
	[Discuz!] (C)2001-2099 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: common.js 34611 2014-06-11 10:28:49Z nemohou $
*/

function $2(id) {
	return !id ? null : document.getElementById(id);
}
