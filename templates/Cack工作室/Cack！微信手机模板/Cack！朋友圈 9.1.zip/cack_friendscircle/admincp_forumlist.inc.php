<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $pluginid;

if($_GET['mod'] == 'del') {
	if ($_GET['formhash'] == FORMHASH) {
		DB::delete('cack_friendscircle_forumlist', array('id' => intval($_GET['id'])));
		 cpmsg(lang('plugin/cack_friendscircle', '2'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=cack_friendscircle&pmod=admincp_forumlist', 'succeed');
	}
}

if (!submitcheck('bqsubmit')) {
    $forumlist = DB::fetch_all("SELECT * FROM %t ORDER BY displayorder", array("cack_friendscircle_forumlist"));
    showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=cack_friendscircle&pmod=admincp_forumlist', 'bqsubmit');
    showtableheader(lang('plugin/cack_friendscircle', '3'));
    showsubtitle(array('display_order', lang('plugin/cack_friendscircle', '4'), lang('plugin/cack_friendscircle', '9'), lang('plugin/cack_friendscircle', '8') , lang('plugin/cack_friendscircle', '12') , "", lang('plugin/cack_friendscircle', '6'), ''), 'header', array('', '', ''));
    foreach ($forumlist as $value) {
        showtablerow('class="data"', array('class="td25"', 'width="20"', 'width="80"', 'width="200"', 'width="80"', 'width="80"'), array(
            "<input type=\"text\" class=\"td25\" name=\"displayorder[$value[id]]\" value=\"$value[displayorder]\">",
            
			"<input type=\"text\" name=\"name[$value[id]]\" value=\"$value[name]\" class=\"td80\">",
            "<input type=\"text\" size=\"80\" name=\"pic[$value[id]]\" value=\"$value[pic]\" class=\"td150\"><img src=\"$value[pic]\" style=\"height: 30px;\">",
			"<input type=\"text\" name=\"url[$value[id]]\" value=\"$value[url]\" class=\"td200\">",
			"<input type=\"text\" name=\"summary[$value[id]]\" value=\"$value[summary]\" class=\"td200\">",
			"",
            "<a href='" . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=cack_friendscircle&pmod=admincp_forumlist&mod=del&id=$value[id]&formhash=".FORMHASH."'>".lang('plugin/cack_friendscircle', '6')."</a>",
                 "<input type=\"hidden\" name=\"id[$value[id]]\" value=\"$value[id]\">"
        ));
    }
        showtablerow('id="addnew"', array('width="100"', 'width="100"', 'width="200"', 'width="200"', 'width="100"', 'width="100"', 'width="100"', 'width="100"'), array("", "<div><a href=\"###\" onclick=\"addnewrecord(this)\" class=\"addtr\">".lang('plugin/cack_friendscircle', '10')."</a></div>", "", "", "", "")
        );
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
    showsubmit('bqsubmit');
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
	$lang6 = lang('plugin/cack_friendscircle', '6');
    print <<<EOF
	<script type="text/JavaScript">
	var rowtypedata = [
		[[1,'<input type="text"  class="td25" name="newdisplayorder[]" value="0" />', 'td25'],
		[1,'<input type="text" size="80" class="td80"  name="newname[]" />', 'td100'],
		[1,'<input type="text" class="td150" name="newpic[]"/>', ''], 
		[1,'<input type="text" class="td200" name="newurl[]"/>', ''], 
		[1,'<input type="text" class="td200" name="newsummary[]"/>', ''], 
		[1,'', 'td100'],
		[1, '<div><a href="javascript:;" class="deleterow" onClick="deleterow(this)">$lang6</a></div>', '']],
	];
	var newrows = document.getElementsByClassName("data").length;	
	function addnewrecord(v) {
		newrows++;
		addrow(v, 0);
		
	}
				
	</script>
				
	<style>
	.td150 {width:150px;}
	.td100 {width:100px;}
    .td80 {width:80px;}
	</style>
EOF;
} else {
    if (is_array(dhtmlspecialchars($_GET['name'])) && is_array(dhtmlspecialchars($_GET['pic']))) {
		$upsql = "UPDATE cdb_cack_friendscircle_forumlist SET ";
		$newhouse_clicks = array('displayorder','name','pic','url','summary');
		foreach ($newhouse_clicks as $key) {
			$upsql .= "{$key} = CASE id ";
				foreach (dhtmlspecialchars($_GET['id']) as $clicks_key) {
					if (empty($clicks_key)) {
						continue;
					}
					$upsql .= " WHEN ".$clicks_key." THEN '".dhtmlspecialchars($_GET[$key][$clicks_key])."' ";	
				}
			$upsql .= " END, ";
		}
		
		 $upsql = substr($upsql, 0, strrpos($upsql,','));
		 $newhouse_clicks_keys = implode(",",$_GET['id']);
		 $upsql .= " WHERE ID IN (".$newhouse_clicks_keys.")";
		 
		runquery($upsql);
		
    }
    if (is_array(dhtmlspecialchars($_GET['newname'])) && is_array(dhtmlspecialchars($_GET['newpic']))) {
        $data = array();
		$i = '0';

		foreach (dhtmlspecialchars($_GET['newname']) as $key => $newname) {
			if (empty($newname)) {
                continue;
            }
			$i = $i+'1';
			if($i == '1'){
				$insql = "INSERT INTO cdb_cack_friendscircle_forumlist(displayorder,name,pic,url,summary,time) VALUES('".dhtmlspecialchars($_GET['newdisplayorder'][$key])."','".dhtmlspecialchars($newname)."','".dhtmlspecialchars($_GET['newpic'][$key])."','".dhtmlspecialchars($_GET['newurl'][$key])."','".dhtmlspecialchars($_GET['newsummary'][$key])."',".time().")";
			}else{
				$insql .= ", ('".dhtmlspecialchars($_GET['newdisplayorder'][$key])."','".dhtmlspecialchars($newname)."','".dhtmlspecialchars($_GET['newpic'][$key])."','".dhtmlspecialchars($_GET['newurl'][$key])."','".dhtmlspecialchars($_GET['newsummary'][$key])."',".time().")";
			}
        }
		runquery($insql);
    }
	
    cpmsg(lang('plugin/cack_friendscircle', '7'), 'action=plugins&operation=config&do=' . $pluginid . '&identifier=cack_friendscircle&pmod=admincp_forumlist', 'succeed');
}