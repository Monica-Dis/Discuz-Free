<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/post');
loadcache('usergroups');
$_C = $_G['cache']['plugin']['cack_friendscircle'];


$perpage = $_C['perpage'];
$curpage = empty ( $_GET['page'] ) ? 1 : intval ( $_GET['page'] );
$start = ($curpage-1)*$perpage;
$fidarr = implode(',',dunserialize($_C['tzbk']));

$sqlforumarray = DB::fetch_all("SELECT * FROM ".DB::table('forum_forum')." where fid in(".$fidarr.") ORDER BY fid DESC LIMIT 0,100");
foreach ($sqlforumarray as $value) {
	$forumname[$value['fid']] = $value['name'];
}

$myfid = '';
	if(!$_GET['myfriend']){
		if($_C['tzbk']){
			$myfid = " AND fid in(".$fidarr.")";
		}
	}
	if($_GET['fid']){
		$myfid = " AND fid=$_GET[fid] ";
		
	}
	if($_G['uid']){
		$query = DB::query("SELECT * FROM ".DB::table('home_follow')." where uid = ".$_G['uid']." ");
		while($cack = DB::fetch($query)) {
			$followuidarr[] = $cack['followuid'];
		}
	}
if($_GET['myfriend'] && $followuidarr){
	$query = DB::query("SELECT * FROM ".DB::table('forum_thread')." where displayorder >= 0 AND authorid in(".implode(',',$followuidarr).") order by tid desc LIMIT  ".$start.",".$perpage."");
}else{
	$query = DB::query("SELECT * FROM ".DB::table('forum_thread')." where displayorder >= 0  ".$myfid." order by tid desc LIMIT  ".$start.",".$perpage."");
}


while($cack = DB::fetch($query)) {
	$threadlist[] = $cack;
	$threadtidarr[] = $cack['tid'];
	$threadauthoridarr[] = $cack['authorid'];
}

if($threadtidarr){
	$mytid = " AND tid in(".implode(',',$threadtidarr).")";
	$query_forum_attachment=DB::query("SELECT * FROM ".DB::table('forum_attachment')." WHERE uid IN(".implode(',',$threadauthoridarr).") AND tid IN(".implode(',',$threadtidarr).") ORDER BY aid desc ") ; 
	while($thread = DB::fetch($query_forum_attachment)){
		$post_pic[$thread['tid']][] = $thread;
	}
	$query = DB::query("SELECT * FROM ".DB::table('forum_memberrecommend')." WHERE tid IN(".implode(',',$threadtidarr).") order by dateline desc") ; 
	while($cack = DB::fetch($query)){
		$post_recommendli[$cack['tid']][] = $cack;
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('forum_post')." where status>=0 ".$mytid." order by pid asc ");
		while($cack = DB::fetch($query)) {
			if($cack['first'] == '1'){
				$threadmessage[$cack['tid']]['message'] = $cack['message'];
			}
			if($cack['first'] != '1'){
				$threadpost[$cack['tid']][] = $cack;
			}
		}
	
}

$multi = multi($askcount, $perpage, $curpage, "plugin.php?id=cack_help&mod=list&catid=".intval($_GET['catid']));

if(!$_GET['fid']){
	$navtitle = $_C['cjbm'];
}else{
	$navtitle = $forumname[$_GET['fid']];
}


include template('cack_friendscircle:ajax');
?>