// JavaScript Document

//关闭提示下载
// $(".close").click(function(){
// 	$(".down-top").hide();
// 	});

//显示密码
$(".show-password").click(function(){
	var psw=$(this).parent().find(".password");
	 if ($(psw).attr("type") == "password") {
            $(psw).attr("type", "text")
        }
        else {
            $(psw).attr("type", "password")
        }
	});	
	
//同意条款
	$(".reg-agree .agree-check").click(function(){
		if($(".agree-check").hasClass("on"))
		{
			$(".agree-check").removeClass("on");
		}
		else
		{
			$(".agree-check").addClass("on");
		}
	});
	

//关注和已关注的
$(".focus-button").click(function(){
	if($(this).hasClass("on"))
	{
		$(this).removeClass("on");
	}
	else
	{
		$(this).addClass("on");
	}
	//$(this).toggleClass("on");
});

//置顶
$(".top").hide();
$(function () {
	$(window).scroll(function(){
	if ($(window).scrollTop()>window.innerHeight){
		$(".top").show();
		}
		else
		{
		$(".top").hide();
		}
	});
	$(".top").click(function(){
		window.scroll(0,0);  
		//$('body,html').animate({scrollTop:0},100);
		return false;
	});
});

//收藏
$(".collect-button").click(function(){
	if($(this).html()=="收藏")
	{
		$(this).html("已收藏");
		$(this).addClass("on");
	}
	else if($(this).html()=="已收藏")
	{
		$(this).html("收藏");
		$(this).removeClass("on");
	}
	
});

//展开收起
$(".show").click(function(){
	if($(this).html()=="∧ 收起")
	{
		$(this).html("∨ 展开");
	}
	else if($(this).html()=="∨ 展开")
	{
		$(this).html("∧ 收起");
	}
	
	});

//全部模块选择
$(".section-left").height(window.innerHeight);
$(".section-right").height(window.innerHeight);
$(".section-left a").each(function(index, element) {
    $(this).click(function(){
		var num=index+1;
		$(this).addClass("on").siblings().removeClass("on");
		$(".section-right .section-detail:nth-child("+num+")").addClass("on").siblings().removeClass("on");
		});
});


//取消图片选择
function fclose(obj){
	event.stopPropagation();
	alert("是否删除");
	$(obj).parents("figure").hide();
	}


//div仿textarea
if (typeof document.webkitHidden == "undefined") {
    // 非chrome浏览器阻止粘贴
    /*box.onpaste = function() {
        return false;
    }*/
}


//话题选择
$(".topics span.circle40").each(function(index, element) {
	$(this).click(function()
	{
		$(".write-textarea").find("br").remove();
		if($(this).hasClass("on"))
		{
			$(this).removeClass("on");
			var new_span="<span>#"+$(this).find("span").html()+"#</span>&#160;";
			var new_span1="<span>#"+$(this).find("span").html()+"#</span>&nbsp;";
			var val=$(".write-textarea").html();
			$(".write-textarea").html(val.replace(new_span1,""));
		}
		else
		{
			$(this).addClass("on");
			var new_span="<span>#"+$(this).find("span").html()+"#</span>&#160;";
			var val=$(".write-textarea").html();
			//console.log(val);
			$(".write-textarea").html(val+new_span);
		}

		if($(".write-textarea").html()=="")
		{
			$(".write-textarea").append("<br/>");
		}
	});
});

//本地圈最新中地址的选择
/*$(".locat-outside .site").click(function(){
	$(this).parent().find("i").addClass("on");
	$(this).addClass("on");
	});*/


//验证码倒计时
 
function yzm(obj){
	var time=90;
    setInterval(function(){
		$(obj).addClass("gray");
		$(obj).html(time+"秒后重试");
        time--;
        if(time<0){
            //time=90;
			$(obj).removeClass("gray");
			$(obj).html("获取验证码");
        }
    },1000)
	
	}


//页面加载的时候巷友发的说说的图片                 
window.onload=function(){
	
	if($(".speak-imgs").hasClass("my-gallery"))
	{
		$(".my-gallery figure").each(function(index, element) {
			//console.log($(this).find("a"));
            if($(this).find("a").length==0)
			{
				$(this).find("img").wrap("<a href='' data-size=''></a>");
			}
        });
		//$(".my-gallery").find("figure img").wrap("<a href='' data-size=''></a>");
			
	}
	auto_data_size();
	};
	function auto_data_size(){
		$("figure img").each(function() {
		var imgs = new Image();
		imgs.src=$(this).attr("src");
		var w = imgs.width,
		h =imgs.height;
		$(this).parent("a").attr("data-size","").attr("data-size",w+"x"+h);
		$(this).parent("a").attr("href","").attr("href","http://qianfan-qianfan.qiniudn.com/2016111612441479275173359219.jpg?imageView2/1/w/288/h/288/interlace/1/q/100");
		if(w/h>1)
		{
			$(this).css("height","100%");
		}
		else
		{
			$(this).css("width","100%");
		}
		
		if($(this).parents("div").hasClass(".speak-img1"))
		{
			$(this).width(w*0.6*0.01+"rem");	
		}
	
		})
	};
	
//右下方照片方式选择
    $(function(){
        var $phoneActionsheet = $('#phoneActionsheet');
        var $phoneMask = $('#phoneMask');

        function hideActionSheet() {
            $phoneActionsheet.removeClass('weui-actionsheet_toggle');
            $phoneMask.fadeOut(200);
        }

        $phoneMask.on('click', hideActionSheet);
        $('#phoneActionsheetCancel').on('click', hideActionSheet);
        $(".showPhoneActionSheet").on("click", function(){
            $phoneActionsheet.addClass('weui-actionsheet_toggle');
            $phoneMask.fadeIn(200);
        });
		
    });
//<a>标签中再添加一个点击事件
	  $(".txtlabel").bind("click",function(e){
		e.preventDefault();
		//接下来使用js代码进行页面跳转
	  });

// 性别弹出层
    $(function(){
        var $iosActionsheet = $('#iosActionsheet');
        var $iosMask = $('#iosMask');

        function hideActionSheet() {
            $iosActionsheet.removeClass('weui-actionsheet_toggle');
            $iosMask.fadeOut(200);
        }

        $iosMask.on('click', hideActionSheet);
        $('#iosActionsheetCancel').on('click', hideActionSheet);
        $("#showIOSActionSheet").on("click", function(){
            $iosActionsheet.addClass('weui-actionsheet_toggle');
            $iosMask.fadeIn(200);
        });
	  /*选择性别*/
		$(".weui-actionsheet__menu .weui-actionsheet__cell").each(function(index, element) {
			$(this).click(function(){
				$(".sex").attr("value",$(this).html());
				$(".sex").val($(this).html());
				$(".sex").html($(this).html());
				$iosActionsheet.removeClass('weui-actionsheet_toggle');
				$iosMask.fadeOut(200);
				});
    	});
		
		
    });


	//控制本地圈首页的轮播图
	$(".swiper-container1 img").height($(".swiper-container1 img ").width()*4/15);
	
	//首页登录 轮播图
	$(".swiper-container3 img").height($(".swiper-container3 img ").width()*21/50);

	
	//提交评论的判断
	
	function discuss(obj){
		if($.trim($(obj).val()).length>0)
		{
			$(obj).next(".dsubmit").addClass("on");
		}
		else
		{
			$(obj).next(".dsubmit").removeClass("on");
		}
	}
	
	//评论失去焦点后隐藏
	/*$(".speak-discuss input").blur(function(){//输入框失焦后还原初始状态
		$(".speak-discuss").removeAttr('style');
		$(window).unbind('scroll');        
		$(".speak-discuss").hide();
	});*/
	//视频的禁止冒泡			
	$("video").click(function(){
		event.stopPropagation();
		});
	$(".speak-discuss input").click(function(){
		event.stopPropagation();
		});
		
	/*$(".previewImage img").click(function(){
		event.stopPropagation();
		});*/
//本地圈点击分享 弹出层
$(".speak-button .button1").click(function(){
	$(".wshare").show();
	event.stopPropagation();
	$(".wshare").click(function(){
		$(this).hide();
		});
	});


$(".post-tit").blur(function(){
    var txt=$(this).val();
    $(".post-tit-hid").html(txt);
    $(this).css("opacity","0");
    $(".post-tit-hid").css("opacity","1");
    $(".post-tit-hid").css("z-index","2");
});

$(".post-tit-hid").click(function(){
    $(this).css("opacity","0");
    $(".post-tit-hid").css("z-index","-1");
    $(".post-tit").css("opacity","1");
    var t=$(".post-tit").val();
    $(".post-tit").val("").focus().val(t);
    //alert($(".post-tit").val());
});
