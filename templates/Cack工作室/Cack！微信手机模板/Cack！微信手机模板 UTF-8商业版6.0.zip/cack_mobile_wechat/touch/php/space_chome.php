<?php
$usersightml = DB::fetch_all('SELECT * FROM '.DB::table('common_member_field_forum').' WHERE uid = '.$space[uid].'  order by uid desc  LIMIT  0 ,'. 1 );
$usercount = DB::fetch_all('SELECT * FROM '.DB::table('common_member_count').' WHERE uid = '.$space[uid].'  order by uid desc  LIMIT  0 ,'. 1 );
$useralbum = DB::fetch_all('SELECT * FROM '.DB::table('forum_post').' WHERE authorid = '.$space[uid].' AND attachment=2 order by tid desc  LIMIT  0 ,'. 30 );
?>
