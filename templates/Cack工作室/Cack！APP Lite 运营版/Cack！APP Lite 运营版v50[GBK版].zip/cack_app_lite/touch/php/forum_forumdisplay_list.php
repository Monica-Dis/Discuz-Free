<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/post');
$tzlbxsysxwforum=unserialize($_G['cache']['plugin']['cack_app_litebl']['tzlbxsysxw']);
$tzlbxsyswtforum=unserialize($_G['cache']['plugin']['cack_app_litebl']['tzlbxsyswt']);
$tzlbxsysxsforum=unserialize($_G['cache']['plugin']['cack_app_litebl']['tzlbxsysxs']);
$tzlbxsyshdforum=unserialize($_G['cache']['plugin']['cack_app_litebl']['tzlbxsyshd']);
$tzlbxsysspforum=unserialize($_G['cache']['plugin']['cack_app_litebl']['tzlbxsyssp']);
$tzlbxsyshhforum=unserialize($_G['cache']['plugin']['cack_app_litebl']['tzlbxsyshh']);
$tzlbxsysdtdtforum=unserialize($_G['cache']['plugin']['cack_app_litebl']['tzlbxsysdtdt']);
$tzlbxsysfmforum=unserialize($_G['cache']['plugin']['cack_app_litebl']['tzlbxsysfm']);

?>