<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('stamps');
if($_G['cache']['plugin']['cack_app_litebl'] || $sql_portal_index){
$page = $_GET['pageajx'];
if($page <= 1){
	$pages = 0;
}else{
	$pages = ($page-1)*$_G['cache']['plugin']['cack_app_litebl']['sytzdigests'];
}
if($_G['cache']['plugin']['cack_app_litebl']['mhsjlyxz'] == '1'){
	$query=DB::query("SELECT * FROM ".DB::table('portal_article_title')." WHERE catid IN(".$_G['cache']['plugin']['cack_app_litebl']['mhwzlylm'].") ORDER BY aid desc  LIMIT ".$pages.",".$_G['cache']['plugin']['cack_app_litebl']['sytzdigests']) ; 
		while($article = DB::fetch($query)){
			$articlelite[] = $article;
			$aidarr[] = $article[aid];
			if(!$article[pic]){
			$nopic[$article[aid]] = $article[aid];
			}
		}
	if($aidarr){
		$query=DB::query("SELECT * FROM ".DB::table('portal_article_content')." WHERE aid IN(".implode(',',$aidarr).") ORDER BY aid desc  ") ; 
		while($article = DB::fetch($query)){
			if($nopic[$article[aid]] == $article[aid]){
				if(preg_match_all("/src\=\"(.*)\"/isU",$article[content],$result)){
					foreach ($result[1] as $key1=>$src){
						$src=trim($src);
						if((stripos($src,$_G['siteurl'])==true)||substr($src,0,7)=='//') continue;
						$ycpic[$article['aid']]['pic']=$src;
					}
				}
			}
		}
	}
}else{
	$inforum=unserialize($_G['cache']['plugin']['cack_app_litebl']['sytzlybk']);
	$inforum=implode(',',$inforum);
	if($_G['cache']['plugin']['cack_app_litebl']['sytzzxsjh']){
		$ddiges = 'AND digest > 0 ';
	}

	if($inforum){
		$dfid = 'AND fid in ('.$inforum.')';
	}

	
	
	
	
	if($_G['cache']['plugin']['cack_app_litebl']['sysjkqzd']){
		$sqlorder = 'order by displayorder desc,tid desc';
	}else{
		$sqlorder = 'order by tid desc';
	}
	
	
	$digestthread =  DB::fetch_all('SELECT * FROM '.DB::table($sql_portal_index).' WHERE displayorder > -1 '.$dfid.' '.$ddiges.' '.$dattachment.' '.$sqlorder.'  LIMIT  ' .$pages.' ,'. $_G['cache']['plugin']['cack_app_litebl']['sytzdigests'] );
	
	function threadhighlight($threadhighlight){
		if($threadhighlight) {
			$_G['forum_colorarray'] = array('', '#EE1B2E', '#EE5023', '#996600', '#3C9D40', '#2897C5', '#2B65B7', '#8F2A90', '#EC1282');
			$string = sprintf('%02d', $threadhighlight);
			$stylestr = sprintf('%03b', $string[0]);

			$threadhighlight = ' style="';
			$threadhighlight .= $stylestr[0] ? 'font-weight: bold;' : '';
			$threadhighlight .= $stylestr[1] ? 'font-style: italic;' : '';
			$threadhighlight .= $stylestr[2] ? 'text-decoration: underline;' : '';
			$threadhighlight .= $string[1] ? 'color: '.$_G['forum_colorarray'][$string[1]].';' : '';
			if($thread['bgcolor']) {
				$threadhighlight .= "background-color: $thread[bgcolor];";
			}
			$threadhighlight .= '"';
			return $threadhighlight;
		} else {
			
		}
	}

	require_once libfile('function/post');
	
	function cackisimage($tid,$aid){
		$table='forum_attachment_'.substr($tid, -1);
		$query = DB::fetch_all("SELECT * FROM ".DB::table($table)." WHERE aid = $aid AND isimage!=0 ORDER BY `dateline` ASC");
		while($thread = DB::fetch($query_forum_attachment)){
			$post_pic_aidarr[] = $thread[aid];
		}
		if($query){
			$query = '1';
		}else{
			$query = '0';
		}
		return $query;
	}
	
	if($digestthread){
		foreach($digestthread as $a){
			$tidarr[]=$a['tid'];
			$authoridarr[]=$a['authorid'];
		}
		$tids=implode(',',$tidarr);
		$authorids=implode(',',$authoridarr);
		
	
		$query_forum_attachment=DB::query("SELECT * FROM ".DB::table('forum_attachment')." WHERE tid IN($tids) AND uid IN($authorids) ORDER BY aid asc ") ; 
		while($thread = DB::fetch($query_forum_attachment)){
			if(cackisimage($thread[tid],$thread[aid]) == '1'){
				$post_pic[$thread[tid]][] = $thread;
			}
		}
		
	}
}
}

	$query=DB::query("SELECT * FROM ".DB::table('cack_app_litebl_hdpsz')." ORDER BY displayorder asc ") ; 
	while($thread = DB::fetch($query)){
		$cackmhhdps_types[] = $thread;
	}
	$query=DB::query("SELECT * FROM ".DB::table('cack_app_litebl_mhdhsz')." ORDER BY displayorder asc ") ; 
	while($thread = DB::fetch($query)){
		$cackmhdhs_types[] = $thread;
	}
	$query=DB::query("SELECT * FROM ".DB::table('cack_app_litebl_mhdh2sz')." ORDER BY displayorder asc ") ; 
	while($thread = DB::fetch($query)){
		$cackmhdh2s_types[] = $thread;
	}
$mhdhmyzs = intval('10000'/$_G['cache']['plugin']['cack_app_litebl']['mhsydhmhgs'])/'100';

$cackindexfyjzgg=$_G['cache']['plugin']['cack_app_litebl']['indexfyjzgg'];
$cackindexfyjzggs = explode ("\n", str_replace ("\r", "", $cackindexfyjzgg));
foreach($cackindexfyjzggs as $key=>$value){
	$arr=explode('|',$value);
	$cackindexfyjzggsc[]=$arr;
}
//From: Dism��taobao��com
?>