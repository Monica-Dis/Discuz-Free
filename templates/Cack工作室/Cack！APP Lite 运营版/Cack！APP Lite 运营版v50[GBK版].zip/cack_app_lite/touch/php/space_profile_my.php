<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($_G['cache']['plugin']['cack_app_litebl']['grkjdhxl']){
	$cackgrkjdhxl=$_G['cache']['plugin']['cack_app_litebl']['grkjdhxl'];
	$cackgrkjdhxls = explode ("\n", str_replace ("\r", "", $cackgrkjdhxl));
	foreach($cackgrkjdhxls as $key=>$value){
		$arr=explode('|',$value);
		$cackgrkjdhxls_types[]=$arr;
	}
}
if($_G['cache']['plugin']['cack_app_litebl']['grzxxl1']){
	$cackgrzxxl1=$_G['cache']['plugin']['cack_app_litebl']['grzxxl1'];
	$cackgrzxxl1s = explode ("\n", str_replace ("\r", "", $cackgrzxxl1));
	foreach($cackgrzxxl1s as $key=>$value){
		$arr=explode('|',$value);
		$cackgrzxxl1s_types[]=$arr;
	}
}
if($_G['cache']['plugin']['cack_app_litebl']['grzxxl2']){
	$cackgrzxxl2=$_G['cache']['plugin']['cack_app_litebl']['grzxxl2'];
	$cackgrzxxl2s = explode ("\n", str_replace ("\r", "", $cackgrzxxl2));
	foreach($cackgrzxxl2s as $key=>$value){
		$arr=explode('|',$value);
		$cackgrzxxl2s_types[]=$arr;
	}
}
//From: Dism_taobao_com
?>