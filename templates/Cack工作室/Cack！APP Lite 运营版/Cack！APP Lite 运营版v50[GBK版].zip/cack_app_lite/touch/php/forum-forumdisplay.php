<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/post');
	function cackisimage($tid,$aid){
		$table='forum_attachment_'.substr($tid, -1);
		$query = DB::fetch_all("SELECT * FROM ".DB::table($table)." WHERE aid = $aid AND isimage!=0 ORDER BY `dateline` ASC");
		while($thread = DB::fetch($query_forum_attachment)){
			$post_pic_aidarr[] = $thread[aid];
		}
		if($query){
			$query = '1';
		}else{
			$query = '0';
		}
		return $query;
	}
if($_G['forum_threadlist']){
	foreach($_G['forum_threadlist'] as $a){
		$tidarr[]=$a['tid'];
		$authoridarr[]=$a['authorid'];
	}
$tids=implode(',',$tidarr);
$authorids=implode(',',$authoridarr);
$query_forum_attachment=DB::query("SELECT * FROM ".DB::table($sql_forum_forumdisplay3).' WHERE tid IN('.$tids.') AND uid IN('.$authorids.') '.$sql_forum_forumdisplay1.'') ; 
	while($thread = DB::fetch($query_forum_attachment)){
			if(cackisimage($thread[tid],$thread[aid]) == '1'){
				$post_pic[$thread[tid]][] = $thread;
			}
	}
$query_member_profile=DB::query("SELECT * FROM ".DB::table($sql_forum_forumdisplay2)." WHERE uid IN($authorids)") ; 
	while($cack = DB::fetch($query_member_profile)){
		$post_profile[$cack[uid]] = $cack;
	}

}
//From: Dism��taobao��com
?>