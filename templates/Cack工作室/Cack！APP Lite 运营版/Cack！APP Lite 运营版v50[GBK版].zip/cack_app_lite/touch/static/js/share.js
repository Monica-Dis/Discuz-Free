
// 获取浏览器版本号
 function getVersion(c) {
    var a = c.split("."),
        b = parseFloat(a[0] + "." + a[1]);
    return b;
}

// 加载 QQ 浏览器分享 API
function isloadqqApi() {
    if (isQQ) {
        var b = (qq_v < 5.4) ? 'https://3gimg.qq.com/html5/js/qb.js' : 'https://jsapi.qq.com/get?api=app.share';
        var d = document.createElement("script");
        var a = document.getElementsByTagName("body")[0];
        d.setAttribute("src", b);
        a.appendChild(d);
    }
}

//判断是否Safari
function isMobileSafari() {
    var ua = navigator.userAgent;
    // 判断safari
    if (/ OS \d/.test(ua) && ua.indexOf('iPhone') > -1) {
        // 不是Chrome //不是QQ浏览器 // 开头必须为Mozilla
        if (!~ua.indexOf('CriOS') && !~ua.indexOf('MQQBrowser') && !ua.indexOf('Mozilla')) {
            // 结尾需为：Safari/xxx.xx
            if (/Safari\/[\d\.]+$/.test(ua)) {
                return true;
            }
        }
    }
    return false;
}

var ua = navigator.userAgent.toLowerCase();
var isUC =/UCBrowser/i.test(ua);
var UC_CONFIG = {fd: {ucb: 'kWeixin', ucw: 'WechatFriends'}, tl: {ucb: 'kWeixinFriend', ucw: 'WechatTimeline'} };

var qq_app = navigator.appVersion.split("MQQBrowser/");
var isQQ = qq_app.length > 1 ? 2 : 0;
var qq_v = isQQ ? getVersion(qq_app[1]) : 0;

var platform_os = (ua.indexOf("iPhone") > -1 || ua.indexOf("iPod") > -1) ? 'iPhone' : 'Android';
if ((isQQ && qq_v < 5.4 && platform_os == "iPhone") || (isQQ && qq_v < 5.3 && platform_os == "Android")) {
    isQQ = 0;
} else {
    if (isQQ && qq_v < 5.4 && platform_os == "Android") {
        isQQ = 1;
    }
}

isloadqqApi();

var title = document.title;
var des = document.getElementsByName('description')[0].content;
var url = location.href.replace(/#.*/, '');
var __and = !~url.indexOf('?') ? '?' :'&'
function detectWeixinApi() {
    if (ua.match(/MicroMessenger/i) != "micromessenger") {
        alert('请点击当前屏幕右上角按钮进行分享。');
    } else {
        alert('请点击当前屏幕右上角按钮进行分享。');
    }
}

// UC 浏览器的微信分享
function shareFromUC(isToFriend) {
    var type = isToFriend ? 'fd' : 'tl';
    var _url = url + __and + 'wapShare=weixin'
    if ('undefined' != typeof(ucbrowser) && 'undefined' != typeof(ucbrowser.web_share)) {
        ucbrowser.web_share(title, des, _url, UC_CONFIG[type].ucb, '', '', '');
    } else {
        if ('undefined' != typeof(ucweb) && 'undefined' != typeof(ucweb.startRequest)) {
            ucweb.startRequest("shell.page_share", [title, des, _url, UC_CONFIG[type].ucw, '', '', ''])
        }
    }
}

// QQ 浏览器的微信分享
function shareFromQQ(isToFriend) {
    var type = isToFriend ? '1' : '8';
    var _url = url + __and + 'wapShare=weixin'
    var obj = {
        url: _url,
        title: title,
        description: des,
        to_app: type,
        cus_txt: ''
    };

    if ('undefined' != typeof(browser) && 'undefined' != typeof(browser.app)) {
        browser.app.share(obj);
    } else {
        if ('undefined' != typeof(window.qb)) {
            window.qb.share(obj);
        } else {}
    }
}

/*
 * 微信分享
 * @param isToFriend: 1, 分享好友; 0, 分享朋友圈
*/
function shareWeixin(isToFriend) {
    if (isUC) {
        shareFromUC(isToFriend);
    } else if (isQQ) {
        shareFromQQ(isToFriend);
    } else {}
}

// Safari微信分享指引
function bodyScroll(e){
    evt = e || window.event;
    evt.preventDefault() ?  evt.preventDefault() : evt.returnValue = false;
}


function closeSafariGuide(){
    document.removeEventListener("touchmove",bodyScroll,false);
    var guideMod = document.getElementById("JsafariGuide");
    guideMod.style.display = "none";
}

(function() {
    var bdshare_warp = document.getElementById('bdshare_warp');
    if (!bdshare_warp) return;
    var titleReg = /([^_]*)_?.*/; //匹配第一个空格前的字符
    var shareTopic = "";
    var shareTitle = document.title.replace(titleReg, "$1");
    var shareUrl = url;
    var _shareUrl = shareUrl.replace(/\?.*/,'')
    var and = __and
    var wrapLeft = '<span id="bdshare" class="bdshare_t bds_tools get-codes-bdshare" data=\'{"url":"'
    //shareTitle=encodeURI(shareTitle);
    window.bds_config = {
        'bdText': shareTopic + shareTitle,
    };

    

    if (/MicroMessenger/i.test(ua)) {
        shareWeixin = '<a class="weixin" onclick="detectWeixinApi()">微信</a>';
    } else {
                shareWeixin = '<a class="weixin" onclick="detectWeixinApi()">微信</a>';
    }

    shareContent = '<div id="bdshare">' + shareWeixin +
        wrapLeft +_shareUrl+'?wapShare=qzone"}\'><a class="bds_qzone">QQ空间</a></span>'+
        //wrapLeft +shareUrl + and +'wapShare=tieba"}\'><a class="bds_tieba">百度贴吧</a></span>'+
        //wrapLeft +shareUrl + and +'wapShare=tsina"}\'><a class="bds_tsina">新浪微博</a></span>'+
        '</div>';

    bdshare_warp.innerHTML = shareContent;

    var queue = [{
        config: {
            id: 'bdshare_js',
            data: 'type=tools&mini=1&uid=726255'
        }
    }, {
        url: 'https://bdimg.share.baidu.com/static/js/shell_v2.js?t=' + new Date().getHours()
    }]

    for (var i = 0, l = queue.length; i < l; i++) {
        var script = document.createElement('script');
        if (queue[i].config) {
            var c = queue[i].config;
            for (var j in c) {
                if (c.hasOwnProperty(j)) {
                    script.setAttribute(j, c[j]);
                }
            }
        }
        document.getElementsByTagName('head')[0].appendChild(script);
        queue[i].url && (script.src = queue[i].url);
    }
})();
