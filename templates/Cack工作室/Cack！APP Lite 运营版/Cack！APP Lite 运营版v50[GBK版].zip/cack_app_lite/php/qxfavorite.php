<?php
require $_SERVER['DOCUMENT_ROOT'].'/source/class/class_core.php';//引入系统核心文件
$discuz = & discuz_core::instance();//以下代码为创建及初始化对象
$discuz->cachelist = $cachelist;
$discuz->init();
global $_G;
$tid = $_GET['tid'];
$uid = $_G['uid'];
if($uid && $tid && $_GET['formhash'] == FORMHASH){
DB::delete('home_favorite', array('id' => intval($tid),'uid' => intval($uid)));
}
echo $_G['uid'];
?>