<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

		require_once libfile('function/forumlist');
		if($_G[uid]){
			$usersightml = DB::fetch_all('SELECT * FROM '.DB::table('common_member_field_forum').' WHERE uid = '.$_G[uid].'  order by uid desc  LIMIT  0,1');
		}
		if($_G['cache']['plugin']['cack_app_litebl']['cblgrxl']){
			$cackcblgrxl=$_G['cache']['plugin']['cack_app_litebl']['cblgrxl'];
			$cackcblgrxls = explode ("\n", str_replace ("\r", "", $cackcblgrxl));
			foreach($cackcblgrxls as $key=>$value){
				$arr=explode('|',$value);
				$cackcblgrxls_types[]=$arr;
			}
		}
		$query=DB::query("SELECT * FROM ".DB::table('cack_app_litebl_header_dh2')." ORDER BY displayorder asc ") ; 
		while($threadccc = DB::fetch($query)){
			$cackheaderdh2_types[] = $threadccc;
		}
		$sql_cack_biaoqing2 = 'common_smiley';
		$sql_forum_forumdisplay1 = ' ORDER BY aid asc';
		$sql_forum_forumdisplay2 = 'common_member_profile';
		$sql_forum_forumdisplay3 = 'forum_attachment';
		$sql_portal_index = 'forum_thread';
		$sql_post = 'forum_forum';
		$sql_space_home_notification = 'home_notification';
		$sql_space_profile = 'forum_post';
		$sql_space_profile2 = 'forum_attachment';
	include 'template/cack_app_lite/touch/lang/'.currentlang().'.php';
	$cackviewnryyswx = unserialize($_G['cache']['plugin']['cack_app_litebl']['nryyswx']);
function cackdate($time = NULL) {
    $text = '';
    $time = $time === NULL || $time > time() ? time() : intval($time);
    $t = time() - $time; //时间差 （秒）
    $y = date('Y', $time)-date('Y', time());//是否跨年
    switch($t){
     case $t == 0:
       $text = '刚刚';
       break;
     case $t < 60:
      $text = $t . '秒前'; // 一分钟内
      break;
     case $t < 60 * 60:
      $text = floor($t / 60) . '分钟前'; //一小时内
      break;
     case $t < 60 * 60 * 24:
      $text = floor($t / (60 * 60)) . '小时前'; // 一天内
      break;
     case $t < 60 * 60 * 24 * 3:
      $text = floor($time/(60*60*24)) ==1 ?'昨天 ' . date('H:i', $time) : '前天 ' . date('H:i', $time) ; //昨天和前天
      break;
     case $t < 60 * 60 * 24 * 30:
      $text = date('m月d日 H:i', $time); //一个月内
      break;
     case $t < 60 * 60 * 24 * 365&&$y==0:
      $text = date('m月d日', $time); //一年内
      break;
     default:
      $text = date('Y年m月d日', $time); //一年以前
      break;
    }
        
    return $text;
}

//From: dis'.'m.tao'.'bao.com
?>
