<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if($hdthread){
	foreach($hdthread as $a){
		$tidarr[]=$a['tid'];
		$authoridarr[]=$a['authorid'];
	}
$tids=implode(',',$tidarr);
$authorids=implode(',',$authoridarr);
$query_forum_attachment=DB::query("SELECT * FROM ".DB::table('forum_attachment')." WHERE tid IN($tids) ORDER BY aid desc ") ; 
	while($thread = DB::fetch($query_forum_attachment)){
		$post_pic[$thread[tid]][] = $thread;
	}
$query_forum_activity=DB::query("SELECT * FROM ".DB::table('forum_activity')." WHERE tid IN($tids) ORDER BY tid desc ") ; 
	while($thread = DB::fetch($query_forum_activity)){
		$post_act[$thread[tid]] = $thread;
	}
$query_member_profile=DB::query("SELECT * FROM ".DB::table('common_member_profile')."") ; 
	while($cack = DB::fetch($query_member_profile)){
		$post_profile[$cack[uid]] = $cack;
	}
$query_forum_post=DB::query("SELECT * FROM ".DB::table('forum_post')." WHERE tid IN($tids) order by pid desc") ; 
	while($cack = DB::fetch($query_forum_post)){
		if($cack['first'] == '1' && $cack['invisible'] == '0'){
		$post_count[$cack[tid]]=$cack;
		}
		if($cack['first'] == '0' && $cack['invisible'] == '0'){
		$post_liforum[$cack[tid]][] = $cack;
		}
	}
$query_recommendli=DB::query("SELECT * FROM ".DB::table('forum_memberrecommend')." WHERE tid IN($tids) order by dateline desc") ; 
	while($cack = DB::fetch($query_recommendli)){
		$post_recommendli[$cack[tid]][] = $cack;
	}

}
//From: Dism_taobao_com
?>