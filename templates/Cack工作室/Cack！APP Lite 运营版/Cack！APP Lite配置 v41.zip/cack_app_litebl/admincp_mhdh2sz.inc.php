<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include 'source/plugin/cack_app_litebl/lang/'.currentlang().'.php';
global $pluginid;

if($_GET['mod'] == 'del') {
    DB::delete('cack_app_litebl_mhdh2sz', array('id' => intval($_GET['id'])));
    cpmsg($admincplang[8], 'action=plugins&operation=config&do='.$pluginid.'&identifier=cack_app_litebl&pmod=admincp_mhdh2sz', 'succeed');
}

if (!submitcheck('bqsubmit')) {
    $listnav = DB::fetch_all("SELECT * FROM %t ORDER BY displayorder", array("cack_app_litebl_mhdh2sz"));
    showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=cack_app_litebl&pmod=admincp_mhdh2sz', 'bqsubmit');
    showtableheader($admincplang[16]);
    showsubtitle(array('display_order', $admincplang[2], $admincplang[12], $admincplang[11], $admincplang[4] , "", $admincplang[5], ''), 'header', array('', '', ''));
    foreach ($listnav as $value) {
        showtablerow('class="data"', array('class="td25"', 'width="20"', 'width="80"', 'width="200"', 'width="80"', 'width="80"'), array(
            "<input type=\"text\" class=\"td25\" name=\"displayorder[$value[id]]\" value=\"$value[displayorder]\">",
            
			"<input type=\"text\" name=\"name[$value[id]]\" value=\"$value[name]\" class=\"td80\">",
			"<input type=\"text\" name=\"zhaiyao[$value[id]]\" value=\"$value[zhaiyao]\" class=\"td200\">",
            "<input id=\"c".$value[id]."_v\" type=\"text\" size=\"80\" name=\"pic[$value[id]]\" value=\"$value[pic]\" class=\"td150\"  onchange=\"updatecolorpreview('c".$value[id]."')\"><input id=\"c".$value[id]."\" class=\"colorwd\" onclick=\"c".$value[id]."_frame.location='static/image/admincp/getcolor.htm?c".$value[id]."|c".$value[id]."_v';showMenu({'ctrlid':'c".$value[id]."'})\" type=\"button\" value=\"\" style=\"float: right;background-color:".$value[pic].";\"><span id=\"c".$value[id]."_menu\" style=\"display: none\"><iframe name=\"c".$value[id]."_frame\" src=\"\" frameborder=\"0\" width=\"210\" height=\"148\" scrolling=\"no\"></iframe></span>",
			"<input type=\"text\" name=\"url[$value[id]]\" value=\"$value[url]\" class=\"td200\">",
			"",
            "<a href='" . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=cack_app_litebl&pmod=admincp_mhdh2sz&mod=del&id=$value[id]'>".$admincplang[5]."</a>",
                 "<input type=\"hidden\" name=\"id[$value[id]]\" value=\"$value[id]\">"
        ));
    }
        showtablerow('id="addnew"', array('width="100"', 'width="100"', 'width="200"', 'width="100"', 'width="100"', 'width="100"', 'width="100"'), array("", "<div><a href=\"###\" onclick=\"addnewrecord(this)\" class=\"addtr\">".$admincplang[14]."</a></div>", "", "", "", "")
        );
    showtablefooter(); /*dism��taobao��com*/
    showsubmit('bqsubmit');
    showformfooter(); /*DISM-TAOBAO-COM*/
	$lang6 = $admincplang[5];
    print <<<EOF
	<script type="text/JavaScript">
	var rowtypedata = [
		[[1,'<input type="text"  class="td25" name="newdisplayorder[]" value="0" />', 'td25'],
		[1,'<input type="text" size="80" class="td80"  name="newname[]" />', 'td100'],
		[1,'<input type="text" class="td200"  name="newzhaiyao[]" />', 'td200'],
		[1,'', ''], 
		
		[1,'<input type="text" class="td200" name="newurl[]"/>', ''], 
		[1,'', 'td100'],
		[1, '<div><a href="javascript:;" class="deleterow" onClick="deleterow(this)">$lang6</a></div>', '']],
	];
	var newrows = document.getElementsByClassName("data").length;	
	function addnewrecord(v) {
		newrows++;
		addrow(v, 0);
		
	}
				
	</script>
				
	<style>
	.td150 {width:150px;}
	.td100 {width:100px;}
    .td80 {width:80px;}
	</style>
EOF;
} else {
    if (is_array(dhtmlspecialchars($_GET['name']))) {
        foreach (dhtmlspecialchars($_GET['name']) as $key => $name) {
            if (empty($name)) {
                continue;
            }
            DB::update('cack_app_litebl_mhdh2sz', array('displayorder' => dhtmlspecialchars($_GET['displayorder'][$key]), 'name' => $name, 'pic' => dhtmlspecialchars($_GET['pic'][$key]) , 'zhaiyao' => dhtmlspecialchars($_GET['zhaiyao'][$key]), 'url' => dhtmlspecialchars($_GET['url'][$key])), array('id'=>intval($_GET['id'][$key])));
        }
        C::t('common_setting')->update('cack_app_litebl_mhdh2sz', $data);
    }
    if (is_array(dhtmlspecialchars($_GET['newname']))) {
        $data = array();
        foreach (dhtmlspecialchars($_GET['newname']) as $key => $newname) {
            if (empty($newname)) {
                continue;
            }
            DB::insert('cack_app_litebl_mhdh2sz', array('displayorder' => dhtmlspecialchars($_GET['newdisplayorder'][$key]), 'name' => dhtmlspecialchars($newname), 'zhaiyao' => dhtmlspecialchars($_GET['newzhaiyao'][$key]), 'pic' => dhtmlspecialchars($_GET['newpic'][$key]), 'url' => dhtmlspecialchars($_GET['newurl'][$key])));
        }
    }
    cpmsg($admincplang[7], 'action=plugins&operation=config&do=' . $pluginid . '&identifier=cack_app_litebl&pmod=admincp_mhdh2sz', 'succeed');
}