<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include 'source/plugin/cack_app_litebl/lang/'.currentlang().'.php';
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `cdb_cack_app_litebl_hdpsz` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `displayorder` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM ;

INSERT INTO `cdb_cack_app_litebl_hdpsz` (`id`, `pic`, `name`, `url`, `displayorder`) VALUES
('', 'template/cack_app_lite/touch/static/images/hdp1.jpg', '$admincplang[13]', '#', 1),
('', 'template/cack_app_lite/touch/static/images/hdp1.jpg', '$admincplang[13]', '#', 2),
('', 'template/cack_app_lite/touch/static/images/hdp1.jpg', '$admincplang[13]', '#', 3);


CREATE TABLE IF NOT EXISTS `cdb_cack_app_litebl_mhdh2sz` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) NOT NULL,
  `zhaiyao` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `displayorder` int(10) NOT NULL,
  `color` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM ;

INSERT INTO `cdb_cack_app_litebl_mhdh2sz` (`id`, `pic`, `zhaiyao`, `name`, `url`, `displayorder`, `color`) VALUES
('', '#3d8de8', '$admincplang[13]', '$admincplang[13]', '#', 1, ''),
('', '#42b680', '$admincplang[13]', '$admincplang[13]', '#', 2, ''),
('', '#f3c93f', '$admincplang[13]', '$admincplang[13]', '#', 3, '');


CREATE TABLE IF NOT EXISTS `cdb_cack_app_litebl_mhdhsz` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `displayorder` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM ;

INSERT INTO `cdb_cack_app_litebl_mhdhsz` (`id`, `pic`, `name`, `url`, `displayorder`) VALUES
('', 'template/cack_app_lite/touch/static/images/nav/b6.png', '$admincplang[13]', '#', 1),
('', 'template/cack_app_lite/touch/static/images/nav/c3.png', '$admincplang[13]', '#', 2),
('', 'template/cack_app_lite/touch/static/images/nav/b1.png', '$admincplang[13]', '#', 3),
('', 'template/cack_app_lite/touch/static/images/nav/b2.png', '$admincplang[13]', '#', 4),
('', 'template/cack_app_lite/touch/static/images/nav/b4.png', '$admincplang[13]', '#', 5),
('', 'template/cack_app_lite/touch/static/images/nav/b8.png', '$admincplang[13]', '#', 6),
('', 'template/cack_app_lite/touch/static/images/nav/b7.png', '$admincplang[13]', '#', 7),
('', 'template/cack_app_lite/touch/static/images/nav/c2.png', '$admincplang[13]', '#', 8);

CREATE TABLE IF NOT EXISTS `cdb_cack_app_litebl_header_dh2` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `pic` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `displayorder` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM ;

INSERT INTO `cdb_cack_app_litebl_header_dh2` (`id`, `pic`, `name`, `url`, `displayorder`) VALUES
('', 'template/cack_app_lite/touch/static/images/nav/b6.png', '$admincplang[13]', '#', 1),
('', 'template/cack_app_lite/touch/static/images/nav/c3.png', '$admincplang[13]', '#', 2),
('', 'template/cack_app_lite/touch/static/images/nav/b1.png', '$admincplang[13]', '#', 3),
('', 'template/cack_app_lite/touch/static/images/nav/b2.png', '$admincplang[13]', '#', 4),
('', 'template/cack_app_lite/touch/static/images/nav/b4.png', '$admincplang[13]', '#', 5),
('', 'template/cack_app_lite/touch/static/images/nav/b8.png', '$admincplang[13]', '#', 6),
('', 'template/cack_app_lite/touch/static/images/nav/b7.png', '$admincplang[13]', '#', 7),
('', 'template/cack_app_lite/touch/static/images/nav/c2.png', '$admincplang[13]', '#', 8);


EOF;
runquery($sql);
$finish = TRUE;
?>