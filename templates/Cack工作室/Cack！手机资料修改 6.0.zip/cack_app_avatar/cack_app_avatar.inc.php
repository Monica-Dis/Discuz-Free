<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if ($_G['uid']) {
    $defaultop = '';
    $profilegroup = C::t('common_setting')->fetch('profilegroup', true);
    foreach ($profilegroup as $key => $value) {
        if ($value['available']) {
            $defaultop = $key;
            break;
        }
    }
    $cgop = dhtmlspecialchars($_GET['op']);
    $cgid = dhtmlspecialchars($_GET['id']);
    $cgvid = dhtmlspecialchars($_GET['vid']);
    $operation = in_array($cgop, array('base', 'contact', 'edu', 'work', 'info', 'password', 'verify')) ? trim($cgop) : $defaultop;
    $space = getuserbyuid($_G['uid']);
    space_merge($space, 'field_home');
    space_merge($space, 'profile');
    list($seccodecheck, $secqaacheck) = seccheck('password');
    @(include_once DISCUZ_ROOT . './data/cache/cache_domain.php');
    $spacedomain = isset($rootdomain['home']) && $rootdomain['home'] ? $rootdomain['home'] : array();
    $cgid = $cgid ? preg_replace("/[^A-Za-z0-9_:]/", '', $cgid) : '';
    include_once libfile('function/profile');
    loadcache('profilesetting');
    if (empty($_G['cache']['profilesetting'])) {
        require_once libfile('function/cache');
        updatecache('profilesetting');
        loadcache('profilesetting');
    }
    space_merge($space, 'field_home');
    space_merge($space, 'field_forum');
    require_once libfile('function/editor');
    $space['sightml'] = html2bbcode($space['sightml']);
    $vid = $cgvid ? intval($cgvid) : 0;
    $privacy = $space['privacy']['profile'] ? $space['privacy']['profile'] : array();
    $_G['setting']['privacy'] = $_G['setting']['privacy'] ? $_G['setting']['privacy'] : array();
    $_G['setting']['privacy'] = is_array($_G['setting']['privacy']) ? $_G['setting']['privacy'] : dunserialize($_G['setting']['privacy']);
    $_G['setting']['privacy']['profile'] = !empty($_G['setting']['privacy']['profile']) ? $_G['setting']['privacy']['profile'] : array();
    $privacy = array_merge($_G['setting']['privacy']['profile'], $privacy);
    $actives = array('profile' => ' class="a"');
    $opactives = array($operation => ' class="a"');
    $allowitems = array();
    if (in_array($operation, array('base', 'contact', 'edu', 'work', 'info'))) {
        $allowitems = $profilegroup[$operation]['field'];
		$allowitems2 = $profilegroup[contact]['field'];
    } elseif ($operation == 'verify') {
        if ($vid == 0) {
            foreach ($_G['setting']['verify'] as $key => $setting) {
                if ($setting['available'] && (empty($setting['groupid']) || in_array($_G['groupid'], $setting['groupid']))) {
                    $cgvid = $vid = $key;
                    break;
                }
            }
        }
        if (empty($_G['setting']['verify'][$vid]['groupid']) || in_array($_G['groupid'], $_G['setting']['verify'][$vid]['groupid'])) {
            $actives = array('verify' => ' class="a"');
            $opactives = array($operation . $vid => ' class="a"');
            $allowitems = $_G['setting']['verify'][$vid]['field'];
        }
    }
    $showbtn = $vid && $verify['verify' . $vid] != 1 || empty($vid);
    if (!empty($verify) && is_array($verify)) {
        foreach ($verify as $key => $flag) {
            if (in_array($key, array('verify1', 'verify2', 'verify3', 'verify4', 'verify5', 'verify6', 'verify7')) && $flag == 1) {
                $verifyid = intval(substr($key, -1, 1));
                if ($_G['setting']['verify'][$verifyid]['available']) {
                    foreach ($_G['setting']['verify'][$verifyid]['field'] as $field) {
                        $_G['cache']['profilesetting'][$field]['unchangeable'] = 1;
                    }
                }
            }
        }
    }
    if ($vid) {
        if ($value = C::t('common_member_verify_info')->fetch_by_uid_verifytype($_G['uid'], $vid)) {
            $field = dunserialize($value['field']);
            foreach ($field as $key => $fvalue) {
                $space[$key] = $fvalue;
            }
        }
    }
    $htmls = $settings = array();
    foreach ($allowitems as $fieldid) {
        if (!in_array($fieldid, array('sightml', 'customstatus', 'timeoffset'))) {
            $html = profile_setting($fieldid, $space, $vid ? false : true);
            if ($html) {
                $settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
                $htmls[$fieldid] = $html;
            }
        }
    }
    foreach ($allowitems2 as $fieldid) {
        if (!in_array($fieldid, array('sightml', 'customstatus', 'timeoffset'))) {
            $html = profile_setting($fieldid, $space, $vid ? false : true);
            if ($html) {
                $settings[$fieldid] = $_G['cache']['profilesetting'][$fieldid];
                $htmls[$fieldid] = $html;
            }
        }
    }
    define('APP_ID', 'cack_app_avatar');
    define('APP_DIR', 'source/plugin/' . APP_ID);
    define('APP_URL', $_G['siteurl'] . 'plugin.php?id=' . APP_ID);
    define('CUR_PAGE', $_G['siteurl']);
    $config = $_G['cache']['plugin'][APP_ID];
	function myImageResize($k_path, $n_path = '', $n_width = 200, $n_height = 200, $fixed_orig = ''){
		$k_info = getimagesize($k_path);
		$k_width = $k_info[0];
		$k_height = $k_info[1];
		$k_mime = $k_info['mime'];
		$ratio_orig = $k_width / $k_height;
		if ($fixed_orig == 'width'){

			$n_height = $n_width / $ratio_orig;
		}elseif ($fixed_orig == 'height'){

			$n_width = $n_height * $ratio_orig;
		}else{

			if ($n_width / $n_height > $ratio_orig){
				$n_width = $n_height * $ratio_orig;
			}else{
				$n_height = $n_width / $ratio_orig;
			}
		}
		$new = imagecreatetruecolor($n_width, $n_height);
		$img=imagecreatefromjpeg($k_path);
		//copy部分图像并调整
		imagecopyresized($new, $img,0, 0,0, 0,$n_width, $n_height, $k_width, $k_height);
		//图像输出新图片、另存为
		imagejpeg($new, $n_path);
		imagedestroy($new);
		imagedestroy($img);
	}

	
    $uid = $_G['uid'];
	$profile['avatar'] = avatar($uid, 'middle', true);
	$profile['avatar_big'] = avatar($uid, 'big', true);
	$cgimage_file = dhtmlspecialchars($_GET['image_file']);
	$gimage_file = $cgimage_file;
	$cgm = dhtmlspecialchars($_GET['m']);
	$cgformhash = dhtmlspecialchars($_GET['formhash']);
	if ($gimage_file && $cgm == 'avatar' && $cgformhash == FORMHASH) {
		$imgdata = explode(',', $gimage_file);
		preg_match('/^(data:\\s*image\\/(\\w+);base64,)/', $gimage_file, $result);
		$mime = '.' . str_replace('jpeg', 'jpg', $result[2]);
		$imgdata = base64_decode($imgdata[1]);
		$basedir = DISCUZ_ROOT . $_G['setting']['attachurl'];
		$cache_ml = $basedir . APP_ID . '/' . $uid;
		@dmkdir($basedir . APP_ID);
		if(imagecreatefromstring($imgdata) !== false){
		file_put_contents($cache_ml, $imgdata);
		$dirs = sprintf("%09d", $uid);
		$dir = array(substr($dirs, 0, 3), substr($dirs, 3, 2), substr($dirs, 5, 2), substr($dirs, 7, 2));
		$avatar_ml = DISCUZ_ROOT . 'uc_server/data/avatar/' . $dir[0] . '/' . $dir[1] . '/' . $dir[2] . '/';
		@dmkdir($avatar_ml);
		myImageResize($cache_ml, $avatar_ml . $dir[3] . '_avatar_big.jpg', 200, 200);
		myImageResize($cache_ml, $avatar_ml . $dir[3] . '_avatar_middle.jpg', 120, 120);
		myImageResize($cache_ml, $avatar_ml . $dir[3] . '_avatar_small.jpg', 48, 48);
		@unlink($cache_ml);
		echo json_encode(array('status' => 1));
		}
	} else {
		if(!$_GET['xycache']){
			header("location:plugin.php?id=cack_app_avatar&xycache=1");
		
		}
		$uid = $_G['uid'];
		$dirs = sprintf("%09d", $uid);
		$dir = array(substr($dirs, 0, 3), substr($dirs, 3, 2), substr($dirs, 5, 2), substr($dirs, 7, 2));
		$avatar_ml = 'uc_server/data/avatar/' . $dir[0] . '/' . $dir[1] . '/' . $dir[2] . '/';
		
		include template('cack_app_avatar:index');
	}
} else {
    showmessage( null, null, array(), array('login' => 1));
}