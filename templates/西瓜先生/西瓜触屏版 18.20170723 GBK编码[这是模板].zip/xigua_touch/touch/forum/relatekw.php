<?php exit('xxxx');?>
<!--{template common/header}-->
<!--{if $return}-->
$return
<!--{/if}-->
<!--{template common/footer}-->
