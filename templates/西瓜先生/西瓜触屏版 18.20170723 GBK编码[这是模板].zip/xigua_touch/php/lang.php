<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
touch_it_touch();
function xtl($item)
{
	$lang = array('home' => '首页', 'portal' => '门户', 'forum' => '论坛', 'pic' => '美图', 'guide' => '导读', 'tag' => '标签', 'channel' => '频道', 'ts1' => '投票', 'ts2' => '商品', 'ts3' => '悬赏', 'ts4' => '活动', 'ts5' => '辩论', 'tdis' => '置顶', 'tatt' => '图片', 'post' => '发帖', 'thread' => '帖子', 'forum_' => '版块', 'profile' => '个人资料', 'favorite' => '我的收藏', 'doing' => '记录', 'follow' => '广播', 'friend' => '好友', 'friendall' => '全部', 'friendol' => '在线好友', 'friendbl' => '黑名单', 'friendrq' => '好友请求', 'friendprofile' => '资料', 'friendgroup' => '分组', 'efriend_doing' => '我和好友', 'friend_feed' => '好友动态', 'blog' => '日志', 'feed' => '动态', 'photo' => '相册', 'subfrm' => '子版块', 'thtys' => '分类', 'pta' => '发表于', 'acom' => '查看评论', 'tiao' => '条', 'tt' => '共有', 'close' => '关闭', 'mypm' => '我的消息', 'arc' => '文章', 'back' => '返回', 'search' => '搜索', 'searchportal' => '搜索文章', 'new_remind' => '有新提醒', 'zhengwen' => '正文', 'noid' => '没有账号?', 'yesid' => '已有账号?', 'load' => '加载更多', 'load_photo' => '查看更多图片', 'load_pic' => '加载中...', 'openhome' => '进入官网', 'indextopnav' => '网站导航', 'faxian' => '发现', 'fatie' => '发贴', 'fav' => '收藏', 'shuaxin' => '刷新', 'zhiding' => '置顶', 'jinghua' => '精华', 'liulan' => '浏览', 'wode' => '我的', 'zanwu' => '暂无版块简介', 'zuixin' => '最新', 'remen' => '热门', 'gengduocaozuo' => '更多操作', 'zhutifenlei' => '主题分类', 'frnlei' => '分类信息', 'gaoji' => '高级筛选', 'paixu' => '排序: ', 'huicha' => '回复/查看', 'fatieshijian' => '发帖时间', 'chakan' => '查看', 'shjian' => '时间', 'shijian1' => '全部时间', 'shijian2' => '一天', 'shijian3' => '两天', 'shijian4' => '一周', 'shijian5' => '一个月', 'shijian6' => '三个月', 'shijian7' => '一年', 'jinri' => '今日', 'tiezi' => '帖子', 'guanzhu' => '关注', 'guanzhu1' => '已关注', 'zhiding1' => '顶', 'quxiao' => '取消', 'fabuhui' => '发布回复', 'hui' => '回复', 'shezhi' => '设置标签', 'zid' => '自动获取', 'mp3' => '请输入MP3地址', 'tianjia' => '添加', 'grshi' => '支持mp3、m4a、ogg、wav等格式', 'mp4' => '请输入视频地址', 'mp4desc' => '支持优酷、腾讯、土豆等视频站的视频网址<br>支持 mp4、mov 等视频格式', 'jin' => '点击进入', 'zheng' => '正序', 'dao' => '倒序', 'ping' => '评论', 'kuai' => '还没有评论 快来说一句', 'xie' => '写评论...', 'xiu' => '修改资料', 'ren' => '认证中心', 'jifen' => '我的积分', 'wodetixing' => '我的提醒', 'shoufei' => '收费看贴', 'xiao' => '微信消息', 'da' => '打赏设置', 'c' => '积分充值', 't' => '积分提现', 'b' => '微信号绑定', 'toucheng' => '投票成功', 'qingxuan' => '请选择', 'bitain' => '必填项目没有填写', 'xia' => '请选择下一级', 'emailerr' => '邮件地址不正确', 'chang' => '填写项目长度过长', 'numerr' => '数字填写不正确', 'dayu' => '大于设置最大值', 'xiaoyu' => '小于设置最小值', 'http' => '请正确填写以http://开头的URL地址', 'fujian' => '附件类型被禁止', 'bun' => '不能超过', 'bit' => '字节', 'newthread' => '新贴', 'hot' => '热门', 'digget' => '精华', 'new' => '最新', 'myfav' => '我的收听', 'guangbo' => '广播大厅', 'postguangbo' => '发广播', 'buy' => '模版唯一购买地址：<a href="http://dism.taobao.com/?@xigua">http://dism.taobao.com/?@xigua</a>。如已购买，请联系客服QQ937987886，并提供网站地址:', 'datetime_format' => '日期格式', 'setanswer' => '您确认要把该回复选为“最佳答案”吗？');
	$item = $lang[$item];
	if (CHARSET == 'gbk') {
		return $item;
	}
	return diconv($item, 'GBK', CHARSET);
}
