<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined("IN_DISCUZ")) {
	exit("Access Denied");
}
touch_it_touch();
function x_s2($threadlist)
{
	$_G = $GLOBALS["_G"];
	if ($_G["cache"]["plugin"]["xigua_th"]["disfids"]) {
		$disfids = unserialize($_G["cache"]["plugin"]["xigua_th"]["disfids"]);
	}
	if (!$_REQUEST["fid"]) {
		foreach ($threadlist as $item) {
			$tids[] = $item["tid"];
		}
		touch_get_addviews($tids, $threadlist);
	}
	if (!$_G["cache"]["usergroups"]) {
		loadcache("usergroups");
	}
	$hideinforum = unserialize($_G["cache"]["plugin"]["xigua_th"]["hideinforum"]);
	$piclist = $uids = array();
	foreach ($threadlist as $k => $item) {
		if ($item["displayorder"] <= 0) {
			if ($_REQUEST["fid"] || !in_array($item["fid"], $hideinforum)) {
				$ogpiclist = $sizelist = array();
				$tid = $item["tid"];
				$uid = $item["authorid"];
				if (!in_array($item["fid"], $disfids)) {
					$posttableid = table_forum_post::get_tablename("tid:" . $tid);
					$tmp = DB::fetch_first("SELECT pid FROM %t WHERE tid=%d AND first=1 AND invisible=0 LIMIT 1", array($posttableid, $tid));
					$pid = $tmp["pid"];
					$reys = C::t("forum_attachment_n")->fetch_all_by_id("tid:" . $tid, "pid", $pid, "aid ASC", true, false, false, 3);
					foreach ($reys as $index => $row) {
						if ($_G["cache"]["plugin"]["xigua_th"]["showgif"] || strpos($row["attachment"], ".gif") === false) {
							if ($row["attachment"]) {
								$piclist[$tid][] = x_get_picurl($row["thumb"] ? getimgthumbname($row["attachment"]) : $row["attachment"], $row["remote"]);
								$ogpiclist[$tid][] = x_get_picurl($row["attachment"], $row["remote"]);
								$sizelist[$tid][] = $row["width"];
							}
						}
					}
					if (count($piclist[$tid]) == 1) {
						$piclist[$tid] = $ogpiclist[$tid];
					}
					if ($_G["cache"]["plugin"]["xigua_th"]["allowimgtag"] && count($piclist[$tid]) < 3) {
						$message = DB::result_first("SELECT message FROM %t WHERE pid=%d LIMIT 1", array($posttableid, $pid));
						if (strpos($message, "[/hide]") !== false) {
							$message = preg_replace("/\\[hide\\].*?\\[\\/hide\\]/i", "", $message);
						}
						if (strpos($message, "[/img]") !== false) {
							$pattern = "/\\[img.*?\\](.*?)\\[\\/img\\]/i";
							preg_match_all($pattern, $message, $matchsimg);
							$piclist[$tid] = array_slice($matchsimg[1], 0, 3);
							foreach ($piclist[$tid] as $kkkk => $vvvv) {
								if (strpos($vvvv, "mobcent/") !== false) {
									$piclist[$tid][$kkkk] = "";
								}
								if (!$_G["cache"]["plugin"]["xigua_th"]["showgif"] && strpos($vvvv, ".gif") !== false) {
									$piclist[$tid][$kkkk] = "";
								}
							}
						}
					}
				}
				if ($lastpost = strtotime($item["lastpost"])) {
					$threadlist[$k]["lastpost"] = date("m-d H:i", $lastpost);
				} else {
					$threadlist[$k]["lastpost"] = str_replace("&nbsp;", "", $item["lastpost"]);
				}
				$threadlist[$k]["typename"] = $item["typeid"] ? $_G["forum"]["threadtypes"]["types"][$item["typeid"]] : "";
				$threadlist[$k]["attach"] = $piclist[$tid];
				$threadlist[$k]["attach_size"] = $sizelist[$tid];
				$threadlist[$k]["sorthtml"] = $item["sorthtml"] ? str_replace(array("[", "]"), "", $item["sorthtml"]) : "";
				$uids[$item["authorid"]] = $item["authorid"];
			} else {
				$threadlist[$k] = array();
			}
		}
	}
	if ($uids) {
		$genders = DB::fetch_all("SELECT uid,gender FROM %t WHERE uid IN (%n)", array("common_member_profile", $uids), "uid");
		$users = DB::fetch_all("SELECT groupid,uid FROM %t WHERE uid IN (%n)", array("common_member", $uids), "uid");
		foreach ($threadlist as $index => $item) {
			$threadlist[$index]["gender"] = $genders[$item["authorid"]]["gender"];
			$threadlist[$index]["iconid"] = $_G["cache"]["usergroups"][$users[$item["authorid"]]["groupid"]]["grouptitle"];
			$threadlist[$index]["groupid"] = $users[$item["authorid"]]["groupid"];
		}
	}
	return $threadlist;
}
function touch_it_touch()
{
/*	$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER["SERVER_PORT"] == "443" ? "https://" : "http://";
	$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER["HTTP_HOST"] : "");
	$url = rtrim($url, "/") . "/";
	$key = "to" . substr(md5($GLOBALS["_G"]["siteurl"] . "xigua_touch"), 0, 10);
	loadcache($key);
	$data = $GLOBALS["_G"]["cache"][$key] ? $GLOBALS["_G"]["cache"][$key] : array();
	if ($data["deadline"] <= TIMESTAMP) {
		$data["deadline"] = TIMESTAMP + 86400;
		@($ret = dfsockopen("http://115.28.190.3/demo/api/template_check.php?url=" . urlencode($url)));
		if (!$ret) {
			$ret = file_get_contents("http://115.28.190.3/demo/api/template_check.php?url=" . urlencode($url));
		}
		$data["rescode"] = $ret;
		save_syscache($key, $data);
	}
	if ($data["rescode"] != md5(md5(date("Y") . "ran44@9!!7&!&&@#~~:LLdom" . $url))) {
		save_syscache($key, array());
		exit($url . " ");
		exit(0);
		@output_by_touch($url);
	}
*/
}
function x_get_picurl($pic, $remote = 0)
{
	$_G = $GLOBALS["_G"];
	if (!$pic) {
		return "";
	}
	if (x_is_picurl($pic)) {
		return $pic;
	}
	if (strpos($pic, "forum.php") !== false) {
		return $_G["siteurl"] . $pic;
	}
	if ($remote) {
		$attach__ = $_G["setting"]["ftp"]["attachurl"] . "forum/" . $pic;
	} else {
		$pic = $_G["setting"]["attachurl"] . "forum/" . $pic;
		if (x_is_picurl($pic)) {
			return $pic;
		}
		$attach__ = $_G["siteurl"] . $pic;
	}
	return $attach__;
}
function x_is_picurl($pic)
{
	return in_array(strtolower(substr($pic, 0, 6)), array("http:/", "https:", "ftp://"));
}
function usergroup_iconid($groupid)
{
	$_G = $GLOBALS["_G"];
	if (!$_G["cache"]["usergroups"]) {
		loadcache("usergroups");
	}
	if (!$GLOBALS["xusergroup_iconid"]) {
		$memberi = 0;
		foreach ($_G["cache"]["usergroups"] as $k => $data) {
			if ($data["type"] == "member") {
				if (!$memberi && $k == $_G["setting"]["newusergroupid"]) {
					$memberi = 1;
				}
				if ($memberi > 0) {
					$GLOBALS["xusergroup_iconid"][$k] = ($memberi = $memberi + 1) + -1;
				}
			} else {
				if ($data["type"] == "system" && $k < 4) {
					$GLOBALS["xusergroup_iconid"][$k] = "admin";
				} else {
					if ($data["type"] == "special") {
						$GLOBALS["xusergroup_iconid"][$k] = "special";
					}
				}
			}
		}
	}
	return $GLOBALS["xusergroup_iconid"][$groupid];
}
function touch_get_addviews($tids, $indexlist)
{
	foreach (C::t("forum_threadaddviews")->fetch_all($tids) as $tidkey => $value) {
		$indexlist[$tidkey]["views"] += $value["addviews"];
	}
	return $indexlist;
}