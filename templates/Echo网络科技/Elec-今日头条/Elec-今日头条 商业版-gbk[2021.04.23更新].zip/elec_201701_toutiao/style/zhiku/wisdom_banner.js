/**
 * Created by Administrator on 2017-5-17.
 * �ǿ� ��ҳ�ֲ�ͼ����ҳ�������list��ɸѡ
 */

/*banner��ʼ ******************************************************************** */
Vue.component("wisdom-banner",{
    props:["list"],
    template:'<div class=" wisdom_banner">'+
    '<div class="banner_in clearfix">'+
    ' <div class="l_phone">'+
    ' <div class="swiper-container swiper-container1">'+
    ' <div class="swiper-wrapper">'+
    ' <a :href="\'in\' + item.thinkTankId + \'.html\'" class="swiper-slide" v-for="item in list" target="_blank" :style="\'background-image:url(\'+item.coverUrl+\'?x-oss-process=style/thinktank-swipe)\'"> </a>'+
' </div>'+
' </div>'+
' </div>'+
' <div class="r_phone">'+
'  <img class="left_arr" src="../image/left_arr.png" alt="">'+
' <div class="swiper-container swiper-container2">'+
' <div class="swiper-wrapper">'+
' <div class="swiper-slide" v-for="item in list" >'+
' <a :href="\'in\' + item.thinkTankId + \'.html\'" target="_blank">'+
    ' <h6>{{item.title}}</h6>'+
    ' <p class="r_phone_p">{{item.summary}}</p>'+
    ' <div class="clearfix r_phone_b">'+
    ' <div>�鿴����</div>'+
    ' <div class="p_time">{{item.publishDate}}</div>'+
    '</div>'+
    ' </a>'+
    ' </div>'+
    ' </div>'+
'  </div>'+
    '<div class="swiper-pagination" ></div>'+
' </div>'+
' </div>'+
/*'<div class="swiper-container swiper-container3" >'+
' <div class="swiper-wrapper">'+
' <div class="swiper-slide" v-for="item in list"> </div>'+
    '</div>'+
    '<div class="swiper-pagination" dir="rtl"></div>'+
'</div>'+*/
'</div> '

});
jQuery(function(){
    var Swiper1 = new Swiper('.swiper-container1',{
        loop:true,
        watchActiveIndex : true,
        onlyExternal : true
        /*onSlideTouch: function() {
            Swiper2.swipeTo(Swiper1.activeLoopIndex);
        }*/
    });

    var Swiper2 = new Swiper('.swiper-container2',{
        loop:true,
        autoplay: 6000,
        paginationClickable :true,
        watchActiveIndex : true,
        pagination : '.swiper-pagination',
        effect : 'slide',
        autoplayDisableOnInteraction : false,
        onSlideChangeStart:function() {
            Swiper1.swipeTo(Swiper2.activeLoopIndex);
        }
    });

    jQuery(".wisdom_banner").mouseenter(function () {
        Swiper1.stopAutoplay();
        Swiper2.stopAutoplay();
    }).mouseleave(function(){
        Swiper1.startAutoplay();
        Swiper2.startAutoplay();
    });

   /* Swiper1.params.control = Swiper2;
    Swiper2.params.control = Swiper1;*/

   /* Swiper1.params.control = Swiper3;
    Swiper2.params.control = Swiper3;*/
    jQuery(".r_phone_p").each(function(index, el) {
        if(jQuery(el).html().length>100){
            var innerHtml =jQuery(el).html().split("");
            innerHtml.length=100;
            innerHtml.push("...");
            jQuery(el).html(innerHtml.join(''));
        }
    });
})

/*banner���� ******************************************************************** */

/*��ҳ�������list��ʼ*************************************************************/
Vue.component("data-list",{
    props:["datal","namel","hrefl","ifone"],
    template:'<div>'+
        '<div class="list_tit clearfix">'+
        '<div class="list_tit_l">{{namel}}</div>'+
        '<a :href="hrefl" target="_blank">�鿴����</a>'+
        '</div>'+
        '<ul class="data_list clearfix">'+
        '<li v-for="init in datal">'+
    '<a :href="\'in\' + init.thinkTankId + \'.html\'" target="_blank">'+
        '<div class="data_img" :style=" \'background-image:url(\'+init.coverUrl+\'?x-oss-process=style/thinktank-list)\'">'+
'</div>'+
'<h6 class="data_tit" :class="{case_data_tit:ifone}">{{init.title}}</h6>'+
'<div class="data_time">{{init.publishTime}} </div>'+
'</a>'+
'</li>'+
' </ul> '+
'</div>'
});

/*��ҳ�������list����*************************************************************/




