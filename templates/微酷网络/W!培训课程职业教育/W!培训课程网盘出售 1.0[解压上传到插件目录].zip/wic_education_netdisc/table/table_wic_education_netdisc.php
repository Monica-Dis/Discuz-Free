<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wic_education_netdisc extends discuz_table
{
	public function __construct() {

		$this->_table = 'wic_education_netdisc';
		$this->_pk    = 'id';

		parent::__construct();
	}

	public function count_by_uid_tid($uid,$tid) {
		return DB::result_first('SELECT count(*) FROM %t WHERE uid = %d AND tid= %d', array($this->_table,$uid,$tid));
	}
	
	



}
//From: Dism��taobao��com
?>