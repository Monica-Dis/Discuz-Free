<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wic_education_netdisc {

}


class plugin_wic_education_netdisc_forum extends plugin_wic_education_netdisc{
	
	function viewthread_posttop_output(){
		
		global $_G, $threadsortshow;
	
		
		$config = $_G['cache']['plugin']['wic_education_netdisc'];
		$sortid = intval($config['wic_education_id']);
		$usergroups = dunserialize($config['wic_usergroups']);
		$credit = $config['wic_sale_credit_type'] ? $config['wic_sale_credit_type'] : 1;
		
		if( $_G['thread']['sortid'] && $sortid && $_G['thread']['sortid'] == $sortid ){
			
			$price = intval($threadsortshow['optionlist']['course_price']['value']);
			$extraction_code = addslashes($threadsortshow['optionlist']['course_extraction_code']['value']);
			$buy_url = dhtmlspecialchars($threadsortshow['optionlist']['course_buy_url']['value']);
			
			$buy_already = C::t('#wic_education_netdisc#wic_education_netdisc')->count_by_uid_tid($_G['uid'],$_G['tid']);
			
			
			if( !$_G['uid'] ){
				
				$code=lang('plugin/wic_education_netdisc','look_after_buy');
				$url='<a href="member.php?mod=logging&action=login" target="_blank">'.lang('plugin/wic_education_netdisc','buy_now').'</a>';
			}else{
				if( $_G['thread']['authorid'] == $_G['uid'] || $buy_already || in_array( $_G['groupid'],$usergroups ) ){
				
					$code=$extraction_code;
					$url='<a href="'.$buy_url.'" target="_blank">'.lang('plugin/wic_education_netdisc','click_download').'</a>';
					
					
				}else{
					$code=lang('plugin/wic_education_netdisc','look_after_buy');
					$url = '<a href="javascript:;" onclick="showWindow(\'wic_buybox\', \'plugin.php?id=wic_education_netdisc&ac=buy&tid='.$_G['tid'].'&formhash='.FORMHASH.'\');">'.lang('plugin/wic_education_netdisc','buy_now').'</a>';
					
				}
			}
			
			
			
			$threadsortshow['typetemplate'] = str_replace("{code}", $code, $threadsortshow['typetemplate']);
			$threadsortshow['typetemplate'] = str_replace("{url}", $url, $threadsortshow['typetemplate']);
			
		}
		
		
	}
	
	
	
	
	
	
	
	
}

class mobileplugin_wic_education_netdisc {
	
}

class mobileplugin_wic_education_netdisc_forum extends mobileplugin_wic_education_netdisc {
	
	function viewthread_posttop_mobile_output(){
		
		global $_G, $threadsortshow;
		
	
		
		$config = $_G['cache']['plugin']['wic_education_netdisc'];
		$sortid = intval($config['wic_education_id']);
		$usergroups = dunserialize($config['wic_usergroups']);
		$credit = $config['wic_sale_credit_type'] ? $config['wic_sale_credit_type'] : 1;
		
		if( $_G['thread']['sortid'] && $sortid && $_G['thread']['sortid'] == $sortid ){
			
			$price = intval($threadsortshow['optionlist']['course_price']['value']);
			$extraction_code = addslashes($threadsortshow['optionlist']['course_extraction_code']['value']);
			$buy_url = dhtmlspecialchars($threadsortshow['optionlist']['course_buy_url']['value']);
			
			$buy_already = C::t('#wic_education_netdisc#wic_education_netdisc')->count_by_uid_tid($_G['uid'],$_G['tid']);
			
			if( !$_G['uid'] ){
				
				$code=lang('plugin/wic_education_netdisc','look_after_buy');
				$url='<a href="member.php?mod=logging&action=login" target="_blank">'.lang('plugin/wic_education_netdisc','buy_now').'</a>';
			}else{
				if( $_G['thread']['authorid'] == $_G['uid'] || $buy_already || in_array( $_G['groupid'],$usergroups ) ){
				
					$code=$extraction_code;
					$url='<a href="'.$buy_url.'" target="_blank">'.lang('plugin/wic_education_netdisc','click_download').'</a>';
					
					
				}else{
					$code=lang('plugin/wic_education_netdisc','look_after_buy');
					$url = '<a href="plugin.php?id=wic_education_netdisc&ac=buy&tid='.$_G['tid'].'&formhash='.FORMHASH.'" class="dialog">'.lang('plugin/wic_education_netdisc','buy_now').'</a>';
					
				}
			}
			
			
			
			$threadsortshow['typetemplate'] = str_replace("{code}", $code, $threadsortshow['typetemplate']);
			$threadsortshow['typetemplate'] = str_replace("{url}", $url, $threadsortshow['typetemplate']);
			
		}
		
		
	}
	
	
}
//From: Dism��taobao��com
?>