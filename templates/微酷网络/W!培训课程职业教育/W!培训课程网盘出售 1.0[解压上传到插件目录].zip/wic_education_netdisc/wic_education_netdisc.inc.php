<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$ac = in_array($_GET['ac'],array('buy')) ? $_GET['ac'] : 'buy';


if( $_GET['formhash'] != FORMHASH || !$_G['uid'] || !$_GET['tid'] ){
	showmessage(lang('plugin/wic_education_netdisc','illegal_submission'));
}else{
	$uid = $_G['uid'];
	$tid = intval($_GET['tid']);
	$config = $_G['cache']['plugin']['wic_education_netdisc'];
	$credit = $config['wic_sale_credit_type'] ? $config['wic_sale_credit_type'] : 1;
	$recharge_url = $config['wic_credit_recharge_url'] ? daddslashes($config['wic_credit_recharge_url']) : 'home.php?mod=spacecp&ac=credit&op=buy';
	$credit_name = $_G['setting']['extcredits'][$credit]['title'];
	$current_user_credits = getuserprofile('extcredits'.$credit);
	$price = DB::result_first("SELECT a.value FROM ".DB::table('forum_typeoptionvar')." a LEFT JOIN ".DB::table('forum_typeoption')." b ON a.optionid=b.optionid WHERE b.identifier='course_price' AND a.tid=".$tid);
	$price = intval($price);
	if( $current_user_credits < $price ) showmessage(lang('plugin/wic_education_netdisc','notenough_recharge'),'',array('credit_name'=>$credit_name,'recharge_url'=>'<a href="'.$recharge_url.'">'.lang('plugin/wic_education_netdisc','recharge_immediately').'</a>'));
	
	$thread = C::t('forum_thread')->fetch($tid);
	$authorid = $thread['authorid'];
	
	if ( $price ) {
    	$data = array(
			'uid' => $uid,
			'tid' => $tid,
			'buy_time' => $_G['timestamp'],
        );
    	C::t('#wic_education_netdisc#wic_education_netdisc')->insert($data);
		updatemembercount($uid, array('extcredits'.$credit => '-'.$price), true,'BTC', $tid);
		updatemembercount($authorid, array('extcredits'.$credit => '+'.$price), true,'STC', $tid);
    	showmessage(lang('plugin/wic_education_netdisc','buy_success'), "forum.php?mod=viewthread&tid=$tid", array(), array('alert' => 'right','showdialog' => 1,'locationtime' => 3));
	} else {
		showmessage(lang('plugin/wic_education_netdisc','price_error'), array(), array(), array('alert' => 'info'));
	}
}
//From: Dism��taobao��com
?>