<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS pre_wic_education_touch_setting_nav (
  id smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  url varchar(255) NOT NULL,
  iconcode varchar(255) NOT NULL,
  available tinyint(1) NOT NULL DEFAULT '0',
  displayorder tinyint(3) NOT NULL,
  `navtype` tinyint(1) NOT NULL default '0',
  PRIMARY KEY (id),
  KEY `navtype` (`navtype`)
) ENGINE=MyISAM;



CREATE TABLE IF NOT EXISTS pre_wic_education_touch_setting_menu (
  id smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  title varchar(255) NOT NULL,
  color varchar(255) NOT NULL,
  url varchar(255) NOT NULL,
  available tinyint(1) NOT NULL DEFAULT '0',
  displayorder tinyint(3) NOT NULL,
  logo varchar(255) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM;


CREATE TABLE IF NOT EXISTS pre_wic_education_touch_setting_postmenu (
  id smallint(6) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  iconcode varchar(255) NOT NULL,
  bgcolor varchar(255) NOT NULL,
  color varchar(255) NOT NULL,
  url varchar(255) NOT NULL,
  available tinyint(1) NOT NULL DEFAULT '0',
  displayorder tinyint(3) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=MyISAM;



INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('1', '$installlang[nav_index]', 'portal.php?mod=index', 'index', '1', '0', '0');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('2', '$installlang[nav_forum]', 'forum.php?forumlist=1', 'forum', '1', '0', '0');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('3', '$installlang[nav_search]', 'search.php?mod=forum', 'search', '1', '0', '0');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('4', '$installlang[nav_tag]', 'misc.php?mod=tag', 'tag', '1', '0', '0');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('5', '$installlang[nav_group]', 'group.php', 'group', '1', '0', '0');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('6', '$installlang[nav_vip]', 'plugin.php?id=wic_education_touch_setting:vip', 'vip', '1', '0', '0');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('7', '$installlang[nav_about]', 'plugin.php?id=wic_education_touch_setting:aboutus', 'aboutus', '1', '0', '0');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('8', '$installlang[nav_index]', 'portal.php?mod=index', 'index', '1', '0', '1');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('9', '$installlang[nav_forum]', 'forum.php?forumlist=1', 'forum', '1', '0', '1');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('10', '$installlang[nav_group]', 'group.php', 'group', '1', '0', '1');
INSERT INTO `pre_wic_education_touch_setting_nav` VALUES ('11', '$installlang[nav_my]', 'home.php?mod=space&do=profile&mycenter=1', 'user', '1', '0', '1');



INSERT INTO `pre_wic_education_touch_setting_postmenu` VALUES ('1', '$installlang[postmenu_post]', 'forum', '#73B2D4', '', 'forum.php?mod=misc&action=nav', '1', '0');
INSERT INTO `pre_wic_education_touch_setting_postmenu` VALUES ('2', '$installlang[postmenu_newsbroke]', 'news', '#F3A53E', '', 'portal.php?mod=list&catid=1', '1', '0');
INSERT INTO `pre_wic_education_touch_setting_postmenu` VALUES ('3', '$installlang[postmenu_circletalk]', 'group', '#E37465', '', 'group.php', '1', '0');
INSERT INTO `pre_wic_education_touch_setting_postmenu` VALUES ('4', '$installlang[postmenu_writelog]', 'blog', '#CF5C7F', '', 'home.php?mod=space&do=blog&view=all', '1', '0');
INSERT INTO `pre_wic_education_touch_setting_postmenu` VALUES ('5', '$installlang[postmenu_remembermood]', 'record', '#E05E4E', '', 'home.php?mod=space&do=doing', '1', '0');
INSERT INTO `pre_wic_education_touch_setting_postmenu` VALUES ('6', '$installlang[postmenu_transferpic]', 'camera', '#E27566', '', 'home.php?mod=space&do=album', '1', '0');
INSERT INTO `pre_wic_education_touch_setting_postmenu` VALUES ('7', '$installlang[postmenu_music]', 'music', '#62B486', '', '#', '1', '0');
INSERT INTO `pre_wic_education_touch_setting_postmenu` VALUES ('8', '$installlang[postmenu_video]', 'shipin', '#72B2D6', '', '#', '1', '0');


EOF;

runquery($sql);

require_once libfile('function/cache');


foreach(C::t('#wic_education_touch_setting#wic_education_touch_setting_nav')->fetch_all_data() as $nav) {
	$navlist[$nav['id']] = $nav;   
}
savecache('wic_education_touch_setting_nav', $navlist);


foreach( C::t('#wic_education_touch_setting#wic_education_touch_setting_postmenu')->fetch_all_data() as $postmenu ){
	$postmenulist[$postmenu['id']] = $postmenu;
}
savecache('wic_education_touch_setting_post', $postmenulist);

$finish = TRUE;

?>