<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



$op = in_array($_GET['op'],array('sidenav','footernav')) ? $_GET['op'] : 'sidenav'; 

$navtype = $op == 'sidenav' ? 0 : 1 ;

showsubmenu_sub('', array(
    array(lang('plugin/wic_education_touch_setting','sidenav'), "plugins&operation=config&do=$pluginid&identifier=$plugin[identifier]&pmod=$module[name]&op=setting", $op == 'sidenav'),
    array(lang('plugin/wic_education_touch_setting','footernav'), "plugins&operation=config&do=$pluginid&identifier=$plugin[identifier]&pmod=$module[name]&op=footernav", $op == 'footernav'),

));



	
	
	
if(!submitcheck('submit')){

	showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&op='.$op);
	showtableheader();
	showsubtitle(
		array(
			'del', 
			lang('plugin/wic_education_touch_setting', 'displayorder'), 
			lang('plugin/wic_education_touch_setting', 'name'), 
			lang('plugin/wic_education_touch_setting', 'url'), 
			lang('plugin/wic_education_touch_setting', 'icon_code'), 
			lang('plugin/wic_education_touch_setting', 'available'),
		)
	);
	showtagheader('tbody', '', true);
	
	$navlist = array();
	
	
	
	foreach( C::t('#wic_education_touch_setting#wic_education_touch_setting_nav')->fetch_all_by_navtype($navtype) as $nav ){
		
		$navlist[$nav['id']] = $nav;
		
	}
	
	foreach($navlist as $nav) {
		if($nav['available'] < 0) {
			continue;
		}
		showtablerow('', array('class="td25"', 'class="td25"', '', '', '','',''), array(
			"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$nav[id]\">",
			"<input type=\"text\" class=\"txt\" size=\"2\" name=\"displayordernew[$nav[id]]\" value=\"$nav[displayorder]\">",
			"<input type=\"text\" class=\"txt\" size=\"15\" name=\"namenew[$nav[id]]\" value=\"".dhtmlspecialchars($nav['name'])."\">",
			"<input type=\"text\" class=\"txt\" size=\"15\" name=\"urlnew[$nav[id]]\" value=\"".dhtmlspecialchars($nav['url'])."\">",
			"<input type=\"text\" class=\"txt\" size=\"15\" name=\"iconcodenew[$nav[id]]\" value=\"".dhtmlspecialchars($nav['iconcode'])."\">",
			"<input class=\"checkbox\" type=\"checkbox\" name=\"availablenew[$nav[id]]\" value=\"1\" ".($nav['available'] > 0 ? 'checked' : '').">",
		));
	}
	showtagfooter('tbody');
	echo '<tr><td colspan="1"></td><td colspan="6"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.lang('plugin/wic_education_touch_setting', 'add_nav').'</a></div></td></tr>';
	showsubmit('submit', 'submit', 'del');
	showtablefooter();/*dis'.'m.tao'.'bao.com*/
	showformfooter();/*dism��taobao��com*/
	

	echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
[
	[1, '', 'td25'], 
	[1, '<input name="newdisplayorder[]" value="" size="2" type="text" class="txt">', 'td25'], 
	[1, '<input name="newname[]" value="" size="15" type="text" class="txt">'],
	[1, '<input name="newurl[]" value="" size="15" type="text" class="txt">'],
	[1, '<input name="newiconcode[]" value="" size="15" type="text" class="txt">'],
],
];
</script>
EOT;


}else{

	if($ids = dimplode($_GET['delete'])) {
	

		
		C::t('#wic_education_touch_setting#wic_education_touch_setting_nav')->delete_by_navtype_id($navtype, $_GET['delete']);
		
		
		
	}

	if(is_array($_GET['namenew'])) {
		foreach($_GET['namenew'] as $id => $name) {


			$name = trim(dhtmlspecialchars($name));
			$urlnew = str_replace(array('&amp;'), array('&'), dhtmlspecialchars($_GET['urlnew'][$id]));
			$iconcodenew = trim(dhtmlspecialchars($_GET['iconcodenew'][$id]));
			$availablenew[$id] = $name && (!isset($_GET['urlnew'][$id]) || $_GET['urlnew'][$id]) && $_GET['availablenew'][$id];
			$displayordernew[$id] = intval($_GET['displayordernew'][$id]);
			$updatedata[$id] = array(
            		'name' => $name,
                    'url' => $urlnew,
                    'iconcode' => $iconcodenew,
					'displayorder' => $displayordernew[$id],
					'available' => $availablenew[$id],
				);
		}
        C::t('#wic_education_touch_setting#wic_education_touch_setting_nav')->update_all($updatedata);
	}


	if( is_array($_GET['newname'])) {
		foreach($_GET['newname'] as $k => $v) {
			$v = dhtmlspecialchars(trim($v));
			if(!empty($v)) {
				$newavailable = $v && $_GET['newurl'][$k];
				$newdisplayorder[$k] = intval($_GET['newdisplayorder'][$k]);
				$newurl[$k] = str_replace('&amp;', '&', dhtmlspecialchars($_GET['newurl'][$k]));
				$newiconcode[$k] = trim(dhtmlspecialchars($_GET['newiconcode'][$k]));
				$insertdata[] = array(
					'name' => $v,
					'displayorder' => $newdisplayorder[$k],
					'url' => $newurl[$k],
					'iconcode' => $newiconcode[$k],
					'available' => $newavailable,
					'navtype' => $navtype
				);
			}
		}
        if( $insertdata ) C::t('#wic_education_touch_setting#wic_education_touch_setting_nav')->insert_all($insertdata);
	}
	
	updatecache_nav();
	cpmsg(lang('plugin/wic_education_touch_setting', 'add_succeed'), 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&op='.$op, 'succeed');
}
	

	



	







function updatecache_nav() {

	require_once libfile('function/cache');
	$navlist = array();
    foreach(C::t('#wic_education_touch_setting#wic_education_touch_setting_nav')->fetch_all_data() as $nav) {
        
        $navlist[$nav['id']] = $nav;
        
    }
	savecache('wic_education_touch_setting_nav', $navlist);
}


function showsubmenu_sub($title, $menus = array(), $right = '', $replace = array()) {
	if(empty($menus)) {
		$s = '<div class="itemtitle">'.$right.'</div>';
	} elseif(is_array($menus)) {
		$s = '<div class="itemtitle">'.$right.'<ul class="tab1">';
		foreach($menus as $k => $menu) {
			if(is_array($menu[0])) {
				$s .= '<li id="addjs'.$k.'" class="'.($menu[1] ? 'current' : 'hasdropmenu').'" onmouseover="dropmenu(this);"><a href="#"><span>'.cplang($menu[0]['menu']).'<em>&nbsp;&nbsp;</em></span></a><div id="addjs'.$k.'child" class="dropmenu" style="display:none;">';
				if(is_array($menu[0]['submenu'])) {
					foreach($menu[0]['submenu'] as $submenu) {
						$s .= $submenu[1] ? '<a href="'.ADMINSCRIPT.'?action='.$submenu[1].'" class="'.($submenu[2] ? 'current' : '').'" onclick="'.$submenu[3].'">'.cplang($submenu[0]).'</a>' : '<a><b>'.cplang($submenu[0]).'</b></a>';
					}
				}
				$s .= '</div></li>';
			} else {
				$s .= '<li'.($menu[2] ? ' class="current"' : '').'><a href="'.(!$menu[4] ? ADMINSCRIPT.'?action='.$menu[1] : $menu[1]).'"'.(!empty($menu[3]) ? ' target="_blank"' : '').'><span>'.cplang($menu[0]).'</span></a></li>';
			}
		}
		$s .= '</ul></div>';
	}
	echo !empty($menus) ? '<div class="floatsub">'.$s.'</div>' : $s;
}


//From: Dism_taobao-com
?>