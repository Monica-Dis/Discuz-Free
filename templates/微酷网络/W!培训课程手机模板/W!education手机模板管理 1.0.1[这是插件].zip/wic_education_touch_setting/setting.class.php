<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_wic_education_touch_setting {
	
	function global_header_mobile(){
		
		global $_G;
		
		loadcache('wic_education_touch_setting_nav');
		loadcache('wic_education_touch_setting_menu');
		loadcache('wic_education_touch_setting_post');

		$config = array();
		
		$config = $_G['cache']['plugin']['wic_education_touch_setting'];


		foreach( explode("\r\n",$config['wic_education_touch_setting_section']) as $k => $v ){
			$v = explode("|",$v);
			$_G['setting']['wic_education_touch_setting']['section'][$k]['name'] = $v[0];
			$_G['setting']['wic_education_touch_setting']['section'][$k]['url'] = $v[1];
		}
		
			
		$_G['setting']['wic_education_touch_setting']['sitename'] = $config['wic_education_touch_setting_sitename'];
		$_G['setting']['wic_education_touch_setting']['sitelogo'] = $config['wic_education_touch_setting_sitelogo'];
		$_G['setting']['wic_education_touch_setting']['indexbanner'] = $config['wic_education_touch_setting_indexbanner'];
		$_G['setting']['wic_education_touch_setting']['indexheadline'] = $config['wic_education_touch_setting_indexhead'];
		$_G['setting']['wic_education_touch_setting']['indexblock1'] = explode("|",$config['wic_education_touch_setting_indexblock1']);
		$_G['setting']['wic_education_touch_setting']['indexblock2'] = explode("|",$config['wic_education_touch_setting_indexblock2']);
		$_G['setting']['wic_education_touch_setting']['indexblock3'] = explode("|",$config['wic_education_touch_setting_indexblock3']);
		$_G['setting']['wic_education_touch_setting']['indexblock4'] = explode("|",$config['wic_education_touch_setting_indexblock4']);
		$_G['setting']['wic_education_touch_setting']['indexblock5'] = explode("|",$config['wic_education_touch_setting_indexblock5']);
		$_G['setting']['wic_education_touch_setting']['indexblock6'] = explode("|",$config['wic_education_touch_setting_indexblock6']);
		$_G['setting']['wic_education_touch_setting']['indexblock7'] = explode("|",$config['wic_education_touch_setting_indexblock7']);
		$_G['setting']['wic_education_touch_setting']['indexblock8'] = explode("|",$config['wic_education_touch_setting_indexblock8']);
		$_G['setting']['wic_education_touch_setting']['footerhtml'] = $config['wic_education_touch_setting_footerhtml'];

		
		
	}

}
//From: Dism��taobao��com
?>