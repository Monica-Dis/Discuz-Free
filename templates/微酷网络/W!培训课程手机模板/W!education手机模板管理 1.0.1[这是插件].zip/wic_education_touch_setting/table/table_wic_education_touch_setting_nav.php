<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_wic_education_touch_setting_nav extends discuz_table
{
	public function __construct() {

		$this->_table = 'wic_education_touch_setting_nav';
		$this->_pk    = 'id';

		parent::__construct();
	}

	public function fetch_all_data() {
		return DB::fetch_all('SELECT * FROM %t ORDER BY displayorder', array($this->_table));
	}
	
	
	public function fetch_all_by_id($ids) {
		$ids = dintval($ids, is_array($ids) ? true : false);
		if($ids) {
			return DB::fetch_all('SELECT * FROM %t WHERE '.DB::field('id', $ids), array($this->_table));
		}
	}
	
	public function fetch_all_by_navtype($navtype = null) {
		$parameter = array($this->_table);
		$wheresql = '';
		if($navtype !== null) {
			$parameter[] = $navtype;
			$wheresql = ' WHERE navtype=%d';
		}
		return DB::fetch_all('SELECT * FROM %t '.$wheresql.' ORDER BY displayorder', $parameter, $this->_pk);
	}
	
	public function fetch_by_id($id) {
		return DB::fetch_first('SELECT * FROM %t WHERE id=%d', array($this->_table, $id));
	}

	public function delete_by_id($ids) {
		$ids = dintval($ids, is_array($ids) ? true : false);
		if($ids) {
			return DB::delete($this->_table, DB::field('id', $ids));
		}
		return 0;
	}
	
	public function delete_by_navtype_id($navtype, $ids) {
		$ids = dintval($ids, is_array($ids) ? true : false);
		$navtype = dintval($navtype, is_array($navtype) ? true : false);
		if($ids) {
			return DB::delete($this->_table, DB::field('id', $ids).' AND '.DB::field('navtype', $navtype));
		}
		return 0;
	}
	
	public function insert_all($data,$replace = false) {
		$cmd = $replace ? 'REPLACE INTO' : 'INSERT INTO';
		if( is_array($data)){
			
			foreach( $data as $dataset ){
				
				$value = DB::quote(array_values($dataset));
            	$values[] = '(' . implode(',', $value).')';
				
				$valueset = implode(',',$values);
				
				if (!isset($fields)) {
					$fields = implode(',',array_keys($dataset));
				}
				
			}
			
		}
		DB::query("$cmd %t ($fields) VALUES $valueset ",array($this->_table));
	}
	
	public function update_all($data) {
		  
		$ids = array_keys($data);  
		$sql = "UPDATE %t SET ";   
		foreach ($data[$ids[0]] as $key => $value) {  
			$sql .= "{$key} = CASE id ";  
			foreach ($data as $k=>$v) {  
	  			$k = intval($k);
				$v[$key] = DB::quote($v[$key]);
				$sql .= " WHEN ".$k." THEN ".$v[$key];  
			}  
			$sql .= " END, ";  
		}  
		$sql = substr($sql, 0, strrpos($sql,','));    
		$sql .= " WHERE ".DB::field('id',$ids);
		
		DB::query($sql,array($this->_table));
		
	}


}
//From: Dism��taobao��com
?>