<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



$ac = daddslashes($_GET['ac']);

if(!$ac){

	if(!submitcheck('submit')){
	
		showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$module['name']);
		showtableheader();
		showsubtitle(array('del', lang('plugin/wic_education_touch_setting', 'displayorder'), lang('plugin/wic_education_touch_setting', 'name'), lang('plugin/wic_education_touch_setting', 'url'), lang('plugin/wic_education_touch_setting', 'icon_code'), lang('plugin/wic_education_touch_setting', 'available'),''));
		showtagheader('tbody', '', true);
		
		$postmenulist = array();
		
		foreach( C::t('#wic_education_touch_setting#wic_education_touch_setting_postmenu')->fetch_all_data() as $postmenu ){
			
			$postmenulist[$postmenu['id']] = $postmenu;

		
		}
		
		
		
		foreach($postmenulist as $postmenu) {
			if($postmenu['available'] < 0) {
				continue;
			}
			showtablerow('', array('class="td25"', 'class="td25"', '', '', '','',''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$postmenu[id]\">",
				"<input type=\"text\" class=\"txt\" size=\"2\" name=\"displayordernew[$postmenu[id]]\" value=\"$postmenu[displayorder]\">",
				"<input type=\"text\" class=\"txt\" size=\"15\" name=\"namenew[$postmenu[id]]\" value=\"".dhtmlspecialchars($postmenu['name'])."\">",
				"<input type=\"text\" class=\"txt\" size=\"15\" name=\"urlnew[$postmenu[id]]\" value=\"".dhtmlspecialchars($postmenu['url'])."\">",
				"<input type=\"text\" class=\"txt\" size=\"15\" name=\"iconcodenew[$postmenu[id]]\" value=\"".dhtmlspecialchars($postmenu['iconcode'])."\">",
				"<input class=\"checkbox\" type=\"checkbox\" name=\"availablenew[$postmenu[id]]\" value=\"1\" ".($postmenu['available'] > 0 ? 'checked' : '').">",
				"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do=".$plugin['pluginid']."&identifier=".$plugin['identifier']."&pmod=".$module['name']."&ac=edit&id=$postmenu[id]\" class=\"act\">$lang[edit]</a>"
			));
		}
		showtagfooter('tbody');
		echo '<tr><td colspan="1"></td><td colspan="6"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.lang('plugin/wic_education_touch_setting', 'add_postmenu').'</a></div></td></tr>';
		showsubmit('submit', 'submit', 'del');
		showtablefooter();/*dis'.'m.tao'.'bao.com*/
		showformfooter();/*dism��taobao��com*/
	
	
		echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
[[1, '', 'td25'], [1,'<input name="newdisplayorder[]" value="" size="3" type="text" class="txt">', 'td25'], [1, '<input name="newname[]" value="" size="15" type="text" class="txt">'],[1, '<input name="newurl[]" value="" size="15" type="text" class="txt" />'],[1, '<input name="newiconcode[]" value="" size="15" type="text" class="txt">']],
];
</script>
EOT;
	
	
	}else{
	
		if($ids = dimplode($_GET['delete'])) {
        
            
			C::t('#wic_education_touch_setting#wic_education_touch_setting_postmenu')->delete_by_id($_GET['delete']);
            
            
            
		}
	
		if(is_array($_GET['namenew'])) {
			foreach($_GET['namenew'] as $id => $name) {


				$name = trim(dhtmlspecialchars($name));
				$urlnew = str_replace(array('&amp;'), array('&'), dhtmlspecialchars($_GET['urlnew'][$id]));
                $iconcodenew = trim(dhtmlspecialchars($_GET['iconcodenew'][$id]));
				$availablenew[$id] = $name && (!isset($_GET['urlnew'][$id]) || $_GET['urlnew'][$id]) && $_GET['availablenew'][$id];
				$displayordernew[$id] = intval($_GET['displayordernew'][$id]);
				$updatedata[$id] = array(
                		'name' => $name,
                        'url' => $urlnew,
                        'iconcode' => $iconcodenew,
						'displayorder' => $displayordernew[$id],
						'available' => intval($availablenew[$id]),
					);
			}
            C::t('#wic_education_touch_setting#wic_education_touch_setting_postmenu')->update_all($updatedata);
		}
	
	
		if(is_array($_GET['newname'])) {
			foreach($_GET['newname'] as $k => $v) {
				$v = dhtmlspecialchars(trim($v));
				if(!empty($v)) {
					$newavailable = $v && $_GET['newurl'][$k];
					$newdisplayorder[$k] = intval($_GET['newdisplayorder'][$k]);
					$newurl[$k] = str_replace('&amp;', '&', dhtmlspecialchars($_GET['newurl'][$k]));
                    $newiconcode[$k] = trim(dhtmlspecialchars($_GET['newiconcode'][$k]));
					$insertdata[] = array(
						'name' => $v,
						'displayorder' => $newdisplayorder[$k],
						'url' => $newurl[$k],
                        'iconcode' => $newiconcode[$k],
						'available' => intval($newavailable),
					);
				}
			}
            if( $insertdata ) C::t('#wic_education_touch_setting#wic_education_touch_setting_postmenu')->insert_all($insertdata);
		}
		
		updatecache_postmenu();
		cpmsg(lang('plugin/wic_education_touch_setting', 'add_succeed'), 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$module['name'], 'succeed');
	}

}elseif($ac == 'edit' && ($id = $_GET['id'])){
	
	$postmenu = C::t('#wic_education_touch_setting#wic_education_touch_setting_postmenu')->fetch_by_id($id);
	if(!$postmenu) {
		cpmsg('nav_not_found', '', 'error');
	}
	
	if(!submitcheck('editsubmit')){
		
		
		showformheader("plugins&operation=config&do=".$plugin['pluginid']."&identifier=".$plugin['identifier']."&pmod=".$module['name']."&ac=edit&id=$id", 'enctype');
		showtableheader();
		showsetting(lang('plugin/wic_education_touch_setting', 'name'), 'namenew', $postmenu['name'], 'text');
		showsetting(lang('plugin/wic_education_touch_setting', 'color'), 'colornew', $postmenu['color'], 'color');
		showsetting(lang('plugin/wic_education_touch_setting', 'bgcolor'), 'bgcolornew', $postmenu['bgcolor'], 'color');
		showsubmit('editsubmit');
		showtablefooter();/*dis'.'m.tao'.'bao.com*/
		showformfooter();/*dism��taobao��com*/
		
	}else{
		
		$namenew = trim(dhtmlspecialchars($_GET['namenew']));
		$urlnew = str_replace(array('&amp;'), array('&'), dhtmlspecialchars($_GET['urlnew']));
		$colornew = trim(dhtmlspecialchars($_GET['colornew']));
        $bgcolornew = trim(dhtmlspecialchars($_GET['bgcolornew']));
		

		
		$data = array(
			'name' => $namenew,
			'color' => $colornew,
            'bgcolor' => $bgcolornew,
		);
		C::t('#wic_education_touch_setting#wic_education_touch_setting_postmenu')->update($id, $data);
		
		updatecache_postmenu();
		cpmsg(lang('plugin/wic_education_touch_setting', 'add_succeed'), 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&ac=edit&id='.$id, 'succeed');
	
	}
	

}

function updatecache_postmenu() {

	require_once libfile('function/cache');
	$postmenulist = array();
    foreach(C::t('#wic_education_touch_setting#wic_education_touch_setting_postmenu')->fetch_all_data() as $postmenu) {
        
        $postmenulist[$postmenu['id']] = $postmenu;
        
    }
	savecache('wic_education_touch_setting_post', $postmenulist);
	
}


?>