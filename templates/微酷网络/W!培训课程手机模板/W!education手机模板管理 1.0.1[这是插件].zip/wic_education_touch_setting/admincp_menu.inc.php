<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



$ac = daddslashes($_GET['ac']);

if(!$ac){

	if(!submitcheck('submit')){
	
		showformheader('plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$module['name']);
		showtableheader();
		showsubtitle(array('del', lang('plugin/wic_education_touch_setting', 'displayorder'), lang('plugin/wic_education_touch_setting', 'name'), lang('plugin/wic_education_touch_setting', 'url'), lang('plugin/wic_education_touch_setting', 'logo'), lang('plugin/wic_education_touch_setting', 'available'),''));
		showtagheader('tbody', '', true);
		
		$menulist = array();
		
		foreach( C::t('#wic_education_touch_setting#wic_education_touch_setting_menu')->fetch_all_data() as $menu ){
			
			$menulist[$menu['id']] = $menu;

		
		}
		
		foreach($menulist as $menu) {
			if($menu['available'] < 0) {
				continue;
			}
			showtablerow('', array('class="td25"', 'class="td25"', '', '', '','',''), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$menu[id]\">",
				"<input type=\"text\" class=\"txt\" size=\"2\" name=\"displayordernew[$menu[id]]\" value=\"$menu[displayorder]\">",
				"<input type=\"text\" class=\"txt\" size=\"15\" name=\"namenew[$menu[id]]\" value=\"".dhtmlspecialchars($menu['name'])."\">",
				"<input type=\"text\" class=\"txt\" size=\"15\" name=\"urlnew[$menu[id]]\" value=\"".dhtmlspecialchars($menu['url'])."\">",
				$menu['logo'] ? '<img src="'.$menu['logo'].'" width="48" />' : '',
				"<input class=\"checkbox\" type=\"checkbox\" name=\"availablenew[$menu[id]]\" value=\"1\" ".($menu['available'] > 0 ? 'checked' : '').">",
				"<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do=".$plugin['pluginid']."&identifier=".$plugin['identifier']."&pmod=".$module['name']."&ac=edit&id=$menu[id]\" class=\"act\">$lang[edit]</a>"
			));
		}
		showtagfooter('tbody');
		echo '<tr><td colspan="1"></td><td colspan="6"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.lang('plugin/wic_education_touch_setting', 'add_menu').'</a></div></td></tr>';
		showsubmit('submit', 'submit', 'del');
		showtablefooter();/*dis'.'m.tao'.'bao.com*/
		showformfooter();/*dism��taobao��com*/
	
	
		echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
[[1, '', 'td25'], [1,'<input name="newdisplayorder[]" value="" size="3" type="text" class="txt">', 'td25'], [1, '<input name="newname[]" value="" size="15" type="text" class="txt">'],[1, '<input name="newurl[]" value="" size="15" type="text" class="txt" />']],
];
</script>
EOT;
	
	
	}else{
	
		if($ids = dimplode($_GET['delete'])) {
        
        	foreach( C::t('#wic_education_touch_setting#wic_education_touch_setting_menu')->fetch_all_by_id($_GET['delete']) as $v ){
            	$valueparse = parse_url($v['logo']);
            	if(!isset($valueparse['host'])) {
                    @unlink($v['logo']);
                } 
            }
            
			C::t('#wic_education_touch_setting#wic_education_touch_setting_menu')->delete_by_id($_GET['delete']);
            
            
            
		}
	
		if(is_array($_GET['namenew'])) {
			foreach($_GET['namenew'] as $id => $name) {


				$name = trim(dhtmlspecialchars($name));
				$urlnew = str_replace(array('&amp;'), array('&'), dhtmlspecialchars($_GET['urlnew'][$id]));
				$availablenew[$id] = $name && (!isset($_GET['urlnew'][$id]) || $_GET['urlnew'][$id]) && $_GET['availablenew'][$id];
				$displayordernew[$id] = intval($_GET['displayordernew'][$id]);
				$updatedata[$id] = array(
                		'name' => $name,
                        'url' => $urlnew,
						'displayorder' => $displayordernew[$id],
						'available' => intval($availablenew[$id]),
					);
			}
            C::t('#wic_education_touch_setting#wic_education_touch_setting_menu')->update_all($updatedata);
		}
	
	
		if(is_array($_GET['newname'])) {
			foreach($_GET['newname'] as $k => $v) {
				$v = dhtmlspecialchars(trim($v));
				if(!empty($v)) {
					$newavailable = $v && $_GET['newurl'][$k];
					$newdisplayorder[$k] = intval($_GET['newdisplayorder'][$k]);
					$newurl[$k] = str_replace('&amp;', '&', dhtmlspecialchars($_GET['newurl'][$k]));
					$insertdata[] = array(
						'name' => $v,
						'displayorder' => $newdisplayorder[$k],
						'url' => $newurl[$k],
						'available' => intval($newavailable),
					);
				}
			}
            if( $insertdata ) C::t('#wic_education_touch_setting#wic_education_touch_setting_menu')->insert_all($insertdata);
		}
		
		updatecache_menu();
		cpmsg(lang('plugin/wic_education_touch_setting', 'add_succeed'), 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$module['name'], 'succeed');
	}

}elseif($ac == 'edit' && ($id = $_GET['id'])){
	
	$menu = C::t('#wic_education_touch_setting#wic_education_touch_setting_menu')->fetch_by_id($id);
	if(!$menu) {
		cpmsg('nav_not_found', '', 'error');
	}
	
	if(!submitcheck('editsubmit')){
		
		if($nav['logo']) {
			$logohtml = '<br /><label><input type="checkbox" class="checkbox" name="deletelogo" value="yes" /> '.$lang['delete'].'</label><br /><img src="'.$menu['logo'].'" />';
		}
		
		showformheader("plugins&operation=config&do=".$plugin['pluginid']."&identifier=".$plugin['identifier']."&pmod=".$module['name']."&ac=edit&id=$id", 'enctype');
		showtableheader();
		showsetting(lang('plugin/wic_education_touch_setting', 'name'), 'namenew', $menu['name'], 'text');
		showsetting(lang('plugin/wic_education_touch_setting', 'url'), 'urlnew', $menu['url'], 'text');
		showsetting(lang('plugin/wic_education_touch_setting', 'color'), 'colornew', $menu['color'], 'color');
		showsetting(lang('plugin/wic_education_touch_setting', 'logo'), 'logonew', $menu['logo'], 'filetext', '', 0, cplang('misc_customnav_logo_comment').$logohtml);
		showsubmit('editsubmit');
		showtablefooter();/*dis'.'m.tao'.'bao.com*/
		showformfooter();/*dism��taobao��com*/
		
	}else{
		
		$namenew = trim(dhtmlspecialchars($_GET['namenew']));
		$urlnew = str_replace(array('&amp;'), array('&'), dhtmlspecialchars($_GET['urlnew']));
		$colornew = trim(dhtmlspecialchars($_GET['colornew']));
		
		$logonew = addslashes($menu['logo']);
		if($_FILES['logonew']['tmp_name']) {
			$upload = new discuz_upload();
			if(!$upload->init($_FILES['logonew'], 'common') || !$upload->save()) {
				cpmsg($upload->errormessage(), '', 'error');
			}
			$logonew = $_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		} else {
			$logonew = $_GET['logonew'];
		}
		if($_GET['deletelogo'] && $menu['logo']) {
			$valueparse = parse_url($menu['logo']);
			if(!isset($valueparse['host'])) {
				@unlink($menu['logo']);
			}
			$logonew = '';
		}
		
		$data = array(
			'name' => $namenew,
			'url' => $urlnew,
			'color' => $colornew,
			'logo' => $logonew
		);
		C::t('#wic_education_touch_setting#wic_education_touch_setting_menu')->update($id, $data);
		
		updatecache_menu();
		cpmsg(lang('plugin/wic_education_touch_setting', 'add_succeed'), 'action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$module['name'].'&ac=edit&id='.$id, 'succeed');
	
	}
	

}


function updatecache_menu() {

	require_once libfile('function/cache');
	$menulist = array();
    foreach(C::t('#wic_education_touch_setting#wic_education_touch_setting_menu')->fetch_all_data() as $menu) {
        
        $menulist[$menu['id']] = $menu;
        
    }
	savecache('wic_education_touch_setting_menu', $menulist);
}


?>