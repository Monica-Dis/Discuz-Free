<?php

$wic_favforumuid = C::t('home_favorite')->fetch_by_id_idtype($_G['fid'], 'fid',$_G['uid']);

if($_G['setting']['verify']['enabled'] && $verifyuids) {
	$wic_verify = verify_uids($verifyuids);
}
//From: Dism��taobao��com
?>
