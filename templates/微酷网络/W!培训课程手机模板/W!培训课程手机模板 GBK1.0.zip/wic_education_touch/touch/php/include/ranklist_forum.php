<?php

foreach( $forumsrank as $value){
	$forumsranknew[$value['fid']] = $value;
	$fids[] = $value['fid'];
}
require_once libfile('function/forumlist');
$result = C::t('forum_forumfield')->fetch_all_by_fid($fids);
foreach( $result as $value ){
	if( $forumsranknew[$value['fid']] ){
		$forumsranknew[$value['fid']]['icon'] = get_forumimg($value['icon']);
	}
	
}
           
        


?>
