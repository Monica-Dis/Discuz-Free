<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$activity = C::t('forum_activity')->fetch($thread['tid']);

$activitystatus = '';

if( $activity['expiration'] && $activity['expiration'] > TIMESTAMP ){
	$activitystatus = 1;
}
if( $activity['starttimefrom'] < TIMESTAMP && $activity['starttimeto'] > TIMESTAMP ){
	$activitystatus = 2;
}
if( $activity['starttimeto'] < TIMESTAMP ){
	$activitystatus = 3;
}

$activityclose = $activity['expiration'] ? ($activity['expiration'] > TIMESTAMP ? 0 : 1) : 0;
$activity['starttimefrom'] = dgmdate($activity['starttimefrom'], 'u');
$activity['starttimeto'] = $activity['starttimeto'] ? dgmdate($activity['starttimeto']) : 0;
$activity['expiration'] = $activity['expiration'] ? dgmdate($activity['expiration']) : 0;
$activity['attachurl'] = $activity['thumb'] = '';


if($activity['aid']) {
	$attach = C::t('forum_attachment_n')->fetch('tid:'.$thread['tid'], $activity['aid']);
	if($attach['isimage']) {
		$activity['attachurl'] = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/'.$attach['attachment'];
		$activity['thumb'] = $attach['thumb'] ? getimgthumbname($activity['attachurl']) : $activity['attachurl'];
		$activity['width'] = $attach['thumb'] && $_G['setting']['thumbwidth'] < $attach['width'] ? $_G['setting']['thumbwidth'] : $attach['width'];
	}
}




?>
