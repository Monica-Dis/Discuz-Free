<?php


$wic_recommenduid = C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $_G['forum_thread']['tid']);
$wic_recommends = DB::result_first('SELECT COUNT(*) FROM %t WHERE tid=%d',array('forum_memberrecommend', $_G['forum_thread']['tid']));

$wic_favthreaduid = C::t('home_favorite')->fetch_by_id_idtype($_G['forum_thread']['tid'], 'tid',$_G['uid']);
$wic_favthreads = C::t('home_favorite')->count_by_id_idtype($_G['forum_thread']['tid'],'tid');


?>
