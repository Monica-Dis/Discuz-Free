<?php


$wic_piclist = $wic_picid = array();
$wic_query = C::t('home_pic')->fetch_all_by_albumid($pic['albumid'], 0, 0, 0, 0, 1, $space['uid']);
foreach($wic_query as $value) {
	if($value['status'] == 0 || $value['uid'] == $_G['uid'] || $_G['adminid'] == 1) {
		$wic_picid[] = $value['picid']; 
		$wic_piclist[$value['picid']] = $value;
		$wic_piclist[$value['picid']]['pic'] = pic_get($value['filepath'], 'album', 0, $value['remote']);
	}
}



array_multisort($wic_picid,SORT_DESC,$wic_piclist);     
        


?>
