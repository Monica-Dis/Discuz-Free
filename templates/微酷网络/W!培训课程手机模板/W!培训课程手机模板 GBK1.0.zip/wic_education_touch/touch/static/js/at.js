/*
	[Discuz!] (C)2001-2099 Comsenz Inc.
	This is NOT a freeware, use is subject to license terms

	$Id: at.js 31619 2012-09-17 01:05:07Z monkey $
*/





var atKeywords = null, keyMenuObj = null,atResult = [];
var curatli = 0, atliclass = '', atsubmitid = '', atkeypress = 0;
function atFilter(kw, id, call, e, nae) {
	var nae = !nae ? false : nae;
	atResult = [];
	atSearch(kw, function () { atFilter(kw, id, call); });
	if(nae) {
		
		var newlist = '';
		if(atResult.length) {
			$('#'+id).show();
			for(i in atResult) {
				var atclass = i == curatli ? ' class="a"' : '';
				newlist += '<li><a href="javascript:;" id="atli_'+i+'"'+atclass+' onclick="'+call+'(this.innerText)">' + atResult[i] + '</a></li>';
			}
			document.getElementById(id).innerHTML = '<i class="iconfont icon-close" onclick="athide();"></i><ul class="cl">' + newlist + '</ul>';
		} else {
		}
	}
}

function atListSet(kw) {
	document.getElementById('atkeyword').value = kw;	
}

function athide(){
	$('#at_list').hide();
}



function atSearch(kw, call) {
	if(atKeywords === null) {
		
		atKeywords = '';
		$.ajax({
			type : 'GET',
			url : 'misc.php?mod=getatuser&inajax=1',
			dataType : 'xml'
		})
		.success(function(s) {
			s = evalscript(s.lastChild.firstChild.nodeValue);	
			if(s) {
				atKeywords = s.split(',');
			}
			
			if(call) {
				if(typeof call == 'function') {
					call();
				} else {
					eval(call);
					
				}
			}
		})
	}
	var lsi = 0;
	
	for(i in atKeywords) {
		if(atKeywords[i].indexOf(kw) !== -1 || kw === '') {
			atResult[lsi] = kw !== '' ? atKeywords[i].replace(kw, '<b>' + kw + '</b>') : atKeywords[i];
			lsi++;
			if(lsi > 10) {
				break;
			}
			
		}
		
	}
	
	
	if(kw && !lsi) {
		curatli = -1;
	}
}


function insertat(at) {
    $('#needmessage').insertContent(at);
}







