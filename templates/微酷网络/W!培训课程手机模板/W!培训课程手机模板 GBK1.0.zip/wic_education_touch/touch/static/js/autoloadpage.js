

(function autoloadpage() {

	var autopbn = $('#autopbn');
	var nextpageurl = autopbn.attr('rel');
	var curmodule = autopbn.attr('curmodule');
	var curpage = parseInt(autopbn.attr('curpage'));
	var totalpage = parseInt(autopbn.attr('totalpage'));
	var autopagenum = 100;
	var maxpage = (curpage + autopagenum) > totalpage ? totalpage : (curpage + autopagenum);
	var picstyle = parseInt(autopbn.attr('picstyle'));
	var forumdefstyle = parseInt(autopbn.attr('forumdefstyle'));
	picstyle = picstyle && !forumdefstyle;
	var loadstatus = 0;

	autopbn.click(function() {
		var oldloadstatus = loadstatus;
		loadstatus = 2;
		autopbn.html('���ڼ�����...');
		getnextpagecontent();
		loadstatus = oldloadstatus;
		
	});
 
	if(autopagenum > 0) {
		window.onscroll = function () {
			var curtop = Math.max(document.documentElement.scrollTop, document.body.scrollTop);
			if(curtop + document.documentElement.clientHeight + 500 >= document.documentElement.scrollHeight && !loadstatus) {
				loadstatus = 1;
				autopbn.html('���ڼ�����...');
				
				setTimeout(getnextpagecontent, 1000);
				
			}
		};
	}

	function getnextpagecontent() {
		
		if(curpage + 1 > totalpage) {
			window.onscroll = null;
			autopbn.html('�ף��Ѿ������ˣ�');
			return;
		}
		if(loadstatus != 2 && curpage + 1 > maxpage) {
			autopbn.html('������ظ���');
			if(curpage + 1 > maxpage) {
				window.onscroll = null;
			}
			return;
		}
		curpage++;
		var url = nextpageurl + '&t=' + parseInt((+new Date()/1000)/(Math.random()*1000));
		
		
		$.ajax({
			type : 'GET',
			url : url,
			dataType : 'html'
		})
		.success(function(s) {
			s = s.replace(/\n|\r/g, '');
			
			var tableobj = $('.autolist');
			var nexts = s.match(/\<article id="alist_(\d+)" class="(.+?)"\>(.+?)\<\/article>/g);
			
			
			for(i in nexts) {
			
				if(i == 'index' || i == 'lastIndex') {
				continue;
				}
				var insertid = nexts[i].match(/<article id="alist_(\d+)" class="(.+?)"\>/);
				if(!$('#alist_' + insertid[1]).length) {
					if(picstyle) {
					$boxes = $(nexts[i]);
					tableobj.append( $boxes ).masonry("appended", $boxes, true);
					}
					else{
					tableobj.append(nexts[i]);
					popup.init();
					}
					
				}
				if(picstyle) {
				waterfall.imagesLoaded(function(){    
					  waterfall.masonry();    
					});
				}
			}
			
			
			$("img.lazy").lazyload();
			
			nextpageurl = nextpageurl.replace(/&page=\d+/, '&page=' + (curpage + 1));

			if(curpage + 1 > totalpage) {
				autopbn.html('������ظ���');
			} else {
				autopbn.html('�ף��Ѿ������ˣ�');
			}
			loadstatus = 0;
			
			
		})
		.error(function() {
		window.location.href = url;
		});
		
		
	}

})();
