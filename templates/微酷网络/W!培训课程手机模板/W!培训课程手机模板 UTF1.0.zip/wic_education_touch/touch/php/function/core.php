<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('function/home');

function threadlist_decorate($thread,$summarynum,$picwidth,$picheight){

	global $_G;
	$message = array();
	$piclist = array();
	$uids = array();
	
	foreach( $thread as $k => $v){
		
		if( $v['tid'] ){
			$tids[] = $v['tid'];
		}else{
			$tids[] = $k;
		}
		$uids[] = $v['authorid'];
		
	}
	
	$profiles = C::t('common_member_profile')->fetch_all($uids);
	
	foreach(C::t('common_member')->fetch_all($uids) as $uid => $value) {
		$usertmp[$uid] = array_merge($profiles[$uid],$value);	
		$usertmp[$uid]['groupcolor'] = $_G['cache']['usergroups'][$value['groupid']]['color'];
		$usertmp[$uid]['grouptitle'] = $_G['cache']['usergroups'][$value['groupid']]['grouptitle'];
		$usertmp[$uid]['stars'] = $_G['cache']['usergroups'][$value['groupid']]['stars'];
	}
	
  	if( $_G['cache']['wic_touch_setting_forum'][$_G['fid']]['modetype'] == 1 ||  $_G['cache']['wic_touch_setting_forum'][$_G['fid']]['modetype'] == 2 ){
		$maxpicnum = 9;
	}elseif( $_G['cache']['wic_touch_setting_forum'][$_G['fid']]['modetype'] == 4 || $_G['cache']['wic_touch_setting_forum'][$_G['fid']]['modetype'] == 5 || $_G['cache']['wic_touch_setting_forum'][$_G['fid']]['modetype'] == 6 ){
		$maxpicnum = 1;
	}else{
		$maxpicnum = 3;
	}
	
	
	
	
	
	require_once libfile('function/post');
	
	$result = DB::fetch_all("SELECT tid,pid,message,attachment FROM ".DB::table("forum_post")." WHERE first=1 and tid in (".dimplode($tids).")");
	
	$posts = DB::fetch_all("SELECT tid,author,authorid,message FROM ".DB::table("forum_post")." WHERE first=0 and tid in (".dimplode($tids).") ORDER BY dateline DESC");
	
	$recommends = DB::fetch_all("SELECT tid,recommenduid FROM ".DB::table("forum_memberrecommend")." WHERE tid in (".dimplode($tids).") ORDER BY dateline DESC");
	
	if( $_G['uid'] ) {
		
		$recommenduid = DB::fetch_all("SELECT tid,recommenduid FROM ".DB::table("forum_memberrecommend")." WHERE recommenduid = ".$G['uid']." tid in (".dimplode($tids).")");
		foreach( $recommenduid as $value ){
			$recommenduidlist[$value['tid']]=$value['recommenduid'];
		}
	}
	
	
	$resultsort = sortbytids($result, $tids);
	unset($tids);
	unset($result);
	
	foreach( $posts as $key => $value ){
		$replieslist[$value['tid']][] = $value ;	
	}
	
	foreach( $replieslist as $key => $value ){
		$i[$key] = 0;
		foreach( $posts as $v ){
			if( $v['tid'] == $key && $i[$key] < 6 ){
				$replieshtml[$key] .= '<p><a href="home.php?mod=space&uid='.$v['authorid'].'&do=profile" class="mr5">'.$v['author'].'&nbsp;:</a>'.wic_messagecutstr($v['message'],60).'</p>';
				$i[$key]++;
			}
		}
	}
	
	foreach( $recommends as $key => $value ){
		$recommendlist[$value['tid']][] = $value ;	
	}
	
	foreach( $recommendlist as $key => $value ){
		$j[$key] = 0;
		foreach( $recommends as $v ){
			if( $v['tid'] == $key && $j[$key] < 9 ){
				$recommendhtml[$key] .= '<a href="home.php?mod=space&uid='.$v['recommenduid'].'&do=profile" class="ml5"><img src="'.avatar($v['recommenduid'], small, true).'" /></a>';
				$j[$key]++;
			}
		}
	}
	
	
	
	
	foreach( $resultsort as $v){			
		if( $v['message'] ){	
		
			$msglower = strtolower($v['message']);
			if(strpos($msglower, '[/media]') !== FALSE) {
				preg_match("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", $v['message'],$mediamatches);
				$media[$v['tid']] = wic_discuzcode_callback_parsemedia_12($mediamatches);
			}
			if(strpos($msglower, '[/audio]') !== FALSE) {
				preg_match("/\[audio(=1)*\]\s*([^\[\<\r\n]+?)\s*\[\/audio\]/is",$v['message'], $audiomatches);
				$audio[$v['tid']] = wic_discuzcode_callback_parseaudio_2($audiomatches);
			}
			if(strpos($msglower, '[/flash]') !== FALSE) {
				preg_match("/\[flash(=(\d+),(\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/is",$v['message'], $flashmatches);
				$flash[$v['tid']] = wic_discuzcode_callback_parseflash_4($flashmatches);
			}
			$message[$v['tid']]['message'] = messagecutstr($v['message'],$summarynum); 	
		}else{	
			$message[$v['tid']]['message'] = '';	
		}
		if( $v['attachment'] == 2 ){	
			$pids[] = $v['pid'];		
		}	
	}
	$attachment = DB::fetch_all("SELECT aid,tid FROM ".DB::table("forum_attachment")." WHERE pid in (".dimplode($pids).")");
	unset($pids);
	foreach( $attachment as $v ){			
			$count[$v['tid']]++;
			if( $count[$v['tid']] <= $maxpicnum){
				$aid[$v['tid']][] = $v['aid'];
			}
			
				
	}
	
	foreach( $aid as $key => $value ){			
			if( $count[$key] < 2 ){
				foreach( $value as $v ){
					$piclist[$key] .= '<dd><img class="lazy" src="'.getforumimg($v,0,440,9999,'').'" /></dd>';
				}
			}elseif( $count[$key] >= 2 && $count[$key] < 3 ){
				foreach( $value as $v ){
					$piclist[$key] .= '<dd><img class="lazy" src="'.getforumimg($v,0,300,190,'').'" /></dd>';
				}
			}else{
				foreach( $value as $v ){
					$piclist[$key] .= '<dd><img class="lazy" src="'.getforumimg($v,0,220,200,'').'" /></dd>';
				}
			}
		
				
	}
	
	foreach( $thread as $k => $v){	
		
		
			$thread[$k]['message'] = $message[$v['tid']]['message'];
			if( $media[$v['tid']] ) $thread[$k]['media'] = $media[$v['tid']];
			if( $audio[$v['tid']] ) $thread[$k]['audio'] = $audio[$v['tid']];
			if( $flash[$v['tid']] ) $thread[$k]['flash'] = $flash[$v['tid']];
			if( $replieshtml[$v['tid']] ) $thread[$k]['replieshtml'] = $replieshtml[$v['tid']];
			if( $recommendhtml[$v['tid']] ) $thread[$k]['recommendhtml'] = $recommendhtml[$v['tid']];
			if( $recommenduidlist[$v['tid']] ) $thread[$k]['recommenduid'] = $recommenduidlist[$v['tid']];
			$thread[$k]['piclist'] = $piclist[$v['tid']];
			$thread[$k]['picnum'] = $count[$v['tid']];	
			$thread[$k]['userinfo'] = $usertmp[$v['authorid']];
		
			
	}
	unset($count);
	unset($piclist);
	unset($message);
	unset($usertmp);
	return $thread;
		
}


function wic_messagecutstr($str, $length = 0, $dot = ' ...') {
	global $_G;
	$str = messagesafeclear($str);
	$sppos = strpos($str, chr(0).chr(0).chr(0));
	if($sppos !== false) {
		$str = substr($str, 0, $sppos);
	}
	$language = lang('forum/misc');
	loadcache(array('bbcodes_display', 'bbcodes', 'smileycodes', 'smilies', 'smileytypes', 'domainwhitelist'));
	$bbcodes = 'b|i|u|p|color|size|font|align|list|indent|float';
	$bbcodesclear = 'email|code|free|table|tr|td|img|swf|flash|attach|media|audio|groupid|payto'.($_G['cache']['bbcodes_display'][$_G['groupid']] ? '|'.implode('|', array_keys($_G['cache']['bbcodes_display'][$_G['groupid']])) : '');
	$str = preg_replace_callback("/\[quote\](.*?)\[color=#[0-9a-zA-Z]{6}\](.*?)\[\/color\](.*?)\[\/quote\]/si", 'wic_discuzcode_callback_parsequote_2', $str);
	$str = strip_tags(preg_replace(array(
			"/\[hide=?\d*\](.*?)\[\/hide\]/is",
			$language['post_edit_regexp'],
			"/\[url=?.*?\](.+?)\[\/url\]/si",
			"/\[($bbcodesclear)=?.*?\].+?\[\/\\1\]/si",
			"/\[($bbcodes)=?.*?\]/i",
			"/\[\/($bbcodes)\]/i",
		), array(
			"[b]$language[post_hidden][/b]",
			'',
			'\\1',
			'',
			'',
			'',
		), $str));
	if($length) {
		$str = cutstr($str, $length, $dot);
	}
	$str = wic_parsesmiles($str);

	return trim($str);
}

function wic_discuzcode_callback_parsequote_2($matches) {
	$arr = explode(" ",$matches[2]);
	if( $arr[0] ) return lang('space', 'reply').$arr[0];
}

function wic_discuzcode_callback_parsemedia_12($matches) {
	return wic_parsemedia($matches[1], $matches[2]);
}


function wic_discuzcode_callback_parseaudio_2($matches) {
	return wic_parseaudio($matches[2]);
}

function wic_discuzcode_callback_parseflash_4($matches) {
	return wic_parseflash($matches[4]);
}

function wic_parsemedia($params, $url) {
	$params = explode(',', $params);

	$url = addslashes($url);
        if(!in_array(strtolower(substr($url, 0, 6)), array('http:/', 'https:', 'ftp://', 'rtsp:/', 'mms://')) && !preg_match('/^static\//', $url) && !preg_match('/^data\//', $url)) {
		return dhtmlspecialchars($url);
	}

	if($flv = wic_parseflv($url)) {
		return $flv;
	}

	if(in_array(count($params), array(3, 4))) {
		$ext = fileext($url);
		$url = htmlspecialchars(str_replace(array('<', '>'), '', str_replace('\\"', '\"', $url)));
		switch($ext) {
			case 'mp4':
				return '<video src="'.$url.'" controls="controls" style="width:100%;"></video>';
			default:
				return ;
		}
	}
	return;
}

function wic_parseflash($url) {
	$url = addslashes($url);
        if(!in_array(strtolower(substr($url, 0, 6)), array('http:/', 'https:', 'ftp://', 'rtsp:/', 'mms://')) && !preg_match('/^static\//', $url) && !preg_match('/^data\//', $url)) {
		return dhtmlspecialchars($url);
	}

	if($flv = wic_parseflv($url)) {
		return $flv;
	}
}


function wic_parseflv($url) {
	$lowerurl = strtolower($url);
	$iframe = '';
	if (strpos($lowerurl, 'v.youku.com/v_show/') !== FALSE) {
		if (preg_match("/https?:\/\/v.youku.com\/v_show\/id_([^\/]+).html([^\/]*)/i", $url, $matches)) {
			$iframe = 'https://player.youku.com/embed/'.$matches[1];
		}
	} elseif (strpos($lowerurl, 'player.youku.com/') !== FALSE) {
		if (preg_match("/https?:\/\/player.youku.com\/player.php\/sid\/([^\/]+)\/v.swf/i", $url, $matches)) {
			$iframe = 'http://player.youku.com/embed/'.$matches[1];
		}
	} elseif(strpos($lowerurl, 'v.qq.com/') !== FALSE) {
		if(preg_match("/https?:\/\/\S*\/([a-z0-9]+).html/i", $url, $matches)) {
			$iframe = 'https://v.qq.com/txp/iframe/player.html?vid='.$matches[1];
		}
	} elseif(strpos($lowerurl, 'qq.com/') !== FALSE) {
		if(preg_match("/https?:\/\/\S*vid=([^\/]+)\S*/i", $url, $matches)) {
			$iframe = 'https://v.qq.com/iframe/player.html?vid='.$matches[1].'&tiny=0&auto=0';
		}
	}
     elseif (strpos($lowerurl, 'iqiyi.com/') !== FALSE) {
		if (preg_match("/https?:\/\/www.iqiyi.com\/v_([a-z0-9]+).html#curid=([a-z0-9]+)_([a-z0-9]+)/i", $url, $matches)) {
			$iframe = 'https://open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid='.$matches[3].'&tvId='.$matches[2];
		}
	} elseif (strpos($lowerurl, 'qiyi.com/') !== FALSE) {
		if (preg_match("/https?:\/\/player.video.qiyi.com\/([a-z0-9]+)\S*tvId=([a-z0-9]+)\S*/i", $url, $matches)) {
			$iframe = 'https://open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid='.$matches[1].'&tvId='.$matches[2];
		}
	}
	if($iframe){
		return '<iframe height="260" width="100%" src="'.$iframe.'" class="wic_video" frameborder=0 allowfullscreen></iframe>';
	}
	
	
}

function wic_parseaudio($url) {
	$url = addslashes($url);
        if(!in_array(strtolower(substr($url, 0, 6)), array('http:/', 'https:', 'ftp://', 'rtsp:/', 'mms://')) && !preg_match('/^static\//', $url) && !preg_match('/^data\//', $url)) {
		return dhtmlspecialchars($url);
	}
	$ext = fileext($url);
	switch($ext) {
		case 'wav':
		case 'ogg':
		case 'mp3':
			return '<audio style="width:100%" src="'.$url.'" controls="controls"></audio>';
	}
}

function wic_parsesmiles(&$message) {
	global $_G;
	static $enablesmiles;
	if($enablesmiles === null) {
		$enablesmiles = false;
		if(!empty($_G['cache']['smilies']) && is_array($_G['cache']['smilies'])) {
			foreach($_G['cache']['smilies']['replacearray'] AS $key => $smiley) {
				$_G['cache']['smilies']['replacearray'][$key] = '<img src="'.STATICURL.'image/smiley/'.$_G['cache']['smileytypes'][$_G['cache']['smilies']['typearray'][$key]]['directory'].'/'.$smiley.'" smilieid="'.$key.'" border="0" alt="" />';
			}
			$enablesmiles = true;
		}
	}
	$enablesmiles && $message = preg_replace($_G['cache']['smilies']['searcharray'], $_G['cache']['smilies']['replacearray'], $message, $_G['setting']['maxsmilies']);
	return $message;
}


function sortbytids($result, $tids){
    $resultsort = array();
    foreach ($tids as $v) {
        foreach ($result as $value) {
            if ( $v == $value['tid'] ) {
                $resultsort[] = array(
                    'tid' => $v,
					'pid' => $value['pid'],
					'message' => $value['message'],
                    'attachment' => $value['attachment']);
            }
        }
    }
    return $resultsort;
}


function verify_uids($ids) {
	global $_G;
	$verify = array();
	foreach(C::t('common_member_verify')->fetch_all($ids) as $value) {
		foreach($_G['setting']['verify'] as $vid => $vsetting) {
			if($vsetting['available'] && $vsetting['showicon'] && $value['verify'.$vid] == 1) {
				$srcurl = !empty($vsetting['icon']) ? $vsetting['icon'] : '';
				$verify[$value['uid']] .= !empty($srcurl) ? '<img src="'.$srcurl.'" class="verify" alt="'.$vsetting['title'].'" title="'.$vsetting['title'].'" />' : '';
			}
		}

	}
	return $verify;
}


?>