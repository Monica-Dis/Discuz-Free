<?php

foreach($list['threadlist'] as $thread) {
	$wic_verifyuids[$thread['authorid']] = $thread['authorid'];
}

if($_G['setting']['verify']['enabled'] && $wic_verifyuids) {
	$wic_verify = verify_uids($wic_verifyuids);
}
//From: Dism��taobao��com
?>