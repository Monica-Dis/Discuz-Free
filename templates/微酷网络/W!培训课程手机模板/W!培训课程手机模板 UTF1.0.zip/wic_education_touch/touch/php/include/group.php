<?php

$wic_favgroupuid = C::t('home_favorite')->fetch_by_id_idtype($_G['forum']['fid'], 'gid',$_G['uid']);


if($action == 'index' && $status != 2 && $status != 3){
	foreach($newthreadlist['dateline']['data'] as $thread) {
		$wic_verifyuids_index[$thread['authorid']] = $thread['authorid'];
	}
	if($_G['setting']['verify']['enabled'] && $wic_verifyuids_index) {
		$wic_verify_index = verify_uids($wic_verifyuids_index);
	}
} elseif($action == 'list'){
	foreach($_G['forum_threadlist'] as $thread) {
		$wic_verifyuids_list[$thread['authorid']] = $thread['authorid'];
	}
	if($_G['setting']['verify']['enabled'] && $wic_verifyuids_list) {
		$wic_verify_list = verify_uids($wic_verifyuids_list);
	}
	
}
           
        


?>