jq(function () {

    var jqplayBtn = jq('.wic_audio_play_btn'),
		jqwaveLength = parseInt(jq('.wic_audio_file .time-bar').css('width')),
        oldPlayItem = null,
        hasOtherPlay = false,
        isDetailPage = false,

		dragingBar = null;
   
	var timeTip = document.createElement('p');
    timeTip.className = 'timeTip';

 
     

    audiosInit();
	
	
    function audiosInit() {
        jqplayBtn.each(function (i, ele) {
            var that = this,
                jqthis = jq(this);
            this.isPlay = true;
            this.showTime = 0;
            this.first = true;
            this.jqthisAudio = jqthis.parent().find('audio');
            this.audio = this.jqthisAudio.get(0);
			
			



			this.jqtoTime = this.jqthisAudio.attr('duration');


			this.pgBar = jqthis.siblings('.time-bar').get(0);
            this.pgBar.pgBarClientLeft = this.pgBar.getBoundingClientRect().left;
            this.pgBar.audio = this.audio;
            this.pgBar.jqtoTime = this.jqtoTime;
            this.pgBar.timeTip = timeTip;
            this.pgBar.audioBox = jqthis.parent().get(0);
            this.pgBar.width = jq(this.pgBar).width();
            this.pgBar.toParLeft = this.pgBar.pgBarClientLeft -  this.pgBar.audioBox.getBoundingClientRect().left;
			
			//console.log(this.pgBar);
			that.jqmoveColor = jqthis.parent().find('.time-bar').find('.move-color');
			that.jqrotateImg = jqthis.parent().parent().find('.wic_audio_img');
			that.jqrotateIcon = jqthis.parent().prev(".wic_audio_chord");
			
			
			that.dragDot = jqthis.parent().find('.move-color .dot');
			
		
            jqwaveLength = parseInt( jq(this.pgBar).css('width'));
           
			//console.log(jqwaveLength);
			
			that.t = TweenMax.to(that.jqmoveColor, that.jqtoTime, {
                width: jqwaveLength,
                ease: Linear.easeNone,
                onComplete: function () {
                    that.jqmoveColor.css('width', 0);
                }
            });
            that.t.pause();
			
            that.audio.onended = function () {
                clearInterval(that.jqaudioInterval);
				
				that.t.seek(that.jqtoTime);
                that.jqmoveColor.css('width', 0);
                // that.$curTime.text('0:00');
                jq(that).removeClass('pause');
				jq(that).addClass('play');
                that.jqrotateImg.removeClass('running');
				that.jqrotateIcon.removeClass('skewing');
                // that.$musicBar.hide();
                that.isPlay = true;
                hasOtherPlay = false;
                that.first = true;
            }
			
			this.pgBar.onmouseover = function (e) {
                var _this = jq(this);
                this.audioBox.appendChild(countTips(e, this));
                
                // this.onmousemove = function (e) {
                //     countTips(e, this);
                // };
                _this.on('mousemove', function (e) { 
                    countTips(e, this);
                 })
                this.onmouseleave = function () {
                    this.audioBox.removeChild(this.timeTip);
                }
                this.onmousedown = function (e) { 
                    stopProp(e);
                    dragingBar = this;
                    this.onmousemove = function (e) { 
                        stopProp(e);
                        var willTo = Math.round((e.clientX - this.pgBarClientLeft) / jqwaveLength * this.jqtoTime);
                        that.t.seek(willTo);
                        // console.log(willTo)
                     }
                 }
                 jq(document).on('mousemove', function (e) { 
                    if (!dragingBar) return;
                    stopProp(e);
                    var that = jq(dragingBar).siblings('.wic_audio_play_btn').get(0);
                    moveColor(e, dragingBar, that);
                    
                 })
                jq(document).on('mouseup', function (e) { 
                    if (!dragingBar) return;
                    stopProp(e);
                    var that = jq(dragingBar).siblings('.wic_audio_play_btn').get(0);
                    var curTime = moveColor(e, dragingBar, that)
                    dragingBar.audio.currentTime = curTime;
                    if (dragingBar.audio.paused) {
                        that.t.resume();
                        dragingBar.audio.play();
                        doPlay(that);
                        // window.onblur = function () {
                        //     doPause(that);
                        //     that.isPlay = true;
                        // }
                        that.isPlay = !that.isPlay;
                    }

                    dragingBar.onmousemove = null;
                    dragingBar = null;
                    return false;
                 })

                function  moveColor (e, dragingBar, that) {
                    var dist = e.clientX - dragingBar.pgBarClientLeft;
                    if (dist < 0) dist = 0;
                    else if (dist > dragingBar.width) dist = dragingBar.width-1;
                    var willTo = Math.round((dist) / jqwaveLength * dragingBar.jqtoTime);
                    that.t.seek(willTo);

                    return willTo;
                }

                function countTips(e, that) {
                    var jqthat = jq(that);
                    if (jqthat.parents('.vwth_resource_content').length > 0) {
                        jqwaveLength = parseInt( jqthat.css('width'));
                    }
                    var dist = e.clientX - that.pgBarClientLeft;
                    if (dist < 0) dist = 0;
                    else if (dist > that.width) dist = that.width;
                    // console.log(dist,that.width)
                    var willTo = Math.round((dist) / jqwaveLength * that.jqtoTime);
                    var minute = willTo / 60;
                    var second = willTo % 60;
                    if (willTo <= 9) {
                        that.timeTip.innerHTML = parseInt('0' + minute) + ":" + '0' + second;
                    } else {
                        that.timeTip.innerHTML = parseInt('0' + minute) + ":" + second;
                    }
                    that.timeTip.style.left = dist + that.toParLeft - 20 + 'px';
                    // console.log(e.clientX,that.pgBarClientLeft,that.toParLeft);
                    return that.timeTip;
                }
            }
            
       
            function doPlay(that) {
                if (hasOtherPlay || oldPlayItem != that) {
                    if (oldPlayItem) {
                        var jqold = jq(oldPlayItem);
                        clearInterval(oldPlayItem.jqaudioInterval);
                        oldPlayItem.jqrotateImg.removeClass('running');
                        oldPlayItem.jqthisAudio.get(0).pause();
                        oldPlayItem.className = 'wic_audio_play_btn play';
						that.jqrotateIcon.removeClass('skewing');
                        // $old.removeClass('icon-zanting');
                        oldPlayItem.isPlay = true;
                    }
                }
                // that.$musicBar.show();
                that.jqrotateImg.addClass('running');
				that.jqrotateIcon.addClass('skewing');
                that.className = 'wic_audio_play_btn pause';
                // $this.addClass('icon-zanting');
                that.jqaudioInterval = setInterval(function () {
                    fun(that);
                }, 16);
                hasOtherPlay = true;
                oldPlayItem = that;

            }
            function fun(audio) {
                audio.showTime = Math.floor(audio.jqthisAudio.get(0).currentTime);
                var minute = Math.floor(audio.showTime / 60);
                var second = Math.round(audio.showTime % 60);
                if (minute <= 9) {
                    minute = '0' + minute;
                }
                if (second <= 9) {
                    second = '0' + second;
                }

                audio.jqcurTime.text(minute + ":" + second);
            }
            function doPause(that) {
                // console.log('oldPlayItem',oldPlayItem, that)
                clearInterval(that.jqaudioInterval);
                that.jqrotateImg.removeClass('running');
                that.pauseTime = that.audio.currentTime;
                that.audio.pause();
				that.t.pause();
                jqthis.removeClass('pause');
				jqthis.addClass('play');
				that.jqrotateIcon.removeClass('skewing');
                hasOtherPlay = false;
            }
            //播放暂停
            jq(this).click(function (e) {
                stopProp(e);
                var jqthis = jq(this),
                    that = this;
                if (this.isPlay) {
                    if (that.first) {
                       if (that.t.progress() == 1) {
                            that.t.progress(0);
                        }
                        that.t.resume();

                        // window.onblur = function () {
                        //     doPause(that);
                        //     that.isPlay = true;
                        // }

                        if (that.first && that.jqtoTime < 5) {
                            setTimeout(function () {
                                that.audio.play();
                            }, 300);
                        } else {
                            that.audio.play();
                        }
                        that.first = false;
                    } else {
  						that.t.resume(that.pauseTime);
                        that.audio.play();
                    }
                    doPlay(that);
                } else {
                    doPause(that);
                }
                this.isPlay = !this.isPlay;
                // 暂停
                return false;
            })


            function stopProp(e) {
                e = e || window.e;
                if ( e && e.stopPropagation ) {
                    e.stopPropagation(); 
                }
                else {
                    e.cancelBubble = true; 
                } 
                if ( e && e.preventDefault ) {
                    e.preventDefault();
                }else {
                    e.returnValue = false; 
                }
            }
        });
    }
})

