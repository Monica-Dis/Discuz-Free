<?php


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include_once libfile('function/home');
$collection = C::t('#wic_material_manage#wic_forum_collection')->fetch_all();
foreach( $collection as $value ){
	if( $value['cover']) {
		if($value['picflag'] != '0') pic_delete(str_replace('forum/', '', $value['cover']), 'forum', 0, $value['picflag'] == '2' ? '1' : '0');
	} 
}


$sql = <<<EOF
DROP TABLE IF EXISTS `pre_wic_forum_collection`;
EOF;

runquery($sql);




$finish = TRUE;

?>