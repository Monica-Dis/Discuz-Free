<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wic_material_manage {
	
	function common(){
		
		global $_G;
		$_G['wic_material_classified_ids'] = explode(',',$_G['cache']['plugin']['wic_material_manage']['classified_ids']);
		$_G['wic_material_normal_ids'] = explode(',',$_G['cache']['plugin']['wic_material_manage']['normal_ids']);
		$_G['wic_material_sound_ids'] = explode(',',$_G['cache']['plugin']['wic_material_manage']['sound_ids']);
		$_G['wic_material_video_ids'] = explode(',',$_G['cache']['plugin']['wic_material_manage']['video_ids']);
			
	}

}

class plugin_wic_material_manage_forum extends plugin_wic_material_manage{
	
	function collection_add_wic_output(){
		global $_G,$oplist,$op,$ctid,$newcollection,$newctid;
		
		$collection_extends =  C::t('#wic_material_manage#wic_forum_collection')->fetch($ctid);
		
		foreach($collection_extends as $key => $value){
			$_G['collection'][$key] = $value;
		}
		
		if($_G['collection']['cover']) {
			if($_G['collection']['picflag'] == '1') {
				$_G['collection']['cover'] = $_G['setting']['attachurl'].$_G['collection']['cover'];
			} elseif ($_G['collection']['picflag'] == '2') {
				$_G['collection']['cover'] = $_G['setting']['ftp']['attachurl'].$_G['collection']['cover'];
			}
		}else{
			$_G['collection']['cover'] = $_G['style']['styleimgdir'].'/resource/noimg.jpg';
		}
		
		$coverpath = $_G['collection']['picflag'] == '0' ? $_G['collection']['cover'] : '';
		
		
		if(empty($op) || $op == 'add') {
			
			if(submitcheck('collectionsubmit')) {
				
				_wic_collection_cover_update($newctid);
			}
			
		}elseif($op == 'edit'){
			if(submitcheck('collectionsubmit')) {
				
				_wic_collection_cover_update($ctid);
				
			}
				
			
		}
		include template('wic_material_manage:collection_add_cover');
		
		return $return;
	}

}

function _wic_collection_cover_update($ctid){
	
	global $_G;	
	
	include_once libfile('function/home');
	
	if($_GET['deletecover'] && $_G['collection']['cover']) {
		if($_G['collection']['picflag'] != '0') pic_delete(str_replace('forum/', '', $_G['collection']['cover']), 'forum', 0, $_G['collection']['picflag'] == '2' ? '1' : '0');
		$newcollection['cover'] = '';
		$newcollection['picflag'] = '0';
	} else {
		if($_FILES['cover']['tmp_name']) {
			if($_G['collection']['cover'] && $_G['collection']['picflag'] != '0') pic_delete(str_replace('forum/', '', $_G['collection']['cover']), 'forum', 0, $_G['collection']['picflag'] == '2' ? '1' : '0');
			$pic = pic_upload($_FILES['cover'], 'forum');
			if($pic) {
				$newcollection['cover'] = 'forum/'.$pic['pic'];
				$newcollection['picflag'] = $pic['remote'] ? '2' : '1';
			}
		} else {
			if(!empty($_GET['cover']) && $_GET['cover'] != $_G['collection']['cover']) {
				if($_G['collection']['cover'] && $_G['collection']['picflag'] != '0') pic_delete(str_replace('forum/', '', $_G['collection']['cover']), 'forum', 0, $_G['collection']['picflag'] == '2' ? '1' : '0');
				$newcollection['cover'] = $_GET['cover'];
				$newcollection['picflag'] = '0';
			}
		}
	}
	
	$newcollection['ctid'] = $ctid;
	
	C::t('#wic_material_manage#wic_forum_collection')->insert($newcollection,false,true,false);
}
//From: Dism_taobao-com
?>