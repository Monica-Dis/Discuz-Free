<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}




$group_recommends_ids = array_keys(dunserialize($_G['setting']['group_recommend']));
$group_recommends = grouplist('', '', '', $group_recommends_ids, 0, 0,'');

function getgroupfirstattach($fid,$num = 5){
	
	$pids = DB::fetch_all("SELECT pid FROM %t WHERE fid = %d AND first = 1 ORDER BY dateline DESC LIMIT %d",array('forum_post',$fid,$num));
	foreach( $pids as $pid){
		$aids = DB::fetch_all("SELECT aid,tid FROM ".DB::table(getattachtablebypid($pid['pid']))." WHERE pid = ".intval($pid['pid'])." and readperm = 0 and price = 0 and isimage = 1 ORDER BY dateline DESC limit 1");
	}
	foreach( $aids as $aid ){
		$attachments[$aid['tid']] = getforumimg($aid['aid'],0,100,100,'');
	}
	return $attachments;
}




?>