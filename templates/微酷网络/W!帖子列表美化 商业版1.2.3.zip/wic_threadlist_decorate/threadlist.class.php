<?php

/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_wic_threadlist_decorate {
	
	
}


class plugin_wic_threadlist_decorate_forum extends plugin_wic_threadlist_decorate{
	
	
	function forumdisplay_top_output(){
		
		global $_G;	
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		include template('wic_threadlist_decorate:css');
		
		return $css;
		
	}
	
	
	function forumdisplay_thread_subject_output(){	
		global $_G;		
		
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		$pcopen = intval($config['pc_open']);
		$forumopen = intval($config['forum_open']);
		$openfid = (array)unserialize($config['open_forum']);
		$summarynum= isset($config['summary_num'])?intval($config['summary_num']):100;
		$picnum = isset($config['pic_num'])?intval($config['pic_num']):3;
		$picwidth = isset($config['pic_width'])?intval($config['pic_width']):120;
		$picheight = isset($config['pic_height'])?intval($config['pic_height']):100;
		$open=in_array('', $openfid) ? TRUE : (in_array($_G['fid'], $openfid) ? TRUE : FALSE);
		
		if( $pcopen && $forumopen && $open ){	
			$threadlist = threadlist_decorate($_G['forum_threadlist'],$summarynum,$picnum,$picwidth,$picheight);	
		}
		
		return $threadlist;
		
	}
	
	
	function guide_top_output(){
		
		global $_G;	
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		include template('wic_threadlist_decorate:css');
		
		return $css;
		
	}
	
	
	
	function guide_thread_output(){	
		global $_G,$view,$data;		
		
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		$pcopen = intval($config['pc_open']);
		$guideopen = intval($config['guide_open']);
		$summarynum= isset($config['summary_num'])?intval($config['summary_num']):100;
		$picnum = isset($config['pic_num'])?intval($config['pic_num']):3;
		$picwidth = isset($config['pic_width'])?intval($config['pic_width']):120;
		$picheight = isset($config['pic_height'])?intval($config['pic_height']):100;
			
		if( $pcopen && $guideopen ){
			$threadlist = threadlist_decorate($data[$view]['threadlist'],$summarynum,$picnum,$picwidth,$picheight);		
	
			return $threadlist;
		}

	}
	
			
}


class plugin_wic_threadlist_decorate_group extends plugin_wic_threadlist_decorate{
	
	
	function forumdisplay_top_output(){
		
		global $_G;	
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		include template('wic_threadlist_decorate:css');
		
		return $css;
		
	}
	
	function forumdisplay_thread_output(){	
		global $_G;		
		
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		$pcopen = intval($config['pc_open']);
		$groupopen = intval($config['group_open']);
		$summarynum= isset($config['summary_num'])?intval($config['summary_num']):100;
		$picnum = isset($config['pic_num'])?intval($config['pic_num']):3;
		$picwidth = isset($config['pic_width'])?intval($config['pic_width']):120;
		$picheight = isset($config['pic_height'])?intval($config['pic_height']):100;
		
		
		if( $pcopen && $groupopen ){			
			$threadlist = threadlist_decorate($_G['forum_threadlist'],$summarynum,$picnum,$picwidth,$picheight);
			return $threadlist;
		}
	}
	
	
	function group_thread_output(){	
		global $_G,$newthreadlist;		
		
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		$pcopen = intval($config['pc_open']);
		$groupopen = intval($config['group_open']);
		$summarynum= isset($config['summary_num'])?intval($config['summary_num']):100;
		$picnum = isset($config['pic_num'])?intval($config['pic_num']):3;
		$picwidth = isset($config['pic_width'])?intval($config['pic_width']):120;
		$picheight = isset($config['pic_height'])?intval($config['pic_height']):100;
		
		if( $pcopen && $groupopen ){			
			$threadlist = threadlist_decorate($newthreadlist['dateline']['data'],$summarynum,$picnum,$picwidth,$picheight);
			return $threadlist;
		}
	}
	
	
	
			
}

class plugin_wic_threadlist_decorate_search extends plugin_wic_threadlist_decorate{
	
	
	function forum_top_output(){
		
		global $_G;	
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		include template('wic_threadlist_decorate:css');
		
		return $css;
		
	}

	function forum_thread_output(){	
		global $_G,$threadlist;		
		
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		$pcopen = intval($config['pc_open']);
		$searchopen = intval($config['search_open']);
		$summarynum= isset($config['summary_num'])?intval($config['summary_num']):100;
		$picnum = isset($config['pic_num'])?intval($config['pic_num']):3;
		$picwidth = isset($config['pic_width'])?intval($config['pic_width']):120;
		$picheight = isset($config['pic_height'])?intval($config['pic_height']):100;
			
		if( $pcopen && $searchopen ){	
		$threadlists = threadlist_decorate($threadlist,$summarynum,$picnum,$picwidth,$picheight);
		return $threadlists;
		}
	}
}


class plugin_wic_threadlist_decorate_misc extends plugin_wic_threadlist_decorate{
	
	
	function tag_output(){
		
		global $_G;	
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		include template('wic_threadlist_decorate:css');
		
		return $css;
		
	}

	function tag_thread_output(){	
		global $_G,$threadlist;		
		
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		$pcopen = intval($config['pc_open']);
		$tagopen = intval($config['tag_open']);
		$summarynum= isset($config['summary_num'])?intval($config['summary_num']):100;
		$picnum = isset($config['pic_num'])?intval($config['pic_num']):3;
		$picwidth = isset($config['pic_width'])?intval($config['pic_width']):120;
		$picheight = isset($config['pic_height'])?intval($config['pic_height']):100;
		
		if( $pcopen && $tagopen ){	
		$threadlists = threadlist_decorate($threadlist,$summarynum,$picnum,$picwidth,$picheight);
		return $threadlists;
		}
	}
}


class mobileplugin_wic_threadlist_decorate {
	
	
}


class mobileplugin_wic_threadlist_decorate_forum extends mobileplugin_wic_threadlist_decorate{
	
	
	function forumdisplay_top_mobile_output(){
		
		global $_G;	
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		include template('wic_threadlist_decorate:css');
		
		return $css;
		
	}
	
	
	function forumdisplay_thread_mobile_output(){	
		global $_G;		
		
		$config = $_G['cache']['plugin']['wic_threadlist_decorate'];
		$mobileopen = intval($config['mobile_open']);
		$forumopen = intval($config['forum_open']);
		$openfid = (array)unserialize($config['open_forum']);
		$summarynum= isset($config['summary_num'])?intval($config['summary_num']):100;
		$picnum = isset($config['pic_num'])?intval($config['pic_num']):3;
		$picwidth = isset($config['pic_width'])?intval($config['pic_width']):120;
		$picheight = isset($config['pic_height'])?intval($config['pic_height']):100;
		$open=in_array('', $openfid) ? TRUE : (in_array($_G['fid'], $openfid) ? TRUE : FALSE);
		
		if( $mobileopen && $forumopen && $open ){	
			$threadlist = threadlist_decorate($_G['forum_threadlist'],$summarynum,$picnum,$picwidth,$picheight);	
		}
		
		return $threadlist;
		
	}
	
}


function threadlist_decorate($threadlist,$summarynum,$picnum,$picwidth,$picheight){

	global $_G;
	$message = array();
	$piclist = array();
	
	
	foreach( $threadlist as $k => $v){
		
		if( $v['tid'] ){
			$tids[] = $v['tid'];
		}else{
			$tids[] = $k;
		}
		
		
	}
	
	
	require_once libfile('function/post');
	
	$result = DB::fetch_all("SELECT tid,pid,message,attachment FROM ".DB::table("forum_post")." WHERE first=1 and tid in (".dimplode($tids).")");
	
	$resultsort = sortbytids($result, $tids);
	unset($tids);
	unset($result);
	
	
	foreach( $resultsort as $v){			
		if( $summarynum && $v['message'] ){	
			$message[$v['tid']]['message'] = messagecutstr($v['message'],$summarynum); 	
		}else{	
			$message[$v['tid']]['message'] = '';	
		}
		if( $v['attachment'] == 2 ){	
			$pids[] = $v['pid'];		
		}	
	}
	
	
	$attachment = DB::fetch_all("SELECT aid,tid FROM ".DB::table("forum_attachment")." WHERE pid in (".dimplode($pids).")");
	
	
	
	unset($pids);
	foreach( $attachment as $v ){	
		if( !isset($piclist[$v['tid']]) ){
			$attachment_source = _get_attachment($v['tid'],$v['aid']);
			//1直接插入图片-1附件图片
			if( $attachment_source['isimage'] == 1 ){
				$piclist[$v['tid']] = '<dd class="aimg'.$count[$v['tid']].'"><img src="'.getforumimg($v['aid'],0,$picwidth,$picheight,'').'" id="aimg_'.$v['aid'].'" zoomfile="'.( $attachment_source['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'] ).'forum/'.$attachment_source['attachment'].'" onclick=" zoom(this,\''.($attachment_source['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/'.$attachment_source['attachment'].'\',0,0,0) " initialized="true"/></dd>';
				$count[$v['tid']] = 1;
				$aidarr[$v['tid']][] = $v['aid'];
			}
		}else{
			if( $count[$v['tid']] < $picnum ){
				$attachment_source = _get_attachment($v['tid'],$v['aid']);
				if( $attachment_source['isimage'] == 1 ){
					$piclist[$v['tid']] .= '<dd class="aimg'.$count[$v['tid']].'"><img src="'.getforumimg($v['aid'],0,$picwidth,$picheight,'').'" id="aimg_'.$v['aid'].'" zoomfile="'.( $attachment_source['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl'] ).'forum/'.$attachment_source['attachment'].'" onclick=" zoom(this,\''.($attachment_source['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/'.$attachment_source['attachment'].'\',0,0,0) " initialized="true" /></dd>';
					$aidarr[$v['tid']][] = $v['aid'];
					$count[$v['tid']]++; 
				}
			} 
		}	
		
	}
	foreach( $threadlist as $k => $v){
		$tidkey = $v['tid'];
		$countaid[$v['tid']] = dimplode($aidarr[$v['tid']]);
		include template('wic_threadlist_decorate:threadlist');
		$threadlistarr[$k] = $threadshow;
	}
	unset($aidarr);
	return $threadlistarr;
		
}

function _get_attachment($tid,$aid){
	return DB::fetch_first("SELECT attachment,remote,isimage,readperm,price FROM ".DB::table(getattachtablebytid($tid))." WHERE aid =".$aid);
}


function sortbytids($result, $tids){
    $resultsort = array();
    foreach ($tids as $v) {
        foreach ($result as $value) {
            if ( $v == $value['tid'] ) {
                $resultsort[] = array(
                    'tid' => $v,
					'pid' => $value['pid'],
					'message' => $value['message'],
                    'attachment' => $value['attachment']);
            }
        }
    }
    return $resultsort;
}


//From: dis'.'m.tao'.'bao.com
?>