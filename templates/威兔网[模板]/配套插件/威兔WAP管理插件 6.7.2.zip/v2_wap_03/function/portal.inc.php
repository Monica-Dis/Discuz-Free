<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $vanylist;
	global $count;
	global $multipage;
	global $theurl;
	global $catids;
	global $aids;
	global $viewcatid;
	global $viewtporderby;
	global $viewtporderby;
	global $homeonlypic;
	global $homelishtimes;
	global $homesummary;
	global $homeperpage;
	global $cat;
	if (!isset($_G["cache"]["plugin"])) {
		loadcache("plugin");
	}
	$_var_14 = $_G["cache"]["plugin"]["v2_wap_03"]["tplkey"];
	$viewcatid = $_G["cache"]["plugin"]["v2_wap_03"]["viewcatid"];
	$viewtporderby = $_G["cache"]["plugin"]["v2_wap_03"]["viewtporderby"];
	$homeonlypic = $_G["cache"]["plugin"]["v2_wap_03"]["homeonlypic"];
	$homelishtimes = $_G["cache"]["plugin"]["v2_wap_03"]["homelishtimes"];
	$homesummary = $_G["cache"]["plugin"]["v2_wap_03"]["homesummarys"];
	$homeperpage = $_G["cache"]["plugin"]["v2_wap_03"]["homeperpages"];
	$catids = explode(",", $viewcatid);
	$count = $_var_18 = 0;
	$_var_19 = max(1, intval($_GET["page"]));
	$_var_18 = ($_var_19 - 1) * $homeperpage;
	$_var_20 = array(1 => "dateline", 2 => "viewnum", 3 => "commentnum", 4 => "favtimes", 5 => "sharetimes");
	$_var_21 = $_var_20[$viewtporderby];
	$_var_22 = 80;
	$homelishtimes = TIMESTAMP - 86400 * $homelishtimes;
	$_var_21 = $_var_21 == "dateline" ? "at.dateline DESC " : "ac." . $_var_21 . " DESC";
	$count = DB::result_first("SELECT count(*) FROM %t WHERE catid IN(%n) AND dateline>=" . $homelishtimes . " %i AND status=0", array("portal_article_title", $catids, $homeonlypic ? "AND pic != ''" : ''));
	$theurl = $cat["caturl"];
	$multipage = multi($count, $homeperpage, $_var_19, $theurl);
	$_var_23 = DB::fetch_all("SELECT * FROM %t at LEFT JOIN %t ac ON at.aid=ac.aid WHERE at.catid IN(%n) AND at.dateline>=" . $homelishtimes . " %i AND at.status=0 ORDER BY %i LIMIT %d, %d", array("portal_article_title", "portal_article_count", $catids, $homeonlypic ? "AND pic != ''" : NULL, $_var_21, $_var_18, $homeperpage));
	foreach ($_var_23 as $_var_24) {
		$_var_24["attachment"] = DB::fetch_all("SELECT remote,attachment FROM %t WHERE aid IN(%n) AND isimage = 1 LIMIT 0,3", array("portal_attachment", $_var_24["aid"]));
		$_var_24["title"] = cutstr(strip_tags($_var_24["title"]), $_var_22, '');
		$_var_24["summary"] = cutstr(strip_tags($_var_24["summary"]), $homesummary, '');
		$_var_24["catname"] = $_G["cache"]["portalcategory"][$_var_24["catid"]]["catname"];
		$_var_24["caturl"] = $_G["cache"]["portalcategory"][$_var_24["catid"]]["caturl"];
		$_var_24["dateline"] = dgmdate($_var_24["dateline"], "u", "9999", "Y-m-d");
		$vanylist[$_var_24["aid"]] = $_var_24;
	}