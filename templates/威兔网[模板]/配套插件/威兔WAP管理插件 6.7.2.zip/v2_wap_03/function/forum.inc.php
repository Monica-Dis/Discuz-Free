<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $manylist;
	global $count;
	global $multipage;
	global $theurl;
	global $forumfids;
	global $forumtporderby;
	global $homeonlypic;
	global $homelishtimes;
	global $homesummary;
	global $homeperpage;
	global $homethspecial;
	global $cat;
	global $imgnumber;
	if (!isset($_G["cache"]["plugin"])) {
		loadcache("plugin");
	}
	$_var_14 = $_G["cache"]["plugin"]["v2_wap_03"]["tplkey"];
	$forumfids = $_G["cache"]["plugin"]["v2_wap_03"]["forumfids"];
	$forumtporderby = $_G["cache"]["plugin"]["v2_wap_03"]["forumtporderby"];
	$homeonlypic = $_G["cache"]["plugin"]["v2_wap_03"]["homeonlypic"];
	$homelishtimes = $_G["cache"]["plugin"]["v2_wap_03"]["homelishtimes"];
	$homesummary = $_G["cache"]["plugin"]["v2_wap_03"]["homesummarys"];
	$homeperpage = $_G["cache"]["plugin"]["v2_wap_03"]["homeperpages"];
	$homethspecial = $_G["cache"]["plugin"]["v2_wap_03"]["homethspecial"];
	$_var_15 = $_G["cache"]["plugin"]["v2_wap_03"]["homelisttype"];
	$_var_16 = $_G["cache"]["plugin"]["v2_wap_03"]["imgexternal"];
	$_var_20 = array(1 => "lastpost", 2 => "dateline", 3 => "heats", 4 => "digest", 5 => "views", 6 => "replies");
	$_var_21 = $_var_20[$forumtporderby];
	$_var_22 = $homelishtimes;
	$_var_23 = 1;
	$_var_24 = $_G["page"];
	$_var_25 = DISCUZ_ROOT . "./data/cache/thread.cache.php";
	if ($_var_23 && $_var_24 == 1 && TIMESTAMP < @filemtime($_var_25) + $_var_23) {
		include $_var_25;
		$manylist = unserialize($manylist);
		$_var_26 = unserialize($_var_26);
	} else {
		require_once libfile("function/post");
		$_var_27 = ($_var_24 - 1) * $homeperpage;
		$_var_28 = '';
		$_var_29 = array();
		$forumfids = (array) unserialize($forumfids);
		$forumfids = join(",", $forumfids);
		if (!empty($forumfids)) {
			$_var_29[] = " t.fid in (" . $forumfids . ")";
		}
		if ($_var_22) {
			$_var_30 = TIMESTAMP - 86400 * $_var_22;
			$_var_29[] = "t.dateline>=" . $_var_30 . '';
		}
		if ($_var_31) {
			$_var_29[] = " t.typeid in (" . $_var_31 . ")";
		}
		if ($_var_32) {
			$_var_29[] = " t.sortid in (" . $_var_32 . ")";
		}
		if ($homethspecial >= 0) {
			$_var_29[] = "t.special = " . $homethspecial . '';
		}
		if ($homeonlypic) {
			$_var_29[] = "t.attachment = 2";
		}
		$_var_29[] = "t.displayorder >= 0";
		$_var_28 = $_var_29 ? "where " . join(" and ", $_var_29) : '';
		$manylist = array();
		$_var_33 = DB::query("SELECT t.*, f.name FROM " . DB::table("forum_thread") . " t LEFT JOIN " . DB::table("forum_forum") . " f ON f.fid=t.fid " . $_var_28 . " order by " . $_var_21 . " desc LIMIT " . $_var_27 . " , " . $homeperpage . '');
		while ($_var_34 = DB::fetch($_var_33)) {
			$_var_34["thumb"] = DB::fetch_all("SELECT aid FROM " . DB::table("forum_attachment_" . substr($_var_34["tid"], -1, 1)) . " WHERE tid =" . $_var_34["tid"] . " and width>0 order by dateline asc LIMIT 0 ," . $imgnumber);
			$_var_34["dateline"] = dgmdate($_var_34["dateline"], "u");
			if ($homesummary) {
				$_var_34["msg"] = DB::result_first("SELECT message FROM " . DB::table("forum_post") . " where tid='" . $_var_34["tid"] . "' and first=1 limit 1");
				$_var_34["msg"] = messagecutstr($_var_34["msg"], $homesummary);
			}
			if ($_var_15 == 1) {
				$_var_34["groupid"] = DB::result_first("SELECT groupid FROM " . DB::table("common_member") . " where uid = " . $_var_34["authorid"]);
				$_var_34["stars"] = DB::result_first("SELECT stars FROM " . DB::table("common_usergroup") . " where groupid ='" . $_var_34["groupid"] . "'");
				$_var_34["grouptitle"] = DB::result_first("SELECT grouptitle FROM " . DB::table("common_usergroup") . " where groupid ='" . $_var_34["groupid"] . "'");
			}
			if ($_var_16) {
				$_var_34["msgpic"] = DB::result_first("SELECT message FROM " . DB::table("forum_post") . " where tid='" . $_var_34["tid"] . "' and first=1 limit 1");
				preg_match_all("/\\[img.*?\\](.*?)\\[\\/img\\]/is", $_var_34["msgpic"], $_var_35);
				$_var_34["eximgurls"] = array_slice($_var_35[1], 0, $imgnumber);
			}
			$manylist[] = $_var_34;
		}
		$count = DB::result_first("SELECT count(*) FROM " . DB::table("forum_thread") . " t LEFT JOIN " . DB::table("forum_forum") . " f ON f.fid=t.fid " . $_var_28 . '');
		if ($_var_23 && $_var_24 == 1) {
			$_var_36 = serialize($manylist);
			$_var_37 = serialize($_var_26);
			$_var_38 = "<?php if(!defined('IN_DISCUZ')) {exit('Access Denied');} ";
			$_var_38 = $_var_38 . ("\$manylist='" . $_var_36 . "';");
			$_var_38 = $_var_38 . ("\$allpage='" . $_var_37 . "';");
			$_var_38 = $_var_38 . "?>";
			file_put_contents($_var_25, $_var_38);
		}
	}
	$theurl = $cat["caturl"];
	$multipage = multi($count, $homeperpage, $_var_24, '' . $theurl . '');