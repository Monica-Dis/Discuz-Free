<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $manylist;
	global $ordertype;
	global $pagenav;
	global $allnum;
	global $pagenum;
	global $theurl;
	global $portalcategory;
	global $catid;
	if (!isset($_G["cache"]["plugin"])) {
		loadcache("plugin");
	}
	$_var_9 = $_G["cache"]["plugin"]["v2_wap_03"]["tplkey"];
	$_var_10 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["picdyfids"];
	$_var_11 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["picorderby"];
	$_var_12 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["picday"];
	$_var_13 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["picpagenum"];
	$_var_14 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pictypeids"];
	$_var_15 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["picsortids"];
	$_var_16 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["picspecial"];
	$_var_20 = 1;
	$_var_21 = array(1 => "lastpost", 2 => "dateline", 3 => "heats", 4 => "digest", 5 => "views", 6 => "replies");
	$ordertype = intval($_GET["ordertype"]);
	$_var_22 = $_var_21[$ordertype] ? $_var_21[$ordertype] : $_var_21[$_var_11];
	$_var_23 = $_G["page"];
	$_var_24 = DISCUZ_ROOT . "./data/cache/pic." . $_var_22 . ".cache.php";
	if ($_var_20 && $_var_23 == 1 && TIMESTAMP < @filemtime($_var_24) + $_var_20) {
		include $_var_24;
		$manylist = unserialize($manylist);
		$_var_25 = unserialize($_var_25);
	} else {
		$pagenum = $_var_13;
		$_var_26 = ($_var_23 - 1) * $pagenum;
		$_var_27 = '';
		$_var_28 = array();
		$_var_10 = (array) unserialize($_var_10);
		$_var_10 = join(",", $_var_10);
		if (!empty($_var_10)) {
			$_var_28[] = " fid in (" . $_var_10 . ")";
		}
		if ($_var_12) {
			$_var_29 = TIMESTAMP - 86400 * $_var_12;
			$_var_28[] = "dateline >= " . $_var_29 . '';
		}
		if ($_var_14) {
			$_var_28[] = " typeid in (" . $_var_14 . ")";
		}
		if ($_var_15) {
			$_var_28[] = " sortid in (" . $_var_15 . ")";
		}
		if ($_var_16 >= 0) {
			$_var_28[] = "special = " . $_var_16 . '';
		}
		$_var_28[] = "attachment = 2";
		$_var_28[] = "displayorder >= 0";
		$_var_27 = $_var_28 ? "where " . join(" and ", $_var_28) : '';
		$manylist = array();
		$_var_30 = DB::query("SELECT * FROM " . DB::table("forum_thread") . " " . $_var_27 . " order by " . $_var_22 . " desc LIMIT " . $_var_26 . " , " . $pagenum . '');
		while ($_var_31 = DB::fetch($_var_30)) {
			$_var_31["thumb"] = DB::result_first("SELECT aid FROM " . DB::table("forum_attachment_" . substr($_var_31["tid"], -1, 1)) . " WHERE tid =" . $_var_31["tid"] . " and width>0 order by dateline asc LIMIT 0 , 1");
			$manylist[] = $_var_31;
		}
		$allnum = DB::result_first("SELECT count(*) FROM " . DB::table("forum_thread") . " " . $_var_27 . '');
		if ($_var_20 && $_var_23 == 1) {
			$_var_32 = serialize($manylist);
			$_var_33 = serialize($_var_25);
			$_var_34 = "<?php if(!defined('IN_DISCUZ')) {exit('Access Denied');} ";
			$_var_34 = $_var_34 . ("\$manylist='" . $_var_32 . "';");
			$_var_34 = $_var_34 . ("\$allpage='" . $_var_33 . "';");
			$_var_34 = $_var_34 . "?>";
			file_put_contents($_var_24, $_var_34);
		}
	}
	$theurl = $portalcategory[$catid]["fullfoldername"] . "/?ordertype=" . $ordertype;
	$pagenav = multi($allnum, $pagenum, $_var_23, '' . $theurl . '');