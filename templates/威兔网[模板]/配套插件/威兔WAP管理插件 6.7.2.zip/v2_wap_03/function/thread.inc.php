<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $manylist;
	global $picmanylist;
	global $pagenav;
	global $allnum;
	global $pagenum;
	global $theurl;
	global $portalcategory;
	global $catid;
	global $imgnumber;
	if (!isset($_G["cache"]["plugin"])) {
		loadcache("plugin");
	}
	$_var_10 = $_G["cache"]["plugin"]["v2_wap_03"]["tplkey"];
	$_var_11 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthfids"];
	$_var_12 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthtypes"];
	$_var_13 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthtids"];
	$_var_14 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthspecial"];
	$_var_15 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthorderby"];
	$_var_16 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthday"];
	$_var_17 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthpagenum"];
	$_var_18 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthtypeids"];
	$_var_19 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthsortids"];
	$_var_20 = $_G["cache"]["plugin"]["v2_wap_03_plus"]["pthmsgnum"];
	$_var_24 = 1;
	$_var_25 = array(1 => "lastpost", 2 => "dateline", 3 => "heats", 4 => "digest", 5 => "views", 6 => "replies");
	$_var_26 = $_var_25[$_var_15];
	$_var_27 = $_G["page"];
	$_var_28 = DISCUZ_ROOT . "./data/cache/thread.cache.php";
	if ($_var_24 && $_var_27 == 1 && TIMESTAMP < @filemtime($_var_28) + $_var_24) {
		include $_var_28;
		$manylist = unserialize($manylist);
		$_var_29 = unserialize($_var_29);
	} else {
		require_once libfile("function/post");
		$pagenum = $_var_17;
		$_var_30 = ($_var_27 - 1) * $pagenum;
		$_var_31 = '';
		$_var_32 = array();
		$_var_11 = (array) unserialize($_var_11);
		$_var_11 = join(",", $_var_11);
		if (!empty($_var_11)) {
			$_var_32[] = " fid in (" . $_var_11 . ")";
		}
		if ($_var_16) {
			$_var_33 = TIMESTAMP - 86400 * $_var_16;
			$_var_32[] = "dateline >= " . $_var_33 . '';
		}
		if ($_var_18) {
			$_var_32[] = " typeid in (" . $_var_18 . ")";
		}
		if ($_var_19) {
			$_var_32[] = " sortid in (" . $_var_19 . ")";
		}
		if ($_var_14 >= 0) {
			$_var_32[] = "special = " . $_var_14 . '';
		}
		$_var_32[] = "attachment = 2";
		$_var_32[] = "displayorder >= 0";
		$_var_31 = $_var_32 ? "where " . join(" and ", $_var_32) : '';
		$manylist = array();
		$_var_34 = DB::query("SELECT * FROM " . DB::table("forum_thread") . " " . $_var_31 . " order by " . $_var_26 . " desc LIMIT " . $_var_30 . " , " . $pagenum . '');
		while ($_var_35 = DB::fetch($_var_34)) {
			$_var_35["thumb"] = DB::fetch_all("SELECT aid FROM " . DB::table("forum_attachment_" . substr($_var_35["tid"], -1, 1)) . " WHERE tid = " . $_var_35["tid"] . " and width>0 order by dateline asc LIMIT 0 ," . $imgnumber);
			$_var_35["dateline"] = dgmdate($_var_35["dateline"], "u");
			if ($_var_20) {
				$_var_35["msg"] = DB::result_first("SELECT message FROM " . DB::table("forum_post") . " where tid='" . $_var_35["tid"] . "' and first=1 limit 1");
				$_var_35["msg"] = messagecutstr($_var_35["msg"], $_var_20);
			}
			if ($_var_12 == 1) {
				$_var_35["groupid"] = DB::result_first("SELECT groupid FROM " . DB::table("common_member") . " where uid = " . $_var_35["authorid"]);
				$_var_35["stars"] = DB::result_first("SELECT stars FROM " . DB::table("common_usergroup") . " where groupid ='" . $_var_35["groupid"] . "'");
				$_var_35["grouptitle"] = DB::result_first("SELECT grouptitle FROM " . DB::table("common_usergroup") . " where groupid ='" . $_var_35["groupid"] . "'");
			}
			$manylist[] = $_var_35;
		}
		$allnum = DB::result_first("SELECT count(*) FROM " . DB::table("forum_thread") . " " . $_var_31 . '');
		$picmanylist = array();
		$_var_31 = "where tid in (" . $_var_13 . ") and displayorder >= 0 ";
		$_var_31 = "where tid in (" . $_var_13 . ")";
		$_var_26 = "find_in_set(tid,'" . $_var_13 . "')";
		$_var_34 = DB::query("SELECT * FROM " . DB::table("forum_thread") . " " . $_var_31 . " order by " . $_var_26 . " asc");
		while ($_var_35 = DB::fetch($_var_34)) {
			$_var_35["thumb"] = DB::result_first("SELECT aid FROM " . DB::table("forum_attachment_" . substr($_var_35["tid"], -1, 1)) . " WHERE tid =" . $_var_35["tid"] . " and width>0 order by dateline asc LIMIT 0 , 1");
			$picmanylist[] = $_var_35;
		}
		if ($_var_24 && $_var_27 == 1) {
			$_var_36 = serialize($manylist);
			$_var_37 = serialize($_var_29);
			$_var_38 = "<?php if(!defined('IN_DISCUZ')) {exit('Access Denied');} ";
			$_var_38 = $_var_38 . ("\$manylist='" . $_var_36 . "';");
			$_var_38 = $_var_38 . ("\$allpage='" . $_var_37 . "';");
			$_var_38 = $_var_38 . "?>";
			file_put_contents($_var_28, $_var_38);
		}
	}
	$theurl = $portalcategory[$catid]["fullfoldername"];
	$pagenav = multi($allnum, $pagenum, $_var_27, '' . $theurl . '');