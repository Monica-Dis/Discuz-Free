<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_v2_wap_03 {
}	
class plugin_v2_wap_03_portal extends plugin_v2_wap_03  {	
	function list_output(){		
		require_once DISCUZ_ROOT . './source/plugin/v2_wap_03/corefile/hook.core.php';		
	}	
	function view_output(){				
		require_once DISCUZ_ROOT . './source/plugin/v2_wap_03/corefile/hook.core.php';
	}
}
//From: Dism_taobao_com
?>