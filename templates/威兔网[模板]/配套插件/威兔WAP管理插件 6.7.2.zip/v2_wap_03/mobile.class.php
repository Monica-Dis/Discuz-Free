<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_v2_wap_03 {
	function global_sidemenus_v2_mobile(){		
		global $_G;				
		$tplsidemenus = $_G['cache']['plugin']['v2_wap_03']['tplsidemenus'];		
		$tplsidemenus = str_replace(array("\r\n", "\n", "\r"), '/ssssss/', $tplsidemenus);
		$tplsidemenus = explode("/ssssss/",$tplsidemenus);
		foreach($tplsidemenus as $k => $v ){
			$v = explode("|",$v);
			if(!empty($v[2])){
				$v[2] = '<i style="background-image: url(template/v2_mbl20121009/touch_plus/image/side_img/'.$v[2].'.png);"></i>';
			}
			if(!empty($v[3])){
				$v[3] = ' style="color:'.$v[3].';"';
			}
			if(!empty($v[4])){
				$v[4] = '<em>'.$v[4].'</em>';
			}
			$urlnames .= '<li><a href="'.$v[1].'" class="urlstyle_'.$k.'"'.$v[3].'>'.$v[2].$v[0].$v[4].'</a></li>';		
			unset($k);
		}		
		return $urlnames;
	}	
	function global_popupmenus_v2_mobile(){		
		global $_G;				
		$tplpopupmenus = $_G['cache']['plugin']['v2_wap_03']['tplpopupmenus'];		
		$tplpopupmenus = str_replace(array("\r\n", "\n", "\r"), '/ssssss/', $tplpopupmenus);
		$tplpopupmenus = explode("/ssssss/",$tplpopupmenus);
		foreach($tplpopupmenus as $k => $v ){
			$v = explode("|",$v);
			if(!empty($v[2])){
				$v[2] = '<img src="template/v2_mbl20121009/touch_plus/image/popmenu_img/'.$v[2].'.png" />';
			}
			if(!empty($v[3])){
				$v[3] = ' style="color:'.$v[3].';"';
			}
			$urlnames .= '<li><a href="'.$v[1].'" class="popurlstyle_'.$k.'">'.$v[2].'<span'.$v[3].'>'.$v[0].'</span></a></li>';		
			unset($k);
		}		
		return $urlnames;
	}	
}
	
class mobileplugin_v2_wap_03_portal extends mobileplugin_v2_wap_03 {	
	function list_pctpl(){
		require_once DISCUZ_ROOT . './source/plugin/v2_wap_03/corefile/mobile.core.php';
	}
}

class mobileplugin_v2_wap_03_forum extends mobileplugin_v2_wap_03 {	
	function forumdisplay_pctpl(){
		require_once DISCUZ_ROOT . './source/plugin/v2_wap_03/corefile/mobile.page.core.php';
	}	
}
//From: Dism_taobao_com
?>