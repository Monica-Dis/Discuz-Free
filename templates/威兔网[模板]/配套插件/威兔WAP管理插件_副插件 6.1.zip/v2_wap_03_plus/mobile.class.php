<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_v2_wap_03_plus {
	function global_pthtopmenu_v2_mobile(){		
		global $_G;				
		$pthtopmenu = $_G['cache']['plugin']['v2_wap_03_plus']['pthtopmenu'];		
		$pthtopmenu = str_replace(array("\r\n", "\n", "\r"), '/ssssss/', $pthtopmenu);
		$pthtopmenu = explode("/ssssss/",$pthtopmenu);
		foreach($pthtopmenu as $k => $v ){
			$v = explode("|",$v);
			if(!empty($v[2])){
				$v[2] = ' style="color:'.$v[2].';"';
			}
			$pthurlnames .= '<li class="menu_slide"><a href="'.$v[1].'" class="pturlstyle_'.$k.'"'.$v[2].'>'.$v[0].'</a></li>';		
			unset($k);
		}		
		return $pthurlnames;
	}	
}
//From: Dism_taobao_com
?>