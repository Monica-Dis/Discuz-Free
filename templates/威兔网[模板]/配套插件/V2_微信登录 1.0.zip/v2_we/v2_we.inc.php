<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	$_var_1 = $_G["cache"]["plugin"]["v2_we"]["appid"];
	$_var_2 = $_G["cache"]["plugin"]["v2_we"]["appsecert"];
	require_once libfile("function", "plugin/v2_we/function");
	include_once libfile("function/cache");
	include_once libfile("function/member");
	include_once DISCUZ_ROOT . "source/plugin/wechat/wechat.lib.class.php";
	$_var_3 = $_G["config"]["security"]["authkey"];
	$_var_4 = new WeChatClient(trim($_var_1), trim($_var_2));
	$_var_5 = substr(md5("wechat" . $_G["siteurl"] . $_var_1), 0, 8);
	$_var_6 = !empty($_G["cookie"][$_var_5]) ? authcode($_G["cookie"][$_var_5], "DECODE", $_var_3) : '';
	if (!$_var_6) {
		if (empty($_GET["oauth"])) {
			$_var_7 = $_var_4->getOAuthConnectUri($_G["siteurl"] . "plugin.php?id=v2_we&oauth=yes&backreferer=" . urlencode($_GET["backreferer"]), '', "snsapi_userinfo");
			dheader("location: " . $_var_7);
		} else {
			$_var_8 = $_var_4->getAccessTokenByCode($_GET["code"]);
			$_var_9 = $_var_8["access_token"];
			$_var_6 = $_var_8["openid"];
			dsetcookie($_var_5, authcode($_var_6, "ENCODE", $_var_3), 7100);
			dsetcookie("accessn", authcode($_var_9, "ENCODE", $_var_3), 7100);
		}
	}
	if (!$_var_6) {
		showmessage("NO OPENID");
	}
	$_var_10 = $_var_4->getUserInfoByAuth(authcode($_G["cookie"]["accessn"], "DECODE", $_var_3), $_var_6);
	$_var_11 = WeChatEmoji::clear($_var_10["nickname"]);
	foreach ($_var_10 as $_var_12 => $_var_13) {
		$_var_10[$_var_12] = diconv($_var_10[$_var_12], "utf-8");
	}
	$_var_10["nickname"] = $_var_11;
	$_var_14 = C::t("#wechat#common_member_wechat")->fetch_by_openid($_var_6);
	$_var_15 = 0;
	if ($_var_14["uid"]) {
		$_var_15 = 1;
		$_var_16 = $_var_14["uid"];
	} else {
		$_var_16 = v2_we_register($_var_10);
		if ($_var_16) {
			WeChatHook::bindOpenId($_var_16, $_var_6, 1);
			$_var_15 = 1;
		}
	}
	if ($_var_15) {
		require_once libfile("function/member");
		$_var_17 = getuserbyuid($_var_16, 1);
		setloginstatus($_var_17, 1296000);
		$_var_18 = $_G["cache"]["plugin"]["v2_we"]["backreferer"] ? $_GET["backreferer"] : $_G["siteurl"];
	} else {
		$_var_18 = $_G["siteurl"];
	}
	dheader("Location: " . $_var_18 . '');