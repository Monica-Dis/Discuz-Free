<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//class plugin_v2_we_forum extends plugin_v2_we { }

global $_G,$v2qrcode;
$v2qrcode = $_G['cache']['plugin']['v2_we'];
class plugin_v2_we {
	function global_header(){
		global $v2qrcode;		
		$qrcode1 = $v2qrcode['qrcode1'];
		$qrcode2 = $v2qrcode['qrcode2'];
		$qrcodetxt = $v2qrcode['qrcodetxt'];
		$qrcodeleft = $v2qrcode['qrcodeleft'] + 10;		
		if ($qrcode1 || $qrcode2){			
		if ($qrcode1){
		return '<div style="text-align:center;position:fixed;left:50%;top:200px;z-index:999;width:120px;margin-left:'.$qrcodeleft.'px;background:#fff;"><img src="http://qr.liantu.com/api.php?w=120&m=10&el=q&text='.$qrcode1.'" /><p style="line-height:18px; padding:5px 10px;">'.$qrcodetxt.'</p></div>'; 	
		}else{
		return '<div style="text-align:center;position:fixed;left:50%;top:200px;z-index:999;width:120px;margin-left:'.$qrcodeleft.'px;background:#fff;"><img src="'.$qrcode2.'" width="120" /><p style="line-height:18px; padding:5px 10px;">'.$qrcodetxt.'</p></div>';	
		}				
		}
	}
}
//From: Dism_taobao_com
?>