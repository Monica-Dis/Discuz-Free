<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_v2_we{	
     function common(){		 
		 require_once DISCUZ_ROOT . './source/plugin/v2_we/v2_we.core.php';	
    }
}

class mobileplugin_v2_we_member extends mobileplugin_v2_we{	
    function logging_bottom_mobile(){		
		global $_G;			
		$btnshow = $_G['cache']['plugin']['v2_we']['btnshow'];
		$btntxt = $_G['cache']['plugin']['v2_we']['btntxt'];
		$inwechat = $_G['cache']['plugin']['v2_we']['inwechat'];
		$myurl = urlencode($_G['cache']['plugin']['v2_we']['backreferer']);	
		$browser = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false; 	
		$return = '<style type="text/css">'.$btnshow.'</style><a href="plugin.php?id=v2_we&mod=login&backreferer='.$myurl.'?mobile=2" class="weixinlogin" >'.$btntxt.'</a>';		
		if($inwechat == 0 || $browser){
			return $return;
		}
    }
}
//From: Dism_taobao_com
?>