<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	if ($_GET["mod"] == "logging" || $_GET["mod"] == "register") {
		$_G["cache"]["plugin"]["v2_we"]["backreferer"] = dreferer();
	} else {
		$_var_1 = isset($_SERVER["SERVER_PORT"]) && $_SERVER["SERVER_PORT"] == "443" ? "https://" : "http://";
		$_var_2 = $_SERVER["PHP_SELF"] ? $_SERVER["PHP_SELF"] : $_SERVER["SCRIPT_NAME"];
		$_var_3 = isset($_SERVER["PATH_INFO"]) ? $_SERVER["PATH_INFO"] : '';
		$_var_4 = isset($_SERVER["REQUEST_URI"]) ? $_SERVER["REQUEST_URI"] : $_var_2 . (isset($_SERVER["QUERY_STRING"]) ? "?" . $_SERVER["QUERY_STRING"] : $_var_3);
		$_G["cache"]["plugin"]["v2_we"]["backreferer"] = $_var_1 . (isset($_SERVER["HTTP_HOST"]) ? $_SERVER["HTTP_HOST"] : '') . $_var_4;
	}