<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
function v2_we_register($_arg_0)
{
	global $_G;
	$_var_2 = $_arg_0["nickname"];
	$_var_3 = $_arg_0["headimgurl"];
	if (!$_var_2) {
		return 0;
	}
	if (!$_G["wechat"]["setting"]) {
		$_G["wechat"]["setting"] = unserialize($_G["setting"]["mobilewechat"]);
	}
	loaducenter();
	$_var_4 = $_G["cache"]["plugin"]["v2_we"]["user_group"];
	$_var_5 = $_var_4 ? $_var_4 : $_G["setting"]["newusergroupid"];
	$_var_6 = md5(random(10));
	$_var_7 = strtolower(random(12)) . "@qq.com";
	$_var_8 = dstrlen($_var_2);
	if ($_var_8 < 3) {
		$_var_2 = $_var_2 . mt_rand(1000, 9999);
	}
	if ($_var_8 > 15) {
		$_var_2 = cutstr($_var_2, 15, '');
	}
	$_var_9 = "\\xA1\\xA1|\\xAC\\xA3|^Guest|^\\xD3\\xCE\\xBF\\xCD|\\xB9\\x43\\xAB\\xC8";
	$_var_2 = preg_replace("/\\s+|^c:\\con\\con|[%,\\*\"\\s\\<\\>\\&]|" . $_var_9 . "/is", '', $_var_2);
	if (C::t("common_member")->fetch_by_username($_var_2) || uc_user_checkname($_var_2) != "1") {
		$_var_2 = cutstr($_var_2, 12, '') . mt_rand(1, 999);
	}
	$_var_10 = "/^(" . str_replace(array("\\*", "\r\n", " "), array(".*", "|", ''), preg_quote($_G["setting"]["censoruser"] = trim($_G["setting"]["censoruser"]), "/")) . ")\$/i";
	$_G["setting"]["censoruser"] && @preg_replace($_var_10, "_", $_var_2);
	$_var_11 = uc_user_register(addslashes($_var_2), $_var_6, $_var_7, '', '', $_G["clientip"]);
	if ($_var_11 <= 0) {
		if ($_var_11 == -1) {
			showmessage("profile_username_illegal");
		} else {
			if ($_var_11 == -2) {
				showmessage("profile_username_protect");
			} else {
				if ($_var_11 == -3) {
					showmessage("profile_username_duplicate");
				} else {
					if ($_var_11 == -4) {
						showmessage("profile_email_illegal");
					} else {
						if ($_var_11 == -5) {
							showmessage("profile_email_domain_illegal");
						} else {
							if ($_var_11 == -6) {
								showmessage("profile_email_duplicate");
							} else {
								showmessage("undefined_action");
							}
						}
					}
				}
			}
		}
		return $_var_11;
	}
	$_var_12 = array("credits" => explode(",", $_G["setting"]["initcredits"]));
	C::t("common_member")->insert($_var_11, $_var_2, $_var_6, $_var_7, $_G["clientip"], $_var_5, $_var_12);
	setloginstatus(array("uid" => $_var_11, "username" => $_var_2, "password" => $_var_6, "groupid" => $_var_5), 0);
	include_once libfile("function/stat");
	updatestat("register");
	v2_syncAvatar($_var_11, $_var_3);
	return $_var_11;
}
function v2_syncAvatar($_arg_0, $_arg_1)
{
	if (!$_arg_0 || !$_arg_1) {
		return false;
	}
	if (!($_var_2 = dfsockopen($_arg_1))) {
		return false;
	}
	$_var_3 = DISCUZ_ROOT . "./data/avatar/" . TIMESTAMP . random(6);
	file_put_contents($_var_3, $_var_2);
	if (!is_file($_var_3)) {
		return false;
	}
	$_var_4 = uploadUcAvatar_upload($_arg_0, $_var_3);
	unlink($_var_3);
	C::t("common_member")->update($_arg_0, array("avatarstatus" => "1"));
	return $_var_4;
}
function uploadUcAvatar_upload($_arg_0, $_arg_1)
{
	global $_G;
	if (!$_arg_0 || !$_arg_1) {
		return false;
	}
	list($_var_3, $_var_4, $_var_5, $_var_6) = getimagesize($_arg_1);
	if (!$_var_3) {
		return false;
	}
	if ($_var_3 < 10 || $_var_4 < 10 || $_var_5 == 4) {
		return false;
	}
	$_var_7 = array(1 => ".gif", 2 => ".jpg", 3 => ".png");
	$_var_8 = $_var_9[$_var_5];
	if (!$_var_8) {
		$_var_8 = ".jpg";
	}
	$_var_10 = $_G["setting"]["attachdir"];
	$_var_11 = $_var_10 . "./temp/upload" . $_arg_0 . $_var_8;
	file_exists($_var_11) && @unlink($_var_11);
	file_put_contents($_var_11, file_get_contents($_arg_1));
	if (!is_file($_var_11)) {
		return false;
	}
	$_var_12 = "./temp/upload" . $_arg_0 . "big" . $_var_8;
	$_var_13 = "./temp/upload" . $_arg_0 . "middle" . $_var_8;
	$_var_14 = "./temp/upload" . $_arg_0 . "small" . $_var_8;
	$_var_15 = new image();
	if ($_var_15->Thumb($_var_11, $_var_12, 200, 250, 1) <= 0) {
		return false;
	}
	if ($_var_15->Thumb($_var_11, $_var_13, 120, 120, 1) <= 0) {
		return false;
	}
	if ($_var_15->Thumb($_var_11, $_var_14, 48, 48, 2) <= 0) {
		return false;
	}
	$_var_12 = $_var_10 . $_var_12;
	$_var_13 = $_var_10 . $_var_13;
	$_var_14 = $_var_10 . $_var_14;
	$_var_16 = v2_byte2hex(file_get_contents($_var_12));
	$_var_17 = v2_byte2hex(file_get_contents($_var_13));
	$_var_18 = v2_byte2hex(file_get_contents($_var_14));
	$_var_19 = "&avatar1=" . $_var_16 . "&avatar2=" . $_var_17 . "&avatar3=" . $_var_18;
	$_var_20 = v2_uc_api_post_ex("user", "rectavatar", array("uid" => $_arg_0), $_var_19);
	@unlink($_var_11);
	@unlink($_var_12);
	@unlink($_var_13);
	@unlink($_var_14);
	return true;
}
function v2_byte2hex($_arg_0)
{
	$_var_1 = '';
	$_var_2 = unpack("H*", $_arg_0);
	$_var_2 = str_split($_var_2[1], 2);
	$_var_3 = '';
	foreach ($_var_2 as $_var_4 => $_var_5) {
		$_var_3 = $_var_3 . strtoupper($_var_5);
	}
	return $_var_3;
}
function v2_uc_api_post_ex($_arg_0, $_arg_1, $_arg_2 = array(), $_arg_3 = '')
{
	$_var_4 = $_var_5 = '';
	foreach ($_arg_2 as $_var_6 => $_var_7) {
		$_var_6 = urlencode($_var_6);
		if (is_array($_var_7)) {
			$_var_8 = $_var_9 = '';
			foreach ($_var_7 as $_var_10 => $_var_11) {
				$_var_10 = urlencode($_var_10);
				$_var_8 = $_var_8 . ('' . $_var_9 . '' . $_var_6 . "[" . $_var_10 . "]=" . urlencode(uc_stripslashes($_var_11)));
				$_var_9 = "&";
			}
			$_var_4 = $_var_4 . ($_var_5 . $_var_8);
		} else {
			$_var_4 = $_var_4 . ('' . $_var_5 . '' . $_var_6 . "=" . urlencode(uc_stripslashes($_var_7)));
		}
		$_var_5 = "&";
	}
	$_var_12 = uc_api_requestdata($_arg_0, $_arg_1, $_var_4, $_arg_3);
	return uc_fopen2(UC_API . "/index.php", 500000, $_var_12, '', true, UC_IP, 20);
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}