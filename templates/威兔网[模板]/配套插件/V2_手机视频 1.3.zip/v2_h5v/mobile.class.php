<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	require_once DISCUZ_ROOT . './source/plugin/v2_h5v/play.core.php';
	
	class mobileplugin_v2_h5v {			
		function discuzcode($param){			
			global $_G;								
			@extract($_G['cache']['plugin']['v2_h5v']);
			
			$groups = in_array($_G['groupid'], unserialize($groups));
			if ($param['caller'] == 'discuzcode' && in_array($_G['fid'], unserialize($forums)) && $groups){
				$_G['discuzcodemessage'] =  $src . deal($_G['discuzcodemessage'],$height);
			}			
		}		
}
//From: dis'.'m.tao'.'bao.com
?>