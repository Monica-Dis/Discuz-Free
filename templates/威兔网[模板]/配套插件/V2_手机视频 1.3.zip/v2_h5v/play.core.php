<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
function istype($_arg_0, $_arg_1)
{
	return preg_match("/" . $_arg_0 . "/i", $_arg_1, $_var_2);
}
function get_type($_arg_0)
{
	$_var_1 = array("qq" => "video.qq.com", "qq2" => "imgcache.qq.com", "qq3" => "v.qq.com\\/x\\/page", "qq4" => "v.qq.com\\/x\\/cover", "qq5" => "m.v.qq.com\\/play.html", "qq6" => "m.v.qq.com\\/page", "youku" => "player.youku.com", "youku2" => "v.youku.com", "youku3" => "m.youku.com", "tudou" => "tudou.com\\/v", "bilibili" => "bilibili.com", "acfun" => "acfun.cn", "iqiyi" => "open.iqiyi.com", "ku6" => "ku6.com", "mp3" => "mp3");
	foreach ($_var_1 as $_var_2 => $_var_3) {
		if (istype($_var_3, $_arg_0)) {
			return $_var_2;
		}
	}
	return 0;
}
function get_embed($_arg_0, $_arg_1, $_arg_2)
{
	if ($_arg_0 == "mp4") {
		return returndata($_arg_1, $_arg_2);
	}
	if ($_arg_0 == "qq") {
		$_var_3 = explode("vid=", $_arg_1);
		$_var_3 = explode("&", $_var_3[1]);
		$_var_3 = $_var_3[0];
		return "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $_var_3 . "&tiny=0&auto=0\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "qq2") {
		$_var_3 = explode("vid=", $_arg_1);
		$_var_3 = explode("&", $_var_3[1]);
		$_var_3 = $_var_3[0];
		return "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $_var_3 . "&tiny=0&auto=0\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "qq3") {
		$_var_3 = explode("x/page/", $_arg_1);
		$_var_3 = explode(".html", $_var_3[1]);
		$_var_3 = $_var_3[0];
		return "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $_var_3 . "&tiny=0&auto=0\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "qq4") {
		$_var_3 = explode("x/cover/", $_arg_1);
		$_var_3 = explode(".html", $_var_3[1]);
		$_var_3 = explode("/", $_var_3[0]);
		$_var_3 = $_var_3[1];
		return "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $_var_3 . "&tiny=0&auto=0\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "qq5") {
		$_var_3 = explode("vid=", $_arg_1);
		$_var_3 = $_var_3[1];
		return "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $_var_3 . "&tiny=0&auto=0\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "qq6") {
		$_var_3 = explode(".html?ptag=", $_arg_1);
		$_var_3 = substr($_var_3[0], -11);
		return "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $_var_3 . "&tiny=0&auto=0\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "youku") {
		$_var_3 = explode("sid/", $_arg_1);
		$_var_3 = explode("/v.swf", $_var_3[1]);
		$_var_3 = $_var_3[0];
		return "<iframe src=\"https://player.youku.com/embed/" . $_var_3 . "\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "youku2") {
		$_var_3 = explode("v_show/id_", $_arg_1);
		$_var_3 = explode(".html", $_var_3[1]);
		$_var_3 = $_var_3[0];
		return "<iframe src=\"https://player.youku.com/embed/" . $_var_3 . "\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "youku3") {
		$_var_3 = explode("video/id_", $_arg_1);
		$_var_3 = explode(".html", $_var_3[1]);
		$_var_3 = $_var_3[0];
		return "<iframe src=\"https://player.youku.com/embed/" . $_var_3 . "\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "tudou") {
		$_var_3 = explode("/v/", $_arg_1);
		$_var_3 = explode("==", $_var_3[1]);
		$_var_3 = $_var_3[0];
		return "<iframe src=\"https://player.youku.com/embed/" . $_var_3 . "\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "bilibili") {
		$_var_4 = "|(\\d+)|";
		preg_match($_var_4, $_arg_1, $_var_5);
		$_var_3 = $_var_5[1];
		return "<iframe src=\"https://player.bilibili.com/player.html?aid=" . $_var_3 . "\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "acfun") {
		$_arg_1 = dfsockopen($_arg_1);
		preg_match("/videoId\\\":(\\d+),/", $_arg_1, $_var_6);
		$_var_3 = $_var_6[1];
		return "<iframe src=\"http://m.acfun.cn/ykplayer?date=undefined#vid=" . $_var_3 . ";\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
	}
	if ($_arg_0 == "ku6") {
		return "<embed src=\"" . $_arg_1 . "\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" quality=\"high\" align=\"middle\" allowscriptaccess=\"always\" allowfullscreen=\"true\" type=\"application/x-shockwave-flash\" flashvars=\"\"></embed>";
	}
	if ($_arg_0 == "mp3") {
		return "<audio src=\"" . $_arg_1 . "\" id=\"audio_" . substr(md5($_arg_1), 14, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" style=\"width:100%;\">" . " <source src=\"" . $_arg_1 . "\" type=\"audio/ogg\">" . " <source src=\"" . $_arg_1 . "\" type=\"audio/mpeg\">" . "</audio>";
	}
	return "<iframe src=\"" . $_arg_1 . "\" style=\"background:#000;width:100%;height:" . $_arg_2 . ";\" frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
}
function xmldata($_arg_0)
{
	$_var_1 = file_get_contents($_arg_0);
	$_var_2 = simplexml_load_string($_var_1);
	$_var_3 = count($_var_2->children()) - 1;
	$_var_4 = 0;
	while ($_var_4 <= $_var_3) {
		foreach ($_var_2->video[$_var_4]->files->file as $_var_5) {
			foreach ($_var_5 as $_var_6) {
				if ($_var_5->ftype == "mp4") {
					$_var_7['' . $_var_5 . "->seconds"][url] = $_var_5->furl;
					$_var_7['' . $_var_5 . "->seconds"][date] = strtotime($_var_5->time);
				}
			}
		}
		$_var_4 = $_var_4 + 1;
	}
	$_var_4 = 0;
	while ($_var_4 <= count($_var_7)) {
		$_var_8 = array();
		foreach ($_var_7 as $_var_5 => $_var_6) {
			$_var_8[$_var_5] = $_var_6["date"];
		}
		$_var_4 = $_var_4 + 1;
	}
	return $_var_7[array_search(max($_var_8), $_var_8)][url];
}
function returndata($_arg_0, $_arg_1)
{
	return "<video id=\"video_" . substr(md5($_arg_0), 14, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" x5-playsinline webkit-playsinline playsinline style=\"background:#000;width:100%;height:" . $_arg_1 . ";\"><source src=\"" . $_arg_0 . "\" type=\"video/ogg\" /><source src=\"" . $_arg_0 . "\" type=\"video/mp4\" /></video>";
}
function deal($_arg_0, $_arg_1)
{
	$_var_2 = preg_match_all("/\\[media.*?\\[\\/media\\]/", $_arg_0, $_var_3);
	foreach ($_var_3[0] as $_var_4 => $_var_5) {
		$_var_6 = get_type($_var_5);
		$_var_7 = preg_replace("/\\[media.*?\\](.*)\\[\\/media\\]/", "\$1", $_var_5);
		$_var_8 = get_embed($_var_6, $_var_7, $_arg_1);
		$_arg_0 = str_replace($_var_5, $_var_8, $_arg_0);
	}
	$_var_9 = preg_match_all("/\\[flash.*?\\[\\/flash\\]/", $_arg_0, $_var_3);
	foreach ($_var_3[0] as $_var_4 => $_var_5) {
		$_var_6 = get_type($_var_5);
		$_var_7 = preg_replace("/\\[flash.*?\\](.*)\\[\\/flash\\]/", "\$1", $_var_5);
		$_var_8 = get_embed($_var_6, $_var_7, $_arg_1);
		$_arg_0 = str_replace($_var_5, $_var_8, $_arg_0);
	}
	$_var_10 = preg_match_all("/\\[audio.*?\\[\\/audio\\]/", $_arg_0, $_var_3);
	foreach ($_var_3[0] as $_var_4 => $_var_5) {
		$_var_6 = get_type($_var_5);
		$_var_7 = preg_replace("/\\[audio.*?\\](.*)\\[\\/audio\\]/", "\$1", $_var_5);
		$_var_8 = get_embed($_var_6, $_var_7, "257", "33");
		$_arg_0 = str_replace($_var_5, $_var_8, $_arg_0);
	}
	return $_arg_0;
}
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}