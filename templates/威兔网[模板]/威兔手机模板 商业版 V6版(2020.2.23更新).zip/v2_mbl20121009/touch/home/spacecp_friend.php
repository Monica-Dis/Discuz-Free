<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang friend_request}<!--{/block}--> 
<!--{template common/header}--> 
<!--{if $_G['inajax']}-->
<div class="bw ajaxpop"> 
<!--{if $op =='ignore'}-->
  <div class="r-block">{lang determine_lgnore_friend}</div>
    <form method="post" autocomplete="off" id="friendform_{$uid}" name="friendform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=ignore&uid=$uid&confirm=1" >    
      <input type="hidden" name="referer" value="{echo dreferer()}">
      <input type="hidden" name="friendsubmit" value="true" />
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <input type="hidden" name="from" value="$_GET[from]" />
      <!--{if $_G[inajax]}-->
      <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
      <!--{/if}-->      
      <div class="hm"><button type="submit" name="friendsubmit_btn" class="formsdialog button2" value="true">{lang determine}</button></div>
    </form> 
<!--{elseif $op=='changegroup'}--> 
    <form method="post" autocomplete="off" id="changegroupform_{$uid}" name="changegroupform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=changegroup&uid=$uid" >
      <input type="hidden" name="referer" value="{echo dreferer()}">
      <input type="hidden" name="changegroupsubmit" value="true" />
      <!--{if $_G[inajax]}-->
      <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
      <!--{/if}-->
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <ul class="friend_add bb">
      <!--{loop $groups $key $value}-->
      <li>
      <label for="group_$key">
      <input type="radio" name="gid" id="group_$key" value="$key"$groupselect[$key] />
      $value</label>
      </li>
      <!--{/loop}-->
      </ul> 
      <div class="hm"><button type="submit" name="changegroupsubmit_btn" class="formdialog button2" value="true">{lang determine}</button></div>  
    </form> 
<!--{elseif $op=='editnote'}-->
			<form method="post" autocomplete="off" id="editnoteform_{$uid}" name="editnoteform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=editnote&uid=$uid">
				<input type="hidden" name="referer" value="{echo dreferer()}">
				<input type="hidden" name="editnotesubmit" value="true" />
				<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<ul class="inputall b_pw pbm bb">				
				<li><input type="text" name="note" value="$friend[note]" placeholder="{lang friend_note}" /></li>
                <li class="m_c fz5">{lang friend_note_message}</li>
				</ul>
				<div class="hm"><button type="submit" name="editnotesubmit_btn" class="formdialog button2" value="true">{lang determine}</button></div>				
			</form>       
<!--{elseif $op=='add'}-->
    <form method="post" autocomplete="off" id="addform_{$tospace[uid]}" name="addform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]" >
      <input type="hidden" name="referer" value="{echo dreferer()}" />
      <input type="hidden" name="addsubmit" value="true" />
      <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <div class="inputall b_pw bb">
      <ul>
      <li class="mbn">{lang view_note_message}</li>
      <li class="mbn">{lang add} {$tospace[username]} {lang add_friend_note}:</li>
      <li><input type="text" name="note" value="" /></li>
      <li class="mbn">{lang friend_group}:</li>
      <li class="m_c">
        <div class="selectstyle">
          <select name="gid">
            <!--{loop $groups $key $value}-->
            <option value="$key" {if empty($space['privacy']['groupname']) && $key==1} selected="selected"{/if}>$value</option>
            <!--{/loop}-->
          </select>
        </div>
       </li>
      </ul>
      </div>
      <div class="hm"><button type="submit" name="addsubmit_btn" id="addsubmit_btn" value="true" class="formdialog button2">{lang determine}</button></div>
    </form>
<!--{elseif $op=='add2'}-->   
  <form method="post" autocomplete="off" id="addratifyform_{$tospace[uid]}" name="addratifyform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]" >
    <input type="hidden" name="referer" value="{echo dreferer()}" />
    <input type="hidden" name="add2submit" value="true" />
    <input type="hidden" name="from" value="$_GET[from]" />
    <!--{if $_G[inajax]}-->
    <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
    <!--{/if}-->
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <ul class="friend_add bb">
    <div class="qian pbn">{lang approval_the_request_group}</div>
      <!--{loop $groups $key $value}-->
      <li>
      <label for="group_$key">
      <input type="radio" name="gid" id="group_$key" value="$key"$groupselect[$key] />
      $value</label>
      </li>
      <!--{/loop}-->
    </ul>    
    <div class="hm"><button type="submit" name="add2submit_btn" value="true" class="formdialog button2">{lang approval}</button></div>  
  </form>
<!--{/if}--> 
</div>
<!--{else}--> 

<!--{if $op !='ignore'}-->
<div class="tabequal">
  <ul>
    <li{$a_actives[me]}><a href="home.php?mod=space&do=friend">{lang all_friends}</a></li>
    <!--{if empty($_G['setting']['sessionclose'])}--><li{$a_actives[onlinefriend]}><a href="home.php?mod=space&do=friend&view=online&type=friend">{$langplus[ol_friend]}</a></li><!--{/if}--> 
    <li{$a_actives[blacklist]}><a href="home.php?mod=space&do=friend&view=blacklist">{$langplus[add_blacklist]}</a></li>
    <li class="a"><a href="home.php?mod=spacecp&ac=friend&op=request">{lang friend_request}</a></li>
  </ul>
</div>
<!--{/if}-->

<!--{if $op=='request'}--> 

<!--{if $list}-->
<ul id="alist" class="pagelist friend">
  <!--{loop $list $key $value}-->
  <li>
    <div class="locker" id="locker_$value[fuid]">
    <span class="friendset"><i class="vt-right"></i></span>
    <a href="home.php?mod=space&uid=$value[fuid]&do=profile" class="friendavatar"><!--{avatar($value[fuid],middle)}--></a>
    <h1><a href="home.php?mod=space&uid=$value[fuid]&do=profile">$value[fusername]</a><span class="y fz5 smf"><!--{date($value[dateline], 'm-d H:i')}--></span></h1>
    <p>{lang leave_comments}: <!--{if $value[note]}-->$value[note]<!--{else}-->{lang nothing}<!--{/if}--></p>   
    <div class="friend_mg">    
    <ul>
    <li class="editnote"><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[fuid]&handlekey=afrfriendhk_{$value[uid]}" class="dialog">{lang confirm_applications}</a></li>
    <li class="frienddel"><a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$value[fuid]&confirm=1&handlekey=afifriendhk_{$value[uid]}" class="dialog">{lang ignore}</a></li> 
    </ul>
    </div>
    <div class="lockerclose" id="lockerclose_$value[uid]"></div>
    </div>
  </li> 
  <!--{/loop}-->  
</ul>
<div class="close_m"></div>
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=spacecp&ac=friend&op=request" class="morelink" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->  
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}--> 

<script type="text/javascript">
$(document).ready(function(){
	$(document).on('click','.friendset',function(){		
		var lockerid = $(this).parent('.locker').attr('id'); 
		$('#' + lockerid).addClass('lockeropen').css('z-index','55');		
		$('.close_m').show();
	})
	$(document).on('click','.lockerclose',function(){
		$('.locker').removeClass('lockeropen').css('z-index', '');	
		$('.close_m').hide();		
	})
	$('.close_m').off().on('touchstart',function(){
		$('.locker').removeClass('lockeropen').css('z-index', '');		
		$(this).hide();		
	});	
});
</script>     
<!--{if $_G[uid]}--><!--{$formsdialog_item}--><!--{/if}-->
    
<!--{else}-->
<div class="r-block">{lang no_new_friend_application}</div>
<!--{/if}--> 

<!--{elseif $op=='editnote'}-->
			<form method="post" autocomplete="off" id="editnoteform_{$uid}" name="editnoteform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=editnote&uid=$uid">
				<input type="hidden" name="referer" value="{echo dreferer()}">
				<input type="hidden" name="editnotesubmit" value="true" />
				<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<ul class="inputall bb bw">				
				<li><input type="text" name="note" value="$friend[note]" placeholder="{lang friend_note}" /></li>
                <li class="m_c">{lang friend_note_message}</li>
				</ul>
				<div class="hm"><button type="submit" name="editnotesubmit_btn" class="formdialog button2" value="true">{lang determine}</button></div>				
			</form>
<!--{elseif $op=='add'}--> 
<div class="inputall bw">
  <ul>
    <form method="post" autocomplete="off" id="addform_{$tospace[uid]}" name="addform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]" >
      <input type="hidden" name="referer" value="{echo dreferer()}" />
      <input type="hidden" name="addsubmit" value="true" />
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <li class="mbn">{lang view_note_message}</li>
      <li class="mbn">{lang add} {$tospace[username]} {lang add_friend_note}:</li>
      <li><input type="text" name="note" value="" /></li>
      <li class="mbn">{lang friend_group}:</li>
      <li class="mbm">
        <div class="selectstyle">
          <select name="gid">
            <!--{loop $groups $key $value}-->
            <option value="$key" {if empty($space['privacy']['groupname']) && $key==1} selected="selected"{/if}>$value</option>
            <!--{/loop}-->
          </select>
        </div>
       </li>
      <button type="submit" name="addsubmit_btn" id="addsubmit_btn" value="true" class="formdialog button5">{lang determine}</button>
    </form>
  </ul>
</div>
<!--{elseif $op=='add2'}--> 
<div class="bw">  
  <form method="post" autocomplete="off" id="addratifyform_{$tospace[uid]}" name="addratifyform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=friend&op=add&uid=$tospace[uid]" >
    <input type="hidden" name="referer" value="{echo dreferer()}" />
    <input type="hidden" name="add2submit" value="true" />
    <input type="hidden" name="from" value="$_GET[from]" />
    <!--{if $_G[inajax]}-->
    <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
    <!--{/if}-->
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <ul class="friend_add bb">
    <div class="qian pbn">{lang approval_the_request_group}</div>
      <!--{loop $groups $key $value}-->
      <li>
      <label for="group_$key">
      <input type="radio" name="gid" id="group_$key" value="$key"$groupselect[$key] />
      $value</label>
      </li>
      <!--{/loop}-->      
    </ul>
    <div class="b_p"><button type="submit" name="add2submit_btn" value="true" class="formdialog button5">{lang approval}</button></div>
  </form>
</div>
<!--{elseif $op =='ignore'}-->  
  <div class="bw pbm">
  <div class="r-block">{lang determine_lgnore_friend}</div>
    <form method="post" autocomplete="off" id="friendform_{$uid}" name="friendform_{$uid}" action="home.php?mod=spacecp&ac=friend&op=ignore&uid=$uid&confirm=1" >
      <input type="hidden" name="referer" value="{echo dreferer()}">
      <input type="hidden" name="friendsubmit" value="true" />
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <input type="hidden" name="from" value="$_GET[from]" />
      <!--{if $_G[inajax]}-->
      <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
      <!--{/if}-->      
      <div class="b_p"><button type="submit" name="friendsubmit_btn" class="formdialog button5" value="true">{lang determine}</button></div>   
    </form>
  </div> 
<!--{else}-->
<div class="r-block aj">{lang uploadstatusmsg10}</div>
<!--{/if}--> 
<!--{/if}--> 
<!--{template common/footer}-->