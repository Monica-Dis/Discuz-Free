<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang credit_rating}<!--{/block}-->
<!--{template common/header}-->
<div class="NkGgJbO2CQdl">
	<ul>
		<li{if !$from} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=spacecp&ac=eccredit&op=list&uid=$uid">{$langplus[eccreditlistall]}</a></li>
		<li{if $from == 'buyer' && !$filter} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=spacecp&ac=eccredit&op=list&uid=$uid&from=buyer">{$langplus[eccreditlistbuyer]}</a></li>
		<li{if $from == 'seller' && !$filter} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=spacecp&ac=eccredit&op=list&uid=$uid&from=seller">{$langplus[eccreditlistseller]}</a></li>
		<li{if $from == 'myself'} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=spacecp&ac=eccredit&op=list&uid=$uid&from=myself">{$langplus[eccreditlistother]}</a></li>
	</ul>
</div>
	<!--{if $_G['uid'] && ($_G['uid'] == $uid || getstatus($_G['member']['allowadmincp'], 1))}-->
	<!--{if $comments}-->
	<ul id="alist" class="syMmU1HFwSBu">
		<!--{loop $comments $comment}-->
			<li>
				<span class="BCrxLLI4aemi">
				<!--{if $comment[score] == 1}-->
				<img src="{STATICURL}image/traderank/good.gif" width="14" height="16" alt="good" class="OV2bpjsRvqFH" /> <i style="color:red">{lang eccredit_good}</i>
				<!--{elseif $comment[score] == 0}-->
				<img src="{STATICURL}image/traderank/soso.gif" width="14" height="16" alt="soso" class="OV2bpjsRvqFH" /> <i style="color:green">{lang eccredit_soso}</i>
				<!--{else}-->
				<img src="{STATICURL}image/traderank/bad.gif" width="14" height="16" alt="bad" class="OV2bpjsRvqFH" /> {lang eccredit_bad}
				<!--{/if}-->
				</span>
				<div class="8yizB9ZMDbJE">
					<!--{if $from == 'myself'}-->
					<a href="home.php?mod=space&uid=$comment[rateeid]">$comment[ratee]</a>
					<!--{else}-->
					<a href="home.php?mod=space&uid=$comment[raterid]">$comment[rater]</a>
					<!--{/if}-->
					<!--{if $from == 'myself'}-->
					<!--{if $comment[type]}--> {lang trade_buyer}<!--{else}--> {lang trade_seller}<!--{/if}-->
					<!--{else}-->
					<!--{if $comment[type]}--> {lang trade_seller}<!--{else}--> {lang trade_buyer}<!--{/if}-->
					<!--{/if}-->
					<em class="NF4sirzIB2jD">$comment[dateline]</em>
				</div>
				<p class="5AtRUB4GQ21Z">
					<a href="forum.php?mod=redirect&goto=findpost&pid=$comment[pid]" class="Q8lZLnjHfm2v">$comment[subject]</a>
					<!--{if $comment[price] > 0}-->
					/ <span>$comment[price]</span> {lang trade_units}
					<!--{/if}-->
					<!--{if $_G['setting']['creditstransextra'][5] != -1 && $comment['credit'] > 0}-->
					/ {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]} <span>$comment[credit]</span> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}
					<!--{/if}-->
				</p>
				<!--{if $comment[message]}-->
				<p>$comment[message]</p>
				<!--{/if}-->
				<!--{if $comment[explanation]}-->
				<div class="eccredit_exp_reply{if $comment[message]} mtm{/if}">{lang reply}: $comment[explanation]</div>
				<!--{elseif $_G['uid'] && $_G['uid'] == $comment[rateeid] && $comment[dbdateline] >= TIMESTAMP - 30 * 86400}-->
				<p class="eccredit_exp_btn{if $comment[message]} mtm{/if}"><a href="home.php?mod=spacecp&ac=eccredit&op=explain&id=$comment[id]&ajaxmenuid=ajax_$comment[id]_explain_menu" class="F3pveqiOE331">{lang reply}</a> <span class="ZIxpOtbJtB6a">{$langplus[endtime]} $comment[expiration]</span></p>
				<!--{/if}-->
			</li>
		<!--{/loop}-->
	</ul>
	<!--{if $tplpages == 1}-->
	<!--{eval $totalpage = ceil($num / 10);}-->
	<!--{if $totalpage > $page}-->
	<a href="home.php?mod=spacecp&ac=eccredit&op=list&uid=$uid" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
	<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{else}-->
	<!--{if $multipage}-->$multipage<!--{/if}-->
	<!--{/if}-->
	<!--{else}-->
	<div class="sqK9gG26iUGb">{lang eccredit_nofound}</div>
	<!--{/if}-->
	<!--{else}-->
	<div class="sqK9gG26iUGb">{$langplus[norights]}</div>
	<!--{/if}-->
<!--{template common/footer}-->