<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval
	$_G['home_tpl_titles'] = array('{lang magic}');
}-->
<!--{template common/header}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if}">
<form id="magicform" method="post" action="home.php?mod=magic&action=shop&infloat=yes">
<div class="magicprt">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="operation" value="$operation" />
		<input type="hidden" name="mid" value="$_GET['mid']" />
		<!--{if !empty($_GET['idtype']) && !empty($_GET['id'])}-->
			<input type="hidden" name="idtype" value="$_GET[idtype]" />
			<input type="hidden" name="id" value="$_GET[id]" />
		<!--{/if}-->
		<!--{if $operation == 'buy'}-->
					<div class="mg_img"><img src="$magic[pic]" /><span>$magic[name]</span></div>
						<p class="qian">$magic[description]</p>
						<p>{lang magics_price}: <span{if $magic[discountprice] && $magic[price] != $magic[discountprice]} style="text-decoration:line-through;"{/if}>{$_G['setting']['extcredits'][$magic[credit]][title]} <span id="magicprice">$magic[price]</span> {$_G['setting']['extcredits'][$magic[credit]][unit]}</span></p>
						<!--{if $magic[discountprice] && $magic[price] != $magic[discountprice]}-->
						<p class="orange">{lang magics_discountprice}: {$_G['setting']['extcredits'][$magic[credit]][title]} <span id="discountprice">$magic[discountprice]</span> $_G['setting']['extcredits'][$magic[credit]][unit]</p>
						<!--{/if}-->
						<p class="qian">{lang magics_yourcredit} <!--{echo getuserprofile('extcredits'.$magic[credit])}--> {$_G['setting']['extcredits'][$magic[credit]][unit]}</p>
						<p>{lang magics_weight}: <span id="magicweight">$magic[weight]</span></p>
						<p class="qian">{lang my_magic_volume} $allowweight</p>										
						<p>{lang stock}: <span>$magic[num]</span> {lang magics_unit}</p>
						<!--{if $useperoid !== true}-->
						<p class="orange"><!--{if $magic['useperoid'] == 1}-->{lang magics_outofperoid_1}<!--{elseif $magic['useperoid'] == 2}-->{lang magics_outofperoid_2}<!--{elseif $magic['useperoid'] == 3}-->{lang magics_outofperoid_3}<!--{elseif $magic['useperoid'] == 4}-->{lang magics_outofperoid_4}<!--{/if}--><!--{if $useperoid > 0}-->{lang magics_outofperoid_value}<!--{else}-->{lang magics_outofperoid_noperm}<!--{/if}--></p>
						<!--{/if}-->
						<!--{if !$useperm}--><p class="orange">{lang magics_permission_no}</p><!--{/if}-->
						<p>{lang memcp_usergroups_buy} <input id="magicnum" name="magicnum" type="text" size="2" autocomplete="off" value="1" /> {lang magics_unit}</p>                        
			<input type="hidden" name="operatesubmit" value="yes" />
		<!--{elseif $operation == 'give'}-->
			<table cellspacing="0" cellpadding="0" class="tfm">
				<tr>
					<th>&nbsp;</th>
					<td>{lang magics_operation_present}"$magic[name]"</td>
				</tr>
				<tr>
					<th>{lang magics_target_present}</th>
					<td class="hasd">
						<input type="text" id="selectedusername" name="tousername" size="12" autocomplete="off" value="" />
					</td>
				</tr>
				<tr>
					<th>{lang magics_num}</th>
					<td><input name="magicnum" type="text" size="12" autocomplete="off" value="1" /></td>
				</tr>
				<tr>
					<th>{lang magics_present_message}</th>
					<td><textarea name="givemessage" rows="3" ></textarea></td>
				</tr>
			</table>
			<input type="hidden" name="operatesubmit" value="yes" />
		<!--{/if}-->
</div>
<div class="hm">
	<!--{if $operation == 'buy'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true"><span>{lang magics_operation_buy}</span></button>
	<!--{elseif $operation == 'give'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true"><span>{lang magics_operation_present}</span></button>
	<!--{/if}-->
</div>
</form>
</div>
<!--{template common/footer}-->