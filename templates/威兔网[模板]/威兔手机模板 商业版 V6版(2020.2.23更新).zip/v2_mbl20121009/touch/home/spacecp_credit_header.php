<?php echo 'From: DisM.taobao.com';exit;?>  
  <div class="NkGgJbO2CQdl">
  <ul>
	<li $opactives[base]><a href="home.php?mod=spacecp&ac=credit&op=base">{$langplus[me]}</a></li>
	<!--{if $buylink || ($_G[setting][ec_ratio] && ($_G[setting][ec_account] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_tenpay_bargainor])) || $_G['setting']['card']['open']}-->
	<li $opactives[buy]><a href="{if $buylink}{$buylink}{else}home.php?mod=spacecp&ac=credit&op=buy{/if}">{lang buy_credits}</a></li>
	<!--{/if}-->
	<!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
	<li $opactives[transfer]><a href="home.php?mod=spacecp&ac=credit&op=transfer">{lang transfer_credits}</a></li>
	<!--{/if}-->
	<!--{if $_G[setting][exchangestatus]}-->
	<li $opactives[exchange]><a href="home.php?mod=spacecp&ac=credit&op=exchange">{lang exchange_credits}</a></li>
	<!--{/if}-->
	<li $opactives[log]><a href="home.php?mod=spacecp&ac=credit&op=log">{$langplus[data_log]}</a></li>
	<li $opactives[rule]><a href="home.php?mod=spacecp&ac=credit&op=rule">{$langplus[credit_rule]}</a></li>
</ul>
</div>