<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_GET['do'] == 'uploading'}-->
<!--{eval require_once(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/home/spacecp_avatar_plus.php');}-->
<!--{/if}-->
<!--{block header_name}-->{lang current_my_space}<!--{/block}-->
<!--{template common/header}-->
<link rel="stylesheet" type="text/css" href="template/v2_mbl20121009/touch_plus/css/cropper.min.css">
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/cropper.min.js?{VERHASH}"></script>

<div class="MaOc32iIiNvz"> 
 
	<div class="bDpmvbR8t4wl"{if !$headershow} style="padding-top:84px;"{/if}>
	  <img id="image" src="{avatar($space[uid],big,true)}&a={TIMESTAMP}" /> 
	</div>    
    
    <i class="UE3UyJh8iw0a"></i><i class="dSbOk9ElEBJm"></i><i class="GutFKHDXHyX5"></i><i class="kBamuz1L1nIW"></i><i class="1HOpj40mY5LD"></i><i class="Wxxxo9MGbrtM"></i><i class="g3PIWVGipSHg"></i><i class="HYZSEXofYG3z"></i><i class="74n7SnRKd7As"></i><i class="nraPdmKGGRzH"></i><i class="oR8RbRCeSQxc"></i><i class="LM4evJSFFVNs"></i><i class="NUIO5s0HsPyW"></i><i class="ZUMIjtCDNb5I"></i><i class="ji6PR1w9Gxnn"></i>       
     
	<div id="imgup" class="RHz3epfwEx4A"><input type="file" accept="image/*" onchange="addimg(this)" /></div>        
	<div id="imgup2" class="RHz3epfwEx4A" style="display:none;"><input type="file" accept="image/*" onchange="addimg2(this)" /></div>
    
    <div class="thckNk9YZBJE">
    <a href="home.php?mod=spacecp&ac=avatar" class="IGcm79RL44su"></a>
    <span class="nKCShrc09zpV">{lang save}</span>
    </div>	
    
    <div class="jD0pYvJ0ZOrH">
	  <ul>
	  <li><span class="8dFVzTLwiI7S"></span></li>
      <li><span class="6jePYduEmAbO"></span></li>
      <li><span class="tDa7I1vGugZ2"></span></li>
      <li><span class="PLHqZUTIRDz9"></span></li>
      <li><span class="xd0syvOEwdjk"></span></li> 
      </ul>     
	</div>
    
</div> 

<div class="aBrBG4357L0F" style="display:none;"></div>

<script type="text/javascript">
var uploadmsg = "{lang uploadstatusmsg0}";

function imgcrp() {
    $('#image').cropper({
        aspectRatio: 1 / 1,
        autoCropArea: 0.6,
        viewMode: 1,
        dragMode:'move',       
        background: false,		
        minContainerHeight: window.screen.height,
        minContainerWidth: window.screen.width
    });	
};

function ajaxpost(imgurl) {	
    $(".avataruploading").show();
    $.ajax({
        url: './home.php?mod=spacecp&ac=avatar&do=uploading&hash={FORMHASH}',
        type: "POST",
        data: 'serverurl=' + imgurl,
        datatype: "text",
        success: function(msg) {
            if (msg == uploadmsg) {               
                $("#image").attr("src", imgurl).removeClass("cropper-hidden");
                $(".avataruploading, .cropper-container, .atbtn, .abbtn").delay(300).fadeOut();
            } else {
                popup.open('<div class="57wo6jJ46Z4Q"><dt>'+msg+'</dt></div>');				
                $(".avataruploading").delay(300).fadeOut();	
                return window.location.reload(true);				
            }
        }
    });
};

function addimg(imgfile) {    
	$(".atbtn, .abbtn").delay(300).fadeIn();
    $("#imgup").hide();
    $("#imgup2").show();
    var image = document.getElementById('image');
    image.src = window.URL.createObjectURL(imgfile.files[0]);
    imgcrp();
};

function addimg2(imgfile) {	
    $(".atbtn, .abbtn").delay(300).fadeIn();
    $('#image').cropper('replace', window.URL.createObjectURL(imgfile.files[0]));
};

$(function() {
	
    $(document).on('click','.resetall',function() {
        $('#image').cropper("reset");
    })

    $(document).on('click','.rotateleft',function() {
        $('#image').cropper('rotate', -30);
    })

    $(document).on('click','.rotateright',function() {
        $('#image').cropper('rotate', 30); 
    })

    $(document).on('click','.scalexr',function() {
        $('#image').cropper('scaleX', -1); 
        $(this).attr("class", "scalexl");
    })
	
    $(document).on('click','.scalexl',function() {	
        $('#image').cropper('scaleX', 1); 
        $(this).attr("class", "scalexr");
    })

    $(document).on('click','.scaleyb',function() {
        $('#image').cropper('scaleY', -1); 
        $(this).attr("class", "scaleyt");
    })

    $(document).on('click','.scaleyt',function() {
        $('#image').cropper('scaleY', 1); 
        $(this).attr("class", "scaleyb");
    })

    $(document).on('click','.imgsave',function() {
        var dataURL = $('#image').cropper('getCroppedCanvas', {
            width:200,
            height:200,
            fillColor: '#fff',
            imageSmoothingEnabled: true,
            imageSmoothingQuality: 'high',
        });
        var imgurl = dataURL.toDataURL("image/jpeg", 1);
        ajaxpost(imgurl);
    })

})

</script>
<!--{template common/footer}-->