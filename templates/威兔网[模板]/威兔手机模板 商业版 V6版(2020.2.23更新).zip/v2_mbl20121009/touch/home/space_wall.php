<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $space[uid] != $_G[uid]}-->{$space[username]}{lang eccredit_s}<!--{/if}-->{lang message}<!--{/block}-->
<!--{template common/header}-->                
        <div id="alist" class="XOAdoUldGtH5">         
         <!--{loop $list $k $value}--> 
         <!--{template home/space_comment_li}--> 
         <!--{/loop}-->         
        </div>       
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->   
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->     
    
<!--{if helper_access::check_module('wall')}-->	
    <div class="JFisFvnvOOmR">
		<form name="inputform" id="quickcommentform_{$space[uid]}" action="home.php?mod=spacecp&ac=comment" method="post" autocomplete="off" >
				<input type="hidden" name="referer" value="home.php?mod=space&uid={$space[uid]}&do=wall" />
				<input type="hidden" name="id" value="$space[uid]" />
				<input type="hidden" name="idtype" value="uid" />
				<input type="hidden" name="handlekey" value="qcwall_{$space[uid]}" />
				<input type="hidden" name="commentsubmit" value="true" />
				<input type="hidden" name="quickcomment" value="true" />
            <table cellspacing="0" cellpadding="0">
            <tr>  
				<td><input id="comment_message" name="message" value="" autocomplete="off" class="a2YoXwq2mvgz" placeholder="{lang send_reply_fast_tip}" ></td>
				<th><button type="submit" name="commentsubmit_btn" value="true" id="commentsubmit_btn" disable="true" class="1VzSWhv3Ko9w">{lang leave_comments}</button></th>
            </tr>
            </table>
			<input type="hidden" name="formhash" value="{FORMHASH}" />
		</form>
        <div class="iJrTjMP0vlhS"><a href="javascript:;"{if $_G[uid]} onclick="$(this).toggleClass('on'); $('#smiliesdiv').slideToggle(); $('.close_s').show();"{/if} class="CzMyTphx0KVg"></a></div>
        <!--{template home/space_smilies}-->       
        </div> 
        <div class="qytY6AvMLAlZ"></div>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript" >
<!--{if !$_G[uid]}-->	
$('#comment_message').on('focus', function() {
	popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
	this.blur();			
});
$('#commentsubmit_btn').on('click', function() {
		return false;
});	
<!--{else}-->		
$('#comment_message').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {		
		$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');
	} else {		
		$('#commentsubmit_btn').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
	}
	$('#comment_message').removeClass('nofocus');
	$('.close_s').show();
	});	
$('#commentsubmit_btn').on('click', function() {				
	var btobj = $(this);
	if(btobj.attr('disable') == 'true') {
		return false;
	}
	$('.postsmilie').removeClass('on');
	$('#smiliesdiv').slideUp();
	});	
$('.close_s').off().on('touchstart',function(){	
	var bt2obj = $('#commentsubmit_btn');	
	if(bt2obj.attr('disable') == 'true') {
		$('#comment_message').blur().addClass('nofocus');		
	}
	$(this).hide();
	$('.postsmilie').removeClass('on');
	$('#smiliesdiv').slideUp();	
	});	
function ismi(sl){ 
	$(".replymsg").insertAtCaret(sl); 
}
<!--{/if}-->
</script>
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->
<!--{/if}-->
<!--{block footerplus}--><div class="TyCJXL60MXvY"></div><!--{/block}-->
<!--{eval $nofooter = true;}-->
<!--{/if}-->
<!--{template common/footer}-->