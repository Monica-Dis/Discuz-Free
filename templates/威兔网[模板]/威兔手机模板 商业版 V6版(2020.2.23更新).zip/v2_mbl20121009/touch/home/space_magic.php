<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=magic">{lang magic}</a><!--{/block}-->
<!--{eval $space[uid] = $_G[uid];}-->
<!--{eval $space[username] = $_G['member']['username']; }-->
<!--{template common/header}-->
<!--{if !$_G['setting']['magicstatus'] && $_G['adminid'] == 1}-->
<div class="sqK9gG26iUGb">{lang magics_tips}</div>
<!--{else}-->
		<div class="NkGgJbO2CQdl">
			<ul>
				<!--{if $_G['group']['allowmagics']}--><li$actives[shop]><a href="home.php?mod=magic&action=shop">{lang magics_shop}</a></li><!--{/if}-->
				<li$actives[mybox]><a href="home.php?mod=magic&action=mybox">{lang magics_user}</a></li>
				<li$actives[log]><a href="home.php?mod=magic&action=log&operation=uselog">{lang magics_log}</a></li>
				<!--{hook/magic_nav_extra}-->
			</ul>
		</div>
<div class="VQP9BGi01iNS">

			<!--{if $action == 'shop'}-->
				<!--{subtemplate home/space_magic_shop}-->
			<!--{elseif $action == 'mybox'}-->
				<!--{subtemplate home/space_magic_mybox}-->
			<!--{elseif $action == 'log'}-->
				<!--{subtemplate home/space_magic_log}-->
			<!--{/if}-->
</div>
<!--{/if}-->
<!--{template common/footer}-->