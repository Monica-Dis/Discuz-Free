<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{if !$_G['inajax']}-->
<!--{eval dheader("location: home.php?mod=medal");exit; }-->
<!--{/if}-->
<div class="ajaxpop">
<form id="medalform" method="post" autocomplete="off" action="home.php?mod=medal&action=apply&medalsubmit=yes">	
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="medalid" value="$medal[medalid]" />
		<input type="hidden" name="operation" value="" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
        <div class="medalfloatitem">
        <table cellpadding="0" cellspacing="0" >
        <tr>
        <th>
		<img src="{STATICURL}image/common/$medal[image]" alt="$medal[name]" />
        </th>
        <td>
					<div class="medalfname">$medal[name]</div>
					<p class="qian mtn mbn">$medal[description]</p>
					<p>
						<!--{if $medal[expiration]}-->
							{lang expire} $medal[expiration] {lang days}<br />
						<!--{/if}-->
						<!--{if $medal[permission]}-->
							$medal[permission]<br />
						<!--{/if}-->
						<!--{if $medal[type] == 0}-->
							{lang medals_type_0}
						<!--{elseif $medal[type] == 1}-->
							<!--{if $medal['price']}-->
								<!--{if {$_G['setting']['extcredits'][$medal[credit]][unit]}}-->
									{$_G['setting']['extcredits'][$medal[credit]][title]} <span>$medal[price]</span> {$_G['setting']['extcredits'][$medal[credit]][unit]}
								<!--{else}-->
									<span>$medal[price]</span> {$_G['setting']['extcredits'][$medal[credit]][title]}
								<!--{/if}-->
							<!--{else}-->
								{lang medals_type_1}
							<!--{/if}-->
						<!--{elseif $medal[type] == 2}-->
							{lang medals_type_2}
						<!--{/if}-->
                        </p>
                </td>
                </tr>
                </table>
                </div>     
		<!--{if $medal[type] && $_G['uid']}-->
            <div class="hm tb">
			<button class="formdialog button2" type="submit" value="true" name="medalsubmit"><span>
				<span>
				<!--{if $medal['price']}-->
					{lang space_medal_buy}
				<!--{else}-->
					<!--{if !$medal[permission]}-->
						{lang medals_apply}
					<!--{else}-->
						{lang medals_draw}
					<!--{/if}-->
				<!--{/if}-->
				</span>
			</button>
            </div>
		<!--{/if}-->       
</form>
</div>

<!--{template common/footer}-->