<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=spacecp&ac=usergroup">{lang memcp_usergroup}</a><!--{/block}-->
<!--{template common/header}-->
<!--{if in_array($do, array('buy', 'exit'))}-->
	<div{if $_G['inajax']} class="ajaxpop"{/if}>
	<div class="usergroupbuy">
		<!--{if $join}-->{lang memcp_usergroups_joinbuy}<!--{else}-->{lang memcp_usergroups_joinexit}<!--{/if}-->	
	</div>
	<form id="buygroupform_{$groupid}" name="buygroupform_{$groupid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=usergroup&do=$do&groupid=$groupid">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="buysubmit" value="true" />
		<input type="hidden" name="gid" value="$_GET[gid]" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="usergrouplist">
			<table cellspacing="0" cellpadding="0">
			<!--{if $join}-->
				<!--{if $group['dailyprice']}-->
					<tr>
						<td>{lang memcp_usergroups_dailyprice}</td><td> $group[dailyprice] {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}</td>
					</tr>
					<tr>
						<td>{lang memcp_usergroups_credit}</td><td>$usermaxdays {lang days}</td>
					</tr>
					<tr>
						<td>{lang memcp_usergroups_span}</td><td><input type="text" size="2" name="days" value="$group[minspan]" id="buydays" /> {lang days}</td>
					</tr>
                    <!--{eval $credits_need = $group[dailyprice] * $group[minspan]}-->
					<tr>
						<td>{lang credits_need}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}</td><td><span id="credits_need" class="orange">{$credits_need}</span> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}
			<script type="text/javascript">				
				var dailyprice = $group[dailyprice];
				$(document).on('input value','#buydays',function(){
					var bonus = $(this).val();
					if(!bonus.search(/^\d+$/) || bonus == '') {
						$('#credits_need').html(bonus * dailyprice);
					}
                });
			</script></td>
					</tr>
					<tr>
						<td colspan="2" class="userexplain">
							<!--{if $join}-->
								{lang memcp_usergroups_join_comment}
							<!--{else}-->
								{lang memcp_usergroups_exit_comment}
							<!--{/if}-->
						</td>
					</tr>
				<!--{else}-->
					<tr>
						<td colspan="2" class="userexplain">{lang memcp_usergroups_free_comment}</td>
					</tr>
				<!--{/if}-->
			<!--{else}-->
				<tr>
					<td colspan="2" class="userexplain">
					<!--{if $group[type] != 'special' || $group[system]=='private'}-->
						{lang memcp_usergroups_admin_exit_comment}
					<!--{elseif $group['dailyprice']}-->
						{lang memcp_usergroups_exit_comment}
					<!--{else}-->
						{lang memcp_usergroups_open_exit_comment}
					<!--{/if}-->
					</td>
				</tr>
			<!--{/if}-->
			</table>
		</div>
		<div class="hm btye">
			<button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="formdialog button2">{lang submit}</button>
		</div>
	</form>
	</div>

<!--{elseif $do == 'switch'}-->
	<div{if $_G['inajax']} class="ajaxpop"{/if}>
	<div class="usergroupbuy">
		{lang memcp_usergroups_switch}
	</div>
	<form id="switchgroupform_{$groupid}" name="switchgroupform_{$groupid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=usergroup&do=switch&groupid=$groupid">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="groupsubmit" value="true" />
		<input type="hidden" name="gid" value="$_GET[gid]" />

		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="usergrouplist">
			<table cellspacing="0" cellpadding="0">
				<tr>
					<td>{lang memcp_usergroups_main_old}</td><td>$_G[group][grouptitle]</td>
				</tr>
				<tr>
					<td>{lang memcp_usergroups_main_new}</td><td>$group[grouptitle]</td>
				</tr>
			</table>
		</div>
		<div class="hm btye">
			<button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="formdialog button2">{lang submit}</button>
		</div>
	</form>
	</div>
<!--{elseif $do == 'forum'}-->			
			<!--{subtemplate home/spacecp_usergroup_header}-->
			<table cellpadding="0" cellspacing="0" class="usergroupform">
				<tr class="usergroupalt">
					<th class="fzb">{lang forum_name}</th>
					<!--{loop $perms $perm}-->
						<td class="fzb">$permlang['perms_'.$perm]</td>
					<!--{/loop}-->
				</tr>
			<!--{eval $key = 1;}-->
			<!--{loop $_G['cache']['forums'] $fid $forum}-->
				<!--{if $forum['status']}-->
				<tr{if $key++%2==0} class="usergroupalt"{/if}>
					<th{if $forum['type'] == 'forum' || $forum['type'] == 'sub'} class="forumtype"{/if}><div class="userforumname"><a href="forum.php?mod=forumdisplay&fid=$forum[fid]">$forum[name]</a></div></th>
					<!--{loop $perms $perm}-->
						<td>
							<!--{if !empty($verifyperm[$fid][$perm])}-->
								<!--{if $myverifyperm[$fid][$perm] || $forumperm[$fid][$perm]}-->
									<i class="data_valid"></i>
								<!--{else}-->
									<i class="data_invalid"></i>
								<!--{/if}-->
								&nbsp;$verifyperm[$fid][$perm]
							<!--{else}-->
								<!--{if $forumperm[$fid][$perm]}--><i class="data_valid"></i><!--{else}--><i class="data_invalid"></i><!--{/if}-->
							<!--{/if}-->
						</td>
					<!--{/loop}-->
				</tr>
				<!--{/if}-->
			<!--{/loop}-->
			</table>
			<div class="usergroupexp">
            <i class="data_valid"></i> {lang usergroup_right_message1}&nbsp;&nbsp;&nbsp;
			<i class="data_invalid"></i> {lang usergroup_right_message2}&nbsp;&nbsp;&nbsp;           
			<!--{if $_G['setting']['verify']['enabled']}-->
				<!--{echo implode('', $verifyicon)}--> {lang usergroup_right_message3}
			<!--{/if}-->
            </div>

<!--{elseif $do == 'expiry' || $do == 'list'}-->
			
			<!--{subtemplate home/spacecp_usergroup_header}-->
            <div class="charts">
				<ul>
                <li><p>{lang yourusergroup}</p><span>{$_G['cache']['usergroups'][$_G[groupid]]['grouptitle']}</span></li>
                <li><p>{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}</p><span>$usermoney</span></li>
				</ul>            
            </div>
				<!--{if $do == 'expiry'}-->
					<div class="r-block pts pbs">{lang usergroup_expired}</div>
				<!--{/if}-->
				<!--{if $expirylist}-->
					<table cellspacing="0" cellpadding="0" class="usergroupdt">
						<tbody>
							<tr>
								<th>{lang usergroup}</th>
								<th>{lang memcp_usergroups_dailyprice}</th>
								<th>{$langplus[musergroupsc]}</th>
								<th>{lang group_expiry_time}</th>								
							</tr>
						</tbody>
						<tbody>
							<!--{loop $expirylist $groupid $group}-->
								<tr class="max320">
									<td><a href="home.php?mod=spacecp&ac=usergroup&gid=$groupid"><strong>$group[grouptitle]</strong></a></td>
									<td>
										<!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy' && $group[dailyprice]}-->
											$group[dailyprice] {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}
										<!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'free'}-->
											{lang free}
                                        <!--{else}-->
											---
										<!--{/if}-->
									</td>
									<td><!--{if $group[usermaxdays]}-->$group[usermaxdays] {lang days}<!--{else}-->---<!--{/if}--></td>
									<td><!--{if $group[time]}-->$group[time]<!--{else}-->---<!--{/if}--></td>
								</tr>
                                <tr>
                                <td colspan="4" class="usergroupmod">
                                <!--{if in_array($groupid, $extgroupids) || $groupid == $_G['groupid']}-->
											<!--{if $groupid != $_G['groupid']}-->
												<!--{if !$group[noswitch]}-->
													<a href="home.php?mod=spacecp&ac=usergroup&do=switch&groupid=$groupid&handlekey=switchgrouphk" class="dialog button4">{lang memcp_usergroups_set_main}</a>
												<!--{/if}-->
												<!--{if !$group['maingroup']}-->
													<!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy'}-->
													<a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="dialog button4">{lang renew}</a>
													<!--{/if}-->
													<a href="home.php?mod=spacecp&ac=usergroup&do=exit&groupid=$groupid&handlekey=exitgrouphk" class="dialog button4">{lang memcp_usergroups_exit}</a>
												<!--{/if}-->
											<!--{else}-->
												<!--{if $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy'}-->
													<a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="dialog button5">{lang renew}</a>
												<!--{/if}-->												
											<!--{/if}-->
										<!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'free'}-->
											<a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="dialog button5">{lang free_buy}</a>
										<!--{elseif $_G['cache']['usergroups'][$groupid]['pubtype'] == 'buy'}-->
											<a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$groupid&handlekey=buygrouphk" class="dialog button5">{lang memcp_usergroups_buy}</a>
										<!--{/if}-->
                                        </td>
                                        </tr>
							<!--{/loop}-->
						</tbody>
					</table>
				<!--{else}-->
					<div class="r-block">{lang memcp_usergroup_unallow}</div>
				<!--{/if}-->

<!--{else}-->   		
			<!--{subtemplate home/spacecp_usergroup_header}-->
			<!--{eval
				$permtype = array(0 => '{lang permission_menu_normaloptions}', 1 => '{lang permission_modoptions_name}');
			}-->
			<!--{if $group}--><div style="overflow-y:hidden; overflow-x:auto;"><!--{/if}-->
            <div class="usergroupatt"{if $group} style="width:150%;"{/if}>
				<table cellpadding="0" cellspacing="0" class="{if $group}usergroupdata2{else}usergroupdata{/if}">
					<tr><td>{lang my_main_usergroup}</td></tr>
					<tr><td class="usergroupalt">{lang credits}</td></tr>
					<tbody class="ca">
						<tr><td>{lang user_level}</td></tr>
						<!--{loop $bperms $key $perm}-->
						<tr{if $key%2==0} class="usergroupalt"{/if}>
							<td>$permlang['perms_'.$perm]</td>
						</tr>
						<!--{/loop}-->
					</tbody>

					<tr class="usergroupalt usergroupname">
						<th>{lang permission_menu_post}</th>
					</tr>
					<tbody class="cb">
						<!--{loop $pperms $key $perm}-->
						<tr{if $key%2==0} class="usergroupalt"{/if}>
							<td>$permlang['perms_'.$perm]</td>
						</tr>
						<!--{/loop}-->
					</tbody>

					<tr class="usergroupalt usergroupname">
						<th>{lang about_space}</th>
					</tr>
					<tbody class="cc">
						<!--{loop $sperms $key $perm}-->
						<tr{if $key%2==0} class="usergroupalt"{/if}>
							<td>$permlang['perms_'.$perm]</td>
						</tr>
						<!--{/loop}-->
					</tbody>

					<tr class="usergroupalt usergroupname">
						<th>{lang permission_menu_attachment}</th>
					</tr>
					<tbody class="cd">
						<!--{loop $aperms $key $perm}-->
						<tr{if $key%2==0} class="usergroupalt"{/if}>
							<td>$permlang['perms_'.$perm]</td>
						</tr>
						<!--{/loop}-->
					</tbody>
				</table>
				<table cellpadding="0" cellspacing="0" class="{if $group}usergroupdata2{else}usergroupdata{/if}">
					<tr>
						<td>$maingroup[grouptitle]</td>
					</tr>
					<tr>
						<td class="usergroupalt">$space[credits]</td>
					</tr>
					<!--{echo permtbody($maingroup)}-->
				</table>
				<!--{if $group}-->
					<!--{if $switchtype == 'user'}--><!--{eval $cid = 1;$tlang = '{lang usergroup_group1}';}--><!--{/if}-->
					<!--{if $switchtype == 'upgrade'}--><!--{eval $cid = 2;$tlang = '{lang usergroup_group2}';}--><!--{/if}-->
					<!--{if $switchtype == 'admin'}--><!--{eval $cid = 3;$tlang = '{lang usergroup_group3}';}--><!--{/if}-->				
						<table cellpadding="0" cellspacing="0" class="{if $group}usergroupdata2{else}usergroupdata{/if}">
							<tr>
								<td>
                                $currentgrouptitle
                                <!--{if in_array($group['groupid'], $extgroupids) && $switchmaingroup && $group['grouptype'] == 'special' && $group['groupid'] != $_G['groupid']}-->
                                <!--{if $_G['cache']['usergroups'][$group['groupid']]['pubtype'] == 'buy'}-->
                                ( <a href="home.php?mod=spacecp&ac=usergroup&do=buy&groupid=$group['groupid']&gid=$_GET[gid]&handlekey=buygrouphk" class="dialog">{lang renew}</a> )
                                <!--{/if}-->
                                <!--{/if}-->
								</td>
							</tr>
							<tr>
								<td class="usergroupalt usergroupname">                                    
									<!--{if array_key_exists($group['groupid'], $groupterms['ext'])}-->
										<!--{date($groupterms[ext][$group['groupid']])}-->
									<!--{/if}-->
								</td>
							</tr>
							<!--{echo permtbody($group)}-->
						</table>
				<!--{/if}--> 
			</div>
            <!--{if $group}--></div><!--{/if}-->     
            
            <div class="usergroupexp">
			<i class="data_valid"></i> {lang usergroup_right_message1}&nbsp;&nbsp;&nbsp;
			<i class="data_invalid"></i> {lang usergroup_right_message2}
            </div>

<!--{/if}-->
{eval
function permtbody($maingroup) {
global $_G, $bperms, $pperms, $sperms, $aperms;
}
<tr><td><!--{echo showstars($_G['cache']['usergroups'][$maingroup['groupid']]['stars']);}--></td></tr>
<tbody class="ca">
	<!--{loop $bperms $key $groupbperm}-->
	<tr{if $key%2==0} class="usergroupalt"{/if}>
		<td>
			<!--{if $groupbperm == 'creditshigher' || $groupbperm == 'readaccess' || $groupbperm == 'maxpmnum'}-->
			$maingroup[$groupbperm]
			<!--{elseif $groupbperm == 'allowsearch'}-->
				<!--{if $maingroup['allowsearch'] == '0'}-->{lang permission_basic_disable_sarch}<!--{elseif $maingroup['allowsearch'] == '1'}-->{lang permission_basic_search_title}<!--{else}-->{lang permission_basic_search_content}<!--{/if}-->
			<!--{else}-->
				<!--{if $maingroup[$groupbperm] >= 1}--><i class="data_valid"></i><!--{else}--><i class="data_invalid"></i><!--{/if}-->
			<!--{/if}-->
		</td>
	</tr>
	<!--{/loop}-->
</tbody>

<tr class="usergroupalt usergroupname">
	<th>$maingroup[grouptitle]</th>
</tr>
<tbody class="cb">
	<!--{loop $pperms $key $grouppperm}-->
	<tr{if $key%2==0} class="usergroupalt"{/if}>
		<td>
			<!--{if in_array($grouppperm, array('maxsigsize', 'maxbiosize'))}-->
				$maingroup[$grouppperm] {lang bytes}
			<!--{elseif $grouppperm == 'allowrecommend'}-->
				<!--{if $maingroup[allowrecommend] > 0}-->+$maingroup[allowrecommend]<!--{else}--><i class="data_invalid"></i><!--{/if}-->
			<!--{elseif in_array($grouppperm, array('allowat', 'allowcreatecollection'))}-->
				<!--{echo intval($maingroup[$grouppperm])}-->
			<!--{else}-->
				<!--{if $maingroup[$grouppperm] == 1 || (in_array($grouppperm, array('raterange', 'allowcommentpost')) && !empty($maingroup[$grouppperm]))}--><i class="data_valid"></i><!--{else}--><i class="data_invalid"></i><!--{/if}-->
			<!--{/if}-->
		</td>
	</tr>
	<!--{/loop}-->
</tbody>

<tr class="usergroupalt usergroupname">
	<th>$maingroup[grouptitle]</th>
</tr>
<tbody class="cc">
	<!--{loop $sperms $key $perm}-->
	<tr{if $key%2==0} class="usergroupalt"{/if}>
		<td>
			<!--{if in_array($perm, array('maxspacesize', 'maximagesize'))}-->
				<!--{if $maingroup[$perm]}-->$maingroup[$perm]<!--{else}-->{lang permission_attachment_nopermission}<!--{/if}-->
			<!--{else}-->
				<!--{if $maingroup[$perm] == 1}--><i class="data_valid"></i><!--{else}--><i class="data_invalid"></i><!--{/if}-->
			<!--{/if}-->
		</td>
	</tr>
	<!--{/loop}-->
</tbody>

<tr class="usergroupalt usergroupname">
	<th>$maingroup[grouptitle]</th>
</tr>
<tbody class="cd">
	<!--{loop $aperms $key $groupaperm}-->
	<tr{if $key%2==0} class="usergroupalt"{/if}>
		<td>
			<!--{if in_array($groupaperm, array('maxattachsize', 'maxsizeperday', 'maxattachnum'))}-->
				<!--{if $maingroup[$groupaperm]}-->$maingroup[$groupaperm]<!--{else}-->{lang permission_attachment_nopermission}<!--{/if}-->
			<!--{elseif $groupaperm == 'attachextensions'}-->
				<!--{if $maingroup[allowpostattach] == 1}--><!--{if $maingroup[attachextensions]}--><p class="nwp" title="$maingroup[attachextensions]">$maingroup[attachextensions]</p><!--{else}-->{lang permission_attachment_nopermission}<!--{/if}--><!--{else}--><i class="data_invalid"></i><!--{/if}-->
			<!--{else}-->
				<!--{if $maingroup[$groupaperm] == 1}--><i class="data_valid"></i><!--{else}--><i class="data_invalid"></i><!--{/if}-->
			<!--{/if}-->
		</td>
	</tr>
	<!--{/loop}-->
</tbody>
<!--{eval
}
}-->
<!--{template common/footer}-->