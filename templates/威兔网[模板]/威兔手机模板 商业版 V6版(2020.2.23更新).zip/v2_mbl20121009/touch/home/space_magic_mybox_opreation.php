<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if}">
<form id="magicform" method="post" action="home.php?mod=magic&action=mybox&infloat=yes">
<div class="magicprt">
	<div id="hkey_$_GET[handlekey]">
		<div id="return_$_GET[handlekey]"></div>
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="handlekey" value="$_GET[handlekey]" />
			<input type="hidden" name="operation" value="$operation" />
			<input type="hidden" name="magicid" value="$magicid" />
			<!--{if $operation == 'give'}-->
				<table cellspacing="0" cellpadding="0" class="tfm">
					<tr>
						<th>&nbsp;</th>
						<td>{lang magics_operation_present}"$magic[name]"</td>
					</tr>
					<!--{if $_G['group']['allowmagics'] > 1 }-->
					<tr>
						<th>{lang magics_target_present}</th>
						<td class="hasd">
							<input type="text" id="selectedusername" name="tousername" size="12" autocomplete="off" value="" />
						</td>
					</tr>
					<!--{/if}-->
					<tr>
						<th>{lang magics_num}</th>
						<td><input name="magicnum" type="text" size="12" autocomplete="off" value="1" /></td>
					</tr>
					<tr>
						<th>{lang magics_present_message}</th>
						<td><textarea name="givemessage" rows="3" ></textarea></td>
					</tr>
				</table>
				<input type="hidden" name="operatesubmit" value="yes" />
			<!--{elseif $operation == 'use'}-->
				<!--{if $magiclist}-->
				<div class="selectstyle mbw" style="display:none;">
					<select name="magicid" onchange="showWindow('magics', 'home.php?mod=magic&action=mybox&operation=use&&infloat=yes&type=$typeid&pid=$pid&typeid=$typeid&magicid='+this.options[this.selectedIndex].value)" class="chosemagic">
						<option value="0">{lang magics_select}</option>
						<!--{loop $magiclist $magics}-->
							<option value="$magics[magicid]" $magicselect[$magics[magicid]]>$magics[name] - $magics[description]</option>
						<!--{/loop}-->
					</select>
				</div>
				<!--{/if}-->               
					<div class="mg_img mbm"><img src="$magic[pic]" alt="$magic[name]"><span>$magic[name]</span></div>						
							<!--{if method_exists($magicclass, 'show')}-->
								<!--{eval $magicclass->show();}-->
							<!--{/if}-->
							<!--{if $useperoid !== true}-->
								<p><!--{if $magic['useperoid'] == 1}-->{lang magics_outofperoid_1}<!--{elseif $magic['useperoid'] == 2}-->{lang magics_outofperoid_2}<!--{elseif $magic['useperoid'] == 3}-->{lang magics_outofperoid_3}<!--{elseif $magic['useperoid'] == 4}-->{lang magics_outofperoid_4}<!--{/if}--><!--{if $useperoid > 0}-->{lang magics_outofperoid_value}<!--{else}-->{lang magics_outofperoid_noperm}<!--{/if}--></p>
							<!--{/if}-->						
				<input type="hidden" name="usesubmit" value="yes" />
				<input type="hidden" name="operation" value="use" />
				<input type="hidden" name="magicid" value="$magicid" />
				<!--{if !empty($_GET['idtype']) && !empty($_GET['id'])}-->
					<input type="hidden" name="idtype" value="$_GET[idtype]" />
					<input type="hidden" name="id" value="$_GET[id]" />
				<!--{/if}-->
			<!--{elseif $operation == 'sell'}-->
					<div class="mg_img mbw"><img src="$magic[pic]" alt="$magic[name]"><span>$magic[name]</span></div>					
						<p>{lang magics_operation_sell} <input name="magicnum" type="text" size="2" value="1" /> {lang magics_unit}"$magic[name]"</p>
						<p>
							{lang recycling_prices}:
							<!--{if {$_G['setting']['extcredits'][$magic[credit]][unit]}}-->
								{$_G['setting']['extcredits'][$magic[credit]][title]} $discountprice {$_G['setting']['extcredits'][$magic[credit]][unit]}/{lang magics_unit}
							<!--{else}-->
								$discountprice {$_G['setting']['extcredits'][$magic[credit]][title]}/{lang magics_unit}
							<!--{/if}-->
						</p>
				<input type="hidden" name="operatesubmit" value="yes" />
			<!--{elseif $operation == 'drop'}-->				
					<div class="mg_img mbw"><img src="$magic[pic]" alt="$magic[name]"></div>					
						<p>{lang magics_operation_drop} <input name="magicnum" type="text" size="2" autocomplete="off" value="1" /> {lang magics_unit}"$magic[name]"</p>
						<p>{lang magics_weight}: $magic[weight]</p>
				<input type="hidden" name="operatesubmit" value="yes" />
			<!--{/if}-->
			</div>
</div>

<div class="hm" id="hbtn_$_GET[handlekey]">
	<!--{if $operation == 'give'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true"><span>{lang magics_operation_present}</span></button>
	<!--{elseif $operation == 'use'}-->
		<button class="button2 formdialog" type="submit" name="usesubmit" id="usesubmit" value="true"><span>{lang magics_operation_use}</span></button>
	<!--{elseif $operation == 'sell'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true"><span>{lang magics_operation_sell}</span></button>
	<!--{elseif $operation == 'drop'}-->
		<button class="button2 formdialog" type="submit" name="operatesubmit" id="operatesubmit" value="true"><span>{lang magics_operation_drop}</span></button>
	<!--{/if}-->
</div>

</form>
</div>

<!--{template common/footer}-->