<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $carray = array();}-->
<!--{eval $beforeuser = 0;}-->
<!--{eval $hiddennum = 0;}-->
<ul id="alist" class="2wo5edK94lwv">
<!--{loop $list['feed'] $feed}-->
	<!--{eval $content = $list['content'][$feed['tid']];}-->
	<!--{eval $thread = $list['threads'][$content['tid']];}-->
	<!--{if !empty($thread) && $thread['displayorder'] >= 0 || !empty($feed['note'])}-->
	<li class="follow_item more_datas{if ($_GET['do'] != 'view' && !isset($_GET[banavatar])) && $beforeuser != $feed['uid']} segt{/if}"> 
        <!--{if $_GET['do'] != 'view' && !isset($_GET[banavatar])}-->		
			<!--{if $beforeuser != $feed['uid']}-->
			<!--{eval $beforeuser = $feed['uid'];}-->
			<a href="home.php?mod=space&uid=$feed[uid]&do=profile" class="UoRZiAghxSa8"><img src="<!--{avatar($feed[uid],middle,true)}-->" /></a>			
			<!--{/if}-->		
		<!--{else}-->
			<!--{eval $beforeuser = $feed['uid'];}-->
			<a href="home.php?mod=space&uid=$feed[uid]&do=profile" class="UoRZiAghxSa8"><img src="<!--{avatar($feed[uid],middle,true)}-->" /></a>
        <!--{/if}-->        
			<div class="9FX0Jnweef3O">
			<!--{if $feed[uid] == $_G[uid] || $_G['adminid'] == 1}-->
			<a href="home.php?mod=spacecp&ac=follow&feedid=$feed[feedid]&op=delete" class="aePgER3tkXjd"><i class="aPyV086aHjq3"></i></a>
			<!--{/if}-->
			<p class="akCuITTXFlOM">
			<a href="home.php?mod=space&uid=$feed[uid]&do=profile" >$feed['username']</a><span><!--{eval echo dgmdate($feed['dateline'], 'u');}--></span>
			</p>
			<!--{if $feed['note']}--><div class="vOGCx5RHRkYA">$feed['note']</div><div class="jZv05EyLnmR0"><!--{/if}-->            
			<!--{if !empty($thread) && $thread['displayorder'] >= 0}-->
			<!--{if $thread[fid] != $_G[setting][followforumid]}-->
            <div class="mgNDHt4Osa86"><a href="forum.php?mod=viewthread&tid=$content['tid']&extra=page%3D1" >$thread['subject']</a></div>
			<!--{/if}-->
			<div class="dKq9HjkR2GOQ">
            $content['content']
			<!--{if $thread['special'] && $thread[fid] != $_G[setting][followforumid]}-->
			<br/>
			<a href="forum.php?mod=viewthread&tid=$content['tid']&extra=page%3D1" class="ZiX90GXcL2C0">{$langplus[morereading]}</a>
			<!--{/if}-->
            </div>            
			<!--{if $feed['note'] || ($thread[fid] != $_G[setting][followforumid] && $_G['cache']['forums'][$thread['fid']]['name'])}-->
            <div class="lM4ahIdHbnXL">            
				<!--{if $feed['note']}--><a href="home.php?mod=space&uid=$feed[uid]" class="Q8lZLnjHfm2v">$thread['author']</a> {lang follow_post_by_time} <!--{date($thread['dateline'])}-->&nbsp;<!--{/if}-->                                
				<!--{if $thread[fid] != $_G[setting][followforumid] && $_G['cache']['forums'][$thread['fid']]['name']}-->#<a href="forum.php?mod=forumdisplay&fid=$thread['fid']" class="Q8lZLnjHfm2v">$_G['cache']['forums'][$thread['fid']]['name']</a><!--{/if}-->                
			</div>
            <!--{/if}-->            
			<!--{else}-->            
			<div class="vq9djFekMGJV" >{lang follow_thread_deleted}</div>            
			<!--{/if}-->
            <!--{if $feed['note']}--></div><!--{/if}-->
            </div>
    </li>
	<!--{else}-->
		<!--{eval $hiddennum++;}-->
	<!--{/if}-->
	<!--{if !isset($carray[$feed['cid']])}-->
		<!--{eval $carray[$feed['cid']] = $feed['cid'];}-->
	<!--{/if}-->
<!--{/loop}-->
</ul>  