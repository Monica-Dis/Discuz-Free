<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang myfavorite}<!--{/block}-->
<!--{if $_GET['type'] == 'forum'}--><!--{eval $navtitle = {lang favorite_forum}{lang favorite};}--><!--{/if}-->
<!--{template common/header}-->
		<div class="NkGgJbO2CQdl">
			<ul>
				<li$actives[all]><a href="home.php?mod=space&do=favorite&type=all">{$langplus[all]}</a></li>
				<li$actives[thread]><a href="home.php?mod=space&do=favorite&type=thread">{lang favorite_thread}</a></li>
				<li$actives[forum]><a href="home.php?mod=space&do=favorite&type=forum">{lang favorite_forum}</a></li>				
				<!--{if helper_access::check_module('group')}--><li$actives[group]><a href="home.php?mod=space&do=favorite&type=group">{lang favorite_group}</a></li><!--{/if}-->
                <!--{if helper_access::check_module('blog')}--><li$actives[blog]><a href="home.php?mod=space&do=favorite&type=blog">{lang favorite_blog}</a></li><!--{/if}-->
				<!--{if helper_access::check_module('album')}--><li$actives[album]><a href="home.php?mod=space&do=favorite&type=album">{lang favorite_album}</a></li><!--{/if}-->
				<!--{if helper_access::check_module('portal')}--><li$actives[article]><a href="home.php?mod=space&do=favorite&type=article">{lang favorite_article}</a></li><!--{/if}-->
			</ul>
		</div>
        <!--{hook/space_favorite_v2_mobile}-->

<!-- main collectlist start -->
		<!--{if $list}--> 
        <ul id="alist" class="qFQg90FQHQW7">			
            <!--{loop $list $k $value}-->
			<li><a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k&type={$_GET[type]}" class="aePgER3tkXjd"><i class="aPyV086aHjq3"></i></a><p>$value[icon]<a href="$value[url]">$value[title]</a></p></li>
			<!--{/loop}-->            
        </ul>
		<!--{else}-->
		<div class="sqK9gG26iUGb">{lang no_favorite_yet}</div>
		<!--{/if}-->
<!-- main collectlist end -->

    <!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->

<!--{template common/footer}-->
