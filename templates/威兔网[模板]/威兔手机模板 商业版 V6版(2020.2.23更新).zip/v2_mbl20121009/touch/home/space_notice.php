<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=space&do=notice">{lang remind}</a><!--{/block}--> 
<!--{subtemplate common/header}-->

<div class="NkGgJbO2CQdl">
	<ul>
        <!--{loop $_G['notice_structure'] $key $type}-->               
		<li $opactives[$key]><a href="home.php?mod=space&do=notice&view=$key"{if $_G['member']['category_num'][$key]} class="Iug1I7rXnrOf"{/if}><!--{eval echo lang('template', 'notice_'.$key)}--></a></li>		
        <!--{/loop}-->
	</ul>
</div>
		<!--{if $view=='userapp'}-->
        <!--{eval dheader("location: home.php?mod=space&do=notice");exit; }-->
		<!--{else}-->               
                <!--{if $view == 'interactive'}-->
                <div class="rthtgygSziGe">
                <ul>                
				<!--{if $_G['notice_structure'][$view] && ($view == 'mypost' || $view == 'interactive')}-->
					<!--{loop $_G['notice_structure'][$view] $subtype}-->                    
					<li$readtag[$subtype]><a href="home.php?mod=space&do=notice&view=$view&type=$subtype"{if $_G['member']['newprompt_num'][$subtype]} class="Iug1I7rXnrOf"{/if}><!--{eval echo lang('template', 'notice_'.$view.'_'.$subtype)}--></a></li>
                    <!--{/loop}-->
                    <!--{else}-->
					<li class="E1x17Q9hYTmk"><a href="home.php?mod=space&do=notice&view=$view"><span><!--{eval echo lang('template', 'notice_'.$view)}--></span></a></li>
				<!--{/if}-->
			    </ul>
                </div>              
                <!--{elseif $view == 'mypost'}-->
                <div class="rthtgygSziGe">
                <ul>                 
				<!--{if $_G['notice_structure'][$view] && ($view == 'mypost' || $view == 'interactive')}-->
					<!--{loop $_G['notice_structure'][$view] $subtype}-->
						<li$readtag[$subtype]><a href="home.php?mod=space&do=notice&view=$view&type=$subtype"{if $_G['member']['newprompt_num'][$subtype]} class="Iug1I7rXnrOf"{/if}><!--{eval echo lang('template', 'notice_'.$view.'_'.$subtype)}--></a></li>
					<!--{/loop}-->
				<!--{else}-->
					<li class="E1x17Q9hYTmk"><a href="home.php?mod=space&do=notice&view=$view"><span><!--{eval echo lang('template', 'notice_'.$view)}--></span></a></li>
				<!--{/if}-->
			    </ul>
                </div>                
                <!--{/if}--> 
                <!--{hook/space_notice_top_v2_mobile}-->     
        
			<!--{if empty($list)}-->
			<div class="sqK9gG26iUGb">
				<!--{if $new == 1}-->
					{lang no_new_notice} <a href="home.php?mod=space&do=notice&isread=1">{lang view_old_notice}</a>
				<!--{else}-->
					{lang no_notice}
				<!--{/if}-->
			</div>
			<!--{/if}-->            
            
            <!--{if $list}--> 
            
            <ul id="alist" class="IBKZ4KBPI1gX">            
            <!--{loop $list $key $value}-->
            <li class="11U6e0azhSle">
            <!--{if $value[authorid]}-->
            <a href="home.php?mod=space&uid=$value[authorid]&do=profile" class="UoRZiAghxSa8"><img src="<!--{avatar($value[authorid],middle,true)}-->" /></a>
            <!--{else}-->
            <img class="UoRZiAghxSa8" src="{IMGDIR}/systempm.png" alt="systempm" />
            <!--{/if}-->
            <p class="FWze18TR3iu2">
            <!--{date($value[dateline], 'u')}-->
            <a href="home.php?mod=spacecp&ac=common&op=ignore&authorid=$value[authorid]&type=$value[type]&handlekey=addfriendhk_{$value[authorid]}" class="CmbtAFT1SmhK" ><i class="a1eQefH4PIjA"></i></a>
            </p>
            <div class="KiXNJ4zIpcGc">$value[note]</div>             
            <!--{if $value[from_num]}--><p class="Q8lZLnjHfm2v">{lang ignore_same_notice_message}</p><!--{/if}-->                  
            </li>
			<!--{/loop}-->
			</ul>                                

	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=space&do=$do&isread=1" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->   
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->
    
	<!--{/if}--> 
    
		<!--{/if}-->

<!--{subtemplate common/footer}-->