<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block leftbutton}--><a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="vt-left fz0 rback"></a><!--{/block}-->
<!--{block header_name}-->{lang memcp_privacy}<!--{/block}-->
<!--{template common/header}-->
		<div class="tabequal">
            <ul>
				<li$opactives[base]><a href="home.php?mod=spacecp&ac=privacy&op=base">{lang personal_privacy_settings}</a></li>
				<!--{if helper_access::check_module('feed')}-->
				<li$opactives[feed]><a href="home.php?mod=spacecp&ac=privacy&op=feed">{$langplus[feedsettings]}</a></li>
				<li$opactives[filter]><a href="home.php?mod=spacecp&ac=privacy&op=filter">{lang feed_filter}</a></li>
				<!--{/if}-->
			</ul>
        </div>
			<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=privacy&op=$operation">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			<!--{if $operation == 'base'}-->				
				<div class="inputall passwordlabel bw">
                <div class="warningmessage">{lang you_control_see_content}</div>
					<ul>						
						<li>
							<span class="labelname">{lang friend_list}</span>
                            <div class="selectstyle">
                            <select name="privacy[view][friend]">
								<option value="0"$sels[view][friend][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][friend][1]>{lang friend_privacy}</option>
								<option value="2"$sels[view][friend][2]>{lang secrecy}</option>
								<option value="3"$sels[view][friend][3]>{lang privacy_register}</option>
							</select>
                            </div>
						</li>
					<!--{if helper_access::check_module('wall')}-->						
						<li>
							<span class="labelname">{lang message_board}</span>
                            <div class="selectstyle">
                            <select name="privacy[view][wall]">
								<option value="0"$sels[view][wall][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][wall][1]>{lang friend_privacy}</option>
								<option value="2"$sels[view][wall][2]>{lang secrecy}</option>
								<option value="3"$sels[view][wall][3]>{lang privacy_register}</option>
							</select>
                            </div>
						</li>
					<!--{/if}-->
					<!--{if helper_access::check_module('feed')}-->						
						<li>
							<span class="labelname">{lang personal_feed}</span>
                            <div class="selectstyle">
                            <select name="privacy[view][home]">
								<option value="0"$sels[view][home][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][home][1]>{lang friend_privacy}</option>
								<option value="3"$sels[view][home][3]>{lang privacy_register}</option>
							</select>
                            </div>
						</li>
					<!--{/if}-->
					<!--{if helper_access::check_module('doing')}-->						
						<li class="mbn">
							<span class="labelname">{lang doing}</span>
                            <div class="selectstyle">
                            <select name="privacy[view][doing]">
								<option value="0"$sels[view][doing][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][doing][1]>{lang friend_privacy}</option>
								<option value="3"$sels[view][doing][3]>{lang privacy_register}</option>
							</select>
                            </div>							
						</li>
                        <li class="smf">{lang privacy_setting_message}<br />{lang site_might_your_log}</li>
					<!--{/if}-->
					<!--{if helper_access::check_module('blog')}-->						
						<li class="mbn">
							<span class="labelname">{lang blog}</span>
                            <div class="selectstyle">
                            <select name="privacy[view][blog]">
								<option value="0"$sels[view][blog][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][blog][1]>{lang friend_privacy}</option>
								<option value="3"$sels[view][blog][3]>{lang privacy_register}</option>
							</select>
							</div>
						</li>
                        <li class="smf">{lang privacy_setting_message}<br />{lang view_right_setting_effective}</li>
					<!--{/if}-->
					<!--{if helper_access::check_module('album')}-->
						<li class="mbn">
							<span class="labelname">{lang album}</span>
                            <div class="selectstyle">
                            <select name="privacy[view][album]">
								<option value="0"$sels[view][album][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][album][1]>{lang friend_privacy}</option>
								<option value="3"$sels[view][album][3]>{lang privacy_register}</option>
							</select>
                            </div>							
						</li>
                        <li class="smf">{lang privacy_setting_message}<br />{lang view_right_setting_effective}</li>
					<!--{/if}-->
					<!--{if helper_access::check_module('share')}-->
						<li class="mbn">
							<span class="labelname">{lang share}</span>
                            <div class="selectstyle">
							<select name="privacy[view][share]">
								<option value="0"$sels[view][share][0]>{lang open_privacy}</option>
								<option value="1"$sels[view][share][1]>{lang friend_privacy}</option>
								<option value="3"$sels[view][share][3]>{lang privacy_register}</option>
							</select>							
                            </div>							
						</li>
                        <li class="smf">{lang privacy_setting_message}<br />{lang view_right_setting_effective}</li>
					<!--{/if}-->
					<!--{if $_G['setting'][videophoto] && $space[videophotostatus]}-->
						<li class="smf mbn"><img src="{IMGDIR}/videophoto.gif" alt="" class="vm" /> {lang certified_video_setting_right}</li>						
						<li>
							<span class="labelname">{$langplus[certifiedphoto]}</span>
                            <div class="selectstyle">
                            <select name="privacy[view][videoviewphoto]">
								<option value="0"$sels[view][videoviewphoto][0]>{lang site_default_setting}</option>
								<option value="1"$sels[view][videoviewphoto][1]>{lang allow}</option>
								<option value="2"$sels[view][videoviewphoto][2]>{lang ban}</option>
							</select>
                            </div>
						</li>
					<!--{/if}-->						
					</ul>
                    </div>
                    <div class="trade_order_btn"><button type="submit" name="privacysubmit" value="true" class="button5" />{lang save}</button></div>

			<!--{elseif $operation == 'feed'}-->

				<div class="privacy_feed">
                <div class="warningmessage">{lang system_depend_action_message}</div>
					<ul>
						<li><label><input type="checkbox" name="privacy[feed][doing]" value="1"$sels[feed][doing] /><em>{lang doing}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][blog]" value="1"$sels[feed][blog] /><em>{lang write_blog}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][upload]" value="1"$sels[feed][upload] /><em>{lang upload_pic}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][share]" value="1"$sels[feed][share] /><em>{lang add_share}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][friend]" value="1"$sels[feed][friend] /><em>{lang friend_add}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][comment]" value="1"$sels[feed][comment] /><em>{lang publish_comment_reply}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][show]" value="1"$sels[feed][show] /><em>{lang bidding_rank}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][credit]" value="1"$sels[feed][credit] /><em>{lang credit_consumption}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][invite]" value="1"$sels[feed][invite] /><em>{lang invite_friend}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][task]" value="1"$sels[feed][task] /><em>{lang complete_task}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][profile]" value="1"$sels[feed][profile] /><em>{lang update_presonal_profile}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][click]" value="1"$sels[feed][click] /><em>{lang pic_blog_position}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][newthread]" value="1"$sels[feed][newthread] /><em>{lang forum_post}</em></label></li>
						<li><label><input type="checkbox" name="privacy[feed][newreply]" value="1"$sels[feed][newreply] /><em>{lang forum_reply}</em></label></li>						
					</ul>
                    <div class="trade_order_btn"><button type="submit" name="privacysubmit" value="true" class="button5" />{lang save}</button></div>
                </div>

			<!--{else}-->

				{eval 
					$iconnames['wall'] = '{lang message}';
					$iconnames['piccomment'] = '{lang pic_comment}';
					$iconnames['blogcomment'] = '{lang blog_comment}';
					$iconnames['sharecomment'] = '{lang share_comment}';
					$iconnames['magic'] = '{lang magics_title}';
					$iconnames['sharenotice'] = '{lang share_notification}';
					$iconnames['clickblog'] = '{lang blog_position}';
					$iconnames['clickpic'] = '{lang pic_position}';
					$iconnames['credit'] = '{lang credits}';
					$iconnames['doing'] = '{lang doing}';
					$iconnames['pcomment'] = '{lang topic_comment}';
					$iconnames['post'] = '{lang topic_reply}';
					$iconnames['show'] = '{lang friend_top}';
					$iconnames['task'] = '{lang task}';
					$iconnames['goods'] = '{lang trade}';
					$iconnames['group'] = $_G[setting][navs][3][navname];
					$iconnames['thread'] = '{lang theme}';
					$iconnames['system'] = '{lang system}';
					$iconnames['friend'] = '{lang friends}';
					$iconnames['debate'] = '{lang debate}';
					$iconnames['album'] = '{lang album}';
					$iconnames['blog'] = '{lang blog}';
					$iconnames['poll'] = '{lang poll}';
					$iconnames['activity'] = '{lang activity}';
					$iconnames['reward'] = '{lang reward}';
					$iconnames['share'] = '{lang share}';
					$iconnames['profile'] = '{lang update_presonal_profile}';
					$iconnames['pusearticle'] = '{lang article_push}';
				}

				<div class="privacy_feed">
					<h1>{lang filtering_rules_title_1}</h1>
                    <div class="warningmessage">{lang filtering_rules_message_1}</div>
                    <div class="warningmessage">{lang list_change_friend_name}</div>
					<ul>
							<!--{loop $groups $key $value}-->
							<li><label><input type="checkbox" name="privacy[filter_gid][$key]" value="$key"{if isset($space['privacy']['filter_gid'][$key])} checked="checked"{/if} /><em>$value</em></label></li>
							<!--{/loop}-->
					</ul>
					<div class="p_c ptm mbm"><button type="submit" name="privacy2submit" value="true" class="button5" />{lang save}</button></div>
				</div>

				<div class="privacy_feed">
					<h1>{lang filtering_rules_title_2}</h1>
					<div class="warningmessage">{lang filtering_rules_message_2}</div>
					<!--{if $icons}-->
					<ul>
							<!--{loop $icons $key $icon}-->
							<!--{eval $uid = $uids[$key];$icon_uid="$icon|$uid";}-->
							<li><label>
								<input type="checkbox" name="privacy[filter_icon][$icon_uid]" value="1" checked="checked" /> 
								<em><!--{if isset($iconnames[$icon])}-->$iconnames[$icon]<!--{else}-->$icon<!--{/if}--> &nbsp;<!--{if $users[$uid]}--><a href="home.php?mod=space&uid=$uid" class="orange">$users[$uid]</a><!--{else}--><span class="orange">{lang all_friends}</span><!--{/if}--></em>
							</label></li>
							<!--{/loop}-->
					</ul>
					<div class="p_c ptm mbm"><button type="submit" name="privacy2submit" value="true" class="button5" />{lang save}</button></div>
					<!--{else}-->
					<div class="btye r-block">{lang no_shield_feed_cat}</div>
					<!--{/if}-->
                </div>

				<div class="privacy_feed">
					<h1>{lang filtering_rules_title_3}</h1>
					<div class="warningmessage">{lang filtering_rules_message_3}</div>
					<!--{if $types}-->
					<ul>
							<!--{loop $types $key $type}-->
							<!--{eval $uid = $uids[$key];$type_uid="$type|$uid";}-->
							<li><label>
								<input type="checkbox" name="privacy[filter_note][$type_uid]" value="1" checked="checked" />
								<em><!--{if isset($iconnames[$type])}-->$iconnames[$type]<!--{else}-->$type<!--{/if}--> &nbsp;<!--{if $users[$uid]}--><a href="home.php?mod=space&uid=$uid" class="orange">$users[$uid]</a><!--{else}--><span class="orange">{lang all_friends}</span><!--{/if}--></em>
							</label></li>
							<!--{/loop}-->
					</ul>
                    <div class="p_c ptm mbm"><button type="submit" name="privacy2submit" value="true" class="button5" />{lang save}</button></div>					
					<!--{else}-->
					<div class="btye r-block">{lang no_shield_feed_cat}</div>
					<!--{/if}-->
				</div>
			<!--{/if}-->
			</form>
            
<script type="text/javascript">
		$(document).on('click', '.button5', function() {
			popup.open('<div class="cloading"></div>');			
		});
</script>

<!--{block footerplus}--><div class="ftbox"></div><!--{/block}-->
<!--{eval $nofooter = true;}-->

<!--{template common/footer}-->