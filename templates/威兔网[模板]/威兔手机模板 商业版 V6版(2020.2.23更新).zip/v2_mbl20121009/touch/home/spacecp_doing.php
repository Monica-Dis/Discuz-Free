<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $_GET['op'] == 'delete'}-->
{lang delete_log}<!--{elseif $_GET['op'] == 'docomment' || $_GET['op'] == 'getcomment'}-->{lang reply}{lang doing}<!--{/if}--><!--{/block}--> 
<!--{if $_GET['op'] == 'delete'}--><!--{eval $navtitle = {lang delete_log};}--><!--{elseif $_GET['op'] == 'docomment' || $_GET['op'] == 'getcomment'}--><!--{eval $navtitle = {lang reply}{lang doing};}--><!--{/if}--> 
<!--{template common/header}--> 
<!--{if $_GET['op'] == 'delete'}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if}">
  <form method="post" autocomplete="off" id="doingform_{$doid}_{$id}" name="doingform" action="home.php?mod=spacecp&ac=doing&op=delete&doid=$doid&id=$id">
    <!--{if $_G[inajax]}-->
    <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
    <!--{/if}-->
    <input type="hidden" name="referer" value="{echo dreferer()}" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <div class="r-block">{lang determine_delete_doing}</div>
    <div class="hm"><button name="deletesubmit" type="submit" class="button2" value="true">{lang determine}</button></div>
  </form>
</div>
<!--{elseif $_GET['op'] == 'docomment' || $_GET['op'] == 'getcomment'}-->

  <!--{if helper_access::check_module('doing')}--> 
	<div class="bw ajaxpop">        
    <form name="inputform" id="{$_GET[key]}_docommform_{$doid}_{$id}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=doing&op=comment&doid=$doid&id=$id" >
      <div class="reply_comment">
      <textarea name="message" id="{$_GET[key]}_form_{$doid}_{$id}_t" rows="4" class="inserts" ></textarea>
      </div>
      <input type="hidden" name="commentsubmit" value="true" /> 
      <!--{if $_G[inajax]}-->
      <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
      <!--{/if}--> 
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <!--{template home/space_smilies}-->    
      <div class="hm btye"><button type="submit" name="do_button" id="{$_GET[key]}_replybtn_{$doid}_{$id}" class="formdialog button2" value="true">{lang reply}</button></div>
    </form>
  </div>
  
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript" >
function ismi(sl) { 	
	$(".inserts").insertAtCaret(sl);
}
</script>

<!--{/if}--> 


<!--{/if}--> 
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->