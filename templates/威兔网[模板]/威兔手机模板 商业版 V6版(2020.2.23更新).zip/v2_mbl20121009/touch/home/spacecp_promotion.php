<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=spacecp&ac=promotion">{lang memcp_promotion}</a><!--{/block}-->
<!--{template common/header}-->
	<div class="WqH1pTfMOGDs">		
			<!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}-->
				<div class="dDXwcqYbv9DU">
					<!--{if $_G['setting']['creditspolicy']['promotion_visit']}--><p>
						{lang post_promotion_url}
					</p><!--{/if}-->
					<!--{if $_G['setting']['creditspolicy']['promotion_register']}-->
					<p>
					<!--{if $_G['setting']['creditspolicy']['promotion_visit']}-->
						{lang post_promotion_reg}
					<!--{else}-->
						{lang post_promotion}
					<!--{/if}-->
					</p>
					<!--{/if}-->
				</div>						
                        <div class="PuP1D0aASwH8"><i></i></div>
                        <div class="3aEBkzuhDMse">
                        <p>{lang copy}{lang post_promotion_url1}</p>
						<input type="text" onclick="this.select();" value="$_G[siteurl]?fromuid=$_G[uid]" />                       
                        <p class="LVn6pdMIdahQ">{lang copy}{lang post_promotion_url2}</p>						
                        <input type="text" onclick="this.select();" value="$_G[siteurl]?fromuser={echo rawurlencode($_G[username])}" />
                        </div>
			<!--{/if}-->			
</div>
<!--{template common/footer}-->