<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=space&do=album&view=all">{lang album}</a><!--{/block}--> 
<!--{template common/header}-->
<div class="NkGgJbO2CQdl">
  <ul>
    <!--{if $_G['uid'] == $space['uid']}-->
    <li$actives[me]><a href="home.php?mod=space&do=album&view=me">{lang my_album}</a></li>
    <!--{else}-->
    <li$actives[me]><a href="javascript:;">{$space[username]}{lang eccredit_s}{lang album}</a></li>
    <!--{/if}-->
    <li$actives[we]><a href="home.php?mod=space&do=album&view=we">{lang friend_album}</a></li>
    <li$actives[all]><a href="home.php?mod=space&do=album&view=all">{lang view_all}</a></li>
  </ul>
</div>
<!--{hook/space_album_list_v2_mobile}-->
<!--{if $picmode}-->  
  <!--{if $count}-->      
    <ul id="alist" class="nNAqCthlpyId">      
      <!--{loop $list $key $value}-->
      <li>
      <div class="ghp7Duf7hZ4L">
      <a href="home.php?mod=space&uid=$value[uid]&do=album&picid=$value[picid]">
      <div class="YoKvEEpT00Z4">
      <!--{if $value[pic]}-->
      <!--{if $albumpictype == 1}-->
      <!--{eval $valuepic = pic_get($value['filepath'], 'album', '0', $value['remote']); }-->
      <img src="$valuepic" />
      <!--{else}-->
      <img src="$value[pic]" />
      <!--{/if}-->
      <!--{/if}-->
      </div>
      <div class="PFiyz1kpiQKG"><p><!--{if $value[title]}-->$value[title]<!--{else}--><span class="Q8lZLnjHfm2v">{echo dgmdate($value[dateline], 'Y-n-j')}</span><!--{/if}--></p><i class="vt-hot{if $value[hot]} orange{/if}"></i></div>
      </a>      
      <div class="tZ4Td6PWqoec"><img src="<!--{avatar($value[uid],middle,true)}-->" /><a href="home.php?mod=space&uid=$value[uid]&do=profile"><!--{if $value[uid]==$_G[uid]}-->{echo cutstr($value[username],10)}<!--{else}-->$value[username]<!--{/if}--></a><!--{if $value[uid]==$_G[uid]}--><a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$value[albumid]&picid=$value[picid]" class="3Ofn0i29QvwV"><em class="Fy9SOlYsObmq"></em></a><!--{/if}--></div>
      </div>
      </li>      
      <!--{/loop}-->      
    </ul>    
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
	<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->      
    <!--{if $multi}-->$multi<!--{/if}--> 
    <!--{/if}-->  
  <!--{else}-->   
  <!--{if !$pricount}--><div class="sqK9gG26iUGb">{lang no_album}</div><!--{/if}-->   
  <!--{/if}-->
<!--{else}-->
<!--{if $count}-->
  <ul id="alist" class="lq90XNZwqu7V">
    <!--{loop $list $key $value}--> 
    <!--{eval $pwdkey = 'view_pwd_album_'.$value['albumid'];}-->   
    <li>
    <div class="ghp7Duf7hZ4L">
    <a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" class="YoKvEEpT00Z4">   
    <!--{if $value[pic]}-->    
    <!--{if $value['friend'] != 4 && ckfriend($value['uid'], $value['friend'], $value['target_ids'])}-->    
    <img src="$value[pic]" />
    <!--{elseif $value['picnum']}-->
    <img src="template/v2_mbl20121009/touch_plus/image/defaultphoto.png" />
    <!--{/if}-->
    <!--{/if}-->
    <h1><!--{if $value[albumname]}-->$value[albumname]<!--{else}-->{lang default_album}<!--{/if}--></h1>    
    <!--{if $value[picnum]}--><i>{$value[picnum]}P</i><!--{/if}-->    
    </a>
    <div class="tZ4Td6PWqoec"><img src="<!--{avatar($value[uid],middle,true)}-->" /><a href="home.php?mod=space&uid=$value[uid]&do=profile"><!--{if $value[uid]==$_G[uid]}-->{echo cutstr($value[username],10)}<!--{else}-->$value[username]<!--{/if}--></a><!--{if $value[uid]==$_G[uid]}--><a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$value[albumid]" class="3Ofn0i29QvwV"><em class="Fy9SOlYsObmq"></em></a><!--{/if}--></div>   
    </div>
    </li>
    <!--{/loop}-->
    <!--{if $space[self] && $_GET['view']=='me' && $page == 1}-->     
    <li>
    <div class="ghp7Duf7hZ4L">
    <a href="home.php?mod=space&uid=$value[uid]&do=album&id=-1" class="YoKvEEpT00Z4">
    <img src="template/v2_mbl20121009/touch_plus/image/defaultphoto.png" /> 
    <h1>{lang default_album}</h1>   
    </a>
    <div class="tZ4Td6PWqoec"><img src="<!--{avatar($value[uid],middle,true)}-->" /><a href="home.php?mod=space&uid=$value[uid]&do=profile"><!--{if $value[uid]==$_G[uid]}-->{echo cutstr($value[username],10)}<!--{else}-->$value[username]<!--{/if}--></a><!--{if $value[uid]==$_G[uid]}--><a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=0" class="3Ofn0i29QvwV"><em class="Fy9SOlYsObmq"></em></a><!--{/if}--></div>
    </div>
    <!--{if $value[uid]==$_G[uid]}--><a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=0" class="FRi08TWtHcEp">{lang edit}</a><!--{/if}-->
    </li>    
    <!--{/if}-->
  </ul>
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->   
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->
<!--{else}-->
<div class="sqK9gG26iUGb">{lang no_album}</div>
<!--{/if}-->
<!--{/if}-->

<!--{if ($_GET['view'] == 'we') && $userlist}-->
    <div class="T8WzIMPFAEdj">
    <div class="gZlcaCGmGZ0q"><span class="MzXGZuYzqGml"></span>{lang filter_by_friend}</div>
    <div class="wfsjgdO0NVeW">
    <ul>
    <li><a href="home.php?mod=space&do=album&view=we"{if !$_GET[fuid]} class="E1x17Q9hYTmk"{/if}>{lang all}</a></li>
    <!--{loop $userlist $value}-->
    <li><a href="home.php?mod=space&do=album&view=we&fuid={$value[fuid]}"{if $_GET[fuid] == $value[fuid]} class="E1x17Q9hYTmk"{/if}>$value[fusername]</a></li>
    <!--{/loop}-->
    </ul>
    </div>
    </div>
<!--{/if}-->

<!--{if $_GET[view] == 'all'}-->
    <div class="T8WzIMPFAEdj">
    <div class="gZlcaCGmGZ0q"><span class="MzXGZuYzqGml"></span>{lang album}{$langplus[threadtypes]}</div>    
    <div class="wfsjgdO0NVeW">
    <ul>
    <li><a href="home.php?mod=space&do=album&view=all" {if !$_GET[catid]}$orderactives[dateline]{/if}>{$langplus[photo_newup]}{lang album}</a></li>
    <li><a href="home.php?mod=space&do=album&view=all&order=hot" $orderactives[hot]>{$langplus[photo_hot]}{$langplus[recommend]}</a></li>
    <!--{if $_G['setting']['albumcategorystat'] && $category}-->
    <!--{loop $category $value}-->						
    <li><a href="home.php?mod=space&do=album&catid={$value[catid]}&view=all"{if $_GET[catid]==$value[catid]} class="E1x17Q9hYTmk"{/if}>$value[catname]</a></li>
    <!--{/loop}-->
    <!--{/if}-->
    </ul>
    </div>
    </div>
<!--{/if}-->
    
<!--{if $_GET[view] == 'all' || (($_GET['view'] == 'we') && $userlist)}-->    
    <script type="text/javascript">	
    $(document).ready(function(){	
        $('.scroll_sort').click(function(){
            $('.menufly').addClass('infly'); 
            $('body').addClass('menufly_open');                		
        }); 	
        $('.vt-close').click(function(){	
            $('.menufly').removeClass('infly');
            $('body').removeClass('menufly_open');                		
        });		 
    });	
    </script>
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="javascript:;" class="fO6hxU2pKqw0"></a></div>
<!--{/block}-->
<!--{else}-->
<!--{if $_G['uid'] == $space['uid']}-->
<!--{block footerthree}-->
<li><div class="lkzxUSeCuNPo"><a href="home.php?mod=spacecp&ac=upload" class="i0a6HFurbhHA"><i class="WKeZSMVfZ14F"></i></a></div></li>
<!--{/block}-->
<!--{/if}-->
<!--{/if}-->
<!--{template common/footer}-->