<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang share}<!--{/block}-->
<!--{template common/header}-->
<div class="sqK9gG26iUGb">
$langplus[no_function]<br />
<a href="home.php?mod=space&do=share&mobile=no" class="r9COG0I1EFgN">[ {lang nomobiletype} ]</a>
</div>
<!--{template common/footer}-->