<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['group']['magicsdiscount'] || $_G['group']['maxmagicsweight']}-->
	<!--{if $_G['group']['maxmagicsweight']}-->
		<div class="s8GlkiuRcvv9">{lang magics_capacity}: {$totalweight} / {$_G['group']['maxmagicsweight']}</div>
	<!--{/if}-->
<!--{/if}-->
<!--{if $mymagiclist}-->
	<ul id="alist" class="bNgbKpfxkwOS">    
	<!--{loop $mymagiclist $key $mymagic}-->
		<li>
			<div class="DJ0u80zsSrkH" id="magic_$mymagic[identifier]">
            <div class="kQeZeG0uIvAr">
            <div class="oFiPKpx5f1dW"><img src="$mymagic[pic]" alt="$mymagic[name]" /></div>
			<div class="3htUHNX3nuJB">$mymagic[name]</div>
			<p class="fJoRhBf6orOE">{lang magics_num}: $mymagic[num], {lang magics_user_totalnum}: $mymagic[weight]</p>
            </div>
			<div class="1QQ5ld3aBsBt">
            <p>
				<!--{if $mymagic['useevent']}-->
					<a href="home.php?mod=magic&action=mybox&operation=use&magicid=$mymagic[magicid]" class="I8gmFyoSxBHY">{lang magics_operation_use}</a>
				<!--{/if}-->
				<!--{if $_G['group']['allowmagics'] > 1}-->
					<a href="home.php?mod=magic&action=mybox&operation=give&magicid=$mymagic[magicid]" class="F3pveqiOE331">{lang magics_operation_present}</a>
				<!--{/if}-->
				<!--{if $_G['setting']['magicdiscount']}-->
					<a href="home.php?mod=magic&action=mybox&operation=sell&magicid=$mymagic[magicid]" class="F3pveqiOE331">{lang magics_operation_sell}</a>
				<!--{else}-->
					<a href="home.php?mod=magic&action=mybox&operation=drop&magicid=$mymagic[magicid]" class="F3pveqiOE331">{lang magics_operation_drop}</a>
				<!--{/if}-->
			</p>
            </div>
            <div class="ZzDvCy6O9iT1"><p>$mymagic[description]</p></div>
            </div>
		</li>
	<!--{/loop}-->    
	</ul>
    <div class="Es3s87mAHtE5"></div>
<script type="text/javascript">
$(document).ready(function(){
	$(document).on('click','.mg_data',function(){		
		var dataid = $(this).parent('.mg_car').attr('id'); 		
		$('#' + dataid + ' > .description').fadeIn();
		$('.close_m').show();
	})
	$('.close_m').off().on('touchstart',function(){		
		$('.description').fadeOut();	
		$(this).hide();
	});	
});
</script> 
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($magiccount / $_G['tpp']);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=magic&action=mybox&pid=$pid$typeadd" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}--> 
<!--{else}-->
	<div class="sqK9gG26iUGb">{lang data_nonexistence}</div>
<!--{/if}-->
