<?php echo 'From: DisM.taobao.com';exit;?>
<div class="NkGgJbO2CQdl">
  <ul>
	<li $activeus[usergroup]><a href="home.php?mod=spacecp&ac=usergroup">{lang my_usergroups}</a></li>
	<li $activeus[list] $activeus[expiry]><a href="home.php?mod=spacecp&ac=usergroup&do=list">{lang usergroups_joinbuy}</a></li>
	<li $activeus[forum]><a href="home.php?mod=spacecp&ac=usergroup&do=forum">{lang my}{$_G['setting']['navs'][2]['navname']}{lang rights}</a></li>
</ul>
</div>