<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang friend_list}<!--{/block}-->
<!--{template common/header}-->
		<div class="NkGgJbO2CQdl">
			<ul>
				<li{$a_actives[me]}><a href="home.php?mod=space&do=friend">{lang all_friends}</a></li>
                <!--{if empty($_G['setting']['sessionclose'])}--><li{$a_actives[onlinefriend]}><a href="home.php?mod=space&do=friend&view=online&type=friend">{$langplus[ol_friend]}</a></li><!--{/if}-->
				<li{$a_actives[blacklist]}><a href="home.php?mod=space&do=friend&view=blacklist">{$langplus[add_blacklist]}</a></li>
                <li><a href="home.php?mod=spacecp&ac=friend&op=request">{lang friend_request}</a></li>
			</ul>
		</div>
		<!--{if $space[self] && $_GET['view'] == 'blacklist'}-->           
		<div class="JFisFvnvOOmR">    
		<form method="post" autocomplete="off" name="blackform" action="home.php?mod=spacecp&ac=friend&op=blacklist&start=$_GET[start]">
			<table cellpadding="0" cellspacing="0" >
				<tr>
				<td><input type="text" name="username" id="usernames" class="a2YoXwq2mvgz" placeholder="{lang username}" /></td>
				<th><button type="submit" name="blacklistsubmit_btn" id="moodsubmit_btn" value="true" class="1VzSWhv3Ko9w" disable="true">{$langplus[add_black]}</button></th>
				</tr>
			</table>
			<input type="hidden" name="blacklistsubmit" value="true" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
		</form>
        </div>        
		<!--{block footerplus}--><div class="TyCJXL60MXvY"></div><!--{/block}-->        
		<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }-->
		<!--{block scrollplus}-->
		<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
		<!--{/block}-->
		<!--{/if}-->        
		<!--{eval $nofooter = true;}-->
		<!--{/if}-->
			<!--{if $list}-->      
			<ul id="alist" class="pagelist friend{if $_GET['view'] != 'blacklist'}{if helper_access::check_module('follow')} fctmore{else} fctmore_m{/if}{/if}">            
			<!--{eval $t = 1;}-->
            <!--{loop $list $key $value}-->
			<li>                        
            <div class="dZ8IOlQN3qsv" id="locker_$value[uid]{if $value[username] == ''}{$page}{$t}99999{/if}">
            <span class="glUaRWZE0PuJ"><i class="l9iUBObiUnzT"></i></span>            
			<!--{if $value[username] == ''}-->
			<a href="javascript:;" class="En13SLg8vfTK"><img src="template/v2_mbl20121009/touch_plus/image/hidden.png" /></a>
			<h1><a href="javascript:;" >{lang anonymity}</a></h1>
            <p>{lang anonymity}</p>            
			<!--{else}-->
			<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="En13SLg8vfTK"><!--{avatar($value[uid],middle)}--></a> 
            <!--{if $ols[$value[uid]]}--><i class="N7D5Tkx42nC2"></i><!--{/if}-->
            <h1><a href="home.php?mod=space&uid=$value[uid]&do=profile">$value[username]</a></h1>
            <p>
			<!--{if $value[note]}-->
			<span class="PijfGiLxri7h">$value[note]</span>
            <!--{else}-->
            <!--{if !in_array($_GET['view'], array('visitor', 'trace', 'online'))}-->
            $value[recentnote]
            <!--{/if}-->
			<!--{/if}-->
            <!--{if $_GET['view'] == 'online'}-->
			{$langplus[oltime]}: <!--{date($ols[$value[uid]], 'H:i')}-->
            <!--{/if}-->                                    
            </p>            									
			<!--{/if}-->
            <div class="FQgd2kpZkKVq">	
            <ul>										
            <!--{if helper_access::check_module('follow')}-->
            <!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != ''}-->
			<li class="{if $value['follow']}reop{else}addfollow{/if}"><a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&fuid=$value[uid]&hash={FORMHASH}&from=a_followmod_" class="F3pveqiOE331"><!--{if $value['follow']}-->{$langplus[nofollows_m]}<!--{else}-->{$langplus[follows]}<!--{/if}--></a></li>
			<!--{/if}-->
            <!--{/if}-->
			<!--{if !$value[isfriend] && $value[username] != ''}-->	
            <li class="L5dROBMEHlia"><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=adduserhk_{$value[uid]}" class="F3pveqiOE331">{$langplus[add_friend]}</a></li>		
            <li class="drO6KhZw54H1"><a href="home.php?mod=spacecp&ac=friend&op=blacklist&subop=delete&uid=$value[uid]&start=$_GET[start]" class="F3pveqiOE331">{$langplus[delete_black]}</a></li>            
			<!--{elseif !in_array($_GET['view'], array('blacklist', 'visitor', 'trace'))}-->            
			<li><a href="home.php?mod=spacecp&ac=pm&touid={$value[uid]}" class="F3pveqiOE331">{lang pm_center}</a></li>
            <li class="J4BmWeFAUr4i"><a href="home.php?mod=spacecp&ac=poke&op=send&uid=$value[uid]" class="F3pveqiOE331">{$langplus[say_hi]}</a></li>
            <li class="IaHQNi6rZvJx"><a href="home.php?mod=spacecp&ac=friend&op=editnote&uid=$value[uid]&handlekey=editnote_{$value[uid]}" class="F3pveqiOE331">{lang friend_editnote}</a></li>
			<li class="OrQxik93gJNu"><a href="home.php?mod=spacecp&ac=friend&op=changegroup&uid=$value[uid]&handlekey=editgrouphk_{$value[uid]}" class="F3pveqiOE331">{lang friend_group}</a></li>
			<li class="drO6KhZw54H1"><a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$value[uid]&handlekey=delfriendhk_{$value[uid]}" class="F3pveqiOE331">{lang delete}</a></li>
			<!--{/if}-->
            </ul>
			</div>
            <div class="zgSirvDkTeGo" id="lockerclose_$value[uid]"></div>
            </div>            
            </li>
            <!--{eval $t++;}-->            
			<!--{/loop}-->            
			</ul>
            <div class="Es3s87mAHtE5"></div>

	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->  
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->
    
<script type="text/javascript">
$(document).ready(function(){
	$(document).on('click','.friendset',function(){		
		var lockerid = $(this).parent('.locker').attr('id'); 
		$('#' + lockerid).addClass('lockeropen').css('z-index','55');		
		$('.close_m').show();
	})
	$(document).on('click','.lockerclose',function(){
		$('.locker').removeClass('lockeropen').css('z-index', '');	
		$('.close_m').hide();
	})
	$('.close_m').off().on('touchstart',function(){
		$('.locker').removeClass('lockeropen').css('z-index', '');		
		$(this).hide();
	});	
});
</script>           
<!--{if $_G[uid]}--><!--{$formsdialog_item}--><!--{/if}-->

<!--{else}-->            
<div class="sqK9gG26iUGb">{lang no_friend_list}</div>				
<!--{/if}-->

<!--{if $space[self] && $_GET['view'] == 'blacklist'}-->
<script type="text/javascript">
$('#usernames').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {
		$('#moodsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');		
	} else {
		$('#moodsubmit_btn').removeClass('btnon').addClass('nopost').attr('disable', 'true');		
	}	
	$('#usernames').removeClass('nofocus');
	});		
$('#usernames').blur(function(){
	var bt2obj = $('#moodsubmit_btn');	
	if(bt2obj.attr('disable') == 'true') {
		$('#usernames').addClass('nofocus');
	}	
	});			
$('#moodsubmit_btn').on('click', function() {				
	var btobj = $(this);
	if(btobj.attr('disable') == 'true') {
		return false;
	}
	});	
</script> 
<!--{/if}-->

<!--{template common/footer}-->