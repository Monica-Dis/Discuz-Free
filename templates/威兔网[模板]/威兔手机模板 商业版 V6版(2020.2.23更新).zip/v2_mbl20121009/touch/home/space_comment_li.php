<?php echo 'From: DisM.taobao.com';exit;?>
    <div class="97NCEgpOD2NN">    
    <!--{if $value[author]}-->
    <a href="home.php?mod=space&uid=$value[authorid]&do=profile" class="UoRZiAghxSa8"><img src="<!--{avatar($value[authorid],middle, true)}-->" /></a>
    <!--{else}-->
    <img class="UoRZiAghxSa8" src="{STATICURL}image/magic/hidden.gif" />
    <!--{/if}-->
    <div class="lMiESRoMfTgX">
    <!--{if $value[author]}-->
	<a href="home.php?mod=space&uid=$value[authorid]&do=profile">{$value[author]}</a>
	<!--{else}-->
	<a href="javascript:;">$_G[setting][anonymoustext]</a>
	<!--{/if}-->
    <em class="Cl3R4A76eWd0"><!--{date($value[dateline], 'u')}--></em> 
    </div>
	<div class="GoiR9H9DsEdV">
    <!--{if $value[status] == 0 || $value[authorid] == $_G[uid] || $_G[adminid] == 1}-->$value[message]<!--{else}--> {lang moderate_not_validate} <!--{/if}-->
    </div>
    	<!--{if $_G[uid]}-->
        <div class="vUZToXk9EwIO">
		<!--{if $value[authorid]==$_G[uid]}-->
		<a href="home.php?mod=spacecp&ac=comment&op=edit&cid=$value[cid]&handlekey=editcommenthk_{$value[cid]}" ><i class="HcGNy22c8avk"></i></a>
		<!--{/if}-->
		<!--{if $value[authorid]!=$_G[uid] && ($value['idtype'] != 'uid' || $space[self]) && $value[author]}-->
			<a href="home.php?mod=spacecp&ac=comment&op=reply&cid=$value[cid]&feedid=$feedid&handlekey=replycommenthk_{$value[cid]}" class="F3pveqiOE331" ><i class="qwZjl2muVz4e"></i></a>
		<!--{/if}--> 
		<!--{if $value[authorid]==$_G[uid] || $value[uid]==$_G[uid] || checkperm('managecomment')}-->
		<a href="home.php?mod=spacecp&ac=comment&op=delete&cid=$value[cid]&handlekey=delcommenthk_{$value[cid]}" class="F3pveqiOE331"><i class="aPyV086aHjq3"></i></a>
		<!--{/if}-->
        </div>
		<!--{/if}--> 
    </div>