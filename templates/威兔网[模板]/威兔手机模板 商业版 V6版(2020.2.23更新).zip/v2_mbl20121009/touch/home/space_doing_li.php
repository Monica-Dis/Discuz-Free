<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $list}-->
<div class="6p3u1Rjju12E">
<!--{loop $list $value}-->
	<!--{if $value[uid]}-->
	<div class="doing_rc{if $value['class']} {$value['class']}{/if}">
    <!--{if $_G[uid] && helper_access::check_module('doing')}-->
    <a href="home.php?mod=spacecp&ac=doing&op=getcomment&handlekey=msg_$doid&doid=$doid&id={$value[id]}&key=$key" class="pQTOcjqdFUrL"><i class="qwZjl2muVz4e"></i></a>
    <!--{/if}-->
    <!--{if $value[uid]==$_G[uid] || $dv['uid']==$_G[uid] || checkperm('managedoing')}-->
    <a href="home.php?mod=spacecp&ac=doing&op=delete&doid=$value[doid]&id=$value[id]&handlekey=doinghk_{$value[doid]}_$value[id]" class="94DZLUDdZasR"><i class="aPyV086aHjq3"></i></a>
    <!--{/if}-->
	<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="r9COG0I1EFgN">$value[username]</a>: $value[message]<span><!--{date($value['dateline'], 'n-j H:i')}--></span>
	</div>
	<!--{/if}-->   
<!--{/loop}-->
</div>
<!--{/if}-->
