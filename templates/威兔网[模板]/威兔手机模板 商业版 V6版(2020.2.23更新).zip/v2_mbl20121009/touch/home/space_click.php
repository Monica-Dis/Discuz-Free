<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $clicks}-->
<div id="click_div" class="click_box">
<table cellpadding="0" cellspacing="0" class="click_list" >
	<tr>
	<!--{eval $clicknum = 0;}-->
	<!--{loop $clicks $key $value}-->
	<!--{eval $clicknum = $clicknum + $value['clicknum'];}-->
	<!--{eval $value['height'] = $maxclicknum?intval($value['clicknum']*36/$maxclicknum):0;}-->
		<td>        
        <!--{if $value[clicknum]}-->
        <div class="click_option"><div class="ac{$value[classid]}" style="height:{$value[height]}px;"></div></div>
		<!--{/if}-->
        <a href="home.php?mod=spacecp&ac=click&op=add&clickid=$key&idtype=$idtype&id=$id&hash=$hash&handlekey=clickhandle" class="ajaxclick">
		<img src="{STATICURL}image/click/$value[icon]" />
        <!--{if $value[name]}--><p>$value[name]</p><!--{/if}-->
        </a>
		</td>
	<!--{/loop}-->
	</tr>
</table>
</div>

<script type="text/javascript">
	$(document).on('click','.ajaxclick',function(){
		<!--{if !$_G[uid]}-->
		popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
		<!--{else}-->
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=ajaxsubmit&inajax=1',
			data:{'formhash':'{FORMHASH}'},
			dataType:'xml',
		})		
		.success(function(s) {	
			var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();	
			var oksmg = '{$langplus[clicksuccess]}';
			if(smg.indexOf(oksmg) >= 0){			
			$("#click_div").load(location.href + " .click_list");
			}else{
				popup.open('<div class="tip"><dt>'+smg+'</dt></div>');
				setTimeout(function(){
					$(".dialogbox, #mask").fadeOut();					
					}, 1500);	
			}
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		<!--{/if}-->
		return false;
	});	
</script>

<!--{/if}-->