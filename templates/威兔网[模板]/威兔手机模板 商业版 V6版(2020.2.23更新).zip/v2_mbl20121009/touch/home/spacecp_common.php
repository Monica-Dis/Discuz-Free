<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang shield_notice}<!--{/block}-->
<!--{eval $navtitle = {lang shield_notice};}-->
<!--{subtemplate common/header}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if}">
	<form method="post" autocomplete="off" id="ignoreform_{$formid}" name="ignoreform_{$formid}" action="home.php?mod=spacecp&ac=common&op=ignore&type=$type" >
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="ignoresubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="referer" value="{echo dreferer()}">
    <div class="inputall ppd bb">
    <ul>   	
	<li><label><input type="radio" name="authorid" id="authorid1" value="$_GET[authorid]" checked="checked" /> {lang shield_this_friend}</label></li>
	<li><label><input type="radio" name="authorid" id="authorid0" value="0" /> {lang shield_all_friend}</label></li>	
	</ul>
    </div>    
    <div class="hm"><button type="submit" name="feedignoresubmit" value="true" class="formdialog button2">{lang determine}</button></div>    
	</form>
    </div>
<!--{eval $nofooter = true;}-->
<!--{subtemplate common/footer}-->