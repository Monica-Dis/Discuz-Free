<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang privacy_prompt}<!--{/block}-->
<!--{eval $_G['home_tpl_titles'] = array('{lang remind}');}-->
<!--{template common/header}-->
<div class="Oxu4BuOKzCUF">{lang set_privacy}</div>
<!--{template common/footer}-->
