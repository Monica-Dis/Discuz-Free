<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang send_pm}<!--{/block}-->
<!--{template common/header}-->
<!--{if $op != ''}-->
<!--{if $_G['inajax']}-->
<form id="pmform_{$pmid}" name="pmform_{$pmid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=pm&op=send&touid=$touid&pmid=$pmid&mobile=2" >
<input type="hidden" name="referer" value="{echo dreferer();}" />
<input type="hidden" name="pmsubmit" value="true" />
<input type="hidden" name="formhash" value="{FORMHASH}" />
<input type="hidden" name="pmsubmit_btn" value="yes" />
<!-- main post_msg_box start -->
<div class="inputall bw{if $_G['inajax']} ajaxpop p_c{/if}">
	<ul class="b_pw bb">
	<!--{if !$touid}-->
	<li><input type="text" value="" tabindex="1" size="30" autocomplete="off" id="username" name="username" placeholder="{lang addressee}"></li>
	<!--{/if}-->
	<li class="m_c">
		<textarea tabindex="2" autocomplete="off" value="" id="sendmessage" name="message" rows="{if $_G['inajax']}5{else}10{/if}" placeholder="{lang thread_content}"></textarea>
	</li>
	</ul>
	<div class="hm"><button id="pmsubmit_btn" class="button2" disable="true">{lang sendpm}</button></div>
</div>
<!-- main postbox start -->
</form>
<!--{else}-->
<div class="r-block">{lang user_mobile_pm_error}</div>
<!--{/if}-->
<!--{else}-->
		<!--{if !$_G['inajax']}-->
        <div class="tabequal">
			<ul>
				<li><a href="home.php?mod=space&do=pm">{lang pm_center}</a></li>
				<li{if !$type} class="a"{/if}><a href="home.php?mod=spacecp&ac=pm">{lang send_pm}</a></li>
                <li{if $type == 1} class="a"{/if}><a href="home.php?mod=spacecp&ac=pm&type=1">{lang chat_type}</a></li>
			</ul>
		</div>
        <!--{/if}-->
<!--{if !$type}-->        
<form id="pmform_{$pmid}" name="pmform_{$pmid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=pm&op=send&touid=$touid&pmid=$pmid&mobile=2" >
	<input type="hidden" name="referer" value="{echo dreferer();}" />
	<input type="hidden" name="pmsubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="pmsubmit_btn" value="yes" />
<!-- main post_msg_box start -->
	<div class="inputall bw{if $_G['inajax']} ajaxpop p_c{/if}">
		<ul{if $_G['inajax']} class="b_pw bb"{/if}>
			<!--{if !$touid}-->
			<li><input type="text" value="" tabindex="1" size="30" autocomplete="off" id="username" name="username" placeholder="{lang addressee}"></li>
			<!--{/if}-->
			<li class="m_c">
				<textarea tabindex="2" autocomplete="off" value="" id="sendmessage" name="message" rows="{if $_G['inajax']}5{else}10{/if}" placeholder="{lang thread_content}"></textarea>
			</li>
		</ul>
        <!--{if $_G['inajax']}-->        
        <div class="hm"><button id="pmsubmit_btn" class="button2" disable="true">{lang sendpm}</button></div>
        <!--{/if}-->
	</div>
    <!--{if !$_G['inajax']}-->
    <div class="ftpost">
    <table cellspacing="0" cellpadding="0">
        <tr>
        <td>
		<div class="editor editordefault">
		<a href="javascript:;" class="postphoto editortab"></a>
		<a href="javascript:;" class="inlink editortab"></a>
		<a href="javascript:;" class="postsmilie editortab"></a>		
		</div> 
        </td>
        <th><button id="pmsubmit_btn" class="ftbtn nopost" disable="true">{lang sendpm}</button></th>
        </tr>
    </table>
		<div class="editor_item">            
		<div class="hidebox">
		<div class="addlinks">
        <i class="vt-links"></i>
		<input type="text" name="img_link" id="img_link" autocomplete="off" placeholder="{$langplus[img_link]}" />
		<span class="addlinks_btn" onclick="ilink(ins_code_0())">{$langplus[insert]}</span>
		</div>
		</div>
		<div class="hidebox">
		<div class="addlinks">
        <i class="vt-links"></i>
        <div class="link_item"><input type="text" name="links_link" id="links_link" autocomplete="off" placeholder="{$langplus[links_link]}" /></div>
        <div class="link_item"><input type="text" name="linkname_link" id="linkname_link" autocomplete="off" placeholder="{$langplus[linkname_link]}" /></div>
		<span class="addlinks_btn" onclick="ilink(ins_code_1())">{$langplus[insert]}</span>
		</div>
        </div>		
		<div id="smiliesdiv" class="hidebox"><div id="fastsmilies"></div></div>
		</div>
    </div>
    <!--{block footerplus}--><div class="ftbox"></div><!--{/block}-->
    <!--{/if}-->  
<!-- main postbox start -->
</form>
<!--{elseif $type == 1}-->
<!--{if !$_G['inajax']}-->
			<form id="pmform_{$pmid}" name="pmform_{$pmid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=pm&op=send&touid=$touid&pmid=$pmid&mobile=2" >
				<input type="hidden" name="referer" value="{echo dreferer()}" />
				<input type="hidden" name="pmsubmit" value="true" />
				<input type="hidden" name="type" value="1" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
                <div class="inputall bw">
                <ul>               
				<!--{if !$touid}-->
				<li><input type="text" name="subject" id="subject" placeholder="{lang title}" /></li>
				<li class="addusers mbn">
				<input type="text" name="username" id="username" autocomplete="off" placeholder="{lang joiner}" />
				<span class="addusers_btn" disable="true">{lang increase}</span>
				</li>                        
				<div class="participant"></div>                        
				<!--{/if}-->
				<li class="m_c ptn"><textarea rows="10" name="message" id="sendmessage" placeholder="{lang content}"></textarea></li>
				</ul>
    <div class="ftpost">
    <table cellspacing="0" cellpadding="0">
        <tr>
        <td>
		<div class="editor editordefault">
		<a href="javascript:;" class="postphoto editortab"></a>
		<a href="javascript:;" class="inlink editortab"></a>
		<a href="javascript:;" class="postsmilie editortab"></a>		
		</div> 
        </td>
        <th>
        <button type="submit" id="pmsubmit_btn" class="ftbtn nopost" disable="true">{lang sendpm}</button>
        </th>
        </tr>
    </table>
		<div class="editor_item">            
		<div class="hidebox">
		<div class="addlinks">
        <i class="vt-links"></i>
		<input type="text" name="img_link" id="img_link" autocomplete="off" placeholder="{$langplus[img_link]}" />
		<span class="addlinks_btn" onclick="ilink(ins_code_0())">{$langplus[insert]}</span>
		</div>
		</div>
		<div class="hidebox">
		<div class="addlinks">
        <i class="vt-links"></i>
        <div class="link_item"><input type="text" name="links_link" id="links_link" autocomplete="off" placeholder="{$langplus[links_link]}" /></div>
        <div class="link_item"><input type="text" name="linkname_link" id="linkname_link" autocomplete="off" placeholder="{$langplus[linkname_link]}" /></div>
		<span class="addlinks_btn" onclick="ilink(ins_code_1())">{$langplus[insert]}</span>
		</div>
        </div>		
		<div id="smiliesdiv" class="hidebox"><div id="fastsmilies"></div></div>
		</div>
    </div>
    <!--{block footerplus}--><div class="ftbox"></div><!--{/block}-->				
		</form>

<script type="text/javascript">
$(document).on('click','.addusers_btn', function() {
	var newvalue = $('#username').val();
	newvalue = newvalue.replace(/^\s+|\s+$/g,"");
	if (newvalue) {
	$(".participant").prepend("<span class='joinername'><i>"+newvalue+"</i><input type='hidden' name='users[]' value='"+newvalue+"'></span>");
	$("#username").val("");
	$('.addusers_btn').removeClass('addusers_btn_on');
	$('.addusers_btn').attr('disable', 'true');
		return true;
	} else {
		return false;
	}
});	
$(document).on('click','.joinername',function(){
	$(this).remove();	
});
$('#username').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {
		$('.addusers_btn').addClass('addusers_btn_on');
		$('.addusers_btn').attr('disable', 'false');		
	} else {
		$('.addusers_btn').removeClass('addusers_btn_on');
		$('.addusers_btn').attr('disable', 'true');
	}
});
</script> 
<!--{else}-->
<div class="ajaxpop"><div class="r-block">{lang uploadstatusmsg10}</div></div>
<!--{/if}-->
<!--{/if}-->

<!--{if !$_G['inajax']}-->
<!--{if $_G[uid]}-->      
<script type="text/javascript">
	$(document).ready(function() {
	$('.editordefault a.editortab').click(function(){
		if($(this).hasClass('on')){
			$('.ftbox').removeClass('keyht');
		}else{
			$('.ftbox').addClass('keyht');
		}
		$('.editordefault a').eq($(this).index()).toggleClass('on').siblings().removeClass('on');
		$('.hidebox').eq($(".editordefault a.editortab").index(this)).slideToggle().siblings().slideUp();
	});	
	});		
	function ins_code_0(){
		var newvalue = $("#img_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#img_link").val("");
			editorclose();
			return "[img]"+ newvalue +"[/img]";
		}else{
			return "";
		}
	}	
	function ins_code_1(){
		var newvalue = $("#links_link").val();
		var newvalue2 = $("#linkname_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		newvalue2 = newvalue2.replace(/^\s+|\s+$/g,"");
		if(!newvalue2) {
			newvalue2 = newvalue;
		}
		if (newvalue) {
			$("#links_link").val("");
			$("#linkname_link").val("");
			editorclose();
			return "[url="+ newvalue +"]"+ newvalue2 +"[/url]";
		}else{
			return "";
		}
	}
	function editorclose(){		
		$('.editordefault a').removeClass('on');
		$('.hidebox').slideUp();
		$('.ftbox').removeClass('keyht');
	}	
</script>
<!--{/if}--> 
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>        
<script type="text/javascript" src="data/cache/common_smilies_var.js?eAa"></script>
<script type="text/javascript">
function ilink(lk){$('#sendmessage').insertAtCaret(lk);}
function ismi(sl){$('#sendmessage').insertAtCaret(sl);}
var j = 1, smilies_fastdata = '', img;
if (smilies_array[{$smileid}][{$smilepg}].length > {$smilenumber}){smilienums = {$smilenumber};}else{smilienums = smilies_array[{$smileid}][{$smilepg}].length;}
for (i = 0; i < smilienums; i++) {	
	s = smilies_array[{$smileid}][{$smilepg}][i];	
    smilieimg = "static/" + 'image/smiley/' + smilies_type['_' + {$smileid}][1] + '/' + s[2];
    smilies_fastdata += s ? '<li><img src="' + smilieimg + '" onclick="ismi(\'' + s[1].replace(/'/, '\\\'') + '\')" />' : '</li>';
}
window.onload = function() {
    $('#fastsmilies').html('<div class="smilies"><ul>' + smilies_fastdata + '</ul></div>');
}

$('#sendmessage').on('input focus', function(){
	$(this).css('height','auto');
	$(this).css('height',this.scrollHeight + 2); 
});
</script>
<!--{/if}-->
<script type="text/javascript">
	(function() {
		$('#sendmessage').on('keyup input focus', function() {
			var obj = $(this);
			if(obj.val()) {
				$('#pmsubmit_btn').removeClass('nopost').addClass('btnon');
				$('#pmsubmit_btn').attr('disable', 'false');
			} else {
				$('#pmsubmit_btn').removeClass('btnon').addClass('nopost');
				$('#pmsubmit_btn').attr('disable', 'true');
			}
		});
		$(document).on('click', '#pmsubmit_btn', function() {
			var obj = $(this);
			var form = $(this.form);
			if(obj.attr('disable') == 'true') {
				return false;
			}
			popup.open('<div class="cloading"></div>');
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey='+form.attr('id')+'&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				<!--{if $_G['inajax']}-->
				window.location.reload();
				<!--{else}-->
				popup.open(s.lastChild.firstChild.nodeValue);
				<!--{/if}-->
			})
			.error(function() {
				popup.open('{lang networkerror}', 'alert');
			});
			return false;
			});
	 })();
</script>
<!--{/if}-->
<!--{eval $nofooter = true; $nosopenmenu = true;}-->
<!--{template common/footer}-->