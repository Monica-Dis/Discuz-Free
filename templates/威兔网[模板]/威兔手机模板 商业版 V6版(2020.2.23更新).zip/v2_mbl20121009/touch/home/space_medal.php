<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=medal">{lang medals}</a><!--{/block}-->
<!--{template common/header}-->
  <div class="NkGgJbO2CQdl">
  <ul>
    <li{if empty($_GET[action])} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=medal">{lang medals_center}</a></li>
	<li{if $_GET[action] == 'log' && $_GET[do] != 'record'} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=medal&action=log">{lang my_medals}</a></li>
    <li{if $_GET[action] == 'log' && $_GET[do] == 'record'} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=medal&action=log&do=record">{lang medals_record}</a></li>
  </ul>
  </div>  
  <div class="9Z98s5hk7ENf">  
			<!--{if empty($_GET[action])}-->
				<!--{if $medallist}-->
					<ul class="mMLnOKwZXEp5">
						<!--{loop $medallist $key $medal}-->
							<li>
								<div class="QyS8QNeg0uby" id="medal_$medal[medalid]">
                                <div class="F2b7zMaxwhZq">
                                <div class="xAYzUuWiJIwj" ><img src="{STATICURL}image/common/$medal[image]" alt="$medal[name]"/></div>
                                <div class="B1xwaN5NYwVa">$medal[name]</div>                                
										<p class="kmbBQut97sKZ">
											<!--{if $medal[expiration]}-->
												{lang expire} $medal[expiration] {lang days},
											<!--{/if}-->
											<!--{if $medal[permission] && !$medal['price']}-->
												$medal[permission]
											<!--{else}-->
												<!--{if $medal[type] == 0}-->
													{lang medals_type_0}
												<!--{elseif $medal[type] == 1}-->
													<!--{if $medal['price']}-->
														<!--{if {$_G['setting']['extcredits'][$medal[credit]][unit]}}-->
															{$_G['setting']['extcredits'][$medal[credit]][title]} <span>$medal[price]</span> {$_G['setting']['extcredits'][$medal[credit]][unit]}
														<!--{else}-->
															<span>$medal[price]</span> {$_G['setting']['extcredits'][$medal[credit]][title]}
														<!--{/if}-->
													<!--{else}-->
														{lang medals_type_1}
													<!--{/if}-->
												<!--{elseif $medal[type] == 2}-->
													{lang medals_type_2}
												<!--{/if}-->
											<!--{/if}-->
										</p>	
                                </div>
									<!--{if in_array($medal[medalid], $membermedal)}-->
										<div class="KGoo21LfmfRG">{lang space_medal_have}</div>
									<!--{else}-->                                                                                                                   
										<div class="mLTIqH1BBxVp">
                                        <!--{if $medal[type] && $_G['uid']}-->                                         
											<!--{if in_array($medal[medalid], $mymedals)}-->
												<span class="Q8lZLnjHfm2v">
                                                <!--{if $medal['price']}-->
													{lang space_medal_purchased}
												<!--{else}-->
													<!--{if !$medal[permission]}-->
														{lang space_medal_applied}
													<!--{else}-->
														{lang space_medal_receive}
													<!--{/if}-->
												<!--{/if}-->
                                                </span>                                            
											<!--{else}-->											
                                                <a href="home.php?mod=medal&action=confirm&medalid=$medal[medalid]" class="F3pveqiOE331">
													<!--{if $medal['price']}-->
														{lang space_medal_buy}
													<!--{else}-->
														<!--{if !$medal[permission]}-->
															{lang medals_apply}
														<!--{else}-->
															{lang medals_draw}
														<!--{/if}-->
													<!--{/if}-->
												</a>                                             
											<!--{/if}-->
                                        <!--{else}-->
                                        <span class="Q8lZLnjHfm2v">{$langplus[award]}</span>    
										<!--{/if}-->
                                        </div>
									<!--{/if}-->                            
								<div class="ZzDvCy6O9iT1"><p>$medal[description]</p></div>
                                </div>                                
							</li>
						<!--{/loop}-->                        
					</ul>
                    <div class="Es3s87mAHtE5"></div> 
                    
<script type="text/javascript">
$(document).ready(function(){
	$(document).on('click','.medal_data',function(){		
		var dataid = $(this).parent('.medal_box').attr('id'); 		
		$('#' + dataid + ' > .description').fadeIn();
		$('.close_m').show();
	})
	$('.close_m').off().on('touchstart',function(){		
		$('.description').fadeOut();	
		$(this).hide();
	});	
});
</script>                                                             
				<!--{else}-->
					<!--{if $medallogs}-->
						<div class="sqK9gG26iUGb">{lang medals_nonexistence}</p>
					<!--{else}-->
						<div class="sqK9gG26iUGb">{lang medals_noavailable}</p>
					<!--{/if}-->
				<!--{/if}-->
   
			<!--{elseif $_GET[action] == 'log'}-->
            
			<!--{if $_GET[action] == 'log' && $_GET[do] == 'record'}--> 
				<!--{if $medallogs}-->
					<ul id="alist" class="rfhmVKYApDVi">                    
						<!--{loop $medallogs $medallog}-->
						<li>
							<!--{if $medallog['type'] == 2 || $medallog['type'] == 3}-->
								{lang medals_message3} $medallog[dateline] {lang medals_message4} <span>$medallog[name]</span> {lang medals},<!--{if $medallog['type'] == 2}--> {lang medals_operation_2}<!--{elseif $medallog['type'] == 3}--> {lang medals_operation_3}<!--{/if}-->
							<!--{elseif $medallog['type'] != 2 && $medallog['type'] != 3}-->
								{lang medals_message3} $medallog[dateline] {lang medals_message5} <span>$medallog[name]</span> {lang medals},<!--{if $medallog[expiration]}--> {lang expire}: $medallog[expiration]<!--{else}--> {lang medals_noexpire}<!--{/if}-->
							<!--{/if}-->
						</li>
						<!--{/loop}-->                        
					</ul>                     
    <!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($medallognum / $tpp);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=medal&action=log&do=record" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="./template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->    
	<!--{else}-->
	<div class="sqK9gG26iUGb">{lang medals_nonexistence_own}</div>
	<!--{/if}-->            
            <!--{else}-->
                <!--{if $mymedals}-->
					<ul class="NVpT5ULbubMK">
						<!--{loop $mymedals $mymedal}-->
						<li>
                           <div class="xAYzUuWiJIwj" ><img src="{STATICURL}image/common/$mymedal[image]" alt="$mymedal[name]" /></div>
							<div class="B1xwaN5NYwVa">$mymedal[name]</div>                            
						</li>
						<!--{/loop}-->
					</ul>
				<!--{else}-->
                <div class="sqK9gG26iUGb">{lang medals_nonexistence_own}</div>
                <!--{/if}-->            
            <!--{/if}-->    
	<!--{/if}-->
</div>

<!--{template common/footer}-->