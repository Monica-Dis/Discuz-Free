<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $_G[home_tpl_titles] = array('{lang personal_category}');}-->
<!--{template common/header}-->
<!--{if $_GET['op'] == 'edit'}-->
	<form id="classform" name="classform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=class&op=edit&classid=$classid">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editsubmit" value="true">
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="wPUq6sXBhE74">
			<div class="YHRcwmjjR4Yi">
            <input type="text" name="classname" id="classname" value="$class[classname]" />
            </div>		
		<div class="CUPwdSVx7pa8"><button type="submit" name="editsubmit_btn" class="AwiHIvwIVEL4" value="true">{lang determine}</button></div>
		</div>
	</form>
<!--{elseif $_GET['op'] == 'delete'}-->
	<form id="classform" name="classform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=class&op=delete&classid=$classid">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="wPUq6sXBhE74">
        <div class="sqK9gG26iUGb">{lang delete_category_message}</div>
		<div class="CUPwdSVx7pa8"><button type="submit" name="deletesubmit_btn" class="AwiHIvwIVEL4" value="true">{lang determine}</button></div>
        </div>
	</form>
<!--{/if}-->
<!--{template common/footer}-->