<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=spacecp&ac=poke">{lang say_hi}</a><!--{/block}-->
<!--{template common/header}-->
{eval 
$icons = array(
	0 => '{lang poke_0}',
	1 => '<img alt="cyx" src="'.STATICURL.'image/poke/cyx.gif" class="vm" /> {lang poke_1}',
	2 => '<img alt="wgs" src="'.STATICURL.'image/poke/wgs.gif" class="vm" /> {lang poke_2}',
	3 => '<img alt="wx" src="'.STATICURL.'image/poke/wx.gif" class="vm" /> {lang poke_3}',
	4 => '<img alt="jy" src="'.STATICURL.'image/poke/jy.gif" class="vm" /> {lang poke_4}',
	5 => '<img alt="pmy" src="'.STATICURL.'image/poke/pmy.gif" class="vm" /> {lang poke_5}',
	6 => '<img alt="yb" src="'.STATICURL.'image/poke/yb.gif" class="vm" /> {lang poke_6}',
	7 => '<img alt="fw" src="'.STATICURL.'image/poke/fw.gif" class="vm" /> {lang poke_7}',
	8 => '<img alt="nyy" src="'.STATICURL.'image/poke/nyy.gif" class="vm" /> {lang poke_8}',
	9 => '<img alt="gyq" src="'.STATICURL.'image/poke/gyq.gif" class="vm" /> {lang poke_9}',
	10 => '<img alt="dyx" src="'.STATICURL.'image/poke/dyx.gif" class="vm" /> {lang poke_10}',
	11 => '<img alt="yw" src="'.STATICURL.'image/poke/yw.gif" class="vm" /> {lang poke_11}',
	12 => '<img alt="ppjb" src="'.STATICURL.'image/poke/ppjb.gif" class="vm" /> {lang poke_12}',
	13 => '<img alt="yyk" src="'.STATICURL.'image/poke/yyk.gif" class="vm" /> {lang poke_13}'
);
}
		<!--{if !$_G['inajax']}-->
        <div class="tabequal">
			<ul>
                <li$actives[poke]><a href="home.php?mod=spacecp&ac=poke"><!--{if $op == 'reply' }-->{lang back_to_say_hello}<!--{else}-->{lang poke_received}<!--{/if}--></a></li>
				<li$actives[send]><a href="home.php?mod=spacecp&ac=poke&op=send">{lang say_hi}</a></li>
			</ul>
        </div>
        <!--{/if}-->

<!--{if $op == 'send' || $op == 'reply'}-->
			<form method="post" autocomplete="off" id="pokeform_{$tospace[uid]}" name="pokeform_{$tospace[uid]}" action="home.php?mod=spacecp&ac=poke&op=$op&uid=$tospace[uid]" >
				<input type="hidden" name="referer" value="{echo dreferer()}">
				<input type="hidden" name="pokesubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="from" value="$_GET[from]" />
				<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->                
                <!--{if $_G[inajax]}--><div class="ajaxpop"><!--{/if}-->
				<div class="inputall bb{if !$_G[inajax]} bw pbm{else} b_pw pbn{/if}">					
					<!--{if !$_G['inajax']}-->
                    <ul>
                    <!--{if $tospace[uid]}-->
                    <div class="poke_avatar">
						<a href="home.php?mod=space&uid=$tospace[uid]&do=profile" class="avatars"><img src="{avatar($tospace[uid],middle,true)}" /></a>
						{lang to} <strong>{$tospace[username]}</strong> {lang say_hi}
                    </div>
					<!--{else}-->
						<li><input type="text" name="username" value="" placeholder="{lang username}" /></li>
					<!--{/if}-->                     
                        <li class="mbw"><input type="text" name="note" id="note" value="" size="30" placeholder="{$langplus[pokemessage]}" /></li>
                    </ul>
                    <!--{/if}-->                                        
					<ul class="poke_kv">
						<!--{loop $icons $k $v}-->
						<li><label for="poke_$k"><input type="radio" name="iconid" id="poke_$k" value="{$k}" {if $k==3}checked="checked"{/if} class="pc checkbox" />{$v}</label></li>
						<!--{/loop}-->
                    </ul>                 
				</div>				
				<div class="{if !$_G['inajax']}naj{else}hm{/if}"><button type="submit" name="pokesubmit_btn" id="pokesubmit_btn" value="true" class="formdialog button2">{lang send}</button></div>
                <!--{if $_G[inajax]}--></div><!--{/if}-->				
			</form>            
<!--{eval $nofooter = true;}-->
<!--{elseif $op == 'view'}-->
			<ul class="poke_view">
            <a href="home.php?mod=space&uid=$subvalue[fromuid]&do=profile" class="poke_view_avatar"><img src="{avatar($subvalue[fromuid],middle,true)}" /></a>
            <!--{loop $list $key $subvalue}-->
			<li>
				<p class="poke_view_name qian">
                <!--{if $subvalue[fromuid]==$space[uid]}--><a href="javascript:;">{lang me}</a><!--{else}--><a href="home.php?mod=space&uid=$subvalue[fromuid]&do=profile">{$value[fromusername]}</a><!--{/if}-->:				
					<!--{if $subvalue[iconid]}-->{$icons[$subvalue[iconid]]}<!--{else}-->{lang say_hi}<!--{/if}-->					
					<span><!--{date($subvalue[dateline],'m-d H:i')}--></span>                    
				</p>
                <!--{if $subvalue[note]}--><p class="qian mtn">{lang say}: $subvalue[note]</p><!--{/if}-->
			</li>
			<!--{/loop}-->
            </ul> 
<!--{$formsdialog_item}--> 
<!--{elseif $op == 'ignore'}-->
            <div class="bw{if $_G['inajax']} ajaxpop{/if}">
			<form method="post" autocomplete="off" id="friendform_{$uid}" name="friendform_{$uid}" action="home.php?mod=spacecp&ac=poke&op=ignore&uid=$uid" >
				<input type="hidden" name="referer" value="{echo dreferer()}">
				<input type="hidden" name="ignoresubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="from" value="$_GET[from]" />
				<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
				<div class="r-block">{lang determine_lgnore_poke}</div>
				<div class="{if !$_G['inajax']}naj{else}hm{/if}">
				<button type="submit" name="ignoresubmit_btn" class="formsdialog button2" value="true">{lang determine}</button>
				</div>
			</form>
            </div> 
<!--{if !$_G[inajax]}-->
<script type="text/javascript">
		$(document).on('click', '.formsdialog', function() {
			popup.open('<div class="cloading"></div>');
			var obj = $(this);
			var formobj = $(this.form);
			$.ajax({
				type:'POST',
				url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
				data:formobj.serialize(),
				dataType:'xml'
			})
			.success(function(s) {					
				window.location.href = 'home.php?mod=space&do=notice&view=interactive&type=poke';										
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});
</script> 
<!--{/if}-->                               
<!--{eval $nofooter = true;}-->            
<!--{else}-->            
			<!--{if $list}-->
            <ul id="alist" class="pagelist friend">				
                <!--{eval $t = 1;}-->
                <!--{loop $list $key $value}-->
				<li>
                <div class="locker" id="locker_$value[uid]{$page}{$t}">
                <span class="friendset"><i class="vt-right"></i></span>
				<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="friendavatar"><img src="<!--{avatar($value[uid],middle,true)}-->" /></a>                
				<h1><a href="home.php?mod=space&uid=$value[fromuid]&do=profile" >{$value[fromusername]}</a></h1>
                <p>
				<!--{if $value[iconid]}-->{$icons[$value[iconid]]}<!--{else}-->{lang say_hi}<!--{/if}-->&nbsp;&nbsp;
                <span><!--{date($value[dateline], 'm-d H:i')}--></span>
				</p>
				<div class="friend_mg">
                <ul>
                <!--{if !$value['isfriend']}--><li class="friendadd"><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]&handlekey=addfriendhk_{$value[uid]}" class="dialog">{$langplus[add_friend]}</a></li>
                <!--{else}-->
                <li class="reop"><a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$value[uid]&handlekey=delfriendhk_{$value[uid]}" class="dialog">{$langplus[ignore_friend]}</a></li>
                <!--{/if}-->
				<li><a href="home.php?mod=spacecp&ac=poke&op=reply&uid=$value[uid]&handlekey=pokereply" class="dialog">{$langplus[sayhello]}</a></li>
				<li class="frienddel"><a href="home.php?mod=spacecp&ac=poke&op=ignore&uid=$value[uid]&handlekey=pokeignore" class="dialog">{lang ignore}</a></li>
                <li class="editnote"><a href="home.php?mod=spacecp&ac=poke&op=view&uid=$value[uid]">{$langplus[all]}</a></li>
                </ul>
                </div>
                <div class="lockerclose" id="lockerclose_$value[uid]"></div>
                </div>
				</li>
                <!--{eval $t++;}-->
				<!--{/loop}-->            
			</ul>
            <div class="close_m"></div>           
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=spacecp&ac=poke" class="morelink" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->  
    <!--{if $multi}-->$multi<!--{/if}--> 
    <!--{/if}--> 
    
<script type="text/javascript">
$(document).ready(function(){
	$(document).on('click','.friendset',function(){		
		var lockerid = $(this).parent('.locker').attr('id'); 
		$('#' + lockerid).addClass('lockeropen').css('z-index','55');		
		$('.close_m').show();
	})
	$(document).on('click','.lockerclose',function(){
		$('.locker').removeClass('lockeropen').css('z-index', '');	
		$('.close_m').hide();	
	})
	$('.close_m').off().on('touchstart',function(){
		$('.locker').removeClass('lockeropen').css('z-index', '');		
		$(this).hide();	
	});	
});
</script>
       
    <!--{$formsdialog_item}-->
			<!--{else}-->
				<div class="r-block">{lang no_new_poke}</div>
			<!--{/if}-->
                        
<!--{/if}-->
<!--{template common/footer}-->