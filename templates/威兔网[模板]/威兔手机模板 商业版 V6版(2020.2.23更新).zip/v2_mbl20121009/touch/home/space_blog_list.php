<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=space&do=blog"><!--{if $_G['uid'] != $space['uid']}-->{$space[username]}{lang eccredit_s}<!--{/if}-->{lang blog}</a><!--{/block}--> 
<!--{template common/header}-->
	<div class="NkGgJbO2CQdl">
      <ul>
        <li$actives[me]><a href="home.php?mod=space{if $_G['uid'] != $space['uid']}&uid={$space['uid']}{/if}&do=blog&view=me">{lang my_blog}</a></li>
        <li$actives[we]><a href="home.php?mod=space&do=blog&view=we">{lang friend_blog}</a></li>        
        <li$actives[all]><a href="home.php?mod=space&do=blog&view=all">{lang view_all}</a></li>
      </ul>
    </div>
    <!--{hook/space_blog_list_v2_mobile}-->
  <!--{if $count}-->
  <ul id="alist" class="JcyMps1sR7GF">      
      <!--{loop $list $k $value}-->
      <!--{eval $stickflag = isset($value['stickflag']) ? 0 : 1;}-->
      <!--{if $page == 1}-->
      <li>      
      <a href="home.php?mod=space&uid=$value[uid]&do=profile" class="UoRZiAghxSa8"><img src="<!--{avatar($value[uid],middle,true)}-->" /></a>
      <div class="aV5BjTsOmhpp">      
      <a href="home.php?mod=space&uid=$value[uid]&do=profile">$value[username]</a>   
      <em>$value[dateline]</em>  
      </div>
      <div class="qpHcVB8N9tXf"><!--{if !$stickflag}--><span class="evXx4HZDPWdN">{lang stick}</span> &middot; <!--{/if}--><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]">$value[subject]</a></div>
      <div class="hk8b4b2rXe54">
      <!--{if $value[pic]}--><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="J63ZfIGjyYMP"><img src="$value[pic]" /></a><!--{/if}-->
      <p><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="Q8lZLnjHfm2v"><!--{if $value[pic]}-->{echo cutstr(strip_tags($value[message]),100)}<!--{else}-->{echo cutstr(strip_tags($value[message]),120)}<!--{/if}--></a></p>
      </div>
      <!--{if $_GET['view']=='me' && $space['self']}-->
      <div class="ecKsBzQuixPL">
      <!--{if $classarr[$value[classid]]}--><a href="home.php?mod=space&uid=$value[uid]&do=blog&classid=$value[classid]&view=me">#{$classarr[$value[classid]]}</a><!--{/if}-->
      <span class="99u2LxYcMOhO">
      <!--{if $value['hot']}--><a href="javascript:;"><i class="c17iFPR1sf2l"></i></a><!--{/if}-->
      <!--{if empty($value['status'])}-->							
      <a href="home.php?mod=spacecp&ac=blog&blogid=$value[blogid]&op=stick&stickflag=$stickflag&handlekey=stickbloghk_{$value[blogid]}" id="blog_stick_$value[blogid]" class="F3pveqiOE331"><!--{if $stickflag}--><i class="K2NZF3OmIhqp"></i><!--{else}--><i class="5CYoNPvujUrr"></i><!--{/if}--></a>
      <!--{/if}-->
      <a href="home.php?mod=spacecp&ac=blog&blogid=$value[blogid]&op=edit"><i class="HcGNy22c8avk"></i></a>
      <a href="home.php?mod=spacecp&ac=blog&blogid=$value[blogid]&op=delete&handlekey=delbloghk_{$value[blogid]}" class="F3pveqiOE331"><i class="aPyV086aHjq3"></i></a>
      </span>
      </div>
      <!--{/if}-->      
      </li>
      <!--{else}-->
      <!--{if $stickflag}-->
      <li>      
      <a href="home.php?mod=space&uid=$value[uid]&do=profile" class="UoRZiAghxSa8"><img src="<!--{avatar($value[uid],middle,true)}-->" /></a>
      <div class="aV5BjTsOmhpp">      
      <a href="home.php?mod=space&uid=$value[uid]&do=profile">$value[username]</a>   
      <em>$value[dateline]</em>  
      </div>
      <div class="qpHcVB8N9tXf"><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]">$value[subject]</a></div>
      <div class="hk8b4b2rXe54">
      <!--{if $value[pic]}--><a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="J63ZfIGjyYMP"><img src="$value[pic]" /></a><!--{/if}-->
      <a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="Q8lZLnjHfm2v"><!--{if $value[pic]}-->{echo cutstr(strip_tags($value[message]),100)}<!--{else}-->{echo cutstr(strip_tags($value[message]),120)}<!--{/if}--></a>
      </div>
      <!--{if $_GET['view']=='me' && $space['self']}-->
      <div class="ecKsBzQuixPL">
      <!--{if $classarr[$value[classid]]}--><a href="home.php?mod=space&uid=$value[uid]&do=blog&classid=$value[classid]&view=me">#{$classarr[$value[classid]]}</a><!--{/if}-->
      <span class="99u2LxYcMOhO">
      <!--{if $value['hot']}--><a href="javascript:;"><i class="c17iFPR1sf2l"></i></a><!--{/if}-->
      <!--{if empty($value['status'])}-->							
      <a href="home.php?mod=spacecp&ac=blog&blogid=$value[blogid]&op=stick&stickflag=$stickflag&handlekey=stickbloghk_{$value[blogid]}" id="blog_stick_$value[blogid]" class="F3pveqiOE331"><!--{if $stickflag}--><i class="K2NZF3OmIhqp"></i><!--{else}--><i class="5CYoNPvujUrr"></i><!--{/if}--></a>
      <!--{/if}-->
      <a href="home.php?mod=spacecp&ac=blog&blogid=$value[blogid]&op=edit"><i class="HcGNy22c8avk"></i></a>
      <a href="home.php?mod=spacecp&ac=blog&blogid=$value[blogid]&op=delete&handlekey=delbloghk_{$value[blogid]}" class="F3pveqiOE331"><i class="aPyV086aHjq3"></i></a>
      </span>
      </div>
      <!--{/if}-->      
      </li>
      <!--{/if}-->
      
      <!--{/if}-->
      <!--{/loop}-->      
    </ul>    
    
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->   
    <!--{if $multi}-->$multi<!--{/if}--> 
    <!--{/if}--> 
  
  <!--{else}-->
  <div class="sqK9gG26iUGb">{lang no_related_blog}</div>
  <!--{/if}-->                               
				<!--{if $_GET[view] == 'all'}-->
                <div class="T8WzIMPFAEdj"> 
                <div class="gZlcaCGmGZ0q"><span class="MzXGZuYzqGml"></span>{lang blog}{$langplus[threadtypes]}</div>
                <div class="6JkCOQZd86Ga">{lang site_categories}</div>              
                    <div class="LyO9GqJZlntf">
					<ul>
					<li><a href="home.php?mod=space&do=blog&view=all" class="blog_sortnm{if !$_GET[catid] && !$_GET[order]} a{/if}">{lang all}</a></li>
					<li><a href="home.php?mod=space&do=blog&view=all&order=hot" class="blog_sortnm{if $_GET[order] == hot} a{/if}" $orderactives[hot]>{$langplus[recommend]}</a></li>
					<!--{if $category}-->
						<!--{loop $category $value}-->							
							<li><a href="home.php?mod=space&do=blog&catid=$value[catid]&view=all&order=$_GET[order]" class="blog_sortnm{if $_GET[catid] == $value[catid]} a{/if}">$value[catname]</a></li>
						<!--{/loop}-->
					<!--{/if}-->
                    </ul>
                    </div>
				</div>
                <!--{/if}-->

				<!--{if $userlist}-->
                <div class="T8WzIMPFAEdj">
                <div class="gZlcaCGmGZ0q"><span class="MzXGZuYzqGml"></span>{lang filter_by_friend}</div>               
                    <div class="829IK7m35Nl8">
                    <ul>
                        <li><a href="home.php?mod=space&do=blog&view=we" class="blog_sortnm{if !$_GET[fuid]} a{/if}">{lang all}</a></li>
                        <!--{loop $userlist $value}-->
                        <li><a href="home.php?mod=space&do=blog&view=we&fuid={$value[fuid]}" class="blog_sortnm{if $_GET[fuid] == $value[fuid]} a{/if}">$value[fusername]</a></li>
                        <!--{/loop}-->
                    </ul>
                    </div>
                </div>
				<!--{/if}-->
                
				<!--{if $_GET[view] == 'me' && $classarr}-->
                <div class="T8WzIMPFAEdj">
                <div class="gZlcaCGmGZ0q"><span class="MzXGZuYzqGml"></span>{lang blog}{$langplus[threadtypes]}</div>
                <div class="6JkCOQZd86Ga">{lang personal_category}<!--{if $space[self]}--><span class="wXOrWenTnGnR">{lang edit}</span><!--{/if}--></div>                
                    <div class="LyO9GqJZlntf">
					<ul>
						<li><a href="home.php?mod=space{if $_G['uid'] != $space['uid']}&uid={$space['uid']}{/if}&do=blog&view=me" class="blog_sortnm{if !$_GET[classid]} a{/if}">{lang all}</a></li>
                    <!--{loop $classarr $classid $classname}-->
						<li>
                        <a href="home.php?mod=space&uid=$space[uid]&do=blog&classid=$classid&view=me" id="classid$classid" class="blog_sortnm{if $_GET[classid] == $classid} a{/if}">$classname</a>
                        <!--{if $space[self]}-->
						<div class="B3IyMxdauKtw" id="classid{$classid}_menu">
							<a href="home.php?mod=spacecp&ac=class&op=edit&classid=$classid" id="c_edit_$classid" class="F3pveqiOE331" ><i class="HcGNy22c8avk"></i></a>
							<a href="home.php?mod=spacecp&ac=class&op=delete&classid=$classid" id="c_delete_$classid" class="F3pveqiOE331" ><i class="qDfR9RhLWeUO"></i></a>
						</div>
						<!--{/if}-->
                        </li>
					<!--{/loop}-->
                    </ul>
                    </div>
                </div>
                <!--{/if}-->
                
                <!--{if ($_GET[view] == 'all') || $userlist || ($_GET[view] == 'me' && $classarr)}-->
                <script type="text/javascript">	
                $(document).ready(function(){	
                	$('.scroll_sort').click(function(){
                		$('.menufly').addClass('infly'); 
						$('body').addClass('menufly_open');                		
                	}); 	
                	$('.vt-close').click(function(){	
                		$('.menufly').removeClass('infly');
						$('body').removeClass('menufly_open');                		
                	});	
                	<!--{if $space[self]}-->
					$('.blog_editsort').click(function(){	
                		$('.blog_sortedit').toggle();
                		$(this).toggleClass('orange');
                	});
					<!--{/if}-->	 
                });	
                </script>     
				<!--{/if}-->
<!--{if helper_access::check_module('blog')}-->
<!--{block footerthree}-->
<li><div class="lkzxUSeCuNPo"><a href="home.php?mod=spacecp&ac=blog" class="i0a6HFurbhHA"><i class="RtBILaDhl45b"></i></a></div></li>
<!--{/block}-->
<!--{/if}-->

<!--{if ($_GET[view] == 'all') || $userlist || ($_GET[view] == 'me' && $classarr)}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="javascript:;" class="fO6hxU2pKqw0"></a></div>
<!--{/block}-->
<!--{/if}-->

<!--{template common/footer}-->