<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $op == 'bkname'}-->{lang follow_editnote}<!--{elseif $op == 'getfeed'}-->{lang follow}<!--{elseif $op == 'delete'}-->{lang delete}{lang follow}<!--{/if}--><!--{/block}-->
<!--{if $op == 'bkname'}-->
<!--{eval $navtitle = {lang follow_editnote};}-->
<!--{elseif $op == 'getfeed'}-->
<!--{eval $navtitle = {lang follow};}-->
<!--{elseif $op == 'delete'}-->
<!--{eval $navtitle = {lang follow_del_feed};}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if $op == 'bkname'}-->    
	<!--{if !submitcheck('editbkname')}-->
    <div class="bw ajaxpop">
	<form method="post" autocomplete="off" id="bknameform_{$_GET[handlekey]}" name="bknameform_{$_GET[handlekey]}" action="home.php?mod=spacecp&ac=follow&op=bkname&fuid=$followuser['followuid']">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editbkname" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<ul class="inputall b_pw pbm bb">
			<li><input type="text" name="bkname" value="$followuser['bkname']" placeholder="{lang follow_editnote}" /></li>
            <li class="m_c fz5">{lang follow_for} $followuser['fusername'] {lang follow_add_bkname}</li>
		</ul>
		<div class="hm"><button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="formdialog button2">{lang save}</button></div>
	</form>
    </div>
	<!--{/if}-->
<!--{elseif $op == 'getfeed'}-->
	<!--{if !empty($list)}-->
	<!--{subtemplate home/follow_feed_li}-->

    <!--{eval $totalpage = ceil(1000 / 20);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=spacecp&ac=follow&op=getfeed&{if $do == 'feed'}viewtype={$view}{elseif $do == 'view'}uid={$uid}&banavatar=1{/if}&archiver=1" class="morelink" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    
	<!--{else}-->
	<div class="r-block">{lang follow_preview_null}</div>
	<!--{/if}-->
<!--{elseif $op == 'delete'}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if} ">
	<form method="post" autocomplete="off" id="deletefeed_{$_GET['feedid']}" name="deletefeed_{$_GET['feedid']}" action="home.php?mod=spacecp&ac=follow&op=delete&feedid=$_GET['feedid']" >
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
        <div class="r-block">{lang follow_del_feed_confirm}</div>
		<div class="hm"><button type="submit" name="btnsubmit" value="true" class="formdialog button2">{lang determine}</button></div>
	</form>
    </div>
<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->