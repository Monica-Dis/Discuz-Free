<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=space&do=doing">{lang doing}</a><!--{/block}-->
<!--{template common/header}-->
<!--{if !$groupsnoad || !in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{$adhome}--><!--{/if}-->
  <div class="NkGgJbO2CQdl">
  <ul>
    <li$actives[me]><a href="home.php?mod=space&do=$do&view=me">{lang doing_view_me}</a></li>
    <li$actives[we]><a href="home.php?mod=space&do=$do&view=we">{lang me_friend_doing}</a></li>    
    <li$actives[all]><a href="home.php?mod=space&do=$do&view=all">{lang view_all}</a></li>
  </ul>
  </div>
  
  <!--{if $dolist}-->
  
  <ul id="alist" class="xFfyjUHEwStA">    
    <!--{loop $dolist $dv}--> 
    <!--{eval $doid = $dv[doid];}--> 
    <!--{eval $_GET[key] = $key = random(8);}-->        
    <li class="VpWS3XqkaCFl"> 
    <a href="home.php?mod=space&uid=$dv[uid]&do=profile" class="UoRZiAghxSa8"><img src="<!--{avatar($dv[uid],middle,true)}-->" /></a>
    <div class="VJGkECAho2ek"> 
    <!--{if empty($diymode)}--><a href="home.php?mod=space&uid=$dv[uid]&do=profile">$dv[username]</a><!--{/if}--> 
    <em class="XBblg3qZXHJ1"><!--{date($dv['dateline'], 'u')}--></em>
    </div>        
    <div class="g0sF2qOc8TUw">$dv[message]</div>
    <!--{eval $list = $clist[$doid];}-->
    <!--{if empty($list) || !$showdoinglist[$doid]}--><!--{else}--><!--{template home/space_doing_li}--><!--{/if}-->
    <div class="vUZToXk9EwIO"> 
    <!--{if $_G[uid] && helper_access::check_module('doing')}--> 
    <a href="home.php?mod=spacecp&ac=doing&op=getcomment&handlekey=msg_$doid&doid=$doid&key=$key" class="F3pveqiOE331"><i class="qwZjl2muVz4e"></i></a> 
    <!--{/if}--> 
    <!--{if $dv[uid]==$_G[uid]}--> 
    <a href="home.php?mod=spacecp&ac=doing&op=delete&doid=$doid&id=$dv[id]&handlekey=doinghk_{$doid}_$dv[id]" class="F3pveqiOE331"><i class="aPyV086aHjq3"></i></a> 
    <!--{/if}--> 
    </div>
    </li>
    <!--{/loop}-->    
  </ul>  
  
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->   
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->
  
  <!--{else}-->
  
  <div class="sqK9gG26iUGb">{lang doing_no_replay}<!--{if $space[self]}-->{lang doing_now}<!--{/if}--></div>
  
  <!--{/if}-->
  
<!--{if helper_access::check_module('doing')}-->
  <div class="JFisFvnvOOmR">
  <form method="post" autocomplete="off" name="inputform" id="mood_addform" action="home.php?mod=spacecp&ac=doing&view=$_GET[view]" >    
  <table cellspacing="0" cellpadding="0">
  <tr>
  <td><input name="message" id="message" value="" autocomplete="off" class="a2YoXwq2mvgz" placeholder="{lang send_reply_fast_tip}"></td>
  <th><button type="submit" name="add" id="add" disable="true" class="iE5tROBSAh66" >{lang publish}</button></th>
  </tr>
  </table>    
  <input type="hidden" name="addsubmit" value="true" />
  <input type="hidden" name="refer" value="$theurl" />
  <input type="hidden" name="topicid" value="$topicid" />
  <input type="hidden" name="formhash" value="{FORMHASH}" />
  </form>
  <div class="iJrTjMP0vlhS"><a href="javascript:;"{if $_G[uid]} onclick="$(this).toggleClass('on'); $('#smiliesdiv').slideToggle(); $('.close_s').show();"{/if} class="CzMyTphx0KVg"></a></div>
  <!--{template home/space_smilies}-->
  </div>
  <div class="qytY6AvMLAlZ"></div>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript" >
<!--{if !$_G[uid]}-->	
$('#message').on('focus', function() {
	popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
	this.blur();			
});
$('#add').on('click', function() {
		return false;
});	
<!--{else}-->		
$('#message').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {		
		$('#add').removeClass('nopost').addClass('btnon').attr('disable', 'false');
	} else {		
		$('#add').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
	}
	$('#message').removeClass('nofocus');
	$('.close_s').show();
	});	
$('#add').on('click', function() {				
	var btobj = $(this);
	if(btobj.attr('disable') == 'true') {
		return false;
	}
	popup.open('<div class="lmVdjV39q3EP"></div>');
	$('.postsmilie').removeClass('on');
	$('#smiliesdiv').slideUp();
	});	
$('.close_s').off().on('touchstart',function(){	
	var bt2obj = $('#add');	
	if(bt2obj.attr('disable') == 'true') {
		$('#message').blur().addClass('nofocus');		
	}
	$(this).hide();
	$('.postsmilie').removeClass('on');
	$('#smiliesdiv').slideUp();	
	});	
function ismi(sl){ 
	$(".replymsg").insertAtCaret(sl); 
}
<!--{/if}-->
</script>
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->
<!--{/if}-->
<!--{block footerplus}--><div class="TyCJXL60MXvY"></div><!--{/block}-->
<!--{eval $nofooter = true;}-->         
<!--{/if}-->
<!--{template common/footer}-->