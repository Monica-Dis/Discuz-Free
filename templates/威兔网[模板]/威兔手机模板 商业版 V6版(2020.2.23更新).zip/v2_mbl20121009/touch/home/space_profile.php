<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><span class="QCOn21Tjutx4"><!--{if $_G['uid'] == $space['uid']}--><!--{if !$_GET['mycenter']}-->{lang myprofile}<!--{else}-->{lang myitem}<!--{/if}--><!--{else}-->{$space[username]}{lang otherprofile}<!--{/if}--></span><!--{/block}-->
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<style type="text/css">header { height:auto; } .header { background:none; } .header span.pg_title { opacity:0; }</style>
<!--{eval $classid = mt_rand(1,7); $onweek = date('w');}-->
<div class="{if !$_GET['mycenter']}home_data_header{else}home_header{/if}">
    <div class="home_bg r{if $tplhomebg == 8}{$onweek}{elseif $tplhomebg > 0 && $tplhomebg < 8}{$tplhomebg}{else}{$classid}{/if}">
        <div class="LOeiu0KPfYh9">
            <a href="{if $_G[uid] == $space[uid]}home.php?mod=spacecp&ac=avatar{else}home.php?mod=space&uid={$space[uid]}&do=profile{/if}" class="home_avatar{if $_G['ols'][$space[uid]] && ($_G['uid'] != $space['uid'])} oluser{/if}"><img src="{avatar($space[uid],big,true)}?{VERHASH}" /></a>
            <div class="b7aEtqhSYFOF">
                <!--{if $_G['uid'] == $space['uid']}-->
                <a href="home.php?mod=spacecp&ac=pm" class="fbSwhk2TDRmQ"><i class="QYLIQwGB8Fp4"></i></a>
                <!--{if !$_GET['mycenter']}-->
                <a href="home.php?mod=space&do=profile&mycenter=1" class="fbSwhk2TDRmQ" ><i class="RFqtGkFo5R0A"></i></a>
                <!--{else}-->
                <a href="home.php?mod=spacecp&ac=profile" class="fbSwhk2TDRmQ"><i class="cvRu1yYRBCjc"></i></a>
                <!--{/if}-->
                <!--{else}-->
                <a href="home.php?mod=spacecp&ac=pm&touid={$space[uid]}" class="home_user_i{if $_G['uid']} dialog{/if}"><i class="QYLIQwGB8Fp4"></i></a>
                <!--{if helper_access::check_module('follow')}-->
                <!--{if !ckfollow($space['uid'])}-->
                <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]" class="home_user_add{if $_G['uid']} dialog{/if}">{$langplus[follows_m]}</a>
                <!--{else}-->
                <a href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]" class="home_user_i{if $_G['uid']} dialog{/if}"><i class="UtBDyLzh8NBC"></i></a>
                <!--{/if}-->
                <!--{elseif !$isfriend}-->
                <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=addfriendhk_{$space[uid]}" class="home_user_add{if $_G['uid']} dialog{/if}">{$langplus[add_friend]}</a>
                <!--{else}-->
                <a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$space[uid]&handlekey=ignorefriendhk_{$space[uid]}" class="home_user_i{if $_G['uid']} dialog{/if}"><i class="bOxdAEo6Suri"></i></a>
                <!--{/if}-->
                <!--{/if}-->
            </div>
        </div>
        <div class="n4sgAu1nFXNV">
            <div class="usernames{if $adhomeuser} adhomerm{/if}"><span><a href="home.php?mod=space&uid={$space[uid]}&do=profile{if $_G[uid] == $space[uid]}&mycenter=1{/if}"><!--{if !$_G[uid] && !$space[uid]}-->{lang guest}<!--{else}-->{$space[username]}<!--{/if}--></a></span><i>{echo strip_tags($space[group][grouptitle])}</i><!--{if $space[group][stars] > 0}--><i>Lv.$space[group][stars]</i><!--{/if}--></div>
            <div class="home_sign{if $adhomeuser} adhomerm{/if}">
                <!--{if $space[customstatus]}-->
                <i class="0JPzjWfQFXGR"></i>{$langplus[prank]}: $space[customstatus]
                <!--{elseif $space[bio] && ($privacy[bio] == 0 || ($privacy[bio] == 1 && $isfriend) || ($_G['uid'] == $space['uid']))}-->
                <i class="4RhCk9h45cgB"></i>{$langplus[pbio]}: $space[bio]
                <!--{elseif $space[group][maxsigsize] && $space[sightml]}-->
                <!--{eval $space[sightml] = cutstr(strip_tags($space[sightml]),100);}-->
                <i class="4RhCk9h45cgB"></i>{$langplus[psig]}: $space[sightml]
                <!--{elseif $space[interest] && ($privacy[interest] == 0 || ($privacy[interest] == 1 && $isfriend) || ($_G['uid'] == $space['uid']))}-->
                <i class="UKfOChqXROBD"></i>{$langplus[phobby]}: $space[interest]
                <!--{else}-->
                <!--{if $_G['uid'] == $space['uid']}-->
                <i class="OprBhaaPnDKC"></i><a href="home.php?mod=spacecp&ac=profile&op=info">{$langplus[pwrite]}</a>
                <!--{else}-->
                <i class="ScEc2VlOnnJi"></i>{$langplus[pempty]}
                <!--{/if}-->
                <!--{/if}-->
            </div>
        </div>
    </div>
    <!--{eval $space['posts'] = $space['posts'] - $space['threads'];}-->
    <!--{if $space[threads] > 9999 }--><!--{eval $space[threads] = round($space[threads] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{if $space[posts] > 9999 }--><!--{eval $space[posts] = round($space[posts] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{if $space[doings] > 9999 }--><!--{eval $space[doings] = round($space[doings] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{if $space[blogs] > 9999 }--><!--{eval $space[blogs] = round($space[blogs] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{if $space[albums] > 9999 }--><!--{eval $space[albums] = round($space[albums] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{if $space[credits] > 9999 }--><!--{eval $space[credits] = round($space[credits] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{if helper_access::check_module('follow')}-->
    <!--{if $space['following'] > 9999 }--><!--{eval $space['following'] = round($space['following'] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{if $space['follower'] > 9999 }--><!--{eval $space['follower'] = round($space['follower'] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{else}-->
    <!--{if $space["extcredits$exskey"] > 9999 }--><!--{eval $space["extcredits$exskey"] = round($space["extcredits$exskey"] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{if $space[friends] > 9999 }--><!--{eval $space[friends] = round($space[friends] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <!--{/if}-->
    <!--{if !$_GET['mycenter']}-->
    <!--{if $adhomeuser}--><div class="nfq364lQmnTO">$adhomeuser</div><!--{/if}-->
    <div class="NkGgJbO2CQdl">
        <ul>
            <li><a href="home.php?mod=space&uid={$space[uid]}&do=thread">{lang topic}</a></li>
            <!--{if helper_access::check_module('blog')}-->
            <li><a href="home.php?mod=space&uid={$space['uid']}&do=blog&view=me">$langplus[blog]</a></li>
            <!--{else}-->
            <!--{if helper_access::check_module('follow')}-->
            <li><a href="home.php?mod=follow&uid={$space['uid']}&do=view">{lang follow}</a></li>
            <!--{/if}-->
            <!--{/if}-->
            <!--{if helper_access::check_module('album')}-->
            <li><a href="home.php?mod=space&uid={$space['uid']}&do=album&view=me">$langplus[album]</a></li>
            <!--{/if}-->
            <!--{if helper_access::check_module('wall')}-->
            <li><a href="home.php?mod=space&uid={$space['uid']}&do=wall">$langplus[wall]</a></li>
            <!--{else}-->
            <!--{if helper_access::check_module('doing')}-->
            <li><a href="home.php?mod=space&uid={$space['uid']}&do=doing&view=me">$langplus[doing]</a></li>
            <!--{/if}-->
            <!--{/if}-->
            <li class="E1x17Q9hYTmk"><a href="javascript:;">{$langplus[profile]}</a></li>
        </ul>
    </div>
    <!--{else}-->
    <!--{if $adhomeuser}--><div class="h814h7NdF8Gv">$adhomeuser</div><!--{/if}-->
    <div class="4W0Mn3qtumTY">
        <ul>
            <li><a href="home.php?mod=space&uid={$space[uid]}&do=thread"><span>$space[threads]</span><p>{$langplus[threads]}</p></a></li>
            <li><a href="home.php?mod=space&uid={$space[uid]}&do=thread&from=space&type=reply"><span>$space[posts]</span><p>{lang reply}</p></a></li>
            <!--{if helper_access::check_module('follow')}-->
            <li><a href="home.php?mod=follow&do=following&uid=$uid"><span>$space['following']</span><p>{$langplus[follows]}</p></a></li>
            <li><a href="home.php?mod=follow&do=follower&uid=$uid"><span>$space['follower']</span><p{if $_G[member][newprompt_num][follower]} class="hdcXLA8GmR6v"{/if}>{$langplus[fans]}{if $_G[member][newprompt_num][follower]} ($_G[member][newprompt_num][follower]){/if}</p></a></li>
            <!--{else}-->
            <li><a href="{if $_G[uid] == $space[uid]}home.php?mod=spacecp&ac=credit{else}javascript:;{/if}"><span>{$space["extcredits$exskey"]}</span><p>$_G['setting'][extcredits][$exskey][title]</p></a></li>
            <li><a href="{if $_G[uid] == $space[uid]}home.php?mod=space&do=friend{else}javascript:;{/if}"><span>$space[friends]</span><p>{lang friends}</p></a></li>
            <!--{/if}-->
        </ul>
    </div>
    <!--{/if}-->
</div>
<!--{hook/space_profile_top_v2_mobile}-->
<!--{if !$_GET['mycenter']}-->
<!-- userinfo start -->
<ul class="X5ViXWV51aEz">
    <li><span>{lang usergroup}</span><p>{$space[group][grouptitle]}</p></li>
    <!--{if $space[extgroupids]}-->
    <li><span>{$langplus[usergroupplus]}</span><p>$space[extgroupids]</p></li>
    <!--{/if}-->
    <!--{if $space[adminid]}-->
    <li><span>{lang management_team}</span><p>{$space[admingroup][grouptitle]}</p></li>
    <!--{/if}-->
    <!--{eval $time_start = new DateTime($space[regdate]); $time_end = new DateTime($space[lastvisit]); $daylength = $time_start -> diff($time_end) -> days; $olyear = round($daylength / 365.24 , 1).' '.$langplus[years]; }-->
    <li><span>{$langplus[webage]}</span><p><!--{if $daylength < 60}-->$daylength {$langplus[days]}<!--{elseif $daylength < 182.62}-->{$langplus[lesshalfyear]}<!--{elseif $daylength < 365.24}-->{$langplus[lessyear]}<!--{else}-->{$olyear}<!--{/if}--></p></li>
    <!--{if $space[customstatus]}-->
    <li><span>{$langplus[prank]}</span><p>$space[customstatus]</p></li>
    <!--{elseif $space[group][maxsigsize] && $space[sightml]}-->
    <!--{eval $space[sightml] = cutstr(strip_tags($space[sightml]),100);}-->
    <li><span>{$langplus[psig]}</span><p>$space[sightml]</p></li>
    <!--{/if}-->
</ul>
<ul class="kYUEQN6hmjsl">
    <li><a href="home.php?mod=space&uid={$space[uid]}&do=thread"><i class="4RhCk9h45cgB"></i><p>{lang topic} $space[threads]</p></a></li>
    <li><a href="home.php?mod=space&uid={$space[uid]}&do=thread&from=space&type=reply"><i class="OprBhaaPnDKC"></i><p>{lang reply} $space[posts]</p></a></li>
    <!--{if helper_access::check_module('follow')}-->
    <li><a href="home.php?mod=follow&do=follower&uid=$uid"><i class="Wh21Y2pBzti3"></i><p>{$langplus[fans]} $space['follower']</p></a></li>
    <!--{/if}-->
    <li><a href="{if $_G[uid] == $space[uid]}home.php?mod=space&do=friend{else}javascript:;{/if}"><i class="4dh7igKfkLwN"></i><p>{lang friends} $space[friends]</p></a></li>
    <li><a href="home.php?mod=space&uid={$space['uid']}&do=doing&view=me"><i class="Ph83pYTFaoF0"></i><p>{lang doing} $space[doings]</p></a></li>
    <li><a href="home.php?mod=space&uid={$space['uid']}&do=blog&view=me"><i class="bSQGADt3u2Sf"></i><p>{lang blog} $space[blogs]</p></a></li>
    <li><a href="home.php?mod=space&uid={$space['uid']}&do=album&view=me"><i class="f4kVb2vxGm4b"></i><p>{lang album} $space[albums]</p></a></li>
    <li><i class="ih2GBIpmzu4I"></i><p>{lang credits} $space[credits]</p></li>
</ul>
<!--{if $_G[setting][extcredits]}-->
<ul class="SpKtYiEEz2Vh">
    <!--{loop $_G[setting][extcredits] $key $value}-->
    <!--{if $value[title]}-->
    <li><span>$value[title]</span><p>{$space["extcredits$key"]}</p></li>
    <!--{/if}-->
    <!--{/loop}-->
</ul>
<!--{/if}-->
<ul class="SpKtYiEEz2Vh">
    <li><span>{lang users}ID</span><p>{$space[uid]}</p></li>
    <!--{if $profiles}-->
    <!--{loop $profiles $value}-->
    <li><span>$value[title]</span><p>$value[value]</p></li>
    <!--{/loop}-->
    <!--{/if}-->
    <!--{if in_array($_G[adminid], array(1, 2))}--><li><span>Email</span><p>$space[email]</p></li><!--{/if}-->
    <!--{if $space['medals']}-->
    <li>
        <span>{$langplus[honor]}{lang medals}</span>
        <a href="home.php?mod=medal" class="4dtWnhtPxSPV">
            <!--{loop $space['medals'] $medal}-->
            <img src="{STATICURL}/image/common/$medal[image]" alt="$medal[name]" />
            <!--{/loop}-->
        </a>
    </li>
    <!--{/if}-->
</ul>
<ul class="5lNtbBaA0eDu">
    <li><span>{lang online_time}</span><p>$space[oltime] {lang hours}</p></li>
    <li><span>{lang regdate}</span><p>$space[regdate]</p></li>
    <li><span>{lang last_visit}</span><p>$space[lastvisit]</p></li>
    <li><span>{lang time_offset}</span><!--{eval $timeoffset = array({lang timezone});}--><p>$timeoffset[$space[timeoffset]]</p></li>
    <!--{if $_G[uid] == $space[uid] || $_G[group][allowviewip]}-->
    <li><span>{lang register_ip}</span><p>$space[regip] $space[regip_loc]</p></li>
    <li><span>{lang last_visit_ip}</span><p>$space[lastip] $space[lastip_loc]</p></li>
    <!--{/if}-->
</ul>
<!-- userinfo end -->
<!--{else}-->
<!--{if $_G['uid'] != $space['uid']}--><!--{eval dheader("location: home.php?mod=space&uid=".$space['uid']."&do=profile");exit; }--><!--{/if}-->
<!--{if $_G['uid']}-->
<div class="Aw18g4mEJrsq">
    <ul class="ETnWzVbo7rOY">
        <li><a href="home.php?mod=space&do=pm"><i class="QYLIQwGB8Fp4"></i><!--{if $_G[member][newpm] || $smscheck}--><span class="hdcXLA8GmR6v">{lang new_pm}</span><!--{else}--><span>{lang pm_center}</span><!--{/if}--></a></li>
        <li><a href="home.php?mod=space&do=notice"><i class="6GTlsiFWNbVn"></i><!--{if $_G[member][newprompt]}--><span class="hdcXLA8GmR6v">{lang remind} ($_G[member][newprompt])</span><!--{else}--><span>{lang remind}</span><!--{/if}--></a></li>
        <!--{if helper_access::check_module('follow')}--><li><a href="home.php?mod=follow"><i class="DiTtoZblEjtV"></i><!--{if $_G[member][newprompt] && $_G[member][newprompt_num][follow]}--><span class="hdcXLA8GmR6v">{lang notice_interactive_follow}</span><!--{else}--><span>{lang follow}</span><!--{/if}--></a></li><!--{/if}-->
        <!--{if helper_access::check_module('feed')}--><li><a href="home.php"><i class="EqR5fdlr3NL9"></i><span>$langplus[feed]</span></a></li><!--{/if}-->
        <li><a href="home.php?mod=space&do=friend"><i class="4dh7igKfkLwN"></i><span>{lang friends}</span></a></li>
        <!--{if helper_access::check_module('wall')}--><li><a href="home.php?mod=space&do=wall"><i class="45WWqTGm8s7n"></i><span>$langplus[wall]</span></a></li><!--{/if}-->
        <!--{if helper_access::check_module('doing')}--><li><a href="home.php?mod=space&do=doing"><i class="Ph83pYTFaoF0"></i><span>$langplus[doing]</span></a></li><!--{/if}-->
        <!--{if helper_access::check_module('blog')}--><li><a href="home.php?mod=space&do=blog&view=me"><i class="bSQGADt3u2Sf"></i><span>$langplus[blog]</span></a></li><!--{/if}-->
        <!--{if helper_access::check_module('album')}--><li><a href="home.php?mod=space&do=album&view=all"><i class="f4kVb2vxGm4b"></i><span>$langplus[album]</span></a></li><!--{/if}-->
        <li><a href="home.php?mod=medal"><i class="Or9qTJAQDtSB"></i><span>$langplus[medal]</span></a></li>
        <li><a href="home.php?mod=magic"><i class="KzNrSpvHgQpu"></i><span>{lang magic}</span></a></li>
        <li><a href="home.php?mod=task"><i class="vQly23P9NssB"></i><!--{if $_G['setting']['taskon'] && !empty($_G['cookie']['taskdoing_'.$_G['uid']])}--><span class="hdcXLA8GmR6v">{lang task}{$langplus[taskdoing]}</span><!--{else}--><span>{lang task}</span><!--{/if}--></a></li>
    </ul>
    <ul class="7V0aj6bIRtYR" id="my_setup">
        <li><a href="home.php?mod=space&do=thread"><i class="4RhCk9h45cgB"></i><span>{lang mythread}</span></p></a></li>
        <li><a href="home.php?mod=space&do=favorite&type=all"><i class="c5jXKWHqTOsX"></i><span>{lang myfavorite}</span></a></li>
        <li><a href="home.php?mod=space&uid={$_G['uid']}&do=profile"><i class="DVFRJBFhZRzt"></i><span>{lang myprofile}</span></a></li>
        <li><a href="home.php?mod=spacecp&ac=avatar"><i class="D1Oavwz2DWxV"></i><span>{$langplus[up_avatar]}</span></a></li>
        <li><a href="home.php?mod=spacecp&ac=profile&op=password"><i class="UsNpnIjeRxzc"></i><span>{$langplus[psw_security]}</span></a></li>
        <li><a href="home.php?mod=spacecp&ac=profile"><i class="cvRu1yYRBCjc"></i><span>{$langplus[my_userprofile]}</span></a></li>
        <li><a href="home.php?mod=spacecp&ac=privacy"><i class="c38yXjPvFapr"></i><span>{lang privacy_settings}</span></a></li>
        <li><a href="home.php?mod=spacecp&ac=credit"><i class="ih2GBIpmzu4I"></i><span>{lang memcp_credit}</span></a></li>
        <li><a href="home.php?mod=spacecp&ac=usergroup"><i class="WXPBKrFwyOJQ"></i><span>{lang memcp_usergroup}</span></a></li>
        <!--{if $space[buyercredit] || $space[sellercredit] || $_G['uid'] == $space['uid']}--><li><a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit" ><i class="Qfw6Zge9pQz5"></i><span>{lang credit_rating}</span></a></li><!--{/if}-->
        <!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}--><li><a href="home.php?mod=spacecp&ac=promotion"><i class="oALnb3pstEtP"></i><span>{lang memcp_promotion}</span></a></li><!--{/if}-->
    </ul>
    <ul>
        <li><a href="{$_G['setting']['mobile']['nomobileurl']}"><i class="Fu6oH3m7wUDV"></i><span>{lang nomobiletype}</span></a></li>
        <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="F3pveqiOE331"><i class="9UKRwJk1d3f8"></i><span>{lang logout}</span></a></li>
    </ul>
</div>
<!--{elseif $_G['connectguest']}-->
<div class="Aw18g4mEJrsq">
    <ul>
        <!--{if $_G['connectguest']}-->
        <li><a href="member.php?mod=connect&mobile=no"><i class="aMPfU5i6fv85"></i><span>{lang qqconnect:connect_register_profile}</span></a></li>
        <li><a href="member.php?mod=connect&ac=bind&mobile=no"><i class="aMPfU5i6fv85"></i><span>{lang qqconnect:connect_register_bind}</span></a></li>
        <!--{/if}-->
        <li><a href="{$_G['setting']['mobile']['nomobileurl']}"><i class="Fu6oH3m7wUDV"></i><span>{lang nomobiletype}</span></a></li>
        <li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="F3pveqiOE331"><i class="9UKRwJk1d3f8"></i><span>{lang logout}</span></a></li>
    </ul>
</div>
<!--{/if}-->
<!--{/if}-->
<!--{if $headershow}-->
<script type="text/javascript">
    $(window).scroll(function(){
        var hexvalue = '{$tplcolorcssa}';
        var rgx = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
        var hex = hexvalue.replace(rgx, (m, r, g, b) => r + r + g + g + b + b );
        var rgb = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        var r = parseInt(rgb[1], 16);
        var g = parseInt(rgb[2], 16);
        var b = parseInt(rgb[3], 16);
        var a = $(window).scrollTop() / 150;
        if(a < '1'){
            $(".header").attr("style","background-color: rgba("+r+","+g+","+b+","+a+") !important;");
            $(".pg_title").attr("style","opacity:"+a+";");
        }else{
            $(".header").attr("style","background-color: rgba("+r+","+g+","+b+",1) !important;");
            $(".pg_title").attr("style","opacity:1;");
        }
    })
</script>
<!--{/if}-->
<!--{if $_G[uid]}--><!--{$formsdialog_item}--><!--{/if}-->
<!--{if $_G['group']['allowbanuser']}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="forum.php?mod=modcp&action=member&op=ban&uid={$space[uid]}" class="EPSs1wRRyPfK"></a></div>
<!--{/block}-->
<!--{/if}-->
<!--{if $_G['uid'] != $space['uid']}-->
<!--{block bottombutton}-->
<ul>
    <li><a href="home.php?mod=spacecp&ac=pm&touid={$space[uid]}"{if $_G['uid']} class="F3pveqiOE331"{/if}><i class="iqTKlHsxxxPS"></i>{lang send_pm}</a></li>
    <!--{if !$isfriend}-->
    <li><a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=addfriendhk_{$space[uid]}"{if $_G['uid']} class="F3pveqiOE331"{/if}><i class="XRVIYXqQqt8X"></i>{$langplus[add_friend]}</a></li>
    <!--{else}-->
    <li><a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$space[uid]&handlekey=ignorefriendhk_{$space[uid]}"{if $_G['uid']} class="F3pveqiOE331"{/if}><i class="afmMu2l1G7mJ"></i>{$langplus[ignore_friend]}</a></li>
    <!--{/if}-->
    <!--{if helper_access::check_module('follow')}-->
    <!--{if !ckfollow($space['uid'])}-->
    <li><a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"{if $_G['uid']} class="F3pveqiOE331"{/if}><i class="0mw4N2h70EqF"></i>{$langplus[follows_m]}</a></li>
    <!--{else}-->
    <li><a href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]"{if $_G['uid']} class="F3pveqiOE331"{/if}><i class="UtBDyLzh8NBC"></i>{$langplus[nofollows]}</a></li>
    <!--{/if}-->
    <!--{/if}-->
    <li>
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
        <a href="member.php?mod=logging&action=login"><i class="0iHKtK6RqXLZ"></i>{lang login}</a>
        <!--{else}-->
        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="0iHKtK6RqXLZ"></i>$langplus[me]</a>
        <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="Iug1I7rXnrOf"></i><!--{/if}-->
        <!--{/if}-->
    </li>
</ul>
<!--{/block}-->
<!--{/if}-->

<!--{template common/footer}-->