<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_title}--><!--{if $_GET['op'] == 'edit'}-->{lang edit}<!--{elseif $_GET['op'] == 'delete'}-->{lang delete_reply}<!--{elseif $_GET['op'] == 'reply'}-->{lang reply}<!--{/if}--><!--{/block}-->
<!--{block header_name}--><!--{if $_GET['op'] == 'edit'}-->{lang edit}<!--{elseif $_GET['op'] == 'delete'}-->{lang delete_reply}<!--{elseif $_GET['op'] == 'reply'}-->{lang reply}<!--{/if}--><!--{/block}-->
<!--{template common/header}-->
<!--{if $_GET['op'] == 'edit'}-->    
	<form id="editcommentform_{$cid}" name="editcommentform_{$cid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment&op=edit&cid=$cid{if $_GET[modcommentkey]}&modcommentkey=$_GET[modcommentkey]{/if}" >
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="inputall bw">        
        <textarea id="message_{$cid}" name="message" rows="10" class="inserts" placeholder="{lang thread_content}" >$comment[message]</textarea>        
        </div>    
    <div class="ftpost">
    <table cellspacing="0" cellpadding="0">
        <tr>
        <td>
            <div class="editor">
            <a href="javascript:;"{if $_G[uid]} onclick="$(this).toggleClass('on'); $('#smiliesdiv').slideToggle();"{/if} class="postsmilie"></a>          
            </div>
        </td>
        <th>
        <button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="formdialog ftbtn nopost" disable="true">{lang submit}</button>
        </th>
        </tr>
    </table>
    <!--{template home/space_smilies}-->
    </div>        	
	</form>
<!--{block footerplus}--><div class="ftbox"></div><!--{/block}-->    
<script type="text/javascript">
$('#message_{$cid}').on('keyup input focus', function() {
		var obj = $(this);
		if(obj.val()) {
			$('#editsubmit_btn').removeClass('nopost').addClass('btnon');
			$('#editsubmit_btn').attr('disable', 'false');
		} else {
			$('#editsubmit_btn').removeClass('btnon').addClass('nopost');
			$('#editsubmit_btn').attr('disable', 'true');
		}
});

$('#message_{$cid}').on('input focus', function(){
	$(this).css('height','auto');
	$(this).css('height',this.scrollHeight + 2); 
});

$('.postsmilie').click(function(){
    $('.ftbox').toggleClass("keyht2");
});

$('#editsubmit_btn').on('click', function() {			
	var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}
});
</script>

<!--{elseif $_GET['op'] == 'delete'}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if}">
	<form id="deletecommentform_{$cid}" name="deletecommentform_{$cid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment&op=delete&cid=$cid">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="r-block">{lang delete_reply_message}</div>
		<div class="hm"><button type="submit" name="deletesubmitbtn" value="true" class="formdialog button2">{lang determine}</button></div>
	</form>
</div>
<!--{elseif $_GET['op'] == 'reply'}-->
<!--{if $_G['inajax']}-->
	<div class="bw ajaxpop">
    <form id="replycommentform_{$comment[cid]}" name="replycommentform_{$comment[cid]}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment" >
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="id" value="$comment[id]" />
		<input type="hidden" name="idtype" value="$comment[idtype]" />
		<input type="hidden" name="cid" value="$comment[cid]" />
		<input type="hidden" name="commentsubmit" value="true" />
		<input type="hidden" name="handlekey" value="$_GET[handlekey]" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />	
    <div class="reply_comment">			
		<textarea id="message_pop_{$comment[cid]}" name="message" rows="4" class="inserts" placeholder="{lang thread_content}" ></textarea>
		<!--{if $secqaacheck || $seccodecheck}-->
		<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
    </div>
    <!--{template home/space_smilies}-->
    <div class="hm btye"><button type="submit" name="commentsubmit_btns" id="commentsubmit_btn" value="true" class="formdialog button2">{lang reply}</button></div>
	</form>
    </div>    
<!--{else}-->
	<div class="bw">
    <form id="replycommentform_{$comment[cid]}" name="replycommentform_{$comment[cid]}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment" >
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="id" value="$comment[id]" />
		<input type="hidden" name="idtype" value="$comment[idtype]" />
		<input type="hidden" name="cid" value="$comment[cid]" />
		<input type="hidden" name="commentsubmit" value="true" />		
		<input type="hidden" name="formhash" value="{FORMHASH}" />	
		<div class="inputall">			
		<textarea id="message_pop_{$comment[cid]}" name="message" rows="10" class="inserts{if $secqaacheck || $seccodecheck} mbm{/if}" placeholder="{lang thread_content}" ></textarea>
		<!--{if $secqaacheck || $seccodecheck}-->
        <!--{subtemplate common/seccheck}-->
		<!--{/if}-->
        </div>    
    <div class="ftpost">
    <table cellspacing="0" cellpadding="0">
        <tr>
        <td>
            <div class="editor">
            <a href="javascript:;"{if $_G[uid]} onclick="$(this).toggleClass('on'); $('#smiliesdiv').slideToggle();"{/if} class="postsmilie"></a>          
            </div>
        </td>
        <th><button type="submit" name="commentsubmit_btns" id="commentsubmit_btn" value="true" class="formdialog ftbtn nopost" disable="true">{lang reply}</button></th>
        </tr>
    </table>
    <!--{template home/space_smilies}-->
    </div>    
	</form>
    </div>
    <!--{block footerplus}--><div class="ftbox"></div><!--{/block}-->    
<script type="text/javascript">
<!--{if $secqaacheck || $seccodecheck}-->
var message_pop_{$comment[cid]} = sectxt = false;
<!--{/if}-->
$('#message_pop_{$comment[cid]}').on('keyup input focus', function() {
		var obj = $(this);
		if(obj.val()) {
			<!--{if $secqaacheck || $seccodecheck}-->
			message_pop_{$comment[cid]} = true;
			if(sectxt == true) {	
			$('#commentsubmit_btn').removeClass('nopost').addClass('btnon');
			$('#commentsubmit_btn').attr('disable', 'false');
			}
			<!--{else}-->
			$('#commentsubmit_btn').removeClass('nopost').addClass('btnon');
			$('#commentsubmit_btn').attr('disable', 'false');
			<!--{/if}-->
		} else {
			<!--{if $secqaacheck || $seccodecheck}-->
			message_pop_{$comment[cid]} = false;
			<!--{/if}-->
			$('#commentsubmit_btn').removeClass('btnon').addClass('nopost');
			$('#commentsubmit_btn').attr('disable', 'true');
		}
});
<!--{if $secqaacheck || $seccodecheck}-->
$('.sectxt').on('keyup input', function() {
		var obj = $(this);
		if(obj.val()) {
			sectxt = true;	
			if(message_pop_{$comment[cid]} == true) {
			$('#commentsubmit_btn').removeClass('nopost').addClass('btnon');
			$('#commentsubmit_btn').attr('disable', 'false');			
			}
		} else {
			sectxt = false;
			$('#commentsubmit_btn').removeClass('btnon').addClass('nopost');
			$('#commentsubmit_btn').attr('disable', 'true');	
		}
});	
<!--{/if}-->
$('#commentsubmit_btn').on('click', function() {			
	var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}
});

$('#message_pop_{$comment[cid]}').on('input focus', function(){
	$(this).css('height','auto');
	$(this).css('height',this.scrollHeight + 2); 
});

$('.postsmilie').click(function(){
    $('.ftbox').toggleClass("keyht2");
});
</script> 
<!--{/if}-->    
<!--{/if}-->
<!--{if $_GET['op'] == 'edit' || $_GET['op'] == 'reply'}--> 
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript" >
function ismi(sl) {
	$(".inserts").insertAtCaret(sl);
}
</script>  
<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->