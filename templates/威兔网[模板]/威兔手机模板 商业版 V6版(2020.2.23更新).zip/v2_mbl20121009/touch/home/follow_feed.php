<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=follow">{lang follow}</a><!--{/block}--> 
<!--{template common/header}-->
<!--{if in_array($do, array('feed', 'view'))}-->
<!--{if !$groupsnoad || !in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{$adhome}--><!--{/if}-->
<div class="NkGgJbO2CQdl">
  <ul>
    <!--{if $_GET['do'] == 'view'}-->
    <li class="E1x17Q9hYTmk"><a href="home.php?mod=follow&uid={$uid}&do=view&from=space"><!--{if $_GET['do'] && $_G['uid'] != $uid}-->TA{lang eccredit_s}<!--{/if}-->{lang follow}</a></li>
    <li><a href="home.php?mod=follow&do=following&uid=$uid"><!--{if $_GET['do'] && $_G['uid'] != $uid}-->TA{lang eccredit_s}<!--{/if}-->{$langplus[follows]}</a></li>
    <li><a href="home.php?mod=follow&do=follower&uid=$uid"><!--{if $_GET['do'] && $_G['uid'] != $uid}-->TA{lang eccredit_s}<!--{/if}-->{$langplus[fans]}</a></li>
    <!--{else}-->
    <li$actives[follow]><a href="home.php?mod=follow&view=follow">{lang invite_my_follow}</a></li>
    <li$actives[special]><a href="home.php?mod=follow&view=special">{$langplus[followsspecial]}</a></li>
    <li$actives[other]><a href="home.php?mod=follow&view=other">{lang view_all}</a></li>
    <!--{/if}-->
  </ul>
</div>

  <!--{if in_array($do, array('feed', 'view'))}-->
  <!--{if !empty($list['feed'])}-->
  <!--{hook/follow_top_v2_mobile}-->
  <!--{template home/follow_feed_li}-->
  <!--{if count($list['feed']) > 19 && ($archiver || $primary)}--> 
  <!--{eval $totalpage = ceil(1000 / $perpage);}-->
  <!--{if $totalpage > $page}--> 
  <a href="home.php?mod=spacecp&ac=follow&op=getfeed&archiver=0&{if $do == 'feed'}viewtype={$view}{elseif $do == 'view'}uid={$uid}&banavatar=1{/if}" id="archiver0" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}" disable="true"><span>$langplus[more]</span></a>
  <a href="home.php?mod=spacecp&ac=follow&op=getfeed&archiver=1&{if $do == 'feed'}viewtype={$view}{elseif $do == 'view'}uid={$uid}&banavatar=1{/if}" id="archiver1" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}" style="display:none;"><span>$langplus[more]</span></a>
  <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage_follow.js?{VERHASH}"></script>  
  <!--{/if}--> 
  <!--{/if}-->
  <!--{else}-->
  <div class="sqK9gG26iUGb">
  <!--{if $viewself}-->{lang follow_following_null}<!--{else}-->{lang follow_no_content}<!--{/if}-->
  <!--{if $do == 'feed' && $view == 'special'}-->
  <p>{lang follow_add_special_tip}<a href="home.php?mod=follow&do=following&uid=$uid">{lang follow_add_special_following}</a></p>
  <!--{/if}--> 
  </div>
  <!--{/if}-->
      <div class="JFisFvnvOOmR">
         <table cellspacing="0" cellpadding="0">
         <tr> 
         <td><div class="M2U4eCIf3Lce">{lang send_reply_fast_tip}</div></td>
         <th><div class="iE5tROBSAh66">{lang publish}</div></th>
         </tr>
         </table>         
      </div>
      <div class="o7XBIO2AbIOX">
      <!--{eval $dmfid = $_G['setting']['followforumid'] && !empty($defaultforum) ? $_G['setting']['followforumid'] : 0;}-->
      <form method="post" autocomplete="off" id="fastpostform" name="fastpostform" action="home.php?mod=spacecp&ac=follow&op=newthread" >
      <ul class="70RMxsdq69z2">
      <li{if $secqaacheck || $seccodecheck} class="7V0aj6bIRtYR"{/if}><textarea name="message" id="fastpostmessage" rows="3" placeholder="{lang send_reply_fast_tip}"></textarea></li>
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <input type="hidden" name="usesig" value="$usesigcheck" />
      <input type="hidden" name="adddynamic" value="1" />
      <input type="hidden" name="addfeed" value="1" />
      <input type="hidden" name="topicsubmit" value="true" />
      <input type="hidden" name="referer" value="{echo dreferer()}" />
      <!--{if $secqaacheck || $seccodecheck}-->
      <li class="AVK4ckDbUu5b"><!--{subtemplate common/seccheck}--></li>
      <!--{/if}--> 
      </ul>    
      <div class="JFisFvnvOOmR">
      <table cellspacing="0" cellpadding="0">
        <tr>
        <td>
		<div class="6Ow6ulKMHLqn">
		<a href="javascript:;" class="RNA6cfDIyWwZ"></a>
        <a href="javascript:;" class="{if $_G['group']['allowat'] > 0}cutoption{else}inlink{/if} editortab"></a>
		<a href="javascript:;" class="8ZEzUDmgfRGH"></a>		
		</div>
        </td>
        <th><button type="submit" name="topicsubmit_btn" id="fastpostsubmit" value="topicsubmitbtn" tabindex="13" class="iE5tROBSAh66" disable="true">{lang publish}</button></th>
        </tr>
      </table>      
		<div class="llLJ43IWYvyD">            
		<div class="22QH8w7MKUZo">
		<div class="3LAI9IVO8Vpr">
        <i class="9EAJdkchBJVA"></i>
		<input type="text" name="img_link" id="img_link" autocomplete="off" placeholder="{$langplus[img_link]}" />
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_0())">{$langplus[insert]}</span>
		</div>
		</div>
		<div class="22QH8w7MKUZo">
		<div class="3LAI9IVO8Vpr">
        <i class="9EAJdkchBJVA"></i>
        <div class="oGYuEZ1uz6pO"><input type="text" name="links_link" id="links_link" autocomplete="off" placeholder="{$langplus[links_link]}" /></div>
        <div class="oGYuEZ1uz6pO"><input type="text" name="linkname_link" id="linkname_link" autocomplete="off" placeholder="{$langplus[linkname_link]}" /></div>
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_1())">{$langplus[insert]}</span>
		</div>
        <!--{if $_G['group']['allowat'] > 0}-->
		<div class="3LAI9IVO8Vpr">
        <i class="27IgHd5nBrvs"></i>
		<input type="text" name="iat_name" id="iat_name" autocomplete="off" placeholder="{$langplus[iat]}" />
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_2())">{$langplus[insert]}</span>
		</div>
        <!--{/if}-->
        </div>		
		<div id="smiliesdiv" class="22QH8w7MKUZo"><div id="fastsmilies"></div></div>
		</div>
      </div>       
      </form>
      </div>
      <div class="3BpUTDuPIV3L"></div>
<!--{if $_G[uid]}-->      
<script type="text/javascript">
	$(document).ready(function() {
	$('.editordefault a.editortab').click(function(){
		$('.editordefault a').eq($(this).index()).toggleClass('on').siblings().removeClass('on');
		$('.hidebox').eq($(".editordefault a.editortab").index(this)).slideToggle().siblings().slideUp();
	});	
	});		
	function ins_code_0(){
		var newvalue = $("#img_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#img_link").val("");
			editorclose();
			return "[img]"+ newvalue +"[/img]";
		}else{
			return "";
		}
	}	
	function ins_code_1(){
		var newvalue = $("#links_link").val();
		var newvalue2 = $("#linkname_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		newvalue2 = newvalue2.replace(/^\s+|\s+$/g,"");
		if(!newvalue2) {
			newvalue2 = newvalue;
		}
		if (newvalue) {
			$("#links_link").val("");
			$("#linkname_link").val("");
			editorclose();
			return "[url="+ newvalue +"]"+ newvalue2 +"[/url]";
		}else{
			return "";
		}
	}
	<!--{if $_G['group']['allowat'] > 0}-->
	function ins_code_2(){
		var newvalue = $("#iat_name").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#iat_name").val("");
			editorclose();
			return "@"+ newvalue +" ";
		}else{
			return "";
		}
	}
	<!--{/if}-->
	function editorclose(){		
		$('.editordefault a').removeClass('on');
		$('.hidebox').slideUp();		
	}	
</script>
<!--{/if}-->
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript" src="data/cache/common_smilies_var.js?eAa"></script>
<script type="text/javascript">
function ilink(lk){$('#fastpostmessage').insertAtCaret(lk);}
function ismi(sl){$('#fastpostmessage').insertAtCaret(sl);}
var j = 1, smilies_fastdata = '', img;
if (smilies_array[{$smileid}][{$smilepg}].length > {$smilenumber}){smilienums = {$smilenumber};}else{smilienums = smilies_array[{$smileid}][{$smilepg}].length;}
for (i = 0; i < smilienums; i++) {	
	s = smilies_array[{$smileid}][{$smilepg}][i];	
    smilieimg = "static/" + 'image/smiley/' + smilies_type['_' + {$smileid}][1] + '/' + s[2];
    smilies_fastdata += s ? '<li><img src="' + smilieimg + '" onclick="ismi(\'' + s[1].replace(/'/, '\\\'') + '\')" />' : '</li>';
}
window.onload = function() {
    $('#fastsmilies').html('<div class="saMZOV8357GQ"><ul>' + smilies_fastdata + '</ul></div>');
}

	$('.falsesmi').click(function(){
		$('.postbox').slideToggle();
		$('.close_p').delay(300).fadeIn();
	}); 
		
	$('.close_p').click(function(){	
		$('.postbox').slideToggle();
		$(this).hide();		
		$('.hidebox').slideUp();	
		$('.editordefault a').removeClass('on');
	}); 

	(function() {
		var form = $('#fastpostform');
		<!--{if $secqaacheck || $seccodecheck}-->
		var fastpostmessage = sectxt = false;
		<!--{else}-->
		var fastpostmessage = false;
		<!--{/if}-->		
		$('#fastpostmessage').on('keyup input focus', function() {
			var obj = $(this);
			if(obj.val()) {
				fastpostmessage = true;	
				<!--{if $secqaacheck || $seccodecheck}-->
				if(sectxt == true) {
					$('#fastpostsubmit').removeClass('nopost').addClass('btnon').attr('disable', 'false');					
				}
				<!--{else}-->
				$('#fastpostsubmit').removeClass('nopost').addClass('btnon').attr('disable', 'false');
				<!--{/if}-->
			} else {
				fastpostmessage = false;
				$('#fastpostsubmit').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
			}
		});		
		<!--{if $secqaacheck || $seccodecheck}-->
		$('.sectxt').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				sectxt = true;	
				if(fastpostmessage == true) {
					$('#fastpostsubmit').removeClass('nopost').addClass('btnon').attr('disable', 'false');					
				}
			} else {
				sectxt = false;
				$('#fastpostsubmit').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
			}
		});	
		<!--{/if}-->
		$('#fastpostsubmit').on('click', function() {	
		var btobj = $(this);
		if(btobj.attr('disable') == 'true') { 
			return false;
		}		
			popup.open('<div class="lmVdjV39q3EP"></div>');
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey='+ form.attr('id') +'&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});							
			return false;
		});				
	})();
</script> 
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->  
<!--{/if}-->
<!--{block footerplus}--><div class="TyCJXL60MXvY"></div><!--{/block}-->
<!--{eval $nofooter = true;}-->   
    
  <!--{/if}-->
  
  <!--{elseif in_array($do, array('following', 'follower'))}--> 

<div class="NkGgJbO2CQdl">
  <ul>
    <li><a href="home.php?mod=follow&uid={$uid}&do=view&from=space"><!--{if $_GET['do'] && $_G['uid'] != $uid}-->TA{lang eccredit_s}<!--{/if}-->{lang follow}</a></li>
    <li{if $_GET['do'] == 'following'} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=follow&do=following&uid=$uid"><!--{if $_GET['do'] && $_G['uid'] != $uid}-->TA{lang eccredit_s}<!--{/if}-->{$langplus[follows]}</a></li>
    <li{if $_GET['do'] == 'follower'} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=follow&do=follower&uid=$uid"><!--{if $_GET['do'] && $_G['uid'] != $uid}-->TA{lang eccredit_s}<!--{/if}-->{$langplus[fans]}</a></li>
  </ul>
</div>
    
  <!--{if $list}--> 
  <ul id="alist" class="pagelist friend{if $do=='follower' || $_G['uid'] != $space['uid']} follower_m{/if}">    
    <!--{loop $list $fuid $fuser}-->
    <li>
      <!--{if $do=='following'}-->      
      <div class="dZ8IOlQN3qsv" id="locker_$fuser['followuid']">
      <!--{if helper_access::check_module('follow')}--><!--{if $fuser[followuid] != $_G[uid]}--><span class="glUaRWZE0PuJ"><i class="l9iUBObiUnzT"></i></span><!--{/if}--><!--{/if}-->
      <a href="home.php?mod=space&uid=$fuser['followuid']&do=profile" class="En13SLg8vfTK"><!--{avatar($fuser['followuid'],middle)}--></a> 
      <h1>
      <a href="home.php?mod=space&uid=$fuser['followuid']&do=profile">$fuser['fusername']</a>
      <!--{if $fuser[followuid] != $_G[uid]}-->            
      <!--{if $fuser['mutual']}-->      
      <!--{if $fuser['mutual'] > 0}-->
      <span class="1b1VfV2YpEg2">{lang follow_follower_mutual}</span>
      <!--{else}-->
      <span class="1b1VfV2YpEg2">{$langplus[notfollowyou]}</span>
      <!--{/if}--> 
      <!--{/if}-->          
      <!--{/if}-->      
      </h1>
      <!--{if $fuser['bkname']}-->
      <p><span class="PijfGiLxri7h">$fuser[bkname]</span></p>
      <!--{else}-->
      <!--{if $fuser[recentnote]}--><p>$fuser[recentnote]</p><!--{/if}-->
      <!--{/if}-->
      <!--{if helper_access::check_module('follow')}-->
      <!--{if $fuser[followuid] != $_G[uid]}-->
      <div class="FQgd2kpZkKVq">
      <ul>
      <!--{if $viewself}--> 
      <li class="EuquFWEp2nsn"><a href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['followuid']" class="F3pveqiOE331">{$langplus[nofollows_m]}</a></li> 
      <!--{elseif $fuser[followuid] != $_G[uid]}--> 
      <!--{if $fuser['mutual']}-->           
      <li class="EuquFWEp2nsn"><a href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['followuid']" class="F3pveqiOE331">{$langplus[nofollows_m]}</a></li>
      <!--{elseif helper_access::check_module('follow')}--> 
      <li class="NZ57IYxR5FcU"><a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['followuid']" class="F3pveqiOE331">{$langplus[follows]}</a></li>
      <!--{/if}-->          
      <!--{/if}-->      
      <!--{if $viewself && $fuser[followuid] != $_G[uid]}-->
      <li class="IaHQNi6rZvJx"><a href="home.php?mod=spacecp&ac=follow&op=bkname&fuid=$fuser['followuid']&handlekey=followbkame_$fuser['followuid']" class="F3pveqiOE331">{lang friend_editnote}</a></li> 
      <!--{if helper_access::check_module('follow')}--> 
      <li class="{if $fuser['status'] == 1}frienddel{else}addfollow{/if}"><a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&special={if $fuser['status'] == 1}2{else}1{/if}&fuid=$fuser['followuid']" class="F3pveqiOE331"><!--{if $fuser['status'] == 1}-->{$langplus[delspecial]}<!--{else}-->{$langplus[followsspecial]}<!--{/if}--></a></li> 
      <!--{/if}--> 
      <!--{/if}--> 
      </ul>
      </div>      
      <div class="zgSirvDkTeGo" id="lockerclose_$fuser['followuid']"></div>
      <!--{/if}-->
      <!--{/if}-->
      </div>           
      <!--{else}-->      
      <div class="dZ8IOlQN3qsv" id="locker_$fuser['uid']">
      <!--{if helper_access::check_module('follow')}--><!--{if $fuser[uid] != $_G[uid]}--><span class="glUaRWZE0PuJ"><i class="l9iUBObiUnzT"></i></span><!--{/if}--><!--{/if}-->
      <a href="home.php?mod=space&uid=$fuser['uid']&do=profile" class="En13SLg8vfTK" ><!--{avatar($fuser['uid'],middle)}--></a>      
      <h1>
      <a href="home.php?mod=space&uid=$fuser['uid']&do=profile">$fuser['username']</a>
      <!--{if $fuser[uid] != $_G[uid]}-->
      <!--{if $fuser['mutual']}--> 
      <!--{if $fuser['mutual'] > 0}-->
      <span class="1b1VfV2YpEg2">{lang follow_follower_mutual}</span>
      <!--{else}-->
      <span class="1b1VfV2YpEg2">{$langplus[notfollowyou]}</span>
      <!--{/if}-->
      <!--{/if}-->
      <!--{/if}-->     
      </h1>
      <!--{if $fuser[recentnote]}--><p>$fuser[recentnote]</p><!--{/if}-->            
      <!--{if helper_access::check_module('follow')}-->
      <!--{if $fuser[uid] != $_G[uid]}-->
      <div class="FQgd2kpZkKVq">
      <ul>
      <!--{if $fuser[uid] != $_G[uid]}-->
      <!--{if $fuser['mutual']}--> 
      <li class="EuquFWEp2nsn"><a href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['uid']" class="F3pveqiOE331">{$langplus[nofollows_m]}</a></li> 
      <!--{elseif helper_access::check_module('follow')}--> 
      <li class="NZ57IYxR5FcU"><a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['uid']" class="F3pveqiOE331">{$langplus[follows]}</a></li> 
      <!--{/if}-->
      <!--{/if}-->
      </ul>
      </div>
      <div class="zgSirvDkTeGo" id="lockerclose_$fuser['uid']"></div>
      <!--{/if}-->
      <!--{/if}-->
      </div>           
      <!--{/if}-->
    </li>
    <!--{/loop}-->
  </ul>
  <div class="Es3s87mAHtE5"></div>
  <!--{if $tplpages == 1}-->
  <!--{eval $totalpage = ceil($count / $perpage);}--> 
  <!--{if $totalpage > $page}--> 
  <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a> 
  <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script> 
  <!--{/if}--> 
  <!--{else}-->
  <!--{if $multi}-->$multi<!--{/if}-->
  <!--{/if}-->
  
<script type="text/javascript">
$(document).ready(function(){
	$(document).on('click','.friendset',function(){		
		var lockerid = $(this).parent('.locker').attr('id'); 
		$('#' + lockerid).addClass('lockeropen').css('z-index','55');		
		$('.close_m').show();
	})
	$(document).on('click','.lockerclose',function(){
		$('.locker').removeClass('lockeropen').css('z-index', '');	
		$('.close_m').hide();	
	})
	$('.close_m').off().on('touchstart',function(){
		$('.locker').removeClass('lockeropen').css('z-index', '');		
		$(this).hide();
	});	
});
</script>
  
  <!--{else}--> 
     
  <div class="sqK9gG26iUGb">   
    <!--{if $viewself}-->     
    <!--{if $do=='following'}--> 
    {lang follow_you_following_none}<a href="home.php?mod=follow&view=other">{lang follow_hall}</a>{lang follow_fetch_interested_user} 
    <!--{else}--> 
    {lang follow_you_follower_none1}<a href="home.php?mod=follow">{lang follow_add_feed}</a>{lang follow_you_follower_none2} 
    <!--{/if}-->     
    <!--{else}-->     
    <!--{if $do=='following'}--> 
    {lang follow_user_following_none} 
    <!--{else}--> 
    {lang follow_user_follower_none} 
    <!--{/if}-->     
    <!--{/if}--> 
  </div> 
  
  <!--{/if}-->
  <!--{/if}-->
  
<!--{template common/footer}-->