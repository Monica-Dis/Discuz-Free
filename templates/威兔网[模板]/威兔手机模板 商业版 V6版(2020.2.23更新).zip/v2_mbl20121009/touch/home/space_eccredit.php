<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang credit_rating}<!--{/block}-->
<!--{template common/header}-->
<!--{if $_GET[uid] && $_G['uid'] != $space[uid]}-->
<div class="NkGgJbO2CQdl">
	<ul>
		<li><a href="home.php?mod=space&do=trade&view=me&uid=$space[uid]">{lang sale_of_goods}</a></li>
		<li class="E1x17Q9hYTmk"><a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit">{lang credit_rating}</a></li>
	</ul>
</div>
<!--{elseif $space[self]}-->
<div class="NkGgJbO2CQdl">
	<ul>
		<li><a href="home.php?mod=space&do=trade&view=me">{lang my_trade}</a></li>
		<li><a href="home.php?mod=space&do=trade&view=tradelog">{lang trade_log}</a></li>
		<li class="E1x17Q9hYTmk"><a href="home.php?mod=space&do=trade&view=eccredit">{lang credit_rating}</a></li>
		<li><a href="home.php?mod=space&do=trade&view=we">{$langplus[friendtrade]}</a></li>
	</ul>
</div>
<!--{/if}-->
<div class="tUESFpCOdmEf">
	<div class="trade_eccredit_avatars{if $_G['uid'] != $space['uid']} view_follow{/if}">
		<a href="home.php?mod=space&uid=$space[uid]&do=profile" class="UoRZiAghxSa8"><!--{avatar($space[uid],middle)}--></a>
		<p><a href="home.php?mod=space&uid=$space[uid]&do=profile">$space[username]</a></p>
		<span>{lang regdate}: $member[regdate]</span>
		<!--{if $_G['uid'] != $space['uid']}-->
		<!--{if helper_access::check_module('follow')}-->
		<a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]" class="4zNHhyy9fG4M">{$langplus[follows]}</a>
		<!--{else}-->
		<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=addfriendhk_{$space[uid]}" class="4zNHhyy9fG4M">{$langplus[follows]}</a>
		<!--{/if}-->
		<!--{/if}-->
	</div>
	<!--{eval $acccredit = $member[sellercredit] + $member[buyercredit]}-->
	<div class="hEeBa7s6Bcpg">
		<div class="keuk5RiCzwFy"><span class="2iXO52fxyQw9">{$acccredit}</span><p>{$langplus[acceccredit]}</p></div>
		<div class="keuk5RiCzwFy"><span class="2iXO52fxyQw9">{$sellerpercent}%</span><p>{lang eccredit_buyerpercent}</p></div>
		<div class="keuk5RiCzwFy"><span class="2iXO52fxyQw9">{$buyerpercent}%</span><p>{lang eccredit_sellerpercent}</p></div>
	</div>
	<div class="itKuTkyeNcBi">
		<p>{lang eccredit_buyerinfo} <span>$member[sellercredit]&nbsp;<img src="{STATICURL}image/traderank/seller/$member['sellerrank'].gif"/></span></p>
			<table id="sellcredit" cellspacing="0" cellpadding="0">
				<tr class="H0GFVnR1fsIu">
					<td style="width: 54px;">{lang trade_buyer}</td>
					<td>{$langplus[oneweek]}</td>
					<td>{$langplus[onemonth]}</td>
					<td>{$langplus[sixmonth]}</td>
					<td>{$langplus[sixmonthago]}</td>
					<td>{lang eccredit_total}</td>
				</tr>
				<tr>
					<td><img src="{STATICURL}image/traderank/good.gif" width="14" height="16" alt="good" class="OV2bpjsRvqFH" /> <span style="color:red">{lang eccredit_good}</span></td>
					<td>$caches[sellercredit][thisweek][good]</td>
					<td>$caches[sellercredit][thismonth][good]</td>
					<td>$caches[sellercredit][halfyear][good]</td>
					<td>$caches[sellercredit][before][good]</td>
					<td>$caches[sellercredit][all][good]</td>
				</tr>
				<tr>
					<td><img src="{STATICURL}image/traderank/soso.gif" width="14" height="16" alt="soso" class="OV2bpjsRvqFH" /> <span style="color:green">{lang eccredit_soso}</span></td>
					<td>$caches[sellercredit][thisweek][soso]</td>
					<td>$caches[sellercredit][thismonth][soso]</td>
					<td>$caches[sellercredit][halfyear][soso]</td>
					<td>$caches[sellercredit][before][soso]</td>
					<td>$caches[sellercredit][all][soso]</td>
				</tr>
				<tr>
					<td><img src="{STATICURL}image/traderank/bad.gif" width="14" height="16" alt="bad" class="OV2bpjsRvqFH" /> {lang eccredit_bad}</td>
					<td>$caches[sellercredit][thisweek][bad]</td>
					<td>$caches[sellercredit][thismonth][bad]</td>
					<td>$caches[sellercredit][halfyear][bad]</td>
					<td>$caches[sellercredit][before][bad]</td>
					<td>$caches[sellercredit][all][bad]</td>
				</tr>
				<tr>
					<td>{lang eccredit_total}</td>
					<td>$caches[sellercredit][thisweek][total]</td>
					<td>$caches[sellercredit][thismonth][total]</td>
					<td>$caches[sellercredit][halfyear][total]</td>
					<td>$caches[sellercredit][before][total]</td>
					<td>$caches[sellercredit][all][total]</td>
				</tr>
			</table>

			<p class="LVn6pdMIdahQ">{lang eccredit_sellerinfo} <span>$member[buyercredit]&nbsp;<img src="{STATICURL}image/traderank/buyer/$member['buyerrank'].gif"/></span></p>
			<table id="buyercredit" cellspacing="0" cellpadding="0">
				<tr class="H0GFVnR1fsIu">
					<td style="width: 54px;">{lang trade_seller}</td>
					<td>{$langplus[oneweek]}</td>
					<td>{$langplus[onemonth]}</td>
					<td>{$langplus[sixmonth]}</td>
					<td>{$langplus[sixmonthago]}</td>
					<td>{lang eccredit_total}</td>
				</tr>
				<tr>
					<td><img src="{STATICURL}image/traderank/good.gif" width="14" height="16" alt="good" class="OV2bpjsRvqFH" /> <span style="color:red">{lang eccredit_good}</span></td><td><a href="home.php?mod=spacecp&ac=eccredit&op=list&uid=$uid&from=seller&filter=thisweek&level=good" onclick="ajaxget(this.href, 'ajaxrate', 'specialposts');doane(event);">$caches[buyercredit][thisweek][good]</a></td>
					<td>$caches[buyercredit][thismonth][good]</td>
					<td>$caches[buyercredit][halfyear][good]</td>
					<td>$caches[buyercredit][before][good]</td>
					<td>$caches[buyercredit][all][good]</td>
				</tr>
				<tr>
					<td><img src="{STATICURL}image/traderank/soso.gif" width="14" height="16" alt="soso" class="OV2bpjsRvqFH" /> <span style="color:green">{lang eccredit_soso}</span></td>
					<td>$caches[buyercredit][thisweek][soso]</td>
					<td>$caches[buyercredit][thismonth][soso]</td>
					<td>$caches[buyercredit][halfyear][soso]</td>
					<td>$caches[buyercredit][before][soso]</td>
					<td>$caches[buyercredit][all][soso]</td>
				</tr>
				<tr>
					<td><img src="{STATICURL}image/traderank/bad.gif" width="14" height="16" alt="bad" class="OV2bpjsRvqFH" /> {lang eccredit_bad}</td>
					<td>$caches[buyercredit][thisweek][bad]</td>
					<td>$caches[buyercredit][thismonth][bad]</td>
					<td>$caches[buyercredit][halfyear][bad]</td>
					<td>$caches[buyercredit][before][bad]</td>
					<td>$caches[buyercredit][all][bad]</td>
				</tr>
				<tr>
					<td>{lang eccredit_total}</td>
					<td>$caches[buyercredit][thisweek][total]</td>
					<td>$caches[buyercredit][thismonth][total]</td>
					<td>$caches[buyercredit][halfyear][total]</td>
					<td>$caches[buyercredit][before][total]</td>
					<td>$caches[buyercredit][all][total]</td>
				</tr>
			</table>
		<!--{if $_G['uid'] && ($_G['uid'] == $space[uid] || getstatus($_G['member']['allowadmincp'], 1))}-->
		<div class="dSuSXF0hZhzY"><a href="home.php?mod=spacecp&ac=eccredit&op=list&uid=$uid" class="r9COG0I1EFgN">{lang show}{$langplus[eccreditlistall]}</a></div>
		<!--{/if}-->
</div>
</div>
<!--{template common/footer}-->