<?php echo 'From: DisM.taobao.com';exit;?>
<div class="rthtgygSziGe">
<ul>
	<li $subactives[uselog]><a href="home.php?mod=magic&action=log&operation=uselog">{lang magics_log_use}</a></li>
	<li $subactives[buylog]><a href="home.php?mod=magic&action=log&operation=buylog">{lang magics_log_buy}</a></li>
	<li $subactives[givelog]><a href="home.php?mod=magic&action=log&operation=givelog">{lang magics_log_present}</a></li>
	<li $subactives[receivelog]><a href="home.php?mod=magic&action=log&operation=receivelog">{lang magics_log_receive}</a></li>
</ul>
</div>
<!--{if $operation == 'uselog'}-->
	<!--{if $loglist}-->
		<div class="XjWOnYxh8acS">
			<div class="zw5p3TMEhC4q">
				<em>{lang magics_name}</em>
				<em>{$langplus[dateline]}</em>
				<em>{lang magics_target_use}</em>
			</div>
            <ul id="alist" class="HwKFWtPXAVEl">
			<!--{loop $loglist $log}-->
			<li class="YeVA6pJ1qcWs">
				<em>$log[name]</em>
				<em>$log[dateline]</em>
				<em>
					<!--{if $log[idtype] == 'uid'}-->
						<a href="home.php?mod=space&uid=$log[targetid]" target="_blank">{lang magics_target}</a>
					<!--{elseif $log[idtype] == 'tid'}-->
						<a href="forum.php?mod=viewthread&tid=$log[targetid]" target="_blank">{lang magics_target}</a>
					<!--{elseif $log[idtype] == 'pid'}-->
						<a href="forum.php?mod=redirect&pid=$log[targetid]&goto=findpost" target="_blank">{lang magics_target}</a>
					<!--{elseif $log[idtype] == 'sell'}-->
						{lang magics_operation_sell}
					<!--{elseif $log[idtype] == 'drop'}-->
						{lang magics_operation_drop}
					<!--{/if}-->
				</em>
			</li>
			<!--{/loop}-->
            </ul>
		</div>
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $_G['tpp']);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=magic&action=log&operation=uselog" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->
	<!--{else}-->
		<div class="sqK9gG26iUGb">{lang data_nonexistence}</div>
	<!--{/if}-->
<!--{elseif $operation == 'buylog'}-->
	<!--{if $loglist}-->		
        <div class="XjWOnYxh8acS">
			<div class="uqrM6I60Zpzk">
				<em>{lang magics_name}</em>
				<em>{$langplus[dateline]}</em>
				<em>{$langplus[amount]}</em>
				<em>{$langplus[price]}</em>
			</div>          
            <ul id="alist" class="HwKFWtPXAVEl">
			<!--{loop $loglist $log}-->
				<li>
					<em>$log[name]</em>
					<em>$log[dateline]</em>
					<em>$log[amount]</em>
					<em>$log[price] {$_G['setting']['extcredits'][$log[credit]][unit]}{$_G['setting']['extcredits'][$log[credit]][title]}</em>
				</li>
			<!--{/loop}-->
            </ul>
        </div>            
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $_G['tpp']);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=magic&action=log&operation=buylog" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->
	<!--{else}-->
		<div class="sqK9gG26iUGb">{lang data_nonexistence}</div>
	<!--{/if}-->
<!--{elseif $operation == 'givelog'}-->
	<!--{if $loglist}-->
		<div class="XjWOnYxh8acS">
			<div class="uqrM6I60Zpzk">
				<em>{lang magics_name}</em>
				<em>{$langplus[dateline]}</em>
				<em>{$langplus[amount]}</em>
				<em>{lang magics_target_present}</em>
			</div>
			<ul id="alist" class="HwKFWtPXAVEl">
            <!--{loop $loglist $log}-->
				<li>
					<em>$log[name]</em>
					<em>$log[dateline]</em>
					<em>$log[amount]</em>
					<em><a href="home.php?mod=space&uid=$log[targetuid]" target="_blank">$log[username]</a></em>
				</li>
			<!--{/loop}-->
            </ul>
		</div>
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $_G['tpp']);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=magic&action=log&operation=givelog" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->
	<!--{else}-->
		<div class="sqK9gG26iUGb">{lang data_nonexistence}</div>
	<!--{/if}-->
<!--{elseif $operation == 'receivelog'}-->
	<!--{if $loglist}-->
		<div class="XjWOnYxh8acS">
			<div class="uqrM6I60Zpzk">
				<em>{lang magics_name}</em>
				<em>{$langplus[dateline]}</em>
				<em>{$langplus[amount]}</em>
				<em>{lang magics_target_receive}</em>
			</div>
            <ul id="alist" class="HwKFWtPXAVEl">
			<!--{loop $loglist $log}-->
				<li>
					<em><a href="home.php?mod=magic&action=index&operation=buy&magicid=$log[magicid]" target="_blank">$log[name]</a></em>
					<em>$log[dateline]</em>
					<em>$log[amount]</em>
					<em><a href="home.php?mod=space&uid=$log[uid]" target="_blank">$log[username]</a></em>
				</li>
			<!--{/loop}-->
			</ul>
        </div>
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $_G['tpp']);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=magic&action=log&operation=receivelog" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->
	<!--{else}-->
		<div class="sqK9gG26iUGb">{lang data_nonexistence}</div>
	<!--{/if}-->
<!--{/if}-->