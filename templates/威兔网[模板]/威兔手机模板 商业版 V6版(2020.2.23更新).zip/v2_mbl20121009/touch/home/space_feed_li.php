<?php echo 'From: DisM.taobao.com';exit;?>
        <div class="pq37hCCorQWR">
        <div class="BfETzT7w1qNI">
        <!--{if $value[uid] && empty($_G['home']['tpl'][hidden_more])}-->
        <!--{if $_G['uid']}-->
        <a href="home.php?mod=spacecp&ac=feed&op=menu&feedid=$value[feedid]" class="CmbtAFT1SmhK" ><!--{if $_G['uid'] != $value[uid]}--><i class="a1eQefH4PIjA"></i><!--{else}--><i class="aPyV086aHjq3"></i><!--{/if}--></a>
        <!--{/if}-->
        <!--{/if}-->
        <p>$value[title_template]<span><!--{date($value[dateline], 'u')}--></span></p>
        </div>        
			<!--{if $value['image_1']}-->
			<img src="$value[image_1]" class="{if $value['body_template']}mbn{else}mbm{/if}" />
			<!--{/if}-->
			<!--{if $value['image_2']}-->
			<img src="$value[image_2]" class="{if $value['body_template']}mbn{else}mbm{/if}" />
			<!--{/if}-->
			<!--{if $value['image_3']}-->
			<img src="$value[image_3]" class="{if $value['body_template']}mbn{else}mbm{/if}" />
			<!--{/if}-->
			<!--{if $value['image_4']}-->
			<img src="$value[image_4]" class="{if $value['body_template']}mbn{else}mbm{/if}" />
			<!--{/if}-->
			<!--{if $value['body_template']}-->
		    <div class="St2eyc72YQPn">$value[body_template]</div>
			<!--{/if}-->                        
            </div>