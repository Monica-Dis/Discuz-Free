<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{$navtitle}<!--{/block}-->
<!--{template common/header}-->
<!--{if $validate}-->
<!--{eval dheader("location: ./forum.php");exit; }-->
<!--{elseif $_GET['myset']}-->
<!--{eval dheader("location: ./forum.php");exit; }-->
<!--{else}-->
<!--{if $operation == 'password'}-->
<div class="z76GhPvFhhjY">
			<div class="IHUDUAqpiULT">
				<!--{if !$_G['member']['freeze']}-->
					<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->{lang old_password_comment}<!--{elseif $wechatuser}-->{lang wechat_config_newpassword_comment}<!--{else}-->{lang connect_config_newpassword_comment}<!--{/if}-->
				<!--{elseif $_G['member']['freeze'] == 1}-->
					<strong>{lang freeze_pw_tips}</strong>
				<!--{elseif $_G['member']['freeze'] == 2}-->
					<strong>{lang freeze_email_tips}</strong>
				<!--{/if}-->
			</div>
		
			<form class="IYXG4PSjPmYD" action="home.php?mod=spacecp&ac=profile" method="post" autocomplete="off" data-am-validator>            
            <ul>			
				<input type="hidden" value="{FORMHASH}" name="formhash" />
				<!--{if !$_G['setting']['connect']['allow'] || !$conisregister}-->
				<li>
                <span class="MpvxeU1AdHyP">{lang old_password}</span>				
				<input type="password" name="oldpassword" id="oldpassword" placeholder="{$langplus[required]}" />
				</li>
				<!--{/if}-->
				<li>
                <span class="MpvxeU1AdHyP">{lang new_password}</span>
				<input type="password" name="newpassword" id="newpassword" placeholder="{lang memcp_profile_passwd_comment}"/>
				</li>
				<li>
                <span class="MpvxeU1AdHyP">{$langplus[new_password_confirm]}</span>
				<input type="password" name="newpassword2" id="newpassword2" placeholder="{lang memcp_profile_passwd_comment}" />					
				</li>
				<li id="contact" class="Gndtj1o9dRc7"{if $_GET[from] == 'contact'} style="background-color: {$_G['style']['specialbg']};"{/if}>
                    <span class="MpvxeU1AdHyP">{lang email}</span>
					<input type="email" name="emailnew" id="emailnew" value="$space[email]" required/>
                    </li>
					<li class="pW8YlVXrYkq8">                                        
						<!--{if empty($space['newemail'])}-->
							{lang email_been_active}
						<!--{else}-->
							$acitvemessage
						<!--{/if}-->
					</li>                                              
					<!--{if $_G['setting']['regverify'] == 1 && (($_G['group']['grouptype'] == 'member' && $_G['adminid'] == 0) || $_G['groupid'] == 8) || $_G['member']['freeze']}--><li class="witFxyKQrWDY">{lang memcp_profile_email_comment}</li><!--{/if}-->
				<!--{if $_G['member']['freeze'] == 2}-->
					<li>
					<span class="MpvxeU1AdHyP">{lang freeze_reason}</span>
					<textarea rows="3" cols="80" name="freezereson" placeholder="{lang freeze_reason_comment}" >$space[freezereson]</textarea>
					</li>
				<!--{/if}-->
					<li class="Gndtj1o9dRc7">
							<span class="MpvxeU1AdHyP">{lang security_question}</span>
							<div class="ifiKZQ0GkoOQ">
							<select name="questionidnew" id="questionidnew">
								<option value="" selected>{lang memcp_profile_security_keep}</option>
								<option value="0">{lang security_question_0}</option>
								<option value="1">{lang security_question_1}</option>
								<option value="2">{lang security_question_2}</option>
								<option value="3">{lang security_question_3}</option>
								<option value="4">{lang security_question_4}</option>
								<option value="5">{lang security_question_5}</option>
								<option value="6">{lang security_question_6}</option>
								<option value="7">{lang security_question_7}</option>
							</select>
                            </div>
                    </li>
					<li class="witFxyKQrWDY">{lang memcp_profile_security_comment}</li>
					<li>
					<span class="MpvxeU1AdHyP">{$langplus[security_answer]}</span>
					<input type="text" name="answernew" id="answernew" placeholder="{lang memcp_profile_security_answer_comment}" />						
					</li>
					<!--{if $secqaacheck || $seccodecheck}-->                   
					<!--{eval $sectpl = '<table cellspacing="0" cellpadding="0" class="qNKmiVIbC7nb"><tr><th><sec></th><td><sec><p class="MggpgDHAhDxn"><sec></p></td></tr></table>';}-->
					<li><!--{subtemplate common/seccheck}--></li>				
					<!--{/if}-->
                    </ul> 
				<div class="pO8btUYfgnr0"><button type="submit" name="pwdsubmit" value="true" class="pymKRL3JTNW2" />{lang save}</button></div>
				<input type="hidden" name="passwordsubmit" value="true" />			
			</form>
         </div>         
        <!--{block footerplus}--><div class="a87wGthEpSmH"></div><!--{/block}-->
        <!--{eval $nofooter = true;}-->            
		<!--{else}-->
        <!--{template home/spacecp_profile_nav}-->
		<script src="template/v2_mbl20121009/touch_plus/js/profile.js"></script>        
        <div class="FWkoMd5M3hp0">
		  <!--{if $vid}-->
		  <div class="IHUDUAqpiULT"><!--{if $showbtn}-->{lang spacecp_profile_message1}<!--{else}-->{lang spacecp_profile_message2}<!--{/if}--></div>
		  <!--{/if}-->
		  <div class="FICSiH44oRVC">
			    <iframe id="frame_profile" name="frame_profile" style="display: none"></iframe>
			    <form action="{if $operation != 'plugin'}home.php?mod=spacecp&ac=profile&op=$operation{else}home.php?mod=spacecp&ac=plugin&op=profile&id=$_GET[id]{/if}" method="post" enctype="multipart/form-data" autocomplete="off"{if $operation != 'plugin'} target="frame_profile"{/if} accept-charset="UTF-8">
				      <input type="hidden" value="{FORMHASH}" name="formhash" />
				      <!--{if $_GET[vid]}-->
				      <input type="hidden" value="$_GET[vid]" name="vid" />
				      <!--{/if}-->				      
				      <table cellspacing="0" cellpadding="0">                                           				      
					      <!--{loop $settings $key $value}-->                          
                            <!--{if $value[available]}--> 
                            <tr>
                            <td class="Z0HZAuPhwQSK" id="th_$key">
                            <span class="bm82kek51fSh">{$value[title]}<!--{if $value[required]}--><em>*</em><!--{/if}--></span>
                            </td>
                            <th>							      
							      <!--{if $value[formtype] == 'textarea'}-->
								      <div class="valuetxta txt_$key">
                                      <span class="flex $value[formtype]">$htmls[$key]</span> 
                                      <span class="wiaf22vX0Mg8"><input type="hidden" name="privacy[$key]" value="{if $vid}3{else}$privacy[$key]{/if}" /></span>
								      </div>							      
							      <!--{else}-->							      
								      <div class="valuetxta txt_$key">								      	
                                      <span class="flex $value[formtype]">$htmls[$key]</span> 
                                      <span class="wiaf22vX0Mg8"><input type="hidden" name="privacy[$key]" value="{if $vid}3{else}$privacy[$key]{/if}" /></span>
								      </div>								      
							      <!--{/if}-->
                            </th>
                            <td class="R3ZmpFt6j2Fs">
                            <!--{if $vid}-->
							<input type="hidden" name="privacy[$key]" value="3" />
							<!--{else}-->
							<select name="privacy[$key]">
								<option value="0"{if $privacy[$key] == "0"} selected="selected"{/if}>{lang open_privacy}</option>
								<option value="1"{if $privacy[$key] == "1"} selected="selected"{/if}>{lang friends}</option>
								<option value="3"{if $privacy[$key] == "3"} selected="selected"{/if}>{lang secrecy}</option>
							</select>
							<!--{/if}--> 
                            </td>
                            </tr>    
                            <!--{/if}--> 
					      <!--{/loop}-->
				      
					      <!--{if $allowcstatus && in_array('customstatus', $allowitems)}-->
                          <tr>
					      <td class="Z0HZAuPhwQSK">
							<span class="bm82kek51fSh">{$langplus[userstatus]}</span>
						  </td>
					      <th colspan="2">
							<span class="4PvkowtOrPtV"><textarea name="customstatus" id="customstatus" />$space[customstatus]</textarea></span>
                          </th>
                          </tr>
					      <!--{/if}-->
				      
					      <!--{if $_G['group']['maxsigsize'] && in_array('sightml', $allowitems)}-->
                          <tr>
					      <td class="Z0HZAuPhwQSK">
							<span class="bm82kek51fSh">{lang personal_signature}</span>
						  </td>
						  <th colspan="2">
							<span class="4PvkowtOrPtV"><textarea name="sightml" id="sightmlmessage" >$space[sightml]</textarea></span>
						  </th>
                          </tr>                          
					      <!--{/if}-->				      
					      <!--{if in_array('timeoffset', $allowitems)}--><!--{/if}-->					      
					      <!--{if $operation == 'contact'}--><!--{/if}-->					      
					      <!--{if $operation == 'plugin'}-->
					          <!--{eval include(template($_GET['id']));}-->
					      <!--{/if}-->					      
					 </table>					 
					 <!--{if $showbtn}-->
					 <input type="hidden" name="profilesubmit" value="true" />
					 <div class="pO8btUYfgnr0">						    
						<button type="submit" name="profilesubmitbtn" id="profilesubmitbtn" value="true" class="hWkKLBWkXyXu" />{lang save}</button>
					 </div>
					 <!--{/if}-->				      
			    </form>
		  </div>           
</div>   
<script type="text/javascript">
	function show_error(fieldid, extrainfo) {
		var elem = $('#th_'+fieldid);
		if(elem) {
			fieldname = elem.find('.name').text();
			Common.tips("{lang check_date_item}: " + fieldname);
			$('#'+fieldid).focus();
		}
	}
	function show_success(message) {
		message = message == '' ? '{lang update_date_success}' : message;
		Common.tips(message);
	}	
</script> 
<!--{block footerplus}--><div class="a87wGthEpSmH"></div><!--{/block}-->
<!--{eval $nofooter = true;}-->              
<!--{/if}-->    
<!--{/if}-->
<!--{template common/footer}-->