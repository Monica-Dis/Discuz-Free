<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang upload_pic}<!--{/block}-->
<!--{template common/header}-->
      <!--{if empty($_GET['op'])}-->
      <!--{if $albums}-->
      <div class="tabequal">
        <ul>
          <li class="on"><a href="javascript:;" >{lang add_to_existing_album}</a></li>
          <li><a href="javascript:;" >{lang create_new_album}</a></li>
        </ul>
      </div>
      <script type="text/javascript">
	  $(document).ready(function(){
		  $('.tabequal li').click(function(){
			  $('.tabequal li').eq($(this).index()).addClass('on').siblings().removeClass('on');
			  $('.hidebox').eq($(".tabequal li").index(this)).slideDown().siblings().slideUp();
			  $('.album_op > input').eq($(".tabequal li").index(this)).attr("checked","checked").siblings().removeAttr("checked");
			  
		  });	
	  })
      </script> 
      <!--{/if}-->
      <form method="post" autocomplete="off" id="albumform" action="home.php?mod=spacecp&ac=upload" >
      <div class="inputall bw">      
      <ul id="imglist" class="album_imglist"></ul>
      <div class="album_uptips">{$langplus[upimgtips]}</div>
      <!--{if $albums}--> 
      <div class="mbm" style="display:none !important;" >
      <label for="albumop_selectalbum" class="album_op"><input type="radio" name="albumop" id="albumop_selectalbum" value="selectalbum" checked="checked" />{lang add_to_existing_album}</label>
      <label for="albumop_creatalbum" class="album_op"><input type="radio" name="albumop" id="albumop_creatalbum" value="creatalbum" />{lang create_new_album}</label>
      </div>
      <!--{/if}-->      
      <div class="albumop_upload">        
      <!--{if $albums}-->      
      <ul id="selectalbum" class="hidebox" style="display:block;">      
      <div class="selectstyle mbm">
      <select name="albumid" id="uploadalbumid" >
         <option value="0" selected="selected">{lang default_album}</option>
         <!--{loop $albums $value}-->
         <!--{if $value['albumid'] == $_GET['albumid']}-->
         <option value="$value[albumid]" selected="selected">$value[albumname]</option>
         <!--{else}-->
         <option value="$value[albumid]">$value[albumname]</option>
         <!--{/if}-->
         <!--{/loop}-->
      </select>
      </div> 
      </ul>
      <!--{else}-->
      <input type="hidden" name="albumop" value="creatalbum" />
      <!--{/if}-->                
      <ul id="creatalbum"{if $albums} class="hidebox"{/if}>      
      <li><input type="text" name="albumname" id="albumname" placeholder="{lang create_new_album}" value="" /></li>
      <li><textarea name="depict" rows="3" placeholder="{lang album_depict}"></textarea></li>
      <!--{if $_G['setting']['albumcategorystat'] && $categoryselect}-->
      <li class="mbn">
      <div class="selectstyle">
      $categoryselect
      </div>
      </li>
      <li class="warningmessage">{lang select_site_album_categories}</li>
      <!--{/if}-->
      <li>
      <div class="selectstyle">
      <select name="friend" id="uploadfriend" onchange="passwordShow(this.value);">
         <option value="0">{lang friendname_0}</option>
         <option value="1">{lang friendname_1}</option>
         <option value="2">{lang friendname_2}</option>
         <option value="3">{lang friendname_3}</option>
         <option value="4">{lang friendname_4}</option>
      </select>
      </div>
      </li>
      <li id="span_password" style="display:none;">
      <input type="text" name="password" id="uploadpassword" value="" placeholder="{lang password}" />
      </li>
      <div id="tb_selectgroup" style="display:none;">
      <li class="mbn">
      <div class="selectstyle">
      <select name="selectgroup" onchange="getgroup(this.value);">
         <option value="">{lang from_friends_group}</option>
         <!--{loop $groups $key $value}-->
         <option value="$key">$value</option>
         <!--{/loop}-->
      </select>
      </div>
      </li>
      <li class="warningmessage">{lang choices_following_friends_list}</li>
      <li><textarea name="target_names" id="target_names" rows="3" placeholder="{lang friend_name_space}">$blog[target_names]</textarea></li>
      </div>
      </ul>
      </div>                
      </div>
      <div class="ftpost">
      <table cellspacing="0" cellpadding="0">
        <tr>
          <td><div class="editor editordefault"><a href="javascript:;" class="postcamera"><input type="file" name="Filedata" id="filedata" accept="image/*" multiple="multiple" /></a></div></td>
          <th><button type="submit" id="issuance" class="formdialog ftbtn nopost" disable="true">{$langplus[newpost]}</button></th>
        </tr>
      </table>    
      </div>    
      <input type="hidden" name="albumsubmit" id="albumsubmit" value="true" />                    
      <input type="hidden" name="formhash" value="{FORMHASH}" />           
      </form>
        
        <script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/ajaxfileupload.js?{VERHASH}"></script>
        <script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/buildfileupload.js?{VERHASH}"></script>        
        <script type="text/javascript">
            var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png, bmp' : imgexts;
            var STATUSMSG = {
                '-1' : '{lang uploadstatusmsgnag1}',
                '0' : '{lang uploadstatusmsg0}',
                '1' : '{lang uploadstatusmsg1}',
                '2' : '{lang uploadstatusmsg2}',
                '3' : '{lang uploadstatusmsg3}',
                '4' : '{lang uploadstatusmsg4}',
                '5' : '{lang uploadstatusmsg5}',
                '6' : '{lang uploadstatusmsg6}',
                '7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
                '8' : '{lang uploadstatusmsg8}',
                '9' : '{lang uploadstatusmsg9}',
                '10' : '{lang uploadstatusmsg10}',
                '11' : '{lang uploadstatusmsg11}'
            };
            var form = $('#albumform');
            $(document).on('change', '#filedata', function() {
                    popup.open('<div class="cloading"></div>');
        
                    uploadsuccess = function(data) {
                        if(data == '') {
                            popup.open('{lang uploadpicfailed}', 'alert');
                        }						                       
                        var dataarr = eval('('+data+')');        
                            popup.close();
                            $('#imglist').append('<li><span aid="'+dataarr['picid']+'" class="imgdel"><a href="javascript:;"></a></span><span class="post_img"><a href="javascript:;"><'+'img id="aimg_'+dataarr['picid']+'" src="'+dataarr['bigimg']+'" /></a></span><textarea name="title['+dataarr['picid']+']" rows="2" placeholder="{$langplus[description]}" class="album_imglist_txt"></textarea></li>');														
                            $('.album_uptips').hide();
                            $('#issuance').removeClass('nopost').addClass('btnon');
                            $('#issuance').attr('disable', 'false');                            
                    };					
        
                    if(typeof FileReader != 'undefined' && this.files[0]) {
                    <!--{if $upimgnumber}-->
                    if(this.files.length < {$upimgnumber}) { var imgnumber = this.files.length; } else { var imgnumber = {$upimgnumber}; }
                    <!--{/if}-->
                    for(var i=0;i<{if $upimgnumber}imgnumber{else}this.files.length{/if};i++ ){
                        var file_data = [];
                        file_data.push(this.files[i]);
                        $.buildfileupload({
                            uploadurl:'misc.php?mod=swfupload&action=swfupload&operation=album&type=image',
                            files:file_data,
                            uploadformdata:{uid : "$_G[uid]", hash:"$swfconfig[hash]"},
                            uploadinputname:'Filedata',
                            maxfilesize:"$swfconfig[max]",
                            success:uploadsuccess,
                            error:function() {
                                popup.open('{lang uploadpicfailed}', 'alert');
                            }
                        });
					}
        
                    } else {
        
                        $.ajaxfileupload({
                            url:'{misc.php?mod=swfupload&action=swfupload&operation=album&type=image',
                            data:{uid : $_G[uid], hash:"$swfconfig[hash]"},
                            dataType:'text',
                            fileElementId:'filedata',
                            success:uploadsuccess,
                            error: function() {
                                popup.open('{lang uploadpicfailed}', 'alert');
                            }
                        });
        
                    }
            });
            
            $(document).on('click', '.imgdel', function() {
                var obj = $(this);
                $.ajax({
                   type:'GET',
                   url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
                })
                .success(function(s) {
                   obj.parent().remove();
                   var albumimglist = $('#imglist').html();
                   if(!albumimglist){
                      $('.album_uptips').show();
                      $('#issuance').removeClass('btnon').addClass('nopost');
                      $('#issuance').attr('disable', 'true');
                   }
                })
                .error(function() {
                   popup.open('{lang networkerror}', 'alert');
                });
                return false;
            });	
			
            $('#issuance').on('click', function() {						
                var btobj = $(this);
                if(btobj.attr('disable') == 'true') {
                    return false;
                }
            });	
            </script>
        
		<script type="text/javascript"> 
		$(document).on('change', '#uploadfriend', function() {
			var obj = $(this);
			if(obj.val() == 4) {
				$("#span_password").css('display', '');				
			} else {
				$("#span_password").css('display', 'none');				
			}			
			if(obj.val() == 2) {
				$("#tb_selectgroup").css('display', '');				
			} else {
				$("#tb_selectgroup").css('display', 'none');				
			}			
		});
		function getgroup(gid) {
			if(gid) {
				$.ajax({
					type:'GET',
					url:'home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid='+gid,
					dataType:'xml'
				})
				.success(function(s) {
					var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();					
					//smg = smg + ' ';
					$('#target_names').val(smg);
				});
			}
		}
		</script>
            
      <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}-->
      <!--{block scrollplus}-->
      <div class="scroll_plus"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="scroll_notice"><i></i></a></div>
      <!--{/block}-->
      <!--{/if}-->
      <!--{block footerplus}--><div class="ftbox"></div><!--{/block}-->
      <!--{eval $nofooter = true;}-->

      <!--{elseif $_GET['op'] == 'cam'}-->
      <div class="r-block">{$langplus[nofunction]}</div>
      <!--{/if}-->

<!--{template common/footer}-->