<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $feed[uid]==$_G[uid]}-->{lang delete_feed}<!--{else}-->{lang shield_feed}<!--{/if}--><!--{/block}-->
<!--{if $feed[uid]==$_G[uid]}--><!--{eval $navtitle = {lang delete_feed};}--><!--{else}--><!--{eval $navtitle = {lang shield_feed};}--><!--{/if}-->
<!--{template common/header}-->
<!--{if $feed[uid]==$_G[uid]}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if}">
	<form method="post" autocomplete="off" id="feedform_{$feedid}" name="feedform_{$feedid}" action="home.php?mod=spacecp&ac=feed&op=delete&feedid=$feedid&handlekey=$_GET[handlekey]" >
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="feedsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="r-block">{lang determine_delete_feed}</div>		
		<div class="hm"><button name="feedsubmitbtn" type="submit" class="formdialog button2" value="true">{lang determine}</button></div>		
	</form>
</div>
<!--{else}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if}">
	<form method="post" autocomplete="off" id="feedform_{$feedid}" name="feedform_{$feedid}" action="home.php?mod=spacecp&ac=feed&op=ignore&icon=$feed[icon]&feedid=$feedid" >
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="feedignoresubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
        <div class="inputall ppd bb">
        <ul>		
		<li><label for="uid1"><input type="radio" name="uid" id="uid1" class="pc checkbox" value="$feed[uid]" checked="checked" />{lang shield_this_friend}</label></li>
		<li><label for="uid0"><input type="radio" name="uid" id="uid0" class="pc checkbox" value="0" />{lang shield_all_friend}</label></li>
		</ul>
        </div>
		<div class="hm"><button name="feedignoresubmitbtn" type="submit" class="formdialog button2" value="true">{lang determine}</button></div>
	</form>
    </div>
	<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->