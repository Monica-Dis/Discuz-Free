<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $_GET[op] == 'delete'}-->{lang delete_blog}<!--{elseif $_GET[op] == 'stick'}--><!--{if $stickflag}-->{lang stick_blog}<!--{else}-->{lang cancel_stick_blog}<!--{/if}--><!--{elseif $_GET[op] == 'addoption'}-->{lang create_category}<!--{elseif $_GET[op] == 'edithot'}-->{lang adjust_hot}<!--{else}--><!--{if $blog[blogid]}-->{lang edit_blog}<!--{else}-->{lang memcp_blog}<!--{/if}--><!--{/if}--><!--{/block}-->
<!--{eval $navtitle = {lang blog};}-->
<!--{template common/header}-->

<!--{if $_GET[op] == 'delete'}-->
<div class="ajaxpop">
<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&op=delete&blogid=$blogid">
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="deletesubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="r-block">{lang sure_delete_blog}</div>
	<div class="hm"><button type="submit" name="btnsubmit" value="true" class="formdialog button2">{lang determine}</button></div>
</form>
</div>
<!--{elseif $_GET[op] == 'stick'}-->
<div class="ajaxpop">
<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&op=stick&blogid=$blogid">
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="sticksubmit" value="true" />
	<input type="hidden" name="stickflag" value="$stickflag" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="r-block"><!--{if $stickflag}-->{lang sure_stick_blog}<!--{else}-->{lang sure_cancel_stick_blog}<!--{/if}--></div>	
	<div class="hm"><button type="submit" name="btnsubmit" value="true" class="formdialog button2">{lang determine}</button></div>	
</form>
</div>

<!--{elseif $_GET[op] == 'addoption'}-->
<div class="ajaxpop">
	<ul class="inputall b_pw bb">
		<li class="mbn">{lang create_category}:</li>
        <li class="m_c"><input type="text" name="newsort" id="newsort" placeholder="{lang name}" value="" /></li>
	</ul>
	<div class="hm">
		<button type="button" name="btnsubmit" value="true" class="newsortbtn button2">{lang create}</button>
	</div>
</div>
<!--{elseif $_GET[op] == 'edithot'}-->
<div class="ajaxpop">
<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&op=edithot&blogid=$blogid">
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="hotsubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="inputall bb b_pw ptm">
		<ul>
        <li class="mbn">{lang new_hot}:</li>
        <li class="m_c"><input type="text" name="hot" value="$blog[hot]" /></li>
        </ul>
	</div>
	<div class="hm"><button type="submit" name="btnsubmit" value="true" class="formdialog button2">{lang determine}</button></div>
</form>
</div>

<!--{else}-->

         <form id="ttHtmlEditor" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]{if $_GET[modblogkey]}&modblogkey=$_GET[modblogkey]{/if}" onsubmit="validate(this);" enctype="multipart/form-data">            
			<div class="inputall bw">
            <!--{if $blog[blogid]}--><div class="warningmessage">{$langplus[editnotice]}</div><!--{/if}-->
				<ul>
				<li><input type="text" id="subject" name="subject" value="$blog[subject]" placeholder="{lang thread_subject}" /></li>
				<!--{if $_G['setting']['blogcategorystat'] && $categoryselect}-->					
				<li><div class="selectstyle">$categoryselect</div></li>                       			
				<!--{/if}-->
				<li><textarea name="message" id="uchome-ttHtmlEditor" rows="10" placeholder="{lang thread_content}">$blog[message]</textarea></li>
                </ul>
                <ul id="imglist" class="post_imglist"></ul>
                <div class="menufly">
                <div class="namefly"><span class="vt-close fz2"></span>$langplus[option]</div>                
                <div class="blog_set">
					<ul>
						<li{if !$blog['uid'] || $blog['uid']==$_G['uid']} class="mesort"{/if}>													
							<div class="selectstyle">
                            <select name="classid" id="classid" onchange="addSort(this)" >
								<option value="0">{lang personal_category}</option>
								<!--{loop $classarr $value}-->
								<!--{if $value['classid'] == $blog['classid']}-->
								<option value="$value[classid]" selected>$value[classname]</option>
								<!--{else}-->
								<option value="$value[classid]">$value[classname]</option>
								<!--{/if}-->
								<!--{/loop}-->								
                                </select>                                
                            </div> 
                            <!--{if !$blog['uid'] || $blog['uid']==$_G['uid']}--><a href="home.php?mod=spacecp&ac=blog&op=addoption&handlekey=addoption&oid=classid" class="addoptions dialog"><i class="vt-plus"></i></a><!--{/if}-->                          
						</li>
                                            
					<li><input type="text" id="tag" name="tag" value="$blog[tag]" placeholder="{lang label}" /></li>
				<!--{if $blog['uid'] && $blog['uid']!=$_G['uid']}-->
				<!--{eval $selectgroupstyle='display:none';}-->
				<!--{/if}--> 
					<li>						
							<div class="selectstyle">
                            <select name="friend" onchange="passwordShow(this.value);" id="privacy_friend">
								<option value="0"$friendarr[0]>{lang friendname_0}</option>
								<option value="1"$friendarr[1]>{lang friendname_1}</option>
								<option value="2"$friendarr[2]>{lang friendname_2}</option>
								<option value="3"$friendarr[3]>{lang friendname_3}</option>
								<option value="4"$friendarr[4]>{lang friendname_4}</option>
							</select>
                            </div>
					</li>                    
					<li id="span_password" style="$passwordstyle">
						<input type="text" name="password" value="$blog[password]" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')" placeholder="{lang password}" />
					</li>
					<div id="tb_selectgroup" class="mbm" style="$selectgroupstyle">
                    <li class="mbn">
						<div class="selectstyle">
								<select name="selectgroup" onchange="getgroup(this.value);">
									<option value="">{lang from_friends_group}</option>
									<!--{loop $groups $key $value}-->
									<option value="$key">$value</option>
									<!--{/loop}-->
								</select>								
						</div>
                    </li>
                    <li class="warningmessage">{lang choices_following_friends_list}</li>
                    <li><textarea name="target_names" id="target_names" rows="3" placeholder="{lang friend_name_space}">$blog[target_names]</textarea></li>                    
                    </div>
					<!--{if checkperm('manageblog')}-->
					<li><input type="text" name="hot" id="hot" value="$blog[hot]" placeholder="{lang hot}" /></li>
					<!--{/if}-->
                    <li class="blog_set_ck">
                    <span><label><input type="checkbox" name="noreply" value="1" {if $blog[noreply]} checked="checked"{/if}><em>{lang comments_not_allowed}</em></label></span>
					<!--{if helper_access::check_module('feed')}-->						
					<span><label for="makefeed"><input type="checkbox" name="makefeed" id="makefeed" value="1" {if ckprivacy('blog', 'feed')} checked="checked"{/if}><em>{lang make_feed}</em></label></span>
                    <span><a href="home.php?mod=spacecp&ac=privacy&op=feed">{lang privacy_settings}</a></span>
					<!--{/if}-->
                    </li>
                    </ul>
                    </div>
                    </div>                    
					<!--{if $secqaacheck || $seccodecheck}-->
					<!--{subtemplate common/seccheck}-->
					<!--{/if}-->                    
                    </div>                    
    <div class="ftpost">
    <table cellspacing="0" cellpadding="0">
        <tr>
        <td>
            <div class="editor editordefault">
            <a href="javascript:;" class="postphoto"><input type="file" name="Filedata" id="filedata" accept="image/*" multiple="multiple" /></a>
            <a href="javascript:;" class="invideo editortab"></a>
            <a href="javascript:;" class="postsmilie editortab"></a>
            <i class="moreoption">{$langplus[option]}</i>         
            </div>
        </td>
        <th><button type="submit" id="issuance" class="formdialog ftbtn nopost" disable="true">{$langplus[newpost]}</button></th>
        </tr>
    </table>
    <div class="editor_item">
		<div class="hidebox">
		<div class="addlinks">
        <i class="vt-play"></i>
		<input type="text" name="video_link" id="video_link" autocomplete="off" placeholder="{$langplus[video_link]}" />
		<span class="addlinks_btn" onclick="ilink(ins_code_0())">{$langplus[insert]}</span>
		</div>
		<div class="addlinks">
        <i class="vt-music"></i>
		<input type="text" name="music_link" id="music_link" autocomplete="off" placeholder="{$langplus[music_link]}" />
		<span class="addlinks_btn" onclick="ilink(ins_code_1())">{$langplus[insert]}</span>
		</div>
		</div>
    	<!--{template home/space_smilies}-->
    </div>
    </div>    
		<input type="hidden" name="blogsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		</form>        
        
        <script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/ajaxfileupload.js?{VERHASH}"></script>
        <script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/buildfileupload.js?{VERHASH}"></script>        
        <script type="text/javascript">
            var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png, bmp' : imgexts;
            var STATUSMSG = {
                '-1' : '{lang uploadstatusmsgnag1}',
                '0' : '{lang uploadstatusmsg0}',
                '1' : '{lang uploadstatusmsg1}',
                '2' : '{lang uploadstatusmsg2}',
                '3' : '{lang uploadstatusmsg3}',
                '4' : '{lang uploadstatusmsg4}',
                '5' : '{lang uploadstatusmsg5}',
                '6' : '{lang uploadstatusmsg6}',
                '7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
                '8' : '{lang uploadstatusmsg8}',
                '9' : '{lang uploadstatusmsg9}',
                '10' : '{lang uploadstatusmsg10}',
                '11' : '{lang uploadstatusmsg11}'
            };
            var form = $('#blogform');
            $(document).on('change', '#filedata', function() {
                    popup.open('<div class="cloading"></div>');
        
                    uploadsuccess = function(data) {
                        if(data == '') {
                            popup.open('{lang uploadpicfailed}', 'alert');
                        }						                       
                        var dataarr = eval('('+data+')');        
                            popup.close();
                            $('#imglist').append('<li><span aid="'+dataarr['picid']+'" class="imgdel"><a href="javascript:;"></a></span><span class="post_img"><a href="javascript:;"><'+'img id="aimg_'+dataarr['picid']+'" src="'+dataarr['bigimg']+'" /></a></span><input type="hidden" name="picids['+dataarr['picid']+']" value="'+dataarr['picid']+'"></li>');   
                    };					
        
                    if(typeof FileReader != 'undefined' && this.files[0]) {
                    <!--{if $upimgnumber}-->
                    if(this.files.length < {$upimgnumber}) { var imgnumber = this.files.length; } else { var imgnumber = {$upimgnumber}; }
                    <!--{/if}-->
                    for(var i=0;i<{if $upimgnumber}imgnumber{else}this.files.length{/if};i++ ){
                        var file_data = [];
                        file_data.push(this.files[i]);
                        $.buildfileupload({
                            uploadurl:'misc.php?mod=swfupload&action=swfupload&operation=album&type=image',
                            files:file_data,
                            uploadformdata:{uid : "$_G[uid]", hash:"$swfconfig[hash]"},
                            uploadinputname:'Filedata',
                            maxfilesize:"$swfconfig[max]",
                            success:uploadsuccess,
                            error:function() {
                                popup.open('{lang uploadpicfailed}', 'alert');
                            }
                        });
                    }
        
                    } else {
        
                        $.ajaxfileupload({
                            url:'{misc.php?mod=swfupload&action=swfupload&operation=album&type=image',
                            data:{uid : $_G[uid], hash:"$swfconfig[hash]"},
                            dataType:'text',
                            fileElementId:'filedata',
                            success:uploadsuccess,
                            error: function() {
                                popup.open('{lang uploadpicfailed}', 'alert');
                            }
                        });
        
                    }
            });
            
            $(document).on('click', '.imgdel', function() {
                var obj = $(this);
                $.ajax({
                   type:'GET',
                   url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
                })
                .success(function(s) {
                   obj.parent().remove();
                })
                .error(function() {
                   popup.open('{lang networkerror}', 'alert');
                });
                return false;
            });	

            </script>            
        
<script type="text/javascript">
	$(document).ready(function() {
	$('.editordefault a.editortab').click(function(){
		if($(this).hasClass('on')){
			$('.ftbox').removeClass('keyht2');
		}else{
			$('.ftbox').addClass('keyht2');
		}
		$('.editordefault a').eq($(this).index()).toggleClass('on').siblings().removeClass('on');
		$('.hidebox').eq($(".editordefault a.editortab").index(this)).slideToggle().siblings().slideUp();
	});	
	$('.moreoption').click(function(){
		$(this).toggleClass('onoption');
		$('.menufly').addClass('infly'); 
		$('body').addClass('menufly_open');               		
	}); 	
	$('.vt-close').click(function(){
		$('.moreoption').removeClass('onoption');	
		$('.menufly').removeClass('infly'); 
		$('body').removeClass('menufly_open');               		
	});	
	});
	function ins_code_0(){
		var newvalue = $("#video_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#video_link").val("");
			editorclose();
			return "[flash=media]"+ newvalue +"[/flash]";
		}else{
			return "";
		}
	}
	function ins_code_1(){
		var newvalue = $("#music_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#music_link").val("");
			editorclose();
			return "[flash=mp3]"+ newvalue +"[/flash]";
		}else{
			return "";
		}
	}
	function editorclose(){		
		$('.editordefault a').removeClass('on');
		$('.hidebox').slideUp();
		$('.ftbox').removeClass('keyht2');
	}
</script>
            
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript">

function ilink(lk){$("#uchome-ttHtmlEditor").insertAtCaret(lk);}
function ismi(sl){$('#uchome-ttHtmlEditor').insertAtCaret(sl);}

$('#uchome-ttHtmlEditor').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {
		$('#issuance').removeClass('nopost').addClass('btnon');
		$('#issuance').attr('disable', 'false');
	} else {
		$('#issuance').removeClass('btnon').addClass('nopost');
		$('#issuance').attr('disable', 'true');
	}
});

$('#uchome-ttHtmlEditor').on('input focus', function(){
	$(this).css('height','auto');
	$(this).css('height',this.scrollHeight + 2); 
});

$('#issuance').on('click', function() {			
	var obj = $(this);
	if(obj.attr('disable') == 'true') {
		return false;
	}
});

$(document).on('change', '#privacy_friend', function() {
	var obj = $(this);
	if(obj.val() == 4) {
		$("#span_password").css('display', '');				
	} else {
		$("#span_password").css('display', 'none');				
	}			
	if(obj.val() == 2) {
		$("#tb_selectgroup").css('display', '');				
	} else {
		$("#tb_selectgroup").css('display', 'none');				
	}			
});

$(document).on('click', '.newsortbtn', function() {
	var newoption = $('#newsort').val();
	newoption = newoption.replace(/^\s+|\s+$/g,"");
	if (newoption != null && newoption != '') {
	$("#classid").prepend("<option value='new:"+newoption+"'>"+newoption+"</option>");
	$("#classid option:first").prop("selected", 'selected');	
	$("#mask, .dialogbox").hide();
		return true;
	} else {
		return false;
	}
});	
function getgroup(gid) {
	if(gid) {
		$.ajax({
			type:'GET',
			url:'home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid='+gid,
			dataType:'xml'
		})
		.success(function(s) {
			var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
			//smg = smg + ' ';
			$('#target_names').val(smg);
		});
	}
}	 
</script>
<!--{block footerplus}--><div class="ftbox"></div><!--{/block}-->
<!--{/if}-->
<!--{eval $nofooter = true; $nosopenmenu = true;}-->
<!--{template common/footer}-->