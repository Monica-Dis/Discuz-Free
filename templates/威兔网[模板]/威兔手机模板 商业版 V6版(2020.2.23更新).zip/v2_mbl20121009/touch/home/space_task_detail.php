<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $task['endtime']}--><p class="LKx3vya93zWB">{lang task_endtime}</p><!--{/if}-->

	<table cellpadding="0" cellspacing="0" class="nylb3VrP3Rdg">
		<tr>			
			<td colspan="2">
				<h1>$task[name]<!--{if $task[applicants]}--> <sup class="evXx4HZDPWdN">{$task[applicants]}</sup><!--{/if}--></h1>				
                <!--{if $task[period]}-->
					<div class="UBnfIx5U49RB">
					<!--{if $task[periodtype] == 0}-->
						{lang task_period_hour}
					<!--{elseif $task[periodtype] == 1}-->
						{lang task_period_day}
					<!--{elseif $task[periodtype] == 2}-->
						<!--{eval $periodweek = $_G['lang']['core']['weeks'][$task[period]];}-->
						{lang task_period_week}
					<!--{elseif $task[periodtype] == 3}-->
						{lang task_period_month}
					<!--{/if}-->
					</div>
				<!--{/if}-->
				$task[description]
			</td>
		</tr>
					<tr>
						<td>{lang task_reward}</td>
						<td>
                            <div class="ZVv7aHldQA8u">
							<!--{if $task['reward'] == 'credit'}-->
								{lang credits} $_G['setting']['extcredits'][$task[prize]][title] $task[bonus] $_G['setting']['extcredits'][$task[prize]][unit]
							<!--{elseif $task['reward'] == 'magic'}-->
								{lang magics_title} $task[rewardtext] $task[bonus] {lang magics_unit}
							<!--{elseif $task['reward'] == 'medal'}-->
								{lang medals} $task[rewardtext] <!--{if $task['bonus']}-->{lang expire} $task[bonus] {lang days} <!--{/if}-->
							<!--{elseif $task['reward'] == 'invite'}-->
								{lang invite_code} $task[prize] {lang expire} $task[bonus] {lang days}
							<!--{elseif $task['reward'] == 'group'}-->
								{lang usergroup} $task[rewardtext] <!--{if $task['bonus']}--> $task[bonus] {lang days} <!--{/if}-->
							<!--{else}-->
								{lang nothing}
							<!--{/if}-->
                            </div>
						</td>
					</tr>
					<!--{if $task['viewmessage']}-->
					<tr>
						<td></td>
                        <td>$task[viewmessage]</td>
					</tr>
					<!--{else}-->
					<tr>
						<td>{lang task_complete_condition}</td>
						<td>
						<!--{if $taskvars['complete']}-->
							<ul>
								<!--{loop $taskvars['complete'] $taskvar}-->
									<li>$taskvar[name] : $taskvar[value]</li>
								<!--{/loop}-->
							</ul>
						<!--{else}-->
							<p>{lang unlimited}</p>
						<!--{/if}-->
						</td>
					<!--{/if}-->
					<tr>
						<td>{$langplus[taskapplycondition]}</td>
						<td>
							<!--{if $task[applyperm] || $task[relatedtaskid] || $task[tasklimits] || $taskvars['apply']}-->
								<ul>
									<li><!--{if $task[grouprequired]}-->{lang usergroup}: $task[grouprequired] <!--{elseif $task['applyperm'] == 'member'}-->{lang task_general_users}<!--{elseif $task['applyperm'] == 'admin'}-->{lang task_admins}<!--{/if}--></li>
									<!--{if $task[relatedtaskid]}--><li>{lang task_relatedtask}: <a href="home.php?mod=task&do=view&id=$task[relatedtaskid]">$_G['taskrequired']</a></li><!--{/if}-->
									<!--{if $task[tasklimits]}--><li>{lang task_numlimit}: $task[tasklimits]</li><!--{/if}-->
									<!--{if $taskvars['apply']}-->
										<!--{loop $taskvars['apply'] $taskvar}-->
											<li>$taskvar[name]: $taskvar[value]</li>
										<!--{/loop}-->
									<!--{/if}-->
								</ul>
							<!--{else}-->
								<p>{lang unlimited}</p>
							<!--{/if}-->
						</td>
					</tr>
		<tr>
			<th colspan="2" class="CxuF3zH22Sei">
				<!--{if $allowapply == '-1'}-->
					<div class="Xi17YljQ3wWJ">
						<div class="OooWoIJp9xLn" style="width:{if $task[csc]}$task[csc]%{else}2px{/if};"></div>
						<span id="csc_$task[taskid]"{if $task[csc] == 100} style="color:#fff;"{/if}>{$task[csc]}%</span>
					</div>
					<div class="taskviewbtn{if $task[csc] < 100} taskcsc_no{/if}">
						<ul>
                        <li><a href="home.php?mod=task&do=draw&id=$task[taskid]" class="taskdialog{if $task[csc] >=100} taskbtn{else} taskbtn_no{/if}" >{$langplus[task_award]}</a></li>
						<!--{if $task[csc] < 100}--><li><a href="home.php?mod=task&do=delete&id=$task[taskid]" class="FMl5kGFSWgTB">{$langplus[task_del]}</a></li><!--{/if}-->
                        </ul>
					</div>                    
				<!--{elseif $allowapply == '-2'}-->
					<div class="ictbHS6qb0TN">{lang task_group_nopermission}</div>					
				<!--{elseif $allowapply == '-3'}-->
					<div class="ictbHS6qb0TN">{lang task_applies_full}</div>					
				<!--{elseif $allowapply == '-4'}-->
					<div class="ictbHS6qb0TN">{lang task_lose_on} $task[dateline]</div>
				<!--{elseif $allowapply == '-5'}-->
					<div class="ictbHS6qb0TN">{lang task_complete_on} $task[dateline]</div>
				<!--{elseif $allowapply == '-6'}-->
					<div class="ictbHS6qb0TN">{lang task_complete_on} $task[dateline] , {$task[t]}{lang task_applyagain}</div>					
				<!--{elseif $allowapply == '-7'}-->
					<div class="ictbHS6qb0TN">{lang task_lose_on} $task[dateline] , {$task[t]}{lang task_reapply}</div>
				<!--{elseif $allowapply == '2'}-->
					<div class="ictbHS6qb0TN">{lang task_complete_on} $task[dateline] , {lang task_applyagain_now}</div>
				<!--{elseif $allowapply == '3'}-->
					<div class="ictbHS6qb0TN">{lang task_lose_on} $task[dateline] , {lang task_reapply_now}</div>
				<!--{/if}-->
				<!--{if $allowapply > '0'}-->
					<div class="Vd1BWg9PrGfw">
                    <ul><li><a href="home.php?mod=task&do=apply&id=$task[taskid]" class="FMl5kGFSWgTB">{$langplus[task_apply]}</a></li></ul>
                    </div>
				<!--{/if}-->
			</th>
		</tr>
	</table>
    
<!--{if $allowapply == '-1'}-->
<script type="text/javascript">
		$(document).on('click', '.taskdialog', function() {
			var message = '{$langplus[task_completed]}';
			var obj = $(this);			
			popup.open('<div class="lmVdjV39q3EP"></div>');
			$.ajax({
				type : 'GET',
				url : obj.attr('href') + '&inajax=1',
				dataType : 'xml'
			})
			.success(function(s) {				
				var smg = s.lastChild.firstChild.nodeValue.split("|");					
				if(smg[0] == 100){	
					popup.open('<div class="57wo6jJ46Z4Q"><dt>'+message+'</dt></div>');	
				}else{
					popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg[1]+'</dt></div>');	
				}
				window.location.reload();
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});
</script>
<!--{/if}--> 