<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=space&uid=$value[uid]&do=album&view=me&from=space">{$space[username]}{lang eccredit_s}{lang album}</a><!--{/block}--> 
<!--{template common/header}-->
<div class="NkGgJbO2CQdl">
  <ul>
    <li class="E1x17Q9hYTmk"><a href="javascript:;" >$album['albumname']</a></li>
    <li class="4NW6I4iArIh3"><a href="javascript:;" >{$langplus[re_album]}</a></li>
    <li><a href="home.php?mod=space&do=album&view=all">{lang view_all}</a></li>
  </ul>
</div>
  <div class="22QH8w7MKUZo">
  <!--{if $albumlist}-->
  <ul class="BGsXNFoRc2Jv">
    <!--{if $albumlist}--> 
    <!--{loop $albumlist $key $albums}--> 
    <!--{loop $albums $akey $value}--> 
    <!--{eval $pwdkey = 'view_pwd_album_'.$value['albumid'];}-->
    <li>
    <div class="ghp7Duf7hZ4L">    
    <a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" class="YoKvEEpT00Z4">    
    <!--{if $value[pic]}-->    
    <!--{if $value['friend'] != 4 && ckfriend($value['uid'], $value['friend'], $value['target_ids'])}-->    
    <img src="$value[pic]" />
    <!--{elseif $value['picnum']}-->
    <img src="template/v2_mbl20121009/touch_plus/image/defaultphoto.png" />
    <!--{/if}-->
    <!--{/if}-->    
    <p><!--{if $value[albumname]}-->$value[albumname]<!--{else}-->{lang default_album}<!--{/if}--></p>
    <!--{if $value[picnum] >1}--><i>{$value[picnum]}P</i><!--{/if}-->
    </a>
    </div> 
    </li>
    <!--{/loop}--> 
    <!--{/loop}--> 
    <!--{/if}-->
  </ul>
  <!--{/if}-->
  </div> 
  
<script type="text/javascript">
$(document).ready(function(){
	$('.tabequal li.li_tab').click(function(){
		$(this).toggleClass('on');
		$('.hidebox').slideToggle(); 		
	});	
	})
</script>

  <!--{if $list}-->
      
    <ul id="alist" class="nNAqCthlpyId">      
      <!--{loop $list $key $value}-->      
      <li>
      <div class="ghp7Duf7hZ4L">
      <a href="home.php?mod=space&uid=$value[uid]&do=$do&picid=$value[picid]">
      <div class="YoKvEEpT00Z4">
      <!--{if $value[pic]}-->
      <!--{if $albumpictype == 1}-->
      <!--{eval $valuepic = pic_get($value['filepath'], 'album', '0', $value['remote']); }-->
      <img src="$valuepic" />
      <!--{else}-->
      <img src="$value[pic]" />
      <!--{/if}-->
      <!--{/if}-->
      </div>
      <div class="PFiyz1kpiQKG"><p><!--{if $value[title]}-->$value[title]<!--{else}--><span class="Q8lZLnjHfm2v">{echo dgmdate($value[dateline], 'Y-n-j')}</span><!--{/if}--></p><i class="vt-hot{if $value[hot]} orange{/if}"></i></div>
      </a>
      </div>
      </li>      
      <!--{/loop}-->      
    </ul>   
    
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=space&uid=$album[uid]&do=$do&id=$id#comment" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
	<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->      
    <!--{if $multi}-->$multi<!--{/if}--> 
    <!--{/if}-->

<!--{block footerthree}-->
<li><div class="lkzxUSeCuNPo"><a {if $_G[uid]}href="home.php?mod=spacecp&ac=upload"{else}href="javascript:;" onclick="popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');"{/if} class="i0a6HFurbhHA"><i class="WKeZSMVfZ14F"></i></a></div></li>
<!--{/block}-->

<!--{if $_G['uid']}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1">
    <!--{eval $favstate = C::t('home_favorite')->fetch_by_id_idtype($value[albumid],'albumid',$_G['uid']);}-->
    <!--{if $favstate && $_G['uid']}-->
    <a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="GVCQ6391pe2J"><i class="c5jXKWHqTOsX"></i></a>
    <!--{else}-->
    <a href="home.php?mod=spacecp&ac=favorite&type=album&id=$album[albumid]&spaceuid=$space[uid]&handlekey=sharealbumhk_{$album[albumid]}" class="tGT2vF1AFZp3" ><i class="a4TcRfVF4aiG"></i></a>
    <!--{/if}-->
    <!--{if ($_G[uid] == $album[uid]) && $space[self]}--><a href="{if $album[albumid] > 0}home.php?mod=spacecp&ac=album&op=edit&albumid=$album[albumid]{else}home.php?mod=spacecp&ac=album&op=editpic&albumid=0{/if}" class="EPSs1wRRyPfK"></a><!--{else}--><!--{if checkperm('managealbum') && $album[albumid] > 0}--><a href="home.php?mod=spacecp&ac=album&op=delete&albumid=$album[albumid]&uid=$album[uid]&handlekey=delalbumhk_{$album[albumid]}" class="EpUW9T1ihDc3"></a><!--{/if}--><!--{/if}-->
</div>
<!--{$ajaxsubmit_item}-->
<!--{/block}-->
<!--{/if}-->
<!--{else}-->
<!--{if !$pricount}--><div class="sqK9gG26iUGb">{lang no_pics}</div><!--{/if}-->
<!--{/if}-->

<!--{template common/footer}-->