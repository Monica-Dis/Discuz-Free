<?php echo 'From: DisM.taobao.com';exit;?>
<div class="zgcAmfGd8k96">
  <ul>
	<li $subactives[index]><a href="home.php?mod=magic&action=shop">{lang default}</a></li>
	<li $subactives[hot]><a href="home.php?mod=magic&action=shop&operation=hot">{lang top}</a></li>
    <!--{if $_G[setting][exchangestatus]}--><li><a href="home.php?mod=spacecp&ac=credit&op=exchange">{lang credit_exchange}</a></li><!--{/if}-->
    <!--{if $buylink || ($_G['setting']['ec_ratio'] && ($_G['setting']['ec_tenpay_opentrans_chnid'] || $_G['setting'][ec_tenpay_bargainor] || $_G['setting']['ec_account'])) || $_G['setting']['card']['open']}--><li><a href="{if $buylink}{$buylink}{else}home.php?mod=spacecp&ac=credit&op=buy{/if}">{lang buy_credits}</a></li><!--{/if}-->
</ul>
</div>
<!--{if $magiclist}-->
	<ul id="alist" class="bNgbKpfxkwOS">    
	<!--{loop $magiclist $key $magic}-->
		<li>
			<div class="DJ0u80zsSrkH" id="magic_$magic[identifier]">
            <!--{if $_G['group']['magicsdiscount']}--><i class="p4soLy1mJblM"></i><!--{/if}-->
            <div class="kQeZeG0uIvAr">
            <div class="oFiPKpx5f1dW"><img src="$magic[pic]" alt="$magic[name]" /></div>
			<div class="3htUHNX3nuJB">$magic[name]</div>
			<!--{if $operation == 'hot'}-->
            <p class="fJoRhBf6orOE">{lang sold} $magic[salevolume] {lang magics_unit}</p>
            <!--{else}-->
            <p class="fJoRhBf6orOE">
				<!--{if {$_G['setting']['extcredits'][$magic[credit]][unit]}}-->
					{$_G['setting']['extcredits'][$magic[credit]][title]} $magic[price] {$_G['setting']['extcredits'][$magic[credit]][unit]} / {lang magics_unit}
				<!--{else}-->
					$magic[price] {$_G['setting']['extcredits'][$magic[credit]][title]} / {lang magics_unit}
				<!--{/if}-->				
			</p> 
            <!--{/if}--> 
            </div>          
			<div class="1QQ5ld3aBsBt">
            <p>
				<!--{if $magic['num'] > 0}-->
					<a href="home.php?mod=magic&action=shop&operation=buy&mid=$magic[identifier]" class="F3pveqiOE331">{lang magics_operation_buy}</a>
					<!--{if $_G['group']['allowmagics'] > 1}-->					
                    <a href="home.php?mod=magic&action=shop&operation=give&mid=$magic[identifier]" class="F3pveqiOE331">{lang magics_operation_present}</a>
					<!--{/if}-->
				<!--{else}-->
					<span>{lang magic_empty}</span>
				<!--{/if}-->
            </p>
			</div>
            <div class="ZzDvCy6O9iT1"><p>$magic[description]</p></div>
            </div>
		</li>
	<!--{/loop}-->    
	</ul> 
    <div class="Es3s87mAHtE5"></div>
<script type="text/javascript">
$(document).ready(function(){
	$(document).on('click','.mg_data',function(){		
		var dataid = $(this).parent('.mg_car').attr('id'); 		
		$('#' + dataid + ' > .description').fadeIn();
		$('.close_m').show();
	})
	$('.close_m').off().on('touchstart',function(){		
		$('.description').fadeOut();	
		$(this).hide();
	});	
});
</script>       
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($magiccount / $_G['tpp']);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=magic&action=shop&operation=$operation" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->    
    
<!--{else}-->
	<div class="sqK9gG26iUGb">{lang data_nonexistence}</div>
<!--{/if}-->