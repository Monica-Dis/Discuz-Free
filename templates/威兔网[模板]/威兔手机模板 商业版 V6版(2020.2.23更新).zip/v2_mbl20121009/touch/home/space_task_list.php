<?php echo 'From: DisM.taobao.com';exit;?>
	<!--{if $tasklist}-->
		<table cellspacing="0" cellpadding="0" class="5UK7zgQ5FSgd">
			<!--{loop $tasklist $task}-->
				<tr>
					<td>
						<h1><a href="home.php?mod=task&do=view&id=$task[taskid]">$task[name]</a><!--{if $task[applicants]}--> <sup>{$task[applicants]}</sup><!--{/if}--></h1>
						<p class="ZzDvCy6O9iT1">$task[description]</p>
						<!--{if $_GET['item'] == 'doing'}-->
						<div class="P33rKjvFPb9w">
							<div style="width: {if $task[csc]}$task[csc]%{else}2px{/if};"></div>
							<span id="csc_$task[taskid]"{if $task[csc] == 100} style="color:#fff;"{/if}>{$task[csc]}%</span>
						</div>
						<!--{/if}-->
                        <div class="ZVv7aHldQA8u">						
                        <!--{if $task['reward'] == 'credit'}-->
							{lang credits} $_G['setting']['extcredits'][$task[prize]][title] $task[bonus] $_G['setting']['extcredits'][$task[prize]][unit]
						<!--{elseif $task['reward'] == 'magic'}-->
							{lang magics_title} $listdata[$task[prize]] $task[bonus] {lang magics_unit}
						<!--{elseif $task['reward'] == 'medal'}-->
							{lang medals} $listdata[$task[prize]] <!--{if $task['bonus']}-->{lang expire} $task[bonus] {lang days} <!--{/if}-->
						<!--{elseif $task['reward'] == 'invite'}-->
							{lang invite_code} $task[prize] {lang expire} $task[bonus] {lang days}
						<!--{elseif $task['reward'] == 'group'}-->
							{lang usergroup} $listdata[$task[prize]] <!--{if $task['bonus']}--> $task[bonus] {lang days} <!--{/if}-->
						<!--{/if}-->
                        </div>                        
					</td>
					<th>
						<!--{if $_GET['item'] == 'new'}-->
							<!--{if $task['noperm']}-->
								<a href="javascript:;" class="XFiV1DJfSyiC">{$langplus[task_nope]}</a>
							<!--{elseif $task['appliesfull']}-->
								<a href="javascript:;" class="XFiV1DJfSyiC">{$langplus[task_full]}</a>
							<!--{else}-->
								<a href="home.php?mod=task&do=apply&id=$task[taskid]" class="{if $task[scriptname] == gift}giftdialog{else}dialog{/if} taskbtn">{$langplus[task_apply]}</a>
							<!--{/if}-->
						<!--{elseif $_GET['item'] == 'doing'}-->
							<a href="home.php?mod=task&do=draw&id=$task[taskid]" class="taskdialog{if $task[csc] >=100} taskbtn{else} taskbtn_no{/if}" >{$langplus[task_award]}</a>
						<!--{elseif $_GET['item'] == 'done'}-->
							<!--{if $task['period'] && $task[t]}-->
                            <!--{if $task[allowapply]}--><a href="home.php?mod=task&do=apply&id=$task[taskid]" class="FMl5kGFSWgTB">{$langplus[task_apply]}</a><!--{else}--><a href="javascript:;" class="XFiV1DJfSyiC">{$langplus[task_wait]}</a><!--{/if}-->
                            <!--{/if}-->
						<!--{elseif $_GET['item'] == 'failed'}-->
							<!--{if $task['period'] && $task[t]}-->
                            <!--{if $task[allowapply]}--><a href="home.php?mod=task&do=apply&id=$task[taskid]" class="FMl5kGFSWgTB">{$langplus[task_apply]}</a><!--{else}--><a href="javascript:;" class="XFiV1DJfSyiC">{$langplus[task_wait]}</a><!--{/if}-->
                            <!--{/if}-->
						<!--{/if}-->
					</th>
				</tr>
			<!--{/loop}-->
		</table>
<!--{if $_GET['item'] == 'new'}-->                   
<script type="text/javascript">
		$(document).on('click', '.giftdialog', function() {
			var message = '{$langplus[task_completed]}';
			var obj = $(this);			
			popup.open('<div class="lmVdjV39q3EP"></div>');
			$.ajax({
				type : 'GET',
				url : obj.attr('href') + '&inajax=1',
				dataType : 'xml'
			})
			.success(function(s) {				
				popup.open(s.lastChild.firstChild.nodeValue);
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				popup.open('<div class="57wo6jJ46Z4Q"><dt>'+message+'</dt></div>');
				setTimeout(function(){					
					obj.parent().parent().remove();
					$(".dialogbox, #mask").fadeOut();
				}, 1500);	
			});
			return false;
		});
</script>
<!--{elseif $_GET['item'] == 'doing'}-->
<script type="text/javascript">
		$(document).on('click', '.taskdialog', function() {
			var message = '{$langplus[task_completed]}';
			var obj = $(this);			
			popup.open('<div class="lmVdjV39q3EP"></div>');
			$.ajax({
				type : 'GET',
				url : obj.attr('href') + '&inajax=1',
				dataType : 'xml'
			})
			.success(function(s) {				
				var smg = s.lastChild.firstChild.nodeValue.split("|");					
				if(smg[0] == 100){	
					popup.open('<div class="57wo6jJ46Z4Q"><dt>'+message+'</dt></div>');	
				}else{
					popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg[1]+'</dt></div>');	
				}
				window.location.reload();
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});
</script>
<!--{/if}-->        
	<!--{else}-->
    <div class="sqK9gG26iUGb"><!--{if $_GET['item'] == 'new'}-->{lang task_nonew}<!--{elseif $_GET['item'] == 'doing'}-->{lang task_nodoing}<!--{else}-->{lang data_nonexistence}<!--{/if}--></div>
	<!--{/if}-->