<?php echo 'From: DisM.taobao.com';exit;?>        
     <div id="smiliesdiv" class="{if $_G[inajax]}ajaxsmi{else}hidebox{/if}">
      <div id="fastsmilies">        
       <div class="smilies">
        <ul>
        <!--{if !$_G[inajax]}-->
        <li><img src="static/image/smiley/comcom/1.gif" onclick="ismi('[em:1:]')"/></li> 
        <li><img src="static/image/smiley/comcom/2.gif" onclick="ismi('[em:2:]')"/></li> 
        <li><img src="static/image/smiley/comcom/3.gif" onclick="ismi('[em:3:]')"/></li> 
        <li><img src="static/image/smiley/comcom/4.gif" onclick="ismi('[em:4:]')"/></li>
        <li><img src="static/image/smiley/comcom/6.gif" onclick="ismi('[em:6:]')"/></li> 
        <li><img src="static/image/smiley/comcom/7.gif" onclick="ismi('[em:7:]')"/></li> 
        <li><img src="static/image/smiley/comcom/8.gif" onclick="ismi('[em:8:]')"/></li>         
        <li><img src="static/image/smiley/comcom/9.gif" onclick="ismi('[em:9:]')"/></li>
        <li><img src="static/image/smiley/comcom/10.gif" onclick="ismi('[em:10:]')"/></li> 
        <li><img src="static/image/smiley/comcom/11.gif" onclick="ismi('[em:11:]')"/></li> 
        <li><img src="static/image/smiley/comcom/12.gif" onclick="ismi('[em:12:]')"/></li> 
        <li><img src="static/image/smiley/comcom/13.gif" onclick="ismi('[em:13:]')"/></li> 
        <li><img src="static/image/smiley/comcom/14.gif" onclick="ismi('[em:14:]')"/></li> 
        <li><img src="static/image/smiley/comcom/15.gif" onclick="ismi('[em:15:]')"/></li> 
        <li><img src="static/image/smiley/comcom/16.gif" onclick="ismi('[em:16:]')"/></li>         
        <li><img src="static/image/smiley/comcom/17.gif" onclick="ismi('[em:17:]')"/></li> 
        <li><img src="static/image/smiley/comcom/18.gif" onclick="ismi('[em:18:]')"/></li>
        <li><img src="static/image/smiley/comcom/22.gif" onclick="ismi('[em:22:]')"/></li> 
        <li><img src="static/image/smiley/comcom/23.gif" onclick="ismi('[em:23:]')"/></li> 
        <li><img src="static/image/smiley/comcom/24.gif" onclick="ismi('[em:24:]')"/></li>
        <li><img src="static/image/smiley/comcom/29.gif" onclick="ismi('[em:29:]')"/></li>
        <!--{else}-->
        <li><img src="static/image/smiley/comcom/2.gif" onclick="ismi('[em:2:]')"/></li> 
        <li><img src="static/image/smiley/comcom/3.gif" onclick="ismi('[em:3:]')"/></li>
        <li><img src="static/image/smiley/comcom/22.gif" onclick="ismi('[em:22:]')"/></li>
        <li><img src="static/image/smiley/comcom/11.gif" onclick="ismi('[em:11:]')"/></li>
        <li><img src="static/image/smiley/comcom/29.gif" onclick="ismi('[em:29:]')"/></li>
        <li><img src="static/image/smiley/comcom/6.gif" onclick="ismi('[em:6:]')"/></li>
        <li><img src="static/image/smiley/comcom/12.gif" onclick="ismi('[em:12:]')"/></li>
        <!--{/if}-->
        </ul>
       </div>
      </div>
     </div>
        