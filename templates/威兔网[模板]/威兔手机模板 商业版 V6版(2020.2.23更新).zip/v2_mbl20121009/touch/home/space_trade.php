<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $_GET[uid] && $_G['uid'] != $space[uid]}-->{$space[username]}{lang trade}<!--{else}-->$navtitle<!--{/if}--><!--{/block}-->
<!--{template common/header}-->
<!--{eval
	$_G['home_tpl_spacemenus'][] = "<a href=\"home.php?mod=space&do=trade\">{lang trade}</a>";
}-->
<!--{if $_GET[view] == 'eccredit'}-->
	<!--{eval
			$_G['home_tpl_spacemenus'][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=$do&view=eccredit\">{lang they_credit_rating}</a>";
	}-->
<!--{else}-->
	<!--{eval
		$_G['home_tpl_spacemenus'][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=$do&view=onlyuser\">{lang they_trade}</a>";
	}-->
<!--{/if}-->

<!--{if $_GET[uid] && $_G['uid'] != $space[uid]}-->
<div class="NkGgJbO2CQdl">
	<ul>
		<li class="E1x17Q9hYTmk"><a href="home.php?mod=space&do=trade&view=me&uid=$space[uid]">{lang sale_of_goods}</a></li>
		<li><a href="home.php?mod=space&uid=$space[uid]&do=trade&view=eccredit">{lang credit_rating}</a></li>
	</ul>
</div>
<!--{elseif $space[self]}-->
<div class="NkGgJbO2CQdl">
	<ul>
		<li$actives[me]><a href="home.php?mod=space&do=trade&view=me">{lang my_trade}</a></li>
		<li$actives[tradelog]><a href="home.php?mod=space&do=trade&view=tradelog">{lang trade_log}</a></li>
		<li><a href="home.php?mod=space&do=trade&view=eccredit">{lang credit_rating}</a></li>
		<li$actives[we]><a href="home.php?mod=space&do=trade&view=we">{$langplus[friendtrade]}</a></li>
	</ul>
</div>
<!--{/if}-->

<!--{if $_GET[view] == 'tradelog' && $space[uid] > 0}-->
<div class="rthtgygSziGe">
	<ul>
		<li$orderactives[sell]><a href="home.php?mod=space&do=trade&view=tradelog">{$langplus[trade]}{$langplus[data_log]}</a></li>
		<li$orderactives[buy]><a href="home.php?mod=space&do=trade&view=tradelog&type=buy">{$langplus[buy]}{$langplus[data_log]}</a></li>
	</ul>
</div>
<!--{/if}-->

		<!--{if $userlist}-->
			<div class="h69u1yvwMtsx">
			<div class="ifiKZQ0GkoOQ">
				<select name="fuidsel" onchange="fuidgoto(this.value);">
					<option value="">{lang all_friends}</option>
					<!--{loop $userlist $value}-->
					<option value="$value[fuid]"{$fuid_actives[$value[fuid]]}>$value[fusername]</option>
					<!--{/loop}-->
				</select>
			</div>
			</div>
				<script type="text/javascript">
					function fuidgoto(fuid) {
						var parameter = fuid != '' ? '&fuid='+fuid : '';
						window.location.href = 'home.php?mod=space&do=trade&view=we'+parameter;
					}
				</script>
		<!--{/if}-->
		<!--{if $_GET[view] == 'tradelog'}-->
			<!--{eval
				$selltrades = array('all' => '{lang trade_all}', 'trading' => '{lang trade_trading}', 'attention' => '{lang trade_attention}', 'eccredit' => '{lang trade_eccredit}', 'success' => '{lang trade_success}', 'refund' => '{lang trade_refund}', 'closed' => '{lang trade_closed}', 'unstart' => '{lang trade_unstart}');
			}-->
			<div class="Y9bh0nG2bBux">
				<div class="h69u1yvwMtsx">
				<div class="ifiKZQ0GkoOQ">
				<select onchange="filterTrade(this.value)">
					<!--{loop $selltrades $key $langstr}-->
					<option value="$key" {if $filter == $key} selected="selected"{/if}>$langstr</option>
					<!--{/loop}-->
				</select>
				</div>
				</div>
				<script type="text/javascript">
					function filterTrade(value) {
						window.location = 'home.php?mod=space&do=trade&view=tradelog&type=$viewtype&filter='+value;
					}
				</script>
				<!--{if $tradeloglist}-->
				<ul id="alist" class="seYLuOK9j9f1">
					<!--{loop $tradeloglist $tradelog}-->
						<li>
							<div class="D4TKQBITwU37">
								<!--{if $item == 'selltrades'}-->
								<a href="home.php?mod=space&uid=$tradelog[buyerid]&do=trade&view=eccredit" class="x9hHSPQjdnYg"><!--{avatar($tradelog[buyerid],small)}--></a>
								<!--{if $tradelog['buyerid']}--><a href="home.php?mod=space&uid=$tradelog[buyerid]&do=trade&view=eccredit">$tradelog[buyer]</a><!--{else}-->$tradelog[buyer]<!--{/if}-->
								<!--{else}-->
								<a href="home.php?mod=space&uid=$tradelog[sellerid]&do=trade&view=eccredit" class="x9hHSPQjdnYg"><!--{avatar($tradelog[sellerid],small)}--></a>
								<a href="home.php?mod=space&uid=$tradelog[sellerid]&do=trade&view=eccredit">$tradelog[seller]</a>
								<!--{/if}-->
								<span class="Q8lZLnjHfm2v"> <!--{if $viewtype == 'sell'}-->{lang trade_buyer}<!--{else}-->{lang trade_seller}<!--{/if}--></span>
								<em class="NF4sirzIB2jD">$tradelog[lastupdate]</em>
							</div>
                            <div class="ymri9IT9RM1p">
							<a href="forum.php?mod=viewthread&tid=$tradelog[tid]&do=tradeinfo&pid=$tradelog[pid]" class="V4QZtq6JcQTJ"><!--{if $tradelog['aid']}--><img src="{echo getforumimg($tradelog[aid])}" /><!--{else}--><img src="{IMGDIR}/nophotosmall.gif" /><!--{/if}--></a>
							<p class="LboqhQ5C6lzU"><a href="forum.php?mod=viewthread&tid=$tradelog[tid]&do=tradeinfo&pid=$tradelog[pid]">$tradelog[subject]</a> <span class="RYlc73y8yn72">�� $tradelog[number]</span></p>
							<p class="Q8lZLnjHfm2v">
								<!--{if $tradelog[price] > 0}-->
								 $tradelog[price] {lang trade_units}
								<!--{/if}-->
								<!--{if $tradelog[credit] > 0}-->
								 / {$extcredits[$creditid][title]} $tradelog[credit] {$extcredits[$creditid][unit]}
								<!--{/if}-->
                            </p>
							<p>
								<a href="forum.php?mod=trade&orderid=$tradelog[orderid]">
								<!--{if $tradelog['attend']}-->
								<span class="evXx4HZDPWdN">$tradelog[status]</span>
								<!--{else}-->
								$tradelog[status]
								<!--{/if}-->
								</a>
							</p>
							<div class="GQdyBQypul8r">
								<!--{if $_GET[type] == 'buy'}-->
								<!--{if ($tradelog[ratestatus] == 2 || $tradelog[ratestatus] == 0) && (strpos($tradelog[status],'green') !== false)}-->
								<!--{if $_G['uid'] == $tradelog[buyerid]}-->
								<a href="home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=0" >{lang eccredit1}</a>
								<!--{elseif $_G['uid'] == $tradelog[sellerid]}-->
								<a href="home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=1" >{lang eccredit1}</a>
								<!--{/if}-->
								<!--{/if}-->
								<!--{else}-->
								<!--{if ($tradelog[ratestatus] == 1 || $tradelog[ratestatus] == 0) && (strpos($tradelog[status],'green') !== false)}-->
								<!--{if $_G['uid'] == $tradelog[buyerid]}-->
								<a href="home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=0" >{lang eccredit1}</a>
								<!--{elseif $_G['uid'] == $tradelog[sellerid]}-->
								<a href="home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=1" >{lang eccredit1}</a>
								<!--{/if}-->
								<!--{/if}-->
								<!--{/if}-->
								<a href="forum.php?mod=trade&orderid=$tradelog[orderid]" >{$langplus[tradeinfo]}</a>
							</div>
                            </div>
                        </li>
					<!--{/loop}-->
				</ul>
				<!--{else}-->
					<div class="sqK9gG26iUGb">{lang data_nonexistence}</div>
				<!--{/if}-->
		</div>
		<!--{if $tplpages == 1}-->
		<!--{eval $totalpage = ceil($num / $perpage);}-->
		<!--{if $totalpage > $page}-->
		<a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
		<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
		<!--{/if}-->
		<!--{else}-->
		<!--{if $multi}-->$multi<!--{/if}-->
		<!--{/if}-->
		<!--{else}-->
			<!--{if $list}-->
				<ul id="alist" class="euX1PSwlNfbX">
					<!--{loop $list $key $value}-->
					<li>
						<div class="SDl0u8ZpYY57">
						<a href="forum.php?mod=viewthread&tid=$value[tid]&do=tradeinfo&pid=$value[pid]" class="Y8o1MBk1pAIi">
							<!--{if $value[displayorder] > 0}--><i class="EzyJlBP5W7u1"></i><!--{/if}-->
							<img src="{if $value[aid]}{echo getforumimg($value[aid])}{else}{IMGDIR}/nophoto.gif{/if}" />
						<h1>
							<!--{if $value[expiration] && $value[expiration] < $_G[timestamp] || $value[closed]}-->
							<em class="Q8lZLnjHfm2v">{$langplus[over]}</em>
							<!--{else}-->
							<!--{if $value[price] > 0}-->
							<em class="evXx4HZDPWdN">&yen;{$value[price]}</em>
							<i>$value[amount]{$langplus[piece]}</i>
							<!--{/if}-->
							<!--{/if}-->
							$value[subject]
						</h1>
						</a>
						<!--{if $userlist}-->
						<div class="iiQppFB2wIQS"><!--{avatar($value[sellerid],small)}--><a href="home.php?mod=space&uid=$value[sellerid]&do=profile">$value[seller]</a></div>
						<!--{/if}-->
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			<!--{else}-->
				<div class="sqK9gG26iUGb">{lang no_trade}</div>
			<!--{/if}-->
		<!--{if $tplpages == 1}-->
		<!--{eval $totalpage = ceil($count / $perpage);}-->
		<!--{if $totalpage > $page}-->
		<a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
		<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
		<!--{/if}-->
		<!--{else}-->
		<!--{if $multi}-->$multi<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->
<!--{template common/footer}-->