<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me">{$space[username]}{lang eccredit_s}{lang blog}</a><!--{/block}-->
<!--{template common/header}-->
<!--{if $brtnav == 1 && !$noheader}-->
<div class="4ptxL1L724dB">
<a href="forum.php?forumlist=1">{$langplus[bbs]}</a><span>&gt;</span><a href="home.php?mod=space&uid=$space[uid]&do=profile">{$space[username]}</a><span>&gt;</span><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me">{lang blog}</a>
</div>
<!--{/if}-->
  <div class="thname{if $viewtitletype == 1} vbtitle{/if}"><a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]">$blog[subject]</a></div>
  <div class="fU45eQ0OXQ7x">
  <div class="8Ua6Ae7A8lfy">  
  <a href="home.php?mod=space&uid=$space[uid]" class="r9COG0I1EFgN">{$space[username]}<!--{if $blog[hot]}--> <i class="pkYChm1IGa4f"></i><!--{/if}--></a>
  <span><!--{date($blog[dateline], 'u')}--></span>
  <!--{if $blog[viewnum] > 9999 }--><!--{eval $blog[viewnum] = round($blog[viewnum] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
  <!--{if $blog[viewnum]}-->$blog[viewnum]{$langplus[view]}<!--{/if}-->
  </div>
  <div class="DsMmwLk5qJsU">$blog[message]</div> 
  
  <!--{if $classarr[classname] || $blog[catname]}-->
  <div class="lnCRKi8ffdfG"> 
  <!--{if $classarr[classname]}--><a href="home.php?mod=space&uid=$blog[uid]&do=blog&classid=$blog[classid]&view=me">#{$classarr[classname]}</a><!--{/if}--><!--{if $blog[catname]}--><a href="home.php?mod=space&do=blog&view=all&catid=$blog[catid]">#{$blog[catname]}</a><!--{/if}-->
  </div>
  <!--{/if}-->
  
  <!--{if $blog[tag]}-->
  <div class="tagview{if $classarr[classname] || $blog[catname]} mtm{else} mtw{/if} mbm">
	<!--{eval $tagi = 0;}-->
	<!--{loop $blog[tag] $var}-->
	<!--{if $tagi}--> , <!--{/if}--><a href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
	<!--{eval $tagi++;}-->
	<!--{/loop}-->
  </div>
  <!--{/if}-->    
      
      <!--{if $blog[friend] != 3 && !$blog[noreply]}-->
      <!--{template home/space_click}-->
      <!--{/if}--> 
           
      <!--{if $_G[uid] == $blog[uid] || checkperm('manageblog')}--> 
      <div class="AXV3uT7AXRS8">
      <a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=delete&handlekey=delbloghk_{$blog[blogid]}" class="F3pveqiOE331"><i class="aPyV086aHjq3"></i></a>
      <a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=edit"><i class="HcGNy22c8avk"></i></a>      
      <a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=edithot&handlekey=bloghothk_{$blog[blogid]}" class="F3pveqiOE331"><i class="c17iFPR1sf2l"></i></a>
      </div> 
      <!--{/if}-->
      
   </div>
       
      <!--{if $blog[replynum] || (!$blog[noreply] && helper_access::check_module('blog'))}-->      
        <div class="Po2VX0NM7umZ">   
        <!--{if $blog[replynum] > 9999 }--><!--{eval $blog[replynum] = round($blog[replynum] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->                
        <div class="qrZcxEaXs8OF" id="ap_reply"><span><!--{if $blog[replynum]}-->{$blog[replynum]}<!--{/if}-->{$langplus[comment]}</span></div>
        <!--{if $count <= 0 }-->
        <div class="d5yNuqYAzkYt">
        <img src="template/v2_mbl20121009/touch_plus/image/sofa.png">
        $langplus[sofas_b]
        </div>
        <!--{else}-->      
        <div id="alist" class="HwKFWtPXAVEl">         
         <!--{loop $list $k $value}--> 
         <!--{template home/space_comment_li}--> 
         <!--{/loop}-->         
        </div>
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=space&uid=$blog[uid]&do=$do&id=$id#comment" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->   
    <!--{if $multi}-->$multi<!--{/if}--> 
    <!--{/if}-->    
    <!--{/if}-->
        <!--{if $count > 0 && $count < $perpage}-->
        <div class="eejJHkr1tiQK">$langplus[allcontent]</div>
        <!--{/if}--> 
        </div>       
    <!--{/if}-->
	<div class="o7XBIO2AbIOX" style="display:none;">
         <form id="quickcommentform_{$id}" action="home.php?mod=spacecp&ac=comment" method="post" autocomplete="off" >
         <ul class="70RMxsdq69z2"> 
         <li{if $secqaacheck || $seccodecheck} class="7V0aj6bIRtYR"{/if}><textarea id="comment_message" name="message" rows="3" class="NiHwjLW6XNJb" placeholder="{lang send_reply_fast_tip}"></textarea></li>
         <!--{if $secqaacheck || $seccodecheck}-->
         <li class="AVK4ckDbUu5b"><!--{subtemplate common/seccheck}--></li>
         <!--{/if}-->
         </ul>
         <input type="hidden" name="referer" value="home.php?mod=space&uid=$blog[uid]&do=$do&id=$id" />
         <input type="hidden" name="id" value="$id" />
         <input type="hidden" name="idtype" value="blogid" />
         <input type="hidden" name="handlekey" value="qcblog_{$id}" />
         <input type="hidden" name="commentsubmit" value="true" />
         <input type="hidden" name="quickcomment" value="true" />         
         <input type="hidden" name="formhash" value="{FORMHASH}" />
         <div class="JFisFvnvOOmR">
         <table cellspacing="0" cellpadding="0">
         <tr>
         <td>
         <div class="Mz5rBOTAtCag">
         <a href="javascript:;"{if $_G[uid]} onclick="$(this).toggleClass('on'); $('#smiliesdiv').slideToggle();"{/if} class="CzMyTphx0KVg"></a>          
         </div>
         </td>        
         <th><button type="submit" name="commentsubmit_btn" value="true" id="commentsubmit_btn" disable="true" class="1VzSWhv3Ko9w">{lang comment}</button></th>
         </tr>
         </table>
         <!--{template home/space_smilies}-->
         </div>
         </form>              
        </div>     
       
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript" >
<!--{if !$_G[uid]}-->
$('#comment_message').on('focus', function() {
	popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
	this.blur();
});
$('#commentsubmit_btn').on('click', function() {
	return false;
});	
<!--{else}-->
<!--{if !$blog[noreply] && helper_access::check_module('blog')}-->
<!--{if $secqaacheck || $seccodecheck}-->
var comment_message = sectxt = false;
<!--{/if}-->	
$('#comment_message').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {		
		<!--{if $secqaacheck || $seccodecheck}-->
		comment_message = true;	
		if(sectxt == true) {
			$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');				
		}
		<!--{else}-->
		$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');
		<!--{/if}-->		
	} else {		
		<!--{if $secqaacheck || $seccodecheck}-->
		comment_message = false;
		<!--{/if}-->
		$('#commentsubmit_btn').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
	}
	});	
	<!--{if $secqaacheck || $seccodecheck}-->
	$('.sectxt').on('keyup input', function() {
		var obj = $(this);
		if(obj.val()) {
			sectxt = true;	
			if(comment_message == true) {
				$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');				
			}
		} else {
			sectxt = false;
			$('#commentsubmit_btn').addClass('nopost').removeClass('btnon').attr('disable', 'true');				
		}
	});	
	<!--{/if}-->	
$('#commentsubmit_btn').on('click', function() {				
	var btobj = $(this);
	if(btobj.attr('disable') == 'true') {
		return false;
	}
	$('.postsmilie').removeClass('on');
	$('#smiliesdiv').slideUp();
	});	
function ismi(sl){ 
	$(".replymsg").insertAtCaret(sl); 
}
<!--{/if}-->
<!--{/if}-->
</script>

<!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') == false && strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') == false && (strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false)}-->
<div id="myshare" class="ysMRojn3XRKC"></div>
<div class="qytY6AvMLAlZ"></div>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/share.js?{VERHASH}"></script>
<script type="text/javascript"> var config={url:'{$_G['siteurl']}/home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]',title:'{$blog[subject]}',desc:'{$blog[subject]}',{if $logourl}img:'{$_G['siteurl']}/{$logourl}',{/if}};var share_obj=new myshare('myshare',config);</script>
<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false }-->
<div id="myshare"></div>
<div class="Bn5G6abKZdVY"></div>
<!--{else}-->
<div class="zddxUhbNB29m"><p>{$langplus[share_browser]}</p><img src="template/v2_mbl20121009/touch_plus/image/browser_share_icon.png"/></div>
<div class="qytY6AvMLAlZ"></div>
<!--{/if}-->
<div class="3BpUTDuPIV3L"></div>
<!--{block bottombutton}-->
<ul>
<li class="E2JMFR03EHf0"><span class="GddXLGiN3F9i">{if !$blog[noreply] && helper_access::check_module('blog')}{lang send_reply_fast_tip}{else}{$langplus['noreply']}{/if}</span></li> 
<li><a href="javascript:;" id="replyid"><i class="4TtPW6YVzyiQ"></i>{lang comment}</a><!--{if $blog[replynum]}-->
<!--{if $blog[replynum] > 9999 }-->           
<!--{eval $blog[replynum] = round($blog[replynum] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->  
<i class="r7wK0yKft2oO">{$blog[replynum]}</i>
<!--{/if}--></li>
<li>
<!--{eval $favstate = C::t('home_favorite')->fetch_by_id_idtype($blog['blogid'],'blogid',$_G['uid']);}-->
<!--{if $favstate && $_G['uid']}-->
<a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="DEpWPCcOgRkB"><i class="yUHLv4Ewx6zR"></i>$langplus[favorite]</a>
<!--{else}-->
<a href="home.php?mod=spacecp&ac=favorite&type=blog&id=$blog[blogid]&spaceuid=$blog[uid]&handlekey=favoritebloghk_{$blog[blogid]}" class="un5EcQmZbb1B"><i class="quKOCKMOWfuc"></i>$langplus[favorite]</a>
<!--{/if}-->
</li>
<li><a href="javascript:;" id="fshare"><i class="K8kYuvxODrq6"></i>$langplus[share]</a></li>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#fshare').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').addClass('weixinshare');
                $('.close_s1').show();
				<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false}-->
                $('#myshare').addClass('openshare');
                $('header, footer, .pt, .scroll_plus{if !$headershow}, .scroll_openmenu{/if}').addClass('onlypage');
				$('.close_s').show();
				<!--{else}-->
				$('.share_browser').fadeIn();
				$('.close_s').show();
				shareclosetime = setTimeout(function(){
					$('.share_browser, .close_s').hide()
					},4000);
				<!--{/if}-->
            });
            $('.close_s, .close_s1').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').removeClass('weixinshare');
                <!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false}-->
                $('#myshare').removeClass('openshare');
                $('header, footer, .pt, .scroll_plus{if !$headershow}, .scroll_openmenu{/if}').removeClass('onlypage');
				<!--{else}-->
				$('.share_browser').hide();
				clearTimeout(shareclosetime);
                <!--{/if}-->
                $(this).hide();
            });
        });
    </script>
</ul>
<!--{if !$blog[noreply] && helper_access::check_module('blog')}-->
<script type="text/javascript">	
$(document).ready(function(){		
	$('.fastreply{if $blog[replynum] <= 0 }, #replyid{/if}').click(function(){
		<!--{if !$_G[uid]}-->
		popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
		this.blur();
		<!--{else}-->
		$('.postbox').slideToggle();
		$('.close_p').delay(300).fadeIn();
		<!--{/if}-->		
	});
  <!--{if $blog[replynum] > 0 }-->
  $("#replyid").on("click",function(){
    $("html,body").animate({scrollTop:$("#ap_reply").offset().top},500)
  });
  <!--{/if}-->
	$('.close_p').click(function(){	
		$('.postbox').slideToggle();
		$(this).hide();
		$('#smiliesdiv').slideUp();	
		$('.postsmilie').removeClass('on');
	});  
});	
</script>
<!--{/if}-->
<!--{$ajaxsubmit_item}-->
<!--{/block}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1">
    <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}-->
    <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a>
    <!--{/if}-->
    <a href="forum.php" class="rnxgBOYPCeEM"></a>
    <!--{if $_G[uid] && helper_access::check_module('blog')}--><a href="home.php?mod=spacecp&ac=blog" class="vvuDzz6aN5Xe"></a><!--{/if}-->
    <a href="javascript:history.back();" class="VkmTmMvm1mAV"></a>
</div>
<!--{/block}-->
<!--{template common/footer}-->   