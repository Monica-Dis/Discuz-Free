<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="57wo6jJ46Z4Q" id="ajax_explain_menu">
	<form method="post" autocomplete="off" id="explainform_$id" action="home.php?mod=spacecp&ac=eccredit&op=explain&explainsubmit=yes">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="id" value="$id"/>
		<input type="hidden" name="explainsubmit" value="true" />
		<div class="2oDA4JD3ybdT"><textarea name="explanation" rows="5" placeholder="{lang reply}"></textarea></div>
		<dd>
			<button class="AwiHIvwIVEL4" type="submit" >{lang submit}</button>
			<a href="javascript:;" onclick="popup.close();">{lang close}</a>
		</dd>
	</form>
</div>
<!--{template common/footer}-->