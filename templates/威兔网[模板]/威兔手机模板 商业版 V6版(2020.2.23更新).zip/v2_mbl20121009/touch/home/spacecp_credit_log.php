<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=spacecp&ac=credit">{lang memcp_credit}</a><!--{/block}-->
<!--{template common/header}-->
<!--{hook/spacecp_credit_top_v2_mobile}-->
		<!--{subtemplate home/spacecp_credit_header}-->
			  <div class="rthtgygSziGe">
              <ul>
				<li {if $_GET[suboperation] != 'creditrulelog'} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=spacecp&ac=credit&op=log" >{lang credit_log}</a></li>
				<li {if $_GET[suboperation] == 'creditrulelog'} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=spacecp&ac=credit&op=log&suboperation=creditrulelog" >{lang credit_log_sys}</a></li>
              </ul>
              </div>

            <!--{if $_GET[suboperation] != 'creditrulelog'}-->
				
				<table cellspacing="0" cellpadding="0" class="2I5DRIDEciGf">
					<tr>
						<th width="60">{lang operation}</th>
						<th width="60">{lang credit_change}</th>
						<th>{lang detail}</th>
						<th width="60" style="padding-right:10px;">{lang changedateline}</th>
					</tr>
                    <tbody id="alist">					
                    <!--{loop $loglist $value}-->
					<!--{eval $value = makecreditlog($value, $otherinfo);}-->
					<tr>
						<td><!--{if $value['operation']}--><a href="home.php?mod=spacecp&ac=credit&op=log&optype=$value['operation']">$value['optype']</a><!--{else}-->$value['title']<!--{/if}--></td>
						<td>$value['credit']</td>
						<td style="word-break:break-all;"><!--{if $value['operation']}-->$value['opinfo']<!--{else}-->$value['text']<!--{/if}--></td>
						<td class="dG0U0gep9PGD">$value['dateline']</td>
					</tr>
					<!--{/loop}-->                    
                    </tbody>
				</table>

			<!--{elseif $_GET[suboperation] == 'creditrulelog'}-->
				<table cellspacing="0" cellpadding="0" class="2I5DRIDEciGf">                
					<tr>
						<th width="60">{lang action_name}</th>
						<th width="60">{lang total_time}</th>
						<th width="60">{lang cycles_num}</th>
						<!--{loop $_G['setting']['extcredits'] $key $value}-->
						<th width="" >$value[title]</th>
						<!--{/loop}-->
						<th width="60" style="padding-right:10px;">{lang last_award_time}</th>
					</tr>
					<tbody id="alist">
                    <!--{eval $i = 0;}-->
					<!--{loop $list $key $log}-->
					<!--{eval $i++;}-->
					<tr{if $i % 2 == 0} class="H0GFVnR1fsIu"{/if}>
						<td><a href="home.php?mod=spacecp&ac=credit&op=rule&rid=$log[rid]">$log[rulename]</a></td>
						<td>$log[total]</td>
						<td>$log[cyclenum]</td>
						<!--{loop $_G['setting']['extcredits'] $key $value}-->
						<!--{eval $creditkey = 'extcredits'.$key;}-->
						<td>$log[$creditkey]</td>
						<!--{/loop}-->
						<td class="dG0U0gep9PGD"><!--{date($log[dateline], 'Y-m-d H:i')}--></td>
					</tr>
					<!--{/loop}-->                    
                    </tbody>
				</table>
			<!--{/if}-->		 
            
    <!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->   
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->
<!--{template common/footer}-->