<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang edit_album}<!--{/block}--> 
<!--{eval $_G[home_tpl_titles] = array($album[albumname], '{lang album}');}-->
<!--{template common/header}-->

<!--{if $_GET['op']=='edit' || $_GET['op']=='editpic'}-->
<div class="NkGgJbO2CQdl">
	<ul>				
		<!--{eval $aid = $albumid ? $albumid : -1;}-->
        <li><a href="home.php?mod=space&uid=$album[uid]&do=album&view=me">{lang my_album}</a></li>
        <li><a href="home.php?mod=space&uid=$album[uid]&do=album&id=$aid"><!--{if $album['albumname']}-->{$album['albumname']}<!--{else}-->{lang default_album}<!--{/if}--></a></li>
		<li{if $_GET['op']=='edit'} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=spacecp&ac=album&op=edit&albumid=$albumid">{$langplus[editalbuminfo]}</a></li>
		<li{if $_GET['op']=='editpic'} class="E1x17Q9hYTmk"{/if}><a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$albumid">{lang edit_pic}</a></li>		
	</ul>
</div>
<!--{/if}-->

<!--{if $_GET['op'] == 'edit'}-->

			<form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=edit&albumid=$albumid">            
				<div class="z76GhPvFhhjY">
                <ul>
					<li><input type="text" id="albumname" name="albumname" value="$album[albumname]" placeholder="{lang album_name}" /></li>
					<li><textarea name="depict" id="depict" rows="3" placeholder="{lang album_depict}">$album[depict]</textarea></li>
					<!--{if $categoryselect}-->
                    <li class="Gndtj1o9dRc7">
                        <div class="ifiKZQ0GkoOQ">
							$categoryselect							
                        </div>
					</li>
                    <li class="IHUDUAqpiULT">{lang select_site_album_categories}</li>
					<!--{/if}-->					
					<li>
                        <div class="ifiKZQ0GkoOQ">
							<select name="friend" onchange="passwordShow(this.value);" id="privacy_friend">
								<option value="0"$friendarr[0]>{lang friendname_0}</option>
								<option value="1"$friendarr[1]>{lang friendname_1}</option>
								<option value="2"$friendarr[2]>{lang friendname_2}</option>
								<option value="3"$friendarr[3]>{lang friendname_3}</option>
								<option value="4"$friendarr[4]>{lang friendname_4}</option>
							</select>
                        </div>
					</li>
					<li id="span_password" style="$passwordstyle"><input type="text" name="password" value="$album[password]" placeholder="{lang password}" /></li>                    
                    <div id="tb_selectgroup" class="7V0aj6bIRtYR" style="$selectgroupstyle">					
					<li class="Gndtj1o9dRc7">
                        <div class="ifiKZQ0GkoOQ">
								<select name="selectgroup" onchange="getgroup(this.value);">
									<option value="">{lang from_friends_group}</option>
									<!--{loop $groups $key $value}-->
									<option value="$key">$value</option>
									<!--{/loop}-->
								</select>								
                        </div>                        
					</li> 
                    <li class="IHUDUAqpiULT">{lang choices_following_friends_list}</li>                   
					<li><textarea name="target_names" id="target_names" rows="3" placeholder="{lang friend_name_space}">$album[target_names]</textarea></li>					
                    </div>                    
							<input type="hidden" name="referer" value="{echo dreferer()}" />
							<input type="hidden" name="editsubmit" value="true" />
					<li class="wextu7Zj0EaY"><a href="home.php?mod=spacecp&ac=album&op=delete&albumid=$album[albumid]&handlekey=delalbumhk_{$album[albumid]}" id="album_delete_$album[albumid]" class="F3pveqiOE331">{lang delete_album}</a><button name="submit" type="submit" class="OZfY4019HcbO" value="true">{lang determine}</button></li>
                </ul>
                </div>
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			</form>
		<script type="text/javascript"> 
		$(document).on('change', '#privacy_friend', function() {
			var obj = $(this);
			if(obj.val() == 4) {
				$("#span_password").css('display', '');				
			} else {
				$("#span_password").css('display', 'none');				
			}			
			if(obj.val() == 2) {
				$("#tb_selectgroup").css('display', '');				
			} else {
				$("#tb_selectgroup").css('display', 'none');				
			}			
		});
		function getgroup(gid) {
			if(gid) {
				$.ajax({
					type:'GET',
					url:'home.php?mod=spacecp&ac=privacy&inajax=1&op=getgroup&gid='+gid,
					dataType:'xml'
				})
				.success(function(s) {
					var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
					$('#target_names').val(smg);							
				});
			}
		}
		</script>
<!--{elseif $_GET['op'] == 'editpic'}-->

		<!--{if $list}-->
        <div class="BexUEl7ulhpU">
        <div class="EoGfF3aL3jmv">
        <div class="IHUDUAqpiULT">{lang album_cover_notice}</div>
        <div class="nT5D1jVvx6GB">{lang delete_pic_notice}</div>
        </div>
			<form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=editpic&albumid=$albumid">
				<ul id="alist" class="kxMPtukhuEWa">
                    <!--{eval $common = '';}-->
					<!--{loop $list $value}-->
					<li>
						<div class="pppxmkiH0x8n">
							<i><input type="checkbox" name="ids[{$value[picid]}]" value="{$value[picid]}" {$value[checked]}></i>						
							<img src="$value[pic]" />
							<!--{eval $ids .= $common.$value['picid'].':'.$value['picid'];}-->
							<!--{eval $common = ',';}-->
							<!--{if $album[albumname]}--><a href="home.php?mod=spacecp&ac=album&op=setpic&albumid=$value[albumid]&picid=$value[picid]&handlekey=setpichk" id="a_picid_$value[picid]" class="F3pveqiOE331" ><p>{lang set_to_conver}</p></a><!--{/if}-->
						</div>
						<textarea name="title[{$value[picid]}]" rows="3" class="37MPj3byeK0P" placeholder="{$langplus[description]}">$value[title]</textarea><input type="hidden" name="oldtitle[{$value[picid]}]" value="$value[title]">
					</li>
					<!--{/loop}-->                    
                    </ul>
                    <div class="GhEa4qmFd0Fw">
							<div class="VVsJQrmApwaI">
                            <label for="chkall"><input type="checkbox" name="chkall" id="chkall" /></label>
							<button type="submit" name="editpicsubmit" value="true" class="RaNlmIdg40a2" onclick="this.form.action+='&subop=update';">{lang update_explain}</button>
							<button type="submit" name="editpicsubmit" value="true" class="RaNlmIdg40a2" onclick="this.form.action+='&subop=delete';return ischeck('theform', 'ids')">{lang delete}</button>
                            <!--{if $albumlist}-->
                            <button type="submit" name="editpicsubmit" value="true" class="RaNlmIdg40a2" onclick="this.form.action+='&subop=move';return ischeck('theform', 'ids')">{lang move_to}</button>
                            <!--{/if}-->
                            </div>
							<!--{if $albumlist}-->
						<div class="ifiKZQ0GkoOQ">
							<select name="newalbumid">
							<!--{loop $albumlist $key $value}-->
							<!--{if $albumid != $value[albumid]}--><option value="$value[albumid]">$value[albumname]</option><!--{/if}-->
							<!--{/loop}-->
							<!--{if $albumid>0}--><option value="0">{lang default_album}</option><!--{/if}-->
							</select>
						</div>
							<!--{/if}-->						
					</div>                                                       
				<input type="hidden" name="page" value="$page" />
				<input type="hidden" name="editpicsubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			</form>
            </div>            	           
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$albumid" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}--> 
    <!--{if $multi}-->$multi<!--{/if}-->  
    <!--{/if}-->
			<script type="text/javascript">
				$("#chkall").click(function(){
					if(this.checked){
						$("input[type='checkbox']").attr("checked","checked");
					}else{
						$("input[type='checkbox']").attr("checked",null);
					}
				});
			</script>             
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->
<!--{/if}-->
        <!--{block footerplus}--><div class="a87wGthEpSmH"></div><!--{/block}-->
        <!--{eval $nofooter = true;}-->
		<!--{else}-->
			<div class="sqK9gG26iUGb">{lang no_pics}</div>
		<!--{/if}-->

<!--{elseif $_GET['op'] == 'delete'}-->
	<div class="wPUq6sXBhE74">
    <form method="post" autocomplete="off" id="theform" name="theform" action="home.php?mod=spacecp&ac=album&op=delete&albumid=$albumid&uid=$_GET[uid]">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="J9nExUQn4LHm">
			<ul>
			<li>{lang delete_album_message}</li>
			<li class="Gndtj1o9dRc7">{lang the_album_pic}:</li>
            </ul>
            <div class="ifiKZQ0GkoOQ">
				<select name="moveto" >
					<option value="-1">{lang completely_remove}</option>
					<option value="0">{lang move_to_default_album}</option>
					<!--{loop $albums $value}-->
					<option value="$value[albumid]">{lang move_to} $value[albumname]</option>
					<!--{/loop}-->
				</select>
			</div>
		</div>
		<div class="CUPwdSVx7pa8"><button type="submit" name="submit" class="AwiHIvwIVEL4" value="true">{lang determine}</button></div>
	</form>
    </div>
<!--{elseif $_GET['op'] == 'edittitle'}-->
	<div class="wPUq6sXBhE74">
    <form id="titleform" name="titleform" action="home.php?mod=spacecp&ac=album&op=editpic&subop=update&albumid=$pic[albumid]" method="post" autocomplete="off" >
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="editpicsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="YHRcwmjjR4Yi">        
        <textarea name="title[{$pic[picid]}]" rows="5" placeholder="{lang edit_description}">$pic[title]</textarea>        
        </div>
		<div class="CUPwdSVx7pa8"><button type="submit" name="editpicsubmit_btn" class="AwiHIvwIVEL4" value="true">{lang update}</button></div>
	</form>
    </div>
<!--{elseif $_GET[op] == 'edithot'}-->
	<div class="wPUq6sXBhE74">
    <form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=album&op=edithot&picid=$picid">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="hotsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="2O4NNAeY4BS4">
            <ul>
			<li class="Gndtj1o9dRc7">{lang new_hot}:</li>
            <li class="m2eNVrMB63Zq"><input type="text" name="hot" value="$pic[hot]" /></li>
            </ul>
		</div>		
		<div class="CUPwdSVx7pa8"><button type="submit" name="btnsubmit" value="true" class="AwiHIvwIVEL4" >{lang determine}</button></div>		
	</form>
    </div>
<!--{elseif $_GET[op] == 'saveforumphoto'}-->
	<div class="wPUq6sXBhE74">
    <form id="saveforumphoto" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=album&op=saveforumphoto&aid=$_GET[aid]" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');return false;"{/if}>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="savephotosubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="aid" value="$_GET[aid]" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="J9nExUQn4LHm">
        <ul>
        <li>{lang save_to_album}</li>
        <li class="Gndtj1o9dRc7">{lang save_to}:</li>
        </ul>
		    <div class="ifiKZQ0GkoOQ">
			<select name="albumid">
			<!--{loop $albumlist $key $value}-->
				<option value="$value[albumid]">$value[albumname]</option>
			<!--{/loop}-->
			<option value="0">{lang default_album}</option>
			</select>
		    </div>
        </div>		
		<div class="CUPwdSVx7pa8"><button type="submit" name="btnsubmit" value="true" class="AwiHIvwIVEL4" >{lang determine}</button></div>
	</form>
    </div>
<!--{/if}-->

<!--{template common/footer}-->
