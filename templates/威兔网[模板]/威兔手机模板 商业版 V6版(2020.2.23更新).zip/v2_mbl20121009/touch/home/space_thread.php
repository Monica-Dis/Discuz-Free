<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $_G['uid'] == $space['uid']}-->{lang my_posts}<!--{else}-->{$navtitle}<!--{/if}--><!--{/block}-->
<!--{template common/header}-->
		<div class="NkGgJbO2CQdl">
			<ul>
                <li$orderactives[thread]><a href="home.php?mod=space&uid=$space[uid]&do=thread&from=space&type=thread">{lang topic}</a></li>
				<li{$orderactives[reply]}{$orderactives[postcomment]}><a href="home.php?mod=space&uid=$space[uid]&do=thread&from=space&type=reply">{lang reply}</a></li>
			</ul>
		</div>
        <!--{hook/space_thread_top_v2_mobile}-->

<!-- main threadlist start -->	
	<!--{if $list}-->
		<ul id="alist" class="HwKFWtPXAVEl">        
        <!--{loop $list $stid $thread}-->
        <!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
			<li class="home_thread_reply{if $mythreadlist == 1} mtb{else} bb{/if}">
            <div class="7V0aj6bIRtYR">
                    <!--{if $thread[folder] == 'lock'}--> 
                    <em>{lang close}</em> &middot; 
                    <!--{elseif $thread['special'] == 1}-->                                                                     
                    <em>{lang thread_poll}</em> &middot; 
                    <!--{elseif $thread['special'] == 2}--> 
                    <em>{lang thread_trade}</em> &middot;  
                    <!--{elseif $thread['special'] == 3}-->
                    <em>{lang thread_reward}</em> &middot;  
                    <!--{elseif $thread['special'] == 4}--> 
                    <em>{lang thread_activity}</em> &middot;  
                    <!--{elseif $thread['special'] == 5}--> 
                    <em>{lang thread_debate}</em> &middot; 
                    <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}--> 
                    <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;  
                    <!--{elseif $thread['digest'] > 0}--> 
                    <em class="GR92yicG3zyZ">$langplus[digest]</em> &middot; 
                    <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}--> 
                    <em class="0rM8odj7aKyi">$langplus[pic]</em> &middot;  
                    <!--{/if}-->
                    <!--{if $viewtype == 'reply' || $viewtype == 'postcomment'}-->
                    <a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$thread[pid]">$thread[subject]</a>
                    <!--{else}-->
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]">$thread[subject]</a>
                    <!--{/if}-->
                    </div>						
                        <!--{if $actives[me] && $viewtype=='reply'}-->
							<!--{loop $tids[$stid] $pid}-->                            
							<!--{eval $post = $posts[$pid];}-->
                            <p class="4OMyWztfE5K4">							
							<i class="8AQZIwEkuORO"></i>
                            <a href="forum.php?mod=redirect&goto=findpost&ptid=$thread[tid]&pid=$pid"><!--{if $post[message]}-->{$post[message]}<!--{else}-->......<!--{/if}--></a> 
                            <i class="vEw75LCL6ls0"></i>
                            </p>
							<!--{/loop}-->
                   		<!--{elseif $actives[me] && $viewtype=='postcomment'}-->
						    <p class="4OMyWztfE5K4">
                            <i class="8AQZIwEkuORO"></i>
                            $thread[comment]
                            <i class="vEw75LCL6ls0"></i>
                            <p>					
						<!--{/if}-->
			</li>
        <!--{else}-->                    
                    <!--{if $mythreadlist == 1}-->                    
                    <!--{eval $msgnumber = 120; $imgnumber = 3; }-->
                    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/threadlist.php');}-->
                    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/mediaplayer.php');}-->
                    <li class="glWm8KGGo5r7">
                    <div class="EpRp4gnHNBzx">
                    <!--{if $thread['authorid'] && $thread['author']}-->
                    <a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="x9hHSPQjdnYg"><img src="<!--{avatar($thread[authorid],middle,true)}-->" /></a> 
					<!--{else}-->
					<a href="javascript:;" class="x9hHSPQjdnYg"><img src="<!--{avatar($thread[authorid],middle,true)}-->" /></a>
                    <!--{/if}--> 
                    <span class="lhcsTc3xRkO8">
                    <!--{if $thread['authorid'] && $thread['author']}-->
                    <a href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
					<!--{else}-->
					<a href="javascript:;">$_G[setting][anonymoustext]</a>
                    <!--{/if}-->
                    </span>                   
                    <span class="99u2LxYcMOhO">                    
                    {$thread[dateline]} <span class="RB4F49dgNi61">/</span>                    
                    <a href="forum.php?mod=forumdisplay&fid=$thread[fid]" class="Q8lZLnjHfm2v">$forums[$thread[fid]]</a>
                    </span>                    
                    </div>                    
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="yUloUBxjglb3">
                    <h1>
                    <!--{if $thread[folder] == 'lock'}--> 
                    <em>{lang close}</em> &middot; 
                    <!--{elseif $thread['special'] == 1}-->                                                                     
                    <em>{lang thread_poll}</em> &middot; 
                    <!--{elseif $thread['special'] == 2}--> 
                    <em>{lang thread_trade}</em> &middot; 
                    <!--{elseif $thread['special'] == 3}-->
                    <em>{lang thread_reward}</em> &middot; 
                    <!--{elseif $thread['special'] == 4}--> 
                    <em>{lang thread_activity}</em> &middot; 
                    <!--{elseif $thread['special'] == 5}--> 
                    <em>{lang thread_debate}</em> &middot; 
                    <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}--> 
                    <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;  
                    <!--{/if}-->
					<!--{if $thread['digest'] > 0}-->
					<em class="GR92yicG3zyZ">$langplus[digest]</em> &middot; 
					<!--{/if}-->
                    {$thread[subject]}
                    </h1>
                    <!--{if $thread['msg'] && ( !$thread['thumb'] && !$mediaplayer )}--><p>{$thread['msg']}</p><!--{/if}-->                    
                    <!--{if $thread['thumb'] && !$mediaplayer}-->
                    <!--{eval $picnumber = count($thread['thumb']); }-->
                    <!--{if $picnumber == 1}-->
                    <div class="eV6QZvlP57vk">
                    <!--{loop $thread['thumb'] $attach}-->                    
                    <!--{eval $imagethumb = getforumimg($attach['aid'], 0, 360, 0); }-->
                    <img src="$imagethumb" />
                    <!--{/loop}--> 
                    </div>                   
                    <!--{elseif $picnumber == 2}-->
                    <div class="3oUBU5xoDoYu">
                    <!--{loop $thread['thumb'] $attach}-->                    
                    <!--{eval $imagethumb = getforumimg($attach['aid'], 0, 300, 180); }-->
                    <div><img src="$imagethumb" /></div>
                    <!--{/loop}-->
                    </div>                    
                    <!--{else}-->                    
                    <div class="UjUdLLZpI86a">
                    <!--{loop $thread['thumb'] $attach}-->                    
                    <!--{eval $imagethumb = getforumimg($attach['aid'], 0, 200, 180); }-->
                    <div><img src="$imagethumb" /></div>
                    <!--{/loop}-->
                    </div>                    
                    <!--{/if}-->
                    <!--{/if}-->
                    </a>
                    <!--{if $mediaplayer}--><div class="D0tnebHrGksS">$mediaplayer</div><!--{/if}-->
                    <div class="4HoDN69BghU7">
                    <ul> 
                    <!--{if $thread[recommends] > 9999 }-->
                    <!--{eval $thread[recommends] = round($thread[recommends] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[favtimes] > 9999 }-->
                    <!--{eval $thread[favtimes] = round($thread[favtimes] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[replies] > 9999 }-->
                    <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[views] > 9999 }-->
                    <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[replies] > 9999 }-->
                    <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $_G['setting']['recommendthread']['status']}-->
                    <li><i class="NjmDx3gkHCuh"></i><span>{$thread[recommend_add]}</span></li>
                    <!--{else}-->
                    <li><i class="a4TcRfVF4aiG"></i><span>{$thread[favtimes]}</span></li>
                    <!--{/if}-->
                    <li><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra={$extra}{if $thread[replies] > 0}#ap_reply{/if}" class="go_reply"><i class="qwZjl2muVz4e"></i><span>{$thread[replies]}</span></a></li>
                    <li><i class="ikp213E0ZDtg"></i><span>{$thread[views]}</span></li>
                    </ul>
                    </div>                                        
                    </li>                    
                    <!--{else}-->
                    <li class="0SjyuQop6KJp">                    
                    <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="yUloUBxjglb3">
                    <h1>
                    <!--{if $thread[folder] == 'lock'}--> 
                    <em>{lang close}</em> &middot; 
                    <!--{elseif $thread['special'] == 1}-->                                                                     
                    <em>{lang thread_poll}</em> &middot; 
                    <!--{elseif $thread['special'] == 2}--> 
                    <em>{lang thread_trade}</em> &middot; 
                    <!--{elseif $thread['special'] == 3}-->
                    <em>{lang thread_reward}</em> &middot; 
                    <!--{elseif $thread['special'] == 4}--> 
                    <em>{lang thread_activity}</em> &middot; 
                    <!--{elseif $thread['special'] == 5}--> 
                    <em>{lang thread_debate}</em> &middot; 
                    <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}--> 
                    <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;  
                    <!--{/if}-->
					<!--{if $thread['digest'] > 0}-->
					<em class="GR92yicG3zyZ">$langplus[digest]</em> &middot; 
					<!--{/if}-->
                    {$thread[subject]}
                    </h1>             
                    <div class="hNOK3poJcpFf">                    
                    <span>$forums[$thread[fid]]</span>
                    <span>{$thread[dateline]}</span>
                    <!--{if $thread[favtimes] > 9999 }-->
                    <!--{eval $thread[favtimes] = round($thread[favtimes] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[replies] > 9999 }-->
                    <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[views] > 9999 }-->
                    <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <span class="99u2LxYcMOhO">
                    <!--{if $thread[favtimes]}-->
                    {$thread[favtimes]}{lang favorite} <cite class="RB4F49dgNi61">/</cite>
                    <!--{/if}-->
                    <!--{if $thread[replies]}-->                  
                    {$thread[replies]}{lang reply}
                    <!--{else}-->
                    {$thread[views]}{$langplus[view]}
                    <!--{/if}-->
                    </span>
                    </div>
                    </a>                    
                    </li> 
                    <!--{/if}-->
        <!--{/if}-->
		<!--{/loop}-->        
        </ul>
	<!--{else}-->
		<div class="sqK9gG26iUGb">{lang no_related_posts}</div>
	<!--{/if}-->
    
    <!--{if $tplpages == 1}--> 
    <!--{if $multi}-->   
    <!--{eval $totalpage = ceil(1000 / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{/if}-->
    <!--{else}-->    
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->
    
<!-- main threadlist end -->
<!--{template common/footer}-->