<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang password_authentication}<!--{/block}--> 
<!--{eval $navtitle = {lang password_authentication};}-->
<!--{template common/header}-->
<!--{if $_G['inajax']}-->
<div class="ajaxpop">
  <form method="post" autocomplete="off"  id="invalueform" name="invalueform" action="home.php?mod=misc&ac=inputpwd">
    <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
    <input type="hidden" name="refer" value="$_SERVER[REQUEST_URI]" />
    <input type="hidden" name="blogid" value="$invalue[blogid]" />
    <input type="hidden" name="albumid" value="$invalue[albumid]" />
    <input type="hidden" name="pwdsubmit" value="true" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <ul class="inputall b_pw pbm bb">
    <li class="smf">{lang enter_password}</li>
    <li class="mbn"><input type="password" name="viewpwd" value="" /></li>   
    </ul>
    <div class="hm"><button type="submit" name="submit" value="true" class="formsdialog button2">{lang submit}</button></div>
  </form>
</div>
<script type="text/javascript">
		$(document).on('click', '.formsdialog', function() {
			popup.open('<div class="cloading"></div>');
			var obj = $(this);
			var formobj = $(this.form);
			$.ajax({
				type:'POST',
				url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
				data:formobj.serialize(),
				dataType:'xml'
			})
			.success(function(s) {				
				var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
				popup.open('<div class="tip"><dt>'+smg+'</dt></div>');
				window.location.reload();			
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});
</script>
<!--{else}-->
<div class="bw">
  <form method="post" autocomplete="off"  id="invalueform" name="invalueform" action="home.php?mod=misc&ac=inputpwd">
    <input type="hidden" name="refer" value="$_SERVER[REQUEST_URI]" />
    <input type="hidden" name="blogid" value="$invalue[blogid]" />
    <input type="hidden" name="albumid" value="$invalue[albumid]" />
    <input type="hidden" name="pwdsubmit" value="true" />
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <ul class="inputall b_pw pbm">
    <li>{lang enter_password}</li>
    <li class="mbs"><input type="password" name="viewpwd" value="" /></li>
    <li><button type="submit" name="submit" value="true" class="formdialog button5">{lang submit}</button></li>
    </ul>
  </form>
</div>
<!--{/if}-->
<!--{template common/footer}-->