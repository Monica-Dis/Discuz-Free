<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang credit_rating}<!--{/block}-->
<!--{template common/header}-->
		<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=eccredit&op=rate" id="postform">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="referer" value="{echo dreferer()}" />
			<input type="hidden" name="ratesubmit" value="true">
				<div class="z76GhPvFhhjY">
					<ul>
						<li class="zwmeSsabmtwT">
							{lang eccredit_retee}:
							<!--{if $_G['uid'] == $order[buyerid]}-->
							<a href="home.php?mod=space&uid=$order[sellerid]&do=profile">$order[seller]</a>
							<!--{else}-->
							<a href="home.php?mod=space&uid=$order[buyerid]&do=profile">$order[buyer]</a>
							<!--{/if}-->
						</li>
						<li class="vOGCx5RHRkYA">
							{lang eccredit_tradegoods}:
							<a href="forum.php?mod=redirect&goto=findpost&pid=$order[pid]">$order[subject]</a>
						</li>
						<li class="mY01P89jiFr8">
							<label for="rate_good"><input id="rate_good" name="score" value="1" type="radio" checked="checked" /><span style="color:red"><img src="{STATICURL}image/traderank/good.gif" border="0" width="14" height="16" class="OV2bpjsRvqFH" /> {lang eccredit_good}</span></label>
							<label for="rate_soso"><input id="rate_soso" name="score" value="0" type="radio" /><span style="color:green"><img src="{STATICURL}image/traderank/soso.gif" border="0" width="14" height="16" class="OV2bpjsRvqFH" /> {lang eccredit_soso}</span></label>
							<label for="rate_bad"><input id="rate_bad" name="score" value="-1" type="radio" /><img src="{STATICURL}image/traderank/bad.gif" border="0" width="14" height="16" class="OV2bpjsRvqFH" /> {lang eccredit_bad}</label>
						</li>
						<li><textarea name="message" rows="6" placeholder="{lang eccredit1}" ></textarea></li>
					</ul>
						<input type="hidden" name="orderid" value="$orderid">
						<input type="hidden" name="type" value="$type">
					<div class="aS6jsuXgjvju">
						<button type="submit" class="pymKRL3JTNW2" id="postsubmit" >{lang submit}</button>
					</div>
				</div>
		</form>
<!--{block footerplus}--><div class="a87wGthEpSmH"></div><!--{/block}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->