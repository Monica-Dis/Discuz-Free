<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=spacecp&ac=credit">{lang memcp_credit}</a><!--{/block}-->
<!--{template common/header}-->
<!--{hook/spacecp_credit_top_v2_mobile}-->		
		<!--{subtemplate home/spacecp_credit_header}-->
		<!--{if in_array($_GET['op'], array('base', 'buy', 'transfer', 'exchange'))}-->
        <div class="kn8g5JhtMfsj">
			<ul>
			<!--{eval $creditid=0;}-->
			<!--{if $_GET['op'] == 'base' && $_G['setting']['creditstrans']}-->
				<!--{eval $creditid=$_G['setting']['creditstrans'];}-->
				<!--{if $_G['setting']['extcredits'][$creditid]}-->
				<!--{eval $credit=$_G['setting']['extcredits'][$creditid]; }-->
				<li><p>{$credit[title]}</p><span><!--{echo getuserprofile('extcredits'.$creditid);}--></span></li>
				<!--{/if}-->
			<!--{/if}-->
			<!--{loop $_G['setting']['extcredits'] $id $credit}-->
				<!--{if $id!=$creditid}-->
				<li><p>{$credit[title]}</p><span><!--{echo getuserprofile('extcredits'.$id);}--></span></li>
				<!--{/if}-->
			<!--{/loop}-->
			<!--{if  $_GET['op'] == 'base'}-->
				<li><p>{lang credits}</p><span>{$_G['member']['credits']}</span></li>
			<!--{/if}-->			
			</ul>
        </div>
		<!--{/if}-->
        
		<!--{if $_GET['op'] == 'base'}-->
        	<h1 class="lk6dWFWN7EzT">
            	{lang memcp_credits_log}
			</h1>
			<table cellspacing="0" cellpadding="0" class="uOH5HGzZVRIC">				
				<tr>
					<th width="60">{lang operation}</th>
					<th width="60">{lang logs_credit}</th>
					<th>{lang detail}</th>
					<th width="60" style="padding-right:10px;">{lang changedateline}</th>
				</tr>
			<!--{if $loglist}-->
				<!--{loop $loglist $value}-->
				<!--{eval $value = makecreditlog($value, $otherinfo);}-->
				<tr>
					<td><!--{if $value['operation']}--><a href="home.php?mod=spacecp&ac=credit&op=log&optype=$value['operation']">$value['optype']</a><!--{else}-->$value['title']<!--{/if}--></td>
					<td>$value['credit']</td>                    
					<td style="word-break:break-all;"><!--{if $value['operation']}-->$value['opinfo']<!--{else}-->$value['text']<!--{/if}--></td>
                    <td class="dG0U0gep9PGD">$value['dateline']</td>					
				</tr>
				<!--{/loop}-->
			<!--{else}-->
				<tr><td colspan="4"><div class="sqK9gG26iUGb">{lang memcp_credits_log_none}</div></td></tr>
			<!--{/if}-->            
			</table>

		<!--{elseif $_GET['op'] == 'buy'}-->
        
        <!--{if $buylink}-->
        <!--{eval dheader("location: $buylink");exit; }-->
        <!--{else}-->
        <div class="sqK9gG26iUGb">{$langplus[nofunction]}</div>
        <!--{/if}-->
        
		<!--{elseif $_GET['op'] == 'transfer'}-->

			<!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
			<form id="transferform" name="transferform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=transfer">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="transfersubmit" value="true" />
				<input type="hidden" name="handlekey" value="transfercredit" />
				<table cellspacing="0" cellpadding="0" class="yNLFCmEJrFgA">
					<tr>
						<th class="DD4tTWDYHfaA">{lang memcp_credits_transfer}:</th>
						<td class="DD4tTWDYHfaA">
							<input type="text" name="transferamount" id="transferamount" size="4" style="width: auto;" value="0" />
							<span class="wAub6tJzGnI0">{$_G[setting][extcredits][$_G[setting][creditstransextra][9]][title]}{lang credits_give}</span>
							<input type="text" name="to" id="to" size="11" style="width:auto;" />
						</td>
                        </tr>
                        <tr><th></th>                        
						<td  class="ZIxpOtbJtB6a" style="padding:2px 10px 7px;">
							{lang memcp_credits_transfer_min_balance} {$_G[setting][transfermincredits]} {$_G[setting][extcredits][$_G[setting][creditstransextra][9]][unit]} &nbsp;
							<!--{if intval($taxpercent) > 0}--><span class="evXx4HZDPWdN">{lang credits_tax} $taxpercent</span><!--{/if}-->
						</td>
					</tr>
					<tr>
						<th>{lang transfer_login_password}:</th>
						<td><input type="password" name="password" value="" /></td>
					</tr>
					<tr>
						<th>{lang credits_transfer_message}:</th>
						<td><input type="text" name="transfermessage" /></td>
					</tr>
					<tr>
						<td colspan="2" style="padding:30px 10px 80px;">
							<button type="submit" name="transfersubmit_btn" id="transfersubmit_btn" class="pymKRL3JTNW2" value="true">{lang memcp_credits_transfer}</button>
							<span style="display: none" id="return_transfercredit"></span>
						</td>
					</tr>
				</table>
			</form>
			<!--{/if}-->

		<!--{elseif $_GET['op'] == 'exchange'}-->

			<!--{if $_G[setting][exchangestatus] && ($_G[setting][extcredits] || $_CACHE['creditsettings'])}-->
			<form id="exchangeform" name="exchangeform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=exchange&handlekey=credit">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="operation" value="exchange" />
				<input type="hidden" name="exchangesubmit" value="true" />
				<input type="hidden" name="outi" value="" />
				<table cellspacing="0" cellpadding="0" class="yNLFCmEJrFgA">
					<tr>
						<th class="DD4tTWDYHfaA">{lang memcp_credits_exchange}:</th>
						<td class="DD4tTWDYHfaA">
							<input type="text" id="exchangeamount" name="exchangeamount" size="4" class="UHZdsvt1DGY2" style="width:auto;" value="0" onkeyup="exchangecalcredit()" />
							<select name="tocredits" id="tocredits" onChange="exchangecalcredit()">
							<!--{loop $_G[setting][extcredits] $id $ecredits}-->
								<!--{if $ecredits[allowexchangein] && $ecredits[ratio]}-->
									<option value="$id" unit="$ecredits[unit]" title="$ecredits[title]" ratio="$ecredits[ratio]">$ecredits[title]</option>
								<!--{/if}-->
							<!--{/loop}-->
							<!--{eval $i=0;}-->

							<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
								<!--{if $data[title]}-->
								<option value="$id" outi="$i">$data[title]</option>
								<!--{/if}-->
							<!--{/loop}-->
							</select>
							<span class="wAub6tJzGnI0">{$langplus[credit_need]}</span>
							<input type="text" id="exchangedesamount" size="5" style="width: auto; display:none;" value="0" disabled="disabled" />
							<select name="fromcredits" id="fromcredits_0" onChange="exchangecalcredit();">
							<!--{loop $_G[setting][extcredits] $id $credit}-->
								<!--{if $credit[allowexchangeout] && $credit[ratio]}-->
									<option value="$id" unit="$credit[unit]" title="$credit[title]" ratio="$credit[ratio]">$credit[title]</option>
								<!--{/if}-->
							<!--{/loop}-->
							</select>
							<!--{eval $i=0;}-->
							<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
								<select name="fromcredits_$i" id="fromcredits_$i" onChange="exchangecalcredit()" style="display: none">
								<!--{loop $data[creditsrc] $id $ratio}-->
									<option value="$id" unit="$_G['setting']['extcredits'][$id][unit]" title="$_G['setting']['extcredits'][$id][title]" ratiosrc="$data[ratiosrc][$id]" ratiodesc="$data[ratiodesc][$id]">$_G['setting']['extcredits'][$id][title]</option>
								<!--{/loop}-->
								</select>
							<!--{/loop}-->

						</td>
                        </tr>
                        <tr><th></th>
						<td class="ZIxpOtbJtB6a" style="padding:2px 10px 7px;">
							<!--{if $_G[setting][exchangemincredits]}-->
								{lang memcp_credits_exchange_min_balance} {$_G[setting][exchangemincredits]} &nbsp;
							<!--{/if}-->							
							<!--{if intval($taxpercent) > 0}-->
								<span class="evXx4HZDPWdN">{lang credits_tax} $taxpercent</span>
							<!--{/if}-->
						</td>
					</tr>
					<tr>
						<th>{lang transfer_login_password}:</th>
						<td><input type="password" name="password" value="" /></td>
					</tr>
					<tr>						
						<td colspan="2" style="padding:30px 10px 80px;">
							<button type="submit" name="exchangesubmit_btn" id="exchangesubmit_btn" class="pymKRL3JTNW2" value="true" tabindex="2">{lang memcp_credits_exchange}</button>
						</td>
					</tr>
				</table>
			</form>			
			<!--{/if}-->
		<!--{else}-->
			{eval
				$_TPL['cycletype'] = array(
					'0' => '{lang one_time}',
					'1' => '{lang everyday}',
					'2' => '{lang the_time}',
					'3' => '{lang interval_minutes}',
					'4' => '{lang open_cycle}'
				);
			}
			<div class="slfSSacIgWoN">
            <p class="nT5D1jVvx6GB">{lang activity_award_message}</p>
            </div>
			<table cellspacing="0" cellpadding="0" class="uOH5HGzZVRIC">
				<tr>
					<th width="60" >{lang action_name}</th>
					<th width="60" >{lang cycle_range}</th>
					<th width="60" >{$langplus[maxawardperweek]}</th>
					<!--{loop $_G['setting']['extcredits'] $key $value}-->
					<th >$value[title]</th>
					<!--{/loop}-->
				</tr>
				<!--{eval $i = 0;}-->
				<!--{loop $list $key $value}-->
				<!--{eval $i++;}-->
				<tr{if $i % 2 == 0} class="H0GFVnR1fsIu"{/if}>
					<td>$value[rulename]</td>
					<td>$_TPL[cycletype][$value[cycletype]]</td>
					<td><!--{if $value[rewardnum]}-->$value[rewardnum]<!--{else}-->{lang unlimited_time}<!--{/if}--></td>
					<!--{loop $_G['setting']['extcredits'] $key $credit}-->
					<!--{eval $creditkey = 'extcredits'.$key;}-->
					<td><!--{if $value[$creditkey] > 0}-->+$value[$creditkey]<!--{elseif $value[$creditkey] < 0}-->$value[$creditkey]<!--{else}-->0<!--{/if}--></td>
					<!--{/loop}-->
				</tr>
				<!--{/loop}-->
			</table>
		<!--{/if}-->
<!--{template common/footer}-->