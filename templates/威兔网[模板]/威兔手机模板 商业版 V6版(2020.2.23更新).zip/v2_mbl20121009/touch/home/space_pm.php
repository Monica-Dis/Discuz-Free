<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if in_array($_GET[subop], array('view'))}--><!--{if $_GET[plid] && $_GET[type] && !$touid}-->{lang chat_type}<!--{else}-->{lang pm_with} $tousername {lang pm_totail}<!--{/if}--><!--{else}-->{lang pm_center}<!--{/if}--><!--{/block}-->
<!--{eval $_G['home_tpl_titles'] = array('{lang pm}');}-->
<!--{if in_array($_GET[subop], array('view'))}--><!--{if $_GET[plid] && $_GET[type]}--><!--{eval $navtitle = {lang chat_type};}--><!--{else}--><!--{eval $navtitle = {lang pm_with}.$tousername.{lang pm_totail};}--><!--{/if}--><!--{else}--><!--{eval $navtitle = {lang pm_center};}--><!--{/if}-->
<!--{template common/header}-->
<!--{if in_array($filter, array('privatepm')) || in_array($_GET[subop], array('view'))}-->
	<!--{if in_array($filter, array('privatepm'))}-->    
		<div class="NkGgJbO2CQdl">
			<ul>
				<li class="E1x17Q9hYTmk"><a href="home.php?mod=space&do=pm">{lang pm_center}</a></li>
				<li><a href="home.php?mod=spacecp&ac=pm">{lang send_pm}</a></li>
			</ul>
		</div>
	<!-- main pmlist start -->
		<ul id="alist" class="K5RFhQr8y50B">
			<!--{loop $list $key $value}-->
			<li>       
				<a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}" class="uVFJ19RryL0A">
                <img class="UoRZiAghxSa8" src="{if $value[pmtype] == 2}template/v2_mbl20121009/touch_plus/image/grouppm.png{else}{avatar($value[touid] ? $value[touid] : ($value[lastauthorid] ? $value[lastauthorid] : $value[authorid]), middle, true)}{/if}" />
                <!--{if $value[new]}--><span class="3wDnqcV7SSmT">$value[pmnum]</span><!--{/if}-->
					<div class="IRqyczrMViLK">						
						<!--{if $value[touid]}-->
							<!--{if $value[msgfromid] == $_G[uid]}-->
								<span class="bm82kek51fSh">{lang me}{lang you_to} {$value[tousername]} {lang say}</span>
							<!--{else}-->
								<span class="bm82kek51fSh">{$value[tousername]} {lang you_to}{lang me}{lang say}</span>
							<!--{/if}-->
						<!--{elseif $value['pmtype'] == 2}-->
							<span class="bm82kek51fSh">{lang chatpm_author} $value['firstauthor']</span>
						<!--{/if}-->                        
                        	<span class="RbNS32WUh48w"><!--{date($value[dateline], 'u')}--></span>
					</div>
					<div class="pmmes{if $value[new]} pmnum{/if}">						
						<!--{if $value['pmtype'] == 2}--><p>[{lang chatpm}] <!--{if $value[subject]}-->$value[subject]<!--{/if}--></p><!--{/if}--><!--{if $value['pmtype'] == 2 && $value['lastauthor']}--><p>{$value['lastauthor']}: $value[message]</p><!--{else}--><!--{if $value[message]}--><p>$value[message]</p><!--{/if}--><!--{/if}-->
					</div>
				</a>
			</li>
			<!--{/loop}-->
		</ul>        
        
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / 15);}-->
	<!--{if $totalpage > $page}-->   
    <a href="home.php?mod=space&do=pm&filter=$filter" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->
	<!-- main pmlist end -->
	<!--{elseif in_array($_GET[subop], array('view'))}-->
		<div class="NkGgJbO2CQdl">
			<ul>
				<li><a href="home.php?mod=space&do=pm">{lang pm_center}</a></li>
                <li class="E1x17Q9hYTmk"><a href="javascript:;">{lang viewmypm}</a></li>
				<li><a href="home.php?mod=spacecp&ac=pm">{lang send_pm}</a></li>
			</ul>
		</div>
	<!-- main viewmsg_box start -->
			<!--{if !$list}-->
            <!--{eval dheader("location: home.php?mod=space&do=pm");exit; }-->
				<div class="sqK9gG26iUGb">{lang no_corresponding_pm}</div>
			<!--{else}-->
			<!--{if $multi && $tplpages == 1}-->
			<!--{eval $totalpage = ceil($count / $perpage); }-->
			<!--{if $totalpage > 1}-->   
				<a href="{if $_GET[plid] && $_GET[type] && !$touid}home.php?mod=space&do=pm&subop=view&plid=$plid&type=$type{else}home.php?mod=space&do=pm&subop=view&touid=$touid{/if}" class="E5VMDvvS4OF5" data-num="0-{$page}"><span>$langplus[more_pm]</span></a> 
				<script type="text/javascript">var language = {'loading_pm':' {$langplus[load_pm]}', 'view_more_pm': '{$langplus[more_pm]}'};</script>
				<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage_pm.js?{VERHASH}"></script>
			<!--{/if}-->
			<!--{/if}-->                       
				<div id="alist" class="6uJD8OFNILGO" >                
                <!--{loop $list $key $value}-->
                <!--{if $value[msgfromid] != $_G['uid']}-->
                <div class="8HIg7U6A2zN4">
                	<a href="home.php?mod=space&uid=$value[msgfromid]&do=profile" class="UoRZiAghxSa8"><img src="<!--{avatar($value[msgfromid], middle, true)}-->" /></a>
                    <div class="6D68c5J6AY34"><!--{date($value[dateline], 'u')}--></div>
                	<div class="7zIkXk2QIJ7e">$value[message]</div>
                </div>
                <!--{else}-->
                <div class="54jD6buCAcBs">
                	<img class="UoRZiAghxSa8" src="<!--{avatar($value[msgfromid], middle, true)}-->" />
                    <div class="6D68c5J6AY34"><!--{date($value[dateline], 'u')}--></div>
                	<div class="Db7yhvizGh8A">$value[message]</div>
                </div>
                <!--{/if}-->
				<!--{/loop}--> 
                <!--{if $multi && $tplpages == 1 && $page < $totalpage}--><div class="Daa33M37X5c9"><span>{$langplus[di]} $page {$langplus[page]}</span></div><!--{/if}-->                            
                </div>
            <!--{if $multi && !$tplpages}-->            
            <div class="mVM4FPhwZ4oz">$multi</div>            
            <script type="text/javascript">            
            	$(document).on('dblclick','.pmlist',function(){	
            		$('.pmpage').fadeToggle();	
            	});
            </script> 
            <!--{/if}-->
			<!--{/if}-->
		<!--{if $list}-->
        <div class="JFisFvnvOOmR">
            <form id="pmform" class="eea6PdjRGshR" name="pmform" method="post" action="home.php?mod=spacecp&ac=pm&op=send&pmid=$pmid&daterange=$daterange&pmsubmit=yes&mobile=2" >
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<!--{if !$touid}-->
			<input type="hidden" name="plid" value="$plid" />
			<!--{else}-->
			<input type="hidden" name="touid" value="$touid" />
			<!--{/if}-->
            <table cellspacing="0" cellpadding="0">
            <tr>
			<td><input type="text" value="" autocomplete="off" id="replymessage" name="message" placeholder="{lang send_reply_fast_tip}" class="6ozkWrMenDhi"></td>
			<th><input type="button" name="pmsubmit" id="pmsubmit" class="1VzSWhv3Ko9w" disable="true" value="{lang reply}" /></th>
            </tr>
            </table>
            </form>            
        <div class="XM6s3x42eeXx">        
		<div class="NqIHAYNYEwFZ">
		<a href="javascript:;" class="RNA6cfDIyWwZ"></a>
		<a href="javascript:;" class="OPIKyLwK6iQC"></a>
		<a href="javascript:;" class="8ZEzUDmgfRGH"></a>		
		</div>        
		<div class="llLJ43IWYvyD">            
		<div class="22QH8w7MKUZo">
		<div class="3LAI9IVO8Vpr">
        <i class="9EAJdkchBJVA"></i>
		<input type="text" name="img_link" id="img_link" autocomplete="off" placeholder="{$langplus[img_link]}" />
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_0())">{$langplus[insert]}</span>
		</div>
		</div>
		<div class="22QH8w7MKUZo">
		<div class="3LAI9IVO8Vpr">
        <i class="9EAJdkchBJVA"></i>
        <div class="oGYuEZ1uz6pO"><input type="text" name="links_link" id="links_link" autocomplete="off" placeholder="{$langplus[links_link]}" /></div>
        <div class="oGYuEZ1uz6pO"><input type="text" name="linkname_link" id="linkname_link" autocomplete="off" placeholder="{$langplus[linkname_link]}" /></div>
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_1())">{$langplus[insert]}</span>
		</div>
        </div>		
		<div id="smiliesdiv" class="22QH8w7MKUZo"><div id="fastsmilies"></div></div>
		</div>
        </div>        
        </div>
        <div class="qytY6AvMLAlZ"></div> 
<!--{if $_G[uid]}-->      
<script type="text/javascript">
	$(document).ready(function() {
	$('.editordefault a.editortab').click(function(){
		$('.editordefault a').eq($(this).index()).toggleClass('on').siblings().removeClass('on');
		$('.hidebox').eq($(".editordefault a.editortab").index(this)).slideToggle().siblings().slideUp();
	});	
	});		
	function ins_code_0(){
		var newvalue = $("#img_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#img_link").val("");
			editorclose();
			return "[img]"+ newvalue +"[/img]";
		}else{
			return "";
		}
	}	
	function ins_code_1(){
		var newvalue = $("#links_link").val();
		var newvalue2 = $("#linkname_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		newvalue2 = newvalue2.replace(/^\s+|\s+$/g,"");
		if(!newvalue2) {
			newvalue2 = newvalue;
		}
		if (newvalue) {
			$("#links_link").val("");
			$("#linkname_link").val("");
			editorclose();
			return "[url="+ newvalue +"]"+ newvalue2 +"[/url]";
		}else{
			return "";
		}
	}
	function editorclose(){		
		$('.editordefault a').removeClass('on');
		$('.hidebox').slideUp();		
	}		
</script>
<!--{/if}-->      
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>        
<script type="text/javascript" src="data/cache/common_smilies_var.js?eAa"></script>
<script type="text/javascript">

function ilink(lk){$('#replymessage').insertAtCaret(lk);}
function ismi(sl){	$('#replymessage').insertAtCaret(sl);}

var j = 1, smilies_fastdata = '', img;
if (smilies_array[{$smileid}][{$smilepg}].length > {$smilenumber}){smilienums = {$smilenumber};}else{smilienums = smilies_array[{$smileid}][{$smilepg}].length;}
for (i = 0; i < smilienums; i++) {	
	s = smilies_array[{$smileid}][{$smilepg}][i];	
    smilieimg = "static/" + 'image/smiley/' + smilies_type['_' + {$smileid}][1] + '/' + s[2];
    smilies_fastdata += s ? '<li><img src="' + smilieimg + '" onclick="ismi(\'' + s[1].replace(/'/, '\\\'') + '\')" />' : '</li>';
}
window.onload = function() {
    $('#fastsmilies').html('<div class="saMZOV8357GQ"><ul>' + smilies_fastdata + '</ul></div>');
}	
$('#replymessage').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {		
		$('#pmsubmit').removeClass('nopost').addClass('btnon').attr('disable', 'false');
	} else {		
		$('#pmsubmit').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
	}
	$('#replymessage').removeClass('nofocus');
	$('.fteditor').slideDown();
	$('.close_s').show();
	});	
$('#pmsubmit').on('click', function() {				
	var btobj = $(this);
	if(btobj.attr('disable') == 'true') {
		return false;
	}
	$('.fteditor').slideUp();
	});	
$('.close_s').off().on('touchstart',function(){
	var bt2obj = $('#pmsubmit');	
	if(bt2obj.attr('disable') == 'true') {
		$('#replymessage').blur().addClass('nofocus');			
	}
	$(this).hide();
	$('.fteditor, .hidebox').slideUp();	
	$('.editordefault a').removeClass('on');
	});	
</script>
<!--{block footerplus}--><div class="TyCJXL60MXvY"></div><!--{/block}-->            
<!--{eval $nofooter = true;}-->                    
	<!--{/if}-->	
	<!-- main viewmsg_box end -->
	<!--{/if}-->
<!--{else}-->
<div class="sqK9gG26iUGb">{lang user_mobile_pm_error}</div>
<!--{/if}-->

<!--{template common/footer}-->