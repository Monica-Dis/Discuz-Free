<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="home.php?mod=task">{lang task}</a><!--{/block}-->
<!--{template common/header}-->

<div class="NkGgJbO2CQdl">
  <ul>
	<li $actives[new]><a href="home.php?mod=task&item=new">{lang task_new}</a></li>
	<li $actives[doing]><a href="home.php?mod=task&item=doing">{$langplus[taskdoing]}</a></li>
	<li $actives[done]><a href="home.php?mod=task&item=done">{$langplus[taskdone]}</a></li>
	<li $actives[failed]><a href="home.php?mod=task&item=failed">{$langplus[taskfailed]}</a></li>
  </ul>
</div>

<div class="SBejHJurEfX1">
		<!--{if empty($do)}-->
			<!--{subtemplate home/space_task_list}-->
		<!--{elseif $do == 'view'}-->
			<!--{subtemplate home/space_task_detail}-->
		<!--{/if}-->	
</div>
<!--{template common/footer}-->