<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="portal.php?mod=list&catid=$cat[catid]">$cat[catname]</a><!--{/block}-->
<!--{template common/header}-->
<!--[name]{lang portalcategory_listtplname}[/name]-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->
<!--{if $brtnav == 1 && $_G['page'] > 1}-->
<div class="4ptxL1L724dB">
    <p><a href="forum.php">{$langplus[home]}</a><span>&gt;</span><!--{loop $cat[ups] $value}--><a href="{echo getportalcategoryurl($value[catid])}">$value[catname]</a><span>&gt;</span><!--{/loop}-->$cat[catname]</p>
</div>
<!--{/if}-->
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
<!--{if $adheadertopa && in_array($cat[catid],explode(",",$adheadertopida))}--><!--{$adheadertopa}--><!--{/if}-->
<!--{if $adheadertopb && in_array($cat[catid],explode(",",$adheadertopidb))}--><!--{$adheadertopb}--><!--{/if}-->
<!--{if $adheadertopc && in_array($cat[catid],explode(",",$adheadertopidc))}--><!--{$adheadertopc}--><!--{/if}-->
<!--{/if}-->

<!--{if $cat[others]}-->
<!--{if $sortmenufloat}--><div class="AtXpQP883jim"><!--{/if}-->
<div class="slidemenu{if $sortmenufloat} sortmenus{/if}">
    <div class="jqRecDJMSqQs">
        <ul class="qhUm3fRMfQIL">
            <!--{loop $cat[ups] $value}-->
            <li class="menu_slide{if $_GET[catid] == $value[catid]} a{/if}"><a href="{$portalcategory[$value['catid']]['caturl']}">$value[catname]</a></li>
            <!--{/loop}-->
            <!--{loop $cat[others] $value}-->
            <!--{if !in_array($value[catid],explode(",",$tplcatid))}-->
            <li class="menu_slide{if $_GET[catid] == $value[catid]} a{/if}"><a href="{echo getportalcategoryurl($value[catid]);}">$value[catname]</a></li>
            <!--{/if}-->
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{if $sortmenufloat}--></div><!--{/if}-->
<!--{/if}-->
<!--{if $cat[subs]}-->
<div class="iGjstsLHlHxi">
    <div class="5K8xLdxY5Hnw">
        <ul class="QEC9zkOzfDvc">
            <!--{loop $cat[subs] $value}-->
            <!--{if !in_array($value[catid],explode(",",$tplcatid))}-->
            <li class="SNBJcxs3eHns"><a href="{echo getportalcategoryurl($value[catid]);}">$value[catname]</a></li>
            <!--{/if}-->
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{/if}-->
<!--{if $cat[others] || $cat[subs]}-->
<script src="./template/v2_mbl20121009/touch_plus/js/swiper.min.js?{VERHASH}"></script>
<script type="text/javascript">
    <!--{if $cat[others]}-->
    $(function() {
        if ($('.slidemenu .a').length > 0) {
            var slidefocus = $('.slidemenu .a').offset().left + $('.slidemenu .a').width() >= $(window).width() ? $('.slidemenu .a').index() : 0;
        } else {
            var slidefocus = 0;
        }
        var swiper = new Swiper('.menu_container', {
            wrapperClass:'menu_wrapper',
            slideClass:'menu_slide',
            slidesPerView:'auto',
            freeMode:true,
            freeModeFluid:true,
            momentumBounce:true,
            initialSlide:slidefocus,
        });
    })
    <!--{/if}-->
    <!--{if $cat[subs]}-->
    var swiper = new Swiper('.menu_two_container', {
        wrapperClass:'menu_two_wrapper',
        slideClass:'menu_two_slide',
        slidesPerView:'auto',
        freeMode:true,
        freeModeFluid:true,
        momentumBounce:true,
        initialSlide:0,
    });
    <!--{/if}-->
</script>
<!--{/if}-->

<!--{if $list['count'] > 0}-->
<ul id="alist" class="A20lxnRaoXuO">
    <!--{eval $ad = 1;}-->
    <!--{loop $list['list'] $value}-->
    <!--{hook/list_middle_v2_mobile}-->
    <!--{if $page == 1}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adlista && in_array($cat[catid],explode(",",$adlistida)) && $ad == $adlisttha}--><!--{$adlista}--><!--{/if}-->
    <!--{if $adlistb && in_array($cat[catid],explode(",",$adlistidb)) && $ad == $adlistthb}--><!--{$adlistb}--><!--{/if}-->
    <!--{if $adlistc && in_array($cat[catid],explode(",",$adlistidc)) && $ad == $adlistthc}--><!--{$adlistc}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{eval $highlight = article_title_style($value);}-->
    <!--{eval $article_url = fetch_article_url($value);}-->
    <!--{eval $value['viewnum'] = DB::result_first("SELECT viewnum FROM ".DB::table("portal_article_count")." where aid=".$value[aid])}-->
    <!--{if $value['viewnum'] > 9999 }--><!--{eval $value['viewnum'] = round($value[viewnum] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->
    <li>
        <a href="portal.php?mod=view&aid=$value[aid]" class="portal_subject{if !$value[pic]} nopic{/if}">
            <!--{if $value[pic]}--><span class="eV6QZvlP57vk"><img src="$value[pic]" /></span><!--{/if}-->
            <div class="tlmwm5r8Nn9Q" $highlight>$value[title]</div>
            <!--{if $value[summary] && !$value[pic]}-->
            <p class="UBnfIx5U49RB">{echo cutstr(strip_tags($value[summary]),90)}</p>
            <!--{/if}-->
            <div class="eFyhs1FdehR0">
                $value[dateline]
                <!--{if $value[viewnum] > 0}-->
                <!--{if $value[viewnum] > 9999 }-->
                <!--{eval $value[viewnum] = round($value[viewnum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <span class="99u2LxYcMOhO">{$value[viewnum]}{$langplus[view]}</span>
                <!--{/if}-->
            </div>
        </a>
        <!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $value['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $value['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
        <span class="nRtPeHZZ0EOY"><a href="portal.php?mod=portalcp&ac=article&op=edit&aid=$value[aid]"class=""><i class="HcGNy22c8avk"></i></a><a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$value[aid]" class="F3pveqiOE331"><i class="aPyV086aHjq3"></i></a></span>
        <!--{/if}-->
    </li>
    <!--{eval $ad++;}-->
    <!--{/loop}-->
</ul>
<!--{else}-->
<div class="sqK9gG26iUGb">{$langplus[forum_nothreads]}</div>
<!--{/if}-->

<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($list['count'] / $cat['perpage']);}-->
<!--{if $totalpage > $page}-->
<a href="$cat['caturl']" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $list['multi']}-->{$list['multi']}<!--{/if}-->
<!--{/if}-->

<!--{if ($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])}-->
<!--{block footerthree}-->
<li><div class="lkzxUSeCuNPo"><a href="portal.php?mod=portalcp&ac=article&catid=$cat[catid]" class="i0a6HFurbhHA"><i class="RtBILaDhl45b"></i></a></div></li>
<!--{/block}-->
<!--{/if}-->
<!--{template common/footer}-->