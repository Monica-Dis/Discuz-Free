<?php echo 'From: DisM.taobao.com';exit;?>            
        <div id="comment">
        <div class="qrZcxEaXs8OF" id="ap_reply"><span>{lang latest_comment}</span></div>        
        <!--{loop $commentlist $comment}-->
		<!--{template portal/comment_li}-->
		<!--{/loop}-->
        </div>         
        <!--{if $data[commentnum] > 20}--><div class="ibmd7U0D0pF4"><a href="$common_url">{lang view_all_comments}</a></div><!--{/if}-->   
        <div class="o7XBIO2AbIOX" style="display:none;">
        <form id="cform" name="cform" action="$form_url" method="post" autocomplete="off">
        <ul class="70RMxsdq69z2">
        <li{if $secqaacheck || $seccodecheck} class="7V0aj6bIRtYR"{/if}><textarea name="message" id="message" rows="3" placeholder="{lang send_reply_fast_tip}"></textarea></li>
		<!--{if $secqaacheck || $seccodecheck}-->
		<li class="AVK4ckDbUu5b"><!--{subtemplate common/seccheck}--></li>
		<!--{/if}-->
		</ul>
		<div class="JFisFvnvOOmR">
		<table cellspacing="0" cellpadding="0">
		<tr>
		<td>
            <div class="Mz5rBOTAtCag">
            <a href="javascript:;"{if $_G[uid]} onclick="$(this).toggleClass('on'); $('#smiliesdiv').slideToggle();"{/if} class="CzMyTphx0KVg"></a>          
            </div>
		</td>        
		<th><button type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="true" disable="true" class="iE5tROBSAh66">{lang comment}</button></th>
        </tr>
        </table>
        <!--{template home/space_smilies}-->
        </div>            
			<!--{if !empty($topicid) }-->
				<input type="hidden" name="referer" value="portal.php?mod=topic&topicid=$topicid" />
				<input type="hidden" name="topicid" value="$topicid">
			<!--{else}-->
				<input type="hidden" name="portal_referer" value="portal.php?mod=view&aid=$aid">
				<input type="hidden" name="referer" value="portal.php?mod=view&aid=$aid" />
				<input type="hidden" name="id" value="$data[id]" />
				<input type="hidden" name="idtype" value="$data[idtype]" />
				<input type="hidden" name="aid" value="$aid">
			<!--{/if}-->
			<input type="hidden" name="formhash" value="{FORMHASH}">
			<input type="hidden" name="replysubmit" value="true">
			<input type="hidden" name="commentsubmit" value="true" />			
		</form>        
    </div>    
    
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript" >
<!--{if $nologinpost == 0 && !$_G[uid]}-->
$('#message').on('focus', function() {
	popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
	this.blur();
});
<!--{/if}-->
function ismi(sl){	$('#message').insertAtCaret(sl);}
function imes(mess){$('#message').insertAtCaret(mess);}	
	(function() {
		var form = $('#message');
		<!--{if $secqaacheck || $seccodecheck}-->
		var message = sectxt = false;
		<!--{else}-->
		var message = false;
		<!--{/if}-->		
		$('#message').on('keyup input focus', function() {
			var obj = $(this);
			if(obj.val()) {
				fastpostmessage = true;	
				<!--{if $secqaacheck || $seccodecheck}-->
				if(sectxt == true) {
					$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');					
				}
				<!--{else}-->
				$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');
				<!--{/if}-->
			} else {
				fastpostmessage = false;
				$('#commentsubmit_btn').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
			}
		});		
		<!--{if $secqaacheck || $seccodecheck}-->
		$('.sectxt').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				sectxt = true;	
				if(fastpostmessage == true) {
					$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');					
				}
			} else {
				sectxt = false;
				$('#commentsubmit_btn').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
			}
		});	
		<!--{/if}-->		
		$('#commentsubmit_btn').on('click', function() {		
			var btobj = $(this);
			if(btobj.attr('disable') == 'true') {
				return false;
			}
			$('.postsmilie').removeClass('on');
			$('#smiliesdiv').slideUp();	
			popup.open('<div class="lmVdjV39q3EP"></div>');
			var obj = $(this);
			var formobj = $(this.form);
			$.ajax({
				type:'POST',
				url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
				data:formobj.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
				evalscript(s.lastChild.firstChild.nodeValue);		
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});					
	})();
</script>