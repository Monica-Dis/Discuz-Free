<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval dheader("location: ./forum.php");exit; }-->

