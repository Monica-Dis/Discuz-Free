<?php echo 'From: DisM.taobao.com';exit;?>    
    <div class="97NCEgpOD2NN">
    <a href="{if !empty($comment['uid'])}home.php?mod=space&uid=$comment[uid]&do=profile{else}javascript:;{/if}" class="UoRZiAghxSa8"><!--{avatar($comment['uid'],middle)}--></a>
    <div class="lMiESRoMfTgX">	
    <!--{if !empty($comment['uid'])}-->
		<a href="home.php?mod=space&uid=$comment[uid]&do=profile">$comment[username]</a>
	<!--{else}-->
		<a href="javascript:;">{lang guest}</a>
	<!--{/if}-->
    <em class="Cl3R4A76eWd0"><!--{date($comment[dateline])}--></em>
    <!--{if $comment[status] == 1}--><em class="evXx4HZDPWdN">{lang moderate_need}</em><!--{/if}-->
    </div>    
    <div class="GoiR9H9DsEdV">
    <!--{if $_G[adminid] == 1 || $comment[uid] == $_G[uid] || $comment[status] != 1}-->$comment[message]<!--{else}-->{lang moderate_not_validate}<!--{/if}-->
    </div>
    <!--{if (($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']) || !isset($_G[makehtml])}-->
    <div class="vUZToXk9EwIO">
    <!--{if !isset($_G[makehtml])}-->
    <!--{eval $commentmessage = preg_replace("/<div.*?class=\"quote\">.*?<\/div>/s", '', $comment[message]);}-->    
    <a href="javascript:;"{if $_G[uid]} class="xzTagshgOfng" onclick="imes('[quote]{$comment[username]}: {echo cutstr(strip_tags($commentmessage),30)}[/quote]')"{/if}><i class="qwZjl2muVz4e"></i></a>
    <!--{/if}-->
	<!--{if ($_G['group']['allowmanagearticle'] || $_G['uid'] == $comment['uid']) && $_G['groupid'] != 7 && !$article['idtype']}-->
    <a href="portal.php?mod=portalcp&ac=comment&op=edit&cid=$comment[cid]" ><i class="HcGNy22c8avk"></i></a>
    <a href="portal.php?mod=portalcp&ac=comment&op=delete&cid=$comment[cid]" class="F3pveqiOE331" ><i class="aPyV086aHjq3"></i></a>
    <!--{/if}--> 	
    </div>
    <!--{/if}-->	
    </div>    