<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang comment}<!--{/block}-->
<!--{template common/header}-->
<div class="bZM4tz7gGcZs"><a href="$url">$csubject[title]</a></div>
    <div id="alist" class="HwKFWtPXAVEl">    
	<!--{loop $commentlist $comment}-->
	<!--{subtemplate portal/comment_li}-->
	<!--{/loop}-->    
	</div>    
    
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($csubject['commentnum'] / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="portal.php?mod=comment&id=$id&idtype=$idtype" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->      
    <!--{if $multi}-->$multi<!--{/if}-->
    <!--{/if}-->
      
           <!--{if $csubject['allowcomment'] == 1}-->
                <div class="o7XBIO2AbIOX" style="display:none;">
				<form id="cform" name="cform" action="portal.php?mod=portalcp&ac=comment" method="post" autocomplete="off">
					<ul class="70RMxsdq69z2">
                    <li{if $secqaacheck || $seccodecheck} class="7V0aj6bIRtYR"{/if}><textarea name="message" rows="3" id="message" placeholder="{lang send_reply_fast_tip}"></textarea></li>
					<!--{if $secqaacheck || $seccodecheck}-->
					<li class="AVK4ckDbUu5b"><!--{subtemplate common/seccheck}--></li>                    
					<!--{/if}-->
                    </ul>
					<!--{if $idtype == 'topicid' }-->
                        <input type="hidden" name="topicid" value="$id">
					<!--{else}-->
                        <input type="hidden" name="aid" value="$id">
					<!--{/if}-->
					<input type="hidden" name="formhash" value="{FORMHASH}">                    
					<input type="hidden" name="replysubmit" value="true">
					<input type="hidden" name="commentsubmit" value="true" />                                                          
					<div class="JFisFvnvOOmR">
					<table cellspacing="0" cellpadding="0">
					<tr>
					<td>
					<div class="Mz5rBOTAtCag">
					<a href="javascript:;"{if $_G[uid]} onclick="$(this).toggleClass('on'); $('#smiliesdiv').slideToggle();"{/if} class="CzMyTphx0KVg"></a>          
					</div>
					</td>        
					<th><button type="submit" name="commentsubmit" id="commentsubmit_btn" value="true" disable="true" class="iE5tROBSAh66">{lang comment}</button></th>
					</tr>
					</table>
					<!--{template home/space_smilies}-->
					</div> 
				</form>
                </div>
			<!--{/if}--> 
            
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript" >
<!--{if $nologinpost == 0 && !$_G[uid]}-->	
$('#message').on('focus', function() {
	popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
	this.blur();
});
<!--{/if}--> 
function ismi(sl){	$('#message').insertAtCaret(sl);}
function imes(mess){$('#message').insertAtCaret(mess);}
	(function() {
		var form = $('#message');
		<!--{if $secqaacheck || $seccodecheck}-->
		var message = sectxt = false;
		<!--{else}-->
		var message = false;
		<!--{/if}-->		
		$('#message').on('keyup input focus', function() {
			var obj = $(this);
			if(obj.val()) {
				fastpostmessage = true;	
				<!--{if $secqaacheck || $seccodecheck}-->
				if(sectxt == true) {
					$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');					
				}
				<!--{else}-->
				$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');
				<!--{/if}-->
			} else {
				fastpostmessage = false;
				$('#commentsubmit_btn').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
			}
		});		
		<!--{if $secqaacheck || $seccodecheck}-->
		$('.sectxt').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				sectxt = true;	
				if(fastpostmessage == true) {
					$('#commentsubmit_btn').removeClass('nopost').addClass('btnon').attr('disable', 'false');					
				}
			} else {
				sectxt = false;
				$('#commentsubmit_btn').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
			}
		});	
		<!--{/if}-->		
		$('#commentsubmit_btn').on('click', function() {		
			var btobj = $(this);
			if(btobj.attr('disable') == 'true') {
				return false;
			}
			$('.postsmilie').removeClass('on');
			$('#smiliesdiv').slideUp();		
			popup.open('<div class="lmVdjV39q3EP"></div>');
			var obj = $(this);
			var formobj = $(this.form);
			$.ajax({
				type:'POST',
				url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
				data:formobj.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});					
	})();	
</script>
    
<div class="3BpUTDuPIV3L"></div>
<!--{block bottombutton}-->
<ul>
<li class="g1msIoXjNQqd"><span class="GddXLGiN3F9i">{if $csubject['allowcomment'] == 1}{lang send_reply_fast_tip}{else}{$langplus['noreply']}{/if}</span></li> 
<li><a href="javascript:;" id="replyid"><i class="4TtPW6YVzyiQ"></i>{lang comment}</a><!--{if $csubject[commentnum] > 0}-->
<!--{if $csubject[commentnum] > 9999 }-->           
<!--{eval $csubject[commentnum] = round($csubject[commentnum] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->  
<i class="r7wK0yKft2oO">{$csubject[commentnum]}</i>
<!--{/if}--></li>
<li>
<!--{if !$_G[uid] && !$_G['connectguest']}-->
<a href="member.php?mod=logging&action=login"><i class="0iHKtK6RqXLZ"></i>{lang login}</a>
<!--{else}-->
<a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="0iHKtK6RqXLZ"></i>$langplus[me]</a>
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="Iug1I7rXnrOf"></i><!--{/if}-->
<!--{/if}-->
</li>
</ul>
<!--{if $csubject['allowcomment'] == 1}-->
<script type="text/javascript">	
$(document).ready(function(){	
	$(document).on('click','.portal_view_quote',function(){				
		$('.postbox').slideToggle();		
		$('.close_p').delay(300).fadeIn();
	});
	$('.fastreply, #replyid').click(function(){		
		<!--{if $nologinpost == 0 && !$_G[uid]}-->
		popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
		this.blur();
		<!--{else}-->
		$('.postbox').slideToggle();
		$('.close_p').delay(300).fadeIn();
		<!--{/if}-->
	}); 	
	$('.close_p').click(function(){	
		$('.postbox').slideToggle();
		$(this).hide();
		$('#smiliesdiv').slideUp();	
		$('.postsmilie').removeClass('on');
	});  
});	
</script>
<!--{/if}-->
<!--{/block}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a><!--{/if}--><a href="forum.php" class="rnxgBOYPCeEM"></a><a href="javascript:history.back();" class="VkmTmMvm1mAV"></a></div>
<!--{/block}-->
<!--{template common/footer}-->