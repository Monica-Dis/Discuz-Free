<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="portal.php?mod=list&catid=$cat[catid]">$cat[catname]</a><!--{/block}-->
<!--{template common/header}-->
<!--{if $brtnav == 1 && !$noheader}-->
<div class="4ptxL1L724dB">
<a href="forum.php">{$langplus[home]}</a><span>&gt;</span><!--{loop $cat[ups] $value}--><a href="{echo getportalcategoryurl($value[catid])}">$value[catname]</a><span>&gt;</span><!--{/loop}--><a href="{echo getportalcategoryurl($cat[catid])}">$cat[catname]</a>
</div>
<!--{/if}-->
<div class="thname{if $viewtitletype == 1} vbtitle{/if}"><a href="portal.php?mod=view&aid=$article[aid]">$article[title]</a></div>
<!--{eval $adviewida = explode(",",$adviewida); $adviewidb = explode(",",$adviewidb); $adviewidc = explode(",",$adviewidc); $adviewidd = explode(",",$adviewidd); $adviewide = explode(",",$adviewide); $adviewidf = explode(",",$adviewidf);}-->
<div class="2OX19285GKx3">
<div class="ENGjlbvYZyUf">
<a href="{echo getportalcategoryurl($cat[catid])}" class="r9COG0I1EFgN">$cat[catname]</a>
<span>$article[dateline]</span>
<!--{if $article[viewnum] > 0}--><!--{if $article[viewnum] > 9999 }--><!--{eval $article[viewnum] = round($article[viewnum] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->{$article[viewnum]}{$langplus[view]}<!--{/if}-->
</div> 

<!--{if $article[summary] && empty($cat[notshowarticlesummay])}--><div class="bwIoZRieWG5y"><span>{lang article_description}</span>{echo cutstr(strip_tags($article[summary]),120)}</div><!--{/if}-->
          
			<!--{hook/view_top_v2_mobile}-->
            <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
            <!--{if $adviewa && in_array($cat[catid],$adviewida)}--><!--{$adviewa}--><!--{/if}-->
            <!--{if $adviewb && in_array($cat[catid],$adviewidb)}--><!--{$adviewb}--><!--{/if}-->
            <!--{if $adviewc && in_array($cat[catid],$adviewidc)}--><!--{$adviewc}--><!--{/if}-->
            <!--{/if}-->
            
            <div class="message portal_view{if $viewheight} viewheight{/if}">
			<!--{if $content[title]}-->$content[title]<!--{/if}--> 
			$content[content]            
			<!--{if $multi}-->$multi<!--{/if}-->
            <!--{if $viewheight}--><div class="ecQ1qz6BxLwl"><a href="javascript:;" >{$langplus[startreading]}</a></div><!--{/if}-->           
            </div>
            <!--{if $article[from] || $article[author]}-->
            <div class="RVTsWjfefRKK">            
			<!--{if $article[from]}--><p>{$langplus[comefrom]}: <!--{if $article[fromurl]}--><a href="$article[fromurl]" class="Q8lZLnjHfm2v">$article[from]</a><!--{else}-->$article[from]<!--{/if}--></p><!--{/if}-->
            <!--{if $article[author]}--><p>{lang view_author_original}: $article[author]</p><!--{/if}-->            
            </div>            
            <!--{/if}-->
            <!--{subtemplate home/space_click}-->
            <!--{hook/view_bottom_v2_mobile}-->
            <!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $article['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $article['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->
            <div class="AXV3uT7AXRS8" >			            
            <!--{if $article[status]>0 && ($_G['group']['allowmanagearticle'] || $categoryperm[$value['catid']]['allowmanage'])}-->
            <a href="portal.php?mod=portalcp&ac=article&op=verify&aid=$article[aid]" class="F3pveqiOE331"><i class="M9ArOHfJHysq"></i></a>
            <!--{else}-->
            <a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$article[aid]" class="F3pveqiOE331"><i class="aPyV086aHjq3"></i></a>
            <!--{/if}-->
            <a href="portal.php?mod=portalcp&ac=article&op=edit&aid=$article[aid]"><i class="HcGNy22c8avk"></i></a>
            </div>
            <!--{/if}-->          
            </div>
            <!--{if $article['preaid'] || $article['nextaid']}-->
            <div class="SeuV21UT4pLL">
                <!--{if $article['prearticle']}--><p><span>{lang pre_article}</span><a href="{$article['prearticle']['url']}">{$article['prearticle']['title']}</a></p><!--{/if}-->
                <!--{if $article['nextarticle']}--><p><span>{lang next_article}</span><a href="{$article['nextarticle']['url']}">{$article['nextarticle']['title']}</a></p><!--{/if}-->
            </div>
            <!--{/if}-->
            <!--{hook/view_centre_v2_mobile}-->
            <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
			<!--{if $adviewd && in_array($cat[catid],$adviewidd)}--><!--{$adviewd}--><!--{/if}-->
            <!--{if $adviewe && in_array($cat[catid],$adviewide)}--><!--{$adviewe}--><!--{/if}-->
            <!--{if $adviewf && in_array($cat[catid],$adviewidf)}--><!--{$adviewf}--><!--{/if}-->
            <!--{/if}-->

    <!--{if $openrelatedview == 0 || $openrelatedview == 1}-->
    <!--{if $openrelatedview == 0 && $article['related']}-->
    <div class="3cUMT47WQpQo">
    <div class="qrZcxEaXs8OF"><span>{lang view_related}</span></div>
    <ul>
    <!--{eval $rel = 1;}-->
    <!--{loop $article['related'] $raid $rvalue}-->
    <!--{eval $rvalue['viewnum'] = DB::result_first("SELECT viewnum FROM ".DB::table("portal_article_count")." where aid =".$rvalue['aid'])}-->
    <!--{if $rel == $relatedviewnums + 1}--><div class="SKbD1jY5BuVe"><span>{$langplus[more_view]}</span></div><!--{/if}-->
    <li{if $rel > $relatedviewnums} class="O7nIojK7ZoYY"{/if}>
    <a href="{$rvalue[uri]}" class="L7aXBQU7lGUH">    
    <div class="tlmwm5r8Nn9Q">{$rvalue[title]}</div>
    <div class="eFyhs1FdehR0">{echo dgmdate($rvalue['dateline'],'u')}
    <!--{if $rvalue[viewnum] > 0}-->
    <!--{if $rvalue[viewnum] > 9999 }-->
    <!--{eval $rvalue[viewnum] = round($rvalue[viewnum] / 10000 , 1).$langplus[tenthousand];}-->
    <!--{/if}-->
    <span class="99u2LxYcMOhO">{$rvalue[viewnum]}{$langplus[view]}</span><!--{/if}--></div>
    </a>
    </li>            
    <!--{eval $rel++;}-->
    <!--{/loop}-->
    </ul>			
    </div>
    <!--{else}-->
    
    <!--{eval require_once(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/viewlist.php');}-->
    <!--{if $vwlist}-->
	<div class="3cUMT47WQpQo">
    <div class="qrZcxEaXs8OF"><span>{lang view_related}</span></div>
    <ul>	
	<!--{eval $rel = 1;}-->
    <!--{loop $vwlist $vws}-->
    <!--{if $rel == $relatedviewnums + 1}--><div class="SKbD1jY5BuVe"><span>{$langplus[more_view]}</span></div><!--{/if}-->
	<li{if $rel > $relatedviewnums} class="O7nIojK7ZoYY"{/if}>
    <a href="portal.php?mod=view&aid={$vws[aid]}" class="portal_subject{if !$vws[picflag]} nopic{/if}">
	<!--{if $vws['picflag']}--><span class="eV6QZvlP57vk"><img src="{if $vws['picflag'] == 1}{$_G['setting'][attachurl]}{else}{$_G['setting']['ftp']['attachurl']}{/if}{$vws[pic]}{if $vws['thumb']}.thumb.jpg{/if}"></span><!--{/if}-->
	<div class="tlmwm5r8Nn9Q">{$vws[title]}</div>
	<div class="eFyhs1FdehR0">    
	{$vws[dateline]}
    <!--{if $vws[viewnum] > 0}-->
	<!--{if $vws[viewnum] > 9999 }-->
	<!--{eval $vws[viewnum] = round($vws[viewnum] / 10000 , 1).$langplus[tenthousand];}-->
	<!--{/if}-->
    <span class="99u2LxYcMOhO">{$vws[viewnum]}{$langplus[view]}</span>
    <!--{/if}-->
    </div>
	</a>
    </li>        
	<!--{eval $rel++;}-->
    <!--{/loop}-->
	</ul> 
    </div>
    <!--{/if}-->
    <!--{/if}-->            
	<script type="text/javascript">
	$(document).ready(function(){	
		$('.portal_list_more').click(function(){	
			$('.portal_list_morerelated').show();
			$(this).hide();
		}); 
	});
	</script>
    <!--{/if}-->

		<!--{if $article['allowcomment']==1}-->
        <!--{eval $data = &$article}-->			
        <!--{subtemplate portal/portal_comment}-->
        <!--{if $data[commentnum] <= 0 }-->
        <div class="d5yNuqYAzkYt">
        <img src="template/v2_mbl20121009/touch_plus/image/sofa.png">
        $langplus[sofas_b]
        </div>
        <!--{/if}-->    
		<!--{/if}-->

<!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') == false && strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') == false && (strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false)}-->
<div id="myshare" class="ysMRojn3XRKC"></div>
<div class="qytY6AvMLAlZ"></div>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/share.js?{VERHASH}"></script>
<script type="text/javascript"> var config={url:'{$_G['siteurl']}/portal.php?mod=view&aid=$article[aid]',title:'{$article[title]}',desc:'{$article[title]}',{if $logourl}img:'{$_G['siteurl']}/{$logourl}',{/if}};var share_obj=new myshare('myshare',config);</script>
<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false }-->
<div id="myshare"></div>
<div class="Bn5G6abKZdVY"></div>
<!--{else}-->
<div class="zddxUhbNB29m"><p>{$langplus[share_browser]}</p><img src="template/v2_mbl20121009/touch_plus/image/browser_share_icon.png"/></div>
<div class="qytY6AvMLAlZ"></div>
<!--{/if}-->
<div class="3BpUTDuPIV3L"></div>
<!--{block bottombutton}-->
<ul>
<li class="E2JMFR03EHf0"><span class="GddXLGiN3F9i">{if $article['allowcomment']==1}{lang send_reply_fast_tip}{else}{$langplus['noreply']}{/if}</span></li> 
<li><a href="javascript:;" id="replyid"><i class="4TtPW6YVzyiQ"></i>{lang comment}</a><!--{if $data[commentnum] > 0}-->
<!--{if $data[commentnum] > 9999 }-->           
<!--{eval $data[commentnum] = round($data[commentnum] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->  
<i class="r7wK0yKft2oO">{$data[commentnum]}</i>
<!--{/if}--></li>
<li>
<!--{eval $favstate = C::t('home_favorite')->fetch_by_id_idtype($article['aid'],'aid',$_G['uid']);}-->
<!--{if $favstate && $_G['uid']}-->
<a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="DEpWPCcOgRkB"><i class="yUHLv4Ewx6zR"></i>$langplus[favorite]</a>
<!--{else}-->
<a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" class="un5EcQmZbb1B"><i class="quKOCKMOWfuc"></i>$langplus[favorite]</a></a>
<!--{/if}-->
</li>
<li><a href="javascript:;" id="fshare"><i class="K8kYuvxODrq6"></i>$langplus[share]</a></li>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#fshare').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').addClass('weixinshare');
                $('.close_s1').show();
				<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false}-->
                $('#myshare').addClass('openshare');
                $('header, footer, .pt, .scroll_plus{if !$headershow}, .scroll_openmenu{/if}').addClass('onlypage');
				$('.close_s').show();
				<!--{else}-->
				$('.share_browser').fadeIn();
				$('.close_s').show();
				shareclosetime = setTimeout(function(){
					$('.share_browser, .close_s').hide()
					},4000);
				<!--{/if}-->
            });
            $('.close_s, .close_s1').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').removeClass('weixinshare');
                <!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false}-->
                $('#myshare').removeClass('openshare');
                $('header, footer, .pt, .scroll_plus{if !$headershow}, .scroll_openmenu{/if}').removeClass('onlypage');
				<!--{else}-->
				$('.share_browser').hide();
				clearTimeout(shareclosetime);
                <!--{/if}-->
                $(this).hide();
            });
        });
    </script>
</ul>
<!--{if $article['allowcomment']==1}-->
<script type="text/javascript">	
$(document).ready(function(){		
	$('.fastreply{if $data[commentnum] <= 0 }, #replyid{/if}, .portal_view_quote').click(function(){
		<!--{if $nologinpost == 0 && !$_G[uid]}-->
		popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
		this.blur();
		<!--{else}-->
		$('.postbox').slideToggle();
		$('.close_p').delay(300).fadeIn();
		<!--{/if}-->
	});
    <!--{if $data[commentnum] > 0 }-->
    $("#replyid").on("click",function(){
        $("html,body").animate({scrollTop:$("#ap_reply").offset().top},500)
    });
    <!--{/if}--> 	
	$('.close_p').click(function(){	
		$('.postbox').slideToggle();
		$(this).hide();
		$('#smiliesdiv').slideUp();	
		$('.postsmilie').removeClass('on');
	});  
});	
</script>
<!--{/if}-->
<!--{$ajaxsubmit_item}-->
<!--{/block}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a><!--{/if}--><a href="forum.php" class="rnxgBOYPCeEM"></a><a href="javascript:history.back();" class="VkmTmMvm1mAV"></a></div>
<!--{/block}-->
<!--{template common/footer}-->