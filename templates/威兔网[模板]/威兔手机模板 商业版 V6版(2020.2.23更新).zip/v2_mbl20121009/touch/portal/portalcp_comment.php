<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $_GET['op'] == 'edit'}-->{lang edit}<!--{elseif $_GET['op'] == 'delete'}-->{lang delete}<!--{else}-->{lang uploadstatusmsg10}<!--{/if}--><!--{/block}-->
<!--{if $_GET['op'] == 'edit'}--><!--{eval $navtitle = {lang edit};}--><!--{elseif $_GET['op'] == 'delete'}--><!--{eval $navtitle = {lang delete};}--><!--{else}--><!--{eval $navtitle = {lang freeze};}--><!--{/if}-->
<!--{template common/header}-->
<!--{if $_GET['op'] == 'edit'}-->
	<form id="editcommentform_{$cid}" name="editcommentform_{$cid}" method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=comment&op=edit&cid=$cid{if $_GET[modarticlecommentkey]}&modarticlecommentkey=$_GET[modarticlecommentkey]{/if}">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="inputall bw">
        <textarea id="message_{$cid}" name="message" rows="10" placeholder="{lang thread_content}" >$comment[message]</textarea>
        </div>        
    <div class="ftpost">
    <table cellspacing="0" cellpadding="0">
        <tr>
        <td>
            <div class="editor">
            <a href="javascript:;"{if $_G[uid]} onclick="$(this).toggleClass('on'); $('#smiliesdiv').slideToggle();"{/if} class="postsmilie"></a>          
            </div>
        </td>
        <th><button type="submit" name="editsubmit_btn" id="editsubmit_btn" value="true" class="formdialog ftbtn nopost" disable="true">{lang submit}</button></th>
        </tr>
    </table>
    <!--{template home/space_smilies}-->
    </div>
	</form>
<!--{block footerplus}--><div class="ftbox"></div><!--{/block}-->     
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript">
function ismi(sl) {$("#message_{$cid}").insertAtCaret(sl);}
$('#message_{$cid}').on('keyup input focus', function() {
		var obj = $(this);
		if(obj.val()) {
			$('#editsubmit_btn').removeClass('nopost').addClass('btnon');
			$('#editsubmit_btn').attr('disable', 'false');
		} else {
			$('#editsubmit_btn').removeClass('btnon').addClass('nopost');
			$('#editsubmit_btn').attr('disable', 'true');
		}
});

$('#message_{$cid}').on('input focus', function(){
	$(this).css('height','auto');
	$(this).css('height',this.scrollHeight + 2); 
});

$('.postsmilie').click(function(){
    $('.ftbox').toggleClass("keyht2");
});

$('#editsubmit_btn').on('click', function() {			
	var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}
});
</script>
    
    
<!--{elseif $_GET['op'] == 'delete'}--> 
    <div class="bw{if $_G['inajax']} ajaxpop{/if}">
    <form id="deletecommentform_{$cid}" name="deletecommentform_{$cid}" method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=comment&op=delete&cid=$cid">
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<div class="r-block">{lang comment_delete_confirm}</div>
		<div class="hm"><button type="submit" name="deletesubmitbtn" value="true" class="button2">{lang confirms}</button></div>
	</form>
    </div>
<!--{else}-->
<div class="r-block">{lang uploadstatusmsg10}</div>
<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->