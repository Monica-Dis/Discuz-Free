<?php exit('QQ:32-77558-32');?>

<!--{block header_name}--><a href="portal.php?mod=list&catid=$cat[catid]">$cat[catname]</a><!--{/block}-->

<!--{template common/header}-->
<!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'miniProgram') !== false }-->
<style type="text/css">
.sortmenu_float { top:0px; }
.close_h { -webkit-transform:translate(0,0px); -moz-transform:translate(0,0px); transform:translate(0,0px);}
</style>
<!--{/if}-->
<!--{ad/portal_list_top_mobile}-->

<!--[name]{lang portalcategory_listtplname}[/name]-->

<!--{eval $list = array();}-->

<!--{eval $wheresql = category_get_wheresql($cat);}-->

<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->

<!--{if $brtnav == 1 && $_G['page'] > 1}-->

<div class="3jFBf3583NdA">

    <p><a href="forum.php">{$langplus[home]}</a><span>&gt;</span><!--{loop $cat[ups] $value}--><a href="{echo getportalcategoryurl($value[catid])}">$value[catname]</a><span>&gt;</span><!--{/loop}-->$cat[catname]</p>

</div>

<!--{/if}-->

<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->

<!--{if $adheadertopa && in_array($cat[catid],explode(",",$adheadertopida))}--><!--{$adheadertopa}--><!--{/if}-->

<!--{if $adheadertopb && in_array($cat[catid],explode(",",$adheadertopidb))}--><!--{$adheadertopb}--><!--{/if}-->

<!--{if $adheadertopc && in_array($cat[catid],explode(",",$adheadertopidc))}--><!--{$adheadertopc}--><!--{/if}-->

<!--{/if}-->

<!--{if $cat[subs] || $cat[others]}-->

<!--{if $sortmenufloat}--><div class="OkTEfU7mYgXw"><!--{/if}-->

<div class="slidemenu{if $sortmenufloat} sortmenus{/if}">

    <div class="KPLQhDcwwS9y">

        <ul class="xCcmihVIrcBI">

            <!--{if !$cat[others]}-->

            <!--{loop $cat[subs] $value}-->

            <!--{if !in_array($value[catid],explode(",",$tplcatid))}-->

            <li class="menu_slide{if $_GET[catid] == $value[catid]} a{/if}"><a href="{echo getportalcategoryurl($value[catid]);}">$value[catname]</a></li>

            <!--{/if}-->

            <!--{/loop}-->

            <!--{/if}-->

            <!--{loop $cat[others] $value}-->

            <!--{if !in_array($value[catid],explode(",",$tplcatid))}-->

            <li class="menu_slide{if $_GET[catid] == $value[catid]} a{/if}"><a href="{echo getportalcategoryurl($value[catid]);}">$value[catname]</a></li>

            <!--{if $cat[subs] && $_GET[catid] == $value[catid]}-->

            <!--{loop $cat[subs] $value}-->

            <!--{if !in_array($value[catid],explode(",",$tplcatid))}-->

            <li class="menu_slide{if $_GET[catid] == $value[catid]} a{/if}"><a href="{echo getportalcategoryurl($value[catid]);}">$value[catname]</a></li>

            <!--{/if}-->

            <!--{/loop}-->

            <!--{/if}-->

            <!--{/if}-->

            <!--{/loop}-->

        </ul>

    </div>

</div>

<!--{if $sortmenufloat}--></div><!--{/if}-->

<script src="./template/v2_mbl20121009/touch_plus/js/swiper.min.js?{VERHASH}"></script>

<script type="text/javascript">

    $(function() {

        if ($('.slidemenu .a').length > 0) {

            var slidefocus = $('.slidemenu .a').offset().left + $('.slidemenu .a').width() >= $(window).width() ? $('.slidemenu .a').index() : 0;

        } else {

            var slidefocus = 0;

        }

        var swiper = new Swiper('.menu_container', {

            wrapperClass:'menu_wrapper',

            slideClass:'menu_slide',

            slidesPerView:'auto',

            freeMode:true,

            freeModeFluid:true,

            momentumBounce:true,

            initialSlide:slidefocus,

        });

    })

</script>

<!--{/if}-->

<!--{if $list['count'] > 0}-->

<ul id="alist" class="uhO0lPlrkrD0">

    <!--{eval $ad = 1;}-->

    <!--{loop $list['list'] $value}-->

    <!--{hook/list_middle_v2_mobile}-->

    <!--{if $page == 1}-->

    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->

    <!--{if $adlista && in_array($cat[catid],explode(",",$adlistida)) && $ad == $adlisttha}--><!--{$adlista}--><!--{/if}-->

    <!--{if $adlistb && in_array($cat[catid],explode(",",$adlistidb)) && $ad == $adlistthb}--><!--{$adlistb}--><!--{/if}-->

    <!--{if $adlistc && in_array($cat[catid],explode(",",$adlistidc)) && $ad == $adlistthc}--><!--{$adlistc}--><!--{/if}-->

    <!--{/if}-->

    <!--{/if}-->

    <!--{eval $highlight = article_title_style($value);}-->

    <!--{eval $article_url = fetch_article_url($value);}-->

    <!--{eval $value['viewnum'] = DB::result_first("SELECT viewnum FROM ".DB::table("portal_article_count")." where aid=".$value[aid])}-->

    <!--{if $value['viewnum'] > 9999 }--><!--{eval $value['viewnum'] = round($value[viewnum] / 10000 , 1).$langplus[tenthousand];}--><!--{/if}-->

    <li>

        <a href="portal.php?mod=view&aid=$value[aid]" class="portal_subject{if !$value[pic]} nopic{/if}">

            <!--{if $value[pic]}--><span class="fRDkQfri0KD8"><img src="$value[pic]" /></span><!--{/if}-->

            <div class="Gl7ecXIHBT0F" $highlight>$value[title]</div>

            <!--{if $value[summary] && !$value[pic]}-->

            <p class="X2hLCuQEFGAn">{echo cutstr(strip_tags($value[summary]),90)}</p>

            <!--{/if}-->

            <div class="FMHWdfyE3RPZ">

                $value[dateline]

                <!--{if $value[viewnum] > 0}-->

                <!--{if $value[viewnum] > 9999 }-->

                <!--{eval $value[viewnum] = round($value[viewnum] / 10000 , 1).$langplus[tenthousand];}-->

                <!--{/if}-->

                <span class="9ECtWVPiFM1j">{$value[viewnum]}{$langplus[view]}</span>

                <!--{/if}-->

            </div>

        </a>

        <!--{if $_G['group']['allowmanagearticle'] || ($_G['group']['allowpostarticle'] && $value['uid'] == $_G['uid'] && (empty($_G['group']['allowpostarticlemod']) || $_G['group']['allowpostarticlemod'] && $value['status'] == 1)) || $categoryperm[$value['catid']]['allowmanage']}-->

        <span class="2nSQGeV0hbq6"><a href="portal.php?mod=portalcp&ac=article&op=edit&aid=$value[aid]"class=""><i class="4iPL2IBpm7EF"></i></a><a href="portal.php?mod=portalcp&ac=article&op=delete&aid=$value[aid]" class="KAJ0RQtE7zdl"><i class="cDXiOoUbMr9R"></i></a></span>

        <!--{/if}-->

    </li>

    <!--{eval $ad++;}-->

    <!--{/loop}-->

</ul>

<!--{else}-->

<div class="AGIXSh5ow2Ai">{$langplus[forum_nothreads]}</div>

<!--{/if}-->



<!--{if $tplpages == 1}-->

<!--{eval $totalpage = ceil($list['count'] / $cat['perpage']);}-->

<!--{if $totalpage > $page}-->

<a href="$cat['caturl']" class="eMpHsVJ7jUAD" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>

<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>

<!--{/if}-->

<!--{else}-->

<!--{if $list['multi']}-->{$list['multi']}<!--{/if}-->

<!--{/if}-->



<!--{if ($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])}-->

<!--{block bottombutton}-->

<ul>

    <!--{if $tplwapurl}-->

    <li><a href="forum.php"><i class="P3Ggjz8tK4wj"></i>$langplus[home]</a></li>

    <li><a href="forum.php?forumlist=1"><i class="h5gassCXSar1"></i>$langplus[bbs]</a></li>

    <!--{else}-->

    <li><a href="forum.php?forumlist=1"><i class="h5gassCXSar1"></i>$langplus[bbs]</a></li>

    <li><a href="forum.php?mod=guide&view=newthread"><i class="wp68XIppeE1f"></i>{$langplus[guide]}</a></li>

    <!--{/if}-->

    <li><div class="CBb2RksjMgB7"><a href="portal.php?mod=portalcp&ac=article&catid=$cat[catid]" class="s0LeHx2M3fn3"><i class="9xg2U1Gd4eWz"></i></a></div></li>

    <!--{if helper_access::check_module('group')}-->

    <li><a href="group.php"><i class="icOQlcaDD9RM"></i>{$langplus[groups]}</a></li>

    <!--{else}-->

    <!--{if $tplwapurl}-->

    <li><a href="forum.php?mod=guide&view=newthread"><i class="wp68XIppeE1f"></i>{$langplus[guide]}</a></li>

    <!--{else}-->

    <li><a href="search.php?mod={if $searchmode == 1 || !$searchmode}forum{elseif $searchmode == 2}portal{elseif $searchmode == 3}group{elseif $searchmode == 4}blog{elseif $searchmode == 5}album{/if}"><i class="icAd5SlLCROZ"></i>{lang search}</a></li>

    <!--{/if}-->

    <!--{/if}-->

    <li>

        <!--{if !$_G[uid] && !$_G['connectguest']}-->

        <a href="member.php?mod=logging&action=login"><i class="XR3zFOL4bCHX"></i>{lang login}</a>

        <!--{else}-->

        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="XR3zFOL4bCHX"></i>$langplus[me]</a>

        <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="GXoXTZmDmtgZ"></i><!--{/if}-->

        <!--{/if}-->

    </li>

</ul>

<!--{/block}-->

<!--{/if}-->

<!--{template common/footer}-->