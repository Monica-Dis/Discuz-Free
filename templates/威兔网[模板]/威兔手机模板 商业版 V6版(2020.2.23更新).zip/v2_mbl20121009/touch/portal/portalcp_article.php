<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $op == 'delete'}-->{lang article_delete}<!--{elseif $op == 'verify'}-->{lang moderate_article}<!--{elseif $op == 'related' || $op == 'pushplus'}-->{lang board_message}<!--{elseif $op == 'add_success'}-->{lang article_send_succeed}<!--{else}--><!--{if !empty($aid)}-->{lang article_edit}<!--{else}-->{lang article_publish}<!--{/if}--><!--{/if}--><!--{/block}-->
<!--{template common/header}-->
<!--{if $op == 'delete'}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if}">
<form method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=article&op=delete&aid=$_GET[aid]">
        <div class="inputall ppd bb">
        <ul>
        <!--{if $_G['group']['allowpostarticlemod'] && $article['status'] == 1}-->
		<li>{lang article_delete_sure}</li>
		<input type="hidden" name="optype" value="0" />
		<!--{else}-->
		<li><label><input type="radio" name="optype" value="0" /> {lang article_delete_direct}</label></li>
		<li><label><input type="radio" name="optype" value="1" checked="checked" /> {lang article_delete_recyclebin}</label></li>
		<!--{/if}-->
        </ul>
        </div>
	<div class="hm"><button type="submit" name="btnsubmit" value="true" class="formdialog button2">{lang confirms}</button></div>
	<input type="hidden" name="aid" value="$_GET[aid]" />
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="deletesubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
</form>
</div>
<!--{elseif $op == 'verify'}-->
<div class="bw{if $_G['inajax']} ajaxpop{/if}">
<form method="post" autocomplete="off" id="aritcle_verify_$aid" action="portal.php?mod=portalcp&ac=article&op=verify&aid=$aid">
        <div class="inputall ppd bb">
        <ul>
		<li><label for="status_0" ><input type="radio" name="status" value="0" id="status_0"{if $article[status]=='1'} checked="checked"{/if} />{lang passed}</label></li>
		<li><label for="status_x" ><input type="radio" name="status" value="-1" id="status_x" />{lang delete}</label></li>
		<li><label for="status_2" ><input type="radio" name="status" value="2" id="status_2"{if $article[status]=='2'} checked="checked"{/if} />{lang ignore}</label></li>
        </ul>
        </div>
		<div class="hm"><button type="submit" name="btnsubmit" value="true" class="formdialog button2">{lang confirms}</button></div>
	<input type="hidden" name="aid" value="$aid" />
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="handlekey" value="$_GET['handlekey']" />
	<input type="hidden" name="verifysubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
</form>
</div>
<!--{elseif $op == 'related' || $op == 'pushplus'}-->
<!--{if $_G[inajax]}--><div class="ajaxpop"><!--{/if}-->
<div class="r-block">{lang uploadstatusmsg10}</div>
<!--{if $_G[inajax]}--></div><!--{/if}-->
<!--{elseif $op == 'add_success'}-->
<a href="portal.php?mod=list&catid={$_GET[catid]}" class="portal_viewarticle" ></a>
<div class="tip">
    <dt id="messagetext">{lang article_send_succeed}<p class="mbmnn"><a href="portal.php?mod=list&catid={$_GET[catid]}" >[ {lang click_return_list} ]</a></p></dt>
    <div class="btnoption">
        <a href="{$article_add_url}&op=edit&aid=$aid">{lang article_edit}</a>
        <a href="$article_add_url">{lang article_publish}</a>
        <a href="portal.php?mod=view&aid=$aid" >{lang view_article}</a>
    </div>
</div>
<!--{else}-->
			<form method="post" autocomplete="off" id="articleform" action="portal.php?mod=portalcp&ac=article{if $_GET[modarticlekey]}&modarticlekey=$_GET[modarticlekey]{/if}" onsubmit="validate(this);" enctype="multipart/form-data">
			<div class="inputall bw">
			<!--{if !empty($aid)}--><div class="warningmessage">{$langplus[editnotice]}</div><!--{/if}-->					
                    <ul>
                    <li><input type="text" name="title" id="title" value="$article[title]" placeholder="{lang thread_subject}" /></li>
                    <input type="hidden" id="color_style" title="{lang select_color}" fwin="eleStyle" onclick="change_title_color(this.id);" style="background-color:$stylecheck[0]" />
                    <input type="hidden" id="highlight_style_0" name="highlight_style[0]" value="$stylecheck[0]" />
                    <input type="hidden" id="highlight_style_1" name="highlight_style[1]" value="$stylecheck[1]" />
                    <input type="hidden" id="highlight_style_2" name="highlight_style[2]" value="$stylecheck[2]" />
                    <input type="hidden" id="highlight_style_3" name="highlight_style[3]" value="$stylecheck[3]" />                    
                    <!--{if $_G['cache']['portalcategory'] && $categoryselect}-->
                    <li><div class="selectstyle">$categoryselect</div></li>
                    <!--{/if}-->
					<li><textarea class="userData" name="content" id="uchome-ttHtmlEditor" rows="10" placeholder="{lang thread_content}">$article_content[content]</textarea></li>
                    </ul>
                    <ul id="imglist" class="post_imglist portal_imglist">
                    <!--{if $attachs}-->
                    <!--{loop $attachs $value}-->
                    <!--{eval $opattach_ctrl = $value['from'] == 'forum' ? 'forum' : 'portal';}-->
                    <!--{eval $bigimg = pic_get($value['attachment'], $opattach_ctrl, $value['thumb'], $value['remote'], 0);}-->
                    <!--{eval $smallimg = $value['thumb'] ? getimgthumbname($bigimg) : '';}-->
                    <!--{eval $attachcheck = $value['pic'] == $opattach_ctrl.'/'.$value['attachment'] ? 'checked' : '';}-->
                    <!--{eval $attachcover = addslashes(serialize(array('pic'=>$opattach_ctrl.'/'.$value['attachment'], 'thumb'=>$value['thumb'], 'remote'=>$value['remote'])))}-->
                    <!--{eval $file_type = explode('.',$bigimg); $file_type = $file_type[1]; $ex_name = array('jpg','jpeg','gif','png','bmp'); }-->
                    <li>
                    <span aid="{$value['attachid']}" class="imgdel"><a href="javascript:;"></a></span>
                    <!--{if !in_array($file_type,$ex_name)}--><div class="attach_roll"><div class="attach_name">$value['filename']</div></div><!--{/if}-->
                    <span class="post_img"><a href="javascript:;"{if in_array($file_type,$ex_name)} onclick="insimg('{if $smallimg}$smallimg{else}$bigimg{/if}');"{else} onclick="insattach('{$value[aid]}');"{/if}><p>{$langplus[clickinsert]}</p><img id="aimg_{if in_array($file_type,$ex_name)}{$value['attachid']}{else}{$value[aid]}{/if}" src="{if in_array($file_type,$ex_name)}{if $smallimg}$smallimg{else}$bigimg{/if}{else}template/v2_mbl20121009/touch_plus/image/filetype/attach.png{/if}"{if !in_array($file_type,$ex_name)} class="attachtype"{/if} /></a></span>{if in_array($file_type,$ex_name)}<div class="attset_cover"><label for="setconver{$value['attachid']}"><input type="radio" name="setconver" id="setconver{$value['attachid']}" value="1" {$attachcheck} onclick="setConver(this.getAttribute('coverstr'))" coverstr=$attachcover ><em>{$langplus[setcover]}</em></label></div>{/if}
                    </li>
                    <!--{/loop}-->
                    <!--{/if}-->                    
                    </ul>
                    <div class="menufly">
                    <div class="namefly"><span class="vt-close fz2"></span>$langplus[option]</div>
                    <div class="portal_set">
                    <ul>
					<li><textarea name="summary" rows="3" placeholder="{lang article_description}">$article[summary]</textarea></li>                    
                    <li{if $from_cookie} class="articlesource"{/if}>
                    <input type="text" id="from" name="from" value="$article[from]" placeholder="{lang article_source}" />
                    <!--{if $from_cookie}-->                    
                    <div class="selectstyle fromcookie">
                    <select name="from_cookie" id="from_cookie" onchange="$('from').value=this.value;" >
                       <option value="" selected>{lang choose_please}</option>
                       <!--{loop $from_cookie $var}-->
                       <option value="$var">$var</option>
                       <!--{/loop}-->
                    </select>
                    </div>
                    <!--{/if}-->
                    </li>                    
                    <li><input type="text" name="fromurl" value="$article[fromurl]" placeholder="{lang article_source_url}" /></li>
                    <li><input type="text" name="dateline" value="$article[dateline]" id="article_times" placeholder="{lang article_dateline}" /></li>                    
                    <li><input type="text" name="url" value="$article[url]" placeholder="{lang article_url}" /></li>
                    <li><input type="text" name="author" value="$article[author]" placeholder="{lang article_author}" /></li>
                    </ul>
                    <div class="portal_tag">
					<h1>{lang article_tag}:</h1>
                    <!--{loop $article_tags $key $tag}-->
                    <span><label for="article_tag_$key"><input type="checkbox" name="tag[$key]" id="article_tag_$key" {if $article_tags[$key]} checked="checked"{/if} /><em>{$tag_names[$key]}</em></label></span>
                    <!--{/loop}-->
                    </div>                    
                    <!--{if $category[$catid][allowcomment]}-->
                    <div class="portal_tag">
                    <h1>{lang article_comment_setup}:</h1>
                    <span><label for="ck_allowcomment"><input type="checkbox" name="forbidcomment" id="ck_allowcomment" value="1"{if isset($article['allowcomment']) && empty($article['allowcomment'])}checked="checked"{/if} /><em>{lang article_forbidcomment_description}</em></label></span>
                    </div>
                    <!--{/if}-->
                    <input type="hidden" id="conver" name="conver" value="" />
                    </div>
                    </div>
				<!--{if $secqaacheck || $seccodecheck}-->					
					<!--{subtemplate common/seccheck}-->
				<!--{/if}-->
                </div>                
    <div class="ftpost">
    <table cellspacing="0" cellpadding="0">
        <tr>
        <td>
            <div class="editor editordefault">
            <a href="javascript:;" class="postphoto"><input type="file" name="Filedata" id="filedata" accept="image/*" multiple="multiple" /></a>
            <a href="javascript:;" class="invideo editortab"></a>
            <a href="javascript:;" class="{if empty($article['aid'])}cutoption{else}inlink{/if} editortab"></a>
            <a href="javascript:;" class="postsmilie editortab"></a>            
            <i class="moreoption">{$langplus[option]}</i>         
            </div>
        </td>
        <th><button type="submit" id="issuance" name="articlebutton" class="formdialog ftbtn nopost" disable="true">{lang publish}</button></th>
        </tr>
    </table>    
    <div class="editor_item">
		<div class="hidebox">
		<div class="addlinks">
        <i class="vt-play"></i>
		<input type="text" name="video_link" id="video_link" autocomplete="off" placeholder="{$langplus[video_link]}" />
		<span class="addlinks_btn" onclick="ilink(ins_code_0())">{$langplus[insert]}</span>
		</div>
		<div class="addlinks">
        <i class="vt-music"></i>
		<input type="text" name="music_link" id="music_link" autocomplete="off" placeholder="{$langplus[music_link]}" />
		<span class="addlinks_btn" onclick="ilink(ins_code_1())">{$langplus[insert]}</span>
		</div>
		</div>
		<div class="hidebox">        
		<div class="addlinks">
        <i class="vt-links"></i>
        <div class="link_item"><input type="text" name="links_link" id="links_link" autocomplete="off" placeholder="{$langplus[links_link]}" /></div>
        <div class="link_item"><input type="text" name="linkname_link" id="linkname_link" autocomplete="off" placeholder="{$langplus[linkname_link]}" /></div>
		<span class="addlinks_btn" onclick="ilink(ins_code_2())">{$langplus[insert]}</span>
		</div>
        <!--{if empty($article['aid'])}-->
        <div class="addlinks">
        <i class="vt-subject"></i>
        <div class="selectstyle link_select">
        <select name="from_idtype" id="from_idtype">
           <option value="tid"$idtypes[tid]>{lang thread} tid</option>
           <option value="blogid"$idtypes[blogid]>{lang blog} id</option>
        </select>
        </div>
        <div class="link_item link_threadid">
        <input type="text" name="from_id" id="from_id" value="{if $_GET[from_id]}$_GET[from_id]{/if}" placeholder="{$langplus[fillingin]}ID{lang article_auto_grab}" />
        </div>
        <!--{if $_GET['from_idtype'] == 'tid'}-->
        <span id="ele_getauthorall" style="display:none !important;">
        <label for="getauthorall"><input type="checkbox" name="getauthorall" id="getauthorall" value="1" {if $_GET['getauthorall']}checked="checked"{/if}/>{lang article_getauthorall}</label>
        </span>
        <!--{/if}-->                
        <button type="button" name="from_button" class="addlinks_btn" onclick="return from_get();">{lang grab}</button>
        <input type="hidden" name="id" value="$_GET[from_id]" />
        <input type="hidden" name="idtype" value="$_GET[from_idtype]" />
		</div>
        <!--{/if}-->
        </div>        
    	<!--{template home/space_smilies}-->
    </div>    
    </div>	
		<input type="hidden" id="aid" name="aid" value="$article[aid]" />
		<input type="hidden" name="cid" value="$article_content[cid]" />
		<input type="hidden" id="attach_ids" name="attach_ids" value="0" />
		<input type="hidden" name="articlesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		</form>
        
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/buildfileupload.js?{VERHASH}"></script>
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png, bmp' : imgexts;
	var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	var form = $('#articleform');
	$(document).on('change', '#filedata', function() {
			popup.open('<div class="cloading"></div>');

			uploadsuccess = function(data) {
				if(data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}				
				var dataarr = eval('('+data+')');
					popup.close();					
					$('#imglist').append('<li><span aid="'+dataarr['aid']+'" class="imgdel"><a href="javascript:;"></a></span><span class="post_img"><a href="javascript:;" onclick="insimg(\''+dataarr['bigimg']+'\');" ><p>{$langplus[clickinsert]}</p><'+'img id="aimg_'+dataarr['aid']+'" src="'+dataarr['bigimg']+'" /></a></span><div class="attset_cover"><label for="setconver'+dataarr['aid']+'"><input type="radio" name="setconver" id="setconver'+dataarr['aid']+'" value="1" onclick="setConver(this.getAttribute(\'coverstr\'))" coverstr='+dataarr['cover']+'><em>{$langplus[setcover]}</em></label></div></li>');										
					$('#attach_ids').val($('#attach_ids').val() + ',' + dataarr['aid']);
			};

			if(typeof FileReader != 'undefined' && this.files[0]) {
			<!--{if $upimgnumber}-->
			if(this.files.length < {$upimgnumber}) { var imgnumber = this.files.length; } else { var imgnumber = {$upimgnumber}; }
			<!--{/if}-->			
			for(var i=0;i<{if $upimgnumber}imgnumber{else}this.files.length{/if};i++ ){
				var file_data = [];
				file_data.push(this.files[i]);
				$.buildfileupload({
					uploadurl:'misc.php?mod=swfupload&action=swfupload&operation=portal&type=image',
					files:file_data,
					uploadformdata:{uid : "$_G[uid]", hash:"$swfconfig[hash]",aid:"$aid",catid:"$catid"},
					uploadinputname:'Filedata',
					maxfilesize:"$swfconfig[max]",
					success:uploadsuccess,
					error:function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});
			}

			} else {

				$.ajaxfileupload({
					url:'{misc.php?mod=swfupload&action=swfupload&operation=portal&type=image',
					data:{uid : $_G[uid], hash:"$swfconfig[hash]",aid:"$aid",catid:"$catid"},
					dataType:'text',
					fileElementId:'filedata',
					success:uploadsuccess,
					error: function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			}
	});	
	
	$(document).on('click', '.imgdel', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',
			url:'portal.php?mod=attachment&id='+obj.attr('aid')+'&op=delete',
		})
		.success(function(s) {
			obj.parent().remove();
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

function from_get() {
	var el = $('#catid');
	var catid = el ? el.val() : 0;
	window.location.href='portal.php?mod=portalcp&ac=article&from_idtype='+$('#from_idtype').val()+'&catid='+catid+'&from_id='+$('#from_id').val()+'&getauthorall='+($('#getauthorall').is(':checked') ? '1' : '');	
	return true;
}
	
function setConver(attach) {
	$('#conver').val(attach);
}
</script>

<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/rolldate.min.js?{VERHASH}"></script>
<script type="text/javascript">
	var roll_title = "{$langplus[selectdate]}",
	roll_cancel = "{lang cancel}",
	roll_confirm = "{$langplus[confirm]}",
	roll_year = "{$langplus[years]}",
	roll_month = "{$langplus[month]}",
	roll_day = "{$langplus[day]}",
	roll_hour = "{$langplus[hour]}",
	roll_min = "{$langplus[min]}",
	roll_sec = "{$langplus[sec]}";		
	new rolldate.Date({
		el:'#article_times',
		format:'YYYY-MM-DD hh:mm'			
	})	
</script> 
                    
<script type="text/javascript">
	$(document).ready(function() {
	$('.editordefault a.editortab').click(function(){
		if($(this).hasClass('on')){
			$('.ftbox').removeClass('keyht2');
		}else{
			$('.ftbox').addClass('keyht2');
		}
		$('.editordefault a').eq($(this).index()).toggleClass('on').siblings().removeClass('on');
		$('.hidebox').eq($(".editordefault a.editortab").index(this)).slideToggle().siblings().slideUp();
	});		
	$('.moreoption').click(function(){
		$(this).toggleClass('onoption');
		$('.menufly').addClass('infly'); 
		$('body').addClass('menufly_open');               		
	}); 	
	$('.vt-close').click(function(){
		$('.moreoption').removeClass('onoption');	
		$('.menufly').removeClass('infly'); 
		$('body').removeClass('menufly_open');               		
	});
	});
	function ins_code_2(){
		var newvalue = $("#links_link").val();
		var newvalue2 = $("#linkname_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		newvalue2 = newvalue2.replace(/^\s+|\s+$/g,"");
		if(!newvalue2) {
			newvalue2 = newvalue;
		}
		if (newvalue) {
			$("#links_link").val("");
			$("#linkname_link").val("");
			editorclose();
			return "<a href="+ newvalue +">"+ newvalue2 +"</a>";
		}else{
			return "";
		}
	}
	function ins_code_0(){
		var newvalue = $("#video_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#video_link").val("");
			editorclose();
			return "[flash=media]"+ newvalue +"[/flash]";
		}else{
			return "";
		}
	}
	function ins_code_1(){
		var newvalue = $("#music_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#music_link").val("");
			editorclose();
			return "[flash=mp3]"+ newvalue +"[/flash]";
		}else{
			return "";
		}
	}
	function editorclose(){		
		$('.editordefault a').removeClass('on');
		$('.hidebox').slideUp();
		$('.ftbox').removeClass('keyht2');
	}
</script>

<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<script type="text/javascript">

function ilink(lk){$("#uchome-ttHtmlEditor").insertAtCaret(lk);}
function ismi(sl){$('#uchome-ttHtmlEditor').insertAtCaret(sl);}

$('#uchome-ttHtmlEditor').on('input focus', function(){
	$(this).css('height','auto');
	$(this).css('height',this.scrollHeight + 2); 
});

$('#uchome-ttHtmlEditor').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {
		$('#issuance').removeClass('nopost').addClass('btnon');
		$('#issuance').attr('disable', 'false');
	} else {
		$('#issuance').removeClass('btnon').addClass('nopost');
		$('#issuance').attr('disable', 'true');
	}
});

$("#from_cookie").click(function(){
	$("#from").val($("#from_cookie option:selected").val());
});

$('#issuance').on('click', function() {			
	var obj = $(this);
	if(obj.attr('disable') == 'true') {
		return false;
	}
});	
function insimg(aid) { 
	var txt = '<img src="' + aid + '" />';	
	$("#uchome-ttHtmlEditor").insertAtCaret(txt);
}
function insattach(aid) { 
	var txt = '[attach]' + aid + '[/attach]';	
	$("#uchome-ttHtmlEditor").insertAtCaret(txt);
}
</script>
<!--{block footerplus}--><div class="ftbox"></div><!--{/block}-->
<!--{/if}-->
<!--{eval $nofooter = true; $nosopenmenu = true;}-->
<!--{template common/footer}-->