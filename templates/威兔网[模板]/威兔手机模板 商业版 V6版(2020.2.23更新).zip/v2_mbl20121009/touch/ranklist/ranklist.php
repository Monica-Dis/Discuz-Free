<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="sqK9gG26iUGb">{$langplus[tplnofunction]}</div>
<!--{template common/footer}-->