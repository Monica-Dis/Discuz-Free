<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $index[num]}-->
<div class="dCLnSvalhpn4"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$adsearch}--><!--{/if}-->
<!--{/if}-->
<!--{if empty($albumlist)}-->
<div class="sqK9gG26iUGb">{lang search_nomatch}</div>
<!--{else}-->
<div class="4rRWOjBAfTFi">
    <ul id="alist" class="HwKFWtPXAVEl">
        <!--{loop $albumlist $key $value}-->
        <li>
            <a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]" >
                <!--{if $value['friend'] != 4 && ckfriend($value['uid'], $value['friend'], $value['target_ids'])}-->
                <img src="$value[pic]" />
                <!--{elseif $value['picnum']}-->
                <img src="template/v2_mbl20121009/touch_plus/image/defaultphoto_sc.png" />
                <!--{else}-->
                <img src="template/v2_mbl20121009/touch_plus/image/defaultphoto_sc.png" />
                <!--{/if}-->
                <h1>$value[albumname]</h1>
                <p>
                    <!--{if $value[picnum]}-->{$value[picnum]}P<!--{/if}-->
                    <span{if !$value[picnum]} class="m2eNVrMB63Zq"{/if}>{lang update} <!--{date($value[updatetime])}--></span>
                </p>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($index['num'] / $_G['tpp']);}-->
<!--{if $totalpage > $page}-->
<a href="search.php?mod=album&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}">$langplus[more]</a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->

