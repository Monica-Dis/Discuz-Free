<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $index[num]}-->
<div class="dCLnSvalhpn4"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$adsearch}--><!--{/if}-->
<!--{/if}-->
<!--{if empty($articlelist)}-->
<div class="sqK9gG26iUGb">{lang search_nomatch}</div>
<!--{else}-->
<div class="e0ootqekT0u0">
    <ul id="alist" class="HwKFWtPXAVEl">
        <!--{loop $articlelist $article}-->
        <li>
            <a href="portal.php?mod=view&aid=$article[aid]"{if !$article[pic]} class="BurbyZ7yftMO"{/if}>
            <!--{if $article[pic]}--><span class="eV6QZvlP57vk"><img src="$article[pic]" /></span><!--{/if}-->
            <h1>$article[title]</h1>
            <p>
                <!--{eval $article[catname] = DB::result_first("SELECT catname FROM ".DB::table('portal_category')." where catid = ".$article['catid'])}-->
                {$article[catname]}
                <span>$article[dateline]</span>
                <!--{if !$article[pic]}-->
                <!--{if $article[commentnum] > 9999 }-->
                <!--{eval $article[commentnum] = round($article[commentnum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $article[viewnum] > 9999 }-->
                <!--{eval $article[viewnum] = round($article[viewnum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $article[commentnum]}-->
                <span class="99u2LxYcMOhO">{$article[commentnum]}{lang comment}</span>
                <!--{else}-->
                <span class="99u2LxYcMOhO">{$article[viewnum]}{$langplus[view]}</span>
                <!--{/if}-->
                <!--{/if}-->
            </p>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($index['num'] / $_G['tpp']);}-->
<!--{if $totalpage > $page}-->
<a href="search.php?mod=portal&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}">$langplus[more]</a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->