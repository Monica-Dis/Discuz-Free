<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="search.php?mod=forum">{lang search}</a><!--{/block}-->
<!--{template common/header}-->
<!--{subtemplate search/navsearch}-->
	<form class="OMa2s8rMn5zP" method="post" autocomplete="off" action="search.php?mod=group" accept-charset="utf-8">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="srchfid" value="$srchfid" />
		<!--{subtemplate search/pubsearch}-->
	</form>
	<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
    <!--{if $searchlist == 1}-->
		<!--{if $srchfid}-->
			<!--{subtemplate search/thread_list_b}-->
		<!--{else}-->
			<!--{subtemplate search/group_list_b}-->
		<!--{/if}-->
	<!--{else}-->
		<!--{if $srchfid}-->
			<!--{subtemplate search/thread_list}-->
		<!--{else}-->
			<!--{subtemplate search/group_list}-->
		<!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
<!--{block footerplus}--><div class="TyCJXL60MXvY"></div><!--{/block}-->        
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->
<!--{/if}-->        
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->