<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="search.php?mod=forum">{lang search}</a><!--{/block}-->
<!--{template common/header}-->
<!--{subtemplate search/navsearch}-->
	<form id="searchform" method="post" autocomplete="off" action="search.php?mod=forum" accept-charset="utf-8">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{subtemplate search/pubsearch}-->
		<!--{eval $policymsgs = $p = '';}-->
		<!--{loop $_G['setting']['creditspolicy']['search'] $id $policy}-->
		<!--{block policymsg}--><!--{if $_G['setting']['extcredits'][$id][img]}-->$_G['setting']['extcredits'][$id][img] <!--{/if}-->$_G['setting']['extcredits'][$id][title] $policy $_G['setting']['extcredits'][$id][unit]<!--{/block}-->
		<!--{eval $policymsgs .= $p.$policymsg;$p = ', ';}-->
		<!--{/loop}-->
		<!--{if $policymsgs}--><div class="jOSLfRJQfClf"><p class="nT5D1jVvx6GB">{lang search_credit_msg}</p></div><!--{/if}-->
	</form>

<!--{if !empty($searchid) && submitcheck('searchsubmit', 1)}-->
<!--{if $searchlist == 1}-->
<!--{subtemplate search/thread_list_b}-->
<!--{else}-->
<!--{subtemplate search/thread_list}-->
<!--{/if}-->
<!--{else}--> 
<!--{if $_G['setting']['srchhotkeywords']}-->
<div class="searchhot{if $policymsgs} ptn{/if}">
<p>{$langplus[searchhot]}:</p>
<!--{loop $_G['setting']['srchhotkeywords'] $val}--> 
<!--{if $val=trim($val)}--> 
<!--{eval $classid = mt_rand(0, 4);}-->
<!--{eval $valenc=rawurlencode($val);}--> 
<!--{if !empty($searchparams[url])}--> 
<a href="$searchparams[url]?q=$valenc&source=hotsearch{$srchotquery}">$val</a>
<!--{else}--> 
<a href="search.php?mod=forum&srchtxt=$valenc&formhash={FORMHASH}&searchsubmit=true&source=hotsearch">$val</a>
<!--{/if}-->
<!--{/if}--> 
<!--{/loop}-->
</div>
<!--{/if}--> 
<!--{/if}--> 
<!--{block footerplus}--><div class="TyCJXL60MXvY"></div><!--{/block}-->        
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->
<!--{/if}-->        
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->