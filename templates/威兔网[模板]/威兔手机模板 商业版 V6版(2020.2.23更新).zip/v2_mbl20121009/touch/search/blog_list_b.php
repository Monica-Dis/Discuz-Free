<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $index[num]}-->
<div class="dCLnSvalhpn4"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$adsearch}--><!--{/if}-->
<!--{/if}-->
<!--{if empty($bloglist)}-->
<div class="sqK9gG26iUGb">{lang search_nomatch}</div>
<!--{else}-->
<div class="e0ootqekT0u0">
    <ul id="alist" class="HwKFWtPXAVEl">
        <!--{loop $bloglist $blog}-->
        <!--{eval $bolg['img'] = DB::result_first("SELECT pic FROM ".DB::table("home_blogfield")." where blogid=".$blog[blogid])}-->
        <li>
            <a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"{if !$blog[pic]} class="BurbyZ7yftMO"{/if}>
            <!--{if $blog[pic]}--><span class="eV6QZvlP57vk"><img src="{$blog[pic]}/{$bolg['img']}" /></span><!--{/if}-->
            <h1>$blog[subject]</h1>
            <p>
                {$blog[username]}
                <span>$blog[dateline]</span>
                <!--{if !$blog[pic]}-->
                <!--{if $blog[replynum] > 9999 }-->
                <!--{eval $blog[replynum] = round($blog[replynum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $blog[viewnum] > 9999 }-->
                <!--{eval $blog[viewnum] = round($blog[viewnum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $blog[replynum]}-->
                <span class="99u2LxYcMOhO">{$blog[replynum]}{lang comment}</span>
                <!--{else}-->
                <span class="99u2LxYcMOhO">{$blog[viewnum]}{$langplus[view]}</span>
                <!--{/if}-->
                <!--{/if}-->
            </p>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($index['num'] / $_G['tpp']);}-->
<!--{if $totalpage > $page}-->
<a href="search.php?mod=blog&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}">$langplus[more]</a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->