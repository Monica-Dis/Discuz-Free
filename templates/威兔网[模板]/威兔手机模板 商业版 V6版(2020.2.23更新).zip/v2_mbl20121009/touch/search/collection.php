<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="search.php?mod=portal">{lang search}</a><!--{/block}-->
<!--{template common/header}-->
<!--{subtemplate search/navsearch}-->
<div class="sqK9gG26iUGb">{lang collection}��{$langplus[nofunction]}</div>
<!--{template common