<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $index[num]}-->
<div class="dCLnSvalhpn4"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$adsearch}--><!--{/if}-->
<!--{/if}-->
<!--{if empty($threadlist)}-->
<div class="sqK9gG26iUGb">{lang search_nomatch}</div>
<!--{else}-->
<div class="EzoObafajtFG">
    <ul id="alist" class="HwKFWtPXAVEl">
        <!--{loop $threadlist $thread}-->
        <li>
            <a href="forum.php?mod=viewthread&tid=$thread[realtid]&highlight=$index[keywords]">
                <h1>$thread[subject]</h1>
                <p>
                    $thread[forumname]
                    <span>$thread[dateline]</span>
                    <!--{if $thread[replies] > 9999 }-->
                    <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[views] > 9999 }-->
                    <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[replies]}-->
                    <span class="99u2LxYcMOhO">{$thread[replies]}{lang join_thread}</span>
                    <!--{else}-->
                    <span class="99u2LxYcMOhO">{$thread[views]}{$langplus[view]}</span>
                    <!--{/if}-->
                </p>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($index['num'] / $_G['tpp']);}-->
<!--{if $totalpage > $page}-->
<a href="search.php?mod=forum&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}">$langplus[more]</a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->