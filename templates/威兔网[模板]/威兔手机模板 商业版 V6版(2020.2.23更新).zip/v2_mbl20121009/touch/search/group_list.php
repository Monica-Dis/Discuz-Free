<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $groupnum || $index[num]}-->
<div class="dCLnSvalhpn4"><!--{if $keyword && empty($searchstring[2])}-->{lang search_group_result_keyword}<!--{elseif $viewgroup}-->{lang search_group_result}<!--{else}-->{lang search_result}<!--{/if}--></div>
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$adsearch}--><!--{/if}-->
<!--{/if}-->
<!--{if $viewgroup}-->
<!--{if empty($grouplist)}-->
<div class="sqK9gG26iUGb">{lang search_nomatch}</div>
<!--{else}-->
<div class="4rRWOjBAfTFi">
    <ul>
        <!--{loop $grouplist $group}-->
        <li>
            <a href="forum.php?mod=group&fid=$group[fid]">
                <img src="$group[icon]" />
                <h1>$group[name]</h1>
                <p>
                    <!--{if $group[membernum] > 9999 }-->
                    <!--{eval $group[membernum] = round($group[membernum] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $group[threads] > 9999 }-->
                    <!--{eval $group[threads] = round($group[threads] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    {$group[membernum]}{lang member}
                    <span>{$group[threads]}{lang threads}</span>
                </p>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>

<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($groupnum / $_G['tpp']);}-->
<!--{if $totalpage > $page}-->
<a href="search.php?mod=group&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes&viewgroup=1" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}">$langplus[more]</a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{else}-->
<!--{if empty($grouplist) && empty($threadlist)}-->
<div class="sqK9gG26iUGb">{lang search_nomatch}</div>
<!--{else}-->

<!--{if !empty($grouplist) && $page < 2}-->
<div class="4rRWOjBAfTFi">
    <ul id="alist">
        <!--{loop $grouplist $group}-->
        <li>
            <a href="forum.php?mod=group&fid=$group[fid]">
                <img src="$group[icon]" />
                <h1>{$group[name]}</h1>
                <p>
                    <!--{if $group[membernum] > 9999 }-->
                    <!--{eval $group[membernum] = round($group[membernum] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $group[threads] > 9999 }-->
                    <!--{eval $group[threads] = round($group[threads] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    {$group[membernum]}{lang member}
                    <span>{$group[threads]}{lang threads}</span>
                </p>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{/if}-->
<!--{if !empty($threadlist)}-->
<div class="EzoObafajtFG">
    <ul id="alist" class="HwKFWtPXAVEl">
        <!--{loop $threadlist $thread}-->
        <li>
            <a href="forum.php?mod=viewthread&tid=$thread[tid]&highlight=$index[keywords]">
                <h1>$thread[subject]</h1>
                <p>
                    $thread[forumname]
                    <span>$thread[dateline]</span>
                    <!--{if $thread[replies] > 9999 }-->
                    <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[views] > 9999 }-->
                    <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread[replies]}-->
                    <span class="99u2LxYcMOhO">{$thread[replies]}{lang join_thread}</span>
                    <!--{else}-->
                    <span class="99u2LxYcMOhO">{$thread[views]}{$langplus[view]}</span>
                    <!--{/if}-->
                </p>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($index['num'] / $_G['tpp']);}-->
<!--{if $totalpage > $page}-->
<a href="search.php?mod=group&searchid=$searchid&orderby=$orderby&ascdesc=$ascdesc&searchsubmit=yes" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}">$langplus[more]</a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->