<?php echo 'From: DisM.taobao.com';exit;?>
     <!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
     <input type="hidden" name="searchsubmit" value="yes" />
     <div class="JFisFvnvOOmR">
		<table cellspacing="0" cellpadding="0">
			<tr>
			<td><input autocomplete="off" class="a2YoXwq2mvgz" name="srchtxt" id="scform_srchtxt" value="$keyword" placeholder="{lang enter_content}"></td>
			<th><button type="submit" id="scform_submit" class="iE5tROBSAh66" disable="true">{lang search}</button></th>            
			</tr>
		</table>
     </div>     
<script type="text/javascript">
$('#scform_srchtxt').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {
		$('#scform_submit').removeClass('nopost').addClass('btnon').attr('disable', 'false');		
	} else {
		$('#scform_submit').removeClass('btnon').addClass('nopost').attr('disable', 'true');		
	}	
	$('#scform_srchtxt').removeClass('nofocus');
	});	
$('#scform_srchtxt').blur(function(){
	var bt2obj = $('#scform_submit');	
	if(bt2obj.attr('disable') == 'true') {
		$('#scform_srchtxt').addClass('nofocus');
	}	
	});		
$('#scform_submit').on('click', function() {				
	var btobj = $(this);
	if(btobj.attr('disable') == 'true') {
		return false;
	}
	});
</script> 