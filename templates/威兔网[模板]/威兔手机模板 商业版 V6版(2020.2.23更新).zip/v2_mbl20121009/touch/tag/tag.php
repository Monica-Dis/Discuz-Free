<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="misc.php?mod=tag">{lang tag}</a><!--{/block}-->
<!--{template common/header}-->
      <div class="M9dz6Zrd0my4">
      <!--{if $type != 'countitem'}-->
      <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$adtag}--><!--{/if}-->
      <!--{if $tagarray}-->      
      <div id="tags" class="6exq4VnFr6Oq"> 
        <!--{loop $tagarray $tag}--> 
        <!--{eval $classid = mt_rand(0, 4);}-->
        <a href="misc.php?mod=tag&id=$tag[tagid]" class="tag{$classid}" >$tag[tagname]</a> 
        <!--{/loop}--> 
      </div>      
      <!--{else}-->
      <div class="sqK9gG26iUGb">{lang no_tag}</div>
      <!--{/if}-->     
      
      <div class="JFisFvnvOOmR">
      <form method="post" action="misc.php?mod=tag" accept-charset="utf-8">
		<table cellspacing="0" cellpadding="0">
		<tr>
		<td><input type="text" name="name" id="search_tagtxt" class="a2YoXwq2mvgz" placeholder="{lang tag}" /></td>
        <th><button type="submit" id="search_tagbtn" disable="true" class="iE5tROBSAh66">{lang search}</button></th>
		</tr>
		</table>
      </form>
      </div>
      
<script type="text/javascript" >		
$('#search_tagtxt').on('keyup input focus', function() {
	var obj = $(this);
	if(obj.val()) {		
		$('#search_tagbtn').removeClass('nopost').addClass('btnon').attr('disable', 'false');
	} else {		
		$('#search_tagbtn').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
	}
	$('#search_tagtxt').removeClass('nofocus');
	});	
$('#search_tagtxt').blur(function(){
	var bt2obj = $('#search_tagbtn');	
	if(bt2obj.attr('disable') == 'true') {
		$('#search_tagtxt').addClass('nofocus');
	}	
	});
$('#search_tagbtn').on('click', function() {				
	var btobj = $(this);
	if(btobj.attr('disable') == 'true') {
		return false;
	}
	});	
</script>
      
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->
<!--{/if}-->     
<!--{block footerplus}--><div class="TyCJXL60MXvY"></div><!--{/block}-->
     <!--{eval $nofooter = true;}-->     
     <!--{else}-->
      $num
     <!--{/if}--> 
     </div>     
<!--{template common/footer}-->