<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="misc.php?mod=tag">{lang tag}<!--{if $tagname}-->: {$tagname}<!--{/if}--></a><!--{/block}-->
<!--{template common/header}-->
<!--{if $tagname}-->
<!--{if empty($showtype) || $showtype == 'thread'}-->
<!--{if $threadlist}-->
<!--{if empty($showtype)}-->
<h2 class="XUqdfpkCFaHt">{lang related_thread}</h2>
<!--{/if}-->
<ul id="alist" class="HwKFWtPXAVEl">
    <!--{if $tagslist == 1}-->
    <!--{loop $threadlist $thread}-->
    <!--{eval $imgnumber = 1;}-->
    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/threadlist.php');}-->
    <li class="uJYyfGzLxp7x">
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="th_item{if !$thread['thumb']} nopic{/if}" >
            <!--{if $thread['thumbfirst']}-->
            <!--{eval $imagethumb = getforumimg($thread['thumbfirst'], 0, 200, 150); }-->
            <span class="eV6QZvlP57vk"><img src="$imagethumb" /></span>
            <!--{/if}-->
            <h1>
                <!--{if $thread['displayorder'] > 0}-->
                <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;
                <!--{/if}-->
                <!--{if $thread['digest'] > 0}-->
                <em class="GR92yicG3zyZ">$langplus[digest]</em> &middot;
                <!--{/if}-->
                {$thread[subject]}
            </h1>
            <div class="hNOK3poJcpFf">
                <!--{if $thread['authorid'] && $thread['author']}--><span>$thread[author]</span><!--{else}--><span>$_G[setting][anonymoustext]</span><!--{/if}-->
                <span>{$thread[dateline]}</span>
                <!--{if $thread[replies]}-->
                <!--{if $thread[replies] > 9999 }-->
                <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $thread['isgroup'] != 1}-->
                <!--{if $thread[views] > 9999 }-->
                <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $groupnames[$thread[tid]][views] > 9999 }-->
                <!--{eval $groupnames[$thread[tid]][views] = round($groupnames[$thread[tid]][views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->
                <span class="99u2LxYcMOhO"><!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}--><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->{$langplus[view]}<!--{/if}--></span>
            </div>
        </a>
    </li>
    <!--{/loop}-->
    <!--{else}-->
    <!--{loop $threadlist $thread}-->
    <li class="0SjyuQop6KJp">
        <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="yUloUBxjglb3">
            <h1>
                <!--{if $thread[folder] == 'lock'}-->
                <em>{lang close}</em> &middot;
                <!--{elseif $thread['special'] == 1}-->
                <em>{lang thread_poll}</em> &middot;
                <!--{elseif $thread['special'] == 2}-->
                <em>{lang thread_trade}</em> &middot;
                <!--{elseif $thread['special'] == 3}-->
                <em>{lang thread_reward}</em> &middot;
                <!--{elseif $thread['special'] == 4}-->
                <em>{lang thread_activity}</em> &middot;
                <!--{elseif $thread['special'] == 5}-->
                <em>{lang thread_debate}</em> &middot;
                <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                <em>$langplus[top]</em> &middot;
                <!--{elseif $thread['digest'] > 0}-->
                <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[digest]</em> &middot;
                <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                <em class="0rM8odj7aKyi">$langplus[pic]</em> &middot;
                <!--{/if}-->
                <!--{if $thread['digest'] > 0}-->
                <em class="GR92yicG3zyZ">$langplus[digest]</em> &middot;
                <!--{/if}-->
                {$thread[subject]}
                <!--{if $thread['price'] > 0}-->
                <span class="DDhgGdFCeBwj"> -
                    <!--{if $thread['special'] == '3'}-->
                    {lang thread_reward} $thread[price] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}
                    <!--{else}-->
                    {lang price} $thread[price] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}
                    <!--{/if}-->
                </span>
                <!--{/if}-->
            </h1>
            <div class="hNOK3poJcpFf">
                <!--{if $thread['authorid'] && $thread['author']}--><span>$thread[author]</span><!--{else}--><span>$_G[setting][anonymoustext]</span><!--{/if}-->
                <span>{$thread[dateline]}</span>
                <span class="WAO1ETmvH49Y">#{$thread['forumname']}</span>
                <!--{if $thread[replies]}-->
                <!--{if $thread[replies] > 9999 }-->
                <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $thread[views] > 9999 }-->
                <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{/if}-->
                <span class="99u2LxYcMOhO"><!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}-->$thread[views]{$langplus[view]}<!--{/if}--></span>
            </div>
        </a>
    </li>
    <!--{/loop}-->
    <!--{/if}-->
</ul>
<!--{if empty($showtype)}-->
<div class="tagmore{if $bloglist} bb{/if}"><a href="misc.php?mod=tag&id=$id&type=thread">{lang more}...</a></div>
<!--{else}-->
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($count / $tpp);}-->
<!--{if $totalpage > $page}-->
<a href="misc.php?mod=tag&id=$tag[tagid]&type=thread" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{elseif !$bloglist}-->
<div class="sqK9gG26iUGb">{lang no_content}</div>
<!--{/if}-->
<!--{/if}-->

<!--{if helper_access::check_module('blog') && (empty($showtype) || $showtype == 'blog')}-->
<!--{if $bloglist}-->
<!--{if empty($showtype)}-->
<h2 class="XUqdfpkCFaHt">{lang related_blog}</h2>
<!--{/if}-->
<ul id="alist" class="HwKFWtPXAVEl">
    <!--{loop $bloglist $blog}-->
    <li class="0SjyuQop6KJp">
        <a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]" class="TXibfwVZLxRN">
            <img src="{avatar($blog[uid], middle, true)}" class="x9hHSPQjdnYg">
            <h1>$blog['subject']</h1>
            <!--{if $blog[message]}--><div class="DoZfsRZN0c69">{echo cutstr(strip_tags($blog[message]),120)}</div><!--{/if}-->
            <div class="hNOK3poJcpFf">
                <span>$blog[username]</span>
                <span>$blog[dateline]</span>
                <!--{if $blog[classname]}--><span class="WAO1ETmvH49Y">#{$blog[classname]}</span><!--{/if}-->
                <span class="99u2LxYcMOhO">
                    <!--{if $blog['hot']}--><i class="c17iFPR1sf2l"></i> &nbsp;<!--{/if}-->
                    <!--{if $blog[replynum]}-->
                    <!--{if $blog[replynum] > 9999 }-->
                    <!--{eval $blog[replynum] = round($blog[replynum] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{else}-->
                    <!--{if $blog[viewnum] > 9999 }-->
                    <!--{eval $blog[viewnum] = round($blog[viewnum] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{if $blog[replynum]}-->
                    {$blog[replynum]}{$langplus[comment]}
                    <!--{else}-->
                    {$blog[viewnum]}{$langplus[view]}
                    <!--{/if}-->
                </span>
            </div>
        </a>
    </li>
    <!--{/loop}-->
</ul>
<!--{if empty($showtype)}-->
<div class="H53Efec0dSE7"><a href="misc.php?mod=tag&id=$id&type=blog">{lang more}...</a></div>
<!--{else}-->
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($count / $tpp);}-->
<!--{if $totalpage > $page}-->
<a href="misc.php?mod=tag&id=$tag[tagid]&type=blog" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{elseif !$threadlist}-->
<div class="sqK9gG26iUGb">{lang no_content}</div>
<!--{/if}-->
<!--{/if}-->

<!--{else}-->
<div class="sqK9gG26iUGb">{lang empty_tags}</div>
<!--{/if}-->

<div class="JFisFvnvOOmR">
    <form method="post" action="misc.php?mod=tag" accept-charset="utf-8">
        <table cellspacing="0" cellpadding="0">
            <tr>
                <td><input type="text" name="name" id="search_tagtxt" class="a2YoXwq2mvgz" placeholder="{lang tag}" /></td>
                <th><button type="submit" id="search_tagbtn" disable="true" class="iE5tROBSAh66">{lang search}</button></th>
            </tr>
        </table>
    </form>
</div>

<script type="text/javascript" >
    $('#search_tagtxt').on('keyup input focus', function() {
        var obj = $(this);
        if(obj.val()) {
            $('#search_tagbtn').removeClass('nopost').addClass('btnon').attr('disable', 'false');
        } else {
            $('#search_tagbtn').removeClass('btnon').addClass('nopost').attr('disable', 'true');
        }
        $('#search_tagtxt').removeClass('nofocus');
    });
    $('#search_tagtxt').blur(function(){
        var bt2obj = $('#search_tagbtn');
        if(bt2obj.attr('disable') == 'true') {
            $('#search_tagtxt').addClass('nofocus');
        }
    });
    $('#search_tagbtn').on('click', function() {
        var btobj = $(this);
        if(btobj.attr('disable') == 'true') {
            return false;
        }
    });
</script>

<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->
<!--{/if}-->
<!--{block footerplus}--><div class="TyCJXL60MXvY"></div><!--{/block}-->
<!--{eval $nofooter = true;}-->

<!--{template common/footer}-->