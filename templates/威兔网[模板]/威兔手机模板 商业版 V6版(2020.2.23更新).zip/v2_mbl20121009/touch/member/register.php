<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang register}<!--{/block}-->
<!--{block rightbutton}-->
<a href="forum.php" class="vt-home fz0 gohome">$langplus[home]</a>
<!--{/block}-->
<!--{template common/header}-->

<!-- registerbox start -->
<div class="loginbox registerbox userbox mobile_register">
<!--{if $tpluserhi}--><div class="userplus"><!--{$tpluserhi}--></div><!--{/if}-->	
		<form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}&mobile=2">
		<input type="hidden" name="regsubmit" value="yes" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
		<input type="hidden" name="referer" value="$dreferer" />
		<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
		<input type="hidden" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
		<div class="userfrom login_from">
        <ul>
			<li class="username_m"><input type="text" tabindex="1" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip}" fwin="login"></li>
			<li class="password_m"><input type="password" tabindex="2" size="30" value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password}" fwin="login"></li>
			<li class="password_m"><input type="password" tabindex="3" size="30" value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2}" fwin="login"></li>
			<li class="email_m"><input type="email" tabindex="4" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login"></li>
            <!--{loop $_G['cache']['fields_register'] $field}-->
			<!--{if $htmls[$field['fieldid']]}-->
            <!--{eval $regfieldid = array(birthcity,residecity);}-->
			<!--{if !in_array($field['fieldid'],$regfieldid) && $field['formtype'] == 'select'}-->             
            <li class="questionli"><div class="register_select"><span class="fieldname">$field[title]</span>$htmls[$field['fieldid']]</div></li>
            <!--{else}-->                                                     
            <li><input type="text" size="30" value="" id="$field['fieldid']" name="$field['fieldid']" placeholder="$field[title]" fwin="login"></li>
            <!--{/if}-->
			<!--{/if}-->
			<!--{/loop}-->
			<!--{if empty($invite) && ($_G['setting']['regstatus'] == 2 || $_G['setting']['regstatus'] == 3)}-->
			<li><input type="text" name="invitecode" autocomplete="off" tabindex="5" size="30" value="" placeholder="{lang invite_code}" fwin="login"></li>
			<!--{/if}-->
			<!--{if $_G['setting']['regverify'] == 2}-->
			<li><input type="text" name="regmessage" autocomplete="off" tabindex="6" size="30" value="" placeholder="{lang register_message}" fwin="login"></li>
			<!--{/if}-->
            <!--{if $secqaacheck || $seccodecheck}--><div class="userfrom_sec"><!--{subtemplate common/seccheck}--></div><!--{/if}-->
            <div class="btn_register"><button tabindex="7" value="true" name="regsubmit" type="submit" class="formdialog button5">{lang register}</button></div>
            <div class="reg_link">            
            <a href="member.php?mod=logging&action=login&viewlostpw=1" class="z">{lang forgotpw}?</a>
            <a href="member.php?mod=logging&action=login" class="y">{$langplus[login_now]}</a>
            </div>
		</ul>
        </div>
	</form>
</div>

<!-- registerbox end -->
<!--{eval updatesession();}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->