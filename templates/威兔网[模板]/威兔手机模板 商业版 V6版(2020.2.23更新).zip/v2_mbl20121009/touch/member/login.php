<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $_GET['viewlostpw'] == 1}-->{lang getpassword}<!--{else}-->{lang login}<!--{/if}--><!--{/block}-->
<!--{block rightbutton}-->
<a href="forum.php" class="vt-home fz0 gohome">$langplus[home]</a>
<!--{/block}-->
<!--{template common/header}-->

{eval $loginhash = 'L'.random(4);}

<!-- userinfo start -->
<!--{if $_GET['viewlostpw'] == 1}-->
        <div class="loginbox{if $_GET[infloat] || $_G['inajax']} login_pop{/if} userbox">
		<form method="post" autocomplete="off" id="lostpwform_$loginhash" onsubmit="ajaxpost('lostpwform_$loginhash', 'returnmessage3_$loginhash', 'returnmessage3_$loginhash', 'onerror');return false;" action="member.php?mod=lostpasswd&lostpwsubmit=yes&infloat=yes">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="handlekey" value="lostpwform" />
           <div class="userfrom login_from">
               <ul>				
				<li class="email_m"><input type="text" name="email" id="lostpw_email" size="30" value=""  tabindex="1" placeholder="{lang email}" /></li>
				<li class="username_m"><input type="text" name="username" id="lostpw_username" size="30" value=""  tabindex="1" placeholder="{lang username}" /></li>
				<div class="btn_login"><button class="formdialog button5" type="submit" name="lostpwsubmit" value="true" tabindex="100">{lang submit}</button></div> 
               </ul>
           </div>
		</form>
        </div> 
<!--{else}-->
<div class="loginbox{if $_GET[infloat] || $_G['inajax']} login_pop{/if} userbox">
<!--{if $tpluserhi}--><div class="userplus"><!--{$tpluserhi}--></div><!--{/if}-->
		<form id="loginform" method="post" action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
		<input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
		<input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
		<input type="hidden" name="fastloginfield" value="username">
		<input type="hidden" name="cookietime" value="2592000">
		<!--{if $auth}-->
			<input type="hidden" name="auth" value="$auth" />
		<!--{/if}-->
	<div class="userfrom login_from">
		<ul>
			<li class="username_m"><input type="text" value="" tabindex="1" size="30" autocomplete="off" value="" name="username" placeholder="{lang inputyourname}" fwin="login"></li>
			<li class="password_m"><input type="password" tabindex="2" size="30" value="" name="password" placeholder="{lang login_password}" fwin="login"></li>
			<li class="questionli ask_m">
				<div class="login_select">					
				<span class="span_question">{lang security_question}</span>
				<select id="questionid_{$loginhash}" name="questionid" class="sel_list">
					<option value="0" selected="selected">{lang security_question}</option>
					<option value="1">{lang security_question_1}</option>
					<option value="2">{lang security_question_2}</option>
					<option value="3">{lang security_question_3}</option>
					<option value="4">{lang security_question_4}</option>
					<option value="5">{lang security_question_5}</option>
					<option value="6">{lang security_question_6}</option>
					<option value="7">{lang security_question_7}</option>
				</select>
				</div>
			</li>
			<li class="answerli answer_m" style="display:none;"><input type="text" name="answer" id="answer_{$loginhash}" size="30" placeholder="{lang security_a}"></li>
            <!--{if $seccodecheck}--><div class="userfrom_sec"><!--{subtemplate common/seccheck}--></div><!--{/if}-->
            <div class="btn_login"><button tabindex="3" value="true" name="submit" type="submit" class="formdialog button5">{lang login}</button></div>
            <div class="reg_link">
            <a href="member.php?mod=logging&action=login&viewlostpw=1" class="{if $_G['setting']['regstatus']}z{else}y{/if}">{lang forgotpw}?</a>
            <!--{if $_G['setting']['regstatus']}-->
            <a href="member.php?mod={$_G[setting][regname]}" class="y">{$langplus[register_now]}</a>
            <!--{/if}-->            
            </div>
            <!--{if $loginplus}-->
            <div class="login_plus">
            <div class="login_plus_name"><span><!--{$loginplus}--></span></div>             
            <!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
            <a href="$_G[connect][login_url]&statfrom=login_simple" class="qqlogin">{lang qqconnect:connect_mobile_login}</a>
            <!--{/if}-->
            <!--{hook/logging_bottom_mobile}--> 
            </div>
            <!--{/if}-->     
		</ul>
	</div>	
	</form>
</div>
<!--{/if}-->    
<!-- userinfo end -->

<!--{if $_G['setting']['pwdsafety']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<!--{/if}-->
<!--{eval updatesession();}-->

<script type="text/javascript">
	(function() {
		$(document).on('change', '.sel_list', function() {
			var obj = $(this);
			$('.span_question').text(obj.find('option:selected').text());
			if(obj.val() == 0) {
				$('.answerli').css('display', 'none');				
			} else {
				$('.answerli').css('display', 'block');				
			}
		});
	 })();
</script>

<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->