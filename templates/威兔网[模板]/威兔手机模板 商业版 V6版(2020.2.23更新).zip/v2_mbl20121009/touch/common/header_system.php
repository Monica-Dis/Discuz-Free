<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval require_once(DISCUZ_ROOT.'./source/plugin/v2_wap_03/mobile.setup.php');}-->
<!--{eval require_once(DISCUZ_ROOT.'./source/plugin/v2_wap_03_plus/mobile.setup.php');}-->
<!--{eval require_once(DISCUZ_ROOT.'./source/plugin/v2_wap_03/corefile/system.core.php');}-->
<!--{eval require_once(DISCUZ_ROOT.'./template/v2_mbl20121009/touch_plus/language/lang_'.currentlang().'.php');}-->
<!--{eval $characterset = strtolower(currentlang());}-->
<!--{eval loaducenter(); $smscheck = uc_pm_checknew($_G['uid']);}-->
<!--{block ajaxsubmit_item}-->
<script type="text/javascript">
	$(document).on('click','.ajaxfav',function(){
        <!--{if !$_G[uid]}-->
        popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
        <!--{else}-->
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=ajaxfav&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})		
		.success(function(s) {
			var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
			var favid = s.lastChild.firstChild.nodeValue.match(/'favid':'(.+?)'/i)[1];
			var oksmg = '{$langplus[favsuccess]}';
			if(smg.indexOf(oksmg) >= 0){
				$('.ajaxdata').addClass('ajaxdelfav').removeClass('ajaxfav');
				$('.ajaxdata').children().addClass('vt-favempty').removeClass('vt-fav');
				$('.ajaxdata').attr('href', 'home.php?mod=spacecp&ac=favorite&op=delete&favid=' + favid + '&formhash={FORMHASH}');
                <!--{if $_G['basescript'] == 'forum' && CURMODULE == forumdisplay }-->
                $('.forumfavbtn').addClass('ajaxdelfav forumcollected').removeClass('ajaxfav').html('{$langplus[favorite_in]}');
                $('.forumfavbtn').attr('href', 'home.php?mod=spacecp&ac=favorite&op=delete&favid=' + favid + '&formhash={FORMHASH}');
                <!--{/if}-->
			}else{
				popup.open('<div class="tip"><dt>'+smg+'</dt></div>');
				setTimeout(function(){
					$(".dialogbox, #mask").fadeOut();					
					}, 1500);
			}
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
        <!--{/if}-->
		return false;
	});
	<!--{if $_G[uid]}-->
	$(document).on('click','.ajaxdelfav',function(){
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=ajaxdelfav&inajax=1',
			data:{'deletesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {	
			var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
			var tid = s.lastChild.firstChild.nodeValue.match(/'id':'(.+?)'/i)[1];
			var oksmg = '{$langplus[oksuccess]}';			
			if(smg.indexOf(oksmg) >= 0){
				$('.ajaxdata').addClass('ajaxfav').removeClass('ajaxdelfav');
				$('.ajaxdata').children().addClass('vt-fav').removeClass('vt-favempty');
				<!--{if $_G['basescript'] == 'forum' && CURMODULE == forumdisplay }-->
                $('.forumfavbtn').addClass('ajaxfav').removeClass('ajaxdelfav forumcollected').html('{$langplus[favorite]}');
				$('.ajaxdata, .forumfavbtn').attr('href', 'home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}');
				<!--{elseif $_G['basescript'] == 'forum' && CURMODULE == viewthread || $_G['basescript'] == 'group' && CURMODULE == viewthread }-->
				$('.ajaxdata').attr('href', 'home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}');
				<!--{elseif $_G['basescript'] == 'portal' && CURMODULE == view }-->
				$('.ajaxdata').attr('href', 'home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}');
				<!--{elseif $_G['basescript'] == 'group' && CURMODULE == forumdisplay }-->
				$('.ajaxdata').attr('href', 'home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}');
				<!--{elseif $_G['basescript'] == 'home' && CURMODULE == space && $_GET['do'] == album }-->
				$('.ajaxdata').attr('href', 'home.php?mod=spacecp&ac=favorite&type=album&id=$album[albumid]&spaceuid=$space[uid]&handlekey=sharealbumhk_{$album[albumid]}');
				<!--{elseif $_G['basescript'] == 'home' && CURMODULE == space && $_GET['do'] == blog }-->
				$('.ajaxdata').attr('href', 'home.php?mod=spacecp&ac=favorite&type=blog&id=$blog[blogid]&spaceuid=$blog[uid]&handlekey=favoritebloghk_{$blog[blogid]}');
				<!--{/if}-->
			}else{
				popup.open('<div class="tip"><dt>'+smg+'</dt></div>');
				setTimeout(function(){
					$(".dialogbox, #mask").fadeOut();					
					}, 1500);
			}
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});
	<!--{/if}-->

	$(document).on('click','.ajaxsupport',function(){
        <!--{if !$_G[uid]}-->
        popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
        <!--{else}-->
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=ajaxjump&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
			var oksmg = '{$langplus[pollsucceed]}';
			if(smg.indexOf(oksmg) >= 0 || smg.indexOf('+1') >= 0){
				var i = $(obj).prev().text();
				i++;				
				$(obj).prev().addClass('insuccess').text(i).show();				
			}else{
				popup.open('<div class="tip"><dt>'+smg+'</dt></div>');				
				setTimeout(function(){
					$(".dialogbox, #mask").fadeOut();					
					}, 1500);	
			}
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
        <!--{/if}-->
		return false;
	});

	$(document).on('click','.ajaxlink',function(){
        <!--{if !$_G[uid]}-->
        popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
        <!--{else}-->
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=ajaxlink&inajax=1',
			data:{'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {			
			var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
			popup.open('<div class="tip"><dt>'+smg+'</dt></div>');
			setTimeout(function(){ 
				$(".dialogbox, #mask").fadeOut();					
				}, 1500);			
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
        <!--{/if}-->
		return false;
	});
</script>
<!--{/block}--> 

<!--{block formsdialog_item}-->
<script type="text/javascript">
		$(document).on('click', '.formsdialog', function() {
			popup.open('<div class="cloading"></div>');
			var obj = $(this);
			var formobj = $(this.form);
			$.ajax({
				type:'POST',
				url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
				data:formobj.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				window.location.reload();
				//popup.open();				
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			return false;
		});
</script>
<!--{/block}--> 