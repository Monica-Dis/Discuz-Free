<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div id="ct" class="E2rtLlMrC7w2">
	<div class="Hwo4Ms30B8m6" style="width: 370px; height: 550px; background: url({STATICURL}image/mobile/preview.png) no-repeat 0 0;">
		<iframe id="ifm0" frameborder="0" width="240" height="360" style="margin: 102px 0 0 70px;" src="misc.php?mod=mobile&view=true"></iframe>
	</div>
	<div class="Hwo4Ms30B8m6" style="margin-top: 60px; width: 530px;">
		<div class="IbzGKEBlPf6z" style="background-color: #dfeaf4;">
			<div class="l9K70iwEMBKw">
				<h1 class="NnpLVNRSnwPS">{lang login_mobile}</h1>
				<p class="4abJfdWa2Own">{lang login_mobile_join}</p>
				<p class="rNYj7RWt2teC" style="font-size: 18px; color: #F60;">
					<!--{if $_G['setting']['domain']['app']['mobile']}-->
						http://{$_G['setting']['domain']['app']['mobile']}
					<!--{else}-->
						{$_G['siteurl']}forum.php
					<!--{/if}-->
				</p>
			</div>
		</div>
		<div class="oqbj6eglqkrR">
			<dl class="w5UD6iecTkxT">
				<dt class="eulO9RXT6w7x">{lang mobile_favorite}</dt>
				<dd>{lang mobile_favorite_comment}</dd>
			</dl>
			<dl class="w5UD6iecTkxT">
				<dt class="eulO9RXT6w7x">{lang mobile_viewthread}</dt>
				<dd>{lang mobile_viewthread_comment}</dd>
			</dl>
			<dl class="8yRU9bAioZYu">
				<dt class="eulO9RXT6w7x">{lang mobile_pm}</dt>
				<dd>{lang mobile_other_1}</dd>
			</dl>
		</div>
	</div>
</div>
<!--{template common/footer}-->