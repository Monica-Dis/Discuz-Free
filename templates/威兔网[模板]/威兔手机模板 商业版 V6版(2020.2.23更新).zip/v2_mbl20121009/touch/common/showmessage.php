<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $param['login']}-->
	<!--{if $_G['inajax']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login&inajax=1&infloat=1');exit;}-->
	<!--{else}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
	<!--{/if}-->
<!--{/if}-->
<!--{block header_name}-->{lang board_message}<!--{/block}-->
<!--{template common/header}-->
<!--{if $_G['inajax']}-->

<div class="tip">
	<dt id="messagetext">
		<p class="message_float">$show_message</p>
        <!--{if $_G['forcemobilemessage']}-->
        	<p>
            <a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
            <a href="javascript:history.back();">{lang goback}</a>
            </p>
        <!--{/if}-->
		<!--{if $url_forward && !$_GET['loc']}-->			
			<script type="text/javascript">
				setTimeout(function() {
					window.location.href = '$url_forward';
				}, '1500');
			</script>
		<!--{elseif $allowreturn}-->
        <!--//<a href="javascript:;" onclick="popup.close();" class="mes_close"></a>//-->       
		<!--{/if}-->
	</dt>
</div>

<!--{else}-->

<!-- main jump start -->
<div class="jump_c">
	<div class="message_float mbm">$show_message</div>
    <!--{if $_G['forcemobilemessage']}-->
		<p>
        <a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
        <a href="javascript:history.back();">{lang goback}</a>
        </p>
    <!--{/if}-->
	<!--{if $url_forward}-->
		<p><a href="$url_forward">{lang message_forward_mobile}</a></p>
	<!--{elseif $allowreturn}-->
		<p><a href="javascript:history.back();">{lang message_go_back}</a></p>
	<!--{/if}-->
</div>
<!-- main jump end -->

<!--{/if}-->
<!--{template common/footer}-->