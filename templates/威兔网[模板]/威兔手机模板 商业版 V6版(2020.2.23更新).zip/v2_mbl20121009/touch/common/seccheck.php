<?php echo 'From: DisM.taobao.com';exit;?>
{eval
	$sechash = 'S'.random(4);
	$sectpl = !empty($sectpl) ? explode("<sec>", $sectpl) : array('<br />',': ','<br />','');	
	$ran = random(5, 1);
}
<!--{if $secqaacheck}-->
<!--{eval
	$message = '';
	$question = make_secqaa();
	$secqaa = $question;
}-->
<!--{/if}-->
<!--{if $sectpl}-->
	<!--{if $secqaacheck}-->
		<div class="RhHsjqw8LA3S">
        {lang secqaa}: $secqaa	
        <input name="secqaahash" type="hidden" value="$sechash" />
        <input name="secanswer" id="secqaaverify_$sechash" type="text" class="Vr8roDqLu0ce" size="12" placeholder="{lang security_a}" />
        </div>
	<!--{/if}-->
	<!--{if $seccodecheck}-->    
		<div class="jBBGCGB91CzL">
		<input name="seccodehash" type="hidden" value="$sechash" />
        <table cellspacing="0" cellpadding="0" width="100%">
        <tr>
        <th width="{$_G['setting'][seccodedata][width]}"><img src="misc.php?mod=seccode&update={$ran}&idhash={$sechash}&mobile=2" class="Bob93lBVroM4"/></th>
        <td><input type="text" class="sectxt{if $_G['setting'][seccodedata][type] == 1} imea{else} imed{/if}" autocomplete="off" value="" id="seccodeverify_$sechash" name="seccodeverify" placeholder="{lang seccode}" fwin="seccode"></td>
        </tr>
        </table>    
		</div>
	<!--{/if}-->
<!--{/if}-->
<script type="text/javascript">
	(function() {
		$('.seccodeimg').on('click', function() {
			$('#seccodeverify_$sechash').attr('value', '');
			var tmprandom = 'S' + Math.floor(Math.random() * 1000);
			$('.sechash').attr('value', tmprandom);
			$(this).attr('src', 'misc.php?mod=seccode&update={$ran}&idhash='+ tmprandom +'&mobile=2');
		});
	})();
</script>
