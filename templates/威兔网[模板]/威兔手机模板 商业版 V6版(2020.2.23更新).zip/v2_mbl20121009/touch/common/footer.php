<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
</div>
<!--{hook/global_footer_v2_mobile}-->
<!--{if $closeplugin == 0}-->
<!--{hook/global_footer_mobile}-->
<!--{/if}-->
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$adfooter}--><!--{/if}-->
<div id="mask" style="display:none;"></div>
</div>

<!--{if $_G['basescript'] != member }-->
<!--{if $nologintplplus == 1}-->
<!--{if !$_G[uid] && !$_G['connectguest']}--><!--{$tplplusb}--><!--{/if}-->
<!--{else}-->
<!--{$tplplusb}-->
<!--{/if}-->
<!--{/if}-->
<!--{if !$nofooter && $footershow}-->
<footer>
    <div class="60mwnxIWnpHM">
        <!--{if $bottombutton}-->
        <!--{$bottombutton}-->
        <!--{else}-->
        <ul>
            <!--{if $footerone}-->
            <!--{$footerone}-->
            <!--{else}-->
            <!--{if $tplwapurl}-->
            <li{if $onindexs} class="d3R6po5JMujx"{/if}><a href="forum.php"><i class="vYwrd8Li1T3q"></i>$langplus[home]</a></li>
            <li{if $_G['basescript'] == 'forum' && $_GET[mod] != 'guide'} class="Yfm1QC5IeoTk"{/if}><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>{$langplus[bbs]}</a></li>
            <!--{else}-->
            <li{if $_G['basescript'] == 'forum' && $_GET[mod] != 'guide'} class="Yfm1QC5IeoTk"{/if}><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>{$langplus[bbs]}</a></li>
            <!--{$footertwo}-->
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $footerthree}--><!--{$footerthree}--><!--{else}--><li><div class="WoyeIPgSVIYX"><a href="javascript:;" class="i0a6HFurbhHA"><!--{if $footerbib}--><!--{$footerbib}--><!--{else}--><i class="TUyhBUhh3Ulh"></i><!--{/if}--></a></div></li><!--{/if}-->
            <!--{$footerfour}-->
            <!--{if $footerfive}-->
            <!--{$footerfive}-->
            <!--{else}-->
            <li{if $_G['basescript'] == 'home' && $_GET[mod] == 'space' && $_GET[do] == 'profile'} class="Yfm1QC5IeoTk"{/if}>
            <!--{if !$_G[uid] && !$_G['connectguest']}-->
            <a href="member.php?mod=logging&action=login"><i class="0iHKtK6RqXLZ"></i>{lang login}</a>
            <!--{else}-->
            <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="0iHKtK6RqXLZ"></i>$langplus[me]</a>
            <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="Iug1I7rXnrOf"></i><!--{/if}-->
            <!--{/if}-->
            </li>
            <!--{/if}-->
        </ul>
        <!--{/if}-->
    </div>
</footer>
<!--{if !$bottombutton && !$footerthree}-->
<div class="okiZRruefurv">
	<!--{if $adpopupmenu}-->$adpopupmenu<!--{/if}-->
	<ul class="BoeMflVRYPtC">
		<!--{hook/global_popupmenus_v2_mobile}-->
	</ul>
	<div class="TwgSz84HaUL9"><i class="ZniOo1BALmJd"></i></div>
</div>
<div class="3BpUTDuPIV3L"></div>
<script type="text/javascript">
	$(document).ready(function(){
		$('.btn_pop').click(function(){
			$('.menus_popup').slideToggle();
			$('.close_p').delay(300).fadeIn();
		});
		$('.close_p, .menus_popup_close').click(function(){
			$('.menus_popup').slideToggle();
			$('.close_p').hide();
		});
	});
</script>
<!--{/if}-->
<!--{/if}-->
<!--{$footerplus}-->
<!--{$scrollplus}-->
<!--{if !$headershow && !$nosopenmenu}-->
<a href="javascript:;" class="bsANtZopabHG"></a>
<style type="text/css">.scroll_plus { bottom: 127px; }</style>
<!--{/if}-->

<nav class="6Kyun4zh22e5">
<div class="1zQoOMY7WjBw">
<!--{eval $classid = mt_rand(1,7); $onweek = date('w');}-->
<div class="sideuser sd{if $sideuserbg == 8}{$onweek}{elseif $sideuserbg > 0 && $sideuserbg < 8}{$sideuserbg}{else}{$classid}{/if}">
<!--{if $_G['uid'] || $_G['connectguest']}-->
<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="GKwF027BVCmr"><img src="{avatar($_G[uid], big, true)}?{VERHASH}"></a>
<div class="X6JwbGXXeSRv">
	<a href="home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1" class="E46c8qBNJVoB">{$_G['member']['username']}</a>
	<!--{if $_G[group][stars] > 0}--><i class="3Js4OPBe9n4d">Lv.$_G[group][stars]</i><!--{/if}-->
</div>
<!--{if $misignshow == 1}-->
<div class="heDDHoXuYaWQ"><!--{hook/global_misign_mobile}--></div>
<!--{/if}-->
<!--{else}-->
<a href="member.php?mod=logging&action=login" class="sw2jjKL2ozK7">{lang login}<!--{if $_G['setting']['regstatus']}-->/{lang register}<!--{/if}--></a>
<!--{/if}-->
<div class="WVhCpmZ6YUn4"></div>
</div>
<!--{if $_G['uid']}-->
<div class="sidequickmenu{if $searchmode} bbno{/if}">
	<ul>
		<li><a href="home.php?mod=space&do=pm"{if $_G[member][newpm] || $smscheck} class="Iug1I7rXnrOf"{/if}><i class="QYLIQwGB8Fp4"></i><span>{lang pm_center}</span><!--{if $_G[member][newpm] || $smscheck}--><em>N</em><!--{/if}--></a></li>
		<li><a href="home.php?mod=space&do=notice"{if $_G[member][newprompt]} class="Iug1I7rXnrOf"{/if}><i class="6GTlsiFWNbVn"></i><span>{lang remind}</span><!--{if $_G[member][newprompt]}--><em>$_G[member][newprompt]</em><!--{/if}--></a></li>
		<li><a href="home.php?mod=space&do=profile&mycenter=1"><i class="0JPzjWfQFXGR"></i><span>{lang myitem}</span></a></li>
		<li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="F3pveqiOE331" onclick="$('body').removeClass('mm-opening');$('.mm-mask').hide();"><i class="9UKRwJk1d3f8"></i><span>{lang logout}</span></a></li>
	</ul>
</div>
<!--{elseif $_G['connectguest']}-->
<div class="sidequickmenu{if $searchmode} bbno{/if}">
	<ul>
		<!--{if $_G['connectguest']}-->
		<li><a href="member.php?mod=connect&mobile=no" ><i class="cvRu1yYRBCjc"></i><span>{$langplus[perfectact]}</span></a></li>
		<li><a href="member.php?mod=connect&ac=bind&mobile=no" ><i class="S6LtBZ87WjAN"></i><span>{$langplus[bindingact]}</span></a></li>
		<!--{/if}-->
		<li><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="F3pveqiOE331" onclick="$('body').removeClass('mm-opening');$('.mm-mask').hide();"><i class="9UKRwJk1d3f8"></i><span>{lang logout}</span></a></li>
	</ul>
</div>
<!--{/if}-->
<!--{if $searchmode}-->
<div class="sidesearch{if !$_G[uid] && !$_G['connectguest']} mts{/if}">
<form id="mod_thread" method="post" action="search.php?searchsubmit=yes" accept-charset="utf-8">
<input type="hidden" id="mod_thread" name="mod" value="{if $searchmode == 1}forum{elseif $searchmode == 2}portal{elseif $searchmode == 3}group{elseif $searchmode == 4}blog{elseif $searchmode == 5}album{/if}" checked="checked" />
<input type="hidden" value="yes" name="searchsubmit">
<input type="text" name="srchtxt" id="scbar_txt" value="" autocomplete="off" />
<button type="submit" name="searchsubmit" id="scbar_btn" value="true" ></button>
</form>
</div>
<!--{/if}-->
<div class="32TlkxUN1LYF"><ul><!--{hook/global_sidemenus_v2_mobile}--></ul></div>
</div>
</nav>

<div class="MCE8V0sYQIg9"></div>

<script type="text/javascript">
	$(document).ready(function(){
		$('body').prepend($('.mm-menu'));
		$('.mm-menu, .mm-mask').height($(window).height() + 100);
		$('.mm-openmenu').click(function(){$('body').addClass('mm-opening');$('.mm-mask').delay(300).fadeIn();});
		$('.mm-mask').click(function(){$('body').removeClass('mm-opening');$(this).hide();});
		<!--{if $viewheight}-->
		$(function(){if($('.viewheight').height()>{$viewheight}){$('.viewheight').addClass('hideview');$('.startreading').show();}});
		$('.startreading > a').click(function(){$('.viewheight').removeClass('hideview');$('.startreading').hide();});
		<!--{/if}-->
		<!--{if $sortmenufloat}-->
		$(window).scroll(function(){var coverheight = $('.sortrollheight').height() + 50; if($(window).scrollTop() > coverheight){$('.sortmenus').addClass('{if $headershow}sortmenu_float{else}sortmenu_top{/if}');}else{$('.sortmenus').removeClass('{if $headershow}sortmenu_float{else}sortmenu_top{/if}');}});
		<!--{/if}-->
	});
	<!--{if ($closenav == 1 && (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false)) && $headershow }-->
	$(document).ready(function(){var p=0,t=0;$(window).scroll(function(e){if($(window).scrollTop()>300){p=$(this).scrollTop();if(t<=p){$('.header{if $sortmenufloat}, .sortmenus{/if}').addClass('close_h')}else{$('.header{if $sortmenufloat}, .sortmenus{/if}').removeClass('close_h')}}t=p});});
	<!--{/if}-->
	$(document).ready(function(){var p=0,t=0;$(window).scroll(function(e){if($(window).scrollTop()>80){p=$(this).scrollTop();if(t<=p){setTimeout(function(){$('.scroll_plus{if !$headershow}, .scroll_openmenu{/if}').addClass('scroll_hide')},300)}else{setTimeout(function(){$('.scroll_plus{if !$headershow}, .scroll_openmenu{/if}').removeClass('scroll_hide')},300)}}t=p})});
</script>
<!--{if ($_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck) && $sounds }-->
<audio src="template/v2_mbl20121009/touch_plus/sound/00_{$sounds}.mp3" autoplay="autoplay"><source src="template/v2_mbl20121009/touch_plus/sound/00_{$sounds}.mp3" type="audio/ogg"><source src="template/v2_mbl20121009/touch_plus/sound/00_{$sounds}.mp3" type="audio/mpeg"></audio>
<!--{/if}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{eval require_once(DISCUZ_ROOT.'./source/plugin/v2_wap_03/corefile/restore.core.php');}-->
<!--{$tplstat}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->