<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="tip report_box">
    <form method="post" autocomplete="off" id="form_$_GET[handlekey]" name="form_$_GET[handlekey]" action="misc.php?mod=report" >
        <div class="report_option bb">
            <p class="mbn">{lang report_reason}</p>
            <div id="report_reasons"></div>
            <div class="report_txt" style="display:none;">
            <textarea id="report_message" name="message" rows="3" placeholder="{lang report_reason_other}">{lang report_reason_other}</textarea>
            </div>
        </div>
        <div class="hm"><button id="report_submit" type="submit" value="true" class="formdialog button2">{lang confirms}</button></div>
        <input type="hidden" name="referer" value="{echo dreferer()}" />
        <input type="hidden" name="reportsubmit" value="true" />
        <input type="hidden" name="rtype" value="$_GET[rtype]" />
        <input type="hidden" name="rid" value="$_GET[rid]" />
        <!--{if $_GET['fid']}-->
        <input type="hidden" name="fid" value="$_GET[fid]" />
        <!--{/if}-->
        <!--{if $_GET['uid']}-->
        <input type="hidden" name="uid" value="$_GET[uid]" />
        <!--{/if}-->
        <input type="hidden" name="url" value="$_GET[url]" />
        <input type="hidden" name="inajax" value="$_G[inajax]" />
        <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
        <input type="hidden" name="formhash" value="{FORMHASH}" />
    </form>
	<script type="text/javascript" reload="1">
    var reasons = {lang report_reason_message};
    var reasonstring = '';
    for (i=0; i<reasons.length; i++) {
        reasonstring += '<span><label><input type="radio" name="report_select" onclick="if(this.checked) {$(\'.report_txt\').' + (i < reasons.length -1 ? 'hide' : 'show') + '();$(\'#report_message\').val(' + (i < reasons.length -1 ? '$(this).val()' : '\'\'') + ');}" value="' + reasons[i] + '"> ' + reasons[i] + '</label></span>';
    }
    $('#report_reasons').html(reasonstring);
    </script>
</div>
<!--{template common/footer}-->