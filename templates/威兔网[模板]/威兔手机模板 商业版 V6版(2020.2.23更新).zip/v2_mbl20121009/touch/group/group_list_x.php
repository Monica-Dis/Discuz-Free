<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['forum_threadcount']}-->
<ul id="alist" class="HwKFWtPXAVEl">
    <!--{eval $ad = 1;}-->
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
    {eval continue;}
    <!--{/if}-->
    <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
    {eval $displayorder_thread = 1;}
    <!--{/if}-->
    <!--{if $thread['moved']}-->
    <!--{eval $thread[tid]=$thread[closed];}-->
    <!--{/if}-->
    <!--{hook/forumdisplay_middle_v2_mobile}-->
    <!--{if $page == 1}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adgrouplista && in_array($_G['fid'],explode(",",$adgrouplistida)) && $ad == $adgrouplisttha}--><!--{$adgrouplista}--><!--{/if}-->
    <!--{if $adgrouplistb && in_array($_G['fid'],explode(",",$adgrouplistidb)) && $ad == $adgrouplistthb}--><!--{$adgrouplistb}--><!--{/if}-->
    <!--{if $adgrouplistc && in_array($_G['fid'],explode(",",$adgrouplistidc)) && $ad == $adgrouplistthc}--><!--{$adgrouplistc}--><!--{/if}-->
    <!--{if $adgrouplistd && in_array($_G['fid'],explode(",",$adgrouplistidd)) && $ad == $adgrouplistthd}--><!--{$adgrouplistd}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <li class="0SjyuQop6KJp">
        <!--{if $closeplugin == 0}--><!--{hook/forumdisplay_thread_mobile $key}--><!--{/if}-->
        <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="th_item{if $thread[folder] == 'new'} foldernew{/if}">
            <h1>
                <!--{if $thread[folder] == 'lock'}-->
                <em>{lang close}</em> &middot;
                <!--{elseif $thread['special'] == 1}-->
                <em>{lang thread_poll}</em> &middot;
                <!--{elseif $thread['special'] == 2}-->
                <em>{lang thread_trade}</em> &middot;
                <!--{elseif $thread['special'] == 3}-->
                <em>{lang thread_reward}</em> &middot;
                <!--{elseif $thread['special'] == 4}-->
                <em>{lang thread_activity}</em> &middot;
                <!--{elseif $thread['special'] == 5}-->
                <em>{lang thread_debate}</em> &middot;
                <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;
                <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                <em class="0rM8odj7aKyi">$langplus[pic]</em> &middot;
                <!--{/if}-->
                <!--{if $thread['digest'] > 0}-->
                <em class="GR92yicG3zyZ">$langplus[digest]</em> &middot;
                <!--{/if}-->
                <!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}-->
                <!--{if $thread['rushreply']}-->
                <span class="DDhgGdFCeBwj"> - {lang rushreply}{if $rushinfo[$thread[tid]] == ''}{lang over}{/if}</span>
                <!--{/if}-->
                <!--{if $thread['price'] > 0}-->
                <span class="DDhgGdFCeBwj"> -
                    <!--{if $thread['special'] == '3'}-->
                    {lang thread_reward} $thread[price] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}
                    <!--{else}-->
                    {lang price} $thread[price] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}
                    <!--{/if}-->
                    </span>
                <!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
                <span class="DDhgGdFCeBwj"> - {lang reward_solved}</span>
                <!--{/if}-->
                <!--{if $thread['replycredit'] > 0}-->
                <span class="DDhgGdFCeBwj"> - {lang replycredit}</span>
                <!--{/if}-->
            </h1>
            <div class="hNOK3poJcpFf">
                <!--{if $thread['authorid'] && $thread['author']}--><span>$thread[author]</span><!--{else}--><span>$_G[setting][anonymoustext]</span><!--{/if}-->
                <span>{$thread[dateline]}</span>
                <!--{if $_G['forum']['threadtypes']['types'][$thread['typeid']] && $_G['forum']['threadtypes']['prefix'] > 0}-->
                <span class="WAO1ETmvH49Y">#{echo strip_tags($_G['forum']['threadtypes']['types'][$thread['typeid']])}</span>
                <!--{/if}-->
                <!--{if $thread[icon] >= 0}-->
                <span class="ZUp4byFwR1BK">#{$_G[cache][stamps][$thread[icon]][text]}</span>
                <!--{else}-->
                <!--{if $thread[heatlevel]}-->
                <span class="Z1K9j6zHkkNq">#{$langplus[orderheats]}</span>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $thread[allreplies]}-->
                <!--{if $thread[allreplies] > 9999 }-->
                <!--{eval $thread[allreplies] = round($thread[allreplies] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $thread[views] > 9999 }-->
                <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{/if}-->
                <span class="99u2LxYcMOhO"><!--{if $thread[allreplies]}-->{$thread[allreplies]}{lang join_thread}<!--{else}-->{$thread[views]}{$langplus[view]}<!--{/if}--></span>
            </div>
        </a>
    </li>
    <!--{eval $ad++;}-->
    <!--{/loop}-->
</ul>
<!--{else}-->
<div class="sqK9gG26iUGb">{lang forum_nothreads}</div>
<!--{/if}-->