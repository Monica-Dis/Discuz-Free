<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $action != 'create'}-->
    <!--{if $status != 2 && $status != 3}-->
    <div class="NkGgJbO2CQdl">
        <ul>
            <li {if $action == 'list'}class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang group_discuss_area}</a></li>
            <li {if $action == 'memberlist' || $action == 'invite'}class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]">{lang group_member_list}</a></li>
            <!--{if $_G['forum']['ismoderator']}--><li {if $action == 'manage'}class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang group_admin}</a></li><!--{/if}-->
        </ul>
    </div>
    <!--{/if}-->
<!--{/if}-->

<!--{if $op == 'alluser'}-->
<div class="drCszIQLosK9">
    <!--{if $adminuserlist}-->
    <h2>{lang group_admin_member}</h2>
    <ul>
        <!--{loop $adminuserlist $user}-->
        <li>
            <a href="home.php?mod=space&uid=$user[uid]&do=profile">
                <img src="{avatar($user[uid],middle,true)}" class="UoRZiAghxSa8" />
                <!--{if $user['online']}--><i class="ZQJHMMQwP4Pe"></i><!--{/if}-->
                <div class="dqUtHLuoIPwV">$user[username]<!--{if $user['level'] == 1}--><em class="2vu5KZqKJIep"></em><!--{elseif $user['level'] == 2}--><em class="32PLJqRGoRH3"></em><!--{/if}--></div>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
    <!--{/if}-->
    <!--{if $staruserlist || $alluserlist}-->
    <h2>{$langplus[groups]}{lang member}</h2>
    <ul id="alist" class="HwKFWtPXAVEl">
        <!--{if $staruserlist}-->
        <!--{loop $staruserlist $user}-->
        <li>
            <a href="home.php?mod=space&uid=$user[uid]&do=profile">
                <img src="{avatar($user[uid],middle,true)}" class="UoRZiAghxSa8" />
                <!--{if $user['online']}--><i class="ZQJHMMQwP4Pe"></i><!--{/if}-->
                <div class="FJiMY75Awt0t">$user[username]<em class="c5EN89KcWrl0"></em></div>
                <p class="EBFaHCDQKCIh"><i class="FyIaCLvsDP3t"></i> {echo dgmdate($user['joindateline'], 'u')}</p>
            </a>
        </li>
        <!--{/loop}-->
        <!--{/if}-->
        <!--{if $alluserlist}-->
        <!--{loop $alluserlist $user}-->
        <li>
            <a href="home.php?mod=space&uid=$user[uid]&do=profile">
                <img src="{avatar($user[uid],middle,true)}" class="UoRZiAghxSa8" />
                <!--{if $user['online']}--><i class="ZQJHMMQwP4Pe"></i><!--{/if}-->
                <div class="FJiMY75Awt0t">$user[username]</div>
                <p class="EBFaHCDQKCIh"><i class="FyIaCLvsDP3t"></i> {echo dgmdate($user['joindateline'], 'u')}</p>
            </a>
        </li>
        <!--{/loop}-->
        <!--{/if}-->
    </ul>
    <!--{/if}-->
    </div>

<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($_G['forum']['membernum'] / $perpage);}-->
<!--{if $totalpage > $page}-->
<a href="forum.php?mod=group&action=memberlist&op=alluser&fid={$_G['fid']}" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->

<!--{block bottombutton}-->
<ul>
    <!--{if $tplwapurl}-->
    <li><a href="forum.php"><i class="vYwrd8Li1T3q"></i>$langplus[home]</a></li>
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{else}-->
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{$footertwo}-->
    <!--{/if}-->
    <li><div class="lkzxUSeCuNPo"><a {if $_G[uid]}href="forum.php?mod=post&action=newthread&fid=$_G[fid]"{else}href="javascript:;" onclick="popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');" {/if} class="i0a6HFurbhHA"><i class="RtBILaDhl45b"></i></a></div></li>
    <!--{if !$tplwapurl && $footernavtw == 3}--><!--{$footerfour}--><!--{else}--><li class="Yfm1QC5IeoTk"><a href="group.php"><i class="YnfUIGTrsvCI"></i>{$langplus[groups]}</a></li><!--{/if}-->
    <li>
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
        <a href="member.php?mod=logging&action=login"><i class="0iHKtK6RqXLZ"></i>{lang login}</a>
        <!--{else}-->
        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="0iHKtK6RqXLZ"></i>$langplus[me]</a>
        <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="Iug1I7rXnrOf"></i><!--{/if}-->
        <!--{/if}-->
    </li>
</ul>
<!--{/block}-->