<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $sortmenufloat}--><div class="AtXpQP883jim"><!--{/if}-->
<div class="slidemenu{if $sortmenufloat} sortmenus{/if}">
    <div class="jqRecDJMSqQs">
        <ul class="qhUm3fRMfQIL">
            <li class="menu_slide{if !$_GET['typeid']} a{/if}"><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang forum_viewall}</a></li>
            <!--{if $_G['forum']['threadtypes']}-->
            <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
            <li class="menu_slide{if $_GET['typeid'] == $id} a{/if}"><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}">$name</a>
            <!--{/loop}-->
            <!--{else}-->
            <li class="wW0qVBCG1RrL"><a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]">{lang group_member_list}</a></li>
            <!--{/if}-->
        </ul>
    </div>
</div>
<!--{if $sortmenufloat}--></div><!--{/if}-->
<!--{if $_G['forum']['threadtypes']}-->
<script src="./template/v2_mbl20121009/touch_plus/js/swiper.min.js?{VERHASH}"></script>
<script type="text/javascript">
    $(function() {
        if ($('.slidemenu .a').length > 0) {
            var slidefocus = $('.slidemenu .a').offset().left + $('.slidemenu .a').width() >= $(window).width() ? $('.slidemenu .a').index() : 0;
        } else {
            var slidefocus = 0;
        }
        var swiper = new Swiper('.menu_container', {
            wrapperClass:'menu_wrapper',
            slideClass:'menu_slide',
            slidesPerView:'auto',
            freeMode:true,
            freeModeFluid:true,
            momentumBounce:true,
            initialSlide:slidefocus,
        });
    })
</script>
<!--{/if}-->

<!--{if $_G[forum][banner] && $_G['forum']['description']}-->
<div class="dNBYAYeEYdr9">
    <div class="iXGbfgfGkWHt"><span class="MzXGZuYzqGml"></span></div>
    <div class="LGT00n5naKel">
        <div class="u9WL0f7h33Y9">
            <a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]" class="24LCOR0eEUqW">
                <!--{if strstr($_G['forum'][icon],'groupicon.gif')}-->
                <img src="template/v2_mbl20121009/touch_plus/image/groupicon.png" />
                <!--{else}-->
                <img src="$_G[forum][icon]" />
                <!--{/if}-->
            </a>
            <h1><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">{$_G['forum']['name']}</a></h1>
            <p>$_G['forum']['description']</p>
        </div>
    </div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        $('.forumname_dp').click(function(){
            $('.descriptionfly').addClass('infly');
            $('body').addClass('menufly_open');
        });
        $('.vt-close').click(function(){
            $('.descriptionfly').removeClass('infly');
            $('body').removeClass('menufly_open');
        });
    });
</script>
<!--{/if}-->
<!--{if $tplpages == 1 && $page > 1}-->
<!--{eval $listallpage = ceil($_G['forum_threadcount'] / $_G['tpp']);}-->
<div class="5As7XAi28n3n">
<!--{if $page >= $listallpage}-->
<a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="evXx4HZDPWdN">{$langplus[gobackpage]}</a>
<!--{else}-->
<a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="evXx4HZDPWdN">{$langplus[goonpage]}</a>
<!--{/if}-->
</div>
<!--{/if}-->
<!--{if in_array($_G[fid],explode(",",$groupthtypea))}-->
<!--{template group/group_list_a}-->
<!--{elseif in_array($_G[fid],explode(",",$groupthtypeb))}-->
<!--{template group/group_list_b}-->
<!--{elseif in_array($_G[fid],explode(",",$groupthtypec))}-->
<!--{template group/group_list_c}-->
<!--{elseif in_array($_G[fid],explode(",",$groupthtyped))}-->
<!--{template group/group_list_d}-->
<!--{elseif in_array($_G[fid],explode(",",$groupthtypee))}-->
<!--{template group/group_list_e}-->
<!--{elseif in_array($_G[fid],explode(",",$groupthtypef))}-->
<!--{template group/group_list_f}-->
<!--{else}-->
<!--{if $groupthtype == 1}-->
<!--{template group/group_list_a}-->
<!--{elseif $groupthtype == 2}-->
<!--{template group/group_list_b}-->
<!--{elseif $groupthtype == 3}-->
<!--{template group/group_list_c}-->
<!--{elseif $groupthtype == 4}-->
<!--{template group/group_list_d}-->
<!--{elseif $groupthtype == 5}-->
<!--{template group/group_list_e}-->
<!--{elseif $groupthtype == 6}-->
<!--{template group/group_list_f}-->
<!--{else}-->
<!--{template group/group_list_x}-->
<!--{/if}-->
<!--{/if}-->

<!--{if helper_access::check_module('group')}-->
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($_G['forum_threadcount'] / $_G['tpp']);}-->
<!--{if $totalpage > $page}-->
<a href="$multipage_more" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{/if}-->

<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1">
    <!--{eval $favstate = C::t('home_favorite')->fetch_by_id_idtype($_G['fid'],'gid',$_G['uid']);}-->
    <!--{if $favstate && $_G['uid']}-->
    <a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="GVCQ6391pe2J"><i class="c5jXKWHqTOsX"></i></a>
    <!--{else}-->
    <a href="home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}" class="tGT2vF1AFZp3"><i class="a4TcRfVF4aiG"></i></a>
    <!--{/if}-->
    <!--{if $_G['forum']['ismoderator']}--><a href="forum.php?mod=group&action=manage&fid=$_G[fid]" class="EPSs1wRRyPfK"></a><!--{/if}-->
</div>
<!--{$ajaxsubmit_item}-->
<!--{/block}-->

<!--{block bottombutton}-->
<ul>
    <!--{if $tplwapurl}-->
    <li><a href="forum.php"><i class="vYwrd8Li1T3q"></i>$langplus[home]</a></li>
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{else}-->
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{$footertwo}-->
    <!--{/if}-->
    <li><div class="lkzxUSeCuNPo"><a {if $_G[uid]}href="forum.php?mod=post&action=newthread&fid=$_G[fid]"{else}href="javascript:;" onclick="popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');" {/if} class="i0a6HFurbhHA"><i class="RtBILaDhl45b"></i></a></div></li>
    <!--{if !$tplwapurl && $footernavtw == 3}--><!--{$footerfour}--><!--{else}--><li class="Yfm1QC5IeoTk"><a href="group.php"><i class="YnfUIGTrsvCI"></i>{$langplus[groups]}</a></li><!--{/if}-->
    <li>
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
        <a href="member.php?mod=logging&action=login"><i class="0iHKtK6RqXLZ"></i>{lang login}</a>
        <!--{else}-->
        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="0iHKtK6RqXLZ"></i>$langplus[me]</a>
        <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="Iug1I7rXnrOf"></i><!--{/if}-->
        <!--{/if}-->
    </li>
</ul>
<!--{/block}-->