<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="group.php"><!--{if $_G[setting][navs][3][navname]}-->$_G[setting][navs][3][navname]<!--{else}-->&#x5708;&#x5B50;<!--{/if}--></a><!--{/block}-->
<!--{template common/header}-->
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$adgroupindex}--><!--{/if}-->
<!--{if $grouptpl != 1}-->
<div class="sDbjLbrOH5EU">
    <ul>
        <li class="pgpXPk0mZTXh"><a href="javascript:;">{lang recommend_group}</a></li>
        <li class="jagMQGVAPKDO"><a href="javascript:;">{lang all}{$langplus[groups]}</a></li>
        <li><a href="group.php?mod=my">{lang my_group}</a></li>
    </ul>
</div>
<script type="text/javascript">
    $('.tabequal li.group_tab').click(function(){
        $('.tabequal li').eq($(this).index()).addClass('a').siblings().removeClass('a');
        $('.hidebox').eq($(".tabequal li.group_tab").index(this)).show().siblings().hide();
    });
</script>
<!--{/if}-->
<!--{if $grouptpl == 1}-->
<!--{if $noheader || !$headershow || $nofooter || !$footershow}-->
<style type="text/css">.forum_left, .forum_right {<!--{if $noheader || !$headershow}--> top: 0px;<!--{/if}--><!--{if $nofooter || !$footershow}--> bottom: 0px;<!--{/if}--> }</style>
<!--{/if}-->
<div class="C37wrkRGIt2N">
    <ul>
        <li class="Buz5v5UOqxi7">{lang recommend_group}</li>
        <!--{if $_G[uid]}-->
        <li class="hPYP3VWaFHvv"><a href="group.php?mod=my">{lang my_group}</a></li>
        <!--{/if}-->
        <!--{eval $i = 1;}-->
        <!--{loop $first $groupid $group}-->
        <!--{if $group[groupnum] > 0}-->
        <li class="jagMQGVAPKDO">$group[name]</li>
        <!--{/if}-->
        <!--{eval $i++;}-->
        <!--{/loop}-->
    </ul>
</div>
<div class="9rz3f9gf6SIc">
    <div class="goHPMAw4lYcx">
        <ul class="dQgvs7znuwpf">
            <!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->
            <!--{eval $val[membernum] = DB::result_first('SELECT membernum FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[founderuid] = DB::result_first('SELECT founderuid FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[threads] = DB::result_first('SELECT threads FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid]);}-->
            <!--{eval $val[todayposts] = DB::result_first('SELECT todayposts FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[join] = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $val['fid']);}-->
            <li class="wH3cPtGthBRK">
                <a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="BlyDcG5YQDZr"><img src="{if strstr($val[icon],'groupicon.gif')}template/v2_mbl20121009/touch_plus/image/groupicon.png{else}{$val[icon]}{/if}" alt="$val[name]" />
                <h1>$val[name]<!--{if $val[todayposts] > 0}--><i title="{$val[todayposts]}">new</i><!--{/if}--></h1>
                <!--{if $val[description]}-->
                <p>$val[description]</p>
                <!--{else}-->
                <!--{if $val[membernum] > 9999 }-->
                <!--{eval $val[membernum] = round($val[membernum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $val[threads] > 9999 }-->
                <!--{eval $val[threads] = round($val[threads] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <p class="bIsURUTNrYLZ">{lang member} {$val[membernum]} &nbsp; {lang threads} {$val[threads]}</p>
                <!--{/if}-->
                </a>
                <!--{if ($val[founderuid] == $_G['uid']) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=manage&fid=$val[fid]" class="1wd0D5ofiP74">{lang manage}</a>
                <!--{elseif (helper_access::check_module('group') && $val[join]) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=out&fid=$val[fid]" class="5sltCVywm0aL">{lang logout}</a>
                <!--{else}-->
                <a href="forum.php?mod=group&action=join&fid=$val[fid]" class="VwB5Mri1QvZQ">{$langplus[join]}</a>
                <!--{/if}-->
            </li>
            <!--{/loop}-->
        </ul>
    </div>
    <!--{loop $first $groupid $group}-->
    <!--{if $group[groupnum] > 0}-->
    <div class="wmKF7kakJIRp">
        <ul class="dQgvs7znuwpf">
            <!--{if $lastupdategroup[$groupid]}-->
            <!--{loop $lastupdategroup[$groupid] $val}-->
            <!--{eval $val[icon] = DB::result_first('SELECT icon FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[description] = DB::result_first('SELECT description FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[membernum] = DB::result_first('SELECT membernum FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[founderuid] = DB::result_first('SELECT founderuid FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[threads] = DB::result_first('SELECT threads FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid]);}-->
            <!--{eval $val[todayposts] = DB::result_first('SELECT todayposts FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[join] = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $val['fid']);}-->
            <li class="wH3cPtGthBRK">
                <a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="BlyDcG5YQDZr">
                <!--{if $val[icon]}-->
                <img src="{$_G['setting']['attachurl']}/group/{$val[icon]}" />
                <!--{else}-->
                <img src="template/v2_mbl20121009/touch_plus/image/groupicon.png" />
                <!--{/if}-->
                <h1>$val[name]<!--{if $val[todayposts] > 0}--><i title="{$val[todayposts]}">new</i><!--{/if}--></h1>
                <!--{if $val[description]}-->
                <p>$val[description]</p>
                <!--{else}-->
                <!--{if $val[membernum] > 9999 }-->
                <!--{eval $val[membernum] = round($val[membernum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $val[threads] > 9999 }-->
                <!--{eval $val[threads] = round($val[threads] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <p class="bIsURUTNrYLZ">{lang member} {$val[membernum]} &nbsp; {lang threads} {$val[threads]}</p>
                <!--{/if}-->
                </a>
                <!--{if ($val[founderuid] == $_G['uid']) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=manage&fid=$val[fid]" class="1wd0D5ofiP74">{lang manage}</a>
                <!--{elseif (helper_access::check_module('group') && $val[join]) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=out&fid=$val[fid]" class="5sltCVywm0aL">{lang logout}</a>
                <!--{else}-->
                <a href="forum.php?mod=group&action=join&fid=$val[fid]" class="VwB5Mri1QvZQ">{$langplus[join]}</a>
                <!--{/if}-->
            </li>
            <!--{/loop}-->
            <!--{/if}-->
        </ul>
    </div>
    <!--{/if}-->
    <!--{/loop}-->
</div>
<script type="text/javascript">
    $(document).ready(function(){
        $('.forum_left li.group_tab').click(function(){
            $('.forum_left li').eq($(this).index()).addClass('on').siblings().removeClass('on');
            $('.hidebox').eq($('.forum_left li.group_tab').index(this)).addClass('on').siblings().removeClass('on');
        });
    })
</script>
<!--{elseif $grouptpl == 2}-->
<div class="50n9sB7ocV8a">
    <div class="22QH8w7MKUZo" style="display: block;">
        <ul class="dQgvs7znuwpf">
            <!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->
            <!--{eval $val[membernum] = DB::result_first('SELECT membernum FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[founderuid] = DB::result_first('SELECT founderuid FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[threads] = DB::result_first('SELECT threads FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid]);}-->
            <!--{eval $val[todayposts] = DB::result_first('SELECT todayposts FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[join] = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $val['fid']);}-->
            <li class="wH3cPtGthBRK">
                <a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="BlyDcG5YQDZr"><img src="{if strstr($val[icon],'groupicon.gif')}template/v2_mbl20121009/touch_plus/image/groupicon.png{else}{$val[icon]}{/if}" alt="$val[name]" />
                <h1>$val[name]<!--{if $val[todayposts] > 0}--><i title="{$val[todayposts]}">new</i><!--{/if}--></h1>
                <!--{if $val[description]}-->
                <p>$val[description]</p>
                <!--{else}-->
                <!--{if $val[membernum] > 9999 }-->
                <!--{eval $val[membernum] = round($val[membernum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $val[threads] > 9999 }-->
                <!--{eval $val[threads] = round($val[threads] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <p>{lang member} {$val[membernum]} &nbsp; {lang threads} {$val[threads]}</p>
                <!--{/if}-->
                </a>
                <!--{if ($val[founderuid] == $_G['uid']) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=manage&fid=$val[fid]" class="1wd0D5ofiP74">{lang manage}</a>
                <!--{elseif (helper_access::check_module('group') && $val[join]) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=out&fid=$val[fid]" class="5sltCVywm0aL">{lang logout}</a>
                <!--{else}-->
                <a href="forum.php?mod=group&action=join&fid=$val[fid]" class="VwB5Mri1QvZQ">{$langplus[join]}</a>
                <!--{/if}-->
            </li>
            <!--{/loop}-->
        </ul>
    </div>
    <div class="22QH8w7MKUZo">
        <!--{loop $first $groupid $group}-->
        <!--{if $group[groupnum] > 0}-->
        <div class="k9Kds1QTVh2a">
            <div class="OsFv1OpGjMGc">
                <h2><span><a href="group.php?gid=$groupid">$group[name]</a></span><!--{if $group[groupnum] > 6}--><a href="group.php?gid=$groupid" class="99u2LxYcMOhO">{lang more}</a><!--{/if}--></h2>
            </div>
            <ul class="WefwVTOJUU71">
                <!--{if $lastupdategroup[$groupid]}-->
                <!--{eval $i = 1;}-->
                <!--{loop $lastupdategroup[$groupid] $val}-->
                <!--{eval $val[icon] = DB::result_first('SELECT icon FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
                <!--{eval $val[description] = DB::result_first('SELECT description FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
                <!--{eval $val[membernum] = DB::result_first('SELECT membernum FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
                <!--{eval $val[threads] = DB::result_first('SELECT threads FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid]);}-->
                <!--{eval $val[todayposts] = DB::result_first('SELECT todayposts FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid])}-->
                <!--{eval $val[join] = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $val['fid']);}-->
                <!--{if $i < 7}-->
                <li class="wH3cPtGthBRK">
                    <a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]">
                    <!--{if $val[icon]}-->
                    <img src="{$_G['setting']['attachurl']}/group/{$val[icon]}" />
                    <!--{else}-->
                    <img src="template/v2_mbl20121009/touch_plus/image/groupicon.png" />
                    <!--{/if}-->
                    <h1>$val[name]<!--{if $val[todayposts] > 0}--><i title="{$val[todayposts]}">new</i><!--{/if}--></h1>
                    <!--{if $val[description]}-->
                    <p>$val[description]</p>
                    <!--{else}-->
                    <!--{if $val[membernum] > 9999 }-->
                    <!--{eval $val[membernum] = round($val[membernum] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $val[threads] > 9999 }-->
                    <!--{eval $val[threads] = round($val[threads] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <p>{lang member} {$val[membernum]} &nbsp; {lang threads} {$val[threads]}</p>
                    <!--{/if}-->
                    </a>
                </li>
                <!--{/if}-->
                <!--{eval $i++;}-->
                <!--{/loop}-->
                <!--{/if}-->
            </ul>
        </div>
        <!--{hook/index_bottom_v2_mobile}-->
        <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
        <!--{if $adgroupsa && in_array($groupid,explode(",",$adgroupsida))}--><!--{$adgroupsa}--><!--{/if}-->
        <!--{if $adgroupsb && in_array($groupid,explode(",",$adgroupsidb))}--><!--{$adgroupsb}--><!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
        <!--{/loop}-->
    </div>
</div>
<!--{else}-->
<div class="50n9sB7ocV8a">
    <div class="22QH8w7MKUZo" style="display: block;">
        <ul class="dQgvs7znuwpf">
            <!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->
            <!--{eval $val[membernum] = DB::result_first('SELECT membernum FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[founderuid] = DB::result_first('SELECT founderuid FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[threads] = DB::result_first('SELECT threads FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid]);}-->
            <!--{eval $val[todayposts] = DB::result_first('SELECT todayposts FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid])}-->
            <!--{eval $val[join] = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $val['fid']);}-->
            <li class="wH3cPtGthBRK">
                <a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="BlyDcG5YQDZr"><img src="{if strstr($val[icon],'groupicon.gif')}template/v2_mbl20121009/touch_plus/image/groupicon.png{else}{$val[icon]}{/if}" alt="$val[name]" />
                <h1>$val[name]<!--{if $val[todayposts] > 0}--><i title="{$val[todayposts]}">new</i><!--{/if}--></h1>
                <!--{if $val[description]}-->
                <p>$val[description]</p>
                <!--{else}-->
                <!--{if $val[membernum] > 9999 }-->
                <!--{eval $val[membernum] = round($val[membernum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $val[threads] > 9999 }-->
                <!--{eval $val[threads] = round($val[threads] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <p>{lang member} {$val[membernum]} &nbsp; {lang threads} {$val[threads]}</p>
                <!--{/if}-->
                </a>
                <!--{if ($val[founderuid] == $_G['uid']) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=manage&fid=$val[fid]" class="1wd0D5ofiP74">{lang manage}</a>
                <!--{elseif (helper_access::check_module('group') && $val[join]) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=out&fid=$val[fid]" class="5sltCVywm0aL">{lang logout}</a>
                <!--{else}-->
                <a href="forum.php?mod=group&action=join&fid=$val[fid]" class="VwB5Mri1QvZQ">{$langplus[join]}</a>
                <!--{/if}-->
            </li>
            <!--{/loop}-->
        </ul>
    </div>
    <div class="22QH8w7MKUZo">
        <!--{loop $first $groupid $group}-->
        <!--{if $group[groupnum] > 0}-->
        <div class="k9Kds1QTVh2a">
            <div class="OsFv1OpGjMGc">
                <h2><span><a href="group.php?gid=$groupid">$group[name]</a></span><!--{if $group[groupnum] > 12}--><a href="group.php?gid=$groupid" class="99u2LxYcMOhO">{lang more}</a><!--{/if}--></h2>
            </div>
            <ul class="4lpnxBAktcZs">
                <!--{if $lastupdategroup[$groupid]}-->
                <!--{eval $i = 1;}-->
                <!--{loop $lastupdategroup[$groupid] $val}-->
                <!--{eval $val[icon] = DB::result_first('SELECT icon FROM '.DB::table('forum_forumfield').' WHERE fid ='.$val[fid])}-->
                <!--{eval $val[todayposts] = DB::result_first('SELECT todayposts FROM '.DB::table('forum_forum').' WHERE fid ='.$val[fid])}-->
                <!--{if $i < 13}-->
                <li class="dSLKIlsbZ4k4">
                    <a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]">
                        <!--{if $val[icon]}-->
                        <img src="{$_G['setting']['attachurl']}/group/{$val[icon]}" />
                        <!--{else}-->
                        <img src="template/v2_mbl20121009/touch_plus/image/groupicon.png" />
                        <!--{/if}-->
                        <h1>$val[name]</h1>
                    </a>
                </li>
                <!--{/if}-->
                <!--{eval $i++;}-->
                <!--{/loop}-->
                <!--{/if}-->
            </ul>
        </div>
        <!--{hook/index_bottom_v2_mobile}-->
        <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
        <!--{if $adgroupsa && in_array($groupid,explode(",",$adgroupsida))}--><!--{$adgroupsa}--><!--{/if}-->
        <!--{if $adgroupsb && in_array($groupid,explode(",",$adgroupsidb))}--><!--{$adgroupsb}--><!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
        <!--{/loop}-->
    </div>
</div>
<!--{/if}-->

<script type="text/javascript">
    $(document).on('click','.ajaxgroups',function(){
        <!--{if !$_G[uid]}-->
        popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
        <!--{else}-->
        var obj = $(this);
        $.ajax({
            type:'POST',
            url:obj.attr('href') + '&handlekey=ajaxgroups&inajax=1',
            data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
            dataType:'xml',
        })
            .success(function(s) {
                var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
                var gfid = s.lastChild.firstChild.nodeValue.match(/&fid=(.+?)&/i)[1];
                var smgjoin = '{$langplus[joinsucceed]}';
                var smgexit = '{$langplus[exitsucceed]}';
                if(smg.indexOf(smgjoin) >= 0) {
                    obj.addClass('dialog_delfav').removeClass('sstbg').html('{lang logout}');
                    obj.attr('href', 'forum.php?mod=group&action=out&fid=' + gfid);
                }else if(smg.indexOf(smgexit) >= 0){
                    obj.removeClass('dialog_delfav').addClass('sstbg').html('{$langplus[join]}');
                    obj.attr('href', 'forum.php?mod=group&action=join&fid=' + gfid);
                }else{
                    popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg+'</dt></div>');
                    setTimeout(function(){
                        $(".dialogbox, #mask").fadeOut();
                    }, 1500);
                }
            })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
        <!--{/if}-->
        return false;
    });
</script>

<!--{block bottombutton}-->
<ul>
    <!--{if $tplwapurl}-->
    <li><a href="forum.php"><i class="vYwrd8Li1T3q"></i>$langplus[home]</a></li>
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{else}-->
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{$footertwo}-->
    <!--{/if}-->
    <li><div class="lkzxUSeCuNPo"><a {if $_G[uid]}href="forum.php?mod=group&action=create"{else}href="javascript:;" onclick="popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');" {/if} class="i0a6HFurbhHA"><i class="AG5yZ3ftzshu"></i></a></div></li>
    <!--{if !$tplwapurl && $footernavtw == 3}--><!--{$footerfour}--><!--{else}--><li class="Yfm1QC5IeoTk"><a href="group.php"><i class="YnfUIGTrsvCI"></i>{$langplus[groups]}</a></li><!--{/if}-->
    <li>
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
        <a href="member.php?mod=logging&action=login"><i class="0iHKtK6RqXLZ"></i>{lang login}</a>
        <!--{else}-->
        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="0iHKtK6RqXLZ"></i>$langplus[me]</a>
        <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="Iug1I7rXnrOf"></i><!--{/if}-->
        <!--{/if}-->
    </li>
</ul>
<!--{/block}-->
<!--{template common/footer}-->