<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['setting']['mobile']['mobiledisplayorder3'] && ($_G['forum_threadlist'][0][displayorder] > $threaddisplayorder)}-->
<div class="jdTRB0kx7bgU">
    <ul class="GD0fnfqbPrto">
        <!--{eval $reltop = 1;}-->
        <!--{loop $_G['forum_threadlist'] $key $thread}-->
        <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
        {eval continue;}
        <!--{/if}-->
        <!--{if $thread['displayorder'] > $threaddisplayorder}-->
        <!--{if $reltop == $displayordernum + 1}--><div class='pinmore'><span>{lang more}</span></div><!--{/if}-->
        <li{if $reltop > $displayordernum} class="TtOHNTUoZZvh"{/if}><i class="vt-top{if $thread['displayorder'] == 1} pin1{elseif $thread['displayorder'] == 2} pin2{/if}"></i>
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">{$thread[subject]}</a>
        </li>
        <!--{/if}-->
        <!--{eval $reltop++;}-->
        <!--{/loop}-->
    </ul>
</div>
<!--{if $_G['setting']['mobile']['mobiledisplayorder3']}-->
<script type="text/javascript">
    $(document).ready(function(){
        var openmore = 1;
        $(".pinmore").click(function() {
            if (openmore == 1) {
                $(this).before($(".hidethread"));
                $(".hidethread").show();
                $(this).html("<span>{$langplus[pack_up]}</span>").addClass("pinclose");
                openmore = 0
            } else {
                $(".hidethread").hide();
                $(this).html("<span>{lang more}</span>").removeClass("pinclose");
                openmore = 1
            }
        })
    });
</script>
<!--{/if}-->
<!--{/if}-->