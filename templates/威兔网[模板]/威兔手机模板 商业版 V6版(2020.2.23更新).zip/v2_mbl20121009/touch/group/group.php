<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->
<span class="kSkofAajeBpC"><!--{if $groupnav}-->{$_G['forum']['name']}<!--{elseif $action == 'create'}-->{lang group_create}<!--{/if}--></span>
<!--{/block}-->
<!--{template common/header}-->

<!--{if $action != 'create'}-->
<!--{if $_G['page'] == 1}-->
<!--{if $_G[forum][threads] > 9999 }-->
<!--{eval $_G[forum][threads] = round($_G[forum][threads] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->
<!--{if $_G[forum][membernum] > 9999 }-->
<!--{eval $_G[forum][membernum] = round($_G[forum][membernum] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->
<!--{if $_G['forum']['banner']}-->
<style type="text/css">header { height:auto; } .header { background:none; } .header span.forum_title { opacity:0; }</style>
<div class="forumname_licon{if $sortmenufloat} sortrollheight{/if}" style="background-image: url('{if $_G[forum][banner]}{$_G[forum][banner]}{else}template/v2_mbl20121009/touch_plus/img/forumicon/{$_G['forum']['fid']}.jpg{/if}');">
    <div class="TuVTp8hieQTX">
        <a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]" class="24LCOR0eEUqW">
            <!--{if strstr($_G['forum'][icon],'groupicon.gif')}-->
            <img src="template/v2_mbl20121009/touch_plus/image/groupicon.png" />
            <!--{else}-->
            <img src="$_G[forum][icon]" />
            <!--{/if}-->
        </a>
        <h1><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">{$_G['forum']['name']}</a></h1>
        <p class="forumname_dp{if !$_G['forum']['description']} mtn{/if}">
            <!--{if $_G['forum']['description']}-->
            $_G['forum']['description']
            <!--{else}-->
            <!--{if $_G['forum']['ismoderator']}-->
            <a href="forum.php?mod=group&action=manage&fid=$_G[fid]"><i class="OprBhaaPnDKC"></i> {$langplus[groupwriteitd]}</a>
            <!--{else}-->
            <i class="ScEc2VlOnnJi"></i> {$langplus[groupnoitd]}
            <!--{/if}-->
            <!--{/if}-->
        </p>
    </div>
    <div class="NrPfZTROTZBr">{lang threads}<span>$_G[forum][threads]</span><em>|</em><a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]">{lang member}<span>$_G[forum][membernum]</span></a></div>
    <!--{if $status != 2 && $status != 3 && $status != 5}-->
    <!--{if helper_access::check_module('group') && $status != 'isgroupuser'}-->
    <a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="gxrGD2JK4O8s">{$langplus[join]}</a>
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $action == 'index' && ($status == 2 || $status == 3 || $status == 5)}-->
    <!--{if $status == 3 || $status == 5}-->
    <!--{elseif helper_access::check_module('group')}-->
    <a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="gxrGD2JK4O8s">{$langplus[join]}</a>
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $status == 'isgroupuser'}-->
    <a href="forum.php?mod=group&action=out&fid=$_G[fid]&mobile=2" class="nkV9hgjv0FcG">{lang logout}</a>
    <!--{/if}-->
</div>
<!--{if $headershow}-->
<script type="text/javascript">
    $(window).scroll(function(){
        var hexvalue = '{$tplcolorcssa}';
        var rgx = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
        var hex = hexvalue.replace(rgx, (m, r, g, b) => r + r + g + g + b + b );
        var rgb = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
        var r = parseInt(rgb[1], 16);
        var g = parseInt(rgb[2], 16);
        var b = parseInt(rgb[3], 16);
        var a = $(window).scrollTop() / 150;
        if(a < '1'){
            $(".header").attr("style","background-color: rgba("+r+","+g+","+b+","+a+") !important;");
            $(".forum_title").attr("style","opacity:"+a+";");
        }else{
            $(".header").attr("style","background-color: rgba("+r+","+g+","+b+",1) !important;");
            $(".forum_title").attr("style","opacity:1;");
        }
    })
</script>
<!--{/if}-->
<!--{else}-->
<div class="forumname{if $sortmenufloat} sortrollheight{/if}">
    <a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}" class="24LCOR0eEUqW">
        <!--{if strstr($_G['forum'][icon],'groupicon.gif')}-->
        <img src="template/v2_mbl20121009/touch_plus/image/groupicon.png" />
        <!--{else}-->
        <img src="$_G[forum][icon]" />
        <!--{/if}-->
    </a>
    <h1><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">$_G['forum'][name]</a></h1>
    <p>{lang threads}<span>$_G[forum][threads]</span> &nbsp; <a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]">{lang member}<span>$_G[forum][membernum]</span></a></p>
    <!--{if $status != 2 && $status != 3 && $status != 5}-->
    <!--{if helper_access::check_module('group') && $status != 'isgroupuser'}-->
    <a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="gxrGD2JK4O8s">{$langplus[join]}</a>
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $action == 'index' && ($status == 2 || $status == 3 || $status == 5)}-->
    <!--{if $status == 3 || $status == 5}-->
    <!--{elseif helper_access::check_module('group')}-->
    <a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="gxrGD2JK4O8s">{$langplus[join]}</a>
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $status == 'isgroupuser'}-->
    <a href="forum.php?mod=group&action=out&fid=$_G[fid]&mobile=2" class="nkV9hgjv0FcG">{lang logout}</a>
    <!--{/if}-->
</div>
<!--{/if}-->
<!--{if $action == 'index' && ($status == 2 || $status == 3 || $status == 5)}-->
<!--{if $status == 3 || $status == 5}-->
<div class="hjmbGzqamYTp"><div class="IHUDUAqpiULT">{lang group_has_joined}</div></div>
<!--{/if}-->
<!--{/if}-->

<script type="text/javascript">
    $(document).on('click','.ajaxgroups',function(){
        <!--{if !$_G[uid]}-->
        popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
        <!--{else}-->
        var obj = $(this);
        $.ajax({
            type:'POST',
            url:obj.attr('href') + '&handlekey=ajaxgroups&inajax=1',
            data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
            dataType:'xml',
        })
            .success(function(s) {
                var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
                var smgjoin = '{$langplus[joinsucceed]}';
                var smgexit = '{$langplus[exitsucceed]}';
                if(smg.indexOf(smgjoin) >= 0) {
                    obj.addClass('group_out').html('{lang logout}');
                    obj.attr('href', 'forum.php?mod=group&action=out&fid=$_G[fid]');
                }else if(smg.indexOf(smgexit) >= 0){
                    obj.removeClass('group_out').html('{$langplus[join]}');
                    obj.attr('href', 'forum.php?mod=group&action=join&fid=$_G[fid]');
                }else{
                    popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg+'</dt></div>');
                    setTimeout(function(){
                        $(".dialogbox, #mask").fadeOut();
                    }, 1500);
                }
            })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
        <!--{/if}-->
        return false;
    });
</script>
<!--{/if}-->
<!--{/if}-->

<!--{if $action == 'index' && $status != 2 && $status != 3}-->
<!--{eval dheader("location: forum.php?mod=forumdisplay&action=list&fid=$_G[fid]");exit; }-->
<!--{elseif $action == 'list'}-->
<!--{template group/group_list}-->
<!--{elseif $action == 'memberlist'}-->
<!--{template group/group_memberlist}-->
<!--{elseif $action == 'create'}-->
<!--{template group/group_create}-->
<!--{elseif $action == 'manage'}-->
<!--{template group/group_manage}-->
<!--{/if}-->

<!--{subtemplate common/footer}-->