<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="group.php?{if $gid}gid{/if}{if $sgid}sgid{/if}=$curtype['fid']">$curtype[name]</a><!--{/block}-->
<!--{template common/header}-->
<!--{if $typelist}-->
<div class="eKqfRvwAu5cE">
    <div class="jqRecDJMSqQs">
        <ul class="qhUm3fRMfQIL">
            <!--{loop $typelist $fid $type}-->
            <li class="wW0qVBCG1RrL"><a href="group.php?sgid=$fid">$type[name]</a></li>
            <!--{/loop}-->
        </ul>
    </div>
</div>
<script src="./template/v2_mbl20121009/touch_plus/js/swiper.min.js?{VERHASH}"></script>
<script type="text/javascript">
    $(function() {
        var swiper = new Swiper('.menu_container', {
            wrapperClass:'menu_wrapper',
            slideClass:'menu_slide',
            slidesPerView:'auto',
            freeMode:true,
            freeModeFluid:true,
            momentumBounce:true,
            initialSlide:0,
        });
    })
</script>
<!--{/if}-->
    <!--{if $list}-->    
    <div class="dQgvs7znuwpf">
        <ul id="alist" class="CGspWma9vU35">
            <!--{loop $list $fid $val}-->
            <!--{eval $val[join] = C::t('forum_groupuser')->fetch_userinfo($_G['uid'], $fid);}-->
            <li class="wH3cPtGthBRK">
                <a href="forum.php?mod=forumdisplay&action=list&fid=$fid" class="BlyDcG5YQDZr">
                <!--{if strstr($val[icon],'groupicon.gif')}-->
                <img src="template/v2_mbl20121009/touch_plus/image/groupicon.png" />
                <!--{else}-->
                <img src="$val[icon]" />
                <!--{/if}-->
                <h1>$val[name]<!--{if $val[todayposts] > 0}--><i title="{$val[todayposts]}">new</i><!--{/if}--></h1>
                <p><!--{if $val[description]}-->$val[description]<!--{else}-->$val[membernum] <span>{lang member}</span> &nbsp; $val[threads] <span>{lang threads}</span><!--{/if}--></p>
                </a>
                <!--{if ($val[founderuid] == $_G['uid']) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=manage&fid=$val[fid]" class="1wd0D5ofiP74">{lang manage}</a>
                <!--{elseif (helper_access::check_module('group') && $val[join]) && $_G['uid']}-->
                <a href="forum.php?mod=group&action=out&fid=$val[fid]" class="5sltCVywm0aL">{lang logout}</a>
                <!--{else}-->
                <a href="forum.php?mod=group&action=join&fid=$val[fid]" class="VwB5Mri1QvZQ">{$langplus[join]}</a>
                <!--{/if}-->
            </li>
            <!--{/loop}-->
        </ul>
    </div>
<script type="text/javascript">
    $(document).on('click','.ajaxgroups',function(){
        <!--{if !$_G[uid]}-->
        popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
        <!--{else}-->
        var obj = $(this);
        $.ajax({
            type:'POST',
            url:obj.attr('href') + '&handlekey=ajaxgroups&inajax=1',
            data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
            dataType:'xml',
        })
            .success(function(s) {
                var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
                var gfid = s.lastChild.firstChild.nodeValue.match(/&fid=(.+?)&/i)[1];
                var smgjoin = '{$langplus[joinsucceed]}';
                var smgexit = '{$langplus[exitsucceed]}';
                if(smg.indexOf(smgjoin) >= 0) {
                    obj.addClass('dialog_delfav').removeClass('sstbg').html('{lang logout}');
                    obj.attr('href', 'forum.php?mod=group&action=out&fid=' + gfid);
                }else if(smg.indexOf(smgexit) >= 0){
                    obj.removeClass('dialog_delfav').addClass('sstbg').html('{$langplus[join]}');
                    obj.attr('href', 'forum.php?mod=group&action=join&fid=' + gfid);
                }else{
                    popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg+'</dt></div>');
                    setTimeout(function(){
                        $(".dialogbox, #mask").fadeOut();
                    }, 1500);
                }
            })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
        <!--{/if}-->
        return false;
    });
</script>
    <!--{else}-->
    <div class="sqK9gG26iUGb">{lang group_category_no_groups}</div>
    <!--{/if}--> 
  
 	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($getcount / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="{$url}&orderby={$orderby}" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->
<!--{block bottombutton}-->
<ul>
    <!--{if $tplwapurl}-->
    <li><a href="forum.php"><i class="vYwrd8Li1T3q"></i>$langplus[home]</a></li>
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{else}-->
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{$footertwo}-->
    <!--{/if}-->
    <li><div class="lkzxUSeCuNPo"><a {if $_G[uid]}href="forum.php?mod=group&action=create"{else}href="javascript:;" onclick="popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');" {/if} class="i0a6HFurbhHA"><i class="AG5yZ3ftzshu"></i></a></div></li>
    <!--{if !$tplwapurl && $footernavtw == 3}--><!--{$footerfour}--><!--{else}--><li class="Yfm1QC5IeoTk"><a href="group.php"><i class="YnfUIGTrsvCI"></i>{$langplus[groups]}</a></li><!--{/if}-->
    <li>
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
        <a href="member.php?mod=logging&action=login"><i class="0iHKtK6RqXLZ"></i>{lang login}</a>
        <!--{else}-->
        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="0iHKtK6RqXLZ"></i>$langplus[me]</a>
        <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="Iug1I7rXnrOf"></i><!--{/if}-->
        <!--{/if}-->
    </li>
</ul>
<!--{/block}-->
<!--{template common/footer}-->