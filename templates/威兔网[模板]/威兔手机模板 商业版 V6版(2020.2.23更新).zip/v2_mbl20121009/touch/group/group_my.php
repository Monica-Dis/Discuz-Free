<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="group.php?mod=my">{$_G[username]}{lang somebody_group}</a><!--{/block}-->
<!--{template common/header}-->
<div class="NkGgJbO2CQdl">
    <ul>
        <li $actives[groupthread]><a href="group.php?mod=my&view=groupthread">{lang group_thread}</a></li>
        <li $actives[mythread]><a href="group.php?mod=my&view=mythread">{lang my_thread}</a></li>
        <li $actives[join]><a href="group.php?mod=my&view=join">{lang my_join}</a></li>
        <li $actives[manager]><a href="group.php?mod=my&view=manager">{lang my_manage}</a></li>
    </ul>
</div>
<!--{if $view == 'groupthread' || $view == 'mythread'}-->
<!--{if $usergroups['grouptype']}-->
<!--{if $sortmenufloat}--><div class="AtXpQP883jim"><!--{/if}-->
<div class="slidemenu tabequal_3{if $sortmenufloat} sortmenus{/if}">
    <div class="jqRecDJMSqQs">
        <ul class="qhUm3fRMfQIL">
            <li class="menu_slide{if empty($typeid)} a{/if}"><a href="group.php?mod=my&view=$view">{lang all}</a></li>
            <!--{loop $usergroups['grouptype'] $type}-->
            <li class="menu_slide{if $typeid == $type['fid']} a{/if}"><a href="group.php?mod=my&view=$view{if $typeid != $type['fid']}&typeid=$type[fid]{/if}">$type[name]</a></li>
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{if $sortmenufloat}--></div><!--{/if}-->
<script src="./template/v2_mbl20121009/touch_plus/js/swiper.min.js?{VERHASH}"></script>
<script type="text/javascript">
    $(function() {
        if ($('.slidemenu .a').length > 0) {
            var slidefocus = $('.slidemenu .a').offset().left + $('.slidemenu .a').width() >= $(window).width() ? $('.slidemenu .a').index() : 0;
        } else {
            var slidefocus = 0;
        }
        var swiper = new Swiper('.menu_container', {
            wrapperClass:'menu_wrapper',
            slideClass:'menu_slide',
            slidesPerView:'auto',
            freeMode:true,
            freeModeFluid:true,
            momentumBounce:true,
            initialSlide:slidefocus,
        });
    })
</script>
<!--{/if}-->
<!--{if $attentionthread}-->
<div class="group_forum{if $groupthreadlist} mbm{/if}">
    <!--{loop $attentionthread $groupid $threads}-->
    <div class="OsFv1OpGjMGc"><h2>{$usergroups['groups'][$groupid]}<a href="forum.php?mod=group&fid=$groupid" class="99u2LxYcMOhO">{lang more}</a></h2></div>
    <ul class="HwKFWtPXAVEl">
        <!--{loop $threads $tid $thread}-->
        <li class="0SjyuQop6KJp">
            <a href="forum.php?mod=viewthread&tid=$tid" class="yUloUBxjglb3">
                <h1>$thread[subject]</h1>
                <div class="hNOK3poJcpFf">
                    <span><!--{if $thread['lastposter']}-->$thread[lastposter]<!--{else}-->{lang anonymous}<!--{/if}--></span>
                    <span>$thread[lastpost]</span>
                    <!--{if $thread[replies]}-->
                    <!--{if $thread[replies] > 9999 }-->
                    <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{else}-->
                    <!--{if $thread[views] > 9999 }-->
                    <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <span class="99u2LxYcMOhO"><!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}-->{$thread[views]}{$langplus[view]}<!--{/if}--></span>
                    <span class="r9COG0I1EFgN">#{$thread[groupname]}</span>
                </div>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
    <!--{/loop}-->
</div>
<!--{/if}-->
<!--{if $groupthreadlist}-->
<div class="8LPmEI6chm7P">
    <!--{if $view == 'groupthread'}-->
    <div class="OsFv1OpGjMGc"><h2><!--{if $view == 'groupthread'}-->{lang last_topic_in_group}<!--{else}-->{lang my_last_topic_in_group}<!--{/if}--></h2></div>
    <!--{/if}-->
    <ul id="alist" class="HwKFWtPXAVEl">
        <!--{loop $groupthreadlist $tid $thread}-->
        <li class="0SjyuQop6KJp">
            <a href="forum.php?mod=viewthread&tid=$tid" class="yUloUBxjglb3">
                <h1>$thread[subject]</h1>
                <div class="hNOK3poJcpFf">
                    <span><!--{if $thread['lastposter']}-->$thread[lastposter]<!--{else}-->{lang anonymous}<!--{/if}--></span>
                    <span>$thread[lastpost]</span>
                    <!--{if $thread[replies]}-->
                    <!--{if $thread[replies] > 9999 }-->
                    <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{else}-->
                    <!--{if $thread[views] > 9999 }-->
                    <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <span class="99u2LxYcMOhO"><!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}-->{$thread[views]}{$langplus[view]}<!--{/if}--></span>
                    <span class="r9COG0I1EFgN">#{$thread[groupname]}</span>
                </div>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{if $tplpages == 1}-->
<!--{if $multipage}-->
<!--{eval $totalpage = ceil(1000 / $perpage);}-->
<a href="group.php?mod=my&view={$view}{$typeurl}" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{else}-->
$multipage
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{if !$attentionthread && !$groupthreadlist}-->
<div class="sqK9gG26iUGb">{lang no_related_posts}</div>
<!--{/if}-->
<!--{elseif $view == 'manager' || $view == 'join'}-->
<!--{if $grouplist}-->
<div class="dQgvs7znuwpf">
    <ul id="alist" class="CGspWma9vU35">
        <!--{loop $grouplist $groupid $group}-->
        <!--{eval $group[membernum] = DB::result_first('SELECT membernum FROM '.DB::table('forum_forumfield').' WHERE fid ='.$groupid)}-->
        <!--{eval $group[description] = DB::result_first('SELECT description FROM '.DB::table('forum_forumfield').' WHERE fid ='.$groupid)}-->
        <li class="wH3cPtGthBRK">
            <a href="forum.php?mod=forumdisplay&action=list&fid=$groupid">
                <!--{if strstr($group[icon],'groupicon.gif')}-->
                <img src="template/v2_mbl20121009/touch_plus/image/groupicon.png" />
                <!--{else}-->
                <img src="$group[icon]" />
                <!--{/if}-->
                <h1>$group[name]<!--{if $group[todayposts] > 0}--><i title="{$group[todayposts]}">new</i><!--{/if}--></h1>
                <!--{if $group[description]}-->
                <p>$group[description]</p>
                <!--{else}-->
                <!--{if $group[membernum] > 9999 }-->
                <!--{eval $group[membernum] = round($group[membernum] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $group[threads] > 9999 }-->
                <!--{eval $group[threads] = round($group[threads] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <p>{lang member} {$group[membernum]} &nbsp; {lang threads} {$group[threads]}</p>
                <!--{/if}-->
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($num / $perpage);}-->
<!--{if $totalpage > $page}-->
<a href="group.php?mod=my&view={$view}" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{else}-->
<div class="sqK9gG26iUGb">{lang no_group_join}</div>
<!--{/if}-->
<!--{/if}-->

<!--{block bottombutton}-->
<ul>
    <!--{if $tplwapurl}-->
    <li><a href="forum.php"><i class="vYwrd8Li1T3q"></i>$langplus[home]</a></li>
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{else}-->
    <li><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>$langplus[bbs]</a></li>
    <!--{$footertwo}-->
    <!--{/if}-->
    <li><div class="lkzxUSeCuNPo"><a {if $_G[uid]}href="forum.php?mod=group&action=create"{else}href="javascript:;" onclick="popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');" {/if} class="i0a6HFurbhHA"><i class="AG5yZ3ftzshu"></i></a></div></li>
    <!--{if !$tplwapurl && $footernavtw == 3}--><!--{$footerfour}--><!--{else}--><li class="Yfm1QC5IeoTk"><a href="group.php"><i class="YnfUIGTrsvCI"></i>{$langplus[groups]}</a></li><!--{/if}-->
    <li>
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
        <a href="member.php?mod=logging&action=login"><i class="0iHKtK6RqXLZ"></i>{lang login}</a>
        <!--{else}-->
        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="0iHKtK6RqXLZ"></i>$langplus[me]</a>
        <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="Iug1I7rXnrOf"></i><!--{/if}-->
        <!--{/if}-->
    </li>
</ul>
<!--{/block}-->
<!--{template common/footer}-->