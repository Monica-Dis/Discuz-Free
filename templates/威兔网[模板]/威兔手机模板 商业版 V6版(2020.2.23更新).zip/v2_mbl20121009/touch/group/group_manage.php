<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $action != 'create'}-->
<!--{if $status != 2 && $status != 3}-->
<div class="NkGgJbO2CQdl">
    <ul>
        <li {if $action == 'list'}class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang group_discuss_area}</a></li>
        <li {if $action == 'memberlist' || $action == 'invite'}class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]">{lang group_member_list}</a></li>
        <!--{if $_G['forum']['ismoderator']}--><li {if $action == 'manage'}class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=group&action=manage&fid=$_G[fid]">{lang group_admin}</a></li><!--{/if}-->
    </ul>
</div>
<!--{/if}-->
<!--{/if}-->
<div class="NkGgJbO2CQdl">
	<ul>
		<li{if $_GET['op'] == 'group'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=group&action=manage&op=group&fid=$_G[fid]">{lang group_setup}</a></li>
		<!--{if !empty($groupmanagers[$_G[uid]]) || $_G['adminid'] == 1}-->
		<li{if $_GET['op'] == 'checkuser'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]">{lang group_member_moderate}</a></li>
		<li{if $_GET['op'] == 'manageuser'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]">{lang group_member_management}</a></li>
		<!--{/if}-->
		<!--{if $_G['forum']['founderuid'] == $_G['uid'] || $_G['adminid'] == 1}-->
		<li{if $_GET['op'] == 'threadtype'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]">{lang group_threadtype}</a></li>
		<li{if $_GET['op'] == 'demise'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]">{lang group_demise}</a></li>
		<!--{/if}-->
	</ul>
</div>
<!--{if $_GET['op'] == 'group'}-->
<form enctype="multipart/form-data" action="forum.php?mod=group&action=manage&op=group&fid=$_G[fid]" name="manage" method="post" autocomplete="off" accept-charset="utf-8" onsubmit="document.charset='utf-8';">
    <input type="hidden" value="{FORMHASH}" name="formhash" />
    <input type="hidden" value="group_handle" name="handlekey" />
    <div class="RGzOcPO730ks">
        <ul>
            <!--{if !empty($specialswitch['allowchangename']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
            <li>
                <div class="nOAF1bDOaAAV">{lang group_name} :</div>
                <input type="text" id="name" autocomplete="off" name="name" value="$_G[forum][name]">
            </li>
            <!--{/if}-->
            <!--{if !empty($specialswitch['allowchangetype']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
            <li>
                <div class="nOAF1bDOaAAV">{lang group_category} :</div>
                <div class="8V5dkRIC3BfX">
                    <select name="parentid" id="parentid" onchange="group_ajaxget('forum.php?mod=ajax&action=secondgroup&fupid='+ this.value);">
                        $groupselect[first]
                    </select>
                </div>
            </li>
            <li>
                <div id="secondgroup" {if !$groupselect['second']}style="display:none"{/if}>
                <div class="nOAF1bDOaAAV">{lang group_category} :</div>
                <div id="linkage" class="8V5dkRIC3BfX">
                    <select name="fup" id="fup" >
                        $groupselect[second]
                    </select>
                </div>
                </div>
            </li>
            <!--{/if}-->
    <li class="03xiqrreb8On">
        <textarea name="descriptionnew" id="descriptionmessage" rows="5" placeholder="{lang group_description} :">$_G[forum][descriptionnew]</textarea>
    </li>
    <li>
        <div class="nOAF1bDOaAAV">{lang group_perm_visit} :</div>
        <div class="8V5dkRIC3BfX">
            <select name="gviewpermnew" id="gviewperm" >
                <option value="1" {if $_G['forum']['gviewperm']=='1'}selected="selected"{/if}>{lang group_perm_all_user}</option>
                <!--{if in_array($_G[adminid], array(1))}-->
                <option value="0" {if $_G['forum']['gviewperm']=='0'}selected="selected"{/if}>{lang group_perm_member_only}</option>
                <!--{/if}-->
            </select>
        </div>
    </li>
    <li>
        <div class="nOAF1bDOaAAV">{lang group_join_type} :</div>
        <div class="8V5dkRIC3BfX">
            <select name="jointypenew" id="jointype">
                <option value="0" {if $_G['forum']['jointype']=='0'}selected="selected"{/if}>{lang group_join_type_free}</option>
                <!--{if in_array($_G[adminid], array(1))}-->
                <option value="2" {if $_G['forum']['jointype']=='2'}selected="selected"{/if}>{lang group_join_type_moderate}</option>
                <option value="1" {if $_G['forum']['jointype']=='1'}selected="selected"{/if}>{lang group_join_type_invite}</option>
                <!--{if !empty($specialswitch['allowclosegroup'])}-->
                <option value="-1" {if $_G['forum']['jointype']=='-1'}selected="selected"{/if}>{lang close}</option>
                <!--{/if}-->
                <!--{/if}-->
            </select>
        </div>
    </li>
    </ul>
    <!--{if !empty($_G['group']['allowupbanner']) || $_G['adminid'] == 1}-->
    <div class="3mLeu3YVGKju">
        <div class="a71qEwXIeaMl"><img src="{if $_G['forum']['banner']}$_G[forum][banner]?{TIMESTAMP}{else}static/image/common/groupicon.gif{/if}"><input type="file" value="" name="bannernew" id="bannernew" class="EiqCLkVvmZZ9" onchange="preview('bannernew')" accept="image/*" /></div>
        <p class="sEj1sHHzaWFN">{lang group_image}</p>
        <p class="ZIxpOtbJtB6a">{$langplus[groupimgfilesize]}</p>
    </div>
    <!--{/if}-->
    <div class="3mLeu3YVGKju">
        <div class="a71qEwXIeaMl"><img src="$_G[forum][icon]?{TIMESTAMP}"><input type="file" value="" name="iconnew" id="iconnew" class="EiqCLkVvmZZ9" onchange="preview('iconnew')" accept="image/*" /></div>
        <p class="sEj1sHHzaWFN">{lang group_icon}</p>
        <p class="ZIxpOtbJtB6a">{$langplus[autocutzoom]}</p>
    </div>
    </div>
    <div class="P2AdpZ33Cex1"><button type="submit" class="hWkKLBWkXyXu" name="groupmanage" value="1">{lang submit}</button></div>
</form>
<!--{elseif $_GET['op'] == 'checkuser'}-->
<!--{if $checkusers}-->
<div class="rkdRiwH1mJE2">
    <ul id="alist" class="HwKFWtPXAVEl">
        <!--{loop $checkusers $uid $user}-->
        <li>
            <a href="home.php?mod=space&uid=$user[uid]&do=profile" class="wyrT88Zbk4nR">
                <!--{echo avatar($user[uid],'middle')}-->
                <h2>$user[username]</h2>
                <p>$user['joindateline']</p>
            </a>
            <div class="nYeW1nXdUAXe">
                <a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=1" class="F3pveqiOE331">{lang pass}</a>
                <a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=2" class="F3pveqiOE331">{lang ignore}</a>
            </div>
        </li>
        <!--{/loop}-->
    </ul>
    <div class="P2AdpZ33Cex1">
        <div class="Hwo4Ms30B8m6"><a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=1" class="dnOUFIhA88M3">{lang pass_all}</a></div>
        <div class="99u2LxYcMOhO"><a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&checkall=2" class="dnOUFIhA88M3">{lang ignore_all}</a></div>
    </div>
</div>
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($checknum / $perpage);}-->
<!--{if $totalpage > $page}-->
<a href="forum.php?mod=group&action=manage&op={$_GET['op']}&fid={$_G['fid']}" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{else}-->
<div class="sqK9gG26iUGb">{lang group_no_member_moderated}</div>
<!--{/if}-->
<!--{elseif $_GET['op'] == 'manageuser'}-->
<!--{if $_G['forum']['membernum'] > 300}-->
<div class="uo53jvBk2MDv">
    <form action="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]&mobile=2" method="post" accept-charset="utf-8" onsubmit="document.charset='utf-8';">
        <input type="text" placeholder="{lang enter_member_user}" value="" size="15" id="groupsearch" name="srchuser">
        <button type="submit"><i class="U2Rdg89k2e6A"></i></button>
    </form>
</div>
<!--{/if}-->
<form action="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]&manageuser=true" name="manageuser" id="manageuser" method="post" autocomplete="off" >
    <input type="hidden" value="{FORMHASH}" name="formhash" />
    <input type="hidden" value="0" name="targetlevel" id="targetlevel" />
    <div class="YvPMfc8w8wwO">
        <!--{if $adminuserlist}-->
        <h2>{lang group_admin_member}</h2>
        <ul{if $staruserlist || $userlist} class="Jcm3VN0vxJGf"{/if}>
            <!--{loop $adminuserlist $user}-->
            <li>
                <!--{if $_G['adminid'] == 1 || ($_G['uid'] != $user['uid'] && ($_G['uid'] == $_G['forum']['founderuid'] || $user['level'] > $groupuser['level']))}-->
                <label for="u{$user['uid']}"><input type="checkbox" name="muid[{$user[uid]}]" value="$user[level]" /></label>
                <!--{/if}-->
                <a href="home.php?mod=space&uid=$user[uid]&do=profile">
                    <img src="{avatar($user[uid],middle,true)}" class="UoRZiAghxSa8" />
                    $user[username]
                </a>
            </li>
            <!--{/loop}-->
        </ul>
    <!--{/if}-->
    <!--{if $staruserlist || $userlist}-->
    <h2>{$langplus[groups]}{lang member}</h2>
    <ul id="alist" class="CGspWma9vU35">
        <!--{if $staruserlist}-->
        <!--{loop $staruserlist $user}-->
        <li>
            <!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}-->
            <label for="u{$user['uid']}"><input type="checkbox" name="muid[{$user[uid]}]" value="$user[level]" /></label>
            <!--{/if}-->
            <a href="home.php?mod=space&uid=$user[uid]&do=profile">
                <img src="{avatar($user[uid],middle,true)}" class="UoRZiAghxSa8" />
                $user[username]
            </a>
        </li>
        <!--{/loop}-->
        <!--{/if}-->
        <!--{if $userlist}-->
        <!--{loop $userlist $user}-->
        <li>
            <!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}-->
            <label for="u{$user['uid']}"><input type="checkbox" name="muid[{$user[uid]}]" value="$user[level]" /></label>
            <!--{/if}-->
            <a href="home.php?mod=space&uid=$user[uid]&do=profile">
                <img src="{avatar($user[uid],middle,true)}" class="UoRZiAghxSa8" />
                $user[username]
            </a>
        </li>
        <!--{/loop}-->
        <!--{/if}-->
    </ul>
    <!--{/if}-->
    </div>
    <div class="P2AdpZ33Cex1">
        <ul class="Oq02BukHP9GL">
        <!--{loop $mtype $key $name}-->
        <!--{if $_G['forum']['founderuid'] == $_G['uid'] || $key > $groupuser['level'] || $_G['adminid'] == 1}-->
        <li><button type="button" name="manageuser" value="true" class="Tnm8u3PJFibk" onclick="groupManageUser('{$key}')">$name</button></li>
        <!--{/if}-->
        <!--{/loop}-->
        </ul>
    </div>
</form>
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($_G['forum']['membernum'] / $perpage);}-->
<!--{if $totalpage > $page}-->
<a href="forum.php?mod=group&action=manage&op={$_GET['op']}&fid={$_G['fid']}" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{if $_G['forum']['membernum'] > 300}-->
<style type="text/css">.ftbox { height: 112px !important;}{if !$headershow} .scroll_openmenu { bottom: 140px; }{/if}</style>
<!--{/if}-->
<!--{elseif $_GET['op'] == 'threadtype'}-->
<form id="threadtypeform" action="forum.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]" autocomplete="off" method="post" name="threadtypeform" accept-charset="utf-8" onsubmit="document.charset='utf-8';">
    <input type="hidden" value="{FORMHASH}" name="formhash" />
    <input type="hidden"  name="tab" value="groupmanage"/>
    <div class="FI4Cuo62JW6C">
        <ul>
            <li>
                <span>{lang threadtype_turn_on} :</span>
                <input type="checkbox" name="threadtypesnew[status]" onclick="setstatus()" value="1" id="status" {if $_G['forum']['threadtypes']['status']=='1'}checked="checked"{/if}/>
            </li>
        </ul>
        <ul id="threadtypest"{if !$_G['forum']['threadtypes']['status']} style="display:none"{/if}>
        <li>
            <span>{lang threadtype_required} :</span>
            <input type="checkbox" name="threadtypesnew[required]" value="1" {if $_G['forum']['threadtypes']['required']=='1'}checked="checked"{/if}/>
        </li>
        <li>
            <span>{lang threadtype_prefix} :</span>
            <input type="checkbox" name="threadtypesnew[prefix]" value="1" {if $_G['forum']['threadtypes']['prefix']=='1'}checked="checked"{/if}/>
        </li>
        </ul>
        <div id="threadtypes" {if !$_G['forum']['threadtypes']['status']}style="display:none"{/if}>
        <table cellspacing="0" cellpadding="0" id="threadtype" class="Cup5BW0kIRqo">
            <thead>
            <tr>
                <th>{lang delete}</th>
                <th>{lang enable}</th>
                <th>{lang displayorder}</th>
                <td>{lang threadtype_name}<a href="javascript:;" onclick="addrow('threadtype')" class="r9COG0I1EFgN">{lang threadtype_add}</a></td>
            </tr>
            </thead>
            <!--{if $threadtypes}-->
            <!--{loop $threadtypes $val}-->
            <tbody>
            <tr>
                <th><input type="checkbox" name="threadtypesnew[options][delete][]" value="{$val[typeid]}" /></th>
                <th><input type="checkbox" name="threadtypesnew[options][enable][{$val[typeid]}]" value="1" $val[enablechecked] /></th>
                <th class="MDmAhYgxMg3D"><input type="text" name="threadtypesnew[options][displayorder][{$val[typeid]}]" value="$val[displayorder]" /></th>
                <td class="G10oNaPA0DMM"><input type="text" name="threadtypesnew[options][name][{$val[typeid]}]" value="$val[name]" /></td>
            </tr>
            </tbody>
            <!--{/loop}-->
            <!--{/if}-->
        </table>
    </div>
    </div>
    <div class="P2AdpZ33Cex1"><button type="submit" class="hWkKLBWkXyXu" name="groupthreadtype" value="1">{lang submit}</button></div>
</form>
<!--{eval $addrowdirect = count($threadtypes);}-->
<!--{elseif $_GET['op'] == 'demise'}-->
<form action="forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]" name="groupdemise" method="post">
    <input type="hidden" value="{FORMHASH}" name="formhash" />
    <input type="hidden"  name="tab" value="groupmanage"/>
        <!--{if $groupmanagers}-->
        <div class="r14TzKg0g0jr">
            {lang group_demise_comment}
            {lang group_demise_notice}
            <h2 class="Ie7H24xmiKQ3">{lang transfer_group_to} :</h2>
        </div>
        <div class="YvPMfc8w8wwO">
            <ul>
                <!--{loop $groupmanagers $user}-->
                <li>
                    <!--{if $user['uid'] != $_G['uid']}-->
                    <label for="u{$user['uid']}"><input type="radio" name="suid" value="$user[uid]" /></label>
                    <!--{else}-->
                    <label for="u{$user['uid']}"><input type="radio" name="suid" value="$user[uid]" /></label>
                    <!--{/if}-->
                    <a href="home.php?mod=space&uid=$user[uid]&do=profile">
                        <img src="{avatar($user[uid],middle,true)}" class="UoRZiAghxSa8" />
                        $user[username]
                    </a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
        <div class="OXYSnNzxWtDV"><input type="password" name="grouppwd" placeholder="{lang group_input_password}" /></div>
        <div class="P2AdpZ33Cex1"><button type="submit" name="groupdemise" class="hWkKLBWkXyXu" value="1">{lang submit}</button></div>
</form>
<style type="text/css">.ftbox { height: 115px !important;}{if !$headershow} .scroll_openmenu { bottom: 140px; }{/if}</style>
<!--{else}-->
<div class="sqK9gG26iUGb">{lang group_no_admin_member}</div>
<!--{/if}-->
<!--{/if}-->
<!--{if $_GET['op'] == 'group'}-->
<script type="text/javascript">
    function preview(id){
        var file=$('#'+id).val();
        var arr=file.split('\\');
        var name=arr[arr.length-1];
        $('#'+id+'_name').html(name);
    }
    function show(id){
        if($('#'+id).css('display')=='none'){
            $('#'+id).css('display', '');
        }else{
            $('#'+id).css('display', 'none');
        }
    }
    function group_ajaxget(url) {
        $.ajax({
            type:'GET',
            url: url + '&inajax=1' ,
            dataType:'xml',
        }).success(function(s) {
            $('#linkage').html(s.lastChild.firstChild.nodeValue);
            return;
        });
    }
    $(document).on('change', '.groupiconup', function() {
        popup.open('<div class="lmVdjV39q3EP"></div>');
        setTimeout(function(){
            $(".dialogbox, #mask").fadeOut();
        }, 4000);
    });
</script>
<!--{elseif $_GET['op'] == 'manageuser'}-->
<script type="text/javascript" id="script_groupManageUser">
    function groupManageUser(targetlevel_val) {
        document.getElementById('targetlevel').value = targetlevel_val;
        document.getElementById('manageuser').submit();
    }
    <!--{if !$_GET['getpage']}-->
    evalscripts.push('script_groupManageUser');
    <!--{/if}-->
</script>
<!--{elseif $_GET['op'] == 'threadtype'}-->
<script type="text/JavaScript" id="script_groupthreadtype" reload="1">
    var addrowdirect = $addrowdirect;
    var typenumlimit = $typenumlimit;
    function addrow(id){
        if(addrowdirect>=typenumlimit){
            alert('{lang group_threadtype_limit_1}'+typenumlimit+'{lang group_threadtype_limit_2}');
        }else{
            var row ='<tbody><tr><th><input type="checkbox" disabled="disabled" /></th><th><input type="checkbox" name="newenable[]" checked="checked" value="1" /></th><th class="MDmAhYgxMg3D"><input type="text" name="newdisplayorder[]" value="0" /></th><td class="G10oNaPA0DMM"><input type="text" name="newname[]" placeholder="{lang threadtype_name}"/></td></tr></tbody>';
            $('#'+id).append(row);
            addrowdirect++;
        }
    }
    function setstatus(){
        if($("#status").attr("checked")=='checked'){
            $('#threadtypest').css({'display':''});
            $('#threadtypes').css({'display':''});
        }else{
            $('#threadtypest').css({'display':'none'});
            $('#threadtypes').css({'display':'none'});
        }
    }
    <!--{if !$_GET['getpage']}-->
    evalscripts.push('script_groupthreadtype');
    <!--{/if}-->
</script>
<!--{/if}-->

<!--{eval $nofooter = true;}-->
<!--{block footerplus}--><div class="a87wGthEpSmH"></div><!--{/block}-->