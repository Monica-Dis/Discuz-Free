<?php echo 'From: DisM.taobao.com';exit;?>
<div class="HCbJuvrQ28xg">
	<div class="Y3MoBRXHeI14"><!--{if $activity['thumb']}--><img src="$activity['attachurl']" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/activity.jpg" /><!--{/if}--></div>
    <div class="3dyckBPpJwK8">
    <table cellspacing="0" cellpadding="0" >
        <tr><th>{lang activity_type}</th><td>$activity[class]</td></tr>
        <tr><th>{lang activity_starttime}</th>
            <td>
				<!--{if $activity['starttimeto']}-->
					{lang activity_start_between}
				<!--{else}-->
					$activity[starttimefrom]
				<!--{/if}-->
            </td>
        </tr>
        <tr><th>{lang activity_space}</th><td>$activity[place]</td></tr>
		<tr><th>{lang gender}</th>
            <td>
				<!--{if $activity['gender'] == 1}-->
					{lang male}
				<!--{elseif $activity['gender'] == 2}-->
					{lang female}
				<!--{else}-->
					 {lang unlimited}
				<!--{/if}-->
            </td>
		</tr>
		<!--{if $activity['cost']}-->
        <tr><th>{lang activity_payment}</th><td><em class="b8WVq0JMhhKi">$activity[cost]</em> {lang payment_unit}</td></tr>
		<!--{/if}-->
		<!--{if !$_G['forum_thread']['is_archived']}-->
		<tr><th>{$langplus[activity_already]}</th>
            <td><em class="b8WVq0JMhhKi">$allapplynum</em> {lang activity_member_unit}</td>
		</tr>
		<!--{if $activity['number']}-->
		<tr><th>{lang activity_about_member}</th>
            <td><em class="b8WVq0JMhhKi">$aboutmembers</em> {lang activity_member_unit}</td>
		</tr>
		<!--{/if}-->
		<!--{if $activity['expiration']}-->
        <tr><th>{lang post_closing}</th><td>$activity[expiration]</td></tr>
		<!--{/if}-->
		<!--{if $post['invisible'] == 0}-->
		<!--{if $applied && $isverified < 2}-->
        <tr>
            <th>{$langplus[apply]}{lang status}</th><td class="evXx4HZDPWdN"><!--{if !$isverified}-->{lang activity_wait}<!--{else}-->{lang activity_join_audit}<!--{/if}--></td>
        </tr>
		<!--{elseif !$activityclose}-->
		<!--{/if}-->
		<!--{/if}-->
		<!--{/if}-->
    </table>
    <!--{if $activityclose}--><div class="RNWgw1lj3W3S"></div><!--{/if}-->
    </div>
</div>

<!--{if !$activityclose && (!$applied || $isverified == 2)}-->
<a href="javascript:;" class="NtBNCppLvYw2">{$langplus[apply]}</a>
<div class="T8WzIMPFAEdj">
<div class="gZlcaCGmGZ0q"><span class="MzXGZuYzqGml"></span>{lang activity}{$langplus[apply]}</div>
<div id="activityjoin" class="oVsTRxpoyyYs">
    <!--{if $_G['forum']['status'] == 3 && helper_access::check_module('group') && $isgroupuser != 'isgroupuser'}-->
    <div class="4AIRBo6rZ31c">
        <p>{lang activity_no_member}</p>
        <p><a href="forum.php?mod=group&action=join&fid=$_G[fid]" class="Va5v2s2SeGgz">{lang activity_join_group}</a></p>
    </div>
    <!--{else}-->
    <form name="activity" id="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}&mobile=2" >
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <!--{if $_G['setting']['activitycredit'] && $activity['credit'] && !$applied}--><div class="4AIRBo6rZ31c">{lang activity_need_credit} $activity[credit] {$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]}</div><!--{/if}-->
        <dl>
            <!--{if $activity['cost']}-->
            <dt class="O81EHHk1if6T"><span>{lang activity_paytype}</span>
                <p>
                <label><input type="radio" value="0" name="payment" id="payment_0" checked="checked" />{lang activity_self}</label>&nbsp;&nbsp;&nbsp;
                <label><input type="radio" value="1" name="payment" id="payment_1" />{lang activity_would_payment}</label> <input name="payvalue" size="3" /> {lang payment_unit}
                </p>
            </dt>
            <!--{/if}-->
            <!--{if !empty($activity['ufield']['userfield']) || !empty($activity['ufield']['extfield'])}-->
            <!--{if !empty($activity['ufield']['userfield'])}-->
            <!--{loop $activity['ufield']['userfield'] $fieldid}-->
            <dt>
                <!--{if $settings[$fieldid][available]}-->
                <span><em class="evXx4HZDPWdN">*</em>{$settings[$fieldid][title]}</span>
                $htmls[$fieldid]
                <!--{/if}-->
            </dt>
            <!--{/loop}-->
            <!--{/if}-->
            <!--{if !empty($activity['ufield']['extfield'])}-->
            <!--{loop $activity['ufield']['extfield'] $extname}-->
            <dt><span>{$extname}</span><input type="text" name="$extname" maxlength="200"  value="{if !empty($ufielddata)}$ufielddata[extfield][$extname]{/if}" class="OCXqivDi0vAs" /></dt>
            <!--{/loop}-->
            <!--{/if}-->
            <!--{/if}-->
            <dt><span>{$langplus[apply]}{lang leaveword}</span><textarea name="message" maxlength="200" placeholder="" rows="3" >$applyinfo[message]</textarea></dt>
        </dl>
        <!--{if $_G['setting']['activitycredit'] && $activity['credit'] && checklowerlimit(array('extcredits'.$_G['setting']['activitycredit'] => '-'.$activity['credit']), $_G['uid'], 1, 0, 1) !== true}-->
        <div class="EOoE2nXQfaqh">{$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]} {lang not_enough}$activity['credit']</div>
        <!--{else}-->
            <input type="hidden" name="activitysubmit" value="true">
            <em id="return_activityapplies"></em>
            <button type="submit" class="wvt5QuTUqae2" >{lang submit}</button>
        <!--{/if}-->
    </form>
    <script src="template/v2_mbl20121009/touch_plus/js/rlinkage.js"></script>
    <script type="text/javascript">
        function succeedhandle_activityapplies(locationhref, message) {
            showDialog(message, 'notice', '', 'location.href="' + locationhref + '"');
        }
    </script>
    <!--{/if}-->
</div>
</div>
<script type="text/javascript">
    $(document).ready(function(){
        $('.activity_apply_btn').click(function(){
            <!--{if !$_G[uid]}-->
            popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
            <!--{else}-->
            $('.menufly').addClass('infly');
            $('body').addClass('menufly_open');
            <!--{/if}-->
        });
        $('.vt-close').click(function(){
            $('.menufly').removeClass('infly');
            $('body').removeClass('menufly_open');
        });
    });
</script>
<!--{elseif !$activityclose && $applied}-->
<span href="#activityjoincancel_$post[pid]" class="3HkYstLbUXdC">{lang cancel}</span>
<div id="activityjoincancel_$post[pid]" popup="true" style="display: none;">
<div class="iSRkVxKxYh6Y">
    <form name="activity" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplies&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="activitycancel" value="true">
        <div class="dUhw1nwITYMy"><textarea name="message" maxlength="200" rows="3" placeholder="{lang leaveword}" ></textarea></div>
        <div class="pRyrdHt9Wayv"><button type="submit" class="IUkJ90p3Qmnh">{lang activity_join_cancel}</button></div>
    </form>
</div>
</div>
<!--{/if}-->

<!--{if $applylist}-->
	<div class="dZJFE6m3xxKH">
        <div class="rAXYqjm1iljw">{lang activity_new_join}{$langplus[apply]} $applynumbers {lang activity_member_unit}
            <!--{if !$_G['forum_thread']['is_archived']}-->
            <!--{if $post['invisible'] == 0 && ($_G['forum_thread']['authorid'] == $_G['uid'] || (in_array($_G['group']['radminid'], array(1, 2)) && $_G['group']['alloweditactivity']) || ( $_G['group']['radminid'] == 3 && $_G['forum']['ismoderator'] && $_G['group']['alloweditactivity']))}-->
            <a href="forum.php?mod=misc&action=activityapplylist&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}">{lang manage}</a>
            <!--{/if}-->
            <!--{/if}-->
        </div>
        <!--{loop $applylist $apply}-->
        <div class="cziMxymooAmt">
        <a href="home.php?mod=space&uid=$apply[uid]&do=profile">
            <!--{echo avatar($apply[uid], 'middle')}-->
            <p>$apply[username]</p>
        </a>
        </div>
        <!--{/loop}-->
    </div>
<!--{/if}-->

<!--{if $applylistverified}-->
<div class="dZJFE6m3xxKH">
    <div class="rAXYqjm1iljw">{lang activity_new_signup}{$langplus[apply]} $noverifiednum {lang activity_member_unit}
        <!--{if !$_G['forum_thread']['is_archived']}-->
        <!--{if $post['invisible'] == 0 && ($_G['forum_thread']['authorid'] == $_G['uid'] || (in_array($_G['group']['radminid'], array(1, 2)) && $_G['group']['alloweditactivity']) || ( $_G['group']['radminid'] == 3 && $_G['forum']['ismoderator'] && $_G['group']['alloweditactivity']))}-->
        <a href="forum.php?mod=misc&action=activityapplylist&tid=$_G[tid]&pid=$post[pid]{if $_GET['from']}&from=$_GET['from']{/if}">{lang manage}</a>
        <!--{/if}-->
        <!--{/if}-->
    </div>
    <!--{loop $applylistverified $apply}-->
    <div class="cziMxymooAmt">
        <a href="home.php?mod=space&uid=$apply[uid]&do=profile">
            <!--{echo avatar($apply[uid], 'middle')}-->
            <p>$apply[username]</p>
        </a>
    </div>
    <!--{/loop}-->
</div>
<!--{/if}-->

<div id="postmessage_$post[pid]" class="2QJS1583Ldl0">$post[message]</div>