<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block leftbutton}--><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="29F99Ig1TPn2"></a><!--{eval loaducenter(); $smscheck = uc_pm_checknew($_G['uid']);}--><!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}--><i class="Iug1I7rXnrOf"><!--{if $_G[member][newprompt]}-->{$_G[member][newprompt]}<!--{else}-->N<!--{/if}--></i><!--{/if}--><!--{/block}-->
<!--{if $_GET['mod'] == 'postselect'}--><!--{block header_name}-->{lang quick_post}<!--{/block}--><!--{/if}-->
<!--{template common/header}-->
<!--{if !$_GET['gid'] && ($_GET['mod'] != 'postselect')}-->
<!--{if $tplwapurl && $_GET['forumlist'] != 1}-->
	<!--{eval dheader("location: $tplwapurl");exit; }-->
<!--{/if}-->
<!--{/if}-->

<!--{if $_GET['mod'] == 'postselect'}-->

<!--{if $noheader || !$headershow || $nofooter || !$footershow}-->
<style type="text/css">.forum_left, .forum_right {<!--{if $noheader || !$headershow}--> top: 0px;<!--{/if}--><!--{if $nofooter || !$footershow}--> bottom: 0px;<!--{/if}--> }</style>
<!--{/if}-->
<div class="C37wrkRGIt2N">
    <ul>
        <!--{eval $i = 1;}-->
        <!--{loop $catlist $key $cat}-->
        <li{if $i == 1} class="Yfm1QC5IeoTk"{/if}>$cat[name]</li>
        <!--{eval $i++;}-->
        <!--{/loop}-->
    </ul>
</div>
<div class="9rz3f9gf6SIc">
    <!--{eval $i = 1;}-->
    <!--{loop $catlist $key $cat}-->
    <div class="forumbox{if $i == 1} on{/if}">
        <ul class="WefwVTOJUU71">
            <!--{loop $cat[forums] $forumid}-->
            <!--{eval $forum=$forumlist[$forumid];}-->
            <li class="wH3cPtGthBRK">
                <a {if !$_G[uid]}href="javascript:;" class="ViXaVIRbrz5Y" {else}href="forum.php?mod=post&action=newthread&fid={$forum['fid']}"{/if}>
                <!--{if $forum[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $forum['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <span class="i0a6HFurbhHA">{lang send_threads}</span>
                <h1 class="HWWM8Se5OmMz">{$forum[name]}</h1>
                </a>
            </li>
            <!--{hook/index_middle_v2_mobile}-->
            <!--{eval $i++;}-->
            <!--{/loop}-->
        </ul>
    </div>
    <!--{/loop}-->
    <script type="text/javascript">
        $(document).ready(function(){
            $('.forum_left li').click(function(){
                $('.forum_left li').eq($(this).index()).addClass('on').siblings().removeClass('on');
                $('.forumbox').eq($('.forum_left li').index(this)).addClass('on').siblings().removeClass('on');
            });
            <!--{if !$_G[uid]}-->
            $('.nopost').click(function(){
                popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
            });
            <!--{/if}-->
        })
    </script>
</div>

<!--{else}-->

<!--{if $closeplugin == 0 || $misignshow == 2}-->
<!--{hook/index_top_mobile}-->
<!--{/if}-->
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$addiscuzindex}--><!--{/if}-->
<!--{if $forumtpl != 1}-->
<!--{if $todayposts > 9999 }-->
<!--{eval $todayposts = round($todayposts / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->
<!--{if $posts > 9999 }-->
<!--{eval $posts = round($posts / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->
<!--{if $_G['cache']['userstats']['totalmembers'] > 9999 }-->
<!--{eval $_G['cache']['userstats']['totalmembers'] = round($_G['cache']['userstats']['totalmembers'] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->
<div class="kn8g5JhtMfsj">
<ul>
<li><p>{$langplus[todaypost]}</p><span>$todayposts</span></li>
<li><p>{$langplus[forumposts]}</p><span>$posts</span></li>
<li><p>{$langplus[forumusers]}</p><span>$_G['cache']['userstats']['totalmembers']</span></li>
</ul>
</div>
<!--{if empty($gid) && $announcements && $displayann == 1}-->
   <div class="gaBZV4piJP4p">
    <i class="XiooH6pGoRAp"></i>
    <div><ul>$announcements</ul></div>
   </div>       
<script type="text/javascript">
var li=$(".forumannlist").find("ul li").length;function forumannlist(){$(".forumannlist ul").animate({marginTop:"-32px"},600,function(){$(this).css({marginTop:"0px"}).find("li:first").appendTo(this)})}$(function(){if(li>1){var anns=setInterval("forumannlist()",3000);$(".forumannlist").hover(function(){clearInterval(anns)},function(){anns=setInterval("forumannlist()",3000)})}})
</script>
<!--{/if}-->
<!--{/if}-->
<!-- main forumlist start -->
<!--{eval $adforumida = explode(",",$adforumida); $adforumidb = explode(",",$adforumidb);}-->
<!--{if $forumtpl == 1}-->
<!--{if $noheader || !$headershow || $nofooter || !$footershow}-->
<style type="text/css">.forum_left, .forum_right {<!--{if $noheader || !$headershow}--> top: 0px;<!--{/if}--><!--{if $nofooter || !$footershow}--> bottom: 0px;<!--{/if}--> }</style>
<!--{/if}-->
<div class="C37wrkRGIt2N">
	<ul>
	<!--{if !empty($forum_favlist)}-->
    <li class="Yfm1QC5IeoTk">{$langplus[forum_myfav_f]}</li>
    <!--{/if}-->
    <!--{eval $i = 1;}-->
    <!--{loop $catlist $key $cat}-->
        <li{if empty($forum_favlist)}{if $i == 1} class="Yfm1QC5IeoTk"{/if}{/if}>$cat[name]</li>
	<!--{eval $i++;}-->
    <!--{/loop}-->
    </ul>
</div>
<div class="9rz3f9gf6SIc">
	<!--{if !empty($forum_favlist)}-->
	<div class="JAukwtiAXyYK">
			<ul class="WefwVTOJUU71">
                <!--{loop $forum_favlist $key $favorite}-->
                <!--{if $favforumlist[$favorite[id]]}-->
                <!--{eval $forum=$favforumlist[$favorite[id]];}-->
                <!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
                <li class="wH3cPtGthBRK">
                <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                <!--{if $forum[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $forum['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <h1>{$forum[name]}<!--{if $forum[todayposts] > 0}--><i class="{$forum[todayposts]}">new</i><!--{/if}--></h1>
                <!--{if $forum['redirect']}-->
				<p>{lang url_link}</p>
                <!--{else}-->
                <!--{if $forum[description]}-->
                <p>{echo strip_tags($forum[description])}</p>
                <!--{else}-->
                <!--{if $forum[threads] > 9999 }-->
                <!--{eval $forum[threads] = round($forum[threads] / 10000 , 0).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $forum[posts] > 9999 }-->
                <!--{eval $forum[posts] = round($forum[posts] / 10000 , 0).$langplus[tenthousand];}-->
                <!--{/if}-->                
                <!--{if empty($forum[redirect])}--><p class="bIsURUTNrYLZ">{lang forum_threads} <!--{echo dnumber($forum[threads])}--> &nbsp; {$langplus[forum_posts]} <!--{echo dnumber($forum[posts])}--></p><!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->
                </a>
                </li>    
                <!--{/if}-->
                <!--{/loop}-->
			</ul>
    </div>
    <!--{/if}-->

	<!--{eval $i = 1;}-->
    <!--{loop $catlist $key $cat}-->    
		<div class="forumbox{if empty($forum_favlist)}{if $i == 1} on{/if}{/if}">
			<ul class="WefwVTOJUU71">
                <!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->
				<li class="wH3cPtGthBRK">
                <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="YLOvsnkGpuDr">
                <!--{if $forum[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $forum['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <h1>{$forum[name]}<!--{if $forum[todayposts] > 0}--><i class="{$forum[todayposts]}">new</i><!--{/if}--></h1>
                <!--{if $forum['redirect']}-->
				<p>{lang url_link}</p>
                <!--{else}-->
                <!--{if $forum[description]}-->
                <p>{echo strip_tags($forum[description])}</p>
                <!--{else}-->
                <!--{if $forum[threads] > 9999 }-->
                <!--{eval $forum[threads] = round($forum[threads] / 10000 , 0).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $forum[posts] > 9999 }-->
                <!--{eval $forum[posts] = round($forum[posts] / 10000 , 0).$langplus[tenthousand];}-->
                <!--{/if}-->                
                <!--{if empty($forum[redirect])}--><p class="bIsURUTNrYLZ">{lang forum_threads} <!--{echo dnumber($forum[threads])}--> &nbsp; {$langplus[forum_posts]} <!--{echo dnumber($forum[posts])}--></p><!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->
                </a>
                    <!--{eval $favsforum = C::t('home_favorite')->fetch_by_id_idtype($forum['fid'],'fid',$_G['uid']);}-->
                    <!--{if $favsforum && $_G['uid']}-->
                    <a class="f3VditYVvX8e" href="home.php?mod=spacecp&ac=favorite&op=delete&favid={$favsforum['favid']}&formhash={FORMHASH}">{$langplus[nofollows_m]}</a>
                    <!--{else}-->
                    <a class="1wd0D5ofiP74" href="home.php?mod=spacecp&ac=favorite&type=forum&id={$forum[fid]}" >{$langplus[follows]}</a>
                    <!--{/if}-->
                </li>
                <!--{hook/index_middle_v2_mobile}-->          
				<!--{eval $i++;}-->
                <!--{/loop}-->
			</ul>
            </div>
            <!--{hook/index_bottom_v2_mobile}-->
	<!--{/loop}-->

    <script type="text/javascript">
        $(document).ready(function(){
            $('.forum_left li').click(function(){
                $('.forum_left li').eq($(this).index()).addClass('on').siblings().removeClass('on');
                $('.forumbox').eq($('.forum_left li').index(this)).addClass('on').siblings().removeClass('on');
            });
        });

        $(document).on('click','.dialog_nbtn',function(){
            <!--{if !$_G[uid]}-->
            popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
            <!--{else}-->
            var obj = $(this);
            $.ajax({
                type:'POST',
                url:obj.attr('href') + '&handlekey=dialog_nbtn&inajax=1',
                data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
                dataType:'xml',
            })
                .success(function(s) {
                    var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
                    var favid = s.lastChild.firstChild.nodeValue.match(/'favid':'(.+?)'/i)[1];
                    var smgjoin = '{$langplus[favsuccess]}';
                    if(smg.indexOf(smgjoin) >= 0) {
                        obj.addClass('dialog_delfav').removeClass('dialog_nbtn sstbg').html('{$langplus[nofollows_m]}');
                        obj.attr('href', 'home.php?mod=spacecp&ac=favorite&op=delete&favid=' + favid + '&formhash={FORMHASH}');
                    }else{
                        popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg+'</dt></div>');
                        setTimeout(function(){
                            $(".dialogbox, #mask").fadeOut();
                        }, 1500);
                    }
                })
                .error(function() {
                    window.location.href = obj.attr('href');
                    popup.close();
                });
            <!--{/if}-->
            return false;
        });

        $(document).on('click','.dialog_delfav',function(){
            var obj = $(this);
            $.ajax({
                type:'POST',
                url:obj.attr('href') + '&handlekey=dialog_delfav&inajax=1',
                data:{'deletesubmit':'true', 'formhash':'{FORMHASH}'},
                dataType:'xml',
            })
                .success(function(s) {
                    var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
                    var tid = s.lastChild.firstChild.nodeValue.match(/'id':'(.+?)'/i)[1];
                    var smgjoin = '{$langplus[oksuccess]}';
                    if(smg.indexOf(smgjoin) >= 0) {
                        obj.addClass('dialog_nbtn sstbg').removeClass('dialog_delfav').html('{$langplus[follows]}');
                        obj.attr('href', 'home.php?mod=spacecp&ac=favorite&type=forum&id=' + tid );
                    }else{
                        popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg+'</dt></div>');
                        setTimeout(function(){
                            $(".dialogbox, #mask").fadeOut();
                        }, 1500);
                    }
                })
                .error(function() {
                    window.location.href = obj.attr('href');
                    popup.close();
                });
            return false;
        });
    </script>
    
</div>    
    <!--{elseif $forumtpl == 2}-->    
	<!--{loop $catlist $key $cat}-->    
		<div class="GD0fnfqbPrto">
        <div class="OsFv1OpGjMGc" href="#sub_forum_$cat[fid]">			
            <h2 class="{if !$_G[setting][mobile][mobileforumview]}yes{else}no{/if}"><span>$cat[name]</span></h2>
		</div>
			<ul id="sub_forum_$cat[fid]" class="4lpnxBAktcZs">
                <!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->
				<li class="oqOTKH2ykhAo">
                <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                <!--{if $forum[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $forum['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <h1>{$forum[name]}<!--{if $forum[todayposts] > 0}--><i title="$forum[todayposts]">new</i><!--{/if}--></h1>
                    <!--{if $forum[threads] > 9999 }-->
                    <!--{eval $forum[threads] = round($forum[threads] / 10000 , 0).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $forum[posts] > 9999 }-->
                    <!--{eval $forum[posts] = round($forum[posts] / 10000 , 0).$langplus[tenthousand];}-->
                    <!--{/if}-->
                <p><span class="4RhCk9h45cgB"></span> $forum[threads] &nbsp; <span class="qwZjl2muVz4e"></span> $forum[posts]</p>
                </a>
                </li>
                <!--{hook/index_middle_v2_mobile}-->          
				<!--{/loop}-->
			</ul>
            </div>
            <!--{hook/index_bottom_v2_mobile}-->
            <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
            <!--{if $adforuma && in_array($cat[fid],$adforumida)}--><!--{$adforuma}--><!--{/if}-->
            <!--{if $adforumb && in_array($cat[fid],$adforumidb)}--><!--{$adforumb}--><!--{/if}-->
            <!--{/if}-->
	<!--{/loop}-->    
    <!--{elseif $forumtpl == 3}-->    
	<!--{loop $catlist $key $cat}-->    
		<div class="GD0fnfqbPrto">
        <div class="OsFv1OpGjMGc" href="#sub_forum_$cat[fid]">			
            <h2 class="{if !$_G[setting][mobile][mobileforumview]}yes{else}no{/if}"><span>$cat[name]</span></h2>
		</div>
			<ul id="sub_forum_$cat[fid]" class="WefwVTOJUU71">
                <!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->
				<li class="wH3cPtGthBRK">
                <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"{if $forum[todayposts] > 0} class="34Q2hO1ZyoI3"{/if}>
                <!--{if $forum[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $forum['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <h1>{$forum[name]}<!--{if $forum[todayposts] > 0}--><i title="{$forum[todayposts]}">new</i><!--{/if}--></h1>
                <!--{if $forum['redirect']}-->
				<p>{lang url_link}</p>
                <!--{else}-->
                <!--{if $forum[description]}-->
                <p>{echo strip_tags($forum[description])}</p>
                <!--{else}-->                
                <!--{if $forum[threads] > 9999 }-->
                <!--{eval $forum[threads] = round($forum[threads] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $forum[posts] > 9999 }-->
                <!--{eval $forum[posts] = round($forum[posts] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->                
                <!--{if empty($forum[redirect])}--><p>{lang forum_threads} <!--{echo dnumber($forum[threads])}--> &nbsp; {$langplus[forum_posts]} <!--{echo dnumber($forum[posts])}--></p><!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->                
                <!--{if $forum[todayposts] > 0}--><em title="{$forum[todayposts]}">{$forum[todayposts]}</em><!--{/if}-->
                </a>
                </li>
                <!--{hook/index_middle_v2_mobile}-->          
				<!--{/loop}-->
			</ul>
            </div>
            <!--{hook/index_bottom_v2_mobile}-->
            <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
            <!--{if $adforuma && in_array($cat[fid],$adforumida)}--><!--{$adforuma}--><!--{/if}-->
            <!--{if $adforumb && in_array($cat[fid],$adforumidb)}--><!--{$adforumb}--><!--{/if}-->
            <!--{/if}-->
	<!--{/loop}-->    
    <!--{elseif $forumtpl == 4}-->
	<!--{loop $catlist $key $cat}-->    
		<div class="GD0fnfqbPrto">
        <div class="OsFv1OpGjMGc" href="#sub_forum_$cat[fid]">			
            <h2 class="{if !$_G[setting][mobile][mobileforumview]}yes{else}no{/if}"><span>$cat[name]</span></h2>
		</div>
			<ul id="sub_forum_$cat[fid]" class="4lpnxBAktcZs">
                <!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->
				<li class="dSLKIlsbZ4k4">
                <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                <!--{if $forum[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $forum['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <h1>{$forum[name]}</h1>
                </a>
                </li>
                <!--{hook/index_middle_v2_mobile}-->          
				<!--{/loop}-->
			</ul>
            </div>
            <!--{hook/index_bottom_v2_mobile}-->
            <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
            <!--{if $adforuma && in_array($cat[fid],$adforumida)}--><!--{$adforuma}--><!--{/if}-->
            <!--{if $adforumb && in_array($cat[fid],$adforumidb)}--><!--{$adforumb}--><!--{/if}-->
            <!--{/if}-->
	<!--{/loop}-->       
    <!--{else}-->
	<!--{loop $catlist $key $cat}-->    
		<div class="GD0fnfqbPrto">
        <div class="OsFv1OpGjMGc" href="#sub_forum_$cat[fid]">			
            <h2 class="{if !$_G[setting][mobile][mobileforumview]}yes{else}no{/if}"><span>$cat[name]</span></h2>
		</div>
			<ul id="sub_forum_$cat[fid]" class="sub_forum{if $cat['forumcolumns']} ptn pbw{/if}">
                <!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->                
                <!--{if $cat['forumcolumns']}-->
                <!--{if $cat['forumcolumns'] < 3}-->
				<li class="oqOTKH2ykhAo">
                <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                <!--{if $forum[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $forum['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <h1>{$forum[name]}<!--{if $forum[todayposts] > 0}--><i title="$forum[todayposts]">new</i><!--{/if}--></h1>
                    <!--{if $forum[threads] > 9999 }-->
                    <!--{eval $forum[threads] = round($forum[threads] / 10000 , 0).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $forum[posts] > 9999 }-->
                    <!--{eval $forum[posts] = round($forum[posts] / 10000 , 0).$langplus[tenthousand];}-->
                    <!--{/if}-->
                <p><span class="4RhCk9h45cgB"></span> $forum[threads] &nbsp; <span class="qwZjl2muVz4e"></span> $forum[posts]</p>
                </a>
                </li>
                <!--{else}-->
				<li class="horizontal{if $cat['forumcolumns'] == 3} threerows{/if}">
                <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                <!--{if $forum[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $forum['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <h1>{$forum[name]}</h1>
                </a>
                </li>
                <!--{/if}-->
                <!--{else}-->                
				<li class="wH3cPtGthBRK">
                <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}"{if $forum[todayposts] > 0} class="34Q2hO1ZyoI3"{/if}>
                <!--{if $forum[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $forum['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <h1>{$forum[name]}<!--{if $forum[todayposts] > 0}--><i title="$forum[todayposts]">new</i><!--{/if}--></h1>
                <!--{if $forum['redirect']}-->
				<p>{lang url_link}</p>
                <!--{else}-->
                <!--{if $forum[description]}-->
                <p>{echo strip_tags($forum[description])}</p>
                <!--{else}-->                
                <!--{if $forum[threads] > 9999 }-->
                <!--{eval $forum[threads] = round($forum[threads] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $forum[posts] > 9999 }-->
                <!--{eval $forum[posts] = round($forum[posts] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->                
                <!--{if empty($forum[redirect])}--><p>{lang forum_threads} <!--{echo dnumber($forum[threads])}--> &nbsp; {$langplus[forum_posts]} <!--{echo dnumber($forum[posts])}--></p><!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->                
                <!--{if $forum[todayposts] > 0}--><em class="{$forum[todayposts]}">{$forum[todayposts]}</em><!--{/if}-->               
                </a>
                </li>
                <!--{/if}-->
                <!--{hook/index_middle_v2_mobile}-->          
				<!--{/loop}-->
			</ul>
            </div>
            <!--{hook/index_bottom_v2_mobile}-->
            <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
            <!--{if $adforuma && in_array($cat[fid],$adforumida)}--><!--{$adforuma}--><!--{/if}-->
            <!--{if $adforumb && in_array($cat[fid],$adforumidb)}--><!--{$adforumb}--><!--{/if}-->
            <!--{/if}-->
	<!--{/loop}-->
    <!--{/if}-->
<!-- main forumlist end -->
<!--{if $closeplugin == 0}-->
<!--{hook/index_middle_mobile}-->
<!--{/if}-->
<!--{if $forumtpl != 1}-->
<script type="text/javascript">
	(function() {
		<!--{if !$_G[setting][mobile][mobileforumview]}-->
		$('.sub_forum').css('display', 'block');
		<!--{else}-->
		$('.sub_forum').css('display', 'none');
		<!--{/if}-->
		$('.subforumshow').on('click', function() {
			var obj = $(this);
			var subobj = $(obj.attr('href'));
			if(subobj.css('display') == 'none') {
				subobj.css('display', 'block');
				obj.find('h2').attr('class', 'yes');
			} else {
				subobj.css('display', 'none');
				obj.find('h2').attr('class', 'no');
			}
		});
	 })();
</script>
<!--{/if}-->
<!--{/if}-->
<!--{template common/footer}-->