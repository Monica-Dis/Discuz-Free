<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang rate_view}<!--{/block}-->
<!--{template common/header}-->
<div class="tip{if !$_G['inajax']} no_ajax pbn{/if}">
        <!--{if $_G['inajax']}-->
        <h3 class="rate_re_tt">
			{lang focus_show}{lang rate}
            <em><a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" >{lang more}</a></em>
		</h3>
        <!--{/if}-->
	<div class="rate_view{if !$_G['inajax']} ratelist_noajxa{/if}">
		<table cellspacing="0" cellpadding="0">
			<!--{if !$_G['inajax']}-->
			<thead>
				<tr>					
					<th>{lang username}</th>
                    <th>{lang credits}</th>
                    <!--{if !$_G['inajax']}-->
					<th>{lang time}</th>
					<th>{lang reason}</th>
                    <!--{/if}-->
				</tr>
			</thead>
            <!--{/if}-->
			<!--{loop $loglist $log}-->
			<tr{if !$_G['inajax']} class="fz5"{/if}>				
				<td><a href="home.php?mod=space&uid=$log[uid]">$log[username]</a></td>
                <td>{$_G['setting']['extcredits'][$log[extcredits]][title]} $log[score] {$_G['setting']['extcredits'][$log[extcredits]][unit]}</td>
                <!--{if !$_G['inajax']}-->
				<td>$log[dateline]</td>
				<td>$log[reason]</td>
                <!--{/if}-->
			</tr>
			<!--{/loop}-->
		</table>
	</div>    
    <div class="rate_view_buttom">
	{lang total}:&nbsp;
	<!--{loop $logcount $id $count}-->
	&nbsp;{$_G['setting']['extcredits'][$id][title]} <!--{if $count>0}-->+<!--{/if}-->$count {$_G['setting']['extcredits'][$id][unit]}
	<!--{/loop}-->
	</div>
</div>
<!--{template common/footer}-->