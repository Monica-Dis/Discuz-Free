<?php echo 'From: DisM.taobao.com';exit;?>
<div class="sqK9gG26iUGb">{$langplus[tplnofunction]}</div>
<!--{eval $nofooter = true;}-->