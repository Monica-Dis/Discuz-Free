<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['forum_threadcount']}-->
<!--{template forum/displayorder}-->
<ul id="alist" class="HwKFWtPXAVEl">
    <!--{eval $ad = 1;}-->
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
    {eval continue;}
    <!--{/if}-->
    <!--{if $thread['displayorder'] > $threaddisplayorder}-->
    <!--{else}-->
    <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
    {eval $displayorder_thread = 1;}
    <!--{/if}-->
    <!--{if $thread['moved']}-->
    <!--{eval $thread[tid]=$thread[closed];}-->
    <!--{/if}-->
    <!--{hook/forumdisplay_middle_v2_mobile}-->
    <!--{if $page == 1}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adforumdisplaya && in_array($_G['fid'],(array)unserialize($adforumdisplayida)) && $ad == $adforumdisplaytha}--><!--{$adforumdisplaya}--><!--{/if}-->
    <!--{if $adforumdisplayb && in_array($_G['fid'],(array)unserialize($adforumdisplayidb)) && $ad == $adforumdisplaythb}--><!--{$adforumdisplayb}--><!--{/if}-->
    <!--{if $adforumdisplayc && in_array($_G['fid'],(array)unserialize($adforumdisplayidc)) && $ad == $adforumdisplaythc}--><!--{$adforumdisplayc}--><!--{/if}-->
    <!--{if $adforumdisplayd && in_array($_G['fid'],(array)unserialize($adforumdisplayidd)) && $ad == $adforumdisplaythd}--><!--{$adforumdisplayd}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{eval $msgnumber = 90; $imgnumber = 3;}-->
    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/threadlist.php');}-->
    <!--{if $specialplugin == 0}--><!--{hook/forumdisplay_thread_mobile $key}--><!--{/if}-->
    <li class="glWm8KGGo5r7">
        <div class="EpRp4gnHNBzx">
            <!--{if $thread['authorid'] && $thread['author']}-->
            <a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="x9hHSPQjdnYg"><img src="<!--{avatar($thread[authorid],middle,true)}-->" /></a>
            <!--{else}-->
            <a href="javascript:;" class="x9hHSPQjdnYg"><img src="<!--{avatar($thread[authorid],middle,true)}-->" /></a>
            <!--{/if}-->
            <span class="lhcsTc3xRkO8">
                <!--{if $thread['authorid'] && $thread['author']}-->
                <a href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
                <!--{else}-->
                <a href="javascript:;">$_G[setting][anonymoustext]</a>
                <!--{/if}-->
            </span>
            <!--{if $leveltype == 1}-->
            <!--{if $_G['cache']['usergroups'][$thread['groupid']][stars] > 0 }-->
            <i class="LgNEwtq1jDD7">Lv.{$_G['cache']['usergroups'][$thread['groupid']][stars]}</i>
            <!--{/if}-->
            <!--{elseif $leveltype == 2}-->
            <!--{if $_G['cache']['usergroups'][$thread['groupid']][stars] > 0 }-->
            <i class="P50uNzFJnLxa"{if $_G['cache']['usergroups'][$thread['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$thread['groupid']]['color']};"{/if}>Lv.{$_G['cache']['usergroups'][$thread['groupid']][stars]}</i>
            <!--{/if}-->
            <!--{else}-->
            <i class="P50uNzFJnLxa"{if $_G['cache']['usergroups'][$thread['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$thread['groupid']]['color']};"{/if}>{$_G['cache']['usergroups'][$thread['groupid']]['grouptitle']}</i>
            <!--{/if}-->
            <span class="99u2LxYcMOhO">
                    {$thread[dateline]} <span class="RB4F49dgNi61">/</span>
                <!--{if $thread[replies]}-->
                <!--{if $thread[replies] > 9999 }-->
                <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $thread['isgroup'] != 1}-->
                <!--{if $thread[views] > 9999 }-->
                <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $groupnames[$thread[tid]][views] > 9999 }-->
                <!--{eval $groupnames[$thread[tid]][views] = round($groupnames[$thread[tid]][views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}--><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->{$langplus[view]}<!--{/if}-->
            </span>
        </div>
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="yUloUBxjglb3">
            <h1>
                <!--{if $thread['displayorder'] > 0}-->
                <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;
                <!--{/if}-->
                <!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}-->
            </h1>
            <!--{if $thread['msg']}--><p>{$thread['msg']}</p><!--{/if}-->
            <!--{if $thread['thumb']}-->
            <!--{eval $picnumber = count($thread['thumb']); }-->
            <!--{if $picnumber == 1}-->
            <div class="eV6QZvlP57vk">
                <!--{loop $thread['thumb'] $attach}-->
                <!--{eval $imagethumb = getforumimg($attach['aid'], 0, 360, 0); }-->
                <img src="$imagethumb" />
                <!--{/loop}-->
            </div>
            <!--{elseif $picnumber == 2}-->
            <div class="3oUBU5xoDoYu">
                <!--{loop $thread['thumb'] $attach}-->
                <!--{eval $imagethumb = getforumimg($attach['aid'], 0, 300, 180); }-->
                <div><img src="$imagethumb" /></div>
                <!--{/loop}-->
            </div>
            <!--{else}-->
            <div class="UjUdLLZpI86a">
                <!--{loop $thread['thumb'] $attach}-->
                <!--{eval $imagethumb = getforumimg($attach['aid'], 0, 200, 180); }-->
                <div><img src="$imagethumb" /></div>
                <!--{/loop}-->
            </div>
            <!--{/if}-->
            <!--{/if}-->
        </a>
        <div class="hNOK3poJcpFf">
            <!--{if $thread['special'] == 1}-->
            <span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_poll}</a></span>
            <!--{elseif $thread['special'] == 2}-->
            <span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_trade}</a></span>
            <!--{elseif $thread['special'] == 3}-->
            <span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_reward}</a></span>
            <!--{elseif $thread['special'] == 4}-->
            <span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_activity}</a></span>
            <!--{elseif $thread['special'] == 5}-->
            <span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang thread_debate}</a></span>
            <!--{/if}-->
            <!--{if $_G['forum']['threadtypes']['types'][$thread['typeid']]}-->
            <span class="WAO1ETmvH49Y"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$thread[typeid]">{echo strip_tags($_G['forum']['threadtypes']['types'][$thread['typeid']])}</a></span>
            <!--{/if}-->
            <!--{if $_G['forum']['threadsorts']['types'][$thread['sortid']]}-->
            <span class="WAO1ETmvH49Y"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$thread[sortid]">{echo strip_tags($_G['forum']['threadsorts']['types'][$thread['sortid']])}</a></span>
            <!--{/if}-->
            <!--{if $thread[icon] >= 0}-->
            <span class="ZUp4byFwR1BK">{$_G[cache][stamps][$thread[icon]][text]}</span>
            <!--{else}-->
            <!--{if $thread[heatlevel]}-->
            <span class="Z1K9j6zHkkNq">{lang order_heats}</span>
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $thread['digest'] > 0}-->
            <span class="GR92yicG3zyZ">$langplus[digest]</span>
            <!--{/if}-->
            <!--{if $_G['setting']['recommendthread']['status']}-->
            <!--{if $thread[recommends] > 0}--><i class="Wh21Y2pBzti3"></i><!--{else}--><i class="UKfOChqXROBD"></i><!--{/if}-->
            <!--{else}-->
            <!--{if $thread[favtimes] > 0}--><i class="c5jXKWHqTOsX"></i><!--{else}--><i class="a4TcRfVF4aiG"></i><!--{/if}-->
            <!--{/if}-->
            <!--{if $thread['rate'] > 0}--><i class="ih2GBIpmzu4I"></i><!--{/if}-->
        </div>
    </li>
    <!--{/if}-->
    <!--{eval $ad++;}-->
    <!--{/loop}-->
</ul>
<!--{else}-->
<div class="sqK9gG26iUGb">{lang forum_nothreads}</div>
<!--{/if}-->