<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">{$_G['forum']['name']}</a><!--{/block}--> 
<!--{template common/header}-->
<div class="pt"><a href="javascript:history.back();">{lang back}</a><span>&lt;</span></div>
<div class="bw">
<div class="r-block">{lang youneedpay} $paycredits {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['unit']}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]]['title']} {lang onlyintoforum}</div>
  <form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=paysubmit">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <div class="hm">
    <button class="button2" type="submit" name="loginsubmit" value="true">{lang confirmyourpay}</button>
    <button class="button2" type="button" onclick="history.go(-1)">{lang cancel}</button>
    </div>
  </form>
</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}--> 
