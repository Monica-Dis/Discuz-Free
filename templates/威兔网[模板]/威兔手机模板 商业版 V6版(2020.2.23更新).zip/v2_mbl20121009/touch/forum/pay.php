<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang attachment_buy}<!--{/block}-->
<!--{template common/header}-->
<div class="ajaxpop{if !$_G['inajax']} no_ajax{/if}">
<form id="payform" method="post" autocomplete="off" action="forum.php?mod=misc&action=pay&paysubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}" >       
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
		<div class="paylist_pay">
			<table cellspacing="0" cellpadding="0">
				<tr>
					<td>{lang author}:</td>
					<td><a href="home.php?mod=space&uid=$thread[authorid]&do=profile" target="_blank">$thread[author]</a></td>
				</tr>
				<tr>
					<td>{lang price}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}):</td>
					<td>$thread[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</td>
				</tr>
				<tr>
					<td>{lang pay_author_income}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}):</td>
					<td>$thread[netprice] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</td>
				</tr>
				<tr>
					<td>{lang pay_balance}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}):</td>
					<td>$balance {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</td>
				</tr>
			</table>            
		</div>
        <div class="hm tb"><button type="submit" name="paysubmit" class="formdialog button2{if !$_G['inajax']} brno{/if}" value="true">{lang pay}</button></div>
</form>
</div>
<!--{template common/footer}-->