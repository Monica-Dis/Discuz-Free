<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="{if $_GET[action] == 'newthread'}forum.php?mod=forumdisplay&fid=$_G[fid]{else}forum.php?mod=redirect&goto=findpost&ptid=$_G[tid]&pid=$pid{/if}"><!--{if $_GET[action] == 'edit'}-->{lang edit}<!--{elseif $_GET['action'] == 'reply'}--><!--{if !empty($_GET['addtrade'])}-->{lang trade_add_post}<!--{else}-->{lang join_thread}<!--{/if}--><!--{else}-->{$_G['forum']['name']}<!--{/if}--></a><!--{/block}-->
<!--{template common/header}-->
<!--{if in_array($_G['fid'],(array)unserialize($postsfunction))}-->
<!--{template forum/post_b}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($postsfunctionass))}-->
<!--{template forum/post_c}-->
<!--{else}-->
<!--{template forum/post_a}-->
<!--{/if}-->
<!--{block footerplus}--><div class="a87wGthEpSmH"></div><!--{/block}-->
<!--{eval $nofooter = true; $nosopenmenu = true;}-->
<!--{template common/footer}-->