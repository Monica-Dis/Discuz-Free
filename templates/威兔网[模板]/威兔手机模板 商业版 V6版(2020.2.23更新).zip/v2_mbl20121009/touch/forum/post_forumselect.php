<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval dheader("location: forum.php?mod=postselect");exit; }-->
<!--{if $_GET['mod'] == 'zhimakaimenba' && $_G[uid]}-->
<!--{block header_name}-->{lang send_posts}<!--{/block}-->
<!--{template common/header}-->
<div class="C37wrkRGIt2N">
	<ul>
		<!--{eval $i = 1;}-->
		<!--{loop $_G['cache']['forums'] $forum}-->
		<!--{if $forum[type]=='group' && $forum[status]}-->
		<li{if $i == 1} class="Yfm1QC5IeoTk"{/if}>{$forum[name]}</li>
		<!--{eval $i++;}-->
		<!--{/if}-->
		<!--{/loop}-->
	</ul>
</div>
<div class="9rz3f9gf6SIc">
	<!--{eval $i = 1;}-->
	<!--{loop $_G['cache']['forums'] $forum}-->
	<!--{if $forum[type]=='group' && $forum[status]}-->
	<div class="forumbox{if $i == 1} on{/if}">
		<ul class="WefwVTOJUU71">
			<!--{loop $_G['cache']['forums'] $forums}-->
			<!--{if $forum[fid]==$forums[fup] && $forums[status]}-->
			<li class="wH3cPtGthBRK">
				<a {if !$_G[uid]}href="javascript:;" class="ViXaVIRbrz5Y" {else}href="forum.php?mod=post&action=newthread&fid=$forums[fid]"{/if}>
					<!--{eval $forumicon = DB::result_first("SELECT icon FROM ".DB::table('forum_forumfield')." WHERE fid = '$forums[fid]'");}-->
					<!--{if $forumicon}--><img src="data/attachment/common/{$forumicon}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $forum[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
					<span class="i0a6HFurbhHA">{lang m_new_t}</span>
					<h1 style="margin-top: 13px;">{$forums[name]}</h1>
				</a>
			</li>
			<!--{/if}-->
			<!--{/loop}-->
		</ul>
	</div>
	<!--{eval $i++;}-->
	<!--{/if}-->
	<!--{/loop}-->
	<script type="text/javascript">
		$(document).ready(function(){
			$('.forum_left li').click(function(){
				$('.forum_left li').eq($(this).index()).addClass('on').siblings().removeClass('on');
				$('.forumbox').eq($('.forum_left li').index(this)).addClass('on').siblings().removeClass('on');
			});
			<!--{if !$_G[uid]}-->
			$('.nopost').click(function(){
				popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
			});
			<!--{/if}-->
		})
	</script>
</div>
<!--{template common/footer}-->
<!--{/if}-->