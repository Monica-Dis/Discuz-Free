<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $brtnav == 1 && !$noheader && $page > 1}-->
<div class="4ptxL1L724dB">
    <!--{if $_G['forum']['status'] == 3}-->
    <a href="forum.php?forumlist=1">{$langplus[bbs]}</a>$navigation
    <!--{else}-->
    <a href="forum.php?forumlist=1">{$langplus[bbs]}</a><!--{if $_G['forum']['type'] == 'forum'}--><span>&gt;</span><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">$_G['forum']['name']</a><!--{else}--><span>&gt;</span><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fup']}">$_G['cache']['forums'][$fup]['name']</a><span>&gt;</span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">{$_G['forum']['name']}</a><!--{/if}-->
    <!--{/if}-->
</div>
<!--{/if}-->
<!--{if $_G[forum_thread][special] != 3 && $_G[forum_thread][special] != 2}-->
<div class="thname{if $viewtitletype == 1} vatitle{/if}" id="myshares"><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]">$_G[forum_thread][subject]</a><!--{if $_G['forum_thread'][displayorder] == -2}--> <span class="evXx4HZDPWdN">({lang moderating})</span><!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span class="evXx4HZDPWdN">({lang have_ignored})</span><!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span class="evXx4HZDPWdN">({lang draft})</span><!--{/if}--></div>
<!--{/if}-->
<!-- main postlist start -->
<div id="alist" class="7rbnzEt1Q9po">
    <!--{eval $postcount = 0;}-->
    <!--{loop $postlist $post}-->
    <!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
    <!--{hook/viewthread_posttop_mobile $postcount}-->
    <div class="plc{if $post['first']} bbno{/if}" id="pid$post[pid]">
        <!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
        <div class="iRJHMF5gGld9"><img src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" /></div>
        <!--{/if}-->
        <!--{if $post['warned']}--><i class="9m86AeynGwRj">{lang warn_get}</i><!--{/if}-->
        <div class="display pi{if $viewheight}{if $post['first']} viewheight{/if}{/if}">
            <!--{if ($_G[forum_thread][special] == 3 || $_G[forum_thread][special] == 2) && $post['first']}--><!--{else}-->
            <div class="view_authi{if $post[authorid] != $_G[uid] && $post['first']} view_follow{/if}">
                <a href="{if $post['authorid'] && $post['username'] && !$post['anonymous']}home.php?mod=space&uid=$post[authorid]&do=profile{else}{if $_G['forum']['ismoderator']}home.php?mod=space&uid=$post[authorid]&do=profile{else}javascript:;{/if}{/if}" class="UoRZiAghxSa8"><img src="{if !$post['authorid'] || $post['anonymous']}{avatar(0, middle, true)}{else}{avatar($post[authorid], middle, true)}{/if}" /></a>
                <p>
                    <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
                    <span class="4sFYn7oKrhV0">
                        <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                        <a href="home.php?mod=space&uid=$post[authorid]&do=profile" >$post[author]</a>
                        <!--{else}-->
                        <!--{if !$post['authorid']}-->
                        <a href="javascript:;">{lang guest}</a>
                        <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                        <!--{if $_G['forum']['ismoderator']}-->
                        <a href="home.php?mod=space&uid=$post[authorid]&do=profile">{lang anonymous}</a>
                        <!--{else}-->
                        <a href="javascript:;">{lang anonymous}</a>
                        <!--{/if}-->
                        <!--{else}-->
                        <a href="javascript:;">$post[author]</a> {lang member_deleted}
                        <!--{/if}-->
                        <!--{/if}-->
                    </span>
                    <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                    <!--{if $post[gender] == 0}-->
                    <!--{elseif $post[gender] == 1}-->
                    <i class="gender gender_{$post[gender]}"></i>
                    <!--{elseif $post[gender] == 2}-->
                    <i class="gender gender_{$post[gender]}"></i>
                    <!--{/if}-->
                    <!--{if !$post['authorid']}--><!--{else}-->
                    <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
                    <!--{if $_self }-->
                    <i class="WxLbkDtVnoGF">{lang thread_author}</i>
                    <!--{else}-->
                    <!--{if $post['authorid'] && $post['username'] && !$post['anonymous'] || $_G['forum']['ismoderator']}-->
                    <!--{if $leveltype == 1}-->
                    <!--{if $_G['cache']['usergroups'][$post['groupid']][stars] > 0 }-->
                    <i class="LgNEwtq1jDD7">Lv.{$_G['cache']['usergroups'][$post['groupid']][stars]}</i>
                    <!--{/if}-->
                    <!--{elseif $leveltype == 2}-->
                    <!--{if $_G['cache']['usergroups'][$post['groupid']][stars] > 0 }-->
                    <i class="P50uNzFJnLxa"{if $_G['cache']['usergroups'][$thread['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$post['groupid']]['color']};"{/if}>Lv.{$_G['cache']['usergroups'][$post['groupid']][stars]}</i>
                    <!--{/if}-->
                    <!--{else}-->
                    <i class="P50uNzFJnLxa"{if $_G['cache']['usergroups'][$post['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$post['groupid']]['color']};"{/if}>{$_G['cache']['usergroups'][$post['groupid']]['grouptitle']}</i>
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{hook/viewthread_articlefrom_v2_mobile $postcount}-->
                    <!--{if !$post['first'] && $post['rewardfloor']}-->
                    <i class="7eunR4IuzjCQ">
                        <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1">{lang rushreply_hit}</a>
                    </i>
                    <!--{/if}-->
                    <!--{if !$post['first']}-->
                    <em class="4c9hcNeRm3xo">
                        <!--{if $supportposit == 1 && (!$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote']))}-->
                        <!--{if isset($post[isstick])}-->
                        <i class="evXx4HZDPWdN">{$langplus[top]}</i>
                        <!--{elseif $post[number] == -1}-->
                        <i class="evXx4HZDPWdN">{lang recommend}</i>
                        <!--{/if}-->
                        <!--{if $post[postreview][support] > 9999 }-->
                        <!--{eval $post[postreview][support] = round($post[postreview][support] / 10000 , 1).$langplus[tenthousand];}-->
                        <!--{/if}-->
                        <span class="Oij7aMlDpyDg"{if !$post[postreview][support]} style="display:none;"{/if}>{$post[postreview][support]}</span>
                        <a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" class="J9xlETRLPlFr"><i class="NjmDx3gkHCuh"></i></a>
                        <!--{else}-->
                        <!--{if $supportposit == 1 && $_G['forum_thread']['special'] == 5}-->
                        <!--{if $post[stand]}-->
                        <span class="Oij7aMlDpyDg"{if !$post[voters]} style="display:none;"{/if}>{$post[voters]}</span>
                        <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]" class="J9xlETRLPlFr"><i class="NjmDx3gkHCuh"></i></a>
                        <!--{/if}-->
                        <!--{else}-->
                        <!--{if isset($post[isstick])}-->
                        <i class="evXx4HZDPWdN">{$langplus[top]}</i> {lang from} {$post[number]}{$postnostick}
                        <!--{elseif $post[number] == -1}-->
                        <i class="evXx4HZDPWdN">{lang recommend}</i>
                        <!--{else}-->
                        <!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}-->
                        <!--{/if}-->
                        <!--{/if}-->
                        <!--{/if}-->
                    </em>
                    <!--{/if}-->
                </p>
                <span class="e3vXzBhozeun"><!--{if $viewstatus == 1}-->{echo dgmdate($post['dbdateline'], 'u')}<!--{if $post['first'] && $post[customstatus]}--> - $post[customstatus]<!--{/if}--><!--{else}-->$post[dateline]<!--{/if}--></span>
                <!--{if $post[authorid] != $_G[uid] && $post['first']}-->
                <!--{if helper_access::check_module('follow')}-->
                <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$post[authorid]" class="aPwQJEMwqFco">{$langplus[follows]}</a>
                <!--{else}-->
                <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$post[authorid]&handlekey=addfriendhk_{$post[authorid]}" class="dialog_ibtn{if $_G['uid']} dialog{/if}">{$langplus[follows]}</a>
                <!--{/if}-->
                <!--{/if}-->
            </div>
            <!--{/if}-->
            <!--{if !$post['first'] && $viewposttype == 1}--><div class="4ING6lo8uynE"><!--{/if}-->
            <!--{hook/viewthread_posttop_v2_mobile $postcount}-->
            <!--{if $post['first']}-->
            <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
            <!--{if $adviewthreada && in_array($_G['fid'],(array)unserialize($adviewthreadida))}--><!--{$adviewthreada}--><!--{/if}-->
            <!--{if $adviewthreadb && in_array($_G['fid'],(array)unserialize($adviewthreadidb))}--><!--{$adviewthreadb}--><!--{/if}-->
            <!--{if $adviewthreadc && in_array($_G['fid'],(array)unserialize($adviewthreadidc))}--><!--{$adviewthreadc}--><!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
            <div class="g0sF2qOc8TUw">
                <!--{if $rushreply && $post['first']}-->
                <div class="QpgKgXqXRZXD">
                    <div class="rushreply_titls{if !$rushresult['timer']} rushreply_over{/if} mbm">
                        <!--{if $rushresult['timer']}-->{lang rushreply}{lang rewarding}<!--{else}-->{lang rushreply}{lang over}<!--{/if}-->
                        <!--{if !$_GET['checkrush']}-->
                        <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1">{lang rushreply_view}</a>
                        <!--{/if}-->
                    </div>
                    <!--{if $rushresult['timertype'] == 'end' || !$rushresult['timer']}-->
                    <!--{if $rushresult[stopfloor]}-->
                    <p>{$langplus[rushreplyend]} : {$rushresult[stopfloor]}</p>
                    <!--{/if}-->
                    <!--{if $rushresult[rewardfloor]}-->
                    <!--{eval $rushresult[rewardfloor] = str_replace(',',', ',$rushresult[rewardfloor])}-->
                    <p>{lang thread_rushreply_floor} : {$rushresult[rewardfloor]}</p>
                    <!--{/if}-->
                    <!--{if $rushresult[creditlimit]}-->
                    <p>{$langplus[rushreplylimit]} : {$rushresult[creditlimit_title]}{$langplus[greaterthan]} {$rushresult[creditlimit]} {$langplus[participate]}{lang rushreply}{lang activity}</p>
                    <!--{/if}-->
                    <!--{else}-->
                    <p>{lang rushreply}{lang header_start}{lang time} {$rushresult[starttimefrom]}</p>
                    <!--{/if}-->
                </div>
                <!--{/if}-->

                <!--{if $_G['forum_thread']['replycredit'] > 0 }-->
                <div class="QpgKgXqXRZXD">
                    <div class="QpsSa9KCK8wO">{lang thread_replycredit_tips1} {lang thread_replycredit_tips2}</div>
                    <p>{$langplus[replycredit_rate]} <!--{if $_G['forum_thread']['replycredit_rule'][random] > 0}-->{$_G[forum_thread][replycredit_rule][random]}<!--{else}-->100<!--{/if}-->%</p>
                </div>
                <!--{/if}-->

                <!--{if !$post['first'] && !empty($post[subject])}-->
                <h3 class="Ph2JLDJkzeSK">$post[subject]</h3>
                <!--{/if}-->
                <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                <div class="0AAUfPW81H3Y">{lang message_banned}</div>
                <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                <div class="0AAUfPW81H3Y">{lang message_single_banned}</div>
                <!--{elseif $needhiddenreply}-->
                <div class="0AAUfPW81H3Y">{lang message_ishidden_hiddenreplies}</div>
                <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
                <!--{template forum/viewthread_pay}-->
                <!--{elseif $_G['forum_discuzcode']['passwordlock'][$post[pid]]}-->
                <div class="LnNTiGK7Shwz">{$langplus[message_password]} <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&mobile=no">{lang nomobiletype}</a></div>
                <!--{else}-->

                <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                <div class="0AAUfPW81H3Y">{lang admin_message_banned}</div>
                <!--{elseif $post['status'] & 1}-->
                <div class="0AAUfPW81H3Y">{lang admin_message_single_banned}</div>
                <!--{/if}-->
                <!--{if $post['first']}-->
                <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                <div class="LnNTiGK7Shwz"><em class="99u2LxYcMOhO"><a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" class="F3pveqiOE331" >{lang pay_view}</a></em>{lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong></div>
                <!--{/if}-->
                <!--{/if}-->

                <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                <!--{if $threadsortshow['typetemplate']}-->
                $threadsortshow[typetemplate]
                <!--{elseif $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                <div class="LnNTiGK7Shwz">{lang has_expired}</div>
                <!--{else}-->
                <div class="Kdhgd1UShrXN">
                    <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                    <!--{loop $threadsortshow['optionlist'] $option}-->
                    <!--{if $option['type'] != 'info'}-->
                    $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="RDmGsXxMXFbB">--</span><!--{/if}--><br />
                    <!--{/if}-->
                    <!--{/loop}-->
                </div>
                <!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->

                <!--{if $post['first']}-->
                <!--{if !$_G[forum_thread][special]}-->
                $post[message]
                <!--{elseif $_G[forum_thread][special] == 1}-->
                <!--{template forum/viewthread_poll}-->
                <!--{elseif $_G[forum_thread][special] == 2}-->
                <!--{template forum/viewthread_trade}-->
                <!--{elseif $_G[forum_thread][special] == 3}-->
                <!--{template forum/viewthread_reward}-->
                <!--{elseif $_G[forum_thread][special] == 4}-->
                <!--{template forum/viewthread_activity}-->
                <!--{elseif $_G[forum_thread][special] == 5}-->
                <!--{template forum/viewthread_debate}-->
                <!--{elseif $threadplughtml}-->
                $threadplughtml
                $post[message]
                <!--{else}-->
                $post[message]
                <!--{/if}-->
                <!--{else}-->
                $post[message]
                <!--{/if}-->
                <!--{/if}-->
            </div>
            <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
            <!--{if $post['attachment']}-->
            <div class="QJgLkByST6uL">
                {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
            </div>
            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
            <div class="6xZuEZtiCCah">
                <!--{if $post['imagelist']}-->
                <!--{if count($post['imagelist']) == 1}-->
                {echo showattach($post, 1)}
                <!--{else}-->
                {echo showattach($post, 1)}
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $post['attachlist']}-->
                {echo showattach($post)}
                <!--{/if}-->
            </div>
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $post['first'] && ($ratetype == 1 || $ratetype == 2)}-->
            <div class="29uIwq546Ihr">
                <a {if $_G[uid]}href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]&reward=1"{else}href="javascript:;" onclick="popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login')"{/if} class="reward_btn{if $_G[uid]} dialog{/if}">{$langplus[viewreward]}</a>
                <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
                <!--{if count($postlist[$post[pid]][totalrate]) > 0}--><div class="DrKRup0iElRr">{$langplus[total]} <span><!--{echo count($postlist[$post[pid]][totalrate]);}--></span> {$langplus[rewardeds]}</div><!--{/if}-->
                <!--{if $post['ratelog'] && $ratetype == 2}-->
                <div class="unFhihS1Jxf2">
                    <a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]&infloat=yes">
                        <!--{eval $p = 1;}-->
                        <!--{loop $post['ratelog'] $uid $ratelog}-->
                        <!--{if $p < 12}-->
                        <img src="{avatar($uid, small, true)}" />
                        <!--{elseif $p == 12}-->
                        <span><i class="NiEHVRiWt8fE"></i></span>
                        <!--{/if}-->
                        <!--{eval $p++;}-->
                        <!--{/loop}-->
                    </a>
                </div>
                <!--{/if}-->
                <!--{/if}-->
            </div>
            <!--{/if}-->
            <!--{if $post['first'] && ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
            <div class="fqhbPzPpqvLu">
                <!--{if $post[tags]}-->
                <!--{eval $tagi = 0;}-->
                <!--{loop $post[tags] $var}-->
                <!--{if $tagi}--> , <!--{/if}--><a href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
                <!--{eval $tagi++;}-->
                <!--{/loop}-->
                <!--{/if}-->
            </div>
            <!--{/if}-->
            <!--{if $_GET['from'] != 'preview' && $_G['setting']['commentnumber'] && !empty($comments[$post[pid]])}-->
            <div class="UOWwQ5apC2wM">
                <div class="jyPNQI3eTGY0">{$langplus[webcomments]}</div>
                <ul>
                    <!--{eval $c = 1;}-->
                    <!--{loop $comments[$post[pid]] $comment}-->
                    <!--{if $c < 6}-->
                    <li>
                        <a href="home.php?mod=space&uid=$comment[authorid]&do=profile" class="x9hHSPQjdnYg">$comment[avatar]</a>
                        <div class="qDv3ZWfIoG06">
                            <p>
                                <!--{if $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
                                <a href="forum.php?mod=topicadmin&action=delcomment&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$comment[id]}" class="8oVKS8OK3xkQ"><i class="aPyV086aHjq3"></i></a>
                                <!--{/if}-->
                                <em><!--{date($comment[dateline], 'u')}--></em>
                                <!--{if $comment['authorid']}-->
                                <span><a href="home.php?mod=space&uid=$comment[authorid]&do=profile" >$comment[author]</a></span>
                                <!--{else}-->
                                <span>{lang guest}</span>
                                <!--{/if}-->
                            </p>
                            <div class="6ViQjaESBbyO">{$comment[comment]}</div>
                        </div>
                    </li>
                    <!--{/if}-->
                    <!--{eval $c++;}-->
                    <!--{/loop}-->
                </ul>
            </div>
            <!--{/if}-->

            <!--{hook/viewthread_postbottom_v2_mobile $postcount}-->
            <!--{hook/viewthread_postbottom_mobile $postcount}-->

            <!--{if $post[first] && $signaturetype == 1}-->
            <!--{if $post['signature'] && ($_G['setting']['bannedmessages'] & 4 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)))}-->
            <div class="dLVfpJyTOsFx"><span class="JRJ8z2hwtn8Y">{$langplus[signature]}</span>{lang member_signature_banned}</div>
            <!--{elseif $post['signature'] && !$post['anonymous'] && $showsignatures}-->
            <div class="dLVfpJyTOsFx"><span class="JRJ8z2hwtn8Y">{$langplus[signature]}</span>$post[signature]</div>
            <!--{elseif !$post['anonymous'] && $showsignatures && $_G['setting']['globalsightml']}-->
            <div class="dLVfpJyTOsFx"><span class="JRJ8z2hwtn8Y">{$langplus[signature]}</span>$_G['setting']['globalsightml']</div>
            <!--{/if}-->
            <!--{elseif $signaturetype == 2}-->
            <!--{if $post['signature'] && ($_G['setting']['bannedmessages'] & 4 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)))}-->
            <div class="dLVfpJyTOsFx"><span class="JRJ8z2hwtn8Y">{$langplus[signature]}</span>{lang member_signature_banned}</div>
            <!--{elseif $post['signature'] && !$post['anonymous'] && $showsignatures}-->
            <div class="dLVfpJyTOsFx"><span class="JRJ8z2hwtn8Y">{$langplus[signature]}</span>$post[signature]</div>
            <!--{elseif !$post['anonymous'] && $showsignatures && $_G['setting']['globalsightml']}-->
            <div class="dLVfpJyTOsFx"><span class="JRJ8z2hwtn8Y">{$langplus[signature]}</span>$_G['setting']['globalsightml']</div>
            <!--{/if}-->
            <!--{/if}-->
            <!--{if !$post['first'] && $viewposttype == 1}--></div><!--{/if}-->
            <!--{if $viewheight}--><!--{if $post['first']}--><div class="ecQ1qz6BxLwl"><a href="javascript:;" >{$langplus[startreading]}</a></div><!--{/if}--><!--{/if}-->
        </div>
        <div class="viewpost{if !$post['first'] && $viewposttype == 1} posttype{if $menusposit == 1} posttype_viewpost{/if}{/if}{if $post['first']} mbn{/if}">
            <!--{if $_G['forum']['ismoderator']}--><span href="#moption_$post[pid]" class="sfIpusg5EDJA"><i class="hv0mRIARmq4b"></i></span><!--{/if}-->
            <!--{if $post['invisible'] == 0}-->
            <!--{if $_G[uid]}-->
            <!--{if ($_G['group']['raterange'] && $post['authorid']) || ($allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])) || ((($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])) || ($post['authorid'] != $_G['uid'])}--><a href="javascript:;" class="hbbBwzmEHpvK"><i class="NiEHVRiWt8fE"></i></a><!--{/if}-->
            <!--{/if}-->
            <!--{if $post['first']}-->
            <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&page=$page" ><i class="qwZjl2muVz4e"></i></a>
            <!--{else}-->
            <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&page=$page" ><i class="qwZjl2muVz4e"></i></a>
            <!--{/if}-->
            <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
            <a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]&infloat=yes" class="F3pveqiOE331"><i class="ih2GBIpmzu4I"></i></a>
            <!--{/if}-->
            <!--{if $supportposit == 0 && (!$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote']))}-->
            <!--{if $post[postreview][support] > 9999 }-->
            <!--{eval $post[postreview][support] = round($post[postreview][support] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <span class="Oij7aMlDpyDg"{if !$post[postreview][support]} style="display:none;"{/if}>{$post[postreview][support]}</span>
            <a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" class="J9xlETRLPlFr"><i class="NjmDx3gkHCuh"></i></a>
            <!--{/if}-->
            <!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
            <a href="forum.php?mod=misc&action=bestanswer&tid=$_G[tid]&pid=$post['pid']&from=$_GET[from]&bestanswersubmit=yes" class="WDj46PgmBLac">{$langplus[setbestanswer]}</a>
            <!--{/if}-->
            <!--{if !$post[first] && $_G['forum_thread']['special'] == 5}-->
            <!--{if $post[stand] == 1}-->
            <a href="javascript:;" class="rewardset stand_{$post[stand]}" >{lang debate_square}</a>
            <!--{elseif $post[stand] == 2}-->
            <a href="javascript:;" class="rewardset stand_{$post[stand]}" >{lang debate_opponent}</a>
            <!--{else}-->
            <a href="javascript:;" class="bS62OcsZu1hX" >{lang debate_neutral}</a>
            <!--{/if}-->
            <!--{if $supportposit == 0 && $post[stand]}-->
            <span class="Oij7aMlDpyDg"{if !$post[voters]} style="display:none;"{/if}>{$post[voters]}</span>
            <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]" class="J9xlETRLPlFr"><i class="NjmDx3gkHCuh"></i></a>
            <!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $post['first']}-->
            <!--{if $_G[forum_thread][views] > 9999 }-->
            <!--{eval $_G[forum_thread][views] = round($_G[forum_thread][views] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{if $_G[forum_thread][views]}--><span class="ySnKavPCx3Hc">$_G[forum_thread][views]{$langplus[view]}</span><!--{/if}-->
            <!--{/if}-->
        </div>
        <!--{if $post['invisible'] == 0}-->
        <!--{if $_G[uid]}-->
        <!--{if ($_G['group']['raterange'] && $post['authorid']) || ($allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])) || ((($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])) || ($post['authorid'] != $_G['uid'])}-->
        <div id="menups_$post[pid]" class="menups{if !$post['first'] && $viewposttype == 1 && $menusposit == 1} posttype_menups{/if}{if $post['first']} mbn{/if}" style="display:none;">
            <ul>
                <!--{if $post['authorid'] != $_G['uid']}-->
                <li><a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" class="F3pveqiOE331"><i class="0C0cLs1XHW4b"></i>{lang report}</a></li>
                <!--{/if}-->
                <!--{if $allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])}-->
                <li><a class="F3pveqiOE331" href="forum.php?mod=misc&action=comment&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page{if $_G['forum_thread']['special'] == 127}&special=$specialextra{/if}"><i class="dlJaJLCE9T5V"></i>{lang comments}</a></li>
                <!--{/if}-->
                <!--{if $_G['group']['raterange'] && $post['authorid']}-->
                <li><a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]{if $ratetype == 1 || $ratetype == 2}&reward=1{/if}" class="F3pveqiOE331"><i class="{if $ratetype == 1 || $ratetype == 2}vt-goldcoin{else}vt-rate{/if}"></i><!--{if $ratetype == 1 || $ratetype == 2}-->{$langplus[viewsreward]}<!--{else}-->{lang rate}<!--{/if}--></a></li>
                <!--{/if}-->
                <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])}-->
                <li><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_G[forum_thread][sortid]}{if $post[first]}&sortid={$_G[forum_thread][sortid]}{/if}{/if}{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><i class="HcGNy22c8avk"></i>{lang edit}</a></li>
                <!--{/if}-->
            </ul>
        </div>
        <!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
        <!--{if $_G['forum']['ismoderator']}-->
        <!-- manage start -->
        <!--{if $post[first]}-->
        <div id="moption_$post[pid]" popup="true" style="display:none;">
            <ul class="1IsysWBNUzTD">
                <!--{if !$_G['forum_thread']['special']}--><li><input type="button" value="{lang edit}" class="MskmOzArai7S" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></li><!--{/if}-->
                <li><input type="button" value="{if !$_G['forum_thread']['closed']}{lang modmenu_switch_off}{else}{lang modmenu_switch_on}{/if}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4"></li>
                <li><input type="button" value="{lang admin_banpost}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></li>
                <li><input type="button" value="{lang topicadmin_warn_add}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></li>
                <li><input type="button" value="{lang thread_moved}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=move&optgroup=2&from={$_G[tid]}"></li>
                <li><input type="button" value="{lang modmenu_type}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=type&optgroup=2&from={$_G[tid]}"></li>
                <li><input type="button" value="{lang modmenu_stickpost}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=stick&optgroup=1&from={$_G[tid]}"></li>
                <li><input type="button" value="{lang digest_posts}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=digest&optgroup=5&from={$_G[tid]}"></li>
                <li><input type="button" value="{lang delete}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}"></li>
                <!--{if !empty($postlist[$post[pid]]['totalrate']) && $_G['forum']['ismoderator']}--><li><a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" class="oLsUIR67Aab7" >{lang removerate}</a></li><!--{/if}-->
            </ul>
        </div>
        <!--{else}-->
        <div id="moption_$post[pid]" popup="true" style="display:none;">
            <ul class="1IsysWBNUzTD">
                <li><input type="button" value="{lang edit}" class="MskmOzArai7S" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></li>
                <!--{if $_G['group']['allowbanpost']}--><li><input type="button" value="{lang modmenu_banpost}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                <!--{if $_G['group']['allowwarnpost']}--><li><input type="button" value="{lang modmenu_warn}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                <!--{if $_G['group']['allowstickreply']}--><li><input type="button" value="{lang modmenu_stickpost}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=stickreply&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                <!--{if $_G['group']['allowdelpost']}--><li><input type="button" value="{lang modmenu_deletepost}" class="KHvUMqDl8usb" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                <!--{if !empty($postlist[$post[pid]]['totalrate']) && $_G['forum']['ismoderator']}--><li><a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" class="oLsUIR67Aab7" >{lang removerate}</a></li><!--{/if}-->
            </ul>
        </div>
        <!--{/if}-->
        <!-- manage end -->
        <!--{/if}-->
    </div>
    <!--{if $post['first'] && $viewforums == 1}-->
    <!--{if $_G[forum][threads] > 9999 }-->
    <!--{eval $_G[forum][threads] = round($_G[forum][threads] / 10000 , 1).$langplus[tenthousand];}-->
    <!--{/if}-->
    <!--{if $_G['basescript'] == 'group'}-->
    <!--{if $_G[forum][membernum] > 9999 }-->
    <!--{eval $_G[forum][membernum] = round($_G[forum][membernum] / 10000 , 1).$langplus[tenthousand];}-->
    <!--{/if}-->
    <!--{else}-->
    <!--{if $_G[forum][posts] > 9999 }-->
    <!--{eval $_G[forum][posts] = round($_G[forum][posts] / 10000 , 1).$langplus[tenthousand];}-->
    <!--{/if}-->
    <!--{/if}-->
    <div class="PpSk9Yadfx9E">
        <a href="forum.php?mod=forumdisplay&fid=$_G[fid]">
            <!--{if $_G['forum'][icon]}--><img src="{$_G['setting']['attachurl']}/{if $_G['basescript'] == 'group'}group{else}common{/if}/$_G['forum'][icon]"><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $_G[forum][todayposts] > 0}_new{/if}.png"/><!--{/if}-->
            <h1>{$_G['forum'][name]}</h1>
            <p>{lang forum_threads} <span>$_G[forum][threads]</span> &nbsp; {if $_G['basescript'] == 'group'}{lang member} <span>{$_G[forum][membernum]}</span>{else}{$langplus[forum_posts]} <span>$_G[forum][posts]</span>{/if}</p>
        </a>
    </div>
    <!--{/if}-->
    <!--{if $post['first']}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adviewthreadd && in_array($_G['fid'],(array)unserialize($adviewthreadidd))}--><!--{$adviewthreadd}--><!--{/if}-->
    <!--{if $adviewthreade && in_array($_G['fid'],(array)unserialize($adviewthreadide))}--><!--{$adviewthreade}--><!--{/if}-->
    <!--{if $adviewthreadf && in_array($_G['fid'],(array)unserialize($adviewthreadidf))}--><!--{$adviewthreadf}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $post['first']}-->
    <!--{if $_G[forum_thread][special] != 2}-->
    <!--{if $openrelated == 0 || $openrelated == 1}-->
    <!--{if $openrelated == 0 && $post['relateitem']}-->
    <div class="QBGaBGBKsHEw">
        <div class="qrZcxEaXs8OF"><span>{$langplus[view_related]}</span></div>
        <ul>
            <!--{eval $rel = 1;}-->
            <!--{loop $post['relateitem'] $var}-->
            <!--{if $relatedpics == 1}-->
            <!--{eval $thread['rlithumb'] = DB::result_first("SELECT aid FROM  ".DB::table("forum_attachment_".substr($var['tid'],-1,1))." WHERE  tid =".$var['tid']." and width>0 order by dateline asc LIMIT 0 , 1");}-->
            <!--{/if}-->
            <!--{if $rel == $relatednums + 1}--><div class="NIqhvm13ww5m"><span>{$langplus[more_view]}</span></div><!--{/if}-->
            <li{if $rel > $relatednums} class="vjfHASvLWKok"{/if}>
            <a href="forum.php?mod=viewthread&tid=$var[tid]" class="relateitem_subject{if !$thread['rlithumb']} nopic{/if}">
                <!--{if $thread['rlithumb']}-->
                <!--{eval $imagerlithumb = getforumimg($thread['rlithumb'], 0, 200, 150); }-->
                <span class="owyRm6a2HE98"><img src="{$imagerlithumb}"></span>
                <!--{/if}-->
                <div class="HENCD91ug4Mj">$var[subject]</div>
                <div class="RmtNF3ghIDoA">
                    {echo dgmdate($var['dateline'], 'u')}
                    <!--{if $var[views] > 9999 }-->
                    <!--{eval $var[views] = round($var[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $var[replies] > 9999 }-->
                    <!--{eval $var[replies] = round($var[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <span class="99u2LxYcMOhO"><!--{if $var[replies] > 0}-->{$var[replies]}{lang join_thread}<!--{else}-->{$var[views]}{$langplus[view]}<!--{/if}--></span>
                </div>
            </a>
            </li>
            <!--{eval $rel++;}-->
            <!--{/loop}-->
        </ul>
    </div>
    <!--{else}-->
    <!--{eval $vtperpage = $relatedallnums; $vtarticleday = $relatedtimes; $vtpostsorts = $relatedsorts; $vtonlypic = $relatedpics; }-->
    <!--{eval require_once(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/viewthreadlist.php');}-->
    <!--{if $vtslist}-->
    <div class="QBGaBGBKsHEw">
        <div class="qrZcxEaXs8OF"><span>{$langplus[view_related]}</span></div>
        <ul>
            <!--{eval $rel = 1;}-->
            <!--{loop $vtslist $vts}-->
            <!--{if $rel == $relatednums + 1}--><div class="NIqhvm13ww5m"><span>{$langplus[more_view]}</span></div><!--{/if}-->
            <li{if $rel > $relatednums} class="vjfHASvLWKok"{/if}>
            <a href="forum.php?mod=viewthread&tid={$vts[tid]}" class="relateitem_subject{if !$vts[imagethumb]} nopic{/if}">
                <!--{if $vts[imagethumb]}--><span class="eV6QZvlP57vk"><img src="{$vts[imagethumb]}"></span><!--{/if}-->
                <div class="HENCD91ug4Mj">{$vts[subject]}</div>
                <div class="RmtNF3ghIDoA">
                    {$vts[dateline]}
                    <!--{if $vts[views] > 9999 }-->
                    <!--{eval $vts[views] = round($vts[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $vts[replies] > 9999 }-->
                    <!--{eval $vts[replies] = round($vts[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <span class="99u2LxYcMOhO"><!--{if $vts[replies] > 0}-->{$vts[replies]}{lang join_thread}<!--{else}-->{$vts[views]}{$langplus[view]}<!--{/if}--></span>
                </div>
            </a>
            </li>
            <!--{eval $rel++;}-->
            <!--{/loop}-->
        </ul>
    </div>
    <!--{/if}-->
    <!--{/if}-->
    <script type="text/javascript">
        $(document).ready(function(){
            $('.relateitem_more').click(function(){
                $('.relateitem_morerelated').show();
                $(this).hide();
            });
        });
    </script>
    <!--{/if}-->
    <!--{/if}-->
    <div class="qrZcxEaXs8OF" id="ap_reply">
        <span class="Hwo4Ms30B8m6">{$_G[forum_thread][allreplies]}{$langplus[reply]}</span>
        <!--{if $_G[forum_thread][allreplies] > 0}-->
        <!--{if !$rushreply}-->
        <!--{if $ordertype != 1}-->
        <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1" class="tSRL61KN2a9L">{$langplus[post_descview]}</a>
        <!--{else}-->
        <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2" class="RHRnvsUcVQvg">{$langplus[post_ascview]}</a>
        <!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
    </div>
    <!--{/if}-->
    <!--{eval $postcount++;}-->
    <!--{/loop}-->
</div>
<!-- main postlist end -->
<div id="ajaxpost"{if $viewposttype == 1} class="ZmV8NrV6SiKm"{/if}><div id="post_new"></div></div>
<!--{if $_G[forum_thread][allreplies] <= 0}-->
<div class="d5yNuqYAzkYt">
    <img src="template/v2_mbl20121009/touch_plus/image/sofa.png">
    $langplus[sofas]
</div>
<!--{/if}-->
<!--{if ($_G[forum_thread][allreplies] > 0) && ($_G['forum_thread']['replies'] < $_G['ppp']) }-->
<div class="eejJHkr1tiQK">$langplus[allcontent]</div>
<!--{/if}-->
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil(($_G['forum_thread']['replies'] + 1) / $_G['ppp']);}-->
<!--{if $totalpage > $page}-->
<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype={if $ordertype != 1}2{else}1{/if}&threads=thread" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}">$langplus[more]</a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage_view.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{subtemplate forum/forumdisplay_fastpost}-->
<!--{hook/viewthread_bottom_mobile}-->
<!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') == false && strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') == false && (strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false)}-->
<!--{eval $thread['thumb'] = DB::result_first("SELECT attachment FROM  ".DB::table("forum_attachment_".substr($thread['tid'],-1,1))." WHERE tid = ".$thread['tid']." and width>0 order by dateline asc LIMIT 0 , 1");}-->
<div id="myshare" class="ysMRojn3XRKC"></div>
<div class="qytY6AvMLAlZ"></div>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/share.js?{VERHASH}"></script>
<script type="text/javascript">var config = {url:'{$_G['siteurl']}/forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]',title:'{$_G[forum_thread][subject]}',desc:'{$_G[forum_thread][subject]}',img:'{if $thread[thumb]}{$_G['siteurl']}/{$_G['setting']['attachurl']}/forum/{$thread[thumb]}{elseif $logourl}{$_G['siteurl']}/{$logourl}{/if}',};var share_obj = new myshare('myshare',config);</script>
<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false }-->
<div id="myshare"></div>
<div class="Bn5G6abKZdVY"></div>
<!--{else}-->
<div class="zddxUhbNB29m"><p>{$langplus[share_browser]}</p><img src="template/v2_mbl20121009/touch_plus/image/browser_share_icon.png"/></div>
<div class="qytY6AvMLAlZ"></div>
<!--{/if}-->
<div class="Es3s87mAHtE5"></div>
<div class="3BpUTDuPIV3L"></div>
<!--{if $_G[forum_thread][special] == 2}-->
<div class="RghlnzV17hRz"></div>
<!--{/if}-->
<script type="text/javascript">
    $(document).ready(function(){
        <!--{if $_G[uid]}-->
        $(document).on('click','.moreaction',function(){
            var menupsid = $(this).parent('.viewpost').next('.menups').attr('id');
            $('#' + menupsid).fadeIn();
            $('.close_m').show();
            $(this).addClass('popon');
        });
        $('.close_m').off().on('touchstart',function(){
            $('.menups').hide();
            $('.popon').removeClass('popon');
            $(this).hide();
        });
        $(document).on('click','.menups a',function(){
            $('.menups, .close_m').hide();
            $('.popon').removeClass('popon');
        });
        $(document).on('click','.ajaxjump',function(){
            popup.open('<div class="lmVdjV39q3EP"></div>');
            var obj = $(this);
            $.ajax({
                type:'POST',
                url:obj.attr('href') + '&handlekey=ajaxjump&inajax=1',
                data:{'formhash':'{FORMHASH}'},
                dataType:'xml',
            })
                .success(function(s) {
                    popup.open(s.lastChild.firstChild.nodeValue);
                    evalscript(s.lastChild.firstChild.nodeValue);
                })
                .error(function() {
                    window.location.href = obj.attr('href');
                    popup.close();
                });
            return false;
        });
        <!--{/if}-->
    });
</script>
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}--><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a><!--{/if}--><!--{if $diypostlinks ==1}--><a href="forum.php" class="rnxgBOYPCeEM"></a><!--{elseif $diypostlinks == 2}--><!--{if $_G['basescript'] == 'group'}--><a href="group.php" class="A2eQY5rXcHeY"></a><!--{else}--><a href="forum.php?forumlist=1" class="s8jMx1vYmVzA"></a><!--{/if}--><!--{/if}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="vvuDzz6aN5Xe"></a><a href="$upnavlink" class="VkmTmMvm1mAV"></a></div>
<!--{/block}-->