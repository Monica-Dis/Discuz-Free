<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $debaternum = $debate[affirmdebaters] + $debate[negadebaters]}-->
<!--{eval $allvotes = $debate[affirmvotes] + $debate[negavotes]}-->
<!--{eval $affirmvotes = round($debate[affirmvotes] / $allvotes * 100, 1)}-->
<!--{eval $negavotes = 100 - $affirmvotes}-->
<div class="hEeBa7s6Bcpg">
    <div class="keuk5RiCzwFy"><span class="AkDaP3wdfx5x">{$_G[forum_thread][views]}</span><p>{$langplus[browsednum]}</p></div>
    <div class="keuk5RiCzwFy"><span class="AkDaP3wdfx5x">{$debaternum}</span><p>{$langplus[debaternum]}</p></div>
    <div class="keuk5RiCzwFy"><span class="AkDaP3wdfx5x">$allvotes</span><p>{$langplus[votenum]}</p></div>
</div>

<div id="postmessage_$post[pid]" class="2QJS1583Ldl0">$post[message]</div>

<div class="E1Oy6Qaawyb0"><span>{lang debate}{$langplus[point]}</span></div>
<div class="P9ZxVpTzl9LD">
<div class="Wvd5cbQrJucu"><div class="vjEJ87WZoR1S"><span>{lang debate_square_point}</span>$debate[affirmpoint]</div></div>
<div class="Wvd5cbQrJucu"></div>
<div class="Wvd5cbQrJucu"><div class="Ps8UP1AtDoTW"><span>{lang debate_opponent_point}</span>$debate[negapoint]</div></div>
</div>

<div class="zMMT1qLMxA9N">
<div class="aqhBPSOwU2g0">
    <div class="pgU9FAcKQ1pe">
        <div class="y33EknAnjxWi"><span>{if $allvotes > 0 && $affirmvotes > 0}{$affirmvotes}{else}0.00{/if}%</span><span>{if $allvotes > 0 && $negavotes > 0}{$negavotes}{else}0.00{/if}%</span></div>
        <div class="gP7ndmUjeFIA">
            <span style="width:{if $allvotes > 0}$affirmvotes{else}50{/if}%;"></span>
            <span style="width:{if $allvotes > 0}$negavotes{else}50{/if}%;"></span>
        </div>
    </div>
<!--{if !$_G['forum_thread']['is_archived']}-->
<div class="htyfdzqFJoqD">
<div class="y58z3wOQYZJY">
    <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" id="affirmbutton" class="57eMt3LaJcIg" ><span>$debate[affirmvotes]</span><p><i>{lang debate_square}</i></p></a>
</div>
<div class="Wvd5cbQrJucu"></div>
<div class="kXncoctlCeSo">
    <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" id="negabutton" class="57eMt3LaJcIg" ><span>$debate[negavotes]</span><p><i>{lang debate_opponent}</i></p></a>
</div>
</div>
<!--{/if}-->
</div>
</div>
<!--{if !$_G['forum_thread']['is_archived']}-->
<script type="text/javascript">
    $(document).on('click', '.votesajax', function() {
        <!--{if !$_G[uid]}-->
        popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
        <!--{else}-->
        var obj = $(this);
        $.ajax({
            type : 'GET',
            url : obj.attr('href') + '&inajax=1',
            dataType : 'xml'
        })
        .success(function(s) {
            var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
            var oksmg = '{$langplus[pollsucceed]}';
            if(smg.indexOf(oksmg) >= 0){
                $(".debate_data_box").load(location.href + " .debate_data_ajax");
            }else{
                popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg+'</dt></div>');
                setTimeout(function(){
                    $(".dialogbox, #mask").fadeOut();
                    }, 1500);
            }
        })
        .error(function() {
            window.location.href = obj.attr('href');
            popup.close();
        });
        <!--{/if}-->
        return false;
    });
</script>
<!--{if $debate[affirmdebaters] || $debate[negadebaters]}-->
<div class="E1Oy6Qaawyb0"><span>{$langplus[bothsides]}{lang debater}</span></div>
<div class="Ske3ZxcAVHYr">
    <div class="4XpnJG7afIdS">
    <!--{if $debate[affirmdebaters]}-->
    <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&filter=debate&stand=1">
    <!--{eval $aunum = 1;}-->
    <!--{loop $debate[affirmavatars] $user}-->
    <!--{if $aunum < 19}-->$user[avatar]<!--{/if}-->
    <!--{eval $aunum++;}-->
    <!--{/loop}-->
    </a>
    <!--{else}-->
    <img src="template/v2_mbl20121009/touch_plus/image/nodebater.png">
    <!--{/if}-->
    </div>
    <div class="4XpnJG7afIdS">
    <!--{if $debate[negadebaters]}-->
    <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&filter=debate&stand=2" >
    <!--{eval $nunum = 1;}-->
    <!--{loop $debate[negaavatars] $user}-->
    <!--{if $nunum < 19}-->$user[avatar]<!--{/if}-->
    <!--{eval $nunum++;}-->
    <!--{/loop}-->
    </a>
    <!--{else}-->
    <img src="template/v2_mbl20121009/touch_plus/image/nodebater.png">
    <!--{/if}-->
    </div>
</div>
<!--{/if}-->
<!--{/if}-->

<!--{if $debate[umpire]}-->
<!--{if $debate['umpirepoint']}-->
<!--{if $debate[winner]}-->
<!--{if $debate[winner] == 1}-->
<div class="22w1DkkDtUmU">{lang debate_square}{lang debate_winner} , {lang debate}{lang over}</div>
<!--{elseif $debate[winner] == 2}-->
<div class="22w1DkkDtUmU">{lang debate_opponent}{lang debate_winner} , {lang debate}{lang over}</div>
<!--{else}-->
<div class="22w1DkkDtUmU">{lang debate_draw} , {lang debate}{lang over}</div>
<!--{/if}-->
<!--{/if}-->
<!--{if $debate[bestdebater]}--><div class="JZCEzM5mujs2">{lang debate_bestdebater} : $debate[bestdebater]</div><!--{/if}-->
<!--{if $debate[umpirepoint]}--><div class="j06g5lmRybMl">{lang debate_umpirepoint} : $debate[umpirepoint]</div><!--{/if}-->
<!--{/if}-->
<!--{/if}-->

<!--{if $debate[endtime]}-->
<div class="Qb0tvxxYPeQf">{lang endtime} : $debate[endtime]</div>
<!--{if $debate[umpire]}--><div class="JZCEzM5mujs2">{lang debate_umpire} : $debate[umpire]</div><!--{/if}-->
<!--{/if}-->

<!--{if $debate[umpire] && $_G['username'] && $debate[umpire] == $_G['member']['username']}-->    
<!--{if $debate[remaintime] && !$debate[umpirepoint]}-->
<a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" class="zJOGrgGlQbXV" >{lang over}{lang debate}</a>
<!--{elseif TIMESTAMP - $debate['dbendtime'] < 3600}-->
<a href="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&pid=$post[pid]{if $_GET[from]}&from=$_GET[from]{/if}" class="GDXNWwsMwABE" >{lang edit}{$langplus[point]}</a>
<!--{/if}-->
<!--{/if}-->

<!--{eval $langplus['sayaword'] = {lang debate_join}{lang debate}}-->
<!--{eval $langplus['reply'] = {lang debate}}-->
<!--{eval $langplus['sofas'] = $langplus['sofas_d']}-->