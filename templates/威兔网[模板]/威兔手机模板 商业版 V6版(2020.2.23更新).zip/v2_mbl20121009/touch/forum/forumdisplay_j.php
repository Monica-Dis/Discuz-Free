<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['forum_threadcount']}-->
<!--{template forum/displayorder}-->
<ul id="alist" class="mtwnHeq7DUeE">
    <!--{eval $ad = 1;}-->
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
    {eval continue;}
    <!--{/if}-->
    <!--{if $thread['displayorder'] > $threaddisplayorder}-->
    <!--{else}-->
    <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
    {eval $displayorder_thread = 1;}
    <!--{/if}-->
    <!--{if $thread['moved']}-->
    <!--{eval $thread[tid]=$thread[closed];}-->
    <!--{/if}-->
    <!--{hook/forumdisplay_middle_v2_mobile}-->
    <!--{if $page == 1}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adforumdisplaya && in_array($_G['fid'],(array)unserialize($adforumdisplayida)) && $ad == $adforumdisplaytha}--><!--{$adforumdisplaya}--><!--{/if}-->
    <!--{if $adforumdisplayb && in_array($_G['fid'],(array)unserialize($adforumdisplayidb)) && $ad == $adforumdisplaythb}--><!--{$adforumdisplayb}--><!--{/if}-->
    <!--{if $adforumdisplayc && in_array($_G['fid'],(array)unserialize($adforumdisplayidc)) && $ad == $adforumdisplaythc}--><!--{$adforumdisplayc}--><!--{/if}-->
    <!--{if $adforumdisplayd && in_array($_G['fid'],(array)unserialize($adforumdisplayidd)) && $ad == $adforumdisplaythd}--><!--{$adforumdisplayd}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $specialplugin == 0}--><!--{hook/forumdisplay_thread_mobile $key}--><!--{/if}-->
    <!--{if $thread['special'] == 1}-->
    <li class="YwnDf5Yfb7HS">
        <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/topicalsubject.php');}-->
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="ITIKGA8Wqdil" >
            <!--{if $thread['expiration'] && $thread['expiration'] < TIMESTAMP}-->
            <div class="nGtd9UEx08dR"></div>
            <!--{/if}-->
            <h1><!--{if $thread['highlight']}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}--></h1>
            <div class="o1ya91eD5zDJ">{$langplus[totals]} {$thread[voters]} {$langplus[people]}{$langplus[voteprtp]}<!--{if $poll[total]}-->, {$langplus[votenum]} {$poll[total]}<!--{/if}--></div>
            <div class="ZIxpOtbJtB6a">
                <!--{if $thread['expiration'] && $thread['expiration'] < TIMESTAMP}-->
                {lang poll}{$langplus[alreadyover]}
                <!--{else}-->
                <span class="dNmi1svKyHdH">{$langplus[voteing]}</span>
                <!--{if $thread['expiration']}-->
                <span class="99u2LxYcMOhO"><!--{if $thread['days']}-->{$thread[days]} {lang days}<!--{/if}--><!--{if $thread['hours']}--> {$thread[hours]} {lang poll_hour}<!--{/if}--><!--{if $thread['minutes']}--> {$thread[minutes]} {lang poll_minute}<!--{/if}--></span>
                <!--{/if}-->
                <!--{/if}-->
            </div>
        </a>
    </li>
    <!--{elseif $thread['special'] == 2}-->
    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/topicalsubject.php');}-->
    <!--{if in_array($_G['fid'],(array)unserialize($threadtradetype))}-->
    <li class="pU9NzWKPT0UP">
        <div class="ghp7Duf7hZ4L">
            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="42P8yvfrkaMT">
                <p>
                    <!--{if $trades['aid']}-->
                    <!--{eval $imagethumb = getforumimg($trades['aid'], 0, 360, 360); }-->
                    <img src="$imagethumb" />
                    <!--{else}-->
                    <img src="{IMGDIR}/nophoto.gif" />
                    <!--{/if}-->
                </p>
                <h1><!--{if $thread[highlight]}--><span{$thread[highlight]}><!--{if $trades[subject] != $thread[subject]}-->{$trades[subject]} <!--{/if}-->{$thread[subject]}</span><!--{else}--><!--{if $trades[subject] != $thread[subject]}-->{$trades[subject]} <!--{/if}-->{$thread[subject]}<!--{/if}--></h1>
                <div class="mE8hmR4OSMbO">
                    <!--{if $trades['price'] > 0}--><span><i>&yen;</i>{$trades[price]}</span><!--{elseif $trades['credit']}--><span>{$trades[credit]}<i>{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}</i></span><!--{/if}-->
                    <em>{$langplus[tradeselled]}{$trades[totalitems]}{$langplus[piece]}</em>
                </div>
            </a>
            <div class="EpRp4gnHNBzx">
                <img src="{avatar($thread[authorid],middle,true)}" />
                <!--{if $thread['authorid'] && $thread['author']}-->
                <a href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
                <!--{else}-->
                <a href="javascript:;">$_G[setting][anonymoustext]</a>
                <!--{/if}-->
            </div>
        </div>
    </li>
    <!--{else}-->
    <li class="YwnDf5Yfb7HS">
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="Ui73Exh4gH3M" >
            <!--{if $trades['aid']}-->
            <!--{eval $imagethumb = getforumimg($trades['aid'], 0, 200, 200); }-->
            <span class="eV6QZvlP57vk"><img src="$imagethumb" /></span>
            <!--{else}-->
            <span class="eV6QZvlP57vk"><img src="{IMGDIR}/nophoto.gif" /></span>
            <!--{/if}-->
            <h1><!--{if $thread[highlight]}--><span{$thread[highlight]}><!--{if $trades[subject] != $thread[subject]}-->{$trades[subject]} <!--{/if}-->{$thread[subject]}</span><!--{else}--><!--{if $trades[subject] != $thread[subject]}-->{$trades[subject]} <!--{/if}-->{$thread[subject]}<!--{/if}--></h1>
            <div class="mE8hmR4OSMbO"><!--{if $trades['price'] > 0}--><span><i>&yen;</i>{$trades[price]}</span><!--{if $trades['costprice'] > 0}--><em>&yen;{$trades[costprice]}</em><!--{/if}--><!--{elseif $trades['credit']}--><span>{$trades[credit]}<i>{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}</i></span><!--{if $trades['costcredit']}--><em>{$trades[costcredit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}</em><!--{/if}--><!--{/if}--></div>
            <div class="qRqwite8NCij">
                <!--{if $trades['quality'] == 1}--><i class="ExTX0x1KXVq1"></i><!--{else}--><i class="lZHztadJtL9p"></i><!--{/if}-->
                <!--{if $thread['authorid'] && $thread['author']}--><span class="Hwo4Ms30B8m6">$thread[author]</span><!--{else}--><span class="Hwo4Ms30B8m6">$_G[setting][anonymoustext]</span><!--{/if}-->
                <span class="99u2LxYcMOhO">{$langplus[tradeselled]} {$trades[totalitems]} {$langplus[piece]}</span>
            </div>
        </a>
    </li>
    <!--{/if}-->
    <!--{elseif $thread['special'] == 3}-->
    <li class="YwnDf5Yfb7HS">
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="spcsubject_2{if $thread['special'] == '3' && $thread['price'] < 0} sbj_reward_yes{/if}" >
            <!--{if $thread['special'] == '3' && $thread['price'] < 0}-->
            <div class="EOGucw5ZyKzZ"></div>
            <!--{/if}-->
            <h1>
                <!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}-->
            </h1>
            <div class="2iegwnlWkQrn">
                <!--{if $thread[replies] > 9999 }-->
                <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                {$langplus[totals]} <span class="Qb3lVD0vju2a">{$thread[replies]}</span> {lang unit}{$langplus[answer]}
                <div class="W00N8hr2PnZb">
                    <span>{lang thread_reward}</span>
                    <strong>
                        <!--{if $thread[price] < 0}-->
                        <!--{eval $thread['price'] = $thread['price'] * -1;}-->
                        {$thread[price]}
                        <!--{else}-->
                        {$thread[price]}
                        <!--{/if}-->
                    </strong>
                    <span>{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}</span>
                </div>
            </div>
            <div class="UhwrobWRAAmG">
                <img src="{avatar($thread[authorid],small,true)}" /><!--{if $thread['authorid'] && $thread['author']}--><span>$thread[author]</span><!--{else}--><span>$_G[setting][anonymoustext]</span><!--{/if}-->
                <span>{$langplus[askat]} {$thread[dateline]}</span>
                <!--{if $thread[views] > 9999 }-->
                <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <em class="99u2LxYcMOhO">{$thread[views]} {$langplus[browsed]}</em>
            </div>
        </a>
    </li>
    <!--{elseif $thread['special'] == 4}-->
    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/topicalsubject.php');}-->
    <li class="kjAMMDVObsXz">
        <div class="eV6QZvlP57vk">
            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">
                <!--{if $activitys['aid']}-->
                <!--{eval $imagethumb = getforumimg($activitys['aid'], 0, 600, 330); }-->
                <img src="$imagethumb" />
                <!--{else}-->
                <img src="template/v2_mbl20121009/touch_plus/image/activity.jpg" />
                <!--{/if}-->
            </a>
        </div>
        <h1><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra"><!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}--></a></h1>
        <p><span>{lang activity_type}:</span>{$activitys[class]}</p>
        <p><span>{lang activity}{lang time}:</span>{echo dgmdate($activitys[starttimefrom])}<!--{if $activitys['starttimeto']}--> - {echo dgmdate($activitys[starttimeto])}<!--{/if}--></p>
        <!--{if $activitys['place']}--><p><span>{lang activity_space}:</span>{$activitys[place]}</p><!--{/if}-->
        <!--{if $activitys['number']}--><p><span>{lang activity_about_member}:</span>{$remainders} {lang activity_member_unit}</p><!--{/if}-->
        <p><span>{lang dateline}:</span>{$thread[dateline]}</p>
        <!--{if !$activityclose}-->
        <div class="ktCWeGaBS4cS"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">{$langplus[iwant]}{$langplus[apply]}</a></div>
        <!--{else}-->
        <div class="nNsIv51CPchg"><a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra">{$langplus[apply]}{$langplus[alreadyover]}</a></div>
        <!--{/if}-->
    </li>
    <!--{elseif $thread['special'] == 5}-->
    <li class="YwnDf5Yfb7HS">
        <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/topicalsubject.php');}-->
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="pHG7Id0hfNsI">
            <!--{if $debates['umpirepoint']}-->
            <!--{if $debates['winner'] == 1}-->
            <div class="Mnz9yX21VIhl"></div>
            <!--{elseif $debates['winner'] == 2}-->
            <div class="CHmZewLa4Qub"></div>
            <!--{else}-->
            <div class="Fx0jRljxeDIT"></div>
            <!--{/if}-->
            <!--{/if}-->
            <h1>
                <!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}-->
            </h1>
            <!--{if $allvotes || $debaternum}-->
            <div class="o1ya91eD5zDJ"><!--{if $debaternum}-->{$langplus[totals]} {$debaternum} {$langplus[people]}{$langplus[debateprtp]}<!--{/if}--><!--{if $allvotes}--><!--{if $debaternum}-->, <!--{/if}-->{$langplus[votenum]} {$allvotes}<!--{/if}--></div>
            <!--{/if}-->
            <div class="pgU9FAcKQ1pe">
                <div class="y33EknAnjxWi"><span>{if $allvotes > 0 && $affirmvotes > 0}{$affirmvotes}{else}0.00{/if}%</span><span>{if $allvotes > 0 && $negavotes > 0}{$negavotes}{else}0.00{/if}%</span></div>
                <div class="gP7ndmUjeFIA">
                    <span style="width:{if $allvotes > 0}$affirmvotes{else}50{/if}%;"></span>
                    <span style="width:{if $allvotes > 0}$negavotes{else}50{/if}%;"></span>
                </div>
            </div>
            <div class="yBb1chwjYVSQ">
                <p><span>{lang debate_square}:</span>$debates[affirmpoint]</p>
                <p><span>{lang debate_opponent}:</span>$debates[negapoint]</p>
            </div>
            <!--{if $debates['umpirepoint'] || $debates['endtime'] < TIMESTAMP}-->
            <div class="ZIxpOtbJtB6a">{lang debate}{$langplus[alreadyover]}<!--{if $debaternum}--><span class="99u2LxYcMOhO">{$langplus[totals]} {$debaternum} {$langplus[people]}{$langplus[debateprtp]}</span><!--{/if}--></div>
            <!--{else}-->
            <div class="ZIxpOtbJtB6a"><span class="N5YEst5J1rb7">{lang debate}{$langplus[taskdoing]}</span><span class="99u2LxYcMOhO">{lang endtime} {echo dgmdate($debates[endtime], 'u')}</span></div>
            <!--{/if}-->
        </a>
    </li>
    <!--{else}-->
    <li class="LMiaPSLU3SLL">
        <!--{eval $imgnumber = 1;}-->
        <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/threadlist.php');}-->
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="th_item{if !$thread['thumb']} nopic{/if}" >
            <!--{if $thread['thumbfirst']}-->
            <!--{eval $imagethumb = getforumimg($thread['thumbfirst'], 0, 200, 150); }-->
            <span class="eV6QZvlP57vk"><img src="$imagethumb" /></span>
            <!--{/if}-->
            <h1>
                <!--{if $thread['displayorder'] > 0}-->
                <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;
                <!--{/if}-->
                <!--{if $thread['digest'] > 0}-->
                <em class="GR92yicG3zyZ">$langplus[digest]</em> &middot;
                <!--{/if}-->
                <!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}-->
            </h1>
            <div class="hNOK3poJcpFf">
                <!--{if $thread['authorid'] && $thread['author']}--><span>$thread[author]</span><!--{else}--><span>$_G[setting][anonymoustext]</span><!--{/if}-->
                <span>{$thread[dateline]}</span>
                <!--{if $thread[replies]}-->
                <!--{if $thread[replies] > 9999 }-->
                <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $thread['isgroup'] != 1}-->
                <!--{if $thread[views] > 9999 }-->
                <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $groupnames[$thread[tid]][views] > 9999 }-->
                <!--{eval $groupnames[$thread[tid]][views] = round($groupnames[$thread[tid]][views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->
                <span class="99u2LxYcMOhO"><!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}--><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->{$langplus[view]}<!--{/if}--></span>
            </div>
        </a>
    </li>
    <!--{/if}-->
    <!--{/if}-->
    <!--{eval $ad++;}-->
    <!--{/loop}-->
</ul>
<!--{else}-->
<div class="sqK9gG26iUGb">{lang forum_nothreads}</div>
<!--{/if}-->