<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang trade_confirm_buy}<!--{/block}-->
<!--{template common/header}-->
	<script type="text/javascript">
		zoomstatus = parseInt($_G[setting][zoomstatus]);
		var feevalue = 0;
		<!--{if $trade[price] > 0}-->var price = $trade[price];<!--{/if}-->
		<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->var credit = $trade[credit];var currentcredit = <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][5])}-->;<!--{/if}-->
	</script>
		<form method="post" autocomplete="off" id="tradepost" name="tradepost" action="forum.php?mod=trade&action=trade&tid=$_G[tid]&pid=$pid">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="z76GhPvFhhjY">
					<div class="78unVSaNt7rx">
						<div class="9wXhwTM6eBJB">
							<!--{if $trade['aid']}-->
							<a href="forum.php?mod=viewthread&do=tradeinfo&tid=$trade[tid]&pid=$trade[pid]"><img src="{echo getforumimg($trade[aid])}" /></a>
							<!--{else}-->
							<a href="forum.php?mod=viewthread&do=tradeinfo&tid=$trade[tid]&pid=$trade[pid]"><img src="{IMGDIR}/nophotosmall.gif" /></a>
							<!--{/if}-->
						</div>
						<h1>$trade[subject]</h1>
						<p>
							<span>{$langplus[price]}:</span>
							<!--{if $trade[price] > 0}-->
							<span id="trade_price">$trade[price]</span> {lang payment_unit}
							<!--{/if}-->
							<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
							/ {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]} <span id="trade_credit">$trade[credit]</span>&nbsp;{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}
							<!--{/if}-->
						</p>
						<!--{if $trade[locus]}-->
						<p><span>{lang trade_locus}:</span> $trade[locus]</p>
						<!--{/if}-->
					</div>
					<table cellspacing="0" cellpadding="0" class="CBXzlsdiQJdd">
						<tr>
							<th>{lang trade_credits_total}:</th>
							<td>
								<!--{if $trade[price] > 0}--><span id="caculate">$trade[price]</span>&nbsp;{lang trade_units}&nbsp;&nbsp;<!--{/if}-->
								<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}&nbsp;<span id="caculatecredit">$trade[credit]</span>&nbsp;{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}&nbsp;<span id="crediterror"></span><!--{/if}-->
							</td>
						</tr>
						<tr>
							<th>{lang trade_nums}:</th>
							<td><input type="text" id="number" name="number" onkeyup="calcsum()" value="1" /></td>
						</tr>
						<tr>
							<th valign="top">{lang post_trade_transport}:</th>
							<td>
								<p>
								<!--{if $trade['transport'] == 0}-->{$langplus[tradeoffline]}<!--{/if}-->
								<!--{if $trade['transport'] == 1}--><input type="hidden" name="transport" value="1">{lang post_trade_transport_seller}<!--{/if}-->
								<!--{if $trade['transport'] == 2}--><input type="hidden" name="transport" value="2">{lang post_trade_transport_buyer}<!--{/if}-->
								<!--{if $trade['transport'] == 3}--><input type="hidden" name="transport" value="3">{lang post_trade_transport_virtual}<!--{/if}-->
								<!--{if $trade['transport'] == 4}--><input type="hidden" name="transport" value="4">{lang post_trade_transport_physical}<!--{/if}-->
								</p>
								<!--{if $trade['transport'] == 1 or $trade['transport'] == 2 or $trade['transport'] == 4}-->
								<p class="sEj1sHHzaWFN">
									<!--{if !empty($trade['ordinaryfee'])}--><label><input type="radio" name="fee" value="1" checked="checked" {if $trade['transport'] == 2}onclick="feevalue = $trade[ordinaryfee];calcsum()"{/if} />{lang post_trade_transport_mail} $trade[ordinaryfee] {lang payment_unit}</label><!--{if $trade['transport'] == 2}--><script type="text/javascript">feevalue = $trade[ordinaryfee]</script><!--{/if}--><!--{/if}-->
									<!--{if !empty($trade['expressfee'])}--><label><input type="radio" name="fee" value="3" checked="checked" {if $trade['transport'] == 2}onclick="feevalue = $trade[expressfee];calcsum()"{/if} />{lang post_trade_transport_express} $trade[expressfee] {lang payment_unit}</label><!--{if $trade['transport'] == 2}--><script type="text/javascript">feevalue = $trade[expressfee]</script><!--{/if}--><!--{/if}-->
									<!--{if !empty($trade['emsfee'])}--><label><input type="radio" name="fee" value="2" checked="checked" {if $trade['transport'] == 2}onclick="feevalue = $trade[emsfee];calcsum()"{/if} /> EMS $trade[emsfee] {lang payment_unit}</label><!--{if $trade['transport'] == 2}--><script type="text/javascript">feevalue = $trade[emsfee]</script><!--{/if}--><!--{/if}-->
								</p>
								<!--{/if}-->
							</td>
						</tr>
						<tr>
							<th>{lang trade_paymethod}:</th>
							<td>
								<!--{if !$_G['uid']}-->
									<label><input type="hidden" name="offline" value="0" checked="checked" />{lang trade_pay_alipay}</label>
								<!--{elseif !$trade['account'] && !$trade['tenpayaccount']}-->
									<input type="hidden" name="offline" value="1" checked="checked" />{lang trade_pay_offline}
								<!--{else}-->
									<label><input type="radio" name="offline" value="0" checked="checked" />{lang trade_pay_alipay}</label>
									<label><input type="radio" name="offline" value="1" />{lang trade_pay_offline}</label>
								<!--{/if}-->
							</td>
						</tr>
						<!--{if $trade['transport'] != 3}-->
							<tr>
								<th>{lang trade_buyername}:</th>
								<td><input type="text" id="buyername" name="buyername" maxlength="50" value="$lastbuyerinfo[buyername]" /></td>
							</tr>
							<tr>
								<th>{lang trade_buyercontact}:</th>
								<td><input type="text" id="buyercontact" name="buyercontact" maxlength="140" value="$lastbuyerinfo[buyercontact]" /></td>
							</tr>
							<tr>
								<th>{lang trade_buyerzip}:</th>
								<td><input type="text" id="buyerzip" name="buyerzip" maxlength="20" value="$lastbuyerinfo[buyerzip]" /></td>
							</tr>
							<tr>
								<th>{lang trade_buyerphone}:</th>
								<td><input type="text" id="buyerphone" name="buyerphone" maxlength="20" value="$lastbuyerinfo[buyerphone]" /></td>
							</tr>
							<tr>
								<th>{lang trade_buyermobile}:</th>
								<td><input type="text" id="buyermobile" name="buyermobile" maxlength="20" value="$lastbuyerinfo[buyermobile]" /></td>
							</tr>
						<!--{else}-->
							<input type="hidden" name="buyername" value="" />
							<input type="hidden" name="buyercontact" value="" />
							<input type="hidden" name="buyerzip" value="" />
							<input type="hidden" name="buyerphone" value="" />
							<input type="hidden" name="buyermobile" value="" />
						<!--{/if}-->
						<tr>
							<th valign="top">{lang trade_seller_remark}:</th>
							<td>
								<textarea id="buyermsg" name="buyermsg" rows="3" maxlength="240" placeholder="{lang trade_seller_remark_comment}"></textarea>
							</td>
						</tr>
						<tr>
							<td colspan="2">
								<!--{if !$_G['uid']}--><div class="IHUDUAqpiULT">{lang trade_guest_alarm}</div><!--{/if}-->
							</td>
						</tr>
					</table>
				</div>
			<div class="pO8btUYfgnr0">
			<button type="submit" id="tradesubmit" name="tradesubmit" value="true" class="pymKRL3JTNW2">{lang trade_buy_confirm}</button>
			</div>
		</form>
	<script type="text/javascript">
		function calcsum() {
			<!--{if $trade[price] > 0}-->caculate.innerHTML = (price * tradepost.number.value + feevalue);<!--{/if}-->
			<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
				v = (credit * tradepost.number.value + feevalue);
				if(v > currentcredit) {
					crediterror.innerHTML = '{lang trade_buy_crediterror}';
					tradesubmit.disabled = true;
				} else {
					crediterror.innerHTML = '';
				}
				caculatecredit.innerHTML = v;
			<!--{/if}-->
		}
		calcsum();
	</script>
<!--{block footerplus}--><div class="a87wGthEpSmH"></div><!--{/block}-->
<!--{eval $nofooter = true;}-->
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->
<!--{/if}-->
<!--{template common/footer}-->