<?php echo 'From: DisM.taobao.com';exit;?>
    <li><textarea name="affirmpoint" id="affirmpoint"  rows="3" placeholder="{lang debate_square_point}" >$debate[affirmpoint]</textarea></li>
    <li><textarea name="negapoint" id="negapoint" rows="3" placeholder="{lang debate_opponent_point}">$debate[negapoint]</textarea></li>
    <li><input type="text" name="endtime" id="endtime" autocomplete="off" value="$debate[endtime]" placeholder="{lang endtime}" /></li>
    <li><input type="text" name="umpire" id="umpire" placeholder="{lang debate_umpire}" /></li>

