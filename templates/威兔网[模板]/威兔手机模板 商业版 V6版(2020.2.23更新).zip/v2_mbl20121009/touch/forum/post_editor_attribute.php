<?php echo 'From: DisM.taobao.com';exit;?>
        <div class="menufly">
        <div class="namefly"><span class="vt-close fz2"></span>$langplus[option]</div>
		<div class="editor editorplus">
				<a href="javascript:;" class="postadditional editortab on"></a>
		<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
			<!--{if $_G['group']['allowsetreadperm']}-->
				<a href="javascript:;" class="postreadperm editortab"></a>
			<!--{/if}-->
			<!--{if $_G['group']['allowreplycredit'] && !in_array($special, array(2, 3))}-->
				<!--{if $_GET[action] == 'newthread'}-->
					<!--{eval $extcreditstype = $_G['setting']['creditstransextra'][10];}-->
				<!--{else}-->
					<!--{eval $extcreditstype = $replycredit_rule['extcreditstype'] ? $replycredit_rule['extcreditstype'] : $_G['setting']['creditstransextra'][10];}-->
				<!--{/if}-->
				<!--{eval $userextcredit = getuserprofile('extcredits'.$extcreditstype);}-->
				<!--{if ($_GET[action] == 'newthread' && $userextcredit > 0) || ($_GET[action] == 'edit' && $isorigauthor && isfirstpost)}-->
					<a href="javascript:;" class="postreplycredit editortab"></a>
				<!--{/if}-->
			<!--{/if}-->
			<!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
				<a href="javascript:;" class="postrushreplyset editortab"></a>
			<!--{/if}-->
			<!--{if $_G['group']['maxprice'] && !$special}-->
				<a href="javascript:;" class="postprice editortab"></a>
			<!--{/if}-->
			<!--{if $_G['group']['allowposttag']}-->
				<a href="javascript:;" class="posttag editortab"></a>
			<!--{/if}-->
			<!--{if $_G['group']['allowsetpublishdate'] && ($_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost && $thread['displayorder'] == -4))}-->
				<a href="javascript:;" class="postpubdate editortab"></a>
			<!--{/if}-->            
		<!--{/if}-->
		</div>
            
		<div class="editor_optionplus">            
		<div class="editor_additional hidebox2" style="display: block;">
			<ul>			
			<!--{if $_GET[action] != 'edit'}-->
			<!--{if $_G['group']['allowanonymous']}-->
            <li><label for="isanonymous"><input type="checkbox" name="isanonymous" id="isanonymous" value="1" /><em>{lang post_anonymous}</em></label></li>
            <!--{/if}-->
            <!--{else}-->
            <!--{if $_G['group']['allowanonymous'] || (!$_G['group']['allowanonymous'] && $orig['anonymous'])}-->
            <li><label for="isanonymous"><input type="checkbox" name="isanonymous" id="isanonymous" value="1" {if $orig['anonymous']}checked="checked"{/if} /><em>{lang post_anonymous}</em></label></li>
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
            <li><label for="hiddenreplies"><input type="checkbox" name="hiddenreplies" id="hiddenreplies" {if $thread['hiddenreplies']} checked="checked"{/if} value="1"><em>{lang hiddenreplies}</em></label></li>
            <!--{/if}-->
            <!--{if $_G['uid'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost) && $special != 3}-->
            <li><label for="ordertype"><input type="checkbox" name="ordertype" id="ordertype" value="1" $ordertypecheck /><em>{lang post_descviewdefault}</em></label></li>
            <!--{/if}-->
            <!--{if ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
            <li><label for="allownoticeauthor"><input type="checkbox" name="allownoticeauthor" id="allownoticeauthor" value="1"{if $allownoticeauthor} checked="checked"{/if} /><em>{lang post_noticeauthor}</em></label></li>
            <!--{/if}-->
            <!--{if $_GET[action] != 'edit' && helper_access::check_module('feed') && $_G['forum']['allowfeed']}-->
            <li><label for="addfeed"><input type="checkbox" name="addfeed" id="addfeed" value="1" $addfeedcheck><em>{lang addfeed}</em></label></li>
            <!--{/if}-->
            <li><label for="usesig"><input type="checkbox" name="usesig" id="usesig" value="1" {if !$_G['group']['maxsigsize']}disabled {else}$usesigcheck {/if}/><em>{lang post_show_sig}</em></label></li>
            </ul> 
            <ul class="mtm">            
            <!--{if ($_G['forum']['allowhtml'] || ($_GET[action] == 'edit' && ($orig['htmlon'] & 1))) && $_G['group']['allowhtml']}-->
            <li><label for="htmlon"><input type="checkbox" name="htmlon" id="htmlon" value="1" $htmloncheck /><em>{lang post_html}</em></label></li>
            <!--{else}-->
            <li><label for="htmlon"><input type="checkbox" name="htmlon" id="htmlon" value="0" $htmloncheck disabled="disabled" /><em>{lang post_html}</em></label></li>
            <!--{/if}-->
            <li><label for="allowimgcode"><input type="checkbox" id="allowimgcode" disabled="disabled" {if $_G['forum']['allowimgcode']} checked="checked"{/if} /><em>{lang post_imgcode}</em></label></li>
            <!--{if $_G['forum']['allowimgcode']}-->
            <li><label for="allowimgurl"><input type="checkbox" id="allowimgurl" checked="checked" /><em>{lang post_imgurl}</em></label></li>
            <!--{/if}-->
            <li><label for="parseurloff"><input type="checkbox" name="parseurloff" id="parseurloff" value="1" $urloffcheck /><em>{lang disable}{lang post_parseurl}</em></label></li>
            <li><label for="smileyoff"><input type="checkbox" name="smileyoff" id="smileyoff" value="1" $smileyoffcheck /><em>{lang disable}{lang smilies}</em></label></li>
            <li><label for="bbcodeoff"><input type="checkbox" name="bbcodeoff" id="bbcodeoff" value="1" $codeoffcheck /><em>{lang disable}{lang discuzcode}</em></label></li>
            <!--{if $_G['group']['allowimgcontent']}-->
            <li><label for="imgcontent"><input type="checkbox" name="imgcontent" id="imgcontent" value="1" $imgcontentcheck /><em>{lang content_to_pic}</em></label></li>
            <!--{else}-->
            <li><label for="imgcontent"><input type="checkbox" name="imgcontent" id="imgcontent" value="0" $imgcontentcheck disabled="disabled"/><em>{lang content_to_pic}</em></label></li>
            <!--{/if}-->
            </ul>           
            <!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts'])}-->            
            <!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts']) && ($_G['group']['allowstickthread'] || $_G['group']['allowdigestthread'])}-->
            <ul class="mtm">            
            <!--{if $_G['group']['allowstickthread']}-->
            <li><label for="sticktopic"><input type="checkbox" name="sticktopic" id="sticktopic" value="1" $stickcheck /><em>{lang post_stick_thread}</em></label></li>
            <!--{/if}-->
            <!--{if $_G['group']['allowdigestthread']}-->
            <li><label for="addtodigest"><input type="checkbox" name="addtodigest" id="addtodigest" value="1" $digestcheck /><em>{lang post_digest_thread}</em></label></li>
            <!--{/if}-->
            </ul>
            <!--{/if}-->            
            <!--{elseif $_GET[action] == 'edit' && $_G['forum_auditstatuson']}-->
            <ul class="mtm">            
            <li><label for="audit"><input type="checkbox" name="audit" id="audit" value="1"><em>{lang auditstatuson}</em></label></li>
            </ul>
            <!--{/if}-->            
            <!--{if $_GET[action] == 'edit' && $isorigauthor && ($isfirstpost && $thread['replies'] < 1 || !$isfirstpost) && !$rushreply && $_G['setting']['editperdel']}-->
            <ul class="mtm">
            <li><label><input type="checkbox" name="delete" id="delete" value="1" title="{lang post_delpost}{if $thread[special] == 3}{lang reward_price_back}{/if}"><em>{lang post_delpost}</em></label></li>
            </ul>
            <!--{/if}-->
		</div>
		<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
		<!--{if $_G['group']['allowsetreadperm']}-->
		<div class="hidebox2">
		<div class="editor_readperm">
        <span>{lang readperm}:</span>
        <div class="selectstyle">
        <select name="readperm" id="readperm" onChange="extraCheck(1)">
            <option value="">{lang unlimited}</option>
            <!--{loop $_G['cache']['groupreadaccess'] $val}-->
            <option value="$val[readaccess]" title="{lang readperm}: $val[readaccess]"{if $thread['readperm'] == $val[readaccess]} selected="selected"{/if}>$val[grouptitle]</option>
            <!--{/loop}-->
            <option value="255"{if $thread['readperm'] == 255} selected="selected"{/if}>{lang highest_right}</option>
        </select>
        </div>
		</div>        
        <div class="warningmessage">{lang post_select_usergroup_readacces}</div>
		</div>
		<!--{/if}-->
        <!--{if $_G['group']['allowreplycredit'] && !in_array($special, array(2, 3))}-->
        <!--{if ($_GET[action] == 'newthread' && $userextcredit > 0) || ($_GET[action] == 'edit' && $isorigauthor && isfirstpost)}-->
		<div class="hidebox2">
        <div class="editor_replycredit">
        <span>{lang replycredit}:</span>
        <input type="text" name="replycredit_extcredits" id="replycredit_extcredits" value="{if $replycredit_rule['extcredits'] && $thread['replycredit'] > 0}{$replycredit_rule['extcredits']}{else}0{/if}" placeholder="{$langplus[replycredit_empty]}" />
        <em>{$_G['setting']['extcredits'][$extcreditstype][unit]}{$_G['setting']['extcredits'][$extcreditstype][title]}</em>
        </div>
        <div class="editor_replycredit">
        <span>{$langplus[maxawardperweek]}:</span>
        <input type="text" name="replycredit_times" id="replycredit_times" value="{if $replycredit_rule['lasttimes']}{$replycredit_rule['lasttimes']}{else}1{/if}" />
        <em>{lang replycredit_time}</em>
        </div>
        <div class="editor_replycredit">
        <span>{$langplus[replycredit_member]}:</span>
        <div class="selectstyle">
        <select id="replycredit_membertimes" name="replycredit_membertimes">
            <!--{eval for($i=1;$i<11;$i++) {;}-->
            <option value="$i"{if $replycredit_rule['membertimes'] == $i} selected="selected"{/if}>$i</option>
            <!--{eval };}-->
        </select>
        </div>
        <em>{lang replycredit_time}</em>
        </div>
        <div class="editor_replycredit">
        <span>{$langplus[replycredit_rate]}:</span>
        <div class="selectstyle">
        <select id="replycredit_random" name="replycredit_random">
            <!--{eval for($i=100;$i>9;$i=$i-10) {;}-->
            <option value="$i"{if $replycredit_rule['random'] == $i} selected="selected"{/if}>$i</option>
            <!--{eval };}-->
        </select>
        </div>
        <em>%</em>
        </div>
        <div class="warningmessage">{lang replycredit_total} <span id="replycredit_sum"><!--{if $thread['replycredit']}-->{$thread['replycredit']}<!--{else}-->0<!--{/if}--></span> {$_G['setting']['extcredits'][$extcreditstype][unit]}{$_G['setting']['extcredits'][$extcreditstype][title]}, {lang replycredit_revenue}{$_G['setting']['extcredits'][$extcreditstype][title]} <span id="replycredit">0</span> {$_G['setting']['extcredits'][$extcreditstype][unit]}, {lang you_have}{$_G['setting']['extcredits'][$extcreditstype][title]} $userextcredit {$_G['setting']['extcredits'][$extcreditstype][unit]}</div>
		</div>
<script type="text/javascript">
	$(document).on('input value','#replycredit_extcredits, #replycredit_times',function(){
		var bonus = $("#replycredit_extcredits").val();
		var rewardnum = $("#replycredit_times").val();
		if(!bonus.search(/^\d+$/) && !rewardnum.search(/^\d+$/) || bonus == '' || rewardnum == '') {
			var fullbonus = Math.ceil(bonus * rewardnum);
			var payams = Math.ceil(bonus * rewardnum * {$_G['setting']['creditstax']} + (bonus * rewardnum));
			$('#replycredit_sum').html(fullbonus);
			$('#replycredit').html(payams);
			if(payams > {$userextcredit}) {
				$('#replycredit').addClass('orange');
			}else{
				$('#replycredit').removeClass('orange');
			}
		}
    });
</script>        
		<!--{/if}-->
        <!--{/if}-->
		<!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
		<div class="hidebox2">                                    
		<div class="editor_rushreplyset rushreplyset_times">
        <span>{lang rushreply_time}</span>        
        <input type="text" name="rushreplyfrom" id="rushreplyfrom" autocomplete="off" value="$postinfo[rush][starttimefrom]" onKeyUp="$('rushreply').checked = true;" placeholder="{lang activity_starttime}" /><em> - </em><input type="text" autocomplete="off" id="rushreplyto" name="rushreplyto" value="$postinfo[rush][starttimeto]" onKeyUp="$('rushreply').checked = true;" placeholder="{lang endtime}" />
        </div>
        <div class="editor_rushreplyset rushreplyset_floor mbn">
        <span>{lang rushreply_rewardfloor}</span>
        <label for="rushreply" class="rushreplyset_cck"><input type="checkbox" name="rushreply" id="rushreply" value="1" {if $_GET[action] == 'edit' && getstatus($thread['status'], 3)}disabled="disabled" checked="checked"{/if} onClick="extraCheck(3)" /><i></i></label>        
        <input type="text" name="rewardfloor" id="rewardfloor" value="$postinfo[rush][rewardfloor]" onKeyUp="$('rushreply').checked = true;" />
        </div>
        <div class="warningmessage">{lang rushreply_rewardfloor_comment}</div>
        <div class="editor_rushreplyset">
        <span>{lang stopfloor}:</span>
        <input type="text" name="replylimit" id="replylimit" autocomplete="off" value="$postinfo[rush][replylimit]" onKeyUp="$('rushreply').checked = true;" placeholder="{lang replylimit}" />
        </div>
        <div class="editor_rushreplyset">
        <span>{lang rushreply_end}</span>
        <input type="text" name="stopfloor" id="stopfloor" autocomplete="off" value="$postinfo[rush][stopfloor]" onKeyUp="$('rushreply').checked = true;" />
        </div>
        <div class="editor_rushreplyset mbn">
        <span><!--{if $_G['setting']['creditstransextra'][11]}-->{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]}<!--{else}-->{lang credits}<!--{/if}-->{lang min_limit}:</span>
        <input type="text" name="creditlimit" id="creditlimit" autocomplete="off" value="$postinfo[rush][creditlimit]" onKeyUp="$('rushreply').checked = true;" />
        </div>        
        <div class="warningmessage"><!--{if $_G['setting']['creditstransextra'][11]}-->({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]})<!--{else}-->{lang total_credits}<!--{/if}-->{lang post_rushreply_credit}</div>              
        </div>             
        <!--{/if}-->
        <!--{if $_G['group']['maxprice'] && !$special}-->
        <div class="hidebox2">
        <div class="editor_price">
		<span>{lang price}:</span>
		<input type="text" id="price" name="price" value="$thread[pricedisplay]" onBlur="extraCheck(2)" />
        <em>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</em>
        </div>
        <div class="warningmessage">{lang post_price_comment}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</div>                    
        <!--{if $_G['group']['maxprice'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
        <!--{if $_G['setting']['maxincperthread'] || $_G['setting']['maxchargespan']}-->
        <div class="warningmessage">
        <!--{if $_G['setting']['maxincperthread']}--><p>{lang post_price_income_comment}</p><!--{/if}-->
        <!--{if $_G['setting']['maxchargespan']}--><p>{lang post_price_charge_comment}<!--{if $_GET[action] == 'edit' && $freechargehours}-->{lang post_price_free_chargehours}<!--{/if}--></p><!--{/if}-->
        </div>
        <!--{/if}-->
        <!--{/if}-->                    
        </div>
        <!--{/if}-->
        <!--{if $_G['group']['allowposttag']}-->
        <div class="hidebox2">
        <div class="editor_tag">
        <span>{lang post_tag}:</span>
        <input type="text" id="tags" name="tags" value="$postinfo[tag]" />	
        </div>
        <!--{eval $recent_use_tag = recent_use_tag();}-->
        <!--{if $recent_use_tag}-->
        <div class="editor_tag_recent mbn">
        <!--{eval $tagi = 1;}-->
        <!--{loop $recent_use_tag $var}-->
        <span onClick="instag('fastpost', '$var ')" class="tag{$tagi}" >$var</span>
        <!--{eval $tagi++;}-->
        <!--{/loop}-->
        </div>
        <!--{/if}-->
        <div class="warningmessage">{lang posttag_comment}</div>
        <script type="text/javascript">function instag(key, post_tag) { post_input = document.postform.tags; post_input.value += post_tag; post_input.focus();}</script>                
        </div> 
        <!--{/if}-->
        <!--{if $_G['group']['allowsetpublishdate'] && ($_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost && $thread['displayorder'] == -4))}-->
        <div class="hidebox2">        
        <div class="editor_pubdate">
        <span>{lang post_timer}:</span>
        <label class="pubdate_cck"><input type="checkbox" name="cronpublish" id="cronpublish" value="true" {if $cronpublish} checked="checked"{/if} /><i></i></label>
        <input type="text" name="cronpublishdate" id="cronpublishdate" autocomplete="off" value="{$cronpublishdate}" onChange="if(this.value) $('cronpublish').checked = true;">
        </div>        
        </div>
        <!--{/if}-->
        <!--{/if}-->
        </div> 
        </div>