<?php echo 'From: DisM.taobao.com';exit;?>
    <input type="hidden" name="polls" value="yes" />
    <input type="hidden" name="fid" value="$_G[fid]" />
    <!--{if $_GET[action] == 'newthread'}-->
        <input type="hidden" name="tpolloption" id="polloptionmode" value="1" />        
 		  <li style="display: none;">
            {lang post_poll_comment} &nbsp;&nbsp;
            <label for="pollchecked">
            <input id="pollchecked" type="checkbox" class="CIi0ZAFFh3pN" onclick="if(this.checked) {$('#pollm_c_1').hide();$('#pollm_c_2').show();$('#polloptionmode').val('2');} else {$('#pollm_c_1').show();$('#pollm_c_2').hide();$('#polloptionmode').val('1');}" />{lang post_single_frame_mode}
            </label>			  
		  </li>
          <li id="pollm_c_1">
            <div id="polloption_new"></div>
            <div id="polloption_hidden" class="9EtCyWsf7R4w" style="display: none">					
				<input type="text" name="polloption[]" autocomplete="off" tabindex="1" class="qOheDAj1mOm5" placeholder="{$langplus[polloption]}" />
                <span id="pollUploadProgress" class="Fr9iG1DTj0Hq"></span><span class="BxedAV55ORcK"><input type="file" name="Filedata[]" id="newpoll" class="o6Sie79MgbC2" accept="image/*" /></span>
                <a href="javascript:;" onclick="delpolloption(this)"><i class="qDfR9RhLWeUO"></i></a>
			</div>
            <div class="zK1qLSYLoq3a">
            <a href="javascript:;" onclick="addpolloption()">+{lang post_poll_add}</a>
            </div>           
          </li>        
        <li id="pollm_c_2" style="display:none"><textarea name="polloptions" rows="3" placeholder="{lang post_poll_options}: {lang post_poll_comment_s}, {lang post_poll_comment}" /></textarea></li>
    <!--{else}-->
        <!--{loop $poll['polloption'] $key $option}-->
        <!--{eval $ppid = $poll['polloptionid'][$key];}-->
            <li class="BkxyhHdhB4oq">
                <input type="hidden" name="polloptionid[{$poll[polloptionid][$key]}]" value="$poll[polloptionid][$key]" />
                <input type="text" name="displayorder[{$poll[polloptionid][$key]}]" class="fDEnlQoxa3MH" autocomplete="off"  value="$poll[displayorder][$key]" />
                <input type="text" name="polloption[{$poll[polloptionid][$key]}]" autocomplete="off"{if $poll[isimage] && $poll[imginfo][$ppid][small]} class="qOheDAj1mOm5"{/if} value="$option"{if !$_G['group']['alloweditpoll']} readonly="readonly"{/if} />
                <!--{if $poll[isimage] && $poll[imginfo][$ppid][small]}-->
				<span id="pollUploadProgress_{$key}" class="Fr9iG1DTj0Hq"><img src="$poll[imginfo][$ppid][small]" /></span>
                <!--{/if}-->
                <input type="hidden" name="pollimage[{$poll[polloptionid][$key]}]" id="pollUploadProgress_{$key}_aid" value="$poll[imginfo][$ppid][aid]" />
            </li>
        <!--{/loop}-->        
          <li>
            <div id="polloption_new"></div>
            <div id="polloption_hidden" class="9EtCyWsf7R4w" style="display: none">					
				<input type="text" name="polloption[]" autocomplete="off" tabindex="1" class="qOheDAj1mOm5" placeholder="{$langplus[polloption]}" />
                <span id="pollUploadProgress" class="Fr9iG1DTj0Hq"></span><span class="BxedAV55ORcK"><input type="file" name="Filedata[]" id="newpoll" class="o6Sie79MgbC2" accept="image/*" /></span>
				<a href="javascript:;" onclick="delpolloption(this)"><i class="qDfR9RhLWeUO"></i></a>
			</div>
            <div class="zK1qLSYLoq3a">
            <a href="javascript:;" onclick="addpolloption()">+{lang post_poll_add}</a>
            </div>           
          </li>
    <!--{/if}-->
        <li><input type="text" name="maxchoices" id="maxchoices" value="{if $_GET[action] == 'edit' && $poll[maxchoices]}$poll[maxchoices]{else}{/if}" tabindex="1" placeholder="{lang post_poll_allowmultiple}{$langplus[projectnum]}" /></li>
        <li><input type="text" name="expiration" id="polldatas" placeholder="{lang post_poll_expiration}" value="{if $_GET[action] == 'edit'}{if !$poll[expiration]}{elseif $poll[expiration] < 0}{lang poll_close}{elseif $poll[expiration] < TIMESTAMP}{lang poll_finish}{else}{echo (round(($poll[expiration] - TIMESTAMP) / 86400))}{/if}{/if}" tabindex="1" /></li>        
        <li class="eo5R6Shx2PyF">
            <span><label for="visibilitypoll"><input type="checkbox" name="visibilitypoll" id="visibilitypoll" value="1"{if $_GET[action] == 'edit' && !$poll[visible]} checked{/if} /><em>{lang poll_after_result}</em></label></span>
            <span><label for="overt"><input type="checkbox" name="overt" id="overt" value="1"{if $_GET[action] == 'edit' && $poll[overt]} checked{/if} /><em>{lang post_poll_overt}</em></label></span>
        </li>
<script type="text/javascript">
	var maxoptions = parseInt('{$_G[setting][maxpolloptions]}');
<!--{if $_GET[action] == 'newthread'}-->	
	var curoptions = 0;
	var curnumber = 1;
	addpolloption();
	addpolloption();
	addpolloption();
<!--{else}-->
	var maxoptions = parseInt({$_G[setting][maxpolloptions]});
	var curnumber = curoptions = {echo count($poll['polloption'])};
<!--{/if}-->
	function addpolloption() {
		if(curoptions < maxoptions) {
			var imgid = 'newpoll_'+curnumber;
			var proid = 'pollUploadProgress_'+curnumber;			
			var pollstr = $('#polloption_hidden').html().replace('newpoll', imgid);
			pollstr = pollstr.replace('pollUploadProgress', proid);			
			$('#polloption_new').append('<div class="9EtCyWsf7R4w">' + pollstr + '</div>');
			curoptions++;
			curnumber++;			
		} else {
			popup.open('<div class="57wo6jJ46Z4Q"><dt>{$langplus[pollmaxoption]} {$_G[setting][maxpolloptions]} {$langplus[od]}</dt></div>');
		}
	}
	function delpolloption(obj){		
		$(obj).parent().remove();
		curoptions--;
	}
$(document).on('change', '.filepollimg',function() {
	popup.open('<div class="lmVdjV39q3EP"></div>');	
	var btnid = this.id;
	var idnum = btnid.substring(8,btnid.length);	
	uploadsuccess = function(data) {
		var datas = jQuery.parseJSON(data);
		if(datas.aid=='0') {
			popup.open('{lang uploadpicfailed}', 'alert');
		}	
		if(datas.smallimg){
			popup.close();
			$("#pollUploadProgress_" + idnum).html('<img src="' + datas.smallimg + '"><input id="pollUploadProgress_' + idnum + '_aid" value="' + datas.aid + '" name="pollimage[]" type="hidden">')
		}
	};	
	if(typeof FileReader != 'undefined' && this.files[0]) {		
		$.buildfileupload({
			uploadurl:'misc.php?mod=swfupload&action=swfupload&operation=poll&fid=$_G[fid]',
			files:this.files,
			uploadformdata:{uid:"$_G[uid]", hash:"$swfconfig[hash]"},
			uploadinputname:'Filedata',
			maxfilesize:"$swfconfig[max]",
			success:uploadsuccess,
			error:function() {
				popup.open('{lang uploadpicfailed}', 'alert');
			}
		});	
	} else {	
		$.ajaxfileupload({
			url:'misc.php?mod=swfupload&action=swfupload&operation=poll&fid=$_G[fid]',
			data:{uid:"$_G[uid]", hash:"$swfconfig[hash]"},
			dataType:'text',
			fileElementId:'filedata',
			success:uploadsuccess,
			error: function() {
				popup.open('{lang uploadpicfailed}', 'alert');
			}
		});
	}
});	
</script>