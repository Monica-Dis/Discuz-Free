<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $isactivitymaster}-->{lang activity_applylist_manage}<!--{else}-->{lang activity_applylist}<!--{/if}--><!--{/block}-->
<!--{template common/header}-->
<form id="applylistform" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplylist&tid=$_G[tid]&applylistsubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="operation" value="" />
    <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
    <div class="activity_manage">
        <!--{loop $applylist $apply}-->
        <div class="activity_manage_box">
            <a href="home.php?mod=space&uid=$apply[uid]&do=profile" class="avatars"><img src="{avatar($apply[uid], middle, true)}" /></a>
            <div class="activity_manage_item">
                <ul class="activity_manage_key">
                    <li><span>{lang activity_join_members}:</span> <a href="home.php?mod=space&uid=$apply[uid]&do=profile">$apply[username]</a></li>
                    <!--{if $activity['cost']}--><li><span>{$langplus[activity_payment]}:</span> <!--{if $apply[payment] >= 0}-->$apply[payment] {lang payment_unit}<!--{else}-->{lang activity_self}<!--{/if}--></li><!--{/if}-->
                    <li><span>{lang activity_jointime}:</span> {$apply[dateline]}</li>
                    <!--{if $isactivitymaster}-->
                    <li>
                        <span>{lang status}:</span>
                        <!--{if $apply[verified] == 1}-->
                        <em class="activity_manage_approval">{lang activity_allow_join}</em>
                        <!--{elseif $apply[verified] == 2}-->
                        {lang activity_do_replenish}
                        <!--{else}-->
                        {lang activity_cant_audit}
                        <!--{/if}-->
                    </li>
                    <!--{if $apply[verified] == 1}--><i class="vt-approval"></i><!--{/if}-->
                    <!--{/if}-->
                </ul>
                <!--{if $apply[ufielddata]}-->
                <div id="actl_$apply[uid]" class="activity_manage_keyct">
                    <ul>
                        $apply[ufielddata]
                    </ul>
                </div>
                <!--{/if}-->
                <!--{if $apply[message]}--><div class="activity_manage_mes"><span>{lang leaveword}:</span> {$apply[message]}</div><!--{/if}-->
            </div>
            <!--{if $isactivitymaster}-->
            <div class="activity_manage_cck">
                <!--{if $apply[uid] != $_G[uid]}-->
                <input type="checkbox" name="applyidarray[]" value="$apply[applyid]" />
                <!--{else}-->
                <input type="checkbox" disabled="disabled" />
                <!--{/if}-->
            </div>
            <!--{/if}-->
        </div>
        <!--{/loop}-->
    </div>
    <!--{if $isactivitymaster}-->
    <div class="activity_manage_footer">
        <div class="activity_manage_in"><input name="reason" size="25" placeholder="{lang activity_ps}" /><label><input type="checkbox" name="chkall" id="chkall" /></label></div>
        <div class="activity_manage_btn">
            <ul>
                <li><button type="submit" value="true" name="applylistsubmit" class="formdialog button">{lang confirm}</button></li>
                <li><button type="submit" value="true" name="applylistsubmit" onclick="applylistform.operation.value='replenish';" class="formdialog button">{lang to_improve}</button></li>
                <li><button type="submit" value="true" name="applylistsubmit" onclick="applylistform.operation.value='notification';" class="formdialog button">{lang send_notification}</button></li>
                <li><button type="submit" value="true" name="applylistsubmit" onclick="applylistform.operation.value='delete';" class="formdialog button">{lang activity_refuse}</button></li>
            </ul>
        </div>
    </div>
    <script type="text/javascript">
        $("#chkall").click(function(){
            if(this.checked){
                $("input[type='checkbox']").attr("checked","checked");
            }else{
                $("input[type='checkbox']").attr("checked",null);
            }
        });
    </script>
    <!--{/if}-->
</form>
<!--{if !$headershow}--><style type="text/css">.scroll_openmenu {bottom: 140px;}</style><!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->