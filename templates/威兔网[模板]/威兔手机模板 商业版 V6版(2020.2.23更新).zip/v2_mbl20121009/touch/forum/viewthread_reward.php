<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['forum_thread']['price'] < 0}--><div class="fJtMq5jTCVw5"></div><!--{/if}-->
<div class="reward{if $_G['forum_thread']['price'] > 0} reward_icon_no{elseif $_G['forum_thread']['price'] < 0} reward_icon_yes{/if}">
    <div class="Qu9MtpnQcPR7"></div>
    <div class="R6onFLe5qnq3">{$langplus[rewardask]}</div>
    <div class="xUuYgumyCpSH">
        <!--{if $_G[forum_thread][allreplies] > 9999 }-->
        <!--{eval $_G[forum_thread][allreplies] = round($_G[forum_thread][allreplies] / 10000 , 1).$langplus[tenthousand];}-->
        <!--{/if}-->
        <span><em class="Qb3lVD0vju2a">{$_G[forum_thread][allreplies]}</em>{$langplus[answer]}</span>
        <!--{if $_G['forum_thread']['favtimes']}-->
        <!--{if $_G['forum_thread']['favtimes'] > 9999 }-->
        <!--{eval $_G['forum_thread']['favtimes'] = round($_G['forum_thread']['favtimes'] / 10000 , 1).$langplus[tenthousand];}-->
        <!--{/if}-->
        <span><em class="evXx4HZDPWdN">{$_G['forum_thread']['favtimes']}</em>{lang thread_favorite}</span>
        <!--{/if}-->
        <!--{if $_G[forum_thread][views] > 9999 }-->
        <!--{eval $_G[forum_thread][views] = round($_G[forum_thread][views] / 10000 , 1).$langplus[tenthousand];}-->
        <!--{/if}-->
        <span><em>{$_G[forum_thread][views]}</em>{$langplus[browsed]}</span>
    </div>
    <div class="W00N8hr2PnZb">
        <span>{lang reward}</span>
        <strong>{$rewardprice}</strong>
        <span>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</span>
    </div>
</div>

<div class="w5iQoobwAPE0"><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]"><span>{$langplus[ask]}:</span>$_G[forum_thread][subject]</a></div>

<div class="vEgQrebvnaK8">
    <a href="{if $post['authorid'] && $post['username'] && !$post['anonymous']}home.php?mod=space&uid=$post[authorid]&do=profile{else}{if $_G['forum']['ismoderator']}home.php?mod=space&uid=$post[authorid]&do=profile{else}javascript:;{/if}{/if}" class="HqT53LUIhU61"><img src="{if !$post['authorid'] || $post['anonymous']}{avatar(0, small, true)}{else}{avatar($post[authorid], small, true)}{/if}" /></a>
    <span class="4sFYn7oKrhV0">
        <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
           <a href="home.php?mod=space&uid=$post[authorid]&do=profile" >$post[author]</a>
        <!--{else}-->
        <!--{if !$post['authorid']}-->
           <a href="javascript:;">{lang guest}</a>
        <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
        <!--{if $_G['forum']['ismoderator']}-->
           <a href="home.php?mod=space&uid=$post[authorid]&do=profile">{lang anonymous}</a>
        <!--{else}-->
           <a href="javascript:;">{lang anonymous}</a>
        <!--{/if}-->
        <!--{else}-->
           <a href="javascript:;">$post[author]</a> {lang member_deleted}
        <!--{/if}-->
        <!--{/if}-->
        </span>
    <span class="e3vXzBhozeun">{$langplus[askat]} {echo dgmdate($post['dbdateline'], 'u')}</span>
</div>
<div id="postmessage_$post[pid]" class="2QJS1583Ldl0">$post[message]</div>
<!--{if $post['attachment']}-->
	<div class="QJgLkByST6uL">{lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em></div>
<!--{elseif $post['imagelist'] || $post['attachlist']}-->
    <div class="6xZuEZtiCCah">
    <!--{if $post['imagelist']}-->
         {echo showattach($post, 1)}
    <!--{/if}-->
    <!--{if $post['attachlist']}-->
         {echo showattach($post)}
    <!--{/if}-->
    </div>
<!--{/if}-->
<!--{eval $post['attachment'] = $post['imagelist'] = $post['attachlist'] = '';}-->

<!--{if $bestpost}-->
	<div class="m2piWXkhq4rv">
		<div class="Vut1Sk1YJYoX">{lang reward_bestanswer}<a href="forum.php?mod=redirect&goto=findpost&ptid=$bestpost[tid]&pid=$bestpost[pid]">{lang view_full_content}</a></div>
		<div class="XicaokuXYpTS">
			<a href="home.php?mod=space&uid=$bestpost[authorid]&do=profile" class="x9hHSPQjdnYg">$bestpost[avatar]</a>
			<a href="home.php?mod=space&uid=$bestpost[authorid]&do=profile" class="hUuJuH1gpRL7">$bestpost[author]</a>
			<div class="8OH9OakEkrqg">$bestpost[message]</div>
		</div>
	</div>
<!--{/if}-->

<!--{eval $langplus['reply'] = $langplus['answer']}-->
<!--{if $_G['forum_thread']['price'] > 0 && $post['authorid'] != $_G[uid]}-->
<!--{eval $langplus['sayaword'] = $langplus['rewardanswer']}-->
<!--{eval $langplus['sofas'] = $langplus['sofas_c']}-->
<style type="text/css">
    .fastreply { background: rgba(0,174,225,0.08); color:#00AEE1; padding: 0px 15px; text-align: center; font-size: 16px; }
    .fastreply:before { content: none; display: none; }
</style>
<!--{/if}-->