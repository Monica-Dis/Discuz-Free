<?php echo 'From: DisM.taobao.com';exit;?>
				<!--{if $list['threadcount']}-->
					<ul id="alist" class="HwKFWtPXAVEl">
					<!--{loop $list['threadlist'] $key $thread}-->
					<li class="0SjyuQop6KJp">
					<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="yUloUBxjglb3">
					<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
					<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
                    <h1>                                        
                    <!--{if $thread[folder] == 'lock'}--> 
                    <em>{lang close}</em> &middot; 
                    <!--{elseif $thread['special'] == 1}-->                                                                     
                    <em>{lang thread_poll}</em> &middot; 
                    <!--{elseif $thread['special'] == 2}--> 
                    <em>{lang thread_trade}</em> &middot; 
                    <!--{elseif $thread['special'] == 3}-->
                    <em>{lang thread_reward}</em> &middot; 
                    <!--{elseif $thread['special'] == 4}--> 
                    <em>{lang thread_activity}</em> &middot; 
                    <!--{elseif $thread['special'] == 5}--> 
                    <em>{lang thread_debate}</em> &middot; 
                    <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}--> 
                    <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;
                    <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}--> 
                    <em class="0rM8odj7aKyi">$langplus[pic]</em> &middot; 
                    <!--{/if}-->
					<!--{if $thread['digest'] > 0}-->
					<em class="GR92yicG3zyZ">$langplus[digest]</em> &middot; 
					<!--{/if}-->
                    $thread[subject]
                    <!--{if $thread['rushreply']}-->
                    <span class="DDhgGdFCeBwj"> - {lang rushreply}</span>
                    <!--{/if}-->
                    <!--{if $thread['price'] > 0}-->
                    <span class="DDhgGdFCeBwj"> -
                    <!--{if $thread['special'] == '3'}-->
                    {lang thread_reward} $thread[price] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}
                    <!--{else}-->
                    {lang price} $thread[price] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}
                    <!--{/if}-->
                    </span>
                    <!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
                    <span class="DDhgGdFCeBwj"> - {lang reward_solved}</span>
                    <!--{/if}-->
                    <!--{if $thread['replycredit'] > 0}-->
                    <span class="DDhgGdFCeBwj"> - {lang replycredit}</span>
                    <!--{/if}-->
                    </h1>
                    <div class="hNOK3poJcpFf">
                    <span>{$list['forumnames'][$thread[fid]]['name']}</span>
                    <span>{$thread[dateline]}</span> 
                    <!--{if $thread[icon] >= 0}-->
                    <em class="ZUp4byFwR1BK">#{$_G[cache][stamps][$thread[icon]][text]}</em>											
					<!--{/if}-->                   
                    <!--{if $thread[replies] > 9999 }-->
                    <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $thread['isgroup'] != 1}--> 
                    <!--{if $thread[views] > 9999 }-->
                    <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{else}-->                    
                    <!--{if $groupnames[$thread[tid]][views] > 9999 }-->
                    <!--{eval $groupnames[$thread[tid]][views] = round($groupnames[$thread[tid]][views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{/if}-->                                       
                    <span class="99u2LxYcMOhO"><!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}--><!--{if $thread['isgroup'] != 1}-->{$thread[views]}<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->{$langplus[view]}<!--{/if}--></span>
                    </div>
                    </a>
					</li>
					<!--{/loop}-->                    
					</ul>
				<!--{else}-->
					<div class="sqK9gG26iUGb">{lang guide_nothreads}</div>
				<!--{/if}-->