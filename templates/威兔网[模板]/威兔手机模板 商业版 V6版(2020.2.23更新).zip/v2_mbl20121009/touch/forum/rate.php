<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><!--{if $_GET[action] == 'rate'}-->{lang rate}<!--{elseif $_GET[action] == 'removerate'}-->{lang thread_removerate}<!--{/if}--><!--{/block}-->
<!--{template common/header}-->
<div class="tip{if !$_G['inajax']} no_ajax{/if}">
<!--{if empty($_GET['showratetip'])}-->
<!--{if $_GET[action] == 'rate'}-->
	<!--{if $_GET[reward] == '1'}-->

	<form id="rateform" method="post" autocomplete="off" action="forum.php?mod=misc&action=rate&ratesubmit=yes&infloat=yes" onsubmit="ajaxpost('rateform', 'return_rate', 'return_rate', 'onerror');">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<input type="hidden" name="pid" value="$_GET[pid]" />
		<input type="hidden" name="referer" value="$referer" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="rate"><!--{/if}-->
		<div class="rate_reward bb">
			<table cellspacing="0" cellpadding="0">
				<!--{eval $rateselfflag = 0;}-->
				<!--{loop $ratelist $id $options}-->
					<tr>
						<th>{$_G['setting']['extcredits'][$id][title]}</th>
						<td>
                        	<div class="rate_select">
								<input type="text" name="score$id" id="score$id" type="number" value="0" />
								<a href="javascript:;" onclick="showselect(this, 'score$id', 'selectoption$id')"></a>
								<ul id="selectoption$id" class="selectoption" style="display:none"><div>$options</div></ul>
                            </div>
						</td>
						<!--{eval $rateselfflag = $_G['group']['raterange'][$id][isself] ? 1 : $rateselfflag;}-->
					</tr>
				<!--{/loop}-->
			</table>
			<div class="rate_select explain_select">
            	<input type="text" name="reason" id="reason" class="select" placeholder="{lang user_operation_explain}" />
                <a href="javascript:;" onclick="showselect(this, 'reason', 'reasonselect')"></a>
				<!--{eval $selectreason = modreasonselect(0, 'userreasons')}-->
				<!--{if $selectreason}-->				
					 <ul id="reasonselect" class="selectoption" style="display:none;"><div>$selectreason</div></ul>					 	
				<!--{/if}-->			
			</div>          
			<!--{if $rateselfflag}-->
			<p class="qian ptn">{lang admin_rate}</p>
			<!--{/if}-->
            <p style="display:none;">
            <label for="sendreasonpm"><input type="checkbox" name="sendreasonpm" id="sendreasonpm" {if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />{lang admin_pm}</label>
            </p>
		</div>
        <div class="hm"><button name="ratesubmit" type="submit" value="true" class="formdialog button2" >{lang confirms}</button></div>
	</form>
	<!--{else}-->
	<form id="rateform" method="post" autocomplete="off" action="forum.php?mod=misc&action=rate&ratesubmit=yes&infloat=yes" onsubmit="ajaxpost('rateform', 'return_rate', 'return_rate', 'onerror');">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<input type="hidden" name="pid" value="$_GET[pid]" />
		<input type="hidden" name="referer" value="$referer" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="rate"><!--{/if}-->
		<div class="rate bb">
			<table cellspacing="0" cellpadding="0">
				<tr class="rate_tt">
					<th>{lang rate}</th>
					<td width="70">&nbsp;</td>
					<td>{lang rate_raterange}</td>
					<td>{lang enabled}</td>
				</tr>
				<!--{eval $rateselfflag = 0;}-->
				<!--{loop $ratelist $id $options}-->
				<tr>
					<th><!--{if $_G['setting']['extcredits'][$id][img]}-->{$_G['setting']['extcredits'][$id][img]} <!--{/if}-->{$_G['setting']['extcredits'][$id][title]}</th>
					<td>
						<div class="rate_select">
							<input type="text" name="score$id" id="score$id" type="number" value="0" />
							<a href="javascript:;" onclick="showselect(this, 'score$id', 'selectoption$id')"></a>
							<ul id="selectoption$id" class="selectoption" style="display:none"><div>$options</div></ul>
						</div>
					</td>
					<td>{$_G['group']['raterange'][$id]['min']} ~ {$_G['group']['raterange'][$id]['max']}</td>
					<!--{eval $rateselfflag = $_G['group']['raterange'][$id][isself] ? 1 : $rateselfflag;}-->
					<td>$maxratetoday[$id]</td>
				</tr>
				<!--{/loop}-->
			</table>
			<div class="rate_select explain_select">
				<input type="text" name="reason" id="reason" class="select" placeholder="{lang user_operation_explain}" />
				<a href="javascript:;" onclick="showselect(this, 'reason', 'reasonselect')"></a>
				<!--{eval $selectreason = modreasonselect(0, 'userreasons')}-->
				<!--{if $selectreason}-->
				<ul id="reasonselect" class="selectoption" style="display:none;"><div>$selectreason</div></ul>
				<!--{/if}-->
			</div>
			<!--{if $rateselfflag}-->
			<p class="qian ptn">{lang admin_rate}</p>
			<!--{/if}-->
			<p style="display:none;">
				<label for="sendreasonpm"><input type="checkbox" name="sendreasonpm" id="sendreasonpm" {if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />{lang admin_pm}</label>
			</p>
		</div>
		<div class="hm"><button name="ratesubmit" type="submit" value="true" class="formdialog button2" >{lang confirms}</button></div>
	</form>
	<!--{/if}-->
	<script type="text/javascript">
		function showselect(t){
			if($(t).siblings('.rate_select ul').css('display')=='none'){
				$('.selectoption').hide();
				$(t).siblings('.rate_select ul').show();
			}else{
				$(t).siblings('.rate_select ul').hide();
			}
		}
		$('.selectoption li').live('click',function(){
			$(this).parent().parent().siblings('.rate_select input').val($(this).text());
			$(this).parents('.rate_select ul').hide();
		});
		$('#reasonselect li').live('click',function(){
			$('#sendreasonpm').prop("checked",true);
		});
	</script>

<!--{elseif $_GET[action] == 'removerate'}-->

<form id="rateform" method="post" autocomplete="off" action="forum.php?mod=misc&action=removerate&ratesubmit=yes&infloat=yes">   
		<!--{if $_G['inajax']}-->
        <h3 class="rate_re_tt">
			{lang thread_removerate}			
            <em><a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" >{lang more}</a></em>
		</h3>
        <!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="tid" value="$_G[tid]">
		<input type="hidden" name="pid" value="$_GET[pid]">
		<input type="hidden" name="referer" value="$referer" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="rate"><!--{/if}-->
		<div class="rate_re{if !$_G['inajax']} ratelist_noajxa{/if}">
			<table class="list" cellspacing="0" cellpadding="0">
            <!--{if !$_G['inajax']}-->
				<thead>
					<tr>
						<th>&nbsp;</th>
						<th>{lang username}</th>
                        <!--{if !$_G['inajax']}-->
						<th>{lang time}</th>
                        <!--{/if}-->
						<th>{lang credits}</th>
                        <!--{if !$_G['inajax']}-->
						<th>{lang reason}</th>
                        <!--{/if}-->
					</tr>
				</thead>
			<!--{/if}-->
            <!--{loop $ratelogs $ratelog}-->
				<tr{if !$_G['inajax']} class="fz5"{/if}>
					<td width="22"><input type="checkbox" name="logidarray[]" value="$ratelog[uid] $ratelog[extcredits] $ratelog[dbdateline]" /></td>
					<td><a href="home.php?mod=space&uid=$ratelog[uid]">$ratelog[username]</a></td>
                    <!--{if !$_G['inajax']}-->
					<td>$ratelog[dateline]</td>
                    <!--{/if}-->
					<td>{$_G['setting']['extcredits'][$ratelog[extcredits]][title]} <span class="xw1">$ratelog[scoreview]</span> {$_G['setting']['extcredits'][$ratelog[extcredits]][unit]}</td>
					<!--{if !$_G['inajax']}-->
                    <td>$ratelog[reason]</td>
                    <!--{/if}-->
				</tr>
			<!--{/loop}-->
			</table>            
		</div>
    <div class="rate_re_explain{if $_G['inajax']} pbs bb{/if}">   
    <input name="reason" id="reason_exp" placeholder="{lang admin_operation_explain}" />
	<p style="display:none;"><label for="sendreasonpm"><input type="checkbox" name="sendreasonpm" id="sendreasonpm" {if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />{lang admin_pm}</label></p>
    </div>               
	<div class="{if $_G['inajax']}hm{else}b_pw{/if}"><button class="formdialog{if $_G['inajax']} button2{else} button5{/if}" type="submit" value="true" name="ratesubmit">{lang submit}</button></div>
</form>
			<script type="text/javascript">
				$('#reason_exp').on('keyup input', function() {
					var obj = $(this);
					if(obj.val()) {
						$('#sendreasonpm').prop("checked",true);
					}else{
						$('#sendreasonpm').prop("checked",false);
					}
				});									
			</script>
<!--{/if}-->
<!--{else}-->
<div class="r-block">{lang admin_threadtopicadmin_error}</div>
<!--{/if}-->

</div>
<!--{template common/footer}-->