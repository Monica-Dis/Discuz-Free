<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang forum_manager}<!--{/block}-->
<!--{template common/header}-->
<div class="bw">
<!--{if $script == 'noperm'}-->
        <div class="pt">{lang mod_option_error}</div>
        <div class="r-block">
        <p>{lang mod_error_invalid}</p>
        <p>{lang mod_notice}</p>
        </div>
<!--{elseif !empty($modtpl)}-->
	<!--{if in_array($script, array('member', 'login'))}-->
    	<!--{eval include(template($modtpl));}-->
    <!--{else}-->
    	<div class="r-block">
    	{lang admin_threadtopicadmin_error}
        </div>
    <!--{/if}-->
<!--{/if}-->
</div>
<!--{template common/footer}-->
