<?php echo 'From: DisM.taobao.com';exit;?>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/optionimgload.js?{VERHASH}"></script>
<div id="floatpost"></div>
<script type="text/javascript">
var emailnot = "{$langplus[emailnot]}";
var textnot = "{$langplus[textnot]}";
var numbernot = "{$langplus[numbernot]}";
var bignot = "{$langplus[bignot]}";
var smallnot = "{$langplus[smallnot]}";
var urlnot = "{$langplus[urlnot]}";
var innot = "{$langplus[innot]}";
$(document).ready(function() {
	$(document).on('click','.close_uploadimg',function(){			
		$('.uploadimg').remove()
	});
	$(document).on('click','.upbutton',function(){			
		$('.uploadimg').fadeOut();
	});
	$(document).on('change','.upbutton',function(){
		popup.open('<div class="lmVdjV39q3EP"></div>');
	});
});
</script>

  <div class="RNnJcA0sjIY7">
  <!--{if $sortid}-->
  <input type="hidden" name="sortid" value="$sortid" />
  <!--{/if}-->  
  <input type="hidden" name="selectsortid" size="45" value="$_G['forum_selectsortid']" />
  <table cellspacing="0" cellpadding="0" class="Lp297nbNjWfW">
    <!--{if $_G['forum']['threadsorts']['description'][$_G['forum_selectsortid']]}-->
    <tr>
      <th><div>{lang threadtype_description}</div></th>
      <td colspan="2">$_G[forum][threadsorts][description][$_G[forum_selectsortid]]</td>
    </tr>
    <!--{/if}--> 
    <!--{if $_G['forum']['threadsorts']['expiration'][$_G['forum_selectsortid']]}-->
    <tr>
      <th><div>{lang threadtype_expiration}</div></th>
      <td colspan="2"><div class="WWrPj11afyWV">
          <select name="typeexpiration" tabindex="1" id="typeexpiration">
            <option value="259200">{lang three_days}</option>
            <option value="432000">{lang five_days}</option>
            <option value="604800">{lang seven_days}</option>
            <option value="2592000">{lang one_month}</option>
            <option value="7776000">{lang three_months}</option>
            <option value="15552000">{lang half_year}</option>
            <option value="31536000">{lang one_year}</option>
          </select>
        </div>        
        <!--{if $_G['forum_optiondata']['expiration']}-->{lang valid_before}: $_G[forum_optiondata][expiration]<!--{/if}-->
        </td>
    </tr>
    <!--{/if}--> 
    <script type="text/javascript"> function $$(id) { return !id ? null : document.getElementById(id);} </script> 
    <!--{loop $_G['forum_optionlist'] $optionid $option}-->    
    <tr class="style_$option[identifier]">
        <th>
        <div>{if $option['required']}<span class="vl7LrSZVhug9">*</span>{/if}$option[title]</div>     
        </th>
        <td>        
        <div id="select_$option[identifier]" class="WWrPj11afyWV">           
          <!--{if in_array($option['type'], array('number', 'text', 'email', 'calendar', 'image', 'url', 'range', 'upload', 'range'))}-->
          <!--{if $option['type'] == 'calendar'}-->           
          <input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" tabindex="1" size="$option[inputsize]" onchange="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$option[value]" placeholder="{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}{if $option[description]}{$option[description]}{/if}{if $option['maxnum']}&nbsp;({lang maxnum} $option[maxnum]){/if}{if $option['minnum']}&nbsp;({lang minnum} $option[minnum]){/if}{if $option['maxlength']}&nbsp;({lang maxlength} $option[maxlength]){/if}{if $option['unchangeable']}&nbsp;({lang unchangeable}){/if}{/if}" $option[unchangeable] />          
					<!--{elseif $option['type'] == 'image'}-->
						<div id="sortattach_image_{$option[identifier]}" class="xdkz0g8ryJ1U">
						<!--{if $option['value']['url']}-->
							<div class="k7aGLZYzYOVF"><a href="$option[value][url]"><img src="$option[value][url]" /></a></div>
						<!--{/if}-->
						</div>
						<!--{if !($option[unchangeable] && $option['value'])}-->
						<button type="button" class="vOHbt7gptCtV" onclick="uploadWindow($_G[fid],function (aid, url){sortaid_{$option[identifier]}_upload(aid, url)})"><i class="AG5yZ3ftzshu"></i></button>
						<input type="hidden" name="typeoption[{$option[identifier]}][aid]" value="$option[value][aid]" id="sortaid_{$option[identifier]}" />
						<input type="hidden" name="sortaid_{$option[identifier]}_url" id="sortaid_{$option[identifier]}_url" />
						<!--{if $option[value]}--><input type="hidden" name="oldsortaid[{$option[identifier]}]" value="$option[value][aid]" tabindex="1" /><!--{/if}-->
						<input type="hidden" name="typeoption[{$option[identifier]}][url]" id="sortattachurl_{$option[identifier]}" {if $option[value][url]}value="$option[value][url]"{/if} tabindex="1" />
						<!--{/if}-->
						<script type="text/javascript" reload="1">
							function sortaid_{$option[identifier]}_upload(aid, url) {
								insert_id('sortaid_{$option[identifier]}_url').value = url;								
								updatesortattach(aid, url, '{$_G['setting']['attachurl']}forum', '{$option[identifier]}');
							}							
						</script>
          <!--{else}-->
          <input type="text" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" tabindex="1" size="$option[inputsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]'{if $option[maxnum]}, '$option[maxnum]'{else}, '0'{/if}{if $option[minnum]}, '$option[minnum]'{else}, '0'{/if}{if $option[maxlength]}, '$option[maxlength]'{/if})" value="{if $_G['tid']}$option[value]{else}{if $member_profile[$option['profile']]}$member_profile[$option['profile']]{else}$option['defaultvalue']{/if}{/if}" placeholder="{if $option['maxnum'] || $option['minnum'] || $option['maxlength'] || $option['unchangeable'] || $option[description]}{if $option[description]}{$option[description]}{/if}{if $option['maxnum']}&nbsp;({lang maxnum} $option[maxnum]){/if}{if $option['minnum']}&nbsp;({lang minnum} $option[minnum]){/if}{if $option['maxlength']}&nbsp;({lang maxlength} $option[maxlength]){/if}{if $option['unchangeable']}&nbsp;({lang unchangeable}){/if}{/if}" $option[unchangeable] />
          <!--{/if}--> 
          <!--{elseif in_array($option['type'], array('radio', 'checkbox', 'select'))}--> 
          <!--{if $option[type] == 'select'}-->           
          <!--{loop $option['value'] $selectedkey $selectedvalue}--> 
          <!--{if $selectedkey}--> 
          <script type="text/javascript">changeselectthreadsort('$selectedkey', $optionid, 'update');</script> 
          <!--{else}-->         
          <select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable]>
            <option value="0">{lang please_select}</option>
            <!--{loop $option['choices'] $id $value}--> 
            <!--{if !$value[foptionid]}-->
            <option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
            <!--{/if}--> 
            <!--{/loop}-->
          </select>          
          <!--{/if}--> 
          <!--{/loop}--> 
          <!--{if !is_array($option['value'])}-->          
          <select tabindex="1" onchange="changeselectthreadsort(this.value, '$optionid');checkoption('$option[identifier]', '$option[required]', '$option[type]')" $option[unchangeable] >
            <option value="0">{lang please_select}</option>
            <!--{loop $option['choices'] $id $value}--> 
            <!--{if !$value[foptionid]}-->
            <option value="$id">$value[content] <!--{if $value['level'] != 1}-->&raquo;<!--{/if}--></option>
            <!--{/if}--> 
            <!--{/loop}-->
          </select>         
          <!--{/if}--> 
          <!--{elseif $option['type'] == 'radio'}-->
          <ul class="rrKAI6oTNFYk">
            <!--{loop $option['choices'] $id $value}-->
            <li class="x8TJoSknmLee">              
                <input type="radio" name="typeoption[{$option[identifier]}]" id="typeoption_$option[identifier]" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id] $option[unchangeable] >
                <label>$value</label>
            </li>
            <!--{/loop}-->
          </ul>
          <!--{elseif $option['type'] == 'checkbox'}-->
          <ul class="rrKAI6oTNFYk">
            <!--{loop $option['choices'] $id $value}-->
            <li class="x8TJoSknmLee">
                <input type="checkbox" name="typeoption[{$option[identifier]}][]" id="typeoption_$option[identifier]" class="aBfZnyLDrNtl" tabindex="1" onclick="checkoption('$option[identifier]', '$option[required]', '$option[type]')" value="$id" $option['value'][$id][$id] $option[unchangeable] >
                <label>$value</label>
            </li>
            <!--{/loop}-->
          </ul>
          <!--{/if}--> 
          <!--{elseif in_array($option['type'], array('textarea'))}-->
          <textarea name="typeoption[{$option[identifier]}]" tabindex="1" id="typeoption_$option[identifier]" rows="$option[rowsize]" cols="$option[colsize]" onBlur="checkoption('$option[identifier]', '$option[required]', '$option[type]', 0, 0{if $option[maxlength]}, '$option[maxlength]'{/if})" $option[unchangeable]>$option[value]</textarea>
          <!--{/if}--> 
          $option[unit] </div>
          </td>
        <td class="MtSv1cRbiaji"><span id="check{$option[identifier]}"></span></td>
    </tr>    
    <!--{/loop}-->
  </table>
</div>
<script type="text/javascript" reload="1">
	var CHECKALLSORT = false;
	function warning(obj, msg) {
		obj.style.display = '';
		obj.innerHTML = '<i class="2vapxBfwd7kH"></i>';
		obj.className = "";
	}	
	function validateextra() {
		CHECKALLSORT = true;
		<!--{loop $_G['forum_optionlist'] $optionid $option}-->
			if(!checkoption('$option[identifier]', '$option[required]', '$option[type]')) {
				return false;
			}
		<!--{/loop}-->
		return true;
	}
	<!--{if $_G['forum']['threadsorts']['expiration'][$_G['forum_selectsortid']]}-->
		simulateSelect('typeexpiration');
	<!--{/if}-->
</script> 