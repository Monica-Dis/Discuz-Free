<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['forum_threadcount']}-->
<!--{template forum/displayorder}-->
<ul id="alist" class="HwKFWtPXAVEl">
    <!--{eval $ad = 1;}-->
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
    {eval continue;}
    <!--{/if}-->
    <!--{if $thread['displayorder'] > $threaddisplayorder}-->
    <!--{else}-->
    <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
    {eval $displayorder_thread = 1;}
    <!--{/if}-->
    <!--{if $thread['moved']}-->
    <!--{eval $thread[tid]=$thread[closed];}-->
    <!--{/if}-->
    <!--{hook/forumdisplay_middle_v2_mobile}-->
    <!--{if $page == 1}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adforumdisplaya && in_array($_G['fid'],(array)unserialize($adforumdisplayida)) && $ad == $adforumdisplaytha}--><!--{$adforumdisplaya}--><!--{/if}-->
    <!--{if $adforumdisplayb && in_array($_G['fid'],(array)unserialize($adforumdisplayidb)) && $ad == $adforumdisplaythb}--><!--{$adforumdisplayb}--><!--{/if}-->
    <!--{if $adforumdisplayc && in_array($_G['fid'],(array)unserialize($adforumdisplayidc)) && $ad == $adforumdisplaythc}--><!--{$adforumdisplayc}--><!--{/if}-->
    <!--{if $adforumdisplayd && in_array($_G['fid'],(array)unserialize($adforumdisplayidd)) && $ad == $adforumdisplaythd}--><!--{$adforumdisplayd}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{eval $msgnumber = 120; $imgnumber = 9; $recnumber = 4; $postnumber = 5;}-->
    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/threadlist.php');}-->
    <!--{if $threadshowmedia == 1}-->
    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/mediaplayer.php');}-->
    <!--{else}-->
    <!--{eval $mediaplayer = 0}-->
    <!--{/if}-->
    <!--{if $specialplugin == 0}--><!--{hook/forumdisplay_thread_mobile $key}--><!--{/if}-->
    <li class="fEvhJ9LUuJ6P">
        <!--{if $thread['authorid'] && $thread['author']}-->
        <a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="UoRZiAghxSa8"><img src="<!--{avatar($thread[authorid],middle,true)}-->" /></a>
        <!--{else}-->
        <a href="javascript:;" class="UoRZiAghxSa8"><img src="<!--{avatar($thread[authorid],middle,true)}-->" /></a>
        <!--{/if}-->
        <div class="EpRp4gnHNBzx">
            <p>
                <span class="lhcsTc3xRkO8">
                    <!--{if $thread['authorid'] && $thread['author']}-->
                    <a href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
                    <!--{else}-->
                    <a href="javascript:;">$_G[setting][anonymoustext]</a>
                    <!--{/if}-->
                </span>
                <!--{if $leveltype == 1}-->
                <!--{if $_G['cache']['usergroups'][$thread['groupid']][stars] > 0 }-->
                <i class="LgNEwtq1jDD7">Lv.{$_G['cache']['usergroups'][$thread['groupid']][stars]}</i>
                <!--{/if}-->
                <!--{elseif $leveltype == 2}-->
                <!--{if $_G['cache']['usergroups'][$thread['groupid']][stars] > 0 }-->
                <i class="P50uNzFJnLxa"{if $_G['cache']['usergroups'][$thread['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$thread['groupid']]['color']};"{/if}>Lv.{$_G['cache']['usergroups'][$thread['groupid']][stars]}</i>
                <!--{/if}-->
                <!--{else}-->
                <i class="P50uNzFJnLxa"{if $_G['cache']['usergroups'][$thread['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$thread['groupid']]['color']};"{/if}>{$_G['cache']['usergroups'][$thread['groupid']]['grouptitle']}</i>
                <!--{/if}-->
            </p>
            <!--{eval $thread['customstatus'] = DB::result_first("SELECT customstatus FROM ".DB::table("common_member_field_forum")." WHERE uid=".$thread['authorid']); }-->
            <!--{if $thread[customstatus]}--><span>$thread[customstatus]</span><!--{/if}-->
            <!--{if helper_access::check_module('follow')}-->
            <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]" class="0zamFtIKkZFj">{$langplus[follows]}</a>
            <!--{else}-->
            <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$thread[authorid]&handlekey=addfriendhk_{$thread[authorid]}" class="dialog_follow{if $_G['uid']} dialog{/if}">{$langplus[follows]}</a>
            <!--{/if}-->
        </div>
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="yUloUBxjglb3">
            <h1>
                <!--{if $thread['special'] == 1}-->
                <em>{lang thread_poll}</em> &middot;
                <!--{elseif $thread['special'] == 2}-->
                <em>{lang thread_trade}</em> &middot;
                <!--{elseif $thread['special'] == 3}-->
                <em>{lang thread_reward}</em> &middot;
                <!--{elseif $thread['special'] == 4}-->
                <em>{lang thread_activity}</em> &middot;
                <!--{elseif $thread['special'] == 5}-->
                <em>{lang thread_debate}</em> &middot;
                <!--{elseif $thread['displayorder'] > 0}-->
                <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;
                <!--{/if}-->
                <!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}-->
                <!--{if $_G['forum']['threadtypes']['types'][$thread['typeid']] && $_G['forum']['threadtypes']['prefix'] > 0}-->
                <em class="WAO1ETmvH49Y">#{echo strip_tags($_G['forum']['threadtypes']['types'][$thread['typeid']])}#</em>
                <!--{else}-->
                <!--{if $_G['forum']['threadsorts']['types'][$thread['sortid']] && $_G['forum']['threadsorts']['prefix'] > 0}-->
                <em class="WAO1ETmvH49Y">#{echo strip_tags($_G['forum']['threadsorts']['types'][$thread['sortid']])}#</em>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $thread[icon] >= 0}-->
                <em class="ZUp4byFwR1BK">#{$_G[cache][stamps][$thread[icon]][text]}#</em>
                <!--{else}-->
                <!--{if $thread[heatlevel]}-->
                <em class="Z1K9j6zHkkNq">#{lang order_heats}#</em>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $thread['digest'] > 0}-->
                <em class="GR92yicG3zyZ">#{$langplus[digest]}#</em>
                <!--{/if}-->
            </h1>
            <!--{if $thread['msg'] && ( !$thread['thumb'] && !$mediaplayer )}--><p>{$thread['msg']}</p><!--{/if}-->
            <!--{if $thread['thumb'] && !$mediaplayer}-->
            <!--{eval $picnumber = count($thread['thumb']); }-->
            <!--{if $picnumber == 1}-->
            <div class="eV6QZvlP57vk">
                <!--{loop $thread['thumb'] $attach}-->
                <!--{eval $imagethumb = getforumimg($attach['aid'], 0, 360, 0); }-->
                <img src="$imagethumb" />
                <!--{/loop}-->
            </div>
            <!--{elseif $picnumber == 2}-->
            <div class="3oUBU5xoDoYu">
                <!--{loop $thread['thumb'] $attach}-->
                <!--{eval $imagethumb = getforumimg($attach['aid'], 0, 300, 180); }-->
                <div><img src="$imagethumb" /></div>
                <!--{/loop}-->
            </div>
            <!--{else}-->
            <div class="UjUdLLZpI86a">
                <!--{loop $thread['thumb'] $attach}-->
                <!--{eval $imagethumb = getforumimg($attach['aid'], 0, 200, 180); }-->
                <div><img src="$imagethumb" /></div>
                <!--{/loop}-->
            </div>
            <!--{/if}-->
            <!--{/if}-->
        </a>
        <!--{if $mediaplayer}--><div class="Nv3u7UI1dTCw">$mediaplayer</div><!--{/if}-->
        <div class="hNOK3poJcpFf">
            <span>{$thread[dateline]}</span> <span class="RB4F49dgNi61">/</span>
            <!--{if $thread[replies]}-->
            <!--{if $thread[replies] > 9999 }-->
            <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{else}-->
            <!--{if $thread['isgroup'] != 1}-->
            <!--{if $thread[views] > 9999 }-->
            <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{else}-->
            <!--{if $groupnames[$thread[tid]][views] > 9999 }-->
            <!--{eval $groupnames[$thread[tid]][views] = round($groupnames[$thread[tid]][views] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}--><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->{$langplus[view]}<!--{/if}-->
            <p>
                <!--{if $thread['rate'] > 0}--><i class="ih2GBIpmzu4I"></i><!--{/if}-->
                <!--{if $thread[recommend_add] > 9999 }-->
                <!--{eval $thread[recommend_add] = round($thread[recommend_add] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $thread[favtimes] > 9999 }-->
                <!--{eval $thread[favtimes] = round($thread[favtimes] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $_G['setting']['recommendthread']['status']}-->
                <i class="NjmDx3gkHCuh"></i><span>{$thread[recommend_add]}</span>
                <!--{else}-->
                <i class="a4TcRfVF4aiG"></i><span>{$thread[favtimes]}</span>
                <!--{/if}-->
            </p>
        </div>
        <!--{if $thread[replies] > 0 || ($_G['setting']['recommendthread']['status'] && $thread[recommend_add] > 0)}-->
        <div class="e0zm1EQsubjr">
            <!--{if $_G['setting']['recommendthread']['status'] && $thread[recommend_add] > 0}-->
            <div class="1hmpU70tSKsx">
                <!--{if $thread[recommends] > 0}--><i class="Wh21Y2pBzti3"></i><!--{else}--><i class="UKfOChqXROBD"></i><!--{/if}-->
                <!--{loop $recommends_add $list}-->
                <a href="home.php?mod=space&uid=$list[recommenduid]&do=profile" class="7BGk338YxTn3"><img src="<!--{avatar($list[recommenduid],middle,true)}-->" /></a>
                <!--{/loop}-->
                <!--{if $thread[recommend_add] >= $recnumber}--><span>{$thread[recommend_add]}{$langplus[supporters]}</span><!--{/if}-->
            </div>
            <!--{/if}-->
            <!--{if $thread[replies] > 0}-->
            <ul{if $_G['setting']['recommendthread']['status'] && $thread[recommend_add] > 0} class="e7sc3Hk44Dnw"{/if}>
                <!--{loop $postlist $list}-->
                <li>
                    <!--{if $list['authorid'] && $list['author']}--><a href="home.php?mod=space&uid=$list[authorid]&do=profile" class="r9COG0I1EFgN">$list[author]</a><!--{else}--><a href="javascript:;" class="r9COG0I1EFgN">$_G[setting][anonymoustext]</a><!--{/if}-->: <!--{if messagecutstr($list['message'],100)}-->{echo messagecutstr($list['message'],100)}<!--{else}-->... <span class="Q8lZLnjHfm2v">[{$langplus[richtext]}]</span><!--{/if}-->
                </li>
                <!--{/loop}-->
            </ul>
<!--{/if}-->
</div>
<!--{/if}-->
</li>
<!--{/if}-->
<!--{eval $ad++;}-->
<!--{/loop}-->
</ul>
<!--{else}-->
<div class="sqK9gG26iUGb">{lang forum_nothreads}</div>
<!--{/if}-->