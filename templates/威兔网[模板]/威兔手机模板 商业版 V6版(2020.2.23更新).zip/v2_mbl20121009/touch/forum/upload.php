<?php echo 'From: DisM.taobao.com';exit;?>
<script type="text/javascript">
var cannot_kb = "{lang donotcross}",
cannot_files = "{lang uploadstatusmsg1}";
</script>
<div class="uploadimg" id="upload_img">
 <em id="uploadwindowing" style="display:none;"></em>  
  <div class="loadimg">
    <form id="uploadform" class="uploadform" method="post" autocomplete="off" target="uploadattachframe" onsubmit="uploadWindowstart()" action="misc.php?mod=swfupload&operation=upload&type=$type&inajax=yes&infloat=yes&simple=2" enctype="multipart/form-data">
      <input type="hidden" name="handlekey" value="upload" />
      <input type="hidden" name="uid" value="$_G['uid']">
      <input type="hidden" name="hash" value="{echo md5(substr(md5($_G['config']['security']['authkey']), 8).$_G['uid'])}">
      <a href="javascript:;" class="upbutton"><input type="file" name="Filedata" id="filedata" size="1" onchange="insert_id('uploadform').submit()" accept="image/*" /></a>      
    </form>
    <iframe name="uploadattachframe" id="uploadattachframe" style="display: none;" onload="uploadWindowload();"></iframe>
  </div>
  <div class="close_uploadimg"></div>
</div>
