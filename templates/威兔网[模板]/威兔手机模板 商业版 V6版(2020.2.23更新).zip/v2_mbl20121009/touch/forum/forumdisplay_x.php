<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
<!--{if $_G['forum_threadcount']}-->
<!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement) && $displayann == 1}-->
<div class="jsuzH0Ku2mIb"><i class="XiooH6pGoRAp"></i>
    <!--{if empty($announcement['type'])}--><a href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]">$announcement[subject]</a><!--{else}--><a href="$announcement[message]">$announcement[subject]</a><!--{/if}-->
</div>
<!--{/if}-->
<ul id="alist" class="HwKFWtPXAVEl">
    <!--{eval $ad = 1;}-->
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
    {eval continue;}
    <!--{/if}-->
    <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
    {eval $displayorder_thread = 1;}
    <!--{/if}-->
    <!--{if $thread['moved']}-->
    <!--{eval $thread[tid]=$thread[closed];}-->
    <!--{/if}-->
    <!--{hook/forumdisplay_middle_v2_mobile}-->
    <!--{if $page == 1}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adforumdisplaya && in_array($_G['fid'],(array)unserialize($adforumdisplayida)) && $ad == $adforumdisplaytha}--><!--{$adforumdisplaya}--><!--{/if}-->
    <!--{if $adforumdisplayb && in_array($_G['fid'],(array)unserialize($adforumdisplayidb)) && $ad == $adforumdisplaythb}--><!--{$adforumdisplayb}--><!--{/if}-->
    <!--{if $adforumdisplayc && in_array($_G['fid'],(array)unserialize($adforumdisplayidc)) && $ad == $adforumdisplaythc}--><!--{$adforumdisplayc}--><!--{/if}-->
    <!--{if $adforumdisplayd && in_array($_G['fid'],(array)unserialize($adforumdisplayidd)) && $ad == $adforumdisplaythd}--><!--{$adforumdisplayd}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <li class="0SjyuQop6KJp">
        <!--{if $specialplugin == 0}--><!--{hook/forumdisplay_thread_mobile $key}--><!--{/if}-->
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="th_item{if $thread[folder] == 'new'} foldernew{/if}">
            <h1>
                <!--{if $thread[folder] == 'lock'}-->
                <em>{lang close}</em> &middot;
                <!--{elseif $thread['special'] == 1}-->
                <em>{lang thread_poll}</em> &middot;
                <!--{elseif $thread['special'] == 2}-->
                <em>{lang thread_trade}</em> &middot;
                <!--{elseif $thread['special'] == 3}-->
                <em>{lang thread_reward}</em> &middot;
                <!--{elseif $thread['special'] == 4}-->
                <em>{lang thread_activity}</em> &middot;
                <!--{elseif $thread['special'] == 5}-->
                <em>{lang thread_debate}</em> &middot;
                <!--{elseif in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;
                <!--{elseif $thread['attachment'] == 2 && $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                <em class="0rM8odj7aKyi">$langplus[pic]</em> &middot;
                <!--{/if}-->
                <!--{if $thread['digest'] > 0}-->
                <em class="GR92yicG3zyZ">$langplus[digest]</em> &middot;
                <!--{/if}-->
                <!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}-->
                <!--{if $thread['rushreply']}-->
                <span class="DDhgGdFCeBwj"> - {lang rushreply}{if $rushinfo[$thread[tid]] == ''}{lang over}{/if}</span>
                <!--{/if}-->
                <!--{if $thread['price'] > 0}-->
                <span class="DDhgGdFCeBwj"> -
                    <!--{if $thread['special'] == '3'}-->
                    {lang thread_reward} $thread[price] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][2]][title]}
                    <!--{else}-->
                    {lang price} $thread[price] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][1]][title]}
                    <!--{/if}-->
                    </span>
                <!--{elseif $thread['special'] == '3' && $thread['price'] < 0}-->
                <span class="DDhgGdFCeBwj"> - {lang reward_solved}</span>
                <!--{/if}-->
                <!--{if $thread['replycredit'] > 0}-->
                <span class="DDhgGdFCeBwj"> - {lang replycredit}</span>
                <!--{/if}-->
            </h1>
            <div class="hNOK3poJcpFf">
                <!--{if $thread['authorid'] && $thread['author']}--><span>$thread[author]</span><!--{else}--><span>$_G[setting][anonymoustext]</span><!--{/if}-->
                <span>{$thread[dateline]}</span>
                <!--{if $_G['forum']['threadtypes']['types'][$thread['typeid']] && $_G['forum']['threadtypes']['prefix'] > 0}-->
                <span class="WAO1ETmvH49Y">#{echo strip_tags($_G['forum']['threadtypes']['types'][$thread['typeid']])}</span>
                <!--{else}-->
                <!--{if $_G['forum']['threadsorts']['types'][$thread['sortid']] && $_G['forum']['threadsorts']['prefix'] > 0}-->
                <span class="WAO1ETmvH49Y">#{echo strip_tags($_G['forum']['threadsorts']['types'][$thread['sortid']])}</span>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $thread[icon] >= 0}-->
                <span class="ZUp4byFwR1BK">#{$_G[cache][stamps][$thread[icon]][text]}</span>
                <!--{else}-->
                <!--{if $thread[heatlevel]}-->
                <span class="Z1K9j6zHkkNq">#{lang order_heats}</span>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $thread[replies]}-->
                <!--{if $thread[replies] > 9999 }-->
                <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $thread['isgroup'] != 1}-->
                <!--{if $thread[views] > 9999 }-->
                <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $groupnames[$thread[tid]][views] > 9999 }-->
                <!--{eval $groupnames[$thread[tid]][views] = round($groupnames[$thread[tid]][views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->
                <span class="99u2LxYcMOhO"><!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}--><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->{$langplus[view]}<!--{/if}--></span>
            </div>
        </a>
    </li>
    <!--{eval $ad++;}-->
    <!--{/loop}-->
</ul>
<!--{else}-->
<div class="sqK9gG26iUGb">{lang forum_nothreads}</div>
<!--{/if}-->
            		        
<!--{else}-->

<!--{if $_G['forum_threadcount']}-->
<ul id="alist" class="o1D1Ems6yCNi">
    <!--{eval $ad = 1;}-->
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
    {eval continue;}
    <!--{/if}-->
    <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
    {eval $displayorder_thread = 1;}
    <!--{/if}-->
    <!--{if $thread['moved']}-->
    <!--{eval $thread[tid]=$thread[closed];}-->
    <!--{/if}-->
    <!--{hook/forumdisplay_middle_v2_mobile}-->
    <!--{if $page == 1}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adforumdisplaya && in_array($_G['fid'],(array)unserialize($adforumdisplayida)) && $ad == $adforumdisplaytha}--><!--{$adforumdisplaya}--><!--{/if}-->
    <!--{if $adforumdisplayb && in_array($_G['fid'],(array)unserialize($adforumdisplayidb)) && $ad == $adforumdisplaythb}--><!--{$adforumdisplayb}--><!--{/if}-->
    <!--{if $adforumdisplayc && in_array($_G['fid'],(array)unserialize($adforumdisplayidc)) && $ad == $adforumdisplaythc}--><!--{$adforumdisplayc}--><!--{/if}-->
    <!--{if $adforumdisplayd && in_array($_G['fid'],(array)unserialize($adforumdisplayidd)) && $ad == $adforumdisplaythd}--><!--{$adforumdisplayd}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $specialplugin == 0}--><!--{hook/forumdisplay_thread_mobile $key}--><!--{/if}-->
    <li class="yUloUBxjglb3">
        <div class="ghp7Duf7hZ4L">
            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="zxNeFJajQSZ0">
                <p>
                    <!--{if $thread['cover']}-->
                    <img src="$thread[coverpath]" />
                    <!--{else}-->
                    <img src="template/v2_mbl20121009/touch_plus/image/nophoto.jpg" />
                    <!--{/if}-->
                </p>
                <h1>{$thread[subject]}</h1>
            </a>
            <div class="EpRp4gnHNBzx">
                <img src="{avatar($thread[authorid],middle,true)}" />
                <!--{if $thread['authorid'] && $thread['author']}-->
                <a href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
                <!--{else}-->
                <a href="javascript:;">$_G[setting][anonymoustext]</a>
                <!--{/if}-->
                <!--{if $thread['rate'] > 0}-->
                <i class="ih2GBIpmzu4I"></i>
                <!--{else}-->
                <!--{if $_G['setting']['recommendthread']['status']}-->
                <!--{if $thread[recommends] > 0}--><i class="Wh21Y2pBzti3"></i><!--{else}--><i class="UKfOChqXROBD"></i><!--{/if}-->
                <!--{else}-->
                <!--{if $thread[favtimes] > 0}--><i class="c5jXKWHqTOsX"></i><!--{else}--><i class="a4TcRfVF4aiG"></i><!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->
            </div>
        </div>
    </li>
    <!--{eval $ad++;}-->
    <!--{/loop}-->
</ul>
<!--{else}-->
<div class="sqK9gG26iUGb">{lang forum_nothreads}</div>
<!--{/if}-->
<!--{block footerbib}--><i class="WKeZSMVfZ14F"></i><!--{/block}-->
<!--{/if}-->