<?php exit('QQ:32-77558-32');?>
<!--{block header_name}--><span class="HZdCN4YZLteK">{$_G['forum']['name']}</span><!--{/block}-->
<!--{template common/header}-->
<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->
<!--{eval $favstate = C::t('home_favorite')->fetch_by_id_idtype($_G['fid'],'fid',$_G['uid']);}-->
<!--{if !$subforumonly}-->
<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
<!--{if in_array($_G['fid'],(array)unserialize($forumheaderno))}--><!--{else}-->
<!--{if $_G['page'] == 1}-->
<!--{if $_G[forum][threads] > 9999 }-->
<!--{eval $_G[forum][threads] = round($_G[forum][threads] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->
<!--{if $_G[forum][posts] > 9999 }-->
<!--{eval $_G[forum][posts] = round($_G[forum][posts] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->
<!--{if $_G[forum][todayposts] > 9999 }-->
<!--{eval $_G[forum][todayposts] = round($_G[forum][todayposts] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->
<!--{if in_array($_G['fid'],(array)unserialize($forumheaderpic))}-->
<style type="text/css">header { height:auto; } .header { background:none; } .header span.forum_title { opacity:0; }</style>
<!--{eval $forum['description'] = DB::result_first("SELECT description FROM ".DB::table("forum_forumfield")." where fid=".$_G['fid']);}-->
<!--{eval $forum['descriptionabb'] = cutstr(strip_tags($forum['description']),120);}-->
<!--{if $forum['description']}-->
<div class="forumname_licon{if $sortmenufloat} sortrollheight{/if}" style="background-image: url('{if $_G[forum][banner]}{$_G[forum][banner]}{else}{if $forumheaderbg}{$forumheaderbg}{else}template/v2_mbl20121009/touch_plus/img/forumicon/{$_G['forum']['fid']}.jpg{/if}{/if}');">
    <div class="kcsl3nIVhdaP">
        <a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}" class="xSW0cepMhyqr"><!--{if $_G['forum'][icon]}--><img src="{$_G['setting']['attachurl']}/common/$_G['forum'][icon]"><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $_G[forum][todayposts] > 0}_new{/if}.png"/><!--{/if}--></a>
        <h1><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">{$_G['forum']['name']}</a></h1>
        <p class="KY40utOnH2DY">$forum['descriptionabb']</p>
    </div>
    <div class="hdJP9w7BJVy7"><!--{if in_array($_G['fid'],(array)unserialize($viewvideos))}-->{$langplus[video]}<!--{elseif in_array($_G['fid'],(array)unserialize($viewmusics))}-->{$langplus[music]}<!--{else}-->{lang index_threads}<!--{/if}--><span>$_G[forum][threads]</span><em>|</em>{lang index_today}<span>$_G[forum][todayposts]</span></div>
    <!--{if $favstate && $_G['uid']}-->
    <a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="m2syzICMiMmz">{$langplus[favorite_in]}</a>
    <!--{else}-->
    <a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}" class="qJ53erYtfvtk" >{$langplus[favorite]}</a>
    <!--{/if}-->
</div>
<!--{else}-->
<div class="forumname_cicon{if $sortmenufloat} sortrollheight{/if}" style="background-image: url('{if $_G[forum][banner]}{$_G[forum][banner]}{else}{if $forumheaderbg}{$forumheaderbg}{else}template/v2_mbl20121009/touch_plus/img/forumicon/{$_G['forum']['fid']}.jpg{/if}{/if}');">
    <a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}" class="xSW0cepMhyqr"><!--{if $_G['forum'][icon]}--><img src="{$_G['setting']['attachurl']}/common/$_G['forum'][icon]"><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $_G[forum][todayposts] > 0}_new{/if}.png"/><!--{/if}--></a>
    <h1><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">{$_G['forum']['name']}</a></h1>
    <p><!--{if in_array($_G['fid'],(array)unserialize($viewvideos))}-->{$langplus[video]}<!--{elseif in_array($_G['fid'],(array)unserialize($viewmusics))}-->{$langplus[music]}<!--{else}-->{lang index_threads}<!--{/if}--><span>$_G[forum][threads]</span><em>|</em>{lang index_posts}<span>$_G[forum][posts]</span><em>|</em>{lang index_today}<span>$_G[forum][todayposts]</span></p>
</div>
<!--{/if}-->
<!--{if $headershow}-->
<script type="text/javascript">
$(window).scroll(function(){	
	var hexvalue = '{$tplcolorcssa}';
	var rgx = /^#?([a-f\d])([a-f\d])([a-f\d])$/i;
	var hex = hexvalue.replace(rgx, (m, r, g, b) => r + r + g + g + b + b );
	var rgb = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
	var r = parseInt(rgb[1], 16);
	var g = parseInt(rgb[2], 16);
	var b = parseInt(rgb[3], 16);
	var a = $(window).scrollTop() / 150;
	if(a < '1'){
		$(".header").attr("style","background-color: rgba("+r+","+g+","+b+","+a+") !important;");
		$(".forum_title").attr("style","opacity:"+a+";");
	}else{
		$(".header").attr("style","background-color: rgba("+r+","+g+","+b+",1) !important;");
		$(".forum_title").attr("style","opacity:1;");
	}	
})
</script>
<!--{/if}-->
<!--{else}-->
<div class="forumname{if $sortmenufloat} sortrollheight{/if}">
    <a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}" class="xSW0cepMhyqr"><!--{if $_G['forum'][icon]}--><img src="{$_G['setting']['attachurl']}/common/$_G['forum'][icon]" ><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $_G[forum][todayposts] > 0}_new{/if}.png"/><!--{/if}--></a>
    <h1><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">$_G['forum'][name]</a></h1>
    <p><!--{if in_array($_G['fid'],(array)unserialize($viewvideos))}-->{$langplus[video]}<!--{elseif in_array($_G['fid'],(array)unserialize($viewmusics))}-->{$langplus[music]}<!--{else}-->{lang index_threads}<!--{/if}--><span>$_G[forum][threads]</span> &nbsp; {lang index_today}<span>$_G[forum][todayposts]</span></p>
    <!--{if $favstate && $_G['uid']}-->
    <a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="m2syzICMiMmz">{$langplus[favorite_in]}</a>
    <!--{else}-->
    <a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}" class="qJ53erYtfvtk" >{$langplus[favorite]}</a>
    <!--{/if}-->
</div>
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
<!--{if $brtnav == 1 && $_G['page'] > 1 && !in_array($_G['fid'],(array)unserialize($tplfidsg))}-->
<div class="3jFBf3583NdA">
    <a href="forum.php?forumlist=1">{$langplus[bbs]}</a><!--{if $_G['forum']['type'] == 'forum'}--><span>&gt;</span><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">$_G['forum']['name']</a><!--{else}--><span>&gt;</span><a href="forum.php?mod=forumdisplay&fid={$forum_up['fid']}">$forum_up['name']</a><span>&gt;</span>$_G['forum']['name']<!--{/if}-->
</div>
<!--{/if}-->
<!--{/if}-->
<!--{if $_G['forum']['threadsorts'] && in_array($_G['fid'],(array)unserialize($openthreadsorts))}-->
<!--{if $sortmenufloat}--><div class="OkTEfU7mYgXw"><!--{/if}-->
<div class="slidemenu{if $sortmenufloat} sortmenus{/if}">
    <div class="KPLQhDcwwS9y">
        <ul class="xCcmihVIrcBI">
            <li class="menu_slide{if !$_GET['sortid']} a{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a></li>
            <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
            <!--{if $_GET['sortid'] == $id}-->
            <li class="5WSPsIoXJ3Pv"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
            <!--{else}-->
            <li class="isoHbnnmNkPl"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
            <!--{/if}-->
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{if $sortmenufloat}--></div><!--{/if}-->
<!--{elseif $_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable'] && in_array($_G['fid'],(array)unserialize($openthreadtypes))}-->
<!--{if $sortmenufloat}--><div class="OkTEfU7mYgXw"><!--{/if}-->
<div class="slidemenu{if $sortmenufloat} sortmenus{/if}">
    <div class="KPLQhDcwwS9y">
        <ul class="xCcmihVIrcBI">
            <li class="menu_slide{if !$_GET['typeid']} a{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a></li>
            <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
            <!--{if $_GET['typeid'] == $id}-->
            <li class="5WSPsIoXJ3Pv"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
            <!--{else}-->
            <li class="isoHbnnmNkPl"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
            <!--{/if}-->
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{if $sortmenufloat}--></div><!--{/if}-->
<!--{else}-->
<!--{if $sortmenufloat}--><div class="OkTEfU7mYgXw"><!--{/if}-->
<div class="tabequal{if $sortmenufloat} sortmenus{/if}">
    <ul>
        <li{if $_GET['filter'] != 'heat' && $_GET['filter'] != 'digest' && $_GET['filter'] != 'lastpost'} class="04klkBou7Siv"{/if}>
        <!--{if $_GET['typeid']}-->
        <!--{if $_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']}-->
        <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
        <!--{if $_GET['typeid'] == $id}-->
        <a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a>
        <!--{/if}-->
        <!--{/loop}-->
        <!--{/if}-->
        <!--{else}-->
        <a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang forum_viewall}</a>
        <!--{/if}-->
        </li>
        <li{if $_GET['filter'] == 'lastpost'} class="04klkBou7Siv"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang latest}</a></li>
        <li{if $_GET['filter'] == 'heat'} class="04klkBou7Siv"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang order_heats}</a></li>
        <li{if $_GET['filter'] == 'digest'} class="04klkBou7Siv"{/if}><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang digest_posts}</a></li>
    </ul>
</div>
<!--{if $sortmenufloat}--></div><!--{/if}-->
<!--{/if}-->
<!--{if $_G['forum']['threadsorts'] || ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable'] && $openthreadtypes)}-->
<script src="./template/v2_mbl20121009/touch_plus/js/swiper.min.js?{VERHASH}"></script>
<script type="text/javascript">
    $(function() {
        if ($('.slidemenu .a').length > 0) {
            var slidefocus = $('.slidemenu .a').offset().left + $('.slidemenu .a').width() >= $(window).width() ? $('.slidemenu .a').index() : 0;
        } else {
            var slidefocus = 0;
        }
        var swiper = new Swiper('.menu_container', {
            wrapperClass:'menu_wrapper',
            slideClass:'menu_slide',
            slidesPerView:'auto',
            freeMode:true,
            freeModeFluid:true,
            momentumBounce:true,
            initialSlide:slidefocus,
        });
    })
</script>
<!--{/if}-->
<!--{if $quicksearchlist && !$_GET['archiveid'] && !in_array($_G['fid'],(array)unserialize($tplfidsg))}-->
<!--{subtemplate forum/search_sortoption}-->
<!--{/if}-->  
<div class="aR7XQ66l5zPc">
<div class="2cY39sDVnH9u">
    <!--{if in_array($_G['fid'],(array)unserialize($tplfidsg))}-->
    <!--{if $favstate && $_G['uid']}-->
    <a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="m2syzICMiMmz">{$langplus[favorite_in]}</a>
    <!--{else}-->
    <a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}" class="qJ53erYtfvtk" >{$langplus[favorite]}</a>
    <!--{/if}-->
    <!--{/if}-->
    <span class="m2jKwr7fspzN"></span>{lang forum_threads}{$langplus[filter]}</div>
<div class="O2jGc6Qkl9Jg">
    <!--{if $showpoll || $showtrade || $showreward || $showactivity || $showdebate}-->
    <ul>
        <span>{$langplus[posts_type]}:</span>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['specialtype'] != 'poll' && $_GET['specialtype'] != 'trade' && $_GET['specialtype'] != 'reward' && $_GET['specialtype'] != 'activity' && $_GET['specialtype'] != 'debate'} class="04klkBou7Siv"{/if}>{lang forum_viewall}</a></li>
        <!--{if $showpoll}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=poll$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['specialtype'] == 'poll'} class="04klkBou7Siv"{/if}>{lang thread_poll}</a></li><!--{/if}-->
        <!--{if $showtrade}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=trade$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['specialtype'] == 'trade'} class="04klkBou7Siv"{/if}>{lang thread_trade}</a></li><!--{/if}-->
        <!--{if $showreward}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['specialtype'] == 'reward'} class="04klkBou7Siv"{/if}>{lang thread_reward}</a></li><!--{/if}-->
        <!--{if $showactivity}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=activity$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['specialtype'] == 'activity'} class="04klkBou7Siv"{/if}>{lang thread_activity}</a></li><!--{/if}-->
        <!--{if $showdebate}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=debate$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['specialtype'] == 'debate'} class="04klkBou7Siv"{/if}>{lang thread_debate}</a></li><!--{/if}-->
    </ul>
    <!--{/if}-->
    <!--{if $_GET['specialtype'] == 'reward'}-->
    <ul>
        <span>{lang thread_reward}:</span>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{lang all_reward}</a></li>
        <!--{if $showpoll}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=1">{lang rewarding}</a></li><!--{/if}-->
        <!--{if $showtrade}--><li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=specialtype&specialtype=reward$forumdisplayadd[specialtype]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}&rewardtype=2">{lang reward_solved}</a></li><!--{/if}-->
    </ul>
    <!--{/if}-->
    <!--{if $quicksearchlist && !$_GET['archiveid']}--><!--{else}-->
    <ul>
        <span>{$langplus[filter]}:</span>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=lastpost&orderby=lastpost$forumdisplayadd[lastpost]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['filter'] == 'lastpost'} class="04klkBou7Siv"{/if}>{lang latest}</a></li>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=heat&orderby=heats$forumdisplayadd[heat]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['filter'] == 'heat'} class="04klkBou7Siv"{/if}>{lang order_heats}</a></li>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['filter'] == 'digest' || $_GET['digest'] == '1'} class="04klkBou7Siv"{/if}>{lang digest_posts}</a></li>
    </ul>
    <!--{/if}-->
    <ul>
        <span>{lang orderby}:</span>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['orderby'] == 'dateline'} class="04klkBou7Siv"{/if}>{lang list_post_time}</a></li>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['orderby'] == 'replies'} class="04klkBou7Siv"{/if}>{lang replies}</a></li>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['orderby'] == 'views'} class="04klkBou7Siv"{/if}>{lang views}</a></li>
    </ul>
    <ul>
        <span>{lang time}:</span>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if !$_GET['dateline']} class="04klkBou7Siv"{/if}>{lang all}{lang search_any_date}</a></li>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['dateline'] == '86400'} class="04klkBou7Siv"{/if}>{lang last_1_days}</a></li>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['dateline'] == '172800'} class="04klkBou7Siv"{/if}>{lang last_2_days}</a></li>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['dateline'] == '604800'} class="04klkBou7Siv"{/if}>{lang list_one_week}</a></li>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['dateline'] == '2592000'} class="04klkBou7Siv"{/if}>{lang list_one_month}</a></li>
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}"{if $_GET['dateline'] == '7948800'} class="04klkBou7Siv"{/if}>{lang list_three_month}</a></li>
    </ul>
    <!--{if $_G['forum']['threadsorts'] && !in_array($_G['fid'],(array)unserialize($openthreadsorts))}-->
    <ul>
        <span>{$langplus[information]}:</span>

        <!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
        <!--{if $_GET['sortid'] == $id}-->
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="04klkBou7Siv">$name</a></li>
        <!--{else}-->
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
        <!--{/if}-->
        <!--{/loop}-->
    </ul>
    <!--{/if}-->
    <!--{if $_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable'] && !in_array($_G['fid'],(array)unserialize($openthreadtypes))}-->
    <ul>
        <span>{$langplus[threadtypes]}:</span>
        <!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
        <!--{if $_GET['typeid'] == $id}-->
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="04klkBou7Siv">$name</a></li>
        <!--{else}-->
        <li><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
        <!--{/if}-->
        <!--{/loop}-->
    </ul>
    <!--{/if}-->
    <!--{if $subexists && !in_array($_G['fid'],(array)unserialize($opensubforum))}-->
    <ul>
        <span style="top:8px;">{$langplus[subforums]}:</span>
        <!--{loop $sublist $sub}-->
        <li class="8nKAnPhvXZ8l">
            <a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
                <!--{if $sub[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $sub['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $sub[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
                <h1{if !empty($sub[extra][namecolor])}style="color: {$sub[extra][namecolor]};"{/if}>{$sub[name]}</h1>
                <!--{if $sub[todayposts] > 0}--><i title="$sub[todayposts]"></i><!--{/if}-->
            </a>
        </li>
        <!--{/loop}-->
    </ul>
    <!--{/if}-->
</div>
</div>
<!--{/if}-->

<!--{if ($subexists && in_array($_G['fid'],(array)unserialize($opensubforum))) || $subforumonly}-->
<div{if !$subforumonly} class="VdOkPYDQsR5b"{/if}>
<ul id="sub_forum_$cat[fid]" class="sub_forum{if $_G['forum']['forumcolumns']} ptn{if $_G['forum']['forumcolumns'] <= 3} pbw{else} pbs{/if}{else}{if $subforumonly} bb{/if}{/if}">
    <!--{loop $sublist $sub}-->
    <!--{if $_G['forum']['forumcolumns']}-->
    <!--{if $_G['forum']['forumcolumns'] < 3}-->
    <li class="8nKAnPhvXZ8l">
        <a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
            <!--{if $sub[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $sub['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $sub[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
            <h1{if !empty($sub[extra][namecolor])}style="color: {$sub[extra][namecolor]};"{/if}>{$sub[name]}</h1>
            <!--{if $sub[todayposts] > 0}--><i title="$sub[todayposts]"></i><!--{/if}-->
        </a>
    </li>
    <!--{else}-->
    <li class="horizontal{if $_G['forum']['forumcolumns'] == 3} threerows{/if}">
        <a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">
            <!--{if $sub[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $sub['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $sub[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
            <h1{if !empty($sub[extra][namecolor])}style="color: {$sub[extra][namecolor]};"{/if}>{$sub[name]}</h1>
            <!--{if $sub[todayposts] > 0}--><i title="$sub[todayposts]"></i><!--{/if}-->
        </a>
    </li>
    <!--{/if}-->
    <!--{else}-->
    <li class="q9L3fP8xExHK">
        <a href="forum.php?mod=forumdisplay&fid={$sub[fid]}"{if $sub[todayposts] > 0} class="R7Wo7XW5XAtN"{/if}>
            <!--{if $sub[icon]}--><img src="{echo preg_replace('/.*<img src="(.+?)".*/i', '$1', $sub['icon']);}" /><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $sub[todayposts] > 0}_new{/if}.png"/><!--{/if}-->
            <h1{if !empty($sub[extra][namecolor])}style="color: {$sub[extra][namecolor]};"{/if}>{$sub[name]}</h1>
            <!--{if $sub['redirect']}-->
            <p>{lang url_link}</p>
            <!--{else}-->
            <!--{if $sub[description]}-->
            <p>{echo strip_tags($sub[description])}</p>
            <!--{else}-->
            <!--{if $sub[threads] > 9999 }-->
            <!--{eval $sub[threads] = round($sub[threads] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{if $sub[posts] > 9999 }-->
            <!--{eval $sub[posts] = round($sub[posts] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{if empty($sub[redirect])}--><p>{lang forum_threads} <!--{echo dnumber($sub[threads])}--> &nbsp; {$langplus[forum_posts]} <!--{echo dnumber($sub[posts])}--></p><!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $sub[todayposts] > 0}--><em title="{$sub[todayposts]}">{$sub[todayposts]}</em><!--{/if}-->
        </a>
    </li>
    <!--{/if}-->
    <!--{/loop}-->
</ul>
</div>
<!--{/if}-->

<!--{if in_array($_G['fid'],(array)unserialize($forumheaderpic)) && $forum['description']}-->
<!--{eval $forum['descriptionall'] = strip_tags($forum['description']);}-->
<div class="IXQ1R6mEYoTY">
    <div class="r4HxmDkG5qOz"><span class="m2jKwr7fspzN"></span></div>
    <div class="O2jGc6Qkl9Jg">
        <div class="hm8haemqQwqh">
            <a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}" class="xSW0cepMhyqr"><!--{if $_G['forum'][icon]}--><img src="{$_G['setting']['attachurl']}/common/$_G['forum'][icon]"><!--{else}--><img src="template/v2_mbl20121009/touch_plus/image/forum{if $_G[forum][todayposts] > 0}_new{/if}.png"/><!--{/if}--></a>
            <h1><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">{$_G['forum']['name']}</a></h1>
            <p>$forum['descriptionall']</p>
        </div>
    </div>
</div>
<!--{/if}-->

<!--{if !$subforumonly}-->

<!--{if in_array($_G['fid'],(array)unserialize($tplfidsa))}-->
<!--{template forum/forumdisplay_a}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidsb))}-->
<!--{template forum/forumdisplay_b}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidsc))}-->
<!--{template forum/forumdisplay_c}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidsd))}-->
<!--{template forum/forumdisplay_d}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidse))}-->
<!--{template forum/forumdisplay_e}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidsf))}-->
<!--{template forum/forumdisplay_f}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidsg))}-->
<!--{template forum/forumdisplay_g}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidsh))}-->
<!--{template forum/forumdisplay_h}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidsi))}-->
<!--{template forum/forumdisplay_i}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidsj))}-->
<!--{template forum/forumdisplay_j}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($tplfidsk))}-->
<!--{if empty($_G['forum']['sortmode'])}-->
<div class="AGIXSh5ow2Ai">{$langplus[nothreadsorts]}<br /><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}" class="ksgdWFZRY4wD">{lang back}</a></div>
<!--{else}-->
<div id="alist" class="zwszNP37Klyf">
$sorttemplate['header']
$sorttemplate['body']
$sorttemplate['footer']
</div>
<!--{/if}-->
<!--{else}-->
<!--{template forum/forumdisplay_x}-->
<!--{/if}-->

<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil($_G['forum_threadcount'] / $_G['tpp']);}-->
<!--{if $totalpage > $page}-->
<a href="$multipage_more" class="eMpHsVJ7jUAD" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->

<!--{/if}-->
<!-- main threadlist end -->
<!--{if !$subforumonly || (in_array($_G['fid'],(array)unserialize($forumheaderpic)) && $forum['description'])}-->
<script type="text/javascript">
    $(document).ready(function(){
        <!--{if !$subforumonly}-->
        $('.scroll_sort').click(function(){
            $('.sortmenufly').addClass('infly');
            $('body').addClass('menufly_open');
        });
        <!--{/if}-->
        <!--{if in_array($_G['fid'],(array)unserialize($forumheaderpic)) && $forum['description']}-->
        $('.forumname_dp').click(function(){
            $('.descriptionfly').addClass('infly');
            $('body').addClass('menufly_open');
        });
        <!--{/if}-->
        $('.vt-close').click(function(){
            $('.menufly').removeClass('infly');
            $('body').removeClass('menufly_open');
        });
    });
</script>
<!--{/if}-->
<!--{if !$subforumonly || in_array($_G['fid'],(array)unserialize($tplfidsg))}-->
<!--{block scrollplus}-->
<div class="LF9scR0aD0no"><!--{if in_array($_G['fid'],(array)unserialize($tplfidsg))}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="gb1EvDjBUSom"></a><!--{/if}--><!--{if !$subforumonly}--><a href="javascript:;" class="tYbALCr7oQyr"></a><!--{/if}--></div>
<!--{/block}-->
<!--{/if}-->
<!--{hook/forumdisplay_bottom_mobile}-->
<!--{if !$nofooter && $footershow}-->
<!--{template touch/mytpl/menubottom}-->
<!--{/if}-->
<!--{template common/footer}-->