<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['forum_threadcount']}-->
<!--{template forum/displayorder}-->
<ul id="alist" class="HwKFWtPXAVEl">
    <!--{eval $ad = 1;}-->
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
    {eval continue;}
    <!--{/if}-->
    <!--{if $thread['displayorder'] > $threaddisplayorder}-->
    <!--{else}-->
    <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
    {eval $displayorder_thread = 1;}
    <!--{/if}-->
    <!--{if $thread['moved']}-->
    <!--{eval $thread[tid]=$thread[closed];}-->
    <!--{/if}-->
    <!--{hook/forumdisplay_middle_v2_mobile}-->
    <!--{if $page == 1}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adforumdisplaya && in_array($_G['fid'],(array)unserialize($adforumdisplayida)) && $ad == $adforumdisplaytha}--><!--{$adforumdisplaya}--><!--{/if}-->
    <!--{if $adforumdisplayb && in_array($_G['fid'],(array)unserialize($adforumdisplayidb)) && $ad == $adforumdisplaythb}--><!--{$adforumdisplayb}--><!--{/if}-->
    <!--{if $adforumdisplayc && in_array($_G['fid'],(array)unserialize($adforumdisplayidc)) && $ad == $adforumdisplaythc}--><!--{$adforumdisplayc}--><!--{/if}-->
    <!--{if $adforumdisplayd && in_array($_G['fid'],(array)unserialize($adforumdisplayidd)) && $ad == $adforumdisplaythd}--><!--{$adforumdisplayd}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{eval $msgnumber = 120; $imgnumber = 1;}-->
    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/threadlist.php');}-->
    <!--{if $specialplugin == 0}--><!--{hook/forumdisplay_thread_mobile $key}--><!--{/if}-->
    <li class="JRP4GGIJsSV5">
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="yUloUBxjglb3" >
            <!--{if $thread['thumbfirst']}-->
            <!--{eval $imagethumb = getforumimg($thread['thumbfirst'], 0, 600, 330); }-->
            <div class="eV6QZvlP57vk"><img src="$imagethumb" /></div>
            <!--{/if}-->
            <h1>
                <!--{if $thread['displayorder'] > 0}-->
                <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;
                <!--{/if}-->
                <!--{if $thread['digest'] > 0}-->
                <em class="GR92yicG3zyZ">$langplus[digest]</em> &middot;
                <!--{/if}-->
                <!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}-->
            </h1>
            <!--{if !$thread['thumb']}-->
            <!--{if $thread['msg']}--><p>{$thread['msg']}</p><!--{/if}-->
            <!--{/if}-->
            <div class="hNOK3poJcpFf">
                <!--{if $thread['rate'] > 0}--><i class="ih2GBIpmzu4I"></i><!--{/if}-->
                <!--{if $_G['forum']['threadtypes']['types'][$thread['typeid']]}-->
                <span class="WAO1ETmvH49Y">#{echo strip_tags($_G['forum']['threadtypes']['types'][$thread['typeid']])}</span>
                <!--{/if}-->
                <!--{if $_G['forum']['threadsorts']['types'][$thread['sortid']]}-->
                <span class="WAO1ETmvH49Y">#{echo strip_tags($_G['forum']['threadsorts']['types'][$thread['sortid']])}</span>
                <!--{/if}-->
                <!--{if $thread[icon] >= 0}-->
                <span class="ZUp4byFwR1BK">#{$_G[cache][stamps][$thread[icon]][text]}</span>
                <!--{else}-->
                <!--{if $thread[heatlevel]}-->
                <span class="Z1K9j6zHkkNq">#{lang order_heats}</span>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $thread[replies]}-->
                <!--{if $thread[replies] > 9999 }-->
                <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $thread['isgroup'] != 1}-->
                <!--{if $thread[views] > 9999 }-->
                <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{else}-->
                <!--{if $groupnames[$thread[tid]][views] > 9999 }-->
                <!--{eval $groupnames[$thread[tid]][views] = round($groupnames[$thread[tid]][views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->
                <span class="99u2LxYcMOhO">{$thread[dateline]} <span class="RB4F49dgNi61">/</span> <!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}--><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->{$langplus[view]}<!--{/if}--></span>
            </div>
        </a>
    </li>
    <!--{/if}-->
    <!--{eval $ad++;}-->
    <!--{/loop}-->
</ul>
<!--{else}-->
<div class="sqK9gG26iUGb">{lang forum_nothreads}</div>
<!--{/if}-->