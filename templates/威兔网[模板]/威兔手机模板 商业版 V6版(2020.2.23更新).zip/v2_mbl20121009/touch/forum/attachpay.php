<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang attachment_buy}<!--{/block}-->
<!--{template common/header}-->
<div class="ajaxpop{if !$_G['inajax']} no_ajax{/if}">
<form id="attachpayform" method="post" autocomplete="off" action="forum.php?mod=misc&action=attachpay&tid={$_G[tid]}&paysubmit=yes&infloat=yes">
	<div class="paylist_pay">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="aid" value="$aid" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
		
			<table cellspacing="0" cellpadding="0" >
				<tr>
					<td>{lang author}</td>
					<td><a href="home.php?mod=space&uid=$attach[uid]">$attach[author]</a></td>
				</tr>
				<tr>
					<td>{lang attachment}</td>
					<td>$attach[filename]</td>
				</tr>  
				<tr>
					<td>{lang price}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</td>
					<td>$attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</td>
				</tr>
				<!--{if $status != 1}-->
				<tr>
					<td>{lang pay_author_income}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</td>
					<td>$attach[netprice] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</td>
				</tr>
				<tr>
					<td>{lang pay_balance}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</td>
					<td>$balance {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</td>
				</tr>
				<!--{/if}-->
				<!--{if $status == 1}-->
				<tr>
					<td colspan="2">{lang status_insufficient}</td>
				</tr>
				<!--{elseif $status == 2}-->
				<tr>
					<td colspan="2">{lang status_download}, <a href="forum.php?mod=attachment&aid=$aidencode">{lang download}</a></td>
				</tr>
				<!--{/if}-->
			</table>
            
			<!--{if $status != 1}-->
				<div class="btye ptm pbn"><label><input name="buyall" type="checkbox" value="yes" class="pc" /> {lang buy_all_attch}</label></div>				
			<!--{/if}-->            
	</div>
    
			<!--{if $status != 1}-->				
				<div class="hm tb"><button class="formdialog button2{if !$_G['inajax']} brno{/if}" type="submit" name="paysubmit" value="true"><span><!--{if $status == 0}-->{lang pay_attachment}<!--{else}-->{lang free_buy}<!--{/if}--></span></button></div>
			<!--{/if}-->    
</form>

</div>
<!--{template common/footer}-->