<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $expiration && $expirations < TIMESTAMP}--><div class="ElK7LmWEy7bB"></div><!--{/if}-->
<!--{if $_G[forum_thread][views] > 9999 }-->           
<!--{eval $_G[forum_thread][views] = round($_G[forum_thread][views] / 10000 , 1).$langplus[tenthousand];}-->
<!--{/if}-->
<div class="hEeBa7s6Bcpg">
<div class="keuk5RiCzwFy"><span>{$_G[forum_thread][views]}</span><p>{$langplus[browsednum]}</p></div>
<div class="keuk5RiCzwFy"><span>{$voterscount}</span><p>{$langplus[voteppnum]}</p></div>
<div class="keuk5RiCzwFy"><span>{$count[total]}</span><p>{$langplus[votenum]}</p></div>
</div>

<div id="postmessage_$post[pid]" class="2QJS1583Ldl0">$post[message]</div>

<div class="YOnIRkxtiuMR">
	<!--{if $expiration && $expirations < TIMESTAMP}-->
	<p>{lang poll_end}</p>
	<!--{else}-->
	<p>
	<!--{if $multiple}-->
	{$langplus[thisis]}{lang poll_multiple}{lang thread_poll}        
	<!--{if $maxchoices}-->, {lang poll_more_than}<!--{/if}-->        
	<!--{else}-->
	{$langplus[thisis]}{lang poll_single}{lang thread_poll}
	<!--{/if}-->        
	<!--{if $visiblepoll && $_G['group']['allowvote']}-->, {lang poll_after_result}<!--{/if}-->
	<!--{if $isimagepoll}-->, {$langplus[imgpollnote]}<!--{/if}-->
	</p>
    <!--{/if}-->
</div>
    
<div class="E1Oy6Qaawyb0"><span>{$langplus[polloption]}</span></div>
<form id="poll" name="poll" method="post" autocomplete="off" action="forum.php?mod=misc&action=votepoll&fid=$_G[fid]&tid=$_G[tid]&pollsubmit=yes{if $_GET[from]}&from=$_GET[from]{/if}&quickforward=yes&mobile=2" >
	<input type="hidden" name="formhash" value="{FORMHASH}" />        
        <!--{if $isimagepoll}-->
        <!--{if in_array($_G['fid'],(array)unserialize($pollimgtype))}-->
        <div class="JIOy3hAITQ3s">
        <!--{loop $polloptions $key $option}-->
            <div class="9IlBmAtqlLU5">
            <div class="lMuqGwK2yFoa">
            <!--{eval $imginfo=$option['imginfo'];}-->            
            <!--{if $imginfo}-->
            <div class="WSKlpo1Ilums" style="background-image: url('{$imginfo[small]}')"></div>
            <!--{else}-->
            <div class="WSKlpo1Ilums">{lang upload}{lang forum_recommend_image}</div>
            <!--{/if}-->
            <div class="poll_op_name{if $visiblepoll} mbn{/if}">$option[polloption]</div>
            <!--{if !$visiblepoll}-->
            <div class="sGpq5ovfv3Ut">
            <span style="color:#{$option[color]};">{if $option[votes]}{$option[votes]}{else}0{/if}{$langplus[ticket]}</span><span class="y fz5{if $option[percent] != 0.00} qian{else} nc{/if}">$option[percent]%</span>         
            </div>
            <!--{/if}-->            
            <!--{if $_G['group']['allowvote']}-->               
               <label class="3UsV2drxzF5k"><input type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]"{if $_G['forum_thread']['is_archived']} disabled="disabled"{/if}{if $optiontype=='checkbox'} onclick="poll_checkbox(this)"{/if} /><i></i></label>
            <!--{/if}-->            
            </div>			
            </div>          
        <!--{/loop}-->
        </div>
        <!--{else}-->
        <div class="BGkoU3yy4ZLA">
        <!--{loop $polloptions $key $option}-->
            <div class="oKSVuPSiAW5C">
            <!--{if $_G['group']['allowvote']}-->
                <label class="3UsV2drxzF5k"><input type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]"{if $_G['forum_thread']['is_archived']} disabled="disabled"{/if}{if $optiontype=='checkbox'} onclick="poll_checkbox(this)"{/if} /><i></i></label>
            <!--{/if}-->
            <!--{eval $imginfo=$option['imginfo'];}-->            
            <!--{if $imginfo}-->
            <div class="WSKlpo1Ilums" style="background-image: url('{$imginfo[small]}')"></div>
            <!--{else}-->
            <div class="WSKlpo1Ilums">{lang upload}{lang forum_recommend_image}</div>
            <!--{/if}-->
            <div class="8H2PRRWDA2YJ">            
            <!--{if !$visiblepoll}-->
                <span style="color:#$option[color];">{if $option[votes]}{$option[votes]}{else}0{/if}{$langplus[ticket]}</span>
            <!--{/if}-->
            $option[polloption]
            </div>            
			<div class="OYIyvCtKHVaM" ><div class="UPnSldXqIlv3" style="width:{$option[width]}; background-color:#{$option[color]};"></div></div>
            </div>           
        <!--{/loop}-->
        </div>
        <!--{/if}-->
        <!--{else}-->
        <div class="BGkoU3yy4ZLA">
        <!--{loop $polloptions $key $option}-->
            <div class="ck2PR7vUwJm2">
            <!--{if $_G['group']['allowvote']}-->
                <label for="option_$key"><input type="$optiontype" id="option_$key" name="pollanswers[]" value="$option[polloptionid]"{if $_G['forum_thread']['is_archived']} disabled="disabled"{/if}{if $optiontype=='checkbox'} onclick="poll_checkbox(this)"{/if} /><i></i></label>
            <!--{/if}-->            
            <div class="poll_op_name{if !$_G['group']['allowvote']} poll_done{/if}">            
            <!--{if !$visiblepoll}-->
                <span style="color:#$option[color];">{if $option[votes]}{$option[votes]}{else}0{/if}{$langplus[ticket]}</span>
            <!--{/if}-->
            {$key}. $option[polloption]
            </div>            
			<div class="OYIyvCtKHVaM" ><div class="UPnSldXqIlv3" style="width:{$option[width]}; background-color:#{$option[color]};"></div></div>
            </div>           
        <!--{/loop}-->
        </div>
        <!--{/if}-->        
        <!--{if !$visiblepoll && ($overt || $_G['adminid'] == 1 || $thread['authorid'] == $_G['uid']) && $post['invisible'] == 0}-->
			<div class="DbyPKJIjdQ8O"><a href="forum.php?mod=misc&action=viewvote&tid=$_G[tid]">{lang poll_view_voters}</a></div>
		<!--{/if}-->        
		<!--{if $_G[forum_thread][remaintime]}-->
            <div class="m84qt9MCHHjU">
            {lang poll_count_down} :
            <!--{if $_G[forum_thread][remaintime][0]}-->$_G[forum_thread][remaintime][0] {lang days} <!--{/if}-->
            <!--{if $_G[forum_thread][remaintime][1]}-->$_G[forum_thread][remaintime][1] {lang poll_hour} <!--{/if}-->
            $_G[forum_thread][remaintime][2] {lang poll_minute}
            </div>
		<!--{/if}-->       
        <!--{if $_G['group']['allowvote'] && !$_G['forum_thread']['is_archived']}-->
            <button type="submit" name="pollsubmit" id="pollsubmit" value="{lang submit}" class="BSKK102ssFRR" />{lang submit}</button>        
        <!--{elseif !$allwvoteusergroup}-->
            <!--{if !$_G['uid']}-->
            <div class="0RedV4FoNN1r">{lang poll_msg_allwvote_user}</div>
            <!--{else}-->
            <div class="0RedV4FoNN1r">{lang poll_msg_allwvoteusergroup}</div>
            <!--{/if}-->
        <!--{elseif !$allowvotepolled}-->
            <div class="0RedV4FoNN1r">{lang poll_msg_allowvotepolled}</div>
        <!--{elseif !$allowvotethread}-->
            <div class="0RedV4FoNN1r">{lang poll_msg_allowvotethread}</div>
        <!--{/if}-->
</form>

<!--{if $_G['group']['allowvote']}-->
<!--{if $optiontype=='checkbox'}-->
<script type="text/javascript">
var max_obj = $maxchoices;
var p = 0;
function poll_checkbox(obj) {
	if(obj.checked) {
		p++;
		for (var i = 0; i < poll.elements.length; i++) {
			var e = poll.elements[i];
			if(p == max_obj) {
				if(e.name.match('pollanswers') && !e.checked) {
					e.disabled = true;
				}
			}
		}
	} else {
		p--;
		for (var i = 0; i < poll.elements.length; i++) {
			var e = poll.elements[i];
			if(e.name.match('pollanswers') && e.disabled) {
				e.disabled = false;
			}
		}
	}
}
</script>
<!--{/if}-->
<!--{/if}-->