<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang manage}<!--{/block}-->
<!--{template common/header}-->
<div class="tip">
<!--{if ($_GET['optgroup'] == 1 && $operation == 'stick') || ($_GET['optgroup'] == 2 && $operation == 'move') || ($_GET['optgroup'] == 2 && $operation == 'type') || ($_GET['optgroup'] == 3 && $operation == 'delete') || ($_GET['optgroup'] == 4 && $operation == '') || ($_GET['optgroup'] == 5 && $operation == 'digest') }-->
<!--{if $_GET['optgroup'] == 1 && $operation == 'stick' || $_GET['optgroup'] == 4 || $_GET['optgroup'] == 5}-->
<!--{eval $one_day = dgmdate(strtotime('+1 day'), 'Y-m-d H:i'); $seven_day = dgmdate(strtotime('+7 day'), 'Y-m-d H:i'); $thirty_day = dgmdate(strtotime('+30 day'), 'Y-m-d H:i'); $ninety_day = dgmdate(strtotime('+90 day'), 'Y-m-d H:i'); }-->
<!--{/if}-->
    <form id="moderateform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&action=moderate&optgroup=$optgroup&modsubmit=yes&mobile=2" >
        <input type="hidden" name="frommodcp" value="$frommodcp" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="fid" value="$_G[fid]" />
        <input type="hidden" name="redirect" value="{echo dreferer()}" />
        <input type="hidden" name="reason" value="{lang topicadmin_mobile_mod}" />
        <!--{loop $threadlist $thread}-->
            <input type="hidden" name="moderate[]" value="$thread[tid]" />
        <!--{/loop}-->
        
		<!--{if $_GET['optgroup'] == 1 && $operation == 'stick'}-->
			
				<!--{if count($threadlist) > 1 || empty($defaultcheck[recommend])}-->
					<!--{if $_G['group']['allowstickthread']}-->
					<dt>
						<input type="checkbox" name="operations[]" value="stick" $defaultcheck[stick] style="display:none;"/>                        
									<div class="mdets_option"> 
                                    <div class="mbm">
                                    <div class="selectstyle">                                     
										<select name="sticklevel">
											<!--{if $_G['forum']['status'] != 3}-->
												<option value="0">{lang none}</option>
												<option value="1" $stickcheck[1]>$_G['setting']['threadsticky'][2]</option>
												<!--{if $_G['group']['allowstickthread'] >= 2}-->
													<option value="2" $stickcheck[2]>$_G['setting']['threadsticky'][1]</option>
													<!--{if $_G['group']['allowstickthread'] == 3}-->
														<option value="3" $stickcheck[3]>$_G['setting']['threadsticky'][0]</option>
													<!--{/if}-->
												<!--{/if}-->
											<!--{else}-->
												<option value="0">{lang no}&nbsp;</option>
												<option value="1" $stickcheck[1]>{lang yes}&nbsp;</option>
											<!--{/if}-->
										</select>                                        
                                        </div> 
                                        </div>                                       
                                        <div class="mbm">										
										<input type="text" autocomplete="off" id="expirationstick" name="expirationstick" value="$expirationstick" tabindex="1" placeholder="{lang expire} 2010-12-01 10:50" />
                                        </div>                                        
                                        <div class="select_date"><span onclick="$('#expirationstick').val('{$one_day}')">{lang last_1_days}</span><span onclick="$('#expirationstick').val('{$seven_day}')">{lang list_one_week}</span><span onclick="$('#expirationstick').val('{$thirty_day}')">{lang list_one_month}</span><span onclick="$('#expirationstick').val('{$ninety_day}')">{lang list_three_month}</span></div>
                                   </div>							
					     <!--{/if}-->
					<!--{/if}-->				
				</dt>
				<dd><input type="submit" name="modsubmit" id="modsubmit"  value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();">{lang cancel}</a></dd>           
         <!--{elseif $_GET['optgroup'] == 2}-->
				<dt class="pts">
                <div class="mdets_option">
						<!--{if $operation != 'type'}-->
                        <input type="hidden" name="operations[]" value="move" />
                        <p class="mbm">{lang admin_target}</p>						
                        <p class="selectstyle">
							<select name="moveto" id="moveto" onchange="">
							$forumselect
							</select>
						</p>
                        <ul id="moveext" class="moveext mtw" style="display:none;">
						<li><label><input type="radio" name="type" value="normal" checked="checked" />{lang admin_move}</label></li>
						<li><label><input type="radio" name="type" value="redirect" />{lang admin_move_hold}</label></li>
						</ul>                                              
                        <!--{else}-->
                        <!--{if $typeselect}-->
							<input type="hidden" name="operations[]" value="type" />
                            <p class="mbm">{lang types}</p>
							<p class="selectstyle">$typeselect</p>
						<!--{else}-->
							<p>{lang admin_type_msg}</p><!--{eval $hiddensubmit = true;}-->
						<!--{/if}-->
                        <!--{/if}-->                        
				</div>
                </dt>
				<dd><input type="submit" name="modsubmit" id="modsubmit"  value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();">{lang cancel}</a></dd>    
        
        <!--{elseif $_GET['optgroup'] == 3}-->
            <!--{if $operation == 'delete'}-->
                <!--{if $_G['group']['allowdelpost']}-->
                    <input name="operations[]" type="hidden" value="delete"/>
                    <dt>{lang admin_delthread_confirm}</dt>
					<dd><input type="submit" class="formdialog button2" name="modsubmit" id="modsubmit"  value="{lang confirms}"><a href="javascript:;" onclick="popup.close();">{lang cancel}</a></dd>
                <!--{else}-->
                    <dt>{lang admin_delthread_nopermission}</dt>
                <!--{/if}-->
            <!--{/if}-->
        <!--{elseif $_GET['optgroup'] == 4}-->
				<dt class="mdets_option">                
                <div class="mbm"><input type="text" name="expirationclose" id="expirationclose" autocomplete="off" value="$expirationclose" placeholder="{lang expire} 2010-12-01 10:50" /></div>
                <div class="select_date mbm"><span onclick="$('#expirationclose').val('{$one_day}')">{lang last_1_days}</span><span onclick="$('#expirationclose').val('{$seven_day}')">{lang list_one_week}</span><span onclick="$('#expirationclose').val('{$thirty_day}')">{lang list_one_month}</span><span onclick="$('#expirationclose').val('{$ninety_day}')">{lang list_three_month}</span></div>                
                <div class="mdetslabel"><span><label><input type="radio" name="operations[]" class="pr" value="open" $closecheck[0] />{lang admin_open}</label></span><span><label><input type="radio" name="operations[]" class="pr" value="close" $closecheck[1] />{lang admin_close}</label></span></div>
				</dt>
				<dd><input type="submit" name="modsubmit" id="modsubmit"  value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();">{lang cancel}</a></dd> 
        <!--{elseif $_GET['optgroup'] == 5}-->        
					<!--{if $_G['group']['allowdigestthread']}-->				
						<dt>
								<input type="checkbox" name="operations[]" value="digest" $defaultcheck[digest] style="display:none;" />
									<div class="mdets_option"> 
                                    <div class="mbm">                                                                       
                                    <div class="selectstyle">
										<select name="digestlevel">
											<option value="0">{lang admin_digest_remove}</option>
											<option value="1" $digestcheck[1]>{lang thread_digest} 1</option>
											<!--{if $_G['group']['allowdigestthread'] >= 2}-->
												<option value="2" $digestcheck[2]>{lang thread_digest} 2</option>
												<!--{if $_G['group']['allowdigestthread'] == 3}-->
													<option value="3" $digestcheck[3]>{lang thread_digest} 3</option>
												<!--{/if}-->
											<!--{/if}-->
										</select>
                                        </div> 
                                        </div>
                                        <div class="mbm">										
										<input type="text" name="expirationdigest" id="expirationdigest" autocomplete="off" value="$expirationdigest" tabindex="1" placeholder="{lang expire} 2010-12-01 10:50" />
                                        </div>
                                        <div class="select_date"><span onclick="$('#expirationdigest').val('{$one_day}')">{lang last_1_days}</span><span onclick="$('#expirationdigest').val('{$seven_day}')">{lang list_one_week}</span><span onclick="$('#expirationdigest').val('{$thirty_day}')">{lang list_one_month}</span><span onclick="$('#expirationdigest').val('{$ninety_day}')">{lang list_three_month}</span></div>                                        
						</dt>
                        <dd><input type="submit" name="modsubmit" id="modsubmit"  value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();">{lang cancel}</a></dd>                
        <!--{/if}-->                
        <!--{/if}-->
    </form>
<!--{else}-->
    	<dt>{lang admin_threadtopicadmin_error}</dt>
		<dd><input type="button" onclick="popup.close();" value="{lang confirms}" class="button2"></dd>
<!--{/if}-->
</div>
<!--{template common/footer}-->
