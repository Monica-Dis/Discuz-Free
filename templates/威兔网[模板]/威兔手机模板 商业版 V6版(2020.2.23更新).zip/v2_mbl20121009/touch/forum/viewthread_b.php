<?php echo 'From: DisM.taobao.com';exit;?>
<!-- main postlist start -->
    <!--{eval $postcount = 0;}-->
    <!--{loop $postlist $post}-->
    <!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
    <!--{if $post['first']}-->
    <div class="viewvideo">
        <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/videoplayer.php');}-->
        <div class="viewmedia">
            <!--{if $mediaplayer}--><div class="mediabox">$mediaplayer</div><!--{else}--><div class="viewmedianoplay">{$langplus[noplay]}</div><!--{/if}-->
            <div class="view_authi{if $post[authorid] != $_G[uid] && $post['first']} view_follow{/if}">
                <a href="{if $post['authorid'] && $post['username'] && !$post['anonymous']}home.php?mod=space&uid=$post[authorid]&do=profile{else}{if $_G['forum']['ismoderator']}home.php?mod=space&uid=$post[authorid]&do=profile{else}javascript:;{/if}{/if}" class="avatars"><img src="{if !$post['authorid'] || $post['anonymous']}{avatar(0, middle, true)}{else}{avatar($post[authorid], middle, true)}{/if}" /></a>
                <p>
                    <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
                    <span class="view_author">
                        <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                        <a href="home.php?mod=space&uid=$post[authorid]&do=profile" >$post[author]</a>
                        <!--{else}-->
                        <!--{if !$post['authorid']}-->
                        <a href="javascript:;">{lang guest}</a>
                        <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                        <!--{if $_G['forum']['ismoderator']}-->
                        <a href="home.php?mod=space&uid=$post[authorid]&do=profile">{lang anonymous}</a>
                        <!--{else}-->
                        <a href="javascript:;">{lang anonymous}</a>
                        <!--{/if}-->
                        <!--{else}-->
                        <a href="javascript:;">$post[author]</a> {lang member_deleted}
                        <!--{/if}-->
                        <!--{/if}-->
                    </span>
                    <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                    <!--{if $post[gender] == 0}-->
                    <!--{elseif $post[gender] == 1}-->
                    <i class="gender gender_{$post[gender]}"></i>
                    <!--{elseif $post[gender] == 2}-->
                    <i class="gender gender_{$post[gender]}"></i>
                    <!--{/if}-->
                    <!--{if !$post['authorid']}--><!--{else}-->
                    <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
                    <!--{if $_self }-->
                    <i class="ta">{lang thread_author}</i>
                    <!--{else}-->
                    <!--{if $post['authorid'] && $post['username'] && !$post['anonymous'] || $_G['forum']['ismoderator']}-->
                    <!--{if $leveltype == 1}-->
                    <!--{if $_G['cache']['usergroups'][$post['groupid']][stars] > 0 }-->
                    <i class="mod_crown">Lv.{$_G['cache']['usergroups'][$post['groupid']][stars]}</i>
                    <!--{/if}-->
                    <!--{elseif $leveltype == 2}-->
                    <!--{if $_G['cache']['usergroups'][$post['groupid']][stars] > 0 }-->
                    <i class="mod"{if $_G['cache']['usergroups'][$thread['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$post['groupid']]['color']};"{/if}>Lv.{$_G['cache']['usergroups'][$post['groupid']][stars]}</i>
                    <!--{/if}-->
                    <!--{else}-->
                    <i class="mod"{if $_G['cache']['usergroups'][$post['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$post['groupid']]['color']};"{/if}>{$_G['cache']['usergroups'][$post['groupid']]['grouptitle']}</i>
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{hook/viewthread_articlefrom_v2_mobile $postcount}-->
                </p>
                <span class="datelinetimes"><!--{if $viewstatus == 1 && $post[customstatus]}-->$post[customstatus]<!--{else}-->$post[dateline]<!--{/if}--></span>
                <!--{if $post[authorid] != $_G[uid] && $post['first']}-->
                <!--{if helper_access::check_module('follow')}-->
                <a href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$post[authorid]" class="dialog_ibtn ajaxlink">{$langplus[follows]}</a>
                <!--{else}-->
                <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$post[authorid]&handlekey=addfriendhk_{$post[authorid]}" class="dialog_ibtn{if $_G['uid']} dialog{/if}">{$langplus[follows]}</a>
                <!--{/if}-->
                <!--{/if}-->
            </div>
        </div>
        <div class="viewmedia_sd"></div>
        <div class="viewvname">$_G[forum_thread][subject]<!--{if $_G['forum_thread'][displayorder] == -2}--> <span class="orange">({lang moderating})</span><!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span class="orange">({lang have_ignored})</span><!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span class="orange">({lang draft})</span><!--{/if}--></div>
        <div class="viewcontent">
            <p class="mbm">
                <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
                <!--{if !IS_ROBOT && ($_G['forum']['threadtypes']['listable'] || $_G['forum']['status'] == 3)}-->
                <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$_G[forum_thread][typeid]">{echo strip_tags({$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]})}</a> <span>|</span>
                <!--{else}-->
                {echo strip_tags({$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]})} <span>|</span>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
                <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_G[forum_thread][sortid]">{echo strip_tags({$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]})}</a> <span>|</span>
                <!--{/if}-->
                <!--{if $_G[forum_thread][views] > 9999 }-->
                <!--{eval $_G[forum_thread][views] = round($_G[forum_thread][views] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <!--{if $viewstatus == 1 && $post[customstatus]}-->$post[dateline] <span>|</span><!--{/if}-->
                $_G[forum_thread][views]{lang replycredit_time}{$langplus[plays]}
            </p>
            <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/messagefilter.php');}-->
            {echo messagecutstr($post[message], 500)}
            <!--{if $post['invisible'] == 0}-->
            <!--{if $_G[uid]}-->
            <!--{if ($post['authorid'] != $_G['uid']) || ($_G['group']['raterange'] && $post['authorid']) || $_G['forum']['ismoderator'] || ((($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first']))}-->
            <div class="viewpost">
                <!--{if $_G['forum']['ismoderator']}--><span href="#moption_$post[pid]" class="popup"><i class="vt-manage"></i></span><!--{/if}-->
                <!--{if $post['authorid'] != $_G['uid']}-->
                <a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" class="dialog"><i class="vt-report"></i>{lang report}</a>
                <!--{/if}-->
                <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
                <a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]&infloat=yes" class="dialog"><i class="vt-gift"></i></a>
                <!--{/if}-->
                <!--{if $_G['group']['raterange'] && $post['authorid']}-->
                <a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]{if $ratetype == 1 || $ratetype == 2}&reward=1{/if}" class="dialog"><i class="{if $ratetype == 1 || $ratetype == 2}vt-goldcoin{else}vt-rate{/if}"></i><!--{if $ratetype == 1 || $ratetype == 2}-->{$langplus[viewsreward]}<!--{else}-->{lang rate}<!--{/if}--></a>
                <!--{/if}-->
                <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])}-->
                <a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_G[forum_thread][sortid]}{if $post[first]}&sortid={$_G[forum_thread][sortid]}{/if}{/if}{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page" class="z"><i class="vt-edit"></i></a>
                <!--{/if}-->
            </div>
            <!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
        </div>
        <!--{hook/viewthread_postbottom_v2_mobile $postcount}-->
        <!--{if $specialplugin == 0}--><!--{hook/viewthread_postbottom_mobile $postcount}--><!--{/if}-->
        <!--{if $post['first']}-->
        <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
        <!--{if $adviewthreadd && in_array($_G['fid'],(array)unserialize($adviewthreadidd))}--><!--{$adviewthreadd}--><!--{/if}-->
        <!--{if $adviewthreade && in_array($_G['fid'],(array)unserialize($adviewthreadide))}--><!--{$adviewthreade}--><!--{/if}-->
        <!--{if $adviewthreadf && in_array($_G['fid'],(array)unserialize($adviewthreadidf))}--><!--{$adviewthreadf}--><!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
        <div class="viewforum">
            <!--{eval $langplus['reply'] = $langplus['comment']}-->
            <span class="video_tab on">{$langplus[brilliant]}{$langplus[comment]}</span><span class="video_tab">{lang order_heats}{$langplus[video]}</span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">{$langplus[video]}{$langplus[list]}</a>
        </div>
    </div>
    <!--{if $_G['forum']['ismoderator']}-->
    <div id="moption_$post[pid]" popup="true" style="display:none;">
        <ul class="mmenus">
            <!--{if !$_G['forum_thread']['special']}--><li><input type="button" value="{lang edit}" class="redirect mgbutton" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></li><!--{/if}-->
            <li><input type="button" value="{if !$_G['forum_thread']['closed']}{lang modmenu_switch_off}{else}{lang modmenu_switch_on}{/if}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4"></li>
            <li><input type="button" value="{lang admin_banpost}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></li>
            <li><input type="button" value="{lang topicadmin_warn_add}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></li>
            <li><input type="button" value="{lang thread_moved}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=move&optgroup=2&from={$_G[tid]}"></li>
            <li><input type="button" value="{lang modmenu_type}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=type&optgroup=2&from={$_G[tid]}"></li>
            <li><input type="button" value="{lang modmenu_stickpost}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=stick&optgroup=1&from={$_G[tid]}"></li>
            <li><input type="button" value="{lang digest_posts}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=digest&optgroup=5&from={$_G[tid]}"></li>
            <li><input type="button" value="{lang delete}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}"></li>
            <!--{if !empty($postlist[$post[pid]]['totalrate']) && $_G['forum']['ismoderator']}--><li><a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" class="mgbutton dialog" >{lang removerate}</a></li><!--{/if}-->
        </ul>
    </div>
    <!--{/if}-->
    <!--{/if}-->
    <!--{eval $postcount++;}-->
    <!--{/loop}-->
<div class="moremedia" disable="true">
<div class="morebox">
<div id="alist" class="viewlist pagelist">    
    <!--{eval $postcount = 0;}-->
	<!--{loop $postlist $post}-->
	<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
    <!--{if !$post['first']}-->
    <div class="plc" id="pid$post[pid]">
    <!--{if $post['warned']}--><i class="view_warneds">{lang warn_get}</i><!--{/if}-->
       <div class="display pi{if $viewheight}{if $post['first']} viewheight{/if}{/if}">
		   <!--{if ($_G[forum_thread][special] == 3 || $_G[forum_thread][special] == 2) && $post['first']}--><!--{else}-->
           <div class="view_authi{if $post[authorid] != $_G[uid] && $post['first']} view_follow{/if}">
           <a href="{if $post['authorid'] && $post['username'] && !$post['anonymous']}home.php?mod=space&uid=$post[authorid]&do=profile{else}{if $_G['forum']['ismoderator']}home.php?mod=space&uid=$post[authorid]&do=profile{else}javascript:;{/if}{/if}" class="avatars"><img src="{if !$post['authorid'] || $post['anonymous']}{avatar(0, middle, true)}{else}{avatar($post[authorid], middle, true)}{/if}" /></a>
           <p>
           <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
           <span class="view_author">
           <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
           <a href="home.php?mod=space&uid=$post[authorid]&do=profile" >$post[author]</a>
           <!--{else}-->
           <!--{if !$post['authorid']}-->
           <a href="javascript:;">{lang guest}</a>
           <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
           <!--{if $_G['forum']['ismoderator']}-->
           <a href="home.php?mod=space&uid=$post[authorid]&do=profile">{lang anonymous}</a>
           <!--{else}-->
           <a href="javascript:;">{lang anonymous}</a>
           <!--{/if}-->
           <!--{else}-->
           <a href="javascript:;">$post[author]</a> {lang member_deleted}
           <!--{/if}-->
           <!--{/if}-->
           </span>
           <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
           <!--{if $post[gender] == 0}-->
           <!--{elseif $post[gender] == 1}-->
           <i class="gender gender_{$post[gender]}"></i>
           <!--{elseif $post[gender] == 2}-->
           <i class="gender gender_{$post[gender]}"></i>
           <!--{/if}-->
           <!--{if !$post['authorid']}--><!--{else}-->
           <!--{eval $_self = $thread['author'] && $post['author'] == $thread['author'] && $post['position'] !== '1';}-->
           <!--{if $_self }-->
           <i class="ta">{lang thread_author}</i>
           <!--{else}-->
           <!--{if $post['authorid'] && $post['username'] && !$post['anonymous'] || $_G['forum']['ismoderator']}-->
           <!--{if $leveltype == 1}-->
           <!--{if $_G['cache']['usergroups'][$post['groupid']][stars] > 0 }-->
           <i class="mod_crown">Lv.{$_G['cache']['usergroups'][$post['groupid']][stars]}</i>
           <!--{/if}-->
           <!--{elseif $leveltype == 2}-->
           <!--{if $_G['cache']['usergroups'][$post['groupid']][stars] > 0 }-->
           <i class="mod"{if $_G['cache']['usergroups'][$thread['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$post['groupid']]['color']};"{/if}>Lv.{$_G['cache']['usergroups'][$post['groupid']][stars]}</i>
           <!--{/if}-->
           <!--{else}-->
           <i class="mod"{if $_G['cache']['usergroups'][$post['groupid']]['color']} style="background:{$_G['cache']['usergroups'][$post['groupid']]['color']};"{/if}>{$_G['cache']['usergroups'][$post['groupid']]['grouptitle']}</i>
           <!--{/if}-->
           <!--{/if}-->
           <!--{/if}-->
           <!--{/if}-->
           <!--{/if}-->
           <!--{hook/viewthread_articlefrom_v2_mobile $postcount}-->
           <!--{if !$post['first'] && $post['rewardfloor']}-->
           <i class="pdbts pdbts_1">
           <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1">{lang rushreply_hit}</a>
           </i>
           <!--{/if}-->
           <!--{if !$post['first']}-->
           <em class="view_floor">
               <!--{if $supportposit == 1 && (!$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote']))}-->
               <!--{if isset($post[isstick])}-->
               <i class="orange">{$langplus[top]}</i>
               <!--{elseif $post[number] == -1}-->
               <i class="orange">{lang recommend}</i>
               <!--{/if}-->
               <!--{if $post[postreview][support] > 9999 }-->
               <!--{eval $post[postreview][support] = round($post[postreview][support] / 10000 , 1).$langplus[tenthousand];}-->
               <!--{/if}-->
               <span class="review_support"{if !$post[postreview][support]} style="display:none;"{/if}>{$post[postreview][support]}</span>
               <a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" class="btn_support ajaxsupport"><i class="vt-recadd"></i></a>
               <!--{else}-->
               <!--{if $supportposit == 1 && $_G['forum_thread']['special'] == 5}-->
               <!--{if $post[stand]}-->
               <span class="review_support"{if !$post[voters]} style="display:none;"{/if}>{$post[voters]}</span>
               <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]" class="btn_support ajaxsupport"><i class="vt-recadd"></i></a>
               <!--{/if}-->
               <!--{else}-->
               <!--{if isset($post[isstick])}-->
               <i class="orange">{$langplus[top]}</i> {lang from} {$post[number]}{$postnostick}
               <!--{elseif $post[number] == -1}-->
               <i class="orange">{lang recommend}</i>
               <!--{else}-->
               <!--{if !empty($postno[$post[number]])}-->$postno[$post[number]]<!--{else}-->{$post[number]}{$postno[0]}<!--{/if}-->
               <!--{/if}-->
               <!--{/if}-->
               <!--{/if}-->
           </em>
           <!--{/if}-->
           </p>
           <span class="datelinetimes"><!--{if $viewstatus == 1}-->{echo dgmdate($post['dbdateline'], 'u')}<!--{if $post['first'] && $post[customstatus]}--> �� $post[customstatus]<!--{/if}--><!--{else}-->$post[dateline]<!--{/if}--></span>
           </div>
           <!--{/if}-->
           <!--{if !$post['first'] && $viewposttype == 1}--><div class="posttype"><!--{/if}-->
			<div class="message">
                    <!--{if !$post['first'] && !empty($post[subject])}-->
                        <h3 class="subedit">$post[subject]</h3>
                    <!--{/if}-->
                    <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                        <div class="quote">{lang message_banned}</div>
                    <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                        <div class="quote">{lang message_single_banned}</div>
                    <!--{elseif $needhiddenreply}-->
                        <div class="quote">{lang message_ishidden_hiddenreplies}</div>
                    <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
						<!--{template forum/viewthread_pay}-->
                    <!--{elseif $_G['forum_discuzcode']['passwordlock'][$post[pid]]}-->
                        <div class="locked">{$langplus[message_password]} <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&mobile=no">{lang nomobiletype}</a></div>
					<!--{else}-->

                    	<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                            <div class="quote">{lang admin_message_banned}</div>
                        <!--{elseif $post['status'] & 1}-->
                            <div class="quote">{lang admin_message_single_banned}</div>
                        <!--{/if}-->
                            $post[message]
					<!--{/if}-->
			</div>
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
			<!--{if $post['attachment']}-->
               <div class="warning mts mbs">
               {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
               </div>
            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
				<div class="attach_list">
				<!--{if $post['imagelist']}-->
				<!--{if count($post['imagelist']) == 1}-->
				{echo showattach($post, 1)}
				<!--{else}-->
				{echo showattach($post, 1)}
				<!--{/if}-->
				<!--{/if}-->
                <!--{if $post['attachlist']}-->
				{echo showattach($post)}
				<!--{/if}-->
                </div>
			<!--{/if}-->
			<!--{/if}-->
	<!--{if $_GET['from'] != 'preview' && $_G['setting']['commentnumber'] && !empty($comments[$post[pid]])}-->
        <div class="threadcomment">
        <div class="titls_view">{$langplus[webcomments]}</div>
         <ul>
		<!--{eval $c = 1;}-->
        <!--{loop $comments[$post[pid]] $comment}-->
			<!--{if $c < 6}-->
            <li>
            <a href="home.php?mod=space&uid=$comment[authorid]&do=profile" class="avatar">$comment[avatar]</a>
				<div class="view_psti">
                <p>
                <!--{if $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
                <a href="forum.php?mod=topicadmin&action=delcomment&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$comment[id]}" class="dialog delete_bt y"><i class="vt-trash"></i></a>
                <!--{/if}-->
                <em><!--{date($comment[dateline], 'u')}--></em>
                <!--{if $comment['authorid']}-->
				<span><a href="home.php?mod=space&uid=$comment[authorid]&do=profile" >$comment[author]</a></span>
				<!--{else}-->
				<span>{lang guest}</span>
				<!--{/if}-->
                </p>
				<div class="postcomment">{$comment[comment]}</div>
				</div>
			</li>
            <!--{/if}-->
		<!--{eval $c++;}-->
        <!--{/loop}-->
         </ul>
        </div>
	<!--{/if}-->
        <!--{if !$post['first'] && $viewposttype == 1}--></div><!--{/if}-->
       </div>
                <div class="viewpost{if !$post['first'] && $viewposttype == 1} posttype{if $menusposit == 1} posttype_viewpost{/if}{/if}">
				<!--{if $_G['forum']['ismoderator']}--><span href="#moption_$post[pid]" class="popup"><i class="vt-manage"></i></span><!--{/if}-->
                <!--{if $post['invisible'] == 0}-->
                <!--{if $_G[uid]}-->
				<!--{if ($_G['group']['raterange'] && $post['authorid']) || ($allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])) || ((($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])) || ($post['authorid'] != $_G['uid'])}--><a href="javascript:;" class="moreaction"><i class="vt-dropdown"></i></a><!--{/if}-->
                <!--{/if}-->
                <!--{if $post['first']}-->
					<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&page=$page" ><i class="vt-reply"></i></a>
				<!--{else}-->
					<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&page=$page" ><i class="vt-reply"></i></a>
				<!--{/if}-->
				<!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
				<a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]&infloat=yes" class="dialog"><i class="vt-gift"></i></a>
				<!--{/if}-->
                <!--{if $supportposit == 0 && (!$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote']))}-->
                <!--{if $post[postreview][support] > 9999 }-->
                <!--{eval $post[postreview][support] = round($post[postreview][support] / 10000 , 1).$langplus[tenthousand];}-->
                <!--{/if}-->
                <span class="review_support"{if !$post[postreview][support]} style="display:none;"{/if}>{$post[postreview][support]}</span>
                <a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" class="btn_support ajaxsupport"><i class="vt-recadd"></i></a>
                <!--{/if}-->
                <!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
                <a href="forum.php?mod=misc&action=bestanswer&tid=$_G[tid]&pid=$post['pid']&from=$_GET[from]&bestanswersubmit=yes" class="ajaxjump rewardset bestanswer">{$langplus[setbestanswer]}</a>
                <!--{/if}-->
                <!--{if !$post[first] && $_G['forum_thread']['special'] == 5}-->
                <!--{if $post[stand] == 1}-->
                <a href="javascript:;" class="rewardset stand_{$post[stand]}" >{lang debate_square}</a>
                <!--{elseif $post[stand] == 2}-->
                <a href="javascript:;" class="rewardset stand_{$post[stand]}" >{lang debate_opponent}</a>
                <!--{else}-->
                <a href="javascript:;" class="rewardset" >{lang debate_neutral}</a>
                <!--{/if}-->
                <!--{if $supportposit == 0 && $post[stand]}-->
                <span class="review_support"{if !$post[voters]} style="display:none;"{/if}>{$post[voters]}</span>
                <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]" class="btn_support ajaxsupport"><i class="vt-recadd"></i></a>
                <!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->
                </div>
       <!--{if $post['invisible'] == 0}-->
            <!--{if $_G[uid]}-->
            <!--{if ($_G['group']['raterange'] && $post['authorid']) || ($allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])) || ((($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])) || ($post['authorid'] != $_G['uid'])}-->
            <div id="menups_$post[pid]" class="menups{if !$post['first'] && $viewposttype == 1 && $menusposit == 1} posttype_menups{/if}" style="display:none;">
				<ul>
                    <!--{if $post['authorid'] != $_G['uid']}-->
                    <li><a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" class="dialog"><i class="vt-report"></i>{lang report}</a></li>
                    <!--{/if}-->
                    <!--{if $allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])}-->
                    <li><a class="dialog" href="forum.php?mod=misc&action=comment&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page{if $_G['forum_thread']['special'] == 127}&special=$specialextra{/if}"><i class="vt-cup"></i>{lang comments}</a></li>
                    <!--{/if}-->
                    <!--{if $_G['group']['raterange'] && $post['authorid']}-->
                    <li><a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]{if $ratetype == 1 || $ratetype == 2}&reward=1{/if}" class="dialog"><i class="{if $ratetype == 1 || $ratetype == 2}vt-goldcoin{else}vt-rate{/if}"></i><!--{if $ratetype == 1 || $ratetype == 2}-->{$langplus[viewsreward]}<!--{else}-->{lang rate}<!--{/if}--></a></li>
                    <!--{/if}-->
                    <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])}-->
                    <li><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_G[forum_thread][sortid]}{if $post[first]}&sortid={$_G[forum_thread][sortid]}{/if}{/if}{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><i class="vt-edit"></i>{lang edit}</a></li>
                    <!--{/if}-->
				</ul>
			</div>
            <!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
					<!--{if $_G['forum']['ismoderator']}-->
					<!-- manage start -->
					<!--{if !$post[first]}-->
						<div id="moption_$post[pid]" popup="true" style="display:none;">
                        <ul class="mmenus">
							<li><input type="button" value="{lang edit}" class="redirect mgbutton" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></li>
                            <!--{if $_G['group']['allowbanpost']}--><li><input type="button" value="{lang modmenu_banpost}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                            <!--{if $_G['group']['allowwarnpost']}--><li><input type="button" value="{lang modmenu_warn}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                            <!--{if $_G['group']['allowstickreply']}--><li><input type="button" value="{lang modmenu_stickpost}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=stickreply&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                            <!--{if $_G['group']['allowdelpost']}--><li><input type="button" value="{lang modmenu_deletepost}" class="dialog mgbutton" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                            <!--{if !empty($postlist[$post[pid]]['totalrate']) && $_G['forum']['ismoderator']}--><li><a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" class="mgbutton dialog" >{lang removerate}</a></li><!--{/if}-->
                         </ul>
                         </div>
					<!--{/if}-->
					<!-- manage end -->
					<!--{/if}-->
    </div>
    <!--{/if}-->
   <!--{eval $postcount++;}-->
   <!--{/loop}-->   
</div>
<div id="ajaxpost"{if $viewposttype == 1} class="posttype_node"{/if}><div id="post_new"></div></div>
    <!--{if $_G[forum_thread][allreplies] <= 0}-->
    <div class="sofareply">
	<img src="template/v2_mbl20121009/touch_plus/image/sofa.png">
    $langplus[sofas]
	</div>
    <!--{/if}-->     
    <!--{if ($_G[forum_thread][allreplies] > 0) && ($_G['forum_thread']['replies'] < $_G['ppp']) }-->
    <div class="allsreply">$langplus[allcontent]</div>
    <!--{/if}-->
    <!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil(($_G['forum_thread']['replies'] + 1) / $_G['ppp']);}-->
    <!--{if $totalpage > $page}-->
    <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype={if $ordertype != 1}2{else}1{/if}&threads=thread" class="morelink" data-num="{$totalpage}-{$page}">$langplus[more]</a>
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage_mediapost.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}-->
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->
</div>
<!--{eval $vtperpage = $relatedmedianums; $vtarticleday = $relatedmediatimes; $vtpostsorts = $relatedmediasorts; $vtonlypic = 0; }-->
<!--{eval require_once(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/viewthreadlist.php');}-->
<!--{if $vtslist}-->
<div class="relateitem video_hot morebox">
    <ul>
        <!--{loop $vtslist $vts}-->
        <li>
            <a href="forum.php?mod=viewthread&tid={$vts[tid]}" class="relateitem_subject nopic">
                <div class="relateitem_title">{$vts[subject]}</div>
                <div class="relateitem_time">
                    <!--{if $vts[views] > 9999 }-->
                    <!--{eval $vts[views] = round($vts[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    {$vts[views]}{lang replycredit_time}{$langplus[plays]}
                    <span class="y">{$vts[dateline]}</span>
                </div>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
<!--{else}-->
<div class="relateitem video_hot morebox">
<div class="r-block bbno">{$langplus[notime]}{lang order_heats}{$langplus[video]}</div>
</div>
<!--{/if}-->
</div>
<!-- main postlist end -->
<!--{subtemplate forum/forumdisplay_fastpost}-->
<!--{hook/viewthread_bottom_mobile}-->
<!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') == false && strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') == false && (strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false)}-->
<!--{eval $thread['thumb'] = DB::result_first("SELECT attachment FROM  ".DB::table("forum_attachment_".substr($thread['tid'],-1,1))." WHERE tid = ".$thread['tid']." and width>0 order by dateline asc LIMIT 0 , 1");}-->
<div id="myshare" class="browsershare"></div>
<div class="close_s"></div>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/share.js?{VERHASH}"></script>
<script type="text/javascript">var config = {url:'{$_G['siteurl']}/forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]',title:'{$_G[forum_thread][subject]}',desc:'{$_G[forum_thread][subject]}',img:'{if $thread[thumb]}{$_G['siteurl']}/{$_G['setting']['attachurl']}/forum/{$thread[thumb]}{elseif $logourl}{$_G['siteurl']}/{$logourl}{/if}',};var share_obj = new myshare('myshare',config);</script>
<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false }-->
<div id="myshare"></div>
<div class="close_s1"></div>
<!--{else}-->
<div class="share_browser"><p>{$langplus[share_browser]}</p><img src="template/v2_mbl20121009/touch_plus/image/browser_share_icon.png"/></div>
<div class="close_s"></div>
<!--{/if}-->
<div class="close_m"></div>
<div class="close_p"></div>
<!--{if $_G[forum_thread][special] == 2}-->
<div class="close_p1"></div>
<!--{/if}-->
<script type="text/javascript">
$(document).ready(function(){
	<!--{if $_G[uid]}-->
	$(document).on('click','.moreaction',function(){				
		var menupsid = $(this).parent('.viewpost').next('.menups').attr('id');		
		$('#' + menupsid).fadeIn();
		$('.close_m').show();
		$(this).addClass('popon');
	});
	$('.close_m').off().on('touchstart',function(){
		$('.menups').hide();
		$('.popon').removeClass('popon');
		$(this).hide();
	});
	$(document).on('click','.menups a',function(){
		$('.menups, .close_m').hide();
		$('.popon').removeClass('popon');
	});
	$(document).on('click','.ajaxjump',function(){
		popup.open('<div class="cloading"></div>');		
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=ajaxjump&inajax=1',
			data:{'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);			
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});	
	<!--{/if}-->    
    $('.viewvname').click(function(){
        $(this).toggleClass("viewvname_show");
        $('.viewcontent').toggle();
    });
    $(window).scroll(function() {
        if ($(window).scrollTop() > 25) {
            $('.viewmedia').addClass('viewmedia_shadow');
        }else{
            $('.viewmedia').removeClass('viewmedia_shadow');
        }
    });
    $('.viewforum .video_tab').click(function(){
        $('.viewforum .video_tab').eq($(this).index()).addClass('on').siblings().removeClass('on');
        $('.morebox').eq($(".viewforum .video_tab").index(this)).show().siblings().hide();
        if($('.viewforum .video_tab:first').hasClass('on')){
            $('.moremedia').attr('disable', 'true');
        }else{
            $('.moremedia').attr('disable', 'false');
        }
    });
});
</script>
<!--{block scrollplus}-->
<div class="scroll_plus"><!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}--><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="scroll_notice"><i></i></a><!--{/if}--><!--{if $diypostlinks ==1}--><a href="forum.php" class="scroll_home"></a><!--{elseif $diypostlinks == 2}--><!--{if $_G['basescript'] == 'group'}--><a href="group.php" class="scroll_group"></a><!--{else}--><a href="forum.php?forumlist=1" class="scroll_forum"></a><!--{/if}--><!--{/if}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="scroll_post"></a><a href="$upnavlink" class="scroll_goback"></a></div>
<!--{/block}-->