<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang manage}<!--{/block}-->
<!--{template common/header}-->
<div class="tip">
<!--{if in_array($_GET[action], array('delpost', 'banpost', 'warn', 'stickreply', 'delcomment'))}-->
	<form id="topicadminform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&action=$_GET[action]&modsubmit=yes&modclick=yes&mobile=2" >
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="fid" value="$_G[fid]" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<input type="hidden" name="page" value="$_G[page]" />
		<input type="hidden" name="reason" value="{lang topicadmin_mobile_mod}" />
    <!--{if $_GET[action] == 'delpost'}-->
            <dt>{lang admin_delpost_confirm}</dt>
            $deleteid
			<dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();" >{lang cancel}</a></dd>
	<!--{elseif $_GET[action] == 'banpost'}-->
		<dt class="mdets_option">            
            $banid
            <p class="mdetslabel"><span><label><input type="radio" name="banned" class="pr" value="1" $checkban />{lang admin_banpost}</label></span><span><label><input type="radio" name="banned" class="pr" value="0" $checkunban />{lang admin_unbanpost}</label></span></p>
		</dt>
		<dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();" >{lang cancel}</a></dd>
    <!--{elseif $_GET[action] == 'warn'}-->
		<dt class="mdets_option">            
            $warnpid
            <p class="mdetslabel"><span><label><input type="radio" name="warned" class="pr" value="1" $checkwarn />{lang topicadmin_warn_add}</label></span><span><label><input type="radio" name="warned" class="pr" value="0" $checkunwarn />{lang topicadmin_warn_delete}</label></span></p>
		</dt>
		<dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();" >{lang cancel}</a></dd>
		<!--{elseif $_GET[action] == 'stickreply'}-->			
		<dt class="mdets_option">            
            $stickpid
            <p class="mdetslabel" ><span><label><input type="radio" name="stickreply" class="pr" value="1" checked="checked"/>{lang admin_stickreply}</label></span><span><label><input type="radio" name="stickreply" class="pr" value="0" />{lang admin_unstickreply}</label></span></p>
		</dt>
		<dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();" >{lang cancel}</a></dd>
        <!--{elseif $_GET[action] == 'delcomment'}-->
        <dt>
        <p>{lang topicadmin_delet_comment}</p>
        $deleteid
        </dt>
        <dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="{if $_GET[trade_delcomment]}formsdialog{else}formdialog{/if} button2"><a href="javascript:;" onclick="popup.close();" >{lang cancel}</a></dd>
    <!--{/if}-->
    </form>
<!--{else}-->
    	<dt>{lang admin_threadtopicadmin_error}</dt>
		<dd><input type="button" onclick="popup.close();" class="button2" value="{lang confirms}" /></dd>
<!--{/if}-->
</div>
<!--{template common/footer}-->
