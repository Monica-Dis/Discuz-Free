<?php echo 'From: DisM.taobao.com';exit;?>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/optionimgload.js?{VERHASH}"></script>
<div id="floatpost"></div>
<script type="text/javascript">
$(document).ready(function() {
	$(document).on('click','.close_uploadimg',function(){			
		$('.uploadimg').remove()
	});
	$(document).on('click','.upbutton',function(){			
		$('.uploadimg').fadeOut();
	});
	$(document).on('change','.upbutton',function(){
		popup.open('<div class="lmVdjV39q3EP"></div>');
	});
});
</script>
	  <input type="hidden" name="trade" value="yes" />
	  <input type="hidden" name="item_type" value="1" />
	  <li class="IHUDUAqpiULT">{lang post_message1}</li>
	  <li><input type="text" name="item_name" id="item_name" value="$trade[subject]" tabindex="1" placeholder="{lang post_trade_name}" /></li>
	  <li class="n9Jda92Vbj4A"><input type="text" name="item_number" id="item_number" value="$trade[amount]" tabindex="1" placeholder="{lang post_trade_number}" />
	  <div class="ifiKZQ0GkoOQ">
		<select id="item_quality" name="item_quality" tabindex="1">
			<option value="1" {if $trade['quality'] == 1}selected="selected"{/if}>{lang trade_new}</option>
			<option value="2" {if $trade['quality'] == 2}selected="selected"{/if}>{lang trade_old}</option>
		</select>
	  </div>
      </li>      
	  <li class="PNg0sSmTWhjQ">
      <div class="ifiKZQ0GkoOQ">
		<select name="paymethod" id="paymethod" onchange="document.getElementById('tenpayseller').style.display = this.value == 1 ? 'none' : ''" >                
			<!--{if $_G[setting][ec_tenpay_opentrans_chnid]}--><option value="0" {if $trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_online}</option><!--{/if}-->
			<option value="1" {if !$trade[tenpayaccount]}selected{/if}>{lang post_trade_paymethod_offline}</option>
		</select>
	  </div>
      <div class="ifiKZQ0GkoOQ">
		<select name="transport" id="transport" onchange="document.getElementById('logisticssetting').style.display = this.value == 'virtual' ? 'none' : ''">
			<option value="virtual" {if $trade['transport'] == 3}selected="selected"{/if}>{lang post_trade_transport_virtual}</option>
			<option value="seller" {if $trade['transport'] == 1}selected="selected"{/if}>{lang post_trade_transport_seller}</option>
			<option value="buyer" {if $trade['transport'] == 2}selected="selected"{/if}>{lang post_trade_transport_buyer}</option>
			<option value="logistics" {if $trade['transport'] == 4}selected="selected"{/if}>{lang trade_type_transport_physical}</option>
			<option value="offline" {if $trade['transport'] == 0}selected="selected"{/if}>{$langplus[tradeoffline]}</option>
		</select>
      </div>
	  </li>      
	  <li id="tenpayseller"{if !$trade[tenpayaccount]} style="display:none"{/if}>
		<input type="text" name="tenpay_account" id="tenpay_account" value="$trade[tenpayaccount]" tabindex="2" placeholder="{lang post_trade_tenpay_seller}">
	  </li>
	  <li class="2P9JnYIltH6w">
      <div class="CGJaxYQRunxE">
		<input type="text" name="item_price" id="item_price" value="$trade[price]" tabindex="1" placeholder="{lang post_current_price}" />
      </div>
      <div class="CGJaxYQRunxE">
		<input type="text" name="item_costprice" id="item_costprice" value="$trade[costprice]" tabindex="1" placeholder="{lang post_original_price}" />
      </div>
	  </li>      
	  <!--{if $_G['setting']['creditstransextra'][5] != -1}-->      
	  <li class="2P9JnYIltH6w">
      <div class="CGJaxYQRunxE">
		<input type="text" name="item_credit" id="item_credit" value="$trade[credit]" tabindex="1" placeholder="{lang post_current_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})" />
      </div>
      <div class="CGJaxYQRunxE">
		<input type="text" name="item_costcredit" id="item_costcredit" value="$trade[costcredit]" tabindex="1" placeholder="{lang post_original_credit}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]})" />
      </div>
	  </li>
	  <!--{/if}-->      
	  <li id="logisticssetting"{if !$trade['transport'] || $trade['transport'] == 3} style="display:none"{/if}>
		<div class="U32zS0Slv1zo"><input type="text" name="postage_mail" id="postage_mail" value="$trade[ordinaryfee]" placeholder="{lang post_trade_transport_mail}{$langplus[cost]}"/></div>
		<div class="U32zS0Slv1zo"><input type="text" name="postage_express" id="postage_express" value="$trade[expressfee]" placeholder="{lang post_trade_transport_express}{$langplus[cost]}"/></div>
		<div class="U32zS0Slv1zo"><input type="text" name="postage_ems" id="postage_ems" value="$trade[emsfee]" placeholder="EMS{$langplus[cost]}"/></div>
	  </li>	  
      <li><input type="text" name="item_locus" id="item_locus" value="$trade[locus]" tabindex="1" placeholder="{lang post_trade_locus}" /></li>
      <li><input type="text" name="item_expiration" id="item_expiration" autocomplete="off" value="$trade[expiration]" tabindex="1" placeholder="{lang valid_before}" /></li>
	  <!--{if $allowpostimg}-->
	  <li class="g9YkQEgAbzDO">
      <input type="hidden" name="tradeaid" id="tradeaid" {if $tradeattach[attachment]}value="$tradeattach[aid]" {/if}/>
      <input type="hidden" name="tradeaid_url" id="tradeaid_url" />
      <div id="tradeattach_image" class="xdkz0g8ryJ1U">
      <!--{if $tradeattach[attachment]}-->
      <div class="k7aGLZYzYOVF"><a href="$tradeattach[url]/$tradeattach[attachment]" ><img src="$tradeattach[url]/{if $tradeattach['thumb']}{eval echo getimgthumbname($tradeattach['attachment']);}{else}$tradeattach[attachment]{/if}"/></a></div>
      <!--{/if}-->
      </div>
      <button type="button" class="vOHbt7gptCtV" onclick="uploadWindow($_G['fid'],function (aid, url){tradeaid_upload(aid, url)})"><i class="AG5yZ3ftzshu"></i></button>
	  <span>{lang post_trade_picture}</span>
	  <script type="text/javascript" reload="1">
	  function tradeaid_upload(aid, url) {
		  $('tradeaid_url').value = url;
		  updatetradeattach(aid, url, '{$_G['setting']['attachurl']}forum');
	  }
      </script>
      </li>
	  <!--{/if}-->