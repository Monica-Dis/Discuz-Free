<?php echo 'From: DisM.taobao.com';exit;?>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/optionimgload.js?{VERHASH}"></script>
<div id="floatpost"></div>
<script type="text/javascript">
$(document).ready(function() {
	$(document).on('click','.close_uploadimg',function(){			
		$('.uploadimg').remove()
	});
	$(document).on('click','.upbutton',function(){			
		$('.uploadimg').fadeOut();
	});
	$(document).on('change','.upbutton',function(){
		popup.open('<div class="lmVdjV39q3EP"></div>');
	});
});
</script> 
  <li class="a61Pq7Hd0cr2">
  <div id="certainstarttime" {if $activity['starttimeto']}style="display: none"{/if}><input type="text" name="starttimefrom[0]" id="starttimefrom_0" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" placeholder="{lang post_event_time}" /></div>  
  <div id="uncertainstarttime" {if !$activity['starttimeto']}style="display: none"{/if}>  
    <input type="text" name="starttimefrom[1]" id="starttimefrom_1" autocomplete="off" value="$activity[starttimefrom]" tabindex="1" placeholder="{lang activity_starttime}" />
    <em>-</em>
    <input type="text" name="starttimeto" id="starttimeto" autocomplete="off" value="{if $activity['starttimeto']}$activity[starttimeto]{/if}" tabindex="1" placeholder="{lang endtime}" />
  </div>
  <label for="activitytime"><input type="checkbox" id="activitytime" name="activitytime" onclick="if(this.checked) {$('#certainstarttime').hide();$('#uncertainstarttime').show();} else {$('#certainstarttime').show();$('#uncertainstarttime').hide();}" value="1" {if $activity['starttimeto']}checked{/if} tabindex="1" /><i class="vc9TIbYYXiSx"></i></label>
  </li>  
  <li><input type="text" name="activityplace" id="activityplace" value="$activity[place]" tabindex="1" placeholder="{lang activity_space}" /></li>
  <!--{if $_GET[action] == 'newthread'}-->
  <li><input name="activitycity" id="activitycity" type="text" tabindex="1" placeholder="{lang activity_city}" /></li>
  <!--{/if}-->  
  <li{if $activitytypelist} class="5ACgPL8CM6Q8"{/if}><input type="text" id="activityclass" name="activityclass" value="$activity[class]" tabindex="1" placeholder="{lang activiy_sort}" />
  <!--{if $activitytypelist}-->
    <div class="ifiKZQ0GkoOQ">
    <select onchange="$('#activityclass').val($(this).find('option:selected').val());">
      <!--{loop $activitytypelist $type}-->
      <option value="$type">$type</option>
      <!--{/loop}-->
    </select>
    </div>
  <!--{/if}-->
  </li>
  <li class="3hWulFJVYNDC"><input type="text" name="activitynumber" id="activitynumber" value="$activity[number]" tabindex="1" placeholder="{lang activity_need_member}" />
  <div class="ifiKZQ0GkoOQ">
  <select name="gender" id="gender" >
      <option value="0" {if !$activity['gender']}selected="selected"{/if}>{lang unlimited}</option>
      <option value="1" {if $activity['gender'] == 1}selected="selected"{/if}>{lang male}</option>
      <option value="2" {if $activity['gender'] == 2}selected="selected"{/if}>{lang female}</option>
  </select>
  </div>
  </li>
  <!--{if $_G['setting']['activityextnum']}-->
  <li><textarea name="extfield" id="extfield" rows="3" placeholder="{lang other_data} , {lang post_activity_message} {$_G['setting']['activityextnum']} {lang post_option}" ><!--{if $activity['ufield']['extfield']}-->$activity[ufield][extfield]<!--{/if}--></textarea></li>
  <!--{/if}--> 
  <!--{if $_G['setting']['activityfield']}-->
  <li class="aG2JZ4lKiZLo">
  <!--{loop $_G['setting']['activityfield'] $key $val}-->
    <span><label for="userfield_$key"><input type="checkbox" name="userfield[]" id="userfield_$key" value="$key"{if $activity['ufield']['userfield'] && in_array($key, $activity['ufield']['userfield'])} checked="checked"{/if} /><em>$val</em></label></span>
  <!--{/loop}-->
  </li>
  <!--{/if}-->  
  <li><input type="text" name="activitycredit" id="activitycredit"  value="$activity[credit]" placeholder="{lang consumption_credit} ({$_G['setting']['extcredits'][$_G['setting']['activitycredit']][title]})" /></li>  
  <li><input type="text" name="cost" id="cost" value="$activity[cost]" tabindex="1" placeholder="{lang activity_payment} ({lang payment_unit})" /></li>  
  <li><input type="text" name="activityexpiration" id="activityexpiration" autocomplete="off" value="$activity[expiration]" tabindex="1" placeholder="{lang post_closing}" /></li>
  <!--{if $allowpostimg}-->
  <li class="g9YkQEgAbzDO">  
  <input type="hidden" name="activityaid" id="activityaid" {if $activityattach[attachment]}value="$activityattach[aid]" {/if}/>
  <input type="hidden" name="activityaid_url" id="activityaid_url" />
  <div id="activityattach_image" class="xdkz0g8ryJ1U">
  <!--{if $activityattach[attachment]}-->
  <div class="k7aGLZYzYOVF"><a href="$activityattach[url]/$activityattach[attachment]"><img src="$activityattach[url]/{if $activityattach['thumb']}{eval echo getimgthumbname($activityattach['attachment']);}{else}$activityattach[attachment]{/if}" /></a></div>
  <!--{/if}-->
  </div>
  <button type="button" class="vOHbt7gptCtV" onclick="uploadWindow($_G['fid'],function (aid, url){activityaid_upload(aid, url)})"><i class="AG5yZ3ftzshu"></i></button>
  <span>{lang post_topic_image}</span>
  <script type="text/javascript" reload="1">
  function activityaid_upload(aid, url) {
	  insert_id('activityaid_url').value = url;
	  updateactivityattach(aid, url, '{$_G['setting']['attachurl']}forum', 'activityaid');
  }
  </script>
  </li>
  <!--{/if}-->