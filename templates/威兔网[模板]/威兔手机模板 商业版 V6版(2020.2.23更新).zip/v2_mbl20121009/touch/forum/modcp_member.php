<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $op == 'ban'}-->
<!--{if $op == 'ban' && $member && !$error}-->
	<form method="post" autocomplete="off" action="{$cpscript}?mod=modcp&action=$_GET[action]&op=$op">
		<input type="hidden" name="formhash" value="{FORMHASH}">
		<input type="hidden" name="username" value="$_GET['username']">
        <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="uid" value="$_GET['uid']">
        	<div class="pt">{lang result}<em class="y"><a href="forum.php?mod=modcp&action=member&op=ban" class="blue" >[{lang find}{lang more}]</a></em></div>
            <div class="inputall">
            <ul>
            <li><a href="home.php?mod=space&uid=$member[uid]" class="xi2">$member[username]</a> &nbsp;UID: $member[uid] <br /><!--{if $member[groupid] == 4}-->{lang modcp_members_status_banpost}<!--{elseif $member[groupid] == 5}-->{lang modcp_members_status_banvisit}<!--{else}-->{lang modcp_members_status_normal}<!--{/if}--> <!--{if $member['banexpiry']}-->&nbsp;{lang valid_before} $member['banexpiry']<!--{/if}--></li>
            <li>{lang changeto}: &nbsp;&nbsp;<!--{if $member[groupid] == 4 || $member[groupid] == 5}-->
						<input type="radio" name="bannew" id="bannew_0" value="0" checked="checked" class="pc checkbox" /><label for="bannew_0">{lang modcp_members_status_normal}</label> &nbsp;&nbsp;&nbsp;
					<!--{/if}-->
					<!--{if $member[groupid] != 4 && $_G[group][allowbanuser]}--><input type="radio" name="bannew" id="bannew_4" class="pc checkbox" value="4" {if $member[groupid] != 4 && $member[groupid] != 5}checked="checked"{/if} /><label for="bannew_4">{lang modcp_members_status_banpost}</label> &nbsp;&nbsp;&nbsp;<!--{/if}-->
					<!--{if $member[groupid] != 5 && $_G[group][allowbanvisituser]}--><label><input type="radio" name="bannew" id="bannew_5" class="pc checkbox" value="5" {if $member[groupid] != 4 && $member[groupid] != 5 && !$_G[group][allowbanuser]}checked="checked"{/if} />{lang modcp_members_status_banvisit}</label><!--{/if}--></li>
            <li class="mbn">{lang expiry}</li>
            <li><input type="text" id="banexpirynew" name="banexpirynew" autocomplete="off" value="" /></li>
            <li class="warningmessage pbn">{lang modcp_members_ban_days_comment}</li>            
            <li><textarea name="reason" rows="3" cols="60" placeholder="{lang reason}">$member[signature]</textarea></li>
           <button type="submit" name="bansubmit" id="submit" value="true" class="button5">{lang submit}</button>           
        </ul>
        </div>
	</form>
  <!--{else}-->
<form method="post" autocomplete="off" action="{$cpscript}?mod=modcp&action=$_GET[action]&op=$op&mobile=2">
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <div class="pt">{lang mod_member_ban}</div>
    <div class="inputall">
    	<ul>
        <li>
        <!--{if !empty($error)}-->
            <!--{if $error == 1}-->
                {lang mod_message_member_search}
            <!--{elseif $error == 2}-->
                {lang mod_message_member_nonexistence}
            <!--{elseif $error == 3}-->
                {lang mod_message_member_nopermission}
                <!--{if $_G['adminid'] == 1}--><br />{lang mod_message_goto_admincp}
                <!--{/if}-->
            <!--{/if}-->
        <!--{/if}-->
        </li>
        <li><input type="text" name="username" value="" size="20" placeholder="{lang username}" /></li>
        <li><input type="text" name="uid" value="<!--{$member['uid']}-->" size="20" placeholder="UID" /></li>        
        <button type="submit" name="submit" id="searchsubmit" class="button5">{lang modcp_logs_search}</button>        
        </ul>
	</div>
</form>
<!--{/if}-->
<!--{else}-->
<div class="pt">{lang forum_manager}<span>&gt;</span><a href="javascript:history.back();">{lang back}</a></div>
<div class="r-block">{lang admin_threadtopicadmin_error}</div>
<!--{/if}-->