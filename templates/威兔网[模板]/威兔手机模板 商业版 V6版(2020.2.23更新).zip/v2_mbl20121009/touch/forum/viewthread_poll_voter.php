<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang poll_voters}<!--{/block}-->
<!--{template common/header}-->
<!--{if $_G['uid']}-->
<div class="bZM4tz7gGcZs" id="myshares"><a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]">$_G[forum_thread][subject]</a></div>
	<div class="oJn94bMQizS2">
    <div class="ifiKZQ0GkoOQ">
		<select onchange="{if !empty($_GET['inajax'])}showWindow('viewvote', 'forum.php?mod=misc&action=viewvote&tid=$_G[tid]&polloptionid=' + this.value){else}location.href = 'forum.php?mod=misc&action=viewvote&tid=$_G[tid]&polloptionid=' + this.value;{/if}">
		<!--{loop $polloptions $options}-->
			<option value="$options[polloptionid]"{if $options[polloptionid] == $polloptionid} selected="selected"{/if}>$options[polloption]</option>
		<!--{/loop}-->
		</select>
	</div>
    </div>
    <!--{if !$voterlist}-->
    <div class="sqK9gG26iUGb">{lang none}{lang poll_voters}</div>
	<!--{else}-->
    <div class="iLwfdWXaH67L">
    <ul id="alist" class="HwKFWtPXAVEl">
		<!--{loop $voterlist $voter}-->
			<li><a href="home.php?mod=space&uid=$voter[uid]&do=profile" ><img src="{avatar($voter[uid],middle,true)}" class="UoRZiAghxSa8" />$voter[username]</a></li>
		<!--{/loop}-->
    </ul>
	<!--{/if}-->
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($count / $perpage);}-->
	<!--{if $totalpage > $page}-->   
    <a href="forum.php?mod=misc&action=viewvote&tid=$_G[tid]&polloptionid=$polloptionid" class="SVXNXIMF0su9" data-num="{$totalpage}-{$page}"><span>$langplus[more]</span></a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}--> 
    <!--{else}-->   
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->
    </div>
<!--{else}-->
<div class="sqK9gG26iUGb">{$langplus[no_logintip]}</div>
<!--{/if}-->

<!--{template common/footer}-->