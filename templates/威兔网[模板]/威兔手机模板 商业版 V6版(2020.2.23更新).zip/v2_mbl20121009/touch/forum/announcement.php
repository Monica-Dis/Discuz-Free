<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="forum.php?mod=announcement">{lang announcement}</a><!--{/block}-->
<!--{template common/header}-->
<div class="NFqzmz9jbp7q">
  <ul>
		<!--{loop $announcelist $ann}-->
		<li class="ann{if $_GET['id'] == $ann[id]} ann_hl{/if}" id="an{$ann[id]}">
            <div class="fSGhjVGM0ctX">$ann[subject]</div>				
                <div class="AuhtoJwzElCv" id="announce{$ann[id]}"{if $_GET['id'] == $ann[id]} style="display:block;"{/if}>                
                $ann[message]
                <div class="4XvC6O7i2dPP"><a href="home.php?mod=space&username=$ann[authorenc]&do=profile">{$ann[author]}</a><span>{$ann[starttime]}</span></div>
				</div>
        </li>
		<!--{/loop}-->
  </li>
</div>
<script type="text/javascript">
$('.ann_title').on('click', function() {				
	var liid = $(this).parent('.ann').attr('id');
	var contentid = $(this).next('.ann_content').attr('id'); 	
	$('#' + liid).toggleClass('ann_hl');
	$('#' + contentid).slideToggle();
	});	
</script>
<!--{template common/footer}-->