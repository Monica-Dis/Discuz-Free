<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang trade}{lang trade_order}<!--{/block}-->
<!--{template common/header}-->
		<form method="post" autocomplete="off" id="tradepost" name="tradepost" action="forum.php?mod=trade&orderid=$orderid">
			<!--{if !empty($_G['gp_modthreadkey'])}-->
				<input type="hidden" name="modthreadkey" value="$_G[gp_modthreadkey]" />
			<!--{/if}-->
			<!--{if !empty($_G['gp_tid'])}-->
				<input type="hidden" name="tid" value="$_G[gp_tid]" />
			<!--{/if}-->
			<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="z76GhPvFhhjY">
					<div class="yNhKM20otpu1"><!--{if !$tradelog[offline]}-->{lang trade_pay_alipay}<!--{else}-->{lang trade_pay_offline}<!--{/if}--></div>
					<ul>
						<li class="sJ1YXcuMPG4l">
							<span>{lang status}: </span>
							$tradelog[statusview] ($tradelog[lastupdate])
						</li>
						<!--{if $tradelog[offline] && $offlinenext}-->
							<li>
								<input id="password" name="password" type="password" placeholder="{lang trade_password}" />
							</li>
							<li>
								<textarea id="buyermsg" id="message" name="message" rows="3" placeholder="{lang trade_message}$trade_message {lang trade_seller_remark_comment}"></textarea>
								<p class="sEj1sHHzaWFN"></p>
							</li>
							<li class="m4blozPLh0lf">
								<!--{loop $offlinenext $nextid $nextbutton}-->
									<button type="button" class="hWkKLBWkXyXu" onclick="tradepost.offlinestatus.value = '$nextid';offlinesubmit.click();">$nextbutton</button>
								<!--{/loop}-->
								<input type="hidden" name="offlinestatus" value="" />
								<input type="submit" id="offlinesubmit" name="offlinesubmit" style="display: none" />
							</li>
						<!--{/if}-->
						<!--{if trade_typestatus('successtrades', $tradelog[status]) || trade_typestatus('refundsuccess', $tradelog[status])}-->

								<!--{if $tradelog[ratestatus] == 3}-->
									<li class="ip1114f2LMl0">{lang eccredit_post_between}</li>
								<!--{elseif ($_G['uid'] == $tradelog[buyerid] && $tradelog[ratestatus] == 1) || ($_G['uid'] == $tradelog[sellerid] && $tradelog[ratestatus] == 2)}-->
									<li class="ip1114f2LMl0">{lang eccredit_post_waiting}</li>
								<!--{else}-->
									<li class="QCPEwKSaGGkZ">
									<!--{if $_G['uid'] == $tradelog[buyerid]}-->
										<a href="home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=0">{lang eccredit1}</a>
									<!--{elseif $_G['uid'] == $tradelog[sellerid]}-->
										<a href="home.php?mod=spacecp&ac=eccredit&op=rate&orderid=$tradelog[orderid]&type=1">{lang eccredit1}</a>
									<!--{/if}-->
										<!--{if ($_G['uid'] == $tradelog[buyerid] && $tradelog[ratestatus] == 2) || ($_G['uid'] == $tradelog[sellerid] && $tradelog[ratestatus] == 1)}-->
										&nbsp;&nbsp;&nbsp;&nbsp;{lang eccredit_post_already}
										<!--{/if}-->
									</li>
								<!--{/if}-->
						<!--{elseif !$tradelog[offline]}-->
								<li>{lang trade_online_tradeurl}</li>
								<li class="m4blozPLh0lf">
									<!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}-->
										<!--{if $tradelog[tenpayaccount]}-->
											<button class="hWkKLBWkXyXu" type="button" name="" onclick="window.open('forum.php?mod=trade&orderid=$orderid&pay=yes&apitype=tenpay','','')"><span>{lang trade_online_tenpay}</span></button>
										<!--{/if}-->
									<!--{else}-->
										<!--{if $tradelog[paytype] == 1}-->
											<button class="hWkKLBWkXyXu" type="button" onclick="window.open('$loginurl', '', '')"><span>{lang trade_order_status}</span></button>
										<!--{/if}-->
										<!--{if $tradelog[paytype] == 2}-->
											<button class="hWkKLBWkXyXu" type="button" onclick="window.open('$loginurl', '', '')"><span>{lang tenpay_trade_order_status}</span></button>
										<!--{/if}-->
									<!--{/if}-->
								</li>
						<!--{/if}-->
					</ul>
				</div>
				<div class="Iqlf5Gx2MwNo">
					<div class="yNhKM20otpu1">{lang trade_order}</div>
					<div class="pvuTokKrzRN0">
						<div class="9wXhwTM6eBJB">
							<a href="forum.php?mod=viewthread&do=tradeinfo&tid=$trade[tid]&pid=$trade[pid]"><!--{if $trade['aid']}--><img src="{echo getforumimg($trade[aid])}" /><!--{else}--><img src="{IMGDIR}/nophotosmall.gif" /><!--{/if}--></a>
						</div>
						<h1><a href="forum.php?mod=viewthread&do=tradeinfo&tid=$tradelog[tid]&pid=$tradelog[pid]">$tradelog[subject]</a></h1>
						<p>
							<span>{$langplus[price]}:</span>
							<!--{if $tradelog[price] > 0}--><span>$tradelog[price]</span>&nbsp;{lang payment_unit}&nbsp;&nbsp;<!--{/if}-->
							<!--{if $_G['setting']['creditstransextra'][5] != -1 && $tradelog[credit]}-->{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}&nbsp;<span>$tradelog[credit]</span>&nbsp;{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}<!--{/if}-->
						</p>
						<p>
							<!--{if $_G['uid'] != $tradelog['sellerid']}-->
							<span>{lang trade_seller}:</span>
							<a href="home.php?mod=space&uid=$tradelog[sellerid]&do=profile">$tradelog[seller]</a>
							&nbsp;<a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$tradelog[sellerid]&touid=$tradelog[sellerid]&pmid=0&daterange=2" class="F3pveqiOE331"><i class="uyjBO3ew0luI"></i></a>
							<!--{/if}-->
							<!--{if $_G['uid'] != $tradelog['buyerid']}-->
							<span>{lang trade_buyer}:</span>
							<a href="home.php?mod=space&uid=$tradelog[buyerid]&do=profile">$tradelog[buyer]</a>
							&nbsp;<a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$tradelog[buyerid]&touid=$tradelog[buyerid]&pmid=0&daterange=2" class="F3pveqiOE331"><i class="uyjBO3ew0luI"></i></a>
							<!--{/if}-->
						</p>
					</div>
					<table cellspacing="0" cellpadding="0" class="CBXzlsdiQJdd">
						<!--{if $tradelog[tradeno]}-->
						<tr>
							<th>{lang trade_order_no}:</th>
							<td><a href="$loginurl">$tradelog[tradeno]</a></td>
						</tr>
						<!--{/if}-->
						<!--{if $tradelog[status] == 0 && $tradelog[sellerid] == $_G['uid']}-->
						<tr>
							<th>{lang trade_baseprice}:</th>
							<td>
								<span><input type="text" id="newprice" name="newprice" value="$tradelog[baseprice]" style="width:80px" /></span> {lang payment_unit}&nbsp;&nbsp;
								<!--{if $_G['setting']['creditstransextra'][5] != -1 && $tradelog[credit]}-->
								<input type="text" id="newcredit" name="newcredit" value="$tradelog[basecredit]" style="width:80px" /> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}
								<!--{/if}-->
							</td>
						</tr>
						<!--{/if}-->
						<tr>
							<th>{lang trade_nums}:</th>
							<td><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newnumber" name="newnumber" value="$tradelog[number]" /><!--{else}-->$tradelog[number]<!--{/if}--></td>
						</tr>
						<tr>
							<th>{lang post_trade_transport}:</th>
							<td>
								<!--{if $tradelog['transport'] == 0}-->{lang post_trade_transport_offline}<!--{/if}-->
								<!--{if $tradelog['transport'] == 1}-->{lang post_trade_transport_seller}<!--{/if}-->
								<!--{if $tradelog['transport'] == 2}-->{lang post_trade_transport_buyer}<!--{/if}-->
								<!--{if $tradelog['transport'] == 3}-->{lang post_trade_transport_virtual}<!--{/if}-->
								<!--{if $tradelog['transport'] == 4}-->{lang post_trade_transport_physical}<!--{/if}-->
								<!--{if $tradelog['transport']}-->
									&nbsp;{lang trade_transportfee}
									<!--{if $tradelog[status] == 0 && $tradelog[sellerid] == $_G['uid']}--><input type="text" name="newfee" value="$tradelog['transportfee']" style="width:80px" />&nbsp;<!--{else}-->$tradelog[transportfee]&nbsp;<!--{/if}-->
									{lang payment_unit}
								<!--{/if}-->
							</td>
						</tr>
						<!--{if $tradelog['transport'] != 3}-->
						<tr>
							<th>{lang trade_buyername}:</th>
							<td><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyername" name="newbuyername" value="$tradelog[buyername]" maxlength="50" /><!--{else}-->$tradelog[buyername]<!--{/if}--></td>
						</tr>
						<tr>
							<th>{lang trade_buyercontact}:</th>
							<td><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyercontact" name="newbuyercontact" value="$tradelog[buyercontact]" maxlength="140" /><!--{else}-->$tradelog[buyercontact]<!--{/if}--></td>
						</tr>
						<tr>
							<th>{lang trade_buyerzip}:</th>
							<td><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyerzip" name="newbuyerzip" value="$tradelog[buyerzip]" maxlength="20" /><!--{else}-->$tradelog[buyerzip]<!--{/if}--></td>
						</tr>
						<tr>
							<th>{lang trade_buyerphone}:</th>
							<td><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyerphone" name="newbuyerphone" value="$tradelog[buyerphone]" maxlength="20" /><!--{else}-->$tradelog[buyerphone]<!--{/if}--></td>
						</tr>
						<tr>
							<th>{lang trade_buyermobile}:</th>
							<td><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><input type="text" id="newbuyermobile" name="newbuyermobile" value="$tradelog[buyermobile]" maxlength="20" /><!--{else}-->$tradelog[buyermobile]<!--{/if}--></td>
						</tr>
						<!--{else}-->
							<input type="hidden" name="newbuyername" value="" />
							<input type="hidden" name="newbuyercontact" value="" />
							<input type="hidden" name="newbuyerzip" value="" />
							<input type="hidden" name="newbuyerphone" value="" />
							<input type="hidden" name="newbuyermobile" value="" />
						<!--{/if}-->
						<tr>
							<th valign="top">{lang trade_seller_remark}:</th>
							<td><!--{if $tradelog[status] == 0 && $tradelog[buyerid] == $_G['uid']}--><textarea id="newbuyermsg" name="newbuyermsg" rows="3" maxlength="240" placeholder="{lang trade_seller_remark_comment}">$tradelog[buyermsg]</textarea><!--{else}--><!--{if $tradelog[buyermsg]}-->$tradelog[buyermsg]<!--{else}-->{lang none}<!--{/if}--><!--{/if}--></td>
						</tr>
						<!--{if $tradelog[status] == 0 && ($_G['uid'] == $tradelog['sellerid'] || $_G['uid'] == $tradelog['buyerid'])}-->
						<tr>
							<td colspan="2">
								<button class="AT79CTmqyiZt" type="submit" name="tradesubmit" value="true">{lang trade_submit_order}</button>
							</td>
						</tr>
						<!--{/if}-->
					</table>
				</div>
		<!--{if $tradelog['offline'] && !empty($messagelist)}-->
				<div class="vNVIatUpXgZC">
					<ul>
						<h1>{lang trade_message}</h1>
						<!--{loop $messagelist $message}-->
						<li>
							<a href="home.php?mod=space&uid=$message[0]&do=profile" class="x9hHSPQjdnYg"><!--{avatar($message[0],small)}--></a>
							<div class="K8Nlb7F457Y1">
							<a href="home.php?mod=space&uid=$message[0]&do=profile">$message[1]</a><em>$message[2]</em>
							</div>
							$message[3]
						</li>
						<!--{/loop}-->
					</ul>
				</div>
		<!--{/if}-->
		</form>
<!--{if $_G['uid'] != $tradelog['sellerid'] || $_G['uid'] != $tradelog['buyerid']}-->
<script type="text/javascript">
	$(document).on('click', '#pmsubmit_btn', function() {
		var obj = $(this);
		var form = $(this.form);
		popup.open('<div class="lmVdjV39q3EP"></div>');
		$.ajax({
			type:'POST',
			url:form.attr('action') + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
				.success(function(s) {
					var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
					popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg+'</dt></div>');
					setTimeout(function(){
						$(".dialogbox, #mask").fadeOut();
					}, 1500);
				})
				.error(function() {
					popup.open('{lang networkerror}', 'alert');
				});
		return false;
	});
</script>
<!--{/if}-->
<!--{template common/footer}-->