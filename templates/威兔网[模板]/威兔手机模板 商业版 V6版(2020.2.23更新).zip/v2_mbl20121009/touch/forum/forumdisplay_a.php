<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $_G['forum_threadcount']}-->
<!--{template forum/displayorder}-->
<ul id="alist" class="HwKFWtPXAVEl">
    <!--{eval $ad = 1;}-->
    <!--{loop $_G['forum_threadlist'] $key $thread}-->
    <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
    {eval continue;}
    <!--{/if}-->
    <!--{if $thread['displayorder'] > $threaddisplayorder}-->
    <!--{else}-->
    <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
    {eval $displayorder_thread = 1;}
    <!--{/if}-->
    <!--{if $thread['moved']}-->
    <!--{eval $thread[tid]=$thread[closed];}-->
    <!--{/if}-->
    <!--{hook/forumdisplay_middle_v2_mobile}-->
    <!--{if $page == 1}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adforumdisplaya && in_array($_G['fid'],(array)unserialize($adforumdisplayida)) && $ad == $adforumdisplaytha}--><!--{$adforumdisplaya}--><!--{/if}-->
    <!--{if $adforumdisplayb && in_array($_G['fid'],(array)unserialize($adforumdisplayidb)) && $ad == $adforumdisplaythb}--><!--{$adforumdisplayb}--><!--{/if}-->
    <!--{if $adforumdisplayc && in_array($_G['fid'],(array)unserialize($adforumdisplayidc)) && $ad == $adforumdisplaythc}--><!--{$adforumdisplayc}--><!--{/if}-->
    <!--{if $adforumdisplayd && in_array($_G['fid'],(array)unserialize($adforumdisplayidd)) && $ad == $adforumdisplaythd}--><!--{$adforumdisplayd}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{eval $msgnumber = 120; }-->
    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/threadlist.php');}-->
    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/mediaplayer.php');}-->
    <!--{if $specialplugin == 0}--><!--{hook/forumdisplay_thread_mobile $key}--><!--{/if}-->
    <li class="n8ggAU9zmnpL">
        <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" class="yUloUBxjglb3" >
            <h1>
                <!--{if $thread['displayorder'] > 0}-->
                <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot;
                <!--{/if}-->
                <!--{if $thread[highlight]}--><span{$thread[highlight]}>{$thread[subject]}</span><!--{else}-->{$thread[subject]}<!--{/if}-->
                <!--{if $_G['forum']['threadtypes']['types'][$thread['typeid']] && $_G['forum']['threadtypes']['prefix'] > 0}-->
                <em class="WAO1ETmvH49Y">#{echo strip_tags($_G['forum']['threadtypes']['types'][$thread['typeid']])}#</em>
                <!--{/if}-->
                <!--{if $_G['forum']['threadsorts']['types'][$thread['sortid']] && $_G['forum']['threadsorts']['prefix'] > 0}-->
                <em class="WAO1ETmvH49Y">#{echo strip_tags($_G['forum']['threadsorts']['types'][$thread['sortid']])}#</em>
                <!--{/if}-->
                <!--{if $thread[icon] >= 0}-->
                <em class="ZUp4byFwR1BK">#{$_G[cache][stamps][$thread[icon]][text]}#</em>
                <!--{else}-->
                <!--{if $thread[heatlevel]}-->
                <em class="Z1K9j6zHkkNq">#{lang order_heats}#</em>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $thread['digest'] > 0}-->
                <em class="GR92yicG3zyZ">$langplus[digest]</em>
                <!--{/if}-->
            </h1>
            <!--{if $thread['msg'] && !$mediaplayer}--><p>{$thread['msg']}</p><!--{/if}-->
        </a>
        <!--{if $mediaplayer}--><div class="D0tnebHrGksS">$mediaplayer</div><!--{/if}-->
        <div class="hNOK3poJcpFf">
            <span>
                <!--{if $thread['authorid'] && $thread['author']}-->
                <a href="home.php?mod=space&uid=$thread[authorid]&do=profile" class="lhcsTc3xRkO8">$thread[author]</a>
                <!--{else}-->
                <a href="javascript:;" class="lhcsTc3xRkO8">$_G[setting][anonymoustext]</a>
                <!--{/if}-->
            </span>
            <!--{if $thread[replies]}-->
            <!--{if $thread[replies] > 9999 }-->
            <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{else}-->
            <!--{if $thread['isgroup'] != 1}-->
            <!--{if $thread[views] > 9999 }-->
            <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{else}-->
            <!--{if $groupnames[$thread[tid]][views] > 9999 }-->
            <!--{eval $groupnames[$thread[tid]][views] = round($groupnames[$thread[tid]][views] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
            <span>
                <!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}--><!--{if $thread['isgroup'] != 1}-->$thread[views]<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->{$langplus[browsed]}<!--{/if}-->
            </span>
            {$thread[dateline]}
            <!--{if $_G['setting']['recommendthread']['status']}-->
            <!--{if $thread[recommends] > 0}--><i class="Wh21Y2pBzti3"></i><!--{else}--><i class="UKfOChqXROBD"></i><!--{/if}-->
            <!--{else}-->
            <!--{if $thread[favtimes] > 0}--><i class="c5jXKWHqTOsX"></i><!--{else}--><i class="a4TcRfVF4aiG"></i><!--{/if}-->
            <!--{/if}-->
            <!--{if $thread['rate'] > 0}--><i class="ih2GBIpmzu4I"></i><!--{/if}-->
        </div>
    </li>
    <!--{/if}-->
    <!--{eval $ad++;}-->
    <!--{/loop}-->
</ul>
<!--{else}-->
<div class="sqK9gG26iUGb">{lang forum_nothreads}</div>
<!--{/if}-->