<?php echo 'From: DisM.taobao.com';exit;?>
    <!--{if $_GET[action] == 'newthread'}-->
        <li>
        <input type="text" name="rewardprice" id="rewardprice" value="" placeholder="{lang reward_price}" />
        </li>
    <!--{elseif $_GET[action] == 'edit'}-->
        <!--{if $isorigauthor}-->
            <!--{if $thread['price'] > 0}-->
                <li>
                <input type="text" name="rewardprice" id="rewardprice" value="$rewardprice" placeholder="{lang reward_price}" />
                </li>
            <!--{else}-->
                <li><span class="evXx4HZDPWdN">{lang post_reward_resolved}</span>
                <input type="hidden" name="rewardprice" value="$rewardprice"  /></li>
            <!--{/if}-->
        <!--{else}-->
            <!--{if $thread['price'] > 0}-->
                <li><span class="evXx4HZDPWdN">{lang reward_price}: $rewardprice {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}</span></li>
            <!--{else}-->
                <li><span class="evXx4HZDPWdN">{lang post_reward_resolved}</span></li>
            <!--{/if}-->
        <!--{/if}-->
    <!--{/if}-->
    <!--{if $_GET[action] == 'newthread' || $_G['setting']['rewardexpiration'] > 0}-->
        <li class="IHUDUAqpiULT">
        <!--{if $_GET[action] == 'newthread'}-->
        <p>    
        {lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
        <!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']}         {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
        , {lang reward_tax_after} <span id="realprice">0</span>
        {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
        , {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]} 
        </p>
        <!--{/if}-->
        <!--{if $_G['setting']['rewardexpiration'] > 0}-->
        <p>$_G['setting']['rewardexpiration'] {lang post_reward_message}</p>
        <!--{/if}-->
        </li>
    <!--{/if}-->
<!--{if $_GET[action] == 'newthread'}-->    
<script type="text/javascript">
	$(document).on('input value','#rewardprice',function(){
		var bonus = $(this).val();
		if(!bonus.search(/^\d+$/)) {
			var payams = Math.ceil(parseInt(bonus) + bonus * {$_G['setting']['creditstax']});
			$('#realprice').html(payams);
			if(payams > {echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);} || payams > 32767) {
				$('#realprice').addClass('orange');
			}else{
				$('#realprice').removeClass('orange');	
			}
		}else if(bonus == ''){
			$('#realprice').html('0');
		}
    });
</script> 
<!--{/if}-->      