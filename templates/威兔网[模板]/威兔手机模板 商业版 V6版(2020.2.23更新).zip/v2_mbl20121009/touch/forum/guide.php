<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="forum.php?mod=guide&view=newthread"><!--{if $_G[setting][navs][10][navname]}--> $_G[setting][navs][10][navname]<!--{else}-->{lang guide}<!--{/if}--></a><!--{/block}-->
<!--{template common/header}-->
<!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}--><!--{$adguide}--><!--{/if}-->
<!--{if $sortmenufloat}--><div class="AtXpQP883jim"><!--{/if}-->
    <div class="tabequal{if $sortmenufloat} sortmenus{/if}">
        <ul>
            <li{if $view == 'newthread'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=guide&view=newthread">{lang latest}</a></li>
            <li{if $view == 'new'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=guide&view=new">{lang reply}</a></li>
            <li{if $view == 'hot'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=guide&view=hot">{lang hot_thread}</a></li>
            <li{if $view == 'digest'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=guide&view=digest">{lang digest_posts}</a></li>
            <li{if $view == 'sofa'} class="E1x17Q9hYTmk"{/if}><a href="forum.php?mod=guide&view=sofa">{$langplus[guidesofa]}</a></li>
        </ul>
    </div>
<!--{if $sortmenufloat}--></div><!--{/if}-->
<!-- main threadlist start -->
<!--{loop $data $key $list}-->
<!--{if $guidelist == 1}-->
<!--{template forum/guide_list_row_a}-->
<!--{elseif $guidelist == 2}-->
<!--{template forum/guide_list_row_b}-->
<!--{elseif $guidelist == 3}-->
<!--{template forum/guide_list_row_c}-->
<!--{else}-->
<!--{template forum/guide_list_row}-->
<!--{/if}-->
<!--{/loop}-->
<!-- main threadlist end -->
	<!--{if $tplpages == 1}-->
    <!--{eval $totalpage = ceil($data[$view]['threadcount'] / $perpage);}-->
	<!--{if $totalpage > $_G['page']}-->   
    <a href="$theurl" class="SVXNXIMF0su9" data-num="{$totalpage}-{$_G['page']}">$langplus[more]</a>    
    <script src="template/v2_mbl20121009/touch_plus/js/ajaxpage.js?{VERHASH}"></script>
    <!--{/if}-->
    <!--{else}--> 
    <!--{if $multipage}-->$multipage<!--{/if}-->
    <!--{/if}-->
<!--{template common/footer}-->