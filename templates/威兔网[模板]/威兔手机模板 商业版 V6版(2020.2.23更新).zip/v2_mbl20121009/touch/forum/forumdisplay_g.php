<?php echo 'From: DisM.taobao.com';exit;?>
<link rel="stylesheet" href="template/v2_mbl20121009/touch_plus/css/jaudio.css" type="text/css" media="all">
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/jaudio.min.js?{VERHASH}" charset="{CHARSET}"></script>
<!--{if $_G['forum_threadcount']}-->
<!--{if (!$simplestyle || !$_G['forum']['allowside'] && $page == 1) && !empty($announcement) && $displayann == 1}-->
<div class="annlist"><i class="vt-volumes"></i>
    <!--{if empty($announcement['type'])}--><a href="forum.php?mod=announcement&id=$announcement[id]#$announcement[id]">$announcement[subject]</a><!--{else}--><a href="$announcement[message]">$announcement[subject]</a><!--{/if}-->
</div>
<!--{/if}-->
<div class="jAudio">
    <audio></audio>
    <div class="jAudio-playlist"></div>
    <div class="jAudio_footer">
        <div class="jAudio-ui">
            <div class="jAudio-thumb"></div>
            <div class="jAudio-progress-bar">
                <div class="jAudio-progress-bar-wrapper"><div class="jAudio-progress-bar-played"></div></div>
            </div>
            <div class="jAudio-status-bar">
                <div class="jAudio-details"></div>
                <div class="jAudio-time">
                    <span class="jAudio-time-elapsed">00:00</span><span class="pipe">/</span><span class="jAudio-time-total">00:00</span>
                </div>
            </div>
        </div>
        <!--{eval $totalpage = ceil($_G['forum_threadcount'] / $_G['tpp']); $prevpage = $page - 1; $nextpage = $page + 1; }-->
        <div class="jAudio-controls">
            <ul>
                <li><a href="{if $prevpage == 0}javascript:;{else}forum.php?mod=forumdisplay&fid={$_G[fid]}&page={$prevpage}{/if}" class="jAudio-control jAudio-btn jAudio-control-prevpg{if $prevpage == 0} grey{/if}"><i></i></a></li>
                <li><button class="jAudio-control jAudio-btn jAudio-control-prev" data-action="prev"><i></i></button></li>
                <li><button class="jAudio-control jAudio-control-play" data-action="play"><i></i></button></li>
                <li><button class="jAudio-control jAudio-btn jAudio-control-next" data-action="next"><i></i></button></li>
                <li><a href="{if $nextpage > $totalpage}javascript:;{else}forum.php?mod=forumdisplay&fid={$_G[fid]}&page={$nextpage}{/if}"class="jAudio-control jAudio-btn jAudio-control-nextpg{if $nextpage > $totalpage} grey{/if}"><i></i></a></li>
            </ul>
        </div>
    </div>
</div>

<script type="text/javascript">
    (function(){
        var music = {
            playlist: [
                <!--{loop $_G['forum_threadlist'] $key $thread}-->
                <!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}--><!--{eval continue;}--><!--{/if}-->
                <!--{if $thread['displayorder'] > 1}--><!--{else}-->
                <!--{if $thread['displayorder'] > 0 && !$displayorder_thread}--><!--{eval $displayorder_thread = 1;}--><!--{/if}-->
                <!--{if $thread['moved']}--><!--{eval $thread[tid]=$thread[closed];}--><!--{/if}-->
                <!--{eval $msgnumber = 40; $imgnumber = 1; $listplaying = 1; }-->                
                <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/musicplayer.php');}-->
                {
                    file: "{if $thread['readperm'] > 1}template/v2_mbl20121009/touch_plus/sound/music_auth.mp3{elseif $thread['price'] > 0 && $thread['special'] != '3'}template/v2_mbl20121009/touch_plus/sound/music_list.mp3{else}{$mediaplayer}{/if}",
                    thumb: "{if $imagethumb}{$imagethumb}{else}template/v2_mbl20121009/touch_plus/image/songcd.png{/if}",
                    trackName: "{if !$mediaplayer}null{else}{if $_G['optionvaluelist'][$thread['sortid']][$thread['tid']][songname][value]}{$_G['optionvaluelist'][$thread['sortid']][$thread['tid']][songname][value]}{else}{$thread[subject]}{/if}{/if}",
                    trackArtist: "{if !$mediaplayer}{$langplus[nomusicfiles]}{else}{if $thread['displayorder'] > 0}<i class='vt-top'></i>{/if}{if $thread[icon] >= 0}<em>{$_G[cache][stamps][$thread[icon]][text]}</em> - {else}{if $thread[heatlevel]}<em>{lang order_heats}</em> - {/if}{/if}{if $_G['optionvaluelist'][$thread['sortid']][$thread['tid']][songartist][value]}{$_G['optionvaluelist'][$thread['sortid']][$thread['tid']][songartist][value]}{else}{$thread[author]}{/if}{/if}",
                    trackComment: "forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra",
                    trackAlbum: "{if $mediaplayer}{if $_G['optionvaluelist'][$thread['sortid']][$thread['tid']][songalbum][value]} - {$_G['optionvaluelist'][$thread['sortid']][$thread['tid']][songalbum][value]}{else}{if $thread['msg']} - {$thread['msg']}{/if}{/if}{/if}",
                },
                <!--{/if}-->
                <!--{/loop}-->
            ]
        }
        $(".jAudio").jAudio(music);
    })();
</script>
<!--{else}-->
<div class="r-block">{lang forum_nothreads}</div>
<!--{/if}-->
<script type="text/javascript">
    $(document).on('click','.ajaxfav',function(){
        <!--{if !$_G[uid]}-->
        popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
        <!--{else}-->
        var obj = $(this);
        $.ajax({
            type:'POST',
            url:obj.attr('href') + '&handlekey=ajaxfav&inajax=1',
            data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
            dataType:'xml',
        })
            .success(function(s) {
                var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
                var favid = s.lastChild.firstChild.nodeValue.match(/'favid':'(.+?)'/i)[1];
                var oksmg = '{$langplus[favsuccess]}';
                if(smg.indexOf(oksmg) >= 0){
                    $('.forumfavbtn').addClass('ajaxdelfav forumcollected').removeClass('ajaxfav').html('{$langplus[favorite_in]}');
                    $('.forumfavbtn').attr('href', 'home.php?mod=spacecp&ac=favorite&op=delete&favid=' + favid + '&formhash={FORMHASH}');
                }else{
                    popup.open('<div class="tip"><dt>'+smg+'</dt></div>');
                    setTimeout(function(){
                        $(".dialogbox, #mask").fadeOut();
                    }, 1500);
                }
            })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
        <!--{/if}-->
        return false;
    });
    <!--{if $_G[uid]}-->
    $(document).on('click','.ajaxdelfav',function(){
        var obj = $(this);
        $.ajax({
            type:'POST',
            url:obj.attr('href') + '&handlekey=ajaxdelfav&inajax=1',
            data:{'deletesubmit':'true', 'formhash':'{FORMHASH}'},
            dataType:'xml',
        })
            .success(function(s) {
                var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
                var tid = s.lastChild.firstChild.nodeValue.match(/'id':'(.+?)'/i)[1];
                var oksmg = '{$langplus[oksuccess]}';
                if(smg.indexOf(oksmg) >= 0){
                    $('.forumfavbtn').addClass('ajaxfav').removeClass('ajaxdelfav forumcollected').html('{$langplus[favorite]}');
                    $('.forumfavbtn').attr('href', 'home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}');
                }else{
                    popup.open('<div class="tip"><dt>'+smg+'</dt></div>');
                    setTimeout(function(){
                        $(".dialogbox, #mask").fadeOut();
                    }, 1500);
                }
            })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
        return false;
    });
    <!--{/if}-->
</script>
<!--{block scrollplus}-->
<div class="scroll_plus"><!--{if !$subforumonly}--><a href="javascript:;" class="scroll_sort"></a><!--{/if}--><!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="scroll_notice"><i></i></a><!--{/if}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]"><i class="vt-post"></i></a></div>
<!--{/block}-->
<!--{eval $tplpages = 0; $multipage = 0; $nofooter = true;}-->