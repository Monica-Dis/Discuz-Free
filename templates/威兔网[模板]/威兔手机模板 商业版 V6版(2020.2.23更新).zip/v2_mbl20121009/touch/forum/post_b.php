<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $adveditor = $isfirstpost && $special || $special == 2 && ($_GET['action'] == 'newthread' || $_GET['action'] == 'reply' && !empty($_GET['addtrade']) || $_GET['action'] == 'edit' && $thread['special'] == 2);}-->
<!--{if $_GET['action'] == 'newthread'}-->
<div class="eKqfRvwAu5cE">
<div class="jqRecDJMSqQs">
<ul class="qhUm3fRMfQIL">
<!--{if !$_G['forum']['threadsorts']['required'] && !$_G['forum']['allowspecialonly']}--><li class="menu_slide{if $postspecialcheck[0]} a{/if}"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]">{lang send_threads}</a></li><!--{/if}-->
<!--{loop $_G['forum']['threadsorts'][types] $tsortid $name}-->
<li class="menu_slide{if $sortid == $tsortid} a{/if}"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&sortid=$tsortid"><!--{echo strip_tags($name);}--></a></li>
<!--{/loop}-->
<!--{if $_G['group']['allowpostpoll']}--><li class="menu_slide{if $postspecialcheck[1]} a{/if}"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=1">{lang post_newthreadpoll}</a></li><!--{/if}-->
<!--{if $_G['group']['allowpostreward']}--><li class="menu_slide{if $postspecialcheck[3]} a{/if}"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=3">{lang post_newthreadreward}</a></li><!--{/if}-->
<!--{if $_G['group']['allowpostdebate']}--><li class="menu_slide{if $postspecialcheck[5]} a{/if}"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=5">{lang post_newthreaddebate}</a></li><!--{/if}-->
<!--{if $_G['group']['allowpostactivity']}--><li class="menu_slide{if $postspecialcheck[4]} a{/if}"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=4">{lang post_newthreadactivity}</a></li><!--{/if}-->
<!--{if $_G['group']['allowposttrade']}--><li class="menu_slide{if $postspecialcheck[2]} a{/if}"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]&special=2">{lang post_newthreadtrade}</a></li><!--{/if}-->
<!--{if $_G['setting']['threadplugins']}-->
<!--{loop $_G['forum']['threadplugin'] $tpid}-->
<!--{if array_key_exists($tpid, $_G['setting']['threadplugins']) && @in_array($tpid, $_G['group']['allowthreadplugin'])}-->
<li class="menu_slide{if $specialextra == $tpid} a{/if}"><a href="forum.php?mod=post&action=newthread&fid={$_G[fid]}&specialextra=$tpid">{$_G[setting][threadplugins][$tpid][name]}</a></li>
<!--{/if}-->
<!--{/loop}-->
<!--{/if}-->
</ul>
</div>
</div>
<script src="./template/v2_mbl20121009/touch_plus/js/swiper.min.js?{VERHASH}"></script>
<script type="text/javascript">
	$(function() {
		if ($('.slidemenu .a').length > 0) {
			var slidefocus = $('.slidemenu .a').offset().left + $('.slidemenu .a').width() >= $(window).width() ? $('.slidemenu .a').index() : 0;
		} else {
			var slidefocus = 0;
		}
		var swiper = new Swiper('.menu_container', {
			wrapperClass:'menu_wrapper',
			slideClass:'menu_slide',
			slidesPerView:'auto',
			freeMode:true,
			freeModeFluid:true,
			momentumBounce:true,
			initialSlide:slidefocus,
		});
	})
</script>
<!--{/if}-->
<!--{if $showthreadsorts}-->
<!--{if $isfirstpost && $sortid}-->
	<script type="text/javascript">
		var forum_optionlist = '{if $forum_optionlist}$forum_optionlist{/if}';
		var select_option = "{lang please_select}";
	</script>
	<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/threadsort.js?{VERHASH}"></script>
<!--{/if}-->
<!--{/if}-->
<form method="post" name="postform" id="postform"
			{if $_GET[action] == 'newthread'}action="forum.php?mod=post&action={if $special != 2}newthread{else}newtrade{/if}&fid=$_G[fid]&extra=$extra&topicsubmit=yes&mobile=2"
			{elseif $_GET[action] == 'reply'}action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$extra&replysubmit=yes&mobile=2"
			{elseif $_GET[action] == 'edit'}action="forum.php?mod=post&action=edit&extra=$extra&editsubmit=yes&mobile=2" $enctype
			{/if}>
<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
<input type="hidden" name="posttime" id="posttime" value="{TIMESTAMP}" />
<!--{if !empty($_GET['modthreadkey'])}--><input type="hidden" name="modthreadkey" id="modthreadkey" value="$_GET['modthreadkey']" /><!--{/if}-->
<!--{if $_GET[action] == 'reply'}-->
	<input type="hidden" name="noticeauthor" value="$noticeauthor" />
	<input type="hidden" name="noticetrimstr" value="$noticetrimstr" />
	<input type="hidden" name="noticeauthormsg" value="$noticeauthormsg" />
	<!--{if $reppid}-->
		<input type="hidden" name="reppid" value="$reppid" />
	<!--{/if}-->
	<!--{if $_GET[reppost]}-->
		<input type="hidden" name="reppost" value="$_GET[reppost]" />
	<!--{elseif $_GET[repquote]}-->
		<input type="hidden" name="reppost" value="$_GET[repquote]" />
	<!--{/if}-->
<!--{/if}-->
<!--{if $_GET[action] == 'edit'}-->
	<input type="hidden" name="fid" id="fid" value="$_G[fid]" />
	<input type="hidden" name="tid" value="$_G[tid]" />
	<input type="hidden" name="pid" value="$pid" />
	<input type="hidden" name="page" value="$_GET[page]" />
<!--{/if}-->

<!--{if $special}-->
	<input type="hidden" name="special" value="$special" />
<!--{/if}-->
<!--{if $specialextra}-->
	<input type="hidden" name="specialextra" value="$specialextra" />
<!--{/if}-->
<input type="hidden" name="{if $_GET[action] == 'newthread'}topicsubmit{elseif $_GET[action] == 'reply'}replysubmit{elseif $_GET[action] == 'edit'}editsubmit{/if}" value="yes">
<!-- main postbox start -->
	<div class="z76GhPvFhhjY">
		<ul>			
			<!--{if $_GET['action'] != 'reply'}-->
            <li>
			<input type="text" tabindex="1" id="needsubject" size="30" autocomplete="off" value="$postinfo[subject]" name="subject" placeholder="{lang thread_subject}" fwin="login">
            </li>
			<!--{else}-->
			<!--{if empty($_GET['addtrade'])}-->
				<li{if $quotemessage} class="eeLyVgo9kFtu"{/if}>
                {lang join_thread}: $thread['subject']
				<!--{if $quotemessage}-->$quotemessage<!--{/if}-->
                </li>
			<!--{/if}-->
			<!--{/if}-->
			<!--{if $isfirstpost && !empty($_G['forum'][threadtypes][types])}-->
			<li>
				<div class="ifiKZQ0GkoOQ">
                <select id="typeid" name="typeid" >
					<option value="0" selected="selected">{lang select_thread_catgory}</option>
					<!--{loop $_G['forum'][threadtypes][types] $typeid $name}-->
					<!--{if empty($_G['forum']['threadtypes']['moderators'][$typeid]) || $_G['forum']['ismoderator']}-->
					<option value="$typeid"{if $thread['typeid'] == $typeid || $_GET['typeid'] == $typeid} selected="selected"{/if}><!--{echo strip_tags($name);}--></option>
					<!--{/if}-->
					<!--{/loop}-->
				</select>
                </div>
			</li>
			<!--{/if}-->
    <!--{if $showthreadsorts}-->
		<!--{if $sortid}-->
		    <input type="hidden" name="sortid" value="$sortid" />
	    <!--{/if}-->
    <!--{template forum/post_sortoption}-->    
    <!--{elseif $adveditor}-->    
        <!--{if $special == 1}--><!--{template forum/post_poll}-->
        <!--{elseif $special == 2 && ($_GET[action] != 'edit' || ($_GET[action] == 'edit' && ($thread['authorid'] == $_G['uid'] && $_G['group']['allowposttrade'] || $_G['group']['allowedittrade'])))}--><!--{template forum/post_trade}-->
        <!--{elseif $special == 3}--><!--{template forum/post_reward}-->
        <!--{elseif $special == 4}--><!--{template forum/post_activity}-->
        <!--{elseif $special == 5}--><!--{template forum/post_debate}-->
        <!--{elseif $specialextra}--><div>$threadplughtml</div>
        <!--{/if}-->       
    <!--{/if}-->
			<li>
			<textarea id="needmessage" tabindex="3" autocomplete="off" id="{$editorid}_textarea" name="$editor[textarea]" rows="10"  placeholder="{if ($_GET[action] == 'newthread' && $special == 2) || ($_GET[action] == 'reply' && !empty($_GET['addtrade']))}{$langplus[tradedes]}{else}{lang thread_content}{/if}" fwin="reply">$postinfo[message]</textarea>
			</li>
		</ul>
		<ul id="imglist" class="3Q32RgcKoVzu">
        <!--{if !empty($imgattachs['used'])}-->
        <!--{eval $imagelist = $imgattachs['used'];}-->
		<!--{if $imagelist}-->
        <!--{loop $imagelist $image}-->        
        <li>
        <span aid="{$image[aid]}" class="hOzJvUuAlrOq"><a href="javascript:;"></a></span>
        <span class="aoMwRN55Xgqm"><a href="javascript:;" onclick="insimg('{$image[aid]}');" ><p>{$langplus[clickinsert]}</p><img id="image_{$image[aid]}" src="{echo getforumimg({$image[aid]}, 1, 56, 56, 'fixnone')}" /></a></span>
        <input type="hidden" name="attachnew[{$image[aid]}][description]">
        </li>
        <!--{/loop}-->
        <!--{/if}-->
        <!--{/if}-->
		</ul>
        <ul id="attlist" class="tWw2az0J4Son">
        <!--{if !empty($attachs['used'])}-->
        <!--{eval $attachlist = $attachs['used'];}-->
        <!--{loop $attachlist $attach}-->        
        <li>
        <span aid="{$attach[aid]}" class="hOzJvUuAlrOq"><a href="javascript:;"></a></span>
        <div class="HQoUwDKilBpC"><div class="mGhbOUlt1QnT">$attach['filename']</div></div>
        <span class="aoMwRN55Xgqm"><a href="javascript:;" onclick="iattach('{$attach[aid]}');" ><p>{$langplus[clickinsert]}</p>$attach[filetype]</a></span>
        <input type="hidden" name="attachnew[{$attach[aid]}][description]">
        </li>
        <!--{/loop}-->
        <!--{/if}-->
		</ul>
		<!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
        <!--{subtemplate common/seccheck}-->
		<!--{/if}-->
    <div class="JFisFvnvOOmR">
		<table cellspacing="0" cellpadding="0">
        <tr>
        <td>
		<div class="6Ow6ulKMHLqn">
		<!--{if $allowpostimg}-->           
		<a href="javascript:;" class="LX2AwZRZ6AcH"{if $showthreadsorts || $special == 2 || $special == 4} id="post_filedata"{/if}><input type="file" name="Filedata{if $_G['group']['allowpostattach']}img{/if}" id="filedata{if $_G['group']['allowpostattach']}img{/if}" class="TC1sCZ9dbUDj" accept="image/*" multiple="multiple" /></a>
		<!--{/if}-->
        <!--{if $_G['group']['allowpostattach']}-->
        <a href="javascript:;" class="hj9v1cc35bQy"{if $showthreadsorts || $special == 2 || $special == 4} id="post_filedata"{/if}><input type="file" name="Filedata" id="filedata" class="TC1sCZ9dbUDj"/></a>
        <!--{/if}-->        
		<!--{if $_G['forum']['allowmediacode'] && $_G['group']['allowmediacode']}-->
		<a href="javascript:;" class="SSX1ug2nmElP"></a>             
		<!--{/if}-->
		<a href="javascript:;" class="{if $_G['group']['allowat'] > 0}cutoption{else}inlink{/if} editortab"></a>
        <!--{if $_G['forum']['allowsmilies']}-->
		<a href="javascript:;" class="8ZEzUDmgfRGH"></a>
        <!--{/if}--> 
		<i class="Ao9uNybpOXna">{$langplus[option]}</i>         
		</div>
        </td>
        <th><button id="postsubmit" class="ftbtn{if $_GET[action] == 'edit'} btnon" disable="false"{else} nopost" disable="true"{/if}><!--{if $_GET[action] == 'newthread'}--><!--{if $special == 2}-->{$langplus[trade]}<!--{else}-->{lang send_thread}<!--{/if}--><!--{elseif $_GET[action] == 'reply'}--><!--{if !empty($_GET['addtrade'])}-->{$langplus[addtrade]}<!--{else}-->{lang join_thread}<!--{/if}--><!--{elseif $_GET[action] == 'edit'}-->{lang edit_save}<!--{/if}--></button></th>
        </tr>
		</table>                       
		<div class="llLJ43IWYvyD">
        <!--{if $_G['forum']['allowmediacode'] && $_G['group']['allowmediacode']}-->            
		<div class="22QH8w7MKUZo">
		<!--{if !in_array($_G['fid'],(array)unserialize($tplfidsg))}-->
		<div class="3LAI9IVO8Vpr">
        <i class="Xqx8QKWTMDzJ"></i>
		<input type="text" name="video_link" id="video_link" autocomplete="off" placeholder="{$langplus[video_link]}" />
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_0())">{$langplus[insert]}</span>
		</div>
		<!--{/if}-->
        <!--{if !in_array($_G['fid'],(array)unserialize($tplfidsa))}-->
        <div class="3LAI9IVO8Vpr">
        <i class="vDgomcPCD8iZ"></i>
        <input type="text" id="musicsharing" autocomplete="off" placeholder="{$langplus[cloudmusic]}"> 
        <span class="upCRTDewMZEF" id="incloudmusic">{$langplus[insert]}</span>
        </div>
		<div class="3LAI9IVO8Vpr">
        <i class="DHkiB5Uji0vl"></i>
		<input type="text" name="music_link" id="music_link" autocomplete="off" placeholder="{$langplus[music_link]}" />
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_1())">{$langplus[insert]}</span>
		</div>
        <!--{/if}-->
        </div>
        <!--{/if}-->
		<div class="22QH8w7MKUZo">
		<div class="3LAI9IVO8Vpr">
        <i class="9EAJdkchBJVA"></i>
        <div class="oGYuEZ1uz6pO"><input type="text" name="links_link" id="links_link" autocomplete="off" placeholder="{$langplus[links_link]}" /></div>
        <div class="oGYuEZ1uz6pO"><input type="text" name="linkname_link" id="linkname_link" autocomplete="off" placeholder="{$langplus[linkname_link]}" /></div>
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_2())">{$langplus[insert]}</span>
		</div>
        <!--{if $_G['group']['allowat'] > 0}-->
		<div class="3LAI9IVO8Vpr">
        <i class="27IgHd5nBrvs"></i>
		<input type="text" name="iat_name" id="iat_name" autocomplete="off" placeholder="{$langplus[iat]}" />
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_3())">{$langplus[insert]}</span>
		</div>
        <!--{/if}-->
        </div>
        <!--{if $_G['forum']['allowsmilies']}-->
		<div id="smiliesdiv" class="22QH8w7MKUZo"><div id="fastsmilies"></div></div>
        <!--{/if}-->
		</div>        
    </div>
    <!--{template forum/post_editor_attribute}-->
	<!--{hook/post_bottom_mobile}-->
	</div>
    <!--{if $_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost) || ($_GET[action] == 'reply' && !empty($_GET['addtrade']))}-->
        <!--{if (($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))) || ($_G['group']['allowsetpublishdate'] && ($_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost && $thread['displayorder'] == -4))) || $showthreadsorts || $special == 2 || $special == 4}-->
		<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/rolldate.min.js?{VERHASH}"></script>
		<script type="text/javascript">
		var roll_title = "{$langplus[selectdate]}",
		roll_cancel = "{lang cancel}",
		roll_confirm = "{$langplus[confirm]}",
		roll_year = "{$langplus[years]}",
		roll_month = "{$langplus[month]}",
		roll_day = "{$langplus[day]}",
		roll_hour = "{$langplus[hour]}",
		roll_min = "{$langplus[min]}",
		roll_sec = "{$langplus[sec]}";
		<!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->	
		new rolldate.Date({
			el:'#rushreplyfrom',
			format:'YYYY-MM-DD hh:mm'			
		})
		new rolldate.Date({
			el:'#rushreplyto',
			format:'YYYY-MM-DD hh:mm'			
		})
		<!--{/if}-->
		<!--{if $_G['group']['allowsetpublishdate'] && ($_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost && $thread['displayorder'] == -4))}-->
		new rolldate.Date({
			el:'#cronpublishdate',
			format:'YYYY-MM-DD hh:mm',
			confirmEnd:function(el,date){
				var objtime = $('#cronpublishdate');
				if(objtime.val()) {
					$('#cronpublish').prop("checked",true);
				}
			}		
		})
		<!--{/if}-->
		<!--{if $special == 5}-->	
		new rolldate.Date({
			el:'#endtime',
			format:'YYYY-MM-DD hh:mm'
		})
		<!--{/if}-->
		<!--{if $special == 4}-->
		new rolldate.Date({
			el:'#starttimefrom_0',
			format:'YYYY-MM-DD hh:mm'			
		})		
		new rolldate.Date({
			el:'#starttimefrom_1',
			format:'YYYY-MM-DD hh:mm'			
		})
		new rolldate.Date({
			el:'#starttimeto',
			format:'YYYY-MM-DD hh:mm'			
		})
		new rolldate.Date({
			el:'#activityexpiration',
			format:'YYYY-MM-DD hh:mm'			
		})
		<!--{/if}-->
		<!--{if $special == 2}-->
		new rolldate.Date({
			el:'#item_expiration'			
		})	
		<!--{/if}-->
		<!--{if $_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2}-->
		$('#rewardfloor').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				$('#rushreply').prop("checked",true);
			}else{
				$('#rushreply').prop("checked",false);
			}
		});	
		<!--{/if}-->			
		</script>        
        <!--{/if}-->                    
    <!--{/if}-->
<!-- main postbox start -->
</form>
<script type="text/javascript">
	$(document).ready(function() {
	$('.editordefault a.editortab').click(function(){
		if($(this).hasClass('on')){
			$('.ftbox').removeClass('keyht');
		}else{
			$('.ftbox').addClass('keyht');
		}
		$('.editordefault a').eq($(this).index()).toggleClass('on').siblings().removeClass('on');
		$('.hidebox').eq($(".editordefault a.editortab").index(this)).slideToggle().siblings().slideUp();
	});			
	$('.editorplus a.editortab').click(function(){
		$('.editorplus a').eq($(this).index()).addClass('on').siblings().removeClass('on');
		$('.hidebox2').eq($(".editorplus a.editortab").index(this)).slideDown().siblings().slideUp();
	});		
	$('.moreoption').click(function(){
		$(this).toggleClass('onoption');
		$('.menufly').addClass('infly'); 
		$('body').addClass('menufly_open');               		
	}); 	
	$('.vt-close').click(function(){
		$('.moreoption').removeClass('onoption');	
		$('.menufly').removeClass('infly'); 
		$('body').removeClass('menufly_open');               		
	});
	});
	function ins_code_2(){
		var newvalue = $("#links_link").val();
		var newvalue2 = $("#linkname_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		newvalue2 = newvalue2.replace(/^\s+|\s+$/g,"");
		if(!newvalue2) {
			newvalue2 = newvalue;
		}
		if (newvalue) {
			$("#links_link").val("");
			$("#linkname_link").val("");
			editorclose();
			return "[url="+ newvalue +"]"+ newvalue2 +"[/url]";
		}else{
			return "";
		}
	}	
	<!--{if $_G['forum']['allowmediacode'] && $_G['group']['allowmediacode']}-->
	<!--{if !in_array($_G['fid'],(array)unserialize($tplfidsg))}-->
	function ins_code_0(){
		var newvalue = $("#video_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#video_link").val("");
			editorclose();
			return "[media]"+ newvalue +"[/media]";
		}else{
			return "";
		}
	}
	<!--{/if}-->
	function ins_code_1(){
		var newvalue = $("#music_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#music_link").val("");
			editorclose();				
			return "[audio]"+ newvalue +"[/audio]";				
		}else{
			return "";
		}
	}
	<!--{/if}-->
	<!--{if $_G['group']['allowat'] > 0}-->
	function ins_code_3(){
		var newvalue = $("#iat_name").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#iat_name").val("");
			editorclose();
			return "@"+ newvalue +" ";
		}else{
			return "";
		}
	}
	<!--{/if}-->
	$(function(){
		$('#incloudmusic').click(function(){
			var songsrc = $('#musicsharing').val();
			var nomsg = '{$langplus[nocloudmusic]}';
			$.ajax({
				type: "post",
				url: "template/v2_mbl20121009/touch/mytpl/musiccloud.php?do=music&hash={FORMHASH}",
				data: {songsrc:songsrc},
				dataType: "json",
				success: function(msg){
					var data = '';
					if(msg != ''){
						data = eval("("+msg+")");
						$('#typeoption_songartist').val(data.artistsname);
						$('#typeoption_songname, #needsubject').val(data.songsname);
						$('#typeoption_songalbum').val(data.albumname);
						$('#typeoption_songeximg').val(data.picurl);
						$('#needmessage').val('[audio]' + data.songapi + '[/audio]\n'+ data.lyricinfo);
						$('#musicsharing').val('');
						editorclose();
					}else{
						popup.open('<div class="57wo6jJ46Z4Q"><dt>'+nomsg+'</dt></div>');
						$('#musicsharing').val('');
                    }
				},
				error:function(msg){
					popup.open('<div class="57wo6jJ46Z4Q"><dt>'+nomsg+'</dt></div>');
					$('#musicsharing').val('');
				}
			});
		});
	});
	function editorclose(){
		$('.editordefault a').removeClass('on');
		$('.hidebox').slideUp();
		$('.ftbox').removeClass('keyht');
	}
</script>

<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<!--{if $_G['forum']['allowsmilies']}-->
<script type="text/javascript" src="data/cache/common_smilies_var.js?{VERHASH}"></script>
<!--{/if}-->
<script type="text/javascript">
function ilink(lk){$("#needmessage").insertAtCaret(lk);}
function ismi(sl){$("#needmessage").insertAtCaret(sl);}
<!--{if $_G['forum']['allowsmilies']}-->
var j = 1, smilies_fastdata = '', img;
if (smilies_array[{$smileid}][{$smilepg}].length > {$smilenumber}){smilienums = {$smilenumber};}else{smilienums = smilies_array[{$smileid}][{$smilepg}].length;}
for (i = 0; i < smilienums; i++) {	
	s = smilies_array[{$smileid}][{$smilepg}][i];	
    smilieimg = "static/" + 'image/smiley/' + smilies_type['_' + {$smileid}][1] + '/' + s[2];
    smilies_fastdata += s ? '<li><img src="' + smilieimg + '" onclick="ismi(\'' + s[1].replace(/'/, '\\\'') + '\')" />' : '</li>';
}
window.onload = function() {
    $('#fastsmilies').html('<div class="saMZOV8357GQ"><ul>' + smilies_fastdata + '</ul></div>');
}
<!--{/if}-->
</script>

<script type="text/javascript">
	(function() {		
		<!--{if $secqaacheck || $seccodecheck}-->
		var needsubject = needmessage = sectxt = false;
		<!--{else}-->
		var needsubject = needmessage = false;
		<!--{/if}-->

		<!--{if $_GET[action] == 'reply'}-->
			needsubject = true;
		<!--{elseif $_GET[action] == 'edit'}-->
			needsubject = needmessage = true;
		<!--{/if}-->

		<!--{if $_GET[action] == 'newthread' || ($_GET[action] == 'edit' && $isfirstpost)}-->
		$('#needsubject').on('keyup input focus', function() {
			var obj = $(this);
			if(obj.val()) {
				needsubject = true;
				<!--{if ($secqaacheck || $seccodecheck) && $_GET[action] != 'edit'}-->
				if(needmessage == true && sectxt == true) {
				<!--{else}-->
				if(needmessage == true) {
				<!--{/if}-->
					$('#postsubmit').removeClass('nopost').addClass('btnon');
					$('#postsubmit').attr('disable', 'false');
				}
			} else {
				needsubject = false;
				$('#postsubmit').removeClass('btnon').addClass('nopost');
				$('#postsubmit').attr('disable', 'true');
			}
		});
		<!--{/if}-->
		$('#needmessage').on('keyup input focus', function() {
			var obj = $(this);
			if(obj.val()) {
				needmessage = true;				
				<!--{if ($secqaacheck || $seccodecheck) && $_GET[action] != 'edit'}-->
				if(needsubject == true && sectxt == true) {
				<!--{else}-->
				if(needsubject == true) {
				<!--{/if}-->
					$('#postsubmit').removeClass('nopost').addClass('btnon');
					$('#postsubmit').attr('disable', 'false');
				}
			} else {
				needmessage = false;
				$('#postsubmit').removeClass('btnon').addClass('nopost');
				$('#postsubmit').attr('disable', 'true');
			}
		});		
		<!--{if ($secqaacheck || $seccodecheck) && $_GET[action] != 'edit'}-->
		$('.sectxt').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				sectxt = true;	
				if(needmessage == true && needsubject == true) {
					$('#postsubmit').removeClass('nopost').addClass('btnon');
					$('#postsubmit').attr('disable', 'false');			
				}
			} else {
				sectxt = false;
				$('#postsubmit').removeClass('btnon').addClass('nopost');
				$('#postsubmit').attr('disable', 'true');		
			}
		});	
		<!--{/if}-->		
		$('#needmessage').on('input focus', function(){
			$(this).css('height','auto');
			$(this).css('height',this.scrollHeight + 2); 
		});			
	 })();
</script>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/ajaxfileupload.js?{VERHASH}"></script>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/buildfileupload.js?{VERHASH}"></script>
<script type="text/javascript">
	var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png, bmp' : imgexts;
	<!--{if $_G['group']['allowpostattach'] && $_G['group']['attachextensions']}-->
	<!--{eval $extnames = explode(',',str_replace(' ','',$_G['group']['attachextensions']));}-->	
	<!--{eval $extdiff = array('jpg','jpeg','gif','png','bmp');}-->	
	<!--{eval $extnames = array_diff($extnames,$extdiff);}-->	
	<!--{eval $extnames = "'".implode("','",$extnames)."'";}-->	
	var allextname = [{$extnames}];
	<!--{else}-->
	var allextname = '';
	<!--{/if}-->
	var STATUSMSG = {
		'-1' : '{lang uploadstatusmsgnag1}',
		'0' : '{lang uploadstatusmsg0}',
		'1' : '{lang uploadstatusmsg1}',
		'2' : '{lang uploadstatusmsg2}',
		'3' : '{lang uploadstatusmsg3}',
		'4' : '{lang uploadstatusmsg4}',
		'5' : '{lang uploadstatusmsg5}',
		'6' : '{lang uploadstatusmsg6}',
		'7' : '{lang uploadstatusmsg9}',
		'8' : '{lang uploadstatusmsg8}',
		'9' : '{lang uploadstatusmsg9}',
		'10' : '{lang uploadstatusmsg10}',
		'11' : '{lang uploadstatusmsg11}'
	};
	var form = $('#postform');
	$(document).on('change', '{if $showthreadsorts || $special == 2 || $special == 4}#post_filedata {/if}.allfiledata', function() {
			popup.open('<div class="lmVdjV39q3EP"></div>');
			uploadsuccess = function(data) {
				if(data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
				var dataarr = data.split('|');
				if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {					
					popup.close();
					$('#imglist').append('<li><span aid="'+dataarr[3]+'" class="hOzJvUuAlrOq"><a href="javascript:;"></a></span><span class="aoMwRN55Xgqm"><a href="javascript:;" onclick="insimg(\''+dataarr[3]+'\');" ><p>{$langplus[clickinsert]}</p><img id="aimg_'+dataarr[3]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
				} else {
					var sizelimit = '';
					if(dataarr[7] == 'ban') {
						sizelimit = '{lang uploadpicatttypeban}';
					} else if(dataarr[7] == 'perday') {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
					} else if(dataarr[7] > 0) {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
					}
					popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
				}
			};			
			<!--{if $_G['group']['allowpostattach']}-->
			uploadsuccessatt = function(data) {
				if(data == '') {
					popup.open('{lang uploadpicfailed}', 'alert');
				}
				var dataarr = data.split('|');
				if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
					var filetype = dataarr[6].substring(dataarr[6].lastIndexOf('.')+1,dataarr[6].length).toLowerCase();//��׺��					
					var extarray1 = ['zip','rar','7z','arj','arc','cab','lzh','lha','tar','gz'];
					var extarray2 = ['mp4','mp3','wav','wma','ape','flac','3gp','wmv','avi','mkv','mid','m3u','asf','asx','vqf','mpg','mpeg','mov'];
					var extarray3 = ['htm','html','php','js','pl','cgi','asp','py','pyc','css'];
					var extarray4 = ['exe','com','bat','dll'];
					var extarray5 = ['doc','docx','xls','xlsx','ppt','pptx'];
					var extarray6 = ['txt','rtf','wri','chm'];
					var extarray7 = ['ra','rm','rv','rmvb'];
					var extarray8 = ['swf','fla','flv','swi'];
					var extarray9 = ['ai','psd','tif','eps'];					
					if(filetype == 'pdf'){
						imgname = 'pdf.gif';
					}else if(filetype == 'torrent'){
						imgname = 'torrent.gif';
					}else if($.inArray(filetype, extarray1) >= 0){
						imgname = 'zip.gif';
					}else if($.inArray(filetype, extarray2) >= 0){
						imgname = 'av.gif';					
					}else if($.inArray(filetype, extarray3) >= 0){						
						imgname = 'html.gif';
					}else if($.inArray(filetype, extarray4) >= 0){						
						imgname = 'binary.gif';
					}else if($.inArray(filetype, extarray5) >= 0){						
						imgname = 'msoffice.gif';
					}else if($.inArray(filetype, extarray6) >= 0){
						imgname = 'text.gif';
					}else if($.inArray(filetype, extarray7) >= 0){						
						imgname = 'real.gif';
					}else if($.inArray(filetype, extarray8) >= 0){						
						imgname = 'flash.gif';
					}else if($.inArray(filetype, extarray9) >= 0){						
						imgname = 'image.gif';
					}else{
						imgname = 'unknown.gif';
					}
					popup.close();
					$('#attlist').append('<li><span aid="'+dataarr[3]+'" class="hOzJvUuAlrOq"><a href="javascript:;"></a></span><div class="HQoUwDKilBpC"><div class="mGhbOUlt1QnT">'+dataarr[6]+'</div></div><span class="aoMwRN55Xgqm"><a href="javascript:;" onclick="iattach('+dataarr[3]+');" ><p>{$langplus[clickinsert]}</p><img id="aimg_'+dataarr[3]+'" src="{STATICURL}image/filetype/'+imgname+'" /></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
				} else {
					var sizelimit = '';
					if(dataarr[7] == 'ban') {
						sizelimit = '{lang uploadpicatttypeban}';
					} else if(dataarr[7] == 'perday') {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
					} else if(dataarr[7] > 0) {
						sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
					}
					popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
				}
			};
			<!--{/if}-->

			if(typeof FileReader != 'undefined' && this.files[0]) {//note ֧��html5�ϴ�������				
			<!--{if $_G['group']['allowpostattach']}-->
				var fileextname = 'undefined';
				var extdiff = ['jpg','jpeg','gif','png','bmp'];				
				if(fileextname == 'undefined'){
					var filename = this.files[0].name;					
					var fileextname = filename.substring(filename.lastIndexOf(".")+1,filename.length).toLowerCase();//��׺��
				}				
				if($.inArray(fileextname, {if $_G['group']['attachextensions']}allextname{else}[fileextname]{/if}) >= 0 && $.inArray(fileextname, extdiff) < 0){					
					$.ajaxfileupload({
						url:'misc.php?mod=swfupload&operation=upload&inajax=yes&infloat=yes&simple=2',
						data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
						dataType:'text',
						fileElementId:'filedata',
						success:uploadsuccessatt,
						error: function() {
							popup.open('{lang uploadpicfailed}', 'alert');
						}
					});
				}else if($.inArray(fileextname, allextname) < 0 && $.inArray(fileextname, extdiff) < 0){					
					popup.open('{lang uploadstatusmsg4}', 'alert');
				}else{
				<!--{/if}-->
				<!--{if $upimgnumber}-->
				if(this.files.length < {$upimgnumber}) { var imgnumber = this.files.length; } else { var imgnumber = {$upimgnumber}; }
				<!--{/if}-->
				for(var i=0;i<{if $upimgnumber}imgnumber{else}this.files.length{/if};i++ ){
					var file_data = [];
					file_data.push(this.files[i]);
					$.buildfileupload({
						uploadurl:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
						files:file_data,
						uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
						uploadinputname:'Filedata',
						maxfilesize:"$swfconfig[max]",
						success:uploadsuccess,
						error:function() {
							popup.open('{lang uploadpicfailed}', 'alert');
						}
					});
				}
				<!--{if $_G['group']['allowpostattach']}-->
				}
				<!--{/if}-->
			} else {

				$.ajaxfileupload({
					url:'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
					data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
					dataType:'text',
					fileElementId:'filedata',
					success:uploadsuccess,
					error: function() {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
				});

			}
	});

	<!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
	geo.getcurrentposition();
	<!--{/if}-->
	$('#postsubmit').on('click', function() {
		var obj = $(this);
		if(obj.attr('disable') == 'true') {
			return false;
		}

		obj.attr('disable', 'true').removeClass('btnon').addClass('nopost');
		popup.open('<div class="lmVdjV39q3EP"></div>');
		<!--{if $showthreadsorts}-->
		if(validateextra()==false){popup.open('{$langplus[innot]}', 'alert'); return false;} 
		<!--{/if}-->

		var postlocation = '';
		if(geo.errmsg === '' && geo.loc) {
			postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
		}

		$.ajax({
			type:'POST',
			url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});

	$(document).on('click', '.imgdel', function() {
		var obj = $(this);
		$.ajax({
			type:'GET',			
			url:'forum.php?mod=ajax&action=deleteattach&pid=$postinfo[pid]&inajax=yes&aids[]=' + obj.attr('aid'),
		})
		.success(function(s) {
			obj.parent().remove();
		})
		.error(function() {
			popup.open('{lang networkerror}', 'alert');
		});
		return false;
	});	
	
function insimg(aid) { 
	var txt = '[attachimg]' + aid + '[/attachimg]';	
	$("#needmessage").insertAtCaret(txt);
}

function iattach(aid) { 
	var txt = '[attach]' + aid + '[/attach]';	
	$("#needmessage").insertAtCaret(txt);
}
</script>