<?php exit('QQ:32-77558-32');?>
<!--{if $brtnav == 1 && !$noheader && $page > 1}-->
<div class="3jFBf3583NdA">
    <!--{if $_G['forum']['status'] == 3}-->
    <a href="forum.php?forumlist=1">{$langplus[bbs]}</a>$navigation
    <!--{else}-->
    <a href="forum.php?forumlist=1">{$langplus[bbs]}</a><!--{if $_G['forum']['type'] == 'forum'}--><span>&gt;</span><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">$_G['forum']['name']</a><!--{else}--><span>&gt;</span><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fup']}">$_G['cache']['forums'][$fup]['name']</a><span>&gt;</span><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">{$_G['forum']['name']}</a><!--{/if}-->
    <!--{/if}-->
</div>
<!--{/if}-->
<!--{if $_G[forum_thread][special] != 3 && $_G[forum_thread][special] != 2}-->
<div class="thname{if $viewtitletype == 1} vatitle{/if}" id="myshares">
                    <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
                        <!--{if !IS_ROBOT && ($_G['forum']['threadtypes']['listable'] || $_G['forum']['status'] == 3)}-->
                            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$_G[forum_thread][typeid]">[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]</a>
                        <!--{else}-->
                            [{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]
                        <!--{/if}-->
                    <!--{/if}-->
                    <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
                        <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_G[forum_thread][sortid]">[{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]</a>
                    <!--{/if}-->
<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]">$_G[forum_thread][subject]</a>
</div>
<!--{/if}-->
<!-- main postlist start -->
<div id="alist" class="4v0jQhvk8v6y">
    <!--{eval $postcount = 0;}-->
    <!--{loop $postlist $post}-->
    <!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
    <!--{hook/viewthread_posttop_mobile $postcount}-->
    <div class="plc{if $post['first']} bbno{/if}" id="pid$post[pid]">
        <!--{if $post['first'] &&  $_G['forum_threadstamp']}-->
        <div class="L95v5eTzBQrt"><img src="{STATICURL}image/stamp/$_G[forum_threadstamp][url]" title="$_G[forum_threadstamp][text]" /></div>
        <!--{/if}-->
        <!--{if $post['warned']}--><i class="En9NOwDz6lbw">{lang warn_get}</i><!--{/if}-->
        <div class="display pi{if $viewheight}{if $post['first']} viewheight{/if}{/if}">
            <!--{if ($_G[forum_thread][special] == 3 || $_G[forum_thread][special] == 2) && $post['first']}--><!--{else}-->
          
            <!--{/if}-->
            <!--{if !$post['first'] && $viewposttype == 1}--><div class="D9pSE4VVIaOP"><!--{/if}-->
            <!--{hook/viewthread_posttop_v2_mobile $postcount}-->
            <!--{if $post['first']}-->
            <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
            <!--{if $adviewthreada && in_array($_G['fid'],(array)unserialize($adviewthreadida))}--><!--{$adviewthreada}--><!--{/if}-->
            <!--{if $adviewthreadb && in_array($_G['fid'],(array)unserialize($adviewthreadidb))}--><!--{$adviewthreadb}--><!--{/if}-->
            <!--{if $adviewthreadc && in_array($_G['fid'],(array)unserialize($adviewthreadidc))}--><!--{$adviewthreadc}--><!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
            <div class="SPbweYmSeqN3">
                <!--{if $rushreply && $post['first']}-->
                <div class="YCCoVtTel0pB">
                    <div class="rushreply_titls{if !$rushresult['timer']} rushreply_over{/if} mbm">
                        <!--{if $rushresult['timer']}-->{lang rushreply}{lang rewarding}<!--{else}-->{lang rushreply}{lang over}<!--{/if}-->
                        <!--{if !$_GET['checkrush']}-->
                        <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1">{lang rushreply_view}</a>
                        <!--{/if}-->
                    </div>
                    <!--{if $rushresult['timertype'] == 'end' || !$rushresult['timer']}-->
                    <!--{if $rushresult[stopfloor]}-->
                    <p>{$langplus[rushreplyend]} : {$rushresult[stopfloor]}</p>
                    <!--{/if}-->
                    <!--{if $rushresult[rewardfloor]}-->
                    <!--{eval $rushresult[rewardfloor] = str_replace(',',', ',$rushresult[rewardfloor])}-->
                    <p>{lang thread_rushreply_floor} : {$rushresult[rewardfloor]}</p>
                    <!--{/if}-->
                    <!--{if $rushresult[creditlimit]}-->
                    <p>{$langplus[rushreplylimit]} : {$rushresult[creditlimit_title]}{$langplus[greaterthan]} {$rushresult[creditlimit]} {$langplus[participate]}{lang rushreply}{lang activity}</p>
                    <!--{/if}-->
                    <!--{else}-->
                    <p>{lang rushreply}{lang header_start}{lang time} {$rushresult[starttimefrom]}</p>
                    <!--{/if}-->
                </div>
                <!--{/if}-->

                <!--{if $_G['forum_thread']['replycredit'] > 0 }-->
                <div class="YCCoVtTel0pB">
                    <div class="M6F4SPbdqYQ0">{lang thread_replycredit_tips1} {lang thread_replycredit_tips2}</div>
                    <p>{$langplus[replycredit_rate]} <!--{if $_G['forum_thread']['replycredit_rule'][random] > 0}-->{$_G[forum_thread][replycredit_rule][random]}<!--{else}-->100<!--{/if}-->%</p>
                </div>
                <!--{/if}-->

                <!--{if !$post['first'] && !empty($post[subject])}-->
                <h3 class="AO9ji9SODWNM">$post[subject]</h3>
                <!--{/if}-->
                <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                <div class="1sx8EmhEmp3G">{lang message_banned}</div>
                <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                <div class="1sx8EmhEmp3G">{lang message_single_banned}</div>
                <!--{elseif $needhiddenreply}-->
                <div class="1sx8EmhEmp3G">{lang message_ishidden_hiddenreplies}</div>
                <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
                <!--{template forum/viewthread_pay}-->
                <!--{elseif $_G['forum_discuzcode']['passwordlock'][$post[pid]]}-->
                <div class="HC0uLEGjv84e">{$langplus[message_password]} <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&mobile=no">{lang nomobiletype}</a></div>
                <!--{else}-->

                <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                <div class="1sx8EmhEmp3G">{lang admin_message_banned}</div>
                <!--{elseif $post['status'] & 1}-->
                <div class="1sx8EmhEmp3G">{lang admin_message_single_banned}</div>
                <!--{/if}-->
                <!--{if $post['first']}-->
                <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                <div class="HC0uLEGjv84e"><em class="9ECtWVPiFM1j"><a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" class="KAJ0RQtE7zdl" >{lang pay_view}</a></em>{lang pay_threads}: <strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong></div>
                <!--{/if}-->
                <!--{/if}-->

                <!--{if $post['first'] && $threadsort && $threadsortshow}-->
                <!--{if $threadsortshow['typetemplate']}-->
                $threadsortshow[typetemplate]
                <!--{elseif $threadsortshow['optionlist'] && !($post['status'] & 1) && !$_G['forum_threadpay']}-->
                <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                <div class="HC0uLEGjv84e">{lang has_expired}</div>
                <!--{else}-->
                <div class="DBKRIb4TpLH0">
                    <h4>$_G[forum][threadsorts][types][$_G[forum_thread][sortid]]</h4>
                    <!--{loop $threadsortshow['optionlist'] $option}-->
                    <!--{if $option['type'] != 'info'}-->
                    $option[title]: <!--{if $option['value']}-->$option[value] $option[unit]<!--{else}--><span class="2bH7U5MuyzRf">--</span><!--{/if}--><br />
                    <!--{/if}-->
                    <!--{/loop}-->
                </div>
                <!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->

                <!--{if $post['first']}-->
                <!--{if !$_G[forum_thread][special]}-->
                $post[message]
                <!--{elseif $_G[forum_thread][special] == 1}-->
                <!--{template forum/viewthread_poll}-->
                <!--{elseif $_G[forum_thread][special] == 2}-->
                <!--{template forum/viewthread_trade}-->
                <!--{elseif $_G[forum_thread][special] == 3}-->
                <!--{template forum/viewthread_reward}-->
                <!--{elseif $_G[forum_thread][special] == 4}-->
                <!--{template forum/viewthread_activity}-->
                <!--{elseif $_G[forum_thread][special] == 5}-->
                <!--{template forum/viewthread_debate}-->
                <!--{elseif $threadplughtml}-->
                $threadplughtml
                $post[message]
                <!--{else}-->
                $post[message]
                <!--{/if}-->
                <!--{else}-->
                $post[message]
                <!--{/if}-->
                <!--{/if}-->
            </div>
            <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
            <!--{if $post['attachment']}-->
            <div class="p3wc0mMF4ZMp">
                {lang attachment}: <em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
            </div>
            <!--{elseif $post['imagelist'] || $post['attachlist']}-->
            <div class="tT0H1L8rbgW1">
                <!--{if $post['imagelist']}-->
                <!--{if count($post['imagelist']) == 1}-->
                {echo showattach($post, 1)}
                <!--{else}-->
                {echo showattach($post, 1)}
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $post['attachlist']}-->
                {echo showattach($post)}
                <!--{/if}-->
            </div>
            <!--{/if}-->
            <!--{/if}-->
            
            <!--{if $post['first'] && ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
            <div class="8FYL4TT1GWKf">
                <!--{if $post[tags]}-->
                <!--{eval $tagi = 0;}-->
                <!--{loop $post[tags] $var}-->
                <!--{if $tagi}--> , <!--{/if}--><a href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
                <!--{eval $tagi++;}-->
                <!--{/loop}-->
                <!--{/if}-->
            </div>
            <!--{/if}-->
			

            <!--{if $_GET['from'] != 'preview' && $_G['setting']['commentnumber'] && !empty($comments[$post[pid]])}-->
            <div class="xziFc8uDue5R">
                <div class="IqXFzBIrD5QN">{$langplus[webcomments]}</div>
                <ul>
                    <!--{eval $c = 1;}-->
                    <!--{loop $comments[$post[pid]] $comment}-->
                    <!--{if $c < 6}-->
                    <li>
                        <a href="home.php?mod=space&uid=$comment[authorid]&do=profile" class="2tRIxdxFgXQj">$comment[avatar]</a>
                        <div class="iiMziP90CXTA">
                            <p>
                                <!--{if $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
                                <a href="forum.php?mod=topicadmin&action=delcomment&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$comment[id]}" class="V1fOL5X8HmGb"><i class="cDXiOoUbMr9R"></i></a>
                                <!--{/if}-->
                                <em><!--{date($comment[dateline], 'u')}--></em>
                                <!--{if $comment['authorid']}-->
                                <span><a href="home.php?mod=space&uid=$comment[authorid]&do=profile" >$comment[author]</a></span>
                                <!--{else}-->
                                <span>{lang guest}</span>
                                <!--{/if}-->
                            </p>
                            <div class="W8GD9lYXLNDd">{$comment[comment]}</div>
                        </div>
                    </li>
                    <!--{/if}-->
                    <!--{eval $c++;}-->
                    <!--{/loop}-->
                </ul>
            </div>
            <!--{/if}-->

            <!--{hook/viewthread_postbottom_v2_mobile $postcount}-->
            <!--{hook/viewthread_postbottom_mobile $postcount}-->

            <!--{if $post[first] && $signaturetype == 1}-->
            <!--{if $post['signature'] && ($_G['setting']['bannedmessages'] & 4 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)))}-->
            <div class="rqCAkr91DvTA"><span class="OzbReorU7hlN">{$langplus[signature]}</span>{lang member_signature_banned}</div>
            <!--{elseif $post['signature'] && !$post['anonymous'] && $showsignatures}-->
            <div class="rqCAkr91DvTA"><span class="OzbReorU7hlN">{$langplus[signature]}</span>$post[signature]</div>
            <!--{elseif !$post['anonymous'] && $showsignatures && $_G['setting']['globalsightml']}-->
            <div class="rqCAkr91DvTA"><span class="OzbReorU7hlN">{$langplus[signature]}</span>$_G['setting']['globalsightml']</div>
            <!--{/if}-->
            <!--{elseif $signaturetype == 2}-->
            <!--{if $post['signature'] && ($_G['setting']['bannedmessages'] & 4 && ($post['memberstatus'] == '-1' || ($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || ($post['status'] & 1)))}-->
            <div class="rqCAkr91DvTA"><span class="OzbReorU7hlN">{$langplus[signature]}</span>{lang member_signature_banned}</div>
            <!--{elseif $post['signature'] && !$post['anonymous'] && $showsignatures}-->
            <div class="rqCAkr91DvTA"><span class="OzbReorU7hlN">{$langplus[signature]}</span>$post[signature]</div>
            <!--{elseif !$post['anonymous'] && $showsignatures && $_G['setting']['globalsightml']}-->
            <div class="rqCAkr91DvTA"><span class="OzbReorU7hlN">{$langplus[signature]}</span>$_G['setting']['globalsightml']</div>
            <!--{/if}-->
            <!--{/if}-->
            <!--{if !$post['first'] && $viewposttype == 1}--></div><!--{/if}-->
            <!--{if $viewheight}--><!--{if $post['first']}--><div class="q8QawBUI3VnI"><a href="javascript:;" >{$langplus[startreading]}</a></div><!--{/if}--><!--{/if}-->

        </div>
        <div class="viewpost{if !$post['first'] && $viewposttype == 1} posttype{if $menusposit == 1} posttype_viewpost{/if}{/if}">
            <!--{if $_G['forum']['ismoderator']}--><a href="#moption_$post[pid]" class="tbY8KNzlTLsS"><i class="HcolmMJk7SfI"></i></a><!--{/if}-->
            <!--{if $post['invisible'] == 0}-->
            <!--{if $_G[uid]}-->
            <!--{if ($_G['group']['raterange'] && $post['authorid']) || ($allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])) || ((($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])) || ($post['authorid'] != $_G['uid'])}--><a href="javascript:;" class="mOreOxJWFJRG"><i class="scQU2fA45jZB"></i></a><!--{/if}-->
            <!--{/if}-->
            <!--{if $post['first']}-->
            <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&page=$page" ><i class="miaj0UIzHsXG"></i></a>
            <!--{else}-->
            <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&page=$page" ><i class="miaj0UIzHsXG"></i></a>
            <!--{/if}-->
            <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
            <a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]&infloat=yes" class="KAJ0RQtE7zdl"><i class="RebeNFMwGbea"></i></a>
            <!--{/if}-->
            <!--{if $supportposit == 0 && (!$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote']))}-->
            <!--{if $post[postreview][support] > 9999 }-->
            <!--{eval $post[postreview][support] = round($post[postreview][support] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <span class="cEDhr4pgFIap"{if !$post[postreview][support]} style="display:none;"{/if}>{$post[postreview][support]}</span>
            <a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" class="15q39wX0zp8e"><i class="ko75396JO0ex"></i></a>
            <!--{/if}-->
            <!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
            <a href="forum.php?mod=misc&action=bestanswer&tid=$_G[tid]&pid=$post['pid']&from=$_GET[from]&bestanswersubmit=yes" class="ZaZI8ZypdrAO">{$langplus[setbestanswer]}</a>
            <!--{/if}-->
            <!--{if !$post[first] && $_G['forum_thread']['special'] == 5}-->
            <!--{if $post[stand] == 1}-->
            <a href="javascript:;" class="rewardset stand_{$post[stand]}" >{lang debate_square}</a>
            <!--{elseif $post[stand] == 2}-->
            <a href="javascript:;" class="rewardset stand_{$post[stand]}" >{lang debate_opponent}</a>
            <!--{else}-->
            <a href="javascript:;" class="lSrtZbGctZ51" >{lang debate_neutral}</a>
            <!--{/if}-->
            <!--{if $supportposit == 0 && $post[stand]}-->
            <span class="cEDhr4pgFIap"{if !$post[voters]} style="display:none;"{/if}>{$post[voters]}</span>
            <a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]" class="15q39wX0zp8e"><i class="ko75396JO0ex"></i></a>
            <!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $post['first']}-->
            <!--{if $_G[forum_thread][views] > 9999 }-->
            <!--{eval $_G[forum_thread][views] = round($_G[forum_thread][views] / 10000 , 1).$langplus[tenthousand];}-->
            <!--{/if}-->
            <!--{if $_G[forum_thread][views]}--><span class="679fM3ruaYbU">$_G[forum_thread][views]{$langplus[view]}</span><!--{/if}-->
            <!--{/if}-->
        </div>
        <!--{if $post['invisible'] == 0}-->
        <!--{if $_G[uid]}-->
        <!--{if ($_G['group']['raterange'] && $post['authorid']) || ($allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])) || ((($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])) || ($post['authorid'] != $_G['uid'])}-->
        <div id="menups_$post[pid]" class="menups{if !$post['first'] && $viewposttype == 1 && $menusposit == 1} posttype_menups{/if}" style="display:none;">
            <ul>
                <!--{if $post['authorid'] != $_G['uid']}-->
                <li><a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" class="KAJ0RQtE7zdl"><i class="6LsrFlSj30t1"></i>{lang report}</a></li>
                <!--{/if}-->
                <!--{if $allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])}-->
                <li><a class="KAJ0RQtE7zdl" href="forum.php?mod=misc&action=comment&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page{if $_G['forum_thread']['special'] == 127}&special=$specialextra{/if}"><i class="uUsFeZvV60tK"></i>{lang comments}</a></li>
                <!--{/if}-->                
                <!--{if $_G['group']['raterange'] && $post['authorid']}-->
                <li><a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]{if $ratetype == 1 || $ratetype == 2}&reward=1{/if}" class="KAJ0RQtE7zdl"><i class="{if $ratetype == 1 || $ratetype == 2}vt-goldcoin{else}vt-rate{/if}"></i><!--{if $ratetype == 1 || $ratetype == 2}-->{$langplus[viewsreward]}<!--{else}-->{lang rate}<!--{/if}--></a></li>
                <!--{/if}-->
                <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && ($_G['forum_thread']['special'] != 2 || $_G['forum_thread']['special'] != 4 || !$post['first'])}-->
                <li><a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if $_G[forum_thread][sortid]}{if $post[first]}&sortid={$_G[forum_thread][sortid]}{/if}{/if}{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"><i class="4iPL2IBpm7EF"></i>{lang edit}</a></li>
                <!--{/if}-->
            </ul>
        </div>
        <!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
        <!--{if $_G['forum']['ismoderator']}-->
        <!-- manage start -->
        <!--{if $post[first]}-->
        <div id="moption_$post[pid]" popup="true" style="display:none;">
            <ul class="tNl30MMBNE1e">
                <!--{if !$_G['forum_thread']['special']}--><li><input type="button" value="{lang edit}" class="sdr8LyB3XsGD" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></li><!--{/if}-->
                <li><input type="button" value="{if !$_G['forum_thread']['closed']}{lang modmenu_switch_off}{else}{lang modmenu_switch_on}{/if}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4"></li>
                <li><input type="button" value="{lang admin_banpost}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></li>
                <li><input type="button" value="{lang topicadmin_warn_add}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}"></li>
                <li><input type="button" value="{lang thread_moved}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=move&optgroup=2&from={$_G[tid]}"></li>
                <li><input type="button" value="{lang modmenu_type}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=type&optgroup=2&from={$_G[tid]}"></li>
                <li><input type="button" value="{lang modmenu_stickpost}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=stick&optgroup=1&from={$_G[tid]}"></li>
                <li><input type="button" value="{lang digest_posts}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=digest&optgroup=5&from={$_G[tid]}"></li>
                <li><input type="button" value="{lang delete}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}"></li>
                <!--{if !empty($postlist[$post[pid]]['totalrate']) && $_G['forum']['ismoderator']}--><li><a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" class="seoCZDlIHhmi" >{lang removerate}</a></li><!--{/if}-->
            </ul>
        </div>
        <!--{else}-->
        <div id="moption_$post[pid]" popup="true" style="display:none;">
            <ul class="tNl30MMBNE1e">
                <li><input type="button" value="{lang edit}" class="sdr8LyB3XsGD" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page"></li>
                <!--{if $_G['group']['allowbanpost']}--><li><input type="button" value="{lang modmenu_banpost}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                <!--{if $_G['group']['allowwarnpost']}--><li><input type="button" value="{lang modmenu_warn}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                <!--{if $_G['group']['allowstickreply']}--><li><input type="button" value="{lang modmenu_stickpost}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=stickreply&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                <!--{if $_G['group']['allowdelpost']}--><li><input type="button" value="{lang modmenu_deletepost}" class="T46cBYEx6Wws" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}"></li><!--{/if}-->
                <!--{if !empty($postlist[$post[pid]]['totalrate']) && $_G['forum']['ismoderator']}--><li><a href="forum.php?mod=misc&action=removerate&tid=$_G[tid]&pid=$post[pid]&page=$page" class="seoCZDlIHhmi" >{lang removerate}</a></li><!--{/if}-->
            </ul>
        </div>
        <!--{/if}-->
        <!-- manage end -->
        <!--{/if}-->
    </div>
    <!--{if $post['first']}-->
    <!--{if $groupsnoad && in_array($_G[group][groupid],(array)unserialize($groupsnoad))}--><!--{else}-->
    <!--{if $adviewthreadd && in_array($_G['fid'],(array)unserialize($adviewthreadidd))}--><!--{$adviewthreadd}--><!--{/if}-->
    <!--{if $adviewthreade && in_array($_G['fid'],(array)unserialize($adviewthreadide))}--><!--{$adviewthreade}--><!--{/if}-->
    <!--{if $adviewthreadf && in_array($_G['fid'],(array)unserialize($adviewthreadidf))}--><!--{$adviewthreadf}--><!--{/if}-->
    <!--{/if}-->
    <!--{/if}-->
    <!--{if $post['first']}-->
    <!--{if $_G[forum_thread][special] != 2}-->
    <!--{if $openrelated == 0 || $openrelated == 1}-->
    <!--{if $openrelated == 0 && $post['relateitem']}-->
    <div class="hcCXEzm2EUmB">
        <div class="kYNdiMbUdV3L"><span>{lang related_thread}</span></div>
        <ul>
            <!--{eval $rel = 1;}-->
            <!--{loop $post['relateitem'] $var}-->
            <!--{if $relatedpics == 1}-->
            <!--{eval $thread['rlithumb'] = DB::result_first("SELECT aid FROM  ".DB::table("forum_attachment_".substr($var['tid'],-1,1))." WHERE  tid =".$var['tid']." and width>0 LIMIT 0 , 1");}-->
            <!--{/if}-->
            <!--{if $rel == $relatednums + 1}--><div class="dQy5wJYaOje6"><span>{$langplus[more_view]}</span></div><!--{/if}-->
            <li{if $rel > $relatednums} class="hrqrSX1tdqGJ"{/if}>
            <a href="forum.php?mod=viewthread&tid=$var[tid]" class="relateitem_subject{if !$thread['rlithumb']} nopic{/if}">
                <!--{if $thread['rlithumb']}-->
                <!--{eval $imagerlithumb = getforumimg($thread['rlithumb'], 0, 200, 150); }-->
                <span class="fRDkQfri0KD8"><img src="{$imagerlithumb}"></span>
                <!--{/if}-->
                <div class="2LPcXe4ioFEM">$var[subject]</div>
                <div class="YeqcH1J2M9yy">
                    {echo dgmdate($var['dateline'], 'u')}
                    <!--{if $var[views] > 9999 }-->
                    <!--{eval $var[views] = round($var[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $var[replies] > 9999 }-->
                    <!--{eval $var[replies] = round($var[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <span class="9ECtWVPiFM1j"><!--{if $var[replies] > 0}-->{$var[replies]}{lang join_thread}<!--{else}-->{$var[views]}{$langplus[view]}<!--{/if}--></span>
                </div>
            </a>
            </li>
            <!--{eval $rel++;}-->
            <!--{/loop}-->
        </ul>
    </div>
    <!--{else}-->
    <!--{eval $vtperpage = $relatedallnums; $vtarticleday = $relatedtimes; $vtpostsorts = $relatedsorts; $vtonlypic = $relatedpics; }-->
    <!--{eval require_once(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/viewthreadlist.php');}-->
    <!--{if $vtslist}-->
    <div class="hcCXEzm2EUmB">
        <div class="kYNdiMbUdV3L"><span>{lang related_thread}</span></div>
        <ul>
            <!--{eval $rel = 1;}-->
            <!--{loop $vtslist $vts}-->
            <!--{if $rel == $relatednums + 1}--><div class="dQy5wJYaOje6"><span>{$langplus[more_view]}</span></div><!--{/if}-->
            <li{if $rel > $relatednums} class="hrqrSX1tdqGJ"{/if}>
            <a href="forum.php?mod=viewthread&tid={$vts[tid]}" class="relateitem_subject{if !$vts[imagethumb]} nopic{/if}">
                <!--{if $vts[imagethumb]}--><span class="fRDkQfri0KD8"><img src="{$vts[imagethumb]}"></span><!--{/if}-->
                <div class="2LPcXe4ioFEM">{$vts[subject]}</div>
                <div class="YeqcH1J2M9yy">
                    {$vts[dateline]}
                    <!--{if $vts[views] > 9999 }-->
                    <!--{eval $vts[views] = round($vts[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{if $vts[replies] > 9999 }-->
                    <!--{eval $vts[replies] = round($vts[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <span class="9ECtWVPiFM1j"><!--{if $vts[replies] > 0}-->{$vts[replies]}{lang join_thread}<!--{else}-->{$vts[views]}{$langplus[view]}<!--{/if}--></span>
                </div>
            </a>
            </li>
            <!--{eval $rel++;}-->
            <!--{/loop}-->
        </ul>
    </div>
    <!--{/if}-->
    <!--{/if}-->
    <script type="text/javascript">
        $(document).ready(function(){
            $('.relateitem_more').click(function(){
                $('.relateitem_morerelated').show();
                $(this).hide();
            });
        });
    </script>
    <!--{/if}-->
    <!--{/if}-->
    <div class="kYNdiMbUdV3L">
        <span class="0bhVAwWEgjfe">{$_G[forum_thread][allreplies]}{$langplus[reply]}</span>
        <!--{if $_G[forum_thread][allreplies] > 0}-->
        <!--{if !$rushreply}-->
        <!--{if $ordertype != 1}-->
        <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=1" class="PrBe62Mw1IDM">{$langplus[post_descview]}</a>
        <!--{else}-->
        <a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype=2" class="NywE32WSJAaj">{$langplus[post_ascview]}</a>
        <!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
    </div>
    <!--{/if}-->
    <!--{eval $postcount++;}-->
    <!--{/loop}-->
</div>
<!-- main postlist end -->
<div id="ajaxpost"{if $viewposttype == 1} class="mDmBotJAJlgM"{/if}><div id="post_new"></div></div>
<!--{if $_G[forum_thread][allreplies] <= 0}-->
<div class="x5BZR3FRERsB">
    <img src="template/v2_mbl20121009/touch_plus/image/sofa.png">
    $langplus[sofas]
</div>
<!--{/if}-->
<!--{if ($_G[forum_thread][allreplies] > 0) && ($_G['forum_thread']['replies'] < $_G['ppp']) }-->
<div class="43wK1zoZJSkW">$langplus[allcontent]</div>
<!--{/if}-->
<!--{if $tplpages == 1}-->
<!--{eval $totalpage = ceil(($_G['forum_thread']['replies'] + 1) / $_G['ppp']);}-->
<!--{if $totalpage > $page}-->
<a href="forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]&ordertype={if $ordertype != 1}2{else}1{/if}&threads=thread" class="eMpHsVJ7jUAD" data-num="{$totalpage}-{$page}">$langplus[more]</a>
<script src="template/v2_mbl20121009/touch_plus/js/ajaxpage_view.js?{VERHASH}"></script>
<!--{/if}-->
<!--{else}-->
<!--{if $multipage}-->$multipage<!--{/if}-->
<!--{/if}-->
<!--{subtemplate forum/forumdisplay_fastpost}-->
<!--{hook/viewthread_bottom_mobile}-->
<!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') == false && strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') == false && (strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false)}-->
<!--{eval $thread['thumb'] = DB::result_first("SELECT attachment FROM  ".DB::table("forum_attachment_".substr($thread['tid'],-1,1))." WHERE tid = ".$thread['tid']." and width>0 LIMIT 0 , 1");}-->
<div id="myshare" class="FaSQYzf2VMvl"></div>
<div class="Z0LPL5WS1xnk"></div>
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/share.js?{VERHASH}"></script>
<script type="text/javascript">var config = {url:'{$_G['siteurl']}/forum.php?mod=viewthread&tid=$_G[tid]&extra=$_GET[extra]',title:'{$_G[forum_thread][subject]}',desc:'{$_G[forum_thread][subject]}',img:'{$_G['siteurl']}/{$_G['setting']['attachurl']}/forum/{$thread[thumb]}',};var share_obj = new myshare('myshare',config);</script>
<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false }-->
<div id="myshare"></div>
<div class="WW4VvNWdFQ4q"></div>
<!--{else}-->
<div id="myshare" class="FaSQYzf2VMvl"><div class="RTAop8vicVmM">{$langplus[share_browser]}</div></div>
<div class="Z0LPL5WS1xnk"></div>
<!--{/if}-->
<div class="L3MPZfbX2D8u"></div>
<div class="5g2wE3zijhsf"></div>
<!--{if $_G[forum_thread][special] == 2}-->
<div class="Fkkj8mfPMFsU"></div>
<!--{/if}-->
<script type="text/javascript">
    $(document).ready(function(){
        $(document).on('dblclick','.viewlist',function(){
            $('.scroll_plus').fadeToggle();
        });
        <!--{if $_G[uid]}-->
        $(document).on('click','.moreaction',function(){
            var menupsid = $(this).parent('.viewpost').next('.menups').attr('id');
            $('#' + menupsid).fadeIn();
            $('.close_m').show();
            $(this).addClass('popon');
        });
        $('.close_m').off().on('touchstart',function(){
            $('.menups').hide();
            $('.popon').removeClass('popon');
            $(this).hide();
        });
        $(document).on('click','.menups a',function(){
            $('.menups, .close_m').hide();
            $('.popon').removeClass('popon');
        });
        $(document).on('click','.ajaxjump',function(){
            popup.open('<div class="mGOxFPyyZxiV"></div>');
            var obj = $(this);
            $.ajax({
                type:'POST',
                url:obj.attr('href') + '&handlekey=ajaxjump&inajax=1',
                data:{'formhash':'{FORMHASH}'},
                dataType:'xml',
            })
                .success(function(s) {
                    popup.open(s.lastChild.firstChild.nodeValue);
                    evalscript(s.lastChild.firstChild.nodeValue);
                })
                .error(function() {
                    window.location.href = obj.attr('href');
                    popup.close();
                });
            return false;
        });
        <!--{/if}-->
    });
</script>
<!--{block scrollplus}-->
<div class="LF9scR0aD0no"><!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}--><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="tGhbvKsLwUoL"><i></i></a><!--{/if}--><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="gb1EvDjBUSom"></a></div>
<!--{/block}-->