<?php echo 'From: DisM.taobao.com';exit;?>
	<div class="pt">{lang panel_login}</div>
    <div class="inputall">
    <ul>
	<form method="post" autocomplete="off" action="{$cpscript}?mod=modcp&action=login" class="exfm">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="fid" value="{$_G[fid]}" />
        <input type="hidden" name="uid" value="{$_GET[uid]}" />
		<input type="hidden" name="submit" value="yes" />
		<input type="hidden" name="login_panel" value="yes" />
		<li>{lang panel_login_username}: <strong>{$_G[member][username]}</strong></li>
        <li><input type="password" name="cppwd" id="cppwd" placeholder="{lang panel_login_password}" /></li>
        <button type="submit" name="submit" id="submit" value="true" class="button5">{lang submit}</button>
	</form>
    </ul>
    </div>