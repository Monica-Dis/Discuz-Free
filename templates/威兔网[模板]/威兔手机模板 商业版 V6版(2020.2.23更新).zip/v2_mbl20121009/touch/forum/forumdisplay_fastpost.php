<?php echo 'From: DisM.taobao.com';exit;?>
<div id="flpost">
<div class="o7XBIO2AbIOX">
	<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes&mobile=2">
	<input type="hidden" name="formhash" value="{FORMHASH}" />	
        <!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->    
		<div class="UnLFzVjvSkaD">
        <select id="stand" name="stand" >
			<option value="">{lang debate_viewpoint}</option>
			<option value="0">{lang debate_neutral}</option>
			<option value="1">{lang debate_square}</option>
			<option value="2">{lang debate_opponent}</option>
		</select>
        </div>
        <!--{/if}-->
		<ul class="70RMxsdq69z2">				
		<li{if $secqaacheck || $seccodecheck} class="7V0aj6bIRtYR"{/if}><textarea name="message" id="fastpostmessage" rows="3" placeholder="{$langplus[sayaword]}"></textarea></li>
        <!--{if $allowfastpost || $_G[uid]}--><!--{if $secqaacheck || $seccodecheck}--><li class="AVK4ckDbUu5b"><!--{subtemplate common/seccheck}--></li><!--{/if}--><!--{/if}-->
        <!--{hook/viewthread_fastpost_button_mobile}-->
		</ul>        
      <div class="JFisFvnvOOmR">
      <table cellspacing="0" cellpadding="0">
        <tr>
        <td>
		<div class="6Ow6ulKMHLqn">        
		<!--{if $_G['forum']['allowmediacode'] && $_G['group']['allowmediacode']}-->
		<a href="javascript:;" class="SSX1ug2nmElP"></a>             
		<!--{/if}-->
        <a href="javascript:;" class="{if $_G['group']['allowat'] > 0}cutoption{else}inlink{/if} editortab"></a>
        <!--{if $_G['forum']['allowsmilies']}-->
		<a href="javascript:;" class="8ZEzUDmgfRGH"></a>
        <!--{/if}-->
        <!--<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" class="LX2AwZRZ6AcH"></a>--> 
        <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" class="BEalYTMDCYe3">{$langplus[advmode]}</a>
		</div>
        </td>
        <th id="fastpostsubmitline"><button type="submit" name="replysubmit" id="fastpostsubmit" value="{lang reply}" class="iE5tROBSAh66" disable="true" >{lang reply}</button></th>
        </tr>
      </table>      
		<div class="llLJ43IWYvyD">
        <!--{if $_G['forum']['allowmediacode'] && $_G['group']['allowmediacode']}-->            
		<div class="22QH8w7MKUZo">
		<div class="3LAI9IVO8Vpr">
        <i class="Xqx8QKWTMDzJ"></i>
		<input type="text" name="video_link" id="video_link" autocomplete="off" placeholder="{$langplus[video_link]}" />
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_0())">{$langplus[insert]}</span>
		</div>
		<div class="3LAI9IVO8Vpr">
        <i class="DHkiB5Uji0vl"></i>
		<input type="text" name="music_link" id="music_link" autocomplete="off" placeholder="{$langplus[music_link]}" />
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_1())">{$langplus[insert]}</span>
		</div>
		</div>
        <!--{/if}-->        
		<div class="22QH8w7MKUZo">
		<div class="3LAI9IVO8Vpr">
        <i class="9EAJdkchBJVA"></i>
        <div class="oGYuEZ1uz6pO"><input type="text" name="links_link" id="links_link" autocomplete="off" placeholder="{$langplus[links_link]}" /></div>
        <div class="oGYuEZ1uz6pO"><input type="text" name="linkname_link" id="linkname_link" autocomplete="off" placeholder="{$langplus[linkname_link]}" /></div>
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_2())">{$langplus[insert]}</span>
		</div>
        <!--{if $_G['group']['allowat'] > 0}-->
		<div class="3LAI9IVO8Vpr">
        <i class="27IgHd5nBrvs"></i>
		<input type="text" name="iat_name" id="iat_name" autocomplete="off" placeholder="{$langplus[iat]}" />
		<span class="upCRTDewMZEF" onclick="ilink(ins_code_3())">{$langplus[insert]}</span>
		</div>
        <!--{/if}-->
        </div>
        <!--{if $_G['forum']['allowsmilies']}-->
		<div id="smiliesdiv" class="22QH8w7MKUZo"><div id="fastsmilies"></div></div>
        <!--{/if}-->
		</div>
      </div>
      <div class="UBBCWM3InK1m" style="display: none;">
		<ul>
            <!--{if $_G['group']['allowanonymous']}-->
            <li><label for="isanonymous"><input type="checkbox" name="isanonymous" id="isanonymous" value="1" /><em>{lang post_anonymous}</em></label></li>
            <!--{/if}-->
			<!--{if $_GET[action] != 'edit' && helper_access::check_module('feed') && $_G['forum']['allowfeed']}-->
            <li><label for="addfeed"><input type="checkbox" name="addfeed" id="addfeed" value="1" $addfeedcheck><em>{lang addfeed}</em></label></li>
            <!--{/if}-->
            <li><label for="usesig"><input type="checkbox" name="usesig" id="usesig" value="1" {if !$_G['group']['maxsigsize']}disabled{else}checked="checked"{/if}/><em>{lang post_show_sig}</em></label></li>
            <li><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page" class="e4RCG3lmxf0V">{$langplus[postadv]}</a></li>
		</ul>
      </div>
    </form>    
</div>
</div>
<!--{if $_G[uid]}-->
<script type="text/javascript">
	$(document).ready(function() {
	$('.editordefault a.editortab').click(function(){
		$('.editordefault a').eq($(this).index()).toggleClass('on').siblings().removeClass('on');
		$('.hidebox').eq($(".editordefault a.editortab").index(this)).slideToggle().siblings().slideUp();
	});
	});
	function ins_code_2(){
		var newvalue = $("#links_link").val();
		var newvalue2 = $("#linkname_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		newvalue2 = newvalue2.replace(/^\s+|\s+$/g,"");
		if(!newvalue2) {
			newvalue2 = newvalue;
		}
		if (newvalue) {
			$("#links_link").val("");
			$("#linkname_link").val("");
			editorclose();
			return "[url="+ newvalue +"]"+ newvalue2 +"[/url]";
		}else{
			return "";
		}
	}	
	<!--{if $_G['forum']['allowmediacode'] && $_G['group']['allowmediacode']}-->
	function ins_code_0(){
		var newvalue = $("#video_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#video_link").val("");
			editorclose();
			return "[media]"+ newvalue +"[/media]";
		}else{
			return "";
		}
	}
	function ins_code_1(){
		var newvalue = $("#music_link").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#music_link").val("");
			editorclose();
			return "[audio]"+ newvalue +"[/audio]";
		}else{
			return "";
		}
	}
	<!--{/if}-->
	<!--{if $_G['group']['allowat'] > 0}-->
	function ins_code_3(){
		var newvalue = $("#iat_name").val();
		newvalue = newvalue.replace(/^\s+|\s+$/g,"");
		if (newvalue) {
			$("#iat_name").val("");
			editorclose();
			return "@"+ newvalue +" ";
		}else{
			return "";
		}
	}
	<!--{/if}-->
	function editorclose(){		
		$('.editordefault a').removeClass('on');
		$('.hidebox').slideUp();		
	}
</script>
<!--{/if}-->
<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/insertsome.js?{VERHASH}"></script>
<!--{if $_G['forum']['allowsmilies']}-->
<script type="text/javascript" src="data/cache/common_smilies_var.js?eAa"></script>
<!--{/if}-->
<script type="text/javascript">
function ilink(lk){$('#fastpostmessage').insertAtCaret(lk);}
function ismi(sl){$("#fastpostmessage").insertAtCaret(sl);}
<!--{if $_G['forum']['allowsmilies']}-->
var j = 1, smilies_fastdata = '', img;
if (smilies_array[{$smileid}][{$smilepg}].length > {$smilenumber}){smilienums = {$smilenumber};}else{smilienums = smilies_array[{$smileid}][{$smilepg}].length;}
for (i = 0; i < smilienums; i++) {	
	s = smilies_array[{$smileid}][{$smilepg}][i];	
    smilieimg = "static/" + 'image/smiley/' + smilies_type['_' + {$smileid}][1] + '/' + s[2];
    smilies_fastdata += s ? '<li><img src="' + smilieimg + '" onclick="ismi(\'' + s[1].replace(/'/, '\\\'') + '\')" />' : '</li>';
}
window.onload = function() {
    $('#fastsmilies').html('<div class="saMZOV8357GQ"><ul>' + smilies_fastdata + '</ul></div>');
}
<!--{/if}-->
</script>
<script type="text/javascript">
	(function() {
		var form = $('#fastpostform');	
		<!--{block viewpostjs}-->
		<!--{if $secqaacheck || $seccodecheck}-->
		var fastpostmessage = sectxt = false;
		<!--{else}-->
		var fastpostmessage = false;
		<!--{/if}-->		
		$('#fastpostmessage').on('keyup input focus', function() {
			var obj = $(this);
			if(obj.val()) {
				fastpostmessage = true;	
				<!--{if $secqaacheck || $seccodecheck}-->
				if(sectxt == true) {
					$('#fastpostsubmitline button').removeClass('nopost').addClass('btnon').attr('disable', 'false');					
				}
				<!--{else}-->
				$('#fastpostsubmitline button').removeClass('nopost').addClass('btnon').attr('disable', 'false');
				<!--{/if}-->
			} else {
				fastpostmessage = false;
				$('#fastpostsubmitline button').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
			}
		});		
		<!--{if $secqaacheck || $seccodecheck}-->
		$('.sectxt').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				sectxt = true;	
				if(fastpostmessage == true) {
					$('#fastpostsubmitline button').removeClass('nopost').addClass('btnon').attr('disable', 'false');					
				}
			} else {
				sectxt = false;
				$('#fastpostsubmitline button').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
			}
		});	
		<!--{/if}-->				
		<!--{/block}-->
		<!--{if $allowfastpost}-->
		<!--{$viewpostjs}-->
		<!--{else}-->
		<!--{if !$_G[uid] || $_G[uid] && !$allowpostreply}-->
		$('#fastpostmessage').on('focus', function() {
			<!--{if !$_G[uid]}-->
				popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
			<!--{else}-->
				popup.open('{lang nopostreply}', 'alert');
			<!--{/if}-->
			this.blur();
		});
		<!--{else}-->
		<!--{$viewpostjs}-->
		<!--{/if}-->
		<!--{/if}-->		
		$('#fastpostsubmit').on('click', function() {		
		var btobj = $(this);
		if(btobj.attr('disable') == 'true') { 
			return false;
		}
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey=fastpost&loc=1&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = obj.attr('href');
				popup.close();
			});
			setTimeout(function(){ 
				$(".postbox").slideToggle();
				$('.editordefault a').removeClass('on');
				$('.hidebox').slideUp();
				$(".close_p").hide();
				<!--{if $_G[forum_thread][allreplies] < 1}-->
				$(".sofareply").remove();
				<!--{/if}-->
				$('#fastpostsubmitline button').removeClass('btnon').addClass('nopost').attr('disable', 'true');				
				}, 500);						
			return false;
		});		
	})();

	function succeedhandle_fastpost(locationhref, message, param) {
		var pid = param['pid'];
		var tid = param['tid'];
		if(pid) {
			$.ajax({
				type:'POST',
				url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid + '&mobile=2',
				dataType:'xml'
			})
			.success(function(s) {
				$('#post_new').append(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = 'forum.php?mod=viewthread&tid=' + tid;
				popup.close();
			});
		} else {
			if(!message) {
				message = '{lang postreplyneedmod}';
			}
			popup.open(message, 'alert');
		}
		$('#fastpostmessage').attr('value', '');
		if(param['sechash']) {
			$('.seccodeimg').click();
		}
	}

	function errorhandle_fastpost(message, param) {
		popup.open(message, 'alert');
	}	
</script>