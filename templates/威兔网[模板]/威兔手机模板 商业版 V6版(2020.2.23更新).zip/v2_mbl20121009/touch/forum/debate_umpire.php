<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang debate_umpirecomment}<!--{/block}-->
<!--{template common/header}-->
<form method="post" autocomplete="off" id="postform" action="forum.php?mod=misc&action=debateumpire&tid=$_G[tid]&umpiresubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}">
	<div class="inputall bw">
		<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
               <ul>                    
					<li class="ptn">
						{lang debate_winner}:&nbsp;&nbsp;&nbsp; <label><input type="radio" name="winner" value="1" $winnerchecked[1] id="winner1" />{lang debate_square}</label>
						&nbsp;&nbsp;<label><input type="radio" name="winner" value="2" $winnerchecked[2] id="winner2" />{lang debate_opponent}</label>
						&nbsp;&nbsp;<label><input type="radio" name="winner" value="3" $winnerchecked[3] id="winner3" />{lang debate_draw}</label>
					</li>
					<li class="mbn"><label for="bestdebater">{lang debate_bestdebater}:</label></li>
					<li>
						<div class="selectstyle">
							<select onchange="document.getElementById('bestdebater').value=this.options[this.options.selectedIndex].value">
								<option value=""><strong>{lang debate_recommend_list}</strong></option>
								<option value="">------------------------------</option>
								<!--{loop $candidates $candidate}-->
									<option value="$candidate[username]"{if $candidate[username] == $debate[bestdebater]} selected="selected"{/if}>$candidate[username] ( $candidate[voters] {lang debate_poll}, <!--{if $candidate[stand] == 1}-->{lang debate_square}<!--{elseif $candidate[stand] == 2}-->{lang debate_opponent}<!--{/if}-->)</option>
								<!--{/loop}-->
							</select>
						</div>
                        </li>
						<li><input type="text" name="bestdebater" id="bestdebater" value="$debate[bestdebater]" placeholder="{lang debate_list_nonexistence}" /></li>
					<li><textarea id="umpirepoint" name="umpirepoint" rows="6" placeholder="{lang debate_umpirepoint}">$debate[umpirepoint]</textarea></li>
                    <li><button class="formdialog button5" type="submit" name="umpiresubmit" value="true" >{lang submit}</button></li>		
         </ul>
	</div>
</form>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->