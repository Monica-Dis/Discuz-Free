<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{if !$_G['inajax']}--><style type="text/css">.tip { border:none; width:auto;}</style><!--{/if}-->
<div class="tip">
	<form method="post" autocomplete="off" id="commentform" action="forum.php?mod=post&action=reply&comment=yes&tid=$post[tid]&pid=$_GET[pid]&extra=$extra{if !empty($_GET[page])}&page=$_GET[page]{/if}&commentsubmit=yes&infloat=yes">
    	<input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
        <input type="hidden" name="handlekey" value="$_GET['handlekey']" />
    <div class="reply_comment">
        <textarea  name="message" id="commentmessage" placeholder="{if !$_GET[trade_comment]}{lang comments}{/if}"  tabindex="2" ></textarea>
        <!--{if $secqaacheck || $seccodecheck}-->
        <div id="seccheck_comment"><!--{subtemplate common/seccheck}--></div>
        <!--{/if}-->   
    </div>
    <dd>
    <button type="submit" id="commentsubmit" class="{if $_GET[trade_comment]}formsdialog{else}formdialog{/if} button2" value="true" name="commentsubmit" tabindex="3"><span>{lang publish}</span></button>
    	<a href="javascript:;" onclick="popup.close();">{lang close}</a>
    </dd>
	</form> 
</div>
<!--{template common/footer}-->