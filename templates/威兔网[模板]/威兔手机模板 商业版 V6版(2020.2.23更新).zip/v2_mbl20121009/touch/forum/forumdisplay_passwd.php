<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="forum.php?mod=forumdisplay&fid={$_G['forum']['fid']}">{$_G['forum']['name']}</a><!--{/block}--> 
<!--{template common/header}-->
<div class="bw">
    <form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=pwverify">
      <input type="hidden" name="formhash" value="{FORMHASH}" />
      <ul class="inputall b_pw pbm">
      <li>{lang forum_password_require}</li>
      <li class="mbs"><input type="password" name="pw" /></li>
      <li><button class="formdialog button5" type="submit" name="loginsubmit" value="true">{lang submit}</button></li>
      </ul>
    </form>
</div>
<!--{template common/footer}-->