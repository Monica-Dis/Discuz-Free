<?php echo 'From: DisM.taobao.com';exit;?>
<!--{if $thread['freemessage']}-->
	<div id="postmessage_$pid">$thread[freemessage]</div>
<!--{/if}-->

<!--{if empty($_GET['archiver'])}-->
	<div class="LnNTiGK7Shwz">
			<em class="99u2LxYcMOhO"><a href="forum.php?mod=misc&action=pay&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET['from'])}&from=$_GET['from']{/if}"{if $_G[uid]} class="F3pveqiOE331"{/if}>{lang pay}</a></em>
			<!--{if $_G[forum_thread][price] > 0}-->{lang pay_comment}<!--{/if}-->
            <!--{if $thread[endtime]}--><br />{lang pay_free_time}<!--{/if}-->
            <!--{if $thread[payers]}--><br />{lang have} $thread[payers] {lang people_buy}<!--{/if}-->
		</div>
<!--{else}-->	
	<!--{if $_G[forum_thread][price] > 0}-->{lang pay_comment}<!--{/if}-->
    <!--{if $thread[endtime]}--><br />{lang pay_free_time}<!--{/if}-->
    <!--{if $thread[payers]}--><br />{lang have} $thread[payers] {lang people_buy}<!--{/if}-->	
<!--{/if}-->
