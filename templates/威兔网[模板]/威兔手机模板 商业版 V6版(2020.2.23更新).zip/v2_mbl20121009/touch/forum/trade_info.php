<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang trade_viewtrade}<!--{/block}-->
<!--{template common/header}-->
<!--{if $postlist[$post[pid]]['invisible'] != 0}-->
<div class="sqK9gG26iUGb">{lang post_trade_removed}</div>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
{eval exit;}
<!--{/if}-->
<div class="SuGP7kKqtjgl">
	<div class="egk16kKQ2GCI">
		<div class="THBxHeNk3WHg">
			<div class="XD7LnGSCwCMA" style="background-image: url('{if $trade['thumb']}{$trade[thumb]}{else}{IMGDIR}/nophoto.gif{/if}')">
				<!--{if !$_G['forum_thread']['is_archived']}-->
				<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] < $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid'])) && !$post['first'] || $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
				<div class="aoVlE2ohDBiG">
					<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit_trade}</a>
					<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}--><a href="forum.php?mod=topicadmin&action=delpost&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$trade[pid]}" class="F3pveqiOE331">{lang delete}</a><!--{/if}-->
					<!--{if $_G['forum']['picstyle'] && ($_G['forum']['ismoderator'] || ($_G['uid'] == $_G['thread']['authorid'] && $_G['forum_thread']['closed'] == 0))}--><a href="forum.php?mod=ajax&action=setthreadcover&aid=$trade[aid]&fid=$_G[fid]" class="F3pveqiOE331">{lang set_cover}</a><!--{/if}-->
				</div>
				<!--{/if}-->
				<!--{/if}-->
			</div>
			<div class="AsntSIu28I7F">
				<div class="yQgpcdrtBijq">
					<!--{if $trade[price] > 0}--><span>&yen;{$trade[price]}</span><!--{if $trade['costprice'] > 0}--><em>&yen;{$trade[costprice]}</em><!--{/if}--><!--{/if}-->
					<!--{if $trade[price] == 0.00}--><!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}--><span>{$trade[credit]}<cite class="LboqhQ5C6lzU">{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</cite></span><!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade['costcredit'] > 0}--><em>{$trade[costcredit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}</em><!--{/if}--><!--{/if}--><!--{/if}-->
					<!--{if $trade['displayorder'] > 0}--><i class="piHOErwgbub3"></i><!--{/if}-->
				</div>
				<div class="hyjjoLtE0YYq">
					<!--{if $trade[closed]}-->
					<span>{lang trade}{lang trade_timeout}</span>
					<!--{elseif $trade[expiration] > 0 || $trade[expirationhour] > 0}-->
					<p class="sEj1sHHzaWFN">{lang trade_remaindays}</p>
					<p><em>{$trade[expiration]}</em>{lang days}<em>{$trade[expirationhour]}</em>{lang trade_hour}</p>
					<!--{elseif $trade[expiration] == 0 && $trade[expirationhour] == 0}-->
					<span>{lang trade}{$langplus[neverexpires]}</span>
					<!--{elseif $trade[expiration] == -1}-->
					<span>{lang trade}{lang trade_timeout}</span>
					<!--{else}-->
					<!--{/if}-->
				</div>
			</div>
		</div>
	</div>
	<div class="gV9DO0ygKA2w">
		<h1><a href="forum.php?mod=viewthread&tid=$_G[tid]{if $_GET[from]}&from=$_GET[from]{/if}">$_G['forum_thread'][subject]</a></h1>
		<div class="z2OY8dGwEsaQ">
			<a href="{if $post['authorid'] && $post['username'] && !$post['anonymous']}home.php?mod=space&uid=$post[authorid]&do=profile{else}{if $_G['forum']['ismoderator']}home.php?mod=space&uid=$post[authorid]&do=profile{else}javascript:;{/if}{/if}" class="m5kR1DjvO3dd"><img src="{if !$post['authorid'] || $post['anonymous']}{avatar(0, small, true)}{else}{avatar($post[authorid], small, true)}{/if}" /></a>
			<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
			<a href="home.php?mod=space&uid=$post[authorid]&do=profile" >$post[author]</a>
			<!--{else}-->
			<!--{if !$post['authorid']}-->
			<a href="javascript:;">{lang guest}</a>
			<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
			<!--{if $_G['forum']['ismoderator']}-->
			<a href="home.php?mod=space&uid=$post[authorid]&do=profile">{lang anonymous}</a>
			<!--{else}-->
			<a href="javascript:;">{lang anonymous}</a>
			<!--{/if}-->
			<!--{else}-->
			<a href="javascript:;">$post[author]</a> {lang member_deleted}
			<!--{/if}-->
			<!--{/if}-->
			<span class="Q8lZLnjHfm2v">{lang trade_seller}</span>
			<a href="home.php?mod=space&uid=$post[authorid]&do=trade&view=eccredit#sellcredit" class="99u2LxYcMOhO">{$langplus[credit]} $post[buyercredit]&nbsp;<img src="{STATICURL}image/traderank/buyer/$post[buyerrank].gif"></a>
		</div>
	</div>
	<div class="trade_des m_c{if !$post[message]} p_c{/if}">
		<div class="ObFJ8Fwillsv" style="display: block;">
			<p class="trade_sel{if !$usertrades} trade_nosel{/if}"><span>$langplus[tradeselected]:</span> $trade[subject]<!--{if $trade['displayorder'] > 0}--><sup class="UR9MTbIErCZG"></sup><!--{/if}--></p>
			<p>
				<span>{$langplus[tradetype]}:</span>
				<!--{if $trade['quality'] == 1}-->{lang trade_new}<!--{/if}--><!--{if $trade['quality'] == 2}-->{lang trade_old}<!--{/if}-->{lang trade_type_buy}
			</p>
			<p><span>{$langplus[tradenumber]}:</span> $trade[amount] {$langplus[piece]}</p>
			<p><span>{$langplus[tradeselled]}:</span> $trade[totalitems] {$langplus[piece]}</p>
			<!--{if $trade[locus]}--><p><span>{lang trade_locus}:</span> $trade[locus]</p><!--{/if}-->
			<p>
				<span>{lang trade_transport}:</span>
				<!--{if $trade['transport'] == 0}-->{lang post_trade_transport_offline}<!--{/if}-->
				<!--{if $trade['transport'] == 1}-->{lang post_trade_transport_seller}<!--{/if}-->
				<!--{if $trade['transport'] == 2 || $trade['transport'] == 4}-->
				<!--{if $trade['transport'] == 4}-->{lang post_trade_transport_physical}<!--{/if}-->
				<!--{if !empty($trade['ordinaryfee']) || !empty($trade['expressfee']) || !empty($trade['emsfee'])}-->
				<!--{if !empty($trade['ordinaryfee'])}-->{lang post_trade_transport_mail} $trade[ordinaryfee] {lang payment_unit}<!--{/if}-->
				<!--{if !empty($trade['expressfee'])}--> {lang post_trade_transport_express} $trade[expressfee] {lang payment_unit}<!--{/if}-->
				<!--{if !empty($trade['emsfee'])}--> EMS $trade[emsfee] {lang payment_unit}<!--{/if}-->
				<!--{elseif $trade['transport'] == 2}-->
				{lang post_trade_transport_none}
				<!--{/if}-->
				<!--{/if}-->
				<!--{if $trade['transport'] == 3}-->{lang post_trade_transport_virtual}<!--{/if}-->
			</p>
			<!--{if $trade[price] > 0}-->
			<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
			<p>
				<span>{lang trade_additional}:</span>
				<!--{if $trade[price] > 0}-->{$langplus[payment]} <!--{/if}--><em class="evXx4HZDPWdN">$trade[credit]</em> {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}
			</p>
			<!--{/if}-->
			<!--{/if}-->
		</div>
	</div>

	<!--{if $post[message]}-->
	<div class="RfSCfHfFXqla">
		<h1 class="ZGzUFVKWyZTf">{lang trade}{lang detail}</h1>
		$post[message]
	</div>
	<!--{/if}-->

	<!--{eval $trade_comment = DB::fetch_all("SELECT * FROM ".DB::table("forum_postcomment")." WHERE pid=".$trade[pid]." ORDER BY dateline DESC LIMIT 20");}-->
	<div id="comment_$post[pid]" class="JGzqgcsxzSw2">
		<!--{if $trade_comment}-->
		<div class="plMY6dXoWDeo">
		<ul>
			<h1>{lang trade_message}</h1>
			<!--{loop $trade_comment $comtrade}-->
			<li>
				<a href="home.php?mod=space&uid=$comtrade[authorid]&do=profile" class="x9hHSPQjdnYg"><!--{avatar($comtrade[authorid],middle)}--></a>
				<div class="K8Nlb7F457Y1">
					<a href="home.php?mod=space&uid=$comtrade[authorid]&do=profile">$comtrade[author]</a>
					<!--{if $_G['forum']['ismoderator'] && $_G['group']['allowdelpost']}-->
					<a href="forum.php?mod=topicadmin&action=delcomment&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$comtrade[id]}&trade_delcomment=1" class="8oVKS8OK3xkQ"><i class="aPyV086aHjq3"></i></a>
					<!--{/if}-->
					<em>{echo dgmdate($comtrade[dateline], 'u')}</em>
				</div>
				$comtrade[comment]
			</li>
			<!--{/loop}-->
		</ul>
		</div>
		<!--{/if}-->
	</div>

	<!--{if $usertrades}-->
	<div class="1ZeoroAvv1gd">
		<div class="gZlcaCGmGZ0q"><span class="MzXGZuYzqGml"></span>{$langplus[selecttrade]}</div>
		<div class="twzVqxrRwm1R">
			<ul>
				<!--{loop $usertrades $usertrade}-->
				<li>
					<a href="forum.php?mod=viewthread&tid=$usertrade[tid]&do=tradeinfo&pid=$usertrade[pid]">
					<div class="91vmkTcOBOJf" style="background-image: url('{if $usertrade['aid']}{echo getforumimg($usertrade[aid])}{else}{IMGDIR}/nophotosmall.gif{/if}')"></div>
					<div class="FRFvxBdckhEw">$usertrade[subject]</div>
					<p>
						<!--{if $usertrade[price] > 0}--><em class="evXx4HZDPWdN">&yen;{$usertrade[price]}</em><!--{if $usertrade['costprice'] > 0}--><em>&yen;{$usertrade[costprice]}</em><!--{/if}--><!--{/if}-->
						<!--{if $usertrade[price] == 0.00}--><!--{if $_G['setting']['creditstransextra'][5] != -1 && $usertrade[credit]}--><em class="evXx4HZDPWdN">$usertrade[credit] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</em><!--{if $_G['setting']['creditstransextra'][5] != -1 && $usertrade['costcredit'] > 0}--><em>$usertrade[costcredit] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}</em><!--{/if}--><!--{/if}--><!--{/if}-->
					</p>
					</a>
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<div class="RghlnzV17hRz"></div>
	<!--{/if}-->
	<!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') == false && strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') == false && (strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false)}-->
	<!--{eval $thread['thumb'] = DB::result_first("SELECT attachment FROM  ".DB::table("forum_attachment_".substr($thread['tid'],-1,1))." WHERE tid = ".$thread['tid']." and width>0 order by dateline asc LIMIT 0 , 1");}-->
	<div id="myshare" class="ysMRojn3XRKC"></div>
	<div class="qytY6AvMLAlZ"></div>
	<script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/share.js?{VERHASH}"></script>
	<script type="text/javascript">var config = {url:'{$_G['siteurl']}/forum.php?mod=viewthread&tid=$_G[tid]&do=tradeinfo&pid=$usertrade[pid]',title:'{$trade[subject]}',desc:'{$trade[subject]}',img:'{if $thread[thumb]}{$_G['siteurl']}/{$_G['setting']['attachurl']}/forum/{$thread[thumb]}{elseif $logourl}{$_G['siteurl']}/{$logourl}{/if}',};var share_obj = new myshare('myshare',config);</script>
	<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false }-->
	<div id="myshare"></div>
	<div class="Bn5G6abKZdVY"></div>
	<!--{else}-->
	<div class="zddxUhbNB29m"><p>{$langplus[share_browser]}</p><img src="template/v2_mbl20121009/touch_plus/image/browser_share_icon.png"/></div>
	<div class="qytY6AvMLAlZ"></div>
	<!--{/if}-->
	<div class="60mwnxIWnpHM">
		<ul>
			<li>
				<!--{if $allowpostreply && $post['allowcomment'] && $_G['setting']['commentnumber']}-->
				<a href="forum.php?mod=misc&action=comment&pid=$post[pid]&trade_comment=1"{if $_G['uid']} class="F3pveqiOE331"{else} onclick="login_btn(this); return false;"{/if}><i class="4TtPW6YVzyiQ"></i>{lang trade_message}</a>
				<!--{else}-->
				<a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$trade[pid]&page=$page"{if !$_G['uid']} onclick="login_btn(this); return false;"{/if}><i class="4TtPW6YVzyiQ"></i>{lang trade_message}</a>
				<!--{/if}-->
			</li>
			<li>
				<!--{eval $favstate = C::t('home_favorite')->fetch_by_id_idtype($_G['tid'],'tid',$_G['uid']);}-->
				<!--{if $favstate && $_G['uid']}-->
				<a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="DEpWPCcOgRkB"><i class="yUHLv4Ewx6zR"></i>{$langplus[favorite]}</a>
				<!--{else}-->
				<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}" class="un5EcQmZbb1B" ><i class="quKOCKMOWfuc"></i>{$langplus[favorite]}</a>
				<!--{/if}-->
			</li>
			<li><a href="javascript:;" id="fshare"><i class="K8kYuvxODrq6"></i>{$langplus[share]}</a></li>
			<li class="rmAyvgIkbrmi"><a href="home.php?mod=spacecp&ac=pm&touid=$post[authorid]&op=showmsg"{if $_G['uid']} class="F3pveqiOE331"{else} onclick="login_btn(this); return false;"{/if}>{$langplus[contact]}{lang trade_seller}</a></li>
			<li class="1BXMqNi1D9lV">
				<!--{if $trade[amount]}-->
				<a href="forum.php?mod=trade&tid=$post[tid]&pid=$trade[pid]"{if !$_G['uid']} onclick="login_btn(this); return false;"{/if}>{$langplus[tradebuy]}</a>
				<!--{else}-->
				<a href="javascript:;">{lang sold_out}</a>
				<!--{/if}-->
			</li>
		</ul>
	</div>
</div>
<!--{if $usertrades}-->
<script type="text/javascript">
	$(document).ready(function(){
		$('.trade_sel').click(function(){
			$('.trade_fly').addClass('infly');
			$('.close_p1').show();
			$('body').addClass('menufly_open');
		});
		$('.vt-close').click(function(){
			$('.trade_fly').removeClass('infly');
			$('body').removeClass('menufly_open');
			$('.close_p1').hide();
		});
		$('.close_p1').click(function(){
			$('.trade_fly').removeClass('infly');
			$('body').removeClass('menufly_open');
			$(this).hide();
		});
	});
</script>
<!--{/if}-->
<script type="text/javascript">
	function login_btn() {
		popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
		return false;
	};
	$(document).on('click', '#pmsubmit_btn', function() {
		var obj = $(this);
		var form = $(this.form);
		popup.open('<div class="lmVdjV39q3EP"></div>');
		$.ajax({
			type:'POST',
			url:form.attr('action') + '&handlekey='+form.attr('id')+'&inajax=1',
			data:form.serialize(),
			dataType:'xml'
		})
				.success(function(s) {
					var smg = $(s.lastChild.firstChild.nodeValue).find('.message_float').html();
					popup.open('<div class="57wo6jJ46Z4Q"><dt>'+smg+'</dt></div>');
					setTimeout(function(){
						$(".dialogbox, #mask").fadeOut();
					}, 1500);
				})
				.error(function() {
					popup.open('{lang networkerror}', 'alert');
				});
		return false;
	});
        $(document).ready(function() {
            $('#fshare').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').addClass('weixinshare');
                $('.close_s1').show();
				<!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false}-->
                $('#myshare').addClass('openshare');
                $('header, footer, .pt, .scroll_plus{if !$headershow}, .scroll_openmenu{/if}').addClass('onlypage');
				$('.close_s').show();
				<!--{else}-->
				$('.share_browser').fadeIn();
				$('.close_s').show();
				shareclosetime = setTimeout(function(){
					$('.share_browser, .close_s').hide()
					},4000);
				<!--{/if}-->
            });
            $('.close_s, .close_s1').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').removeClass('weixinshare');
                <!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false}-->
                $('#myshare').removeClass('openshare');
                $('header, footer, .pt, .scroll_plus{if !$headershow}, .scroll_openmenu{/if}').removeClass('onlypage');
				<!--{else}-->
				$('.share_browser').hide();
				clearTimeout(shareclosetime);
                <!--{/if}-->
                $(this).hide();
            });
        });	
	<!--{if $allowpostreply && $post['allowcomment'] && $_G['setting']['commentnumber']}-->
	$(document).on('click', '.formsdialog', function() {
		popup.open('<div class="lmVdjV39q3EP"></div>');
		var obj = $(this);
		var formobj = $(this.form);
		$.ajax({
			type:'POST',
			url:formobj.attr('action') + '&handlekey='+ formobj.attr('id') +'&inajax=1',
			data:formobj.serialize(),
			dataType:'xml'
		})
				.success(function(s) {
					$(".trade_comment_box").load(location.href + " .trade_comment_list");
					popup.open();
				})
				.error(function() {
					window.location.href = obj.attr('href');
					popup.close();
				});
		return false;
	});
	<!--{/if}-->
</script>
<!--{$ajaxsubmit_item}-->
<!--{block footerplus}--><div class="a87wGthEpSmH"></div><!--{/block}-->
<!--{eval $nofooter = true;}-->
<!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck}-->
<!--{block scrollplus}-->
<div class="w1qg3pi8Q2H1"><a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1" class="NhU32Wlw1xbd"><i></i></a></div>
<!--{/block}-->
<!--{/if}-->
<!--{template common/footer}-->