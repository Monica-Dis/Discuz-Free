<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}-->{lang pay_attachment}{lang pay_view}<!--{/block}-->
<!--{template common/header}-->
<!--{if $_G['inajax']}-->
<div class="ajaxpop">
			<!--{if $loglist}-->
            <h3 class="paylist_tt">
            {lang attachment_buy}{lang pay_view}
            <em><a href="forum.php?mod=misc&action=viewattachpayments&aid=$aid" >{lang more}</a></em>
            </h3>
            <div class="paylist_view">
			<table cellspacing="0" cellpadding="0">
                <!--{loop $loglist $log}-->
                    <tr>
						<td><a href="home.php?mod=space&uid=$log[uid]">$log[username]</a></td>
						<td class="fz5">$log[dateline]</td>
						<td>{$log[$extcreditname]} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</td>
					</tr>
                <!--{/loop}-->                
			</table>
            </div>
			<!--{else}-->
			<div class="r-block shen bbno">{lang attachment_buy_not}</div>
			<!--{/if}-->   
</div>
<!--{else}-->
<div class="bw">
			<!--{if $loglist}-->
            <div class="paylist_view paylist_noajax">
			<table cellspacing="0" cellpadding="0">
				<tr>
					<th>{lang username}</th>
					<th>{lang time}</th>
					<th>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</th>
				</tr>
                <!--{loop $loglist $log}-->
                    <tr>
						<td><a href="home.php?mod=space&uid=$log[uid]">$log[username]</a></td>
						<td>$log[dateline]</td>
						<td>{$log[$extcreditname]}</td>
					</tr>
                <!--{/loop}-->                 
            </table>
            </div>
            <!--{else}-->
			<div class="r-block">{lang attachment_buy_not}</div>
			<!--{/if}-->
</div>
<!--{/if}-->

<!--{template common/footer}-->