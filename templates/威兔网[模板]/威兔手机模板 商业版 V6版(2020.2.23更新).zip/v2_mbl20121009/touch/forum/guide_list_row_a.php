<?php echo 'From: DisM.taobao.com';exit;?>
				<!--{if $list['threadcount']}-->
					<ul id="alist" class="HwKFWtPXAVEl">
					<!--{loop $list['threadlist'] $key $thread}-->
                    <!--{eval $imgnumber = 1;}-->
                    <!--{eval include(DISCUZ_ROOT.'./template/v2_mbl20121009/touch/mytpl/threadlist.php');}-->
					<li class="uJYyfGzLxp7x">
					<a href="forum.php?mod=viewthread&tid=$thread[tid]&fromguid=hot&{if $_GET['archiveid']}archiveid={$_GET['archiveid']}&{/if}extra=$extra" class="th_item{if !$thread['thumb']} nopic{/if}">
					<!--{if !$thread['forumstick'] && $thread['closed'] > 1 && ($thread['isgroup'] == 1 || $thread['fid'] != $_G['fid'])}-->
					<!--{eval $thread[tid]=$thread[closed];}-->
					<!--{/if}-->
                    <!--{if $thread['thumbfirst']}-->
                    <!--{eval $imagethumb = getforumimg($thread['thumbfirst'], 0, 200, 150); }-->
                    <span class="eV6QZvlP57vk"><img src="$imagethumb" /></span>
                    <!--{/if}-->  
                    <h1>
                    <!--{if $thread['displayorder'] > 0}--> 
                    <em class="{if $thread['displayorder'] == 1}pin1{elseif $thread['displayorder'] == 2}pin2{else}pin3{/if}">$langplus[top]</em> &middot; 
                    <!--{/if}-->
					<!--{if $thread['digest'] > 0}-->
					<em class="GR92yicG3zyZ">$langplus[digest]</em> &middot; 
					<!--{/if}-->
                    $thread[subject]
                    </h1>
                    <div class="hNOK3poJcpFf">                    
                    <span>{$list['forumnames'][$thread[fid]]['name']}</span>
                    <span>{$thread[dateline]}</span> 
                    <!--{if $thread[replies]}-->                 
                    <!--{if $thread[replies] > 9999 }-->
                    <!--{eval $thread[replies] = round($thread[replies] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{else}-->                    
                    <!--{if $thread['isgroup'] != 1}--> 
                    <!--{if $thread[views] > 9999 }-->
                    <!--{eval $thread[views] = round($thread[views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{else}-->                    
                    <!--{if $groupnames[$thread[tid]][views] > 9999 }-->
                    <!--{eval $groupnames[$thread[tid]][views] = round($groupnames[$thread[tid]][views] / 10000 , 1).$langplus[tenthousand];}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->                    
                    <span class="99u2LxYcMOhO"><!--{if $thread[replies]}-->{$thread[replies]}{lang join_thread}<!--{else}--><!--{if $thread['isgroup'] != 1}-->{$thread[views]}<!--{else}-->{$groupnames[$thread[tid]][views]}<!--{/if}-->{$langplus[view]}<!--{/if}--></span>                    
                    </div>
                    </a>
					</li>
					<!--{/loop}-->                    
					</ul>
				<!--{else}-->
					<div class="sqK9gG26iUGb">{lang guide_nothreads}</div>
				<!--{/if}-->