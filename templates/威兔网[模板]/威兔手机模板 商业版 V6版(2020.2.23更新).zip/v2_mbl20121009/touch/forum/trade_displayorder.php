<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<div class="tip">
<script type="text/javascript" reload="1">
	var max_obj = {$_G['group']['tradestick']};
	var p = $stickcount;
	function checkbox(obj) {
		if(obj.checked) {
			p++;
			for (var i = 0; i < $('tradeform').elements.length; i++) {
				var e = tradeform.elements[i];
				if(p == max_obj) {
					if(e.name.match('stick') && !e.checked) {
						e.disabled = true;
					}
				}
			}
		} else {
			p--;
			for (var i = 0; i < $('tradeform').elements.length; i++) {
				var e = tradeform.elements[i];
				if(e.name.match('stick') && e.disabled) {
					e.disabled = false;
				}
			}
		}
	}
</script>
<form id="tradeform" method="post" autocomplete="off" action="forum.php?mod=misc&action=tradeorder&tid=$_G[tid]&tradesubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
		<div class="trade_mod_form">
			<table cellspacing="0" cellpadding="0">
				<thead>
					<tr>
						<td>{lang displayorder}</td>
						<td>{lang trade_update_stick}</td>
						<th>{lang post_trade_name}</th>
						<td></td>
					</tr>
				</thead>
			</table>
			<div class="trade_mod_list">
			<table cellspacing="0" cellpadding="0">
				<!--{loop $trades $trade}-->
				<tr>
					<td><input size="1" name="displayorder[{$trade[pid]}]" value="$trade[displayorderview]" class="trade_mod_ord" /></td>
					<td><input type="checkbox" onclick="checkbox(this)" name="stick[{$trade[pid]}]" value="yes" {if $trade[displayorder] > 0}checked="checked"{elseif $_G['group']['tradestick'] <= $stickcount}disabled="disabled"{/if} /></td>
					<th><div>$trade[subject]</div></th>
					<td class="trade_mod_editbtn"><a href="forum.php?mod=post&action=edit&fid=$thread[fid]&tid=$_G[tid]&pid=$trade[pid]">{lang edit}</a></td>
				</tr>
				<!--{/loop}-->
			</table>
			</div>
			<div class="warningmessage">{lang trade_update_stickmax} {$_G['group']['tradestick']}</div>
		</div>
	<div class="hm tb"><button tabindex="1" class="formdialog button2" type="submit" name="tradesubmit" value="true">{lang save}</button></div>
</form>
<script type="text/javascript" reload="1">
function succeedhandle_$_GET['handlekey'](locationhref) {
	location.href = locationhref;
}
</script>
</div>

<!--{template common/footer}-->