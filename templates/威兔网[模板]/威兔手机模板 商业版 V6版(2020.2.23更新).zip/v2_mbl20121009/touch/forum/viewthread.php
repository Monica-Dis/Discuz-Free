<?php echo 'From: DisM.taobao.com';exit;?>
<!--{block header_name}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">{$_G['forum']['name']}</a><!--{/block}-->
<!--{template common/header}-->
<!--{if helper_access::check_module('follow') && $tplfollows && $_G['fid'] == $tplfollows}-->
<!--{eval dheader("Location: home.php?mod=follow");exit;}-->
<!--{/if}-->
<!--{hook/viewthread_top_mobile}-->
<!--{if in_array($_G['fid'],(array)unserialize($viewvideos))}-->
<!--{template forum/viewthread_b}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($viewmusics))}-->
<!--{template forum/viewthread_c}-->
<!--{elseif in_array($_G['fid'],(array)unserialize($viewstors))}-->
<!--{template forum/viewthread_d}-->
<!--{else}-->
<!--{template forum/viewthread_a}-->
<!--{/if}-->
<!--{if !$nofooter && $footershow}-->
<!--{template touch/mytpl/menubottom}-->
<!--{/if}-->
<!--{template common/footer}-->