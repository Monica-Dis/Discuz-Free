<?php echo 'From: DisM.taobao.com';exit;?>
{eval
function tpl_hide_credits_hidden($creditsrequire) {
global $_G;
}
<!--{block return}--><div class="locked"><!--{if $_G[uid]}-->{$_G[username]}<!--{else}-->{lang guest}<!--{/if}-->{lang post_hide_credits_hidden}</div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_hide_credits($creditsrequire, $message) {
}
<!--{block return}--><div class="locked">{lang post_hide_credits}</div>
$message<br /><br />
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_codedisp($code) {
}
<!--{block return}--><div class="blockcode"><div><ol><li>$code</ol></div></div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_quote() {
}
<!--{block return}--><div class="quote"><blockquote>{lang e_quote}: \\1</blockquote></div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_free() {
}
<!--{block return}--><div class="quote"><blockquote>\\1</blockquote></div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_hide_reply() {
global $_G;
}
<!--{block return}--><div class="showhide"><h4>{lang post_hide}</h4>\\1</div>
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function tpl_hide_reply_hidden() {
global $_G;
}
<!--{block return}--><div class="locked"><!--{if $_G[uid]}-->{$_G[username]}<!--{else}-->{lang guest}<!--{/if}-->{lang post_hide_reply_hidden}</div><!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function attachlist($attach) {
global $_G;
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G[forum_thread][archiveid] : '';
}
<!--{block return}-->
<div class="attach_item">		
     <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
		$attach[attachicon]
     <!--{/if}-->
		<p class="attach_names">
			<!--{if !$attach['price'] || $attach['payed']}-->
				<a href="forum.php?mod=attachment{$is_archive}&aid=$aidencode" id="aid$attach[aid]"><i class="vt-downloads"></i>$attach[filename]</a>
			<!--{else}-->
				<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]"{if $_G[uid]} class="dialog"{/if}>$attach[filename]</a>
			<!--{/if}-->
			<span class="qian">&nbsp;&nbsp;{$attach[dateline]} {lang upload}</span>
		</p>
        <!--{if $attach['description']}--><p class="qian">{$attach[description]}</p><!--{/if}-->
		<p class="qian">{$attach[attachsize]}, {lang downloads}: {$attach[downloads]}<!--{if $attach['readperm']}-->, {lang readperm}: {$attach[readperm]}<!--{/if}--><!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->, {lang attachcredits}: {$_G[getattachcredits]}<!--{/if}--></p>
        <!--{if $attach['price']}-->
        <p class="attach_price">
        <span class="orange">{lang price}: $attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</span>		
		&nbsp;&nbsp;<a href="forum.php?mod=misc&action=viewattachpayments&aid=$attach[aid]" class="dialog" >{lang pay_view}</a>
		<!--{if !$attach['payed']}-->
		&nbsp;&nbsp;<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" class="attachment_buy{if $_G[uid]} dialog{/if}">{lang attachment_buy}</a>
		<!--{/if}-->
		</p>
     <!--{/if}-->
</div>
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function imagelist($attach) {
global $_G;
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$mobilethumburl = $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) ? getforumimg($attach['aid'], 0, 3000, 0, 'fixnone') : '' ;
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? '&fid='.$_G['fid'].'&archiveid='.$_G[forum_thread][archiveid] : '';
}
<!--{block return}-->
	<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) }-->			
				<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
				<div class="img_item">
                <!--{if !$attach['price'] || $attach['payed']}-->
                <a href="forum.php?mod=viewthread&tid=$attach[tid]&aid=$attach[aid]&from=album&page=$_G[page]" class="orange"><img id="aimg_$attach[aid]" src="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" /></a>                
                <!--{else}-->                
				<div class="attach_item img_buy">
                $attach[attachicon]
                <p class="attach_names">
                <a href="javascript:;" >{lang attachment_buy}{lang image}</a>
                <span class="qian">&nbsp;&nbsp;{$attach[dateline]} {lang upload}</span>
                </p>
                <!--{if $attach[description]}--><p class="qian">$attach[description]</p><!--{/if}--> 
                <p class="qian">{$attach[attachsize]}, {lang downloads}: {$attach[downloads]}<!--{if $attach['readperm']}-->, {lang readperm}: {$attach[readperm]}<!--{/if}--><!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->, {lang attachcredits}: {$_G[getattachcredits]}<!--{/if}--></p>               
                <!--{if $attach['price']}-->
                <p class="attach_price">
                <span class="orange">{lang price}: $attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</span>
                &nbsp;&nbsp;<a href="forum.php?mod=misc&action=viewattachpayments&aid=$attach[aid]" class="dialog">{lang pay_view}</a>
                <!--{if !$attach['payed']}-->
                &nbsp;&nbsp;<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" class="attachment_buy{if $_G[uid]} dialog{/if}">{lang attachment_buy}</a>
                <!--{/if}-->
                </p>
                <!--{/if}-->
                </div>
                <!--{/if}-->                
				</div>                
				<!--{/if}-->
	<!--{/if}-->
<!--{/block}-->
<!--{eval return $return;}-->
{eval
}

function attachinpost($attach) {
global $_G;
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$mobilethumburl = $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) ? getforumimg($attach['aid'], 0, 3000, 0, 'fixnone') : '' ;
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? '&fid='.$_G['fid'].'&archiveid='.$_G[forum_thread][archiveid] : '';
}
<!--{block return}-->
	<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid'])}-->
		<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
		<div class="img_insert">
        <a href="forum.php?mod=viewthread&tid=$attach[tid]&aid=$attach[aid]&from=album&page=$_G[page]" class="orange"><img id="aimg_$attach[aid]" src="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" /></a>
        <!--{if $attach[description]}--><div class="img_describe">$attach[description]</div><!--{/if}-->
        </div>        
		<!--{/if}-->
	<!--{else}-->		
		<div id="attach_$attach[aid]" class="attach_item">        
			<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
			$attach[attachicon]
			<!--{/if}-->
            <p class="attach_names">
			<!--{if !$attach['price'] || $attach['payed']}-->
				<a href="forum.php?mod=attachment{$is_archive}&aid=$aidencode" id="aid$attach[aid]"><i class="vt-downloads"></i>$attach[filename]</a>
			<!--{else}-->
				<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]"{if $_G[uid]} class="dialog"{/if}>$attach[filename]</a>
			<!--{/if}-->
			<span class="qian">&nbsp;&nbsp;{$attach[dateline]} {lang upload}</span>
            </p>
            <!--{if $attach['description']}--><p class="qian">{$attach[description]}</p><!--{/if}-->
			<p class="qian">{$attach[attachsize]}, {lang downloads}: {$attach[downloads]}<!--{if $attach['readperm']}-->, {lang readperm}: {$attach[readperm]}<!--{/if}--><!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->, {lang attachcredits}: {$_G[getattachcredits]}<!--{/if}--></p>
        <!--{if $attach['price']}-->
        <p class="attach_price">
        <span class="orange">{lang price}: $attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}</span>		
		&nbsp;&nbsp;<a href="forum.php?mod=misc&action=viewattachpayments&aid=$attach[aid]" class="dialog" >{lang pay_view}</a>
		<!--{if !$attach['payed']}-->
		&nbsp;&nbsp;<a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" class="attachment_buy{if $_G[uid]} dialog{/if}">{lang attachment_buy}</a>
		<!--{/if}-->        
		</p>
     <!--{/if}-->			
		</div>		
	<!--{/if}-->
<!--{/block}-->
<!--{eval return $return;}-->
<!--{eval
}

}-->
