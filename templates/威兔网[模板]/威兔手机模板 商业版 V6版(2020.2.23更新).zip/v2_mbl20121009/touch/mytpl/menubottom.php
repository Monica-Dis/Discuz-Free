<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G['basescript'] == 'forum' && CURMODULE == forumdisplay }-->
<!--{block bottombutton}-->
<ul>
    <!--{if $tplwapurl}-->
    <li><a href="forum.php"><i class="vYwrd8Li1T3q"></i>{$langplus[home]}</a></li>
    <li class="Yfm1QC5IeoTk"><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>{$langplus[bbs]}</a></li>
    <!--{else}-->
    <li class="Yfm1QC5IeoTk"><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>{$langplus[bbs]}</a></li>
    <li><a href="forum.php?mod=guide&view=newthread"><i class="2BNmEfaRrZB2"></i>{$langplus[guide]}</a></li>
    <!--{/if}-->
    <li><div class="lkzxUSeCuNPo"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="i0a6HFurbhHA"><!--{if $footerbib}--><!--{$footerbib}--><!--{else}--><i class="RtBILaDhl45b"></i><!--{/if}--></a></div></li>
    <!--{$footerfour}-->
    <li>
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
        <a href="member.php?mod=logging&action=login"><i class="0iHKtK6RqXLZ"></i>{lang login}</a>
        <!--{else}-->
        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="0iHKtK6RqXLZ"></i>$langplus[me]</a>
        <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="Iug1I7rXnrOf"></i><!--{/if}-->
        <!--{/if}-->
    </li>
</ul>
<!--{$ajaxsubmit_item}-->
<!--{/block}-->
<!--{elseif $_G['basescript'] == 'forum' && CURMODULE == viewthread || $_G['basescript'] == 'group' && CURMODULE == viewthread }-->
<!--{block bottombutton}-->
<ul>
    <li class="fastbtn{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}{if !empty($_G['setting']['recommendthread']['addtext'])} supportbtn{/if}{/if}"><span class="GddXLGiN3F9i">{$langplus[sayaword]}</span></li>
    <li><a href="javascript:;" class="go_reply"><i class="4TtPW6YVzyiQ"></i>{$langplus[reply]}</a><!--{if $_G[forum_thread][allreplies] > 0}-->
        <!--{if $_G[forum_thread][allreplies] > 9999 }-->
        <!--{eval $_G[forum_thread][allreplies] = round($_G[forum_thread][allreplies] / 10000 , 1).$langplus[tenthousand];}-->
        <!--{/if}-->
        <i class="r7wK0yKft2oO">{$_G[forum_thread][allreplies]}</i>
        <!--{/if}-->
    </li>
    <li>
        <!--{eval $favstate = C::t('home_favorite')->fetch_by_id_idtype($_G['tid'],'tid',$_G['uid']);}-->
        <!--{if $favstate && $_G['uid']}-->
        <a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="DEpWPCcOgRkB"><i class="yUHLv4Ewx6zR"></i>{$langplus[favorite]}</a>
        <!--{else}-->
        <a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}" class="un5EcQmZbb1B" ><i class="quKOCKMOWfuc"></i>{$langplus[favorite]}</a>
        <!--{/if}-->
    </li>
    <!--{if (($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']) && (!empty($_G['setting']['recommendthread']['addtext']))}-->
    <!--{if $_G[forum_thread][recommend_add] > 9999 }-->
    <!--{eval $_G[forum_thread][recommend_add] = round($_G[forum_thread][recommend_add] / 10000 , 1).$langplus[tenthousand];}-->
    <!--{/if}-->
    <li><i class="r7wK0yKft2oO"{if !$_G['forum_thread']['recommend_add']} style="display:none;"{/if}><!--{if $_G['forum_thread']['recommend_add']}-->{$_G[forum_thread][recommend_add]}<!--{/if}--></i><a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" class="XWTawCWl7NJU"><i class="D3C2riF7L489"></i>{$langplus[support]}</a></li>
    <!--{/if}-->
    <li><a href="javascript:;" id="fshare"><i class="K8kYuvxODrq6"></i>{$langplus[share]}</a></li>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#fshare').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').addClass('weixinshare');
                $('.close_s1').show();
                <!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false}-->
                $('#myshare').addClass('openshare');
                $('header, footer, .pt, .scroll_plus{if !$headershow}, .scroll_openmenu{/if}').addClass('onlypage');
                $('.close_s').show();
                <!--{else}-->
                $('.share_browser').fadeIn();
                $('.close_s').show();
                shareclosetime = setTimeout(function(){
                    $('.share_browser, .close_s').hide()
                    },4000);
                <!--{/if}-->
            });
            $('.close_s, .close_s1').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').removeClass('weixinshare');
                <!--{elseif strpos($_SERVER['HTTP_USER_AGENT'], 'UCBrowser') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'MQQBrowser') !== false}-->
                $('#myshare').removeClass('openshare');
                $('header, footer, .pt, .scroll_plus{if !$headershow}, .scroll_openmenu{/if}').removeClass('onlypage');
                <!--{else}-->
                $('.share_browser').hide();
                clearTimeout(shareclosetime);
                <!--{/if}-->
                $(this).hide();
            });
        });
    </script>
</ul>
<script type="text/javascript">	
$(document).ready(function(){	
	$('.fastreply, .sofareply{if $_G[forum_thread][allreplies] <= 0 || $page > 1 || in_array($_G['fid'],(array)unserialize($viewvideos)) || in_array($_G['fid'],(array)unserialize($viewmusics))}, .go_reply{/if}').click(function(){
		<!--{if $allowfastpost}-->
		$('.postbox').slideToggle();
		$('.close_p').delay(300).fadeIn();
		<!--{else}-->
		<!--{if !$_G[uid] || $_G[uid] && !$allowpostreply}-->
		<!--{if !$_G[uid]}-->
		popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
		<!--{else}-->
		popup.open('{lang nopostreply}', 'alert');
		<!--{/if}-->
		this.blur();
		<!--{else}-->
		$('.postbox').slideToggle();
		$('.close_p').delay(300).fadeIn();
		<!--{/if}-->
		<!--{/if}-->
	}); 
	<!--{if $_G[forum_thread][allreplies] > 0 && $page <= 1 && !in_array($_G['fid'],(array)unserialize($viewvideos)) && !in_array($_G['fid'],(array)unserialize($viewmusics))}-->
	$(".go_reply").on("click",function(){
		$("html,body").animate({scrollTop:$("#ap_reply").offset().top},500)
	});
	<!--{/if}-->	
	$('.close_p').click(function(){	
		$('.postbox').slideToggle();
		$('.editordefault a').removeClass('on');
		$('.hidebox').slideUp();
		$(this).hide();
	});  
});	
</script>
<!--{$ajaxsubmit_item}-->
<!--{/block}-->
<!--{/if}-->