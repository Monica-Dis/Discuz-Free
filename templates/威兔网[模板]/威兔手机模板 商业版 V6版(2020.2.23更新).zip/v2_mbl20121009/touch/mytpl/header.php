<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{subtemplate touch/common/header_system}-->
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0" />
    <!--{if $fullscreen}-->
    <meta name="full-screen" content="yes" />
    <meta name="x5-fullscreen" content="true" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-capable"content="no" />
    <!--{/if}-->
    <meta name="apple-touch-fullscreen" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black" />
    <meta name="format-detection" content="telephone=no" />
    <meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
    <meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
    <title><!--{if !empty($navtitle)}-->$navtitle<!--{/if}--><!--{if empty($nobbname)}--> - $_G['setting']['bbname']<!--{/if}--></title>
    <base href="{$_G['siteurl']}" />
    <link rel="stylesheet" href="template/v2_mbl20121009/touch_plus/css/vtoo.style.css?{VERHASH}" type="text/css" media="all">
    <link rel="stylesheet" href="template/v2_mbl20121009/touch_plus/css/style.{$tplstylecss}.css?{VERHASH}" type="text/css" media="all">
    <style type="text/css">
        .header { background-color:{$tplcolorcssa};}
        .header .new, .sidequickmenu a i { color:{$tplcolorcssa}; }
        .header .new { background:{$tplcolorcssc}; }
        .header, .header a { color:{$tplcolorcssc}; }
        .footer li a { color:{$tplcolorcssd}; }
        .sstbg, .button, .button2, .button4, .button5, .forum_left li.on:after, .tabequal li.a a:after, .tabequal li.on a:after, .tabequal_2 li.a a:after, .slidemenu .a a:after, .viewforum .on:after { background-color: {$tplcolorcssb}; }
        a.sstcl, .footer li.onindexs a, .footer li.on a, .tabequal li.a a, .tabequal li.on a, .tabequal_2 li.a a, .slidemenu li.a a, .btnon, .forum_left li.on, .reg_link a, .forumname h1 a, .viewforum .on, .rolldate-container .rolldate-confirm { color:{$tplcolorcssb}; }
        .hideview { height:{$viewheight}px;}
        .message, .follow_box, .home_mess { font-size:{$viewfontsize}px;}
        .keyht { padding-top:150px; }
        .keyht2 { padding-top:150px; }
        <!--{$tplcssdiy}-->
        <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'Firefox') !== false }-->
        .selectstyle select { padding-left:1px; }
        .profile .privacy select { padding-left:4px; }
        <!--{/if}-->
    </style>
    <link rel="apple-touch-icon-precomposed" href="{$_G['siteurl']}/template/v2_mbl20121009/touch_plus/image/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="{$_G['siteurl']}/template/v2_mbl20121009/touch_plus/image/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon-precomposed" sizes="171x171" href="{$_G['siteurl']}/template/v2_mbl20121009/touch_plus/image/apple-touch-icon-171x171.png">
    <script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/jquery.js?{VERHASH}"></script>
    <script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]', language = {'loading':'{$langplus[load]}', 'view_more': '{$langplus[more]}', 'view_content': '{$langplus[allcontent]}'};</script>
    <script type="text/javascript" src="template/v2_mbl20121009/touch_plus/js/common_{$characterset}.js?{VERHASH}" charset="{CHARSET}"></script>
</head>
<body class="pg_{CURMODULE}{if $_G['basescript'] === 'portal'} p_{$cat[catid]}{elseif $_G['basescript'] === 'forum'} f_{if $_G[fid]}{$_G[fid]}{else}0{/if}{elseif $_G['basescript'] === 'group'} g_{$_G[fid]}{/if}">
<!--{if $_G['basescript'] != member }-->
<!--{if $nologintplplus == 1}-->
<!--{if !$_G[uid] && !$_G['connectguest']}--><!--{$tplplusa}--><!--{/if}-->
<!--{else}-->
<!--{$tplplusa}-->
<!--{/if}-->
<!--{/if}-->
<div>