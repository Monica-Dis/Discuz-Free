<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $msgnumber;
	global $imgnumber;
	global $recnumber;
	global $postnumber;
	global $imgpostfirst;
	global $imgexternal;
	global $eximgurls;
	global $thread;
	global $recommends_add;
	global $postlist;
	global $wearehores;
	global $hidesummary;
	if ($wearehores != "okmaxs") {
		return 0;
	}
	if ($msgnumber && !$hidesummary) {
		require_once libfile("function/post");
		$thread["msg"] = DB::result_first("SELECT message FROM " . DB::table("forum_post") . " where tid='" . $thread["tid"] . "' and first=1 limit 1");
		$thread["msg"] = messagecutstr($thread["msg"], $msgnumber);
		$thread["msg"] = str_replace(array("\r\n", "\r", "\n"), '', $thread["msg"]);
	}
	if ($imgnumber) {
		if ($imgpostfirst) {
			$thread["pid"] = DB::result_first("SELECT pid FROM " . DB::table("forum_post") . " WHERE tid = " . $thread["tid"] . " and first=1 LIMIT 1");
			$thread["thumb"] = DB::fetch_all("SELECT aid FROM " . DB::table("forum_attachment_" . substr($thread["tid"], -1, 1)) . " WHERE pid = " . $thread["pid"] . " and width>0 order by dateline asc LIMIT 0 ," . $imgnumber);
			$thread["thumbfirst"] = DB::result_first("SELECT aid FROM " . DB::table("forum_attachment_" . substr($thread["tid"], -1, 1)) . " WHERE pid =" . $thread["pid"] . " and width>0 order by dateline asc LIMIT 0 , " . $imgnumber);
		} else {
			$thread["thumb"] = DB::fetch_all("SELECT aid FROM " . DB::table("forum_attachment_" . substr($thread["tid"], -1, 1)) . " WHERE tid = " . $thread["tid"] . " and width>0 order by dateline asc LIMIT 0 ," . $imgnumber);
			$thread["thumbfirst"] = DB::result_first("SELECT aid FROM " . DB::table("forum_attachment_" . substr($thread["tid"], -1, 1)) . " WHERE tid =" . $thread["tid"] . " and width>0 order by dateline asc LIMIT 0 , " . $imgnumber);
		}
		if ($imgexternal && (!$thread["thumb"] || !$thread["thumbfirst"])) {
			$thread["msgpic"] = DB::result_first("SELECT message FROM " . DB::table("forum_post") . " where tid='" . $thread["tid"] . "' and first=1 limit 1");
			preg_match_all("/\\[img.*?\\](.*?)\\[\\/img\\]/is", $thread["msgpic"], $_var_12);
			$eximgurls = array_slice($_var_12[1], 0, $imgnumber);
		}
	}
	$thread["groupid"] = DB::result_first("SELECT groupid FROM " . DB::table("common_member") . " WHERE uid = " . $thread["authorid"]);
	if ($recnumber && $postnumber) {
		if ($hidesummary) {
			require_once libfile("function/post");
		}
		$recommends_add = DB::fetch_all("SELECT recommenduid FROM " . DB::table("forum_memberrecommend") . " WHERE tid=" . $thread["tid"] . " LIMIT " . $recnumber);
		$postlist = DB::fetch_all("SELECT author, authorid, message FROM " . DB::table("forum_post") . " WHERE tid=" . $thread["tid"] . " and first != 1 and invisible = 0 order by dateline desc LIMIT " . $postnumber);
	}