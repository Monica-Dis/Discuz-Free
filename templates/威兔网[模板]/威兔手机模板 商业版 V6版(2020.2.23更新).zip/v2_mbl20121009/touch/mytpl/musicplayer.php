<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $thread;
	global $mediaplayer;
	global $wearehores;
	global $msgnumber;
	global $imgnumber;
	global $imgpostfirst;
	global $listplaying;
	global $viewplaying;
	global $viewcovertype;
	global $threadsortshow;
	global $imagethumb;
	global $viewbgcover;
	if ($wearehores != "okmaxs") {
		return 0;
	}
	if ($msgnumber) {
		require_once libfile("function/post");
		$thread["msg"] = DB::result_first("SELECT message FROM " . DB::table("forum_post") . " where tid='" . $thread["tid"] . "' and first=1 limit 1");
		$thread["msg"] = messagecutstr($thread["msg"], $msgnumber);
		$thread["msg"] = str_replace(array("\r\n", "\r", "\n"), '', $thread["msg"]);
	}
	if ($imgnumber) {
		$thread["pid"] = DB::result_first("SELECT pid FROM " . DB::table("forum_post") . " WHERE tid = " . $thread["tid"] . " and first=1 LIMIT 1");
		$thread["thumbfirst"] = DB::result_first("SELECT aid FROM " . DB::table("forum_attachment_" . substr($thread["tid"], -1, 1)) . " WHERE pid =" . $thread["pid"] . " and width>0 LIMIT 0 , " . $imgnumber);
		if ($viewplaying) {
			$viewbgcover = '';
			$imagethumb = '';
			if ($viewcovertype) {
				if (!strstr($_G["forum_option"]["songimg"]["value"], "nophoto.gif")) {
					if ($threadsortshow["typetemplate"]) {
						$viewbgcover = $_G["forum_option"]["songimg"]["value"];
						$imagethumb = $viewbgcover;
					} else {
						$viewbgcover = explode("<a href=\"", $_G["forum_option"]["songimg"]["value"]);
						$viewbgcover = explode("\"", $viewbgcover[1]);
						$viewbgcover = $viewbgcover[0];
						$imagethumb = $viewbgcover;
					}
				} else {
					if ($_G["forum_option"]["songeximg"]["value"]) {
						$viewbgcover = $_G["forum_option"]["songeximg"]["value"];
						$imagethumb = $viewbgcover;
					} else {
						if ($thread["thumbfirst"]) {
							$viewbgcover = getforumimg($thread["thumbfirst"], 0, 400, 240);
							$imagethumb = getforumimg($thread["thumbfirst"], 0, 240, 240);
						}
					}
				}
			} else {
				if ($thread["thumbfirst"]) {
					$viewbgcover = getforumimg($thread["thumbfirst"], 0, 400, 240);
					$imagethumb = getforumimg($thread["thumbfirst"], 0, 240, 240);
				} else {
					if ($_G["forum_option"]["songeximg"]["value"]) {
						$viewbgcover = $_G["forum_option"]["songeximg"]["value"];
						$imagethumb = $viewbgcover;
					}
				}
			}
		} else {
			if ($listplaying) {
				$imagethumb = '';
				if ($viewcovertype) {
					if ($_G["optionvaluelist"][$thread["sortid"]][$thread["tid"]]["songimg"]["value"]) {
						$imagethumb = explode("src=\"", $_G["optionvaluelist"][$thread["sortid"]][$thread["tid"]]["songimg"]["value"]);
						$imagethumb = explode("\"", $imagethumb[1]);
						$imagethumb = $imagethumb[0];
					} else {
						if ($_G["optionvaluelist"][$thread["sortid"]][$thread["tid"]]["songeximg"]["value"]) {
							$imagethumb = $_G["optionvaluelist"][$thread["sortid"]][$thread["tid"]]["songeximg"]["value"];
						} else {
							if ($thread["thumbfirst"]) {
								$imagethumb = getforumimg($thread["thumbfirst"], 0, 120, 120);
							}
						}
					}
				} else {
					if ($thread["thumbfirst"]) {
						$imagethumb = getforumimg($thread["thumbfirst"], 0, 120, 120);
					} else {
						if ($_G["optionvaluelist"][$thread["sortid"]][$thread["tid"]]["songeximg"]["value"]) {
							$imagethumb = $_G["optionvaluelist"][$thread["sortid"]][$thread["tid"]]["songeximg"]["value"];
						}
					}
				}
			}
		}
	}
	$thread["messages"] = DB::result_first("SELECT message FROM " . DB::table("forum_post") . " where tid='" . $thread["tid"] . "' and first=1 limit 1");
	$thread["pid"] = DB::result_first("SELECT pid FROM " . DB::table("forum_post") . " where tid='" . $thread["tid"] . "' and first=1 limit 1");
	$_var_13 = C::t("forum_attachment_n")->fetch_all_by_id(getattachtableid($thread["tid"]), "pid", $thread["pid"]);
	preg_match_all("/\\[audio.*?\\](.*?)\\[\\/audio\\]/is", $thread["messages"], $_var_14);
	preg_match_all("/\\[media.*?\\](.*?)\\[\\/media\\]/is", $thread["messages"], $_var_15);
	$_var_14 = $_var_14[1][0];
	$_var_15 = $_var_15[1][0];
	if ($_var_14) {
		$_var_16 = $_var_14;
	} else {
		if ($_var_15) {
			$_var_16 = $_var_15;
		}
	}
	$mediaplayer = '';
	if ($_var_16) {
		if (strpos($_var_16, "163.com/song/") !== false) {
			$mediaplayer = explode("/song/", $_var_16);
			$mediaplayer = explode("/?userid=", $mediaplayer[1]);
			$mediaplayer = $mediaplayer[0];
			$mediaplayer = "https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3";
		} else {
			if (strpos($_var_16, "163.com/song?id=") !== false) {
				$mediaplayer = explode("/song?id=", $_var_16);
				$mediaplayer = explode("&userid=", $mediaplayer[1]);
				$mediaplayer = $mediaplayer[0];
				$mediaplayer = "https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3";
			} else {
				if (strpos($_var_16, "163.com/#/song?id=") !== false) {
					$mediaplayer = explode("/song?id=", $_var_16);
					$mediaplayer = $mediaplayer[1];
					$mediaplayer = "https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3";
				} else {
					if (strpos($_var_16, "163.com/m/song?id=") !== false) {
						$mediaplayer = explode("/song?id=", $_var_16);
						$mediaplayer = explode("&", $mediaplayer[1]);
						$mediaplayer = $mediaplayer[0];
						$mediaplayer = "https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3";
					} else {
						if (strpos($_var_16, "163.com/#/outchain/2") !== false) {
							$mediaplayer = explode("outchain/2/", $_var_16);
							$mediaplayer = explode("/", $mediaplayer[1]);
							$mediaplayer = $mediaplayer[0];
							$mediaplayer = "https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3";
						} else {
							if (strpos($_var_16, ".mp3") !== false || strpos($_var_16, ".wav") !== false) {
								$mediaplayer = $_var_16;
							}
						}
					}
				}
			}
		}
	} else {
		if ($_var_13) {
			$_var_17 = 0;
			foreach ($_var_13 as $_var_18) {
				if (stripos($_var_18["filename"], ".mp3") !== false || stripos($_var_18["filename"], ".wav") !== false) {
					if ($_var_17 == 1) {
						break;
					}
					$_var_19 = $_var_18["remote"] ? $_G["setting"]["ftp"]["attachurl"] : $_G["setting"]["attachurl"];
					$_var_19 = $_var_19 . "forum/" . $_var_18["attachment"];
					$mediaplayer = $mediaplayer . $_var_19;
					$_var_17 = $_var_17 + 1;
				}
			}
		}
	}