<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $thread;
	global $poll;
	global $trades;
	global $activitys;
	global $activityclose;
	global $remainders;
	global $debates;
	global $debaternum;
	global $allvotes;
	global $affirmvotes;
	global $negavotes;
	global $wearehores;
	if ($wearehores != "okmaxs") {
		return 0;
	}
	if ($thread["special"] == 1) {
		$thread["voters"] = DB::result_first("SELECT voters FROM " . DB::table("forum_poll") . " WHERE tid =" . $thread["tid"]);
		$thread["expiration"] = DB::result_first("SELECT expiration FROM " . DB::table("forum_poll") . " WHERE tid =" . $thread["tid"]);
		$_var_12 = DB::fetch_all("SELECT sum(votes) FROM " . DB::table("forum_polloption") . " WHERE tid =" . $thread["tid"]);
		$poll["total"] = current($_var_12[0]);
		if ($thread["expiration"]) {
			$_var_13 = $thread["expiration"] - TIMESTAMP;
			$thread["days"] = floor($_var_13 / 86400);
			$thread["hours"] = floor(($_var_13 - 86400 * $thread["days"]) / 3600);
			$thread["minutes"] = floor(($_var_13 - 86400 * $thread["days"] - 3600 * $thread["hours"]) / 60);
		}
	} else {
		if ($thread["special"] == 2) {
			$_var_14 = "subject,quality,totalitems,aid,price,costprice,credit,costcredit";
			$trades = DB::fetch_all("SELECT " . $_var_14 . " FROM " . DB::table("forum_trade") . " WHERE tid =" . $thread["tid"] . " and displayorder between 0 and 1 LIMIT 1");
			if (!$trades) {
				$trades = DB::fetch_all("SELECT " . $_var_14 . " FROM " . DB::table("forum_trade") . " WHERE tid =" . $thread["tid"] . " order by displayorder LIMIT 1");
			}
			$trades = $trades[0];
		} else {
			if ($thread["special"] == 4) {
				$_var_15 = "aid,starttimefrom,starttimeto,place,class,number,applynumber,expiration";
				$activitys = DB::fetch_all("SELECT " . $_var_15 . " FROM " . DB::table("forum_activity") . " WHERE tid =" . $thread["tid"] . " LIMIT 1");
				$activitys = $activitys[0];
				$activityclose = $activitys["expiration"] ? $activitys["expiration"] > TIMESTAMP ? 0 : ($activitys["expiration"] > TIMESTAMP ? 0 : 1) : 0;
				$remainders = $activitys["number"] - $activitys["applynumber"];
			} else {
				if ($thread["special"] == 5) {
					$_var_16 = "endtime,affirmdebaters,negadebaters,affirmvotes,negavotes,winner,affirmpoint,negapoint,umpirepoint";
					$debates = DB::fetch_all("SELECT " . $_var_16 . " FROM " . DB::table("forum_debate") . " WHERE tid =" . $thread["tid"] . " LIMIT 1");
					$debates = $debates[0];
					$debaternum = $debates["affirmdebaters"] + $debates["negadebaters"];
					$allvotes = $debates["affirmvotes"] + $debates["negavotes"];
					$affirmvotes = round($debates["affirmvotes"] / $allvotes * 100, 1);
					$negavotes = 100 - $affirmvotes;
				}
			}
		}
	}