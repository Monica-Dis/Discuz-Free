<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $vtslist;
	global $vtperpage;
	global $vtarticleday;
	global $vtonlypic;
	global $vtpostsorts;
	global $imgpostfirst;
	global $wearehores;
	if ($wearehores != "okmaxs") {
		return 0;
	}
	$vtarticleday = TIMESTAMP - 86400 * $vtarticleday;
	if ($vtpostsorts == 7) {
		$_var_8 = "rand()";
	} else {
		$_var_9 = array(1 => "lastpost", 2 => "dateline", 3 => "heats", 4 => "digest", 5 => "views", 6 => "replies");
		$_var_8 = $_var_9[$vtpostsorts];
		if ($imgpostfirst) {
			$_var_8 = $_var_8 == "dateline" ? "at.dateline DESC " : "at." . $_var_8 . " DESC";
		} else {
			$_var_8 = $_var_8 == "dateline" ? "dateline DESC " : '' . $_var_8 . " DESC";
		}
	}
	if ($imgpostfirst) {
		$_var_10 = DB::fetch_all("SELECT * FROM %t at LEFT JOIN %t ac ON at.tid=ac.tid WHERE at.fid IN(%n) AND at.tid not LIKE %n AND at.dateline>=" . $vtarticleday . " %i AND at.displayorder>=0 AND ac.first=1 ORDER BY %i LIMIT 0, %d", array("forum_thread", "forum_post", $_G["fid"], $_G["tid"], $vtonlypic ? "AND ac.attachment=2" : NULL, $_var_8, $vtperpage));
	} else {
		$_var_10 = DB::fetch_all("SELECT * FROM %t WHERE fid IN(%n) AND tid not LIKE %n AND dateline>=" . $vtarticleday . " %i AND displayorder>=0 ORDER BY %i LIMIT 0, %d", array("forum_thread", $_G["fid"], $_G["tid"], $vtonlypic ? "AND attachment=2" : NULL, $_var_8, $vtperpage));
	}
	foreach ($_var_10 as $_var_11) {
		if ($vtonlypic) {
			if ($imgpostfirst) {
				$_var_11["aid"] = DB::result_first("SELECT aid FROM " . DB::table("forum_attachment_" . substr($_var_11["tid"], -1, 1)) . " WHERE pid =" . $_var_11["pid"] . " and width>0 order by dateline asc LIMIT 0, 1");
			} else {
				$_var_11["aid"] = DB::result_first("SELECT aid FROM " . DB::table("forum_attachment_" . substr($_var_11["tid"], -1, 1)) . " WHERE tid =" . $_var_11["tid"] . " and width>0 order by dateline asc LIMIT 0, 1");
			}
			$_var_11["imagethumb"] = getforumimg($_var_11["aid"], 0, 200, 150);
		} else {
			$_var_11["imagethumb"] = "0";
		}
		$_var_11["dateline"] = dgmdate($_var_11["dateline"], "u");
		$vtslist[] = $_var_11;
	}