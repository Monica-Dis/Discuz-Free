<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $_G;
	global $thread;
	global $mediaplayer;
	global $langplus;
	global $wearehores;
	if ($wearehores != "okmaxs") {
		return 0;
	}
	$thread["messages"] = DB::result_first("SELECT message FROM " . DB::table("forum_post") . " where tid='" . $thread["tid"] . "' and first=1 limit 1");
	$thread["pid"] = DB::result_first("SELECT pid FROM " . DB::table("forum_post") . " where tid='" . $thread["tid"] . "' and first=1 limit 1");
	$_var_5 = C::t("forum_attachment_n")->fetch_all_by_id(getattachtableid($thread["tid"]), "pid", $thread["pid"]);
	preg_match_all("/\\[media.*?\\](.*?)\\[\\/media\\]/is", $thread["messages"], $_var_6);
	preg_match_all("/\\[audio.*?\\](.*?)\\[\\/audio\\]/is", $thread["messages"], $_var_7);
	$_var_6 = $_var_6[1][0];
	$_var_7 = $_var_7[1][0];
	if ($_var_6) {
		$_var_8 = $_var_6;
	} else {
		if ($_var_7) {
			$_var_8 = $_var_7;
		}
	}
	$mediaplayer = '';
	if ($_var_8) {
		if (strpos($_var_8, ".mp4") !== false || strpos($_var_8, ".mov") !== false || strpos($_var_8, ".attach") !== false) {
			$mediaplayer = "<div class=\"mediaplayer_video\"><video id=\"video_" . substr(md5($_var_8), 14, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" x5-playsinline webkit-playsinline playsinline ><source src=\"" . $_var_8 . "\" type=\"video/ogg\" /><source src=\"" . $_var_8 . "\" type=\"video/mp4\" />" . $langplus["nothtmltag"] . "</video></div>";
		} else {
			if (strpos($_var_8, ".mp3") !== false || strpos($_var_8, ".wav") !== false) {
				$mediaplayer = "<div class=\"mediaplayer_audio\"><audio src=\"" . $_var_8 . "\" id=\"audio_" . substr(md5($_var_8), 14, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" ><source src=\"" . $_var_8 . "\" type=\"audio/ogg\"><source src=\"" . $_var_8 . "\" type=\"audio/mpeg\">" . $langplus["nothtmltag"] . "</audio></div>";
			} else {
				if (strpos($_var_8, "video.qq.com") !== false) {
					$mediaplayer = explode("vid=", $_var_8);
					$mediaplayer = explode("&", $mediaplayer[1]);
					$mediaplayer = $mediaplayer[0];
					$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
				} else {
					if (strpos($_var_8, "imgcache.qq.com") !== false) {
						$mediaplayer = explode("vid=", $_var_8);
						$mediaplayer = explode("&", $mediaplayer[1]);
						$mediaplayer = $mediaplayer[0];
						$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
					} else {
						if (strpos($_var_8, "v.qq.com/x/page") !== false) {
							$mediaplayer = explode("x/page/", $_var_8);
							$mediaplayer = explode(".html", $mediaplayer[1]);
							$mediaplayer = $mediaplayer[0];
							$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
						} else {
							if (strpos($_var_8, "v.qq.com/x/cover") !== false) {
								$mediaplayer = explode("x/cover/", $_var_8);
								$mediaplayer = explode(".html", $mediaplayer[1]);
								$mediaplayer = explode("/", $mediaplayer[0]);
								$mediaplayer = $mediaplayer[1];
								$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
							} else {
								if (strpos($_var_8, "m.v.qq.com/play.html") !== false) {
									$mediaplayer = explode("vid=", $_var_8);
									$mediaplayer = $mediaplayer[1];
									$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
								} else {
									if (strpos($_var_8, "m.v.qq.com/cover") !== false) {
										$mediaplayer = explode("vid=", $_var_8);
										$mediaplayer = $mediaplayer[1];
										$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
									} else {
										if (strpos($_var_8, "m.v.qq.com/page") !== false) {
											$mediaplayer = explode(".html?ptag=", $_var_8);
											$mediaplayer = substr($mediaplayer[0], -11);
											$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
										} else {
											if (strpos($_var_8, "v.qq.com/iframe") !== false) {
												$mediaplayer = explode("vid=", $_var_8);
												$mediaplayer = $mediaplayer[1];
												$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
											} else {
												if (strpos($_var_8, "m.v.qq.com/play/play.html") !== false) {
													$mediaplayer = explode("vid=", $_var_8);
													$mediaplayer = explode("&ptag", $mediaplayer[1]);
													$mediaplayer = $mediaplayer[0];
													$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
												} else {
													if (strpos($_var_8, "yoo.qq.com/m/video.html") !== false) {
														$mediaplayer = explode("id=", $_var_8);
														$mediaplayer = explode("&hgptag", $mediaplayer[1]);
														$mediaplayer = $mediaplayer[0];
														$mediaplayer = "<iframe src=\"https://v.qq.com/iframe/player.html?vid=" . $mediaplayer . "&tiny=0&auto=0\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
													} else {
														if (strpos($_var_8, "youku.com/player.php") !== false) {
															$mediaplayer = explode("/sid/", $_var_8);
															$mediaplayer = explode("/v.swf", $mediaplayer[1]);
															$mediaplayer = $mediaplayer[0];
															$mediaplayer = "<iframe src=\"https://player.youku.com/embed/" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
														} else {
															if (strpos($_var_8, "player.youku.com") !== false) {
																$mediaplayer = explode("/embed/", $_var_8);
																$mediaplayer = explode("==", $mediaplayer[1]);
																$mediaplayer = $mediaplayer[0];
																$mediaplayer = "<iframe src=\"https://player.youku.com/embed/" . $mediaplayer . "==\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
															} else {
																if (strpos($_var_8, "v.youku.com") !== false) {
																	$mediaplayer = explode("v_show/id_", $_var_8);
																	$mediaplayer = explode(".html", $mediaplayer[1]);
																	$mediaplayer = $mediaplayer[0];
																	$mediaplayer = "<iframe src=\"https://player.youku.com/embed/" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																} else {
																	if (strpos($_var_8, "m.youku.com") !== false) {
																		$mediaplayer = explode("video/id_", $_var_8);
																		$mediaplayer = explode(".html", $mediaplayer[1]);
																		$mediaplayer = $mediaplayer[0];
																		$mediaplayer = "<iframe src=\"https://player.youku.com/embed/" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																	} else {
																		if (strpos($_var_8, "tudou.com/v") !== false) {
																			$mediaplayer = explode("/v/", $_var_8);
																			$mediaplayer = explode("==", $mediaplayer[1]);
																			$mediaplayer = $mediaplayer[0];
																			$mediaplayer = "<iframe src=\"https://player.youku.com/embed/" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																		} else {
																			if (strpos($_var_8, "bilibili.com") !== false) {
																				$_var_9 = "|(\\d+)|";
																				preg_match($_var_9, $_var_8, $_var_10);
																				$mediaplayer = $_var_10[1];
																				$mediaplayer = "<iframe src=\"https://player.bilibili.com/player.html?aid=" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																			} else {
																				if (strpos($_var_8, "my.tv.sohu.com") !== false) {
																					$mediaplayer = explode("/us/", $_var_8);
																					$mediaplayer = explode("/", $mediaplayer[1]);
																					$mediaplayer = explode(".shtml", $mediaplayer[1]);
																					$mediaplayer = $mediaplayer[0];
																					$mediaplayer = "<iframe src=\"https://tv.sohu.com/upload/static/share/share_play.html#" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																				} else {
																					if (strpos($_var_8, "tv.sohu.com/s/") !== false) {
																						if (strpos($_var_8, "bid=") !== false) {
																							$mediaplayer = explode("bid=", $_var_8);
																							$mediaplayer = explode("&", $mediaplayer[1]);
																							$mediaplayer = $mediaplayer[0];
																							$mediaplayer = "<iframe src=\"https://tv.sohu.com/s/sohuplayer/iplay.html?bid=" . $mediaplayer . "&autoplay=false&disablePlaylist=false\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																						} else {
																							if (strpos($_var_8, "vid=") !== false) {
																								$mediaplayer = explode("vid=", $_var_8);
																								$mediaplayer = explode("&", $mediaplayer[1]);
																								$mediaplayer = $mediaplayer[0];
																								$mediaplayer = "<iframe src=\"https://tv.sohu.com/s/sohuplayer/iplay.html?vid=" . $mediaplayer . "&autoplay=false&disablePlaylist=false\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																							}
																						}
																					} else {
																						if (strpos($_var_8, "m.tv.sohu.com/sugs") !== false) {
																							$mediaplayer = explode("sugs/sv", $_var_8);
																							$mediaplayer = explode(".shtml", $mediaplayer[1]);
																							$mediaplayer = $mediaplayer[0];
																							$mediaplayer = "<iframe src=\"https://tv.sohu.com/s/sohuplayer/iplay.html?bid=" . $mediaplayer . "&autoplay=false&disablePlaylist=false\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																						} else {
																							if (strpos($_var_8, "m.tv.sohu.com/svs") !== false) {
																								$mediaplayer = explode("svs/sv", $_var_8);
																								$mediaplayer = explode(".shtml", $mediaplayer[1]);
																								$mediaplayer = $mediaplayer[0];
																								$mediaplayer = "<iframe src=\"https://tv.sohu.com/s/sohuplayer/iplay.html?vid=" . $mediaplayer . "&autoplay=false&disablePlaylist=false\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																							} else {
																								if (strpos($_var_8, "m.tv.sohu.com") !== false) {
																									$mediaplayer = explode("/v", $_var_8);
																									$mediaplayer = explode(".shtml", $mediaplayer[1]);
																									$mediaplayer = $mediaplayer[0];
																									$mediaplayer = "<iframe src=\"https://tv.sohu.com/upload/static/share/share_play.html#" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																								} else {
																									if (strpos($_var_8, "m.56.com") !== false) {
																										$mediaplayer = explode("/v", $_var_8);
																										$mediaplayer = explode(".shtml", $mediaplayer[1]);
																										$mediaplayer = $mediaplayer[0];
																										$mediaplayer = "<iframe src=\"https://tv.sohu.com/upload/static/share/share_play.html#" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																									} else {
																										if (strpos($_var_8, "v.miaopai.com") !== false) {
																											$mediaplayer = explode("iframe?scid=", $_var_8);
																											$mediaplayer = explode("__", $mediaplayer[1]);
																											$mediaplayer = $mediaplayer[0];
																											$mediaplayer = "<iframe src=\"https://v.miaopai.com/iframe?scid=" . $mediaplayer . "__\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																										} else {
																											if (strpos($_var_8, "www.miaopai.com") !== false) {
																												$mediaplayer = explode("/show/", $_var_8);
																												$mediaplayer = explode("__", $mediaplayer[1]);
																												$mediaplayer = $mediaplayer[0];
																												$mediaplayer = "<iframe src=\"https://v.miaopai.com/iframe?scid=" . $mediaplayer . "__\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																											} else {
																												if (strpos($_var_8, "youtube.com/watch") !== false) {
																													$mediaplayer = explode("/watch?v=", $_var_8);
																													$mediaplayer = explode("&", $mediaplayer[1]);
																													$mediaplayer = $mediaplayer[0];
																													$mediaplayer = "<iframe src=\"https://www.youtube.com/embed/" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																												} else {
																													if (strpos($_var_8, "youtu.be") !== false) {
																														$mediaplayer = explode("youtu.be/", $_var_8);
																														$mediaplayer = explode("&", $mediaplayer[1]);
																														$mediaplayer = $mediaplayer[0];
																														$mediaplayer = "<iframe src=\"https://www.youtube.com/embed/" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																													} else {
																														if (strpos($_var_8, "youtube.com/v/") !== false) {
																															$mediaplayer = explode("/v/", $_var_8);
																															$mediaplayer = explode("&", $mediaplayer[1]);
																															$mediaplayer = $mediaplayer[0];
																															$mediaplayer = "<iframe src=\"https://www.youtube.com/embed/" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																														} else {
																															if (strpos($_var_8, "m.acfun.cn") !== false) {
																																$mediaplayer = explode("ac=", $_var_8);
																																$mediaplayer = $mediaplayer[1];
																																$mediaplayer = "<iframe src=\"https://www.acfun.cn/player/ac" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																															} else {
																																if (strpos($_var_8, "www.acfun.cn") !== false) {
																																	$mediaplayer = explode("/ac", $_var_8);
																																	$mediaplayer = explode("\"", $mediaplayer[1]);
																																	$mediaplayer = $mediaplayer[0];
																																	$mediaplayer = "<iframe src=\"https://www.acfun.cn/player/ac" . $mediaplayer . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\"></iframe>";
																																} else {
																																	if (strpos($_var_8, "open.iqiyi.com") !== false || strpos($_var_8, "djivideos.com") !== false) {
																																		$mediaplayer = "<iframe src=\"" . $_var_8 . "\" class=\"mediaplayer_video\" frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
																																	} else {
																																		if (strpos($_var_8, "163.com/song/") !== false) {
																																			$mediaplayer = explode("/song/", $_var_8);
																																			$mediaplayer = explode("/?userid=", $mediaplayer[1]);
																																			$mediaplayer = $mediaplayer[0];
																																			$mediaplayer = "<div class=\"mediaplayer_audio\"><audio src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" id=\"audio_" . substr(md5($_var_8), 10, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/mpeg\">" . $langplus["nothtmltag"] . "</audio></div>";
																																		} else {
																																			if (strpos($_var_8, "163.com/song?id=") !== false) {
																																				$mediaplayer = explode("/song?id=", $_var_8);
																																				$mediaplayer = explode("&userid=", $mediaplayer[1]);
																																				$mediaplayer = $mediaplayer[0];
																																				$mediaplayer = "<div class=\"mediaplayer_audio\"><audio src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" id=\"audio_" . substr(md5($_var_8), 10, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/mpeg\">" . $langplus["nothtmltag"] . "</audio></div>";
																																			} else {
																																				if (strpos($_var_8, "163.com/#/song?id=") !== false) {
																																					$mediaplayer = explode("/song?id=", $_var_8);
																																					$mediaplayer = $mediaplayer[1];
																																					$mediaplayer = "<div class=\"mediaplayer_audio\"><audio src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" id=\"audio_" . substr(md5($_var_8), 10, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/mpeg\">" . $langplus["nothtmltag"] . "</audio></div>";
																																				} else {
																																					if (strpos($_var_8, "163.com/m/song?id=") !== false) {
																																						$mediaplayer = explode("/song?id=", $_var_8);
																																						$mediaplayer = explode("&", $mediaplayer[1]);
																																						$mediaplayer = $mediaplayer[0];
																																						$mediaplayer = "<div class=\"mediaplayer_audio\"><audio src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" id=\"audio_" . substr(md5($_var_8), 10, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/mpeg\">" . $langplus["nothtmltag"] . "</audio></div>";
																																					} else {
																																						if (strpos($_var_8, "163.com/#/outchain/2") !== false) {
																																							$mediaplayer = explode("outchain/2/", $_var_8);
																																							$mediaplayer = explode("/", $mediaplayer[1]);
																																							$mediaplayer = $mediaplayer[0];
																																							$mediaplayer = "<div class=\"mediaplayer_audio\"><audio src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" id=\"audio_" . substr(md5($_var_8), 10, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" ><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/ogg\"><source src=\"https://music.163.com/song/media/outer/url?id=" . $mediaplayer . ".mp3\" type=\"audio/mpeg\">" . $langplus["nothtmltag"] . "</audio></div>";
																																						} else {
																																							if (strpos($_var_8, "163.com/m/program?id=") !== false) {
																																								$mediaplayer = explode("/program?id=", $_var_8);
																																								$mediaplayer = explode("&", $mediaplayer[1]);
																																								$mediaplayer = $mediaplayer[0];
																																								$mediaplayer = "<iframe width=\"100%\" height=\"86\" src=\"//music.163.com/outchain/player?type=3&id=" . $mediaplayer . "&auto=0&height=66\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music\"></iframe>";
																																							} else {
																																								if (strpos($_var_8, "163.com/#/program?id=") !== false) {
																																									$mediaplayer = explode("/program?id=", $_var_8);
																																									$mediaplayer = explode("&", $mediaplayer[1]);
																																									$mediaplayer = $mediaplayer[0];
																																									$mediaplayer = "<iframe width=\"100%\" height=\"86\" src=\"//music.163.com/outchain/player?type=3&id=" . $mediaplayer . "&auto=0&height=66\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music\"></iframe>";
																																								} else {
																																									if (strpos($_var_8, "163.com/#/outchain/3") !== false) {
																																										$mediaplayer = explode("outchain/3/", $_var_8);
																																										$mediaplayer = explode("/", $mediaplayer[1]);
																																										$mediaplayer = $mediaplayer[0];
																																										$mediaplayer = "<iframe width=\"100%\" height=\"86\" src=\"//music.163.com/outchain/player?type=3&id=" . $mediaplayer . "&auto=0&height=66\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music\"></iframe>";
																																									} else {
																																										if (strpos($_var_8, "163.com/#/outchain/4") !== false) {
																																											$mediaplayer = explode("outchain/4/", $_var_8);
																																											$mediaplayer = explode("/", $mediaplayer[1]);
																																											$mediaplayer = $mediaplayer[0];
																																											$mediaplayer = "<iframe width=\"100%\" height=\"270\" src=\"//music.163.com/outchain/player?type=4&id=" . $mediaplayer . "&auto=0&height=250\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music_big\"></iframe>";
																																										} else {
																																											if (strpos($_var_8, "163.com/radio?id=") !== false) {
																																												$mediaplayer = explode("/radio?id=", $_var_8);
																																												$mediaplayer = explode("&", $mediaplayer[1]);
																																												$mediaplayer = $mediaplayer[0];
																																												$mediaplayer = "<iframe width=\"100%\" height=\"270\" src=\"//music.163.com/outchain/player?type=4&id=" . $mediaplayer . "&auto=0&height=250\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music_big\"></iframe>";
																																											} else {
																																												if (strpos($_var_8, "163.com/m/radio?id=") !== false) {
																																													$mediaplayer = explode("/radio?id=", $_var_8);
																																													$mediaplayer = explode("&", $mediaplayer[1]);
																																													$mediaplayer = $mediaplayer[0];
																																													$mediaplayer = "<iframe width=\"100%\" height=\"270\" src=\"//music.163.com/outchain/player?type=4&id=" . $mediaplayer . "&auto=0&height=250\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music_big\"></iframe>";
																																												} else {
																																													if (strpos($_var_8, "163.com/#/playlist?id=") !== false) {
																																														$mediaplayer = explode("/playlist?id=", $_var_8);
																																														$mediaplayer = $mediaplayer[1];
																																														$mediaplayer = "<iframe width=\"100%\" height=\"270\" src=\"//music.163.com/outchain/player?type=0&id=" . $mediaplayer . "&auto=0&height=250\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music_big\"></iframe>";
																																													} else {
																																														if (strpos($_var_8, "163.com/playlist/") !== false) {
																																															$mediaplayer = explode("/playlist/", $_var_8);
																																															$mediaplayer = explode("/", $mediaplayer[1]);
																																															$mediaplayer = $mediaplayer[0];
																																															$mediaplayer = "<iframe width=\"100%\" height=\"270\" src=\"//music.163.com/outchain/player?type=0&id=" . $mediaplayer . "&auto=0&height=250\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music_big\"></iframe>";
																																														} else {
																																															if (strpos($_var_8, "163.com/m/playlist?id=") !== false) {
																																																$mediaplayer = explode("/playlist?id=", $_var_8);
																																																$mediaplayer = explode("&", $mediaplayer[1]);
																																																$mediaplayer = $mediaplayer[0];
																																																$mediaplayer = "<iframe width=\"100%\" height=\"270\" src=\"//music.163.com/outchain/player?type=0&id=" . $mediaplayer . "&auto=0&height=250\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music_big\"></iframe>";
																																															} else {
																																																if (strpos($_var_8, "163.com/#/outchain/0") !== false) {
																																																	$mediaplayer = explode("outchain/0/", $_var_8);
																																																	$mediaplayer = explode("/", $mediaplayer[1]);
																																																	$mediaplayer = $mediaplayer[0];
																																																	$mediaplayer = "<iframe width=\"100%\" height=\"270\" src=\"//music.163.com/outchain/player?type=0&id=" . $mediaplayer . "&auto=0&height=250\" frameborder=\"no\" border=\"0\" marginwidth=\"0\" marginheight=\"0\" class=\"yun_music_big\"></iframe>";
																																																} else {
																																																	if (strpos($_var_8, "ximalaya.com/thirdparty/player/sound") !== false) {
																																																		$mediaplayer = explode("/player.html?id=", $_var_8);
																																																		$mediaplayer = explode("&", $mediaplayer[1]);
																																																		$mediaplayer = $mediaplayer[0];
																																																		$mediaplayer = "<iframe height=\"36\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/sound/player.html?id=" . $mediaplayer . "&type=red\" class=\"ximalaya_music\" frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
																																																	} else {
																																																		if (strpos($_var_8, "ximalaya.com/thirdparty/player/album") !== false) {
																																																			$mediaplayer = explode("/player.html?id=", $_var_8);
																																																			$mediaplayer = explode("&", $mediaplayer[1]);
																																																			$mediaplayer = $mediaplayer[0];
																																																			$mediaplayer = "<iframe height=\"230\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/album/player.html?id=" . $mediaplayer . "&type=red\" class=\"ximalaya_music_big\" frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
																																																		} else {
																																																			if (strpos($_var_8, "m.ximalaya.com/sound") !== false) {
																																																				$mediaplayer = explode("/sound/", $_var_8);
																																																				$mediaplayer = $mediaplayer[1];
																																																				$mediaplayer = "<iframe height=\"36\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/sound/player.html?id=" . $mediaplayer . "&type=red\" class=\"ximalaya_music\" frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
																																																			} else {
																																																				if (strpos($_var_8, "m.ximalaya.com/album") !== false) {
																																																					$mediaplayer = explode("/album/", $_var_8);
																																																					$mediaplayer = $mediaplayer[1];
																																																					$mediaplayer = "<iframe height=\"230\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/album/player.html?id=" . $mediaplayer . "&type=red\" class=\"ximalaya_music_big\" frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
																																																				} else {
																																																					if (strpos($_var_8, "m.ximalaya.com/share/sound") !== false) {
																																																						$mediaplayer = explode("/sound/", $_var_8);
																																																						$mediaplayer = explode("?uid=", $mediaplayer[1]);
																																																						$mediaplayer = $mediaplayer[0];
																																																						$mediaplayer = "<iframe height=\"36\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/sound/player.html?id=" . $mediaplayer . "&type=red\" class=\"ximalaya_music\" frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
																																																					} else {
																																																						if (strpos($_var_8, "m.ximalaya.com/share/album") !== false) {
																																																							$mediaplayer = explode("/album/", $_var_8);
																																																							$mediaplayer = explode("?uid=", $mediaplayer[1]);
																																																							$mediaplayer = $mediaplayer[0];
																																																							$mediaplayer = "<iframe height=\"230\" width=\"100%\" src=\"https://www.ximalaya.com/thirdparty/player/album/player.html?id=" . $mediaplayer . "&type=red\" class=\"ximalaya_music_big\" frameborder=\"0\" allowfullscreen=\"\" scrolling=\"no\"></iframe>";
																																																						} else {
																																																							$mediaplayer = "<div class=\"medianoplay_thread\">" . $langplus["noplay"] . "</div>";
																																																						}
																																																					}
																																																				}
																																																			}
																																																		}
																																																	}
																																																}
																																															}
																																														}
																																													}
																																												}
																																											}
																																										}
																																									}
																																								}
																																							}
																																						}
																																					}
																																				}
																																			}
																																		}
																																	}
																																}
																															}
																														}
																													}
																												}
																											}
																										}
																									}
																								}
																							}
																						}
																					}
																				}
																			}
																		}
																	}
																}
															}
														}
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
	} else {
		if ($_var_5) {
			$_var_11 = 0;
			foreach ($_var_5 as $_var_12) {
				if (stripos($_var_12["filename"], ".mp4") !== false || stripos($_var_12["filename"], ".mov") !== false) {
					if ($_var_11 == 1) {
						break;
					}
					$_var_13 = $_var_12["remote"] ? $_G["setting"]["ftp"]["attachurl"] : $_G["setting"]["attachurl"];
					$_var_13 = $_var_13 . "forum/" . $_var_12["attachment"];
					$mediaplayer = "<div class=\"mediaplayer_video\"><video id=\"video_" . substr(md5($_var_13), 14, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" x5-playsinline webkit-playsinline playsinline ><source src=\"" . $_var_13 . "\" type=\"video/ogg\" /><source src=\"" . $_var_13 . "\" type=\"video/mp4\" />" . $langplus["nothtmltag"] . "</video></div>";
					$_var_11 = $_var_11 + 1;
				} else {
					if (stripos($_var_12["filename"], ".mp3") !== false || stripos($_var_12["filename"], ".wav") !== false) {
						if ($_var_11 == 1) {
							break;
						}
						$_var_13 = $_var_12["remote"] ? $_G["setting"]["ftp"]["attachurl"] : $_G["setting"]["attachurl"];
						$_var_13 = $_var_13 . "forum/" . $_var_12["attachment"];
						$mediaplayer = $mediaplayer . ("<div class=\"mediaplayer_audio\"><audio src=\"" . $_var_13 . "\" id=\"audio_" . substr(md5($_var_13), 14, 10) . "\" controls=\"controls\" controlslist=\"nodownload\" oncontextmenu=\"return false\" ><source src=\"" . $_var_13 . "\" type=\"audio/ogg\"><source src=\"" . $_var_13 . "\" type=\"audio/mpeg\">" . $langplus["nothtmltag"] . "</audio></div>");
						$_var_11 = $_var_11 + 1;
					}
				}
			}
		}
	}