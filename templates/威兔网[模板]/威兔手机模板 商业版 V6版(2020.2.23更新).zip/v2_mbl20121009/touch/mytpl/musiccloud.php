<?php

	if (!$_GET || !$_POST) {
		echo "Access Denied";
		return 0;
	}
	global $songapi;
	global $songdata;
	$_var_2 = $_POST["songsrc"];
	if (strpos($_var_2, "163.com/song/") !== false) {
		$_var_2 = explode("/song/", $_var_2);
		$_var_2 = explode("/?userid=", $_var_2[1]);
		$_var_2 = $_var_2[0];
	} else {
		if (strpos($_var_2, "163.com/song?id=") !== false) {
			$_var_2 = explode("/song?id=", $_var_2);
			$_var_2 = explode("&userid=", $_var_2[1]);
			$_var_2 = $_var_2[0];
		} else {
			if (strpos($_var_2, "163.com/#/song?id=") !== false) {
				$_var_2 = explode("/song?id=", $_var_2);
				$_var_2 = $_var_2[1];
			} else {
				if (strpos($_var_2, "163.com/m/song?id=") !== false) {
					$_var_2 = explode("/song?id=", $_var_2);
					$_var_2 = explode("&", $_var_2[1]);
					$_var_2 = $_var_2[0];
				} else {
					if (strpos($_var_2, "163.com/#/outchain/2") !== false) {
						$_var_2 = explode("outchain/2/", $_var_2);
						$_var_2 = explode("/", $_var_2[1]);
						$_var_2 = $_var_2[0];
					}
				}
			}
		}
	}
	$_var_3 = array("http://music.163.com/api/song/detail/?id=" . $_var_2 . "&ids=%5B" . $_var_2 . "%5D&csrf_token=", "http://music.163.com/api/song/lyric?os=pc&id=" . $_var_2 . "&lv=-1");
	$_var_4 = curl_multi_init();
	foreach ($_var_3 as $_var_5) {
		$_var_6 = curl_init();
		curl_setopt($_var_6, CURLOPT_URL, $_var_5);
		curl_setopt($_var_6, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($_var_6, CURLOPT_POST, 0);
		curl_setopt($_var_6, CURLOPT_TIMEOUT, 30);
		curl_multi_add_handle($_var_4, $_var_6);
	}
	$_var_7 = array();
	Label_3983:
	while (($_var_8 = curl_multi_exec($_var_4, $_var_9)) == CURLM_CALL_MULTI_PERFORM) {
	}
	if ($_var_9) {
		goto Label_3983;
	}
	while ($_var_10 = curl_multi_info_read($_var_4)) {
		$_var_11 = curl_multi_getcontent($_var_10["handle"]);
		curl_multi_remove_handle($_var_4, $_var_10["handle"]);
		curl_close($_var_10["handle"]);
		$_var_7[] = $_var_11;
	}
	curl_multi_close($_var_4);
	$_var_12 = json_decode($_var_7[0]);
	$_var_13 = json_decode($_var_7[1]);
	if (array_key_exists("songs", $_var_13)) {
		$_var_14 = $_var_13->songs[0]->album->picUrl;
		$_var_15 = $_var_13->songs[0]->artists[0]->name;
		$_var_16 = $_var_13->songs[0]->name;
		$_var_17 = $_var_13->songs[0]->album->name;
		if (array_key_exists("lrc", $_var_12)) {
			$_var_18 = $_var_12->lrc->lyric;
			$_var_18 = str_replace(array("\r\n", "\r", "\n"), '', $_var_18);
			$_var_18 = preg_replace("/\\[.*?\\]/", "\\n", $_var_18);
		} else {
			$_var_18 = '';
		}
	} else {
		$_var_14 = $_var_12->songs[0]->album->picUrl;
		$_var_15 = $_var_12->songs[0]->artists[0]->name;
		$_var_16 = $_var_12->songs[0]->name;
		$_var_17 = $_var_12->songs[0]->album->name;
		if (array_key_exists("lrc", $_var_13)) {
			$_var_18 = $_var_13->lrc->lyric;
			$_var_18 = str_replace(array("\r\n", "\r", "\n"), '', $_var_18);
			$_var_18 = preg_replace("/\\[.*?\\]/", "\\n", $_var_18);
		} else {
			$_var_18 = '';
		}
	}
	$songapi = $_POST["songsrc"];
	$songdata = '';
	if ($_var_15 != '') {
		$songdata = "{artistsname:\"" . $_var_15 . "\",songsname:\"" . $_var_16 . "\",albumname:\"" . $_var_17 . "\",songapi:\"" . $songapi . "\",picurl:\"" . $_var_14 . "\",lyricinfo:\"" . $_var_18 . "\"}";
	}
	echo json_encode($songdata);