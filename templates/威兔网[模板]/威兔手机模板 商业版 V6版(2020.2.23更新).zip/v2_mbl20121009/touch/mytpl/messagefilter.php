<?php

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$post['message'] = preg_replace('/<video.*?<\/video>.*?<br \/>/is', '',$post['message']);
$post['message'] = preg_replace('/<audio.*?<\/audio>.*?<br \/>/is', '',$post['message']);
$post['message'] = preg_replace('/<iframe.*?<\/iframe>.*?<br \/>/is', '',$post['message']);
$post['message'] = preg_replace('/<video.*?<\/video>/is', '',$post['message']);
$post['message'] = preg_replace('/<audio.*?<\/audio>/is', '',$post['message']);
$post['message'] = preg_replace('/<iframe.*?<\/iframe>/is', '',$post['message']);
$post['message'] = preg_replace('/<script.*?<\/script>/is', '',$post['message']);
$post['message'] = preg_replace('/<div id="attach.*?<\/div>/is', '',$post['message']);
$post['message'] = preg_replace('/<div class="img_insert">.*?<\/div>/is', '',$post['message']);
$post['message'] = preg_replace('/\[media.*?\[\/media\]/is', '',$post['message']);
$post['message'] = preg_replace('/\[audio.*?\[\/audio\]/is', '',$post['message']);
$post['message'] = preg_replace('/\[flash.*?\[\/flash\]/is', '',$post['message']);

?>