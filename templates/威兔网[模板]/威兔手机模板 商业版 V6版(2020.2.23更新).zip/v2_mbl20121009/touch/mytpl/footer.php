<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $closeplugin == 0}-->
<!--{hook/global_footer_mobile}-->
<!--{/if}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->
<div id="mask" style="display:none;"></div>
</div>
<!--{if $_G['basescript'] != member }-->
<!--{if $nologintplplus == 1}-->
<!--{if !$_G[uid] && !$_G['connectguest']}--><!--{$tplplusb}--><!--{/if}-->
<!--{else}-->
<!--{$tplplusb}-->
<!--{/if}-->
<!--{/if}-->
<!--{$footerplus}-->
<!--{$scrollplus}-->
<!--{if !$headershow && !$nosopenmenu}-->
<a href="javascript:;" class="mm-openmenu scroll_openmenu"></a>
<style type="text/css">.scroll_plus { bottom: 127px; }</style>
<!--{/if}-->
<!--{if $sortmenufloat || (($closenav == 1 && (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false)) && $headershow) }-->
<script type="text/javascript">
    <!--{if $sortmenufloat}-->
    $(document).ready(function(){$(window).scroll(function(){var coverheight = $('.sortrollheight').height() + 50;if ($(window).scrollTop() > coverheight) {$('.sortmenus').addClass('{if $headershow}sortmenu_float{else}sortmenu_top{/if}');}else{$('.sortmenus').removeClass('{if $headershow}sortmenu_float{else}sortmenu_top{/if}');	}});});
    <!--{/if}-->
    <!--{if ($closenav == 1 && (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false)) && $headershow }-->
    $(document).ready(function(){var p=0,t=0;$(window).scroll(function(e){if($(window).scrollTop()>300){p=$(this).scrollTop();if(t<=p){$('.header{if $sortmenufloat}, .sortmenus{/if}').addClass('close_h')}else{$('.header{if $sortmenufloat}, .sortmenus{/if}').removeClass('close_h')}}t=p});});
    <!--{/if}-->
	$(document).ready(function(){var p=0,t=0;$(window).scroll(function(e){if($(window).scrollTop()>80){p=$(this).scrollTop();if(t<=p){setTimeout(function(){$('.scroll_plus{if !$headershow}, .scroll_openmenu{/if}').addClass('scroll_hide')},300)}else{setTimeout(function(){$('.scroll_plus{if !$headershow}, .scroll_openmenu{/if}').removeClass('scroll_hide')},300)}}t=p})});
</script>
<!--{/if}-->
<!--{if ($_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck) && $sounds }-->
<audio src="template/v2_mbl20121009/touch_plus/sound/00_{$sounds}.mp3" autoplay="autoplay"><source src="template/v2_mbl20121009/touch_plus/sound/00_{$sounds}.mp3" type="audio/ogg"><source src="template/v2_mbl20121009/touch_plus/sound/00_{$sounds}.mp3" type="audio/mpeg"></audio>
<!--{/if}-->
</body>
</html>
<!--{eval updatesession();}-->
<!--{eval require_once(DISCUZ_ROOT.'./source/plugin/v2_wap_03/corefile/restore.core.php');}-->
<!--{$tplstat}-->
<!--{if defined('IN_MOBILE')}-->
	<!--{eval output();}-->
<!--{else}-->
	<!--{eval output_preview();}-->
<!--{/if}-->