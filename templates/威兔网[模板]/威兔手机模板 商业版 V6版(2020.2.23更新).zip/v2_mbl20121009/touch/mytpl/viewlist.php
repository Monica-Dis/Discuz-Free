<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
	if (!defined("IN_DISCUZ")) {
		echo "Access Denied";
		return 0;
	}
	global $vwlist;
	global $relatedviewallnums;
	global $relatedviewpics;
	global $relatedviewsorts;
	global $relatedviewtimes;
	global $cat;
	global $article;
	global $wearehores;
	if ($wearehores != "okmaxs") {
		return 0;
	}
	$_var_8 = $relatedviewallnums;
	$_var_9 = $relatedviewpics;
	$_var_10 = $relatedviewtimes;
	$_var_10 = TIMESTAMP - 86400 * $_var_10;
	if ($relatedviewsorts == 6) {
		$_var_11 = "rand()";
	} else {
		$_var_12 = array(1 => "dateline", 2 => "viewnum", 3 => "commentnum", 4 => "favtimes", 5 => "sharetimes");
		$_var_11 = $_var_12[$relatedviewsorts];
		$_var_11 = $_var_11 == "dateline" ? "at.dateline DESC " : "ac." . $_var_11 . " DESC";
	}
	$_var_13 = DB::fetch_all("SELECT * FROM %t at LEFT JOIN %t ac ON at.aid=ac.aid WHERE at.catid IN(%n) AND at.aid not LIKE %n AND at.dateline>=" . $_var_10 . " %i AND at.status=0 ORDER BY %i LIMIT 0, %d", array("portal_article_title", "portal_article_count", $cat["catid"], $article["aid"], $_var_9 ? "AND pic != ''" : NULL, $_var_11, $_var_8));
	foreach ($_var_13 as $_var_14) {
		if ($_var_9) {
			$_var_14["pic"] = $_var_14["pic"];
			$_var_14["picflag"] = $_var_14["remote"] == "1" ? "2" : "1";
		} else {
			$_var_14["picflag"] = "0";
		}
		$_var_14["dateline"] = dgmdate($_var_14["dateline"], "u");
		$vwlist[] = $_var_14;
	}