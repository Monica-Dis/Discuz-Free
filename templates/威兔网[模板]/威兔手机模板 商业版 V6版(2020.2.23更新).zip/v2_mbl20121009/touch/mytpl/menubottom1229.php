<?php exit('QQ:32-77558-32');?>
<!--{if $_G['basescript'] == 'forum' && CURMODULE == forumdisplay }-->
<!--{block bottombutton}-->
<ul>
    <!--{if $tplwapurl}-->
    <li><a href="forum.php"><i class="P3Ggjz8tK4wj"></i>{$langplus[home]}</a></li>
    <li class="z9OiMHNVHl8G"><a href="forum.php?forumlist=1"><i class="h5gassCXSar1"></i>{$langplus[bbs]}</a></li>
    <!--{else}-->
    <li class="z9OiMHNVHl8G"><a href="forum.php?forumlist=1"><i class="h5gassCXSar1"></i>{$langplus[bbs]}</a></li>
    <li><a href="forum.php?mod=guide&view=newthread"><i class="wp68XIppeE1f"></i>{$langplus[guide]}</a></li>
    <!--{/if}-->
    <li><div class="CBb2RksjMgB7"><a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="s0LeHx2M3fn3"><!--{if $footerbib}--><!--{$footerbib}--><!--{else}--><i class="9xg2U1Gd4eWz"></i><!--{/if}--></a></div></li>
    <li>
        <!--{if $favstate && $_G['uid']}-->
        <a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="YLWBeoFxc65X"><i class="0AzReYbBML2J"></i>{$langplus[favorite]}</a>
        <!--{else}-->
        <a href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G[fid]}" class="OpMUVmE827zN"><i class="IG6Lejyn1LxU"></i>{$langplus[favorite]}</a>
        <!--{/if}-->
    </li>
    <li>
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
        <a href="member.php?mod=logging&action=login"><i class="XR3zFOL4bCHX"></i>{lang login}</a>
        <!--{else}-->
        <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><i class="XR3zFOL4bCHX"></i>$langplus[me]</a>
        <!--{if $_G[member][newpm] || $_G[member][newprompt] || $_G['connectguest'] || $smscheck }--><i class="GXoXTZmDmtgZ"></i><!--{/if}-->
        <!--{/if}-->
    </li>
</ul>
<!--{$ajaxsubmit_item}-->
<!--{/block}-->
<!--{elseif $_G['basescript'] == 'forum' && CURMODULE == viewthread || $_G['basescript'] == 'group' && CURMODULE == viewthread }-->
<!--{block bottombutton}-->
<ul>
    <li class="fastbtn{if ($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']}{if !empty($_G['setting']['recommendthread']['addtext'])} supportbtn{/if}{/if}"><span class="bkET0E9CCf1H">{$langplus[sayaword]}</span></li>
    <li><a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$post[pid]&page=$page"><i class="NvWRZJRmWp7P"></i>{$langplus[reply]}</a><!--{if $_G[forum_thread][allreplies] > 0}-->
        <!--{if $_G[forum_thread][allreplies] > 9999 }-->
        <!--{eval $_G[forum_thread][allreplies] = round($_G[forum_thread][allreplies] / 10000 , 1).$langplus[tenthousand];}-->
        <!--{/if}-->
        <i class="CfcpMdPAfYn2">{$_G[forum_thread][allreplies]}</i>
        <!--{/if}-->
    </li>
    <li>
        <!--{eval $favstate = C::t('home_favorite')->fetch_by_id_idtype($_G['tid'],'tid',$_G['uid']);}-->
        <!--{if $favstate && $_G['uid']}-->
        <a href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favstate['favid']&formhash={FORMHASH}" class="YLWBeoFxc65X"><i class="0AzReYbBML2J"></i>{$langplus[favorite]}</a>
        <!--{else}-->
        <a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]&formhash={FORMHASH}" class="OpMUVmE827zN" ><i class="IG6Lejyn1LxU"></i>{$langplus[favorite]}</a>
        <!--{/if}-->
    </li>
    <!--{if (($_G['group']['allowrecommend'] || !$_G['uid']) && $_G['setting']['recommendthread']['status']) && (!empty($_G['setting']['recommendthread']['addtext']))}-->
    <!--{if $_G[forum_thread][recommend_add] > 9999 }-->
    <!--{eval $_G[forum_thread][recommend_add] = round($_G[forum_thread][recommend_add] / 10000 , 1).$langplus[tenthousand];}-->
    <!--{/if}-->
    <li><i class="CfcpMdPAfYn2"{if !$_G['forum_thread']['recommend_add']} style="display:none;"{/if}><!--{if $_G['forum_thread']['recommend_add']}-->{$_G[forum_thread][recommend_add]}<!--{/if}--></i><a href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" class="e4nPFajA8567"><i class="CXCDCYFJEQTe"></i>{$langplus[support]}</a></li>
    <!--{/if}-->
    <li><a href="javascript:;" id="fshare"><i class="IEQniONTPkBH"></i>{$langplus[share]}</a></li>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#fshare').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').addClass('weixinshare');
                $('.close_s1').show();
                <!--{else}-->
                $('#myshare').addClass('openshare');
                $('header, footer, .pt, .scroll_plus, .scroll_top').addClass('onlypage');
                $('.close_s').show();
                <!--{/if}-->
            });
            $('.close_s, .close_s1').click(function(){
                <!--{if strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false || strpos($_SERVER['HTTP_USER_AGENT'], 'QQ/') !== false}-->
                $('#myshare').removeClass('weixinshare');
                <!--{else}-->
                $('#myshare').removeClass('openshare');
                $('header, footer, .pt, .scroll_plus, .scroll_top').removeClass('onlypage');
                <!--{/if}-->
                $(this).hide();
            });
        });
    </script>
</ul>
<script type="text/javascript">	
$(document).ready(function(){	
	$('.fastreply, .sofareply').click(function(){
		<!--{if $allowfastpost}-->
		$('.postbox').slideToggle();
		$('.close_p').delay(300).fadeIn();
		<!--{else}-->
		<!--{if !$_G[uid] || $_G[uid] && !$allowpostreply}-->
		<!--{if !$_G[uid]}-->
		popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
		<!--{else}-->
		popup.open('{lang nopostreply}', 'alert');
		<!--{/if}-->
		this.blur();
		<!--{else}-->
		$('.postbox').slideToggle();
		$('.close_p').delay(300).fadeIn();
		<!--{/if}-->
		<!--{/if}-->
	}); 	
	$('.close_p').click(function(){	
		$('.postbox').slideToggle();
		$('.editordefault a').removeClass('on');
		$('.hidebox').slideUp();
		$(this).hide();
	});  
});	
</script>
<!--{$ajaxsubmit_item}-->
<!--{/block}-->
<!--{/if}-->