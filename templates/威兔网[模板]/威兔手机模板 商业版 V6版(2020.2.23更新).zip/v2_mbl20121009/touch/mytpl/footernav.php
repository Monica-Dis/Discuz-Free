<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if !$nofooter && $footershow}-->
<!--{block footertwo}-->
<!--{if $footernavtw == 1}-->
<li><a href="search.php?mod={if $searchmode == 1 || !$searchmode}forum{elseif $searchmode == 2}portal{elseif $searchmode == 3}group{elseif $searchmode == 4}blog{elseif $searchmode == 5}album{/if}"><i class="42PwTC7qtJHD"></i>{lang search}</a></li>
<!--{elseif $footernavtw == 2}-->
<li{if $_G['basescript'] == 'forum' && $_GET[mod] != 'guide'} class="Yfm1QC5IeoTk"{/if}><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>{$langplus[bbs]}</a></li>
<!--{elseif $footernavtw == 3}-->
<li><a href="group.php"><i class="YnfUIGTrsvCI"></i>{$langplus[groups]}</a></li>
<!--{elseif $footernavtw == 4}-->
<li><a href="home.php?mod=follow"><i class="nPDQLXbWUFhN"></i>{$langplus[follow]}</a></li>
<!--{elseif $footernavtw == 5}-->
<li{if $_G['basescript'] == 'forum' && $_GET[mod] == 'guide'} class="Yfm1QC5IeoTk"{/if}><a href="forum.php?mod=guide&view=newthread"><i class="2BNmEfaRrZB2"></i>{$langplus[guide]}</a></li>
<!--{elseif $footernavtw == 6}-->
<li><a href="home.php"><i class="gJOIWw2O9nKD"></i>{$langplus[feed]}</a></li>
<!--{elseif $footernavtw == 7}-->
<li><a href="home.php?mod=space&do=blog&view=me"><i class="tPWMlekcSvvx"></i>{$langplus[blog]}</a></li>
<!--{elseif $footernavtw == 8}-->
<li><a href="home.php?mod=space&do=album&view=me"><i class="daZn2ppRqYhB"></i>{$langplus[album]}</a></li>
<!--{elseif $footernavtw == 9}-->
<li><a href="home.php?mod=space&do=doing"><i class="uxRuc7g0NTb5"></i>{$langplus[doing]}</a></li>
<!--{elseif $footernavtw == 10}-->
<li><a href="home.php?mod=space&do=wall"><i class="2poN9DWA9DRW"></i>{$langplus[wall]}</a></li>
<!--{elseif $footernavtw == 11}-->
<li{if $_G['basescript'] == 'misc' && $_GET[mod] == 'ranklist'} class="Yfm1QC5IeoTk"{/if}><a href="misc.php?mod=ranklist"><i class="N5Fk4vSFx8xE"></i>{$langplus[ranklist]}</a></li>
<!--{elseif $footernavtw == 12}-->
<li><a href="home.php?mod=space&do=pm"><i class="iqTKlHsxxxPS"></i>{lang pm_center}</a></li>
<!--{elseif $footernavtw == 13}-->
<li><a href="home.php?mod=space&do=notice"><i class="xhWsdQpQ1LkB"></i>{lang remind}</a></li>
<!--{/if}-->
<!--{/block}-->
<!--{block footerfour}-->
<!--{if $footernavth == 1}-->
<li><a href="search.php?mod={if $searchmode == 1 || !$searchmode}forum{elseif $searchmode == 2}portal{elseif $searchmode == 3}group{elseif $searchmode == 4}blog{elseif $searchmode == 5}album{/if}"><i class="42PwTC7qtJHD"></i>{lang search}</a></li>
<!--{elseif $footernavth == 2}-->
<li{if $_G['basescript'] == 'forum' && $_GET[mod] != 'guide'} class="Yfm1QC5IeoTk"{/if}><a href="forum.php?forumlist=1"><i class="xNbTvxGE0mMM"></i>{$langplus[bbs]}</a></li>
<!--{elseif $footernavth == 3}-->
<li><a href="group.php"><i class="YnfUIGTrsvCI"></i>{$langplus[groups]}</a></li>
<!--{elseif $footernavth == 4}-->
<li><a href="home.php?mod=follow"><i class="nPDQLXbWUFhN"></i>{$langplus[follow]}</a></li>
<!--{elseif $footernavth == 5}-->
<li{if $_G['basescript'] == 'forum' && $_GET[mod] == 'guide'} class="Yfm1QC5IeoTk"{/if}><a href="forum.php?mod=guide&view=newthread"><i class="2BNmEfaRrZB2"></i>{$langplus[guide]}</a></li>
<!--{elseif $footernavth == 6}-->
<li><a href="home.php"><i class="gJOIWw2O9nKD"></i>{$langplus[feed]}</a></li>
<!--{elseif $footernavth == 7}-->
<li><a href="home.php?mod=space&do=blog&view=me"><i class="tPWMlekcSvvx"></i>{$langplus[blog]}</a></li>
<!--{elseif $footernavth == 8}-->
<li><a href="home.php?mod=space&do=album&view=me"><i class="daZn2ppRqYhB"></i>{$langplus[album]}</a></li>
<!--{elseif $footernavth == 9}-->
<li><a href="home.php?mod=space&do=doing"><i class="uxRuc7g0NTb5"></i>{$langplus[doing]}</a></li>
<!--{elseif $footernavth == 10}-->
<li><a href="home.php?mod=space&do=wall"><i class="2poN9DWA9DRW"></i>{$langplus[wall]}</a></li>
<!--{elseif $footernavth == 11}-->
<li{if $_G['basescript'] == 'misc' && $_GET[mod] == 'ranklist'} class="Yfm1QC5IeoTk"{/if}><a href="misc.php?mod=ranklist"><i class="N5Fk4vSFx8xE"></i>{$langplus[ranklist]}</a></li>
<!--{elseif $footernavth == 12}-->
<li><a href="home.php?mod=space&do=pm"><i class="iqTKlHsxxxPS"></i>{lang pm_center}</a></li>
<!--{elseif $footernavth == 13}-->
<li><a href="home.php?mod=space&do=notice"><i class="xhWsdQpQ1LkB"></i>{lang remind}</a></li>
<!--{/if}-->
<!--{/block}-->
<!--{/if}-->