<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->


<div id="ct" class="rtj1009_ct2 cl">
	<div class="rtj1009_sz_mn">
		<div class="ren_sz_bm">
		<div class="ren_sz_bt"><h3>$_G['setting']['plugins']['portalcp'][$_GET['id']]['name']</h3></div>
			<div class="ren_sz_z">
			<div id="block_selection">
				<!--{eval include(template($_GET['id']));}-->
			</div>
			</div>
		</div>
	</div>
	<div class="rtj1009_zcd">
		<!--{subtemplate portal/portalcp_nav}-->
	</div>
</div>

<!--{template common/footer}-->
