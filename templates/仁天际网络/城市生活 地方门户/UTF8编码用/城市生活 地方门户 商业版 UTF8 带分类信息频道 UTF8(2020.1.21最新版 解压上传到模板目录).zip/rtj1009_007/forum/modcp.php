<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<div id="ct" class="rtj1009_ct2 cl">
	<div class="rtj1009_sz_mn">
		<!--{if $script == 'noperm'}-->
		<div class="ren_sz_bm">
				<div class="ren_sz_bt cl"><h3>{lang mod_option_error}</h3></div>
				<p>{lang mod_error_invalid}</p>
				<p class="notice">{lang mod_notice}</p>
			</div>
		<!--{elseif !empty($modtpl)}-->
			<!--{eval include(template($modtpl));}-->
		<!--{/if}-->
	</div>
	<div class="rtj1009_zcd">
		<ul class="ren_tbn">
			<li{if $_GET[action] == 'home'} class="a cl"{else} class="cl"{/if}><a href="{$cpscript}?mod=modcp&action=home$forcefid">{lang mod_notice_title}</a><span>></span></li>
			<!--{if $modforums['fids']}-->
				<!--{if $_G['group']['allowmodpost'] || $_G['group']['allowmoduser']}-->
					<li{if $_GET[action] == 'moderate'} class="a cl"{else} class="cl"{/if}><a href="{$cpscript}?mod=modcp&action=moderate&op={if $_G['group']['allowmodpost']}threads{$forcefid}{else}members{/if}">{lang forum_moderate}</a><span>></span></li>
				<!--{/if}-->
			<!--{/if}-->
			<!--{if !empty($_G['setting']['plugins']['modcp_base'])}-->
				<!--{loop $_G['setting']['plugins']['modcp_base'] $id $module}-->
					<li{if $_GET[id] == $id} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=plugin&op=base&id=$id{$forcefid}">$module[name]</a><span>></span></li>
				<!--{/loop}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowedituser'] || $_G['group']['allowbanuser'] || $_G['group']['allowbanvisituser'] || $_G['group']['allowbanip']}-->
				<!--{if $_G['group']['allowbanuser'] || $_G['group']['allowbanvisituser']}--><li{if $_GET[action] == 'member' && $op == 'ban'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=member&op=ban$forcefid">{lang mod_option_member_ban}</a><span>></span></li><!--{/if}-->
				<!--{if $_G['group']['allowbanip']}--><li{if $_GET[action] == 'member' && $op == 'ipban'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=member&op=ipban$forcefid">{lang mod_option_member_ipban}</a><span>></span></li><!--{/if}-->
				<!--{if $modforums['fids']}--><li{if $_GET[action] == 'forumaccess'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=forumaccess{$forcefid}">{lang mod_option_member_access}</a><span>></span></li><!--{/if}-->
				<!--{if $_G['group']['allowedituser']}--><li{if $_GET[action] == 'member' && $op == 'edit'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=member&op=edit$forcefid">{lang mod_option_member_edit}</a><span>></span></li><!--{/if}-->
			<!--{/if}-->
			<!--{if $modforums['fids']}-->
				<li{if $_GET[action] == 'thread' || $_GET[action] == 'recyclebin'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=thread&op=thread{$forcefid}">{lang mod_option_subject}</a><span>></span></li>
				<!--{if $_G['group']['allowrecommendthread']}--><li{if $_GET[action] == 'forum' && $op == 'recommend'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=forum&op=recommend&show=all{$forcefid}">{lang mod_option_forum_recommend}</a><span>></span></li><!--{/if}-->
				<!--{if $_G['group']['alloweditforum']}--><li{if $_GET[action] == 'forum' && $op == 'editforum'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=forum&op=editforum{$forcefid}">{lang mod_option_forum_edit}</a><span>></span></li><!--{/if}-->
			<!--{/if}-->
			<!--{if $_G['group']['allowpostannounce'] || $_G['group']['allowviewlog']}-->
				<!--{if $_G['group']['allowpostannounce']}--><li{if $_GET[action] == 'announcement'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=announcement$forcefid">{lang announcements}</a><span>></span></li><!--{/if}-->
				<!--{if $_G['group']['allowviewlog']}--><li{if $_GET[action] == 'log'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=log$forcefid">{lang modcp_logs}</a><span>></span></li><!--{/if}-->
			<!--{/if}-->
			<!--{if !empty($_G['setting']['plugins']['modcp_tools'])}-->
				<!--{loop $_G['setting']['plugins']['modcp_tools'] $id $module}-->
					<li{if $_GET[id] == $id} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=plugin&op=tools&id=$id">$module[name]</a><span>></span></li>
				<!--{/loop}-->
			<!--{/if}-->
			<li{if $_GET[action] == 'report'} class="a"{/if}><a href="{$cpscript}?mod=modcp&action=report$forcefid">{lang modcp_report}</a><span>></span></li>
			<li><a href="{if $forcefid}forum.php?mod=forumdisplay{$forcefid}{else}forum.php{/if}">{lang mod_option_return}</a><span>></span></li>
			<li><a href="{$cpscript}?mod=modcp&action=logout">{lang logout}</a><span>></span></li>
		</ul>
	</div>
</div>

<!--{template common/footer}-->
