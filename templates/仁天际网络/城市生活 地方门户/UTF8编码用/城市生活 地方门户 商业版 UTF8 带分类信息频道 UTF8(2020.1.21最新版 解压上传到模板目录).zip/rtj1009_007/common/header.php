<?php echo 'From: DisM.taobao.com';exit;?>
<!--{subtemplate common/header_common}-->
<!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_007/php/rtj1009_core.php';}-->
	<meta name="application-name" content="$_G['setting']['bbname']" />
	<meta name="msapplication-tooltip" content="$_G['setting']['bbname']" />
	<!--{if $_G['setting']['portalstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][1]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['portal']) ? 'http://'.$_G['setting']['domain']['app']['portal'] : $_G[siteurl].'portal.php'};icon-uri={$_G[siteurl]}{IMGDIR}/portal.ico" /><!--{/if}-->
	<meta name="msapplication-task" content="name=$_G['setting']['navs'][2]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['forum']) ? 'http://'.$_G['setting']['domain']['app']['forum'] : $_G[siteurl].'forum.php'};icon-uri={$_G[siteurl]}{IMGDIR}/bbs.ico" />
	<!--{if $_G['setting']['groupstatus']}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][3]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['group']) ? 'http://'.$_G['setting']['domain']['app']['group'] : $_G[siteurl].'group.php'};icon-uri={$_G[siteurl]}{IMGDIR}/group.ico" /><!--{/if}-->
	<!--{if helper_access::check_module('feed')}--><meta name="msapplication-task" content="name=$_G['setting']['navs'][4]['navname'];action-uri={echo !empty($_G['setting']['domain']['app']['home']) ? 'http://'.$_G['setting']['domain']['app']['home'] : $_G[siteurl].'home.php'};icon-uri={$_G[siteurl]}{IMGDIR}/home.ico" /><!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' && $_G['setting']['archiver']}-->
		<link rel="archives" title="$_G['setting']['bbname']" href="{$_G[siteurl]}archiver/" />
	<!--{/if}-->
	<!--{if !empty($rsshead)}-->$rsshead<!--{/if}-->
	<!--{if widthauto()}-->
		<link rel="stylesheet" id="css_widthauto" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_widthauto.css?{VERHASH}' />
		<script type="text/javascript">HTMLNODE.className += ' widthauto'</script>
	<!--{/if}-->
	<!--{if $_G['basescript'] == 'forum' || $_G['basescript'] == 'group'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}forum.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'home' || $_G['basescript'] == 'userapp'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<!--{elseif $_G['basescript'] == 'portal'}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_G['basescript'] != 'portal' && $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<script type="text/javascript" src="{$_G[setting][jspath]}portal.js?{VERHASH}"></script>
	<!--{/if}-->
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<link rel="stylesheet" type="text/css" id="diy_common" href="data/cache/style_{STYLEID}_css_diy.css?{VERHASH}" />
	<!--{/if}-->
		<script type="text/javascript" src="template/rtj1009_007/static/js/jquery-1.8.3.min.js"></script>
		<script type="text/javascript" src="template/rtj1009_007/static/js/jq_scroll.js"></script>
        <script type="text/javascript">jQuery.noConflict();</script>
		<script type="text/javascript">var jq = jQuery;</script>
        <script type="text/javascript" src="template/rtj1009_007/static/js/jquery.flexslider-min.js"></script>
</head>

<body id="nv_{$_G[basescript]}" class="pg_{CURMODULE}{if $_G['basescript'] === 'portal' && CURMODULE === 'list' && !empty($cat)} {$cat['bodycss']}{/if} rtj1009_zong" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div><div id="ajaxwaitid"></div>
	<!--{if $_GET['diy'] == 'yes' && check_diy_perm($topic)}-->
		<!--{template common/header_diy}-->
	<!--{/if}-->
	<!--{if check_diy_perm($topic)}-->
		<!--{template common/header_diynav}-->
	<!--{/if}-->
	<!--{if CURMODULE == 'topic' && $topic && empty($topic['useheader']) && check_diy_perm($topic)}-->
		$diynav
	<!--{/if}-->
	<!--{if empty($topic) || $topic['useheader']}-->
		<!--{if $_G['setting']['mobile']['allowmobile'] && (!$_G['setting']['cacheindexlife'] && !$_G['setting']['cachethreadon'] || $_G['uid']) && ($_GET['diy'] != 'yes' || !$_GET['inajax']) && ($_G['mobile'] != '' && $_G['cookie']['mobile'] == '' && $_GET['mobile'] != 'no')}-->
			<div class="xi1 bm bm_c">
			    {lang your_mobile_browser}<a href="{$_G['siteurl']}forum.php?mobile=yes">{lang go_to_mobile}</a> <span class="xg1">|</span> <a href="$_G['setting']['mobile']['nomobileurl']">{lang to_be_continue}</a>
			</div>
		<!--{/if}-->
		<!--{if $_G['setting']['shortcut'] && $_G['member'][credits] >= $_G['setting']['shortcut']}-->
			<div id="shortcut">
				<span><a href="javascript:;" id="shortcutcloseid" title="{lang close}">{lang close}</a></span>
				{lang shortcut_notice}
				<a href="javascript:;" id="shortcuttip">{lang shortcut_add}</a>

			</div>
			<script type="text/javascript">setTimeout(setShortcut, 2000);</script>
		<!--{/if}-->
        
	<div class="rtj1009_header cl">
        <!--{if $rtj1009_hd==1}-->
        <div id="toptb" class="rtj1009_top cl">
			<div class="wp rtj1009_topwp cl">
			<!--{hook/global_cpnav_top}-->
				<div class="z header_z">
                    <a id="rtj_weixin" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'43!','ctrlclass':'on','duration':2});">官方微信</a>
                    <a id="rtj_app" href="$pc_hd_mobile">手机客户端</a>
                    <!--{loop $_G['setting']['topnavs'][0] $nav}-->
                    <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
                    <!--{/loop}-->
                    <div id="rtj_weixin_menu" class="header_weixin" style="display: none; ">
                        <div class="weixin_img"></div>
                        <p> 扫一扫，关注我们 </p>
                    </div>
                    <!--{hook/global_cpnav_extra1}-->
                    <!--{hook/global_myitem_extra}-->
                </div>
				<div class="y">
            	<!--{hook/global_cpnav_extra2}-->
                   <!--{template common/header_userstatus}-->
                    <!--{loop $_G['setting']['topnavs'][1] $nav}-->
                        <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
                    <!--{/loop}-->
                </div>
			</div>
		</div>
    <!--{else}-->
    	<div id="toptbs" class="rtj1009_tops cl">
                <div class="wp rtj1009_topwps cl">
        		<!--{hook/global_cpnav_top}-->
                    <div class="z header_zs">
                        <a id="rtj_minilogo" href="./" style="padding: 0 10px 0 0;"><img src="{$_G['style']['styleimgdir']}/mini_logo.png"></a>
                        <!--{hook/global_cpnav_extra1}-->
                            <!--{loop $_G['setting']['navs'] $nav}-->
                                <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
                            <!--{/loop}-->
                        <!--{hook/global_myitem_extra}-->
                    </div>
                    <div class="y">
                	<!--{hook/global_cpnav_extra2}-->
                       <!--{template common/rtj1009_userstatus}-->
                        <!--{loop $_G['setting']['topnavs'][1] $nav}-->
                            <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
			<!--{ad/subnavbanner/a_mu}-->
        <!--{/if}-->
	</div>
    
    	<ul id="rtj_xiaoxi_menu" style="display: none;">
        	<li class="ren_top_xlkongjian"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank">我的空间</a></li>
            <li class="ren_top_xlxiaoxi"><a href="home.php?mod=space&do=pm"{if $_G[member][newpm]} class="new"{/if}>我的消息<!--{if $newpmcount}--><strong class="xi1">$newpmcount</strong><!--{/if}--></a></li>
            <!--{if $_G[member][newprompt]}-->
                <!--{loop $_G['member']['category_num'] $key $val}-->
                    <li class="ren_$key"><a href="home.php?mod=space&do=notice&view=$key"><!--{echo lang('template', 'notice_'.$key)}--><strong class="xi1">$val</strong></a></li>
                <!--{/loop}-->
            <!--{/if}-->
            <li class="ren_top_xlsoucang"><a href="home.php?mod=space&do=favorite&view=me" target="_blank">我的收藏</a></li>
            <li class="ren_top_xlhaoyou"><a href="home.php?mod=space&do=friend" target="_blank">我的好友</a></li>
            <li class="ren_top_xlxiangce"><a href="home.php?mod=space&do=album" target="_blank">我的相册</a></li>
            <li class="ren_top_xldaoju"><a href="home.php?mod=magic&action=mybox" target="_blank">我的道具</a></li>
        </ul>
        
         <ul id="rtj_shezhi_menu" style="display: none; top: 75px;">
            <li class="ren_top_xlzhsz"><a href="home.php?mod=spacecp">帐号设置</a></li>	  
            
                    
            <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
            <li class="ren_top_xlmhgl"><a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
            <!--{/if}-->
            <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
            <li class="ren_top_snlt"><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>
            <!--{/if}-->
            <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
            <li class="ren_top_xlht"><a href="admin.php" target="_blank">{lang admincp}</a></li>
            <!--{/if}-->
            <!--{if check_diy_perm($topic)}-->
            <li class="ren_top_xldiy"><a href="javascript:openDiy();" title="{lang open_diy}">DIY 设置</a></li>
            <!--{/if}-->
            <li class="ren_top_xltcdl"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">退出登录</a></li>
        </ul>
        <!--{if $rtj1009_hd==0}-->
            <ul id="rtj_sousuo_menu" style="display: none; top: 75px;">
                <div class="rtj1009_ss">
                    <!--{subtemplate common/pubsearchform}-->
                </div>
          	</ul>
		<!--{/if}-->
        	<!--{if $_G['uid'] && !empty($_G['style']['extstyle'])}-->
				<div id="ren_sslct_menu" class="cl ren_psk" style="display: none;">
					<!--{if !$_G[style][defaultextstyle]}--><span class="ren_sslct_btn" onClick="extstyle('')" title="{lang default}"><i></i><em>{lang default}</em></span><!--{/if}-->
					<!--{loop $_G['style']['extstyle'] $extstyle}-->
						<span class="ren_sslct_btn" onClick="extstyle('$extstyle[0]')" title="$extstyle[1]"><i style='background:$extstyle[2]'></i><em>{$extstyle[1]}</em></span>
					<!--{/loop}-->
                    <span class="ren_pskts">提示：您选择的风格在登录后显示！</span>
				</div>
			<!--{/if}-->
		<!--{ad/headerbanner/wp a_h}-->
        <!--{if $rtj1009_hd==1}-->
		<div id="hd">
			<div class="wp">
            	<div class="ren_headera cl">
                    <div class="hdc cl">
                        <!--{eval $mnid = getcurrentnav();}-->
                        <h3><!--{if !isset($_G['setting']['navlogos'][$mnid])}--><a href="{if $_G['setting']['domain']['app']['default']}http://{$_G['setting']['domain']['app']['default']}/{else}./{/if}" title="$_G['setting']['bbname']">{$_G['style']['boardlogo']}</a><!--{else}-->$_G['setting']['navlogos'][$mnid]<!--{/if}--></h3>
                        <div class="rtj1009_sousuo<!--{if $ren_hd_ssk ==2}--> ren-ssktu<!--{/if}--> z">
							<!--{if $ren_hd_ssk ==1}-->
							<!--{subtemplate common/pubsearchform}-->
							<!--{else}-->
							<!--{subtemplate common/ren_pubsearchform}-->
							<!--{/if}-->
                        </div>
						<!--{if $rtj1009_hd_fabu==1}-->
						<div class="y ren_list_flft cl">
							<a href="forum.php?mod=misc&amp;action=nav" onClick="showWindow('nav', this.href, 'get', 0)" class="ren_hd_fabu">免费发布信息</a>
						</div>
						<!--{/if}-->
                    </div>
                </div>
				<div id="nv" class="toubuxiabian">
                	<div class="rtj1009_nv cl">
                        <ul class="ren_nv cl">
                            <!--{loop $_G['setting']['navs'] $nav}-->
                                <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
                            <!--{/loop}-->
                        </ul>
                    </div>
					<!--{hook/global_nav_extra}-->
				</div>
				<!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
					<ul class="p_pop h_pop" id="plugin_menu" style="display: none">
					<!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
						 <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
						 <li>$module[url]</li>
						 <!--{/if}-->
					<!--{/loop}-->
					</ul>
				<!--{/if}-->
				$_G[setting][menunavs]
				<div id="mu" class="ren_nv_mu cl">
                <!--{if $_G['setting']['subnavs']}-->
                    <!--{loop $_G[setting][subnavs] $navid $subnav}-->
                        <!--{if $_G['setting']['navsubhover'] || $mnid == $navid}-->
                        <ul class="cl {if $mnid == $navid}current{/if}" id="snav_$navid" style="display:{if $mnid != $navid}none{/if}">
                        $subnav
                        </ul>
                        <!--{/if}-->
                    <!--{/loop}-->
                <!--{/if}-->
                </div>

				<!--{if $ren_hd_nav}-->
                <div class="rtj1009_nav<!--{if $rtj1009_hd_xuannav == 2}-->2<!--{/if}--><!--{if $rtj1009_hd_xuannav == 3}-->3<!--{/if}-->">
                	<!--{template common/toubu}-->
                </div>
				<!--{ad/subnavbanner/a_mu}-->
				<!--{/if}-->
			</div>
		</div>
		<!--{/if}-->
		<!--{hook/global_header}-->
	<!--{/if}-->

	<div id="wp" class="wp">

