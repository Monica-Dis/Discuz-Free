<?php echo 'From: DisM.taobao.com';exit;?>
<script type="text/javascript">
    function fixed_top_nv(eleid, disbind) {
        this.nv = eleid && $(eleid) || $('nv');
        this.openflag = this.nv && BROWSER.ie != 6;
        this.nvdata = {};
        this.init = function (disattachevent) {
            if(this.openflag) {
                if(!disattachevent) {
                    var obj = this;
                    _attachEvent(window, 'resize', function(){obj.reset();obj.init(1);obj.run();});
                    var switchwidth = $('switchwidth');
                    if(switchwidth) {
                        _attachEvent(switchwidth, 'click', function(){obj.reset();obj.openflag=false;});
                    }
                }

                var next = this.nv;
                try {
                    while((next = next.nextSibling).nodeType != 1 || next.style.display === 'none') {}
                    this.nvdata.next = next;
                    this.nvdata.height = parseInt(this.nv.offsetHeight, 10);
                    this.nvdata.width = parseInt(this.nv.offsetWidth, 10);
                    this.nvdata.left = this.nv.getBoundingClientRect().left - document.documentElement.clientLeft;
                    this.nvdata.position = this.nv.style.position;
                    this.nvdata.opacity = this.nv.style.opacity;
                } catch (e) {
                    this.nvdata.next = null;
                }
            }
        };

        this.run = function () {
            var fixedheight = 0;
            if(this.openflag && this.nvdata.next){
                var nvnexttop = document.body.scrollTop || document.documentElement.scrollTop;
                var dofixed = nvnexttop !== 0 && document.documentElement.clientHeight >= 15 && this.nvdata.next.getBoundingClientRect().top - this.nvdata.height < 0;
                if(dofixed) {
                    if(this.nv.style.position != 'fixed') {
                        this.nv.style.borderLeftWidth = '0';
                        this.nv.style.borderRightWidth = '0';
                        this.nv.style.height = this.nvdata.height + 'px';
                        this.nv.style.width = this.nvdata.width + 'px';
                        this.nv.style.top = '0';
                        this.nv.style.left = this.nvdata.left + 'px';
                        this.nv.style.position = 'fixed';
                        this.nv.style.zIndex = '199';
                        this.nv.style.opacity = 0.85;
                    }
                } else {
                    if(this.nv.style.position != this.nvdata.position) {
                        this.reset();
                    }
                }
                if(this.nv.style.position == 'fixed') {
                    fixedheight = this.nvdata.height;
                }
            }
            return fixedheight;
        };
        this.reset = function () {
            if(this.nv) {
                this.nv.style.position = this.nvdata.position;
                this.nv.style.borderLeftWidth = '';
                this.nv.style.borderRightWidth = '';
                this.nv.style.height = '';
                this.nv.style.width = '';
                this.nv.style.opacity = this.nvdata.opacity;
            }
        };
        if(!disbind && this.openflag) {
            this.init();
            _attachEvent(window, 'scroll', this.run);
        }
    }
</script>
<!--{if empty($_G['setting']['disfixednv_forumindex']) }--><script>fixed_top_nv();</script><!--{/if}-->
