<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . './template/rtj1009_007/php/rtj1009_header.php';
$addonid = 'rtj1009_007.template';
$ren_home_bgstyle = $_G['cache']['plugin']['rtj1009_democp']['ren_home_hdstyle'];
$youhuid = $space[uid];
$yonghuzuid = DB::result(DB::query('SELECT groupid FROM ' . DB::table('common_member') . (' WHERE `uid`= ' . $youhuid)));
$yonghuzu = DB::result(DB::query('SELECT grouptitle FROM ' . DB::table('common_usergroup') . (' WHERE groupid = \'' . $yonghuzuid . '\'')));
$homeyuid = $space[uid];
$jifen = DB::fetch_first('SELECT * FROM ' . DB::table('common_member_count') . (' WHERE uid=' . $homeyuid));
