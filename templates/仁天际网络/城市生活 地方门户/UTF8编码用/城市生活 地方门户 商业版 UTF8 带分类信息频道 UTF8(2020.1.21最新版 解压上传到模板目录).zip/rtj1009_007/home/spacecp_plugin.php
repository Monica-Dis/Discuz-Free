<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->
<!--{template home/spacecp_header}-->
<!--{if $op == 'credit'}-->
	<!--{template home/spacecp_credit_header}-->
<!--{/if}-->
<div class="ren_sz_z">
<!--{eval include(template($_GET['id']));}-->
</div>
</div>
</div>
<div class="rtj1009_zcd">
	<!--{template home/spacecp_footer}-->
</div>
</div>

<!--{template common/footer}-->
