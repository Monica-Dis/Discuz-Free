<?php echo 'From: DisM.taobao.com';exit;?>
<!--{eval $_G['home_tpl_titles'] = array(getstr($pic['title'], 60, 0, 0, 0, -1), $album['albumname'], '{lang album}');}-->
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->

<!--{if $_G[setting][homepagestyle]}-->
	<!--{subtemplate home/space_header}-->
	<div id="ren_ct" class="rtj1009_lai_ct cl">
            <div class="ren_lai_mn z">
                <div class="bm ren_ly_bm">
                	<div class="ren_lai_xc ren_ly_c">
						<!--{if $space[self] && helper_access::check_module('album')}--><a href="home.php?mod=spacecp&ac=upload" class="y pn pnc"><strong>{lang upload_pic}</strong></a><!--{/if}-->
						<h3>{lang album}</h3>
					</div>
			<div class="ren_bm_c ren_ly_c">
<!--{else}-->
	<!--{template common/header}-->
    
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<!--{template home/space_menu}-->
	<div id="ct" class="rtj1009_ct cl">
		<div class="ren_g_mn">
            <!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
            <div class="ren_ly_bm">
                <div class="ren_ly_c">
<!--{/if}-->

				<div class="tbmu" id="pic_block">
									<div class="y">
										<a href="javascript:;" onclick="imageRotate('pic', 1)"><img class="vm" src="{STATICURL}image/common/rleft.gif" /></a>
										<a href="javascript:;" onclick="imageRotate('pic', 2)"><img class="vm" src="{STATICURL}image/common/rright.gif" /></a><span class="pipe">|</span>
										<a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$upid&goto=up#pic_block">{lang previous_pic}</a><span class="pipe">|</span>
										<a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid&goto=down#pic_block" id="nextlink">{lang next_pic}</a><span class="pipe">|</span>
										<!--{if $_GET['play']}-->
										<a href="javascript:;" id="playid" class="osld" onclick="playNextPic(false);">{lang stop_playing}</a>
										<!--{else}-->
										<a href="javascript:;" id="playid" class="osld" onclick="playNextPic(true);">{lang start_playing}</a>
										<!--{/if}--><span id="displayNum"></span>
									</div>
									<a href="home.php?mod=space&uid=$space[uid]&do=album&id=$pic[albumid]">&laquo; {lang return_pic_list}</a>
									<!--{if $album[picnum]}--><span class="pipe">|</span>{lang current_pic}<!--{/if}-->&nbsp;
									<!--{if $album['friend']}-->
									<span class="xg1"> &nbsp; {$friendsname[$value[friend]]}</span>
									<!--{/if}-->
									<!--{hook/space_album_pic_top}-->
								</div>

								<div class="vw pic">

									<div id="photo_pic" class="c{if $pic[magicframe]} magicframe magicframe$pic[magicframe]{/if}">
										<!--{if $pic[magicframe]}-->
										<div class="pic_lb1">
											<table cellpadding="0" cellspacing="0" class="">
												<tr>
													<td class="frame_jiao frame_top_left"></td>
													<td class="frame_x frame_top_middle"></td>
													<td class="frame_jiao frame_top_right"></td>
												</tr>
												<tr>
													<td class="frame_y frame_middle_left"></td>
													<td class="frame_middle_middle">
														<!--{/if}--><a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid&goto=down#pic_block"><img src="$pic[pic]" id="pic" alt="" /></a>
														<script type="text/javascript">
															function createElem(e){
																var obj = document.createElement(e);
																obj.style.position = 'absolute';
																obj.style.zIndex = '1';
																obj.style.cursor = 'pointer';
																obj.onmouseout = function(){ this.style.background = 'none';}
																return obj;
															}
															function viewPhoto(){
																var pager = createElem('div');
																var pre = createElem('div');
																var next = createElem('div');
																var cont = $('photo_pic');
																var tar = $('pic');
																var space = 0;
																var w = tar.width/2;
																if(!!window.ActiveXObject && !window.XMLHttpRequest){
																	space = -(cont.offsetWidth - tar.width)/2;
																}
																var objpos = fetchOffset(tar);

																pager.style.position = 'absolute';
																pager.style.top = '0';
																pager.style.left = objpos['left'] + 'px';
																pager.style.top = objpos['top'] + 'px';
																pager.style.width = tar.width + 'px';
																pager.style.height = tar.height + 'px';
																pre.style.left = 0;
																next.style.right = 0;
																pre.style.width = next.style.width = w + 'px';
																pre.style.height = next.style.height = tar.height + 'px';
																pre.innerHTML = next.innerHTML = '<img src="{IMGDIR}/emp.gif" width="' + w + '" height="' + tar.height + '" />';

																pre.onmouseover = function(){ this.style.background = 'url({IMGDIR}/pic-prev.png) no-repeat 0 100px'; }
																pre.onclick = function(){ window.location = 'home.php?mod=space&uid=$pic[uid]&do=$do&picid=$upid&goto=up#pic_block'; }

																next.onmouseover = function(){ this.style.background = 'url({IMGDIR}/pic-next.png) no-repeat 100% 100px'; }
																next.onclick = function(){ window.location = 'home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid&goto=down#pic_block'; }

																//cont.style.position = 'relative';
																cont.appendChild(pager);
																pager.appendChild(pre);
																pager.appendChild(next);
															}
															$('pic').onload = function(){
																viewPhoto();
															}
														</script>
														<!--{if $pic[magicframe]}-->
													</td>
													<td class="frame_y frame_middle_right"></td>
												</tr>
												<tr>
													<td class="frame_jiao frame_bottom_left"></td>
													<td class="frame_x frame_bottom_middle"></td>
													<td class="frame_jiao frame_bottom_right"></td>
												</tr>
											</table>
										</div>
										<!--{/if}-->
									</div>

									<div class="pns mlnv vm mtm cl">
											<a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$upid&goto=up#pic_block" class="btn" title="{lang previous_pic}"><img src="{STATICURL}image/common/pic_nv_prev.gif" alt="{lang previous_pic}"/></a><!--{loop $piclist $value}--><a href="home.php?mod=space&uid=$value[uid]&do=album&picid=$value[picid]#pic_block"><img alt="" src="$value[pic]"{if $value[picid]==$picid} class="a"{/if} /></a><!--{/loop}--><a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid&goto=down#pic_block" class="btn" title="{lang next_pic}"><img src="{STATICURL}image/common/pic_nv_next.gif" alt="{lang next_pic}"/></a>
									</div>

									<div class="d bbs">
										<p id="a_set_title" class="albim_pic_title"><!--{if $pic[title]}-->$pic[title]<!--{else}--><!--{eval echo substr($pic['filename'], 0, strrpos($pic['filename'], '.'));}--><!--{/if}--><!--{if $pic[status] == 1}--><b>({lang moderate_need})</b><!--{/if}--></p>
										<p class="xg1 xs1">
											<!--{if $pic[hot]}--><span class="hot">{lang hot} <em>$pic[hot]</em></span><!--{/if}-->
											<!--{if $do=='event'}--><a href="home.php?mod=space&uid=$pic[uid]" target="_blank">$pic[username]</a><!--{/if}-->
											{lang upload_at} <!--{date($pic[dateline])}--> ($pic[size])
										</p>
										<!--{if isset($_GET['exif'])}-->
											<!--{if $exifs}-->
												<!--{loop $exifs $key $value}-->
													<!--{if $value}--><p>$key : $value</p><!--{/if}-->
												<!--{/loop}-->
											<!--{else}-->
												<p>{lang no_exif}</p>
											<!--{/if}-->
										<!--{/if}-->
										<div class="o cl bw0 xs1 pbn">
											<!--{if helper_access::check_module('share')}-->
											<a href="home.php?mod=spacecp&ac=share&type=pic&id=$pic[picid]&handlekey=sharealbumhk_{$pic[picid]}" id="a_share_$pic[picid]" onclick="showWindow(this.id, this.href, 'get', 0);" class="oshr">{lang share}</a>
											<!--{/if}-->
											<!--{hook/space_album_pic_op_extra}-->
											<!--{if $pic[uid] == $_G[uid]}-->
											<!--{if $_G[magic][frame]}-->
												<img src="{STATICURL}image/magic/frame.small.gif" alt="frame" class="vm" />
												<!--{if $pic[magicframe]}-->
												<a id="a_magic_frame" href="home.php?mod=spacecp&ac=magic&op=cancelframe&idtype=picid&id=$pic[picid]" onclick="ajaxmenu(event,this.id)">{lang cancel_frame}</a>
												<!--{else}-->
												<a id="a_magic_frame" href="home.php?mod=magic&mid=frame&idtype=picid&id=$pic[picid]" onclick="ajaxmenu(event,this.id, 1)">{lang add_frame}</a>
												<!--{/if}-->
												<span class="pipe">|</span>
											<!--{/if}-->

											<!--{/if}-->

											<!--{if $_G[uid] == $pic[uid] || checkperm('managealbum')}-->
											<a href="home.php?mod=spacecp&ac=album&op=editpic&albumid=$pic[albumid]&picid=$pic[picid]">{lang manage_pic}</a><span class="pipe">|</span>
											<a href="home.php?mod=spacecp&ac=album&op=edittitle&albumid=$pic[albumid]&picid=$pic[picid]&handlekey=edittitlehk_{$pic[picid]}" id="a_set_title" onclick="showWindow(this.id, this.href, 'get', 0);">{lang edit_description}</a>
											<!--{/if}-->

											<!--{if checkperm('managealbum')}-->
											<span class="pipe">|</span>IP: $pic[postip]{if $pic[port]}:$pic[port]{/if}
											<span class="pipe">|</span><a href="home.php?mod=spacecp&ac=album&picid=$pic[picid]&op=edithot&handlekey=picedithothk_{$pic[picid]}" id="a_hot_$pic[picid]" onclick="showWindow(this.id, this.href, 'get', 0);">{lang hot}</a>
											<!--{/if}-->
											<!--a href="home.php?mod=spacecp&ac=common&op=report&idtype=picid&id=$pic[picid]&handlekey=reportpichk_{$pic[picid]}" id="a_report" onclick="showWindow(this.id, this.href, 'get', 0);">{lang report}</a-->

											<span class="z">
												<a href="$pic[pic]" target="_blank">{lang look_pic}</a>
												<!--{if !isset($_GET['exif'])}-->
												<span class="pipe">|</span><a href="$theurl&exif=1">{lang look_exif}</a>
												<!--{/if}-->
												<!--{if $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 5)}-->
												<span class="pipe">|</span><a href="portal.php?mod=portalcp&ac=portalblock&op=recommend&idtype=picid&id=$pic[picid]" onclick="showWindow('recommend', this.href, 'get', 0)">{lang blockdata_recommend}</a>
												<!--{/if}-->
												<!--{if $pic[uid] != $_G['uid']}-->
												<span class="pipe">|</span><a href="javascript:;" onclick="showWindow('miscreport$pic[picid]', 'misc.php?mod=report&rtype=pic&uid=$pic[uid]&rid=$pic[picid]', 'get', -1);return false;">{lang report}</a>
												<!--{/if}-->
												<!--{hook/space_album_pic_bottom}-->
											</span>
										</div>
									</div>

								</div>
								<!--[diy=diyclicktop]--><div id="diyclicktop" class="area"></div><!--[/diy]-->
								<!--{if $album[friend] != 3}-->
								<div id="click_div">
									<!--{template home/space_click}-->
								</div>
								<!--{/if}-->
								<!--[diy=diycommenttop]--><div id="diycommenttop" class="area"></div><!--[/diy]-->
								<div id="pic_comment" class="bm bw0 mtm mbm">
									<h3 class="pbn bbs">
										<!--{if !empty($list)}-->
										<a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$pic[picid]#quickcommentform_{$picid}" onclick="if($('comment_message')){$('comment_message').focus();return false;}" class="y xi2 xw0">{lang publish_comment}</a>
										<!--{/if}-->
										{lang comment}
									</h3>
									<div id="comment">
										<!--{if $cid}-->
										<div class="i">
											{lang current_comment}
										</div>
										<!--{/if}-->

										<div id="comment_ul" class="xld xlda">
										<!--{loop $list $k $value}-->
											<!--{template home/space_comment_li}-->
										<!--{/loop}-->
										</div>
									</div>
									<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
								</div>
								<!--{if helper_access::check_module('album')}-->
								<form id="quickcommentform_{$picid}" name="quickcommentform_{$picid}" action="home.php?mod=spacecp&ac=comment&handlekey=qcpic_{$picid}" method="post" autocomplete="off" onsubmit="ajaxpost('quickcommentform_{$picid}', 'return_qcpic_{$picid}');doane(event);" class="bm bw0" style="width: 600px;">
									<!--{if $_G['uid']}-->
										<p>
											<span id="comment_face" onclick="showFace(this.id, 'comment_message');return false;" class="cur1"><img src="{IMGDIR}/facelist.gif" alt="facelist" class="vm" /></span>
											<!--{hook/space_album_pic_face_extra}-->
											<!--{if $_G['setting']['magicstatus'] && !empty($_G['setting']['magics']['doodle'])}-->
											<a id="a_magic_doodle" href="home.php?mod=magic&mid=doodle&showid=comment_doodle&target=comment_message" onclick="showWindow(this.id, this.href, 'get', 0)"><img src="{STATICURL}image/magic/doodle.small.gif" alt="doodle" class="vm" /> $_G['setting']['magics']['doodle']</a>
											<!--{/if}-->
										</p>
									<!--{/if}-->
									<div class="tedt mtn mbn">
										<div class="area">
											<!--{if $_G['uid'] || $_G['group']['allowcomment']}-->
												<textarea id="comment_message" onkeydown="ctrlEnter(event, 'commentsubmit_btn');" name="message" rows="3" class="pt"></textarea>
											<!--{else}-->
												<div class="pt hm">{lang login_to_comment} <a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)" class="xi2">{lang login}</a> | <a href="member.php?mod={$_G[setting][regname]}" class="xi2">$_G['setting']['reglinkname']</a></div>
											<!--{/if}-->
										</div>

									</div>
									<!--{if $secqaacheck || $seccodecheck}-->
										<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id);"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
										<div class="mtm mbm sec"><!--{subtemplate common/seccheck}--></div>
									<!--{/if}-->
									<p class="pns">
										<input type="hidden" name="refer" value="$theurl" />
										<input type="hidden" name="id" value="$picid" />
										<input type="hidden" name="idtype" value="picid" />
										<input type="hidden" name="commentsubmit" value="true" />
										<input type="hidden" name="quickcomment" value="true" />
										<button type="submit" name="commentsubmit_btn" value="true" id="commentsubmit_btn" class="pn"{if !$_G[uid]&&!$_G['group']['allowcomment']} onclick="showWindow(this.id, this.form.action);return false;"{/if}><strong>{lang comment}</strong></button>
										<span id="__quickcommentform_{$picid}"></span>
										<span id="return_qcpic_{$picid}"></span>
										<input type="hidden" name="formhash" value="{FORMHASH}" />
									</p>
								</form>
								<!--{/if}-->
						</div>


						<script type="text/javascript">
							function succeedhandle_qcpic_{$picid}(url, msg, values) {
								if(values['cid']) {
									comment_add(values['cid']);
								} else {
									$('return_qcpic_{$picid}').innerHTML = msg;
								}
								<!--{if $sechash}-->
									<!--{if $secqaacheck}-->
									updatesecqaa('$sechash');
									<!--{/if}-->
									<!--{if $seccodecheck}-->
									updateseccode('$sechash');
									<!--{/if}-->
								<!--{/if}-->
							}
						</script>

						<script type="text/javascript">
							var interval = 5000;
							var timerId = -1;
							var derId = -1;
							var replay = false;
							var num = 0;
							var endPlay = false;
							function forward() {
								window.location.href = 'home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid&goto=down&play=1#pic_block';
							}
							function derivativeNum() {
								num++;
								$('displayNum').innerHTML = '[' + (interval/1000 - num) + ']';
							}
							function playNextPic(stat) {
								if(stat || replay) {
									derId = window.setInterval('derivativeNum();', 1000);
									$('displayNum').innerHTML = '[' + (interval/1000 - num) + ']';
									$('playid').onclick = function (){replay = false;playNextPic(false);};
									$('playid').innerHTML = '{lang stop_playing}';
									timerId = window.setInterval('forward();', interval);
								} else {
									replay = true;
									num = 0;
									if(endPlay) {
										$('playid').innerHTML = '{lang restart}';
									} else {
										$('playid').innerHTML = '{lang start_playing}';
									}
									$('playid').onclick = function (){playNextPic(true);};
									$('displayNum').innerHTML = '';
									window.clearInterval(timerId);
									window.clearInterval(derId);
								}
							}
							<!--{if $_GET['play']}-->
							<!--{if $sequence && $album['picnum']}-->
							if($sequence == $album[picnum]) {
								endPlay = true;
								playNextPic(false);
							} else {
								playNextPic(true);
							}
							<!--{else}-->
							playNextPic(true);
							<!--{/if}-->
							<!--{/if}-->

							function update_title() {
								$('title_form').style.display='';
							}

							var elems = selector('dd[class~=magicflicker]');
							for(var i=0; i<elems.length; i++){
								magicColor(elems[i]);
							}
						</script>

						<!--end bm-->

				<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->
				</div>
			</div>
			<!--{if $_G[setting][homepagestyle]}-->
		<div class="rtj1009_home_sd y">
			<!--{subtemplate home/space_userabout}-->
		<!--{/if}-->
	</div>
</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->
<!--{template common/footer}-->
