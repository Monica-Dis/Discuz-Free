<?php echo 'From: DisM.taobao.com';exit;?>
<!--{subtemplate common/header_common}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<link rel="stylesheet" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_css_space.css?{VERHASH}' />
	<link id="style_css" rel="stylesheet" type="text/css" href="{STATICURL}space/{if $space[theme]}$space[theme]{else}t1{/if}/style.css?{VERHASH}">
	<style id="diy_style">$space[spacecss]</style>
</head>

<body id="space" class="rtj1009_zong" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div>
	<div id="ajaxwaitid"></div>

	<!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_007/php/spacecp_userstatus.php';}-->
	<!--{if $space['self'] && $_GET['diy'] == 'yes' && $do == 'index' }-->
	<link rel="stylesheet" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_css_diy.css?{VERHASH}' />
	<!--{subtemplate home/space_diy}-->
	<!--{/if}-->

	<div class="rtj1009_header <!--{if $ren_home_bgstyle==2}-->ren_home_bgstyle<!--{/if}-->">
        	<div id="toptbs" class="rtj1009_tops cl">
                <div class="wp rtj1009_topwps cl">
                    <div class="z header_zs">
                        <a id="rtj_minilogo" href="./" style="padding: 0 10px 0 0;"><img src="{$_G['style']['styleimgdir']}/mini_logo.png"></a>
                            <!--{loop $_G['setting']['navs'] $nav}-->
                                <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
                            <!--{/loop}-->
                        <!--{hook/global_myitem_extra}-->
                    </div>
                    <div class="y">
                       <!--{if $_G['uid']}-->
	<div class="rtj_yonghutouxiang"><a href="home.php?mod=space&uid=$_G[uid]"><!--{avatar($_G[uid],small)}--></a></div>
		<strong class="yonghuming"{if $_G['setting']['connect']['allow'] && $_G[member][conisbind]} class="qq"{/if}><a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">{$_G[member][username]}</a></strong>
                      
                              <!--{hook/global_usernav_extra1}-->

        	<a id="rtj_xiaoxi" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});"{if $_G[member][newpm] || $_G[member][newprompt]} class="ynew"{/if}>我的</a>
            <a id="rtj_shezhi" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});">设置</a>
            <a id="rtj_sousuo" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});">搜索</a>
            <!--{hook/global_usernav_extra2}-->
                      </div>
                      <!--{elseif !empty($_G['cookie']['loginuser'])}-->
                          <strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
                          <span class="pipe">|</span><a href="member.php?mod=logging&action=login" onClick="showWindow('login', this.href)">{lang activation}</a>
                          <span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
                      <!--{elseif !$_G[connectguest]}-->
                          <a id="rtj_ydenglu" href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}">登录</a>
                          <a id="rtj_yzhucen" href="member.php?mod={$_G[setting][regname]}">注册</a>
                      <!--{else}-->
                      <div id="um">
                          <div class="avt y"><!--{avatar(0,small)}--></div>
                              <strong class="vwmy qq">{$_G[member][username]}</strong>
                              <a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
                              <a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}: 0</a>
                              {lang usergroup}: $_G[group][grouptitle]
                      <!--{/if}-->
                        <!--{loop $_G['setting']['topnavs'][1] $nav}-->
                            <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
        </div>
	<!--{if $space['status'] == -1 && $_G['adminid'] == 1 }-->
		<p class="ptw xw1 xi1 hm"><img src="{IMGDIR}/locked.gif" alt="Locked" class="vm" /> {lang message_banned}</p>
	<!--{/if}-->
	<!--{if $ren_home_bgstyle==2}-->
	<div class="rtj1009_showbg ren_bg">
		<div class="ren_header_bg"></div>
	</div>
	<!--{/if}-->
	<div id="rtj1009_mn_u" class="rtj1009_menu">
		<div class="rtj1009_menu_nv">
			<!--{eval space_merge($space, 'field_home'); $space[domainurl] = space_domain($space);getuserdiydata($space);$personalnv = isset($_G['blockposition']['nv']) ? $_G['blockposition']['nv'] : '';}-->
            <!--{if CURMODULE == 'follow'}-->
            <!--{subtemplate home/follow_user_header}-->
              <!--{elseif !$space[self]}-->
              <div class="ren_menu_mn">
                  <ul>
                      <div class="ren_mt">
                          <span>{$space[username]}</span>
                      </div>
                      <!--{if helper_access::check_module('follow')}-->
                      <li class="ren_addflw z">
                          <!--{if !ckfollow($space['uid'])}-->
                              <a id="followmod" onClick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"><span>关注</span></a>
                          <!--{else}-->
                              <a id="followmod" onClick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]">取消关注</a>
                          <!--{/if}-->
                      </li>
                      <!--{/if}-->
                      <li class="ren_pm2 z">
                          <a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onClick="showWindow('showMsgBox', this.href, 'get', 0)" title="{lang send_pm}">{lang send_pm}</a>
                      </li>
                  </ul>
                  <!--{if helper_access::check_module('follow')}-->
                  <script type="text/javascript">
                  function succeedhandle_followmod(url, msg, values) {
                      var fObj = $('followmod');
                      if(values['type'] == 'add') {
                          fObj.innerHTML = '关注';
                          fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
                      } else if(values['type'] == 'del') {
                          fObj.innerHTML = '取消关注';
                          fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
                      }
                  }
                  </script>
                  <!--{/if}-->
              </div>
              <!--{/if}-->
            <!--{eval $konguid = $space[uid];}-->
			<!--{eval $guangbo = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid=$konguid");}-->
            <div class="z rtj1009_icn cl">
                <div class="ren_icn rtj_avt"><a href="home.php?mod=space&uid=$space[uid]"><!--{avatar($space[uid],big)}--></a></div>
                <!--{if helper_access::check_module('follow')}-->
                <ul class="ren_gb">
                    <li>
                        <a href="home.php?mod=follow&do=following&uid=$uid" target="_blank"><p>$guangbo['following']</p><span>关注</span></a>
                    </li>
                    <li>
                        <a href="home.php?mod=follow&do=follower&uid=$uid" target="_blank"><p>$guangbo['follower']</p><span>粉丝</span></a>
                    </li>
                </ul>
                <!--{/if}-->
        	</div>
		</div>
		<!--{subtemplate home/space_header_personalnv}-->
	</div>
		<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
		<ul id="usermanageli_menu" class="p_pop" style="width: 80px; display:none;">
			<!--{if checkperm('allowbanuser')}-->
				<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" target="_blank">{lang user_ban}</a></li>
			<!--{/if}-->
			<!--{if checkperm('allowedituser')}-->
				<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" target="_blank">{lang user_edit}</a></li>
			<!--{/if}-->
		</ul>
		<!--{/if}-->
		
		<!--{if $_G['adminid'] == 1}-->
		<ul id="umanageli_menu" class="p_pop" style="width: 80px; display:none;">
			<li><a href="forum.php?mod=modcp&action=thread&op=post&searchsubmit=1&do=search&users=$encodeusername" target="_blank">{lang manage_post}</a></li>
			<!--{if helper_access::check_module('doing')}-->
				<li><a href="admin.php?action=doing&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_doing}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('blog')}-->
				<li><a href="admin.php?action=blog&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_blog}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('feed')}-->
				<li><a href="admin.php?action=feed&searchsubmit=1&detail=1&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_feed}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('album')}-->
				<li><a href="admin.php?action=album&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_album}</a></li>
				<li><a href="admin.php?action=pic&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_pic}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('wall')}-->
				<li><a href="admin.php?action=comment&searchsubmit=1&detail=1&fromumanage=1&authorid=$space[uid]" target="_blank">{lang manage_comment}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('share')}-->
				<li><a href="admin.php?action=share&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_share}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('group')}-->
				<li><a href="admin.php?action=threads&operation=group&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_threads}</a></li>
				<li><a href="admin.php?action=prune&searchsubmit=1&detail=1&operation=group&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_prune}</a></li>
			<!--{/if}-->
		</ul>
		<!--{/if}-->

		<ul id="rtj_xiaoxi_menu" style="display: none;">
        	<li class="ren_top_xlkongjian"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank">我的空间</a></li>
            <li class="ren_top_xlxiaoxi"><a href="home.php?mod=space&do=pm"{if $_G[member][newpm]} class="new"{/if}>我的消息<!--{if $newpmcount}--><strong class="xi1">$newpmcount</strong><!--{/if}--></a></li>
            <!--{if $_G[member][newprompt]}-->
                <!--{loop $_G['member']['category_num'] $key $val}-->
                    <li class="ren_$key"><a href="home.php?mod=space&do=notice&view=$key"><!--{echo lang('template', 'notice_'.$key)}--><strong class="xi1">$val</strong></a></li>
                <!--{/loop}-->
            <!--{/if}-->
            <li class="ren_top_xlsoucang"><a href="home.php?mod=space&do=favorite&view=me" target="_blank">我的收藏</a></li>
            <li class="ren_top_xlhaoyou"><a href="home.php?mod=space&do=friend" target="_blank">我的好友</a></li>
            <li class="ren_top_xlxiangce"><a href="home.php?mod=space&do=album" target="_blank">我的相册</a></li>
        </ul>
        
         <ul id="rtj_shezhi_menu" style="display: none; top: 75px;">
            <li class="ren_top_xlzhsz"><a href="home.php?mod=spacecp">帐号设置</a></li>	  
            <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
            <li class="ren_top_xlmhgl"><a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
            <!--{/if}-->
            <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
            <li class="ren_top_snlt"><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>
            <!--{/if}-->
            <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
            <li class="ren_top_xlht"><a href="admin.php" target="_blank">{lang admincp}</a></li>
            <!--{/if}-->
            <!--{if check_diy_perm($topic)}-->
            <li class="ren_top_xldiy"><a href="javascript:openDiy();" title="{lang open_diy}">DIY 设置</a></li>
            <!--{/if}-->
            <li class="ren_top_xltcdl"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">退出登录</a></li>
        </ul>
        
		<ul id="rtj_sousuo_menu" style="display: none; top: 75px;">
			<div class="rtj1009_ss">
			  <!--{subtemplate common/pubsearchform}-->
			</div>
		</ul>
</ul>

