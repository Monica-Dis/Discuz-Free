<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . './source/plugin/rtj1009_democp/rtj1009_democp_core.php';
$addonid = 'rtj1009_democp.plugin';
if (file_exists(DISCUZ_ROOT . './source/plugin/rtj1009_democp/function.php')) {
	@(include_once DISCUZ_ROOT . './source/plugin/rtj1009_democp/function.php');
} else {
	exit('Access Denied');
}
$act = daddslashes($_GET['act']);
if (!$act) {
	$perpage = max(20, empty($_GET['perpage']) ? 10 : intval($_GET['perpage']));
	$start = ($page - 1) * $perpage;
	$count = get_forum_count();
	$forum = get_forum_list($start, $perpage);
	$mpurl = ADMINSCRIPT . '?' . $plug_url . 'rtj1009_forumdisplay';
	$multipage = multi($count, $perpage, $page, $mpurl, 0, 100);
	$bids = get_style_list();
	foreach ($bids as $row) {
		$fids[$row['bid']] = $row;
	}
	showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_democp&pmod=rtj1009_forumdisplay&act=add', 'enctype');
	echo '<input type="hidden" name="id" value="' . $fid . '"/>';
	showtableheader(lang('plugin/rtj1009_democp', 'rtj1009_001'));
	echo '<tr class="header"><th>' . lang('plugin/rtj1009_democp', 'rtj1009_019') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_003') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_004') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_005') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_006') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_007') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_018') . '</th><th>' . lang('plugin/rtj1009_democp', 'rtj1009_021') . '</th><th></th></tr>';
	foreach ($forum as $list) {
		$check0 = $fids[$list['fid']]['style'] == 0 ? 'checked="checked"' : '';
		$check1 = $fids[$list['fid']]['style'] == 1 ? 'checked="checked"' : '';
		$check2 = $fids[$list['fid']]['style'] == 2 ? 'checked="checked"' : '';
		$check3 = $fids[$list['fid']]['style'] == 3 ? 'checked="checked"' : '';
		$check4 = $fids[$list['fid']]['style'] == 4 ? 'checked="checked"' : '';
		$check5 = $fids[$list['fid']]['style'] == 5 ? 'checked="checked"' : '';
		$name = 'style' . $list['fid'] . '';
		echo '<tr class="hover">' . '<th>' . $list['fid'] . '</th>' . '<th>' . $list['name'] . '</th>' . '<th><input type="radio" name="upbid[' . $list['fid'] . ']" value="0" ' . $check0 . '/></th>' . '<th><input type="radio" name="upbid[' . $list['fid'] . ']" value="1" ' . $check1 . '/></th>' . '<th><input type="radio" name="upbid[' . $list['fid'] . ']" value="2" ' . $check2 . '/></th>' . '<th><input type="radio" name="upbid[' . $list['fid'] . ']" value="3" ' . $check3 . '/></th>' . '<th><input type="radio" name="upbid[' . $list['fid'] . ']" value="4" ' . $check4 . '/></th>' . '<th><input type="radio" name="upbid[' . $list['fid'] . ']" value="5" ' . $check5 . '/></th>' . '</tr>';
	}
	showtablefooter();
	showsubmit('submit', lang('plugin/rtj1009_democp', 'rtj1009_013'), '', '', $multipage);
	showformfooter();
} else {
	if ($act == 'add') {
		$data = array();
		$data['bid'] = $_GET['upbid'];
		foreach ($data['bid'] as $key => $val) {
			$bid = intval($key);
			$cubid = get_style_bid($bid);
			if ($cubid) {
				$condition = 'bid = ' . $key . '';
				$data1 = array('bid' => $key, 'style' => intval($val));
				update($data1, $condition);
			} else {
				$data1 = array('bid' => $key, 'style' => intval($val));
				insert($data1);
			}
		}
		cpmsg(lang('plugin/rtj1009_democp', 'cr_cg'), $plug_url . 'rtj1009_forumdisplay', 'succeed');
	}
}