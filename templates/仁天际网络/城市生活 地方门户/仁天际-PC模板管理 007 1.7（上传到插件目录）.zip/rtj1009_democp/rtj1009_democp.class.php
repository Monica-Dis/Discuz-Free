<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_rtj1009_democp
{
	public function global_header()
	{
		global $_G;
		global $style;
		global $config;
		loadcache('plugin');
		$config = $_G['cache']['plugin']['rtj1009_democp'];
		if ($_G[fid] && CURMODULE == 'forumdisplay') {
			$style = $this->get_style_value();
		}
	}
	public function get_style_value()
	{
		global $_G;
		$style = DB::fetch_first('SELECT * FROM ' . DB::table('rtj1009_style') . (' WHERE bid=\'' . $_G['fid'] . '\' '));
		return $style;
	}
	public function discuzcode()
	{
		require_once libfile('function/rtj1009_vedio', 'plugin/rtj1009_democp');
		global $_G;
		$config = $_G['cache']['plugin']['rtj1009_democp'];
		if ($config['pc_video_radio']) {
			if (strstr($_G['discuzcodemessage'], '[/media]')) {
				$_G['discuzcodemessage'] = preg_replace_callback("/\\[media=([\\w,]+)\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/media\\]/i", 'rtj1009_vedio', $_G['discuzcodemessage']);
			}
			if (strstr($_G['discuzcodemessage'], '[/video]')) {
				$_G['discuzcodemessage'] = preg_replace_callback("/\\[media=([\\w,]+)\\]\\s*([^\\[\\<\r\n]+?)\\s*\\[\\/media\\]/i", 'rtj1009_vedio', $_G['discuzcodemessage']);
			}
		}
	}
}