<?php

/**
 *      [�����-PCģ�����] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: yingyong.inc.php 2017-08-10 18:07:44Z rtj1009_democp $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
//From: Dism��taobao��com
?>

<script type="text/javascript">location.href="http://dism.taobao.com/?@24863.developer";</script>