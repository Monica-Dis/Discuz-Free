<?php echo 'From: DisM.taobao.com';exit;?>
{eval 
$icons = array(
	0 => '{lang poke_0}',
	1 => '<img alt="cyx" src="'.STATICURL.'image/poke/cyx.gif" class="vm" /> {lang poke_1}',
	2 => '<img alt="wgs" src="'.STATICURL.'image/poke/wgs.gif" class="vm" /> {lang poke_2}',
	3 => '<img alt="wx" src="'.STATICURL.'image/poke/wx.gif" class="vm" /> {lang poke_3}',
	4 => '<img alt="jy" src="'.STATICURL.'image/poke/jy.gif" class="vm" /> {lang poke_4}',
	5 => '<img alt="pmy" src="'.STATICURL.'image/poke/pmy.gif" class="vm" /> {lang poke_5}',
	6 => '<img alt="yb" src="'.STATICURL.'image/poke/yb.gif" class="vm" /> {lang poke_6}',
	7 => '<img alt="fw" src="'.STATICURL.'image/poke/fw.gif" class="vm" /> {lang poke_7}',
	8 => '<img alt="nyy" src="'.STATICURL.'image/poke/nyy.gif" class="vm" /> {lang poke_8}',
	9 => '<img alt="gyq" src="'.STATICURL.'image/poke/gyq.gif" class="vm" /> {lang poke_9}',
	10 => '<img alt="dyx" src="'.STATICURL.'image/poke/dyx.gif" class="vm" /> {lang poke_10}',
	11 => '<img alt="yw" src="'.STATICURL.'image/poke/yw.gif" class="vm" /> {lang poke_11}',
	12 => '<img alt="ppjb" src="'.STATICURL.'image/poke/ppjb.gif" class="vm" /> {lang poke_12}',
	13 => '<img alt="yyk" src="'.STATICURL.'image/poke/yyk.gif" class="vm" /> {lang poke_13}'
);
}