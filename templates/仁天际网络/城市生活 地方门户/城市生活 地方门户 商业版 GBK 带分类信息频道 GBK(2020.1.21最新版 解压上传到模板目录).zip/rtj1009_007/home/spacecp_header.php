<?php echo 'From: DisM.taobao.com';exit;?>

<div id="ct" class="rtj1009_ct2 cl">
	<div class="rtj1009_sz_mn">
		<div class="ren_sz_bm">
			<div class="ren_sz_bt"><h3><!--{subtemplate home/spacecp_header_name}--></h3></div>
<!--don't close the div here-->