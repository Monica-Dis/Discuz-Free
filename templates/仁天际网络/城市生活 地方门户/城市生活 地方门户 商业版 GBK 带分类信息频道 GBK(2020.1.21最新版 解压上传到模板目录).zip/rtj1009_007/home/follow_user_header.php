<?php echo 'From: DisM.taobao.com';exit;?>
<div class="flw_hd">
	
<!--{if !$viewself}-->
	<div class="ren_mtm o cl">
    	<div class="ren_mt">
			<span>{$space[username]}</span>
		</div>
		<div id="followflag" class="ren_addflw z" {if !isset($flag[$_G['uid']])}style="display: none"{/if}>
			<a id="a_followmod_{$uid}" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$uid&from=head" onclick="ajaxget(this.href);doane(event);">ȡ����ע</a>
		</div>
		<div id="unfollowflag" class="ren_addflw z" {if isset($flag[$_G['uid']])}style="display: none"{/if}>
			<!--{if isset($flag[$uid])}-->
			<span class="z flw_status_1">TA��ע����</span>
			<!--{/if}-->
			<!--{if helper_access::check_module('follow')}-->
			<a id="a_followmod_{$uid}" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$uid&from=head" onclick="ajaxget(this.href);doane(event);" class="ren_fol_gz"><span>��ע</span></a>
			<!--{/if}-->
		</div>
        <div class="ren_pm2 z">
				<a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onclick="showWindow('showMsgBox', this.href, 'get', 0)" title="{lang send_pm}">{lang send_pm}</a>
		</div>
	</div>
<!--{/if}-->
</div>