<?php echo 'From: DisM.taobao.com';exit;?>
<table cellspacing="0" cellpadding="20">
	<tr><td>
	<table width="500" cellspacing="0" cellpadding="1">
		<tr><td bgcolor="#FF8E00" align="left" style="font-family:'lucida grande',tahoma,'bitstream vera sans',helvetica,sans-serif;line-height:150%;color:#FFF;font-size:24px;font-weight:bold;padding:4px">&nbsp; $_G['setting'][sitename]</th></tr>
		<tr><td bgcolor="#FF8E00">
			<table width="100%" cellspacing="0" bgcolor="#FFFFFF" cellpadding="20">
				<tr><td style="font-family:'lucida grande',tahoma,'bitstream vera sans',helvetica,sans-serif;line-height:150%;color:#000;font-size:14px;">
					{lang my_dear_friend}:
					<blockquote>$message<br></blockquote>
					<br>
					<br>$_G['setting'][sitename]
					<br><a href="{eval echo getsiteurl();}" target="_blank"><!--{eval echo getsiteurl();}--></a>
					<br><!--{date($_G[timestamp])}-->
					<br>
					<br>{lang system_email_not_replay}
				</td></tr></table>
		</td></tr></table>
	</td></tr>
</table>