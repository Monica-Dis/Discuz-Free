<?php echo 'From: DisM.taobao.com';exit;?>
<!--{template common/header}-->

<!--{if $_GET['op'] == 'show'}-->
	<!--{template home/space_click}-->
<!--{/if}-->

<!--{template common/footer}-->