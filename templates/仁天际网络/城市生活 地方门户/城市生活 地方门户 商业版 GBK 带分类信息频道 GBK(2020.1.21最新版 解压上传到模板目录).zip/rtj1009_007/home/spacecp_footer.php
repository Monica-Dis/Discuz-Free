<?php echo 'From: DisM.taobao.com';exit;?>

	<ul class="ren_tbn">
		<li$actives[avatar]><a href="home.php?mod=spacecp&ac=avatar">{lang memcp_avatar}</a><span>></span></li>
		<li$actives[profile]><a href="home.php?mod=spacecp&ac=profile">{lang memcp_profile}</a><span>></span></li>
		<!--{if $_G['setting']['verify']['enabled'] && allowverify() || $_G['setting']['my_app_status'] && $_G['setting']['videophoto']}-->
		<li$actives[verify]><a href="{if $_G['setting']['verify']['enabled']}home.php?mod=spacecp&ac=profile&op=verify{else}home.php?mod=spacecp&ac=videophoto{/if}">�ҵ���֤</a><span>></span></li>
		<!--{/if}-->
		<li$actives[credit]><a href="home.php?mod=spacecp&ac=credit">�ҵĻ���</a><span>></span></li>
		<li$actives[usergroup]><a href="home.php?mod=spacecp&ac=usergroup">�� �� ��</a><span>></span></li>
		<li$actives[privacy]><a href="home.php?mod=spacecp&ac=privacy">�ռ�����</a><span>></span></li>
		
		<!--{if $_G['setting']['sendmailday']}--><li$actives[sendmail]><a href="home.php?mod=spacecp&ac=sendmail">{lang memcp_sendmail}</a><span></span></li><!--{/if}-->
		<li$actives[password]><a href="home.php?mod=spacecp&ac=profile&op=password">{lang password_security}</a><span>></span></li>

		<!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}-->
		<li$actives[promotion]><a href="home.php?mod=spacecp&ac=promotion">{lang memcp_promotion}</a><span>></span></li>
		<!--{/if}-->
		<!--{if !empty($_G['setting']['plugins']['spacecp'])}-->
			<!--{loop $_G['setting']['plugins']['spacecp'] $id $module}-->
				<!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}--><li{if $_GET[id] == $id} class="a"{/if}><a href="home.php?mod=spacecp&ac=plugin&id=$id">$module[name]</a><span>></span></li><!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>