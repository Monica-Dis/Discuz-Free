<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require DISCUZ_ROOT . './template/rtj1009_007/php/rtj1009_header.php';
$addonid = 'rtj1009_007.template';
$rtj1009_democp = $_G['cache']['plugin']['rtj1009_democp'];
$rtj1009_hd_portal = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_portal'];
$rtj1009_hd_portal_list = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_portal_list'];
$rtj1009_hd_portal_view = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_portal_view'];
$rtj1009_hd_forum = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_forum'];
$rtj1009_hd_forum_list = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_forum_list'];
$rtj1009_hd_forum_view = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_forum_view'];
$rtj1009_hd_register = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_register'];
$rtj1009_hd_logging = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_logging'];
$rtj1009_hd_guide = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_guide'];
$rtj1009_hd_group = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_group'];
$rtj1009_hd_home = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_home'];
$rtj1009_hd_qita = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_qita'];
$ren_hd_nav = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_nav'];
$ren_hd_kjdl = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_kjdl'];
$ren_hd_kjdlwz = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_kjdlwz'];
$ren_ft_baxx = $_G['cache']['plugin']['rtj1009_democp']['ren_ft_baxx'];
$ren_beian = $_G['cache']['plugin']['rtj1009_democp']['pc_beian'];
$pc_hd_mobile = $_G['cache']['plugin']['rtj1009_democp']['pc_hd_mobile'];
$pc_hd_wxlogin = $_G['cache']['plugin']['rtj1009_democp']['pc_hd_wxlogin'];
$rtj1009_hd = 0;
if ($rtj1009_hd_portal == 1 && $_G['basescript'] == 'portal' && CURMODULE == 'index' || $rtj1009_hd_portal_list == 1 && $_G['basescript'] == 'portal' && CURMODULE == 'list' || $rtj1009_hd_portal_view == 1 && $_G['basescript'] == 'portal' && CURMODULE == 'view' || $rtj1009_hd_forum == 1 && $_G['basescript'] == 'forum' && CURMODULE == 'index' || $rtj1009_hd_forum_list == 1 && $_G['basescript'] == 'forum' && CURMODULE == 'forumdisplay' || $rtj1009_hd_forum_view == 1 && $_G['basescript'] == 'forum' && CURMODULE == 'viewthread' || $rtj1009_hd_register == 1 && $_G['basescript'] == 'member' && CURMODULE == 'register' || $rtj1009_hd_logging == 1 && $_G['basescript'] == 'member' && CURMODULE == 'logging' || $rtj1009_hd_guide == 1 && $_G['basescript'] == 'forum' && CURMODULE == 'guide' || $rtj1009_hd_group == 1 && $_G['basescript'] == 'group' || $rtj1009_hd_home == 1 && $_G['basescript'] == 'home' && (CURMODULE == 'space' || CURMODULE == 'spacecp') || $rtj1009_hd_qita == 1 && (($_G['basescript'] != 'portal' || CURMODULE != 'index') && ($_G['basescript'] != 'portal' || CURMODULE != 'list') && ($_G['basescript'] != 'portal' || CURMODULE != 'view') && ($_G['basescript'] != 'forum' || CURMODULE != 'index') && ($_G['basescript'] != 'forum' || CURMODULE != 'forumdisplay') && ($_G['basescript'] != 'forum' || CURMODULE != 'viewthread') && ($_G['basescript'] != 'member' || CURMODULE != 'register') && ($_G['basescript'] != 'member' || CURMODULE != 'logging') && ($_G['basescript'] != 'forum' || CURMODULE != 'guide') && $_G['basescript'] != 'group' && ($_G['basescript'] != 'home' || CURMODULE != 'space' && CURMODULE != 'spacecp') && $_G['basescript'] != 'search')) {
	$rtj1009_hd = 1;
}
$rtj1009_hd_fabu = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_fabu'];
$rtj1009_hd_xuannav = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_xuannav'];
$ren_hd_ssk = $_G['cache']['plugin']['rtj1009_democp']['ren_hd_ssk'];