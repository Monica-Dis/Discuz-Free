<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
    require_once DISCUZ_ROOT.'./template/rtj1009_010/php/rtj1009_portal.php';
    include_once libfile('function/post');
    include_once libfile('function/attachment');
    require_once DISCUZ_ROOT.'./template/rtj1009_010/php/rtj1009_list.php';
}-->

<!--{loop $portallist $key $value}-->
<!--{eval
	$value['post'] = C::t('forum_post')->fetch_all_by_tid_position($value['posttableid'],$value['tid'],1);
	$value['post'] = array_shift($value['post']);
	$ren_pic = C::t('forum_attachment_n')->count_image_by_id('tid:'.$value['post']['tid'], 'pid', $value['post']['pid']);
	$forumname = DB::result_first("SELECT name FROM ".DB::table("forum_forum")." WHERE `fid` = $value[fid]");
	$shustars = DB::fetch_first("SELECT b.* FROM ".DB::table("common_member")." a LEFT JOIN ".DB::table("common_usergroup")." b on b.groupid=a.groupid WHERE a.`uid` = '$value[authorid]'");
	$isfollowuid = DB::result_first("SELECT followuid FROM ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$value[authorid]");
}-->
<!--{eval
$imgurlx = rtj1009_imgurl($value['post']['message']);
$vediourlx = rtj1009_vedio_url($value['post']['message']);
}-->
<!--{if $rtj1009_democp['ren_portal_left']}-->
    <!--{eval $rtj1009_msg = messagecutstr(rtj1009_msg($value['post']['message']),110);}-->
<!--{else}-->
    <!--{eval $rtj1009_msg = messagecutstr(rtj1009_msg($value['post']['message']),150);}-->
<!--{/if}-->
<!--{if $ren_pic <=2}--><!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 1);}--><!--{/if}-->
<!--{if !$rtj1009_democp['ren_portal_left']}-->
<!--{if $ren_pic >=3}--><!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 4);}--><!--{/if}-->
<!--{else}-->
<!--{if $ren_pic >=3}--><!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 3);}--><!--{/if}-->
<!--{/if}-->
<!--{if $ren_pic <=2}-->
<li class="ren-index-list-liyi">
    <div class="ren-index-list-yiimg">
        <!--{if $valuelistimg || $imgurlx}-->
        <a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren-index-threadimg z">
            <!--{if $valuelistimg}-->
				<!--{loop $valuelistimg $values}-->
					<!--{if !$rtj1009_democp['ren_portal_left']}-->
						<!--{eval $renlistimgkey = getforumimg($values[aid], 0, 197, 135); }-->
					<!--{else}-->
						<!--{eval $renlistimgkey = getforumimg($values[aid], 0, 201, 135); }-->
					<!--{/if}-->
					<!--{if $values['remote'] == 1}-->
						<span class="ren-thread-imge ren-thread-img ren-remote-img"><img src="{eval echo ftpattachurl($values['aid'])}" alt="$value[subject]"/></span>
					<!--{else}-->
						<span class="ren-thread-imge ren-thread-img"><img src="$renlistimgkey" alt="$value[subject]"/></span>
					<!--{/if}-->
				<!--{/loop}-->
            <!--{elseif $imgurlx}-->
            	<!--{eval echo $imgurlx;}-->
            <!--{/if}-->
        </a>
        <!--{/if}-->
        <div class="ren-index-xx-bt yi">
            <a href="forum.php?mod=viewthread&tid=$value[tid]">{$value[subject]}</a>
        </div>
        <div class="ren-index-xx-msg">
            <!--{if $value['post']['message']}-->
            <a href="forum.php?mod=viewthread&tid=$value[tid]"><!--{eval echo $rtj1009_msg}--></a>
            <!--{/if}-->
        </div>
        <div class="ren-index-us cl">
            <!--{if $rtj1009_democp['ren_portal_lzforums']}-->
            <div class="ren-index-lzforums z">
                <a href="forum.php?mod=forumdisplay&fid=$value[fid]">{$forumname}</a>
            </div>
            <!--{/if}-->
            <a href="<!--{if !$value['anonymous']}-->home.php?mod=space&uid=$value[authorid]<!--{else}-->javascript:;<!--{/if}-->" class="ren-index-us-img z cl">
				<!--{if !$value['authorid'] || $value['anonymous']}-->
					<!--{avatar(0, avatar_middle)}-->
				<!--{else}-->
					<!--{avatar($value[authorid],middle)}-->
				<!--{/if}-->
            </a>
            <a href="<!--{if !$value['anonymous']}-->home.php?mod=space&uid=$value[authorid]<!--{else}-->javascript:;<!--{/if}-->" class="ren-index-us-name z cl">
				<!--{if !$value['anonymous']}-->
					$value[author]
				<!--{else}-->
					����
				<!--{/if}-->
			</a>
            <span class="time z"><!--{echo dgmdate($value[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
            <a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren-index-us-sun y">
                <span class="reply y">{$value[replies]}</span>
                <span class="views y">{$value[views]}</span>
            </a>
        </div>
    </div>
</li>
<!--{else}-->
<li class="ren-index-list-lisan">
    <div class="ren-index-list-sanimg">
        <div class="ren-index-xx-bt">
            <a href="forum.php?mod=viewthread&tid=$value[tid]">{$value[subject]}</a>
        </div>
        <div class="ren-index-threadimg">
            <!--{if ($valuelistimg || $imgurlx) && !$vediourlx}-->
            <!--{if $valuelistimg}-->
            <a href="forum.php?mod=viewthread&tid=$value[tid]">
                <!--{loop $valuelistimg $values}-->
					<!--{if !$rtj1009_democp['ren_portal_left']}-->
						<!--{eval $renlistimgkey = getforumimg($values[aid], 0, 197, 135); }-->
					<!--{else}-->
						<!--{eval $renlistimgkey = getforumimg($values[aid], 0, 201, 135); }-->
					<!--{/if}-->
					<!--{if $values['remote'] == 1}-->
						<span class="ren-thread-imge ren-thread-img ren-remote-img"><img src="{eval echo ftpattachurl($values['aid'])}" alt="$value[subject]"/></span>
					<!--{else}-->
						<span class="ren-thread-imge ren-thread-img"><img src="$renlistimgkey" alt="$value[subject]"/></span>
					<!--{/if}-->
                <!--{/loop}-->
            </a>
            <!--{elseif $imgurlx}-->
            <a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_threadimg imgurltu y">
                <!--{eval echo $imgurlx;}-->
            </a>
            <!--{/if}-->
            <!--{/if}-->
        </div>
        <div class="ren-index-us cl">
            <!--{if $rtj1009_democp['ren_portal_lzforums']}-->
            <div class="ren-index-lzforums z">
                <a href="forum.php?mod=forumdisplay&fid=$value[fid]">{$forumname}</a>
            </div>
            <!--{/if}-->
			<a href="<!--{if !$value['anonymous']}-->home.php?mod=space&uid=$value[authorid]<!--{else}-->javascript:;<!--{/if}-->" class="ren-index-us-img z cl">
				<!--{if !$value['authorid'] || $value['anonymous']}-->
				<!--{avatar(0, avatar_middle)}-->
				<!--{else}-->
				<!--{avatar($value[authorid],middle)}-->
				<!--{/if}-->
			</a>
			<a href="<!--{if !$value['anonymous']}-->home.php?mod=space&uid=$value[authorid]<!--{else}-->javascript:;<!--{/if}-->" class="ren-index-us-name z cl">
				<!--{if !$value['anonymous']}-->
				$value[author]
				<!--{else}-->
				����
				<!--{/if}-->
			</a>
            <span class="time z"><!--{echo dgmdate($value[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
            <a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren-index-us-sun y">
                <span class="reply y">{$value[replies]}</span>
                <span class="views y">{$value[views]}</span>
            </a>
        </div>
    </div>
</li>
<!--{/if}-->
<!--{/loop}-->


