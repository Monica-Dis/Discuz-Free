<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{hook/global_userabout_top $_G['basescript'].'::'.CURMODULE}-->
<ul class="ren_tbn ren_bjxc">
	<!--{loop $_G['setting']['spacenavs'] $nav}-->
		<!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->			
			$nav[code]
		<!--{/if}-->
	<!--{/loop}-->
</ul>
<!--{hook/global_userabout_bottom $_G['basescript'].'::'.CURMODULE}-->
