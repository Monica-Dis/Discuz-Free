<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $_GET['op'] == 'resend'}-->

<h3 class="flb">
	<em id="return_$_GET[handlekey]">{lang send_mail_again}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>
<form id="resendform_{$id}" name="resendform_{$id}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=invite&op=resend&id=$id" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="resendsubmit" value="true" />
	<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="c">{lang sure_resend}</div>
	<p class="o pns">
		<button type="submit" name="btnsubmit" value="true" class="pn pnc"><strong>{lang resend}</strong></button>
	</p>
</form>
<script type="text/javascript">
	function succeedhandle_$_GET[handlekey](url, msg, values) {
		if(typeof resend_mail == 'function' && parseInt(values['id'])) {
			resend_mail(values['id']);
		}
	}
</script>
<!--{elseif $_GET['op'] == 'delete'}-->
<h3 class="flb">
	<em id="return_$_GET[handlekey]">{lang delete_log}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>
<form id="deleteform_{$id}" name="deleteform_{$id}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=invite&op=delete&id=$id" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="deletesubmit" value="true" />
	<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<div class="c">{lang delete_log_message}</div>
	<p class="o pns">
		<button type="submit" name="btnsubmit" value="true" class="pn pnc"><strong>{lang delete}</strong></button>
	</p>
</form>
<script type="text/javascript">
	function succeedhandle_$_GET[handlekey](url, msg, values) {
		if(typeof resend_mail == 'function' && parseInt(values['id'])) {
			resend_mail(values['id']);
		}
	}
</script>
<!--{elseif $_GET['op'] == 'showinvite'}-->
	<!--{loop $list $key $url}-->
	<tr>
		<td class="bbda"><a href="$url" onclick="setCopy('$url', '{lang copy_invite_link}');return false;">$url</a> &nbsp;<a href="$url" onclick="setCopy('$url', '{lang copy_invite_link}');return false;" class="xi2">[{lang copy}]</a></td>
		<td class="bbda"><a href="javascript:;" onclick="setCopy('$key', '{lang copy_invite_code}');return false;">$key</a> &nbsp;<a href="javascript:;" onclick="setCopy('$key', '{lang copy_invite_code}');return false;" class="xi2">[{lang copy}]</a></td>
	</tr>
	<!--{/loop}-->
<!--{else}-->



<div id="ct" class="rtj1009_ct2 cl">
	<div class="rtj1009_sz_mn">
		<div class="ren_sz_bm">
            <div class="ren_sz_bt"><h3>{lang invite_friend}</h3></div>
		<div class="ren_sz_z">
			<!--{if $allowinvite}-->
			<form method="post" id="newinvite" autocomplete="off" action="home.php?mod=spacecp&ac=invite&appid=$appid&ref" onsubmit="ajaxpost(this.id, 'return_newinvite');doane(event);">
				<!--{if $config[inviteaddcredit] || $config[invitedaddcredit]}-->
				<p class="tbmu">
					{lang friend_invite_success}
					<!--{if $config[invitedaddcredit]}-->{lang you_get} <strong class="xi1">$config[invitedaddcredit]</strong> {lang unit}{$credittitle},<!--{/if}-->
					<!--{if $config[inviteaddcredit]}-->{lang friend_get} <strong class="xi1">$config[inviteaddcredit]</strong> {lang unit}{$credittitle},<!--{/if}-->
					{lang go_nuts}
				</p>
				<!--{/if}-->
				<!--{if $flist}-->
					<div class="tbmu">
					<h2 class="mbm">{lang invited_friend}</h2>
					<!--{if $invitedcount < 24}-->
					<ul class="ml mls cl">
						<!--{loop $flist $key $value}-->
						<li>
							<div class="avt"><a href="home.php?mod=space&uid=$value[fuid]" c="1"><!--{avatar($value[fuid],small)}--></a></div>
							<p><a href="home.php?mod=space&uid=$value[fuid]" title="$value[fusername]">$value[fusername]</a></p>
						</li>
						<!--{/loop}-->
					</ul>
					<!--{else}-->
					<p>
					<!--{eval $mod='';}-->
					<!--{loop $flist $key $value}-->
					$mod<a href="home.php?mod=space&uid=$value[fuid]" title="$value[fusername]">$value[fusername]</a>
					<!--{eval $mod=', ';}-->
					<!--{/loop}-->
					</p>
					<!--{/if}-->
					</div>
				<!--{/if}-->

				<!--{if $maillist}-->
					<div class="tbmu">
						<h2 class="mbm">{lang no_invite_friend_email}</h2>
						<ul class="xl xl1">
							<!--{loop $maillist $key $value}-->
							<li id="sendmail_$value[id]_li">
								<em>
									<a href="home.php?mod=spacecp&ac=invite&op=resend&id=$value[id]&handlekey=resendinvitehk_{$value[id]}" id="mail_invite_$value[id]" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang resend}">{lang resend}</a>
									<a href="javascript:;" title="{lang link}" onclick="setCopy('$value[url]', '{lang copy_invite_link}');return false;">{lang link}</a>
									<a href="home.php?mod=spacecp&ac=invite&op=delete&id=$value[id]&handlekey=deleteinvitehk_{$value[id]}" id="del_invite_$value[id]" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang delete}">{lang delete}</a>
								</em>
								$value[email]
							</li>
							<!--{/loop}-->
						</ul>
					</div>
				<!--{/if}-->
				<table cellspacing="0" cellpadding="0" width="100%" class="tfm mbm">
					<caption class="cl">
					<!--{if $appid}-->
						<div class="avt z" style="margin-right: 5px;"><img src="http://appicon.manyou.com/logos/{$appid}" alt="{$appinfo[appname]}" /></div>
						<h2 class="wx">{lang friend_invite_play}$appinfo[appname]</h2>
					<!--{else}-->
						<h2 class="wx">{lang friend_invite_link}</h2>
					<!--{/if}-->
						<p class="mtn mbn">{lang friend_invite_message}</p>
						<!--{if $creditnum && $list}--><p>{lang click_link_copy}</p><!--{/if}-->
					</caption>
							<tbody id="invitelist">
								<!--{if $list}-->
									<!--{loop $list $key $url}-->
									<tr>
										<td class="bbda"><a href="$url" onclick="setCopy('$url', '{lang copy_invite_link}');return false;">$url</a> &nbsp;<a href="$url" onclick="setCopy('$url', '{lang copy_invite_link}');return false;" class="xi2">[{lang copy}]</a></td>
										<td class="bbda"><a href="javascript:;" onclick="setCopy('$key', '{lang copy_invite_code}');return false;">$key</a> &nbsp;<a href="javascript:;" onclick="setCopy('$key', '{lang copy_invite_code}');return false;" class="xi2">[{lang copy}]</a></td>
									</tr>
									<!--{/loop}-->
								<!--{/if}-->
							</tbody>

						<tr>
							<td colspan="2">
								<p class="mtm">{lang invitation_code_spend}{$extcredits[title]} <strong class="xi1">$creditnum</strong> $extcredits[unit] ( {lang you_have}$extcredits[title] <strong id="haveallcredit">{$space[$creditkey]}</strong> $extcredits[unit] )<!--{if $space[$creditkey] < $creditnum}--><span><a href="home.php?mod=spacecp&ac=credit" target="_blank" class="xi2">{lang credit_recharge}</a></span><!--{/if}--></p>
								<!--{if $_G['group']['maxinviteday']}-->
								<p class="d">{lang max_invite_day_message}</p>
								<!--{/if}-->
								<input type="text" name="invitenum" value="1" size="10" class="px vm" style="width: auto;" />
								<button type="submit" name="invitesubmit_btn" value="true" class="pn vm"><em>{lang get_invitation_code}</em></button>
								<span id="return_newinvite" style="display:none;"></span>
								<script type="text/javascript">
									function succeedhandle_newinvite(url, message, values) {
										if(values['deduction']) {
											var allCreditObj = $('haveallcredit');
											allCreditObj.innerHTML = parseInt(allCreditObj.innerHTML) - parseInt(values['deduction']);
											var x = new Ajax();
											x.get('home.php?mod=spacecp&ac=invite&op=showinvite&inajax=1', function(s){
												ajaxinnerhtml($('invitelist'), s);
					   						});
											showCreditPrompt();
										}
									}
								</script>
							</td>
						</tr>
					<!--{if !$creditnum}-->
						<tr>
							<td>
								{lang copy_invite_manage}: <a onclick="setCopy('$inviteurl', '{lang copy_invite_link}');return false;" href="$inviteurl" class="xw1">$inviteurl</a> &nbsp;<a onclick="setCopy('$inviteurl', '{lang copy_invite_link}');return false;" href="$inviteurl" class="xw1 xi2">[{lang copy}]</a>
							</td>
						</tr>
					<!--{/if}-->
				</table>
				<input type="hidden" name="handlekey" value="newinvite" />
				<input type="hidden" name="invitesubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			</form>
			<!--{if $_G['group']['allowmailinvite']}-->
			<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=invite&type=mail&appid=$appid&ref">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<h2 class="xs2">{lang send_invitation_email}<!--{if $appid}-->{lang friend_play_together}$appinfo[appname]<!--{/if}--></h2>
				<div class="mtn bm bmn">
					<script type="text/javascript" src="http://widgets.manyou.com/misc/scripts/ab.js" charset=gbk></script>
					<table cellspacing="0" cellpadding="0" class="tfm mbm">
						<caption>
							<p>{lang send_invitation_email_message}</p>
						</caption>
						<tr>
							<td>
								<p class="d">
									<a class="mbn y" href="#" onclick="MYABC.showChooser('email', '{$uri}api/manyou/getmaillist.htm', null, false, false, null); return false"><img src="http://widgets.manyou.com/misc/images/ab/ab_button.gif" alt="{lang add_from_address_book}" /></a>
									{lang friend_email_address}
								</p>
								<textarea name="email" id="email" rows="3" class="pt" style="width:99%;"></textarea>
							</td>
						</tr>
						<tr>
							<td>
								<p class="d">{lang friend_to_say}</p>
								<input type="text" name="saymsg" id="saymsg" onkeyup="showPreview(this.value, 'sayPreview')" class="px" style="width:99%;">
							</td>
						</tr>
						<tr>
							<td><button type="submit" name="emailinvite" value="true" class="pn pnc"><strong>{lang invite}</strong></button></td>
						</tr>
					</table>
				</div>
				<h2 class="mtw xs2">{lang preview_invitation}</h2>
				<div class="mtn bm bmn">
					<table cellspacing="0" cellpadding="0" width="100%" class="tfm" style="table-layout: fixed;">
						<tr>
							<td valign="top" width="140"><div class="avt avtm">{$mailvar[avatar]}</div></td>
							<td valign="top">
							<!--{if $appid}-->
								<h4>{lang i_play_invite_you}</h4>
							<!--{else}-->
								<h4>{lang hi_iam_invite_you}</h4>
								<p class="mtm">{lang become_friend_message}<p>
							<!--{/if}-->
								<p class="mtm">{lang invite_add_note}:</p>
								<p id="sayPreview" class="exfm" style="width: 420px;"></p>
								<h4 class="mtm">{lang click_link_become_friend}<!--{if $appid}-->{lang play_together}$appinfo[appname]<!--{/if}-->:</h4>
								<p>{$inviteurl}</p>
								<h4 class="mtm">{lang have_account_view_homepage}</h4>
								<p>{$mailvar[siteurl]}home.php?mod=space&uid=$mailvar[uid]</p>
							</td>
						</tr>
					</table>
				</div>
			</form>
			<!--{/if}-->

<!--{else}-->
			<div class="emp">{lang no_right_invite_friend}</div>
<!--{/if}-->
		</div>
	</div>
</div>
	<div class="rtj1009_zcd">
		<!--{subtemplate home/space_friend_nav}-->
	</div>
</div>

<!--{/if}-->
<!--{template common/footer}-->

