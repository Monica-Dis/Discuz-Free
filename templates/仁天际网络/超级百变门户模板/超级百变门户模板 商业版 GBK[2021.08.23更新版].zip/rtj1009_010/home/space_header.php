<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{subtemplate common/header_common}-->
	<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
	<link rel="stylesheet" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_css_space.css?{VERHASH}' />
	<link id="style_css" rel="stylesheet" type="text/css" href="{STATICURL}space/{if $space[theme]}$space[theme]{else}t1{/if}/style.css?{VERHASH}">
	<style id="diy_style">$space[spacecss]</style>
    <script type="text/javascript" src="template/rtj1009_010/static/js/jquery.min.js"></script>
    <script type="text/javascript">jQuery.noConflict();</script>
    <script type="text/javascript">jq = jQuery;</script>
</head>

<body id="space" class="rtj1009_zong ren-body-top" onkeydown="if(event.keyCode==27) return false;">
	<div id="append_parent"></div>
	<div id="ajaxwaitid"></div>

	<!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_010/php/spacecp_userstatus.php';}-->
	<!--{if $space['self'] && $_GET['diy'] == 'yes' && $do == 'index' }-->
	<link rel="stylesheet" type="text/css" href='{$_G['setting']['csspath']}{STYLEID}_css_diy.css?{VERHASH}' />
	<!--{subtemplate home/space_diy}-->
	<!--{/if}-->

    <div id="fixed-header-slide" class="ren-fixed-header cl">
        <div id="fixed-header-wrap" class="cl<!--{if ($_G['basescript']=='portal' && CURMODULE=='index') || ($_G['basescript']=='portal' && CURMODULE=='list') || ($_G['basescript']=='portal' && CURMODULE=='view')}--> ren-portal<!--{/if}--> ren_hd_kuan<!--{if $ren_hd_kuan == 1}-->e<!--{elseif $ren_hd_kuan == 2}-->si<!--{elseif $ren_hd_kuan == 3}-->bai<!--{/if}-->">
            <div id="header" class="wp rtj1009_topwp cl">
                <h2>
                    <a id="ren_logo" href="./">
                        <img src="{$_G['style']['styleimgdir']}/mini_logo.png" class="ren_logo">
                    </a>
                    <!--{hook/global_myitem_extra}-->
                </h2>
                <div id="main-nav" class="y ren-nv cl">
                    <div class="y ren-nav-us cl">
                        <div class="ren-nav-usbox cl">
                            <!--{if $_G['uid']}-->
                            <div class="ren-nav-usxx cl">
                                <a class="ren-us-name" href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">
                                    <div class="ren-us-avatar">
                                        <!--{avatar($_G[uid],small)}-->
                                        {if $_G[member][newpm] || $_G[member][newprompt]}<div class="dian"></div>{/if}
                                    </div>
                                    <span>{$_G[member][username]}</span>
                                    <i></i>
                                </a>
                            </div>
                            <!--{hook/global_usernav_extra2}-->
                            <!--{elseif !empty($_G['cookie']['loginuser'])}-->
                            <strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
                            <span class="pipe">|</span><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
                            <span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
                            <!--{elseif !$_G[connectguest]}-->
                            <div class="ren-wei-logging y">
                                <a class="ren-us-denglu" href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}">��¼</a>
                                <a class="ren-us-zhucen tu" href="member.php?mod={$_G[setting][regname]}">ע��</a>
                            </div>
                            <!--{else}-->
                            <div class="ren-nav-usxx cl">
                                <a class="ren-us-name" href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">
                                    <div class="ren-us-avatar">
                                        <!--{avatar($_G[uid],small)}-->
                                        {if $_G[member][newpm] || $_G[member][newprompt]}<div class="dian"></div>{/if}
                                    </div>
                                    <span>{$_G[member][username]}</span>
                                    <i></i>
                                </a>
                            </div>

                            <!--{hook/global_usernav_extra4}-->
                            <!--{hook/global_usernav_extra2}-->
                            <!--{hook/global_usernav_extra3}-->
                            <!--{/if}-->
                            <div class="ren-usxx-box cl">
                                <div class="ren-usxx-z cl">
                                    <div class="ren-nav-usxx cl">
                                        <a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}" class="avatar">
                                            <div class="ren-us-avatar">
                                                <!--{avatar($_G[uid],small)}-->
                                                {if $_G[member][newpm] || $_G[member][newprompt]}<div class="dian"></div>{/if}
                                            </div>
                                        </a>
                                        <div class="z ren-us-username cl">
                                            <div class="ren_us_usnxx cl">
                                                <a href="home.php?mod=space&uid=$_G[uid]" class="ren_us_mz z">{$_G[member][username]}</a>
                                                <a href="home.php?mod=spacecp&ac=usergroup" class="z ren_us_xing">Lv.12</a>
                                            </div>
                                            <div class="ren_us_usgroup cl">
                                                <a href="home.php?mod=spacecp&ac=usergroup" class="yi">$_G[group][grouptitle]</a>
                                                <a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}��$_G[member][credits]</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ren-usxx-y">
                                    <ul class="ren-nav-my cl">
                                        <li class="ren_top_xlkongjian"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank">�ҵĿռ�</a></li>
                                        <li class="ren_top_xlxiaoxi"><a href="home.php?mod=space&do=pm"{if $_G[member][newpm]} class="new"{/if}>�ҵ���Ϣ<!--{if $newpmcount}--><strong class="xi1">$newpmcount</strong><!--{/if}--></a></li>
                                        <!--{if $_G[member][newprompt]}-->
                                        <!--{loop $_G['member']['category_num'] $key $val}-->
                                        <li class="ren_$key"><a href="home.php?mod=space&do=notice&view=$key"><!--{echo lang('template', 'notice_'.$key)}--><strong class="xi1">$val</strong></a></li>
                                        <!--{/loop}-->
                                        <!--{/if}-->
                                        <li class="ren_top_xlsoucang"><a href="home.php?mod=space&do=favorite&view=me" target="_blank">�ҵ��ղ�</a></li>
                                        <li class="ren_top_xlhaoyou"><a href="home.php?mod=space&do=friend" target="_blank">�ҵĺ���</a></li>
                                        <!--{hook/global_myitem_extra}-->
                                    </ul>
                                    <ul class="ren-nav-sz cl">
                                        <li class="ren_top_xlzhsz"><a href="home.php?mod=spacecp" target="_blank">�ʺ�����</a></li>
                                        <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
                                        <li class="ren_top_xlmhgl"><a href="portal.php?mod=portalcp" target="_blank"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
                                        <!--{/if}-->
                                        <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
                                        <li class="ren_top_snlt"><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>
                                        <!--{/if}-->
                                        <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
                                        <li class="ren_top_xlht"><a href="admin.php" target="_blank">{lang admincp}</a></li>
                                        <!--{/if}-->
                                        <!--{if check_diy_perm($topic)}-->
                                        <li class="ren_top_xldiy"><a href="javascript:openDiy();" title="{lang open_diy}">DIY ����</a></li>
                                        <!--{/if}-->
                                        <li class="ren_top_xltcdl"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">�˳���¼</a></li>
                                        <!--{hook/global_usernav_extra1}-->
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <!--{hook/global_cpnav_extra2}-->
                        <!--{loop $_G['setting']['topnavs'][1] $nav}-->
                        <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}-->$nav[code]<!--{/if}-->
                        <!--{/loop}-->
                    </div>
                    <div id="ren_nav_ss" class="ren-nav-ss y"  onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});">
                        <a href="javascript:;"><i></i></a>
                    </div>

                    <script type="text/javascript">
                        jq(".ren-nav-usxx").hover(
                            function(){
                                jq(this).siblings(".ren-usxx-box").show();
                            },
                            function(){
                                jq(this).siblings(".ren-usxx-box").hide();
                            })
                        jq(".ren-usxx-box").hover(
                            function(){
                                jq(this).show();
                                jq(this).siblings(".ren-nav-usxx").addClass("ren-usxx-hov");
                            },
                            function(){
                                jq(this).hide();
                                jq(this).siblings(".ren-nav-usxx").removeClass("ren-usxx-hov");
                            })
                    </script>
                    <ul class="z main-menu">
                        <!--{loop $_G['setting']['navs'] $nav}-->
                        <!--{if $nav['available'] && (!$nav['level'] || ($nav['level'] == 1 && $_G['uid']) || ($nav['level'] == 2 && $_G['adminid'] > 0) || ($nav['level'] == 3 && $_G['adminid'] == 1))}--><li {if $mnid == $nav[navid]}class="a" {/if}$nav[nav]></li><!--{/if}-->
                        <!--{/loop}-->
                    </ul>
                    <!--{hook/global_nav_extra}-->
                </div>
            </div>
        </div>
    </div>
	<!--{if $space['status'] == -1 && $_G['adminid'] == 1 }-->
		<p class="ptw xw1 xi1 hm"><img src="{IMGDIR}/locked.gif" alt="Locked" class="vm" /> {lang message_banned}</p>
	<!--{/if}-->
	<!--{if $ren_home_bgstyle==2}-->
	<div class="rtj1009_showbg ren_bg">
		<div class="ren_header_bg"></div>
	</div>
	<!--{/if}-->
    <!--{if !empty($_G['setting']['plugins']['jsmenu'])}-->
    <ul class="p_pop h_pop" id="plugin_menu" style="display: none">
        <!--{loop $_G['setting']['plugins']['jsmenu'] $module}-->
        <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}-->
        <li>$module[url]</li>
        <!--{/if}-->
        <!--{/loop}-->
    </ul>
    <!--{/if}-->
    $_G[setting][menunavs]
    <div id="mu" class="ren_nv_mu cl">
        <!--{if $_G['setting']['subnavs']}-->
        <!--{loop $_G[setting][subnavs] $navid $subnav}-->
        <!--{if $_G['setting']['navsubhover'] || $mnid == $navid}-->
        <ul class="cl {if $mnid == $navid}current{/if}" id="snav_$navid" style="display:{if $mnid != $navid}none{/if}">
            $subnav
        </ul>
        <!--{/if}-->
        <!--{/loop}-->
        <!--{/if}-->
    </div>
    <div id="ren_nav_ss_menu" style="display: none; top: 75px;">
        <div class="rtj1009_ss">
            <!--{subtemplate common/pubsearchform}-->
        </div>
    </div>

	<div id="rtj1009_mn_u" class="rtj1009_menu">
		<div class="rtj1009_menu_nv">
			<!--{eval space_merge($space, 'field_home'); $space[domainurl] = space_domain($space);getuserdiydata($space);$personalnv = isset($_G['blockposition']['nv']) ? $_G['blockposition']['nv'] : '';}-->
            <!--{if CURMODULE == 'follow'}-->
            <!--{subtemplate home/follow_user_header}-->
              <!--{elseif !$space[self]}-->
              <div class="ren_menu_mn">
                  <ul>
                      <div class="ren_mt">
                          <span>{$space[username]}</span>
                      </div>
                      <!--{if helper_access::check_module('follow')}-->
                      <li class="ren_addflw z">
                          <!--{if !ckfollow($space['uid'])}-->
                              <a id="followmod" onClick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"><span>��ע</span></a>
                          <!--{else}-->
                              <a id="followmod" onClick="showWindow(this.id, this.href, 'get', 0);" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]">ȡ����ע</a>
                          <!--{/if}-->
                      </li>
                      <!--{/if}-->
                      <li class="ren_pm2 z">
                          <a href="home.php?mod=spacecp&ac=pm&op=showmsg&handlekey=showmsg_$space[uid]&touid=$space[uid]&pmid=0&daterange=2" id="a_sendpm_$space[uid]" onClick="showWindow('showMsgBox', this.href, 'get', 0)" title="{lang send_pm}">{lang send_pm}</a>
                      </li>
                  </ul>
                  <!--{if helper_access::check_module('follow')}-->
                  <script type="text/javascript">
                  function succeedhandle_followmod(url, msg, values) {
                      var fObj = $('followmod');
                      if(values['type'] == 'add') {
                          fObj.innerHTML = '��ע';
                          fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
                      } else if(values['type'] == 'del') {
                          fObj.innerHTML = 'ȡ����ע';
                          fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
                      }
                  }
                  </script>
                  <!--{/if}-->
              </div>
              <!--{/if}-->
            <!--{eval $konguid = $space[uid];}-->
			<!--{eval $guangbo = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid=$konguid");}-->
            <div class="z rtj1009_icn cl">
                <div class="ren_icn rtj_avt"><a href="home.php?mod=space&uid=$space[uid]"><!--{avatar($space[uid],big)}--></a></div>
                <!--{if helper_access::check_module('follow')}-->
                <ul class="ren_gb">
                    <li>
                        <a href="home.php?mod=follow&do=following&uid=$uid" target="_blank"><p>$guangbo['following']</p><span>��ע</span></a>
                    </li>
                    <li>
                        <a href="home.php?mod=follow&do=follower&uid=$uid" target="_blank"><p>$guangbo['follower']</p><span>��˿</span></a>
                    </li>
                </ul>
                <!--{/if}-->
        	</div>
		</div>
		<!--{subtemplate home/space_header_personalnv}-->
	</div>
		<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
		<ul id="usermanageli_menu" class="p_pop" style="width: 80px; display:none;">
			<!--{if checkperm('allowbanuser')}-->
				<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=ban&username=$encodeusername&frames=yes{else}forum.php?mod=modcp&action=member&op=ban&uid=$space[uid]{/if}" target="_blank">{lang user_ban}</a></li>
			<!--{/if}-->
			<!--{if checkperm('allowedituser')}-->
				<li><a href="{if $_G[adminid] == 1}admin.php?action=members&operation=search&username=$encodeusername&submit=yes&frames=yes{else}forum.php?mod=modcp&action=member&op=edit&uid=$space[uid]{/if}" target="_blank">{lang user_edit}</a></li>
			<!--{/if}-->
		</ul>
		<!--{/if}-->
		
		<!--{if $_G['adminid'] == 1}-->
		<ul id="umanageli_menu" class="p_pop" style="width: 80px; display:none;">
			<li><a href="forum.php?mod=modcp&action=thread&op=post&searchsubmit=1&do=search&users=$encodeusername" target="_blank">{lang manage_post}</a></li>
			<!--{if helper_access::check_module('doing')}-->
				<li><a href="admin.php?action=doing&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_doing}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('blog')}-->
				<li><a href="admin.php?action=blog&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_blog}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('feed')}-->
				<li><a href="admin.php?action=feed&searchsubmit=1&detail=1&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_feed}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('album')}-->
				<li><a href="admin.php?action=album&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_album}</a></li>
				<li><a href="admin.php?action=pic&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_pic}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('wall')}-->
				<li><a href="admin.php?action=comment&searchsubmit=1&detail=1&fromumanage=1&authorid=$space[uid]" target="_blank">{lang manage_comment}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('share')}-->
				<li><a href="admin.php?action=share&searchsubmit=1&detail=1&search=true&fromumanage=1&uid=$space[uid]" target="_blank">{lang manage_share}</a></li>
			<!--{/if}-->
			<!--{if helper_access::check_module('group')}-->
				<li><a href="admin.php?action=threads&operation=group&searchsubmit=1&detail=1&search=true&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_threads}</a></li>
				<li><a href="admin.php?action=prune&searchsubmit=1&detail=1&operation=group&fromumanage=1&users=$encodeusername" target="_blank">{lang manage_group_prune}</a></li>
			<!--{/if}-->
		</ul>
		<!--{/if}-->

		<ul id="rtj_xiaoxi_menu" style="display: none;">
        	<li class="ren_top_xlkongjian"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank">�ҵĿռ�</a></li>
            <li class="ren_top_xlxiaoxi"><a href="home.php?mod=space&do=pm"{if $_G[member][newpm]} class="new"{/if}>�ҵ���Ϣ<!--{if $newpmcount}--><strong class="xi1">$newpmcount</strong><!--{/if}--></a></li>
            <!--{if $_G[member][newprompt]}-->
                <!--{loop $_G['member']['category_num'] $key $val}-->
                    <li class="ren_$key"><a href="home.php?mod=space&do=notice&view=$key"><!--{echo lang('template', 'notice_'.$key)}--><strong class="xi1">$val</strong></a></li>
                <!--{/loop}-->
            <!--{/if}-->
            <li class="ren_top_xlsoucang"><a href="home.php?mod=space&do=favorite&view=me" target="_blank">�ҵ��ղ�</a></li>
            <li class="ren_top_xlhaoyou"><a href="home.php?mod=space&do=friend" target="_blank">�ҵĺ���</a></li>
            <li class="ren_top_xlxiangce"><a href="home.php?mod=space&do=album" target="_blank">�ҵ����</a></li>
        </ul>
        
         <ul id="rtj_shezhi_menu" style="display: none; top: 75px;">
            <li class="ren_top_xlzhsz"><a href="home.php?mod=spacecp">�ʺ�����</a></li>	  
            <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
            <li class="ren_top_xlmhgl"><a href="portal.php?mod=portalcp"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
            <!--{/if}-->
            <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
            <li class="ren_top_snlt"><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>
            <!--{/if}-->
            <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
            <li class="ren_top_xlht"><a href="admin.php" target="_blank">{lang admincp}</a></li>
            <!--{/if}-->
            <!--{if check_diy_perm($topic)}-->
            <li class="ren_top_xldiy"><a href="javascript:openDiy();" title="{lang open_diy}">DIY ����</a></li>
            <!--{/if}-->
            <li class="ren_top_xltcdl"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">�˳���¼</a></li>
        </ul>
        
		<ul id="rtj_sousuo_menu" style="display: none; top: 75px;">
			<div class="rtj1009_ss">
			  <!--{subtemplate common/pubsearchform}-->
			</div>
		</ul>
</ul>

