<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_lai_bm cl">
	<!--{eval $encodeusername = rawurlencode($space[username]);}-->
	<div class="ren_bm_c">
		<div class="ren_lai_hm">
			<h3>
            	<a href="home.php?mod=space&uid=$space[uid]">$space[username]</a>
            	<span class="ren_lai_id">ID {$space[uid]}</span>
            </h3>
		</div>
			<ul class="ren_lai_xx">
                <!--{eval $youhuid; $yonghuzuid; $yonghuzu;}-->
            	<li>
                	<em class="ren_lai_xxx ren_us_dj">�ȼ�</em>
                    <div class="ren_lai_mbn">$yonghuzu</div>
                </li>
                <li><em class="ren_lai_xxx ren_us_jf">{lang credits}</em><div class="ren_lb_mbn"><span>$space[credits]</span></div></li>
            <!--{eval $homeyuid = $space[uid];}-->
			<!--{eval $jifen;}-->
                <!--{loop $_G[setting][extcredits] $key $value}-->
                <!--{if $value['title']}-->
                <li class="ren_us_extc"><em class="ren_lai_xxx">$value['title']</em><div class="ren_lb_mbn"><span>{$jifen["extcredits$key"]} $value[unit]</span></div></li>
                <!--{/if}-->
                <!--{/loop}-->
			<!--{if $space[self]}-->
				<a href="home.php?mod=spacecp&ac=profile" class="ren_us_profile">{lang update_profile}</a>
			<!--{/if}-->
			</ul>
			<!--{if checkperm('allowbanuser') || checkperm('allowedituser') || $_G[adminid] == 1}-->
				
				<!--{if checkperm('allowbanuser') || checkperm('allowedituser')}-->
				
				<!--{/if}-->
				<!--{if $_G['adminid'] == 1}-->
				<!--{/if}-->
			<!--{/if}-->
		</div>
	</div>
</div>
<script type="text/javascript">
function succeedhandle_followmod(url, msg, values) {
	var fObj = $('followmod');
	if(values['type'] == 'add') {
		fObj.innerHTML = '{lang follow_del}';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
	} else if(values['type'] == 'del') {
		fObj.innerHTML = '{lang follow_add}TA';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
	}
}
</script>
