<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<div id="ct" class="rtj1009_ct2 cl">
	<div class="rtj1009_sz_mn">
		<div class="ren_sz_bm">
			<div class="ren_sz_bt">	
			<h3>
				<img src="{STATICURL}image/feed/magic.gif" alt="{lang magic}" class="vm" />
				<!--{if $action == 'shop'}-->{lang magics_shop}
				<!--{elseif $action == 'mybox'}-->{lang magics_user}
				<!--{elseif $action == 'log'}-->{lang magics_log}
				<!--{else}-->{lang magics_title}<!--{/if}-->
			</h1>
			</div>
			<!--{if !$_G['setting']['magicstatus'] && $_G['adminid'] == 1}-->
				<div class="emp">{lang magics_tips}</div>
			<!--{/if}-->

			<!--{if $action == 'shop'}-->
				<!--{subtemplate home/space_magic_shop}-->
			<!--{elseif $action == 'mybox'}-->
				<!--{subtemplate home/space_magic_mybox}-->
			<!--{elseif $action == 'log'}-->
				<!--{subtemplate home/space_magic_log}-->
			<!--{/if}-->
		</div>
	</div>
	<div class="rtj1009_zcd">
		<div class="ren_tbn">
			<ul>
				<!--{if $_G['group']['allowmagics']}--><li$actives[shop]><a href="home.php?mod=magic&action=shop">{lang magics_shop}</a><span>></span></li><!--{/if}-->
				<li$actives[mybox]><a href="home.php?mod=magic&action=mybox">{lang magics_user}</a><span>></span></li>
				<li$actives[log]><a href="home.php?mod=magic&action=log&operation=uselog">{lang magics_log}</a><span>></span></li>
				<!--{hook/magic_nav_extra}-->
			</ul>
		</div>
	</div>
</div>
<!--{template common/footer}-->
