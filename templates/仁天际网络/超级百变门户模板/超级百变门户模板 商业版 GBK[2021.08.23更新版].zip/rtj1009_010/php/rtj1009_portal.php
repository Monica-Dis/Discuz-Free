<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_core.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */
 
if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}

$ren_portal_forums = unserialize($rtj1009_democp['ren_portal_forums']);
$forums_fid = '';
foreach($ren_portal_forums as $key=>$value) {
    $forums_fid .= $value.",";
}
$renfid = rtrim($forums_fid , ",");

$perpage = $rtj1009_democp['ren_portal_page'];
$curpage = empty ( $_GET['page'] ) ? 1 : intval ( $_GET['page'] );
$start = ($curpage-1)*$perpage;
$maxpagenum = $rtj1009_democp['ren_portal_maxpagenum'] ? intval($rtj1009_democp['ren_portal_maxpagenum']) : 1000;

if ($rtj1009_democp['ren_portal_order'] == 1) {
    $orderby = "ORDER BY f_t.tid DESC LIMIT";
} else if ($rtj1009_democp['ren_portal_order'] == 2) {
    $orderby = "ORDER BY f_t.lastpost DESC LIMIT";
} else if ($rtj1009_democp['ren_portal_order'] == 3) {
    $orderby = "ORDER BY f_t.views DESC LIMIT";
} else if ($rtj1009_democp['ren_portal_order'] == 4) {
    $orderby = "ORDER BY f_t.replies DESC LIMIT";
}

if (!empty($renfid)) {
    $portalacount = DB::query("SELECT f_p.*, f_t.* FROM ".DB::table('forum_thread')." f_t LEFT JOIN ".DB::table('forum_post')." f_p ON f_p.tid=f_t.tid WHERE f_t.fid in ($renfid) and f_t.displayorder>='0' and f_p.first='1' $orderby $maxpagenum");
    $num = DB::num_rows($portalacount);
}

$portallist = array();
if ($num) {
    $query = DB::query("SELECT f_p.*, f_t.* FROM ".DB::table('forum_thread')." f_t LEFT JOIN ".DB::table('forum_post')." f_p ON f_p.tid=f_t.tid WHERE f_t.fid in ($renfid) and f_t.displayorder>='0' and f_p.first='1' $orderby $start,$perpage");
    while ($value = DB::fetch($query)) {
        $portallist[] = $value;
    }
}

$renpages = ceil($num / $perpage);
$multi = multi($num, $perpage, $curpage, "portal.php?mod=index");

?>
