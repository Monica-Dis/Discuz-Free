<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_list.php 2017-08-10 18:07:44Z rtj1009_app $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}



function rtj1009_imgurl($imgurl) {
    if (strstr($imgurl, '[/img]')) {
        if (strstr($imgurl, '[img=')) {
            $parrent = "/\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is";
            preg_match_all($parrent, $imgurl, $match);
            $imgurlx = $match[3][0];
        } else if (strstr($imgurl, '[img]')) {
            $parrent = "/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is";
            preg_match_all($parrent, $imgurl, $match);
            $imgurlx = $match[1][0];
        }
    }
    if ($imgurlx) {
        $attachid .= '<span class="ren-thread-imge imgurlx"><img src="'.$imgurlx.'" /></span>';
        return $attachid;
    }
}

function rtj1009_vedio_url($vediourl) {
    if (strstr($vediourl, '[/media]')) {
        $parrent = "/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i";
        preg_match_all($parrent, $vediourl, $match);
        $vediourlx = $match[0][0];
    } else if (strstr($vediourl, '[/video]')) {
        $parrent = "/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i";
        preg_match_all($parrent, $vediourl, $match);
        $vediourlx = $match[0][0];
    }
    $vediourlx = preg_replace_callback("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i","rtj1009_vedio", $vediourlx);
    return $vediourlx;
}

function rtj1009_msg($messages) {
    $messages = preg_replace("/\[[a-z][^\]]*\]|\[\/[a-z]+\]/i", '',
        preg_replace("/\[attach\]\d+\[\/attach\]/i", '',
            preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i", '',
                preg_replace("/\[img=(\d{1,4})[x|\,]\s*(.+?)\s*\[\/img\]/i", '',
                    preg_replace("/\[img\]\s*(.+?)\s*\[\/img\]/i", '',$messages)))));

    return $messages;
}


function get_ren_attachment_table($tableid) {
    if(!is_numeric($tableid)) {
        list($idtype, $id) = explode(':', $tableid);
        $tid = (string)$id;
        $tableid = dintval($tid{strlen($tid)-1});
    }
    if($tableid >= 0 && $tableid < 10) {
        return 'forum_attachment_'.intval($tableid);
    } else {
        throw new DbException('Table forum_attachment_'.$tableid.' has not exists');
    }
}


function fetch_ren_attachment_aid($tableid, $idtype, $id, $limit) {
    $limit = DB::limit(0, $limit);
    return DB::fetch_all('SELECT aid,remote FROM %t WHERE %i AND isimage IN (1, -1) %i', array(get_ren_attachment_table($tableid), DB::field($idtype, $id), $limit));
}

function ftpattachurl($aid) {
    global $_G;
    $data = array();
    $query = DB::query("SELECT tableid from " . DB::table('forum_attachment') . " where aid='$aid'");
    $data = DB::fetch($query);
    $table = DB::table('forum_attachment_' . intval($data['tableid']));
    $attach = DB::fetch_first("SELECT attachment FROM $table WHERE aid='$aid'");
    $filename = $_G['setting']['ftp']['attachurl'] . 'forum/' . $attach['attachment'];

    return $filename;
}


?>
