<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<style id="diy_style" type="text/css"></style>
<div class="ren-zong">

    <div id="rtj1009_iho00" class="rtj1009_iho00 cl">
        <!--[diy=rtj1009_diy135]--><div id="rtj1009_diy135" class="area"></div><!--[/diy]-->
    </div>
	<!--{if $config['ren_ad_yi']}-->
    <div id="rtj1009_iho0" class="rtj1009_iho0 cl">
        <div class="ren_iho">
            <a href="http://t.cn/Aiux1Qh0" target="_blank"><img src="template/rtj1009_010/icon/ren_mh_gg02.gif" /></a>
        </div>
    </div>
    <!--{/if}-->
	<!--{if $config['ren_ad_e']}-->
    <div id="rtj1009_iho1" class="rtj1009_iho1 cl">
        <div class="ren_iho">
            <a href="http://t.cn/Aiux1Qh0" target="_blank"><img src="template/rtj1009_010/icon/ren_mh_gg04.jpg" /></a>
        </div>
    </div>
    <!--{/if}-->
    <!--{if $config['ren_ad_san']}-->
    <div id="rtj1009_iho2" class="rtj1009_iho2 cl">
        <div class="ren_iho">
            <a href="http://t.cn/Aiux1Qh0" target="_blank"><img src="template/rtj1009_010/icon/ren_mh_gg03.gif" /></a>
        </div>
    </div>
    <!--{/if}-->
    <!--{if $config['ren_ad_si']}-->
    <div id="rtj1009_iho3" class="rtj1009_iho3 cl">
        <div class="ren_iho">
            <a href="http://t.cn/Aiux1Qh0" target="_blank" class="ren_ihoo1"><img src="template/rtj1009_010/icon/ren_mh_ihoo1.jpg" /></a>
            <a href="http://t.cn/Aiux1Qh0" target="_blank" class="ren_ihoo2"><img src="template/rtj1009_010/icon/ren_mh_ihoo2.jpg" /></a>
        </div>
    </div>
    <!--{/if}-->

    <div class="ren-index-main<!--{if !$rtj1009_democp['ren_portal_left']}--> ren-left-none<!--{/if}--> cl">
        <!--{if $rtj1009_democp['ren_portal_left']}-->
        <div class="ren-index-rowyi z cl">
            <div class="ren-left-menu ren-left-fixed cl">
                <ul>
                    <!--{loop $menulist $values}-->
                    <li><a href="{$values['url']}" target="_blank"><img src="{$values['icon']}" /><span>{$values['title']}</span></a></li>
                    <!--{/loop}-->
                </ul>
                <div class="ren-left-btn" <!--{if !$rtj1009_democp['ren_portal_left_wx']}-->style="margin-bottom: 0;"<!--{/if}-->>
                    <a href="forum.php" target="_blank"><img src="template/rtj1009_010/image/ren_di_weixin.png" /><span>������̳</span></a>
                </div>
                <!--{if $rtj1009_democp['ren_portal_left_wx']}-->
                <div class="ren-left-wx">
                    <div class="ren-left-wx-bt">
                        <h3>��ע΢�Ź��ں�</h3>
                        <span>��ע���������������Ѷ</span>
                    </div>
                    <div class="ren-left-wx-img">
                        <img src="template/rtj1009_010/icon/weixin.jpg" >
                    </div>
                </div>
                <!--{/if}-->
            </div>
        </div>
        <!--{/if}-->
        <div class="ren-index-rowe z cl">
            <div class="ren-zong-lunbo">
                <!--[diy=rtj1009_diy2]--><div id="rtj1009_diy2" class="area"></div><!--[/diy]-->
            </div>
            <!--{if !$rtj1009_democp['ren_portal_left']}-->
            <div class="ren-zong-yad y">
                <a href="http://t.cn/Aiux1Qh0" target="_blank"><img src="template/rtj1009_010/icon/rem_xmd9.jpg" ></a>
                <a href="http://t.cn/Aiux1Qh0" target="_blank"><img src="template/rtj1009_010/icon/rem_xmd10.jpg" ></a>
                <a href="http://t.cn/Aiux1Qh0" target="_blank"><img src="template/rtj1009_010/icon/rem_xmd5.jpg" ></a>
            </div>
            <!--{/if}-->

            <div class="ren-index-tlist cl">
                <div class="ren-index-list-xx cl">
                    <ul class="ren-index-list-ul cl">
                        <!--{if $rtj1009_democp['ren_portal_laiyuan'] == 1}-->
                        <!--{subtemplate rtj1009_core/ren_portal_list}-->
                        <!--{else}-->
                        <!--{subtemplate rtj1009_core/ren_portal_list2}-->
                        <!--{/if}-->
                    </ul>
                    $multi
                </div>
            </div>
        </div>
        <div class="ren-index-rowsan y cl">
            <div class="ren-index-right-info cl">
                <div class="ren_yiy y cl">
                    <div class="ren_yiy_s cl">
                        <div class="ren_yiys_user cl">
                            <!--{if !$_G[uid] && !$_G['connectguest']}-->
                            <div class="ren_userinfo cl">
                                <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="ren_us_avatar"><!--{avatar($_G[uid],avatar_middle)}--></a>
                                <h3 class="ren_us_name">Hi �ο� ����</h3>
                                <span class="ren_us_hy">��ӭ������{$_G['setting']['bbname']}��</span>
                            </div>
                            <!--{else}-->
                            <div class="ren_userinfo cl">
                                <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="ren_us_avatar"><!--{avatar($_G[uid],avatar_middle)}--></a>
                                <h3 class="ren_us_name">Hi $_G[username] ����</h3>
                                <span class="ren_us_hy">��ӭ������{$_G['setting']['bbname']}��</span>
                            </div>
                            <!--{/if}-->
                        </div>
                        <ul class="cl">
                            <li class="ren_yiy_sliz">
                                <!--{if $_G['uid']}-->
                                <a href="home.php?mod=space&do=pm" target="_blank" class="ren_yiy_sxx">�ҵ���Ϣ</a><!--{else}-->
                                <a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" class="ren_yiy_sdl">��¼</a><!--{/if}-->
                            </li>
                            <li class="ren_yiy_sliz">
                                <!--{if $_G['uid']}-->
                                <a href="home.php?mod=space&uid=$_G[uid]&do=profile" target="_blank" class="ren_yiy_swd">�ҵ���ҳ</a><!--{else}-->
                                <a href="member.php?mod={$_G[setting][regname]}" class="ren_yiy_szc">ע��</a><!--{/if}-->
                            </li>
                            <li class="ren_yiy_sliy">
                                <!--{if $_G['uid']}-->
                                <a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="ren_yiy_sfb">��������</a><!--{else}-->
                                <a href="forum.php?mod=misc&action=nav" onclick="showWindow('nav', this.href, 'get', 0)" class="ren_yiy_sft">����</a><!--{/if}-->
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="ren_yiy_x y cl">
                    <div class="ren_yiy_lunbo cl">
                        <!--[diy=rtj1009_diy102]--><div id="rtj1009_diy102" class="area"></div><!--[/diy]-->
                    </div>
                </div>
                <!--{if $rtj1009_democp['ren_portal_yiz']}-->
                <div class="y ren_yiz cl">
                    <div class="rtj1009_yixy_bt cl">
                        <h3 class="rtj1009_bt z">�������</h3>
                    </div>
                    <div class="ren_yizs cl">
                        <ul class="cl">
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx1"></span>
                                    <p>����</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx2"></span>
                                    <p>�ⷿ</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx3"></span>
                                    <p>װ��</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx4"></span>
                                    <p>��Ƹ</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx5"></span>
                                    <p>��ְ</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx6"></span>
                                    <p>����</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx7"></span>
                                    <p>���</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx8"></span>
                                    <p>����</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx9"></span>
                                    <p>����</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx10"></span>
                                    <p>����</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx11"></span>
                                    <p>����</p>
                                </a></li>
                            <li><a href="http://t.cn/Aiux1Qh0" target="_blank"><span class="ren_yizs_xx12"></span>
                                    <p>��ʳ</p>
                                </a></li>
                        </ul>
                    </div>
                </div>
                <!--{/if}-->

                <!--{if $rtj1009_democp['ren_portal_hongdong']}-->
                <div class="ren_e_y y cl">
                    <!--[diy=rtj1009_diy207]--><div id="rtj1009_diy207" class="area"></div><!--[/diy]-->
                </div>
                <!--{/if}-->
                <div class="ren-index-right-fix ren-right-fixed cl">
                    <div class="ren-index-right-tie y cl">
                        <div class="ren-index-right-box cl">
                            <div class="ren-index-right-tbt cl">
                                <h3>��������</h3>
                            </div>
                            <div class="ren-index-right-txx cl">
                                <!--[diy=rtj1009_diy208]--><div id="rtj1009_diy208" class="area"></div><!--[/diy]-->
                            </div>
                        </div>
                    </div>

                    <div class="ren-index-right-dad y cl">
                        <a href="#" class="ren-index-adimg" target="_blank">
                            <img src="template/rtj1009_010/icon/rtj1009_gg5.jpg" >
                            <span>���</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="zhanwei cl"></div>

    <script type="text/javascript">
        window.��nl��ad=
            function(){
                var oDiv = document.getElementsByClassName("ren-index-right-dad"),
                    H = 0,
                    Y = oDiv
                while (Y) {
                    H += Y.offsetTop;
                    Y = Y.offsetParent;
                }
                window.onscroll = function()
                {
                    var s = document.body.scrollTop || document.documentElement.scrollTop
                    if(s>H) {
                        oDiv.style = "position:fixed;top:0;"
                    } else {
                        oDiv.style = ""
                    }
                }
            }
    </script>

    <script type="text/javascript">
        var curpage = $curpage;
        var ren_loading = false;
        var ren_loading_ing='<div class="ren-index-loading ing"><a href="javascript:;">���ظ���</a></div>';
        var ren_loading_end='<div class="ren-index-loading end"><a href="javascript:;">�ף���ʱ����ô����Ŷ��</a></div>';
        jq(document).ready(function(){
            jq(".pg").html(ren_loading_ing);
            <!--{if $rtj1009_democp['ren_portal_pages'] ==2}-->
            jq(window).scroll(function () {
                if (jq(document).scrollTop() + jq(window).height()> jq(document).height() - 500 && !ren_loading) {
                    ren_loading = true;
                    ren_list_page();
                }
            });
            <!--{else}-->
            jq('.ren-index-loading').on('click', function() {
                ren_loading = true;
                ren_list_page();
            });
            <!--{/if}-->
        });

        function ren_list_page() {
            curpage++;
            var url = 'portal.php?mod=index&page=' + curpage;
            jq.ajax({
                url : url,
                data : null,
                dataType : "html",
                success : function(s) {
                    if(curpage >= $renpages){
                        jq(".pg").html(ren_loading_end);
                    }
                    s = s.replace(/\n|\r/g, '');
                    var nexts = s.match(/<ul class="ren-index-list-ul cl">(.+?)<\/ul>/);
                    var pagenum = s.match(/<strong>(\d+)<\/strong>/);
                    pagenum = parseInt(pagenum[1]);

                    if(pagenum==$renpages){
                        ren_loading = false;
                    }else{

                        if(nexts[1]){
                            jq(nexts[1]).insertAfter(jq(".ren-index-list-ul>li").last());
                        }
                        ren_loading = false;
                    }
                }
            });
        }
    </script>

    <script type="text/javascript">
        jq(document).ready(function(){
            jq("#scrollDiv").Scroll({line:1,speed:600,timer:4000,up:"but_up",down:"but_down"});
        });

        jq(document).ready(function(){
            jq('.flexslider').flexslider({
                animation: "slide",
                directionNav: true,
                pauseOnAction: false,
                pauseOnHover: true,
                slideshowSpeed: 3000
            });
        });
    </script>

    <script type="text/javascript">
        jq(document).ready(function() {
            var topheight = <!--{if $rtj1009_hd !=1 && $rtj1009_democp['ren_nav_fix']}-->64<!--{elseif $rtj1009_democp['ren_nav_fix']}-->46<!--{else}-->0<!--{/if}-->;
            <!--{if $rtj1009_democp['ren_portal_left_fix']}-->
            var summariesz = jq('.ren-left-fixed');
            summariesz.each(function(i) {
                var summary = jq(summariesz[i]);
                var next = summariesz[i + 1];
                if(next) {
                    summary.scrollFix({
                        distanceTop: topheight,
                        endPos: '.zhanwei',
                        baseClassName: 'scrollfixedz',
                        zIndex: 189
                    });
                } else {
                    summary.scrollFix({
                        distanceTop: topheight,
                        endPos: '.zhanwei',
                        baseClassName: 'scrollfixedz',
                        zIndex: 189
                    });
                }
            });
            <!--{/if}-->
            <!--{if $rtj1009_democp['ren_portal_right_fix']}-->
            var summariesy = jq('.ren-right-fixed');
            summariesy.each(function(i) {
                var summary = jq(summariesy[i]);
                var next = summariesy[i + 1];
                if (next) {
                    summary.scrollFix({
                        distanceTop: topheight,
                        endPos: '.zhanwei',
                        baseClassName: 'scrollfixedy',
                        zIndex: 189
                    });
                } else {
                    summary.scrollFix({
                        distanceTop: topheight,
                        endPos: '.zhanwei',
                        baseClassName: 'scrollfixedy',
                        zIndex: 189
                    });
                }
            });
            <!--{/if}-->
        });
    </script>


    <!--{if $config['ren_portal_yl']}-->
    <div class="rtj1009_shiban cl">
    	<p>
        	<span>��������</span>
        </p>
        <ul>
        	<!--[diy=rtj1009_diy1]--><div id="rtj1009_diy1" class="area"></div><!--[/diy]-->
        </ul>
    </div>
	<!--{/if}-->
</div>



<!--{template common/footer}-->
