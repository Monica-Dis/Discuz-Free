<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

	<!--{ad/text/wp a_t}-->
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<div id="ren_ct" class="rtj1009_group_ct ren-group cl">
		<div class="ren_lai_mn z">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
            <!--[diy=diy5]--><div id="diy5" class="area"></div><!--[/diy]-->
			<!--[diy=diycommendtop]--><div id="diycommendtop" class="area"></div><!--[/diy]-->
			<!--{hook/index_header}-->
            <div class="rtj1009_eban cl">
                <div class="rtj1009_e cl">
                    <div class="z ren_e_z cl">
                        <div class="ren_e_zs">
                            <div class="ren_ez_tw z">
                                <!--[diy=rtj1009_diy3]--><div id="rtj1009_diy3" class="area"></div><!--[/diy]-->
                            </div>
                            <div class="ren_ez_tie y">
                                <!--[diy=rtj1009_diy4]--><div id="rtj1009_diy4" class="area"></div><!--[/diy]-->
                                <ul class="ren_ez_xx cl">
                                    <!--[diy=rtj1009_diy5]--><div id="rtj1009_diy5" class="area"></div><!--[/diy]-->
                                </ul>
                            </div>
                        </div>
                        <div class="ren_e_zx">
                            <div class="ren_ezx_tw">
                                <ul>
                                    <!--[diy=rtj1009_diy6]--><div id="rtj1009_diy6" class="area"></div><!--[/diy]-->
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <script type="text/javascript">
                jq(document).ready(function(){
                    jq('.flexslider').flexslider({
                        animation: "slide",
                        directionNav: true,
                        pauseOnAction: false,
                        pauseOnHover: true,
                        slideshowSpeed: 3000
                    });
                });
            </script>
			<div id="g_commend" class="ren-bm ren-group-rec">
                <div class="rtj1009_sd_bt cl">
                    <h3 class="rtj1009_bt z">{lang recommend_group}</h3>
                </div>
				<ul class="cl">
					<!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->
					<li>
						<div class="ren-group-icon"><a href="forum.php?mod=group&fid=$val[fid]"><img src="$val[icon]" alt="$val[name]" width="48" height="48" /></a></div>
						<h3><a href="forum.php?mod=group&fid=$val[fid]">$val[name]</a></h3>
						<p>$val[description]</p>
					</li>
					<!--{/loop}-->
				</ul>
			</div>

			<!--[diy=diycategorytop]--><div id="diycategorytop" class="area"></div><!--[/diy]-->
			<!--{hook/index_top}-->
			<div class="ren-bm">
                <div class="rtj1009_sd_bt cl">
                    <h3 class="rtj1009_bt z">{lang group_categories}</h3>
                </div>
				<div class="ren_bm_c ren-group-lalist">
					<!--{loop $first $groupid $group}-->
							<ul class="cl">
								<div class="ren-group-pbn">
									<span class="y xi2">
                                        <!--{loop $group['secondlist'] $fid}--><a href="group.php?sgid=$fid">$second[$fid][name]</a> <!--{/loop}-->
                                        <a href="group.php?gid=$groupid">{lang more} &rsaquo;</a>
                                    </span>
                                    <h3>
                                        <a href="group.php?gid=$groupid">$group[name]</a><!--{if $group[groupnum]}--><span class="shu"> ($group[groupnum])</span><!--{/if}-->
                                    </h3>
								</div>
                                <!--{loop $lastupdategroup[$groupid] $val}-->
                                <li>
                                    <a href="forum.php?mod=group&fid=$val[fid]">$val[name]</a>
                                </li>
                                <!--{/loop}-->
							</ul>
					<!--{/loop}-->
				</div>
			</div>
			<!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->
			<!--{hook/index_bottom}-->
		</div>

		<div class="rtj1009_home_sd ren-group-sd y">
			<div class="drag">
				<!--[diy=diysidetop]--><div id="diysidetop" class="area"></div><!--[/diy]-->
			</div>
            <div class="ren-group-y">
                <div class="ren_yiys_user cl">
                    <!--{if !$_G[uid] && !$_G['connectguest']}-->
                    <div class="ren_userinfo cl">
                        <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="ren_us_avatar"><!--{avatar($_G[uid],avatar_middle)}--></a>
                        <h3 class="ren_us_name">Hi �ο� ����</h3>
                        <span class="ren_us_hy">��¼���ָ��ྫ�ʣ�</span>
                    </div>
                    <!--{else}-->
                    <div class="ren_userinfo cl">
                        <a href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->" class="ren_us_avatar"><!--{avatar($_G[uid],avatar_middle)}--></a>
                        <h3 class="ren_us_name">Hi $_G[username] ����</h3>
                        <span class="ren_us_hy">�����Լ������{$_G[setting][navs][3][navname]}��</span>
                    </div>
                    <!--{/if}-->

                    <ul class="cl">
                        <li class="ren_yiy_sliz">
                            <!--{if $_G['uid']}-->
                                <a href="group.php?mod=my" target="_blank" class="ren_yiy_sxx">{lang my_group}</a>
                            <!--{else}-->
                                <a href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}" class="ren_yiy_sdl">��¼</a>
                            <!--{/if}-->
                        </li>
                        <li class="ren_yiy_sliz">
                            <!--{if helper_access::check_module('group')}-->
                                <a href="forum.php?mod=group&action=create" target="_blank" class="ren_yiy_swd">����{$_G[setting][navs][3][navname]}</a>
                            <!--{else}-->
                                <a href="home.php?mod=space&uid=$_G[uid]&do=profile" target="_blank" class="ren_yiy_swd">�ҵ���ҳ</a>
                            <!--{/if}-->
                        </li>
                    </ul>
                </div>
            </div>
			<!--{hook/index_side_top}-->
			<!--{if helper_access::check_module('group')}-->
				<!--{if empty($gid) && empty($sgid)}-->
					<div class="ren-bm">
                        <div class="rtj1009_sd_bt cl">
                            <h3 class="rtj1009_bt z">{lang create_group_step}</h3>
                        </div>
						<div class="bm_c">
							<ul id="g_guide" class="mbm">
								<li><label><strong class="xi1">{lang group_create}</strong><span class="xg1">{lang create_group_message1}</span></label></li>
								<li><label><strong class="xi1">{lang personality_setting}</strong><span class="xg1">{lang create_group_message2}</span></label></li>
								<li><label><strong class="xi1">{lang invite_friend}</strong><span class="xg1">{lang create_group_message3}</span></label></li>
								<li><label><strong class="xi1">{lang group_upgrade}</strong><span class="xg1">{lang create_group_message4}</span></label></li>
							</ul>
						</div>
					</div>
				<!--{else}-->
					<div class="bm bw0">
						<div class="bm_c">
							<a href="forum.php?mod=group&action=create&fupid=$fup&groupid=$sgid" id="create_group_btn">����һ���������ѵ�Ⱥ��</a>
						</div>
					</div>
				<!--{/if}-->
			<!--{/if}-->
            <div class="ren_sd_yi">
                <!--[diy=rtj1009_diy10]--><div id="rtj1009_diy10" class="area"></div><!--[/diy]-->
            </div>
			<div class="drag">
				<!--[diy=diysidemiddle]--><div id="diysidemiddle" class="area"></div><!--[/diy]-->
			</div>
            <!--{if $topgrouplist}-->
            <div class="ren_sd_e">
                <div class="rtj1009_sd_bt cl">
                    <h3 class="rtj1009_bt z">{lang group_hot}</h3>
                </div>
                <div class="ren_sd_hy">
                    <ul class="ren_sd_hyxx">
                        <!--{loop $topgrouplist $fid $group}-->
                        <li class="ren_u_li{currentorder}">
                            <a href="forum.php?mod=group&fid=$group[fid]">
                                <p class="z ren_u_img">
                                    <img src="$group[icon]" width="40" height="40" alt=">$group[name]" />
                                </p>
                                <p class="z ren_u_n">$group[name]</p>
                                <span class="y ren_u_jf">$group[commoncredits]<i></i></span>
                            </a>
                        </li>
                        <!--{/loop}-->
                    </ul>
                </div>
            </div>
            <!--{/if}-->
			<div class="drag">
				<!--[diy=diysidebottom]--><div id="diysidebottom" class="area"></div><!--[/diy]-->
			</div>
			<!--{hook/index_side_bottom}-->
		</div>
	</div>

<div class="wp">
	<!--[diy=diy4]--><div id="diy4" class="area"></div><!--[/diy]-->
</div>

<!--{template common/footer}-->
