<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{ad/text/wp a_t}-->

<style id="diy_style" type="text/css"></style>
<div class="wp">
	<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
</div>
<div id="rtj_forumdisplay" class="ren-group-list">
	<div id="pt" class="bm cl">
		<div class="z">
			<a href="./" class="nvhm" title="{lang home}">$_G[setting][bbname]</a><em>&rsaquo;</em><a href="group.php">$_G[setting][navs][3][navname]</a><!--{if $groupnav}-->$groupnav<!--{elseif $action == 'create'}--><em>&rsaquo;</em>{lang group_create}<!--{/if}-->
		</div>
	</div>

	<div class="rtj_boardnav cl">
		<div class="liebiaozuo cl">
			<div id="ct" class="wp cl ct2">
				<div class="mn">
					<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
					<!--{if $action != 'create'}-->
						<div class="ren-group-box<!--{if $_G['forum']['banner']}--> ren-group-bg<!--{/if}-->" <!--{if $_G['forum']['banner']}-->style="background: url($_G[forum][banner]);background-size: cover; background-repeat: no-repeat;background-position: center;"<!--{/if}-->>
							<div class="rtj_bkhead cl">
								<div id="head_z" class="z head_zuo cl">
									<div class="head_bktp z cl">
										<a href="forum.php?mod=forumdisplay&fid=$_G[fid]" target="_blank">
											<img src="$_G[forum][icon]" alt="{$_G['forum'][name]}">
										</a>
									</div>
									<div class="head_bkxx f15 cl">
										<h1 class="head_biaoti z"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">$_G['forum'][name]</a></h1>
										<p class="head_num">{lang credits}��<span class="tieshu">$_G[forum][commoncredits]</span></p>
										<div class="ren_bk_ft">
											<!--{eval $ren_forum_gz = DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='gid' and id=".$_G['fid']."");}-->
											<!--{if $ren_forum_gz[id]}-->
											<a id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" class="ren_qxgz" href="home.php?mod=spacecp&ac=favorite&op=delete&favid={$ren_forum_gz[favid]}&type=forum&formhash={FORMHASH}">���ղ�</a>
											<!--{else}-->
											<a href="home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}" id="a_favorite" onclick="showWindow(this.id, this.href, 'get', 0);" title="{lang favorite}" class="fa_fav">{lang favorite}</a>
											<!--{/if}-->
										</div>
										<!--{if $status != 2 && $status != 3 && $status != 5}-->
										<!--{if helper_access::check_module('group') && $status != 'isgroupuser'}-->
										<div class="ren_bk_ft">
											<a href="forum.php?mod=group&action=join&fid=$_G[fid]" title="{lang group_join_group}" class="fa_fav">{lang group_join_group}</a>
										</div>
										<!--{/if}-->
										<!--{if CURMODULE == 'group'}--><!--{hook/group_navlink}--><!--{else}--><!--{hook/forumdisplay_navlink}--><!--{/if}-->
										<!--{/if}-->
									</div>
									<p class="f14 head_bkjs">
										<!--{if $_G[forum][description]}-->{$_G[forum][description]}<!--{else}-->���޼��, ���ں�̨������������!<!--{/if}-->
									</p>

									<div class="z rtj_bzn cl">
										<div class="rtj_bzxx">
											{lang group_moderator_title}��
											<span class="bxmz">
												<!--{eval $i = 1;}-->
												<!--{loop $groupmanagers $manage}--><!--{if $i <= 0}-->, <!--{/if}--><!--{eval $i--;}-->
													<a href="home.php?mod=space&uid=$manage[uid]" target="_blank" class="xi2">$manage[username]</a>
												<!--{/loop}-->
											</span>
										</div>
										<!--{if $status == 'isgroupuser' && helper_access::check_module('group')}-->
										<a href="javascript:;" onclick="showWindow('invite','misc.php?mod=invite&action=group&id=$_G[fid]')" class="fa_ivt"><strong class="xi2">{lang my_buddylist_invite}</strong></a><!--{/if}-->
										<!--{if $_G['current_grouplevel']['icon']}-->
										<img src="$_G[current_grouplevel][icon]" title="{lang group_level}��$_G[current_grouplevel][leveltitle]" class="vm">
										<!--{/if}-->
									</div>
								</div>
								<div class="ren_list_post y">
									<!--{if !$_GET['archiveid']}-->
									<a class="head_post y" href="javascript:;" id="newspecial" onmouseover="$('newspecial').id = 'newspecialtmp';this.id = 'newspecial';showMenu({'ctrlid':this.id})"{if !$_G['forum']['allowspecialonly'] && empty($_G['forum']['picstyle']) && !$_G['forum']['threadsorts']['required']} onclick="showWindow('newthread', 'forum.php?mod=post&action=newthread&fid=$_G[fid]')"{else} onclick="location.href='forum.php?mod=post&action=newthread&fid=$_G[fid]';return false;"{/if} title="{lang send_posts}">����</a>
									<!--{/if}-->
								</div>
							</div>
							<!--{if $action == 'index' && ($status == 2 || $status == 3 || $status == 5)}-->
								<div class="ren-group-tbms">
									<div class="tbms">
										<div class="ren-group-join">
											{lang group_join_type}��<!--{if $_G['forum']['jointype'] == 1}-->
											<strong>{lang group_join_type_invite}</strong>
											<!--{elseif $_G['forum']['jointype'] == 2}-->
											<strong>{lang group_join_type_moderate}</strong>
											<!--{else}-->
											<strong>{lang group_join_type_free}</strong>
											<!--{/if}-->
											{lang group_perm_visit}��<strong><!--{if $_G['forum']['gviewperm'] == 0}-->{lang group_perm_member_only}<!--{else}-->{lang group_perm_all_user}<!--{/if}--></strong>
										</div>
										<div class="xi1">
											<!--{if $status == 3 || $status == 5}-->
											{lang group_has_joined}
											<!--{elseif helper_access::check_module('group')}-->
											<button type="button" class="pn" onclick="location.href='forum.php?mod=group&action=join&fid=$_G[fid]'"><em>{lang group_join_group}</em></button>
											<!--{/if}-->
										</div>
									</div>
								</div>
							<!--{/if}-->
						</div>
						<!--[diy=diycontentmiddle]--><div id="diycontentmiddle" class="area"></div><!--[/diy]-->
						<!--{if CURMODULE == 'group'}--><!--{hook/group_top}--><!--{else}--><!--{hook/forumdisplay_top}--><!--{/if}-->
						<!--{if $status != 2 && $status != 3}-->
						<div class="ren-group-nav cl">
							<!--{if in_array($_G['adminid'], array(1,2))}--><span class="a bw0_all y xi2"><a href="javascript:;" onclick="showWindow('grecommend$_G[fid]', 'forum.php?mod=group&action=recommend&fid=$_G[fid]');return false;">{lang group_push_to_forum}</a></span><!--{/if}-->
							<ul id="groupnav">
								<li {if $action == 'index'}class="a"{/if}><a href="forum.php?mod=group&fid=$_G[fid]#groupnav" title="">{lang home}</a></li>
								<li {if $action == 'list'}class="a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]#groupnav" title="">{lang group_discuss_area}</a></li>
								<li {if $action == 'memberlist' || $action == 'invite'}class="a"{/if}><a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]#groupnav" title="">{lang group_member_list}</a></li>
								<!--{if $_G['forum']['ismoderator']}--><li {if $action == 'manage'}class="a"{/if}><a href="forum.php?mod=group&action=manage&fid=$_G[fid]#groupnav">{lang group_admin}</a></li><!--{/if}-->
								<!--{if CURMODULE == 'group'}--><!--{hook/group_nav_extra}--><!--{else}--><!--{hook/forumdisplay_nav_extra}--><!--{/if}-->
							</ul>
						</div>
						<!--{/if}-->
					<!--{/if}-->
					<!--{if $action == 'index' && $status != 2 && $status != 3}-->
						<!--{subtemplate group/group_index}-->
					<!--{elseif $action == 'list'}-->
						<!--{subtemplate group/group_list}-->
					<!--{elseif $action == 'memberlist'}-->
						<!--{subtemplate group/group_memberlist}-->
					<!--{elseif $action == 'create'}-->
						<!--{subtemplate group/group_create}-->
					<!--{elseif $action == 'invite'}-->
						<!--{subtemplate group/group_invite}-->
					<!--{elseif $action == 'manage'}-->
						<!--{subtemplate group/group_manage}-->
					<!--{/if}-->
					<!--{if CURMODULE == 'group'}--><!--{hook/group_bottom}--><!--{else}--><!--{hook/forumdisplay_bottom}--><!--{/if}-->
					<!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]-->
				</div>
				<div class="rtj1009_home_sd ren-group-listsd y">
					<div class="drag">
						<!--[diy=diysidetop]--><div id="diysidetop" class="area"></div><!--[/diy]-->
					</div>
					<!--{subtemplate group/group_right}-->
					<!--{if CURMODULE == 'group'}--><!--{hook/group_side_bottom}--><!--{else}--><!--{hook/forumdisplay_side_bottom}--><!--{/if}-->

					<div class="drag">
						<!--[diy=diy2]--><div id="diy2" class="area"></div><!--[/diy]-->
					</div>

				</div>
			</div>
		</div>
	</div>
</div>
<div class="wp">
	<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
</div>

<!--{template common/footer}-->
