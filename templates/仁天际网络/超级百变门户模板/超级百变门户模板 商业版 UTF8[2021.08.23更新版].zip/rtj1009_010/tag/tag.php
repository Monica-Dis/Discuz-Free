<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if $type != 'countitem'}-->
<div id="ct" class="wp cl">
	<h1 class="mt"><img class="vm" src="{IMGDIR}/tag.gif" alt="tag" /> {lang tag}</h1>
	<div class="bm">
		<div class="bm_c">
			<form method="post" action="misc.php?mod=tag" class="pns">
				<input type="text" name="name" class="px vm" size="30" />&nbsp;
				<button type="submit" class="pn vm"><em>{lang search}</em></button>
			</form>
			<div class="taglist mtm mbm">
				<!--{if $tagarray}-->
					<!--{loop $tagarray $tag}-->
						<a href="misc.php?mod=tag&id=$tag[tagid]" title="$tag[tagname]" target="_blank" class="xi2">$tag[tagname]</a>
					<!--{/loop}-->
				<!--{else}-->
					<p class="emp">{lang no_tag}</p>
				<!--{/if}-->
			</div>
		</div>
	</div>
</div>
<!--{else}-->
$num
<!--{/if}-->
<!--{template common/footer}-->