<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->



<div id="ct" class="rtj1009_ct2 cl">
	<div class="rtj1009_sz_mn">
		<div class="ren_sz_bm">
			<form method="post" autocomplete="off" action="misc.php?mod=faq&action=search" class="y mtn pns">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="searchtype" value="all" />
				<input type="text" name="keyword" size="16" value="$keyword" class="px vm" />
				<button type="submit" name="searchsubmit" class="pn vm" value="yes"><em>{lang search}</em></button>
			</form>
			<!--{if empty($_GET[action])}-->
            <div class="ren_sz_bt">
                <h3>{lang all}{lang faq}</h3>
            </div>
				<div class="lum">
					<!--{loop $faqparent $fpid $parent}-->
						<h2 class="blocktitle"><a href="misc.php?mod=faq&action=faq&id=$fpid">$parent[title]</a></h2>
						<ul name="$parent[title]">
							<!--{loop $faqsub[$parent[id]] $sub}-->
								<li><a href="misc.php?mod=faq&action=faq&id=$sub[fpid]&messageid=$sub[id]">$sub[title]</a></li>
							<!--{/loop}-->
						</ul>
					<!--{/loop}-->
				</div>
			<!--{elseif $_GET[action] == 'faq'}-->
                <div class="ren_sz_bt">
                	<h3>$ctitle</h3>
            	</div>
				<!--{loop $faqlist $faq}-->
					<div id="messageid$faq[id]_c" class="umh{if $messageid != $faq[id]} umn{/if}">
						<h3 onclick="toggle_collapse('messageid$faq[id]', 1, 1);">$faq[title]</h3>
						<div class="umh_act">
							<p class="umh_cb" onclick="toggle_collapse('messageid$faq[id]', 1, 1);">[ {lang open} ]</p>
						</div>
					</div>
					<div class="um" id="messageid$faq[id]" style="{if $messageid != $faq[id]} display: none {/if}">$faq[message]</div>
				<!--{/loop}-->
			<!--{elseif $_GET[action] == 'search'}-->
                <div class="ren_sz_bt">
                	<h3>{lang keyword_faq}</h3>
            	</div>
				<!--{if $faqlist}-->
					<!--{loop $faqlist $faq}-->
						<div class="umh schfaq"><h3>$faq[title]</h3></div>
						<div class="um">$faq[message]</div>
					<!--{/loop}-->
				<!--{else}-->
					<p class="emp">{lang faq_search_nomatch}</p>
				<!--{/if}-->
			<!--{elseif $_GET[action] == 'plugin' && !empty($_GET['id'])}-->
				<!--{eval include(template($_GET['id']));}-->
			<!--{/if}-->
		</div>
	</div>
	<div class="rtj1009_zcd">
		<div class="ren_tbn">
			<ul>
				<li class="cl{if empty($_GET[action])} a{/if}"><a href="misc.php?mod=faq">{lang all}</a><span>></span></li>
				<!--{loop $faqparent $fpid $parent}-->
					<li name="$parent[title]" class="cl{if $_GET[id] == $fpid} a{/if}"><a href="misc.php?mod=faq&action=faq&id=$fpid">$parent[title]</a><span>></span></li>
				<!--{/loop}-->
				<!--{if !empty($_G['setting']['plugins']['faq'])}-->
					<!--{loop $_G['setting']['plugins']['faq'] $id $module}-->
						<li class="cl{if $_GET[id] == $id} a{/if}"><a href="misc.php?mod=faq&action=plugin&id=$id">$module[name]</a><span>></span></li>
					<!--{/loop}-->
				<!--{/if}-->
			</ul>
		</div>
		<!--{hook/faq_extra}-->
	</div>
</div>

<!--{template common/footer}-->