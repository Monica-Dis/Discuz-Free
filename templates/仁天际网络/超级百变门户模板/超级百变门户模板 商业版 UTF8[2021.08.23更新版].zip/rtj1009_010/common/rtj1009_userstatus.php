<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<div class="ren-nav-usbox cl">
    <!--{if $_G['uid']}-->
    <div class="ren-nav-usxx cl">
        <a class="ren-us-name" href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">
            <div class="ren-us-avatar">
                <!--{avatar($_G[uid],small)}-->
                {if $_G[member][newpm] || $_G[member][newprompt]}<div class="dian"></div>{/if}
            </div>
            <span>{$_G[member][username]}</span>
            <i></i>
        </a>
    </div>
    <!--{hook/global_usernav_extra4}-->
    <!--{hook/global_usernav_extra2}-->
    <!--{hook/global_usernav_extra3}-->
    <!--{elseif !empty($_G['cookie']['loginuser'])}-->
    <strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
    <span class="pipe">|</span><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
    <span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
    <!--{elseif !$_G[connectguest]}-->
    <div class="ren-wei-logging y">
        <a class="ren-us-denglu" href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}">登录</a>
        <a class="ren-us-zhucen tu" href="member.php?mod={$_G[setting][regname]}">注册</a>
    </div>
    <!--{else}-->
    <div class="ren-nav-usxx cl">
        <a class="ren-us-name" href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">
            <div class="ren-us-avatar">
                <!--{avatar($_G[uid],small)}-->
                {if $_G[member][newpm] || $_G[member][newprompt]}<div class="dian"></div>{/if}
            </div>
            <span>{$_G[member][username]}</span>
            <i></i>
        </a>
    </div>

    <!--{hook/global_usernav_extra4}-->
    <!--{hook/global_usernav_extra2}-->
    <!--{hook/global_usernav_extra3}-->
    <!--{/if}-->
    <div class="ren-usxx-box cl">
        <div class="ren-usxx-z cl">
            <div class="ren-nav-usxx cl">
                <a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}" class="avatar">
                    <div class="ren-us-avatar">
                        <!--{avatar($_G[uid],small)}-->
                        {if $_G[member][newpm] || $_G[member][newprompt]}<div class="dian"></div>{/if}
                    </div>
                </a>
                <div class="z ren-us-username cl">
                    <div class="ren_us_usnxx cl">
                        <a href="home.php?mod=space&uid=$_G[uid]" class="ren_us_mz z">{$_G[member][username]}</a>
                        <a href="home.php?mod=spacecp&ac=usergroup" class="z ren_us_xing">Lv.12</a>
                    </div>
                    <div class="ren_us_usgroup cl">
                        <a href="home.php?mod=spacecp&ac=usergroup" class="yi">$_G[group][grouptitle]</a>
                        <a href="home.php?mod=spacecp&ac=credit&showcredit=1">{lang credits}：$_G[member][credits]</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="ren-usxx-y">
            <ul class="ren-nav-my cl">
                <li class="ren_top_xlkongjian"><a href="home.php?mod=space&uid=$_G[uid]" target="_blank">我的空间</a></li>
                <li class="ren_top_xlxiaoxi"><a href="home.php?mod=space&do=pm"{if $_G[member][newpm]} class="new"{/if}>我的消息<!--{if $newpmcount}--><strong class="xi1">$newpmcount</strong><!--{/if}--></a></li>
                <!--{if $_G[member][newprompt]}-->
                <!--{loop $_G['member']['category_num'] $key $val}-->
                <li class="ren_$key"><a href="home.php?mod=space&do=notice&view=$key"><!--{echo lang('template', 'notice_'.$key)}--><strong class="xi1">$val</strong></a></li>
                <!--{/loop}-->
                <!--{/if}-->
                <li class="ren_top_xlsoucang"><a href="home.php?mod=space&do=favorite&view=me" target="_blank">我的收藏</a></li>
                <li class="ren_top_xlhaoyou"><a href="home.php?mod=space&do=friend" target="_blank">我的好友</a></li>
                <!--{hook/global_myitem_extra}-->
            </ul>
            <ul class="ren-nav-sz cl">
                <li class="ren_top_xlzhsz"><a href="home.php?mod=spacecp" target="_blank">帐号设置</a></li>
                <!--{if ($_G['group']['allowmanagearticle'] || $_G['group']['allowpostarticle'] || $_G['group']['allowdiy'] || getstatus($_G['member']['allowadmincp'], 4) || getstatus($_G['member']['allowadmincp'], 6) || getstatus($_G['member']['allowadmincp'], 2) || getstatus($_G['member']['allowadmincp'], 3))}-->
                <li class="ren_top_xlmhgl"><a href="portal.php?mod=portalcp" target="_blank"><!--{if $_G['setting']['portalstatus'] }-->{lang portal_manage}<!--{else}-->{lang portal_block_manage}<!--{/if}--></a></li>
                <!--{/if}-->
                <!--{if $_G['uid'] && $_G['group']['radminid'] > 1}-->
                <li class="ren_top_snlt"><a href="forum.php?mod=modcp&fid=$_G[fid]" target="_blank">{lang forum_manager}</a></li>
                <!--{/if}-->
                <!--{if $_G['uid'] && getstatus($_G['member']['allowadmincp'], 1)}-->
                <li class="ren_top_xlht"><a href="admin.php" target="_blank">{lang admincp}</a></li>
                <!--{/if}-->
                <!--{if check_diy_perm($topic)}-->
                <li class="ren_top_xldiy"><a href="javascript:openDiy();" title="{lang open_diy}">DIY 设置</a></li>
                <!--{/if}-->
                <li class="ren_top_xltcdl"><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">退出登录</a></li>
                <!--{hook/global_usernav_extra1}-->
            </ul>
        </div>
    </div>
</div>