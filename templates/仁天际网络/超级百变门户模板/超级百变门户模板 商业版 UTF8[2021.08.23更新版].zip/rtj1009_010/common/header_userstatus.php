<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{if $_G['uid']}-->
	<div class="rtj_yonghutouxiang"><a href="home.php?mod=space&uid=$_G[uid]"><!--{avatar($_G[uid],small)}--></a></div>
		<strong class="yonghuming"{if $_G['setting']['connect']['allow'] && $_G[member][conisbind]} class="qq"{/if}><a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">{$_G[member][username]}</a></strong>

            <!--{hook/global_usernav_extra1}-->
        	<a id="rtj_xiaoxi" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});"{if $_G[member][newpm] || $_G[member][newprompt]} class="ynew"{/if}>我的</a>
            <a id="rtj_shezhi" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});">设置</a>
            
            <!--{if $_G['uid'] && !empty($_G['style']['extstyle']) && count($_G['style']['extstyle']) > 1}--><a id="ren_sslct" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});">风格</a><!--{/if}-->
        <!--{hook/global_usernav_extra4}-->
		<!--{hook/global_usernav_extra2}-->
		<!--{hook/global_usernav_extra3}-->
<!--{elseif !empty($_G['cookie']['loginuser'])}-->
	<strong><a id="loginuser" class="noborder"><!--{echo dhtmlspecialchars($_G['cookie']['loginuser'])}--></a></strong>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=login" onclick="showWindow('login', this.href)">{lang activation}</a>
	<span class="pipe">|</span><a href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang logout}</a>
<!--{elseif !$_G[connectguest]}-->
	<!--{if $ren_hd_kjdl}-->
	<a class="ren_qqdl" href="connect.php?mod=login&op=init&referer=index.php&statfrom=login_simple"><!--{if $ren_hd_kjdlwz}-->QQ登录<!--{/if}--></a>
    <a class="ren_wxdl" href="$pc_hd_wxlogin" onclick="showWindow('comiis_wxlogin', this.href, 'get', 0);"><!--{if $ren_hd_kjdlwz}-->微信登录<!--{/if}--></a>
	<!--{/if}-->
	<a id="rtj_ydenglu" href="member.php?mod=logging&action=login&referer={echo rawurlencode($dreferer)}">登录</a>
	<a id="rtj_yzhucen" href="member.php?mod={$_G[setting][regname]}">注册</a>
<!--{else}-->
<div class="rtj_yonghutouxiang"><a href="home.php?mod=space&uid=$_G[uid]"><!--{avatar($_G[uid],small)}--></a></div>
	<strong class="yonghuming"{if $_G['setting']['connect']['allow'] && $_G[member][conisbind]} class="qq"{/if}><a href="home.php?mod=space&uid=$_G[uid]" target="_blank" title="{lang visit_my_space}">{$_G[member][username]}</a></strong>

		<!--{hook/global_usernav_extra1}-->
		<a id="rtj_xiaoxi" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});"{if $_G[member][newpm] || $_G[member][newprompt]} class="ynew"{/if}>我的</a>
		<a id="rtj_shezhi" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});">设置</a>

        <!--{if $_G['uid'] && !empty($_G['style']['extstyle']) && count($_G['style']['extstyle']) > 1}--><a id="ren_sslct" href="javascript:;" onMouseOver="showMenu({'ctrlid':this.id,'pos':'34','ctrlclass':'on','duration':2});">风格</a><!--{/if}-->
	<!--{hook/global_usernav_extra4}-->
	<!--{hook/global_usernav_extra2}-->
	<!--{hook/global_usernav_extra3}-->
<!--{/if}-->