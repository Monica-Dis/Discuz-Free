<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_list.php 2017-08-10 18:07:44Z rtj1009_app $
 */

if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}



$ren_home_bgstyle = $_G['cache']['plugin']['rtj1009_democp']['ren_home_hdstyle'];
$youhuid = $space[uid];
$yonghuzuid = DB::result(DB::query("SELECT groupid FROM ".DB::table('common_member')." WHERE `uid`= $youhuid"));
$yonghuzu = DB::result(DB::query("SELECT grouptitle FROM ".DB::table('common_usergroup')." WHERE groupid = '$yonghuzuid'"));
$homeyuid = $space[uid];
$jifen = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid=$homeyuid");




?>