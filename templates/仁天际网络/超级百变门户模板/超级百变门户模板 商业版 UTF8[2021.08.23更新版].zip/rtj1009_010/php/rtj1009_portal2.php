<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_core.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */
 
if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}

$catid = $rtj1009_democp['ren_portal_cat'];
$perpage = $rtj1009_democp['ren_portal_page'];
$curpage = empty ( $_GET['page'] ) ? 1 : intval ( $_GET['page'] );
$start = ($curpage-1)*$perpage;
$maxpagenum = $rtj1009_democp['ren_portal_maxpagenum'] ? intval($rtj1009_democp['ren_portal_maxpagenum']) : 1000;

if ($rtj1009_democp['ren_portal_order'] == 1) {
    $orderby = "ORDER BY a.aid DESC LIMIT";
} else if ($rtj1009_democp['ren_portal_order'] == 2) {
    $orderby = "ORDER BY a.aid DESC LIMIT";
} else if ($rtj1009_democp['ren_portal_order'] == 3) {
    $orderby = "ORDER BY b.viewnum DESC LIMIT";
} else if ($rtj1009_democp['ren_portal_order'] == 4) {
    $orderby = "ORDER BY b.commentnum DESC LIMIT";
}


if (!empty($catid)) {
    $portalacount = DB::query("SELECT a.*,b.* FROM ".DB::table('portal_article_title')." a LEFT JOIN ".DB::table('portal_article_count')." b ON b.aid = a.aid WHERE a.catid in ($catid) AND a.status = '0' $orderby $maxpagenum");
    $num = DB::num_rows($portalacount);
}

$portallist = array();
if ($num) {
    $query = DB::query("SELECT a.*,b.* FROM ".DB::table('portal_article_title')." a LEFT JOIN ".DB::table('portal_article_count')." b ON b.aid = a.aid WHERE a.catid in ($catid) AND a.status = '0' $orderby $start,$perpage");
    while ($value = DB::fetch($query)) {
        $portallist[] = $value;
    }
}

$renpages = ceil($num / $perpage);
$multi = multi($num, $perpage, $curpage, "portal.php?mod=index");

?>