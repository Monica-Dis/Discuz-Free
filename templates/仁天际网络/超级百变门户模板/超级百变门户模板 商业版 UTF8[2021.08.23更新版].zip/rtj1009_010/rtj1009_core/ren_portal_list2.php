<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
    require_once DISCUZ_ROOT.'./template/rtj1009_010/php/rtj1009_portal2.php';
    require_once DISCUZ_ROOT.'./template/rtj1009_010/php/rtj1009_list.php';
    include_once libfile('function/post');
}-->

<!--{loop $portallist $key $value}-->
<!--{if $rtj1009_democp['ren_portal_left']}-->
<!--{eval $rtj1009_msg = messagecutstr(rtj1009_msg($value['summary']),110);}-->
<!--{else}-->
<!--{eval $rtj1009_msg = messagecutstr(rtj1009_msg($value['summary']),150);}-->
<!--{/if}-->
<!--{eval
	$catname = DB::result_first("SELECT catname FROM ".DB::table("portal_category")." WHERE `catid` = $value[catid]");
}-->
<li class="ren-index-list-liyi">
    <div class="ren-index-list-yiimg">
        <!--{if $value['pic'] || $imgurlx}-->
        <a href="portal.php?mod=view&aid=$value['aid']" class="ren-index-threadimg z">
            <!--{if $value['pic']}-->
                <span class="ren-thread-imge ren-thread-img"><img src="<!--{if $value['remote']}-->{$_G['setting']['ftp']['attachurl']}<!--{/if}-->data/attachment/{$value['pic']}.thumb.jpg" alt="$value['title']"/></span>
            <!--{elseif $imgurlx}-->
                <!--{eval echo $imgurlx;}-->
            <!--{/if}-->
        </a>
        <!--{/if}-->
        <div class="ren-index-xx-bt yi">
            <a href="portal.php?mod=view&aid=$value['aid']">{$value[title]}</a>
        </div>
        <div class="ren-index-xx-msg">
            <!--{if $value['summary']}-->
            <a href="portal.php?mod=view&aid=$value['aid']">{$rtj1009_msg}</a>
            <!--{/if}-->
        </div>
        <div class="ren-index-us cl">
            <!--{if $rtj1009_democp['ren_portal_lzforums']}-->
            <div class="ren-index-lzforums z">
                <a href="forum.php?mod=forumdisplay&fid=$value['catid']">{$catname}</a>
            </div>
            <!--{/if}-->
            <a href="home.php?mod=space&uid=$value['uid']" class="ren-index-us-img z cl">
                <!--{avatar($value[authorid],middle)}-->
            </a>
            <a href="home.php?mod=space&uid=$value['uid']" class="ren-index-us-name z cl">{$value[username]}</a>
            <span class="time z"><!--{echo dgmdate($value[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
            <a href="portal.php?mod=view&aid=$value['aid']" class="ren-index-us-sun y">
                <span class="reply y">{$value['commentnum']}</span>
                <span class="views y">{$value['viewnum']}</span>
            </a>
        </div>
    </div>
</li>
<!--{/loop}-->

