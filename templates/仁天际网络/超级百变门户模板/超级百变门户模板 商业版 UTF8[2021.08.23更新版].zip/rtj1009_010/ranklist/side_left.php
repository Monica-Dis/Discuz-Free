<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_tbn">
	<ul>
		<li class="cl{if $_GET['type'] == 'index' || !$_GET['type']} a{/if}"><a href="misc.php?mod=ranklist">{lang all}</a><span>></span></li>
		<!--{if $ranklist_setting['member']['available']}-->
		<li class="cl{if $_GET['type'] == 'member'} a{/if}"><a href="misc.php?mod=ranklist&type=member">{lang user}</a><span>></span></li>
		<!--{/if}-->
		<!--{if $ranklist_setting['thread']['available']}-->
		<li class="cl{if $_GET['type'] == 'thread'} a{/if}"><a href="misc.php?mod=ranklist&type=thread&view=replies&orderby=thisweek">{lang posts}</a><span>></span></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('blog') && $ranklist_setting['blog']['available']}-->
		<li class="cl{if $_GET['type'] == 'blog'} a{/if}"><a href="misc.php?mod=ranklist&type=blog&view=heats&orderby=thisweek">{lang blogs}</a><span>></span></li>
		<!--{/if}-->
		<!--{if $ranklist_setting['poll']['available']}-->
		<li class="cl{if $_GET['type'] == 'poll'} a{/if}"><a href="misc.php?mod=ranklist&type=poll&view=heats&orderby=thisweek">{lang poll}</a><span>></span></li>
		<!--{/if}-->
		<!--{if $ranklist_setting['activity']['available']}-->
		<li class="cl{if $_GET['type'] == 'activity'} a{/if}"><a href="misc.php?mod=ranklist&type=activity&view=heats&orderby=thismonth">{lang activity}</a><span>></span></li>
		<!--{/if}-->
		<!--{if helper_access::check_module('album') && $ranklist_setting['picture']['available']}-->
		<li class="cl{if $_GET['type'] == 'picture'} a{/if}"><a href="misc.php?mod=ranklist&type=picture&view=hot&orderby=thismonth">{lang pics}</a><span>></span></li>
		<!--{/if}-->
		<!--{if $ranklist_setting['forum']['available']}-->
		<li class="cl{if $_GET['type'] == 'forum'} a{/if}"><a href="misc.php?mod=ranklist&type=forum&view=threads">{lang forum}</a><span>></span></li>
		<!--{/if}-->
		<!--{if $ranklist_setting['group']['available']&&$_G[setting]['groupstatus']}-->
		<li class="cl{if $_GET['type'] == 'group'} a{/if}"><a href="misc.php?mod=ranklist&type=group&view=credit">{lang group}</a><span>></span></li>
		<!--{/if}-->
	</ul>
	<!--{hook/ranklist_nav_extra}-->
</div>