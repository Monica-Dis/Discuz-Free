<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if $_GET['op'] == 'show'}-->
	<!--{template home/space_click}-->
<!--{/if}-->

<!--{template common/footer}-->