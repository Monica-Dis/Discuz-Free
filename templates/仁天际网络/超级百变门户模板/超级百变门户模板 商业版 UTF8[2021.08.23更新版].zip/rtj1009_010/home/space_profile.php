<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G[setting][homepagestyle]}-->
	<!--{subtemplate home/space_header}-->
	<div id="ren_ct" class="rtj1009_lai_ct cl">
		<div class="ren_lai_mn z">
			<div class="bm bw0">
				<div class="ren_bm_c">
<!--{else}-->
	<!--{template common/header}-->
	
	<style id="diy_style" type="text/css"></style>
	<div class="wp">
		<!--[diy=diy1]--><div id="diy1" class="area"></div><!--[/diy]-->
	</div>
	<!--{template home/space_menu}-->
	<div id="ct" class="rtj1009_ct cl">
		<div class="ren_g_mn">
			<!--[diy=diycontenttop]--><div id="diycontenttop" class="area"></div><!--[/diy]-->
			<div class="bm bw0">
				<div class="ren_bm_c">
<!--{/if}-->

				<!--{subtemplate home/space_profile_body}-->
		
				<!--{if !$_G[setting][homepagestyle]}--><!--[diy=diycontentbottom]--><div id="diycontentbottom" class="area"></div><!--[/diy]--><!--{/if}-->
				</div>
			</div>
			<!--{if $_G[setting][homepagestyle]}-->
		</div>
		<div class="rtj1009_home_sd y">
			<!--{subtemplate home/space_userabout}-->
		<!--{/if}-->
	</div>
</div>

<!--{if !$_G[setting][homepagestyle]}-->
	<div class="wp mtn">
		<!--[diy=diy3]--><div id="diy3" class="area"></div><!--[/diy]-->
	</div>
<!--{/if}-->
<!--{template common/footer}-->