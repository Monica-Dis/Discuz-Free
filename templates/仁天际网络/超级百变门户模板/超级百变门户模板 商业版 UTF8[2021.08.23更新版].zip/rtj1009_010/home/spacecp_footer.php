<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>

	<ul class="ren_tbn">
		<li$actives[avatar]><a href="home.php?mod=spacecp&ac=avatar">{lang memcp_avatar}</a><span>></span></li>
		<li$actives[profile]><a href="home.php?mod=spacecp&ac=profile">{lang memcp_profile}</a><span>></span></li>
		<!--{if $_G['setting']['verify']['enabled'] && allowverify() || $_G['setting']['my_app_status'] && $_G['setting']['videophoto']}-->
		<li$actives[verify]><a href="{if $_G['setting']['verify']['enabled']}home.php?mod=spacecp&ac=profile&op=verify{else}home.php?mod=spacecp&ac=videophoto{/if}">我的认证</a><span>></span></li>
		<!--{/if}-->
		<li$actives[credit]><a href="home.php?mod=spacecp&ac=credit">我的积分</a><span>></span></li>
		<li$actives[usergroup]><a href="home.php?mod=spacecp&ac=usergroup">用 户 组</a><span>></span></li>
		<li$actives[privacy]><a href="home.php?mod=spacecp&ac=privacy">空间设置</a><span>></span></li>
		
		<!--{if $_G['setting']['sendmailday']}--><li$actives[sendmail]><a href="home.php?mod=spacecp&ac=sendmail">{lang memcp_sendmail}</a><span></span></li><!--{/if}-->
		<li$actives[password]><a href="home.php?mod=spacecp&ac=profile&op=password">{lang password_security}</a><span>></span></li>

		<!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}-->
		<li$actives[promotion]><a href="home.php?mod=spacecp&ac=promotion">{lang memcp_promotion}</a><span>></span></li>
		<!--{/if}-->
		<!--{if !empty($_G['setting']['plugins']['spacecp'])}-->
			<!--{loop $_G['setting']['plugins']['spacecp'] $id $module}-->
				<!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}--><li{if $_GET[id] == $id} class="a"{/if}><a href="home.php?mod=spacecp&ac=plugin&id=$id">$module[name]</a><span>></span></li><!--{/if}-->
			<!--{/loop}-->
		<!--{/if}-->
	</ul>