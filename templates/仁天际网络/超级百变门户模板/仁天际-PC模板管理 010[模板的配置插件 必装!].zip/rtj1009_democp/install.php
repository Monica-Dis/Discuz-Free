<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_rtj1009_style` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `bid` int(10) DEFAULT NULL,
  `style` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_rtj1009_menu` (
    `id` int(10) NOT NULL AUTO_INCREMENT,
    `status` tinyint(1) NOT NULL DEFAULT 1,
    `displayorder` smallint(6) NOT NULL DEFAULT '0', 
    `title` varchar(32) NOT NULL DEFAULT '',
    `icon` varchar(255) NOT NULL DEFAULT '',
    `url` varchar(255) NOT NULL Default '', 
    PRIMARY KEY (`id`)
)ENGINE=MyISAM;

EOF;
runquery($sql);

$menulist = C::t('#rtj1009_democp#rtj1009_menu')->fetch_all();
if (!$menulist) {
    $data = array(
        '1' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0055'),
            'icon' => 'template/rtj1009_010/icon/zt2.png',
            'url' => '#',
        ),
        '2' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0056'),
            'icon' => 'template/rtj1009_010/icon/qg2.png',
            'url' => '#',
        ),
        '3' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0057'),
            'icon' => 'template/rtj1009_010/icon/fc2.png',
            'url' => '#',
        ),
        '4' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0058'),
            'icon' => 'template/rtj1009_010/icon/jj2.png',
            'url' => '#',
        ),
        '5' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0059'),
            'icon' => 'template/rtj1009_010/icon/ms2.png',
            'url' => '#',
        ),
        '6' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0060'),
            'icon' => 'template/rtj1009_010/icon/ly2.png',
            'url' => '#',
        ),
        '7' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0061'),
            'icon' => 'template/rtj1009_010/icon/qz2.png',
            'url' => '#',
        ),
        '8' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0062'),
            'icon' => 'template/rtj1009_010/icon/jy2.png',
            'url' => '#',
        ),
        '9' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0063'),
            'icon' => 'template/rtj1009_010/icon/zp2.png',
            'url' => '#',
        ),
        '10' => array (
            'title' => lang('plugin/rtj1009_democp', 'rtj1009_0064'),
            'icon' => 'template/rtj1009_010/icon/fw2.png',
            'url' => '#',
        ),
    );

    foreach($data as $value) {
        C::t('#rtj1009_democp#rtj1009_menu')->insert($value);
    }
}


$identifier = 'rtj1009_democp';
/* 删除文件 */
$extras = array("SC_UTF8","SC_GBK","TC_UTF8","TC_BIG5");
$entrydir = DISCUZ_ROOT.'./source/plugin/'.$identifier;
foreach($extras as $extra){
  @unlink($entrydir.'/discuz_plugin_'.$identifier."_".$extra.'.xml');
}
@unlink($entrydir.'/discuz_plugin_'.$identifier.'.xml');
@unlink($entrydir.'/install.php');
$finish = true;
?>