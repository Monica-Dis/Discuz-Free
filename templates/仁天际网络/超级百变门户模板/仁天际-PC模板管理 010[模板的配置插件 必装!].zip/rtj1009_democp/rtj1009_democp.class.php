<?php

/**
 *      [仁天际-PC模板管理] (C)2001-2099 DisM.Taobao.Com.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_democp.class.php 2017-08-10 18:07:44Z rtj1009_democp $
 */

if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}

class plugin_rtj1009_democp { 
       function global_header() {
            global $_G,$style,$config;
			loadcache('plugin');
			$config = $_G['cache']['plugin']['rtj1009_democp'];
			
			if($_G[fid] && CURMODULE=='forumdisplay'){//如果有板块ID在执行
				
				$style =  $this->get_style_value();
			}
      }
	  
	 /* 通过 fid 返回
	  * $fid  板块ID 
	  * 返回style 值 0 默认|1 样式一|2 样式二 |3 样式二 
	  * 前端调用 if  $style['style'] ==1/2/3  执行代码  else  执行代码
	 */
	function get_style_value( ) {
		global $_G;	
		
		$style = DB::fetch_first('SELECT * FROM ' . DB::table('rtj1009_style') . " WHERE bid='$_G[fid]' " );
			
		return $style;
	}
	
	function discuzcode() {
		require_once libfile('function/rtj1009_vedio','plugin/rtj1009_democp');
		global $_G;
		$config = $_G['cache']['plugin']['rtj1009_democp'];
		if ($config['pc_video_radio']) {
			if (strstr($_G['discuzcodemessage'],'[/media]')) {
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i","rtj1009_vedio",$_G['discuzcodemessage']);
			}
			if (strstr($_G['discuzcodemessage'],'[/video]')) {
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i","rtj1009_vedio",$_G['discuzcodemessage']);
			}
		}
	}
}

   

?>