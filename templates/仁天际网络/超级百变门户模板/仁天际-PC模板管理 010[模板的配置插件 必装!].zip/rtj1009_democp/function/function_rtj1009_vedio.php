<?php
/**
 *      [仁天际-手机版管理] (C)2001-2099 1009.com.cn.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: function_rtj1009_vedio.php 2017-08-10 18:07:44Z rtj1009_democp $
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function rtj1009_vedio($vedio_url) {
	global $_G;
	$url = $vedio_url[2];
	$config = $_G['cache']['plugin']['rtj1009_democp'];
	$width = $config['pc_vedio_width']?$config['pc_vedio_width']:'100%';
	$height = $config['pc_vedio_height'];
	$url_array = array_filter(explode('/',$url));
	$http = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";

    if (strpos($url, 'youku.com') !== FALSE) {
        if (strpos($url_array[count($url_array)],'.html') !== FALSE) {
            $src = $http."player.youku.com/embed/".str_replace('id_','',str_replace('.html','',$url_array[count($url_array)]));
            return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
        } else if(strpos($url,'.swf') !== FALSE) {
            $string = end(explode('/',current(array_filter(explode('/v.swf',$url)))));
            $src = $http."player.youku.com/embed/".$string;
            return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
        }
    }

    if (strpos($url, 'tudou.com/v/') !== FALSE) {
        $src = $http."player.youku.com/embed/".str_replace('id_','',str_replace('.html','',$url_array[count($url_array)]));
        return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
    }

    if (strpos($url, 'qq.com/x/page/') !== FALSE) {
        if (strpos($url_array[count($url_array)],'.html') !== FALSE) {
            $src = $http."v.qq.com/iframe/player.html?vid=".str_replace('.html','',$url_array[count($url_array)])."&auto=0";
            return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';

        } else if(strpos($url,'.swf') !== FALSE) {
            $string = current(explode('&',end(array_filter(explode('vid=',$url)))));
            $src = $http."v.qq.com/iframe/player.html?vid=".$string."&auto=0";
            return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
        }
    } else if (strpos($url, 'qq.com/x/cover/') !== FALSE) {
        if (strpos($url_array[count($url_array)],'.html') !== FALSE) {
            $src = $http."v.qq.com/txp/iframe/player.html?vid=".str_replace('.html','',$url_array[count($url_array)])."&auto=0";
            return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';

        } else if(strpos($url,'.swf') !== FALSE) {
            $string = current(explode('&',end(array_filter(explode('vid=',$url)))));
            $src = $http."v.qq.com/txp/iframe/player.html?vid=".$string."&auto=0";
            return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
        }
    }

    if (strpos($url, 'iqiyi.com') !== FALSE) {
        if (strpos($url_array[count($url_array)],'.html') !== FALSE || strpos($url,'.swf') !== FALSE) {
            $string = current(explode('&accessToken',end(array_filter(explode('vid=',$url)))));
            $src = $http."open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=".$string;
            return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
        }
    }

    if (strpos($url, 'ixigua.com') !== FALSE) {
        if(preg_match("/^https?:\/\/(|m.|www.)ixigua.com\/(\d+)/i", $url, $matches)) {
            $src = 'https://www.ixigua.com/iframe/'.$matches[2];
            return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
        }
    }

    if (strpos($url, 'acfun.') !== FALSE) {
        if(preg_match("/https?:\/\/(www.|)acfun.(cn|tv)\/v\/ac(\d+)/i", $url, $matches)) {
            $vid = $matches[3];
            $src = 'https://www.acfun.cn/player/ac'.$vid;
        } elseif(preg_match("/https?:\/\/m.acfun.(cn|tv)\/v\/\?ac=(\d+)/i", $url, $matches)) {
            $vid = $matches[2];
            $src = 'https://www.acfun.cn/player/ac'.$vid;
        }
        return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
    }

    if (strpos($url, 'bilibili.') !== FALSE) {
        if(preg_match("/https?:\/\/(m.|www.|)bilibili.(com|tv)\/video\/(a|b)v([A-Za-z0-9]+)(\/?.*?&p=|\/?\?p=)?(\d+)?/i", $url, $matches)) {
            $vid = (is_numeric($matches[4]) ? 'aid='.$matches[4] : 'bvid='.$matches[4]) . (empty($matches[6]) ? '' : '&page='.intval($matches[6]));
            $src = 'https://player.bilibili.com/player.html?'.$vid;
        } else if(preg_match("/https?:\/\/(www.|)(acg|b23).tv\/(a|b)v([A-Za-z0-9]+)(\/?.*?&p=|\/?\?p=)?(\d+)?/i", $url, $matches)) {
            $vid = (is_numeric($matches[4]) ? 'aid='.$matches[4] : 'bvid='.$matches[4]) . (empty($matches[6]) ? '' : '&page='.intval($matches[6]));
            $src = 'https://player.bilibili.com/player.html?'.$vid;
        }
        return '<div class="rtj1009_video"><iframe src="'.$src.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen="true"></iframe></div>';
    }
	
}
//From: Dism·taobao·com
?>