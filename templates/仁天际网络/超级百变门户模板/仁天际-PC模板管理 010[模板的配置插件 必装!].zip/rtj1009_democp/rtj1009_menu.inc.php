<?php

/**
 *      [仁天际-PC模板管理] (C)2001-2099 DisM.Taobao.Com.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_menu.inc.php 2017-08-10 18:07:44Z rtj1009_democp $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}



$ren_url = 'plugins&operation=config&do=' . $pluginid . '&identifier=rtj1009_democp&pmod=rtj1009_menu';
$plug_url = ADMINSCRIPT . '?action='.$ren_url.'';

$menulist = C::t('#rtj1009_democp#rtj1009_menu')->fetch_all();
if (submitcheck('menulistsubmit')) {
    foreach ($_GET['title'] as $key => $value) {
        C::t('#rtj1009_democp#rtj1009_menu')->update($key, array(
            'icon' => $_GET['icon'][$key],
            'title' => $_GET['title'][$key],
            'url' => $_GET['url'][$key],
            'status' => $_GET['status'][$key] ? 1 : 0
        ));
    }
    cpmsg(lang('plugin/rtj1009_democp', 'cr_cg'), 'action='.$ren_url.'', 'succeed');
} else {
    showtips(lang('plugin/rtj1009_democp', 'rtj1009_0125'),'',true,lang('plugin/rtj1009_democp', 'rtj1009_0124'));
    showformheader(''.$ren_url.'', 'enctype');
    showtableheader(lang('plugin/rtj1009_democp', 'rtj1009_0101'), 'fixpadding');
    showsubtitle(array(
        lang('plugin/rtj1009_democp', 'rtj1009_0013'),
        lang('plugin/rtj1009_democp', 'rtj1009_0101'),
        lang('plugin/rtj1009_democp', 'rtj1009_0102'),
        lang('plugin/rtj1009_democp', 'rtj1009_0103'),
    ));

    foreach($menulist as $key => $value) {
        $isstatu = $value['status'] ? 'checked' : '';
        showtablerow('', array('class="td29 td31"', 'class="td29 td31"', 'class="td29 td31"', ''), array(
            "<input class=\"checkbox\" type=\"checkbox\" name=\"status[$value[id]]\" value=\"checkbox\" $isstatu>",
            "<input class=\"text\" type=\"txt\" name=\"title[$value[id]]\" value=\"$value[title]\" >",
            "<input class=\"text\" type=\"txt\" name=\"icon[$value[id]]\" value=\"$value[icon]\" >",
            "<input class=\"text\" style=\"width:100%\" type=\"txt\" name=\"url[$value[id]]\" value=\"$value[url]\" >",
        ));
    }

    showsubmit('menulistsubmit', lang('plugin/rtj1009_democp', 'rtj1009_013'));
    showtablefooter(); /*dism·taobao·com*/
    showformfooter(); /*Dism_taobao-com*/


}
