<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<script type="text/javascript" src='template/rtj1009_app/js/ren_share.js'></script>
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header-->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_dqwz z">
            <span class="ren_bk_name">$topic[title]</span>
        </div>
        <div class="ren_nav_right">
            <div class="ren_view_navgd open-popover"><span class="icon ren-font">&#xe677;</span></div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="ren_nav_gd popover">
    <div class="popover-angle on-top"></div>
    <div class="ren_gd_list close-popover cl">
        <a href="javascript:;" class="ren_viewdi_fx ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe613;</i><span>{$rtj1009_lang['ren089']}</span></a>
        <a href="portal.php?mod=index" class="ren_gd_fh"><i class="icon ren-font">&#xe605;</i><span>{$rtj1009_lang['ren201']}</span></a>
    </div>
</div>

<div class="content p-b-0">
    {$block_topic}
</div>


<script type="text/javascript">
    $('.ren_share').ready(function(){
        var share = new ren_share({
            title : document.title,
            url   : window.location.href,
            desc  : document.getElementsByName('description')[0].content,
            img   : '$ren_wx_imgUrl',
        });
        $('.ren_share').click(function () {
            share.init(0,'.ren_view_share');
        });
    });
</script>
<div id="popup-share" class="popup popup-share">
    <div class="content-block">
        <div class="ren_tiefx_share">
            <div class="bdsharebuttonbox">
                <a href="javascript:;" class="popup_sqq" data-cmd="sqq"><p>{$rtj1009_lang['ren100']}</p></a>
                <a href="javascript:;" class="bds_qzone" data-cmd="qzone"><p>{$rtj1009_lang['ren101']}</p></a>
                <a href="javascript:;" class="bds_tsina" data-cmd="tsina"><p>{$rtj1009_lang['ren102']}</p></a>
                <a href="javascript:;" class="bds_weixin" data-cmd="weixin"><p>{$rtj1009_lang['ren103']}</p></a>
                <a href="javascript:;" class="bds_copy" data-cmd="copy"><p>{$rtj1009_lang['ren212']}</p></a>
            </div>
        </div>
    </div>
    <a href="javascript:;" class="ren_tiefx_qx close-popup">{$rtj1009_lang['ren012']}</a>
</div>

<!--{template common/footer}-->