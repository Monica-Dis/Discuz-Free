<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval $list = array();}-->
<!--{eval $wheresql = category_get_wheresql($cat);}-->
<!--{eval $list = category_get_list($cat, $wheresql, $page);}-->
<!--{eval $realpages = @ceil(($list['count'])/$cat[perpage]);}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header-->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_dqwz z">
            <span class="ren_bk_name">$cat[catname]</span>
        </div>
		<div class="y ren_list_nav">
            <!--{if ($_G['group']['allowpostarticle'] || $_G['group']['allowmanagearticle'] || $categoryperm[$catid]['allowmanage'] || $categoryperm[$catid]['allowpublish']) && empty($cat['disallowpublish'])}-->
            <a href="portal.php?mod=portalcp&ac=article&catid=$cat[catid]" class="ren_nav_fb"><span class="icon ren-font">&#xe619;</span></a>
            <!--{/if}-->
			<a href="search.php?mod=portal" class="ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content<!--{if !$rtj1009_m_config['ren_m_forum_bar']}--> p-b-0<!--{/if}-->">
	<div class="rtj1009_wz_list ren-wz-list">
	<!--{if $rtj1009_m_config['ren_portal_list_nav']}-->
		<div class="rtj1009-nav-swiper">
			<div class="swiper-container2 ren_m_lx">
				<ul class="swiper-wrapper">
					<!--{loop $cat[others] $value}-->
					<li class="swiper-slide{if $_GET['catid'] == $value[catid]} a{/if}"><a href="{$portalcategory[$value['catid']]['caturl']}">$value[catname]</a></li>

					<!--{/loop}-->
				</ul>
			</div>
		</div>
	<!--{/if}-->

    <!--{eval echo rtj1009_list_block($_GET['catid']);}-->
	
	
	<!--{if $list['list']}-->
		<div class="ren_yixz_xx cl">
			<ul class="wz_list cl">
			<!--{loop $list['list'] $value}-->
				<!--{eval $highlight = article_title_style($value);}-->
				<!--{eval $article_url = fetch_article_url($value);}-->
                <li class="ren_yixzxxk zbxxk1">
					<!--{if $value[pic]}--><a href="$article_url" class="z ren_tieimg"><img src="$value[pic]" alt="$value[title]" class="tn" /></a><!--{/if}-->
					<a href="$article_url" class="ren_tiexx cl">
						<div class="ren_twbt">
							<span>
								$value[title]<!--{if $value[status] == 1}-->({lang moderate_need})<!--{/if}-->
							</span>
						</div>
						<div class="ren_twxxx">
							<span class="z ren_tie_ztfl">$value[dateline]</span>
						</div>
					</a>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
        <!--{if $list['multi']}-->$list['multi']<!--{/if}-->
        <!--{if $rtj1009_m_config['ren_portal_listwx']}-->
        <script type="text/javascript">
            var curpage = $page;
            var ren_loading = false;
            var html = '';
            var ren_loading_ing='<div class="ren_loading loading">{$rtj1009_lang[ren018]}</div>';
            var ren_loading_end='<div class="ren_loading">{$rtj1009_lang[ren019]}</div>';
            $(document).ready(function(){
                $(".page").html(ren_loading_ing);
                $(window).scroll(function () {
                    if ($(document).scrollTop() + $(window).height()> $(document).height() - 130 && !ren_loading) {
                        ren_loading = true;
                        ren_list_page();
                    }
                });
            });

            function ren_list_page() {
                curpage++;
                var caturl = '$cat[caturl]';
                if (caturl.indexOf('portal') > -1) {
                    var url = '$cat[caturl]&page=' + curpage;
                } else {
                    var url = '$cat[caturl]index.php?page=' + curpage;
                }
                $.ajax({
                    url : url,
                    data : null,
                    dataType : "html",
                    cache: false,
                    success : function(s) {
                        if(curpage >= $realpages){
                            $(".page").html(ren_loading_end);
                        }
                        s = s.replace(/\n|\r/g, '');
                        var nexts = s.match(/<ul class="wz_list cl">(.+?)<\/ul>/);
                        var pagenum = s.match(/<strong>(\d+)<\/strong>/);
                        pagenum = parseInt(pagenum[1]);

                        if(pagenum == $realpages){
                            ren_loading = false;
                        }else{

                            if(nexts[1]){
                                $(nexts[1]).insertAfter($(".wz_list>li").last());
                            }
                            ren_loading = false;
                        }
                    }
                });
            }
        </script>
        <!--{/if}-->
	<!--{else}-->
        <!--{if $rtj1009_m_config['ren_portal_list_wu']}-->
		<div class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{$rtj1009_lang['ren132']}</span>
		</div>
        <!--{/if}-->
	<!--{/if}-->
	</div>
</div>
<!--{template common/footer}-->