<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
<script type="text/javascript" src='template/rtj1009_app/js/ren_share.js'></script>
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']), imagemaxwidth = '{$_G['setting']['imagemaxwidth']}', aimgcount = new Array();</script>

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:;" onclick="renBack()" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span class="ren_bk_name">
				<a href="{echo getportalcategoryurl($cat[catid])}">{$rtj1009_lang['ren121']}</a>
			</span>
		</div>
		<div class="ren_nav_right">
            <div class="ren_view_navgd open-popover"><span class="icon ren-font">&#xe677;</span></div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="ren_nav_gd popover">
	<div class="popover-angle on-top"></div>
	<div class="ren_gd_list close-popover cl">
		<a href="javascript:;" class="ren_viewdi_fx ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe613;</i><span>{$rtj1009_lang['ren089']}</span></a>
		<a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_gd_jb"><i class="icon ren-font">&#xe603;</i><span>{lang favorite}</a>
		<a href="{echo getportalcategoryurl($cat[catid])}" class="ren_gd_fh close-popover"><i class="icon ren-font">&#xe641;</i><span>{$rtj1009_lang['ren122']}</span></a>
        <a href="portal.php?mod=index" class="ren_gd_fh"><i class="icon ren-font">&#xe605;</i><span>{$rtj1009_lang['ren201']}</span></a>
	</div>
</div>

<div class="content ren-view-main ren-view-b48">
	<div class="rtj1009_m_view rtj1009_m_main m_pb43">
		<div class="ren_view">
            {$block_portal_vievtop}
			<div class="ren_view_wztop">
				<h3 class="ph">$article[title] <!--{if $article['status'] == 1}-->({lang moderate_need})<!--{elseif $article['status'] == 2}-->({lang ignored})<!--{/if}--></h3>
				<div class="ren_twsj_xx">
					<div class="z">
						<a href="{echo getportalcategoryurl($cat[catid])}" class="z ren_twsj_fl"><span>$cat[catname] </span></a>
						<span class="ren_twsj_sj z">$article[dateline]</span>
					</div>
					<div class="y">
						<span class="ren_twsj_ck y"><i class="icon ren-font">&#xe660;</i><!--{if $article[viewnum] > 0}-->$article[viewnum]<!--{else}-->0<!--{/if}--></span>
						<span class="ren_twsj_hf y"><i class="icon ren-font">&#xe694;</i><!--{if $article[commentnum] > 0}-->$article[commentnum]<!--{else}-->0<!--{/if}--></span>
					</div>
				</div>
			</div>
	
	
			<!--{if $article[summary] && empty($cat[notshowarticlesummay])}--><div class="ren_wz_zy"><div class="ren_zyxx"><span>{lang article_description}</span>$article[summary]</div><!--{hook/view_article_summary}--></div><!--{/if}-->
	
	
			<div class="ren_wz_nr">
				<div class="message">
					<!--{if $content[title]}-->
					<div class="vm_pagetitle xw1">$content[title]</div>
					<!--{/if}-->
					$content[content]
				</div>
				<!--{hook/view_article_content}-->
				<!--{if $multi}--><div class="ptw pbw cl">$multi</div><!--{/if}-->
	
	
				<script type="text/javascript" src="{$_G[setting][jspath]}home.js?{VERHASH}"></script>
				<div id="click_div" class="ren_click">
					<!--{template home/space_click}-->
				</div>
	
				<!--{if !empty($contents)}-->
				<div id="inner_nav" class="ptn xs1">
					<h3>{lang article_inner_navigation}</h3>
					<ul class="xl xl2 cl">
						<!--{loop $contents $key $value}-->
						<!--{eval $curpage = $key+1;}-->
						<!--{eval $inner_view_url = helper_page::mpurl($viewurl, '&page=', $curpage);}-->
						<li>&bull; <a href="$inner_view_url"{if $key === $start} class="xi1"{/if}>{lang article_inner_page_pre} {$curpage} {lang article_inner_page} $value[title]</a></li>
						<!--{/loop}-->
					</ul>
				</div>
				<!--{/if}-->
	
	
			</div>
			<!--{if !empty($aimgs[$content[pid]])}-->
				<script type="text/javascript" reload="1">aimgcount[{$content[pid]}] = [<!--{echo implode(',', $aimgs[$content[pid]]);}-->];attachimgshow($content[pid]);</script>
			<!--{/if}-->
	
			<!--{if !empty($_G['setting']['pluginhooks']['view_share_method'])}-->
				<div class="tshare cl">
					<strong>{lang viewthread_share_to}:</strong>
					<!--{hook/view_share_method}-->
				</div>
			<!--{/if}-->
	
			
			<!--{if $article['preaid'] || $article['nextaid']}-->
			<div class="ren_wz_sxyp">
				<!--{if $article['prearticle']}--><a href="{$article['prearticle']['url']}">{lang pre_article}{$article['prearticle']['title']}</a>
				<!--{/if}-->
				<!--{if $article['nextarticle']}--><a href="{$article['nextarticle']['url']}">{lang next_article}{$article['nextarticle']['title']}</a><!--{/if}-->
			</div>
				<!--{/if}-->
            {$block_portal_vievzo}
	
			
	
			<!--{if $article['allowcomment']==1}-->
				<!--{eval $data = &$article}-->
				<!--{subtemplate portal/portal_comment}-->
			<!--{/if}-->
	
			<!--{if $article['related']}-->
			<div id="related_article" class="ren_mtie_xx cl">
				<div class="ren_m_mkbt">
					<span>{lang view_related}</span>
				</div>
				<ul class="ren_wz_xg cl" id="raid_div">
				<!--{loop $article['related'] $raid $rvalue}-->
					<input type="hidden" value="$raid" />
					<li class="ren_mtie"><span></span><a href="{$rvalue[uri]}" class="z ren_twbt">{$rvalue[title]}</a></li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
            {$block_portal_vievfoo}
		</div>
	</div>
</div>

<!--{if $_G['relatedlinks']}-->
	<script type="text/javascript">
		var relatedlink = [];
		<!--{loop $_G['relatedlinks'] $key $link}-->
		relatedlink[$key] = {'sname':'$link[name]', 'surl':'$link[url]'};
		<!--{/loop}-->
		relatedlinks('article_content');
	</script>
<!--{/if}-->

<input type="hidden" id="portalview" value="1">

<div class="ren_view_share ren_view_footer ren-wz-view">
	<a class="ren_viewdi_hf open-popup" data-popup=".popup-view"><span>{$rtj1009_lang['ren053']}</span></a>
	<a href="home.php?mod=spacecp&ac=favorite&type=article&id=$article[aid]&handlekey=favoritearticlehk_{$article[aid]}" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_twsj_sc"><i class="icon ren-font<!--{if $recommend}--> color<!--{/if}-->"><!--{if $recommend}-->&#xe646;<!--{else}-->&#xe603;<!--{/if}--></i></a>
	<a href="javascript:;" class="ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe742;</i></a>
</div>
<script type="text/javascript">
    $('.ren_share').ready(function(){
        var share = new ren_share({
            title : document.title,
            url   : window.location.href,
            desc  : document.getElementsByName('description')[0].content,
            img   : '$ren_wx_imgUrl',
        });
        $('.ren_share').click(function () {
            share.init(0,'.ren_view_share');
        });
    });
</script>
<div id="popup-share" class="popup popup-share">
    <div class="content-block">
        <div class="ren_tiefx_share">
            <div class="bdsharebuttonbox">
                <a href="javascript:;" class="popup_sqq" data-cmd="sqq"><p>{$rtj1009_lang['ren100']}</p></a>
                <a href="javascript:;" class="bds_qzone" data-cmd="qzone"><p>{$rtj1009_lang['ren101']}</p></a>
                <a href="javascript:;" class="bds_tsina" data-cmd="tsina"><p>{$rtj1009_lang['ren102']}</p></a>
                <a href="javascript:;" class="bds_weixin" data-cmd="weixin"><p>{$rtj1009_lang['ren103']}</p></a>
                <a href="javascript:;" class="bds_copy" data-cmd="copy"><p>{$rtj1009_lang['ren212']}</p></a>
            </div>
        </div>
    </div>
    <a href="javascript:;" class="ren_tiefx_qx close-popup">{$rtj1009_lang['ren012']}</a>
</div>



<!--{template common/footer}-->