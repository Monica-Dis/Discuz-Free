<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G['basescript'] == 'forum' && CURMODULE == 'guide'}-->
<!--{eval $navtitle = $rtj1009_lang['ren007'];}-->
<!--{elseif $_G['basescript'] == 'group' && CURMODULE == 'index'}-->
<!--{eval $navtitle = $_G[setting][navs][3][navname];}-->
<!--{/if}-->