<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_g_c u_profile">
	<div class="ren_pbm ren_mbm cl">
        <div class="ren_gxxs_xx">
        	<ul class="ren_gxxsz_xx cl">
                <li class="ren-you-jian">
                	<em class="ren_gxxx_lb">{$rtj1009_lang['home062']}</em>
                    <div class="ren_lb_mbn">
                        <span>{$space[group][grouptitle]}</span>
                        <a href="home.php?mod=spacecp&ac=usergroup" class="ren-pr-xxa">{$rtj1009_lang['home129']}</a>
                    </div>
                </li>
                <li>
                    <em class="ren_gxxx_lb">{$rtj1009_lang['home124']}UID</em>
                    <div class="ren_lb_mbn"><span>{$space[uid]}</span></div>
                </li>
                <li class="ren-you-jian ren-you-verify">
                    <em class="ren_gxxx_lb">{$rtj1009_lang['home134']}</em>
                    <div class="ren_lb_mbn">
                        <!--{if $_G['setting']['verify']['enabled']}-->
                        <a href="home.php?mod=spacecp&ac=profile&op=verify" class="ren-mymedals">
                            <!--{loop $_G['setting']['verify'] $vid $verify}-->
                                <!--{if $verify['available'] && $verify['showicon']}-->
                                    <!--{if $space['verify'.$vid] == 1}-->
                                        <span class="medal"><img src="{$verify[icon]}" alt="$verify[title]" class="vm" /></span>
                                    <!--{/if}-->
                                <!--{/if}-->
                            <!--{/loop}-->
                        </a>
                        <!--{/if}-->
                        <a href="home.php?mod=spacecp&ac=profile&op=verify" class="ren-pr-xxa">{$rtj1009_lang['home133']}</a>
                    </div>
                </li>
                <!--{if $space['medals']}-->
                <li class="ren-you-jian">
                    <em class="ren_gxxx_lb">{$rtj1009_lang['home130']}</em>
                    <div class="ren_lb_mbn">
                        <a href="home.php?mod=medal" class="ren-mymedals">
                            <!--{loop $space['medals'] $medal}-->
                            <span class="medal"><img src="{STATICURL}image/common/$medal[image]" alt="$medal[name]" class="vm" /></span>
                            <!--{/loop}-->
                        </a>
                        <a href="home.php?mod=medal" class="ren-pr-xxa">{$rtj1009_lang['home131']}</a>
                    </div>
                </li>
                <!--{/if}-->
                <li class="ren-you-qian">
                	<em class="ren_gxxx_lb">{$rtj1009_lang['home063']}</em>
                    <div class="ren_lb_mbn"><span><!--{if $space[sightml]}-->$space[sightml]<!--{else}-->{$rtj1009_lang['home040']}<!--{/if}--></span></div>
                </li>
            </ul>
        </div>
    </div>
	<div class="ren_pbm ren_mbm cl">
        <div class="ren_gxxs_xx">
        	<ul class="ren_gxxsz_xx cl">
                <!--{if $space[buyercredit]}-->
                <li><em class="ren_gxxx_lb">{lang eccredit_sellerinfo}</em><div class="ren_lb_mbn"><span>$space[buyercredit]</span></div></li>
                <!--{/if}-->
                <!--{if $space[sellercredit]}-->
                <li><em class="ren_gxxx_lb">{lang eccredit_buyerinfo}</em><div class="ren_lb_mbn"><span>$space[sellercredit]</span></div></li>
                <!--{/if}-->
                <li><em class="ren_gxxx_lb">{lang credits}</em><div class="ren_lb_mbn"><span>$space[credits]</span></div></li>
                <!--{loop $_G[setting][extcredits] $key $value}-->
                <!--{if $value[title]}-->
                <li><em class="ren_gxxx_lb">$value[title]</em><div class="ren_lb_mbn"><span>{$space["extcredits$key"]} $value[unit]</span></div></li>
                <!--{/if}-->
                <!--{/loop}-->
            </ul>
        </div>
    </div>
	<div class="ren_pbm ren_mbm cl">
        <div class="ren_gxxs_xx">
        	<ul class="ren_gxxsz_xx cl">
				<!--{loop $profiles $value}-->
				<li>
					<em class="ren_gxxx_lb">$value[title]</em>
					<div class="ren_lb_mbn"><span>$value[value]</span></div>
				</li>
				<!--{/loop}-->
            </ul>
            <!--{if CURMODULE == 'space'}-->
                <!--{hook/space_profile_baseinfo_top}-->
            <!--{elseif CURMODULE == 'follow'}-->
                <!--{hook/follow_profile_baseinfo_top}-->
            <!--{/if}-->
        </div>
	</div>

    <!--{if $rtj1009_m_config['ren_profile_timel']}-->
    <div class="ren_pbm ren_mbm cl">
        <div class="ren_gxxs_xx">
            <ul class="ren_gxxsz_xx cl">
                <!--{if $space[oltime]}--><li><em class="ren_gxxx_lb">{lang online_time}</em><div class="ren_lb_mbn"><span>$space[oltime] {lang hours}</span></div></li><!--{/if}-->
                <li><em class="ren_gxxx_lb">{lang regdate}</em><div class="ren_lb_mbn"><span>$space[regdate]</span></div></li>
                <li><em class="ren_gxxx_lb">{lang last_visit}</em><div class="ren_lb_mbn"><span>$space[lastvisit]</span></div></li>
            </ul>
        </div>
    </div>
    <!--{/if}-->

  </div>


</div>