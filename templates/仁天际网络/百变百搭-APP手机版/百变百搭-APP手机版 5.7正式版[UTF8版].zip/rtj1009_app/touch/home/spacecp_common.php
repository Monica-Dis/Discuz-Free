<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->


<div class="tip ren-rate-tip ren-gmgroup-tip">
<!--{if $_GET['op'] == 'ignore'}-->
	<form method="post" autocomplete="off" id="ignoreform_{$formid}" name="ignoreform_{$formid}" action="home.php?mod=spacecp&ac=common&op=ignore&type=$type">
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="ignoresubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="referer" value="{echo dreferer()}">
        <div class="ren-rate-nav cl">
            <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
            <div class="ren-post-nav cl">
                <div class="ren-post-wall">
                    <span>{lang shield_notice}</span>
                </div>
            </div>
        </div>
        <div class="list-block ren-stick-block">
            <ul>
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang shield_this_friend}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="authorid" id="authorid1" value="$_GET[authorid]" checked="checked" />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang shield_all_friend}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="authorid" id="authorid0" value="0" />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
		</div>

        <p class="ren_login btn_login">
            <button type="submit" name="feedignoresubmit" value="true" class="formdialog pn button ren_btn">{lang determine}</button>
        </p>
	</form>

<!--{elseif $_GET['op']=='modifyunitprice'}-->

	<form method="post" autocomplete="off" id="ignoreform_{$formid}" name="ignoreform_{$formid}" action="home.php?mod=spacecp&ac=common&op=modifyunitprice" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="modifysubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="referer" value="{echo dreferer()}">
    <div class="ren-rate-nav cl">
        <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
        <div class="ren-post-nav cl">
            <div class="ren-post-wall">
                <span>{lang modify_unitprice}</span>
            </div>
        </div>
    </div>
		<div class="c altw">
			<p>{lang modify_unitprice_note}</p>
			<p class="ptn"><label>{lang bid_single_price}: <input type="text" name="unitprice" class="px" value="$showinfo[unitprice]" /></label></p>
		</div>
		<p class="o pns">
			<button type="submit" name="unitpriceysubmit" value="true" class="pn pnc"><strong>{lang determine}</strong></button>
		</p>
	</form>
	<script type="text/javascript">
		function succeedhandle_$_GET['handlekey'] (url, message, values) {
			var priceObj = $('show_unitprice');
			if(priceObj) {
				priceObj.innerHTML = values['unitprice'];
			}

		}
	</script>
<!--{/if}-->
</div>

<!--{template common/footer}-->