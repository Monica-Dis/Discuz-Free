<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="tip ren-rate-tip ren-magic-tip">
    <form id="magicform" method="post" action="home.php?mod=magic&action=mybox&infloat=yes">

        <div class="ren-rate-nav cl">
            <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
            <div class="ren-post-nav cl">
                <div class="ren-post-wall">
                <span>
                    <!--{if $operation == 'give'}-->
                    {lang magics_operation_present}{lang magic}
                    <!--{elseif $operation == 'drop'}-->
                    {lang magics_operation_drop}{lang magic}
                    <!--{elseif $operation == 'sell'}-->
                    {lang magics_operation_sell}{lang magic}
                    <!--{elseif $operation == 'use'}-->
                    {lang magics_operation_use}{lang magic}
                    <!--{/if}-->
                </span>
                </div>
            </div>
            <a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren-rate-author">
                <img src="$magic[pic]" alt="" />
                <p>$magic[name]</p>
            </a>
            <p>$magic[description]</p>
        </div>

        <div class="list-block ren-stick-block">
            <ul class="c" id="hkey_$_GET[handlekey]">
                <div id="return_$_GET[handlekey]"></div>
                <input type="hidden" name="formhash" value="{FORMHASH}" />
                <input type="hidden" name="handlekey" value="$_GET[handlekey]" />
                <input type="hidden" name="operation" value="$operation" />
                <input type="hidden" name="magicid" value="$magicid" />
                <!--{if $operation == 'give'}-->
                <!--{if $_G['group']['allowmagics'] > 1 }-->
                    <li>
                        <div class="item-content">
                            <div class="item-media">{lang magics_target_present}</div>
                            <div class="item-inner">
                                <div class="item-input">
                                    <input type="text" id="selectedusername" name="tousername" size="12" autocomplete="off" value="" class="px p_fre" />
                                </div>
                            </div>
                        </div>
                    </li>
                <!--{/if}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang magics_num}</div>
                        <div class="item-inner">
                            <div class="item-input">
                                <input name="magicnum" type="text" size="12" autocomplete="off" value="1" class="px p_fre" />
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang magics_present_message}</div>
                        <div class="item-inner">
                            <div class="item-input">
                                <textarea name="givemessage" rows="3" class="pt">{lang magics_present_message_text}</textarea>
                            </div>
                        </div>
                    </div>
                </li>
                <input type="hidden" name="operatesubmit" value="yes" />
                <!--{elseif $operation == 'use'}-->
                <!--{if method_exists($magicclass, 'show')}-->
                <li class="ren-magic-tsli">
                    <!--{eval $magicclass->show();}-->
                </li>
                <!--{/if}-->
                <!--{if $useperoid !== true}-->
                <li class="ren-usgroup-tsli">
                    <p>
                        <!--{if $magic['useperoid'] == 1}-->{lang magics_outofperoid_1}<!--{elseif $magic['useperoid'] == 2}-->{lang magics_outofperoid_2}<!--{elseif $magic['useperoid'] == 3}-->{lang magics_outofperoid_3}<!--{elseif $magic['useperoid'] == 4}-->{lang magics_outofperoid_4}<!--{/if}--><!--{if $useperoid > 0}-->{lang magics_outofperoid_value}<!--{else}-->{lang magics_outofperoid_noperm}<!--{/if}-->
                    </p>
                </li>
                <!--{/if}-->
                <input type="hidden" name="usesubmit" value="yes" />
                <input type="hidden" name="operation" value="use" />
                <input type="hidden" name="magicid" value="$magicid" />
                <!--{if !empty($_GET['idtype']) && !empty($_GET['id'])}-->
                <input type="hidden" name="idtype" value="$_GET[idtype]" />
                <input type="hidden" name="id" value="$_GET[id]" />
                <!--{/if}-->
                <!--{elseif $operation == 'sell'}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang magics_operation_sell}</div>
                        <div class="item-inner">
                            <div class="item-input">
                                <input name="magicnum" type="text" size="2" value="1" class="px pxs" />
                            </div>
                        </div>
                        <div class="item-media">{lang magics_unit}</div>
                    </div>
                </li>
                <li class="ren-usgroup-gmli">
                    <div class="item-content">
                        <div class="item-media">{lang recycling_prices}</div>
                        <div class="item-inner">
                            <div class="item-input color">
                                <!--{if {$_G['setting']['extcredits'][$magic[credit]][unit]}}-->
                                {$_G['setting']['extcredits'][$magic[credit]][title]} $discountprice {$_G['setting']['extcredits'][$magic[credit]][unit]}/{lang magics_unit}
                                <!--{else}-->
                                $discountprice {$_G['setting']['extcredits'][$magic[credit]][title]}/{lang magics_unit}
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </li>
                <input type="hidden" name="operatesubmit" value="yes" />
                <!--{elseif $operation == 'drop'}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang magics_operation_drop}</div>
                        <div class="item-inner">
                            <div class="item-input">
                                <input name="magicnum" type="text" size="2" autocomplete="off" value="1" class="px pxs" />
                            </div>
                        </div>
                        <div class="item-media">{lang magics_unit}</div>
                    </div>
                </li>
                <li class="ren-usgroup-gmli">
                    <div class="item-content">
                        <div class="item-media">{lang magics_weight}</div>
                        <div class="item-inner">
                            <div class="item-input color">
                                $magic[weight]
                            </div>
                        </div>
                    </div>
                </li>
                <input type="hidden" name="operatesubmit" value="yes" />
                <!--{/if}-->
            </ul>
        </div>

        <div class="ren_login btn_login" id="hbtn_$_GET[handlekey]">
            <!--{if $operation == 'give'}-->
            <button class="formdialog pn button ren_btn" type="submit" name="operatesubmit" id="operatesubmit" value="true">{lang magics_operation_present}</button>
            <!--{elseif $operation == 'use'}-->
            <button class="formdialog pn button ren_btn" type="submit" name="usesubmit" id="usesubmit" value="true">{lang magics_operation_use}</button>
            <!--{elseif $operation == 'sell'}-->
            <button class="formdialog pn button ren_btn" type="submit" name="operatesubmit" id="operatesubmit" value="true">{lang magics_operation_sell}</button>
            <!--{elseif $operation == 'drop'}-->
            <button class="formdialog pn button ren_btn" type="submit" name="operatesubmit" id="operatesubmit" value="true">{lang magics_operation_drop}</button>
            <!--{/if}-->
        </div>
    </form>
</div>
<script type="text/javascript" reload="1">
    function confirmMagicOp(e) {
        e = e ? e : window.event;
        showDialog('{lang magics_confirm}', 'confirm', '', 'ajaxpost(\'magicform\', \'return_magics\', \'return_magics\', \'onerror\');');
        doane(e);
        return false;
    }
    function succeedhandle_$_GET[handlekey](url, msg) {
        hideWindow('$_GET[handlekey]');
        if(arguments[2] && arguments[2]['avatar']) {
            msg += ' <ul class="ml mls cl"><li><a class="avt" target="_blank" href="home.php?mod=space&amp;uid='+arguments[2]['uid']+'"><em class=""></em><img src="{$_G[setting][ucenterurl]}/avatar.php?uid='+arguments[2]['uid']+'&size=small" /></a><p><a title="admin" href="home.php?mod=space&amp;uid='+arguments[2]['uid']+'" target="_blank"><b>'+arguments[2]['username']+'</b></a></p></li></ul>';
        }
        <!--{if !$location}-->
        showDialog(msg, 'notice', null, function () { location.href=url; }, 0);
        <!--{else}-->
        showWindow('$_GET[handlekey]', 'home.php?$querystring');
        <!--{/if}-->
        showCreditPrompt();
    }
</script>
<!--{template common/footer}-->