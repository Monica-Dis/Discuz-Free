<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="tip ren-rate-tip ren-medal-tip">
	<form id="medalform" method="post" autocomplete="off" action="home.php?mod=medal&action=apply&medalsubmit=yes">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="medalid" value="$medal[medalid]" />
		<input type="hidden" name="operation" value="" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->

		<div class="ren-rate-nav">
			<a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
			<a href="javascript:;" class="ren-rate-author">
				<img src="{STATICURL}image/common/$medal[image]" class="vm" alt="$medal[name]" />
				<p>$medal[name]</p>
			</a>
			<p>$medal[description]</p>
		</div>
		<div class="list-block">
			<p class="ren-medal-tipts">
				<!--{if $medal[expiration]}-->
					{lang expire} $medal[expiration] {lang days}<br />
				<!--{/if}-->
				<!--{if $medal[permission]}-->
					$medal[permission]<br />
				<!--{/if}-->
				<!--{if $medal[type] == 0}-->
					{lang medals_type_0}
				<!--{elseif $medal[type] == 1}-->
					<!--{if $medal['price']}-->
						<!--{if {$_G['setting']['extcredits'][$medal[credit]][unit]}}-->
							{$_G['setting']['extcredits'][$medal[credit]][title]} <strong class="xi1 xw1 xs2">$medal[price]</strong> {$_G['setting']['extcredits'][$medal[credit]][unit]}
						<!--{else}-->
							<strong class="xi1 xw1 xs2">$medal[price]</strong> {$_G['setting']['extcredits'][$medal[credit]][title]}
						<!--{/if}-->
					<!--{else}-->
						{lang medals_type_1}
					<!--{/if}-->
				<!--{elseif $medal[type] == 2}-->
					{lang medals_type_2}
				<!--{/if}-->
			</p>
		</div>
		<div class="ren_login btn_login">
			<!--{if $medal[type] && $_G['uid']}-->
			<button name="medalsubmit" type="submit" value="true" class="formdialog pn button ren_btn"><span>
					<span>
					<!--{if $medal['price']}-->
						{lang space_medal_buy}
					<!--{else}-->
						<!--{if !$medal[permission]}-->
							{lang medals_apply}
						<!--{else}-->
							{lang medals_draw}
						<!--{/if}-->
					<!--{/if}-->
					</span>
				</button>
			<!--{/if}-->
		</div>
	</form>
</div>
<!--{template common/footer}-->