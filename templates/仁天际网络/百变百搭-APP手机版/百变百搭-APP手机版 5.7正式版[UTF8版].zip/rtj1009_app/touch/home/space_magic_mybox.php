<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G['group']['magicsdiscount'] || $_G['group']['maxmagicsweight']}-->
	<!--{if $_G['group']['maxmagicsweight']}-->
		<p class="tbms ren-tbms-r tbms_r" style="text-align: center;">{lang magics_capacity} $totalweight/{$_G['group']['maxmagicsweight']}</p>
	<!--{/if}-->
<!--{/if}-->
<!--{if $mymagiclist}-->
<ul class="ren-notice-re ren-magic-ul cl">
<!--{loop $mymagiclist $key $mymagic}-->
    <li>
        <div id="magic_$mymagic[identifier]" class="ren-notice-avt">
            <img src="$mymagic[pic]" alt="$mymagic[name]" />
        </div>
        <div class="ren-task-us">
            <div class="z ren-task-name"><span>$mymagic[name]</span></div>
            <span class="z ren-task-reward">
                <!--{if $task['reward'] == 'credit'}-->
                    {lang credits} $_G['setting']['extcredits'][$task[prize]][title] $task[bonus] $_G['setting']['extcredits'][$task[prize]][unit]
                <!--{elseif $task['reward'] == 'magic'}-->
                    {lang magics_title} $listdata[$task[prize]] $task[bonus] {lang magics_unit}
                <!--{elseif $task['reward'] == 'medal'}-->
                    {lang medals} $listdata[$task[prize]] <!--{if $task['bonus']}-->{lang expire} $task[bonus] {lang days} <!--{/if}-->
                <!--{elseif $task['reward'] == 'invite'}-->
                    {lang invite_code} $task[prize] {lang expire} $task[bonus] {lang days}
                <!--{elseif $task['reward'] == 'group'}-->
                    {lang usergroup} $listdata[$task[prize]] <!--{if $task['bonus']}--> $task[bonus] {lang days} <!--{/if}-->
                <!--{/if}-->
            </span>
        </div>
        <p class="ren-magic_magnum">
            <span class="info_label">{lang magics_num}</span>
            <span class="info_value">$mymagic[num]</span>
            <span class="info_label">{lang magics_user_totalnum}</span>
            <span class="info_value">$mymagic[weight]</span>
        </p>
        <div class="y ren-friend-in">
            <!--{if $mymagic['useevent']}-->
                <a href="home.php?mod=magic&action=mybox&operation=use&magicid=$mymagic[magicid]" class="z dialog">{lang magics_operation_use}</a>
            <!--{/if}-->
            <!--{if $_G['group']['allowmagics'] > 1}-->
                <a href="home.php?mod=magic&action=mybox&operation=give&magicid=$mymagic[magicid]" class="z sl dialog">{lang magics_operation_present}</a>
            <!--{/if}-->
            <!--{if $_G['setting']['magicdiscount']}-->
                <a href="home.php?mod=magic&action=mybox&operation=sell&magicid=$mymagic[magicid]" class="z tu dialog">{lang magics_operation_sell}</a>
            <!--{else}-->
                <a href="home.php?mod=magic&action=mybox&operation=drop&magicid=$mymagic[magicid]" class="z tu dialog">{lang magics_operation_drop}</a>
            <!--{/if}-->
        </div>
        <p class="ren-task-js">$mymagic[description]</p>
    </li>
<!--{/loop}-->
</ul>
	<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
<!--{else}-->
<div class="ren_ss_wu">
    <i class="icon ren-font">&#xe608;</i>
    <span>{lang data_nonexistence}</span>
</div>
<!--{/if}-->
