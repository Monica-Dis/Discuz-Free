<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>

<ul class="ren-notice-re cl">
	<!--{if $tasklist}-->
			<!--{loop $tasklist $task}-->
				<li>
					<div class="ren-notice-avt"><img src="$task[icon]" alt="$task[name]" /></div>
					<div class="ren-task-us">
						<div class="z ren-task-name"><a href="home.php?mod=task&do=view&id=$task[taskid]">$task[name]</a></div>
						<span class="z ren-task-reward">
							<!--{if $task['reward'] == 'credit'}-->
								{lang credits} $_G['setting']['extcredits'][$task[prize]][title] $task[bonus] $_G['setting']['extcredits'][$task[prize]][unit]
							<!--{elseif $task['reward'] == 'magic'}-->
								{lang magics_title} $listdata[$task[prize]] $task[bonus] {lang magics_unit}
							<!--{elseif $task['reward'] == 'medal'}-->
								{lang medals} $listdata[$task[prize]] <!--{if $task['bonus']}-->{lang expire} $task[bonus] {lang days} <!--{/if}-->
							<!--{elseif $task['reward'] == 'invite'}-->
								{lang invite_code} $task[prize] {lang expire} $task[bonus] {lang days}
							<!--{elseif $task['reward'] == 'group'}-->
								{lang usergroup} $listdata[$task[prize]] <!--{if $task['bonus']}--> $task[bonus] {lang days} <!--{/if}-->
							<!--{/if}-->
						</span>
					</div>
					<div class="ren-task-btn">
						<!--{if $_GET['item'] == 'new'}-->
							<!--{if $task['noperm']}-->
								<a href="javascript:;" onclick="doane(event);showDialog('{lang task_group_nopermission}')">{$rtj1009_lang['home117']}</a>
							<!--{elseif $task['appliesfull']}-->
								<a href="javascript:;" onclick="doane(event);showDialog('{lang task_applies_full}')">{$rtj1009_lang['home117']}</a>
							<!--{else}-->
								<a href="home.php?mod=task&do=apply&id=$task[taskid]">{$rtj1009_lang['home117']}</a>
							<!--{/if}-->
						<!--{elseif $_GET['item'] == 'doing'}-->
							<a href="home.php?mod=task&do=draw&id=$task[taskid]">{$rtj1009_lang['home115']}</a>
						<!--{elseif $_GET['item'] == 'done'}-->
							{lang task_complete_on} $task[dateline]
							<!--{if $task['period'] && $task[t]}--><br /><!--{if $task[allowapply]}--><a href="home.php?mod=task&do=apply&id=$task[taskid]">{lang task_applyagain_now}</a><!--{else}-->{$task[t]}{lang task_applyagain}<!--{/if}--><!--{/if}-->
						<!--{elseif $_GET['item'] == 'failed'}-->
							{lang task_lose_on} $task[dateline]
							<!--{if $task['period'] && $task[t]}--><br /><!--{if $task[allowapply]}--><a href="home.php?mod=task&do=apply&id=$task[taskid]">{lang task_applyagain_now}</a><!--{else}-->{$task[t]}{lang task_reapply}<!--{/if}--><!--{/if}-->
						<!--{/if}-->
					</div>
					<p class="ren-task-js">$task[description]</p>
					
					<!--{if $_GET['item'] == 'doing'}-->
					<div class="ren-task-listjd">
					<div class="ren-task-jd">
						<div class="ren-task-pdr" style="width: {if $task[csc]}$task[csc]%{else}8px{/if};"></div>
						<div class="ren-task-csc">{lang task_complete} <span id="csc_$task[taskid]">$task[csc]</span>%</div>
					</div>
					</div>
					<!--{/if}-->
				</li>
			<!--{/loop}-->
	<!--{else}-->
		<div class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<span><!--{if $_GET['item'] == 'new'}-->{lang task_nonew}<!--{elseif $_GET['item'] == 'doing'}-->{lang task_nodoing}<!--{else}-->{lang data_nonexistence}<!--{/if}--></span>
		</div>
	<!--{/if}-->
</ul>