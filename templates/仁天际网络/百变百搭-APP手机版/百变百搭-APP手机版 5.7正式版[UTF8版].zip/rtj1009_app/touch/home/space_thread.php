<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header<!--{if $rtj1009_m_config['ren_menu_nav'] ==2}--> ren-menu-header<!--{/if}-->">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{$rtj1009_lang['home064']}</span>
		</div>
        <div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content<!--{if $rtj1009_m_config['ren_menu_nav'] ==2}--> p-t-0<!--{/if}--> p-b-0">
<!-- userinfo start -->
    <!--{template home/space_menu}-->
<!-- userinfo end -->
<!-- main threadlist start -->
<div class="ren_tie_list rtj1009_lai_ct cl">
    <ul class="ren_list ren_kjtie_list cl">
	<!--{if $list}-->
        <!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/rtj1009_list.php';}-->
    <!--{template rtj1009_core/space_thread_list}-->
	<!--{else}-->
		<div class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{lang no_album}</span>
		</div>
	<!--{/if}-->
	</ul>
	$multi
</div>
</div>
<!-- main threadlist end -->
<!--{eval $nofooter = true;}-->


<!--{template common/footer}-->
