<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{$rtj1009_lang['home111']}</span>
		</div>
        <div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content p-b-0">
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
			<a href="home.php?mod=task&item=new"$actives[new]>{lang task_new}</a>
			<a href="home.php?mod=task&item=doing"$actives[doing]>{$rtj1009_lang['home112']}</a>
			<a href="home.php?mod=task&item=done"$actives[done]>{$rtj1009_lang['home113']}</a>
			<a href="home.php?mod=task&item=failed"$actives[failed]>{$rtj1009_lang['home114']}</a>
		</div>
	</div>
	<div class="ren-friend-list ren-notice-list cl">
			<!--{if empty($do)}-->
				<!--{subtemplate home/space_task_list}-->
			<!--{elseif $do == 'view'}-->
				<!--{subtemplate home/space_task_detail}-->
			<!--{/if}-->
	</div>
</div>
<!--{template common/footer}-->