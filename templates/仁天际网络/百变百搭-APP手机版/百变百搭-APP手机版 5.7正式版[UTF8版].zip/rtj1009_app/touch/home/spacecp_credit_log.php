<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{$rtj1009_lang['home107']}</span>
		</div>
        <div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content p-b-0">
<!--{subtemplate home/spacecp_credit_header}-->
	<!--{if $_GET[suboperation] != 'creditrulelog'}-->
		<ul class="ren-notice-re ren-credit-log cl">
			<!--{loop $loglist $value}-->
			<!--{eval $value = makecreditlog($value, $otherinfo);}-->
			<li>
				<div class="ren-notice-avt">
					<div class="ren-notice-wuavt ">$value['credit']</div>
				</div>
				<div class="ren-notice-note">
					<!--{if $value['operation']}--><a href="home.php?mod=spacecp&ac=credit&op=log&optype=$value['operation']" class="z">$value['optype']</a><!--{else}-->$value['title']<!--{/if}-->
					<span class="y ren-notice-date">$value['dateline']</span>
				</div>
				<div class="ren-credit-op">
					<!--{if $value['operation']}-->$value['opinfo']<!--{else}-->$value['text']<!--{/if}-->
				</div>
			</li>
			<!--{/loop}-->
		</ul>
	<!--{/if}-->
	<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
</div>

<!--{template common/footer}-->