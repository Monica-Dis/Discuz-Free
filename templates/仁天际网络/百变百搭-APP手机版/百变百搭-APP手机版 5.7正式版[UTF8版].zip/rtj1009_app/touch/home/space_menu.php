<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $space[uid]}-->
<div id="rtj1009_mn_u" class="rtj1009_menu">
    <div class="rtj1009_menu_nv">
        <!--{eval space_merge($space, 'field_home'); $space[domainurl] = space_domain($space);getuserdiydata($space);$personalnv = isset($_G['blockposition']['nv']) ? $_G['blockposition']['nv'] : '';}-->
        <div class="z ren-menu cl">
            <div class="ren-menu-avatar"><!--{avatar($space[uid], big)}--></div>
        </div>
		
        <!--{eval $konguid = $space[uid];}-->
        <!--{eval $guangbo = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid=$konguid");}-->
         <div class="ren-menu-item">
			 <div class="ren-menu-name">
				 <span>{$space[username]}</span>
			 </div>
			<!--{if helper_access::check_module('follow')}-->
			<div class="ren-menu-follow">
				<span class="info_label">{$rtj1009_lang['home009']}</span><span class="info_value">$guangbo['following']</span>
				<span class="ren-menu-shu">|</span>
				<span class="info_label">{$rtj1009_lang['home008']}</span><span class="info_value">$guangbo['follower']</span>
			</div>
			<!--{/if}-->
			<!--{eval $menu = DB::fetch_first("SELECT * FROM ".DB::table('common_member_field_forum')." WHERE uid=$space[uid]");}-->
			<div class="ren-menu-sig"><span><!--{if $menu[sightml]}-->$menu[sightml]<!--{else}-->{$rtj1009_lang['home040']}<!--{/if}--></span></div>
         </div>
    </div>
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
			<a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space"{if $do=='thread'} class="a"{/if}>{$rtj1009_lang['home041']}</a>
            <!--{if helper_access::check_module('album')}-->
			<a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space"{if $do=='album'} class="a"{/if}>{lang album}</a>
            <!--{/if}-->
            <!--{if helper_access::check_module('blog')}-->
			<a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space"{if $do=='blog'} class="a"{/if}>{lang blog}</a>
            <!--{/if}-->
            <!--{if helper_access::check_module('wall')}-->
			<a href="home.php?mod=space&uid=$space[uid]&do=wall&from=space"{if $do=='wall'} class="a"{/if}>{$rtj1009_lang['home042']}</a>
            <!--{/if}-->
			<a href="home.php?mod=space&uid=$space[uid]&do=profile"{if $do=='profile'} class="a"{/if}>{$rtj1009_lang['home043']}</a>
		</div>
	</div>
<!--{if !$space[self]}-->
	<div class="ren_view_foo">
		  <!--{if !ckfollow($space['uid'])}-->
		  <a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-menu-gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"><i class="icon ren-font">&#xe7b9;</i>{$rtj1009_lang['home093']}</a>
	 	 <!--{else}-->
		  <a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-menu-gz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]"><i class="icon ren-font">&#xe7b9;</i>{$rtj1009_lang['home094']}</a>
	  	<!--{/if}-->
		<a href="home.php?mod=space&do=pm&subop=view&touid=$space[uid]" class="ren-menu-pm"><i class="icon ren-font">&#xe61b;</i>{lang send_pm}</a>
        <!--{if !$isfriend}-->
        <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=addfriendhk_$space[uid]" class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-menu-hy"><i class="icon ren-font">&#xe676;</i>{$rtj1009_lang['home095']}</a>
        <!--{else}-->
        <a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$space[uid]&handlekey=ignorefriendhk_{$space[uid]}" class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-menu-hy"><i class="icon ren-font">&#xe676;</i>{$rtj1009_lang['home125']}</a>
        <!--{/if}-->
	</div>
<!--{/if}-->
</div>
<!--{/if}-->

<!--{if $rtj1009_m_config['ren_menu_nav'] ==2}-->
<script type="text/javascript">  
$(function(){  
	var nav=$(".rtj1009_header");
	var win=$(window);
	var sc=$(document);
	win.scroll(function(){  
	  if(sc.scrollTop()>=110){  
		nav.removeClass("ren-menu-header");   
	   $(".navTmp").fadeIn();   
	  }else{  
	   nav.addClass("ren-menu-header");  
	   $(".navTmp").fadeOut();  
	  }  
	})    
})  
</script> 
<!--{/if}-->