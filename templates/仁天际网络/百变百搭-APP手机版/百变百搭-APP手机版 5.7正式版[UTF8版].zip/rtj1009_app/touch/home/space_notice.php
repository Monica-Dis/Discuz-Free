<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['home_tpl_titles'] = array('{lang remind}');}-->
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl"> <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z"> <span class="ren_bk_name">{$rtj1009_lang['home106']}</span> </div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn"> <span><span class="ren_nav_icon"><span></span></span></span> </div>
		</div>
	</div>
</header>
<!--{/if}-->
<!--{if !$_GET['view']}-->
<div class="content">
    <div class="ren-notice-rk cl">
        <div class="ren-notice-rkli cl">
            <a class="ren-notice-rka xx" href="home.php?mod=space&do=pm"><i class="icon ren-font">&#xe61b;</i>{$rtj1009_lang['home047']}<!--{if $_G[member][newpm]}--><span class="dian"></span><!--{/if}--></a>
            <!--{loop $_G['notice_structure'] $key $type}-->
            <a class="ren-notice-rka $key" href="home.php?mod=space&do=notice&view=$key"><i class="icon ren-font"><!--{if $key == 'mypost'}-->&#xe62c;<!--{elseif $key == 'interactive'}-->&#xe6cf;<!--{elseif $key == 'system'}-->&#xe6a5;<!--{elseif $key == 'manage'}-->&#xe666;<!--{elseif $key == 'app'}-->&#xe743;<!--{/if}--></i><!--{eval echo lang('template', 'notice_'.$key)}--><!--{if $_G['member']['category_num'][$key]}--><span class="shu">$_G['member']['category_num'][$key]</span><!--{/if}--></a>
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{else}-->
<div class="content p-b-0">
    <!--{if $_G['notice_structure'][$view] && ($view == 'mypost' || $view == 'interactive')}-->
	<div class="rtj1009-nav-swiper">
		<div class="swiper-container2 ren_m_lx">
			<ul class="swiper-wrapper">
                <!--{loop $_G['notice_structure'][$view] $subtype}-->
				<li class="swiper-slide{if $readtag[$subtype]} a{/if}"><a href="home.php?mod=space&do=notice&view=$view&type=$subtype"><!--{eval echo lang('template', 'notice_'.$view.'_'.$subtype)}--><!--{if $_G['member']['newprompt_num'][$subtype]}--><span class="ren-friend-su">$_G['member']['newprompt_num'][$subtype]</span><!--{/if}--></a></li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
    <!--{/if}-->
	
	<div class="ren-friend-list ren-notice-list cl">
		
		<!--{if empty($list)}-->
		<div class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{lang no_notice}</span>
		</div>
		<!--{/if}-->
		<!--{if $list}-->
		<ul class="ren-notice-re cl">
			<!--{loop $list $key $value}-->
			<li $value[rowid] notice="$value[id]">
				<div class="ren-notice-avt">
					<!--{if $value[authorid]}-->
					<a href="home.php?mod=space&uid=$value[authorid]&do=profile"><!--{avatar($value[authorid],middle)}--></a>
					<!--{else}-->
					<div class="ren-notice-wuavt "><i class="icon ren-font">&#xe6a5;</i></div>
					<!--{/if}-->
				</div>
				<div class="ren-notice-note">
					<a href="home.php?mod=spacecp&ac=common&op=ignore&authorid=$value[authorid]&type=$value[type]&handlekey=addfriendhk_{$value[authorid]}" id="a_note_$value[id]" class="y dialog" ><i class="icon ren-font">&#xe78e;</i></a>
					<span class="z ren-notice-date"><!--{date($value[dateline], 'u')}--></span>
				</div>
				<div class="ntc_body ren-ntc-note" style="$value[style]">
                    $value[note]
				</div>

				<!--{if $value[from_num]}-->
				<div class="xg1 xw0">{lang ignore_same_notice_message}</div>
				<!--{/if}-->
			</li>
			<!--{/loop}-->
		</ul>
		<!--{/if}-->

	
        
	</div>
	<!--{if $multi}--><div class="pgs cl">$multi</div><!--{/if}-->
</div>
<!--{/if}-->

<!--{template common/footer}-->