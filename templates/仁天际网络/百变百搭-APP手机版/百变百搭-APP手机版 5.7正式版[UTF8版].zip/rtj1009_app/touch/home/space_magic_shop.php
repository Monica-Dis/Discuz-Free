<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<ul class="ren-notice-xnav">
	<li $subactives[index]><a href="home.php?mod=magic&action=shop">{lang default}</a></li>
	<li $subactives[hot]><a href="home.php?mod=magic&action=shop&operation=hot">{lang top}</a></li>
</ul>
<div class="ren-credit-z ren-magic-ts" style="margin-top: 7px; position: relative;">
	<!--{if $magiccredits}-->
        <!--{if $_G['group']['magicsdiscount']}-->{lang magics_discount}<!--{/if}-->
        <!--{eval $i = 0;}-->
        <!--{loop $magiccredits $id}-->
            <!--{if $i != 0}--> <!--{/if}-->
            <div class="ren-credit-zxx"><h3>{$_G['setting']['extcredits'][$id][title]}</h3><p><!--{echo getuserprofile('extcredits'.$id);}--> {$_G['setting']['extcredits'][$id][unit]}</p></div>
            <!--{eval $i++;}-->
        <!--{/loop}-->
    <div class="y ren-friend-in">
        <!--{if ($_G['setting']['ec_ratio'] && ($_G['setting']['ec_tenpay_opentrans_chnid'] || $_G['setting'][ec_tenpay_bargainor] || $_G['setting']['ec_account'])) || $_G['setting']['card']['open']}-->
            <a href="home.php?mod=spacecp&ac=credit&op=buy" class="z">{lang buy_credits}</a>
        <!--{/if}-->
        <!--{if $_G[setting][exchangestatus]}-->
            <a href="home.php?mod=spacecp&ac=credit&op=exchange" class="z sl">{lang credit_exchange}</a>
        <!--{/if}-->
    </div>
	<!--{/if}-->
    <!--{if $_G['group']['maxmagicsweight']}-->
    <span class="ren-credit-zsm">{lang magics_capacity} $totalweight/{$_G['group']['maxmagicsweight']}</span>
    <!--{/if}-->
</div>
<!--{if $magiclist}-->
<ul class="ren-notice-re ren-magic-ul cl">
	<!--{loop $magiclist $key $magic}-->
		<li>
            <div id="magic_$magic[identifier]" class="ren-notice-avt">
                <img src="$magic[pic]" alt="$magic[name]" />
            </div>
            <div class="ren-task-us">
                <div class="z ren-task-name"><span>$magic[name]</span></div>
                <span class="z ren-task-reward">
                    <!--{if {$_G['setting']['extcredits'][$magic[credit]][unit]}}-->
                        {$_G['setting']['extcredits'][$magic[credit]][title]} $magic[price] {$_G['setting']['extcredits'][$magic[credit]][unit]}/{lang magics_unit}
                        <!--{else}-->
                        $magic[price] {$_G['setting']['extcredits'][$magic[credit]][title]}/{lang magics_unit}
                        <!--{/if}-->
                        <!--{if $operation == 'hot'}-->({lang sold} $magic[salevolume] {lang magics_unit})<!--{/if}-->
                </span>
            </div>

            <div class="y ren-friend-in">
                <!--{if $magic['num'] > 0}-->
                <a href="home.php?mod=magic&action=shop&operation=buy&mid=$magic[identifier]" class="z dialog">{lang magics_operation_buy}</a>
                <!--{if $_G['group']['allowmagics'] > 1}-->
                <a href="home.php?mod=magic&action=shop&operation=give&mid=$magic[identifier]" class="z tu dialog">{lang magics_operation_present}</a>
                <!--{/if}-->
                <!--{else}-->
                <span class="xg1">{lang magic_empty}</span>
                <!--{/if}-->
            </div>
            <p class="ren-task-js">$magic[description]</p>
		</li>
	<!--{/loop}-->
	</ul>
	<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
<!--{else}-->
<div class="ren_ss_wu">
    <i class="icon ren-font">&#xe608;</i>
    <span>{lang data_nonexistence}</span>
</div>
<!--{/if}-->