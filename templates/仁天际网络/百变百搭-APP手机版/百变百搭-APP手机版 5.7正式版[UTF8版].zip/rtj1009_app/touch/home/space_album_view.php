<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['home_tpl_titles'] = array($album['albumname'], '{lang album}');}-->
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header<!--{if $diymode && $rtj1009_m_config['ren_menu_nav'] ==2}--> ren-menu-header<!--{/if}-->">
	<div class="ren_nav cl">
		<a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z"><span class="ren_bk_name"><!--{if $diymode}-->{$rtj1009_lang['home013']}<!--{else}-->{$rtj1009_lang['home023']}<!--{/if}--></span></div>
        <div class="y ren_list_nav">
            <a href="home.php?mod=spacecp&ac=upload" class="ren_nav_ss"><span class="icon ren-font">&#xe645;</span></a>
        </div>
	</div>
</header>
<!-- header end --> 
<!--{/if}-->
<div class="content<!--{if $diymode && $rtj1009_m_config['ren_menu_nav'] ==2}--> p-t-0<!--{/if}--> p-b-0">
<!--{if $diymode}-->
	<!--{template home/space_menu}-->
<!--{/if}-->
		<!--{if !$diymode}-->
		<div class="ren-album-nvxx cl">
			<div class="ren-album-name">
				<div class="albumname z">$album['albumname']</div>
				<span><!--{if $album[picnum]}-->{lang total} $album[picnum] {lang album_pics}<!--{/if}--></span>
                <!--{if ($_G[uid] == $album[uid] || checkperm('managealbum')) && $album[albumid] > 0}-->
                <a href="home.php?mod=spacecp&ac=album&op=delete&albumid=$album[albumid]&uid=$album[uid]&handlekey=delalbumhk_{$album[albumid]}" id="album_delete_$album[albumid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}--> ren-album-fav tu y"><i class="icon ren-font">&#xe684;</i></a>
                <!--{/if}-->
			<!--{if $album[albumid]>0}-->
				<a href="home.php?mod=spacecp&ac=favorite&type=album&id=$album[albumid]&spaceuid=$space[uid]&handlekey=sharealbumhk_{$album[albumid]}" id="a_favorite" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}--> ren-album-fav y"><i class="icon ren-font">&#xe603;</i></a>
			<!--{/if}-->
			</div>
			<div class="ren-album-depict">$album['depict']</div>
		</div>
		<!--{/if}-->
		<div id="ren_pbl_list" class="ren-album-list ren-album-view">
		<!--{if $count}-->
			<ul id="waterfall" class="waterfall cl">
				<!--{loop $list $key $value}-->
				<li>
					<div class="ren-album-pic c">
						<a href="home.php?mod=space&uid=$value[uid]&do=$do&picid=$value[picid]"><!--{if $value[pic]}--><img src="$value[pic]" alt="" /><!--{/if}--></a><!--{if $value[status] == 1}--><p>({lang moderate_need})</p><!--{/if}-->
					</div>
				</li>
				<!--{/loop}-->
			</ul>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
		<!--{else}-->
			<div class="ren_ss_wu">
				<i class="icon ren-font">&#xe608;</i>
				<span>{lang no_album}</span>
			</div>
		<!--{/if}-->
		</div>
	<script type="text/javascript" src="template/rtj1009_app/js/redef.js?{VERHASH}"></script>
	<script type="text/javascript" reload="1">
          var wf = {};

          _attachEvent(window, "load", function () {
              if(jq("waterfall")) {
                  wf = waterfall();
              }
          });

    </script>
</div>

<!--{template common/footer}-->