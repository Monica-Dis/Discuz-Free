<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<script type="text/javascript">
        window.location.href = 'home.php?mod=space&do=profile&mycenter=1';
</script>
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->
