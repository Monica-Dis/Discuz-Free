<?PHP exit('DisM!应用中心 https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_grkj z">
            <span class="ren_bk_name ren_vm">{$rtj1009_lang['home001']}</span>
        </div>
        <div class="ren_nav_right open-panel">
            <div class="ren_btn">
                <span><span class="ren_nav_icon"><span></span></span></span>
            </div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content ren-post-blog">
    <div class="rtj1009_post rtj1009_m_main cl">
        <div class="rtj1009_p_nav">
            <div class="ren_p_nav">
                <a $actives[me] href="home.php?mod=space&do=album&view=me">{$rtj1009_lang['home015']}</a>
                <a $actives[we] href="home.php?mod=space&do=album&view=we">{$rtj1009_lang['home016']}</a>
                <a $actives[all] href="home.php?mod=space&do=album&view=all">{lang view_all}</a>
                <a <!--{if $_GET['ac'] == 'upload'}-->class="a"<!--{/if}-->href="home.php?mod=spacecp&ac=upload">{lang upload_pic}</a>
            </div>
        </div>
        <!--{if empty($_GET['op'])}-->
        <form method="post" autocomplete="off" id="albumform" action="home.php?mod=spacecp&ac=upload">
            <input type="hidden" name="albumsubmit" id="albumsubmit" value="true" />
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <div class="post_from ren_post_list cl">
                <ul class="ren_fb_hd cl">
                    <li class="ren_hdxx_li ren_hdxx_de">
                        <div class="ren_hdxx_lx">{$rtj1009_lang['home141']}</div>
                        <div class="ren_hdxx_lxnr ren-webki">
                            <select name="classid" id="classid" onchange="album_op(this.value);" >
                                <option name="albumop" id="albumop_selectalbum" class="pr" value="selectalbum" selected="selected" onclick="album_op(this.value);" />{lang add_to_existing_album}</option>
                                <option name="albumop" id="albumop_creatalbum" class="pr" value="creatalbum" onclick="album_op(this.value);" />{lang create_new_album}</option>
                            </select>
                        </div>
                    </li>


                    <li id="selectalbum" class="ren_hdxx_li ren_hdxx_de">
                        <div class="ren_hdxx_lx">{lang select_album}</div>
                        <div class="ren_hdxx_lxnr ren-webki">
                            <select name="albumid" id="uploadalbumid">
                                <!--{loop $albums $value}-->
                                <!--{if $value['albumid'] == $_GET['albumid']}-->
                                <option value="$value[albumid]" selected="selected">$value[albumname]</option>
                                <!--{else}-->
                                <option value="$value[albumid]">$value[albumname]</option>
                                <!--{/if}-->
                                <!--{/loop}-->
                            </select>
                        </div>
                    </li>
                    <div class="kong"></div>
                    <ul id="creatalbum" class="ren_fb_hd d cl" style="display:none;">
                        <li class="ren_bl_li">
                            <div class="ren_hdxx_lx">{lang album_name}</div>
                            <div class="ren-post-btxx">
                                <input type="text" name="albumname" id="albumname" size="20" placeholder="{$rtj1009_lang['ren073']}" />
                            </div>
                        </li>
                        <li class="ren_bl_no">
                            <textarea class="pt" name="message" id="uchome-ttHtmlEditor" cols="40" rows="3" placeholder="{lang album_depict}">$blog[message]</textarea>
                        </li>
                        <!--{if $_G['setting']['albumcategorystat'] && $categoryselect}-->
                        <li class="ren_hdxx_li ren_hdxx_de">
                            <div class="ren_hdxx_lx">{lang site_categories}</div>
                            <div class="ren_hdxx_lxnr ren-webki">
                                $categoryselect
                            </div>
                        </li>
                        <!--{/if}-->

                        <li class="ren_hdxx_li ren_hdxx_de">
                            <div class="ren_hdxx_lx">{lang privacy_settings}</div>
                            <div class="ren_hdxx_lxnr ren-webki">
                                <select name="friend" id="uploadfriend" onchange="passwordShow(this.value);" class="ps">
                                    <option value="0">{lang friendname_0}</option>
                                    <option value="1">{lang friendname_1}</option>
                                    <option value="2">{lang friendname_2}</option>
                                    <option value="3">{lang friendname_3}</option>
                                    <option value="4">{lang friendname_4}</option>
                                </select>
                            </div>
                        </li>

                        <li id="span_password" class="ren_hdxx_li ren_hdxx_de" style="display:none;">
                            <div class="ren_hdxx_lx">{lang password}</div>
                            <div class="ren_hdxx_lxnr">
                                <input type="text" name="password" id="uploadpassword" size="10" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')" class="px" />
                            </div>
                        </li>
                        <div class="kong"></div>
                    </ul>
                </ul>

                <ul id="imglist" class="ren-upload-imglist cl">
                    <div class="ren-upload-dimg">
                        <a href="javascript:;" class="ren-upload-a">
                            <i class="icon ren-font">&#xe60d;</i>
                            <input type="file" name="Filedata" id="filedata"/>
                            <span>{$rtj1009_lang['home142']}</span>
                        </a>
                        <p>{$rtj1009_lang['home143']}</p>
                    </div>
                </ul>
            </div>
            <div class="ren_ft_anniu">
                <button type="submit" name="albumsubmit_btn" id="albumsubmit_btn" class="formdialog ren_ft_an" value="true">{lang upload_start}</button>
            </div>
        </form>
        <!--{/if}-->
    </div>
    <script type="text/javascript" src="template/rtj1009_app/js/ajaxfileupload.js?{VERHASH}"></script>
    <script type="text/javascript" src="template/rtj1009_app/js/buildfileupload.js?{VERHASH}"></script>
    <script type="text/javascript">
        var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
        var STATUSMSG = {
            '-1' : '{lang uploadstatusmsgnag1}',
            '0' : '{lang uploadstatusmsg0}',
            '1' : '{lang uploadstatusmsg1}',
            '2' : '{lang uploadstatusmsg2}',
            '3' : '{lang uploadstatusmsg3}',
            '4' : '{lang uploadstatusmsg4}',
            '5' : '{lang uploadstatusmsg5}',
            '6' : '{lang uploadstatusmsg6}',
            '7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
            '8' : '{lang uploadstatusmsg8}',
            '9' : '{lang uploadstatusmsg9}',
            '10' : '{lang uploadstatusmsg10}',
            '11' : '{lang uploadstatusmsg11}'
        };
        $(document).on('change', '#filedata', function() {
            popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

            uploadsuccess = function(data) {
                if(data == '') {
                    popup.open('{lang uploadpicfailed}', 'alert');
                }
                var dataarr = eval('('+data+')');
                if (dataarr['picid'] == '0') {
                    popup.open('{lang uploadpicfailed}', 'alert');
                } else {
                    popup.close();
                    $('#imglist').append('<li class="ren-upload-li"><span aid="'+dataarr['picid']+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><div class="ren-upload-img"><span class="p_img"><'+'img id="aimg_'+dataarr['picid']+'" src="'+dataarr['bigimg']+'" /></span></div><div class="ren-upload-textarea"><textarea name="title['+dataarr['picid']+']" placeholder="$rtj1009_lang[home144]"></textarea></div></li>');
                }
            };

            if(typeof FileReader != 'undefined' && this.files[0]) {//note 支持html5上传新特性

                $.buildfileupload({
                    uploadurl:'{$_G[siteurl]}misc.php?mod=swfupload&action=swfupload&operation=album&type=image',
                    files:this.files,
                    uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                    uploadinputname:'Filedata',
                    maxfilesize:"$swfconfig[max]",
                    success:uploadsuccess,
                    error:function() {
                        popup.open('{lang uploadpicfailed}', 'alert');
                    }
                });

            } else {

                $.ajaxfileupload({
                    url:'{$_G[siteurl]}misc.php?mod=swfupload&action=swfupload&operation=album&type=image',
                    data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
                    dataType:'text',
                    fileElementId:'filedata',
                    success:uploadsuccess,
                    error: function() {
                        popup.open('{lang uploadpicfailed}', 'alert');
                    }
                });

            }
        });

        <!--{if 0 && $_G['setting']['mobile']['geoposition']}-->
        geo.getcurrentposition();
        <!--{/if}-->
        $('#postsubmit').on('click', function() {
            var obj = $(this);
            popup.open('<img src="' + IMGDIR + '/imageloading.gif">');

            var postlocation = '';
            if(geo.errmsg === '' && geo.loc) {
                postlocation = geo.longitude + '|' + geo.latitude + '|' + geo.loc;
            }

            $.ajax({
                type:'POST',
                url:form.attr('action') + '&geoloc=' + postlocation + '&handlekey='+form.attr('id')+'&inajax=1',
                data:form.serialize(),
                dataType:'xml'
            })
                .success(function(s) {
                    popup.open(s.lastChild.firstChild.nodeValue);
                })
                .error(function() {
                    popup.open('{lang networkerror}', 'alert');
                });
            return false;
        });

        $(document).on('click', '.del', function() {
            var obj = $(this);
            $.ajax({
                type:'GET',
                url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
            })
                .success(function(s) {
                    obj.parent().remove();
                })
                .error(function() {
                    popup.open('{lang networkerror}', 'alert');
                });
            return false;
        });
    </script>


    <script type="text/javascript">
        var check = false;
        no_insert = 1;
        function a_addOption() {
            var obj = $('#uploadalbum');
            obj.value = 'addoption';
            addOption(obj);
        }

        function album_op(id) {
            $('#selectalbum').css('display','none');
            $('#creatalbum').css('display','none');
            $('#'+id).css('display','block');
        }

        function passwordShow(value) {
            if(value==4) {
                $('#span_password').css('display','');
            } else if(value==2) {
                $('#span_password').css('display','none');
            } else {
                $('#span_password').css('display','none');
            }
        }
    </script>
</div>

<!--{template common/footer}-->