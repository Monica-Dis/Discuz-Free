<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
		<a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{lang medals_center}</span>
		</div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
	</div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content p-b-0">
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
			<a href="home.php?mod=medal"{if empty($_GET[action])} class="a"{/if}>{lang medals_center}</a>
			<a href="home.php?mod=medal&action=log"{if $_GET[action] == 'log'} class="a"{/if}>{lang my_medals}</a>
		</div>
	</div>
	<div class="ren-medal cl">
		<!--{if empty($_GET[action])}-->
			<!--{if $medallist}-->
				<!--{if $medalcredits && $_G['uid']}-->
					<div class="ren-medal-extc">
						{lang you_have_now}
						<!--{eval $i = 0;}-->
						<!--{loop $medalcredits $id}-->
							<!--{if $i != 0}-->, <!--{/if}-->{$_G['setting']['extcredits'][$id][img]} {$_G['setting']['extcredits'][$id][title]} <span><!--{echo getuserprofile('extcredits'.$id);}--></span> {$_G['setting']['extcredits'][$id][unit]}
							<!--{eval $i++;}-->
						<!--{/loop}-->
					</div>
				<!--{/if}-->
				<ul class="ren-medal-ul cl">
					<!--{loop $medallist $key $medal}-->
						<li>
							<div class="ren-medal-nxx">
								<div id="medal_$medal[medalid]_menu" class="tip tip_4" style="display:none">
									<div class="tip_horn"></div>
									<div class="tip_c" style="text-align:left">
										<p>$medal[description]</p>
										<p class="mtn">
											<!--{if $medal[expiration]}-->
												{lang expire} $medal[expiration] {lang days},
											<!--{/if}-->
											<!--{if $medal[permission] && !$medal['price']}-->
												$medal[permission]
											<!--{else}-->
												<!--{if $medal[type] == 0}-->
													{lang medals_type_0}
												<!--{elseif $medal[type] == 1}-->
													<!--{if $medal['price']}-->
														<!--{if {$_G['setting']['extcredits'][$medal[credit]][unit]}}-->
															{$_G['setting']['extcredits'][$medal[credit]][title]} <strong class="xi1 xw1 xs2">$medal[price]</strong> {$_G['setting']['extcredits'][$medal[credit]][unit]}
														<!--{else}-->
															<strong class="xi1 xw1 xs2">$medal[price]</strong> {$_G['setting']['extcredits'][$medal[credit]][title]}
														<!--{/if}-->
													<!--{else}-->
														{lang medals_type_1}
													<!--{/if}-->
												<!--{elseif $medal[type] == 2}-->
													{lang medals_type_2}
												<!--{/if}-->
											<!--{/if}-->
										</p>
									</div>
								</div>
								<div id="medal_$medal[medalid]" class="mg_img"><img src="{STATICURL}image/common/$medal[image]" class="vm" alt="$medal[name]" /></div>
								<p class="ren-medal-name">$medal[name]</p>
								<div class="ren-medal-btnxx">
									<!--{if in_array($medal[medalid], $membermedal)}-->
									<span class="ren-medal-btn ren_qxgz">
										{lang space_medal_have}
									</span>
									<!--{else}-->
										<!--{if $medal[type] && $_G['uid']}-->
											<!--{if in_array($medal[medalid], $mymedals)}-->
												<!--{if $medal['price']}-->
													{lang space_medal_purchased}
												<!--{else}-->
													<!--{if !$medal[permission]}-->
														{lang space_medal_applied}
													<!--{else}-->
														{lang space_medal_receive}
													<!--{/if}-->
												<!--{/if}-->
											<!--{else}-->
											<span class="ren-medal-btn">
												<a href="home.php?mod=medal&action=confirm&medalid=$medal[medalid]" class="dialog">
													<!--{if $medal['price']}-->
														{lang space_medal_buy}
													<!--{else}-->
														<!--{if !$medal[permission]}-->
															{lang medals_apply}
														<!--{else}-->
															{lang medals_draw}
														<!--{/if}-->
													<!--{/if}-->
												</a>
											</span>
											<!--{/if}-->
										<!--{/if}-->
									<!--{/if}-->

									<!--{if !in_array($medal[medalid], $membermedal) && !$medal[type]}-->
										<span class="ren-medal-btn ren_qxgz">
										<!--{if $medal[type] == 0}-->
											{lang medals_type_0}
										<!--{elseif $medal[type] == 1}-->
											{lang medals_type_1}
										<!--{elseif $medal[type] == 2}-->
											{lang medals_type_2}
										<!--{/if}-->
										</span>
									<!--{/if}-->
								</div>
							</div>
						</li>
					<!--{/loop}-->
				</ul>
			<!--{else}-->
				<!--{if $medallogs}-->
				<div class="ren_ss_wu">
					<i class="icon ren-font">&#xe608;</i>
					<span>{lang medals_nonexistence}</span>
				</div>
				<!--{else}-->
				<div class="ren_ss_wu">
					<i class="icon ren-font">&#xe608;</i>
					<span>{lang medals_noavailable}</span>
				</div>
				<!--{/if}-->
			<!--{/if}-->

			<!--{if $lastmedals}-->
			<div class="ren_xx_box cl">
				<div class="ren-medal-bt">
					<span>{lang medals_record}</span>
				</div>
				<ul>
					<!--{loop $lastmedals $lastmedal}-->
					<li>
						<a href="home.php?mod=space&uid=$lastmedal[uid]&do=profile">
							<!--{avatar($lastmedal[uid],small)}-->
							<div class="ren-xx-name">
								<span class="name">$lastmedalusers[$lastmedal[uid]][username]</span>
								<span class="time">$lastmedal[dateline]</span>
							</div>
							<div class="ren-xx-mes grey">
								<span>{lang medals_message2}$medallist[$lastmedal['medalid']]['name']{lang medals}</span>
							</div>
						</a>
					</li>
					<!--{/loop}-->
				</ul>
			</div>
			<!--{/if}-->
		<!--{elseif $_GET[action] == 'log'}-->

			<!--{if $mymedals}-->
				<ul class="ren-medal-myxz cl">
					<!--{loop $mymedals $mymedal}-->
					<li>
						<div class="ren-medal-nxx">
							<div class="mg_img"><img src="{STATICURL}image/common/$mymedal[image]" alt="$mymedal[name]" class="vm" /></div>
							<p class="ren-medal-name">$mymedal[name]</p>
						</div>
					</li>
					<!--{/loop}-->
				</ul>
			<!--{/if}-->

			<!--{if $medallogs}-->
				<div class="ren-medal-bt">
					<span>{lang medals_record}</span>
				</div>
				<ul class="ren-medal-myjl">
					<!--{loop $medallogs $medallog}-->
					<li>
						<!--{if $medallog['type'] == 2 || $medallog['type'] == 3}-->
							{lang medals_message3} $medallog[dateline] {lang medals_message4} <strong>$medallog[name]</strong> {lang medals},<!--{if $medallog['type'] == 2}-->{lang medals_operation_2}<!--{elseif $medallog['type'] == 3}-->{lang medals_operation_3}<!--{/if}-->
						<!--{elseif $medallog['type'] != 2 && $medallog['type'] != 3}-->
							{lang medals_message3} $medallog[dateline] {lang medals_message5} <strong>$medallog[name]</strong> {lang medals},<!--{if $medallog[expiration]}-->{lang expire}: $medallog[expiration]<!--{else}-->{lang medals_noexpire}<!--{/if}-->
						<!--{/if}-->
					</li>
					<!--{/loop}-->
				</ul>
				<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
			<!--{else}-->
				<div class="ren_ss_wu">
					<i class="icon ren-font">&#xe608;</i>
					<span>{lang medals_nonexistence_own}</span>
				</div>
			<!--{/if}-->
		<!--{/if}-->
	</div>
</div>

<!--{template common/footer}-->