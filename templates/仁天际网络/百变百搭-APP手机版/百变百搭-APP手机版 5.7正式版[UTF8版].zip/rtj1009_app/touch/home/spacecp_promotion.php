<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_grkj z">
            <span class="ren_bk_name ren_vm">{lang memcp_promotion}</span>
        </div>
        <div class="ren_nav_right open-panel">
            <div class="ren_btn">
                <span><span class="ren_nav_icon"><span></span></span></span>
            </div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content ren-prom">
    <!--{if $_G['setting']['creditspolicy']['promotion_visit'] || $_G['setting']['creditspolicy']['promotion_register']}-->
    <div class="ren-prom-ts">
        <!--{if $_G['setting']['creditspolicy']['promotion_visit']}-->
        <p>
            {$rtj1009_lang['home135']} <i>$visitstr</i>{$rtj1009_lang['home137']}
        </p>
        <!--{/if}-->
        <!--{if $_G['setting']['creditspolicy']['promotion_register']}-->
        <p>
            <!--{if $_G['setting']['creditspolicy']['promotion_visit']}-->
            {$rtj1009_lang['home136']} <i>$regstr</i>{$rtj1009_lang['home137']}
            <!--{else}-->
            {$rtj1009_lang['home136']} <i>$regstr</i>{$rtj1009_lang['home137']}
            <!--{/if}-->
        </p>
        <!--{/if}-->
    </div>
    <script type="text/javascript" src='template/rtj1009_app/js/jquery.qrcode.min.js'></script>
    <div class="ren-prom-code">
        <div class="ren-code-k">
            <div class="ren-code-txt">
                <div id="ren-code-svs"></div>
                <img id='ren-code-img' class="vm" />
            </div>
            <div class="ren-code-us">
                <img src="<!--{avatar($_G[uid], middle, true)}-->" class="vm" >
                <h3 class="ren-code-usname">$_G[username]</h3>
                <span>{$rtj1009_lang['home138']}</span>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        var str = '$_G[siteurl]?fromuid=$_G[uid]';
        var qrcode = $('#ren-code-svs').qrcode({
            render: "canvas",
            width:  400,
            height: 400,
            text: str
        }).hide();
        var canvas = qrcode.find('canvas').get(0);
        $('#ren-code-img').attr('src',canvas.toDataURL('image/jpg'));
    </script>
    <!--{/if}-->
</div>
<!--{template common/footer}-->