<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if $_GET['op'] == 'delete'}-->
<div class="tip">
	<form method="post" autocomplete="off" id="doingform_{$doid}_{$id}" name="doingform" action="home.php?mod=spacecp&ac=doing&op=delete&doid=$doid&id=$id">
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<dt>{lang determine_delete_doing}</dt>
		<dd>
			<input name="deletesubmit" type="submit" value="{lang determine}" class="button2 color">
			<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
		</dd>
	</form>
</div>
<!--{elseif $_GET['op'] == 'spacenote'}-->
	<!--{if $space[spacenote]}-->$space[spacenote]<!--{/if}-->
<!--{elseif $_GET['op'] == 'docomment' || $_GET['op'] == 'getcomment'}-->
	<!--{if helper_access::check_module('doing')}-->
<div class="tip ren-hf-post">
	<div id="{$_GET[key]}_form_{$doid}_{$id}">
		<form id="{$_GET[key]}_docommform_{$doid}_{$id}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=doing&op=comment&doid=$doid&id=$id" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
			<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
			<input type="hidden" name="commentsubmit" value="true" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<div class="post_from ren_kshf cl">
				<div class="cl">
					<div class="ren-post-nav cl">
						<div class="ren-post-wall">
							<span>{lang reply}</span>
						</div>
					</div>
					<div class="ren_post_nr cl">
					<textarea name="message" id="{$_GET[key]}_form_{$doid}_{$id}_t" cols="70" rows="2" class="ren_post_nrk"></textarea>
					</div>
				</div>
			</div>
			<dd>
				<input type="submit" name="do_button" id="{$_GET[key]}_replybtn_{$doid}_{$id}" value="{lang reply}" class="formdialog button2 color">
				<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
			</dd>
		</form>
		<span id="return_$_GET[handlekey]"></span>
	</div>
	<!--{/if}-->
	<!--{if $_GET['op'] == 'getcomment'}-->
		<!--{template home/space_doing_li}-->
	<!--{/if}-->
</div>
<!--{else}-->

<div id="content">
	<!--{if helper_access::check_module('doing')}-->
	<!--{template home/space_doing_form}-->
	<!--{/if}-->
</div>

<!--{/if}-->

<!--{template common/footer}-->