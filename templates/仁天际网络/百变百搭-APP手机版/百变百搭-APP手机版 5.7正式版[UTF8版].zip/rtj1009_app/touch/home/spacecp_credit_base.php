<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{$rtj1009_lang['home107']}</span>
		</div>
        <div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<script type="text/javascript">
    function did(id) {
        return document.getElementById(id);
    }
</script>
<div class="content p-b-0">
		<!--{subtemplate home/spacecp_credit_header}-->
		<!--{if in_array($_GET['op'], array('base', 'buy', 'transfer', 'exchange'))}-->
			<div class="ren-credit cl">
			<!--{if  $_GET['op'] == 'base'}-->
				<div class="ren-credit-z">
					<div class="ren-credit-zxx"><h3>{lang credits}</h3><p>$_G['member']['credits']</p></div>
					<span class="ren-credit-zsm">$creditsformulaexp</span>
				</div>
			<!--{/if}-->
				<ul class="cl">
				<!--{eval $creditid=0;}-->
				<!--{if $_GET['op'] == 'base' && $_G['setting']['creditstrans']}-->
					<!--{eval $creditid=$_G['setting']['creditstrans'];}-->
					<!--{if $_G['setting']['extcredits'][$creditid]}-->
					<!--{eval $credit=$_G['setting']['extcredits'][$creditid]; }-->
					<li class="ren-credit-li cl"><span><!--{if $credit[img]}-->{$credit[img]}<!--{/if}--> {$credit[title]}</span><!--{echo getuserprofile('extcredits'.$creditid);}--> {$credit[unit]}</li>
					<!--{/if}-->
				<!--{/if}-->
				<!--{loop $_G['setting']['extcredits'] $id $credit}-->
					<!--{if $id!=$creditid}-->
					<li class="ren-credit-li cl"><span><!--{if $credit[img]}--> {$credit[img]}<!--{/if}--> {$credit[title]}</span><!--{echo getuserprofile('extcredits'.$id);}--> {$credit[unit]}</li>
					<!--{/if}-->
				<!--{/loop}-->
				</ul>
			</div>
		<!--{/if}-->

		<!--{if $_GET['op'] == 'buy'}-->

			<!--{if ($_G[setting][ec_ratio] && ($_G[setting][ec_account] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_tenpay_bargainor])) || $_G[setting][card][open]}-->
			<form id="addfundsform" name="addfundsform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=buy">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="addfundssubmit" value="true" />
				<input type="hidden" name="handlekey" value="buycredit" />
				
				<ul class="ren-credit-exchange cl">
                    <div id="paybox">
                        <li class="ren-credit-exli yi" style="{if ($_G[setting][ec_tenpay_bargainor] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_account]) && empty($ecchecked) }display:;{else}display:none;{/if}">
                            <div class="ren-credit-exc e">
                            <span>{lang memcp_credits_addfunds}</span>
                                <input type="text" class="ren-credit-expx" style="width: 17%;" id="addfundamount" name="addfundamount" value="0" onkeyup="addcalcredit()" />
                                &nbsp;{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}&nbsp;
                                {lang credits_need}&nbsp;{lang memcp_credits_addfunds_caculate_radio}
                            </div>
                        </li>

                        <div id="taxpercent" class="taxpercent">
                                {lang memcp_credits_addfunds_rules_ratio} =  <strong>$_G[setting][ec_ratio]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}
                                <!--{if $_G[setting][ec_mincredits]}--><br />{lang memcp_credits_addfunds_rules_min}  <strong>$_G[setting][ec_mincredits]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{/if}-->
                                <!--{if $_G[setting][ec_maxcredits]}--><br />{lang memcp_credits_addfunds_rules_max}  <strong>$_G[setting][ec_maxcredits]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{/if}-->
                                <!--{if $_G[setting][ec_maxcreditspermonth]}--><br />{lang memcp_credits_addfunds_rules_month}  <strong>$_G[setting][ec_maxcreditspermonth]</strong> {$_G[setting][extcredits][$_G[setting][creditstrans]][unit]}{$_G[setting][extcredits][$_G[setting][creditstrans]][title]}<!--{/if}-->
                        </div>
                    </div>
                        <div class="long-logo mbw">
                            <ul>
                                <li class="ren-crebuy-li">
                                    <!--{if $_G[setting][ec_ratio] && $_G[setting][ec_account]}-->
                                    <div class="ren-crebuy-labe z">
                                        <label class="label-checkbox item-content" onclick="api_alipay();" for="apitype_alipay">
                                            <input name="bank_type" type="radio" value="alipay" class="vm" id="apitype_alipay" $ecchecked />
                                            <div class="item-media"><i class="icon ren-font">&#xe62b;</i></div>
                                        </label>
                                    </div>
                                    <!--{/if}-->
                                    <!--{if $_G[setting][card][open]}-->
                                    <div class="ren-crebuy-labe y">
                                        <label class="label-checkbox item-content" onclick="activatecardbox();">
                                        <input name="bank_type" type="radio" value="card" id="apitype_card" class="vm" $ecchecked  onclick="activatecardbox();" />
                                            <div class="item-media tu"><i class="icon ren-font">&#xe6b5;</i>{lang card_credit}</div>
                                        </label>
                                    </div>
                                    <!--{/if}-->
                                </li>
                            </ul>
                        </div>
                        <!--{if $_G[setting][card][open]}-->
                        <li id="cardbox" class="ren-credit-exli ren-credit-ssli" style="{if $_G[setting][card][open] && $ecchecked}display:;{else}display:none;{/if}">
                            <div class="ren-credit-mm">{lang card}</div>
                            <div class="ren-credit-mmk">
                                <input type="text" class="px" id="cardid" name="cardid" />
                            </div>
                        </li>

                        <!--{if $seccodecheck}-->
                    <!--{block sectpl}--><table id="card_box_sec" style="{if $_G[setting][card][open] && $ecchecked}display:;{else}display:none;{/if}" cellspacing="0" cellpadding="0" class="tfm mtn"><tr><th><sec></th><td colspan="2"><span id="sec<hash>" onclick="showMenu({'ctrlid':this.id,'win':'{$_GET[handlekey]}'})"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div></td></tr></table><!--{/block}-->
                    <!--{subtemplate common/seccheck}-->
                        <!--{/if}-->
                        <!--{/if}-->
				</ul>
				<div class="ren_login btn_login">
					<button type="submit" name="addfundssubmit_btn" class="formdialog pn button ren_btn" id="addfundssubmit_btn" value="true">{lang memcp_credits_addfunds}</button>
				</div>
			</form>
			<span style="display: none" id="return_addfundsform"></span>
			<script type="text/javascript">
				function addcalcredit() {
					var addfundamount = did('addfundamount').value.replace(/^0/, '');
					var addfundamount = parseInt(addfundamount);
                    did('desamount').innerHTML = !isNaN(addfundamount) ? Math.ceil(((addfundamount / $_G[setting][ec_ratio]) * 100)) / 100 : 0;
				}
				<!--{if $_G[setting][card][open]}-->
				function activatecardbox() {
                    did('apitype_card').checked=true;
                    did('cardbox').style.display='';
					if(did('card_box_sec')){
                        did('card_box_sec').style.display='';
					}
                    did('paybox').style.display = 'none';
				}
                function api_alipay() {
                    did('cardbox').style.display = 'none';
                    did('paybox').style.display = '';
                }
				<!--{/if}-->
			</script>
			<!--{/if}-->
		<!--{elseif $_GET['op'] == 'transfer'}-->

			<!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
			<form id="transferform" name="transferform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=transfer">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="transfersubmit" value="true" />
				<input type="hidden" name="handlekey" value="transfercredit" />
				<ul class="ren-credit-exchange cl">
					<li class="ren-credit-exli yi">
						<div class="ren-credit-exc e">
						<span>{lang memcp_credits_transfer}</span>
							<input type="text" name="transferamount" id="transferamount" class="ren-credit-expx" style="width: 17%;" value="0" />
							{$_G[setting][extcredits][$_G[setting][creditstransextra][9]][title]}&nbsp;
							{lang credits_give}&nbsp;
							<input type="text" name="to" id="to" class="ren-credit-expx" style="width: 40%;" />
						</div>
					</li>
					
					<div id="taxpercent" class="taxpercent">
					{lang memcp_credits_transfer_min_balance} $_G[setting][transfermincredits] {$_G[setting][extcredits][$_G[setting][creditstransextra][9]][unit]}, 
							<!--{if intval($taxpercent) > 0}-->{lang credits_tax} $taxpercent<!--{/if}-->
					</div>
					<li class="ren-credit-exli">
						<div class="ren-credit-mm">{lang transfer_login_password}<span class="rq">*</span></div>
						<div class="ren-credit-mmk"><input type="password" name="password" class="px" value="" /></div>
					</li>
					<li class="ren-credit-exli">
						<div class="ren-credit-mm">{lang credits_transfer_message}</div>
						<div class="ren-credit-mmk"><input type="text" name="transfermessage" class="px" size="40" /></div>
					</li>
				</ul>
				<div class="ren_login btn_login">
					<button type="submit" name="transfersubmit_btn" id="transfersubmit_btn" class="formdialog pn button ren_btn" value="true"><em>{lang memcp_credits_transfer}</em></button>
					<span style="display: none" id="return_transfercredit"></span>
				</div>
			</form>
			<!--{/if}-->

		<!--{elseif $_GET['op'] == 'exchange'}-->

			<!--{if $_G[setting][exchangestatus] && ($_G[setting][extcredits] || $_CACHE['creditsettings'])}-->
			<form id="exchangeform" name="exchangeform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=credit&op=exchange&handlekey=credit">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<input type="hidden" name="operation" value="exchange" />
				<input type="hidden" name="exchangesubmit" value="true" />
				<input type="hidden" name="outi" value="" />
				<ul class="ren-credit-exchange cl">
					<li class="ren-credit-exli yi">
						<div class="ren-credit-exc yi">
						<span>{lang memcp_credits_exchange}</span>
							<input type="text" id="exchangeamount" name="exchangeamount" class="ren-credit-expx" style="width: 34%;" value="0" onkeyup="exchangecalcredit()" />
							<select name="tocredits" id="tocredits" class="ren-credit-exps" onChange="exchangecalcredit()">
							<!--{loop $_G[setting][extcredits] $id $ecredits}-->
								<!--{if $ecredits[allowexchangein] && $ecredits[ratio]}-->
									<option value="$id" unit="$ecredits[unit]" title="$ecredits[title]" ratio="$ecredits[ratio]">$ecredits[title]</option>
								<!--{/if}-->
							<!--{/loop}-->
							<!--{eval $i=0;}-->

							<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
								<!--{if $data[title]}-->
								<option value="$id" outi="$i">$data[title]</option>
								<!--{/if}-->
							<!--{/loop}-->
							</select>
						</div>
						<div class="ren-credit-exc">
							<span>{lang credits_need}</span>
							<input type="text" id="exchangedesamount" class="ren-credit-expx" style="width: 34%;" value="0" disabled="disabled" />
							<select name="fromcredits" id="fromcredits_0" class="ren-credit-exps" onChange="exchangecalcredit();">
							<!--{loop $_G[setting][extcredits] $id $credit}-->
								<!--{if $credit[allowexchangeout] && $credit[ratio]}-->
									<option value="$id" unit="$credit[unit]" title="$credit[title]" ratio="$credit[ratio]">$credit[title]</option>
								<!--{/if}-->
							<!--{/loop}-->
							</select>
							<!--{eval $i=0;}-->
							<!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
								<select name="fromcredits_$i" id="fromcredits_$i" class="ps" style="display: none" onChange="exchangecalcredit()">
								<!--{loop $data[creditsrc] $id $ratio}-->
									<option value="$id" unit="$_G['setting']['extcredits'][$id][unit]" title="$_G['setting']['extcredits'][$id][title]" ratiosrc="$data[ratiosrc][$id]" ratiodesc="$data[ratiodesc][$id]">$_G['setting']['extcredits'][$id][title]</option>
								<!--{/loop}-->
								</select>
							<!--{/loop}-->
                            <script type="text/javascript">
                                var tocredits = did('tocredits');
                                var fromcredits = did('fromcredits_0');
                                if(fromcredits.length > 1 && tocredits.value == fromcredits.value) {
                                    fromcredits.selectedIndex = tocredits.selectedIndex + 1;
                                }
                            </script>
					</div>
					</li>
					
					<div id="taxpercent" class="taxpercent">
					<!--{if $_G[setting][exchangemincredits]}-->
						{lang memcp_credits_exchange_min_balance} $_G[setting][exchangemincredits], 
					<!--{/if}-->
					<!--{if intval($taxpercent) > 0}-->
						{lang credits_tax} $taxpercent
					<!--{/if}-->
					</div>
					<li class="ren-credit-exli">
						<div class="ren-credit-mm">{lang transfer_login_password}<span class="rq">*</span></div>
						<div class="ren-credit-mmk"><input type="password" name="password" class="px" value="" size="20" /></div>
					</li>
				</ul>
				<div class="ren_login btn_login"><button type="submit" name="exchangesubmit_btn" id="exchangesubmit_btn" class="formdialog pn button ren_btn" value="true" tabindex="2"><em>{lang memcp_credits_exchange}</em></button></div>
			</form>
            <script type="text/javascript">
                function exchangecalcredit() {
                    with(did('exchangeform')) {
                        tocredit = tocredits[tocredits.selectedIndex];
                        if(!tocredit) {
                            return;
                        }
                        <!--{eval $i=0;}-->
                        <!--{loop $_CACHE['creditsettings'] $id $data}--><!--{eval $i++;}-->
                        did('fromcredits_$i').style.display = 'none';
                        <!--{/loop}-->
                        if(tocredit.getAttribute('outi')) {
                            outi.value = tocredit.getAttribute('outi');
                            fromcredit = did('fromcredits_' + tocredit.getAttribute('outi'));
                            did('taxpercent').style.display = did('fromcredits_0').style.display = 'none';
                            fromcredit.style.display = '';
                            fromcredit = fromcredit[fromcredit.selectedIndex];
                            did('exchangeamount').value = did('exchangeamount').value.toInt();
                            if(did('exchangeamount').value != 0) {
                                did('exchangedesamount').value = Math.floor( fromcredit.getAttribute('ratiosrc') / fromcredit.getAttribute('ratiodesc') * $('exchangeamount').value);
                            } else {
                                did('exchangedesamount').value = '';
                            }
                        } else {
                            outi.value = 0;
                            did('taxpercent').style.display = did('fromcredits_0').style.display = '';
                            fromcredit = fromcredits[fromcredits.selectedIndex];
                            did('exchangeamount').value = did('exchangeamount').value.toInt();
                            if(fromcredit.getAttribute('title') != tocredit.getAttribute('title') && did('exchangeamount').value != 0) {
                                if(tocredit.getAttribute('ratio') < fromcredit.getAttribute('ratio')) {
                                    did('exchangedesamount').value = Math.ceil( tocredit.getAttribute('ratio') / fromcredit.getAttribute('ratio') * did('exchangeamount').value * (1 + $_G[setting][creditstax]));
                                } else {
                                    did('exchangedesamount').value = Math.floor( tocredit.getAttribute('ratio') / fromcredit.getAttribute('ratio') * did('exchangeamount').value * (1 + $_G[setting][creditstax]));
                                }
                            } else {
                                did('exchangedesamount').value = '';
                            }
                        }
                    }
                }
                String.prototype.toInt = function() {
                    var s = parseInt(this);
                    return isNaN(s) ? 0 : s;
                }
                exchangecalcredit();
            </script>
			<!--{/if}-->
		<!--{/if}-->
		</div>
<!--{template common/footer}-->