<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<ul class="ren-notice-xnav">
    <li $subactives[uselog]><a href="home.php?mod=magic&action=log&operation=uselog">{lang magics_log_use}</a></li>
    <li $subactives[buylog]><a href="home.php?mod=magic&action=log&operation=buylog">{lang magics_log_buy}</a></li>
    <li $subactives[givelog]><a href="home.php?mod=magic&action=log&operation=givelog">{lang magics_log_present}</a></li>
    <li $subactives[receivelog]><a href="home.php?mod=magic&action=log&operation=receivelog">{lang magics_log_receive}</a></li>
</ul>
<!--{if $operation == 'uselog'}-->
<!--{if $loglist}-->
<div class="ren-tdats cl"style="margin-top: 7px;">
    <table cellspacing="0" cellpadding="0" class="tdat ftb mtm mbm" style="width: 100%;">
        <tr class="alt ren-tdats-alt">
            <th>{lang magics_name}</th>
            <th>{lang magics_dateline_use}</th>
            <th>{lang magics_target_use}</th>
        </tr>
        <!--{loop $loglist $log}-->
        <tr>
            <td>$log[name]</td>
            <td>$log[dateline]</td>
            <td>
                <!--{if $log[idtype] == 'uid'}-->
                <a href="home.php?mod=space&uid=$log[targetid]&do=profil">{lang magics_target}</a>
                <!--{elseif $log[idtype] == 'tid'}-->
                <a href="forum.php?mod=viewthread&tid=$log[targetid]">{lang magics_target}</a>
                <!--{elseif $log[idtype] == 'pid'}-->
                <a href="forum.php?mod=redirect&pid=$log[targetid]&goto=findpost">{lang magics_target}</a>
                <!--{elseif $log[idtype] == 'sell'}-->
                {lang magics_operation_sell}
                <!--{elseif $log[idtype] == 'drop'}-->
                {lang magics_operation_drop}
                <!--{/if}-->
            </td>
        </tr>
        <!--{/loop}-->
    </table>
</div>
<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
<!--{else}-->
<div class="ren_ss_wu">
    <i class="icon ren-font">&#xe608;</i>
    <span>{lang data_nonexistence}</span>
</div>
<!--{/if}-->
<!--{elseif $operation == 'buylog'}-->
<!--{if $loglist}-->
<div class="ren-tdats cl"style="margin-top: 7px;">
    <table cellspacing="0" cellpadding="0" class="tdat ftb mtm mbm" style="width: 100%;">
        <tr class="alt ren-tdats-alt">
            <th>{lang magics_name}</th>
            <th>{lang magics_dateline_buy}</th>
            <th>{lang magics_amount_buy}</th>
            <th>{lang magics_price_buy}</th>
        </tr>
        <!--{loop $loglist $log}-->
        <tr>
            <td>$log[name]</td>
            <td>$log[dateline]</td>
            <td>$log[amount]</td>
            <td>$log[price] {$_G['setting']['extcredits'][$log[credit]][unit]}{$_G['setting']['extcredits'][$log[credit]][title]}</td>
        </tr>
        <!--{/loop}-->
    </table>
</div>
<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
<!--{else}-->
<div class="ren_ss_wu">
    <i class="icon ren-font">&#xe608;</i>
    <span>{lang data_nonexistence}</span>
</div>
<!--{/if}-->
<!--{elseif $operation == 'givelog'}-->
<!--{if $loglist}-->
<div class="ren-tdats cl"style="margin-top: 7px;">
    <table cellspacing="0" cellpadding="0" class="tdat ftb mtm mbm" style="width: 100%;">
        <tr class="alt ren-tdats-alt">
            <th>{lang magics_name}</td>
            <th>{lang magics_dateline_present}</th>
            <th>{lang magics_amount_present}</th>
            <th>{lang magics_target_present}</th>
        </tr>
        <!--{loop $loglist $log}-->
        <tr>
            <td>$log[name]</td>
            <td>$log[dateline]</td>
            <td>$log[amount]</td>
            <td><a href="home.php?mod=space&uid=$log[uid]&do=profile">$log[username]</a></td>
        </tr>
        <!--{/loop}-->
    </table>
</div>
<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
<!--{else}-->
<div class="ren_ss_wu">
    <i class="icon ren-font">&#xe608;</i>
    <span>{lang data_nonexistence}</span>
</div>
<!--{/if}-->
<!--{elseif $operation == 'receivelog'}-->
<!--{if $loglist}-->
<div class="ren-tdats cl"style="margin-top: 7px;">
    <table cellspacing="0" cellpadding="0" class="tdat ftb mtm mbm" style="width: 100%;">
        <tr class="alt ren-tdats-alt">
            <th>{lang magics_name}</th>
            <th>{lang magics_dateline_receive}</th>
            <th>{lang magics_amount_receive}</th>
            <th>{lang magics_target_receive}</th>
        </tr>
        <!--{loop $loglist $log}-->
        <tr>
            <td><a href="home.php?mod=magic&action=index&operation=buy&magicid=$log[magicid]">$log[name]</a></td>
            <td>$log[dateline]</td>
            <td>$log[amount]</td>
            <td><a href="home.php?mod=space&uid=$log[uid]&do=profile">$log[username]</a></td>
        </tr>
        <!--{/loop}-->
    </table>
</div>
<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
<!--{else}-->
<div class="ren_ss_wu">
    <i class="icon ren-font">&#xe608;</i>
    <span>{lang data_nonexistence}</span>
</div>
<!--{/if}-->
<!--{/if}-->