<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="rtj1009_p_nav">
	<div class="ren_p_nav">
        <a href="home.php?mod=spacecp&ac=credit&op=base" $opactives[base]>{$rtj1009_lang['home108']}</a>
        <!--{if $_G[setting][transferstatus] && $_G['group']['allowtransfer']}-->
        <a href="home.php?mod=spacecp&ac=credit&op=transfer" $opactives[transfer]>{lang transfer_credits}</a>
        <!--{/if}-->
        <!--{if $_G[setting][exchangestatus]}-->
        <a href="home.php?mod=spacecp&ac=credit&op=exchange" $opactives[exchange]>{lang exchange_credits}</a>
        <!--{/if}-->
        <a href="home.php?mod=spacecp&ac=credit&op=log" $opactives[log]>{$rtj1009_lang['home109']}</a>
        <!--{if !empty($_G['setting']['plugins']['spacecp_credit'])}-->
            <!--{loop $_G['setting']['plugins']['spacecp_credit'] $id $module}-->
                <!--{if !$module['adminid'] || ($module['adminid'] && $_G['adminid'] > 0 && $module['adminid'] >= $_G['adminid'])}--><a href="home.php?mod=spacecp&ac=plugin&op=credit&id=$id" {if $_GET[id] == $id} class="a"{/if}>$module[name]</a><!--{/if}-->
            <!--{/loop}-->
        <!--{/if}-->
        <!--{if $_G[setting][ec_ratio] && ($_G[setting][ec_account] || $_G[setting][ec_tenpay_opentrans_chnid] || $_G[setting][ec_tenpay_bargainor]) || $_G['setting']['card']['open']}-->
        <a href="home.php?mod=spacecp&ac=credit&op=buy" $opactives[buy]>{lang buy_credits}</a>
        <!--{/if}-->
	</div>
</div>