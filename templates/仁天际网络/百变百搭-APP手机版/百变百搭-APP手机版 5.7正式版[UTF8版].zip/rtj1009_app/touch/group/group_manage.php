<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<ul class="ren-notice-xnav">
	<li {if $_GET['op'] == 'group'} class="a"{/if}><a href="forum.php?mod=group&action=manage&op=group&fid=$_G[fid]">{$rtj1009_lang['group017']}</a></li>
<!--{if !empty($groupmanagers[$_G[uid]]) || $_G['adminid'] == 1}-->
	<li {if $_GET['op'] == 'checkuser'} class="a"{/if}><a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]">{$rtj1009_lang['group018']}</a></li>
	<li {if $_GET['op'] == 'manageuser'} class="a"{/if}><a href="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]">{$rtj1009_lang['group019']}</a></li>
<!--{/if}-->
<!--{if $_G['forum']['founderuid'] == $_G['uid'] || $_G['adminid'] == 1}-->
	<li {if $_GET['op'] == 'demise'} class="a"{/if}><a href="forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]">{$rtj1009_lang['group020']}</a></li>
<!--{/if}-->
</ul>

<!--{if $_GET['op'] == 'group'}-->
<div class="rtj1009_post rtj1009_m_main cl">
		<form enctype="multipart/form-data" action="forum.php?mod=group&action=manage&op=group&fid=$_G[fid]" name="manage" method="post" autocomplete="off">
			<input type="hidden" value="{FORMHASH}" name="formhash" />
<div class="post_from ren_post_list cl">
			<div class="ren_fb_hd ren-create cl">
				<ul>
				<!--{if !empty($specialswitch['allowchangename']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{lang group_name}<span class="rq"> *</span></div>
						<div class="ren_hdxx_lxnr">
						   <input type="text" id="name" name="name" class="px" size="36" tabindex="1" value="$_G[forum][name]" autocomplete="off" tabindex="1" />
						</div>
					</li>
				<!--{/if}-->
				<!--{if !empty($specialswitch['allowchangetype']) && ($_G['uid'] == $_G['forum']['founderuid'] || $_G['adminid'] == 1)}-->
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{lang group_category}<span class="rq"> *</span></div>
						<div class="ren_hdxx_lxnr ren-webki">
							<select name="parentid" tabindex="2" class="ps" onchange="ajaxget('forum.php?mod=ajax&action=secondgroup&fupid='+ this.value, 'secondgroup');">
								<option value="0">{lang choose_please}</option>
								$groupselect[first]
							</select>
							<em id="secondgroup" class="secondgroup"><!--{if $groupselect['second']}--><select id="fup" name="fup" class="ps" >$groupselect[second]</select><!--{/if}--></em>
						</div>
					</li>
				<!--{/if}-->
			
					<li class="ren_hdxx_li ren_hdxx_he">
						<div class="ren_hdxx_lx">{lang group_description}<span class="rq"> *</span></div>
						<div class="ren_hdxx_lxnr">
							<textarea id="descriptionmessage" name="descriptionnew" class="pt" rows="3">$_G[forum][descriptionnew]</textarea>
						</div>
					</li>
					
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{lang group_perm_visit}</div>
						<div class="ren_hdxx_lxnr">
							<label class="lb"><input type="radio" name="gviewpermnew" class="pr" value="1" $gviewpermselect[1] />{lang group_perm_all_user}</label>
							<label class="lb"><input type="radio" name="gviewpermnew" class="pr" value="0" $gviewpermselect[0] />{lang group_perm_member_only}</label>
						</div>
					</li>
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{lang group_join_type}</div>
						<div class="ren_hdxx_lxnr ren-mange">
							<label class="lb"><input type="radio" name="jointypenew" class="pr" value="0" $jointypeselect[0] />{lang group_join_type_free}</label>
							<label class="lb"><input type="radio" name="jointypenew" class="pr" value="2" $jointypeselect[2] />{lang group_join_type_moderate}</label>
							<label class="lb"><input type="radio" name="jointypenew" class="pr" value="1" $jointypeselect[1] />{lang group_join_type_invite}</label>
							<!--{if !empty($specialswitch['allowclosegroup'])}-->
							<label class="lb"><input type="radio" name="jointypenew" class="pr" value="-1" $jointypeselect[-1] />{lang close}</label>
							<!--{/if}-->
						</div>
					</li>
					<!--{if !empty($_G['group']['allowupbanner']) || $_G['adminid'] == 1}-->
					<li class="ren_hdxx_li ren_hdxx_me">
						<div class="ren_hdxx_lx">{$rtj1009_lang['group021']}</div>
						<div class="ren_hdxx_lxnr">
							  <div class="ren_flpost_img cl">
                                  <a href="javascript:;" class="ren_bl_fjy">
                                      <input type="file" name="bannernew" id="bannernew" onchange="$('#inbannernew').css('display','block');popup.open('{lang uploadstatusmsg0}', 'alert');" class="pf" size="25" />
                                      <em>{$rtj1009_lang['ren068']}</em>
                                  </a>
                                  <i id="inbannernew" class="icon ren-font" style="display: none;">&#xe669;</i>
							  </div>
							  <div class="ren_flpost_pic">
                                  <!--{if $_G['forum']['banner']}-->
                                    <a href="$_G[forum][banner]?{TIMESTAMP}">
                                        <img src="$_G[forum][banner]?{TIMESTAMP}" />
                                    </a>
                                  <!--{/if}-->
                     		 </div>
						</div>
					</li>
					<!--{/if}-->
					
					<li class="ren_hdxx_li ren_hdxx_me">
						<div class="ren_hdxx_lx">{lang group_icon}</div>
						<div class="ren_hdxx_lxnr">
							  <div class="ren_flpost_img cl">
								  <a href="javascript:;" class="ren_bl_fjy">
									  <input type="file" id="iconnew" onchange="$('#iniconnew').css('display','block');popup.open('{lang uploadstatusmsg0}', 'alert');" class="pf vm" size="25" name="iconnew" />
									  <em>{$rtj1009_lang['ren068']}</em>
								  </a>
                                  <i id="iniconnew" class="icon ren-font" style="display: none;">&#xe669;</i>
							  </div>
							  <div class="ren_flpost_pic ren-icon-mana">
                                  <!--{if $_G['forum']['icon']}-->
                                    <a href="$_G[forum][icon]?{TIMESTAMP}">
                                        <img class="vm" src="$_G[forum][icon]?{TIMESTAMP}" />
                                    </a>
                                  <!--{/if}-->
                     		 </div>
						</div>
					</li>
					
				</ul>
			</div>
		</div>
		<span class="ren_ft_anniu">
			<button type="submit" name="groupmanage" class="ren_ft_an" value="1">{lang submit}</button>
		</span>
		</form>
	</div>
<!--{elseif $_GET['op'] == 'checkuser'}-->
	<!--{if $checkusers}-->
		<ul class="ren-friend-re cl">
		<!--{loop $checkusers $uid $user}-->
			<li>
				<div class="ren-list-usxx">
					<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="ren-us-img z">
						<!--{echo avatar($user[uid], 'small')}-->
					</a>
					<div class="z ren-us-name">
						<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="z">$user[username]</a>
					</div>
					<div class="z ren-us-dateline">
						<span class="info_label">{$user['joindateline']}</span>
					</div>
					<div class="y ren-friend-in">
						<a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=1" id="fbkname_$fuser['followuid']" class="z dialog">{lang pass}</a>
						<a href="forum.php?mod=group&action=manage&op=checkuser&fid=$_G[fid]&uid=$user[uid]&checktype=2" class="dialog tu z">{lang ignore}</a>
					</div>
				</div>
			</li>
		<!--{/loop}-->
		</ul>
		<!--{if $multipage}--><div class="pgs cl mtm">$multipage</div><!--{/if}-->
	<!--{else}-->
		<div class="ren_ss_wu ren-manage-wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{lang group_no_member_moderated}</span>
		</div>
	<!--{/if}-->
<!--{elseif $_GET['op'] == 'manageuser'}-->
	<script type="text/javascript">
		function groupManageUser(targetlevel_val) {
		  document.getElementById('targetlevel').value = targetlevel_val;
		  document.getElementById('manageuser').submit();
		}
	</script>
	<!--{if $_G['forum']['membernum'] > 50}-->
	<div class="bm_c pns">
		<form action="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]" method="post">
		<input type="text" {if empty($_GET['srchuser'])}onclick="$('groupsearch').value=''"{/if} value="{if $_GET['srchuser']}$_GET[srchuser]{else}{lang enter_member_user}{/if}" size="15" class="px p_fre vm" id="groupsearch" name="srchuser">&nbsp;
		<button class="pn vm" type="submit"><span>{lang search}</span></button>
		</form>
	</div>
	<!--{/if}-->
	<form action="forum.php?mod=group&action=manage&op=manageuser&fid=$_G[fid]&manageuser=true" name="manageuser" id="manageuser" method="post" autocomplete="off" class="ptm">
		<input type="hidden" value="{FORMHASH}" name="formhash" />
        <input type="hidden" value="0" name="targetlevel" id="targetlevel" />
			<!--{if $adminuserlist}-->
			<div class="ren-group-mem">
				<div class="ren_m_mkbt">
					<span>{lang group_admin_member}</span>
				</div>
				<ul class="ren-friend-re cl">
				<!--{loop $adminuserlist $user}-->
					<li>
						<!--{if $_G['adminid'] == 1 || ($_G['uid'] != $user['uid'] && ($_G['uid'] == $_G['forum']['founderuid'] || $user['level'] > $groupuser['level']))}--><div class="z ren-mana-inp"><input type="checkbox" class="pc" name="muid[{$user[uid]}]" value="$user[level]" /></div><!--{/if}-->
						<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="ren-list-usxx">
							<div class="ren-us-img z">
								<!--{echo avatar($user[uid], 'small')}-->
							</div>
							<div class="z ren-us-name tu">
								<div class="z ren-mana-name">$user[username]<span>{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}</span></div>
							</div>
						</a>
					</li>
				<!--{/loop}-->
				</ul>
			</div>
		<!--{/if}-->
		
		<!--{if $staruserlist || $userlist}-->
			<div class="ren-group-mem">
				<div class="ren_m_mkbt">
					<span>$_G[setting][navs][3][navname]{lang member}</span>
				</div>
				<!--{if $staruserlist}-->
				<ul class="ren-friend-re cl">
				<!--{loop $staruserlist $user}-->
					<li>
						<!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}--><div class="z ren-mana-inp"><input type="checkbox" class="pc" name="muid[{$user[uid]}]" value="$user[level]" /></div><!--{/if}-->
						<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="ren-list-usxx">
							<div class="ren-us-img z">
								<!--{echo avatar($user[uid], 'small')}-->
							</div>
							<div class="z ren-us-name">
								<div class="z ren-memb-name">$user[username]</div>
							</div>
							<div class="z ren-us-dateline">
								<span class="info_label">{$rtj1009_lang['group016']}<!--{echo date('Y-m-d', $user['joindateline'])}--></span>
							</div>
						</a>
					</li>
				<!--{/loop}-->
				</ul>
				<!--{/if}-->
				<!--{if $userlist}-->
				<ul class="ren-friend-re cl">
				<!--{loop $userlist $user}-->
					<li>
						<!--{if $_G['adminid'] == 1 || $user['level'] > $groupuser['level']}--><div class="z ren-mana-inp"><input type="checkbox" class="pc" name="muid[{$user[uid]}]" value="$user[level]" /></div><!--{/if}-->
						<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="ren-list-usxx">
							<div class="ren-us-img z">
								<!--{echo avatar($user[uid], 'small')}-->
							</div>
							<div class="z ren-us-name">
								<div class="z ren-memb-name">$user[username]</div>
							</div>
							<div class="z ren-us-dateline">
								<span class="info_label">{$rtj1009_lang['group016']}<!--{echo date('Y-m-d', $user['joindateline'])}--></span>
							</div>
						</a>
					</li>
				<!--{/loop}-->
				</ul>
				<!--{/if}-->
			</div>
		<!--{/if}-->
		<!--{if $multipage}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
		<div class="rtj1009-nav-swiper ren-manageuser-list">
			<div class="swiper-container2">
			  <ul class="swiper-wrapper">
				<!--{loop $mtype $key $name}-->
				<!--{if $_G['forum']['founderuid'] == $_G['uid'] || $key > $groupuser['level'] || $_G['adminid'] == 1}-->
				<li class="swiper-slide"><button type="button" name="manageuser" value="true" class="pn" onclick="groupManageUser('{$key}')"><span>$name</span></button></li>
				<!--{/if}-->
				<!--{/loop}-->
			  </ul>
			</div>
		</div>
	</form>
<!--{elseif $_GET['op'] == 'threadtype'}-->
	<div class="bm bw0">
		<!--{if empty($specialswitch['allowthreadtype'])}-->
			{lang group_level_cannot_do}
		<!--{else}-->
		<script type="text/JavaScript">
			var rowtypedata = [
				[
					[1,'<input type="checkbox" class="pc" disabled="disabled" />', ''],
					[1,'<input type="checkbox" class="pc" name="newenable[]" checked="checked" value="1" />', ''],
					[1,'<input class="px" type="text" size="2" name="newdisplayorder[]" value="0" />'],
					[1,'<input class="px" type="text" name="newname[]" />']
				],
			];
			var addrowdirect = 0;
			var typenumlimit = $typenumlimit;
			function addrow(obj, type) {
				var table = obj.parentNode.parentNode.parentNode.parentNode;
				if(typenumlimit <= obj.parentNode.parentNode.parentNode.rowIndex - 1) {
					alert('{lang group_threadtype_limit_1}'+typenumlimit+'{lang group_threadtype_limit_2}');
					return false;
				}
				if(!addrowdirect) {
					var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
				} else {
					var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex + 1);
				}

				var typedata = rowtypedata[type];
				for(var i = 0; i <= typedata.length - 1; i++) {
					var cell = row.insertCell(i);
					cell.colSpan = typedata[i][0];
					var tmp = typedata[i][1];
					if(typedata[i][2]) {
						cell.className = typedata[i][2];
					}
					tmp = tmp.replace(/\{(\d+)\}/g, function($1, $2) {return addrow.arguments[parseInt($2) + 1];});
					cell.innerHTML = tmp;
				}
				addrowdirect = 0;
			}
		</script>
		<div id="threadtypes">
			<form id="threadtypeform" action="forum.php?mod=group&action=manage&op=threadtype&fid=$_G[fid]" autocomplete="off" method="post" name="threadtypeform">
				<input type="hidden" value="{FORMHASH}" name="formhash" />
				<table cellspacing="0" cellpadding="0" class="tfm vt">
					<tr>
						<th>{lang threadtype_turn_on}:</th>
						<td>
							<label class="lb"><input type="radio" name="threadtypesnew[status]" class="pr" value="1" onclick="$('threadtypes_config').style.display = '';$('threadtypes_manage').style.display = '';" $checkeds[status][1] />{lang yes}</label>
							<label class="lb"><input type="radio" name="threadtypesnew[status]" class="pr" value="0" onclick="$('threadtypes_config').style.display = 'none';$('threadtypes_manage').style.display = 'none';"  $checkeds[status][0] />{lang no}</label>
							<p class="d">{lang threadtype_turn_on_comment}</p>
						</td>
					</tr>
					<tbody id="threadtypes_config" style="display: $display">
						<tr>
							<th>{lang threadtype_required}:</th>
							<td>
								<label class="lb"><input type="radio" name="threadtypesnew[required]" class="pr" value="1" $checkeds[required][1] />{lang yes}</label>
								<label class="lb"><input type="radio" name="threadtypesnew[required]" class="pr" value="0" $checkeds[required][0] />{lang no}</label>
								<p class="d">{lang threadtype_required_force}</p>
							</td>
						</tr>
						<tr>
							<th>{lang threadtype_prefix}:</th>
							<td>
								<label class="lb"><input type="radio" name="threadtypesnew[prefix]" class="pr" value="0" $checkeds[prefix][0] />{lang threadtype_prefix_off}</label>
								<label class="lb"><input type="radio" name="threadtypesnew[prefix]" class="pr" value="1" $checkeds[prefix][1] />{lang threadtype_prefix_on}</label>
								<p class="d">{lang threadtype_prefix_comment}</p>
							</td>
						</tr>
					</tbody>
				</table>
				<div id="threadtypes_manage" style="display: $display">
					<h2 class="ptm pbm">{lang threadtype}</h2>
					<table cellspacing="0" cellpadding="0" class="dt">
						<thead>
							<tr>
								<th width="25">{lang delete}</th>
								<th>{lang enable}</th>
								<th>{lang displayorder}</th>
								<th>{lang threadtype_name}</th>
							</tr>
						</thead>
						<!--{if $threadtypes}-->
							<!--{loop $threadtypes $val}-->
							<tbody>
								<tr>
									<td><input type="checkbox" class="pc" name="threadtypesnew[options][delete][]" value="{$val[typeid]}" /></td>
									<td><input type="checkbox" class="pc" name="threadtypesnew[options][enable][{$val[typeid]}]" value="1" class="pc" $val[enablechecked] /></td>
									<td><input type="text" name="threadtypesnew[options][displayorder][{$val[typeid]}]" class="px" size="2" value="$val[displayorder]" /></td>
									<td><input type="text" name="threadtypesnew[options][name][{$val[typeid]}]" class="px" value="$val[name]" /></td>
								</tr>
							</tbody>
							<!--{/loop}-->
						<!--{/if}-->
						<tr>
							<td colspan="4"><img class="vm" src="{IMGDIR}/addicn.gif" /> <a href="javascript:;" onclick="addrow(this, 0)">{lang threadtype_add}</a></td>
						</tr>
					</table>
				</div>
				<button type="submit" class="pn pnc mtm" name="groupthreadtype" value="1"><strong>{lang submit}</strong></button>
			</form>
		</div>
		<!--{/if}-->
	</div>
<!--{elseif $_GET['op'] == 'demise'}-->
		<!--{if $groupmanagers}-->
			<div class="ren_mm_top ren-demise-ts cl">
				<span class="ren_mm_xgts">{$rtj1009_lang['group022']}</div>
			</div>
			<form action="forum.php?mod=group&action=manage&op=demise&fid=$_G[fid]" name="groupdemise" method="post" class="exfm">
				<input type="hidden" value="{FORMHASH}" name="formhash" />
				<div class="ren-group-mem">
					<div class="ren_m_mkbt">
						<span>{lang transfer_group_to}</span>
					</div>
					<ul class="ren-friend-re cl">
					<!--{loop $groupmanagers $user}-->
						<li>
							<div class="z ren-mana-inp"><!--{if $user['uid'] != $_G['uid']}--><input type="radio" class="pc" name="suid" value="$user[uid]" /><!--{/if}--></div>
							<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="ren-list-usxx">
								<div class="ren-us-img z">
									<!--{echo avatar($user[uid], 'small')}-->
								</div>
								<div class="z ren-us-name tu">
									<div class="z ren-mana-name">$user[username]</div>
								</div>
							</a>
						</li>
					<!--{/loop}-->
					</ul>
				</div>
				<div class="rtj1009_post ren-manage-post cl">
					<div class="ren_fb_hd ren-create cl">
						<ul>
							<li class="ren_hdxx_li ren_hdxx_de">
								<div class="ren_hdxx_lx">{lang group_input_password}<span class="rq"> *</span></div>
								<div class="ren_hdxx_lxnr">
								   <input type="password" name="grouppwd" class="px p_fre" />
								</div>
							</li>
						</ul>
					</div>
				<span class="ren_ft_anniu">
					<button type="submit" name="groupdemise" class="ren_ft_an" value="1">{lang submit}</button>
				</span>
				</div>
			</form>
		<!--{else}-->
		<div class="ren_ss_wu ren-manage-wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{lang group_no_admin_member}</span>
		</div>
		<!--{/if}-->
<!--{/if}-->