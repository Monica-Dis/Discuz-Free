<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header<!--{if $action != 'create'}--> ren-menu-header<!--{/if}-->">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<!--{if $action != 'create'}-->
		<div class="ren_top_grkj ren-group-hd z">
			<span class="ren_bk_name ren_vm">$_G[forum][name]</span>
		</div>
		<!--{else}-->
		<div class="ren_top_dqwz z">
			<span class="ren_bk_name">{$rtj1009_lang['group009']}$_G[setting][navs][3][navname]</span>
		</div>
		<!--{/if}-->
		<!--{if $action != 'create'}-->
		<div class="ren_nav_right">
            <div class="ren_view_navgd open-popover"><span class="icon ren-font">&#xe677;</span></div>
        </div>
		<!--{/if}-->
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="ren_nav_gd popover">
	<div class="popover-angle on-top"></div>
	<div class="ren_gd_list close-popover cl">
		<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="ren_gd_jb"><i class="icon ren-font">&#xe619;</i><span>{$rtj1009_lang['group010']}</a>
		<a href="search.php?mod=group" class="ren_gd_jb"><i class="icon ren-font">&#xe68d;</i><span>{$rtj1009_lang['group011']}$_G[setting][navs][3][navname]</a>
		<a href="group.php" class="ren_gd_fh"><i class="icon ren-font">&#xe60c;</i><span>$_G[setting][navs][3][navname]{$rtj1009_lang['group012']}</span></a>
	</div>
</div>


<div class="content<!--{if $action != 'create'}--> p-t-0<!--{/if}--> ren-group-index">
<!--{if $action != 'create'}-->
<div id="rtj1009_mn_u" class="rtj1009_menu">
    <div class="rtj1009_menu_nv" style="<!--{if $_G[forum][banner]}-->background-image:url($_G[forum][banner]) !important;<!--{/if}-->background-repeat:no-repeat;background-position:center;">
        <div class="z ren-menu cl">
            <div class="ren-menu-avatar"><img src="$_G[forum][icon]" alt="$_G[forum][name]" /></div>
        </div>
		
         <div class="ren-menu-item">
			 <div class="ren-menu-name">
				 <span>$_G[forum][name]</span>
			 </div>
			<!--{if helper_access::check_module('follow')}-->
			<div class="ren-menu-follow">
				<span class="info_label">{lang posts}</span><span class="info_value">$_G[forum][posts]</span>
				<span class="ren-menu-shu">|</span>
				<span class="info_label">{lang member}</span><span class="info_value">$_G[forum][membernum]</span>
				<span class="ren-menu-shu">|</span>
				<span class="info_label">{lang group_member_rank}</span><span class="info_value">$groupcache[ranking][data][today]</span>
			</div>
			<!--{/if}-->
			<div class="ren_us_xy">
				<!--{if $status == 'isgroupuser'}-->
				<a href="forum.php?mod=group&action=out&fid=$_G[fid]" class="ren_us_zc<!--{if $_G[uid]}--> dialog<!--{else}--> ren-confirm<!--{/if}-->"><span class="icon ren-font">&#xe617;</span>{$rtj1009_lang['group013']}</a>
				<!--{else}-->
				<a href="forum.php?mod=group&action=join&fid={$_G[forum][fid]}" class="ren_us_zc<!--{if $_G[uid]}--> dialog<!--{else}--> ren-confirm<!--{/if}-->"><span class="icon ren-font">&#xe60d;</span>{$rtj1009_lang['group014']}</a>
				<!--{/if}-->
				<!--{eval $ren_forum_gz = DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='gid' and id=".$_G['fid']."");}-->
				<!--{if $ren_forum_gz[id]}-->
					<a href="home.php?mod=spacecp&ac=favorite&op=delete&favid={$ren_forum_gz[favid]}&type=forum&formhash={FORMHASH}" class="ren_us_dl<!--{if $_G[uid]}--> dialog<!--{else}--> ren-confirm<!--{/if}-->"><span class="icon ren-font">&#xe603;</span>{$rtj1009_lang['group015']}</a>
				<!--{else}-->
					<a id="a_favorite" href="home.php?mod=spacecp&ac=favorite&type=group&id={$_G[forum][fid]}&handlekey=sharealbumhk_{$_G[forum][fid]}&formhash={FORMHASH}" class="ren_us_dl<!--{if $_G[uid]}--> dialog<!--{else}--> ren-confirm<!--{/if}-->"><span class="icon ren-font">&#xe603;</span>{lang favorite}</a>
				<!--{/if}-->
			</div>
         </div>
    </div>
	<!--{if $status != 2 && $status != 3}-->
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
			<a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]#groupnav" {if $action == 'list'}class="a"{/if}>{lang group_discuss_area}</a>
			<a href="forum.php?mod=group&action=memberlist&fid=$_G[fid]#groupnav" {if $action == 'memberlist' || $action == 'invite'}class="a"{/if}>{lang group_member_list}</a>
			<!--{if $_G['forum']['ismoderator']}--><a href="forum.php?mod=group&action=manage&fid=$_G[fid]" {if $action == 'manage'}class="a"{/if}>{lang group_admin}</a><!--{/if}-->
		</div>
	</div>
	<!--{/if}-->
    <!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/rtj1009_list.php';}-->
			<!--{/if}-->
			<!--{if $action == 'index' && $status != 2 && $status != 3}-->
				<!--{subtemplate group/group_index}-->
			<!--{elseif $action == 'list'}-->
			<!--{if $_G['forum']['threadtypes']}-->
			<ul class="ren-notice-xnav">
					<li id="ttp_all"{if !$_GET['typeid']} class="a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]">{lang forum_viewall}</a></li>
					<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
					<li{if $_GET['typeid'] == $id} class="a"{/if}><a href="forum.php?mod=forumdisplay&action=list&fid=$_G[fid]{if $_GET['typeid'] != $id}&filter=typeid&typeid=$id$forumdisplayadd[typeid]{/if}">$name</a>
					<!--{/loop}-->
			</ul>
			<!--{/if}-->
			<!--{if empty($_G['forum']['sortmode'])}-->
				<!--{if $_G['forum_threadcount']}-->
					<div class="ren_zd cl">
						<ul style="height: 119px;">
						<!--{loop $_G['forum_threadlist'] $key $thread}-->
								<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
								<li>
								<!--{hook/forumdisplay_thread_mobile $key}-->
									<span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
									<a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight]>{$thread[subject]}</a>
								</li>
							<!--{/if}-->
						<!--{/loop}-->
						</ul>
						<a href="javascript:void(0)" class="ren_zd_btn">{$rtj1009_lang[ren034]}<span class="icon ren-font">&#xe60a;</span></a>
					</div>
				<!--{/if}-->
			<!--{/if}-->
			<div id="ren_tie_list" class="ren_tie_list rtj1009_m_main cl">
				<div class="<!--{if $rtj1009_list_style['style'] == 1 || $rtj1009_list_style['style'] ==7}-->ren_list_yi<!--{elseif $rtj1009_list_style['style'] == 2}-->ren_list_e<!--{elseif $rtj1009_list_style['style'] == 3}-->ren_list_san<!--{elseif $rtj1009_list_style['style'] == 4}-->ren_list_si<!--{elseif $rtj1009_list_style['style'] == 5}-->ren_list_wu<!--{elseif $rtj1009_list_style['style'] == 6}-->ren_list_liu<!--{/if}--> cl">
				    <ul class="ren_list cl">
					<!--{if $_G['forum_threadcount']}-->
                        <!--{eval
                            include_once libfile('function/post');
                            include_once libfile('function/attachment');
                        }-->
						<!--{loop $_G['forum_threadlist'] $key $thread}-->
							<!--{if !$_G['setting']['mobile']['mobiledisplayorder3'] && $thread['displayorder'] > 0}-->
								{eval continue;}
							<!--{/if}-->
							<!--{if $thread['displayorder'] > 0 && !$displayorder_thread}-->
								{eval $displayorder_thread = 1;}
							<!--{/if}-->
							<!--{if $thread['moved']}-->
								<!--{eval $thread[tid]=$thread[closed];}-->
							<!--{/if}-->
							<!--{if !$rtj1009_m_config['ren_m_forum_tst'] == 1}-->
								<!--{subtemplate rtj1009_core/ren_forum_list}-->
							<!--{else}-->
								<!--{if !$thread['displayorder']}-->
									<!--{subtemplate rtj1009_core/ren_forum_list}-->
								<!--{/if}-->
							<!--{/if}-->
						<!--{/loop}-->
					<!--{else}-->
					<li class="ren_ss_wu">
						<i class="icon ren-font">&#xe608;</i>
						<span>{lang forum_nothreads}</span>
					</li>
					<!--{/if}-->
					</ul>
				</div>
			</div>
			$multipage
			<!--{elseif $action == 'memberlist'}-->
				<!--{subtemplate group/group_memberlist}-->
			<!--{elseif $action == 'create'}-->
				<!--{subtemplate group/group_create}-->
			<!--{elseif $action == 'invite'}-->
				<!--{subtemplate group/group_invite}-->
			<!--{elseif $action == 'manage'}-->
				<!--{subtemplate group/group_manage}-->
			<!--{/if}-->
	</div>
<script type="text/javascript">
	var zdList= $(".ren_zd li").length;
	if(zdList==0){
		$(".ren_zd").css({
			"display":"none"
		})
	}
	if(zdList<4){
		$(".ren_zd .ren_zd_btn").css({
			"display":"none"
		})
	}
	if(zdList<=3){
		$(".ren_zd ul").css({
			"height":"auto"
		})
	}
	$(".ren_zd_btn").click(function(){
		if($(this).hasClass("sq")){
			$(this).html('{$rtj1009_lang[ren034]}<span class="icon ren-font">&#xe60a;</span>');
			$(this).removeClass("sq");
			$(this).siblings("ul").css({"height":"118px"});
		}else{
			$(this).html('{$rtj1009_lang[ren035]}<span class="icon ren-font">&#xe606;</span>');
			$(this).addClass("sq");
			$(this).siblings("ul").css({"height":"auto"});
		}
	})
</script>
	
<script type="text/javascript">  
$(function(){  
	var nav=$(".rtj1009_header");
	var ren_top_grkj=$(".ren_top_grkj");
	var win=$(window);
	var sc=$(document);
	win.scroll(function(){  
	  if(sc.scrollTop()>=110){  
		nav.removeClass("ren-menu-header");
		ren_top_grkj.removeClass("ren-group-hd"); 
	   $(".navTmp").fadeIn();   
	  }else{  
	   nav.addClass("ren-menu-header");  
	   ren_top_grkj.addClass("ren-group-hd"); 
	   $(".navTmp").fadeOut();  
	  }  
	})    
})  
</script> 

<!--{template common/footer}-->