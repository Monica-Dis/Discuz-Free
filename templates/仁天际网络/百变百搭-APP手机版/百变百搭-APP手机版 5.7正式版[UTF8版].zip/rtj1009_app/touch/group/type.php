<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span class="ren_bk_name">$_G[setting][navs][3][navname]</span>
		</div>
		<div class="y ren_list_nav">
            <a href="forum.php?mod=group&action=create" class="ren-nav-group">{$rtj1009_lang['group001']}</a>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content ren-group">
	<div class="rtj1009_m_forum ren-home-slide-e">
        <div class="ren_fenpinglist cl">
            <div class="menu-left scrollbar-none" id="sidebar"<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}--> style="top: 45px;"<!--{/if}-->>
                <ul>
                    <!--{loop $first $groupid $group}-->
                    <li id="tab$group[fid]" class="<!--{if $group[fid] == $_GET[gid]}-->active <!--{/if}-->groupid"><a href="group.php?gid=$group[fid]">$group[name]</a></li>
                    <!--{if $rtj1009_mobilecp['ren_group_sfid']}-->
                        <!--{loop $group['secondlist'] $fid}-->
                        <li id="tab$group[$fid][fid]" class="<!--{if $second[$fid][fid] == $_GET[sgid]}-->active <!--{/if}-->sfid"><a href="group.php?sgid=$second[$fid][fid]">$second[$fid][name]</a></li>
                        <!--{/loop}-->
                    <!--{/if}-->
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="menu-right padding-all j-content" style="display: block;<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}--> top: 45px;<!--{/if}-->">
                <!--{if $list}-->
                <ul class="cl">
                    <!--{loop $list $fid $val}-->
                    <!--{eval $groupsub = DB::fetch_first("SELECT * FROM ".DB::table("forum_forumfield")." WHERE `fid` = $val[fid]");}-->
                    <!--{eval $groupsubshu = DB::fetch_first("SELECT * FROM ".DB::table("forum_forum")." WHERE `fid` = $val[fid]");}-->
                    <!--{eval $statusxx = DB::fetch_first("SELECT * FROM  ".DB::table('forum_groupuser')." WHERE  uid=".$_G[uid]." and fid=".$val['fid']."");}-->
                    <li <!--{if $statusxx}-->class="statusxxli"<!--{/if}-->>
                        <a href="forum.php?mod=forumdisplay&action=list&fid={$val['fid']}"><img src="<!--{if $groupsub['icon']}-->data/attachment/group/$groupsub['icon']<!--{else}-->static/image/common/groupicon.gif<!--{/if}-->" alt="$val[name]" /></a>
                        <a href="forum.php?mod=forumdisplay&action=list&fid={$val['fid']}" class="ren_bkbt">
                            <span>{$val[name]}</span>
                            <em>{$rtj1009_lang['group005']}$groupsub[membernum]</em>
                            <em>{$rtj1009_lang['ren042']}$groupsubshu[threads]</em>
                        </a>
                        <!--{if !$statusxx}-->
                            <a href="forum.php?mod=group&action=join&fid=$val[fid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_bklist_gz">{$rtj1009_lang['group003']}</a>
                        <!--{/if}-->
                    </li>
                <!--{/loop}-->
                </ul>
                <!--{else}-->
                <div class="ren_ss_wu">
                    <i class="icon ren-font">&#xe608;</i>
                    <span>{$rtj1009_lang['group004']}$_G[setting][navs][3][navname]</span>
                </div>
                <!--{/if}-->
                <!--{if $list}-->
                <div class="pgs cl">
                    $multipage
                </div>
                <!--{/if}-->
            </div>
		</div>
	</div>
</div>


<!--{template common/footer}-->