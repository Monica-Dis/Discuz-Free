<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<script>window.location.href = 'forum.php?mod=forumdisplay&action=list&fid={$_GET['fid']}'</script>