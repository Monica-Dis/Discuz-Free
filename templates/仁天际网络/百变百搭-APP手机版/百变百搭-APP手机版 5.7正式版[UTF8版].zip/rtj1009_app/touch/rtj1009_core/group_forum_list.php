<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<li>
<!--{eval 
$groupthread = DB::result(DB::query("SELECT author FROM ".DB::table('forum_thread')." WHERE tid = '$tid'"));
$groupauthorid = DB::result(DB::query("SELECT authorid FROM ".DB::table('forum_thread')." WHERE tid = '$tid'"));
$isfollowuid = DB::result_first("SELECT followuid FROM ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$groupauthorid");
}-->
<!--{eval $threadlistimg = DB::fetch_all('SELECT * FROM '.DB::table('forum_attachment').' WHERE tid = '.$tid.' LIMIT  0 ,'. 3 );}-->
		<div class="ren_twsj">
			<a class="ren_twus_img z cl" href="home.php?mod=space&uid=$groupauthorid&do=profile">
				<!--{avatar($groupauthorid,middle)}-->
			</a>				
			<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$groupauthorid&do=profile">{$groupthread}</a>
			<div class="y">
				<!--{if !$isfollowuid}-->
				<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_zz_gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$groupauthorid">{$rtj1009_lang['ren022']}</a>
				<!--{else}-->
				<a class="dialog ren_qxgz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$groupauthorid">{$rtj1009_lang['ren031']}</a>
				<!--{/if}-->
			</div>
		</div>
		<div class="ren_twbt">
				<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
					<span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
				<!--{elseif $thread['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
			<!--{if !$_G[forum_thread][special]}-->
				{if $thread['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
				{if $thread['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
				{if $thread['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
				{if $thread['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
				{if $thread['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
			<!--{/if}-->
	
			<a href="forum.php?mod=viewthread&tid=$tid" $thread[highlight]>{$thread[subject]}</a>
		 </div>
		<!--{if $threadlistimg}-->
		<div class="ren_threadimg">
			<a href="forum.php?mod=viewthread&tid=$tid">
				<!--{loop $threadlistimg $values}-->
				<!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
					<span class="ren_thread_imgsan ren_thread_img"><img src="$renlistimgkey"/></span>
				<!--{/loop}-->
			</a>
		</div>
		<!--{/if}-->
		<a href="forum.php?mod=viewthread&tid=$tid" class="ren_twsj_xx" >
			<span class="ren_twsj_sj z"><i class="icon ren-font">&#xe61c;</i>$thread[lastpost]</span>
			<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
			<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
		</a>
	</li>