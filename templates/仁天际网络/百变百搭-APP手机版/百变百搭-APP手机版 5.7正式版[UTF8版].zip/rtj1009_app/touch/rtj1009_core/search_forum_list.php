<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
include_once libfile('function/post');
include_once libfile('function/attachment');
}-->
<!--{loop $threadlist $thread}-->
<!--{eval
	$thread['post'] = C::t('forum_post')->fetch_all_by_tid_position($thread['posttableid'],$thread['tid'],1);
	$thread['post'] = array_shift($thread['post']);
	$ren_pic = C::t('forum_attachment_n')->count_image_by_id('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid']);
	$forumname = DB::result_first("SELECT name FROM ".DB::table("forum_forum")." WHERE `fid` = $thread[fid]");
	$shustars =DB::result_first("SELECT b.stars FROM ".DB::table("common_member")." a LEFT JOIN ".DB::table("common_usergroup")." b on b.groupid=a.groupid where a.`uid` = '$thread[authorid]' AND b.`allowvisit` > 0");
	$imgurlx = rtj1009_imgurl($thread['post']['message']);
	$rtj1009_msg = rtj1009_msg($thread['post']['message']);
	$vediourlx = rtj1009_vedio_url($thread['post']['message']);
}-->

<!--{if $ren_pic <=2}--><!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid'], 1);}--><!--{/if}-->
<!--{if $ren_pic >=3}--><!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid'], 3);}--><!--{/if}-->
<!--{if $ren_pic <=2}-->
	<li>
		<div class="ren_twsj">
			<a class="ren_twus_img z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">
				<!--{avatar($thread[authorid],middle)}-->
			</a>
			<!--{if $thread['authorid'] && $thread['author']}-->
			<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
			<!--{else}-->
				$_G[setting][anonymoustext]
			<!--{/if}-->
			<!--{if $rtj1009_m_config['ren_m_forum_xing'] == 1}-->
			<span class="ren_us_xing">Lv.$shustars[stars]</span>
			<!--{/if}-->
			<!--{if $rtj1009_m_config['ren_m_forum_verify'] == 1}--><span class="verify"><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}--></span><!--{/if}-->
			<div class="y">
				<div class="y ren-p-fname">
					<a href="forum.php?mod=forumdisplay&fid=$thread[fid]">#{$forumname}#</a>
				</div>
			</div>
		</div>
		<div class="ren_tw_yiimg">
            <!--{if ($threadlistimg || $imgurlx) && !$vediourlx}-->
            <!--{if $threadlistimg}-->
            <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_threadimg y">
                <!--{if $ren_pic <=2}-->
                <!--{loop $threadlistimg $values}-->
                <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
                <span class="ren_thread_imge ren_thread_img"><img src="$renlistimgkey" /></span>
                <!--{/loop}-->
                <!--{/if}-->
            </a>
            <!--{elseif $imgurlx}-->
            <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_threadimg imgurltu y">
                <!--{eval echo $imgurlx;}-->
            </a>
            <!--{/if}-->
            <!--{/if}-->
			<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_tw_yi<!--{if ($ren_pic || $imgurlx) && !$vediourlx}--> tw-tu<!--{/if}-->">
				<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				<!--{if !$rtj1009_m_config['ren_m_forum_tst']}-->
					<span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
				<!--{/if}-->
				<!--{elseif $thread['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
				<!--{if !$_G[forum_thread][special]}-->
					{if $thread['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
					{if $thread['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
					{if $thread['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
					{if $thread['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
					{if $thread['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
				<!--{/if}-->

				<span $thread[highlight]>{$thread[subject]}</span>
			 </a>
		 </div>
        <!--{if $rtj1009_m_config['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
		<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_twsj_xx" >
			<span class="ren_twsj_sj z"><i class="icon ren-font">&#xe61c;</i>{$thread[dateline]}</span>
			<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
			<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
		</a>
	</li>
<!--{else}-->
	<li>
		<div class="ren_twsj">
			<a class="ren_twus_img z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">
				<!--{avatar($thread[authorid],middle)}-->
			</a>
			<!--{if $thread['authorid'] && $thread['author']}-->
			<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
			<!--{else}-->
				$_G[setting][anonymoustext]
			<!--{/if}-->
			<!--{if $rtj1009_m_config['ren_m_forum_xing'] == 1}-->
			<span class="ren_us_xing">Lv.$shustars[stars]</span>
			<!--{/if}-->
			<!--{if $rtj1009_m_config['ren_m_forum_verify'] == 1}--><span class="verify"><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}--></span><!--{/if}-->
			<div class="y">
				<div class="y ren-p-fname">
					<a href="forum.php?mod=forumdisplay&fid=$thread[fid]">#{$forumname}#</a>
				</div>
			</div>
		</div>
		<div class="ren_twbt">
			<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				<!--{if !$rtj1009_m_config['ren_m_forum_tst']}-->
					<span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
				<!--{/if}-->
				<!--{elseif $thread['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
			<!--{if !$_G[forum_thread][special]}-->
				{if $thread['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
				{if $thread['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
				{if $thread['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
				{if $thread['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
				{if $thread['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
			<!--{/if}-->
	
			<a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight]>{$thread[subject]}</a>
		 </div>
		<!--{if $threadlistimg}-->
		<div class="ren_threadimg">
			<a href="forum.php?mod=viewthread&tid=$thread[tid]">
				<!--{if $ren_pic >=3}-->
				<!--{loop $threadlistimg $values}-->
				<!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
					<span class="ren_thread_imgsan ren_thread_img"><img src="$renlistimgkey"/></span>
				<!--{/loop}-->
				<!--{/if}-->
			</a>
		</div>
		<!--{/if}-->
        <!--{if $rtj1009_m_config['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
		<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_twsj_xx" >
			<span class="ren_twsj_sj z"><i class="icon ren-font">&#xe61c;</i>{$thread[dateline]}</span>
			<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
			<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
		</a>
	</li>
<!--{/if}-->
<!--{/loop}-->