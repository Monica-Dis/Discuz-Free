<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
require_once DISCUZ_ROOT.'./template/rtj1009_app/php/rtj1009_portal.php';
require_once DISCUZ_ROOT.'./template/rtj1009_app/php/rtj1009_list.php';
include_once libfile('function/post');
include_once libfile('function/attachment');
}-->
<div class="<!--{if $rtj1009_mobilecp['ren_m_portal_style'] == 2}-->ren_list_yi<!--{elseif $rtj1009_mobilecp['ren_m_portal_style'] == 3}-->ren_list_e<!--{elseif $rtj1009_mobilecp['ren_m_portal_style'] == 4}-->ren_list_san<!--{elseif $rtj1009_mobilecp['ren_m_portal_style'] == 5}-->ren_list_si<!--{/if}--> cl">
	<ul class="ren_list cl">

<!--{loop $portallist $key $value}-->
<!--{eval
	$value['post'] = C::t('forum_post')->fetch_all_by_tid_position($value['posttableid'],$value['tid'],1);
	$value['post'] = array_shift($value['post']);
	$ren_pic = C::t('forum_attachment_n')->count_image_by_id('tid:'.$value['post']['tid'], 'pid', $value['post']['pid']);
	$forumname = DB::result_first("SELECT name FROM ".DB::table("forum_forum")." WHERE `fid` = $value[fid]");
	$shustars = DB::fetch_first("SELECT b.* FROM ".DB::table("common_member")." a LEFT JOIN ".DB::table("common_usergroup")." b on b.groupid=a.groupid WHERE a.`uid` = '$value[authorid]'");
	$isfollowuid = DB::result_first("SELECT followuid FROM ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$value[authorid]");
}-->
<!--{eval
$imgurlx = rtj1009_imgurl($value['post']['message']);
$rtj1009_msg = rtj1009_msg($value['post']['message']);
$vediourlx = rtj1009_vedio_url($value['post']['message']);
}-->

<!--{if ($rtj1009_mobilecp['ren_m_portal_style'] ==1) || ($rtj1009_mobilecp['ren_m_portal_style'] ==2)}-->
<!--{if $ren_pic <=2}--><!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 1);}--><!--{/if}-->
<!--{if $ren_pic >=3}--><!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 3);}--><!--{/if}-->
<!--{if $ren_pic <=2}-->
	<li>
		<!--{if $rtj1009_mobilecp['ren_m_portal_style'] ==1}-->
		<div class="ren_twsj">
			<a class="ren_twus_img z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">
				<!--{avatar($value[authorid],middle)}-->
			</a>
			<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">$value[author]</a>
			<!--{if $rtj1009_mobilecp['ren_m_forum_xing'] == 1}-->
			<span class="ren_us_xing">Lv.{$shustars[stars]}<!--{if $rtj1009_mobilecp['ren_portal_utitle']}--> {$shustars[grouptitle]}<!--{/if}--></span>
			<!--{if $shustars[icon]}-->
			<span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
			<!--{/if}-->
            <!--{/if}-->
			<!--{if $rtj1009_mobilecp['ren_m_portal_listfw']}-->
			<div class="y">
				<!--{if !$isfollowuid}-->
				<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_zz_gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$value[authorid]">{$rtj1009_lang['ren022']}</a>
				<!--{else}-->
				<a class="dialog ren_qxgz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$value[authorid]">{$rtj1009_lang['ren031']}</a>
				<!--{/if}-->
			</div>
			<!--{else}-->
				<div class="y ren-p-fname">
					<a href="forum.php?mod=forumdisplay&fid=$value[fid]">#{$forumname}#</a>
				</div>
			<!--{/if}-->
		</div>
		<!--{/if}-->
		<div class="ren_tw_yiimg">
            <!--{if ($valuelistimg || $imgurlx) && !$vediourlx}-->
                <!--{if $valuelistimg}-->
                <a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_threadimg y">
                        <!--{if $ren_pic <=2}-->
                            <!--{loop $valuelistimg $values}-->
                            <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
                                <span class="ren_thread_imge ren_thread_img"><img src="$renlistimgkey" alt="$value[subject]"/></span>
                            <!--{/loop}-->
                        <!--{/if}-->
                </a>
                <!--{elseif $imgurlx}-->
                    <a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_threadimg imgurltu y">
                    <!--{eval echo $imgurlx;}-->
                    </a>
                <!--{/if}-->
            <!--{/if}-->

			<a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_tw_yi<!--{if $rtj1009_mobilecp['ren_m_portal_style'] ==1}--><!--{if ($ren_pic || $imgurlx) && !$vediourlx}--> tw-tu<!--{/if}--><!--{/if}-->" <!--{if $rtj1009_mobilecp['ren_m_portal_style'] ==2}-->style="<!--{if ($ren_pic || $imgurlx) && !$vediourlx}-->height: 48px; margin-bottom: 5px; overflow: hidden; <!--{/if}-->"<!--{/if}-->>
				<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if $value['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
				<!--{if !$_G[forum_thread][special]}-->
					{if $value['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
					{if $value['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
					{if $value['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
					{if $value['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
					{if $value['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
				<!--{/if}-->

				<span>{$value[subject]}</span>
			 </a>

			<!--{if $rtj1009_mobilecp['ren_m_portal_style'] ==2}-->
            <!--{if $rtj1009_mobilecp['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
			<div class="ren_list_us">
				<a class="ren_twus_img z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">
					<!--{avatar($value[authorid],middle)}-->
				</a>
				<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">$value[author]</a>
				<span class="time z" style="<!--{if !$ren_pic}-->display: block;<!--{else}-->display: none;<!--{/if}-->"><!--{echo dgmdate($value[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
				<a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_list_li_xx y" >
					<span class="reply y"><i class="icon ren-font">&#xe694;</i>{$value[replies]}</span>
					<span class="views y"><i class="icon ren-font">&#xe660;</i>{$value[views]}</span>
				</a>
			</div>
			<!--{/if}-->
		 </div>
        <!--{if $rtj1009_mobilecp['ren_m_portal_style'] !=2}-->
            <!--{if $rtj1009_mobilecp['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
        <!--{/if}-->
	   	<!--{if $rtj1009_mobilecp['ren_m_portal_style'] ==1}-->
		<a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_twsj_xx" >
			<span class="ren_twsj_sj z"><i class="icon ren-font">&#xe61c;</i><!--{echo dgmdate($value[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
			<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$value[views]}</span>
			<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$value[replies]}</span>
		</a>
		<!--{/if}-->
	</li>

	<!--{else}-->
	<li>
		<!--{if $rtj1009_mobilecp['ren_m_portal_style'] ==1}-->
		<div class="ren_twsj">
			<a class="ren_twus_img z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">
				<!--{avatar($value[authorid],middle)}-->
			</a>
			<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">$value[author]</a>
			<!--{if $rtj1009_mobilecp['ren_m_forum_xing'] == 1}-->
			<span class="ren_us_xing">Lv.{$shustars[stars]}<!--{if $rtj1009_mobilecp['ren_portal_utitle']}--> {$shustars[grouptitle]}<!--{/if}--></span>
			<!--{if $shustars[icon]}-->
			<span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
			<!--{/if}-->
            <!--{/if}-->
			<!--{if $rtj1009_mobilecp['ren_m_portal_listfw']}-->
			<div class="y">
				<!--{if !$isfollowuid}-->
				<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_zz_gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$value[authorid]">{$rtj1009_lang['ren022']}</a>
				<!--{else}-->
				<a class="dialog ren_qxgz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$value[authorid]">{$rtj1009_lang['ren031']}</a>
				<!--{/if}-->
			</div>
			<!--{else}-->
				<div class="y ren-p-fname">
					<a href="forum.php?mod=forumdisplay&fid=$value[fid]">#{$forumname}#</a>
				</div>
			<!--{/if}-->
		</div>
		<!--{/if}-->
		<div class="ren_twbt">
			<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if $value['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
			<!--{if !$_G[forum_thread][special]}-->
				{if $value['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
				{if $value['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
				{if $value['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
				{if $value['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
				{if $value['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
			<!--{/if}-->

			<a href="forum.php?mod=viewthread&tid=$value[tid]">{$value[subject]}</a>
		 </div>

        <!--{if $valuelistimg && !$vediourlx}-->
            <div class="ren_threadimg">
                <a href="forum.php?mod=viewthread&tid=$value[tid]">
                    <!--{if $ren_pic >=3}-->
                    <!--{loop $valuelistimg $values}-->
                    <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
                        <span class="ren_thread_imgsan ren_thread_img"><img src="$renlistimgkey"/></span>
                    <!--{/loop}-->
                    <!--{/if}-->
                </a>
            </div>
        <!--{/if}-->
        <!--{if $rtj1009_mobilecp['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
	   	<!--{if $rtj1009_mobilecp['ren_m_portal_style'] ==1}-->
		<a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_twsj_xx" >
			<span class="ren_twsj_sj z"><i class="icon ren-font">&#xe61c;</i><!--{echo dgmdate($value[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
			<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$value[views]}</span>
			<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$value[replies]}</span>
		</a>
		<!--{else}-->
		<div class="ren_list_us">
			<a class="ren_twus_img z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">
				<!--{avatar($value[authorid],middle)}-->
			</a>
			<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">$value[author]</a>
			<span class="time z"><!--{echo dgmdate($value[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
			<a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_list_li_xx y" >
				<span class="reply y"><i class="icon ren-font">&#xe694;</i>{$value[replies]}</span>
				<span class="views y"><i class="icon ren-font">&#xe660;</i>{$value[views]}</span>
			</a>
		</div>
		<!--{/if}-->
	</li>
<!--{/if}-->

<!--{elseif ($rtj1009_mobilecp['ren_m_portal_style'] ==3) || ($rtj1009_mobilecp['ren_m_portal_style'] ==4)}-->
<!--{if $ren_pic ==1}--><!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 1);}--><!--{/if}-->
<!--{if $ren_pic <=4}--><!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 3);}--><!--{/if}-->
<!--{if $ren_pic >=5}--><!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 6);}--><!--{/if}-->
<!--{if $ren_pic >=9}--><!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 9);}--><!--{/if}-->
	<li>
		<div class="ren_twsj ren_list_tu">
			<a class="ren_twus_img z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">
				<!--{avatar($value[authorid],middle)}-->
			</a>
			<div class="z ren_author">
				<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">$value[author]</a>
			<!--{if $rtj1009_mobilecp['ren_m_forum_xing'] == 1}-->
				<span class="ren_us_xing">Lv.{$shustars[stars]}<!--{if $rtj1009_mobilecp['ren_portal_utitle']}--> {$shustars[grouptitle]}<!--{/if}--></span>
                <!--{if $shustars[icon]}-->
                <span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
                <!--{/if}-->
                <!--{/if}-->
			</div>
			<div class="z ren_thread_sj">
				<span class="z ren_thread_dateline"><!--{if !$rtj1009_mobilecp['ren_m_portal_listfw']}-->{$rtj1009_lang['ren033']}<!--{/if}--><!--{echo dgmdate($value[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
				<!--{if $rtj1009_mobilecp['ren_m_portal_listfw']}-->
				<a href="forum.php?mod=forumdisplay&fid=$value[fid]" class="z">{$rtj1009_lang['ren032']}{$forumname}</a>
				<!--{/if}-->
			</div>
			<!--{if $rtj1009_mobilecp['ren_m_portal_listfw']}-->
			<div class="ren_gz">
				<!--{if !$isfollowuid}-->
				<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_zz_gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$value[authorid]">{$rtj1009_lang['ren022']}</a>
				<!--{else}-->
				<a class="dialog ren_qxgz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$value[authorid]">{$rtj1009_lang['ren031']}</a>
				<!--{/if}-->
			</div>
			<!--{else}-->
				<div class="y ren-p-fname">
					<a href="forum.php?mod=forumdisplay&fid=$value[fid]">#{$forumname}#</a>
				</div>
			<!--{/if}-->
		</div>
		<div class="ren_twbt tu">
			<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if $value['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
			<!--{if !$_G[forum_thread][special]}-->
				{if $value['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
				{if $value['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
				{if $value['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
				{if $value['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
				{if $value['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
			<!--{/if}-->

			<a href="forum.php?mod=viewthread&tid=$value[tid]">{$value[subject]}</a>
        </div>
        <!--{if $value['post']['message']}-->
        <div class="forum_message">
			<a href="forum.php?mod=viewthread&tid=$value[tid]"><!--{eval echo $rtj1009_msg}--></a>
		 </div>
        <!--{/if}-->

        <!--{if $rtj1009_mobilecp['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->

		<!--{if ($valuelistimg || $imgurlx) && !$vediourlx}-->
		<div class="ren_threadimg tu">
			<a href="forum.php?mod=viewthread&tid=$value[tid]">
                <!--{if $valuelistimg}-->
                    <!--{if $ren_pic ==1}-->
                    <!--{loop $valuelistimg $values}-->
                        <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 350, 9999); }-->
                            <span class="yige_img ren_thread_img"><img src="$renlistimgkey" /></span>
                    <!--{/loop}-->
                    <!--{else}-->
                        <!--{loop $valuelistimg $values}-->
                        <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 150); }-->
                            <span class="ren_thread_imgsan ren_thread_img"><img src="$renlistimgkey" /></span>
                        <!--{/loop}-->
                    <!--{/if}-->
                <!--{elseif $imgurlx}-->
                    <!--{eval echo $imgurlx;}-->
                <!--{/if}-->
			</a>
		</div>
		<!--{/if}-->

		<a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_twsj_xx tu" >
			<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$value[views]}</span>
			<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$value[replies]}</span>
			<span class="ren_twsj_sj z"><i class="icon ren-font">&#xe856;</i>{$value[recommend_add]}</span>
		</a>
	</li>
<!--{elseif $rtj1009_mobilecp['ren_m_portal_style'] ==5}-->
<!--{eval $valuelistimg = fetch_ren_attachment_aid('tid:'.$value['post']['tid'], 'pid', $value['post']['pid'], 1);}-->
	<li>
		<div class="ren_tw_yiimg">
            <!--{if ($valuelistimg || $imgurlx) && !$vediourlx}-->
                <!--{if $valuelistimg}-->
                <a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_threadimg z">
                    <!--{if $ren_pic}-->
                    <!--{loop $valuelistimg $values}-->
                    <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
                    <span class="ren_thread_imge ren_thread_img"><img src="$renlistimgkey" alt="$value[subject]"/></span>
                    <!--{/loop}-->
                    <!--{/if}-->
                </a>
                <!--{elseif $imgurlx}-->
                <a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_threadimg z imgurlsan">
                    <!--{eval echo $imgurlx;}-->
                </a>
                <!--{/if}-->
            <!--{/if}-->

			<a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_tw_yi" style="margin-bottom: 5px; <!--{if ($ren_pic || $imgurlx) && !$vediourlx}-->height: 48px; margin-top: 5px; overflow: hidden; <!--{/if}-->">
				<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if $value['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
				<!--{if !$_G[forum_thread][special]}-->
					{if $value['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
					{if $value['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
					{if $value['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
					{if $value['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
					{if $value['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
				<!--{/if}-->

                <span>{$value[subject]}</span>
			 </a>
            <!--{if $rtj1009_mobilecp['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
			 <div class="ren_list_us">
				<a class="ren_twus_img z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">
					<!--{avatar($value[authorid],middle)}-->
				</a>
				<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$value[authorid]&do=profile">$value[author]</a>
				<span class="time z" style="<!--{if !$ren_pic}-->display: block;<!--{else}-->display: none;<!--{/if}-->"><!--{echo dgmdate($value[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
				<a href="forum.php?mod=viewthread&tid=$value[tid]" class="ren_list_li_xx y" >
					<span class="reply y"><i class="icon ren-font">&#xe694;</i>{$value[replies]}</span>
					<span class="views y"><i class="icon ren-font">&#xe660;</i>{$value[views]}</span>
				</a>
			</div>
		 </div>
	</li>
<!--{/if}-->
<!--{/loop}-->
	</ul>
</div>