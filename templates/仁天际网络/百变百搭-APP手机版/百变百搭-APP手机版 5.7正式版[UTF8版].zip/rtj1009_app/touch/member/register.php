<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $ren_weixin_hd}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
		<a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span>{lang register}</span>
		</div>
		<div class="y ren_list_nav">
			<a href="portal.php?mod=index" class="ren_nav_fb"><span class="icon ren-font">&#xe601;</span></a>
		</div>
	</div>
</header>
<!-- header end -->
<!--{/if}-->
<!-- registerbox start -->
<div class="content p-b-0">
	<div class="rtj1009_m_login">
		<div class="ren_mn ren_zc_mn cl">
			<form method="post" autocomplete="off" name="register" id="registerform" action="member.php?mod={$_G[setting][regname]}&mobile=2">
			<input type="hidden" name="regsubmit" value="yes" />
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<!--{eval $dreferer = str_replace('&amp;', '&', dreferer());}-->
			<input type="hidden" name="referer" value="$dreferer" />
			<input type="hidden" name="activationauth" value="{if $_GET[action] == 'activation'}$activationauth{/if}" />
			<div class="list-block">
				<ul>
                    <!--{if $sendurl}-->
                    <li>
                        <div class="item-content">
                            <div class="item-media"><i class="icon ren-font">&#xe70c;</i></div>
                            <div class="item-inner">
                                <div class="item-input">
                                    <input type="email" tabindex="1" class="ren_px ren_zc_text" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login">
                                </div>
                            </div>
                        </div>
                    </li>
                    <!--{else}-->
                    <!--{if empty($invite) && $_G['setting']['regstatus'] == 2 && !$invitestatus}-->
                    <li>
                        <div class="item-content">
                            <div class="item-media"><i class="icon ren-font">&#xe61a;</i></div>
                            <div class="item-inner">
                                <div class="item-input">
                                    <input type="text" tabindex="1" class="ren_px ren_zc_text" size="30" autocomplete="off" value="" name="invitecode" placeholder="{lang invite_code}" fwin="login">
                                </div>
                            </div>
                        </div>
                    </li>
                    <!--{/if}-->
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe67e;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="text" tabindex="1" class="ren_zc_text" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['username']}" placeholder="{lang registerinputtip}" fwin="login">
						</div>
					  </div>
					</div>
				  </li>
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe61a;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="password" tabindex="2" class="ren_px ren_zc_text" size="30" value="" name="{$_G['setting']['reginput']['password']}" placeholder="{lang login_password}" fwin="login">
						</div>
					  </div>
					</div>
				  </li>
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe61a;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="password" tabindex="3" class="ren_px ren_zc_text" size="30" value="" name="{$_G['setting']['reginput']['password2']}" placeholder="{lang registerpassword2}" fwin="login">
						</div>
					  </div>
					</div>
				  </li>
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe70c;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="email" tabindex="4" class="ren_px ren_zc_text" size="30" autocomplete="off" value="" name="{$_G['setting']['reginput']['email']}" placeholder="{lang registeremail}" fwin="login">
						</div>
					  </div>
					</div>
				  </li>
                    <!--{if empty($invite) && $_G['setting']['regstatus'] == 3}-->
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe62a;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="text" name="invitecode" autocomplete="off" tabindex="5" class="px p_fre" size="30" value="" placeholder="{lang invite_code}" fwin="login">
						</div>
					  </div>
					</div>
				  </li>
				  <!--{/if}-->
				  <!--{if $_G['setting']['regverify'] == 2}-->
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe62c;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="text" name="regmessage" autocomplete="off" tabindex="6" class="px p_fre" size="30" value="" placeholder="{lang register_message}" fwin="login">
						</div>
					  </div>
					</div>
				  </li>
				  <!--{/if}-->
                    <!--{loop $_G['cache']['fields_register'] $field}-->
                    <!--{if $htmls[$field['fieldid']]}-->
                    <li>
                        <div class="item-content">
                            <div class="item-media">$field[title]</div>
                            <div class="item-inner">
                                <div class="item-input<!--{if $field['formtype'] == 'select'}--> item-input-select<!--{/if}-->">
                                    $htmls[$field['fieldid']]
                                </div>
                            </div>
                        </div>
                    </li>
                    <!--{/if}-->
                    <!--{/loop}-->
                    <!--{/if}-->
                    <!--{if $secqaacheck || $seccodecheck}-->
                    <!--{if $secqaacheck}-->
                    <!--{subtemplate common/seccheck}-->
                    <!--{else}-->
                    <li>
                        <div class="item-content">
                            <div class="item-media"><i class="icon ren-font icon-form-gender">&#xe609;</i></div>
                            <div class="item-inner">
                                <!--{subtemplate common/seccheck}-->
                            </div>
                        </div>
                    </li>
                    <!--{/if}-->
				<!--{/if}-->
				</ul>
			  </div>
		</div>
		
		<div class="ren_login btn_login">
			<button tabindex="7" value="true" name="regsubmit" type="submit" class="formdialog pn button ren_btn"><span>{lang quickregister}</span></button>
		</div>
		<!--{if $bbrules}-->
		<div class="ren_reg_link cl">
			<div class="ren_zc_xy">
				<input type="checkbox" class="pc" name="agreebbrule" value="$bbrulehash" id="agreebbrule" checked="checked" />
				<label for="agreebbrule">{$rtj1009_lang['ren051']}<a href="javascript:;" class="open-popup" data-popup=".popup-abe">{lang rulemessage}</a></label>
			</div>
		</div>
		<!--{/if}-->
		</form>
	</div>
		<div class="ren_qtzhdl cl">
		<!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
			<div class="ren_qtzh cl"><span>{$rtj1009_lang['ren048']}</span></div>
			<div class="ren_qqlogin cl"><a class="ren_qq" href="$_G[connect][login_url]&statfrom=login_simple"></a></div>
		<!--{/if}-->
		</div>
		<!--{hook/logging_bottom_mobile}-->
</div>
<div class="popup popup-abe">
	<header class="bar bar-nav rtj1009_header">
		<div class="ren_nav cl">
			<a href="javascript:;" class="z ren_fhjt close-popup"><span></span></a>
			<div class="ren_top_dqwz z">
				<span>{lang rulemessage}</span>
			</div>
			<div class="y ren_list_nav">
				<a href="portal.php?mod=index" class="ren_nav_fb"><span class="icon ren-font">&#xe601;</span></a>
			</div>
		</div>
	</header>
  <div class="content-block">
	<div class="content-padded">
	  <p>$bbrulestxt</p>
	</div>
	<div class="ren_login btn_login">
		<a href="javascript:;" class="pn button ren_btn close-popup">{$rtj1009_lang['ren052']}</a>
	</div>
  </div>
</div>


<!-- registerbox end -->
<!--{eval updatesession();}-->
<!--{template common/footer}-->
