<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !$_GET['infloat']}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $ren_weixin_hd}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
		<a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span>{lang login}</span>
		</div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<!--{/if}-->
<div class="content p-b-0">
{eval $loginhash = 'L'.random(4);}

<!-- userinfo start -->
	<div class="rtj1009_m_login <!--{if $_GET[infloat]}-->login_pop<!--{/if}-->">
		<form id="loginform" method="post" action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" onsubmit="{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
			<input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
			<input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
			<input type="hidden" name="fastloginfield" value="username">
			<input type="hidden" name="cookietime" value="2592000">
			<!--{if $auth}-->
				<input type="hidden" name="auth" value="$auth" />
			<!--{/if}-->
			<div class="list-block">
				<ul>
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe67e;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="text" tabindex="1" class="ren_px input_text xg1" size="30" autocomplete="off" value="" name="username" placeholder="{lang inputyourname}" fwin="login">
						</div>
					  </div>
					</div>
				  </li>
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe61a;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="password" tabindex="2" class="ren_px input_text xg1" size="30" value="" name="password" placeholder="{lang login_password}" fwin="login">
						</div>
					  </div>
					</div>
				  </li>
			
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe6f2;</i></div>
					  <div class="item-inner">
						<div class="item-input item-input-select">
							<select id="questionid_{$loginhash}" name="questionid" class="ren_label_tiwen">
								<option value="0" selected="selected">{lang security_question}</option>
								<option value="1">{lang security_question_1}</option>
								<option value="2">{lang security_question_2}</option>
								<option value="3">{lang security_question_3}</option>
								<option value="4">{lang security_question_4}</option>
								<option value="5">{lang security_question_5}</option>
								<option value="6">{lang security_question_6}</option>
								<option value="7">{lang security_question_7}</option>
							</select>
						</div>
					  </div>
					</div>
				  </li>
				  <li class="answerli" style="display:none;">
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe669;</i></div>
					  <div class="item-inner">
						<div class="item-input">
							<input type="text" name="answer" id="answer_{$loginhash}" class="ren_px input_text_tiwen" size="30" placeholder="{lang security_a}">
						</div>
					  </div>
					</div>
				  </li>
				<!--{if $seccodecheck}-->
				 <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font icon-form-gender">&#xe609;</i></div>
					  	<div class="item-inner">
						<!--{subtemplate common/seccheck}-->
						</div>
					</div>
				  </li>
				<!--{/if}-->
				</ul>
			  </div>
			<div class="ren_login btn_login">
				<button tabindex="3" value="true" name="submit" type="submit" class="formdialog pn button ren_btn">{lang login}</button>
			</div>
		</form>
		<div class="ren_reg_link cl">
			<a href="member.php?mod={$_G[setting][regname]}" class="z">{$rtj1009_lang['ren046']}</a>
			<a href="javascript:;" class="y open-popup" data-popup=".popup-lostpw">{$rtj1009_lang['ren047']}</a>
		</div>
		<div class="ren_qtzhdl cl">
		<!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
			<div class="ren_qtzh cl"><span>{$rtj1009_lang['ren048']}</span></div>
			<div class="ren_qqlogin cl"><a class="ren_qq" href="$_G[connect][login_url]&statfrom=login_simple"></a></div>
		<!--{/if}-->
		</div>
		<!--{hook/logging_bottom_mobile}-->
	</div>
<!-- userinfo end -->
<!--{if $_G['setting']['pwdsafety']}-->
	<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<!--{/if}-->
<!--{eval updatesession();}-->
</div>
<div class="popup popup-lostpw">
	<header class="bar bar-nav rtj1009_header">
		<div class="ren_nav cl">
			<a href="javascript:;" class="z ren_fhjt close-popup"><span></span></a>
			<div class="ren_top_dqwz z">
				<span>{$rtj1009_lang['ren047']}</span>
			</div>
			<div class="y ren_list_nav">
				<a href="portal.php?mod=index" class="ren_nav_fb"><span class="icon ren-font">&#xe601;</span></a>
			</div>
		</div>
	</header>
  <div class="content-block">
	<div class="ren_lostpw">
		<form method="post" autocomplete="off" id="lostpwform_$loginhash" class="cl" onsubmit="ajaxpost('lostpwform_$loginhash', 'returnmessage3_$loginhash', 'returnmessage3_$loginhash', 'onerror');return false;" action="member.php?mod=lostpasswd&lostpwsubmit=yes&infloat=yes">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="handlekey" value="lostpwform" />
			<div class="list-block">
				<ul>
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe70c;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="text" name="email" id="lostpw_email" size="30" value=""  tabindex="1" class="px p_fre" placeholder="{$rtj1009_lang['ren049']}"/>
						</div>
					  </div>
					</div>
				  </li>
				  <li>
					<div class="item-content">
					  <div class="item-media"><i class="icon ren-font">&#xe67e;</i></div>
					  <div class="item-inner">
						<div class="item-input">
						  <input type="text" name="username" id="lostpw_username" size="30" value=""  tabindex="1" class="px p_fre" placeholder="{$rtj1009_lang['ren050']}"/>
						</div>
					  </div>
					</div>
				  </li>
				</ul>
			</div>
			<div class="ren_login btn_login">
				<button class="formdialog pn button ren_btn" type="submit" name="lostpwsubmit" value="true" tabindex="100">{lang submit}</button>
			</div>
		</form>
	</div>
  </div>
</div>

<script type="text/javascript">
	(function() {
		$(document).on('change', '.ren_label_tiwen', function() {
			var obj = $(this);
			$('.span_question').text(obj.find('option:selected').text());
			if(obj.val() == 0) {
				$('.answerli').css('display', 'none');
				$('.questionli').addClass('bl_none');
			} else {
				$('.answerli').css('display', 'block');
				$('.questionli').removeClass('bl_none');
			}
		});
	 })();
</script>

<!--{template common/footer}-->
