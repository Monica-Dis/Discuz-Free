<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/ren_lang.'.currentlang().'.php';}-->
<!--{if $_GET[action] == 'rate'}-->

<div class="tip ren-rate-tip">
	<form id="rateform" method="post" autocomplete="off" action="forum.php?mod=misc&action=rate&ratesubmit=yes&infloat=yes" onsubmit="ajaxpost('rateform', 'return_rate', 'return_rate', 'onerror');">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<input type="hidden" name="pid" value="$_GET[pid]" />
		<input type="hidden" name="referer" value="$referer" />
		<input type="hidden" name="handlekey" value="rate">
		<div class="ren-rate-nav">
			<a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
			<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren-rate-author">
				<img src="<!--{avatar($post[authorid], middle, true)}-->">
				<p>$post[author]</p>
			</a>
			<p>{$rtj1009_lang['ren084']}</p>
		</div>
		<div class="list-block">
			<ul>
				<!--{eval $rateselfflag = 0;}--> 
				<!--{loop $ratelist $id $options}-->
				<li>
					<div class="item-content">
						<div class="item-media">{$_G['setting']['extcredits'][$id][img]} {$_G['setting']['extcredits'][$id][title]}</div>
						<div class="item-inner">
							<div class="item-input">
								<input type="text" name="score$id" id="score$id" class="ren-rate-input" placeholder="0" value=""/>
							</div>
						</div>
						<div class="item-media">{$_G['group']['raterange'][$id]['min']} ~ {$_G['group']['raterange'][$id]['max']}</div>
					</div>
				</li>
				<!--{/loop}-->
				<li>
					<div class="item-content">
						<div class="item-inner">
							<div class="item-input">
								<input type="text" name="reason" id="reason" placeholder="{$rtj1009_lang['ren085']}" class="ren-reason" />
							</div>
						</div>
					</div>
				</li>
				<li>
					<div class="item-content">
						<div class="item-media">{lang admin_pm}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="sendreasonpm" class="label-switch">
								<input type="checkbox" name="sendreasonpm" id="sendreasonpm" />
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</div>
				</li>
			</ul>
		</div>
		<p class="ren_login btn_login">
			<button name="ratesubmit" type="submit" value="true" class="formdialog pn button ren_btn"><span>{lang confirms}</span></button>
		</p>
	</form>
</div>
<!--{/if}--> 
<!--{eval $nofooter = true;}--> 
<!--{template common/footer}-->