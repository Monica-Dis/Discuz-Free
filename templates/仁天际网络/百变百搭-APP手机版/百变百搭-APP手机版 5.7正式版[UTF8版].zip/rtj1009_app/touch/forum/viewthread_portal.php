<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
{eval
	$specialarr = array(0 => array('thread', '{lang index_posts}'), 1 => array('poll', '{lang thread_poll}'), 2 => array('trade', '{lang thread_trade}'), 3 => array('reward', '{lang thread_reward}'), 4 => array('activity', '{lang thread_activity}'), 5 => array('debate', '{lang thread_debate}'));
	$specialtype = $specialarr[$_G['forum_thread']['special']];
	$_G[home_tpl_titles][] = $navsubject;
	$_G[home_tpl_titles][] = $specialtype[1];
	$_G[home_tpl_titles][] = '{lang portal}';
}

<!--{template common/header}-->
<script type="text/javascript" src="template/rtj1009_app/js/jQuery.rTabs.js"></script>
<script type="text/javascript" src='template/rtj1009_app/js/ren_share.js'></script>
<style type="text/css">
    .tab { position: relative; overflow: hidden; }
    .tab-con { position: relative; }
</style>


<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_dqwz z">
			<span class="ren_bk_name">
				<a href="javascript:history.back();">{$rtj1009_lang['ren121']}</a>
			</span>
        </div>
        <div class="ren_nav_right">
            <div class="ren_view_navgd open-popover"><span class="icon ren-font">&#xe677;</span></div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="ren_nav_gd popover">
    <div class="popover-angle on-top"></div>
    <div class="ren_gd_list close-popover cl">
        <a href="javascript:;" class="ren_viewdi_fx ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe613;</i><span>{$rtj1009_lang['ren089']}</span></a>
        <a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_gd_jb close-popover"><i class="icon ren-font">&#xe66b;</i><span>{$rtj1009_lang['ren090']}</a>
        <a href="forum.php?mod=forumdisplay&fid={$forum[fid]}" class="ren_gd_fh"><i class="icon ren-font">&#xe60c;</i><span>{$rtj1009_lang['ren091']}</span></a>
    </div>
</div>

<form method="post" autocomplete="off" name="modactions" id="modactions">
<input type="hidden" name="formhash" value="{FORMHASH}" />
<input type="hidden" name="optgroup" />
<input type="hidden" name="operation" />
<input type="hidden" name="listextra" value="$_GET[extra]" />
</form>

<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';var aimgcount = new Array();</script>


<div class="content ren-view-main ren-view-b48">
    <div class="rtj1009_m_view rtj1009_m_main m_pb43">
        <div class="postlist rtj1009_m_main">
            <div class="ren_view_wztop">
                <h3 class="ph">$_G[forum_thread][subject]</h3>
                <div class="ren_twsj_xx">
                    <div class="z">
                        <a href="home.php?mod=space&uid=$_G[forum_thread][authorid]" class="z ren_twsj_fl"><span>$_G[forum_thread][author]</span></a>
                        <span class="ren_twsj_sj z"><!--{date($_G[forum_thread][dateline])}--></span>
                    </div>
                    <div class="y">
                        <span class="ren_twsj_ck y"><i class="icon ren-font">&#xe660;</i><!--{if $_G[forum_thread][views] > 0}-->$_G[forum_thread][views]<!--{else}-->0<!--{/if}--></span>
                        <span class="ren_twsj_hf y"><i class="icon ren-font">&#xe694;</i><!--{if $_G[forum_thread][replies] > 0}-->$_G[forum_thread][replies]<!--{else}-->0<!--{/if}--></span>
                    </div>
                </div>
            </div>

			<!--{if empty($_GET['page']) || $_GET['page'] < 2}-->
            <div class="ren_view_ny cl" id="pid$post[pid]">
                <div class="display pi" href="#replybtn_$post[pid]">
                    <div class="message">
                        <!--{if $post['warned']}-->
                        <span class="grey quote">{lang warn_get}</span>
                        <!--{/if}-->
                        <!--{if !$post['first'] && !empty($post[subject])}-->
                        <h2><strong>$post[subject]</strong></h2>
                        <!--{/if}-->
                        <!--{if $_G['forum_thread']['replycredit'] > 0}-->
                        <div class="ren-replycredit cl">
                            <div class="ren-reply">
                                {$rtj1009_lang['ren196']} {$_G['forum_thread']['replycredit']}{$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][unit]} {$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][title]} {lang thread_replycredit_tips1} {lang thread_replycredit_tips2}<!--{if $_G['forum_thread']['replycredit_rule'][random] > 0}--><span class="xg1">{lang thread_replycredit_tips3}</span><!--{/if}-->
                            </div>
                        </div>
                        <!--{/if}-->
                        <!--{if $rushreply}-->
                        <div class="ren-locked ren_rwd ren-rushreply cl">
                            <div class="ren-loc-z">
											<span class="ren-loc-txt">
										<!--{if $rushresult[creditlimit] == ''}-->
											{lang thread_rushreply}&nbsp;
                                                <!--{else}-->
											{lang thread_rushreply_limit} &nbsp;
                                                <!--{/if}-->
											</span>
                                <!--{if !$_GET['checkrush']}-->
                                <a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" class="ren-checkrush"><span>{lang rushreply_view}</span></a>
                                <!--{/if}-->
                            </div>
                            <p class="">
                                <!--{if $rushresult[stopfloor]}-->
                                {lang thread_rushreply_end}$rushresult[stopfloor]&nbsp;
                                <!--{/if}-->
                            </p>
                            <p class="">
                                <!--{if $rushresult[rewardfloor]}-->
                                {lang thread_rushreply_floor}{$rtj1009_lang['ren131']}$rushresult[rewardfloor]&nbsp;
                                <!--{/if}-->
                            </p>
                            <!--{if $rushresult[rewardfloor] && $_GET['checkrush']}-->
                            <p class="ren-checkrush-ptn">
                                <!--{if $countrushpost}-->[<strong>$countrushpost</strong>]{lang thread_rushreply_rewardnum}<!--{else}--> {lang thread_rushreply_noreward} <!--{/if}-->&nbsp;
                                <a href="forum.php?mod=viewthread&tid=$_G[tid]" class="xi2">{lang thread_rushreply_check_back}</a>
                            </p>
                            <!--{/if}-->
                        </div>
                        <!--{/if}-->
                        <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                        <div class="grey quote">{lang message_banned}</div>
                        <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                        <div class="grey quote">{lang message_single_banned}</div>
                        <!--{elseif $needhiddenreply}-->
                        <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
                        <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
                        <!--{template forum/viewthread_pay}-->
                        <!--{else}-->

                        <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                        <div class="grey quote">{lang admin_message_banned}</div>
                        <!--{elseif $post['status'] & 1}-->
                        <div class="grey quote">{lang admin_message_single_banned}</div>
                        <!--{/if}-->
                        <!--{if $post['first']}-->
                        <!--{if $threadsortshow['typetemplate'] && $rtj1009_m_config['ren_flxx_view']}-->
                        $threadsortshow[typetemplate]

                        <script type="text/javascript">
                            $(function() {
                                $("#tab4").rTabs({
                                    animation : 'fadein',
                                    bind : 'click'
                                });
                                $("#tab2").rTabs({
                                    animation : 'fadein',
                                    bind : 'click'
                                });
                            })
                        </script>
                        <!--{elseif $threadsortshow['optionlist']}-->
                        <div class="typeoption ren_view_flxx">
                            <!--{if $threadsortshow['optionlist'] == 'expire'}-->
                            {lang has_expired}
                            <!--{else}-->
                            <table summary="{lang threadtype_option}" cellpadding="0" cellspacing="0" class="cgtl ren_view_flxxnr">
                                <caption>{$rtj1009_lang['ren092']}</caption>
                                <tbody>
                                <!--{loop $threadsortshow['optionlist'] $option}-->
                                <!--{if $option['type'] != 'info'}-->
                                <tr>
                                    <th>$option[title]{$rtj1009_lang['ren131']}</th>
                                    <td><!--{if $option['value'] !== ''}--><!--{if $option['type'] == 'image' && $threadsortshow['typetemplate']}--><img src="$option[value]"><!--{else}-->$option[value] $option[unit]<!--{/if}--><!--{else}-->-<!--{/if}--></td>
                                </tr>
                                <!--{/if}-->
                                <!--{/loop}-->
                                </tbody>
                            </table>
                            <!--{/if}-->
                        </div>
                        <!--{/if}-->
                        <!--{if !$_G[forum_thread][special]}-->
                        $post[message]
                        <!--{elseif $_G[forum_thread][special] == 1}-->
                        <!--{template forum/viewthread_poll}-->
                        <!--{elseif $_G[forum_thread][special] == 2}-->
                        <!--{template forum/viewthread_trade}-->
                        <!--{elseif $_G[forum_thread][special] == 3}-->
                        <!--{template forum/viewthread_reward}-->
                        <!--{elseif $_G[forum_thread][special] == 4}-->
                        <!--{template forum/viewthread_activity}-->
                        <!--{elseif $_G[forum_thread][special] == 5}-->
                        <!--{template forum/viewthread_debate}-->
                        <!--{elseif $threadplughtml}-->
                        $threadplughtml
                        $post[message]
                        <!--{else}-->
                        $post[message]
                        <!--{/if}-->
                        <!--{else}-->
                        $post[message]
                        <!--{/if}-->
                        <!--{/if}-->
                    </div>

                    <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                    <!--{if $post['attachment']}-->
                    <div class="ren-flxx-jbts quote cl">
                        {lang attachment}{$rtj1009_lang['ren131']}<em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
                    </div>
                    <!--{elseif $post['imagelist'] || $post['attachlist']}-->
                    <!--{if $post['imagelist']}-->
                    <!--{if count($post['imagelist']) == 1}-->
                    <ul class="img_one">{echo showattach($post, 1)}</ul>
                    <!--{else}-->
                    <ul class="ren_img_list cl vm">{echo showattach($post, 1)}</ul>
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{if $post['attachlist']}-->
                    <ul>{echo showattach($post)}</ul>
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{if $threadsortshow}-->
                    <div class="ren-flxx-us">
                        <div class="ren_lc_xx cl">
                            <a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="avatar z"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->"/></a>
                            <div class="ren_lc_zz cl">
                                <div class="ren_lc_zzxx cl">
                                    <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                                    <a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren_zz_mz z">$post[author]</a>
                                    <!--{else}-->
                                    <!--{if !$post['authorid']}-->
                                    <a href="javascript:;">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
                                    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
                                    <!--{if $_G['forum']['ismoderator']}--><a href="home.php?mod=space&uid=$post[authorid]&do=profile">{lang anonymous}</a><!--{else}-->{lang anonymous}<!--{/if}-->
                                    <!--{else}-->
                                    $post[author] <em>{lang member_deleted}</em>
                                    <!--{/if}-->
                                    <!--{/if}-->
                                    <!--{if $rtj1009_mobilecp['ren_m_view_xing']}-->
                                    <em class="z ren_us_xing">Lv.{$post[stars]}<!--{if $rtj1009_m_config['ren_view_utitle']}--> {$post[authortitle]}<!--{/if}--></em>
                                    <!--{/if}-->
                                    <!--{if $_G['forum']['ismoderator']}-->
                                    <!-- manage start -->
                                    <div href="#moption_$post[pid]" class="open-popup ren_lc_gl" data-popup=".popup-view-lzgl">{lang manage}</div>
                                    <div class="popup popup-view-gl popup-view-lzgl">
                                        <div class="content-block">
                                            <div class="ren_lostpw">
                                                <!--{if !$_G['forum_thread']['special']}-->
                                                <a class="redirect" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a>
                                                <!--{/if}-->
                                            </div>
                                        </div>
                                        <div class="ren-close">
                                            <a href="javascript:;" class="close-popup">{$rtj1009_lang['ren012']}</a>
                                        </div>
                                    </div>
                                    <!-- manage end -->
                                    <!--{/if}-->
                                    <a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->y ren-flxx-jbbtn">{$rtj1009_lang['ren090']}</a>
                                    <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
                                    <a class="y ren_zz_gz ren-flxx-bjbtn" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a>
                                    <!--{/if}-->
                                </div>
                                <div class="ren_lc_sj cl">
                                    <span class="ren_lc_sjsj">{$rtj1009_lang['ren033']}$post[dateline]</span>
                                    <span class="ren-flxx-i"><i class="icon ren-font">&#xe660;</i>{$thread[views]}{$rtj1009_lang['ren135']}</span>
                                </div>
                            </div>
                        </div>
                        <div class="ren-flxx-jbts cl">
                            <span><i class="icon ren-font">&#xe62e;</i>{$rtj1009_lang['ren136']}</span>
                        </div>
                    </div>
                    <!--{/if}-->
                    <!--{if $rtj1009_m_config['ren_forum_view_rate']}-->
                    <div class="ren-view-rate">
                        <p>{$rtj1009_lang['ren093']}</p>
                        <a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]" class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-view-but">
                            <p>{$rtj1009_lang['ren094']}</p>
                        </a>
                        <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
                        <a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" class="ren-rate-shu">{$rtj1009_lang['ren095']}<span><!--{echo count($postlist[$post[pid]][totalrate]);}--></span>{$rtj1009_lang['ren096']}</a>
                        <!--{/if}-->
                        <!--{if $_G['setting']['ratelogon']}-->
                        <ul class="cl">
                            <!--{loop $post['ratelog'] $uid $ratelog}-->
                            <li>
                                <a href="home.php?mod=space&uid=$uid&do=profile"><!--{echo avatar($uid, 'small');}--></a>
                            </li>
                            <!--{/loop}-->
                        </ul>
                        <!--{/if}-->
                    </div>
                    <!--{/if}-->

                    <!--{if $post['first'] && ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
                    <div class="ren-view-tag">
                        <!--{if $post[tags]}-->
                        <i class="icon ren-font">&#xe6bb;</i>
                        <!--{eval $tagi = 0;}-->
                        <!--{loop $post[tags] $var}-->
                        <!--{if $tagi}--> , <!--{/if}--><a title="$var[1]" href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
                        <!--{eval $tagi++;}-->
                        <!--{/loop}-->
                        <!--{/if}-->
                        <!--{if $relatedkeywords}--><span>$relatedkeywords</span><!--{/if}-->
                    </div>
                    <!--{/if}-->
                </div>
			</div>
			<!--{/if}-->
            <div class="kong"></div>
            <div class="ren_lc_ks cl">
                <span class="ren_lc_ksz z">{lang latest_comments}</span>
            </div>

            <!--{loop $postlist $postid $post}-->
            <!--{if $postid && !$post['first']}-->
            <div class="ren_view_ny cl" id="pid$post[pid]">
                <!--{subtemplate forum/viewthread_from_node}-->
            </div>
            <!--{/if}-->
            <!--{/loop}-->
            <!--{if $multipage}-->
            <div id="post_new" class="ren_post_new cl"></div>
            $multipage
            <!--{/if}-->
		</div>
	</div>
</div>
<!--{hook/viewthread_bottom_mobile}-->
<!--{if $rtj1009_m_config['ren_view_footer'] ==1}-->
<div class="ren_view_share ren_view_footer">
    <!--{if $rtj1009_m_config['ren_view_ftfh']}--><a href="javascript:history.back();" class="ren_viewdi_fh back"><i class="icon ren-font">&#xe633;</i></a><!--{/if}-->
    <a class="ren_viewdi_hf<!--{if $rtj1009_m_config['ren_view_ftfh']}--> e<!--{/if}--> open-popup" data-popup=".popup-view"><span>{$rtj1009_lang['ren053']}</span></a>
    <!--{eval $recommend = DB::fetch_first("SELECT * FROM  ".DB::table('forum_memberrecommend')." WHERE  recommenduid=".$_G[uid]." and tid=".$_G['tid']."");}-->
    <a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_viewdi_dz" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}">
        <i class="icon ren-font<!--{if $recommend}--> color<!--{/if}-->"><!--{if $recommend}-->&#xe793;<!--{else}-->&#xe856;<!--{/if}--></i>
        <!--{if $rtj1009_m_config['ren_view_ftadd']}--><!--{if $_G['forum_thread']['recommend_add']}--><span id="recommendv_add" class="ren_view_ftadd">{$_G[forum_thread][recommend_add]}</span><!--{/if}--><!--{/if}-->
    </a>
    <!--{eval $isfavtimes = DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='tid' and id=".$_G['tid']."");}-->
    <a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_twsj_sc">
        <i class="icon ren-font<!--{if $isfavtimes}--> color<!--{/if}-->"><!--{if $isfavtimes}-->&#xe646;<!--{else}-->&#xe603;<!--{/if}--></i>
        <!--{if $rtj1009_m_config['ren_view_ftadd']}--><!--{if $_G['forum_thread']['favtimes']}--><span id="k_favorite" class="ren_view_ftadd">{$_G['forum_thread']['favtimes']}</span><!--{/if}--><!--{/if}-->
    </a>
    <a href="javascript:;" class="ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe742;</i></a>
</div>
<!--{else}-->
<div class="ren_view_share ren_view_foo">
    <a href="javascript:;" class="ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe613;</i>{$rtj1009_lang['ren089']}</a>
    <a class="ren_viewdi_hf open-popup" data-popup=".popup-view"><i class="icon ren-font">&#xe694;</i>{$rtj1009_lang['ren056']}</a>
    <a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_viewdi_dz" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" title="{lang maketoponce}" ><i class="icon ren-font">&#xe856;</i>{$rtj1009_lang['ren099']}</a>
</div>
<!--{/if}-->
<script type="text/javascript">
    $('.ren_share').ready(function(){
        var share = new ren_share({
            title : document.title,
            url   : window.location.href,
            desc  : document.getElementsByName('description')[0].content,
            img   : '$ren_wx_imgUrl',
        });
        $('.ren_share').click(function () {
            share.init(0,'.ren_view_share');
        });
    });
</script>
<div id="popup-share" class="popup popup-share">
    <div class="content-block">
        <div class="ren_tiefx_share">
            <div class="bdsharebuttonbox">
                <a href="javascript:;" class="popup_sqq" data-cmd="sqq"><p>{$rtj1009_lang['ren100']}</p></a>
                <a href="javascript:;" class="bds_qzone" data-cmd="qzone"><p>{$rtj1009_lang['ren101']}</p></a>
                <a href="javascript:;" class="bds_tsina" data-cmd="tsina"><p>{$rtj1009_lang['ren102']}</p></a>
                <a href="javascript:;" class="bds_weixin" data-cmd="weixin"><p>{$rtj1009_lang['ren103']}</p></a>
                <a href="javascript:;" class="bds_copy" data-cmd="copy"><p>{$rtj1009_lang['ren212']}</p></a>
            </div>
        </div>
    </div>
    <a href="javascript:;" class="ren_tiefx_qx close-popup">{$rtj1009_lang['ren012']}</a>
</div>

<div class="popup popup-view">
    <header class="bar bar-nav popup-view-nav">
        <div class="ren_nav cl">
            <a href="javascript:;" class="z ren-fh close-popup"><i class="icon ren-font">&#xe64d;</i></a>
            <div class="ren_top_dqwz z">
                <span>{$rtj1009_lang['ren056']}</span>
            </div>
        </div>
    </header>
    <div class="content-block">
        <div class="ren_lostpw">
            <!--{subtemplate forum/forumdisplay_fastpost}-->
        </div>
    </div>
</div>


<script type="text/javascript">
    $('.favbtn').on('click', function() {
        var obj = $(this);
        $.ajax({
            type:'POST',
            url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
            data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
            dataType:'xml',
        })
            .success(function(s) {
                popup.open(s.lastChild.firstChild.nodeValue);
                evalscript(s.lastChild.firstChild.nodeValue);
            })
            .error(function() {
                window.location.href = obj.attr('href');
                popup.close();
            });
        return false;
    });
</script>

<!--{template common/footer}-->