<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<div class="tip ren-rate-tip ren-gmgroup-tip">
    <form id="attachpayform" method="post" autocomplete="off" action="forum.php?mod=misc&action=attachpay&tid={$_G[tid]}{if !empty($_GET['infloat'])}&paysubmit=yes&infloat=yes" onsubmit="ajaxpost('attachpayform', 'return_$_GET['handlekey']', 'return_$_GET['handlekey']', 'onerror');return false;"{else}"{/if}>
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="referer" value="{echo dreferer()}" />
        <input type="hidden" name="aid" value="$aid" />
        <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
    <div class="ren-rate-nav cl">
        <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
        <div class="ren-post-nav cl">
            <div class="ren-post-wall">
                <span>{lang pay_attachment}</span>
            </div>
        </div>
    </div>
    <div class="list-block">
        <ul>
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang author}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $attach[author]
                        </div>
                    </div>
                </div>
            </li>
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang attachment}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $attach[filename]
                        </div>
                    </div>
                </div>
            </li>
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang price}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}
                        </div>
                    </div>
                </div>
            </li>
            <!--{if $status != 1}-->
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang pay_author_income}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $attach[netprice] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}
                        </div>
                    </div>
                </div>
            </li>
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang pay_balance}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $balance {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}
                        </div>
                    </div>
                </div>
            </li>
            <!--{/if}-->
            <li class="ren-usgroup-tsli">
                <p>
                    <!--{if $status == 1}-->
                    {lang status_insufficient}
                    <!--{elseif $status == 2}-->
                    {lang status_download}
                    <br >
                    <!--{/if}-->
                    <!--{if $attach['description']}-->
                    $attach[description]
                    <!--{/if}-->
                </p>
            </li>
        </ul>
    </div>
    <p class="ren_login btn_login">
        <button type="submit" name="paysubmit" value="true" class="pn button ren_btn"><!--{if $status == 0}-->{lang pay_attachment}<!--{else}-->{lang free_buy}<!--{/if}--></button>
    </p>
    </form>
</div>
<!--{if !empty($_GET['infloat'])}-->
<script type="text/javascript" reload="1">
function succeedhandle_$_GET['handlekey'](locationhref) {
	ajaxget('forum.php?mod=viewthread&tid=$attach[tid]&viewpid=$attach[pid]', 'post_$attach[pid]');
	hideWindow('$_GET['handlekey']');
	showCreditPrompt();
}
</script>
<!--{/if}-->
<!--{template common/footer}-->