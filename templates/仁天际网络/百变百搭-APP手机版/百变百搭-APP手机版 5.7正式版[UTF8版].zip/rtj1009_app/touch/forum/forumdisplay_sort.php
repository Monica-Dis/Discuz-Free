<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="z ren_threadlist cl">
    <ul class="ren_fllb_tie cl">
		$sorttemplate['body']
    </ul>
</div>

