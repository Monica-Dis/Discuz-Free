<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="tip ren-rate-tip ren-gmgroup-tip">
<!--{if ($_GET['optgroup'] == 1 && $operation == '') || ($_GET['optgroup'] == 2 && $operation == '') || ($_GET['optgroup'] == 3 && $operation == 'delete') || ($_GET['optgroup'] == 3 && $operation == 'bump') || ($_GET['optgroup'] == 3 && $operation == 'down') || ($_GET['optgroup'] == 4 && $operation == '') || ($_GET['optgroup'] == 5 && $operation == '')}-->
<!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/ren_lang.'.currentlang().'.php';}-->
    <form id="moderateform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&action=moderate&optgroup=$optgroup&modsubmit=yes&mobile=2" >
        <input type="hidden" name="frommodcp" value="$frommodcp" />
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="fid" value="$_G[fid]" />
        <input type="hidden" name="redirect" value="{echo dreferer()}" />
        <input type="hidden" name="reason" value="{lang topicadmin_mobile_mod}" />
        <!--{loop $threadlist $thread}-->
            <input type="hidden" name="moderate[]" value="$thread[tid]" />
        <!--{/loop}-->
        <!--{if $_GET['optgroup'] == 1}-->
        <div class="ren-rate-nav cl">
            <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
            <div class="ren-post-nav cl">
                <div class="ren-post-wall">
                    <span>{lang thread_stick}</span>
                </div>
            </div>
        </div>
        <div class="list-block ren-stick-block">
            <ul>
                <!--{if count($threadlist) > 1 || empty($defaultcheck[recommend])}-->
                <!--{if $_G['group']['allowstickthread']}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{$rtj1009_lang['ren187']}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="operations[]" value="stick" $defaultcheck[stick] checked="checked" />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="item-content ren-webki">
                        <div class="item-media">{$rtj1009_lang['ren188']}</div>
                        <div class="item-inner">
                            <div class="item-input">
                                <select class="ps" name="sticklevel">
                                    <!--{if $_G['forum']['status'] != 3}-->
                                    <option value="0">{lang none}</option>
                                    <option value="1" $stickcheck[1]>$_G['setting']['threadsticky'][2]</option>
                                    <!--{if $_G['group']['allowstickthread'] >= 2}-->
                                    <option value="2" $stickcheck[2]>$_G['setting']['threadsticky'][1]</option>
                                    <!--{if $_G['group']['allowstickthread'] == 3}-->
                                    <option value="3" $stickcheck[3]>$_G['setting']['threadsticky'][0]</option>
                                    <!--{/if}-->
                                    <!--{/if}-->
                                    <!--{else}-->
                                    <option value="0">{lang no}&nbsp;</option>
                                    <option value="1" $stickcheck[1]>{lang yes}&nbsp;</option>
                                    <!--{/if}-->
                                </select>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{/if}-->
                <!--{/if}-->
            </ul>
        </div>
        <p class="ren_login btn_login">
            <button type="submit" name="modsubmit" id="modsubmit" class="formdialog pn button ren_btn" value="{lang confirms}">{lang confirms}</button>
        </p>
        <!--{elseif $_GET['optgroup'] == 2}-->
        <div class="ren-rate-nav cl">
            <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
            <div class="ren-post-nav cl">
                <div class="ren-post-wall">
                    <span>{lang modmenu_move}</span>
                </div>
            </div>
        </div>
        <div class="list-block ren-stick-block">
            <ul>
                <li>
                    <div class="item-content ren-webki">
                        <input type="hidden" name="operations[]" value="move" />
                        <div class="item-media">{lang admin_target}</div>
                        <div class="item-inner">
                            <div class="item-input">
                                <select name="moveto" id="moveto" class="ps" onchange="ajaxget('forum.php?mod=ajax&action=getthreadtypes&fid=' + this.value, 'threadtypes');if(this.value) {document.getElementById('moveext').style.display='';} else {document.getElementById('moveext').style.display='none';}">
                                    $forumselect
                                </select>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="item-content ren-webki">
                        <div class="item-media">{lang admin_targettype}</div>
                        <div class="item-inner">
                            <div id="threadtypes" class="item-input">
                                <select name="threadtypeid" class="ps"><option value="0" /></option></select>
                            </div>
                        </div>
                    </div>
                </li>
                <li id="moveext" style="display:none;">
                    <div class="item-content">
                        <div class="item-media">{lang admin_move}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label class="label-switch">
                                    <input type="radio" name="type" value="normal" checked="checked" />
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="item-content">
                        <div class="item-media">{lang admin_move_hold}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label class="label-switch">
                                    <input type="radio" name="type" value="redirect" />
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang admin_pm}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="sendreasonpm" id="sendreasonpm"{if $_G['group']['reasonpm'] == 2 || $_G['group']['reasonpm'] == 3} checked="checked" disabled="disabled"{/if} />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
            </ul>
        </div>
        <p class="ren_login btn_login">
            <button type="submit" name="modsubmit" id="modsubmit" class="formdialog pn button ren_btn" value="{lang confirms}">{lang confirms}</button>
        </p>

        <div class="tplw">
            <!--{if $operation != 'type'}-->
            <input type="hidden" name="operations[]" value="move" />
            <ul class="llst" id="moveext" style="display:none;">
                <li class="wide"><label><input type="radio" name="type" class="pr" value="normal" checked="checked" />{lang admin_move}</label></li>
                <li class="wide"><label><input type="radio" name="type" class="pr" value="redirect" />{lang admin_move_hold}</label></li>
            </ul>
            <!--{else}-->
            <!--{if $typeselect}-->
            <input type="hidden" name="operations[]" value="type" />
            <p>{lang types}: $typeselect</p>
            <!--{else}-->
            {lang admin_type_msg}<!--{eval $hiddensubmit = true;}-->
            <!--{/if}-->
            <!--{/if}-->
        </div>
        <!--{elseif $_GET['optgroup'] == 3}-->
                <!--{if $operation == 'delete'}-->
                    <!--{if $_G['group']['allowdelpost']}-->
                        <input name="operations[]" type="hidden" value="delete"/>
                        <dt>{lang admin_delthread_confirm}</dt>
                        <dd><input type="submit" class="formdialog button2" name="modsubmit" id="modsubmit"  value="{lang confirms}"><a href="javascript:;" onclick="popup.close();">{lang cancel}</a></dd>
                    <!--{else}-->
                        <dt>{lang admin_delthread_nopermission}</dt>
                    <!--{/if}-->
                <!--{elseif $operation == 'down'}-->
                    <div class="ren-rate-nav cl">
                        <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
                        <div class="ren-post-nav cl">
                            <div class="ren-post-wall">
                                <span>{lang admin_down}</span>
                            </div>
                        </div>
                    </div>
                    <div class="list-block ren-stick-block">
                        <ul>
                            <li>
                                <div class="item-content">
                                    <div class="item-media">{lang admin_down}</div>
                                    <div class="item-inner ren-sendreasonpm">
                                        <div class="item-input">
                                            <label for="sendreasonpm" class="label-switch">
                                                <input type="checkbox" name="operations[]" value="down" checked="checked" />
                                                <div class="checkbox"></div>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <p class="ren_login btn_login">
                        <button type="submit" name="modsubmit" id="modsubmit" class="formdialog pn button ren_btn" value="{lang confirms}">{lang confirms}</button>
                    </p>
                <!--{elseif $operation == 'bump'}-->
                    <div class="ren-rate-nav cl">
                        <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
                        <div class="ren-post-nav cl">
                            <div class="ren-post-wall">
                                <span>{lang admin_bump}</span>
                            </div>
                        </div>
                    </div>
                    <div class="list-block ren-stick-block">
                        <ul>
                            <li>
                                <div class="item-content">
                                    <div class="item-media">{lang admin_bump}</div>
                                    <div class="item-inner ren-sendreasonpm">
                                        <div class="item-input">
                                            <label for="sendreasonpm" class="label-switch">
                                                <input type="checkbox" name="operations[]" value="bump" checked="checked" />
                                                <div class="checkbox"></div>
                                            </label>
                                        </div>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <p class="ren_login btn_login">
                        <button type="submit" name="modsubmit" id="modsubmit" class="formdialog pn button ren_btn" value="{lang confirms}">{lang confirms}</button>
                    </p>
                <!--{/if}-->

        <!--{elseif $_GET['optgroup'] == 4}-->
        <div class="ren-rate-nav cl">
            <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
            <div class="ren-post-nav cl">
                <div class="ren-post-wall">
                    <span><!--{if $closecheck[0]}-->{lang modmenu_switch_off}<!--{else}-->{lang modmenu_switch_on}<!--{/if}--></span>
                </div>
            </div>
        </div>
        <div class="list-block ren-stick-block">
            <ul>
                <!--{if $closecheck[0]}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang admin_open}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="operations[]" value="open" $closecheck[0] />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{elseif $closecheck[1]}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang admin_close}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="operations[]" value="close" $closecheck[1] />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{/if}-->
            </ul>
        </div>
        <p class="ren_login btn_login">
            <button type="submit" name="modsubmit" id="modsubmit" class="formdialog pn button ren_btn" value="{lang confirms}">{lang confirms}</button>
        </p>
        <!--{elseif $_GET['optgroup'] == 5}-->
        <div class="ren-rate-nav cl">
            <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
            <div class="ren-post-nav cl">
                <div class="ren-post-wall">
                    <span>{lang admin_digest_add}</span>
                </div>
            </div>
        </div>
        <div class="list-block ren-stick-block">
            <ul>
                <!--{if count($threadlist) > 1 || empty($defaultcheck[recommend])}-->
                <!--{if $_G['group']['allowdigestthread']}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{$rtj1009_lang['ren202']}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="operations[]" value="digest" $defaultcheck[digest] checked="checked" />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="item-content ren-webki">
                        <div class="item-media">{$rtj1009_lang['ren203']}</div>
                        <div class="item-inner">
                            <div class="item-input">
                                <select class="ps" name="digestlevel">
                                    <option value="0">{lang admin_digest_remove}</option>
                                    <option value="1" $digestcheck[1]>{lang thread_digest} 1</option>
                                    <!--{if $_G['group']['allowdigestthread'] >= 2}-->
                                    <option value="2" $digestcheck[2]>{lang thread_digest} 2</option>
                                    <!--{if $_G['group']['allowdigestthread'] == 3}-->
                                    <option value="3" $digestcheck[3]>{lang thread_digest} 3</option>
                                    <!--{/if}-->
                                    <!--{/if}-->
                                </select>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{/if}-->
                <!--{/if}-->
            </ul>
            <p class="ren_login btn_login">
                <button type="submit" name="modsubmit" id="modsubmit" class="formdialog pn button ren_btn" value="{lang confirms}">{lang confirms}</button>
            </p>
        </div>
        <!--{/if}-->
    </form>
<!--{else}-->
    	<dt>{lang admin_threadtopicadmin_error}</dt>
		<dd><input type="button" onclick="popup.close();" value="{lang confirms}" class="button2"></dd>
<!--{/if}-->
</div>
<!--{template common/footer}-->
