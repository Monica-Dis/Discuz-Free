<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="tip ren-hf-post">
<form method="post" autocomplete="off" id="commentform" action="forum.php?mod=post&action=reply&comment=yes&tid=$post[tid]&pid=$_GET[pid]&extra=$extra{if !empty($_GET[page])}&page=$_GET[page]{/if}&commentsubmit=yes&infloat=yes">
    <div class="post_from ren_kshf cl">
        <div class="cl">
            <div class="ren-post-nav cl">
                <div id="return_$_GET['handlekey']" class="ren-post-wall"><span>{lang comments}</span></div>
            </div>
            <input type="hidden" name="formhash" id="formhash" value="{FORMHASH}" />
            <input type="hidden" name="handlekey" value="$_GET['handlekey']" />
            <div class="ren_post_nr cl">
                <textarea rows="3" cols="80" name="message" id="commentmessage" tabindex="3" placeholder="{lang comment_message1} 200 {lang comment_message2}"></textarea>
                <div id="seccheck_comment">
                    <!--{if $secqaacheck || $seccodecheck}-->
                        <!--{subtemplate forum/seccheck_post}-->
                    <!--{/if}-->
                </div>
            </div>
        </div>
	</div>

    <dd>
        <input type="submit" name="commentsubmit" id="commentsubmit" value="{lang publish}" class="formdialog button2 color">
        <a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
    </dd>
</form>
</div>
<!--{template common/footer}-->