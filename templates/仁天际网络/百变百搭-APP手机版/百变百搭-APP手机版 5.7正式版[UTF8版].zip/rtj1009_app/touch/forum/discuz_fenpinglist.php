<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>

<div class="menu-left scrollbar-none" id="sidebar"<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}--> style="top: 45px;"<!--{/if}-->>
    <ul>
	    <li id="tab0" class="active">{$rtj1009_lang['ren197']}</li>
	<!--{loop $catlist $key $cat}-->
        <li id="tab$cat[fid]">$cat[name]</li>
	<!--{/loop}-->
    </ul>
</div>

	<div class="menu-right padding-all j-content"<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}--> style="top: 45px;"<!--{/if}-->>
<!--{if $rtj1009_m_config['ren_forum_shuju']}-->
        <div class="ren-f-count cl">
            <ul class="cl">
                <li>
                    <p>{$rtj1009_lang['ren036']}</p>
                    <em>$todayposts</em>
                </li>
                <li>
                    <p>{$rtj1009_lang['ren037']}</p>
                    <em>$posts</em>
                </li>
                <li>
                    <p>{$rtj1009_lang['ren038']}</p>
                    <em>$_G['cache']['userstats']['totalmembers']</em>
                </li>
            </ul>
        </div>
<!--{/if}-->
        <div class="ren-tj-bt">{$rtj1009_lang['ren198']}</div>
		<!--{if empty($gid) && !empty($forum_favlist)}-->
		<ul class="cl">
			<!--{eval $favorderid = 0;}--> 
			<!--{loop $forum_favlist $key $favorite}-->
			<li> 
				<!--{if $favforumlist[$favorite[id]]}--> 
				<!--{eval $forum=$favforumlist[$favorite[id]];}--> 
				<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
                <div class="ren-bk-img">
                    <!--{if $forum[icon]}-->
                    $forum[icon]
                    <!--{else}-->
                    <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                        <img src="{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg" alt="$forum[name]" />
                    </a>
                    <!--{/if}-->
                    <!--{if $rtj1009_m_config['ren_forum_num'] == 1}--><!--{if $forum[todayposts] > 0}--><span class="ren-bk-nums">$forum[todayposts]</span><!--{/if}--><!--{/if}-->
                </div>
				<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="ren_bkbt">
					<span>{$forum[name]}</span>
					<em>{$rtj1009_lang['ren042']}<!--{echo dnumber($forum[threads])}--></em>
					<em>{$rtj1009_lang['ren043']}<!--{echo dnumber($forum[posts])}--></em>
				</a>

				<!--{eval $ren_forum_gz = DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$forum['fid']."");}-->
				<!--{if $ren_forum_gz[id]}-->
				<a class="dialog ren_bklist_gz ren_qxgz" href="home.php?mod=spacecp&ac=favorite&op=delete&favid={$ren_forum_gz[favid]}&type=forum">{$rtj1009_lang['ren012']}</a>
				<!--{/if}-->
				<!--{/if}-->
			</li>
			<!--{/loop}-->
		</ul>
		<!--{else}-->
		<div class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<!--{if !$_G[uid] && !$_G['connectguest']}-->
			<span>{$rtj1009_lang['ren044']}</span>
			<!--{else}-->
			<span>{$rtj1009_lang['ren045']}</span>
			<!--{/if}-->
		</div>
		<!--{/if}-->
        <div class="ren-forums-list">
            <div class="ren-tj-bt">{$rtj1009_lang['ren199']}</div>
            <!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/rtj1009_forum.php';}-->
            <!--{if !empty($forums_list)}-->
            <ul class="cl">
                <!--{loop $forums_list $key $forums_lists}-->
                <!--{eval $ren_forum_gzs = DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$forums_lists['fid']."");}-->
                <!--{eval $ren_forum_ico = rtj1009_ficoisurl($forums_lists[icon]);}-->
                <!--{if !$ren_forum_gzs[id]}-->
                <li>
                    <div class="ren-bk-img">
                        <a href="forum.php?mod=forumdisplay&fid={$forums_lists['fid']}">
                            <img src="<!--{if $forums_lists[icon]}-->$ren_forum_ico<!--{else}-->{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg<!--{/if}-->" alt="{$_G['forum'][name]}">
                        </a>
                        <!--{if $rtj1009_m_config['ren_forum_num'] == 1}-->
                        <!--{if $forums_lists[todayposts] > 0}--><span class="ren-bk-nums">$forums_lists[todayposts]</span><!--{/if}-->
                        <!--{/if}-->
                    </div>
                    <a href="forum.php?mod=forumdisplay&fid={$forums_lists['fid']}" class="ren_bkbt">
                        <span>{$forums_lists[name]}</span>
                        <em>{$rtj1009_lang['ren042']}<!--{echo dnumber($forums_lists[threads])}--></em>
                        <em>{$rtj1009_lang['ren043']}<!--{echo dnumber($forums_lists[posts])}--></em>
                    </a>

                    <a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_bklist_gz" href="home.php?mod=spacecp&ac=favorite&type=forum&id={$forums_lists['fid']}&handlekey=favoriteforum&formhash={FORMHASH}">{$rtj1009_lang['ren022']}</a>
                </li>
                <!--{/if}-->
                <!--{/loop}-->
            </ul>
            <!--{else}-->
            <div class="ren_ss_wu">
                <i class="icon ren-font">&#xe608;</i>
                <span>{$rtj1009_lang['ren200']}</span>
            </div>
            <!--{/if}-->
        </div>
	</div>


	<!--{loop $catlist $key $cat}-->
	<div class="menu-right padding-all j-content" style="display: none;<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}--> top: 45px;<!--{/if}-->">
		<ul class="cl">
			<!--{loop $cat[forums] $forumid}-->
			<!--{eval $forum=$forumlist[$forumid];}-->
			<li>
                <div class="ren-bk-img">
                    <!--{if $forum[icon]}-->
                    $forum[icon]
                    <!--{else}-->
                    <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                        <img src="{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg" alt="$forum[name]" />
                    </a>
                    <!--{/if}-->
                    <!--{if $rtj1009_m_config['ren_forum_num'] == 1}--><!--{if $forum[todayposts] > 0}--><span class="ren-bk-nums">$forum[todayposts]</span><!--{/if}--><!--{/if}-->
                </div>
				<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="ren_bkbt">
					<span>{$forum[name]}</span>
					<em>{$rtj1009_lang['ren042']}<!--{echo dnumber($forum[threads])}--></em>
					<em>{$rtj1009_lang['ren043']}<!--{echo dnumber($forum[posts])}--></em>
				</a>
				<!--{eval $ren_forum_gz = DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$forum['fid']."");}-->
				<!--{if $ren_forum_gz[id]}-->
				<a class="dialog ren_bklist_gz ren_qxgz" href="home.php?mod=spacecp&ac=favorite&op=delete&favid={$ren_forum_gz[favid]}&type=forum">{$rtj1009_lang['ren030']}</a>
				<!--{else}-->
				<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_bklist_gz" href="home.php?mod=spacecp&ac=favorite&type=forum&id={$forum['fid']}&handlekey=favoriteforum&formhash={FORMHASH}">{$rtj1009_lang['ren022']}</a>
				<!--{/if}-->
			</li>
			<!--{/loop}-->
		</ul>
	</div>
	<!--{/loop}-->

<script type="text/javascript" src='template/rtj1009_app/js/ectouch.js'></script>
<script type="text/javascript">
    $(function($){
        $('#sidebar ul li').click(function(){
            $(this).addClass('active').siblings('li').removeClass('active');
            var index = $(this).index();
            $('.j-content').eq(index).show().siblings('.j-content').hide();
        })
    })
</script>