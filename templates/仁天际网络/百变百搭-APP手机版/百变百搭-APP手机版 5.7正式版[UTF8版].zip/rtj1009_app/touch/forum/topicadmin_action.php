<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="tip ren-rate-tip ren-gmgroup-tip">
<!--{if in_array($_GET[action], array('delpost', 'banpost', 'warn'))}-->
	<form id="topicadminform" method="post" autocomplete="off" action="forum.php?mod=topicadmin&action=$_GET[action]&modsubmit=yes&modclick=yes&mobile=2" >
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="fid" value="$_G[fid]" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<input type="hidden" name="page" value="$_G[page]" />
		<input type="hidden" name="reason" value="{lang topicadmin_mobile_mod}" />
    <!--{if $_GET[action] == 'delpost'}-->
            <dt>{lang admin_delpost_confirm}</dt>
            $deleteid
			<dd><input type="submit" name="modsubmit" id="modsubmit" value="{lang confirms}" class="formdialog button2"><a href="javascript:;" onclick="popup.close();" >{lang cancel}</a></dd>
	<!--{elseif $_GET[action] == 'banpost'}-->
        <div class="ren-rate-nav cl">
            <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
            <div class="ren-post-nav cl">
                <div class="ren-post-wall">
                    <span>{lang admin_banpost_confirm}</span>
                </div>
            </div>
        </div>
        <div class="list-block ren-stick-block">
            <ul>
                $banid
                <!--{if $checkban}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang admin_banpost}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="banned" value="1" $checkban />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{elseif $checkunban}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang admin_unbanpost}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="banned" value="0" $checkunban />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{/if}-->
            </ul>
        </div>
        <p class="ren_login btn_login">
            <button type="submit" name="modsubmit" id="modsubmit" class="formdialog pn button ren_btn" value="{lang confirms}">{lang confirms}</button>
        </p>
    <!--{elseif $_GET[action] == 'warn'}-->
        <div class="ren-rate-nav cl">
            <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
            <div class="ren-post-nav cl">
                <div class="ren-post-wall">
                    <span>{lang admin_warn_confirm}</span>
                </div>
            </div>
        </div>
        <div class="list-block ren-stick-block">
            <ul>
                $warnpid
                <!--{if $checkwarn}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang topicadmin_warn_add}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="warned" value="1" $checkwarn />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{elseif $checkunwarn}-->
                <li>
                    <div class="item-content">
                        <div class="item-media">{lang topicadmin_warn_delete}</div>
                        <div class="item-inner ren-sendreasonpm">
                            <div class="item-input">
                                <label for="sendreasonpm" class="label-switch">
                                    <input type="checkbox" name="warned" value="0" $checkunwarn />
                                    <div class="checkbox"></div>
                                </label>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{/if}-->
            </ul>
        </div>
        <p class="ren_login btn_login">
            <button type="submit" name="modsubmit" id="modsubmit" class="formdialog pn button ren_btn" value="{lang confirms}">{lang confirms}</button>
        </p>
    <!--{/if}-->
    </form>
<!--{else}-->
    	<dt>{lang admin_threadtopicadmin_error}</dt>
		<dd><input type="button" onclick="popup.close();" value="{lang confirms}" /></dd>
<!--{/if}-->
</div>
<!--{template common/footer}-->
