<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span class="ren_bk_name">
			<!--{if $rtj1009_m_config['ren_m_view_nav'] == 1}-->
				<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
				</a>
			<!--{else}-->
				<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}">{$rtj1009_lang['ren086']}</a>
			<!--{/if}-->
			</span>
		</div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content ren-view-main">
	<div class="ren-rate-tj cl">
		<span>{lang total}: </span>
		<!--{loop $logcount $id $count}-->
		&nbsp;{$_G['setting']['extcredits'][$id][title]} <!--{if $count>0}-->+<!--{/if}-->$count {$_G['setting']['extcredits'][$id][unit]} &nbsp;
		<!--{/loop}-->
	</div>
	<div class="ren-view-log">
		<ul class="cl">
		<!--{loop $loglist $log}-->
				<li>
					<a href="home.php?mod=space&uid=$log[uid]&do=profile" class="ren-view-logimg">
						<img src="<!--{avatar($log[uid], middle, true)}-->">
						<div class="y time">$log[dateline]</div>
						<div class="ren-view-author">
							<span>$log[username]</span>
							<p>{$_G['setting']['extcredits'][$log[extcredits]][title]} $log[score] {$_G['setting']['extcredits'][$log[extcredits]][unit]}</p>
						</div>
					 	<div class="ren-view-reason">$log[reason]</div>
					</a>
				</li>
			<!--{/loop}-->
		</ul>
	</div>
</div>
<!--{eval $nofooter = true;}--> 
<!--{template common/footer}-->