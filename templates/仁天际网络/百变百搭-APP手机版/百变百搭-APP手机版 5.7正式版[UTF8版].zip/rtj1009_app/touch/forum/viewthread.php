<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $threadsort = $threadsorts = null;}-->
<!--{template common/header}-->
<script type="text/javascript" src="template/rtj1009_app/js/jQuery.rTabs.js"></script>
<script type="text/javascript" src='template/rtj1009_app/js/ren_share.js'></script>

<style type="text/css">
	.tab { position: relative; overflow: hidden; }
	.tab-con { position: relative; }
</style>

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:;" onclick="renBack()" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span class="ren_bk_name">
			<!--{if $rtj1009_m_config['ren_m_view_nav'] == 1}-->
				<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
				</a>
			<!--{else}-->
				<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}">{$rtj1009_lang['ren088']}</a>
			<!--{/if}-->
			</span>
		</div>
		<div class="ren_nav_right">
            <div class="ren_view_navgd open-popover"><span class="icon ren-font">&#xe614;</span></div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<!--{eval $firstpid = rtj1009_isfirst($thread['tid']);}-->
<div class="ren_nav_gd popover">
	<div class="popover-angle on-top"></div>
	<div class="ren_gd_list close-popover cl">
		<a id="ren_share" href="javascript:;" class="ren_viewdi_fx ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe613;</i><span>{$rtj1009_lang['ren089']}</span></a>
		<a href="misc.php?mod=report&rtype=post&rid={$firstpid[pid]}&tid=$_G[tid]&fid=$_G[fid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_gd_jb close-popover"><i class="icon ren-font" style="font-size: 20px;">&#xe66b;</i><span>{$rtj1009_lang['ren090']}</span></a>
        <a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="ren_gd_fh"><i class="icon ren-font">&#xe619;</i><span>{$rtj1009_lang['ren003']}</span></a>
        <!--{if $_G['setting']['magicstatus']}-->
            <!--{if !empty($_G['setting']['magics']['showip'])}-->
            <a href="javascript:;" id="mgc_post_{$firstpid[pid]}" class="open-popup ren_lc_magic" data-popup=".popup-view-magic-{$firstpid[pid]}"><i class="icon ren-font">&#xe647;</i><span>{lang thread_magic}</span></a>
            <!--{/if}-->
        <!--{/if}-->
		<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}" class="ren_gd_fh"><i class="icon ren-font">&#xe641;</i><span>{$rtj1009_lang['ren091']}</span></a>
        <a href="portal.php?mod=index" class="ren_gd_fh"><i class="icon ren-font">&#xe605;</i><span>{$rtj1009_lang['ren201']}</span></a>
	</div>
</div>

<!--{if $_G['setting']['magicstatus']}-->
<div class="popup popup-view-gl popup-view-magic-{$firstpid[pid]}">
    <div class="content-block">
        <div class="ren_lostpw">
            <!--{if $firstpid['first']}-->
            <!--{if !empty($_G['setting']['magics']['bump'])}-->
            <a href="home.php?mod=magic&mid=bump&idtype=tid&id=$_G[tid]" id="a_bump" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/bump.small.gif" class="vm" />$_G['setting']['magics']['bump']</a>
            <!--{/if}-->
            <!--{if !empty($_G['setting']['magics']['stick'])}-->
            <a href="home.php?mod=magic&mid=stick&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/stick.small.gif" class="vm" />$_G['setting']['magics']['stick']</a>
            <!--{/if}-->
            <!--{if !empty($_G['setting']['magics']['close'])}-->
            <a href="home.php?mod=magic&mid=close&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/close.small.gif" class="vm" />$_G['setting']['magics']['close']</a>
            <!--{/if}-->
            <!--{if !empty($_G['setting']['magics']['open'])}-->
            <a href="home.php?mod=magic&mid=open&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/open.small.gif" class="vm" />$_G['setting']['magics']['open']</a>
            <!--{/if}-->
            <!--{if !empty($_G['setting']['magics']['highlight'])}-->
            <a href="home.php?mod=magic&mid=highlight&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/highlight.small.gif" class="vm" />$_G['setting']['magics']['highlight']</a></li>
            <!--{/if}-->
            <!--{if !empty($_G['setting']['magics']['sofa'])}-->
            <a href="home.php?mod=magic&mid=sofa&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/sofa.small.gif" class="vm" />$_G['setting']['magics']['sofa']</a>
            <!--{/if}-->
            <!--{if !empty($_G['setting']['magics']['jack'])}-->
            <a href="home.php?mod=magic&mid=jack&idtype=tid&id=$_G[tid]" id="a_jack" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/jack.small.gif" class="vm" />$_G['setting']['magics']['jack']</a>
            <!--{/if}-->
            <!--{/if}-->
            <!--{if !empty($_G['setting']['magics']['repent']) && $post['authorid'] == $_G['uid'] && !$rushreply}-->
            <a href="home.php?mod=magic&mid=repent&idtype=pid&id=$post[pid]:$_G[tid]" id="a_repent_$post[pid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/repent.small.gif" class="vm" />$_G['setting']['magics']['repent']</a>
            <!--{/if}-->
            <!--{if !empty($_G['setting']['magics']['anonymouspost']) && $post['authorid'] == $_G['uid']}-->
            <a href="home.php?mod=magic&mid=anonymouspost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_anonymouspost_$post[pid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/anonymouspost.small.gif" class="vm" />$_G['setting']['magics']['anonymouspost']</a>
            <!--{/if}-->
            <!--{if !empty($_G['setting']['magics']['namepost'])}-->
            <a href="home.php?mod=magic&mid=namepost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_namepost_$post[pid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/namepost.small.gif" class="vm" />$_G['setting']['magics']['namepost']</a>
            <!--{/if}-->
        </div>
    </div>
    <div class="ren-close">
        <a href="javascript:;" class="close-popup">{$rtj1009_lang['ren012']}</a>
    </div>
</div>
<!--{/if}-->

<div class="content ren-view-main<!--{if $rtj1009_m_config['ren_view_footer'] ==1}--> ren-view-b48<!--{/if}-->">
<!--{hook/viewthread_top_mobile}-->
<!-- main postlist start -->
	<div class="postlist rtj1009_m_main">
        {$block_viewthread_top}
		<div class="ren_view_xxtop<!--{if $rtj1009_m_config['ren_view_topxx'] !=1}--> xian<!--{/if}-->">
			<h3>
                <!--{if $rtj1009_m_config['ren_view_sortid']}-->
                <!--{if $_G['forum_thread']['typeid'] && $_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}-->
                    <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$_G[forum_thread][typeid]" class="color">[{$_G['forum']['threadtypes']['types'][$_G['forum_thread']['typeid']]}]</a>
                <!--{/if}-->
                <!--{if $threadsorts && $_G['forum_thread']['sortid']}-->
                    <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$_G[forum_thread][sortid]" class="color">[{$_G['forum']['threadsorts']['types'][$_G['forum_thread']['sortid']]}]</a>
                <!--{/if}-->
                <!--{/if}-->
                $_G[forum_thread][subject]
                <!--{if $_G['forum_thread'][displayorder] == -2}--> <span>({lang moderating})</span>
                    <!--{elseif $_G['forum_thread'][displayorder] == -3}--> <span>({lang have_ignored})</span>
                    <!--{elseif $_G['forum_thread'][displayorder] == -4}--> <span>({lang draft})</span>
                <!--{/if}-->
			</h3>
			<!--{if $rtj1009_m_config['ren_view_topxx'] ==1}-->
			<div class="ren_twsj_xx">
				<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="favbtn ren_twsj_sc"><i class="icon ren-font">&#xe603;</i>{$_G['forum_thread']['favtimes']}</a>
				<a class="favbtn ren_view_d" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}"><i class="icon ren-font">&#xe856;</i>$_G[forum_thread][recommend_add]</a>
				<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
				<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
			</div>
			<!--{/if}-->
			<!--{if $rtj1009_m_config['ren_view_topxx'] ==3}-->
			<div class="ren_view_topxx3">
				<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}" class="z">{$rtj1009_lang['ren137']}<span><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}--></span></a>
				<span class="ren_twsj_hf"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
				<span class="ren_twsj_ck"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
			</div>
			<!--{/if}-->
		</div>
	
	
		<!--{eval $postcount = 0;}-->
		<!--{loop $postlist $post}-->
		<!--{eval $needhiddenreply = ($hiddenreplies && $_G['uid'] != $post['authorid'] && $_G['uid'] != $_G['forum_thread']['authorid'] && !$post['first'] && !$_G['forum']['ismoderator']);}-->
		<!--{hook/viewthread_posttop_mobile $postcount}-->
		<!--{if $post[first]}-->
		   <div class="ren_view_ny cl" id="pid$post[pid]">
				<div class="ren_lc_xx cl">
					<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="avatar z"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->"/></a>
					<div class="ren_lc_zz cl">
						<div class="ren_lc_zzxx cl">
							<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
								<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren_zz_mz z">$post[author]</a>
							<!--{else}-->
								<!--{if !$post['authorid']}-->
									<a href="javascript:;" class="ren_zz_mz z">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
								<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
									<!--{if $_G['forum']['ismoderator']}-->
									<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren_zz_mz z">{lang anonymous}</a>
									<!--{else}-->
									<a href="javascript:;" class="ren_zz_mz z">{lang anonymous}</a>
									<!--{/if}-->
								<!--{else}-->
									$post[author] <em>{lang member_deleted}</em>
								<!--{/if}-->
							<!--{/if}-->
                            <!--{if ($rtj1009_m_config['ren_m_view_xing'] || $rtj1009_m_config['ren_view_utitle']) && $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                            <em class="z ren_us_xing"><!--{if $rtj1009_m_config['ren_m_view_xing']}-->Lv.{$post[stars]}<!--{/if}--><!--{if $rtj1009_m_config['ren_view_utitle']}--> {$post[authortitle]}<!--{/if}--></em>
                            <!--{/if}-->
							<!--{eval $shustars = DB::fetch_first("SELECT b.* FROM ".DB::table("common_member")." a LEFT JOIN ".DB::table("common_usergroup")." b on b.groupid=a.groupid WHERE a.`uid` = '$thread[authorid]'");}-->
							<!--{block authorverifys}-->
							<!--{loop $post['verifyicon'] $vid}-->
								<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid"><!--{if $_G['setting']['verify'][$vid]['icon']}--><img src="$_G['setting']['verify'][$vid]['icon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /><!--{else}-->$_G['setting']['verify'][$vid]['title']<!--{/if}--></a>
							<!--{/loop}-->
							<!--{loop $post['unverifyicon'] $vid}-->
								<a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><img src="$_G['setting']['verify'][$vid]['unverifyicon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /></a>
							<!--{/loop}-->
							<!--{/block}-->

							<div class="ren-verify z">
                                <!--{if $rtj1009_mobilecp['ren_m_view_verify']}-->
								$authorverifys
                                <!--{/if}-->
                                <!--{if $rtj1009_mobilecp['ren_m_view_shustars']}-->
                                    <!--{if $shustars[icon]}-->
                                        <span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
                                    <!--{/if}-->
                                <!--{/if}-->
							</div>
							<!--{if $rtj1009_m_config['ren_view_topxx'] ==2}-->
							<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
								<a class="y ren_zz_gz" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a>
							<!--{else}-->
								<!--{eval $isfollowuid = DB::result_first("SELECT followuid FROM ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$thread[authorid]");}-->
								<!--{if !$isfollowuid}-->
								<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_zz_gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]">{$rtj1009_lang['ren139']}</a>
								<!--{else}-->
								<a class="dialog ren_zz_gz ren_qxgz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$thread[authorid]">{$rtj1009_lang['ren140']}</a>
								<!--{/if}-->
							<!--{/if}-->
							<!--{if $_G['forum']['ismoderator']}-->
							<!-- manage start -->

								<div href="#moption_$post[pid]" class="open-popup ren_lc_gl" data-popup=".popup-view-lzgl">{lang manage}</div>
								<div class="popup popup-view-gl popup-view-lzgl">
									<div class="content-block">
										<div class="ren_lostpw ren-view-gl">
                                            <ul>
											<!--{if !$_G['forum_thread']['special']}-->
                                                <li><a class="redirect" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a></li>
											<!--{/if}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">{lang delete}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4"><!--{if !$_G['forum_thread']['closed']}-->{lang modmenu_switch_off}<!--{else}-->{lang modmenu_switch_on}<!--{/if}--></a></li>
                                            <!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=5">{lang modmenu_digestpost}</a></li>
                                            <!--{/if}-->
                                            <!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=1">{lang modmenu_stickthread}</a></li>
                                            <!--{/if}-->
                                            <!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=2">{lang modmenu_move}</a></li>
                                            <!--{/if}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{lang admin_banpost}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{lang topicadmin_warn_add}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=bump&optgroup=3&from={$_G[tid]}">{$rtj1009_lang['ren204']}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=down&optgroup=3&from={$_G[tid]}">{$rtj1009_lang['ren205']}</a></li>
                                            </ul>
										</div>
									</div>
									<div class="ren-close">
										<a href="javascript:;" class="close-popup">{$rtj1009_lang['ren012']}</a>
									</div>
								</div>
							<!-- manage end -->
							<!--{/if}-->
						<!--{if $_G['uid']}-->
						<!--{/if}-->
						<!--{/if}-->
						</div>
						<div class="ren_lc_sj cl">
							<span class="ren_lc_sjsj">$post[dateline]</span>
							<!--{if $rtj1009_m_config['ren_view_topxx'] ==2}-->
							<span class="ren_twsj_hf y"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
							<span class="ren_twsj_ck y"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
							<!--{else}-->
							<!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
								<a class="y ren_zz_gz" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a>
							<!--{else}-->
								<!--{eval $isfollowuid = DB::result_first("SELECT followuid FROM ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$thread[authorid]");}-->
								<!--{if !$isfollowuid}-->
								<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_zz_gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]">{$rtj1009_lang['ren139']}</a>
								<!--{else}-->
								<a class="dialog ren_zz_gz ren_qxgz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$thread[authorid]">{$rtj1009_lang['ren140']}</a>
								<!--{/if}-->
							<!--{/if}-->

							<!--{if $_G['forum']['ismoderator']}-->
							<!-- manage start -->
								<div href="#moption_$post[pid]" class="open-popup ren_lc_gl" data-popup=".popup-view-lzgl">{lang manage}</div>
								<div class="popup popup-view-gl popup-view-lzgl">
									<div class="content-block">
                                        <div class="ren_lostpw ren-view-gl">
                                            <ul>
                                                <!--{if !$_G['forum_thread']['special']}-->
                                                <li><a class="redirect" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a></li>
                                                <!--{/if}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">{lang delete}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">{lang close}</a></li>
                                                <!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=5">{lang modmenu_digestpost}</a></li>
                                                <!--{/if}-->
                                                <!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=1">{lang modmenu_stickthread}</a></li>
                                                <!--{/if}-->
                                                <!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=2">{lang modmenu_move}</a></li>
                                                <!--{/if}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{lang admin_banpost}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{lang topicadmin_warn_add}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=bump&optgroup=3&from={$_G[tid]}">{$rtj1009_lang['ren204']}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=down&optgroup=3&from={$_G[tid]}">{$rtj1009_lang['ren205']}</a></li>
                                            </ul>
                                        </div>
									</div>
									<div class="ren-close">
										<a href="javascript:;" class="close-popup">{$rtj1009_lang['ren012']}</a>
									</div>
								</div>
							<!-- manage end -->
							<!--{/if}-->
							<!--{/if}-->
						</div>
					</div>
				</div>

			   <div class="display pi" href="#replybtn_$post[pid]">
					<div class="message">
                        <!--{eval $post[message] = str_replace('target="_blank">', 'class="a-link">', $post[message]);}-->
							<!--{if $post['warned']}-->
								<span class="grey quote">{lang warn_get}</span>
							<!--{/if}-->
							<!--{if !$post['first'] && !empty($post[subject])}-->
								<h2><strong>$post[subject]</strong></h2>
							<!--{/if}-->
                        <!--{if $_G['forum_thread']['replycredit'] > 0}-->
                        <div class="ren-replycredit cl">
                            <div class="ren-reply">
                                {$rtj1009_lang['ren196']} {$_G['forum_thread']['replycredit']}{$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][unit]} {$_G['setting']['extcredits'][$_G[forum_thread][replycredit_rule][extcreditstype]][title]} {lang thread_replycredit_tips1} {lang thread_replycredit_tips2}<!--{if $_G['forum_thread']['replycredit_rule'][random] > 0}--><span class="xg1">{lang thread_replycredit_tips3}</span><!--{/if}-->
                            </div>
                        </div>
                        <!--{/if}-->
							<!--{if $rushreply}-->
								<div class="ren-locked ren_rwd ren-rushreply cl">
										<div class="ren-loc-z">
											<span class="ren-loc-txt">
										<!--{if $rushresult[creditlimit] == ''}-->
											{lang thread_rushreply}&nbsp;
										<!--{else}-->
											{lang thread_rushreply_limit} &nbsp;
										<!--{/if}-->
											</span>
											<!--{if !$_GET['checkrush']}-->
													<a href="forum.php?mod=viewthread&tid=$post[tid]&checkrush=1" rel="nofollow" class="ren-checkrush"><span>{lang rushreply_view}</span></a>
											<!--{/if}-->
										</div>
										<p class="">
										<!--{if $rushresult[stopfloor]}-->
											{lang thread_rushreply_end}$rushresult[stopfloor]&nbsp;
										<!--{/if}-->
										</p>
										<p class="">
										<!--{if $rushresult[rewardfloor]}-->
											{lang thread_rushreply_floor}{$rtj1009_lang['ren131']}$rushresult[rewardfloor]&nbsp;
										<!--{/if}-->
										</p>
										<!--{if $rushresult[rewardfloor] && $_GET['checkrush']}-->
											<p class="ren-checkrush-ptn">
												<!--{if $countrushpost}-->[<strong>$countrushpost</strong>]{lang thread_rushreply_rewardnum}<!--{else}--> {lang thread_rushreply_noreward} <!--{/if}-->&nbsp;
												<a href="forum.php?mod=viewthread&tid=$_G[tid]" class="xi2">{lang thread_rushreply_check_back}</a>
											</p>
										<!--{/if}-->
								</div>
							<!--{/if}-->
							<!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
								<div class="grey quote">{lang message_banned}</div>
							<!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
								<div class="grey quote">{lang message_single_banned}</div>
							<!--{elseif $needhiddenreply}-->
								<div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
							<!--{elseif $post['first'] && $_G['forum_threadpay']}-->
								<!--{template forum/viewthread_pay}-->
                            <!--{elseif $_G['forum_discuzcode']['passwordlock'][$post[pid]]}-->
                            <div class="ren-locked locked">
                                <span class="ren-flxx-i"><i class="icon ren-font">&#xe61a;</i>{lang message_password_exists} {lang pleaseinputpw}</span>

                                <div class="searchbar">
                                    <div class="search-input">
                                        <input type="text" id="postpw_$post[pid]" class="input"/>
                                    </div>
                                    <div class="button button-fill button-primary">
                                        <button type="button" class="button2" onclick="submitpostpw($post[pid]{if $_GET['from'] == 'preview'},{$post[tid]}{else}{/if})">{lang submit}</button>
                                    </div>
                                </div>
                            </div>
                            <!--{else}-->

								<!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
									<div class="grey quote">{lang admin_message_banned}</div>
								<!--{elseif $post['status'] & 1}-->
									<div class="grey quote">{lang admin_message_single_banned}</div>
								<!--{/if}-->
								<!--{if $post['first']}-->
									<!--{if $threadsortshow['typetemplate'] && $rtj1009_m_config['ren_flxx_view']}-->
										$threadsortshow[typetemplate]

									<script type="text/javascript">
										$(function() {
											$("#tab4").rTabs({
												animation : 'fadein',
												bind : 'click'
											});
											$("#tab2").rTabs({
												animation : 'fadein',
												bind : 'click'
											});
										})
									</script>
									<!--{elseif $threadsortshow['optionlist']}-->
										<div class="typeoption ren_view_flxx">
											<!--{if $threadsortshow['optionlist'] == 'expire'}-->
												{lang has_expired}
											<!--{else}-->
												<table summary="{lang threadtype_option}" cellpadding="0" cellspacing="0" class="cgtl ren_view_flxxnr">
													<caption>{$rtj1009_lang['ren092']}</caption>
													<tbody>
														<!--{loop $threadsortshow['optionlist'] $option}-->
															<!--{if $option['type'] != 'info'}-->
																<tr>
																	<th>$option[title]{$rtj1009_lang['ren131']}</th>
                                                                    <td><!--{if $option['value'] !== ''}--><!--{if $option['type'] == 'image' && $threadsortshow['typetemplate']}--><img src="$option[value]"><!--{else}-->$option[value] $option[unit]<!--{/if}--><!--{else}-->-<!--{/if}--></td>
																</tr>
															<!--{/if}-->
														<!--{/loop}-->
													</tbody>
												</table>
											<!--{/if}-->
										</div>
									<!--{/if}-->
									<!--{if !$_G[forum_thread][special]}-->
										$post[message]
									<!--{elseif $_G[forum_thread][special] == 1}-->
										<!--{template forum/viewthread_poll}-->
									<!--{elseif $_G[forum_thread][special] == 2}-->
										<!--{template forum/viewthread_trade}-->
									<!--{elseif $_G[forum_thread][special] == 3}-->
										<!--{template forum/viewthread_reward}-->
									<!--{elseif $_G[forum_thread][special] == 4}-->
										<!--{template forum/viewthread_activity}-->
									<!--{elseif $_G[forum_thread][special] == 5}-->
										<!--{template forum/viewthread_debate}-->
									<!--{elseif $threadplughtml}-->
										$threadplughtml
										$post[message]
									<!--{else}-->
										$post[message]
									<!--{/if}-->
								<!--{else}-->
									$post[message]
								<!--{/if}-->
							<!--{/if}-->
					</div>

					<!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
					<!--{if $post['attachment']}-->
					   <div class="ren-flxx-jbts quote cl">
					   {lang attachment}{$rtj1009_lang['ren131']}<em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
					   </div>
					<!--{elseif $post['imagelist'] || $post['attachlist']}-->
					   <!--{if $post['imagelist']}-->
						<!--{if count($post['imagelist']) == 1}-->
						<ul class="img_one">{echo showattach($post, 1)}</ul>
						<!--{else}-->
						<ul class="ren_img_list cl vm">{echo showattach($post, 1)}</ul>
						<!--{/if}-->
						<!--{/if}-->
						<!--{if $post['attachlist']}-->
						<ul>{echo showattach($post)}</ul>
						<!--{/if}-->
					<!--{/if}-->
					<!--{/if}-->
					<!--{if $threadsortshow}-->
					<div class="ren-flxx-us">
						<div class="ren_lc_xx cl">
							<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="avatar z"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->"/></a>
							<div class="ren_lc_zz cl">
								<div class="ren_lc_zzxx cl">
									<!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
										<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren_zz_mz z">$post[author]</a>
									<!--{else}-->
										<!--{if !$post['authorid']}-->
										<a href="javascript:;" class="ren_zz_mz z">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
										<!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
											<!--{if $_G['forum']['ismoderator']}-->
												<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren_zz_mz z">{lang anonymous}</a>
											<!--{else}-->
												<a href="javascript:;" class="ren_zz_mz z">{lang anonymous}</a>
											<!--{/if}-->
										<!--{else}-->
										$post[author] <em>{lang member_deleted}</em>
										<!--{/if}-->
									<!--{/if}-->
									<!--{if ($rtj1009_m_config['ren_m_view_xing'] || $rtj1009_m_config['ren_view_utitle']) && $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                                    <em class="z ren_us_xing"><!--{if $rtj1009_m_config['ren_m_view_xing']}-->Lv.{$post[stars]}<!--{/if}--><!--{if $rtj1009_m_config['ren_view_utitle']}--> {$post[authortitle]}<!--{/if}--></em>
                                    <!--{/if}-->

							<!--{if $_G['forum']['ismoderator']}-->
							<!-- manage start -->
								<div href="#moption_$post[pid]" class="open-popup ren_lc_gl" data-popup=".popup-view-lzgl">{lang manage}</div>
								<div class="popup popup-view-gl popup-view-lzgl">
									<div class="content-block">
                                        <div class="ren_lostpw ren-view-gl">
                                            <ul>
                                                <!--{if !$_G['forum_thread']['special']}-->
                                                <li><a class="redirect" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a></li>
                                                <!--{/if}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=delete&optgroup=3&from={$_G[tid]}">{lang delete}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=4">{lang close}</a></li>
                                                <!--{if $_G['group']['allowdigestthread'] && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=5">{lang modmenu_digestpost}</a></li>
                                                <!--{/if}-->
                                                <!--{if $_G['group']['allowstickthread'] && ($_G['forum_thread']['displayorder'] <= 3 || $_G['adminid'] == 1) && !$_G['forum_thread']['is_archived']}--><!--{eval $modopt++}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=1">{lang modmenu_stickthread}</a></li>
                                                <!--{/if}-->
                                                <!--{if $_G['group']['allowmovethread'] && !$_G['forum_thread']['is_archived'] && $_G['forum']['status'] != 3}--><!--{eval $modopt++}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&from={$_G[tid]}&optgroup=2">{lang modmenu_move}</a></li>
                                                <!--{/if}-->
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{lang admin_banpost}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&topiclist[]={$_G[forum_firstpid]}">{lang topicadmin_warn_add}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=bump&optgroup=3&from={$_G[tid]}">{$rtj1009_lang['ren204']}</a></li>
                                                <li><a class="dialog" href="forum.php?mod=topicadmin&action=moderate&fid={$_G[fid]}&moderate[]={$_G[tid]}&operation=down&optgroup=3&from={$_G[tid]}">{$rtj1009_lang['ren205']}</a></li>
                                            </ul>
                                        </div>
									</div>
									<div class="ren-close">
										<a href="javascript:;" class="close-popup">{$rtj1009_lang['ren012']}</a>
									</div>
								</div>
							<!-- manage end -->
							<!--{/if}-->
								<a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->y ren-flxx-jbbtn">{$rtj1009_lang['ren090']}</a>
                                    <!--{if (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && ($post['authorid'] == $_G['uid'] && $_G['forum_thread']['closed'] == 0) && !(!$alloweditpost_status && $edittimelimit && TIMESTAMP - $post['dbdateline'] > $edittimelimit)))}-->
                                    <a class="y ren_zz_gz ren-flxx-bjbtn" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]<!--{if $_G[forum_thread][sortid]}--><!--{if $post[first]}-->&sortid={$_G[forum_thread][sortid]}<!--{/if}--><!--{/if}-->{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a>
                                    <!--{/if}-->
								</div>
								<div class="ren_lc_sj cl">
									<span class="ren_lc_sjsj">{$rtj1009_lang['ren033']}$post[dateline]</span>
									<span class="ren-flxx-i"><i class="icon ren-font">&#xe660;</i>{$thread[views]}{$rtj1009_lang['ren135']}</span>
								</div>
							</div>
						</div>
						<div class="ren-flxx-jbts cl">
							<span><i class="icon ren-font">&#xe62e;</i>{$rtj1009_lang['ren136']}</span>
						</div>
					</div>
					<!--{/if}-->
                   <!--{if $rtj1009_m_config['ren_forum_view_rate']}-->
                       <!--{if in_array($_G[fid], $ren_rate_forums)}-->
                       <div class="ren-view-rate">
                           <p>{$rtj1009_lang['ren093']}</p>
                           <a href="forum.php?mod=misc&action=rate&tid=$_G[tid]&pid=$post[pid]" class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-view-but">
                                <p>{$rtj1009_lang['ren094']}</p>
                            </a>
                            <!--{if $_GET['from'] != 'preview' && !empty($post['ratelog'])}-->
                            <a href="forum.php?mod=misc&action=viewratings&tid=$_G[tid]&pid=$post[pid]" class="ren-rate-shu">{$rtj1009_lang['ren095']}<span><!--{echo count($postlist[$post[pid]][totalrate]);}--></span>{$rtj1009_lang['ren096']}</a>
                            <!--{/if}-->
                            <!--{if $_G['setting']['ratelogon']}-->
                            <ul class="cl">
                            <!--{loop $post['ratelog'] $uid $ratelog}-->
                                    <li>
                                        <a href="home.php?mod=space&uid=$uid&do=profile"><!--{echo avatar($uid, 'small');}--></a>
                                    </li>
                                <!--{/loop}-->
                            </ul>
                            <!--{/if}-->
                        </div>
                        <!--{/if}-->
					<!--{/if}-->
                   {$block_viewthread_ratex}

	   		<!--{if $post['first'] && ($post[tags] || $relatedkeywords) && $_GET['from'] != 'preview'}-->
			<div class="ren-view-tag">
				<!--{if $post[tags]}-->
				<i class="icon ren-font">&#xe6bb;</i>
					<!--{eval $tagi = 0;}-->
					<!--{loop $post[tags] $var}-->
						<!--{if $tagi}--> , <!--{/if}--><a title="$var[1]" href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
						<!--{eval $tagi++;}-->
					<!--{/loop}-->
				<!--{/if}-->
				<!--{if $relatedkeywords}--><span>$relatedkeywords</span><!--{/if}-->
			</div>
			<!--{/if}-->
			   </div>
		<!--{hook/viewthread_postbottom_mobile $postcount}-->
		   </div>
        <!--{if $rtj1009_m_config['ren_view_bk_xx']}-->
			<a href="forum.php?mod=forumdisplay&fid=$_G[fid]" class="ren_bk_topz cl">
				<div class="z head_bktp cl">
					<span>
                        <!--{eval $ren_forum_ico = rtj1009_ficoisurl($_G['forum'][icon]);}-->
                        <img src="<!--{if $_G['basescript'] == 'group'}-->data/attachment/group/{$_G['forum'][icon]}<!--{else}--><!--{if $_G['forum'][icon]}-->$ren_forum_ico<!--{else}-->{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg<!--{/if}--><!--{/if}-->" alt="{$_G['forum'][name]}">
					</span>           							 							
				</div>
				<div class="ren_bk_xx cl">
					<span class="ren_bk_name z">$_G['forum'][name]</span>
				</div>
				<p class="ren_bk_num"><span class="info_label">{$rtj1009_lang['ren028']}</span><span class="info_value">$_G[forum][posts]</span><span class="info_label">{$rtj1009_lang['ren029']}</span><span class="info_value">$_G[forum][favtimes]</span></p>
				<div class="y ren_bk_fh"><span class="z">{$rtj1009_lang['ren091']}</span><i class="icon ren-font">&#xe643;</i></div>
			</a>
        <!--{else}-->
        <div class="kong"></div>
        <!--{/if}-->

        <!--{if $post['relateitem'] && $rtj1009_m_config['ren_related_thread'] == 1}-->
        <!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/rtj1009_list.php';}-->
        <div class="ren-related ren_tie_list cl">
            <div class="ren_m_mkbt">
                <span>{lang related_thread}</span>
            </div>
            <div class="ren_list_yi cl">
                <ul class="ren_list cl">
                    <!--{loop $post['relateitem'] $var}-->
                    <!--{eval include_once libfile('function/post');
                        include_once libfile('function/attachment');
                        $var['post'] = C::t('forum_post')->fetch_all_by_tid_position($var['posttableid'],$var['tid'],1);
                        $var['post'] = array_shift($var['post']);
                        $ren_pic = C::t('forum_attachment_n')->count_image_by_id('tid:'.$var['post']['tid'], 'pid', $var['post']['pid']);
                    }-->

                    <li>
                        <!--{if $rtj1009_m_config['ren_related_imgs'] ==1}-->
                        <!--{if $ren_pic <=2}-->
                        <!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$var['post']['tid'], 'pid', $var['post']['pid'], 1);}-->
                        <div class="ren_tw_yiimg">
                            <!--{if $threadlistimg}-->
                            <a href="forum.php?mod=viewthread&tid=$var[tid]" class="ren_threadimg y">
                                <!--{if $ren_pic <=2}-->
                                <!--{loop $threadlistimg $values}-->
                                <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
                                <span class="ren_thread_imge ren_thread_img"><img src="$renlistimgkey" /></span>
                                <!--{/loop}-->
                                <!--{/if}-->
                            </a>
                            <!--{/if}-->
                            <div class="ren_tw_yi"<!--{if $ren_pic}--> style="height: 48px; margin-bottom: 5px; overflow: hidden;"<!--{/if}-->>
                                <a href="forum.php?mod=viewthread&tid=$var[tid]">{$var[subject]}</a>
                            </div>
                            <div class="ren_list_us">
                                <a class="ren_twus_img z cl" href="home.php?mod=space&uid=$var[authorid]&do=profile">
                                    <!--{avatar($var[authorid],middle)}-->
                                </a>
                                <a class="ren_twus_name z cl" href="home.php?mod=space&uid=$var[authorid]&do=profile">$var[author]</a>
                                <span class="time z" style="<!--{if !$ren_pic}-->display: block;<!--{else}-->display: none;<!--{/if}-->"><!--{echo dgmdate($var[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                                <a href="forum.php?mod=viewthread&tid=$var[tid]" class="ren_list_li_xx y" >
                                    <span class="reply y"><i class="icon ren-font">&#xe694;</i>{$var[replies]}</span>
                                    <span class="views y"><i class="icon ren-font">&#xe660;</i>{$var[views]}</span>
                                </a>
                            </div>
                        </div>
                    <!--{elseif $ren_pic >=3}-->
            <!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$var['post']['tid'], 'pid', $var['post']['pid'], 3);}-->
                        <div class="ren_twbt">
                            <a href="forum.php?mod=viewthread&tid=$var[tid]">{$var[subject]}</a>
                        </div>
                        <!--{if $threadlistimg}-->
                        <div class="ren_threadimg">
                            <a href="forum.php?mod=viewthread&tid=$var[tid]">
                                <!--{if $ren_pic >=3}-->
                                <!--{loop $threadlistimg $values}-->
                                <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
                                <span class="ren_thread_imgsan ren_thread_img"><img src="$renlistimgkey"/></span>
                                <!--{/loop}-->
                                <!--{/if}-->
                            </a>
                        </div>
                        <!--{/if}-->

                        <div class="ren_list_us">
                            <a class="ren_twus_img z cl" href="home.php?mod=space&uid=$var[authorid]&do=profile">
                                <!--{avatar($var[authorid],middle)}-->
                            </a>
                            <a class="ren_twus_name z cl" href="home.php?mod=space&uid=$var[authorid]&do=profile">$var[author]</a>
                            <span class="time z"><!--{echo dgmdate($var[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                            <a href="forum.php?mod=viewthread&tid=$var[tid]" class="ren_list_li_xx y" >
                                <span class="reply y"><i class="icon ren-font">&#xe694;</i>{$var[replies]}</span>
                                <span class="views y"><i class="icon ren-font">&#xe660;</i>{$var[views]}</span>
                            </a>
                        </div>
                    <!--{/if}-->
            <!--{else}-->
            <!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$var['post']['tid'], 'pid', $var['post']['pid'], 1);}-->
            <div class="ren_tw_yiimg">
                <!--{if $threadlistimg}-->
                <a href="forum.php?mod=viewthread&tid=$var[tid]" class="ren_threadimg y">
                    <!--{loop $threadlistimg $values}-->
                    <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
                    <span class="ren_thread_imge ren_thread_img"><img src="$renlistimgkey" /></span>
                    <!--{/loop}-->
                </a>
                <!--{/if}-->
                <div class="ren_tw_yi"<!--{if $ren_pic}--> style="height: 48px; margin-bottom: 5px; overflow: hidden;"<!--{/if}-->>
                <a href="forum.php?mod=viewthread&tid=$var[tid]">{$var[subject]}</a>
            </div>
            <div class="ren_list_us">
                <a class="ren_twus_img z cl" href="home.php?mod=space&uid=$var[authorid]&do=profile">
                    <!--{avatar($var[authorid],middle)}-->
                </a>
                <a class="ren_twus_name z cl" href="home.php?mod=space&uid=$var[authorid]&do=profile">$var[author]</a>
                <span class="time z" style="<!--{if !$ren_pic}-->display: block;<!--{else}-->display: none;<!--{/if}-->"><!--{echo dgmdate($var[dateline], 'u', '9999', getglobal('setting/dateformat'))}--></span>
                <a href="forum.php?mod=viewthread&tid=$var[tid]" class="ren_list_li_xx y" >
                    <span class="reply y"><i class="icon ren-font">&#xe694;</i>{$var[replies]}</span>
                    <span class="views y"><i class="icon ren-font">&#xe660;</i>{$var[views]}</span>
                </a>
            </div>
        </div>
            <!--{/if}-->
            </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <!--{/if}-->
        {$block_viewthread}
		   <div class="ren_lc_ks cl">
				<span class="ren_lc_ksz z">{$rtj1009_lang['ren097']}<em>{$thread[replies]}</em></span>
				<span class="ren_lc_ksy y">
				<!--{if !IS_ROBOT && !$_GET['authorid'] && !$_G['forum_thread']['archiveid']}-->
					<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page&authorid=$_G[forum_thread][authorid]" rel="nofollow" class="ren_lc_zkzz">{lang viewonlyauthorid}</a>
				<!--{elseif !$_G['forum_thread']['archiveid']}-->
					<a href="forum.php?mod=viewthread&tid=$_G[tid]&page=$page" rel="nofollow" class="ren_lc_zkzz">{lang thread_show_all}</a>
				<!--{/if}-->
				</span>
		   </div>
		<!--{else}-->
		<!--{template forum/ren_viewthread}-->
		<!--{/if}-->
	   <!--{eval $postcount++;}-->
	   <!--{/loop}-->
	   
	<!--{if $_G[forum_thread][allreplies] == 0 }-->
		<div class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{$rtj1009_lang['ren098']}</span>
		</div>
	<!--{/if}-->
	
	<div id="post_new" class="ren_post_new cl"></div>
	$multipage
    {$block_viewthread_footer}
    <!--{hook/viewthread_bottom_mobile}-->
	</div>
<!-- main postlist end -->
</div>

<!--{if $rtj1009_m_config['ren_view_footer'] ==1}-->
<div class="ren_view_share ren_view_footer">
    <!--{if $rtj1009_m_config['ren_view_ftfh']}--><a href="javascript:;" onclick="renBack()" class="ren_viewdi_fh back"><i class="icon ren-font">&#xe633;</i></a><!--{/if}-->
	<a class="ren_viewdi_hf<!--{if $rtj1009_m_config['ren_view_ftfh']}--> e<!--{/if}--> open-popup" data-popup=".popup-view"><span>{$rtj1009_lang['ren053']}</span></a>
	<!--{eval $recommend = DB::fetch_first("SELECT * FROM  ".DB::table('forum_memberrecommend')." WHERE  recommenduid=".$_G[uid]." and tid=".$_G['tid']."");}-->
	<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_viewdi_dz" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}">
		<i class="icon ren-font<!--{if $recommend}--> color<!--{/if}-->"><!--{if $recommend}-->&#xe793;<!--{else}-->&#xe856;<!--{/if}--></i>
		<!--{if $rtj1009_m_config['ren_view_ftadd']}--><!--{if $_G['forum_thread']['recommend_add']}--><span id="recommendv_add" class="ren_view_ftadd">{$_G[forum_thread][recommend_add]}</span><!--{/if}--><!--{/if}-->
	</a>
	<!--{eval $isfavtimes = DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='tid' and id=".$_G['tid']."");}-->
	<a href="home.php?mod=spacecp&ac=favorite&type=thread&id=$_G[tid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_twsj_sc">
		<i class="icon ren-font<!--{if $isfavtimes}--> color<!--{/if}-->"><!--{if $isfavtimes}-->&#xe646;<!--{else}-->&#xe603;<!--{/if}--></i>
		<!--{if $rtj1009_m_config['ren_view_ftadd']}--><!--{if $_G['forum_thread']['favtimes']}--><span id="k_favorite" class="ren_view_ftadd">{$_G['forum_thread']['favtimes']}</span><!--{/if}--><!--{/if}-->
	</a>
	<a id="ren_share" href="javascript:;" class="ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe742;</i></a>
</div>
<!--{else}-->
<div class="ren_view_share ren_view_foo">
	<a href="javascript:;" class="ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe613;</i>{$rtj1009_lang['ren089']}</a>
	<a class="ren_viewdi_hf open-popup" data-popup=".popup-view"><i class="icon ren-font">&#xe694;</i>{$rtj1009_lang['ren056']}</a>
	<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_viewdi_dz" href="forum.php?mod=misc&action=recommend&do=add&tid=$_G[tid]&hash={FORMHASH}" title="{lang maketoponce}" ><i class="icon ren-font">&#xe856;</i>{$rtj1009_lang['ren099']}</a>
</div>
<!--{/if}-->
<script type="text/javascript">
	$('.ren_share').ready(function(){
		var share = new ren_share({
			  title : document.title,
			  url   : window.location.href,
			  desc  : document.getElementsByName('description')[0].content,
			  img   : '$ren_wx_imgUrl',
		});
		$('.ren_share').click(function () {
			share.init(0,'.ren_view_share');
		});
	});
</script>
<div id="popup-share" class="popup popup-share">
    <div class="content-block">
        <div class="ren_tiefx_share">
			<div class="bdsharebuttonbox">
				<a href="javascript:;" class="popup_sqq" data-cmd="sqq"><p>{$rtj1009_lang['ren100']}</p></a>
				<a href="javascript:;" class="bds_qzone" data-cmd="qzone"><p>{$rtj1009_lang['ren101']}</p></a>
				<a href="javascript:;" class="bds_tsina" data-cmd="tsina"><p>{$rtj1009_lang['ren102']}</p></a>
                <a href="javascript:;" class="bds_weixin" data-cmd="weixin"><p>{$rtj1009_lang['ren103']}</p></a>
				<a href="javascript:;" class="bds_copy" data-cmd="copy"><p>{$rtj1009_lang['ren212']}</p></a>
			</div>
        </div>
    </div>
    <a href="javascript:;" class="ren_tiefx_qx close-popup">{$rtj1009_lang['ren012']}</a>
</div>

<div class="popup popup-view">
	<header class="bar bar-nav popup-view-nav">
		<div class="ren_nav cl">
			<a href="javascript:;" class="z ren-fh close-popup"><i class="icon ren-font">&#xe64d;</i></a>
			<div class="ren_top_dqwz z">
				<span>{$rtj1009_lang['ren056']}</span>
			</div>
		</div>
	</header>
  <div class="content-block">
	<div class="ren_lostpw">
	<!--{subtemplate forum/forumdisplay_fastpost}-->
	</div>
  </div>
</div>



<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<script type="text/javascript">
    function submitpostpw(pid, tid) {
        var obj = document.getElementById('postpw_' + pid);
        appendscript(JSPATH + 'md5.js?' + VERHASH);
        setcookie('postpw_' + pid, hex_md5(obj.value));
        if(!tid) {
            location.href = location.href;
        } else {
            location.href = 'forum.php?mod=viewthread&tid='+tid;
        }
    }

    var renmsg = '{$rtj1009_lang[ren206]}';
    function setanswer(tid, pid, from){
        if(confirm(renmsg)){
            $("#modactions").attr('action', 'forum.php?mod=misc&action=bestanswer&tid=' + tid + '&pid=' + pid + '&from=' + from + '&bestanswersubmit=yes');
            $('#modactions').submit();
        }
    }

    $('.favbtn').on('click', function() {
		var obj = $(this);
		$.ajax({
			type:'POST',
			url:obj.attr('href') + '&handlekey=favbtn&inajax=1',
			data:{'favoritesubmit':'true', 'formhash':'{FORMHASH}'},
			dataType:'xml',
		})
		.success(function(s) {
			popup.open(s.lastChild.firstChild.nodeValue);
			evalscript(s.lastChild.firstChild.nodeValue);
		})
		.error(function() {
			window.location.href = obj.attr('href');
			popup.close();
		});
		return false;
	});

</script>


<form method="post" autocomplete="off" name="modactions" id="modactions">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <input type="hidden" name="optgroup" />
    <input type="hidden" name="operation" />
    <input type="hidden" name="listextra" value="$_GET[extra]" />
    <input type="hidden" name="page" value="$page" />
</form>

<!--{template common/footer}-->
