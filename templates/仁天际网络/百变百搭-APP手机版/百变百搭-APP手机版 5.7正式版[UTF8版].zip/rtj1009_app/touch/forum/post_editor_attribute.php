<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="j-tab-con cl">
	<div class="tab-con-item">
		<div id="Smohan_FaceBox"></div>
	</div>
	<div class="tab-con-item">
		<script type="text/javascript" src="template/rtj1009_app/js/jquery.tabso_yeso.js"></script>
		<div id="tab6" class="tabs-block">
			<ul class="tabbtn">
				<a href="javascript:;" class="tu tab-link current"><i class="icon ren-font">&#xe626;</i><p>{$rtj1009_lang['ren150']}</p></a>
				<a href="javascript:;" class="tu tab-link"><i class="icon ren-font">&#xe634;</i><p>{$rtj1009_lang['ren151']}</p></a>
				<a href="javascript:;" class="tu tab-link"><i class="icon ren-font">&#xe6eb;</i><p>{$rtj1009_lang['ren152']}</p></a>
				<a href="javascript:;" class="tab-link"><i class="icon ren-font">&#xe6ae;</i><p>{$rtj1009_lang['ren153']}</p></a>
				<a href="javascript:;" class="tab-link"><i class="icon ren-font">&#xe68f;</i><p>Flash</p></a>
				<a href="javascript:;" class="tab-link"><i class="icon ren-font">&#xe767;</i><p>{$rtj1009_lang['ren154']}</p></a>
				<a href="javascript:;" class="tu tab-link"><i class="icon ren-font">&#xe829;</i><p>{$rtj1009_lang['ren155']}</p></a>
				<a href="javascript:;" class="tu tab-link"><i class="icon ren-font">&#xe627;</i><p>{$rtj1009_lang['ren156']}</p></a>
				<a href="javascript:;" class="tu tab-link"><i class="icon ren-font">&#xe632;</i><p>{$rtj1009_lang['ren157']}</p></a>
			</ul>
			<div class="tabs tabcon">
				<div id="tab1" class="tab active ren-de-edoin">
					<div class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{$rtj1009_lang['ren158']}</div>
						<div class="ren_hdxx_lxnr">
							<input type="text" name="text" id="ren-de-edowz" placeholder="{$rtj1009_lang['ren159']}" class="px" autocomplete="off" value="">
						</div>
					</div>
					<div class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{$rtj1009_lang['ren160']}</div>
						<div class="ren_hdxx_lxnr">
							<input type="text" name="text" id="ren-de-edolj" placeholder="{$rtj1009_lang['ren161']}" class="px" autocomplete="off" value="">
						</div>
					</div>
					<div class="ren-de-edobtn cl"><a href="javascript:;" id="ren-de-edbtn" class="ren-de-edbtn">{$rtj1009_lang['ren162']}</a></div>
					<script type="text/javascript">
						$('#ren-de-edbtn').click(function(){
							var a = $('#needmessage');
							var b = $("#ren-de-edowz");
							var c = $("#ren-de-edolj");
							console.log(b.val());
							if(b.val() == ''){
								popup.open('$rtj1009_lang[ren163]', 'alert');
								return false;
							}else{
								a.val(a.val()+"[url="+c.val()+"]"+b.val()+"[/url]");
								return false;
							}
						});
					</script>
				</div>
				<div id="tab2" class="tab ren-de-edod">
					<div class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lxnr">
							<input type="text" name="text" id="ren-de-edosp" placeholder="{$rtj1009_lang['ren164']}" class="px" autocomplete="off" value="">
						</div>
						<div class="ren-de-edsbtn cl"><a href="javascript:;" id="ren-de-edsbtn" class="ren-de-edbtn">{$rtj1009_lang['ren162']}</a></div>
					</div>
					<div class="ren-de-edsts">{$rtj1009_lang['ren165']}</div>
					<script type="text/javascript">
						$('#ren-de-edsbtn').click(function(){
							var a = $('#needmessage');
							var b = $("#ren-de-edosp");
							console.log(b.val());
							if(b.val() == ''){
								popup.open('$rtj1009_lang[ren163]', 'alert');
								return false;
							}else{
								a.val(a.val()+"[media=x,500,375]"+b.val()+"[/media]");
								return false;
							}
						});
					</script>
				</div>
				<div id="tab10" class="tab ren-de-edod">
					<div class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lxnr">
							<input type="text" name="text" id="ren-de-edoimg" placeholder="{$rtj1009_lang['ren166']}" class="px" autocomplete="off" value="">
						</div>
						<div class="ren-de-edsbtn cl"><a href="javascript:;" id="ren-de-edibtn" class="ren-de-edbtn">{$rtj1009_lang['ren162']}</a></div>
					</div>
					<script type="text/javascript">
						$('#ren-de-edibtn').click(function(){
							var a = $('#needmessage');
							var b = $("#ren-de-edoimg");
							console.log(b.val());
							if(b.val() == ''){
								popup.open('$rtj1009_lang[ren163]', 'alert');
								return false;
							}else{
								a.val(a.val()+"[img]"+b.val()+"[/img]");
								return false;
							}
						});
					</script>
				</div>
				<div id="tab4" class="tab ren-de-edod">
					<div class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lxnr">
							<input type="text" name="text" id="ren-de-edmp3" placeholder="{$rtj1009_lang['ren167']}" class="px" autocomplete="off" value="">
						</div>
						<div class="ren-de-edsbtn cl"><a href="javascript:;" id="ren-de-edmbtn" class="ren-de-edbtn">{$rtj1009_lang['ren162']}</a></div>
					</div>
					<div class="ren-de-edsts">{$rtj1009_lang['ren168']}</div>
					<script type="text/javascript">
						$('#ren-de-edmbtn').click(function(){
							var a = $('#needmessage');
							var b = $("#ren-de-edmp3");
							console.log(b.val());
							if(b.val() == ''){
								popup.open('$rtj1009_lang[ren163]', 'alert');
								return false;
							}else{
								a.val(a.val()+"[audio]"+b.val()+"[/audio]");
								return false;
							}
						});
					</script>
				</div>
				
				<div id="tab5" class="tab ren-de-edod">
					<div class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lxnr">
							<input type="text" name="text" id="ren-de-edflash" placeholder="{$rtj1009_lang['ren169']}" class="px" autocomplete="off" value="">
						</div>
						<div class="ren-de-edsbtn cl"><a href="javascript:;" id="ren-de-edfbtn" class="ren-de-edbtn">{$rtj1009_lang['ren162']}</a></div>
					</div>
					<div class="ren-de-edsts">{$rtj1009_lang['ren170']}</div>
					<script type="text/javascript">
						$('#ren-de-edfbtn').click(function(){
							var a = $('#needmessage');
							var b = $("#ren-de-edflash");
							console.log(b.val());
							if(b.val() == ''){
								popup.open('$rtj1009_lang[ren163]', 'alert');
								return false;
							}else{
								a.val(a.val()+"[flash]"+b.val()+"[/flash]");
								return false;
							}
						});
					</script>
				</div>
				<div id="tab6" class="tab ren-de-edod">
					<div class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lxnr">
							<input type="text" name="text" id="ren-de-edpy" placeholder="{$rtj1009_lang['ren171']}" class="px" autocomplete="off" value="">
						</div>
						<div class="ren-de-edsbtn cl"><a href="javascript:;" id="ren-de-edpbtn" class="ren-de-edbtn">{$rtj1009_lang['ren172']}</a></div>
					</div>
					<div class="ren-de-edsts">{$rtj1009_lang['ren173']}</div>
					<script type="text/javascript">
						$('#ren-de-edpbtn').click(function(){
							var a = $('#needmessage');
							var b = $("#ren-de-edpy");
							console.log(b.val());
							if(b.val() == ''){
								popup.open('$rtj1009_lang[ren163]', 'alert');
								return false;
							}else{
								a.val(a.val()+"@"+b.val()+"");
								return false;
							}
						});
					</script>
				</div>
				<div id="tab7" class="tab ren-de-edkin">
					<div class="ren_hdxx_text ren_hdxx_de">
						<div class="ren_hdxx_lxnr">
							<textarea id="ren-de-edkyy" class="px" cols="80" rows="3"  placeholder="{$rtj1009_lang['ren174']}"></textarea>
						</div>
						<div class="ren-de-edobtn cl"><a href="javascript:;" id="ren-de-edatn" class="ren-de-edbtn">{$rtj1009_lang['ren162']}</a></div>
					</div>
					<script type="text/javascript">
						$('#ren-de-edatn').click(function(){
							var a = $('#needmessage');
							var b = $("#ren-de-edkyy");
							console.log(b.val());
							if(b.val() == ''){
								popup.open('$rtj1009_lang[ren163]', 'alert');
								return false;
							}else{
								a.val(a.val()+"[quote]"+b.val()+"[/quote]");
								return false;
							}
						});
					</script>
				</div>
				<div id="tab8" class="tab ren-de-edkin">
					<div class="ren_hdxx_text ren_hdxx_de">
						<div class="ren_hdxx_lxnr">
							<textarea id="ren-de-edkhtm" class="px" cols="80" rows="3"  placeholder="{$rtj1009_lang['ren175']}"></textarea>
						</div>
						<div class="ren-de-edobtn cl"><a href="javascript:;" id="ren-de-edmtn" class="ren-de-edbtn">{$rtj1009_lang['ren162']}</a></div>
					</div>
					<script type="text/javascript">
						$('#ren-de-edmtn').click(function(){
							var a = $('#needmessage');
							var b = $("#ren-de-edkhtm");
							console.log(b.val());
							if(b.val() == ''){
								popup.open('$rtj1009_lang[ren163]', 'alert');
								return false;
							}else{
								a.val(a.val()+"[code]"+b.val()+"[/code]");
								return false;
							}
						});
					</script>
				</div>
				<div id="tab9" class="tab ren-de-edkin">
					<div class="ren_hdxx_text ren_hdxx_de">
						<div class="ren_hdxx_lxnr">
							<textarea id="ren-de-edkxx" class="px" cols="80" rows="3"  placeholder="{$rtj1009_lang['ren176']}"></textarea>
						</div>
						<div class="ren-de-edobtn cl"><a href="javascript:;" id="ren-de-edxtn" class="ren-de-edbtn">{$rtj1009_lang['ren162']}</a></div>
					</div>
					<script type="text/javascript">
						$('#ren-de-edxtn').click(function(){
							var a = $('#needmessage');
							var b = $("#ren-de-edkxx");
							console.log(b.val());
							if(b.val() == ''){
								popup.open('$rtj1009_lang[ren163]', 'alert');
								return false;
							}else{
								a.val(a.val()+"[free]"+b.val()+"[/free]");
								return false;
							}
						});
					</script>
				</div>
			</div>
		</div>
	</div>
    <!--{if ($_GET[action] == 'newthread' && $_G['group']['allowpostrushreply'] && $special != 2) || ($_GET[action] == 'edit' && getstatus($thread['status'], 3))}-->
	<div class="tab-con-item">
		<div class="post_from ren-post-newt cl">
			<div class="ren_fb_hd cl">
				<ul>
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang rushreply_change}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="rushreply" class="label-switch">
									<input type="checkbox" name="rushreply" id="rushreply" value="1" {if $_GET[action] == 'edit' && getstatus($thread['status'], 3)}disabled="disabled" checked="checked"{/if} />
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{$rtj1009_lang['ren177']}</div>
						<div class="ren_hdxx_lxnr ren-webki">
						   <input type="text" name="rushreplyfrom" id="rushreplyfrom" onfocus="this.blur();" placeholder="{$rtj1009_lang['ren178']}" class="px" autocomplete="off" value="$postinfo[rush][starttimefrom]" onkeyup="$('rushreply').checked = true;" />
						</div>
					</li>
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{$rtj1009_lang['ren179']}</div>
						<div class="ren_hdxx_lxnr ren-webki">
						   <input type="text" autocomplete="off" id="rushreplyto" name="rushreplyto" placeholder="{$rtj1009_lang['ren180']}" class="px" onfocus="this.blur();" value="$postinfo[rush][starttimeto]" onkeyup="$('rushreply').checked = true;" />
						</div>
					</li>
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{$rtj1009_lang['ren181']}</div>
						<div class="ren_hdxx_lxnr">
							<input type="text" name="rewardfloor" id="rewardfloor" placeholder="{$rtj1009_lang['ren182']}" class="px" value="$postinfo[rush][rewardfloor]" onkeyup="$('rushreply').checked = true;" />
						</div>
					</li>
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{$rtj1009_lang['ren183']}</div>
						<div class="ren_hdxx_lxnr">
							<input type="text" name="replylimit" id="replylimit" placeholder="{lang replylimit}" class="px" autocomplete="off" value="$postinfo[rush][replylimit]" onkeyup="$('rushreply').checked = true;" />
						</div>
					</li>
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{$rtj1009_lang['ren184']}</div>
						<div class="ren_hdxx_lxnr">
							<input type="text" name="stopfloor" id="stopfloor" class="px" autocomplete="off" value="$postinfo[rush][stopfloor]" onkeyup="$('rushreply').checked = true;" />
						</div>
					</li>
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx"><!--{if $_G['setting']['creditstransextra'][11]}-->{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][11]][title]}<!--{else}-->{lang credits}<!--{/if}-->{lang min_limit}</div>
						<div class="ren_hdxx_lxnr">
							<input type="text" name="creditlimit" id="creditlimit" class="px" placeholder="{$rtj1009_lang['ren185']}" autocomplete="off" value="$postinfo[rush][creditlimit]" onkeyup="$('rushreply').checked = true;" />
						</div>
					</li>
				</ul>
			</div>
		</div>

        <script>
            var rushreplyfrom = new datePicker();
            rushreplyfrom.init({
                'trigger': '#rushreplyfrom',
                'type': 'datetime',
                'minDate':'1970-1-1',
                'maxDate':'2030-12-31',
                'onSubmit':function(){
                    var theSelectData = rushreplyfrom.value;
                },
                'onClose':function() {
                }
            });
            var rushreplyto = new datePicker();
            rushreplyto.init({
                'trigger': '#rushreplyto',
                'type': 'datetime',
                'minDate':'1970-1-1',
                'maxDate':'2030-12-31',
                'onSubmit':function(){
                    var theSelectData = rushreplyto.value;
                },
                'onClose':function() {
                }
            });
        </script>
    </div>
    <!--{/if}-->
    <!--{if $_G['group']['allowposttag']}-->
	<div class="tab-con-item">
		<div class="post_from cl">
			<div class="ren_fb_hd ren-editor cl">
				<ul>
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{lang post_tag}</div>
						<div class="ren_hdxx_lxnr">
						   <input type="text" class="px" size="60" id="tags" name="tags" placeholder="{$rtj1009_lang['ren186']}" value="$postinfo[tag]" />
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
    <!--{/if}-->

    <!--{if $_G['group']['maxprice'] && !$special}-->
	<div class="tab-con-item">
		<div class="post_from cl">
			<div class="ren_fb_hd ren-editor cl">
				<ul>
					<li class="ren_hdxx_li ren_hdxx_de">
						<div class="ren_hdxx_lx">{lang price}</div>
						<div class="ren_hdxx_lxnr">
						   <input type="text" id="price" name="price" class="px" placeholder="{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} {lang post_price_comment}" value="$thread[pricedisplay]" onblur="extraCheck(2)" />
						</div>
					</li>
				</ul>
			</div>
		</div>
	</div>
    <!--{/if}-->
	
	<div class="tab-con-item">
		<div class="post_from ren-post-newt cl">
			<div class="ren_fb_hd cl">
				<ul>
                    <li class="ren_hdxx_li ren_hdxx_de ren-post-password">
                        <div class="ren_hdxx_lxnr">
                            <input type="text" name="text" id="ren-de-edmpas" placeholder="{$rtj1009_lang['ren214']}" class="px" autocomplete="off" value="">
                        </div>
                        <div class="ren-de-edsbtn cl"><a href="javascript:;" id="ren-de-pasbtn" class="ren-de-edbtn">{$rtj1009_lang['ren133']}</a></div>
                    </li>
                    <script type="text/javascript">
                        $('#ren-de-pasbtn').click(function(){
                            var a = $('#needmessage');
                            var b = $("#ren-de-edmpas");
                            console.log(b.val());
                            if(b.val() == ''){
                                popup.open('$rtj1009_lang[ren215]', 'alert');
                                return false;
                            }else{
                                a.val(a.val()+"[password]"+b.val()+"[/password]");
                                return false;
                            }
                        });
                    </script>
					<!--{if $_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang hiddenreplies}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="hiddenreplies" class="label-switch">
									<input type="checkbox" name="hiddenreplies" id="hiddenreplies" class="pc"{if $thread['hiddenreplies']} checked="checked"{/if} value="1">
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>
					<!--{/if}-->
				<!--{if $_GET[action] != 'edit'}-->
					<!--{if $_G['group']['allowanonymous']}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang post_anonymous}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="isanonymous" class="label-switch">
									<input type="checkbox" name="isanonymous" id="isanonymous" class="pc" value="1" />
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>	
					<!--{/if}-->				
					<!--{else}-->
					<!--{if $_G['group']['allowanonymous'] || (!$_G['group']['allowanonymous'] && $orig['anonymous'])}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang post_anonymous}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="isanonymous" class="label-switch">
									<input type="checkbox" name="isanonymous" id="isanonymous" class="pc" value="1" {if $orig['anonymous']}checked="checked"{/if} />
									<div class="checkbox"></div>
							</div>
						</div>
					</li>
					<!--{/if}-->
				<!--{/if}-->
					<!--{if $_G['uid'] && ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost) && $special != 3}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang post_descviewdefault}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="ordertype" class="label-switch">
									<input type="checkbox" name="ordertype" id="ordertype" class="pc" value="1" $ordertypecheck />
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>
					<!--{/if}-->
					<!--{if ($_GET[action] == 'newthread' || $_GET[action] == 'edit' && $isfirstpost)}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang post_noticeauthor}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="allownoticeauthor" class="label-switch">
									<input type="checkbox" name="allownoticeauthor" id="allownoticeauthor" class="pc" value="1"{if $allownoticeauthor} checked="checked"{/if} />
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>
					<!--{/if}-->
					<!--{if $_GET[action] != 'edit' && helper_access::check_module('feed') && $_G['forum']['allowfeed']}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang addfeed}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="addfeed" class="label-switch">
									<input type="checkbox" name="addfeed" id="addfeed" class="pc" value="1" $addfeedcheck>
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>
					<!--{/if}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang post_show_sig}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="usesig" class="label-switch">
									<input type="checkbox" name="usesig" id="usesig" class="pc" value="1" {if !$_G['group']['maxsigsize']}disabled {else}$usesigcheck {/if}/>
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>
					<!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts'])}-->
					<!--{if $_GET[action] == 'newthread' && $_G['forum']['ismoderator'] && ($_G['group']['allowdirectpost'] || !$_G['forum']['modnewposts']) && ($_G['group']['allowstickthread'] || $_G['group']['allowdigestthread'])}-->
					<!--{if $_G['group']['allowstickthread']}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang post_stick_thread}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="sticktopic" class="label-switch">
									<input type="checkbox" name="sticktopic" id="sticktopic" class="pc" value="1" $stickcheck />
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>
					<!--{/if}-->
					
					<!--{if $_G['group']['allowdigestthread']}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang post_digest_thread}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="addtodigest" class="label-switch">
									<input type="checkbox" name="addtodigest" id="addtodigest" class="pc" value="1" $digestcheck />
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>
					<!--{/if}-->
					<!--{/if}-->
					<!--{elseif $_GET[action] == 'edit' && $_G['forum_auditstatuson']}-->
					<li class="ren_hdxx_li ren_spxx_de">
						<div class="ren_hdxx_lx">{lang auditstatuson}</div>
						<div class="item-inner ren-sendreasonpm">
							<div class="item-input">
								<label for="audit" class="label-switch">
									<input type="checkbox" name="audit" id="audit" class="pc" value="1">
									<div class="checkbox"></div>
								</label>
							</div>
						</div>
					</li>
					<!--{/if}-->
				</ul>
			</div>
		</div>
	</div>
</div>

