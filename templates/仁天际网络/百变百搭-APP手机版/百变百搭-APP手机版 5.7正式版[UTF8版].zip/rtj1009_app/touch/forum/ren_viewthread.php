<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_view_ny cl" id="pid$post[pid]">
    <div class="ren_lchf_xx cl">
        <a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren_avatar z"><img src="<!--{if !$post['authorid'] || $post['anonymous']}--><!--{avatar(0, small, true)}--><!--{else}--><!--{avatar($post[authorid], small, true)}--><!--{/if}-->"/></a>
        <div class="ren_lc_zz cl">
            <div class="ren_lc_zzxx cl">
                <!--{if $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                    <a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren_zz_mz z">$post[author]</a>
                <!--{else}-->
                    <!--{if !$post['authorid']}-->
                    <a href="javascript:;" class="ren_zz_mz z">{lang guest} <em>$post[useip]{if $post[port]}:$post[port]{/if}</em></a>
                    <!--{elseif $post['authorid'] && $post['username'] && $post['anonymous']}-->
						<!--{if $_G['forum']['ismoderator']}-->
							<a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren_zz_mz z">{lang anonymous}</a>
						<!--{else}-->
							<a href="javascript:;" class="ren_zz_mz z">{lang anonymous}</a>
						<!--{/if}-->
                    <!--{else}-->
                    	$post[author] <em>{lang member_deleted}</em>
                    <!--{/if}-->
                <!--{/if}-->
                <!--{if ($rtj1009_m_config['ren_m_view_xing'] || $rtj1009_m_config['ren_view_utitle']) && $post['authorid'] && $post['username'] && !$post['anonymous']}-->
                <em class="z ren_us_xing"><!--{if $rtj1009_m_config['ren_m_view_xing']}-->Lv.{$post[stars]}<!--{/if}--><!--{if $rtj1009_m_config['ren_view_utitle']}--> {$post[authortitle]}<!--{/if}--></em>
                <!--{/if}-->
                <!--{eval $shustars = DB::fetch_first("SELECT b.* FROM ".DB::table("common_member")." a LEFT JOIN ".DB::table("common_usergroup")." b on b.groupid=a.groupid WHERE a.`uid` = '$post[authorid]'");}-->
                <!--{block authorverifys}-->
                <!--{loop $post['verifyicon'] $vid}-->
                <a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><!--{if $_G['setting']['verify'][$vid]['icon']}--><img src="$_G['setting']['verify'][$vid]['icon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /><!--{else}-->$_G['setting']['verify'][$vid]['title']<!--{/if}--></a>
                <!--{/loop}-->
                <!--{loop $post['unverifyicon'] $vid}-->
                <a href="home.php?mod=spacecp&ac=profile&op=verify&vid=$vid" target="_blank"><img src="$_G['setting']['verify'][$vid]['unverifyicon']" class="vm" alt="$_G['setting']['verify'][$vid][title]" title="$_G['setting']['verify'][$vid][title]" /></a>
                <!--{/loop}-->
                <!--{/block}-->
                <div class="ren-verify z">
                    <!--{if $rtj1009_mobilecp['ren_m_view_verify']}-->
                    $authorverifys
                    <!--{/if}-->
                    <!--{if $rtj1009_mobilecp['ren_m_view_shustars']}-->
                    <!--{if $shustars[icon]}-->
                    <span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
                    <!--{/if}-->
                    <!--{/if}-->
                </div>
                <span>
                    <!--{if isset($post[isstick])}-->
                        <img src ="{IMGDIR}/settop.png" title="{lang replystick}" class="vm" /> {lang from} {$post[number]}{$postnostick}
                    <!--{elseif $post[number] == -1}-->
                        {lang recommend_post}
                    <!--{else}-->
                        <!--{if !empty($postno[$post[number]])}--><!--{if !$post['first'] && $post['rewardfloor']}-->{lang rushreply_hit}<!--{/if}-->$postno[$post[number]]<!--{else}--><!--{if !$post['first'] && $post['rewardfloor']}-->{lang rushreply_hit}<!--{/if}-->{$post[number]}{$rtj1009_lang['ren207']}<!--{/if}-->
                    <!--{/if}-->
                </span>
                <div class="ren-xs-lc">
                <!--{if !$post[first] && $_G['forum_thread']['special'] == 5}-->
                    <!--{if $post[stand] == 1}--><a class="yi dialog" href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]">{lang debate_square} <i class="icon ren-font">&#xe856;</i>$post[voters]</a>
                    <!--{elseif $post[stand] == 2}--><a class="e dialog" href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&pid=$post[pid]">{lang debate_opponent} <i class="icon ren-font">&#xe856;</i>$post[voters]</a>
                <!--{else}--><p class="san">{lang debate_neutral}</p><!--{/if}-->
                <!--{/if}-->
                </div>
            </div>

        </div>
    </div>
    <div class="display pi" href="#replybtn_$post[pid]">
        <div class="message">
            <!--{if !$post['first'] && $post['replycredit'] > 0}-->
            <div class="ren-replycredit cl">
                <div class="ren-reply">
                    {lang replycredit} <span>+{$post['replycredit']}</span>
                    {$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][unit]}{$_G['setting']['extcredits'][$_G['forum_thread']['replycredit_rule']['extcreditstype']][title]}
                </div>
            </div>
            <!--{/if}-->
            <!--{eval $post[message] = str_replace('target="_blank">', 'class="a-link">', $post[message]);}-->
                <!--{if $post['warned']}-->
                    <span class="grey quote">{lang warn_get}</span>
                <!--{/if}-->
                <!--{if !$post['first'] && !empty($post[subject])}-->
                    <h2><strong>$post[subject]</strong></h2>
                <!--{/if}-->
                <!--{if $_G['adminid'] != 1 && $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5) || $post['status'] == -1 || $post['memberstatus'])}-->
                    <div class="grey quote">{lang message_banned}</div>
                <!--{elseif $_G['adminid'] != 1 && $post['status'] & 1}-->
                    <div class="grey quote">{lang message_single_banned}</div>
                <!--{elseif $needhiddenreply}-->
                    <div class="grey quote">{lang message_ishidden_hiddenreplies}</div>
                <!--{elseif $post['first'] && $_G['forum_threadpay']}-->
                    <!--{template forum/viewthread_pay}-->
                <!--{else}-->

                    <!--{if $_G['setting']['bannedmessages'] & 1 && (($post['authorid'] && !$post['username']) || ($post['groupid'] == 4 || $post['groupid'] == 5))}-->
                        <div class="grey quote">{lang admin_message_banned}</div>
                    <!--{elseif $post['status'] & 1}-->
                        <div class="grey quote">{lang admin_message_single_banned}</div>
                    <!--{/if}-->
                    <!--{if $_G['forum_thread']['price'] > 0 && $_G['forum_thread']['special'] == 0}-->
                        {lang pay_threads}{$rtj1009_lang['ren131']}<strong>$_G[forum_thread][price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]} </strong> <a href="forum.php?mod=misc&action=viewpayments&tid=$_G[tid]" >{lang pay_view}</a>
                    <!--{/if}-->
                        $post[message]

                <!--{/if}-->
        </div>
        <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
        <!--{if $post['attachment']}-->
       <div class="ren-flxx-jbts quote cl">
           {lang attachment}{$rtj1009_lang['ren131']}<em><!--{if $_G['uid']}-->{lang attach_nopermission}<!--{else}-->{lang attach_nopermission_login}<!--{/if}--></em>
           </div>
        <!--{elseif $post['imagelist'] || $post['attachlist']}-->
           <!--{if $post['imagelist']}-->
            <!--{if count($post['imagelist']) == 1}-->
            <ul class="img_one">{echo showattach($post, 1)}</ul>
            <!--{else}-->
            <ul class="img_list cl vm">{echo showattach($post, 1)}</ul>
            <!--{/if}-->
            <!--{/if}-->
            <!--{if $post['attachlist']}-->
            <ul>{echo showattach($post)}</ul>
            <!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
    </div>
    <!--{if $_GET['from'] != 'preview' && $_G['setting']['commentnumber'] && !empty($comments[$post[pid]])}-->
    <div id="comment_$post[pid]" class="ren-view-cm">
        <ul class="cl">
        <!--{loop $comments[$post[pid]] $comment}-->
            <li>
                <!--{if $comment['authorid']}-->
                <a href="home.php?mod=space&uid=$comment[authorid]&do=profile" class="xi2">$comment[author]{$rtj1009_lang['ren131']}</a>
                <!--{else}-->
                {lang guest}
                <!--{/if}-->
                $comment[comment]
            </li>
        <!--{/loop}-->
        </ul>
    </div>
    <!--{/if}-->
    <div class="ren_lc_sjhf">
        <div class="ren_lc_sj cl">
            <!--{if $_G['forum']['ismoderator']}-->
            <!-- manage start -->
            <div href="#moption_$post[pid]" class="open-popup ren_lc_gl" data-popup=".popup-view-lcgl-$post[pid]">{lang manage}</div>
            <div class="popup popup-view-gl popup-view-lcgl-$post[pid]">
				<div class="content-block">
					<div class="ren_lostpw">
						<a class="redirect" href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET[modthreadkey])}&modthreadkey=$_GET[modthreadkey]{/if}&page=$page">{lang edit}</a>
						<!--{if $_G['group']['allowdelpost']}--><a class="dialog" href="forum.php?mod=topicadmin&action=delpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}">{lang modmenu_deletepost}</a><!--{/if}-->
						<!--{if $_G['group']['allowbanpost']}--><a class="dialog" href="forum.php?mod=topicadmin&action=banpost&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}">{lang modmenu_banpost}</a><!--{/if}-->
						<!--{if $_G['group']['allowwarnpost']}--><a class="dialog" href="forum.php?mod=topicadmin&action=warn&fid={$_G[fid]}&tid={$_G[tid]}&operation=&optgroup=&page=&topiclist[]={$post[pid]}">{lang modmenu_warn}</a><!--{/if}-->
					</div>
				</div>
				<div class="ren-close">
					<a href="javascript:;" class="close-popup">{$rtj1009_lang['ren012']}</a>
				</div>
			</div>
            <!-- manage end -->
            <!--{/if}-->
            <span>$post[dateline]</span>
            <!--{if $_G['forum_thread']['special'] == 3 && ($_G['forum']['ismoderator'] && (!$_G['setting']['rewardexpiration'] || $_G['setting']['rewardexpiration'] > 0 && ($_G[timestamp] - $_G['forum_thread']['dateline']) / 86400 > $_G['setting']['rewardexpiration']) || $_G['forum_thread']['authorid'] == $_G['uid']) && $post['authorid'] != $_G['forum_thread']['authorid'] && $post['first'] == 0 && $_G['uid'] != $post['authorid'] && $_G['forum_thread']['price'] > 0}-->
            <span class="ren-view-zjda">
                <a href="javascript:;" onclick="setanswer($post['tid'], $post['pid'], '$_GET[from]')"><i class="icon ren-font">&#xe663;</i>{lang reward_set_bestanswer}</a>
            </span>
            <!--{/if}-->
            <div id="replybtn_$post[pid]" class="view_renreply fnd">
                <!--{if $_G['setting']['magicstatus']}-->
                <!--{if !empty($_G['setting']['magics']['showip'])}-->
                    <a href="javascript:;" id="mgc_post_$post[pid]" class="open-popup ren_lc_magic" data-popup=".popup-view-magic-$post[pid]"><i class="icon ren-font">&#xe647;</i></a>
                    <!--{/if}-->
                <!--{/if}-->
                <a href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&repquote=$post[pid]&extra=$_GET[extra]&page=$page" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-lc-yhf"><i class="icon ren-font">&#xe619;</i></a>
                <!--{if $allowpostreply && $post['allowcomment'] && (!$thread['closed'] || $_G['forum']['ismoderator'])}-->
                <a href="forum.php?mod=misc&action=comment&tid=$post[tid]&pid=$post[pid]&extra=$_GET[extra]&page=$page{if $_G['forum_thread']['special'] == 127}&special=$specialextra{/if}" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-lc-dp"><i class="icon ren-font">&#xe64a;</i></a>
                <!--{/if}-->
                <a href="misc.php?mod=report&rtype=post&rid=$post[pid]&tid=$_G[tid]&fid=$_G[fid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_lc_jb"><i class="icon ren-font">&#xe614;</i></a>
				<!--{if !$_G['forum_thread']['special'] && !$rushreply && !$hiddenreplies && $_G['setting']['repliesrank'] && !$post['first'] && !($post['isWater'] && $_G['setting']['filterednovote'])}-->
				<a href="forum.php?mod=misc&action=postreview&do=support&tid=$_G[tid]&pid=$post[pid]&hash={FORMHASH}" id="review_support_$post[pid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_lc_dz <!--{if C::t('forum_hotreply_member')->fetch($post['pid'], $_G['uid'])}-->ren-lc-dz<!--{else}-->ren_lc_dz<!--{/if}-->"><i class="icon ren-font">&#xe856;</i></a>
				<!--{/if}-->
            </div>


            <!--{if $_G['setting']['magicstatus']}-->
            <div class="popup popup-view-gl popup-view-magic-$post[pid]">
                <div class="content-block">
                    <div class="ren_lostpw">
                        <!--{if $post['first']}-->
                        <!--{if !empty($_G['setting']['magics']['bump'])}-->
                        <a href="home.php?mod=magic&mid=bump&idtype=tid&id=$_G[tid]" id="a_bump" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/bump.small.gif" class="vm" />$_G['setting']['magics']['bump']</a>
                        <!--{/if}-->
                        <!--{if !empty($_G['setting']['magics']['stick'])}-->
                        <a href="home.php?mod=magic&mid=stick&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/stick.small.gif" class="vm" />$_G['setting']['magics']['stick']</a>
                        <!--{/if}-->
                        <!--{if !empty($_G['setting']['magics']['close'])}-->
                        <a href="home.php?mod=magic&mid=close&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/close.small.gif" class="vm" />$_G['setting']['magics']['close']</a>
                        <!--{/if}-->
                        <!--{if !empty($_G['setting']['magics']['open'])}-->
                        <a href="home.php?mod=magic&mid=open&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/open.small.gif" class="vm" />$_G['setting']['magics']['open']</a>
                        <!--{/if}-->
                        <!--{if !empty($_G['setting']['magics']['highlight'])}-->
                        <a href="home.php?mod=magic&mid=highlight&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/highlight.small.gif" class="vm" />$_G['setting']['magics']['highlight']</a></li>
                        <!--{/if}-->
                        <!--{if !empty($_G['setting']['magics']['sofa'])}-->
                        <a href="home.php?mod=magic&mid=sofa&idtype=tid&id=$_G[tid]" id="a_stick" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/sofa.small.gif" class="vm" />$_G['setting']['magics']['sofa']</a>
                        <!--{/if}-->
                        <!--{if !empty($_G['setting']['magics']['jack'])}-->
                        <a href="home.php?mod=magic&mid=jack&idtype=tid&id=$_G[tid]" id="a_jack" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/jack.small.gif" class="vm" />$_G['setting']['magics']['jack']</a>
                        <!--{/if}-->
                        <!--{/if}-->
                        <!--{if !empty($_G['setting']['magics']['repent']) && $post['authorid'] == $_G['uid'] && !$rushreply}-->
                        <a href="home.php?mod=magic&mid=repent&idtype=pid&id=$post[pid]:$_G[tid]" id="a_repent_$post[pid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/repent.small.gif" class="vm" />$_G['setting']['magics']['repent']</a>
                        <!--{/if}-->
                        <!--{if !empty($_G['setting']['magics']['anonymouspost']) && $post['authorid'] == $_G['uid']}-->
                        <a href="home.php?mod=magic&mid=anonymouspost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_anonymouspost_$post[pid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/anonymouspost.small.gif" class="vm" />$_G['setting']['magics']['anonymouspost']</a>
                            <!--{/if}-->
                            <!--{if !empty($_G['setting']['magics']['namepost'])}-->
                        <a href="home.php?mod=magic&mid=namepost&idtype=pid&id=$post[pid]:$_G[tid]" id="a_namepost_$post[pid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren-view-magic"><img src="{STATICURL}image/magic/namepost.small.gif" class="vm" />$_G['setting']['magics']['namepost']</a>
                            <!--{/if}-->
                    </div>
                </div>
                <div class="ren-close">
                    <a href="javascript:;" class="close-popup">{$rtj1009_lang['ren012']}</a>
                </div>
            </div>
            <!--{/if}-->
        </div>
    </div>
    <!--{hook/viewthread_postbottom_mobile $postcount}-->
</div>