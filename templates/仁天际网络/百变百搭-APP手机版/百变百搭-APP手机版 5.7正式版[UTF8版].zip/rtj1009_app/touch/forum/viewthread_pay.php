<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $thread['freemessage']}-->
	<div id="postmessage_$pid" class="t_f">$thread[freemessage]</div>
<!--{/if}-->
<div class="ren-locked ren_rwd cl">
	<div class="ren-loc-z">
    	<i class="icon ren-font">&#xe631;</i>
        <span class="ren-loc-txt">
			<!--{if $_G[forum_thread][price] > 0}-->{lang pay_comment}<!--{/if}-->
        </span>
	</div>

    <!--{if $_G['forum_thread']['price'] > 0 && !$_G['forum_thread']['is_archived']}-->
        <div class="ren-loc-y">
        	<a href="forum.php?mod=misc&action=pay&tid=$_G[tid]&pid=$post[pid]{if !empty($_GET['from'])}&from=$_GET['from']{/if}" class="ren_rwd_anniu<!--{if $_G[uid]}--> dialog<!--{else}--> ren-confirm<!--{/if}-->">{lang pay}</a>
        </div>
    <!--{/if}-->
</div>