<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>

<div class="ren_tie_list rtj1009_ss_main cl">
	<!--{if empty($albumlist)}-->
		<li class="ren_ss_wu">
			<i class="icon ren-font">&#xe678;</i>
			<span>{lang search_nomatch}</span>
		</li>
	<!--{else}-->
    	<div class="ren_ss_tit"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
		<ul class="ren_search_album cl">
			<!--{loop $albumlist $key $value}-->
					<li>
						<div class="ren_album_pic">
							<a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]">
							<!--{if $value[pic]}--><img src="$value[pic]" /><!--{/if}-->
								<p>$value[albumname]</p>
							</a>
						</div>
					</li>
			<!--{/loop}-->
		</ul>
	<!--{/if}-->
	$multipage
</div>