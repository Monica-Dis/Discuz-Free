<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if !empty($srchtype)}--><input type="hidden" name="srchtype" value="$srchtype" /><!--{/if}-->
<div class="content-padded">
  <div class="searchbar">
    <div class="search-input">
      <label class="icon icon-sousuo" for="search"></label>
	  <input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="{$rtj1009_lang['ren127']}">
    </div>
    <a class="button button-fill button-primary"><input type="hidden" name="searchsubmit" value="yes"><input type="submit" value="{lang search}" class="button2" id="scform_submit"></a>
  </div>
</div>
