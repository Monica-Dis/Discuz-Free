<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_tie_list rtj1009_ss_main cl">
	<!--{if empty($articlelist)}-->
		<li class="ren_ss_wu">
			<i class="icon ren-font">&#xe678;</i>
			<span>{lang search_nomatch}</span>
		</li>
	<!--{else}-->
    	<div class="ren_ss_tit"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
		<ul class="ren_yixz_xx cl">
			<!--{loop $articlelist $article}-->
			<li class="ren_yixzxxk zbxxk1">
				<!--{if $article[pic]}--><a href="{echo fetch_article_url($article);}" class="z ren_tieimg"><img src="$article[pic]"/></a><!--{/if}-->
				<a href="{echo fetch_article_url($article);}" class="ren_tiexx cl">
					<div class="ren_twbt">
						<span>
							$article[title]
						</span>
					</div>
					<div class="ren_twxxx">
						<span class="z ren_tie_ztfl">$article[dateline]</span>
					</div>
				</a>
			</li>
			<!--{/loop}-->
		</ul>
	<!--{/if}-->
	$multipage
</div>
