(function ($) {
    $.fn.extend({
        inserts: function (value) {
            var dthis = $(this)[0]; //将jQuery对象转换为DOM元素

            if (dthis.selectionStart || dthis.selectionStart == '0') {

                var start = dthis.selectionStart;
                var end = dthis.selectionEnd;
                var top = dthis.scrollTop;

                //以下这句，应该是在焦点之前，和焦点之后的位置，中间插入我们传入的值
                dthis.value = dthis.value.substring(0, start) + value + dthis.value.substring(end, dthis.value.length);
                dthis.selectionStart = dthis.selectionEnd = start + value.length;
            } else {
                this.value += value;
            }
            this.focus();
            return $(this);
        }
    })
})(jQuery);