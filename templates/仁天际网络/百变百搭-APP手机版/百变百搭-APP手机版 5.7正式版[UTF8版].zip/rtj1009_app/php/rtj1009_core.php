<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_core.php 2017-08-10 18:07:44Z rtj1009_mobilecp $
 */

if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}



$ren_m_sidebar = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_m_sidebar'];
$ren_portal_diy = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_portal_diy'];
$ren_weixin_hd = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_weixin_hd'];
$ren_title_sjb = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_title_sjb'];
$ren_smd_open = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_smd_open'];
$ren_smd_url = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_smd_url'];
$ren_smd_img = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_smd_img'];
$ren_smd_gtime = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_smd_gtime'];
$ren_smd_jtime = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_smd_jtime'];
$ren_smd_ts = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_smd_ts'];
$ren_back = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_back'];

$ren_m_portal_zy = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_m_portal_zy'];
$ren_m_portal_logo = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_m_portal_logo'];
$ren_m_slide = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_m_slide'];
$ren_m_portal_list = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_m_portal_list'];
$ren_portal_page = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_portal_page'];
$ren_weixin_hd = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_weixin_hd'];
$ren_footer_barfb = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_footer_barfb'];
$ren_footer_styles = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_footer_styles'];
$ren_m_forum_bar = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_m_forum_bar'];
$ren_m_html = $_G['cache']['plugin']['rtj1009_mobilecp']['ren_m_html'];

$rtj1009_mobilecp = $_G['cache']['plugin']['rtj1009_mobilecp'];


loadcache(array('block_portal','block_faxian','block_forum_yi','block_forum_e','block_group','block_sosuo','block_topic','block_viewthread','block_forumdisplay_top','block_forumdisplay_zd','block_viewthread_top','block_viewthread_footer','block_viewthread_ratex','block_post_juhe','block_post_juhebage','block_portal_vievtop','block_portal_vievzo','block_portal_vievfoo','block_forum_si'));
function rtj1009_wx_desc($messages) {
    $messages = preg_replace("/\[[a-z][^\]]*\]|\[\/[a-z]+\]/i", '',
        preg_replace("/\[attach\]\d+\[\/attach\]/i", '',
            preg_replace("/\[media=([\w,]+)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i", '',
                preg_replace("/\[img=(\d{1,4})[x|\,]\s*(.+?)\s*\[\/img\]/i", '',
                    preg_replace("/\s+/", '',
                        preg_replace("/\[img\]\s*(.+?)\s*\[\/img\]/i", '',$messages))))));
    $messages = messagecutstr($messages,120);
    return $messages;
}


$ren_rate_forums = unserialize($rtj1009_m_config['ren_view_rate_dx']);
if ($_G['basescript'] == 'forum' && CURMODULE =='viewthread' && $_G['forum_thread']['tid'] && $_G['forum_thread']['authorid']) {
    $ren_wx_img = DB::fetch_all('SELECT * FROM '.DB::table('forum_attachment').' WHERE tid = '.$_G['forum_thread']['tid'].' AND uid = '.$_G['forum_thread']['authorid'] .' LIMIT  0 ,'. 1 );
    $ren_wxfx_title = $_G['forum_thread']['subject'];
    $rtj1009_view_desc = rtj1009_isfirst($_G['forum_thread']['tid']);
    $ren_wxfx_desc = rtj1009_wx_desc($rtj1009_view_desc['message']);
    if ($ren_wx_img['0']['aid']) {
        $ren_wx_imgUrl = $_G['siteurl'].getforumimg($ren_wx_img['0']['aid'], '0', '80', '80');
    } else {
        $ren_wx_imgUrl = $rtj1009_m_config['wx_fx_ico'];
    }
} else if ($_G['basescript'] == 'forum' && CURMODULE =='forumdisplay') {
    $ren_wxfx_desc = $_G['forum']['description'];
    $ren_wx_imgUrl = $_G['siteurl'].'data/attachment/common/'.$_G['forum']['icon'];
} else if ($_G['basescript'] == 'portal' && CURMODULE =='view') {
    $ren_wx_img = DB::fetch_all('SELECT * FROM '.DB::table('portal_article_title').' WHERE aid = '.intval($_GET['aid']).' LIMIT  0 ,'. 1 );
    $ren_wxfx_title = $ren_wx_img['subject'];
    $ren_wxfx_desc = $article['summary'];
    if ($ren_wx_img['0']['pic']) {
        $ren_wx_imgUrl = $_G['siteurl'].'data/attachment/'.$ren_wx_img['0']['pic'];
    }
} else if (!$ren_wx_imgUrl) {
    $ren_wx_imgUrl = $rtj1009_m_config['wx_fx_ico'];
}

function rtj1009_output() {
    $content = ob_get_contents();
    $content = output_replace($content);
    ob_end_clean();
    $_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
    echo $content;
}

function rtj1009_ficoisurl($icon) {
    $ico = !strpos($icon,"://") ? 'data/attachment/common/' .$icon : $icon;
    return $ico;
}


function rtj1009_block($block) {
    foreach($block as $bid) {
        $arr .= get_rtj1009_block($bid);
    }
    return $arr;
}

function get_rtj1009_block($block) {
    include_once libfile('function/block');
    loadcache('blockclass');
    $bid = dintval(trim($block));
    block_get_batch($bid);
    $arr = block_fetch_content($bid, true);
    return $arr;
}

function rtj1009_list_block($catid) {
    global $_G;
    loadcache(array('block_portalcategory_'.$catid));
    return rtj1009_block($_G['cache']['block_portalcategory_'.$catid]);
}

$block_portal = rtj1009_block($_G['cache']['block_portal']);
$block_faxian = rtj1009_block($_G['cache']['block_faxian']);
$block_forum_yi = rtj1009_block($_G['cache']['block_forum_yi']);
$block_forum_e = rtj1009_block($_G['cache']['block_forum_e']);
$block_group = rtj1009_block($_G['cache']['block_group']);
$block_sosuo = rtj1009_block($_G['cache']['block_sosuo']);
$block_topic = rtj1009_block($_G['cache']['block_topic']);
$block_viewthread = rtj1009_block($_G['cache']['block_viewthread']);
$block_viewthread_top = rtj1009_block($_G['cache']['block_viewthread_top']);
$block_viewthread_footer = rtj1009_block($_G['cache']['block_viewthread_footer']);
$block_viewthread_ratex = rtj1009_block($_G['cache']['block_viewthread_ratex']);
$block_forumdisplay_top = rtj1009_block($_G['cache']['block_forumdisplay_top']);
$block_forumdisplay_zd = rtj1009_block($_G['cache']['block_forumdisplay_zd']);
$block_post_juhe = rtj1009_block($_G['cache']['block_post_juhe']);
$block_post_juhebage = rtj1009_block($_G['cache']['block_post_juhebage']);
$block_portal_vievtop = rtj1009_block($_G['cache']['block_portal_vievtop']);
$block_portal_vievzo = rtj1009_block($_G['cache']['block_portal_vievzo']);
$block_portal_vievfoo = rtj1009_block($_G['cache']['block_portal_vievfoo']);
$block_forum_si = rtj1009_block($_G['cache']['block_forum_si']);


$menulist = C::t('#rtj1009_mobilecp#rtj1009_m_menu')->fetch_all();
function rtj1009_isaurl($isaurl) {
    $old_url = $_SERVER["REQUEST_URI"];
    $check = strpos($old_url, $isaurl);
    if($check !== false) {
        return true;
    } else {
        return false;
    }
}

function rtj1009_isfirst($tid) {
    $postpid = DB::fetch_first('SELECT * FROM '.DB::table('forum_post').' WHERE tid = '.$tid.' AND first = 1');
    return $postpid;
}


$sidelistyi = C::t('#rtj1009_mobilecp#rtj1009_m_sidebar')->get_sidebar_typeyi();
$sideliste = C::t('#rtj1009_mobilecp#rtj1009_m_sidebar')->get_sidebar_typee();
$prmenulistyi = C::t('#rtj1009_mobilecp#rtj1009_m_prmenu')->get_prmenu_typeyi();
$prmenuliste = C::t('#rtj1009_mobilecp#rtj1009_m_prmenu')->get_prmenu_typee();
$prmenulists = C::t('#rtj1009_mobilecp#rtj1009_m_prmenu')->get_prmenu_types();
usort($prmenulistyi, 'cmp');
usort($prmenuliste, 'cmp');
usort($prmenulists, 'cmp');
usort($sidelistyi, 'cmp');
usort($sideliste, 'cmp');
function cmp($a, $b) {
    return $a['displayorder'] > $b['displayorder'] ? 1 : -1;
}
//From: dis'.'m.tao'.'bao.com
?>