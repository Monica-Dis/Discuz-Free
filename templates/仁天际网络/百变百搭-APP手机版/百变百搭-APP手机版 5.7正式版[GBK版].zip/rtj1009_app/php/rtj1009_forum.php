<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: rtj1009_forum.php 2017-08-10 18:07:44Z rtj1009_app $
 */
 
if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
}


$ren_tj_forums = unserialize($rtj1009_m_config['ren_tj_forums']);
$forums_fid = '';
foreach($ren_tj_forums as $key=>$value) {
    $forums_fid .= $value.",";
}

$forums_fid = rtrim($forums_fid , ",");


if (!empty($forums_fid)) {
    $forums_list = DB::fetch_all("SELECT a.fid,a.name,a.todayposts,a.threads,a.posts,b.icon FROM ".DB::table('forum_forum')." a LEFT JOIN ".DB::table('forum_forumfield')." b ON b.fid=a.fid WHERE a.fid in ($forums_fid) and a.type>='forum'");

}



?>
