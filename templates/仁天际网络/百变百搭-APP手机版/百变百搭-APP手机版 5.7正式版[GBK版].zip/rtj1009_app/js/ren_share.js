(function(share) {
    'use strict';

    var UA, uc, qq, wx, tc, qqVs, ucVs, os, qqBridgeDone;
    UA = navigator.appVersion;
    uc = UA.split('UCBrowser/').length > 1  ? 1 : 0;
    qq = UA.split('MQQBrowser/').length > 1 ? 2 : 0;
	wx = (function () {
        var a = UA.toLowerCase();
        if (a.match(/MicroMessenger/i) == "micromessenger" || a.match(/qq\//i) == "qq/") {
            return true
        } else {
            return false
        }
    }());

    qqVs = qq ? parseFloat(UA.split('MQQBrowser/')[1]) : 0;
    ucVs = uc ?  parseFloat(UA.split('UCBrowser/')[1]) : 0;
    os = (function () {
        var ua = navigator.userAgent;

        if (/iphone|ipod/i.test(ua)) {
            return 1;
        } else if(/android/i.test(ua)){
            return 2;
        } else {
            return 0;
        }
    }());

    qqBridgeDone = false;

    if ((qq && qqVs < 5.4 && os == 1) || (qq && qqVs < 5.3 && os == 1)) {
        qq = 0;
    } else {
        if (qq && qqVs < 5.4 && os == 2) {
            qq = 1;
        } else {
            if (uc && ( (ucVs < 10.2 && os == 1) || (ucVs < 9.7 && os == 2) )) {
                uc = 0;
            }
        }
    }


    function loadqqApi(cb) {
        if (!qq) {
            return cb && cb();
        }

        var qqApiScript = document.createElement('script');
        qqApiScript.onload = function () {cb && cb();};
        qqApiScript.onerror = function () {};
        qqApiScript.src = (qq == 1 ) ? 'https://3gimg.qq.com/html5/js/qb.js' : 'https://jsapi.qq.com/get?api=app.share';
        document.body.appendChild(qqApiScript);
    }

    function ucShare(config) {
        
        var platform = '', shareInfo;

        if (config.type) {
            if (os == 2) {
                platform = config.type == 1 ? 'WechatTimeline' : 'WechatFriends';
            } else if (os == 1) {
                platform = config.type == 1 ? 'kWeixinFriend' : 'kWeixin';
            }
        }

        shareInfo = [ config.title, config.desc, config.url, platform, '', '', '' ];

        if (window.ucweb) {
            ucweb.startRequest && ucweb.startRequest('shell.page_share', shareInfo);
        } else if (window.ucbrowser) {
            ucbrowser.web_share && ucbrowser.web_share.apply(null, shareInfo);
        }

    };
    

    function qqshare(config) {
        var type = config.type;
        type = type ? ((type == 1) ? 8 : 1) : ''; 
        var share = function () {
            var shareInfo = {
                'url': config.url,
                'title': config.title,
                'description': config.desc,
                'img_url': config.img,
                'img_title': config.title,
                'to_app': type,
                'cus_txt': ''
            };

            if (window.browser) {
                browser.app && browser.app.share(shareInfo);
            } else if (window.qb) {
                qb.share && qb.share(shareInfo);
            }
        };

        if (qqBridgeDone) {
            share();
        } else {
            loadqqApi(share);
        }
    };

    function ishare(config,share_button) {    
        this.config = config;             
        this.init = function (type,share_button) {
			this.share_button = share_button;
            if (typeof type != 'undefined') this.config.type = type;
            try {
                if (uc) {
                    ucShare(this.config);
					$('.ren_share').removeClass("open-popup");
                } else if (qq && !wx) {
                    qqshare(this.config);
					$('.ren_share').removeClass("open-popup");
                } else if (wx) {
					$(this.share_button).after('<div class="ren_share_ts" onclick="this.remove()"></div>');
					$('.ren_share').removeClass("open-popup");
				}
            } catch (f) {}


            $(document).on('click', '.bdsharebuttonbox a', function() {
                var obj = $(this);
                if (obj.attr('data-cmd') == 'sqq'){
                    window.open('https://connect.qq.com/widget/shareqq/index.html?url='+encodeURIComponent(config.url)+'&desc='+urlencode(config.desc)+'&title='+urlencode(config.title)+'&pics='+encodeURIComponent(config.img));
                } else if(obj.attr('data-cmd') == 'qzone'){
                    window.open('https://h5.qzone.qq.com/q/qzs/open/connect/widget/mobile/qzshare/index.html?page=qzshare.html&loginpage=loginindex.html&logintype=qzone&title='+urlencode(config.title)+'&summary='+urlencode(config.desc)+'&url='+encodeURIComponent(config.url)+'&desc='+urlencode(config.desc)+'&imageUrl='+encodeURIComponent(config.img)+'&site=&sid=&referer='+encodeURIComponent(config.url));
                } else if(obj.attr('data-cmd') == 'tsina'){
                    window.open('https://service.weibo.com/share/share.php?url='+encodeURIComponent(config.url)+'&appkey=&title='+urlencode(config.title)+'&pic='+encodeURIComponent(config.img)+'&language=zh_cn&referer='+encodeURIComponent(config.url));
                }
            });

        }
    };

    function urlencode (str) {
        str = (str + '').toString();
        return encodeURIComponent(str).replace(/!/g, '%21').replace(/'/g, '%27').replace(/\(/g, '%28').
        replace(/\)/g, '%29').replace(/\*/g, '%2A').replace(/%20/g, '+');
    }

    loadqqApi(function () {
        qqBridgeDone = true;
    });

    share.ren_share = ishare;

})(this);



