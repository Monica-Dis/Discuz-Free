<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
	$thread['post'] = C::t('forum_post')->fetch_all_by_tid_position($thread['posttableid'],$thread['tid'],1);
	$thread['post'] = array_shift($thread['post']);
	$ren_pic = C::t('forum_attachment_n')->count_image_by_id('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid']);
	$shustars = DB::fetch_first("SELECT b.* FROM ".DB::table("common_member")." a LEFT JOIN ".DB::table("common_usergroup")." b on b.groupid=a.groupid WHERE a.`uid` = '$thread[authorid]'");
	$isfollowuid = DB::result_first("SELECT followuid FROM ".DB::table("home_follow")." WHERE `uid` = $_G[uid] AND `followuid`=$thread[authorid]");
	$imgurlx = rtj1009_imgurl($thread['post']['message']);
	$rtj1009_msg = rtj1009_msg($thread['post']['message']);
	$vediourlx = rtj1009_vedio_url($thread['post']['message']);
}-->



<!--{if ($rtj1009_list_style['style'] ==0) || ($rtj1009_list_style['style'] ==1) || ($rtj1009_list_style['style'] ==7)}-->
<!--{if $ren_pic <=2}--><!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid'], 1);}--><!--{/if}-->
<!--{if $ren_pic >=3}--><!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid'], 3);}--><!--{/if}-->

<!--{if $ren_pic <=2 || $rtj1009_list_style['style'] ==7}-->
	<li>
		<!--{if $rtj1009_list_style['style'] ==0}-->
		<div class="ren_twsj">
			<a class="ren_twus_img z cl" href="<!--{if $thread['authorid'] && $thread['author']}-->home.php?mod=space&uid=$thread[authorid]&do=profile<!--{else}-->javascript:;<!--{/if}-->">
				<!--{if $thread['authorid'] && $thread['author']}-->
					<!--{avatar($thread[authorid],middle)}-->
				<!--{else}-->
					<img src="<!--{avatar(0, small, true)}-->" />
				<!--{/if}-->
			</a>
			<!--{if $thread['authorid'] && $thread['author']}-->
			<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
			<!--{else}-->
				<a class="ren_twus_name z cl" href="javascript:;">$_G[setting][anonymoustext]</a>
			<!--{/if}-->
			<!--{if ($rtj1009_m_config['ren_m_forum_xing'] || $rtj1009_m_config['ren_forum_utitle']) && $thread['authorid'] && $thread['author']}-->
            <span class="ren_us_xing"><!--{if $rtj1009_m_config['ren_m_forum_xing']}-->Lv.{$shustars[stars]}<!--{/if}--><!--{if $rtj1009_m_config['ren_forum_utitle']}--> {$shustars[grouptitle]}<!--{/if}--></span>
            <!--{/if}-->
            <!--{if $rtj1009_m_config['ren_m_forum_shustars']}-->
            <!--{if $shustars[icon] && $thread['authorid'] && $thread['author']}-->
            <span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
            <!--{/if}-->
            <!--{/if}-->
			<!--{if $rtj1009_m_config['ren_m_forum_verify'] == 1 && $thread['authorid'] && $thread['author']}--><span class="verify"><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}--></span><!--{/if}-->
			<!--{if $thread['authorid'] && $thread['author']}-->
			<div class="y">
				<!--{if !$isfollowuid}-->
				<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_zz_gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]">{$rtj1009_lang['ren022']}</a>
				<!--{else}-->
				<a class="dialog ren_qxgz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$thread[authorid]">{$rtj1009_lang['ren031']}</a>
				<!--{/if}-->
			</div>
			<!--{/if}-->
		</div>
		<!--{/if}-->

		<div class="ren_tw_yiimg">
            <!--{if $rtj1009_list_style['style'] !=7}-->
            <!--{if ($threadlistimg || $imgurlx) && !$vediourlx}-->
                <!--{if $threadlistimg}-->
                <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_threadimg y">
                    <!--{if $ren_pic <=2}-->
                    <!--{loop $threadlistimg $values}-->
                    <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
                    <span class="ren_thread_imge ren_thread_img"><img src="$renlistimgkey" /></span>
                    <!--{/loop}-->
                    <!--{/if}-->
                </a>
                <!--{elseif $imgurlx}-->
                <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_threadimg imgurltu y">
                    <!--{eval echo $imgurlx;}-->
                </a>
                <!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
			<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_tw_yi<!--{if $rtj1009_list_style['style'] ==0}--><!--{if ($ren_pic || $imgurlx) && !$vediourlx}--> tw-tu<!--{/if}--><!--{/if}-->" <!--{if $rtj1009_list_style['style'] ==1}-->style="<!--{if ($ren_pic || $imgurlx) && !$vediourlx}-->height: 48px; margin-bottom: 5px; overflow: hidden;<!--{/if}-->"<!--{/if}-->>
				<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				<!--{if !$rtj1009_m_config['ren_m_forum_tst']}-->
					<span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
				<!--{/if}-->
				<!--{elseif $thread['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
				<!--{if !$_G[forum_thread][special]}-->
					{if $thread['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
					{if $thread['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
					{if $thread['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
					{if $thread['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
					{if $thread['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
				<!--{/if}-->

				<sapn $thread[highlight]>{$thread[subject]}</sapn>
			 </a>
			<!--{if $rtj1009_list_style['style'] ==1 || $rtj1009_list_style['style'] ==7}-->
            <!--{if $rtj1009_m_config['list_video_radio'] && $rtj1009_list_style['style'] !=7}--><!--{eval echo $vediourlx}--><!--{/if}-->
			<div class="ren_list_us<!--{if $rtj1009_list_style['style'] ==7}--> ren-list-us7<!--{/if}-->">
				<a class="ren_twus_img z cl" href="<!--{if $thread['authorid'] && $thread['author']}-->home.php?mod=space&uid=$thread[authorid]&do=profile<!--{else}-->javascript:;<!--{/if}-->">
					<!--{if $thread['authorid'] && $thread['author']}-->
						<!--{avatar($thread[authorid],middle)}-->
					<!--{else}-->
						<img src="<!--{avatar(0, small, true)}-->" />
					<!--{/if}-->
				</a>
				<!--{if $thread['authorid'] && $thread['author']}-->
					<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
				<!--{else}-->
					<a class="ren_twus_name z cl" href="javascript:;">$_G[setting][anonymoustext]</a>
				<!--{/if}-->
                <!--{if $rtj1009_list_style['style'] ==7}-->
				<!--{if ($rtj1009_m_config['ren_m_forum_xing'] || $rtj1009_m_config['ren_forum_utitle']) && $thread['authorid'] && $thread['author']}-->
                <span class="ren_us_xing"><!--{if $rtj1009_m_config['ren_m_forum_xing']}-->Lv.{$shustars[stars]}<!--{/if}--><!--{if $rtj1009_m_config['ren_forum_utitle']}--> {$shustars[grouptitle]}<!--{/if}--></span>
                <!--{/if}-->
                <!--{if $rtj1009_m_config['ren_m_forum_shustars']}-->
                <!--{if $shustars[icon] && $thread['authorid'] && $thread['author']}-->
                <span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $rtj1009_m_config['ren_m_forum_verify'] == 1 && $thread['authorid'] && $thread['author']}--><span class="verify z"><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}--></span><!--{/if}-->
                <!--{/if}-->
				<span class="time z" style="<!--{if !$ren_pic || $rtj1009_list_style['style'] ==7}-->display: block;<!--{else}-->display: none;<!--{/if}-->">{$thread[dateline]}</span>
				<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_list_li_xx y" >
					<span class="reply y"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
					<span class="views y"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
				</a>
			</div>
			<!--{/if}-->
		 </div>
        <!--{if $rtj1009_list_style['style'] !=1 && $rtj1009_list_style['style'] !=7}-->
        <!--{if $rtj1009_m_config['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
        <!--{/if}-->
	   	<!--{if $rtj1009_list_style['style'] ==0}-->
		<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_twsj_xx" >
			<span class="ren_twsj_sj z"><i class="icon ren-font">&#xe61c;</i>{$thread[dateline]}</span>
			<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
			<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
		</a>
		<!--{/if}-->
	</li>

	<!--{else}-->
	<li>
		<!--{if $rtj1009_list_style['style'] ==0}-->
		<div class="ren_twsj">
			<a class="ren_twus_img z cl" href="<!--{if $thread['authorid'] && $thread['author']}-->home.php?mod=space&uid=$thread[authorid]&do=profile<!--{else}-->javascript:;<!--{/if}-->">
				<!--{if $thread['authorid'] && $thread['author']}-->
					<!--{avatar($thread[authorid],middle)}-->
				<!--{else}-->
					<img src="<!--{avatar(0, small, true)}-->" />
				<!--{/if}-->
			</a>
			<!--{if $thread['authorid'] && $thread['author']}-->
				<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
			<!--{else}-->
				<a class="ren_twus_name z cl" href="javascript:;">$_G[setting][anonymoustext]</a>
			<!--{/if}-->
			<!--{if ($rtj1009_m_config['ren_m_forum_xing'] || $rtj1009_m_config['ren_forum_utitle']) && $thread['authorid'] && $thread['author']}-->
            <span class="ren_us_xing"><!--{if $rtj1009_m_config['ren_m_forum_xing']}-->Lv.{$shustars[stars]}<!--{/if}--><!--{if $rtj1009_m_config['ren_forum_utitle']}--> {$shustars[grouptitle]}<!--{/if}--></span>
            <!--{/if}-->
            <!--{if $rtj1009_m_config['ren_m_forum_shustars']}-->
            <!--{if $shustars[icon] && $thread['authorid'] && $thread['author']}-->
            <span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
            <!--{/if}-->
            <!--{/if}-->
			<!--{if $rtj1009_m_config['ren_m_forum_verify'] == 1 && $thread['authorid'] && $thread['author']}--><span class="verify"><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}--></span><!--{/if}-->
			<!--{if $thread['authorid'] && $thread['author']}-->
			<div class="y">
				<!--{if !$isfollowuid}-->
				<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_zz_gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]">{$rtj1009_lang['ren022']}</a>
				<!--{else}-->
				<a class="dialog ren_qxgz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$thread[authorid]">{$rtj1009_lang['ren031']}</a>
				<!--{/if}-->
			</div>
			<!--{/if}-->
		</div>
		<!--{/if}-->
		<div class="ren_twbt">
			<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				<!--{if !$rtj1009_m_config['ren_m_forum_tst']}-->
					<span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
				<!--{/if}-->
				<!--{elseif $thread['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
			<!--{if !$_G[forum_thread][special]}-->
				{if $thread['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
				{if $thread['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
				{if $thread['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
				{if $thread['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
				{if $thread['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
			<!--{/if}-->

			<a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight]>{$thread[subject]}</a>
		 </div>
        <!--{if $threadlistimg && !$vediourlx}-->
		<div class="ren_threadimg">
			<a href="forum.php?mod=viewthread&tid=$thread[tid]">
				<!--{if $ren_pic >=3}-->
				<!--{loop $threadlistimg $values}-->
				<!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
					<span class="ren_thread_imgsan ren_thread_img"><img src="$renlistimgkey"/></span>
				<!--{/loop}-->
				<!--{/if}-->
			</a>
		</div>
		<!--{/if}-->
        <!--{if $rtj1009_m_config['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
	   	<!--{if $rtj1009_list_style['style'] ==0}-->
		<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_twsj_xx" >
			<span class="ren_twsj_sj z"><i class="icon ren-font">&#xe61c;</i>{$thread[dateline]}</span>
			<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
			<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
		</a>
		<!--{else}-->
		<div class="ren_list_us">
			<a class="ren_twus_img z cl" href="<!--{if $thread['authorid'] && $thread['author']}-->home.php?mod=space&uid=$thread[authorid]&do=profile<!--{else}-->javascript:;<!--{/if}-->">
				<!--{if $thread['authorid'] && $thread['author']}-->
					<!--{avatar($thread[authorid],middle)}-->
				<!--{else}-->
					<img src="<!--{avatar(0, small, true)}-->" />
				<!--{/if}-->
			</a>
			<!--{if $thread['authorid'] && $thread['author']}-->
				<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
			<!--{else}-->
				<a class="ren_twus_name z cl" href="javascript:;">$_G[setting][anonymoustext]</a>
			<!--{/if}-->
			<span class="time z">{$thread[dateline]}</span>
			<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_list_li_xx y" >
				<span class="reply y"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
				<span class="views y"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
			</a>
		</div>
		<!--{/if}-->
	</li>
<!--{/if}-->

<!--{elseif ($rtj1009_list_style['style'] ==2) || ($rtj1009_list_style['style'] ==3)}-->
<!--{if $ren_pic ==1}--><!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid'], 1);}--><!--{/if}-->
<!--{if $ren_pic <=4}--><!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid'], 3);}--><!--{/if}-->
<!--{if $ren_pic >=5}--><!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid'], 6);}--><!--{/if}-->
<!--{if $ren_pic >=9}--><!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid'], 9);}--><!--{/if}-->
	<li>
		<div class="ren_twsj ren_list_tu">
			<a class="ren_twus_img z cl" href="<!--{if $thread['authorid'] && $thread['author']}-->home.php?mod=space&uid=$thread[authorid]&do=profile<!--{else}-->javascript:;<!--{/if}-->">
				<!--{if $thread['authorid'] && $thread['author']}-->
						<!--{avatar($thread[authorid],middle)}-->
					<!--{else}-->
						<img src="<!--{avatar(0, small, true)}-->" />
					<!--{/if}-->
			</a>
			<div class="z ren_author">
			<!--{if $thread['authorid'] && $thread['author']}-->
				<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
			<!--{else}-->
				<a class="ren_twus_name z cl" href="javascript:;">$_G[setting][anonymoustext]</a>
			<!--{/if}-->
                <!--{if ($rtj1009_m_config['ren_m_forum_xing'] || $rtj1009_m_config['ren_forum_utitle']) && $thread['authorid'] && $thread['author']}-->
                <span class="ren_us_xing"><!--{if $rtj1009_m_config['ren_m_forum_xing']}-->Lv.{$shustars[stars]}<!--{/if}--><!--{if $rtj1009_m_config['ren_forum_utitle']}--> {$shustars[grouptitle]}<!--{/if}--></span>
                <!--{/if}-->
                <!--{if $rtj1009_m_config['ren_m_forum_shustars']}-->
                <!--{if $shustars[icon] && $thread['authorid'] && $thread['author']}-->
                <span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
                <!--{/if}-->
                <!--{/if}-->
			<!--{if $rtj1009_m_config['ren_m_forum_verify'] == 1 && $thread['authorid'] && $thread['author']}-->
				<span class="verify"><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}--></span>
			<!--{/if}-->
			</div>
			<div class="z ren_thread_sj">
				<span class="z ren_thread_dateline"><!--{if $_GET['typeid'] == $id}-->{$rtj1009_lang['ren033']}<!--{/if}-->{$thread[dateline]}</span>
				<!--{if !$_GET['typeid'] == $id}--><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid={$thread['typeid']}" class="z">{$rtj1009_lang['ren032']}{$_G['forum']['threadtypes']['types'][$thread['typeid']]}</a><!--{/if}-->
			</div>
			<!--{if $thread['authorid'] && $thread['author']}-->
			<div class="ren_gz">
				<!--{if !$isfollowuid}-->
				<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren_zz_gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$thread[authorid]">{$rtj1009_lang['ren022']}</a>
				<!--{else}-->
				<a class="dialog ren_qxgz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$thread[authorid]">{$rtj1009_lang['ren031']}</a>
				<!--{/if}-->
			</div>
			<!--{/if}-->
		</div>
		<div class="ren_twbt tu">
			<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				<!--{if !$rtj1009_m_config['ren_m_forum_tst']}-->
					<span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
				<!--{/if}-->
				<!--{elseif $thread['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
			<!--{if !$_G[forum_thread][special]}-->
				{if $thread['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
				{if $thread['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
				{if $thread['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
				{if $thread['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
				{if $thread['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
			<!--{/if}-->

			<a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight]>{$thread[subject]}</a>
		 </div>
        <!--{if $thread['post']['message']}-->
        <div class="forum_message">
            <a href="forum.php?mod=viewthread&tid=$thread[tid]"><!--{eval echo $rtj1009_msg}--></a>
        </div>
        <!--{/if}-->
        <!--{if $rtj1009_m_config['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->

        <!--{if ($threadlistimg || $imgurlx) && !$vediourlx}-->
		<div class="ren_threadimg tu">
			<a href="forum.php?mod=viewthread&tid=$thread[tid]">
                <!--{if $threadlistimg}-->
                    <!--{if $ren_pic ==1}-->
                    <!--{loop $threadlistimg $values}-->
                    <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 350, 9999); }-->
                        <span class="yige_img ren_thread_img"><img src="$renlistimgkey"/></span>
                    <!--{/loop}-->
                    <!--{else}-->
                    <!--{loop $threadlistimg $values}-->
                    <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 150); }-->
                        <span class="ren_thread_imgsan ren_thread_img"><img src="$renlistimgkey"/></span>
                    <!--{/loop}-->
                    <!--{/if}-->
                <!--{elseif $imgurlx}-->
                    <!--{eval echo $imgurlx}-->
                <!--{/if}-->
			</a>
		</div>
		<!--{/if}-->

		<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_twsj_xx tu">
			<span class="ren_twsj_ck z"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
			<span class="ren_twsj_hf z"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
			<span class="ren_twsj_sj z"><i class="icon ren-font">&#xe856;</i>{$thread[recommend_add]}</span>
		</a>


        <!--{if $rtj1009_list_style['style'] ==3}-->
        <!--{eval
            $recommend_list = recommend_list($thread['tid']);
            $num_rows = DB::query('SELECT * FROM ' .DB::table('forum_memberrecommend') . " WHERE tid='.$thread[tid].'");
            $recommend_num = DB::num_rows($num_rows);
            $replylist = fetch_replylist($thread['tid']);
        }-->
        <!--{if $replylist || $recommend_list}-->
        <div class="ren-zan-list">
            <div class="ren-zan-listinfo">
                <div class="ren-recommend-list">
                    <i class="z ren-font">&#xea84;</i>
                    <span class="z">{$recommend_num}��</span>
                    <!--{loop $recommend_list $key $value}-->
                    <a href="home.php?mod=space&uid={$value[recommenduid]}&do=profile" class=""><!--{avatar($value[recommenduid],middle)}--></a>
                    <!--{/loop}-->
                </div>
                <!--{if $replylist}-->
                <ul class="ren-reply-list">
                    <!--{loop $replylist $key $value}-->
                    <!--{eval $reply = rtj1009_reply_msg($value[message])}-->
                    <li>
                        <a href="home.php?mod=space&uid={$value[authorid]}&do=profile" class="">{$value[author]}</a>: {$reply}
                    </li>
                    <!--{/loop}-->
                </ul>
                <!--{/if}-->
            </div>
        </div>
        <!--{/if}-->
        <!--{/if}-->

	</li>
<!--{elseif ($rtj1009_list_style['style'] ==4) || ($rtj1009_list_style['style'] ==5) || ($rtj1009_list_style['style'] ==6)}-->
<!--{eval $threadlistimg = fetch_ren_attachment_aid('tid:'.$thread['post']['tid'], 'pid', $thread['post']['pid'], 1);}-->
    <!--{if $rtj1009_list_style['style'] ==4}-->
	<li>
		<div class="ren_tw_yiimg">
            <!--{if ($threadlistimg || $imgurlx) && !$vediourlx}-->
                <!--{if $threadlistimg}-->
                <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_threadimg z">
                    <!--{if $ren_pic}-->
                    <!--{loop $threadlistimg $values}-->
                    <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 200, 140); }-->
                    <span class="ren_thread_imge ren_thread_img"><img src="$renlistimgkey" /></span>
                    <!--{/loop}-->
                    <!--{/if}-->
                </a>
                <!--{elseif $imgurlx}-->
                <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_threadimg z imgurlsan">
                    <!--{eval echo $imgurlx;}-->
                </a>
                <!--{/if}-->
            <!--{/if}-->

			<div class="ren_tw_yi" style="margin-bottom: 5px; <!--{if ($ren_pic || $imgurlx) && !$vediourlx}-->height: 48px; margin-top: 5px; overflow: hidden;<!--{/if}-->">
				<!--{hook/forumdisplay_thread_mobile $key}-->
				<!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
				<!--{if !$rtj1009_m_config['ren_m_forum_tst']}-->
					<span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
				<!--{/if}-->
				<!--{elseif $thread['digest'] > 0}-->
					<span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
				<!--{/if}-->
				<!--{if !$_G[forum_thread][special]}-->
					{if $thread['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
					{if $thread['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
					{if $thread['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
					{if $thread['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
					{if $thread['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
				<!--{/if}-->

				<a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight]>{$thread[subject]}</a>
			 </div>
            <!--{if $rtj1009_m_config['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
			 <div class="ren_list_us">
				<a class="ren_twus_img z cl" href="<!--{if $thread['authorid'] && $thread['author']}-->home.php?mod=space&uid=$thread[authorid]&do=profile<!--{else}-->javascript:;<!--{/if}-->">
					<!--{if $thread['authorid'] && $thread['author']}-->
						<!--{avatar($thread[authorid],middle)}-->
					<!--{else}-->
						<img src="<!--{avatar(0, small, true)}-->" />
					<!--{/if}-->
				</a>
				<!--{if $thread['authorid'] && $thread['author']}-->
					<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
				<!--{else}-->
					<a class="ren_twus_name z cl" href="javascript:;">$_G[setting][anonymoustext]</a>
				<!--{/if}-->
				<span class="time z" style="<!--{if !$ren_pic}-->display: block;<!--{else}-->display: none;<!--{/if}-->">{$thread[dateline]}</span>
				<a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_list_li_xx y" >
					<span class="reply y"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
					<span class="views y"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
				</a>
			</div>
		 </div>
	</li>
    <!--{elseif $rtj1009_list_style['style'] ==5}-->
    <li>
        <div class="ren_tw_yiimg">
            <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_threadimg z">
            <!--{if $threadlistimg || $imgurlx}-->
            <!--{if $threadlistimg}-->
                <!--{if $ren_pic}-->
                <!--{loop $threadlistimg $values}-->
                <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 300, 240); }-->
                <span class="ren_thread_imge ren_thread_img"><img src="$renlistimgkey" /></span>
                <!--{/loop}-->
                <!--{/if}-->
            <!--{elseif $imgurlx}-->
                <!--{eval echo $imgurlx;}-->
            <!--{/if}-->
            <!--{/if}-->
            </a>

            <div class="ren_tw_yi">
                <a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight]>{$thread[subject]}</a>
            </div>
            <div class="ren_list_us">
                <a class="ren_twus_img z cl" href="<!--{if $thread['authorid'] && $thread['author']}-->home.php?mod=space&uid=$thread[authorid]&do=profile<!--{else}-->javascript:;<!--{/if}-->">
                    <!--{if $thread['authorid'] && $thread['author']}-->
						<!--{avatar($thread[authorid],middle)}-->
					<!--{else}-->
						<img src="<!--{avatar(0, small, true)}-->" />
					<!--{/if}-->
                </a>
				<!--{if $thread['authorid'] && $thread['author']}-->
					<a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
				<!--{else}-->
					<a class="ren_twus_name z cl" href="javascript:;">$_G[setting][anonymoustext]</a>
				<!--{/if}-->
                <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_list_li_xx y">
                    <span class="views y"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
                </a>
            </div>
        </div>
    </li>
    <!--{elseif $rtj1009_list_style['style'] ==6}-->
    <li>
        <div class="ren_tw_yiimg">
            <!--{if ($threadlistimg || $imgurlx) && !$vediourlx}-->
            <!--{if $threadlistimg}-->
            <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_threadimg z">
                <!--{if $ren_pic}-->
                <!--{loop $threadlistimg $values}-->
                <!--{eval $renlistimgkey = getforumimg($values[aid], 0, 620, 9999); }-->
                <span class="ren_thread_imge ren_thread_img"><img src="$renlistimgkey" /></span>
                <!--{/loop}-->
                <!--{/if}-->
            </a>
            <!--{elseif $imgurlx}-->
            <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_threadimg z imgurlsan">
                <!--{eval echo $imgurlx;}-->
            </a>
            <!--{/if}-->
            <!--{/if}-->

            <!--{if $rtj1009_m_config['list_video_radio']}--><!--{eval echo $vediourlx}--><!--{/if}-->
            <div class="ren_tw_yi" style="margin-bottom: 5px;">
                <!--{hook/forumdisplay_thread_mobile $key}-->
                <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                <!--{if !$rtj1009_m_config['ren_m_forum_tst']}-->
                <span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
                <!--{/if}-->
                <!--{elseif $thread['digest'] > 0}-->
                <span class="ren_jinghua">{$rtj1009_lang['ren021']}</span>
                <!--{/if}-->
                <!--{if !$_G[forum_thread][special]}-->
                {if $thread['special'] == 1}<span class="ren_jinghua">{lang thread_poll}</span>{/if}
                {if $thread['special'] == 2}<span class="ren_jinghua">{lang thread_trade}</span>{/if}
                {if $thread['special'] == 3}<span class="ren_jinghua">{lang thread_reward}</span>{/if}
                {if $thread['special'] == 4}<span class="ren_jinghua">{lang thread_activity}</span>{/if}
                {if $thread['special'] == 5}<span class="ren_jinghua">{lang thread_debate}</span>{/if}
                <!--{/if}-->

                <a href="forum.php?mod=viewthread&tid=$thread[tid]" $thread[highlight]>{$thread[subject]}</a>
            </div>
            <div class="ren_list_us">
                <a class="ren_twus_img z cl" href="<!--{if $thread['authorid'] && $thread['author']}-->home.php?mod=space&uid=$thread[authorid]&do=profile<!--{else}-->javascript:;<!--{/if}-->">
                    <!--{if $thread['authorid'] && $thread['author']}-->
						<!--{avatar($thread[authorid],middle)}-->
					<!--{else}-->
						<img src="<!--{avatar(0, small, true)}-->" />
					<!--{/if}-->
                </a>
                <!--{if $thread['authorid'] && $thread['author']}-->
                <a class="ren_twus_name z cl" href="home.php?mod=space&uid=$thread[authorid]&do=profile">$thread[author]</a>
                <!--{else}-->
                <a class="ren_twus_name z cl" href="javascript:;">$_G[setting][anonymoustext]</a>
                <!--{/if}-->
				<!--{if ($rtj1009_m_config['ren_m_forum_xing'] || $rtj1009_m_config['ren_forum_utitle']) && $thread['authorid'] && $thread['author']}-->
                <span class="ren_us_xing"><!--{if $rtj1009_m_config['ren_m_forum_xing']}-->Lv.{$shustars[stars]}<!--{/if}--><!--{if $rtj1009_m_config['ren_forum_utitle']}--> {$shustars[grouptitle]}<!--{/if}--></span>
                <!--{/if}-->
                <!--{if $rtj1009_m_config['ren_m_forum_shustars']}-->
                <!--{if $shustars[icon] && $thread['authorid'] && $thread['author']}-->
                <span class="starsico"><img src="data/attachment/common/$shustars[icon]" class="vm"/></span>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $rtj1009_m_config['ren_m_forum_verify'] == 1 && $thread['authorid'] && $thread['author']}--><span class="verify"><!--{if !empty($verify[$thread['authorid']])}--> $verify[$thread[authorid]]<!--{/if}--></span><!--{/if}-->
                <a href="forum.php?mod=viewthread&tid=$thread[tid]" class="ren_list_li_xx y" >
                    <span class="reply y"><i class="icon ren-font">&#xe694;</i>{$thread[replies]}</span>
                    <span class="views y"><i class="icon ren-font">&#xe660;</i>{$thread[views]}</span>
                </a>
            </div>
        </div>
    </li>
    <!--{/if}-->
<!--{/if}-->


