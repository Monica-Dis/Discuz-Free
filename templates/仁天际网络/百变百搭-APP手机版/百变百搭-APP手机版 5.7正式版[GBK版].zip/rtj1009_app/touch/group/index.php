<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span class="ren_bk_name">$_G[setting][navs][3][navname]</span>
		</div>
		<div class="y ren_list_nav">
            <a href="forum.php?mod=group&action=create" class="ren-nav-group">{$rtj1009_lang['group001']}</a>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content ren-group">
	<form class="searchform" method="post" autocomplete="off" action="search.php?mod=group">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="srchfid" value="$srchfid" />
		<div class="content-padded">
		  <div class="searchbar">
			<div class="search-input">
			  <label class="icon icon-sousuo" for="search"></label>
			  <input value="$keyword" autocomplete="off" class="input" name="srchtxt" id="scform_srchtxt" value="" placeholder="{$rtj1009_lang['group002']}">
			</div>
			<a class="button button-fill button-primary"><input type="hidden" name="searchsubmit" value="yes"><input type="submit" value="{lang search}" class="button2" id="scform_submit"></a>
		  </div>
		</div>
	</form>
	
	{$block_group}
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
            <!--{eval $groupsubshu = DB::fetch_first("SELECT fid FROM ".DB::table("forum_forum")." WHERE `type` = 'group' and `status` = 3 and `fup` = 0");}-->
			<a href="javascript:void(0);" class="a">{$rtj1009_lang['ren141']}$_G[setting][navs][3][navname]</a>
			<a href="group.php?gid={$groupsubshu['fid']}">{$rtj1009_lang['ren023']}$_G[setting][navs][3][navname]</a>
			<a href="group.php?mod=my&view=join">{$rtj1009_lang['ren005']}$_G[setting][navs][3][navname]</a>
		</div>
	</div>
	<div class="ren-friend-list cl">
		<ul class="ren-friend-re cl">
		<!--{loop dunserialize($_G['setting']['group_recommend']) $val}-->
			<!--{eval $statusxx = DB::fetch_first("SELECT * FROM  ".DB::table('forum_groupuser')." WHERE  uid=".$_G[uid]." and fid=".$val['fid']."");}-->
			<li class="<!--{if $statusxx}-->ren-statusxx-wu<!--{/if}--> cl">
				<div class="ren-list-usxx">
					<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="ren-us-img z">
						<img src="$val[icon]">
					</a>
					<div class="z ren-us-name">
						<a href="forum.php?mod=forumdisplay&action=list&fid=$val[fid]" class="z">$val[name]</a>
					</div>
					<div class="z ren-us-dateline">
						$val[description]
					</div>
					<!--{if !$statusxx}-->
					<div class="y ren-friend-in">
						<a href="forum.php?mod=group&action=join&fid=$val[fid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->tu z">{$rtj1009_lang['group003']}</a>
					</div>
					<!--{/if}-->
				</div>
			</li>
		<!--{/loop}-->
		</ul>
	</div>
</div>


<!--{template common/footer}-->
