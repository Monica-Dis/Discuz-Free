<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span class="ren_bk_name">{$rtj1009_lang['ren005']}$_G[setting][navs][3][navname]</span>
		</div>
		<div class="y ren_list_nav">
            <a href="forum.php?mod=group&action=create" class="ren-nav-group">{$rtj1009_lang['group001']}</a>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->


<div class="content p-b-0 ren-group-my">
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
			<a href="group.php?mod=my&view=groupthread" $actives[groupthread]>{lang group_thread}</a>
			<a href="group.php?mod=my&view=mythread" $actives[mythread]>{lang my_thread}</a>
			<a href="group.php?mod=my&view=join" $actives[join]>{lang my_join}</a>
			<a href="group.php?mod=my&view=manager" $actives[manager]>{lang my_manage}</a>
		</div>
	</div>
	<!--{if $view == 'groupthread' || $view == 'mythread'}-->

		<!--{if $attentionthread}-->
			<div class="ren_tie_list rtj1009_ss_main cl">
			<!--{loop $attentionthread $groupid $threads}-->
				<ul class="z ren_list cl">
				<!--{loop $threads $tid $thread}-->
					<!--{subtemplate rtj1009_core/group_forum_list}-->
				<!--{/loop}-->
				</ul>
			<!--{/loop}-->
			</div>
		<!--{/if}-->

		<!--{if $groupthreadlist}-->
		<div class="ren_tie_list rtj1009_ss_main cl">
			<ul class="z ren_list cl">
			<!--{loop $groupthreadlist $tid $thread}-->
				<!--{subtemplate rtj1009_core/group_forum_list}-->
			<!--{/loop}-->
			</ul>
		</div>
		<!--{/if}-->

	<!--{if $multipage}--><div class="pgs cl">$multipage</div><!--{/if}-->

	<!--{elseif $view == 'manager' || $view == 'join'}-->
		<!--{if $grouplist}-->
			<div class="ren-group-sslist cl">
				<ul class="ren-group-re cl">
				<!--{loop $grouplist $groupid $group}-->
					<li class="cl">
						<a href="forum.php?mod=group&fid=$groupid" class="ren-list-usxx">
							<div class="ren-us-img z">
								<img src="$group[icon]">
							</div>
							<div class="z ren-us-name">
								<!--{if $group['flevel'] == '-1'}-->({lang group_wait_mod})<!--{/if}--><span class="z">$group[name]</span>
							</div>
							<div class="z ren-us-dateline">
								<span class="info_label">{lang threads}</span>
								<span class="info_value">$group[threads]</span>
							</div>
							<div class="y ren-group-in"></div>
						</a>
					</li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{if $multipage}--><div class="pgs">$multipage</div><!--{/if}-->
		<!--{else}-->
			<div class="ren_ss_wu">
				<i class="icon ren-font">&#xe608;</i>
				<span><!--{if $view == 'manager'}-->{$rtj1009_lang['group006']}<!--{elseif $view == 'join'}-->{$rtj1009_lang['group007']}<!--{/if}--></span>
			</div>
		<!--{/if}-->
	<!--{/if}-->
</div>

<!--{template common/footer}-->
