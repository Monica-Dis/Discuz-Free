<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $op == 'alluser'}-->
	<!--{if $adminuserlist}-->
		<div class="ren-group-mem">
			<div class="ren_m_mkbt">
				<span>{lang group_admin_member}</span>
			</div>
			<ul class="ren-friend-re cl">
			<!--{loop $adminuserlist $user}-->
				<li>
					<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="ren-list-usxx">
						<div class="ren-us-img z">
							<!--{echo avatar($user[uid], 'small')}-->
						</div>
						<div class="z ren-us-name tu">
							<div class="z ren-mana-name">$user[username]<span>{if $user['level'] == 1}{lang group_moderator_title}{elseif $user['level'] == 2}{lang group_moderator_vice_title}{/if}{if $user['online']} {lang login_normal_mode}{/if}</span></div>
						</div>
					</a>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if $staruserlist || $alluserlist}-->
		<div class="ren-group-mem">
			<div class="ren_m_mkbt">
				<span>$_G[setting][navs][3][navname]{lang member}</span>
			</div>
			<!--{if $staruserlist}-->
			<ul class="ren-friend-re cl">
			<!--{loop $staruserlist $user}-->
				<li>
					<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="ren-list-usxx">
						<div class="ren-us-img z">
							<!--{echo avatar($user[uid], 'small')}-->
						</div>
						<div class="z ren-us-name">
							<div class="z ren-memb-name">$user[username]</div>
						</div>
						<div class="z ren-us-dateline">
							<span class="info_label">{$rtj1009_lang['group016']}<!--{echo date('Y-m-d', $user['joindateline'])}--></span>
						</div>
					</a>
				</li>
			<!--{/loop}-->
			</ul>
			<!--{/if}-->
			<!--{if $alluserlist}-->
			<ul class="ren-friend-re cl">
			<!--{loop $alluserlist $user}-->
				<li>
					<a href="home.php?mod=space&uid=$user[uid]&do=profile" class="ren-list-usxx">
						<div class="ren-us-img z">
							<!--{echo avatar($user[uid], 'small')}-->
						</div>
						<div class="z ren-us-name">
							<div class="z ren-memb-name">$user[username]</div>
						</div>
						<div class="z ren-us-dateline">
							<span class="info_label">{$rtj1009_lang['group016']}<!--{echo date('Y-m-d', $user['joindateline'])}--></span>
						</div>
					</a>
				</li>
			<!--{/loop}-->
			</ul>
			<!--{/if}-->
		</div>
	<!--{/if}-->
	<!--{if $multipage}--><div class="pgs cl">$multipage</div><!--{/if}-->
<!--{/if}-->
