<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_tie_list rtj1009_ss_main cl">
	<div class="ren_ss_tit"><!--{if $keyword && empty($searchstring[2])}-->{lang search_group_result_keyword}  <!--{if empty($viewgroup) && !empty($grouplist)}--><!--{/if}--><!--{elseif $viewgroup}-->{lang search_group_result}<!--{else}-->{lang search_result}<!--{/if}--></div>
<!--{if $viewgroup}-->
	<!--{if empty($grouplist)}-->
		<p class="emp xs2 xg2">{lang search_nomatch}</p>
	<!--{else}-->
		<div class="ren-group-sslist cl">
			<ul class="ren-group-re cl">
			<!--{loop $grouplist $group}-->
				<li class="cl">
					<a href="forum.php?mod=group&fid=$group[fid]" class="ren-list-usxx">
						<div class="ren-us-img z">
							<img src="$group[icon]">
						</div>
						<div class="z ren-us-name">
							<span class="z">$group[name]</span>
						</div>
						<div class="z ren-us-dateline">
							<span class="info_label">{lang member}</span>
							<span class="info_value">$group[membernum]</span>
							<span class="info_label">{lang threads}</span>
							<span class="info_value">$group[threads]</span>
							<span class="info_label">{lang credits}</span>
							<span class="info_value">$group[commoncredits]</span>
						</div>
						<div class="y ren-group-in"></div>
					</a>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
		<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
	<!--{/if}-->
<!--{else}-->
	<!--{if !empty($grouplist) && $page < 2}-->
		<div class="ren-group-sslist cl">
			<ul class="ren-group-re cl">
			<!--{loop $grouplist $group}-->
				<li class="cl">
					<a href="forum.php?mod=group&fid=$group[fid]" class="ren-list-usxx">
						<div class="ren-us-img z">
							<img src="$group[icon]">
						</div>
						<div class="z ren-us-name">
							<span class="z">$group[name]</span>
						</div>
						<div class="z ren-us-dateline">
							<span class="info_label">{lang member}</span>
							<span class="info_value">$group[membernum]</span>
							<span class="info_label">{lang threads}</span>
							<span class="info_value">$group[threads]</span>
							<span class="info_label">{lang credits}</span>
							<span class="info_value">$group[commoncredits]</span>
						</div>
						<div class="y ren-group-in"></div>
					</a>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
	<!--{/if}-->
	<!--{if !empty($threadlist)}-->
    <!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/rtj1009_list.php';}-->
		<ul class="z ren_list cl">
			<!--{subtemplate rtj1009_core/search_forum_list}-->
		</ul>
	<!--{/if}-->
	<!--{if !empty($multipage)}--><div class="pgs cl mbm">$multipage</div><!--{/if}-->
<!--{/if}-->
</div>
