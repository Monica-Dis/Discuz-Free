<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_tie_list rtj1009_ss_main cl">

	<!--{if empty($threadlist)}-->
		<li class="ren_ss_wu">
			<i class="icon ren-font">&#xe678;</i>
			<span>{lang search_nomatch}</span>
		</li>
	<!--{else}-->
    	<div class="ren_ss_tit"><!--{if $keyword}-->{lang search_result_keyword} <!--{else}-->{lang search_result}<!--{/if}--></div>
    <!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/rtj1009_list.php';}-->
		<ul class="z ren_list cl">
			<!--{subtemplate rtj1009_core/search_forum_list}-->
		</ul>
	<!--{/if}-->
	$multipage
</div>

