<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_tie_list rtj1009_ss_main cl">
	<!--{if empty($bloglist)}-->
		<li class="ren_ss_wu">
			<i class="icon ren-font">&#xe678;</i>
			<span>{lang search_nomatch}</span>
		</li>
	<!--{else}-->
    	<div class="ren_ss_tit"><!--{if $keyword}-->{lang search_result_keyword}<!--{else}-->{lang search_result}<!--{/if}--></div>
		<ul class="ren_yixz_xx cl">
			<!--{loop $bloglist $blog}-->
			<li class="ren_yixzxxk zbxxk1">
				<a href="home.php?mod=space&uid=$blog[uid]&do=blog&id=$blog[blogid]"{if $blog[magiccolor]}{/if} class="ren_tiexx cl">
					<div class="ren_twbt">
						<span>
							$blog[subject]
						</span>
					</div>
					<div class="ren_twxxx">
						<span class="z ren_tie_ztfl">$blog[dateline]</span>
					</div>
				</a>
			</li>
			<!--{/loop}-->
		</ul>
	<!--{/if}-->
	$multipage
</div>

