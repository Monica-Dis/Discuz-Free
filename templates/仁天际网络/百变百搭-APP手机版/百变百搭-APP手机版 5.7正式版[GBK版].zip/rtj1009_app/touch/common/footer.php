<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{hook/global_footer_mobile}-->
<!--{eval $useragent = strtolower($_SERVER['HTTP_USER_AGENT']);$clienturl = ''}-->
<!--{if strpos($useragent, 'iphone') !== false || strpos($useragent, 'ios') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=ios' : 'http://www.discuz.net/mobile.php?platform=ios';}-->
<!--{elseif strpos($useragent, 'android') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=android' : 'http://www.discuz.net/mobile.php?platform=android';}-->
<!--{elseif strpos($useragent, 'windows phone') !== false}-->
<!--{eval $clienturl = $_G['cache']['mobileoem_data']['iframeUrl'] ? $_G['cache']['mobileoem_data']['iframeUrl'].'&platform=windowsphone' : 'http://www.discuz.net/mobile.php?platform=windowsphone';}-->
<!--{/if}-->

{$ren_m_html}
<!--{template common/footer_bar}-->
<div class="ren_scrolltop scrhide">
    <!--{if $rtj1009_mobilecp['ren_m_scrolltop_bar'] == 1}-->
    <a href="javascript:;" class="ren_scrolltop_bar open-panel">
        <span class="icon ren-font">&#xea4d;</span>
    </a>
    <!--{/if}-->
    <!--{if $rtj1009_mobilecp['ren_m_scrolltop_fb'] == 1}-->
    <a href="{if $_GET['mod'] == 'forumdisplay' || $_GET['mod'] == 'viewthread'}forum.php?mod=post&action=newthread&fid=$_G[fid]<!--{else}-->forum.php?mod=misc&action=nav{/if}" class="ren_scrolltop_fb<!--{if !$_G[uid]}--> ren-confirm<!--{/if}-->">
        <span class="icon ren-font">&#xe619;</span>
    </a>
    <!--{/if}-->
    <!--{if $rtj1009_mobilecp['ren_m_scrolltop_sx'] == 1}-->
    <a href="javascript:;" onclick="location.reload();" class="ren_scrolltop_sx">
        <span class="icon ren-font">&#xe604;</span>
    </a>
    <!--{/if}-->
</div>

<script>
    $(function(){
        var page_heig = $(document).scrollTop();
        var ren_scrolltop = $('.ren_scrolltop').outerHeight();

        $(window).scroll(function() {
            var real_heig = $(document).scrollTop();

            if (real_heig > ren_scrolltop) {
                $('.ren_scrolltop').removeClass('scrhide');
            } else {
                $('.ren_scrolltop').addClass('scrhide');
            }
            if (real_heig < page_heig) {
                $('.ren_scrolltop').addClass('scrhide');
            } else {
                $('.ren_scrolltop').removeClass('scrhide');
            }
            page_heig = $(document).scrollTop();
        });
    });

</script>



</div>
<div id="mask" style="display:none;"></div>
<div class="popup-mantle"></div>
<div class="popup-mantles"></div>
<div id="popup-mantless"></div>
<div class="nav-menu-panel <!--{if $rtj1009_mobilecp['ren_m_sidebarfx'] == 2}-->panel-right<!--{else}-->panel-left<!--{/if}-->">
    <div class="menu-panel">
        <!--{template common/sidebar}-->
    </div>
</div>

<script>
    $(document).ready(function() {
        $("#ren-scrol-tie").Scroll({line:1,speed:600,timer:3000,up:"but_up",down:"but_down"});
        $(document).find(".open-calendar").each(function() {
            var val = $(this).data('toggle');
            var calendarid = "#"+val;
            var val = new datePicker();
            val.init({
                'trigger': calendarid,
                'type': 'date',
                'minDate':'1970-1-1',
                'maxDate':'2030-12-31',
                'onSubmit':function(){
                    var theSelectData = val.value;
                },
                'onClose':function() {
                }
            });
        });

        $(".open-popup").on("click", function ren_open() {
            var val = $(this).data('popup');
            $(val).addClass("modal-in");
            $(".popup-mantle").addClass("open-popup-overlay");
            $(".close-popup").on("click", function ren_close() {
                $(val).removeClass("modal-in");
                $(".popup-mantle").removeClass("open-popup-overlay");
            });
            $(".popup-mantle").on("click", function ren_overlay() {
                $(val).removeClass("modal-in");
                $(".popup-mantle").removeClass("open-popup-overlay");
            });
        });
        $(".open-popover").on("click", function ren_open() {
            $(".popover").addClass("modal-in");
            $(".popover").css("display","block");
            $(".popup-mantles").addClass("open-popup-overlay");
            $(".close-popover").on("click", function ren_close() {
                $(".popover").removeClass("modal-in");
                $(".popover").css("display","none");
                $(".popup-mantles").removeClass("open-popup-overlay");
            });
            $(".popup-mantles").on("click", function ren_overlay() {
                $(".popover").removeClass("modal-in");
                $(".popover").css("display","none");
                $(".popup-mantles").removeClass("open-popup-overlay");
            });
        });
        $(".open-panel").on("click", function ren_open() {
            $(".nav-menu-panel").addClass("nav-open");
            $(".popup-mantles").addClass("open-popup-overlay");
            $(".nav-menu-panel").on("click", function ren_close() {
                $(".nav-menu-panel").removeClass("nav-open");
                $(".popup-mantles").removeClass("open-popup-overlay");
            });
            $(".popup-mantles").on("click", function ren_overlay() {
                $(".nav-menu-panel").removeClass("nav-open");
                $(".popup-mantles").removeClass("open-popup-overlay");
            });
        });

        $(".bds_copy").on("click", function ren_open() {
            var url = window.location.href;
            var successful;
            if (navigator.userAgent.match(/(iPhone|iPod|iPad|iOS)/i)) {
                var copyDOM = document.createElement('div');
                copyDOM.innerHTML = url;
                document.body.appendChild(copyDOM);
                var range = document.createRange();
                range.selectNode(copyDOM);
                window.getSelection().addRange(range);
                successful = document.execCommand('copy');
                window.getSelection().removeAllRanges();
                $(copyDOM).hide()
            } else {
                var oInput = document.createElement('input');
                oInput.value = url;
                document.body.appendChild(oInput);
                oInput.select();
                successful = document.execCommand('copy');
            }
            if(successful){
                popup.open("{$rtj1009_lang[ren209]}", "alert");
                $('.popup-share').removeClass("modal-in");
            }else{
                popup.open("{$rtj1009_lang[ren210]}", "alert");
                $('.popup-share').removeClass("modal-in");
            }
        });
        $(".bds_weixin").on("click", function ren_open() {
            popup.open("{$rtj1009_lang[ren211]}", "alert");
            $('.popup-share').removeClass("modal-in");
        });
    });
</script>


<!--{if ($_G['basescript']=='portal' && CURMODULE=='view') || ($_G['basescript']=='forum' && CURMODULE=='viewthread') || ($_G['basescript']=='group' && CURMODULE=='viewthread')}-->
<script type="text/javascript">
    function renBack() {
        <!--{if $_G['basescript']=='portal' && CURMODULE=='view'}-->
        var listurl = '{echo getportalcategoryurl($cat[catid])}';
        <!--{elseif ($_G['basescript']=='forum' && CURMODULE=='viewthread') || ($_G['basescript']=='group' && CURMODULE=='viewthread')}-->
        var listurl = 'forum.php?mod=forumdisplay&fid={$forum[fid]}';
        <!--{/if}-->
        if ((navigator.userAgent.indexOf('MSIE') >= 0) && (navigator.userAgent.indexOf('Opera') < 0)) {
            if (history.length > 0) {
                window.history.back();
            } else {
                <!--{if $ren_back == 1}-->
                window.location.href = "portal.php?mod=index";
                <!--{elseif $ren_back == 2}-->
                window.location.href = "forum.php?forumlist=1";
                <!--{elseif ($ren_back == 3 && $_G['basescript']=='portal' && CURMODULE=='view') || ($ren_back == 3 && $_G['basescript']=='forum' && CURMODULE=='viewthread')}-->
                window.location.href = listurl;
                <!--{else}-->
                window.location.href = "portal.php?mod=index";
                <!--{/if}-->
            }
        } else {
            if (navigator.userAgent.indexOf('Firefox') >= 0 ||
                navigator.userAgent.indexOf('Opera') >= 0 ||
                navigator.userAgent.indexOf('Safari') >= 0 ||
                navigator.userAgent.indexOf('Chrome') >= 0 ||
                navigator.userAgent.indexOf('WebKit') >= 0) {
                if (window.history.length > 1) {
                    window.history.back();
                } else {
                    <!--{if $ren_back == 1}-->
                    window.location.href = "portal.php?mod=index";
                    <!--{elseif $ren_back == 2}-->
                    window.location.href = "forum.php?forumlist=1";
                    <!--{elseif ($ren_back == 3 && $_G['basescript']=='portal' && CURMODULE=='view') || ($ren_back == 3 && $_G['basescript']=='forum' && CURMODULE=='viewthread')}-->
                    window.location.href = listurl;
                    <!--{else}-->
                    window.location.href = "portal.php?mod=index";
                    <!--{/if}-->
                }
            } else {
                window.history.back();
            }
        }
    }
</script>
<!--{/if}-->

<script type="text/javascript">
	$('.ren-confirm').on('click', function() {
		popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
		return false;
	});
</script>


<!--{if $rtj1009_mobilecp['wx_radio'] || $rtj1009_mobilecp['wx_uploadimg']}-->
<script type="text/javascript">
    wx.config({
        debug: false,
        appId: '$rtj1009_m_config["signPackage"]["appId"]',
        timestamp: '$rtj1009_m_config["signPackage"]["timestamp"]',
        nonceStr: '$rtj1009_m_config["signPackage"]["nonceStr"]',
        signature: '$rtj1009_m_config["signPackage"]["signature"]',
        jsApiList: ['onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo', 'onMenuShareQZone', 'chooseImage', 'uploadImage', 'downloadImage', 'previewImage']
    });
    <!--{if $rtj1009_mobilecp['wx_radio']}-->
    wx.ready(function () {
        var ren_wx_share_data = {
            <!--{if $ren_wxfx_title}-->title: '$ren_wxfx_title',<!--{else}-->title: document.title,<!--{/if}-->
            <!--{if $ren_wxfx_desc}-->desc: '$ren_wxfx_desc',<!--{else}-->desc: document.getElementsByName('description')[0].content,<!--{/if}-->
            imgUrl: '$ren_wx_imgUrl',
            link: '$rtj1009_m_config["signPackage"]["url"]'
        }
        wx.onMenuShareTimeline(ren_wx_share_data);
        wx.onMenuShareAppMessage(ren_wx_share_data);
        wx.onMenuShareQQ(ren_wx_share_data);
        wx.onMenuShareWeibo(ren_wx_share_data);
        wx.onMenuShareQZone(ren_wx_share_data);
    });
    <!--{/if}-->
</script>
<!--{/if}-->

<script>
	var swiper = new Swiper('.swiper-container', {
		autoHeight: true,
		centeredSlides: true,
		loop : true,
		autoplay: {
            delay: 3000,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
	});
	var swiper2 = new Swiper('.swiper-container2', {
		freeMode: true,
		slidesPerView: 'auto'
	});
    var swiper3 = new Swiper('.swiper-container3', {
        slidesPerView: 'auto',
        paginationClickable: true,
        spaceBetween: 10
    });
    var swiper7 = new Swiper('.swiper-container7', {
        pagination: {
            el: '.swiper-pagination',
            clickable: true,
        },
    });
    <!--{if $_GET['from'] == 'album'}-->
    var i = $("ul.swiper-wrapper>li.img_index").index();
    <!--{if $curaidkey == 0}-->
    var curkey = $curaidkey;
    <!--{else}-->
    var curkey = $curaidkey - 1;
    <!--{/if}-->
    var swiper5 = new Swiper('.swiper-container4', {
        zoom: true,
        pagination : '.swiper-pagination',
        paginationType : 'custom',
        initialSlide: i,
        on:{
            slidePrevTransitionEnd:function(){
                curkey--;
                $('#curpic').text(curkey + 1);
            },
            slideNextTransitionEnd:function(){
                curkey++;
                $('#curpic').text(curkey + 1);
            },
        }
    });
    <!--{/if}-->

</script>
</body>
</html>
<!--{eval updatesession();}-->
<!--{if $rtj1009_mobilecp['ren_m_ewrite']}-->
<!--{eval rtj1009_output();}-->
<!--{/if}-->
<!--{eval output();}-->

