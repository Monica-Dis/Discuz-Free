<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>

<div class="ren_sidebar <!--{if $ren_m_sidebar == 1}-->ren_sidenav<!--{elseif $ren_m_sidebar == 2}-->ren_sidenav_line<!--{/if}-->">
    <div class="ren_nav_user close-panel cl">
        <!--{if !$_G[uid] && !$_G['connectguest']}-->
		<a class="ren_userinfo cl" href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->">
            <div class="ren_us_avatar_m" ><img src="<!--{avatar($_G[uid], middle, true)}-->" /></div>
            <h3 class="ren_us_name">{$rtj1009_lang['ren006']}</h3>
        </a>
		<div class="ren_us_xy">
            <a class="ren_us_zc" href="member.php?mod={$_G[setting][regname]}" title="{$_G['setting']['reglinkname']}"><span class="icon ren-font">&#xe676;</span>{lang register}</a>
            <a class="ren_us_dl" href="member.php?mod=logging&action=login" title="{lang login}"><span class="icon ren-font">&#xe67e;</span>{lang login}</a>
		</div>
        <!--{else}-->
        <a class="ren_userinfo cl" href="<!--{if $_G[uid]}-->home.php?mod=space&uid=$_G[uid]&do=profile&mycenter=1<!--{else}-->member.php?mod=logging&action=login<!--{/if}-->">
            <div class="ren_us_avatar_m" >
			<!--{if $_G[member][newpm] || $_G[member][newprompt]}--><span class="dian"></span><!--{/if}--><img src="<!--{avatar($_G[uid], middle, true)}-->" /></div>
            <h3 class="ren_us_name">$_G[username]</h3>
			<span class="ren_us_xing">Lv.$_G[group][stars]</span>
        </a>
		<div class="ren_us_xy">
            <a class="ren_us_tc dialog" href="member.php?mod=logging&action=logout&formhash={FORMHASH}" title="{lang logout}" class="dialog"><span class="icon ren-font">&#xe617;</span>{lang logout}</a>
		</div>
        <!--{/if}-->
        <div class="ren-swiper-svg">
            <div class="ren-swiper-svg1"></div>
            <div class="ren-swiper-svg2"></div>
        </div>
    </div>
    
    <div class="ren_nav_list close-panel cl">
        <!--{hook/global_misign_mobile}-->
        <div class="ren_nav_fx cl">{$rtj1009_lang['ren007']}</div>
        <ul class="cl">
            <!--{loop $sidelistyi $key $values}-->
            <li><a href="{$values['url']}" class="icon_fx"><span class="icon ren-font" style="color: {$values['color']}">{$values['icon']}</span>{$values['title']}</a></li>
            <!--{/loop}-->
        </ul>
    </div>
    
    <div class="ren_nav_list close-panel cl">
        <div class="ren_nav_wd cl">{$rtj1009_lang['ren005']}</div>
        <ul class="cl">
            <!--{loop $sideliste $key $values}-->
            <li><a href="{$values['url']}" class="icon_fx"><span class="icon ren-font" style="color: {$values['color']}">{$values['icon']}</span>{$values['title']}</a></li>
            <!--{/loop}-->
        </ul>
    </div>
    <p class="ren-dz-banquan">&copy; Comsenz Inc.</p>
</div>
