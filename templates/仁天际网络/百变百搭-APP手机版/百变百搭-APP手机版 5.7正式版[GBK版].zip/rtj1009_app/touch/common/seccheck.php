<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
{eval
	$sechash = 'S'.random(4);
	$sectpl = !empty($sectpl) ? explode("<sec>", $sectpl) : array('<br />',': ','<br />','');
	$ran = random(5, 1);
}
<!--{if $secqaacheck}-->
<!--{eval
	$message = '';
	$question = make_secqaa();
	$secqaa = $question;
}-->
<!--{/if}-->
<!--{if $sectpl}-->
	<!--{if $secqaacheck}-->

    <div class="ren-secqaacheck">{$rtj1009_lang[ren216]}<span>$secqaa</span></div>
	<li>
		<div class="item-content">
		  <div class="item-media"><i class="icon ren-font icon-form-gender">&#xe609;</i></div>
			<div class="item-inner">
				<div class="sec_code item-input vm">
				<input name="secqaahash" type="hidden" value="$sechash" />
				<input name="secanswer" id="secqaaverify_$sechash" type="text" class="txt" placeholder="{lang secqaa}" />
				</div>
			</div>
		</div>
	</li>
	<!--{/if}-->
	<!--{if $seccodecheck}-->
	<!--{if $secqaacheck}-->
	<li>
		<div class="item-content">
		    <div class="item-media"><i class="icon ren-font icon-form-gender">&#xe609;</i></div>
			<div class="item-inner">
	<!--{/if}-->
                <div class="sec_code item-input vm">
                    <input name="seccodehash" type="hidden" value="$sechash" />
                    <input type="text" class="txt ren_yzm_px vm" style="ime-mode:disabled;width:115px;background:white;" autocomplete="off" value="" id="seccodeverify_$sechash" name="seccodeverify" placeholder="{lang seccode}" fwin="seccode">
                    <img src="misc.php?mod=seccode&update={$ran}&idhash={$sechash}&mobile=2" class="seccodeimg vm"/>
                </div>
	<!--{if $secqaacheck}-->
			</div>
		</div>
	</li>
	<!--{/if}-->
	<!--{/if}-->
<!--{/if}-->
<script type="text/javascript">
	(function() {
		$('.seccodeimg').on('click', function() {
			$('#seccodeverify_$sechash').attr('value', '');
			var tmprandom = 'S' + Math.floor(Math.random() * 1000);
			$('.sechash').attr('value', tmprandom);
			$(this).attr('src', 'misc.php?mod=seccode&update={$ran}&idhash='+ tmprandom +'&mobile=2');
		});
	})();
</script>

