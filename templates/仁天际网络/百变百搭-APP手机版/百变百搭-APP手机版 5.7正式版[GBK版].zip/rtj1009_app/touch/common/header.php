<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/ren_lang.'.currentlang().'.php';}-->
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=gbk">
<meta http-equiv="Cache-control" content="{if $_G['setting']['mobile'][mobilecachetime] > 0}{$_G['setting']['mobile'][mobilecachetime]}{else}no-cache{/if}" />
<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no, minimum-scale=1.0, maximum-scale=1.0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-touch-fullscreen" content="yes">
<meta name="apple-mobile-web-app-title" content="IM 1009">
<meta name="apple-mobile-web-app-status-bar-style" content="black">
<meta name="format-detection" content="telephone=no" />
<meta name="format-detection" content="email=no" />
<meta name="full-screen" content="yes">
<meta name="browsermode" content="application">
<meta name="x5-fullscreen" content="true">
<meta name="x5-page-mode" content="app">
<meta name="keywords" content="{if !empty($metakeywords)}{echo dhtmlspecialchars($metakeywords)}{/if}" />
<meta name="description" content="{if !empty($metadescription)}{echo dhtmlspecialchars($metadescription)} {/if},$_G['setting']['bbname']" />
<base href="{$_G['siteurl']}" />
<!--{template common/header_title}-->
<title><!--{if !empty($navtitle)}-->$navtitle<!--{/if}--><!--{if empty($nobbname)}--> - $_G['setting']['bbname']<!--{/if}--><!--{if $ren_title_sjb}--> - {lang waptitle}<!--{/if}--></title>
<script src="template/rtj1009_app/js/jquery.min.js?{VERHASH}"></script>

<script type="text/javascript">var STYLEID = '{STYLEID}', STATICURL = '{STATICURL}', IMGDIR = '{IMGDIR}', VERHASH = '{VERHASH}', charset = '{CHARSET}', discuz_uid = '$_G[uid]', cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', showusercard = '{$_G[setting][showusercard]}', attackevasive = '{$_G[config][security][attackevasive]}', disallowfloat = '{$_G[setting][disallowfloat]}', creditnotice = '<!--{if $_G['setting']['creditnotice']}-->$_G['setting']['creditnames']<!--{/if}-->', defaultstyle = '$_G[style][defaultextstyle]', REPORTURL = '$_G[currenturl_encode]', SITEURL = '$_G[siteurl]', JSPATH = '$_G[setting][jspath]';</script>

<script src="template/rtj1009_app/js/common.js?{VERHASH}" charset="{CHARSET}"></script>
<script type="text/javascript" src='template/rtj1009_app/js/swiper.min.js'></script>
<script type="text/javascript" src='template/rtj1009_app/js/datePicker.js'></script>
<script type="text/javascript" src='template/rtj1009_app/js/jq_scroll.js'></script>
<link href="template/rtj1009_app/css/extend_common.css" rel="stylesheet" type="text/css" />
<link href="template/rtj1009_app/css/extend_module.css" rel="stylesheet" type="text/css" />
<link href="template/rtj1009_app/css/ren_swiper.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src='https://res.wx.qq.com/open/js/jweixin-1.6.0.js'></script>
<!--{csstemplate}-->
</head>

<body class="bg">
	<div class="mpadi" id="ren-post">
        <!--{if $ren_smd_open && !$_COOKIE['timename'] && ($_G['basescript'] == 'portal' || ($_G['basescript']=='forum' && CURMODULE=='index') || ($_G['basescript']=='forum' && CURMODULE=='forumdisplay') || ($rtj1009_mobilecp['ren_smd_view'] && $_G['basescript']=='forum' && CURMODULE=='viewthread') || $_G['basescript']=='group' || $_G['basescript']=='group')}-->
        <div class="ren-smd">
            <a href="{$ren_smd_url}" class="ren-smd-a"><img src="{$ren_smd_img}"></a>
            <div class="ren-smd-gtime"><span>{$ren_smd_gtime}</span> {$ren_smd_ts}</div>
        </div>
        <script type="text/javascript">
            function setCookie(name,value,time) {
                var msec = getMsec(time);
                var exp = new Date();
                exp.setTime(exp.getTime() + msec*1);
                document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
            }
            function getMsec(str) {
                var timeNum = str.substring(1, str.length) * 1;
                var timeStr = str.substring(0, 1);
                if (timeStr == "s") {
                    return timeNum * 1000;
                } else if (timeStr == "h") {
                    return timeNum * 60 * 60 * 1000;
                } else if (timeStr == "d") {
                    return timeNum * 24 * 60 * 60 * 1000;
                }
            }
            function getCookie(name) {
                var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
                if (arr=document.cookie.match(reg)) {
                    return unescape(arr[2]);
                } else {
                    return null;
                }
            }

            if (!getCookie('timename')) {
                var time = {$ren_smd_gtime};
                var b = setInterval(function () {
                    time--;
                    if (time == -1) {
                        $('.ren-smd').css('display', 'none');
                    } else if (time >= 0){
                        $('.ren-smd-gtime span').html(time);
                    } else {
                        clearInterval(b);
                        setCookie('timename', '1', '{$ren_smd_jtime}');
                    }
                }, 1000);
            } else {
                $('.ren-smd').css('display', 'none');
            }

            $('.ren-smd-gtime').click(function() {
                $('.ren-smd').css('display', 'none');
                setCookie('timename', '1', '{$ren_smd_jtime}');
            });

            $('.ren-smd').click(function() {
                $('.ren-smd').css('display', 'none');
                setCookie('timename', '1', '{$ren_smd_jtime}');
            });
        </script>
        <!--{/if}-->

<!--{hook/global_header_mobile}-->
