<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/ren_lang.'.currentlang().'.php';}-->
<div class="tip ren-rate-tip ren-gmgroup-tip">
    <form method="post" autocomplete="off" id="form_$_GET[handlekey]" name="form_$_GET[handlekey]" action="misc.php?mod=report" {if $_G[inajax]}onsubmit="if(!$('report_message').value) return false;ajaxpost(this.id, 'form_$_GET[handlekey]');"{/if}>
    <div class="ren-rate-nav cl">
        <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
        <div class="ren-post-nav cl">
            <div class="ren-post-wall">
                <span>{lang report}</span>
            </div>
        </div>
    </div>

    <div class="reason_slct c" id="return_$_GET[handlekey]">
        <p class="ren_lc_jbxx ren-report" id="report_reasons">
            <label><input type="radio" name="report_select" onclick="$('#report_message').html(this.value);$('#report_other').css('display', 'none');" value="{$rtj1009_lang['ren013']}" /> {$rtj1009_lang['ren013']}</label>
            <label><input type="radio" name="report_select" onclick="$('#report_message').html(this.value);$('#report_other').css('display', 'none');" value="{$rtj1009_lang['ren014']}" /> {$rtj1009_lang['ren014']}</label>
            <label><input type="radio" name="report_select" onclick="$('#report_message').html(this.value);$('#report_other').css('display', 'none');" value="{$rtj1009_lang['ren015']}" /> {$rtj1009_lang['ren015']}</label>
            <label><input type="radio" name="report_select" onclick="$('#report_message').html(this.value);$('#report_other').css('display', 'none');" value="{$rtj1009_lang['ren016']}" /> {$rtj1009_lang['ren016']}</label>
            <label><input type="radio" name="report_select" onclick="$('#report_message').html('');$('#report_other').css('display', '');" /> {$rtj1009_lang['ren217']}</label>
        </p>
        <div id="report_other" class="ren-report-text" style="display:none">
            <textarea id="report_message" name="message" class="reasonarea pt mtn xg1" rows="1" placeholder="{lang report_reason_other}"></textarea>
        </div>
    </div>
    <p class="ren_login btn_login">
        <button type="submit" id="report_submit" name="report_submit" value="true" class="formdialog pn button ren_btn">{lang confirms}</button>
    </p>
    <input type="hidden" name="referer" value="{echo dreferer()}" />
    <input type="hidden" name="reportsubmit" value="true" />
    <input type="hidden" name="rtype" value="$_GET[rtype]" />
    <input type="hidden" name="rid" value="$_GET[rid]" />
    <!--{if $_GET['fid']}-->
    <input type="hidden" name="fid" value="$_GET[fid]" />
    <!--{/if}-->
    <!--{if $_GET['uid']}-->
    <input type="hidden" name="uid" value="$_GET[uid]" />
    <!--{/if}-->
    <input type="hidden" name="url" value="$_GET[url]" />
    <input type="hidden" name="inajax" value="$_G[inajax]" />
    <!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    </form>
</div>
<!--{template common/footer}-->
