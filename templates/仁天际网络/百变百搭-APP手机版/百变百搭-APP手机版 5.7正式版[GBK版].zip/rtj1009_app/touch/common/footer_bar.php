<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G['basescript'] == 'portal' && CURMODULE == 'index' || $_G['basescript']=='portal' && CURMODULE=='list' || $_G['basescript'] == 'forum' && CURMODULE== 'index' ||  $_G['basescript'] == 'forum' && CURMODULE == 'guide' || ($ren_m_forum_bar == 1 && $_G['basescript']=='forum' && CURMODULE=='forumdisplay') || $_G['basescript']=='forum' && CURMODULE=='misc' || $_G['basescript']=='group' && CURMODULE=='index' || $_G['basescript']=='home' && $_GET['mycenter'] || $_G['basescript']=='group' && CURMODULE=='forumdisplay' || $_G['basescript']=='home' && (CURMODULE=='space' && $_GET['do'] == 'notice' && !$_GET['view']) || $_G['basescript']=='plugin' && CURMODULE == 'k_misign'}-->

<nav class="bar bar-tab">
	<div class="ren_footer">
        <!--{if $menulist['0']['status'] == 1}-->
            <!--{if $_G['setting']['mobile']['mobilehotthread']}-->
            <a href="{$menulist['0']['url']}" class="tab-item{if rtj1009_isaurl($menulist['0']['url'])} a{/if}">
              <span class="icon ren-font">{if rtj1009_isaurl($menulist['0']['url'])}{$menulist['0']['icon']}<!--{else}-->{$menulist['0']['icons']}{/if}</span>
              <span class="tab-label">{$menulist['0']['title']}</span>
            </a>
            <!--{else}-->
            <a href="{$menulist['0']['url']}" class="tab-item{if rtj1009_isaurl($menulist['0']['url'])} a{/if}">
              <span class="icon ren-font">{if rtj1009_isaurl($menulist['0']['url'])}{$menulist['0']['icon']}<!--{else}-->{$menulist['0']['icons']}{/if}</span>
              <span class="tab-label">{$menulist['0']['title']}</span>
            </a>
            <!--{/if}-->
        <!--{/if}-->

        <!--{if $menulist['1']['status'] == 1}-->
            <!--{if $_G['setting']['mobile']['mobilehotthread']}-->
            <a href="{$menulist['1']['url']}" class="tab-item{if rtj1009_isaurl($menulist['1']['url'])} a{/if}">
              <span class="icon ren-font">{if rtj1009_isaurl($menulist['1']['url'])}{$menulist['1']['icon']}<!--{else}-->{$menulist['1']['icons']}{/if}</span>
              <span class="tab-label">{$menulist['1']['title']}</span>
            </a>
            <!--{else}-->
            <a href="{$menulist['1']['url']}" class="tab-item{if rtj1009_isaurl($menulist['1']['url'])} a{/if}">
              <span class="icon ren-font">{if rtj1009_isaurl($menulist['1']['url'])}{$menulist['1']['icon']}<!--{else}-->{$menulist['1']['icons']}{/if}</span>
              <span class="tab-label">{$menulist['1']['title']}</span>
            </a>
            <!--{/if}-->
        <!--{/if}-->

        <!--{if $menulist['2']['status'] == 1}-->
            <!--{if $ren_footer_barfb ==1}-->
                <!--{if $ren_footer_styles ==1}-->
                <a href="{if $menulist['2']['type'] == 2}{$menulist['2']['url']}<!--{else}-->{if $_GET['mod'] == 'forumdisplay'}forum.php?mod=post&action=newthread&fid=$_G[fid]<!--{else}-->forum.php?mod=misc&action=nav{/if}{/if}" class="tab-item{if rtj1009_isaurl($menulist['2']['url'])} a{/if}">
                <!--{elseif $ren_footer_styles ==2}-->
                <a href="javascript:;" class="tab-item open-popup-styles" data-popup=".popup-styles">
                <!--{/if}-->
                  <span class="icon ren-font">{$menulist['2']['icon']}</span>
                  <span class="tab-label">{$menulist['2']['title']}</span>
                </a>
            <!--{elseif $ren_footer_barfb ==2}-->
                <!--{if $ren_footer_styles ==1}-->
                <a href="{if $menulist['2']['type'] == 2}{$menulist['2']['url']}<!--{else}-->{if $_GET['mod'] == 'forumdisplay'}forum.php?mod=post&action=newthread&fid=$_G[fid]<!--{else}-->forum.php?mod=misc&action=nav{/if}{/if}" class="tab-item{if rtj1009_isaurl($menulist['2']['url'])} a{/if} ren-bar-tu">
                <!--{elseif $ren_footer_styles ==2}-->
                <a href="javascript:;" class="tab-item ren-bar-tu open-popup-styles" data-popup=".popup-styles">
                <!--{/if}-->
                  <div class="ren-bar-tuxx"><span class="icon ren-font">{$menulist['2']['icon']}</span><span class="ren-bar-tubj"></span></div>
                </a>
            <!--{/if}-->
        <!--{/if}-->

        <!--{if $menulist['3']['status'] == 1}-->
            <a href="{$menulist['3']['url']}" class="tab-item{if rtj1009_isaurl($menulist['3']['url'])} a{/if}">
              <span class="icon ren-font">{if rtj1009_isaurl($menulist['3']['url'])}{$menulist['3']['icon']}<!--{else}-->{$menulist['3']['icons']}{/if}</span>
              <span class="tab-label">{$menulist['3']['title']}</span>
            </a>
		<!--{/if}-->
        <!--{if $menulist['4']['status'] == 1}-->
            <a href="{$menulist['4']['url']}" class="tab-item{if rtj1009_isaurl($menulist['4']['url'])} a{/if}">
              <span class="icon ren-font">{if rtj1009_isaurl($menulist['4']['url'])}{$menulist['4']['icon']}<!--{else}-->{$menulist['4']['icons']}{/if}</span>
              <span class="tab-label">{$menulist['4']['title']}</span>
            </a>
        <!--{/if}-->
	</div>
</nav>
<div class="popup popup-styles">
    <div class="content-block">
        <div class="ren-post-styles">
            {$block_post_juhe}
            <div class="ren-post-stys">
                {$block_post_juhebage}
                <a href="javascript:;" class="ren-styles-ico close-popup-styles"><i class="icon ren-font">&#xe64d;</i></a>
            </div>
        </div>
    </div>
</div>

<div class="popup-mantle"></div>

<!--{if $ren_footer_styles ==2}-->
<script>
    var styles_popupbtn = document.querySelector('.open-popup-styles');
    var styles_popupbox = document.querySelector('.popup-styles');
    var styles_closepopup = document.querySelectorAll('.close-popup-styles');
    var styles_overlay = document.querySelector('.popup-mantle');
    styles_popupbtn.addEventListener("click", function() {
        styles_popupbox.classList.toggle("modal-in");
        styles_overlay.classList.toggle("open-popup-overlay");
    })
    for (let i = 0; i < styles_closepopup.length; i++) {
        styles_closepopup[i].addEventListener("click", function() {
            styles_popupbox.classList.toggle("modal-in");
            styles_overlay.classList.toggle("open-popup-overlay");
        });
    }
    styles_overlay.addEventListener("click", function() {
        styles_popupbox.classList.toggle("modal-in");
        styles_overlay.classList.toggle("open-popup-overlay");
    })
</script>
<!--{/if}-->
<!--{/if}-->




