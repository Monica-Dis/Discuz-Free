<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $param['login']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if $_G['inajax']}-->
<div class="tip">
	<dt id="messagetext">
		<p>$show_message</p>
        <!--{if $_G['forcemobilemessage']}-->
        	<p >
            	<a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
                <a href="javascript:history.back();">{lang goback}</a>
            </p>
        <!--{/if}-->
		<!--{if $url_forward && !$_GET['loc']}-->
			<!--<p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>-->
			<script type="text/javascript">
				setTimeout(function() {
					window.location.href = '$url_forward';
				}, '3000');
			</script>
		<!--{elseif $allowreturn}-->
			<dd><input type="button" class="button" onclick="popup.close();" value="{lang close}"></dd>
		<!--{/if}-->
	</dt>
</div>
<!--{else}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->

<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<a class="ren_logo" title="$_G[setting][bbname]" href="$nav"><img src="template/rtj1009_app/image/logo.png" /></a>
		<div class="ren_nav_right">
            <div class="ren_view_navgd open-popover"><span class="icon ren-font">&#xe677;</span></div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<!-- main jump start -->
<div class="content">
	<div class="ren_jump">
		<div class="jump_c">
			<p>$show_message</p>
			<!--{if $_G['forcemobilemessage']}-->
				<p>
					<a href="{$_G['setting']['mobile']['pageurl']}" class="mtn">{lang continue}</a><br />
					<a href="javascript:history.back();">{lang goback}</a>
				</p>
			<!--{/if}-->
			<!--{if $url_forward}-->
				<p><a class="grey" href="$url_forward">{lang message_forward_mobile}</a></p>
			<!--{elseif $allowreturn}-->
				<p><a class="grey" href="javascript:history.back();">{lang message_go_back}</a></p>
			<!--{/if}-->
		</div>
	</div>
</div>
<!-- main jump end -->


<!--{/if}-->
<!--{template common/footer}-->

