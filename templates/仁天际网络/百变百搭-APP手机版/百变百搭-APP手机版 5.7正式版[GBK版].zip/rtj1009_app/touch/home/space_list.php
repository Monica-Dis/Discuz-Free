<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $list}-->
<div class="ren-friend-list cl">
    <ul class="ren-friend-re cl">
		<!--{loop $list $key $value}-->
        <li>
            <div class="ren-list-usxx">
                <a href="home.php?mod=space&uid=$value[uid]&do=profile" class="ren-us-img z">
                    <!--{avatar($value[uid],small)}-->
                </a>

                <div class="z ren-us-name">
                    <a href="home.php?mod=space&uid=$value[uid]&do=profile" class="z" {eval g_color($value[groupid]);}>$value['username']</a>
                </div>

                <div class="z ren-us-dateline">
                    <span class="info_label">{$_G['cache']['usergroups'][$value['groupid']]['grouptitle']}</span>
                </div>

                <div class="y ren-friend-in tu">
                    <!--{if isset($value['isfriend']) && !$value['isfriend']}-->
                    <a href="home.php?mod=spacecp&ac=friend&op=add&uid=$value[uid]" class="z dialog">{lang add_friend}</a>
                    <!--{/if}-->
                    <!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != ''}-->
                    <a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&fuid=$value[uid]&hash={FORMHASH}&from=a_followmod_" id="a_followmod_$key" class="dialog tu z"><!--{if $value['follow']}-->{$rtj1009_lang['home011']}<!--{else}-->{$rtj1009_lang['home012']}<!--{/if}--></a>
                    <!--{/if}-->
                    <a href="home.php?mod=space&do=pm&subop=view&touid=$value[uid]" id="a_sendpm_$key" class="tu z">{lang send_pm}</a>
                </div>
            </div>
		</li>
		<!--{/loop}-->
	</ul>
</div>
	<!--{if $multi}--><div class="mtm pgs cl">$multi</div><!--{/if}-->
<script type="text/javascript">
function succeedhandle_followmod(url, msg, values) {
	var fObj = $('a_followmod_'+values['fuid']);
	if(values['type'] == 'add') {
		fObj.innerHTML = '{lang follow_del}';
		fObj.className = 'flw_btn_unfo';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=del&fuid='+values['fuid'];
	} else if(values['type'] == 'del') {
		fObj.innerHTML = '{lang follow_add}TA';
		fObj.className = 'flw_btn_fo';
		fObj.href = 'home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid='+values['fuid'];
	}
}
</script>
<!--{else}-->
<div class="ren_ss_wu">
    <i class="icon ren-font">&#xe608;</i>
    <span>{lang no_members_of}</span>
</div>
<!--{/if}-->
