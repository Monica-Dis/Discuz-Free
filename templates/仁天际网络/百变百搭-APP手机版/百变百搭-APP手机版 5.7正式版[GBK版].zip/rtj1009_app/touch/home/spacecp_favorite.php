<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/ren_lang.'.currentlang().'.php';}-->
<!--{if $_GET['op'] == 'delete'}-->
<div class="tip">
	<form id="favoriteform_{$favid}" name="favoriteform_{$favid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=favorite&op=delete&favid=$favid&type=$_GET[type]&mobile=2">
		<input type="hidden" name="referer" value="{eval echo dreferer();}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<dt>{lang delete_favorite_message}</dt>
		<dd>
			<input type="submit" name="deletesubmitbtn" id="deletesubmitbtn" value="{lang determine}" class="formdialog button2 color">
			<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
		</dd>
	</form>
</div>
<!--{else}-->
<div class="tip ren-hf-post">
	<form method="post" autocomplete="off" id="favoriteform_{$id}" name="favoriteform_{$id}" action="home.php?mod=spacecp&ac=favorite&type=$type&id=$id&spaceuid=$spaceuid&mobile=2" >
		<input type="hidden" name="favoritesubmit" value="true" />
		<input type="hidden" name="referer" value="{eval echo dreferer();}" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="post_from ren_kshf cl">
			<div class="cl">
				<div class="ren-post-nav cl">
					<div class="ren-post-wall">
						<span>{$rtj1009_lang['home067']}</span>
					</div>
				</div>
				<div class="ren_post_nr cl">
					<textarea id="general_{$id}" name="description" rows="1" class="ren_post_nrk" cols="70" rows="2"><!--{if $description}-->$description<!--{else}-->{lang favorite_description_default}<!--{/if}--></textarea>
				</div>
			</div>
		</div>
		<dd>
			<input type="submit" name="favoritesubmit_btn" id="favoritesubmit_btn" value="{lang determine}" class="formdialog button2 color">
			<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
		</dd>
	</form>
</div>
<!--{/if}-->



<!--{template common/footer}-->

