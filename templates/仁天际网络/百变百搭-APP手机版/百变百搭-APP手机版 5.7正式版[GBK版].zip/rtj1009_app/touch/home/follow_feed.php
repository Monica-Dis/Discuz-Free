<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl"> <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z"> <span class="ren_bk_name">{$rtj1009_lang['home002']}</span> </div>
        <a href="home.php?mod=spacecp&ac=search" class="y ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
	</div>
</header>
<!--{/if}-->


<div class="content p-b-0">
	<div class="rtj1009-nav-swiper">
		<div class="swiper-container2 ren_m_lx">
			<ul class="swiper-wrapper">
				<li class="swiper-slide{if $a_actives[me]} a{/if}"><a href="home.php?mod=space&do=friend">{$rtj1009_lang['home002']}</a></li>
				<li class="swiper-slide{if $_GET['do'] == 'follower'} a{/if}"><a href="home.php?mod=follow&do=follower">{$rtj1009_lang['home003']}</a></li>
				<li class="swiper-slide{if $_GET['do'] == 'following'} a{/if}"><a href="home.php?mod=follow&do=following">{$rtj1009_lang['home004']}</a></li>
				<li class="swiper-slide{if $a_actives[request]} a{/if}"><a href="home.php?mod=spacecp&ac=friend&op=request">{$rtj1009_lang['home005']}</a></li>
				<li class="swiper-slide{if $a_actives[visitor]} a{/if}"><a href="home.php?mod=space&do=friend&view=visitor">{$rtj1009_lang['home006']}</a></li>
				<li class="swiper-slide{if $a_actives[blacklist]} a{/if}"><a href="home.php?mod=space&do=friend&view=blacklist">{$rtj1009_lang['home007']}</a></li>
                <li class="swiper-slide{if $actives[search]} a{/if}"><a href="home.php?mod=spacecp&ac=search">{lang search_friend}</a></li>
			</ul>
		</div>
	</div>
<!--{if in_array($do, array('following', 'follower'))}-->
<div class="ren-friend-list cl">
<!--{if $list}-->
	<ul class="ren-friend-re cl">
	<!--{loop $list $fuid $fuser}-->
		<li class="cl<!--{if in_array($fuser['uid'], $newfollower_list)}--> unread<!--{/if}-->">
		<!--{if $do=='following'}-->
		<div class="ren-list-usxx">
			<a href="home.php?mod=space&uid=$fuser['followuid']&do=profile" class="ren-us-img z">
				<!--{avatar($fuser['followuid'],small)}-->
			</a>
			<div class="z ren-us-name">
				<a href="home.php?mod=space&uid=$fuser['followuid']&do=profile" class="z">$fuser['fusername']</a>
				<span id="followbkame_{$fuser['followuid']}" class="xg1 xs1 xw0"><!--{if $fuser['bkname']}-->$fuser[bkname]<!--{/if}--></span>
			</div>
			<div class="z ren-us-dateline">
				<span class="info_label">{$rtj1009_lang['home008']}</span>
				<span class="info_value">$memberinfo[$fuid]['follower']</span>
				<span class="info_label">{$rtj1009_lang['home009']}</span>
				<span class="info_value">$memberinfo[$fuid]['following']</span>
			</div>
			<div class="y ren-friend-in">
				<!--{if $viewself && $fuser[followuid] != $_G[uid]}-->
					<a href="home.php?mod=spacecp&ac=follow&op=bkname&fuid=$fuser['followuid']&handlekey=followbkame_$fuser['followuid']" id="fbkname_$fuser['followuid']" class="z dialog"><!--{if $fuser['bkname']}-->{lang follow_mod_bkname}<!--{else}-->{$rtj1009_lang['home010']}<!--{/if}--></a>
				<!--{/if}-->
				<!--{if $viewself}-->
					<a id="a_followmod_{$fuser['followuid']}" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['followuid']" class="dialog tu z">{$rtj1009_lang['home011']}</a>
				<!--{elseif $fuser[followuid] != $_G[uid]}-->
					<!--{if $fuser['mutual']}-->
						<a id="a_followmod_{$fuser['followuid']}" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['followuid']" class="dialog tu z">{$rtj1009_lang['home011']}</a>
					<!--{elseif helper_access::check_module('follow')}-->
						<a id="a_followmod_{$fuser['followuid']}" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['followuid']" class="dialog tu z">{$rtj1009_lang['home011']}</a>
					<!--{/if}-->
				<!--{/if}-->
			</div>
		</div>
		<!--{else}-->
		<div class="ren-list-usxx">
			<a href="home.php?mod=space&uid=$fuser['uid']&do=profile" class="ren-us-img z">
				<!--{avatar($fuser['uid'],small)}-->
			</a>
			<div class="z ren-us-name">
				<a href="home.php?mod=space&uid=$fuser['uid']&do=profile" class="z">$fuser['username']</a>
			</div>
			<div class="z ren-us-dateline">
				<span class="info_label">{$rtj1009_lang['home008']}</span>
				<span class="info_value">$memberinfo[$fuid]['follower']</span>
				<span class="info_label">{$rtj1009_lang['home009']}</span>
				<span class="info_value">$memberinfo[$fuid]['following']</span>
			</div>
			<div class="y ren-friend-in">
			<!--{if $fuser[uid] != $_G[uid]}-->
				<!--{if $fuser['mutual']}-->
					<a id="a_followmod_{$fuser['uid']}" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$fuser['uid']" class="dialog tu z">{$rtj1009_lang['home011']}</a>
				<!--{elseif helper_access::check_module('follow')}-->
					<a id="a_followmod_{$fuser['uid']}" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$fuser['uid']" class="dialog tu z">{$rtj1009_lang['home012']}</a>
				<!--{/if}-->
			<!--{/if}-->
			</div>
		</div>
		<!--{/if}-->
		</li>
	<!--{/loop}-->
	</ul>
	<!--{if !empty($multi)}--><div>$multi</div><!--{/if}-->
	<!--{else}-->
	<div class="ren_ss_wu">
		<i class="icon ren-font">&#xe608;</i>
		<span>{lang no_friend_list}</span>
	</div>
	<!--{/if}-->
</div>
<!--{/if}-->
</div>

<!--{template common/footer}-->

