<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="rtj1009_p_nav">
    <div class="ren_p_nav">
        <a href="home.php?mod=spacecp&ac=usergroup" $activeus[usergroup]>{lang my_usergroups}</a>
        <a href="home.php?mod=spacecp&ac=usergroup&do=list" $activeus[list] $activeus[expiry]>{lang usergroups_joinbuy}</a>
        <a href="home.php?mod=spacecp&ac=usergroup&do=forum" $activeus[forum]>{lang my}{$_G['setting']['navs'][2]['navname']}{lang rights}</a>
    </div>
</div>
