<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<li id="comment_$value[cid]_li" class="ren-wall-li cl">
	<div class="ren_lc_xx cl">
		<a href="home.php?mod=space&uid=$value[authorid]&do=profile" class="avatar z">
			<!--{if $value[author]}-->
				<!--{avatar($value[authorid],small)}-->
			<!--{else}-->
				<img src="{STATICURL}image/magic/hidden.gif" alt="hidden" />
			<!--{/if}-->
		</a>
		<div class="ren_lc_zz cl">
			<div class="ren_lc_zzxx cl">
				<!--{if $value[author]}-->
				<a href="home.php?mod=space&uid=$value[authorid]&do=profile" id="author_$value[cid]" class="ren_zz_mz z">{$value[author]}</a>
				<!--{else}-->
				$_G[setting][anonymoustext]
				<!--{/if}-->
			</div>
			<div class="ren_lc_sj cl"> 
				<span class="ren_lc_sjsj"><!--{date($value[dateline])}--></span>
			</div>
			<div class="ren-wall-listgl">
				<!--{if $_G[uid]}-->
					<!--{if $value[authorid]==$_G[uid] || $value[uid]==$_G[uid] || checkperm('managecomment')}-->
						<a href="home.php?mod=spacecp&ac=comment&op=delete&cid=$value[cid]&handlekey=delcommenthk_{$value[cid]}" class="y ren_lc_gl{if $_G['uid']} dialog{/if}"><i class="icon ren-font">&#xe64d;</i></a>
					<!--{/if}-->
					<!--{if $value[authorid]==$_G[uid]}-->
						<a href="home.php?mod=spacecp&ac=comment&op=edit&cid=$value[cid]&handlekey=editcommenthk_{$value[cid]}" class="y ren_lc_gl{if $_G['uid']} dialog{/if}"><i class="icon ren-font">&#xe62c;</i></a>
					<!--{/if}-->
				<!--{/if}-->
				<!--{if $value[authorid]!=$_G[uid] && ($value['idtype'] != 'uid' || $space[self]) && $value[author]}-->
					<a href="home.php?mod=spacecp&ac=comment&op=reply&cid=$value[cid]&feedid=$feedid&handlekey=replycommenthk_{$value[cid]}" class="y ren_lc_gl{if $_G['uid']} dialog{/if}"><i class="icon ren-font">&#xe61b;</i></a>
				<!--{/if}-->
			</div>
		</div>
	</div>

	<div id="comment_$value[cid]"class="ren-wall-comment{if $value[magicflicker]} magicflicker{/if}"><!--{if $value[status] == 0 || $value[authorid] == $_G[uid] || $_G[adminid] == 1}-->$value[message]<!--{else}--> {lang moderate_not_validate} <!--{/if}--></div>

</li>
