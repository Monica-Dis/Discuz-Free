<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['home_tpl_titles'] = array('{lang pm}');}-->
<!--{template common/header}-->
<!--{if in_array($filter, array('privatepm')) || in_array($_GET[subop], array('view'))}-->

<!--{if in_array($filter, array('privatepm'))}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{$rtj1009_lang['home044']}</span>
		</div>
        <div class="y ren_list_nav">
            <a href="home.php?mod=spacecp&ac=pm" class="ren_nav_fb"><span class="icon ren-font">&#xe619;</span></a>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
	<!-- main pmlist start -->
<div class="content p-b-0">
    <div class="rtj1009_p_nav">
        <div class="ren_p_nav">
            <a href="home.php?mod=space&do=pm&filter=privatepm" $actives[privatepm]>{lang private_pm}</a>
            <a href="home.php?mod=space&do=pm&filter=announcepm" $actives[announcepm]>{lang announce_pm}</a>
        </div>
    </div>
	<div class="ren_xx_box cl">
		<ul>
            <!--{if $list}-->
			<!--{loop $list $key $value}-->
			<li>
				<a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}">
                    <img src="<!--{if $value[pmtype] == 2}-->{STATICURL}image/common/grouppm.png<!--{else}--><!--{avatar($value[touid] ? $value[touid] : ($value[lastauthorid] ? $value[lastauthorid] : $value[authorid]), small, true)}--><!--{/if}-->" />
					<div class="ren-xx-name">
						<!--{if $value[touid]}-->
							<!--{if $value[msgfromid] == $_G[uid]}-->
								<span class="name">{$value[tousername]}</span>
							<!--{else}-->
								<span class="name">{$value[tousername]}</span>
							<!--{/if}-->
						<!--{elseif $value['pmtype'] == 2}-->
							<span class="name">{lang chatpm_author}:$value['firstauthor']</span>
						<!--{/if}-->
						<span class="time"><!--{date($value[dateline], 'u')}--></span>
					</div>
					<div class="ren-xx-mes grey">
						<span><!--{if $value['pmtype'] == 2}-->[{lang chatpm}]<!--{if $value[subject]}-->$value[subject]<br><!--{/if}--><!--{/if}--><!--{if $value['pmtype'] == 2 && $value['lastauthor']}--><div style="padding:0 0 0 20px;">......<br>$value['lastauthor'] : $value[message]</div><!--{else}-->$value[message]<!--{/if}--></span>
					</div>
					<!--{if $value[new]}--><span class="num">$value[pmnum]</span><!--{/if}-->
				</a>
			</li>
			<!--{/loop}-->
            <!--{else}-->
            <div class="ren_ss_wu">
                <i class="icon ren-font">&#xe608;</i>
                <span>{lang no_corresponding_pm}</span>
            </div>
            <!--{/if}-->
		</ul>
	</div>
</div>
	<!-- main pmlist end -->

<!--{elseif in_array($_GET[subop], array('view'))}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_grkj z">
            <span class="ren_bk_name ren_vm">{$rtj1009_lang['home044']}</span>
        </div>
        <div class="y ren_list_nav">
            <a href="home.php?mod=spacecp&ac=pm" class="ren_nav_fb"><span class="icon ren-font">&#xe619;</span></a>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<!-- main viewmsg_box start -->
<div class="content p-b-0">
	<div class="ren_xx_wp rtj1009_m_main">
		<div class="ren_msg_box b_m">
			<!--{if !$list}-->
				<li class="ren_wtie_ts">{lang no_corresponding_pm}</li>
			<!--{else}-->
				<!--{loop $list $key $value}-->
					<!--{subtemplate home/space_pm_node}-->
				<!--{/loop}-->
				$multi
			<!--{/if}-->
		</div>
        <div class="ren_xx_hui">
            <form id="pmform" class="pmform" name="pmform" method="post" action="home.php?mod=spacecp&ac=pm&op=send&pmid=$pmid&daterange=$daterange&pmsubmit=yes&mobile=2" >
                <input type="hidden" name="formhash" value="{FORMHASH}" />
                <!--{if !$touid}-->
                <input type="hidden" name="plid" value="$plid" />
                <!--{else}-->
                <input type="hidden" name="touid" value="$touid" />
                <!--{/if}-->
                <script type="text/javascript" src="template/rtj1009_app/js/pm.face.js"></script>
                <div class="ren_reply">
                    <div class="ren_xx_kuang z">
                    	<input type="text" value="" class="ren_xx_px" autocomplete="off" id="replymessage" name="message" placeholder="{$rtj1009_lang['home045']}">
                    </div>
                    <a href="javascript:void(0)" class="face"><i class="icon ren-font">&#xe615;</i></a>
                    <div class="ren_xx_rn z"><input type="button" name="pmsubmit" id="pmsubmit" class="formdialog button3" value="{$rtj1009_lang['home046']}" /></div>
                </div>
                <div id="Smohan_FaceBox"></div><script type="text/javascript">
				$(function (){
					$("a.face").smohanfacebox({
						Event : "click",
						divid : "Smohan_FaceBox",
						textid : "replymessage"
					});
				});

				$('#Smohan_Showface').click(function(){
					$('#Zones').fadeIn(360);
					$('#Zones').html($('#Smohan_text').val());
					$('#Zones').replaceface($('#Zones').html());
				});

				</script>
            </form>
        </div>
	</div>
<!--{else}-->
    <div class="ren_ss_wu">
        <i class="icon ren-font">&#xe608;</i>
        <span>{lang no_corresponding_pm}</span>
    </div>
<!--{/if}-->
</div>
<!-- main viewmsg_box end -->
<!--{elseif $_GET['subop'] == 'viewg'}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_grkj z">
            <span class="ren_bk_name ren_vm">{$rtj1009_lang['home044']}</span>
        </div>
        <div class="y ren_list_nav">
            <a href="home.php?mod=spacecp&ac=pm" class="ren_nav_fb"><span class="icon ren-font">&#xe619;</span></a>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<!--{if $grouppm}-->
<div class="content p-b-0">
    <div class="ren_xx_box cl">
        <ul>
            <li class="ren-xx-gzxxli">
                <div class="ren-notice-wuavt"><i class="icon ren-font"><!--{if $grouppm[author]}-->&#xe6a5;<!--{else}-->&#xe61b;<!--{/if}--></i></div>
                <div class="ren-xx-name">
                    <span class="name"><!--{if $grouppm['author']}-->{lang sendmultipmwho}<!--{else}-->{lang sendmultipmsystem}<!--{/if}--></span>
                </div>
                <span class="time tu"><!--{date($grouppm[dateline], 'u')}--></span>
                <div class="ren-xx-mes tu">
                    <span>$grouppm[message]</span>
                </div>
                <!--{if $grouppm[author]}-->
                <div class="ren_login btn_login">
                    <a href="home.php?mod=spacecp&ac=pm&touid=$grouppm[authorid]" class="button ren_btn">{lang reply} $grouppm[author]</a>
                </div>
                <!--{/if}-->
            </li>
        </ul>
    </div>
</div>
<!--{else}-->
<div class="ren_ss_wu">
    <i class="icon ren-font">&#xe608;</i>
    <span>{lang no_corresponding_pm}</span>
</div>
<!--{/if}-->
<!--{elseif $_GET['subop'] == 'setting'}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_grkj z">
            <span class="ren_bk_name ren_vm">{$rtj1009_lang['home044']}</span>
        </div>
        <div class="ren_nav_right open-panel">
            <div class="ren_btn">
                <span><span class="ren_nav_icon"><span></span></span></span>
            </div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content p-b-0">
<form id="pmsettingform" name="pmsettingform" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=pm&op=setting">
    <table cellspacing="0" cellpadding="0" class="tfm mtm">
        <tr>
            <th>{lang pm_onlyacceptfriendpm}</th>
            <td>
                <label class="lb"><input type="radio" name="onlyacceptfriendpm" class="pr" value="1"{if $acceptfriendpmstatus == 1} checked="checked"{/if} />{lang yes}</label>
                <label class="lb"><input type="radio" name="onlyacceptfriendpm" class="pr" value="2"{if $acceptfriendpmstatus == 2} checked="checked"{/if} />{lang no}</label>
            </td>
        </tr>
        <tr>
            <th>{lang ignore_list}</th>
            <td>
                <textarea id="ignorelist" name="ignorelist" cols="40" rows="3" class="pt" onkeydown="ctrlEnter(event, 'ignoresubmit');">$ignorelist</textarea>
                <div class="d">{lang ignore_member_pm_message}</div>
            </td>
        </tr>
        <tr>
            <th></th>
            <td><button type="submit" name="settingsubmit" value="true" class="pn"><strong>{lang save}</strong></button></td>
        </tr>
    </table>
    <input type="hidden" name="formhash" value="{FORMHASH}" />
</form>
</div>
<!--{else}-->

<!--{if $count || $grouppms}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_grkj z">
            <span class="ren_bk_name ren_vm">{$rtj1009_lang['home044']}</span>
        </div>
        <div class="y ren_list_nav">
            <a href="home.php?mod=spacecp&ac=pm" class="ren_nav_fb"><span class="icon ren-font">&#xe619;</span></a>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content p-b-0">
    <div class="rtj1009_p_nav">
        <div class="ren_p_nav">
            <a href="home.php?mod=space&do=pm&filter=privatepm" $actives[privatepm]>{lang private_pm}</a>
            <a href="home.php?mod=space&do=pm&filter=announcepm" $actives[announcepm]>{lang announce_pm}</a>
        </div>
    </div>
    <div class="ren_xx_box cl">
        <ul>
            <!--{if $grouppms}-->
            <!--{loop $grouppms $grouppm}-->
            <li>
                <a href="home.php?mod=space&do=pm&subop=viewg&pmid=$grouppm[id]">
                    <div class="ren-notice-wuavt"><i class="icon ren-font"><!--{if $grouppm[author]}-->&#xe6a5;<!--{else}-->&#xe61b;<!--{/if}--></i></div>
                    <div class="ren-xx-name">
                        <!--{if $grouppm[author]}-->
                        <span class="name">$grouppm[author]</span>
                        <!--{else}-->
                        <span class="name">$_G['setting']['sitename']</span>
                        <!--{/if}-->
                        <span class="time"><!--{date($grouppm[dateline], 'u')}--></span>
                    </div>
                    <div class="ren-xx-mes grey">
                        <span>$grouppm[message]</span>
                    </div>
                </a>
            </li>
            <!--{/loop}-->
            <!--{/if}-->
            <!--{loop $list $key $value}-->
            <li>
                <a href="{if $value[touid]}home.php?mod=space&do=pm&subop=view&touid=$value[touid]{else}home.php?mod=space&do=pm&subop=view&plid={$value['plid']}&type=1{/if}">
                    <img src="<!--{if $value[pmtype] == 2}-->{STATICURL}image/common/grouppm.png<!--{else}--><!--{avatar($value[touid] ? $value[touid] : ($value[lastauthorid] ? $value[lastauthorid] : $value[authorid]), small, true)}--><!--{/if}-->" />
                    <div class="ren-xx-name">
                        <!--{if $value[touid]}-->
                        <!--{if $value[msgfromid] == $_G[uid]}-->
                        <span class="name">{$value[tousername]}</span>
                        <!--{else}-->
                        <span class="name">{$value[tousername]}</span>
                        <!--{/if}-->
                        <!--{elseif $value['pmtype'] == 2}-->
                        <span class="name">{lang chatpm_author}:$value['firstauthor']</span>
                        <!--{/if}-->
                        <span class="time"><!--{date($value[dateline], 'u')}--></span>
                    </div>
                    <div class="ren-xx-mes grey">
                        <span><!--{if $value['pmtype'] == 2}-->[{lang chatpm}]<!--{if $value[subject]}-->$value[subject]<br><!--{/if}--><!--{/if}--><!--{if $value['pmtype'] == 2 && $value['lastauthor']}--><div style="padding:0 0 0 20px;">......<br>$value['lastauthor'] : $value[message]</div><!--{else}-->$value[message]<!--{/if}--></span>
                    </div>
                    <!--{if $value[new]}--><span class="num">$value[pmnum]</span><!--{/if}-->
                </a>
            </li>
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{else}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_grkj z">
            <span class="ren_bk_name ren_vm">{$rtj1009_lang['home044']}</span>
        </div>
        <div class="y ren_list_nav">
            <a href="home.php?mod=spacecp&ac=pm" class="ren_nav_fb"><span class="icon ren-font">&#xe619;</span></a>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content p-b-0">
    <div class="rtj1009_p_nav">
        <div class="ren_p_nav">
            <a href="home.php?mod=space&do=pm&filter=privatepm" $actives[privatepm]>{lang private_pm}</a>
            <a href="home.php?mod=space&do=pm&filter=announcepm" $actives[announcepm]>{lang announce_pm}</a>
        </div>
    </div>
    <div class="ren_xx_box cl">
        <ul>
            <div class="ren_ss_wu">
                <i class="icon ren-font">&#xe608;</i>
                <span>{lang no_corresponding_pm}</span>
            </div>
        </ul>
    </div>
</div>
<!--{/if}-->
<!--{/if}-->


<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

