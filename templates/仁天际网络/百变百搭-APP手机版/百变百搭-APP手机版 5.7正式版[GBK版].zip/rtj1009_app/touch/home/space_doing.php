<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl"> <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z"> <span class="ren_bk_name">{$rtj1009_lang['home036']}</span> </div>
		<div class="y ren_list_nav">
			<a href="javascript:;" class="ren_nav_fb open-popup" data-popup=".popup-view"><span class="icon ren-font">&#xe619;</span></a>
		</div>
	</div>
</header>
<!--{/if}-->

<div class="popup popup-view">
	<header class="bar bar-nav popup-view-nav">
		<div class="ren_nav cl"> <a href="javascript:;" class="z ren-fh close-popup"><i class="icon ren-font">&#xe64d;</i></a>
			<div class="ren_top_dqwz z"> <span>{$rtj1009_lang['home037']}</span> </div>
		</div>
	</header>
	<div class="content-block">
		<div class="ren_lostpw ren-doing-fb">
			<div class="ren_kshf cl"> 
				<!--{if helper_access::check_module('doing')}-->
				<!--{template home/space_doing_form}-->
				<!--{/if}-->
				<script type="text/javascript" src="template/rtj1009_app/js/home.face.js"></script>
				<div id="Home_FaceBox"></div>
				<script type="text/javascript">
					$(function (){
						$("a.wall_face").HomeFaceBox({
							Event : "click",	//�����¼�	
							divid : "Home_FaceBox", //���DIV ID
							textid : "message" //�ı��� ID
						});
					});
					
					$('#Smohan_Showface').click(function(){
						$('#Zones').fadeIn(360);
						$('#Zones').html($('#Smohan_text').val());
						$('#Zones').replaceface($('#Zones').html());
					});
				</script> 
			</div>
		</div>
	</div>
</div>


<div class="content p-b-0">
	<div class="ren-doing-img"><img src="template\rtj1009_app\icon\doing.jpg" /></div>
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
				<a href="home.php?mod=space&do=$do&view=me" <!--{if $_G[uid]}-->$actives[me]<!--{else}-->class="ren-confirm"<!--{/if}-->>{$rtj1009_lang['home038']}</a>
				<a href="home.php?mod=space&do=$do&view=we" <!--{if $_G[uid]}-->$actives[we]<!--{else}-->class="ren-confirm"<!--{/if}-->>{$rtj1009_lang['home039']}</a>
				<a href="home.php?mod=space&do=$do&view=all"$actives[all]>{lang view_all}</a>
		</div>
	</div>
	<div class="ren-blog-count cl">
		<div class="ren-wall-list">
			<!--{if $dolist}-->
			<ul class="cl">
				<!--{loop $dolist $dv}-->
				<li class="ren-wall-li cl">
				<!--{eval $doid = $dv[doid];}-->
				<!--{eval $_GET[key] = $key = random(8);}-->
					<div class="ren_lc_xx cl">
						<!--{if empty($diymode)}-->
						<a href="home.php?mod=space&uid=$dv[uid]&do=profile" class="avatar z">
							<!--{avatar($dv[uid],small)}-->
						</a>
						<!--{/if}-->
						<div class="ren_lc_zz cl">
							<div class="ren_lc_zzxx cl">
								<!--{if empty($diymode)}-->
								<a href="home.php?mod=space&uid=$dv[uid]&do=profile" id="author_$value[cid]" class="ren_zz_mz z">$dv[username]</a>
								<!--{/if}-->
							</div>
							<div class="ren_lc_sj cl"> 
								<span class="ren_lc_sjsj"><!--{date($dv['dateline'], 'u')}--></span>
							</div>
							<div class="ren-wall-listgl">
								<!--{if $dv[uid]==$_G[uid]}-->
									<a href="home.php?mod=spacecp&ac=doing&op=delete&doid=$doid&id=$dv[id]&handlekey=doinghk_{$doid}_$dv[id]" id="{$key}_doing_delete_{$doid}_{$dv[id]}" class="y ren_lc_gl{if $_G['uid']} dialog{/if}"><i class="icon ren-font">&#xe64d;</i></a>
								<!--{/if}-->
								<!--{if helper_access::check_module('doing')}-->
									<a href="home.php?mod=spacecp&ac=doing&op=docomment&handlekey=msg_0&doid=$doid&id=0&key=$key" class="y ren_lc_gl{if $_G['uid']} dialog{/if}"><i class="icon ren-font">&#xe61b;</i></a>
								<!--{/if}-->
							</div>
						</div>
					</div>
					<div id="comment_$value[cid]"class="ren-wall-comment{if $value[magicflicker]} magicflicker{/if}">$dv[message]<!--{if $dv[status] == 1}--> <span style="font-weight: bold;">({lang moderate_need})</span><!--{/if}--></div>
					
					<div id="{$key}dl{$doid}" class="ren-wall-comment">
						<!--{eval $list = $clist[$doid];}-->
						<div class="quote" id="{$key}_$doid"{if empty($list) || !$showdoinglist[$doid]} style="display:none;"{/if}>
							<span id="{$key}_form_{$doid}_0"></span>
							<!--{template home/space_doing_li}-->
						</div>
					</div>
			
				</li>
				<!--{/loop}-->
				<!--{if $multi}-->
				<div class="pgs cl mtm">$multi</div>
				<!--{/if}-->
			</ul>
			<!--{else}-->
			<div class="ren_ss_wu">
				<i class="icon ren-font">&#xe608;</i>
				<span>{lang doing_no_replay}<!--{if $space[self]}-->{lang doing_now}<!--{/if}--></span>
			</div>
			<!--{/if}-->
		</div>
	</div>
</div>

<!--{eval $nofooter = true;}--> 
<!--{template common/footer}-->

