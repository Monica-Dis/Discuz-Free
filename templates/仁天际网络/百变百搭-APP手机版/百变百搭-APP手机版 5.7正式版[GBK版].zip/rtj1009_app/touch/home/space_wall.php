<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header<!--{if $diymode && $rtj1009_m_config['ren_menu_nav'] ==2}--> ren-menu-header<!--{/if}-->">
	<div class="ren_nav cl"> <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z"> <span class="ren_bk_name ren_vm">{$rtj1009_lang['ren124']}</span> </div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn"> <span><span class="ren_nav_icon"><span></span></span></span> </div>
		</div>
	</div>
</header>
<!-- header end --> 
<!--{/if}-->
<!--{eval $_G['home_tpl_titles'] = array('{lang message}');}-->

<div class="content<!--{if $diymode && $rtj1009_m_config['ren_menu_nav'] ==2}--> p-t-0<!--{/if}-->">
	<!--{template home/space_menu}-->
	<div class="ren-blog-count cl">
		<!--{if $count}-->
		<div class="ren-wall-list">
			<ul class="cl">
				<!--{loop $list $k $value}-->
				<!--{template home/space_comment_li}-->
				<!--{/loop}-->
			</ul>
			<div class="pgs cl">$multi</div>
		</div>
		<!--{else}-->
		<div class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{$rtj1009_lang['home065']}</span>
		</div>
		<!--{/if}-->
	</div>
	<div class="ren_xx_hui">
		<div class="ren_reply open-popup" data-popup=".popup-view">
			<div class="ren_xx_kuang z">
				<div class="ren_xx_px">{$rtj1009_lang['home066']}</div>
			</div>
			<div class="face"><i class="icon ren-font">&#xe615;</i></div>
			<div class="ren_xx_rn z">
				<div class="button3">{$rtj1009_lang['home046']}</div>
			</div>
		</div>
	</div>
</div>
<div class="popup popup-view">
	<header class="bar bar-nav popup-view-nav">
		<div class="ren_nav cl"> <a href="javascript:;" class="z ren-fh close-popup"><i class="icon ren-font">&#xe64d;</i></a>
			<div class="ren_top_dqwz z"> <span>{$rtj1009_lang['home042']}</span> </div>
		</div>
	</header>
	<div class="content-block">
		<div class="ren_lostpw">
			<div class="ren_kshf cl"> 
				<!--{if helper_access::check_module('wall')}-->
				<form id="quickcommentform_{$space[uid]}" action="home.php?mod=spacecp&ac=comment" method="post" autocomplete="off">
					<div class="ren_post_pi cl">
						<div class="ren_post_nr cl">
							<textarea id="comment_message" placeholder="{$rtj1009_lang['ren053']}" name="message" rows="5" class="ren_post_nrk"></textarea>
						</div>
						<div class="ren_post_tj">
							<input type="hidden" name="referer" value="home.php?mod=space&uid={$space[uid]}&do=wall" />
							<input type="hidden" name="id" value="$space[uid]" />
							<input type="hidden" name="idtype" value="uid" />
							<input type="hidden" name="handlekey" value="qcwall_{$space[uid]}" />
							<input type="hidden" name="commentsubmit" value="true" />
							<input type="hidden" name="quickcomment" value="true" />
							<a href="javascript:void(0)" class="wall_face"><i class="icon ren-font">&#xe615;</i></a>
							<div id="commentsubmit_btn" class="post_fast">
								<button type="submit" name="commentsubmit_btn"value="true" id="commentsubmit_btn" class="ren_post_tjan">{lang leave_comments}</button>
							</div>
							<span id="return_qcwall_{$space[uid]}"></span>
						</div>
						<input type="hidden" name="formhash" value="{FORMHASH}" />
					</div>
				</form>
				<!--{/if}-->
				<script type="text/javascript" src="template/rtj1009_app/js/home.face.js"></script>
				<div id="Home_FaceBox"></div>
				<script type="text/javascript">
					$(function (){
						$("a.wall_face").HomeFaceBox({
							Event : "click",	//�����¼�	
							divid : "Home_FaceBox", //���DIV ID
							textid : "comment_message" //�ı��� ID
						});
					});
					
					$('#Smohan_Showface').click(function(){
						$('#Zones').fadeIn(360);
						$('#Zones').html($('#Smohan_text').val());
						$('#Zones').replaceface($('#Zones').html());
					});
				</script> 
			</div>
		</div>
	</div>
</div>

<!--{eval $nofooter = true;}--> 
<!--{template common/footer}-->
