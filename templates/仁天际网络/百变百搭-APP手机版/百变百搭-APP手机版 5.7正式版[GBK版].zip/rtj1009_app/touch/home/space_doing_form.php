<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<script type="text/javascript">
var msgstr = '$defaultstr';
function handlePrompt(type) {
	var msgObj = $('message');
	if(type) {
		if(msgObj.value == msgstr) {
			msgObj.value = '';
			msgObj.className = 'xg2';
		}
		if($('message_menu')) {
			if($('message_menu').style.display == 'block') {
				showFace('message', 'message', msgstr);
			}
		}
		if(BROWSER.firefox || BROWSER.chrome) {
			showFace('message', 'message', msgstr);
		}
	} else {
		if(msgObj.value == ''){
			msgObj.value = msgstr;
			msgObj.className = 'xg1';
		}
	}
}
</script>


	<form method="post" autocomplete="off" id="mood_addform" action="home.php?mod=spacecp&ac=doing&view=$_GET[view]" onsubmit="if($('message').value == msgstr){return false;}">
		<div class="ren_post_pi cl">
			<div class="ren_post_nr cl">
				<textarea name="message" id="message" class="ren_post_nrk" placeholder="$defaultstr" rows="5"></textarea>
			</div>
			<div class="ren_post_tj">
				<a href="javascript:void(0)" class="wall_face"><i class="icon ren-font">&#xe615;</i></a>
				<div id="commentsubmit_btn" class="post_fast">
					<button type="submit" name="add" id="add" class="ren_post_tjan">{lang publish}</button>
				</div>
				<!--{if $_G['group']['maxsigsize']}-->
				<div class="item-input">
					<span>{$rtj1009_lang['home031']}</span>
					<label for="to_sign" class="label-switch">
					<input type="checkbox" name="to_signhtml" id="to_sign" value="1"{if $blog[noreply]} checked="checked"{/if} />
						<div class="checkbox"></div>
					</label>
				</div>
				<!--{/if}-->
				<span id="return_qcwall_{$space[uid]}"></span>
			</div>
		</div>
		<input type="hidden" name="addsubmit" value="true" />
		<input type="hidden" name="refer" value="$theurl" />
		<input type="hidden" name="topicid" value="$topicid" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
	</form>
	

