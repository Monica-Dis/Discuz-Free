<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<script type="text/javascript" src='template/rtj1009_app/js/ren_share.js'></script>
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
		<a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z"><span class="ren_bk_name"><!--{if $album[picnum]}-->$sequence / $album[picnum]<!--{else}-->{$rtj1009_lang['home017']}<!--{/if}--></span></div>
        <div class="y ren_list_nav">
            <a href="home.php?mod=spacecp&ac=upload" class="ren_nav_ss"><span class="icon ren-font">&#xe645;</span></a>
        </div>
	</div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content">
	<div class="ren-album-img">
		<div class="ren-album-imgxx pic">
			<div id="photo_pic" class="c{if $pic[magicframe]} magicframe magicframe$pic[magicframe]{/if}">
				<a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid"><img src="$pic[pic]" id="pic" class="vm" /></a>
				<div class="tbmu" id="pic_block">
					<a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$upid" class="z">{lang previous_pic}</a>
					<a href="home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid" id="nextlink" class="y">{lang next_pic}</a>
				</div>
					<script type="text/javascript">
						function createElem(e){
							var obj = document.createElement(e);
							obj.style.position = 'absolute';
							obj.style.zIndex = '1';
							obj.style.cursor = 'pointer';
							obj.onmouseout = function(){ this.style.background = 'none';}
							return obj;
						}
						function viewPhoto(){
							var pager = createElem('div');
							var pre = createElem('div');
							var next = createElem('div');
							var cont = $('photo_pic');
							var tar = $('pic');
							var space = 0;
							var w = tar.width/2;
							if(!!window.ActiveXObject && !window.XMLHttpRequest){
								space = -(cont.offsetWidth - tar.width)/2;
							}
							var objpos = fetchOffset(tar);
	
							pager.style.position = 'absolute';
							pager.style.top = '0';
							pager.style.left = objpos['left'] + 'px';
							pager.style.top = objpos['top'] + 'px';
							pager.style.width = tar.width + 'px';
							pager.style.height = tar.height + 'px';
							pre.style.left = 0;
							next.style.right = 0;
							pre.style.width = next.style.width = w + 'px';
							pre.style.height = next.style.height = tar.height + 'px';
							pre.innerHTML = next.innerHTML = '<img src="{IMGDIR}/emp.gif" width="' + w + '" height="' + tar.height + '" />';
	
							pre.onmouseover = function(){ this.style.background = 'url({IMGDIR}/pic-prev.png) no-repeat 0 100px'; }
							pre.onclick = function(){ window.location = 'home.php?mod=space&uid=$pic[uid]&do=$do&picid=$upid'; }
	
							next.onmouseover = function(){ this.style.background = 'url({IMGDIR}/pic-next.png) no-repeat 100% 100px'; }
							next.onclick = function(){ window.location = 'home.php?mod=space&uid=$pic[uid]&do=$do&picid=$nextid'; }
	
							//cont.style.position = 'relative';
							cont.appendChild(pager);
							pager.appendChild(pre);
							pager.appendChild(next);
						}
						$('pic').onload = function(){
							viewPhoto();
						}
					</script>
			</div>
		
			<div class="ren-album-in">
				<p id="a_set_title" class="albim_pic_title"><span>{$rtj1009_lang['home018']}{$rtj1009_lang['ren131']}</span><!--{if $pic[title]}-->$pic[title]<!--{else}--><!--{eval echo substr($pic['filename'], 0, strrpos($pic['filename'], '.'));}--><!--{/if}--></p>
				<p class="ren-album-hot"><span>{$rtj1009_lang['home019']}{$rtj1009_lang['ren131']}</span>
					{lang upload_at} <!--{date($pic[dateline])}--> ($pic[size])
				</p>
			</div>
		</div>
		
		<div class="ren-blog-count cl">
			<div class="ren_lc_ks cl">
				<span class="ren_lc_ksz z">{$rtj1009_lang['home020']}</span>
			</div>
			<!--{if $count}-->
				<div class="ren-wall-list">
					<ul class="cl">
					<!--{loop $list $k $value}-->
						<!--{template home/space_comment_li}-->
					<!--{/loop}-->
					</ul>
					<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
				</div>
				<!--{else}-->
				<div class="ren_ss_wu">
					<i class="icon ren-font">&#xe608;</i>
					<span>{$rtj1009_lang['home021']}</span>
				</div>
			<!--{/if}-->
		</div>
	</div>
</div>

<div class="ren_view_share ren_view_footer ren-album-viewf">
	<a class="ren_viewdi_hf open-popup" data-popup=".popup-view"><span>{$rtj1009_lang['ren053']}</span></a>
	<a href="javascript:;" class="ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe742;</i></a>
</div>

<div class="popup popup-view">
	<header class="bar bar-nav popup-view-nav">
		<div class="ren_nav cl"> <a href="javascript:;" class="z ren-fh close-popup"><i class="icon ren-font">&#xe64d;</i></a>
			<div class="ren_top_dqwz z"> <span>{$rtj1009_lang['home022']}</span> </div>
		</div>
	</header>
	<div class="content-block">
		<div class="ren_lostpw">
			<div class="ren_kshf cl"> 
				<!--{if helper_access::check_module('album')}-->
				<form id="quickcommentform_{$picid}" name="quickcommentform_{$picid}" action="home.php?mod=spacecp&ac=comment&handlekey=qcpic_{$picid}" method="post" autocomplete="off" onsubmit="ajaxpost('quickcommentform_{$picid}', 'return_qcpic_{$picid}');doane(event);">
					<div class="ren_post_pi cl">
						<div class="ren_post_nr cl">
							<textarea id="comment_message" placeholder="{$rtj1009_lang['ren053']}" name="message" rows="5" class="ren_post_nrk"></textarea>
						</div>
						<div class="ren_post_tj">
							<input type="hidden" name="refer" value="$theurl" />
							<input type="hidden" name="id" value="$picid" />
							<input type="hidden" name="idtype" value="picid" />
							<input type="hidden" name="commentsubmit" value="true" />
							<input type="hidden" name="quickcomment" value="true" />
							<a href="javascript:void(0)" class="wall_face"><i class="icon ren-font">&#xe615;</i></a>
							<div id="commentsubmit_btn" class="post_fast">
								<button type="submit" name="commentsubmit_btn" value="true" id="commentsubmit_btn" class="ren_post_tjan">{lang comment}</button>
							</div>
							<span id="__quickcommentform_{$picid}"></span>
							<span id="return_qcpic_{$picid}"></span>
						</div>
						<!--{if $secqaacheck || $seccodecheck}--><!--{subtemplate common/seccheck}--><!--{/if}-->
						<input type="hidden" name="formhash" value="{FORMHASH}" />
					</div>
				</form>
				<!--{/if}-->
				<script type="text/javascript" src="template/rtj1009_app/js/home.face.js"></script>
				<div id="Home_FaceBox"></div>
				<script type="text/javascript">
					$(function (){
						$("a.wall_face").HomeFaceBox({
							Event : "click",	//�����¼�	
							divid : "Home_FaceBox", //���DIV ID
							textid : "comment_message" //�ı��� ID
						});
					});
					
					$('#Smohan_Showface').click(function(){
						$('#Zones').fadeIn(360);
						$('#Zones').html($('#Smohan_text').val());
						$('#Zones').replaceface($('#Zones').html());
					});
				</script> 
			</div>
		</div>
	</div>
</div>


<script type="text/javascript">
    $('.ren_share').ready(function(){
        var share = new ren_share({
            title : document.title,
            url   : window.location.href,
            desc  : document.getElementsByName('description')[0].content,
            img   : '$ren_wx_imgUrl',
        });
        $('.ren_share').click(function () {
            share.init(0,'.ren_view_share');
        });
    });
</script>
<div id="popup-share" class="popup popup-share">
    <div class="content-block">
        <div class="ren_tiefx_share">
            <div class="bdsharebuttonbox">
                <a href="javascript:;" class="popup_sqq" data-cmd="sqq"><p>{$rtj1009_lang['ren100']}</p></a>
                <a href="javascript:;" class="bds_qzone" data-cmd="qzone"><p>{$rtj1009_lang['ren101']}</p></a>
                <a href="javascript:;" class="bds_tsina" data-cmd="tsina"><p>{$rtj1009_lang['ren102']}</p></a>
                <a href="javascript:;" class="bds_weixin" data-cmd="weixin"><p>{$rtj1009_lang['ren103']}</p></a>
                <a href="javascript:;" class="bds_copy" data-cmd="copy"><p>{$rtj1009_lang['ren212']}</p></a>
            </div>
        </div>
    </div>
    <a href="javascript:;" class="ren_tiefx_qx close-popup">{$rtj1009_lang['ren012']}</a>
</div>

<!--{template common/footer}-->
