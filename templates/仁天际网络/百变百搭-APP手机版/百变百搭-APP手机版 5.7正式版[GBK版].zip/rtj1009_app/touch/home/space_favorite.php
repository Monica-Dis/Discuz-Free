<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span class="ren_bk_name">{$rtj1009_lang['home032']}</span>
		</div>
        <div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!--{/if}-->

<!-- main collectlist start -->
<div class="content p-b-0">
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
				<a href="home.php?mod=space&do=favorite&type=all" $actives[all]>{$rtj1009_lang['home033']}</a>
				<a href="home.php?mod=space&do=favorite&type=thread" $actives[thread]>{lang favorite_thread}</a>
				<a href="home.php?mod=space&do=favorite&type=forum" $actives[forum]>{lang favorite_forum}</a>
				<!--{if helper_access::check_module('blog')}--><a href="home.php?mod=space&do=favorite&type=blog" $actives[blog]>{lang favorite_blog}</a><!--{/if}-->
				<!--{if helper_access::check_module('album')}--><a href="home.php?mod=space&do=favorite&type=album" $actives[album]>{lang favorite_album}</a><!--{/if}-->
				<!--{if helper_access::check_module('portal')}--><a href="home.php?mod=space&do=favorite&type=article" $actives[article]>{lang favorite_article}</a><!--{/if}-->
		</div>
	</div>
	<div class="ren-sc-list rtj1009_m_main cl">
			<!--{if $list}-->
			<form method="post" autocomplete="off" name="delform" id="delform" action="home.php?mod=spacecp&ac=favorite&op=delete&type=$_GET[type]&checkall=1" onsubmit="showDialog('{lang del_select_favorite_confirm}', 'confirm', '', '$(\'delform\').submit();'); return false;">
			<input type="hidden" name="formhash" value="{FORMHASH}" />
			<input type="hidden" name="delfavorite" value="true" />
			<ul id="favorite_ul" class="ren_sc_list">
				<!--{loop $list $k $value}-->
				<li id="fav_$k">
					<a class="y dialog ren-fav-delete" id="a_delete_$k" href="home.php?mod=spacecp&ac=favorite&op=delete&favid=$k"><i class="icon ren-font">&#xe64d;</i></a>
					<div class="ren-fav-title">
						$value[icon]
						<a href="$value[url]">$value[title]</a>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
			<!--{else}-->
			<div class="ren_ss_wu">
				<i class="icon ren-font">&#xe608;</i>
				<span>{lang no_favorite_yet}</span>
			</div>
			<!--{/if}-->
	</div>
<!-- main collectlist end -->
$multi
</div>
<!--{eval $nofooter = true;}-->


<!--{template common/footer}-->

