<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>

<!--{eval 
	$_G[home_tpl_titles] = array('{lang task}');
}-->
<!--{template common/header}-->
<ul class="ren-task-parterlist">
	<!--{loop $parterlist $parter}-->
		<li>
			<a href="home.php?mod=space&uid=$parter[uid]" title="{if $parter[status] == 1}{lang task_complete}{elseif $parter[status] == -1}{lang task_failed}{elseif $parter[status] == 0}{lang task_complete} $parter[csc]%{/if}"  class="ren-task-avt">$parter[avatar]<p>$parter[username]</p></a>
		</li>
	<!--{/loop}-->
</ul>
<!--{template common/footer}-->
