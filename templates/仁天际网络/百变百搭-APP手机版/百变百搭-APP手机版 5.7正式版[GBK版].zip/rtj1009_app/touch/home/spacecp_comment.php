<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->


<!--{if $_GET['op'] == 'edit'}-->
<div class="tip ren-hf-post">
	<form id="editcommentform_{$cid}" name="editcommentform_{$cid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment&op=edit&cid=$cid{if $_GET[modcommentkey]}&modcommentkey=$_GET[modcommentkey]{/if}" {if $_G[inajax]} onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="editsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div class="post_from ren_kshf cl">
			<div class="cl">
				<div class="ren-post-nav cl">
					<div class="ren-post-wall">
						<span>{lang edit}</span>
					</div>
				</div>
				<div class="ren_post_nr cl">
				<textarea name="message" class="ren_post_nrk" id="message_{$cid}" name="$editor[textarea]" cols="70" rows="2">$comment[message]</textarea>
				</div>
			</div>
		</div>
		<dd>
			<input type="submit" name="editsubmit_btn" id="editsubmit_btn" value="{lang determine}" class="formdialog button2 color">
			<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
		</dd>
	</form>
</div>
<!--{elseif $_GET['op'] == 'delete'}-->
<div class="tip">
	<form id="deletecommentform_{$cid}" name="deletecommentform_{$cid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment&op=delete&cid=$cid" {if $_G[inajax]}onsubmit="ajaxpost(this.id, 'return_$_GET[handlekey]');"{/if}>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="deletesubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<dt>{lang delete_reply_message}</dt>
		<dd>
			<input type="submit" name="deletesubmitbtn" value="{lang determine}" class="formdialog button2 color">
			<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
		</dd>
	</form>
</div>
<!--{elseif $_GET['op'] == 'reply'}-->
<div class="tip ren-hf-post">
	<form id="replycommentform_{$comment[cid]}" name="replycommentform_{$comment[cid]}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=comment" {if $_G[inajax]} onsubmit="ajaxpost('replycommentform_{$comment[cid]}', 'return_$_GET[handlekey]');"{/if}>
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="id" value="$comment[id]" />
		<input type="hidden" name="idtype" value="$comment[idtype]" />
		<input type="hidden" name="cid" value="$comment[cid]" />
		<input type="hidden" name="commentsubmit" value="true" />
		<!--{if $_G[inajax]}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<div id="reply_msg_{$comment[cid]}" class="post_from ren_kshf cl">
			<div class="cl">
				<div class="ren-post-nav cl">
					<div class="ren-post-wall">
						<span>{lang reply}</span>
					</div>
				</div>
				<div class="ren_post_nr cl">
					<textarea id="message_pop_{$comment[cid]}" name="message" rows="2" cols="70" class="ren_post_nrk"></textarea>
				</div>
			<!--{if $secqaacheck || $seccodecheck}-->
			<!--{subtemplate common/seccheck}-->
			<!--{/if}-->
			<dd>
				<input type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="{lang reply}" class="formdialog button2 color">
				<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
			</dd>
			</div>
		</div>
	</form>
</div>
<!--{/if}-->
<!--{template common/footer}-->

