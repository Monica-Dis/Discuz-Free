<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl"> <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z"> <span class="ren_bk_name">{$rtj1009_lang['home002']}</span> </div>
        <a href="home.php?mod=spacecp&ac=search" class="y ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
	</div>
</header>
<!--{/if}-->

<!-- main collectlist start -->
<div class="content p-b-0">
	<div class="rtj1009-nav-swiper">
		<div class="swiper-container2 ren_m_lx">
			<ul class="swiper-wrapper">
				<li class="swiper-slide{if $a_actives[me]} a{/if}"><a href="home.php?mod=space&do=friend">{$rtj1009_lang['home002']}</a></li>
				<li class="swiper-slide{if $_GET['do'] == 'follower'} a{/if}"><a href="home.php?mod=follow&do=follower">{$rtj1009_lang['home003']}</a></li>
				<li class="swiper-slide{if $_GET['do'] == 'following'} a{/if}"><a href="home.php?mod=follow&do=following">{$rtj1009_lang['home004']}</a></li>
				<li class="swiper-slide{if $a_actives[request]} a{/if}"><a href="home.php?mod=spacecp&ac=friend&op=request">{$rtj1009_lang['home005']}</a></li>
				<li class="swiper-slide{if $a_actives[visitor]} a{/if}"><a href="home.php?mod=space&do=friend&view=visitor">{$rtj1009_lang['home006']}</a></li>
				<li class="swiper-slide{if $a_actives[blacklist]} a{/if}"><a href="home.php?mod=space&do=friend&view=blacklist">{$rtj1009_lang['home007']}</a></li>
                <li class="swiper-slide{if $actives[search]} a{/if}"><a href="home.php?mod=spacecp&ac=search">{lang search_friend}</a></li>
			</ul>
		</div>
	</div>
	<div class="ren-friend-list cl">
		<!--{if $_GET['view']=='blacklist'}-->
		<div class="content-padded">
			<div class="searchbar">
			<form method="post" autocomplete="off" name="blackform" action="home.php?mod=spacecp&ac=friend&op=blacklist&start=$_GET[start]">
				<div class="search-input">
					<input type="text" name="username" value="" placeholder="{$rtj1009_lang['home034']}" size="15"/>
				</div>
				<a class="button button-fill button-primary">
				<button type="submit" name="blacklistsubmit_btn" id="moodsubmit_btn" value="{lang search}" class="button2">{lang add}</button>
				</a>
				</div>
				<input type="hidden" name="blacklistsubmit" value="true" />
				<input type="hidden" name="formhash" value="{FORMHASH}" />
			</form>
		</div>
		<!--{/if}--> 
		<!--{if $list}-->
		<ul id="friend_ul" class="ren-friend-re cl">
		<!--{loop $list $key $value}-->
			<li id="friend_{$value[uid]}_li">
				<div class="ren-list-usxx">
					<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="ren-us-img z">
						<!--{avatar($value[uid],small)}-->
					</a>
					<div class="z ren-us-name tu">
						<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="z">$value[username]</a>
						<!--{if $space[self]}-->
							<span id="friend_note_$value[uid]">$value[note]</span>
						<!--{/if}-->
					</div>
					<div class="y ren-friend-in tu">
						<!--{if $_GET['view'] == 'blacklist'}-->
							<a href="home.php?mod=spacecp&ac=friend&op=blacklist&subop=delete&uid=$value[uid]&start=$_GET[start]" class="z dialog">{$rtj1009_lang['home035']}</a>
						<!--{else}-->
						<a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$value[uid]&handlekey=delfriendhk_{$value[uid]}" id="a_ignore_$key" class="z dialog">{lang delete}</a>
						<!--{/if}-->
						<!--{if isset($value['follow']) && $key != $_G['uid'] && $value[username] != ''}-->
						<a href="home.php?mod=spacecp&ac=follow&op={if $value['follow']}del{else}add{/if}&fuid=$value[uid]&hash={FORMHASH}&from=a_followmod_" id="a_followmod_$key" class="dialog tu z"><!--{if $value['follow']}-->{$rtj1009_lang['home011']}<!--{else}-->{$rtj1009_lang['home012']}<!--{/if}--></a>
						<!--{/if}-->
						<a href="home.php?mod=space&do=pm&subop=view&touid=$value[uid]" id="a_sendpm_$key" class="tu z">{lang send_pm}</a>
					</div>
				</div>
			</li>
		<!--{/loop}-->
		</ul>
		<!--{else}-->
		<div class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{lang no_friend_list}</span>
		</div>
		<!--{/if}-->
	</div>
<!-- main collectlist end --> 
$multi
</div>

<!--{eval $nofooter = true;}--> 
<!--{template common/footer}--> 

