<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
{eval
	$_G['home_tpl_titles'] = array($blog['subject'], '{lang blog}');
	$_G['home_tpl_spacemenus'][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=$do&view=me\">{lang they_blog}</a>";
	$_G['home_tpl_spacemenus'][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=blog&id=$blog[blogid]\">{lang view_blog}</a>";
	$friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');
}
<!--{template common/header}-->

<script type="text/javascript" src='template/rtj1009_app/js/ren_share.js'></script>

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span class="ren_bk_name">{$rtj1009_lang['home025']}</span>
		</div>
		<div class="ren_nav_right">
            <div class="ren_view_navgd open-popover"><span class="icon ren-font">&#xe677;</span></div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="ren_nav_gd popover">
	<div class="popover-angle on-top"></div>
	<div class="ren_gd_list close-popover cl">
		<a href="javascript:;" class="ren_viewdi_fx ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe613;</i><span>{$rtj1009_lang['ren089']}</span></a>
		<!--{if $_G[uid] == $blog[uid] || checkperm('manageblog')}-->
		<a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=delete&handlekey=delbloghk_{$blog[blogid]}" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_gd_jb close-popover"><i class="icon ren-font">&#xe64d;</i><span>{$rtj1009_lang['home026']}</span></a>
		<!--{/if}-->
		<!--{if $_G['uid'] != $blog['uid']}-->
		<a href="misc.php?mod=report&rtype=blog&uid=$blog[uid]&rid=$blog[blogid]" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_gd_jb close-popover"><i class="icon ren-font">&#xe66b;</i><span>{$rtj1009_lang['home027']}</span></a>
		<!--{/if}-->
		<a href="home.php?mod=spacecp&ac=favorite&type=blog&id=$blog[blogid]&spaceuid=$blog[uid]&handlekey=favoritebloghk_{$blog[blogid]}" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_gd_jb"><i class="icon ren-font">&#xe603;</i><span>{lang favorite}</span></a>
		<a href="home.php?mod=spacecp&ac=blog" class="ren_gd_fh close-popover"><i class="icon ren-font">&#xe62c;</i><span>{$rtj1009_lang['home028']}</span></a>
	</div>
</div>

<div class="content ren-view-main ren-view-b48">
	<div class="rtj1009_m_view ren-blog-view">
		<div class="ren_view_wztop">
			<h3 class="ph">$blog[subject]</h3>
			<div class="ren-blog-us">
				<a href="home.php?mod=space&uid=$blog[uid]&do=profile" class="ren_twus_img z cl">
					<!--{avatar($blog[uid],small)}-->
				</a>
				<div class="z ren_author">
					<a href="home.php?mod=space&uid=$blog[uid]&do=profile" class="ren_twus_name z cl">$blog[username]</a>
				</div>
				<div class="z ren_thread_sj">
					<span class="z ren_thread_dateline"><!--{date($blog[dateline])}--></span>
				</div>
				<div class="y ren-blog-in">
					<span class="ren_twsj_ck y"><i class="icon ren-font">&#xe660;</i><!--{if $blog[viewnum] > 0}-->$blog[viewnum]<!--{else}-->0<!--{/if}--></span>
                    <span class="ren_twsj_hf y"><i class="icon ren-font">&#xe694;</i><!--{if $blog[replynum] > 0}-->$blog[replynum]<!--{else}-->0<!--{/if}--></span>
				</div>

                <!--{if $_G[uid] == $blog[uid] || checkperm('manageblog')}-->
                <div class="y ren-blog-xn">
                    <a href="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]&op=delete&handlekey=delbloghk_{$blog[blogid]}" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_gd_jb close-popover">{$rtj1009_lang['home026']}</a>
                </div>
                <!--{/if}-->
			</div>

		</div>
		<div class="ren-blog-mn">
			<div id="blog_article" class="ren_wz_nr cl">
				<div class="message">
					$blog[message]
				</div>
			
			<!--{if $blog[tag]}-->
				<div class="ren-tag">
					<i class="icon ren-font">&#xe61d;</i>
					<!--{eval $tagi = 0;}-->
					<!--{loop $blog[tag] $var}-->
						<!--{if $tagi}--><span>, </span><!--{/if}--><a href="misc.php?mod=tag&id=$var[0]">$var[1]</a>
						<!--{eval $tagi++;}-->
					<!--{/loop}-->
				</div>
			<!--{/if}-->
			
			<!--{if $blog[friend] != 3 && !$blog[noreply]}-->
			<div id="click_div" class="ren_click">
				<!--{template home/space_click}-->
			</div>
			<!--{/if}-->
		</div>
		<div class="ren-blog-count cl">
			<div class="ren_lc_ks cl">
				<span class="ren_lc_ksy y">$blog[replynum]{$rtj1009_lang['home029']}</span> 
				<span class="ren_lc_ksz z">{$rtj1009_lang['home030']}</span>
			</div>
			<!--{if $count}-->
				<div class="ren-wall-list">
					<ul class="cl">
						<!--{loop $list $k $value}-->
						<!--{template home/space_comment_li}-->
						<!--{/loop}-->
					</ul>
					<div class="pgs cl">$multi</div>
				</div>
				<!--{else}-->
				<div class="ren_ss_wu">
					<i class="icon ren-font">&#xe608;</i>
					<span>{$rtj1009_lang['home021']}</span>
				</div>
			<!--{/if}-->
		</div>
	</div>
</div>

<!--{if !$blog[noreply] && helper_access::check_module('blog')}-->
<div class="ren_view_share ren_view_footer ren-wz-view">
	<a class="ren_viewdi_hf open-popup" data-popup=".popup-view"><span>{$rtj1009_lang['ren053']}</span></a>
	<a href="home.php?mod=spacecp&ac=favorite&type=blog&id=$blog[blogid]&spaceuid=$blog[uid]&handlekey=favoritebloghk_{$blog[blogid]}" class="<!--{if $_G[uid]}-->dialog <!--{else}-->ren-confirm <!--{/if}-->ren_twsj_sc"><i class="icon ren-font<!--{if $recommend}--> color<!--{/if}-->">&#xe603;</i></a>
	<a href="javascript:;" class="ren_share open-popup" data-popup=".popup-share"><i class="icon ren-font">&#xe742;</i></a>
</div>
<!--{/if}-->
<!--{if !$blog[noreply] && helper_access::check_module('blog')}-->
<div class="popup popup-view">
	<header class="bar bar-nav popup-view-nav">
		<div class="ren_nav cl"> <a href="javascript:;" class="z ren-fh close-popup"><i class="icon ren-font">&#xe64d;</i></a>
			<div class="ren_top_dqwz z"> <span>{$rtj1009_lang['home022']}</span> </div>
		</div>
	</header>
	<div class="content-block">
		<div class="ren_lostpw">
			<div class="ren_kshf cl"> 
				<form id="quickcommentform_{$id}" action="home.php?mod=spacecp&ac=comment" method="post" autocomplete="off" onsubmit="ajaxpost('quickcommentform_{$id}', 'return_qcblog_$id');doane(event);">
					<div class="ren_post_pi cl">
						<div class="ren_post_nr cl">
							<textarea id="comment_message" placeholder="{$rtj1009_lang['ren053']}" name="message" rows="5" class="ren_post_nrk"></textarea>
						</div>
						<div class="ren_post_tj">
							<input type="hidden" name="referer" value="home.php?mod=space&uid=$blog[uid]&do=$do&id=$id" />
							<input type="hidden" name="id" value="$id" />
							<input type="hidden" name="idtype" value="blogid" />
							<input type="hidden" name="handlekey" value="qcblog_{$id}" />
							<input type="hidden" name="commentsubmit" value="true" />
							<input type="hidden" name="quickcomment" value="true" />
							<a href="javascript:void(0)" class="wall_face"><i class="icon ren-font">&#xe615;</i></a>
							<div id="commentsubmit_btn" class="post_fast">
								<button type="submit" name="commentsubmit_btn" value="true" id="commentsubmit_btn" class="ren_post_tjan">{lang comment}</button>
							</div>
							<span id="return_qcwall_{$space[uid]}"></span>
						</div>
						<!--{if $secqaacheck || $seccodecheck}--><!--{subtemplate common/seccheck}--><!--{/if}-->
						<input type="hidden" name="formhash" value="{FORMHASH}" />
					</div>
				</form>
				<script type="text/javascript" src="template/rtj1009_app/js/home.face.js"></script>
				<div id="Home_FaceBox"></div>
				<script type="text/javascript">
					$(function (){
						$("a.wall_face").HomeFaceBox({
							Event : "click",	//�����¼�	
							divid : "Home_FaceBox", //���DIV ID
							textid : "comment_message" //�ı��� ID
						});
					});
					
					$('#Smohan_Showface').click(function(){
						$('#Zones').fadeIn(360);
						$('#Zones').html($('#Smohan_text').val());
						$('#Zones').replaceface($('#Zones').html());
					});
				</script> 
			</div>
		</div>
	</div>
</div>
<!--{/if}-->

<script type="text/javascript">
    $('.ren_share').ready(function(){
        var share = new ren_share({
            title : document.title,
            url   : window.location.href,
            desc  : document.getElementsByName('description')[0].content,
            img   : '$ren_wx_imgUrl',
        });
        $('.ren_share').click(function () {
            share.init(0,'.ren_view_share');
        });
    });
</script>
<div id="popup-share" class="popup popup-share">
    <div class="content-block">
        <div class="ren_tiefx_share">
            <div class="bdsharebuttonbox">
                <a href="javascript:;" class="popup_sqq" data-cmd="sqq"><p>{$rtj1009_lang['ren100']}</p></a>
                <a href="javascript:;" class="bds_qzone" data-cmd="qzone"><p>{$rtj1009_lang['ren101']}</p></a>
                <a href="javascript:;" class="bds_tsina" data-cmd="tsina"><p>{$rtj1009_lang['ren102']}</p></a>
                <a href="javascript:;" class="bds_weixin" data-cmd="weixin"><p>{$rtj1009_lang['ren103']}</p></a>
                <a href="javascript:;" class="bds_copy" data-cmd="copy"><p>{$rtj1009_lang['ren212']}</p></a>
            </div>
        </div>
    </div>
    <a href="javascript:;" class="ren_tiefx_qx close-popup">{$rtj1009_lang['ren012']}</a>
</div>



<!--{template common/footer}-->
