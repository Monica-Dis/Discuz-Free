<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');}-->
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header<!--{if $diymode && $rtj1009_m_config['ren_menu_nav'] ==2}--> ren-menu-header<!--{/if}-->">
	<div class="ren_nav cl">
		<a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z"><span class="ren_bk_name"><!--{if $diymode}-->{$rtj1009_lang['home013']}<!--{else}-->{$rtj1009_lang['home014']}<!--{/if}--></span></div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
	</div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content<!--{if $diymode && $rtj1009_m_config['ren_menu_nav'] ==2}--> p-t-0<!--{/if}--> p-b-0">
<!--{if $diymode}-->
	<!--{template home/space_menu}-->
<!--{else}-->
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
			<a $actives[me] href="home.php?mod=space&do=album&view=me">{$rtj1009_lang['home015']}</a>
			<a $actives[we] href="home.php?mod=space&do=album&view=we">{$rtj1009_lang['home016']}</a>
			<a $actives[all] href="home.php?mod=space&do=album&view=all">{lang view_all}</a>
            <a <!--{if $_GET['ac'] == 'upload'}-->class="a"<!--{/if}-->href="home.php?mod=spacecp&ac=upload">{lang upload_pic}</a>
		</div>
	</div>
<!--{/if}-->
		<div class="ren-album-list">
		<!--{if $count}-->
			<ul class="cl">
				<!--{loop $list $key $value}-->
				<!--{eval $pwdkey = 'view_pwd_album_'.$value['albumid'];}-->
				<li>
					<div class="ren-album-pic c">
						<a href="home.php?mod=space&uid=$value[uid]&do=album&id=$value[albumid]">
							<!--{if $value[pic]}--><img src="$value[pic]"/><!--{/if}-->
							<p><!--{if $value[albumname]}-->$value[albumname]<!--{else}-->{lang default_album}<!--{/if}--></p>
							<!--{if $value[picnum]}--><span><i class="icon ren-font">&#xe64c;</i> $value[picnum]</span><!--{/if}-->
						</a>
					</div>
				</li>
				<!--{/loop}-->
			</ul>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
		<!--{else}-->
			<div class="ren_ss_wu">
				<i class="icon ren-font">&#xe608;</i>
				<span>{lang no_album}</span>
			</div>
		<!--{/if}-->
		</div>
</div>

<!--{template common/footer}-->
