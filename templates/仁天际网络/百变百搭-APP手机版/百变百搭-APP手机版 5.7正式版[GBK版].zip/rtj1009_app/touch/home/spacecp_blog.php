<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if $_GET[op] == 'delete'}-->
<div class="tip">
<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&op=delete&blogid=$blogid">
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="deletesubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<dt>{lang sure_delete_blog}?</dt>
	<dd>
		<input type="submit" name="deletesubmitbtn" value="{lang determine}" class="formdialog button2 color">
		<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
	</dd>
</form>
</div>
<!--{elseif $_GET[op] == 'stick'}-->
<div class="tip">
<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&op=stick&blogid=$blogid">
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="sticksubmit" value="true" />
	<input type="hidden" name="stickflag" value="$stickflag" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<dt><!--{if $stickflag}-->{lang sure_stick_blog}<!--{else}-->{lang sure_cancel_stick_blog}<!--{/if}-->?</dt>
	<dd>
		<input type="submit" name="btnsubmit" value="{lang determine}" class="formdialog button2 color">
		<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
	</dd>
</form>
</div>
<!--{elseif $_GET[op] == 'addoption'}-->
<div class="tip">
	<dt><label for="newsort">{lang name}: <input type="text" name="newsort" id="newsort" class="px" size="30" /></label></dt>
	<dd>
		<input type="submit" name="btnsubmit" value="{lang create}" class="formdialog button2 color">
		<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
	</dd>
</div>
<!--{elseif $_GET[op] == 'edithot'}-->
<div class="tip">
<form method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&op=edithot&blogid=$blogid">
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="hotsubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<dt><input type="text" name="hot" value="$blog[hot]" size="10" class="px" /></dt>
	<dd>
		<input type="submit" name="btnsubmit" value="{lang determine}" class="formdialog button2 color">
		<a href="javascript:;" onclick="popup.close();" >{lang cancel}</a>
	</dd>
</form>
</div>
<!--{else}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm"><!--{if $blog[blogid]}-->{lang edit_blog}<!--{else}-->{lang memcp_blog}<!--{/if}-->
			</span>
		</div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content ren-post-blog">
	<div class="rtj1009_post rtj1009_m_main cl">
		<script type="text/javascript" src="{$_G[setting][jspath]}home_blog.js?{VERHASH}"></script>
		<form id="ttHtmlEditor" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=blog&blogid=$blog[blogid]{if $_GET[modblogkey]}&modblogkey=$_GET[modblogkey]{/if}" enctype="multipart/form-data">
		<div class="post_from ren_post_list cl">
			<ul class="cl">
				<li class="ren_bl_li">
					<div class="ren-post-btlabel">{lang thread_subject}</div>
					<div class="ren-post-btxx">
						<input type="text" id="subject" name="subject" value="$blog[subject]" placeholder="{$rtj1009_lang['ren073']}"/>
					</div>
				</li>
				<li class="ren_bl_no">
				    <textarea class="pt" name="message" id="uchome-ttHtmlEditor" cols="80" rows="2" placeholder="{$rtj1009_lang['ren053']}">$blog[message]</textarea>
				</li>
			</ul>
			<ul id="imglist" class="ren_post_imglist cl">
				<li class="ren_bl_fj">
					<a href="javascript:;" class="ren_bl_fjy">
						<i class="icon ren-font">&#xe60d;</i>
						<input type="file" name="Filedata" id="filedata"/>
					</a>
				</li>
			</ul>
			<div class="kong"></div>
			<div class="ren_fb_hd cl">
				<div class="ren_fb_hdxxs">
					<ul>
                        <!--{if $_G['setting']['blogcategorystat'] && $categoryselect}-->
                        <li class="ren_hdxx_li ren_hdxx_de">
                            <div class="ren_hdxx_lx">{lang site_categories}</div>
                            <div class="ren_hdxx_lxnr ren-webki">
                                $categoryselect
                            </div>
                        </li>
                        <!--{/if}-->
						<li class="ren_hdxx_li ren_hdxx_de">
							<div class="ren_hdxx_lx">{lang personal_category}</div>
							<div class="ren_hdxx_lxnr ren-webki">
								<select name="classid" id="classid" onchange="addSort(this)" >
									<option value="0">------</option>
									<!--{loop $classarr $value}-->
									<!--{if $value['classid'] == $blog['classid']}-->
									<option value="$value[classid]" selected>$value[classname]</option>
									<!--{else}-->
									<option value="$value[classid]">$value[classname]</option>
									<!--{/if}-->
									<!--{/loop}-->
									<!--{if !$blog['uid'] || $blog['uid']==$_G['uid']}--><option value="addoption" style="color:red;">+{lang create_new_categories}</option><!--{/if}-->
								</select>
							</div>
						</li>

                        <li id="addoptiontet" class="ren_hdxx_li ren_hdxx_de" style="display: none;">
                            <div class="ren_hdxx_lxnr">
                                <input type="text" name="newsort" id="newsort" placeholder="{$rtj1009_lang['home139']}" class="px" size="30" />
                            </div>
                            <div class="ren-de-edsbtn ren-blog-postbtn cl">
                                <button type="button" name="btnsubmit" value="true" class="pn" onclick="blogAddOption('newsort', 'classid')">{lang create}</button>
                            </div>
                        </li>
						<li class="ren_hdxx_li ren_hdxx_de">
							<div class="ren_hdxx_lx">{lang privacy_settings}</div>
							<div class="ren_hdxx_lxnr ren-webki">
								<select id="friend" name="friend" onchange="passwordShow(this.value);">
									<option value="0"$friendarr[0]>{lang friendname_0}</option>
									<option value="1"$friendarr[1]>{lang friendname_1}</option>
									<option value="2"$friendarr[2]>{lang friendname_2}</option>
									<option value="3"$friendarr[3]>{lang friendname_3}</option>
									<option value="4"$friendarr[4]>{lang friendname_4}</option>
								</select>
							</div>
						</li>
                        <li id="span_password" class="ren_hdxx_li ren_hdxx_de" style="$passwordstyle">
                            <div class="ren_hdxx_lx">{lang password}</div>
                            <div class="ren_hdxx_lxnr">
                                <input type="text" name="password" value="$blog[password]" size="10" onkeyup="value=value.replace(/[^\w\.\/]/ig,'')" class="px" />
                            </div>
                        </li>


						<li class="ren_hdxx_li ren_hdxx_de">
							<div class="ren_hdxx_lx">{lang label}</div>
							<div class="ren_hdxx_lxnr">
								<input type="text" class="px oinf" size="40" id="tag" name="tag" value="$blog[tag]" />
							</div>
						</li>
						<li class="ren_hdxx_li ren_spxx_de">
							<div class="ren_hdxx_lx">{lang comments_not_allowed}</div>
							<div class="item-inner ren-sendreasonpm">
								<div class="item-input">
									<label for="overt" class="label-switch">
									<input type="checkbox" name="noreply" value="1"{if $blog[noreply]} checked="checked"{/if} />
										<div class="checkbox"></div>
									</label>
								</div>
							</div>
						</li>
						<li class="ren_hdxx_li ren_spxx_de">
							<div class="ren_hdxx_lx">{lang make_feed}</div>
							<div class="item-inner ren-sendreasonpm">
								<div class="item-input">
									<label for="makefeed" class="label-switch">
									<input type="checkbox" name="makefeed" id="makefeed" value="1" class="pc"{if ckprivacy('blog', 'feed')} checked="checked"{/if}/>
										<div class="checkbox"></div>
									</label>

								</div>
							</div>
						</li>
					</ul>
				</div>
			</div>
			<!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
			<!--{subtemplate common/seccheck}-->
			<!--{/if}-->
			<!--{hook/post_bottom_mobile}-->
		</div>
		<span class="ren_ft_anniu">
			<button type="submit" id="issuance" class="ren_ft_an">{lang save_publish}</button>
		</span>
		<input type="hidden" name="blogsubmit" value="true" />
		<input type="hidden" name="formhash" value="{FORMHASH}" />
	</form>
        <script type="text/javascript">
            function addSort(obj) {
                if (obj.value == 'addoption') {
                    $('#addoptiontet').css('display', 'block');
                    $('#newsort').focus();
                }
            }

            function blogAddOption(sid, aid) {
                var obj = document.getElementById(aid);
                var newOption = document.getElementById(sid).value;
                newOption = newOption.replace(/^\s+|\s+$/g,"");
                $(sid).value = "";
                if (newOption!=null && newOption!='') {
                    var newOptionTag=document.createElement('option');
                    newOptionTag.text=newOption;
                    newOptionTag.value="new:" + newOption;
                    try {
                        obj.add(newOptionTag, obj.options[0]);
                    } catch(ex) {
                        obj.add(newOptionTag, obj.selecedIndex);
                    }
                    obj.value="new:" + newOption;
                    return true;
                } else {
                    popup.open('{$rtj1009_lang[home140]}', 'alert');
                    return false;
                }
            }

            function passwordShow(value) {
                if(value==4) {
                    $('#span_password').css('display','');
                } else if(value==2) {
                    $('#span_password').css('display','none');
                } else {
                    $('#span_password').css('display','none');
                }
            }

        </script>
	<script type="text/javascript" src="{STATICURL}js/mobile/ajaxfileupload.js?{VERHASH}"></script>
	<script type="text/javascript" src="{STATICURL}js/mobile/buildfileupload.js?{VERHASH}"></script>
	<script type="text/javascript">
		var imgexts = typeof imgexts == 'undefined' ? 'jpg, jpeg, gif, png' : imgexts;
		var STATUSMSG = {
			'-1' : '{lang uploadstatusmsgnag1}',
			'0' : '{lang uploadstatusmsg0}',
			'1' : '{lang uploadstatusmsg1}',
			'2' : '{lang uploadstatusmsg2}',
			'3' : '{lang uploadstatusmsg3}',
			'4' : '{lang uploadstatusmsg4}',
			'5' : '{lang uploadstatusmsg5}',
			'6' : '{lang uploadstatusmsg6}',
			'7' : '{lang uploadstatusmsg7}(' + imgexts + ')',
			'8' : '{lang uploadstatusmsg8}',
			'9' : '{lang uploadstatusmsg9}',
			'10' : '{lang uploadstatusmsg10}',
			'11' : '{lang uploadstatusmsg11}'
		};
		var form = $('#postform');
		$(document).on('change', '#filedata', 
		function() {
				popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
	
				uploadsuccess = function(data) {
					if(data == '') {
						popup.open('{lang uploadpicfailed}', 'alert');
					}
					var dataarr = new Function('return' + data)();
     				if (dataarr.bigimg != '') {
						popup.close();
						$('#imglist').append('<li><span aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a href="javascript:;"><img style="height:60px;width:60px;" id="aimg_'+dataarr.picid+'" src="'+dataarr.bigimg+'" /></a></span><input type="hidden" name="picids[' + dataarr.picid + ']" value="'+dataarr['picid']+'"/></li>');
					} else {
						var sizelimit = '';
						if(dataarr[7] == 'ban') {
							sizelimit = '{lang uploadpicatttypeban}';
						} else if(dataarr[7] == 'perday') {
							sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
						} else if(dataarr[7] > 0) {
							sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
						}
						popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
					}
				};
				
				if(typeof FileReader != 'undefined' && this.files[0]) {//note ֧��html5�ϴ�������
					
					$.buildfileupload({
						uploadurl:'misc.php?mod=swfupload&operation=album&inajax=yes&infloat=yes',
						files:this.files,
						uploadformdata:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
						uploadinputname:'Filedata',
						maxfilesize:"$swfconfig[max]",
						success:uploadsuccess,
						error:function() {
							popup.open('{lang uploadpicfailed}', 'alert');
						}
					});
	
				} else {
	
					$.ajaxfileupload({
						url:'misc.php?mod=swfupload&operation=album&inajax=yes&infloat=yes',
						data:{uid:"$_G[uid]", hash:"<!--{eval echo md5(substr(md5($_G[config][security][authkey]), 8).$_G[uid])}-->"},
						dataType:'text',
						fileElementId:'filedata',
						success:uploadsuccess,
						error: function() {
							popup.open('{lang uploadpicfailed}', 'alert');
						}
					});
	
				}
		});

        $(document).on('click', '.del', function() {
			var obj = $(this);
			$.ajax({
				type:'GET',
				url:'forum.php?mod=ajax&action=deleteattach&inajax=yes&aids[]=' + obj.attr('aid'),
			})
			.success(function(s) {
				obj.parent().remove();
			})
			.error(function() {
				popup.open('{lang networkerror}', 'alert');
			});
			return false;
		});
	
	</script>

	</div>
</div>
	

<!--{/if}-->
<!--{template common/footer}-->
