<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !$_GET['mycenter']}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{$rtj1009_lang['home069']}</span>
		</div>
        <div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content p-b-0 11">
    <div class="rtj1009_post rtj1009_m_main cl">
        <form id="pmform_{$pmid}" name="pmform_{$pmid}" method="post" autocomplete="off" action="home.php?mod=spacecp&ac=pm&op=send&touid=$touid&pmid=$pmid&mobile=2" >
            <input type="hidden" name="referer" value="{echo dreferer();}" />
            <input type="hidden" name="pmsubmit" value="true" />
            <input type="hidden" name="formhash" value="{FORMHASH}" />
        <!-- main post_msg_box start -->
            <div class="post_from ren_post_list cl">
                <ul class="cl">
                    <!--{if !$touid}-->
                    <li class="ren_bl_li">
                        <div class="ren-post-btlabel">{lang addressee}</div>
                        <div class="ren-post-btxx">
                            <input type="text" value="" tabindex="1" class="px" size="30" autocomplete="off" id="username" name="username" placeholder="{$rtj1009_lang['home126']}">
                        </div>
                    </li>
                    <li class="post_msg_fxx"><div class="ren_tie_ksf">{lang thread_content}</div></li>
                    <!--{/if}-->
                    <li class="ren_bl_no">
                        <textarea class="pt" tabindex="2" autocomplete="off" value="" id="sendmessage" name="message" cols="80" rows="4" placeholder="{$rtj1009_lang['ren053']}"></textarea>
                    </li>
                </ul>
            </div>
            <div class="ren_ft_anniu">
                <button type="submit" id="pmsubmit_btn" class="ren_btn_pn ren_ft_an ren_btn_pn_blue">{lang sendpm}</button>
            </div>
            <input type="hidden" name="pmsubmit_btn" value="yes" />
        <!-- main postbox start -->
        </form>
    </div>
</div>
<script type="text/javascript">
	(function() {
		$('#sendmessage').on('keyup input', function() {
			var obj = $(this);
			if(obj.val()) {
				$('.ren_btn_pn').removeClass('btn_pn_grey').addClass('ren_btn_pn_blue');
				$('.ren_btn_pn').attr('disable', 'false');
			} else {
				$('.ren_btn_pn').removeClass('ren_btn_pn_blue').addClass('btn_pn_grey');
				$('.ren_btn_pn').attr('disable', 'true');
			}
		});
		var form = $('#pmform_{$pmid}');
		$('#pmsubmit_btn').on('click', function() {
			var obj = $(this);
			if(obj.attr('disable') == 'true') {
				return false;
			}
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey='+form.attr('id')+'&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				popup.open(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				popup.open('{lang networkerror}', 'alert');
			});
			return false;
			});
	 })();
</script>

<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->


