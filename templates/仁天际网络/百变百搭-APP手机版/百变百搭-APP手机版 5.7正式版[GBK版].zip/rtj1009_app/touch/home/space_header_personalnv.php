<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_G['adminid'] == 1 && empty($space['self'])}-->
<!--{eval $personalnv['items'] = array(); $personalnv['banitems'] = array(); $personalnv['nvhidden'] = 0;}-->
<!--{/if}-->
<!--{eval $nvclass = !empty($personalnv['nvhidden']) ? ' class="mininv"' : '';}-->
<div id="nv">
	<ul$nvclass>
		<!--{if empty($personalnv['nvhidden'])}-->
			<!--{if empty($personalnv['banitems']['index'])}-->
				<!--{if $_G['adminid'] == 1 && $_G['setting']['allowquickviewprofile'] == 1}-->
					<li><a href="home.php?mod=space&uid=$space[uid]&do=index&view=admin"><!--{if !empty($personalnv['items']['index'])}-->$personalnv['items']['index']<!--{else}-->{lang main_page}<!--{/if}--></a></li>
				<!--{else}-->
					<li><a href="home.php?mod=space&uid=$space[uid]&do=index"><!--{if !empty($personalnv['items']['index'])}-->$personalnv['items']['index']<!--{else}-->{lang main_page}<!--{/if}--></a></li>
				<!--{/if}-->
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['feed']) && helper_access::check_module('feed')}-->
			<li><a href="home.php?mod=space&uid=$space[uid]&do=home&view=me&from=space"><!--{if !empty($personalnv['items']['feed'])}-->$personalnv['items']['feed']<!--{else}-->{lang feed}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['doing']) && helper_access::check_module('doing')}-->
			<li><a href="home.php?mod=space&uid=$space[uid]&do=doing&view=me&from=space"><!--{if !empty($personalnv['items']['doing'])}-->$personalnv['items']['doing']<!--{else}-->{lang doing}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['blog']) && helper_access::check_module('blog')}-->
			<li><a href="home.php?mod=space&uid=$space[uid]&do=blog&view=me&from=space"><!--{if !empty($personalnv['items']['blog'])}-->$personalnv['items']['blog']<!--{else}-->{lang blog}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['album']) && helper_access::check_module('album')}-->
			<li><a href="home.php?mod=space&uid=$space[uid]&do=album&view=me&from=space"><!--{if !empty($personalnv['items']['album'])}-->$personalnv['items']['album']<!--{else}-->{lang album}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['follow']) && helper_access::check_module('follow')}-->
			<li><a href="home.php?mod=follow&uid=$space[uid]&do=view"><!--{if !empty($personalnv['items']['follow'])}-->$personalnv['items']['follow']<!--{else}-->{lang follow}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if $_G['setting']['allowviewuserthread'] !== false && (empty($personalnv['banitems']['topic']))}-->
			<li><a href="home.php?mod=space&uid=$space[uid]&do=thread&view=me&from=space"><!--{if !empty($personalnv['items']['topic'])}-->$personalnv['items']['topic']<!--{else}-->{lang topic}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['share']) && helper_access::check_module('share')}-->
			<li><a href="home.php?mod=space&uid=$space[uid]&do=share&view=me&from=space"><!--{if !empty($personalnv['items']['share'])}-->$personalnv['items']['share']<!--{else}-->{lang share}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['wall']) && helper_access::check_module('wall')}-->
			<li><a href="home.php?mod=space&uid=$space[uid]&do=wall"><!--{if !empty($personalnv['items']['wall'])}-->$personalnv['items']['wall']<!--{else}-->{lang message_board}<!--{/if}--></a></li>
			<!--{/if}-->
			<!--{if empty($personalnv['banitems']['profile'])}-->
			<li><a href="home.php?mod=space&uid=$space[uid]&do=profile"><!--{if !empty($personalnv['items']['profile'])}-->$personalnv['items']['profile']<!--{else}-->{lang memcp_profile}<!--{/if}--></a></li>
			<!--{/if}-->
		<!--{/if}-->
	</ul>
</div>
