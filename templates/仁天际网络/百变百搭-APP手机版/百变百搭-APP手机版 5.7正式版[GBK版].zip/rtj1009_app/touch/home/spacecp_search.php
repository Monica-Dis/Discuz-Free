<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_grkj z">
            <span class="ren_bk_name ren_vm">
            {lang search_friend}
            </span>
        </div>
        <div class="ren_nav_right open-panel">
            <div class="ren_btn">
                <span><span class="ren_nav_icon"><span></span></span></span>
            </div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content ren-post-blog">
    <div class="rtj1009_post rtj1009_m_main cl">
			<!--{if !empty($_GET['searchsubmit'])}-->
				<!--{if empty($list)}-->
        <div class="ren_ss_wu">
            <i class="icon ren-font">&#xe608;</i>
            <span>{lang no_search_friend}</span>
        </div>
				<!--{else}-->
					<div class="ren_mm_top cl"><span class="ren_mm_xgts cl">{$rtj1009_lang['home132']}</span></div>
					<!--{template home/space_list}-->
				<!--{/if}-->
			<!--{else}-->
				<!--{if $_GET['op'] == 'sex'}-->
						<form action="home.php" method="get" accept-charset="gbk">
                            <div class="post_from ren_post_list cl">
                                <div class="ren_fb_hd cl">
                                    <div class="ren_fb_hdxxs">
                                        <ul>
                                            <li class="ren_hdxx_li ren_hdxx_de">
                                                <div class="ren_hdxx_lx">{lang username}</div>
                                                <div class="ren_hdxx_lxnr">
                                                    <input type="text" name="username" value="" class="px" />
                                                </div>
                                            </li>

                                            <li class="ren_hdxx_li ren_hdxx_de">
                                                <div class="ren_hdxx_lx">{lang sex}</div>
                                                <div class="ren_hdxx_lxnr ren-webki">
                                                    <select id="friend" name="friend">
                                                        <option value="0">{lang random}</option>
                                                        <option value="1">{lang male}</option>
                                                        <option value="2">{lang female}</option>
                                                    </select>
                                                </div>
                                            </li>
                                            <li class="ren_hdxx_li ren_hdxx_de">
                                                <div class="ren_hdxx_lx">{lang age_segment}</div>
                                                <div class="ren_hdxx_lxnr">
                                                    <input type="text" name="startage" value="" size="10" class="px" style="width: 114px;" /> ~ <input type="text" name="endage" value="" size="10" class="px" style="width: 114px;" />
                                                </div>
                                            </li>
                                            <li class="ren_hdxx_li ren_spxx_de">
                                                <div class="ren_hdxx_lx">{lang upload_avatar}</div>
                                                <div class="item-inner ren-sendreasonpm">
                                                    <div class="item-input">
                                                        <label for="overt" class="label-switch">
                                                            <input type="checkbox" name="avatarstatus" value="1" />
                                                            <div class="checkbox"></div>
                                                        </label>
                                                    </div>
                                                </div>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
							</div>

                            <span class="ren_ft_anniu">
                                <input type="hidden" name="searchsubmit" value="true" />
                                <button type="submit" class="ren_ft_an">{lang seek}</button>
                            </span>
							<input type="hidden" name="op" value="$_GET[op]" />
							<input type="hidden" name="mod" value="spacecp" />
							<input type="hidden" name="ac" value="search" />
							<input type="hidden" name="type" value="base" />
						</form>
				<!--{else}-->
					<form action="home.php" method="get" accept-charset="gbk">
                        <div class="post_from ren_post_list cl">
                            <div class="ren_fb_hd cl">
                                <div class="ren_fb_hdxxs">
                                    <ul>
                                        <li class="ren_hdxx_li ren_hdxx_de">
                                            <div class="ren_hdxx_lx">{lang username}</div>
                                            <div class="ren_hdxx_lxnr">
                                                <input type="text" name="username" value="" class="px" />
                                            </div>
                                        </li>

                                        <li class="ren_hdxx_li ren_hdxx_de">
                                            <div class="ren_hdxx_lx">{lang sex}</div>
                                            <div class="ren_hdxx_lxnr ren-webki">
                                                <select id="friend" name="friend">
                                                    <option value="0">{lang random}</option>
                                                    <option value="1">{lang male}</option>
                                                    <option value="2">{lang female}</option>
                                                </select>
                                            </div>
                                        </li>
                                        <li class="ren_hdxx_li ren_hdxx_de">
                                            <div class="ren_hdxx_lx">{lang age_segment}</div>
                                            <div class="ren_hdxx_lxnr">
                                                <input type="text" name="startage" value="" size="10" class="px" style="width: 114px;" /> ~ <input type="text" name="endage" value="" size="10" class="px" style="width: 114px;" />
                                            </div>
                                        </li>
                                        <li class="ren_hdxx_li ren_spxx_de">
                                            <div class="ren_hdxx_lx">{lang upload_avatar}</div>
                                            <div class="item-inner ren-sendreasonpm">
                                                <div class="item-input">
                                                    <label for="overt" class="label-switch">
                                                        <input type="checkbox" name="avatarstatus" value="1" />
                                                        <div class="checkbox"></div>
                                                    </label>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <span class="ren_ft_anniu">
            <input type="hidden" name="searchsubmit" value="true" />
            <button type="submit" class="ren_ft_an">{lang seek}</button>
        </span>
						<input type="hidden" name="op" value="$_GET[op]" />
						<input type="hidden" name="mod" value="spacecp" />
						<input type="hidden" name="ac" value="search" />
						<input type="hidden" name="type" value="all" />
					</form>
				</div>
				<!--{/if}-->
			<!--{/if}-->
	</div>
</div>
<!--{template common/footer}-->
