<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
{eval
	$_G[home_tpl_spacemenus][] = "<a href=\"home.php?mod=space&uid=$space[uid]&do=blog&view=me\">{lang they_blog}</a>";
	$friendsname = array(1 => '{lang friendname_1}',2 => '{lang friendname_2}',3 => '{lang friendname_3}',4 => '{lang friendname_4}');
}
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header<!--{if $diymode && $rtj1009_m_config['ren_menu_nav'] ==2}--> ren-menu-header<!--{/if}-->">
	<div class="ren_nav cl"> <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z"><span class="ren_bk_name">{lang blog}</span></div>
		<div class="y ren_list_nav">
			<a href="home.php?mod=spacecp&ac=blog" class="ren_nav_fb"><span class="icon ren-font">&#xe619;</span></a>
			<a href="search.php?mod=blog" class="ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
		</div>
	</div>
</header>
<!-- header end --> 
<!--{/if}-->
<div class="content<!--{if $diymode && $rtj1009_m_config['ren_menu_nav'] ==2}--> p-t-0<!--{/if}-->">
<!--{if $diymode}-->
	<!--{template home/space_menu}-->
<!--{else}-->
	<div class="rtj1009_p_nav">
		<div class="ren_p_nav">
			<a href="home.php?mod=space&do=blog&view=me" $actives[me]>{lang my_blog}</a>
			<a href="home.php?mod=space&do=blog&view=we" $actives[we]>{lang friend_blog}</a>
			<a href="home.php?mod=space&do=blog&view=all" $actives[all]>{lang view_all}</a>
		</div>
	</div>
<!--{/if}-->
		<!--{if $count}-->
		<div class="ren_tie_list ren-blog-list">
			<ul class="ren_list cl">
			<!--{loop $list $k $value}-->
				<li>
					<div class="ren_twsj ren_list_tu">
						<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="ren_twus_img z cl">
							<!--{avatar($value[uid],small)}-->
						</a>
						<div class="z ren_author">
							<a href="home.php?mod=space&uid=$value[uid]&do=profile" class="ren_twus_name z cl">$value[username]</a>
						</div>
						<div class="z ren_thread_sj"> <span class="z ren_thread_dateline">{$rtj1009_lang['home024']} $value[dateline]</span> </div>
						<div class="y ren-blog-in">
							<span class="ren_twsj_ck y"><i class="icon ren-font">&#xe660;</i><!--{if $value[viewnum] > 0}-->$value[viewnum]<!--{else}-->0<!--{/if}--></span>
							<span class="ren_twsj_hf y"><i class="icon ren-font">&#xe694;</i><!--{if $value[replynum] > 0}-->$value[replynum]<!--{else}-->0<!--{/if}--></span>
						</div>
					</div>
					<div class="ren_twbt tu">
						<a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]">$value[subject]</a>
					</div>
					<div class="forum_message">
					 <!--{if $value[pic]}-->
						<a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="y ren-blog-pic">
							<span><img src="$value[pic]" alt="$value[subject]" class="vm" /></span>
						</a>
					<!--{/if}-->
						<a href="home.php?mod=space&uid=$value[uid]&do=blog&id=$value[blogid]" class="ren-blog-message"><!--{echo cutstr($value[message],136)}--></a>
					 </div>
				</li>
			<!--{/loop}-->
			</ul>
		</div>
			<!--{if $multi}--><div class="pgs cl mtm">$multi</div><!--{/if}-->
		<!--{else}-->
			<div class="ren_ss_wu tu">
				<i class="icon ren-font">&#xe608;</i>
				<span>{lang no_related_blog}</span>
			</div>
		<!--{/if}-->
</div>

<!--{template common/footer}-->
