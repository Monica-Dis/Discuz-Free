<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
	$_G['home_tpl_titles'] = array('{lang magic}');
}-->
<!--{template common/header}-->
<div class="tip ren-rate-tip ren-magic-tip">
    <form id="magicform" method="post" action="home.php?mod=magic&action=shop&infloat=yes"{if $_G[inajax]} onsubmit="ajaxpost('magicform', 'return_$_GET[handlekey]', 'return_$_GET[handlekey]', 'onerror');return false;"{/if}>

    <div class="ren-rate-nav cl">
        <a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
        <div class="ren-post-nav cl">
            <div class="ren-post-wall">
                <span id="return_$_GET[handlekey]">
                    <!--{if $operation == 'buy'}-->
                    {lang magics_operation_buy}{lang magic}
                    <!--{elseif $operation == 'give'}-->
                    {lang magics_operation_present}{lang magic}
                    <!--{/if}-->
                </span>
            </div>
        </div>
        <a href="home.php?mod=space&uid=$post[authorid]&do=profile" class="ren-rate-author">
            <img src="$magic[pic]" alt="" />
            <p>$magic[name]</p>
        </a>
        <p>$magic[description]</p>
    </div>

    <div class="list-block ren-stick-block">
        <ul class="c">
            <input type="hidden" name="formhash" value="{FORMHASH}" />
            <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET[handlekey]" /><!--{/if}-->
            <input type="hidden" name="operation" value="$operation" />
            <input type="hidden" name="mid" value="$_GET['mid']" />
            <!--{if !empty($_GET['idtype']) && !empty($_GET['id'])}-->
                <input type="hidden" name="idtype" value="$_GET[idtype]" />
                <input type="hidden" name="id" value="$_GET[id]" />
            <!--{/if}-->
            <!--{if $operation == 'buy'}-->
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang magics_price}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $magic[price] {$_G['setting']['extcredits'][$magic[credit]][unit]} {$_G['setting']['extcredits'][$magic[credit]][title]}
                        </div>
                    </div>
                </div>
            </li>
            <!--{if $magic[discountprice] && $magic[price] != $magic[discountprice]}-->
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang magics_discountprice}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $magic[discountprice] $_G['setting']['extcredits'][$magic[credit]][unit] {$_G['setting']['extcredits'][$magic[credit]][title]}
                        </div>
                    </div>
                </div>
            </li>
            <!--{/if}-->
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang magics_yourcredit}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            <!--{echo getuserprofile('extcredits'.$magic[credit])}--> {$_G['setting']['extcredits'][$magic[credit]][unit]}
                        </div>
                    </div>
                </div>
            </li>
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang magics_weight}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $magic[weight]
                        </div>
                    </div>
                </div>
            </li>
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang my_magic_volume}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $allowweight
                        </div>
                    </div>
                </div>
            </li>
            <li class="ren-usgroup-gmli">
                <div class="item-content">
                    <div class="item-media">{lang stock}</div>
                    <div class="item-inner">
                        <div class="item-input color">
                            $magic[num] {lang magics_unit}
                        </div>
                    </div>
                </div>
            </li>
            <!--{if $useperoid !== true}-->
            <li class="ren-usgroup-tsli">
                <p>
                    <!--{if $magic['useperoid'] == 1}-->{lang magics_outofperoid_1}<!--{elseif $magic['useperoid'] == 2}-->{lang magics_outofperoid_2}<!--{elseif $magic['useperoid'] == 3}-->{lang magics_outofperoid_3}<!--{elseif $magic['useperoid'] == 4}-->{lang magics_outofperoid_4}<!--{/if}--><!--{if $useperoid > 0}-->{lang magics_outofperoid_value}<!--{else}-->{lang magics_outofperoid_noperm}<!--{/if}-->
                </p>
            </li>
            <!--{/if}-->
            <!--{if !$useperm}-->
            <li class="ren-usgroup-tsli">
                <p>
                    {lang magics_permission_no}
                </p>
            </li>
            <!--{/if}-->
            <li>
                <div class="item-content">
                    <div class="item-media">{lang memcp_usergroups_buy}</div>
                    <div class="item-inner">
                        <div class="item-input">
                            <input id="magicnum" name="magicnum" type="text" size="2" autocomplete="off" value="1" class="px pxs" onkeyup="compute();" />
                        </div>
                    </div>
                    <div class="item-media">{lang magics_unit}</div>
                </div>
            </li>
            <input type="hidden" name="operatesubmit" value="yes" />
            <!--{elseif $operation == 'give'}-->

            <li>
                <div class="item-content">
                    <div class="item-media">{lang magics_target_present}</div>
                    <div class="item-inner">
                        <div class="item-input">
                            <input type="text" id="selectedusername" name="tousername" size="12" autocomplete="off" value="" class="px p_fre" />
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <div class="item-content">
                    <div class="item-media">{lang magics_num}</div>
                    <div class="item-inner">
                        <div class="item-input">
                            <input name="magicnum" type="text" size="12" autocomplete="off" value="1" class="px p_fre" />
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <div class="item-content">
                    <div class="item-media">{lang magics_present_message}</div>
                    <div class="item-inner">
                        <div class="item-input">
                            <textarea name="givemessage" rows="3" class="pt">{lang magics_present_message_text}</textarea>
                        </div>
                    </div>
                </div>
            </li>
                <input type="hidden" name="operatesubmit" value="yes" />
            <!--{/if}-->
        </ul>
    </div>

    <div class="ren_login btn_login">
        <!--{if $operation == 'buy'}-->
            <button class="formdialog pn button ren_btn" type="submit" name="operatesubmit" id="operatesubmit" value="true">{lang magics_operation_buy}</button>
        <!--{elseif $operation == 'give'}-->
            <button class="formdialog pn button ren_btn" type="submit" name="operatesubmit" id="operatesubmit" value="true">{lang magics_operation_present}</button>
        <!--{/if}-->
    </div>
    </form>
</div>

<script type="text/javascript" reload="1">
	function succeedhandle_$_GET[handlekey](url, msg) {
		hideWindow('$_GET[handlekey]');
		<!--{if !$location}-->
			showDialog(msg, 'notice', null, function () { location.href=url; }, 0);
		<!--{else}-->
			showWindow('$_GET[handlekey]', 'home.php?$querystring');
		<!--{/if}-->
		showCreditPrompt();
	}
	function confirmMagicOp(e) {
		e = e ? e : window.event;
		showDialog('{lang magics_confirm}', 'confirm', '', 'ajaxpost(\'magicform\', \'return_magics\', \'return_magics\', \'onerror\');');
		doane(e);
		return false;
	}
	function compute() {
		var totalcredit = <!--{echo getuserprofile('extcredits'.$magic[credit])}-->;
		var totalweight = $allowweight;
		var magicprice = $('magicprice').innerHTML;
		if($('discountprice')) {
			magicprice = $('discountprice').innerHTML;
		}
		if(isNaN(parseInt($('magicnum').value))) {
			$('magicnum').value = 0;
			return;
		}
		if(!$('magicnum').value || totalcredit < 1 || totalweight < 1) {
			$('magicnum').value = 0;
			return;
		}
		var curprice = $('magicnum').value * magicprice;
		var curweight = $('magicnum').value * $('magicweight').innerHTML;
		if(curprice > totalcredit) {
			$('magicnum').value = parseInt(totalcredit / magicprice);
		} else if(curweight > totalweight) {
			$('magicnum').value = parseInt(totalweight / $('magicweight').innerHTML);
		}
		$('magicnum').value = parseInt($('magicnum').value);
	}
</script>

<!--{template common/footer}-->
