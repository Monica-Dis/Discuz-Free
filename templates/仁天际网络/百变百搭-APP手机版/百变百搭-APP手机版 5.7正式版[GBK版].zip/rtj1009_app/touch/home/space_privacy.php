<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval $_G['home_tpl_titles'] = array('{lang remind}');}-->
<!--{template common/header}-->
{eval 
	$space['isfriend'] = $space['self'];
	if(in_array($_G['uid'], (array)$space['friends'])) $space['isfriend'] = 1;
	space_merge($space, 'count');
	space_merge($space, 'field_home');
}

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header<!--{if $diymode && $rtj1009_m_config['ren_menu_nav'] ==2}--> ren-menu-header<!--{/if}-->">
	<div class="ren_nav cl">
		<a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z"><span class="ren_bk_name">{lang privacy_prompt}</span></div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
	</div>
</header>
<!-- header end -->
<!--{/if}-->
<div class="content p-b-0">
	<div class="ren-space-privacy">
		<div class="ren-menu cl">
			<div class="ren-menu-avatar"><!--{avatar($space[uid], big)}--></div>
		</div>
		<div class="ren-menu-privacy">
			<div class="ren-menu-name">
				<span>{$space[username]}</span>
			</div>
		</div>
	</div>
	<div class="ren-privacy-not">
		<span>{lang set_privacy}</span>
	</div>

	<!--{if !$space[self]}-->
	<div class="ren_view_foo">
		<!--{if !ckfollow($space['uid'])}-->
		<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-menu-gz" href="home.php?mod=spacecp&ac=follow&op=add&hash={FORMHASH}&fuid=$space[uid]"><i class="icon ren-font">&#xe7b9;</i>{$rtj1009_lang['home093']}</a>
		<!--{else}-->
		<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-menu-gz" href="home.php?mod=spacecp&ac=follow&op=del&fuid=$space[uid]"><i class="icon ren-font">&#xe7b9;</i>{$rtj1009_lang['home094']}</a>
		<!--{/if}-->
		<a href="home.php?mod=space&do=pm&subop=view&touid=$space[uid]" class="ren-menu-pm"><i class="icon ren-font">&#xe61b;</i>{lang send_pm}</a>
		<!--{if !$isfriend}-->
		<a href="home.php?mod=spacecp&ac=friend&op=add&uid=$space[uid]&handlekey=addfriendhk_$space[uid]" class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-menu-hy"><i class="icon ren-font">&#xe676;</i>{$rtj1009_lang['home095']}</a>
		<!--{else}-->
		<a href="home.php?mod=spacecp&ac=friend&op=ignore&uid=$space[uid]&handlekey=ignorefriendhk_{$space[uid]}" class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}--> ren-menu-hy"><i class="icon ren-font">&#xe676;</i>{$rtj1009_lang['home125']}</a>
		<!--{/if}-->
	</div>
	<!--{/if}-->
</div>
<!--{template common/footer}-->

