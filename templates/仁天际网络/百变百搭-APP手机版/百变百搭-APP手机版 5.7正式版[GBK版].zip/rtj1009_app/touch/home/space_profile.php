<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_GET['mycenter'] && !$_G['uid']}-->
	<!--{eval dheader('Location:member.php?mod=logging&action=login');exit;}-->
<!--{/if}-->
<!--{template common/header}-->
<!--{if !$_GET['mycenter']}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header<!--{if $rtj1009_m_config['ren_menu_nav'] ==2}--> ren-menu-header<!--{/if}-->">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{$rtj1009_lang['ren124']}</span>
		</div>
        <div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<!-- userinfo start -->
<div class="content<!--{if $rtj1009_m_config['ren_menu_nav'] ==2}--> p-t-0<!--{/if}--> p-b-0">
    <!--{template home/space_menu}-->
	<div id="ren_ct" class="rtj1009_lai_ct cl">
		<div class="ren_lai_mn">
			<!--{subtemplate home/space_profile_body}-->
		</div>
	</div>
</div>
<!-- userinfo end -->


<!--{else}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm">{$rtj1009_lang['ren124']}</span>
		</div>
        <div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<!-- userinfo start -->
<div class="content p-b-0 p-b-60">
	<div class="rtj1009_myall cl">
		<div class="ren_kj_listtop cl">
			<div class="ren_kj_rk">
				<div class="ren-pr-avatar">
					<span>{$rtj1009_lang['home096']}</span>
					<input type="file" id="file">
					<!--{avatar($space[uid],big)}-->
				</div>
				<a href="home.php?mod=spacecp" class="ren_kj_jj">
					<span>{$space[username]}</span>
					<em><!--{if $space[sightml]}-->$space[sightml]<!--{else}-->{$rtj1009_lang['ren125']}<!--{/if}--></em>
				</a>
			</div>
		</div>
		
		<div class="ren_fx_fl ren-profile-me cl">
			<ul class="ren_fx_xx cl">
                <!--{loop $prmenulistyi $key $values}-->
                <li>
                    <a href="{$values['url']}" class="ren_fx_xxxx">
                        <i class="icon ren-font" style="color: {$values['color']}">{$values['icon']}</i>
                        <p>{$values['title']}</p>
                    </a>
                </li>
                <!--{/loop}-->
			</ul>
		</div>
		
		<div class="ren_kj_list3 cl">
		<!--{if $_G['uid'] && !empty($_G['style']['extstyle']) && count($_G['style']['extstyle']) > 1}-->
			<a href="javascript:;" class="ren_fgps open-popup" data-popup=".popup-lostpw"><i class="icon ren-font">&#xe6a0;</i>{$rtj1009_lang['ren126']}</a>
		<!--{/if}-->
            <a class="ren_kj_tx" href="home.php?mod=space&do=notice"><i class="icon ren-font">&#xe6a5;</i>{$rtj1009_lang['home127']}<!--{if $_G[member][newpm] || $_G[member][newprompt]}--><span class="dian"></span><!--{/if}--></a>
            <!--{loop $prmenuliste $key $values}-->
            <a href="{$values['url']}"><i class="icon ren-font" style="color: {$values['color']}">{$values['icon']}</i>{$values['title']}</a>
            <!--{/loop}-->
		</div>
		<div class="ren_kj_list2 cl">
            <!--{loop $prmenulists $key $values}-->
            <a href="{$values['url']}"><i class="icon ren-font" style="color: {$values['color']}">{$values['icon']}</i>{$values['title']}</a>
            <!--{/loop}-->
		</div>
	
		<div class="ren_login btn_login">
			<a href="member.php?mod=logging&action=logout&formhash={FORMHASH}" class="dialog button ren_btn">{$rtj1009_lang['home059']}</a>
		</div>
	</div>
</div>
<!-- userinfo end -->


<div class="rtj1009-avatar" style="display:none">
	<header class="bar bar-nav rtj1009_header">
		<div class="ren_nav cl">
			<a href="javascript:;" class="z ren_fhjt back rtj1009-avatar-n"><span></span></a>
			<div class="ren_top_grkj z">
				<span class="ren_bk_name ren_vm">{$rtj1009_lang['home097']}</span>
			</div>
		</div>
	</header>
	<div id="clipArea"></div>
	<input type="file" id="file" class="none">
	<div class="rtj1009-avatar-foo">
		<button class="ren_btn rtj1009-avatar-n z">{$rtj1009_lang['home098']}</button>
		<button id="clipBtn" class="y">{$rtj1009_lang['home099']}</button>
	</div>
</div>

<script type="text/javascript" src='template/rtj1009_app/js/iscroll-zoom-min.js'></script>
<script type="text/javascript" src='template/rtj1009_app/js/hammer.min.js'></script>
<script type="text/javascript" src='template/rtj1009_app/js/lrz.all.bundle.js'></script>
<script type="text/javascript" src='template/rtj1009_app/js/jquery.photoClip.min.js'></script>



<script>
var pc = new PhotoClip("#clipArea", {
	size: 200,
	outputSize: 200,
	file: "#file",
	ok: "#clipBtn",
	loadStart: function() {
		console.log("{$rtj1009_lang['home101']}");
	},
	loadComplete: function() {
		$('.rtj1009-avatar').css('display','block');
		console.log("{$rtj1009_lang['home102']}");
	},
	loadError: function() {
		$('.rtj1009-avatar').css('display','none');
		popup.open("{$rtj1009_lang['home103']}", "alert");
	},
    done: function(dataURL) {
		$.ajax({
		type:'POST',
		url:'plugin.php?id=rtj1009_mobilecp:rtj1009_avatar',
		data: {image_file: dataURL, formhash:'{FORMHASH}'}, 
		dataType: 'html',
		}).success(function(s) {
		console.log("{$rtj1009_lang['home104']}");
		$('.ren-pr-avatar').find('img').attr('src', dataURL);
		$('.rtj1009-avatar').css('display','none');
		popup.open("{$rtj1009_lang['home105']}", "alert");
		setTimeout(function() {
			location.reload(true);
		},
		1500);
      });
    }
});
$(".rtj1009-avatar-n").click(function () {
	$('.rtj1009-avatar').css('display','none');
});
</script>


<!--{if $_G['uid'] && !empty($_G['style']['extstyle'])}-->
<div class="popup popup-lostpw">
	<header class="bar bar-nav rtj1009_header">
		<div class="ren_nav cl">
			<a href="javascript:;" class="z ren_fhjt close-popup"><span></span></a>
			<div class="ren_top_dqwz z">
				<span>{$rtj1009_lang['home060']}</span>
			</div>
			<div class="y ren_list_nav">
				<a href="portal.php?mod=index" class="ren_nav_fb"><span class="icon ren-font">&#xe601;</span></a>
			</div>
		</div>
	</header>
  <div class="content-block">
	<div class="ren_lostpw">
		<script src="template/rtj1009_app/js/ren_ps.js" charset="{CHARSET}"></script>
			<div id="ren_fgsz" class="ren_fgsz cl">
				<!--{if !$_G[style][defaultextstyle]}--><span class="ren_sslct_btn" onClick="extstyle('')" title="{lang default}"><i></i><em>{lang default}</em></span><!--{/if}-->
				<!--{loop $_G['style']['extstyle'] $extstyle}-->
					<span class="ren_sslct_btn" onClick="extstyle('$extstyle[0]')" title="$extstyle[1]">
					<i style='background:$extstyle[2]'></i><em>{$extstyle[1]}</em></span>
				<!--{/loop}-->
			</div>
			<div class="ren_login close-popup">
				<span class="button ren_btn">{$rtj1009_lang['home061']}</span>
			</div>
	</div>
  </div>
</div>
<!--{/if}-->
<!--{/if}-->
<!--{eval $nofooter = true;}-->
<!--{template common/footer}-->

