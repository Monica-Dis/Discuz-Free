<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_wz_pl cl">
	<div class="ren_lc_ks cl">
    	<span class="ren_lc_ksy y">
		
		<!--{if $data[commentnum]}-->$data[commentnum]{$rtj1009_lang['ren119']}<!--{/if}-->
        </span>
		<span class="ren_lc_ksz z">{lang latest_comment}</span>
	</div>
	<div id="comment_ul">
    <!--{if $data[commentnum]}-->
		<!--{loop $commentlist $comment}-->
		<!--{template portal/comment_li}-->
		<!--{if !empty($aimgs[$comment[cid]])}-->
			<script type="text/javascript" reload="1">aimgcount[{$comment[cid]}] = [<!--{echo implode(',', $aimgs[$comment[cid]]);}-->];attachimgshow($comment[cid]);</script>
		<!--{/if}-->
		<!--{/loop}-->
        <!--{else}-->
        <div class="ren_ss_wu">
			<i class="icon ren-font">&#xe608;</i>
			<span>{$rtj1009_lang['ren098']}</span>
		</div>
    <!--{/if}-->
		<!--{if !empty($pricount)}-->
			<p class="mtn mbn y">{lang hide_portal_comment}</p>
		<!--{/if}-->
	</div>
</div>
<div class="popup popup-view">
	<header class="bar bar-nav popup-view-nav">
		<div class="ren_nav cl">
			<a href="javascript:;" class="z ren-fh close-popup"><i class="icon ren-font">&#xe64d;</i></a>
			<div class="ren_top_dqwz z">
				<span>{$rtj1009_lang['ren123']}</span>
			</div>
		</div>
	</header>
  <div class="content-block">
	<div class="ren_lostpw">
		<div class="ren_kshf cl">
			<form id="cform" name="cform" action="$form_url" method="post" autocomplete="off">
				<div class="ren_post_pi cl">
					<div class="ren_post_nr">
						<textarea name="message" rows="3" placeholder="{$rtj1009_lang['ren120']}" class="ren_post_nrk" id="message"></textarea>
					</div>
                    <div class="ren_post_tj">
                        <a href="javascript:void(0)" class="wall_face"><i class="icon ren-font">&#xe615;</i></a>
                        <div id="fastpostsubmitline" class="post_fast">
                            <button type="submit" name="commentsubmit_btn" id="commentsubmit_btn" value="true" class="ren_post_tjan">{lang comment}</button>
                        </div>
                    </div>

				<!--{if $secqaacheck || $seccodecheck}--><!--{subtemplate common/seccheck}--><!--{/if}-->
				<!--{if !empty($topicid) }-->
					<input type="hidden" name="referer" value="$topicurl#comment" />
					<input type="hidden" name="topicid" value="$topicid">
				<!--{else}-->
					<input type="hidden" name="portal_referer" value="$viewurl#comment">
					<input type="hidden" name="referer" value="$viewurl#comment" />
					<input type="hidden" name="id" value="$data[id]" />
					<input type="hidden" name="idtype" value="$data[idtype]" />
					<input type="hidden" name="aid" value="$aid">
				<!--{/if}-->
				<input type="hidden" name="formhash" value="{FORMHASH}">
				<input type="hidden" name="replysubmit" value="true">
				<input type="hidden" name="commentsubmit" value="true" />
				</div>
			</form>
            <script type="text/javascript" src="template/rtj1009_app/js/home.face.js"></script>
            <div id="Home_FaceBox"></div>
            <script type="text/javascript">
                $(function (){
                    $("a.wall_face").HomeFaceBox({
                        Event : "click",	//�����¼�
                        divid : "Home_FaceBox", //���DIV ID
                        textid : "message" //�ı��� ID
                    });
                });

                $('#Smohan_Showface').click(function(){
                    $('#Zones').fadeIn(360);
                    $('#Zones').html($('#Smohan_text').val());
                    $('#Zones').replaceface($('#Zones').html());
                });
            </script>
        </div>
	</div>
  </div>
</div>
