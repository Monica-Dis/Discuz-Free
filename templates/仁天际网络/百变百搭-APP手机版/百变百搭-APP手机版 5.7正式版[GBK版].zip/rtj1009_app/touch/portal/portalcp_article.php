<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if $op == 'delete'}-->

<h3 class="flb">
	<em>{lang article_delete}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>

<form method="post" autocomplete="off" action="portal.php?mod=portalcp&ac=article&op=delete&aid=$_GET[aid]">
	<div class="c">
		<!--{if $_G['group']['allowpostarticlemod'] && $article['status'] == 1}-->
		{lang article_delete_sure}
		<input type="hidden" name="optype" value="0" class="pc" />
		<!--{else}-->
		<label class="lb"><input type="radio" name="optype" value="0" class="pc" />{lang article_delete_direct}</label>
		<label class="lb"><input type="radio" name="optype" value="1" class="pc" checked="checked" />{lang article_delete_recyclebin}</label>
		<!--{/if}-->
	</div>
	<p class="o pns">
		<button type="submit" name="btnsubmit" value="true" class="pn pnc"><strong>{lang confirms}</strong></button>
	</p>
	<input type="hidden" name="aid" value="$_GET[aid]" />
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="deletesubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
</form>
<!--{elseif $op == 'verify'}-->
<h3 class="flb">
	<em id="return_$_GET[handlekey]">{lang moderate_article}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>

<form method="post" autocomplete="off" id="aritcle_verify_$aid" action="portal.php?mod=portalcp&ac=article&op=verify&aid=$aid">
	<div class="c">
		<label for="status_0" class="lb"><input type="radio" class="pr" name="status" value="0" id="status_0"{if $article[status]=='1'} checked="checked"{/if} />{lang passed}</label>
		<label for="status_x" class="lb"><input type="radio" class="pr" name="status" value="-1" id="status_x" />{lang delete}</label>
		<label for="status_2" class="lb"><input type="radio" class="pr" name="status" value="2" id="status_2"{if $article[status]=='2'} checked="checked"{/if} />{lang ignore}</label>
	</div>
	<p class="o pns">
		<button type="submit" name="btnsubmit" value="true" class="pn pnc"><strong>{lang confirms}</strong></button>
	</p>
	<input type="hidden" name="aid" value="$aid" />
	<input type="hidden" name="referer" value="{echo dreferer()}" />
	<input type="hidden" name="handlekey" value="$_GET['handlekey']" />
	<input type="hidden" name="verifysubmit" value="true" />
	<input type="hidden" name="formhash" value="{FORMHASH}" />
</form>
<!--{elseif $op == 'related'}-->

	<!--{if $ra}-->
	<li id="raid_li_$ra[aid]"><input type="hidden" name="raids[]" value="$ra[aid]" size="5">[ $ra[aid] ] <a href="{echo fetch_article_url($ra);}" target="_blank">$ra[title]</a> <a href="javascript:;" onclick="raid_delete($ra[aid]);">{lang delete}</a></li>
	<!--{/if}-->

<!--{elseif $op == 'pushplus'}-->
<h3 class="flb">
	<em>{lang article_pushplus}</em>
	<!--{if $_G[inajax]}--><span><a href="javascript:;" onclick="hideWindow('$_GET[handlekey]');" class="flbc" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>
<form method="post" target="_blank" action="portal.php?mod=portalcp&ac=article&tid=$tid&aid=$aid">
	<div class="c">
		<b>$pushcount</b> {lang portalcp_article_message1}<a href="$article_url" target="_blank" class="xi2">({lang view_article})</a>
		<!--{if $pushedcount}--><br />{lang portalcp_article_message2}<!--{/if}-->
		<div id="pushplus_list">
		<!--{loop $pids $pid}-->
		<input type="hidden" name="pushpluspids[]" value="$pid" />
		<!--{/loop}-->
		</div>
	</div>
	<p class="o pns">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="pushplussubmit" value="1" />

		<input type="hidden" name="toedit" value="1" />
		<button type="submit" class="pn pnc vm"><span>{lang submit}</span></button>
	</p>
</form>
<!--{elseif $op == 'add_success'}-->
<div class="tip">
	<dt id="messagetext">
		<p>{lang article_send_succeed}</p>
		<script type="text/javascript">
            setTimeout(function() {
                window.location.href = 'portal.php?mod=view&aid={$aid}';
            }, '3000');
		</script>
	</dt>
</div>
<!--{else}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
	<div class="ren_nav cl">
		<a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_grkj z">
			<span class="ren_bk_name ren_vm"><!--{if !empty($aid)}-->{lang article_edit}<!--{else}-->{lang article_publish}<!--{/if}-->
			</span>
		</div>
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
	</div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content ren-post-blog">
	<div class="rtj1009_post rtj1009_m_main cl">
		<form method="post" autocomplete="off" id="articleform" action="portal.php?mod=portalcp&ac=article{if $_GET[modarticlekey]}&modarticlekey=$_GET[modarticlekey]{/if}" enctype="multipart/form-data">
			<div class="post_from ren_post_list cl">
				<ul class="cl">
					<li class="ren_bl_li">
						<div class="ren-post-btlabel">{$rtj1009_lang['ren189']}</div>
						<div class="ren-post-btxx">
							<input type="text" name="title" id="title" class="px" value="$article[title]" placeholder="{$rtj1009_lang['ren073']}" size="80" />
						</div>
					</li>
				</ul>
				<div class="ren_fb_hd cl">
					<div class="ren_fb_hdxxs">
						<ul>

							<li class="ren_hdxx_li ren_hdxx_de">
								<div class="ren_hdxx_lx">{lang article_category}</div>
								<div class="ren_hdxx_lxnr ren-webki">
									$categoryselect
								</div>
							</li>

							<li class="ren_hdxx_li ren_hdxx_de">
								<div class="ren_hdxx_lx">{lang article_source}</div>
								<div class="ren_hdxx_lxnr">
									<input type="text" id="from" name="from" class="px oinf" value="$article[from]" {if $from_cookie}size="10"{else}size="30"{/if} />
								</div>
							</li>
							<li class="ren_hdxx_li ren_hdxx_de">
								<div class="ren_hdxx_lx">{lang article_source_url}</div>
								<div class="ren_hdxx_lxnr">
									<input type="text" name="fromurl" class="px oinf" value="$article[fromurl]" size="30" />
								</div>
							</li>
							<li class="ren_hdxx_li ren_hdxx_de">
								<div class="ren_hdxx_lx">{lang article_dateline}</div>
								<div class="ren_hdxx_lxnr">
									<input type="text" id='ren-article-pdateline' name="dateline" class="px oinf" value="$article[dateline]" size="30" />
								</div>
							</li>
							<li class="ren_hdxx_li ren_hdxx_de">
								<div class="ren_hdxx_lx">{lang article_url}</div>
								<div class="ren_hdxx_lxnr">
									<input type="text" class="px oinf" name="url" value="$article[url]" size="30" />
								</div>
							</li>
							<li class="ren_hdxx_li ren_hdxx_de">
								<div class="ren_hdxx_lx">{lang article_author}</div>
								<div class="ren_hdxx_lxnr">
									<input type="text" name="author" class="px oinf" value="$article[author]" size="30" />
								</div>
							</li>
                            <!--{if $category[$catid][allowcomment]}-->
                            <li class="ren_hdxx_li ren_spxx_de">
                                <div class="ren_hdxx_lx">{lang article_comment_setup}</div>
                                <div class="item-inner ren-sendreasonpm">
                                    <div class="item-input">
                                        <label for="ck_allowcomment" class="label-switch">
                                            <input type="checkbox" name="forbidcomment" id="ck_allowcomment" value="1"{if isset($article['allowcomment']) && empty($article['allowcomment'])}checked="checked"{/if} />
                                            <div class="checkbox"></div>
                                        </label>
                                    </div>
                                </div>
                            </li>
                            <!--{/if}-->
                            <li class="ren_hdxx_li ren_hdxx_he">
                                <div class="ren_hdxx_lx">{lang article_tag}</div>
                                <div class="ren_hdxx_lxnr">
                                    <ul class="ren_fl_dx cl">
                                        <!--{loop $article_tags $key $tag}-->
                                        <li>
                                            <label for="article_tag_$key">
                                                <input type="checkbox" name="tag[$key]" id="article_tag_$key" class="pc"{if $article_tags[$key]} checked="checked"{/if} />
                                                $tag_names[$key]
                                            </label>
                                        </li>
                                        <!--{/loop}-->
                                    </ul>
                                </div>
                            </li>
							<li class="ren_hdxx_he"><div class="ren_tie_ksf">{$rtj1009_lang['ren190']}{$rtj1009_lang['ren069']}</div></li>
							<li class="ren_bl_no">
								<textarea class="userData" name="content" id="uchome-ttHtmlEditor" rows="4" placeholder="{$rtj1009_lang['ren053']}">$article_content[content]</textarea>
							</li>
                            <li class="ren_hdxx_he"><div class="ren_tie_ksf">{$rtj1009_lang['ren190']}{lang article_description}</div></li>
                            <li class="ren_bl_no">
                                <textarea name="summary" cols="80" rows="2">$article[summary]</textarea>
                            </li>
						</ul>
					</div>
				</div>

			<!--{if $secqaacheck || $seccodecheck}-->
				<!--{block sectpl}--><sec> <span id="sec<hash>" onclick="showMenu(this.id)"><sec></span><div id="sec<hash>_menu" class="p_pop p_opt" style="display:none"><sec></div><!--{/block}-->
				<div class="exfm pns"><!--{subtemplate common/seccheck}--></div>
			<!--{/if}-->

			</div>

            <span class="ren_ft_anniu">
                <button type="submit" id="issuance" name="articlebutton" class="formdialog ren_ft_an">{lang submit}</button>
            </span>
            <input type="hidden" id="aid" name="aid" value="$article[aid]" />
            <input type="hidden" name="cid" value="$article_content[cid]" />
            <input type="hidden" id="attach_ids" name="attach_ids" value="0" />
            <input type="hidden" name="articlesubmit" value="true" />
            <input type="hidden" name="formhash" value="{FORMHASH}" />
		</form>

	</div>
</div>
<iframe id="uploadframe" name="uploadframe" width="0" height="0" marginwidth="0" frameborder="0" src="about:blank"></iframe>
<script type="text/javascript">
    var pdateline = new datePicker();
    pdateline.init({
        'trigger': '#ren-article-pdateline',
        'type': 'datetime',
        'minDate':'1970-1-1',
        'maxDate':'2030-12-31',
        'onSubmit':function(){
            var theSelectData = pdateline.value;
        },
        'onClose':function() {
        }
    });
function from_get() {
	var el = $('catid');
	var catid = el ? el.value : 0;
	window.location.href='portal.php?mod=portalcp&ac=article&from_idtype='+$('from_idtype').value+'&catid='+catid+'&from_id='+$('from_id').value+'&getauthorall='+($('getauthorall').checked ? '1' : '');
	return true;
}
function validate(obj) {
	var title = $('title');
	if(title) {
		var slen = strlen(title.value);
		if (slen < 1 || slen > 80) {
			alert("{lang article_validate_title}");
			title.focus();
			return false;
		}
	}
	if(!check_catid()) {
		return false;
	}
	edit_save();
	window.onbeforeunload = null;
	obj.form.submit();
	return false;
}
function check_catid(){
	var catObj = $("catid");
	if(catObj) {
		if (catObj.value < 1) {
			alert("{lang article_validate_category}");
			catObj.focus();
			return false;
		}
	}
	return true;
}
function raid_add() {
	var raid = $('raid').value;
	if($('raid_li_'+raid)) {
		alert('{lang article_validate_has_added}');
		return false;
	}
	var url = 'portal.php?mod=portalcp&ac=article&op=related&inajax=1&aid={$article[aid]}&raid='+raid;
	var x = new Ajax();
	x.get(url, function(s){
		s = trim(s);
		if(s) {
			$('raid_div').innerHTML += s;
		} else {
			alert('{lang article_validate_noexist}');
			return false;
		}
	});
}
function raid_delete(aid) {
	var node = $('raid_li_'+aid);
	var p;
	if(p = node.parentNode) {
		p.removeChild(node);
	}
}
function switchhl(obj, v) {
	if(parseInt($('highlight_style_' + v).value)) {
		$('highlight_style_' + v).value = 0;
		obj.className = obj.className.replace(/ cnt/, '');
	} else {
		$('highlight_style_' + v).value = 1;
		obj.className += ' cnt';
	}
}
function change_title_color(hlid) {
	var showid = hlid;
	if(!$(showid + '_menu')) {
		var str = '';
		var coloroptions = {'0' : '#000', '1' : '#EE1B2E', '2' : '#EE5023', '3' : '#996600', '4' : '#3C9D40', '5' : '#2897C5', '6' : '#2B65B7', '7' : '#8F2A90', '8' : '#EC1282'};
		var menu = document.createElement('div');
		menu.id = showid + '_menu';
		menu.className = 'cmen';
		menu.style.display = 'none';
		for(var i in coloroptions) {
			str += '<a href="javascript:;" onclick="$(\'highlight_style_0\').value=\'' + coloroptions[i] + '\';$(\'' + showid + '\').style.backgroundColor=\'' + coloroptions[i] + '\';hideMenu(\'' + menu.id + '\')" style="background:' + coloroptions[i] + ';color:' + coloroptions[i] + ';">' + coloroptions[i] + '</a>';
		}
		menu.innerHTML = str;
		$('append_parent').appendChild(menu);
	}
	showMenu({'ctrlid':hlid + '_ctrl','evt':'click','showid':showid});
}
if($('title')) {
	$('title').focus();
}
function setConver(attach) {
	$('conver').value = attach;
}

function deleteAttach(attachid, url) {
	ajaxget(url);
	$('attach_list_' + attachid).style.display = 'none';
	if($('setconver' + attachid).checked) {
		$('conver').value = '';
	}
}
<!--{if !empty($article['conver'])}-->
setConver('$article[conver]');
<!--{/if}-->
function check_htmlname_exists(obj) {
	name = obj.value;
	var msg = $('checkhtmlnamemsg');
	if(name && $('oldhtmlname').value != name) {
		var catid = $('catid').value;
		var aid = $('aid').value;
		var x = new Ajax();
		x.getJSON('portal.php?mod=portalcp&ac=article&op=checkhtmlname&htmlname='+name+'&catid='+catid+'&aid='+aid, function(s){
			if(s['message'] == 'html_existed') {
				obj.focus();
				msg.style.color = 'red';
				msg.style.paddingLeft = '10px';
				msg.innerHTML = '{lang article_html_existed}';
				$('issuance').disabled = 'disabled';
			} else {
				msg.innerHTML = '';
				$('issuance').disabled = '';
			}
		});
	} else {
		msg.innerHTML = '';
		$('issuance').disabled = '';
	}
}
</script>

<!--{/if}-->

<!--{template common/footer}-->

