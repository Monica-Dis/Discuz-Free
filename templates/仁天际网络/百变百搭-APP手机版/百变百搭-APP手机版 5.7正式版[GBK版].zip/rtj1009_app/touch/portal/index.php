<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $ren_weixin_hd}-->
  	<!-- header start -->
	<header class="bar bar-nav rtj1009_header">
		<div class="ren_nav cl">
			<!--{if ($ren_m_portal_zy ==1) || ($ren_m_portal_zy ==2)}-->
			<a href="search.php?mod=forum" class="z ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
			<!--{elseif $ren_m_portal_zy ==3}-->
			<div class="ren_nav_left open-panel">
				<div class="ren_btn">
					<span><span class="ren_nav_icon"><span></span></span></span>
				</div>
			</div>
			<!--{elseif $ren_m_portal_zy ==4}-->
			<div class="ren_nav_left open-panel">
				<div class="ren-nav-avatar">
					<!--{if $_G[member][newpm] || $_G[member][newprompt]}--><span class="dian"></span><!--{/if}-->
					<img src="<!--{avatar($_G[uid], middle, true)}-->" />
				</div>
			</div>
			<!--{/if}-->
			<!--{if $_G['setting']['domain']['app']['mobile']}-->
				{eval $nav = 'http://'.$_G['setting']['domain']['app']['mobile'];}
			<!--{else}-->
				{eval $nav = "forum.php";}
			<!--{/if}-->
			<!--{if $ren_m_portal_logo==1}--><a class="ren_logo" title="$_G[setting][bbname]" href="$nav"><img src="template/rtj1009_app/image/logo.png" /></a>
			<!--{else}-->
			<div class="ren_top_grkj z">
				<span class="ren_bk_name ren_vm"><!--{if $ren_m_portal_logo==2}-->{$rtj1009_lang['ren001']}<!--{elseif $ren_m_portal_logo==3}-->{$rtj1009_lang['ren134']}<!--{elseif $ren_m_portal_logo==4}-->$_G[setting][bbname]<!--{/if}--></span>
			</div>
			<!--{/if}-->
			<!--{if $ren_m_portal_zy ==1}-->
			<div class="ren_nav_right open-panel">
				<div class="ren_btn">
					<span><span class="ren_nav_icon"><span></span></span></span>
				</div>
			</div>
			<!--{elseif $ren_m_portal_zy ==2}-->
			<div class="ren_nav_right open-panel">
				<div class="ren-nav-avatar">
					<!--{if $_G[member][newpm] || $_G[member][newprompt]}--><span class="dian"></span><!--{/if}-->
					<img src="<!--{avatar($_G[uid], middle, true)}-->" />
				</div>
			</div>
			<!--{elseif ($ren_m_portal_zy ==3) || ($ren_m_portal_zy ==4)}-->
			<a href="search.php?mod=forum" class="y ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
			<!--{/if}-->
		</div>
	</header>
	<!-- header end -->
<!--{/if}-->

  <!-- ������ҳ�������� -->
	<div class="content">
		<div class="rtj1009_m_portal <!--{if $ren_m_slide == 2}-->ren-home-slide-e<!--{elseif $ren_m_slide == 3}-->ren-home-slide-san<!--{elseif $ren_m_slide == 4}-->ren-home-slide-si<!--{elseif $ren_m_slide == 5}-->ren-home-slide-wu<!--{/if}-->">
            {$block_portal}
		</div>
		<!--{if $ren_m_portal_list}-->
			<div id="ren-m-list" class="ren-m-list ren_tie_list rtj1009_m_main cl">
			<!--{subtemplate rtj1009_core/ren_portal_list}-->
			$multi
                <!--{if $ren_portal_page}-->
			<script type="text/javascript">
			var curpage = $curpage;
			var ren_loading = false;
			var ren_loading_ing='<div class="ren_loading loading">{$rtj1009_lang[ren018]}</div>';
			var ren_loading_end='<div class="ren_loading">{$rtj1009_lang[ren019]}</div>';
			$(document).ready(function(){
			  $(".page").html(ren_loading_ing);
			  $(window).scroll(function () {
				  if ($(document).scrollTop() + $(window).height()> $(document).height() - 130 && !ren_loading) {
					ren_loading = true;
					ren_list_page();
				  }
			   });
			});
			
			function ren_list_page() {
				curpage++;
				var url = 'portal.php?mod=index&page=' + curpage;
				$.ajax({
					url : url,
					data : null,
					dataType : "html",
					success : function(s) {
						if(curpage >= $renpages){
							$(".page").html(ren_loading_end);
						}
						s = s.replace(/\n|\r/g, '');
						var nexts = s.match(/<ul class="ren_list cl">(.+?)<\/ul>/);
						var pagenum = s.match(/<strong>(\d+)<\/strong>/);
						pagenum = parseInt(pagenum[1]);
						
						if(pagenum==$renpages){
							ren_loading = false;
						}else{
							
							if(nexts[1]){
								$(nexts[1]).insertAfter($(".ren_list>li").last());
							}
							ren_loading = false;
						}	
					}
				});
			}
			</script>
                <!--{/if}-->
			</div>
		<!--{/if}-->
	</div>
	

<!--{template common/footer}-->












