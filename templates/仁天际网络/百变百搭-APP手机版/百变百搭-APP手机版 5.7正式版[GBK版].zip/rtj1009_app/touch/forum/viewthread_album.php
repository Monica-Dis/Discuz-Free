<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<style type="text/css">
.postalbum { background-color:#343434; display:none; height:100%; overflow:hidden; padding:0 0 1px 0; position:absolute; top:0; width:100%; z-index:80; }
</style>

	<!--{eval $curaidkey = 0;}-->
	<!--{eval $count = count($imglist['aid']);}-->
	<!--{if $_GET['aid']}-->
		<!--{loop $imglist['aid'] $k $aid}-->
			<!--{if $_GET['aid'] == $aid}-->
				<!--{eval $curaidkey = $k;break;}-->
			<!--{/if}-->
		<!--{/loop}-->
	<!--{/if}-->
	<div class="postalbum">
        <header class="bar bar-nav rtj1009_header postalbum-pic">
            <div class="ren_nav cl">
                <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
                <div class="ren_top_grkj z"><span id="curpic" class="ren_bk_name"><!--{eval echo $curaidkey + 1}--></span><span> / $count</span></div>
            </div>
        </header>
        <div class="swiper-container4">
            <ul class="swiper-wrapper">
                <!--{loop $imglist[url] $key $imgurl}-->
                <li class="swiper-slide<!--{if $imglist[aid][$key] == $_GET['aid']}--> img_index<!--{/if}-->" aid="<!--{if $imglist[aid][$key] == $_GET['aid']}-->$imglist[aid][$key]<!--{/if}-->">
                    <div class="swiper-zoom-container">
                        <!--{eval $imgurl = getforumimg($imglist[aid][$key], 0, 2000, 1500, 'fixnone');}-->
                        <img src="$imgurl" class="ren-album-img" />
                    </div>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
	</div>


<script type="text/javascript">
(function() {
    var support3d = ("WebKitCSSMatrix" in window && "m11" in new WebKitCSSMatrix());
	var width = window.innerWidth;
	var height = document.documentElement.clientHeight;
	$('.postalbum').css({'display':'block', 'height':height + 'px'});
	if(support3d) {
		$('.swiper-container4').css({'line-height':height + 'px'});;
	} else {
		$('.swiper-container4').css({'display':'block', 'height':height * count + 'px'});
		$('.swiper-container4').css({'top': '-' + curkey * height + 'px'});
	}
})();
</script>

<!--{template common/footer}-->

