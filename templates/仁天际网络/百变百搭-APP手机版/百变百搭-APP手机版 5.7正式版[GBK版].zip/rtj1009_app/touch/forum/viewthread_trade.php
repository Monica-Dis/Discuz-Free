<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren-trade">
	<!--{if !$post['message'] && (($_G['forum']['ismoderator'] && $_G['group']['alloweditpost'] && (!in_array($post['adminid'], array(1, 2, 3)) || $_G['adminid'] <= $post['adminid'])) || ($_G['forum']['alloweditpost'] && $_G['uid'] && $post['authorid'] == $_G['uid']))}-->
	<div class="box">
		<a href="forum.php?mod=post&action=edit&fid=$_G[fid]&tid=$_G[tid]&pid=$post[pid]&page=$page">
		<span>{lang post_add_aboutcounter}</span>
		</a>
	</div>
	<!--{else}-->
	 <div class="postmessage">
	 $post[message]
	 </div>
	<!--{/if}-->
	
	<!--{if $tradenum}-->
		<!--{if $trades}-->
			<!--{loop $trades $key $trade}-->
				<div id="trade$trade[pid]" class="ren-trade-box">
					<div class="ren-trade-img">
						<!--{if $trade['thumb']}-->
							<img src="$trade[thumb]" alt="$trade[subject]" />
						<!--{else}-->
							<img src="{IMGDIR}/nophotosmall.gif" alt="$trade[subject]" />
						<!--{/if}-->
					</div>
					<div class="ren-trade-xx">
						<div class="ren-trade-bt">$trade[subject]</div>
						<ul class="cl">
							<li>
								<span>{lang trade_type_viewthread}</span>
								<em><!--{if $trade['quality'] == 1}-->{lang trade_new}<!--{/if}-->
								<!--{if $trade['quality'] == 2}-->{lang trade_old}<!--{/if}-->
								{lang trade_type_buy}
								</em>
							</li>
							<li>
								<span>{lang trade_remaindays}</span>
								<!--{if $trade[closed]}-->
									<em>{lang trade_timeout}</em>
								<!--{elseif $trade[expiration] > 0}-->
									<em>{$trade[expiration]}{lang days}{$trade[expirationhour]}{lang trade_hour}</em>
								<!--{elseif $trade[expiration] == -1}-->
									<em>{lang trade_timeout}</em>
								<!--{/if}-->
							</li>
							<li>
								<span>{$rtj1009_lang['ren116']}</span>
								<em>
							<!--{if $trade[price] > 0}-->
								<strong>$trade[price]{lang payment_unit}</strong>
							<!--{/if}-->
							<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade[credit]}-->
								<i><!--{if $trade['price'] > 0}-->{lang trade_additional} <!--{/if}--><strong>$trade[credit]</strong>&nbsp;{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][5]][title]}</i>
							<!--{/if}-->
								</em>
							</li>
							<li>
								<span>{$rtj1009_lang['ren117']}</span>
								<em>
								<del>
								<!--{if $trade['costprice'] > 0}-->
									$trade[costprice]{lang payment_unit}
								<!--{/if}-->
								</del>
								<!--{if $_G['setting']['creditstransextra'][5] != -1 && $trade['costcredit'] > 0}-->
									<del><!--{if $trade['costprice'] > 0}-->{lang trade_additional} <!--{/if}-->$trade[costcredit] {$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][unit]}{$_G[setting][extcredits][$_G['setting']['creditstransextra'][5]][title]}</del>
								<!--{/if}-->
								</em>
							</li>
							<li>
								<span>{lang trade_transport}</span>
								<em>
								<!--{if $trade['transport'] == 0}-->{lang post_trade_transport_offline}<!--{/if}-->
								<!--{if $trade['transport'] == 1}-->{lang post_trade_transport_seller}<!--{/if}-->
								<!--{if $trade['transport'] == 2 || $trade['transport'] == 4}-->
									<!--{if $trade['transport'] == 4}-->{lang post_trade_transport_physical}<!--{/if}-->
									<!--{if !empty($trade['ordinaryfee']) || !empty($trade['expressfee']) || !empty($trade['emsfee'])}-->
										<!--{if !empty($trade['ordinaryfee'])}-->{lang post_trade_transport_mail} $trade[ordinaryfee] {lang payment_unit}<!--{/if}-->
										<!--{if !empty($trade['expressfee'])}--> {lang post_trade_transport_express} $trade[expressfee] {lang payment_unit}<!--{/if}-->
										<!--{if !empty($trade['emsfee'])}--> EMS $trade[emsfee] {lang payment_unit}<!--{/if}-->
									<!--{elseif $trade['transport'] == 2}-->
										{lang post_trade_transport_none}
									<!--{/if}-->
								<!--{/if}-->
								<!--{if $trade['transport'] == 3}-->{lang post_trade_transport_virtual}<!--{/if}-->
								</em>
							</li>
							<li>
								<span>{lang trade_locus}</span>
								<em>$trade[locus]</em>
							</li>
							<li>
								<span>{lang post_trade_number}</span>
								<em>$trade[amount]</em>
							</li>
							<li>
								<span>{lang post_trade_buynumber}</span>
								<em>$trade[totalitems]</em>
							</li>
						</ul>
						<div class="ren-trade-pn cl">
							<a href="home.php?mod=space&do=pm&subop=view&touid=$post[uid]" class="ren-trade-button">{$rtj1009_lang['ren118']}</a>
						</div>
					</div>
				</div>
			<!--{/loop}-->
		<!--{/if}-->
	<div id="postmessage_$post[pid]">$post[counterdesc]</div>
	<!--{else}-->
		<div class="locked">{lang trade_nogoods}</div>
	<!--{/if}-->
</div>

