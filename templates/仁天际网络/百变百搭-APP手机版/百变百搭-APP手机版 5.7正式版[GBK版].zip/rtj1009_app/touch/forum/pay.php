<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<div class="tip ren-rate-tip">
<form id="payform" method="post" autocomplete="off" action="forum.php?mod=misc&action=pay&paysubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}"{if !empty($_GET['infloat'])} onsubmit="ajaxpost('payform', 'return_$_GET['handlekey']', 'return_$_GET['handlekey']', 'onerror');return false;"{/if}>
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="referer" value="{echo dreferer()}" />
		<input type="hidden" name="tid" value="$_G[tid]" />
		<!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
		<div class="ren-rate-nav ren-pay-nav">
			<a href="javascript:;" class="rate-close" onclick="popup.close();"><i class="icon ren-font">&#xe64d;</i></a>
			<div class="ren_top_dqwz z">
				<span>{lang pay}</span>
			</div>
		</div>
		<div class="ren-pay-topxx">
			<ul>
				<li>
					<span>{lang author}</span>
					<p><a href="home.php?mod=space&uid=$thread[authorid]">$thread[author]</p></span>
				</li>
				<li>
					<span >{lang price}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</span>
					<p>$thread[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</p>
				</li>
				<li>
					<span >{lang pay_author_income}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</span>
					<p>$thread[netprice] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</p>
				</li>
				<li>
					<span >{lang pay_balance}({$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]})</span>
					<p>$balance {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}</p>
				</li>
			</ul>
		</div>
	<div class="ren_login btn_login">
		<button type="submit" name="paysubmit" class="formdialog pn button ren_btn" value="true"><span>{lang submit}</span></button>
	</div>
</form>

<!--{if !empty($_GET['infloat'])}-->
<script type="text/javascript" reload="1">
function succeedhandle_$_GET['handlekey'](locationhref) {
	<!--{if !empty($_GET['from'])}-->
		location.href = locationhref;
	<!--{else}-->
		ajaxget('forum.php?mod=viewthread&tid=$_G[tid]&viewpid=$_GET[pid]', 'post_$_GET[pid]');
		hideWindow('$_GET['handlekey']');
		showCreditPrompt();
	<!--{/if}-->
}
</script>
<!--{/if}-->

<!--{template common/footer}-->
