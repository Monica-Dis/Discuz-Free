<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_xxk_xx<!--{if $rtj1009_mobilecp['ren_m_forum'] == 4}--> ren-foumlist-dan<!--{/if}-->">
    <!--{if $rtj1009_m_config['ren_m_forum'] == 3}-->
        <!--{if $rtj1009_m_config['ren_forum_shuju']}-->
        <div class="ren-f-count cl">
            <ul class="cl">
                <li>
                    <p>{$rtj1009_lang['ren036']}</p>
                    <em>$todayposts</em>
                </li>
                <li>
                    <p>{$rtj1009_lang['ren037']}</p>
                    <em>$posts</em>
                </li>
                <li>
                    <p>{$rtj1009_lang['ren038']}</p>
                    <em>$_G['cache']['userstats']['totalmembers']</em>
                </li>
            </ul>
        </div>
        <!--{/if}-->
    <!--{/if}-->

    <!--{if $rtj1009_mobilecp['ren_m_forum'] == 4}-->{$block_forum_si}<!--{/if}-->
	<!--{if empty($gid) && !empty($forum_favlist)}-->
	<!--{eval $forumscount = count($forum_favlist);}-->
	<!--{eval $forumcolumns = $forumscount > 3 ? ($forumscount == 4 ? 4 : 5) : 1;}-->
	
	<!--{eval $forumcolwidth = (floor(100 / $forumcolumns) - 0.1).'%';}-->
	<div class="ren_m_bm ren_m_bk">
		<div class="subforumshow ren_m_bm_h cl" href="#sub_forum_$cat[fid]">
			<h3 class="ren_pdbt"><a href="javascript:;">{$rtj1009_lang['ren041']}</a></h3>
		</div>
		<div id="sub_forum_$cat[fid]" class="sub_forum">
			<ul class="<!--{if $rtj1009_m_config['ren_m_forum_ico'] == 1}-->ren-forum-ico-y<!--{/if}-->">
				<!--{eval $favorderid = 0;}-->
				<!--{loop $forum_favlist $key $favorite}-->
				<li class="<!--{if $rtj1009_m_config['ren_m_forum_xx'] == 1}-->ren-forum-s-y<!--{elseif $rtj1009_m_config['ren_m_forum_xx'] == 2}-->ren-forum-s-n<!--{/if}-->">
					<!--{if $favforumlist[$favorite[id]]}-->
					<!--{eval $forum=$favforumlist[$favorite[id]];}-->
					<!--{eval $forumurl = !empty($forum['domain']) && !empty($_G['setting']['domain']['root']['forum']) ? 'http://'.$forum['domain'].'.'.$_G['setting']['domain']['root']['forum'] : 'forum.php?mod=forumdisplay&fid='.$forum['fid'];}-->
                    <div class="ren-bk-img">
                        <!--{if $forum[icon]}-->
                        $forum[icon]
                        <!--{else}-->
                        <a href="$forumurl">
                            <img src="{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg" alt="$forum[name]" />
                        </a>
                        <!--{/if}-->
                        <!--{if $rtj1009_m_config['ren_forum_num'] == 1}--><!--{if $forum[todayposts] > 0}--><span class="ren-bk-nums">$forum[todayposts]</span><!--{/if}--><!--{/if}-->
                    </div>
					<a href="$forumurl" class="ren_bkbt"><span>{$forum[name]}</span><em>{$rtj1009_lang['ren043']}<!--{echo dnumber($forum[posts])}--></em></a> 
					<!--{/if}-->
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{/if}--> 
	
	<!--{loop $catlist $key $cat}-->
	<div class="ren_m_bm ren_m_bk">
		<div class="subforumshow ren_m_bm_h cl" href="#sub_forum_$cat[fid]">
			<h3 class="ren_pdbt"><a href="javascript:;">$cat[name]</a></h3>
		</div>
		<div id="sub_forum_$cat[fid]" class="sub_forum">
			<ul class="<!--{if $rtj1009_m_config['ren_m_forum_ico'] == 1}-->ren-forum-ico-y<!--{/if}-->">
				<!--{loop $cat[forums] $forumid}-->
				<!--{eval $forum=$forumlist[$forumid];}-->
				<li class="<!--{if $rtj1009_m_config['ren_m_forum_xx'] == 1}-->ren-forum-s-y<!--{elseif $rtj1009_m_config['ren_m_forum_xx'] == 2}-->ren-forum-s-n<!--{/if}-->">
                    <div class="ren-bk-img">
                        <!--{if $forum[icon]}-->
                        $forum[icon]
                        <!--{else}-->
                        <a href="forum.php?mod=forumdisplay&fid={$forum['fid']}">
                            <img src="{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg" alt="$forum[name]" />
                        </a>
                        <!--{/if}-->
                        <!--{if $rtj1009_m_config['ren_m_forum'] == 2 || $rtj1009_m_config['ren_m_forum'] == 3}-->
                            <!--{if $rtj1009_m_config['ren_forum_num'] == 1}-->
                                <!--{if $forum[todayposts] > 0}--><span class="ren-bk-nums">$forum[todayposts]</span><!--{/if}-->
                            <!--{/if}-->
                        <!--{/if}-->
                    </div>
					<a href="forum.php?mod=forumdisplay&fid={$forum['fid']}" class="<!--{if $rtj1009_m_config['ren_m_forum'] == 4}-->ren-forumlist-bt<!--{else}-->ren_bkbt<!--{/if}-->">
                        <!--{if $rtj1009_m_config['ren_m_forum'] == 4}-->
                        <div class="ren_bk_xx z cl">
                            <h1 {if $forum[extra][namecolor]}style="color: {$forum[extra][namecolor]};"{/if}>{$forum[name]}</h1>
                            <!--{if $rtj1009_m_config['ren_m_forum_xx'] == 1}-->
                            <p class="z ren_bk_num">
                                <span class="info_label">{$rtj1009_lang['ren042']}</span>
                                <span class="info_value"><!--{echo dnumber($forum[threads])}--></span>
                                <span class="info_label">{$rtj1009_lang['ren043']}</span>
                                <span class="info_value"><!--{echo dnumber($forum[posts])}--></span>
                            </p>
                            <!--{/if}-->
                        </div>
                        <!--{else}-->
                        <span {if $forum[extra][namecolor]}style="color: {$forum[extra][namecolor]};"{/if}>{$forum[name]}</span>
                        <!--{/if}-->
                        <em>
                            <!--{if $rtj1009_m_config['ren_m_forum'] == 4}-->
                            <!--{if $forum[description]}-->$forum[description]<!--{else}-->{$rtj1009_lang['ren026']}<!--{/if}-->
                            <!--{else}-->
                            {$rtj1009_lang['ren043']}<!--{echo dnumber($forum[posts])}-->
                            <!--{/if}-->
                        </em>
                    </a>
                    <!--{if $rtj1009_m_config['ren_m_forum'] == 4}-->
                        <!--{if $rtj1009_m_config['ren_forum_num'] == 1}-->
                            <!--{if $forum[todayposts] > 0}--><span class="ren-bk-nums">$forum[todayposts]</span><!--{/if}-->
                        <!--{/if}-->
                    <!--{/if}-->
				</li>
				<!--{/loop}-->
			</ul>
		</div>
	</div>
	<!--{/loop}--> 
</div>

