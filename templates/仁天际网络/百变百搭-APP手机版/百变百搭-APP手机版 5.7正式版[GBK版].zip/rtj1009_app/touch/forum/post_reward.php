<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_ft_xs cl">
	<!--{if $_GET[action] == 'newthread'}-->
    <li class="ren_xs_ftk">
		<div class="xs_form_sue">{lang reward_price}</div>
		<div class="ren_xs_sm">
        	<input type="text" name="rewardprice" id="rewardprice" class="px pxs" size="6" onkeyup="getrealprice(this.value)" value="{$_G['group']['minrewardprice']}" tabindex="1" />
        <span>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}				</span>
        </div>
    </li>	
    <div class="ren_xs_rwd">
    	<div class="ren_xs_rwdxx">
            <p class="ren_xs_js">
                {lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
                <!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
                , {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
            </p>
        <!--{elseif $_GET[action] == 'edit'}-->
            <!--{if $isorigauthor}-->
				<li class="ren_xs_ftk">
					<div class="xs_form_sue">{lang reward_price}</div>
					<div class="ren_xs_sm">
						<input type="text" name="rewardprice" id="rewardprice" onkeyup="getrealprice(this.value)" size="6" value="$rewardprice" tabindex="1" />
					<span>{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}				</span>
					</div>
				</li>
				
				<div class="ren_xs_rwd">
					<div class="ren_xs_rwdxx">
					<!--{if $thread['price'] > 0}-->
						<p class="ren_xs_js">
							{lang reward_price_min} {$_G['group']['minrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}
							<!--{if $_G['group']['maxrewardprice'] > 0}-->, {lang reward_price_max} {$_G['group']['maxrewardprice']} {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}<!--{/if}-->
                        , {lang you_have} <!--{echo getuserprofile('extcredits'.$_G['setting']['creditstransextra'][2]);}--> {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
						</p>
                <!--{else}-->
					<p class="ren_xs_js">
                    	{lang post_reward_resolved}
                    	<input type="hidden" name="rewardprice" value="$rewardprice" tabindex="1" />
					</p>
                <!--{/if}-->
            <!--{else}-->
                <!--{if $thread['price'] > 0}-->
				<p class="ren_xs_js">
                    {lang reward_price}: $rewardprice {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][2]][title]}
				</p>
                <!--{else}-->
                    <p class="ren_xs_js">{lang post_reward_resolved}</p>
                <!--{/if}-->
            <!--{/if}-->
        <!--{/if}-->
        <!--{if $_G['setting']['rewardexpiration'] > 0}-->
            <p class="ren_xs_ts">$_G['setting']['rewardexpiration'] {lang post_reward_message}</p>
        <!--{/if}-->
		</div>
	<!--{hook/post_reward_extra}-->
	</div>
</div>

<script type="text/javascript" reload="1">
function getrealprice(price){
	if(!price.search(/^\d+$/) ) {
		n = Math.ceil(parseInt(price) + price * $_G['setting']['creditstax']);
		if(price > 32767) {
			$('realprice').innerHTML = '<b>{lang reward_price_overflow}</b>';
		}<!--{if $_GET[action] == 'edit'}-->	else if(price < $rewardprice) {
			$('realprice').innerHTML = '<b>{lang reward_cant_fall}</b>';
		}<!--{/if}--> else if(price < $_G['group']['minrewardprice'] || ($_G['group']['maxrewardprice'] > 0 && price > $_G['group']['maxrewardprice'])) {
			$('realprice').innerHTML = '<b>{lang reward_price_bound}</b>';
		} else {
			$('realprice').innerHTML = n;
		}
	}else{
		$('realprice').innerHTML = '<b>{lang input_invalid}</b>';
	}
}
if($('rewardprice')) {
	getrealprice($('rewardprice').value)
}

EXTRAFUNC['validator']['special'] = 'validateextra';
function validateextra() {
	if($('postform').rewardprice && $('postform').rewardprice.value == '') {
		showDialog('{lang post_reward_error_message}', 'alert', '', function () { $('postform').rewardprice.focus() });
		return false;
	}
	return true;
}
</script>
