<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval}-->
<!--
function tpl_hide_credits_hidden($creditsrequire) {
	global $_G;
-->
<!--{/eval}-->
<!--{block return}--><div class="locked"><!--{if $_G[uid]}-->{$_G[username]}<!--{else}-->{lang guest}<!--{/if}-->{lang post_hide_credits_hidden}</div><!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_hide_credits($creditsrequire, $message) {
-->
<!--{/eval}-->
<!--{block return}--><div class="locked">{lang post_hide_credits}</div>
$message
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_codedisp($code) {
	$randomid = 'code_'.random(3);
-->
<!--{/eval}-->
<!--{block return}--><div class="blockcode"><div><ol><li>$code</ol></div></div><!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_quote() {
-->
<!--{/eval}-->
<!--{block return}--><div class="grey quote"><blockquote>{lang e_quote}: \\1</blockquote></div><!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_free() {
-->
<!--{/eval}-->
<!--{block return}--><div class="grey quote"><blockquote>\\1</blockquote></div><!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_hide_reply() {
	global $_G;
-->
<!--{/eval}-->
<!--{block return}--><div class="showhide"><h4>{lang post_hide}</h4>\\1</div>
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function tpl_hide_reply_hidden() {
	global $_G;
-->
<!--{/eval}-->
<!--{block return}--><div class="locked"><!--{if $_G[uid]}-->{$_G[username]}<!--{else}-->{lang guest}<!--{/if}-->{lang post_hide_reply_hidden}</div><!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function attachlist($attach) {
global $_G;
$attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
$aidencode = packaids($attach);
$is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G[forum_thread][archiveid] : '';
-->
<!--{/eval}-->
<!--{block return}-->
<div id="attach_$attach[aid]" class="ren-attach" >
    <a href="<!--{if !$attach['price'] || $attach['payed']}-->forum.php?mod=attachment{$is_archive}&aid=$aidencode<!--{else}-->forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]<!--{/if}-->" class="<!--{if !$attach['price'] || $attach['payed']}--><!--{else}--><!--{if !$_G[uid]}-->ren-confirm<!--{else}-->dialog<!--{/if}--><!--{/if}-->">
        <div class="ren-attach-i"><i class="icon ren-font">&#xe63b;</i></div>
        <div class="ren-attach-xz">
            <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
            $attach[attachicon]
            <!--{/if}-->
            <!--{if !$attach['price'] || $attach['payed']}-->
            <span>$attach[filename]</span>
            <!--{else}-->
            <span>$attach[filename]</span>
            <!--{/if}-->
        </div>

        <!--{if $attach['description']}--><p>$attach[description]</p><!--{/if}-->
        <p>$attach[attachsize] ,<!--{if $attach['readperm']}-->{lang readperm}: $attach[readperm]<!--{/if}-->{lang downloads}: $attach[downloads]<!--{if !$attach['attachimg'] && $_G['getattachcredits']}-->, {lang attachcredits}: $_G[getattachcredits]<!--{/if}--><!--{if $attach['price']}--> , {lang price}: $attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}<!--{/if}-->
        </p>
        <!--{if !$attach['attachimg'] && $_G['getattachcredits']}--><p>{lang attachcredits}: $_G[getattachcredits]</p><!--{/if}-->
    </a>
    <div class="ren-attach-gm">
        <!--{if $attach['price']}-->
        <a href="forum.php?mod=misc&action=viewattachpayments&aid=$attach[aid]" class="yi">{lang pay_view}</a>
        <!--{if !$attach['payed']}-->
        <a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" class="e <!--{if !$_G[uid]}-->ren-confirm<!--{else}-->dialog<!--{/if}-->">{lang attachment_buy}</a>
        <!--{/if}-->
        <!--{/if}-->
    </div>
</div>
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function imagelist($attach, $firstpost = 0) {
    global $_G, $post;
    $fix = count($post[imagelist]) == 1 ? 800 : 1600;
    $fixtype = count($post[imagelist]) == 1 ? 'fixnone' : 'fixwr';
    $attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
    $mobilethumburl = $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) ? getforumimg($attach['aid'], 0,  800, 1600, 'fixnone') : '' ;
    $aidencode = packaids($attach);
    $is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G[forum_thread][archiveid] : '';
-->
<!--{/eval}-->
<!--{block return}-->
<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) && (!$attach['price'] || $attach['payed'])}-->
    <!--{if !$attach['price'] || $attach['payed']}-->
        <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
            <li class="ren_fu_img"><a href="forum.php?mod=viewthread&tid=$attach[tid]&aid=$attach[aid]&from=album&page=$_G[page]" class="orange"><img id="aimg_$attach[aid]" src="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" /></a>
            </li>
        <!--{/if}-->
    <!--{/if}-->
<!--{/if}-->
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}

function attachinpost($attach, $post) {
    global $_G;
    $attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
    $mobilethumburl = $attach['attachimg'] && $_G['setting']['showimages'] && (!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid']) ? getforumimg($attach['aid'], 0, 800, 1600, 'fixnone') : '' ;
    $aidencode = packaids($attach);
    $is_archive = $_G['forum_thread']['is_archived'] ? '&fid='.$_G['fid'].'&archiveid='.$_G[forum_thread][archiveid] : '';
	$guestviewthumb = !empty($_G['setting']['guestviewthumb']['flag']) && !$_G['uid'];
	if($guestviewthumb) {
        $mobilethumburl = getforumimg($attach['aid'], 0, 240, 240, 'fixnone');
	}
-->
<!--{/eval}-->
<!--{block return}-->
<!--{if $attach['attachimg'] && $_G['setting']['showimages'] && (((!$attach['price'] || $attach['payed']) && ($_G['group']['allowgetimage'] || $_G['uid'] == $attach['uid'])) || (($guestviewthumb)))}-->
    <!--{if $guestviewthumb}-->
        <div class="guestviewthumb<!--{if !$_G[uid]}--> ren-confirm<!--{/if}-->">
            <img id="aimg_$attach[aid]" class="guestviewthumb_cur vm" aid="$attach[aid]" src="$mobilethumburl" makefile="$makefile" alt="$attach[imgalt]" title="$attach[imgalt]"/>
            <a href="javascript:;">{lang guestviewthumb}</a>
        </div>
        <!--{elseif $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
        <a href="forum.php?mod=viewthread&tid=$attach[tid]&aid=$attach[aid]&from=album&page=$_G[page]" class="orange"><img id="aimg_$attach[aid]" src="$mobilethumburl" alt="$attach[imgalt]" title="$attach[imgalt]" /></a>
        <!--{/if}-->
    <!--{else}-->

        <div id="attach_$attach[aid]" class="ren-attach" >
            <a href="<!--{if !$attach['price'] || $attach['payed']}-->forum.php?mod=attachment{$is_archive}&aid=$aidencode<!--{else}-->forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]<!--{/if}-->" class="<!--{if !$attach['price'] || $attach['payed']}--><!--{else}--><!--{if !$_G[uid]}-->ren-confirm<!--{else}-->dialog<!--{/if}--><!--{/if}-->">
                <div class="ren-attach-i"><i class="icon ren-font">&#xe63b;</i></div>
                <div class="ren-attach-xz">
                    <!--{if $_G['setting']['mobile']['mobilesimpletype'] == 0}-->
                    $attach[attachicon]
                    <!--{/if}-->
                    <!--{if !$attach['price'] || $attach['payed']}-->
                    <span>$attach[filename]</span>
                    <!--{else}-->
                    <span>$attach[filename]</span>
                    <!--{/if}-->
                </div>
                <!--{if $attach['description']}--><p>$attach[description]</p><!--{/if}-->
                <p>$attach[attachsize] , {lang downloads}: $attach[downloads]<!--{if $attach['price']}--> , {lang price}: $attach[price] {$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][unit]}{$_G['setting']['extcredits'][$_G['setting']['creditstransextra'][1]][title]}<!--{/if}-->
                </p>
                <!--{if !$attach['attachimg'] && $_G['getattachcredits']}--><p>{lang attachcredits}: $_G[getattachcredits]</p><!--{/if}-->
            </a>
            <!--{if !IS_ROBOT && !$guestviewthumb}-->
            <div class="ren-attach-gm" >
                <!--{if $attach['price']}-->
                <a href="forum.php?mod=misc&action=viewattachpayments&aid=$attach[aid]" class="yi">{lang pay_view}</a>
                    <!--{if !$attach['payed']}-->
                        <a href="forum.php?mod=misc&action=attachpay&aid=$attach[aid]&tid=$attach[tid]" class="e dialog">{lang attachment_buy}</a>
                    <!--{/if}-->
                <!--{/if}-->
            </div>
            <!--{/if}-->
        </div>
    <!--{/if}-->
<!--{/block}-->
<!--{eval}-->
<!--
	return $return;
}
-->
<!--{/eval}-->

