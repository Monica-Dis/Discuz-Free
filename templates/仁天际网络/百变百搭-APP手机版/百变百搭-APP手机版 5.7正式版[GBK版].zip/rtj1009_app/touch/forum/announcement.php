<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl"> <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_dqwz z"> <span class="ren_bk_name">{lang announcement}</span> </div>
        <div class="ren_nav_right open-panel">
            <div class="ren_btn"> <span><span class="ren_nav_icon"><span></span></span></span> </div>
        </div>
    </div>
</header>
<!--{/if}-->

<script type="text/javascript" src="{$_G['setting']['jspath']}forum_viewthread.js?{VERHASH}"></script>
<script type="text/javascript">zoomstatus = parseInt($_G['setting']['zoomstatus']);var imagemaxwidth = '{$_G['setting']['imagemaxwidth']}';</script>

<div class="content p-b-0">
    <div class="rtj1009-nav-swiper">
        <div class="swiper-container2 ren_m_lx">
            <ul id="annonav" class="swiper-wrapper">
                <li class="swiper-slide{if empty($_GET[m])} a{/if}"><a href="forum.php?mod=announcement">{lang all}</a></li>
                <!--{loop $months $month}-->
                <li class="swiper-slide{if $_GET[m] == $month[0].$month[1]} a{/if}"><a href="forum.php?mod=announcement&m=$month[0].$month[1]">$month[0] {lang year} $month[1] {lang month}</a></li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <div class="ren-friend-list ren-notice-list ren-ann-list cl">
        <div id="annofilter"></div>
        <ul class="ren-notice-re cl">
            <!--{loop $announcelist $ann}-->
            <li>
                <div href="#announce$ann[id]" class="ren-ann-um{if $messageid != $ann[id]} umn{/if}">
                    <h3 id="a_ann_$ann[id]">$ann[subject]</h3>
                    <i></i>
                </div>
                <div class="ren-notice-note">
                    <p class="z">{lang author} : <a href="home.php?mod=space&username=$ann[authorenc]">$ann[author]</a></p>
                    <span class="z">$ann[starttime]</span>
                </div>

                <div id="announce$ann[id]" class="ren-ann-announce" style="display:<!--{if $_GET[id] == $ann[id]}--> block<!--{else}--> none<!--{/if}-->">
                    <span>$ann[message]</span>
                </div>
            </li>
            <!--{/loop}-->
        </ul>
	</div>
</div>


<script type="text/javascript">
    (function() {
        $('.ren-ann-um').on('click', function() {
            var obj = $(this);
            var subobj = $(obj.attr('href'));
            if(subobj.css('display') == 'none') {
                obj.find('h3').removeClass('ren-subforums');
                subobj.css('display', 'block');
            } else {
                obj.find('h3').addClass('ren-subforums');
                subobj.css('display', 'none');
            }
        });
    })();
</script>

<!--{template common/footer}-->
