<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
        <div class="ren_top_dqwz z">
			<span class="ren_bk_name">
			<!--{if $rtj1009_m_config['ren_m_view_nav'] == 1}-->
				<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}"><!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
				</a>
                <!--{else}-->
				<a href="forum.php?mod=forumdisplay&fid={$forum[fid]}"><!--{if $isactivitymaster}-->{lang activity_applylist_manage}<!--{else}-->{lang activity_applylist}<!--{/if}--></a>
                <!--{/if}-->
			</span>
        </div>
        <div class="ren_nav_right open-panel">
            <div class="ren_btn">
                <span><span class="ren_nav_icon"><span></span></span></span>
            </div>
        </div>
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content ren-view-main ren-applylist">
    <form id="applylistform" method="post" autocomplete="off" action="forum.php?mod=misc&action=activityapplylist&tid=$_G[tid]&applylistsubmit=yes&infloat=yes{if !empty($_GET['from'])}&from=$_GET['from']{/if}">
    <div class="ren-group-mem ren-apply-b">
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="operation" id="operation" value="" />
        <!--{if !empty($_GET['infloat'])}--><input type="hidden" name="handlekey" value="$_GET['handlekey']" /><!--{/if}-->
        <ul class="ren-friend-re cl">
            <!--{loop $applylist $apply}-->
            <li>
                <!--{if $isactivitymaster}-->
                <div class="z ren-mana-inp">
                    <!--{if $apply[uid] != $_G[uid]}-->
                    <input type="checkbox" name="applyidarray[]" class="pc" value="$apply[applyid]" />
                    <!--{else}-->
                    <input type="checkbox" class="pc" disabled="disabled" />
                    <!--{/if}-->
                </div>
                <!--{/if}-->
                <a href="home.php?mod=space&uid=$apply[uid]" class="ren-list-usxx">
                    <div class="ren-us-img z">
                        <!--{echo avatar($apply[uid], 'small')}-->
                    </div>
                    <div class="z ren-us-name tu">
                        <div class="z ren-mana-name">$apply[username]
                            <!--{if $isactivitymaster}-->
                            <span>
                            <!--{if $apply[verified] == 1}-->
                    {lang activity_allow_join}
                                <!--{elseif $apply[verified] == 2}-->
                    {lang activity_do_replenish}
                                <!--{else}-->
                    {lang activity_cant_audit}
                                <!--{/if}-->
                            </span>
                            <!--{/if}-->
                        </div>
                    </div>
                </a>
            </li>
            <div class="ren-apply-gd cl">
                <ul>
                    <!--{if $activity['cost']}-->
                    <li>{$rtj1009_lang['ren192']}&nbsp;&nbsp;:&nbsp;&nbsp;<!--{if $apply[payment] >= 0}-->$apply[payment] {lang payment_unit}<!--{else}-->{lang activity_self}<!--{/if}--></li>
                    <!--{/if}-->
                    <li>{$rtj1009_lang['ren193']}&nbsp;&nbsp;:&nbsp;&nbsp;$apply[dateline]</li>
                    <!--{if $apply[ufielddata]}-->
                    $apply[ufielddata]
                    <!--{else}-->
                    {lang no_informations}
                    <!--{/if}-->
                    <!--{if $apply[message]}--><li>{$rtj1009_lang['ren194']}&nbsp;&nbsp;:&nbsp;&nbsp;$apply[message]</li><!--{/if}-->
                </ul>
            </div>
            <!--{/loop}-->
        </ul>
    </div>
    <!--{if $isactivitymaster}-->
    <div class="ren-manageuser-list ren-isactivity">
        <ul class="cl">
            <li><button class="pn pnc vm" type="submit" value="true" name="applylistsubmit"><span>{lang confirm}</span></button></li>
            <li><button class="pn vm" type="submit" value="true" name="applylistsubmit" onclick="$('#operation').val('replenish');"><span>{lang to_improve}</span></button></li>
            <li><button class="pn vm" type="submit" value="true" name="applylistsubmit" onclick="$('#operation').val('delete');"><span>{lang activity_refuse}</span></button></li>
        </ul>
    </div>
    <!--{/if}-->
    </form>

    <!--{if !empty($_GET['infloat'])}-->
    <script type="text/javascript" reload="1">
        function succeedhandle_$_GET['handlekey'](locationhref) {
            ajaxget('forum.php?mod=viewthread&tid=$_G[tid]&viewpid=$_GET[pid]', 'post_$_GET[pid]');
            hideWindow('$_GET['handlekey']');
        }
    </script>
    <!--{/if}-->
</div>
<!--{template common/footer}-->
