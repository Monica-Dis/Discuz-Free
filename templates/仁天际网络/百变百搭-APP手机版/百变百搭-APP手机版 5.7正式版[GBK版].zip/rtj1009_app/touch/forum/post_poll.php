<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<input type="hidden" name="polls" value="yes" />
<div class="ren-post-poll ren_fb_hd cl">
	<ul class="cl">
		<input type="hidden" name="fid" value="$_G[fid]" />

<!--{if $_GET[action] == 'newthread'}-->
<input type="hidden" name="tpolloption" value="1" />
<li class="ren_hdxx_li ren_hdxx_he">
	<div class="ren_hdxx_lx">{lang post_poll_comment}</div>
</li>
<li id="pollm_c_1">
	<div class="ren-poll-add">
		<div id="dynamicTable"></div>
		<div id="tab11" style="display: none">
			<ul>
				<li class="ren_hdxx_li ren_spxx_de">
					<div class="ren_hdxx_lx">{$rtj1009_lang['ren077']}</div>
					<div class="ren_flxx_lxnr">
						<input type="text" name="polloption[]" class="px" placeholder="{$rtj1009_lang['ren078']}" autocomplete="off" tabindex="1" />
					</div>
					<div class="ren-flxx-dw">
						<a href="javascript:;" id="button2" onClick="deltr(this)"><i class="icon ren-font">&#xe61f;</i></a>
					</div>
				</li>
			</ul>
		</div>
	</div>
</li>
<div class="ren-post-poll-add">
	<a href="javascript:;" id="button1" onClick="addpolloption()">+ {lang post_poll_add}</a>
</div>
<!--{else}-->
<li id="pollm_c_1">
	<div class="ren-poll-add">
<!--{loop $poll['polloption'] $key $option}-->
	<!--{eval $ppid = $poll['polloptionid'][$key];}-->
		<input type="hidden" name="polloptionid[{$poll[polloptionid][$key]}]" value="$poll[polloptionid][$key]" />
		<ul>
			<li class="ren_hdxx_li ren_spxx_de">
				<div class="ren_hdxx_lx">
					<input type="text" name="displayorder[{$poll[polloptionid][$key]}]" class="px pxs vm" autocomplete="off" tabindex="1" value="$poll[displayorder][$key]" />
				</div>
				<div class="ren_flxx_lxnr">
					<input type="text" name="polloption[{$poll[polloptionid][$key]}]" class="px vm" autocomplete="off" tabindex="1" value="$option"{if !$_G['group']['alloweditpoll']} readonly="readonly"{/if} />
				</div>
			</li>
		</ul>
		<!--{/loop}-->
		<div id="dynamicTable"></div>
		<div id="tab11" style="display: none">
			<ul>
				<li class="ren_hdxx_li ren_spxx_de">
					<div class="ren_hdxx_lx">
						<input type="text" name="displayorder[{$poll[polloptionid][$key]}]" class="px pxs vm" autocomplete="off" tabindex="1" value="$poll[displayorder][$key]" />
					</div>
					<div class="ren_flxx_lxnr">
						<input type="text" name="polloption[]" class="px" placeholder="{$rtj1009_lang['ren078']}" autocomplete="off" tabindex="1" />
					</div>
					<div class="ren-flxx-dw">
						<a href="javascript:;" id="button2" onClick="deltr(this)"><i class="icon ren-font">&#xe61f;</i></a>
					</div>
				</li>
			</ul>
		</div>
	</div>
</li>

<div class="ren-post-poll-add">
	<a href="javascript:;" id="button1" onClick="addpolloption()">+{lang post_poll_add}</a>
</div>
<!--{/if}-->
		<li class="ren_hdxx_li ren_spxx_de">
			<div class="ren_hdxx_lx">{lang post_poll_allowmultiple}</div>
			<div class="ren_flxx_lxnr">
				<input type="text" name="maxchoices" id="maxchoices" class="px pxs" value="{if $_GET[action] == 'edit' && $poll[maxchoices]}$poll[maxchoices]{else}1{/if}" tabindex="1" />
			</div>
			<div class="ren-flxx-dw">{lang post_option}</div>
		</li>
	
		<li class="ren_hdxx_li ren_spxx_de">
			<div class="ren_hdxx_lx">{lang post_poll_expiration}</div>
			<div class="ren_flxx_lxnr">
				<input type="text" name="expiration" id="polldatas" class="px pxs" value="{if $_GET[action] == 'edit'}{if !$poll[expiration]}0{elseif $poll[expiration] < 0}{lang poll_close}{elseif $poll[expiration] < TIMESTAMP}{lang poll_finish}{else}{echo (round(($poll[expiration] - TIMESTAMP) / 86400))}{/if}{/if}" tabindex="1" />
			</div>
			<div class="ren-flxx-dw">{lang days}</div>
		</li>
	
		<li class="ren_hdxx_li ren_spxx_de">
			<div class="ren_hdxx_lx">{lang poll_after_result}</div>
			<div class="item-inner ren-sendreasonpm">
				<div class="item-input">
					<label for="visibilitypoll" class="label-switch">
					<input type="checkbox" name="sendreasonpm" id="sendreasonpm" value="1"{if $_GET[action] == 'edit' && !$poll[visible]} checked{/if} tabindex="1" />
						<div class="checkbox"></div>
					</label>
				</div>
			</div>
		</li>
		<li class="ren_hdxx_li ren_spxx_de">
			<div class="ren_hdxx_lx">{lang post_poll_overt}</div>
			<div class="item-inner ren-sendreasonpm">
				<div class="item-input">
					<label for="overt" class="label-switch">
					<input type="checkbox" name="overt" id="overt" value="1"{if $_GET[action] == 'edit' && $poll[overt]} checked{/if} tabindex="1" />
						<div class="checkbox"></div>
					</label>
				</div>
			</div>
		</li>
		<li class="ren_hdxx_he"><div class="ren_tie_ksf">{$rtj1009_lang['ren069']}</div></li>
	</ul>
</div>
		
<script type="text/javascript" reload="1">
var maxoptions = parseInt('$_G[setting][maxpolloptions]');
<!--{if $_GET[action] == 'newthread'}-->
	var curoptions = 0;
	var curnumber = 1;
	addpolloption();
	addpolloption();
	addpolloption();
<!--{else}-->
	var curnumber = curoptions = <!--{echo count($poll['polloption'])}-->;
<!--{/if}-->


function addpolloption() {
	if(curoptions < maxoptions) {
		$('#dynamicTable').append($('#tab11').html());
		curoptions++;
		curnumber++;

	} else {
		popup.open('{$rtj1009_lang[ren079]}', 'alert');
	}
}
function changeIndex() {
	var i = 1;
	$("#dynamicTable ul li").each(function () {
		$(this).find("input[name='NO']").val(i++);
	});
}

function deltr(opp) {
	var length = $("#dynamicTable ul li").length;
	if (length <= 1) {
		popup.open('{$rtj1009_lang[ren080]}', 'alert');
	} else {
		$(opp).parent().parent().remove();
		changeIndex();
	}
}
</script>
