<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $debate[umpire]}-->
	<!--{if $debate['umpirepoint']}-->
	<div>
		<p>
			<!--{if $debate[winner]}-->
			<!--{if $debate[winner] == 1}-->
			<label><strong>{lang debate_square}</strong>{lang debate_winner}</label>
			<!--{elseif $debate[winner] == 2}-->
			<label><strong>{lang debate_opponent}</strong>{lang debate_winner}</label>
			<!--{else}-->
			<label><strong>{lang debate_draw}</strong></label>
			<!--{/if}-->
			<!--{/if}-->
			<em>{lang debate_comment_dateline}: $debate[endtime]</em>
		</p>
		<!--{if $debate[umpirepoint]}--><p><strong>{lang debate_umpirepoint}</strong>: $debate[umpirepoint]</p><!--{/if}-->
		<!--{if $debate[bestdebater]}--><p><strong>{lang debate_bestdebater}</strong>: $debate[bestdebater]</p><!--{/if}-->
	</div>
	<!--{/if}-->
<!--{/if}-->

<div id="postmessage_$post[pid]" class="postmessage">$post[message]</div>



<div class="ren-debate">
	<div class="ren-deba-bfb cl">
		<div class="z bfb">{$rtj1009_lang['ren111']} {echo $debate[affirmvoteswidth]}%</div>
		<div class="y bfb">{$rtj1009_lang['ren112']} {echo $debate[negavoteswidth]}%</div>
	</div>
	<div class="ren-deba-bfb-img cl">
		<div class="z bfb-t">
			<div class="bfb-ts">
				<div class="bfb-tsxx" style="height: {echo $debate[affirmvoteswidth]}%;"></div>
			</div>
		</div>
		<div class="y bfb-t">
			<div class="bfb-ts">
				<div class="bfb-tsxx" style="height: {echo $debate[negavoteswidth]}%;"></div>
			</div>
		</div>
	</div>
	<div class="ren-deba-gd cl">
		<div class="z ren-deba-gdbf">
			<div class="ren-deba-gd-t">{lang debate_square_point}</div>
			<div class="ren-deba-gd-ts">$debate[affirmpoint]</div>
		</div>
		<div class="y ren-deba-gdbf">
			<div class="ren-deba-gd-t">{lang debate_opponent_point}</div>
			<div class="ren-deba-gd-ts">$debate[negapoint]</div>
		</div>
	</div>
	<div class="ren-deba-zc cl">
		<!--{if !$_G['forum_thread']['is_archived']}-->
			<a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=1" id="affirmbutton" class="dialog z affirmbutton">{$rtj1009_lang['ren113']} $debate[affirmvotes]</a>
		<!--{/if}-->
		<div class="ren-deba-vs z">vs</div>
		<a href="forum.php?mod=misc&action=debatevote&tid=$_G[tid]&stand=2" id="negabutton" class="dialog z negabutton">{$rtj1009_lang['ren114']} $debate[negavotes]</a>
	</div>
	<div class="ren-deba-sm cl">
	<!--{if $debate[endtime]}-->
		<p>{lang endtime}: $debate[endtime] <!--{if $debate[umpire]}-->{lang debate_umpire}: $debate[umpire]<!--{/if}--></p>
	<!--{/if}-->
	</div>
</div>
