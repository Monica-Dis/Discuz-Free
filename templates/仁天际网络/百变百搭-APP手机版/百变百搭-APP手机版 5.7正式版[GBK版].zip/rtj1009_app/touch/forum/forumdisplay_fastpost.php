<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="ren_kshf cl">
	<form method="post" autocomplete="off" id="fastpostform" action="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&extra=$_GET[extra]&replysubmit=yes&mobile=2">
	<input type="hidden" name="formhash" value="{FORMHASH}" />
	<input type="hidden" name="noticeauthor" value="$noticeauthor" />
	<div class="ren_post_pi cl">
		<!--{if $_G[forum_thread][special] == 5 && empty($firststand)}-->
		<div class="ren-post-xs">
            <ul class="ren-post-xsul">
                <li class="ren-post-xsli">
                    <div class="ren-post-xslx">{$rtj1009_lang['ren208']}</div>
                    <div class="ren-post-xsnr ren-webki">
                        <select id="stand" name="stand" >
                            <option value="">{lang debate_viewpoint}</option>
                            <option value="0">{lang debate_neutral}</option>
                            <option value="1">{lang debate_square}</option>
                            <option value="2">{lang debate_opponent}</option>
                        </select>
                    </div>
                </li>
            </ul>
		</div>
		<!--{/if}-->
		<div class="ren_post_nr cl">
        	<textarea type="text" placeholder="{$rtj1009_lang['ren053']}" class="ren_post_nrk" name="message" id="fastpostmessage"></textarea>
        </div>
        <div class="ren_post_tj">
            <a href="javascript:void(0)" class="face"><i class="icon ren-font">&#xe615;</i></a>
        	<a class="ren_post_tu" href="forum.php?mod=post&action=reply&fid=$_G[fid]&tid=$_G[tid]&reppost=$_G[forum_firstpid]&page=$page"><i class="icon ren-font">&#xe63e;</i></a>
			<div id="fastpostsubmitline" class="post_fast">
            	<input type="button" value="{lang reply}" class="ren_post_tjan" name="replysubmit" id="fastpostsubmit">
        	<!--{hook/viewthread_fastpost_button_mobile}-->
        	</div>
        </div>
        <!--{if $secqaacheck || $seccodecheck}--><!--{subtemplate common/seccheck}--><!--{/if}-->
	</div>
		<script type="text/javascript" src="template/rtj1009_app/js/smohan.face.js"></script>
        <div id="Smohan_FaceBox"></div>
	<script type="text/javascript">
	$(function (){
		$("a.face").smohanfacebox({
			Event : "click",
			divid : "Smohan_FaceBox",
			textid : "fastpostmessage"
		});
	});
	
	$('#Smohan_Showface').click(function(){
		$('#Zones').fadeIn(360);
		$('#Zones').html($('#Smohan_text').val());
		$('#Zones').replaceface($('#Zones').html());
	});
	</script>
    </form>
</div>

<script type="text/javascript">
	(function() {
		var form = $('#fastpostform');
		<!--{if (!$_G[uid] || $_G[uid] && !$allowpostreply) && !$allowfastpost}-->
		$('#fastpostmessage').on('focus', function() {
			<!--{if !$_G[uid]}-->
				popup.open('{lang nologin_tip}', 'confirm', 'member.php?mod=logging&action=login');
			<!--{else}-->
				popup.open('{lang nopostreply}', 'alert');
			<!--{/if}-->
			this.blur();
		});
		<!--{else}-->
		$('#fastpostmessage').on('focus', function() {
			var obj = $(this);
			if(obj.attr('color') == 'gray') {
				obj.attr('value', '');
				obj.removeClass('grey');
				obj.attr('color', 'black');
				$('#fastpostsubmitline').css('display', 'block');
			}
		})
		.on('blur', function() {
			var obj = $(this);
		});
		<!--{/if}-->
		$('#fastpostsubmit').on('click', function() {
			var msgobj = $('#fastpostmessage');
			$.ajax({
				type:'POST',
				url:form.attr('action') + '&handlekey=fastpost&loc=1&inajax=1',
				data:form.serialize(),
				dataType:'xml'
			})
			.success(function(s) {
				evalscript(s.lastChild.firstChild.nodeValue);
			})
			.error(function() {
				window.location.href = form.attr('action');
				popup.close();
			});
			return false;
		});

		$('#replyid').on('click', function() {
			$(document).scrollTop($(document).height());
			$('#fastpostmessage')[0].focus();
		});

	})();

	function succeedhandle_fastpost(locationhref, message, param) {
		var pid = param['pid'];
		var tid = param['tid'];
		if(pid) {
			$.ajax({
				type:'POST',
				url:'forum.php?mod=viewthread&tid=' + tid + '&viewpid=' + pid + '&mobile=2',
				dataType:'xml'
			})
			.success(function(s) {
				$('#post_new').append(s.lastChild.firstChild.nodeValue);
				popup.open('{$rtj1009_lang[ren054]}', 'alert');
				$(".button2").addClass("close-popup");
			})
			.error(function() {
				window.location.href = 'forum.php?mod=viewthread&tid=' + tid;
				popup.close();
			});
		} else {
			if(!message) {
				message = '{lang postreplyneedmod}';
			}
			popup.open(message, 'alert');
		}
		$('#fastpostmessage').attr('value', '');
		if(param['sechash']) {
			$('.seccodeimg').click();
		}
	}

	function errorhandle_fastpost(message, param) {
		popup.open(message, 'alert');
	}
</script>
