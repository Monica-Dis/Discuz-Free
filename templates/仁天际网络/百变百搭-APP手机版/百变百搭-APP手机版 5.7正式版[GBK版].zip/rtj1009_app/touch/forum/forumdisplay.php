<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->
<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header<!--{if (($_G[forum][banner] && !$subforumonly) || ($rtj1009_m_config['ren_m_forum_bg'] == 1 && $_G[forum][banner]) || $rtj1009_m_config['ren_m_forum_bg'] == 2 || $rtj1009_m_config['ren_m_forum_bg'] == 3) && $rtj1009_m_config['ren_m_forum_bg'] != 4}--> ren-menu-header<!--{/if}-->">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<span href="javascript:;" class="open-popup ren_vm" data-popup=".popup-forumdlist">
				<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
			</span>
		</div>
		<!--{if $rtj1009_m_config['ren_m_nav_fb'] || $rtj1009_m_config['ren_m_nav_ss']}-->
		<div class="y ren_list_nav">
			<!--{if $rtj1009_m_config['ren_m_nav_fb']}-->
			<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="ren_nav_fb"><span class="icon ren-font">&#xe619;</span></a>
			<!--{/if}-->
			<!--{if $rtj1009_m_config['ren_m_nav_ss']}-->
			<a href="search.php?mod=forum" class="ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
			<!--{/if}-->
		</div>
		<!--{else}-->
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
		<!--{/if}-->
    </div>
</header>
<!-- header end -->
<!--{/if}-->
<!--{if (($_G[forum][banner] && !$subforumonly) || ($rtj1009_m_config['ren_m_forum_bg'] == 1 && $_G[forum][banner]) || ($rtj1009_m_config['ren_m_forum_bg'] == 2 || $rtj1009_m_config['ren_m_forum_bg'] == 3)) && $rtj1009_m_config['ren_m_forum_bg'] != 4}-->
<script type="text/javascript">
    $(function(){
        var nav=$(".rtj1009_header");
        var win=$(window);
        var sc=$(document);
        win.scroll(function(){
            if(sc.scrollTop()>=80){
                nav.removeClass("ren-menu-header");
                $(".navTmp").fadeIn();
            }else{
                nav.addClass("ren-menu-header");
                $(".navTmp").fadeOut();
            }
        })
    })
</script>
<!--{/if}-->
<div class="popup popup-forumdlist">
	<header class="bar bar-nav popup-view-nav">
		<div class="ren_nav cl">
			<a href="javascript:;" class="z ren-fh close-popup"><i class="icon ren-font">&#xe64d;</i></a>
			<div class="ren_top_dqwz z">
				<span>{lang orderby}{$rtj1009_lang['ren142']}</span>
			</div>
		</div>
	</header>
  <div class="content-block">
	  <div class="ren-list-morem">
		  <!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
			<ul class="cl">
				<li><span>{lang orderby}{$rtj1009_lang['ren143']}</span></li>
				<li>
					<!--{if ($_GET['typeid'] || $_GET['sortid']) && !($_GET['filter'] && $_G['gp_specialtype'])}-->
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="a">{$rtj1009_lang['ren023']}</a>
					<!--{else}-->
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if !$filter} a{/if}">{$rtj1009_lang['ren023']}</a>
					<!--{/if}-->
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="ren_lbzxhf{if $_GET['filter'] == 'author'} a{/if}">{$rtj1009_lang['ren024']}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="ren_lbzkjh{if $_GET['filter'] == 'digest'} a{/if}">{$rtj1009_lang['ren021']}</a>
				</li>
			</ul>
			<!--{/if}-->
			<ul class="cl">
				<li><span>{lang orderby}{$rtj1009_lang['ren131']}</span></li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'dateline'}class="a"{/if}>{lang list_post_time}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=replies$forumdisplayadd[reply]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'replies'}class="a"{/if}>{lang replies}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=reply&orderby=views$forumdisplayadd[view]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['orderby'] == 'views'}class="a"{/if}>{lang views}</a>
				</li>
			</ul>
			<ul class="cl">
				<li><span>{lang orderby}{$rtj1009_lang['ren131']}</span></li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if !$_GET['dateline']}class="a"{/if}>{lang all}{lang search_any_date}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=86400$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '86400'}class="a"{/if}>{lang last_1_days}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=172800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '172800'}class="a"{/if}>{lang last_2_days}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=604800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '604800'}class="a"{/if}>{lang list_one_week}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=2592000$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '2592000'}class="a"{/if}>{lang list_one_month}</a>
				</li>
				<li>
					<a href="forum.php?mod=forumdisplay&fid=$_G[fid]&orderby={$_GET['orderby']}&filter=dateline&dateline=7948800$forumdisplayadd[dateline]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" {if $_GET['dateline'] == '7948800'}class="a"{/if}>{lang list_three_month}</a>
				</li>
			</ul>
		</div>
  </div>
</div>

<div class="content<!--{if !$rtj1009_m_config['ren_m_forum_bar']}--> p-b-0<!--{/if}--><!--{if (($_G[forum][banner] && !$subforumonly) || ($rtj1009_m_config['ren_m_forum_bg'] == 1 && $_G[forum][banner]) || ($rtj1009_m_config['ren_m_forum_bg'] == 2 || $rtj1009_m_config['ren_m_forum_bg'] == 3)) && $rtj1009_m_config['ren_m_forum_bg'] != 4}--> ren-forumdisplay-bg p-t-0<!--{/if}-->">
<!--{hook/forumdisplay_top_mobile}-->
<!-- main threadlist start -->

<div id="ren_tie_list" class="ren_tie_list rtj1009_m_main cl">
    {$block_forumdisplay_top}
    <!--{if (($_G[forum][banner] && !$subforumonly) || ($rtj1009_m_config['ren_m_forum_bg'] == 1 && $_G[forum][banner]) || ($rtj1009_m_config['ren_m_forum_bg'] == 2 || $rtj1009_m_config['ren_m_forum_bg'] == 3)) && $rtj1009_m_config['ren_m_forum_bg'] != 4}-->
    <!--{if $rtj1009_m_config['ren_m_forum_bg'] == 1 && $_G[forum][banner]}-->
    <div class="ren-forumdisplay-bgimg">
        <img src="$_G[forum][banner]" alt="$_G['forum'][name]" />
        <div class="ren-swiper-svg">
            <div class="ren-swiper-svg1"></div>
            <div class="ren-swiper-svg2"></div>
        </div>
    </div>
    <!--{elseif $rtj1009_m_config['ren_m_forum_bg'] != 1 && $rtj1009_m_config['ren_m_forum_bg'] != 4}-->
    <div class="ren-forumdisplay-bgimg">
        <!--{if $rtj1009_m_config['ren_m_forum_bg'] == 2}-->
        <img src="template/rtj1009_app/icon/forumdisplay-bg.jpg" alt="$_G['forum'][name]" />
        <!--{elseif $rtj1009_m_config['ren_m_forum_bg'] == 3}-->
        <!--{if $_G[forum][banner]}-->
        <img src="$_G[forum][banner]" alt="$_G['forum'][name]" />
        <!--{else}-->
        <img src="template/rtj1009_app/icon/forumdisplay-bg.jpg" alt="$_G['forum'][name]" />
        <!--{/if}-->
        <!--{/if}-->
        <div class="ren-swiper-svg">
            <div class="ren-swiper-svg1"></div>
            <div class="ren-swiper-svg2"></div>
        </div>
    </div>
    <!--{/if}-->
    <!--{/if}-->
	<div class="ren_bk_top cl">
        <div id="ren_bk_topz" class="z ren_bk_topz<!--{if !$rtj1009_m_config['ren_m_forum_info']}--> ren_foruminfo<!--{/if}--> cl">
            <div class="z head_bktp<!--{if $rtj1009_m_config['ren_m_forum_ico']}--> b-r-50<!--{/if}--> cl">
                <a href="forum.php?mod=forumdisplay&fid=$_G[fid]">
                    <!--{eval $ren_forum_ico = rtj1009_ficoisurl($_G['forum'][icon]);}-->
                    <img src="<!--{if $_G['forum'][icon]}-->$ren_forum_ico<!--{else}-->{$_G['style']['styleimgdir']}/rtj_zwtp100.jpg<!--{/if}-->" alt="{$_G['forum'][name]}">
                </a>           							 							
            </div>
            <div class="ren_bk_xx z cl">
                <h1 class="ren_bk_biaoti z"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]">$_G['forum'][name]</a></h1>
				<p class="z ren_bk_num"><span class="info_label">{$rtj1009_lang['ren028']}</span><span class="info_value">$_G[forum][posts]</span><span class="info_label">{$rtj1009_lang['ren029']}</span><span class="info_value">$_G[forum][favtimes]</span></p>
            </div>
            <p class="ren_bk_js z">
                <!--{if $_G[forum][description]}-->{$_G[forum][description]}<!--{else}-->{$rtj1009_lang['ren026']}<!--{/if}-->
            </p>
        </div>
        <div class="ren_bk_ft y">
			<!--{eval $ren_forum_gz = DB::fetch_first("SELECT * FROM  ".DB::table('home_favorite')." WHERE  uid=".$_G[uid]." and `idtype`='fid' and id=".$_G['fid']."");}-->
			<!--{if $ren_forum_gz[id]}-->
			<a class="dialog ren_qxgz" href="home.php?mod=spacecp&ac=favorite&op=delete&favid={$ren_forum_gz[favid]}&type=forum&formhash={FORMHASH}">{$rtj1009_lang['ren030']}</a>
			<!--{else}-->
			<a class="<!--{if $_G[uid]}-->dialog<!--{else}-->ren-confirm<!--{/if}-->" href="home.php?mod=spacecp&ac=favorite&type=forum&id={$_G['fid']}&handlekey=favoriteforum&formhash={FORMHASH}">{$rtj1009_lang['ren022']}</a>
			<!--{/if}-->
		</div>
    </div>
	<!--{if $subexists && $_G['page'] == 1}--><!--{template forum/forumdisplay_subforum}--><!--{/if}-->
<!--{if !$subforumonly}-->
    <div class="rtj1009_th cl">
        <!--{if ($_G['forum']['threadtypes'] && $_G['forum']['threadtypes']['listable']) || count($_G['forum']['threadsorts']['types']) > 0}-->
        <div class="rtj1009-nav-swiper">
			<div class="swiper-container2 ren_m_lx">
				<ul class="swiper-wrapper">
					<!--{if $_G['forum']['threadtypes']}-->
					<li id="ren_ttp_all" class="swiper-slide{if !$_GET['typeid'] && !$_GET['sortid']} a{/if}"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">{$rtj1009_lang['ren023']}</a></li>
						<!--{loop $_G['forum']['threadtypes']['types'] $id $name}-->
							<!--{if $_GET['typeid'] == $id}-->
							<li class="swiper-slide a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['sortid']}&filter=sortid&sortid=$_GET['sortid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
							<!--{else}-->
							<li class="swiper-slide"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=typeid&typeid=$id$forumdisplayadd[typeid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
							<!--{/if}-->
						<!--{/loop}-->
					<!--{/if}-->
			
					<!--{if $_G['forum']['threadsorts']}-->
						<!--{if $_G['forum']['threadtypes']}--><!--{/if}-->
						<!--{loop $_G['forum']['threadsorts']['types'] $id $name}-->
							<!--{if $_GET['sortid'] == $id}-->
							<li class="swiper-slide a"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_GET['typeid']}&filter=typeid&typeid=$_GET['typeid']{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
							<!--{else}-->
							<li class="swiper-slide"><a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=sortid&sortid=$id$forumdisplayadd[sortid]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}">$name</a></li>
							<!--{/if}-->
						<!--{/loop}-->
					<!--{/if}-->
				</ul>
			</div>
		</div>
        <!--{else}-->
        <div class="ren_tf cl">
        
        	<!--{if ($_GET['typeid'] || $_GET['sortid']) && !($_GET['filter'] && $_G['gp_specialtype'])}-->
        	<a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="a">{$rtj1009_lang['ren023']}</a>
            <!--{else}-->
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]{if $_G['forum']['threadsorts']['defaultshow']}&filter=sortall&sortall=1{/if}{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="{if !$filter} a{/if}">{$rtj1009_lang['ren023']}</a>
            <!--{/if}-->
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=author&orderby=dateline$forumdisplayadd[author]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="ren_lbzxhf{if $_GET['filter'] == 'author'} a{/if}">{$rtj1009_lang['ren024']}</a>
            <a href="forum.php?mod=forumdisplay&fid=$_G[fid]&filter=digest&digest=1$forumdisplayadd[digest]{if $_GET['archiveid']}&archiveid={$_GET['archiveid']}{/if}" class="ren_lbzkjh{if $_GET['filter'] == 'digest'} a{/if}">{$rtj1009_lang['ren021']}</a>
            
        </div>
        <!--{/if}-->
    </div>
<!--{if $_G['forum']['threadsorts']}-->
	<!--{if $quicksearchlist && !$_GET['archiveid']}-->
		<!--{subtemplate forum/search_sortoption}-->
	<!--{/if}-->
<!--{/if}-->
    <!--{eval require_once DISCUZ_ROOT.'./template/rtj1009_app/php/rtj1009_list.php';}-->
    {$block_forumdisplay_zd}
<!--{if empty($_G['forum']['sortmode']) || !$rtj1009_m_config['ren_flxx_list']}-->
    <!--{if $rtj1009_m_config['ren_m_forum_tst']}-->
        <!--{if $_G['forum_threadcount']}-->
            <div class="ren_zd cl">
                <ul style="height: 119px;">
                <!--{loop $_G['forum_threadlist'] $key $thread}-->
                        <!--{if in_array($thread['displayorder'], array(1, 2, 3, 4))}-->
                        <li>
                        <!--{hook/forumdisplay_thread_mobile $key}-->
                            <span class="ren_zhiding">{$rtj1009_lang['ren020']}</span>
                            <a href="forum.php?mod=viewthread&tid=$thread[tid]&extra=$extra" $thread[highlight]>{$thread[subject]}</a>
                        </li>
                    <!--{/if}-->
                <!--{/loop}-->
                </ul>
                <a href="javascript:void(0)" class="ren_zd_btn">{$rtj1009_lang[ren034]}<span class="icon ren-font">&#xe60a;</span></a>
            </div>
        <!--{/if}-->
    <!--{/if}-->
		<div class="<!--{if $rtj1009_list_style['style'] == 1 || $rtj1009_list_style['style'] ==7}-->ren_list_yi<!--{elseif $rtj1009_list_style['style'] == 2}-->ren_list_e<!--{elseif $rtj1009_list_style['style'] == 3}-->ren_list_san<!--{elseif $rtj1009_list_style['style'] == 4}-->ren_list_si<!--{elseif $rtj1009_list_style['style'] == 5}-->ren_list_wu<!--{elseif $rtj1009_list_style['style'] == 6}-->ren_list_liu<!--{/if}--> cl">
		<!--{subtemplate forum/forumdisplay_list}-->
		</div>
<!--{else}-->
    <!--{subtemplate forum/forumdisplay_sort}-->
<!--{/if}-->
$multipage
<!--{if $rtj1009_m_config['ren_m_forum_tst']}-->
<script type="text/javascript">
	var zdList= $(".ren_zd li").length;
	if(zdList==0){
		$(".ren_zd").css({
			"display":"none"
		})
	}
	if(zdList<4){
		$(".ren_zd .ren_zd_btn").css({
			"display":"none"
		})
	}
	if(zdList<=3){
		$(".ren_zd ul").css({
			"height":"auto"
		})
	}
	$(".ren_zd_btn").click(function(){
		if($(this).hasClass("sq")){
			$(this).html('{$rtj1009_lang[ren034]}<span class="icon ren-font">&#xe60a;</span>');
			$(this).removeClass("sq");
			$(this).siblings("ul").css({"height":"118px"});
		}else{
			$(this).html('{$rtj1009_lang[ren035]}<span class="icon ren-font">&#xe606;</span>');
			$(this).addClass("sq");
			$(this).siblings("ul").css({"height":"auto"});
		}
	})
</script>
<!--{/if}-->
<!--{/if}-->
<!--{if $rtj1009_m_config['ren_m_page'] && $multipage}-->
<!--{if empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']}-->
<!--{if !$_G['forum']['threadsorts']}-->
<script type="text/javascript">
var curpage = $page;
var ren_loading = false;
var html = '';
var ren_loading_ing='<div class="ren_loading loading">{$rtj1009_lang[ren018]}</div>';
var ren_loading_end='<div class="ren_loading">{$rtj1009_lang[ren019]}</div>';
$(document).ready(function(){
  $(".page").html(ren_loading_ing);
  $(window).scroll(function () {
	  if ($(document).scrollTop() + $(window).height()> $(document).height() - 130 && !ren_loading) {
	    ren_loading = true;
	    ren_list_page();
	  }
   });
});

function ren_list_page() {
	curpage++;
    <!--{if $_GET['typeid']}-->
    var url = 'forum.php?mod=forumdisplay&fid={$_G[fid]}{$forumdisplayadd[page]}&typeid={$_GET[typeid]}&filter=typeid&typeid={$_GET[typeid]}&mobile=2&page=' + curpage;
    <!--{else}-->
    var url = 'forum.php?mod=forumdisplay&fid={$_G[fid]}{$forumdisplayadd[page]}&page=' + curpage;
    <!--{/if}-->
	$.ajax({
		url : url,
		data : null,
		dataType : "html",
		cache: false,
		success : function(s) {
			if(curpage >= $maxpage){
				$(".page").html(ren_loading_end);
			}
			s = s.replace(/\n|\r/g, '');
			var nexts = s.match(/<ul class="ren_list cl">(.+?)<\/ul>/);
			var pagenum = s.match(/<strong>(\d+)<\/strong>/);
			pagenum = parseInt(pagenum[1]);
			
			if(pagenum==1){
				ren_loading = false;
			}else{

				if(nexts[1]){
					$(nexts[1]).insertAfter($(".ren_list>li").last());
				}
				ren_loading = false;
			}	
		}
	});
}
</script>
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
</div>





<!-- main threadlist end -->
<!--{hook/forumdisplay_bottom_mobile}-->
<div class="pullrefresh" style="display:none;"></div>

</div>
<!--{template common/footer}-->
