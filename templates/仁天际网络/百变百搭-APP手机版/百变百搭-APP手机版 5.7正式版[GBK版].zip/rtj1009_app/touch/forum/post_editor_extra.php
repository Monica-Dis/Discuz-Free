<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<div class="post_from ren_post_list cl">
    <ul class="cl">
    <!--{if $sortid}-->
		<input type="hidden" name="sortid" value="$sortid" />
	<!--{/if}-->
        <!--{if !$isfirstpost && $thread[special] == 5 && empty($firststand) && $_GET[action] != 'edit'}-->
        <div class="ren-post-xs">
            <ul class="ren-post-xsul">
                <li class="ren-post-xsli">
                    <div class="ren-post-xslx">{$rtj1009_lang['ren208']}</div>
                    <div class="ren-post-xsnr ren-webki">
                        <select name="stand" id="stand">
                            <option value="">{lang debate_viewpoint}</option>
                            <option value="0">{lang debate_neutral}</option>
                            <option value="1"{if $stand == 1} selected="selected"{/if}>{lang debate_square}</option>
                            <option value="2"{if $stand == 2} selected="selected"{/if}>{lang debate_opponent}</option>
                        </select>
                    </div>
                </li>
            </ul>
        </div>
        <!--{/if}-->
        <!--{if $isfirstpost && !empty($_G['forum'][threadtypes][types])}-->
        <li class="ren_bl_li post_lei">
            <select id="typeid" name="typeid" class="sort_sel">
                <option value="0" selected="selected">{lang select_thread_catgory}</option>
                <!--{loop $_G['forum'][threadtypes][types] $typeid $name}-->
                <!--{if empty($_G['forum']['threadtypes']['moderators'][$typeid]) || $_G['forum']['ismoderator']}-->
                <option value="$typeid"{if $thread['typeid'] == $typeid || $_GET['typeid'] == $typeid} selected="selected"{/if}><!--{echo strip_tags($name);}--></option>
                <!--{/if}-->
                <!--{/loop}-->
            </select>
        </li>
        <!--{/if}-->
        <li class="ren_bl_li">
			<!--{if $_GET['action'] != 'reply'}-->
			<div class="ren-post-btlabel">{lang thread_subject}</div>
			<div class="ren-post-btxx">
				<input type="text" tabindex="1" class="px" id="needsubject" size="30" autocomplete="off" value="$postinfo[subject]" name="subject" placeholder="{$rtj1009_lang['ren073']}" fwin="login">
			</div>
			<!--{else}-->
            {$rtj1009_lang['ren074']}$thread['subject']
			<!--{/if}-->
        </li>
        <!--{if $quotemessage}-->
        <li class="ren_bl_li">
            $quotemessage
        </li>
        <!--{/if}-->
        <!--{if $_GET[action] == 'edit' && $isorigauthor && ($isfirstpost && $thread['replies'] < 1 || !$isfirstpost) && !$rushreply && $_G['setting']['editperdel']}-->
        <li class="ren_bl_bjli">
        	<label>
            	<input type="checkbox" name="delete" id="delete" class="pc" value="1" title="{lang post_delpost}{if $thread[special] == 3}{lang reward_price_back}{/if}">{$rtj1009_lang['ren075']}
            </label>
        </li>
        <!--{/if}-->
        <!--{if $showthreadsorts}-->
            <div class="ren_fb_flxx cl">
                <!--{template forum/post_sortoption}-->
            </div>
        <!--{elseif $adveditor}-->
            <!--{if $special == 1}--><!--{template forum/post_poll}-->
            <!--{elseif $special == 2 && ($_GET[action] != 'edit' || ($_GET[action] == 'edit' && ($thread['authorid'] == $_G['uid'] && $_G['group']['allowposttrade'] || $_G['group']['allowedittrade'])))}--><!--{template forum/post_trade}-->
            <!--{elseif $special == 3}--><!--{template forum/post_reward}-->
            <!--{elseif $special == 4}--><!--{template forum/post_activity}-->
            <!--{elseif $special == 5}--><!--{template forum/post_debate}-->
            <!--{elseif $specialextra}--><div class="specialpost s_clear">$threadplughtml</div>
            <!--{/if}-->
        <!--{/if}-->
        <li class="ren_bl_no">
        <textarea class="pt" id="needmessage" tabindex="3" autocomplete="off" id="{$editorid}_textarea" name="$editor[textarea]" cols="80" rows="2"  placeholder="{$rtj1009_lang['ren053']}" fwin="reply">$postinfo[message]</textarea>
        </li>
    </ul>
        <script type="text/javascript" src="template/rtj1009_app/js/smohan.face.js"></script>
		<ul id="imglist" class="ren_post_imglist cl">
			<li class="ren_bl_fj">
				<a href="javascript:;" class="ren_bl_fjy">
					<i class="icon ren-font">&#xe60d;</i>
					<input type="file" name="Filedata" id="filedata" multiple="multiple" accept="image/*" />
				</a>
			</li>
		</ul>
		<!--{if $_GET[action] != 'edit' && ($secqaacheck || $seccodecheck)}-->
		<!--{subtemplate common/seccheck}-->
		<!--{/if}-->
		<!--{hook/post_bottom_mobile}-->
	</div>




