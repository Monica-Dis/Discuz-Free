<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template common/header}-->

<!--{if !strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') || $rtj1009_m_config['ren_weixin_hd']}-->
<!-- header start -->
<header class="bar bar-nav rtj1009_header">
    <div class="ren_nav cl">
        <a href="javascript:history.back();" class="z ren_fhjt back"><span></span></a>
		<div class="ren_top_dqwz z">
			<!--{if $subexists && $_G['page'] == 1}-->
			<span class="display ren_bk_name ren_vm" href="#subname_list">
				<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
			</span>
			<div id="subname_list" class="subname_list" display="true" style="display:none;">
				<ul>
				<!--{loop $sublist $sub}-->
				<li>
					<a href="forum.php?mod=forumdisplay&fid={$sub[fid]}">{$sub['name']}</a>
				</li>
				<!--{/loop}-->
				</ul>
			</div>
			<!--{else}-->
			<span class="ren_bk_name">
				<!--{eval echo strip_tags($_G['forum']['name']) ? strip_tags($_G['forum']['name']) : $_G['forum']['name'];}-->
			</span>
			<!--{/if}-->
		</div>
		<!--{if $rtj1009_m_config['ren_m_nav_fb'] || $rtj1009_m_config['ren_m_nav_ss']}-->
		<div class="y ren_list_nav">
			<!--{if $rtj1009_m_config['ren_m_nav_fb']}-->
			<a href="forum.php?mod=post&action=newthread&fid=$_G[fid]" class="ren_nav_fb"><span class="icon ren-font">&#xe619;</span></a>
			<!--{/if}-->
			<!--{if $rtj1009_m_config['ren_m_nav_ss']}-->
			<a href="search.php?mod=forum" class="ren_nav_ss"><span class="icon ren-font">&#xe68d;</span></a>
			<!--{/if}-->
		</div>
		<!--{else}-->
		<div class="ren_nav_right open-panel">
			<div class="ren_btn">
				<span><span class="ren_nav_icon"><span></span></span></span>
			</div>
		</div>
		<!--{/if}-->
    </div>
</header>
<!-- header end -->
<!--{/if}-->

<div class="content<!--{if !$rtj1009_m_config['ren_m_forum_bar']}--> p-b-0<!--{/if}-->">
	<div class="ren_qx_fw rtj1009_m_main m_pb12 cl">
		<div class="ren_qx_xx cl">
			<div class="ren_qx_ui"><i class="icon ren-font">&#xe61a;</i></div>
			<span class="ren_qx_ts">{lang forum_password_require}</span>
		</div>
		<div class="ren_qx_tj cl">
			<form method="post" autocomplete="off" action="forum.php?mod=forumdisplay&fid=$_G[fid]&action=pwverify">
				<input type="hidden" name="formhash" value="{FORMHASH}" />
				<div class="act_mn cl"><input type="password" name="pw" class="px vm" placeholder="{$rtj1009_lang['ren055']}" size="25" /></div>
				<div class="act_fai cl"><button class="pn pnc vm" type="submit" name="loginsubmit" value="true">{lang submit}</button></div>
			</form>
		</div>
	</div>
</div>
<!--{template common/footer}-->
